import asyncio
import json as stdlib_json
from typing import Any
import pytest

from meridian.gateway import Gateway
from meridian.response import Response
from meridian.exceptions import NotFound, BadRequest


async def mock_receive_empty():
    """Mock receive that returns empty body immediately"""
    return {"type": "http.request", "body": b"", "more_body": False}


async def make_asgi_receive(body: bytes = b""):
    """Factory for ASGI receive callable"""

    async def receive():
        return {"type": "http.request", "body": body, "more_body": False}

    return receive


async def make_asgi_send():
    """Factory for ASGI send callable that captures messages"""
    messages = []

    async def send(message):
        messages.append(message)

    send.messages = messages
    return send


def make_http_scope(
    method: str = "GET",
    path: str = "/",
    query_string: bytes = b"",
    headers: list[tuple[bytes, bytes]] | None = None,
) -> dict:
    """Helper to create an HTTP ASGI scope"""
    return {
        "type": "http",
        "asgi": {"version": "3.0"},
        "http_version": "1.1",
        "method": method,
        "scheme": "http",
        "path": path,
        "query_string": query_string,
        "root_path": "",
        "headers": headers or [],
        "server": ("127.0.0.1", 8000),
        "client": ("127.0.0.1", 54321),
    }


async def simple_handler(request):
    """Simple handler that returns 200 OK"""
    return Response(b"OK", 200)


async def json_handler(request):
    """Handler that returns JSON response"""
    data = {"message": "Hello", "status": "success"}
    body = stdlib_json.dumps(data).encode()
    return Response(body, 200, media_type="application/json")


async def slow_handler(request):
    """Handler that takes time"""
    await asyncio.sleep(0.1)
    return Response(b"Done", 200)


async def error_handler(request):
    """Handler that raises an error"""
    raise BadRequest("Invalid input")


async def meridian_error_handler(request):
    """Handler that raises MeridianError"""
    raise NotFound()


async def unhandled_error_handler(request):
    """Handler that raises an unhandled exception"""
    raise ValueError("Something went wrong")


@pytest.mark.asyncio
async def test_lifespan_startup_event():
    """Lifespan: accepts startup event and sends complete"""
    gateway = Gateway(simple_handler)

    scope = {"type": "lifespan"}

    messages_to_send = [
        {"type": "lifespan.startup"},
        {"type": "lifespan.shutdown"},
    ]
    message_index = 0

    async def receive():
        nonlocal message_index
        if message_index < len(messages_to_send):
            msg = messages_to_send[message_index]
            message_index += 1
            return msg
        await asyncio.sleep(10)
        return {"type": "lifespan.shutdown"}

    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert len(send.messages) == 2
    assert send.messages[0]["type"] == "lifespan.startup.complete"
    assert send.messages[1]["type"] == "lifespan.shutdown.complete"


@pytest.mark.asyncio
async def test_lifespan_shutdown_event():
    """Lifespan: accepts shutdown event and sends complete, then returns"""
    gateway = Gateway(simple_handler)

    scope = {"type": "lifespan"}
    messages_to_send = [
        {"type": "lifespan.startup"},
        {"type": "lifespan.shutdown"},
    ]
    message_index = 0

    async def receive():
        nonlocal message_index
        msg = messages_to_send[message_index]
        message_index += 1
        return msg

    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert len(send.messages) == 2
    assert send.messages[0]["type"] == "lifespan.startup.complete"
    assert send.messages[1]["type"] == "lifespan.shutdown.complete"


@pytest.mark.asyncio
async def test_lifespan_multiple_startup_shutdown_cycles():
    """Lifespan: handles multiple startup/shutdown events"""
    gateway = Gateway(simple_handler)

    scope = {"type": "lifespan"}
    messages_to_send = [
        {"type": "lifespan.startup"},
        {"type": "lifespan.shutdown"},
    ]
    message_index = 0

    async def receive():
        nonlocal message_index
        if message_index < len(messages_to_send):
            msg = messages_to_send[message_index]
            message_index += 1
            return msg
        return {"type": "lifespan.shutdown"}

    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert len(send.messages) == 2


@pytest.mark.asyncio
async def test_http_request_simple_get():
    """HTTP: simple GET request returns 200"""
    gateway = Gateway(simple_handler)
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert len(send.messages) == 2
    assert send.messages[0]["type"] == "http.response.start"
    assert send.messages[0]["status"] == 200
    assert send.messages[1]["type"] == "http.response.body"
    assert send.messages[1]["body"] == b"OK"


@pytest.mark.asyncio
async def test_http_request_with_json_response():
    """HTTP: handler returning JSON response"""
    gateway = Gateway(json_handler)
    scope = make_http_scope("GET", "/users")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert send.messages[0]["status"] == 200
    body = send.messages[1]["body"]
    data = stdlib_json.loads(body)
    assert data["message"] == "Hello"
    assert data["status"] == "success"


@pytest.mark.asyncio
async def test_http_request_post_method():
    """HTTP: POST request is dispatched correctly"""
    gateway = Gateway(simple_handler)
    scope = make_http_scope("POST", "/api/users")
    receive = await make_asgi_receive(b'{"name":"Alice"}')
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert send.messages[0]["status"] == 200


@pytest.mark.asyncio
async def test_http_request_with_path_and_query():
    """HTTP: request with path and query string"""
    gateway = Gateway(simple_handler)
    scope = make_http_scope("GET", "/search", query_string=b"q=python&limit=10")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert send.messages[0]["status"] == 200


@pytest.mark.asyncio
async def test_http_request_with_headers():
    """HTTP: request with custom headers"""
    gateway = Gateway(simple_handler)
    headers = [
        (b"authorization", b"Bearer token123"),
        (b"content-type", b"application/json"),
    ]
    scope = make_http_scope("GET", "/", headers=headers)
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert send.messages[0]["status"] == 200


@pytest.mark.asyncio
async def test_http_unknown_scope_type_ignored():
    """HTTP: unknown ASGI scope type is ignored"""
    gateway = Gateway(simple_handler)
    scope = {"type": "websocket"}

    async def receive():
        raise AssertionError("Should not call receive")

    async def send(msg):
        raise AssertionError("Should not call send")

    await gateway(scope, receive, send)


@pytest.mark.asyncio
async def test_backpressure_unlimited_concurrent():
    """Backpressure: max_concurrent_requests=0 means unlimited"""
    gateway = Gateway(simple_handler, max_concurrent_requests=0)

    assert gateway._semaphore is None


@pytest.mark.asyncio
async def test_backpressure_503_when_at_capacity():
    """Backpressure: returns 503 when semaphore at capacity"""
    gateway = Gateway(slow_handler, max_concurrent_requests=1)

    await gateway._semaphore.acquire()

    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway._handle_http(scope, receive, send)

    assert len(send.messages) >= 1
    assert send.messages[0]["status"] == 503

    headers = dict(send.messages[0]["headers"])
    assert b"retry-after" in headers


@pytest.mark.asyncio
async def test_backpressure_acquires_and_releases():
    """Backpressure: semaphore is acquired and released properly"""
    gateway = Gateway(simple_handler, max_concurrent_requests=2)

    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    initial_count = gateway._semaphore._value

    await gateway._handle_http(scope, receive, send)

    assert gateway._semaphore._value == initial_count


@pytest.mark.asyncio
async def test_hooks_on_request_start_called():
    """Hooks: on_request_start is called before handler"""
    hook_called = False

    async def hook(ctx):
        nonlocal hook_called
        hook_called = True

    gateway = Gateway(simple_handler, on_request_start=[hook])
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert hook_called is True


@pytest.mark.asyncio
async def test_hooks_on_request_end_called():
    """Hooks: on_request_end is called after handler"""
    hook_called = False
    received_response = None

    async def hook(ctx, response):
        nonlocal hook_called, received_response
        hook_called = True
        received_response = response

    gateway = Gateway(simple_handler, on_request_end=[hook])
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert hook_called is True
    assert isinstance(received_response, Response)


@pytest.mark.asyncio
async def test_hooks_on_request_error_called():
    """Hooks: on_request_error is called when handler raises MeridianError"""
    hook_called = False
    received_error = None

    async def hook(ctx, error):
        nonlocal hook_called, received_error
        hook_called = True
        received_error = error

    gateway = Gateway(meridian_error_handler, on_request_error=[hook])
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert hook_called is True
    assert isinstance(received_error, NotFound)


@pytest.mark.asyncio
async def test_hooks_multiple_start_hooks():
    """Hooks: multiple on_request_start hooks are called in order"""
    call_order = []

    async def hook1(ctx):
        call_order.append(1)

    async def hook2(ctx):
        call_order.append(2)

    async def hook3(ctx):
        call_order.append(3)

    gateway = Gateway(simple_handler, on_request_start=[hook1, hook2, hook3])
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert call_order == [1, 2, 3]


@pytest.mark.asyncio
async def test_hooks_multiple_end_hooks():
    """Hooks: multiple on_request_end hooks are called in order"""
    call_order = []

    async def hook1(ctx, response):
        call_order.append(1)

    async def hook2(ctx, response):
        call_order.append(2)

    gateway = Gateway(simple_handler, on_request_end=[hook1, hook2])
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert call_order == [1, 2]


@pytest.mark.asyncio
async def test_hooks_error_hook_called_on_unhandled_exception():
    """Hooks: on_request_error is called for unhandled exceptions"""
    hook_called = False
    received_error = None

    async def hook(ctx, error):
        nonlocal hook_called, received_error
        hook_called = True
        received_error = error

    gateway = Gateway(unhandled_error_handler, on_request_error=[hook])
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    with pytest.raises(ValueError):
        await gateway(scope, receive, send)

    assert hook_called is True
    assert isinstance(received_error, ValueError)


@pytest.mark.asyncio
async def test_exception_meridian_error_bad_request():
    """Exception: BadRequest (MeridianError) returns 400"""
    gateway = Gateway(error_handler)
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert send.messages[0]["status"] == 400


@pytest.mark.asyncio
async def test_exception_meridian_error_not_found():
    """Exception: NotFound (MeridianError) returns 404"""
    gateway = Gateway(meridian_error_handler)
    scope = make_http_scope("GET", "/nonexistent")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert send.messages[0]["status"] == 404


@pytest.mark.asyncio
async def test_exception_meridian_error_includes_allowed_methods():
    """Exception: MethodNotAllowed includes Allow header"""
    from meridian.exceptions import MethodNotAllowed

    async def method_not_allowed_handler(request):
        raise MethodNotAllowed(allowed=["GET", "POST"])

    gateway = Gateway(method_not_allowed_handler)
    scope = make_http_scope("DELETE", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert send.messages[0]["status"] == 405
    headers = dict(send.messages[0]["headers"])
    assert b"allow" in headers


@pytest.mark.asyncio
async def test_exception_unhandled_exception_returns_500():
    """Exception: unhandled exception returns 500 and re-raises"""
    gateway = Gateway(unhandled_error_handler)
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    with pytest.raises(ValueError):
        await gateway(scope, receive, send)

    assert send.messages[0]["status"] == 500


@pytest.mark.asyncio
async def test_exception_meridian_error_detail_in_response():
    """Exception: MeridianError detail is included in response body"""

    async def custom_error_handler(request):
        raise BadRequest("Email is invalid")

    gateway = Gateway(custom_error_handler)
    scope = make_http_scope("POST", "/users")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    body = send.messages[1]["body"]
    data = stdlib_json.loads(body)
    assert "detail" in data
    assert "Email is invalid" in data["detail"]


@pytest.mark.asyncio
async def test_context_created_on_http_request():
    """Context: RequestContext is created for HTTP requests"""
    from meridian.context import get_request_context

    async def context_checking_handler(request):
        ctx = get_request_context()
        assert ctx is not None
        assert ctx.method == "GET"
        assert ctx.path == "/api/users"
        return Response(b"OK")

    gateway = Gateway(context_checking_handler)
    scope = make_http_scope("GET", "/api/users")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)


@pytest.mark.asyncio
async def test_context_includes_deadline():
    """Context: RequestContext includes deadline if set"""
    from meridian.context import get_request_context

    async def context_checking_handler(request):
        ctx = get_request_context()
        assert ctx.deadline_at is not None
        return Response(b"OK")

    gateway = Gateway(context_checking_handler, request_deadline_ms=5000)
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)


@pytest.mark.asyncio
async def test_context_cleaned_up_after_request():
    """Context: RequestContext is available during request and may be cleaned up after"""
    from meridian.context import get_request_context

    context_during_request = None

    async def context_capturing_handler(request):
        nonlocal context_during_request
        context_during_request = get_request_context()
        return Response(b"OK")

    gateway = Gateway(context_capturing_handler)
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert context_during_request is not None
    assert context_during_request.method == "GET"
    try:
        _ = get_request_context()
    except LookupError:
        pass


@pytest.mark.asyncio
async def test_deadline_no_deadline_by_default():
    """Deadline: no deadline when request_deadline_ms is None"""
    gateway = Gateway(simple_handler, request_deadline_ms=None)
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)
    assert send.messages[0]["status"] == 200


@pytest.mark.asyncio
async def test_deadline_exceeding_deadline_returns_503():
    """Deadline: exceeding deadline returns 503 Service Unavailable"""

    async def slow_10_second_handler(request):
        await asyncio.sleep(10)
        return Response(b"Done")

    gateway = Gateway(slow_10_second_handler, request_deadline_ms=100)
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert send.messages[0]["status"] == 503


@pytest.mark.asyncio
async def test_deadline_error_hook_called():
    """Deadline: on_request_error hook is called on timeout"""
    error_hook_called = False
    received_error = None

    async def error_hook(ctx, error):
        nonlocal error_hook_called, received_error
        error_hook_called = True
        received_error = error

    async def slow_handler_timeout(request):
        await asyncio.sleep(10)
        return Response(b"Done")

    gateway = Gateway(
        slow_handler_timeout,
        request_deadline_ms=100,
        on_request_error=[error_hook],
    )
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert error_hook_called is True
    assert isinstance(received_error, TimeoutError)


@pytest.mark.asyncio
async def test_deadline_within_limit_completes():
    """Deadline: request completing within deadline succeeds"""

    async def fast_handler(request):
        await asyncio.sleep(0.01)
        return Response(b"Quick response")

    gateway = Gateway(fast_handler, request_deadline_ms=1000)
    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert send.messages[0]["status"] == 200
    assert send.messages[1]["body"] == b"Quick response"


@pytest.mark.asyncio
async def test_real_world_standard_rest_request():
    """Real-world: standard REST GET request through gateway"""

    async def get_user_handler(request):
        data = {"id": 1, "name": "Alice", "role": "admin"}
        body = stdlib_json.dumps(data).encode()
        return Response(body, 200, media_type="application/json")

    gateway = Gateway(get_user_handler)
    scope = make_http_scope("GET", "/users/1")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert send.messages[0]["status"] == 200
    body = send.messages[1]["body"]
    data = stdlib_json.loads(body)
    assert data["name"] == "Alice"


@pytest.mark.asyncio
async def test_real_world_post_with_validation():
    """Real-world: POST with validation error"""

    async def create_user_handler(request):
        raise BadRequest("Name is required")

    gateway = Gateway(create_user_handler)
    scope = make_http_scope("POST", "/users")
    receive = await make_asgi_receive(b"{}")
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert send.messages[0]["status"] == 400


@pytest.mark.asyncio
async def test_real_world_lifecycle_with_logging():
    """Real-world: logging with lifecycle hooks"""
    events = []

    async def start_hook(ctx):
        events.append({"type": "start", "method": ctx.method, "path": ctx.path})

    async def end_hook(ctx, response):
        events.append({"type": "end", "status": response.status_code})

    async def handler(request):
        return Response(b"Success", 200)

    gateway = Gateway(
        handler,
        on_request_start=[start_hook],
        on_request_end=[end_hook],
    )
    scope = make_http_scope("GET", "/api/data")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert len(events) == 2
    assert events[0]["type"] == "start"
    assert events[0]["method"] == "GET"
    assert events[0]["path"] == "/api/data"
    assert events[1]["type"] == "end"
    assert events[1]["status"] == 200


@pytest.mark.asyncio
async def test_real_world_rate_limiting_with_backpressure():
    """Real-world: rate limiting with semaphore"""
    call_count = 0

    async def counting_handler(request):
        nonlocal call_count
        call_count += 1
        return Response(f"Call {call_count}".encode(), 200)

    gateway = Gateway(counting_handler, max_concurrent_requests=1)

    scope = make_http_scope("GET", "/")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway._handle_http(scope, receive, send)
    assert send.messages[0]["status"] == 200

    await gateway._semaphore.acquire()

    scope2 = make_http_scope("GET", "/")
    receive2 = await make_asgi_receive()
    send2 = await make_asgi_send()

    await gateway._handle_http(scope2, receive2, send2)
    assert send2.messages[0]["status"] == 503


@pytest.mark.asyncio
async def test_real_world_deadline_with_error_tracking():
    """Real-world: deadline with error tracking"""
    errors_seen = []

    async def error_hook(ctx, error):
        errors_seen.append(type(error).__name__)

    async def timeout_prone_handler(request):
        await asyncio.sleep(5)
        return Response(b"Done")

    gateway = Gateway(
        timeout_prone_handler,
        request_deadline_ms=100,
        on_request_error=[error_hook],
    )
    scope = make_http_scope("GET", "/heavy-computation")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert send.messages[0]["status"] == 503
    assert "TimeoutError" in errors_seen


@pytest.mark.asyncio
async def test_real_world_multiple_hooks_with_state():
    """Real-world: multiple hooks managing request state"""
    state = {}

    async def auth_hook(ctx):
        state["authenticated"] = True
        state["user_id"] = "123"

    async def logging_hook(ctx, response):
        state["response_status"] = response.status_code
        state["logged"] = True

    async def handler(request):
        return Response(b"Protected resource", 200)

    gateway = Gateway(
        handler,
        on_request_start=[auth_hook],
        on_request_end=[logging_hook],
    )
    scope = make_http_scope("GET", "/protected")
    receive = await make_asgi_receive()
    send = await make_asgi_send()

    await gateway(scope, receive, send)

    assert state["authenticated"] is True
    assert state["user_id"] == "123"
    assert state["response_status"] == 200
    assert state["logged"] is True


@pytest.mark.asyncio
async def test_lifespan_startup_hooks_run_in_order():
    """Lifespan: startup hooks run in order and complete."""
    calls: list[str] = []

    async def hook1():
        calls.append("one")

    async def hook2():
        calls.append("two")

    gateway = Gateway(
        simple_handler,
        on_startup=[hook1, hook2],
    )

    messages = [
        {"type": "lifespan.startup"},
        {"type": "lifespan.shutdown"},
    ]
    idx = 0

    async def receive():
        nonlocal idx
        msg = messages[idx]
        idx += 1
        return msg

    sent: list[dict[str, Any]] = []

    async def send(message: dict[str, Any]) -> None:
        sent.append(message)

    await gateway(scope={"type": "lifespan"}, receive=receive, send=send)

    assert calls == ["one", "two"]
    assert sent[0]["type"] == "lifespan.startup.complete"
    assert sent[-1]["type"] == "lifespan.shutdown.complete"


@pytest.mark.asyncio
async def test_lifespan_startup_fails_fast():
    """Lifespan: startup fails fast and skips remaining hooks."""
    calls: list[str] = []

    async def bad_hook():
        calls.append("bad")
        raise RuntimeError("boom")

    async def good_hook():
        calls.append("good")

    gateway = Gateway(
        simple_handler,
        on_startup=[bad_hook, good_hook],
    )

    async def receive():
        return {"type": "lifespan.startup"}

    sent: list[dict[str, Any]] = []

    async def send(message: dict[str, Any]) -> None:
        sent.append(message)

    with pytest.raises(RuntimeError):
        await gateway(scope={"type": "lifespan"}, receive=receive, send=send)

    assert calls == ["bad"]
    assert sent[0]["type"] == "lifespan.startup.failed"


@pytest.mark.asyncio
async def test_lifespan_shutdown_collects_errors():
    """Lifespan: shutdown runs all hooks and reports errors."""
    calls: list[str] = []

    async def bad_hook():
        calls.append("bad")
        raise RuntimeError("shutdown error")

    async def good_hook():
        calls.append("good")

    gateway = Gateway(
        simple_handler,
        on_shutdown=[bad_hook, good_hook],
    )

    messages = [
        {"type": "lifespan.startup"},
        {"type": "lifespan.shutdown"},
    ]
    idx = 0

    async def receive():
        nonlocal idx
        msg = messages[idx]
        idx += 1
        return msg

    sent: list[dict[str, Any]] = []

    async def send(message: dict[str, Any]) -> None:
        sent.append(message)

    with pytest.raises(RuntimeError):
        await gateway(scope={"type": "lifespan"}, receive=receive, send=send)

    assert calls == ["bad", "good"]
    assert sent[0]["type"] == "lifespan.startup.complete"
    assert sent[1]["type"] == "lifespan.shutdown.failed"


@pytest.mark.asyncio
async def test_lifespan_shutdown_timeout_wins():
    """Lifespan: shutdown timeout wins over slow hooks."""
    calls: list[str] = []

    async def slow_hook():
        calls.append("slow")
        await asyncio.sleep(0.2)

    gateway = Gateway(
        simple_handler,
        on_shutdown=[slow_hook],
        drain_timeout_s=0.05,
    )

    messages = [
        {"type": "lifespan.startup"},
        {"type": "lifespan.shutdown"},
    ]
    idx = 0

    async def receive():
        nonlocal idx
        msg = messages[idx]
        idx += 1
        return msg

    sent: list[dict[str, Any]] = []

    async def send(message: dict[str, Any]) -> None:
        sent.append(message)

    with pytest.raises(RuntimeError):
        await gateway(scope={"type": "lifespan"}, receive=receive, send=send)

    assert calls == ["slow"]
    assert sent[0]["type"] == "lifespan.startup.complete"
    assert sent[1]["type"] == "lifespan.shutdown.failed"


@pytest.mark.asyncio
async def test_lifespan_shutdown_reports_multiple_errors():
    """Lifespan: shutdown.failed reports aggregated error count."""
    calls: list[str] = []

    async def bad_hook_one():
        calls.append("one")
        raise RuntimeError("first failure")

    async def bad_hook_two():
        calls.append("two")
        raise RuntimeError("second failure")

    gateway = Gateway(
        simple_handler,
        on_shutdown=[bad_hook_one, bad_hook_two],
    )

    messages = [
        {"type": "lifespan.startup"},
        {"type": "lifespan.shutdown"},
    ]
    idx = 0

    async def receive():
        nonlocal idx
        msg = messages[idx]
        idx += 1
        return msg

    sent: list[dict[str, Any]] = []

    async def send(message: dict[str, Any]) -> None:
        sent.append(message)

    with pytest.raises(RuntimeError):
        await gateway(scope={"type": "lifespan"}, receive=receive, send=send)

    assert calls == ["one", "two"]
    assert sent[0]["type"] == "lifespan.startup.complete"
    assert sent[1]["type"] == "lifespan.shutdown.failed"
    assert "2 error(s)" in sent[1]["message"]
