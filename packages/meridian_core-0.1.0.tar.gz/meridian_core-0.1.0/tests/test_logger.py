"""Tests for the central logging module."""

from __future__ import annotations

import logging

from meridian.logger import get_logger, setup_logging


def test_get_logger_adds_null_handler():
    logger = get_logger("test_logger")
    assert any(isinstance(h, logging.NullHandler) for h in logger.handlers)


def test_setup_logging_sets_level_debug():
    root = logging.getLogger()
    old_handlers = list(root.handlers)
    old_level = root.level

    try:
        root.handlers = []
        setup_logging(debug=True, app_name="meridian-test")
        assert root.level == logging.DEBUG
        assert logging.getLogger("meridian-test").level == logging.DEBUG
    finally:
        root.handlers = old_handlers
        root.setLevel(old_level)


def test_setup_logging_sets_level_info_by_default():
    root = logging.getLogger()
    old_handlers = list(root.handlers)
    old_level = root.level

    try:
        root.handlers = []
        setup_logging(debug=False, app_name="meridian-test")
        assert root.level == logging.INFO
    finally:
        root.handlers = old_handlers
        root.setLevel(old_level)
