"""
Extractors — Full Test Suite

Tests are organised into sections. Each test has a comment explaining
WHAT is being tested and WHY it's a distinct case worth covering.

The Extractors module contract being tested:
  - Path[T]: extract from URL path parameters with type coercion
  - Query[T]: extract from query string with defaults and optional support
  - Body[T]: extract and validate request body (JSON + Pydantic)
  - Header[T]: extract from headers with custom names and defaults
  - Inject[T]: resolve from DI container (requires container)
  - ExtractorPlan: build plan from handler signature and execute

Run with: pytest tests/test_extractors.py
"""

from __future__ import annotations
import json as stdlib_json
import pytest
from datetime import datetime
from enum import Enum
from typing import Optional
from uuid import UUID

from meridian.extractors import (
    Path,
    Query,
    Body,
    Header,
    Inject,
    ExtractorPlan,
    _PathExtractor,
    _QueryExtractor,
    _BodyExtractor,
    _HeaderExtractor,
    _InjectExtractor,
    _coerce,
    _is_optional,
)
from meridian.exceptions import ValidationError, ConfigurationError
from meridian.request import Request


async def mock_receive_empty():
    """Mock receive that returns empty body"""
    return {"type": "http.request", "body": b"", "more_body": False}


async def mock_receive_with_body(body: bytes):
    """Factory for mock receive with specific body"""

    async def receive():
        return {"type": "http.request", "body": body, "more_body": False}

    return receive


def make_request(
    path: str = "/",
    method: str = "GET",
    headers: list[tuple[bytes, bytes]] | None = None,
    query_string: bytes = b"",
    path_params: dict[str, str] | None = None,
    body: bytes = b"",
) -> Request:
    """Helper to create a Request with specified parameters"""
    scope = {
        "type": "http",
        "method": method,
        "path": path,
        "headers": headers or [],
        "query_string": query_string,
    }

    async def receive():
        return {"type": "http.request", "body": body, "more_body": False}

    request = Request(scope, receive)
    if path_params:
        request.path_params = path_params
    return request


class Status(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"


class Priority(int, Enum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3


def test_coerce_int():
    """_coerce: converts string to int"""
    assert _coerce("42", int) == 42
    assert _coerce("-100", int) == -100


def test_coerce_float():
    """_coerce: converts string to float"""
    assert _coerce("3.14", float) == 3.14
    assert _coerce("-2.5", float) == -2.5


def test_coerce_bool_true_values():
    """_coerce: converts truthy strings to True"""
    assert _coerce("true", bool) is True
    assert _coerce("True", bool) is True
    assert _coerce("1", bool) is True
    assert _coerce("yes", bool) is True
    assert _coerce("anything", bool) is True


def test_coerce_bool_false_values():
    """_coerce: converts falsy strings to False"""
    assert _coerce("false", bool) is False
    assert _coerce("False", bool) is False
    assert _coerce("0", bool) is False
    assert _coerce("no", bool) is False
    assert _coerce("", bool) is False


def test_coerce_str():
    """_coerce: passes through string"""
    assert _coerce("hello", str) == "hello"
    assert _coerce("123", str) == "123"


def test_coerce_uuid():
    """_coerce: converts string to UUID"""
    uuid_str = "550e8400-e29b-41d4-a716-446655440000"
    result = _coerce(uuid_str, UUID)
    assert isinstance(result, UUID)
    assert str(result) == uuid_str


def test_coerce_datetime_iso():
    """_coerce: converts ISO datetime string to datetime"""
    dt_str = "2024-01-15T10:30:00"
    result = _coerce(dt_str, datetime)
    assert isinstance(result, datetime)
    assert result.year == 2024
    assert result.month == 1
    assert result.day == 15


def test_coerce_datetime_with_z():
    """_coerce: converts ISO datetime with Z suffix to datetime"""
    dt_str = "2024-01-15T10:30:00Z"
    result = _coerce(dt_str, datetime)
    assert isinstance(result, datetime)
    assert result.year == 2024


def test_coerce_enum_by_value():
    """_coerce: converts string to Enum by value"""
    result = _coerce("active", Status)
    assert result == Status.ACTIVE
    assert isinstance(result, Status)


def test_coerce_enum_by_name():
    """_coerce: converts string to Enum by name if value fails"""
    result = _coerce("ACTIVE", Status)
    assert result == Status.ACTIVE


def test_coerce_int_enum():
    """_coerce: converts string to int Enum by name"""
    result = _coerce("MEDIUM", Priority)
    assert result == Priority.MEDIUM


def test_coerce_none_returns_none():
    """_coerce: returns None when value is None"""
    assert _coerce(None, int) is None
    assert _coerce(None, str) is None


def test_coerce_invalid_int_raises():
    """_coerce: raises ValueError for invalid int"""
    with pytest.raises(ValueError):
        _coerce("not-a-number", int)


def test_coerce_invalid_uuid_raises():
    """_coerce: raises ValueError for invalid UUID"""
    with pytest.raises(ValueError):
        _coerce("not-a-uuid", UUID)


def test_is_optional_with_optional():
    """_is_optional: detects Optional[T]"""
    assert _is_optional(Optional[int]) is True
    assert _is_optional(Optional[str]) is True


def test_is_optional_with_union_none():
    """_is_optional: detects Union[T, None]"""
    from typing import Union

    assert _is_optional(Union[int, None]) is True
    assert _is_optional(Union[str, None]) is True


def test_is_optional_with_pipe_none():
    """_is_optional: detects T | None (Python 3.10+)"""
    try:
        annotation = eval("int | None")
        assert _is_optional(annotation) is True
    except SyntaxError:
        pytest.skip("Python 3.10+ required for | syntax")


def test_is_optional_non_optional():
    """_is_optional: returns False for non-optional types"""
    assert _is_optional(int) is False
    assert _is_optional(str) is False
    assert _is_optional(list) is False


def test_is_optional_union_without_none():
    """_is_optional: returns False for Union without None"""
    from typing import Union

    assert _is_optional(Union[int, str]) is False


@pytest.mark.asyncio
async def test_path_extractor_basic_string():
    """PathExtractor: extracts string path parameter"""
    extractor = _PathExtractor("_id", str, is_optional=False)
    request = make_request(path_params={"_id": "123"})

    result = await extractor.extract(request)
    assert result == "123"


@pytest.mark.asyncio
async def test_path_extractor_coerces_to_int():
    """PathExtractor: coerces string to int"""
    extractor = _PathExtractor("_id", int, is_optional=False)
    request = make_request(path_params={"_id": "42"})

    result = await extractor.extract(request)
    assert result == 42
    assert isinstance(result, int)


@pytest.mark.asyncio
async def test_path_extractor_coerces_to_uuid():
    """PathExtractor: coerces string to UUID"""
    uuid_str = "550e8400-e29b-41d4-a716-446655440000"
    extractor = _PathExtractor("user_id", UUID, is_optional=False)
    request = make_request(path_params={"user_id": uuid_str})

    result = await extractor.extract(request)
    assert isinstance(result, UUID)
    assert str(result) == uuid_str


@pytest.mark.asyncio
async def test_path_extractor_missing_required_raises():
    """PathExtractor: raises ValueError when required param missing"""
    extractor = _PathExtractor("_id", int, is_optional=False)
    request = make_request(path_params={})

    with pytest.raises(ValueError, match="Path parameter '_id' not found"):
        await extractor.extract(request)


@pytest.mark.asyncio
async def test_path_extractor_missing_optional_returns_none():
    """PathExtractor: returns None when optional param missing"""
    extractor = _PathExtractor("_id", int, is_optional=True)
    request = make_request(path_params={})

    result = await extractor.extract(request)
    assert result is None


@pytest.mark.asyncio
async def test_path_extractor_multiple_params():
    """PathExtractor: works with multiple path parameters"""
    extractor1 = _PathExtractor("user_id", int, is_optional=False)
    extractor2 = _PathExtractor("post_id", int, is_optional=False)
    request = make_request(path_params={"user_id": "10", "post_id": "20"})

    result1 = await extractor1.extract(request)
    result2 = await extractor2.extract(request)

    assert result1 == 10
    assert result2 == 20


@pytest.mark.asyncio
async def test_query_extractor_basic_string():
    """QueryExtractor: extracts string query parameter"""
    import inspect

    extractor = _QueryExtractor(
        "q",
        str,
        default=inspect.Parameter.empty,
        is_optional=False,
        ignore_unknown=True,
    )
    request = make_request(query_string=b"q=hello")

    result = await extractor.extract(request)
    assert result == "hello"


@pytest.mark.asyncio
async def test_query_extractor_coerces_to_int():
    """QueryExtractor: coerces string to int"""
    import inspect

    extractor = _QueryExtractor(
        "page", int, default=inspect.Parameter.empty, is_optional=False
    )
    request = make_request(query_string=b"page=5")

    result = await extractor.extract(request)
    assert result == 5
    assert isinstance(result, int)


@pytest.mark.asyncio
async def test_query_extractor_with_default():
    """QueryExtractor: returns default when param missing"""
    extractor = _QueryExtractor(
        "page", int, default=1, is_optional=False, ignore_unknown=True
    )
    request = make_request(query_string=b"")

    result = await extractor.extract(request)
    assert result == 1


@pytest.mark.asyncio
async def test_query_extractor_missing_required_raises():
    """QueryExtractor: raises ValueError when required param missing and no default"""
    import inspect

    extractor = _QueryExtractor(
        "q", str, default=inspect.Parameter.empty, is_optional=False
    )
    request = make_request(query_string=b"")

    with pytest.raises(ValueError, match="Required query parameter 'q' missing"):
        await extractor.extract(request)


@pytest.mark.asyncio
async def test_query_extractor_missing_optional_returns_none():
    """QueryExtractor: returns None when optional param missing"""
    import inspect

    extractor = _QueryExtractor(
        "filter", str, default=inspect.Parameter.empty, is_optional=True
    )
    request = make_request(query_string=b"")

    result = await extractor.extract(request)
    assert result is None


@pytest.mark.asyncio
async def test_query_extractor_bool_coercion():
    """QueryExtractor: coerces to bool correctly"""
    import inspect

    extractor_true = _QueryExtractor(
        "active", bool, default=inspect.Parameter.empty, is_optional=False
    )
    extractor_false = _QueryExtractor(
        "active", bool, default=inspect.Parameter.empty, is_optional=False
    )

    request_true = make_request(query_string=b"active=true")
    request_false = make_request(query_string=b"active=false")

    assert await extractor_true.extract(request_true) is True
    assert await extractor_false.extract(request_false) is False


@pytest.mark.asyncio
async def test_query_extractor_multiple_params():
    """QueryExtractor: works with multiple query parameters"""
    import inspect

    extractor1 = _QueryExtractor(
        "page", int, default=inspect.Parameter.empty, is_optional=False
    )
    extractor2 = _QueryExtractor(
        "limit", int, default=inspect.Parameter.empty, is_optional=False
    )
    request = make_request(query_string=b"page=2&limit=50")

    result1 = await extractor1.extract(request)
    result2 = await extractor2.extract(request)

    assert result1 == 2
    assert result2 == 50


@pytest.mark.asyncio
async def test_body_extractor_json_dict():
    """BodyExtractor: extracts JSON dictionary"""
    extractor = _BodyExtractor(dict, is_optional=False)
    body = stdlib_json.dumps({"name": "Alice", "age": 30}).encode()
    request = make_request(body=body)

    result = await extractor.extract(request)
    assert result == {"name": "Alice", "age": 30}


@pytest.mark.asyncio
async def test_body_extractor_json_list():
    """BodyExtractor: extracts JSON list"""
    extractor = _BodyExtractor(list, is_optional=False)
    body = stdlib_json.dumps([1, 2, 3, 4]).encode()
    request = make_request(body=body)

    result = await extractor.extract(request)
    assert result == [1, 2, 3, 4]


@pytest.mark.asyncio
async def test_body_extractor_empty_body_required_raises():
    """BodyExtractor: raises ValueError for empty body when required"""
    extractor = _BodyExtractor(dict, is_optional=False)
    request = make_request(body=b"")

    with pytest.raises(ValueError, match="Request body is empty"):
        await extractor.extract(request)


@pytest.mark.asyncio
async def test_body_extractor_empty_body_optional_returns_none():
    """BodyExtractor: returns None for empty body when optional"""
    extractor = _BodyExtractor(dict, is_optional=True)
    request = make_request(body=b"")

    result = await extractor.extract(request)
    assert result is None


@pytest.mark.asyncio
async def test_body_extractor_invalid_json_raises():
    """BodyExtractor: raises ValueError for invalid JSON"""
    extractor = _BodyExtractor(dict, is_optional=False)
    request = make_request(body=b"not valid json")

    with pytest.raises(ValueError, match="Invalid JSON body"):
        await extractor.extract(request)


@pytest.mark.asyncio
async def test_body_extractor_null_optional_returns_none():
    """BodyExtractor: returns None for 'null' body when optional"""
    extractor = _BodyExtractor(dict, is_optional=True)
    request = make_request(body=b"null")

    result = await extractor.extract(request)
    assert result is None


@pytest.mark.asyncio
async def test_body_extractor_with_pydantic():
    """BodyExtractor: validates with Pydantic model if available"""
    try:
        from pydantic import BaseModel

        class User(BaseModel):
            name: str
            age: int

        extractor = _BodyExtractor(User, is_optional=False)
        body = stdlib_json.dumps({"name": "Bob", "age": 25}).encode()
        request = make_request(body=body)

        result = await extractor.extract(request)
        assert isinstance(result, User)
        assert result.name == "Bob"
        assert result.age == 25
    except ImportError:
        pytest.skip("Pydantic not installed")


@pytest.mark.asyncio
async def test_body_extractor_nested_json():
    """BodyExtractor: handles nested JSON structures"""
    extractor = _BodyExtractor(dict, is_optional=False)
    body = stdlib_json.dumps(
        {
            "user": {"name": "Charlie", "email": "charlie@example.com"},
            "items": [1, 2, 3],
        }
    ).encode()
    request = make_request(body=body)

    result = await extractor.extract(request)
    assert result["user"]["name"] == "Charlie"
    assert result["items"] == [1, 2, 3]


@pytest.mark.asyncio
async def test_header_extractor_basic_string():
    """HeaderExtractor: extracts string header"""
    import inspect

    extractor = _HeaderExtractor(
        "Authorization", str, default=inspect.Parameter.empty, is_optional=False
    )
    request = make_request(headers=[(b"authorization", b"Bearer token123")])

    result = await extractor.extract(request)
    assert result == "Bearer token123"


@pytest.mark.asyncio
async def test_header_extractor_case_insensitive():
    """HeaderExtractor: header lookup is case-insensitive"""
    import inspect

    extractor = _HeaderExtractor(
        "Content-Type", str, default=inspect.Parameter.empty, is_optional=False
    )
    request = make_request(headers=[(b"content-type", b"application/json")])

    result = await extractor.extract(request)
    assert result == "application/json"


@pytest.mark.asyncio
async def test_header_extractor_with_default():
    """HeaderExtractor: returns default when header missing"""
    extractor = _HeaderExtractor(
        "X-Custom", str, default="default-value", is_optional=False
    )
    request = make_request(headers=[])

    result = await extractor.extract(request)
    assert result == "default-value"


@pytest.mark.asyncio
async def test_header_extractor_missing_required_raises():
    """HeaderExtractor: raises ValueError when required header missing"""
    import inspect

    extractor = _HeaderExtractor(
        "Authorization", str, default=inspect.Parameter.empty, is_optional=False
    )
    request = make_request(headers=[])

    with pytest.raises(ValueError, match="Required header 'Authorization' missing"):
        await extractor.extract(request)


@pytest.mark.asyncio
async def test_header_extractor_missing_optional_returns_none():
    """HeaderExtractor: returns None when optional header missing"""
    import inspect

    extractor = _HeaderExtractor(
        "X-Optional", str, default=inspect.Parameter.empty, is_optional=True
    )
    request = make_request(headers=[])

    result = await extractor.extract(request)
    assert result is None


@pytest.mark.asyncio
async def test_header_extractor_coerces_to_int():
    """HeaderExtractor: coerces header value to int"""
    import inspect

    extractor = _HeaderExtractor(
        "X-Rate-Limit", int, default=inspect.Parameter.empty, is_optional=False
    )
    request = make_request(headers=[(b"x-rate-limit", b"100")])

    result = await extractor.extract(request)
    assert result == 100
    assert isinstance(result, int)


@pytest.mark.asyncio
async def test_header_extractor_ignores_header_instance_default():
    """HeaderExtractor: doesn't return Header() instance as default"""
    from meridian.extractors import Header as HeaderMarker

    header_default = HeaderMarker("X-Custom-Name")
    extractor = _HeaderExtractor(
        "X-Custom-Name", str, default=header_default, is_optional=True
    )
    request = make_request(headers=[])

    result = await extractor.extract(request)
    assert result is None


@pytest.mark.asyncio
async def test_inject_extractor_resolves_from_container():
    """InjectExtractor: resolves type from DI container"""

    class FakeContainer:
        @staticmethod
        async def resolve(target_type):
            if target_type == str:
                return "injected-value"
            return None

    container = FakeContainer()
    extractor = _InjectExtractor(str, container)
    request = make_request()

    result = await extractor.extract(request)
    assert result == "injected-value"


@pytest.mark.asyncio
async def test_inject_extractor_resolves_custom_type():
    """InjectExtractor: resolves custom class from container"""

    class Database:
        def __init__(self):
            self.connected = True

    class FakeContainer:
        async def resolve(self, target_type):
            if target_type == Database:
                return Database()
            return None

    container = FakeContainer()
    extractor = _InjectExtractor(Database, container)
    request = make_request()

    result = await extractor.extract(request)
    assert isinstance(result, Database)
    assert result.connected is True


def test_plan_build_single_path_param():
    """ExtractorPlan.build: builds plan for single Path parameter"""

    def handler(_id: Path[int]):
        pass

    plan = ExtractorPlan.build(handler)
    assert len(plan._steps) == 1
    assert plan._steps[0][0] == "_id"
    assert isinstance(plan._steps[0][1], _PathExtractor)


def test_plan_build_single_query_param():
    """ExtractorPlan.build: builds plan for single Query parameter"""

    def handler(page: Query[int]):
        pass

    plan = ExtractorPlan.build(handler)
    assert len(plan._steps) == 1
    assert plan._steps[0][0] == "page"
    assert isinstance(plan._steps[0][1], _QueryExtractor)


def test_plan_build_single_body_param():
    """ExtractorPlan.build: builds plan for single Body parameter"""

    def handler(data: Body[dict]):
        pass

    plan = ExtractorPlan.build(handler)
    assert len(plan._steps) == 1
    assert plan._steps[0][0] == "data"
    assert isinstance(plan._steps[0][1], _BodyExtractor)


def test_plan_build_single_header_param():
    """ExtractorPlan.build: builds plan for single Header parameter"""

    def handler(auth: Header[str]):
        pass

    plan = ExtractorPlan.build(handler)
    assert len(plan._steps) == 1
    assert plan._steps[0][0] == "auth"
    assert isinstance(plan._steps[0][1], _HeaderExtractor)


def test_plan_build_multiple_params():
    """ExtractorPlan.build: builds plan for multiple parameters"""

    def handler(_id: Path[int], page: Query[int], data: Body[dict]):
        pass

    plan = ExtractorPlan.build(handler)
    assert len(plan._steps) == 3
    assert plan._steps[0][0] == "_id"
    assert plan._steps[1][0] == "page"
    assert plan._steps[2][0] == "data"


def test_plan_build_optional_params():
    """ExtractorPlan.build: handles parameters with defaults"""

    def handler(_id: Path[int], filter: Query[str] = "all"):
        pass

    plan = ExtractorPlan.build(handler)
    assert len(plan._steps) == 2
    assert isinstance(plan._steps[0][1], _PathExtractor)
    assert isinstance(plan._steps[1][1], _QueryExtractor)
    assert plan._steps[1][1].default == "all"


def test_plan_build_with_defaults():
    """ExtractorPlan.build: preserves default values"""

    def handler(page: Query[int] = 1, limit: Query[int] = 10):
        pass

    plan = ExtractorPlan.build(handler)
    assert len(plan._steps) == 2
    assert plan._steps[0][1].default == 1
    assert plan._steps[1][1].default == 10


def test_plan_build_header_with_custom_name():
    """ExtractorPlan.build: uses custom header name from Header()"""

    def handler(token: Header[str] = Header("X-Auth-Token")):
        pass

    plan = ExtractorPlan.build(handler)
    assert len(plan._steps) == 1
    extractor = plan._steps[0][1]
    assert extractor.header_name == "X-Auth-Token"


def test_plan_build_header_normalizes_name():
    """ExtractorPlan.build: normalizes header name from parameter name"""

    def handler(user_agent: Header[str]):
        pass

    plan = ExtractorPlan.build(handler)
    extractor = plan._steps[0][1]
    assert extractor.header_name == "User-Agent"


def test_plan_build_no_annotation_raises():
    """ExtractorPlan.build: raises ConfigurationError for unannotated param"""

    def handler(_id):
        pass

    with pytest.raises(ConfigurationError, match="has no type annotation"):
        ExtractorPlan.build(handler)


def test_plan_build_wrong_annotation_raises():
    """ExtractorPlan.build: raises ConfigurationError for non-extractor annotation"""

    def handler(_id: int):
        pass

    with pytest.raises(ConfigurationError, match="not a recognised extractor type"):
        ExtractorPlan.build(handler)


def test_plan_build_inject_without_container_raises():
    """ExtractorPlan.build: raises ConfigurationError for Inject without container"""

    def handler(db: Inject[str]):
        pass

    with pytest.raises(ConfigurationError, match="no DI container is attached"):
        ExtractorPlan.build(handler)


def test_plan_build_inject_with_container():
    """ExtractorPlan.build: builds plan for Inject with container"""

    class FakeContainer:
        async def resolve(self, target_type):
            return None

    def handler(db: Inject[str]):
        pass

    container = FakeContainer()
    plan = ExtractorPlan.build(handler, container=container)
    assert len(plan._steps) == 1
    assert isinstance(plan._steps[0][1], _InjectExtractor)


def test_plan_build_empty_handler():
    """ExtractorPlan.build: builds empty plan for handler with no params"""

    def handler():
        pass

    plan = ExtractorPlan.build(handler)
    assert len(plan._steps) == 0


def test_plan_build_complex_types():
    """ExtractorPlan.build: handles complex type annotations"""

    def handler(
        user_id: Path[UUID],
        status: Query[Status],
        created_after: Query[datetime],
    ):
        pass

    plan = ExtractorPlan.build(handler)
    assert len(plan._steps) == 3
    assert plan._steps[0][1].target_type == UUID
    assert plan._steps[1][1].target_type == Status
    assert plan._steps[2][1].target_type == datetime


@pytest.mark.asyncio
async def test_plan_run_single_path_param():
    """ExtractorPlan.run: extracts single path parameter"""

    def handler(_id: Path[int]):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(path_params={"_id": "42"})

    kwargs = await plan.run(request)
    assert kwargs == {"_id": 42}


@pytest.mark.asyncio
async def test_plan_run_multiple_params():
    """ExtractorPlan.run: extracts multiple parameters"""

    def handler(_id: Path[int], page: Query[int]):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(path_params={"_id": "10"}, query_string=b"page=2")

    kwargs = await plan.run(request)
    assert kwargs == {"_id": 10, "page": 2}


@pytest.mark.asyncio
async def test_plan_run_with_body():
    """ExtractorPlan.run: extracts body parameter"""

    def handler(data: Body[dict]):
        pass

    plan = ExtractorPlan.build(handler)
    body = stdlib_json.dumps({"name": "Alice"}).encode()
    request = make_request(body=body)

    kwargs = await plan.run(request)
    assert kwargs == {"data": {"name": "Alice"}}


@pytest.mark.asyncio
async def test_plan_run_with_header():
    """ExtractorPlan.run: extracts header parameter"""

    def handler(auth: Header[str]):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(headers=[(b"auth", b"Bearer token")])

    kwargs = await plan.run(request)
    assert kwargs == {"auth": "Bearer token"}


@pytest.mark.asyncio
async def test_plan_run_collects_all_errors():
    """ExtractorPlan.run: collects all validation errors before raising"""

    def handler(_id: Path[int], page: Query[int], limit: Query[int]):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(path_params={}, query_string=b"")

    with pytest.raises(ValidationError) as exc_info:
        await plan.run(request)

    errors = exc_info.value.errors
    assert len(errors) == 3
    assert any(e["field"] == "_id" for e in errors)
    assert any(e["field"] == "page" for e in errors)
    assert any(e["field"] == "limit" for e in errors)


@pytest.mark.asyncio
async def test_plan_run_validation_error_structure():
    """ExtractorPlan.run: ValidationError has correct structure"""

    def handler(_id: Path[int]):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(path_params={})

    with pytest.raises(ValidationError) as exc_info:
        await plan.run(request)

    error = exc_info.value.errors[0]
    assert "field" in error
    assert "source" in error
    assert "message" in error
    assert error["field"] == "_id"
    assert error["source"] == "path"


@pytest.mark.asyncio
async def test_plan_run_partial_success_still_fails():
    """ExtractorPlan.run: fails if any extractor fails, even if others succeed"""

    def handler(_id: Path[int], page: Query[int]):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(path_params={"_id": "10"}, query_string=b"")

    with pytest.raises(ValidationError) as exc_info:
        await plan.run(request)

    errors = exc_info.value.errors
    assert len(errors) == 1
    assert errors[0]["field"] == "page"


@pytest.mark.asyncio
async def test_plan_run_type_coercion_error():
    """ExtractorPlan.run: captures type coercion errors"""

    def handler(_id: Path[int]):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(path_params={"_id": "not-a-number"})

    with pytest.raises(ValidationError) as exc_info:
        await plan.run(request)

    error = exc_info.value.errors[0]
    assert error["field"] == "_id"
    assert "invalid" in error["message"].lower()


@pytest.mark.asyncio
async def test_plan_run_empty_plan():
    """ExtractorPlan.run: runs successfully with no extractors"""

    def handler():
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request()

    kwargs = await plan.run(request)
    assert kwargs == {}


@pytest.mark.asyncio
async def test_plan_run_optional_params():
    """ExtractorPlan.run: handles parameters with default values correctly"""

    def handler(_id: Path[int], filter: Query[str] = "all"):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(path_params={"_id": "5"}, query_string=b"")

    kwargs = await plan.run(request)
    assert kwargs == {"_id": 5, "filter": "all"}


@pytest.mark.asyncio
async def test_plan_run_with_defaults():
    """ExtractorPlan.run: uses default values when params missing"""

    def handler(page: Query[int] = 1, limit: Query[int] = 10):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(query_string=b"")

    kwargs = await plan.run(request)
    assert kwargs == {"page": 1, "limit": 10}


@pytest.mark.asyncio
async def test_plan_run_overrides_defaults():
    """ExtractorPlan.run: overrides defaults when params provided"""

    def handler(page: Query[int] = 1, limit: Query[int] = 10):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(query_string=b"page=5&limit=50")

    kwargs = await plan.run(request)
    assert kwargs == {"page": 5, "limit": 50}


@pytest.mark.asyncio
async def test_real_world_rest_create_endpoint():
    """Real-world: POST /users endpoint with body and auth header"""

    def handler(data: Body[dict], authorization: Header[str]):
        pass

    plan = ExtractorPlan.build(handler)
    body = stdlib_json.dumps({"name": "Alice", "email": "alice@example.com"}).encode()
    request = make_request(
        method="POST",
        headers=[(b"authorization", b"Bearer token123")],
        body=body,
    )

    kwargs = await plan.run(request)
    assert kwargs["data"] == {"name": "Alice", "email": "alice@example.com"}
    assert kwargs["authorization"] == "Bearer token123"


@pytest.mark.asyncio
async def test_real_world_rest_get_endpoint():
    """Real-world: GET /users/{_id} endpoint with path and query params"""

    def handler(_id: Path[int], include_posts: Query[bool] = False):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(
        path_params={"_id": "42"},
        query_string=b"include_posts=true",
    )

    kwargs = await plan.run(request)
    assert kwargs == {"_id": 42, "include_posts": True}


@pytest.mark.asyncio
async def test_real_world_search_endpoint():
    """Real-world: GET /search with multiple query params"""

    def handler(
        q: Query[str],
        page: Query[int] = 1,
        limit: Query[int] = 20,
        sort: Query[Optional[str]] = None,
    ):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(query_string=b"q=python&page=2&limit=50")

    kwargs = await plan.run(request)
    assert kwargs == {"q": "python", "page": 2, "limit": 50, "sort": None}


@pytest.mark.asyncio
async def test_real_world_update_endpoint():
    """Real-world: PATCH /users/{_id} with path, body, and header"""

    def handler(_id: Path[UUID], data: Body[dict], authorization: Header[str]):
        pass

    plan = ExtractorPlan.build(handler)
    uuid_str = "550e8400-e29b-41d4-a716-446655440000"
    body = stdlib_json.dumps({"name": "Updated Name"}).encode()
    request = make_request(
        method="PATCH",
        path_params={"_id": uuid_str},
        headers=[(b"authorization", b"Bearer token")],
        body=body,
    )

    kwargs = await plan.run(request)
    assert isinstance(kwargs["_id"], UUID)
    assert str(kwargs["_id"]) == uuid_str
    assert kwargs["data"] == {"name": "Updated Name"}
    assert kwargs["authorization"] == "Bearer token"


@pytest.mark.asyncio
async def test_real_world_filter_with_enums():
    """Real-world: GET /items with enum query params"""

    def handler(status: Query[Status], priority: Query[str] = "MEDIUM"):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(query_string=b"status=active&priority=HIGH")

    kwargs = await plan.run(request)
    assert kwargs["status"] == Status.ACTIVE
    assert kwargs["priority"] == "HIGH"


@pytest.mark.asyncio
async def test_real_world_date_filtering():
    """Real-world: GET /posts with datetime query params"""

    def handler(
        created_after: Query[datetime], created_before: Query[Optional[datetime]] = None
    ):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(query_string=b"created_after=2024-01-01T00:00:00")

    kwargs = await plan.run(request)
    assert isinstance(kwargs["created_after"], datetime)
    assert kwargs["created_after"].year == 2024
    assert kwargs["created_before"] is None


@pytest.mark.asyncio
async def test_real_world_validation_with_multiple_errors():
    """Real-world: multiple validation errors collected together"""

    def handler(
        _id: Path[int],
        status: Query[Status],
        authorization: Header[str],
        data: Body[dict],
    ):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request()

    with pytest.raises(ValidationError) as exc_info:
        await plan.run(request)

    errors = exc_info.value.errors
    assert len(errors) == 4
    fields = {e["field"] for e in errors}
    assert fields == {"_id", "status", "authorization", "data"}


@pytest.mark.asyncio
async def test_real_world_custom_header_names():
    """Real-world: custom header names with Header() marker"""

    def handler(
        request_id: Header[str] = Header("X-Request-ID"),
        api_key: Header[str] = Header("X-API-Key"),
    ):
        pass

    plan = ExtractorPlan.build(handler)
    request = make_request(
        headers=[
            (b"x-request-id", b"req-123"),
            (b"x-api-key", b"secret-key"),
        ]
    )

    kwargs = await plan.run(request)
    assert kwargs == {"request_id": "req-123", "api_key": "secret-key"}


@pytest.mark.asyncio
async def test_real_world_with_dependency_injection():
    """Real-world: handler using dependency injection"""

    class FakeContainer:
        async def resolve(self, target_type):  # noqa
            if target_type == str:
                return "injected-database-connection"
            return None

    def handler(_id: Path[int], db_url: Inject[str]):
        pass

    container = FakeContainer()
    plan = ExtractorPlan.build(handler, container=container)
    request = make_request(path_params={"_id": "10"})

    kwargs = await plan.run(request)
    assert kwargs["_id"] == 10
    assert kwargs["db_url"] == "injected-database-connection"
