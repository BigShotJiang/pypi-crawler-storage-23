import pytest
from meridian import Meridian, Query, ValidationConfig
from meridian.testing import AsyncTestClient


@pytest.mark.asyncio
async def test_ignore_unknown_query_params_true():
    """When ignore_unknown_query_params=True, unknown params are silently ignored"""
    app = Meridian(validation=ValidationConfig(ignore_unknown_query_params=True))

    @app.get("/search")
    async def search(q: Query[str]) -> dict:
        return {"query": q}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/search?q=test&unknown=value")
        if resp.status_code != 200:
            print(f"Status: {resp.status_code}")
            print(f"Body: {resp.text()}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["query"] == "test"


@pytest.mark.asyncio
async def test_ignore_unknown_query_params_false():
    """When ignore_unknown_query_params=False, unknown params cause validation error"""
    app = Meridian(validation=ValidationConfig(ignore_unknown_query_params=False))

    @app.get("/search")
    async def search(q: Query[str]) -> dict:
        return {"query": q}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/search?q=test&unknown=value")
        assert resp.status_code == 422
        data = resp.json()
        assert "errors" in data
        assert any(e["field"] == "unknown" for e in data["errors"])
        assert any("Unknown query parameter" in e["message"] for e in data["errors"])


@pytest.mark.asyncio
async def test_ignore_unknown_query_params_multiple_unknown():
    """Multiple unknown query params are all reported"""
    app = Meridian(validation=ValidationConfig(ignore_unknown_query_params=False))

    @app.get("/search")
    async def search(q: Query[str]) -> dict:
        return {"query": q}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/search?q=test&foo=1&bar=2&baz=3")
        assert resp.status_code == 422
        data = resp.json()
        assert "errors" in data

        unknown_fields = {e["field"] for e in data["errors"]}
        assert "foo" in unknown_fields
        assert "bar" in unknown_fields
        assert "baz" in unknown_fields


@pytest.mark.asyncio
async def test_ignore_unknown_query_params_all_params_known():
    """When all query params are known, no validation error"""
    app = Meridian(validation=ValidationConfig(ignore_unknown_query_params=False))

    @app.get("/search")
    async def search(
        q: Query[str], limit: Query[int] = 10, sort: Query[str] = "asc"
    ) -> dict:
        return {"query": q, "limit": limit, "sort": sort}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/search?q=test&limit=20&sort=desc")
        assert resp.status_code == 200
        data = resp.json()
        assert data["query"] == "test"
        assert data["limit"] == 20
        assert data["sort"] == "desc"


@pytest.mark.asyncio
async def test_ignore_unknown_query_params_no_query_params():
    """Handler with no query params doesn't trigger validation"""
    app = Meridian(validation=ValidationConfig(ignore_unknown_query_params=False))

    @app.get("/hello")
    async def hello() -> dict:
        return {"message": "hello"}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/hello?foo=bar")
        assert resp.status_code == 200


@pytest.mark.asyncio
async def test_validation_mode_strict_with_pydantic():
    """Validation mode 'strict' validates Pydantic models"""
    try:
        from pydantic import BaseModel

        class User(BaseModel):
            name: str
            age: int

        app = Meridian(validation=ValidationConfig(mode="strict"))

        @app.post("/users")
        async def create_user(user: Query[User]) -> dict:
            return {"name": user.name, "age": user.age}

    except ImportError:
        pytest.skip("Pydantic not installed")


@pytest.mark.asyncio
async def test_ignore_unknown_with_subset_of_params():
    """Sending subset of known params with unknown params is validated correctly"""
    app = Meridian(validation=ValidationConfig(ignore_unknown_query_params=False))

    @app.get("/search")
    async def search(
        q: Query[str],
        limit: Query[int] = 10,
        offset: Query[int] = 0,
    ) -> dict:
        return {"query": q, "limit": limit, "offset": offset}

    async with AsyncTestClient(app) as client:
        resp = await client.get("/search?q=test&limit=5&unknown=value")
        assert resp.status_code == 422
        data = resp.json()
        assert any(e["field"] == "unknown" for e in data["errors"])

        resp = await client.get("/search?q=test&unknown=value")
        assert resp.status_code == 422

        resp = await client.get("/search?q=test&limit=5&offset=10")
        assert resp.status_code == 200
