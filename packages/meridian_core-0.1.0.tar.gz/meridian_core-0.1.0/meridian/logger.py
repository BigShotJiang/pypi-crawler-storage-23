import logging
from typing import Optional, TYPE_CHECKING, Any

if TYPE_CHECKING:
    try:
        from meridian.observability import TraceContextFilter
    except ImportError:
        TraceContextFilter = Any  # type: ignore[misc,assignment]

_filter = None
try:
    from meridian.observability import TraceContextFilter as _TraceContextFilter

    _filter = _TraceContextFilter()
except ImportError:
    _filter = None

_DEFAULT_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"


def get_logger(name: Optional[str] = None) -> logging.Logger:
    logger = logging.getLogger(name)
    if not any(isinstance(h, logging.NullHandler) for h in logger.handlers):
        logger.addHandler(logging.NullHandler())

    if _filter is not None and not any(
        type(f).__name__ == "TraceContextFilter" for f in logger.filters
    ):
        logger.addFilter(_filter)

    return logger


def setup_logging(
    *,
    debug: bool = False,
    app_name: str = "meridian",
    level: Optional[int] = None,
    fmt: str = _DEFAULT_FORMAT,
) -> None:
    """
    Configure root logging for the application.

    Parameters
    ----------
    debug : bool
        When True, sets log level to DEBUG unless `level` is provided.
    app_name : str
        Prefix for the root logger name.
    level : int | None
        Optional explicit log level. Overrides debug.
    fmt : str
        Logging format string.
    """
    root = logging.getLogger()
    effective_level = (
        level if level is not None else (logging.DEBUG if debug else logging.INFO)
    )

    if not root.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(fmt))
        root.addHandler(handler)

    root.setLevel(effective_level)
    logging.getLogger(app_name).setLevel(effective_level)
