import json as _json
from typing import Any, AsyncIterator

from .types import Send


class Response:
    """
    Base HTTP response. Handlers return this (or a subclass).
    """

    def __init__(
        self,
        body: bytes | str = b"",
        status_code: int = 200,
        headers: dict[str, str] | None = None,
        media_type: str = "application/octet-stream",
    ) -> None:
        if isinstance(body, str):
            body = body.encode()
        self.body = body
        self.status_code = status_code
        self.media_type = media_type
        self._headers = headers or {}

    def raw_headers(self) -> list[tuple[bytes, bytes]]:
        headers = {
            "content-length": str(len(self.body)),
            "content-type": self.media_type,
            **{k.lower(): v for k, v in self._headers.items()},
        }
        return [(k.encode(), v.encode()) for k, v in headers.items()]

    async def send(self, send: Send) -> None:
        await send(
            {
                "type": "http.response.start",
                "status": self.status_code,
                "headers": self.raw_headers(),
            }
        )
        await send(
            {
                "type": "http.response.body",
                "body": self.body,
                "more_body": False,
            }
        )


class JSONResponse(Response):
    """JSON-serialised response. Default for most API handlers."""

    def __init__(
        self,
        content: Any,
        status_code: int = 200,
        headers: dict[str, str] | None = None,
    ) -> None:
        body = _json.dumps(content, default=str).encode()
        super().__init__(
            body=body,
            status_code=status_code,
            headers=headers,
            media_type="application/json",
        )


class ORJSONResponse(Response):
    """ORJSON-serialised response. Faster than JSONResponse, but less flexible."""

    def __init__(
        self,
        content: Any,
        status_code: int = 200,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.ensure_orjson_installed()

        body = _json.dumps(content, default=str).encode()
        super().__init__(
            body=body,
            status_code=status_code,
            headers=headers,
            media_type="application/json",
        )

    @staticmethod
    def ensure_orjson_installed():
        try:
            import orjson  # noqa: F401
        except ImportError:
            raise ImportError(
                "ORJSONResponse requires the 'orjson' package. "
                "Install with 'pip install orjson' or 'uv add orjson'."
            ) from None


class ErrorResponse(JSONResponse):
    """
    Used by the Gateway's exception handlers.
    Wraps MeridianError.to_dict() as a JSON response.
    """

    def __init__(
        self,
        detail: dict[str, Any],
        status_code: int,
        headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(content=detail, status_code=status_code, headers=headers)


class StreamingResponse(Response):
    """
    Streams an async iterator of bytes to the client.

    The body is not buffered — content is sent as it is yielded.
    Used by BodyStream handlers and agent tool streaming responses.
    """

    def __init__(
        self,
        content: AsyncIterator[bytes],
        status_code: int = 200,
        headers: dict[str, str] | None = None,
        media_type: str = "application/octet-stream",
    ) -> None:
        super().__init__(
            body=b"",
            status_code=status_code,
            headers=headers,
            media_type=media_type,
        )
        self._content = content
        self.status_code = status_code
        self.media_type = media_type
        self._headers = headers or {}

    @property
    def body(self) -> bytes:
        return b""

    def raw_headers(self) -> list[tuple[bytes, bytes]]:
        headers = {
            "content-type": self.media_type,
            "transfer-encoding": "chunked",
            **{k.lower(): v for k, v in self._headers.items()},
        }
        return [(k.encode(), v.encode()) for k, v in headers.items()]

    async def send(self, send: Send) -> None:
        await send(
            {
                "type": "http.response.start",
                "status": self.status_code,
                "headers": self.raw_headers(),
            }
        )
        async for chunk in self._content:
            await send(
                {
                    "type": "http.response.body",
                    "body": chunk,
                    "more_body": True,
                }
            )
        await send(
            {
                "type": "http.response.body",
                "body": b"",
                "more_body": False,
            }
        )
