from dataclasses import dataclass, field
from typing import Callable, Awaitable
from .response import Response
from .types import RequestContext


@dataclass(frozen=True)
class OperationalConfig:
    max_concurrent_requests: int = 1000
    request_deadline_ms: int | None = 5000
    max_body_size: int = 1_048_576
    drain_timeout_s: int = 30
    request_id_header: str | None = "X-Request-ID"


@dataclass(frozen=True)
class ValidationConfig:
    mode: str = "strict"
    ignore_unknown_query_params: bool = True
    validate_responses: bool = True


@dataclass(frozen=True)
class LifeCycleHooks:
    on_startup: list[Callable[[], Awaitable[None]]] = field(default_factory=list)
    on_shutdown: list[Callable[[], Awaitable[None]]] = field(default_factory=list)
    on_request_start: list[Callable[[RequestContext], Awaitable[None]]] = field(
        default_factory=list
    )
    on_request_end: list[Callable[[RequestContext, Response], Awaitable[None]]] = field(
        default_factory=list
    )
    on_request_error: list[Callable[[RequestContext, Exception], Awaitable[None]]] = (
        field(default_factory=list)
    )
