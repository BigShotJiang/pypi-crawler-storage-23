from __future__ import annotations
import asyncio
import json
from typing import Any
from urllib.parse import urlencode


class TestResponse:
    def __init__(
        self,
        status_code: int,
        headers: dict[str, str],
        body: bytes,
    ) -> None:
        self.status_code = status_code
        self.headers = headers
        self.body = body

    def json(self) -> Any:
        return json.loads(self.body)

    def text(self) -> str:
        return self.body.decode()

    def __repr__(self) -> str:
        return f"<TestResponse {self.status_code}>"


class AsyncTestClient:
    """
    Drives an ASGI application directly — no network, no server.

    Constructs raw ASGI scope + receive/send callables and calls
    app(scope, receive, send) directly.
    """

    def __init__(self, app: Any) -> None:
        self._app = app
        self._lifespan_task: asyncio.Task | None = None
        self._lifespan_started_event: asyncio.Event | None = None
        self._lifespan_shutdown_event: asyncio.Event | None = None
        self._lifespan_error: BaseException | None = None

    async def __aenter__(self) -> "AsyncTestClient":
        await self._lifespan_startup()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self._lifespan_shutdown()  # noqa

    async def request(
        self,
        method: str,
        path: str,
        *,
        headers: dict[str, str] | None = None,
        body: bytes | str | dict | None = None,
        params: dict[str, str] | None = None,
    ) -> TestResponse:
        """Send a request to the app and return the response."""

        if isinstance(body, dict):
            body = json.dumps(body).encode()
            if headers is None:
                headers = {}
            headers.setdefault("content-type", "application/json")
        elif isinstance(body, str):
            body = body.encode()

        body_bytes: bytes = body or b""

        if "?" in path:
            path, query_part = path.split("?", 1)
            query_string = query_part.encode()
        else:
            query_string = b""

        if params:
            param_str = urlencode(params)
            if query_string:
                query_string += b"&" + param_str.encode()
            else:
                query_string = param_str.encode()

        raw_headers: list[tuple[bytes, bytes]] = [
            (k.lower().encode(), v.encode()) for k, v in (headers or {}).items()
        ]
        if body_bytes:
            raw_headers.append((b"content-length", str(len(body_bytes)).encode()))

        scope: dict[str, Any] = {
            "type": "http",
            "asgi": {"version": "3.0"},
            "http_version": "1.1",
            "method": method.upper(),
            "path": path,
            "query_string": query_string,
            "headers": raw_headers,
        }

        body_sent = False

        async def receive() -> dict[str, Any]:
            nonlocal body_sent
            if not body_sent:
                body_sent = True
                return {"type": "http.request", "body": body_bytes, "more_body": False}
            await asyncio.sleep(999999)
            return {"type": "http.disconnect"}

        response_started: dict[str, Any] = {}
        response_body = bytearray()

        async def send_fn(message: dict[str, Any]) -> None:
            if message["type"] == "http.response.start":
                response_started["status"] = message["status"]
                response_started["headers"] = {
                    k.decode(): v.decode() for k, v in message.get("headers", [])
                }
            elif message["type"] == "http.response.body":
                response_body.extend(message.get("body", b""))

        await self._app(scope, receive, send_fn)

        return TestResponse(
            status_code=response_started.get("status", 500),
            headers=response_started.get("headers", {}),
            body=bytes(response_body),
        )

    async def get(self, path: str, **kwargs: Any) -> TestResponse:
        return await self.request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> TestResponse:
        return await self.request("POST", path, **kwargs)

    async def put(self, path: str, **kwargs: Any) -> TestResponse:
        return await self.request("PUT", path, **kwargs)

    async def delete(self, path: str, **kwargs: Any) -> TestResponse:
        return await self.request("DELETE", path, **kwargs)

    async def patch(self, path: str, **kwargs: Any) -> TestResponse:
        return await self.request("PATCH", path, **kwargs)

    async def _lifespan_startup(self) -> None:
        scope = {"type": "lifespan", "asgi": {"version": "3.0"}}
        started = asyncio.Event()
        shutdown = asyncio.Event()

        async def receive() -> dict[str, Any]:
            if not started.is_set():
                return {"type": "lifespan.startup"}
            await shutdown.wait()
            return {"type": "lifespan.shutdown"}

        async def send_fn(message: dict[str, Any]) -> None:
            msg_type = message.get("type")
            if msg_type == "lifespan.startup.complete":
                started.set()
            elif msg_type == "lifespan.startup.failed":
                self._lifespan_error = RuntimeError(
                    message.get("message", "Lifespan startup failed")
                )
                started.set()
            elif msg_type == "lifespan.shutdown.complete":
                shutdown.set()
            elif msg_type == "lifespan.shutdown.failed":
                self._lifespan_error = RuntimeError(
                    message.get("message", "Lifespan shutdown failed")
                )
                shutdown.set()

        self._lifespan_started_event = started
        self._lifespan_shutdown_event = shutdown
        self._lifespan_task = asyncio.create_task(self._app(scope, receive, send_fn))

        await started.wait()
        if self._lifespan_error is not None:
            raise self._lifespan_error

    async def _lifespan_shutdown(self) -> None:
        if self._lifespan_task is None or self._lifespan_shutdown_event is None:
            return

        self._lifespan_shutdown_event.set()
        try:
            await self._lifespan_task
        finally:
            self._lifespan_task = None
            self._lifespan_started_event = None
            self._lifespan_shutdown_event = None
