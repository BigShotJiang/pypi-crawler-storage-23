def check_observability_plugin_installed():
    try:
        from meridian.observability import ObservabilityConfig, install
    except ImportError:
        raise ImportError(
            "meridian-observability is not installed. "
            "Run: pip install meridian-observability or uv add meridian-observability"
        ) from None
