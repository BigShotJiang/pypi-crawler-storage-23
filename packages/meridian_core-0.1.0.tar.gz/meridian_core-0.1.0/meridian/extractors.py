import inspect
import json
import types
from datetime import datetime
from enum import Enum
from typing import Any, Annotated, TypeVar, get_args, get_origin, get_type_hints
from uuid import UUID

from .config import ValidationConfig
from .exceptions import ValidationError, ConfigurationError
from .request import Request

try:
    from pydantic import TypeAdapter
except ImportError:
    TypeAdapter = None

T = TypeVar("T")


class _ExtractorMarker:
    """
    Base for all extractor markers. Not instantiated directly.

    Uses Annotated[T, Marker] so type checkers see T while runtime can
    still detect the marker via get_origin/get_args.
    """

    _source: str = "unknown"

    def __class_getitem__(cls, item: type[T]) -> Any:
        return Annotated[item, cls]


class Path(_ExtractorMarker):
    """Extract from URL path parameters. e.g. /users/{id} → Path[int]"""

    _source = "path"


class Query(_ExtractorMarker):
    """Extract from query string. e.g. ?page=2 → Query[int]"""

    _source = "query"


class Body(_ExtractorMarker):
    """Extract and validate the request body. Body[UserCreate]"""

    _source = "body"


class Header(_ExtractorMarker):
    """Extract from request headers. Header[str] → Authorization header."""

    _source = "header"

    def __init__(self, name: str | None = None):
        self.name = name


class Cookie(_ExtractorMarker):
    """Extract from request cookies. Cookie[str] → session_id."""

    _source = "cookie"

    def __init__(self, name: str | None = None):
        self.name = name


class Inject(_ExtractorMarker):
    """
    Resolve from the DI container.
    Raises ConfigurationError at registration time if no container attached.
    """

    _source = "inject"


_COERCE: dict[type, Any] = {
    int: int,
    float: float,
    bool: lambda v: v.lower() not in ("false", "0", "no", ""),
    str: str,
}


# Pre-calculate common coercers to avoid issubclass checks at request time
_SPECIAL_COERCERS: dict[type, Any] = {
    UUID: UUID,
    datetime: lambda v: datetime.fromisoformat(v.replace("Z", "+00:00")),
}


def _coerce(value: str | None, target_type: type) -> Any:
    """Coerce raw strings to complex Python types."""
    if value is None:
        return None

    # 1. Check direct map (int, str, float, etc)
    coercer = _COERCE.get(target_type)
    if coercer:
        return coercer(value)

    # 2. Check special map (UUID, datetime)
    special = _SPECIAL_COERCERS.get(target_type)
    if special:
        return special(value)

    # 3. Check Enum (most frequent dynamic check)
    if isinstance(target_type, type) and issubclass(target_type, Enum):
        try:
            return target_type(value)
        except ValueError:
            return target_type[value]

    # 4. Fallback
    return target_type(value)


def _is_optional(annotation: Any) -> bool:
    """
    Returns True if the annotation allows None.
    Handles Optional[T], Union[T, None], T | None, and Annotated[...] wrappers.
    """
    annotation = _unwrap_annotated(annotation)[0]
    origin = get_origin(annotation)

    from typing import Union

    if origin is Union or (hasattr(types, "UnionType") and origin is types.UnionType):
        return type(None) in get_args(annotation)

    return False


def _unwrap_annotated(annotation: Any) -> tuple[Any, Any | None]:
    """
    If annotation is Annotated[T, Marker], return (T, Marker).
    Otherwise, return (annotation, None).
    """
    origin = get_origin(annotation)
    if origin is Annotated:
        args = get_args(annotation)
        if args:
            inner = args[0]
            for meta in args[1:]:
                if isinstance(meta, _ExtractorMarker) or (
                    isinstance(meta, type) and issubclass(meta, _ExtractorMarker)
                ):
                    return inner, meta
            return inner, None
    return annotation, None


class _PathExtractor:
    def __init__(self, param_name: str, target_type: type, is_optional: bool) -> None:
        self.param_name = param_name
        self.target_type = target_type
        self.is_optional = is_optional

    async def extract(self, request: Request) -> Any:
        raw = request.path_params.get(self.param_name)

        if raw is None:
            if self.is_optional:
                return None
            raise ValueError(f"Path parameter '{self.param_name}' not found")

        return _coerce(raw, self.target_type)

    def verify(self, handler_name: str, route_pattern: str, container: Any) -> None:
        marker = f"{{{self.param_name}}}"
        if marker not in route_pattern and not route_pattern.endswith(
            f"{{{self.param_name}:rest}}"
        ):
            raise ConfigurationError(
                f"Handler '{handler_name}': Path parameter '{self.param_name}' "
                f"is not defined in route pattern '{route_pattern}'."
            )


class _QueryExtractor:
    def __init__(
        self,
        param_name: str,
        target_type: type,
        default: Any,
        is_optional: bool,
        ignore_unknown: bool = True,
    ) -> None:
        self.param_name = param_name
        self.target_type = target_type
        self.default = default
        self.is_optional = is_optional
        self.ignore_unknown = ignore_unknown

    async def extract(self, request: Request) -> Any:
        raw = request.query_params.get(self.param_name)

        if raw is None:
            if self.default is not inspect.Parameter.empty:
                return self.default

            if self.is_optional:
                return None

            raise ValueError(f"Required query parameter '{self.param_name}' missing")

        return _coerce(raw, self.target_type)

    def verify(self, handler_name: str, route_pattern: str, container: Any) -> None:
        pass


class _BodyExtractor:
    def __init__(
        self, target_type: type, is_optional: bool, validation_mode: str = "strict"
    ) -> None:
        self.target_type = target_type
        self.is_optional = is_optional
        self.validation_mode = validation_mode
        self._adapter: Any | None = None

        if validation_mode == "strict" and TypeAdapter:
            try:
                self._adapter = TypeAdapter(target_type)
            except Exception:  # noqa
                # Fallback to model_validate if TypeAdapter fails (e.g. for some complex unions)
                pass

    async def extract(self, request: Request) -> Any:
        raw_bytes = await request.body()
        if not raw_bytes:
            if self.is_optional:
                return None
            raise ValueError("Request body is empty")

        try:
            data = json.loads(raw_bytes)
            if data is None and self.is_optional:
                return None
        except json.JSONDecodeError as e:
            if self.is_optional and raw_bytes.strip() in (b"", b"null"):
                return None
            raise ValueError(f"Invalid JSON body: {e}") from e

        if self.validation_mode == "strict":
            if self._adapter:
                return self._adapter.validate_python(data)

            if hasattr(self.target_type, "model_validate"):
                return self.target_type.model_validate(data)

        return data

    def verify(self, handler_name: str, route_pattern: str, container: Any) -> None:
        pass


class _HeaderExtractor:
    def __init__(
        self, header_name: str, target_type: type, default: Any, is_optional: bool
    ) -> None:
        self.header_name = header_name
        self.target_type = target_type
        self.default = default
        self.is_optional = is_optional

    async def extract(self, request: Request) -> Any:
        raw = request.headers.get(self.header_name)

        if raw is None:
            if self.default is not inspect.Parameter.empty and not isinstance(
                self.default, Header
            ):
                return self.default
            if self.is_optional:
                return None
            raise ValueError(f"Required header '{self.header_name}' missing")

        return _coerce(raw, self.target_type)

    def verify(self, handler_name: str, route_pattern: str, container: Any) -> None:
        pass


class _CookieExtractor:
    def __init__(
        self, cookie_name: str, target_type: type, default: Any, is_optional: bool
    ) -> None:
        self.cookie_name = cookie_name
        self.target_type = target_type
        self.default = default
        self.is_optional = is_optional

    async def extract(self, request: Request) -> Any:
        raw = request.cookies.get(self.cookie_name)

        if raw is None:
            if self.default is not inspect.Parameter.empty and not isinstance(
                self.default, Cookie
            ):
                return self.default
            if self.is_optional:
                return None
            raise ValueError(f"Required cookie '{self.cookie_name}' missing")

        return _coerce(raw, self.target_type)

    def verify(self, handler_name: str, route_pattern: str, container: Any) -> None:
        pass


class _InjectExtractor:
    """
    Resolved at request time from the DI container's REQUEST scope.

    Raises InjectionError (500) on failure — never ValidationError (422).
    This is a framework/config error, not a user input error.
    """

    def __init__(self, target_type: type, container: Any) -> None:
        self.target_type = target_type
        self.container = container

    async def extract(self, request: Request) -> Any:
        from .context import get_request_context
        from .di.exceptions import InjectionError

        try:
            ctx = get_request_context()
            scope = ctx.extras.get("app.scope")
            if scope is not None:
                return await scope.resolve(self.target_type)
        except LookupError:
            pass

        # Fallback for unit tests where context is not set up
        if hasattr(self.container, "resolve"):
            return await self.container.resolve(self.target_type)

        raise InjectionError(
            f"Cannot resolve {self.target_type.__name__}: "
            f"no request context available and no resolvable container."
        )

    def verify(self, handler_name: str, route_pattern: str, container: Any) -> None:
        if container is None:
            return

        if self.target_type not in container._bindings:
            raise ConfigurationError(
                f"Handler '{handler_name}': Inject[{self.target_type.__name__}] "
                f"has no registered binding in the DI container."
            )


class ExtractorPlan:
    """
    Pre-built extraction plan for a single handler function.

    Built ONCE at route registration via ExtractorPlan.build(handler).
    Executed MANY times via plan.run(request) — one per request.

    Stores an ordered list of (param_name, extractor) pairs
    mirroring the handler's parameter order.
    """

    def __init__(
        self,
        steps: list[tuple[str, Any]],
        query_param_names: set[str],
        ignore_unknown_query_params: bool,
    ) -> None:
        self._steps = steps
        self._query_param_names = query_param_names
        self._ignore_unknown_query_params = ignore_unknown_query_params

    @classmethod
    def build(
        cls,
        handler: Any,
        container: Any | None = None,
        validation: ValidationConfig | None = None,
    ) -> "ExtractorPlan":
        """
        Inspect handler signature and build the plan.

        Raises ConfigurationError immediately if:
          - Inject[T] is used but no container is attached.
          - A parameter has no type annotation (we can't extract it).
          - An unrecognised annotation is used.

        Called at @app.get() / @app.post() decoration time.
        :param validation: Validation configuration (mode, ignore_unknown_query_params)
        :param handler: The route handler function to build the plan for.
        :param container: The DI container, if any, for resolving Inject[T] parameters.
        """
        if validation is None:
            validation = ValidationConfig()

        sig = inspect.signature(handler)
        try:
            hints = get_type_hints(handler, include_extras=True)
        except Exception:  # noqa
            hints = getattr(handler, "__annotations__", {})

        validation_mode = validation.mode
        ignore_unknown_query_params = validation.ignore_unknown_query_params
        steps: list[tuple[str, Any]] = []
        query_param_names: set[str] = set()

        for param_name, param in sig.parameters.items():
            annotation = hints.get(param_name, param.annotation)
            default = param.default

            if annotation is inspect.Parameter.empty:
                raise ConfigurationError(
                    f"Handler '{handler.__name__}': parameter '{param_name}' "
                    f"has no type annotation. All handler parameters must be "
                    f"annotated with Path[T], Query[T], Body[T], Header[T], "
                    f"or Inject[T]."
                )

            annotation, marker = _unwrap_annotated(annotation)
            origin = marker if marker is not None else get_origin(annotation)
            original = hints.get(param_name, param.annotation)
            args = get_args(original) if marker is not None else get_args(annotation)

            if origin is None:
                raise ConfigurationError(
                    f"Handler '{handler.__name__}': parameter '{param_name}' "
                    f"has annotation '{annotation}' which is not a recognised "
                    f"extractor type. Use Path[T], Query[T], Body[T], "
                    f"Header[T], or Inject[T]."
                )

            is_nullable = _is_optional(annotation)
            if is_nullable:
                actual_args = [a for a in args if a is not type(None)]
                inner_type = actual_args[0] if actual_args else Any
            else:
                inner_type = args[0] if args else annotation

            if issubclass(origin, Path):  # noqa
                extractor = _PathExtractor(
                    param_name=param_name,
                    target_type=inner_type,
                    is_optional=is_nullable,
                )

            elif issubclass(origin, Query):  # noqa
                query_param_names.add(param_name)
                extractor = _QueryExtractor(
                    param_name=param_name,
                    target_type=inner_type,
                    default=default,
                    is_optional=is_nullable,
                    ignore_unknown=ignore_unknown_query_params,
                )

            elif issubclass(origin, Body):  # noqa
                extractor = _BodyExtractor(
                    target_type=inner_type,
                    is_optional=is_nullable,
                    validation_mode=validation_mode,
                )

            elif issubclass(origin, Header):  # noqa
                header_name = param_name
                if isinstance(default, Header) and default.name:
                    header_name = default.name

                header_name = header_name.replace("_", "-").title()
                extractor = _HeaderExtractor(
                    header_name=header_name,
                    target_type=inner_type,
                    default=default,
                    is_optional=is_nullable,
                )

            elif issubclass(origin, Cookie):  # noqa
                cookie_name = param_name
                if isinstance(default, Cookie) and default.name:
                    cookie_name = default.name

                cookie_name = cookie_name.replace("_", "-").title()
                extractor = _CookieExtractor(
                    cookie_name=cookie_name,
                    target_type=inner_type,
                    default=default,
                    is_optional=is_nullable,
                )

            elif issubclass(origin, Inject):  # noqa
                if container is None:
                    raise ConfigurationError(
                        f"Handler '{handler.__name__}': parameter '{param_name}' "
                        f"uses Inject[{inner_type.__name__}] but no DI container "
                        f"is attached to this application. "
                        f"Call app.with_di(container) before registering routes "
                        f"that use Inject[T]."
                    )
                extractor = _InjectExtractor(inner_type, container)

            else:
                raise ConfigurationError(
                    f"Handler '{handler.__name__}': parameter '{param_name}' "
                    f"has unrecognised extractor type '{origin.__name__}'."
                )

            steps.append((param_name, extractor))

        return cls(steps, query_param_names, ignore_unknown_query_params)

    def verify(self, handler_name: str, route_pattern: str, container: Any) -> None:
        """
        Verify that all extraction steps are valid for this route and container.
        Called at startup.
        """
        for param_name, extractor in self._steps:
            if hasattr(extractor, "verify"):
                extractor.verify(handler_name, route_pattern, container)

    async def run(self, request: Request) -> dict[str, Any]:
        """
        Execute all extractors against the request.

        Collects ALL errors before raising — never fail-fast.
        Returns a dict of {param_name: typed_value} on success.
        Raises ValidationError with all failures on error.

        If ignore_unknown_query_params is False, also validates that all
        query parameters in the request are declared in the handler signature.
        """
        kwargs: dict[str, Any] = {}
        errors: list[dict[str, Any]] = []

        if not self._ignore_unknown_query_params and self._query_param_names:
            actual_query_params = set(request.query_params.keys())
            unknown_params = actual_query_params - self._query_param_names

            if unknown_params:
                for param in sorted(unknown_params):
                    errors.append(
                        {
                            "field": param,
                            "source": "query",
                            "message": f"Unknown query parameter '{param}'. Allowed parameters: {', '.join(sorted(self._query_param_names))}",
                        }
                    )

        for param_name, extractor in self._steps:
            try:
                kwargs[param_name] = await extractor.extract(request)
            except (ValueError, TypeError) as e:
                errors.append(
                    {
                        "field": param_name,
                        "source": extractor.__class__.__name__.lstrip("_")
                        .replace("Extractor", "")
                        .lower(),
                        "message": str(e),
                    }
                )

        if errors:
            raise ValidationError(errors=errors)

        return kwargs
