"""
Radix tree router.

Design decisions (from architecture discussion):
  - Path-only matching. Method dispatch happens within the matched node.
  - Static segments beat parameterised segments at the same level.
  - /users/me resolves before /users/{id} regardless of registration order.
  - 404 vs 405: if the path matches but method doesn't → MethodNotAllowed.
  - Route pattern /users/{id} → path_params["id"] = "42"
  - Wildcard: /files/{path:rest} → captures everything after /files/
  - Regex constraints: /users/{id:[0-9]+} → matches only digits
  - Conflict detection: /users/{id} and /users/{name} at same level raises error
"""

from dataclasses import dataclass, field
from typing import Any, Callable
import re

from .exceptions import MethodNotAllowed, NotFound, ConfigurationError

RawHandler = Callable[..., Any]


@dataclass
class Route:
    """A single registered route with its extractor plan and response validator."""

    pattern: str
    handler: RawHandler
    extractor_plan: Any = None
    response_validator: Any = None
    name: str | None = None
    constraints: dict[str, str] = field(default_factory=dict)


@dataclass
class _Node:
    """A node in the radix trie."""

    static: dict[str, "_Node"] = field(default_factory=dict)
    param: tuple[str, "_Node"] | None = None
    param_constraint: Any = None
    wildcard: tuple[str, "_Node"] | None = None
    methods: dict[str, Route] = field(default_factory=dict)


def _segments(path: str) -> list[str]:
    """Split a path into non-empty segments."""
    return [s for s in path.split("/") if s]


def _is_param(segment: str) -> bool:
    return segment.startswith("{") and segment.endswith("}")


def _is_wildcard(segment: str) -> bool:
    return segment.startswith("{") and ":rest}" in segment


def _param_name(segment: str) -> str:
    """Extract parameter name from '{id}' or '{path:rest}' or '{id:[0-9]+}'."""
    inner = segment[1:-1]
    return inner.split(":")[0]


def _param_constraint(segment: str) -> str | None:
    """Extract regex constraint from '{id:[0-9]+}' or None if no constraint."""
    if not _is_param(segment) or _is_wildcard(segment):
        return None
    inner = segment[1:-1]
    parts = inner.split(":", 1)
    if len(parts) > 1 and parts[1] != "rest":
        return parts[1]
    return None


def _validate_regex_pattern(pattern: str) -> None:
    """Validate that a regex pattern is well-formed. Raises ValueError if invalid."""
    try:
        re.compile(pattern)
    except re.error as e:
        raise ValueError(f"Invalid regex pattern '{pattern}': {e}")


class Router:
    """
    Radix tree router. Path-only. Method dispatch within matched nodes.

    Usage:
        router = Router()
        router.add("GET",  "/users/{id}", get_user_handler)
        router.add("POST", "/users",      create_user_handler)

        match = router.match("GET", "/users/42")
        match.route.handler, match.path_params == {"id": "42"}
    """

    def __init__(self) -> None:
        self._root = _Node()

    def add(
        self,
        method: str,
        path: str,
        handler: RawHandler,
        name: str | None = None,
    ) -> Route:
        """
        Register a route. Returns the Route object so the caller
        can attach an ExtractorPlan to it later.

        Raises ConfigurationError if:
          - Route is already registered (same method and path)
          - Conflicting parameter names at same level (e.g., {id} vs {name})
        """
        method = method.upper()
        route = Route(pattern=path, handler=handler, name=name)
        node = self._root

        for segment in _segments(path):
            if _is_wildcard(segment):
                param_name = _param_name(segment)
                if node.wildcard is None:
                    node.wildcard = (param_name, _Node())
                node = node.wildcard[1]

            elif _is_param(segment):
                param_name = _param_name(segment)
                constraint = _param_constraint(segment)

                if constraint:
                    _validate_regex_pattern(constraint)
                    route.constraints[param_name] = constraint
                    compiled_constraint = re.compile(f"^{constraint}$")
                else:
                    compiled_constraint = None

                if node.param is None:
                    node.param = (param_name, _Node())
                    node.param_constraint = compiled_constraint
                else:
                    if node.param[0] != param_name:
                        raise ConfigurationError(
                            f"Conflicting parameter names at same level: {node.param[0]} vs {param_name}"
                        )
                    # For performance, we store the compiled constraint on the node
                    # during registration.
                    exist_pattern = (
                        node.param_constraint.pattern[1:-1]
                        if node.param_constraint
                        else None
                    )
                    if constraint != exist_pattern:
                        raise ConfigurationError(
                            f"Conflicting regex constraints for param '{param_name}': "
                            f"{exist_pattern} vs {constraint}"
                        )

                node = node.param[1]

            else:
                if segment not in node.static:
                    node.static[segment] = _Node()
                node = node.static[segment]

        if method in node.methods:
            raise ConfigurationError(f"Route already registered: {method} {path}")
        node.methods[method] = route
        return route

    def match(self, method: str, path: str) -> "Match":
        """
        Match a method + path against the trie.

        Returns a Match with the route and extracted path params.
        Raises NotFound or MethodNotAllowed on failure.
        """
        method = method.upper()
        segments = _segments(path)
        path_params: dict[str, str] = {}

        node = self._walk_iterative(segments, path_params)

        if node is None:
            raise NotFound(f"No route match found.")

        if method not in node.methods:
            raise MethodNotAllowed(allowed=list(node.methods.keys()))

        route = node.methods[method]
        return Match(route=route, path_params=path_params)

    def _walk_iterative(
        self,
        segments: list[str],
        path_params: dict[str, str],
    ) -> "_Node | None":
        """
        Iterative traversal through the trie.
        priority: static > parameterised (with regex match) > wildcard.
        """
        stack: list[tuple["_Node", int, dict[str, str]]] = [(self._root, 0, {})]

        while stack:
            node, idx, current_params = stack.pop()

            if idx == len(segments):
                if node.methods:
                    path_params.update(current_params)
                    return node
                continue

            head = segments[idx]

            if node.wildcard:
                p_name, w_node = node.wildcard
                w_params = current_params.copy()
                w_params[p_name] = "/".join(segments[idx:])
                stack.append((w_node, len(segments), w_params))

            if node.param:
                p_name, p_node = node.param
                matched = True
                if node.param_constraint:
                    if not node.param_constraint.match(head):
                        matched = False

                if matched:
                    p_params = current_params.copy()
                    p_params[p_name] = head
                    stack.append((p_node, idx + 1, p_params))

            if head in node.static:
                stack.append((node.static[head], idx + 1, current_params))

        return None

    def get_all_routes(self) -> list[tuple[str, str, Route]]:
        """
        Return a list of (method, pattern, Route) for all registered routes.
        Used for startup verification.
        """
        routes: list[tuple[str, str, Route]] = []

        def _collect(node: "_Node", current_pattern: str):
            for method, route in node.methods.items():
                routes.append((method, current_pattern, route))

            for segment, child in node.static.items():
                _collect(child, f"{current_pattern}/{segment}")

            if node.param:
                param_name, child = node.param
                constraint = ""
                if node.param_constraint:
                    constraint = f":{node.param_constraint.pattern[1:-1]}"
                _collect(child, f"{current_pattern}/{{{param_name}{constraint}}}")

            if node.wildcard:
                param_name, child = node.wildcard
                _collect(child, f"{current_pattern}/{{{param_name}:rest}}")

        _collect(self._root, "")
        return routes


@dataclass
class Match:
    """Result of a successful router match."""

    route: Route
    path_params: dict[str, str]
