"""
Exception hierarchy for Meridian.

Every exception maps to an HTTP status code and carries a detail
payload that becomes the 4xx/5xx response body.
"""

from typing import Any


class MeridianError(Exception):
    """Base for all framework-level exceptions."""

    status_code: int = 500
    default_detail: str = "Internal server error"

    def __init__(self, detail: str | None = None, **extra: Any) -> None:
        self.detail = detail or self.default_detail
        self.extra = extra
        super().__init__(self.detail)

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"detail": self.detail}
        if self.extra:
            payload.update(self.extra)
        return payload


class NotFound(MeridianError):
    status_code = 404
    default_detail = "Not found"


class MethodNotAllowed(MeridianError):
    status_code = 405
    default_detail = "Method not allowed"

    def __init__(self, allowed: list[str]) -> None:
        super().__init__(detail=self.default_detail)
        self.allowed = allowed


class BadRequest(MeridianError):
    status_code = 400
    default_detail = "Bad request"


class ValidationError(MeridianError):
    """
    Raised when one or more extractors fail.
    Collects ALL failures before raising — never fail-fast.
    """

    status_code = 422
    default_detail = "Validation error"

    def __init__(self, errors: list[dict[str, Any]]) -> None:
        self.errors = errors
        super().__init__(detail="Validation error")

    def to_dict(self) -> dict[str, Any]:
        return {"detail": "Validation error", "errors": self.errors}


class ServiceUnavailable(MeridianError):
    status_code = 503
    default_detail = "Service temporarily unavailable"

    def __init__(self, retry_after: int = 1) -> None:
        super().__init__(detail=self.default_detail, retry_after=retry_after)
        self.retry_after = retry_after


class ConfigurationError(MeridianError):
    """
    Raised at route registration or app startup when the application
    is misconfigured. Always a 500.
    """

    status_code = 500
    default_detail = "Application configuration error"


class ResponseValidationError(Exception):
    """
    Raised when handler response fails validation in strict mode.

    Unlike ValidationError (422), this is a 500 because it indicates
    a server implementation error - the handler returned wrong data.
    Not a MeridianError subclass so it won't be handled as an API error,
    just returned as 500 generic server error.
    """

    def __init__(self, errors: list[dict[str, str]] | None = None):
        self.errors = errors or []
        self.detail = {"detail": "Response validation failed", "errors": self.errors}
        super().__init__(str(self.detail))


class ClientDisconnectError(MeridianError):
    """
    Raised internally when the client disconnects before the response is sent.
    Not intended to be caught by application code.
    """

    status_code = 499
    default_detail = "Client disconnected"
