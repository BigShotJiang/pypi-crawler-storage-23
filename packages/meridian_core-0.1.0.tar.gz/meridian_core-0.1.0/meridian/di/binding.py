from __future__ import annotations
import inspect
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any


class Scope(Enum):
    SINGLETON = auto()
    REQUEST = auto()
    TRANSIENT = auto()


SINGLETON = Scope.SINGLETON
REQUEST = Scope.REQUEST
TRANSIENT = Scope.TRANSIENT


@dataclass
class Binding:
    """
    How to produce an instance of `type_`.

    Fields
    ------
    type_:
        The type being registered. Also the key in the container.
    scope:
        Lifetime of instances. Default: REQUEST.
    impl:
        Concrete implementation if type_ is an interface/abstract class.
        If set, the container resolves impl instead of type_.
    factory:
        Callable that produces an instance. May be sync or async.
        If None, the container auto-resolves via __init__ inspection.
    teardown:
        Callable called when the instance is disposed.
        Receives the instance as its only argument. May be sync or async.
        Only meaningful for SINGLETON and REQUEST scopes.
    instance:
        Pre-built instance. If set, scope is effectively SINGLETON
        regardless of the scope field. factory must be None.

    Resolution priority:
        instance > factory > impl > auto (inspect __init__)
    """

    type_: type
    scope: Scope = Scope.REQUEST
    impl: type | None = None
    factory: Any | None = None
    teardown: Any | None = None
    instance: Any | None = None

    _deps: list[type] = field(default_factory=list, repr=False)
    _cached_params: dict[str, type] | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        if self.instance is not None and self.factory is not None:
            raise ValueError(
                f"Binding for {self.type_.__name__}: "
                f"cannot specify both 'instance' and 'factory'."
            )
        if self.instance is not None:
            self.scope = Scope.SINGLETON

    def effective_type(self) -> type:
        """The type actually instantiated — impl if set, else type_."""
        return self.impl or self.type_

    def get_constructor_params(self) -> dict[str, type]:
        """
        Inspect __init__ to find typed parameters that need injection.
        Returns {param_name: type} for all params with type annotations,
        excluding 'self', '*args', '**kwargs', and params with defaults
        that are not themselves registered types.

        Called at build() time. Results are cached after first call.
        """
        if self._cached_params is not None:
            return self._cached_params

        if self.instance is not None:
            self._cached_params = {}
            return self._cached_params

        target = self.factory or self.effective_type()
        if target is self.factory:
            func_to_inspect = target
        else:
            func_to_inspect = target.__init__

        try:
            sig = inspect.signature(func_to_inspect)
            try:
                import typing

                hints = typing.get_type_hints(func_to_inspect)
            except Exception:  # noqa
                hints = getattr(func_to_inspect, "__annotations__", {})

            params = {}
            for name, param in sig.parameters.items():
                if name == "self":
                    continue
                if param.kind in (
                    inspect.Parameter.VAR_POSITIONAL,
                    inspect.Parameter.VAR_KEYWORD,
                ):
                    continue
                if name in hints:
                    hint = hints[name]
                    if isinstance(hint, str):
                        continue
                    params[name] = hint
            self._cached_params = params
            return params
        except (ValueError, TypeError):
            self._cached_params = {}
            return {}
