from __future__ import annotations
import inspect
import logging
from typing import Any, TYPE_CHECKING

from .binding import Binding, Scope
from ..checks import check_observability_plugin_installed

if TYPE_CHECKING:
    from .container import Container

_log = logging.getLogger("meridian.di")


class RequestScope:
    """
    Per-request dependency scope.

    Created by on_request_start hook.
    Torn down by on_request_end / on_request_error hook.
    """

    def __init__(self, container: "Container") -> None:
        self._container = container
        self._cache: dict[type, Any] = {}
        self._teardown: list[tuple[Any, Any]] = []

    async def resolve(self, type_: type) -> Any:
        """
        Resolve a type from this request scope.

        Resolution priority:
          1. REQUEST cache (same instance if already resolved this request)
          2. SINGLETON cache (from Container)
          3. TRANSIENT (new instance every time)

        Raises InjectionError if the type is not registered.
        """
        from .exceptions import InjectionError

        binding = self._container._bindings.get(type_)
        if binding is None:
            raise InjectionError(
                f"No binding registered for {type_.__name__}. "
                f"Call container.register({type_.__name__}, ...) before build()."
            )

        if binding.instance is not None:
            return binding.instance

        if binding.scope == Scope.SINGLETON:
            return await self._container._resolve_singleton(binding, self)

        if binding.scope == Scope.REQUEST:
            if type_ in self._cache:
                return self._cache[type_]
            instance, teardown = await self._create(binding)
            self._cache[type_] = instance
            if teardown is not None:
                self._teardown.append((instance, teardown))
            return instance

        instance, _ = await self._create(binding)
        return instance

    async def _create(self, binding: Binding) -> tuple[Any, Any]:
        """
        Instantiate a binding by calling its factory or auto-resolved constructor.
        """
        if binding.factory is not None:
            instance, teardown = await _call(
                binding.factory, await self._resolve_deps(binding)
            )
            return instance, (teardown or binding.teardown)

        target = binding.effective_type()
        deps = await self._resolve_deps(binding)
        return target(**deps), binding.teardown

    async def _resolve_deps(self, binding: Binding) -> dict[str, Any]:
        """Resolve all declared dependencies for a binding."""
        result = {}
        params = binding.get_constructor_params()
        for name, dep_type in params.items():
            if dep_type in self._container._bindings:
                result[name] = await self.resolve(dep_type)
        return result

    async def teardown(self) -> None:
        """
        Tear down all REQUEST-scoped instances created in this scope.

        Runs in reverse resolution order (LIFO).
        Collects ALL errors — never fail-fast.
        Errors are logged and stored for M2 span attribute.
        """
        errors: list[str] = []

        for instance, teardown_fn in reversed(self._teardown):
            try:
                await _call_teardown(teardown_fn, instance)
            except Exception as e:
                err = f"{type(instance).__name__}.teardown: {e}"
                errors.append(err)
                _log.error("teardown error: %s", err, exc_info=False)

        if errors:
            try:
                check_observability_plugin_installed()
                from meridian.observability.context import _get_active_span

                span = _get_active_span()
                if span:
                    span.set("app.teardown_errors", errors)
            except Exception:  # noqa
                pass

        self._cache.clear()
        self._teardown.clear()


async def _call(factory: Any, kwargs: dict[str, Any]) -> tuple[Any, Any]:
    """
    Call a factory with kwargs.
    Returns a tuple of (instance, generator_or_none).
    """
    res = factory(**kwargs)

    if inspect.isasyncgen(res):
        instance = await res.__anext__()
        return instance, res

    if inspect.iscoroutine(res):
        return await res, None

    return res, None


async def _call_teardown(teardown_fn: Any, instance: Any) -> None:
    """Call a teardown function (sync or async) with the instance."""
    if inspect.isasyncgen(teardown_fn):
        try:
            await teardown_fn.__anext__()
        except StopAsyncIteration:
            return
        await teardown_fn.aclose()
        return

    if inspect.iscoroutinefunction(teardown_fn):
        await teardown_fn(instance)
    elif hasattr(teardown_fn, "__call__") and inspect.iscoroutinefunction(
        teardown_fn.__call__
    ):
        await teardown_fn(instance)
    else:
        teardown_fn(instance)
