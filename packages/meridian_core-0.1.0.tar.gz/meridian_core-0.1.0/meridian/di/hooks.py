from __future__ import annotations
import logging
from typing import TYPE_CHECKING

from .. import Meridian

if TYPE_CHECKING:
    from ..context import RequestContext
    from ..response import Response
    from .container import Container

_log = logging.getLogger("meridian.di")


def install(app: Meridian, container: "Container") -> None:
    """
    Wire lifecycle hooks into the app.
    Called by Meridian.with_di().
    """
    if not container.is_built:
        container.build()

    async def _on_start(ctx: "RequestContext") -> None:
        scope = container.request_scope()
        ctx.extras["app.scope"] = scope

    async def _on_end(ctx: "RequestContext", response: "Response") -> None:
        scope = ctx.extras.get("app.scope")
        if scope is None:
            return
        try:
            await scope.teardown()
        except Exception as e:
            _log.error("M3 scope teardown failed: %s", e)

    async def _on_error(ctx: "RequestContext", exc: BaseException) -> None:
        scope = ctx.extras.get("app.scope")
        if scope is None:
            return
        try:
            await scope.teardown()
        except Exception as e:
            _log.error("Scope teardown failed on error path: %s", e)

    app.lifecycle.on_request_start.append(_on_start)
    app.lifecycle.on_request_end.append(_on_end)
    app.lifecycle.on_request_error.append(_on_error)
