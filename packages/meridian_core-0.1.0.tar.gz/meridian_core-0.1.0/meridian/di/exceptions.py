from __future__ import annotations
from ..exceptions import ConfigurationError, MeridianError


class InjectionError(MeridianError):
    """
    Raised at request time when a dependency cannot be resolved.
    Maps to 500 — this is always a framework/config error, not user input.
    """

    status_code = 500
    default_detail = "Dependency injection failed"


class ScopeViolationError(ConfigurationError):
    """
    Raised at build() time when a SINGLETON depends on a REQUEST-scoped type.
    State poisoning: request A's data would leak into request B via the shared
    singleton instance.
    """

    def __init__(self, dependent: type, dependency: type) -> None:
        super().__init__(
            f"Scope violation: {dependent.__name__} (SINGLETON) depends on "
            f"{dependency.__name__} (REQUEST). A singleton cannot hold a "
            f"request-scoped dependency — data from one request would leak "
            f"into subsequent requests. "
            f"Fix: change {dependent.__name__} to REQUEST scope, or change "
            f"{dependency.__name__} to SINGLETON scope."
        )
        self.dependent = dependent
        self.dependency = dependency


class CycleError(ConfigurationError):
    """
    Raised at build() time when a circular dependency is detected.
    """

    def __init__(self, cycle: list[type]) -> None:
        names = " → ".join(t.__name__ for t in cycle)
        super().__init__(
            f"Circular dependency detected: {names}. "
            f"Circular dependencies cannot be resolved."
        )
        self.cycle = cycle


class MissingBindingError(ConfigurationError):
    """
    Raised at build() time when a dependency is required but not registered.
    """

    def __init__(self, type_: type, required_by: type | None = None) -> None:
        if required_by:
            msg = (
                f"{type_.__name__} is required by {required_by.__name__} "
                f"but is not registered in the container. "
                f"Call container.register({type_.__name__}, ...) before build()."
            )
        else:
            msg = (
                f"{type_.__name__} is not registered in the container. "
                f"Call container.register({type_.__name__}, ...) before build()."
            )
        super().__init__(msg)
        self.type_ = type_
        self.required_by = required_by
