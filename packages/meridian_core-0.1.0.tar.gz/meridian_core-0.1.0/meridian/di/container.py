"""
Container — the DI registry.

Lifecycle:
  1. Register types via container.register(...)
  2. Call container.build() — validates graph, pre-builds singletons
  3. Pass to app: app.with_di(container)
  4. At request time, Container creates a RequestScope per request
  5. At shutdown, container.shutdown() tears down singletons

Thread/task safety:
  Singleton creation uses asyncio.Lock to prevent double-initialisation
  under concurrent requests. RequestScope instances are per-request and
  therefore never shared between tasks.
"""

from __future__ import annotations
import asyncio
import inspect
import logging
from typing import Any, Callable

from .binding import Binding, Scope, REQUEST
from .exceptions import InjectionError
from .graph import build_graph, topological_order
from .scope import RequestScope, _call, _call_teardown
from .. import ConfigurationError

_log = logging.getLogger("meridian.di")


def provider(
    container: "Container",
    scope: Scope = REQUEST,
    *,
    type_: type | None = None,
    teardown: Any | None = None,
) -> Callable[[Any], Any]:
    def decorator(factory: Any) -> Any:
        target_type = type_
        if target_type is None:
            try:
                import typing
                import collections.abc

                hints = typing.get_type_hints(factory)
                ret_hint = hints.get("return")
                if ret_hint:
                    origin = typing.get_origin(ret_hint)
                    if origin in (
                        typing.AsyncGenerator,
                        typing.Generator,
                        collections.abc.AsyncGenerator,
                        collections.abc.Generator,
                    ):
                        args = typing.get_args(ret_hint)
                        if args:
                            target_type = args[0]
                    else:
                        target_type = ret_hint
            except Exception:
                sig = inspect.signature(factory)
                target_type = (
                    sig.return_annotation
                    if sig.return_annotation is not inspect.Signature.empty
                    else None
                )

        if target_type is None or target_type is inspect.Signature.empty:
            raise ConfigurationError(
                f"Provider '{factory.__name__}' must have a return type annotation "
                f"or specify 'type_=' in @provider."
            )

        container.register(target_type, scope=scope, factory=factory, teardown=teardown)
        return factory

    return decorator


class Container:
    """
    Dependency injection container.

    Usage:
        container = Container()
        container.register(UserService, scope=SINGLETON)
        container.register(UserRepository, impl=PostgresRepo, scope=REQUEST)
        container.register(Database, factory=create_db, teardown=lambda db: db.close(), scope=SINGLETON)
        container.register(Config, instance=Config.from_env())
        container.build()

        app = Meridian().with_di(container)
    """

    def __init__(self) -> None:
        self._bindings: dict[type, Binding] = {}
        self._singletons: dict[type, Any] = {}
        self._lock: asyncio.Lock | None = None
        self.is_built: bool = False
        self._singleton_teardown: list[tuple[Any, Any]] = []

    def register(
        self,
        type_: type,
        *,
        scope: Scope = REQUEST,
        impl: type | None = None,
        factory: Any | None = None,
        teardown: Any | None = None,
        instance: Any | None = None,
    ) -> "Container":
        """
        Register a type with the container.

        Parameters
        ----------
        type_:
            The type to register. Used as the resolution key.
        scope:
            Lifetime: SINGLETON, REQUEST (default), or TRANSIENT.
        impl:
            Concrete implementation if type_ is abstract/protocol.
        factory:
            Callable (sync or async) that produces the instance.
            Receives resolved dependencies as keyword arguments.
        teardown:
            Callable (sync or async) called with the instance on disposal.
        instance:
            Pre-built instance. Implies SINGLETON scope.

        Returns self for chaining.
        """
        if self.is_built:
            raise RuntimeError(
                f"Cannot register {type_.__name__} after container.build() "
                f"has been called. Create a new container or call build() "
                f"after all registrations."
            )
        self._bindings[type_] = Binding(
            type_=type_,
            scope=scope,
            impl=impl,
            factory=factory,
            teardown=teardown,
            instance=instance,
        )
        return self

    def provider(
        self,
        scope: Scope = REQUEST,
        *,
        type_: type | None = None,
        teardown: Any | None = None,
    ) -> Callable[[Any], Any]:
        return provider(self, scope=scope, type_=type_, teardown=teardown)

    def build(self) -> "Container":
        """
        Validate the dependency graph and pre-build singletons.

        Raises:
            MissingBindingError  - unregistered dependency
            CycleError           - circular dependency
            ScopeViolationError  - SINGLETON -> REQUEST dependency

        Singletons with no async dependencies are built eagerly here.
        Singletons with async factories are built lazily on first resolve.

        Returns self for chaining.
        """
        if self.is_built:
            return self

        build_graph(self._bindings)

        order = topological_order(self._bindings)
        for type_ in order:
            binding = self._bindings[type_]
            if binding.instance is not None:
                self._singletons[type_] = binding.instance
                continue
            if binding.scope != Scope.SINGLETON:
                continue
            if binding.factory is not None and (
                inspect.iscoroutinefunction(binding.factory)
                or inspect.isasyncgenfunction(binding.factory)
            ):
                continue
            if binding.factory is None and self._has_async_deps(binding):
                continue

            try:
                instance = self._build_sync(binding)
                self._singletons[type_] = instance
                if binding.teardown is not None:
                    self._singleton_teardown.append((instance, binding.teardown))
            except Exception as e:
                raise InjectionError(
                    f"Failed to build singleton {type_.__name__}: {e}"
                ) from e

        self.is_built = True
        self._lock = asyncio.Lock()
        return self

    def override(self, type_: type, **kwargs: Any) -> "Container":
        """
        Return a new Container with one binding replaced.
        The original container is unchanged.

        Useful in tests:
            test_container = production_container.override(
                UserRepository, instance=FakeUserRepository()
            )
        """
        new = Container()
        new._bindings = dict(self._bindings)
        new.register(type_, **kwargs)
        return new

    async def _resolve_singleton(
        self,
        binding: Binding,
        scope: RequestScope,
    ) -> Any:
        """
        Resolve a SINGLETON-scoped binding.
        Uses a lock to prevent double-initialisation under concurrency.
        """
        type_ = binding.type_

        if type_ in self._singletons:
            return self._singletons[type_]

        async with self._lock:  # type: ignore[union-attr]
            if type_ in self._singletons:
                return self._singletons[type_]

            result = await self._build_async(binding, scope)
            if isinstance(result, tuple):
                instance, teardown = result
            else:
                instance, teardown = result, None

            self._singletons[type_] = instance
            if teardown is not None:
                self._singleton_teardown.append((instance, teardown))
            return instance

    def _build_sync(self, binding: Binding) -> Any:
        """Build a binding synchronously (only safe for sync factories/constructors)."""
        if binding.factory is not None:
            deps = self._resolve_sync_deps(binding)
            return binding.factory(**deps)
        target = binding.effective_type()
        deps = self._resolve_sync_deps(binding)
        return target(**deps)

    def _resolve_sync_deps(self, binding: Binding) -> dict[str, Any]:
        params = binding.get_constructor_params()
        result = {}
        for name, dep_type in params.items():
            if dep_type in self._singletons:
                result[name] = self._singletons[dep_type]
        return result

    async def _build_async(self, binding: Binding, scope: RequestScope) -> Any:
        """Build a binding asynchronously, resolving deps via scope."""
        deps = {}
        params = binding.get_constructor_params()
        for name, dep_type in params.items():
            if dep_type in self._bindings:
                deps[name] = await scope.resolve(dep_type)

        if binding.factory is not None:
            return await _call(binding.factory, deps)
        target = binding.effective_type()
        return target(**deps), binding.teardown

    def _has_async_deps(self, binding: Binding) -> bool:
        """True if any transitive dependency has an async factory."""
        params = binding.get_constructor_params()
        for dep_type in params.values():
            dep_binding = self._bindings.get(dep_type)
            if dep_binding is None:
                continue
            if dep_binding.factory and inspect.iscoroutinefunction(dep_binding.factory):
                return True
            if self._has_async_deps(dep_binding):
                return True
        return False

    def request_scope(self) -> RequestScope:
        """
        Create a new RequestScope for one request.
        Called by the on_request_start hook.
        """
        if not self.is_built:
            raise RuntimeError(
                "Container.build() must be called before handling requests. "
                "with_di() calls build() automatically if not already built."
            )
        return RequestScope(self)

    async def shutdown(self) -> None:
        """
        Tear down all SINGLETON-scoped instances.

        Called once on application shutdown (on_shutdown hook).
        Runs in reverse resolution order.
        Collects all errors — never fail-fast.
        """
        errors: list[str] = []

        for instance, teardown_fn in reversed(self._singleton_teardown):
            try:
                await _call_teardown(teardown_fn, instance)
            except Exception as e:
                err = f"{type(instance).__name__}.teardown: {e}"
                errors.append(err)
                _log.error("singleton teardown error: %s", err)

        self._singletons.clear()
        self._singleton_teardown.clear()
        self.is_built = False

        if errors:
            raise InjectionError(
                f"Container shutdown completed with {len(errors)} teardown error(s): "
                + "; ".join(errors)
            )
