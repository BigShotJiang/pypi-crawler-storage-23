"""
Dependency graph — validation at build() time.

Two checks run over the full binding set before any instance is created:

1. Cycle detection
   Uses depth-first search. Any back edge in the graph is a cycle.
   Raises CycleError immediately on first cycle found.

2. Scope violation detection
   A SINGLETON that depends (transitively) on a REQUEST-scoped type
   would hold a stale reference after the request ends — state poisoning.
   Raises ScopeViolationError for any such violation.

Both checks run in O(V + E) where V = types, E = dependencies.
"""

from __future__ import annotations
from typing import TYPE_CHECKING

from .binding import Binding, Scope
from .exceptions import CycleError, MissingBindingError, ScopeViolationError

if TYPE_CHECKING:
    pass


def build_graph(bindings: dict[type, Binding]) -> None:
    """
    Validate the dependency graph and populate Binding._deps for each binding.

    Mutates bindings in-place: sets binding._deps to the ordered list of
    dependency types for each binding.

    Raises:
        MissingBindingError  — a dependency is not registered
        CycleError           — circular dependency detected
        ScopeViolationError  — SINGLETON depends on REQUEST
    """
    for binding in bindings.values():
        params = binding.get_constructor_params()
        deps = []
        for param_name, param_type in params.items():
            if param_type in bindings:
                deps.append(param_type)
            elif _is_injectable(param_type):
                raise MissingBindingError(param_type, required_by=binding.type_)
        binding._deps = deps

    _detect_cycles(bindings)

    _detect_scope_violations(bindings)


def _is_injectable(t: type) -> bool:
    """
    True if the type looks like something that should be injected
    (i.e. a user-defined class, not a primitive or stdlib type).
    """
    if t in (int, float, str, bool, bytes, list, dict, tuple, set, type(None)):
        return False
    module = getattr(t, "__module__", "") or ""
    if module.startswith("builtins"):
        return False
    return True


def _detect_cycles(bindings: dict[type, Binding]) -> None:
    """DFS cycle detection. Raises CycleError on first cycle found."""
    WHITE, GRAY, BLACK = 0, 1, 2
    colour: dict[type, int] = {t: WHITE for t in bindings}
    path: list[type] = []

    def visit(node: type) -> None:
        colour[node] = GRAY
        path.append(node)
        for dep in bindings[node]._deps:
            if dep not in colour:
                continue
            if colour[dep] == GRAY:
                cycle_start = path.index(dep)
                raise CycleError(path[cycle_start:] + [dep])
            if colour[dep] == WHITE:
                visit(dep)
        path.pop()
        colour[node] = BLACK

    for t in bindings:
        if colour[t] == WHITE:
            visit(t)


def _detect_scope_violations(bindings: dict[type, Binding]) -> None:
    """
    A SINGLETON must not depend (directly or transitively) on a REQUEST type.

    Walk the graph from each SINGLETON node. If any reachable node is REQUEST,
    raise ScopeViolationError.
    """

    def reachable_request_dep(
        start: type,
        visited: set[type],
    ) -> type | None:
        for dep in bindings[start]._deps:
            if dep in visited or dep not in bindings:
                continue
            visited.add(dep)
            if bindings[dep].scope == Scope.REQUEST:
                return dep
            _found = reachable_request_dep(dep, visited)
            if _found:
                return _found
        return None

    for t, binding in bindings.items():
        if binding.scope == Scope.SINGLETON:
            found = reachable_request_dep(t, {t})
            if found:
                raise ScopeViolationError(dependent=t, dependency=bindings[found].type_)


def topological_order(bindings: dict[type, Binding]) -> list[type]:
    """
    Return types in dependency order (leaves first, dependents last).
    Used to determine instantiation order for singletons.

    Assumes build_graph() has already run (no cycles).
    """
    visited: set[type] = set()
    order: list[type] = []

    def visit(node: type) -> None:
        if node in visited:
            return
        visited.add(node)
        for dep in bindings[node]._deps:
            if dep in bindings:
                visit(dep)
        order.append(node)

    for t in bindings:
        visit(t)

    return order
