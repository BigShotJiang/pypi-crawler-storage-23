"""
NoopBackend — silences all observability output.

Use in tests or benchmarks where you want M2 wired up but no output:

    app = Meridian(
        observability=ObservabilityConfig(backends=[NoopBackend()])
    )
"""

from meridian.observability.backends import ObservabilityBackend

from meridian.observability.span import Span


class NoopBackend(ObservabilityBackend):
    async def on_span_start(self, span: Span) -> None:
        pass

    async def on_span_end(self, span: Span) -> None:
        pass

    async def on_span_error(self, span: Span) -> None:
        pass

    async def shutdown(self) -> None:
        pass
