from __future__ import annotations
import json
import sys
from datetime import datetime, timezone
from typing import Any

from meridian.observability.backends import ObservabilityBackend

from meridian.observability.span import Span


def _ts() -> str:
    """ISO 8601 timestamp in UTC."""
    return (
        datetime.now(timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )


class LoggingBackend(ObservabilityBackend):
    """
    Writes one JSON line per completed request to stdout.

    Parameters
    ----------
    include_start:
        If True, also emits a line when the span opens (before handler).
        Useful for debugging long-running requests. Default False.
    stream:
        Output stream. Defaults to sys.stdout.
    """

    def __init__(
        self,
        include_start: bool = False,
        stream: Any = None,
    ) -> None:
        self._include_start = include_start
        self._stream = stream or sys.stdout

    async def on_span_start(self, span: "Span") -> None:
        if not self._include_start:
            return
        self._emit(
            {
                "ts": _ts(),
                "level": "DEBUG",
                "event": "request.start",
                "method": span.method,
                "path": span.path,
                "trace_id": span.trace_id,
                "span_id": span.span_id,
                "request_id": span.request_id,
                **({"parent_id": span.parent_id} if span.parent_id else {}),
            }
        )

    async def on_span_end(self, span: "Span") -> None:
        record: dict[str, Any] = {
            "ts": _ts(),
            "level": "WARNING" if span.is_slow else "INFO",
            "event": "request.slow" if span.is_slow else "request",
            "method": span.method,
            "path": span.path,
            "status": span.status_code,
            "duration_ms": round(span.duration_ms or 0, 3),
            "trace_id": span.trace_id,
            "span_id": span.span_id,
            "request_id": span.request_id,
        }
        if span.route:
            record["route"] = span.route
        if span.parent_id:
            record["parent_id"] = span.parent_id
        if span.attributes:
            for k, v in span.attributes.items():
                if not k.startswith("_"):
                    record[k] = v
        self._emit(record)

    async def on_span_error(self, span: Span) -> None:
        record: dict[str, Any] = {
            "ts": _ts(),
            "level": "ERROR",
            "event": "request.error",
            "method": span.method,
            "path": span.path,
            "error": span.error,
            "error_type": span.error_type,
            "duration_ms": round(span.duration_ms or 0, 3),
            "trace_id": span.trace_id,
            "span_id": span.span_id,
            "request_id": span.request_id,
        }
        if span.route:
            record["route"] = span.route
        if span.parent_id:
            record["parent_id"] = span.parent_id
        self._emit(record)

    def _emit(self, record: dict[str, Any]) -> None:
        try:
            line = json.dumps(record, default=str)
            print(line, file=self._stream, flush=True)
        except Exception:  # noqa
            pass

    async def shutdown(self) -> None:
        """Flush any buffered output. Called on app shutdown."""
        try:
            if hasattr(self._stream, "flush"):
                self._stream.flush()
        except Exception:  # noqa
            pass
