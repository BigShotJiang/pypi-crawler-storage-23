from __future__ import annotations
import logging


class TraceContextFilter(logging.Filter):
    """
    Injects trace context into log records if a request is in progress.

    Fields added to each record:
      trace_id   — from active span (or "-")
      span_id    — from active span (or "-")
      request_id — from active span (or "-")
      route      — matched route pattern (or "-")
    """

    def filter(self, record: logging.LogRecord) -> bool:
        from meridian.observability.context import _get_active_span

        span = _get_active_span()
        if span is not None:
            record.trace_id = span.trace_id
            record.span_id = span.span_id
            record.request_id = span.request_id
            record.route = span.route or "-"
        else:
            record.trace_id = "-"
            record.span_id = "-"
            record.request_id = "-"
            record.route = "-"
        return True


_filter = TraceContextFilter()

_DEFAULT_FORMAT = (
    "%(asctime)s %(levelname)-8s %(name)s "
    "[trace=%(trace_id).8s span=%(span_id).8s route=%(route)s] "
    "%(message)s"
)


def install_trace_filter(
    fmt: str | None = None,
    level: int = logging.INFO,
) -> None:
    """
    Install the trace context filter on the root logger.

    Call once during application startup (e.g. in on_startup hook).
    After this, all logging calls anywhere in the process will include
    trace context when inside a request.

    Parameters
    ----------
    fmt:   Log format string. Defaults to _DEFAULT_FORMAT.
    level: Root logger level. Defaults to INFO.
    """
    root = logging.getLogger()
    root.setLevel(level)

    if not any(isinstance(f, TraceContextFilter) for f in root.filters):
        root.addFilter(_filter)

    if not root.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(fmt or _DEFAULT_FORMAT))
        root.addHandler(handler)
    else:
        for h in root.handlers:
            if not h.formatter:
                h.setFormatter(logging.Formatter(fmt or _DEFAULT_FORMAT))
