import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Literal


SpanStatus = Literal["unset", "ok", "error"]


@dataclass
class SpanEvent:
    """A timestamped point-in-time record attached to a span."""

    name: str
    timestamp: float
    attributes: dict[str, Any] = field(default_factory=dict)


@dataclass
class Span:
    span_id: str
    trace_id: str
    parent_id: str | None
    request_id: str

    method: str
    path: str
    route: str | None

    started_at: float

    status_code: int | None = field(default=None)
    duration_ms: float | None = field(default=None)
    error: str | None = field(default=None)
    error_type: str | None = field(default=None)

    status: SpanStatus = field(default="unset")

    events: list[SpanEvent] = field(default_factory=list)

    attributes: dict[str, Any] = field(default_factory=dict)

    _closed: bool = field(default=False, repr=False)

    def set(self, key: str, value: Any) -> None:
        """Write an attribute. Safe to call from handlers and middleware."""
        self.attributes[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        return self.attributes.get(key, default)

    def add_event(self, name: str, attributes: dict[str, Any] | None = None) -> None:
        """
        Record a timestamped point-in-time event on this span.

        Useful for recording cache misses, retries, or other discrete occurrences
        that happen during the request. Events are buffered and available to
        backends when the span closes.

        Parameters
        ----------
        name : str
            Event name (e.g. "cache.miss", "db.retry")
        attributes : dict[str, Any], optional
            Key-value pairs associated with this event
        """
        event = SpanEvent(
            name=name,
            timestamp=time.monotonic(),
            attributes=attributes or {},
        )
        self.events.append(event)

    def set_status(self, status: SpanStatus) -> None:
        """
        Set the OTel-style span status explicitly.

        Parameters
        ----------
        status : "unset" | "ok" | "error"
            The span completion status
        """
        if status not in ("unset", "ok", "error"):
            raise ValueError(
                f"Invalid status: {status}. Must be 'unset', 'ok', or 'error'."
            )
        self.status = status

    @property
    def is_slow(self) -> bool:
        """True if duration_ms is set and exceeds the configured threshold."""
        return self.attributes.get("_slow", False)

    @property
    def is_error(self) -> bool:
        return self.error is not None

    def close(self, status_code: int) -> None:
        if self._closed:
            return
        self.status_code = status_code
        self.duration_ms = (time.monotonic() - self.started_at) * 1000
        if self.status == "unset":
            self.status = "ok"
        self._closed = True

    def close_with_error(self, exc: BaseException) -> None:
        if self._closed:
            return
        self.error = str(exc)
        self.error_type = type(exc).__name__
        self.duration_ms = (time.monotonic() - self.started_at) * 1000
        self.status = "error"
        self._closed = True


def make_span(
    request_id: str,
    method: str,
    path: str,
    trace_id: str | None = None,
    parent_id: str | None = None,
) -> Span:
    """

    If trace_id is not provided (no upstream X-Trace-ID header),
    a new one is generated. For deterministic sampling, the trace_id
    is the sampling key — all spans with the same trace_id are either
    all sampled or all dropped.
    """
    span_id = str(uuid.uuid4())
    trace_id = trace_id or span_id

    return Span(
        span_id=span_id,
        trace_id=trace_id,
        parent_id=parent_id,
        request_id=request_id,
        method=method,
        path=path,
        route=None,
        started_at=time.monotonic(),
    )
