from dataclasses import dataclass, field

from meridian.observability.backends import ObservabilityBackend
from meridian.observability.logging import LoggingBackend


@dataclass(frozen=True)
class ObservabilityConfig:
    backends: list[ObservabilityBackend] = field(default_factory=list)

    trace_id_header: str = "X-Trace-ID"
    parent_id_header: str = "X-Parent-Span-ID"
    span_id_header: str = "X-Span-ID"
    propagate_headers: bool = True

    sample_rate: float = 1.0

    slow_request_ms: int | None = None

    def __post_init__(self) -> None:
        if not (0.0 <= self.sample_rate <= 1.0):
            raise ValueError(
                f"ObservabilityConfig.sample_rate must be between 0.0 and 1.0, "
                f"got {self.sample_rate}"
            )

    def effective_backends(self) -> list[ObservabilityBackend]:
        """
        Return backends to use. If none configured, default to LoggingBackend.
        Called at install time, not at construction time, to avoid import cycles.
        """
        if self.backends:
            return list(self.backends)
        return [LoggingBackend()]

    def is_sampled(self, trace_id: str) -> bool:
        """
        Deterministic sampling based on trace_id hash.
        All spans in the same distributed trace make the same sampling decision.
        """
        if self.sample_rate >= 1.0:
            return True
        if self.sample_rate <= 0.0:
            return False
        h = int(trace_id.replace("-", ""), 16)
        return (h % 10_000) < int(self.sample_rate * 10_000)
