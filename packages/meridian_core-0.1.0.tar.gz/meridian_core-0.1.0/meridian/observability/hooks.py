from __future__ import annotations
import logging

from meridian import Response, Meridian
from meridian.context import RequestContext

from meridian.observability.config import ObservabilityConfig
from meridian.observability.context import set_active_span, reset_active_span
from meridian.observability.span import make_span

_log = logging.getLogger("meridian.observability")


def install(app: Meridian, config: ObservabilityConfig) -> None:
    """
    Wire M2 hooks into the app's lifecycle hook registries.

    Called by Meridian.__init__ when observability is not None.
    """
    backends = config.effective_backends()

    async def _on_start(ctx: RequestContext) -> None:
        request = ctx.extras.get("_request")
        trace_id = None
        parent_id = None

        if request is not None:
            h = request.headers
            trace_id = h.get(config.trace_id_header.lower())
            parent_id = h.get(config.parent_id_header.lower())

        span = make_span(
            request_id=ctx.request_id,
            method=ctx.method,
            path=ctx.path,
            trace_id=trace_id,
            parent_id=parent_id,
        )

        if not config.is_sampled(span.trace_id):
            span.set("_sampled", False)
        else:
            span.set("_sampled", True)

        ctx.extras["m2.span"] = span

        token = set_active_span(span)
        ctx.extras["m2.span_token"] = token

        if not span.get("_sampled"):
            return

        for backend in backends:
            try:
                await backend.on_span_start(span)
            except Exception as e:
                _log.error("on_span_start backend failed: %s", e, exc_info=False)

    async def _on_end(ctx: "RequestContext", response: Response) -> None:
        span = ctx.extras.get("m2.span")
        if span is None:
            return

        span.route = ctx.route

        span.close(status_code=response.status_code)

        if (
            config.slow_request_ms is not None
            and span.duration_ms is not None
            and span.duration_ms > config.slow_request_ms
        ):
            span.set("_slow", True)

        if config.propagate_headers:
            response._headers[config.span_id_header.lower()] = span.span_id
            response._headers[config.trace_id_header.lower()] = span.trace_id
            response._headers["x-request-id"] = span.request_id

        token = ctx.extras.pop("m2.span_token", None)
        if token is not None:
            reset_active_span(token)

        if not span.get("_sampled"):
            return

        for backend in backends:
            try:
                await backend.on_span_end(span)
            except Exception as e:
                _log.error("on_span_end backend failed: %s", e, exc_info=False)

    async def _on_error(ctx: RequestContext, exc: BaseException) -> None:
        span = ctx.extras.get("m2.span")
        if span is None:
            return

        span.route = ctx.route

        span.close_with_error(exc)

        token = ctx.extras.pop("m2.span_token", None)
        if token is not None:
            reset_active_span(token)

        if not span.get("_sampled"):
            return

        for backend in backends:
            try:
                await backend.on_span_error(span)
            except Exception as e:
                _log.error("on_span_error backend failed: %s", e, exc_info=False)

    app.lifecycle.on_request_start.append(_on_start)
    app.lifecycle.on_request_end.append(_on_end)
    app.lifecycle.on_request_error.append(_on_error)

    async def _on_shutdown() -> None:
        """Flush buffers and clean up all backends on app shutdown."""
        for backend in backends:
            try:
                await backend.shutdown()
            except Exception as e:
                _log.error("backend.shutdown() failed: %s", e, exc_info=False)

    app.lifecycle.on_shutdown.append(_on_shutdown)
