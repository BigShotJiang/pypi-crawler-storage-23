from __future__ import annotations

from meridian.observability.span import Span


class ObservabilityBackend:
    """
    Protocol for observability backends.

    Subclass this or implement the same interface.
    All methods are optional — default implementations are no-ops.
    """

    async def on_span_start(self, span: Span) -> None:
        """Called when a span is opened (before middleware chain)."""

    async def on_span_end(self, span: Span) -> None:
        """Called when a span is closed (after handler, including slow requests)."""

    async def on_span_error(self, span: Span) -> None:
        """Called when a request ends with an unhandled exception."""

    async def shutdown(self) -> None:
        """Called when the app is shutting down. Override to clean up resources."""
