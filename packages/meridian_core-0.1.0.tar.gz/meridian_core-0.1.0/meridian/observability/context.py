"""
Span ContextVar — makes current_span() work from anywhere in the call stack.

The span is stored in RequestContext.extras["m2.span"] as the source of truth,
but also mirrored here in a ContextVar for O(1) access without going through
the RequestContext lookup chain.

"""

from __future__ import annotations
from contextvars import ContextVar

from meridian.observability.span import Span

_active_span: ContextVar[Span | None] = ContextVar("_active_span", default=None)


def _get_active_span() -> Span | None:
    """Internal. Used by TraceContextFilter and current_span()."""
    return _active_span.get()


def _set_active_span(span: Span) -> object:
    """Internal. Called by M2 install hooks only."""
    return _active_span.set(span)


def _reset_active_span(token: object) -> None:
    """Internal. Called in the finally block after each request."""
    _active_span.reset(token)  # type: ignore[arg-type]


set_active_span = _set_active_span
reset_active_span = _reset_active_span


def current_span() -> Span | None:
    """
    Public API. Return the active Span for the current request.

    Returns None if:
      - Called outside a request context
      - M2 is disabled (observability=None)
      - The request was not sampled

    Safe to call from handlers, middleware, background tasks spawned
    during a request (ContextVar is inherited by child tasks).

    Example:
        from meridian.observability import current_span

        @app.get("/users/{id}")
        async def get_user(id: Path[int]) -> dict:
            span = current_span()
            if span:
                span.set("user.id", id)
            ...
    """
    return _get_active_span()
