import inspect
from typing import Any, Callable


from .checks import check_observability_plugin_installed
from .config import OperationalConfig, ValidationConfig, LifeCycleHooks
from .exceptions import ConfigurationError
from .extractors import ExtractorPlan
from .gateway import Gateway
from .logger import setup_logging
from .middleware import MiddlewareChain
from .request import Request
from .response import JSONResponse, Response
from .router import Router
from .types import Middleware, Plugin, Scope, Receive, Send

_SENTINEL = object()


class Meridian:
    """
    Meridian REST API framework.

    A minimal, composable async REST framework for Python 3.12+.
    Combines type-safe parameter extraction, automatic request/response handling,
    middleware composition, and optional dependency injection.

    Architecture
    ============
    Request flow: ASGI Gateway → Middleware Chain → Router → Handler Extractors → Handler

    The application is built lazily on first request via _build(), which:
      1. Composes the middleware chain
      2. Creates the Gateway (handles concurrency, deadlines, lifecycle)
      3. Wires request context, hooks, and error handling

    Configuration
    ==============
    Parameters
    ----------
    name : str, optional
        Application name for logging and identification. Default: "meridian-app"

    operational : OperationalConfig, optional
        Runtime behavior:
        - max_concurrent_requests: int (default 1000)
          Backpressure limit. 0 = unlimited. Returns 503 when exceeded.
        - request_deadline_ms: int | None (default 5000)
          Per-request timeout in milliseconds. None = no deadline.
          Uses anyio.CancelScope for proper cancellation propagation.
        - max_body_size: int (default 1 MB)
          Maximum allowed request body size.
        - drain_timeout_s: int (default 30)
          Graceful shutdown drain timeout for M7.

    validation : ValidationConfig, optional
        Validation behavior:
        - mode: str (default "strict")
          Validation strictness mode.
        - ignore_unknown_query_params: bool (default True)
          If True, unknown query parameters are silently ignored.
          If True, validate response types match handler annotations.

    lifecycle : LifecycleHooks, optional
        Async lifecycle callbacks:
        - on_startup: list[Callable[[], Awaitable[None]]]
          Called once when app starts (M7 startup).
        - on_shutdown: list[Callable[[], Awaitable[None]]]
          Called once when app shuts down (M7 shutdown).
        - on_request_start: list[Callable[[Request], Awaitable[None]]]
          Called before each request (M2).
        - on_request_end: list[Callable[[Request, Response], Awaitable[None]]]
          Called after each successful request (M2).
        - on_request_error: list[Callable[[Request, Exception], Awaitable[None]]]
          Called when handler raises an exception (M2).
          Health check handlers (M9).
        - drain_timeout_s: int
          Graceful shutdown timeout.

    debug : bool, optional
        Enable debug mode (default False). Disables request deadlines,
        includes stack traces in error responses.

    exception_handlers : dict[type[Exception], Callable], optional
        Custom exception handlers for specific exception types.
        Handler signature: async def handler(request: Request, exception: Exception) -> Response | None
        If handler returns a Response, it will be sent and default error handling is skipped.
        If handler returns None or raises an exception, default error handling proceeds.
        Handlers respect exception inheritance (MRO) for matching.

    default_response_class : type[Response], optional
        Default response wrapper for handler return values (default JSONResponse).
        Used for wrapping dict, list, and Pydantic model returns from handlers.
    """

    def __init__(
        self,
        *,
        name: str = "meridian-app",
        operational: OperationalConfig = OperationalConfig(),
        validation: ValidationConfig = ValidationConfig(),
        lifecycle: LifeCycleHooks = LifeCycleHooks(),
        observability: Any = _SENTINEL,
        debug: bool = False,
        exception_handlers: dict[type[Exception], Callable] | None = None,
        default_response_class: type[Response] = JSONResponse,
    ) -> None:
        self.app_name = name
        self.operational = operational
        self.validation = validation
        self.lifecycle = lifecycle
        self.debug = debug
        self.default_response_class = default_response_class
        if not (
            isinstance(default_response_class, type)
            and issubclass(default_response_class, Response)
        ):
            raise ConfigurationError(
                f"default_response_class must be a subclass of meridian.Response, "
                f"got {type(default_response_class).__name__}."
            )

        self.exception_handlers = exception_handlers

        setup_logging(debug=self.debug, app_name=self.app_name)

        self._router = Router()
        self._middlewares: list[Middleware] = []
        self._container: Any | None = None

        self._gateway: Gateway | None = None

        if observability is not _SENTINEL:
            self.with_observability(observability)

    def with_di(self, container: Any) -> "Meridian":
        """
        Attach a DI container.

        Calls container.build() if not already built, then wires
        lifecycle hooks for request-scope creation and teardown.

        Must be called before registering routes that use Inject[T].
        """
        if self._gateway is not None:
            raise ConfigurationError(
                "with_di() must be called before the app is built. "
                "Call it before registering routes or on the initial app instance."
            )

        from .di.hooks import install
        from .di.container import Container

        if not isinstance(container, Container):
            raise ConfigurationError(
                f"with_di() expects a meridian.di.Container instance, "
                f"got {type(container).__name__}."
            )

        self._container = container
        install(self, container)
        self._gateway = None
        return self

    def with_plugin(self, plugin: Plugin) -> "Meridian":
        """Generic plugin attachment. M2, M5, M7 use this."""
        if not isinstance(plugin, Plugin):
            raise ConfigurationError(
                f"{type(plugin).__name__} does not implement the Plugin protocol. "
                f"Plugins must have an install(app) method."
            )
        plugin.install(self)
        return self

    def with_observability(self, config=None) -> "Meridian":
        check_observability_plugin_installed()
        from meridian.observability import ObservabilityConfig, install

        if config is None:
            config = ObservabilityConfig()

        install(self, config)
        return self

    def use(self, mw: Middleware) -> "Meridian":
        """
        Add middleware to the stack.
        First added = outermost (runs first on request).
        """
        self._middlewares.append(mw)
        self._gateway = None
        return self

    def _register(
        self,
        method: str,
        path: str,
        handler: Callable,
        name: str | None = None,
    ) -> Callable:
        """
        Core route registration. Called by get/post/put/delete/patch.

        Steps:
          1. Validate handler is async def
          2. Add route to router (gets back Route object)
          3. Build ExtractorPlan (raises ConfigurationError immediately on misconfiguration)
          4. Wrap handler: resolve extractors → call handler → wrap return as Response
          5. Attach ExtractorPlan to Route
        """
        if not inspect.iscoroutinefunction(handler):
            raise ConfigurationError(
                f"Handler '{handler.__name__}' is not an async function. "
                f"Meridian only supports async def handlers. "
                f"Sync handlers silently harm performance under concurrency."
            )

        route = self._router.add(method, path, handler, name=name)

        plan = ExtractorPlan.build(
            handler=handler, container=self._container, validation=self.validation
        )
        route.extractor_plan = plan

        from .validation import ResponseValidator

        validator = ResponseValidator.build(handler, self.validation)
        route.response_validator = validator

        self._gateway = None
        return handler

    def get(self, path: str, *, name: str | None = None) -> Callable:
        return lambda fn: self._register("GET", path, fn, name)

    def post(self, path: str, *, name: str | None = None) -> Callable:
        return lambda fn: self._register("POST", path, fn, name)

    def put(self, path: str, *, name: str | None = None) -> Callable:
        return lambda fn: self._register("PUT", path, fn, name)

    def delete(self, path: str, *, name: str | None = None) -> Callable:
        return lambda fn: self._register("DELETE", path, fn, name)

    def patch(self, path: str, *, name: str | None = None) -> Callable:
        return lambda fn: self._register("PATCH", path, fn, name)

    async def _route_request(self, request: Request) -> Response:
        """
        The innermost handler in the middleware chain.
        Matches the request, runs extractors, calls the handler.
        """
        from .context import get_request_context

        match = self._router.match(request.method, request.path)

        request.path_params = match.path_params

        try:
            ctx = get_request_context()
            ctx.route = match.route.pattern
        except LookupError:
            pass

        kwargs = await match.route.extractor_plan.run(request)

        result = await match.route.handler(**kwargs)

        if match.route.response_validator is not None:
            await match.route.response_validator.validate(result)

        return _wrap_response(result, self.default_response_class)

    def verify_integrity(self) -> None:
        """
        Audit all registered routes for structural misconfigurations.
        Checks:
          - Missing DI bindings for Inject[T]
          - Path parameter mismatches (extractor exists but param missing from route)

        Raises ConfigurationError on the first failure found.
        """
        for method, pattern, route in self._router.get_all_routes():
            if route.extractor_plan is not None:
                route.extractor_plan.verify(
                    handler_name=route.handler.__name__,
                    route_pattern=pattern,
                    container=self._container,
                )

    def _build(self) -> Gateway:
        """
        Compose the middleware chain and build the Gateway.
        Called lazily on first request or explicitly.
        Logs the middleware chain to stdout.
        """
        self.verify_integrity()

        chain = MiddlewareChain(self._middlewares, self._route_request)

        gateway = Gateway(
            handler=chain,
            max_concurrent_requests=self.operational.max_concurrent_requests,
            request_deadline_ms=self.operational.request_deadline_ms,
            on_request_start=self.lifecycle.on_request_start,
            on_request_end=self.lifecycle.on_request_end,
            on_request_error=self.lifecycle.on_request_error,
            on_startup=self.lifecycle.on_startup,
            on_shutdown=self.lifecycle.on_shutdown,
            drain_timeout_s=self.operational.drain_timeout_s,
            exception_handlers=self.exception_handlers,
        )
        return gateway

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """ASGI entry point."""
        if self._gateway is None:
            self._gateway = self._build()
        await self._gateway(scope, receive, send)


def _wrap_response(
    result: Any, default_response_class: type[Response] = JSONResponse
) -> Response:
    """
    Convert a handler's return value to a Response.

    - Response subclass: pass through unchanged
    - dict / list: wrap as default_response_class
    - Pydantic BaseModel: use model_dump() → default_response_class
    - None: 204 No Content
    - str: 200 text/plain
    - Everything else: attempt JSON serialisation via default_response_class
    """
    if isinstance(result, Response):
        return result

    if result is None:
        return Response(b"", status_code=204)

    if isinstance(result, str):
        return Response(result.encode(), status_code=200, media_type="text/plain")

    if hasattr(result, "model_dump"):
        return default_response_class(result.model_dump(), status_code=200)

    if hasattr(result, "dict"):
        return default_response_class(result.dict(), status_code=200)

    return default_response_class(result, status_code=200)
