from __future__ import annotations
import time
import uuid
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any


@dataclass
class RequestContext:
    request_id: str
    received_at: float
    method: str
    path: str
    deadline_at: float | None = None
    route: str | None = None
    extras: dict[str, Any] = field(default_factory=dict)

    def elapsed_ms(self) -> float:
        return (time.monotonic() - self.received_at) * 1000

    def is_deadline_exceeded(self) -> bool:
        if self.deadline_at is None:
            return False
        return time.monotonic() > self.deadline_at


_request_context_var: ContextVar[RequestContext] = ContextVar(
    "meridian_request_context"
)


def get_request_context() -> RequestContext:
    """
    Public API. Call from anywhere in the stack.
    Raises LookupError if called outside a request context
    (e.g. in a background task not spawned during a request).
    """
    try:
        return _request_context_var.get()
    except LookupError:
        raise LookupError(
            "get_request_context() called outside a request. "
            "If you're in a background task, pass the context explicitly."
        ) from None


def _set_request_context(ctx: RequestContext) -> Any:
    """
    Internal. Called only by Gateway before middleware chain runs.
    Returns the token needed to reset the ContextVar after the request.
    """
    return _request_context_var.set(ctx)


def _reset_request_context(token: Any) -> None:
    """
    Internal. Called only by Gateway after request completes.
    """
    _request_context_var.reset(token)


def make_request_context(
    method: str,
    path: str,
    deadline_ms: int | None = None,
) -> RequestContext:
    """
    Factory called by Gateway for each incoming request.
    """
    now = time.monotonic()
    return RequestContext(
        request_id=str(uuid.uuid4()),
        received_at=now,
        method=method,
        path=path,
        deadline_at=(now + deadline_ms / 1000) if deadline_ms else None,
    )
