from __future__ import annotations
from typing import Any, Awaitable, Callable, Protocol, runtime_checkable

Scope = dict[str, Any]
Message = dict[str, Any]
Receive = Callable[[], Awaitable[Message]]
Send = Callable[[Message], Awaitable[None]]
ASGIApp = Callable[[Scope, Receive, Send], Awaitable[None]]


class Request:
    """Forward reference — defined in _request.py."""

    ...


class Response:
    """Forward reference — defined in _response.py."""

    ...


Handler = Callable[["Request"], Awaitable["Response"]]
Middleware = Callable[[Handler], Handler]


class RequestContext:
    """Forward reference — defined in _context.py."""

    ...


OnRequestStart = Callable[["RequestContext"], Awaitable[None]]
OnRequestEnd = Callable[["RequestContext", "Response"], Awaitable[None]]
OnRequestError = Callable[["RequestContext", Exception], Awaitable[None]]
ExceptionHandler = Callable[["Request", Exception], Awaitable["Response | None"]]


@runtime_checkable
class Plugin(Protocol):
    """
    Called once during app construction by .with_*(plugin).
    Plugins register their hooks and middleware here — they do
    not store a reference to the app.
    """

    def install(self, app: Any) -> None:
        """
        Register middleware and lifecycle hooks on the app.
        Called once. Must be idempotent.
        """
        ...
