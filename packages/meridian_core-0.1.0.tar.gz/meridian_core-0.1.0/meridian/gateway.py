import asyncio
import time
from typing import Any

import anyio

from .context import make_request_context, _set_request_context, _reset_request_context
from .exceptions import MeridianError, ServiceUnavailable
from .logger import get_logger
from .request import Request
from .response import Response, ErrorResponse
from .types import Scope, Receive, Send

logger = get_logger(__name__)


class Gateway:
    """
    The ASGI callable. Instantiated once per application.

    Parameters
    ----------
    handler:
        The middleware chain terminating in the router.
        Built by Meridian._build_handler() at startup.
    max_concurrent_requests:
        Backpressure limit. 0 means unlimited.
    request_deadline_ms:
        Per-request deadline. None means no deadline.
    on_request_start / on_request_end / on_request_error:
        Lifecycle hook lists.
    exception_handlers:
        Dict mapping exception types to custom handler callables.
        Handlers have signature: async def handler(request: Request, exc: Exception) -> Response | None
        If handler returns a Response, it's sent and fallback to default error handling is skipped.
        If handler returns None or raises, default error handling proceeds.
        Respects exception MRO for inheritance-based matching.
    """

    def __init__(
        self,
        handler: Any,
        max_concurrent_requests: int = 0,
        request_deadline_ms: int | None = None,
        on_request_start: list[Any] | None = None,
        on_request_end: list[Any] | None = None,
        on_request_error: list[Any] | None = None,
        on_startup: list[Any] | None = None,
        on_shutdown: list[Any] | None = None,
        drain_timeout_s: int | None = None,
        exception_handlers: dict[type[Exception], Any] | None = None,
    ) -> None:
        self._handler = handler
        self._max_concurrent_requests = max_concurrent_requests
        self.deadline_ms = request_deadline_ms
        self._hooks_start = on_request_start or []
        self._hooks_end = on_request_end or []
        self._hooks_error = on_request_error or []
        self._hooks_startup = on_startup or []
        self._hooks_shutdown = on_shutdown or []
        self._drain_timeout_s = drain_timeout_s
        self._exception_handlers = exception_handlers or {}
        self._stopping = False

        self._semaphore: asyncio.Semaphore | None = (
            asyncio.Semaphore(max_concurrent_requests)
            if max_concurrent_requests > 0
            else None
        )

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """ASGI entry point."""
        scope_type = scope.get("type")

        if scope_type == "lifespan":
            await self._handle_lifespan(scope, receive, send)
            return

        if scope_type != "http":
            return

        await self._handle_http(scope, receive, send)

    async def _handle_http(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Main HTTP request handling path."""

        if self._stopping:
            resp = ErrorResponse(
                {"detail": "Service is shutting down"}, 503, {"retry-after": "10"}
            )
            await resp.send(send)
            return

        if self._semaphore is not None:
            acquired = self._semaphore._value > 0
            if not acquired:
                err = ServiceUnavailable(retry_after=1)
                resp = ErrorResponse(
                    err.to_dict(), err.status_code, {"retry-after": "1"}
                )
                await resp.send(send)
                return

        request = Request(scope, receive)
        ctx = make_request_context(
            method=request.method,
            path=request.path,
            deadline_ms=self.deadline_ms,
        )
        ctx.extras["_request"] = request
        token = _set_request_context(ctx)

        try:
            if self._semaphore is not None:
                await self._semaphore.acquire()

            await self._dispatch(request, ctx, send)

        finally:
            if self._semaphore is not None:
                self._semaphore.release()
            _reset_request_context(token)

    def _find_exception_handler(self, exc: Exception) -> Any | None:
        """
        Find a custom exception handler for the given exception.
        Respects the MRO (method resolution order) to match parent exception types.
        Returns the handler if found, None otherwise.
        """
        # First try exact type match
        handler = self._exception_handlers.get(type(exc))
        if handler is not None:
            return handler

        # Then try parent classes via MRO
        for exc_type in type(exc).__mro__[1:]:
            if exc_type in self._exception_handlers:
                return self._exception_handlers[exc_type]

        return None

    async def _dispatch(
        self,
        request: Request,
        ctx: Any,
        send: Send,
    ) -> None:
        """
        Run lifecycle hooks + middleware chain inside a deadline.

        Uses anyio.CancelScope(deadline=...) which gives correct cancellation
        behaviour, propagating cancellation to child tasks correctly. This is
        important for M5 (agent streaming) and M10 (SSE).
        """
        response = None
        try:
            if self.deadline_ms is not None:
                deadline_at = anyio.current_time() + (self.deadline_ms / 1000)
                with anyio.CancelScope(deadline=deadline_at) as cancel_scope:
                    response = await self._run_hooks_and_handler(request, ctx)
                if cancel_scope.cancel_called:
                    raise TimeoutError("Request deadline exceeded")
            else:
                response = await self._run_hooks_and_handler(request, ctx)

            await response.send(send)

        except TimeoutError:
            resp = ErrorResponse(
                {"detail": "Request deadline exceeded"},
                503,
            )
            await resp.send(send)
            for hook in self._hooks_error:
                try:
                    await hook(ctx, TimeoutError("deadline exceeded"))
                except Exception:  # noqa
                    logger.exception("on_request_error hook failed")

        except MeridianError as e:
            # Try custom exception handler first
            custom_handler = self._find_exception_handler(e)
            if custom_handler is not None:
                try:
                    resp = await custom_handler(request, e)
                    if resp is not None:
                        await resp.send(send)
                        for hook in self._hooks_error:
                            try:
                                await hook(ctx, e)
                            except Exception:  # noqa
                                logger.exception("on_request_error hook failed")
                        return
                except Exception as handler_exc:  # noqa
                    logger.exception("Custom exception handler failed")

            # Fall back to default error handling
            extra_headers: dict[str, str] = {}
            if hasattr(e, "allowed") and e.allowed:
                extra_headers["allow"] = ", ".join(sorted(e.allowed))
            resp = ErrorResponse(e.to_dict(), e.status_code, extra_headers)
            await resp.send(send)
            for hook in self._hooks_error:
                try:
                    await hook(ctx, e)
                except Exception:  # noqa
                    logger.exception("on_request_error hook failed")

        except Exception as e:
            from .exceptions import ResponseValidationError

            # Try custom exception handler first
            custom_handler = self._find_exception_handler(e)
            if custom_handler is not None:
                try:
                    resp = await custom_handler(request, e)
                    if resp is not None:
                        await resp.send(send)
                        for hook in self._hooks_error:
                            try:
                                await hook(ctx, e)
                            except Exception:  # noqa
                                logger.exception("on_request_error hook failed")
                        return
                except Exception as handler_exc:  # noqa
                    logger.exception("Custom exception handler failed")

            # Fall back to default error handling
            if isinstance(e, ResponseValidationError):
                resp = ErrorResponse(e.detail, 500)
                await resp.send(send)
                for hook in self._hooks_error:
                    try:
                        await hook(ctx, e)
                    except Exception:  # noqa
                        logger.exception("on_request_error hook failed")
            else:
                resp = ErrorResponse({"detail": "Internal server error"}, 500)
                await resp.send(send)
                for hook in self._hooks_error:
                    try:
                        await hook(ctx, e)
                    except Exception:  # noqa
                        logger.exception("on_request_error hook failed")
                raise

    async def _run_hooks_and_handler(
        self,
        request: Request,
        ctx: Any,
    ) -> Response:
        """Fire on_request_start hooks, run handler, fire on_request_end hooks."""

        for hook in self._hooks_start:
            try:
                await hook(ctx)
            except Exception:  # noqa
                logger.exception("on_request_start hook failed")

        response = await self._handler(request)

        for hook in self._hooks_end:
            try:
                await hook(ctx, response)
            except Exception:  # noqa
                logger.exception("on_request_end hook failed")

        return response

    async def _handle_lifespan(
        self, scope: Scope, receive: Receive, send: Send
    ) -> None:
        """
        Handle ASGI lifespan events (startup / shutdown).
        Startup fails fast, shutdown collects errors and respects drain timeout.
        """
        while True:
            message = await receive()
            msg_type = message.get("type")

            if msg_type == "lifespan.startup":
                try:
                    for hook in self._hooks_startup:
                        await hook()
                    await send({"type": "lifespan.startup.complete"})
                except Exception as e:
                    await send(
                        {
                            "type": "lifespan.startup.failed",
                            "message": str(e),
                        }
                    )
                    raise

            elif msg_type == "lifespan.shutdown":
                self._stopping = True
                errors: list[Exception] = []

                async def run_shutdown_hooks() -> None:
                    if self._semaphore is not None:
                        start_wait = time.monotonic()
                        while self._semaphore._value < self._max_concurrent_requests:
                            if time.monotonic() - start_wait > self._drain_timeout_s:
                                break
                            await asyncio.sleep(0.1)

                    for _hook in self._hooks_shutdown:
                        try:
                            await _hook()
                        except Exception as e:  # noqa
                            errors.append(e)

                try:
                    if self._drain_timeout_s is not None:
                        async with asyncio.timeout(self._drain_timeout_s):
                            await run_shutdown_hooks()
                    else:
                        await run_shutdown_hooks()
                except TimeoutError as e:
                    errors.append(e)
                except Exception:  # noqa
                    pass
                finally:
                    self._stopping = False

                if errors:
                    await send(
                        {
                            "type": "lifespan.shutdown.failed",
                            "message": f"Shutdown completed with {len(errors)} error(s): {errors[0]}",
                        }
                    )
                    raise RuntimeError("Shutdown hooks failed") from errors[0]

                await send({"type": "lifespan.shutdown.complete"})
                return
