import inspect
from typing import Any, get_args, get_origin, get_type_hints, Union

from .config import ValidationConfig


class ResponseValidator:
    """
    Pre-built response validation plan for a handler's return type.

    Built ONCE at route registration via ResponseValidator.build(handler, validation).
    Executed ONCE per request via validator.validate(data) after handler executes.

    Validates that the handler's return value matches its annotated return type
    when validation mode is "strict".
    """

    def __init__(
        self,
        return_type: Any,
        validation_mode: str,
    ) -> None:
        """
        Initialize response validator.

        Parameters
        ----------
        return_type : Any
            The handler's return type annotation (from get_type_hints)
        validation_mode : str
            Validation mode: "strict" (validate), "passthrough" (log only)
        """
        self.return_type = return_type
        self.validation_mode = validation_mode

    @classmethod
    def build(cls, handler: Any, validation: ValidationConfig) -> "ResponseValidator":
        """
        Inspect handler's return type annotation and build the validator.

        Called at @app.get() / @app.post() decoration time.

        Parameters
        ----------
        handler : Callable
            The route handler function
        validation : ValidationConfig
            Validation configuration with mode and other settings

        Returns
        -------
        ResponseValidator
            Built validator (or NullResponseValidator if no validation needed)
        """
        if not validation.validate_responses or validation.mode == "passthrough":
            return NullResponseValidator()

        try:
            hints = get_type_hints(handler, include_extras=True)
        except Exception:  # noqa
            hints = getattr(handler, "__annotations__", {})

        return_type = hints.get("return", inspect.Parameter.empty)

        if return_type is inspect.Parameter.empty:
            return NullResponseValidator()

        return cls(return_type, validation.mode)

    async def validate(self, data: Any) -> None:
        """
        Validate response data matches the handler's return type.

        Raises ResponseValidationError if validation fails in strict mode.

        Parameters
        ----------
        data : Any
            The raw data from handler (before wrapping in Response)

        Raises
        ------
        ResponseValidationError
            If data doesn't match return type in strict mode
        """
        from .exceptions import ResponseValidationError

        if self.validation_mode != "strict":
            return

        if data is None:
            self._validate_none()
            return

        errors = self._collect_validation_errors(data)
        if errors:
            raise ResponseValidationError(errors=errors)

    def _validate_none(self) -> None:
        """Check if None is allowed by return type."""
        from .exceptions import ResponseValidationError

        if self.return_type is None or self.return_type is type(None):
            return

        origin = get_origin(self.return_type)
        if origin is Union:
            args = get_args(self.return_type)
            if type(None) in args:
                return

        raise ResponseValidationError(
            errors=[
                {
                    "field": "return",
                    "source": "response",
                    "message": f"Handler returned None but return type is {self.return_type}",
                }
            ]
        )

    def _collect_validation_errors(self, data: Any) -> list[dict[str, Any]]:
        """
        Collect all validation errors for response data.

        Returns list of error dicts (empty if valid).
        """
        errors = []

        if not self._is_type_match(data, self.return_type):
            errors.append(
                {
                    "field": "return",
                    "source": "response",
                    "message": f"Expected {self.return_type}, got {type(data).__name__}",
                }
            )
            return errors

        if hasattr(data, "model_dump"):
            pydantic_errors = self._validate_pydantic(data)
            errors.extend(pydantic_errors)

        elif isinstance(data, dict) and get_origin(self.return_type) is dict:
            dict_errors = self._validate_dict(data)
            errors.extend(dict_errors)

        elif isinstance(data, list) and get_origin(self.return_type) is list:
            list_errors = self._validate_list(data)
            errors.extend(list_errors)

        return errors

    def _is_type_match(self, data: Any, expected_type: Any) -> bool:
        """Check if data matches expected type (shallow check)."""
        if expected_type is Any:
            return True

        origin = get_origin(expected_type)

        if origin is None and isinstance(expected_type, type):
            try:
                from .response import Response  # noqa

                if isinstance(data, Response):
                    return True
            except ImportError:
                pass

        if origin is Union:
            args = get_args(expected_type)
            return any(self._is_type_match(data, arg) for arg in args)

        if origin is dict:
            return isinstance(data, dict)

        if origin is list:
            return isinstance(data, list)

        if hasattr(expected_type, "model_dump"):
            return isinstance(data, expected_type)

        if hasattr(expected_type, "__dataclass_fields__"):
            return isinstance(data, expected_type)

        if origin is None and isinstance(expected_type, type):
            return isinstance(data, expected_type)

        return True

    def _validate_pydantic(self, data: Any) -> list[dict[str, Any]]:
        """Validate Pydantic model instance."""
        errors = []
        target_type = self.return_type

        origin = get_origin(target_type)
        if origin is Union:
            matched_arg = None
            for arg in get_args(target_type):
                if isinstance(data, arg):
                    matched_arg = arg
                    break
            if matched_arg:
                target_type = matched_arg
            else:
                return errors

        if not hasattr(target_type, "model_validate"):
            return errors

        if isinstance(data, target_type):
            return errors

        try:
            target_type.model_validate(
                data.model_dump() if hasattr(data, "model_dump") else data
            )
        except Exception as e:
            errors.append(
                {
                    "field": "return",
                    "source": "response",
                    "message": f"Pydantic validation failed: {str(e)}",
                }
            )

        return errors

    def _validate_dict(self, data: dict[str, Any]) -> list[dict[str, Any]]:
        """Validate dict against dict[K, V] type hint."""
        errors = []
        args = get_args(self.return_type)

        if len(args) < 2:
            return errors

        key_type, value_type = args[0], args[1]

        for k, v in data.items():
            if not self._is_type_match(k, key_type):
                errors.append(
                    {
                        "field": f"return.keys",
                        "source": "response",
                        "message": f"Dict key {k!r} doesn't match type {key_type}",
                    }
                )
            if not self._is_type_match(v, value_type):
                errors.append(
                    {
                        "field": f"return[{k}]",
                        "source": "response",
                        "message": f"Dict value doesn't match type {value_type}",
                    }
                )

        return errors

    def _validate_list(self, data: list[Any]) -> list[dict[str, Any]]:
        """Validate list against list[T] type hint."""
        errors = []
        args = get_args(self.return_type)

        if not args:
            return errors

        item_type = args[0]

        for i, item in enumerate(data):
            if not self._is_type_match(item, item_type):
                errors.append(
                    {
                        "field": f"return[{i}]",
                        "source": "response",
                        "message": f"List item doesn't match type {item_type}",
                    }
                )

        return errors


class NullResponseValidator(ResponseValidator):
    """
    No-op validator. Used when validation is disabled or can't build a real validator.
    """

    def __init__(self) -> None:
        super().__init__(Any, "passthrough")

    async def validate(self, data: Any) -> None:
        """No validation."""
        pass
