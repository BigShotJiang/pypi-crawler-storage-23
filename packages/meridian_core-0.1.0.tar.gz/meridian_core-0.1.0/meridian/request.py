import json
from typing import Any, AsyncIterator
from urllib.parse import parse_qs

import anyio

from .exceptions import ClientDisconnectError
from .types import Scope, Receive


class Headers:
    """Case-insensitive header access. Keys normalised to lowercase."""

    def __init__(self, raw: list[tuple[bytes, bytes]]) -> None:
        self._data: dict[str, list[str]] = {}
        for k, v in raw:
            key = k.decode().lower()
            val = v.decode()
            if key in self._data:
                self._data[key].append(val)
            else:
                self._data[key] = [val]

    def get(self, key: str, default: str | None = None) -> str | None:
        values = self._data.get(key.lower())
        return values[0] if values else default

    def get_all(self, key: str) -> list[str]:
        return self._data.get(key.lower(), [])

    def __contains__(self, key: str) -> bool:
        return key.lower() in self._data

    def __getitem__(self, key: str) -> str:
        value = self.get(key)
        if value is None:
            raise KeyError(key)
        return value

    def items(self) -> list[tuple[str, str]]:
        result = []
        for k, vs in self._data.items():
            for v in vs:
                result.append((k, v))
        return result


class QueryParams:
    """Parsed query string. Multi-value keys supported."""

    def __init__(self, query_string: bytes) -> None:
        raw = parse_qs(query_string.decode(), keep_blank_values=True)
        self._data: dict[str, list[str]] = raw

    def get(self, key: str, default: str | None = None) -> str | None:
        values = self._data.get(key)
        return values[0] if values else default

    def get_all(self, key: str) -> list[str]:
        return self._data.get(key, [])

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def keys(self) -> list[str]:
        """Return all query parameter keys."""
        return list(self._data.keys())


class Cookies:
    """Parsed Cookie header."""

    def __init__(self, cookie_header: str | None) -> None:
        self._data: dict[str, str] = {}
        if cookie_header:
            for part in cookie_header.split(";"):
                if "=" in part:
                    k, v = part.strip().split("=", 1)
                    self._data[k] = v

    def get(self, key: str, default: str | None = None) -> str | None:
        return self._data.get(key, default)

    def __contains__(self, key: str) -> bool:
        return key in self._data


class Request:
    """
    Wraps the ASGI scope for a single HTTP request.

    Instantiated by the Gateway once per request. Passed through
    the middleware chain and into extractors.
    """

    __slots__ = (
        "_scope",
        "_receive",
        "_body_cache",
        "_body_consumed",
        "_headers",
        "_query_params",
        "_cookies",
        "path_params",
        "_is_disconnected",
    )

    def __init__(self, scope: Scope, receive: Receive) -> None:
        self._scope = scope
        self._receive = receive

        self._body_cache: bytes | None = None
        self._body_consumed: bool = False
        self._is_disconnected: bool = False

        self._headers: Headers | None = None
        self._query_params: QueryParams | None = None
        self._cookies: Cookies | None = None
        self.path_params: dict[str, str] = {}

    @property
    def headers(self) -> Headers:
        if self._headers is None:
            self._headers = Headers(self._scope.get("headers", []))
        return self._headers

    @property
    def query_params(self) -> QueryParams:
        if self._query_params is None:
            self._query_params = QueryParams(self._scope.get("query_string", b""))
        return self._query_params

    @property
    def cookies(self) -> Cookies:
        if self._cookies is None:
            self._cookies = Cookies(self.headers.get("cookie"))
        return self._cookies

    @property
    def method(self) -> str:
        return self._scope["method"].upper()

    @property
    def path(self) -> str:
        return self._scope["path"]

    @property
    def scope(self) -> Scope:
        """Raw ASGI scope. Avoid using this in application code."""
        return self._scope

    async def body(self) -> bytes:
        """
        Read and cache the full request body.

        Safe to call multiple times — returns the cache after first read.
        Do NOT call after stream() — stream() consumes receive() directly.
        """
        if self._body_cache is not None:
            return self._body_cache

        if self._body_consumed:
            return b""

        chunks: list[bytes] = []
        while True:
            message = await self._receive()
            chunk = message.get("body", b"")
            if chunk:
                chunks.append(chunk)
            if not message.get("more_body", False):
                break

        self._body_cache = b"".join(chunks)
        return self._body_cache

    async def json(self) -> Any:
        """Read body and parse as JSON."""
        raw = await self.body()
        return json.loads(raw)

    async def stream(self) -> AsyncIterator[bytes]:
        """
        Stream the request body. Respects M1 disconnect signals.
        """
        self._body_consumed = True
        while True:
            message = await self._receive()
            if message["type"] == "http.disconnect":
                self._is_disconnected = True
                raise ClientDisconnectError("Client disconnected during body stream")

            chunk = message.get("body", b"")
            if chunk:
                yield chunk
            if not message.get("more_body", False):
                break

    async def is_disconnected(self) -> bool:
        """
        Poll the receive channel for a disconnect message without blocking.
        """
        if not self._is_disconnected:
            with anyio.MoveOnAfter(0):
                message = await self._receive()
                if message.get("type") == "http.disconnect":
                    self._is_disconnected = True

        return self._is_disconnected

    def __repr__(self) -> str:
        return f"<Request {self.method} {self.path}>"
