from typing import Callable

from .types import Handler, Middleware


class MiddlewareChain:
    """
    The composed middleware chain.

    Built once at app startup. callable as a Handler.
    Logs its composition order on first call to describe().
    """

    def __init__(
        self,
        middlewares: list[Middleware],
        inner: Handler,
    ) -> None:
        self._middlewares = middlewares
        self._inner = inner
        self._handler = _compose(middlewares, inner)

    async def __call__(self, request: object) -> object:
        return await self._handler(request)  # type: ignore[arg-type]

    def describe(self) -> list[str]:
        """
        Returns the chain as an ordered list of names for startup logging.
        Outermost first.
        """
        names = []
        for mw in self._middlewares:
            name = getattr(mw, "__name__", None) or type(mw).__name__
            names.append(name)
        names.append("router")
        return names


def _compose(middlewares: list[Middleware], inner: Handler) -> Handler:
    """
    Build the composed handler by folding right-to-left.

    reduce right: mw[-1](mw[-2](...mw[0](inner)...))

    With [logging, cors, auth] and inner=router:
        Step 1: auth(router)             → auth_wrapped
        Step 2: cors(auth_wrapped)       → cors_wrapped
        Step 3: logging(cors_wrapped)    → final handler
    """
    handler = inner
    for mw in reversed(middlewares):
        handler = mw(handler)
    return handler


def middleware(fn: Callable) -> Middleware:
    """
    Decorator that converts a two-argument async function into
    a standard one-argument Middleware.

    Usage:
        @middleware
        async def log_requests(request, next_handler):
            print(f"→ {request.method} {request.path}")
            response = await next_handler(request)
            print(f"← {response.status_code}")
            return response
    """

    def wrapper(next_handler: Handler) -> Handler:
        async def handler(request: object) -> object:
            return await fn(request, next_handler)

        handler.__name__ = fn.__name__
        return handler  # type: ignore[return-value]

    wrapper.__name__ = fn.__name__
    return wrapper
