//
// Created by Richard Cloete on 9/1/22.
//

//#include "digest2.h"

#ifndef MPCDEV_DIGEST2_COMMON_H
#define MPCDEV_DIGEST2_COMMON_H

#endif //MPCDEV_DIGEST2_COMMON_H


int parseCod3(char *cod3);
double mustStrtod(char *str);
int mustStrtoi(char *str);

double updateMagnitude(char band, double mag);