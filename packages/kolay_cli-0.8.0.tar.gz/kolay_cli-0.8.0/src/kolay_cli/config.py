from __future__ import annotations
import json
import os
from pathlib import Path
from typing import Any

try:
    import yaml
    _HAS_YAML = True
except ImportError:
    _HAS_YAML = False

CONFIG_DIR = Path.home() / ".config" / "kolay"
CONFIG_FILE_JSON = CONFIG_DIR / "config.json"
CONFIG_FILE_YAML = CONFIG_DIR / "config.yaml"


class Config:
    """Centralized configuration manager for kolay-cli.

    Handles values from environment variables, YAML config, or JSON config.
    Falls back to JSON-only when PyYAML is not installed.
    """

    def __init__(self) -> None:
        """Initialize and load current configuration."""
        self._data: dict[str, Any] = self._load()

    def _load(self) -> dict[str, Any]:
        """Load configuration from files, preferring YAML over JSON."""
        data: dict[str, Any] = {}

        # 1. Load JSON if it exists
        if CONFIG_FILE_JSON.exists():
            try:
                with open(CONFIG_FILE_JSON, "r", encoding="utf-8") as f:
                    data.update(json.load(f))
            except (json.JSONDecodeError, OSError):
                pass

        # 2. Load YAML if it exists and PyYAML is available (takes precedence)
        if _HAS_YAML and CONFIG_FILE_YAML.exists():
            try:
                with open(CONFIG_FILE_YAML, "r", encoding="utf-8") as f:
                    yaml_data = yaml.safe_load(f)
                    if isinstance(yaml_data, dict):
                        data.update(yaml_data)
            except (yaml.YAMLError, OSError):
                pass

        return data

    def get(self, key: str, default: Any = None) -> Any:
        """Get a configuration value with environment variable precedence.

        Args:
            key: The configuration key (e.g., 'api_token').
            default: Value to return if key is not found anywhere.

        Returns:
            The configuration value.
        """
        # Environment variables take highest precedence (KOLAY_API_TOKEN etc.)
        env_val = os.getenv(f"KOLAY_{key.upper()}")
        if env_val is not None:
            return env_val

        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """Set a configuration value and persist to disk.

        Saves as YAML when PyYAML is available, otherwise falls back to JSON.
        Ensures the config directory exists and file permissions are restricted (0o600).

        Args:
            key: The configuration key.
            value: The value to set.
        """
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        self._data[key] = value

        if _HAS_YAML:
            target = CONFIG_FILE_YAML
            fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                yaml.dump(self._data, f, default_flow_style=False)
        else:
            target = CONFIG_FILE_JSON
            fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2)

    @property
    def api_token(self) -> str | None:
        """The API token from environment or config file."""
        return self.get("api_token")

    @property
    def base_url(self) -> str:
        """The Kolay API base URL."""
        url = self.get("base_url") or "https://api.kolayik.com"
        # Basic validation
        if not url.startswith("https://"):
            # We don't raise here to allow the client to catch it or the user to fix it
            pass
        return str(url)


# Global instance for easy access
_config_instance = Config()


def get_api_token() -> str | None:
    """Shortcut to get the API token."""
    return _config_instance.api_token


def get_base_url() -> str:
    """Shortcut to get the base URL."""
    return _config_instance.base_url


def set_config_value(key: str, value: Any) -> None:
    """Shortcut to set a configuration value."""
    _config_instance.set(key, value)


def get_config_value(key: str, default: Any = None) -> Any:
    """Shortcut to get any configuration value."""
    return _config_instance.get(key, default)
