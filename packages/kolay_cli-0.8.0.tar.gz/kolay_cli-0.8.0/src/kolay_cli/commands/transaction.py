from __future__ import annotations
from typing import Any
import typer
from rich.table import Table
from rich.panel import Panel
from datetime import datetime

from ..api import KolayClient, safe_id
from ..ui import (
    console, short_id, display_status, fmt_num,
    print_success, print_empty, kv_table,
    pick_person, pick_transaction, api_call, no_command_help, PRIMARY,
)

app = typer.Typer(help="Manage financial transactions (expenses, bonuses, advances).")


@app.callback(invoke_without_command=True)
def _hint(ctx: typer.Context) -> None:
    no_command_help(ctx)


TRANSACTION_TYPES = [
    "expense", "advancePayment", "bonus", "premium", "otherCut",
    "militaryBenefit", "nationalHolidayBenefit", "fuelAllowanceBenefit",
]


@app.command(name="list")
def list_transactions(
    page: int = typer.Option(1, help="Page number"),
    person_id: str | None = typer.Option(None, "--person-id", "-p", help="Filter by person ID"),
    type: str | None = typer.Option(None, "--type", "-t", help="Filter by type (expense, bonus, etc.)"),
    status: str | None = typer.Option(None, "--status", help="Filter by status (waiting, approved)"),
    limit: int = typer.Option(20, help="Number of records to return"),
) -> None:
    """List financial transactions. Filterable by person, type, or approval status."""
    now = datetime.now()
    payload: dict[str, Any] = {
        "page": page, "limit": limit,
        "startDate": f"{now.year}-01-01 00:00:00",
        "endDate": f"{now.year}-12-31 23:59:59",
    }
    if person_id:
        payload["personId"] = person_id
    if type:
        payload["type"] = type
    if status:
        payload["status"] = status

    with api_call("Fetching transactions..."):
        client = KolayClient()
        response = client.post("v2/transaction/list", data=payload)

    data = response.get("data", {})
    items = data.get("items", []) if isinstance(data, dict) else []
    total = data.get("totalCount", 0) if isinstance(data, dict) else len(items)

    if not items:
        print_empty("transactions")
        return

    console.print(f"\n[bold {PRIMARY}]💸 Transactions[/bold {PRIMARY}] [grey62]({len(items)}/{total})[/grey62]\n")
    table = Table(header_style=f"bold {PRIMARY}", border_style=PRIMARY, box=None, show_edge=False)
    table.add_column("#", style="grey62", justify="right", width=4)
    table.add_column("Employee", style="bold white", min_width=18)
    table.add_column("Type", style="grey85")
    table.add_column("Amount", justify="right", style="bold white")
    table.add_column("Status", justify="center")
    table.add_column("Short ID", style="grey62")

    for i, trx in enumerate(items, 1):
        p = trx.get("person", {})
        pname = f"{p.get('firstName', '')} {p.get('lastName', '')}".strip() if isinstance(p, dict) else "—"
        amt = trx.get("amount") or trx.get("totalAmount") or "—"
        curr = trx.get("currency", "")
        amt_str = f"{fmt_num(amt)} {curr}".strip()
        table.add_row(
            str(i + (page - 1) * limit), pname,
            str(trx.get("type", "—")), amt_str,
            display_status(str(trx.get("status", ""))),
            short_id(str(trx.get("id", "")))
        )

    console.print(table)
    console.print()


@app.command(name="view")
def view_transaction(transaction_id: str | None = typer.Argument(None, help="ID of the transaction")) -> None:
    """View full details and notes of a specific transaction."""
    if not transaction_id:
        transaction_id = pick_transaction()

    with api_call("Fetching transaction details..."):
        client = KolayClient()
        response = client.get(f"v2/transaction/view/{safe_id(transaction_id)}")

    data = response.get("data", {})
    p = data.get("person", {})
    pname = f"{p.get('firstName', '')} {p.get('lastName', '')}".strip() if isinstance(p, dict) else "Unknown"
    console.print(f"\n[bold {PRIMARY}]💸 Transaction[/bold {PRIMARY}] [bold white]{pname}[/bold white] — {data.get('type', 'Record')}")
    console.print(f"  {display_status(str(data.get('status', '')))}\n")
    console.print(Panel(kv_table(data, exclude=["id", "person", "type", "status", "personId"]), border_style=PRIMARY, expand=False))
    console.print()


@app.command(name="create")
def create_transaction(
    person_id: str | None = typer.Option(None, "--person-id", "-p", help="ID of the person"),
    type: str | None = typer.Option(None, "--type", "-t", help="Type (expense, bonus, etc.)"),
    amount: float | None = typer.Option(None, "--amount", help="Total amount"),
    currency: str = typer.Option("TL", "--currency", help="Currency code"),
    date: str | None = typer.Option(None, "--date", help="Date (YYYY-MM-DD)"),
    description: str | None = typer.Option(None, "--desc", help="Optional description"),
) -> None:
    """Create a new financial transaction (bonus, cut, or expense)."""
    console.print(f"\n[bold {PRIMARY}]💸 New Transaction[/bold {PRIMARY}]\n")

    if not person_id:
        person_id = pick_person()
    if not type:
        console.print("  [bold white]Types:[/bold white] " + ", ".join(TRANSACTION_TYPES))
        type = typer.prompt("  Pick a type", default="expense")
    if amount is None:
        amount = float(typer.prompt("  Amount"))
    if not date:
        date = typer.prompt("  Date (YYYY-MM-DD)", default=datetime.now().strftime("%Y-%m-%d"))

    payload: dict[str, Any] = {
        "personId": safe_id(person_id), "type": type,
        "amount": amount, "currency": currency,
        "date": date, "description": description or "",
    }

    with api_call("Submitting transaction..."):
        client = KolayClient()
        client.post("v2/transaction/create", data=payload)

    print_success("Transaction created successfully.")


@app.command(name="delete")
def delete_transaction(transaction_id: str | None = typer.Argument(None, help="ID of the transaction")) -> None:
    """Permanently delete a transaction record."""
    if not transaction_id:
        transaction_id = pick_transaction()

    typer.confirm("  Delete this transaction?", abort=True)

    with api_call("Deleting transaction..."):
        client = KolayClient()
        client.delete(f"v2/transaction/delete/{safe_id(transaction_id)}")

    print_success("Transaction deleted successfully.")
