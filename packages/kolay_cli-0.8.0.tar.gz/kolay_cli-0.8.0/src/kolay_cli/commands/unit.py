from __future__ import annotations
from typing import Any
import typer
from rich.table import Table
from rich.tree import Tree

from ..api import KolayClient, APIError, safe_id
from ..ui import (
    console, short_id, print_success, print_empty,
    api_call, no_command_help, PRIMARY,
)

app = typer.Typer(help="Manage organisational units (departments, locations, etc.) in Kolay.")


@app.callback(invoke_without_command=True)
def _hint(ctx: typer.Context) -> None:
    no_command_help(ctx)


def _render_unit_tree(node: dict, tree: Tree) -> None:
    """Recursively render a unit node and its children into a Rich Tree.
    
    Args:
        node: The dictionary representing a unit or item node.
        tree: The parent Tree object to add branches to.
    """
    node_name = node.get("name", "—")
    node_id = str(node.get("id", ""))
    
    # Unit types are usually bold and white, items are steel blue
    is_leaf = "children" not in node and "items" not in node
    label = f"[steel_blue1]{node_name}[/steel_blue1]" if is_leaf else f"[bold white]{node_name}[/bold white]"
    
    branch = tree.add(f"{label} [grey62]{short_id(node_id)}[/grey62]")
    
    # Process nested items (leaves)
    for item in (node.get("items") or []):
        i_name = item.get("name", "—")
        i_id = str(item.get("id", ""))
        branch.add(f"[steel_blue1]{i_name}[/steel_blue1] [grey62]{short_id(i_id)}[/grey62]")
    
    # Process child units (branches)
    for child in (node.get("children") or []):
        _render_unit_tree(child, branch)


@app.command(name="tree")
def show_unit_tree() -> None:
    """Show the full organisational unit tree (departments, locations, teams, etc.)."""
    with api_call("Fetching unit tree..."):
        client = KolayClient()
        response = client.get("v2/unit/show-unit-tree")

    data = response.get("data", [])
    if not data:
        print_empty("organisational units")
        return

    console.print(f"\n[bold {PRIMARY}]🏢 Organisational Unit Tree[/bold {PRIMARY}]\n")
    root = Tree(f"[bold {PRIMARY}]Company[/bold {PRIMARY}]")
        
    # Data can be a single dict or a list
    nodes = data if isinstance(data, list) else [data]
    for node in nodes:
        _render_unit_tree(node, root)

    console.print(root)
    console.print()


@app.command(name="create-item")
def create_unit_item(
    unit_id: str | None = typer.Option(None, "--unit-id", help="ID of the unit to add the item to"),
    unit_name: str | None = typer.Option(None, "--unit-name", help="Name of the unit (e.g., Location)"),
    description: str | None = typer.Option(None, "--desc", help="Description of the new item"),
    item_name: str | None = typer.Option(None, "--name", "-n", help="Name of the new item (e.g., Amsterdam)"),
) -> None:
    """Create a new item inside an organisational unit.
    
    If no ID or names are provided, fetches the tree and lets you pick.
    """
    console.print(f"\n[bold {PRIMARY}]🏢 Create Unit Item[/bold {PRIMARY}]\n")

    client = KolayClient()

    if not unit_id or not unit_name:
        with api_call("Fetching unit tree..."):
            resp = client.get("v2/unit/show-unit-tree")
        tree_data = resp.get("data", [])
        units_flat: list[dict[str, str]] = []

        def _collect(node: dict) -> None:
            nid = str(node.get("id", ""))
            if nid:
                units_flat.append({"id": nid, "name": node.get("name", "—")})
            for child in (node.get("children") or []):
                _collect(child)

        for n in (tree_data if isinstance(tree_data, list) else [tree_data]):
            _collect(n)

        if not units_flat:
            from ..ui import print_error
            print_error("No organisational units found.", hint="Define units in Kolay first.")
            return

        console.print(f"[bold white]  Pick a unit:[/bold white]\n")
        tbl = Table(header_style=f"bold {PRIMARY}", border_style=PRIMARY, box=None, show_edge=False)
        tbl.add_column("#", style="grey62", justify="right", width=4)
        tbl.add_column("Unit Name", style="bold white", min_width=22)
        tbl.add_column("Short ID", style="grey62")
        for i, u in enumerate(units_flat, 1):
            tbl.add_row(str(i), u["name"], short_id(u["id"]))
        console.print(tbl)
        console.print()

        raw = typer.prompt("  Pick a unit (# or ID)")
        try:
            idx = int(raw) - 1
            if 0 <= idx < len(units_flat):
                unit_id, unit_name = units_flat[idx]["id"], units_flat[idx]["name"]
                console.print(f"  [{PRIMARY}]→ Adding to [bold]{unit_name}[/bold][/{PRIMARY}]\n")
            else:
                unit_id = raw
        except ValueError:
            unit_id = raw

        if not unit_name:
            unit_name = typer.prompt("  Confirm unit name (e.g. Location)")

    if not item_name:
        item_name = typer.prompt(f"  New item name for '{unit_name}'")

    payload: dict[str, Any] = {
        "unitId": safe_id(unit_id),
        "unitName": unit_name,
        "unitItemName": item_name,
    }
    if description:
        payload["description"] = description

    with api_call(f"Adding '{item_name}' to {unit_name}..."):
        client.post("v2/unit/create-unit-item", data=payload)

    print_success(f"'{item_name}' added to {unit_name} successfully.")

