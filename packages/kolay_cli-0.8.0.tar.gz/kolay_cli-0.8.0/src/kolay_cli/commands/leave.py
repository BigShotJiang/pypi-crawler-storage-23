from __future__ import annotations
from typing import Any
import typer
from rich.table import Table
from rich.panel import Panel
from datetime import datetime

from ..api import KolayClient, safe_id
from ..ui import (
    console, short_id, display_status, print_success, print_empty, kv_table,
    pick_person, pick_leave, api_call, no_command_help, PRIMARY, SUCCESS,
)

app = typer.Typer(help="Manage leave records in Kolay.")


@app.callback(invoke_without_command=True)
def _hint(ctx: typer.Context) -> None:
    no_command_help(ctx)


@app.command(name="list")
def list_leaves(
    status: str = typer.Option("approved", help="Filter: approved, waiting, rejected, cancelled"),
    start: str | None = typer.Option(None, "--start", help="Start date (YYYY-MM-DD)"),
    end: str | None = typer.Option(None, "--end", help="End date (YYYY-MM-DD)"),
    person_id: str | None = typer.Option(None, "--person-id", "-p", help="Filter by person ID"),
    limit: int = typer.Option(50, help="Max records to return"),
) -> None:
    """List leave records. Defaults to approved leaves within the current year."""
    now = datetime.now()
    params: dict[str, Any] = {
        "status": status,
        "startDate": start or f"{now.year}-01-01 00:00:00",
        "endDate": end or f"{now.year}-12-31 23:59:59",
        "limit": limit,
    }
    if person_id:
        params["personId"] = person_id

    with api_call(f"Fetching {status} leave records..."):
        client = KolayClient()
        response = client.get("v2/leave/list", params=params)

    data = response.get("data", [])
    if not data:
        print_empty(f"{status} leave records")
        return

    console.print(f"\n[bold {PRIMARY}]🏖️ {status.title()} Leave Records[/bold {PRIMARY}]\n")
    table = Table(header_style=f"bold {PRIMARY}", border_style=PRIMARY, box=None, show_edge=False)
    table.add_column("#", style="grey62", justify="right", width=4)
    table.add_column("Employee", style="bold white", min_width=18)
    table.add_column("Type", style="grey85")
    table.add_column("Start", style="grey62")
    table.add_column("End", style="grey62")
    table.add_column("Short ID", style="grey62")

    for i, lv in enumerate(data, 1):
        p = lv.get("person", {})
        ltype = lv.get("leaveType", {})
        table.add_row(
            str(i),
            p.get("name") or "—",
            ltype.get("name") or "—",
            (lv.get("startDate") or "—")[:10],
            (lv.get("endDate") or "—")[:10],
            short_id(str(lv.get("id", "")))
        )

    console.print(table)
    console.print()


@app.command(name="view")
def view_leave(leave_id: str | None = typer.Argument(None, help="ID of the leave record")) -> None:
    """View full details and workflow status of an individual leave record."""
    if not leave_id:
        leave_id = pick_leave()

    with api_call("Fetching leave details..."):
        client = KolayClient()
        response = client.get(f"v2/leave/view/{safe_id(leave_id)}")

    data = response.get("data", {})
    p = data.get("person", {})
    ltype = data.get("leaveType", {})
    console.print(f"\n[bold {PRIMARY}]🏖️ Leave Record[/bold {PRIMARY}] [bold white]{p.get('name', 'Unknown')}[/bold white] — {ltype.get('name', 'Leave')}")
    console.print(f"  {display_status(str(data.get('status', '')))}\n")
    console.print(Panel(kv_table(data, exclude=["id", "person", "leaveType", "status", "personId", "leaveTypeId"]), border_style=PRIMARY, expand=False))
    console.print()


@app.command(name="create")
def create_leave(
    person_id: str | None = typer.Option(None, "--person-id", "-p", help="Person ID to create leave for"),
    leave_type_id: str | None = typer.Option(None, "--type-id", "-t", help="Leave type ID"),
    start_date: str | None = typer.Option(None, "--start", help="Start date (YYYY-MM-DD)"),
    end_date: str | None = typer.Option(None, "--end", help="End date (YYYY-MM-DD)"),
    comment: str | None = typer.Option(None, "--comment", "-c", help="Optional comment"),
) -> None:
    """Create a new leave request. Prompts for missing details interactively."""
    console.print(f"\n[bold {PRIMARY}]🏖️ Create Leave Request[/bold {PRIMARY}]\n")

    if not person_id:
        person_id = pick_person()

    with api_call("Fetching available leave types..."):
        client = KolayClient()
        if not leave_type_id:
            resp_types = client.get(f"v2/person/leave-status/{safe_id(person_id)}")
            types = resp_types.get("data", [])
        else:
            types = []

    if not leave_type_id:
        if not types:
            from ..ui import print_error
            print_error("This employee has no leave types assigned.")
            return
        console.print(f"\n  [bold white]Available Leave Types:[/bold white]")
        for i, t in enumerate(types, 1):
            l_obj = t.get("leaveType", {})
            console.print(f"  [{PRIMARY}]{i}[/{PRIMARY}]: {l_obj.get('name')}  [grey62]({t.get('unused', 0)} days left)[/grey62]")
        try:
            idx = int(typer.prompt("\n  Pick a leave type (#)", default="1")) - 1
            leave_type_id = str(types[idx].get("leaveTypeId", ""))
        except (ValueError, IndexError):
            from ..ui import print_error
            print_error("Invalid selection.")
            return

    if not start_date:
        start_date = typer.prompt("  Start date", default=datetime.now().strftime("%Y-%m-%d"))
    if len(start_date) == 10:
        start_date += " 09:00:00"

    if not end_date:
        end_date = typer.prompt("  End date", default=start_date[:10])
    if len(end_date) == 10:
        end_date += " 18:00:00"

    payload: dict[str, Any] = {
        "personId": safe_id(person_id),
        "leaveTypeId": safe_id(leave_type_id),
        "startDate": start_date,
        "endDate": end_date,
        "comment": comment or "",
    }

    with api_call("Submitting leave request..."):
        client.post("v2/leave/create", data=payload)

    print_success("Leave request submitted successfully.")
