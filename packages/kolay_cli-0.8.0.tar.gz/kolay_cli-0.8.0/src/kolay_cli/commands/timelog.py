from __future__ import annotations
from typing import Any
import typer
from rich.table import Table
from rich.panel import Panel
from datetime import datetime

from ..api import KolayClient, safe_id
from ..ui import (
    console, short_id, display_status, fmt_val,
    print_success, print_empty, kv_table, pick_timelog, pick_person,
    api_call, no_command_help, PRIMARY,
)

app = typer.Typer(help="Manage timelogs (work hours, overtime, etc.) in Kolay.")


@app.callback(invoke_without_command=True)
def _hint(ctx: typer.Context) -> None:
    no_command_help(ctx)


@app.command(name="list")
def list_timelogs(
    page: int = typer.Option(1, help="Page number"),
    limit: int = typer.Option(20, help="Number of records to return"),
    person_id: str | None = typer.Option(None, "--person-id", "-p", help="Filter by person ID"),
    type: str | None = typer.Option(None, "--type", "-t", help="Filter by type: work, overtime, remote"),
    status: str | None = typer.Option(None, "--status", help="Filter: waiting, approved, rejected"),
    start: str | None = typer.Option(None, "--start", help="Start date (YYYY-MM-DD)"),
    end: str | None = typer.Option(None, "--end", help="End date (YYYY-MM-DD)"),
) -> None:
    """List timelog records. Filterable by person, type, status, or date range."""
    now = datetime.now()
    payload: dict[str, Any] = {
        "page": page, "limit": limit,
        "startDate": start or f"{now.year}-01-01 00:00:00",
        "endDate": end or f"{now.year}-12-31 23:59:59",
        "sortType": "startDate", "sortOrder": "desc",
    }
    if person_id:
        payload["personId"] = person_id
    if type:
        payload["type"] = type
    if status:
        payload["status"] = status

    with api_call("Fetching timelogs..."):
        client = KolayClient()
        response = client.post("v2/timelog/list", data=payload)

    data = response.get("data", {})
    items = data.get("items", []) if isinstance(data, dict) else []
    total = data.get("totalCount", 0) if isinstance(data, dict) else len(items)

    if not items:
        print_empty("timelog records")
        return

    console.print(f"\n[bold {PRIMARY}]⏱️ Timelog Records[/bold {PRIMARY}] [grey62]({len(items)}/{total})[/grey62]\n")
    table = Table(header_style=f"bold {PRIMARY}", border_style=PRIMARY, box=None, show_edge=False)
    table.add_column("#", style="grey62", justify="right", width=4)
    table.add_column("Employee", style="bold white", min_width=18)
    table.add_column("Type", style="grey85")
    table.add_column("Start", style="grey62")
    table.add_column("End", style="grey62")
    table.add_column("Status", justify="center")
    table.add_column("Short ID", style="grey62")

    for i, tl in enumerate(items, 1):
        p = tl.get("person", {})
        pname = f"{p.get('firstName', '')} {p.get('lastName', '')}".strip() if isinstance(p, dict) else "—"
        table.add_row(
            str(i + (page - 1) * limit), pname,
            str(tl.get("type", "—")),
            (tl.get("startDate") or "—")[:16],
            (tl.get("endDate") or "—")[:16],
            display_status(str(tl.get("status", ""))),
            short_id(str(tl.get("id", "")))
        )

    console.print(table)
    console.print()


@app.command(name="view")
def view_timelog(timelog_id: str | None = typer.Argument(None, help="ID of the timelog to view")) -> None:
    """View full details and approval workflow for a specific timelog."""
    if not timelog_id:
        timelog_id = pick_timelog()

    with api_call("Fetching timelog details..."):
        client = KolayClient()
        response = client.get(f"v2/timelog/view/{safe_id(timelog_id)}")

    data = response.get("data", {})
    p = data.get("person", {})
    pname = f"{p.get('firstName', '')} {p.get('lastName', '')}".strip() if isinstance(p, dict) else "Unknown"
    console.print(f"\n[bold {PRIMARY}]⏱️ Timelog[/bold {PRIMARY}] [bold white]{pname}[/bold white] — {data.get('type', 'Work')}")
    console.print(f"  {display_status(str(data.get('status', '')))}\n")
    console.print(Panel(kv_table(data, exclude=["id", "person", "type", "status", "personId"]), border_style=PRIMARY, expand=False))
    console.print()


@app.command(name="create")
def create_timelog(
    person_id: str | None = typer.Option(None, "--person-id", "-p", help="ID of the person"),
    type: str = typer.Option("work", "--type", "-t", help="Type: work, overtime, remote"),
    start: str | None = typer.Option(None, "--start", "-s", help="Start datetime (YYYY-MM-DD HH:MM:SS)"),
    end: str | None = typer.Option(None, "--end", "-e", help="End datetime (YYYY-MM-DD HH:MM:SS)"),
    description: str | None = typer.Option(None, "--desc", help="Optional description"),
) -> None:
    """Submit a new timelog entry for approval."""
    console.print(f"\n[bold {PRIMARY}]⏱️ Create Timelog Entry[/bold {PRIMARY}]\n")

    if not person_id:
        person_id = pick_person()
    if not start:
        start = typer.prompt("  Start (YYYY-MM-DD HH:MM:SS)", default=datetime.now().replace(minute=0, second=0).strftime("%Y-%m-%d %H:%M:%S"))
    if not end:
        end = typer.prompt("  End (YYYY-MM-DD HH:MM:SS)")

    payload: dict[str, Any] = {
        "personId": safe_id(person_id), "startDate": start, "endDate": end,
        "type": type, "status": "waiting", "description": description or "",
    }

    with api_call("Submitting timelog..."):
        client = KolayClient()
        client.post("v2/timelog/create", data=payload)

    print_success("Timelog entry submitted for approval.")


@app.command(name="delete")
def delete_timelog(timelog_id: str | None = typer.Argument(None, help="ID of the timelog to delete")) -> None:
    """Permanently delete a timelog record."""
    if not timelog_id:
        timelog_id = pick_timelog()

    typer.confirm(f"  Delete this timelog record?", abort=True)

    with api_call("Deleting timelog..."):
        client = KolayClient()
        client.delete(f"v2/timelog/delete/{safe_id(timelog_id)}")

    print_success("Timelog deleted successfully.")
