from __future__ import annotations
from typing import Any
import typer
from rich.table import Table
from rich.panel import Panel

from ..api import KolayClient, safe_id
from ..ui import (
    console, short_id, print_success, print_empty, kv_table, pick_training,
    api_call, no_command_help, PRIMARY,
)

app = typer.Typer(help="Manage company training catalogue.")


@app.callback(invoke_without_command=True)
def _hint(ctx: typer.Context) -> None:
    no_command_help(ctx)


@app.command(name="list")
def list_trainings(
    search: str | None = typer.Option(None, "--search", "-s", help="Search by training name"),
    page: int = typer.Option(1, help="Page number"),
    limit: int = typer.Option(20, help="Number of records to return"),
) -> None:
    """List all trainings in the company catalogue."""
    params: dict[str, Any] = {"page": page, "limit": limit}
    if search:
        params["search"] = search

    with api_call("Fetching training catalogue..."):
        client = KolayClient()
        response = client.get("v2/training/list", params=params)

    data = response.get("data", {})
    items = data.get("items", []) if isinstance(data, dict) else []
    total = data.get("totalCount", 0) if isinstance(data, dict) else len(items)

    if not items:
        print_empty("trainings")
        return

    console.print(f"\n[bold {PRIMARY}]🎓 Training Catalogue[/bold {PRIMARY}] [grey62]({len(items)}/{total})[/grey62]\n")
    table = Table(header_style=f"bold {PRIMARY}", border_style=PRIMARY, box=None, show_edge=False)
    table.add_column("#", style="grey62", justify="right", width=4)
    table.add_column("Training Name", style="bold white", min_width=24)
    table.add_column("Duration", justify="right", style="grey85")
    table.add_column("Short ID", style="grey62")

    for i, tr in enumerate(items, 1):
        dur = tr.get("duration") or tr.get("durationDays") or "—"
        table.add_row(str(i + (page - 1) * limit), str(tr.get("name", "—")), str(dur), short_id(str(tr.get("id", ""))))

    console.print(table)
    console.print()


@app.command(name="view")
def view_training(training_id: str | None = typer.Argument(None, help="ID of the training to view")) -> None:
    """View full details of a specific training in the catalogue."""
    if not training_id:
        training_id = pick_training()

    with api_call("Fetching training details..."):
        client = KolayClient()
        response = client.get(f"v2/training/view/{safe_id(training_id)}")

    data = response.get("data", {})
    name = data.get("name", "Training Details")
    console.print(f"\n[bold {PRIMARY}]🎓 Training[/bold {PRIMARY}] [bold white]{name}[/bold white]\n")
    console.print(Panel(kv_table(data, exclude=["id", "name"]), border_style=PRIMARY, expand=False))
    console.print()


@app.command(name="create")
def create_training(
    name: str | None = typer.Option(None, "--name", "-n", help="Training name"),
    description: str | None = typer.Option(None, "--desc", help="Training description"),
    duration: str | None = typer.Option(None, "--duration", help="Duration in days"),
) -> None:
    """Add a new training to the company catalogue."""
    console.print(f"\n[bold {PRIMARY}]🎓 Create Training[/bold {PRIMARY}]\n")

    if not name:
        name = typer.prompt("  Name")
    if not description:
        description = typer.prompt("  Description (optional)", default="")
    if not duration:
        duration = typer.prompt("  Duration in days (optional)", default="")

    with api_call(f"Adding '{name}'..."):
        client = KolayClient()
        client.post("v2/training/create", data={"name": name, "description": description, "duration": duration})

    print_success("Training added to catalogue.")


@app.command(name="update")
def update_training(
    training_id: str | None = typer.Argument(None, help="ID of the training to update"),
    name: str | None = typer.Option(None, "--name", "-n", help="New name"),
    description: str | None = typer.Option(None, "--desc", help="New description"),
) -> None:
    """Update details for an existing training in the catalogue."""
    if not training_id:
        training_id = pick_training()

    with api_call("Fetching current training..."):
        client = KolayClient()
        response = client.get(f"v2/training/view/{safe_id(training_id)}")

    cur = response.get("data", {})
    payload: dict[str, Any] = {}
    if not any([name, description]):
        payload["name"] = typer.prompt("  Name", default=cur.get("name", ""))
        payload["description"] = typer.prompt("  Description", default=cur.get("description") or "")
    else:
        if name:
            payload["name"] = name
        if description:
            payload["description"] = description

    with api_call("Saving changes..."):
        client.put(f"v2/training/update/{safe_id(training_id)}", data=payload)

    print_success("Training updated successfully.")


@app.command(name="delete")
def delete_training(training_id: str | None = typer.Argument(None, help="ID of the training to delete")) -> None:
    """Permanently remove a training from the company catalogue."""
    if not training_id:
        training_id = pick_training()

    with api_call("Fetching training name..."):
        client = KolayClient()
        response = client.get(f"v2/training/view/{safe_id(training_id)}")

    name = response.get("data", {}).get("name", "this training")
    typer.confirm(f"  Delete '{name}' and all associated history?", abort=True)

    with api_call("Deleting training..."):
        client.delete(f"v2/training/delete/{safe_id(training_id)}")

    print_success("Training removed from catalogue.")
