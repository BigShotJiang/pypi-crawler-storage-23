from __future__ import annotations
import typer
from rich.table import Table

from ..api import KolayClient
from ..ui import (
    console, short_id, print_empty,
    api_call, no_command_help, PRIMARY, SUCCESS, ERROR,
)

app = typer.Typer(help="Manage expense categories in Kolay.")


@app.callback(invoke_without_command=True)
def _hint(ctx: typer.Context) -> None:
    no_command_help(ctx)


@app.command(name="categories")
def list_categories(
    title: str | None = typer.Option(None, "--title", "-t", help="Filter by title"),
    enabled_only: bool = typer.Option(False, "--enabled", help="Show only enabled categories"),
) -> None:
    """List expense categories available for your company."""
    params: dict = {}
    if title:
        params["title"] = title
    if enabled_only:
        params["isEnable"] = 1

    with api_call("Fetching expense categories..."):
        client = KolayClient()
        response = client.get("v2/expense/list-categories", params=params)

    data = response.get("data", [])
    if not data:
        print_empty("expense categories")
        return

    console.print(f"\n[bold {PRIMARY}]🧾 Expense Categories[/bold {PRIMARY}]\n")
    table = Table(header_style=f"bold {PRIMARY}", border_style=PRIMARY, box=None, show_edge=False)
    table.add_column("#", style="grey62", justify="right", width=4)
    table.add_column("Title", style="bold white", min_width=20)
    table.add_column("Enabled", justify="center")
    table.add_column("Short ID", style="grey62")

    for i, cat in enumerate(data, 1):
        enabled = cat.get("isEnable") or cat.get("enabled")
        enabled_str = f"[{SUCCESS}]Yes[/{SUCCESS}]" if enabled else f"[{ERROR}]No[/{ERROR}]"
        table.add_row(str(i), cat.get("title") or cat.get("name") or "—", enabled_str, short_id(str(cat.get("id", ""))))

    console.print(table)
    console.print()
