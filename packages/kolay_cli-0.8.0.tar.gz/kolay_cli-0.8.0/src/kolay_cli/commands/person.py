from __future__ import annotations
import os
from typing import Any
import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.columns import Columns

from ..api import KolayClient, APIError, safe_id
from ..ui import (
    console, short_id, display_status, fmt_val, fmt_num, label,
    print_error, print_success, print_fetching, print_empty, kv_table,
    pick_person, pick_training, pick_person_training,
    api_call, no_command_help, PRIMARY,
)

app = typer.Typer(help="Manage person/employee records in Kolay.")


@app.callback(invoke_without_command=True)
def _hint(ctx: typer.Context) -> None:
    no_command_help(ctx)


@app.command(name="list")
def list_people(
    page: int = typer.Option(1, help="Page number"),
    status: str = typer.Option("active", help="Filter by status: active, inactive"),
    search: str | None = typer.Option(None, "--search", "-s", help="Search by name or email"),
    limit: int = typer.Option(20, help="Number of records to show")
) -> None:
    """List employees from the company roster.
    
    Defaults to active employees. Can be filtered by status or searched by name/email.
    
    Args:
        page: The page number for pagination.
        status: Filter by 'active' or 'inactive' status.
        search: Optional search term for name or email.
        limit: Number of records to return per page.
    """
    try:
        client = KolayClient()
        print_fetching(f"Fetching {status} employees...")
        
        payload = {"page": page, "status": status, "limit": limit}
        if search:
            payload["search"] = search

        response = client.post("v2/person/list", data=payload)
        data = response.get("data", {})
        items = data.get("items", [])
        total = data.get("totalCount", 0)

        if not items:
            print_empty(f"{status} employees", hint="Try --status inactive to find terminated employees.")
            return

        title = f"👥 {status.title()} Employees"
        if search:
            title += f" matching '{search}'"
        
        console.print(f"\n[bold {PRIMARY}]{title}[/bold {PRIMARY}] [grey62]({len(items)}/{total})[/grey62]\n")
        
        table = Table(header_style=f"bold {PRIMARY}", border_style=PRIMARY, box=None, show_edge=False)
        table.add_column("#", style="grey62", justify="right", width=4)
        table.add_column("Name", style="bold white", min_width=22)
        table.add_column("Email", style="grey85")
        table.add_column("Phone", style="grey62")
        table.add_column("Short ID", style="grey62")

        for i, person in enumerate(items, 1):
            name = f"{person.get('firstName', '')} {person.get('lastName', '')}".strip() or person.get("name", "—")
            email = person.get("workEmail") or person.get("email") or "—"
            phone = person.get("mobilePhone") or "—"
            table.add_row(
                str(i + (page - 1) * limit),
                name, email, phone,
                short_id(str(person.get("id", "")))
            )
        
        console.print(table)
        console.print()

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="view")
def view_person(person_id: str | None = typer.Argument(None, help="ID of the person to view")) -> None:
    """View the full profile of a specific employee.
    
    If no ID is provided, an interactive picker will be shown.
    """
    if not person_id:
        person_id = pick_person()

    try:
        client = KolayClient()
        print_fetching(f"Fetching person details...")
        response = client.get(f"v2/person/view/{safe_id(person_id)}")
        data = response.get("data", {})

        fname = data.get("firstName", "")
        lname = data.get("lastName", "")
        st = data.get("status", "")
        email = data.get("workEmail") or data.get("email") or "—"

        console.print(f"\n[bold {PRIMARY}]👤 Employee Profile[/bold {PRIMARY}] [bold white]{fname} {lname}[/bold white]")
        console.print(f"  {display_status(st)}  [grey62]{email}[/grey62]\n")

        tbl = kv_table(data, exclude=["id", "firstName", "lastName", "status", "workEmail", "email", "units"])
        console.print(Panel(tbl, border_style=PRIMARY, expand=False))
        
        # Display Unit Details if available
        units = data.get("units", [])
        if units:
            console.print("\n[bold magenta]🏢 Organisational Units[/bold magenta]")
            u_tbl = Table(header_style="bold magenta", border_style="magenta", box=None, show_edge=False)
            u_tbl.add_column("Type", style="grey62")
            u_tbl.add_column("Item", style="bold white")
            u_tbl.add_column("Primary?", justify="center")
            
            for u in units:
                items = u.get("items", [])
                for item in items:
                    u_tbl.add_row(
                        item.get("unitName", "—"),
                        item.get("unitItemName", "—"),
                        "[green]Yes[/green]" if u.get("primary", False) else "[grey62]No[/grey62]"
                    )
            console.print(u_tbl)
        
        console.print()

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="leave-status")
def view_leave_status(
    person_id: str | None = typer.Argument(None, help="ID of the person to view leave balances for")
) -> None:
    """View current leave balances and limits for a specific employee.
    
    Shows used, upcoming, and remaining days for all assigned leave types.
    """
    if not person_id:
        person_id = pick_person()

    try:
        client = KolayClient()
        print_fetching("Fetching leave balances...")
        response = client.get(f"v2/person/leave-status/{safe_id(person_id)}")
        data = response.get("data", [])

        if not data:
            print_empty("leave balances")
            return

        table = Table(header_style=f"bold {PRIMARY}", border_style=PRIMARY, box=None, show_edge=False)
        table.add_column("Leave Type", style="bold white", min_width=20)
        table.add_column("Limit", justify="right")
        table.add_column("Used", justify="right", style="orange1")
        table.add_column("Upcoming", justify="right", style="grey85")
        table.add_column("Remaining", justify="right", style="bold green")

        for item in data:
            ltype = item.get("leaveType", {})
            name = ltype.get("name", "—")
            table.add_row(
                name,
                fmt_num(item.get("dayLimit", "∞")),
                fmt_num(item.get("used", 0)),
                fmt_num(item.get("totalUpcoming", 0)),
                fmt_num(item.get("unused", 0))
            )

        console.print("\n[bold {PRIMARY}]🏖️ Leave Balances[/bold {PRIMARY}]\n")
        console.print(table)
        console.print()

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


# SGK termination reason codes
REASON_CODES = {
    "01": "Resignation (deneme süreli fesh - işverence)",
    "03": "Voluntary resignation (istifa)",
    "04": "Termination without notice (haklı nedenle)",
    "10": "End of fixed-term contract",
    "11": "Retirement",
    "22": "Termination by employer (geçerli neden)",
    "23": "Death",
    "30": "Other",
}


@app.command(name="terminate")
def terminate_person(
    person_id: str | None = typer.Argument(None, help="ID of the person to terminate"),
    termination_date: str | None = typer.Option(
        None, help="Termination date (YYYY-MM-DD). Defaults to today."
    ),
    reason: str | None = typer.Option(
        None, help="Reason code (e.g. 01 for resignation). Leave blank to see options."
    ),
) -> None:
    """Terminate the employment of a specific employee.
    
    Will prompt for the termination date and reason if not provided as options.
    """
    if not person_id:
        person_id = pick_person()

    if not termination_date:
        from datetime import datetime
        default_date = datetime.now().strftime("%Y-%m-%d")
        termination_date = typer.prompt("  Termination date", default=default_date)

    if not reason:
        console.print("\n[bold white]  Termination reasons:[/bold white]")
        for code, desc in REASON_CODES.items():
            console.print(f"  [cyan]{code}[/cyan] : {desc}")
        reason = typer.prompt("\n  Enter reason code", type=str)

    try:
        client = KolayClient()
        print_fetching("Processing termination...")
        client.post(
            f"v2/person/terminate",
            data={
                "personId": safe_id(person_id),
                "date": termination_date,
                "reasonCode": reason,
                "details": REASON_CODES.get(reason, "Termination")
            }
        )
        print_success("Employee terminated successfully.")
    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="update")
def update_person(
    person_id: str | None = typer.Argument(None, help="ID of the person to update"),
    first_name: str | None = typer.Option(None, "--first-name", help="Update first name"),
    last_name: str | None = typer.Option(None, "--last-name", help="Update last name"),
    email: str | None = typer.Option(None, "--email", help="Update work email address"),
    mobile_phone: str | None = typer.Option(None, "--phone", help="Update mobile phone"),
    custom_field: list[str] | None = typer.Option(
        None, "--custom", help="Custom field as key=value (e.g. --custom adres='Street 33/4')"
    )
) -> None:
    """Update profile details of a specific employee.
    
    Only fields passed as options will be updated.
    """
    if not person_id:
        person_id = pick_person()

    person_payload: dict[str, Any] = {"id": safe_id(person_id)}
    if first_name:
        person_payload["firstName"] = first_name
    if last_name:
        person_payload["lastName"] = last_name
    if email:
        person_payload["workEmail"] = email
    if mobile_phone:
        person_payload["mobilePhone"] = mobile_phone
    
    if custom_field:
        data_list = []
        for cf in custom_field:
            if "=" in cf:
                k, v = cf.split("=", 1)
                data_list.append({"fieldToken": k.strip(), "value": v.strip()})
        if data_list:
            person_payload["dataList"] = data_list

    if len(person_payload) == 1:
        print_error("Nothing to update.", hint="Provide at least one option like --first-name.")
        return

    try:
        client = KolayClient()
        print_fetching("Updating person details...")
        client.put(f"v2/person/update", data={"person": person_payload})
        print_success("Employee profile updated successfully.")
    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="summary")
def view_summary(person_id: str | None = typer.Argument(None, help="ID of the person to view summary for")) -> None:
    """View a condensed summary of an employee record.
    
    Includes key identity and contact info.
    """
    if not person_id:
        person_id = pick_person()

    try:
        client = KolayClient()
        print_fetching("Fetching summary...")
        response = client.get(f"v2/person/summary/{safe_id(person_id)}")
        data = response.get("data", {})

        fname = data.get("firstName", "")
        lname = data.get("lastName", "")
        
        console.print(f"\n[bold {PRIMARY}]📄 Employee Summary[/bold {PRIMARY}] [bold white]{fname} {lname}[/bold white]\n")
        tbl = kv_table(data, exclude=["id", "firstName", "lastName", "status", "dataList"])
        console.print(Panel(tbl, border_style=PRIMARY, expand=False))
        
        # Custom Fields in Summary
        custom_data = [f for f in data.get("dataList", []) if f.get("value")]
        if custom_data:
            c_tbl = Table(show_header=True, header_style=f"bold {PRIMARY}", box=None, padding=(0, 2, 0, 0))
            c_tbl.add_column("Field", style="grey85")
            c_tbl.add_column("Value")
            for field in custom_data:
                c_tbl.add_row(field.get("fieldToken", "—"), fmt_val(field.get("value")))
            console.print(Panel(c_tbl, title="Custom Fields", border_style="grey85", expand=False))
        console.print()

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="create")
def create_person(
    first_name: str | None = typer.Option(None, "--first-name", help="First name"),
    last_name: str | None = typer.Option(None, "--last-name", help="Last name"),
    email: str | None = typer.Option(None, "--email", help="Work email address"),
    mobile_phone: str | None = typer.Option(None, "--phone", help="Mobile phone number"),
    employment_start: str | None = typer.Option(None, "--start-date", help="Employment start date (YYYY-MM-DD)"),
) -> None:
    """Create a new employee record. Prompts for missing required fields."""
    console.print("\n[bold {PRIMARY}]👤 Create Employee[/bold {PRIMARY}]\n")
    if not first_name:
        first_name = typer.prompt("  First name")
    if not last_name:
        last_name = typer.prompt("  Last name")
    if not email:
        email = typer.prompt("  Work email")
    if not employment_start:
        employment_start = typer.prompt("  Employment start date (YYYY-MM-DD)")

    payload = {
        "person": {
            "firstName": first_name,
            "lastName": last_name,
            "workEmail": email,
            "employmentStartDate": employment_start,
        }
    }
    if mobile_phone:
        payload["person"]["mobilePhone"] = mobile_phone

    try:
        client = KolayClient()
        print_fetching(f"Creating employee {first_name} {last_name}...")
        response = client.post("v2/person/create", data=payload)
        data = response.get("data", {})
        new_id = data.get("id", "—")
        print_success(f"Employee created! ID: [cyan]{new_id}[/cyan]")
    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="bulk-view")
def bulk_view_people(
    person_ids: str = typer.Argument(..., help="Comma-separated person IDs to view"),
) -> None:
    """View multiple employees at once. Pass comma-separated IDs."""
    ids = [i.strip() for i in person_ids.split(",") if i.strip()]
    if not ids:
        print_error("No valid IDs provided.")
        raise typer.Exit(1)

    try:
        client = KolayClient()
        print_fetching(f"Fetching {len(ids)} employee(s)...")
        response = client.post("v2/person/bulk-view", data={"ids": ids})

        data = response.get("data", [])
        items = data if isinstance(data, list) else data.get("items", [])

        if not items:
            print_empty("employees", hint="Check the IDs and try again.")
            return

        console.print("\n[bold {PRIMARY}]👥 Bulk Employees View[/bold {PRIMARY}]\n")
        table = Table(header_style=f"bold {PRIMARY}", border_style=PRIMARY, box=None, show_edge=False)
        table.add_column("Name", style="bold white", min_width=22)
        table.add_column("Email", style="grey85")
        table.add_column("Status", justify="center")
        table.add_column("Short ID", style="grey62")

        for p in items:
            name = f"{p.get('firstName', '')} {p.get('lastName', '')}".strip() or p.get("name", "—")
            email = p.get("workEmail") or "—"
            table.add_row(name, email, display_status(p.get("status", "")), short_id(str(p.get("id", ""))))

        console.print(table)
        console.print()

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="fields")
def show_available_fields() -> None:
    """Show all dictionary fields/tokens available for person updates."""
    try:
        client = KolayClient()
        print_fetching("Fetching available data fields...")
        response = client.get("v2/person/show-available-data-fields")
        data = response.get("data", [])

        if not data:
            print_empty("data fields")
            return

        table = Table(header_style=f"bold {PRIMARY}", border_style=PRIMARY, box=None, show_edge=False)
        table.add_column("#", style="grey62", justify="right", width=4)
        table.add_column("Token", style="bold white", no_wrap=True)
        table.add_column("Label", style="grey85")
        table.add_column("Type", style="grey62")
        table.add_column("Required", justify="center")

        for i, field in enumerate(data, 1):
            token = field.get("token") or field.get("fieldToken") or "—"
            field_label = field.get("label") or field.get("name") or "—"
            req = "[red]Yes[/red]" if field.get("required") else "[grey62]No[/grey62]"
            table.add_row(str(i), token, field_label, field.get("type", "—"), req)

        console.print("\n[bold {PRIMARY}]📋 Available Custom Fields[/bold {PRIMARY}]\n")
        console.print(table)
        console.print()

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="rehire")
def rehire_person(
    person_id: str | None = typer.Argument(None, help="ID of the person to rehire"),
    start_date: str | None = typer.Option(None, "--start-date", help="New start date (YYYY-MM-DD)"),
) -> None:
    """Rehire a previously terminated employee."""
    if not person_id:
        person_id = pick_person()

    if not start_date:
        from datetime import datetime
        start_date = typer.prompt("  New employment start date (YYYY-MM-DD)", default=datetime.now().strftime("%Y-%m-%d"))

    try:
        client = KolayClient()
        print_fetching("Processing rehire...")
        client.post(f"v2/person/rehire/{safe_id(person_id)}", data={"employmentStartDate": start_date})
        print_success("Employee rehired successfully.")
    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="list-files")
def list_person_files(person_id: str | None = typer.Argument(None, help="ID of the person")) -> None:
    """List all documents attached to an employee profile."""
    if not person_id:
        person_id = pick_person()

    try:
        client = KolayClient()
        print_fetching("Fetching employee files...")
        response = client.get(f"v2/person/list-files/{safe_id(person_id)}")
        data = response.get("data", [])

        if not data:
            print_empty("files")
            return

        table = Table(header_style=f"bold {PRIMARY}", border_style=PRIMARY, box=None, show_edge=False)
        table.add_column("#", style="grey62", justify="right", width=4)
        table.add_column("Name", style="bold white", min_width=22)
        table.add_column("Folder", style="grey85")
        table.add_column("Short ID", style="grey62")

        for i, f in enumerate(data, 1):
            name = f.get("name") or "—"
            folder = f.get("folderName") or "—"
            table.add_row(str(i), name, folder, short_id(str(f.get("id", ""))))

        console.print("\n[bold {PRIMARY}]📁 Employee Files[/bold {PRIMARY}]\n")
        console.print(table)
        console.print()

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="delete-file")
def delete_person_file(file_id: str | None = typer.Argument(None, help="ID of the file to delete")) -> None:
    """Delete a document from an employee profile."""
    if not file_id:
        console.print("[grey62]  Tip: run 'kolay person list-files' to find file IDs.[/grey62]")
        file_id = typer.prompt("  File ID")
    
    typer.confirm(f"  Delete file {file_id}?", abort=True)

    try:
        client = KolayClient()
        print_fetching("Deleting file...")
        client.delete(f"v2/person/delete-file/{safe_id(file_id)}")
        print_success("File deleted.")
    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="delete-folder")
def delete_person_folder(folder_id: str | None = typer.Argument(None, help="ID of the folder to delete")) -> None:
    """Delete a folder and all documents inside it from an employee profile."""
    if not folder_id:
        console.print("[grey62]  Tip: run 'kolay person list-files' to find folder IDs.[/grey62]")
        folder_id = typer.prompt("  Folder ID")
    
    typer.confirm(f"  Delete folder {folder_id}? All contents will be lost.", abort=True)

    try:
        client = KolayClient()
        print_fetching("Deleting folder...")
        client.delete(f"v2/person/delete-folder/{safe_id(folder_id)}")
        print_success("Folder deleted.")
    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="upload-file")
def upload_file(
    person_id: str | None = typer.Option(None, "--person-id", "-p", help="ID of the person"),
    file_path: str = typer.Option(..., "--file", "-f", help="Path to the file to upload"),
    folder_name: str | None = typer.Option(None, "--folder", help="Target folder name (optional)"),
) -> None:
    """Upload a local document to an employee profile."""
    if not os.path.isfile(file_path):
        print_error(f"File not found: {file_path}")
        raise typer.Exit(1)

    if not person_id:
        person_id = pick_person()

    try:
        client = KolayClient()
        url = f"{client.base_url}/v2/person/upload-file"
        
        with open(file_path, "rb") as fh:
            files = {"file": (os.path.basename(file_path), fh)}
            form_data = {"personId": safe_id(person_id)}
            if folder_name:
                form_data["folderName"] = folder_name

            # Use session for auth but remove Content-Type for multipart
            session = client.session
            headers = dict(session.headers)
            headers.pop("Content-Type", None)

            print_fetching(f"Uploading {os.path.basename(file_path)}...")
            resp = session.post(url, data=form_data, files=files, headers=headers, timeout=60)
            resp.raise_for_status()

        print_success(f"File '{os.path.basename(file_path)}' uploaded successfully.")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


# ── Person Training Management ────────────────────────────────────────────────

@app.command(name="list-trainings")
def list_person_trainings(person_id: str | None = typer.Argument(None, help="ID of the person")) -> None:
    """List all training assignments for an employee."""
    if not person_id:
        person_id = pick_person()

    try:
        client = KolayClient()
        print_fetching("Fetching training assignments...")
        response = client.get(f"v2/person/list-trainings/{safe_id(person_id)}")
        data = response.get("data", [])

        if not data:
            print_empty("training assignments")
            return

        table = Table(header_style=f"bold {PRIMARY}", border_style=PRIMARY, box=None, show_edge=False)
        table.add_column("#", style="grey62", justify="right", width=4)
        table.add_column("Training", style="bold white", min_width=22)
        table.add_column("Status", justify="center")
        table.add_column("Start", style="grey62")
        table.add_column("End", style="grey62")
        table.add_column("Short ID", style="grey62")

        for i, pt in enumerate(data, 1):
            t = pt.get("training", {})
            tname = t.get("name", "—") if isinstance(t, dict) else str(t)
            st = display_status(str(pt.get("status", "")))
            table.add_row(
                str(i), tname, st,
                (pt.get("startDate") or "—")[:10],
                (pt.get("endDate") or "—")[:10],
                short_id(str(pt.get("id", "")))
            )

        console.print("\n[bold {PRIMARY}]🎓 Training Assignments[/bold {PRIMARY}]\n")
        console.print(table)
        console.print()

    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="assign-training")
def assign_training(
    person_id: str | None = typer.Option(None, "--person-id", "-p", help="ID of the person"),
    training_id: str | None = typer.Option(None, "--training-id", "-t", help="ID of the training to assign"),
    start_date: str | None = typer.Option(None, "--start", help="Start date (YYYY-MM-DD)"),
    end_date: str | None = typer.Option(None, "--end", help="End date (YYYY-MM-DD)"),
    status: str = typer.Option("waiting", "--status", help="Status: waiting, approved"),
) -> None:
    """Assign a training from the catalogue to an employee."""
    if not person_id:
        person_id = pick_person()
    if not training_id:
        training_id = pick_training()

    payload = {
        "personId": safe_id(person_id),
        "trainingId": safe_id(training_id),
        "status": status,
    }
    if start_date:
        payload["startDate"] = start_date
    if end_date:
        payload["endDate"] = end_date

    try:
        client = KolayClient()
        print_fetching("Assigning training...")
        client.post("v2/person/assign-training", data=payload)
        print_success("Training assigned successfully.")
    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="update-training")
def update_person_training(
    person_training_id: str | None = typer.Argument(None, help="Assignment ID to update"),
    status: str | None = typer.Option(None, "--status", help="New status"),
    start_date: str | None = typer.Option(None, "--start", help="New start date"),
    end_date: str | None = typer.Option(None, "--end", help="New end date"),
) -> None:
    """Update an existing training assignment."""
    if not person_training_id:
        person_training_id = pick_person_training()

    payload: dict[str, Any] = {}
    if status:
        payload["status"] = status
    if start_date:
        payload["startDate"] = start_date
    if end_date:
        payload["endDate"] = end_date

    if not payload:
        print_error("No fields to update.", hint="Use --status, --start, or --end.")
        return

    try:
        client = KolayClient()
        print_fetching("Updating assignment...")
        client.put(f"v2/person/update-training/{safe_id(person_training_id)}", data=payload)
        print_success("Assignment updated.")
    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="delete-training")
def delete_person_training(
    person_training_id: str | None = typer.Argument(None, help="Assignment ID to delete"),
) -> None:
    """Permanently delete a training assignment."""
    if not person_training_id:
        person_training_id = pick_person_training()

    typer.confirm(f"  Delete assignment {person_training_id}?", abort=True)

    try:
        client = KolayClient()
        print_fetching("Deleting assignment...")
        client.delete(f"v2/person/delete-training/{safe_id(person_training_id)}")
        print_success("Assignment deleted.")
    except APIError as e:
        print_error(str(e))
        raise typer.Exit(1)
