"""
UI formatters for kolay-cli.

Provides a consistent, premium visual layer using Kolay brand colours:
  • ``spinner``   — context manager that shows a live dots spinner
  • ``api_call``  — spinner + automatic APIError → rich Panel (DRY wrapper)
  • ``print_error`` — rich error panel with recovery hint
  • ``print_success`` / ``print_empty`` — consistent feedback helpers
  • ``kv_table`` / ``short_id`` / ``display_status`` — data formatting
"""
from __future__ import annotations
import sys
import time
from contextlib import contextmanager
from typing import Any, Generator

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .constants import (
    STATUS_STYLES, FIELD_LABELS,
    PRIMARY, ACCENT, SUCCESS, WARNING, ERROR,
)

# ── Global console ────────────────────────────────────────────────────────────
console = Console(highlight=False)


# ── Spinner / Loading State ───────────────────────────────────────────────────

@contextmanager
def spinner(message: str = "Working...") -> Generator[None, None, None]:
    """Context manager that shows a live Kolay-branded spinner.

    Usage::

        with spinner("Fetching employees..."):
            data = client.get("v2/person/list")

    Args:
        message: The text to display next to the spinner.
    """
    with console.status(f"[{PRIMARY}]{message}[/{PRIMARY}]", spinner="dots"):
        yield


@contextmanager
def api_call(message: str = "Working...") -> Generator[None, None, None]:
    """Spinner + automatic error handling for API operations."""
    import typer
    from ..api.errors import APIError

    try:
        with spinner(message):
            yield
    except APIError as exc:
        print_api_error(exc)
        raise typer.Exit(1)


def no_command_help(ctx: "typer.Context") -> None:  # type: ignore[name-defined]
    """Show when a command group is invoked with no subcommand.

    Prints a friendly hint, waits 3 seconds with a live countdown,
    then displays the full help so the user knows what's available.

    Usage — add this identical callback to every Typer sub-app::

        @app.callback(invoke_without_command=True)
        def _hint(ctx: typer.Context) -> None:
            if ctx.invoked_subcommand is None:
                no_command_help(ctx)

    Args:
        ctx: The Typer context of the invoked command group.
    """
    import typer

    if ctx.invoked_subcommand is not None:
        return

    name = ctx.info_name or "this command"
    console.print(
        f"\n[bold {PRIMARY}]kolay {name}[/bold {PRIMARY}] needs a sub-command.\n"
        f"  Try: [bold]kolay {name} --help[/bold]\n"
    )

    # 3-second countdown with a live status indicator
    for secs in (3, 2, 1):
        with console.status(
            f"[{PRIMARY}]Showing help in {secs}…[/{PRIMARY}]",
            spinner="dots",
        ):
            time.sleep(1)

    console.print()
    console.print(ctx.get_help())
    raise typer.Exit(0)


# ── ID & Status Helpers ───────────────────────────────────────────────────────

def short_id(full_id: str) -> str:
    """Return a truncated display version of a UUID (last 8 chars).

    Args:
        full_id: The full UUID string.

    Returns:
        A rich-formatted shortened ID.
    """
    if not full_id or full_id in ("N/A", "—"):
        return "[grey62]—[/grey62]"
    clean = str(full_id)
    return f"[grey62]…{clean[-8:]}[/grey62]" if len(clean) > 8 else f"[grey62]{clean}[/grey62]"


def display_status(status: str) -> str:
    """Return a styled status badge using Kolay brand colours.

    Args:
        status: The raw status string from the API.

    Returns:
        A rich-formatted status badge.
    """
    if not status:
        return "[grey62]—[/grey62]"
    return STATUS_STYLES.get(str(status).lower(), f"[grey62]{status}[/grey62]")


# ── Value Formatters ──────────────────────────────────────────────────────────

def fmt_val(val: Any) -> str:
    """Format a value for display — handles None, bool, empty string.

    Args:
        val: The value to format.

    Returns:
        A formatted string.
    """
    if val is None or val == "" or val == "N/A":
        return "[grey62]—[/grey62]"
    if isinstance(val, bool):
        return f"[{SUCCESS}]Yes[/{SUCCESS}]" if val else f"[{ERROR}]No[/{ERROR}]"
    return str(val)


def fmt_num(val: Any) -> str:
    """Format a numeric value, stripping trailing ``.0``.

    Args:
        val: The number to format.

    Returns:
        A cleaned numeric string.
    """
    if val is None:
        return "[grey62]—[/grey62]"
    try:
        f = float(val)
        return str(int(f)) if f == int(f) else str(f)
    except (ValueError, TypeError):
        return str(val)


def label(key: str) -> str:
    """Convert a camelCase API key to a human-readable label.

    Args:
        key: The API field key (e.g. ``firstName``).

    Returns:
        A human-readable label (e.g. ``First Name``).
    """
    return FIELD_LABELS.get(key, key.replace("_", " ").title())


# ── Print Helpers ─────────────────────────────────────────────────────────────

# ── Witty Auth / Status Error Panels ─────────────────────────────────────────

_WITTY_STATUS = {401, 403, 429, 500, 502, 503}

# Status-code → border colour (softer tones so it doesn't look like a crash)
_WITTY_BORDER: dict[int, str] = {
    401: WARNING,   # orange — oops, identity issue
    403: WARNING,   # orange — permission, not a crash
    429: ACCENT,    # blue   — slow down, not broken
    500: ERROR,     # red    — actual server problem
    502: ERROR,
    503: ERROR,
}


def print_api_error(exc: "APIError") -> None:  # type: ignore[name-defined]
    """Render the best error panel for a given APIError.

    Routes 401/403/429/500 through the witty panel from ``ui/messages``.
    Falls back to the plain error panel for all other codes.

    Args:
        exc: The APIError to present to the user.
    """
    from .messages import get_scenario

    status = exc.status_code or 0
    scenario = get_scenario(status) if status in _WITTY_STATUS else None

    if scenario:
        headline, body, hint = scenario
        border = _WITTY_BORDER.get(status, WARNING)
        panel_body = f"{body}\n\n[grey85]{hint}[/grey85]"
        console.print()
        console.print(
            Panel(
                panel_body,
                title=f"[bold {border}]{headline}[/bold {border}]",
                border_style=border,
                expand=False,
                padding=(1, 2),
            )
        )
    else:
        print_error(exc.message, hint=exc.hint)


def print_error(msg: str, hint: str | None = None) -> None:
    """Render a human-friendly error panel (never a raw traceback).

    Shows the error in a bordered panel using Kolay Red with an
    optional recovery hint.

    Args:
        msg: The error message to display.
        hint: An optional recovery suggestion for the user.
    """
    # Strip redundant prefixes the API client may have added
    clean = msg
    for prefix in ("API Error: API Error:", "API Error:", "Request failed:"):
        if clean.startswith(prefix):
            clean = clean[len(prefix):].strip()
            break

    body = f"[bold {ERROR}]{clean}[/bold {ERROR}]"
    if hint:
        body += f"\n\n[grey85]{hint}[/grey85]"

    console.print()
    console.print(
        Panel(body, title=f"[{ERROR}]Error[/{ERROR}]", border_style=ERROR, expand=False, padding=(1, 2))
    )


def print_success(msg: str) -> None:
    """Print a clean success confirmation using Kolay Cheer green.

    Args:
        msg: The success message to display.
    """
    console.print(f"\n[bold {SUCCESS}]  ✔[/bold {SUCCESS}] {msg}\n")


def print_fetching(msg: str) -> None:
    """Print a dim loading hint (prefer ``spinner`` or ``api_call`` instead).

    Args:
        msg: The loading message.
    """
    console.print(f"[grey62]  {msg}[/grey62]")


def print_empty(entity: str, hint: str | None = None) -> None:
    """Print a context-aware empty-state message.

    Args:
        entity: The name of the entity (e.g. ``employees``).
        hint: An optional hint for the user.
    """
    console.print(f"\n[grey62]  No {entity} found.[/grey62]")
    if hint:
        console.print(f"  [grey62]→ {hint}[/grey62]")
    console.print()


# ── Tables ────────────────────────────────────────────────────────────────────

def kv_table(data: dict[str, Any], exclude: list[str] | None = None) -> Table:
    """Build a key-value detail table from an API response dict.

    Args:
        data: The dictionary to display.
        exclude: Keys to omit from the table.

    Returns:
        A rich ``Table`` ready to print.
    """
    exclude = exclude or []
    table = Table(show_header=False, box=None, padding=(0, 2, 0, 0), expand=False)
    table.add_column("Key", style="grey85", no_wrap=True, min_width=16)
    table.add_column("Value")
    for k, v in data.items():
        if k in exclude or isinstance(v, (dict, list)):
            continue
        table.add_row(label(k), fmt_val(v))
    return table
