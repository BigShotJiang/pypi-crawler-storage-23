from __future__ import annotations

DEFAULT_BASE_URL = "https://spot.rackspace.com"
DEFAULT_OAUTH_URL = "https://login.spot.rackspace.com"
DEFAULT_CLIENT_ID = "mwG3lUMV8KyeMqHe4fJ5Bb3nM1vBvRNa"

DEFAULT_CONFIG_DIR = "~/.config/rsspot"
DEFAULT_CONFIG_FILE = "~/.config/rsspot/config.yml"
DEFAULT_LEGACY_CONFIG_FILE = "~/.spot_config"
