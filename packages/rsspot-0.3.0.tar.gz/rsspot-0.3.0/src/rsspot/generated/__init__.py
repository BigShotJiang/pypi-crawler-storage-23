"""Generated models package (reserved for OpenAPI codegen artifacts)."""
