"""Persistent state primitives."""

from rsspot.state.store import StateStore, default_state_path

__all__ = ["StateStore", "default_state_path"]
