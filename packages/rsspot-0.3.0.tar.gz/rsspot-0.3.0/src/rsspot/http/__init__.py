"""HTTP transport primitives."""

from rsspot.http.transport import SpotTransport

__all__ = ["SpotTransport"]
