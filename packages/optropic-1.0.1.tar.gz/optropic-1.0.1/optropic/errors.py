from __future__ import annotations


class OptropicError(Exception):
    """Base error for all Optropic API errors."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"message={self.message!r}, "
            f"status_code={self.status_code!r}, "
            f"code={self.code!r})"
        )


class AuthenticationError(OptropicError):
    """Raised when the API key is missing or invalid (HTTP 401)."""

    def __init__(self, message: str = "Authentication failed", code: str | None = None) -> None:
        super().__init__(message=message, status_code=401, code=code)


class ForbiddenError(OptropicError):
    """Raised when the caller lacks permission for the requested action (HTTP 403)."""

    def __init__(self, message: str = "Forbidden", code: str | None = None) -> None:
        super().__init__(message=message, status_code=403, code=code)


class NotFoundError(OptropicError):
    """Raised when the requested resource does not exist (HTTP 404)."""

    def __init__(self, message: str = "Not found", code: str | None = None) -> None:
        super().__init__(message=message, status_code=404, code=code)


class ValidationError(OptropicError):
    """Raised when the request payload fails validation (HTTP 400)."""

    def __init__(self, message: str = "Validation error", code: str | None = None) -> None:
        super().__init__(message=message, status_code=400, code=code)


class RateLimitError(OptropicError):
    """Raised when the caller has exceeded the allowed request rate (HTTP 429)."""

    def __init__(self, message: str = "Rate limit exceeded", code: str | None = None) -> None:
        super().__init__(message=message, status_code=429, code=code)
