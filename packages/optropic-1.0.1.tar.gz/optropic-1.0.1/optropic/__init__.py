"""Optropic Python SDK -- official client for the Optropic Trust API."""

from .client import Optropic
from .errors import (
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    OptropicError,
    RateLimitError,
    ValidationError,
)
from .types import (
    ApiKeyMeta,
    Asset,
    AssetDetail,
    AssetSeal,
    AuditEvent,
    ChainVerifyResult,
    ComplianceConfig,
    CreateAssetParams,
    CreateKeyParams,
    CreateWebhookParams,
    ExportParams,
    ExportResult,
    ListAssetsParams,
    ListAuditParams,
    MerkleProof,
    MerkleRoot,
    RevokeAssetParams,
    UpdateAssetParams,
    VerificationResult,
    WebhookDelivery,
    WebhookEndpoint,
)
from .webhook_verify import verify_webhook_signature

__all__ = [
    # Client
    "Optropic",
    # Errors
    "OptropicError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    # Types -- params
    "CreateAssetParams",
    "UpdateAssetParams",
    "RevokeAssetParams",
    "ListAssetsParams",
    "ListAuditParams",
    "ExportParams",
    "CreateWebhookParams",
    "CreateKeyParams",
    # Types -- responses
    "AssetSeal",
    "Asset",
    "AssetDetail",
    "AuditEvent",
    "ChainVerifyResult",
    "MerkleRoot",
    "MerkleProof",
    "ExportResult",
    "ComplianceConfig",
    "VerificationResult",
    "WebhookEndpoint",
    "WebhookDelivery",
    "ApiKeyMeta",
    # Webhook verification
    "verify_webhook_signature",
]
