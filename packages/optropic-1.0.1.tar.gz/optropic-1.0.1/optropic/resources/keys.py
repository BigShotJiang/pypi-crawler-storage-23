from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, List, TYPE_CHECKING

from ..types import ApiKeyMeta, CreateKeyParams

if TYPE_CHECKING:
    from ..client import Optropic


class Keys:
    """Manage API keys for your tenant."""

    def __init__(self, client: Optropic) -> None:
        self._client = client

    def create(self, params: CreateKeyParams) -> Dict[str, Any]:
        """Create a new API key.

        Returns the full key value (shown only once), a warning message,
        and key metadata.
        """
        return self._client._request("POST", "/keys", json=asdict(params))

    def list(self) -> List[ApiKeyMeta]:
        """List all API keys for the current tenant."""
        data = self._client._request("GET", "/keys")
        return [ApiKeyMeta(**item) for item in data]

    def revoke(self, key_id: str) -> Dict[str, Any]:
        """Revoke an API key."""
        return self._client._request("DELETE", f"/keys/{key_id}")

    def update(self, key_id: str, label: str) -> Dict[str, Any]:
        """Update the label of an API key."""
        return self._client._request(
            "PATCH",
            f"/keys/{key_id}",
            json={"label": label},
        )
