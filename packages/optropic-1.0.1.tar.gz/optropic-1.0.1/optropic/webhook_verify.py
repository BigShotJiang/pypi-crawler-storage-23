from __future__ import annotations

import hashlib
import hmac


def verify_webhook_signature(
    payload: str,
    signature_header: str,
    secret: str,
) -> bool:
    """Verify the cryptographic signature on an incoming webhook request.

    Args:
        payload: The raw request body as a string.
        signature_header: The value of the ``X-Optropic-Signature`` header.
        secret: The webhook signing secret provided when the endpoint was
            created.

    Returns:
        ``True`` if the signature is valid, ``False`` otherwise.
    """
    if not signature_header or not signature_header.startswith("sha256="):
        return False

    expected_hex = signature_header[len("sha256="):]
    computed = hmac.new(
        secret.encode("utf-8"),
        payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()

    return hmac.compare_digest(computed, expected_hex)
