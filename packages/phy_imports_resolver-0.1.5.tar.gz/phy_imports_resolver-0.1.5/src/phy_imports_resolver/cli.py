""" cli app by `click` """
# imports
from pathlib import Path
from typing import Literal, Annotated

# import optional dependencies
try:
    import typer
    from rich.console import Console
    from graphviz import Digraph

except ImportError as err:
    raise SystemExit(
        'The CLI requires extra dependencies. ' +
        'Please install with `pip install phy-imports-resolver[cli]`.'
    ) from err

# local imports
from phy_imports_resolver.types import ModuleImportsNode
from phy_imports_resolver import ImportResolver

# CLI app
cli_app = typer.Typer()
console = Console()


def _add_children_to_diagram(
        diagram: Digraph, 
        node: ModuleImportsNode, 
        parent_node: ModuleImportsNode = None
    ) -> None:
    """ recursively add imported modules to diagram """
    diagram.node(str(id(node)), node.name, shape='box')
    if parent_node is not None:
        diagram.edge(str(id(parent_node)), str(id(node)))
    for _child in node.imports:
        _add_children_to_diagram(diagram, _child, node)


def _mod_imports_node_to_diagram(mod_imports_node: ModuleImportsNode, output_path: Path, fmt: str = 'png') -> Digraph:
    """ generate `graphviz` diagram by module imports tree """
    diagram = Digraph(comment=mod_imports_node.name, format=fmt)
    diagram.attr('node', shape='box')
    diagram.attr(rankdir='TB')  # layout: from top to bottom

    _add_children_to_diagram(diagram, mod_imports_node)
    diagram.render(output_path.with_suffix(''), view=True)  # graphviz will add `fmt` as suffix
    print(f'Diagram image saved to {output_path}.')


@cli_app.command()
def cli_endpoint_main(
        file: Path = typer.Argument(
            ...,
            exists=True,
            help=(
                'Path of the entry file; to resolve package, '
                'use path of the `__init__.py` file of the package'
            )
        ),
        verbose: bool = typer.Option(
            False,
            "--verbose",
            "-v",
            help="Print verbose log",
        ),
        output_format: Annotated[
            Literal['xml', 'png', 'svg'], 
            typer.Option(
                '--format',
                '-f',
                help='Specify the output format',
                case_sensitive=False,
                rich_help_panel=None,
            )
        ] = 'xml',
        output: Path = typer.Option(
            None,
            "--output",
            "-o",
            help="Optional output file path.",
        ),
    ):
    """ Resolve the imports of a python file or module, recursively. """
    project_dir = Path.cwd().resolve()
    resolver = ImportResolver(project_dir=project_dir, verbose_logging=verbose)

    with console.status('fetching ...', spinner='line'):
        entry_file_path = Path(file).resolve()
        resolved_node = resolver.start(entry_file_path)

    # if no output specified, print xml to stdout
    resolved_tree_repr = str(resolved_node)
    if output is None:
        typer.echo(resolved_tree_repr)

    # if output specified, output to file
    else:
        output_path = Path(output).resolve()
        # output to xml
        if output_format == 'xml':
            with open(output_path, 'w', encoding='utf8') as _f:
                _f.write(resolved_tree_repr)

        # output to diagram with `graphviz`
        elif output_format in ('png', 'svg'):
            _mod_imports_node_to_diagram(resolved_node, output_path, fmt=output_format)

        else:
            raise NotImplementedError


def main():
    """ expose method entry to `pyproject.toml` script spec """
    cli_app()
