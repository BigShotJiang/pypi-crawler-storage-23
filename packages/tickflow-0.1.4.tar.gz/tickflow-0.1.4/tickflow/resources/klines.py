"""K-line (OHLCV) data resources for TickFlow API."""

from __future__ import annotations

import asyncio
import concurrent.futures
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Literal,
    Optional,
    Tuple,
    Union,
    overload,
)

from .._cache import InstrumentNameCache
from .._types import NOT_GIVEN, NotGiven
from ..utils import (
    instrument_timestamp_to_trade_date,
    instrument_timestamp_to_trade_time,
)
from ._base import AsyncResource, SyncResource

if TYPE_CHECKING:
    import pandas as pd

    from ..generated_model import CompactKlineData, Period

# Maximum symbols per batch request (API limit)
MAX_SYMBOLS_PER_BATCH = 100


def _klines_to_dataframe(
    data: "CompactKlineData",
    symbol: Optional[str] = None,
    name: Optional[str] = None,
) -> "pd.DataFrame":
    """Convert compact K-line data to a pandas DataFrame.

    Parameters
    ----------
    data : CompactKlineData
        Compact columnar K-line data from the API.
    symbol : str, optional
        Symbol code to include as a column.
    name : str, optional
        Instrument name to include as a column.

    Returns
    -------
    pd.DataFrame
        DataFrame with columns: timestamp, open, high, low, close, volume, amount.
    """
    import pandas as pd

    df = pd.DataFrame(
        {
            "timestamp": data["timestamp"],
            "trade_date": [
                instrument_timestamp_to_trade_date(symbol, x) for x in data["timestamp"]
            ],
            "trade_time": [
                instrument_timestamp_to_trade_time(symbol, x) for x in data["timestamp"]
            ],
            "open": data["open"],
            "high": data["high"],
            "low": data["low"],
            "close": data["close"],
            "volume": data["volume"],
            "amount": data.get("amount", [0.0] * len(data["timestamp"])),
        }
    )

    if symbol:
        df.insert(0, "symbol", symbol)
    if name:
        col_idx = 1 if symbol else 0
        df.insert(col_idx, "name", name)

    return df


def _batch_klines_to_dataframes(
    data: Dict[str, "CompactKlineData"],
    names: Optional[Dict[str, str]] = None,
) -> Dict[str, "pd.DataFrame"]:
    """Convert batch K-line data to DataFrames with optional name column.

    Parameters
    ----------
    data : dict
        Dictionary mapping symbol codes to compact K-line data.
    names : dict, optional
        Dictionary mapping symbol codes to instrument names.

    Returns
    -------
    dict of str to pd.DataFrame
        Dictionary mapping symbol codes to pandas DataFrames.
    """
    names = names or {}
    dfs: Dict[str, "pd.DataFrame"] = {}
    for symbol, kline_data in data.items():
        df = _klines_to_dataframe(kline_data, symbol=symbol, name=names.get(symbol))
        dfs[symbol] = df

    return dfs


def _chunk_list(lst: List[str], chunk_size: int) -> List[List[str]]:
    """Split a list into chunks of specified size.

    Parameters
    ----------
    lst : list
        The list to chunk.
    chunk_size : int
        Maximum size of each chunk.

    Returns
    -------
    list of list
        List of chunks.
    """
    return [lst[i : i + chunk_size] for i in range(0, len(lst), chunk_size)]


def _get_progress_bar(total: int, desc: str, show_progress: bool):
    """Get a progress bar iterator or a simple range.

    Parameters
    ----------
    total : int
        Total number of items.
    desc : str
        Description for the progress bar.
    show_progress : bool
        Whether to show the progress bar.

    Returns
    -------
    iterator
        tqdm progress bar or range.
    """
    if show_progress:
        try:
            from tqdm.auto import tqdm

            return tqdm(total=total, desc=desc, leave=False)
        except ImportError:
            # tqdm not installed, fall back to no progress bar
            pass
    return None


class Klines(SyncResource):
    """Synchronous interface for K-line (OHLCV) data endpoints.

    Supports returning data as raw dicts or pandas DataFrames.
    When returning DataFrames, instrument names are automatically resolved
    from a local cache (fetched from the instruments API on first access).

    Examples
    --------
    >>> client = TickFlow(api_key="your-key")
    >>>
    >>> # Get raw K-line data
    >>> klines = client.klines.get("600000.SH", count=100)
    >>>
    >>> # Get as DataFrame (includes name column)
    >>> df = client.klines.get("600000.SH", count=100, as_dataframe=True)
    >>> print(df.head())
    """

    _instrument_cache: Optional[InstrumentNameCache]

    def __init__(
        self, client: Any, instrument_cache: Optional[InstrumentNameCache] = None
    ) -> None:
        super().__init__(client)
        self._instrument_cache = instrument_cache

    def _resolve_name(self, symbol: str) -> Optional[str]:
        if not self._instrument_cache:
            return None
        names = self._instrument_cache.resolve_sync([symbol], self._client)
        return names.get(symbol)

    def _resolve_names(self, symbols: List[str]) -> Dict[str, str]:
        if not self._instrument_cache:
            return {}
        return self._instrument_cache.resolve_sync(symbols, self._client)

    @overload
    def get(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[False] = False,
    ) -> "CompactKlineData": ...

    @overload
    def get(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[True],
    ) -> "pd.DataFrame": ...

    def get(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: bool = False,
    ) -> Union["CompactKlineData", "pd.DataFrame"]:
        """Get K-line (OHLCV) data for a single symbol.

        Parameters
        ----------
        symbol : str
            Symbol code (e.g., "600000.SH", "AAPL.US").
        period : str, optional
            K-line period. One of: "1m", "5m", "10m", "15m", "30m", "60m",
            "4h", "1d", "1w", "1M". Defaults to "1d".
        count : int, optional
            Number of K-lines to return. Default 100, max 10000.
        start_time : int, optional
            Start timestamp in milliseconds.
        end_time : int, optional
            End timestamp in milliseconds.
        as_dataframe : bool, optional
            If True, return a pandas DataFrame. If False (default), return
            the raw compact columnar data.

        Returns
        -------
        CompactKlineData or pd.DataFrame
            If as_dataframe=False: dict with keys 'timestamp', 'open', 'high',
            'low', 'close', 'volume', 'amount' (each a list).
            If as_dataframe=True: pandas DataFrame with datetime index.

        Examples
        --------
        >>> # Get raw data
        >>> data = client.klines.get("600000.SH", period="1d", count=10)
        >>> print(data["close"][-1])  # Latest close price

        >>> # Get as DataFrame for analysis
        >>> df = client.klines.get("600000.SH", period="1d", count=100, as_dataframe=True)
        >>> print(df.tail())
        >>>
        >>> # Calculate 20-day moving average
        >>> df["ma20"] = df["close"].rolling(20).mean()
        """
        params: Dict[str, Any] = {"symbol": symbol}
        if not isinstance(period, NotGiven):
            params["period"] = period
        if not isinstance(count, NotGiven):
            params["count"] = count
        if not isinstance(start_time, NotGiven) and start_time is not None:
            params["start_time"] = start_time
        if not isinstance(end_time, NotGiven) and end_time is not None:
            params["end_time"] = end_time

        response = self._client.get("/v1/klines", params=params)
        data = response["data"]

        if as_dataframe:
            name = self._resolve_name(symbol)
            return _klines_to_dataframe(data, symbol=symbol, name=name)
        return data

    def _fetch_batch_chunk(
        self,
        symbols: List[str],
        params: Dict[str, Any],
        endpoint: str = "/v1/klines/batch",
    ) -> Tuple[Dict[str, "CompactKlineData"], List[Tuple[str, Exception]]]:
        """Fetch a single batch chunk.

        Returns
        -------
        tuple
            (data dict, list of (symbol, error) for failed symbols)
        """
        symbols_str = ",".join(symbols)
        chunk_params = {**params, "symbols": symbols_str}

        response = self._client.get(endpoint, params=chunk_params)
        return response["data"], []

    def _run_batch(
        self,
        symbols: List[str],
        params: Dict[str, Any],
        endpoint: str,
        batch_size: int,
        as_dataframe: bool,
        show_progress: bool,
        max_workers: int,
        progress_desc: str = "Fetching K-lines",
    ) -> Union[Dict[str, "CompactKlineData"], "pd.DataFrame"]:
        if not symbols:
            return {} if not as_dataframe else _batch_klines_to_dataframes({})

        chunks = _chunk_list(symbols, batch_size)

        if len(chunks) == 1:
            data, errors = self._fetch_batch_chunk(chunks[0], params, endpoint)
            if as_dataframe:
                names = self._resolve_names(list(data.keys()))
                return _batch_klines_to_dataframes(data, names=names)
            return data

        pbar = _get_progress_bar(len(chunks), progress_desc, show_progress)

        all_data: Dict[str, "CompactKlineData"] = {}
        all_errors: List[Tuple[str, Exception]] = []

        try:
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=max_workers
            ) as executor:
                futures = {
                    executor.submit(
                        self._fetch_batch_chunk, chunk, params, endpoint
                    ): chunk
                    for chunk in chunks
                }

                for future in concurrent.futures.as_completed(futures):
                    try:
                        data, errors = future.result()
                        all_data.update(data)
                        all_errors.extend(errors)
                    except Exception as e:
                        chunk = futures[future]
                        all_errors.extend((s, e) for s in chunk)

                    if pbar:
                        pbar.update(1)
        finally:
            if pbar:
                pbar.close()

        if as_dataframe:
            names = self._resolve_names(list(all_data.keys()))
            return _batch_klines_to_dataframes(all_data, names=names)
        return all_data

    @overload
    def batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[False] = False,
        show_progress: bool = False,
        max_workers: int = 5,
        batch_size: int = MAX_SYMBOLS_PER_BATCH,
    ) -> Dict[str, "CompactKlineData"]: ...

    @overload
    def batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[True],
        show_progress: bool = False,
        max_workers: int = 5,
        batch_size: int = MAX_SYMBOLS_PER_BATCH,
    ) -> "pd.DataFrame": ...

    def batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: bool = False,
        show_progress: bool = False,
        max_workers: int = 5,
        batch_size: int = MAX_SYMBOLS_PER_BATCH,
    ) -> Union[Dict[str, "CompactKlineData"], "pd.DataFrame"]:
        """Get K-line data for multiple symbols in batched concurrent requests.

        Automatically splits large symbol lists into chunks and fetches them
        concurrently. Failed chunks don't affect other chunks.

        Parameters
        ----------
        symbols : list of str
            List of symbol codes.
        period : str, optional
            K-line period. Defaults to "1d".
        count : int, optional
            Number of K-lines per symbol. Default 100.
        start_time : int, optional
            Start timestamp in milliseconds.
        end_time : int, optional
            End timestamp in milliseconds.
        as_dataframe : bool, optional
            If True, return dict of DataFrames. Default False.
        show_progress : bool, optional
            If True, display a progress bar (requires tqdm). Default False.
        max_workers : int, optional
            Maximum number of concurrent requests. Default 5.
        batch_size : int, optional
            Number of symbols per request. Default 100.
            Reduce this if the server enforces a lower per-request limit.

        Returns
        -------
        dict or pd.DataFrame
            If as_dataframe=False: dict mapping symbol codes to CompactKlineData.
            If as_dataframe=True: dict mapping symbol codes to DataFrames.

        Examples
        --------
        >>> symbols = client.exchanges.get_symbols("SH")[:500]
        >>> dfs = client.klines.batch(symbols, as_dataframe=True, show_progress=True)
        """
        params: Dict[str, Any] = {}
        if not isinstance(period, NotGiven):
            params["period"] = period
        if not isinstance(count, NotGiven):
            params["count"] = count
        if not isinstance(start_time, NotGiven) and start_time is not None:
            params["start_time"] = start_time
        if not isinstance(end_time, NotGiven) and end_time is not None:
            params["end_time"] = end_time

        return self._run_batch(
            symbols=symbols,
            params=params,
            endpoint="/v1/klines/batch",
            batch_size=batch_size,
            as_dataframe=as_dataframe,
            show_progress=show_progress,
            max_workers=max_workers,
            progress_desc="Fetching K-lines",
        )

    @overload
    def intraday(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[False] = False,
    ) -> "CompactKlineData": ...

    @overload
    def intraday(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[True],
    ) -> "pd.DataFrame": ...

    def intraday(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        as_dataframe: bool = False,
    ) -> Union["CompactKlineData", "pd.DataFrame"]:
        """Get intraday minute K-line data for a single symbol.

        This endpoint returns today's minute-level K-line data. The data is
        continuously updated during trading hours.

        Parameters
        ----------
        symbol : str
            Symbol code (e.g., "600000.SH", "AAPL.US").
        period : str, optional
            K-line period. One of: "1m", "5m", "15m", "30m", "60m".
            Defaults to "1m".
        count : int, optional
            Number of K-lines to return. If not specified, returns all
            available data for today.
        as_dataframe : bool, optional
            If True, return a pandas DataFrame. If False (default), return
            the raw compact columnar data.

        Returns
        -------
        CompactKlineData or pd.DataFrame
            If as_dataframe=False: dict with keys 'timestamp', 'open', 'high',
            'low', 'close', 'volume', 'amount' (each a list).
            If as_dataframe=True: pandas DataFrame with datetime index.

        Examples
        --------
        >>> # Get today's 1-minute K-lines
        >>> data = client.klines.intraday("600000.SH")
        >>> print(f"Got {len(data['timestamp'])} bars")

        >>> # Get as DataFrame
        >>> df = client.klines.intraday("600000.SH", as_dataframe=True)
        >>> print(df.tail())

        >>> # Get 5-minute aggregated data
        >>> df = client.klines.intraday("600000.SH", period="5m", as_dataframe=True)
        """
        params: Dict[str, Any] = {"symbol": symbol}
        if not isinstance(period, NotGiven):
            params["period"] = period
        if not isinstance(count, NotGiven):
            params["count"] = count

        response = self._client.get("/v1/klines/intraday", params=params)
        data = response["data"]

        if as_dataframe:
            name = self._resolve_name(symbol)
            return _klines_to_dataframe(data, symbol=symbol, name=name)
        return data

    @overload
    def intraday_batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[False] = False,
        show_progress: bool = False,
        max_workers: int = 5,
        batch_size: int = MAX_SYMBOLS_PER_BATCH,
    ) -> Dict[str, "CompactKlineData"]: ...

    @overload
    def intraday_batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[True],
        show_progress: bool = False,
        max_workers: int = 5,
        batch_size: int = MAX_SYMBOLS_PER_BATCH,
    ) -> "pd.DataFrame": ...

    def intraday_batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        as_dataframe: bool = False,
        show_progress: bool = False,
        max_workers: int = 5,
        batch_size: int = MAX_SYMBOLS_PER_BATCH,
    ) -> Union[Dict[str, "CompactKlineData"], "pd.DataFrame"]:
        """Get intraday K-line data for multiple symbols in batched concurrent requests.

        Automatically splits large symbol lists into chunks and fetches them
        concurrently. Failed chunks don't affect other chunks.

        Parameters
        ----------
        symbols : list of str
            List of symbol codes.
        period : str, optional
            K-line period. One of: "1m", "5m", "15m", "30m", "60m".
            Defaults to "1m".
        count : int, optional
            Number of K-lines per symbol. If not specified, returns all
            available data for today.
        as_dataframe : bool, optional
            If True, return dict of DataFrames. Default False.
        show_progress : bool, optional
            If True, display a progress bar (requires tqdm). Default False.
        max_workers : int, optional
            Maximum number of concurrent requests. Default 5.
        batch_size : int, optional
            Number of symbols per request. Default 100.
            Reduce this if the server enforces a lower per-request limit.

        Returns
        -------
        dict or pd.DataFrame
            If as_dataframe=False: dict mapping symbol codes to CompactKlineData.
            If as_dataframe=True: dict mapping symbol codes to DataFrames.

        Examples
        --------
        >>> symbols = ["600000.SH", "000001.SZ", "600519.SH"]
        >>> dfs = client.klines.intraday_batch(symbols, as_dataframe=True)
        """
        params: Dict[str, Any] = {}
        if not isinstance(period, NotGiven):
            params["period"] = period
        if not isinstance(count, NotGiven):
            params["count"] = count

        return self._run_batch(
            symbols=symbols,
            params=params,
            endpoint="/v1/klines/intraday/batch",
            batch_size=batch_size,
            as_dataframe=as_dataframe,
            show_progress=show_progress,
            max_workers=max_workers,
            progress_desc="Fetching intraday K-lines",
        )


class AsyncKlines(AsyncResource):
    """Asynchronous interface for K-line (OHLCV) data endpoints.

    Supports returning data as raw dicts or pandas DataFrames.
    When returning DataFrames, instrument names are automatically resolved
    from a local cache (fetched from the instruments API on first access).

    Examples
    --------
    >>> async with AsyncTickFlow(api_key="your-key") as client:
    ...     # Get raw K-line data
    ...     klines = await client.klines.get("600000.SH", count=100)
    ...
    ...     # Get as DataFrame (includes name column)
    ...     df = await client.klines.get("600000.SH", count=100, as_dataframe=True)
    """

    _instrument_cache: Optional[InstrumentNameCache]

    def __init__(
        self, client: Any, instrument_cache: Optional[InstrumentNameCache] = None
    ) -> None:
        super().__init__(client)
        self._instrument_cache = instrument_cache

    async def _resolve_name(self, symbol: str) -> Optional[str]:
        if not self._instrument_cache:
            return None
        names = await self._instrument_cache.resolve_async([symbol], self._client)
        return names.get(symbol)

    async def _resolve_names(self, symbols: List[str]) -> Dict[str, str]:
        if not self._instrument_cache:
            return {}
        return await self._instrument_cache.resolve_async(symbols, self._client)

    @overload
    async def get(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[False] = False,
    ) -> "CompactKlineData": ...

    @overload
    async def get(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[True],
    ) -> "pd.DataFrame": ...

    async def get(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: bool = False,
    ) -> Union["CompactKlineData", "pd.DataFrame"]:
        """Get K-line (OHLCV) data for a single symbol.

        Parameters
        ----------
        symbol : str
            Symbol code (e.g., "600000.SH", "AAPL.US").
        period : str, optional
            K-line period. One of: "1m", "5m", "10m", "15m", "30m", "60m",
            "4h", "1d", "1w", "1M". Defaults to "1d".
        count : int, optional
            Number of K-lines to return. Default 100, max 10000.
        start_time : int, optional
            Start timestamp in milliseconds.
        end_time : int, optional
            End timestamp in milliseconds.
        as_dataframe : bool, optional
            If True, return a pandas DataFrame. If False (default), return
            the raw compact columnar data.

        Returns
        -------
        CompactKlineData or pd.DataFrame
            If as_dataframe=False: dict with keys 'timestamp', 'open', 'high',
            'low', 'close', 'volume', 'amount' (each a list).
            If as_dataframe=True: pandas DataFrame with datetime index.

        Examples
        --------
        >>> df = await client.klines.get("600000.SH", period="1d", as_dataframe=True)
        >>> print(df.tail())
        """
        params: Dict[str, Any] = {"symbol": symbol}
        if not isinstance(period, NotGiven):
            params["period"] = period
        if not isinstance(count, NotGiven):
            params["count"] = count
        if not isinstance(start_time, NotGiven) and start_time is not None:
            params["start_time"] = start_time
        if not isinstance(end_time, NotGiven) and end_time is not None:
            params["end_time"] = end_time

        response = await self._client.get("/v1/klines", params=params)
        data = response["data"]

        if as_dataframe:
            name = await self._resolve_name(symbol)
            return _klines_to_dataframe(data, symbol=symbol, name=name)
        return data

    async def _fetch_batch_chunk(
        self,
        symbols: List[str],
        params: Dict[str, Any],
        endpoint: str = "/v1/klines/batch",
    ) -> Tuple[Dict[str, "CompactKlineData"], List[Tuple[str, Exception]]]:
        """Fetch a single batch chunk asynchronously.

        Returns
        -------
        tuple
            (data dict, list of (symbol, error) for failed symbols)
        """
        symbols_str = ",".join(symbols)
        chunk_params = {**params, "symbols": symbols_str}

        try:
            response = await self._client.get(endpoint, params=chunk_params)
            return response["data"], []
        except Exception as e:
            return {}, [(s, e) for s in symbols]

    async def _run_batch(
        self,
        symbols: List[str],
        params: Dict[str, Any],
        endpoint: str,
        batch_size: int,
        as_dataframe: bool,
        show_progress: bool,
        max_concurrency: int,
        progress_desc: str = "Fetching K-lines",
    ) -> Union[Dict[str, "CompactKlineData"], "pd.DataFrame"]:
        if not symbols:
            return {} if not as_dataframe else _batch_klines_to_dataframes({})

        chunks = _chunk_list(symbols, batch_size)

        if len(chunks) == 1:
            data, errors = await self._fetch_batch_chunk(chunks[0], params, endpoint)
            if as_dataframe:
                names = await self._resolve_names(list(data.keys()))
                return _batch_klines_to_dataframes(data, names=names)
            return data

        pbar = _get_progress_bar(len(chunks), progress_desc, show_progress)
        semaphore = asyncio.Semaphore(max_concurrency)

        async def fetch_with_semaphore(
            chunk: List[str],
        ) -> Tuple[Dict[str, "CompactKlineData"], List[Tuple[str, Exception]]]:
            async with semaphore:
                result = await self._fetch_batch_chunk(chunk, params, endpoint)
                if pbar:
                    pbar.update(1)
                return result

        all_data: Dict[str, "CompactKlineData"] = {}
        all_errors: List[Tuple[str, Exception]] = []

        try:
            tasks = [fetch_with_semaphore(chunk) for chunk in chunks]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    all_errors.extend((s, result) for s in chunks[i])
                else:
                    data, errors = result
                    all_data.update(data)
                    all_errors.extend(errors)
        finally:
            if pbar:
                pbar.close()

        if as_dataframe:
            names = await self._resolve_names(list(all_data.keys()))
            return _batch_klines_to_dataframes(all_data, names=names)
        return all_data

    @overload
    async def batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[False] = False,
        show_progress: bool = False,
        max_concurrency: int = 5,
        batch_size: int = MAX_SYMBOLS_PER_BATCH,
    ) -> Dict[str, "CompactKlineData"]: ...

    @overload
    async def batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[True],
        show_progress: bool = False,
        max_concurrency: int = 5,
        batch_size: int = MAX_SYMBOLS_PER_BATCH,
    ) -> "pd.DataFrame": ...

    async def batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        start_time: Union[int, None, NotGiven] = NOT_GIVEN,
        end_time: Union[int, None, NotGiven] = NOT_GIVEN,
        as_dataframe: bool = False,
        show_progress: bool = False,
        max_concurrency: int = 5,
        batch_size: int = MAX_SYMBOLS_PER_BATCH,
    ) -> Union[Dict[str, "CompactKlineData"], "pd.DataFrame"]:
        """Get K-line data for multiple symbols in batched concurrent requests.

        Automatically splits large symbol lists into chunks and fetches them
        concurrently. Failed chunks don't affect other chunks.

        Parameters
        ----------
        symbols : list of str
            List of symbol codes.
        period : str, optional
            K-line period. Defaults to "1d".
        count : int, optional
            Number of K-lines per symbol. Default 100.
        start_time : int, optional
            Start timestamp in milliseconds.
        end_time : int, optional
            End timestamp in milliseconds.
        as_dataframe : bool, optional
            If True, return dict of DataFrames. Default False.
        show_progress : bool, optional
            If True, display a progress bar (requires tqdm). Default False.
        max_concurrency : int, optional
            Maximum number of concurrent requests. Default 5.
        batch_size : int, optional
            Number of symbols per request. Default 100.
            Reduce this if the server enforces a lower per-request limit.

        Returns
        -------
        dict or pd.DataFrame
            If as_dataframe=False: dict mapping symbol codes to CompactKlineData.
            If as_dataframe=True: dict mapping symbol codes to DataFrames.

        Examples
        --------
        >>> symbols = await client.exchanges.get_symbols("SH")
        >>> dfs = await client.klines.batch(symbols[:500], as_dataframe=True, show_progress=True)
        """
        params: Dict[str, Any] = {}
        if not isinstance(period, NotGiven):
            params["period"] = period
        if not isinstance(count, NotGiven):
            params["count"] = count
        if not isinstance(start_time, NotGiven) and start_time is not None:
            params["start_time"] = start_time
        if not isinstance(end_time, NotGiven) and end_time is not None:
            params["end_time"] = end_time

        return await self._run_batch(
            symbols=symbols,
            params=params,
            endpoint="/v1/klines/batch",
            batch_size=batch_size,
            as_dataframe=as_dataframe,
            show_progress=show_progress,
            max_concurrency=max_concurrency,
            progress_desc="Fetching K-lines",
        )

    @overload
    async def intraday(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[False] = False,
    ) -> "CompactKlineData": ...

    @overload
    async def intraday(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[True],
    ) -> "pd.DataFrame": ...

    async def intraday(
        self,
        symbol: str,
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        as_dataframe: bool = False,
    ) -> Union["CompactKlineData", "pd.DataFrame"]:
        """Get intraday minute K-line data for a single symbol.

        This endpoint returns today's minute-level K-line data. The data is
        continuously updated during trading hours.

        Parameters
        ----------
        symbol : str
            Symbol code (e.g., "600000.SH", "AAPL.US").
        period : str, optional
            K-line period. One of: "1m", "5m", "15m", "30m", "60m".
            Defaults to "1m".
        count : int, optional
            Number of K-lines to return. If not specified, returns all
            available data for today.
        as_dataframe : bool, optional
            If True, return a pandas DataFrame. If False (default), return
            the raw compact columnar data.

        Returns
        -------
        CompactKlineData or pd.DataFrame
            If as_dataframe=False: dict with keys 'timestamp', 'open', 'high',
            'low', 'close', 'volume', 'amount' (each a list).
            If as_dataframe=True: pandas DataFrame with datetime index.

        Examples
        --------
        >>> # Get today's 1-minute K-lines
        >>> data = await client.klines.intraday("600000.SH")
        >>> print(f"Got {len(data['timestamp'])} bars")

        >>> # Get as DataFrame
        >>> df = await client.klines.intraday("600000.SH", as_dataframe=True)
        >>> print(df.tail())
        """
        params: Dict[str, Any] = {"symbol": symbol}
        if not isinstance(period, NotGiven):
            params["period"] = period
        if not isinstance(count, NotGiven):
            params["count"] = count

        response = await self._client.get("/v1/klines/intraday", params=params)
        data = response["data"]

        if as_dataframe:
            name = await self._resolve_name(symbol)
            return _klines_to_dataframe(data, symbol=symbol, name=name)
        return data

    @overload
    async def intraday_batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[False] = False,
        show_progress: bool = False,
        max_concurrency: int = 5,
        batch_size: int = MAX_SYMBOLS_PER_BATCH,
    ) -> Dict[str, "CompactKlineData"]: ...

    @overload
    async def intraday_batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        as_dataframe: Literal[True],
        show_progress: bool = False,
        max_concurrency: int = 5,
        batch_size: int = MAX_SYMBOLS_PER_BATCH,
    ) -> "pd.DataFrame": ...

    async def intraday_batch(
        self,
        symbols: List[str],
        *,
        period: Union["Period", NotGiven] = NOT_GIVEN,
        count: Union[int, NotGiven] = NOT_GIVEN,
        as_dataframe: bool = False,
        show_progress: bool = False,
        max_concurrency: int = 5,
        batch_size: int = MAX_SYMBOLS_PER_BATCH,
    ) -> Union[Dict[str, "CompactKlineData"], "pd.DataFrame"]:
        """Get intraday K-line data for multiple symbols in batched concurrent requests.

        Automatically splits large symbol lists into chunks and fetches them
        concurrently. Failed chunks don't affect other chunks.

        Parameters
        ----------
        symbols : list of str
            List of symbol codes.
        period : str, optional
            K-line period. One of: "1m", "5m", "15m", "30m", "60m".
            Defaults to "1m".
        count : int, optional
            Number of K-lines per symbol. If not specified, returns all
            available data for today.
        as_dataframe : bool, optional
            If True, return dict of DataFrames. Default False.
        show_progress : bool, optional
            If True, display a progress bar (requires tqdm). Default False.
        max_concurrency : int, optional
            Maximum number of concurrent requests. Default 5.
        batch_size : int, optional
            Number of symbols per request. Default 100.
            Reduce this if the server enforces a lower per-request limit.

        Returns
        -------
        dict or pd.DataFrame
            If as_dataframe=False: dict mapping symbol codes to CompactKlineData.
            If as_dataframe=True: dict mapping symbol codes to DataFrames.

        Examples
        --------
        >>> symbols = ["600000.SH", "000001.SZ", "600519.SH"]
        >>> dfs = await client.klines.intraday_batch(symbols, as_dataframe=True)
        """
        params: Dict[str, Any] = {}
        if not isinstance(period, NotGiven):
            params["period"] = period
        if not isinstance(count, NotGiven):
            params["count"] = count

        return await self._run_batch(
            symbols=symbols,
            params=params,
            endpoint="/v1/klines/intraday/batch",
            batch_size=batch_size,
            as_dataframe=as_dataframe,
            show_progress=show_progress,
            max_concurrency=max_concurrency,
            progress_desc="Fetching intraday K-lines",
        )
