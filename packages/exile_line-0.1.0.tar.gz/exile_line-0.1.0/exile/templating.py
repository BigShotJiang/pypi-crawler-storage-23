from __future__ import annotations

import asyncio
from typing import Any

from .context import current_app


def render_template(template_name: str, **context: Any) -> str:
    environment = current_app.get_template_environment()
    template = environment.get_template(template_name)
    return template.render(**context)


async def render_template_async(template_name: str, **context: Any) -> str:
    environment = current_app.get_template_environment()

    def _render() -> str:
        template = environment.get_template(template_name)
        return template.render(**context)

    return await asyncio.to_thread(_render)


def url_for(endpoint: str, **values: Any) -> str:
    return current_app.url_for(endpoint, **values)
