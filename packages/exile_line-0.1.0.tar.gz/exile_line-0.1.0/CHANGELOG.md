# Changelog

All notable changes to this project are documented in this file.

## [0.1.0] - 2026-03-03

### Added
- Async-first `Exile` application core with ASGI HTTP and lifespan handling.
- Flask-style routing decorators with dynamic path converters.
- Request/response abstractions and automatic response coercion.
- Context proxies: `request`, `current_app`, `g`.
- Hook system: before/after/teardown request.
- Error handling for app and blueprint scopes.
- Function and ASGI class middleware support.
- Blueprint modular routing with URL prefixes.
- Static file serving and optional Jinja2 templating helpers.
- URL reverse building via `app.url_for(...)` and template `url_for`.
- Async test client (`AsyncTestClient`) and test response helpers.
- Example app and release workflow docs/scripts.

