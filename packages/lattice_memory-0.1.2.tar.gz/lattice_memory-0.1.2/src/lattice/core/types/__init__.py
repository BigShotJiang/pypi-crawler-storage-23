"""
Core type definitions for Lattice.

All types are pure dataclasses with no logic and no I/O.
Reference: RFC-002 §3 Type Catalog
"""

from lattice.core.types.config import (
    CaptureConfig,
    CompilerConfig,
    Config,
    EmbeddingConfig,
    Layer1Config,
    SafetyConfig,
    ThresholdsConfig,
)
from lattice.core.types.enums import EventType, PatternType, ProposalAction, Role, Scope
from lattice.core.types.evidence import (
    CandidatePattern,
    CompilerOutput,
    CotPhases,
    Evidence,
    ProjectRegistration,
    PromoteAction,
    SecretSpan,
)
from lattice.core.types.event import (
    Event,
    estimate_tokens,
    is_high_signal,
    should_summarize,
    summarize_error_output,
    summarize_success_output,
    summarize_tool_input,
    truncate_error,
)
from lattice.core.types.log import LogEntry, Session
from lattice.core.types.proposal import ProposeRuleInput, Proposal
from lattice.core.types.rule import Rule, RuleDiff
from lattice.core.types.search import (
    FtsResult,
    FusedResult,
    RankedItem,
    SearchResult,
    VecResult,
)
from lattice.core.types.status import StatusReport

__all__ = [
    # Enums
    "Role",
    "EventType",
    "PatternType",
    "ProposalAction",
    "Scope",
    # Config
    "CompilerConfig",
    "EmbeddingConfig",
    "ThresholdsConfig",
    "SafetyConfig",
    "CaptureConfig",
    "Layer1Config",
    "Config",
    # Rule
    "Rule",
    "RuleDiff",
    # Search
    "FtsResult",
    "VecResult",
    "RankedItem",
    "SearchResult",
    "FusedResult",
    # Log (legacy)
    "LogEntry",
    "Session",
    # Event (new for session compression)
    "Event",
    "is_high_signal",
    "summarize_tool_input",
    "summarize_error_output",
    "summarize_success_output",
    "truncate_error",
    "estimate_tokens",
    "should_summarize",
    # Proposal
    "ProposeRuleInput",
    "Proposal",
    # Status
    "StatusReport",
    # Evidence
    "CandidatePattern",
    "CompilerOutput",
    "CotPhases",
    "Evidence",
    "ProjectRegistration",
    "PromoteAction",
    "SecretSpan",
]
