# Copyright (C) 2026 Vijayaraj Paramasivam. Licensed under the GNU GPLv3.
import argparse
import json
import os
import platform
import subprocess
import sys
import time
from pathlib import Path
import shutil
import zipfile
import tarfile
import requests
import socket
import threading
from types import SimpleNamespace
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("yit-player")
except PackageNotFoundError:
    __version__ = "unknown"

# Constants
YIT_DIR = Path.home() / ".yit"
YIT_BIN = YIT_DIR / "bin"
RESULTS_FILE = YIT_DIR / "results.json"
HISTORY_FILE = YIT_DIR / "history.json"
IPC_PIPE = str(YIT_DIR / "socket") # Unified path name, handled differently by OS
FAV_FILE = YIT_DIR / "favorites.json"
UPDATE_FILE = YIT_DIR / "update.json"

if os.name == 'nt':
    IPC_PIPE = r"\\.\pipe\yit_socket"

def check_for_updates():
    """Checks PyPI for a newer version once a day in a background thread."""
    def _check():
        try:
            now = time.time()
            # Enforce 24h cache (86400 seconds)
            if UPDATE_FILE.exists():
                try:
                    with open(UPDATE_FILE, "r") as f:
                        data = json.load(f)
                        if now - data.get("last_checked", 0) < 86400:
                            return
                except: pass

            resp = requests.get("https://pypi.org/pypi/yit-player/json", timeout=3)
            resp.raise_for_status()
            latest = resp.json()["info"]["version"]
            
            with open(UPDATE_FILE, "w") as f:
                json.dump({"last_checked": now, "latest_version": latest}, f)
        except Exception:
            pass # Fail silently
            
    t = threading.Thread(target=_check, daemon=True)
    t.start()

def show_update_notice():
    """Prints a non-blocking notice if an update is available."""
    if __version__ == "unknown" or not UPDATE_FILE.exists():
        return
        
    try:
        with open(UPDATE_FILE, "r") as f:
            data = json.load(f)
            latest = data.get("latest_version")
            if latest and _is_newer(latest, __version__):
                print(f"\033[93m[Update Available: yit-player {latest}] Run `pip install --upgrade yit-player`\033[0m")
    except Exception:
        pass

def _is_newer(latest, current):
    """Simple semver comparison."""
    try:
        def pad(v): return [int(x) for x in v.split('.')] + [0,0,0]
        return pad(latest)[:3] > pad(current)[:3]
    except: return False

def get_mpv_path():
    """Finds MPV or installs it (Windows only)."""
    # 1. Check local bin (Windows priority for portability)
    if os.name == 'nt':
        local_mpv = YIT_BIN / "mpv.exe"
        if local_mpv.exists():
            return str(local_mpv)

    # 2. Check PATH
    if shutil.which("mpv"):
        return "mpv"

    # 3. Not found.
    system = platform.system()
    if system == "Windows":
        print("MPV not found. Downloading portable MPV for Windows...")
        return download_mpv_windows()
    elif system == "Darwin":
        print("MPV is required. Please run: brew install mpv")
        sys.exit(1)
    else:
        print("MPV is required. Please install it (e.g., sudo apt install mpv).")
        sys.exit(1)

def download_mpv_windows():
    if not YIT_BIN.exists(): YIT_BIN.mkdir(parents=True, exist_ok=True)
    
    try:
        # Fetch latest release
        print("Fetching latest MPV release info...")
        api_url = "https://api.github.com/repos/shinchiro/mpv-winbuild-cmake/releases/latest"
        resp = requests.get(api_url)
        resp.raise_for_status()
        assets = resp.json().get("assets", [])
        
        url = None
        # Prefer main build (mpv-x86_64...) over dev
        for asset in assets:
            if asset["name"].startswith("mpv-x86_64") and asset["name"].endswith(".7z") and "v3" in asset["name"]:
                url = asset["browser_download_url"]
                break
        
        if not url:
            for asset in assets:
                 if asset["name"].startswith("mpv-x86_64") and asset["name"].endswith(".7z"):
                    url = asset["browser_download_url"]
                    break
        
        if not url:
            raise Exception("No suitable MPV build (mpv-x86_64*.7z) found in latest release.")

        print(f"Downloading {url}...")
        archive_path = YIT_BIN / "mpv.7z"
        with requests.get(url, stream=True) as r:
            r.raise_for_status()
            with open(archive_path, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
        
        print("Extracting...")
        print("Extracting (using system tar)...")
        try:
            # Modern Windows (10 build 17063+) has native tar
            subprocess.run(["tar", "-xf", str(archive_path), "-C", str(YIT_BIN)], check=True)
        except Exception as e:
             print(f"Error extracting: {e}")
             print("Please install standard 7-Zip or run 'winget install mpv.mpv'")
             sys.exit(1)
            
        # Flatten: Find mpv.exe and move to YIT_BIN
        found = list(YIT_BIN.rglob("mpv.exe"))
        if not found:
            raise Exception("mpv.exe not found in extracted archive.")
            
        mpv_exe = found[0]
        if mpv_exe.parent != YIT_BIN:
            print(f"Moving {mpv_exe} to {YIT_BIN}...")
            # Move all files from that dir to YIT_BIN to satisfy dependencies? 
            # Usually mpv.exe needs files next to it? No, it's usually portable.
            # But let's verify. Shinchiro builds are usually standalone-ish folders.
            # Let's move the executable.
            shutil.move(str(mpv_exe), str(YIT_BIN / "mpv.exe"))
            
        try:
            os.remove(archive_path)
        except: pass
        
        print("MPV installed successfully.")
        return str(YIT_BIN / "mpv.exe")
        
    except Exception as e:
        print(f"Failed to auto-install MPV: {e}")
        print("Please install it manually via 'winget install mpv.mpv'")
        sys.exit(1)

def ensure_yit_dir():
    if not YIT_DIR.exists():
        YIT_DIR.mkdir()



def save_to_history(track):
    """Saves a track to the persistent history file."""
    ensure_yit_dir()
    history = []
    if HISTORY_FILE.exists():
        try:
            with open(HISTORY_FILE, "r") as f:
                history = json.load(f)
        except Exception:
            pass 

    # Check for duplicates or update
    existing = None
    for item in history:
        if item.get("url") == track["url"]:
            existing = item
            break
            
    if not existing:
        history.append(track)
        
    try:
        with open(HISTORY_FILE, "w") as f:
            json.dump(history, f, indent=4)
    except Exception as e:
        print(f"Warning: Could not save history: {e}")

class SocketWrapper:
    """Wraps a socket to behave like a file object (read/write/flush)."""
    def __init__(self, sock):
        self.sock = sock
        self.r_file = sock.makefile("rb", buffering=0)
        self.w_file = sock.makefile("wb", buffering=0)

    def write(self, data):
        self.w_file.write(data)

    def flush(self):
        self.w_file.flush()

    def readline(self):
        return self.r_file.readline()

    def close(self):
        try:
            self.r_file.close()
            self.w_file.close()
            self.sock.close()
        except: pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

def connect_ipc():
    """Connects to the MPV IPC."""
    if os.name == 'nt':
        return open(IPC_PIPE, "r+b", buffering=0)
    else:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(IPC_PIPE)
        return SocketWrapper(sock)

def send_ipc_command(command):
    """Sends a JSON-formatted command to the MPV IPC pipe."""
    try:
        with connect_ipc() as f:
            payload = json.dumps(command).encode("utf-8") + b"\n"
            f.write(payload)
            f.flush() # Essential for socket
            response_line = f.readline().decode("utf-8")
            if response_line:
                return json.loads(response_line)
            return {"error": "no_response"}
    except (FileNotFoundError, ConnectionRefusedError, OSError):
        # On Linux, OSError might be "Connection refused" or "No such file"
        return None
    except Exception as e:
        print(f"Error communicating with player: {e}")
        return None

def get_ipc_property(prop):
    """Gets a property from MPV."""
    try:
        with connect_ipc() as f:
            cmd = {"command": ["get_property", prop]}
            payload = json.dumps(cmd).encode("utf-8") + b"\n"
            f.write(payload)
            f.flush()
            
            # Simple read line
            response = f.readline().decode("utf-8")
            return json.loads(response)
    except (FileNotFoundError, ConnectionRefusedError, OSError):
        return None
    except Exception:
        return None

def cmd_search(args):
    """Searches YouTube and stores results."""
    ensure_yit_dir()
    query = " ".join(args.query)
    print(f"Searching for '{query}'...")

    # using yt-dlp via subprocess for simplicity and speed
    # ytsearch5: gets 5 results
    cmd = [
        "yt-dlp",
        "--print", "%(title)s|%(id)s",
        "--flat-playlist",
        f"ytsearch5:{query}"
    ]

    try:
        # Use full path to yt-dlp if needed, assuming it's in venv or path
        # In this environment, we should rely on the venv activation or use sys.executable to find it
        # But for now, let's assume 'yt-dlp' is in PATH or we use the one we just installed.
        # Ideally, we should use the library, but subprocess is often more stable for simple "get strings"
        
        # Let's try to use the python library method to be cleaner if possible, 
        # but subprocess is standard for this tool type.
        
        # Use system yt-dlp since we are a package now
        yt_dlp_path = "yt-dlp"
        
        
        command = [str(yt_dlp_path), "--print", "%(title)s||||%(webpage_url)s", "--flat-playlist", f"ytsearch5:{query}"]

        
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding='utf-8',
            errors='replace',
            check=False
        )
        
        if result.returncode != 0:
            print(f"Error: yt-dlp returned {result.returncode}")
            print(f"Stderr: {result.stderr}")
            return

        if result.stdout is None:
            print("Error: stdout is None")
            return

        lines = result.stdout.strip().split('\n')
        results = []
        print("\nResults:")
        for i, line in enumerate(lines):
            if "||||" in line:
                title, url = line.split("||||", 1)
                print(f"{i+1}. {title}")
                results.append({"title": title, "url": url})
        
        if not results:
            print("No results found.")
            return

        with open(RESULTS_FILE, "w") as f:
            json.dump(results, f, indent=4)

    except Exception as e:
        print(f"Unexpected error: {e}\nTry running the setup_installer.bat")

    if getattr(args, 'play', False) and results:
        print("\nAuto-playing result #1...")
        # Create a simple namespace to simulate args for cmd_play
        cmd_play(SimpleNamespace(number=1))

def play_tracks(tracks):
    """Plays a list of tracks (dicts with 'url' and 'title')."""
    if not tracks: return

    first_track = tracks[0]
    print(f"Playing: {first_track['title']}")
    if len(tracks) > 1:
        print(f"...and {len(tracks)-1} others queued.")

    save_to_history(first_track)
    
    # Try to load into existing player
    # If it's a list, we usually replace the queue
    # Check if running first
    is_running = send_ipc_command({"command": ["get_property", "idle-active"]})
    
    if is_running and is_running.get("error") == "success":
         print("Added to existing player.")
         # Replace current with first
         send_ipc_command({"command": ["loadfile", first_track["url"], "replace"]})
         send_ipc_command({"command": ["set_property", "pause", False]})
         
         # Append the rest
         for t in tracks[1:]:
             send_ipc_command({"command": ["loadfile", t["url"], "append"]})
    else:
        # Spawn new
        mpv_exe = get_mpv_path()
        cmd = [
            mpv_exe,
            "--no-video",
            "--idle",
            "--cache=yes",
            "--prefetch-playlist=yes",
            "--demuxer-max-bytes=128M",
            "--demuxer-max-back-bytes=128M",
            f"--input-ipc-server={IPC_PIPE}"
        ]
        
        # Add all URLs
        for t in tracks:
            cmd.append(t["url"])

        # Prepare env with yt-dlp in path
        env = os.environ.copy()
        yt_dlp_path = Path(sys.executable).parent
        env["PATH"] = str(yt_dlp_path) + os.pathsep + env["PATH"]

        # Prepare subprocess args based on OS
        kwargs = {
            "stdout": subprocess.DEVNULL,
            "stderr": subprocess.DEVNULL,
            "env": env,
            "close_fds": True
        }

        if os.name == 'nt':
            kwargs["creationflags"] = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
        else:
            kwargs["start_new_session"] = True

        # Detach process
        subprocess.Popen(cmd, **kwargs)
        print("Player started in background.")

def cmd_play(args):
    """Plays the selected track number."""
    if not RESULTS_FILE.exists():
        print("No search results found. Run 'yit search <query>' first.")
        return

    try:
        with open(RESULTS_FILE, "r") as f:
            results = json.load(f)
        
        idx = args.number - 1
        if idx < 0 or idx >= len(results):
            print("Invalid selection number.")
            return

        track = results[idx]
        play_tracks([track])

    except Exception as e:
        print(f"Error playing: {e}")

def cmd_pause(args):
    send_ipc_command({"command": ["set_property", "pause", True]})
    print("Paused.")

def cmd_resume(args):
    send_ipc_command({"command": ["set_property", "pause", False]})
    print("Resumed.")
    
def cmd_toggle(args):
    send_ipc_command({"command": ["cycle", "pause"]})
    print("Toggled playback.")

def cmd_stop(args):
    send_ipc_command({"command": ["quit"]})
    print("Stopped.")

def cmd_loop(args):
    send_ipc_command({"command": ["set_property", "loop-file", "inf"]})
    print("Looping current track.")

def cmd_unloop(args):
    send_ipc_command({"command": ["set_property", "loop-file", "no"]})
    print("Unlooped. Playback will continue normally.")

def cmd_add(args):
    """Appends the selected track number to the queue."""
    if not RESULTS_FILE.exists():
        print("No search results found. Run 'yit search <query>' first.")
        return

    try:
        with open(RESULTS_FILE, "r") as f:
            results = json.load(f)
        
        idx = args.number - 1
        if idx < 0 or idx >= len(results):
            print("Invalid selection number.")
            return

        track = results[idx]
        print(f"Adding to queue: {track['title']}")
        save_to_history(track)
        
        # Determine if we need to spawn mpv or just append
        # Try to append first
        res = send_ipc_command({"command": ["loadfile", track["url"], "append-play"]})
        
        if not res or res.get("error") != "success":
            # If not running, play normally (which spawns)
            print("Player not running (or append failed), starting new queue...")
            cmd_play(args) # This will spawn it
        else:
            print("Added to queue.")

    except Exception as e:
        print(f"Error adding to queue: {e}")

def cmd_next(args):
    send_ipc_command({"command": ["playlist-next"]})
    print("Skipping to next track...")

def cmd_prev(args):
    send_ipc_command({"command": ["playlist-prev"]})
    print("Going to previous track...")

def cmd_restart(args):
    send_ipc_command({"command": ["seek", 0, "absolute"]})
    send_ipc_command({"command": ["set_property", "pause", False]})
    print("Restarting current track...")

def cmd_clear(args):
    send_ipc_command({"command": ["playlist-clear"]})
    print("Queue cleared.")

def extract_video_id(url):
    """Extracts YouTube Video ID from URL."""
    if not url: return None
    # Standard v= parameter
    if "v=" in url:
        try:
            return url.split("v=")[1].split("&")[0][:11] # ID is 11 chars
        except:
            pass
    # Shortened youtu.be/ID
    if "youtu.be/" in url:
        try:
            return url.split("youtu.be/")[1][:11]
        except:
            pass
    return None

def cmd_queue(args):
    # Get playlist info
    resp = get_ipc_property("playlist")
    if not resp or resp.get("error") != "success":
        print("Queue is empty (or player not running).")
        return

    playlist = resp.get("data", [])
    if not playlist:
        print("Queue is empty.")
        return
    
    # Load local results to resolve titles if missing in MPV
    # Map both full URL and Video ID to title
    url_map = {}
    id_map = {}
    
    # Helper to load a list of items into the maps
    def load_into_maps(items):
        for item in items:
            url = item["url"].strip("| ")
            title = item["title"]
            url_map[url] = title
            vid = extract_video_id(url)
            if vid:
                id_map[vid] = title

    # 1. Load Results (Current Search)
    if RESULTS_FILE.exists():
        try:
            with open(RESULTS_FILE, "r") as f:
                load_into_maps(json.load(f))
        except Exception: pass

    # 2. Load History (Persistent Cache)
    if HISTORY_FILE.exists():
        try:
            with open(HISTORY_FILE, "r") as f:
                load_into_maps(json.load(f))
        except Exception: pass

    print("\nCurrent Queue:")
    for i, item in enumerate(playlist):
        prefix = "-> " if item.get("current") else "   "
        
        # Priority: MPV Title -> Local Cache (ID) -> Local Cache (URL) -> Filename -> Unknown
        title = item.get("title")
        
        if not title:
            # MPV 'filename' field holds the URL
            url = item.get("filename", "")
            
            # Try exact match
            if url in url_map:
                title = url_map[url]
            else:
                # Try ID match
                vid = extract_video_id(url)
                if vid and vid in id_map:
                    title = id_map[vid]
                else:
                    title = url or "Unknown"

        print(f"{prefix}{i+1}. {title}")

def cmd_status(args):
    resp = get_ipc_property("media-title")
    if resp and resp.get("error") == "success" and resp.get("data"):
        title = resp.get("data")
        
        # Check pause status
        paused = get_ipc_property("pause")
        looping = get_ipc_property("loop-file")

        status_str = "[Paused]" if paused and paused.get("data") else "[Playing]"
        
        if looping and looping.get("data") in ["inf", "yes"]:
            status_str += " [Looped]"
            
        print(f"{status_str} {title}")
    else:
        # Check if running at least
        if get_ipc_property("idle-active"): 
             print("Queue is empty.")
        else:
             print("Yit is not running.")
            
def cmd_agent(args):
    """Outputs full player state as JSON for AI agents."""
    state = {
        "status": "stopped",
        "track": {},
        "position": 0,
        "duration": 0,
        "volume": 0,
        "loop": False,
        "queue_length": 0
    }

    # Check if running
    idle_resp = get_ipc_property("idle-active")
    if not idle_resp:
        print(json.dumps(state, indent=2))
        return

    # Gather data sequentially
    pause_resp = get_ipc_property("pause")
    title_resp = get_ipc_property("media-title")
    path_resp = get_ipc_property("path") # often URL
    time_resp = get_ipc_property("time-pos")
    dur_resp = get_ipc_property("duration")
    vol_resp = get_ipc_property("volume")
    loop_resp = get_ipc_property("loop-file")
    playlist_resp = get_ipc_property("playlist-count")

    # Process Status
    if pause_resp and pause_resp.get("data") is True:
        state["status"] = "paused"
    elif pause_resp and pause_resp.get("data") is False:
        state["status"] = "playing"

    # Process Track Info
    if title_resp and title_resp.get("data"):
        state["track"]["title"] = title_resp["data"]
    if path_resp and path_resp.get("data"):
        state["track"]["url"] = path_resp["data"]

    # Playback Info
    if time_resp and time_resp.get("data"):
        state["position"] = time_resp["data"]
    if dur_resp and dur_resp.get("data"):
        state["duration"] = dur_resp["data"]
    if vol_resp and vol_resp.get("data"):
        state["volume"] = vol_resp["data"]
    
    # Loop Status
    if loop_resp and loop_resp.get("data") in ["inf", "yes"]:
        state["loop"] = True
    
    # Queue Info
    if playlist_resp and playlist_resp.get("data"):
        state["queue_length"] = playlist_resp["data"]

    print(json.dumps(state, indent=2))

def cmd_commands(args):
    """Outputs available commands as JSON for AI agents."""
    cmds = [
        {"cmd": "search", "usage": "yit search <query> [-p]", "desc": "Search YouTube. -p to auto-play."},
        {"cmd": "play", "usage": "yit play <index>", "desc": "Play a track from results."},
        {"cmd": "add", "usage": "yit add <index>", "desc": "Add a track to queue."},
        {"cmd": "pause", "usage": "yit pause", "desc": "Pause playback."},
        {"cmd": "resume", "usage": "yit resume", "desc": "Resume playback."},
        {"cmd": "stop", "usage": "yit stop", "desc": "Stop playback completely."},
        {"cmd": "next", "usage": "yit next", "desc": "Skip to next track."},
        {"cmd": "back", "usage": "yit back", "desc": "Go to previous track."},
        {"cmd": "loop", "usage": "yit loop", "desc": "Loop current track indefinitely."},
        {"cmd": "unloop", "usage": "yit unloop", "desc": "Stop looping."},
        {"cmd": "queue", "usage": "yit queue", "desc": "Show current queue."},
        {"cmd": "clear", "usage": "yit clear", "desc": "Clear the queue."},
        {"cmd": "status", "usage": "yit status", "desc": "Show playback status (text)."},
        {"cmd": "agent", "usage": "yit agent", "desc": "Get full system state (JSON)."},
        {"cmd": "commands", "usage": "yit commands", "desc": "Get this list (JSON)."},
        {"cmd": "0", "usage": "yit 0", "desc": "Replay current track."},
        {"cmd": "fav", "usage": "yit fav [add|play|list|remove]", "desc": "Manage favorites."}
    ]
    print(json.dumps(cmds, indent=2))

def load_favorites():
    if not FAV_FILE.exists():
        return []
    try:
        with open(FAV_FILE, "r") as f:
            return json.load(f)
    except:
        return []

def save_favorites(favs):
    ensure_yit_dir()
    with open(FAV_FILE, "w") as f:
        json.dump(favs, f, indent=4)

def cmd_fav(args):
    """Handles favorites commands."""
    favs = load_favorites()

    if args.action == "list":
        if not favs:
            print("No favorites yet.")
            return
        print("\nFavorites:")
        for i, track in enumerate(favs):
            print(f"{i+1}. {track['title']}")
    
    elif args.action == "add":
        track_to_add = None
        
        # Add from search results (by index)
        if args.target:
             if not RESULTS_FILE.exists():
                print("No search results found.")
                return
             try:
                 with open(RESULTS_FILE, "r") as f:
                     results = json.load(f)
                 idx = int(args.target) - 1
                 if 0 <= idx < len(results):
                     track_to_add = results[idx]
                 else:
                     print("Invalid index.")
                     return
             except Exception as e:
                 print(f"Error reading results: {e}")
                 return
        
        # Add currently playing song
        else:
            path_resp = get_ipc_property("path")
            title_resp = get_ipc_property("media-title")
            
            # Note: 'path' can be a URL or filename
            if path_resp and path_resp.get("data") and title_resp and title_resp.get("data"):
                 track_to_add = {"title": title_resp["data"], "url": path_resp["data"]}
            else:
                print("No track selected or playing. Specify an index from search results or play a song first.")
                return

        if track_to_add:
            # Check duplicates (by URL)
            if any(f["url"] == track_to_add["url"] for f in favs):
                print(f"Already in favorites: {track_to_add['title']}")
            else:
                favs.append(track_to_add)
                save_favorites(favs)
                print(f"Added to favorites: {track_to_add['title']}")

    elif args.action == "remove":
        if not args.target:
            print("Specify an index to remove (run 'yit fav list').")
            return
        try:
            idx = int(args.target) - 1
            if 0 <= idx < len(favs):
                removed = favs.pop(idx)
                save_favorites(favs)
                print(f"Removed: {removed['title']}")
            else:
                print("Invalid index.")
        except ValueError:
            print("Invalid index found (must be a number).")

    elif args.action == "play":
        if not favs:
            print("No favorites to play.")
            return

        # Play specific index
        if args.target:
            try:
                idx = int(args.target) - 1
                if 0 <= idx < len(favs):
                    track = favs[idx]
                    play_tracks([track])
                else:
                    print("Invalid index.")
            except ValueError:
                print("Invalid index.")
        
        # Play ALL
        else:
            print(f"Playing all {len(favs)} favorites...")
            play_tracks(favs)

def main():
    show_update_notice()
    check_for_updates()

    # Ensure MPV is available (auto-install on Windows if needed)
    # checking this once here avoids checks later, although get_mpv_path caches fairly well?
    # get_mpv_path checks file existence, which is fast.
    try:
        if len(sys.argv) > 1 and sys.argv[1] in ("-v", "--version"):
            # Don't block version check on mpv install
            pass
        else:
            get_mpv_path()
    except SystemExit:
        return # already printed error

    parser = argparse.ArgumentParser(prog="yit", description="Yit (YouTube in Terminal) - Fire-and-Forget Music Player")
    parser.add_argument("-v", "--version", action="version", version=f"%(prog)s {__version__}")
    
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Search
    parser_search = subparsers.add_parser("search", help="Search YouTube")
    parser_search.add_argument("query", nargs="+", help="Search query")
    parser_search.add_argument("-p", "--play", action="store_true", help="Auto-play the first result")
    parser_search.set_defaults(func=cmd_search)

    # Play
    parser_play = subparsers.add_parser("play", help="Play a song by number")
    parser_play.add_argument("number", type=int, help="Track number from search results")
    parser_play.set_defaults(func=cmd_play)

    # Controls
    parser_pause = subparsers.add_parser("pause", aliases=["p"], help="Pause playback")
    parser_pause.set_defaults(func=cmd_pause)

    parser_resume = subparsers.add_parser("resume", aliases=["r"], help="Resume playback")
    parser_resume.set_defaults(func=cmd_resume)
    
    parser_toggle = subparsers.add_parser("toggle", help="Toggle pause/resume")
    parser_toggle.set_defaults(func=cmd_toggle)

    parser_stop = subparsers.add_parser("stop", help="Stop playback")
    parser_stop.set_defaults(func=cmd_stop)

    # Add to queue
    parser_add = subparsers.add_parser("add", help="Add song to queue")
    parser_add.add_argument("number", type=int, help="Track number")
    parser_add.set_defaults(func=cmd_add)

    # Queue management
    parser_queue = subparsers.add_parser("queue", help="Show queue")
    parser_queue.set_defaults(func=cmd_queue)

    parser_clear = subparsers.add_parser("clear", help="Clear queue")
    parser_clear.set_defaults(func=cmd_clear)

    # Fast Navigation (Safe Aliases)
    # Next
    parser_next = subparsers.add_parser("next", aliases=["n"], help="Next track")
    parser_next.set_defaults(func=cmd_next)

    # Previous (Back)
    parser_prev = subparsers.add_parser("back", aliases=["b"], help="Previous track")
    parser_prev.set_defaults(func=cmd_prev)

    # Replay/Restart
    parser_restart = subparsers.add_parser("replay", aliases=["0"], help="Replay current track")
    parser_restart.set_defaults(func=cmd_restart)

    parser_status = subparsers.add_parser("status", help="Show status")
    parser_status.set_defaults(func=cmd_status)
    
    # Agent Interface
    parser_agent = subparsers.add_parser("agent", help="JSON output for AI agents")
    parser_agent.set_defaults(func=cmd_agent)

    parser_cmds = subparsers.add_parser("commands", help="JSON command list for AI agents")
    parser_cmds.set_defaults(func=cmd_commands)

    # Favorites
    parser_fav = subparsers.add_parser("fav", help="Manage favorites")
    # Sub-arguments for fav: action (add, list, play, remove) and target (index)
    # We use nargs='?' for action to support 'yit fav' -> list
    parser_fav.add_argument("action", nargs="?", default="list", choices=["add", "list", "play", "remove"], help="Action to perform")
    parser_fav.add_argument("target", nargs="?", help="Index (for add/play/remove)")
    parser_fav.set_defaults(func=cmd_fav)

    # Loop
    subparsers.add_parser("loop", help="Loop current track").set_defaults(func=cmd_loop)
    subparsers.add_parser("unloop", help="Stop looping").set_defaults(func=cmd_unloop)

    args = parser.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
