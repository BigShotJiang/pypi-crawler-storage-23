from pathlib import Path
from typing import Optional, Dict, Any
import os

DEFAULT_VERSION = "1.0.0"


class ConfManProvider:
    """Configuration provider implementation - avoids conflict with oc-collab's LocalConfigProvider"""

    def __init__(self, config_path: Optional[str] = None, base_dir: Optional[Path] = None):
        self._base_dir = base_dir or Path.cwd()
        self._config = self._load_config(config_path)
        self._version = DEFAULT_VERSION

    def _load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """Load configuration with fallback to defaults"""
        if config_path:
            config_file = Path(config_path)
            if config_file.exists():
                base_dir = config_file.parent.parent
                self._base_dir = base_dir
                import yaml
                with open(config_file, 'r') as f:
                    return yaml.safe_load(f) or {}

        return {}

    def _get_path(self, key: str, default: str) -> str:
        """Get path from config with default fallback"""
        paths = self._config.get('paths', {})
        return str(self._base_dir / paths.get(key, default))

    def _get_file(self, key: str, default: str) -> str:
        """Get file path from config with default fallback"""
        files = self._config.get('files', {})
        return str(self._base_dir / files.get(key, default))

    def _get_config_file(self, key: str, default: str) -> str:
        """Get config file path from config with default fallback"""
        configs = self._config.get('configs', {})
        config_dir = self._get_path('config_dir', 'config')
        return str(Path(config_dir) / configs.get(key, default))

    def get_data_dir(self) -> str:
        return self._get_path('data_dir', 'state')

    def get_config_dir(self) -> str:
        return self._get_path('config_dir', 'config')

    def get_log_dir(self) -> str:
        return self._get_path('log_dir', 'logs')

    def get_temp_dir(self) -> str:
        return self._get_path('temp_dir', 'tmp')

    def get_todo_db_path(self) -> str:
        return self._get_file('todo_db', 'todos.db')

    def get_state_file_path(self) -> str:
        return self._get_file('state_file', 'project_state.yaml')

    def get_lock_file_path(self, name: str) -> str:
        data_dir = self.get_data_dir()
        return str(Path(data_dir) / f"{name}.lock")

    def get_agent_status_db_path(self) -> str:
        return self._get_file('agent_status_db', 'agent_status.db')

    def get_session_dir(self) -> str:
        return self._get_file('session_dir', 'sessions')

    def get_adhoc_todos_path(self) -> str:
        return self._get_file('adhoc_todos', 'agent_adhoc_todos.yaml')

    def get_identity_file_path(self) -> str:
        return self._get_file('identity_file', 'agent.identity')

    def get_pid_file_path(self) -> str:
        return self._get_file('pid_file', 'agent.pid')

    def get_opencode_db_path(self) -> str:
        return self._get_file('opencode_db', '.opencode/opencode.db')

    def get_agents_config_path(self) -> str:
        return self._get_config_file('agents', 'agents.yaml')

    def get_git_sync_config_path(self) -> str:
        return self._get_config_file('git_sync', 'git_sync.yaml')

    def get_notification_config_path(self) -> str:
        return self._get_config_file('notification', 'notification.yaml')

    def get_skill_index_path(self) -> str:
        return self._get_config_file('skill_index', 'skill_index.yaml')

    def get_file_owners_path(self) -> str:
        return self._get_config_file('file_owners', 'file_owners.yaml')

    def get_full_path(self, relative_path: str, base_path: Optional[Path] = None) -> Path:
        """Get full path by joining base path with relative path"""
        base = base_path or self._base_dir
        return base / relative_path

    def get_version(self) -> str:
        """Get conf-man version"""
        return self._version


_provider_instance: Optional[ConfManProvider] = None


def get_provider(config_path: Optional[str] = None, base_dir: Optional[Path] = None) -> ConfManProvider:
    """Get or create singleton ConfManProvider instance"""
    global _provider_instance
    if _provider_instance is None:
        _provider_instance = ConfManProvider(config_path, base_dir)
    return _provider_instance
