"""
conf-man v1.2 E2E and Integration Test Cases

测试覆盖: HTTP API + 认证 + PyPI Token + 项目/版本/依赖管理
执行方式: python3 -m pytest tests/test_e2e_v1_2.py -v
"""

import pytest
import os
import sys
from pathlib import Path
import tempfile
import json

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from fastapi.testclient import TestClient
from storage import Database


class TestDatabaseInit:
    """集成测试 - 数据库初始化"""

    def test_tc_db_001_init_database(self, tmp_path):
        """TC-DB-001: 验证数据库初始化成功"""
        db_path = tmp_path / "test_confman.db"
        db = Database(db_path=str(db_path))
        assert db_path.exists(), "数据库文件应该被创建"

    def test_tc_db_002_create_tables(self, tmp_path):
        """TC-DB-002: 验证所有表被正确创建"""
        db_path = tmp_path / "test_confman.db"
        db = Database(db_path=str(db_path))
        
        rows = db.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        )
        table_names = [row["name"] for row in rows]
        
        assert "versions" in table_names
        assert "projects" in table_names
        assert "dependencies" in table_names
        assert "api_keys" in table_names
        assert "pypi_tokens" in table_names

    def test_tc_db_003_create_indexes(self, tmp_path):
        """TC-DB-003: 验证索引被正确创建"""
        db_path = tmp_path / "test_confman.db"
        db = Database(db_path=str(db_path))
        
        rows = db.execute(
            "SELECT name FROM sqlite_master WHERE type='index'"
        )
        index_names = [row["name"] for row in rows]
        
        assert "idx_versions_project" in index_names
        assert "idx_versions_status" in index_names
        assert "idx_dependencies_version" in index_names

    def test_tc_db_004_foreign_keys_enabled(self, tmp_path):
        """TC-DB-004: 验证外键约束已启用"""
        db_path = tmp_path / "test_confman.db"
        db = Database(db_path=str(db_path))
        
        conn = db._get_connection()
        cursor = conn.cursor()
        cursor.execute("PRAGMA foreign_keys")
        result = cursor.fetchone()
        conn.close()
        
        assert result[0] == 1, "外键约束应该启用"


class TestProjectsAPI:
    """E2E测试 - 项目管理API"""

    @pytest.fixture
    def client(self, tmp_path):
        """创建测试客户端"""
        db_path = tmp_path / "test.db"
        os.environ["TEST_DB_PATH"] = str(db_path)
        
        from api import app
        from storage import Database
        import hashlib
        
        db = Database(db_path=str(db_path))
        
        api_key = "test-api-key-123"
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        db.insert("api_keys", {
            "id": "key-001",
            "key_hash": key_hash,
            "name": "test-key",
            "created_at": "2024-01-01T00:00:00",
            "expires_at": ""
        })
        
        class ApiClient:
            def __init__(self, test_client, api_key):
                self._client = test_client
                self._api_key = api_key
                self.db = test_client.app.state.db
                self.api_key = api_key
            
            def _add_header(self, kwargs):
                if "headers" not in kwargs:
                    kwargs["headers"] = {}
                kwargs["headers"]["x-api-key"] = self._api_key
                return kwargs
            
            def get(self, url, **kwargs):
                return self._client.get(url, **self._add_header(kwargs))
            
            def post(self, url, **kwargs):
                return self._client.post(url, **self._add_header(kwargs))
            
            def put(self, url, **kwargs):
                return self._client.put(url, **self._add_header(kwargs))
            
            def delete(self, url, **kwargs):
                return self._client.delete(url, **self._add_header(kwargs))
        
        with TestClient(app) as test_client:
            app.state.db = db
            client = ApiClient(test_client, api_key)
            yield client
        
        del os.environ["TEST_DB_PATH"]

    def test_tc_prj_001_create_project(self, client):
        """TC-PRJ-001: 验证创建项目"""
        response = client.post(
            "/api/v1/projects",
            json={"name": "test-project"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "test-project"
        assert "id" in data

    def test_tc_prj_002_list_projects(self, client):
        """TC-PRJ-002: 验证列出项目"""
        client.post("/api/v1/projects", json={"name": "project-1"})
        client.post("/api/v1/projects", json={"name": "project-2"})
        
        response = client.get("/api/v1/projects")
        assert response.status_code == 200
        data = response.json()
        assert len(data.get("projects", data)) >= 2

    def test_tc_prj_003_get_project(self, client):
        """TC-PRJ-003: 验证获取项目详情"""
        create_resp = client.post(
            "/api/v1/projects",
            json={"name": "detail-project"}
        )
        project_id = create_resp.json()["id"]
        
        response = client.get(f"/api/v1/projects/{project_id}")
        assert response.status_code == 200
        assert response.json()["name"] == "detail-project"

    def test_tc_prj_005_delete_project(self, client):
        """TC-PRJ-005: 验证删除项目"""
        create_resp = client.post(
            "/api/v1/projects",
            json={"name": "to-delete"}
        )
        project_id = create_resp.json()["id"]
        
        response = client.delete(f"/api/v1/projects/{project_id}")
        assert response.status_code == 200
        
        get_resp = client.get(f"/api/v1/projects/{project_id}")
        assert get_resp.status_code == 404

    def test_tc_prj_006_pagination(self, client):
        """TC-PRJ-006: 验证分页参数"""
        for i in range(25):
            client.post("/api/v1/projects", json={"name": f"project-{i}"})
        
        response = client.get("/api/v1/projects?skip=0&limit=10")
        assert response.status_code == 200
        data = response.json()
        assert len(data.get("projects", data)) == 10


class TestVersionsAPI:
    """E2E测试 - 版本管理API"""

    @pytest.fixture
    def client_with_project(self, tmp_path):
        """创建带项目的测试客户端"""
        db_path = tmp_path / "test.db"
        from api import app
        from storage import Database
        import hashlib
        
        db = Database(db_path=str(db_path))
        
        api_key = "test-api-key-123"
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        db.insert("api_keys", {
            "id": "key-001",
            "key_hash": key_hash,
            "name": "test-key",
            "created_at": "2024-01-01T00:00:00",
            "expires_at": ""
        })
        
        class ApiClient:
            def __init__(self, test_client, api_key):
                self._client = test_client
                self._api_key = api_key
                self.db = test_client.app.state.db
            
            def _add_header(self, kwargs):
                if "headers" not in kwargs:
                    kwargs["headers"] = {}
                kwargs["headers"]["x-api-key"] = self._api_key
                return kwargs
            
            def get(self, url, **kwargs):
                return self._client.get(url, **self._add_header(kwargs))
            
            def post(self, url, **kwargs):
                return self._client.post(url, **self._add_header(kwargs))
            
            def put(self, url, **kwargs):
                return self._client.put(url, **self._add_header(kwargs))
            
            def delete(self, url, **kwargs):
                return self._client.delete(url, **self._add_header(kwargs))
        
        with TestClient(app) as test_client:
            app.state.db = db
            client = ApiClient(test_client, api_key)
            
            proj_resp = client.post(
                "/api/v1/projects",
                json={"name": "test-project"}
            )
            client.project_id = proj_resp.json()["id"]
            
            yield client

    def test_tc_ver_001_create_version(self, client_with_project):
        """TC-VER-001: 验证创建版本"""
        response = client_with_project.post(
            "/api/v1/versions",
            json={
                "version": "1.0.0",
                "project_id": client_with_project.project_id,
                "git_commit_hash": "abc123"
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert data["version"] == "1.0.0"
        assert data["project_id"] == client_with_project.project_id

    def test_tc_ver_002_list_versions(self, client_with_project):
        """TC-VER-002: 验证列出版本"""
        client_with_project.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": client_with_project.project_id}
        )
        client_with_project.post(
            "/api/v1/versions",
            json={"version": "1.1.0", "project_id": client_with_project.project_id}
        )
        
        response = client_with_project.get("/api/v1/versions")
        assert response.status_code == 200
        assert len(response.json()) >= 2

    def test_tc_ver_003_get_version(self, client_with_project):
        """TC-VER-003: 验证获取版本详情"""
        create_resp = client_with_project.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": client_with_project.project_id}
        )
        version_id = create_resp.json()["id"]
        
        response = client_with_project.get(f"/api/v1/versions/{version_id}")
        assert response.status_code == 200
        assert response.json()["version"] == "1.0.0"

    def test_tc_ver_004_release_version(self, client_with_project):
        """TC-VER-004: 验证发布版本"""
        create_resp = client_with_project.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": client_with_project.project_id}
        )
        version_id = create_resp.json()["id"]
        
        response = client_with_project.post(
            f"/api/v1/versions/{version_id}/release"
        )
        assert response.status_code == 200
        
        detail_resp = client_with_project.get(f"/api/v1/versions/{version_id}")
        assert detail_resp.json()["status"] == "released"


class TestDependenciesAPI:
    """E2E测试 - 依赖管理API"""

    @pytest.fixture
    def client_with_version(self, tmp_path):
        """创建带版本的测试客户端"""
        db_path = tmp_path / "test.db"
        from api import app
        from storage import Database
        import hashlib
        
        db = Database(db_path=str(db_path))
        
        api_key = "test-api-key-123"
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        db.insert("api_keys", {
            "id": "key-001",
            "key_hash": key_hash,
            "name": "test-key",
            "created_at": "2024-01-01T00:00:00",
            "expires_at": ""
        })
        
        class ApiClient:
            def __init__(self, test_client, api_key):
                self._client = test_client
                self._api_key = api_key
                self.db = test_client.app.state.db
            
            def _add_header(self, kwargs):
                if "headers" not in kwargs:
                    kwargs["headers"] = {}
                kwargs["headers"]["x-api-key"] = self._api_key
                return kwargs
            
            def get(self, url, **kwargs):
                return self._client.get(url, **self._add_header(kwargs))
            
            def post(self, url, **kwargs):
                return self._client.post(url, **self._add_header(kwargs))
            
            def put(self, url, **kwargs):
                return self._client.put(url, **self._add_header(kwargs))
            
            def delete(self, url, **kwargs):
                return self._client.delete(url, **self._add_header(kwargs))
        
        with TestClient(app) as test_client:
            app.state.db = db
            client = ApiClient(test_client, api_key)
            
            proj_resp = client.post(
                "/api/v1/projects",
                json={"name": "test-project"}
            )
            project_id = proj_resp.json()["id"]
            
            ver_resp = client.post(
                "/api/v1/versions",
                json={"version": "1.0.0", "project_id": project_id}
            )
            client.version_id = ver_resp.json()["id"]
            
            yield client

    def test_tc_dep_001_add_dependency(self, client_with_version):
        """TC-DEP-001: 验证添加依赖 (设计文档: POST /api/v1/versions/{id}/dependencies)"""
        response = client_with_version.post(
            f"/api/v1/versions/{client_with_version.version_id}/dependencies",
            json={
                "name": "requests",
                "version_spec": ">=2.28.0"
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "requests"
        assert data["version_spec"] == ">=2.28.0"

    def test_tc_dep_002_list_dependencies(self, client_with_version):
        """TC-DEP-002: 验证列出依赖"""
        client_with_version.post(
            f"/api/v1/versions/{client_with_version.version_id}/dependencies",
            json={
                "name": "requests",
                "version_spec": ">=2.28.0"
            }
        )
        client_with_version.post(
            f"/api/v1/versions/{client_with_version.version_id}/dependencies",
            json={
                "name": "pyyaml",
                "version_spec": ">=6.0"
            }
        )
        
        response = client_with_version.get(
            f"/api/v1/versions/{client_with_version.version_id}/dependencies"
        )
        assert response.status_code == 200
        assert len(response.json()) >= 2

    def test_tc_dep_003_lock_dependency(self, client_with_version):
        """TC-DEP-003: 验证锁定依赖版本"""
        client_with_version.post(
            f"/api/v1/versions/{client_with_version.version_id}/dependencies",
            json={
                "name": "requests",
                "version_spec": ">=2.28.0"
            }
        )
        
        response = client_with_version.post(
            f"/api/v1/versions/{client_with_version.version_id}/dependencies/lock",
            json=[{"name": "requests", "locked_version": "2.28.0"}]
        )
        assert response.status_code == 200


class TestAuthentication:
    """E2E测试 - 认证"""

    @pytest.fixture
    def client_with_api_key(self, tmp_path):
        """创建带API Key的测试客户端 (使用哈希存储)"""
        db_path = tmp_path / "test.db"
        from api import app
        from storage import Database
        import hashlib
        
        db = Database(db_path=str(db_path))
        
        from datetime import datetime, timedelta
        expires = (datetime.utcnow() + timedelta(days=30)).isoformat()
        
        api_key = "test-api-key-123"
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        
        db.execute(
            "INSERT INTO api_keys (id, key_hash, name, created_at, expires_at) VALUES (?, ?, ?, ?, ?)",
            ("key-1", key_hash, "test-key", datetime.utcnow().isoformat(), expires)
        )
        
        client = TestClient(app)
        client.db = db
        client.api_key = api_key
        yield client

    def test_tc_auth_001_valid_api_key(self, client_with_api_key):
        """TC-AUTH-001: 验证有效API Key访问"""
        response = client_with_api_key.get(
            "/api/v1/projects",
            headers={"X-API-Key": client_with_api_key.api_key}
        )
        assert response.status_code == 200

    def test_tc_auth_002_invalid_api_key(self, client_with_api_key):
        """TC-AUTH-002: 验证无效API Key被拒绝"""
        response = client_with_api_key.get(
            "/api/v1/projects",
            headers={"X-API-Key": "invalid-key"}
        )
        assert response.status_code == 401

    def test_tc_auth_003_missing_api_key(self, client_with_api_key):
        """TC-AUTH-003: 验证缺少API Key被拒绝"""
        response = client_with_api_key.get("/api/v1/projects")
        assert response.status_code == 422

    def test_tc_auth_004_expired_api_key(self, tmp_path):
        """TC-AUTH-004: 验证过期API Key被拒绝 (P2)"""
        db_path = tmp_path / "test.db"
        from api import app
        from storage import Database
        import hashlib
        
        db = Database(db_path=str(db_path))
        
        from datetime import datetime, timedelta
        expires = (datetime.utcnow() - timedelta(days=1)).isoformat()
        
        api_key = "expired-key-123"
        key_hash = hashlib.sha256(api_key.encode()).hexdigest()
        
        db.execute(
            "INSERT INTO api_keys (id, key_hash, name, created_at, expires_at) VALUES (?, ?, ?, ?, ?)",
            ("key-expired", key_hash, "expired-key", datetime.utcnow().isoformat(), expires)
        )
        
        client = TestClient(app)
        response = client.get(
            "/api/v1/projects",
            headers={"X-API-Key": api_key}
        )
        assert response.status_code == 401


class TestHealthCheck:
    """E2E测试 - 健康检查"""

    def test_tc_health_001_health_endpoint(self, tmp_path):
        """TC-HEALTH-001: 验证健康检查端点"""
        db_path = tmp_path / "test.db"
        from api import app
        
        client = TestClient(app)
        response = client.get("/health")
        
        assert response.status_code == 200
        assert response.json()["status"] == "ok"


class TestPyPIToken:
    """E2E测试 - PyPI Token管理"""

    @pytest.fixture
    def client(self, tmp_path):
        """创建测试客户端"""
        db_path = tmp_path / "test.db"
        from api import app
        from storage import Database
        
        db = Database(db_path=str(db_path))
        client = TestClient(app)
        client.db = db
        yield client

    def test_tc_pypi_001_store_token(self, client):
        """TC-PYPI-001: 验证存储PyPI Token"""
        response = client.post(
            "/api/v1/pypi-tokens",
            json={
                "name": "pypi-token-1",
                "token": "pypi-AgEIcHlwaS5vcmcCXXX"
            }
        )
        assert response.status_code == 200

    def test_tc_pypi_002_list_tokens(self, client):
        """TC-PYPI-002: 验证列出PyPI Tokens"""
        client.post(
            "/api/v1/pypi-tokens",
            json={"name": "token-1", "token": "test-token-1"}
        )
        
        response = client.get("/api/v1/pypi-tokens")
        assert response.status_code == 200


class TestAPIKeyManagement:
    """E2E测试 - API Key管理 (P1: 需求F2.3)"""

    @pytest.fixture
    def client(self, tmp_path):
        """创建测试客户端"""
        db_path = tmp_path / "test.db"
        from api import app
        from storage import Database
        
        db = Database(db_path=str(db_path))
        client = TestClient(app)
        client.db = db
        yield client

    def test_tc_key_001_create_api_key(self, client):
        """TC-KEY-001: 验证创建API Key (P1)"""
        response = client.post(
            "/api/v1/api-keys",
            json={
                "name": "new-api-key",
                "expires_days": 30
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert "key" in data
        assert data["name"] == "new-api-key"

    def test_tc_key_002_list_api_keys(self, client):
        """TC-KEY-002: 验证列出API Keys (P1)"""
        client.post(
            "/api/v1/api-keys",
            json={"name": "key-1", "expires_days": 30}
        )
        
        response = client.get("/api/v1/api-keys")
        assert response.status_code == 200

    def test_tc_key_003_delete_api_key(self, client):
        """TC-KEY-003: 验证删除API Key (P1)"""
        create_resp = client.post(
            "/api/v1/api-keys",
            json={"name": "to-delete", "expires_days": 30}
        )
        key_id = create_resp.json()["id"]
        
        response = client.delete(f"/api/v1/api-keys/{key_id}")
        assert response.status_code == 200


class TestTokenRotation:
    """E2E测试 - Token轮换 (P1: 需求F3.3)"""

    @pytest.fixture
    def client(self, tmp_path):
        """创建测试客户端"""
        db_path = tmp_path / "test.db"
        from api import app
        from storage import Database
        
        db = Database(db_path=str(db_path))
        client = TestClient(app)
        client.db = db
        yield client

    def test_tc_token_001_rotate_token(self, client):
        """TC-TOKEN-001: 验证Token轮换 (P1)"""
        create_resp = client.post(
            "/api/v1/pypi-tokens",
            json={"name": "old-token", "token": "old-token-value"}
        )
        token_id = create_resp.json()["id"]
        
        response = client.post(
            f"/api/v1/pypi-tokens/{token_id}/rotate",
            json={"new_token": "new-rotated-token-value"}
        )
        assert response.status_code == 200


class TestVersionHistory:
    """E2E测试 - 版本变更历史 (P1: 需求F5.2)"""

    @pytest.fixture
    def client(self, tmp_path):
        """创建测试客户端"""
        db_path = tmp_path / "test.db"
        from api import app
        from storage import Database
        
        db = Database(db_path=str(db_path))
        client = TestClient(app)
        client.db = db
        yield client

    def test_tc_hist_001_version_history(self, client):
        """TC-HIST-001: 验证版本变更历史 (P1)"""
        proj_resp = client.post(
            "/api/v1/projects",
            json={"name": "history-project"}
        )
        project_id = proj_resp.json()["id"]
        
        ver1 = client.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": project_id}
        )
        
        client.post(f"/api/v1/versions/{ver1.json()['id']}/release")
        
        ver2 = client.post(
            "/api/v1/versions",
            json={"version": "1.1.0", "project_id": project_id}
        )
        
        response = client.get(f"/api/v1/projects/{project_id}/history")
        assert response.status_code == 200


class TestVersionRollback:
    """E2E测试 - 版本回滚 (P1: 需求F5.3)"""

    @pytest.fixture
    def client(self, tmp_path):
        """创建测试客户端"""
        db_path = tmp_path / "test.db"
        from api import app
        from storage import Database
        
        db = Database(db_path=str(db_path))
        client = TestClient(app)
        client.db = db
        yield client

    def test_tc_roll_001_rollback_version(self, client):
        """TC-ROLL-001: 验证版本回滚 (P1)"""
        proj_resp = client.post(
            "/api/v1/projects",
            json={"name": "rollback-project"}
        )
        project_id = proj_resp.json()["id"]
        
        ver1 = client.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": project_id}
        )
        ver1_id = ver1.json()["id"]
        
        client.post(f"/api/v1/versions/{ver1_id}/release")
        
        ver2 = client.post(
            "/api/v1/versions",
            json={"version": "1.1.0", "project_id": project_id}
        )
        
        response = client.post(
            f"/api/v1/versions/{ver1_id}/rollback"
        )
        assert response.status_code == 200


class TestCLICommands:
    """E2E测试 - CLI命令"""

    def test_tc_cli_001_version_command(self):
        """TC-CLI-001: 验证 version 命令"""
        from click.testing import CliRunner
        from src import cli
        
        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        
        assert result.exit_code == 0

    def test_tc_cli_002_list_command(self):
        """TC-CLI-002: 验证 list 命令"""
        from click.testing import CliRunner
        from src import cli
        
        runner = CliRunner()
        result = runner.invoke(cli, ["list"])
        
        assert result.exit_code == 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
