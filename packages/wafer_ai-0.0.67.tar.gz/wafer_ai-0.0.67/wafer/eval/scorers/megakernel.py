from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

from wafer.core.rollouts.dtypes import Metric, Score
from wafer.eval import extract_eval_result

_PROBLEM_MARKER = ".megakernel_problem"


async def _run_benchmark(work_dir: Path, problem_name: str) -> str:
    proc = await asyncio.create_subprocess_exec(
        sys.executable,
        "-m",
        "megakernel_bench.bench",
        "run",
        "--problem",
        problem_name,
        "--solution-dir",
        str(work_dir),
        cwd=str(work_dir),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, _ = await proc.communicate()
    return extract_eval_result(stdout.decode())


async def score(
    work_dir: Path,
    *,
    baseline_dir: Path | None = None,
) -> Score:
    """Score a megakernel submission via subprocess isolation."""
    assert work_dir.is_dir(), f"Not a directory: {work_dir}"
    marker = work_dir / _PROBLEM_MARKER
    assert marker.is_file(), (
        f"Missing {_PROBLEM_MARKER} in {work_dir}. "
        f"The eval harness definition must write this file."
    )
    problem_name = marker.read_text().strip()
    output = await _run_benchmark(work_dir, problem_name)
    after = json.loads(output)

    fused = 1.0 if after.get("fusion") else 0.0
    correct = 1.0 if after.get("correct") else 0.0
    stages_passed = float(after.get("stages_passed", 0))
    speedup = float(after.get("geomean_speedup", 0.0))
    e2e_speedup = float(after.get("e2e_speedup") or 0.0)
    rw_correct = 1.0 if after.get("real_weights_correct") else 0.0

    gates_pass = stages_passed >= 2
    composite = (1.0 + speedup) if gates_pass else 0.0

    metrics = [
        Metric("fusion", fused),
        Metric("correct", correct),
        Metric("stages_passed", stages_passed),
        Metric("geomean_speedup", speedup),
        Metric("score", composite, weight=1.0),
    ]
    if after.get("real_weights_correct") is not None:
        metrics.append(Metric("real_weights_correct", rw_correct))
    if after.get("e2e_speedup") is not None:
        metrics.append(Metric("e2e_speedup", e2e_speedup))

    return Score(metrics=tuple(metrics))
