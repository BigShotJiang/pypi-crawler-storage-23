"""Logging configuration for rollouts.
Tiger Style: Explicit configuration, bounded resources, fail-fast.
"""
import atexit
import logging
import logging.config
import logging.handlers
import os
from pathlib import Path
from typing import Any

from .json_formatter import JSONFormatter
from .sample_handler import SampleRoutingHandler


def setup_logging(
    level: str | None = None,
    console_level: str | None = None,
    use_json: bool | None = None,
    use_rich: bool | None = None,
    use_color: bool | None = None,
    logger_levels: dict[str, str] | None = None,
    log_file: str | None = None,
    rich_tracebacks: bool = False,
    use_queue_handler: bool = True,
    max_log_bytes: int = 100_000_000,
    backup_count: int = 5,
) -> None:
    """Setup standardized logging configuration using dict config.
    Tiger Style: Bounded log files, explicit parameters, assertions.
    Args:
        level: Default log level for root logger (default: INFO or LOG_LEVEL env var)
        console_level: Log level for console handler (default: same as level).
                      Set to "CRITICAL" to suppress console output while still logging to file.
        use_json: Whether to use JSON formatter for console (default: False for human-readable)
        use_rich: Whether to use RichHandler for console output (default: False).
                 If True, produces clean CLI output with colors and formatting.
                 Overridden to False if use_json=True or use_color=True.
        use_color: Whether to use ANSI color formatter for console (default: False).
                  If True, produces colorized output with minimal formatting.
                  Format: [HH:MM:SS] message (color indicates level).
                  Overrides use_rich if both are True.
        logger_levels: Dict mapping logger names to specific log levels
                      e.g. {"httpx": "WARNING", "asyncssh": "ERROR"}
        log_file: Optional log file path. If provided, logs in JSONL format to file
                 with automatic rotation when file reaches max_log_bytes
        rich_tracebacks: Whether to enable rich tracebacks (only applies when use_rich=True)
        use_queue_handler: Whether to use QueueHandler for async-safe logging (default: True).
                          Recommended for async code (trio/asyncio) to prevent blocking.
        max_log_bytes: Maximum bytes per log file before rotation (default: 100MB).
                       Tiger Style: All files must be bounded!
        backup_count: Number of rotated log files to keep (default: 5)
    Returns:
        None. Configures Python's global logging state.
    Example:
        >>> from .._logging import setup_logging
        >>> setup_logging(level="DEBUG", log_file="logs/app.jsonl")
        >>> import logging
        >>> logger = logging.getLogger(__name__)
        >>> logger.info("Application started")
    """
    # Tiger Style: Assert preconditions
    assert max_log_bytes > 0, f"max_log_bytes must be > 0, got {max_log_bytes}"
    assert backup_count >= 0, f"backup_count must be >= 0, got {backup_count}"
    level = level or os.getenv("LOG_LEVEL", "INFO")
    console_level = console_level or level  # Default to same as root level
    use_json = use_json if use_json is not None else os.getenv("LOG_JSON", "").lower() == "true"
    use_rich = use_rich if use_rich is not None else False
    use_color = use_color if use_color is not None else False
    logger_levels = logger_levels or {}
    # JSON mode and color mode override rich mode
    if use_json or use_color:
        use_rich = False
    formatters: dict[str, Any] = {
        "standard": {
            "format": "[%(asctime)s] %(levelname)s: %(message)s",
            "datefmt": "%H:%M:%S",
        },
        "minimal": {"format": "%(message)s"},
        "color": {
            "()": f"{__package__.rsplit('.', 1)[0]}._logging.color_formatter.ColorFormatter",
            "show_timestamp": True,
        },
        "json": {
            "()": f"{__package__.rsplit('.', 1)[0]}._logging.json_formatter.JSONFormatter",
            "fmt_keys": {
                "level": "levelname",
                "logger": "name",
                "module": "module",
                "function": "funcName",
                "line": "lineno",
            },
        },
    }
    # Choose handler and formatter based on mode
    handlers: dict[str, Any]
    if use_rich:
        handlers = {
            "console": {
                "class": "rich.logging.RichHandler",
                "level": console_level,
                "formatter": "minimal",
                "rich_tracebacks": rich_tracebacks,
                "show_time": False,
                "show_path": False,
            }
        }
    else:

        console_formatter = "standard"  # Default
        if use_json:
            console_formatter = "json"
        elif use_color:
            console_formatter = "color"
        handlers = {
            "console": {
                "class": "logging.StreamHandler",
                "level": console_level,
                "formatter": console_formatter,
                "stream": "ext://sys.stderr",
            }
        }
    # Tiger Style: Bounded! Use RotatingFileHandler to prevent unbounded growth
    handler_list = ["console"]
    if log_file:
        handlers["file"] = {
            "class": "logging.handlers.RotatingFileHandler",
            "level": "DEBUG",
            "formatter": "json",  # Always use JSON for file output
            "filename": log_file,
            "mode": "a",
            "maxBytes": max_log_bytes,  # Tiger: Bounded!
            "backupCount": backup_count,  # Keep N rotated files
        }
        handler_list.append("file")
    # mCoding pattern: Use QueueHandler for async-safe logging
    # Python 3.12+ QueueHandler in dictConfig automatically creates QueueListener!
    # The listener runs in a background thread, prevents blocking in async code
    if use_queue_handler:
        handlers["queue_handler"] = {
            "class": "logging.handlers.QueueHandler",
            "handlers": handler_list.copy(),  # Wrap our actual handlers
            "respect_handler_level": True,  # Each handler keeps its own level
        }
        handler_list = ["queue_handler"]  # Route all logs through queue
    config: dict[str, Any] = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": formatters,
        "handlers": handlers,
        "loggers": {},
        "root": {"level": level, "handlers": handler_list},
    }
    loggers_config = config["loggers"]
    assert isinstance(loggers_config, dict), "loggers must be dict"
    for logger_name, logger_level in logger_levels.items():
        loggers_config[logger_name] = {
            "level": logger_level,
            "handlers": handler_list,
            "propagate": False,  # Don't propagate to root to avoid duplicate logs
        }
    logging.config.dictConfig(config)
    # mCoding pattern: Start QueueListener and register cleanup
    # Python 3.12+ creates the listener automatically, we just need to start it
    if use_queue_handler:
        queue_handler = logging.getHandlerByName("queue_handler")
        if queue_handler is not None and hasattr(queue_handler, "listener"):
            queue_handler.listener.start()
            # Register cleanup on exit (mCoding pattern)
            atexit.register(queue_handler.listener.stop)


class EvalLoggingContext:
    """Manages eval-specific logging handlers for the duration of an eval run.
    Returned by setup_eval_logging(). Call teardown() when the eval is done
    to remove handlers and close file handles.
    """
    def __init__(
        self,
        logger: logging.Logger,
        queue_handler: logging.handlers.QueueHandler,
        listener: logging.handlers.QueueListener,
        sample_handler: SampleRoutingHandler,
    ) -> None:
        self.logger = logger
        self.queue_handler = queue_handler
        self.listener = listener
        self.sample_handler = sample_handler

    def teardown(self) -> None:
        """Stop listener, remove handler, close files."""
        self.listener.stop()
        self.logger.removeHandler(self.queue_handler)
        self.sample_handler.close()


def setup_eval_logging(
    output_dir: Path,
    logger_name: str = "wafer.eval.events",
    max_log_bytes: int = 100_000_000,
    backup_count: int = 5,
) -> EvalLoggingContext:
    """Configure eval-specific logging: overview JSONL + per-sample JSONL.
    Adds handlers to the named logger (not root) for the duration of an
    eval run. Returns an EvalLoggingContext — call .teardown() when done.
    Handlers:
      1. RotatingFileHandler -> {output_dir}/events.jsonl (INFO+ overview)
      2. SampleRoutingHandler -> {output_dir}/samples/{sample_id}.jsonl (all levels)
    Both are wrapped in a QueueHandler for non-blocking writes.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    formatter = JSONFormatter()
    # 1. Overview: events.jsonl (INFO+ only)
    events_handler = logging.handlers.RotatingFileHandler(
        str(output_dir / "events.jsonl"),
        mode="a",
        maxBytes=max_log_bytes,
        backupCount=backup_count,
    )
    events_handler.setFormatter(formatter)
    events_handler.setLevel(logging.INFO)
    # 2. Per-sample: samples/{sample_id}.jsonl (all levels including DEBUG)
    sample_handler = SampleRoutingHandler(output_dir)
    sample_handler.setFormatter(formatter)
    sample_handler.setLevel(logging.DEBUG)
    # Wrap both in QueueHandler for non-blocking writes.
    # QueueHandler puts records onto a queue; QueueListener consumes
    # from that queue and dispatches to the real handlers in a background thread.
    import queue as queue_mod
    q: queue_mod.Queue[logging.LogRecord] = queue_mod.Queue()
    queue_handler = logging.handlers.QueueHandler(q)
    listener = logging.handlers.QueueListener(
        q, events_handler, sample_handler, respect_handler_level=True
    )
    listener.start()
    logger = logging.getLogger(logger_name)
    logger.addHandler(queue_handler)
    logger.setLevel(logging.DEBUG)  # Let handlers decide what to filter
    logger.propagate = False  # Events go to files only, not root
    return EvalLoggingContext(
        logger=logger,
        queue_handler=queue_handler,
        listener=listener,
        sample_handler=sample_handler,
    )
