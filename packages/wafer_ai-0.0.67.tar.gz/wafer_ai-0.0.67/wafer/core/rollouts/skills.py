"""Skill discovery and loading.
Skills are documentation files that agents can load on demand.
Format follows agentskills.io spec: SKILL.md with YAML frontmatter.
Discovery order:
1. ~/.wafer/skills/{name}/SKILL.md (user-installed)
2. Bundled skills (wafer-ai CLI package)
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .paths import get_config_dir


@dataclass(frozen=True)
class SkillMetadata:
    """Lightweight skill metadata for system prompt injection and / command discovery."""
    name: str
    description: str
    path: Path
    argument_hint: str | None = None
    disable_model_invocation: bool = False
    user_invocable: bool = True
    context: str = "inline"  # "inline" or "fork"
    allowed_tools: list[str] | None = None


@dataclass(frozen=True)
class Skill:
    """Full skill with content."""
    name: str
    description: str
    content: str
    path: Path
    argument_hint: str | None = None
    disable_model_invocation: bool = False
    user_invocable: bool = True
    context: str = "inline"
    allowed_tools: list[str] | None = None


def _parse_bool(value: str) -> bool:
    return value.lower() in ("true", "yes", "1")


def _parse_skill_file(path: Path) -> tuple[dict[str, str], str] | None:
    """Parse SKILL.md file into (frontmatter, content).
    Returns None if file doesn't exist or is malformed.
    """
    if not path.exists():
        return None
    try:
        text = path.read_text()
    except (OSError, PermissionError):
        return None
    if not text.startswith("---"):
        return None

    end_idx = text.find("---", 3)
    if end_idx == -1:
        return None
    frontmatter_text = text[3:end_idx].strip()
    content = text[end_idx + 3 :].strip()
    frontmatter: dict[str, str] = {}
    for raw_line in frontmatter_text.split("\n"):
        stripped = raw_line.strip()
        if not stripped or ":" not in stripped:
            continue
        key, _, value = stripped.partition(":")
        frontmatter[key.strip()] = value.strip()
    if "name" not in frontmatter or "description" not in frontmatter:
        return None
    return frontmatter, content


def _build_metadata(frontmatter: dict[str, str], path: Path) -> SkillMetadata:
    """Build SkillMetadata from parsed frontmatter."""
    allowed_tools_raw = frontmatter.get("allowed-tools", "")
    allowed_tools = (
        [t.strip() for t in allowed_tools_raw.split(",") if t.strip()]
        if allowed_tools_raw
        else None
    )
    return SkillMetadata(
        name=frontmatter["name"],
        description=frontmatter["description"],
        path=path,
        argument_hint=frontmatter.get("argument-hint"),
        disable_model_invocation=_parse_bool(
            frontmatter.get("disable-model-invocation", "false")
        ),
        user_invocable=_parse_bool(frontmatter.get("user-invocable", "true")),
        context=frontmatter.get("context", "inline"),
        allowed_tools=allowed_tools,
    )


def _get_bundled_skills_dir() -> Path:
    """Get path to bundled skills in wafer-ai CLI package."""
    import wafer.cli as wafer_cli

    wafer_cli_path = Path(wafer_cli.__file__).parent
    skills_dir = wafer_cli_path / "skills"
    assert skills_dir.exists(), f"Bundled skills directory missing: {skills_dir}"
    assert skills_dir.is_dir(), f"Bundled skills path is not a directory: {skills_dir}"
    return skills_dir


def discover_skills() -> list[SkillMetadata]:
    """Discover all available skills.
    Returns list of SkillMetadata with full frontmatter fields.
    """
    skills: dict[str, SkillMetadata] = {}
    # 1. User-installed skills (~/.wafer/skills/) — take precedence
    user_skills_dir = get_config_dir() / "skills"
    if user_skills_dir.exists():
        for skill_dir in user_skills_dir.iterdir():
            if not skill_dir.is_dir():
                continue
            skill_file = skill_dir / "SKILL.md"
            parsed = _parse_skill_file(skill_file)
            if parsed:
                frontmatter, _ = parsed
                skills[frontmatter["name"]] = _build_metadata(frontmatter, skill_file)
    # 2. Bundled skills (wafer-ai CLI package)
    bundled_dir = _get_bundled_skills_dir()
    for skill_dir in bundled_dir.iterdir():
        if not skill_dir.is_dir():
            continue
        skill_file = skill_dir / "SKILL.md"
        parsed = _parse_skill_file(skill_file)
        if parsed:
            frontmatter, _ = parsed
            if frontmatter["name"] not in skills:
                skills[frontmatter["name"]] = _build_metadata(frontmatter, skill_file)
    return list(skills.values())


def get_user_invocable_skills() -> list[SkillMetadata]:
    """Return skills where user_invocable=True, sorted by name."""
    return sorted(
        (s for s in discover_skills() if s.user_invocable),
        key=lambda s: s.name,
    )


def load_skill(name: str) -> Skill | None:
    """Load a skill by name.
    Returns full Skill with content, or None if not found.
    """
    for metadata in discover_skills():
        if metadata.name == name:
            parsed = _parse_skill_file(metadata.path)
            if parsed:
                _, content = parsed
                return Skill(
                    name=metadata.name,
                    description=metadata.description,
                    content=content,
                    path=metadata.path,
                    argument_hint=metadata.argument_hint,
                    disable_model_invocation=metadata.disable_model_invocation,
                    user_invocable=metadata.user_invocable,
                    context=metadata.context,
                    allowed_tools=metadata.allowed_tools,
                )
    return None


def format_skill_metadata_for_prompt(skills: list[SkillMetadata]) -> str:
    """Format skill metadata for system prompt injection.
    Returns a compact section listing available skills.
    """
    if not skills:
        return ""
    lines = ["## Available Skills", ""]
    lines.append(
        "You have access to the following skills. Use the `skill` tool to load full instructions when needed."
    )
    lines.append("")
    for skill in skills:
        lines.append(f"- **{skill.name}**: {skill.description}")
    return "\n".join(lines)
