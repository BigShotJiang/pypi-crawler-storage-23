"""Package configuration and asset discovery.

Provides paths to package assets (README, docs, presets) that work with:
- `uv tool install -e ~/research/rollouts` (editable/dev install)
- `uv tool install rollouts` (from PyPI)
- `python -m rollouts` (direct execution)

For editable installs, assets are found relative to the source tree.
For installed packages, key docs should be bundled in rollouts/_docs/.
"""

from importlib.metadata import PackageNotFoundError, version
from importlib.resources import files
from pathlib import Path

# =============================================================================
# User Config Directory
# =============================================================================


def get_config_dir() -> Path:
    """Get the rollouts config directory (~/.rollouts/).

    This is where global user configuration lives:
    - AGENTS.md or CLAUDE.md for global context
    - sessions/ for session persistence
    - Future: skills/, themes/, etc.
    """
    return Path.home() / ".rollouts"


# =============================================================================
# Version
# =============================================================================


def get_version() -> str:
    """Get rollouts package version."""
    try:
        return version("rollouts")
    except PackageNotFoundError:
        return "dev"


# =============================================================================
# Package Paths
# =============================================================================


def get_package_dir() -> Path:
    """Get the rollouts package directory.

    Returns the directory containing the rollouts Python modules.
    Works with both editable installs and installed packages.
    """
    return Path(str(files("wafer.core.rollouts"))).resolve()


def get_repo_root() -> Path:
    """Get the repository root (parent of package dir).

    For editable installs, this is the repo root with README.md, docs/, etc.
    For installed packages, assets should be included in the wheel.
    """
    return get_package_dir().parent


def get_readme_path() -> Path:
    """Get path to README.md."""
    return get_repo_root() / "README.md"


def get_docs_dir() -> Path:
    """Get path to docs/ directory."""
    return get_repo_root() / "docs"
