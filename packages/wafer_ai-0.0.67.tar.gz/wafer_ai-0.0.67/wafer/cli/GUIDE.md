# Wafer CLI Guide

GPU development primitives for LLM agents.

## Quick Start

Run code on a GPU in three commands:

```bash
wafer login                                              # One-time auth
wafer target init ssh --name my-gpu --host user@host:22   # Register your GPU machine
wafer sandbox run --target my-gpu -- python -c "import torch; print(torch.cuda.get_device_name(0))"
```

**Available GPUs:**

- `MI300X` - AMD Instinct MI300X (192GB HBM3, ROCm)
- `B200` - NVIDIA Blackwell B200 (180GB HBM3e, CUDA) - default

## Running Code on a GPU

Push files to the sandbox, then run commands:

```bash
# Push files to sandbox, then run commands (no repeated sync)
wafer sandbox push ./project
wafer sandbox run --target my-gpu -- python train.py

# Push single file after editing
wafer sandbox push ./project/kernel.cu
wafer sandbox run --target my-gpu -- nvcc kernel.cu && ./kernel

# Alternative: sync + run in one shot
wafer sandbox run --target my-gpu --sync ./project -- python train.py

# Set a timeout (seconds)
wafer sandbox run --target my-gpu --timeout 300 -- python long_job.py
```

**Sandbox is SSH-only.** For cloud workspaces, use `wafer target sync` and `wafer target ssh` instead.

## Managing Targets

Targets are GPU environments you run code on. SSH targets (your own machines) use sandbox for remote execution.

```bash
wafer target list                                # List all targets
wafer target show my-gpu                         # Show target details
wafer target ssh my-gpu                         # Interactive SSH
wafer target sync my-gpu ./project               # Sync files to target
wafer target pull my-gpu /remote/results ./local # Pull files from target
wafer target remove my-gpu                       # Remove a target
```

**Creating targets:**

```bash
# Your own SSH host (required for sandbox)
wafer target init ssh --name my-gpu --host user@host:22

# Cloud workspace (use wafer target sync + wafer target ssh, not sandbox)
wafer target init workspace dev --gpu B200
wafer target init workspace amd-dev --gpu MI300X
```

## Documentation Lookup

Answer GPU programming questions from wafer's cloud documentation.

```bash
# Query documentation (uses wafer API — no local download needed)
wafer agent -t docs "What is warp divergence?"
wafer agent -t docs "What is a TiledMma in CUTLASS?"
```

## Trace Analysis

Analyze performance traces from PyTorch profiler or Perfetto.

```bash
# Direct trace queries (PyTorch/Perfetto JSON)
wafer tool perfetto tables trace.json
wafer tool perfetto query trace.json \
  "SELECT name, dur/1e6 as ms FROM slice WHERE cat='kernel' ORDER BY dur DESC LIMIT 10"
```

## Kernel Evaluation

Test kernel correctness and measure speedup against a reference.

```bash
# List available evaluation tasks
wafer tool eval --list-tasks

# Run evaluation locally
wafer tool eval --task kernelbench
wafer tool eval --task gpumode

# Push files to sandbox, then run eval
wafer sandbox push ./my-kernel
wafer sandbox run --target my-gpu -- wafer tool eval --task gpumode

# After editing, push just the changed file
wafer sandbox push ./my-kernel/kernel.cu
wafer sandbox run --target my-gpu -- wafer tool eval --task kernelbench
```

For target setup, see `wafer target init --help`.

## Kernel Optimization (AI-assisted)

Use the wafer agent to optimize GPU kernels with AI assistance.

```bash
# Optimize a kernel interactively (local TUI)
wafer agent "optimize this GEMM kernel for B200"

# Run optimization on the cloud
wafer agent --cloud -t default "optimize this kernel" --single-turn --dir .

# Use the agent with a specific target
wafer agent --cloud --dir ./my-kernel "reduce memory bandwidth usage in this matmul"
```

Combine with evaluation to measure improvement:

```bash
# Evaluate before and after optimization
wafer tool eval --task gpumode --after ./optimized --before ./original

# Roofline analysis to identify bottleneck
wafer tool roofline --gpu B200 --bytes 100e6 --flops 137e12 --time-ms 85
```

## Command Reference

```bash
wafer target init|list|show|remove|default  # Manage GPU targets
wafer target ssh|sync|pull|verify           # Interact with targets
wafer sandbox push|run|list|attach|delete|gc # Push files + execute commands on targets
wafer tool eval                             # Test kernel correctness/performance
wafer tool perfetto                         # Trace analysis (PyTorch/Perfetto JSON)
wafer tool isa|rocprof-compute|rocprof-sdk|rocprof-systems  # AMD profiling tools
wafer tool roofline                         # Roofline analysis
wafer tool baseline run|hardware            # Baseline benchmarks
wafer tool compare analyze|fusion           # Kernel comparison
wafer tool capture run|list                  # Trace capture
wafer tool tracelens check|report|compare|collective  # Trace lens analysis
wafer tool nvidia-distributed-traces analyze|collect|compare|metrics  # NVIDIA distributed traces
wafer tool amd-distributed-traces analyze|collect|compare|metrics    # AMD distributed traces
wafer agent -t docs                          # GPU docs lookup
wafer login|logout|whoami                   # Authentication
wafer settings config|billing|ssh-keys|deps|status|telemetry|skill|auth  # Configuration
wafer --version                             # Show CLI version
```
