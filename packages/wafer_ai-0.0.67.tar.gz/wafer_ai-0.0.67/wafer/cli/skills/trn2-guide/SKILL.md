---
name: trn2-guide
description: AWS Trainium 2 (NeuronCore-v3) NKI optimization guide. Sandbox commands, NKI API, critical rules.
---

# AWS Trainium 2 (NeuronCore-v3) — NKI Optimization Guide

## Hardware Specs

- Architecture: NeuronCore-v3
- P_MAX = 128 (partition dimension max)
- Target name: `trn2`

## Sandbox Commands

```bash
# Run any command on the remote trn2
wafer sandbox run --target trn2 -- <command>

# Sync local edits and run benchmark
wafer sandbox run --target trn2 --sync . -- "cd /tmp/workspace && bash run.sh"

# Run benchmark (files already on remote)
wafer sandbox run --target trn2 -- "cd /tmp/workspace && bash run.sh"
```

Your working directory on the trn2 sandbox is `/tmp/workspace`. All problem files
(solution/kernel.py, baseline_kernel.py, nki_bench.py, run.sh, definition.json,
input_gen.py) are already there.

The ONLY file you should modify is `solution/kernel.py`. Do NOT modify `nki_bench.py`,
`run.sh`, or `baseline_kernel.py`.

## Resource Contention

The benchmark harness automatically retries NeuronCore allocation up to 8 times with
15s delays. If the output shows "NeuronCore busy, retrying..." just wait — do NOT
re-run the command yourself. Only re-run if the command exits with a non-contention
error (e.g., compile failure, trace error).

## NKI API Reference (`import nki`)

ALL nisa ops use `dst=` parameter:

```python
import nki
import nki.isa as nisa
import nki.language as nl

# ScalarE ops
nisa.activation(dst=result, op=nl.rsqrt, data=x, bias=eps_tile, scale=1.0/N)
nisa.activation_reduce(dst=sq_out, op=nl.square, data=x, reduce_op=nl.add, reduce_res=sum_sq, bias=zero_tile, scale=1.0)
nisa.reciprocal(dst=recip, data=x)

# VectorE ops
nisa.tensor_tensor(dst=result, data1=a, data2=b, op=nl.multiply)
nisa.tensor_scalar(dst=result, data=x, op0=nl.multiply, operand0=scale)
nisa.tensor_scalar_reduce(dst=abs_out, data=x, op0=nl.abs, operand0=0.0, reduce_op=nl.maximum, reduce_res=row_max)
nisa.scalar_tensor_tensor(dst=out, data=x, op0=nl.multiply, operand0=scale, op1=nl.multiply, operand1=gamma_psum)

# TensorE ops
nisa.nc_matmul(dst=psum_tile, stationary=lhs, moving=rhs)

# DMA ops
nisa.dma_copy(dst=sbuf_tile, src=hbm_tile)
```

## Critical Rules

- `nisa.activation(bias=0.0)` is WRONG. bias MUST be a tile (nl.ndarray), never a float literal.
- `nisa.tensor_tensor(op=nl.divide)` is NOT supported. Use `nisa.reciprocal` + multiply.
- `nl.multiply()`, `nl.add()` etc. as function calls are NOT supported in `import nki`. They are op codes only.
- P_MAX = 128 (partition dimension max).
- Hoist `nisa.memset` and constant allocations OUTSIDE the tile loop.
- `scalar_tensor_tensor` operand0 must be an SBUF tile, not PSUM or HBM.

## Dead Ends (don't waste time on these)

- `engine=nisa.scalar_engine` on `tensor_scalar` after `scalar_tensor_tensor` -> all-zero output (compiler bug)
- `activation(reduce_op=nl.maximum)` is NOT supported, only `nl.add`
- `tensor_reduce(op=nl.maximum)` is NOT supported, use `tensor_scalar_reduce` instead

## Optimization Strategies

- **Fuse operations**: Combine computation steps in a single pass to reduce DMA round-trips
- **Use wider tiles**: Process 2x or 4x tiles at once to reduce loop overhead
- **Use `nisa.nc_matmul`** for broadcast operations instead of element-wise multiply
- **Reduce SBUF pressure**: Use 0-step access patterns (.ap()) to avoid large intermediate buffers
- **Minimize DMA round-trips** between HBM and SBUF

## Scoring

Score = geometric mean speedup over baseline across 5 shapes.
All 5 shapes must pass correctness check for a nonzero score.
Score of 0 means at least one shape failed correctness.
