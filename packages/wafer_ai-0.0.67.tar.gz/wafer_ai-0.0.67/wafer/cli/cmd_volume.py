"""Volume management commands: create, list, delete, push/pull files.

Subcommands:
  wafer volume list          List all volumes
  wafer volume create <name> Create a new volume
  wafer volume delete <name> Delete a volume
  wafer volume info <name>   Show volume details
  wafer volume ls <name>     List files in a volume
  wafer volume push <name>   Upload file/directory to a volume
  wafer volume pull <name>   Download a file from a volume
"""
from __future__ import annotations

import io
import json
import os
import tarfile
import urllib.parse
from pathlib import Path

import httpx
import typer

volume_app = typer.Typer(help="Manage persistent volumes for cloud agents")


# ---------------------------------------------------------------------------
# Auth + resolution helpers
# ---------------------------------------------------------------------------

def _cloud_auth_headers() -> tuple[str, dict[str, str]]:
    from .auth import get_valid_token
    from .global_config import get_api_url

    api_base = os.environ.get("WAFER_API_URL") or get_api_url()
    auth_token = os.environ.get("WAFER_AUTH_TOKEN") or get_valid_token()
    if not auth_token:
        typer.echo(
            "\nNot signed in. Run `wafer login` first, or set WAFER_AUTH_TOKEN.\n",
            err=True,
        )
        raise typer.Exit(1)
    return api_base, {"Authorization": f"Bearer {auth_token}"}


def _resolve_volume_id(api_base: str, headers: dict[str, str], name: str) -> str:
    resp = httpx.get(f"{api_base}/v1/user-volumes", headers=headers, timeout=30.0)
    resp.raise_for_status()
    for vol in resp.json()["volumes"]:
        if vol["name"] == name:
            return vol["id"]
    raise SystemExit(f"Volume '{name}' not found")


def _create_tarball(directory: Path) -> bytes:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        tar.add(str(directory), arcname=".")
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@volume_app.command("list")
def volume_list(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List all volumes"""
    api_base, headers = _cloud_auth_headers()
    resp = httpx.get(f"{api_base}/v1/user-volumes", headers=headers, timeout=30.0)
    resp.raise_for_status()
    data = resp.json()
    volumes = data.get("volumes", [])

    if json_output:
        print(json.dumps(data, indent=2))
        return

    if not volumes:
        typer.echo("No volumes found.")
        typer.echo("  Create one with: wafer volume create <name>")
        return

    typer.echo(f"  {'NAME':<24} {'CREATED':<14} {'DESCRIPTION'}")
    typer.echo(f"  {'─' * 24} {'─' * 14} {'─' * 30}")
    for v in volumes:
        created = v.get("created_at", "")[:10]
        typer.echo(f"  {v['name']:<24} {created:<14} {v.get('description', '')}")


@volume_app.command("create")
def volume_create(
    name: str = typer.Argument(..., help="Volume name (lowercase alphanumeric/hyphens)"),
    description: str = typer.Option("", "--description", "-d", help="Volume description"),
) -> None:
    """Create a new persistent volume"""
    api_base, headers = _cloud_auth_headers()
    body: dict[str, str] = {"name": name}
    if description:
        body["description"] = description

    resp = httpx.post(
        f"{api_base}/v1/user-volumes",
        headers=headers,
        json=body,
        timeout=30.0,
    )
    if resp.status_code == 409:
        typer.echo(f"Error: Volume '{name}' already exists.", err=True)
        raise typer.Exit(1)
    resp.raise_for_status()
    vol = resp.json()
    typer.echo(f"Created volume: {vol['name']}")
    if vol.get("description"):
        typer.echo(f"  Description: {vol['description']}")


@volume_app.command("delete")
def volume_delete(
    name: str = typer.Argument(..., help="Volume name"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Delete a volume"""
    api_base, headers = _cloud_auth_headers()
    volume_id = _resolve_volume_id(api_base, headers, name)

    if not yes:
        confirm = typer.confirm(f"Delete volume '{name}'? This cannot be undone.")
        if not confirm:
            typer.echo("Cancelled.")
            raise typer.Exit(0)

    resp = httpx.delete(
        f"{api_base}/v1/user-volumes/{volume_id}",
        headers=headers,
        timeout=30.0,
    )
    resp.raise_for_status()
    typer.echo(f"Deleted volume: {name}")


@volume_app.command("info")
def volume_info(
    name: str = typer.Argument(..., help="Volume name"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show volume details"""
    api_base, headers = _cloud_auth_headers()
    volume_id = _resolve_volume_id(api_base, headers, name)

    resp = httpx.get(
        f"{api_base}/v1/user-volumes/{volume_id}",
        headers=headers,
        timeout=30.0,
    )
    resp.raise_for_status()
    vol = resp.json()

    if json_output:
        print(json.dumps(vol, indent=2))
        return

    typer.echo(f"Volume:      {vol['name']}")
    typer.echo(f"ID:          {vol['id']}")
    typer.echo(f"Description: {vol.get('description', '')}")
    typer.echo(f"Created:     {vol['created_at']}")


@volume_app.command("ls")
def volume_ls(
    name: str = typer.Argument(..., help="Volume name"),
    path: str = typer.Argument("/", help="Path inside the volume"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List files in a volume"""
    api_base, headers = _cloud_auth_headers()
    volume_id = _resolve_volume_id(api_base, headers, name)

    resp = httpx.get(
        f"{api_base}/v1/user-volumes/{volume_id}/files",
        headers=headers,
        params={"path": path},
        timeout=30.0,
    )
    resp.raise_for_status()
    data = resp.json()
    files = data.get("files", [])

    if json_output:
        print(json.dumps(data, indent=2))
        return

    if not files:
        typer.echo(f"No files at '{path}'.")
        return

    for f in files:
        kind = "d" if f.get("is_dir") else "-"
        typer.echo(f"  {kind}  {f['size']:>10}  {f['path']}")


@volume_app.command("push")
def volume_push(
    name: str = typer.Argument(..., help="Volume name"),
    local_path: Path = typer.Argument(..., help="Local file or directory to upload"),
    remote_path: str | None = typer.Argument(None, help="Remote path inside volume (for files)"),
) -> None:
    """Push a file or directory to a volume"""
    assert local_path.exists(), f"Path not found: {local_path}"

    api_base, headers = _cloud_auth_headers()
    volume_id = _resolve_volume_id(api_base, headers, name)

    is_dir = local_path.is_dir()
    if is_dir:
        typer.echo(f"Creating tarball of {local_path}...", err=True)
        content = _create_tarball(local_path.resolve())
        mode = "tarball"
    else:
        content = local_path.read_bytes()
        mode = "file"
        if remote_path is None:
            remote_path = local_path.name

    size_mb = len(content) / (1024 * 1024)
    typer.echo(f"Uploading ({size_mb:.1f}MB)...", err=True)

    url_resp = httpx.post(
        f"{api_base}/v1/user-volumes/{volume_id}/upload-url",
        headers=headers,
        timeout=30.0,
    )
    url_resp.raise_for_status()
    url_data = url_resp.json()
    upload_url = url_data["upload_url"]
    storage_path = url_data["storage_path"]

    put_resp = httpx.put(upload_url, content=content, timeout=120.0)
    if put_resp.status_code not in (200, 201, 204):
        typer.echo(f"Error: Upload failed ({put_resp.status_code}): {put_resp.text[:200]}", err=True)
        raise typer.Exit(1)

    typer.echo("Syncing to volume...", err=True)
    sync_body: dict[str, str] = {"storage_path": storage_path, "mode": mode}
    if mode == "file" and remote_path:
        sync_body["remote_path"] = remote_path

    sync_resp = httpx.post(
        f"{api_base}/v1/user-volumes/{volume_id}/sync",
        headers=headers,
        json=sync_body,
        timeout=120.0,
    )
    sync_resp.raise_for_status()

    if is_dir:
        typer.echo(f"Pushed directory {local_path} to volume '{name}'.")
    else:
        typer.echo(f"Pushed {local_path.name} to volume '{name}' at {remote_path}.")


@volume_app.command("pull")
def volume_pull(
    name: str = typer.Argument(..., help="Volume name"),
    remote_path: str = typer.Argument(..., help="Remote file path inside the volume"),
    local_path: Path | None = typer.Argument(None, help="Local destination (default: filename from remote_path)"),
) -> None:
    """Pull a file from a volume"""
    api_base, headers = _cloud_auth_headers()
    volume_id = _resolve_volume_id(api_base, headers, name)

    encoded = "/".join(
        urllib.parse.quote(seg, safe="") for seg in remote_path.strip("/").split("/")
    )
    resp = httpx.get(
        f"{api_base}/v1/user-volumes/{volume_id}/files/{encoded}",
        headers=headers,
        timeout=30.0,
    )
    if resp.status_code == 404:
        typer.echo(f"Error: File not found: {remote_path}", err=True)
        raise typer.Exit(1)
    resp.raise_for_status()

    data = resp.json()
    content_str = data.get("content", "")
    encoding = data.get("encoding", "utf-8")

    dest = local_path or Path(Path(remote_path).name)
    dest.parent.mkdir(parents=True, exist_ok=True)

    if encoding == "base64":
        import base64
        dest.write_bytes(base64.b64decode(content_str))
    else:
        dest.write_text(content_str, encoding="utf-8")

    typer.echo(f"Pulled {remote_path} -> {dest} ({data.get('size', 0)} bytes)")
