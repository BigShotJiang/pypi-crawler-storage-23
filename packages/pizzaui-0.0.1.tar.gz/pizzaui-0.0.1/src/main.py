import os

def cnlen(text):
    length = 0
    for char in str(text):
        code = ord(char)
        if (0x4E00  <= code <= 0x9FFF  or
            0x3400  <= code <= 0x4DBF  or
            0x20000 <= code <= 0x2A6DF or
            0x2A700 <= code <= 0x2B73F or
            0x2B740 <= code <= 0x2B81F or
            0x2B820 <= code <= 0x2CEAF or
            0x2CEB0 <= code <= 0x2EBEF or
            0x30000 <= code <= 0x3134F or
            0xF900  <= code <= 0xFAFF  or
            0x2F800 <= code <= 0x2FA1F or
            0xFF00  <= code <= 0xFFEF  or
            char in '，。！？；：「」【】（）《》'):
            length += 2
        else:
            length += 1
    return length

def box(*text, name='', style=["╭", "╮", "╰", "╯", "─", "│", " "]):
    maxlong = cnlen(max(text, key=len))
    print(style[0]+style[4]+style[6]+name+style[6]+ style[4] * (namelong := maxlong - cnlen(name) - 2) + style[4]+style[1])
    if namelong <= 0:
        maxlong = cnlen(name) + 2

    for t in text:
        long = cnlen(t)
        print(f"{style[5]}{style[6]}{t}{style[6]}" + style[6] * (maxlong-long) + style[5])
    print(f"{style[2]}{style[4]}" + style[4] * maxlong + f"{style[4]}{style[3]}")

def demo():
    box("你好",
        "这是PizzaUI的dome",
        "PizzaUI和PyPizza的很多元素都几乎一样",
        "但请注意",
        "PyPizza未使用这个库",
        "PyPizza更多使用硬代码",
        "虽然使用PizzaUI看起来更方便",
        "但硬代码代表更少的依赖和更可靠的运行",
        "且更定制化", name='dome')