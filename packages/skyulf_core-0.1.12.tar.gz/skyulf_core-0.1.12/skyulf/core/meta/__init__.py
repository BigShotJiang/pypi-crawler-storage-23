"""Metadata helpers for Skyulf nodes."""
