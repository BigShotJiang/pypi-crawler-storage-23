import namaka

# Initialize a run (creates project if it doesn't exist)
run = namaka.init(
    project="my-project",
    api_url="http://localhost:8000/api/v1",
    name="experiment-alpha",
)

# Log hyperparameters
run["parameters"] = {
    "learning_rate": 0.001,
    "batch_size": 64,
    "model_type": "transformer",
}

# Log metrics during training
for epoch in range(100):
    loss = train_step()
    accuracy = evaluate()
    run.log("train/loss", loss, step=epoch)
    run.log("val/accuracy", accuracy, step=epoch)

# Finalize the run
run.stop()