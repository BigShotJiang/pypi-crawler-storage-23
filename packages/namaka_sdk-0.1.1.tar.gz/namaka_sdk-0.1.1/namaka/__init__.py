from namaka.run import Run

__all__ = ["init", "Run"]


def init(
    project: str,
    api_url: str = "http://localhost:8000/api/v1",
    name: str | None = None,
    api_token: str | None = None,
) -> Run:
    """Initialize a new run.

    Args:
        project: Project name (or "workspace/project" format).
        api_url: Backend API base URL.
        name: Optional run name.
        api_token: Optional API token (reserved for future auth).

    Returns:
        A Run object for logging metrics and parameters.
    """
    return Run._create(project=project, api_url=api_url, name=name, api_token=api_token)
