"""FastAPI server for team formation."""

from team_formation.api.main import app

__all__ = ["app"]
