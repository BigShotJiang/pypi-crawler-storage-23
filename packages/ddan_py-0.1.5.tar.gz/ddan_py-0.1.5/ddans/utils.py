# -*- coding: utf-8 -*-

import traceback
import sys
from multiprocessing import freeze_support

from ddans.common.executor import DExecutor
from ddans.data.color import DColor
from ddans.native.log import NLog
from ddans.single.net import SNetter


class Utils():
    net: SNetter = SNetter()
    executor: DExecutor = DExecutor()

    @staticmethod
    def catch(func, *args, **kwargs):
        ret = None
        try:
            ret = func(*args, **kwargs)
            if ret is None:
                ret = True
        except KeyboardInterrupt:
            pass
        except Exception:
            et, ev, tb = sys.exc_info()
            msg = traceback.format_exception(et, ev, tb)
            for m in msg:
                if m.find("catch") < 0:
                    NLog.printf(m, fc=DColor.red)
        finally:
            return ret

    @staticmethod
    def pause():
        return input("Press any key to continue . . .")

    @staticmethod
    def freeze_support():
        freeze_support()
