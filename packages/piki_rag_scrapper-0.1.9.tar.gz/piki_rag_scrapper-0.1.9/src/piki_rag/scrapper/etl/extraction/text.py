from functools import wraps
from pathlib import Path

import PyPDF2
from docx import Document
from piki_rag.common.exception import FileNotFoundException

from .common import Extractor


def file_exists(func):
    @wraps(func)
    def wrapper(self, path):
        if not Path(path).exists():
            raise FileNotFoundException(f"Файл {path} не найден")
        return func(self, path)

    return wrapper


class PdfExtractor(Extractor):
    def is_extractable(self, path: str) -> bool:
        return path.endswith(".pdf")

    @file_exists
    def extract(self, path: str) -> str:
        with open(path, "rb") as file:
            pdf = PyPDF2.PdfReader(file)
            return "".join([
                page.extract_text()
                for page in pdf.pages
            ])


class DocxExtractor(Extractor):
    def is_extractable(self, path: str) -> bool:
        return path.endswith(('.docx', '.doc'))

    @file_exists
    def extract(self, path: str) -> str:
        doc = Document(path)
        return '\n'.join([p.text for p in doc.paragraphs])


class TxtExtractor(Extractor):
    def is_extractable(self, path: str) -> bool:
        return path.endswith('.txt')

    @file_exists
    def extract(self, path: str) -> str:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
