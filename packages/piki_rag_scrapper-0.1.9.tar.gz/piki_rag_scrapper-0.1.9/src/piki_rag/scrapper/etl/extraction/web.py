from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse

import trafilatura
from piki_rag.common.exception import WebScrappingException
from playwright.sync_api import sync_playwright
from playwright_stealth import Stealth

from .common import Extractor


class DefaultWebExtractor(Extractor):
    def __init__(self, timeout: int = 30000, headless: bool = True):
        self.timeout = timeout
        self.headless = headless
        self._executor = ThreadPoolExecutor()

    def is_extractable(self, path: str) -> bool:
        return path and urlparse(path).scheme in ["http", "https"]

    def _extract_in_thread(self, path: str) -> str:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=self.headless)
            page = None
            try:
                page = browser.new_page()
                Stealth().apply_stealth_sync(page)
                page.goto(path, timeout=self.timeout)
                try:
                    page.wait_for_load_state('networkidle', timeout=self.timeout)
                except Exception as e:
                    if self.headless:
                        raise WebScrappingException() from e
                html = page.content()
                text = trafilatura.extract(html, include_comments=False, include_tables=True)
                if not text:
                    raise WebScrappingException(f"Текст для ресурса {path} не найден")
                return text
            except WebScrappingException:
                raise
            except Exception as e:
                raise WebScrappingException() from e
            finally:
                if page:
                    page.close()
                browser.close()

    def extract(self, path: str) -> str:
        future = self._executor.submit(self._extract_in_thread, path)
        return future.result()

    def __del__(self):
        self._executor.shutdown(wait=False)


class MultiStrategyWebExtractor(Extractor):
    def __init__(self, timeout: int = 30000):
        self.web_extractors = [
            DefaultWebExtractor(timeout, True),
            DefaultWebExtractor(timeout, False)
        ]

    def is_extractable(self, path: str) -> bool:
        return self.web_extractors[0].is_extractable(path)

    def extract(self, path: str) -> str:
        last_error = None
        for extractor in self.web_extractors:
            try:
                result = extractor.extract(path)
                if result:
                    return result
            except WebScrappingException as e:
                last_error = e
                continue

        if last_error:
            raise WebScrappingException() from last_error
        raise WebScrappingException()
