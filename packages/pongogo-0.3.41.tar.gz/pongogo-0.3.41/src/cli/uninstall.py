"""Pongogo uninstall helper functions.

This module provides helper functions for removing Pongogo configuration
from various config files. Used by the main `pongogo uninstall` command.
"""

import json
import os

from .console import console, print_error, print_success


def debug_print(message: str, debug: bool) -> None:
    """Print debug message if debug mode is enabled."""
    if debug:
        console.print(f"[dim][DEBUG] {message}[/dim]")


def remove_from_mcp_json(path: str, debug: bool = False) -> bool:
    """Remove pongogo-knowledge from an MCP config file.

    Args:
        path: Path to the .mcp.json file
        debug: Whether to print debug output

    Returns:
        True if successful, False if error occurred
    """
    abs_path = os.path.abspath(path)
    debug_print(f"Processing: {abs_path}", debug)

    if not os.path.exists(path):
        debug_print(f"File not found: {abs_path}", debug)
        return True  # Not an error - file doesn't exist

    try:
        with open(path) as f:
            config = json.load(f)

        if debug:
            keys = list(config.get("mcpServers", {}).keys())
            debug_print(f"Keys in mcpServers: {keys}", debug)

        if "mcpServers" in config and "pongogo-knowledge" in config["mcpServers"]:
            del config["mcpServers"]["pongogo-knowledge"]

            if not config["mcpServers"]:
                # Remove file if mcpServers is now empty
                os.remove(path)
                # Verify removal
                if os.path.exists(path):
                    print_error(f"Failed to remove {abs_path} - file still exists!")
                    return False
                print_success(f"Removed {path} (no other MCP servers configured)")
            else:
                with open(path, "w") as f:
                    json.dump(config, f, indent=2)
                print_success(f"Removed pongogo-knowledge from {path}")
        else:
            print_success(f"No pongogo-knowledge config found in {path}")

        return True

    except PermissionError as e:
        print_error(f"Permission denied: {abs_path} - {e}")
        return False
    except json.JSONDecodeError as e:
        print_error(f"Invalid JSON in {abs_path}: {e}")
        return False
    except Exception as e:
        print_error(f"Could not modify {path}: {e}")
        if debug:
            import traceback

            traceback.print_exc()
        return False


def remove_from_claude_mcp_json(debug: bool = False) -> bool:
    """Remove pongogo-knowledge from .claude/mcp.json.

    Also removes empty .claude directory if applicable.
    """
    path = ".claude/mcp.json"
    abs_path = os.path.abspath(path)
    debug_print(f"Processing: {abs_path}", debug)

    if not os.path.exists(path):
        debug_print(f"File not found: {abs_path}", debug)
        return True

    try:
        with open(path) as f:
            config = json.load(f)

        if "mcpServers" in config and "pongogo-knowledge" in config["mcpServers"]:
            del config["mcpServers"]["pongogo-knowledge"]

            if not config["mcpServers"]:
                os.remove(path)
                if os.path.exists(path):
                    print_error(f"Failed to remove {abs_path} - file still exists!")
                    return False

                # Remove .claude dir if empty
                if os.path.isdir(".claude") and not os.listdir(".claude"):
                    os.rmdir(".claude")
                    print_success(
                        "Removed .claude/mcp.json and empty .claude/ directory"
                    )
                else:
                    print_success("Removed .claude/mcp.json (no other MCP servers)")
            else:
                with open(path, "w") as f:
                    json.dump(config, f, indent=2)
                print_success("Removed pongogo-knowledge from .claude/mcp.json")
        else:
            print_success("No pongogo-knowledge config found in .claude/mcp.json")

        return True

    except PermissionError as e:
        print_error(f"Permission denied: {abs_path} - {e}")
        return False
    except Exception as e:
        print_error(f"Could not modify .claude/mcp.json: {e}")
        if debug:
            import traceback

            traceback.print_exc()
        return False


def remove_hooks_from_settings(debug: bool = False) -> bool:
    """Remove pongogo-route hooks from .claude/settings.local.json."""
    path = ".claude/settings.local.json"
    abs_path = os.path.abspath(path)
    debug_print(f"Processing: {abs_path}", debug)

    if not os.path.exists(path):
        debug_print(f"File not found: {abs_path}", debug)
        return True

    try:
        with open(path) as f:
            config = json.load(f)

        modified = False
        if "hooks" in config and "UserPromptSubmit" in config["hooks"]:
            new_hooks = []
            for hook_group in config["hooks"]["UserPromptSubmit"]:
                if "hooks" in hook_group:
                    hook_group["hooks"] = [
                        h
                        for h in hook_group["hooks"]
                        if "pongogo-route" not in h.get("command", "")
                    ]
                    if hook_group["hooks"]:
                        new_hooks.append(hook_group)
                else:
                    new_hooks.append(hook_group)

            if new_hooks:
                config["hooks"]["UserPromptSubmit"] = new_hooks
            else:
                del config["hooks"]["UserPromptSubmit"]

            if not config["hooks"]:
                del config["hooks"]

            modified = True

        if modified:
            if not config:
                os.remove(path)
                if os.path.exists(path):
                    print_error(f"Failed to remove {abs_path} - file still exists!")
                    return False
                print_success("Removed .claude/settings.local.json (no other settings)")
            else:
                with open(path, "w") as f:
                    json.dump(config, f, indent=2)
                print_success("Removed pongogo hooks from .claude/settings.local.json")
        else:
            print_success("No pongogo hooks found in .claude/settings.local.json")

        return True

    except PermissionError as e:
        print_error(f"Permission denied: {abs_path} - {e}")
        return False
    except Exception as e:
        print_error(f"Could not modify .claude/settings.local.json: {e}")
        if debug:
            import traceback

            traceback.print_exc()
        return False


def remove_from_global_claude_json(debug: bool = False) -> bool:
    """Remove pongogo-knowledge from ~/.claude.json.

    Handles:
    - Top-level mcpServers (legacy global config)
    - Project-scoped mcpServers under "projects" dict (current Claude Code format)
    """
    path = os.path.expanduser("~/.claude.json")
    debug_print(f"Processing: {path}", debug)

    if not os.path.exists(path):
        debug_print(f"File not found: {path}", debug)
        return True

    try:
        with open(path) as f:
            config = json.load(f)

        modified = False
        removed_from = []

        # Check top-level mcpServers (legacy)
        if "mcpServers" in config and "pongogo-knowledge" in config["mcpServers"]:
            del config["mcpServers"]["pongogo-knowledge"]
            modified = True
            removed_from.append("top-level")

        # Check project-scoped entries under "projects" dict (current format)
        projects = config.get("projects", {})
        if isinstance(projects, dict):
            for project_path, project_config in projects.items():
                if isinstance(project_config, dict):
                    if (
                        "mcpServers" in project_config
                        and "pongogo-knowledge" in project_config["mcpServers"]
                    ):
                        del project_config["mcpServers"]["pongogo-knowledge"]
                        modified = True
                        removed_from.append(f"project '{project_path}'")
                        debug_print(
                            f"Removed from project scope: {project_path}", debug
                        )

        if modified:
            with open(path, "w") as f:
                json.dump(config, f, indent=2)
            locations = ", ".join(removed_from)
            print_success(
                f"Removed pongogo-knowledge from ~/.claude.json ({locations})"
            )
        # Silent when nothing to remove — this is the normal case for pip/Homebrew installs

        return True

    except PermissionError as e:
        print_error(f"Permission denied: {path} - {e}")
        return False
    except Exception as e:
        print_error(f"Could not modify ~/.claude.json: {e}")
        if debug:
            import traceback

            traceback.print_exc()
        return False
