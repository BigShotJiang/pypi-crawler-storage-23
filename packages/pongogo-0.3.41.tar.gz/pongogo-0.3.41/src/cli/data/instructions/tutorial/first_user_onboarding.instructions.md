---
pongogo_instruction_spec: "0.0.2"
title: "First User Onboarding Tutorial Nudge"
description: "Soft nudge for new users to try the interactive tutorial. Non-blocking, advisory only."
applies_to:
  - "**/*"
domains:
  - "onboarding"
  - "tutorial"
priority: "P3"
pongogo_version: "2026-02-25"
source: "Original"

id: tutorial:first_user_onboarding
routing:
  protected: false
  priority: 100
  always_include: false
  description: Nudges new users toward the interactive tutorial
  triggers:
    keywords:
      - getting started
      - how does pongogo work
      - what can pongogo do
      - pongogo tutorial
      - new to pongogo
      - first time
      - onboarding
      - learn pongogo
      - pongogo help
      - how to use pongogo
evaluation:
  success_signals:
    - Tutorial nudge shown to new users on first few interactions
    - Nudge stops after 3 ignored prompts (decay)
    - Nudge stops entirely when tutorial is complete
  failure_signals:
    - Nudge shown to users who completed the tutorial
    - Nudge blocks or interrupts user workflow
    - Nudge shown more than 3 times when ignored
---

# First User Onboarding Tutorial Nudge

**Purpose**: Gently suggest the interactive tutorial to new Pongogo users. Non-blocking and advisory only.

## When This Applies

This instruction routes when:
1. The user's message matches onboarding-related keywords (above), OR
2. This is one of the user's first few interactions after `pongogo init`

## Behavior

### Step 1: Check Tutorial Progress

Call `get_tutorial_progress` MCP tool to check current state.

### Step 2: Decide Whether to Nudge

**Do NOT nudge if:**
- `all_complete` is true (user finished the tutorial)
- `completed_count` > 0 AND routing events count > 5 (user is actively using Pongogo and knows about the tutorial)
- User has already been nudged once in this conversation

**Decay rule**: If `completed_count` is 0 and routing event stats show > 3 total events, the user has had multiple interactions without engaging the tutorial. They've chosen not to — stop nudging entirely.

**Principle**: The tutorial is optional. Experienced users who run `pongogo init` on a new repo should never feel pressured. One mention is enough — after that, the user knows it exists.

### Step 3: Show Nudge (if applicable)

The nudge should reflect where the user is in the tutorial:

**If completed_count is 0** (never started):
> Tip: Run `/pongogo-tutorial` if you'd like a guided tour — it's optional and you can skip it.

**If completed_count > 0 but not all complete** (started but bailed out):
> Tip: You left off at step [next_step.step_number] of the tutorial ([next_step.title]). Run `/pongogo-tutorial` to pick up where you left off.

**Important**: This is advisory only. Do NOT:
- Block the user's current request
- Make the tutorial the focus of your response
- Repeat the nudge if it was already shown in this conversation
- Use preceptor enforcement or compliance blocking

Answer the user's actual question first, then append the tip at the end.