---
description: Collect diagnostic data for support
---

# Pongogo Debug

Collect all diagnostic data into a single report for troubleshooting and support.

## Usage

```
/pongogo-debug
```

## Execution

1. Run `pongogo debug --json` via Bash to collect all diagnostic data
2. Parse the JSON output
3. Present a formatted summary to the user
4. Tell the user the report file location

### Step 1: Run the debug command

```bash
pongogo debug --json 2>/dev/null
```

### Step 2: Interpret the results

The JSON output contains these sections:

| Section | Key | What to check |
|---------|-----|----------------|
| Install & Environment | `install_env` | `install_method`, `version`, `entry_points` |
| Hook Configuration | `hooks` | `has_docker_refs` (should be false), `duplicate_hooks` (should be false) |
| MCP Configuration | `mcp` | `configured` (should be true), `health.overall` (should be "healthy") |
| State Files | `state_files` | `database.exists` (should be true), `mcp_state` |
| Shell Environment | `shell_env` | `pongogo_is_bash_wrapper` (should be false/null) |

### Step 3: Present findings

Format the output as a clear summary:

```markdown
## Pongogo Debug Report

**Version**: [display_version]
**Install Method**: [install_method]
**MCP Health**: [health status]

### Issues Found
- [List any problems detected]

### Recommended Actions
- [Specific fix commands]
```

### Step 4: Save and share

Also run the markdown version to save a file:

```bash
pongogo debug
```

Tell the user:
> Report saved to `.pongogo/debug-report.md` — share this file for support.

### Common Issues and Fixes

| Issue | Fix |
|-------|-----|
| `has_docker_refs: true` | Run `pongogo init --force` to update hooks from Docker to native |
| `duplicate_hooks: true` | Edit `.claude/settings.local.json` and remove duplicate entries |
| `mcp.configured: false` | Run `pongogo init` or `pongogo setup-mcp` |
| `mcp.health.overall: unhealthy` | Restart Claude Code to reload MCP server |
| `database.exists: false` | Run `pongogo init` |
| `pongogo_is_bash_wrapper: true` | Uninstall Docker wrapper: remove the bash script and reinstall via pip/Homebrew |
| Entry point not found | Run `pip install -e .` or `brew reinstall pongogo` |

### Privacy Note

The debug report contains:
- ✅ System info (OS, install method, Python version)
- ✅ File paths and existence checks
- ✅ Hook configuration structure
- ✅ Version information
- ❌ NO file contents
- ❌ NO personal data
- ❌ NO API keys (all secrets redacted)
