"""Setup MCP server integration with Claude Code."""

import json
import os
import shutil
import subprocess
from datetime import datetime
from pathlib import Path

import typer

from .console import RICH_AVAILABLE, console


def has_docker() -> bool:
    """Check if Docker is available and running."""
    try:
        result = subprocess.run(
            ["docker", "info"],
            capture_output=True,
            timeout=5,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return False


def get_project_mcp_config_path() -> Path:
    """Get path to project-local MCP configuration file.

    Uses .mcp.json in project root (Claude Code's standard location).
    """
    return Path.cwd() / ".mcp.json"


def get_mcp_config(container_name: str | None = None, native: bool = False) -> dict:
    """Generate MCP server configuration for Claude Code.

    If native is True, generates a direct entry point config (no Docker).
    If a container_name is provided, generates a ``docker exec`` config
    that connects to the named daemon container. Otherwise, falls back
    to the legacy ``docker run`` approach for backwards compatibility.

    Args:
        container_name: Name of the daemon container to exec into.
            If None and not native, uses ephemeral docker run.
        native: If True, use native entry point (pip/Homebrew install).
    """
    if native:
        return {
            "command": "pongogo-server",
        }

    if container_name:
        return {
            "command": "docker",
            "args": ["exec", "-i", container_name, "pongogo-server"],
        }

    # Fallback: ephemeral docker run (backwards compatibility)
    host_project_dir = os.environ.get("HOST_PROJECT_DIR")
    if host_project_dir:
        pongogo_abs_path = f"{host_project_dir}/.pongogo"
    else:
        pongogo_abs_path = str((Path.cwd() / ".pongogo").resolve())

    uid = int(os.environ.get("HOST_UID", os.getuid()))
    gid = int(os.environ.get("HOST_GID", os.getgid()))

    image = os.environ.get("PONGOGO_IMAGE", "pongogo.azurecr.io/pongogo:stable")

    config = {
        "command": "docker",
        "args": [
            "run",
            "-i",
            "--rm",
            "--user",
            f"{uid}:{gid}",
            "-v",
            f"{pongogo_abs_path}:/project/.pongogo:z",
            image,
        ],
    }

    return config


def load_mcp_config(path: Path) -> dict:
    """Load existing MCP configuration or return default."""
    if path.exists():
        try:
            with open(path) as f:
                return json.load(f)
        except json.JSONDecodeError:
            console.print(
                "[yellow]Warning: Could not parse existing config, starting fresh[/yellow]"
            )
    return {}


def backup_config(path: Path) -> Path | None:
    """Create backup of existing config file."""
    if path.exists():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = path.with_suffix(f".backup_{timestamp}.json")
        shutil.copy(path, backup_path)
        return backup_path
    return None


def merge_mcp_config(existing: dict, new_server_config: dict) -> dict:
    """Merge new MCP server config into existing MCP config."""
    # Ensure mcpServers key exists
    if "mcpServers" not in existing:
        existing["mcpServers"] = {}

    # Add/update pongogo server
    existing["mcpServers"]["pongogo-knowledge"] = new_server_config

    return existing


def setup_mcp_command(
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        "-n",
        help="Show what would be done without making changes",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Overwrite existing pongogo configuration if present",
    ),
) -> None:
    """Configure Claude Code to use Pongogo MCP server.

    Creates .mcp.json in the current project directory. In native mode
    (pip/Homebrew install), uses entry points directly. In Docker mode,
    uses Docker volume mounts for multi-repo isolation.
    """
    # Detect native mode: if PONGOGO_CONTAINER_NAME is not set, try native
    native_mode = os.environ.get("PONGOGO_CONTAINER_NAME") is None

    if not native_mode and not has_docker():
        console.print(
            "[red]Error: Docker is required for Docker-mode Pongogo MCP server.[/red]"
        )
        console.print("\nDocker ensures proper isolation when using Pongogo across")
        console.print("multiple repositories on the same machine.")
        console.print("\n[bold]To install Docker:[/bold]")
        console.print("  macOS: brew install --cask docker")
        console.print("  Linux: https://docs.docker.com/engine/install/")
        console.print(
            "  Windows: https://docs.docker.com/desktop/install/windows-install/"
        )
        console.print("\nAfter installing, ensure Docker is running and try again.")
        raise typer.Exit(1)

    config_path = get_project_mcp_config_path()
    mcp_config = get_mcp_config(native=native_mode)

    # Load existing config
    existing_config = load_mcp_config(config_path)

    # Check if pongogo already configured
    if (
        "mcpServers" in existing_config
        and "pongogo-knowledge" in existing_config["mcpServers"]
        and not force
    ):
        console.print("[yellow]Pongogo MCP server already configured.[/yellow]")
        console.print("Use --force to overwrite existing configuration.")
        raise typer.Exit(1)

    # Merge configuration
    merged_config = merge_mcp_config(existing_config.copy(), mcp_config)

    if dry_run:
        console.print("[bold]Dry run - no changes made[/bold]\n")
        console.print(f"Config path: {config_path}")
        console.print("Method: Docker (required for multi-repo isolation)\n")
        console.print("[bold]Configuration to add:[/bold]")
        config_json = json.dumps(
            {"mcpServers": {"pongogo-knowledge": mcp_config}}, indent=2
        )
        if RICH_AVAILABLE:
            console.print_json(config_json)
        else:
            print(config_json)
        return

    # Create backup
    backup_path = backup_config(config_path)
    if backup_path:
        console.print(f"[dim]Backup created: {backup_path}[/dim]")

    # Write merged config
    with open(config_path, "w") as f:
        json.dump(merged_config, f, indent=2)

    # Success message
    mode_label = "native" if native_mode else "Docker"
    console.print(f"[green]Pongogo MCP server configured ({mode_label})[/green]")
    console.print(f"[dim]Config: {config_path}[/dim]")
    console.print("\n[bold]Next steps:[/bold]")
    console.print("1. Restart Claude Code to pick up the new configuration")
    console.print("2. Ensure your project has .pongogo/instructions/ directory")
