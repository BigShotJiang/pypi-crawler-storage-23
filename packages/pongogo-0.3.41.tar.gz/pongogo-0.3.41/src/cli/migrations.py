"""Post-upgrade config migration system for Pongogo.

Automatically patches project-local config (settings.json, config.yaml) after
upgrades, following the database migration pattern already used for SQLite schema.

Entry points:
  1. `pongogo migrate` CLI command
  2. `pongogo upgrade` CLI (calls migrate after successful package upgrade)
  3. MCP server startup (_deferred_startup) — catches Docker upgrades

Each migration is a pure function that patches settings.json. A monotonic
config_schema_version integer in .pongogo/config.yaml tracks which migrations
have been applied (same pattern as PRAGMA user_version in database.py).
"""

from __future__ import annotations

import json
import logging
import tempfile
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

# Increment when adding new migrations. Must equal len(MIGRATIONS).
CURRENT_CONFIG_VERSION = 1

# Pongogo hook command markers — used to distinguish Pongogo hooks from user hooks.
_PONGOGO_MARKERS = (
    "pongogo-route",
    "pongogo-pretooluse-check",
    "pongogo-compliance-check",
    "pongogo-posttooluse-route",
    "pongogo-subagent-hook",
    "pongogo-stop-hook",
    "python -m mcp_server.hooks.",
)


@dataclass
class MigrationResult:
    """Result of running migrations."""

    applied_count: int = 0
    from_version: int = 0
    to_version: int = 0
    changes: list[str] = field(default_factory=list)
    success: bool = True
    error: str | None = None


def _is_pongogo_hook(command: str) -> bool:
    """Detect whether a hook command belongs to Pongogo.

    Returns True for commands containing Pongogo entry-point names or
    the mcp_server.hooks module path. This lets us distinguish
    Pongogo-managed hooks from user-added hooks in the same hook type.
    """
    return any(marker in command for marker in _PONGOGO_MARKERS)


def _build_hook_cmd(
    native_cmd: str,
    mode: str,
    container_name: str | None,
    docker_cmd: str | None = None,
) -> str:
    """Build the correct hook command string for native or Docker mode.

    Args:
        native_cmd: Entry-point name for native mode (pip-installed shim).
        mode: "native" or "docker".
        container_name: Docker container name (required in docker mode).
        docker_cmd: Override command for Docker mode. If None, uses native_cmd.
    """
    if mode == "native":
        return f'"$CLAUDE_PROJECT_DIR"/.venv/bin/{native_cmd}'
    return f"docker exec -i {container_name} {docker_cmd or native_cmd}"


def _build_canonical_hooks(
    mode: str, container_name: str | None = None
) -> dict[str, Any]:
    """Generate the canonical hook configuration dict.

    This is the single source of truth for what hooks Pongogo installs.
    Both `pongogo init` and the migration system call this function.

    Args:
        mode: "native" or "docker".
        container_name: Docker container name (required when mode="docker").

    Returns:
        A dict suitable for use as the "hooks" value in settings.json.
    """

    def _cmd(native: str, docker_override: str | None = None) -> str:
        return _build_hook_cmd(native, mode, container_name, docker_override)

    route_cmd = _cmd("pongogo-route")
    pretooluse_cmd = _cmd(
        "pongogo-pretooluse-check",
        "python -m mcp_server.hooks.pretooluse_compliance_hook",
    )
    posttooluse_cmd = _cmd("pongogo-compliance-check")
    posttooluse_route_cmd = _cmd(
        "pongogo-posttooluse-route",
        "python -m mcp_server.hooks.posttooluse_routing_hook",
    )
    subagent_cmd = _cmd(
        "pongogo-subagent-hook",
        "python -m mcp_server.hooks.subagent_observation_hook",
    )
    stop_cmd = _cmd(
        "pongogo-stop-hook",
        "python -m mcp_server.hooks.stop_response_capture_hook",
    )

    return {
        "UserPromptSubmit": [{"hooks": [{"type": "command", "command": route_cmd}]}],
        "PreToolUse": [
            {
                "matcher": "mcp__github__close_issue",
                "hooks": [{"type": "command", "command": pretooluse_cmd}],
            },
            {
                "matcher": "mcp__github__update_issue",
                "hooks": [{"type": "command", "command": pretooluse_cmd}],
            },
            {
                "matcher": "Bash",
                "hooks": [{"type": "command", "command": pretooluse_cmd}],
            },
        ],
        "PostToolUse": [
            {
                "matcher": "Read",
                "hooks": [{"type": "command", "command": posttooluse_cmd}],
            },
            {
                "matcher": "Write",
                "hooks": [{"type": "command", "command": posttooluse_cmd}],
            },
            {
                "matcher": "Edit",
                "hooks": [{"type": "command", "command": posttooluse_cmd}],
            },
            {
                "matcher": "Bash",
                "hooks": [{"type": "command", "command": posttooluse_cmd}],
            },
            {
                "matcher": "AskUserQuestion",
                "hooks": [{"type": "command", "command": posttooluse_route_cmd}],
            },
        ],
        "SubagentStart": [{"hooks": [{"type": "command", "command": subagent_cmd}]}],
        "SubagentStop": [{"hooks": [{"type": "command", "command": subagent_cmd}]}],
        "Stop": [{"hooks": [{"type": "command", "command": stop_cmd}]}],
    }


def _extract_matchers(hook_entries: list[dict[str, Any]]) -> set[str | None]:
    """Extract the set of matcher values from a hook-type's entry list.

    Entries without a "matcher" key get None (match-all entries like
    UserPromptSubmit).
    """
    return {entry.get("matcher") for entry in hook_entries}


def _get_settings_path(project_root: Path, mode: str) -> Path:
    """Return the correct settings file path for the mode."""
    claude_dir = project_root / ".claude"
    if mode == "native":
        return claude_dir / "settings.json"
    return claude_dir / "settings.local.json"


def _read_config_version(config_path: Path) -> int:
    """Read config_schema_version from config.yaml, defaulting to 0."""
    if not config_path.exists():
        return 0
    try:
        with open(config_path) as f:
            config = yaml.safe_load(f) or {}
        return int(config.get("config_schema_version", 0))
    except (yaml.YAMLError, ValueError, TypeError):
        return 0


def _write_config_version(config_path: Path, version: int) -> None:
    """Update config_schema_version in config.yaml, preserving other keys."""
    config: dict[str, Any] = {}
    if config_path.exists():
        try:
            with open(config_path) as f:
                config = yaml.safe_load(f) or {}
        except yaml.YAMLError:
            config = {}
    config["config_schema_version"] = version
    # Atomic write — intentionally not using context manager because
    # delete=False + rename requires the file to outlive the block.
    tmp = tempfile.NamedTemporaryFile(  # noqa: SIM115
        mode="w", dir=config_path.parent, suffix=".yaml", delete=False
    )
    try:
        yaml.dump(config, tmp, default_flow_style=False, sort_keys=False)
        tmp.close()
        Path(tmp.name).replace(config_path)
    except Exception:
        Path(tmp.name).unlink(missing_ok=True)
        raise


def _atomic_write_json(path: Path, data: dict[str, Any]) -> None:
    """Write JSON atomically (write to temp then rename)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = tempfile.NamedTemporaryFile(  # noqa: SIM115
        mode="w", dir=path.parent, suffix=".json", delete=False
    )
    try:
        json.dump(data, tmp, indent=2)
        tmp.write("\n")
        tmp.close()
        Path(tmp.name).replace(path)
    except Exception:
        Path(tmp.name).unlink(missing_ok=True)
        raise


# ---------------------------------------------------------------------------
# Migration 001: Ensure complete hook set matches init output
# ---------------------------------------------------------------------------


def _migration_001_full_hook_set(
    project_root: Path, mode: str, container_name: str | None, dry_run: bool
) -> list[str]:
    """Ensure the full set of hooks and matchers are present.

    Adds missing matchers (Write, Edit, Bash PostToolUse) and missing hook
    types (SubagentStart, SubagentStop, Stop, PreToolUse) without replacing
    existing entries. Preserves non-Pongogo hooks.

    Returns a list of human-readable change descriptions.
    """
    changes: list[str] = []
    settings_path = _get_settings_path(project_root, mode)

    if not settings_path.exists():
        # No settings file — nothing to migrate (init hasn't run yet)
        return changes

    try:
        settings = json.loads(settings_path.read_text())
    except (json.JSONDecodeError, OSError):
        return changes

    hooks = settings.get("hooks", {})
    canonical = _build_canonical_hooks(mode, container_name)
    modified = False

    for hook_type, canonical_entries in canonical.items():
        if hook_type not in hooks:
            # Entire hook type missing — add wholesale
            hooks[hook_type] = canonical_entries
            modified = True
            changes.append(f"Added hook type: {hook_type}")
            continue

        existing_entries = hooks[hook_type]
        existing_matchers = _extract_matchers(existing_entries)

        for canonical_entry in canonical_entries:
            matcher = canonical_entry.get("matcher")
            if matcher not in existing_matchers:
                # Missing matcher — append
                existing_entries.append(canonical_entry)
                modified = True
                label = f"{hook_type}[{matcher}]" if matcher else hook_type
                changes.append(f"Added matcher: {label}")

    if modified and not dry_run:
        settings["hooks"] = hooks
        _atomic_write_json(settings_path, settings)

    return changes


# ---------------------------------------------------------------------------
# Migration registry
# ---------------------------------------------------------------------------

# Each entry: (version_number, migration_function)
# The function signature is:
#   fn(project_root, mode, container_name, dry_run) -> list[str]
MigrationFn = Callable[[Path, str, str | None, bool], list[str]]

MIGRATIONS: list[tuple[int, MigrationFn]] = [
    (1, _migration_001_full_hook_set),
]

# Invariant: CURRENT_CONFIG_VERSION must equal the highest version in MIGRATIONS
assert len(MIGRATIONS) == CURRENT_CONFIG_VERSION, (
    f"CURRENT_CONFIG_VERSION ({CURRENT_CONFIG_VERSION}) must equal "
    f"len(MIGRATIONS) ({len(MIGRATIONS)})"
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def run_migrations(
    project_root: Path,
    *,
    dry_run: bool = False,
    force: bool = False,
) -> MigrationResult:
    """Apply pending config migrations to a Pongogo project.

    Args:
        project_root: Root of the project (where .pongogo/ lives).
        dry_run: If True, report what would change without writing.
        force: If True, re-run all migrations regardless of current version.

    Returns:
        MigrationResult with details of what was (or would be) applied.
    """
    config_path = project_root / ".pongogo" / "config.yaml"
    result = MigrationResult()

    if not config_path.exists():
        result.success = False
        result.error = "No .pongogo/config.yaml found — run 'pongogo init' first"
        return result

    # Read project config for mode and container_name
    try:
        with open(config_path) as f:
            config = yaml.safe_load(f) or {}
    except (yaml.YAMLError, OSError) as e:
        result.success = False
        result.error = f"Failed to read config.yaml: {e}"
        return result

    mode = config.get("mode", "native")
    container_name = config.get("container_name")
    current_version = int(config.get("config_schema_version", 0))

    if force:
        current_version = 0

    result.from_version = current_version
    result.to_version = current_version  # updated as migrations apply

    if current_version >= CURRENT_CONFIG_VERSION and not force:
        # Already up to date
        return result

    # Apply each pending migration in order
    for version, migration_fn in MIGRATIONS:
        if version <= current_version:
            continue
        try:
            changes = migration_fn(project_root, mode, container_name, dry_run)
            result.changes.extend(changes)
            result.applied_count += 1
            result.to_version = version
        except Exception as e:
            result.success = False
            result.error = f"Migration {version} failed: {e}"
            logger.error(f"Migration {version} failed: {e}")
            break

    # Persist new version (unless dry run or failure)
    if result.success and result.applied_count > 0 and not dry_run:
        try:
            _write_config_version(config_path, result.to_version)
        except Exception as e:
            result.success = False
            result.error = f"Failed to update config_schema_version: {e}"

    return result
