"""Pongogo CLI entry point."""

import os
import shutil

import typer

from . import get_display_version
from .console import console, print_error, print_success, print_warning
from .debug_command import debug_command
from .discoveries import app as discoveries_app
from .init_command import init_command
from .setup_mcp import setup_mcp_command
from .uninstall import (
    remove_from_claude_mcp_json,
    remove_from_global_claude_json,
    remove_from_mcp_json,
    remove_hooks_from_settings,
)

# Conditionally import validate command for beta/alpha builds only
# PONGOGO_CHANNEL is set during Docker build (stable builds won't have this)
_CHANNEL = os.environ.get("PONGOGO_CHANNEL", "stable")
_VALIDATE_AVAILABLE = _CHANNEL in ("alpha", "beta")

app = typer.Typer(
    name="pongogo",
    help="Pongogo - AI agent knowledge routing for your repository",
    no_args_is_help=True,
    epilog="Run 'pongogo COMMAND --help' for command-specific options.",
)


def version_callback(value: bool) -> None:
    """Show version and exit."""
    if value:
        console.print(f"pongogo version {get_display_version()}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None,
        "--version",
        "-v",
        help="Show version and exit",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """Pongogo - AI agent knowledge routing for your repository."""
    pass


# Register the init command
app.command(name="init")(init_command)


@app.command(name="migrate")
def migrate_command(
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        "-n",
        help="Show what would change without applying",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Re-run all migrations regardless of current version",
    ),
) -> None:
    """Apply pending config migrations after a Pongogo upgrade.

    Patches .claude/settings.json with any new hooks or matchers added
    since the last init/migrate. Safe to run multiple times (idempotent).
    """
    from pathlib import Path

    from .migrations import run_migrations

    result = run_migrations(Path.cwd(), dry_run=dry_run, force=force)

    if not result.success:
        print_error(f"Migration failed: {result.error}")
        raise typer.Exit(1)

    if result.applied_count == 0:
        print_success(f"Already up to date (config version {result.from_version})")
        return

    verb = "Would apply" if dry_run else "Applied"
    print_success(
        f"{verb} {result.applied_count} migration(s) "
        f"(version {result.from_version} → {result.to_version})"
    )
    for change in result.changes:
        console.print(f"  • {change}")


# Register the debug command
app.command(name="debug")(debug_command)

# Register the setup-mcp command
app.command(name="setup-mcp")(setup_mcp_command)

# Register the discoveries subcommand group
app.add_typer(discoveries_app, name="discoveries")

# Register validate command ONLY for beta/alpha builds
# This command runs the same validation suite used in CI for troubleshooting
if _VALIDATE_AVAILABLE:
    from .validate_command import validate_command

    app.command(name="validate")(validate_command)


def get_pongogo_image() -> str:
    """Get the Pongogo Docker image name.

    PONGOGO_IMAGE is baked into the Docker image at build time by CI/CD,
    ensuring each release channel (beta/stable) knows its own identity.
    Falls back to stable if not set (e.g., during local development).
    """
    return os.environ.get("PONGOGO_IMAGE", "pongogo.azurecr.io/pongogo:stable")


@app.command(name="version")
def version_command(
    engine: bool = typer.Option(
        False,
        "--engine",
        "-e",
        help="Show routing engine version instead of package version",
    ),
) -> None:
    """Show Pongogo version information.

    By default shows the package version. Use --engine to show the routing
    engine version (e.g., durian-0.6.5).
    """
    if engine:
        try:
            from mcp_server.pongogo_router import DURIAN_VERSION

            console.print(f"engine: {DURIAN_VERSION}")
        except ImportError:
            console.print("engine: unknown")
        try:
            from mcp_server.preceptor import PRECEPTOR_VERSION

            console.print(f"preceptor: {PRECEPTOR_VERSION}")
        except ImportError:
            console.print("preceptor: unknown")
    else:
        console.print(f"pongogo version {get_display_version()}")


@app.command(name="start")
def start_command() -> None:
    """Start the Pongogo daemon container for this project.

    Reads the container name from .pongogo/config.yaml and starts
    the daemon. If already running, prints status and exits.
    In native mode (pip/Homebrew install), no daemon is needed.
    """
    from pathlib import Path

    from .config import load_config

    config_path = Path(".pongogo/config.yaml")
    if not config_path.exists():
        print_error("No .pongogo/config.yaml found - run 'pongogo init' first")
        raise typer.Exit(1)

    config = load_config(config_path)

    # Native mode: no daemon needed
    if config.get("mode") == "native":
        print_success("Native mode: no daemon needed (MCP server runs directly)")
        raise typer.Exit(0)

    from .container import (
        build_labels,
        container_is_running,
        get_container_name,
        start_daemon,
    )

    container_name = config.get("container_name")

    if not container_name:
        # Derive from project root if not in config (backwards compat)
        project_root = Path.cwd()
        container_name = get_container_name(project_root)

    if container_is_running(container_name):
        print_success(f"Daemon already running: {container_name}")
        raise typer.Exit(0)

    image = get_pongogo_image()
    uid = int(os.environ.get("HOST_UID", os.getuid()))
    gid = int(os.environ.get("HOST_GID", os.getgid()))
    project_root = Path.cwd()
    pongogo_path = str(Path(".pongogo").resolve())
    labels = build_labels(project_root, image)

    if start_daemon(
        container_name, project_root, pongogo_path, image, uid, gid, labels
    ):
        print_success(f"Daemon started: {container_name}")
    else:
        print_error(f"Failed to start daemon: {container_name}")
        raise typer.Exit(1)


@app.command(name="stop")
def stop_command() -> None:
    """Stop the Pongogo daemon container for this project.

    Reads the container name from .pongogo/config.yaml and stops
    the daemon. If not running, prints message and exits.
    In native mode (pip/Homebrew install), no daemon exists to stop.
    """
    from pathlib import Path

    from .config import load_config

    config_path = Path(".pongogo/config.yaml")
    if not config_path.exists():
        print_error("No .pongogo/config.yaml found - run 'pongogo init' first")
        raise typer.Exit(1)

    config = load_config(config_path)

    # Native mode: no daemon to stop
    if config.get("mode") == "native":
        print_success("Native mode: no daemon to stop")
        raise typer.Exit(0)

    from .container import container_is_running, get_container_name, stop_daemon

    container_name = config.get("container_name")

    if not container_name:
        project_root = Path.cwd()
        container_name = get_container_name(project_root)

    if not container_is_running(container_name):
        print_warning(f"Daemon not running: {container_name}")
        raise typer.Exit(0)

    if stop_daemon(container_name):
        print_success(f"Daemon stopped: {container_name}")
    else:
        print_error(f"Failed to stop daemon: {container_name}")
        raise typer.Exit(1)


@app.command(name="upgrade")
def upgrade_command() -> None:
    """Upgrade Pongogo to the latest version.

    Detects the installation method (Docker, pip, or Homebrew) and runs
    the appropriate upgrade command.
    """
    import subprocess

    from mcp_server.auto_upgrade import execute_upgrade
    from mcp_server.upgrade import (
        InstallMethod,
        detect_install_method,
        get_current_version,
    )

    method = detect_install_method()
    current = get_current_version()

    if method == InstallMethod.DOCKER:
        # Docker is special-cased in CLI: we can run `docker pull` from the host
        image = get_pongogo_image()
        console.print(f"Upgrading Pongogo (Docker: {image})...")
        try:
            result = subprocess.run(
                ["docker", "pull", image],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                if (
                    "up to date" in result.stdout.lower()
                    or "already exists" in result.stdout.lower()
                ):
                    print_success("Already up to date!")
                else:
                    print_success(
                        "Upgrade complete! Restart Claude Code to use the new version."
                    )
            else:
                print_error(f"Upgrade failed: {result.stderr.strip()}")
                raise typer.Exit(1)
        except FileNotFoundError:
            print_error("Docker not found. Please install Docker to upgrade.")
            raise typer.Exit(1)
    elif method in (InstallMethod.PIP, InstallMethod.HOMEBREW):
        label = "pip" if method == InstallMethod.PIP else "Homebrew"
        console.print(f"Upgrading Pongogo ({label}, current: {current})...")
        exec_result = execute_upgrade(method)
        if not exec_result.attempted:
            print_error(exec_result.error_message or "Upgrade not attempted")
            raise typer.Exit(1)
        if exec_result.already_up_to_date:
            print_success("Already up to date!")
        elif exec_result.succeeded:
            print_success(
                "Upgrade complete! Restart Claude Code to use the new version."
            )
        else:
            print_error(f"Upgrade failed: {exec_result.error_message}")
            raise typer.Exit(1)
    else:
        print_error("Could not detect installation method")
        raise typer.Exit(1)

    # After successful upgrade, run config migrations to patch settings.json
    # with any new hooks/matchers from the upgraded version.
    # Graceful: if not in a project dir, skip silently.
    try:
        from pathlib import Path

        from .migrations import run_migrations

        cwd = Path.cwd()
        if (cwd / ".pongogo" / "config.yaml").exists():
            migrate_result = run_migrations(cwd)
            if migrate_result.applied_count > 0 and migrate_result.success:
                print_success(
                    f"Applied {migrate_result.applied_count} config migration(s)"
                )
                for change in migrate_result.changes:
                    console.print(f"  • {change}")
    except Exception:
        pass  # Non-fatal — migrations can be run manually via `pongogo migrate`


@app.command(name="uninstall")
def uninstall_command(
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Skip confirmation prompt and proceed with uninstall",
    ),
    remove_image: bool = typer.Option(
        False,
        "--remove-image",
        help="Also remove the Docker image (Docker installs only)",
    ),
    remove_package: bool = typer.Option(
        False,
        "--remove-package",
        help="Also remove the pongogo pip or Homebrew package (native installs only)",
    ),
    full: bool = typer.Option(
        False,
        "--full",
        help="Full cleanup: force uninstall and remove package/image based on install method",
    ),
    debug: bool = typer.Option(
        False,
        "--debug",
        "-d",
        help="Show detailed output for troubleshooting",
    ),
) -> None:
    """Uninstall Pongogo from the current project.

    This command removes all Pongogo configuration from your project:

    \b
    Project files removed:
      .pongogo/                    Instructions, config, and event database
      .mcp.json                    MCP server configuration (project root)
      .claude/mcp.json             MCP server configuration (Claude dir)
      .claude/settings.local.json  Routing hooks

    \b
    Global config cleaned:
      ~/.claude.json               Removes pongogo-knowledge entries

    \b
    Package removal (install-method-aware):
      --remove-image               Docker installs: remove the Docker image
      --remove-package             pip/Homebrew installs: uninstall the package
      --full                       Auto-detects method and removes accordingly

    \b
    Examples:
      pongogo uninstall                  Interactive uninstall with confirmation
      pongogo uninstall --force          Skip confirmation prompt
      pongogo uninstall --remove-image   Also remove Docker image
      pongogo uninstall --remove-package Also remove pip/Homebrew package
      pongogo uninstall --full           Full cleanup (force + remove package/image)
      pongogo uninstall -f -d            Force uninstall with debug output
    """
    # --full implies --force and auto-detects the right removal action
    # Track explicit flags so we only warn on wrong-method when user explicitly asked
    explicit_remove_image = remove_image
    explicit_remove_package = remove_package
    if full:
        force = True
        remove_image = True
        remove_package = True
    import subprocess
    from pathlib import Path

    from mcp_server.upgrade import InstallMethod, detect_install_method

    method = detect_install_method()

    # Check if .pongogo exists
    pongogo_dir = Path(".pongogo")
    if not pongogo_dir.exists():
        print_warning("No .pongogo directory found - Pongogo may not be installed here")
        if not force:
            raise typer.Exit(0)

    # Confirm unless --force
    if not force:
        console.print("\n[bold]This will remove:[/bold]")
        console.print("  • .pongogo/ directory")
        console.print("  • MCP server configuration from .mcp.json")
        console.print("  • MCP server configuration from .claude/mcp.json")
        console.print("  • Hooks from .claude/settings.local.json")
        console.print("  • Global config from ~/.claude.json (if present)")
        if remove_image and method == InstallMethod.DOCKER:
            console.print(f"  • Docker image: {get_pongogo_image()}")
        if remove_package and method == InstallMethod.PIP:
            console.print("  • pip package: pongogo")
        if remove_package and method == InstallMethod.HOMEBREW:
            console.print("  • Homebrew package: pongogo")
        console.print("")

        confirm = typer.confirm("Continue with uninstall?")
        if not confirm:
            console.print("Uninstall cancelled.")
            raise typer.Exit(0)

    console.print("")
    success = True

    # Detect mode from config
    is_native_mode = False
    try:
        from .config import load_config as _load_config

        config_path_check = pongogo_dir / "config.yaml"
        if config_path_check.exists():
            cfg = _load_config(config_path_check)
            is_native_mode = cfg.get("mode") == "native"
    except Exception:
        pass

    # Stop daemon container before removing .pongogo/ (Docker mode only)
    if not is_native_mode:
        try:
            from .config import load_config
            from .container import container_exists, get_container_name, stop_daemon

            config_path = pongogo_dir / "config.yaml"
            container_name = None
            if config_path.exists():
                try:
                    cfg = load_config(config_path)
                    container_name = cfg.get("container_name")
                except Exception:
                    pass

            if not container_name:
                container_name = get_container_name(Path.cwd())

            if container_name and container_exists(container_name):
                if stop_daemon(container_name):
                    print_success(f"Stopped daemon container: {container_name}")
                else:
                    print_warning(f"Could not stop daemon container: {container_name}")
        except Exception as e:
            if debug:
                print_warning(f"Could not stop daemon container: {e}")

    # Remove .pongogo directory
    if pongogo_dir.exists():
        try:
            shutil.rmtree(pongogo_dir)
            print_success("Removed .pongogo/ directory")
        except Exception as e:
            print_error(f"Failed to remove .pongogo/: {e}")
            success = False

    # Remove from .mcp.json
    if not remove_from_mcp_json(".mcp.json", debug):
        success = False

    # Remove from .claude/mcp.json
    if not remove_from_claude_mcp_json(debug):
        success = False

    # Remove hooks from settings
    if not remove_hooks_from_settings(debug):
        success = False

    # Remove from global config
    if not remove_from_global_claude_json(debug):
        success = False

    # Remove Docker image if requested
    if remove_image:
        if method == InstallMethod.PIP and explicit_remove_image:
            print_warning(
                "--remove-image is for Docker installs. "
                "You installed via pip — use --remove-package to uninstall the pip package."
            )
        elif method == InstallMethod.HOMEBREW and explicit_remove_image:
            print_warning(
                "--remove-image is for Docker installs. "
                "You installed via Homebrew — use --remove-package to uninstall the Homebrew package."
            )
        elif method == InstallMethod.DOCKER:
            image = get_pongogo_image()
            # Inside container - provide instructions for host
            console.print(
                "\n[bold]To remove the Docker image, run on your host:[/bold]"
            )
            console.print(f"  docker rmi {image}\n")
        else:
            image = get_pongogo_image()
            try:
                result = subprocess.run(
                    ["docker", "rmi", image],
                    capture_output=True,
                    text=True,
                )
                if result.returncode == 0:
                    print_success(f"Removed Docker image: {image}")
                elif "No such image" in result.stderr:
                    print_success("Docker image not present (already removed)")
                else:
                    print_error(
                        f"Failed to remove Docker image: {result.stderr.strip()}"
                    )
                    success = False
            except FileNotFoundError:
                console.print("\n[bold]To remove the Docker image, run:[/bold]")
                console.print(f"  docker rmi {image}\n")
            except Exception as e:
                print_error(f"Failed to remove Docker image: {e}")
                success = False

    # Remove pip/Homebrew package if requested
    if remove_package:
        if method == InstallMethod.DOCKER and explicit_remove_package:
            print_warning(
                "--remove-package is for pip/Homebrew installs. "
                "You installed via Docker — use --remove-image to remove the Docker image."
            )
        elif method == InstallMethod.PIP:
            try:
                result = subprocess.run(
                    ["pip", "uninstall", "-y", "pongogo"],
                    capture_output=True,
                    text=True,
                )
                if result.returncode == 0:
                    print_success("Removed pip package: pongogo")
                elif "not installed" in (result.stdout + result.stderr).lower():
                    print_success("pip package not installed (already removed)")
                else:
                    print_error(
                        f"Failed to remove pip package: {(result.stdout + result.stderr).strip()}"
                    )
                    success = False
            except FileNotFoundError:
                print_error("pip not found — cannot remove package")
                success = False
            except Exception as e:
                print_error(f"Failed to remove pip package: {e}")
                success = False
        elif method == InstallMethod.HOMEBREW:
            try:
                result = subprocess.run(
                    ["brew", "uninstall", "pongogo"],
                    capture_output=True,
                    text=True,
                )
                if result.returncode == 0:
                    print_success("Removed Homebrew package: pongogo")
                elif "not installed" in (result.stdout + result.stderr).lower():
                    print_success("Homebrew package not installed (already removed)")
                else:
                    print_error(
                        f"Failed to remove Homebrew package: {(result.stdout + result.stderr).strip()}"
                    )
                    success = False
            except FileNotFoundError:
                print_error("brew not found — cannot remove package")
                success = False
            except Exception as e:
                print_error(f"Failed to remove Homebrew package: {e}")
                success = False

    console.print("")
    if success:
        print_success("Pongogo uninstalled successfully")
    else:
        print_error("Uninstall completed with errors")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
