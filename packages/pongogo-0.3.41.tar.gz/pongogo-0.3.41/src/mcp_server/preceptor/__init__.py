"""
Compliance preceptor — the glue between routing and compliance tracking.

Bridges the routing engine's procedural detection to the compliance tracking
database, enabling the PostToolUse and Stop hooks to enforce requirements.

Platform-agnostic: no Claude Code or hook-specific imports.

Epic #545: Hook-Based Compliance Enforcement

Architecture (three layers):
    Router (durian)     — provides context (finds relevant instructions)
    Preceptor (this)    — ensures compliance (registers and tracks requirements)
    Adapter             — handles surface integration (Claude Code hooks, etc.)
"""

from .compliance_preceptor import (
    ComplianceContext,
    CompliancePreceptor,
)
from .registration import ComplianceRegistrar

PRECEPTOR_VERSION = "0.4.0"

__all__ = [
    "ComplianceContext",
    "CompliancePreceptor",
    "ComplianceRegistrar",
    "PRECEPTOR_VERSION",
]
