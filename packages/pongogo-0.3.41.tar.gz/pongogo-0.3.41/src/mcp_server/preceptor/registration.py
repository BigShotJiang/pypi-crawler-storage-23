"""
Compliance registrar — writes ComplianceRule objects to guidance_fulfillment.

Platform-agnostic: uses raw SQLite, no Claude Code or hook-specific imports.

Epic #545: Hook-Based Compliance Enforcement
"""

import json
import logging
from pathlib import Path

from ..compliance.models import ComplianceSpec
from ..database.connection import get_connection

logger = logging.getLogger(__name__)


class ComplianceRegistrar:
    """Write ComplianceSpec rules to the guidance_fulfillment table.

    Each ComplianceRule becomes one guidance_fulfillment row with status 'pending'.
    Deduplicates against existing pending rows for the same session to avoid
    re-registering requirements on repeated routing calls.
    """

    def __init__(self, db_path: Path):
        self._db_path = db_path

    def register_requirements(
        self,
        spec: ComplianceSpec,
        session_id: str,
        routing_event_id: int | None = None,
        branch: str | None = None,
    ) -> list[int]:
        """Insert one guidance_fulfillment row per ComplianceRule.

        Deduplicates against existing pending rows for this session+branch — if a
        row with the same action_type, guidance_content, and branch already exists
        with status 'pending', it is skipped.

        Args:
            spec: ComplianceSpec with rules to register.
            session_id: Session identifier for scoping.
            routing_event_id: Optional routing_events.id for FK linkage.
            branch: Git branch name for cross-branch isolation (Task #640).

        Returns:
            List of inserted row IDs (excludes deduplicated skips).
        """
        if not spec.has_rules:
            return []

        inserted_ids: list[int] = []

        with get_connection(self._db_path) as conn:
            for rule in spec.rules:
                action_type = rule.rule_type.value
                guidance_content = rule.description

                # Task #653: Include enforcement_phase in dedup —
                # same action_type+content but different phase should not deduplicate.
                enforcement_phase = rule.enforcement_phase.value

                # Deduplicate: skip if identical row exists for session+branch+phase
                # Bug #656: Check ALL statuses (not just pending) to prevent
                # re-accumulation of already-fulfilled requirements in long sessions.
                existing = conn.execute(
                    """
                    SELECT id, fulfillment_status FROM guidance_fulfillment
                    WHERE session_id = ?
                      AND action_type = ?
                      AND guidance_content = ?
                      AND (branch = ? OR (branch IS NULL AND ? IS NULL))
                      AND (enforcement_phase = ? OR (enforcement_phase IS NULL AND ? = 'blocked_until'))
                    ORDER BY
                      CASE fulfillment_status
                        WHEN 'pending' THEN 1
                        WHEN 'in_progress' THEN 2
                        WHEN 'carried_forward' THEN 3
                        WHEN 'fulfilled' THEN 4
                      END
                    LIMIT 1
                    """,
                    (
                        session_id,
                        action_type,
                        guidance_content,
                        branch,
                        branch,
                        enforcement_phase,
                        enforcement_phase,
                    ),
                ).fetchone()

                if existing:
                    status = existing["fulfillment_status"]
                    logger.debug(
                        f"COMPLIANCE_DEDUP: skipping duplicate rule "
                        f"'{action_type}' for session {session_id[:16]} "
                        f"(existing status: {status})"
                    )
                    continue

                # Serialize blocked_tools as JSON (Epic #565: declarative enforcement)
                blocked_tools_json = (
                    json.dumps(rule.blocked_tools) if rule.blocked_tools else None
                )
                # Store enforcement scope (Epic #565: scope management)
                enforcement_scope = rule.scope.value if rule.scope else "session"

                # Store required_tool for call_mcp_tool rules
                required_tool = (
                    rule.required_tool if action_type == "call_mcp_tool" else None
                )

                cursor = conn.execute(
                    """
                    INSERT INTO guidance_fulfillment (
                        guidance_event_id, guidance_type, guidance_content,
                        action_type, blocked_tools, enforcement_scope,
                        fulfillment_status, session_id, required_tool, branch,
                        enforcement_phase, pattern
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        routing_event_id,
                        "procedural",
                        guidance_content,
                        action_type,
                        blocked_tools_json,
                        enforcement_scope,
                        "pending",
                        session_id,
                        required_tool,
                        branch,
                        enforcement_phase,
                        rule.pattern,
                    ),
                )
                row_id = cursor.lastrowid or 0
                inserted_ids.append(row_id)
                logger.debug(
                    f"COMPLIANCE_REGISTERED: id={row_id} "
                    f"action_type={action_type} session={session_id[:16]}"
                )

        return inserted_ids

    def get_pending_count(self, session_id: str) -> int:
        """Return the number of pending compliance requirements for a session."""
        with get_connection(self._db_path, readonly=True) as conn:
            row = conn.execute(
                """
                SELECT COUNT(*) FROM guidance_fulfillment
                WHERE session_id = ? AND fulfillment_status = 'pending'
                """,
                (session_id,),
            ).fetchone()
            return row[0] if row else 0
