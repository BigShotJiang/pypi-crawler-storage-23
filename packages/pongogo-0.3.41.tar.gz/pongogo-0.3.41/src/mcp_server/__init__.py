"""
Pongogo MCP Server Package

Provides intelligent knowledge routing via Model Context Protocol.

Main components:
- server: FastMCP server implementation
- pongogo_router: Instruction routing logic
- instruction_handler: Instruction file loading
- routing_engine: Engine abstraction and registry
- config: Configuration management
- engines: Frozen engine versions (durian-0.x)
- pi_system: Potential Improvements tracking
- database: Unified database layer
- discovery_system: Observation-triggered promotion
- formatter: Routing result formatting
- event_capture: Routing event storage
- health_check: Health check tools
- upgrade: Version check and upgrade utilities
"""

# Lazy imports - components are imported when accessed, not at package load time
# This avoids requiring all dependencies to be installed for basic imports

__all__ = [
    "server",
    "pongogo_router",
    "instruction_handler",
    "routing_engine",
    "config",
    "engines",
    "pi_system",
    "database",
    "discovery_system",
    "formatter",
    "event_capture",
    "health_check",
    "upgrade",
]
