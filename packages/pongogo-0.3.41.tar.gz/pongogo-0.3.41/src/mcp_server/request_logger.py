"""Lightweight E2E request tracing for Pongogo MCP server.

Activated by setting PONGOGO_E2E_TRACE to a file path. When set, logs every
JSON-RPC tool call and server lifecycle event to that file as JSONL. Zero
overhead when disabled (all functions are no-ops).

Usage in server.py:
    from .request_logger import trace_event, traced

    # Lifecycle events
    trace_event("server_start")

    # Tool tracing via decorator
    @mcp.tool()
    @traced
    async def my_tool(...):
        ...

Trace output format (one JSON object per line):
    {"ts":"2026-02-25T14:30:01.123Z","event":"server_start","pid":1234}
    {"ts":"2026-02-25T14:30:02.100Z","event":"tool_start","tool":"get_health_status","params":{}}
    {"ts":"2026-02-25T14:30:02.350Z","event":"tool_end","tool":"get_health_status","duration_ms":250,"status":"ok"}
"""

import functools
import json
import os
import time
from contextlib import contextmanager
from datetime import UTC, datetime

_trace_path = os.environ.get("PONGOGO_E2E_TRACE")
_enabled = _trace_path is not None


def _write(entry: dict) -> None:
    """Append a trace entry to the trace file. Never raises."""
    if not _enabled:
        return
    try:
        entry["ts"] = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        entry["pid"] = os.getpid()
        with open(_trace_path, "a") as f:
            f.write(json.dumps(entry, default=str) + "\n")
    except Exception:
        pass  # Never crash the server for tracing


def trace_event(event: str, **data) -> None:
    """Log a lifecycle event (server_start, ready, shutdown, etc.)."""
    _write({"event": event, **data})


def _summarize_params(params: dict | None) -> dict:
    """Truncate long string values for compact logging."""
    if params is None:
        return {}
    summary = {}
    for k, v in params.items():
        if isinstance(v, str) and len(v) > 100:
            summary[k] = v[:100] + "..."
        elif isinstance(v, dict) and len(str(v)) > 200:
            summary[k] = "{...}"
        else:
            summary[k] = v
    return summary


@contextmanager
def trace_tool(name: str, params: dict | None = None):
    """Context manager to trace a tool call with timing."""
    if not _enabled:
        yield
        return
    start = time.monotonic()
    _write({"event": "tool_start", "tool": name, "params": _summarize_params(params)})
    try:
        yield
        elapsed_ms = int((time.monotonic() - start) * 1000)
        _write(
            {
                "event": "tool_end",
                "tool": name,
                "duration_ms": elapsed_ms,
                "status": "ok",
            }
        )
    except Exception as e:
        elapsed_ms = int((time.monotonic() - start) * 1000)
        _write(
            {
                "event": "tool_end",
                "tool": name,
                "duration_ms": elapsed_ms,
                "status": "error",
                "error": str(e)[:200],
            }
        )
        raise


def traced(func):
    """Decorator to add E2E tracing to an async tool handler.

    Apply below @mcp.tool() so FastMCP sees the original metadata:
        @mcp.tool()
        @traced
        async def my_tool(...):
            ...
    """
    if not _enabled:
        return func

    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        with trace_tool(func.__name__, kwargs if kwargs else None):
            return await func(*args, **kwargs)

    return wrapper
