"""Auto-upgrade system for Pongogo (Task #662).

Checks for and applies upgrades at MCP server startup, with throttling,
skip guards, and history tracking in pongogo.db.

The execute_upgrade() function is shared by both auto-upgrade (server startup)
and the CLI `pongogo upgrade` command to avoid duplicating subprocess logic.
"""

import logging
import subprocess
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path

from .upgrade import InstallMethod, detect_install_method, get_current_version

logger = logging.getLogger(__name__)

# How often to check for upgrades (hours)
UPGRADE_CHECK_INTERVAL_HOURS = 24

# Optional per-version "what's new" messages.
# Key = version string, value = short user-facing message.
# Empty dict = silent upgrades (default).
WHATS_NEW: dict[str, str] = {}


@dataclass
class UpgradeExecResult:
    """Result of executing an upgrade subprocess."""

    attempted: bool
    succeeded: bool = False
    from_version: str | None = None
    to_version: str | None = None
    error_message: str | None = None
    already_up_to_date: bool = False


@dataclass
class AutoUpgradeResult:
    """Result of the full auto-upgrade check+apply flow."""

    checked: bool
    upgrade: UpgradeExecResult | None = None
    config_migrations_applied: int = 0
    whats_new: str | None = None
    skipped_reason: str | None = None


def _is_dev_version(version: str) -> bool:
    """Check if this is a development/editable install.

    Detects:
    - Explicit dev markers: "0.1.0-dev", "unknown"
    - PEP 610 editable installs (`pip install -e .`)
    """
    if version in ("0.1.0-dev", "unknown"):
        return True

    # PEP 610: editable installs have direct_url.json with dir_info.editable=true
    try:
        import json
        from importlib.metadata import distribution

        dist = distribution("pongogo")
        for f in dist.files or []:
            if f.name == "direct_url.json":
                data = json.loads(f.read_text())
                return data.get("dir_info", {}).get("editable", False)
    except Exception:
        pass
    return False


def _is_docker() -> bool:
    """Check if running inside a Docker container."""
    return detect_install_method() == InstallMethod.DOCKER


def _should_skip_upgrade(project_root: Path) -> str | None:
    """Check user preference for auto_upgrade behavior.

    Returns:
        Skip reason string, or None if upgrade should proceed.
    """
    try:
        from cli.preferences import get_behavior_mode, load_preferences

        prefs = load_preferences(project_root)
        mode = get_behavior_mode(prefs, "auto_upgrade")
        if mode == "skip":
            return "user preference: auto_upgrade=skip"
        if mode == "ask":
            return (
                "user preference: auto_upgrade=ask (update available, not auto-applied)"
            )
    except Exception:
        pass  # Preferences unavailable — proceed with upgrade
    return None


def _check_throttle(db) -> str | None:
    """Check if we've already checked for upgrades recently.

    Args:
        db: PongogoDatabase instance

    Returns:
        Skip reason string, or None if enough time has passed.
    """
    try:
        cutoff = (
            datetime.now(UTC) - timedelta(hours=UPGRADE_CHECK_INTERVAL_HOURS)
        ).isoformat()
        row = db.execute_one(
            "SELECT timestamp FROM upgrade_history WHERE timestamp > ? ORDER BY timestamp DESC LIMIT 1",
            (cutoff,),
        )
        if row:
            return f"throttled: last check at {row['timestamp']}"
    except Exception as e:
        logger.debug(f"Throttle check failed: {e}")
    return None


def _is_already_current(output: str, method: InstallMethod) -> bool:
    """Parse subprocess output to detect 'already up to date'.

    Args:
        output: Combined stdout+stderr from the upgrade command.
        method: Install method (affects output format).

    Returns:
        True if output indicates no upgrade was needed.
    """
    lower = output.lower()
    if method == InstallMethod.PIP:
        # pip prints "Requirement already satisfied" when no upgrade needed,
        # BUT also prints it for dependencies even when main package upgraded.
        # "Successfully installed" takes priority.
        if "successfully installed" in lower:
            return False
        return "already satisfied" in lower or "already up-to-date" in lower
    elif method == InstallMethod.HOMEBREW:
        return "already installed" in lower or "already up-to-date" in lower
    return False


def execute_upgrade(method: InstallMethod, timeout: int = 120) -> UpgradeExecResult:
    """Execute the upgrade subprocess for the given install method.

    This is the shared execution logic used by both auto-upgrade (server startup)
    and the CLI `pongogo upgrade` command.

    Args:
        method: Installation method determining the command to run.
        timeout: Subprocess timeout in seconds.

    Returns:
        UpgradeExecResult with outcome details.
    """
    from_version = get_current_version()

    if method == InstallMethod.DOCKER:
        # Can't pull from inside a container
        return UpgradeExecResult(
            attempted=False,
            from_version=from_version,
            to_version=from_version,
            error_message="Docker upgrades must be performed externally",
        )

    if method == InstallMethod.PIP:
        cmd = ["pip", "install", "--upgrade", "pongogo"]
    elif method == InstallMethod.HOMEBREW:
        cmd = ["brew", "upgrade", "pongogo"]
    else:
        return UpgradeExecResult(
            attempted=False,
            from_version=from_version,
            error_message=f"Unknown install method: {method}",
        )

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except FileNotFoundError:
        return UpgradeExecResult(
            attempted=True,
            succeeded=False,
            from_version=from_version,
            error_message=f"{cmd[0]} not found",
        )
    except subprocess.TimeoutExpired:
        return UpgradeExecResult(
            attempted=True,
            succeeded=False,
            from_version=from_version,
            error_message=f"Upgrade timed out after {timeout}s",
        )

    output = result.stdout + result.stderr

    if result.returncode != 0:
        return UpgradeExecResult(
            attempted=True,
            succeeded=False,
            from_version=from_version,
            error_message=output.strip()[:500],
        )

    if _is_already_current(output, method):
        return UpgradeExecResult(
            attempted=True,
            succeeded=True,
            from_version=from_version,
            to_version=from_version,
            already_up_to_date=True,
        )

    # Upgrade succeeded — re-read version (may not reflect until next process)
    to_version = get_current_version()
    return UpgradeExecResult(
        attempted=True,
        succeeded=True,
        from_version=from_version,
        to_version=to_version,
    )


def _record_upgrade(
    db,
    result: UpgradeExecResult,
    method: InstallMethod,
    config_migrations: int = 0,
    adapter: str = "claude_code",
) -> None:
    """Record an upgrade attempt in upgrade_history.

    Args:
        db: PongogoDatabase instance
        result: Upgrade execution result
        method: Installation method used
        config_migrations: Number of config migrations applied after upgrade
        adapter: Platform adapter identifier
    """
    try:
        db.execute_insert(
            """INSERT INTO upgrade_history
            (timestamp, from_version, to_version, install_method,
             upgrade_attempted, upgrade_succeeded, config_migrations_applied,
             error_message, adapter)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                datetime.now(UTC).isoformat(),
                result.from_version,
                result.to_version or result.from_version or "unknown",
                method.value,
                result.attempted,
                result.succeeded if result.attempted else None,
                config_migrations,
                result.error_message,
                adapter,
            ),
        )
    except Exception as e:
        logger.debug(f"Failed to record upgrade history: {e}")


def check_and_upgrade(
    project_root: Path, adapter: str = "claude_code"
) -> AutoUpgradeResult:
    """Full auto-upgrade orchestrator called from _deferred_startup().

    Skip guards (checked in order):
    1. Dev version → skip
    2. Docker mode → skip (record check only)
    3. User preference = "skip" → skip
    4. Throttled (checked within 24h) → skip
    5. User preference = "ask" → skip (record only)

    Args:
        project_root: Repository root path.
        adapter: Platform adapter name.

    Returns:
        AutoUpgradeResult with full details.
    """
    from .database.database import PongogoDatabase

    version = get_current_version()
    method = detect_install_method()

    # Guard 1: Dev version
    if _is_dev_version(version):
        return AutoUpgradeResult(checked=False, skipped_reason="development version")

    # Guard 2: Docker mode
    if _is_docker():
        # Record the check but don't attempt upgrade
        try:
            db = PongogoDatabase(project_root=project_root)
            no_op = UpgradeExecResult(
                attempted=False,
                from_version=version,
                to_version=version,
            )
            _record_upgrade(db, no_op, method, adapter=adapter)
        except Exception:
            pass
        return AutoUpgradeResult(
            checked=True, skipped_reason="Docker mode (upgrade externally)"
        )

    # Guard 3: User preference = skip
    skip_reason = _should_skip_upgrade(project_root)
    if skip_reason:
        return AutoUpgradeResult(checked=False, skipped_reason=skip_reason)

    # Guard 4: Throttle
    try:
        db = PongogoDatabase(project_root=project_root)
    except Exception as e:
        return AutoUpgradeResult(
            checked=False, skipped_reason=f"database unavailable: {e}"
        )

    throttle_reason = _check_throttle(db)
    if throttle_reason:
        return AutoUpgradeResult(checked=True, skipped_reason=throttle_reason)

    # Execute upgrade
    exec_result = execute_upgrade(method)

    # Run config migrations after successful upgrade
    config_migrations = 0
    if exec_result.succeeded and not exec_result.already_up_to_date:
        try:
            from cli.migrations import run_migrations

            migrate_result = run_migrations(project_root)
            if migrate_result.applied_count > 0:
                config_migrations = migrate_result.applied_count
                logger.info(
                    f"Auto-upgrade: applied {config_migrations} config migration(s)"
                )
        except Exception as e:
            logger.debug(f"Auto-upgrade: config migration failed: {e}")

    # Record in history
    _record_upgrade(db, exec_result, method, config_migrations, adapter)

    # Check for what's new message
    whats_new = None
    if exec_result.succeeded and exec_result.to_version:
        whats_new = WHATS_NEW.get(exec_result.to_version)

    return AutoUpgradeResult(
        checked=True,
        upgrade=exec_result,
        config_migrations_applied=config_migrations,
        whats_new=whats_new,
    )
