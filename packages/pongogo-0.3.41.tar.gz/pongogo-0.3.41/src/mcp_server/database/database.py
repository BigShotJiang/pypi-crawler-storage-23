"""
Core database connection and schema management for Pongogo Unified Database.

The unified database consolidates:
- routing_events (event logging)
- artifact_* tables (file-based knowledge lifecycle)
- routing_triggers (friction/guidance dictionaries)
- observation_* tables (runtime observation lifecycle)

Location: .pongogo/pongogo.db (project root)
Fallback: ~/.pongogo/pongogo.db (user-level)
"""

import logging
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

from .connection import get_connection

logger = logging.getLogger(__name__)

# Schema version for migrations
SCHEMA_VERSION = "3.16.0"

# PRAGMA user_version tracks migration state; increment when adding migrations
SCHEMA_USER_VERSION = 11


def get_default_db_path(project_root: Path | None = None) -> Path:
    """Get the default database path.

    Path resolution:
    1. If project_root provided: .pongogo/pongogo.db (project-local)
    2. Derive from PONGOGO_KNOWLEDGE_PATH env var (container deployment)
    3. Fallback: ~/.pongogo/pongogo.db (user-level fallback)

    Args:
        project_root: If provided, uses project-local database.

    Returns:
        Path to pongogo.db
    """
    if project_root:
        return Path(project_root) / ".pongogo" / "pongogo.db"

    # Import here to avoid circular imports
    from mcp_server.config import get_project_root

    # Use project root derived from config (handles container paths correctly)
    derived_root = get_project_root()
    db_path = derived_root / ".pongogo" / "pongogo.db"

    # Only use derived path if .pongogo directory exists there
    if (derived_root / ".pongogo").exists():
        return db_path

    # User-level fallback (development mode or no project)
    return Path.home() / ".pongogo" / "pongogo.db"


# Embedded schema (unified v3.0.0)
SCHEMA = """
-- Schema metadata
CREATE TABLE IF NOT EXISTS schema_info (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Routing events (core event logging)
CREATE TABLE IF NOT EXISTS routing_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    user_message TEXT NOT NULL,
    message_hash TEXT,
    routed_instructions TEXT,
    instruction_count INTEGER DEFAULT 0,
    routing_scores TEXT,
    engine_version TEXT DEFAULT 'durian-0.6.1',
    session_id TEXT,
    context TEXT,
    routing_latency_ms REAL,
    exclude_from_eval BOOLEAN DEFAULT 0,
    exclude_reason TEXT,
    pongogo_build TEXT,
    preceptor_version TEXT,
    adapter TEXT,
    -- Response capture columns (added for stop hook)
    agent_response TEXT,
    agent_response_tokens INTEGER,
    response_captured_at TEXT,
    response_correlation_method TEXT,
    -- Plan mode context (Task #614)
    execution_context TEXT,
    -- Branch context (Task #640: Wave 2 execution context propagation)
    branch_name TEXT
);

CREATE INDEX IF NOT EXISTS idx_routing_events_timestamp ON routing_events(timestamp);
CREATE INDEX IF NOT EXISTS idx_routing_events_session ON routing_events(session_id);
CREATE INDEX IF NOT EXISTS idx_routing_events_engine ON routing_events(engine_version);
CREATE INDEX IF NOT EXISTS idx_routing_events_build ON routing_events(pongogo_build);
CREATE INDEX IF NOT EXISTS idx_routing_events_adapter ON routing_events(adapter);
CREATE INDEX IF NOT EXISTS idx_routing_events_execution_context ON routing_events(execution_context);
CREATE INDEX IF NOT EXISTS idx_routing_events_branch_name ON routing_events(branch_name);

-- Routing triggers (friction, guidance, violation dictionaries)
CREATE TABLE IF NOT EXISTS routing_triggers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trigger_type TEXT NOT NULL,
    trigger_key TEXT NOT NULL,
    trigger_value TEXT,
    category TEXT,
    description TEXT,
    source TEXT NOT NULL DEFAULT 'built_in',
    confidence TEXT DEFAULT 'HIGH',
    enabled BOOLEAN DEFAULT 1,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    created_by TEXT,
    UNIQUE(trigger_type, trigger_key)
);

CREATE INDEX IF NOT EXISTS idx_triggers_type ON routing_triggers(trigger_type);
CREATE INDEX IF NOT EXISTS idx_triggers_enabled ON routing_triggers(enabled);

-- Artifact discovered (file-based knowledge from repo)
CREATE TABLE IF NOT EXISTS artifact_discovered (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_file TEXT NOT NULL,
    source_type TEXT NOT NULL,
    section_title TEXT,
    section_content TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    keywords TEXT,
    status TEXT NOT NULL DEFAULT 'DISCOVERED',
    promoted_to INTEGER,
    discovered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    promoted_at TEXT,
    archived_at TEXT,
    archive_reason TEXT,
    UNIQUE(content_hash)
);

CREATE INDEX IF NOT EXISTS idx_artifact_discovered_status ON artifact_discovered(status);
CREATE INDEX IF NOT EXISTS idx_artifact_discovered_source_type ON artifact_discovered(source_type);

-- Artifact implemented (promoted to instruction files)
CREATE TABLE IF NOT EXISTS artifact_implemented (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    discovered_id INTEGER,
    instruction_file TEXT NOT NULL,
    instruction_id TEXT,
    instruction_category TEXT,
    content_hash TEXT NOT NULL,
    word_count INTEGER,
    title TEXT,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    deprecated_at TEXT,
    deprecated_reason TEXT,
    times_routed INTEGER DEFAULT 0,
    avg_routing_score REAL,
    FOREIGN KEY (discovered_id) REFERENCES artifact_discovered(id)
);

CREATE INDEX IF NOT EXISTS idx_artifact_implemented_status ON artifact_implemented(status);
CREATE INDEX IF NOT EXISTS idx_artifact_implemented_category ON artifact_implemented(instruction_category);

-- Observation discovered (runtime guidance/patterns)
CREATE TABLE IF NOT EXISTS observation_discovered (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id INTEGER,
    observation_type TEXT NOT NULL,
    observation_content TEXT NOT NULL,
    observation_target TEXT,
    guidance_type TEXT,
    should_persist BOOLEAN DEFAULT 1,
    persistence_scope TEXT DEFAULT 'project',
    status TEXT NOT NULL DEFAULT 'DISCOVERED',
    promoted_to INTEGER,
    session_id TEXT,
    context TEXT,
    discovered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at TEXT,
    promoted_at TEXT,
    rejected_at TEXT,
    rejection_reason TEXT,
    FOREIGN KEY (event_id) REFERENCES routing_events(id)
);

CREATE INDEX IF NOT EXISTS idx_observation_discovered_status ON observation_discovered(status);
CREATE INDEX IF NOT EXISTS idx_observation_discovered_type ON observation_discovered(observation_type);

-- Observation implemented (promoted to triggers/instructions/rules)
CREATE TABLE IF NOT EXISTS observation_implemented (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    discovered_id INTEGER,
    implementation_type TEXT NOT NULL,
    trigger_id INTEGER,
    instruction_id INTEGER,
    rule_content TEXT,
    rule_scope TEXT,
    title TEXT,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    deprecated_at TEXT,
    deprecated_reason TEXT,
    times_applied INTEGER DEFAULT 0,
    feedback_positive INTEGER DEFAULT 0,
    feedback_negative INTEGER DEFAULT 0,
    FOREIGN KEY (discovered_id) REFERENCES observation_discovered(id),
    FOREIGN KEY (trigger_id) REFERENCES routing_triggers(id),
    FOREIGN KEY (instruction_id) REFERENCES artifact_implemented(id)
);

CREATE INDEX IF NOT EXISTS idx_observation_implemented_status ON observation_implemented(status);
CREATE INDEX IF NOT EXISTS idx_observation_implemented_type ON observation_implemented(implementation_type);

-- Scan history (pongogo init runs)
CREATE TABLE IF NOT EXISTS scan_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_date TEXT NOT NULL,
    scan_type TEXT NOT NULL,
    source_type TEXT NOT NULL,
    files_scanned INTEGER DEFAULT 0,
    sections_found INTEGER DEFAULT 0,
    new_discoveries INTEGER DEFAULT 0,
    updated_discoveries INTEGER DEFAULT 0,
    duration_ms INTEGER,
    engine_version TEXT,
    pongogo_version TEXT
);

CREATE INDEX IF NOT EXISTS idx_scan_history_date ON scan_history(scan_date);

-- Guidance fulfillment tracking (Phase 9, Issue #390)
-- Tracks whether guidance given in message N is operationalized in subsequent messages
CREATE TABLE IF NOT EXISTS guidance_fulfillment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- The guidance event
    guidance_event_id INTEGER,
    guidance_type TEXT NOT NULL,
    guidance_content TEXT NOT NULL,
    action_type TEXT NOT NULL,

    -- Declarative enforcement (Epic #565)
    -- JSON array of tool names blocked until this requirement is fulfilled
    -- e.g., '["Edit", "Write", "Bash"]'
    blocked_tools TEXT,
    -- Enforcement scope: 'session' (persists until fulfilled) or 'action' (per-action)
    enforcement_scope TEXT DEFAULT 'session'
        CHECK(enforcement_scope IN ('session', 'action')),
    -- MCP tool name required for call_mcp_tool action type
    required_tool TEXT,

    -- Enforcement phase (Task #653: Declarative Step Verification)
    -- 'blocked_until' = blocks tools in blocked_tools category (existing behavior)
    -- 'required_before_closure' = only blocks closure operations
    enforcement_phase TEXT DEFAULT 'blocked_until',
    -- Glob/regex pattern for write_file/bash_command rules (Task #653)
    pattern TEXT,

    -- Fulfillment tracking
    fulfillment_status TEXT NOT NULL DEFAULT 'pending'
        CHECK(fulfillment_status IN ('pending', 'in_progress', 'fulfilled', 'abandoned', 'superseded', 'carried_forward')),

    -- Evidence
    fulfillment_event_id INTEGER,
    fulfillment_evidence TEXT,
    distance_to_fulfillment INTEGER,
    confidence REAL DEFAULT 0.0,

    -- Session context
    session_id TEXT,
    conversation_id TEXT,

    -- Timing
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fulfilled_at TEXT,

    -- Branch context (Task #640: Wave 2 execution context propagation)
    branch TEXT,

    FOREIGN KEY (guidance_event_id) REFERENCES routing_events(id),
    FOREIGN KEY (fulfillment_event_id) REFERENCES routing_events(id)
);

CREATE INDEX IF NOT EXISTS idx_guidance_fulfillment_status ON guidance_fulfillment(fulfillment_status);
CREATE INDEX IF NOT EXISTS idx_guidance_fulfillment_session ON guidance_fulfillment(session_id);
CREATE INDEX IF NOT EXISTS idx_guidance_fulfillment_action ON guidance_fulfillment(action_type);
CREATE INDEX IF NOT EXISTS idx_guidance_fulfillment_session_branch ON guidance_fulfillment(session_id, branch);
CREATE INDEX IF NOT EXISTS idx_guidance_fulfillment_phase ON guidance_fulfillment(enforcement_phase);

-- Tool usage patterns (Epic #565: Intent-Based Enforcement)
-- Data-driven intent detection: determines HOW a tool is being used (dangerous vs safe)
-- Replaces hardcoded BASH_*_PATTERNS and TOOL_ENFORCEMENT_RULES constants
CREATE TABLE IF NOT EXISTS tool_usage_patterns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    intent TEXT NOT NULL,              -- "closure", "commencement", "pr_creation", "commit_closure"
    tool_name TEXT NOT NULL,           -- "Bash", "mcp__github__close_issue", etc.
    match_type TEXT NOT NULL           -- "contains", "regex", "exact", "always"
        CHECK(match_type IN ('contains', 'regex', 'exact', 'always')),
    pattern TEXT,                      -- Match string (NULL for "always" match_type)
    platform TEXT DEFAULT '*',         -- "claude_code", "cursor", "*" (all platforms)
    source TEXT DEFAULT 'seeded'       -- "seeded", "discovered", "manual"
        CHECK(source IN ('seeded', 'discovered', 'manual')),
    enabled INTEGER DEFAULT 1,         -- Toggle without deletion
    exempt INTEGER DEFAULT 0,          -- If 1, this pattern BYPASSES enforcement
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    discovered_context TEXT            -- Why this pattern was added (for discovered patterns)
);

CREATE INDEX IF NOT EXISTS idx_tool_usage_patterns_tool ON tool_usage_patterns(tool_name);
CREATE INDEX IF NOT EXISTS idx_tool_usage_patterns_intent ON tool_usage_patterns(intent);
CREATE INDEX IF NOT EXISTS idx_tool_usage_patterns_enabled ON tool_usage_patterns(enabled);

-- Tutorial progress tracking (Epic #631: First-User Tutorial System)
CREATE TABLE IF NOT EXISTS tutorial_progress (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    step_id TEXT NOT NULL UNIQUE,
    step_title TEXT,
    completed_at TEXT,
    evidence TEXT,
    session_id TEXT
);

-- Upgrade history tracking (Task #662: Auto-Upgrade with History)
CREATE TABLE IF NOT EXISTS upgrade_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL,
    from_version TEXT,
    to_version TEXT NOT NULL,
    install_method TEXT NOT NULL,
    upgrade_attempted BOOLEAN NOT NULL,
    upgrade_succeeded BOOLEAN,
    config_migrations_applied INTEGER DEFAULT 0,
    error_message TEXT,
    build_hash TEXT,
    adapter TEXT DEFAULT 'claude_code'
);
CREATE INDEX IF NOT EXISTS idx_upgrade_history_timestamp ON upgrade_history(timestamp);
"""

# Seed data for tool_usage_patterns table (Epic #565)
# Maps tool usage to intent for enforcement decisions
TOOL_USAGE_PATTERN_SEEDS = [
    # MCP tools: intent matches tool purpose (always match)
    ("closure", "mcp__github__close_issue", "always", None, "*", 0),
    # Issue updates (body, labels, milestone) exempt from enforcement (Bug #656)
    # Actual closure is caught by mcp__github__close_issue (row above) and by
    # detecting state="closed" in tool_input. Body/label edits are routine.
    ("issue_update", "mcp__github__update_issue", "always", None, "*", 1),
    ("pr_creation", "mcp__github__create_pull_request", "always", None, "*", 0),
    # Bash project board: exempt from enforcement (Bug #651)
    # Board status mutations (move to "Up Next", "In Progress", etc.) are routine
    # operations. Commencement compliance is enforced at the routing level via
    # keyword triggers, not at the tool level. Marking these exempt prevents
    # false positives where board updates trigger closure/commencement gates.
    ("board_update", "Bash", "contains", "updateProjectV2ItemFieldValue", "*", 1),
    ("board_update", "Bash", "contains", "updateProjectV2", "*", 1),
    ("board_update", "Bash", "contains", "createProjectV2StatusUpdate", "*", 1),
    ("board_update", "Bash", "contains", "gh project item-edit", "*", 1),
    # Bash closure
    ("closure", "Bash", "contains", "gh issue close", "*", 0),
    # Bash PR creation
    ("pr_creation", "Bash", "contains", "gh pr create", "*", 0),
    # Bash commit message closure keywords (auto-close bypass)
    ("commit_closure", "Bash", "contains", "Fixes #", "*", 0),
    ("commit_closure", "Bash", "contains", "Closes #", "*", 0),
    ("commit_closure", "Bash", "contains", "Fixed #", "*", 0),
    ("commit_closure", "Bash", "contains", "Closed #", "*", 0),
    ("commit_closure", "Bash", "contains", "Resolves #", "*", 0),
    ("commit_closure", "Bash", "contains", "Resolved #", "*", 0),
    # Exempt: issue creation bypasses closure enforcement (Task #563)
    ("issue_creation", "Bash", "contains", "gh issue create", "*", 1),
    # Bash file mutation: closes Edit/Write bypass loophole (Epic #632, Task #635)
    # In-place editing
    ("mutation", "Bash", "contains", "sed -i", "*", 0),
    # Write via tee
    ("mutation", "Bash", "contains", "tee ", "*", 0),
    # Filesystem operations
    ("mutation", "Bash", "contains", "rm ", "*", 0),
    ("mutation", "Bash", "contains", "cp ", "*", 0),
    ("mutation", "Bash", "contains", "mv ", "*", 0),
    ("mutation", "Bash", "contains", "mkdir ", "*", 0),
    ("mutation", "Bash", "contains", "touch ", "*", 0),
    ("mutation", "Bash", "contains", "chmod ", "*", 0),
    ("mutation", "Bash", "contains", "chown ", "*", 0),
    # Redirect writes (common Edit/Write bypass in plan mode)
    ("mutation", "Bash", "contains", "cat >", "*", 0),
    ("mutation", "Bash", "contains", "cat >>", "*", 0),
    ("mutation", "Bash", "contains", "echo >", "*", 0),
    ("mutation", "Bash", "contains", "echo >>", "*", 0),
    ("mutation", "Bash", "contains", "printf >", "*", 0),
    ("mutation", "Bash", "contains", "printf >>", "*", 0),
    # Redirect to absolute path (catches "echo content > /path/to/file" etc.)
    ("mutation", "Bash", "contains", "> /", "*", 0),
    ("mutation", "Bash", "contains", ">> /", "*", 0),
    # Bare pip/pip3 usage: unsafe intent for enforcement pipeline
    # Matches "pip install", "pip3 install", "pip uninstall", etc.
    # Does NOT match ".venv/bin/pip" — exempt pattern checked first (ORDER BY exempt DESC)
    ("unsafe_pip", "Bash", "contains", "pip install", "*", 0),
    ("unsafe_pip", "Bash", "contains", "pip3 install", "*", 0),
    ("unsafe_pip", "Bash", "contains", "pip uninstall", "*", 0),
    ("unsafe_pip", "Bash", "contains", "pip3 uninstall", "*", 0),
    # Exempt: .venv/bin/pip is always allowed (exempt=1, checked first)
    ("unsafe_pip", "Bash", "contains", ".venv/bin/pip", "*", 1),
]


def seed_tool_usage_patterns(conn: "sqlite3.Connection") -> int:
    """Seed tool_usage_patterns table with default patterns.

    Only inserts patterns that don't already exist (by intent + tool_name + pattern).
    Returns the number of new patterns inserted.

    Seed tuples are (intent, tool_name, match_type, pattern, platform, exempt).
    """
    inserted = 0
    for seed in TOOL_USAGE_PATTERN_SEEDS:
        intent, tool_name, match_type, pattern, platform, exempt = seed

        # Check if this pattern already exists
        existing = conn.execute(
            """SELECT id FROM tool_usage_patterns
            WHERE intent = ? AND tool_name = ? AND pattern IS ?""",
            (intent, tool_name, pattern),
        ).fetchone()

        if not existing:
            conn.execute(
                """INSERT INTO tool_usage_patterns
                (intent, tool_name, match_type, pattern, platform, source, exempt)
                VALUES (?, ?, ?, ?, ?, 'seeded', ?)""",
                (intent, tool_name, match_type, pattern, platform, exempt),
            )
            inserted += 1

    return inserted


class PongogoDatabase:
    """Unified database for all Pongogo routing data."""

    def __init__(
        self, db_path: Path | str | None = None, project_root: Path | None = None
    ):
        """Initialize database connection.

        Args:
            db_path: Explicit path to database file.
            project_root: Project root for project-local database.
                         Ignored if db_path is provided.
        """
        if db_path:
            self.db_path = Path(db_path)
        else:
            self.db_path = get_default_db_path(project_root)

        self._ensure_db_exists()

    def _ensure_db_exists(self) -> None:
        """Create database and schema if they don't exist."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        with self.connection() as conn:
            # Check PRAGMA user_version for fast-path skip
            current_uv = conn.execute("PRAGMA user_version").fetchone()[0]
            if current_uv >= SCHEMA_USER_VERSION:
                return  # Schema is current

            # Check if routing_events table exists (indicates existing database)
            cursor = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='routing_events'"
            )
            table_exists = cursor.fetchone() is not None

            # Run migrations FIRST on existing databases to add missing columns
            # This must happen before executescript(SCHEMA) which creates indexes
            if table_exists:
                self._run_migrations(conn)

            # Run schema script (creates tables if missing, creates indexes)
            conn.executescript(SCHEMA)

            # Set schema version
            conn.execute(
                "INSERT OR REPLACE INTO schema_info (key, value) VALUES (?, ?)",
                ("schema_version", SCHEMA_VERSION),
            )
            conn.execute(
                "INSERT OR REPLACE INTO schema_info (key, value) VALUES (?, ?)",
                ("schema_created_at", "datetime('now')"),
            )

            # Seed tool_usage_patterns with defaults (idempotent)
            seed_tool_usage_patterns(conn)

            # Mark schema as current
            conn.execute(f"PRAGMA user_version = {SCHEMA_USER_VERSION}")

    def _run_migrations(self, conn: sqlite3.Connection) -> None:
        """Run database migrations for existing databases.

        Must be called BEFORE executescript(SCHEMA) to ensure columns exist
        before indexes are created on them.
        """
        cursor = conn.execute("PRAGMA table_info(routing_events)")
        columns = [row[1] for row in cursor.fetchall()]

        # Migration: rename orchestrator_version → preceptor_version (schema 3.5.0)
        if "orchestrator_version" in columns and "preceptor_version" not in columns:
            conn.execute(
                "ALTER TABLE routing_events RENAME COLUMN orchestrator_version TO preceptor_version"
            )
            # Refresh column list after rename
            cursor = conn.execute("PRAGMA table_info(routing_events)")
            columns = [row[1] for row in cursor.fetchall()]

        # Migration: add version fingerprint columns (schema 3.5.0)
        # These columns may be completely missing in older schemas (e.g., v0.2.0)
        fingerprint_columns = [
            ("pongogo_build", "TEXT"),
            ("preceptor_version", "TEXT"),
            ("adapter", "TEXT"),
        ]
        for col_name, col_type in fingerprint_columns:
            if col_name not in columns:
                conn.execute(
                    f"ALTER TABLE routing_events ADD COLUMN {col_name} {col_type}"
                )

        # Migration: add response capture columns (schema 3.6.0)
        # Re-fetch columns in case they changed
        cursor = conn.execute("PRAGMA table_info(routing_events)")
        columns = [row[1] for row in cursor.fetchall()]
        response_columns = [
            ("agent_response", "TEXT"),
            ("agent_response_tokens", "INTEGER"),
            ("response_captured_at", "TEXT"),
            ("response_correlation_method", "TEXT"),
        ]
        for col_name, col_type in response_columns:
            if col_name not in columns:
                conn.execute(
                    f"ALTER TABLE routing_events ADD COLUMN {col_name} {col_type}"
                )

        # Migration: add required_tool column to guidance_fulfillment (schema 3.10.0)
        cursor = conn.execute("PRAGMA table_info(guidance_fulfillment)")
        gf_columns = [row[1] for row in cursor.fetchall()]
        if gf_columns and "required_tool" not in gf_columns:
            conn.execute(
                "ALTER TABLE guidance_fulfillment ADD COLUMN required_tool TEXT"
            )

        # Migration: add blocked_tools, enforcement_scope to guidance_fulfillment (schema 3.11.0)
        # These columns were in CREATE TABLE but never had ALTER TABLE migrations,
        # so existing databases created before these columns were added are missing them.
        # Re-fetch columns after previous migration
        cursor = conn.execute("PRAGMA table_info(guidance_fulfillment)")
        gf_columns = [row[1] for row in cursor.fetchall()]
        if gf_columns and "blocked_tools" not in gf_columns:
            conn.execute(
                "ALTER TABLE guidance_fulfillment ADD COLUMN blocked_tools TEXT"
            )
        if gf_columns and "enforcement_scope" not in gf_columns:
            conn.execute(
                "ALTER TABLE guidance_fulfillment"
                " ADD COLUMN enforcement_scope TEXT DEFAULT 'session'"
            )

        # Migration: add execution_context column to routing_events (schema 3.13.0)
        # Re-fetch routing_events columns after previous migrations
        cursor = conn.execute("PRAGMA table_info(routing_events)")
        columns = [row[1] for row in cursor.fetchall()]
        if "execution_context" not in columns:
            conn.execute("ALTER TABLE routing_events ADD COLUMN execution_context TEXT")

        # Migration: absorb stop_response_capture_hook columns (Task #639)
        # These were previously added by ensure_schema_columns() in the stop hook;
        # now managed centrally here so the stop hook can skip schema work.
        cursor = conn.execute("PRAGMA table_info(routing_events)")
        columns = [row[1] for row in cursor.fetchall()]
        stop_hook_columns = [
            ("agent_response", "TEXT"),
            ("agent_response_tokens", "INTEGER"),
            ("response_captured_at", "TEXT"),
            ("response_correlation_method", "TEXT"),
            ("exclude_from_eval", "BOOLEAN DEFAULT 0"),
        ]
        for col_name, col_type in stop_hook_columns:
            # Strip default clause for column name comparison
            base_name = col_name
            if base_name not in columns:
                conn.execute(
                    f"ALTER TABLE routing_events ADD COLUMN {col_name} {col_type}"
                )

        # Migration: Wave 2 branch context propagation (Task #640)
        # Add branch column to guidance_fulfillment for cross-branch isolation
        cursor = conn.execute("PRAGMA table_info(guidance_fulfillment)")
        gf_columns = [row[1] for row in cursor.fetchall()]
        if gf_columns and "branch" not in gf_columns:
            conn.execute("ALTER TABLE guidance_fulfillment ADD COLUMN branch TEXT")

        # Add branch_name column to routing_events (may already exist from adapter)
        cursor = conn.execute("PRAGMA table_info(routing_events)")
        columns = [row[1] for row in cursor.fetchall()]
        if "branch_name" not in columns:
            conn.execute("ALTER TABLE routing_events ADD COLUMN branch_name TEXT")

        # Migration: Task #653 — enforcement_phase + pattern columns for guidance_fulfillment
        cursor = conn.execute("PRAGMA table_info(guidance_fulfillment)")
        gf_columns = [row[1] for row in cursor.fetchall()]
        if gf_columns and "enforcement_phase" not in gf_columns:
            conn.execute(
                "ALTER TABLE guidance_fulfillment"
                " ADD COLUMN enforcement_phase TEXT DEFAULT 'blocked_until'"
            )
        if gf_columns and "pattern" not in gf_columns:
            conn.execute("ALTER TABLE guidance_fulfillment ADD COLUMN pattern TEXT")

    @contextmanager
    def connection(self) -> Iterator[sqlite3.Connection]:
        """Context manager for database connections.

        Delegates to the unified connection factory which handles WAL,
        timeout, foreign_keys, commit/rollback, and close.

        Yields:
            sqlite3.Connection with row_factory set to sqlite3.Row
        """
        with get_connection(self.db_path) as conn:
            yield conn

    def execute(self, sql: str, params: tuple = ()) -> list[sqlite3.Row]:
        """Execute SQL and return all results."""
        with self.connection() as conn:
            cursor = conn.execute(sql, params)
            return cursor.fetchall()

    def execute_one(self, sql: str, params: tuple = ()) -> sqlite3.Row | None:
        """Execute SQL and return first result."""
        with self.connection() as conn:
            cursor = conn.execute(sql, params)
            return cursor.fetchone()

    def execute_insert(self, sql: str, params: tuple = ()) -> int:
        """Execute INSERT and return last row ID."""
        with self.connection() as conn:
            cursor = conn.execute(sql, params)
            return cursor.lastrowid or 0

    def execute_update(self, sql: str, params: tuple = ()) -> int:
        """Execute UPDATE/DELETE and return rows affected."""
        with self.connection() as conn:
            cursor = conn.execute(sql, params)
            return cursor.rowcount

    def get_schema_version(self) -> str:
        """Get current schema version."""
        result = self.execute_one(
            "SELECT value FROM schema_info WHERE key = ?", ("schema_version",)
        )
        return result["value"] if result else "unknown"

    def get_stats(self) -> dict:
        """Get database statistics for diagnostics."""
        stats = {
            "schema_version": self.get_schema_version(),
            "database_path": str(self.db_path),
            "database_exists": self.db_path.exists(),
        }

        if not self.db_path.exists():
            return stats

        try:
            # Count rows in each table
            tables = [
                "routing_events",
                "routing_triggers",
                "artifact_discovered",
                "artifact_implemented",
                "observation_discovered",
                "observation_implemented",
            ]

            for table in tables:
                result = self.execute_one(f"SELECT COUNT(*) as cnt FROM {table}")
                stats[f"{table}_count"] = result["cnt"] if result else 0

            # Database file size
            stats["database_size_bytes"] = self.db_path.stat().st_size

        except sqlite3.OperationalError as e:
            stats["error"] = str(e)

        return stats
