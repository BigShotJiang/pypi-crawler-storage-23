#!/usr/bin/env python3
"""
PostToolUse Routing Hook for AskUserQuestion Responses

Fires after AskUserQuestion tool calls to route the user's response through
the Pongogo routing engine. This enables routing coverage during plan mode
conversations, where the primary interaction channel is AskUserQuestion
rather than UserPromptSubmit.

Architecture:
    AskUserQuestion Complete → PostToolUse Hook → This Script →
        [Extract Response] → [Route Through Engine] → [Register Compliance] →
        [Capture Event] → stdout (injected as context) → Claude

Separate from PostToolUse compliance hook because:
- Compliance hook has a silent-output contract (no stdout, DB-only)
- Compliance hook fast-path skips anything that isn't Read or mcp__*
- Routing and compliance tracking are orthogonal concerns

Usage:
    Configured in .claude/settings.local.json as PostToolUse hook:
    {
      "hooks": {
        "PostToolUse": [{
          "matcher": "AskUserQuestion",
          "hooks": [{"type": "command", "command": "/path/to/posttooluse_routing_hook.py"}]
        }]
      }
    }

Input:
    Receives JSON via stdin with:
    - session_id: Current session identifier
    - tool_name: "AskUserQuestion"
    - tool_input: Question payload (questions, options, etc.)
    - tool_response: User's selected answer(s)
    - permission_mode: Permission settings (e.g., "plan")
    - hook_event_name: "PostToolUse"

Output:
    Prints formatted routing context to stdout (injected into conversation)
    OR prints nothing if Pongogo disabled/no routing match

Exit Codes:
    0: Success (context injected or skipped)
    1: Error (logged, doesn't block)

Task #634: AskUserQuestion Routing Pipeline Integration
"""

import json
import logging
import sys
import time
from pathlib import Path

# Ensure mcp_server package is importable when run as standalone hook script.
# Hooks are invoked directly by Claude Code, so src/ must be on sys.path.
_src_path = str(Path(__file__).parent.parent.parent)
if _src_path not in sys.path:
    sys.path.insert(0, _src_path)

# Import adapter functions (reuse, don't duplicate ~500 lines)
try:
    from mcp_server.hooks.claude_code_adapter import (
        call_routing_engine,
        capture_routing_event,
        format_routing_results,
        get_log_paths,
        load_state_file,
    )
except ImportError:
    try:
        from src.mcp_server.hooks.claude_code_adapter import (
            call_routing_engine,
            capture_routing_event,
            format_routing_results,
            get_log_paths,
            load_state_file,
        )
    except ImportError:
        # Will be caught at runtime in main() — allows import for testing
        call_routing_engine = None
        capture_routing_event = None
        format_routing_results = None
        get_log_paths = None
        load_state_file = None

# Import compliance preceptor
try:
    from mcp_server.preceptor import CompliancePreceptor
except ImportError:
    try:
        from src.mcp_server.preceptor import CompliancePreceptor
    except ImportError:
        CompliancePreceptor = None

# Configure logging to file (not stdout - stdout is context injection)
# Lazy initialization to avoid side effects at import time (CI test environments)
_log_initialized = False
logger = logging.getLogger(__name__)


def _get_log_dir() -> Path:
    """Get the appropriate log directory, worktree-aware."""
    import os

    try:
        from mcp_server.database.context import get_data_root

        return get_data_root() / ".pongogo" / "logs"
    except ImportError:
        project_root = os.environ.get("PONGOGO_PROJECT_ROOT")
        if project_root:
            return Path(project_root) / ".pongogo" / "logs"
        return Path.home() / ".claude" / "logs"


def _ensure_log_dir(session_id: str = "", branch: str = ""):
    """Ensure log directory exists and configure dual logging. Called lazily on first use."""
    global _log_initialized
    if _log_initialized:
        return

    try:
        from mcp_server.hooks.logging_utils import setup_dual_logging

        log_dir = _get_log_dir()
        setup_dual_logging(
            log_dir=log_dir,
            hook_name="posttooluse-routing",
            session_id=session_id,
            branch=branch,
        )
    except ImportError:
        log_dir = _get_log_dir()
        try:
            log_dir.mkdir(parents=True, exist_ok=True)
            logging.basicConfig(
                filename=log_dir / "posttooluse-routing.log",
                level=logging.INFO,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
        except (PermissionError, OSError):
            logging.basicConfig(
                stream=sys.stderr,
                level=logging.WARNING,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
    _log_initialized = True


def extract_routing_message(tool_input: dict, tool_response: str) -> str:
    """Build composite message from AskUserQuestion payload.

    Combines question context + user response for routing accuracy.
    Example output: "[Question]: Which approach?\\n[Response]: Use Redis"

    Falls back to raw tool_response if structured extraction fails.

    Args:
        tool_input: The AskUserQuestion tool_input containing questions/options
        tool_response: The user's answer text from tool_result

    Returns:
        Composite message string for routing, or empty string if no content
    """
    if not tool_response or not tool_response.strip():
        return ""

    parts = []

    # Extract question text from tool_input for context
    try:
        questions = tool_input.get("questions", [])
        if questions:
            # Collect all question texts
            question_texts = []
            for q in questions:
                question_text = q.get("question", "")
                if question_text:
                    question_texts.append(question_text)
            if question_texts:
                parts.append(f"[Question]: {' | '.join(question_texts)}")
    except (AttributeError, TypeError):
        # tool_input might not be a dict or questions might not be a list
        logger.debug("Could not extract questions from tool_input")

    # Add the user's response
    response_text = tool_response.strip()
    parts.append(f"[Response]: {response_text}")

    return "\n".join(parts)


def main():
    start_time = time.time()

    try:
        input_data = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError):
        _ensure_log_dir()
        logger.error("Failed to read JSON from stdin")
        sys.exit(0)  # Don't block on input errors

    tool_name = input_data.get("tool_name", "")

    # Fast-path: skip if not AskUserQuestion
    if tool_name != "AskUserQuestion":
        sys.exit(0)

    session_id = input_data.get("session_id", "")
    tool_input = input_data.get("tool_input", {})
    tool_response = input_data.get("tool_response", "")
    cwd = input_data.get("cwd", "")
    permission_mode = input_data.get("permission_mode", "")

    # Initialize dual logging with session context
    _ensure_log_dir(session_id=session_id)

    logger.info(
        f"AskUserQuestion PostToolUse fired: session={session_id}, "
        f"permission_mode={permission_mode}"
    )

    # Verify adapter functions are available
    if call_routing_engine is None or load_state_file is None:
        logger.error("Could not import adapter functions")
        sys.exit(0)

    # Load state file to check mode
    state = load_state_file()
    mode = state.get("mode", "disabled")

    if mode == "disabled":
        logger.info("Pongogo disabled, skipping routing")
        sys.exit(0)

    # Extract composite message from question + response
    message = extract_routing_message(tool_input, tool_response)
    if not message:
        logger.info("Empty response from AskUserQuestion, skipping routing")
        sys.exit(0)

    # Route through engine
    logger.info(f"Routing AskUserQuestion response: {message[:100]}")
    routing_start = time.time()

    routing_result = call_routing_engine(
        message=message, context={"cwd": cwd, "session_id": session_id}
    )

    routing_time = (time.time() - routing_start) * 1000

    # Register compliance requirements from procedural instructions
    try:
        # Detect branch for cross-branch isolation (Task #640)
        from mcp_server.database.context import get_current_branch

        current_branch = get_current_branch(cwd=cwd)

        _logs_dir, _pongogo_dir, db_path = get_log_paths(state, Path(cwd))
        preceptor = CompliancePreceptor(db_path)
        compliance_context = preceptor.process_routing_result(
            routing_result=routing_result,
            session_id=session_id,
            execution_context="plan" if permission_mode == "plan" else None,
            branch=current_branch,
        )
        if compliance_context.had_procedural:
            if compliance_context.enforcement_suppressed:
                logger.info(
                    f"COMPLIANCE_SUPPRESSED_PLAN_MODE: {len(compliance_context.specs)} "
                    f"procedural instruction(s) detected but enforcement skipped (plan mode)"
                )
            else:
                logger.info(
                    f"COMPLIANCE_REGISTERED: {compliance_context.registered_count} requirements "
                    f"from {len(compliance_context.specs)} procedural instruction(s)"
                )
    except Exception as e:
        logger.warning(f"COMPLIANCE_REGISTRATION_ERROR: {e}")

    # Format results for context injection
    formatted_context = format_routing_results(routing_result, message=message)

    total_time = (time.time() - start_time) * 1000

    # Capture routing event with source_context tagging
    source_context = {
        "source": "posttooluse_askuserquestion",
        "permission_mode": permission_mode or "unknown",
    }

    try:
        capture_routing_event(
            prompt=message,
            session_id=session_id,
            cwd=cwd,
            mode=mode,
            routing_result=routing_result,
            formatted_context=formatted_context,
            routing_latency_ms=routing_time,
            total_latency_ms=total_time,
            cache_status="miss",  # No caching for PostToolUse — each response is unique
            input_data=input_data,
            state=state,
            source_context=source_context,
        )
    except Exception as e:
        logger.error(f"Failed to capture routing event: {e}")

    # Inject context via stdout (if there's anything to inject)
    if formatted_context:
        print(formatted_context)
        logger.info(
            f"Routing context injected: {len(formatted_context)} chars, "
            f"routing={routing_time:.1f}ms, total={total_time:.1f}ms"
        )
    else:
        logger.info(
            f"No routing context to inject: "
            f"routing={routing_time:.1f}ms, total={total_time:.1f}ms"
        )

    sys.exit(0)


if __name__ == "__main__":
    main()
