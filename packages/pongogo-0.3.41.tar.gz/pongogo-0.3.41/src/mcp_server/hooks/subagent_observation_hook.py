#!/usr/bin/env python3
"""SubagentStart and SubagentStop observation hook for Pongogo.

Task #637: Sub-agent Pongogo Integration
Epic #632: Plan Mode and Agent Context Compatibility

This hook captures sub-agent lifecycle events (start/stop) for observation.
Parent hooks do NOT fire in sub-agent processes, so these parent-context
events are the only touchpoint for Pongogo to observe sub-agent work.

Hook events handled:
- SubagentStart: Logs sub-agent spawn with agent_id, agent_type
- SubagentStop: Captures transcript path and last message for post-hoc analysis

Output:
- Logs events to observation DB (routing_events table with execution_context='subagent')
- SubagentStart: silent (no stdout), informational only
- SubagentStop: silent (no stdout), captures event data
"""

import json
import logging
import sys
import time
from pathlib import Path

_log_initialized = False
logger = logging.getLogger(__name__)


def _get_log_dir() -> Path:
    """Get log directory, worktree-aware via get_data_root()."""
    try:
        from mcp_server.database.context import get_data_root

        return get_data_root() / ".pongogo" / "logs"
    except ImportError:
        import os

        project_root = os.environ.get("PONGOGO_PROJECT_ROOT") or os.environ.get(
            "CLAUDE_PROJECT_DIR", ""
        )
        if project_root:
            return Path(project_root) / ".pongogo" / "logs"
        return Path.home() / ".claude" / "logs"


def _ensure_log_dir(session_id: str = "", branch: str = ""):
    """Lazy-init dual logging to avoid side effects on import."""
    global _log_initialized
    if _log_initialized:
        return

    try:
        from mcp_server.hooks.logging_utils import setup_dual_logging

        log_dir = _get_log_dir()
        setup_dual_logging(
            log_dir=log_dir,
            hook_name="subagent-observation",
            session_id=session_id,
            branch=branch,
        )
    except ImportError:
        log_dir = _get_log_dir()
        try:
            log_dir.mkdir(parents=True, exist_ok=True)
            logging.basicConfig(
                filename=str(log_dir / "subagent_observation.log"),
                level=logging.INFO,
                format="%(asctime)s %(levelname)s %(message)s",
            )
        except (PermissionError, OSError):
            logging.basicConfig(
                stream=sys.stderr,
                level=logging.WARNING,
                format="%(asctime)s %(levelname)s %(message)s",
            )
    _log_initialized = True


def _analyze_transcript(transcript_path: str) -> dict:
    """Light analysis of sub-agent transcript for audit trail.

    Reads the transcript JSONL file (capped at 1MB) and extracts:
    - tools_used: set of tool names invoked
    - tool_count: total number of tool invocations
    - compliance_actions: count of compliance-related actions

    Args:
        transcript_path: Path to the sub-agent's transcript JSONL file

    Returns:
        Summary dict with analysis results. Returns {"analyzed": False}
        if file is missing or unreadable.
    """
    if not transcript_path:
        return {"analyzed": False, "reason": "no_transcript_path"}

    transcript_file = Path(transcript_path)
    if not transcript_file.exists():
        return {"analyzed": False, "reason": "file_not_found"}

    MAX_SIZE = 1_048_576  # 1MB cap to prevent OOM
    tools_used: set[str] = set()
    tool_count = 0
    compliance_actions = 0

    try:
        file_size = transcript_file.stat().st_size
        if file_size > MAX_SIZE:
            # Read only first 1MB
            raw_content = transcript_file.read_bytes()[:MAX_SIZE].decode(
                "utf-8", errors="replace"
            )
            lines = raw_content.splitlines()
        else:
            lines = transcript_file.read_text().splitlines()

        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            # Look for tool_use content blocks in assistant messages
            msg = entry.get("message", {})
            content = msg.get("content", [])
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "tool_use":
                        tool_name = block.get("name", "")
                        if tool_name:
                            tools_used.add(tool_name)
                            tool_count += 1
                            if "compliance" in tool_name.lower():
                                compliance_actions += 1

        return {
            "analyzed": True,
            "tools_used": sorted(tools_used),
            "tool_count": tool_count,
            "compliance_actions": compliance_actions,
            "truncated": file_size > MAX_SIZE if file_size else False,
        }
    except Exception as e:
        return {"analyzed": False, "reason": str(e)[:100]}


def _write_observation_event(
    event_type: str,
    agent_id: str,
    agent_type: str,
    session_id: str,
    input_data: dict,
    branch: str = "",
) -> None:
    """Write sub-agent observation event to JSONL log.

    Uses a dedicated JSONL file for sub-agent events rather than the
    routing_events table, since sub-agent events don't have routing results.
    """
    log_dir = _get_log_dir()
    jsonl_path = log_dir / "subagent_events.jsonl"

    event = {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "event_type": event_type,
        "agent_id": agent_id,
        "agent_type": agent_type,
        "session_id": session_id,
        "parent_session_id": session_id,
        "branch": branch,
    }

    if event_type == "subagent_stop":
        event["agent_transcript_path"] = input_data.get("agent_transcript_path", "")
        # Truncate last_assistant_message to avoid huge log entries
        last_msg = input_data.get("last_assistant_message", "")
        event["last_assistant_message_preview"] = last_msg[:500] if last_msg else ""
        event["last_assistant_message_length"] = len(last_msg) if last_msg else 0

        # Transcript analysis (Task #641)
        transcript_path = input_data.get("agent_transcript_path", "")
        event["transcript_summary"] = _analyze_transcript(transcript_path)

    try:
        with open(jsonl_path, "a") as f:
            f.write(json.dumps(event) + "\n")
    except Exception as e:
        logger.error(f"Failed to write subagent event: {e}")


def main():
    """Main entry point for SubagentStart and SubagentStop hooks."""
    start_time = time.time()

    try:
        raw_input = sys.stdin.read()
    except Exception as e:
        _ensure_log_dir()
        logger.error(f"Failed to read stdin: {e}")
        sys.exit(0)

    try:
        input_data = json.loads(raw_input)
    except (json.JSONDecodeError, ValueError) as e:
        _ensure_log_dir()
        logger.error(f"Invalid JSON on stdin: {e}")
        sys.exit(0)

    hook_event = input_data.get("hook_event_name", "")
    agent_id = input_data.get("agent_id", "unknown")
    agent_type = input_data.get("agent_type", "unknown")
    session_id = input_data.get("session_id", "unknown")

    # Detect branch for event correlation (Task #641)
    try:
        from mcp_server.database.context import get_current_branch

        branch = get_current_branch() or ""
    except ImportError:
        branch = ""

    # Initialize dual logging with session context
    _ensure_log_dir(session_id=session_id, branch=branch)

    if hook_event == "SubagentStart":
        logger.info(
            f"SUBAGENT_START: agent_id={agent_id} "
            f"agent_type={agent_type} session={session_id} branch={branch}"
        )
        _write_observation_event(
            event_type="subagent_start",
            agent_id=agent_id,
            agent_type=agent_type,
            session_id=session_id,
            input_data=input_data,
            branch=branch,
        )

    elif hook_event == "SubagentStop":
        transcript_path = input_data.get("agent_transcript_path", "")
        last_msg_len = len(input_data.get("last_assistant_message", ""))
        elapsed = (time.time() - start_time) * 1000

        logger.info(
            f"SUBAGENT_STOP: agent_id={agent_id} "
            f"agent_type={agent_type} session={session_id} "
            f"branch={branch} transcript={transcript_path} "
            f"last_msg_chars={last_msg_len} "
            f"hook_time={elapsed:.1f}ms"
        )
        _write_observation_event(
            event_type="subagent_stop",
            agent_id=agent_id,
            agent_type=agent_type,
            session_id=session_id,
            input_data=input_data,
            branch=branch,
        )

    else:
        logger.warning(
            f"UNEXPECTED_EVENT: {hook_event} (expected SubagentStart or SubagentStop)"
        )

    sys.exit(0)


if __name__ == "__main__":
    main()
