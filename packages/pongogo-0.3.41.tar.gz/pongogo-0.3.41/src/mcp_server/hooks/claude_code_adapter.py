#!/usr/bin/env python3
"""
Claude Code Adapter for Always-On Routing

UserPromptSubmit hook that automatically routes every message through Pongogo routing engine.
Implements session-based caching and context injection for standards enforcement.

Architecture:
    User Message → UserPromptSubmit Hook → This Script →
        [Check Config] → [Check Cache] → [Call Routing Engine] →
        [Format Context] → [Cache Results] → stdout (injected as context) → Claude

Usage:
    Configured in ~/.claude/settings.json as UserPromptSubmit hook:
    {
      "hooks": {
        "UserPromptSubmit": [{
          "hooks": [{"type": "command", "command": "/path/to/claude_code_adapter.py"}]
        }]
      }
    }

Input:
    Receives JSON via stdin with:
    - prompt: User's submitted text
    - session_id: Current session identifier
    - cwd: Current working directory
    - permission_mode: Permission settings

Output:
    Prints formatted context to stdout (injected into conversation)
    OR prints nothing if Pongogo disabled/cached

Exit Codes:
    0: Success (context injected or skipped)
    1: Error (logged, but doesn't block prompt)
"""

import contextlib
import hashlib
import json
import logging
import os
import re
import sqlite3
import sys
import time
from datetime import date, datetime
from pathlib import Path

# Ensure mcp_server package is importable when run as standalone hook script.
# Hooks are invoked directly by Claude Code, so src/ must be on sys.path.
_src_path = str(Path(__file__).parent.parent.parent)
if _src_path not in sys.path:
    sys.path.insert(0, _src_path)

from mcp_server.database.connection import atomic_json_write, get_connection

# Configure logging to file (not stdout - stdout is context injection)
# Lazy initialization to avoid side effects at import time (CI test environments)
_log_initialized = False
_log_dir: Path | None = None
logger = logging.getLogger(__name__)


def _get_log_dir() -> Path:
    """Get the appropriate log directory, worktree-aware."""
    try:
        from mcp_server.database.context import get_data_root

        return get_data_root() / ".pongogo" / "logs"
    except ImportError:
        project_root = os.environ.get("PONGOGO_PROJECT_ROOT")
        if project_root:
            return Path(project_root) / ".pongogo" / "logs"
        return Path.home() / ".claude" / "logs"


def _ensure_log_dir(session_id: str = "", branch: str = ""):
    """Ensure log directory exists and configure dual logging. Called lazily on first use."""
    global _log_initialized, _log_dir
    if _log_initialized:
        return

    _log_dir = _get_log_dir()

    try:
        from mcp_server.hooks.logging_utils import setup_dual_logging

        _log_dir = setup_dual_logging(
            log_dir=_log_dir,
            hook_name="always-on-routing",
            session_id=session_id,
            branch=branch,
        )
    except ImportError:
        # Fallback: text-only logging
        try:
            _log_dir.mkdir(parents=True, exist_ok=True)
            logging.basicConfig(
                filename=_log_dir / "always-on-routing.log",
                level=logging.INFO,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
        except (PermissionError, OSError):
            _log_dir = Path("/tmp/pongogo-logs")
            logging.basicConfig(
                stream=sys.stderr,
                level=logging.WARNING,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )

    # Ensure instruction-state subdirectory exists
    state_dir = _log_dir / "instruction-state"
    with contextlib.suppress(PermissionError, OSError):
        state_dir.mkdir(parents=True, exist_ok=True)

    _log_initialized = True


def _get_early_log_file() -> Path:
    """Get the early log file path, ensuring log dir is initialized."""
    _ensure_log_dir()
    return (_log_dir or Path("/tmp/pongogo-logs")) / "hook-invocations.log"


def _get_instruction_state_dir() -> Path:
    """Get the instruction state directory, ensuring log dir is initialized."""
    _ensure_log_dir()
    return (_log_dir or Path("/tmp/pongogo-logs")) / "instruction-state"


# Version fingerprinting constants
ADAPTER_NAME = "claude_code"
ADAPTER_VERSION = "1.0.0"


def get_pongogo_build() -> str:
    """Get pongogo build identifier for routing event tracking.

    CI/CD: Uses PONGOGO_VERSION env var (e.g., "0.2.0-alpha.93").
    Local dev: Derives from git commit hash (e.g., "dev+d9c5a7f" or "dev+d9c5a7f.dirty").
    """
    env_version = os.environ.get("PONGOGO_VERSION")
    if env_version:
        return env_version

    try:
        import subprocess

        # Get short commit hash
        short_hash = (
            subprocess.check_output(
                ["git", "rev-parse", "--short", "HEAD"],
                stderr=subprocess.DEVNULL,
                timeout=5,
            )
            .decode()
            .strip()
        )

        # Check for uncommitted changes
        dirty = (
            subprocess.call(
                ["git", "diff", "--quiet", "HEAD"],
                stderr=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                timeout=5,
            )
            != 0
        )

        return f"dev+{short_hash}" + (".dirty" if dirty else "")
    except Exception:
        return "0.1.0-dev"


def _get_preceptor_version() -> str:
    """Get preceptor version via lazy import (avoids hook crash if module missing)."""
    try:
        # Try installed package path first (Docker/pip install)
        from mcp_server.preceptor import PRECEPTOR_VERSION

        return PRECEPTOR_VERSION
    except ImportError:
        try:
            # Fall back to source path (local development)
            from src.mcp_server.preceptor import PRECEPTOR_VERSION

            return PRECEPTOR_VERSION
        except ImportError:
            return "unknown"


# =============================================================================
# INSTRUCTION COMPLIANCE STATE MANAGEMENT
# =============================================================================
# Functions for tracking which instruction files were routed and verifying
# that the agent has read them before proceeding with tool execution.
#
# Architecture (Task #227):
#   UserPromptSubmit: Routes instructions → writes state (file paths)
#   PreToolUse: Reads state → checks transcript for Read tool calls → allows/denies
#
# Goal: Ensure agent reads ALL routed instruction files in full (not excerpts,
# not from memory) to leverage institutional knowledge in Pongogo's self-healing
# and self-teaching loops.
# =============================================================================


def get_instruction_state_path(session_id: str) -> Path:
    """
    Get path to instruction state file for a session.

    Args:
        session_id: Session identifier

    Returns:
        Path to session's instruction state JSON file
    """
    # Hash session_id for filesystem-safe filename
    session_hash = hashlib.md5(session_id.encode()).hexdigest()[:16]
    return _get_instruction_state_dir() / f"instructions-{session_hash}.json"


def write_instruction_state(session_id: str, routed_files: list[str]) -> None:
    """
    Write routed instruction file paths for inter-hook communication.

    Called by UserPromptSubmit after routing to record which instruction
    files were surfaced. PreToolUse will then verify the agent read them.

    Args:
        session_id: Session identifier
        routed_files: List of instruction file paths that were routed
    """
    if not routed_files:
        return  # No files to track

    state_path = get_instruction_state_path(session_id)

    state = {
        "routed_files": routed_files,
        "routed_at": datetime.now().isoformat(),
        "files_read": [],  # Populated by PreToolUse as reads verified
    }

    atomic_json_write(state_path, state)

    logger.info(
        f"INSTRUCTION_STATE_WRITTEN: {len(routed_files)} files for session {session_id[:16]}..."
    )


def read_instruction_state(session_id: str) -> dict | None:
    """
    Read instruction state for a session.

    Called by PreToolUse to check which instruction files need to be read.

    Args:
        session_id: Session identifier

    Returns:
        Instruction state dict if exists, None otherwise
    """
    state_path = get_instruction_state_path(session_id)

    if not state_path.exists():
        return None

    try:
        with open(state_path) as f:
            state = json.load(f)

        # Check if state is stale (older than 1 hour)
        routed_at = datetime.fromisoformat(state.get("routed_at", "1970-01-01"))
        age_hours = (datetime.now() - routed_at).total_seconds() / 3600

        if age_hours > 1:
            logger.info(f"INSTRUCTION_STATE_STALE: {age_hours:.1f}h old, clearing")
            clear_instruction_state(session_id)
            return None

        return state

    except (json.JSONDecodeError, ValueError) as e:
        logger.warning(f"INSTRUCTION_STATE_CORRUPT: {e}, clearing state")
        clear_instruction_state(session_id)
        return None


def clear_instruction_state(session_id: str) -> None:
    """
    Clear instruction state for a session.

    Called when all files have been read or state is stale.

    Args:
        session_id: Session identifier
    """
    state_path = get_instruction_state_path(session_id)

    if state_path.exists():
        state_path.unlink()
        logger.info(f"INSTRUCTION_STATE_CLEARED: session {session_id[:16]}...")


def update_instruction_files_read(session_id: str, file_path: str) -> None:
    """
    Mark an instruction file as read in state.

    Called by PreToolUse when it detects a Read tool call for an instruction file.

    Args:
        session_id: Session identifier
        file_path: Path to the instruction file that was read
    """
    state = read_instruction_state(session_id)
    if not state:
        return

    files_read = state.get("files_read", [])
    if file_path not in files_read:
        files_read.append(file_path)
        state["files_read"] = files_read

        state_path = get_instruction_state_path(session_id)
        atomic_json_write(state_path, state)

        logger.info(f"INSTRUCTION_FILE_READ: {file_path}")


def check_instruction_reads_satisfied(session_id: str) -> tuple[bool, list[str]]:
    """
    Check if all routed instruction files have been read.

    Args:
        session_id: Session identifier

    Returns:
        Tuple of (all_satisfied: bool, unread_files: list)
    """
    state = read_instruction_state(session_id)
    if not state:
        return (True, [])  # No routed files, nothing to check

    routed_files = set(state.get("routed_files", []))
    files_read = set(state.get("files_read", []))

    unread = list(routed_files - files_read)

    return (len(unread) == 0, unread)


def write_early_log(session_id: str, event_type: str, details: str = ""):
    """
    Write to early log file with minimal dependencies.

    This captures hook invocations immediately after stdin read,
    before any complex imports or processing that could fail.
    Helps diagnose silent hook failures.

    Args:
        session_id: Session identifier
        event_type: Type of event (HOOK_START, HOOK_END, HOOK_ERROR)
        details: Optional additional details
    """
    try:
        early_log_file = _get_early_log_file()
        timestamp = datetime.now().isoformat()
        entry = f"{timestamp} | {event_type} | session={session_id} | {details}\n"
        with open(early_log_file, "a") as f:
            f.write(entry)
    except Exception:
        pass  # Silently continue - this is a diagnostic aid, not critical


def estimate_token_count(text: str) -> int:
    """
    Estimate token count for text using rough heuristic.

    Uses ~4 characters per token approximation (conservative for English).
    For production, consider using tiktoken library for accurate counts.

    Args:
        text: Text to estimate tokens for

    Returns:
        Estimated token count
    """
    if not text:
        return 0
    # Conservative estimate: 4 chars per token (actually ~3.5-4 for English)
    return max(1, len(text) // 4)


def get_claude_code_version() -> str | None:
    """
    Get Claude Code version by calling `claude --version`.

    Returns:
        Version string (e.g., "2.0.51") or None if detection fails
    """
    import subprocess

    try:
        result = subprocess.run(
            ["claude", "--version"], capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            # Output format: "2.0.51 (Claude Code)"
            version = result.stdout.strip().split()[0]
            return version
    except Exception as e:
        logger.debug(f"Could not detect Claude Code version: {e}")
    return None


def get_default_model_for_version(version: str) -> str:
    """
    Get the default model for a given Claude Code version.

    Maintains mapping of Claude Code versions to their default models.
    This enables self-healing when model field is missing from settings.json.

    Args:
        version: Claude Code version string (e.g., "2.0.51")

    Returns:
        Default model identifier for that version
    """
    # Version to default model mapping
    # Updated when Claude Code changes default models
    # Reference: /release-notes command output
    VERSION_DEFAULTS = {
        # 2.0.51+ introduced Opus 4.5 as default
        "2.0.51": "claude-opus-4-5-20251101",
        # Pre-2.0.51 used Sonnet 4.5 as default
    }

    # Check for exact match first
    if version in VERSION_DEFAULTS:
        return VERSION_DEFAULTS[version]

    # For newer versions, assume latest known default (Opus 4.5)
    try:
        major, minor, patch = map(int, version.split("."))
        if (
            major > 2
            or (major == 2 and minor > 0)
            or (major == 2 and minor == 0 and patch >= 51)
        ):
            return "claude-opus-4-5-20251101"
    except (ValueError, AttributeError):
        pass

    # Fallback to Sonnet 4.5 for older/unknown versions
    return "claude-sonnet-4-5-20250929"


def self_heal_model_config() -> tuple[str | None, str | None]:
    """
    Self-heal missing model configuration in settings.json.

    When model field is missing:
    1. Detect Claude Code version
    2. Look up default model for that version
    3. Update settings.json with the model field
    4. Return model and info message

    Returns:
        Tuple of (model_identifier, info_message)
        - model_identifier: The configured or auto-configured model
        - info_message: Message to display if auto-configured, None otherwise
    """
    settings_path = Path.home() / ".claude" / "settings.json"

    try:
        if not settings_path.exists():
            logger.warning(f"Settings file not found: {settings_path}")
            return None, None

        with open(settings_path) as f:
            settings = json.load(f)

        model = settings.get("model")
        if model:
            # Model already configured
            return model, None

        # Model missing - self-heal
        version = get_claude_code_version()
        if not version:
            logger.warning("Could not detect Claude Code version for self-healing")
            return None, None

        default_model = get_default_model_for_version(version)

        # Update settings.json with model field
        settings["model"] = default_model

        # Write back atomically
        import tempfile

        with tempfile.NamedTemporaryFile(
            mode="w", dir=settings_path.parent, delete=False, suffix=".json"
        ) as tmp:
            json.dump(settings, tmp, indent=2)
            tmp.write("\n")
            tmp_path = tmp.name

        os.replace(tmp_path, settings_path)

        info_msg = (
            f"⚠️ **Model auto-configured**: `{default_model}` "
            f"(Claude Code {version} default). "
            f"Edit ~/.claude/settings.json to change."
        )
        logger.info(f"Self-healed model config: {default_model} (version {version})")

        return default_model, info_msg

    except Exception as e:
        logger.error(f"Error in self_heal_model_config: {e}", exc_info=True)
        return None, None


def get_model_from_transcript(transcript_path: str) -> str | None:
    """
    Extract the actual model being used from the transcript file.

    The transcript file (JSONL format) records the model for each assistant message.
    We read the most recent assistant message to get the actual model in use.

    This is more accurate than settings.json because:
    - settings.json may be stale or missing the model field
    - User may have changed models via /model command
    - Transcript reflects what's actually running

    Args:
        transcript_path: Path to the transcript JSONL file

    Returns:
        Model identifier from most recent assistant message, or None if not found
    """
    if not transcript_path:
        return None

    try:
        transcript_file = Path(transcript_path)
        if not transcript_file.exists():
            logger.debug(f"Transcript file not found: {transcript_path}")
            return None

        # Read transcript file (JSONL format - one JSON object per line)
        # We need to find the most recent assistant message with a model field
        model = None

        with open(transcript_file) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue

                try:
                    entry = json.loads(line)

                    # Look for assistant messages which contain the model field
                    message = entry.get("message", {})
                    if message.get("role") == "assistant" and "model" in message:
                        model = message["model"]
                        # Don't break - keep reading to get the MOST RECENT one

                except json.JSONDecodeError:
                    continue

        if model:
            logger.info(f"Model identifier from transcript: {model}")
            return model

    except Exception as e:
        logger.debug(f"Error reading model from transcript: {e}")

    return None


def get_model_identifier(input_data: dict = None) -> str | None:
    """
    Get Claude model identifier with multi-source detection.

    Priority order:
    1. Transcript file (most accurate - reflects actual running model)
    2. settings.json model field (user configuration)
    3. Version-based default (self-healing fallback)
    4. None only if all methods fail

    Args:
        input_data: Hook input data containing transcript_path

    Returns:
        Model identifier from best available source, None if all methods fail
    """
    # Priority 1: Get model from transcript (most accurate)
    if input_data:
        transcript_path = input_data.get("transcript_path")
        if transcript_path:
            model = get_model_from_transcript(transcript_path)
            if model:
                return model
            # Note: On first message, transcript has no assistant messages yet

    # Priority 2: Get model from settings.json
    settings_path = Path.home() / ".claude" / "settings.json"

    try:
        if settings_path.exists():
            with open(settings_path) as f:
                settings = json.load(f)
                model = settings.get("model")
                if model:
                    logger.info(f"Model identifier from settings.json: {model}")
                    return model

        # Model not configured - attempt self-healing
        # Note: self_heal_model_config() is called separately in main() to get info_message
        # This function just returns the current state
        logger.debug("Model not configured in settings.json")

    except Exception as e:
        logger.error(f"Error reading model from settings.json: {e}", exc_info=True)

    return None


def get_platform_identifier() -> str:
    """
    Get platform identifier for this adapter.

    Returns platform name for tracking which AI coding assistant is being used.
    Future adapters will return different values:
    - "claude-code" (this adapter)
    - "cursor" (future)
    - "windsurf" (future)
    - "warp" (future)
    - "github-copilot" (future)

    Returns:
        Platform identifier string
    """
    # This is the Claude Code adapter
    return "claude-code"


def get_git_context(cwd: str) -> dict[str, str | None]:
    """
    Extract git repository name and current branch from working directory.

    Enables multi-repo observability tracking:
    - repo_name: "owner/repo" format for GitHub repos
    - branch_name: Current branch (e.g., "main", "feature/xyz")

    Args:
        cwd: Current working directory path

    Returns:
        Dictionary with repo_name and branch_name (None if not in git repo)
    """
    import subprocess

    repo_name = None
    branch_name = None

    try:
        repo_path = Path(cwd)

        # Find .git directory (walk up from cwd)
        git_dir = None
        current = repo_path
        while current != current.parent:
            potential_git = current / ".git"
            if potential_git.exists():
                git_dir = current
                break
            current = current.parent

        if git_dir is None:
            # Not in a git repository
            return {"repo_name": None, "branch_name": None}

        # Get remote URL to extract repo name
        result = subprocess.run(
            ["git", "-C", str(git_dir), "config", "--get", "remote.origin.url"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        if result.returncode == 0:
            remote_url = result.stdout.strip()

            # Parse repo name from various URL formats:
            # - git@github.com:owner/repo.git
            # - https://github.com/owner/repo.git
            # - https://github.com/owner/repo
            if "github.com" in remote_url:
                if remote_url.startswith("git@"):
                    # git@github.com:owner/repo.git → owner/repo
                    repo_part = remote_url.split(":")[-1]
                else:
                    # https://github.com/owner/repo.git → owner/repo
                    repo_part = "/".join(remote_url.split("/")[-2:])

                # Remove .git suffix if present
                repo_name = repo_part.replace(".git", "")

        # Get current branch name
        result = subprocess.run(
            ["git", "-C", str(git_dir), "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
        )

        if result.returncode == 0:
            branch_name = result.stdout.strip()

    except subprocess.TimeoutExpired:
        logger.warning(f"Git command timed out for cwd={cwd}")
    except Exception as e:
        logger.debug(f"Could not extract git context: {e}")
        # Not an error - working directory may not be a git repo

    return {"repo_name": repo_name, "branch_name": branch_name}


class SessionCache:
    """In-memory session cache for routing results."""

    def __init__(self, cache_ttl_seconds: int = 3600):
        """
        Initialize session cache.

        Args:
            cache_ttl_seconds: Time-to-live for cached entries (default: 1 hour)
        """
        self.cache: dict[str, dict] = {}
        self.cache_ttl = cache_ttl_seconds

    def get(self, session_id: str) -> dict | None:
        """
        Get cached routing data for session.

        Args:
            session_id: Session identifier

        Returns:
            Cached data dict (context, routing_result, timestamp) or None if not cached/expired
        """
        if session_id not in self.cache:
            return None

        entry = self.cache[session_id]
        age = time.time() - entry["timestamp"]

        if age > self.cache_ttl:
            logger.info(f"Cache expired for session {session_id} (age: {age:.1f}s)")
            del self.cache[session_id]
            return None

        logger.info(f"Cache hit for session {session_id} (age: {age:.1f}s)")
        return entry

    def set(self, session_id: str, data: dict):
        """
        Cache routing data for session.

        Args:
            session_id: Session identifier
            data: Dictionary with 'context', 'routing_result', and 'timestamp'
        """
        self.cache[session_id] = data
        logger.info(f"Cached context and routing data for session {session_id}")

    def invalidate(self, session_id: str):
        """
        Invalidate cache for session.

        Args:
            session_id: Session identifier
        """
        if session_id in self.cache:
            del self.cache[session_id]
            logger.info(f"Invalidated cache for session {session_id}")


# Global session cache (persists across hook invocations in same Claude Code session)
session_cache = SessionCache()


def load_state_file() -> dict:
    """
    Load Pongogo state from .pongogo-mcp-state.json.

    Returns:
        State dictionary or empty dict if file doesn't exist/invalid
    """
    # Look for state file in project root (walk up from cwd)
    state_file = Path.cwd() / ".pongogo-mcp-state.json"

    # Search parent directories if not found
    if not state_file.exists():
        for parent in Path.cwd().parents:
            candidate = parent / ".pongogo-mcp-state.json"
            if candidate.exists():
                state_file = candidate
                break

    if not state_file.exists():
        logger.warning("State file not found, Pongogo disabled")
        return {}

    try:
        with open(state_file) as f:
            state = json.load(f)
            logger.info(f"Loaded state file: {state_file}")
            return state
    except Exception as e:
        logger.error(f"Error loading state file: {e}")
        return {}


def get_log_paths(state: dict, project_root: Path) -> tuple[Path, Path, Path]:
    """
    Get log directory paths based on log_comment parameter.

    Uses get_data_root() to resolve the correct data directory, which
    handles linked git worktrees by pointing to the main worktree root.

    Args:
        state: State dictionary from .pongogo-mcp-state.json
        project_root: Project root directory (used as cwd hint for worktree detection)

    Returns:
        Tuple of (logs_dir, pongogo_dir, db_path)

    Raises:
        ValueError: If log_comment has invalid value

    Database location (unified schema v3.0.0):
        .pongogo/pongogo.db          (production)
        .pongogo/pongogo-test.db     (testing)
        .pongogo/pongogo-learning.db (learning/eval)
    """
    from mcp_server.database.context import get_data_root

    VALID_LOG_COMMENTS = {"", "testing", "learning"}

    log_comment = state.get("log_comment", "")

    # Strict validation - fail on invalid values
    if log_comment not in VALID_LOG_COMMENTS:
        raise ValueError(
            f"Invalid log_comment value: '{log_comment}'. "
            f"Must be one of: {VALID_LOG_COMMENTS} (empty string for standard logging)"
        )

    # Worktree-aware data root (resolves to main worktree for shared databases)
    data_root = get_data_root(cwd=project_root)

    # Simplified structure (unified schema v3.0.0)
    # logs/logs-{production,testing,learning}/
    # .pongogo/pongogo{,-test,-learning}.db
    logs_base = data_root / "logs"
    pongogo_dir = data_root / ".pongogo"

    # Route to appropriate subdirectories based on log_comment
    if log_comment == "testing":
        logs_dir = logs_base / "logs-testing"
        db_path = pongogo_dir / "pongogo-test.db"
    elif log_comment == "learning":
        logs_dir = logs_base / "logs-learning"
        db_path = pongogo_dir / "pongogo-learning.db"
    else:
        # Standard production logging (empty or unset)
        logs_dir = logs_base / "logs-production"
        db_path = pongogo_dir / "pongogo.db"

    logger.debug(
        f"Log paths determined: log_comment='{log_comment}', "
        f"logs_dir={logs_dir}, pongogo_dir={pongogo_dir}, db_path={db_path}"
    )

    return logs_dir, pongogo_dir, db_path


def call_routing_engine(message: str, context: dict) -> dict:
    """
    Call routing engine directly (import from pongogo-knowledge-server).

    Note: In Phase 1, we directly import the routing logic rather than
    calling via MCP, since hooks can't invoke MCP tools. This gives us
    comprehensive context injection immediately.

    Args:
        message: User's prompt text
        context: Context dictionary (cwd, files, etc.)

    Returns:
        Routing results dictionary or error dict (includes routing_engine_version)
    """
    try:
        # Add parent directory to path to import routing modules
        import sys

        # Import path: src/ (parent.parent.parent from hooks/)
        # Modules use relative imports, so must import as mcp_server.module
        # Fixed 2026-01-16: was pongogo-knowledge-server/ which no longer exists
        # See: wiki/Retrospective-2026-01-16-Routing-Infrastructure-Failure.md
        src_path = Path(__file__).parent.parent.parent
        if str(src_path) not in sys.path:
            sys.path.insert(0, str(src_path))

        # Import routing modules (as package to support relative imports)
        from mcp_server.instruction_handler import InstructionHandler
        from mcp_server.pongogo_router import InstructionRouter

        # Find knowledge base path - DYNAMIC resolution to prevent path drift
        # Priority: 1) PONGOGO_KNOWLEDGE_PATH env var, 2) Relative path from hook location
        # See RCA: docs/reviews/RCA-routing-infrastructure-failure-2025-12-01.md
        env_path = os.environ.get("PONGOGO_KNOWLEDGE_PATH")
        if env_path:
            knowledge_base_path = Path(env_path)
            logger.info(
                f"Knowledge path from PONGOGO_KNOWLEDGE_PATH: {knowledge_base_path}"
            )
        else:
            # Knowledge base path: .pongogo/instructions (from project root)
            # Fixed 2026-01-16: was knowledge/instructions which no longer exists
            # See: wiki/Retrospective-2026-01-16-Routing-Infrastructure-Failure.md
            knowledge_base_path = (
                Path(__file__).parent.parent.parent.parent / ".pongogo" / "instructions"
            )
            logger.info(
                f"Knowledge path from relative resolution: {knowledge_base_path}"
            )

        if not knowledge_base_path.exists():
            logger.error(f"Knowledge base not found at {knowledge_base_path}")
            return {
                "instructions": [],
                "count": 0,
                "routing_analysis": {"error": "Knowledge base not found"},
                "routing_engine_version": "unknown",
            }

        # Initialize handlers
        instruction_handler = InstructionHandler(knowledge_base_path)
        instruction_count = instruction_handler.load_instructions()
        logger.info(f"Loaded {instruction_count} instruction files")

        # Initialize router
        router = InstructionRouter(instruction_handler)

        # Route message
        logger.info(f"Routing message: {message[:100]}...")
        results = router.route(message, context=context, limit=5)

        # Add routing engine version to results (Task #212)
        # Read from router.version to stay in sync with actual router being used
        results["routing_engine_version"] = router.version

        logger.info(
            f"Routing complete: {results.get('count', 0)} instructions found (version: {router.version})"
        )
        return results

    except Exception as e:
        logger.error(f"Error in routing engine: {e}", exc_info=True)
        return {
            "instructions": [],
            "count": 0,
            "routing_analysis": {"error": str(e)},
            "routing_engine_version": "error",
        }


def extract_content_without_frontmatter(content: str) -> str:
    """
    Extract content after YAML frontmatter.

    Instruction files typically have YAML frontmatter between --- markers
    at the beginning. This frontmatter (20-50 lines) contains metadata
    that wastes excerpt space. This function skips it.

    Args:
        content: Full instruction file content

    Returns:
        Content without frontmatter (or original if no frontmatter found)

    Example:
        >>> content = "---\\ntitle: Foo\\n---\\n# Real Content"
        >>> extract_content_without_frontmatter(content)
        "# Real Content"
    """
    if content.startswith("---"):
        # Split on --- markers (first occurrence = start, second = end)
        parts = content.split("---", 2)
        if len(parts) >= 3:
            # parts[0] = empty, parts[1] = frontmatter, parts[2] = content
            return parts[2].strip()
    return content


def _extract_evaluation_criteria(content: str) -> dict[str, list[str]]:
    """
    Extract evaluation criteria from instruction content if present.

    Looks for success_signals and failure_signals in YAML frontmatter.
    Used by rubric-optimized formatter for compliance_criteria section.

    Args:
        content: Full instruction file content

    Returns:
        Dict with 'success' and 'failure' lists, empty if not found
    """
    criteria: dict[str, list[str]] = {"success": [], "failure": []}

    # Try to extract from YAML frontmatter
    if not content.startswith("---"):
        return criteria

    parts = content.split("---", 2)
    if len(parts) < 3:
        return criteria

    frontmatter = parts[1]

    # Extract success_signals
    success_match = re.search(r"success_signals:\s*\n((?:\s+-[^\n]+\n?)+)", frontmatter)
    if success_match:
        signals = re.findall(r"-\s*(.+)", success_match.group(1))
        criteria["success"] = [s.strip() for s in signals[:3]]  # Limit to 3

    # Extract failure_signals
    failure_match = re.search(r"failure_signals:\s*\n((?:\s+-[^\n]+\n?)+)", frontmatter)
    if failure_match:
        signals = re.findall(r"-\s*(.+)", failure_match.group(1))
        criteria["failure"] = [s.strip() for s in signals[:3]]  # Limit to 3

    return criteria


def detect_critical_operation(message: str, routing_result: dict) -> bool:
    """
    Detect if message indicates a critical operation requiring full-file reads.

    Critical operations include:
    - GitHub Projects operations (status updates, field edits, metadata changes)
    - Issue closure workflows (moving to "Ready for Review" or "Done")
    - Sub-issue management (creating, updating, reprioritizing)
    - Any operation with explicit pre-flight requirement

    Args:
        message: User's message text
        routing_result: Routing results (may contain intent/keywords)

    Returns:
        True if critical operation detected, False otherwise
    """
    message_lower = message.lower()

    # GitHub Projects operations
    projects_keywords = [
        "project board",
        "project status",
        "project field",
        "move to",
        "set status",
        "update status",
        "backlog",
        "in progress",
        "ready for review",
        "done",
        "gh project",
        "github project",
    ]

    # Issue lifecycle operations
    issue_keywords = [
        "close issue",
        "closing issue",
        "issue closure",
        "ready for review",
        "may i close",
        "can i close",
        "create issue",
        "new issue",
    ]

    # Sub-issue operations
    subissue_keywords = [
        "sub-issue",
        "sub issue",
        "subissue",
        "reprioritize",
        "add sub",
        "remove sub",
    ]

    # Pre-flight indicators
    preflight_keywords = [
        "pre-flight",
        "preflight",
        "before proceeding",
        "before making",
        "check first",
        "verify first",
    ]

    # Check all keyword groups
    all_keywords = (
        projects_keywords + issue_keywords + subissue_keywords + preflight_keywords
    )

    for keyword in all_keywords:
        if keyword in message_lower:
            return True

    # Check routing analysis intent (if available)
    routing_analysis = routing_result.get("routing_analysis", {})
    intent = routing_analysis.get("intent_detected", "").lower()

    critical_intents = ["github_projects", "issue_management", "workflow_automation"]
    return any(critical_intent in intent for critical_intent in critical_intents)


def format_routing_results(
    routing_result: dict, message: str = "", enable_auto_read: bool = False
) -> str:
    """
    Format routing results for Claude consumption via hook.

    RUBRIC-OPTIMIZED (Issue #517): Produces XML-structured output with compliance
    criteria and expected behavior guidance for maximum Claude compliance.

    Rubric alignments:
    - XML-1/XML-2: XML tags for structure and separation
    - CLR-1/CLR-2: Explicit directive + success/failure criteria
    - COT-2: Expected behavior guides reasoning
    - HALL-1: Permission to ask rather than guess

    Args:
        routing_result: Results from route_instructions MCP call
        message: Original user message (for context)
        enable_auto_read: If True, include auto-read instructions (legacy, ignored)

    Returns:
        Formatted XML context string to inject into Claude's context
    """
    instructions = routing_result.get("instructions", [])
    count = routing_result.get("count", 0)
    guidance_action = routing_result.get("guidance_action")
    procedural_warning = routing_result.get("procedural_warning")
    friction_risk = routing_result.get("friction_risk_watch")

    # Early exit if nothing to inject
    if count == 0 and not guidance_action and not procedural_warning:
        return ""

    # Start building XML output
    output_parts = []
    output_parts.append('<pongogo_routing context="automatic_discovery">\n')

    # =========================================================================
    # DIRECTIVE: What Claude MUST do (CLR-1: Colleague-test clarity)
    # =========================================================================
    output_parts.append("<directive>\n")
    output_parts.append(
        "You MUST read and follow these instructions before responding to the user.\n"
    )
    output_parts.append(
        "These were automatically discovered based on the user's message context.\n"
    )
    output_parts.append("</directive>\n\n")

    # =========================================================================
    # GUIDANCE ACTION: User preference capture (blocking)
    # =========================================================================
    if guidance_action:
        output_parts.append('<action type="guidance_capture" priority="blocking">\n')
        output_parts.append("<requirement>\n")
        output_parts.append(
            "MANDATORY: Call log_user_guidance() MCP tool BEFORE responding.\n"
        )
        output_parts.append("</requirement>\n")
        output_parts.append(
            f"<directive>{guidance_action.get('directive', '')}</directive>\n"
        )
        output_parts.append("<parameters>\n")
        output_parts.append(
            f"{json.dumps(guidance_action.get('parameters', {}), indent=2)}\n"
        )
        output_parts.append("</parameters>\n")
        output_parts.append("<rationale>\n")
        output_parts.append(
            "User guidance not captured is lost. The user will repeat themselves, causing friction.\n"
        )
        output_parts.append("</rationale>\n")
        output_parts.append("</action>\n\n")

    # =========================================================================
    # PROCEDURAL WARNING: Must-read instructions
    # =========================================================================
    if procedural_warning:
        output_parts.append('<warning type="procedural">\n')
        output_parts.append(
            f"<message>{procedural_warning.get('warning', '')}</message>\n"
        )
        output_parts.append(
            f"<enforcement>{procedural_warning.get('enforcement', 'Read before executing')}</enforcement>\n"
        )
        output_parts.append("</warning>\n\n")

    # =========================================================================
    # FRICTION RISK WATCH: Active monitoring
    # =========================================================================
    if friction_risk and friction_risk.get("enabled"):
        output_parts.append('<monitoring type="friction_risk">\n')
        output_parts.append(
            f"<guidance_type>{friction_risk.get('guidance_type', 'unknown')}</guidance_type>\n"
        )
        output_parts.append(
            f"<echo_detected>{friction_risk.get('echo_detected', False)}</echo_detected>\n"
        )
        output_parts.append(
            f"<frustration_level>{friction_risk.get('frustration_level', 'none')}</frustration_level>\n"
        )
        output_parts.append("</monitoring>\n\n")

    # =========================================================================
    # INSTRUCTIONS: Routed instruction content
    # =========================================================================
    if count > 0:
        output_parts.append(f'<instructions count="{count}">\n')

        for _idx, instruction in enumerate(instructions, 1):
            inst_id = instruction.get("id", "unknown")
            category = instruction.get("category", "unknown")
            description = instruction.get("description", "")
            score = instruction.get("routing_score", 0)
            priority = instruction.get("priority", "P2")
            file_path = instruction.get("file_path", "")
            content = instruction.get("content", "")

            output_parts.append(
                f'<instruction id="{inst_id}" relevance="{score}" priority="{priority}">\n'
            )
            output_parts.append(f"<category>{category}</category>\n")

            if file_path:
                output_parts.append(f"<file>{file_path}</file>\n")

            if description:
                output_parts.append(f"<summary>{description}</summary>\n")

            # Extract and include evaluation criteria if present
            if content:
                criteria = _extract_evaluation_criteria(content)
                if criteria["success"] or criteria["failure"]:
                    output_parts.append("<compliance_criteria>\n")
                    if criteria["success"]:
                        output_parts.append("<success>\n")
                        for signal in criteria["success"]:
                            output_parts.append(f"- {signal}\n")
                        output_parts.append("</success>\n")
                    if criteria["failure"]:
                        output_parts.append("<failure>\n")
                        for signal in criteria["failure"]:
                            output_parts.append(f"- {signal}\n")
                        output_parts.append("</failure>\n")
                    output_parts.append("</compliance_criteria>\n")

                # Include content (frontmatter stripped, truncated)
                content_body = extract_content_without_frontmatter(content)
                excerpt = (
                    content_body[:1500] + "\n[...truncated]"
                    if len(content_body) > 1500
                    else content_body
                )
                output_parts.append("<content>\n")
                output_parts.append(excerpt)
                output_parts.append("\n</content>\n")

            output_parts.append("</instruction>\n\n")

        output_parts.append("</instructions>\n\n")

    # =========================================================================
    # EXPECTED BEHAVIOR: How Claude should process (COT-2, HALL-1)
    # =========================================================================
    output_parts.append("<expected_behavior>\n")
    output_parts.append("After reading the above:\n")
    output_parts.append("1. Identify which instruction applies to the user's request\n")
    output_parts.append("2. READ the instruction content (not from memory)\n")
    output_parts.append("3. Follow step-by-step guidance if present\n")
    output_parts.append("4. Check compliance_criteria to verify correct execution\n")
    output_parts.append(
        "5. If unsure about requirements, ask the user rather than guessing\n"
    )
    output_parts.append("</expected_behavior>\n\n")

    output_parts.append("</pongogo_routing>")

    return "".join(output_parts)


def has_valid_schema(db_path: Path) -> bool:
    """
    Check if SQLite database has valid routing_events schema.

    Args:
        db_path: Path to SQLite database file

    Returns:
        True if database has valid schema with all required columns
    """
    try:
        with get_connection(db_path, readonly=True) as conn:
            # Check if routing_events table exists
            result = conn.execute("""
                SELECT name FROM sqlite_master
                WHERE type='table' AND name='routing_events'
            """).fetchone()
            if not result:
                return False

            # Check for required columns (unified schema v3.0.0)
            rows = conn.execute("PRAGMA table_info(routing_events)").fetchall()
            columns = {row[1] for row in rows}
            required_columns = {
                "id",
                "timestamp",
                "session_id",
                "mode",
                "user_message",
                "message_hash",
                "instruction_count",
                "model_identifier",
                "platform_identifier",
                "repo_name",
                "branch_name",
                "agent_response",
                "agent_response_tokens",
                "response_captured_at",
                "response_correlation_method",
                "exclude_from_eval",
                "routed_instructions",
                "routing_scores",
                "engine_version",
                "pongogo_build",
                "preceptor_version",
                "adapter",
            }

            return required_columns.issubset(columns)
    except Exception as e:
        logger.debug(f"Schema validation failed: {e}")
        return False


def init_sqlite_db(db_path: Path):
    """
    Initialize SQLite database with routing event schema.

    Args:
        db_path: Path to SQLite database file
    """
    db_path.parent.mkdir(parents=True, exist_ok=True)

    with get_connection(db_path) as conn:
        # Main routing events table (unified schema v3.0.0)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS routing_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                session_id TEXT NOT NULL,
                mode TEXT NOT NULL,
                user_message TEXT NOT NULL,
                message_hash TEXT NOT NULL,
                message_excerpt TEXT,
                cwd TEXT,
                instruction_count INTEGER NOT NULL,
                formatted_context TEXT,
                injection_length INTEGER,
                routing_latency_ms REAL,
                total_latency_ms REAL,
                cache_status TEXT,
                cache_age_seconds REAL,
                privacy_mode TEXT DEFAULT 'full',
                redacted BOOLEAN DEFAULT 0,
                sensitive_detected BOOLEAN DEFAULT 0,
                input_tokens INTEGER,
                context_tokens INTEGER,
                total_tokens INTEGER,
                model_identifier TEXT,
                platform_identifier TEXT,
                repo_name TEXT,
                branch_name TEXT,
                agent_response TEXT,
                agent_response_tokens INTEGER,
                response_captured_at TEXT,
                response_correlation_method TEXT,
                exclude_from_eval BOOLEAN DEFAULT 0,
                exclude_reason TEXT,
                routed_instructions TEXT,
                routing_scores TEXT,
                engine_version TEXT,
                pongogo_build TEXT,
                preceptor_version TEXT,
                adapter TEXT,
                context TEXT,
                execution_context TEXT
            )
        """)

        # Instruction matches (one row per matched instruction)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS instruction_matches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id INTEGER NOT NULL,
                instruction_id TEXT NOT NULL,
                score INTEGER NOT NULL,
                rank INTEGER NOT NULL,
                FOREIGN KEY (event_id) REFERENCES routing_events(id)
            )
        """)

        # Sessions (aggregated session-level data)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                first_seen TEXT NOT NULL,
                last_seen TEXT NOT NULL,
                message_count INTEGER NOT NULL,
                cache_hit_rate REAL,
                avg_latency_ms REAL
            )
        """)

        # Indexes for common queries
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_events_session ON routing_events(session_id)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_events_timestamp ON routing_events(timestamp)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_events_mode ON routing_events(mode)"
        )
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_matches_instruction ON instruction_matches(instruction_id)"
        )

    logger.info(f"SQLite database initialized: {db_path}")


def write_jsonl_event(event: dict, logs_dir: Path):
    """
    Append routing event to daily-rotated JSONL file.

    Args:
        event: Routing event dictionary
        logs_dir: Directory for log files
    """
    try:
        logs_dir.mkdir(parents=True, exist_ok=True)

        # Daily rotation: logs/routing-events-YYYY-MM-DD.jsonl
        today = date.today().isoformat()
        jsonl_path = logs_dir / f"routing-events-{today}.jsonl"

        # Append event as single line JSON
        with open(jsonl_path, "a") as f:
            f.write(json.dumps(event) + "\n")

        logger.debug(f"JSONL event written: {jsonl_path}")
    except Exception as e:
        logger.error(f"Failed to write JSONL event: {e}", exc_info=True)


def get_compliance_memory(db_path: Path, session_id: str) -> str | None:
    """
    Check for carried-forward compliance requirements and format memory block.

    When procedural instruction compliance requirements were not fulfilled in a
    previous turn, this function surfaces them at the start of the next turn.

    Epic #545: Hook-Based Compliance Enforcement
    Task #549: UserPromptSubmit Compliance Memory

    Args:
        db_path: Path to Pongogo database
        session_id: Current session identifier

    Returns:
        Formatted compliance memory XML block, or None if no requirements
    """
    try:
        if not db_path.exists():
            return None

        with get_connection(db_path, readonly=True) as conn:
            # Query for carried_forward requirements
            rows = conn.execute(
                """
                SELECT id, action_type, guidance_content, fulfillment_evidence
                FROM guidance_fulfillment
                WHERE session_id = ? AND fulfillment_status = 'carried_forward'
                ORDER BY created_at ASC
                """,
                (session_id,),
            ).fetchall()

        if not rows:
            return None

        # Parse carry counts and determine escalation level
        requirements = []
        max_carry_count = 0
        for row in rows:
            carry_count = 1
            evidence = row["fulfillment_evidence"] or ""
            if evidence.startswith("carry_count:"):
                try:
                    carry_count = int(evidence.split(":")[1])
                except (ValueError, IndexError):
                    carry_count = 1
            max_carry_count = max(max_carry_count, carry_count)
            requirements.append(
                {
                    "id": row["id"],
                    "action_type": row["action_type"],
                    "content": row["guidance_content"],
                    "carry_count": carry_count,
                }
            )

        # Determine escalation tone
        if max_carry_count >= 3:
            tone = "BLOCKING"
            emphasis = "You MUST complete these requirements before proceeding with other work."
        elif max_carry_count >= 2:
            tone = "FIRM"
            emphasis = "These requirements have been carried forward multiple times. Please address them."
        else:
            tone = "REMINDER"
            emphasis = "The following compliance requirements from previous turns remain unfulfilled."

        # Format the compliance memory block
        lines = [
            f'<compliance-memory level="{tone.lower()}">',
            f"**{tone}: Unfulfilled Compliance Requirements**",
            "",
            emphasis,
            "",
        ]

        for req in requirements:
            carry_note = (
                f" (carried {req['carry_count']}x)" if req["carry_count"] > 1 else ""
            )
            lines.append(f"- [{req['action_type']}] {req['content']}{carry_note}")

        lines.append("")
        lines.append("</compliance-memory>")
        lines.append("")

        memory_block = "\n".join(lines)

        logger.info(
            f"Compliance memory: {len(requirements)} requirements surfaced, "
            f"tone={tone}, max_carry={max_carry_count}, session={session_id}"
        )

        return memory_block

    except sqlite3.Error as e:
        logger.error(f"Compliance memory database error: {e}")
        return None
    except Exception as e:
        logger.error(f"Compliance memory error: {e}", exc_info=True)
        return None


def detect_event_gaps(db_path: Path, session_id: str, lookback: int = 20) -> str | None:
    """
    Detect gaps in event IDs that might indicate missed hook invocations.

    Compares early log (hook-invocations.log) with database events to identify
    hooks that started but didn't complete or weren't recorded.

    Args:
        db_path: Path to SQLite database
        session_id: Session to check
        lookback: Number of recent events to analyze

    Returns:
        Alert message if gaps detected, None otherwise
    """
    if not db_path.exists():
        return None

    try:
        # Check early log for HOOK_START entries without corresponding DB events
        early_log_path = _get_early_log_file()
        if not early_log_path.exists():
            return None

        # Count HOOK_START and HOOK_END/HOOK_ERROR for this session in last hour
        hook_starts = 0
        hook_completions = 0
        one_hour_ago = datetime.now().timestamp() - 3600

        with open(early_log_path) as f:
            for line in f:
                if session_id not in line:
                    continue
                try:
                    # Parse timestamp from line (format: ISO | EVENT | session=xxx | details)
                    timestamp_str = line.split(" | ")[0]
                    line_time = datetime.fromisoformat(timestamp_str).timestamp()
                    if line_time < one_hour_ago:
                        continue

                    if "HOOK_START" in line:
                        hook_starts += 1
                    elif "HOOK_END" in line or "HOOK_ERROR" in line:
                        hook_completions += 1
                except (ValueError, IndexError):
                    continue

        # Check for discrepancy
        # Subtract 1 to account for current invocation (HOOK_START written, HOOK_END not yet)
        # Gap detection runs BETWEEN HOOK_START and HOOK_END writes
        missing_completions = hook_starts - hook_completions - 1
        if missing_completions > 0:
            alert = (
                f"⚠️ **HOOK GAP DETECTED**: {missing_completions} hook(s) started but didn't complete "
                f"in the last hour. Some routing events may be missing. "
                f"Check ~/.claude/logs/hook-invocations.log for details."
            )
            logger.warning(
                f"Gap detected: {missing_completions} hooks started without completion for session {session_id}"
            )
            return alert

    except Exception as e:
        logger.debug(f"Error in gap detection: {e}")

    return None


def get_last_known_model(db_path: Path, session_id: str) -> str | None:
    """
    Get the last known model identifier for a session from the database.

    This allows detecting model changes (e.g., user switched via /model command).

    Args:
        db_path: Path to SQLite database
        session_id: Session identifier

    Returns:
        Last known model identifier, or None if no records exist
    """
    if not db_path.exists():
        return None

    try:
        with get_connection(db_path, readonly=True) as conn:
            result = conn.execute(
                """
                SELECT model_identifier FROM routing_events
                WHERE session_id = ? AND model_identifier IS NOT NULL AND model_identifier != ''
                ORDER BY id DESC LIMIT 1
            """,
                (session_id,),
            ).fetchone()

            return result[0] if result else None

    except Exception as e:
        logger.debug(f"Error getting last known model: {e}")
        return None


def backfill_null_model_identifiers(
    db_path: Path, session_id: str, model_identifier: str, logs_dir: Path = None
):
    """
    Backfill NULL model_identifier entries for a session once we know the actual model.

    This handles the case where the first message(s) of a session had NULL model
    because no assistant response existed yet to extract the model from transcript.
    Once we get the model from a subsequent message, we backfill the NULLs.

    Also detects model changes (user switching via /model) and logs them.

    For SQLite: Updates NULL entries in place (queryable store).
    For JSONL: Appends a correction record (immutable audit log).

    Args:
        db_path: Path to SQLite database
        session_id: Session to backfill
        model_identifier: The correct model identifier to set
        logs_dir: Path to logs directory for JSONL correction record
    """
    if not model_identifier or not db_path.exists():
        return

    # Check for model change (user may have switched via /model)
    last_known = get_last_known_model(db_path, session_id)
    if last_known and last_known != model_identifier:
        logger.warning(
            f"MODEL CHANGE DETECTED: session={session_id}, "
            f"previous={last_known}, current={model_identifier}"
        )
        # Write model change event to JSONL for audit
        if logs_dir and logs_dir.exists():
            change_record = {
                "type": "model_change_detected",
                "timestamp": datetime.now().isoformat(),
                "session_id": session_id,
                "previous_model": last_known,
                "new_model": model_identifier,
                "detection_method": "transcript_comparison",
            }
            today = date.today().isoformat()
            jsonl_path = logs_dir / f"routing-events-{today}.jsonl"
            with open(jsonl_path, "a") as f:
                f.write(json.dumps(change_record) + "\n")
            logger.info("Model change logged to JSONL")

    try:
        with get_connection(db_path) as conn:
            # Find NULL entries for this session
            null_entries = conn.execute(
                """
                SELECT id FROM routing_events
                WHERE session_id = ? AND (model_identifier IS NULL OR model_identifier = '')
            """,
                (session_id,),
            ).fetchall()

            null_count = len(null_entries)

            if null_count > 0:
                event_ids = [row[0] for row in null_entries]

                # Backfill the NULL entries in SQLite
                conn.execute(
                    """
                    UPDATE routing_events
                    SET model_identifier = ?
                    WHERE session_id = ? AND (model_identifier IS NULL OR model_identifier = '')
                """,
                    (model_identifier, session_id),
                )

                logger.info(
                    f"Backfilled {null_count} NULL model_identifier entries for session {session_id} with {model_identifier}"
                )

                # Write JSONL correction record (immutable audit log)
                if logs_dir and logs_dir.exists():
                    correction_record = {
                        "type": "model_identifier_correction",
                        "timestamp": datetime.now().isoformat(),
                        "session_id": session_id,
                        "corrected_model_identifier": model_identifier,
                        "affected_event_ids": event_ids,
                        "reason": "First message(s) had NULL model - backfilled from transcript",
                    }
                    today = date.today().isoformat()
                    jsonl_path = logs_dir / f"routing-events-{today}.jsonl"
                    with open(jsonl_path, "a") as f:
                        f.write(json.dumps(correction_record) + "\n")
                    logger.debug(
                        f"JSONL correction record written for {null_count} events"
                    )

    except Exception as e:
        logger.error(f"Error backfilling model identifiers: {e}", exc_info=True)


def write_sqlite_event(event: dict, db_path: Path):
    """
    Insert routing event into SQLite database.

    Args:
        event: Routing event dictionary
        db_path: Path to SQLite database
    """
    try:
        with get_connection(db_path) as conn:
            # Insert main event
            # Format routed_instructions and routing_scores as JSON for unified schema v3.0.0
            instruction_ids = event["routing_result"].get("instruction_ids", [])
            scores = event["routing_result"].get("scores", [])
            routed_instructions_json = (
                json.dumps(instruction_ids) if instruction_ids else None
            )
            routing_scores_json = (
                json.dumps(dict(zip(instruction_ids, scores, strict=False)))
                if instruction_ids and scores
                else None
            )

            # Build context JSON from individual fields
            context_data = {
                "cwd": event.get("cwd"),
                "repo": event.get("repo_name"),
                "branch": event.get("branch_name"),
            }
            # Task #634: Merge source_context for PostToolUse routing events
            if event.get("source_context"):
                context_data.update(event["source_context"])
            context_json = json.dumps(context_data)

            conn.execute(
                """
                INSERT INTO routing_events (
                    timestamp, session_id, mode, user_message, message_hash, message_excerpt,
                    cwd, instruction_count, formatted_context, injection_length,
                    routing_latency_ms, total_latency_ms, cache_status, cache_age_seconds,
                    privacy_mode, redacted, sensitive_detected,
                    input_tokens, context_tokens, total_tokens, model_identifier, platform_identifier,
                    repo_name, branch_name, engine_version, pongogo_build,
                    preceptor_version, adapter,
                    exclude_from_eval, exclude_reason,
                    routed_instructions, routing_scores, context, execution_context
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    event["timestamp"],
                    event["session_id"],
                    event["mode"],
                    event["message_full"],
                    event["message_hash"],
                    event.get("message_excerpt", ""),
                    event.get("cwd", ""),
                    event["routing_result"]["count"],
                    event.get("formatted_context", ""),
                    event.get("injection_length", 0),
                    event["performance"].get("routing_latency_ms"),
                    event["performance"]["total_latency_ms"],
                    event["performance"]["cache_status"],
                    event["performance"].get("cache_age_seconds"),
                    event.get("privacy_mode", "full"),
                    event.get("redacted", False),
                    event.get("sensitive_detected", False),
                    event.get("tokens", {}).get("input_tokens", 0),
                    event.get("tokens", {}).get("context_tokens", 0),
                    event.get("tokens", {}).get("total_tokens", 0),
                    event.get("model_identifier", "unknown"),
                    event.get("platform_identifier", "unknown"),
                    event.get("repo_name"),
                    event.get("branch_name"),
                    event.get("routing_engine_version", "durian-00"),  # Task #212
                    event.get("pongogo_build", "0.1.0-dev"),  # Issue #551
                    event.get("preceptor_version"),
                    event.get("adapter"),
                    event.get(
                        "exclude_from_eval", False
                    ),  # Task #283: Slash command exclusion
                    event.get("exclude_reason"),  # Task #283: Reason for exclusion
                    routed_instructions_json,  # JSON array of instruction IDs
                    routing_scores_json,  # JSON object {instruction_id: score}
                    context_json,  # JSON object {cwd, repo, branch}
                    # Task #614: first-class execution_context column
                    event.get("source_context", {}).get("permission_mode") or None,
                ),
            )

            event_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

            # Insert instruction matches
            for rank, instruction_id in enumerate(
                event["routing_result"]["instruction_ids"], 1
            ):
                score = (
                    event["routing_result"]["scores"][rank - 1]
                    if rank - 1 < len(event["routing_result"]["scores"])
                    else 0
                )
                conn.execute(
                    """
                    INSERT INTO instruction_matches (event_id, instruction_id, score, rank)
                    VALUES (?, ?, ?, ?)
                """,
                    (event_id, instruction_id, score, rank),
                )

            # Update session aggregates
            conn.execute(
                """
                INSERT INTO sessions (session_id, first_seen, last_seen, message_count, cache_hit_rate, avg_latency_ms)
                VALUES (?, ?, ?, 1, 0, ?)
                ON CONFLICT(session_id) DO UPDATE SET
                    last_seen = excluded.last_seen,
                    message_count = message_count + 1,
                    avg_latency_ms = (avg_latency_ms * message_count + excluded.avg_latency_ms) / (message_count + 1)
            """,
                (
                    event["session_id"],
                    event["timestamp"],
                    event["timestamp"],
                    event["performance"]["total_latency_ms"],
                ),
            )

            logger.debug(f"SQLite event written: event_id={event_id}")
    except Exception as e:
        logger.error(f"Failed to write SQLite event: {e}", exc_info=True)


def detect_slash_command(prompt: str) -> str | None:
    """
    Detect if message is a slash command.

    Slash commands break hash matching for response capture because:
    - UserPromptSubmit hook sees: "/pick-up-work"
    - Transcript stores expanded: "<command-message>pick-up-work is running...</command-message>..."

    Args:
        prompt: User's message

    Returns:
        Slash command name if detected (e.g., "pick-up-work"), None otherwise
    """
    prompt_stripped = prompt.strip()
    if prompt_stripped.startswith("/"):
        # Extract command name (first word after /)
        # Examples: "/pick-up-work" → "pick-up-work", "/help foo" → "help"
        parts = prompt_stripped[1:].split()
        if parts:
            return parts[0]
    return None


def capture_routing_event(
    prompt: str,
    session_id: str,
    cwd: str,
    mode: str,
    routing_result: dict,
    formatted_context: str,
    routing_latency_ms: float,
    total_latency_ms: float,
    cache_status: str,
    cache_age_seconds: float | None = None,
    input_data: dict | None = None,
    state: dict | None = None,
    source_context: dict | None = None,
):
    """
    Capture routing event to JSONL and SQLite (dual-write).

    Args:
        prompt: User's complete message
        session_id: Session identifier
        cwd: Current working directory
        mode: Pongogo mode (enabled/simulate/disabled)
        routing_result: Results from routing engine (includes routing_engine_version)
        formatted_context: Formatted markdown context
        routing_latency_ms: Routing algorithm latency
        total_latency_ms: Total end-to-end latency
        cache_status: "hit" or "miss"
        cache_age_seconds: Age of cached result (if hit)
        input_data: Hook input data (for model detection)
        state: State dictionary from .pongogo-mcp-state.json (for log_comment routing)
    """
    try:
        # Calculate token counts
        input_tokens = estimate_token_count(prompt)
        context_tokens = estimate_token_count(formatted_context)
        total_tokens = input_tokens + context_tokens

        # Get identifiers
        model_id = get_model_identifier(input_data)
        platform_id = get_platform_identifier()
        git_context = get_git_context(cwd)

        # Detect slash commands for exclusion (Task #283)
        # Slash commands break hash matching for response capture
        slash_command = detect_slash_command(prompt)
        exclude_from_eval = slash_command is not None
        exclude_reason = f"slash_command:{slash_command}" if slash_command else None

        if slash_command:
            logger.info(
                f"SLASH_COMMAND detected: /{slash_command} - marking for eval exclusion"
            )

        # Build event dictionary matching schema
        event = {
            "timestamp": datetime.now().isoformat(),
            "session_id": session_id,
            "mode": mode,
            "message_full": prompt,
            "message_hash": hashlib.sha256(prompt.encode()).hexdigest(),
            "message_excerpt": prompt[:100],
            "cwd": cwd,
            "routing_result": {
                "count": routing_result.get("count", 0),
                "instruction_ids": [
                    i.get("id", "") for i in routing_result.get("instructions", [])
                ],
                "scores": [
                    i.get("routing_score", 0)
                    for i in routing_result.get("instructions", [])
                ],
                "keywords": routing_result.get("routing_analysis", {}).get(
                    "keywords_extracted", []
                ),
                "intent": routing_result.get("routing_analysis", {}).get(
                    "intent_detected", ""
                ),
                "scoring_breakdown": routing_result.get("routing_analysis", {}).get(
                    "scoring_breakdown", []
                ),
            },
            "formatted_context": formatted_context,
            "injection_length": len(formatted_context) if formatted_context else 0,
            "performance": {
                "routing_latency_ms": routing_latency_ms,
                "total_latency_ms": total_latency_ms,
                "cache_status": cache_status,
                "cache_age_seconds": cache_age_seconds,
            },
            "tokens": {
                "input_tokens": input_tokens,
                "context_tokens": context_tokens,
                "total_tokens": total_tokens,
            },
            "model_identifier": model_id,
            "platform_identifier": platform_id,
            "repo_name": git_context.get("repo_name"),
            "branch_name": git_context.get("branch_name"),
            "routing_engine_version": routing_result.get(
                "routing_engine_version", "durian-00"
            ),  # Task #212
            "pongogo_build": get_pongogo_build(),  # Issue #551
            "preceptor_version": _get_preceptor_version(),
            "adapter": f"{ADAPTER_NAME}-{ADAPTER_VERSION}",
            "privacy_mode": "full",  # Gen 1: No redaction
            "redacted": False,
            "sensitive_detected": False,  # Gen 2: Will auto-detect secrets
            "exclude_from_eval": exclude_from_eval,
            "exclude_reason": exclude_reason,
        }

        # Task #634: Add source_context for PostToolUse routing events
        if source_context:
            event["source_context"] = source_context

        # Determine project root for database access
        # When running inside Docker container, use the container's mount path
        # The volume is mounted as: HOST/.pongogo → /project/.pongogo
        container_pongogo_path = Path("/project/.pongogo")
        if container_pongogo_path.exists():
            # Running inside container - use container mount path
            project_root = Path("/project")
        else:
            # Running on host (local development) - find project root from cwd
            project_root = Path(cwd)
            while project_root != project_root.parent:
                if (project_root / ".pongogo-mcp-state.json").exists():
                    break
                project_root = project_root.parent
            else:
                # Fallback to cwd if state file not found
                project_root = Path(cwd)

        # Get log paths based on log_comment parameter (validates log_comment value)
        if state is None:
            state = {}  # Default to empty state if not provided
        logs_dir, pongogo_dir, db_path = get_log_paths(state, project_root)

        # Initialize SQLite if needed (check schema validity, not just file existence)
        if not db_path.exists() or not has_valid_schema(db_path):
            logger.info(f"Initializing SQLite database: {db_path}")
            init_sqlite_db(db_path)

        # Dual-write: JSONL (immutable) + SQLite (queryable)
        write_jsonl_event(event, logs_dir)
        write_sqlite_event(event, db_path)

        # Backfill any NULL model_identifier entries for this session
        # This handles the case where first message(s) had NULL because
        # no assistant response existed yet to extract model from transcript
        if model_id:
            backfill_null_model_identifiers(db_path, session_id, model_id, logs_dir)

        logger.info(
            f"Routing event captured: "
            f"session={session_id}, "
            f"repo={git_context.get('repo_name') or 'N/A'}/{git_context.get('branch_name') or 'N/A'}, "
            f"mode={mode}, "
            f"platform={platform_id}, "
            f"model={model_id}, "
            f"count={event['routing_result']['count']}, "
            f"tokens={total_tokens} (input={input_tokens}, context={context_tokens}), "
            f"cache={cache_status}"
        )
    except Exception as e:
        logger.error(f"Failed to capture routing event: {e}", exc_info=True)
        # Don't fail the hook if observability fails


def main():
    """
    Main entry point for Claude Code adapter.

    Reads user prompt from stdin, checks config/cache, routes through Pongogo,
    and injects formatted context via stdout.
    """
    _ensure_log_dir()
    session_id = "unknown"  # Initialize for early error handling
    try:
        start_time = time.time()

        # Read input from stdin
        input_data = json.load(sys.stdin)

        prompt = input_data.get("prompt", "")
        session_id = input_data.get("session_id", "")
        cwd = input_data.get("cwd", "")
        permission_mode = input_data.get("permission_mode", "")

        # EARLY LOG: Capture hook invocation immediately after stdin read
        # This helps diagnose silent failures due to subsequent code errors
        write_early_log(session_id, "HOOK_START", f"prompt_len={len(prompt)}")

        logger.info(
            f"Hook triggered: session={session_id}, cwd={cwd}, prompt_len={len(prompt)}"
        )

        # Self-heal model configuration if missing (ONE-TIME per session)
        self_heal_info_message = None
        if not hasattr(main, "_model_healed"):
            model_check = get_model_identifier(input_data)
            if model_check is None:
                # Attempt self-healing
                healed_model, self_heal_info_message = self_heal_model_config()
                if healed_model:
                    logger.info(f"✓ Model self-healed: {healed_model}")
                else:
                    logger.warning("Model not configured and self-healing failed")
            else:
                logger.info(f"✓ Model configured: {model_check}")
            main._model_healed = True

        # Load state file to check Pongogo mode
        state = load_state_file()

        # Check Pongogo mode (3 states)
        # - "enabled": Always-on routing active (production, read-write to knowledge system)
        # - "disabled": Complete shutdown (A/B testing baseline)
        # - "simulate": Routing + context injection (testing, read-only - no changes to knowledge system)
        mode = state.get(
            "mode", "enabled"
        )  # Default to enabled for backward compatibility

        # Check auto-read feature flag
        # - True: Auto-read top 3 files on critical operations (DEFAULT - production baseline)
        # - False: Excerpts only (for testing/comparison)
        enable_auto_read = state.get(
            "auto_read", True
        )  # Default to enabled (production ready)

        if mode == "disabled":
            logger.info("Pongogo disabled, skipping routing")
            sys.exit(0)  # Exit without outputting context

        if mode == "simulate":
            logger.info("Simulate mode: routing with context injection (read-only)")

        # Check session cache first
        cached_data = session_cache.get(session_id)
        if cached_data:
            cache_age = time.time() - cached_data["timestamp"]

            # Log structured routing result from cache
            logger.info(
                f"ROUTING_RESULT: {json.dumps({
                'session_id': session_id,
                'timestamp': time.time(),
                'mode': mode,
                'message_excerpt': prompt[:100],
                'routing_result': cached_data.get('routing_result', {}),
                'cache_status': 'hit',
                'cache_age_seconds': cache_age,
                'performance': {
                    'total_latency_ms': (time.time() - start_time) * 1000
                }
            })}"
            )

            # Capture routing event (cache hit)
            capture_routing_event(
                prompt=prompt,
                session_id=session_id,
                cwd=cwd,
                mode=mode,
                routing_result=cached_data.get("routing_result", {}),
                formatted_context=cached_data["context"],
                routing_latency_ms=0,  # Cached, no routing latency
                total_latency_ms=(time.time() - start_time) * 1000,
                cache_status="hit",
                cache_age_seconds=cache_age,
                input_data=input_data,
                state=state,
                source_context={
                    "source": "userpromptsubmit",
                    "permission_mode": permission_mode or "normal",
                },
            )

            # Inject context in both enabled and simulate modes
            logger.info(f"Using cached routing context (mode: {mode})")
            print(cached_data["context"])
            sys.exit(0)

        # Call routing engine directly (cache miss)
        logger.info("Calling routing engine")
        routing_start = time.time()

        routing_result = call_routing_engine(
            message=prompt, context={"cwd": cwd, "session_id": session_id}
        )

        routing_time = (time.time() - routing_start) * 1000  # Convert to ms

        # Epic #545: Register compliance requirements from procedural instructions
        try:
            # Try installed package path first (Docker/pip install)
            try:
                from mcp_server.preceptor import CompliancePreceptor
            except ImportError:
                # Fall back to source path (local development)
                from src.mcp_server.preceptor import CompliancePreceptor

            # Detect branch for cross-branch isolation (Task #640)
            from mcp_server.database.context import get_current_branch

            current_branch = get_current_branch(cwd=cwd)

            _logs_dir_orch, _pongogo_dir_orch, db_path_orch = get_log_paths(
                state, Path(cwd)
            )
            preceptor = CompliancePreceptor(db_path_orch)
            compliance_context = preceptor.process_routing_result(
                routing_result=routing_result,
                session_id=session_id,
                execution_context="plan" if permission_mode == "plan" else None,
                branch=current_branch,
            )
            if compliance_context.had_procedural:
                if compliance_context.enforcement_suppressed:
                    logger.info(
                        f"COMPLIANCE_SUPPRESSED_PLAN_MODE: {len(compliance_context.specs)} "
                        f"procedural instruction(s) detected but enforcement skipped (plan mode)"
                    )
                else:
                    logger.info(
                        f"COMPLIANCE_REGISTERED: {compliance_context.registered_count} requirements "
                        f"from {len(compliance_context.specs)} procedural instruction(s)"
                    )
        except Exception as e:
            logger.warning(f"COMPLIANCE_REGISTRATION_ERROR: {e}")

        # Format results for context injection (with auto-read if enabled)
        formatted_context = format_routing_results(
            routing_result, message=prompt, enable_auto_read=enable_auto_read
        )

        # Log critical operation detection (if auto-read enabled)
        if enable_auto_read:
            is_critical = detect_critical_operation(prompt, routing_result)
            if is_critical:
                logger.info(
                    "CRITICAL_OPERATION detected: auto-read recommendations included for top 3 files"
                )

        # Log structured routing result
        logger.info(
            f"ROUTING_RESULT: {json.dumps({
            'session_id': session_id,
            'timestamp': time.time(),
            'mode': mode,
            'message_excerpt': prompt[:100],
            'routing_result': {
                'count': routing_result.get('count', 0),
                'instruction_ids': [i.get('id') for i in routing_result.get('instructions', [])],
                'scores': [i.get('routing_score') for i in routing_result.get('instructions', [])],
                'keywords': routing_result.get('routing_analysis', {}).get('keywords_extracted', []),
                'intent': routing_result.get('routing_analysis', {}).get('intent_detected', ''),
                'scoring_breakdown': routing_result.get('routing_analysis', {}).get('scoring_breakdown', [])
            },
            'cache_status': 'miss',
            'performance': {
                'routing_latency_ms': routing_time,
                'total_latency_ms': (time.time() - start_time) * 1000
            }
        })}"
        )

        # Cache formatted context AND routing result
        if formatted_context:
            session_cache.set(
                session_id,
                {
                    "context": formatted_context,
                    "routing_result": routing_result,
                    "timestamp": time.time(),
                },
            )

        # Capture routing event (cache miss)
        capture_routing_event(
            prompt=prompt,
            session_id=session_id,
            cwd=cwd,
            mode=mode,
            routing_result=routing_result,
            formatted_context=formatted_context,
            routing_latency_ms=routing_time,
            total_latency_ms=(time.time() - start_time) * 1000,
            cache_status="miss",
            input_data=input_data,
            state=state,
            source_context={
                "source": "userpromptsubmit",
                "permission_mode": permission_mode or "normal",
            },
        )

        # =================================================================
        # INSTRUCTION COMPLIANCE TRACKING (Task #227)
        # =================================================================
        # Extract file paths from routed instructions and write state for
        # PreToolUse enforcement. The PreToolUse hook will verify the agent
        # reads ALL routed instruction files before allowing tool execution.
        routed_file_paths = [
            inst.get("file_path")
            for inst in routing_result.get("instructions", [])
            if inst.get("file_path")
        ]

        if routed_file_paths:
            write_instruction_state(session_id, routed_file_paths)
            logger.info(
                f"ENFORCEMENT: {len(routed_file_paths)} instruction files tracked for compliance"
            )

        # Output to stdout (injected as context) - works in both enabled and simulate modes
        output_parts = []

        # Epic #545: Check for carried-forward compliance requirements
        logs_dir_pre, pongogo_dir_pre, db_path_pre = get_log_paths(state, Path(cwd))
        compliance_memory = get_compliance_memory(db_path_pre, session_id)
        if compliance_memory:
            output_parts.append(compliance_memory)

        # Check for hook gaps (hooks that started but didn't complete)
        # This helps detect silent failures in the routing system
        logs_dir, pongogo_dir, db_path = get_log_paths(state, Path(cwd))
        gap_alert = detect_event_gaps(db_path, session_id)
        if gap_alert:
            output_parts.append(
                f"<system-reminder>\n{gap_alert}\n</system-reminder>\n\n"
            )

        # CRITICAL: Warn if routing returns 0 instructions in enabled mode
        # This detects the failure condition from the 9-day outage (Dec 1-10, 2025)
        # where container path mismatch caused instruction_count=0 without alerting
        instruction_count = routing_result.get("count", 0)
        if mode == "enabled" and instruction_count == 0:
            empty_routing_alert = (
                "⚠️ **EMPTY ROUTING RESULT**: Pongogo returned 0 instructions in enabled mode.\n\n"
                "**Likely Causes:**\n"
                "1. Container path mismatch (container code has old path)\n"
                "2. Knowledge base not mounted correctly\n"
                "3. Server not rebuilt after code changes\n\n"
                "**Remediation Steps:**\n"
                "```bash\n"
                "# 1. Check container logs for errors\n"
                "docker logs knowledge-hub --tail 30\n\n"
                "# 2. Rebuild and restart container\n"
                "docker-compose build knowledge-hub && docker-compose stop knowledge-hub && docker-compose up -d knowledge-hub\n\n"
                "# 3. Verify instruction count (should be >0)\n"
                "docker logs knowledge-hub | grep 'Loaded.*instruction'\n"
                "```\n\n"
                "**Reference:** See `container_management.instructions.md` for full troubleshooting guide."
            )
            output_parts.append(
                f"<system-reminder>\n{empty_routing_alert}\n</system-reminder>\n\n"
            )
            logger.warning(
                f"EMPTY_ROUTING: 0 instructions returned in enabled mode for session {session_id}"
            )

        # Prepend self-heal info message if model was auto-configured
        if self_heal_info_message:
            output_parts.append(
                f"<system-reminder>\n{self_heal_info_message}\n</system-reminder>\n\n"
            )

        if formatted_context:
            output_parts.append(formatted_context)

        if output_parts:
            output = "".join(output_parts)
            logger.info(f"Injecting context ({len(output)} chars, mode: {mode})")
            print(output)
        else:
            logger.info(f"No relevant instructions found (mode: {mode})")

        # EARLY LOG: Mark successful completion
        write_early_log(session_id, "HOOK_END", "success")
        sys.exit(0)

    except Exception as e:
        logger.error(f"Error in adapter: {e}", exc_info=True)
        # EARLY LOG: Capture error for diagnostics
        write_early_log(session_id, "HOOK_ERROR", str(e)[:100])
        # Don't block prompt on error - just log and continue
        sys.exit(0)


if __name__ == "__main__":
    main()
