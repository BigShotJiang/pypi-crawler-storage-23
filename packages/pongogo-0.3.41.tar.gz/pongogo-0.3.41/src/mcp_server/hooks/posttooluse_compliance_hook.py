#!/usr/bin/env python3
"""
PostToolUse Compliance Verification Hook

Fires after every tool call to check if it satisfies a pending compliance
requirement. Updates fulfillment state in the database.

Architecture:
    Tool Call Complete → PostToolUse Hook → This Script →
        [Check Pending Requirements] → [Evaluate Fulfillment] →
        [Update Database] → Exit (silent)

Usage:
    Configured in .claude/settings.local.json as PostToolUse hook:
    {
      "hooks": {
        "PostToolUse": [{
          "matcher": "Read",
          "hooks": [{"type": "command", "command": "/path/to/posttooluse_compliance_hook.py"}]
        }]
      }
    }

Input:
    Receives JSON via stdin with:
    - session_id: Current session identifier
    - tool_name: Name of the tool that was called
    - tool_input: Parameters passed to the tool
    - tool_response: Result from the tool
    - transcript_path: Path to conversation JSONL file
    - hook_event_name: "PostToolUse"

Output:
    Prints nothing (silent operation - state tracking only)

Exit Codes:
    0: Success (fulfillment checked and updated)
    1: Error (logged, doesn't block)

Epic #545: Hook-Based Compliance Enforcement
Task #547: PostToolUse Verification Hook
"""

import json
import logging
import sqlite3
import sys
import time
from datetime import datetime
from pathlib import Path

# Ensure mcp_server package is importable when run as standalone hook script.
# Hooks are invoked directly by Claude Code, so src/ must be on sys.path.
_src_path = str(Path(__file__).parent.parent.parent)
if _src_path not in sys.path:
    sys.path.insert(0, _src_path)

from mcp_server.database.connection import get_connection

# Configure logging to file (not stdout - stdout would inject context)
# Lazy initialization to avoid side effects at import time (CI test environments)
_log_initialized = False
logger = logging.getLogger(__name__)


def _get_log_dir() -> Path:
    """Get the appropriate log directory, worktree-aware."""
    try:
        from mcp_server.database.context import get_data_root

        return get_data_root() / ".pongogo" / "logs"
    except ImportError:
        import os

        project_root = os.environ.get("PONGOGO_PROJECT_ROOT")
        if project_root:
            return Path(project_root) / ".pongogo" / "logs"
        return Path.home() / ".claude" / "logs"


def _ensure_log_dir(session_id: str = "", branch: str = ""):
    """Ensure log directory exists and configure dual logging. Called lazily on first use."""
    global _log_initialized
    if _log_initialized:
        return

    try:
        from mcp_server.hooks.logging_utils import setup_dual_logging

        log_dir = _get_log_dir()
        setup_dual_logging(
            log_dir=log_dir,
            hook_name="posttooluse-compliance",
            session_id=session_id,
            branch=branch,
        )
    except ImportError:
        log_dir = _get_log_dir()
        try:
            log_dir.mkdir(parents=True, exist_ok=True)
            logging.basicConfig(
                filename=log_dir / "posttooluse-compliance.log",
                level=logging.INFO,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
        except (PermissionError, OSError):
            logging.basicConfig(
                stream=sys.stderr,
                level=logging.WARNING,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
    _log_initialized = True


def get_db_path() -> Path | None:
    """Find the Pongogo database path.

    Search order:
    1. get_data_root() — worktree-aware (resolves to main worktree in linked worktrees)
    2. User home directory fallback
    """
    from mcp_server.database.context import get_data_root

    # Worktree-aware data root (handles PONGOGO_PROJECT_ROOT, linked worktrees, cwd)
    data_root = get_data_root()
    data_db = data_root / ".pongogo" / "pongogo.db"
    if data_db.exists():
        return data_db

    # Fall back to user-level
    user_db = Path.home() / ".pongogo" / "pongogo.db"
    if user_db.exists():
        return user_db

    return None


def get_pending_requirements(
    db_path: Path, session_id: str, branch: str | None = None
) -> list[dict]:
    """Query guidance_fulfillment for pending requirements in this session.

    Branch filtering (Task #640): When branch is provided, returns only rows
    matching the current branch OR rows with NULL branch (backward compat).
    """
    try:
        with get_connection(db_path, readonly=True) as conn:
            cursor = conn.execute(
                """
                SELECT id, guidance_type, guidance_content, action_type,
                       fulfillment_status, session_id, required_tool,
                       enforcement_phase, pattern
                FROM guidance_fulfillment
                WHERE session_id = ?
                AND (branch = ? OR branch IS NULL)
                AND fulfillment_status IN ('pending', 'in_progress', 'carried_forward')
                ORDER BY created_at ASC
                """,
                (session_id, branch),
            )
            return [dict(row) for row in cursor.fetchall()]
    except sqlite3.Error as e:
        logger.error(f"Database error querying pending requirements: {e}")
        return []


def update_fulfillment_status(
    db_path: Path,
    requirement_id: int,
    new_status: str,
    evidence: str,
    fulfillment_event_id: int | None = None,
) -> None:
    """Update the fulfillment status of a requirement."""
    try:
        with get_connection(db_path) as conn:
            conn.execute(
                """
                UPDATE guidance_fulfillment
                SET fulfillment_status = ?,
                    fulfillment_evidence = ?,
                    fulfillment_event_id = ?,
                    fulfilled_at = ?
                WHERE id = ?
                """,
                (
                    new_status,
                    evidence,
                    fulfillment_event_id,
                    datetime.now().isoformat() if new_status == "fulfilled" else None,
                    requirement_id,
                ),
            )
    except sqlite3.Error as e:
        logger.error(f"Database error updating fulfillment: {e}")


def _glob_match(file_path: str, pattern: str) -> bool:
    """Check if a file path matches a glob pattern.

    Handles absolute paths by matching the pattern against the path suffix.
    For example, pattern "wiki/Work-Log-*.md" matches
    "/Users/max/Development/pongogo/wiki/Work-Log-2026-02.md".

    Task #653: Declarative step verification.
    """
    import fnmatch

    if not file_path or not pattern:
        return False

    # Direct match
    if fnmatch.fnmatch(file_path, pattern):
        return True

    # Suffix match: try matching the end of the absolute path against the pattern
    # This handles absolute vs relative path differences
    path_parts = Path(file_path).parts
    pattern_parts = Path(pattern).parts
    if len(pattern_parts) <= len(path_parts):
        suffix = str(Path(*path_parts[-len(pattern_parts) :]))
        if fnmatch.fnmatch(suffix, pattern):
            return True

    return False


def _regex_match(command: str, pattern: str) -> bool:
    """Check if a command matches a regex pattern.

    Uses re.search (not re.match) so patterns match anywhere in the command.
    Handles invalid regex gracefully by returning False.

    Task #653: Declarative step verification.
    """
    import re

    if not command or not pattern:
        return False

    try:
        return bool(re.search(pattern, command))
    except re.error:
        logger.warning(f"Invalid regex pattern in requirement: {pattern}")
        return False


def evaluate_tool_call(
    tool_name: str, tool_input: dict, requirement: dict
) -> dict | None:
    """Evaluate if a tool call satisfies a requirement.

    Lightweight evaluation without importing the full compliance module.
    Checks if a Read, Write, Edit, Bash, or MCP tool call matches a pending
    requirement.

    Returns:
        Dict with fulfillment details if matched, None otherwise
    """
    action_type = requirement.get("action_type", "")
    guidance_content = requirement.get("guidance_content", "")
    pattern = requirement.get("pattern")

    # Handle call_mcp_tool requirements
    if action_type == "call_mcp_tool":
        required_tool = requirement.get("required_tool", "")
        if required_tool and (tool_name == required_tool or required_tool in tool_name):
            return {
                "fulfilled": True,
                "evidence": f"MCP tool call {tool_name} satisfies {required_tool} requirement",
            }
        return None

    # Task #653: Handle write_file requirements (Write/Edit tool calls)
    if action_type == "write_file":
        if tool_name not in ("Write", "Edit"):
            return None
        file_path = tool_input.get("file_path", "")
        if pattern and _glob_match(file_path, pattern):
            return {
                "fulfilled": True,
                "evidence": f"{tool_name} to {file_path} matches pattern '{pattern}'",
            }
        return None

    # Task #653: Handle bash_command requirements (Bash tool calls)
    if action_type == "bash_command":
        if tool_name != "Bash":
            return None
        command = tool_input.get("command", "")
        if pattern and _regex_match(command, pattern):
            return {
                "fulfilled": True,
                "evidence": f"Bash command matches pattern '{pattern}'",
            }
        return None

    # For all other action types, only Read tool calls are relevant
    if tool_name != "Read":
        return None

    file_path = tool_input.get("file_path", "")
    if not file_path:
        return None

    # Check if the Read call matches a "read instruction" requirement
    if action_type in ("read_instruction", "process_checklist"):
        # Check if the file path contains .pongogo/instructions/
        if ".pongogo/instructions/" in file_path and file_path.endswith(
            ".instructions.md"
        ):
            return {
                "fulfilled": True,
                "evidence": f"Read tool call on instruction file: {file_path}",
            }

    # Check if the Read call matches a specific file requirement
    if action_type == "read_file":
        # The guidance_content may contain the required file path
        # Check if the actual read matches
        if guidance_content:
            # Extract file path from guidance content
            required_file = _extract_required_file(guidance_content)
            if required_file and _paths_match(file_path, required_file):
                return {
                    "fulfilled": True,
                    "evidence": f"Read tool call matches required file: {file_path}",
                }

    # Handle step_citation requirement:
    # When a checklist is read, mark step_citation as fulfilled
    # because reading the checklist enables citing steps from it
    if action_type == "step_citation":
        # Check if a checklist file was read
        if "checklist" in file_path.lower() and file_path.endswith(".md"):
            return {
                "fulfilled": True,
                "evidence": f"Checklist read enables step citation: {file_path}",
            }

    return None


def _extract_required_file(guidance_content: str) -> str | None:
    """Extract a file path from guidance content text."""
    import re

    # Match patterns like: Read /path/to/file.md or Read(file_path="/path/to/file.md")
    match = re.search(
        r'(?:Read\s+|file_path\s*=\s*["\'])([^\s"\']+\.md)', guidance_content
    )
    if match:
        return match.group(1)
    return None


def _paths_match(actual_path: str, required_path: str) -> bool:
    """Check if two file paths refer to the same file."""
    if actual_path == required_path:
        return True

    # Check suffix match (handles absolute vs relative)
    actual_parts = Path(actual_path).parts
    required_parts = Path(required_path).parts

    if len(required_parts) <= len(actual_parts):
        return actual_parts[-len(required_parts) :] == required_parts

    return False


def main():
    start_time = time.time()

    try:
        input_data = json.load(sys.stdin)
    except (json.JSONDecodeError, EOFError):
        _ensure_log_dir()
        logger.error("Failed to read JSON from stdin")
        sys.exit(0)  # Don't block on input errors

    session_id = input_data.get("session_id", "")
    tool_name = input_data.get("tool_name", "")
    tool_input = input_data.get("tool_input", {})

    # Fast path: only process tools that can satisfy compliance requirements
    # Read: blocked_until read requirements
    # Write/Edit: write_file closure requirements (Task #653)
    # Bash: bash_command closure requirements (Task #653)
    # MCP tools (mcp__*): call_mcp_tool enforcement requirements
    TRACKED_TOOLS = {"Read", "Write", "Edit", "Bash"}
    if tool_name not in TRACKED_TOOLS and not tool_name.startswith("mcp__"):
        sys.exit(0)

    # Detect branch for cross-branch isolation (Task #640)
    from mcp_server.database.context import get_current_branch

    branch = get_current_branch()

    # Initialize dual logging with session context
    _ensure_log_dir(session_id=session_id, branch=branch or "")

    # Find database
    db_path = get_db_path()
    if not db_path:
        logger.debug("No database found, skipping compliance check")
        sys.exit(0)

    # Check for pending requirements (branch-filtered)
    pending = get_pending_requirements(db_path, session_id, branch=branch)
    if not pending:
        elapsed = (time.time() - start_time) * 1000
        logger.debug(
            f"No pending requirements for session {session_id}: {elapsed:.1f}ms"
        )
        sys.exit(0)

    # Evaluate tool call against each pending requirement
    fulfilled_count = 0
    for req in pending:
        result = evaluate_tool_call(tool_name, tool_input, req)
        if result and result.get("fulfilled"):
            update_fulfillment_status(
                db_path,
                req["id"],
                "fulfilled",
                result["evidence"],
            )
            fulfilled_count += 1
            logger.info(
                f"Compliance requirement fulfilled: id={req['id']}, "
                f"action_type={req['action_type']}, "
                f"evidence={result['evidence'][:80]}"
            )

    elapsed = (time.time() - start_time) * 1000
    logger.info(
        f"PostToolUse compliance check: tool={tool_name}, "
        f"pending={len(pending)}, fulfilled={fulfilled_count}, "
        f"elapsed={elapsed:.1f}ms"
    )

    # Silent exit - no stdout output
    sys.exit(0)


if __name__ == "__main__":
    main()
