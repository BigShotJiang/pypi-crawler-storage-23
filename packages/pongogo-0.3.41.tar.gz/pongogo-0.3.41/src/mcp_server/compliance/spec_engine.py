"""
Compliance specification engine for parsing procedural instructions.

Extracts declarative ComplianceRule objects from:
1. YAML frontmatter `enforcement:` blocks (Epic #565 - declarative)
2. COMPLIANCE GATE sections in markdown body (Epic #545 - legacy)

Platform-agnostic: no Claude Code or hook-specific imports.

Epic #545: Hook-Based Compliance Enforcement
Epic #565: Declarative Enforcement Engine
"""

import logging
import re

import yaml

from .models import (
    ComplianceRule,
    ComplianceSpec,
    EnforcementPhase,
    EnforcementScope,
    EnforcementSpec,
    RuleType,
    ToolCategory,
)

logger = logging.getLogger(__name__)

# Pattern to detect COMPLIANCE GATE section headers
# Matches variations: "## 🛑 COMPLIANCE GATE", "## 🛑 STOP: COMPLIANCE GATE (BLOCKING - NOT ADVISORY)"
COMPLIANCE_GATE_HEADER = re.compile(
    r"^##\s+.*COMPLIANCE\s+GATE.*$", re.MULTILINE | re.IGNORECASE
)

# Pattern to extract Read tool call requirements from compliance gates
# Matches: Read(file_path="/path/to/file.md") or Read(`path/to/file.md`)
READ_TOOL_CALL_PATTERN = re.compile(
    r'Read\s*\(\s*file_path\s*=\s*["\']([^"\']+)["\']',
    re.IGNORECASE,
)

# Pattern to extract referenced documents from compliance gates
# Matches: Read `docs/templates/issue_closure_checklist.md`
# or: read `docs/templates/issue_closure_checklist.md` first
READ_DOC_REFERENCE_PATTERN = re.compile(
    r'[Rr]ead\s+[`"\']([^`"\']+\.md)[`"\']',
)

# Pattern to detect "read this instruction file" requirements
READ_INSTRUCTION_PATTERN = re.compile(
    r"(?:have\s+I\s+READ\s+this\s+instruction\s+file|"
    r"read\s+this\s+file\s+NOW|"
    r"read\s+the\s+instruction\s+file)",
    re.IGNORECASE,
)

# Pattern to detect step citation requirements
STEP_CITATION_PATTERN = re.compile(
    r"(?:cite\s+step\s+numbers|"
    r"step\s+citation\s+requirement|"
    r'format:\s+["\']?step\s+\d)',
    re.IGNORECASE,
)


class ComplianceSpecEngine:
    """Parse procedural instructions into declarative compliance rules.

    This engine extracts ComplianceSpec objects from instruction content by:
    1. Parsing `enforcement:` block from YAML frontmatter (Epic #565)
    2. Falling back to COMPLIANCE GATE sections in body (Epic #545)
    3. Building ComplianceRule objects for each requirement

    Usage:
        engine = ComplianceSpecEngine()
        spec = engine.parse(instruction_id, instruction_content)
        if spec.has_rules:
            for rule in spec.rules:
                print(f"Requirement: {rule.description}")
    """

    def parse(self, instruction_id: str, content: str) -> ComplianceSpec:
        """Parse instruction content into a ComplianceSpec.

        Tries declarative enforcement frontmatter first (Epic #565),
        then falls back to COMPLIANCE GATE body parsing (Epic #545).

        Args:
            instruction_id: Identifier for the source instruction
            content: Full text content of the instruction file

        Returns:
            ComplianceSpec with extracted rules (empty if no compliance found)
        """
        if not content:
            return ComplianceSpec(source_instruction_id=instruction_id)

        # Try declarative enforcement from frontmatter first (Epic #565)
        enforcement_spec = self._parse_enforcement_frontmatter(content)
        if enforcement_spec and enforcement_spec.has_enforcement:
            rules = self._rules_from_enforcement(instruction_id, enforcement_spec)
            # Task #653: Also generate rules from required_before_closure
            rules.extend(
                self._rules_from_required_before_closure(
                    instruction_id, enforcement_spec
                )
            )
            return ComplianceSpec(
                rules=rules,
                source_instruction_id=instruction_id,
                detection_method="enforcement_frontmatter",
            )

        # Fall back to COMPLIANCE GATE body parsing (Epic #545)
        gate_sections = self._extract_gate_sections(content)
        if not gate_sections:
            return ComplianceSpec(source_instruction_id=instruction_id)

        rules = []
        for section in gate_sections:
            rules.extend(self._extract_rules(instruction_id, section))

        return ComplianceSpec(
            rules=rules,
            source_instruction_id=instruction_id,
            detection_method="compliance_gate",
        )

    def parse_from_routing_result(
        self, instruction_id: str, content: str, procedural_info: dict
    ) -> ComplianceSpec:
        """Parse from routing result that already has procedural detection info.

        This optimized path uses the detection already done by
        pongogo_router._is_procedural_instruction().

        Args:
            instruction_id: Identifier for the source instruction
            content: Full text content of the instruction file
            procedural_info: Dict from _is_procedural_instruction() with
                is_procedural, detection_method, referenced_doc

        Returns:
            ComplianceSpec with extracted rules
        """
        if not procedural_info.get("is_procedural", False):
            return ComplianceSpec(source_instruction_id=instruction_id)

        spec = self.parse(instruction_id, content)

        # If routing detected a referenced doc but parsing didn't find it,
        # add a READ_FILE rule from the routing detection
        if procedural_info.get("referenced_doc"):
            ref_doc = procedural_info["referenced_doc"]
            has_ref = any(
                r.referenced_file == ref_doc
                for r in spec.rules
                if r.rule_type == RuleType.READ_FILE
            )
            if not has_ref:
                spec.rules.append(
                    ComplianceRule(
                        rule_type=RuleType.READ_FILE,
                        description=f"Read {ref_doc} before executing",
                        source_instruction_id=instruction_id,
                        required_tool="Read",
                        referenced_file=ref_doc,
                        blocked_tools=[ToolCategory.MUTATING],
                        scope=EnforcementScope.SESSION,
                    )
                )

        return spec

    def _extract_gate_sections(self, content: str) -> list[str]:
        """Extract COMPLIANCE GATE sections from instruction content.

        Returns the text of each compliance gate section, from the header
        to the next --- separator or next ## header.
        """
        sections = []
        matches = list(COMPLIANCE_GATE_HEADER.finditer(content))

        for match in matches:
            start = match.start()
            # Find the end: next "---" or next "## " after this section
            rest = content[match.end() :]
            end_match = re.search(r"^---\s*$|^## (?!.*COMPLIANCE)", rest, re.MULTILINE)
            if end_match:
                section_text = content[start : match.end() + end_match.start()]
            else:
                section_text = content[start:]
            sections.append(section_text)

        return sections

    def _extract_rules(
        self, instruction_id: str, gate_section: str
    ) -> list[ComplianceRule]:
        """Extract compliance rules from a single COMPLIANCE GATE section.

        Body-parsed rules get default blocked_tools=[ToolCategory.MUTATING]
        and scope=SESSION, making them self-sufficient without legacy
        TOOL_ENFORCEMENT_RULES. Categories are resolved to platform-specific
        tool names at enforcement time via resolve_blocked_tools().
        """
        rules = []
        # Default enforcement for body-parsed rules: block mutating tools
        default_blocked = [ToolCategory.MUTATING]
        default_scope = EnforcementScope.SESSION

        # Check for explicit Read tool call requirements
        for match in READ_TOOL_CALL_PATTERN.finditer(gate_section):
            file_path = match.group(1)
            rules.append(
                ComplianceRule(
                    rule_type=RuleType.READ_FILE,
                    description=f"Read {file_path} before executing",
                    source_instruction_id=instruction_id,
                    required_tool="Read",
                    referenced_file=file_path,
                    blocked_tools=list(default_blocked),
                    scope=default_scope,
                )
            )

        # Check for referenced document requirements (Read `path/to/file.md`)
        for match in READ_DOC_REFERENCE_PATTERN.finditer(gate_section):
            ref_doc = match.group(1)
            # Avoid duplicates if same file found by READ_TOOL_CALL_PATTERN
            already_found = any(r.referenced_file == ref_doc for r in rules)
            if not already_found:
                rules.append(
                    ComplianceRule(
                        rule_type=RuleType.READ_FILE,
                        description=f"Read {ref_doc} before executing",
                        source_instruction_id=instruction_id,
                        required_tool="Read",
                        referenced_file=ref_doc,
                        blocked_tools=list(default_blocked),
                        scope=default_scope,
                    )
                )

        # Check for "read this instruction file" requirement
        if READ_INSTRUCTION_PATTERN.search(gate_section):
            rules.append(
                ComplianceRule(
                    rule_type=RuleType.READ_INSTRUCTION,
                    description="Read this instruction file before executing",
                    source_instruction_id=instruction_id,
                    required_tool="Read",
                    blocked_tools=list(default_blocked),
                    scope=default_scope,
                )
            )

        # Check for step citation requirement
        if STEP_CITATION_PATTERN.search(gate_section):
            rules.append(
                ComplianceRule(
                    rule_type=RuleType.STEP_CITATION,
                    description="Cite step numbers from the instruction file",
                    source_instruction_id=instruction_id,
                    blocked_tools=list(default_blocked),
                    scope=default_scope,
                )
            )

        return rules

    def _parse_enforcement_frontmatter(self, content: str) -> EnforcementSpec | None:
        """Extract enforcement specification from YAML frontmatter.

        Parses the `enforcement:` block from instruction file frontmatter.

        Args:
            content: Full instruction file content

        Returns:
            EnforcementSpec if enforcement block found, None otherwise
        """
        # Extract YAML frontmatter (between --- markers)
        if not content.startswith("---"):
            return None

        # Find closing ---
        match = re.search(r"^---\s*$", content[3:], re.MULTILINE)
        if not match:
            return None

        frontmatter_text = content[3 : match.start() + 3]

        try:
            frontmatter = yaml.safe_load(frontmatter_text)
        except yaml.YAMLError as e:
            logger.warning(f"Failed to parse YAML frontmatter: {e}")
            return None

        if not frontmatter or "enforcement" not in frontmatter:
            return None

        enforcement_data = frontmatter["enforcement"]
        if not isinstance(enforcement_data, dict):
            logger.warning("enforcement block is not a dict")
            return None

        # Parse scope
        scope_str = enforcement_data.get("scope", "session")
        try:
            scope = EnforcementScope(scope_str)
        except ValueError:
            logger.warning(f"Invalid enforcement scope: {scope_str}, using session")
            scope = EnforcementScope.SESSION

        # Parse blocked_tools
        blocked_tools = enforcement_data.get("blocked_tools", [])
        if not isinstance(blocked_tools, list):
            blocked_tools = [blocked_tools] if blocked_tools else []

        # Parse blocked_until
        blocked_until = enforcement_data.get("blocked_until", [])
        if not isinstance(blocked_until, list):
            blocked_until = [blocked_until] if blocked_until else []

        # Parse required_before_closure (Task #653)
        required_before_closure = enforcement_data.get("required_before_closure", [])
        if not isinstance(required_before_closure, list):
            required_before_closure = (
                [required_before_closure] if required_before_closure else []
            )

        return EnforcementSpec(
            scope=scope,
            blocked_tools=blocked_tools,
            blocked_until=blocked_until,
            required_before_closure=required_before_closure,
        )

    def _rules_from_enforcement(
        self, instruction_id: str, enforcement: EnforcementSpec
    ) -> list[ComplianceRule]:
        """Generate ComplianceRules from an EnforcementSpec.

        Each blocked_until item becomes a ComplianceRule with the
        blocked_tools list attached.

        Args:
            instruction_id: Source instruction identifier
            enforcement: Parsed enforcement specification

        Returns:
            List of ComplianceRule objects
        """
        rules = []

        for item in enforcement.blocked_until:
            if not isinstance(item, dict):
                logger.warning(f"blocked_until item is not a dict: {item}")
                continue

            action_type_str = item.get("action_type", "")

            # Map action_type string to RuleType enum
            try:
                rule_type = RuleType(action_type_str)
            except ValueError:
                logger.warning(f"Unknown action_type: {action_type_str}")
                continue

            # Build description based on rule type
            file_path = item.get("file")
            tool_name = item.get("tool_name")
            required_args = item.get("required_args")
            if rule_type == RuleType.READ_FILE and file_path:
                description = f"Read {file_path} before executing"
            elif rule_type == RuleType.READ_INSTRUCTION:
                description = "Read this instruction file before executing"
            elif rule_type == RuleType.PROCESS_CHECKLIST:
                description = "Process the compliance checklist"
            elif rule_type == RuleType.STEP_CITATION:
                description = "Cite step numbers from the instruction file"
            elif rule_type == RuleType.APPROVAL_REQUIRED:
                description = "Obtain explicit approval before proceeding"
            elif rule_type == RuleType.CALL_MCP_TOOL and tool_name:
                description = f"Call MCP tool {tool_name} before proceeding"
            else:
                description = f"Complete {action_type_str} requirement"

            # Determine required_tool based on rule type
            if rule_type == RuleType.CALL_MCP_TOOL:
                req_tool = tool_name
            elif "read" in action_type_str:
                req_tool = "Read"
            else:
                req_tool = None

            rules.append(
                ComplianceRule(
                    rule_type=rule_type,
                    description=description,
                    source_instruction_id=instruction_id,
                    required_tool=req_tool,
                    required_args=required_args
                    if rule_type == RuleType.CALL_MCP_TOOL
                    else None,
                    referenced_file=file_path,
                    blocked_tools=list(enforcement.blocked_tools),
                    scope=enforcement.scope,
                )
            )

        return rules

    def _rules_from_required_before_closure(
        self, instruction_id: str, enforcement: EnforcementSpec
    ) -> list[ComplianceRule]:
        """Generate ComplianceRules from required_before_closure items.

        Task #653: These rules have enforcement_phase=REQUIRED_BEFORE_CLOSURE
        and blocked_tools=[] (they must NOT block general tool usage).

        Args:
            instruction_id: Source instruction identifier
            enforcement: Parsed enforcement specification

        Returns:
            List of ComplianceRule objects with closure-phase enforcement
        """
        rules = []

        for item in enforcement.required_before_closure:
            if not isinstance(item, dict):
                logger.warning(f"required_before_closure item is not a dict: {item}")
                continue

            action_type_str = item.get("action_type", "")
            pattern = item.get("pattern")
            description = item.get("description", f"Complete {action_type_str}")

            # Map action_type string to RuleType enum
            try:
                rule_type = RuleType(action_type_str)
            except ValueError:
                logger.warning(
                    f"Unknown action_type in required_before_closure: {action_type_str}"
                )
                continue

            # Determine required_tool based on rule type
            tool_name = item.get("tool_name")
            if rule_type == RuleType.CALL_MCP_TOOL:
                req_tool = tool_name
            elif rule_type in (RuleType.READ_FILE, RuleType.READ_INSTRUCTION):
                req_tool = "Read"
            else:
                req_tool = None

            rules.append(
                ComplianceRule(
                    rule_type=rule_type,
                    description=description,
                    source_instruction_id=instruction_id,
                    required_tool=req_tool,
                    referenced_file=item.get("file"),
                    blocked_tools=[],  # Must NOT block general tool usage
                    scope=enforcement.scope,
                    enforcement_phase=EnforcementPhase.REQUIRED_BEFORE_CLOSURE,
                    pattern=pattern,
                )
            )

        return rules
