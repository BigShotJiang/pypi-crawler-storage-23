"""
Data models for the compliance enforcement system.

Platform-agnostic: no Claude Code or hook-specific imports.
"""

from dataclasses import dataclass, field
from enum import Enum


class RuleType(str, Enum):
    """Types of compliance requirements that can be extracted from instructions."""

    READ_FILE = "read_file"
    READ_INSTRUCTION = "read_instruction"
    PROCESS_CHECKLIST = "process_checklist"
    APPROVAL_REQUIRED = "approval_required"
    STEP_CITATION = "step_citation"
    CALL_MCP_TOOL = "call_mcp_tool"
    WRITE_FILE = "write_file"  # Task #653: matches Write/Edit by glob pattern
    BASH_COMMAND = "bash_command"  # Task #653: matches Bash by regex pattern


class EnforcementPhase(str, Enum):
    """When an enforcement rule applies.

    Task #653: Declarative step verification.
    """

    BLOCKED_UNTIL = "blocked_until"  # Blocks tools in blocked_tools category (existing)
    REQUIRED_BEFORE_CLOSURE = (
        "required_before_closure"  # Only blocks closure operations
    )


class EnforcementScope(str, Enum):
    """How long an enforcement block persists.

    Part of declarative enforcement (Epic #565).
    """

    SESSION = "session"  # Block persists until session ends or status changes
    ACTION = "action"  # Block resets after each action (per-action enforcement)


class ToolCategory(str, Enum):
    """Semantic tool categories for platform-agnostic enforcement.

    Instruction files use these categories instead of literal tool names,
    allowing enforcement to work across different platforms (Claude Code,
    Cursor, Windsurf, etc.) by resolving categories to platform-specific
    tool names via TOOL_CATEGORY_REGISTRY.

    Part of declarative enforcement (Epic #565).
    """

    MUTATING = "mutating"  # Tools that modify project state
    READING = "reading"  # Tools that read project state
    EXECUTING = "executing"  # Tools that execute commands


# Maps semantic categories to platform-specific tool names.
# Currently configured for Claude Code. Update this registry
# to support additional platforms without changing instruction files.
TOOL_CATEGORY_REGISTRY: dict[str, list[str]] = {
    ToolCategory.MUTATING: ["Edit", "Write", "Bash"],
    ToolCategory.READING: ["Read", "Glob", "Grep"],
    ToolCategory.EXECUTING: ["Bash"],
}


def resolve_blocked_tools(blocked_tools: list[str]) -> list[str]:
    """Resolve tool categories and literal names to actual tool names.

    Supports both semantic categories and literal tool names:
    - "mutating" → ["Edit", "Write", "Bash"] (category expansion)
    - "Edit" → ["Edit"] (literal passthrough)

    This enables instruction files to use platform-agnostic categories
    while the enforcement layer resolves to platform-specific tools.
    """
    resolved = []
    for item in blocked_tools:
        if item in TOOL_CATEGORY_REGISTRY:
            resolved.extend(TOOL_CATEGORY_REGISTRY[item])
        else:
            resolved.append(item)  # Literal tool name passthrough
    return list(set(resolved))


@dataclass
class EnforcementSpec:
    """Declarative enforcement specification from instruction frontmatter.

    Defines what tools are blocked and what requirements release the block.
    Part of declarative enforcement (Epic #565).

    Example frontmatter:
        enforcement:
          scope: session
          blocked_tools:
            - mutating
          blocked_until:
            - action_type: read_instruction
            - action_type: read_file
              file: "docs/templates/checklist.md"
    """

    scope: EnforcementScope = EnforcementScope.SESSION
    blocked_tools: list[str] = field(default_factory=list)
    blocked_until: list[dict] = field(default_factory=list)
    required_before_closure: list[dict] = field(default_factory=list)

    @property
    def has_enforcement(self) -> bool:
        """Check if this spec has any enforcement rules."""
        has_blocked_until = len(self.blocked_tools) > 0 and len(self.blocked_until) > 0
        has_closure_reqs = len(self.required_before_closure) > 0
        return has_blocked_until or has_closure_reqs


@dataclass
class ComplianceRule:
    """A single compliance requirement extracted from a procedural instruction."""

    rule_type: RuleType
    description: str
    source_instruction_id: str
    required_tool: str | None = None
    required_args: dict | None = None
    referenced_file: str | None = None
    # Tools blocked until this requirement is fulfilled (Epic #565)
    blocked_tools: list[str] = field(default_factory=list)
    # Scope determines how long enforcement persists (Epic #565)
    scope: EnforcementScope = EnforcementScope.SESSION
    # Enforcement phase: blocked_until (pre-execution) or required_before_closure (Task #653)
    enforcement_phase: EnforcementPhase = EnforcementPhase.BLOCKED_UNTIL
    # Glob/regex pattern for write_file/bash_command rules (Task #653)
    pattern: str | None = None

    def matches_tool_call(self, tool_name: str, tool_input: dict) -> bool:
        """Check if a tool call could potentially satisfy this rule.

        This is a fast pre-filter. The evaluator does full matching.
        """
        if self.rule_type == RuleType.READ_FILE:
            return tool_name == "Read" and self.referenced_file is not None
        if self.rule_type == RuleType.READ_INSTRUCTION:
            return tool_name == "Read"
        if self.rule_type == RuleType.PROCESS_CHECKLIST:
            return tool_name == "Read"
        if self.rule_type == RuleType.CALL_MCP_TOOL:
            return self.required_tool is not None and (
                tool_name == self.required_tool or self.required_tool in tool_name
            )
        if self.rule_type == RuleType.WRITE_FILE:
            return tool_name in ("Write", "Edit")
        if self.rule_type == RuleType.BASH_COMMAND:
            return tool_name == "Bash"
        return False


@dataclass
class FulfillmentResult:
    """Result of evaluating a tool call against a compliance requirement."""

    fulfilled: bool
    partial: bool = False
    reason: str = ""


@dataclass
class ComplianceSpec:
    """Collection of compliance rules extracted from an instruction."""

    rules: list[ComplianceRule] = field(default_factory=list)
    source_instruction_id: str = ""
    detection_method: str = ""

    @property
    def has_rules(self) -> bool:
        return len(self.rules) > 0
