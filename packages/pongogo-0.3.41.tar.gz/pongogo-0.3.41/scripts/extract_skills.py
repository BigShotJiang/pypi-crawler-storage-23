#!/usr/bin/env python3
"""
Extract skills from seed/skills.jsonl to .claude/commands/ markdown files.

Converts JSONL entries to Claude Code slash command files.
"""

import argparse
import json
import sys
from pathlib import Path


def extract_skills(jsonl_path: Path, output_dir: Path, verbose: bool = False) -> int:
    """
    Extract skills from JSONL to markdown command files.

    Args:
        jsonl_path: Path to skills.jsonl
        output_dir: Output directory for command files (.claude/commands/)

    Returns:
        Number of files extracted
    """
    if not jsonl_path.exists():
        print(f"Error: {jsonl_path} not found", file=sys.stderr)
        return 0

    # Create output directory
    output_dir.mkdir(parents=True, exist_ok=True)

    count = 0

    with open(jsonl_path) as f:
        for line in f:
            if not line.strip():
                continue

            entry = json.loads(line)

            # Get command name
            command = entry.get("command", "")
            if not command:
                print("Warning: Entry missing command name", file=sys.stderr)
                continue

            # Output file path
            filename = f"{command}.md"
            file_path = output_dir / filename

            # Write content
            content = entry.get("content", "")
            if not content:
                print(f"Warning: Entry missing content: {command}", file=sys.stderr)
                continue

            with open(file_path, "w") as out:
                out.write(content)

            count += 1

            if verbose:
                print(f"  Extracted: {filename}")

    return count


def main():
    parser = argparse.ArgumentParser(
        description="Extract skills.jsonl to .claude/commands/ markdown files"
    )
    parser.add_argument(
        "jsonl_path",
        type=Path,
        nargs="?",
        default=Path("seed/skills.jsonl"),
        help="Path to skills.jsonl (default: seed/skills.jsonl)",
    )
    parser.add_argument(
        "output_dir",
        type=Path,
        nargs="?",
        default=Path("build/.claude/commands"),
        help="Output directory (default: build/.claude/commands)",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Print each file as extracted"
    )
    args = parser.parse_args()

    print(f"Extracting {args.jsonl_path} → {args.output_dir}/")

    count = extract_skills(args.jsonl_path, args.output_dir, args.verbose)

    if count > 0:
        print(f"Extracted {count} skill files")
        return 0
    else:
        print("No files extracted", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
