#!/usr/bin/env python3
"""
Extract config from seed/config.jsonl to settings files.

Converts JSONL config entries to Claude Code settings and other config files.
"""

import argparse
import json
import sys
from pathlib import Path


def extract_config(jsonl_path: Path, output_dir: Path, verbose: bool = False) -> dict:
    """
    Extract config from JSONL to settings files.

    Args:
        jsonl_path: Path to config.jsonl
        output_dir: Base output directory (build/)

    Returns:
        Dict with counts by config type
    """
    if not jsonl_path.exists():
        print(f"Error: {jsonl_path} not found", file=sys.stderr)
        return {}

    # Read all config entries
    entries = []
    with open(jsonl_path) as f:
        for line in f:
            if not line.strip():
                continue
            entries.append(json.loads(line))

    # Group by type
    by_type = {}
    for entry in entries:
        config_type = entry.get("type", "unknown")
        if config_type not in by_type:
            by_type[config_type] = []
        by_type[config_type].append(entry)

    # Create .claude directory
    claude_dir = output_dir / ".claude"
    claude_dir.mkdir(parents=True, exist_ok=True)

    # Build settings.json for Claude Code
    settings = {
        "mcpServers": {"pongogo-knowledge": {"command": "pongogo-server", "args": []}}
    }

    # Add routing config
    if "routing" in by_type:
        routing_config = {}
        for entry in by_type["routing"]:
            key = entry.get("key", "")
            default = entry.get("default")
            if key and default is not None:
                # Handle nested keys like "features.violation_detection"
                parts = key.split(".")
                current = routing_config
                for part in parts[:-1]:
                    if part not in current:
                        current[part] = {}
                    current = current[part]
                current[parts[-1]] = default

        if routing_config:
            settings["pongogo"] = {"routing": routing_config}

    # Write settings.json
    settings_path = claude_dir / "settings.json"
    with open(settings_path, "w") as f:
        json.dump(settings, f, indent=2)

    if verbose:
        print("  Created: .claude/settings.json")

    # Generate manifest metadata if manifest entries exist
    if "manifest" in by_type:
        manifest = {}
        for entry in by_type["manifest"]:
            key = entry.get("key", "")
            default = entry.get("default")
            if key and default is not None:
                manifest[key] = default

        manifest_path = output_dir / "instructions" / "manifest.json"
        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        with open(manifest_path, "w") as f:
            json.dump(manifest, f, indent=2)

        if verbose:
            print("  Created: instructions/manifest.json")

    # Return counts
    return {t: len(entries) for t, entries in by_type.items()}


def main():
    parser = argparse.ArgumentParser(
        description="Extract config.jsonl to settings files"
    )
    parser.add_argument(
        "jsonl_path",
        type=Path,
        nargs="?",
        default=Path("seed/config.jsonl"),
        help="Path to config.jsonl (default: seed/config.jsonl)",
    )
    parser.add_argument(
        "output_dir",
        type=Path,
        nargs="?",
        default=Path("build"),
        help="Base output directory (default: build)",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Print each file as created"
    )
    args = parser.parse_args()

    print(f"Extracting {args.jsonl_path} → {args.output_dir}/")

    type_counts = extract_config(args.jsonl_path, args.output_dir, args.verbose)

    if type_counts:
        total = sum(type_counts.values())
        print(f"Processed {total} config entries")
        for t, count in sorted(type_counts.items()):
            print(f"  {t}: {count}")
        return 0
    else:
        print("No config extracted", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
