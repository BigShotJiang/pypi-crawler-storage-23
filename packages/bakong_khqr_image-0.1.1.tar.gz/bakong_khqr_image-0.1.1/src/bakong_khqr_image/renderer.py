"""QR card image renderer."""

from __future__ import annotations

import importlib.resources
import io
import os
from typing import Optional, Tuple

from bakong_khqr_image.exceptions import MissingDependencyError
from bakong_khqr_image.models import Currency
from bakong_khqr_image.utils import format_amount


# ---------------------------------------------------------------------------
# Asset helpers
# ---------------------------------------------------------------------------

def _asset_path(filename: str) -> str:
    """Return the absolute path of a bundled asset file."""
    package_dir = os.path.join(os.path.dirname(__file__), "assets")
    return os.path.join(package_dir, filename)


def _load_image(filename: str):
    """Load a bundled PNG asset as an RGBA PIL Image, or return *None*."""
    try:
        from PIL import Image  # type: ignore
        return Image.open(_asset_path(filename)).convert("RGBA")
    except Exception:
        return None


def _load_font(filename: str, size: int):
    """Load a bundled TTF font, falling back to the PIL default."""
    try:
        from PIL import ImageFont  # type: ignore
        return ImageFont.truetype(_asset_path(filename), size)
    except Exception:
        from PIL import ImageFont  # type: ignore
        return ImageFont.load_default()


# ---------------------------------------------------------------------------
# Card renderer
# ---------------------------------------------------------------------------

class CardRenderer:
    """Renders a styled KHQR card image from a payload string.

    The card layout mirrors the official Bakong KHQR design:

    * 300 × 450 px white card with rounded corners
    * Red header band (60 px) with centred Bakong logo
    * Merchant name, bold amount and currency label
    * Dashed separator line
    * 280 × 280 QR code with a currency icon overlay at the centre
    * Red folded-corner triangle (top-right)

    This renderer is used internally by :class:`~bakong_khqr_image.KHQRImage`.
    """

    # Card dimensions
    CARD_WIDTH: int = 300
    CARD_HEIGHT: int = 450
    HEADER_HEIGHT: int = 60
    QR_SIZE: int = 280
    CORNER_RADIUS: int = 15
    FOLD_SIZE: int = 90
    HEADER_COLOR: Tuple[int, int, int] = (204, 0, 0)

    def render(
        self,
        merchant_name: str,
        amount: float,
        currency: Currency,
        qr_payload: str,
    ):
        """Render the card and return a :class:`QRImageResult`.

        Args:
            merchant_name: Merchant display name.
            amount: Transaction amount (0 = no amount shown).
            currency: :class:`~bakong_khqr_image.models.Currency` member.
            qr_payload: Full EMV KHQR payload string.

        Returns:
            :class:`QRImageResult` with multiple export methods.

        Raises:
            :class:`~bakong_khqr_image.exceptions.MissingDependencyError`:
                If *Pillow* or *qrcode* are not installed.
        """
        try:
            from PIL import Image, ImageDraw, ImageFont  # noqa: F401  # type: ignore
        except ImportError:
            raise MissingDependencyError("Pillow")
        try:
            import qrcode  # type: ignore  # noqa: F401
        except ImportError:
            raise MissingDependencyError("qrcode")

        currency_str = currency.value
        card = self._build_card(merchant_name, amount, currency_str, qr_payload)
        return QRImageResult(card)

    # ------------------------------------------------------------------
    # Private – card construction steps
    # ------------------------------------------------------------------

    def _build_card(self, merchant_name: str, amount: float, currency_str: str, qr_payload: str):
        from PIL import Image, ImageDraw  # type: ignore

        w, h = self.CARD_WIDTH, self.CARD_HEIGHT
        img = Image.new("RGB", (w, h), (255, 255, 255))
        draw = ImageDraw.Draw(img)

        self._draw_header(img, draw, w)
        self._draw_merchant_info(draw, merchant_name, amount, currency_str, w)
        self._draw_separator(draw, w)
        self._draw_qr(img, qr_payload, w, amount, currency_str)
        self._draw_fold_corner(draw, w, h)

        return self._apply_rounded_corners(img, self.CORNER_RADIUS)

    def _draw_header(self, img, draw, width: int) -> None:
        from PIL import Image  # type: ignore

        draw.rectangle([(0, 0), (width, self.HEADER_HEIGHT)], fill=self.HEADER_COLOR)

        logo = _load_image("logo.png")
        if logo is not None:
            logo_w, logo_h = 90, 21
            logo = logo.resize((logo_w, logo_h))
            img.paste(logo, (width // 2 - logo_w // 2, 20), logo)

    def _draw_merchant_info(
        self, draw, merchant_name: str, amount: float, currency_str: str, width: int
    ) -> None:
        from PIL import Image, ImageDraw  # type: ignore

        name_font = _load_font("regular.ttf", 18)
        amount_font = _load_font("bold.ttf", 22)
        currency_font = _load_font("regular.ttf", 14)

        draw.text((32, 80), merchant_name, fill="black", font=name_font)

        amount_text = format_amount(amount, currency_str)

        # Measure amount text width for side-by-side currency label
        dummy = Image.new("RGB", (1, 1))
        dummy_draw = ImageDraw.Draw(dummy)
        bbox = dummy_draw.textbbox((0, 0), amount_text, font=amount_font)
        amount_width = bbox[2] - bbox[0]

        draw.text((30, 110), amount_text, fill="black", font=amount_font)
        draw.text((30 + amount_width + 5, 118), currency_str, fill="black", font=currency_font)

    def _draw_separator(self, draw, width: int) -> None:
        self._draw_dashed_line(draw, (0, 150), (width, 150), dash=2, gap=4, fill="grey")

    def _draw_qr(self, img, qr_payload: str, width: int, amount: float, currency_str: str) -> None:
        from PIL import Image  # type: ignore
        import qrcode  # type: ignore
        import qrcode.constants  # type: ignore

        qr = qrcode.QRCode(
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(qr_payload)
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
        qr_img = qr_img.resize((self.QR_SIZE, self.QR_SIZE))
        img.paste(qr_img, (10, 160))

        icon = self._load_center_icon(amount, currency_str)
        if icon is not None:
            icon = icon.resize((40, 40))
            img.paste(icon, (width // 2 - 20, 280), icon)

    @staticmethod
    def _load_center_icon(amount: float, currency_str: str):
        if amount > 0:
            return _load_image("USD.png" if currency_str == "USD" else "KHR.png")
        return _load_image("khqr.png")

    @staticmethod
    def _draw_fold_corner(draw, width: int, height: int, fold_size: int = 90) -> None:
        triangle = [
            (width - fold_size, 0),
            (width, 0),
            (width, fold_size),
        ]
        draw.polygon(triangle, fill="#cc0000")

    @staticmethod
    def _apply_rounded_corners(image, radius: int):
        from PIL import Image, ImageDraw  # type: ignore

        w, h = image.size
        mask = Image.new("L", (w, h), 0)
        mask_draw = ImageDraw.Draw(mask)
        mask_draw.rounded_rectangle([0, 0, w, h], radius=radius, fill=255)

        rounded = Image.new("RGBA", (w, h))
        rounded.paste(image, (0, 0), mask)
        return rounded

    @staticmethod
    def _draw_dashed_line(draw, start, end, dash: int = 5, gap: int = 5, fill="grey", width: int = 1) -> None:
        x1, y1 = start
        x2, y2 = end
        total = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
        if total == 0:
            return
        dx, dy = (x2 - x1) / total, (y2 - y1) / total
        drawn = 0.0
        while drawn < total:
            seg_start = (x1 + dx * drawn, y1 + dy * drawn)
            drawn += dash
            seg_end = (x1 + dx * min(drawn, total), y1 + dy * min(drawn, total))
            draw.line([seg_start, seg_end], fill=fill, width=width)
            drawn += gap


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------

class QRImageResult:
    """Container for a rendered KHQR card image with flexible export options.

    You obtain an instance by calling
    :meth:`~bakong_khqr_image.KHQRImage.generate_image`.

    Example::

        result = khqr.generate_image(amount=1.50)
        result.save_png("payment.png")
        encoded = result.to_base64()
    """

    def __init__(self, image) -> None:
        self._image = image

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def image(self):
        """The underlying :class:`PIL.Image.Image` object."""
        return self._image

    # ------------------------------------------------------------------
    # Export methods
    # ------------------------------------------------------------------

    def save_png(self, path: Optional[str] = None) -> str:
        """Save the card as a PNG file.

        Args:
            path: Destination file path. Defaults to a temp-directory file.

        Returns:
            Absolute path to the saved file.
        """
        import tempfile
        path = path or os.path.join(tempfile.gettempdir(), "khqr_card.png")
        self._image.save(path, format="PNG", optimize=True, compress_level=9)
        return path

    def save_jpeg(self, path: Optional[str] = None) -> str:
        """Save the card as a JPEG file.

        Args:
            path: Destination file path. Defaults to a temp-directory file.

        Returns:
            Absolute path to the saved file.
        """
        import tempfile
        path = path or os.path.join(tempfile.gettempdir(), "khqr_card.jpg")
        self._image.convert("RGB").save(
            path, format="JPEG", quality=95, subsampling=0, optimize=True
        )
        return path

    def save_webp(self, path: Optional[str] = None) -> str:
        """Save the card as a lossless WebP file.

        Args:
            path: Destination file path. Defaults to a temp-directory file.

        Returns:
            Absolute path to the saved file.
        """
        import tempfile
        path = path or os.path.join(tempfile.gettempdir(), "khqr_card.webp")
        self._image.save(path, format="WEBP", lossless=True)
        return path

    def to_bytes(self) -> bytes:
        """Return the PNG-encoded image as raw bytes."""
        buf = io.BytesIO()
        self._image.save(buf, format="PNG")
        return buf.getvalue()

    def to_base64(self) -> str:
        """Return the PNG-encoded image as a Base-64 string."""
        import base64
        return base64.b64encode(self.to_bytes()).decode("utf-8")

    def to_data_uri(self) -> str:
        """Return a ``data:image/png;base64,…`` URI for direct use in HTML / CSS."""
        return f"data:image/png;base64,{self.to_base64()}"
