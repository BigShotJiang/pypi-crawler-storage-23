"""bakong-khqr-image – Generate styled Bakong KHQR card images.

Quick start::

    from bakong_khqr_image import KHQRImage

    khqr = KHQRImage(
        bakong_account_id="yourname@aclb",
        merchant_name="My Coffee Shop",
    )

    result = khqr.generate_image(amount=2.50)
    result.save_png("payment.png")
"""

from bakong_khqr_image.exceptions import (
    BakongKHQRError,
    InvalidAmountError,
    InvalidCurrencyError,
    MissingDependencyError,
)
from bakong_khqr_image.khqr_image import KHQRImage
from bakong_khqr_image.models import Currency, MerchantInfo, QROptions
from bakong_khqr_image.renderer import QRImageResult

__all__ = [
    "KHQRImage",
    "Currency",
    "MerchantInfo",
    "QROptions",
    "QRImageResult",
    "BakongKHQRError",
    "InvalidAmountError",
    "InvalidCurrencyError",
    "MissingDependencyError",
]

__version__ = "0.1.1"
