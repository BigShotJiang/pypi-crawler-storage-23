"""EMV-compliant KHQR payload builder."""

from __future__ import annotations

import random
import time
from typing import Optional, Tuple

from bakong_khqr_image.models import Currency, MerchantInfo, QROptions
from bakong_khqr_image.utils import BAKONG_GUID, calculate_crc16, format_tlv


class PayloadBuilder:
    """Builds a fully-compliant KHQR (EMV QR) payload string.

    You rarely need to use this class directly – prefer
    :class:`~bakong_khqr_image.KHQRImage` which combines payload generation
    with image rendering.

    Args:
        merchant: Merchant configuration.
    """

    def __init__(self, merchant: MerchantInfo) -> None:
        self._merchant = merchant

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def build(self, amount: float, options: Optional[QROptions] = None) -> Tuple[str, str]:
        """Generate an EMV-compliant KHQR payload string.

        Args:
            amount: Transaction amount (0 for static / open-amount QR codes).
            options: Extra metadata. A new :class:`~bakong_khqr_image.models.QROptions`
                     is created automatically when not supplied.

        Returns:
            A ``(payload, bill_number)`` tuple.
        """
        opts = options or QROptions()
        bill_number = opts.bill_number or self._generate_bill_number()

        payload = self._build_payload(amount, opts, bill_number)
        return payload, bill_number

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _build_payload(self, amount: float, opts: QROptions, bill_number: str) -> str:
        merchant = self._merchant
        currency = merchant.currency

        parts: list[str] = [
            # Tag 00 – Payload Format Indicator
            format_tlv("00", "01"),
            # Tag 01 – Point of Initiation (11=static, 12=dynamic)
            format_tlv("01", "11" if opts.static else "12"),
            # Tag 15 – Merchant Account (Acquiring Bank / Bakong)
            format_tlv("15", BAKONG_GUID + format_tlv("00", merchant.bakong_account_id)),
            # Tag 29 – Merchant Account (Individual)
            format_tlv("29", format_tlv("00", merchant.bakong_account_id)),
            # Tag 52 – Merchant Category Code
            format_tlv("52", "5999"),
            # Tag 53 – Transaction Currency
            format_tlv("53", currency.iso_code),
        ]

        # Tag 54 – Transaction Amount (dynamic QR with non-zero amount only)
        if not opts.static and amount and amount > 0:
            amount_str = f"{amount:.2f}" if currency == Currency.USD else f"{amount:.0f}"
            parts.append(format_tlv("54", amount_str))

        parts += [
            # Tag 58 – Country Code
            format_tlv("58", "KH"),
            # Tag 59 – Merchant Name
            format_tlv("59", merchant.merchant_name),
            # Tag 60 – Merchant City
            format_tlv("60", merchant.merchant_city),
        ]

        # Tag 62 – Additional Data Field (optional sub-tags)
        additional = self._build_additional_data(bill_number, opts)
        if additional:
            parts.append(format_tlv("62", additional))

        # Tag 63 – CRC (appended last)
        partial = "".join(parts) + "6304"
        crc = calculate_crc16(partial)
        return partial + crc

    @staticmethod
    def _build_additional_data(bill_number: str, opts: QROptions) -> str:
        fields: list[str] = []
        if bill_number:
            fields.append(format_tlv("01", bill_number))    # Bill number
        if opts.store_label:
            fields.append(format_tlv("03", opts.store_label))   # Store label
        if opts.terminal_label:
            fields.append(format_tlv("07", opts.terminal_label))  # Terminal label
        if opts.mobile_number:
            fields.append(format_tlv("09", opts.mobile_number))   # Mobile number
        return "".join(fields)

    @staticmethod
    def _generate_bill_number() -> str:
        timestamp = str(int(time.time()))[-8:]
        random_part = random.randint(1000, 9999)
        return f"KHQR{timestamp}{random_part}"
