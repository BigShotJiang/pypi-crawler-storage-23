"""Main entry point for the bakong-khqr-image library."""

from __future__ import annotations

import hashlib
from typing import Optional, Tuple

from bakong_khqr_image.exceptions import InvalidAmountError, InvalidCurrencyError
from bakong_khqr_image.models import Currency, MerchantInfo, QROptions
from bakong_khqr_image.payload import PayloadBuilder
from bakong_khqr_image.renderer import CardRenderer, QRImageResult


class KHQRImage:
    """High-level API for generating Bakong KHQR card images.

    Create one instance per merchant and reuse it for every payment.

    Args:
        bakong_account_id: Bakong account ID (e.g. ``"merchant@aclb"``).
        merchant_name: Name shown on the QR card.
        merchant_city: City encoded in the payload (default ``"Phnom Penh"``).
        currency: ``"USD"`` or ``"KHR"`` (default ``"USD"``).

    Raises:
        :class:`~bakong_khqr_image.exceptions.InvalidCurrencyError`:
            If an unsupported currency string is supplied.

    Example::

        from bakong_khqr_image import KHQRImage

        khqr = KHQRImage(
            bakong_account_id="yourname@aclb",
            merchant_name="My Coffee Shop",
        )

        result = khqr.generate_image(amount=2.50)
        result.save_png("payment_qr.png")
    """

    def __init__(
        self,
        bakong_account_id: str,
        merchant_name: str,
        merchant_city: str = "Phnom Penh",
        currency: str = "USD",
    ) -> None:
        self._merchant = MerchantInfo(
            bakong_account_id=bakong_account_id,
            merchant_name=merchant_name,
            merchant_city=merchant_city,
            currency=Currency.from_str(currency),
        )
        self._payload_builder = PayloadBuilder(self._merchant)
        self._renderer = CardRenderer()

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def generate_image(
        self,
        amount: float,
        *,
        bill_number: Optional[str] = None,
        store_label: Optional[str] = None,
        terminal_label: Optional[str] = None,
        mobile_number: Optional[str] = None,
        static: bool = False,
    ) -> QRImageResult:
        """Generate a styled KHQR card image.

        Args:
            amount: Transaction amount. Pass ``0`` for an open-amount (static) QR.
            bill_number: Unique reference ID. Auto-generated when omitted.
            store_label: Store label embedded in the QR payload.
            terminal_label: Terminal label embedded in the QR payload.
            mobile_number: Merchant phone number embedded in the QR payload.
            static: ``True`` to generate a *static* (reusable) QR code.

        Returns:
            :class:`~bakong_khqr_image.renderer.QRImageResult` with
            ``save_png``, ``save_jpeg``, ``save_webp``, ``to_bytes``,
            ``to_base64``, and ``to_data_uri`` export methods.

        Raises:
            :class:`~bakong_khqr_image.exceptions.InvalidAmountError`:
                If *amount* is negative.
            :class:`~bakong_khqr_image.exceptions.MissingDependencyError`:
                If *Pillow* or *qrcode* are not installed.

        Example::

            result = khqr.generate_image(amount=5.00, store_label="Table 3")
            result.save_png("qr.png")
        """
        self._validate_amount(amount)

        options = QROptions(
            bill_number=bill_number,
            store_label=store_label,
            terminal_label=terminal_label,
            mobile_number=mobile_number,
            static=static,
        )
        payload, _ = self._payload_builder.build(amount, options)

        return self._renderer.render(
            merchant_name=self._merchant.merchant_name,
            amount=amount,
            currency=self._merchant.currency,
            qr_payload=payload,
        )

    def generate_payload(
        self,
        amount: float,
        *,
        bill_number: Optional[str] = None,
        store_label: Optional[str] = None,
        terminal_label: Optional[str] = None,
        mobile_number: Optional[str] = None,
        static: bool = False,
    ) -> Tuple[str, str]:
        """Generate only the EMV KHQR payload string (no image).

        Useful when you need the raw payload for a third-party QR library or
        to feed into the Bakong payment-verification API.

        Args:
            amount: Transaction amount.
            bill_number: Unique reference ID. Auto-generated when omitted.
            store_label: Store label.
            terminal_label: Terminal label.
            mobile_number: Merchant phone number.
            static: ``True`` for a static QR.

        Returns:
            ``(payload_string, bill_number)`` tuple.

        Raises:
            :class:`~bakong_khqr_image.exceptions.InvalidAmountError`:
                If *amount* is negative.

        Example::

            payload, ref_id = khqr.generate_payload(amount=1.00)
            md5 = khqr.md5(payload)
        """
        self._validate_amount(amount)

        options = QROptions(
            bill_number=bill_number,
            store_label=store_label,
            terminal_label=terminal_label,
            mobile_number=mobile_number,
            static=static,
        )
        return self._payload_builder.build(amount, options)

    @staticmethod
    def md5(payload: str) -> str:
        """Compute the MD5 hash of a KHQR payload.

        The Bakong payment-status API requires the MD5 of the QR string
        to look up a transaction.

        Args:
            payload: A KHQR payload string returned by :meth:`generate_payload`.

        Returns:
            Lowercase 32-character hex MD5 digest.

        Example::

            payload, _ = khqr.generate_payload(amount=2.00)
            hash_value = KHQRImage.md5(payload)
        """
        return hashlib.md5(payload.encode()).hexdigest()

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _validate_amount(amount: float) -> None:
        if amount < 0:
            raise InvalidAmountError(amount)
