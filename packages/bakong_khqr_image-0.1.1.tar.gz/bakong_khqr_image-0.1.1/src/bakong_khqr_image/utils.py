"""Low-level EMV / KHQR payload helpers."""

from __future__ import annotations


# Bakong GUID used in the acquiring-bank merchant account tag (Tag 15).
BAKONG_GUID = "www.bakong.nbc.org.kh"


def format_tlv(tag: str, value: str) -> str:
    """Encode a single EMV Tag-Length-Value field.

    Args:
        tag: Two-digit tag identifier string (e.g. ``"00"``).
        value: Raw string value to encode.

    Returns:
        Formatted TLV string, e.g. ``"0002"`` + ``value``.
    """
    return f"{tag}{len(value):02d}{value}"


def calculate_crc16(data: str) -> str:
    """Compute a CRC-CCITT (0xFFFF) checksum over *data*.

    This follows the EMV QR specification used by KHQR.

    Args:
        data: The partial payload string ending with ``"6304"``.

    Returns:
        Four-character uppercase hex string, e.g. ``"AB12"``.
    """
    crc = 0xFFFF
    polynomial = 0x1021

    for byte in data.encode("utf-8"):
        crc ^= byte << 8
        for _ in range(8):
            if crc & 0x8000:
                crc = (crc << 1) ^ polynomial
            else:
                crc <<= 1
            crc &= 0xFFFF

    return f"{crc:04X}"


def format_amount(amount: float, currency: str) -> str:
    """Format *amount* for display on the QR card.

    * **USD** → ``"1,000.50"`` (comma thousands, period decimal)
    * **KHR** → ``"1,000"`` (no decimals)

    Args:
        amount: The transaction amount.
        currency: ``"USD"`` or ``"KHR"``.

    Returns:
        Locale-style formatted string.
    """
    if currency.upper() == "USD":
        integer_part, decimal_part = f"{amount:.2f}".split(".")
        formatted_integer = f"{int(integer_part):,}"
        return f"{formatted_integer}.{decimal_part}"
    return f"{amount:,.0f}"
