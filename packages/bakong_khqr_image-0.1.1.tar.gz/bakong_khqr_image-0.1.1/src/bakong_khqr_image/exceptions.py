"""Custom exceptions for bakong-khqr-image."""


class BakongKHQRError(Exception):
    """Base exception for all bakong-khqr-image errors."""


class MissingDependencyError(BakongKHQRError):
    """Raised when an optional dependency is not installed."""

    def __init__(self, package: str) -> None:
        super().__init__(
            f"Required package '{package}' is not installed. "
            f"Install it with: pip install {package}"
        )


class InvalidCurrencyError(BakongKHQRError):
    """Raised when an unsupported currency code is supplied."""

    def __init__(self, currency: str) -> None:
        super().__init__(
            f"Unsupported currency '{currency}'. Accepted values: 'USD', 'KHR'."
        )


class InvalidAmountError(BakongKHQRError):
    """Raised when a negative amount is supplied."""

    def __init__(self, amount: float) -> None:
        super().__init__(f"Amount must be >= 0, got {amount}.")
