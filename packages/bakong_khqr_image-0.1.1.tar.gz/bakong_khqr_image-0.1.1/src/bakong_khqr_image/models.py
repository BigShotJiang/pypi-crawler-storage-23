"""Value objects and data-transfer types used across the library."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class Currency(str, Enum):
    """Supported Bakong transaction currencies."""

    USD = "USD"
    KHR = "KHR"

    @classmethod
    def from_str(cls, value: str) -> "Currency":
        """Parse a currency string or ISO-4217 numeric code.

        Args:
            value: ``"USD"``, ``"KHR"``, ``"840"`` (USD) or ``"116"`` (KHR).

        Returns:
            The matching :class:`Currency` member.

        Raises:
            :class:`~bakong_khqr_image.exceptions.InvalidCurrencyError`:
                If the value cannot be mapped.
        """
        from bakong_khqr_image.exceptions import InvalidCurrencyError

        mapping = {"USD": cls.USD, "840": cls.USD, "KHR": cls.KHR, "116": cls.KHR}
        result = mapping.get(value.upper())
        if result is None:
            raise InvalidCurrencyError(value)
        return result

    @property
    def iso_code(self) -> str:
        """ISO-4217 numeric code (``"840"`` for USD, ``"116"`` for KHR)."""
        return "840" if self == Currency.USD else "116"


@dataclass(frozen=True)
class MerchantInfo:
    """Immutable merchant configuration used for every QR generation call.

    Args:
        bakong_account_id: Bakong account ID (e.g. ``"merchant@bank"``).
        merchant_name: Display name shown on the QR card (max ~25 chars looks best).
        merchant_city: City name encoded in the payload (default ``"Phnom Penh"``).
        currency: Transaction currency (default ``Currency.USD``).
    """

    bakong_account_id: str
    merchant_name: str
    merchant_city: str = "Phnom Penh"
    currency: Currency = Currency.USD


@dataclass
class QROptions:
    """Optional metadata attached to a single QR generation call.

    All fields are optional – omit any you do not need.

    Args:
        bill_number: Unique bill / reference ID. Auto-generated when ``None``.
        store_label: Human-readable store label shown in the Bakong app.
        terminal_label: Terminal identifier.
        mobile_number: Merchant mobile number.
        static: When ``True`` the QR is *static* (no fixed amount); when
            ``False`` (default) it is *dynamic* (amount encoded in payload).
    """

    bill_number: Optional[str] = None
    store_label: Optional[str] = None
    terminal_label: Optional[str] = None
    mobile_number: Optional[str] = None
    static: bool = False
