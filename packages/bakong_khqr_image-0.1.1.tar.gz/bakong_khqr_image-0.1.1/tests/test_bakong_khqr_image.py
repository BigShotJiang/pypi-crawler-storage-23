"""Unit tests for bakong-khqr-image."""

from __future__ import annotations

import pytest

from bakong_khqr_image import KHQRImage, Currency
from bakong_khqr_image.exceptions import InvalidAmountError, InvalidCurrencyError
from bakong_khqr_image.models import MerchantInfo, QROptions
from bakong_khqr_image.payload import PayloadBuilder
from bakong_khqr_image.utils import calculate_crc16, format_amount, format_tlv


# ---------------------------------------------------------------------------
# Helpers / fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def khqr() -> KHQRImage:
    return KHQRImage(
        bakong_account_id="merchant@aclb",
        merchant_name="Test Shop",
        merchant_city="Phnom Penh",
        currency="USD",
    )


@pytest.fixture
def merchant() -> MerchantInfo:
    return MerchantInfo(
        bakong_account_id="merchant@aclb",
        merchant_name="Test Shop",
        currency=Currency.USD,
    )


# ---------------------------------------------------------------------------
# utils.py
# ---------------------------------------------------------------------------

class TestFormatTlv:
    def test_basic(self):
        assert format_tlv("00", "01") == "000201"

    def test_length_padding(self):
        result = format_tlv("59", "AB")
        assert result == "590" + "2AB"  # length 2, zero-padded to 2 digits

    def test_longer_value(self):
        result = format_tlv("59", "A" * 15)
        assert result.startswith("5915")


class TestFormatAmount:
    def test_usd_cents(self):
        assert format_amount(0.01, "USD") == "0.01"

    def test_usd_thousands(self):
        assert format_amount(1234.56, "USD") == "1,234.56"

    def test_khr_no_decimal(self):
        assert format_amount(4000, "KHR") == "4,000"

    def test_usd_zero(self):
        assert format_amount(0.0, "USD") == "0.00"


class TestCalculateCrc16:
    def test_returns_4_chars(self):
        data = "000201" + "6304"
        crc = calculate_crc16(data)
        assert len(crc) == 4

    def test_returns_uppercase_hex(self):
        data = "000201" + "6304"
        crc = calculate_crc16(data)
        assert crc == crc.upper()
        int(crc, 16)  # must be valid hex


# ---------------------------------------------------------------------------
# models.py
# ---------------------------------------------------------------------------

class TestCurrency:
    def test_from_str_usd(self):
        assert Currency.from_str("USD") == Currency.USD

    def test_from_str_khr(self):
        assert Currency.from_str("KHR") == Currency.KHR

    def test_from_str_numeric_usd(self):
        assert Currency.from_str("840") == Currency.USD

    def test_from_str_numeric_khr(self):
        assert Currency.from_str("116") == Currency.KHR

    def test_from_str_invalid(self):
        with pytest.raises(InvalidCurrencyError):
            Currency.from_str("EUR")

    def test_iso_code_usd(self):
        assert Currency.USD.iso_code == "840"

    def test_iso_code_khr(self):
        assert Currency.KHR.iso_code == "116"


# ---------------------------------------------------------------------------
# payload.py
# ---------------------------------------------------------------------------

class TestPayloadBuilder:
    def test_returns_tuple(self, merchant):
        builder = PayloadBuilder(merchant)
        result = builder.build(1.50)
        assert isinstance(result, tuple)
        assert len(result) == 2

    def test_payload_starts_with_format_indicator(self, merchant):
        builder = PayloadBuilder(merchant)
        payload, _ = builder.build(1.50)
        assert payload.startswith("000201")

    def test_payload_ends_with_crc(self, merchant):
        builder = PayloadBuilder(merchant)
        payload, _ = builder.build(1.50)
        assert payload[-8:-4] == "6304"
        crc_part = payload[-4:]
        int(crc_part, 16)  # must be valid hex

    def test_bill_number_auto_generated(self, merchant):
        builder = PayloadBuilder(merchant)
        _, bill = builder.build(1.00)
        assert bill.startswith("KHQR")

    def test_bill_number_preserved(self, merchant):
        builder = PayloadBuilder(merchant)
        opts = QROptions(bill_number="CUSTOM123")
        _, bill = builder.build(1.00, opts)
        assert bill == "CUSTOM123"

    def test_static_qr_has_no_amount(self, merchant):
        builder = PayloadBuilder(merchant)
        opts = QROptions(static=True)
        payload, _ = builder.build(5.00, opts)
        # Tag 54 (amount) must NOT be present for static QR
        assert "5406" not in payload  # "54" + 2-digit length + value

    def test_dynamic_qr_contains_amount(self, merchant):
        builder = PayloadBuilder(merchant)
        payload, _ = builder.build(1.50)
        # payload should contain "1.50" somewhere
        assert "1.50" in payload

    def test_khr_amount_no_decimal(self):
        khr_merchant = MerchantInfo(
            bakong_account_id="m@aclb", merchant_name="Shop", currency=Currency.KHR
        )
        builder = PayloadBuilder(khr_merchant)
        payload, _ = builder.build(4000)
        assert "4000" in payload


# ---------------------------------------------------------------------------
# KHQRImage (high-level API)
# ---------------------------------------------------------------------------

class TestKHQRImage:
    def test_invalid_currency_raises(self):
        with pytest.raises(InvalidCurrencyError):
            KHQRImage("id@bank", "Shop", currency="EUR")

    def test_negative_amount_raises(self, khqr):
        with pytest.raises(InvalidAmountError):
            khqr.generate_payload(amount=-1.0)

    def test_generate_payload_returns_strings(self, khqr):
        payload, ref_id = khqr.generate_payload(amount=1.50)
        assert isinstance(payload, str)
        assert isinstance(ref_id, str)

    def test_generate_payload_zero_amount(self, khqr):
        payload, _ = khqr.generate_payload(amount=0)
        assert isinstance(payload, str)

    def test_md5_returns_32_chars(self, khqr):
        payload, _ = khqr.generate_payload(amount=1.00)
        digest = KHQRImage.md5(payload)
        assert len(digest) == 32
        assert digest == digest.lower()

    def test_generate_image_returns_result(self, khqr):
        from bakong_khqr_image.renderer import QRImageResult
        result = khqr.generate_image(amount=2.50)
        assert isinstance(result, QRImageResult)

    def test_generate_image_to_bytes(self, khqr):
        result = khqr.generate_image(amount=2.50)
        data = result.to_bytes()
        assert isinstance(data, bytes)
        assert data[:4] == b"\x89PNG"  # valid PNG header

    def test_generate_image_to_base64(self, khqr):
        import base64
        result = khqr.generate_image(amount=2.50)
        encoded = result.to_base64()
        decoded = base64.b64decode(encoded)
        assert decoded[:4] == b"\x89PNG"

    def test_generate_image_to_data_uri(self, khqr):
        result = khqr.generate_image(amount=2.50)
        uri = result.to_data_uri()
        assert uri.startswith("data:image/png;base64,")

    def test_save_png(self, khqr, tmp_path):
        path = str(tmp_path / "card.png")
        result = khqr.generate_image(amount=1.00)
        saved = result.save_png(path)
        assert saved == path
        import os
        assert os.path.exists(saved)

    def test_save_jpeg(self, khqr, tmp_path):
        path = str(tmp_path / "card.jpg")
        result = khqr.generate_image(amount=1.00)
        saved = result.save_jpeg(path)
        assert saved == path

    def test_save_webp(self, khqr, tmp_path):
        path = str(tmp_path / "card.webp")
        result = khqr.generate_image(amount=1.00)
        saved = result.save_webp(path)
        assert saved == path

    def test_khr_image(self):
        khqr = KHQRImage("merchant@aclb", "ហាងកាហ្វេ", currency="KHR")
        result = khqr.generate_image(amount=4000)
        assert result.to_bytes()[:4] == b"\x89PNG"

    def test_static_qr_image(self, khqr):
        result = khqr.generate_image(amount=0, static=True)
        assert result.to_bytes()[:4] == b"\x89PNG"
