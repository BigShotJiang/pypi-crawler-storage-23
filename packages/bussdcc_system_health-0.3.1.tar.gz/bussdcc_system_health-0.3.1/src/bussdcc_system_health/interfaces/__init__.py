from .system import SystemWebInterface

__all__ = [
    "SystemWebInterface",
]
