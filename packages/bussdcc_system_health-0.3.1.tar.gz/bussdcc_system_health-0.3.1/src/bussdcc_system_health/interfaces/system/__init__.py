from .interface import SystemWebInterface

__all__ = [
    "SystemWebInterface",
]
