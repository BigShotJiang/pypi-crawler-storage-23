"""INAV Toolkit - Blackbox analyzer, parameter checker, and tuning wizard for INAV flight controllers."""

__version__ = "2.15.0"
