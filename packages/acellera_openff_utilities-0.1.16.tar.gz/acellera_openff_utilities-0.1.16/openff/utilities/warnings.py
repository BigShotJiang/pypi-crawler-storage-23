class CondaExecutableNotFoundWarning(UserWarning):
    """
    A conda (or mamba/micromamba) executable is not found.
    """
