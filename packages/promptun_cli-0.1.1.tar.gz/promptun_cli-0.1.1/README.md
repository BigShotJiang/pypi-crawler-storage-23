# Promptun CLI 🛸

O **Promptun CLI** é o seu centro de comando para engenharia de prompts. Versionamento, colaboração e produtividade direto no terminal.

## Funcionalidades

- **Push/Pull:** Sincronize seus prompts locais com a plataforma PromptHub.
- **Versionamento:** Detecção automática de mudanças via Hash e suporte a versionamento semântico.
- **Git-like:** Comandos familiares como `init`, `clone`, `history`, `revert` e `log`.
- **System Prompt:** Suporte total para separação de contexto do sistema e templates do usuário.

## Instalação Rápida

```bash
pip install promptun-cli
```

## Começando

1. Faça login: `promptun login`
2. Inicialize um projeto: `promptun init meu-repo`
3. Envie seus prompts: `promptun push -m "Primeiro commit"`

Para documentação completa, visite: [Documentação CLI](http://localhost:3000/docs/cli)
