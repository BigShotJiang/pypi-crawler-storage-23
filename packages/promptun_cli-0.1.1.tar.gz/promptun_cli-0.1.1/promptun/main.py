import typer
from rich.console import Console
from promptun.commands import auth, sync

app = typer.Typer(
    name="promptun",
    help="PromptHub CLI - Git for Prompts",
    add_completion=False
)

# Register sub-commands
app.add_typer(auth.app, name="auth", help="Manage authentication")

# Shortcuts for auth commands at root level (optional, but convenient: `promptun login`)
app.command(name="login")(auth.login)
app.command(name="logout")(auth.logout)
app.command(name="whoami")(auth.whoami)

# Sync commands
app.command(name="init")(sync.init)
app.command(name="push")(sync.push)
app.command(name="pull")(sync.pull)
app.command(name="clone")(sync.clone)
app.command(name="log")(sync.log)
app.command(name="revert")(sync.revert)
app.command(name="rm")(sync.rm)
app.command(name="history")(sync.history)

@app.command()
def version():
    """
    Show CLI version.
    """
    console = Console()
    console.print("PromptHub CLI v0.1.0")

if __name__ == "__main__":
    app()
