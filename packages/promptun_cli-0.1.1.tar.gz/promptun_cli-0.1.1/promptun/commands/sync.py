import typer
import yaml
import glob
import os
from pathlib import Path
from rich.console import Console
from rich.table import Table
import requests
from promptun import config, utils

console = Console()
app = typer.Typer(help="Manage prompt synchronization")

@app.command()
def init(name: str = typer.Argument(..., help="Project slug/name")):
    """
    Initialize a new PromptHub project in the current directory.
    """
    if (Path('.') / 'prompthub.yaml').exists():
        console.print("[red]prompthub.yaml already exists![/red]")
        raise typer.Exit(1)
    
    utils.create_project_config(name)
    console.print(f"[green]Initialized project '{name}' in prompthub.yaml[/green]")
    console.print("You can now add .prompt.md files and run 'promptun push'.")

@app.command()
def push(
    message: str = typer.Option(None, "--message", "-m", help="Commit message (changelog)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate without sending to server")
):
    """
    Upload prompts to PromptHub.
    """
    # 1. Load Config
    project_conf = utils.get_project_config()
    if not project_conf:
        console.print("[red]No prompthub.yaml found. Run 'promptun init <name>' first.[/red]")
        raise typer.Exit(1)

    collection_slug = project_conf.get('project')
    
    # 2. Find Files
    # Simple glob implementation for now.
    patterns = project_conf.get('include', ['**/*.prompt.md'])
    files = []
    for pattern in patterns:
        files.extend(glob.glob(pattern, recursive=True))
    
    # 3. Parse Files (and map slug -> path)
    prompts_payload = []
    slug_to_path = {}
    
    table = Table(title=f"Pushing to collection: {collection_slug}")
    table.add_column("File", style="cyan")
    table.add_column("Slug", style="magenta")
    table.add_column("Version", style="green")
    table.add_column("Status", style="white")

    for f_path in files:
        path_obj = Path(f_path)
        try:
            data = utils.parse_prompt_file(path_obj)
            meta = data['meta']
            content = data['content']
            
            slug = meta.get('slug', path_obj.stem)
            slug_to_path[slug] = path_obj

            # Prepare payload object
            payload = {
                'slug': slug,
                'title': meta.get('title', slug),
                'version': str(meta.get('version', '0.0.1')),
                'description': meta.get('description', ''),
                'tags': meta.get('tags', []),
                'area': meta.get('area'), # Optional
                'is_public': not meta.get('private', True), # Default private?
                'content': {
                    'user': content,
                    'system': meta.get('system_prompt', '') # Support system prompt in frontmatter
                },
                'config': meta.get('config', {})
            }
            prompts_payload.append(payload)
            table.add_row(f_path, payload['slug'], payload['version'], "Parsed OK")
            
        except Exception as e:
            table.add_row(f_path, "???", "???", f"[red]Error: {e}[/red]")

    console.print(table)

    if not prompts_payload:
        console.print("[yellow]No valid prompts found to push.[/yellow]")
        raise typer.Exit()

    if dry_run:
        console.print("[yellow]Dry run complete. Nothing sent.[/yellow]")
        return

    # 4. Send to API
    token = config.get_token()
    host = config.get_host()
    
    if not token:
        console.print("[red]Not logged in. Run 'promptun login' first.[/red]")
        raise typer.Exit(1)

    with console.status(f"Uploading {len(prompts_payload)} prompts..."):
        try:
            response = requests.post(
                f"{host}/api/cli/v1/push",
                json={
                    'collection': collection_slug, 
                    'prompts': prompts_payload,
                    'message': message
                },
                headers={"Authorization": f"Bearer {token}"}
            )
            
            if response.status_code == 200:
                result = response.json()
                console.print(f"[bold green]Success![/bold green] Processed {len(result.get('results', []))} items.")
                
                for res in result.get('results', []):
                    slug = res['slug']
                    new_version = res.get('version')
                    status_text = res['status']
                    
                    status_color = "green" if status_text == 'updated' else "yellow"
                    msg = f"  - {slug}: [{status_color}]{status_text}[/{status_color}] (v{new_version})"
                    
                    # Auto-update local file if version changed
                    if status_text == 'updated' and slug in slug_to_path:
                         original_payload = next((p for p in prompts_payload if p['slug'] == slug), None)
                         if original_payload and original_payload['version'] != new_version:
                             # Update local file
                             f_path = slug_to_path[slug]
                             try:
                                 # Re-read to ensure we don't lose anything, or just use payload?
                                 # Using payload is safer for structure but let's just update the version in the dict we have
                                 file_data = utils.parse_prompt_file(f_path)
                                 file_data['meta']['version'] = new_version
                                 # We need to preserve content exactly as is in file or what we parsed?
                                 # parse_prompt_file returns 'content' as string body.
                                 # utils.dump_prompt_file expects 'content': {'user': ...} or just uses data structure
                                 # Let's adjust utils.dump_prompt_file call to match what parse returns + update
                                 
                                 # Wait, utils.dump_prompt_file expects the unified dict format used in 'pull'.
                                 # Let's construct it correctly.
                                 dump_data = {
                                     'slug': slug,
                                     'version': new_version,
                                     'description': file_data['meta'].get('description'),
                                     'tags': file_data['meta'].get('tags'),
                                     'area': file_data['meta'].get('area'),
                                     'config': file_data['meta'].get('config'),
                                     'content': {
                                         'user': file_data['content'],
                                         'system': file_data['meta'].get('system_prompt')
                                     }
                                 }
                                 utils.dump_prompt_file(f_path, dump_data)
                                 msg += " [blue](Local file updated)[/blue]"
                             except Exception as e:
                                 msg += f" [red](Failed to update local file: {e})[/red]"

                    console.print(msg)
            else:
                console.print(f"[red]Upload failed ({response.status_code}):[/red] {response.text}")
                
        except Exception as e:
            console.print(f"[red]Network error:[/red] {e}")

@app.command()
def pull(
    collection: str = typer.Argument(None, help="Collection slug to pull from. Defaults to current project."),
    force: bool = typer.Option(False, "--force", "-f", help="Overwrite local files without asking")
):
    """
    Download prompts from PromptHub to local files.
    """
    # 1. Determine Collection
    project_conf = utils.get_project_config()
    author = None
    
    if not collection:
        if not project_conf:
            console.print("[red]No collection specified and no prompthub.yaml found.[/red]")
            console.print("Usage: promptun pull <collection-slug>")
            raise typer.Exit(1)
        collection = project_conf.get('project')
        author = project_conf.get('author')
    else:
        # User passed an argument, might be a URL/shorthand
        collection, author = utils.parse_repo_string(collection)

    # 2. Auth
    token = config.get_token()
    host = config.get_host()
    if not token:
        console.print("[red]Not logged in.[/red]")
        raise typer.Exit(1)

    # 3. Fetch
    params = {'collection': collection}
    if author:
        params['author'] = author

    with console.status(f"Fetching prompts from '{collection}'..."):
        try:
            response = requests.get(
                f"{host}/api/cli/v1/pull",
                params=params,
                headers={"Authorization": f"Bearer {token}"}
            )
            
            if response.status_code != 200:
                console.print(f"[red]Failed to pull ({response.status_code}):[/red] {response.text}")
                raise typer.Exit(1)
            
            data = response.json()
            prompts = data.get('prompts', [])
            
        except Exception as e:
            console.print(f"[red]Network error:[/red] {e}")
            raise typer.Exit(1)

    # 4. Initialize if needed
    if not project_conf:
        if typer.confirm(f"Initialize new project '{collection}' in current directory?"):
            api_author = data.get('author') or author
            utils.create_project_config(collection, author=api_author)
            project_conf = utils.get_project_config() # Reload config
        else:
            console.print("Aborted.")
            raise typer.Exit(1)

    # 4.5 Scan for existing files to map Slug -> FilePath
    # This prevents creating duplicates if local filename != slug.prompt.md
    existing_files_map = {}
    if project_conf:
        patterns = project_conf.get('include', ['**/*.prompt.md'])
        local_candidates = []
        for pattern in patterns:
            local_candidates.extend(glob.glob(pattern, recursive=True))
        
        for f_path in local_candidates:
            try:
                # We need to parse just the frontmatter to get the slug
                # We can reuse utils.parse_prompt_file, though it reads content too (acceptable overhead)
                p_data = utils.parse_prompt_file(Path(f_path))
                f_slug = p_data.get('meta', {}).get('slug')
                if f_slug:
                    existing_files_map[f_slug] = Path(f_path)
            except Exception:
                pass # Ignore malformed files during this scan

    # 5. Write Files
    table = Table(title=f"Pulling from: {collection}")
    table.add_column("Slug", style="cyan")
    table.add_column("File", style="magenta")
    table.add_column("Version", style="green")
    table.add_column("Action", style="white")

    for p_data in prompts:
        slug = p_data['slug']
        
        # Determine target file path
        if slug in existing_files_map:
            file_path = existing_files_map[slug]
            action = "Updated"
        else:
            filename = f"{slug}.prompt.md"
            file_path = Path(filename)
            action = "Created"

        if file_path.exists() and action == "Created":
             # Edge case: file exists but slug wasn't in it (or parse failed), 
             # OR slug matches but we didn't catch it for some reason.
             # If filename matches default but wasn't mapped (e.g. empty slug in file), we overwrite.
             if not force:
                 action = "Updated"
             else:
                 action = "Overwritten"

        try:
            utils.dump_prompt_file(file_path, p_data)
            table.add_row(slug, str(file_path), p_data['version'], f"[green]{action}[/green]")
        except Exception as e:
             table.add_row(slug, str(file_path), "error", f"[red]{e}[/red]")

    console.print(table)
    console.print(f"[bold green]Done![/bold green] Synced {len(prompts)} prompts.")

@app.command()
def clone(
    repo: str = typer.Argument(..., help="Collection URL or 'user/slug' to clone.")
):
    """
    Clone a remote collection into a new directory.
    Accepts:
    - Full URL: http://domain/username/collections/slug
    - Shorthand: username/slug
    - Slug only: slug (assumes your user)
    """
    collection_slug, author = utils.parse_repo_string(repo)
    target_dir = Path(collection_slug)
    
    # 1. Check Dir
    if target_dir.exists():
        console.print(f"[red]Directory '{collection_slug}' already exists.[/red]")
        raise typer.Exit(1)
    
    # 2. Auth Check
    token = config.get_token()
    host = config.get_host()
    if not token:
        console.print("[red]Not logged in. Run 'promptun login' first.[/red]")
        raise typer.Exit(1)

    # 3. Create Dir & Config
    try:
        target_dir.mkdir(parents=True)
    except Exception as e:
        console.print(f"[red]Failed to create directory:[/red] {e}")
        raise typer.Exit(1)

    # 4. Fetch Prompts
    params = {'collection': collection_slug}
    if author:
        params['author'] = author

    with console.status(f"Cloning '{collection_slug}'..."):
        try:
            response = requests.get(
                f"{host}/api/cli/v1/pull",
                params=params,
                headers={"Authorization": f"Bearer {token}"}
            )
            
            if response.status_code != 200:
                console.print(f"[red]Failed to clone ({response.status_code}):[/red] {response.text}")
                # Cleanup
                import shutil
                if target_dir.exists():
                    shutil.rmtree(target_dir)
                raise typer.Exit(1)
            
            data = response.json()
            prompts = data.get('prompts', [])
            real_author = data.get('author')
            
        except Exception as e:
            console.print(f"[red]Network error:[/red] {e}")
            import shutil
            if target_dir.exists():
                shutil.rmtree(target_dir)
            raise typer.Exit(1)

    # 3b. Create Config
    utils.create_project_config(collection_slug, author=real_author, root=target_dir)
    console.print(f"[green]Initialized project in {target_dir}/ (Author: {real_author})[/green]")

    # 5. Write Files into Target Dir
    table = Table(title=f"Cloning: {collection_slug}")
    table.add_column("Slug", style="cyan")
    table.add_column("File", style="magenta")
    table.add_column("Version", style="green")

    for p_data in prompts:
        slug = p_data['slug']
        filename = f"{slug}.prompt.md"
        file_path = target_dir / filename
        
        try:
            utils.dump_prompt_file(file_path, p_data)
            table.add_row(slug, str(file_path), p_data['version'])
        except Exception as e:
             table.add_row(slug, str(file_path), f"[red]Error: {e}[/red]")

    console.print(table)
    console.print(f"[bold green]Cloned successfully![/bold green] 'cd {collection_slug}' to start working.")

@app.command()
def log(slug: str = typer.Argument(..., help="Prompt slug")):
    """
    Show version history for a prompt.
    """
    token = config.get_token()
    host = config.get_host()
    if not token:
        console.print("[red]Not logged in.[/red]")
        raise typer.Exit(1)

    try:
        response = requests.get(
            f"{host}/api/cli/v1/log",
            params={'slug': slug},
            headers={"Authorization": f"Bearer {token}"}
        )
        
        if response.status_code != 200:
            console.print(f"[red]Error ({response.status_code}):[/red] {response.text}")
            raise typer.Exit(1)
            
        history = response.json()
        
        table = Table(title=f"History: {slug}")
        table.add_column("Version", style="green")
        table.add_column("Date", style="cyan")
        table.add_column("Changelog", style="white")
        
        for entry in history:
            date_str = entry['created_at'].split('T')[0]
            table.add_row(entry['version'], date_str, entry['changelog'])
            
        console.print(table)

    except Exception as e:
        console.print(f"[red]Network error:[/red] {e}")

@app.command()
def revert(
    slug: str = typer.Argument(..., help="Prompt slug"),
    version: str = typer.Argument(..., help="Version to revert to")
):
    """
    Revert a prompt to a specific version (overwrites local file).
    """
    token = config.get_token()
    host = config.get_host()
    if not token:
        console.print("[red]Not logged in.[/red]")
        raise typer.Exit(1)

    # 1. Fetch content
    with console.status(f"Fetching {slug} v{version}..."):
        try:
            response = requests.get(
                f"{host}/api/cli/v1/get",
                params={'slug': slug, 'version': version},
                headers={"Authorization": f"Bearer {token}"}
            )
            
            if response.status_code != 200:
                console.print(f"[red]Error ({response.status_code}):[/red] {response.text}")
                raise typer.Exit(1)
                
            data = response.json()
            
        except Exception as e:
            console.print(f"[red]Network error:[/red] {e}")
            raise typer.Exit(1)

    # 2. Find local file
    # We scan to match slug, similar to pull
    target_file = Path(f"{slug}.prompt.md") # Default
    
    project_conf = utils.get_project_config()
    if project_conf:
        patterns = project_conf.get('include', ['**/*.prompt.md'])
        local_candidates = []
        for pattern in patterns:
            local_candidates.extend(glob.glob(pattern, recursive=True))
        
        for f_path in local_candidates:
            try:
                p_data = utils.parse_prompt_file(Path(f_path))
                if p_data.get('meta', {}).get('slug') == slug:
                    target_file = Path(f_path)
                    break
            except: pass

    # 3. Write
    try:
        utils.dump_prompt_file(target_file, data)
        console.print(f"[bold green]Success![/bold green] Reverted {target_file} to v{version}.")
    except Exception as e:
        console.print(f"[red]Failed to write file:[/red] {e}")

@app.command()
def rm(slug: str = typer.Argument(..., help="Prompt slug to delete")):
    """
    Delete a prompt from the server AND locally.
    """
    token = config.get_token()
    host = config.get_host()
    if not token:
        console.print("[red]Not logged in.[/red]")
        raise typer.Exit(1)

    if not typer.confirm(f"Are you sure you want to DELETE '{slug}' from the server? This cannot be undone via CLI."):
        raise typer.Exit()

    # 1. Delete remote
    with console.status(f"Deleting {slug} remote..."):
        try:
            response = requests.delete(
                f"{host}/api/cli/v1/delete",
                params={'slug': slug},
                headers={"Authorization": f"Bearer {token}"}
            )
            
            if response.status_code != 200:
                console.print(f"[red]Error ({response.status_code}):[/red] {response.text}")
                raise typer.Exit(1)
                
        except Exception as e:
            console.print(f"[red]Network error:[/red] {e}")
            raise typer.Exit(1)

    # 2. Delete local
    target_file = None
    project_conf = utils.get_project_config()
    if project_conf:
        patterns = project_conf.get('include', ['**/*.prompt.md'])
        local_candidates = []
        for pattern in patterns:
            local_candidates.extend(glob.glob(pattern, recursive=True))
        
        for f_path in local_candidates:
            try:
                p_data = utils.parse_prompt_file(Path(f_path))
                if p_data.get('meta', {}).get('slug') == slug:
                    target_file = Path(f_path)
                    break
            except: pass
    
    if not target_file:
        target_file = Path(f"{slug}.prompt.md")

    if target_file.exists():
        try:
            os.remove(target_file)
            console.print(f"[green]Deleted local file: {target_file}[/green]")
        except Exception as e:
            console.print(f"[red]Failed to delete local file:[/red] {e}")
    else:
        console.print("[yellow]Local file not found, but remote deleted.[/yellow]")

    console.print(f"[bold green]Prompt '{slug}' deleted successfully.[/bold green]")

@app.command()
def history(
    collection: str = typer.Argument(None, help="Collection slug (optional)")
):
    """
    Show status of all prompts in the collection (Active & Deleted).
    """
    # 1. Determine Collection
    project_conf = utils.get_project_config()
    
    if not collection:
        if not project_conf:
            console.print("[red]No collection specified and no prompthub.yaml found.[/red]")
            raise typer.Exit(1)
        collection = project_conf.get('project')

    token = config.get_token()
    host = config.get_host()
    if not token:
        console.print("[red]Not logged in.[/red]")
        raise typer.Exit(1)

    try:
        response = requests.get(
            f"{host}/api/cli/v1/history",
            params={'collection': collection},
            headers={"Authorization": f"Bearer {token}"}
        )
        
        if response.status_code != 200:
            console.print(f"[red]Error ({response.status_code}):[/red] {response.text}")
            raise typer.Exit(1)
            
        data = response.json()
        
        table = Table(title=f"Collection History: {collection}")
        table.add_column("Slug", style="cyan")
        table.add_column("Status", style="bold")
        table.add_column("Latest Ver", style="green")
        table.add_column("Last Updated", style="white")
        
        for item in data:
            status_style = "green" if item['status'] == 'Active' else "red"
            date_str = item['updated_at'].split('T')[0]
            table.add_row(
                item['slug'], 
                f"[{status_style}]{item['status']}[/{status_style}]", 
                item['latest_version'],
                date_str
            )
            
        console.print(table)

    except Exception as e:
        console.print(f"[red]Network error:[/red] {e}")

