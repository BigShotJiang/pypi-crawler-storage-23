import typer
import requests
from rich.console import Console
from promptun import config

console = Console()

app = typer.Typer(help="Manage authentication for PromptHub CLI")

@app.command()
def login(
    host: str = typer.Option(config.DEFAULT_HOST, help="PromptHub API URL"),
    token: str = typer.Option(None, help="Personal Access Token (create one at /settings/tokens)")
):
    """
    Authenticate with PromptHub.
    """
    if not token:
        console.print(f"[bold blue]Welcome to PromptHub CLI![/bold blue]")
        console.print(f"Please enter your Personal Access Token.")
        console.print(f"You can generate one at: [underline]{host}/settings/tokens[/underline]")
        token = typer.prompt("Token", hide_input=True)

    # Verify token
    try:
        with console.status("[bold green]Verifying token..."):
            response = requests.get(
                f"{host}/api/cli/v1/check",
                headers={"Authorization": f"Bearer {token}"},
                timeout=10
            )
        
        if response.status_code == 200:
            data = response.json()
            user = data.get('user', 'Unknown')
            config.set_auth(token, host)
            console.print(f"[bold green]Success![/bold green] Logged in as [bold]{user}[/bold].")
        else:
            console.print(f"[bold red]Login failed![/bold red] Server returned: {response.status_code}")
            if response.status_code == 401:
                console.print("Invalid token.")
    except Exception as e:
        console.print(f"[bold red]Connection error:[/bold red] {e}")

@app.command()
def logout():
    """
    Remove local authentication credentials.
    """
    config.logout()
    console.print("[green]Logged out successfully.[/green]")

@app.command()
def whoami():
    """
    Show current logged in user.
    """
    token = config.get_token()
    host = config.get_host()
    
    if not token:
        console.print("[yellow]Not logged in.[/yellow]")
        raise typer.Exit(code=1)

    try:
        response = requests.get(
            f"{host}/api/cli/v1/check",
            headers={"Authorization": f"Bearer {token}"},
            timeout=5
        )
        if response.status_code == 200:
            data = response.json()
            console.print(f"Logged in as: [bold green]{data.get('user')}[/bold green] on {host}")
        else:
            console.print("[red]Session expired or invalid token.[/red]")
    except Exception as e:
        console.print(f"[red]Could not connect to server:[/red] {e}")
