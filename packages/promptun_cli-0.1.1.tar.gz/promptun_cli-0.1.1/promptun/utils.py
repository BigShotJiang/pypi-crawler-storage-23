import yaml
import re
from pathlib import Path
from typing import Dict, Tuple, Any

FRONTMATTER_REGEX = re.compile(r"^---\n(.*?)\n---\n(.*)", re.DOTALL)

def parse_prompt_file(file_path: Path) -> Dict[str, Any]:
    """
    Parses a markdown prompt file with YAML frontmatter.
    Returns a dict with metadata and content ('system'/'user' split logic if needed,
    or just raw content).
    
    Expected format:
    ---
    slug: my-prompt
    version: 1.0.0
    ...
    ---
    Content...
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    match = FRONTMATTER_REGEX.match(content)
    if not match:
        raise ValueError(f"File {file_path} is missing valid YAML frontmatter.")

    yaml_block = match.group(1)
    body = match.group(2).strip()

    try:
        metadata = yaml.safe_load(yaml_block)
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML in {file_path}: {e}")

    # Basic validation
    if 'slug' not in metadata:
        # Fallback to filename if slug missing? Prefer explicit.
        metadata['slug'] = file_path.stem

    # Split body into System/User if a delimiter exists?
    # For now, let's assume the body is the USER template, 
    # and SYSTEM template might be in config or separated by `---SYSTEM---` etc.
    # Or, as per user request: "System Context... Template User..."
    # Let's check if there is a convention. 
    # For now, we will treat the whole body as 'user_text' or 'template'.
    # If the user wants system prompt, maybe they put it in frontmatter 'system_prompt' 
    # or we define a separator.
    
    return {
        'meta': metadata,
        'content': body
    }

def parse_repo_string(repo_str: str) -> Tuple[str, Optional[str]]:
    """
    Parses a repository string which can be:
    1. A full URL: http://domain/username/collections/slug
    2. A shorthand: username/slug
    3. Just a slug: slug
    Returns (slug, username)
    """
    if 'http' in repo_str:
        # Assume URL format: .../username/collections/slug
        # Remove trailing slash
        repo_str = repo_str.rstrip('/')
        parts = repo_str.split('/')
        if 'collections' in parts:
            idx = parts.index('collections')
            if idx > 0 and idx < len(parts) - 1:
                username = parts[idx - 1]
                slug = parts[idx + 1]
                return slug, username
        
        # Fallback if URL structure is weird but ends in slug
        return parts[-1], None

    if '/' in repo_str:
        parts = repo_str.split('/')
        if len(parts) == 2:
            return parts[1], parts[0]
            
    return repo_str, None

def get_project_config(root: Path = Path('.')) -> Dict:
    config_path = root / 'prompthub.yaml'
    if not config_path.exists():
        return None
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)

def create_project_config(name: str, author: str = None, root: Path = Path('.')):
    config = {
        'project': name,
        'version': '0.1.0',
        'include': ['**/*.prompt.md'],
        'exclude': ['node_modules/**', '.git/**']
    }
    if author:
        config['author'] = author
        
    with open(root / 'prompthub.yaml', 'w') as f:
        yaml.safe_dump(config, f, sort_keys=False)

def dump_prompt_file(file_path: Path, data: Dict):
    """
    Writes a prompt data dictionary to a markdown file with YAML frontmatter.
    Reconstructs the format expected by parse_prompt_file.
    """
    meta = {
        'slug': data.get('slug'),
        'version': data.get('version'),
        'description': data.get('description'),
        'tags': data.get('tags', []),
        'area': data.get('area'),
        'config': data.get('config', {})
    }
    
    # Optional fields
    content_block = data.get('content', {})
    user_text = content_block.get('user', '')
    system_text = content_block.get('system', '')
    
    if system_text:
        meta['system_prompt'] = system_text

    # Clean up empty keys
    meta = {k: v for k, v in meta.items() if v}

    with open(file_path, 'w', encoding='utf-8') as f:
        f.write("---\n")
        yaml.safe_dump(meta, f, sort_keys=False, allow_unicode=True)
        f.write("---\n\n")
        f.write(user_text)


