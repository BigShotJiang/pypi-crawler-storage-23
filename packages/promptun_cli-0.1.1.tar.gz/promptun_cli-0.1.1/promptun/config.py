import os
import yaml
from pathlib import Path
from typing import Optional, Dict

APP_NAME = "promptun"
CONFIG_DIR = Path.home() / f".{APP_NAME}"
CONFIG_FILE = CONFIG_DIR / "config.yaml"

DEFAULT_HOST = "https://promptun.com"  # Production URL

def _ensure_config_dir():
    if not CONFIG_DIR.exists():
        CONFIG_DIR.mkdir(parents=True)

def load_config() -> Dict:
    if not CONFIG_FILE.exists():
        return {}
    try:
        with open(CONFIG_FILE, 'r') as f:
            return yaml.safe_load(f) or {}
    except Exception:
        return {}

def save_config(data: Dict):
    _ensure_config_dir()
    current_config = load_config()
    current_config.update(data)
    with open(CONFIG_FILE, 'w') as f:
        yaml.safe_dump(current_config, f)

def get_token() -> Optional[str]:
    config = load_config()
    return config.get('token')

def get_host() -> str:
    config = load_config()
    return config.get('host', DEFAULT_HOST)

def set_auth(token: str, host: str = DEFAULT_HOST):
    save_config({'token': token, 'host': host})

def logout():
    config = load_config()
    if 'token' in config:
        del config['token']
    # We might want to keep the host
    with open(CONFIG_FILE, 'w') as f:
        yaml.safe_dump(config, f)
