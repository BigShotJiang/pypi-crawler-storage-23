# LoCoMo benchmark for evaluating mnemory's long-term conversational memory.
#
# Based on: "Evaluating Very Long-Term Conversational Memory of LLM Agents"
# (Snap Research, ACL 2024)
# Dataset: https://github.com/snap-research/locomo
