"""mnemory — A self-hosted, two-tier memory system for AI agents and assistants."""

__version__ = "1.0.0"
