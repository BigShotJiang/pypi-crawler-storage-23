"""Tests for mnemory.categories module."""

import pytest

from mnemory.categories import (
    IMPORTANCE_WEIGHTS,
    PREDEFINED_CATEGORIES,
    VALID_MEMORY_TYPES,
    count_categories,
    matches_category_filter,
    validate_categories,
    validate_importance,
    validate_memory_type,
)

# ── validate_categories ───────────────────────────────────────────────


class TestValidateCategories:
    def test_predefined_category(self):
        assert validate_categories(["personal"]) == ["personal"]

    def test_multiple_predefined(self):
        result = validate_categories(["personal", "work", "health"])
        assert result == ["personal", "work", "health"]

    def test_project_subcategory(self):
        assert validate_categories(["project:myapp"]) == ["project:myapp"]

    def test_project_nested_subcategory(self):
        result = validate_categories(["project:domecek/k8s-manifests"])
        assert result == ["project:domecek/k8s-manifests"]

    def test_case_insensitive(self):
        assert validate_categories(["Personal"]) == ["personal"]

    def test_strips_whitespace(self):
        assert validate_categories(["  work  "]) == ["work"]

    def test_empty_strings_skipped(self):
        assert validate_categories(["", "work", "  "]) == ["work"]

    def test_empty_list(self):
        assert validate_categories([]) == []

    def test_unknown_category_raises(self):
        with pytest.raises(ValueError, match="Unknown category 'foobar'"):
            validate_categories(["foobar"])

    def test_unknown_prefix_raises(self):
        with pytest.raises(ValueError, match="Unknown category prefix 'foobar'"):
            validate_categories(["foobar:baz"])

    def test_all_predefined_accepted(self):
        result = validate_categories(list(PREDEFINED_CATEGORIES.keys()))
        assert result == list(PREDEFINED_CATEGORIES.keys())


# ── validate_memory_type ──────────────────────────────────────────────


class TestValidateMemoryType:
    @pytest.mark.parametrize("mt", VALID_MEMORY_TYPES)
    def test_valid_types(self, mt):
        assert validate_memory_type(mt) == mt

    def test_case_insensitive(self):
        assert validate_memory_type("FACT") == "fact"

    def test_strips_whitespace(self):
        assert validate_memory_type("  episodic  ") == "episodic"

    def test_invalid_raises(self):
        with pytest.raises(ValueError, match="Unknown memory_type 'invalid'"):
            validate_memory_type("invalid")


# ── validate_importance ───────────────────────────────────────────────


class TestValidateImportance:
    @pytest.mark.parametrize("level", IMPORTANCE_WEIGHTS.keys())
    def test_valid_levels(self, level):
        assert validate_importance(level) == level

    def test_case_insensitive(self):
        assert validate_importance("HIGH") == "high"

    def test_strips_whitespace(self):
        assert validate_importance("  critical  ") == "critical"

    def test_invalid_raises(self):
        with pytest.raises(ValueError, match="Unknown importance 'urgent'"):
            validate_importance("urgent")


# ── matches_category_filter ───────────────────────────────────────────


class TestMatchesCategoryFilter:
    def test_empty_filter_matches_all(self):
        assert matches_category_filter(["work"], []) is True

    def test_exact_match(self):
        assert matches_category_filter(["work"], ["work"]) is True

    def test_no_match(self):
        assert matches_category_filter(["work"], ["health"]) is False

    def test_prefix_match_project(self):
        """Filter 'project' should match 'project:myapp'."""
        assert matches_category_filter(["project:myapp"], ["project"]) is True

    def test_prefix_no_false_positive(self):
        """Filter 'project' should NOT match 'projectx'."""
        assert matches_category_filter(["projectx"], ["project"]) is False

    def test_exact_subcategory_match(self):
        assert matches_category_filter(["project:myapp"], ["project:myapp"]) is True

    def test_subcategory_no_match(self):
        assert matches_category_filter(["project:myapp"], ["project:other"]) is False

    def test_or_logic_multiple_filters(self):
        """Multiple filter categories use OR logic."""
        assert matches_category_filter(["health"], ["work", "health"]) is True

    def test_or_logic_no_match(self):
        assert matches_category_filter(["finance"], ["work", "health"]) is False

    def test_case_insensitive(self):
        assert matches_category_filter(["Work"], ["work"]) is True

    def test_empty_memory_categories(self):
        assert matches_category_filter([], ["work"]) is False


# ── count_categories ──────────────────────────────────────────────────


class TestCountCategories:
    def test_empty_list(self):
        assert count_categories([]) == {}

    def test_single_memory(self):
        memories = [{"metadata": {"categories": ["work", "technical"]}}]
        assert count_categories(memories) == {"work": 1, "technical": 1}

    def test_multiple_memories(self):
        memories = [
            {"metadata": {"categories": ["work"]}},
            {"metadata": {"categories": ["work", "technical"]}},
            {"metadata": {"categories": ["personal"]}},
        ]
        result = count_categories(memories)
        assert result == {"work": 2, "technical": 1, "personal": 1}

    def test_missing_metadata(self):
        memories = [{"id": "1"}, {"metadata": {"categories": ["work"]}}]
        assert count_categories(memories) == {"work": 1}

    def test_non_list_categories_ignored(self):
        memories = [{"metadata": {"categories": "not-a-list"}}]
        assert count_categories(memories) == {}

    def test_case_normalized(self):
        memories = [{"metadata": {"categories": ["Work", "WORK"]}}]
        assert count_categories(memories) == {"work": 2}
