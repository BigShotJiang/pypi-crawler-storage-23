"""Eval file integration for importing .eval archives into trajectory analysis."""

from .convert_to_trajectory import convert_eval_sample
