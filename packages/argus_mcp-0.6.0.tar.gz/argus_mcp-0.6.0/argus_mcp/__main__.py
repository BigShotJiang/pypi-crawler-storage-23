"""Allow running the package with `python -m argus_mcp`."""

from argus_mcp.cli import main

if __name__ == "__main__":
    main()
