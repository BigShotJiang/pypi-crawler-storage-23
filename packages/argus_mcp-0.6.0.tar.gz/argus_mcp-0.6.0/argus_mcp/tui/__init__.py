"""TUI subpackage - Textual-based terminal user interface."""

from argus_mcp.tui.app import ArgusApp

__all__ = ["ArgusApp"]
