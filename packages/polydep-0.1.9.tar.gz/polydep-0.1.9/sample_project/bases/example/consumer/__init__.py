from example.consumer import core

__all__ = ["core"]
