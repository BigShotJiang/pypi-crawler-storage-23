"""ViSP quality metrics task."""

from dataclasses import dataclass
from dataclasses import field
from typing import Iterable

import numpy as np
from astropy.time import Time
from dkist_processing_common.codecs.fits import fits_access_decoder
from dkist_processing_common.parsers.quality import L1QualityFitsAccess
from dkist_processing_common.tasks import QualityL0Metrics
from dkist_processing_common.tasks.mixin.quality import QualityMixin

from dkist_processing_visp.models.constants import VispConstants
from dkist_processing_visp.models.tags import VispTag
from dkist_processing_visp.tasks.visp_base import VispTaskBase

__all__ = ["VispL0QualityMetrics", "VispL1QualityMetrics"]


@dataclass
class _QualityData:
    """Class for storage of Visp quality data."""

    datetimes: list[str] = field(default_factory=list)
    I_sensitivity: list[float] = field(default_factory=list)
    Q_sensitivity: list[float] = field(default_factory=list)
    U_sensitivity: list[float] = field(default_factory=list)
    V_sensitivity: list[float] = field(default_factory=list)


@dataclass
class _QualityTaskTypeData:
    """Class for storage of Visp quality task type data."""

    quality_task_type: str
    average_values: list[float] = field(default_factory=list)
    rms_values_across_frame: list[float] = field(default_factory=list)
    datetimes: list[str] = field(default_factory=list)

    @property
    def has_values(self) -> bool:
        return bool(self.average_values)


class VispL0QualityMetrics(QualityL0Metrics):
    """
    Task class for collection of Visp L0 specific quality metrics.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs

    """

    @property
    def constants_model_class(self):
        """Class for Visp constants."""
        return VispConstants

    @property
    def modstate_list(self) -> Iterable[int] | None:
        """
        Define the list of modstates over which to compute L0 quality metrics.

        If the dataset is non-polarimetric then we just compute all metrics over all modstates at once.
        """
        if self.constants.correct_for_polarization:
            return range(1, self.constants.num_modstates + 1)

        return None


class VispL1QualityMetrics(VispTaskBase, QualityMixin):
    """
    Task class for collection of Visp L1 specific quality metrics.

    Parameters
    ----------
    recipe_run_id : int
        id of the recipe run used to identify the workflow run this task is part of
    workflow_name : str
        name of the workflow to which this instance of the task belongs
    workflow_version : str
        version of the workflow to which this instance of the task belongs

    """

    def run(self) -> None:
        """
        For each spectral scan.

            - Gather stokes data
            - Find Stokes Q, U, and V RMS noise
            - Find the polarimetric sensitivity (smallest intensity signal measured)
            - Send metrics for storage

        NOTE THAT THIS TASK HAS BEEN REMOVED FROM WORKFLOWS WHILE CALCULATIONS ARE WORKED ON
        """
        pass

    def compute_sensitivity(self) -> None:
        """Compute RMS noise and sensitivity estimate for L1 Visp frames."""
        # Restore this method when the computation is corrected
        return None

    def compute_noise(self):
        """Compute noise in data."""
        # Restore this method when the computation is corrected
        return None
