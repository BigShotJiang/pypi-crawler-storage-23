"""
实战示例：为聊天机器人添加持久记忆

演示如何在对话系统中集成 RememberMe，让 AI 自动记住用户信息。
"""

from openai import OpenAI
from rememberme import RememberMe

REMEMBERME_API_KEY = "rm_sk_你的API密钥"
REMEMBERME_BASE_URL = "http://localhost:8000"  # 修改为你的服务地址
OPENAI_API_KEY = "sk-xxx"

memory = RememberMe(api_key=REMEMBERME_API_KEY, base_url=REMEMBERME_BASE_URL)
llm = OpenAI(api_key=OPENAI_API_KEY)


def chat(user_id: str, user_message: str) -> str:
    """带记忆的聊天函数"""

    # 1. 搜索相关记忆
    relevant = memory.search(user_message, user_id=user_id, limit=5)
    memory_context = "\n".join(f"- {m.memory}" for m in relevant.memories)

    # 2. 构建 system prompt
    system = "你是一个友好的助手。"
    if memory_context:
        system += f"\n\n你对这位用户的了解：\n{memory_context}"

    # 3. 调用 LLM
    response = llm.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user_message},
        ],
    )
    assistant_reply = response.choices[0].message.content

    # 4. 将对话存入记忆（LLM 自动提取关键事实）
    memory.add(
        [
            {"role": "user", "content": user_message},
            {"role": "assistant", "content": assistant_reply},
        ],
        user_id=user_id,
    )

    return assistant_reply


def main():
    user_id = "user_demo"
    print("💬 带记忆的聊天机器人（输入 quit 退出）\n")

    while True:
        user_input = input("你: ")
        if user_input.strip().lower() in ("quit", "exit", "q"):
            break
        reply = chat(user_id, user_input)
        print(f"AI: {reply}\n")


if __name__ == "__main__":
    main()
