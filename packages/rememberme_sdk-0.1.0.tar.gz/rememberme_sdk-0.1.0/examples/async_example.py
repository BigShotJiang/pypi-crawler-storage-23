"""
RememberMe SDK 异步使用示例

适用于 FastAPI / aiohttp / 异步框架中使用。
需要额外安装异步依赖: pip install rememberme-sdk[async]
"""

import asyncio

from rememberme import AsyncRememberMe

API_KEY = "rm_sk_你的API密钥"
BASE_URL = "http://localhost:8000"  # 修改为你的服务地址


async def main():
    async with AsyncRememberMe(api_key=API_KEY, base_url=BASE_URL) as client:
        # 写入
        await client.add(
            "用户偏好暗色主题，代码字体用 JetBrains Mono",
            user_id="user_bob",
        )

        # 搜索
        results = await client.search("用户界面偏好", user_id="user_bob")
        for mem in results.memories:
            print(f"[{mem.score:.2f}] {mem.memory}")


if __name__ == "__main__":
    asyncio.run(main())
