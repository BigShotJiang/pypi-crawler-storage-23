"""
RememberMe SDK 快速入门示例

运行前请确保：
1. 已安装 SDK：pip install rememberme-sdk
2. 已在 Dashboard 中创建 API Key
3. 服务端已启动
"""

from rememberme import RememberMe

API_KEY = "rm_sk_你的API密钥"
BASE_URL = "http://localhost:8000"  # 修改为你的服务地址
USER_ID = "user_alice"


def main():
    client = RememberMe(api_key=API_KEY, base_url=BASE_URL)

    # ① 写入记忆 — 纯文本
    print("📝 写入记忆...")
    result = client.add("我叫 Alice，是一名后端工程师，喜欢用 Python 和 Go", user_id=USER_ID)
    print(f"   写入结果: {result.results}")

    # ② 写入记忆 — 对话格式（LLM 自动提取关键事实）
    client.add(
        [
            {"role": "user", "content": "我最近在学 Rust，感觉所有权机制很有趣"},
            {"role": "assistant", "content": "Rust 的所有权系统确实是它最独特的设计！"},
        ],
        user_id=USER_ID,
    )

    # ③ 语义搜索
    print("\n🔍 搜索记忆...")
    results = client.search("这个用户会什么编程语言？", user_id=USER_ID)
    for mem in results.memories:
        print(f"   [{mem.score:.2f}] {mem.memory}")

    # ④ 列出所有记忆
    print("\n📋 所有记忆:")
    all_mems = client.get_all(user_id=USER_ID)
    for mem in all_mems.memories:
        print(f"   • {mem.memory}")

    print("\n✅ 完成!")


if __name__ == "__main__":
    main()
