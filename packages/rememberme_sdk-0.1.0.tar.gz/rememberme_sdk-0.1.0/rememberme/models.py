"""RememberMe SDK 数据模型"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Memory:
    """单条记忆"""
    id: str
    memory: str
    hash: str | None = None
    metadata: dict[str, Any] | None = None
    score: float | None = None
    created_at: str | None = None
    updated_at: str | None = None
    user_id: str | None = None
    agent_id: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Memory:
        return cls(
            id=data.get("id", ""),
            memory=data.get("memory", ""),
            hash=data.get("hash"),
            metadata=data.get("metadata"),
            score=data.get("score"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
            user_id=data.get("user_id"),
            agent_id=data.get("agent_id"),
        )


@dataclass
class MemoryList:
    """记忆列表"""
    memories: list[Memory] = field(default_factory=list)
    total: int | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemoryList:
        results = data.get("results", [])
        return cls(
            memories=[Memory.from_dict(r) for r in results],
            total=data.get("total", len(results)),
        )


@dataclass
class AddResult:
    """添加记忆的返回结果"""
    results: list[dict[str, Any]] = field(default_factory=list)
    relations: list[dict[str, Any]] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AddResult:
        return cls(
            results=data.get("results", []),
            relations=data.get("relations"),
        )


@dataclass
class Message:
    """对话消息"""
    role: str
    content: str

    def to_dict(self) -> dict[str, str]:
        return {"role": self.role, "content": self.content}
