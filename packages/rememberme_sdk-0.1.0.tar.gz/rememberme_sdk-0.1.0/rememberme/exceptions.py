"""RememberMe SDK 异常定义"""


class RememberMeError(Exception):
    """SDK 基础异常"""

    def __init__(self, message: str, status_code: int | None = None, body: dict | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class AuthenticationError(RememberMeError):
    """API Key 无效或过期"""


class ForbiddenError(RememberMeError):
    """权限不足（如只读 Key 尝试写入）"""


PermissionError = ForbiddenError


class NotFoundError(RememberMeError):
    """请求的资源不存在"""


class ValidationError(RememberMeError):
    """请求参数校验失败"""


class RateLimitError(RememberMeError):
    """请求频率超限"""


class ServerError(RememberMeError):
    """服务端内部错误"""
