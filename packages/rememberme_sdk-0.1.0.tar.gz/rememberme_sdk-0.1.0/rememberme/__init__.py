"""
RememberMe — 让 AI 拥有持久记忆

Python SDK for the RememberMe memory service.

快速开始::

    from rememberme import RememberMe

    client = RememberMe(api_key="rm_sk_xxx", base_url="https://your-server.com")

    # 写入记忆
    client.add("用户喜欢简洁的回答", user_id="u_123")

    # 语义搜索
    results = client.search("用户的偏好是什么？", user_id="u_123")
    for mem in results.memories:
        print(mem.memory)
"""

__version__ = "0.1.0"

from .client import RememberMe
from .async_client import AsyncRememberMe
from .models import AddResult, Memory, MemoryList, Message
from .exceptions import (
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    PermissionError,  # 向后兼容别名，推荐使用 ForbiddenError
    RateLimitError,
    RememberMeError,
    ServerError,
    ValidationError,
)

__all__ = [
    "RememberMe",
    "AsyncRememberMe",
    "AddResult",
    "Memory",
    "MemoryList",
    "Message",
    "RememberMeError",
    "AuthenticationError",
    "ForbiddenError",
    "PermissionError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
]
