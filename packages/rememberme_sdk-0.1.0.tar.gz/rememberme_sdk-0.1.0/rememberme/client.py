"""RememberMe SDK — 同步客户端"""

from __future__ import annotations

import time
from typing import Any

import requests

from .exceptions import (
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    RememberMeError,
    ServerError,
    ValidationError,
)
from .models import AddResult, Memory, MemoryList

_DEFAULT_TIMEOUT = 30
_DEFAULT_MAX_RETRIES = 3
_RETRY_STATUS_CODES = {429, 500, 502, 503, 504}


class RememberMe:
    """RememberMe 记忆服务客户端（同步）。

    用法::

        from rememberme import RememberMe

        client = RememberMe(api_key="rm_sk_xxx")
        client.add("用户喜欢Python", user_id="u_123")
        results = client.search("用户偏好", user_id="u_123")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.rememberme.dev",
        timeout: int = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
    ):
        if not base_url:
            raise ValueError("base_url 不能为空，请指定 RememberMe 服务地址")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        })

    def _url(self, path: str) -> str:
        return f"{self.base_url}/api/memories{path}"

    def _handle_response(self, resp: requests.Response) -> dict[str, Any]:
        if resp.status_code == 401:
            raise AuthenticationError("API Key 无效或已过期", resp.status_code, resp.json() if resp.content else None)
        if resp.status_code == 403:
            raise ForbiddenError("权限不足", resp.status_code, resp.json() if resp.content else None)
        if resp.status_code == 404:
            raise NotFoundError("资源不存在", resp.status_code, resp.json() if resp.content else None)
        if resp.status_code == 422:
            raise ValidationError("请求参数校验失败", resp.status_code, resp.json() if resp.content else None)
        if resp.status_code == 429:
            raise RateLimitError("请求频率超限", resp.status_code, resp.json() if resp.content else None)
        if resp.status_code >= 500:
            raise ServerError("服务端错误", resp.status_code, resp.json() if resp.content else None)
        if not resp.ok:
            raise RememberMeError(f"HTTP {resp.status_code}", resp.status_code, resp.json() if resp.content else None)
        return resp.json()

    def _request(self, method: str, url: str, **kwargs) -> dict[str, Any]:
        """带指数退避重试的统一请求方法"""
        kwargs.setdefault("timeout", self.timeout)
        last_exc: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                resp = self._session.request(method, url, **kwargs)
                if resp.status_code in _RETRY_STATUS_CODES and attempt < self.max_retries:
                    retry_after = float(resp.headers.get("Retry-After", 0))
                    delay = max(retry_after, 0.5 * (2 ** attempt))
                    time.sleep(delay)
                    continue
                return self._handle_response(resp)
            except (requests.ConnectionError, requests.Timeout) as e:
                last_exc = e
                if attempt < self.max_retries:
                    time.sleep(0.5 * (2 ** attempt))
                    continue
                raise RememberMeError(f"网络请求失败: {e}") from e
            except (RateLimitError, ServerError) as e:
                last_exc = e
                if attempt < self.max_retries:
                    time.sleep(0.5 * (2 ** attempt))
                    continue
                raise

        raise last_exc  # type: ignore[misc]

    # ------------------------------------------------------------------ #
    #  Core API
    # ------------------------------------------------------------------ #

    def add(
        self,
        messages: str | list[dict[str, str]],
        *,
        user_id: str | None = None,
        agent_id: str | None = None,
        run_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        infer: bool = True,
    ) -> AddResult:
        """向记忆库写入内容。

        Args:
            messages: 记忆内容，可以是纯文本字符串或消息列表 ``[{"role": "user", "content": "..."}]``
            user_id:  终端用户标识（推荐传入，用于隔离不同用户的记忆）
            agent_id: Agent 标识
            run_id:   会话/运行 标识
            metadata: 附加元数据
            infer:    是否使用 LLM 自动提取关键事实（默认 True）

        Returns:
            AddResult: 包含写入结果列表
        """
        payload: dict[str, Any] = {"messages": messages, "infer": infer}
        if user_id is not None:
            payload["user_id"] = user_id
        if agent_id is not None:
            payload["agent_id"] = agent_id
        if run_id is not None:
            payload["run_id"] = run_id
        if metadata is not None:
            payload["metadata"] = metadata

        data = self._request("POST", self._url(""), json=payload)
        return AddResult.from_dict(data)

    def search(
        self,
        query: str,
        *,
        user_id: str | None = None,
        agent_id: str | None = None,
        run_id: str | None = None,
        limit: int = 10,
        threshold: float | None = None,
    ) -> MemoryList:
        """语义搜索记忆库。

        Args:
            query:     自然语言搜索查询
            user_id:   按用户过滤
            agent_id:  按 Agent 过滤
            run_id:    按会话过滤
            limit:     返回条数上限（1~100）
            threshold: 最低相似度阈值（0~1）

        Returns:
            MemoryList: 匹配的记忆列表
        """
        payload: dict[str, Any] = {"query": query, "limit": limit}
        if user_id is not None:
            payload["user_id"] = user_id
        if agent_id is not None:
            payload["agent_id"] = agent_id
        if run_id is not None:
            payload["run_id"] = run_id
        if threshold is not None:
            payload["threshold"] = threshold

        data = self._request("POST", self._url("/search"), json=payload)
        return MemoryList.from_dict(data)

    def get_all(
        self,
        *,
        user_id: str | None = None,
        agent_id: str | None = None,
        run_id: str | None = None,
        limit: int = 100,
    ) -> MemoryList:
        """列出记忆（可按 user_id / agent_id / run_id 过滤）。

        Returns:
            MemoryList: 记忆列表
        """
        params: dict[str, Any] = {"limit": limit}
        if user_id is not None:
            params["user_id"] = user_id
        if agent_id is not None:
            params["agent_id"] = agent_id
        if run_id is not None:
            params["run_id"] = run_id

        data = self._request("GET", self._url(""), params=params)
        return MemoryList.from_dict(data)

    def get(self, memory_id: str) -> Memory:
        """获取单条记忆详情。

        Args:
            memory_id: 记忆 ID

        Returns:
            Memory: 记忆详情

        Raises:
            NotFoundError: 记忆不存在
        """
        data = self._request("GET", self._url(f"/{memory_id}"))
        return Memory.from_dict(data)

    def update(self, memory_id: str, content: str) -> dict[str, Any]:
        """更新单条记忆内容。

        Args:
            memory_id: 记忆 ID
            content:   新的记忆文本

        Returns:
            dict: 更新结果
        """
        return self._request("PUT", self._url(f"/{memory_id}"), json={"content": content})

    def delete(self, memory_id: str) -> dict[str, Any]:
        """删除单条记忆。

        Args:
            memory_id: 记忆 ID

        Returns:
            dict: 删除结果
        """
        return self._request("DELETE", self._url(f"/{memory_id}"))

    def delete_all(
        self,
        *,
        user_id: str | None = None,
        agent_id: str | None = None,
        run_id: str | None = None,
    ) -> dict[str, Any]:
        """批量删除记忆（至少指定一个过滤条件）。

        Args:
            user_id:  按用户过滤
            agent_id: 按 Agent 过滤
            run_id:   按会话过滤

        Returns:
            dict: 删除结果
        """
        payload: dict[str, Any] = {}
        if user_id is not None:
            payload["user_id"] = user_id
        if agent_id is not None:
            payload["agent_id"] = agent_id
        if run_id is not None:
            payload["run_id"] = run_id

        return self._request("DELETE", self._url(""), json=payload)

    def history(self, memory_id: str) -> list[dict[str, Any]]:
        """获取单条记忆的变更历史。

        Args:
            memory_id: 记忆 ID

        Returns:
            list: 变更历史列表
        """
        data = self._request("GET", self._url(f"/{memory_id}/history"))
        return data.get("history", [])

    def close(self):
        """关闭连接。"""
        self._session.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
