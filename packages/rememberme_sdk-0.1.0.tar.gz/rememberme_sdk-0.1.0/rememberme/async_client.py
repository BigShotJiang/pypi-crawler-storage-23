"""RememberMe SDK — 异步客户端"""

from __future__ import annotations

import asyncio
from typing import Any

import httpx

from .exceptions import (
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    RememberMeError,
    ServerError,
    ValidationError,
)
from .models import AddResult, Memory, MemoryList

_DEFAULT_TIMEOUT = 30
_DEFAULT_MAX_RETRIES = 3
_RETRY_STATUS_CODES = {429, 500, 502, 503, 504}


class AsyncRememberMe:
    """RememberMe 记忆服务客户端（异步）。

    用法::

        from rememberme import AsyncRememberMe

        async with AsyncRememberMe(api_key="rm_sk_xxx") as client:
            await client.add("用户喜欢Python", user_id="u_123")
            results = await client.search("用户偏好", user_id="u_123")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.rememberme.dev",
        timeout: int = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
    ):
        if not base_url:
            raise ValueError("base_url 不能为空，请指定 RememberMe 服务地址")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self._client = httpx.AsyncClient(
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )

    def _url(self, path: str) -> str:
        return f"{self.base_url}/api/memories{path}"

    def _handle_response(self, resp: httpx.Response) -> dict[str, Any]:
        body = resp.json() if resp.content else None
        if resp.status_code == 401:
            raise AuthenticationError("API Key 无效或已过期", resp.status_code, body)
        if resp.status_code == 403:
            raise ForbiddenError("权限不足", resp.status_code, body)
        if resp.status_code == 404:
            raise NotFoundError("资源不存在", resp.status_code, body)
        if resp.status_code == 422:
            raise ValidationError("请求参数校验失败", resp.status_code, body)
        if resp.status_code == 429:
            raise RateLimitError("请求频率超限", resp.status_code, body)
        if resp.status_code >= 500:
            raise ServerError("服务端错误", resp.status_code, body)
        if resp.is_error:
            raise RememberMeError(f"HTTP {resp.status_code}", resp.status_code, body)
        return resp.json()

    async def _request(self, method: str, url: str, **kwargs) -> dict[str, Any]:
        """带指数退避重试的统一请求方法"""
        last_exc: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                resp = await self._client.request(method, url, **kwargs)
                if resp.status_code in _RETRY_STATUS_CODES and attempt < self.max_retries:
                    retry_after = float(resp.headers.get("Retry-After", 0))
                    delay = max(retry_after, 0.5 * (2 ** attempt))
                    await asyncio.sleep(delay)
                    continue
                return self._handle_response(resp)
            except (httpx.ConnectError, httpx.TimeoutException) as e:
                last_exc = e
                if attempt < self.max_retries:
                    await asyncio.sleep(0.5 * (2 ** attempt))
                    continue
                raise RememberMeError(f"网络请求失败: {e}") from e
            except (RateLimitError, ServerError) as e:
                last_exc = e
                if attempt < self.max_retries:
                    await asyncio.sleep(0.5 * (2 ** attempt))
                    continue
                raise

        raise last_exc  # type: ignore[misc]

    # ------------------------------------------------------------------ #
    #  Core API
    # ------------------------------------------------------------------ #

    async def add(
        self,
        messages: str | list[dict[str, str]],
        *,
        user_id: str | None = None,
        agent_id: str | None = None,
        run_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        infer: bool = True,
    ) -> AddResult:
        """向记忆库写入内容。"""
        payload: dict[str, Any] = {"messages": messages, "infer": infer}
        if user_id is not None:
            payload["user_id"] = user_id
        if agent_id is not None:
            payload["agent_id"] = agent_id
        if run_id is not None:
            payload["run_id"] = run_id
        if metadata is not None:
            payload["metadata"] = metadata

        data = await self._request("POST", self._url(""), json=payload)
        return AddResult.from_dict(data)

    async def search(
        self,
        query: str,
        *,
        user_id: str | None = None,
        agent_id: str | None = None,
        run_id: str | None = None,
        limit: int = 10,
        threshold: float | None = None,
    ) -> MemoryList:
        """语义搜索记忆库。"""
        payload: dict[str, Any] = {"query": query, "limit": limit}
        if user_id is not None:
            payload["user_id"] = user_id
        if agent_id is not None:
            payload["agent_id"] = agent_id
        if run_id is not None:
            payload["run_id"] = run_id
        if threshold is not None:
            payload["threshold"] = threshold

        data = await self._request("POST", self._url("/search"), json=payload)
        return MemoryList.from_dict(data)

    async def get_all(
        self,
        *,
        user_id: str | None = None,
        agent_id: str | None = None,
        run_id: str | None = None,
        limit: int = 100,
    ) -> MemoryList:
        """列出记忆。"""
        params: dict[str, Any] = {"limit": limit}
        if user_id is not None:
            params["user_id"] = user_id
        if agent_id is not None:
            params["agent_id"] = agent_id
        if run_id is not None:
            params["run_id"] = run_id

        data = await self._request("GET", self._url(""), params=params)
        return MemoryList.from_dict(data)

    async def get(self, memory_id: str) -> Memory:
        """获取单条记忆详情。"""
        data = await self._request("GET", self._url(f"/{memory_id}"))
        return Memory.from_dict(data)

    async def update(self, memory_id: str, content: str) -> dict[str, Any]:
        """更新单条记忆内容。"""
        return await self._request("PUT", self._url(f"/{memory_id}"), json={"content": content})

    async def delete(self, memory_id: str) -> dict[str, Any]:
        """删除单条记忆。"""
        return await self._request("DELETE", self._url(f"/{memory_id}"))

    async def delete_all(
        self,
        *,
        user_id: str | None = None,
        agent_id: str | None = None,
        run_id: str | None = None,
    ) -> dict[str, Any]:
        """批量删除记忆。"""
        payload: dict[str, Any] = {}
        if user_id is not None:
            payload["user_id"] = user_id
        if agent_id is not None:
            payload["agent_id"] = agent_id
        if run_id is not None:
            payload["run_id"] = run_id

        return await self._request("DELETE", self._url(""), json=payload)

    async def history(self, memory_id: str) -> list[dict[str, Any]]:
        """获取单条记忆的变更历史。"""
        data = await self._request("GET", self._url(f"/{memory_id}/history"))
        return data.get("history", [])

    async def close(self):
        """关闭连接。"""
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
