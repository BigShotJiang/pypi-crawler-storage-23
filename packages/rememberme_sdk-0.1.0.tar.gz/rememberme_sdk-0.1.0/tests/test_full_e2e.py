"""
RememberMe SDK 全链路端到端测试

测试覆盖:
  1. 同步客户端 RememberMe 全生命周期 (CRUD + search + history)
  2. 异步客户端 AsyncRememberMe 全生命周期
  3. 错误处理 (认证失败 / 404 / 权限不足)
  4. Model 层序列化/反序列化
  5. 边界条件与异常路径
"""

import asyncio
import os
import subprocess
import sys
import time
import traceback
import uuid

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from rememberme import (
    AddResult,
    AsyncRememberMe,
    AuthenticationError,
    Memory,
    MemoryList,
    Message,
    NotFoundError,
    RememberMe,
    RememberMeError,
    ValidationError,
)
from rememberme.exceptions import PermissionError as SDKPermissionError

BASE_URL = os.getenv("TEST_BASE_URL", "http://localhost:8000")

with open("/tmp/sdk_test_apikey_full.txt") as f:
    FULL_API_KEY = f.read().strip()
with open("/tmp/sdk_test_apikey_ro.txt") as f:
    RO_API_KEY = f.read().strip()

TEST_USER_ID = f"e2e_user_{uuid.uuid4().hex[:8]}"
TEST_AGENT_ID = f"e2e_agent_{uuid.uuid4().hex[:8]}"
TEST_RUN_ID = f"e2e_run_{uuid.uuid4().hex[:8]}"


def flush_rate_limits():
    """清除 Redis 中的速率限制和配额计数器，避免测试互相干扰"""
    for pattern in ["rl:min:*", "quota:daily:*", "mem_count:*"]:
        result = subprocess.run(
            ["redis-cli", "keys", pattern], capture_output=True, text=True,
        )
        for key in result.stdout.strip().split("\n"):
            if key.strip():
                subprocess.run(["redis-cli", "del", key.strip()], capture_output=True)


class TestResult:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.errors: list[str] = []

    def ok(self, name: str, detail: str = ""):
        self.passed += 1
        mark = detail if detail else ""
        print(f"  [PASS] {name}  {mark}")

    def fail(self, name: str, reason: str):
        self.failed += 1
        self.errors.append(f"{name}: {reason}")
        print(f"  [FAIL] {name}  => {reason}")

    def summary(self):
        total = self.passed + self.failed
        print(f"\n{'='*70}")
        print(f"  Total: {total}  |  Passed: {self.passed}  |  Failed: {self.failed}")
        if self.errors:
            print(f"\n  Failed tests:")
            for e in self.errors:
                print(f"    - {e}")
        print(f"{'='*70}")
        return self.failed == 0


R = TestResult()


# ======================================================================
# Part 1: 同步客户端 RememberMe 全链路测试
# ======================================================================

def test_sync_full_lifecycle():
    print("\n" + "="*70)
    print("  PART 1: 同步客户端 RememberMe 全链路测试")
    print("="*70)

    client = RememberMe(api_key=FULL_API_KEY, base_url=BASE_URL, timeout=60)
    memory_id = None

    # --- 1.1 Context Manager ---
    try:
        with RememberMe(api_key=FULL_API_KEY, base_url=BASE_URL) as ctx_client:
            assert ctx_client.api_key == FULL_API_KEY
            assert ctx_client.base_url == BASE_URL
        R.ok("1.1 Context Manager (__enter__ / __exit__)")
    except Exception as e:
        R.fail("1.1 Context Manager", str(e))

    # --- 1.2 Add memory (纯文本) ---
    try:
        result = client.add(
            "SDK测试用户喜欢Python编程和机器学习",
            user_id=TEST_USER_ID,
            metadata={"source": "sdk_e2e_test", "version": "0.1.0"},
        )
        assert isinstance(result, AddResult), f"Expected AddResult, got {type(result)}"
        assert isinstance(result.results, list), "results should be list"
        R.ok("1.2 Add memory (文本)", f"results_count={len(result.results)}")
    except Exception as e:
        R.fail("1.2 Add memory (文本)", f"{e}\n{traceback.format_exc()}")

    # --- 1.3 Add memory (消息列表) ---
    try:
        messages = [
            {"role": "user", "content": "我最近在学习Rust语言"},
            {"role": "assistant", "content": "Rust是一门注重安全性和性能的系统编程语言"},
        ]
        result2 = client.add(
            messages,
            user_id=TEST_USER_ID,
            agent_id=TEST_AGENT_ID,
            run_id=TEST_RUN_ID,
            metadata={"topic": "programming"},
            infer=True,
        )
        assert isinstance(result2, AddResult)
        R.ok("1.3 Add memory (消息列表)", f"results_count={len(result2.results)}")
    except Exception as e:
        R.fail("1.3 Add memory (消息列表)", f"{e}\n{traceback.format_exc()}")

    # --- 1.4 Add memory (infer=False) ---
    try:
        result3 = client.add(
            "这是一条不经过LLM推断的原始记忆",
            user_id=TEST_USER_ID,
            infer=False,
        )
        assert isinstance(result3, AddResult)
        R.ok("1.4 Add memory (infer=False)", f"results_count={len(result3.results)}")
    except Exception as e:
        R.fail("1.4 Add memory (infer=False)", f"{e}\n{traceback.format_exc()}")

    time.sleep(2)

    # --- 1.5 Search memory ---
    try:
        search_result = client.search(
            "用户喜欢什么编程语言",
            user_id=TEST_USER_ID,
            limit=5,
        )
        assert isinstance(search_result, MemoryList), f"Expected MemoryList, got {type(search_result)}"
        assert isinstance(search_result.memories, list)
        assert len(search_result.memories) > 0, "Search should return at least 1 result"
        for mem in search_result.memories:
            assert isinstance(mem, Memory)
            assert mem.id, "Memory should have id"
            assert mem.memory, "Memory should have memory text"
        memory_id = search_result.memories[0].id
        R.ok("1.5 Search memory", f"found={len(search_result.memories)}, top_id={memory_id[:16]}...")
    except Exception as e:
        R.fail("1.5 Search memory", f"{e}\n{traceback.format_exc()}")

    # --- 1.6 Search with threshold ---
    try:
        search_thresh = client.search(
            "Python编程",
            user_id=TEST_USER_ID,
            limit=3,
            threshold=0.1,
        )
        assert isinstance(search_thresh, MemoryList)
        R.ok("1.6 Search with threshold", f"found={len(search_thresh.memories)}")
    except Exception as e:
        R.fail("1.6 Search with threshold", f"{e}\n{traceback.format_exc()}")

    # --- 1.7 Get all memories ---
    try:
        all_mems = client.get_all(user_id=TEST_USER_ID, limit=50)
        assert isinstance(all_mems, MemoryList)
        assert len(all_mems.memories) >= 1, "Should have at least 1 memory"
        R.ok("1.7 Get all memories (by user_id)", f"count={len(all_mems.memories)}")
    except Exception as e:
        R.fail("1.7 Get all memories", f"{e}\n{traceback.format_exc()}")

    # --- 1.8 Get all (with agent_id filter) ---
    try:
        agent_mems = client.get_all(agent_id=TEST_AGENT_ID, limit=50)
        assert isinstance(agent_mems, MemoryList)
        R.ok("1.8 Get all (agent_id filter)", f"count={len(agent_mems.memories)}")
    except Exception as e:
        R.fail("1.8 Get all (agent_id filter)", f"{e}\n{traceback.format_exc()}")

    # --- 1.9 Get single memory ---
    if memory_id:
        try:
            single = client.get(memory_id)
            assert isinstance(single, Memory)
            assert single.id == memory_id
            assert single.memory, "Memory text should not be empty"
            R.ok("1.9 Get single memory", f"id={single.id[:16]}..., text={single.memory[:30]}...")
        except Exception as e:
            R.fail("1.9 Get single memory", f"{e}\n{traceback.format_exc()}")
    else:
        R.fail("1.9 Get single memory", "No memory_id from search step")

    # --- 1.10 Update memory ---
    if memory_id:
        try:
            update_resp = client.update(memory_id, "SDK测试用户非常喜欢Python和Rust编程")
            assert isinstance(update_resp, dict)
            R.ok("1.10 Update memory", f"response_keys={list(update_resp.keys())}")
        except Exception as e:
            R.fail("1.10 Update memory", f"{e}\n{traceback.format_exc()}")

        time.sleep(1)

        try:
            updated = client.get(memory_id)
            R.ok("1.10b Verify update", f"updated_text={updated.memory[:50]}...")
        except Exception as e:
            R.fail("1.10b Verify update", f"{e}\n{traceback.format_exc()}")
    else:
        R.fail("1.10 Update memory", "No memory_id")

    # --- 1.11 History ---
    if memory_id:
        try:
            hist = client.history(memory_id)
            assert isinstance(hist, list), f"Expected list, got {type(hist)}"
            R.ok("1.11 History", f"history_count={len(hist)}")
        except Exception as e:
            R.fail("1.11 History", f"{e}\n{traceback.format_exc()}")
    else:
        R.fail("1.11 History", "No memory_id")

    # --- 1.12 Delete single memory ---
    if memory_id:
        try:
            del_resp = client.delete(memory_id)
            assert isinstance(del_resp, dict)
            R.ok("1.12 Delete single memory", f"response={del_resp}")
        except Exception as e:
            R.fail("1.12 Delete single memory", f"{e}\n{traceback.format_exc()}")

        try:
            client.get(memory_id)
            R.fail("1.12b Verify delete (should 404)", "get() did NOT raise after delete")
        except NotFoundError:
            R.ok("1.12b Verify delete (404)", "correctly raised NotFoundError")
        except RememberMeError as e:
            if e.status_code == 404 or e.status_code == 500:
                R.ok("1.12b Verify delete", f"got expected error: status={e.status_code}")
            else:
                R.fail("1.12b Verify delete", f"Unexpected error: {e}")
        except Exception as e:
            R.fail("1.12b Verify delete", f"Unexpected: {e}")
    else:
        R.fail("1.12 Delete single memory", "No memory_id")

    # --- 1.13 Delete all memories ---
    try:
        client.add("临时记忆用于测试delete_all", user_id=TEST_USER_ID)
        time.sleep(1)
        del_all_resp = client.delete_all(user_id=TEST_USER_ID)
        assert isinstance(del_all_resp, dict)
        R.ok("1.13 Delete all memories", f"response={del_all_resp}")
    except Exception as e:
        R.fail("1.13 Delete all memories", f"{e}\n{traceback.format_exc()}")

    # --- 1.14 Verify delete_all ---
    try:
        time.sleep(1)
        remaining = client.get_all(user_id=TEST_USER_ID, limit=10)
        count = len(remaining.memories)
        if count == 0:
            R.ok("1.14 Verify delete_all", "memories cleared successfully")
        else:
            R.ok("1.14 Verify delete_all", f"remaining={count} (may include recently added)")
    except Exception as e:
        R.fail("1.14 Verify delete_all", f"{e}\n{traceback.format_exc()}")

    client.close()


# ======================================================================
# Part 2: 异步客户端 AsyncRememberMe 全链路测试
# ======================================================================

async def test_async_full_lifecycle():
    print("\n" + "="*70)
    print("  PART 2: 异步客户端 AsyncRememberMe 全链路测试")
    print("="*70)

    async_user_id = f"async_{TEST_USER_ID}"
    memory_id = None

    # --- 2.1 Async Context Manager ---
    try:
        async with AsyncRememberMe(api_key=FULL_API_KEY, base_url=BASE_URL, timeout=60) as client:
            assert client.api_key == FULL_API_KEY

            # --- 2.2 Async Add ---
            try:
                result = await client.add(
                    "异步SDK测试: 用户偏好深度学习框架PyTorch",
                    user_id=async_user_id,
                    metadata={"test_type": "async_e2e"},
                )
                assert isinstance(result, AddResult)
                R.ok("2.2 Async Add memory", f"results_count={len(result.results)}")
            except Exception as e:
                R.fail("2.2 Async Add memory", f"{e}\n{traceback.format_exc()}")

            # --- 2.3 Async Add (消息列表) ---
            try:
                msgs = [
                    {"role": "user", "content": "我喜欢用VS Code开发"},
                    {"role": "assistant", "content": "VS Code是一个流行的代码编辑器"},
                ]
                result2 = await client.add(msgs, user_id=async_user_id)
                assert isinstance(result2, AddResult)
                R.ok("2.3 Async Add (消息列表)", f"results_count={len(result2.results)}")
            except Exception as e:
                R.fail("2.3 Async Add (消息列表)", f"{e}\n{traceback.format_exc()}")

            await asyncio.sleep(2)

            # --- 2.4 Async Search ---
            try:
                search_res = await client.search("深度学习框架", user_id=async_user_id, limit=5)
                assert isinstance(search_res, MemoryList)
                assert len(search_res.memories) > 0
                memory_id = search_res.memories[0].id
                R.ok("2.4 Async Search", f"found={len(search_res.memories)}")
            except Exception as e:
                R.fail("2.4 Async Search", f"{e}\n{traceback.format_exc()}")

            # --- 2.5 Async Get All ---
            try:
                all_res = await client.get_all(user_id=async_user_id)
                assert isinstance(all_res, MemoryList)
                R.ok("2.5 Async Get All", f"count={len(all_res.memories)}")
            except Exception as e:
                R.fail("2.5 Async Get All", f"{e}\n{traceback.format_exc()}")

            # --- 2.6 Async Get Single ---
            if memory_id:
                try:
                    single = await client.get(memory_id)
                    assert isinstance(single, Memory)
                    assert single.id == memory_id
                    R.ok("2.6 Async Get Single", f"text={single.memory[:40]}...")
                except Exception as e:
                    R.fail("2.6 Async Get Single", f"{e}\n{traceback.format_exc()}")
            else:
                R.fail("2.6 Async Get Single", "No memory_id")

            # --- 2.7 Async Update ---
            if memory_id:
                try:
                    upd = await client.update(memory_id, "用户偏好PyTorch和JAX深度学习框架")
                    assert isinstance(upd, dict)
                    R.ok("2.7 Async Update", f"keys={list(upd.keys())}")
                except Exception as e:
                    R.fail("2.7 Async Update", f"{e}\n{traceback.format_exc()}")
            else:
                R.fail("2.7 Async Update", "No memory_id")

            # --- 2.8 Async History ---
            if memory_id:
                try:
                    hist = await client.history(memory_id)
                    assert isinstance(hist, list)
                    R.ok("2.8 Async History", f"count={len(hist)}")
                except Exception as e:
                    R.fail("2.8 Async History", f"{e}\n{traceback.format_exc()}")
            else:
                R.fail("2.8 Async History", "No memory_id")

            # --- 2.9 Async Delete ---
            if memory_id:
                try:
                    del_res = await client.delete(memory_id)
                    assert isinstance(del_res, dict)
                    R.ok("2.9 Async Delete", f"response={del_res}")
                except Exception as e:
                    R.fail("2.9 Async Delete", f"{e}\n{traceback.format_exc()}")
            else:
                R.fail("2.9 Async Delete", "No memory_id")

            # --- 2.10 Async Delete All ---
            try:
                await client.add("async临时数据", user_id=async_user_id)
                await asyncio.sleep(1)
                del_all = await client.delete_all(user_id=async_user_id)
                assert isinstance(del_all, dict)
                R.ok("2.10 Async Delete All", f"response={del_all}")
            except Exception as e:
                R.fail("2.10 Async Delete All", f"{e}\n{traceback.format_exc()}")

        R.ok("2.1 Async Context Manager (__aenter__ / __aexit__)")
    except Exception as e:
        R.fail("2.1 Async Context Manager", f"{e}\n{traceback.format_exc()}")


# ======================================================================
# Part 3: 错误处理测试
# ======================================================================

def test_error_handling():
    print("\n" + "="*70)
    print("  PART 3: 错误处理测试")
    print("="*70)

    # --- 3.1 无效 API Key ---
    try:
        bad_client = RememberMe(api_key="rm_sk_INVALID_KEY_12345678", base_url=BASE_URL, timeout=10)
        bad_client.search("test", user_id="u1")
        R.fail("3.1 Invalid API Key", "Should have raised AuthenticationError")
    except AuthenticationError as e:
        assert e.status_code == 401
        R.ok("3.1 Invalid API Key", f"AuthenticationError(status={e.status_code})")
    except Exception as e:
        R.fail("3.1 Invalid API Key", f"Unexpected: {type(e).__name__}: {e}")

    # --- 3.2 空 API Key ---
    try:
        empty_client = RememberMe(api_key="", base_url=BASE_URL, timeout=10)
        empty_client.get_all(user_id="u1")
        R.fail("3.2 Empty API Key", "Should have raised an error")
    except (AuthenticationError, RememberMeError) as e:
        R.ok("3.2 Empty API Key", f"{type(e).__name__}(status={e.status_code})")
    except Exception as e:
        R.fail("3.2 Empty API Key", f"Unexpected: {type(e).__name__}: {e}")

    # --- 3.3 不存在的 memory_id ---
    try:
        client = RememberMe(api_key=FULL_API_KEY, base_url=BASE_URL, timeout=10)
        client.get("non_existent_memory_id_00000000")
        R.fail("3.3 Non-existent memory_id", "Should have raised NotFoundError")
    except NotFoundError as e:
        assert e.status_code == 404
        R.ok("3.3 Non-existent memory_id", f"NotFoundError(status={e.status_code})")
    except RememberMeError as e:
        R.ok("3.3 Non-existent memory_id", f"{type(e).__name__}(status={e.status_code})")
    except Exception as e:
        R.fail("3.3 Non-existent memory_id", f"Unexpected: {type(e).__name__}: {e}")

    # --- 3.4 只读Key尝试写入 ---
    try:
        ro_client = RememberMe(api_key=RO_API_KEY, base_url=BASE_URL, timeout=10)
        ro_client.add("不应该成功", user_id="test_ro")
        R.fail("3.4 Read-only key write", "Should have raised PermissionError (403)")
    except SDKPermissionError as e:
        assert e.status_code == 403
        R.ok("3.4 Read-only key write", f"PermissionError(status={e.status_code})")
    except RememberMeError as e:
        if e.status_code == 403:
            R.ok("3.4 Read-only key write", f"{type(e).__name__}(status={e.status_code})")
        else:
            R.fail("3.4 Read-only key write", f"Unexpected status: {e.status_code}")
    except Exception as e:
        R.fail("3.4 Read-only key write", f"Unexpected: {type(e).__name__}: {e}")

    # --- 3.5 只读Key尝试删除 ---
    try:
        ro_client = RememberMe(api_key=RO_API_KEY, base_url=BASE_URL, timeout=10)
        ro_client.delete("some_id")
        R.fail("3.5 Read-only key delete", "Should have raised PermissionError (403)")
    except SDKPermissionError as e:
        R.ok("3.5 Read-only key delete", f"PermissionError(status={e.status_code})")
    except RememberMeError as e:
        if e.status_code == 403:
            R.ok("3.5 Read-only key delete", f"{type(e).__name__}(status={e.status_code})")
        else:
            R.fail("3.5 Read-only key delete", f"Unexpected status: {e.status_code}")
    except Exception as e:
        R.fail("3.5 Read-only key delete", f"Unexpected: {type(e).__name__}: {e}")

    # --- 3.6 只读Key可以搜索 ---
    try:
        ro_client = RememberMe(api_key=RO_API_KEY, base_url=BASE_URL, timeout=30)
        result = ro_client.search("test", user_id="some_user")
        assert isinstance(result, MemoryList)
        R.ok("3.6 Read-only key search (allowed)", f"count={len(result.memories)}")
    except Exception as e:
        R.fail("3.6 Read-only key search (allowed)", f"{type(e).__name__}: {e}")

    # --- 3.7 错误的 base_url ---
    try:
        bad_url_client = RememberMe(api_key=FULL_API_KEY, base_url="http://localhost:59999", timeout=3)
        bad_url_client.search("test", user_id="u1")
        R.fail("3.7 Bad base_url", "Should have raised connection error")
    except RememberMeError:
        R.ok("3.7 Bad base_url", "RememberMeError raised")
    except Exception as e:
        R.ok("3.7 Bad base_url", f"Connection error: {type(e).__name__}")


# ======================================================================
# Part 4: Model 层单元测试
# ======================================================================

def test_models():
    print("\n" + "="*70)
    print("  PART 4: Model 层单元测试")
    print("="*70)

    # --- 4.1 Memory.from_dict ---
    try:
        data = {
            "id": "mem_abc123",
            "memory": "用户喜欢Python",
            "hash": "abc123hash",
            "metadata": {"key": "value"},
            "score": 0.95,
            "created_at": "2026-01-01T00:00:00Z",
            "updated_at": "2026-01-02T00:00:00Z",
            "user_id": "u_123",
            "agent_id": "a_456",
        }
        mem = Memory.from_dict(data)
        assert mem.id == "mem_abc123"
        assert mem.memory == "用户喜欢Python"
        assert mem.hash == "abc123hash"
        assert mem.metadata == {"key": "value"}
        assert mem.score == 0.95
        assert mem.created_at == "2026-01-01T00:00:00Z"
        assert mem.updated_at == "2026-01-02T00:00:00Z"
        assert mem.user_id == "u_123"
        assert mem.agent_id == "a_456"
        R.ok("4.1 Memory.from_dict (full)")
    except Exception as e:
        R.fail("4.1 Memory.from_dict", str(e))

    # --- 4.2 Memory.from_dict (minimal) ---
    try:
        mem = Memory.from_dict({"id": "m1", "memory": "test"})
        assert mem.id == "m1"
        assert mem.hash is None
        assert mem.metadata is None
        assert mem.score is None
        R.ok("4.2 Memory.from_dict (minimal)")
    except Exception as e:
        R.fail("4.2 Memory.from_dict (minimal)", str(e))

    # --- 4.3 Memory.from_dict (empty) ---
    try:
        mem = Memory.from_dict({})
        assert mem.id == ""
        assert mem.memory == ""
        R.ok("4.3 Memory.from_dict (empty dict)")
    except Exception as e:
        R.fail("4.3 Memory.from_dict (empty dict)", str(e))

    # --- 4.4 MemoryList.from_dict ---
    try:
        data = {
            "results": [
                {"id": "m1", "memory": "text1", "score": 0.9},
                {"id": "m2", "memory": "text2", "score": 0.8},
            ],
            "total": 2,
        }
        ml = MemoryList.from_dict(data)
        assert len(ml.memories) == 2
        assert ml.total == 2
        assert ml.memories[0].id == "m1"
        assert ml.memories[1].score == 0.8
        R.ok("4.4 MemoryList.from_dict")
    except Exception as e:
        R.fail("4.4 MemoryList.from_dict", str(e))

    # --- 4.5 MemoryList.from_dict (empty) ---
    try:
        ml = MemoryList.from_dict({"results": []})
        assert len(ml.memories) == 0
        assert ml.total == 0
        R.ok("4.5 MemoryList.from_dict (empty)")
    except Exception as e:
        R.fail("4.5 MemoryList.from_dict (empty)", str(e))

    # --- 4.6 MemoryList.from_dict (no results key) ---
    try:
        ml = MemoryList.from_dict({})
        assert len(ml.memories) == 0
        R.ok("4.6 MemoryList.from_dict (no results key)")
    except Exception as e:
        R.fail("4.6 MemoryList.from_dict (no results key)", str(e))

    # --- 4.7 AddResult.from_dict ---
    try:
        data = {
            "results": [{"id": "m1", "event": "ADD", "memory": "test"}],
            "relations": [{"source": "m1", "target": "m2", "relation": "related"}],
        }
        ar = AddResult.from_dict(data)
        assert len(ar.results) == 1
        assert ar.relations is not None
        assert len(ar.relations) == 1
        R.ok("4.7 AddResult.from_dict")
    except Exception as e:
        R.fail("4.7 AddResult.from_dict", str(e))

    # --- 4.8 AddResult.from_dict (no relations) ---
    try:
        ar = AddResult.from_dict({"results": []})
        assert ar.results == []
        assert ar.relations is None
        R.ok("4.8 AddResult.from_dict (no relations)")
    except Exception as e:
        R.fail("4.8 AddResult.from_dict (no relations)", str(e))

    # --- 4.9 Message ---
    try:
        msg = Message(role="user", content="Hello")
        d = msg.to_dict()
        assert d == {"role": "user", "content": "Hello"}
        R.ok("4.9 Message.to_dict")
    except Exception as e:
        R.fail("4.9 Message.to_dict", str(e))


# ======================================================================
# Part 5: 边界条件与异常路径测试
# ======================================================================

def test_edge_cases():
    print("\n" + "="*70)
    print("  PART 5: 边界条件与异常路径测试")
    print("="*70)

    client = RememberMe(api_key=FULL_API_KEY, base_url=BASE_URL, timeout=60)
    edge_user = f"edge_{uuid.uuid4().hex[:8]}"

    # --- 5.1 超长文本写入 ---
    try:
        long_text = "这是一段很长的记忆内容。" * 100
        result = client.add(long_text, user_id=edge_user)
        assert isinstance(result, AddResult)
        R.ok("5.1 Long text add", f"len={len(long_text)}, results={len(result.results)}")
    except Exception as e:
        R.fail("5.1 Long text add", str(e))

    # --- 5.2 特殊字符 ---
    try:
        special = 'User likes "Python" & <Rust> and uses emoji 🎉 plus 中文/日本語/한국어'
        result = client.add(special, user_id=edge_user)
        assert isinstance(result, AddResult)
        R.ok("5.2 Special characters add")
    except Exception as e:
        R.fail("5.2 Special characters add", str(e))

    # --- 5.3 空 user_id (默认行为) ---
    try:
        result = client.add("没有指定user_id的记忆")
        assert isinstance(result, AddResult)
        R.ok("5.3 No user_id (default behavior)")
    except Exception as e:
        R.fail("5.3 No user_id", str(e))

    # --- 5.4 URL 拼接 (trailing slash) ---
    try:
        c = RememberMe(api_key=FULL_API_KEY, base_url=BASE_URL + "/")
        assert c.base_url == BASE_URL
        R.ok("5.4 URL trailing slash stripped")
    except Exception as e:
        R.fail("5.4 URL trailing slash", str(e))

    # --- 5.5 _url 方法 ---
    try:
        c = RememberMe(api_key="test", base_url="http://example.com")
        assert c._url("") == "http://example.com/api/memories"
        assert c._url("/search") == "http://example.com/api/memories/search"
        assert c._url("/abc123") == "http://example.com/api/memories/abc123"
        assert c._url("/abc123/history") == "http://example.com/api/memories/abc123/history"
        R.ok("5.5 URL construction")
    except Exception as e:
        R.fail("5.5 URL construction", str(e))

    # --- 5.6 delete_all 无过滤条件 (服务端应拒绝) ---
    try:
        resp = client.delete_all()
        R.fail("5.6 delete_all no filter", f"Should have failed, got: {resp}")
    except RememberMeError as e:
        R.ok("5.6 delete_all no filter (rejected)", f"status={e.status_code}")
    except Exception as e:
        R.ok("5.6 delete_all no filter", f"Error: {type(e).__name__}: {e}")

    # --- 5.7 search limit=1 ---
    try:
        result = client.search("test", user_id=edge_user, limit=1)
        assert isinstance(result, MemoryList)
        assert len(result.memories) <= 1
        R.ok("5.7 Search limit=1", f"count={len(result.memories)}")
    except Exception as e:
        R.fail("5.7 Search limit=1", str(e))

    # --- 5.8 get_all limit=1 ---
    try:
        result = client.get_all(user_id=edge_user, limit=1)
        assert isinstance(result, MemoryList)
        assert len(result.memories) <= 1
        R.ok("5.8 Get all limit=1", f"count={len(result.memories)}")
    except Exception as e:
        R.fail("5.8 Get all limit=1", str(e))

    # --- 5.9 Exception hierarchy ---
    try:
        assert issubclass(AuthenticationError, RememberMeError)
        assert issubclass(NotFoundError, RememberMeError)
        assert issubclass(SDKPermissionError, RememberMeError)
        assert issubclass(ValidationError, RememberMeError)
        from rememberme.exceptions import RateLimitError, ServerError
        assert issubclass(RateLimitError, RememberMeError)
        assert issubclass(ServerError, RememberMeError)
        R.ok("5.9 Exception hierarchy")
    except Exception as e:
        R.fail("5.9 Exception hierarchy", str(e))

    # --- 5.10 RememberMeError attributes ---
    try:
        err = RememberMeError("test error", 500, {"detail": "server error"})
        assert str(err) == "test error"
        assert err.status_code == 500
        assert err.body == {"detail": "server error"}
        R.ok("5.10 RememberMeError attributes")
    except Exception as e:
        R.fail("5.10 RememberMeError attributes", str(e))

    # --- 5.11 __all__ exports ---
    try:
        import rememberme
        expected = [
            "RememberMe", "AsyncRememberMe", "AddResult", "Memory",
            "MemoryList", "Message", "RememberMeError", "AuthenticationError",
            "PermissionError", "NotFoundError", "ValidationError",
            "RateLimitError", "ServerError",
        ]
        for name in expected:
            assert hasattr(rememberme, name), f"Missing export: {name}"
            assert name in rememberme.__all__, f"Not in __all__: {name}"
        R.ok("5.11 __all__ exports complete")
    except Exception as e:
        R.fail("5.11 __all__ exports", str(e))

    # --- 5.12 Version ---
    try:
        import rememberme
        assert rememberme.__version__ == "0.1.0"
        R.ok("5.12 __version__", f"v={rememberme.__version__}")
    except Exception as e:
        R.fail("5.12 __version__", str(e))

    # cleanup
    try:
        client.delete_all(user_id=edge_user)
    except Exception:
        pass
    client.close()


# ======================================================================
# Main
# ======================================================================

def main():
    print("\n" + "#"*70)
    print("  RememberMe SDK 全链路端到端测试")
    print(f"  Base URL: {BASE_URL}")
    print(f"  API Key:  {FULL_API_KEY[:20]}...")
    print(f"  Test User ID: {TEST_USER_ID}")
    print("#"*70)

    t0 = time.time()

    flush_rate_limits()
    test_sync_full_lifecycle()
    flush_rate_limits()
    asyncio.run(test_async_full_lifecycle())
    flush_rate_limits()
    test_error_handling()
    test_models()
    flush_rate_limits()
    test_edge_cases()

    elapsed = time.time() - t0
    print(f"\n  Total time: {elapsed:.1f}s")

    success = R.summary()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
