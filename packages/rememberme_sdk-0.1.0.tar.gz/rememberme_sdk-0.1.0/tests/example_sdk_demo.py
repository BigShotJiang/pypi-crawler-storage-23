"""
RememberMe SDK 完整调用示例

服务地址: http://localhost:8000 (通过 BASE_URL 变量修改)
运行方式: python3 tests/example_sdk_demo.py  (需要 Python >= 3.10)

演示流程:
  1.  注册用户 → 获取 JWT Token
  2.  用 JWT Token 创建 API Key
  3.  用 API Key 初始化 SDK 客户端
  4.  写入记忆 (add) — 纯文本 / 对话列表两种方式
  5.  语义搜索 (search)
  6.  列出所有记忆 (get_all)
  7.  获取单条记忆 (get)
  8.  更新记忆 (update)
  9.  查看变更历史 (history)
  10. 删除单条记忆 (delete)
  11. 批量删除 (delete_all)

运行结果 (2026-02-25):
  - 步骤 1: 注册成功, 获得 JWT Token
  - 步骤 2: 创建 API Key (rm_sk_NWG0RC-...) 权限=full
  - 步骤 3: SDK 客户端初始化完成
  - 步骤 4: 3 次写入共生成 6 条记忆 (LLM 自动拆分事实)
      纯文本 "Python 全栈开发者, 擅长 FastAPI 和 React" → 2 条
      对话列表 "北京工作, 研究 LLM/RAG" → 2 条
      纯文本 "喜欢咖啡, 偏好手冲" → 2 条
  - 步骤 5: 搜索 "用户的技术栈和工作方向" 命中 5 条, 最高相关度 0.6504
  - 步骤 6: get_all 返回 6 条记忆
  - 步骤 7: 获取单条记忆详情成功
  - 步骤 8: update 成功, 内容已更新
  - 步骤 9: history 返回 2 条变更记录 (ADD → UPDATE)
  - 步骤 10: delete 成功, 再次 get 抛出 NotFoundError
  - 步骤 11: delete_all 批量删除成功
  - 全部 11 步均通过, 耗时 ~17s
"""

import os
import sys
import json
import time
import uuid
import requests

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from rememberme import RememberMe, AuthenticationError, NotFoundError

BASE_URL = os.getenv("TEST_BASE_URL", "http://localhost:8000")

DIVIDER = "=" * 60


def step(num: int, title: str):
    print(f"\n{DIVIDER}")
    print(f"  步骤 {num}: {title}")
    print(DIVIDER)


def pretty(obj):
    """美化打印对象"""
    if hasattr(obj, "__dict__"):
        print(json.dumps(obj.__dict__, ensure_ascii=False, indent=2, default=str))
    elif isinstance(obj, dict):
        print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))
    elif isinstance(obj, list):
        print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))
    else:
        print(obj)


def main():
    tag = uuid.uuid4().hex[:6]
    test_email = f"sdk_demo_{tag}@example.com"
    test_password = "demo_password_123"
    test_name = f"SDK示例用户_{tag}"
    test_user_id = f"demo_user_{tag}"

    print(f"\n{'#' * 60}")
    print(f"  RememberMe SDK 完整调用示例")
    print(f"  服务地址: {BASE_URL}")
    print(f"  测试用户: {test_email}")
    print(f"{'#' * 60}")

    # ----------------------------------------------------------
    # 步骤 1: 注册用户
    # ----------------------------------------------------------
    step(1, "注册用户获取 JWT Token")
    resp = requests.post(f"{BASE_URL}/api/auth/register", json={
        "name": test_name,
        "email": test_email,
        "password": test_password,
    })
    assert resp.status_code == 201, f"注册失败: {resp.status_code} {resp.text}"
    auth_data = resp.json()
    jwt_token = auth_data["token"]
    print(f"  注册成功!")
    print(f"  用户名: {auth_data['user']['name']}")
    print(f"  邮  箱: {auth_data['user']['email']}")
    print(f"  JWT Token: {jwt_token[:20]}...{jwt_token[-10:]}")

    # ----------------------------------------------------------
    # 步骤 2: 创建 API Key
    # ----------------------------------------------------------
    step(2, "使用 JWT Token 创建 API Key")
    resp = requests.post(
        f"{BASE_URL}/api/keys",
        json={"name": "SDK示例密钥", "permissions": "full"},
        headers={"Authorization": f"Bearer {jwt_token}"},
    )
    assert resp.status_code == 201, f"创建 API Key 失败: {resp.status_code} {resp.text}"
    key_data = resp.json()
    api_key = key_data["key"]
    print(f"  API Key 创建成功!")
    print(f"  密钥名称: {key_data['name']}")
    print(f"  权    限: {key_data['permissions']}")
    print(f"  API Key:  {api_key}")

    # ----------------------------------------------------------
    # 步骤 3: 初始化 SDK 客户端
    # ----------------------------------------------------------
    step(3, "初始化 RememberMe SDK 客户端")
    client = RememberMe(
        api_key=api_key,
        base_url=BASE_URL,
        timeout=60,
    )
    print(f"  客户端初始化完成")
    print(f"  base_url: {client.base_url}")

    # ----------------------------------------------------------
    # 步骤 4: 写入记忆 (add)
    # ----------------------------------------------------------
    step(4, "写入记忆 (client.add)")

    print("\n  4a. 纯文本方式写入:")
    result1 = client.add(
        "用户是一名 Python 全栈开发者，擅长 FastAPI 和 React",
        user_id=test_user_id,
    )
    print(f"  写入结果:")
    pretty(result1)

    print("\n  4b. 对话消息列表方式写入:")
    result2 = client.add(
        [
            {"role": "user", "content": "我在北京工作，最近在研究大语言模型和 RAG 技术"},
            {"role": "assistant", "content": "很好！北京有很多优秀的 AI 研究团队，RAG 是当前非常热门的方向"},
        ],
        user_id=test_user_id,
        metadata={"source": "sdk_demo"},
    )
    print(f"  写入结果:")
    pretty(result2)

    print("\n  4c. 再写入一条记忆:")
    result3 = client.add(
        "用户喜欢喝咖啡，偏好手冲方式",
        user_id=test_user_id,
    )
    print(f"  写入结果:")
    pretty(result3)

    print("\n  等待 2 秒让记忆处理完成...")
    time.sleep(2)

    # ----------------------------------------------------------
    # 步骤 5: 语义搜索 (search)
    # ----------------------------------------------------------
    step(5, "语义搜索记忆 (client.search)")
    search_result = client.search(
        "用户的技术栈和工作方向",
        user_id=test_user_id,
        limit=5,
    )
    print(f"  搜索查询: '用户的技术栈和工作方向'")
    print(f"  命中条数: {len(search_result.memories)}")
    for i, mem in enumerate(search_result.memories):
        score_str = f"{mem.score:.4f}" if mem.score is not None else "N/A"
        print(f"  [{i+1}] 相关度={score_str} | {mem.memory}")

    # ----------------------------------------------------------
    # 步骤 6: 列出所有记忆 (get_all)
    # ----------------------------------------------------------
    step(6, "列出所有记忆 (client.get_all)")
    all_memories = client.get_all(user_id=test_user_id)
    print(f"  总记忆数: {all_memories.total}")
    for i, mem in enumerate(all_memories.memories):
        print(f"  [{i+1}] id={mem.id[:16]}... | {mem.memory}")

    # ----------------------------------------------------------
    # 步骤 7: 获取单条记忆 (get)
    # ----------------------------------------------------------
    step(7, "获取单条记忆详情 (client.get)")
    if all_memories.memories:
        target_id = all_memories.memories[0].id
        single_mem = client.get(target_id)
        print(f"  记忆 ID:    {single_mem.id}")
        print(f"  内    容:   {single_mem.memory}")
        print(f"  创建时间:   {single_mem.created_at}")
        print(f"  更新时间:   {single_mem.updated_at}")
        print(f"  user_id:    {single_mem.user_id}")
    else:
        print("  没有可用的记忆")
        target_id = None

    # ----------------------------------------------------------
    # 步骤 8: 更新记忆 (update)
    # ----------------------------------------------------------
    step(8, "更新记忆 (client.update)")
    if target_id:
        update_result = client.update(target_id, "用户是一名资深 Python 全栈开发者，精通 FastAPI、React 和 LLM 应用开发")
        print(f"  更新结果:")
        pretty(update_result)

        updated_mem = client.get(target_id)
        print(f"  更新后内容: {updated_mem.memory}")

    # ----------------------------------------------------------
    # 步骤 9: 查看变更历史 (history)
    # ----------------------------------------------------------
    step(9, "查看变更历史 (client.history)")
    if target_id:
        history = client.history(target_id)
        print(f"  历史记录条数: {len(history)}")
        for i, entry in enumerate(history):
            pretty(entry)

    # ----------------------------------------------------------
    # 步骤 10: 删除单条记忆 (delete)
    # ----------------------------------------------------------
    step(10, "删除单条记忆 (client.delete)")
    if target_id:
        delete_result = client.delete(target_id)
        print(f"  删除结果:")
        pretty(delete_result)

        print(f"  验证删除 - 尝试再次获取该记忆:")
        try:
            client.get(target_id)
            print(f"  (意外：记忆仍然存在)")
        except NotFoundError:
            print(f"  确认: 记忆已被成功删除 (NotFoundError)")

    # ----------------------------------------------------------
    # 步骤 11: 批量删除 (delete_all)
    # ----------------------------------------------------------
    step(11, "批量删除所有记忆 (client.delete_all)")
    remaining = client.get_all(user_id=test_user_id)
    print(f"  删除前剩余记忆: {remaining.total} 条")

    delete_all_result = client.delete_all(user_id=test_user_id)
    print(f"  批量删除结果:")
    pretty(delete_all_result)

    after = client.get_all(user_id=test_user_id)
    print(f"  删除后剩余记忆: {after.total} 条")

    # ----------------------------------------------------------
    # 完成
    # ----------------------------------------------------------
    client.close()
    print(f"\n{'#' * 60}")
    print(f"  示例运行完成!")
    print(f"  所有 SDK API 均调用成功")
    print(f"{'#' * 60}\n")


if __name__ == "__main__":
    main()
