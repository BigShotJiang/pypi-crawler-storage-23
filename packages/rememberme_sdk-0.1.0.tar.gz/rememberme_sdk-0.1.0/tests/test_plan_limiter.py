"""
会员计划限额管理 — 全链路测试

测试覆盖:
  1. 基本功能回归: 限额检查不影响正常 CRUD
  2. 速率限制: 超过 rate_per_minute 后返回 429
  3. 每日配额: 超过 daily_api_calls 后返回 429
  4. 记忆上限: 超过 max_memories 后 add 返回 429
  5. 只读Key权限: 限额检查不破坏已有权限逻辑
  6. Redis 状态验证: 限额计数器正确写入
"""

import json
import os
import sys
import time
import uuid

import requests

BASE_URL = os.getenv("TEST_BASE_URL", "http://localhost:8000")

with open("/tmp/sdk_test_apikey_full.txt") as f:
    FULL_API_KEY = f.read().strip()
with open("/tmp/sdk_test_apikey_ro.txt") as f:
    RO_API_KEY = f.read().strip()

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from rememberme import (
    AddResult,
    AuthenticationError,
    Memory,
    MemoryList,
    NotFoundError,
    RememberMe,
    RememberMeError,
)
from rememberme.exceptions import PermissionError as SDKPermissionError, RateLimitError


class TestResult:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.errors: list[str] = []

    def ok(self, name: str, detail: str = ""):
        self.passed += 1
        print(f"  [PASS] {name}  {detail}")

    def fail(self, name: str, reason: str):
        self.failed += 1
        self.errors.append(f"{name}: {reason}")
        print(f"  [FAIL] {name}  => {reason}")

    def summary(self):
        total = self.passed + self.failed
        print(f"\n{'='*70}")
        print(f"  Total: {total}  |  Passed: {self.passed}  |  Failed: {self.failed}")
        if self.errors:
            print(f"\n  Failed tests:")
            for e in self.errors:
                print(f"    - {e}")
        print(f"{'='*70}")
        return self.failed == 0


R = TestResult()


# ======================================================================
# Helper: 直接操作 Redis 来准备测试条件
# ======================================================================

def redis_cmd(*args):
    """通过 redis-cli 执行命令"""
    import subprocess
    result = subprocess.run(
        ["redis-cli"] + [str(a) for a in args],
        capture_output=True, text=True,
    )
    return result.stdout.strip()


def get_user_id_from_api_key(api_key: str) -> int | None:
    """通过一个轻量 API 调用, 从日志推断 user_id (用 /api/memories GET)"""
    resp = requests.get(
        f"{BASE_URL}/api/memories",
        headers={"Authorization": f"Bearer {api_key}"},
        params={"limit": 1},
        timeout=10,
    )
    if resp.status_code == 200:
        return None  # 需要从 Redis key 推断
    return None


# ======================================================================
# Part 1: 基本功能回归 — 限额未触发时正常工作
# ======================================================================

def test_basic_regression():
    print("\n" + "="*70)
    print("  PART 1: 基本功能回归 (限额未触发)")
    print("="*70)

    uid = f"plan_test_{uuid.uuid4().hex[:8]}"
    client = RememberMe(api_key=FULL_API_KEY, base_url=BASE_URL, timeout=60)

    # 1.1 Add
    try:
        result = client.add("限额测试: 用户喜欢Go语言", user_id=uid)
        assert isinstance(result, AddResult)
        R.ok("1.1 Add (with limiter active)", f"results={len(result.results)}")
    except Exception as e:
        R.fail("1.1 Add", str(e))

    time.sleep(1)

    # 1.2 Search
    try:
        result = client.search("Go语言", user_id=uid, limit=3)
        assert isinstance(result, MemoryList)
        R.ok("1.2 Search (with limiter active)", f"found={len(result.memories)}")
    except Exception as e:
        R.fail("1.2 Search", str(e))

    # 1.3 Get All
    try:
        result = client.get_all(user_id=uid)
        assert isinstance(result, MemoryList)
        assert len(result.memories) >= 1
        memory_id = result.memories[0].id
        R.ok("1.3 Get All", f"count={len(result.memories)}")
    except Exception as e:
        R.fail("1.3 Get All", str(e))
        memory_id = None

    # 1.4 Get Single
    if memory_id:
        try:
            mem = client.get(memory_id)
            assert isinstance(mem, Memory)
            R.ok("1.4 Get Single", f"id={memory_id[:16]}...")
        except Exception as e:
            R.fail("1.4 Get Single", str(e))

    # 1.5 Update
    if memory_id:
        try:
            resp = client.update(memory_id, "限额测试: 用户非常喜欢Go和Rust")
            assert isinstance(resp, dict)
            R.ok("1.5 Update", f"keys={list(resp.keys())}")
        except Exception as e:
            R.fail("1.5 Update", str(e))

    # 1.6 History
    if memory_id:
        try:
            hist = client.history(memory_id)
            assert isinstance(hist, list)
            R.ok("1.6 History", f"count={len(hist)}")
        except Exception as e:
            R.fail("1.6 History", str(e))

    # 1.7 Delete
    if memory_id:
        try:
            resp = client.delete(memory_id)
            assert isinstance(resp, dict)
            R.ok("1.7 Delete", str(resp))
        except Exception as e:
            R.fail("1.7 Delete", str(e))

    # 1.8 Delete All
    try:
        client.add("临时数据", user_id=uid)
        time.sleep(0.5)
        resp = client.delete_all(user_id=uid)
        assert isinstance(resp, dict)
        R.ok("1.8 Delete All", str(resp))
    except Exception as e:
        R.fail("1.8 Delete All", str(e))

    # 1.9 Read-only key 仍然正常拦截写入
    try:
        ro = RememberMe(api_key=RO_API_KEY, base_url=BASE_URL, timeout=10)
        ro.add("不应成功", user_id="ro_test")
        R.fail("1.9 Read-only still blocked", "Should have raised 403")
    except SDKPermissionError:
        R.ok("1.9 Read-only still blocked (403)")
    except RememberMeError as e:
        if e.status_code == 403:
            R.ok("1.9 Read-only still blocked (403)")
        else:
            R.fail("1.9 Read-only still blocked", f"status={e.status_code}")

    # 1.10 Invalid key 仍然 401
    try:
        bad = RememberMe(api_key="rm_sk_INVALID", base_url=BASE_URL, timeout=10)
        bad.search("test", user_id="x")
        R.fail("1.10 Invalid key still 401", "Should have raised")
    except AuthenticationError:
        R.ok("1.10 Invalid key still 401")
    except Exception as e:
        R.fail("1.10 Invalid key still 401", str(e))

    client.close()


# ======================================================================
# Part 2: 速率限制测试
# ======================================================================

def test_rate_limit():
    print("\n" + "="*70)
    print("  PART 2: 速率限制测试 (rate_per_minute)")
    print("="*70)

    # starter 计划限制 30 次/分钟
    # 我们不真的发 31 次请求 (太慢), 而是通过 Redis 注入假计数来模拟

    # 首先做一次正常请求来确认 user_id 并让 Redis 创建 key
    client = RememberMe(api_key=FULL_API_KEY, base_url=BASE_URL, timeout=30)
    uid = f"rate_test_{uuid.uuid4().hex[:8]}"

    try:
        client.search("test", user_id=uid)
    except Exception:
        pass

    # 找到 Redis 中的速率限制 key
    rl_keys = redis_cmd("keys", "rl:min:*")
    if rl_keys:
        # 获取最新的 rl key (属于我们的测试用户)
        keys = rl_keys.split("\n")
        # 取最后一个 key, 向其中注入 30 条假记录
        target_key = keys[-1]
        user_db_id = target_key.split(":")[-1]

        now = time.time()
        pipe_cmds = []
        for i in range(35):
            ts = now - 30 + i  # 最近 30 秒内的 35 个时间戳
            redis_cmd("zadd", target_key, str(ts), f"fake_{i}_{ts}")
        redis_cmd("expire", target_key, "120")

        # 现在再发请求, 应该触发 429
        try:
            client.search("test after rate limit", user_id=uid)
            R.fail("2.1 Rate limit triggers 429", "Should have raised RateLimitError")
        except RateLimitError as e:
            assert e.status_code == 429
            R.ok("2.1 Rate limit triggers 429", f"RateLimitError(429), body={e.body}")
        except RememberMeError as e:
            if e.status_code == 429:
                R.ok("2.1 Rate limit triggers 429", f"status=429, body={e.body}")
            else:
                R.fail("2.1 Rate limit triggers 429", f"Wrong status: {e.status_code}")
        except Exception as e:
            R.fail("2.1 Rate limit triggers 429", f"{type(e).__name__}: {e}")

        # 清理: 删除假数据
        redis_cmd("del", target_key)

        # 清理后应该恢复正常
        try:
            result = client.search("recovery test", user_id=uid)
            assert isinstance(result, MemoryList)
            R.ok("2.2 Recovery after rate limit cleared")
        except Exception as e:
            R.fail("2.2 Recovery after rate limit cleared", str(e))
    else:
        R.fail("2.1 Rate limit triggers 429", "No rl:min:* keys found in Redis")
        R.fail("2.2 Recovery after rate limit cleared", "Skipped")

    client.close()


# ======================================================================
# Part 3: 每日配额测试
# ======================================================================

def test_daily_quota():
    print("\n" + "="*70)
    print("  PART 3: 每日配额测试 (daily_api_calls)")
    print("="*70)

    client = RememberMe(api_key=FULL_API_KEY, base_url=BASE_URL, timeout=30)
    uid = f"quota_test_{uuid.uuid4().hex[:8]}"

    # 做一次正常请求
    try:
        client.search("test", user_id=uid)
    except Exception:
        pass

    # 找到 quota key 并注入超限值
    from datetime import datetime, timezone
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    quota_keys = redis_cmd("keys", f"quota:daily:*:{today}")

    if quota_keys:
        keys = quota_keys.split("\n")
        target_key = keys[-1]

        # starter 限制 500 次/天, 设为 501
        redis_cmd("set", target_key, "501")
        redis_cmd("expire", target_key, "86400")

        try:
            client.search("over quota", user_id=uid)
            R.fail("3.1 Daily quota triggers 429", "Should have raised")
        except RateLimitError as e:
            assert e.status_code == 429
            R.ok("3.1 Daily quota triggers 429", f"body={e.body}")
        except RememberMeError as e:
            if e.status_code == 429:
                R.ok("3.1 Daily quota triggers 429", f"status=429, body={e.body}")
            else:
                R.fail("3.1 Daily quota triggers 429", f"Wrong status: {e.status_code}")
        except Exception as e:
            R.fail("3.1 Daily quota triggers 429", f"{type(e).__name__}: {e}")

        # 恢复
        redis_cmd("set", target_key, "1")
        try:
            result = client.search("after quota reset", user_id=uid)
            assert isinstance(result, MemoryList)
            R.ok("3.2 Recovery after quota reset")
        except Exception as e:
            R.fail("3.2 Recovery after quota reset", str(e))
    else:
        R.fail("3.1 Daily quota triggers 429", "No quota keys found")
        R.fail("3.2 Recovery after quota reset", "Skipped")

    client.close()


# ======================================================================
# Part 4: 记忆上限测试
# ======================================================================

def test_memory_limit():
    print("\n" + "="*70)
    print("  PART 4: 记忆上限测试 (max_memories)")
    print("="*70)

    client = RememberMe(api_key=FULL_API_KEY, base_url=BASE_URL, timeout=60)
    uid = f"memlimit_{uuid.uuid4().hex[:8]}"

    # 从已有 Redis key 推断 DB user_id (rl:min:{user_id})
    rl_keys = redis_cmd("keys", "rl:min:*")
    if not rl_keys:
        # 先做一次请求产生 rl key
        try:
            client.search("probe", user_id=uid)
        except Exception:
            pass
        rl_keys = redis_cmd("keys", "rl:min:*")

    if rl_keys:
        db_user_id = rl_keys.split("\n")[-1].split(":")[-1]
        cache_key = f"mem_count:{db_user_id}"

        # 直接注入超限的 mem_count 缓存 (starter max=1000)
        redis_cmd("set", cache_key, "1001")
        redis_cmd("expire", cache_key, "120")

        try:
            client.add("should be blocked by memory limit", user_id=uid)
            R.fail("4.1 Memory limit blocks add", "Should have raised 429")
        except RateLimitError as e:
            assert e.status_code == 429
            R.ok("4.1 Memory limit blocks add (429)", f"body={e.body}")
        except RememberMeError as e:
            if e.status_code == 429:
                R.ok("4.1 Memory limit blocks add (429)", f"body={e.body}")
            else:
                R.fail("4.1 Memory limit blocks add", f"Wrong status: {e.status_code}")
        except Exception as e:
            R.fail("4.1 Memory limit blocks add", f"{type(e).__name__}: {e}")

        # 搜索不受 memory limit 影响 (只对 add 生效)
        try:
            result = client.search("test", user_id=uid)
            assert isinstance(result, MemoryList)
            R.ok("4.2 Search not blocked by memory limit")
        except RateLimitError:
            R.fail("4.2 Search not blocked by memory limit", "Search was incorrectly blocked")
        except Exception as e:
            R.fail("4.2 Search not blocked by memory limit", str(e))

        # 清理缓存后 add 应恢复正常
        redis_cmd("del", cache_key)
        try:
            result = client.add("after memory limit cleared", user_id=uid)
            assert isinstance(result, AddResult)
            R.ok("4.3 Add recovers after limit cleared")
        except Exception as e:
            R.fail("4.3 Add recovers after limit cleared", str(e))
    else:
        R.fail("4.1 Memory limit blocks add", "Cannot determine DB user_id from Redis")
        R.fail("4.2 Search not blocked by memory limit", "Skipped")
        R.fail("4.3 Add recovers after limit cleared", "Skipped")

    # cleanup
    try:
        client.delete_all(user_id=uid)
    except Exception:
        pass
    client.close()


# ======================================================================
# Part 5: Redis 状态验证
# ======================================================================

def test_redis_state():
    print("\n" + "="*70)
    print("  PART 5: Redis 状态验证")
    print("="*70)

    # 清空所有测试相关的 Redis keys
    for pattern in ["rl:min:*", "quota:daily:*", "mem_count:*"]:
        keys = redis_cmd("keys", pattern)
        if keys:
            for k in keys.split("\n"):
                if k.strip():
                    redis_cmd("del", k.strip())

    client = RememberMe(api_key=FULL_API_KEY, base_url=BASE_URL, timeout=60)
    uid = f"redis_state_{uuid.uuid4().hex[:8]}"

    # 做一次请求
    try:
        client.search("redis state test", user_id=uid)
    except Exception:
        pass

    # 5.1 检查 rl:min:* key 存在
    rl_keys = redis_cmd("keys", "rl:min:*")
    if rl_keys:
        R.ok("5.1 Rate limit key created in Redis", f"keys={rl_keys}")
    else:
        R.fail("5.1 Rate limit key created", "No rl:min:* keys found")

    # 5.2 检查 quota:daily:* key 存在
    from datetime import datetime, timezone
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    quota_keys = redis_cmd("keys", f"quota:daily:*:{today}")
    if quota_keys:
        R.ok("5.2 Daily quota key created", f"keys={quota_keys}")
    else:
        R.fail("5.2 Daily quota key created", "No quota:daily keys found")

    # 5.3 做一次 add, 检查 mem_count 缓存被创建后又被清除
    try:
        client.add("redis state add test", user_id=uid)
        time.sleep(0.5)
        # add 后 invalidate_memory_count 会删除 mem_count key
        mc_keys = redis_cmd("keys", "mem_count:*")
        # 可能已经被清除了 (invalidate), 这是正确行为
        R.ok("5.3 Memory count cache invalidated after add", f"remaining_keys={mc_keys or 'none'}")
    except Exception as e:
        R.fail("5.3 Memory count cache", str(e))

    # 5.4 多次请求后 quota 计数递增
    initial_keys = redis_cmd("keys", f"quota:daily:*:{today}")
    if initial_keys:
        target = initial_keys.split("\n")[-1]
        val_before = int(redis_cmd("get", target) or "0")
        try:
            client.search("increment test", user_id=uid)
        except Exception:
            pass
        val_after = int(redis_cmd("get", target) or "0")
        if val_after > val_before:
            R.ok("5.4 Quota counter increments", f"{val_before} -> {val_after}")
        else:
            R.fail("5.4 Quota counter increments", f"before={val_before}, after={val_after}")
    else:
        R.fail("5.4 Quota counter increments", "No quota key")

    # cleanup
    try:
        client.delete_all(user_id=uid)
    except Exception:
        pass
    client.close()


# ======================================================================
# Part 6: 429 响应体格式验证
# ======================================================================

def test_error_body_format():
    print("\n" + "="*70)
    print("  PART 6: 429 响应体格式验证")
    print("="*70)

    # 注入超限状态, 直接用 requests 查看原始响应
    client = RememberMe(api_key=FULL_API_KEY, base_url=BASE_URL, timeout=30)
    uid = f"body_test_{uuid.uuid4().hex[:8]}"

    # 先触发一次请求建立 key
    try:
        client.search("body format test", user_id=uid)
    except Exception:
        pass

    from datetime import datetime, timezone
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    quota_keys = redis_cmd("keys", f"quota:daily:*:{today}")

    if quota_keys:
        target = quota_keys.split("\n")[-1]
        redis_cmd("set", target, "501")

        # 用 raw requests 检查响应体结构
        resp = requests.post(
            f"{BASE_URL}/api/memories/search",
            headers={
                "Authorization": f"Bearer {FULL_API_KEY}",
                "Content-Type": "application/json",
            },
            json={"query": "test", "user_id": uid},
            timeout=10,
        )

        if resp.status_code == 429:
            body = resp.json()
            detail = body.get("detail", {})

            # 检查结构化字段
            has_message = "message" in detail
            has_type = "type" in detail
            has_limit = "limit" in detail

            if has_message and has_type and has_limit:
                R.ok("6.1 429 body has structured fields", f"type={detail.get('type')}, limit={detail.get('limit')}")
            else:
                R.fail("6.1 429 body structure", f"Missing fields. Got: {detail}")
        else:
            R.fail("6.1 429 body structure", f"Expected 429, got {resp.status_code}")

        # 恢复
        redis_cmd("set", target, "1")
    else:
        R.fail("6.1 429 body structure", "No quota key to inject")

    client.close()


# ======================================================================
# Main
# ======================================================================

def main():
    print("\n" + "#"*70)
    print("  RememberMe 会员计划限额管理 — 全链路测试")
    print(f"  Base URL: {BASE_URL}")
    print(f"  API Key:  {FULL_API_KEY[:20]}...")
    print("#"*70)

    t0 = time.time()

    test_basic_regression()
    test_rate_limit()
    test_daily_quota()
    test_memory_limit()
    test_redis_state()
    test_error_body_format()

    elapsed = time.time() - t0
    print(f"\n  Total time: {elapsed:.1f}s")

    success = R.summary()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
