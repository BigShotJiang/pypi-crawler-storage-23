#!/bin/bash
# RememberMe SDK 上传到 PyPI 的脚本
# 
# 使用前请确保：
# 1. 已注册 PyPI 账号：https://pypi.org/account/register/
# 2. 已创建 API Token：https://pypi.org/manage/account/token/
#    （Scope 选 "Entire account" 或只选 "rememberme-sdk"）
#
# 方式一：使用环境变量（推荐）
#   export TWINE_USERNAME=__token__
#   export TWINE_PASSWORD=pypi-xxxxxxxxxxxxxxxx  # 你的 API Token
#   ./scripts/upload_to_pypi.sh
#
# 方式二：首次运行时会提示输入
#   Username: __token__
#   Password: pypi-你的Token
#
# 方式三：使用 .pypirc（不推荐，Token 会明文存储）
#   在 ~/.pypirc 中配置：
#   [pypi]
#   username = __token__
#   password = pypi-xxxxxxxxxxxxxxxx

set -e
cd "$(dirname "$0")/.."

echo ">>> 构建 rememberme-sdk 分发包..."
pip install -q build twine
rm -rf dist/ build/ *.egg-info 2>/dev/null
python -m build

echo ""
echo ">>> 上传到 PyPI..."
twine upload dist/*

echo ""
echo ">>> 上传完成！用户现在可以通过以下命令安装："
echo "    pip install rememberme-sdk"
echo ""
