# TradeMux

Python SDK for TradeMux, a unified trading API for MetaTrader (MT4/MT5) and OANDA.

Docs: https://docs.trademux.io

## Install

```bash
pip install trademux
```

## Quickstart (MetaTrader)

```python
from trademux import MTClient

client = MTClient(api_key="sb_tmux_...")
print(client.get_server_status())
# {"status": "ok"}

order = client.buy_market("EURUSD", 0.01, sl=1.0900, tp=1.1100, comment="tmx demo")
print(order)

print(client.get_account_info())
print(client.get_balance())
print(client.get_equity())
```

Make sure the MT4/MT5 EA is running and connected to the same API key.

## Quickstart (OANDA)

```python
from trademux import OandaClient

client = OandaClient(
    api_key="sb_tmux_...",
    oanda_api_key="oanda_pat_...",
)

print(client.get_server_status())
# {"status": "ok"}

order = client.buy_market("EURUSD", 0.01, sl=1.0900, tp=1.1100, comment="tmx demo")
print(order)

print(client.get_account_info())
print(client.get_balance())
print(client.get_equity())
```
