# Event-сервис для доменной сущности (генерация кода)

Классы из `tp_common.event_service`: `BaseEvent`, `BaseEventMessage`. Топик: `events.{SERVICE_NAME}.public.{EVENT_GROUP}`.

**EventGroup и типы событий (Event-enum)** хранятся в `src/types/events.py`. Там: один член `EventGroup` на сущность (например `USERS = "users"`) и enum типов с обязательными `CREATE = "create"`, `UPDATE = "update"`, `DELETE = "delete"`. В файле event-сервиса их импортировать, не объявлять.

---

## Шаблон event-сервиса (в своём модуле сервиса)

Импорт `EventGroup` и `XxxEvent` из `src/types/events.py`. В файле — только payload, Message, EventService.

```python
from pydantic import BaseModel
from tp_common.event_service.schemas import BaseEventMessage
from tp_common.event_service.service import BaseEvent

from src.types.events import EventGroup, UserEvent

# 1. Payload — доменная модель (поля как в контракте/БД)
class User(BaseModel):
    id: int
    name: str
    # ...

# 2. Сообщение
class UserEventMessage(BaseEventMessage[User, UserEvent]):
    pass

# 3. Event-сервис — 4 атрибута класса обязательны
class UserEventService(BaseEvent[UserEventMessage, UserEvent]):
    SERVICE_NAME = "crm-users"   # имя сервиса (часть топика)
    EVENT_GROUP = EventGroup.USERS
    MESSAGE_CLASS = UserEventMessage
    EVENT_TYPE_CLASS = UserEvent
```

---

## Чек-лист генерации

**В `src/types/events.py`** (если ещё нет):
- [ ] `EventGroup(str, Enum)`: одно значение на сущность, например `USERS = "users"`
- [ ] Event-enum: обязательно `CREATE = "create"`, `UPDATE = "update"`, `DELETE = "delete"`; при необходимости свои типы

**В модуле event-сервиса**:
- [ ] Импорт `EventGroup`, `XxxEvent` из `src.types.events`
- [ ] Pydantic-модель payload (поля сущности)
- [ ] `BaseEventMessage[PayloadModel, EventEnum]` — пустой класс или с docstring
- [ ] Класс-наследник `BaseEvent[MessageClass, EventEnum]` с атрибутами: `SERVICE_NAME`, `EVENT_GROUP`, `MESSAGE_CLASS`, `EVENT_TYPE_CLASS`
