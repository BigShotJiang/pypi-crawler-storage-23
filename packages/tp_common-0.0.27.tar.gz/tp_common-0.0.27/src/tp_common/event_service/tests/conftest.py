"""Фикстуры для онлайновых тестов event_service (реальный Kafka)."""

from __future__ import annotations

import logging
import os
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

import pytest
from confluent_kafka import Consumer
from pydantic import BaseModel

from tp_common.event_service.schemas import BaseEventMessage
from tp_common.event_service.service import BaseEvent
from tp_common.kafka.connector import KafkaConnector


def _load_dotenv() -> None:
    """Загружает .env из корня проекта в os.environ (только если переменная ещё не задана)."""
    root = Path(__file__).resolve().parent
    for _ in range(6):
        env_file = root / ".env"
        if env_file.is_file():
            for line in env_file.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, value = line.partition("=")
                    key, value = key.strip(), value.strip()
                    if key and os.environ.get(key) is None:
                        os.environ[key] = value
            return
        root = root.parent


_load_dotenv()


def _kafka_url() -> str | None:
    return os.environ.get("KAFKA_URL") or os.environ.get("TP_KAFKA_URL")


def _require_kafka_url() -> str:
    url = _kafka_url()
    if not url or not url.strip():
        pytest.skip("Онлайновые тесты требуют KAFKA_URL или TP_KAFKA_URL в окружении")
    return url


# --- Минимальная модель события для тестов (аналог example.UserEventService) ---


class EventGroup(str, Enum):
    USERS = "users"


class UserEvent(str, Enum):
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"
    CHANGE_NAME = "change_name"


class User(BaseModel):
    id: int
    name: str
    description: str | None = None
    is_active: bool
    created_at: datetime
    updated_at: datetime | None = None


class UserEventMessage(BaseEventMessage[User, UserEvent]):
    """Сообщение события пользователя для тестов."""


class UserEventService(BaseEvent[UserEventMessage, UserEvent]):
    """Сервис событий пользователей для тестов."""

    SERVICE_NAME = "postgres"
    EVENT_GROUP = EventGroup.USERS
    MESSAGE_CLASS = UserEventMessage
    EVENT_TYPE_CLASS = UserEvent


# --- Фикстуры ---


@pytest.fixture(scope="session")
def kafka_url() -> str:
    """URL Kafka для онлайновых тестов. Пропуск теста, если не задан."""
    return _require_kafka_url()


class _TestKafkaConnector(KafkaConnector):
    """Коннектор с укороченными таймаутами для тестов (быстрый rebalance, не ждём 30 сек)."""

    def get_consumer(
        self,
        group_id: str,
        auto_offset_reset: str = "earliest",
        enable_auto_commit: bool = False,
        session_timeout_ms: int = 6_000,
        max_poll_interval_ms: int = 30_000,
        overrides: dict[str, Any] | None = None,
    ) -> Consumer:
        return super().get_consumer(
            group_id=group_id,
            auto_offset_reset=auto_offset_reset,
            enable_auto_commit=enable_auto_commit,
            session_timeout_ms=session_timeout_ms,
            max_poll_interval_ms=max_poll_interval_ms,
            overrides=overrides,
        )


@pytest.fixture(scope="session")
def kafka_connector(kafka_url: str) -> KafkaConnector:
    """Коннектор к Kafka (session-scoped), с укороченными таймаутами для тестов."""
    return _TestKafkaConnector(kafka_url)


@pytest.fixture
def event_service_logger() -> logging.Logger:
    """Логгер для сервиса событий в тестах."""
    return logging.getLogger("event_service_tests")


@pytest.fixture
def user_event_service(
    kafka_connector: KafkaConnector,
    event_service_logger: logging.Logger,
) -> UserEventService:
    """Экземпляр UserEventService с уникальной consumer group для изоляции тестов."""
    import uuid

    return UserEventService(
        connector=kafka_connector,
        log=event_service_logger,
        consumer_group=f"test_online_{uuid.uuid4().hex[:12]}",
        subscribe_to=None,
        retry_enabled=False,
    )


@pytest.fixture
def user_event_service_subscribe_create(
    kafka_connector: KafkaConnector,
    event_service_logger: logging.Logger,
) -> UserEventService:
    """Сервис, подписанный только на CREATE."""
    import uuid

    return UserEventService(
        connector=kafka_connector,
        log=event_service_logger,
        consumer_group=f"test_online_create_{uuid.uuid4().hex[:12]}",
        subscribe_to=[UserEvent.CREATE],
        retry_enabled=False,
    )
