import copy
import datetime
import os
import random
import time
from collections import deque
from pathlib import Path
from typing import Any, Deque, Mapping, TypedDict

import matplotlib
import numpy as np
from scipy.fft import fft, fftfreq
from robot.robot_base import (
    DEFAULT_MAX_DISP,
    DEFAULT_MAX_ACC,
    DEFAULT_ROBOT_FREQ,
    DEFAULT_MAX_VEL,
)
from robot.robot_base import TrajParams, SystemIdParams, Trajectory
from robot.robot_base import store_recorder_data_in_data_folder
from robot.robot_interface import RobotInterface
from reforge_core.util.utility import extract_dynamic_variables, read_identification_parameters
from matplotlib import pyplot as plt

from types import SimpleNamespace
from reforge_core.control.python.covalent_wrapper import (
    RobotState as _RobotState,
    ShaperInterface as _ShaperInterface,
)

covalent = SimpleNamespace(
    RobotState=_RobotState,
    ShaperInterface=_ShaperInterface,
)


# =========================
# User-Tunable Plot Options
# =========================
# Turn interactive plotting on/off.
# Set `REFORGE_PLOT_INTERACTIVE=1` to show figures; use `0` for headless/long runs.
PLOT_INTERACTIVE = os.getenv("REFORGE_PLOT_INTERACTIVE", "1") == "1"
if not PLOT_INTERACTIVE:
    matplotlib.use("Agg", force=True)

# Save plots to PNG when enabled.
# Set `REFORGE_PLOT_SAVE=1` to save figures; keep `0` for fastest execution.
PLOT_SAVE = os.getenv("REFORGE_PLOT_SAVE", "0") == "1"
PLOT_DPI = (
    120  # Output image resolution [dots per inch] used when `PLOT_SAVE` is enabled.
)

# ===========================
# User-Tunable Test Execution
# ===========================
# Post-motion hold [s] to capture residual vibration after the move ends.
# Increase for slower-settling systems; decrease to shorten test duration.
DWELL_TIME = 4

# Repetitions per axis when building random pose/axis experiment pairs.
# Increase for testing more poses; decrease for quicker tests.
AXIS_REPETITIONS = 1


# =============================
# User-Tunable Signal Analysis
# =============================
# Butterworth filter order (higher means sharper cutoff, but more phase effect).
BUTTER_ORDER = 4

# Butterworth low-pass cutoff frequency [Hz].
BUTTER_CUTOFF = 40

# Useful lenght of residual vibraiton window [s] used to calcualte FFT.
# Longer windows improve frequency resolution, shorter windows track transients.
# Should be smaller than `DWELL_TIME'
FFT_WINDOW_DURATION_SEC = 3

# FFT window start offset [s] from trajectory start.
# Increase to skip launch transients before frequency analysis.
# Affects plot_fft_summaries()
FFT_WINDOW_START_SEC = 0

# Moving-window lenght [s] for removing trend of rotated accerometer readings.
# Increase for smoother metrics, decrease for more reactive metrics.
# Affects plot_rotated_accelerometer_readings()
MOVING_AVG_WINDOW_SEC = 0.2

# Number of lowest FFT bins to skip to avoid DC/bias dominance in peak searches.
DC_FFT_OFFSET = 5


# ==================================
# Auto-Resolved Paths (Usually Fixed)
# ==================================
# Repository paths are derived from this file location.
# Change these only if project directory layout changes.
THIS_DIR = Path(__file__).resolve().parent
REPO_ROOT = THIS_DIR.parents[2]


def _package_dir(pkg_name: str) -> Path | None:
    """Return the package directory for an importable module.

    Args:
        pkg_name: Module name to import.

    Returns:
        `Path | None` to the module directory, or None if not found.

    Side Effects:
        Attempts to import the module.

    Raises:
        None.

    Preconditions:
        None.
    """
    try:
        mod = __import__(pkg_name)
    except Exception:
        return None
    mod_file = getattr(mod, "__file__", None)
    if not mod_file:
        return None
    return Path(mod_file).resolve().parent


# Installed/project `robot` package directory, if importable.
ROBOT_PKG_DIR = _package_dir("robot")
# Installed/project `util` package directory, if importable.
UTIL_PKG_DIR = _package_dir("util")

MODEL_DIR = (
    (ROBOT_PKG_DIR / "models" / "current")
    if ROBOT_PKG_DIR
    else (REPO_ROOT / "src/robot/models/current")
)
# Python source root used by the shaper wrapper for model-related imports.
PYTHON_SRC_ROOT = UTIL_PKG_DIR.parent if UTIL_PKG_DIR else (REPO_ROOT / "src")
# ===========================
# Output Folder Configuration
# ===========================
# Date-based output folder used by vibration-test CSV and saved figures.
TODAY = datetime.datetime.now()
VIBRATION_DATA_FOLDER = f"src/unit_tests/data/{TODAY.year}-{TODAY.month}-{TODAY.day}"

# Plot output folder used when `PLOT_SAVE` is enabled.
PLOT_OUTPUT_FOLDER = Path(VIBRATION_DATA_FOLDER) / "plots"


class VibrationTestPlots:
    """Generate all vibration-test diagnostic figures.

    Args:
        None.
    Returns:
        None.
    Side Effects:
        None.
    Raises:
        None.
    Preconditions:
        None.
    """

    @staticmethod
    def finalize_figure(fig: Any, plot_name: str) -> None:
        """Apply common figure finalization behavior for vibration-test plots.

        Args:
            fig: Matplotlib figure object to finalize.
            plot_name: Output filename stem used when saving a PNG.
        Returns:
            `None`.
        Side Effects:
            Writes a PNG file when `PLOT_SAVE` is enabled.
            Displays the figure when `PLOT_INTERACTIVE` is enabled.
            Closes the figure handle.
            Prints a warning line if interactive display fails.
        Raises:
            OSError: If the output directory cannot be created or written.
        Preconditions:
            `fig` is a valid matplotlib figure.
            `plot_name` is a non-empty filename-safe stem.
        """
        # Save to disk first when enabled so figures are preserved in headless runs.
        if PLOT_SAVE:
            PLOT_OUTPUT_FOLDER.mkdir(parents=True, exist_ok=True)
            fig.savefig(PLOT_OUTPUT_FOLDER / f"{plot_name}.png", dpi=PLOT_DPI)
        # Show interactively only when explicitly enabled.
        if PLOT_INTERACTIVE:
            # fig.show()
            plt.show()

    @staticmethod
    def plot_rotated_accelerometer_readings(
        *,
        time_vec: np.ndarray,
        signal: np.ndarray,
        moving_avg: np.ndarray,
        residual: np.ndarray,
        title: str,
        signal_color: str,
        signal_linestyle: str,
        plot_name: str,
    ) -> None:
        """Plot base-frame acceleration components with trend and residual traces.

        Args:
            time_vec: Sample times [s], shape `(N,)`.
            signal: Base-frame acceleration [m/s^2], shape `(N, 3)`.
            moving_avg: Moving-average acceleration [m/s^2], shape `(N, 3)`.
            residual: Residual acceleration [m/s^2], shape `(N, 3)`.
            title: Figure title text.
            signal_color: Matplotlib color for the primary signal trace.
            signal_linestyle: Matplotlib linestyle for the primary signal trace.
            plot_name: Output filename stem used by `finalize_figure`.
        Returns:
            `None`.
        Side Effects:
            Creates a matplotlib figure and delegates save/show/close behavior.
        Raises:
            ValueError: If input arrays are incompatible with plotting operations.
        Preconditions:
            `time_vec`, `signal`, `moving_avg`, and `residual` are time-aligned.
            `signal`, `moving_avg`, and `residual` each contain exactly 3 columns.
        """
        base_font = float(plt.rcParams.get("font.size", 10))
        title_size = base_font + 6
        label_size = base_font + 6

        fig, axes = plt.subplots(3, 1, sharex=True)
        labels = ("Ax [m/s^2]", "Ay [m/s^2]", "Az [m/s^2]")

        # Each iteration renders one acceleration axis with a consistent style.
        for i, axis in enumerate(axes):
            axis.plot(
                time_vec,
                signal[:, i],
                color=signal_color,
                linestyle=signal_linestyle,
                linewidth=2,
                label="Signal",
            )
            axis.plot(
                time_vec,
                moving_avg[:, i],
                color="b",
                linewidth=2,
                label="Moving Avg",
            )
            axis.plot(
                time_vec,
                residual[:, i],
                color="m",
                linewidth=2,
                label="Signal - Avg",
            )
            axis.set_ylabel(labels[i], fontsize=base_font, fontweight="bold")
            axis.set_xlim(0.0, DWELL_TIME)
            axis.legend(prop={"weight": "bold", "size": base_font}, loc="lower right")

        axes[0].set_title(title, fontsize=title_size)
        axes[2].set_xlabel("Time [s]", fontsize=label_size, fontweight="bold")
        fig.tight_layout()
        VibrationTestPlots.finalize_figure(fig, plot_name)

    @staticmethod
    def plot_encoder_fullacc_residual_vibration(
        *,
        time_u: np.ndarray,
        time_s: np.ndarray,
        encoder_u_axis: np.ndarray,
        encoder_s_axis: np.ndarray,
        mag_acc_u: np.ndarray,
        mag_acc_s: np.ndarray,
        idx_vib_u: int,
        idx_vib_s: int,
        peak_acc_u: int,
        peak_acc_s: int,
        duration_diff_s: float,
        closest_time_abs: float | None,
        pose: int,
        axis: int,
    ) -> None:
        """Plot encoder history, full acceleration norm, and residual-window zoom.

        Args:
            time_u: Unshaped time samples [s], shape `(N_u,)`.
            time_s: Shaped time samples [s], shape `(N_s,)`.
            encoder_u_axis: Unshaped encoder signal [rad], shape `(N_u,)`.
            encoder_s_axis: Shaped encoder signal [rad], shape `(N_s,)`.
            mag_acc_u: Unshaped acceleration norm [m/s^2], shape `(N_u,)`.
            mag_acc_s: Shaped acceleration norm [m/s^2], shape `(N_s,)`.
            idx_vib_u: Start index of unshaped residual-vibration window.
            idx_vib_s: Start index of shaped residual-vibration window.
            peak_acc_u: Peak index within unshaped residual window.
            peak_acc_s: Peak index within shaped residual window.
            duration_diff_s: Shaped minus unshaped trajectory duration [s].
            closest_time_abs: Optional reference timestamp [s] for threshold marker.
            pose: Pose identifier used in the output filename.
            axis: Joint-axis identifier used in the output filename.
        Returns:
            `None`.
        Side Effects:
            Creates a matplotlib figure and delegates save/show/close behavior.
        Raises:
            IndexError: If any provided index is outside the corresponding vector.
            ValueError: If plotted arrays are malformed.
        Preconditions:
            Time and signal arrays are aligned for each trajectory type.
            Residual-window and peak indices are valid for their arrays.
        """
        base_font = float(plt.rcParams.get("font.size", 10))
        title_size = base_font + 6
        label_size = base_font + 6
        legend_size = base_font + 3

        fig, axes = plt.subplots(3, 1, sharex=True)
        axes[0].plot(time_u, encoder_u_axis, color="k", linewidth=2)
        axes[0].plot(time_s, encoder_s_axis, color="r", linestyle="--", linewidth=2)
        axes[0].axvline(time_u[idx_vib_u], color="k", linestyle=":", linewidth=2)
        axes[0].axvline(time_s[idx_vib_s], color="r", linestyle=":", linewidth=2)
        axes[0].annotate(
            f"Added delay ΔT = {duration_diff_s:.2f} [s]",
            xy=(time_s[idx_vib_s], encoder_s_axis[idx_vib_s]),
            xytext=(10, 10),
            textcoords="offset points",
            color="r",
            fontsize=plt.rcParams.get("font.size", 10) + 3,
        )
        axes[0].set_ylabel("Encoder [rad]", fontsize=label_size, fontweight="bold")
        axes[0].set_title("Encoder (Moving Joint)", fontsize=title_size)

        axes[1].plot(time_u, mag_acc_u, color="k", linewidth=2)
        axes[1].plot(time_s, mag_acc_s, color="r", linestyle="--", linewidth=2)
        axes[1].axvline(time_u[idx_vib_u], color="k", linestyle=":", linewidth=2)
        axes[1].axvline(time_s[idx_vib_s], color="r", linestyle=":", linewidth=2)
        # Add the optional threshold crossing marker when available.
        if closest_time_abs is not None:
            y_mid_full = 0.25 * (np.max(mag_acc_u) + np.min(mag_acc_u))
            axes[1].axvline(closest_time_abs, color="blue", linestyle="-.", linewidth=2)
            axes[1].annotate(
                f"  Initial Avg. acceleration \n  reached at t = {closest_time_abs:.2f} [s]",
                xy=(closest_time_abs, y_mid_full),
                xytext=(0, 0),
                textcoords="offset points",
                color="blue",
                fontsize=plt.rcParams.get("font.size", 10) + 3,
            )
        axes[1].set_ylabel("Accel Norm [m/s^2]", fontsize=label_size, fontweight="bold")
        axes[1].set_title("Acceleration Norm (Full Trajectory)", fontsize=title_size)

        axes[2].plot(
            time_u[idx_vib_u:],
            mag_acc_u[idx_vib_u:],
            color="k",
            linewidth=2,
            label="Unshaped",
        )
        axes[2].plot(
            time_s[idx_vib_s:],
            mag_acc_s[idx_vib_s:],
            color="r",
            linestyle="--",
            linewidth=2,
            label="Shaped",
        )
        axes[2].scatter(
            [time_u[idx_vib_u + peak_acc_u], time_s[idx_vib_s + peak_acc_s]],
            [mag_acc_u[idx_vib_u + peak_acc_u], mag_acc_s[idx_vib_s + peak_acc_s]],
            s=60,
            c="green",
            zorder=5,
            label="Max acceleration peak",
        )
        axes[2].set_ylabel("Accel Norm [m/s^2]", fontsize=label_size, fontweight="bold")
        axes[2].set_xlabel("Time [s]", fontsize=label_size, fontweight="bold")
        axes[2].set_title("Residual Vibration Window", fontsize=title_size)
        axes[2].legend(prop={"weight": "bold", "size": legend_size}, loc="upper right")
        axes[0].legend(
            ["Unshaped", "Shaped"],
            prop={"weight": "bold", "size": legend_size},
            loc="upper right",
        )
        axes[1].legend(
            ["Unshaped", "Shaped"],
            prop={"weight": "bold", "size": legend_size},
            loc="upper right",
        )
        # Apply the same x-axis window to all subplots for visual comparison.
        x_limit = (
            float(closest_time_abs + 1.0)
            if closest_time_abs is not None
            else float(DWELL_TIME)
        )
        for ax in axes:
            ax.set_xlim(0.0, x_limit)
        plt.tight_layout()
        VibrationTestPlots.finalize_figure(
            fig, f"residual_window_pose_{pose}_axis_{axis}"
        )

    @staticmethod
    def plot_fft_summaries(
        *,
        f_u: np.ndarray,
        f_s: np.ndarray,
        fft_u_x: np.ndarray,
        fft_u_y: np.ndarray,
        fft_u_z: np.ndarray,
        fft_s_x: np.ndarray,
        fft_s_y: np.ndarray,
        fft_s_z: np.ndarray,
        fft_u_norm: np.ndarray,
        fft_s_norm: np.ndarray,
        pose: int,
        axis: int,
        plot_fft_axes: bool,
        plot_fft_norm: bool,
    ) -> None:
        """Plot FFT comparisons for per-axis and norm acceleration spectra.

        Args:
            f_u: Unshaped one-sided frequency bins [Hz], shape `(N_f,)`.
            f_s: Shaped one-sided frequency bins [Hz], shape `(N_f,)` or compatible.
            fft_u_x: Unshaped X-axis FFT magnitude.
            fft_u_y: Unshaped Y-axis FFT magnitude.
            fft_u_z: Unshaped Z-axis FFT magnitude.
            fft_s_x: Shaped X-axis FFT magnitude.
            fft_s_y: Shaped Y-axis FFT magnitude.
            fft_s_z: Shaped Z-axis FFT magnitude.
            fft_u_norm: Unshaped norm FFT magnitude.
            fft_s_norm: Shaped norm FFT magnitude.
            pose: Pose identifier used in figure titles/filenames.
            axis: Joint-axis identifier used in output filenames.
            plot_fft_axes: Predicate controlling the per-axis FFT figure.
            plot_fft_norm: Predicate controlling the norm FFT figure.
        Returns:
            `None`.
        Side Effects:
            Creates one or two matplotlib figures and delegates save/show/close.
        Raises:
            ValueError: If frequency and amplitude vectors are incompatible.
        Preconditions:
            Frequency vectors and matching FFT vectors are aligned in length.
            At least one of `plot_fft_axes` or `plot_fft_norm` is `True` to emit plots.
        """
        base_font = float(plt.rcParams.get("font.size", 10))
        title_size = base_font + 6
        label_size = base_font + 6
        legend_size = base_font + 3

        # Plot per-axis FFTs when requested.
        if plot_fft_axes:
            fig, axes = plt.subplots(3, 1, sharex=True)
            axes[0].plot(f_u, fft_u_x, color="k", linewidth=2)
            axes[0].plot(f_s, fft_s_x, color="r", linestyle="--", linewidth=2)
            axes[0].set_ylabel("Ax FFT", fontsize=label_size, fontweight="bold")
            axes[0].set_title("FFT X", fontsize=title_size)
            axes[0].set_xlim(0.0, 30.0)

            axes[1].plot(f_u, fft_u_y, color="k", linewidth=2)
            axes[1].plot(f_s, fft_s_y, color="r", linestyle="--", linewidth=2)
            axes[1].set_ylabel("Ay FFT", fontsize=label_size, fontweight="bold")
            axes[1].set_title("FFT Y", fontsize=title_size)
            axes[1].set_xlim(0.0, 30.0)

            axes[2].plot(f_u, fft_u_z, color="k", linewidth=2)
            axes[2].plot(f_s, fft_s_z, color="r", linestyle="--", linewidth=2)
            axes[2].set_ylabel("Az FFT", fontsize=label_size, fontweight="bold")
            axes[2].set_xlabel("Frequency [Hz]", fontsize=label_size, fontweight="bold")
            axes[2].set_title("FFT Z", fontsize=title_size)
            axes[2].set_xlim(0.0, 30.0)
            axes[0].legend(
                ["Unshaped", "Shaped"], prop={"weight": "bold", "size": legend_size}
            )
            plt.tight_layout()
            VibrationTestPlots.finalize_figure(fig, f"fft_axes_pose_{pose}_axis_{axis}")

        # Plot FFT of the acceleration norm when requested.
        if plot_fft_norm:
            fig_norm, ax_norm = plt.subplots(1, 1)
            ax_norm.plot(f_u, fft_u_norm, color="k", linewidth=2)
            ax_norm.plot(f_s, fft_s_norm, color="r", linestyle="--", linewidth=2)
            ax_norm.set_title(
                f"FFT of Acceleration Norm at Configuration {pose}",
                fontsize=title_size,
            )
            ax_norm.set_xlabel("Frequency [Hz]", fontsize=label_size, fontweight="bold")
            ax_norm.set_ylabel(
                "Acceleration Norm FFT", fontsize=label_size, fontweight="bold"
            )
            ax_norm.legend(
                ["Unshaped", "Shaped"], prop={"weight": "bold", "size": legend_size}
            )
            ax_norm.set_xlim(0.0, 30.0)
            ax_norm.grid()
            fig_norm.tight_layout()
            VibrationTestPlots.finalize_figure(
                fig_norm, f"fft_norm_pose_{pose}_axis_{axis}"
            )

    @staticmethod
    def plot_shaped_vs_unshaped_trajectory(
        *,
        unshaped: Mapping[str, np.ndarray],
        shaped: Mapping[str, np.ndarray],
        moved_axis: int | None,
        plot_name: str,
    ) -> None:
        """Plot shaped versus unshaped joint position, velocity, and acceleration.

        Args:
            unshaped: Mapping with keys `time`, `positions`, `velocities`,
                `accelerations` for the unshaped trajectory.
            shaped: Mapping with keys `time`, `positions`, `velocities`,
                `accelerations` for the shaped trajectory.
            moved_axis: Joint index to plot; `None` plots full arrays directly.
            plot_name: Output filename stem used by `finalize_figure`.
        Returns:
            `None`.
        Side Effects:
            Creates a matplotlib figure and delegates save/show/close behavior.
        Raises:
            KeyError: If required trajectory keys are missing.
            IndexError: If `moved_axis` is out of bounds for trajectory arrays.
            ValueError: If provided arrays are not plottable.
        Preconditions:
            Both trajectory mappings contain aligned time and signal arrays.
            `moved_axis` is `None` or a valid joint index.
        """
        fig, axes = plt.subplots(3, 1, sharex=True, figsize=(10, 8))
        base_font = float(plt.rcParams.get("font.size", 10))
        title_size = base_font + 6
        label_size = base_font + 6
        legend_size = base_font + 3
        time_u = unshaped["time"]
        time_s = shaped["time"]

        # Plot either full vectors or one moved axis based on caller intent.
        if moved_axis is None:
            pos_u = unshaped["positions"]
            pos_s = shaped["positions"]
            vel_u = unshaped["velocities"]
            vel_s = shaped["velocities"]
            acc_u = unshaped["accelerations"]
            acc_s = shaped["accelerations"]
        else:
            pos_u = unshaped["positions"][:, moved_axis]
            pos_s = shaped["positions"][:, moved_axis]
            vel_u = unshaped["velocities"][:, moved_axis]
            vel_s = shaped["velocities"][:, moved_axis]
            acc_u = unshaped["accelerations"][:, moved_axis]
            acc_s = shaped["accelerations"][:, moved_axis]

        axes[0].plot(time_u, pos_u, color="k", linewidth=2)
        axes[0].plot(time_s, pos_s, linestyle="--", color="r", linewidth=2)
        axes[0].set_ylabel("Position [rad]", fontsize=label_size, fontweight="bold")
        axes[0].set_title("Position", fontsize=title_size)

        axes[1].plot(time_u, vel_u, color="k", linewidth=2)
        axes[1].plot(time_s, vel_s, linestyle="--", color="r", linewidth=2)
        axes[1].set_ylabel("Velocity [rad/s]", fontsize=label_size, fontweight="bold")
        axes[1].set_title("Velocity", fontsize=title_size)

        axes[2].plot(time_u, acc_u, color="k", linewidth=2)
        axes[2].plot(time_s, acc_s, linestyle="--", color="r", linewidth=2)
        axes[2].set_ylabel(
            "Acceleration [rad/s^2]", fontsize=label_size, fontweight="bold"
        )
        axes[2].set_xlabel("Time [s]", fontsize=label_size, fontweight="bold")
        axes[2].set_title("Acceleration", fontsize=title_size)

        axes[0].legend(
            ["Unshaped", "Shaped"], prop={"weight": "bold", "size": legend_size}
        )
        fig.tight_layout()
        VibrationTestPlots.finalize_figure(fig, plot_name)

    @staticmethod
    def plot_mag_acc_residual_and_fft(
        *,
        time_u: np.ndarray,
        time_s: np.ndarray,
        mag_acc_u: np.ndarray,
        mag_acc_s: np.ndarray,
        mag_acc_u_residual_abs: np.ndarray,
        mag_acc_s_residual_abs: np.ndarray,
        sample_time: float,
        pose: int,
        axis: int,
    ) -> None:
        """Plot full-trajectory norm, residual-abs norm, and their FFT comparison.

        Args:
            time_u: Unshaped time vector [s].
            time_s: Shaped time vector [s].
            mag_acc_u: Unshaped acceleration norm [m/s^2].
            mag_acc_s: Shaped acceleration norm [m/s^2].
            mag_acc_u_residual_abs: Absolute residual norm (unshaped) [m/s^2].
            mag_acc_s_residual_abs: Absolute residual norm (shaped) [m/s^2].
            sample_time: Sampling period [s].
            pose: Pose identifier for title/filename.
            axis: Axis identifier for title/filename.
        Returns:
            `None`.
        Side Effects:
            Creates a matplotlib figure and delegates save/show/close behavior.
        Raises:
            ValueError: If `sample_time <= 0` or vectors are malformed.
        Preconditions:
            Time and signal vectors are aligned per trajectory type.
        """
        if sample_time <= 0.0:
            raise ValueError("sample_time must be positive")

        base_font = float(plt.rcParams.get("font.size", 10))
        title_size = base_font + 6
        label_size = base_font + 6
        legend_size = base_font + 3

        def _one_sided_fft(signal: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
            """Compute one-sided FFT magnitude for a scalar signal."""
            n = signal.size
            fft_vals = np.asarray(fft(signal))
            freqs = fftfreq(n, sample_time)
            # `half`: one-sided FFT cutoff index (positive-frequency half-spectrum).
            half = n // 2
            freqs = freqs[:half]
            amps = np.abs(fft_vals[:half]) / float(n)
            if n > 1:
                amps[1:] *= 2.0
            return freqs, amps

        f_u, fft_u = _one_sided_fft(mag_acc_u_residual_abs)
        f_s, fft_s = _one_sided_fft(mag_acc_s_residual_abs)

        fig, axes = plt.subplots(3, 1, sharex=False, figsize=(10, 9))

        axes[0].plot(time_u, mag_acc_u, color="k", linewidth=2, label="Unshaped")
        axes[0].plot(
            time_s, mag_acc_s, color="r", linestyle="--", linewidth=2, label="Shaped"
        )
        axes[0].set_title("Acceleration Norm (Full Trajectory)", fontsize=title_size)
        axes[0].set_ylabel("Norm [m/s^2]", fontsize=label_size, fontweight="bold")
        axes[0].set_xlabel("Time [s]", fontsize=label_size, fontweight="bold")
        axes[0].legend(prop={"weight": "bold", "size": legend_size}, loc="upper right")

        axes[1].plot(
            time_u,
            mag_acc_u_residual_abs,
            color="k",
            linewidth=2,
            label="Unshaped residual abs",
        )
        axes[1].plot(
            time_s,
            mag_acc_s_residual_abs,
            color="r",
            linestyle="--",
            linewidth=2,
            label="Shaped residual abs",
        )
        axes[1].set_title(
            "Acceleration Norm Residual Acceleration (Full Trajectory)",
            fontsize=title_size,
        )
        axes[1].set_ylabel(
            "Residual Abs [m/s^2]", fontsize=label_size, fontweight="bold"
        )
        axes[1].set_xlabel("Time [s]", fontsize=label_size, fontweight="bold")
        axes[1].legend(prop={"weight": "bold", "size": legend_size}, loc="upper right")

        axes[2].plot(
            f_u, fft_u, color="k", linewidth=2, label="FFT unshaped residual abs"
        )
        axes[2].plot(
            f_s,
            fft_s,
            color="r",
            linestyle="--",
            linewidth=2,
            label="FFT shaped residual abs",
        )
        axes[2].set_title(
            "FFT of Residual Acceleration (Full Trajectory)", fontsize=title_size
        )
        axes[2].set_ylabel("FFT Magnitude", fontsize=label_size, fontweight="bold")
        axes[2].set_xlabel("Frequency [Hz]", fontsize=label_size, fontweight="bold")
        axes[2].legend(prop={"weight": "bold", "size": legend_size}, loc="upper right")

        fig.tight_layout()
        VibrationTestPlots.finalize_figure(
            fig, f"mag_acc_residual_fft_pose_{pose}_axis_{axis}"
        )

    @staticmethod
    def plot_residual_vibration(
        time_unshaped: np.ndarray,
        time_shaped: np.ndarray,
        mag_unshaped: np.ndarray,
        mag_shaped: np.ndarray,
        idx_vib_unshaped: int,
        idx_vib_shaped: int,
        peak_idx_unshaped: int,
        peak_idx_shaped: int,
        sample_time: float,
        pose: int,
        duration_diff_s: float,
        window_sec: float = 0.2,
        tol_rel: float = 0.4,
        min_duration_sec: float = 0.125,
        consecutive_windows: int = 2,
    ) -> tuple[float | None, float | None, int | None]:
        """Plot residual vibration metrics and return key detected timestamps.

        Args:
            time_unshaped: Unshaped time samples [s], shape `(N_u,)`.
            time_shaped: Shaped time samples [s], shape `(N_s,)`.
            mag_unshaped: Unshaped acceleration norm [m/s^2], shape `(N_u,)`.
            mag_shaped: Shaped acceleration norm [m/s^2], shape `(N_s,)`.
            idx_vib_unshaped: Start index of unshaped residual-vibration window.
            idx_vib_shaped: Start index of shaped residual-vibration window.
            peak_idx_unshaped: Peak index offset within unshaped residual window.
            peak_idx_shaped: Peak index offset within shaped residual window.
            sample_time: Sample period used for moving-window metrics [s].
            pose: Pose identifier used in title/filename.
            duration_diff_s: Shaped minus unshaped trajectory duration [s].
            window_sec: Moving-window length for RMS/average operations [s].
            tol_rel: Affects blue vertical line placement - Relative tolerance
            for RMS coincidence detection [0..1].
            min_duration_sec: Minimum stable coincidence duration [s].
            consecutive_windows:Affects pink vertical line placement- Number of
            consecutive windows required for the unshaped moving average to stay
            below the shaped initial-window average. This determns the tiem where the
            amplitude match (pink vertical line).
        Returns:
            `tuple[float | None, float | None, int | None]`:
            (absolute coincidence time [s] or None,
            absolute initial-average reach time [s] or None,
            residual-window index of the blue coincidence line or None).
        Side Effects:
            Creates a matplotlib figure and delegates save/show/close behavior.
        Raises:
            IndexError: If any provided index is outside the corresponding vector.
            ValueError: If window sizes or vector shapes are invalid.
        Preconditions:
            Input vectors are time-aligned within each trajectory.
            `sample_time > 0`.
            Residual-window and peak indices are valid.
        """
        fig, ax = plt.subplots(1, 1)
        ax.plot(
            time_unshaped[idx_vib_unshaped:] - time_unshaped[idx_vib_unshaped],
            mag_unshaped[idx_vib_unshaped:],
            color="k",
            linewidth=2,
            label="Unshaped",
        )
        ax.plot(
            time_shaped[idx_vib_shaped:] - time_shaped[idx_vib_shaped],
            mag_shaped[idx_vib_shaped:],
            color="r",
            linestyle="--",
            linewidth=2,
            label="Shaped",
        )

        # Build moving RMS envelopes and detect earliest stable coincidence region.
        # `window_n`: samples per moving RMS window.
        # `window_n`: samples per moving RMS window.
        window_n = max(1, int(round(window_sec / sample_time)))
        # `min_len`: minimum consecutive samples required for coincidence acceptance.
        min_len = max(1, int(round(min_duration_sec / sample_time)))

        rms_unshaped = np.sqrt(
            np.convolve(
                mag_unshaped[idx_vib_unshaped:] ** 2,
                np.ones(window_n) / window_n,
                mode="same",
            )
        )
        rms_shaped = np.sqrt(
            np.convolve(
                mag_shaped[idx_vib_shaped:] ** 2,
                np.ones(window_n) / window_n,
                mode="same",
            )
        )
        common_len = min(rms_unshaped.size, rms_shaped.size)
        rms_unshaped = rms_unshaped[:common_len]
        rms_shaped = rms_shaped[:common_len]
        rms_diff = np.abs(rms_unshaped - rms_shaped)
        rms_ref = np.maximum(rms_unshaped, rms_shaped)
        coincidence_mask = rms_diff <= (tol_rel * rms_ref)

        # `coincide_idx`: index inside residual window where blue-line coincidence starts.
        coincide_idx = None
        coincide_time = None
        coincide_time_abs = None
        # Each iteration tests whether a contiguous run satisfies coincidence criteria.
        if np.any(coincidence_mask):
            for i in range(coincidence_mask.size - min_len + 1):
                if np.all(coincidence_mask[i : i + min_len]):
                    coincide_idx = i
                    break
        y_min = float(
            np.min(
                np.concatenate(
                    [
                        mag_unshaped[idx_vib_unshaped:],
                        mag_shaped[idx_vib_shaped:],
                    ]
                )
            )
        )
        y_max = float(
            np.max(
                np.concatenate(
                    [
                        mag_unshaped[idx_vib_unshaped:],
                        mag_shaped[idx_vib_shaped:],
                    ]
                )
            )
        )

        if coincide_idx is not None:
            coincide_time_abs = time_unshaped[idx_vib_unshaped + coincide_idx]
            coincide_time = coincide_time_abs - time_unshaped[idx_vib_unshaped]
            ax.axvline(x=coincide_time, color="b", linestyle=":", linewidth=2)
            y_mid = 0.25 * (y_min + y_max)
            ax.annotate(
                f"  Amplitude coincide \n  at t = {coincide_time:.2f} [s]",
                xy=(coincide_time, y_mid),
                xytext=(0, 0),
                textcoords="offset points",
                color="b",
                fontsize=plt.rcParams.get("font.size", 10) + 3,
            )

        # Annotate when unshaped average reaches shaped initial-window amplitude.
        shaped_peak_value = mag_shaped[idx_vib_shaped + peak_idx_shaped]
        unshaped_residual = mag_unshaped[idx_vib_unshaped:]
        shaped_residual = mag_shaped[idx_vib_shaped:]
        unshaped_ma = np.convolve(
            unshaped_residual,
            np.ones(window_n) / window_n,
            mode="same",
        )
        shaped_window_avg = float(np.mean(shaped_residual[:window_n]))
        reach_mask = unshaped_ma <= shaped_window_avg
        # `start_idx`: first index where pink-line threshold condition is sustained.
        start_idx = 0
        # Each iteration checks for the first stable threshold-reaching segment.
        if np.any(reach_mask):
            window_req = max(1, int(consecutive_windows))
            for i in range(reach_mask.size - window_req + 1):
                if np.all(reach_mask[i : i + window_req]):
                    start_idx = i
                    break
        # `closest_idx`: closest unshaped sample (after `start_idx`) to shaped peak level.
        closest_idx = start_idx + int(
            np.argmin(np.abs(unshaped_residual[start_idx:] - shaped_peak_value))
        )
        closest_time_abs = time_unshaped[idx_vib_unshaped + closest_idx]
        closest_time = closest_time_abs - time_unshaped[idx_vib_unshaped]
        y_mid = 0.5 * (y_min + y_max)
        should_plot_pink = coincide_idx is None or closest_time <= coincide_time
        if should_plot_pink:
            ax.axvline(x=closest_time, color="deeppink", linestyle="-.", linewidth=2)
            ax.annotate(
                f"  Initial Avg. acceleration \n  reached at t = {closest_time:.2f} [s]",
                xy=(closest_time, y_mid),
                xytext=(0, 0),
                textcoords="offset points",
                color="deeppink",
                fontsize=plt.rcParams.get("font.size", 10) + 3,
            )
            ax.scatter(
                [closest_time],
                [unshaped_residual[closest_idx]],
                s=120,
                c="deeppink",
                zorder=5,
            )

        ax.scatter(
            [
                time_unshaped[idx_vib_unshaped + peak_idx_unshaped]
                - time_unshaped[idx_vib_unshaped],
                time_shaped[idx_vib_shaped + peak_idx_shaped]
                - time_shaped[idx_vib_shaped],
            ],
            [
                mag_unshaped[idx_vib_unshaped + peak_idx_unshaped],
                mag_shaped[idx_vib_shaped + peak_idx_shaped],
            ],
            s=120,
            c="green",
            zorder=5,
            label="Max acceleration peak",
        )
        base_font = float(plt.rcParams.get("font.size", 10))
        title_size = base_font + 6
        label_size = base_font + 6
        legend_size = base_font + 3

        ax.set_title(
            f"Residual Vibration at Configuration {pose}\n "
            f"(Added delay ΔT = {duration_diff_s:.2f} [s])",
            fontsize=title_size,
        )
        if coincide_idx is not None:
            ax.legend(prop={"weight": "bold", "size": legend_size})
        else:
            ax.legend(
                ["Unshaped", "Shaped", "Max acceleration peak"],
                prop={"weight": "bold", "size": legend_size},
            )
        ax.set_xlabel("Time [s]", fontsize=label_size, fontweight="bold")
        ax.set_ylabel(
            "Acceleration Norm [m/s^2]", fontsize=label_size, fontweight="bold"
        )
        ax.set_xlim(0.0, DWELL_TIME * 0.75)
        fig.tight_layout()
        VibrationTestPlots.finalize_figure(fig, f"residual_vibration_pose_{pose}")
        return (
            coincide_time_abs,
            (closest_time_abs if should_plot_pink else None),
            (int(coincide_idx) if coincide_idx is not None else None),
        )


vibration_test_plots = VibrationTestPlots()


def get_pose_pairs(
    local_data_location: str, max_disp: float
) -> list[tuple[int, int, list[float], list[float]]]:
    """Select random pose/axis pairs and build target configurations.

    Args:
        local_data_location: Folder containing calibration data CSVs.
        max_disp: Displacement to apply on the commanded axis [rad].

    Returns:
        `list[tuple[int, int, list[float], list[float]]]` of
        (pose, axis, config2, config1) tuples.

    Side Effects:
        Reads calibration files from disk.

    Raises:
        FileNotFoundError: If required CSV files are missing.

    Preconditions:
        `local_data_location` contains identification parameters and motion files.
    """
    # Find out how many poses and axes there are in the folder by reading the "identification_parameters.csv file"
    calibration_params = read_identification_parameters(data_folder=local_data_location)
    num_poses = calibration_params.nV * calibration_params.nR
    num_axes = calibration_params.axes
    num_joints = calibration_params.num_joints

    # Select and extract [num_axes * AXIS_REPETITIONS] poses to test randomly from the CSVs
    # Each axis will get tested ${AXIS_REPETITION} times.
    pose_pair_list = []
    for i in range(num_axes * AXIS_REPETITIONS):
        pose_i = random.randint(0, num_poses - 1)
        axis_i = int(i % num_axes)
        file_i = f"{local_data_location}/robotData_motion_pose{pose_i}_axis{axis_i}.csv"
        # (TODO: how to bias towards outstretched poses?)

        # Get the initial position of the file
        _, cmd_joints, *_ = extract_dynamic_variables(
            dynamic_file=file_i, num_joints=num_joints
        )

        # Create and store a tuple pair that changes the commanded axes by [max_disp] radians
        # TODO: How do we know config2 is able to be reached?
        config1_i = copy.copy(cmd_joints[0, :])
        config2_i = copy.copy(cmd_joints[0, :])
        config2_i[axis_i] += max_disp

        pose_pair_list.append((pose_i, axis_i, list(config2_i), list(config1_i)))

    # return that list of pair
    return pose_pair_list


def plan_point_to_point_unshaped(
    start_angles: list[float],
    goal_angles: list[float],
    *,
    sample_time: float = 1 / DEFAULT_ROBOT_FREQ,
    dwell: float = DWELL_TIME,
    max_velocity: float = DEFAULT_MAX_VEL,
    max_acceleration: float = DEFAULT_MAX_ACC,
) -> Mapping[str, np.ndarray]:
    """Generate the raw point-to-point trajectory without shaping.

    Args:
        start_angles: Starting joint angles.
        goal_angles: Goal joint angles.
        sample_time: Sampling time [s].
        dwell: Dwell time after motion [s].
        max_velocity: Maximum joint velocity [rad/s].
        max_acceleration: Maximum joint acceleration [rad/s^2].

    Returns:
        `Mapping[str, np.ndarray]` with keys `positions`, `velocities`,
        `accelerations`, and `time`.

    Side Effects:
        None.

    Raises:
        None.

    Preconditions:
        `start_angles` and `goal_angles` have the same length.
    """

    displacement = np.max(np.abs(np.array(goal_angles) - np.array(start_angles)))
    t_params = TrajParams(
        max_displacement=float(displacement),
        max_velocity=float(max_velocity),
        max_acceleration=float(max_acceleration),
    )
    s_params = SystemIdParams(nV=1, nR=1)

    # Generate per-axis trajectories using the Python trajectory generator
    trajectory_gen = Trajectory(t_params=t_params, s_params=s_params)
    joint_trajectories = []
    joint_velocities = []
    joint_accelerations = []
    time_vectors = []

    for start_val, goal_val in zip(start_angles, goal_angles):
        # Store directionality, compute point-to-point on the displacement,
        # then add directionality back in after
        direction = np.sign(goal_val - start_val) or 1.0
        displacement_axis = abs(goal_val - start_val)

        qj: np.ndarray
        qj_dot: np.ndarray
        qj_ddot: np.ndarray
        tj: np.ndarray

        if displacement_axis <= 1e-9:
            # Degenerate move: stay at start position.
            qj = np.asarray([start_val])
            tj = np.asarray([0.0])
            qj_dot = np.zeros_like(qj)
            qj_ddot = np.zeros_like(qj)
        else:
            qj, qj_dot, qj_ddot, tj = trajectory_gen.point_to_point_motion(
                feedrate=max_velocity,
                acc_limit=max_acceleration,
                dec_limit=-1 * max_acceleration,
                displacement=displacement_axis,
                Ts=sample_time,
                dwell=dwell,
            )
            qj = start_val + direction * qj
            qj_dot = np.gradient(qj, sample_time)
            qj_ddot = np.gradient(qj_dot, sample_time)

        joint_trajectories.append(qj)
        joint_velocities.append(qj_dot)
        joint_accelerations.append(qj_ddot)
        time_vectors.append(tj)

    max_samples = max(len(q) for q in joint_trajectories)
    common_time = np.linspace(0.0, (max_samples - 1) * sample_time, max_samples)

    def _resample(series_list: list[np.ndarray]) -> np.ndarray:
        """Resample per-axis series onto a common time base.

        Args:
            series_list: One series per joint axis.
        Returns:
            `np.ndarray` stacked as `(N, num_axes)` on `common_time`.
        Side Effects:
            None.
        Raises:
            ValueError: If `series_list` length mismatches `time_vectors`.
        Preconditions:
            Each series aligns with its corresponding entry in `time_vectors`.
        """
        if len(series_list) != len(time_vectors):
            raise ValueError("series_list and time_vectors must have matching length")
        resampled = []
        for arr, t_vec in zip(series_list, time_vectors):
            if len(arr) == max_samples:
                resampled.append(arr)
            else:
                resampled.append(np.interp(common_time, t_vec, arr))
        return np.stack(resampled, axis=1)

    positions = _resample(joint_trajectories)
    velocities = _resample(joint_velocities)
    accelerations = _resample(joint_accelerations)

    return {
        "positions": positions,
        "velocities": velocities,
        "accelerations": accelerations,
        "time": common_time,
    }


def shape_stream(
    shaper: Any,
    commands: np.ndarray,
    times: np.ndarray,
) -> tuple[list, list, list]:
    """Shape a command stream sample-by-sample.

    Args:
        shaper: Shaper instance.
        commands: Commanded joint angles over time.
        times: Time vector aligned with `commands`.

    Returns:
        `tuple[list, list, list]` of (positions, velocities, accelerations).

    Side Effects:
        Advances the shaper state.

    Raises:
        None.

    Preconditions:
        `commands` and `times` have matching length.
    """
    positions = []
    velocities = []
    accelerations = []
    last_time = times[0] if len(times) else 0.0

    for i, cmd in enumerate(commands):
        state = covalent.RobotState()
        state.joint_angles = cmd
        sample = shaper.shape_sample(cmd, state)
        positions.append((times[i], sample.positions))
        velocities.append((times[i], sample.velocities))
        accelerations.append((times[i], sample.accelerations))
        last_time = times[i]

    for tail_idx, tail in enumerate(shaper.finalize()):
        t = last_time + (tail_idx + 1) * shaper.sample_time
        positions.append((t, tail.positions))
        velocities.append((t, tail.velocities))
        accelerations.append((t, tail.accelerations))
    return positions, velocities, accelerations


def shape_batch(
    commands: np.ndarray,
    times: np.ndarray,
    shaper: Any,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Shape a full trajectory in batch mode.

    Args:
        commands: Commanded joint angles over time.
        times: Time vector aligned with `commands`.
        shaper: Shaper instance.

    Returns:
        `tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]` containing time,
        positions, velocities, and accelerations.

    Side Effects:
        None.

    Raises:
        None.

    Preconditions:
        `commands` and `times` have matching length.
    """

    states = []
    for cmd in commands:
        st = covalent.RobotState()
        st.joint_angles = cmd
        states.append(st)
    traj = shaper.shape_trajectory(commands, states, time_vector=list(times))
    return traj.time, traj.positions, traj.velocities, traj.accelerations


def shape_point_to_point_trajectory(
    robot_interface: RobotInterface,
    unshaped_trajectory: Mapping[str, np.ndarray],
    sample_time: float,
    axes_to_shape: int,
    side_length: float,
    initial_height: float,
) -> Mapping[str, np.ndarray]:
    """Compute a shaped trajectory for a point-to-point move.

    Args:
        robot_interface: Robot interface used for kinematics.
        unshaped_trajectory: Raw trajectory mapping.
        sample_time: Sampling time [s].
        axes_to_shape: Number of axes to shape.
        side_length: Side arm length [m].
        initial_height: Initial height [m].

    Returns:
        `Mapping[str, np.ndarray]` containing shaped trajectory fields.

    Side Effects:
        None.

    Raises:
        None.

    Preconditions:
        `unshaped_trajectory` contains required keys.
    """
    shaped_positions = np.zeros_like(unshaped_trajectory["positions"])
    shaped_velocities = np.zeros_like(unshaped_trajectory["velocities"])
    shaped_accelerations = np.zeros_like(unshaped_trajectory["positions"])

    shaper_ = covalent.ShaperInterface(
        sample_time=sample_time,
        model_directory=str(MODEL_DIR),
        python_src_root=str(PYTHON_SRC_ROOT),
        urdf_filepath=robot_interface.urdf_path,
        side_length=side_length,
        base_height=initial_height,
        num_axes=axes_to_shape,
        num_joints=robot_interface.num_joints,
    )

    time, shaped_positions, shaped_velocities, shaped_accelerations = shape_batch(
        commands=unshaped_trajectory["positions"],
        times=unshaped_trajectory["time"],
        shaper=shaper_,
    )

    return {
        "positions": shaped_positions,
        "velocities": shaped_velocities,
        "accelerations": shaped_accelerations,
        "time": time,
    }


class CompareResult(TypedDict):
    shaped_duration: float
    unshaped_duration: float
    shaped_log: Deque[dict]
    unshaped_log: Deque[dict]
    shaped_trajectory: Mapping[str, np.ndarray]
    unshaped_trajectory: Mapping[str, np.ndarray]


def generate_stream_shaped_unshaped_trajecotry(
    robot_interface: RobotInterface,
    start_angles: list[float],
    goal_angles: list[float],
    identification_file: str,
    moved_axis: int | None = None,
    *,
    sample_time: float = 1 / DEFAULT_ROBOT_FREQ,
    dwell: float = DWELL_TIME,
    max_velocity: float = DEFAULT_MAX_VEL,
    max_acceleration: float = DEFAULT_MAX_ACC,
) -> CompareResult:
    """Compare shaped and unshaped point-to-point trajectories for a move.

    Args:
        robot_interface: Robot interface for kinematics.
        start_angles: Starting joint angles.
        goal_angles: Goal joint angles.
        identification_file: Folder with identification parameters.
        moved_axis: Joint axis index used for the move; if provided, only that
                    joint is plotted for shaped vs unshaped profiles.
        sample_time: Sampling time [s].
        dwell: Dwell time after motion [s].
        max_velocity: Maximum joint velocity [rad/s].
        max_acceleration: Maximum joint acceleration [rad/s^2].
    Returns:
        `CompareResult` containing comparison metrics and streamed logs.

    Side Effects:
        Reads calibration parameters and prints status.

    Raises:
        ValueError: If start/goal angles do not match joint count.

    Preconditions:
        `identification_file` contains identification parameters.
    """

    if (
        len(start_angles) != robot_interface.num_joints
        or len(goal_angles) != robot_interface.num_joints
    ):
        raise ValueError(
            f"Expected {robot_interface.num_joints} joint values for start and goal"
        )

    calibration_params = read_identification_parameters(data_folder=identification_file)
    unshaped = plan_point_to_point_unshaped(
        start_angles=start_angles,
        goal_angles=goal_angles,
        sample_time=sample_time,
        dwell=dwell,
        max_velocity=max_velocity,
        max_acceleration=max_acceleration,
    )
    print("Completed unshaped trajectory. Building shaped trajectory.")
    shaped = shape_point_to_point_trajectory(
        robot_interface=robot_interface,
        unshaped_trajectory=unshaped,
        sample_time=sample_time,
        axes_to_shape=calibration_params.axes,
        side_length=calibration_params.shoulder_len,
        initial_height=calibration_params.base_height,
    )

    unshaped_payload = {
        "time": unshaped["time"].tolist(),
        "positions": unshaped["positions"].tolist(),
        "velocities": unshaped["velocities"].tolist(),
        "accelerations": unshaped["accelerations"].tolist(),
        "Ts": _derive_ts(unshaped["time"], sample_time),
    }
    shaped_payload = {
        "time": shaped["time"].tolist(),
        "positions": shaped["positions"].tolist(),
        "velocities": shaped["velocities"].tolist(),
        "accelerations": shaped["accelerations"].tolist(),
        "Ts": _derive_ts(shaped["time"], sample_time),
    }

    # Implementation note (Codex): print commanded span so "published but no
    # motion" cases can be diagnosed quickly from the terminal output.
    commanded_delta = np.array(goal_angles) - np.array(start_angles)
    print(
        "[StandardRobot] Commanded joint delta [rad]: "
        + np.array2string(commanded_delta, precision=4)
    )

    shaped_log: Deque[dict] = deque()
    unshaped_log: Deque[dict] = deque()

    # Here is when the robot is commanded to move

    if not robot_interface.in_sim_mode and hasattr(robot_interface, "robot"):
        start_tuple = tuple(start_angles)
        print("[StandardRobot] Moving to start configuration before comparison run...")
        robot_interface.move_to_joint(target_joint=start_tuple)

        if unshaped_payload["positions"]:
            print("[StandardRobot] Streaming unshaped trajectory...")
            unshaped_log = robot_interface.publish_and_record_joint_positions(
                time_data=unshaped_payload["time"],
                position_stream=unshaped_payload["positions"],
                velocity_stream=unshaped_payload["velocities"],
                acceleration_stream=unshaped_payload["accelerations"],
                Ts=unshaped_payload["Ts"],
            )

        print("[StandardRobot] Returning to start angles before shaped trajectory...")
        robot_interface.move_to_joint(target_joint=start_tuple)
        # Wait after motion to send next command
        time.sleep(dwell)

        if shaped_payload["positions"]:
            print("[StandardRobot] Streaming shaped trajectory...")
            shaped_log = robot_interface.publish_and_record_joint_positions(
                time_data=shaped_payload["time"],
                position_stream=shaped_payload["positions"],
                velocity_stream=shaped_payload["velocities"],
                acceleration_stream=shaped_payload["accelerations"],
                Ts=shaped_payload["Ts"],
            )

    # TO-DO: Store information about trajectories that will help us compute the results
    # ex: time when the trajectory ends and the dwell begins, etc.
    return {
        "shaped_duration": float(shaped["time"][-1]),
        "unshaped_duration": float(unshaped["time"][-1]),
        "shaped_log": shaped_log,
        "unshaped_log": unshaped_log,
        "shaped_trajectory": shaped,
        "unshaped_trajectory": unshaped,
    }


def _derive_ts(time_vector: np.ndarray, fallback: float) -> float:
    """Estimate a sampling period from a time vector.

    Args:
        time_vector: Time stamps array.
        fallback: Fallback sampling time [s] if estimation fails.

    Returns:
        `float` estimated sampling time [s].

    Side Effects:
        None.

    Raises:
        None.

    Preconditions:
        `time_vector` is sorted and in seconds.
    """
    if time_vector.size > 1:
        deltas = np.diff(time_vector)
        mean_dt = (
            float(np.mean(deltas[deltas > 0]))
            if np.any(deltas > 0)
            else float(fallback)
        )
        if mean_dt > 0.0:
            return mean_dt
    return float(fallback)


def _build_uniform_time(num_points: int, sample_time: float) -> np.ndarray:
    """Build a synthetic uniform time vector from sample count and fixed period.

    Summary of recent modifications:
        Analysis and plotting now ignore CSV timestamps and use a deterministic time
        base derived from `DEFAULT_ROBOT_FREQ`. This keeps comparisons stable even
        when runtime publish timing jitters.

    Args:
        num_points: Number of samples in the analyzed signal.
        sample_time: Fixed sample period [s].

    Returns:
        `np.ndarray` time vector with shape `(num_points,)`, defined as
        `[0, Ts, 2*Ts, ...]` [s].

    Side Effects:
        None.

    Raises:
        None.

    Preconditions:
        `num_points >= 0` and `sample_time > 0`.
    """
    if num_points <= 0:
        return np.zeros(0, dtype=float)
    return np.arange(num_points, dtype=float) * float(sample_time)


def moving_average_signal(
    signal: np.ndarray, window_sec: float, sample_time: float
) -> np.ndarray:
    """Compute moving average for a 1D or 2D signal.

    Args:
        signal: Signal samples with shape `(N,)` or `(N, M)`.
        window_sec: Moving-average window duration [s].
        sample_time: Signal sampling period [s].
    Returns:
        `np.ndarray` moving-average signal with the same shape as `signal`.
    Side Effects:
        None.
    Raises:
        ValueError: If `sample_time <= 0` or `signal` is not 1D/2D.
    Preconditions:
        Signal samples are time ordered.
    """
    if sample_time <= 0.0:
        raise ValueError("sample_time must be positive")

    signal_array = np.asarray(signal)
    if signal_array.ndim not in (1, 2):
        raise ValueError("signal must be 1D or 2D")

    # `window_n`: moving-average kernel length in samples.
    window_n = max(1, int(round(window_sec / sample_time)))
    # Keep kernel length <= signal length so `mode="same"` preserves input length.
    max_window = signal_array.shape[0]
    window_n = min(window_n, max_window) if max_window > 0 else 1
    kernel = np.ones(window_n, dtype=float) / float(window_n)

    # For 2D signals, each iteration smooths one axis/column independently.
    if signal_array.ndim == 2:
        return np.vstack(
            [
                np.convolve(signal_array[:, i], kernel, mode="same")
                for i in range(signal_array.shape[1])
            ]
        ).T
    return np.convolve(signal_array, kernel, mode="same")


def vibration_metric_using_variance(
    mag_acc_u: np.ndarray,
    mag_acc_s: np.ndarray,
    sample_time: float,
    moving_avg_window_sec: float = MOVING_AVG_WINDOW_SEC,
) -> float:
    """Compute vibration reduction metric using variance around moving average.

    Args:
        mag_acc_u: Unshaped acceleration norm [m/s^2].
        mag_acc_s: Shaped acceleration norm [m/s^2].
        sample_time: Sampling period [s].
        moving_avg_window_sec: Moving-average window duration [s].
    Returns:
        `float` percent reduction based on variance of residuals.
    Side Effects:
        None.
    Raises:
        ValueError: If inputs are empty or `sample_time <= 0`.
    Preconditions:
        Signals are time-aligned and represent the same window definition.
    """
    if sample_time <= 0.0:
        raise ValueError("sample_time must be positive")
    if mag_acc_u.size == 0 or mag_acc_s.size == 0:
        raise ValueError("signals must be non-empty")

    mag_acc_u_moving_avg = moving_average_signal(
        signal=mag_acc_u,
        window_sec=moving_avg_window_sec,
        sample_time=sample_time,
    )
    mag_acc_s_moving_avg = moving_average_signal(
        signal=mag_acc_s,
        window_sec=moving_avg_window_sec,
        sample_time=sample_time,
    )
    mag_acc_u_residual = mag_acc_u - mag_acc_u_moving_avg
    mag_acc_s_residual = mag_acc_s - mag_acc_s_moving_avg

    var_u = float(np.var(mag_acc_u_residual))
    var_s = float(np.var(mag_acc_s_residual))
    if var_u <= 0.0:
        return 0.0
    return 100.0 * (var_u - var_s) / var_u


def store_vibration_test_data(
    robot_interface: RobotInterface,
    data_log: Deque[dict],
    pose_number: int,
    axis_number: int,
    label: str,
) -> None:
    """Persist vibration test data to disk.

    Args:
        robot_interface: Robot interface with recorder state.
        data_log: Recorded data log.
        pose_number: Pose index for file naming.
        axis_number: Axis index for file naming.
        label: Subfolder label (e.g., `shaped`, `unshaped`).

    Returns:
        `None`.

    Side Effects:
        Writes CSV files to disk.

    Raises:
        OSError: If files cannot be written.

    Preconditions:
        `robot_interface` is connected and `data_log` is populated.
    """
    robot_interface.recorder.reset()

    while data_log:
        log_entry = data_log.popleft()
        robot_interface.process_motion_data(entry=log_entry)

    vibration_data_folder = f"{VIBRATION_DATA_FOLDER}/{label}"
    store_recorder_data_in_data_folder(
        recorder=robot_interface.recorder,
        run_index=pose_number,
        move_axis=axis_number,
        data_folder=vibration_data_folder,
    )


def run_vibration_test(
    robot_interface: RobotInterface,
    local_data_location: str,
    Ts: float,
    max_disp: float = DEFAULT_MAX_DISP,
) -> None:
    """Run vibration tests and store shaped/unshaped results.

    Args:
        robot_interface: Robot interface used to execute trajectories.
        local_data_location: Folder containing calibration data.
        Ts: Sampling time [s].
        max_disp: Maximum displacement [rad].
        plotting: Whether to plot comparisons.

    Returns:
        `None`.

    Side Effects:
        Commands robot motion and writes test data to disk.

    Raises:
        RuntimeError: If robot motion fails.

    Preconditions:
        Robot connection is active and calibration data exists.
    """

    # Get the random poses that we want to test from the data folder location
    # Compute their pair location based on the axis that was moved in the system ID
    pose_pairs = get_pose_pairs(
        local_data_location=local_data_location, max_disp=max_disp
    )

    pose_axis_pairs: list[tuple[int, int]] = []

    # Loop 1: execute all experiments and store shaped/unshaped CSV files.
    for _, (pose, axis, start, end) in enumerate(pose_pairs):
        response = generate_stream_shaped_unshaped_trajecotry(
            robot_interface=robot_interface,
            start_angles=start,
            goal_angles=end,
            identification_file=local_data_location,
            moved_axis=axis,
            sample_time=Ts,
        )

        store_vibration_test_data(
            robot_interface=robot_interface,
            data_log=response["unshaped_log"],
            pose_number=pose,
            axis_number=axis,
            label="unshaped",
        )
        store_vibration_test_data(
            robot_interface=robot_interface,
            data_log=response["shaped_log"],
            pose_number=pose,
            axis_number=axis,
            label="shaped",
        )
        pose_axis_pairs.append((pose, axis))

    def rotate_and_compensate_acc(
        time_vec: np.ndarray, encoder: np.ndarray, tcp_acc: np.ndarray
    ) -> tuple[np.ndarray, float, np.ndarray]:
        """Rotate tool-frame acceleration to base frame and remove static bias.

        Args:
            time_vec: Sample timestamps [s], shape `(N,)`.
            encoder: Joint-angle samples [rad], shape `(N, num_joints)`.
            tcp_acc: Tool-frame acceleration samples [m/s^2], shape `(N, 3)`.
        Returns:
            `tuple[np.ndarray, float, np.ndarray]`:
            (bias-compensated base-frame acceleration [m/s^2], shape `(N, 3)`,
            estimated gravity component in base Z [m/s^2],
            estimated XYZ bias vector in base frame [m/s^2], shape `(3,)`).
        Side Effects:
            None.
        Raises:
            ValueError: If input arrays are empty or shape-incompatible.
            RuntimeError: If forward-kinematics transformation cannot be computed.
        Preconditions:
            `time_vec`, `encoder`, and `tcp_acc` are time-aligned with equal `N`.
            `tcp_acc` has 3 columns representing tool-frame XYZ acceleration.
        """
        acc_base = np.zeros_like(tcp_acc)
        # Each iteration rotates one tool-frame sample into the base frame.
        for i in range(tcp_acc.shape[0]):
            T_tool = robot_interface.model.get_transformation_matrix(encoder[i, :])
            R_base_tool = T_tool[:3, :3]
            acc_base[i, :] = R_base_tool @ tcp_acc[i, :]

        # Estimate static bias from the last second, where motion should be settled.
        last_start = time_vec[-1] - 1.0
        last_mask = time_vec >= last_start
        if not np.any(last_mask):
            # Fallback when timestamps are degenerate: use last ~1 s by sample count.
            last_n = max(1, int(round(1.0 / Ts)))
            last_mask = np.arange(tcp_acc.shape[0]) >= tcp_acc.shape[0] - last_n
        bias_xyz = np.mean(acc_base[last_mask, :], axis=0)
        gravity_z = bias_xyz[2]
        # Remove estimated static offset (including gravity in base Z).
        acc_base = acc_base - bias_xyz
        return acc_base, gravity_z, bias_xyz

    def _one_sided_fft(
        signal: np.ndarray, sample_time: float
    ) -> tuple[np.ndarray, np.ndarray]:
        """Compute one-sided FFT magnitude with amplitude normalization."""
        n = signal.size
        fft_vals = np.asarray(fft(signal))
        freqs = fftfreq(n, sample_time)
        # `half`: one-sided FFT cutoff index for positive frequencies.
        half = n // 2
        freqs = freqs[:half]
        amps = np.abs(fft_vals[:half]) / float(n)
        if n > 1:
            amps[1:] *= 2.0
        return freqs, amps

    # Loop 2: read saved CSV files and generate all analysis/plots.
    for pose, axis in pose_axis_pairs:
        motion_shaped = (
            f"{VIBRATION_DATA_FOLDER}/shaped/robotData_motion_pose{pose}_axis{axis}.csv"
        )
        motion_unshaped = f"{VIBRATION_DATA_FOLDER}/unshaped/robotData_motion_pose{pose}_axis{axis}.csv"

        # Shaped run signals loaded from CSV:
        # time_s: timeline [s]
        # cmd_s: commanded joint positions [rad]
        # encoder_s: measured joint positions [rad]
        # currents_s: motor current samples
        # acc_t_s: accelerometer timeline [s]
        # tcp_acc_s: TCP/tool-frame linear acceleration [m/s^2]
        # gyro_s: TCP/tool-frame angular velocity [rad/s]
        # quat_t_s: quaternion timeline [s]
        # quat_s: TCP orientation quaternion [w, x, y, z]
        (
            time_s,
            cmd_s,
            encoder_s,
            currents_s,
            acc_t_s,
            tcp_acc_s,
            gyro_s,
            quat_t_s,
            quat_s,
        ) = extract_dynamic_variables(
            dynamic_file=motion_shaped, num_joints=robot_interface.num_joints
        )

        # Unshaped run signals loaded from CSV (same meaning as shaped variables above).
        (
            time_u,
            cmd_u,
            encoder_u,
            currents_u,
            acc_t_u,
            tcp_acc_u,
            gyro_u,
            quat_t_u,
            quat_u,
        ) = extract_dynamic_variables(
            dynamic_file=motion_unshaped, num_joints=robot_interface.num_joints
        )

        # Uniform analysis sample period [s] used to remove host timestamp jitter.
        analysis_Ts = 1.0 / float(DEFAULT_ROBOT_FREQ)
        time_s = _build_uniform_time(time_s.shape[0], analysis_Ts)
        time_u = _build_uniform_time(time_u.shape[0], analysis_Ts)
        acc_t_s = _build_uniform_time(acc_t_s.shape[0], analysis_Ts)
        acc_t_u = _build_uniform_time(acc_t_u.shape[0], analysis_Ts)
        quat_t_s = _build_uniform_time(quat_t_s.shape[0], analysis_Ts)
        quat_t_u = _build_uniform_time(quat_t_u.shape[0], analysis_Ts)

        # Plot 1: trajectory comparison from saved command streams.
        run_vibration_test_plot_trajectory_compare = True
        if run_vibration_test_plot_trajectory_compare:
            vel_u = np.gradient(cmd_u, analysis_Ts, axis=0)
            vel_s = np.gradient(cmd_s, analysis_Ts, axis=0)
            acc_u = np.gradient(vel_u, analysis_Ts, axis=0)
            acc_s = np.gradient(vel_s, analysis_Ts, axis=0)
            vibration_test_plots.plot_shaped_vs_unshaped_trajectory(
                unshaped={
                    "time": time_u,
                    "positions": cmd_u,
                    "velocities": vel_u,
                    "accelerations": acc_u,
                },
                shaped={
                    "time": time_s,
                    "positions": cmd_s,
                    "velocities": vel_s,
                    "accelerations": acc_s,
                },
                moved_axis=axis,
                plot_name=f"trajectory_compare_pose_{pose}_axis_{axis}",
            )

        tcp_acc_s, _, _ = rotate_and_compensate_acc(
            time_vec=time_s, encoder=encoder_s, tcp_acc=tcp_acc_s
        )
        tcp_acc_u, _, _ = rotate_and_compensate_acc(
            time_vec=time_u, encoder=encoder_u, tcp_acc=tcp_acc_u
        )

        # Residual-extraction variables:
        # ma_u/ma_s: moving averages of base-frame acceleration [m/s^2]
        # residual_acc_full_u/residual_acc_full_s: full-trajectory residual
        # acceleration (signal - moving average) [m/s^2]
        ma_u = moving_average_signal(
            signal=tcp_acc_u,
            window_sec=MOVING_AVG_WINDOW_SEC,
            sample_time=Ts,
        )
        ma_s = moving_average_signal(
            signal=tcp_acc_s,
            window_sec=MOVING_AVG_WINDOW_SEC,
            sample_time=Ts,
        )

        residual_acc_full_u = tcp_acc_u - ma_u
        residual_acc_full_s = tcp_acc_s - ma_s

        run_vibration_test_plot_rotated_acceleration_data = False
        if run_vibration_test_plot_rotated_acceleration_data:
            vibration_test_plots.plot_rotated_accelerometer_readings(
                time_vec=time_u,
                signal=tcp_acc_u,
                moving_avg=ma_u,
                residual=residual_acc_full_u,
                title="Unshaped base-frame acceleration for full trajectory (bias/grav removed)",
                signal_color="k",
                signal_linestyle="-",
                plot_name=f"acc_base_unshaped_pose_{pose}_axis_{axis}",
            )

            vibration_test_plots.plot_rotated_accelerometer_readings(
                time_vec=time_s,
                signal=tcp_acc_s,
                moving_avg=ma_s,
                residual=residual_acc_full_s,
                title="Shaped base-frame acceleration for full trajectory (bias/grav removed)",
                signal_color="r",
                signal_linestyle="--",
                plot_name=f"acc_base_shaped_pose_{pose}_axis_{axis}",
            )

        # Residual-vibration metrics:
        # mag_acc_*: acceleration norm [m/s^2]
        # idx_vib_*: index where joint motion is considered settled (end of the motion)
        # peak_acc_*: index of largest residual vibraiton magnitude after end of the motion
        # p2p_*: peak residual amplitude [m/s^2] used for percent reduction metric
        mag_acc_s = np.linalg.norm(tcp_acc_s, axis=1)
        mag_acc_u = np.linalg.norm(tcp_acc_u, axis=1)

        # Residual traces are retained for optional diagnostic plots.
        mag_acc_u_moving_avg = moving_average_signal(
            signal=mag_acc_u,
            window_sec=MOVING_AVG_WINDOW_SEC,
            sample_time=Ts,
        )
        mag_acc_s_moving_avg = moving_average_signal(
            signal=mag_acc_s,
            window_sec=MOVING_AVG_WINDOW_SEC,
            sample_time=Ts,
        )
        mag_acc_u_residual_abs = mag_acc_u - mag_acc_u_moving_avg
        mag_acc_s_residual_abs = mag_acc_s - mag_acc_s_moving_avg

        run_vibration_test_plot_mag_acc_residual_fft = False
        if run_vibration_test_plot_mag_acc_residual_fft:
            vibration_test_plots.plot_mag_acc_residual_and_fft(
                time_u=time_u,
                time_s=time_s,
                mag_acc_u=mag_acc_u,
                mag_acc_s=mag_acc_s,
                mag_acc_u_residual_abs=mag_acc_u_residual_abs,
                mag_acc_s_residual_abs=mag_acc_s_residual_abs,
                sample_time=Ts,
                pose=pose,
                axis=axis,
            )

        # `idx_vib_s`: first shaped index where moved joint is considered settled.
        idx_vib_s = np.where(np.abs(encoder_s[:, axis] - encoder_s[-1, axis]) < 0.0005)[
            0
        ][0]
        # `idx_vib_u`: first unshaped index where moved joint is considered settled.
        idx_vib_u = np.where(np.abs(encoder_u[:, axis] - encoder_u[-1, axis]) < 0.0005)[
            0
        ][0]

        duration_diff_s = (
            float(time_s[-1] - time_u[-1]) if time_s.size and time_u.size else 0.0
        )

        # `peak_acc_*`: index offset (inside residual window) of max vibration amplitude.
        peak_acc_s = np.argmax(np.abs(mag_acc_s[idx_vib_s:]))
        peak_acc_u = np.argmax(np.abs(mag_acc_u[idx_vib_u:]))

        p2p_s = mag_acc_s[idx_vib_s + peak_acc_s]
        p2p_u = mag_acc_u[idx_vib_u + peak_acc_u]
        percent_decrease = (p2p_u - p2p_s) / p2p_u

        print(
            f"percent reduction in peak-to-peak vibration (residual window): {percent_decrease * 100:.2f}%"
        )

        coincide_time_abs = None
        closest_time_abs = None
        coincide_idx_residual_window = None
        run_vibration_test_plot_residual_window = True
        if run_vibration_test_plot_residual_window:
            vibration_test_plots.plot_encoder_fullacc_residual_vibration(
                time_u=time_u,
                time_s=time_s,
                encoder_u_axis=encoder_u[:, axis],
                encoder_s_axis=encoder_s[:, axis],
                mag_acc_u=mag_acc_u,
                mag_acc_s=mag_acc_s,
                idx_vib_u=idx_vib_u,
                idx_vib_s=idx_vib_s,
                peak_acc_u=int(peak_acc_u),
                peak_acc_s=int(peak_acc_s),
                duration_diff_s=duration_diff_s,
                closest_time_abs=closest_time_abs,
                pose=pose,
                axis=axis,
            )

        run_vibration_test_plot_residual_vibration = True
        if run_vibration_test_plot_residual_vibration:
            coincide_time_abs, closest_time_abs, coincide_idx_residual_window = (
                vibration_test_plots.plot_residual_vibration(
                    time_unshaped=time_u,
                    time_shaped=time_s,
                    mag_unshaped=mag_acc_u,
                    mag_shaped=mag_acc_s,
                    idx_vib_unshaped=idx_vib_u,
                    idx_vib_shaped=idx_vib_s,
                    peak_idx_unshaped=int(peak_acc_u),
                    peak_idx_shaped=int(peak_acc_s),
                    sample_time=Ts,
                    pose=pose,
                    duration_diff_s=duration_diff_s,
                    consecutive_windows=2,
                )
            )

        # `blue_idx_*`: absolute sample index where blue coincidence line is placed.
        blue_idx_u = None
        blue_idx_s = None
        # Use the blue-line index to build the two comparison windows.
        if coincide_idx_residual_window is not None:
            # Convert residual-window relative index -> absolute index in full arrays.
            blue_idx_u = min(
                idx_vib_u + coincide_idx_residual_window,
                mag_acc_u.shape[0] - 1,
            )
            blue_idx_s = min(
                idx_vib_s + coincide_idx_residual_window,
                mag_acc_s.shape[0] - 1,
            )

            residual_until_blue_percent = vibration_metric_using_variance(
                mag_acc_u=mag_acc_u[idx_vib_u : blue_idx_u + 1],
                mag_acc_s=mag_acc_s[idx_vib_s : blue_idx_s + 1],
                sample_time=Ts,
                moving_avg_window_sec=MOVING_AVG_WINDOW_SEC,
            )
            print(
                "percent reduction of vibration (residual vibration window): "
                f"{residual_until_blue_percent:.2f}%"
            )
        else:
            print(
                "variance-window metrics skipped: blue-line coincidence index not available"
            )

        # FFT window selection: residual-vibration window from end-of-motion
        # index up to the blue-line coincidence index.
        if blue_idx_u is not None and blue_idx_s is not None:
            # `mask_*`: boolean selectors for residual-vibration samples up to blue line.
            mask_u = np.zeros_like(time_u, dtype=bool)
            mask_s = np.zeros_like(time_s, dtype=bool)
            mask_u[idx_vib_u : blue_idx_u + 1] = True
            mask_s[idx_vib_s : blue_idx_s + 1] = True
        else:
            print("FFT skipped: blue-line coincidence index not available")
            continue

        # FFT inputs/outputs:
        # residual_vibration_window_*: residual-vibration time window [m/s^2]
        # f_*: frequency bins [Hz]
        # fft_*_{x,y,z}: one-sided axis FFT magnitudes
        # fft_*_norm: combined axis-norm FFT magnitude

        residual_vibration_window_u = moving_average_signal(
            signal=residual_acc_full_u[mask_u, :],
            window_sec=MOVING_AVG_WINDOW_SEC,
            sample_time=Ts,
        )
        residual_vibration_window_s = moving_average_signal(
            signal=residual_acc_full_s[mask_s, :],
            window_sec=MOVING_AVG_WINDOW_SEC,
            sample_time=Ts,
        )

        f_u, fft_u_x = _one_sided_fft(residual_vibration_window_u[:, 0], Ts)
        _, fft_u_y = _one_sided_fft(residual_vibration_window_u[:, 1], Ts)
        _, fft_u_z = _one_sided_fft(residual_vibration_window_u[:, 2], Ts)

        f_s, fft_s_x = _one_sided_fft(residual_vibration_window_s[:, 0], Ts)
        _, fft_s_y = _one_sided_fft(residual_vibration_window_s[:, 1], Ts)
        _, fft_s_z = _one_sided_fft(residual_vibration_window_s[:, 2], Ts)

        fft_u_norm = np.sqrt(fft_u_x**2 + fft_u_y**2 + fft_u_z**2)
        fft_s_norm = np.sqrt(fft_s_x**2 + fft_s_y**2 + fft_s_z**2)

        run_vibration_test_plot_fft_axes = False
        run_vibration_test_plot_fft_norm = False

        if run_vibration_test_plot_fft_axes or run_vibration_test_plot_fft_norm:
            vibration_test_plots.plot_fft_summaries(
                f_u=f_u,
                f_s=f_s,
                fft_u_x=fft_u_x,
                fft_u_y=fft_u_y,
                fft_u_z=fft_u_z,
                fft_s_x=fft_s_x,
                fft_s_y=fft_s_y,
                fft_s_z=fft_s_z,
                fft_u_norm=fft_u_norm,
                fft_s_norm=fft_s_norm,
                pose=pose,
                axis=axis,
                plot_fft_axes=run_vibration_test_plot_fft_axes,
                plot_fft_norm=run_vibration_test_plot_fft_norm,
            )
