# src/core_sdk/reforge_core/api.py
import os
import time
import zipfile

ROBOT_MODELS_PATH = os.path.join("src", "robot", "models", "current")

API_TOKEN = os.getenv("REFORGE_API_TOKEN", "dev-token-change-me")

API_TIMEOUT_SECONDS = 60 * 10
JOB_POLL_INTERVAL_SECONDS = 10
JOB_TIMEOUT_SECONDS = 60 * 45

CHUNK_SIZE = 10 * 1024 * 1024


class ReforgeAPIManager:
    """Coordinate calibration data upload and model retrieval.

    Args:
        None.

    Side Effects:
        None.

    Raises:
        None.

    Preconditions:
        None.
    """

    def __init__(
        self,
        reforge_api_token: str,
        robot_id: str,
    ) -> None:
        """Initialize the API manager with credentials and robot identity.

        Args:
            reforge_api_token: API token for cloud authentication.
            robot_id: Identifier for the robot.

        Side Effects:
            Stores credentials in the instance.

        Raises:
            None.

        Preconditions:
            `reforge_api_token` and `robot_id` are non-empty strings.
        """
        self.user_api_token = reforge_api_token
        self.robot_id = robot_id
        self._api_base_url = os.getenv(
            "REFORGE_API_BASE_URL", "https://api.reforgerobotics.com"
        )

    def _get_requests_module(self):
        """Import and return the HTTP client dependency.

        Args:
            None.

        Returns:
            The imported `requests` module.

        Side Effects:
            Imports an optional dependency at runtime.

        Raises:
            RuntimeError: If `requests` is not installed.

        Preconditions:
            None.
        """
        try:
            import requests  # type: ignore[import-untyped]
        except ModuleNotFoundError as exc:
            raise RuntimeError(
                "The 'requests' package is required for cloud API calls. Install it with `pip install requests`."
            ) from exc
        return requests

    def _auth_headers(self) -> dict[str, str]:
        """Build auth headers for outbound cloud API requests.

        Args:
            None.

        Returns:
            `dict[str, str]` HTTP headers with bearer token authorization.

        Side Effects:
            None.

        Raises:
            ValueError: If no usable token is available.

        Preconditions:
            API token is provided via constructor or environment.
        """
        token = self.user_api_token or API_TOKEN
        if not token:
            raise ValueError("Missing API token.")
        return {"Authorization": f"Bearer {token}"}

    def _api_url(self, path: str) -> str:
        """Build an absolute API endpoint URL.

        Args:
            path: Relative endpoint path.

        Returns:
            `str` fully-qualified API URL.

        Side Effects:
            None.

        Raises:
            None.

        Preconditions:
            `path` is a non-empty endpoint path.
        """
        return f"{self._api_base_url.rstrip('/')}/{path.lstrip('/')}"

    def _manual_fallback_hint(self, local_data_path: str | None = None) -> str:
        """Build manual fallback instructions for cloud processing failures.

        Args:
            local_data_path: Optional local path to calibration artifact for support.

        Returns:
            `str` user-facing fallback instructions.

        Side Effects:
            None.

        Raises:
            None.

        Preconditions:
            None.
        """
        hint = (
            " If this issue persists, send the calibration ZIP to "
            "calibration@reforgerobotics.com for manual processing."
        )
        if local_data_path:
            hint += f" Local data path: {os.path.abspath(local_data_path)}"
        return hint

    def _compress_data(
        self, data_folder: str, temp_folder: str = "temp_calibration_data.zip"
    ) -> str:
        """Create a zip archive of the calibration data folder.

        Args:
            data_folder: Path to the folder to compress.
            temp_folder: Zip filename to create within the folder.

        Returns:
            `str` path to the created zip file.

        Side Effects:
            Writes a zip file to disk.

        Raises:
            OSError: If files cannot be read or written.

        Preconditions:
            `data_folder` exists and is readable.
        """
        if os.path.isfile(data_folder) and zipfile.is_zipfile(data_folder):
            return data_folder

        zip_filename = os.path.join(data_folder, temp_folder)
        if zipfile.is_zipfile(zip_filename):
            return zip_filename

        with zipfile.ZipFile(zip_filename, "w", zipfile.ZIP_DEFLATED) as zipf:
            for root, _, files in os.walk(data_folder):
                for file in files:
                    if file != temp_folder:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, start=data_folder)
                        zipf.write(file_path, arcname)
        return zip_filename

    def _save_models_locally(
        self, destination_folder: str, local_folder: str = ROBOT_MODELS_PATH
    ) -> None:
        """Save model artifacts from a cloud folder to local storage.

        Args:
            destination_folder: Folder containing model artifacts to save.
            local_folder: Folder for extracted models.

        Returns:
            `None`.

        Side Effects:
            Creates directories and writes model files to disk.

        Raises:
            OSError: If files cannot be read or written.
            ValueError: If `destination_folder` is not a zip artifact.

        Preconditions:
            `destination_folder` exists and is readable.
        """
        if os.path.isfile(destination_folder) and not zipfile.is_zipfile(
            destination_folder
        ):
            raise ValueError(
                f"Expected a compressed zip artifact, but got non-zip file: {destination_folder}"
            )

        # Unzip and save to src/robot/models/current
        with zipfile.ZipFile(destination_folder, "r") as zipf:
            extract_path = local_folder
            os.makedirs(extract_path, exist_ok=True)
            zipf.extractall(extract_path)

    def upload_data_to_cloud(self, zip_file_path: str) -> tuple[str, float]:
        """Upload zipped calibration data to the cloud and return the data handle.

        Args:
            zip_file_path: Path to a `.zip` file containing calibration data.

        Returns:
            `tuple[str, float]` containing:
            - data_id returned by the cloud upload endpoint
            - upload duration in seconds

        Raises:
            FileNotFoundError: If `zip_file_path` does not exist.
            ValueError: If `zip_file_path` is not a zip file or response is invalid.
            RuntimeError: If request fails or the server returns an error.
        """
        requests = self._get_requests_module()

        if not os.path.isfile(zip_file_path):
            raise FileNotFoundError(f"Zip file not found: {zip_file_path}")
        if not zip_file_path.lower().endswith(".zip"):
            raise ValueError(f"Expected a .zip file, got: {zip_file_path}")
        if not self.robot_id:
            raise ValueError("Missing robot_id.")

        url = self._api_url("/identify/upload_sine_sweep_data")
        uploaded_at = int(time.time())
        manual_fallback_hint = self._manual_fallback_hint(local_data_path=zip_file_path)
        headers = self._auth_headers()
        data = {
            "robot_id": self.robot_id,
            "uploaded_at": str(uploaded_at),
        }

        print(
            f"Uploading data to Reforge Robotics cloud. This may take a few minutes depending on your connection..."
        )
        request_started_at = time.time()

        try:
            with open(zip_file_path, "rb") as file_obj:
                files = {
                    "file": (
                        os.path.basename(zip_file_path),
                        file_obj,
                        "application/zip",
                    )
                }
                response = requests.post(
                    url,
                    headers=headers,
                    data=data,
                    files=files,
                    timeout=API_TIMEOUT_SECONDS,
                )
        except requests.exceptions.ConnectionError as exc:
            raise RuntimeError(
                "Could not reach Reforge cloud API. Check internet connection and API base URL."
                f" Details: {exc}.{manual_fallback_hint}"
            ) from exc
        except requests.exceptions.Timeout as exc:
            raise RuntimeError(
                f"Upload request timed out after {API_TIMEOUT_SECONDS} seconds.{manual_fallback_hint}"
            ) from exc
        except Exception as exc:
            raise RuntimeError(
                f"Upload request failed: {exc}.{manual_fallback_hint}"
            ) from exc

        if response.status_code != 201:
            raise RuntimeError(
                f"Upload failed with status {response.status_code}: {response.text}.{manual_fallback_hint}"
            )

        try:
            payload = response.json()
        except ValueError as exc:
            raise RuntimeError(
                f"Upload response is not valid JSON: {response.text}"
            ) from exc

        data_id = payload.get("data_id")
        upload_duration = payload.get("upload_duration_sec")
        if not data_id or not isinstance(data_id, str):
            raise ValueError(f"Upload response missing valid `data_id`: {payload}")
        if not isinstance(upload_duration, (float, int)):
            upload_duration = time.time() - request_started_at
        return data_id, upload_duration

    def _create_identification_job(self, data_id: str, fine_tune: bool = False) -> str:
        """Trigger cloud identification and return the created job id.

        Args:
            data_id: Identifier returned by the upload endpoint.
            fine_tune: If `True`, run fine-tuning instead of identification.

        Returns:
            `str` job id for the asynchronous identification request.

        Raises:
            ValueError: If the response does not contain a valid `job_id`.
            RuntimeError: If request fails, returns non-202, or JSON decoding fails.
        """
        requests = self._get_requests_module()
        url = self._api_url(
            "/identify/run_sine_sweep_fine_tune"
            if fine_tune
            else "/identify/run_sine_sweep_identification"
        )
        headers = self._auth_headers()
        payload = {"data_id": data_id}
        try:
            response = requests.post(
                url, json=payload, headers=headers, timeout=API_TIMEOUT_SECONDS
            )
        except requests.exceptions.ConnectionError as exc:
            raise RuntimeError(
                f"Could not reach Reforge cloud API while creating the job. "
                f"Check internet connection.{self._manual_fallback_hint()}"
            ) from exc
        except requests.exceptions.Timeout as exc:
            raise RuntimeError(
                f"Job creation timed out after {API_TIMEOUT_SECONDS} seconds.{self._manual_fallback_hint()}"
            ) from exc
        if response.status_code != 202:
            raise RuntimeError(
                f"Failed to create identification job (status {response.status_code}): {response.text}.{self._manual_fallback_hint()}"
            )

        try:
            body = response.json()
        except ValueError as exc:
            raise RuntimeError(
                f"Identification job response is not valid JSON: {response.text}"
            ) from exc

        job_id = body.get("job_id")
        if not job_id or not isinstance(job_id, str):
            raise ValueError(
                f"Identification job response missing valid `job_id`: {body}"
            )
        return job_id

    def _wait_for_job_completion(
        self,
        job_id: str,
        poll_interval_seconds: int = JOB_POLL_INTERVAL_SECONDS,
        timeout_seconds: int = JOB_TIMEOUT_SECONDS,
    ) -> dict:
        """Poll `/jobs/{job_id}` until the job reaches a terminal state.

        Args:
            job_id: Identification job id returned by `_create_identification_job`.
            poll_interval_seconds: Delay between job status checks.
            timeout_seconds: Maximum total wait time before giving up.

        Returns:
            `dict` final job payload when status is `completed`.

        Raises:
            RuntimeError: If status checks fail, JSON decoding fails, or status is `failed`.
            TimeoutError: If `timeout_seconds` is exceeded before completion.
        """
        requests = self._get_requests_module()

        deadline = time.time() + timeout_seconds
        url = self._api_url(f"/jobs/{job_id}")
        headers = self._auth_headers()
        while time.time() < deadline:
            try:
                response = requests.get(
                    url, headers=headers, timeout=API_TIMEOUT_SECONDS
                )
            except requests.exceptions.ConnectionError as exc:
                raise RuntimeError(
                    "Lost connection to Reforge cloud API while polling job status. "
                    f"Check internet connection.{self._manual_fallback_hint()}"
                ) from exc
            except requests.exceptions.Timeout as exc:
                raise RuntimeError(
                    f"Job status request timed out after {API_TIMEOUT_SECONDS} seconds.{self._manual_fallback_hint()}"
                ) from exc
            if response.status_code != 200:
                raise RuntimeError(
                    f"Failed to fetch job status (status {response.status_code}): {response.text}.{self._manual_fallback_hint()}"
                )

            try:
                payload = response.json()
            except ValueError as exc:
                raise RuntimeError(
                    f"Job status response is not valid JSON: {response.text}"
                ) from exc

            status = payload.get("status")
            if status == "completed":
                print(f"Job {job_id} completed.")
                return payload
            if status == "failed":
                error_message = payload.get("error") or "Unknown error"
                raise RuntimeError(f"Identification job failed: {error_message}")
            if status != "processing":
                raise RuntimeError(
                    f"Unexpected job status '{status}' for job_id={job_id}: {payload}"
                )

            time.sleep(poll_interval_seconds)

        raise TimeoutError(
            f"Timed out waiting for identification job {job_id} after {timeout_seconds} seconds. Please email calibration@reforgerobotics.com to manually process your data."
        )

    def _download_file(self, filename: str, destination_dir: str) -> str:
        """Download a file from `/download/{filename}`.

        Args:
            filename: Remote artifact filename returned by the completed job.
            destination_dir: Local directory where the file will be written.

        Returns:
            `str` full local path to the downloaded file.

        Raises:
            RuntimeError: If the download request fails or returns a non-200 status.
        """
        requests = self._get_requests_module()

        safe_filename = os.path.basename(filename)
        url = self._api_url(f"/download/{safe_filename}")
        headers = self._auth_headers()
        os.makedirs(destination_dir, exist_ok=True)
        destination_path = os.path.join(destination_dir, safe_filename)
        manual_fallback_hint = self._manual_fallback_hint(
            local_data_path=destination_dir
        )
        tic = time.time()
        try:
            with requests.get(
                url, headers=headers, stream=True, timeout=API_TIMEOUT_SECONDS
            ) as response:
                if response.status_code != 200:
                    raise RuntimeError(
                        f"Download failed for '{safe_filename}' (status {response.status_code}): {response.text}.{manual_fallback_hint}"
                    )

                with open(destination_path, "wb") as downloaded_file:
                    for chunk in response.iter_content(chunk_size=CHUNK_SIZE):
                        if chunk:
                            downloaded_file.write(chunk)
        except requests.exceptions.ConnectionError as exc:
            raise RuntimeError(
                "Could not reach Reforge cloud API while downloading models. "
                "Check internet connection and API base URL."
                f"{manual_fallback_hint}"
            ) from exc
        except requests.exceptions.Timeout as exc:
            raise RuntimeError(
                f"Download request timed out after {API_TIMEOUT_SECONDS} seconds.{manual_fallback_hint}"
            ) from exc

        duration = time.time() - tic
        print(f"Downloaded files in {duration: .2f} seconds.")
        return destination_path

    def has_local_models(self, models_path: str = ROBOT_MODELS_PATH) -> bool:
        """Check whether local model files are available for fine-tuning.

        Args:
            models_path: Folder expected to contain `.pt` model artifacts.

        Returns:
            `bool` indicating whether at least one `.pt` file is present.

        Side Effects:
            Reads directory metadata and file names from local storage.

        Raises:
            OSError: If `models_path` exists but cannot be listed.

        Preconditions:
            `models_path` is a valid filesystem path.
        """
        return os.path.exists(models_path) and any(
            fname.endswith(".pt") for fname in os.listdir(models_path)
        )

    def run_cloud_model_generation(
        self,
        data_folder: str,
        delete_temp_file: bool = False,
        fine_tune: bool = False,
    ) -> None:
        """Run cloud identification/fine-tuning and save returned models locally.

        Args:
            data_folder: Path to calibration data folder (or zip) to upload.
            delete_temp_file: If `True`, delete temporary zip created locally after upload.
            fine_tune: If `True`, trigger fine-tuning job; otherwise trigger identification.

        Returns:
            `None`.

        Side Effects:
            Uploads data to cloud, creates and polls a remote job, downloads model artifact,
            and writes extracted models to local storage.

        Raises:
            FileNotFoundError: If upload input cannot be found.
            ValueError: If cloud payloads are missing required fields.
            RuntimeError: If upload/job/download requests fail.
            TimeoutError: If job does not complete within timeout.
            OSError: If local file operations fail.

        Preconditions:
            `data_folder` exists and contains valid calibration data.
        """
        # Upload compressed data to cloud using self.user_api_token and self.robot_id (have it decompress in the cloud)
        temp_zip_path = self._compress_data(data_folder)
        try:
            data_id, upload_duration = self.upload_data_to_cloud(temp_zip_path)
        finally:
            if delete_temp_file and os.path.exists(temp_zip_path):
                os.remove(temp_zip_path)
        job_kind = "fine-tuning" if fine_tune else "identification"
        print(
            f"Data uploaded in {upload_duration:.2f} seconds. Running {job_kind}... this may take 20-30 minutes depending on server load."
        )

        # Create job to run model generation in the cloud and wait for completion.
        job_id = self._create_identification_job(data_id, fine_tune=fine_tune)
        print(f"Created {job_kind} job {job_id}. Waiting for completion...")

        job_payload = self._wait_for_job_completion(job_id)

        result = job_payload.get("result") or {}
        model_filename = result.get("model_filename")
        if not model_filename or not isinstance(model_filename, str):
            raise ValueError(
                f"Completed {job_kind} job {job_id} did not include `result.model_filename`: {job_payload}"
            )

        artifact_dir = os.path.join(data_folder, "downloaded_models")
        downloaded_model_zip = self._download_file(model_filename, artifact_dir)
        print(
            f"Downloaded model artifact to {downloaded_model_zip}. Extracting to {ROBOT_MODELS_PATH}..."
        )

        # The API returns a compressed model artifact; reuse local save helper to unzip into current models path.
        self._save_models_locally(downloaded_model_zip)
