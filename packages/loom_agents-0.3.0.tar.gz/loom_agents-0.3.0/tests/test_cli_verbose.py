"""Tests for the --verbose / -v CLI flag.

Verifies that ``--verbose`` enables DEBUG-level logging output on stderr
and that the default (no flag) does NOT produce DEBUG lines.

Note: ``loom status`` will likely fail without a running Postgres instance.
That is expected -- we only inspect the *log output level*, not the exit code.
"""

from __future__ import annotations

import subprocess
import sys


def test_verbose_flag_produces_debug_output():
    """Running ``python -m loom --verbose status`` should emit DEBUG lines on stderr."""
    result = subprocess.run(
        [sys.executable, "-m", "loom", "--verbose", "status"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    # We don't check the exit code -- Postgres is likely not running.
    # Instead we verify that DEBUG-level log lines appear on stderr.
    stderr_lines = result.stderr.splitlines()
    debug_lines = [line for line in stderr_lines if "DEBUG" in line]
    assert len(debug_lines) > 0, (
        "Expected at least one DEBUG line on stderr when --verbose is used.\n"
        f"stderr was:\n{result.stderr}"
    )


def test_no_verbose_flag_omits_debug_output():
    """Running ``python -m loom status`` (no --verbose) should NOT emit DEBUG lines."""
    result = subprocess.run(
        [sys.executable, "-m", "loom", "status"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    # Again, exit code is irrelevant -- we only care about log level.
    stderr_lines = result.stderr.splitlines()
    debug_lines = [line for line in stderr_lines if "DEBUG" in line]
    assert len(debug_lines) == 0, (
        "Expected NO DEBUG lines on stderr without --verbose.\n"
        f"Found {len(debug_lines)} DEBUG line(s):\n"
        + "\n".join(debug_lines)
    )


def test_verbose_short_flag_produces_debug_output():
    """The short form ``-v`` should behave identically to ``--verbose``."""
    result = subprocess.run(
        [sys.executable, "-m", "loom", "-v", "status"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    stderr_lines = result.stderr.splitlines()
    debug_lines = [line for line in stderr_lines if "DEBUG" in line]
    assert len(debug_lines) > 0, (
        "Expected at least one DEBUG line on stderr when -v is used.\n"
        f"stderr was:\n{result.stderr}"
    )
