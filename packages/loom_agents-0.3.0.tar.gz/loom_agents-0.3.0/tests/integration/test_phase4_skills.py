"""Tests for Phase 4 Stream B: new skills and workflows."""

from __future__ import annotations

from pathlib import Path

from loom.skills.loader import discover_skills, parse_skill_file
from loom.workflows.loader import discover_workflows, load_workflow


class TestPhase4Skills:
    def test_discover_all_skills(self):
        """All 10 built-in skills discovered."""
        skills = discover_skills()
        assert len(skills) == 10
        assert "identify_parallelism" in skills
        assert "summarize_graph" in skills

    def test_parse_identify_parallelism(self):
        skills = discover_skills()
        skill = parse_skill_file(Path(skills["identify_parallelism"].source_path))
        assert skill.name == "identify_parallelism"
        assert "task_graph" in skill.inputs
        assert len(skill.outputs) >= 1

    def test_parse_summarize_graph(self):
        skills = discover_skills()
        skill = parse_skill_file(Path(skills["summarize_graph"].source_path))
        assert skill.name == "summarize_graph"
        assert "project_name" in skill.inputs
        assert "task_graph" in skill.inputs
        assert "status_counts" in skill.inputs

    def test_discover_all_workflows(self):
        """All 4 built-in workflows discovered."""
        workflows = discover_workflows()
        assert len(workflows) == 4
        assert "audit_codebase" in workflows
        assert "deploy_to_prod" in workflows

    def test_parse_audit_codebase_workflow(self):
        wf = load_workflow("audit_codebase")
        assert wf.name == "audit_codebase"
        assert len(wf.steps) == 5
        assert wf.steps[0].name == "decompose_audit"

    def test_parse_deploy_to_prod_workflow(self):
        wf = load_workflow("deploy_to_prod")
        assert wf.name == "deploy_to_prod"
        assert len(wf.steps) == 3
        assert wf.steps[1].type == "confirm"
