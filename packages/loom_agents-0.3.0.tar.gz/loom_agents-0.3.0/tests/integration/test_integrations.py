"""Tests for Phase 4 Stream D: Slack + Obsidian integrations."""

from __future__ import annotations

import json
import os

import pytest

from loom.integrations.slack import send_slack_notification, SEVERITY_COLORS
from loom.integrations.obsidian import write_daily_digest
from loom.config import IntegrationsConfig


class TestSlackNotifications:
    async def test_slack_notification_disabled(self):
        """No-op when webhook URL is empty."""
        result = await send_slack_notification(
            webhook_url="",
            message="test",
        )
        assert result is False

    def test_severity_colors_defined(self):
        """All severity levels have colors."""
        assert "info" in SEVERITY_COLORS
        assert "warning" in SEVERITY_COLORS
        assert "error" in SEVERITY_COLORS


class TestObsidianDigest:
    async def test_obsidian_digest_writes_file(self, tmp_path):
        """Digest markdown file created in correct location."""
        vault = str(tmp_path / "vault")
        file_path = await write_daily_digest(
            vault_path=vault,
            project_name="Test Project",
            summary="Everything is going well.",
            status_counts={"pending": 3, "done": 5, "failed": 1},
            escalations=[],
        )
        assert os.path.exists(file_path)
        assert "test-project" in file_path
        assert file_path.endswith(".md")

    async def test_obsidian_digest_format(self, tmp_path):
        """File contents include all expected sections."""
        vault = str(tmp_path / "vault")
        file_path = await write_daily_digest(
            vault_path=vault,
            project_name="My App",
            summary="Summary text here.",
            status_counts={"pending": 2, "done": 10},
            escalations=[{"task_id": "loom-abc123", "message": "Needs review"}],
        )
        content = open(file_path).read()
        assert "# Loom Daily Digest" in content
        assert "Summary text here." in content
        assert "**Pending:** 2" in content
        assert "**Done:** 10" in content
        assert "loom-abc123" in content
        assert "Needs review" in content

    async def test_obsidian_digest_empty_escalations(self, tmp_path):
        """Handles empty escalations gracefully."""
        vault = str(tmp_path / "vault")
        file_path = await write_daily_digest(
            vault_path=vault,
            project_name="Clean Project",
            summary="All clear.",
            status_counts={},
            escalations=[],
        )
        content = open(file_path).read()
        assert "No open escalations" in content


class TestIntegrationsConfig:
    def test_config_defaults(self):
        config = IntegrationsConfig()
        assert config.slack_webhook_url == ""
        assert config.obsidian_vault_path == ""

    def test_config_with_values(self):
        config = IntegrationsConfig(
            slack_webhook_url="https://hooks.slack.com/test",
            obsidian_vault_path="/path/to/vault",
        )
        assert config.slack_webhook_url == "https://hooks.slack.com/test"
        assert config.obsidian_vault_path == "/path/to/vault"
