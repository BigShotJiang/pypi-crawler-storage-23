"""Tests for the web dashboard — template rendering and API endpoints."""

import asyncio

import pytest

from loom.dashboard.app import (
    _get_all_tasks,
    _get_graph_mermaid,
    _handle_api_graph,
    _handle_api_projects,
    _handle_api_tasks,
    _handle_board,
    _handle_static,
    _http_response,
)
from loom.graph import store
from loom.graph.task import Task, TaskStatus


@pytest.fixture
async def dashboard_tasks(pool, project):
    """Create tasks for dashboard testing."""
    tasks = [
        Task(id="dash-001", project_id=project, title="Pending Task", status=TaskStatus.PENDING, priority="p0"),
        Task(id="dash-002", project_id=project, title="Claimed Task", status=TaskStatus.CLAIMED, priority="p1", assignee="agent-1"),
        Task(id="dash-003", project_id=project, title="Done Task", status=TaskStatus.DONE, priority="p2"),
        Task(id="dash-004", project_id=project, title="Failed Task", status=TaskStatus.FAILED, priority="p1"),
        Task(id="dash-005", project_id=project, title="Blocked Task", status=TaskStatus.BLOCKED, priority="p1", depends_on=["dash-001"]),
    ]
    for t in tasks:
        await store.create_task(pool, t)
    return tasks


async def test_dashboard_route_returns_html(pool, project, dashboard_tasks):
    """GET /dashboard returns 200 with HTML content."""
    response = await _handle_board(pool, project)
    assert b"HTTP/1.1 200 OK" in response
    assert b"text/html" in response
    assert b"Task Board" in response


async def test_board_template_renders_columns(pool, project, dashboard_tasks):
    """Board page includes kanban columns via the tasks API."""
    response = await _handle_api_tasks(pool, project)
    html = response.decode("utf-8")
    assert "Pending" in html
    assert "Claimed" in html
    assert "Done" in html
    assert "Failed" in html
    assert "Blocked" in html


async def test_api_tasks_returns_task_cards(pool, project, dashboard_tasks):
    """API endpoint returns task cards with IDs and titles."""
    response = await _handle_api_tasks(pool, project)
    html = response.decode("utf-8")
    assert "dash-001" in html
    assert "Pending Task" in html
    assert "dash-002" in html
    assert "Claimed Task" in html


async def test_api_graph_returns_mermaid(pool, project, dashboard_tasks):
    """API endpoint returns valid Mermaid syntax."""
    response = await _handle_api_graph(pool, project)
    html = response.decode("utf-8")
    assert "graph TD" in html
    assert "dash-001" in html


async def test_graph_mermaid_includes_styles(pool, project, dashboard_tasks):
    """Graph Mermaid output includes status-colored styles."""
    graph = await _get_graph_mermaid(pool, project)
    assert "graph TD" in graph
    assert "style dash-001" in graph
    assert "style dash-003" in graph  # done task
    # Verify dependency edge
    assert "dash-001 --> dash-005" in graph


async def test_projects_page_lists_projects(pool, project):
    """Projects page shows all projects."""
    response = await _handle_api_projects(pool)
    html = response.decode("utf-8")
    assert "200 OK" in response.decode("utf-8", errors="replace")
    # Should contain the test project ID
    assert project in html


async def test_static_css_served():
    """Static CSS file served correctly."""
    response = _handle_static("/static/style.css")
    assert b"200 OK" in response
    assert b"text/css" in response
    assert b"Loom Dashboard" in response


async def test_static_missing_404():
    """Missing static file returns 404."""
    response = _handle_static("/static/nonexistent.xyz")
    assert b"404 Not Found" in response
