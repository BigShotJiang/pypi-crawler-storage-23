"""Tests for CLI entry points: `python -m loom` and `loom` console script."""

from __future__ import annotations

import subprocess
import sys


def test_python_m_loom_help():
    """Running `python -m loom --help` should exit 0 and mention Loom."""
    result = subprocess.run(
        [sys.executable, "-m", "loom", "--help"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert result.returncode == 0, (
        f"python -m loom --help failed:\nstdout={result.stdout}\nstderr={result.stderr}"
    )
    assert "Loom" in result.stdout, (
        f"Expected 'Loom' in output, got:\n{result.stdout}"
    )


def test_loom_console_script_help():
    """Running `loom --help` via the console script should exit 0 and mention Loom."""
    result = subprocess.run(
        ["uv", "run", "loom", "--help"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert result.returncode == 0, (
        f"uv run loom --help failed:\nstdout={result.stdout}\nstderr={result.stderr}"
    )
    assert "Loom" in result.stdout, (
        f"Expected 'Loom' in output, got:\n{result.stdout}"
    )
