"""Event types for the Loom event system."""

from __future__ import annotations

from enum import StrEnum


class EventType(StrEnum):
    TASK_CREATED = "task.created"
    TASK_CLAIMED = "task.claimed"
    TASK_DONE = "task.done"
    TASK_FAILED = "task.failed"
    TASK_BLOCKED = "task.blocked"
    TASK_UPDATED = "task.updated"
    TASK_UNBLOCKED = "task.unblocked"
    PROJECT_DECOMPOSED = "project.decomposed"
    PROJECT_COMPLETE = "project.complete"
    MESSAGE_SENT = "message.sent"
    ESCALATION_RAISED = "escalation.raised"
    ESCALATION_RESOLVED = "escalation.resolved"
    # Phase 3: Orchestration
    TASK_RETRIED = "task.retried"
    TASK_DEAD_LETTER = "task.dead_letter"
    CLAIM_EXPIRED = "claim.expired"
    WORKFLOW_STARTED = "workflow.started"
    WORKFLOW_STEP_COMPLETED = "workflow.step_completed"
    WORKFLOW_COMPLETED = "workflow.completed"
    WORKFLOW_FAILED = "workflow.failed"
    # Phase 6: Merge agent
    MERGE_STARTED = "merge.started"
    MERGE_SUCCEEDED = "merge.succeeded"
    MERGE_FAILED = "merge.failed"
    # Phase 7: Task state management
    TASK_RESET = "task.reset"
    # Idea backlog
    IDEA_CREATED = "idea.created"
