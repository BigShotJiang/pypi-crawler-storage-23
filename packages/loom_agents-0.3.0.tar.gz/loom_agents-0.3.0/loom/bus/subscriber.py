"""Redis subscribe helpers — minimal Phase 1 skeleton."""

from __future__ import annotations

import json
from collections.abc import AsyncIterator

from redis.asyncio import Redis

from loom.bus import channels


async def subscribe_events(
    redis: Redis, project_id: str
) -> AsyncIterator[dict]:
    """Subscribe to task update events. Yields parsed event dicts."""
    pubsub = redis.pubsub()
    await pubsub.subscribe(channels.updates_channel(project_id))
    try:
        async for message in pubsub.listen():
            if message["type"] == "message":
                yield json.loads(message["data"])
    finally:
        await pubsub.unsubscribe()
        await pubsub.aclose()
