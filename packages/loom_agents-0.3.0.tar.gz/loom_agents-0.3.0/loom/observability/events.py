"""Structured event logging for task lifecycle and tool calls."""

from __future__ import annotations

import logging


logger = logging.getLogger("loom.events")


def log_task_event(
    event_type: str,
    task_id: str,
    project_id: str,
    **extra: object,
) -> None:
    """Emit a structured log for a task lifecycle event."""
    logger.info(
        "task_event",
        extra={
            "event_type": event_type,
            "task_id": task_id,
            "project_id": project_id,
            **extra,
        },
    )


def log_tool_call(
    tool_name: str,
    duration_ms: float,
    success: bool,
    **extra: object,
) -> None:
    """Emit a structured log for an MCP tool call."""
    logger.info(
        "tool_call",
        extra={
            "tool_name": tool_name,
            "duration_ms": round(duration_ms, 2),
            "success": success,
            **extra,
        },
    )


def log_orchestrator_tick(
    swept: int,
    retried: int,
    escalated: int,
    **extra: object,
) -> None:
    """Emit a structured log for an orchestrator sweep cycle."""
    logger.info(
        "orchestrator_tick",
        extra={
            "expired_swept": swept,
            "tasks_retried": retried,
            "escalations_handled": escalated,
            **extra,
        },
    )
