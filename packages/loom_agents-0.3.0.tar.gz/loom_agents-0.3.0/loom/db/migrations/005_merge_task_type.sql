-- Phase 6: Add task_type column with merge support
-- Idempotent: uses IF NOT EXISTS / DO blocks

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name = 'tasks' AND column_name = 'task_type'
    ) THEN
        ALTER TABLE tasks ADD COLUMN task_type TEXT NOT NULL DEFAULT 'standard';
    END IF;
END
$$;

-- Add CHECK constraint for allowed task types (idempotent)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'chk_task_type'
    ) THEN
        ALTER TABLE tasks ADD CONSTRAINT chk_task_type
            CHECK (task_type IN ('standard', 'merge'));
    END IF;
END
$$;

CREATE INDEX IF NOT EXISTS idx_tasks_task_type ON tasks (task_type)
    WHERE task_type != 'standard';
