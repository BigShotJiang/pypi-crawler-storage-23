-- Phase 5: Multi-project support
ALTER TABLE projects ADD COLUMN IF NOT EXISTS archived BOOLEAN DEFAULT FALSE;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS config JSONB DEFAULT '{}';

CREATE INDEX IF NOT EXISTS idx_projects_archived ON projects (archived);
