-- Migration 006: Add verify_command column for post-completion verification
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS verify_command TEXT;
