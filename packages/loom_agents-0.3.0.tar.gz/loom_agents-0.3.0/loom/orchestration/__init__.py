"""Orchestration components: sweeper, retry, escalation handler, and main loop."""
