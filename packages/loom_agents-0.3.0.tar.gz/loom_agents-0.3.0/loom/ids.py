"""Conflict-free ID generation for Loom entities."""

import secrets


def task_id() -> str:
    """Generate a task ID: loom-{8 hex chars}."""
    return f"loom-{secrets.token_hex(4)}"
