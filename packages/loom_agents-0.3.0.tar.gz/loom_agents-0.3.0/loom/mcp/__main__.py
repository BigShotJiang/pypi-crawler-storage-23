"""Entry point for running the MCP server: python -m loom.mcp"""

from loom.mcp.server import mcp

mcp.run(transport="stdio")
