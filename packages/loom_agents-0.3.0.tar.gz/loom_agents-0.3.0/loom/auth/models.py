"""Auth models and role permission definitions."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel


class AgentRole(str, Enum):
    READONLY = "readonly"
    WORKER = "worker"
    LEAD = "lead"
    ADMIN = "admin"


class Agent(BaseModel):
    id: str
    name: str
    role: AgentRole
    project_ids: list[str] = []
    active: bool = True
    last_seen_at: str | None = None


# Maps roles to allowed MCP tool names
ROLE_PERMISSIONS: dict[str, set[str]] = {
    "readonly": {
        "loom_ready", "loom_status", "loom_graph", "loom_projects",
        "loom_dead_letter",
    },
    "worker": {
        "loom_ready", "loom_status", "loom_graph", "loom_projects",
        "loom_dead_letter",
        "loom_claim", "loom_done", "loom_fail", "loom_heartbeat", "loom_message",
    },
    "lead": {
        "loom_ready", "loom_status", "loom_graph", "loom_projects",
        "loom_dead_letter",
        "loom_claim", "loom_done", "loom_fail", "loom_heartbeat", "loom_message",
        "loom_create", "loom_update", "loom_escalate", "loom_decompose",
        "loom_workflow", "loom_orchestrate",
    },
    "admin": {
        "loom_ready", "loom_status", "loom_graph", "loom_projects",
        "loom_dead_letter",
        "loom_claim", "loom_done", "loom_fail", "loom_heartbeat", "loom_message",
        "loom_create", "loom_update", "loom_escalate", "loom_decompose",
        "loom_workflow", "loom_orchestrate",
        "loom_create_project", "loom_archive_project", "loom_switch_project",
    },
}
