"""GCP Secret Manager loader — runs before config load."""

from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)

# Maps GCP secret names to environment variable names.
SECRET_MAP: dict[str, str] = {
    "loom-database-url": "LOOM_DATABASE_URL",
    "loom-redis-url": "LOOM_REDIS_URL",
    "loom-skills-api-key": "LOOM_SKILLS_API_KEY",
}


def maybe_load_gcp_secrets() -> int:
    """Load secrets from GCP Secret Manager into env vars.

    Only active when LOOM_GCP_PROJECT is set. Uses os.environ.setdefault()
    so explicit env vars always win. Returns the number of secrets loaded.
    Gracefully degrades with a warning if google-cloud-secret-manager is
    not installed.
    """
    gcp_project = os.environ.get("LOOM_GCP_PROJECT")
    if not gcp_project:
        return 0

    try:
        from google.cloud.secretmanager import SecretManagerServiceClient
    except ImportError:
        logger.warning(
            "LOOM_GCP_PROJECT is set but google-cloud-secret-manager is not "
            "installed. Install with: pip install 'loom-agents[gcp]'"
        )
        return 0

    client = SecretManagerServiceClient()
    loaded = 0

    for secret_name, env_var in SECRET_MAP.items():
        if os.environ.get(env_var):
            logger.debug("Skipping %s — %s already set", secret_name, env_var)
            continue
        try:
            name = f"projects/{gcp_project}/secrets/{secret_name}/versions/latest"
            response = client.access_secret_version(request={"name": name})
            value = response.payload.data.decode("utf-8")
            os.environ.setdefault(env_var, value)
            loaded += 1
            logger.info("Loaded secret %s → %s", secret_name, env_var)
        except Exception:
            logger.warning("Failed to load secret %s", secret_name, exc_info=True)

    return loaded
