"""Workflow system: YAML-defined multi-step processes with state tracking."""
