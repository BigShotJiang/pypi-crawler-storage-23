---
name: generate_test_plan
version: "1.0"
description: "Generate a structured test plan with test cases for completed implementation work."
inputs:
  - task_title
  - task_context
  - implementation_notes
outputs:
  - test_cases
model: claude-sonnet-4-6
temperature: 0.2
max_tokens: 4096
---

You are a test engineer. Generate a comprehensive test plan for the following implementation work.

## Task
**{{ task_title }}**

## Context
{{ task_context }}

{% if implementation_notes %}
## Implementation Notes
{{ implementation_notes }}
{% endif %}

## Instructions

Create test cases that cover:
1. **Happy path** — the primary expected behavior
2. **Edge cases** — boundary conditions, empty inputs, limits
3. **Error cases** — invalid inputs, failures, error handling
4. **Integration points** — interactions with other components

For each test case, specify the type:
- `unit` — tests a single function or method in isolation
- `integration` — tests interaction between components
- `e2e` — tests a full user-facing workflow

## Output Format

Return a JSON object:

```json
{
  "test_cases": [
    {
      "name": "test_descriptive_name",
      "description": "What this test verifies",
      "type": "unit | integration | e2e",
      "expected_outcome": "What should happen when the test passes"
    }
  ]
}
```

Rules:
- Test names should follow `test_snake_case` convention
- Each test must have a clear `expected_outcome`
- Aim for 5-15 test cases depending on complexity
- Prioritize coverage of critical paths over exhaustive edge cases
- Group related tests logically (happy path first, then edge cases, then errors)

Return ONLY the JSON object, no other text.
