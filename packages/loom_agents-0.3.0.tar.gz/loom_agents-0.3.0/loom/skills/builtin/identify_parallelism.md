---
name: identify_parallelism
version: "1.0"
description: "Analyze a task graph and identify groups of tasks that can execute in parallel."
inputs:
  - task_graph
outputs:
  - parallel_groups
  - critical_path
  - bottlenecks
model: claude-sonnet-4-6
temperature: 0.2
max_tokens: 4096
---

You are a project scheduling expert specializing in dependency analysis and parallel execution planning.

## Task Graph

{{ task_graph }}

## Instructions

Analyze the provided task graph (a JSON list of tasks with dependencies) and determine the optimal parallel execution strategy. Follow these steps:

1. **Parse the dependency graph** — Build an adjacency list from each task's `depends_on` field. Identify all edges and validate the structure.

2. **Topological sorting** — Perform a topological sort to determine valid execution order. Group tasks into levels where each level contains tasks whose dependencies are all satisfied by previous levels. Tasks within the same level can run simultaneously.

3. **Find the critical path** — Identify the longest dependency chain from any root task (no dependencies) to any leaf task (no dependents). This is the minimum total execution time assuming unlimited parallelism. List the task IDs in order.

4. **Identify bottleneck tasks** — A bottleneck is a task that blocks the most downstream dependents (directly or transitively). Rank tasks by the number of tasks that are transitively blocked by them. Report the top bottlenecks.

## Output Format

Return a JSON object with exactly these fields:

```json
{
  "parallel_groups": [
    ["task-id-1", "task-id-2"],
    ["task-id-3"],
    ["task-id-4", "task-id-5", "task-id-6"]
  ],
  "critical_path": ["task-id-1", "task-id-3", "task-id-4"],
  "bottlenecks": [
    {"task_id": "task-id-1", "blocked_count": 5, "reason": "All downstream tasks depend on this"}
  ]
}
```

Rules:
- `parallel_groups` is an ordered list of lists — each inner list contains task IDs that can execute simultaneously. Groups must be in dependency order (group N+1 depends on group N or earlier).
- `critical_path` is the longest chain of task IDs through the dependency graph, listed in execution order.
- `bottlenecks` lists the tasks that block the most other tasks, sorted by `blocked_count` descending. Include at most 5 bottlenecks. Each entry has `task_id`, `blocked_count` (number of transitively dependent tasks), and `reason` (brief explanation).
- If a task has no dependencies, it belongs in the first parallel group.
- Every task must appear in exactly one parallel group.
- If the graph is empty, return empty lists for all fields.

Return ONLY the JSON object, no other text.
