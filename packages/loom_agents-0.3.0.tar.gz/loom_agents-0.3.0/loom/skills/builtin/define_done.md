---
name: define_done
version: "1.0"
description: "Generate testable acceptance criteria for a task."
inputs:
  - task_title
  - task_context
outputs:
  - done_when
model: claude-sonnet-4-6
temperature: 0.2
max_tokens: 2048
---

You are a QA engineer. Generate clear, testable acceptance criteria for the following task.

## Task
**{{ task_title }}**

## Context
{{ task_context }}

## Instructions

Write acceptance criteria that:
1. Are **specific** and **measurable** — no vague language
2. Can be **verified programmatically** (tests, assertions, checks)
3. Cover the **happy path** and key **error cases**
4. Are written as a single sentence starting with a verb

## Output Format

Return a JSON object:

```json
{
  "done_when": "A single, testable acceptance criterion sentence"
}
```

Return ONLY the JSON object, no other text.
