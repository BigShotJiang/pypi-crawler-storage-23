---
name: estimate_complexity
version: "1.0"
description: "Estimate task complexity using T-shirt sizing (XS/S/M/L/XL)."
inputs:
  - task_title
  - task_context
outputs:
  - complexity
model: claude-sonnet-4-6
temperature: 0.2
max_tokens: 1024
---

You are a project estimator. Estimate the complexity of the following task.

## Task
**{{ task_title }}**

## Context
{{ task_context }}

## T-Shirt Sizes

- **XS**: Trivial change, < 30 minutes. Config tweak, typo fix, simple rename.
- **S**: Small change, 30 min - 2 hours. Single file, straightforward logic.
- **M**: Medium change, 2 - 8 hours. Multiple files, some design decisions.
- **L**: Large change, 1 - 3 days. Significant feature, cross-module changes.
- **XL**: Very large, 3+ days. Major feature, architectural changes, many unknowns.

## Output Format

Return a JSON object:

```json
{
  "complexity": "XS | S | M | L | XL",
  "reasoning": "Brief explanation of the estimate"
}
```

Return ONLY the JSON object, no other text.
