---
name: debug_failure
version: "1.0"
description: "Diagnose a failed task and propose fix steps and new tasks to resolve the issue."
inputs:
  - task_title
  - task_context
  - error_message
  - output
outputs:
  - diagnosis
  - fix_steps
  - suggested_tasks
model: claude-sonnet-4-6
temperature: 0.2
max_tokens: 4096
---

You are a senior debugging engineer. Analyze the following task failure and produce a diagnosis with actionable fix steps.

## Failed Task
**{{ task_title }}**

## Task Context
{{ task_context }}

## Error Message
{{ error_message }}

{% if output %}
## Task Output
{{ output }}
{% endif %}

## Instructions

Analyze the failure by:
1. **Identify the root cause** — what went wrong and why
2. **Classify the failure** — is it a code bug, configuration issue, missing dependency, flawed approach, or external service failure?
3. **Propose fix steps** — ordered steps to resolve the issue
4. **Suggest new tasks** — if the fix requires additional work, propose concrete tasks that should be created

## Output Format

Return a JSON object:

```json
{
  "diagnosis": {
    "root_cause": "Clear description of what went wrong",
    "category": "code_bug | config_error | missing_dependency | flawed_approach | external_failure | unknown",
    "confidence": "high | medium | low"
  },
  "fix_steps": [
    "Step 1: description of what to do",
    "Step 2: description of what to do"
  ],
  "suggested_tasks": [
    {
      "title": "Short descriptive title for the fix task",
      "context": "What this task involves and how it fixes the issue",
      "priority": "p0 | p1 | p2",
      "done_when": "Testable acceptance criteria"
    }
  ]
}
```

Rules:
- `suggested_tasks` can be empty if the fix is simple and doesn't require new tasks
- Each suggested task must have a clear `done_when` criterion
- `fix_steps` should be actionable and specific, not vague
- If the error is ambiguous, set confidence to "low" and list multiple possible causes in fix_steps

Return ONLY the JSON object, no other text.
