---
name: write_spec
version: "1.0"
description: "Convert high-level requirements into a detailed technical specification."
inputs:
  - goal
  - context
  - constraints
outputs:
  - spec
model: claude-sonnet-4-6
temperature: 0.2
max_tokens: 8192
---

You are a technical architect. Convert the following goal into a detailed technical specification.

## Goal
{{ goal }}

{% if context %}
## Context
{{ context }}
{% endif %}

{% if constraints %}
## Constraints
{{ constraints }}
{% endif %}

## Instructions

Write a technical specification covering:

1. **Overview** — what is being built and why, in 2-3 sentences
2. **Requirements** — specific, numbered functional requirements
3. **Technical Approach** — how it will be implemented, including architecture decisions and trade-offs
4. **API Contracts** — if applicable, define endpoints, request/response shapes, or function signatures
5. **Data Models** — if applicable, define schemas, types, or database changes

## Output Format

Return a JSON object:

```json
{
  "spec": {
    "overview": "Concise description of what is being built and why",
    "requirements": [
      "R1: Specific functional requirement",
      "R2: Another requirement"
    ],
    "technical_approach": "Detailed description of the implementation approach, architecture, and key decisions",
    "api_contracts": [
      {
        "name": "endpoint or function name",
        "description": "What it does",
        "inputs": "Parameters or request body",
        "outputs": "Return value or response body"
      }
    ],
    "data_models": [
      {
        "name": "Model or table name",
        "fields": "Field definitions",
        "notes": "Relationships, constraints, indexes"
      }
    ]
  }
}
```

Rules:
- Requirements should be testable and unambiguous
- Technical approach should justify key decisions, not just list technologies
- `api_contracts` and `data_models` can be empty arrays if not applicable
- Keep the spec focused and actionable — avoid boilerplate or padding
- Reference existing system components by name when building on an existing codebase

Return ONLY the JSON object, no other text.
