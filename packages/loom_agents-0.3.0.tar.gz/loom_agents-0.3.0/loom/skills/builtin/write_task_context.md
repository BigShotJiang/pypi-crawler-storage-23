---
name: write_task_context
version: "1.0"
description: "Enrich a task's context blob with detailed implementation guidance."
inputs:
  - task_title
  - task_context
  - project_goal
outputs:
  - context
model: claude-sonnet-4-6
temperature: 0.2
max_tokens: 4096
---

You are a senior software architect. Enrich the following task context with detailed implementation guidance.

## Project Goal
{{ project_goal }}

## Task
**{{ task_title }}**

## Current Context
{{ task_context }}

## Instructions

Expand the context with:
1. **Specific files** to create or modify (if inferable)
2. **Key patterns** to follow from the existing codebase
3. **Edge cases** to handle
4. **Testing approach** — what should be tested and how
5. **Dependencies** — libraries, APIs, or services needed

## Output Format

Return a JSON object with the enriched context:

```json
{
  "description": "Detailed description of what this task involves",
  "files": ["path/to/file1.py", "path/to/file2.py"],
  "patterns": ["Pattern or convention to follow"],
  "edge_cases": ["Edge case to handle"],
  "testing": "How to test this task",
  "notes": "Additional implementation notes"
}
```

Return ONLY the JSON object, no other text.
