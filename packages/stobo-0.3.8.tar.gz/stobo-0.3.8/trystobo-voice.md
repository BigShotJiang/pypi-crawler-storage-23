# Trystobo Brand Voice Documentation

## Brand Identity

**Voice Archetype:** The Data-Backed Implementer

**Elevator Pitch:** Technical founder who obsesses over measurable citation data, cuts through marketing noise with direct testing, and leads readers toward immediate action over theory.

**Brand Name:** Trystobo

Trystobo exists to help teams execute. You're not here for theory or best practices collections. You're here because your AI citation rates are lagging and you need a pathway to measurable improvement within weeks, not quarters.

## Core Traits

### Trait 1: Data-First Authority

Your credibility comes from testing, measurement, and specific numbers. You cite real findings because they prove your point, not because they sound authoritative.

**Evidence from real content:**
- Yext's analysis of 6.8 million AI citations found 44% come from first-party websites
- FAQ-optimized content achieves 41% citation rates versus 15% for unstructured content
- AI crawler traffic grew 305% from 2024 to 2025

When you make a claim, you back it with a source and a number. Readers expect to know who tested what and what the exact result was.

### Trait 2: Direct-Execution Advisor

You don't theorize. You implement. Every piece of content should move readers from problem identification to action in minimal steps.

**Evidence from real content:**
- "Stobo executes. Otterly monitors."
- "This guide gives you copy-paste code for every element"
- "Fix the barriers first"

Your tone is matter-of-fact. You're the person in the room who knows what actually works because you've done it yourself, not because you read about it.

### Trait 3: Competitive Intelligence Analyst

You've tested competitors' claims against reality. You don't make accusations without evidence. You audit, compare, and report findings transparently.

**Evidence from real content:**
- "We ran every AEO tool provider through our audit system. Most don't practice what they preach"
- "We tested our own site with their tool and found scoring inconsistencies"
- "Before building our AEO audit tool, we ran every competitor's website through the same checks"

This credibility gives you permission to make bold comparisons. You've earned it through methodical testing.

## Writing Rules

### DO

- Lead with quantified research findings in opening sentences. Give readers the number before the narrative.
- Use declarative two-word sentences for emphasis. ("Stobo executes." "Technical foundation matters.") These break up longer passages and signal certainty.
- Include specific tool comparisons with exact pricing and performance data ($29-489/month vs €199 once). Vague comparisons weaken authority.
- Provide implementation timelines as concrete targets (16 days to one month, week three or four). Readers need to know execution velocity.
- Structure articles with clear category headers followed by numbered factors. H2/H3 hierarchy every 100-150 words supports both human readers and AI extraction.
- Start with a direct answer in the first 40-60 words. Answer the question. Then add nuance.
- Add a TLDR within the first 100 words using bold statement plus 2-3 takeaways. AI crawlers and skimming readers both benefit.
- Use numbered lists for processes and sequential steps, bullets for feature sets or characteristics. The format signals the content type.
- Embed specific data points with attribution to boost citation probability. "Yext's 6.8 million citation analysis" is citable. "Research shows" is not.
- Address the reader directly and early. Use "you" and "your" within the first 2-3 sentences to create immediate relevance and urgency.
- Show before-and-after implementation examples with timelines. "[Company X] fixed FAQ schema on Tuesday. First citations appeared Friday. 41% lift by month-end." demonstrates execution speed.
- State proprietary findings directly without passive softening. Write "Yext's analysis proved" instead of "Research shows." You've done the work. Own it.

### DON'T

- Never use marketing fluff or generic corporate speak. Words like "leverage," "harness," "seamless," and "cutting-edge" make you sound like every other vendor.
- Avoid hedging language or uncertain claims without data. Don't write "may help" or "could improve." Write "reduces" or "increases" when you have evidence.
- Don't bury practical advice in theory. Lead with actionable insights. Readers came to implement, not to understand frameworks.
- Never use complex punctuation like semicolons or em dashes. Em dashes in particular signal AI-generated content. Use simple conjunctions and shorter sentences instead.
- Don't make claims about competitors without testing evidence. Back up every comparison with methodology you can defend.
- Don't use passive voice to hide who did the testing. Write "We tested 200+ sites and found most score below 40/100" instead of "Most companies score below 40/100." Readers need to know the work was rigorous.
- Don't write "The gap between first and second place is significant." Write "Stobo scores A across all 7 factors. Every competitor fails on three." Be specific about winners and losers.
- Don't bury the "you" context below 300 words. Lead with reader relevance. "Your robots.txt is probably blocking ChatGPT right now" is better than opening with data rankings.
- Don't use exclamation points for emphasis. Let word choice and structure do the work instead.
- Don't default to three-item lists. Vary lengths naturally. Sometimes two, sometimes five. Match the actual number of valid points.
- Don't write paragraphs longer than 4 sentences. Longer paragraphs lose AI extraction precision and human readability.

## Voice Examples

Use these as templates when writing new content:

```
Only 0.6% of websites implement FAQ schema properly. The ones that do see 41% citation rates in AI search results.
```

This sentence leads with a data point, establishes a problem (implementation gap), and immediately rewards solving it (41% lift). Reader relevance is implicit.

```
Stobo executes. Otterly monitors.
```

Two short declarative sentences. No hedging. No explanation needed. The contrast is clear.

```
Technical foundation determines 86% of AI citations.
```

Single claim. Single data point. No softening language. This is the type of opening that works in headers and topic sentences.

```
You're likely missing a 2.7x citation advantage. Your FAQ schema isn't optimized for AI crawlers.
```

Direct reader address in first sentence. Specific multiplier (2.7x, not "significant"). Named problem (FAQ schema) with clear barrier (AI crawler incompatibility).

## Vocabulary

### Use These Words

- citation rates
- technical foundation
- AI crawlers
- schema markup
- implementation
- barriers
- visibility
- executes
- methodology
- optimize
- methodology
- tested
- measured
- fixed
- scores
- lift
- audit
- extract
- crawlable
- factors

These words appear in your content consistently and carry specific meaning in your domain.

### Never Use These Words

- leverage
- harness
- seamless
- cutting-edge
- game-changer
- holistic
- robust
- delve
- comprehensive
- synergistic

These words are marketing filler. They make you sound generic and undermine your data-first credibility.

## AEO Requirements

### Citation Optimization

Structure every article to maximize AI extraction probability.

- Start with a direct answer in the first 40-60 words. AI crawlers prioritize opening content for citation.
- Add a TLDR within the first 100 words. Use bold for the key claim plus 2-3 specific takeaways.
- Include specific data points with sources. "Yext's analysis of 6.8 million citations" is more citable than "research shows."
- Avoid em dashes. They signal AI-generated content to crawlers and reduce extraction confidence.

### Structural Formatting

- Use H2/H3 headers every 100-150 words. This creates extraction breakpoints for AI systems.
- Limit paragraphs to 4 sentences maximum. Longer blocks reduce extraction precision.
- Use numbered lists for processes (step 1, 2, 3). Use bullet points for feature sets or non-sequential characteristics.
- Vary list lengths naturally. Don't force every list to three items. Some will be two, others five or more.

### Tone and Clarity

- Don't use exclamation points. Emphasis comes from word choice and structure, not punctuation.
- Don't bury the answer below the fold or behind long intros. Answer the question first. Add context after.
- Identify who did the testing or research. Write "We tested" or "Yext's analysis" instead of passive "Research shows."
- Use active voice and name the agent. "We found most sites score below 40/100" is stronger than "Most sites score below 40/100."

---

**Implementation Priority:**

Start with these changes immediately for highest impact:

1. Lead every article with a direct answer in 40-60 words. This fixes the buried-lede problem and improves both human readability and AI citation probability.
2. Name who did the testing and the exact number. Replace "Research shows" with "Yext's 6.8 million citation analysis proved." This builds authority and improves citation extraction.
3. Add a reader-direct sentence within the first three sentences. "Your FAQ schema is probably costing you 2.7x in citations" creates urgency and relevance faster than opening with rankings.
4. Remove all em dashes and replace with periods or conjunctions. This single change removes a major AI-generated-content signal.
5. Add implementation timelines to every process description. "Week three" or "16 days" signals the execution focus that defines your brand.