## 🔴 Critical Issue

### 1. Double-Close Bug in `open()` Exception Handler
In the `try/except` block of `open()`, if an exception occurs **after** `self._data_mm = data_mm` but **before** `data_mm = None`, both the local variable `data_mm` and the instance 
attribute `self._data_mm` reference the same `mmap.mmap` object.

The `except` handler then closes `data_mm` (local), and `_cleanup_open_handles()` subsequently closes `self._data_mm` again, causing a `ValueError: mmap closed or invalid` (or 
undefined behavior).

**Fix:** Nullify the instance attributes before calling cleanup, or check for identity:

```python
except Exception:
    # Avoid double-close by transferring ownership check
    if data_mm is not None and data_mm is not self._data_mm:
        data_mm.close()
    if meta_mm is not None and meta_mm is not self._meta_mm:
        meta_mm.close()
    # ... fd closing ...
    self._cleanup_open_handles()
    raise
```

---

## 🟡 High-Priority Improvements

### 2. Missing `fsync` for Wrap Markers (Durability Gap)
`_write_wrap_marker()` calls `mm.flush()` but does **not** call `os.fsync(self._data_fd)`. If `self.fsync_data` is enabled and the system crashes immediately after a wrap marker is 
written but before the next record's `fsync`, the wrap marker may not be durable on disk, leading to the reader seeing garbage at the end of the ring on recovery.

**Fix:** Accept `fsync` parameter or check `self.fsync_data` inside the method:
```python
def _write_wrap_marker(self, off: int) -> None:
    # ... existing code ...
    mm.flush(off, min(RECORD_HDR_SIZE, self.capacity - off))
    if self.fsync_data:
        os.fsync(self._data_fd)  # Add this
```

### 3. Metadata Write Amplification in `_make_space`
Every iteration of the `while` loop in `_make_space()` increments `s.commit` and potentially triggers `_write_meta()` (via the caller's logic or explicit calls). If the buffer is full 
and a large record is being inserted, this could write metadata dozens of times for a single `append()`.

**Fix:** Batch the metadata update:
```python
def _make_space(self, need: int) -> None:
    s = self._state
    original_commit = s.commit
    # ... loop logic without s.commit += 1 ...
    if s.commit != original_commit:
        self._write_meta(s)  # Write once at end
```

---

## 🟢 Architectural Observations

### 4. Recovery Scan Limit Edge Case Handling (✅ Fixed)
Your implementation correctly handles the case where `recover_scan_limit_bytes` is reached before `head`:
```python
if not truncated and scanned >= limit and off != s.head:
    s.head = last_good_off
```
This prevents exposing unvalidated tail data as valid records.

### 5. Type Safety (✅ Excellent)
The use of `Literal["wrap"] | Literal["rec"]` combined with `ParsedRecord` enables exhaustive type checking. Consider using `match`/`case` in consumers for structural pattern matching 
(Python 3.10+).

### 6. Data Integrity on Existing Files (✅ Good)
The check `if existing_data_size > 0 and self._data_mm[:DATA_START] != DATA_MAGIC` prevents accidental overwrite of non-ring files.

---

## 📝 Minor Suggestions

### 7. `close()` Idempotency
If `close()` raises an exception during `os.fsync` or `os.close`, subsequent calls to `close()` may fail or behave unexpectedly because `_state` is set to `None` at the end, but file 
descriptors might remain open if the exception occurred mid-function.

**Fix:** Use a `try/finally` or set state to `None` only after successful cleanup, or track closure with a separate boolean.

### 8. Constant Validation
Add a static assertion to ensure `DATA_MAGIC` length matches expectations:
```python
assert len(DATA_MAGIC) == 4, "DATA_MAGIC must be 4 bytes for u32 alignment"
```
This guards against future changes breaking `DATA_START` assumptions.

### 9. Iterator `from_seq` Optimization
`iter_records` currently reads every record from `tail` even if `from_seq` is much higher. For large buffers with high `from_seq`, this is O(n) wasted work.

**Fix:** Document this behavior, or add a binary search optimization if records were fixed-size (they're not, due to JSON), or accept that scanning is required for variable-length 
records.

### 10. Zero-Copy Optimization
In `export_jsonl`, you re-encode the JSON object. If the stored payload is trusted to be valid JSON, you could write the raw bytes directly (removing the trailing newline first if 
present):
```python
# Instead of re-encoding:
# raw_payload = mm[...] # Store raw bytes in ParsedRecord?
# f.write(raw_payload)
```
However, re-encoding ensures consistency with `json_dumps_kwargs`, so the current approach is safer.

---

## Summary

| Severity     | Issue                                          | Location               |
|--------------|------------------------------------------------|------------------------|
| **Critical** | Double-close on exception in `open()`          | `open()` except block  |
| **High**     | Wrap marker not fsync'd when `fsync_data=True` | `_write_wrap_marker()` |
| **Medium**   | Metadata write amplification in `_make_space`  | `_make_space()`        |
| **Low**      | `close()` not fully idempotent                 | `close()`              |

The code is otherwise robust, well-typed, and handles crash recovery correctly.
