# Code of Conduct

## The Entire Policy

Try to not be a cunt.

## Slightly Longer Version (because apparently we need one)

Be decent.

Don't harass people.
Don't be racist, sexist, homophobic, transphobic, or any other flavor of garbage human behavior
(unless is for a good joke and no hate is actually intended).

Don't bully, threaten, or act like GitHub comments are your personal therapy couch.

If you wouldn't say it face‑to‑face without getting escorted out of a pub, don't type it here.

## Enforcement

Maintainers may remove comments, issues, pull requests, or people who fail the very low bar described above.

This is not a democracy. This is a repo.

## TL;DR

Be kind. Ship code. Don't be a problem. In short: do not be a cunt.
