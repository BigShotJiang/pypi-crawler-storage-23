"""
Protocols for istari-digital-client.

This module contains protocol definitions used for structural typing.
"""

from istari_digital_client.protocol.pagelike import PageLike

__all__ = ["PageLike"]
