"""FastMCP Client Tests Package

This package contains all test files that use the FastMCP Client SDK
to test MCP server functionality via HTTP requests.
"""
