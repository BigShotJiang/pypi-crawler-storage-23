from starlette.middleware.base import BaseHTTPMiddleware

class SecurityMiddleware(BaseHTTPMiddleware):

    async def dispatch(self, request, call_next):
        pipeline = request.app.state.security_pipeline
        security_context = await pipeline.process_request(request)
        request.state.security = security_context
        return await call_next(request)
