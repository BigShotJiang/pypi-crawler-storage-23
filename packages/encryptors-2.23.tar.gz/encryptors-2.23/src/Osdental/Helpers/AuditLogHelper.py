import json
from typing import Dict, Literal, Any, Optional
from Osdental.Models.AuditConfig import AuditConfig
from Osdental.Models._SecurityContext import SecurityContext

class AuditLogHelper:
        
    @staticmethod
    async def build_request_payload(security: SecurityContext, audit_config: AuditConfig) -> Dict:
        default_value = '*'
        request = security.request  # FastAPI request
        graphql_request = security.gql_request  # GraphQLRequest
        token = security.token

        user_ip = request.headers.get("X-Forwarded-For")
        if user_ip:
            user_ip = user_ip.split(',')[0]
        else:
            user_ip = getattr(request.client, "host", "*")

        SAFE_HEADERS = {
            "user-agent",
            "host",
            "origin",
            "referer",
            "content-type"
        }

        headers = {k: v for k, v in request.headers.items() if k.lower() in SAFE_HEADERS}

        return {
            "idMessageLog": request.headers.get("Idmessagelog"),
            "environment": audit_config.environment,
            "header": json.dumps(headers),
            "microServiceUrl": str(request.url),
            "microServiceName": audit_config.microservice_name,
            "microServiceVersion": audit_config.microservice_version,
            "serviceName": graphql_request.operation_name,
            "machineNameUser": request.headers.get("Machinenameuser", default_value),
            "ipUser": user_ip or default_value,
            "userName": token.user_full_name,
            "localitation": default_value,
            "httpMethod": request.method,
            "messageIn": json.dumps(security.payload) if security.payload else default_value,
            "auditLog": "MESSAGE_LOG_INTERNAL"
        }
    
    @staticmethod
    def build_final_payload(
        type: Literal["RESPONSE", "ERROR"],
        status_code: Any,
        result: Optional[Any] = "*",
        error: Optional[Any] = "*"
    ):
        return {
            "type": type,
            "httpResponseCode": status_code,
            "messageOut": json.dumps(result) if isinstance(result, dict) else result,
            "errorProducer": error
        }
