from azure.identity.aio import DefaultAzureCredential
from azure.keyvault.secrets.aio import SecretClient
from Osdental.Shared.Logger import logger

class KeyVaultService:

    def __init__(self, vault_url: str):
        self._vault_url = vault_url
        self._credential = None
        self._client = None
        self._cache = {}

    async def connect(self):
        self._credential = DefaultAzureCredential()
        self._client = SecretClient(
            vault_url=self._vault_url,
            credential=self._credential
        )

    async def get_secret(self, name: str) -> str:
        if name in self._cache:
            return self._cache[name]

        try:
            secret = await self._client.get_secret(name)
            self._cache[name] = secret.value
            return secret.value
        except Exception:
            logger.exception("Error retrieving secret", extra={"secret": name})
            raise

    async def close(self):
        if self._client:
            await self._client.close()
        if self._credential:
            await self._credential.close()
