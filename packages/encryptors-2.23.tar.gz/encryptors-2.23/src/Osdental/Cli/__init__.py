import os
import sys
import subprocess
import platform
import click
from Osdental.Shared.Logger import logger
from Osdental.Shared.Enums.Message import Message


@click.group()
def cli():
    """Comandos personalizados para gestionar el proyecto."""
    pass

@cli.command()
def clean():
    """Borrar todos los __pycache__."""
    if platform.system() == 'Windows':
        subprocess.run('for /d /r . %d in (__pycache__) do @if exist "%d" rd /s/q "%d"', shell=True)
    else:
        subprocess.run("find . -name '__pycache__' -type d -exec rm -rf {} +", shell=True)

    logger.info(Message.PYCACHE_CLEANUP_SUCCESS_MSG)


@cli.command()
@click.argument('port')
def start(port: int):
    """Start the FastAPI server.."""
    try:
        subprocess.run(['uvicorn', 'app:app', '--port', str(port), '--reload'], check=True)
    except subprocess.CalledProcessError as e:
        logger.error(f'{Message.SERVER_NETWORK_ACCESS_ERROR_MSG}: {e}')


@cli.command()
@click.argument('port')
def serve(port: int):
    """Set up the FastAPI server accessible from any machine."""
    try:
        subprocess.run(['uvicorn', 'app:app', '--host', '0.0.0.0', '--port', str(port), '--reload'], check=True)
    except subprocess.CalledProcessError as e:
        logger.error(f'{Message.SERVER_NETWORK_ACCESS_ERROR_MSG}: {e}')


@cli.command("clean-redis")
@click.argument('redis_env')
async def clean_redis(redis_env: str):
    try:
        from Osdental.RedisCache.Redis import RedisCacheAsync
        redis_url = os.getenv(redis_env)
        if not redis_url:
            logger.warning(f'Environment variable not found: {redis_env}')
            return
        
        redis = RedisCacheAsync(redis_url=redis_url)
        await redis.flush()
        logger.info(Message.REDIS_CLEANUP_SUCCESS_MSG)
    except Exception as e:
        logger.error(f'{Message.REDIS_CLEANUP_ERROR_MSG}: {e}')


@cli.command(name='proto-files')
@click.argument('name')
def proto_files(name: str):
    proto_dir = os.path.join('src', 'Infrastructure', 'Grpc', 'Proto').replace('\\', '/')
    gen_dir = os.path.join('src', 'Infrastructure', 'Grpc', 'Generated').replace('\\', '/')

    proto_path = os.path.join(proto_dir, f'{name}.proto').replace('\\', '/')
    common_path = os.path.join(proto_dir, 'Common.proto').replace('\\', '/')

    common_py = os.path.join(gen_dir, 'Common_pb2.py').replace('\\', '/')
    common_grpc_py = os.path.join(gen_dir, 'Common_pb2_grpc.py').replace('\\', '/')

    proto_files = [proto_path]
    if not (os.path.exists(common_py) and os.path.exists(common_grpc_py)):
        proto_files.append(common_path)

    cmd = [
        sys.executable, "-m", "grpc_tools.protoc",
        f"-I={proto_dir}",
        f"--python_out={gen_dir}",
        f"--grpc_python_out={gen_dir}",
        *proto_files
]

    subprocess.run(cmd, shell=False, check=True)
    logger.info(Message.PROTO_FILES_GENERATED_MSG)



@cli.command('run-server')
@click.option('--host', default="0.0.0.0", help='Host where to set up the server')
@click.option('--port', default=5000, help='Server port')
@click.option('--workers', default=4, help='Number of workers')
def run_server(host, port, workers):
    """
        Launch the application with uvicorn on Windows or gunicorn on other systems
        :host
        :port
        :workers
    """
    if sys.platform.startswith('win'):
        cmd = [
            sys.executable, '-m', 'uvicorn',
            'app:app',
            '--host', host,
            '--port', str(port),
            '--workers', str(workers)
        ]
    else:
        cmd = [
            sys.executable, '-m', 'gunicorn',
            'app:app',
            '-k', 'uvicorn.workers.UvicornWorker',
            '--bind', f'{host}:{port}',
            '--workers', str(workers)
        ]
    
    logger.info(f'Running: {' '.join(cmd)}')
    subprocess.run(cmd)
    
if __name__ == "__main__":
    cli()
