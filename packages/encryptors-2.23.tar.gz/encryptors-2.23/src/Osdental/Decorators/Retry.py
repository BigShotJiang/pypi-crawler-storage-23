from functools import wraps
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception
import grpc
import httpx


# gRPC
def _is_retryable_grpc_error(exception: grpc.RpcError):
    return exception.code() in (
        grpc.StatusCode.UNAVAILABLE,
        grpc.StatusCode.DEADLINE_EXCEEDED,
        grpc.StatusCode.RESOURCE_EXHAUSTED,
    )


def grpc_retry(func):
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=4),
        retry=retry_if_exception(_is_retryable_grpc_error),
        reraise=True
    )
    @wraps(func)
    async def wrapper(*args, **kwargs):
        return await func(*args, **kwargs)
    return wrapper



# REST
def _is_retryable_http_error(exception: Exception):
    if isinstance(exception, httpx.RequestError):
        return True
    
    if isinstance(exception, httpx.HTTPStatusError):
        return exception.response.status_code in (502, 503, 504)
    
    return False


def rest_retry(func):
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=4),
        retry=retry_if_exception(_is_retryable_http_error),
        reraise=True
    )
    @wraps(func)
    async def wrapper(*args, **kwargs):
        return await func(*args, **kwargs)
    return wrapper
