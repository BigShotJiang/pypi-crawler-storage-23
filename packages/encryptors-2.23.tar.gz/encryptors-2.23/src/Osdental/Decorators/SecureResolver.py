import inspect
import asyncio
from functools import wraps
from typing import Callable, Dict, Any, Iterable
from graphql import GraphQLResolveInfo
from Osdental.Shared.Enums.Profile import Profile
from Osdental.Models.Response import Response
from Osdental.Encryptor.Aes import AES
from Osdental.Models._SecurityContext import SecurityContext
from Osdental.Exception.ControlledException import OSDException, UnauthorizedException

def _encrypt_if_needed(result: Response, security: SecurityContext) -> Response:
    if result.data is not None and security.encryptor:
        result.data = AES.encrypt(security.encryptor.aes_auth, result.data)

    return result

def secure_resolver(allowed_roles: Iterable[str] | None = None):
    def decorator(func: Callable):

        signature = inspect.signature(func)
        accepts_data = "data" in signature.parameters

        @wraps(func)
        async def wrapper(obj: Any, info: GraphQLResolveInfo, **rest_kwargs: Dict):
            try:
                security: SecurityContext = info.context.security
                token = security.token

                if allowed_roles:
                    if Profile(token.abbreviation) not in allowed_roles:
                        raise UnauthorizedException()

                if not security.encryptor or not token:
                    raise ValueError("Security infrastructure not available in the context.")

                # Solo inyectar si el resolver lo espera
                if accepts_data:
                    payload = getattr(security, "payload", None)
                    if payload:
                        rest_kwargs["data"] = payload

                result: Response = await func(obj, info, **rest_kwargs)
                result = _encrypt_if_needed(result, security)

                _ = asyncio.create_task(
                    info.context.audit_dispatcher.dispatch(
                        security=security,
                        result=result
                    )
                )

                return result.send()

            except (Exception, OSDException) as e:
                result = Response(
                    status=getattr(e, "status_code", "DB_ERROR_UNEXPECTED"),
                    message=getattr(e, "message", "Could not process request."),
                    error=getattr(e, "error", type(e).__name__),
                    data=None
                )

                _ = asyncio.create_task(
                    info.context.audit_dispatcher.dispatch(
                        security=security,
                        result=result
                    )
                )

                return result.send()

        return wrapper
    return decorator