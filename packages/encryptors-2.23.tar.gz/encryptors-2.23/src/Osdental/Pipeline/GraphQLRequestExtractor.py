import json
from graphql import parse
from Osdental.Models._SecurityContext import GraphQLRequest

class GraphQLRequestExtractor:

    async def extract(self, request) -> GraphQLRequest:
        body_bytes = await request.body()

        try:
            json_body = json.loads(body_bytes.decode())
        except Exception:
            json_body = {}

        query_string = json_body.get("query", "")
        operation_name = json_body.get("operationName", "UnknownOperation")
        variables = json_body.get("variables", {})

        operation_type = "query"

        try:
            ast = parse(query_string)
            operation = next(
                (d for d in ast.definitions if hasattr(d, "operation")),
                None
            )
            if operation:
                operation_type = operation.operation.value
        except Exception:
            pass

        return GraphQLRequest(
            operation_name=operation_name,
            operation_type=operation_type,
            variables=variables
        )
