from uuid import UUID
from typing import Dict
from graphql import OperationType
from Osdental.Encryptor.Aes import AES
from Osdental.Shared.Enums.Profile import Profile
from Osdental.Models.Token import AuthToken

class TenantPolicy:

    def resolve(self, token: AuthToken, headers, decrypted_payload: Dict, operation_type: str):
        # Solo aplicamos cambios si es QUERY
        if operation_type != OperationType.QUERY.value:
            return token  # devolver token tal cual

        # SUPER ADMIN / OSDEL ADMIN -> UUID 0
        if token.abbreviation.startswith((Profile.SUPER_ADMIN, Profile.ADMIN_OSD)):
            token.id_external_enterprise = str(UUID(int=0))
            return token

        # Marketing -> tomar dynamicClientId del header
        if token.abbreviation.startswith(Profile.MARKETING):
            dynamic_client_id = headers.get("dynamicClientId")
            if dynamic_client_id:
                decrypted_mk_id = AES.decrypt(token.aes_key_auth, dynamic_client_id)
                token.id_external_enterprise = decrypted_mk_id
                token.mk_id_external_enterprise = decrypted_mk_id
                return token

        # If it comes by request, it is taken as priority
        external_enterprise_req = decrypted_payload.get('idExternalEnterprise')
        if external_enterprise_req and token:
            token.id_external_enterprise = external_enterprise_req

        return token
