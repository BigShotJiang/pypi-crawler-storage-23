from Osdental.Pipeline.TokenService import TokenService
from Osdental.Pipeline.TenantPolicy import TenantPolicy
from Osdental.Pipeline.GraphQLPayloadService import GraphQLPayloadService
from Osdental.Pipeline.GraphQLRequestExtractor import GraphQLRequestExtractor
from Osdental.Models._SecurityContext import SecurityContext


class SecurityPipeline:
    def __init__(
        self, 
        token_service: TokenService, 
        tenant_policy: TenantPolicy, 
        payload_service: GraphQLPayloadService,
        request_extractor: GraphQLRequestExtractor
    ):
        self._token_service = token_service
        self._tenant_policy = tenant_policy
        self._payload_service = payload_service
        self._request_extractor = request_extractor

    async def process_request(self, request):
        # Extraer request GraphQL una sola vez
        gql_request = await self._request_extractor.extract(request)

        # Desencriptar payload
        encryptor = getattr(request.app.state, "encryptor", None)
        decrypted_payload = self._payload_service.decrypt(
            gql_request,
            encryptor
        )

        # Autenticar token original
        original_token = await self._token_service.authenticate(request)

        # Aplicar reglas de tenant (mutar token si corresponde)
        token = self._tenant_policy.resolve(
            token=original_token,
            headers=request.headers,
            decrypted_payload=decrypted_payload,
            operation_type=gql_request.operation_type
        )

        # Construir SecurityContext
        return SecurityContext(
            request=request,
            token=token,
            encryptor=getattr(request.app.state, "encryptor", None),
            payload=decrypted_payload,
            gql_request=gql_request
        )