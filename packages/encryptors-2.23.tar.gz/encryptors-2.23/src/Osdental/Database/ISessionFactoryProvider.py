from abc import ABC, abstractmethod
from Osdental.Models.ShardResource import DatabaseData

class ISessionFactoryProvider(ABC):

    @abstractmethod
    async def get(self, db: DatabaseData):
        pass
