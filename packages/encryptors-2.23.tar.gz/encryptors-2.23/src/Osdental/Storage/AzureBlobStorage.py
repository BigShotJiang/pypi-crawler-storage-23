from azure.storage.blob.aio import BlobServiceClient
from azure.core.exceptions import ResourceNotFoundError, AzureError
from typing import Optional
from Osdental.Storage import IStorageService
from Osdental.Shared.Logger import logger
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from azure.storage.blob.aio import BlobServiceClient

@asynccontextmanager
async def lifespan(app: FastAPI):
    retry_policy = RetryPolicy(retry_total=5)

    blob_client = BlobServiceClient.from_connection_string(
        settings.AZURE_CONN_STR,
        retry_policy=retry_policy
    )

    app.state.blob_client = blob_client

    yield

    await blob_client.close()

app = FastAPI(lifespan=lifespan)

"""

class AzureBlobStorage(IStorageService):

    def __init__(self, client: BlobServiceClient, container_name: str):
        self._client = client
        self._container = client.get_container_client(container_name)

    async def upload(self, blob_name: str, data: bytes) -> str:
        try:
            blob_client = self._container.get_blob_client(blob_name)

            await blob_client.upload_blob(
                data,
                overwrite=True,
                max_concurrency=4
            )

            return blob_client.url

        except AzureError:
            logger.exception("Blob upload failed", extra={"blob_name": blob_name})
            raise

    async def download(self, blob_name: str) -> Optional[bytes]:
        try:
            blob_client = self._container.get_blob_client(blob_name)
            stream = await blob_client.download_blob()
            return await stream.readall()

        except ResourceNotFoundError:
            return None

        except AzureError:
            logger.exception("Blob download failed", extra={"blob_name": blob_name})
            raise

    async def delete(self, blob_name: str) -> bool:
        try:
            blob_client = self._container.get_blob_client(blob_name)
            await blob_client.delete_blob()
            return True

        except ResourceNotFoundError:
            return False

        except AzureError:
            logger.exception("Blob delete failed", extra={"blob_name": blob_name})
            raise

    async def close(self):
        await self._client.close()
