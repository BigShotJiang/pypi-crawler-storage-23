"""Blog models for Aptpath and internship blog content."""
from django.db import models
from ckeditor.fields import RichTextField

from .base import BaseModelProfile


class AptpathBlogType(BaseModelProfile):
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'aptpath_blog_type'

    def __str__(self):
        return self.name


class AptpathBlog(BaseModelProfile):
    name = models.CharField(max_length=255, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    source_image_url = models.FileField(null=True, blank=True)
    mentor = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    category = models.CharField(max_length=255, null=True, blank=True)
    blog_type = models.ForeignKey(AptpathBlogType, on_delete=models.CASCADE, null=True, blank=True)

    class Meta:
        db_table = 'aptpath_blog'

    def __str__(self):
        return self.name


class AptpathBlogContent(BaseModelProfile):
    blog = models.ForeignKey(AptpathBlog, on_delete=models.CASCADE, related_name='contents')
    image_url = models.FileField(null=True, blank=True)
    position = models.IntegerField(null=True, blank=True)
    content = RichTextField(null=True, blank=True)

    class Meta:
        db_table = 'aptpath_blog_content'

    def __str__(self):
        return self.blog.name


class BlogType(BaseModelProfile):
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField(blank=True, null=True)

    class Meta:
        db_table = 'blog_type'

    def __str__(self):
        return self.name


class Blog(BaseModelProfile):
    name = models.CharField(max_length=255, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    source_image_url = models.FileField(null=True, blank=True)
    mentor = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    category = models.CharField(max_length=255, null=True, blank=True)
    blog_type = models.ForeignKey(BlogType, on_delete=models.CASCADE, null=True, blank=True)

    class Meta:
        db_table = 'blog'

    def __str__(self):
        return self.name


class BlogContent(BaseModelProfile):
    blog = models.ForeignKey(Blog, on_delete=models.CASCADE, related_name='contents')
    image_url = models.FileField(null=True, blank=True)
    position = models.IntegerField(null=True, blank=True)
    content = RichTextField(null=True, blank=True)

    class Meta:
        db_table = 'blog_content'

    def __str__(self):
        return self.blog.name
