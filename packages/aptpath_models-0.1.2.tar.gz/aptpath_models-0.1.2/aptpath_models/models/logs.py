"""Operation log models for all user types."""
from django.db import models
from django.utils import timezone


class OperationLog(models.Model):
    ACTION_CHOICES = (
        ('C', 'Create'),
        ('U', 'Update'),
        ('D', 'Delete'),
        ('M', 'Modify'),
    )

    user = models.ForeignKey(
        'aptpath_models.MongoUser', on_delete=models.SET_NULL, null=True)
    timestamp = models.DateTimeField(default=timezone.now)
    action = models.CharField(max_length=1, choices=ACTION_CHOICES)
    model_name = models.CharField(max_length=100)
    model_id = models.PositiveIntegerField()

    class Meta:
        db_table = 'operations_log'


class OperationLogEmployer(models.Model):
    ACTION_CHOICES = (
        ('C', 'Create'),
        ('U', 'Update'),
        ('D', 'Delete'),
        ('M', 'Modify'),
    )

    user = models.ForeignKey(
        'aptpath_models.MongoEmployer', on_delete=models.SET_NULL, null=True)
    timestamp = models.DateTimeField(default=timezone.now)
    action = models.CharField(max_length=1, choices=ACTION_CHOICES)
    model_name = models.CharField(max_length=100)
    model_id = models.PositiveIntegerField()

    class Meta:
        db_table = 'operations_log_employer'


class OperationLogCollege(models.Model):
    ACTION_CHOICES = (
        ('C', 'Create'),
        ('U', 'Update'),
        ('D', 'Delete'),
        ('M', 'Modify'),
    )

    college_user = models.ForeignKey(
        'aptpath_models.College', on_delete=models.SET_NULL, null=True)
    timestamp = models.DateTimeField(default=timezone.now)
    action = models.CharField(max_length=1, choices=ACTION_CHOICES)
    model_name = models.CharField(max_length=100)
    model_id = models.PositiveIntegerField()

    class Meta:
        db_table = 'operations_log_college'


class OperationLogAptpathAdmin(models.Model):
    ACTION_CHOICES = (
        ('C', 'Create'),
        ('U', 'Update'),
        ('D', 'Delete'),
        ('M', 'Modify'),
    )

    aptpathadmin_user = models.ForeignKey(
        'aptpath_models.AptPathAdmin', on_delete=models.SET_NULL, null=True)
    timestamp = models.DateTimeField(default=timezone.now)
    action = models.CharField(max_length=1, choices=ACTION_CHOICES)
    model_name = models.CharField(max_length=100)
    model_id = models.PositiveIntegerField()

    class Meta:
        db_table = 'operations_log_aptpathadmin'
