"""LMS partner, course, enrollment payment and progress tracking models."""
from django.db import models

from .base import BaseModelProfile, GenericModel


class LearningManagementSystemPartner(GenericModel):
    name = models.CharField(max_length=255)
    courses_count = models.IntegerField(default=0)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'lms-partner'


class AiCertsCategory(models.Model):
    name = models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'ai_certs_category'


class AicertsNewsletter(models.Model):
    email = models.EmailField(unique=True, verbose_name='ai_certs_email', max_length=255)

    def __str__(self):
        return self.email

    class Meta:
        db_table = 'ai_certs_newsletter'


class LMSCourse(GenericModel):
    name = models.CharField(max_length=250, null=True, blank=True)
    course_url = models.TextField(null=True, blank=True)
    course_logo_url = models.FileField(null=True, blank=True)
    ai_certs_logo_url = models.FileField(null=True, blank=True)
    lms_course_id = models.IntegerField(blank=True, null=True)
    course_about = models.TextField(null=True, blank=True)
    course_rating = models.IntegerField(null=True, blank=True, default=0)
    course_level = models.CharField(null=True, blank=True, max_length=100)
    course_skills = models.ManyToManyField('aptpath_models.MongoSkill', null=True, blank=True)
    paid = models.BooleanField(default=False)
    amount = models.IntegerField(default=0)
    discount = models.IntegerField(default=0)
    lms_partner = models.ForeignKey(
        LearningManagementSystemPartner, on_delete=models.CASCADE, null=True, blank=True)
    course_data = models.JSONField(null=True, blank=True)
    order = models.IntegerField(null=True, blank=True)
    project = models.ManyToManyField('aptpath_models.Internship', blank=True)
    liked_by_users = models.ManyToManyField(
        'aptpath_models.Profile', blank=True, null=True, related_name='liked_courses')
    labs = models.ManyToManyField('aptpath_models.Lab', blank=True)
    tech_stack = models.ManyToManyField('aptpath_models.TechnologyStack', blank=True)
    skill_builder = models.ForeignKey(
        'aptpath_models.SkillBuilder', on_delete=models.SET_NULL, null=True, blank=True)
    categories = models.ManyToManyField(
        AiCertsCategory, blank=True, null=True, related_name='ai_certs_courses')
    webinar = models.BooleanField(default=False)
    rating = models.FloatField(default=0.0)
    rating_count = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.name}"

    class Meta:
        db_table = 'lms-course'


class CourseEnrollmentPaymentDetails(GenericModel):
    STATUS_CHOICES = (
        ('successfull', 'Successfull'),
        ('pending', 'Pending'),
        ('failed', 'Failed'),
    )

    user = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)
    lms_user_id = models.IntegerField(default=0)
    lms_course_id = models.CharField(max_length=100, default='', null=True)
    course = models.ForeignKey(LMSCourse, on_delete=models.CASCADE, null=True, blank=True)
    order_id = models.CharField(max_length=250, default='', null=True)
    payment_id = models.CharField(max_length=250, default='', null=True)
    signature = models.TextField(default='', null=True, blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    payment_status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    enrolment_key = models.CharField(max_length=255, null=True, blank=True)
    lms_partner = models.ForeignKey(
        LearningManagementSystemPartner, on_delete=models.CASCADE, null=True, blank=True)

    class Meta:
        db_table = 'course-enrollment-payment-details'


class UserCourseStatus(BaseModelProfile):
    STATUS_CHOICES = [
        ('in_progress', 'In Progress'),
        ('completed', 'Completed'),
        ('not_started', 'Not Started'),
    ]

    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, blank=True, null=True)
    course = models.ForeignKey(LMSCourse, on_delete=models.CASCADE, blank=True, null=True)
    modules_completed = models.IntegerField(blank=True, null=True)
    total_modules = models.IntegerField(blank=True, null=True)
    last_visited = models.DateTimeField(null=True, blank=True)
    course_status = models.CharField(
        max_length=20, choices=STATUS_CHOICES, default='not_started')

    def __str__(self):
        return f"{self.profile.email} - {self.course.name} - {self.course_status}"

    class Meta:
        unique_together = ('profile', 'course')
        db_table = 'lms-course-progress'


class AICertsContactUs(models.Model):
    name = models.CharField(max_length=100, null=True, blank=True)
    email = models.EmailField(null=True, blank=True)
    phone = models.CharField(max_length=20, null=True, blank=True)
    subject = models.CharField(max_length=200, null=True, blank=True)
    message = models.TextField(null=True, blank=True)
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.subject}"

    class Meta:
        db_table = 'ai-certs-contactus'


class LMSCountryPrices(models.Model):
    country = models.CharField(max_length=100)
    tier = models.CharField(max_length=20)
    price_one = models.DecimalField(max_digits=10, decimal_places=2)
    price_two = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    price_three = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    def __str__(self):
        return f"{self.country} ({self.tier})"

    class Meta:
        db_table = 'lms-country-prices'


class LMSStates(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'lms-states'


class InternshipSuggestedCourses(GenericModel):
    project = models.ForeignKey(
        'aptpath_models.Internship', on_delete=models.CASCADE, null=True, blank=True)
    courses = models.ManyToManyField(LMSCourse, blank=True)

    class Meta:
        db_table = 'internship_suggested_courses'
