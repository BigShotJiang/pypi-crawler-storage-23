"""Company, employment, invitation, notification and activity models."""
import uuid

from django.db import models
from django.contrib.auth.models import Group

from .base import BaseModelEmployer


class Company(BaseModelEmployer):
    name = models.CharField(max_length=250, verbose_name='name')
    description = models.TextField(max_length=3000, null=True, blank=True)
    employment = models.ManyToManyField(
        'aptpath_models.Employment', related_name='employment', blank=True)
    company_logo = models.FileField(blank=True)
    company_banner = models.FileField(blank=True)
    email = models.EmailField(unique=True, verbose_name='Email', max_length=255)
    address = models.CharField(max_length=250, null=True, blank=True)
    state = models.CharField(max_length=150, null=True, blank=True)
    city = models.CharField(max_length=150, null=True, blank=True)
    linkedin_url = models.URLField(null=True, blank=True)
    website_url = models.URLField(null=True, blank=True)
    phone_no = models.CharField(max_length=20, null=True, blank=True)
    company_size = models.CharField(max_length=500, null=True, blank=True)
    industry = models.CharField(max_length=500, null=True, blank=True)
    country = models.CharField(max_length=500, null=True, blank=True)

    def __str__(self):
        return f"{self.name} - {self.email}"

    class Meta:
        db_table = 'company'


class Employment(BaseModelEmployer):
    company = models.ForeignKey(
        Company, on_delete=models.CASCADE, related_name='company', null=True, blank=True)
    user = models.ForeignKey(
        'aptpath_models.MongoEmployer', on_delete=models.CASCADE, null=True, blank=True)
    role = models.ManyToManyField(Group, blank=True)

    def __str__(self):
        if self.user:
            roles = ', '.join(role.name for role in self.role.all())
            return f"{self.user.email} - {roles}"
        return ''

    class Meta:
        db_table = 'employment'
        unique_together = ['user']


class Invitation(BaseModelEmployer):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
        ('archived', 'Archived'),
    )

    email = models.EmailField()
    inviter = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.SET_NULL, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    invitation_code = models.UUIDField(unique=True, default=uuid.uuid4)
    company = models.ForeignKey(Company, on_delete=models.CASCADE, null=True, blank=True)
    registered = models.BooleanField(default=False)

    def __str__(self):
        return f"Invitation to {self.email}"

    class Meta:
        db_table = 'invitations'


class Notification(BaseModelEmployer):
    description = models.TextField()
    is_unread = models.BooleanField(default=True)
    title = models.CharField(max_length=255)
    type = models.CharField(max_length=100)
    user = models.ForeignKey('aptpath_models.MongoEmployer', on_delete=models.CASCADE)

    def __str__(self):
        return self.title

    class Meta:
        db_table = 'notifications'


class Activity(BaseModelEmployer):
    name = models.CharField(max_length=255)
    description = models.TextField()

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'activity'


class EmployerInvitationLog(BaseModelEmployer):
    STATUS_CHOICES = (
        ('Success', 'Success'),
        ('Failed', 'Failed'),
    )

    employer = models.ForeignKey(
        'aptpath_models.MongoEmployer', on_delete=models.CASCADE, null=True)
    email = models.CharField(max_length=50, null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)
    message = models.TextField(blank=True)

    def __str__(self):
        return f"{self.email} - {self.message}"

    class Meta:
        db_table = 'employer_invitation_logs'
