"""
Neo4j graph node definitions using neomodel.
Install: pip install neomodel
These nodes mirror Django ORM models in a graph database.
"""
try:
    from neomodel import (
        StructuredNode, StringProperty, IntegerProperty,
        UniqueIdProperty, RelationshipTo, RelationshipFrom,
    )
except ImportError:
    raise ImportError(
        "neomodel is required for Neo4j support. "
        "Install it with: pip install neomodel"
    )


class NeoCollege(StructuredNode):
    name = StringProperty(unique_index=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    job = RelationshipTo('Job', 'JOB_COLLEGES')
    learner = RelationshipTo('Learner', 'COLLEGE_USER')


class AccountType(StructuredNode):
    name = StringProperty(unique_index=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    learner = RelationshipTo('Learner', 'LEARNER')
    employer = RelationshipTo('Employer', 'EMPLOYER')


class Skill(StructuredNode):
    name = StringProperty(unique_index=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    skills = RelationshipFrom('Learner', 'SKILLED_IN')
    job = RelationshipFrom('Job', 'HAS_SKILL')
    course = RelationshipFrom('NeoCourse', 'SKILLS_NEEDED')


class Job(StructuredNode):
    name = StringProperty(unique_index=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    employer = RelationshipFrom('Employer', 'EMPLOYER_JOB_POSTED')
    category = RelationshipTo('Category', 'HAS_CATEGORY')
    skill = RelationshipTo('Skill', 'HAS_SKILL')
    applications = RelationshipTo('Application', 'JOB_APPLIED')
    learner = RelationshipFrom('Learner', 'JOB_LIKED')
    learning_path = RelationshipTo('LearningPathNeo', 'LEARNING_PATH_JOB')
    company = RelationshipFrom('NeoCompany', 'COMPANY_JOBS')
    college = RelationshipFrom('NeoCollege', 'JOB_COLLEGES')


class NeoCourse(StructuredNode):
    name = StringProperty()
    mongo_id = StringProperty(unique_index=True)
    course_keywords = RelationshipTo('Skill', 'SKILLS_NEEDED')
    node_env = StringProperty()
    learning_path = RelationshipFrom('LearningPathNeo', 'LEARNING_PATH')
    learner = RelationshipFrom('Learner', 'COURSE_ENROLLED')
    course_liked = RelationshipFrom('Learner', 'COURSE_LIKED')
    follow_category = RelationshipTo('Category', 'FOLLOWS_CATEGORY_COURSE')
    learning_path_module = RelationshipFrom('LearningPathModuleNeo', 'LEARNING_PATH_COURSE')


class Learner(StructuredNode):
    name = StringProperty(required=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    skills = RelationshipTo('Skill', 'SKILLED_IN')
    job_liked = RelationshipTo('Job', 'JOB_LIKED')
    follow_companies = RelationshipTo('NeoCompany', 'FOLLOWS_COMPANY')
    follow_category = RelationshipTo('Category', 'FOLLOWS_CATEGORY')
    educations = RelationshipTo('Education', 'COMPLETED_EDUCATION')
    certificate = RelationshipTo('Certificate', 'CERTIFIED_IN')
    experience = RelationshipTo('Experience', 'WORKED_AT')
    applications = RelationshipTo('Application', 'APPLIED_TO')
    account_type = RelationshipFrom('AccountType', 'LEARNER')
    course = RelationshipTo('NeoCourse', 'COURSE_ENROLLED')
    course_liked = RelationshipTo('NeoCourse', 'COURSE_LIKED')
    college = RelationshipFrom('NeoCollege', 'COLLEGE_USER')


class LearningPathNeo(StructuredNode):
    name = StringProperty(unique_index=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    course = RelationshipTo('NeoCourse', 'LEARNING_PATH')
    job = RelationshipFrom('Job', 'LEARNING_PATH_JOB')
    learning_path_module = RelationshipTo('LearningPathModuleNeo', 'LEARNING_PATH_MODULE')


class Employer(StructuredNode):
    name = StringProperty(required=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    job = RelationshipTo('Job', 'EMPLOYER_JOB_POSTED')
    account_type = RelationshipFrom('AccountType', 'EMPLOYER')
    learner = RelationshipFrom('Learner', 'FOLLOWS_COMPANY')
    emp_company = RelationshipTo('NeoCompany', 'IN_COMPANY')


class NeoCompany(StructuredNode):
    name = StringProperty(required=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    user = RelationshipFrom('Learner', 'FOLLOWS_COMPANY')
    employer = RelationshipFrom('Employer', 'IN_COMPANY')
    job = RelationshipTo('Job', 'COMPANY_JOBS')


class Category(StructuredNode):
    name = StringProperty(unique_index=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    job = RelationshipFrom('Job', 'HAS_CATEGORY')
    learner = RelationshipFrom('Learner', 'FOLLOWS_CATEGORY')
    course = RelationshipFrom('NeoCourse', 'FOLLOWS_CATEGORY_COURSE')


class Education(StructuredNode):
    name = StringProperty(unique_index=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    learner = RelationshipFrom('Learner', 'COMPLETED_EDUCATION')


class Certificate(StructuredNode):
    name = StringProperty(unique_index=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    learner = RelationshipFrom('Learner', 'CERTIFIED_IN')


class Experience(StructuredNode):
    name = StringProperty(unique_index=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    learner = RelationshipFrom('Learner', 'WORKED_AT')


class Application(StructuredNode):
    name = StringProperty(unique_index=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    learner = RelationshipFrom('Learner', 'APPLIED_TO')
    job = RelationshipFrom('Job', 'JOB_APPLIED')


class AptpathTestsNeo(StructuredNode):
    name = StringProperty(unique_index=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    learning_path_module = RelationshipFrom('LearningPathModuleNeo', 'LEARNING_PATH_TESTS')


class ActivityNeo(StructuredNode):
    name = StringProperty(unique_index=True)
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    learning_path_module = RelationshipFrom('LearningPathModuleNeo', 'LEARNING_PATH_ACTIVITY')


class LearningPathModuleNeo(StructuredNode):
    name = StringProperty()
    mongo_id = StringProperty(unique_index=True)
    node_env = StringProperty()
    course = RelationshipTo('NeoCourse', 'LEARNING_PATH_COURSE')
    test = RelationshipTo('AptpathTestsNeo', 'LEARNING_PATH_TESTS')
    activity = RelationshipTo('ActivityNeo', 'LEARNING_PATH_ACTIVITY')
    learning_path = RelationshipFrom('LearningPathNeo', 'LEARNING_PATH_MODULE')
