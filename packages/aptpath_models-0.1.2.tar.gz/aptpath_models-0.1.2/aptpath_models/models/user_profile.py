"""User education, experience and certificate records."""
from django.db import models

from .base import BaseModel


class UserEducation(BaseModel):
    college = models.CharField(max_length=150, null=True, blank=True)
    department = models.CharField(max_length=150, null=True, blank=True)
    degree_name = models.CharField(max_length=150, null=True, blank=True)
    year_of_start = models.DateField(null=True, blank=True)
    course_start_date = models.DateField(null=True, blank=True)
    course_end_date = models.DateField(null=True, blank=True)
    present = models.BooleanField(default=False, null=True, blank=True)
    country = models.CharField(max_length=150, null=True, blank=True)
    state = models.CharField(max_length=150, null=True, blank=True)
    city = models.CharField(max_length=150, null=True, blank=True)
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.CASCADE, null=True, blank=True)

    class Meta:
        db_table = 'education'


class UserExperience(BaseModel):
    EMPLOYMENT_TYPE_CHOICES = (
        ('full_time', 'FullTime'),
        ('part_time', 'PartTime'),
        ('contract', 'Contract'),
    )

    employment_type = models.CharField(
        max_length=20, choices=EMPLOYMENT_TYPE_CHOICES, default='full_time')
    role_name = models.CharField(max_length=150, null=True, blank=True)
    company_name = models.CharField(max_length=150, null=True, blank=True)
    start_date = models.DateField()
    end_date = models.DateField(null=True, blank=True)
    city = models.CharField(max_length=150, null=True, blank=True)
    state = models.CharField(max_length=150, null=True, blank=True)
    country = models.CharField(max_length=150)
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.SET_NULL, null=True)
    present = models.BooleanField(default=False)
    description = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.role_name} - {self.company_name} - {self.profile}"

    class Meta:
        db_table = 'experience'


class UserCertificate(BaseModel):
    title = models.CharField(max_length=150, blank=True, null=True)
    url = models.URLField(max_length=500, null=True, blank=True)
    file = models.FileField(blank=True, null=True)
    profile = models.ForeignKey(
        'aptpath_models.Profile', on_delete=models.SET_NULL, null=True)
    issued_by = models.CharField(max_length=150, blank=True, null=True)

    def __str__(self):
        return f"{self.title} - {self.profile} - {self.issued_by}"

    class Meta:
        db_table = 'certificate'
