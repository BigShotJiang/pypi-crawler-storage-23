"""Moodle-backed courses, LMS systems and user-course completion tracking."""
from django.db import models
from django.utils import timezone

from .base import BaseModel, BaseModelEmployer


class LMSSystem(BaseModelEmployer):
    name = models.CharField(max_length=100)
    client_id = models.CharField(max_length=500, null=True, blank=True)
    secret_key = models.CharField(max_length=500, null=True, blank=True)
    lms_host = models.CharField(max_length=1000, null=True, blank=True)
    auth_token = models.CharField(max_length=1000, null=True, blank=True)
    company = models.ForeignKey(
        'aptpath_models.Company', on_delete=models.CASCADE, null=True, blank=True)
    account_id = models.IntegerField(null=True, blank=True)
    lms_logo = models.FileField(upload_to='lms_logo/', blank=True, null=True)

    def __str__(self):
        if self.company:
            return f"{self.name}{self.company.name}"
        return self.name

    class Meta:
        db_table = 'lms_system'


class MongoCourse(BaseModelEmployer):
    category_id = models.ForeignKey(
        'aptpath_models.MongoCategories',
        on_delete=models.SET_NULL, null=True, blank=True, default=None)
    moodle_course_id = models.IntegerField(null=True, blank=True)
    course_name = models.CharField(null=True, blank=True, max_length=100)
    course_url = models.TextField(null=True, blank=True)
    course_level = models.CharField(null=True, blank=True, max_length=100)
    course_logo = models.FileField(upload_to='course_images/', null=True, blank=True)
    course_duration = models.IntegerField(null=True, blank=True)
    course_about = models.TextField(null=True, blank=True)
    course_rating = models.IntegerField(null=True, blank=True, default=0)
    course_keywords = models.ManyToManyField('aptpath_models.MongoSkill', null=True, blank=True)
    course_lms = models.ForeignKey(
        LMSSystem, on_delete=models.SET_NULL, null=True, blank=True, default=None)
    num_lectures = models.IntegerField(null=True, blank=True)
    num_videos = models.IntegerField(null=True, blank=True)
    lms_course_image_url = models.URLField(null=True, blank=True)
    instructor = models.CharField(null=True, blank=True, max_length=150)
    lms_course_id = models.IntegerField(unique=True, blank=True, null=True)

    def __str__(self):
        return f"{self.id} - {self.course_name} - {self.created_by}"

    class Meta:
        db_table = 'courses'


class HiddenCourses(BaseModel):
    user = models.ForeignKey('aptpath_models.MongoUser', on_delete=models.SET_NULL, null=True)
    course = models.ForeignKey(MongoCourse, on_delete=models.SET_NULL, null=True)

    class Meta:
        db_table = 'hidden-courses'


class UserCourseCompletion(BaseModel):
    user = models.ForeignKey('aptpath_models.MongoUser', on_delete=models.SET_NULL, null=True)
    lms_course_id = models.IntegerField(blank=True, null=True)
    modules_completed = models.IntegerField(blank=True, null=True)
    total_modules = models.IntegerField(blank=True, null=True)
    courses = models.ManyToManyField(MongoCourse, blank=True)
    last_visited = models.DateTimeField(default=timezone.now, null=True)

    class Meta:
        db_table = 'user-course-completion'


class CourseTemplates(BaseModelEmployer):
    TEMPLATE_TYPE_CHOICES = (
        ('aptpath', 'aptpath'),
        ('company', 'company'),
    )

    category_id = models.ForeignKey(
        'aptpath_models.MongoCategories',
        on_delete=models.SET_NULL, null=True, blank=True, default=None)
    moodle_course_id = models.IntegerField(null=True, blank=True)
    course_name = models.CharField(null=True, blank=True, max_length=100)
    course_url = models.TextField(null=True, blank=True)
    course_level = models.CharField(null=True, blank=True, max_length=100)
    course_logo = models.FileField(upload_to='course_images/', null=True, blank=True)
    course_duration = models.IntegerField(null=True, blank=True)
    course_about = models.TextField(null=True, blank=True)
    course_rating = models.IntegerField(null=True, blank=True, default=0)
    course_keywords = models.ManyToManyField('aptpath_models.MongoSkill', null=True, blank=True)
    course_lms = models.ForeignKey(
        LMSSystem, on_delete=models.SET_NULL, null=True, blank=True, default=None)
    num_lectures = models.IntegerField(null=True, blank=True)
    num_videos = models.IntegerField(null=True, blank=True)
    lms_course_image_url = models.URLField(null=True, blank=True)
    instructor = models.CharField(null=True, blank=True, max_length=150)
    lms_course_id = models.IntegerField(unique=True, blank=True, null=True)
    template_type = models.CharField(
        max_length=100, null=True, blank=True,
        choices=TEMPLATE_TYPE_CHOICES, default='company')

    def __str__(self):
        return f"{self.id} - {self.course_name} - {self.created_by}"

    class Meta:
        db_table = 'course-templates'


class CompanyCourseTemplates(BaseModelEmployer):
    company = models.ForeignKey(
        'aptpath_models.Company', on_delete=models.CASCADE, null=True, blank=True)
    course_template = models.ForeignKey(
        CourseTemplates, on_delete=models.CASCADE, null=True, blank=True)
    is_enabled = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.company} - {self.course_template} - {self.is_enabled}"

    class Meta:
        db_table = 'company-course-templates'
