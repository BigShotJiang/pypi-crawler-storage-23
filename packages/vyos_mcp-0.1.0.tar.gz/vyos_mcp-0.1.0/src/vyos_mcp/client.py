"""Async HTTP client for the VyOS API."""

from __future__ import annotations

import json
import os
from typing import Any

import httpx


class VyOSError(Exception):
    """Raised when the VyOS API returns an error."""


class VyOSClient:
    """Thin async wrapper around the VyOS HTTP API.

    All POST endpoints accept ``key`` (API key) and ``data`` (JSON payload)
    as multipart form fields.
    """

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        verify_ssl: bool | None = None,
    ) -> None:
        self.base_url = (base_url or os.environ["VYOS_URL"]).rstrip("/")
        self.api_key = api_key or os.environ["VYOS_API_KEY"]
        if verify_ssl is not None:
            self._verify = verify_ssl
        else:
            self._verify = os.environ.get("VYOS_VERIFY_SSL", "true").lower() != "false"

    # -- low-level helpers ---------------------------------------------------

    async def _post(self, endpoint: str, payload: dict[str, Any]) -> dict[str, Any]:
        """Send an authenticated POST request and return the parsed response."""
        async with httpx.AsyncClient(verify=self._verify, timeout=60.0) as client:
            resp = await client.post(
                f"{self.base_url}/{endpoint}",
                data={
                    "key": self.api_key,
                    "data": json.dumps(payload),
                },
            )
            resp.raise_for_status()
            body = resp.json()

        if not body.get("success"):
            error = body.get("error") or "Unknown VyOS API error"
            raise VyOSError(str(error))
        return body

    async def _get(self, endpoint: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        """Send a public GET request."""
        async with httpx.AsyncClient(verify=self._verify, timeout=30.0) as client:
            resp = await client.get(f"{self.base_url}/{endpoint}", params=params)
            resp.raise_for_status()
            return resp.json()

    async def _save(self) -> None:
        """Save running config to /config/config.boot after changes."""
        await self._post("config-file", {"op": "save"})

    # -- public API methods --------------------------------------------------

    async def info(self) -> dict[str, Any]:
        """GET /info — public system info (no auth required)."""
        return await self._get("info", {"version": "true", "hostname": "true"})

    # /retrieve operations

    async def show_config(self, path: list[str] | None = None) -> Any:
        """Retrieve full or partial running configuration."""
        body = await self._post("retrieve", {"op": "showConfig", "path": path or []})
        return body.get("data")

    async def return_values(self, path: list[str]) -> Any:
        """Return values of a multi-valued config node."""
        body = await self._post("retrieve", {"op": "returnValues", "path": path})
        return body.get("data")

    async def exists(self, path: list[str]) -> bool:
        """Check whether a config path exists."""
        body = await self._post("retrieve", {"op": "exists", "path": path})
        return bool(body.get("data"))

    # /show

    async def show(self, path: list[str]) -> str:
        """Run an operational-mode show command."""
        body = await self._post("show", {"op": "show", "path": path})
        return body.get("data", "")

    # /configure

    async def configure(
        self,
        operations: list[dict[str, Any]],
        confirm_time: int | None = None,
    ) -> str:
        """Apply one or more configure operations (set/delete).

        If ``confirm_time`` is set (minutes), changes auto-revert unless
        confirmed via :meth:`confirm_commit`.
        """
        payload: list[dict[str, Any]] | dict[str, Any]
        if len(operations) == 1:
            payload = operations[0]
        else:
            payload = operations

        if confirm_time is not None:
            if isinstance(payload, list):
                payload = {"ops": payload, "confirm_time": confirm_time}
            else:
                payload["confirm_time"] = confirm_time

        body = await self._post("configure", payload)
        if confirm_time is None:
            await self._save()
        return body.get("data", "Configuration applied")

    async def comment(self, path: list[str], value: str) -> str:
        """Add a comment to a configuration node.

        The VyOS API expects the comment text in a ``value`` field,
        separate from the config path.
        """
        payload: dict[str, Any] = {"op": "comment", "path": path, "value": value}
        body = await self._post("configure", payload)
        await self._save()
        return body.get("data", "")

    # /config-file

    async def config_file(
        self,
        op: str,
        file: str | None = None,
        string: str | None = None,
        confirm_time: int | None = None,
    ) -> str:
        """Save, load, merge, or confirm configuration files."""
        payload: dict[str, Any] = {"op": op}
        if file is not None:
            payload["file"] = file
        if string is not None:
            payload["string"] = string
        if confirm_time is not None:
            payload["confirm_time"] = confirm_time
        body = await self._post("config-file", payload)
        if op in ("load", "merge"):
            await self._save()
        return body.get("data", f"config-file {op} succeeded")

    # /generate

    async def generate(self, path: list[str]) -> str:
        """Run a generate command (keys, certs, etc.)."""
        body = await self._post("generate", {"op": "generate", "path": path})
        return body.get("data", "")

    # /reset

    async def reset(self, path: list[str]) -> str:
        """Run a reset command."""
        body = await self._post("reset", {"op": "reset", "path": path})
        return body.get("data", "")

    # /image

    async def image_add(self, url: str) -> str:
        """Download and install a system image from a URL."""
        body = await self._post("image", {"op": "add", "url": url})
        return body.get("data", "Image add initiated")

    async def image_delete(self, name: str) -> str:
        """Delete a system image by name."""
        body = await self._post("image", {"op": "delete", "name": name})
        return body.get("data", "Image deleted")

    # /reboot & /poweroff

    async def reboot(self) -> str:
        await self._save()
        body = await self._post("reboot", {"op": "reboot", "path": ["now"]})
        return body.get("data", "Reboot initiated")

    async def poweroff(self) -> str:
        await self._save()
        body = await self._post("poweroff", {"op": "poweroff", "path": ["now"]})
        return body.get("data", "Poweroff initiated")
