"""VyOS MCP Server — full VyOS router management via the HTTP API."""

from __future__ import annotations

import json
from contextlib import asynccontextmanager
from enum import Enum
from typing import Any, List, Literal, Optional

import httpx
from mcp.server.fastmcp import Context, FastMCP
from pydantic import BaseModel, ConfigDict, Field, field_validator

from vyos_mcp.client import VyOSClient, VyOSError

# ---------------------------------------------------------------------------
# Lifespan — initialise VyOSClient once, share across all tools
# ---------------------------------------------------------------------------


@asynccontextmanager
async def _lifespan(server: FastMCP):  # noqa: ARG001
    client = VyOSClient()
    yield {"vyos": client}


mcp = FastMCP("vyos_mcp", lifespan=_lifespan)


def _get_client(ctx: Context) -> VyOSClient:
    return ctx.request_context.lifespan_context["vyos"]


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _format_error(exc: Exception) -> str:
    """Return a user-friendly error string."""
    if isinstance(exc, VyOSError):
        return f"VyOS error: {exc}"
    if isinstance(exc, httpx.HTTPStatusError):
        code = exc.response.status_code
        if code == 401:
            return "Error: Authentication failed. Check VYOS_API_KEY."
        if code == 403:
            return "Error: Permission denied."
        if code == 404:
            return "Error: Endpoint not found. Check VYOS_URL."
        return f"Error: HTTP {code} — {exc.response.text[:200]}"
    if isinstance(exc, httpx.ConnectError):
        return "Error: Cannot connect to VyOS. Check VYOS_URL and network."
    if isinstance(exc, httpx.TimeoutException):
        return "Error: Request timed out. The operation may still be in progress."
    return f"Error: {type(exc).__name__}: {exc}"


def _json(data: Any) -> str:
    """Serialise arbitrary data to indented JSON."""
    return json.dumps(data, indent=2, default=str)


# ---------------------------------------------------------------------------
# Input models
# ---------------------------------------------------------------------------


class PathInput(BaseModel):
    """A VyOS configuration or command path."""

    model_config = ConfigDict(str_strip_whitespace=True)

    path: List[str] = Field(
        default_factory=list,
        description=(
            "Path segments as a list of strings. "
            "Example: [\"interfaces\", \"ethernet\", \"eth0\", \"address\"]. "
            "Pass an empty list for the root / full config."
        ),
    )


class ConfigOp(BaseModel):
    """A single configure operation."""

    model_config = ConfigDict(str_strip_whitespace=True)

    op: Literal["set", "delete", "comment"] = Field(
        ..., description="Operation type: 'set', 'delete', or 'comment'"
    )
    path: List[str] = Field(
        ...,
        description=(
            "Config path segments, e.g. [\"interfaces\", \"ethernet\", \"eth0\", \"address\", \"10.0.0.1/24\"]. "
            "For 'comment' ops, the last element is the comment text."
        ),
    )


class BatchConfigureInput(BaseModel):
    """Input for batch configuration operations."""

    model_config = ConfigDict(str_strip_whitespace=True)

    operations: List[ConfigOp] = Field(
        ...,
        description="List of configure operations to apply atomically in a single commit.",
        min_length=1,
    )
    confirm_time: Optional[int] = Field(
        default=None,
        description=(
            "Optional commit-confirm timeout in minutes. "
            "Changes auto-revert unless confirmed with vyos_confirm_commit."
        ),
        ge=1,
        le=60,
    )


class SingleConfigInput(BaseModel):
    """Input for a single set/delete/comment operation."""

    model_config = ConfigDict(str_strip_whitespace=True)

    path: List[str] = Field(
        ...,
        description="Config path segments, e.g. [\"interfaces\", \"ethernet\", \"eth0\", \"address\", \"10.0.0.1/24\"]",
    )
    confirm_time: Optional[int] = Field(
        default=None,
        description="Optional commit-confirm timeout in minutes.",
        ge=1,
        le=60,
    )


class SaveConfigInput(BaseModel):
    """Input for saving configuration."""

    model_config = ConfigDict(str_strip_whitespace=True)

    file: Optional[str] = Field(
        default=None,
        description="File path to save to. Omit for default /config/config.boot.",
    )


class LoadConfigInput(BaseModel):
    """Input for loading configuration from a file."""

    model_config = ConfigDict(str_strip_whitespace=True)

    file: str = Field(
        ..., description="Absolute file path on VyOS to load, e.g. /config/test.config"
    )


class MergeConfigInput(BaseModel):
    """Input for merging configuration."""

    model_config = ConfigDict(str_strip_whitespace=True)

    file: Optional[str] = Field(
        default=None,
        description="File path on VyOS to merge from.",
    )
    string: Optional[str] = Field(
        default=None,
        description="Inline VyOS config string to merge.",
    )
    confirm_time: Optional[int] = Field(
        default=None,
        description="Optional commit-confirm timeout in minutes.",
        ge=1,
        le=60,
    )

    @field_validator("string")
    @classmethod
    def file_or_string_required(cls, v: Optional[str], info: Any) -> Optional[str]:
        # At least one of file/string must be provided
        file_val = info.data.get("file")
        if not v and not file_val:
            raise ValueError("Provide either 'file' or 'string' (or both).")
        return v


class ImageInput(BaseModel):
    """Input for system image management."""

    model_config = ConfigDict(str_strip_whitespace=True)

    op: Literal["add", "delete"] = Field(
        ..., description="'add' to install from URL, 'delete' to remove by name"
    )
    url: Optional[str] = Field(
        default=None,
        description="Image download URL (required for 'add').",
    )
    name: Optional[str] = Field(
        default=None,
        description="Image name to delete (required for 'delete').",
    )


class SystemControlInput(BaseModel):
    """Input for reboot / poweroff with safety confirmation."""

    model_config = ConfigDict(str_strip_whitespace=True)

    action: Literal["reboot", "poweroff"] = Field(
        ..., description="'reboot' or 'poweroff'"
    )
    confirm: bool = Field(
        ...,
        description=(
            "Must be set to true to proceed. "
            "This is a destructive operation — the router will go offline."
        ),
    )


# ---------------------------------------------------------------------------
# Read-only tools
# ---------------------------------------------------------------------------


@mcp.tool(
    name="vyos_info",
    annotations={
        "title": "VyOS System Info",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def vyos_info(ctx: Context) -> str:
    """Get public system information (version, hostname, banner).

    No authentication required. Useful to verify connectivity.

    Returns:
        str: JSON with version, hostname, and banner fields.
    """
    try:
        client = _get_client(ctx)
        data = await client.info()
        return _json(data)
    except Exception as exc:
        return _format_error(exc)


@mcp.tool(
    name="vyos_show_config",
    annotations={
        "title": "Show VyOS Configuration",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def vyos_show_config(params: PathInput, ctx: Context) -> str:
    """Retrieve the running VyOS configuration (full or partial).

    Pass an empty path list for the entire config tree, or specify path
    segments to retrieve a subtree.

    Args:
        params: path — config path segments (e.g. ["interfaces", "ethernet"])

    Returns:
        str: JSON configuration data for the requested path.

    Examples:
        - Full config: path=[]
        - Interfaces only: path=["interfaces"]
        - Specific interface: path=["interfaces", "ethernet", "eth0"]
        - Firewall rules: path=["firewall"]
        - BGP config: path=["protocols", "bgp"]
    """
    try:
        client = _get_client(ctx)
        data = await client.show_config(params.path)
        return _json(data)
    except Exception as exc:
        return _format_error(exc)


@mcp.tool(
    name="vyos_return_values",
    annotations={
        "title": "Return Config Values",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def vyos_return_values(params: PathInput, ctx: Context) -> str:
    """Return values of a multi-valued configuration node.

    Use this for nodes that hold multiple values (e.g. interface addresses,
    DNS servers, NTP servers).

    Args:
        params: path — path to the multi-valued node

    Returns:
        str: JSON array of values.

    Examples:
        - Interface addresses: path=["interfaces", "dummy", "dum0", "address"]
        - DNS nameservers: path=["system", "name-server"]
    """
    try:
        client = _get_client(ctx)
        data = await client.return_values(params.path)
        return _json(data)
    except Exception as exc:
        return _format_error(exc)


@mcp.tool(
    name="vyos_exists",
    annotations={
        "title": "Check Config Path Exists",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def vyos_exists(params: PathInput, ctx: Context) -> str:
    """Check whether a configuration path exists.

    Returns true/false. Useful before setting or deleting a path.

    Args:
        params: path — config path segments to check

    Returns:
        str: "true" or "false"

    Examples:
        - Check if API is enabled: path=["service", "https", "api"]
        - Check if interface exists: path=["interfaces", "ethernet", "eth1"]
    """
    try:
        client = _get_client(ctx)
        result = await client.exists(params.path)
        return str(result).lower()
    except Exception as exc:
        return _format_error(exc)


@mcp.tool(
    name="vyos_show",
    annotations={
        "title": "VyOS Show Command",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def vyos_show(params: PathInput, ctx: Context) -> str:
    """Run an operational-mode 'show' command.

    Equivalent to running 'show <path>' in the VyOS CLI. Returns
    the text output of the command.

    Args:
        params: path — command path segments

    Returns:
        str: Command output text.

    Examples:
        - System images: path=["system", "image"]
        - Interface status: path=["interfaces"]
        - BGP summary: path=["ip", "bgp", "summary"]
        - Route table: path=["ip", "route"]
        - DHCP leases: path=["dhcp", "server", "leases"]
        - Firewall stats: path=["firewall"]
        - System uptime: path=["system", "uptime"]
        - VPN status: path=["vpn", "ipsec", "sa"]
    """
    try:
        client = _get_client(ctx)
        data = await client.show(params.path)
        return str(data)
    except Exception as exc:
        return _format_error(exc)


# ---------------------------------------------------------------------------
# Configuration tools
# ---------------------------------------------------------------------------


@mcp.tool(
    name="vyos_set",
    annotations={
        "title": "Set VyOS Config",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def vyos_set(params: SingleConfigInput, ctx: Context) -> str:
    """Set a single VyOS configuration path.

    Equivalent to 'set <path>' in configure mode. The value is the
    last element of the path list.

    Args:
        params:
            - path: Config path including the value as the last segment
            - confirm_time: Optional rollback timeout in minutes

    Returns:
        str: Success message or error.

    Examples:
        - Set interface address:
          path=["interfaces", "ethernet", "eth0", "address", "10.0.0.1/24"]
        - Set hostname:
          path=["system", "host-name", "router01"]
        - Enable SSH:
          path=["service", "ssh"]
        - Set static route:
          path=["protocols", "static", "route", "0.0.0.0/0", "next-hop", "10.0.0.254"]
        - Set firewall rule:
          path=["firewall", "name", "WAN_IN", "rule", "10", "action", "accept"]
    """
    try:
        client = _get_client(ctx)
        ops = [{"op": "set", "path": params.path}]
        result = await client.configure(ops, confirm_time=params.confirm_time)
        return str(result) if result else "Configuration set successfully."
    except Exception as exc:
        return _format_error(exc)


@mcp.tool(
    name="vyos_delete",
    annotations={
        "title": "Delete VyOS Config",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def vyos_delete(params: SingleConfigInput, ctx: Context) -> str:
    """Delete a VyOS configuration path.

    Equivalent to 'delete <path>' in configure mode. Removes the
    specified node and all its children.

    Args:
        params:
            - path: Config path to delete
            - confirm_time: Optional rollback timeout in minutes

    Returns:
        str: Success message or error.

    Examples:
        - Remove interface address:
          path=["interfaces", "ethernet", "eth0", "address", "10.0.0.1/24"]
        - Remove firewall rule:
          path=["firewall", "name", "WAN_IN", "rule", "10"]
        - Remove entire interface:
          path=["interfaces", "dummy", "dum1"]
    """
    try:
        client = _get_client(ctx)
        ops = [{"op": "delete", "path": params.path}]
        result = await client.configure(ops, confirm_time=params.confirm_time)
        return str(result) if result else "Configuration deleted successfully."
    except Exception as exc:
        return _format_error(exc)


@mcp.tool(
    name="vyos_comment",
    annotations={
        "title": "Comment VyOS Config Node",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def vyos_comment(params: SingleConfigInput, ctx: Context) -> str:
    """Add a comment to a VyOS configuration node.

    Equivalent to 'comment <path>' in configure mode.
    The comment text is the last element of the path list.

    Args:
        params:
            - path: Config path with comment text as last segment

    Returns:
        str: Success message or error.
    """
    if len(params.path) < 2:
        return "Error: path must include config path segments followed by the comment text as the last element."
    try:
        client = _get_client(ctx)
        config_path = params.path[:-1]
        comment_text = params.path[-1]
        result = await client.comment(config_path, comment_text)
        return str(result) if result else "Comment added successfully."
    except Exception as exc:
        return _format_error(exc)


@mcp.tool(
    name="vyos_configure_batch",
    annotations={
        "title": "Batch Configure VyOS",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
async def vyos_configure_batch(params: BatchConfigureInput, ctx: Context) -> str:
    """Apply multiple configuration operations in a single atomic commit.

    Use this for changes that must be applied together (e.g. creating a
    VXLAN interface with its remote and VNI, or setting up a firewall
    ruleset with multiple rules).

    Args:
        params:
            - operations: List of {op, path} dicts
            - confirm_time: Optional rollback timeout in minutes

    Returns:
        str: Success message or error.

    Examples:
        - Create VXLAN with settings:
          operations=[
            {"op": "set", "path": ["interfaces", "vxlan", "vxlan1", "remote", "203.0.113.99"]},
            {"op": "set", "path": ["interfaces", "vxlan", "vxlan1", "vni", "1"]},
            {"op": "set", "path": ["interfaces", "vxlan", "vxlan1", "address", "10.10.10.1/24"]}
          ]
        - Set up BGP peer:
          operations=[
            {"op": "set", "path": ["protocols", "bgp", "65000", "neighbor", "10.0.0.2", "remote-as", "65001"]},
            {"op": "set", "path": ["protocols", "bgp", "65000", "neighbor", "10.0.0.2", "address-family", "ipv4-unicast"]}
          ]
    """
    try:
        client = _get_client(ctx)
        ops = []
        for o in params.operations:
            if o.op == "comment" and len(o.path) >= 2:
                ops.append({"op": "comment", "path": o.path[:-1], "value": o.path[-1]})
            else:
                ops.append({"op": o.op, "path": o.path})
        result = await client.configure(ops, confirm_time=params.confirm_time)
        return str(result) if result else f"Batch configuration applied ({len(ops)} operations)."
    except Exception as exc:
        return _format_error(exc)


# ---------------------------------------------------------------------------
# Config-file tools
# ---------------------------------------------------------------------------


@mcp.tool(
    name="vyos_save_config",
    annotations={
        "title": "Save VyOS Config",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def vyos_save_config(params: SaveConfigInput, ctx: Context) -> str:
    """Save the running configuration to disk.

    By default saves to /config/config.boot. Optionally specify a
    custom file path.

    Args:
        params: file — optional save path

    Returns:
        str: Success message or error.
    """
    try:
        client = _get_client(ctx)
        result = await client.config_file("save", file=params.file)
        return str(result)
    except Exception as exc:
        return _format_error(exc)


@mcp.tool(
    name="vyos_load_config",
    annotations={
        "title": "Load VyOS Config",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
async def vyos_load_config(params: LoadConfigInput, ctx: Context) -> str:
    """Load a configuration file, replacing the running configuration.

    WARNING: This replaces the entire running config with the file contents.

    Args:
        params: file — absolute path on VyOS filesystem

    Returns:
        str: Success message or error.
    """
    try:
        client = _get_client(ctx)
        result = await client.config_file("load", file=params.file)
        return str(result)
    except Exception as exc:
        return _format_error(exc)


@mcp.tool(
    name="vyos_merge_config",
    annotations={
        "title": "Merge VyOS Config",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
async def vyos_merge_config(params: MergeConfigInput, ctx: Context) -> str:
    """Merge configuration from a file or inline string into the running config.

    Merging adds/overwrites matching nodes without removing unrelated
    configuration. Supports commit-confirm for safe rollback.

    Args:
        params:
            - file: path on VyOS filesystem, OR
            - string: inline VyOS config text
            - confirm_time: optional rollback timeout in minutes

    Returns:
        str: Success message or error.

    Examples:
        - Merge from file: file="/config/branch-office.config"
        - Merge inline config:
          string="interfaces { ethernet eth1 { address 192.168.50.1/24 } }"
    """
    try:
        client = _get_client(ctx)
        result = await client.config_file(
            "merge",
            file=params.file,
            string=params.string,
            confirm_time=params.confirm_time,
        )
        return str(result)
    except Exception as exc:
        return _format_error(exc)


@mcp.tool(
    name="vyos_confirm_commit",
    annotations={
        "title": "Confirm Pending Commit",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    },
)
async def vyos_confirm_commit(ctx: Context) -> str:
    """Confirm a pending commit-confirm timer.

    If a previous configure or merge operation was sent with
    ``confirm_time``, call this before the timer expires to keep
    the changes. Otherwise the router will automatically roll back.

    Returns:
        str: Confirmation result or error.
    """
    try:
        client = _get_client(ctx)
        result = await client.config_file("confirm")
        return str(result)
    except Exception as exc:
        return _format_error(exc)


# ---------------------------------------------------------------------------
# Generate / Reset / Image tools
# ---------------------------------------------------------------------------


@mcp.tool(
    name="vyos_generate",
    annotations={
        "title": "VyOS Generate Command",
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
async def vyos_generate(params: PathInput, ctx: Context) -> str:
    """Run a VyOS 'generate' command.

    Used to generate cryptographic keys, certificates, and other
    system components.

    Args:
        params: path — generate command path segments

    Returns:
        str: Generated output (keys, etc.) or error.

    Examples:
        - WireGuard keypair: path=["pki", "wireguard", "key-pair"]
        - OpenVPN keys: path=["pki", "openvpn"]
    """
    try:
        client = _get_client(ctx)
        result = await client.generate(params.path)
        return str(result)
    except Exception as exc:
        return _format_error(exc)


@mcp.tool(
    name="vyos_reset",
    annotations={
        "title": "VyOS Reset Command",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
async def vyos_reset(params: PathInput, ctx: Context) -> str:
    """Run a VyOS 'reset' command.

    Resets protocol sessions, counters, or other runtime state.
    Does NOT affect saved configuration.

    Args:
        params: path — reset command path segments

    Returns:
        str: Reset result or error.

    Examples:
        - Reset BGP peer: path=["ip", "bgp", "192.0.2.11"]
        - Reset all BGP: path=["ip", "bgp", "all"]
        - Reset OSPF: path=["ip", "ospf", "process"]
        - Reset counters: path=["interfaces", "ethernet", "eth0", "counters"]
    """
    try:
        client = _get_client(ctx)
        result = await client.reset(params.path)
        return str(result)
    except Exception as exc:
        return _format_error(exc)


@mcp.tool(
    name="vyos_image",
    annotations={
        "title": "Manage VyOS System Images",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
async def vyos_image(params: ImageInput, ctx: Context) -> str:
    """Add or delete VyOS system images.

    Use 'add' with a URL to download and install a new image.
    Use 'delete' with a name to remove an existing image.

    Args:
        params:
            - op: 'add' or 'delete'
            - url: download URL (required for add)
            - name: image name (required for delete)

    Returns:
        str: Operation result or error.
    """
    try:
        client = _get_client(ctx)
        if params.op == "add":
            if not params.url:
                return "Error: 'url' is required for 'add' operation."
            return await client.image_add(params.url)
        else:
            if not params.name:
                return "Error: 'name' is required for 'delete' operation."
            return await client.image_delete(params.name)
    except Exception as exc:
        return _format_error(exc)


# ---------------------------------------------------------------------------
# System control (reboot / poweroff) with safety gate
# ---------------------------------------------------------------------------


@mcp.tool(
    name="vyos_system_control",
    annotations={
        "title": "Reboot or Power Off VyOS",
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
async def vyos_system_control(params: SystemControlInput, ctx: Context) -> str:
    """Reboot or power off the VyOS router.

    CRITICAL: This will take the router offline. The 'confirm' parameter
    must be explicitly set to true.

    Args:
        params:
            - action: 'reboot' or 'poweroff'
            - confirm: must be true to proceed

    Returns:
        str: Result message or error.
    """
    if not params.confirm:
        return (
            f"Aborted: '{params.action}' requires confirm=true. "
            "This will take the router offline."
        )
    try:
        client = _get_client(ctx)
        if params.action == "reboot":
            return await client.reboot()
        else:
            return await client.poweroff()
    except Exception as exc:
        return _format_error(exc)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main():
    mcp.run()


if __name__ == "__main__":
    main()
