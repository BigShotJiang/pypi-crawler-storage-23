"""VyOS MCP Server — Manage VyOS routers via the HTTP API."""
