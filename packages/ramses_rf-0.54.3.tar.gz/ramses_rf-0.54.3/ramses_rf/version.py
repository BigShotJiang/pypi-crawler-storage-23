"""RAMSES RF - a RAMSES-II protocol decoder & analyser (application layer)."""

__version__ = "0.54.3"
VERSION = __version__
