# jleechanorg-testing-utils

Shared testing utilities: centralized test configuration, test server management, and test environment setup for browser and HTTP tests.

## Install

```bash
pip install jleechanorg-testing-utils
```

## Usage

```python
from testing_util import (
    TestConfig,
    TestType,
    TestMode,
    get_browser_base_url,
    get_http_base_url,
    setup_test_environment,
    TestServerManager,
    start_test_server,
    stop_test_server,
    test_server,
)

# Configuration
url = get_browser_base_url()  # http://localhost:8081
config = TestConfig.get_server_config(TestType.BROWSER)

# Server management
with test_server(TestType.HTTP) as port:
    # run tests against server on port
    pass
```

## API

- **TestConfig** – Centralized test server configuration (ports, URLs)
- **TestType** – BROWSER | HTTP | INTEGRATION | DEVELOPMENT
- **TestMode** – MOCK | REAL | INTEGRATION
- **TestServerManager** – Manages Flask test server lifecycle
- **test_server** – Context manager for temporary test server
- **setup_test_environment** – Initialize test environment variables
