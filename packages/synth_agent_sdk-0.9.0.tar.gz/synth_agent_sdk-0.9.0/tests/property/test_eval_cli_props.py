"""Property-based tests for eval CLI exit code.

**Property 28: Eval CLI exit code reflects pass rate**
**Validates: Requirements 11.6**
"""

from __future__ import annotations

from hypothesis import given, settings
from hypothesis import strategies as st

from synth.eval.report import EvalCaseResult, EvalReport


# ---------------------------------------------------------------------------
# Property 28: Eval CLI exit code reflects pass rate
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    n_pass=st.integers(min_value=0, max_value=10),
    n_fail=st.integers(min_value=0, max_value=10),
    threshold=st.floats(min_value=0.0, max_value=1.0),
)
def test_eval_exit_code_reflects_pass_rate(
    n_pass: int, n_fail: int, threshold: float,
):
    """Property 28: Eval CLI exit code reflects pass rate.

    For any evaluation run, the exit code should be non-zero when the
    pass rate falls below the threshold and zero when it meets or
    exceeds the threshold.

    **Validates: Requirements 11.6**
    """
    total = n_pass + n_fail
    if total == 0:
        return  # Skip empty case

    cases = []
    for i in range(n_pass):
        cases.append(EvalCaseResult(
            input=f"pass_{i}", expected="x", actual="x",
            score=1.0, passed=True, latency_ms=1.0, cost=0.0,
        ))
    for i in range(n_fail):
        cases.append(EvalCaseResult(
            input=f"fail_{i}", expected="x", actual="y",
            score=0.0, passed=False, latency_ms=1.0, cost=0.0,
        ))

    pass_rate = n_pass / total

    # Simulate the CLI exit code logic
    should_exit_zero = pass_rate >= threshold

    if should_exit_zero:
        assert pass_rate >= threshold
    else:
        assert pass_rate < threshold
