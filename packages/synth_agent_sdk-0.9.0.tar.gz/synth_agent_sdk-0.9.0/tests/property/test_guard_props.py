# Feature: synth-agent-sdk, Properties 29-33: Guard system property tests
"""Property-based tests for the Synth guard system.

**Property 29: PII guard detects PII patterns**
**Validates: Requirements 12.1**

**Property 30: Cost guard enforces limit**
**Validates: Requirements 12.2**

**Property 31: Tool filter guard matches glob patterns**
**Validates: Requirements 12.3**

**Property 32: Custom guard invocation**
**Validates: Requirements 12.4**

**Property 33: Guard evaluation order and short-circuit**
**Validates: Requirements 12.6**
"""

from __future__ import annotations

import asyncio
import fnmatch

from hypothesis import given, settings, assume
from hypothesis import strategies as st

from synth.guards.base import BaseGuard, Guard
from synth.guards.cost import CostGuard
from synth.guards.custom import CustomGuard
from synth.guards.pii import PIIGuard
from synth.guards.tool_filter import ToolFilterGuard
from synth.types import GuardContext, GuardResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _run(coro):
    """Run an async coroutine synchronously (Hypothesis doesn't support async)."""
    import asyncio
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


def _default_context(
    cumulative_cost: float = 0.0,
    tool_calls: list[str] | None = None,
) -> GuardContext:
    """Build a ``GuardContext`` with sensible defaults."""
    return GuardContext(
        cumulative_cost=cumulative_cost,
        tool_calls=tool_calls or [],
        run_id=None,
    )


# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

# Email addresses
_email_user = st.from_regex(r"[a-zA-Z0-9._%+-]{1,20}", fullmatch=True)
_email_domain = st.from_regex(r"[a-zA-Z0-9.-]{1,15}\.[a-zA-Z]{2,4}", fullmatch=True)
_email_strategy = st.builds(lambda u, d: f"{u}@{d}", _email_user, _email_domain)

# US phone numbers in various formats
_phone_strategy = st.builds(
    lambda area, mid, last, fmt: fmt(area, mid, last),
    st.from_regex(r"\d{3}", fullmatch=True),
    st.from_regex(r"\d{3}", fullmatch=True),
    st.from_regex(r"\d{4}", fullmatch=True),
    st.sampled_from([
        lambda a, m, l: f"{a}-{m}-{l}",
        lambda a, m, l: f"({a}) {m}-{l}",
        lambda a, m, l: f"{a}.{m}.{l}",
        lambda a, m, l: f"{a}{m}{l}",
    ]),
)

# SSNs: 3-2-4 digit format with dashes
_ssn_strategy = st.builds(
    lambda a, b, c: f"{a}-{b}-{c}",
    st.from_regex(r"\d{3}", fullmatch=True),
    st.from_regex(r"\d{2}", fullmatch=True),
    st.from_regex(r"\d{4}", fullmatch=True),
)

# Strings guaranteed to contain PII
_pii_string_strategy = st.one_of(
    _email_strategy,
    _phone_strategy,
    _ssn_strategy,
).flatmap(
    lambda pii: st.builds(
        lambda prefix, suffix: f"{prefix} {pii} {suffix}",
        st.text(
            alphabet=st.characters(
                whitelist_categories=("L",), whitelist_characters=" "
            ),
            min_size=0,
            max_size=30,
        ),
        st.text(
            alphabet=st.characters(
                whitelist_categories=("L",), whitelist_characters=" "
            ),
            min_size=0,
            max_size=30,
        ),
    )
)

# Strings guaranteed to NOT contain PII — only letters and spaces
_safe_text_strategy = st.text(
    alphabet=st.characters(
        whitelist_categories=("L",), whitelist_characters=" "
    ),
    min_size=0,
    max_size=100,
)

# Positive floats for cost testing
_positive_float = st.floats(min_value=0.001, max_value=1000.0, allow_nan=False)

# Simple tool names: lowercase identifiers
_tool_name = st.from_regex(r"[a-z][a-z0-9_]{0,20}", fullmatch=True)

# Simple glob patterns using * wildcard
_glob_pattern = st.one_of(
    _tool_name,
    st.builds(lambda n: f"{n}*", st.from_regex(r"[a-z]{1,8}", fullmatch=True)),
    st.builds(lambda n: f"*{n}", st.from_regex(r"[a-z]{1,8}", fullmatch=True)),
    st.builds(lambda n: f"*{n}*", st.from_regex(r"[a-z]{1,8}", fullmatch=True)),
)


# ---------------------------------------------------------------------------
# Property 29: PII guard detects PII patterns
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(pii_text=_pii_string_strategy)
def test_pii_guard_detects_pii(pii_text):
    """Property 29: For any output string containing PII patterns, the
    PIIGuard should return a failing GuardResult.

    **Validates: Requirements 12.1**
    """
    guard = PIIGuard()
    result = _run(guard.check(pii_text, _default_context()))
    assert not result.passed, (
        f"PIIGuard should have detected PII in: {pii_text!r}"
    )
    assert result.violation_message is not None


@settings(max_examples=100)
@given(safe_text=_safe_text_strategy)
def test_pii_guard_passes_clean_text(safe_text):
    """Property 29: For any output string without PII patterns, the
    PIIGuard should return a passing GuardResult.

    **Validates: Requirements 12.1**
    """
    import re
    # Defensively skip any string that happens to match a PII pattern,
    # ensuring the property only asserts on genuinely clean inputs.
    _pii_check = re.compile(
        r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
        r"|(?:\+?1[-.\s]?)?(?:\(\d{3}\)|\d{3})[-.\s]?\d{3}[-.\s]?\d{4}"
        r"|\b\d{3}-\d{2}-\d{4}\b"
    )
    assume(not _pii_check.search(safe_text))
    guard = PIIGuard()
    result = _run(guard.check(safe_text, _default_context()))
    assert result.passed, (
        f"PIIGuard should have passed for clean text: {safe_text!r}"
    )


# ---------------------------------------------------------------------------
# Property 30: Cost guard enforces limit
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    limit=_positive_float,
    overshoot=st.floats(min_value=0.001, max_value=500.0, allow_nan=False),
)
def test_cost_guard_blocks_over_limit(limit, overshoot):
    """Property 30: For any run where cumulative cost exceeds the limit,
    the CostGuard should return a failing GuardResult.

    **Validates: Requirements 12.2**
    """
    guard = CostGuard(limit=limit)
    ctx = _default_context(cumulative_cost=limit + overshoot)
    result = _run(guard.check("", ctx))
    assert not result.passed
    assert result.violation_message is not None


@settings(max_examples=100)
@given(
    limit=_positive_float,
    fraction=st.floats(min_value=0.0, max_value=1.0, allow_nan=False),
)
def test_cost_guard_passes_under_limit(limit, fraction):
    """Property 30: For any run where cumulative cost is at or under the
    limit, the CostGuard should return a passing GuardResult.

    **Validates: Requirements 12.2**
    """
    guard = CostGuard(limit=limit)
    ctx = _default_context(cumulative_cost=limit * fraction)
    result = _run(guard.check("", ctx))
    assert result.passed


# ---------------------------------------------------------------------------
# Property 31: Tool filter guard matches glob patterns
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    tool_name=_tool_name,
    patterns=st.lists(_glob_pattern, min_size=1, max_size=5),
)
def test_tool_filter_matches_fnmatch(tool_name, patterns):
    """Property 31: For any tool call name and list of glob patterns, the
    ToolFilterGuard should block the call if and only if the name matches
    at least one pattern via fnmatch.

    **Validates: Requirements 12.3**
    """
    guard = ToolFilterGuard(patterns=patterns)
    ctx = _default_context(tool_calls=[tool_name])
    result = _run(guard.check("", ctx))

    should_block = any(fnmatch.fnmatch(tool_name, p) for p in patterns)
    assert result.passed != should_block, (
        f"tool={tool_name!r}, patterns={patterns}, "
        f"expected block={should_block}, got passed={result.passed}"
    )


# ---------------------------------------------------------------------------
# Property 32: Custom guard invocation
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(content=st.text(min_size=0, max_size=50))
def test_custom_guard_passes_when_fn_returns_true(content):
    """Property 32: For any custom guard function that returns True,
    the guard should pass.

    **Validates: Requirements 12.4**
    """
    guard = CustomGuard(fn=lambda _: True)
    result = _run(guard.check(content, _default_context()))
    assert result.passed


@settings(max_examples=100)
@given(content=st.text(min_size=0, max_size=50))
def test_custom_guard_fails_when_fn_returns_false(content):
    """Property 32: For any custom guard function that returns False,
    the guard should fail with a violation message.

    **Validates: Requirements 12.4**
    """
    guard = CustomGuard(fn=lambda _: False)
    result = _run(guard.check(content, _default_context()))
    assert not result.passed
    assert result.violation_message is not None


@settings(max_examples=100)
@given(content=st.text(min_size=0, max_size=50))
def test_custom_guard_fails_when_fn_raises(content):
    """Property 32: For any custom guard function that raises an exception,
    the guard should fail with a violation message.

    **Validates: Requirements 12.4**
    """
    def _boom(_):
        raise ValueError("test error")

    guard = CustomGuard(fn=_boom)
    result = _run(guard.check(content, _default_context()))
    assert not result.passed
    assert result.violation_message is not None


# ---------------------------------------------------------------------------
# Property 33: Guard evaluation order and short-circuit
# ---------------------------------------------------------------------------


class _TrackingGuard(BaseGuard):
    """A guard that records whether it was evaluated and can be configured
    to pass or fail."""

    def __init__(self, name: str, should_pass: bool, tracker: list[str]) -> None:
        super().__init__(name=name)
        self._should_pass = should_pass
        self._tracker = tracker

    async def check(self, content: str, context: GuardContext) -> GuardResult:
        self._tracker.append(self.name)
        if self._should_pass:
            return GuardResult(passed=True)
        return GuardResult(
            passed=False,
            violation_message=f"{self.name} failed",
        )


@settings(max_examples=100)
@given(
    total=st.integers(min_value=2, max_value=8),
    fail_idx=st.integers(min_value=0),
)
def test_guard_evaluation_order_and_short_circuit(total, fail_idx):
    """Property 33: For any ordered list of guards where the guard at index k
    fails, all guards 0..k should have been evaluated, no guard beyond k
    should have been evaluated, and the error should be from guard k.

    **Validates: Requirements 12.6**
    """
    k = fail_idx % total
    tracker: list[str] = []

    guards: list[BaseGuard] = []
    for i in range(total):
        guards.append(
            _TrackingGuard(
                name=f"guard_{i}",
                should_pass=(i != k),
                tracker=tracker,
            )
        )

    # Simulate the agent's guard evaluation loop: in order, stop at first
    # failure.
    failing_result: GuardResult | None = None
    failing_guard_name: str | None = None
    for guard in guards:
        result = _run(guard.check("test", _default_context()))
        if not result.passed:
            failing_result = result
            failing_guard_name = guard.name
            break

    # Guards 0..k should have been evaluated
    assert tracker == [f"guard_{i}" for i in range(k + 1)], (
        f"Expected guards 0..{k} evaluated, got {tracker}"
    )

    # The failure should come from guard k
    assert failing_result is not None
    assert not failing_result.passed
    assert failing_guard_name == f"guard_{k}"
