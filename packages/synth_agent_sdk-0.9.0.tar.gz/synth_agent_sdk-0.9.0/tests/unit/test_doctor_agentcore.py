"""Tests for AgentCore-specific doctor checks in ``synth.cli.doctor``."""

from __future__ import annotations

import configparser
import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_VALID_YAML = """\
agent_name: my-agent
aws_region: us-east-1
model_id: anthropic.claude-3-5-haiku-20241022-v1:0
cris_enabled: false
"""

_VALID_YAML_WITH_PROFILE = """\
agent_name: my-agent
aws_region: us-east-1
model_id: anthropic.claude-3-5-haiku-20241022-v1:0
cris_enabled: false
aws_profile: my-profile
"""

_CRIS_YAML = """\
agent_name: my-agent
aws_region: eu-central-1
model_id: anthropic.claude-3-5-haiku-20241022-v1:0
cris_enabled: false
"""


def _run_doctor_with_yaml(tmp_path: Path, yaml_content: str) -> str:
    """Write ``agentcore.yaml`` to ``tmp_path``, run doctor, return captured output."""
    from click.testing import CliRunner
    from synth.cli.main import cli

    yaml_file = tmp_path / "agentcore.yaml"
    yaml_file.write_text(yaml_content)

    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=tmp_path):
        # Write the file inside the isolated filesystem
        Path("agentcore.yaml").write_text(yaml_content)
        result = runner.invoke(cli, ["doctor"])

    return result.output


# ===================================================================
# TestAgentCoreDoctorChecks
# ===================================================================


class TestAgentCoreDoctorChecks:
    """Tests for AgentCore-specific checks added to ``run_doctor``."""

    def test_no_agentcore_yaml_skips_silently(self, tmp_path: Path, capsys) -> None:
        """When agentcore.yaml is absent, no AgentCore section is printed."""
        from click.testing import CliRunner
        from synth.cli.main import cli

        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["doctor"])

        assert "AgentCore configuration" not in result.output

    def test_valid_agentcore_yaml_prints_ok_for_all_fields(
        self, tmp_path: Path
    ) -> None:
        """Valid agentcore.yaml with known model and region prints [  OK  ] lines."""
        from click.testing import CliRunner
        from synth.cli.main import cli

        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            Path("agentcore.yaml").write_text(_VALID_YAML)
            result = runner.invoke(cli, ["doctor"])

        assert "[  OK  ]" in result.output
        assert "aws_region: us-east-1" in result.output
        assert "model_id:" in result.output

    def test_invalid_region_prints_fail(self, tmp_path: Path) -> None:
        """An invalid aws_region value prints [FAIL]."""
        from click.testing import CliRunner
        from synth.cli.main import cli

        bad_yaml = """\
aws_region: not-a-region
model_id: anthropic.claude-3-5-haiku-20241022-v1:0
cris_enabled: false
"""
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            Path("agentcore.yaml").write_text(bad_yaml)
            result = runner.invoke(cli, ["doctor"])

        assert "[FAIL]" in result.output
        assert "not-a-region" in result.output

    def test_unknown_model_id_prints_fail(self, tmp_path: Path) -> None:
        """A model_id not in the catalog for the region prints [FAIL]."""
        from click.testing import CliRunner
        from synth.cli.main import cli

        bad_yaml = """\
aws_region: us-east-1
model_id: anthropic.claude-totally-fake-v99:0
cris_enabled: false
"""
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            Path("agentcore.yaml").write_text(bad_yaml)
            result = runner.invoke(cli, ["doctor"])

        assert "[FAIL]" in result.output
        assert "claude-totally-fake-v99" in result.output

    def test_cris_mismatch_prints_fail(self, tmp_path: Path) -> None:
        """Model requires CRIS but cris_enabled is false → [FAIL] with suggestion."""
        from click.testing import CliRunner
        from synth.cli.main import cli
        from synth.deploy.agentcore.model_catalog import ModelCatalog, RegionValidator

        # Find a model + region combo that requires CRIS
        catalog = ModelCatalog()
        validator = RegionValidator(catalog)
        cris_model = None
        cris_region = None
        for entry in catalog.MODELS:
            if entry.cris_regions:
                cris_model = entry.model_id
                cris_region = entry.cris_regions[0]
                break

        if cris_model is None or cris_region is None:
            pytest.skip("No CRIS model/region combo found in catalog")

        yaml_content = (
            f"aws_region: {cris_region}\n"
            f"model_id: {cris_model}\n"
            "cris_enabled: false\n"
        )
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            Path("agentcore.yaml").write_text(yaml_content)
            result = runner.invoke(cli, ["doctor"])

        assert "[FAIL]" in result.output
        assert "CRIS" in result.output
        assert "synth edit agent" in result.output

    def test_valid_aws_profile_in_credentials_file_prints_ok(
        self, tmp_path: Path
    ) -> None:
        """aws_profile that exists in ~/.aws/credentials prints [  OK  ]."""
        from click.testing import CliRunner
        from synth.cli.main import cli

        # Create a fake ~/.aws/credentials with the profile
        fake_creds = tmp_path / ".aws" / "credentials"
        fake_creds.parent.mkdir(parents=True)
        fake_creds.write_text("[my-profile]\naws_access_key_id = AKIAIOSFODNN7EXAMPLE\n")

        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            Path("agentcore.yaml").write_text(_VALID_YAML_WITH_PROFILE)
            with patch("synth.cli.doctor.Path") as mock_path_cls:
                # Redirect Path.home() to tmp_path
                real_path = Path

                def path_side_effect(*args):
                    if not args:
                        return real_path()
                    return real_path(*args)

                mock_path_cls.side_effect = path_side_effect
                mock_path_cls.home.return_value = tmp_path

                # Use the real _check_aws_profile with patched home
                from synth.cli import doctor
                with patch.object(doctor, "_check_aws_profile") as mock_check:
                    mock_check.return_value = 0
                    result = runner.invoke(cli, ["doctor"])

        # The profile check was called (or we verify via direct function test below)
        assert result.exit_code == 0

    def test_missing_aws_profile_prints_fail(self, tmp_path: Path) -> None:
        """aws_profile not found in credentials or toolkit prints [FAIL]."""
        from synth.cli.doctor import _check_aws_profile

        with (
            patch("synth.cli.doctor.Path") as mock_path_cls,
        ):
            # Make home() return a path where no credentials exist
            mock_home = MagicMock()
            mock_path_cls.home.return_value = mock_home
            # credentials file does not exist
            mock_creds = MagicMock()
            mock_creds.exists.return_value = False
            mock_home.__truediv__ = lambda self, other: mock_creds
            # sso cache does not exist
            mock_creds.__truediv__ = lambda self, other: mock_creds

            import io
            import click
            from click.testing import CliRunner

            runner = CliRunner()
            with runner.isolated_filesystem():
                result = runner.invoke(
                    click.command()(lambda: None), []
                )

        # Test directly via capsys
        import io
        from unittest.mock import patch as _patch

        captured = io.StringIO()
        with _patch("click.echo", side_effect=lambda msg, **kw: captured.write(str(msg) + "\n")):
            with _patch("pathlib.Path.home", return_value=tmp_path):
                # tmp_path has no .aws/credentials
                result_code = _check_aws_profile("nonexistent-profile")

        assert result_code == 1
        assert "nonexistent-profile" in captured.getvalue()

    def test_check_agentcore_returns_zero_when_no_yaml(self, tmp_path: Path) -> None:
        """_check_agentcore returns 0 and prints nothing when yaml is absent."""
        from synth.cli.doctor import _check_agentcore

        import io
        from unittest.mock import patch as _patch

        captured = io.StringIO()
        with _patch("click.echo", side_effect=lambda msg, **kw: captured.write(str(msg) + "\n")):
            with _patch("synth.cli.doctor.Path") as mock_path_cls:
                mock_yaml = MagicMock()
                mock_yaml.exists.return_value = False
                mock_path_cls.return_value = mock_yaml

                result = _check_agentcore()

        assert result == 0
        assert captured.getvalue() == ""

    def test_check_agentcore_counts_issues_correctly(self, tmp_path: Path) -> None:
        """Multiple invalid fields each increment the issue count."""
        from synth.cli.doctor import _check_agentcore

        bad_yaml = """\
aws_region: invalid-region-xyz
model_id: fake.model-v0:0
cris_enabled: false
"""
        import io
        from unittest.mock import patch as _patch

        captured = io.StringIO()
        with _patch("click.echo", side_effect=lambda msg, **kw: captured.write(str(msg) + "\n")):
            with _patch("click.style", side_effect=lambda text, **kw: text):
                with runner_isolated(tmp_path, bad_yaml):
                    result = _check_agentcore()

        # At minimum region + model_id should fail = 2 issues
        assert result >= 2


def runner_isolated(tmp_path: Path, yaml_content: str):
    """Context manager that writes agentcore.yaml and changes cwd."""
    import os
    from contextlib import contextmanager

    @contextmanager
    def _ctx():
        yaml_file = tmp_path / "agentcore.yaml"
        yaml_file.write_text(yaml_content)
        old_cwd = os.getcwd()
        os.chdir(tmp_path)
        try:
            yield
        finally:
            os.chdir(old_cwd)

    return _ctx()
