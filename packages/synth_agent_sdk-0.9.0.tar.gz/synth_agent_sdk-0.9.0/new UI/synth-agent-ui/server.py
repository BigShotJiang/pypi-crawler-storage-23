"""Local testing UI server — bridges the browser to your Synth agent."""

from __future__ import annotations

import asyncio
import importlib.util
import json
import sys
import time
import uuid
from pathlib import Path

try:
    from fastapi import FastAPI, Request
    from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
    from fastapi.staticfiles import StaticFiles
    import uvicorn
except ImportError:
    print("Missing dependencies. Install them with:")
    print("  pip install uvicorn fastapi")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
AGENT_FILE = str(Path(__file__).parent.parent / "Trav" / "agent.py")
PERSIST_FILE = Path(__file__).parent / "conversations.json"
PROMPTS_FILE = Path(__file__).parent / "prompts.json"
EVALS_FILE = Path(__file__).parent / "evals.json"
SCENARIOS_FILE = Path(__file__).parent / "scenarios.json"

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------
app = FastAPI(title="Synth Agent UI")
app.mount("/static", StaticFiles(directory=Path(__file__).parent / "static"), name="static")

_agent = None
_agent_status = {"loaded": False, "error": None, "file": AGENT_FILE}
_conversations: dict[str, list[dict]] = {"default": []}
_current_conv = "default"
_prompts: dict[str, list[dict]] = {}   # name -> list of versions [{version, text, created_at, notes}]
_evals: list[dict] = []                # [{id, name, input, expected, golden}]
_scenarios: list[dict] = []            # [{id, name, turns: [{role, content}]}]


# ---------------------------------------------------------------------------
# Persistence helpers
# ---------------------------------------------------------------------------

def _load_conversations():
    global _conversations
    if PERSIST_FILE.exists():
        try:
            _conversations = json.loads(PERSIST_FILE.read_text(encoding="utf-8"))
        except Exception:
            _conversations = {"default": []}
    try:
        PERSIST_FILE.write_text(json.dumps(_conversations, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save conversations: {e}")


def _save_conversations():
    try:
        PERSIST_FILE.write_text(json.dumps(_conversations, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save conversations: {e}")


def _load_prompts():
    global _prompts
    if PROMPTS_FILE.exists():
        try:
            _prompts = json.loads(PROMPTS_FILE.read_text(encoding="utf-8"))
        except Exception:
            _prompts = {}


def _save_prompts():
    try:
        PROMPTS_FILE.write_text(json.dumps(_prompts, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save prompts: {e}")


def _load_evals():
    global _evals
    if EVALS_FILE.exists():
        try:
            _evals = json.loads(EVALS_FILE.read_text(encoding="utf-8"))
        except Exception:
            _evals = []


def _save_evals():
    try:
        EVALS_FILE.write_text(json.dumps(_evals, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save evals: {e}")


def _load_scenarios():
    global _scenarios
    if SCENARIOS_FILE.exists():
        try:
            _scenarios = json.loads(SCENARIOS_FILE.read_text(encoding="utf-8"))
        except Exception:
            _scenarios = []


def _save_scenarios():
    try:
        SCENARIOS_FILE.write_text(json.dumps(_scenarios, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"Warning: could not save scenarios: {e}")


# ---------------------------------------------------------------------------
# Agent loader
# ---------------------------------------------------------------------------

def _load_agent():
    global _agent, _agent_status
    spec = importlib.util.spec_from_file_location("_agent_mod", AGENT_FILE)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load agent from '{AGENT_FILE}'")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if not hasattr(mod, "agent"):
        raise RuntimeError(f"'{AGENT_FILE}' must define an 'agent' variable.")
    _agent = mod.agent
    _agent_status = {"loaded": True, "error": None, "file": AGENT_FILE}
    return _agent


def _run_agent(prompt: str):
    """Run agent synchronously, return (result, elapsed_ms)."""
    start = time.perf_counter()
    result = _agent.run(prompt)
    elapsed = (time.perf_counter() - start) * 1000
    return result, elapsed


def _build_msg(result, elapsed_ms: float, prompt: str = "") -> dict:
    text = result.text or (result.output.answer if result.output else "")
    return {
        "type": "done",
        "text": text,
        "output": result.output.model_dump() if result.output else None,
        "tokens": {
            "input": result.tokens.input_tokens,
            "output": result.tokens.output_tokens,
            "total": result.tokens.total_tokens,
        },
        "cost": result.cost,
        "latency_ms": round(elapsed_ms, 1),
        "tool_calls": [
            {"name": tc.name, "args": tc.args, "result": str(tc.result), "latency_ms": round(tc.latency_ms, 1)}
            for tc in result.tool_calls
        ],
        "trace": _serialize_trace(result),
    }


@app.on_event("startup")
async def startup():
    _load_conversations()
    _load_prompts()
    _load_evals()
    _load_scenarios()
    try:
        _load_agent()
        print(f"Agent loaded from {AGENT_FILE}")
    except Exception as exc:
        _agent_status["error"] = str(exc)
        print(f"Warning: could not load agent: {exc}")


@app.get("/", response_class=HTMLResponse)
async def index():
    html = (Path(__file__).parent / "static" / "index.html").read_text(encoding="utf-8")
    return HTMLResponse(content=html)


# ---------------------------------------------------------------------------
# Streaming chat endpoint (SSE)
# ---------------------------------------------------------------------------
@app.post("/api/chat/stream")
async def chat_stream(request: Request):
    """Stream agent response as SSE events."""
    if _agent is None:
        async def err():
            yield f"data: {json.dumps({'type': 'error', 'error': 'No agent loaded.'})}\n\n"
        return StreamingResponse(err(), media_type="text/event-stream")

    body = await request.json()
    prompt = body.get("prompt", "")
    conv_id = body.get("conversation", "default")

    if not prompt.strip():
        async def err():
            yield f"data: {json.dumps({'type': 'error', 'error': 'Empty prompt.'})}\n\n"
        return StreamingResponse(err(), media_type="text/event-stream")

    async def generate():
        start = time.perf_counter()
        try:
            loop = asyncio.get_event_loop()
            full_text = ""
            result = None

            def _stream():
                return list(_agent.stream(prompt))

            events = await loop.run_in_executor(None, _stream)

            for event in events:
                etype = type(event).__name__

                if etype == "ThinkingEvent":
                    thinking = getattr(event, "thinking", "") or getattr(event, "text", "")
                    if thinking:
                        yield f"data: {json.dumps({'type': 'thinking', 'text': thinking})}\n\n"
                        await asyncio.sleep(0)

                elif etype == "TokenEvent":
                    token = getattr(event, "text", "") or getattr(event, "token", "")
                    if token:
                        full_text += token
                        yield f"data: {json.dumps({'type': 'token', 'text': token})}\n\n"
                        await asyncio.sleep(0)

                elif etype == "ToolCallEvent":
                    yield f"data: {json.dumps({'type': 'tool_call', 'name': getattr(event, 'name', '?')})}\n\n"
                    await asyncio.sleep(0)

                elif etype == "DoneEvent":
                    result = getattr(event, "result", None)

            elapsed = (time.perf_counter() - start) * 1000

            if result is None:
                result = await loop.run_in_executor(None, _agent.run, prompt)
                full_text = result.text or ""

            text = full_text or result.text or (result.output.answer if result.output else "")
            msg = _build_msg(result, elapsed)
            msg["text"] = text

            if conv_id not in _conversations:
                _conversations[conv_id] = []
            _conversations[conv_id].append({"role": "user", "content": prompt, "ts": time.time()})
            _conversations[conv_id].append({"role": "agent", "data": msg, "ts": time.time()})
            _save_conversations()

            yield f"data: {json.dumps(msg)}\n\n"

        except Exception as exc:
            import traceback
            traceback.print_exc()
            yield f"data: {json.dumps({'type': 'error', 'error': str(exc)})}\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


# ---------------------------------------------------------------------------
# Non-streaming fallback
# ---------------------------------------------------------------------------
@app.post("/api/chat")
async def chat(request: Request):
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)

    body = await request.json()
    prompt = body.get("prompt", "")
    conv_id = body.get("conversation", "default")
    if not prompt.strip():
        return JSONResponse({"error": "Empty prompt."}, status_code=400)

    try:
        loop = asyncio.get_event_loop()
        result, elapsed = await loop.run_in_executor(None, lambda: _run_agent(prompt))
        msg = _build_msg(result, elapsed)

        if conv_id not in _conversations:
            _conversations[conv_id] = []
        _conversations[conv_id].append({"role": "user", "content": prompt, "ts": time.time()})
        _conversations[conv_id].append({"role": "agent", "data": msg, "ts": time.time()})
        _save_conversations()

        return JSONResponse(msg)
    except Exception as exc:
        import traceback
        traceback.print_exc()
        return JSONResponse({"error": str(exc)}, status_code=500)


# ---------------------------------------------------------------------------
# Agent management
# ---------------------------------------------------------------------------

@app.post("/api/reload")
async def reload_agent():
    try:
        _load_agent()
        return JSONResponse({"status": "reloaded"})
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


@app.get("/api/tools")
async def list_tools():
    if _agent is None:
        return JSONResponse({"tools": []})
    tools = getattr(_agent, "_registered_tools", {})
    tool_list = []
    for name, fn in tools.items():
        schema = getattr(fn, "_tool_schema", {})
        tool_list.append({
            "name": name,
            "description": schema.get("description", ""),
            "parameters": schema.get("parameters", {}),
        })
    return JSONResponse({"tools": tool_list})


@app.post("/api/tools/test")
async def test_tool(request: Request):
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    body = await request.json()
    tool_name = body.get("name", "")
    tool_args = body.get("args", {})
    tools = getattr(_agent, "_registered_tools", {})
    if tool_name not in tools:
        return JSONResponse({"error": f"Tool '{tool_name}' not found."}, status_code=404)
    start = time.perf_counter()
    try:
        fn = tools[tool_name]
        if asyncio.iscoroutinefunction(fn):
            result = await fn(**tool_args)
        else:
            result = fn(**tool_args)
        elapsed = (time.perf_counter() - start) * 1000
        return JSONResponse({"result": str(result), "latency_ms": round(elapsed, 1)})
    except Exception as exc:
        return JSONResponse({"error": str(exc)}, status_code=500)


# ---------------------------------------------------------------------------
# Conversations
# ---------------------------------------------------------------------------

@app.get("/api/conversations")
async def list_conversations():
    return JSONResponse({"conversations": list(_conversations.keys()), "current": _current_conv})


@app.get("/api/conversations/{conv_id}")
async def get_conversation(conv_id: str):
    return JSONResponse({"messages": _conversations.get(conv_id, [])})


@app.post("/api/conversations")
async def create_conversation(request: Request):
    global _current_conv
    body = await request.json()
    conv_id = body.get("id", f"chat-{len(_conversations) + 1}")
    _conversations[conv_id] = []
    _current_conv = conv_id
    _save_conversations()
    return JSONResponse({"id": conv_id})


@app.delete("/api/conversations/{conv_id}")
async def delete_conversation(conv_id: str):
    global _current_conv
    if conv_id in _conversations and conv_id != "default":
        del _conversations[conv_id]
        if _current_conv == conv_id:
            _current_conv = "default"
        _save_conversations()
    return JSONResponse({"status": "deleted"})


# ---------------------------------------------------------------------------
# Prompt management
# ---------------------------------------------------------------------------

@app.get("/api/prompts")
async def list_prompts():
    return JSONResponse({"prompts": {name: versions for name, versions in _prompts.items()}})


@app.post("/api/prompts")
async def save_prompt(request: Request):
    body = await request.json()
    name = body.get("name", "").strip()
    text = body.get("text", "").strip()
    notes = body.get("notes", "")
    if not name or not text:
        return JSONResponse({"error": "name and text required"}, status_code=400)
    if name not in _prompts:
        _prompts[name] = []
    version = len(_prompts[name]) + 1
    _prompts[name].append({
        "version": version,
        "text": text,
        "notes": notes,
        "created_at": time.time(),
    })
    _save_prompts()
    return JSONResponse({"name": name, "version": version})


@app.delete("/api/prompts/{name}")
async def delete_prompt(name: str):
    if name in _prompts:
        del _prompts[name]
        _save_prompts()
    return JSONResponse({"status": "deleted"})


@app.delete("/api/prompts/{name}/{version}")
async def delete_prompt_version(name: str, version: int):
    if name in _prompts:
        _prompts[name] = [v for v in _prompts[name] if v["version"] != version]
        if not _prompts[name]:
            del _prompts[name]
        _save_prompts()
    return JSONResponse({"status": "deleted"})


# ---------------------------------------------------------------------------
# A/B testing
# ---------------------------------------------------------------------------

@app.post("/api/ab-test")
async def ab_test(request: Request):
    """Run the same input against two prompts/models and return both results."""
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    body = await request.json()
    input_text = body.get("input", "").strip()
    prompt_a = body.get("prompt_a", "").strip()
    prompt_b = body.get("prompt_b", "").strip()
    if not input_text:
        return JSONResponse({"error": "input required"}, status_code=400)

    loop = asyncio.get_event_loop()

    async def run_variant(system_prompt: str, label: str):
        try:
            full_prompt = f"{system_prompt}\n\n{input_text}" if system_prompt else input_text
            result, elapsed = await loop.run_in_executor(None, lambda: _run_agent(full_prompt))
            return {
                "label": label,
                "prompt": system_prompt,
                "text": result.text or (result.output.answer if result.output else ""),
                "tokens": {
                    "input": result.tokens.input_tokens,
                    "output": result.tokens.output_tokens,
                    "total": result.tokens.total_tokens,
                },
                "cost": result.cost,
                "latency_ms": round(elapsed, 1),
            }
        except Exception as exc:
            return {"label": label, "prompt": system_prompt, "error": str(exc)}

    results = await asyncio.gather(
        run_variant(prompt_a, "A"),
        run_variant(prompt_b, "B"),
    )
    return JSONResponse({"results": list(results), "input": input_text})


# ---------------------------------------------------------------------------
# Evals
# ---------------------------------------------------------------------------

@app.get("/api/evals")
async def list_evals():
    return JSONResponse({"evals": _evals})


@app.post("/api/evals")
async def create_eval(request: Request):
    body = await request.json()
    name = body.get("name", "").strip()
    input_text = body.get("input", "").strip()
    expected = body.get("expected", "").strip()
    if not name or not input_text:
        return JSONResponse({"error": "name and input required"}, status_code=400)
    eval_case = {
        "id": str(uuid.uuid4())[:8],
        "name": name,
        "input": input_text,
        "expected": expected,
        "golden": None,
        "created_at": time.time(),
    }
    _evals.append(eval_case)
    _save_evals()
    return JSONResponse(eval_case)


@app.delete("/api/evals/{eval_id}")
async def delete_eval(eval_id: str):
    global _evals
    _evals = [e for e in _evals if e["id"] != eval_id]
    _save_evals()
    return JSONResponse({"status": "deleted"})


@app.post("/api/evals/run")
async def run_evals(request: Request):
    """Run all (or selected) eval cases and score them."""
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    body = await request.json()
    ids = body.get("ids", None)  # None = run all
    use_llm_judge = body.get("llm_judge", False)

    cases = _evals if ids is None else [e for e in _evals if e["id"] in ids]
    if not cases:
        return JSONResponse({"results": []})

    loop = asyncio.get_event_loop()
    results = []

    for case in cases:
        try:
            result, elapsed = await loop.run_in_executor(None, lambda c=case: _run_agent(c["input"]))
            actual = result.text or (result.output.answer if result.output else "")
            expected = case.get("expected", "")
            golden = case.get("golden")

            # Simple keyword match score
            score = _simple_score(actual, expected) if expected else None
            regression = _simple_score(actual, golden) if golden else None

            llm_score = None
            llm_reason = None
            if use_llm_judge and expected:
                llm_score, llm_reason = await loop.run_in_executor(
                    None, lambda a=actual, e=expected: _llm_judge(a, e)
                )

            results.append({
                "id": case["id"],
                "name": case["name"],
                "input": case["input"],
                "expected": expected,
                "actual": actual,
                "score": score,
                "llm_score": llm_score,
                "llm_reason": llm_reason,
                "regression_score": regression,
                "golden": golden,
                "latency_ms": round(elapsed, 1),
                "tokens": {
                    "input": result.tokens.input_tokens,
                    "output": result.tokens.output_tokens,
                    "total": result.tokens.total_tokens,
                },
                "cost": result.cost,
                "pass": score is not None and score >= 0.5,
            })
        except Exception as exc:
            results.append({"id": case["id"], "name": case["name"], "error": str(exc), "pass": False})

    return JSONResponse({"results": results})


@app.post("/api/evals/{eval_id}/set-golden")
async def set_golden(eval_id: str, request: Request):
    """Save current output as the golden baseline for regression testing."""
    body = await request.json()
    text = body.get("text", "")
    for e in _evals:
        if e["id"] == eval_id:
            e["golden"] = text
            _save_evals()
            return JSONResponse({"status": "saved"})
    return JSONResponse({"error": "not found"}, status_code=404)


def _simple_score(actual: str, expected: str) -> float:
    """Keyword overlap score between 0 and 1."""
    if not expected:
        return 1.0
    a_words = set(actual.lower().split())
    e_words = set(expected.lower().split())
    if not e_words:
        return 1.0
    overlap = len(a_words & e_words)
    return round(overlap / len(e_words), 3)


def _llm_judge(actual: str, expected: str) -> tuple[float, str]:
    """Use the agent's model to score the response."""
    judge_prompt = (
        f"You are an evaluator. Score the following response against the expected output.\n\n"
        f"Expected: {expected}\n\nActual: {actual}\n\n"
        f"Reply with JSON only: {{\"score\": <0.0-1.0>, \"reason\": \"<one sentence>\"}}"
    )
    try:
        result = _agent.run(judge_prompt)
        text = result.text or ""
        import re
        m = re.search(r'\{.*\}', text, re.DOTALL)
        if m:
            data = json.loads(m.group())
            return float(data.get("score", 0)), str(data.get("reason", ""))
    except Exception:
        pass
    return 0.0, "Judge failed"


# ---------------------------------------------------------------------------
# Scenarios (multi-turn)
# ---------------------------------------------------------------------------

@app.get("/api/scenarios")
async def list_scenarios():
    return JSONResponse({"scenarios": _scenarios})


@app.post("/api/scenarios")
async def create_scenario(request: Request):
    body = await request.json()
    name = body.get("name", "").strip()
    turns = body.get("turns", [])
    if not name:
        return JSONResponse({"error": "name required"}, status_code=400)
    scenario = {
        "id": str(uuid.uuid4())[:8],
        "name": name,
        "turns": turns,
        "created_at": time.time(),
    }
    _scenarios.append(scenario)
    _save_scenarios()
    return JSONResponse(scenario)


@app.put("/api/scenarios/{scenario_id}")
async def update_scenario(scenario_id: str, request: Request):
    body = await request.json()
    for s in _scenarios:
        if s["id"] == scenario_id:
            s["name"] = body.get("name", s["name"])
            s["turns"] = body.get("turns", s["turns"])
            _save_scenarios()
            return JSONResponse(s)
    return JSONResponse({"error": "not found"}, status_code=404)


@app.delete("/api/scenarios/{scenario_id}")
async def delete_scenario(scenario_id: str):
    global _scenarios
    _scenarios = [s for s in _scenarios if s["id"] != scenario_id]
    _save_scenarios()
    return JSONResponse({"status": "deleted"})


@app.post("/api/scenarios/{scenario_id}/run")
async def run_scenario(scenario_id: str):
    """Execute a scripted multi-turn conversation."""
    if _agent is None:
        return JSONResponse({"error": "No agent loaded."}, status_code=503)
    scenario = next((s for s in _scenarios if s["id"] == scenario_id), None)
    if not scenario:
        return JSONResponse({"error": "not found"}, status_code=404)

    loop = asyncio.get_event_loop()
    results = []
    for turn in scenario["turns"]:
        if turn.get("role") != "user":
            continue
        content = turn["content"]
        try:
            result, elapsed = await loop.run_in_executor(None, lambda c=content: _run_agent(c))
            results.append({
                "input": content,
                "output": result.text or (result.output.answer if result.output else ""),
                "latency_ms": round(elapsed, 1),
                "tokens": {
                    "input": result.tokens.input_tokens,
                    "output": result.tokens.output_tokens,
                    "total": result.tokens.total_tokens,
                },
                "cost": result.cost,
            })
        except Exception as exc:
            results.append({"input": content, "error": str(exc)})

    return JSONResponse({"scenario": scenario["name"], "results": results})


# ---------------------------------------------------------------------------
# Info / health
# ---------------------------------------------------------------------------

@app.get("/api/info")
async def agent_info():
    tools = getattr(_agent, "_registered_tools", {}) if _agent else {}
    return JSONResponse({
        "model": getattr(_agent, "model", "unknown") if _agent else "not loaded",
        "tools": len(tools),
        "instructions": getattr(_agent, "instructions", "")[:200] if _agent else "",
        "status": _agent_status,
    })


@app.get("/api/health")
async def health():
    return JSONResponse({"ok": True, "agent_loaded": _agent is not None})


def _serialize_trace(result):
    trace = getattr(result, "trace", None)
    if trace is None:
        return []
    spans = getattr(trace, "spans", [])
    return [
        {
            "name": getattr(s, "name", "?"),
            "type": getattr(s, "span_type", "?"),
            "duration_ms": round(getattr(s, "duration_ms", 0.0), 1),
            "metadata": {k: v for k, v in getattr(s, "metadata", {}).items()},
        }
        for s in spans
    ]


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8420)
