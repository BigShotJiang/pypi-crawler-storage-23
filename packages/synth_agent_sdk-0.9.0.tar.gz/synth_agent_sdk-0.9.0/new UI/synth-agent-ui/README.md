# synth-agent-ui

A developer dashboard for testing your SynthAgentSDK agent locally.

## Setup

```bash
pip install uvicorn fastapi
```

## Usage

1. Edit `server.py` and set `AGENT_FILE` to point at your agent module.
2. Start the server:

```bash
python server.py
```

3. Open http://localhost:8420 in your browser.

## Features

- **Chat interface** — talk to your agent with real-time responses
- **Conversation history** — sidebar with multiple conversations, switch between them
- **Trace timeline** — collapsible right panel showing every span (LLM calls, tool calls, guard checks) with timing
- **Tool playground** — bottom drawer to test individual tools with custom arguments, see results and latency
- **Metrics** — per-response and session-level token count, cost, and latency
- **Hot-reload** — reload your agent from disk without restarting the server
- **Fallout terminal aesthetic** — CRT scanlines, green-on-dark theme matching the Synth boot sequence
