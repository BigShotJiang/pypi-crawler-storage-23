"""Welcome message for first-time Synth SDK users.

Displays a friendly onboarding message on first CLI invocation.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path


_WELCOME_MARKER = Path.home() / ".synth" / ".welcome_shown"


def should_show_welcome() -> bool:
    """Check if this is the first time the user is running synth."""
    return not _WELCOME_MARKER.exists()


def mark_welcome_shown() -> None:
    """Mark that the welcome message has been displayed."""
    _WELCOME_MARKER.parent.mkdir(parents=True, exist_ok=True)
    _WELCOME_MARKER.touch()


def display_welcome() -> None:
    """Display first-run welcome message with setup instructions."""
    if not should_show_welcome():
        return

    # Skip if not in a TTY or if banners are disabled
    if not sys.stdout.isatty() or os.environ.get("SYNTH_NO_BANNER"):
        mark_welcome_shown()
        return

    # Check for NO_COLOR
    no_color = os.environ.get("NO_COLOR")

    if no_color:
        _display_plain_welcome()
    else:
        _display_colored_welcome()

    mark_welcome_shown()


def _display_colored_welcome() -> None:
    """Display colorful welcome message."""
    GREEN = "\033[92m"
    CYAN = "\033[96m"
    YELLOW = "\033[93m"
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"

    message = f"""
{GREEN}{BOLD}╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   {CYAN}✓{GREEN} Welcome to Synth SDK!                                ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝{RESET}

{BOLD}Quick Start:{RESET}

  {CYAN}1.{RESET} Install a provider (if you haven't already):
     {YELLOW}pip install synth-agent-sdk[anthropic]{RESET}
     {DIM}or: synth-agent-sdk[openai], [google], [bedrock], [all]{RESET}

  {CYAN}2.{RESET} Set your API key:
     {YELLOW}export ANTHROPIC_API_KEY=your-key-here{RESET}
     {DIM}(or OPENAI_API_KEY, GOOGLE_API_KEY, etc.){RESET}

  {CYAN}3.{RESET} Verify your setup:
     {YELLOW}synth doctor{RESET}

  {CYAN}4.{RESET} Create your first agent:
     {YELLOW}synth create agent my-app{RESET}

  {CYAN}5.{RESET} Start building:
     {YELLOW}synth dev my_agent.py{RESET}

{DIM}Run 'synth help' for the full command reference.{RESET}
"""
    print(message)


def _display_plain_welcome() -> None:
    """Display plain text welcome message (no color)."""
    message = """
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   ✓ Welcome to Synth SDK!                                ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝

Quick Start:

  1. Install a provider (if you haven't already):
     pip install synth-agent-sdk[anthropic]
     or: synth-agent-sdk[openai], [google], [bedrock], [all]

  2. Set your API key:
     export ANTHROPIC_API_KEY=your-key-here
     (or OPENAI_API_KEY, GOOGLE_API_KEY, etc.)

  3. Verify your setup:
     synth doctor

  4. Create your first agent:
     synth create agent my-app

  5. Start building:
     synth dev my_agent.py

Run 'synth help' for the full command reference.
"""
    print(message)
