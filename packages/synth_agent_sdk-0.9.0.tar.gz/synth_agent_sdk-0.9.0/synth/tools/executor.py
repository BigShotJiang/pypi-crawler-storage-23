"""ToolExecutor — invocation and error handling for tool functions.

Executes ``@tool``-decorated functions by name, wraps exceptions in
:class:`~synth.errors.ToolExecutionError`, and emits
:class:`TypeMismatchWarning` when the return value's type does not match
the function's declared return annotation.
"""

from __future__ import annotations

import asyncio
import inspect
import typing
import warnings
from typing import Any

from synth.errors import ToolExecutionError
from synth.tools.decorator import ToolFunction


class TypeMismatchWarning(UserWarning):
    """Emitted when a tool's return value doesn't match its declared return type."""


class ToolExecutor:
    """Execute registered tool functions by name.

    Parameters
    ----------
    tools:
        Mapping of tool name → ``@tool``-decorated callable.
    """

    def __init__(self, tools: dict[str, ToolFunction]) -> None:
        self._tools = dict(tools)

    async def execute(self, name: str, args: dict[str, Any]) -> Any:
        """Call the tool identified by *name* with the given *args*.

        Raises
        ------
        ToolExecutionError
            If the tool function raises any exception, or if *name* is not
            a registered tool.
        """
        if name not in self._tools:
            raise ToolExecutionError(
                message=f"Unknown tool '{name}'.",
                component="ToolExecutor",
                suggestion=f"Available tools: {', '.join(sorted(self._tools)) or '(none)'}.",
                tool_name=name,
                tool_args=args,
                original_error=KeyError(name),
            )

        fn = self._tools[name]

        try:
            result = fn(**args)
            if asyncio.iscoroutine(result):
                result = await result
        except Exception as exc:
            raise ToolExecutionError(
                message=f"Tool '{name}' raised an error: {exc}",
                component="ToolExecutor",
                suggestion="Check the tool implementation and the arguments passed.",
                tool_name=name,
                tool_args=args,
                original_error=exc,
            ) from exc

        # Check return type against annotation
        self._check_return_type(name, fn, result)

        return result

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _check_return_type(name: str, fn: ToolFunction, result: Any) -> None:
        """Emit :class:`TypeMismatchWarning` if *result* doesn't match the
        declared return annotation of *fn*."""
        try:
            hints = typing.get_type_hints(fn)
        except Exception:
            return

        expected = hints.get("return")
        if expected is None or expected is inspect.Parameter.empty:
            return

        if not isinstance(result, expected):
            warnings.warn(
                f"Tool '{name}' declared return type {expected.__name__} "
                f"but returned {type(result).__name__}.",
                TypeMismatchWarning,
                stacklevel=2,
            )
