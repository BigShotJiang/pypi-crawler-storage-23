"""SemanticMemory — vector embedding storage with cosine similarity retrieval.

Stores conversation messages as vector embeddings and retrieves the most
relevant context chunks using cosine similarity against a query vector.
The embedding function is user-provided, keeping the SDK free of heavy
ML dependencies.
"""

from __future__ import annotations

from collections.abc import Callable

from synth.memory.base import BaseMemory
from synth.types import Message


# ---------------------------------------------------------------------------
# SemanticMemory
# ---------------------------------------------------------------------------


class SemanticMemory(BaseMemory):
    """Memory backend that stores turns as vector embeddings.

    Uses cosine similarity to retrieve the most relevant messages for a
    given query.  The ``embedder`` callable is user-provided — it converts
    a text string into a list of floats (the embedding vector).

    Parameters
    ----------
    embedder:
        Callable that converts text to a vector (``list[float]``).
    top_k:
        Default number of results returned by :meth:`search`.
        Defaults to ``10``.

    Examples
    --------
    ::

        def my_embedder(text: str) -> list[float]:
            return [float(ord(c)) for c in text[:8]]

        mem = SemanticMemory(embedder=my_embedder, top_k=5)
        await mem.add_messages("t1", [{"role": "user", "content": "hello"}])
        results = await mem.search("t1", "hi", top_k=3)
    """

    def __init__(self, embedder: Callable[[str], list[float]], top_k: int = 10) -> None:
        self._embedder = embedder
        self._top_k = top_k
        self._store: dict[str, list[tuple[Message, list[float]]]] = {}

    # ------------------------------------------------------------------
    # BaseMemory interface
    # ------------------------------------------------------------------

    async def get_messages(self, thread_id: str) -> list[Message]:
        """Return all messages for the thread.

        This returns every stored message regardless of relevance.  For
        similarity-based retrieval, use :meth:`search` instead.

        Parameters
        ----------
        thread_id:
            Unique identifier for the conversation thread.

        Returns
        -------
        list[Message]
            All messages in the thread, in insertion order.
        """
        entries = self._store.get(thread_id, [])
        return [msg for msg, _vec in entries]

    async def add_messages(self, thread_id: str, messages: list[Message]) -> None:
        """Append messages and their embeddings to the thread.

        Each message's ``content`` field is passed through the embedder to
        produce a vector that is stored alongside the message.

        Parameters
        ----------
        thread_id:
            Unique identifier for the conversation thread.
        messages:
            Messages to append.
        """
        if thread_id not in self._store:
            self._store[thread_id] = []
        for msg in messages:
            vec = self._embedder(msg["content"])
            self._store[thread_id].append((msg, vec))

    # ------------------------------------------------------------------
    # Semantic retrieval
    # ------------------------------------------------------------------

    async def search(
        self, thread_id: str, query: str, top_k: int | None = None
    ) -> list[Message]:
        """Retrieve the most relevant messages by cosine similarity.

        Parameters
        ----------
        thread_id:
            Unique identifier for the conversation thread.
        query:
            Text to compare against stored messages.
        top_k:
            Number of results to return.  Falls back to the instance
            default if ``None``.

        Returns
        -------
        list[Message]
            Up to ``top_k`` messages ordered by descending similarity.
        """
        k = top_k if top_k is not None else self._top_k
        entries = self._store.get(thread_id, [])
        if not entries:
            return []
        query_vec = self._embedder(query)
        scored = [
            (msg, self._cosine_similarity(query_vec, vec))
            for msg, vec in entries
        ]
        scored.sort(key=lambda x: x[1], reverse=True)
        return [msg for msg, _score in scored[:k]]

    # ------------------------------------------------------------------
    # Similarity helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _cosine_similarity(a: list[float], b: list[float]) -> float:
        """Compute cosine similarity between two vectors.

        Returns ``0.0`` when either vector has zero magnitude.

        Parameters
        ----------
        a:
            First vector.
        b:
            Second vector.

        Returns
        -------
        float
            Cosine similarity in the range ``[-1.0, 1.0]``.
        """
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = sum(x * x for x in a) ** 0.5
        norm_b = sum(x * x for x in b) ** 0.5
        if norm_a == 0.0 or norm_b == 0.0:
            return 0.0
        return dot / (norm_a * norm_b)
