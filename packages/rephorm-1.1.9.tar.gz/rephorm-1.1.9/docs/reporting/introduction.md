# About
The purpose of this documentation is to provide guidance on how to use and interact with the Rephorm package. Using Python, Rephorm can create PDF reports that include various charts and tables. By enabling users to write high-level Python code, Rephorm facilitates the creation of PDF reports. All the complex details are handled in the background by the package, so users are only required to import Rephorm, provide the required data, and use it to generate their reports.

# Installing rephorm package
1. Initiate a new python project
2. Access your virtual environment terminal: this can be done directly in your IDE or by activating the virtual environment in your system’s command line. (Python dependency 3.12)
3. Execute the following command in your (virtual environment) terminal: 


```bash
1. pip install rephorm
```
This command will download and install the most recent version of the Rephorm package. Once installed, ensure that your IDE is configured to use this virtual environment.

# Rephorm Objects

Objects serve as the building blocks of your report. As the creator, you are responsible for initializing, creating, and interacting with them:

* **Report** – this is the main object that is responsible for assembling all other objects. Picture it as your blank report sheet. First, you need to initialize it, specifying its structure (such as margins, paper size like A4, A3), and then amend other objects within. Everything you add to this object will be included in the final output PDF file.
* **Chapter** – used to establish a new chapter by inserting a title for a new page and organizing shared parameters and styles for objects within that chapter.
* **Page break** – allows adding page breaks throughout the report.
* **Grid** – allows creating grid layouts.
* **Text** – to insert text.
* **Chart** – to create charts.
* **Table** – to create tables.
* **Table section** – facilitates the creation of a "new section" within a table, marked by a bold title. This adds an empty row where the title is placed in the first column.
* **Chart series** – to create chart series (that can be added to Chart object).
* **Table series** – to create table series (that can be added to Table object).

The function of some of these objects is simple and straightforward. However, we will explore certain ones in more detail later to ensure you have a thorough understanding of their operation and what you can achieve with them. 

# Object hierarchy

Before we dive deeper, it is crucial to understand the hierarchy of the object structure. Having an understanding of this order is essential when amending multiple objects together, as trying to amend incompatible objects together would be like trying to fit a square peg into a round hole.

For instance, this hierarchy demonstrates that you can use the .add() method on the report object to include sections, tables, grids, charts, texts, or page breaks.

![marketplace](assets/hierarchy.png)



