# Appendix A – Styles dictionary

**Default values for each key**

```bash
  1. {
  2.     "table": {
  3.         "highlight_color": "#E0E0E0",
  4.         "title": {
  5.             "font_style": "B",
  6.             "font_family": "Helvetica",
  7.             "font_color": "#000000",
  8.             "font_size": 13,
  9.         },
 10.         "heading": {
 11.             "font_style": "",
 12.             "font_family": "Helvetica",
 13.             "font_color": "#000000",
 14.             "font_size": 10,
 15.             "highlight_color": "#E0E0E0",
 16.         },
 17.         "series": {
 18.             "font_style": "",
 19.             "font_family": "Helvetica",
 20.             "font_color": "#000000",
 21.             "font_size": 10,
 22.             "highlight_color": "#E0E0E0",
 23.         },
 24.         "section": {
 25.             "font_style": "",
 26.             "font_family": "Helvetica",
 27.             "font_color": "#000000",
 28.             "font_size": 10,
 29.             "highlight_color": "#E0E0E0",
 30.         },
 31.     },
 32.     "text": {
 33.         "font_style": "",
 34.         "font_family": "Helvetica",
 35.         "font_size": 10,
 36.         "title": {
 37.             "font_style": "B",
 38.             "font_family": "Helvetica",
 39.             "font_size": 16,
 40.         },
 41.     },
 42.     "footnotes": {
 43.         "font_size": 8,
 44.         "font_color": "#000000",
 45.         "font_style": "",
 46.         "font_family": "Helvetica",
 47.     },
 48.     "grid": {
 49.         "title": {
 50.             "font_style": "B",
 51.             "font_family": "Helvetica",
 52.             "font_color": "#000000",
 53.             "font_size": 13,
 54.         },
 55.     },
 56.     "chapter": {
 57.         "title": {
 58.             "font_style": "B",
 59.             "font_family": "Helvetica",
 60.             "font_color": "#000000",
 61.             "font_size": 16,
 62.         },
 63.         "font_style": "",
 64.         "font_family": "Helvetica",
 65.         "font_size": 11,
 66.     },
 67.     "chart": {
 68.         "highlight_color": "rgba(0, 0, 0, 0.12)",
 69.         "grid_color": "lightgrey",
 70.         "bg_color": "rgba(0, 255, 0, 0)",
 71.         "chart_border_color": "#000000",
 72.         "line_styles_order": ["solid"],
 73.         "line_color_order": [
 74.             "rgb(31, 119, 180)",
 75.             "rgb(255, 127, 14)",
 76.             "rgb(44, 160, 44)",
 77.             "rgb(214, 39, 40)",
 78.             "rgb(148, 103, 189)",
 79.             "rgb(140, 86, 75)",
 80.             "rgb(227, 119, 194)",
 81.             "rgb(127, 127, 127)",
 82.             "rgb(188, 189, 34)",
 83.             "rgb(23, 190, 207)",
 84.         ],
 85.         "bar_color_order": [
 86.             "rgb(31, 119, 180)",
 87.             "rgb(255, 127, 14)",
 88.             "rgb(44, 160, 44)",
 89.             "rgb(214, 39, 40)",
 90.             "rgb(148, 103, 189)",
 91.             "rgb(140, 86, 75)",
 92.             "rgb(227, 119, 194)",
 93.             "rgb(127, 127, 127)",
 94.             "rgb(188, 189, 34)",
 95.             "rgb(23, 190, 207)",
 96.         ],
 97.         "line_width_order": [1],
 98.         "series": {
 99.             "bar_edge_color": "black",
100.             "bar_face_color": None,
101.             "bar_edge_width": 1.0,
102.             "line_width": None,
103.             "line_style": None,
104.             "line_color": None,
105.             "marker_color": "#46b336",
106.             "marker_size": 1,
107.             "marker_width": 1,
108.         },
109.         "legend": {
110.             "border_width": 0,
111.             "bg_color": "rgba(255, 255, 255, 0)",
112.             "font_style": "",
113.             "font_family": "Helvetica",
114.             "font_color": "#000000",
115.             "font_size": 8,
116.         },
117.         "title": {
118.             "font_style": "",
119.             "font_family": "Helvetica",
120.             "font_color": "#000000",
121.             "font_size": 11,
122.         },
123.         "x_axis": {
124.             "ticks": {
125.                 "font_size": 10,
126.                 "font_color": "#000000",
127.                 "font_family": "Helvetica",
128.             },
129.             "label": {
130.                 "font_size": 10,
131.                 "font_color": "#000000",
132.                 "font_family": "Helvetica",
133.             },
134.         },
135.         "y_axis": {
136.             "ticks": {
137.                 "font_size": 10,
138.                 "font_color": "#000000",
139.                 "font_family": "Helvetica",
140.             },
141.             "label": {
142.                 "font_size": 10,
143.                 "font_color": "#000000",
144.                 "font_family": "Helvetica",
145.             },
146.         },
147.         "y_axis2": {
148.             "ticks": {
149.                 "font_size": 10,
150.                 "font_color": "#000000",
151.                 "font_family": "Helvetica",
152.             },
153.             "label": {
154.                 "font_size": 10,
155.                 "font_color": "#000000",
156.                 "font_family": "Helvetica",
157.             },
158.         },
159.     },
160.     "report": {
161.         "title": {
162.             "font_style": "B",
163.             "font_size": 25,
164.             "font_color": "#000000",
165.             "font_family": "Helvetica",
166.         },
167.         "subtitle": {
168.             "font_style": "B",
169.             "font_size": 21,
170.             "font_color": "#000000",
171.             "font_family": "Helvetica",
172.         },
173.         "abstract": {
174.             "height": 50,
175.             "font_size": 10,
176.             "font_color": "#000000",
177.             "font_family": "Helvetica",
178.         },
179.         "footer": {
180.             "height": 15,
181.             "top_margin": 5,
182.             "top_padding": 5,
183.         },
184.         "header": {
185.             "height": 20,
186.             "bottom_margin": 5,
187.         },
188.         "font_style": "",
189.         "font_family": "Helvetica",
190.         "font_color": "#000000",
191.         "page_margin_top": 10,
192.         "page_margin_right": 40,
193.         "page_margin_bottom": 15,
194.         "page_margin_left": 40,
195.         "title_bottom_padding": 10,
196.         "logo_height": 15,
197.     },
198. }
```


