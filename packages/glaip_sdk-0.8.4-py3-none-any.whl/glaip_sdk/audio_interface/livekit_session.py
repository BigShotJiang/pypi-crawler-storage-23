"""LiveKit-backed audio session implementation for glaip-sdk."""

from __future__ import annotations

import asyncio
import importlib
import importlib.util
import os
import uuid
from typing import Any

from glaip_sdk.audio_interface._defaults import build_default_livekit_audio_config


def _ensure_audio_available() -> None:
    """Check if audio-capable aip-agents and LiveKit dependencies are available."""
    if importlib.util.find_spec("aip_agents") is None:
        raise ImportError(
            "Audio support requires 'aip-agents' with audio extra. Install it with: pip install glaip-sdk[audio]"
        )

    if importlib.util.find_spec("livekit") is None:
        raise ImportError(
            "LiveKit dependencies missing. Install them with: "
            "pip install 'glaip-sdk[audio]' (or 'aip-agents-binary[audio]')"
        )


class _GlaipSDKAgentAudioShim:
    """Shim a glaip-sdk Agent into the minimal interface expected by aip-agents."""

    thread_id_key = "thread_id"

    def __init__(self, agent: Any) -> None:
        self._agent = agent
        self._memory_user_id = self._resolve_memory_user_id()

    def _resolve_memory_user_id(self) -> str | None:
        explicit = (os.environ.get("AIP_AUDIO_MEMORY_USER_ID") or "").strip()
        if explicit:
            return explicit

        agent_config = getattr(self._agent, "agent_config", None)
        if not isinstance(agent_config, dict):
            return None

        if str(agent_config.get("memory") or "").strip().lower() != "mem0":
            return None

        return f"mem0-user-{uuid.uuid4().hex[:8]}"

    async def arun(self, text: str, **kwargs: Any) -> dict[str, str]:
        local = bool(kwargs.pop("local", False))

        if "id" in dir(self._agent) and getattr(self._agent, "id", None) is None:
            local = True

        if not local:
            kwargs.pop("configurable", None)

        if self._memory_user_id and not kwargs.get("memory_user_id"):
            kwargs["memory_user_id"] = self._memory_user_id

        result = await asyncio.to_thread(self._agent.run, text, local=local, verbose=False, **kwargs)
        return {"output": str(result)}


def _should_wrap_sdk_agent(agent: Any) -> bool:
    """Check if the agent is a glaip-sdk Agent (or subclass)."""
    from glaip_sdk.agents.base import Agent  # noqa: PLC0415

    return isinstance(agent, Agent)


class LiveKitAudioSession:
    """Manage a LiveKit audio session for a glaip-sdk Agent."""

    def __init__(self, config: Any = None, *, agent: Any | None = None, instructions: str | None = None) -> None:
        """Initialize a LiveKit-backed audio session.

        Args:
            config: Audio session config object or dict.
            agent: Optional bound agent used by `run()`/`start()` when not provided.
            instructions: Optional bound instructions used by `run()`/`start()`.
        """
        _ensure_audio_available()

        aip_audio_interface = importlib.import_module("aip_agents.audio_interface")
        aip_audio_session_config = aip_audio_interface.AudioSessionConfig
        aip_livekit_audio_session = aip_audio_interface.LiveKitAudioSession

        if config is None:
            config = build_default_livekit_audio_config()

        if isinstance(config, dict):
            self._config = aip_audio_session_config.from_agent_config_audio(config)
        else:
            self._config = config or aip_audio_session_config()

        self._session = aip_livekit_audio_session(self._config)
        self._agent = agent
        self._instructions = instructions

    def _resolve_agent(self, agent: Any | None) -> Any:
        resolved = agent if agent is not None else self._agent
        if resolved is None:
            raise ValueError(
                "Agent is required. Provide agent=... when constructing the session or pass it to start()/run()."
            )
        return resolved

    def _resolve_instructions(self, *, agent: Any, instructions: str | None) -> str:
        if instructions is not None:
            return instructions
        if self._instructions is not None:
            return self._instructions
        agent_inst = getattr(agent, "instruction", None)
        if isinstance(agent_inst, str) and agent_inst.strip():
            return agent_inst
        return "You are a helpful assistant."

    async def start(self, agent: Any | None = None, *, instructions: str | None = None) -> None:
        """Start the LiveKit audio session with the provided or bound agent."""
        resolved_agent = self._resolve_agent(agent)
        resolved_instructions = self._resolve_instructions(agent=resolved_agent, instructions=instructions)
        aip_agent = (
            _GlaipSDKAgentAudioShim(resolved_agent) if _should_wrap_sdk_agent(resolved_agent) else resolved_agent
        )
        await self._session.start(aip_agent, instructions=resolved_instructions)

    async def stop(self) -> None:
        """Stop the audio session and release resources."""
        await self._session.stop()

    async def wait_closed(self) -> None:
        """Wait until the underlying session reports closure."""
        await self._session.wait_closed()

    async def run(self, agent: Any | None = None, *, instructions: str | None = None) -> None:
        """Start the session and block until it closes."""
        await self.start(agent, instructions=instructions)
        try:
            await self.wait_closed()
        except asyncio.CancelledError:
            await self.stop()
            raise
