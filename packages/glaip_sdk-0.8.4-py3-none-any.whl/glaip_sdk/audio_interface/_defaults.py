"""Defaults and helpers for the SDK audio interface.

Keep env var names and local-dev fallback values centralized here so the public
wrapper (`glaip_sdk.audio_interface.LiveKitAudioSession`) stays small and
readable.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from typing import Any


DEFAULT_LIVEKIT_ENV: dict[str, str] = {
    "LIVEKIT_URL": "ws://localhost:7880",
    "LIVEKIT_API_KEY": "devkey",
    "LIVEKIT_API_SECRET": "devsecretdevsecretdevsecretdevsecret",
    "LIVEKIT_ROOM_NAME": "aip-audio-demo",
    "LIVEKIT_IDENTITY": "aip-agent",
}


def build_default_livekit_audio_config(
    environ: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    """Build a default `agent_config.audio`-shaped config for local LiveKit usage."""
    env = os.environ if environ is None else environ

    return {
        "provider": "livekit",
        "io": {"input_enabled": True, "output_enabled": True},
        "model": {
            "provider": "openai",
            "voice": env.get("OPENAI_TTS_VOICE", "echo"),
        },
        "livekit": {
            "url": env.get("LIVEKIT_URL", DEFAULT_LIVEKIT_ENV["LIVEKIT_URL"]),
            "api_key": env.get("LIVEKIT_API_KEY", DEFAULT_LIVEKIT_ENV["LIVEKIT_API_KEY"]),
            "api_secret": env.get(
                "LIVEKIT_API_SECRET",
                DEFAULT_LIVEKIT_ENV["LIVEKIT_API_SECRET"],
            ),
            "room_name": env.get("LIVEKIT_ROOM_NAME", DEFAULT_LIVEKIT_ENV["LIVEKIT_ROOM_NAME"]),
            "identity": env.get("LIVEKIT_IDENTITY", DEFAULT_LIVEKIT_ENV["LIVEKIT_IDENTITY"]),
        },
    }
