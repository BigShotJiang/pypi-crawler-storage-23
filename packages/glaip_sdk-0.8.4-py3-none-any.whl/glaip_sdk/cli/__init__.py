"""CLI package for AIP SDK.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from glaip_sdk.cli.main import main

__all__ = ["main"]
