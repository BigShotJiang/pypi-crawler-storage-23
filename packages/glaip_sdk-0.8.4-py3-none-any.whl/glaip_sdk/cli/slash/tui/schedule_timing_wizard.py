# pyright: reportGeneralTypeIssues=false
"""Simplified schedule timing wizard modal for TUI schedules.

This wizard uses a natural language approach with frequency selection
and multiple time slots, hiding the complexity of cron syntax.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, cast

from glaip_sdk.models.schedule import ScheduleConfig

if TYPE_CHECKING:  # pragma: no cover - type checking only
    from textual.app import ComposeResult
    from textual.binding import Binding
    from textual.containers import Container, Horizontal, Vertical, VerticalScroll
    from textual.screen import ModalScreen
    from textual.widgets import Button, Input, Select, Static
else:
    try:  # pragma: no cover - optional dependency
        from textual.app import ComposeResult
        from textual.binding import Binding
        from textual.containers import Container, Horizontal, Vertical, VerticalScroll
        from textual.screen import ModalScreen
        from textual.widgets import Button, Input, Select, Static
    except Exception:  # pragma: no cover - optional dependency
        ComposeResult = None  # type: ignore[assignment]
        Binding = None  # type: ignore[assignment]
        Container = None  # type: ignore[assignment]
        Horizontal = None  # type: ignore[assignment]
        Vertical = None  # type: ignore[assignment]
        VerticalScroll = None  # type: ignore[assignment]
        ModalScreen = None  # type: ignore[assignment]
        Button = None  # type: ignore[assignment]
        Input = None  # type: ignore[assignment]
        Static = None  # type: ignore[assignment]
        Select = None  # type: ignore[assignment]

if ModalScreen is None:  # pragma: no cover - fallback stubs

    class ModalScreen:  # type: ignore[no-redef]
        """Fallback stub for ModalScreen."""

        pass


if Button is None:  # pragma: no cover - fallback stubs

    class Button:  # type: ignore[no-redef]
        """Fallback stub for Button."""

        class Pressed:  # pragma: no cover - stub
            """Fallback stub for Button.Pressed event."""

            def __init__(self, button: Any) -> None:
                """Initialize the event."""
                self.button = button

        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            """Initialize the button."""
            self.id = _kwargs.get("id")

        def toggle_class(self, _class_name: str) -> None:
            """Toggle a CSS class (stub)."""


if Input is None:  # pragma: no cover - fallback stubs

    class Input:  # type: ignore[no-redef]
        """Fallback stub for Input."""

        class Changed:  # pragma: no cover - stub
            """Fallback stub for Input.Changed event."""

            def __init__(self, input: Any, value: str) -> None:
                """Initialize the event."""
                self.input = input
                self.value = value

        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            """Initialize the input."""
            self.id = _kwargs.get("id")
            self.value = _kwargs.get("value", "")


if Static is None:  # pragma: no cover - fallback stubs

    class Static:  # type: ignore[no-redef]
        """Fallback stub for Static."""

        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            """Initialize the static widget."""
            self.id = _kwargs.get("id")

        def update(self, _content: str) -> None:
            """Update the widget content (stub)."""


if Select is None:  # pragma: no cover - fallback stubs

    class Select:  # type: ignore[no-redef]
        """Fallback stub for Select."""

        BLANK = object()  # type: ignore[assignment]

        class Changed:  # pragma: no cover - stub
            """Fallback stub for Select.Changed event."""

            def __init__(self, select: Any, value: Any) -> None:
                """Initialize the event."""
                self.select = select
                self.value = value

        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            """Initialize the select."""
            self.id = _kwargs.get("id")


if Horizontal is None:  # pragma: no cover - fallback stubs

    class Horizontal:  # type: ignore[no-redef]
        """Fallback stub for Horizontal container."""

        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            """Initialize the container."""
            self.id = _kwargs.get("id")


if Vertical is None:  # pragma: no cover - fallback stubs

    class Vertical:  # type: ignore[no-redef]
        """Fallback stub for Vertical container."""

        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            """Initialize the container."""
            self.id = _kwargs.get("id")


if VerticalScroll is None:  # pragma: no cover - fallback stubs

    class VerticalScroll:  # type: ignore[no-redef]
        """Fallback stub for VerticalScroll container."""

        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            """Initialize the container."""
            self.id = _kwargs.get("id")


if Container is None:  # pragma: no cover - fallback stubs

    class Container:  # type: ignore[no-redef]
        """Fallback stub for Container."""

        def __init__(self, *_args: Any, **_kwargs: Any) -> None:
            """Initialize the container."""
            self.id = _kwargs.get("id")


TEXTUAL_SUPPORTED = (
    ModalScreen is not None
    and Input is not None
    and Button is not None
    and Static is not None
    and Horizontal is not None
    and Vertical is not None
    and Container is not None
    and VerticalScroll is not None
    and Select is not None
)


if TEXTUAL_SUPPORTED:
    _WizardBase = ModalScreen  # type: ignore[assignment]
else:
    _WizardBase = object  # pragma: no cover - unreachable: import failure defines fallback stubs

InputType = cast(Any, Input)
StaticType = cast(Any, Static)
ButtonType = cast(Any, Button)
SelectType = cast(Any, Select)
HorizontalType = cast(Any, Horizontal)
VerticalType = cast(Any, Vertical)
ContainerType = cast(Any, Container)
VerticalScrollType = cast(Any, VerticalScroll)

# Day mapping for display
DAY_OPTIONS = [("Sun", 0), ("Mon", 1), ("Tue", 2), ("Wed", 3), ("Thu", 4), ("Fri", 5), ("Sat", 6)]
DAY_MAP = {0: "Sun", 1: "Mon", 2: "Tue", 3: "Wed", 4: "Thu", 5: "Fri", 6: "Sat"}

# Frequency options
FREQUENCY_OPTIONS = [
    ("Every X minutes/hours", "interval"),
    ("Daily", "daily"),
    ("Weekly", "weekly"),
    ("Monthly", "monthly"),
    ("Yearly", "yearly"),
    ("Custom (advanced)", "custom"),
]

# UI constants
FREQ_PANEL_HIDDEN_CLASS = "freq-panel hidden"
AT_WHAT_TIME_LABEL = "At what time?"
WIZARD_NEXT_RUNS_ID = "#wizard-next-runs"


@dataclass
class TimeSlot:
    """Represents a single time slot (hour:minute)."""

    hour: int = 9
    minute: int = 0

    def __str__(self) -> str:
        """Return time slot as HH:MM string."""
        return f"{self.hour:02d}:{self.minute:02d}"

    def to_cron(self) -> tuple[str, str]:
        """Return (minute, hour) cron values."""
        return (str(self.minute), str(self.hour))


@dataclass
class WizardState:
    """Simplified wizard state."""

    frequency: str = "daily"
    # For interval
    interval_minutes: int = 60
    # For daily/weekly/monthly/yearly
    time_slots: list[TimeSlot] = field(default_factory=lambda: [TimeSlot()])
    # For weekly
    selected_days: set[int] = field(default_factory=lambda: {1})  # Mon default
    # For monthly
    day_of_month: int = 1
    # For yearly
    selected_month: int = 1
    # For custom
    custom_cron: str = ""

    def add_time_slot(self) -> None:
        """Add a new time slot."""
        self.time_slots.append(TimeSlot(hour=9, minute=0))

    def remove_time_slot(self, index: int) -> None:
        """Remove a time slot at index."""
        if len(self.time_slots) > 1 and 0 <= index < len(self.time_slots):
            self.time_slots.pop(index)

    def to_schedule_config(self) -> ScheduleConfig | None:
        """Convert state to ScheduleConfig."""
        if self.frequency == "interval":
            if self.interval_minutes >= 60:
                # For 60+ minutes, we use hour intervals
                hours = self.interval_minutes // 60
                return ScheduleConfig(
                    minute="0",
                    hour=f"*/{hours}",
                    day_of_month="*",
                    month="*",
                    day_of_week="*",
                )
            return ScheduleConfig(
                minute=f"*/{self.interval_minutes}",
                hour="*",
                day_of_month="*",
                month="*",
                day_of_week="*",
            )

        if self.frequency == "custom":
            # Parse custom cron
            parts = self.custom_cron.split()
            if len(parts) == 5:
                return ScheduleConfig(
                    minute=parts[0],
                    hour=parts[1],
                    day_of_month=parts[2],
                    month=parts[3],
                    day_of_week=parts[4],
                )
            return None

        # Build minutes and hours from time slots
        minutes = sorted({slot.minute for slot in self.time_slots})
        hours = sorted({slot.hour for slot in self.time_slots})

        minute_str = ",".join(str(m) for m in minutes) if len(minutes) > 1 else str(minutes[0])
        hour_str = ",".join(str(h) for h in hours) if len(hours) > 1 else str(hours[0])

        if self.frequency == "daily":
            return ScheduleConfig(
                minute=minute_str,
                hour=hour_str,
                day_of_month="*",
                month="*",
                day_of_week="*",
            )

        if self.frequency == "weekly":
            days = sorted(self.selected_days)
            day_str = ",".join(str(d) for d in days)
            return ScheduleConfig(
                minute=minute_str,
                hour=hour_str,
                day_of_month="*",
                month="*",
                day_of_week=day_str,
            )

        if self.frequency == "monthly":
            return ScheduleConfig(
                minute=minute_str,
                hour=hour_str,
                day_of_month=str(self.day_of_month),
                month="*",
                day_of_week="*",
            )

        if self.frequency == "yearly":
            return ScheduleConfig(
                minute=minute_str,
                hour=hour_str,
                day_of_month=str(self.day_of_month),
                month=str(self.selected_month),
                day_of_week="*",
            )

        return None

    def get_human_summary(self) -> str:
        """Get human-readable summary."""
        times_str = ", ".join(str(slot) for slot in self.time_slots)

        if self.frequency == "interval":
            if self.interval_minutes < 60:
                return f"Every {self.interval_minutes} minutes"
            hours = self.interval_minutes // 60
            return f"Every {hours} hour{'s' if hours > 1 else ''}"

        if self.frequency == "daily":
            return f"Daily at {times_str}"

        if self.frequency == "weekly":
            days = [DAY_MAP[d] for d in sorted(self.selected_days)]
            return f"Weekly on {', '.join(days)} at {times_str}"

        if self.frequency == "monthly":
            return f"Monthly on day {self.day_of_month} at {times_str}"

        if self.frequency == "yearly":
            months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
            return f"Yearly on {months[self.selected_month - 1]} {self.day_of_month} at {times_str}"

        if self.frequency == "custom":
            return f"Custom: {self.custom_cron}"

        return "Unknown schedule"


@dataclass
class WizardPreview:
    """Preview data for the wizard."""

    summary: str
    cron: str


class ScheduleTimingWizard(_WizardBase):  # type: ignore[no-redef]
    """Simplified modal wizard for configuring schedule timing.

    This wizard provides a natural language approach to scheduling
    with support for multiple time slots and simplified controls.
    """

    CSS_PATH = "schedules.tcss"

    BINDINGS: list[Binding] = []  # type: ignore[valid-type]

    def __init__(
        self,
        initial: ScheduleConfig | None = None,
        *,
        agent_name: str | None = None,
        action_preview: str | None = None,
    ) -> None:
        """Initialize the wizard.

        Args:
            initial: Optional existing schedule to edit.
            agent_name: Optional agent name for trigger summary.
            action_preview: Optional action preview for trigger summary.
        """
        super().__init__()
        self._initial = initial
        self._agent_name = agent_name
        self._action_preview = action_preview
        self._state = WizardState()
        if initial:
            self._parse_initial_config(initial)
        self._time_slot_count = 0
        self._initialized = False
        self._suppress_state_updates = False
        self._is_syncing = False

    def compose(self) -> ComposeResult:  # type: ignore[override]
        """Compose the simplified wizard UI."""
        if not TEXTUAL_SUPPORTED:
            return  # type: ignore[return-value]

        yield StaticType("Schedule Timing", id="wizard-title")

        with HorizontalType(id="wizard-split-container"):
            with VerticalType(id="wizard-form-panel"):
                yield StaticType("How often should this run?", classes="section-label")
                yield SelectType(
                    [(label, value) for label, value in FREQUENCY_OPTIONS],
                    value=self._state.frequency,
                    id="frequency-select",
                )

                with VerticalScrollType(id="frequency-panels"):
                    with VerticalType(id="panel-interval", classes=FREQ_PANEL_HIDDEN_CLASS):
                        yield StaticType("Run every:", classes="section-label")
                        with HorizontalType(classes="interval-row"):
                            yield InputType(
                                placeholder="60",
                                value="60",
                                id="interval-minutes",
                                classes="interval-input",
                            )
                            yield StaticType("minutes", classes="interval-label")

                    with VerticalType(id="panel-daily", classes=FREQ_PANEL_HIDDEN_CLASS):
                        yield StaticType(AT_WHAT_TIME_LABEL, classes="section-label")
                        yield self._build_time_slots_container()

                    with VerticalType(id="panel-weekly", classes=FREQ_PANEL_HIDDEN_CLASS):
                        yield StaticType("On which days?", classes="section-label")
                        yield self._build_day_checkboxes()
                        yield StaticType(AT_WHAT_TIME_LABEL, classes="section-label")
                        yield self._build_time_slots_container()

                    with VerticalType(id="panel-monthly", classes=FREQ_PANEL_HIDDEN_CLASS):
                        yield StaticType("On which day of the month?", classes="section-label")
                        yield SelectType(
                            [(str(day), day) for day in range(1, 32)],
                            value=1,
                            id="monthly-day",
                        )
                        yield StaticType(AT_WHAT_TIME_LABEL, classes="section-label")
                        yield self._build_time_slots_container()

                    with VerticalType(id="panel-yearly", classes=FREQ_PANEL_HIDDEN_CLASS):
                        yield StaticType("In which month?", classes="section-label")
                        months = [
                            ("January", 1),
                            ("February", 2),
                            ("March", 3),
                            ("April", 4),
                            ("May", 5),
                            ("June", 6),
                            ("July", 7),
                            ("August", 8),
                            ("September", 9),
                            ("October", 10),
                            ("November", 11),
                            ("December", 12),
                        ]
                        yield SelectType(months, value=1, id="yearly-month")
                        yield StaticType("On which day?", classes="section-label")
                        yield SelectType(
                            [(str(day), day) for day in range(1, 32)],
                            value=1,
                            id="yearly-day",
                        )
                        yield StaticType(AT_WHAT_TIME_LABEL, classes="section-label")
                        yield self._build_time_slots_container()

                    with VerticalType(id="panel-custom", classes=FREQ_PANEL_HIDDEN_CLASS):
                        yield StaticType("Enter cron expression:", classes="section-label")
                        yield StaticType(
                            "Format: minute hour day_of_month month day_of_week",
                            classes="help-text",
                        )
                        yield InputType(
                            placeholder="0 9 * * 1-5",
                            id="custom-cron-input",
                        )

            with VerticalType(id="wizard-preview-panel"):
                yield StaticType("Preview", classes="section-label")
                yield StaticType("Timezone: UTC", id="wizard-timezone")
                yield StaticType("", id="wizard-trigger")
                yield StaticType("", id="wizard-summary")
                yield StaticType("", id="wizard-cron-output")
                yield StaticType("", id="wizard-next-runs")

        yield HorizontalType(
            ButtonType("Apply", id="wizard-apply", variant="primary"),
            ButtonType("Cancel", id="wizard-cancel"),
            id="wizard-actions",
        )
        yield StaticType("", id="wizard-status")

    def _build_day_checkboxes(self) -> Any:
        """Build day of week checkboxes."""
        checkboxes = []
        for label, value in DAY_OPTIONS:
            selected = "✓ " if value in self._state.selected_days else ""
            btn_id = f"day-toggle-{value}"
            classes = "day-toggle active" if value in self._state.selected_days else "day-toggle"
            checkboxes.append(ButtonType(f"{selected}{label}", id=btn_id, classes=classes))
        return HorizontalType(*checkboxes, id="day-checkboxes")

    def _build_time_slots_container(self) -> Any:
        children = []
        for i, slot in enumerate(self._state.time_slots):
            slot_row = HorizontalType(
                SelectType(
                    [(f"{h:02d}", h) for h in range(24)],
                    value=slot.hour,
                    id=f"time-slot-hour-{i}",
                    classes="time-select",
                ),
                StaticType(":", classes="time-separator"),
                SelectType(
                    [(f"{m:02d}", m) for m in range(60)],
                    value=slot.minute,
                    id=f"time-slot-minute-{i}",
                    classes="time-select",
                ),
                id=f"time-slot-row-{i}",
                classes="time-slot-row",
            )
            children.append(slot_row)
            self._time_slot_count += 1

        return VerticalType(*children, classes="time-slots-container")

    def on_mount(self) -> None:
        """Initialize wizard state on mount."""
        if not TEXTUAL_SUPPORTED:
            return
        self._suppress_state_updates = True
        if self._initial:
            self._parse_initial_config(self._initial)
        self._sync_frequency_ui()
        self._suppress_state_updates = False
        self._update_summary()
        self.call_later(self._finish_initialization)

    def _finish_initialization(self) -> None:
        self._initialized = True

    def _parse_initial_config(self, config: ScheduleConfig) -> None:
        """Parse initial config into wizard state."""
        if self._try_parse_interval(config):
            return
        self._parse_time_slots(config)
        self._determine_frequency(config)

    def _try_parse_interval(self, config: ScheduleConfig) -> bool:
        """Try to parse as interval schedule. Returns True if successful."""
        if config.minute.startswith("*/") and config.hour == "*":
            self._state.frequency = "interval"
            try:
                self._state.interval_minutes = int(config.minute.replace("*/", ""))
            except ValueError:
                self._state.interval_minutes = 60
            return True
        return False

    def _parse_time_slots(self, config: ScheduleConfig) -> None:
        """Parse time slots from minutes/hours."""
        minutes = self._parse_list_field(config.minute)
        hours = self._parse_list_field(config.hour)
        self._state.time_slots = []
        for hour in hours:
            for minute in minutes:
                self._state.time_slots.append(TimeSlot(hour=hour, minute=minute))
        if not self._state.time_slots:
            self._state.time_slots = [TimeSlot()]

    def _determine_frequency(self, config: ScheduleConfig) -> None:
        """Determine frequency type from config."""
        if config.day_of_week != "*":
            self._state.frequency = "weekly"
            self._state.selected_days = set(self._parse_list_field(config.day_of_week))
        elif config.month != "*":
            self._state.frequency = "yearly"
            try:
                self._state.selected_month = int(config.month)
                self._state.day_of_month = int(config.day_of_month)
            except ValueError:
                pass
        elif config.day_of_month != "*":
            self._state.frequency = "monthly"
            try:
                self._state.day_of_month = int(config.day_of_month)
            except ValueError:
                pass
        else:
            self._state.frequency = "daily"

    def _parse_list_field(self, value: str) -> list[int]:
        """Parse a comma-separated list of integers."""
        if value == "*" or not value:
            return [0]
        result = []
        for part in value.split(","):
            try:
                result.append(int(part.strip()))
            except ValueError:
                pass
        return result if result else [0]

    def _sync_frequency_ui(self) -> None:
        """Show/hide frequency-specific panels."""
        if not TEXTUAL_SUPPORTED or self._is_syncing:
            return

        self._is_syncing = True
        try:
            select = self.query_one("#frequency-select", SelectType)
            select.value = self._state.frequency

            for freq in ["interval", "daily", "weekly", "monthly", "yearly", "custom"]:
                panel = self.query_one(f"#panel-{freq}", VerticalType)
                is_hidden = freq != self._state.frequency
                panel.set_class(is_hidden, "hidden")

            if self._state.frequency == "monthly":
                monthly_day = self.query_one("#monthly-day", SelectType)
                monthly_day.value = self._state.day_of_month
            elif self._state.frequency == "yearly":
                yearly_month = self.query_one("#yearly-month", SelectType)
                yearly_month.value = self._state.selected_month
                self._update_year_day_options(self._state.selected_month)
                yearly_day = self.query_one("#yearly-day", SelectType)
                yearly_day.value = self._state.day_of_month
            elif self._state.frequency in ("daily", "weekly"):
                for idx, slot in enumerate(self._state.time_slots):
                    hour_select = self.query_one(f"#time-slot-hour-{idx}", SelectType)
                    minute_select = self.query_one(f"#time-slot-minute-{idx}", SelectType)
                    hour_select.value = slot.hour
                    minute_select.value = slot.minute
        finally:
            self._is_syncing = False

    def _update_summary(self) -> None:
        """Update the summary display."""
        if not TEXTUAL_SUPPORTED:
            return

        # Trigger info
        agent_label = self._agent_name or "(unknown agent)"
        action_label = self._action_preview or "(set action in form)"
        trigger_text = f"Agent: {agent_label}\nAction: {action_label}\nTimezone: UTC"
        self.query_one("#wizard-trigger", StaticType).update(trigger_text)

        # Human summary
        summary = self._state.get_human_summary()
        self.query_one("#wizard-summary", StaticType).update(summary)

        # Cron output
        config = self._state.to_schedule_config()
        if config:
            cron_str = config.to_cron_string()
            self.query_one("#wizard-cron-output", StaticType).update(f"Cron: {cron_str}")

        else:
            self.query_one("#wizard-cron-output", StaticType).update("")
            self.query_one(WIZARD_NEXT_RUNS_ID, StaticType).update("")

        # Update apply button state
        self._update_apply_state()

    def _update_apply_state(self) -> None:
        """Update the apply button state."""
        if not TEXTUAL_SUPPORTED:
            return

        apply_button = self.query_one("#wizard-apply", ButtonType)
        status_widget = self.query_one("#wizard-status", StaticType)

        if self._state.frequency == "custom" and not self._state.custom_cron:
            apply_button.disabled = True
            status_widget.update("Enter a cron expression.")
            return

        # Validate time slots
        for slot in self._state.time_slots:
            if not (0 <= slot.hour <= 23 and 0 <= slot.minute <= 59):
                apply_button.disabled = True
                status_widget.update("Invalid time value.")
                return

        apply_button.disabled = False
        status_widget.update("")

    def _handle_frequency_select(self, event: Select.Changed) -> None:
        """Handle frequency selection change."""
        new_frequency = str(event.value)
        self._state.frequency = new_frequency
        self._sync_frequency_ui()
        self._update_summary()

    def _handle_monthly_day(self, event: Select.Changed) -> None:
        """Handle monthly day selection change."""
        try:
            new_value = int(event.value)
            if event.select.value != new_value:
                return
            if self._state.day_of_month != new_value:
                self._state.day_of_month = new_value
                self._update_summary()
        except (ValueError, TypeError):
            pass

    def _handle_yearly_month(self, event: Select.Changed) -> None:
        """Handle yearly month selection change."""
        try:
            month = int(event.value)
            if event.select.value != month:
                return
            if self._state.selected_month != month:
                self._state.selected_month = month
                self._update_year_day_options(month)
                self._update_summary()
        except (ValueError, TypeError):
            pass

    def _handle_yearly_day(self, event: Select.Changed) -> None:
        """Handle yearly day selection change."""
        try:
            new_value = int(event.value)
            if event.select.value != new_value:
                return
            if self._state.day_of_month != new_value:
                self._state.day_of_month = new_value
                self._update_summary()
        except (ValueError, TypeError):
            pass

    def _handle_time_slot_hour(self, event: Select.Changed) -> None:
        """Handle time slot hour selection change."""
        try:
            idx = int(event.select.id.split("-")[-1])
            if 0 <= idx < len(self._state.time_slots):
                if event.value is None or event.value == Select.BLANK:
                    return
                new_hour = int(event.value)
                if event.select.value != new_hour:
                    return
                if self._state.time_slots[idx].hour != new_hour:
                    self._state.time_slots[idx].hour = new_hour
                    self._update_summary()
        except (ValueError, IndexError):
            pass

    def _handle_time_slot_minute(self, event: Select.Changed) -> None:
        """Handle time slot minute selection change."""
        try:
            idx = int(event.select.id.split("-")[-1])
            if 0 <= idx < len(self._state.time_slots):
                if event.value is None or event.value == Select.BLANK:
                    return
                new_minute = int(event.value)
                if event.select.value != new_minute:
                    return
                if self._state.time_slots[idx].minute != new_minute:
                    self._state.time_slots[idx].minute = new_minute
                    self._update_summary()
        except (ValueError, IndexError):
            pass

    def on_select_changed(self, event: Select.Changed) -> None:  # type: ignore[override]
        """Handle select widget changes."""
        if not TEXTUAL_SUPPORTED:
            return

        if self._suppress_state_updates or not self._initialized:
            return

        select_id = event.select.id or ""
        handlers = {
            "frequency-select": self._handle_frequency_select,
            "monthly-day": self._handle_monthly_day,
            "yearly-month": self._handle_yearly_month,
            "yearly-day": self._handle_yearly_day,
        }

        if select_id in handlers:
            handlers[select_id](event)
        elif select_id.startswith("time-slot-hour-"):
            self._handle_time_slot_hour(event)
        elif select_id.startswith("time-slot-minute-"):
            self._handle_time_slot_minute(event)

    def on_input_changed(self, event: Input.Changed) -> None:  # type: ignore[override]
        """Handle input changes."""
        if not TEXTUAL_SUPPORTED:
            return

        if event.input.id == "interval-minutes":
            try:
                self._state.interval_minutes = int(event.value) if event.value else 60
            except ValueError:
                pass
            self._update_summary()
        elif event.input.id == "custom-cron-input":
            self._state.custom_cron = event.value
            self._update_summary()

    def on_button_pressed(self, event: Button.Pressed) -> None:  # type: ignore[override]
        """Handle button actions."""
        if not TEXTUAL_SUPPORTED:
            return

        btn_id = event.button.id or ""

        if btn_id == "wizard-cancel":
            self.dismiss(None)
            return

        if btn_id == "wizard-apply":
            self.action_apply()
            return

        if btn_id.startswith("day-toggle-"):
            try:
                day = int(btn_id.split("-")[-1])
                if day in self._state.selected_days:
                    self._state.selected_days.remove(day)
                else:
                    self._state.selected_days.add(day)
                self._refresh_day_checkboxes()
                self._update_summary()
            except ValueError:
                pass

    def _refresh_day_checkboxes(self) -> None:
        if not TEXTUAL_SUPPORTED:
            return

        for label, value in DAY_OPTIONS:
            btn = self.query_one(f"#day-toggle-{value}", ButtonType)
            selected = value in self._state.selected_days
            btn.label = f"{'✓ ' if selected else ''}{label}"
            btn.set_class(selected, "active")

    def _update_year_day_options(self, month: int) -> None:
        if not TEXTUAL_SUPPORTED:
            return

        days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        max_day = days_in_month[month - 1]

        day_select = self.query_one("#yearly-day", SelectType)
        current_value = day_select.value
        if current_value and str(current_value).isdigit():
            current_day = int(current_value)
        else:
            current_day = self._state.day_of_month

        if current_day > max_day:
            current_day = max_day

        day_select.set_options([(str(day), day) for day in range(1, max_day + 1)])
        day_select.value = current_day

    def action_apply(self) -> None:
        """Validate and apply configuration."""
        config = self._state.to_schedule_config()
        if config is None:
            return

        self.dismiss(config)


ScheduleTimingWizardModal = ScheduleTimingWizard
