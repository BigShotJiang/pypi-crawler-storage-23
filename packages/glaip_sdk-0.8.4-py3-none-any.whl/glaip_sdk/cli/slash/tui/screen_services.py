"""Shared service bootstrap helpers for TUI screens.

This module provides common utilities for initializing TUI services
(keybinds, toasts, clipboard) across different Harlequin screens.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from collections.abc import Callable

from glaip_sdk.cli.slash.tui.clipboard import ClipboardAdapter
from glaip_sdk.cli.slash.tui.context import TUIContext
from glaip_sdk.cli.slash.tui.keybind_registry import KeybindRegistry
from glaip_sdk.cli.slash.tui.terminal import TerminalCapabilities
from glaip_sdk.cli.slash.tui.toast import ToastBus


def ensure_context_services(
    ctx: TUIContext,
    notify: Callable[[ToastBus.Changed], None],
) -> tuple[KeybindRegistry | None, ToastBus | None, ClipboardAdapter]:
    """Ensure the context has keybinds, toasts, and clipboard services.

    Args:
        ctx: The TUI context to initialize services in
        notify: Callback for toast notifications

    Returns:
        Tuple of (keybind_registry, toast_bus, clipboard_adapter)
    """
    if ctx.keybinds is None:
        ctx.keybinds = KeybindRegistry()
    if ctx.toasts is None:
        ctx.toasts = ToastBus(on_change=notify)
    if ctx.clipboard is None:
        ctx.clipboard = ClipboardAdapter(terminal=ctx.terminal)
    return ctx.keybinds, ctx.toasts, ctx.clipboard


def initialize_fallback_services(
    notify: Callable[[ToastBus.Changed], None],
) -> tuple[KeybindRegistry | None, ToastBus | None, ClipboardAdapter]:
    """Create fallback clipboard and toast services without a context.

    Args:
        notify: Callback for toast notifications

    Returns:
        Tuple of (None, toast_bus, clipboard_adapter)
    """
    terminal = TerminalCapabilities(tty=True, ansi=True, osc52=False, osc11_bg=None, mouse=False, truecolor=False)
    clipboard = ClipboardAdapter(terminal=terminal)
    toast_bus = ToastBus(on_change=notify)
    return None, toast_bus, clipboard


def wire_toast_notifications(toast_bus: ToastBus | None, notify: Callable[[ToastBus.Changed], None]) -> None:
    """Ensure toast bus forwards notifications to the provided callback.

    Args:
        toast_bus: The toast bus to wire up
        notify: Callback for toast notifications
    """
    if toast_bus is None:
        return
    toast_bus.subscribe(notify)
