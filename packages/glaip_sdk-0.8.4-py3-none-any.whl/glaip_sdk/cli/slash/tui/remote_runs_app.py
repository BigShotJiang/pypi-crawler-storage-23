"""Textual UI for the /runs command.

This module provides a Harlequin layout screen for browsing remote runs with
an always-visible detail pane and transcript panel.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, cast

from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text
from textual import events
from textual._context import NoActiveAppError
from textual.app import App, ComposeResult, ScreenStackError
from textual.binding import Binding
from textual.containers import Container, Horizontal, ScrollableContainer
from textual.coordinate import Coordinate
from textual.screen import Screen
from textual.widgets import DataTable, Footer, Input, RichLog, Static, TextArea

from glaip_sdk.cli.slash.tui.background_tasks import BackgroundTaskMixin
from glaip_sdk.cli.slash.tui.clipboard import ClipboardAdapter
from glaip_sdk.cli.slash.tui.context import TUIContext
from glaip_sdk.cli.slash.tui.indicators import PulseIndicator
from glaip_sdk.cli.slash.tui.layouts.harlequin import HarlequinScreen
from glaip_sdk.cli.slash.tui.loading import hide_loading_indicator, show_loading_indicator
from glaip_sdk.cli.slash.tui.toast import ClipboardToastMixin, ToastBus, ToastHandlerMixin
from glaip_sdk.exceptions import APIError, AuthenticationError, ForbiddenError, NotFoundError, ValidationError

logger = logging.getLogger(__name__)

RUNS_TABLE_ID = "runs-table"
RUNS_FILTER_ID = "runs-filter"
RUNS_LOADING_ID = "runs-loading"
RUNS_STATUS_ID = "runs-status"
RUNS_DETAIL_META_ID = "runs-detail-meta"
RUNS_DETAIL_INPUT_ID = "runs-detail-input"
RUNS_DETAIL_FINAL_RESPONSE_ID = "runs-detail-final-response"
RUNS_DETAIL_TRANSCRIPT_ID = "runs-detail-transcript"
RUNS_LOADING_SELECTOR = f"#{RUNS_LOADING_ID}"
RUNS_SELECT_FIRST_MESSAGE = "Select a run first."
RUN_ID_LABEL = "Run ID"
RUNS_DETAIL_LOG_MESSAGE = "Failed to load run detail %s: %s"
RUNS_RUN_JSON_LABEL = "Run JSON"
TRANSCRIPT_ASYNC_THRESHOLD = 50
RUNS_RETRY_BACKOFF_SECONDS = (0.25, 0.75, 1.5)
RUNS_NO_TRANSCRIPT_MESSAGE = "No transcript available."


@dataclass
class RemoteRunsTUICallbacks:
    """Callbacks invoked by the Textual UI for data operations."""

    fetch_page: Callable[[int, int], Any | None]
    fetch_detail: Callable[[str], Any | None]
    export_run: Callable[[str, Any | None], bool]


def run_remote_runs_textual(
    initial_page: Any,
    cursor_idx: int,
    callbacks: RemoteRunsTUICallbacks,
    *,
    agent_name: str | None = None,
    agent_id: str | None = None,
    ctx: TUIContext | None = None,
) -> tuple[int, int, int]:
    """Launch the Textual application and return the final pagination state.

    Args:
        initial_page: RunsPage instance loaded before launching the UI.
        cursor_idx: Previously selected row index.
        callbacks: Data provider callback bundle.
        agent_name: Optional agent name for display purposes.
        agent_id: Optional agent ID for display purposes.
        ctx: Shared TUI context.

    Returns:
        Tuple of (page, limit, cursor_index) after the UI exits.
    """
    app = _HarlequinRunsApp(
        initial_page,
        cursor_idx,
        callbacks,
        agent_name=agent_name,
        agent_id=agent_id,
        ctx=ctx,
    )
    # Enable mouse capture for scrolling within the detail panes.
    app.run(mouse=True)
    try:
        screen = app.screen
    except ScreenStackError:
        screen = None
    if isinstance(screen, RunsHarlequinScreen):
        current_page = screen.current_page
        cursor_index = screen.cursor_index
        limit = getattr(screen, "_limit", current_page.limit)
    else:
        current_page = getattr(app, "current_page", None) or initial_page
        cursor_index = getattr(app, "cursor_index", None)
        if cursor_index is None:
            cursor_index = cursor_idx
        limit = current_page.limit
    return current_page.page, limit, cursor_index


class RunsHarlequinScreen(ToastHandlerMixin, ClipboardToastMixin, BackgroundTaskMixin, HarlequinScreen):
    """Harlequin layout screen for browsing remote runs."""

    BINDINGS = [
        Binding("left", "page_left", "Prev page", priority=True),
        Binding("right", "page_right", "Next page", priority=True),
        Binding("pageup", "transcript_page_up", "Transcript Up", priority=True),
        Binding("pagedown", "transcript_page_down", "Transcript Down", priority=True),
        Binding("c", "copy_run_id", "Copy Run ID", priority=True, show=False),
        Binding("i", "copy_input", "Copy Input", priority=True, show=False),
        Binding("r", "copy_final_response", "Copy Final Response", priority=True, show=False),
        Binding("t", "copy_transcript", "Copy Transcript", priority=True, show=False),
        Binding("C", "copy_detail_json", "Copy Run JSON", priority=True, show=False),
        Binding("e", "export_run", "Export", priority=True),
        Binding("/", "focus_filter", "Filter", priority=True),
        Binding("escape", "clear_or_exit", "Close", priority=True),
        Binding("q", "app_exit", "Quit", priority=True),
    ]

    @staticmethod
    def _copy_hint(key: str) -> Text:
        # Use bold yellow to make hints stand out without complex animation
        return Text(f"(copy: {key})", style="bold yellow reverse")

    CSS = """
    RunsHarlequinScreen {
        layers: base toasts;
    }

    #toast-container {
        width: auto;
        height: auto;
        dock: top;
        align: right top;
        layer: toasts;
    }

    #harlequin-container {
        height: 100%;
    }

    #left-pane {
        width: 40%;
        min-width: 38;
        padding: 1;
    }

    #right-pane {
        width: 60%;
        padding: 1;
    }

    #right-pane-body {
        height: 100%;
        overflow-y: auto;
        scrollbar-size: 1 1;
        scrollbar-color: $accent;
    }

    .pane-title {
        color: $warning;
        text-style: bold;
        padding-bottom: 1;
    }

    .section-title {
        color: $warning;
        text-style: bold;
        padding-top: 1;
        padding-bottom: 1;
    }

    .detail-block {
        padding-bottom: 1;
    }

    .detail-input {
        border: solid $secondary;
        padding: 1;
        margin-bottom: 1;
        height: auto;
        min-height: 3;
    }

    .detail-final-response {
        border: solid $secondary;
        padding: 1;
        margin-bottom: 1;
        height: auto;
        min-height: 3;
    }

    .step-list {
        border: solid $secondary;
        padding: 1;
        height: auto;
        min-height: 5;
    }

    .status-bar {
        height: 5;
        align: left middle;
        padding-top: 1;
        margin-bottom: 1;
    }

    .status-line {
        color: $text-muted;
    }

    .filter-input {
        height: 3;
        margin: 0 1;
        border: solid $accent;
    }

    #runs-table {
        height: 1fr;
    }
    """

    def __init__(
        self,
        initial_page: Any,
        cursor_idx: int,
        callbacks: RemoteRunsTUICallbacks,
        *,
        agent_name: str | None = None,
        agent_id: str | None = None,
        ctx: TUIContext | None = None,
    ) -> None:
        """Initialize the Harlequin runs screen."""
        super().__init__(ctx=ctx)
        self.current_page = initial_page
        self.cursor_index = max(0, min(cursor_idx, max(len(initial_page.data) - 1, 0)))
        self._runs_callbacks = callbacks
        self._agent_name = (agent_name or "").strip()
        self._agent_id = (agent_id or "").strip()
        self._ctx = ctx
        self._clip_cache: ClipboardAdapter | None = None
        self._local_toasts: ToastBus | None = None
        self._detail_cache: dict[str, Any] = {}
        self._page_loader_task: asyncio.Task[Any] | None = None
        self._detail_loader_task: asyncio.Task[None] | None = None
        self._detail_loading_id: str | None = None
        self._current_rows: list[Any] = initial_page.data[:]
        self._visible_rows: list[Any] = []
        self._filter_text = ""
        self._limit = initial_page.limit
        self._transcript_render_task: asyncio.Task[None] | None = None
        self._transcript_render_token = 0
        # Initial safe default, but we'll recalculate on mount/resize
        self._preview_limit = 45
        self._initial_load_complete = False

    def compose(self) -> ComposeResult:
        """Compose the Harlequin layout and footer."""
        yield from super().compose()
        yield Footer()

    def on_mount(self) -> None:
        """Populate panes with run list and detail widgets."""
        # Defensive: on_mount may be delivered more than once in some flows.
        # Make it idempotent to avoid DuplicateIds when mounting widgets.
        if getattr(self, "_did_mount", False):
            return
        self._did_mount = True

        # Additional guard: if we already created the table, don't mount again.
        if hasattr(self, "_runs_table"):
            return
        query_one = cast(Any, self).query_one
        left_pane = query_one("#left-pane")
        right_pane = query_one("#right-pane")

        self._page_title = Static("Run History", classes="pane-title")
        self._agent_label = Static(self._agent_context_label(), classes="section-title")
        self._runs_table = DataTable(id=RUNS_TABLE_ID, cursor_type="row", zebra_stripes=True)
        self._runs_table.add_column("St", width=4)
        self._runs_table.add_column("Started (UTC)", width=13)
        self._runs_table.add_column("Input")
        self._filter_input = Input(placeholder="Filter input...", id=RUNS_FILTER_ID, classes="filter-input")
        self._filter_input.display = False
        self._loading_indicator = PulseIndicator(id=RUNS_LOADING_ID)
        self._status_line = Static("", id=RUNS_STATUS_ID, classes="status-line")
        self._status_bar = Horizontal(self._loading_indicator, self._status_line, classes="status-bar")

        left_pane.mount(self._page_title)
        left_pane.mount(self._agent_label)
        left_pane.mount(self._runs_table)
        left_pane.mount(self._filter_input)
        left_pane.mount(self._status_bar)

        self._detail_title = Static("Run Detail", classes="pane-title")
        self._detail_meta = Static("", id=RUNS_DETAIL_META_ID, classes="detail-block")
        self._input_title = Static(
            Text.assemble("Input ", self._copy_hint("i")),
            classes="section-title",
        )
        self._input_body = TextArea(
            "",
            id=RUNS_DETAIL_INPUT_ID,
            read_only=True,
            show_line_numbers=False,
            classes="detail-input",
        )
        self._input_body.can_focus = True
        self._final_response_title = Static(
            Text.assemble("Final Response ", self._copy_hint("r")),
            classes="section-title",
        )
        self._final_response_body = TextArea(
            "",
            id=RUNS_DETAIL_FINAL_RESPONSE_ID,
            read_only=True,
            show_line_numbers=False,
            classes="detail-final-response",
        )
        self._final_response_body.can_focus = True
        self._transcript_title = Static(
            Text.assemble("Transcript ", self._copy_hint("t")),
            classes="section-title",
        )
        self._transcript_log = RichLog(id=RUNS_DETAIL_TRANSCRIPT_ID, wrap=False, classes="step-list")
        self._transcript_log.can_focus = True

        self._right_pane_body = ScrollableContainer(id="right-pane-body")
        right_pane.mount(self._right_pane_body)
        self._right_pane_body.mount(self._detail_title)
        self._right_pane_body.mount(self._detail_meta)
        self._right_pane_body.mount(self._input_title)
        self._right_pane_body.mount(self._input_body)
        self._right_pane_body.mount(self._final_response_title)
        self._right_pane_body.mount(self._final_response_body)
        self._right_pane_body.mount(self._transcript_title)
        self._right_pane_body.mount(self._transcript_log)

        self._ensure_toast_bus()
        try:
            app = self.app
        except NoActiveAppError:
            app = None
        if app is not None:
            self._calculate_preview_limit(app.size.width)
            self.call_after_refresh(self._check_dynamic_page_size)
        self._render_page()

    def on_resize(self, event: events.Resize) -> None:
        """Recalculate layout limits on resize."""
        self._calculate_preview_limit(event.size.width)
        self._calculate_page_size(event.size.height)
        self._render_page()

    def _check_dynamic_page_size(self) -> None:
        """Check if we need to reload with a better page size on startup."""
        if self._initial_load_complete:
            return
        self._initial_load_complete = True
        app = getattr(self, "app", None)
        if app:
            self._calculate_page_size(app.size.height, reload_if_needed=True)

    def _calculate_preview_limit(self, screen_width: int) -> None:
        """Calculate input preview limit to avoid horizontal scrolling."""
        if screen_width <= 0:
            return
        # Left pane is 40%. Fixed cols use roughly 4+13+margins ~= 23 chars.
        # We leave a buffer for borders and scrollbars (~4 chars).
        # Calculation: (screen_width * 0.4) - 23 - 4
        left_pane_width = int(screen_width * 0.4)
        available = left_pane_width - 27
        # Ensure a reasonable minimum (e.g. 20 chars) and maximum (e.g. 150)
        self._preview_limit = max(20, min(available, 150))

    def _calculate_page_size(self, screen_height: int, reload_if_needed: bool = False) -> None:
        """Calculate optimal page size based on height."""
        if screen_height <= 0:
            return
        # Overhead: Title(2) + Agent(3) + Filter(0 or 3) + Status(3) + Header(1) + Borders/Pad(~2)
        # Total overhead approx 11-14 lines.
        overhead = 12
        available_lines = max(1, screen_height - overhead)

        if available_lines != self._limit:
            self._limit = available_lines
            if reload_if_needed and available_lines > self.current_page.limit:
                self._queue_page_load(self.current_page.page, "Adjusting view...", "Failed to adjust view.")

    def on_key(self, event: events.Key) -> None:
        """Route left/right navigation to paging instead of table scroll."""
        filter_input = getattr(self, "_filter_input", None)
        if event.key == "left" and (filter_input is None or not filter_input.has_focus):
            self.action_page_left()
            event.stop()
        if event.key == "right" and (filter_input is None or not filter_input.has_focus):
            self.action_page_right()
            event.stop()
        if event.key == "escape" and filter_input is not None:
            if filter_input.has_focus or filter_input.display:
                self.action_clear_filter()
                event.stop()

    def on_mouse_scroll_up(self, event: events.MouseScrollUp) -> None:
        """Let standard scrolling happen."""
        pass

    def on_mouse_scroll_down(self, event: events.MouseScrollDown) -> None:
        """Let standard scrolling happen."""
        pass

    def on_mouse_down(self, event: events.MouseDown) -> None:
        """Let standard click focus happen."""
        pass

    def on_input_changed(self, event: Input.Changed) -> None:
        """Filter rows as user types."""
        if event.input.id != RUNS_FILTER_ID:
            return
        self._filter_text = event.value.strip().lower()
        self._render_page()

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        """Update the detail pane when selection changes."""
        if event.data_table.id != RUNS_TABLE_ID:
            return
        self.cursor_index = event.cursor_row
        self._render_detail(event.cursor_row)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Show detail when a row is selected."""
        if event.data_table.id != RUNS_TABLE_ID:
            return
        self.cursor_index = event.cursor_row
        self._render_detail(event.cursor_row)

    def action_page_left(self) -> None:
        """Move to the previous page."""
        if not self.current_page.has_prev:
            self._set_status("Already on the first page.")
            return
        target_page = max(1, self.current_page.page - 1)
        self._queue_page_load(target_page, "Loading previous page...", "Failed to load previous page.")

    def action_page_right(self) -> None:
        """Move to the next page."""
        if not self.current_page.has_next:
            self._set_status("This is the last page.")
            return
        target_page = self.current_page.page + 1
        self._queue_page_load(target_page, "Loading next page...", "Failed to load next page.")

    def action_transcript_page_up(self) -> None:
        """Scroll the transcript up one page."""
        self._transcript_log.scroll_visible(animate=False)
        self._transcript_log.action_page_up()

    def action_transcript_page_down(self) -> None:
        """Scroll the transcript down one page."""
        self._transcript_log.scroll_visible(animate=False)
        self._transcript_log.action_page_down()

    def action_focus_filter(self) -> None:
        """Focus the filter input."""
        if not hasattr(self, "_filter_input"):  # pragma: no cover - defensive
            return
        self._filter_input.display = True
        self._filter_input.focus()

    def action_clear_filter(self) -> None:
        """Clear filter and return focus to table."""
        if not hasattr(self, "_filter_input"):  # pragma: no cover - defensive
            return
        if self._filter_input.has_focus or self._filter_input.display:
            self._filter_input.value = ""
            self._filter_text = ""
            self._filter_input.display = False
            if hasattr(self, "_runs_table"):
                self._runs_table.focus()
            self._render_page()

    def action_clear_or_exit(self) -> None:
        """Clear filter when active, otherwise close the screen."""
        filter_input = getattr(self, "_filter_input", None)
        if filter_input is not None and (filter_input.has_focus or filter_input.display or self._filter_text):
            self.action_clear_filter()
            return
        self.action_app_exit()

    def action_app_exit(self) -> None:
        """Exit the parent app."""
        app = None
        try:
            app = cast(Any, self).app
        except Exception:
            pass
        if app is not None:
            app.exit()

    def action_copy_run_id(self) -> None:
        """Copy the run id to the clipboard."""
        run = self._current_run()
        if run is None:
            self._set_status(RUNS_SELECT_FIRST_MESSAGE)
            return
        self._copy_to_clipboard(str(run.id), label=RUN_ID_LABEL)

    def action_copy_input(self) -> None:
        """Copy the full input to the clipboard."""
        run = self._current_run()
        if run is None:
            self._set_status(RUNS_SELECT_FIRST_MESSAGE)
            return
        text = getattr(run, "input", "") or ""
        if not text:
            self._set_status("No input to copy.")
            return
        self._copy_to_clipboard(str(text), label="Input")

    def action_copy_final_response(self) -> None:
        """Copy the final response to the clipboard."""
        run = self._current_run()
        if run is None:
            self._set_status(RUNS_SELECT_FIRST_MESSAGE)
            return
        run_id = str(run.id)
        detail = self._detail_cache.get(run_id)
        if detail is None:
            self._set_status("Run detail not loaded.")
            return
        final_response = self._extract_final_response(detail)
        if not final_response:
            self._set_status("No final response available.")
            return
        self._copy_to_clipboard(final_response, label="Final Response")

    def action_copy_transcript(self) -> None:
        """Copy the transcript to the clipboard."""
        run = self._current_run()
        if run is None:
            self._set_status(RUNS_SELECT_FIRST_MESSAGE)
            return
        run_id = str(run.id)
        detail = self._detail_cache.get(run_id)
        if detail is None:
            self._set_status("Transcript not loaded.")
            return

        output = getattr(detail, "output", []) or []
        if not output:
            self._set_status("No transcript to copy.")
            return

        if self._should_async_transcript(output):
            self._set_status("Preparing transcript...")
            try:
                self.track_task(self._copy_transcript_async(list(output)))
            except RuntimeError:
                payload = json.dumps(output, indent=2, ensure_ascii=False, default=str)
                self._copy_to_clipboard(payload, label="Transcript")
            return

        try:
            payload = json.dumps(output, indent=2, ensure_ascii=False, default=str)
            self._copy_to_clipboard(payload, label="Transcript")
        except Exception as exc:
            self._set_status(f"Failed to serialize transcript: {exc}")

    def action_copy_detail_json(self) -> None:
        """Copy the run detail JSON to the clipboard."""
        run = self._current_run()
        if run is None:
            self._set_status(RUNS_SELECT_FIRST_MESSAGE)
            return
        detail = self._get_or_load_detail(str(run.id))
        if detail is None:
            self._set_status("Run detail unavailable.")
            return
        output = self._detail_output(detail)
        if self._should_async_transcript(output):
            self._set_status("Preparing run JSON...")
            try:
                self.track_task(self._copy_detail_json_async(detail))
            except RuntimeError:
                payload = self._detail_json_payload(detail)
                if payload is None:
                    return
                self._copy_to_clipboard(payload, label=RUNS_RUN_JSON_LABEL)
            return
        payload = self._detail_json_payload(detail)
        if payload is None:
            return
        self._copy_to_clipboard(payload, label=RUNS_RUN_JSON_LABEL)

    def action_export_run(self) -> None:
        """Export the selected run via callback."""
        run = self._current_run()
        if run is None:
            self._set_status(RUNS_SELECT_FIRST_MESSAGE)
            return
        run_id = str(run.id)
        detail = self._get_or_load_detail(run_id)
        if detail is None:
            self._set_status("Failed to load run detail for export.")
            return
        self._queue_export_job(run_id, detail)

    def _render_page(self) -> None:
        """Render the run list and refresh the detail pane."""
        self._runs_table.clear()
        self._current_rows = self.current_page.data[:]
        self._visible_rows = [run for run in self._current_rows if self._matches_filter(run)]
        for run in self._visible_rows:
            self._runs_table.add_row(
                Text(self._status_label(str(run.status)), style=self._status_style(str(run.status))),
                self._format_started(getattr(run, "started_at", None)),
                self._input_preview(run),
            )

        if self._visible_rows:
            self.cursor_index = max(0, min(self.cursor_index, len(self._visible_rows) - 1))
            self._runs_table.cursor_coordinate = Coordinate(self.cursor_index, 0)
            if not self._filter_input.has_focus:
                self._runs_table.focus()
            self._render_detail(self.cursor_index)
        else:
            self._clear_detail()

        total_pages = max(1, (self.current_page.total + self.current_page.limit - 1) // self.current_page.limit)
        filter_suffix = f" | Filter: '{self._filter_text}'" if self._filter_text else ""
        page_title = (
            "Run History "
            f"(Page {self.current_page.page}/{total_pages} | "
            f"Page size={self.current_page.limit}{filter_suffix})"
        )
        self._page_title.update(page_title)
        self._set_status("")
        self._hide_loading()

    def _render_detail(self, row_index: int) -> None:
        """Render the detail pane for the selected row."""
        run = self._get_row(row_index)
        if run is None:
            self._clear_detail()
            return
        run_id = str(run.id)
        detail = self._detail_cache.get(run_id)

        detail_table = Table.grid(padding=(0, 1))
        detail_table.add_column(style="bold cyan", no_wrap=True)
        detail_table.add_column()
        detail_table.add_row(RUN_ID_LABEL, Text.assemble(run_id, " ", self._copy_hint("c")))
        detail_table.add_row("Agent ID", str(getattr(run, "agent_id", "-")))
        detail_table.add_row("Type", str(getattr(run, "run_type", "-")).title())
        status_value = str(getattr(run, "status", "-")).upper()
        detail_table.add_row("Status", Text(status_value, style=self._status_style(status_value)))
        detail_table.add_row("Started (UTC)", self._format_timestamp(getattr(run, "started_at", None)))
        detail_table.add_row("Completed (UTC)", self._format_timestamp(getattr(run, "completed_at", None)))
        detail_table.add_row("Duration", self._format_duration(getattr(run, "duration_formatted", None)))
        self._detail_meta.update(detail_table)
        self._update_input_body(getattr(run, "input", None) or "-")
        self._update_final_response_body(detail)

        if detail is not None:
            self._update_transcript(detail)
        else:
            self._update_transcript(None)
            self._queue_detail_load(run_id)

    def _clear_detail(self) -> None:
        """Clear the detail pane when no rows are visible."""
        self._detail_meta.update("No runs available.")
        self._update_input_body("")
        self._final_response_body.text = ""
        self._transcript_log.clear()
        self._transcript_render_token += 1
        self._transcript_log.write(RUNS_NO_TRANSCRIPT_MESSAGE)

    def _update_input_body(self, text: str) -> None:
        self._input_body.text = text or ""

    def _extract_final_response(self, detail: Any) -> str | None:
        """Extract final response content from run detail output.

        Args:
            detail: Run detail object containing output events.

        Returns:
            The final response content string, or None if not found.
        """
        output = self._detail_output(detail)
        if not output or not isinstance(output, list):
            return None

        for event in output:
            if not isinstance(event, dict):
                continue
            if not self._is_final_response_event(event):
                continue
            content = self._event_content(event)
            if content is not None:
                return content

        return None

    @staticmethod
    def _event_content(event: dict[str, Any]) -> str | None:
        content = event.get("content")
        if not content:
            return None
        return str(content)

    @staticmethod
    def _is_final_response_event(event: dict[str, Any]) -> bool:
        if event.get("event_type") == "final_response":
            return True
        metadata = event.get("metadata")
        if isinstance(metadata, dict) and metadata.get("kind") == "final_response":
            return True
        return event.get("final") is True

    def _update_final_response_body(self, detail: Any | None) -> None:
        """Update the final response body widget with extracted content.

        Args:
            detail: Run detail object, or None if not loaded.
        """
        if detail is None:
            self._final_response_body.text = "Loading final response..."
            return
        final_response = self._extract_final_response(detail)
        if final_response:
            self._final_response_body.text = final_response
        else:
            self._final_response_body.text = "No final response available."

    def _queue_page_load(self, page: int, loading_message: str, failure_message: str) -> None:
        if self._page_loader_task and not self._page_loader_task.done():
            self._set_status("Already loading a page. Please wait.")
            return
        self._show_loading(loading_message, footer_message=False)
        try:
            task = self.track_task(self._load_page_async(page, self._limit, failure_message))
            self._page_loader_task = task
        except RuntimeError:
            self._load_page_sync(page, self._limit, failure_message)

    async def _load_page_async(self, page: int, limit: int, failure_message: str) -> None:
        current_task = asyncio.current_task()
        try:
            new_page = await self._fetch_with_retry_async(
                lambda: self._runs_callbacks.fetch_page(page, limit),
                failure_label=f"Failed to fetch runs page {page}",
            )
        finally:
            if self._page_loader_task is current_task:
                self._page_loader_task = None
            self._hide_loading()

        if new_page is None:
            self._set_status(failure_message)
            return
        self.current_page = new_page
        self._limit = new_page.limit
        self.cursor_index = 0
        self._render_page()

    def _load_page_sync(self, page: int, limit: int, failure_message: str) -> None:
        try:
            new_page = self._fetch_with_retry_sync(
                lambda: self._runs_callbacks.fetch_page(page, limit),
                failure_label=f"Failed to fetch runs page {page}",
            )
        finally:
            self._page_loader_task = None
            self._hide_loading()

        if new_page is None:
            self._set_status(failure_message)
            return
        self.current_page = new_page
        self._limit = new_page.limit
        self.cursor_index = 0
        self._render_page()

    def _queue_detail_load(self, run_id: str) -> None:
        if self._detail_loading_id == run_id and self._detail_loader_task and not self._detail_loader_task.done():
            return
        self._detail_loading_id = run_id
        self._show_loading("Loading run detail...", footer_message=False)
        try:
            task = self.track_task(self._load_detail_async(run_id))
            self._detail_loader_task = task
        except RuntimeError:
            self._load_detail_sync(run_id)

    async def _load_detail_async(self, run_id: str) -> None:
        current_task = asyncio.current_task()

        def _is_stale() -> bool:
            return self._detail_loading_id is not None and self._detail_loading_id != run_id

        try:
            detail = await self._fetch_with_retry_async(
                lambda: self._runs_callbacks.fetch_detail(run_id),
                failure_label=f"Failed to fetch run detail {run_id}",
                stale_check=_is_stale,
            )
        finally:
            if self._detail_loader_task is current_task:
                self._detail_loader_task = None
            if self._detail_loading_id in (None, run_id):
                self._hide_loading()
        if _is_stale():
            return
        self._handle_detail_loaded(run_id, detail)

    def _load_detail_sync(self, run_id: str) -> None:
        def _is_stale() -> bool:
            return self._detail_loading_id is not None and self._detail_loading_id != run_id

        try:
            detail = self._fetch_with_retry_sync(
                lambda: self._runs_callbacks.fetch_detail(run_id),
                failure_label=f"Failed to fetch run detail {run_id}",
                stale_check=_is_stale,
            )
        finally:
            self._detail_loader_task = None
            if self._detail_loading_id in (None, run_id):
                self._hide_loading()
        if _is_stale():
            return
        self._handle_detail_loaded(run_id, detail)

    def _handle_detail_loaded(self, run_id: str, detail: Any | None) -> None:
        if self._detail_loading_id in (None, run_id):
            self._detail_loading_id = None
        if detail is None:
            self._set_status("Failed to load run detail.")
            selected = self._current_run()
            if selected and str(selected.id) == run_id:
                self._transcript_log.clear()
                self._transcript_log.write("Failed to load run detail.")
            return
        self._detail_cache[run_id] = detail
        selected = self._current_run()
        if selected and str(selected.id) == run_id:
            self._update_final_response_body(detail)
            self._update_transcript(detail)

    @staticmethod
    def _is_retryable_fetch_error(exc: Exception) -> bool:
        if isinstance(exc, (AuthenticationError, ForbiddenError, NotFoundError, ValidationError)):
            return False
        if isinstance(exc, APIError):
            status_code = getattr(exc, "status_code", None)
            if isinstance(status_code, int) and 400 <= status_code < 500 and status_code not in (408, 429):
                return False
            return True
        return True

    @staticmethod
    def _retry_attempts() -> int:
        return len(RUNS_RETRY_BACKOFF_SECONDS) + 1

    def _retry_message(self, *, subject: str, attempt: int) -> str:
        retries = self._retry_attempts() - 1
        return f"{subject}; retrying ({attempt}/{retries})..."

    def _retry_delay(
        self,
        *,
        attempt: int,
        attempts: int,
        error: Exception | None,
        failure_label: str,
    ) -> float | None:
        if error is not None and not self._is_retryable_fetch_error(error):
            logger.exception("%s", failure_label, exc_info=error)
            return None
        if attempt >= attempts:
            if error is not None:
                logger.exception("%s", failure_label, exc_info=error)
            return None
        return RUNS_RETRY_BACKOFF_SECONDS[attempt - 1]

    @staticmethod
    def _sleep_backoff(seconds: float) -> None:
        time.sleep(seconds)

    async def _sleep_backoff_async(self, seconds: float) -> None:
        await asyncio.sleep(seconds)

    async def _fetch_with_retry_async(
        self,
        fetcher: Callable[[], Any | None],
        *,
        failure_label: str,
        stale_check: Callable[[], bool] | None = None,
    ) -> Any | None:
        attempts = self._retry_attempts()
        for attempt in range(1, attempts + 1):
            if stale_check and stale_check():
                return None
            try:
                result = await asyncio.to_thread(fetcher)
                error: Exception | None = None
            except Exception as exc:  # pragma: no cover - defensive
                result = None
                error = exc

            if result is not None:
                return result

            delay = self._retry_delay(
                attempt=attempt,
                attempts=attempts,
                error=error,
                failure_label=failure_label,
            )
            if delay is None:
                return None

            self._set_status(self._retry_message(subject=failure_label, attempt=attempt))
            await self._sleep_backoff_async(delay)

        return None

    def _fetch_with_retry_sync(
        self,
        fetcher: Callable[[], Any | None],
        *,
        failure_label: str,
        stale_check: Callable[[], bool] | None = None,
    ) -> Any | None:
        attempts = self._retry_attempts()
        for attempt in range(1, attempts + 1):
            if stale_check and stale_check():
                return None
            try:
                result = fetcher()
                error: Exception | None = None
            except Exception as exc:  # pragma: no cover - defensive
                result = None
                error = exc

            if result is not None:
                return result

            delay = self._retry_delay(
                attempt=attempt,
                attempts=attempts,
                error=error,
                failure_label=failure_label,
            )
            if delay is None:
                return None

            self._set_status(self._retry_message(subject=failure_label, attempt=attempt))
            self._sleep_backoff(delay)

        return None

    def _get_or_load_detail(self, run_id: str) -> Any | None:
        detail = self._detail_cache.get(run_id)
        if detail is not None:
            return detail
        try:
            detail = self._runs_callbacks.fetch_detail(run_id)
        except Exception as exc:  # pragma: no cover - defensive
            logger.exception(RUNS_DETAIL_LOG_MESSAGE, run_id, exc)
            detail = None
        if detail is not None:
            self._detail_cache[run_id] = detail
            self._update_transcript(detail)
        return detail

    def _queue_export_job(self, run_id: str, detail: Any) -> None:
        async def runner() -> None:  # pragma: no cover - defensive
            await self._perform_export(run_id, detail)

        try:
            run_worker = getattr(cast(Any, self), "run_worker", None)
            if callable(run_worker):
                run_worker(runner(), name="export-run", exclusive=True)
            else:
                raise AttributeError("run_worker not available")
        except Exception:  # pragma: no cover - defensive
            self.track_task(runner())

    async def _perform_export(self, run_id: str, detail: Any) -> None:
        try:
            app = getattr(self, "app", None)
            if app is None:
                success = bool(self._runs_callbacks.export_run(run_id, detail))
            else:
                with app.suspend():
                    success = bool(self._runs_callbacks.export_run(run_id, detail))
        except Exception as exc:  # pragma: no cover - defensive
            logger.exception("Export failed: %s", exc)
            self._set_status(f"Export failed: {exc}")
            return

        if success:
            self._set_status("Export complete (see slash console for path).")
        else:
            self._set_status("Export cancelled.")

    def _show_loading(self, message: str | None = None, *, footer_message: bool = True) -> None:
        show_loading_indicator(
            self,
            RUNS_LOADING_SELECTOR,
            message=message,
            set_status=self._set_status if footer_message else None,
        )

    def _hide_loading(self) -> None:
        hide_loading_indicator(self, RUNS_LOADING_SELECTOR)

    def _ensure_toast_bus(self) -> None:
        def _notify(message: ToastBus.Changed) -> None:  # pragma: no cover - defensive
            # Post to self (Screen) so ToastHandlerMixin.on_toast_bus_changed can handle it.
            self.post_message(message)

        if self._local_toasts is not None:
            self._local_toasts.subscribe(_notify)
            return

        if self._ctx and self._ctx.toasts is not None:  # pragma: no cover - defensive
            self._local_toasts = self._ctx.toasts  # pragma: no cover - defensive
            self._local_toasts.subscribe(_notify)  # pragma: no cover - defensive
            return  # pragma: no cover - defensive
        self._local_toasts = ToastBus(on_change=_notify)
        if self._ctx:
            self._ctx.toasts = self._local_toasts

    def _announce_status(self, message: str) -> None:
        self._set_status(message)

    def _append_copy_fallback(self, text: str) -> None:
        self._transcript_log.write(Text(text))
        self._transcript_log.write(Text(""))

    def _set_status(self, message: str) -> None:
        self._status_line.update(message)

    def _should_async_transcript(self, output: Any) -> bool:
        if not isinstance(output, list):
            return False
        return len(output) > TRANSCRIPT_ASYNC_THRESHOLD

    @staticmethod
    def _detail_output(detail: Any) -> Any:
        if isinstance(detail, dict):
            return detail.get("output")
        return getattr(detail, "output", None)

    @staticmethod
    def _serialize_transcript(output: list[Any]) -> list[str]:
        return [json.dumps(chunk, indent=2, ensure_ascii=False, default=str) for chunk in output]

    async def _render_transcript_async(self, output: list[Any], token: int) -> None:
        try:
            rendered = await asyncio.to_thread(self._serialize_transcript, output)
        except Exception as exc:
            self.call_after_refresh(self._render_transcript_error, token, exc)
            return
        self.call_after_refresh(self._apply_transcript_render, token, rendered)

    def _apply_transcript_render(self, token: int, rendered: list[str]) -> None:
        if token != self._transcript_render_token:
            return
        self._transcript_log.clear()
        if not rendered:
            self._transcript_log.write(RUNS_NO_TRANSCRIPT_MESSAGE)
            return
        for json_str in rendered:
            self._transcript_log.write(Syntax(json_str, "json", theme="monokai", word_wrap=True))
            self._transcript_log.write("")

    def _render_transcript_error(self, token: int, exc: Exception) -> None:
        if token != self._transcript_render_token:
            return
        self._transcript_log.clear()
        self._transcript_log.write(f"Failed to render transcript: {exc}")

    def _update_transcript(self, detail: Any | None) -> None:
        self._transcript_log.clear()
        self._transcript_render_token += 1
        token = self._transcript_render_token
        if detail is None:
            self._transcript_log.write("Loading transcript...")
            return
        output = self._detail_output(detail)
        if not output:
            self._transcript_log.write(RUNS_NO_TRANSCRIPT_MESSAGE)
            return
        if self._should_async_transcript(output):
            self._transcript_log.write("Rendering transcript...")
            try:
                self._transcript_render_task = self.track_task(self._render_transcript_async(list(output), token))
            except RuntimeError:
                rendered = self._serialize_transcript(list(output))
                self._apply_transcript_render(token, rendered)
            return
        for chunk in output:
            json_str = json.dumps(chunk, indent=2, ensure_ascii=False, default=str)
            self._transcript_log.write(Syntax(json_str, "json", theme="monokai", word_wrap=True))
            self._transcript_log.write("")

    async def _copy_transcript_async(self, output: list[Any]) -> None:
        try:
            payload = await asyncio.to_thread(json.dumps, output, indent=2, ensure_ascii=False, default=str)
        except Exception as exc:
            self.call_after_refresh(self._set_status, f"Failed to serialize transcript: {exc}")
            return
        self.call_after_refresh(lambda: self._copy_to_clipboard(payload, label="Transcript"))

    async def _copy_detail_json_async(self, detail: Any) -> None:
        payload, error = self._detail_payload(detail)
        if error:
            self.call_after_refresh(self._set_status, error)
            return
        if isinstance(payload, str):
            self.call_after_refresh(lambda: self._copy_to_clipboard(payload, label=RUNS_RUN_JSON_LABEL))
            return
        try:
            json_payload = await asyncio.to_thread(
                json.dumps,
                payload,
                indent=2,
                ensure_ascii=False,
                default=str,
            )
        except Exception as exc:
            self.call_after_refresh(self._set_status, f"Failed to serialize run detail: {exc}")
            return
        self.call_after_refresh(lambda: self._copy_to_clipboard(json_payload, label=RUNS_RUN_JSON_LABEL))

    def _detail_payload(self, detail: Any | None) -> tuple[Any | None, str | None]:
        if detail is None:
            return None, "Run detail unavailable."
        if isinstance(detail, str):
            return detail, None
        if isinstance(detail, dict):
            return detail, None
        if hasattr(detail, "model_dump"):
            return detail.model_dump(mode="json"), None
        if hasattr(detail, "dict"):
            return detail.dict(), None
        return getattr(detail, "__dict__", {"value": detail}), None

    def _detail_json_payload(self, detail: Any | None) -> str | None:
        payload, error = self._detail_payload(detail)
        if error:
            self._set_status(error)
            return None
        if isinstance(payload, str):
            return payload
        try:
            return json.dumps(payload, indent=2, ensure_ascii=False, default=str)
        except Exception as exc:
            self._set_status(f"Failed to serialize run detail: {exc}")
            return None

    def _format_timestamp(self, value: datetime | None) -> str:
        if value is None:
            return "-"
        try:
            return value.strftime("%Y-%m-%d %H:%M:%S")
        except Exception:  # pragma: no cover - defensive
            return str(value)

    def _format_started(self, value: datetime | None) -> str:
        if value is None:
            return "-"
        try:
            # Short format: "Jan 02 14:30" (Mon DD HH:MM)
            # This avoids year (redundant for recent) and TZ noise in the table
            if value.tzinfo:
                value = value.astimezone(UTC)
            return value.strftime("%b %d %H:%M")
        except Exception:  # pragma: no cover - defensive
            return str(value)

    def _format_duration(self, formatter: Any) -> str:
        if callable(formatter):
            try:
                value = formatter()
            except Exception:  # pragma: no cover - defensive
                value = None
        else:
            value = None
        if not value:
            return "-"
        return str(value).replace("\u2014", "-")

    def _agent_context_label(self) -> str:
        if self._agent_name and self._agent_id:
            return f"Agent: {self._agent_name} ({self._agent_id})"
        if self._agent_name:
            return f"Agent: {self._agent_name}"
        if self._agent_id:
            return f"Agent: {self._agent_id}"
        return "Agent runs"

    def _input_preview(self, run: Any) -> str:
        text = getattr(run, "input", None) or ""
        # Strip common prefixes to increase information density
        text = str(text).replace("Execute the ", "").replace(" tool with", "")

        # Try to parse "tool_name: args" pattern without regex to avoid backtracking.
        parts = text.split(None, 1)
        if len(parts) == 2:
            tool, args = parts
            if tool and args:
                text = f"{tool}: {args}"

        # Reduce whitespace
        preview = " ".join(text.split())
        if not preview:
            return "-"
        if len(preview) > self._preview_limit:
            return preview[: self._preview_limit - 3] + "..."
        return preview

    def _matches_filter(self, run: Any) -> bool:
        if not self._filter_text:
            return True
        haystack = " ".join(
            [
                str(getattr(run, "input", "")),
                str(getattr(run, "run_type", "")),
                str(getattr(run, "status", "")),
            ]
        ).lower()
        return self._filter_text in haystack

    def _get_row(self, row_index: int) -> Any | None:
        if not self._visible_rows:
            return None
        row_index = max(0, min(row_index, len(self._visible_rows) - 1))
        return self._visible_rows[row_index]

    def _current_run(self) -> Any | None:
        if not self._visible_rows:
            return None
        return self._get_row(self.cursor_index)

    @staticmethod
    def _status_label(status: str | None) -> str:
        if not status:
            return "-"
        normalized = str(status).strip().lower()
        if normalized in {"ok", "success", "completed", "succeeded"}:
            return "✔"
        if normalized in {"running", "in_progress"}:
            return "⟳"
        if normalized in {"failed", "error", "errored"}:
            return "✖"
        if normalized in {"aborted", "cancelled", "canceled"}:
            return "⊘"
        return normalized[:3].upper()

    @staticmethod
    def _status_style(status: str | None) -> str:
        if not status:
            return "dim"
        normalized = str(status).strip().lower()
        if normalized in {"ok", "success", "completed", "succeeded"}:
            return "green"
        if normalized in {"running", "in_progress", "run"}:
            return "yellow"
        if normalized in {"failed", "error", "errored", "err", "aborted", "cancelled", "canceled", "abt"}:
            return "red"
        return "cyan"


class _HarlequinRunsApp(App[None]):
    """App wrapper that hosts the Harlequin runs screen."""

    def __init__(
        self,
        initial_page: Any,
        cursor_idx: int,
        callbacks: RemoteRunsTUICallbacks,
        *,
        agent_name: str | None = None,
        agent_id: str | None = None,
        ctx: TUIContext | None = None,
    ) -> None:
        super().__init__()
        self._initial_page = initial_page
        self._initial_cursor = cursor_idx
        self._callbacks = callbacks
        self._agent_name = agent_name
        self._agent_id = agent_id
        self._ctx = ctx
        self.current_page = initial_page
        self.cursor_index = cursor_idx

    def on_mount(self) -> None:
        screen = RunsHarlequinScreen(
            self._initial_page,
            self._initial_cursor,
            self._callbacks,
            agent_name=self._agent_name,
            agent_id=self._agent_id,
            ctx=self._ctx,
        )
        self.push_screen(cast(Screen, screen))

    def on_screen_resume(self, event: Any) -> None:  # pragma: no cover - UI hook
        screen = getattr(event, "screen", None)
        if isinstance(screen, RunsHarlequinScreen):
            self.current_page = screen.current_page
            self.cursor_index = screen.cursor_index
