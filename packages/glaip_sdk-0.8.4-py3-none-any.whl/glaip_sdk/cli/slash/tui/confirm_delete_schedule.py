"""Confirmation modal for schedule deletion."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:  # pragma: no cover - type checking only
    from textual.app import ComposeResult
    from textual.containers import Horizontal
    from textual.screen import ModalScreen
    from textual.widgets import Button, Static
else:
    try:  # pragma: no cover - optional dependency
        from textual.app import ComposeResult
        from textual.containers import Horizontal
        from textual.screen import ModalScreen
        from textual.widgets import Button, Static
    except Exception:  # pragma: no cover - optional dependency
        ComposeResult = None  # type: ignore[assignment]
        Horizontal = None  # type: ignore[assignment]
        ModalScreen = None  # type: ignore[assignment]
        Button = None  # type: ignore[assignment]
        Static = None  # type: ignore[assignment]

TEXTUAL_SUPPORTED = ModalScreen is not None and Button is not None

if TEXTUAL_SUPPORTED:
    _ConfirmBase = ModalScreen  # type: ignore[assignment]
else:
    _ConfirmBase = object

StaticType = cast(Any, Static)
ButtonType = cast(Any, Button)
HorizontalType = cast(Any, Horizontal)


def _agent_context(schedule: Any, fallback: str | None) -> str:
    if fallback:
        return fallback

    metadata = getattr(schedule, "metadata", None)
    if metadata is not None:
        for attr in ("agent_name", "agent_id"):
            value = getattr(metadata, attr, None)
            if value:
                return str(value)

    for attr in ("agent_name", "agent_id"):
        value = getattr(schedule, attr, None)
        if value:
            return str(value)

    return "Active agent"


def _format_schedule_info(schedule: Any) -> str:
    """Format schedule info for display in confirmation dialog."""
    schedule_config = getattr(schedule, "schedule_config", None)
    if not schedule_config:
        return "No schedule configured"

    minute = getattr(schedule_config, "minute", "*")
    hour = getattr(schedule_config, "hour", "*")
    day_of_month = getattr(schedule_config, "day_of_month", "*")
    month = getattr(schedule_config, "month", "*")
    day_of_week = getattr(schedule_config, "day_of_week", "*")

    # Interval schedule
    if minute.startswith("*/"):
        interval = minute.replace("*/", "")
        return f"Every {interval} minutes"

    # Format time
    times = []
    hours = hour.split(",") if hour != "*" else ["9"]
    minutes = minute.split(",") if minute != "*" else ["0"]
    for h in hours[:2]:  # Show max 2 times
        for m in minutes[:1]:
            times.append(f"{h.zfill(2)}:{m.zfill(2)}")
    time_str = ", ".join(times)
    if len(hours) > 2 or len(minutes) > 1:
        time_str += " ..."

    # Weekly
    if day_of_week != "*":
        days_map = {"0": "Sun", "1": "Mon", "2": "Tue", "3": "Wed", "4": "Thu", "5": "Fri", "6": "Sat"}
        days = [days_map.get(d.strip(), d) for d in day_of_week.split(",")]
        return f"Weekly on {', '.join(days)} at {time_str}"

    # Yearly
    if month != "*":
        months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        month_name = months[int(month) - 1] if month.isdigit() else month
        return f"Yearly on {month_name} {day_of_month} at {time_str}"

    # Monthly
    if day_of_month != "*":
        return f"Monthly on day {day_of_month} at {time_str}"

    # Daily
    return f"Daily at {time_str}"


class ConfirmDeleteScheduleModal(_ConfirmBase):  # type: ignore[misc]
    """Modal requiring confirmation before deleting a schedule."""

    CSS_PATH = "schedules.tcss"

    def __init__(self, schedule: Any, agent_label: str | None = None) -> None:
        """Initialize the delete confirmation modal.

        Args:
            schedule: The schedule object to delete.
            agent_label: Optional active agent label to display in the modal.
        """
        super().__init__()
        self._schedule = schedule
        self._agent_label = agent_label

    def compose(self) -> ComposeResult:  # type: ignore[override]
        """Compose the delete confirmation UI."""
        if not TEXTUAL_SUPPORTED:
            return  # type: ignore[return-value]
        schedule_id = str(getattr(self._schedule, "id", ""))
        schedule_info = _format_schedule_info(self._schedule)
        task_input = " ".join(str(getattr(self._schedule, "input", "") or "—").split())
        if len(task_input) > 180:
            task_input = task_input[:180] + "…"
        agent_label = _agent_context(self._schedule, self._agent_label)

        yield StaticType("Delete Scheduled Task?", id="confirm-title")
        yield StaticType(f"Agent: {agent_label}", id="confirm-agent")
        yield StaticType(f"Task: {task_input}", id="confirm-task")
        yield StaticType(f"Schedule: {schedule_info}", id="confirm-schedule-info")
        yield StaticType(f"Schedule ID: {schedule_id}", id="confirm-subtitle")
        yield StaticType("This action is irreversible and cannot be undone.", id="confirm-warning")
        yield HorizontalType(
            ButtonType("Delete", id="confirm-delete", variant="error"),
            ButtonType("Cancel", id="confirm-cancel"),
            id="confirm-actions",
        )

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses for delete/cancel."""
        btn_id = event.button.id or ""
        if btn_id == "confirm-cancel":
            self.dismiss(None)
            return
        if btn_id == "confirm-delete":
            self.dismiss(True)
