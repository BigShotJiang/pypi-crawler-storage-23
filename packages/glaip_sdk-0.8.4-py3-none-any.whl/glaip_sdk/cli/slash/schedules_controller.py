"""Schedules controller for the /schedules slash command.

Provides a Textual-first schedule browser with a Rich fallback for non-TTY
environments. Schedules are scoped to the active agent session.
"""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING, Any

import click
from rich.console import Group
from rich.text import Text

from glaip_sdk.branding import ERROR_STYLE, INFO_STYLE, WARNING_STYLE
from glaip_sdk.cli.constants import DEFAULT_SCHEDULES_PAGE_LIMIT
from glaip_sdk.cli.slash.tui.schedules_app import TEXTUAL_SUPPORTED, SchedulesTUICallbacks, run_schedules_textual
from glaip_sdk.exceptions import AuthenticationError, ForbiddenError, NotFoundError, TimeoutError, ValidationError
from glaip_sdk.models.schedule import ScheduleRunResult
from glaip_sdk.rich_components import AIPPanel, AIPTable

if TYPE_CHECKING:  # pragma: no cover
    from glaip_sdk.cli.slash.session import SlashSession
    from glaip_sdk.schedules.base import Schedule, ScheduleListResult


class SchedulesController:
    """Controller for browsing and editing agent schedules."""

    def __init__(self, session: SlashSession) -> None:
        """Initialize the schedules controller.

        Args:
            session: The slash session context.
        """
        self.session = session
        self.console = session.console
        self.ctx = session.ctx
        self._snapshot_notice_shown = False

    def handle_schedules_command(self, args: list[str]) -> bool:
        """Handle the /schedules command for the active agent.

        Args:
            args: Optional arguments ("new" to open the form immediately).

        Returns:
            True to continue session.
        """
        current_agent = getattr(self.session, "_current_agent", None)
        if not current_agent:
            self.console.print(f"[{WARNING_STYLE}]Open /agents and select an agent first to manage schedules.[/]")
            return self._continue_session()

        agent_id = str(getattr(current_agent, "id", ""))
        if not agent_id:
            self.console.print(f"[{ERROR_STYLE}]Invalid agent context.[/]")
            return self._continue_session()

        open_create = bool(args and args[0] in {"new", "create"})
        if args and not open_create:
            self.console.print(
                f"[{WARNING_STYLE}]Unknown argument '{args[0]}'. Use `/schedules` or `/schedules new`.[/]"
            )
            return self._continue_session()

        client = self._get_client_or_fail()
        if not client:
            return self._continue_session()

        agent_name = getattr(current_agent, "name", "") or None
        self.open_schedule_browser(client, agent_id, agent_name=agent_name, open_create=open_create)
        return self._continue_session()

    def open_schedule_browser(
        self,
        client: Any,
        agent_id: str,
        *,
        agent_name: str | None = None,
        open_create: bool = False,
    ) -> None:
        """Fetch and render the schedule list for the current agent."""
        state = self._get_schedules_state(agent_id)
        schedules_page = self._fetch_schedule_page(client, agent_id, state)
        if schedules_page is None:
            return

        state["page"] = schedules_page.page or state["page"]
        state["limit"] = schedules_page.limit or state["limit"]
        cursor = state.get("cursor", 0)
        if schedules_page.items:
            cursor = max(0, min(cursor, len(schedules_page.items) - 1))
        state["cursor"] = cursor

        if self._should_use_textual_browser():
            self._run_textual_browser(
                client,
                agent_id,
                schedules_page,
                state,
                agent_name=agent_name,
                open_create=open_create,
            )
            return

        if not self._snapshot_notice_shown:
            self.console.print(
                f"[{INFO_STYLE}]Interactive schedule manager requires a TTY. Showing a snapshot instead.[/]"
            )
            self._snapshot_notice_shown = True
        self._render_schedule_snapshot(schedules_page, agent_id)

    def _get_schedules_state(self, agent_id: str) -> dict[str, Any]:
        pagination_state = getattr(self.session, "_schedules_pagination_state", {})
        state = pagination_state.setdefault(
            agent_id,
            {"page": 1, "limit": DEFAULT_SCHEDULES_PAGE_LIMIT, "cursor": 0},
        )
        state.setdefault("page", 1)
        state.setdefault("limit", DEFAULT_SCHEDULES_PAGE_LIMIT)
        state.setdefault("cursor", 0)
        return state

    def _fetch_schedule_page(
        self,
        client: Any,
        agent_id: str,
        state: dict[str, Any],
        *,
        allow_reset: bool = True,
    ) -> ScheduleListResult | None:
        try:
            return client.schedules.list(agent_id=agent_id, limit=state["limit"], page=state["page"])
        except AuthenticationError:
            self.console.print(f"[{ERROR_STYLE}]Authentication failed. Run /login to refresh credentials.[/]")
        except ForbiddenError as exc:
            self.console.print(f"[{ERROR_STYLE}]Access denied: {exc}[/]")
        except NotFoundError:
            self.console.print(
                f"[{WARNING_STYLE}]Agent not found or access revoked. Re-open /agents to select again.[/]"
            )
            pagination_state = getattr(self.session, "_schedules_pagination_state", {})
            pagination_state.pop(agent_id, None)
        except TimeoutError:
            ctx_obj = self.ctx.obj if isinstance(self.ctx.obj, dict) else {}
            timeout_seconds = ctx_obj.get("timeout", 30)
            self.console.print(
                f"[{WARNING_STYLE}]Schedule request timed out after {timeout_seconds}s. Press Enter to retry.[/]"
            )
        except ValidationError:
            if allow_reset:
                self.console.print(
                    f"[{WARNING_STYLE}]Invalid pagination request (page {state['page']}, limit {state['limit']}). "
                    "Resetting to defaults.[/]"
                )
                state["page"] = 1
                state["limit"] = DEFAULT_SCHEDULES_PAGE_LIMIT
                return self._fetch_schedule_page(client, agent_id, state, allow_reset=False)
            self.console.print(f"[{ERROR_STYLE}]Pagination request rejected by backend.[/]")
        except Exception as exc:  # pragma: no cover - unexpected API failure
            self.console.print(f"[{ERROR_STYLE}]Error fetching schedules: {exc}[/]")
        return None

    def _run_textual_browser(
        self,
        client: Any,
        agent_id: str,
        schedules_page: ScheduleListResult,
        state: dict[str, Any],
        *,
        agent_name: str | None = None,
        open_create: bool = False,
    ) -> None:
        def _fetch_page(page: int, limit: int) -> ScheduleListResult | None:
            fetch_state = {"page": page, "limit": limit}
            return self._fetch_schedule_page(client, agent_id, fetch_state)

        def _fetch_detail(schedule_id: str) -> Schedule | None:
            try:
                return client.schedules.get(schedule_id)
            except Exception as exc:  # pragma: no cover - handled in TUI status
                self.console.print(f"[{ERROR_STYLE}]Failed to load schedule: {exc}[/]")
                return None

        def _create_schedule(input_text: str, schedule: Any) -> Schedule | None:
            try:
                return client.schedules.create(agent_id=agent_id, input=input_text, schedule=schedule)
            except Exception as exc:  # pragma: no cover - handled in TUI status
                self.console.print(f"[{ERROR_STYLE}]Failed to create schedule: {exc}[/]")
                return None

        def _update_schedule(schedule_id: str, input_text: str | None, schedule: Any | None) -> Schedule | None:
            try:
                return client.schedules.update(schedule_id, input=input_text, schedule=schedule)
            except Exception as exc:  # pragma: no cover - handled in TUI status
                self.console.print(f"[{ERROR_STYLE}]Failed to update schedule: {exc}[/]")
                return None

        def _delete_schedule(schedule_id: str) -> bool:
            try:
                client.schedules.delete(schedule_id)
                return True
            except Exception as exc:  # pragma: no cover - handled in TUI status
                self.console.print(f"[{ERROR_STYLE}]Failed to delete schedule: {exc}[/]")
                return False

        def _list_runs(schedule_id: str, limit: int, page: int):
            try:
                return client.schedules.list_runs(agent_id, schedule_id=schedule_id, limit=limit, page=page)
            except Exception as exc:  # pragma: no cover - handled in TUI status
                self.console.print(f"[{ERROR_STYLE}]Failed to load schedule runs: {exc}[/]")
                return None

        def _fetch_run_detail(run_id: str) -> ScheduleRunResult | None:
            try:
                return client.schedules.get_run_result(agent_id, run_id)
            except Exception as exc:  # pragma: no cover - handled in TUI status
                self.console.print(f"[{ERROR_STYLE}]Failed to load schedule run detail: {exc}[/]")
                return None

        callbacks = SchedulesTUICallbacks(
            fetch_page=_fetch_page,
            fetch_detail=_fetch_detail,
            create_schedule=_create_schedule,
            update_schedule=_update_schedule,
            delete_schedule=_delete_schedule,
            list_runs=_list_runs,
            fetch_run_detail=_fetch_run_detail,
        )

        try:
            tui_ctx = getattr(self.session, "tui_ctx", None)
            page, limit, cursor = run_schedules_textual(
                schedules_page,
                state.get("cursor", 0),
                callbacks,
                agent_name=agent_name,
                agent_id=agent_id,
                ctx=tui_ctx,
                open_create=open_create,
            )
            state["page"] = page
            state["limit"] = limit
            state["cursor"] = cursor
        except Exception as exc:  # pragma: no cover - defensive around Textual failures
            self.console.print(f"[{WARNING_STYLE}]Schedule browser exited unexpectedly: {exc}[/]")

    def _render_schedule_snapshot(self, schedules_page: ScheduleListResult, agent_id: str) -> None:
        title = f"Schedules ({agent_id})"
        table = AIPTable(title=title)
        table.add_column("Schedule", style="cyan", width=36, no_wrap=True)
        table.add_column("Next Run", style="green", width=24, no_wrap=True)
        table.add_column("Cron", style="dim", width=20, no_wrap=True)
        table.add_column("Input Preview", style="white", width=40, overflow="ellipsis")

        if not schedules_page.items:
            self.console.print(f"[{WARNING_STYLE}]No schedules yet. Use /schedules in a TTY to create one.[/]")
        for schedule in schedules_page.items:
            label = _schedule_label(schedule)
            next_run = schedule.next_run_time or "—"
            cron = "—"
            if schedule.schedule_config is not None:
                cron = schedule.schedule_config.to_cron_string()
            preview = _input_preview(schedule.input)
            table.add_row(label, next_run, cron, preview)

        total = schedules_page.total or len(schedules_page.items)
        page = schedules_page.page or 1
        limit = schedules_page.limit or DEFAULT_SCHEDULES_PAGE_LIMIT
        total_pages = max(1, (total + limit - 1) // limit)
        footer = Text.from_markup(f"[dim]Page {page}/{total_pages} · limit={limit} · rerun in a TTY for CRUD[/]")
        self.console.print(AIPPanel(Group(table, footer), title="Schedule Snapshot", border_style=INFO_STYLE))

    def _should_use_textual_browser(self) -> bool:
        if not TEXTUAL_SUPPORTED:
            return False

        def _is_tty(stream: Any) -> bool:
            isatty = getattr(stream, "isatty", None)
            if not callable(isatty):
                return False
            try:
                return bool(isatty())
            except Exception:
                return False

        return _is_tty(sys.stdin) and _is_tty(sys.stdout)

    def _get_client_or_fail(self) -> Any:
        try:
            return self.session._get_client()
        except click.ClickException as exc:
            self.console.print(f"[{ERROR_STYLE}]{exc}[/]")
            return None

    def _continue_session(self) -> bool:
        return not getattr(self.session, "_should_exit", False)


def _schedule_label(schedule: Schedule) -> str:
    base = " ".join((schedule.input or "").split())
    if not base:
        return str(schedule.id)
    if len(base) > 32:
        return f"{base[:32]}…"
    return base


def _input_preview(value: str | None, *, max_length: int = 60) -> str:
    if not value:
        return "—"
    preview = " ".join(value.split())
    if len(preview) > max_length:
        return preview[:max_length] + "…"
    return preview
