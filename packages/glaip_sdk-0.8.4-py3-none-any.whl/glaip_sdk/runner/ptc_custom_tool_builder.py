"""PTC Custom Tool Builder for bundling LangChain tools.

This module provides the PTCCustomToolBuilder class for building PTCCustomToolConfig
from Agent.tools for PTC sandbox execution.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any

from glaip_sdk.exceptions import ValidationError
from glaip_sdk.utils.bundler import ToolBundler
from glaip_sdk.utils.tool_detection import get_tool_name, is_aip_agents_tool


class PTCCustomToolBuilder:
    """Builds PTCCustomToolConfig from adapted LangChain tools.

    This builder bundles user-defined LangChain tools into single-file artifacts
    for PTC sandbox execution. Native aip-agents tools are registered as package
    tools without bundling.

    Attributes:
        bundle_dir: Path to the bundle directory (if created).
        bundle_tmp: TemporaryDirectory handle for cleanup.

    Example:
        >>> from glaip_sdk.runner.ptc_custom_tool_builder import PTCCustomToolBuilder
        >>> builder = PTCCustomToolBuilder()
        >>> config = builder.build(adapted_tools)
        >>> # Use config.tools and config.bundle_roots for PTCSandboxConfig
        >>> # Call builder.bundle_tmp.cleanup() when done
    """

    def __init__(self) -> None:
        """Initialize the PTCCustomToolBuilder."""
        self._bundle_dir: Path | None = None
        self._bundle_tmp: tempfile.TemporaryDirectory[str] | None = None

    @property
    def bundle_dir(self) -> Path | None:
        """Return the bundle directory if created (used for cleanup)."""
        return self._bundle_dir

    @property
    def bundle_tmp(self) -> tempfile.TemporaryDirectory[str] | None:
        """Return the TemporaryDirectory handle if created (used for cleanup)."""
        return self._bundle_tmp

    def build(
        self,
        adapted_tools: list[Any],  # BaseTool instances
    ) -> Any:  # Returns PTCCustomToolConfig
        """Build PTCCustomToolConfig from adapted LangChain tools.

        Args:
            adapted_tools: List of already-adapted LangChain BaseTool instances.

        Returns:
            PTCCustomToolConfig with:
            - enabled=True if tools are provided
            - bundle_roots derived from bundled tool artifact locations
            - tools=[PTCFileToolDef, ...] for user-defined LangChain tools
              (native aip-agents tools are emitted as package tools)

        Raises:
            ValidationError: If a tool cannot be bundled into a single file,
                is defined in __main__/dynamic modules, or is a function-based
                LangChain tool (@tool / StructuredTool).
        """
        # Lazy imports to avoid breaking non-local installs
        from aip_agents.ptc import PTCCustomToolConfig  # noqa: PLC0415
        from aip_agents.ptc.custom_tools import (  # noqa: PLC0415
            PTCCustomToolValidationError,
            check_name_collisions,
            validate_custom_tool_config,
        )
        from aip_agents.ptc.naming import sanitize_function_name  # noqa: PLC0415
        from aip_agents.ptc.tool_def_helpers import (  # noqa: PLC0415
            file_tool,
            package_tool,
        )

        if not adapted_tools:
            return PTCCustomToolConfig(enabled=False)

        # Pre-check name collisions before bundling to avoid file overwrites
        tool_names = [get_tool_name(tool) or type(tool).__name__ for tool in adapted_tools]
        try:
            check_name_collisions([{"name": name} for name in tool_names])
        except PTCCustomToolValidationError as exc:
            raise ValidationError(str(exc)) from exc

        tool_defs = []
        try:
            for tool in adapted_tools:
                tool_def = self._build_tool_def(
                    tool,
                    file_tool=file_tool,
                    package_tool=package_tool,
                    sanitize_function_name=sanitize_function_name,
                )
                tool_defs.append(tool_def)
        except Exception:
            if self._bundle_tmp is not None:
                self._bundle_tmp.cleanup()
                self._bundle_tmp = None
                self._bundle_dir = None
            raise

        # Derive bundle_roots from file tool locations
        bundle_roots = sorted(
            {str(Path(tool_def["file_path"]).parent) for tool_def in tool_defs if tool_def.get("kind") == "file"}
        )

        config = PTCCustomToolConfig(
            enabled=True,
            bundle_roots=bundle_roots,
            tools=tool_defs,
        )

        # Validate via aip-agents and wrap errors as SDK ValidationError
        try:
            validate_custom_tool_config(config)
        except PTCCustomToolValidationError as exc:
            raise ValidationError(str(exc)) from exc

        return config

    def _build_tool_def(
        self,
        tool: Any,
        *,
        file_tool: Any,
        package_tool: Any,
        sanitize_function_name: Any,
    ) -> dict:
        """Build a single tool definition from a BaseTool instance.

        Args:
            tool: A LangChain BaseTool instance.
            file_tool: Helper function to create PTCFileToolDef.
            package_tool: Helper function to create PTCPackageToolDef.
            sanitize_function_name: Helper function to sanitize filenames.

        Returns:
            A PTCToolDef dict (either file or package).

        Raises:
            ValidationError: If tool cannot be bundled.
        """
        tool_class = type(tool)

        # Reject function-based LangChain tools (@tool / StructuredTool)
        if getattr(tool, "func", None) is not None or getattr(tool, "coroutine", None) is not None:
            tool_name = get_tool_name(tool) or tool_class.__name__
            raise ValidationError(
                f"Tool '{tool_name}' is function-based and not supported yet. "
                "Define a BaseTool class in an importable module."
            )

        # Reject tools defined in __main__, <stdin>, or <string>
        module_name = getattr(tool_class, "__module__", "")
        if module_name in {"__main__", "<stdin>", "<string>"}:
            raise ValidationError(
                f"Tool '{tool_class.__name__}' is defined in {module_name} which "
                "cannot be bundled. Define tools in importable modules."
            )

        # Native aip-agents tools: register as package (no bundling)
        if is_aip_agents_tool(tool):
            tool_name = get_tool_name(tool) or tool_class.__name__
            return package_tool(
                tool_name,
                import_path=tool_class.__module__,
                class_name=tool_class.__name__,
            )

        # User-defined tools: bundle into single file
        try:
            bundled_source = ToolBundler(tool_class).bundle(add_tool_plugin_decorator=False)
        except Exception as exc:
            raise ValidationError(
                f"Failed to bundle tool '{getattr(tool, 'name', tool_class.__name__)}': {exc}"
            ) from exc

        # Create bundle directory if not exists
        if self._bundle_dir is None:
            self._bundle_tmp = tempfile.TemporaryDirectory(prefix="glaip_ptc_tools_")
            self._bundle_dir = Path(self._bundle_tmp.name)

        # Write bundled source to file
        tool_name = get_tool_name(tool) or tool_class.__name__
        safe_name = sanitize_function_name(tool_name)
        file_path = self._bundle_dir / f"{safe_name}.py"
        file_path.write_text(bundled_source, encoding="utf-8")

        return file_tool(
            tool_name,
            file_path=str(file_path),
            class_name=tool_class.__name__,
        )
