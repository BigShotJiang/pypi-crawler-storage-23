"""Filesystem configuration models for local runner execution.

These models define a typed API for selecting filesystem behavior in
`Agent(..., filesystem=...)` when running with the local LangGraph runner.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

from gllm_core.utils import LoggerManager
from pydantic import BaseModel, field_validator

logger = LoggerManager().get_logger(__name__)


class FilesystemConfig(BaseModel):
    """Base type for filesystem configuration models.

    Subclasses represent concrete backend choices and validation rules.
    """

    def model_dump(self, **_: Any) -> dict[str, Any]:
        """Serialize to dictionary for API transport.

        Returns:
            Dictionary representation of the config for backend API.
        """
        return {"backend": "in_memory"}


class InMemoryConfig(FilesystemConfig):
    """In-memory filesystem configuration.

    Attributes:
        backend (Literal["in_memory"]): Backend selector used by resolver logic.
    """

    backend: Literal["in_memory"] = "in_memory"

    def model_dump(self, **_: Any) -> dict[str, Any]:
        """Serialize to dictionary for API transport.

        Returns:
            Dictionary representation of the config for backend API.
        """
        return {"backend": "in_memory"}


class LocalDiskConfig(FilesystemConfig):
    """Local-disk filesystem configuration.

    Attributes:
        backend (Literal["local_disk"]): Backend selector used by resolver logic.
        base_directory (str): Existing directory used as filesystem root.
    """

    backend: Literal["local_disk"] = "local_disk"
    base_directory: str

    @field_validator("base_directory")
    @classmethod
    def _validate_base_directory(cls, value: str) -> str:
        """Validate that base_directory exists and log warning if not.

        In remote deployment mode, the base_directory is not used (backend
        auto-generates a temp directory), so the warning can be safely ignored.

        Args:
            value: Candidate directory path.

        Returns:
            The directory path (always accepted, warning logged if missing).
        """
        path = Path(value)
        if not path.is_dir():
            logger.warning(
                f"base_directory does not exist: {value}. This is expected for remote deployment and will be ignored."
            )
        return str(path)

    def model_dump(self, **_: Any) -> dict[str, Any]:
        """Serialize to dictionary for API transport.

        Note: base_directory is intentionally stripped for security in remote mode.
        The backend auto-generates a temp directory.

        Returns:
            Dictionary representation of the config for backend API.
        """
        return {"backend": "local_disk"}
