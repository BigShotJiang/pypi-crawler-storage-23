# Default variables
DEFAULT_RPC_URL = "https://ogevmdevnet.opengradient.ai"
DEFAULT_API_URL = "https://sdk-devnet.opengradient.ai"
DEFAULT_OG_FAUCET_URL = "https://faucet.opengradient.ai/?address="
DEFAULT_HUB_SIGNUP_URL = "https://hub.opengradient.ai/signup"
DEFAULT_INFERENCE_CONTRACT_ADDRESS = "0x8383C9bD7462F12Eb996DD02F78234C0421A6FaE"
DEFAULT_SCHEDULER_ADDRESS = "0x7179724De4e7FF9271FA40C0337c7f90C0508eF6"
DEFAULT_BLOCKCHAIN_EXPLORER = "https://explorer.opengradient.ai/tx/"
# TODO (Kyle): Add a process to fetch these IPS from the TEE registry
DEFAULT_OPENGRADIENT_LLM_SERVER_URL = "https://3.15.214.21:443"
DEFAULT_OPENGRADIENT_LLM_STREAMING_SERVER_URL = "https://3.15.214.21:443"
