import asyncio
import contextlib
import json
import logging
import ssl
from dataclasses import dataclass, field

from .sharding import DEFAULT_SERVERS, ShardingStrategy, stable_hash_shard

log = logging.getLogger("dflockd-client")


def _encode_lines(*lines: str) -> bytes:
    return ("".join(f"{ln}\n" for ln in lines)).encode("utf-8")


async def _readline(reader: asyncio.StreamReader) -> str:
    raw = await reader.readline()
    if raw == b"":
        raise ConnectionError("server closed connection")
    return raw.decode("utf-8").rstrip("\r\n")


def _parse_lease(parts: list[str]) -> int:
    try:
        return int(parts[2]) if len(parts) >= 3 else 30
    except ValueError:
        return 30


async def acquire(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    key: str,
    acquire_timeout_s: int,
    lease_ttl_s: int | None = None,
) -> tuple[str, int]:
    # l\nkey\n"<timeout> [<lease>]"\n
    arg = (
        str(acquire_timeout_s)
        if lease_ttl_s is None
        else f"{acquire_timeout_s} {lease_ttl_s}"
    )

    writer.write(_encode_lines("l", key, arg))
    await writer.drain()

    resp = await _readline(reader)
    if resp == "timeout":
        raise TimeoutError(f"timeout acquiring {key!r}")
    if not resp.startswith("ok "):
        raise RuntimeError(f"acquire failed: {resp!r}")

    # ok <token> <lease>
    parts = resp.split()
    if len(parts) < 2:
        raise RuntimeError(f"bad ok response: {resp!r}")
    token = parts[1]
    lease = _parse_lease(parts)
    return token, lease


async def renew(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    key: str,
    token: str,
    lease_ttl_s: int | None = None,
) -> int:
    # n\nkey\n"<token> [<lease>]"\n
    arg = token if lease_ttl_s is None else f"{token} {lease_ttl_s}"
    writer.write(_encode_lines("n", key, arg))
    await writer.drain()

    resp = await _readline(reader)
    if not resp.startswith("ok"):
        raise RuntimeError(f"renew failed: {resp!r}")

    # ok <seconds_remaining> (optional)
    parts = resp.split()
    if len(parts) >= 2 and parts[1].isdigit():
        return int(parts[1])
    return -1


async def enqueue(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    key: str,
    lease_ttl_s: int | None = None,
) -> tuple[str, str | None, int | None]:
    """
    Two-phase enqueue: join FIFO queue, return immediately.
    Returns (status, token, lease) where status is "acquired" or "queued".
    """
    arg = "" if lease_ttl_s is None else str(lease_ttl_s)
    writer.write(_encode_lines("e", key, arg))
    await writer.drain()

    resp = await _readline(reader)
    if resp.startswith("acquired "):
        parts = resp.split()
        token = parts[1]
        lease = _parse_lease(parts)
        return ("acquired", token, lease)
    if resp == "queued":
        return ("queued", None, None)
    raise RuntimeError(f"enqueue failed: {resp!r}")


async def wait(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    key: str,
    wait_timeout_s: int,
) -> tuple[str, int]:
    """
    Two-phase wait: block until lock is granted.
    Returns (token, lease). Raises TimeoutError on timeout.
    """
    writer.write(_encode_lines("w", key, str(wait_timeout_s)))
    await writer.drain()

    resp = await _readline(reader)
    if resp == "timeout":
        raise TimeoutError(f"timeout waiting for {key!r}")
    if not resp.startswith("ok "):
        raise RuntimeError(f"wait failed: {resp!r}")

    parts = resp.split()
    token = parts[1]
    lease = _parse_lease(parts)
    return token, lease


async def release(
    reader: asyncio.StreamReader, writer: asyncio.StreamWriter, key: str, token: str
) -> None:
    writer.write(_encode_lines("r", key, token))
    await writer.drain()

    resp = await _readline(reader)
    if resp != "ok":
        raise RuntimeError(f"release failed: {resp!r}")


async def stats(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
) -> dict:
    writer.write(_encode_lines("stats", "_", ""))
    await writer.drain()

    resp = await _readline(reader)
    if not resp.startswith("ok "):
        raise RuntimeError(f"stats failed: {resp!r}")

    try:
        return json.loads(resp[3:])
    except json.JSONDecodeError as e:
        raise RuntimeError(f"bad stats response: {resp!r}") from e


@dataclass
class DistributedLock:
    key: str
    acquire_timeout_s: int = 10
    lease_ttl_s: int | None = None  # if None, server default
    servers: list[tuple[str, int]] = field(
        default_factory=lambda: list(DEFAULT_SERVERS)
    )
    sharding_strategy: ShardingStrategy = stable_hash_shard
    renew_ratio: float = 0.5  # renew at lease * ratio
    ssl_context: ssl.SSLContext | None = None
    auth_token: str | None = None

    _reader: asyncio.StreamReader | None = None
    _writer: asyncio.StreamWriter | None = None
    token: str | None = None
    lease: int = 0
    _renew_task: asyncio.Task | None = None
    _closed: bool = False

    def __post_init__(self):
        if not self.servers:
            raise ValueError("servers must be a non-empty list")

    def _pick_server(self) -> tuple[str, int]:
        idx = self.sharding_strategy(self.key, len(self.servers))
        return self.servers[idx % len(self.servers)]

    async def _connect(
        self,
    ) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
        await self.aclose()
        self._closed = False
        host, port = self._pick_server()
        self._reader, self._writer = await asyncio.open_connection(
            host, port, ssl=self.ssl_context
        )
        if self.auth_token is not None:
            self._writer.write(_encode_lines("auth", "_", self.auth_token))
            await self._writer.drain()
            resp = await _readline(self._reader)
            if resp != "ok":
                await self.aclose()
                raise PermissionError(f"authentication failed: {resp!r}")
        return self._reader, self._writer

    async def acquire(self) -> bool:
        reader, writer = await self._connect()
        try:
            self.token, self.lease = await acquire(
                reader,
                writer,
                self.key,
                self.acquire_timeout_s,
                self.lease_ttl_s,
            )
        except TimeoutError:
            await self.aclose()
            return False
        except BaseException:
            await self.aclose()
            raise
        # Start renew loop
        self._renew_task = asyncio.create_task(self._renew_loop())
        return True

    async def enqueue(self) -> str:
        """
        Two-phase step 1: connect and enqueue. Returns "acquired" or "queued".
        Starts renew loop on fast-path acquire.
        """
        reader, writer = await self._connect()
        try:
            status, tok, lease = await enqueue(
                reader, writer, self.key, self.lease_ttl_s
            )
        except BaseException:
            await self.aclose()
            raise
        if status == "acquired":
            self.token = tok
            self.lease = lease or 0
            self._renew_task = asyncio.create_task(self._renew_loop())
        return status

    async def wait(self, timeout_s: int | None = None) -> bool:
        """
        Two-phase step 2: wait for lock grant. Returns True if granted, False on timeout.
        If already acquired (fast path from enqueue), returns immediately.
        """
        if self.token is not None:
            # Already acquired during enqueue
            return True
        if self._reader is None or self._writer is None:
            raise RuntimeError("not connected; call enqueue() first")
        timeout = timeout_s if timeout_s is not None else self.acquire_timeout_s
        try:
            self.token, self.lease = await wait(
                self._reader, self._writer, self.key, timeout
            )
        except TimeoutError:
            await self.aclose()
            return False
        except BaseException:
            await self.aclose()
            raise
        self._renew_task = asyncio.create_task(self._renew_loop())
        return True

    async def release(self) -> bool:
        try:
            if self._renew_task:
                self._renew_task.cancel()
                with contextlib.suppress(BaseException):
                    await self._renew_task

            if self._reader and self._writer and self.token:
                await release(self._reader, self._writer, self.key, self.token)
        finally:
            await self.aclose()
        return True

    async def __aenter__(self):
        reader, writer = await self._connect()
        try:
            self.token, self.lease = await acquire(
                reader,
                writer,
                self.key,
                self.acquire_timeout_s,
                self.lease_ttl_s,
            )
        except BaseException:
            await self.aclose()
            raise
        # Start renew loop
        self._renew_task = asyncio.create_task(self._renew_loop())
        return self

    async def _renew_loop(self):
        assert self._reader and self._writer and self.token
        interval = max(1.0, self.lease * self.renew_ratio)
        try:
            while True:
                await asyncio.sleep(interval)
                try:
                    await renew(
                        self._reader,
                        self._writer,
                        self.key,
                        self.token,
                        self.lease_ttl_s,
                    )
                except asyncio.CancelledError:
                    raise
                except Exception:
                    log.error(
                        "lock lost (renew failed): key=%s token=%s",
                        self.key,
                        self.token,
                    )
                    await self.aclose()
                    return
        except asyncio.CancelledError:
            return

    async def __aexit__(self, exc_type, exc, tb):
        try:
            if self._renew_task:
                self._renew_task.cancel()
                with contextlib.suppress(BaseException):
                    await self._renew_task

            if self._reader and self._writer and self.token:
                with contextlib.suppress(Exception):
                    await release(self._reader, self._writer, self.key, self.token)
        finally:
            await self.aclose()

    async def aclose(self):
        if self._closed:
            return
        self._closed = True
        if self._writer:
            try:
                self._writer.close()
            except Exception:
                pass
            with contextlib.suppress(Exception):
                await self._writer.wait_closed()
        self._reader = None
        self._writer = None
        self.token = None


# ===========================================================================
# Semaphore protocol functions
# ===========================================================================


async def sem_acquire(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    key: str,
    acquire_timeout_s: int,
    limit: int,
    lease_ttl_s: int | None = None,
) -> tuple[str, int]:
    # sl\nkey\n"<timeout> <limit> [<lease>]"\n
    arg = f"{acquire_timeout_s} {limit}"
    if lease_ttl_s is not None:
        arg = f"{arg} {lease_ttl_s}"

    writer.write(_encode_lines("sl", key, arg))
    await writer.drain()

    resp = await _readline(reader)
    if resp == "timeout":
        raise TimeoutError(f"timeout acquiring semaphore {key!r}")
    if not resp.startswith("ok "):
        raise RuntimeError(f"sem_acquire failed: {resp!r}")

    parts = resp.split()
    if len(parts) < 2:
        raise RuntimeError(f"bad ok response: {resp!r}")
    token = parts[1]
    lease = _parse_lease(parts)
    return token, lease


async def sem_renew(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    key: str,
    token: str,
    lease_ttl_s: int | None = None,
) -> int:
    # sn\nkey\n"<token> [<lease>]"\n
    arg = token if lease_ttl_s is None else f"{token} {lease_ttl_s}"
    writer.write(_encode_lines("sn", key, arg))
    await writer.drain()

    resp = await _readline(reader)
    if not resp.startswith("ok"):
        raise RuntimeError(f"sem_renew failed: {resp!r}")

    parts = resp.split()
    if len(parts) >= 2 and parts[1].isdigit():
        return int(parts[1])
    return -1


async def sem_enqueue(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    key: str,
    limit: int,
    lease_ttl_s: int | None = None,
) -> tuple[str, str | None, int | None]:
    """
    Two-phase enqueue for semaphore: join FIFO queue, return immediately.
    Returns (status, token, lease) where status is "acquired" or "queued".
    """
    arg = str(limit) if lease_ttl_s is None else f"{limit} {lease_ttl_s}"
    writer.write(_encode_lines("se", key, arg))
    await writer.drain()

    resp = await _readline(reader)
    if resp.startswith("acquired "):
        parts = resp.split()
        token = parts[1]
        lease = _parse_lease(parts)
        return ("acquired", token, lease)
    if resp == "queued":
        return ("queued", None, None)
    raise RuntimeError(f"sem_enqueue failed: {resp!r}")


async def sem_wait(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    key: str,
    wait_timeout_s: int,
) -> tuple[str, int]:
    """
    Two-phase wait for semaphore: block until semaphore slot is granted.
    Returns (token, lease). Raises TimeoutError on timeout.
    """
    writer.write(_encode_lines("sw", key, str(wait_timeout_s)))
    await writer.drain()

    resp = await _readline(reader)
    if resp == "timeout":
        raise TimeoutError(f"timeout waiting for semaphore {key!r}")
    if not resp.startswith("ok "):
        raise RuntimeError(f"sem_wait failed: {resp!r}")

    parts = resp.split()
    token = parts[1]
    lease = _parse_lease(parts)
    return token, lease


async def sem_release(
    reader: asyncio.StreamReader, writer: asyncio.StreamWriter, key: str, token: str
) -> None:
    writer.write(_encode_lines("sr", key, token))
    await writer.drain()

    resp = await _readline(reader)
    if resp != "ok":
        raise RuntimeError(f"sem_release failed: {resp!r}")


# ===========================================================================
# DistributedSemaphore
# ===========================================================================


@dataclass
class DistributedSemaphore:
    key: str
    limit: int
    acquire_timeout_s: int = 10
    lease_ttl_s: int | None = None
    servers: list[tuple[str, int]] = field(
        default_factory=lambda: list(DEFAULT_SERVERS)
    )
    sharding_strategy: ShardingStrategy = stable_hash_shard
    renew_ratio: float = 0.5
    ssl_context: ssl.SSLContext | None = None
    auth_token: str | None = None

    _reader: asyncio.StreamReader | None = None
    _writer: asyncio.StreamWriter | None = None
    token: str | None = None
    lease: int = 0
    _renew_task: asyncio.Task | None = None
    _closed: bool = False

    def __post_init__(self):
        if not self.servers:
            raise ValueError("servers must be a non-empty list")

    def _pick_server(self) -> tuple[str, int]:
        idx = self.sharding_strategy(self.key, len(self.servers))
        return self.servers[idx % len(self.servers)]

    async def _connect(
        self,
    ) -> tuple[asyncio.StreamReader, asyncio.StreamWriter]:
        await self.aclose()
        self._closed = False
        host, port = self._pick_server()
        self._reader, self._writer = await asyncio.open_connection(
            host, port, ssl=self.ssl_context
        )
        if self.auth_token is not None:
            self._writer.write(_encode_lines("auth", "_", self.auth_token))
            await self._writer.drain()
            resp = await _readline(self._reader)
            if resp != "ok":
                await self.aclose()
                raise PermissionError(f"authentication failed: {resp!r}")
        return self._reader, self._writer

    async def acquire(self) -> bool:
        reader, writer = await self._connect()
        try:
            self.token, self.lease = await sem_acquire(
                reader,
                writer,
                self.key,
                self.acquire_timeout_s,
                self.limit,
                self.lease_ttl_s,
            )
        except TimeoutError:
            await self.aclose()
            return False
        except BaseException:
            await self.aclose()
            raise
        self._renew_task = asyncio.create_task(self._renew_loop())
        return True

    async def enqueue(self) -> str:
        """
        Two-phase step 1: connect and enqueue. Returns "acquired" or "queued".
        Starts renew loop on fast-path acquire.
        """
        reader, writer = await self._connect()
        try:
            status, tok, lease = await sem_enqueue(
                reader, writer, self.key, self.limit, self.lease_ttl_s
            )
        except BaseException:
            await self.aclose()
            raise
        if status == "acquired":
            self.token = tok
            self.lease = lease or 0
            self._renew_task = asyncio.create_task(self._renew_loop())
        return status

    async def wait(self, timeout_s: int | None = None) -> bool:
        """
        Two-phase step 2: wait for semaphore grant. Returns True if granted,
        False on timeout. If already acquired (fast path from enqueue),
        returns immediately.
        """
        if self.token is not None:
            return True
        if self._reader is None or self._writer is None:
            raise RuntimeError("not connected; call enqueue() first")
        timeout = timeout_s if timeout_s is not None else self.acquire_timeout_s
        try:
            self.token, self.lease = await sem_wait(
                self._reader, self._writer, self.key, timeout
            )
        except TimeoutError:
            await self.aclose()
            return False
        except BaseException:
            await self.aclose()
            raise
        self._renew_task = asyncio.create_task(self._renew_loop())
        return True

    async def release(self) -> bool:
        try:
            if self._renew_task:
                self._renew_task.cancel()
                with contextlib.suppress(BaseException):
                    await self._renew_task

            if self._reader and self._writer and self.token:
                await sem_release(self._reader, self._writer, self.key, self.token)
        finally:
            await self.aclose()
        return True

    async def __aenter__(self):
        reader, writer = await self._connect()
        try:
            self.token, self.lease = await sem_acquire(
                reader,
                writer,
                self.key,
                self.acquire_timeout_s,
                self.limit,
                self.lease_ttl_s,
            )
        except BaseException:
            await self.aclose()
            raise
        self._renew_task = asyncio.create_task(self._renew_loop())
        return self

    async def _renew_loop(self):
        assert self._reader and self._writer and self.token
        interval = max(1.0, self.lease * self.renew_ratio)
        try:
            while True:
                await asyncio.sleep(interval)
                try:
                    await sem_renew(
                        self._reader,
                        self._writer,
                        self.key,
                        self.token,
                        self.lease_ttl_s,
                    )
                except asyncio.CancelledError:
                    raise
                except Exception:
                    log.error(
                        "semaphore lost (renew failed): key=%s token=%s",
                        self.key,
                        self.token,
                    )
                    await self.aclose()
                    return
        except asyncio.CancelledError:
            return

    async def __aexit__(self, exc_type, exc, tb):
        try:
            if self._renew_task:
                self._renew_task.cancel()
                with contextlib.suppress(BaseException):
                    await self._renew_task

            if self._reader and self._writer and self.token:
                with contextlib.suppress(Exception):
                    await sem_release(self._reader, self._writer, self.key, self.token)
        finally:
            await self.aclose()

    async def aclose(self):
        if self._closed:
            return
        self._closed = True
        if self._writer:
            try:
                self._writer.close()
            except Exception:
                pass
            with contextlib.suppress(Exception):
                await self._writer.wait_closed()
        self._reader = None
        self._writer = None
        self.token = None
