#!/usr/bin/env python3
"""Script to index existing Claude Code conversation history."""

from memotrail.cli import cmd_index

if __name__ == "__main__":
    cmd_index(None)
