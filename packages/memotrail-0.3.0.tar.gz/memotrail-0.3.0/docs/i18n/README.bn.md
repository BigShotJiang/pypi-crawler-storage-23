<div align="center">

# MemoTrail

> 🌐 এটি একটি স্বয়ংক্রিয় অনুবাদ। সম্প্রদায়ের সংশোধন স্বাগত! · [English](../../README.md)

[🇨🇳 中文](README.zh-CN.md) · [🇹🇼 繁體中文](README.zh-TW.md) · [🇯🇵 日本語](README.ja.md) · [🇵🇹 Português](README.pt.md) · [🇰🇷 한국어](README.ko.md) · [🇪🇸 Español](README.es.md) · [🇩🇪 Deutsch](README.de.md) · [🇫🇷 Français](README.fr.md) · [🇮🇱 עברית](README.he.md) · [🇸🇦 العربية](README.ar.md) · [🇷🇺 Русский](README.ru.md) · [🇵🇱 Polski](README.pl.md) · [🇨🇿 Čeština](README.cs.md) · [🇳🇱 Nederlands](README.nl.md) · [🇹🇷 Türkçe](README.tr.md) · [🇺🇦 Українська](README.uk.md) · [🇻🇳 Tiếng Việt](README.vi.md) · [🇮🇩 Indonesia](README.id.md) · [🇹🇭 ไทย](README.th.md) · [🇮🇳 हिन्दी](README.hi.md) · [🇧🇩 বাংলা](README.bn.md) · [🇵🇰 اردو](README.ur.md) · [🇷🇴 Română](README.ro.md) · [🇸🇪 Svenska](README.sv.md) · [🇮🇹 Italiano](README.it.md) · [🇬🇷 Ελληνικά](README.el.md) · [🇭🇺 Magyar](README.hu.md) · [🇫🇮 Suomi](README.fi.md) · [🇩🇰 Dansk](README.da.md) · [🇳🇴 Norsk](README.no.md)

**আপনার AI কোডিং সহকারী সবকিছু ভুলে যায়। MemoTrail এটি সমাধান করে।**

[![PyPI version](https://img.shields.io/pypi/v/memotrail?color=blue)](https://pypi.org/project/memotrail/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](../../LICENSE)
[![GitHub stars](https://img.shields.io/github/stars/HalilHopa-Datatent/memotrail?style=social)](https://github.com/HalilHopa-Datatent/memotrail)

AI কোডিং সহকারীদের জন্য একটি স্থায়ী মেমোরি স্তর।
প্রতিটি সেশন রেকর্ড করা, প্রতিটি সিদ্ধান্ত অনুসন্ধানযোগ্য, প্রতিটি প্রসঙ্গ মনে রাখা।

</div>

---

## সমস্যা

Claude Code-এর প্রতিটি নতুন সেশন শূন্য থেকে শুরু হয়। আপনার AI গতকালের ৩ ঘণ্টার ডিবাগিং সেশন, গত সপ্তাহের আর্কিটেকচার সিদ্ধান্ত বা ইতিমধ্যে ব্যর্থ হওয়া পদ্ধতিগুলো মনে রাখে না।

**MemoTrail ছাড়া:**
```
আপনি: "ক্যাশিংয়ের জন্য Redis ব্যবহার করি"
AI:     "অবশ্যই, Redis সেট আপ করি"
         ... ২ সপ্তাহ পর, নতুন সেশন ...
আপনি: "কেন আমরা Redis ব্যবহার করছি?"
AI:     "এই সিদ্ধান্ত সম্পর্কে আমার কোনো প্রসঙ্গ নেই"
```

**MemoTrail সহ:**
```
আপনি: "কেন আমরা Redis ব্যবহার করছি?"
AI:     "১৫ জানুয়ারির সেশনের ভিত্তিতে — আপনি Redis বনাম Memcached মূল্যায়ন করেছিলেন।
         ডেটা স্ট্রাকচার সাপোর্ট এবং স্থায়িত্বের জন্য Redis বেছে নেওয়া হয়েছিল।
         আলোচনাটি সেশন #42-তে আছে।"
```

## দ্রুত শুরু

```bash
# 1. ইনস্টল করুন
pip install memotrail

# 2. Claude Code-এ সংযুক্ত করুন
claude mcp add memotrail -- memotrail serve
```

এটাই সব। MemoTrail প্রথম লঞ্চে আপনার ইতিহাস স্বয়ংক্রিয়ভাবে ইনডেক্স করে।

## কিভাবে কাজ করে

| ধাপ | কী ঘটে |
|:----:|:-------------|
| **1. রেকর্ড** | MemoTrail প্রতিটি সার্ভার স্টার্টে নতুন সেশন স্বয়ংক্রিয়ভাবে ইনডেক্স করে |
| **2. বিভাজন** | কথোপকথন অর্থবহ অংশে বিভক্ত হয় |
| **3. এম্বেডিং** | প্রতিটি অংশ `all-MiniLM-L6-v2` দিয়ে এম্বেড হয় (~80MB, CPU-তে চলে) |
| **4. সংরক্ষণ** | ভেক্টর ChromaDB-তে, মেটাডেটা SQLite-এ — সব `~/.memotrail/`-এ |
| **5. অনুসন্ধান** | পরবর্তী সেশনে, Claude আপনার সম্পূর্ণ ইতিহাসে সিমেন্টিক অনুসন্ধান করে |
| **6. প্রদর্শন** | সবচেয়ে প্রাসঙ্গিক অতীত প্রসঙ্গ ঠিক যখন প্রয়োজন তখন দেখা যায় |

> **100% স্থানীয়** — কোনো ক্লাউড নেই, কোনো API কী নেই, কোনো ডেটা আপনার মেশিন ছাড়ে না।

## লাইসেন্স

MIT — দেখুন [LICENSE](../../LICENSE)

---

<div align="center">

**[Halil Hopa](https://halilhopa.com) দ্বারা নির্মিত** · [memotrail.ai](https://memotrail.ai)

MemoTrail যদি আপনাকে সাহায্য করে, GitHub-এ একটি স্টার দেওয়ার কথা ভাবুন।

</div>
