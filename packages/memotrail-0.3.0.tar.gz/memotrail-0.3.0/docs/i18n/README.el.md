<div align="center">

# MemoTrail

> 🌐 Αυτή είναι μια αυτόματη μετάφραση. Οι διορθώσεις από την κοινότητα είναι ευπρόσδεκτες! · [English](../../README.md)

[🇨🇳 中文](README.zh-CN.md) · [🇹🇼 繁體中文](README.zh-TW.md) · [🇯🇵 日本語](README.ja.md) · [🇵🇹 Português](README.pt.md) · [🇰🇷 한국어](README.ko.md) · [🇪🇸 Español](README.es.md) · [🇩🇪 Deutsch](README.de.md) · [🇫🇷 Français](README.fr.md) · [🇮🇱 עברית](README.he.md) · [🇸🇦 العربية](README.ar.md) · [🇷🇺 Русский](README.ru.md) · [🇵🇱 Polski](README.pl.md) · [🇨🇿 Čeština](README.cs.md) · [🇳🇱 Nederlands](README.nl.md) · [🇹🇷 Türkçe](README.tr.md) · [🇺🇦 Українська](README.uk.md) · [🇻🇳 Tiếng Việt](README.vi.md) · [🇮🇩 Indonesia](README.id.md) · [🇹🇭 ไทย](README.th.md) · [🇮🇳 हिन्दी](README.hi.md) · [🇧🇩 বাংলা](README.bn.md) · [🇵🇰 اردو](README.ur.md) · [🇷🇴 Română](README.ro.md) · [🇸🇪 Svenska](README.sv.md) · [🇮🇹 Italiano](README.it.md) · [🇬🇷 Ελληνικά](README.el.md) · [🇭🇺 Magyar](README.hu.md) · [🇫🇮 Suomi](README.fi.md) · [🇩🇰 Dansk](README.da.md) · [🇳🇴 Norsk](README.no.md)

**Ο βοηθός κώδικα AI σας ξεχνά τα πάντα. Το MemoTrail το λύνει.**

[![PyPI version](https://img.shields.io/pypi/v/memotrail?color=blue)](https://pypi.org/project/memotrail/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](../../LICENSE)
[![GitHub stars](https://img.shields.io/github/stars/HalilHopa-Datatent/memotrail?style=social)](https://github.com/HalilHopa-Datatent/memotrail)

Ένα μόνιμο επίπεδο μνήμης για βοηθούς κώδικα AI.
Κάθε συνεδρία καταγεγραμμένη, κάθε απόφαση αναζητήσιμη, κάθε πλαίσιο αποθηκευμένο.

</div>

---

## Το Πρόβλημα

Κάθε νέα συνεδρία Claude Code ξεκινά από το μηδέν. Η AI σας δεν θυμάται τη χθεσινή 3ωρη συνεδρία αποσφαλμάτωσης, τις αρχιτεκτονικές αποφάσεις της περασμένης εβδομάδας ή τις προσεγγίσεις που ήδη απέτυχαν.

**Χωρίς MemoTrail:**
```
Εσύ: "Ας χρησιμοποιήσουμε Redis για caching"
AI:   "Βεβαίως, ας ρυθμίσουμε το Redis"
         ... 2 εβδομάδες αργότερα, νέα συνεδρία ...
Εσύ: "Γιατί χρησιμοποιούμε Redis;"
AI:   "Δεν έχω πλαίσιο για αυτή την απόφαση"
```

**Με MemoTrail:**
```
Εσύ: "Γιατί χρησιμοποιούμε Redis;"
AI:   "Με βάση τη συνεδρία της 15ης Ιανουαρίου — αξιολογήσατε Redis vs Memcached.
       Το Redis επιλέχθηκε για την υποστήριξη δομών δεδομένων και την αντοχή.
       Η συζήτηση είναι στη συνεδρία #42."
```

## Γρήγορη Εκκίνηση

```bash
# 1. Εγκατάσταση
pip install memotrail

# 2. Σύνδεση με Claude Code
claude mcp add memotrail -- memotrail serve
```

Αυτό ήταν. Το MemoTrail ευρετηριάζει αυτόματα το ιστορικό σας κατά την πρώτη εκκίνηση.

## Πώς Λειτουργεί

| Βήμα | Τι συμβαίνει |
|:----:|:-------------|
| **1. Καταγραφή** | Το MemoTrail ευρετηριάζει αυτόματα νέες συνεδρίες σε κάθε εκκίνηση του server |
| **2. Τμηματοποίηση** | Οι συνομιλίες χωρίζονται σε ουσιαστικά τμήματα |
| **3. Ενσωμάτωση** | Κάθε τμήμα ενσωματώνεται με `all-MiniLM-L6-v2` (~80MB, τρέχει σε CPU) |
| **4. Αποθήκευση** | Τα vectors πάνε στο ChromaDB, τα metadata στο SQLite — όλα στο `~/.memotrail/` |
| **5. Αναζήτηση** | Στην επόμενη συνεδρία, ο Claude αναζητά σημασιολογικά σε όλο σας το ιστορικό |
| **6. Εμφάνιση** | Το πιο σχετικό παλαιότερο πλαίσιο εμφανίζεται ακριβώς όταν το χρειάζεστε |

> **100% τοπικά** — χωρίς cloud, χωρίς API keys, κανένα δεδομένο δεν φεύγει από τον υπολογιστή σας.

## Άδεια

MIT — δείτε [LICENSE](../../LICENSE)

---

<div align="center">

**Δημιουργήθηκε από [Halil Hopa](https://halilhopa.com)** · [memotrail.ai](https://memotrail.ai)

Αν το MemoTrail σας βοηθά, σκεφτείτε να δώσετε ένα αστέρι στο GitHub.

</div>
