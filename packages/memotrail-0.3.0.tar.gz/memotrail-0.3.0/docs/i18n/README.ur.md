<div align="center">

# MemoTrail

> 🌐 یہ ایک خودکار ترجمہ ہے۔ کمیونٹی کی اصلاحات کا خیرمقدم ہے! · [English](../../README.md)

[🇨🇳 中文](README.zh-CN.md) · [🇹🇼 繁體中文](README.zh-TW.md) · [🇯🇵 日本語](README.ja.md) · [🇵🇹 Português](README.pt.md) · [🇰🇷 한국어](README.ko.md) · [🇪🇸 Español](README.es.md) · [🇩🇪 Deutsch](README.de.md) · [🇫🇷 Français](README.fr.md) · [🇮🇱 עברית](README.he.md) · [🇸🇦 العربية](README.ar.md) · [🇷🇺 Русский](README.ru.md) · [🇵🇱 Polski](README.pl.md) · [🇨🇿 Čeština](README.cs.md) · [🇳🇱 Nederlands](README.nl.md) · [🇹🇷 Türkçe](README.tr.md) · [🇺🇦 Українська](README.uk.md) · [🇻🇳 Tiếng Việt](README.vi.md) · [🇮🇩 Indonesia](README.id.md) · [🇹🇭 ไทย](README.th.md) · [🇮🇳 हिन्दी](README.hi.md) · [🇧🇩 বাংলা](README.bn.md) · [🇵🇰 اردو](README.ur.md) · [🇷🇴 Română](README.ro.md) · [🇸🇪 Svenska](README.sv.md) · [🇮🇹 Italiano](README.it.md) · [🇬🇷 Ελληνικά](README.el.md) · [🇭🇺 Magyar](README.hu.md) · [🇫🇮 Suomi](README.fi.md) · [🇩🇰 Dansk](README.da.md) · [🇳🇴 Norsk](README.no.md)

**آپ کا AI کوڈنگ اسسٹنٹ سب کچھ بھول جاتا ہے۔ MemoTrail اسے حل کرتا ہے۔**

[![PyPI version](https://img.shields.io/pypi/v/memotrail?color=blue)](https://pypi.org/project/memotrail/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](../../LICENSE)
[![GitHub stars](https://img.shields.io/github/stars/HalilHopa-Datatent/memotrail?style=social)](https://github.com/HalilHopa-Datatent/memotrail)

AI کوڈنگ اسسٹنٹس کے لیے مستقل میموری لیئر۔
ہر سیشن ریکارڈ، ہر فیصلہ تلاش کے قابل، ہر سیاق و سباق یاد رکھا گیا۔

</div>

---

## مسئلہ

Claude Code کا ہر نیا سیشن صفر سے شروع ہوتا ہے۔ آپ کا AI کل کے 3 گھنٹے کے ڈیبگنگ سیشن، پچھلے ہفتے کے آرکیٹیکچر فیصلوں، یا پہلے سے ناکام ہو چکے طریقوں کو یاد نہیں رکھتا۔

**MemoTrail کے بغیر:**
```
آپ: "کیشنگ کے لیے Redis استعمال کرتے ہیں"
AI:   "ضرور، Redis سیٹ اپ کرتے ہیں"
         ... 2 ہفتے بعد، نیا سیشن ...
آپ: "ہم Redis کیوں استعمال کر رہے ہیں؟"
AI:   "مجھے اس فیصلے کے بارے میں کوئی سیاق نہیں ہے"
```

**MemoTrail کے ساتھ:**
```
آپ: "ہم Redis کیوں استعمال کر رہے ہیں؟"
AI:   "15 جنوری کے سیشن کی بنیاد پر — آپ نے Redis بمقابلہ Memcached کا جائزہ لیا۔
       ڈیٹا سٹرکچر سپورٹ اور استقامت کے لیے Redis منتخب کیا گیا۔
       بحث سیشن #42 میں ہے۔"
```

## فوری آغاز

```bash
# 1. انسٹال کریں
pip install memotrail

# 2. Claude Code سے جوڑیں
claude mcp add memotrail -- memotrail serve
```

بس۔ MemoTrail پہلی بار لانچ پر آپ کی تاریخ کو خودکار طور پر انڈیکس کرتا ہے۔

## یہ کیسے کام کرتا ہے

| مرحلہ | کیا ہوتا ہے |
|:----:|:-------------|
| **1. ریکارڈ** | MemoTrail ہر سرور سٹارٹ پر نئے سیشنز کو خودکار انڈیکس کرتا ہے |
| **2. تقسیم** | بات چیت کو معنی خیز حصوں میں تقسیم کیا جاتا ہے |
| **3. ایمبیڈنگ** | ہر حصہ `all-MiniLM-L6-v2` سے ایمبیڈ ہوتا ہے (~80MB، CPU پر چلتا ہے) |
| **4. ذخیرہ** | ویکٹرز ChromaDB میں، میٹا ڈیٹا SQLite میں — سب `~/.memotrail/` میں |
| **5. تلاش** | اگلے سیشن میں، Claude آپ کی پوری تاریخ میں سیمینٹک تلاش کرتا ہے |
| **6. دکھائیں** | سب سے متعلقہ ماضی کا سیاق بالکل تب ظاہر ہوتا ہے جب آپ کو ضرورت ہو |

> **100% مقامی** — کوئی کلاؤڈ نہیں، کوئی API کلید نہیں، کوئی ڈیٹا آپ کی مشین نہیں چھوڑتا۔

## دستیاب ٹولز

| ٹول | تفصیل |
|------|-------------|
| `search_chats` | تمام ماضی کی بات چیت میں سیمینٹک تلاش |
| `get_decisions` | ریکارڈ شدہ آرکیٹیکچر فیصلے حاصل کریں |
| `get_recent_sessions` | خلاصے کے ساتھ حالیہ سیشنز کی فہرست |
| `get_session_detail` | کسی مخصوص سیشن کے مواد کا تفصیلی جائزہ |
| `save_memory` | اہم حقائق یا فیصلے دستی طور پر محفوظ کریں |
| `memory_stats` | انڈیکسنگ کے اعداد و شمار اور اسٹوریج کا استعمال دیکھیں |

## CLI کمانڈز

```bash
memotrail serve                          # MCP سرور شروع کریں
memotrail search "redis caching decision"  # ٹرمینل سے تلاش کریں
memotrail stats                          # انڈیکسنگ کے اعداد و شمار دیکھیں
memotrail index                          # دستی طور پر دوبارہ انڈیکس کریں (اختیاری)
```

## لائسنس

MIT — [LICENSE](../../LICENSE) دیکھیں

---

<div align="center">

**[Halil Hopa](https://halilhopa.com) نے بنایا** · [memotrail.ai](https://memotrail.ai)

اگر MemoTrail آپ کی مدد کرتا ہے تو GitHub پر اسٹار دینے پر غور کریں۔

</div>
