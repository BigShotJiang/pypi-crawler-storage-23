<div align="center">

# MemoTrail

> 🌐 यह एक स्वचालित अनुवाद है। समुदाय द्वारा सुधार का स्वागत है! · [English](../../README.md)

[🇨🇳 中文](README.zh-CN.md) · [🇹🇼 繁體中文](README.zh-TW.md) · [🇯🇵 日本語](README.ja.md) · [🇵🇹 Português](README.pt.md) · [🇰🇷 한국어](README.ko.md) · [🇪🇸 Español](README.es.md) · [🇩🇪 Deutsch](README.de.md) · [🇫🇷 Français](README.fr.md) · [🇮🇱 עברית](README.he.md) · [🇸🇦 العربية](README.ar.md) · [🇷🇺 Русский](README.ru.md) · [🇵🇱 Polski](README.pl.md) · [🇨🇿 Čeština](README.cs.md) · [🇳🇱 Nederlands](README.nl.md) · [🇹🇷 Türkçe](README.tr.md) · [🇺🇦 Українська](README.uk.md) · [🇻🇳 Tiếng Việt](README.vi.md) · [🇮🇩 Indonesia](README.id.md) · [🇹🇭 ไทย](README.th.md) · [🇮🇳 हिन्दी](README.hi.md) · [🇧🇩 বাংলা](README.bn.md) · [🇵🇰 اردو](README.ur.md) · [🇷🇴 Română](README.ro.md) · [🇸🇪 Svenska](README.sv.md) · [🇮🇹 Italiano](README.it.md) · [🇬🇷 Ελληνικά](README.el.md) · [🇭🇺 Magyar](README.hu.md) · [🇫🇮 Suomi](README.fi.md) · [🇩🇰 Dansk](README.da.md) · [🇳🇴 Norsk](README.no.md)

**आपका AI कोडिंग सहायक सब कुछ भूल जाता है। MemoTrail इसे ठीक करता है।**

[![PyPI version](https://img.shields.io/pypi/v/memotrail?color=blue)](https://pypi.org/project/memotrail/)
[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](../../LICENSE)
[![GitHub stars](https://img.shields.io/github/stars/HalilHopa-Datatent/memotrail?style=social)](https://github.com/HalilHopa-Datatent/memotrail)

AI कोडिंग सहायकों के लिए एक स्थायी मेमोरी लेयर।
हर सत्र रिकॉर्ड किया गया, हर निर्णय खोजा जा सकता है, हर संदर्भ याद रखा गया।

[त्वरित शुरुआत](#त्वरित-शुरुआत) · [यह कैसे काम करता है](#यह-कैसे-काम-करता-है) · [उपलब्ध उपकरण](#उपलब्ध-उपकरण) · [रोडमैप](#रोडमैप)

</div>

---

## समस्या

हर नया Claude Code सत्र शून्य से शुरू होता है। आपका AI कल के 3 घंटे के डिबगिंग सत्र, पिछले सप्ताह के आर्किटेक्चर निर्णयों, या पहले से विफल हो चुके दृष्टिकोणों को याद नहीं रखता।

**MemoTrail के बिना:**
```
आप: "कैशिंग के लिए Redis का उपयोग करते हैं"
AI:   "ठीक है, Redis सेट करते हैं"
         ... 2 सप्ताह बाद, नया सत्र ...
आप: "हम Redis क्यों उपयोग कर रहे हैं?"
AI:   "मेरे पास इस निर्णय के बारे में कोई संदर्भ नहीं है"
```

**MemoTrail के साथ:**
```
आप: "हम Redis क्यों उपयोग कर रहे हैं?"
AI:   "15 जनवरी के सत्र के आधार पर — आपने Redis बनाम Memcached का मूल्यांकन किया।
       डेटा संरचना समर्थन और स्थायित्व के लिए Redis चुना गया।
       चर्चा सत्र #42 में है।"
```

## त्वरित शुरुआत

```bash
# 1. इंस्टॉल करें
pip install memotrail

# 2. Claude Code से कनेक्ट करें
claude mcp add memotrail -- memotrail serve
```

बस इतना ही। MemoTrail पहली बार लॉन्च करने पर आपके इतिहास को स्वचालित रूप से इंडेक्स करता है।
एक नया सत्र शुरू करें और पूछें: *"हमने पिछले सप्ताह क्या काम किया?"*

## यह कैसे काम करता है

| चरण | क्या होता है |
|:----:|:-------------|
| **1. रिकॉर्ड** | MemoTrail हर सर्वर स्टार्ट पर नए सत्रों को स्वचालित रूप से इंडेक्स करता है |
| **2. विभाजन** | बातचीत को सार्थक खंडों में विभाजित किया जाता है |
| **3. एम्बेडिंग** | प्रत्येक खंड `all-MiniLM-L6-v2` से एम्बेड किया जाता है (~80MB, CPU पर चलता है) |
| **4. स्टोर** | वेक्टर ChromaDB में, मेटाडेटा SQLite में — सब `~/.memotrail/` में |
| **5. खोज** | अगले सत्र में, Claude आपके पूरे इतिहास में सिमेंटिक खोज करता है |
| **6. प्रदर्शन** | सबसे प्रासंगिक पिछला संदर्भ ठीक तब दिखाई देता है जब आपको इसकी आवश्यकता होती है |

> **100% स्थानीय** — कोई क्लाउड नहीं, कोई API कुंजी नहीं, कोई डेटा आपकी मशीन नहीं छोड़ता।

## उपलब्ध उपकरण

कनेक्ट होने के बाद, Claude Code को ये MCP उपकरण मिलते हैं:

| उपकरण | विवरण |
|------|-------------|
| `search_chats` | सभी पिछली बातचीत में सिमेंटिक खोज |
| `get_decisions` | रिकॉर्ड किए गए आर्किटेक्चर निर्णय प्राप्त करें |
| `get_recent_sessions` | सारांश के साथ हालिया कोडिंग सत्रों की सूची |
| `get_session_detail` | एक विशिष्ट सत्र की सामग्री का विस्तृत अवलोकन |
| `save_memory` | महत्वपूर्ण तथ्य या निर्णय मैन्युअल रूप से सहेजें |
| `memory_stats` | इंडेक्सिंग आंकड़े और स्टोरेज उपयोग देखें |

## CLI कमांड

```bash
memotrail serve                          # MCP सर्वर शुरू करें (नए सत्रों को स्वचालित इंडेक्स करता है)
memotrail search "redis caching decision"  # टर्मिनल से खोजें
memotrail stats                          # इंडेक्सिंग आंकड़े देखें
memotrail index                          # मैन्युअल रूप से री-इंडेक्स करें (वैकल्पिक)
```

## आर्किटेक्चर

```
~/.memotrail/
├── chroma/          # वेक्टर एम्बेडिंग (ChromaDB)
└── memotrail.db     # सत्र मेटाडेटा (SQLite)
```

| घटक | तकनीक | विवरण |
|-----------|-----------|---------|
| एम्बेडिंग | `all-MiniLM-L6-v2` | ~80MB, CPU पर चलता है |
| वेक्टर DB | ChromaDB | स्थायी स्थानीय स्टोरेज |
| मेटाडेटा | SQLite | एकल-फ़ाइल डेटाबेस |
| प्रोटोकॉल | MCP | Model Context Protocol |

## MemoTrail क्यों?

| | MemoTrail | CLAUDE.md / नियम फ़ाइलें | मैन्युअल नोट्स |
|---|---|---|---|
| स्वचालित | हाँ — हर सत्र शुरुआत पर इंडेक्स | नहीं — आप लिखते हैं | नहीं |
| खोजने योग्य | सिमेंटिक खोज | AI पढ़ता है, लेकिन केवल जो आपने लिखा | केवल Ctrl+F |
| स्केलेबल | हज़ारों सत्र | एकल फ़ाइल | बिखरी हुई फ़ाइलें |
| संदर्भ-जागरूक | प्रासंगिक संदर्भ लौटाता है | स्थिर नियम | मैन्युअल खोज |
| सेटअप | 5 मिनट | निरंतर रखरखाव | निरंतर रखरखाव |

MemoTrail `CLAUDE.md` की जगह नहीं लेता — यह उसका पूरक है। नियम फ़ाइलें निर्देशों के लिए हैं। MemoTrail मेमोरी के लिए है।

## रोडमैप

- [x] Claude Code सत्र इंडेक्सिंग
- [x] बातचीत में सिमेंटिक खोज
- [x] 6 उपकरणों के साथ MCP सर्वर
- [x] इंडेक्सिंग और खोज के लिए CLI
- [x] सर्वर स्टार्टअप पर ऑटो-इंडेक्सिंग
- [ ] स्वचालित निर्णय निष्कर्षण
- [ ] सत्र सारांश
- [ ] Cursor कलेक्टर
- [ ] Copilot कलेक्टर
- [ ] VS Code एक्सटेंशन
- [ ] क्लाउड सिंक (Pro)
- [ ] टीम मेमोरी (Team)

## विकास

```bash
git clone https://github.com/HalilHopa-Datatent/memotrail.git
cd memotrail
pip install -e ".[dev]"
pytest
ruff check src/
```

## योगदान

योगदान का स्वागत है! दिशानिर्देशों के लिए [CONTRIBUTING.md](../../docs/CONTRIBUTING.md) देखें।

## लाइसेंस

MIT — [LICENSE](../../LICENSE) देखें

---

<div align="center">

**[Halil Hopa](https://halilhopa.com) द्वारा निर्मित** · [memotrail.ai](https://memotrail.ai)

अगर MemoTrail आपकी मदद करता है, तो GitHub पर एक स्टार देने पर विचार करें।

</div>
