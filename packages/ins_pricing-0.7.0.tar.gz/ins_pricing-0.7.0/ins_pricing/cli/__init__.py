"""CLI entry points for ins_pricing modelling."""
