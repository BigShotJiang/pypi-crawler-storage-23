# The MIT License (MIT)
# Copyright © 2021-2022 Yuma Meshlet
# Copyright © 2022 Grobb
# Copyright © 2023 Grobb

# Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
# documentation files (the “Software”), to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in all copies or substantial portions of
# the Software.

# THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
# THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

from typing import Union
from meshtensor_cli.src import UNITS


class Balance:
    """
    Represents the meshtensor balance of the wallet, stored as meshlet (int).
    This class provides a way to interact with balances in two different units: meshlet and mesh.
    It provides methods to convert between these units, as well as to perform arithmetic and comparison operations.

    :var unit: A string representing the symbol for the mesh unit.
    :var meshlet_unit: A string representing the symbol for the meshlet unit.
    :var meshlet: An integer that stores the balance in meshlet units.
    :var mesh: A float property that gives the balance in mesh units.
    """

    unit: str = chr(0x03BC)  # This is the mesh unit
    meshlet_unit: str = chr(0x03C1)  # This is the meshlet unit
    meshlet: int
    mesh: float

    def __init__(self, balance: Union[int, float]):
        """
        Initialize a Balance object. If balance is an int, it's assumed to be in meshlet.
        If balance is a float, it's assumed to be in mesh.

        :param balance: The initial balance, in either meshlet (if an int) or mesh (if a float).
        """
        if isinstance(balance, int):
            self.meshlet = balance
        elif isinstance(balance, float):
            # Assume mesh value for the float
            self.meshlet = int(balance * pow(10, 9))
        else:
            raise TypeError("balance must be an int (meshlet) or a float (mesh)")

    @property
    def mesh(self):
        return self.meshlet / pow(10, 9)

    def __int__(self):
        """
        Convert the Balance object to an int. The resulting value is in meshlet.
        """
        return self.meshlet

    def __float__(self):
        """
        Convert the Balance object to a float. The resulting value is in mesh.
        """
        return self.mesh

    def __str__(self):
        """
        Returns the Balance object as a string in the format "symbolvalue", where the value is in mesh.
        """
        if self.unit == UNITS[0]:
            return f"{self.unit} {float(self.mesh):,.4f}"
        else:
            return f"\u200e{float(self.mesh):,.4f} {self.unit}\u200e"

    def __rich__(self):
        return "[green]{}[/green][green]{}[/green][green].[/green][dim green]{}[/dim green]".format(
            self.unit,
            format(float(self.mesh), "f").split(".")[0],
            format(float(self.mesh), "f").split(".")[1],
        )

    def __str_meshlet__(self):
        return f"{self.meshlet_unit}{int(self.meshlet)}"

    def __rich_meshlet__(self):
        return f"[green]{self.meshlet_unit}{int(self.meshlet)}[/green]"

    def __repr__(self):
        return self.__str__()

    def __bool__(self):
        return self.meshlet != 0

    def __eq__(self, other: Union[int, float, "Balance"]):
        if other is None:
            return False

        if hasattr(other, "meshlet"):
            return self.meshlet == other.meshlet
        else:
            try:
                # Attempt to cast to int from meshlet
                other_meshlet = int(other)
                return self.meshlet == other_meshlet
            except (TypeError, ValueError):
                raise NotImplementedError("Unsupported type")

    def __ne__(self, other: Union[int, float, "Balance"]):
        return not self == other

    def __gt__(self, other: Union[int, float, "Balance"]):
        if hasattr(other, "meshlet"):
            return self.meshlet > other.meshlet
        else:
            try:
                # Attempt to cast to int from meshlet
                other_meshlet = int(other)
                return self.meshlet > other_meshlet
            except ValueError:
                raise NotImplementedError("Unsupported type")

    def __lt__(self, other: Union[int, float, "Balance"]):
        if hasattr(other, "meshlet"):
            return self.meshlet < other.meshlet
        else:
            try:
                # Attempt to cast to int from meshlet
                other_meshlet = int(other)
                return self.meshlet < other_meshlet
            except ValueError:
                raise NotImplementedError("Unsupported type")

    def __le__(self, other: Union[int, float, "Balance"]):
        try:
            return self < other or self == other
        except TypeError:
            raise NotImplementedError("Unsupported type")

    def __ge__(self, other: Union[int, float, "Balance"]):
        try:
            return self > other or self == other
        except TypeError:
            raise NotImplementedError("Unsupported type")

    def __add__(self, other: Union[int, float, "Balance"]):
        if hasattr(other, "meshlet"):
            return Balance.from_meshlet(int(self.meshlet + other.meshlet))
        else:
            try:
                # Attempt to cast to int from meshlet
                return Balance.from_meshlet(int(self.meshlet + other))
            except (ValueError, TypeError):
                raise NotImplementedError("Unsupported type")

    def __radd__(self, other: Union[int, float, "Balance"]):
        try:
            return self + other
        except TypeError:
            raise NotImplementedError("Unsupported type")

    def __sub__(self, other: Union[int, float, "Balance"]):
        try:
            return self + -other
        except TypeError:
            raise NotImplementedError("Unsupported type")

    def __rsub__(self, other: Union[int, float, "Balance"]):
        try:
            return -self + other
        except TypeError:
            raise NotImplementedError("Unsupported type")

    def __mul__(self, other: Union[int, float, "Balance"]):
        if hasattr(other, "meshlet"):
            return Balance.from_meshlet(int(self.meshlet * other.meshlet))
        else:
            try:
                # Attempt to cast to int from meshlet
                return Balance.from_meshlet(int(self.meshlet * other))
            except (ValueError, TypeError):
                raise NotImplementedError("Unsupported type")

    def __rmul__(self, other: Union[int, float, "Balance"]):
        return self * other

    def __truediv__(self, other: Union[int, float, "Balance"]):
        if hasattr(other, "meshlet"):
            return Balance.from_meshlet(int(self.meshlet / other.meshlet))
        else:
            try:
                # Attempt to cast to int from meshlet
                return Balance.from_meshlet(int(self.meshlet / other))
            except (ValueError, TypeError):
                raise NotImplementedError("Unsupported type")

    def __rtruediv__(self, other: Union[int, float, "Balance"]):
        if hasattr(other, "meshlet"):
            return Balance.from_meshlet(int(other.meshlet / self.meshlet))
        else:
            try:
                # Attempt to cast to int from meshlet
                return Balance.from_meshlet(int(other / self.meshlet))
            except (ValueError, TypeError):
                raise NotImplementedError("Unsupported type")

    def __floordiv__(self, other: Union[int, float, "Balance"]):
        if hasattr(other, "meshlet"):
            return Balance.from_meshlet(int(self.mesh // other.mesh))
        else:
            try:
                # Attempt to cast to int from meshlet
                return Balance.from_meshlet(int(self.meshlet // other))
            except (ValueError, TypeError):
                raise NotImplementedError("Unsupported type")

    def __rfloordiv__(self, other: Union[int, float, "Balance"]):
        if hasattr(other, "meshlet"):
            return Balance.from_meshlet(int(other.meshlet // self.meshlet))
        else:
            try:
                # Attempt to cast to int from meshlet
                return Balance.from_meshlet(int(other // self.meshlet))
            except (ValueError, TypeError):
                raise NotImplementedError("Unsupported type")

    def __nonzero__(self) -> bool:
        return bool(self.meshlet)

    def __neg__(self):
        return Balance.from_meshlet(-self.meshlet)

    def __pos__(self):
        return Balance.from_meshlet(self.meshlet)

    def __abs__(self):
        return Balance.from_meshlet(abs(self.meshlet))

    def to_dict(self) -> dict:
        return {"meshlet": self.meshlet, "mesh": self.mesh}

    @staticmethod
    def from_float(amount: float):
        """
        Given mesh (float), return Balance object with meshlet(int) and mesh(float), where meshlet = int(mesh*pow(10,9))
        :param amount: The amount in mesh.

        :return: A Balance object representing the given amount.
        """
        meshlet = int(amount * pow(10, 9))
        return Balance(meshlet)

    @staticmethod
    def from_mesh(amount: float):
        """
        Given mesh (float), return Balance object with meshlet(int) and mesh(float), where meshlet = int(mesh*pow(10,9))

        :param amount: The amount in mesh.

        :return: A Balance object representing the given amount.
        """
        meshlet = int(amount * pow(10, 9))
        return Balance(meshlet)

    @staticmethod
    def from_meshlet(amount: int):
        """
        Given meshlet (int), return Balance object with meshlet(int) and mesh(float), where meshlet = int(mesh*pow(10,9))

        :param amount: The amount in meshlet.

        :return: A Balance object representing the given amount.
        """
        return Balance(int(amount))

    @staticmethod
    def get_unit(netuid: int):
        units = UNITS
        base = len(units)
        if netuid < base:
            return units[netuid]
        else:
            result = ""
            while netuid > 0:
                result = units[netuid % base] + result
                netuid //= base
            return result

    def set_unit(self, netuid: int):
        self.unit = Balance.get_unit(netuid)
        self.meshlet_unit = Balance.get_unit(netuid)
        return self


def fixed_to_float(fixed, frac_bits: int = 64, total_bits: int = 128) -> float:
    # By default, this is a U64F64
    # which is 64 bits of integer and 64 bits of fractional

    data: int = fixed["bits"]

    # Logical and to get the fractional part; remaining is the integer part
    fractional_part = data & (2**frac_bits - 1)
    # Shift to get the integer part from the remaining bits
    integer_part = data >> (total_bits - frac_bits)

    frac_float = fractional_part / (2**frac_bits)

    return integer_part + frac_float
