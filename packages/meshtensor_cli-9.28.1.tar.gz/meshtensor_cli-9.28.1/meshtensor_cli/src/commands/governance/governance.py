"""
Governance commands for meshcli.

Provides commands for interacting with the Meshtensor on-chain governance system:
- Submit referenda
- Vote on active proposals
- Delegate voting power
- View governance status
"""

import asyncio
import json
import sys
from typing import TYPE_CHECKING, Optional

from meshtensor_wallet import Wallet

from meshtensor_cli.src.meshtensor.balances import Balance
from rich import box
from rich.table import Column, Table

from meshtensor_cli.src.meshtensor.utils import (
    confirm_action,
    console,
    print_error,
    print_success,
    print_verbose,
    unlock_key,
    blocks_to_duration,
    json_console,
    print_extrinsic_id,
)

if TYPE_CHECKING:
    from meshtensor_cli.src.meshtensor.meshtensor_interface import MeshtensorInterface


# ============================================================================
# Constants
# ============================================================================

GOVERNANCE_TRACKS = {
    0: {"name": "Root", "description": "Runtime upgrades & consensus changes", "origin": {"system": "Root"}},
    1: {"name": "Treasury", "description": "Fund allocation & grants", "origin": {"GovernanceOrigins": "Treasurer"}},
    2: {"name": "Param-Critical", "description": "Critical network parameters", "origin": {"GovernanceOrigins": "ParameterCritical"}},
    3: {"name": "Param-Standard", "description": "Standard network parameters", "origin": {"GovernanceOrigins": "ParameterStandard"}},
    4: {"name": "Subnet", "description": "Subnet-scoped governance", "origin": {"GovernanceOrigins": "SubnetGovernance"}},
    5: {"name": "Emergency", "description": "Emergency actions (TC co-signed)", "origin": {"GovernanceOrigins": "Emergency"}},
    6: {"name": "CriticalUpgrade", "description": "Critical runtime upgrades", "origin": {"GovernanceOrigins": "CriticalUpgrade"}},
}

CONVICTION_LEVELS = {
    0: {"multiplier": "0.5x", "lock": "No lock"},
    1: {"multiplier": "1.0x", "lock": "1x enactment period"},
    2: {"multiplier": "1.5x", "lock": "2x enactment period"},
    3: {"multiplier": "2.0x", "lock": "4x enactment period"},
    4: {"multiplier": "2.5x", "lock": "8x enactment period"},
    5: {"multiplier": "3.0x", "lock": "16x enactment period"},
    6: {"multiplier": "3.5x", "lock": "32x enactment period"},
}


# ============================================================================
# meshcli governance propose
# ============================================================================

async def governance_propose(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    track: int,
    call_data: str,
    deposit: float,
    enactment_delay: int,
    description: str = "",
    quiet: bool = False,
    verbose: bool = False,
):
    """Submit a new referendum proposal."""

    if track not in GOVERNANCE_TRACKS:
        print_error(f"Invalid track: {track}. Must be 0-6.")
        return

    track_info = GOVERNANCE_TRACKS[track]
    if not quiet:
        console.print(
            f"\n[bold]Submitting referendum on {track_info['name']} Track[/bold]"
        )
        console.print(f"  Track: {track} ({track_info['description']})")
        console.print(f"  Deposit: {deposit} MESH")
        console.print(f"  Enactment delay: {enactment_delay} blocks")
        if description:
            console.print(f"  Description: {description}")

    if not confirm_action("Submit this referendum?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="Referenda",
            call_function="submit",
            call_params={
                "proposal_origin": track_info["origin"],
                "proposal": {"Inline": call_data},
                "enactment_moment": {"After": enactment_delay},
            },
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success(f"Referendum submitted successfully on {track_info['name']} Track")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to submit referendum: {await response.error_message}")
    except Exception as e:
        print_error(f"Error submitting referendum: {e}")


# ============================================================================
# meshcli governance vote
# ============================================================================

async def governance_vote(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    ref_index: int,
    vote: str,
    conviction: int = 1,
    quiet: bool = False,
    verbose: bool = False,
):
    """Vote on an active referendum."""

    if vote.lower() not in ("aye", "nay", "abstain"):
        print_error("Vote must be 'aye', 'nay', or 'abstain'.")
        return

    if conviction not in CONVICTION_LEVELS:
        print_error(f"Invalid conviction level: {conviction}. Must be 0-6.")
        return

    conv_info = CONVICTION_LEVELS[conviction]
    if not quiet:
        console.print(f"\n[bold]Voting on Referendum #{ref_index}[/bold]")
        console.print(f"  Vote: {vote.upper()}")
        console.print(f"  Conviction: {conviction} ({conv_info['multiplier']}, {conv_info['lock']})")

    if not confirm_action("Confirm vote?"):
        return

    if not unlock_key(wallet):
        return

    try:
        is_aye = vote.lower() == "aye"
        conviction_value = f"Locked{conviction}x" if conviction > 0 else "None"

        if vote.lower() == "abstain":
            call = await meshtensor.substrate.compose_call(
                call_module="MeshtensorVoting",
                call_function="vote",
                call_params={
                    "poll_index": ref_index,
                    "vote": {
                        "SplitAbstain": {
                            "aye": 0,
                            "nay": 0,
                            "abstain": 1,
                        }
                    },
                },
            )
        else:
            call = await meshtensor.substrate.compose_call(
                call_module="MeshtensorVoting",
                call_function="vote",
                call_params={
                    "poll_index": ref_index,
                    "vote": {
                        "Standard": {
                            "vote": {"aye": is_aye, "conviction": conviction_value},
                            "balance": 0,  # Use full available balance
                        }
                    },
                },
            )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success(f"Vote cast successfully: {vote.upper()} on referendum #{ref_index}")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to vote: {await response.error_message}")
    except Exception as e:
        print_error(f"Error voting: {e}")


# ============================================================================
# meshcli governance delegate
# ============================================================================

async def governance_delegate(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    track: int,
    delegatee: str,
    conviction: int = 1,
    quiet: bool = False,
    verbose: bool = False,
):
    """Delegate voting power to another account for a specific track."""

    if track not in GOVERNANCE_TRACKS:
        print_error(f"Invalid track: {track}. Must be 0-6.")
        return

    if conviction not in CONVICTION_LEVELS:
        print_error(f"Invalid conviction: {conviction}. Must be 0-6.")
        return

    track_info = GOVERNANCE_TRACKS[track]
    conv_info = CONVICTION_LEVELS[conviction]

    if not quiet:
        console.print(f"\n[bold]Delegating Voting Power[/bold]")
        console.print(f"  Track: {track} ({track_info['name']})")
        console.print(f"  Delegatee: {delegatee}")
        console.print(f"  Conviction: {conviction} ({conv_info['multiplier']})")

    if not confirm_action("Confirm delegation?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="MeshtensorGovernance",
            call_function="delegate",
            call_params={
                "track": track,
                "delegatee": delegatee,
                "conviction": conviction,
            },
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success(
                f"Delegated to {delegatee[:8]}...{delegatee[-8:]} on {track_info['name']} Track"
            )
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to delegate: {await response.error_message}")
    except Exception as e:
        print_error(f"Error delegating: {e}")


# ============================================================================
# meshcli governance undelegate
# ============================================================================

async def governance_undelegate(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    track: int,
    quiet: bool = False,
    verbose: bool = False,
):
    """Revoke a delegation for a specific track."""

    if track not in GOVERNANCE_TRACKS:
        print_error(f"Invalid track: {track}. Must be 0-6.")
        return

    track_info = GOVERNANCE_TRACKS[track]

    if not quiet:
        console.print(f"\n[bold]Revoking Delegation[/bold]")
        console.print(f"  Track: {track} ({track_info['name']})")

    if not confirm_action("Revoke delegation?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="MeshtensorGovernance",
            call_function="undelegate",
            call_params={"track": track},
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success(f"Delegation revoked on {track_info['name']} Track")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to undelegate: {await response.error_message}")
    except Exception as e:
        print_error(f"Error undelegating: {e}")


# ============================================================================
# meshcli governance list
# ============================================================================

async def governance_list(
    meshtensor: "MeshtensorInterface",
    track: Optional[int] = None,
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """List active referenda, optionally filtered by track."""

    try:
        # Query all active referenda from pallet_referenda
        referenda = await meshtensor.substrate.query_map(
            module="Referenda",
            storage_function="ReferendumInfoFor",
        )

        results = []
        async for ref_index, ref_info in referenda:
            ref_data = ref_info.value if hasattr(ref_info, "value") else ref_info
            if isinstance(ref_data, dict) and "Ongoing" in ref_data:
                ongoing_raw = ref_data["Ongoing"]
                # SCALE decoder wraps enum variant values in a tuple
                ongoing = ongoing_raw[0] if isinstance(ongoing_raw, tuple) else ongoing_raw
                ref_track = ongoing.get("track", -1)
                if track is not None and ref_track != track:
                    continue
                tally = ongoing.get("tally", {})
                results.append({
                    "index": ref_index,
                    "track": ref_track,
                    "track_name": GOVERNANCE_TRACKS.get(ref_track, {}).get("name", "Unknown"),
                    "tally_ayes": tally.get("ayes", 0),
                    "tally_nays": tally.get("nays", 0),
                    "tally_support": tally.get("support", 0),
                    "submitted": ongoing.get("submitted", 0),
                })

        if output_json:
            json_console.print_json(json.dumps(results))
            return

        if not results:
            console.print("[dim]No active referenda found.[/dim]")
            return

        table = Table(
            Column("Index", style="bold cyan"),
            Column("Track", style="bold"),
            Column("Ayes", style="green"),
            Column("Nays", style="red"),
            Column("Support", style="yellow"),
            Column("Submitted", style="dim"),
            title="Active Referenda",
            box=box.ROUNDED,
        )

        for ref in sorted(results, key=lambda r: r["index"]):
            table.add_row(
                str(ref["index"]),
                f"{ref['track_name']} ({ref['track']})",
                str(ref["tally_ayes"]),
                str(ref["tally_nays"]),
                str(ref["tally_support"]),
                str(ref["submitted"]),
            )

        console.print(table)
        console.print(f"\n[dim]Total: {len(results)} active referenda[/dim]")

    except Exception as e:
        print_error(f"Error listing referenda: {e}")


# ============================================================================
# meshcli governance info
# ============================================================================

async def governance_info(
    meshtensor: "MeshtensorInterface",
    ref_index: int,
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """Show detailed information about a specific referendum."""

    try:
        ref_info = await meshtensor.substrate.query(
            module="Referenda",
            storage_function="ReferendumInfoFor",
            params=[ref_index],
        )

        if ref_info is None:
            print_error(f"Referendum #{ref_index} not found.")
            return

        ref_data = ref_info.value if hasattr(ref_info, "value") else ref_info

        if output_json:
            json_console.print_json(json.dumps(ref_data, default=str))
            return

        console.print(f"\n[bold]Referendum #{ref_index}[/bold]")
        console.print(f"  Status: {list(ref_data.keys())[0] if isinstance(ref_data, dict) else 'Unknown'}")

        if isinstance(ref_data, dict) and "Ongoing" in ref_data:
            ongoing_raw = ref_data["Ongoing"]
            ongoing = ongoing_raw[0] if isinstance(ongoing_raw, tuple) else ongoing_raw
            track_id = ongoing.get("track", -1)
            track_info = GOVERNANCE_TRACKS.get(track_id, {"name": "Unknown"})

            console.print(f"  Track: {track_info['name']} ({track_id})")
            console.print(f"  Submitted at block: {ongoing.get('submitted', 'N/A')}")

            tally = ongoing.get("tally", {})
            console.print(f"  Ayes: {tally.get('ayes', 0)}")
            console.print(f"  Nays: {tally.get('nays', 0)}")
            console.print(f"  Support: {tally.get('support', 0)}")

    except Exception as e:
        print_error(f"Error fetching referendum info: {e}")


# ============================================================================
# meshcli governance power
# ============================================================================

async def governance_power(
    meshtensor: "MeshtensorInterface",
    account: str,
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """Show voting power breakdown for an account."""

    try:
        # Query contribution score from MeshtensorGovernance pallet
        contribution_score = await meshtensor.substrate.query(
            module="MeshtensorGovernance",
            storage_function="ContributionScore",
            params=[account],
        )

        # Query stake deposit block for duration bonus
        stake_deposit = await meshtensor.substrate.query(
            module="MeshtensorGovernance",
            storage_function="StakeDepositBlock",
            params=[account],
        )

        # Query total staked balance via the interface method
        stake_results = await meshtensor.get_total_stake_for_coldkey(account)
        mesh_value, _ = stake_results.get(account, (Balance(0), Balance(0)))
        raw_stake = int(mesh_value.meshlet)
        cw = contribution_score.value if contribution_score else 0

        if output_json:
            data = {
                "account": account,
                "raw_stake": raw_stake,
                "contribution_score": cw,
                "stake_deposit_block": stake_deposit.value if stake_deposit else None,
            }
            json_console.print_json(json.dumps(data, default=str))
            return

        console.print(f"\n[bold]Voting Power Breakdown[/bold]")
        console.print(f"  Account: {account[:8]}...{account[-8:]}")
        console.print(f"  Raw Stake: {raw_stake / 1e9:.4f} MESH")
        console.print(f"  Contribution Score: {cw}/1000")
        console.print(
            f"  Stake Since Block: {stake_deposit.value if stake_deposit else 'N/A'}"
        )
        console.print()

        # Show per-track VP estimates
        table = Table(
            Column("Track", style="bold"),
            Column("α (Stake)", style="cyan"),
            Column("β (Contrib)", style="green"),
            Column("γ (Activity)", style="yellow"),
            title="Track Coefficients",
            box=box.SIMPLE,
        )
        track_coefficients = [
            (0, "Root", 0.35, 0.35, 0.30),
            (1, "Treasury", 0.35, 0.40, 0.25),
            (2, "Param-Crit", 0.30, 0.45, 0.25),
            (3, "Param-Std", 0.30, 0.45, 0.25),
            (4, "Subnet", 0.25, 0.50, 0.25),
            (5, "Emergency", 0.25, 0.30, 0.45),
            (6, "CritUpgrade", 0.30, 0.70, 0.00),
        ]
        for tid, name, a, b, g in track_coefficients:
            table.add_row(f"{name} ({tid})", f"{a:.2f}", f"{b:.2f}", f"{g:.2f}")

        console.print(table)

    except Exception as e:
        print_error(f"Error fetching voting power: {e}")


# ============================================================================
# meshcli governance tracks
# ============================================================================

async def governance_tracks(
    meshtensor: "MeshtensorInterface",
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """Show governance track configuration."""

    tracks_data = [
        {"id": 0, "name": "Root", "approval": "66%", "support": "20%",
         "decision": "28 days", "enactment": "14 days", "deposit": "10,000 MESH"},
        {"id": 1, "name": "Treasury", "approval": "55%", "support": "15%",
         "decision": "14 days", "enactment": "7 days", "deposit": "1,000 MESH"},
        {"id": 2, "name": "Param-Critical", "approval": "60%", "support": "15%",
         "decision": "14 days", "enactment": "7 days", "deposit": "5,000 MESH"},
        {"id": 3, "name": "Param-Standard", "approval": "55%", "support": "15%",
         "decision": "7 days", "enactment": "3 days", "deposit": "1,000 MESH"},
        {"id": 4, "name": "Subnet", "approval": "50%", "support": "10%",
         "decision": "7 days", "enactment": "2 days", "deposit": "100 MESH"},
        {"id": 5, "name": "Emergency", "approval": "75%", "support": "25%",
         "decision": "3 days", "enactment": "6 hours", "deposit": "TC-waived"},
        {"id": 6, "name": "CriticalUpgrade", "approval": "75%", "support": "25%",
         "decision": "14 days", "enactment": "7 days", "deposit": "100 MESH"},
    ]

    if output_json:
        json_console.print_json(json.dumps(tracks_data))
        return

    table = Table(
        Column("ID", style="bold"),
        Column("Track", style="bold cyan"),
        Column("Approval", style="green"),
        Column("Support", style="yellow"),
        Column("Decision", style="dim"),
        Column("Enactment", style="dim"),
        Column("Deposit", style="magenta"),
        title="Governance Tracks",
        box=box.ROUNDED,
    )

    for t in tracks_data:
        table.add_row(
            str(t["id"]),
            t["name"],
            t["approval"],
            t["support"],
            t["decision"],
            t["enactment"],
            t["deposit"],
        )

    console.print(table)
    console.print("\n[dim]All deposits include a 10% non-refundable burn component.[/dim]")


# ============================================================================
# meshcli governance history
# ============================================================================

async def governance_history(
    meshtensor: "MeshtensorInterface",
    limit: int = 20,
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """Show recent referendum history."""

    try:
        referenda = await meshtensor.substrate.query_map(
            module="Referenda",
            storage_function="ReferendumInfoFor",
        )

        results = []
        async for ref_index, ref_info in referenda:
            ref_data = ref_info.value if hasattr(ref_info, "value") else ref_info
            idx = ref_index.value if hasattr(ref_index, "value") else ref_index
            if isinstance(ref_data, dict):
                status = list(ref_data.keys())[0]
                results.append({"index": idx, "status": status, "data": ref_data})

        results.sort(key=lambda r: r["index"], reverse=True)
        results = results[:limit]

        if output_json:
            json_console.print_json(json.dumps(results, default=str))
            return

        if not results:
            console.print("[dim]No referendum history found.[/dim]")
            return

        table = Table(
            Column("Index", style="bold"),
            Column("Status", style="bold"),
            title=f"Referendum History (last {limit})",
            box=box.ROUNDED,
        )

        for ref in results:
            status = ref["status"]
            style = {
                "Ongoing": "yellow",
                "Approved": "green",
                "Rejected": "red",
                "Cancelled": "dim",
                "TimedOut": "dim red",
                "Killed": "bold red",
            }.get(status, "white")
            table.add_row(str(ref["index"]), f"[{style}]{status}[/{style}]")

        console.print(table)

    except Exception as e:
        print_error(f"Error fetching referendum history: {e}")


# ============================================================================
# meshcli governance signal-golr
# ============================================================================

async def governance_signal_golr(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    quiet: bool = False,
    verbose: bool = False,
):
    """Signal support for Governance of Last Resort (GoLR) activation.

    Only callable by validators when governance has been paralyzed for 180+ days.
    When 80% of validators signal, reduced threshold mode activates, halving
    approval thresholds on all tracks.
    """

    if not quiet:
        console.print(f"\n[bold]Signaling GoLR Activation[/bold]")
        console.print(f"  [dim]GoLR activates when 80% of validators signal[/dim]")
        console.print(f"  [dim]Requires 180+ days of governance paralysis[/dim]")

    if not confirm_action("Signal GoLR activation?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="MeshtensorGovernance",
            call_function="signal_golr",
            call_params={},
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success("GoLR signal submitted successfully")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to signal GoLR: {await response.error_message}")
    except Exception as e:
        print_error(f"Error signaling GoLR: {e}")


# ============================================================================
# meshcli governance update-scores
# ============================================================================

async def governance_update_scores(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    quiet: bool = False,
    verbose: bool = False,
):
    """Trigger contribution score recalculation for the current epoch.

    This is a permissionless call — anyone can trigger the computation.
    """

    if not quiet:
        console.print(f"\n[bold]Updating Contribution Scores[/bold]")

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="MeshtensorGovernance",
            call_function="update_contribution_scores",
            call_params={},
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success("Contribution scores updated")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to update scores: {await response.error_message}")
    except Exception as e:
        print_error(f"Error updating scores: {e}")


# ============================================================================
# meshcli governance distribute-rewards
# ============================================================================

async def governance_distribute_rewards(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    quiet: bool = False,
    verbose: bool = False,
):
    """Distribute governance rewards from the reward pool.

    This is a permissionless call — anyone can trigger the distribution.
    """

    if not quiet:
        console.print(f"\n[bold]Distributing Governance Rewards[/bold]")

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="MeshtensorGovernance",
            call_function="distribute_governance_rewards",
            call_params={},
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success("Governance rewards distributed")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to distribute rewards: {await response.error_message}")
    except Exception as e:
        print_error(f"Error distributing rewards: {e}")


# ============================================================================
# meshcli governance endorse
# ============================================================================

async def governance_endorse(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    ref_index: int,
    track: int,
    quiet: bool = False,
    verbose: bool = False,
):
    """Endorse a referendum as a TC or subnet council member."""

    if track not in GOVERNANCE_TRACKS:
        print_error(f"Invalid track: {track}. Must be 0-6.")
        return

    if not quiet:
        console.print(f"\n[bold]Endorsing Referendum #{ref_index}[/bold]")
        console.print(f"  Track: {track} ({GOVERNANCE_TRACKS[track]['name']})")

    if not confirm_action("Endorse this referendum?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="MeshtensorGovernance",
            call_function="endorse_referendum",
            call_params={
                "referendum_index": ref_index,
                "track": track,
            },
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success(f"Endorsed referendum #{ref_index} on {GOVERNANCE_TRACKS[track]['name']} Track")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to endorse: {await response.error_message}")
    except Exception as e:
        print_error(f"Error endorsing referendum: {e}")


# ============================================================================
# meshcli governance cancel
# ============================================================================

async def governance_cancel(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    ref_index: int,
    quiet: bool = False,
    verbose: bool = False,
):
    """Cancel an active referendum."""

    if not quiet:
        console.print(f"\n[bold]Cancelling Referendum #{ref_index}[/bold]")

    if not confirm_action("Cancel this referendum?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="Referenda",
            call_function="cancel",
            call_params={"idx": ref_index},
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success(f"Referendum #{ref_index} cancelled")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to cancel: {await response.error_message}")
    except Exception as e:
        print_error(f"Error cancelling referendum: {e}")


# ============================================================================
# meshcli governance claim-rewards
# ============================================================================

async def governance_claim_rewards(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    quiet: bool = False,
    verbose: bool = False,
):
    """Claim pending governance rewards."""

    if not quiet:
        console.print(f"\n[bold]Claiming Governance Rewards[/bold]")

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="MeshtensorGovernance",
            call_function="claim_governance_rewards",
            call_params={},
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success("Governance rewards claimed")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to claim rewards: {await response.error_message}")
    except Exception as e:
        print_error(f"Error claiming rewards: {e}")


# ============================================================================
# meshcli governance approve-treasury
# ============================================================================

async def governance_approve_treasury(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    proposal_id: int,
    quiet: bool = False,
    verbose: bool = False,
):
    """Approve a pending treasury proposal."""

    if not quiet:
        console.print(f"\n[bold]Approving Treasury Proposal #{proposal_id}[/bold]")

    if not confirm_action("Approve this treasury proposal?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="Treasury",
            call_function="approve_proposal",
            call_params={"proposal_id": proposal_id},
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success(f"Treasury proposal #{proposal_id} approved")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to approve: {await response.error_message}")
    except Exception as e:
        print_error(f"Error approving treasury proposal: {e}")


# ============================================================================
# meshcli governance submit-preimage
# ============================================================================

async def governance_submit_preimage(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    encoded_call: str,
    quiet: bool = False,
    verbose: bool = False,
):
    """Submit a preimage (encoded call bytes) on-chain."""

    if not quiet:
        console.print(f"\n[bold]Submitting Preimage[/bold]")
        console.print(f"  Encoded call length: {len(encoded_call)} chars")

    if not confirm_action("Submit this preimage?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call_bytes = bytes.fromhex(encoded_call.replace("0x", ""))
        call = await meshtensor.substrate.compose_call(
            call_module="Preimage",
            call_function="note_preimage",
            call_params={"bytes": list(call_bytes)},
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success("Preimage submitted successfully")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to submit preimage: {await response.error_message}")
    except Exception as e:
        print_error(f"Error submitting preimage: {e}")


# ============================================================================
# meshcli governance set-track-coefficients
# ============================================================================

async def governance_set_track_coefficients(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    track_id: int,
    alpha: int,
    beta: int,
    gamma: int,
    quiet: bool = False,
    verbose: bool = False,
):
    """Set VP formula coefficients for a governance track. Root-only."""

    if track_id not in GOVERNANCE_TRACKS:
        print_error(f"Invalid track: {track_id}. Must be 0-6.")
        return

    if not quiet:
        console.print(f"\n[bold]Setting Track Coefficients[/bold]")
        console.print(f"  Track: {track_id} ({GOVERNANCE_TRACKS[track_id]['name']})")
        console.print(f"  Alpha: {alpha}, Beta: {beta}, Gamma: {gamma}")

    if not confirm_action("Set these coefficients?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="MeshtensorGovernance",
            call_function="set_track_coefficients",
            call_params={
                "track_id": track_id,
                "alpha": alpha,
                "beta": beta,
                "gamma": gamma,
            },
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success(f"Track {track_id} coefficients updated")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to set coefficients: {await response.error_message}")
    except Exception as e:
        print_error(f"Error setting track coefficients: {e}")


# ============================================================================
# meshcli governance set-config
# ============================================================================

async def governance_set_config(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    min_contribution_floor: int,
    max_delegation_pct: int,
    delegation_factor: int,
    quiet: bool = False,
    verbose: bool = False,
):
    """Set core governance configuration. Root-only."""

    if not quiet:
        console.print(f"\n[bold]Setting Governance Config[/bold]")
        console.print(f"  Min Contribution Floor: {min_contribution_floor}")
        console.print(f"  Max Delegation Pct: {max_delegation_pct}")
        console.print(f"  Delegation Factor: {delegation_factor}")

    if not confirm_action("Set this governance config?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="MeshtensorGovernance",
            call_function="set_governance_config",
            call_params={
                "min_contribution_floor": min_contribution_floor,
                "max_delegation_pct": max_delegation_pct,
                "delegation_factor": delegation_factor,
            },
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success("Governance config updated")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to set config: {await response.error_message}")
    except Exception as e:
        print_error(f"Error setting governance config: {e}")


# ============================================================================
# meshcli governance set-golr-config
# ============================================================================

async def governance_set_golr_config(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    paralysis_days: int,
    threshold_pct: int,
    quiet: bool = False,
    verbose: bool = False,
):
    """Set GoLR (Governance of Last Resort) parameters. Root-only."""

    if not quiet:
        console.print(f"\n[bold]Setting GoLR Config[/bold]")
        console.print(f"  Paralysis Days: {paralysis_days} (min 90)")
        console.print(f"  Threshold Pct: {threshold_pct}%")

    if not confirm_action("Set this GoLR config?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="MeshtensorGovernance",
            call_function="set_golr_config",
            call_params={
                "paralysis_days": paralysis_days,
                "threshold_pct": threshold_pct,
            },
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success("GoLR config updated")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to set GoLR config: {await response.error_message}")
    except Exception as e:
        print_error(f"Error setting GoLR config: {e}")


# ============================================================================
# meshcli governance prune-accounts
# ============================================================================

async def governance_prune_accounts(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    accounts: list[str],
    quiet: bool = False,
    verbose: bool = False,
):
    """Prune governance storage for zero-balance accounts. Root-only."""

    if not quiet:
        console.print(f"\n[bold]Pruning Stale Governance Accounts[/bold]")
        console.print(f"  Accounts to prune: {len(accounts)}")

    if not confirm_action(f"Prune {len(accounts)} accounts?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="MeshtensorGovernance",
            call_function="prune_stale_accounts",
            call_params={"accounts": accounts},
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success(f"Pruned {len(accounts)} stale accounts")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to prune accounts: {await response.error_message}")
    except Exception as e:
        print_error(f"Error pruning accounts: {e}")


# ============================================================================
# meshcli governance status
# ============================================================================

async def governance_status(
    meshtensor: "MeshtensorInterface",
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """Show overall governance status summary."""

    try:
        # Query governance reward pool
        gov_pool = await meshtensor.substrate.query(
            module="MeshtensorGovernance",
            storage_function="GovernanceRewardPool",
        )
        pool_balance = gov_pool.value if gov_pool else 0

        # Query participation rate
        part_rate = await meshtensor.substrate.query(
            module="MeshtensorGovernance",
            storage_function="ParticipationRate",
        )
        rate_val = part_rate.value if part_rate else 0

        # Query active referenda count
        referenda = await meshtensor.substrate.query_map(
            module="Referenda",
            storage_function="ReferendumInfoFor",
        )
        active_count = 0
        async for _, ref_info in referenda:
            ref_data = ref_info.value if hasattr(ref_info, "value") else ref_info
            if isinstance(ref_data, dict) and "Ongoing" in ref_data:
                active_count += 1

        if output_json:
            data = {
                "governance_reward_pool": pool_balance,
                "governance_reward_pool_mesh": pool_balance / 1e9,
                "participation_rate": rate_val,
                "active_referenda": active_count,
            }
            json_console.print_json(json.dumps(data, default=str))
            return

        console.print(f"\n[bold]Governance Status[/bold]")
        console.print(f"  Reward Pool: [green]{pool_balance / 1e9:.4f} MESH[/green]")
        console.print(f"  Participation Rate: {rate_val / 10:.1f}%")
        console.print(f"  Active Referenda: {active_count}")

    except Exception as e:
        print_error(f"Error fetching governance status: {e}")


# ============================================================================
# meshcli governance my-rewards
# ============================================================================

async def governance_my_rewards(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """Show pending governance rewards for the current wallet."""

    account = wallet.coldkeypub.ss58_address

    try:
        pending = await meshtensor.substrate.query(
            module="MeshtensorGovernance",
            storage_function="PendingRewards",
            params=[account],
        )
        pending_val = pending.value if pending else 0

        if output_json:
            data = {
                "account": account,
                "pending_rewards": pending_val,
                "pending_rewards_mesh": pending_val / 1e9,
            }
            json_console.print_json(json.dumps(data, default=str))
            return

        console.print(f"\n[bold]My Governance Rewards[/bold]")
        console.print(f"  Account: {account[:8]}...{account[-8:]}")
        console.print(f"  Pending Rewards: [green]{pending_val / 1e9:.4f} MESH[/green]")

    except Exception as e:
        print_error(f"Error fetching rewards: {e}")


# ============================================================================
# meshcli governance my-delegations
# ============================================================================

async def governance_my_delegations(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """Show active delegations for the current wallet."""

    account = wallet.coldkeypub.ss58_address

    try:
        delegations = []
        for track_id, track_info in GOVERNANCE_TRACKS.items():
            delegation = await meshtensor.substrate.query(
                module="MeshtensorGovernance",
                storage_function="DelegatedTo",
                params=[account, track_id],
            )
            if delegation and delegation.value:
                delegations.append({
                    "track": track_id,
                    "track_name": track_info["name"],
                    "delegatee": str(delegation.value),
                })

        if output_json:
            json_console.print_json(json.dumps(delegations, default=str))
            return

        if not delegations:
            console.print("[dim]No active delegations.[/dim]")
            return

        table = Table(
            Column("Track", style="bold"),
            Column("Delegatee", style="cyan"),
            title="Active Delegations",
            box=box.ROUNDED,
        )

        for d in delegations:
            delegatee = d["delegatee"]
            table.add_row(
                f"{d['track_name']} ({d['track']})",
                f"{delegatee[:8]}...{delegatee[-8:]}" if len(delegatee) > 16 else delegatee,
            )

        console.print(table)

    except Exception as e:
        print_error(f"Error fetching delegations: {e}")
