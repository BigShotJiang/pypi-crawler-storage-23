"""
Technical Committee (TC) commands for meshcli.

Provides commands for interacting with the elected Technical Committee:
- List current TC members
- List TC election candidates
- Vote in TC elections
"""

import asyncio
import json
from typing import TYPE_CHECKING, Optional

from meshtensor_wallet import Wallet
from rich import box
from rich.table import Column, Table

from meshtensor_cli.src.meshtensor.utils import (
    confirm_action,
    console,
    print_error,
    print_success,
    unlock_key,
    json_console,
    print_extrinsic_id,
)

if TYPE_CHECKING:
    from meshtensor_cli.src.meshtensor.meshtensor_interface import MeshtensorInterface


# ============================================================================
# meshcli tc members
# ============================================================================

async def tc_members(
    meshtensor: "MeshtensorInterface",
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """List current Technical Committee members."""

    try:
        members = await meshtensor.substrate.query(
            module="TechnicalMembership",
            storage_function="Members",
        )

        member_list = members.value if members else []

        if output_json:
            json_console.print_json(json.dumps({"members": member_list}, default=str))
            return

        if not member_list:
            console.print("[dim]No Technical Committee members found.[/dim]")
            return

        console.print(f"\n[bold]Technical Committee Members ({len(member_list)})[/bold]")

        table = Table(
            Column("#", style="bold"),
            Column("Account", style="cyan"),
            title=f"TC Members (adaptive size: {len(member_list)} seats)",
            box=box.ROUNDED,
        )

        for i, member in enumerate(member_list, 1):
            account_str = str(member)
            table.add_row(str(i), account_str)

        console.print(table)

        # Show adaptive sizing info
        if len(member_list) <= 5:
            console.print("[dim]Current phase: 5 seats (initial)[/dim]")
        elif len(member_list) <= 7:
            console.print("[dim]Current phase: 7 seats (network growth)[/dim]")
        else:
            console.print("[dim]Current phase: 9 seats (mature network)[/dim]")

    except Exception as e:
        print_error(f"Error fetching TC members: {e}")


# ============================================================================
# meshcli tc candidates
# ============================================================================

async def tc_candidates(
    meshtensor: "MeshtensorInterface",
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """List TC election candidates."""

    try:
        candidates = await meshtensor.substrate.query(
            module="Elections",
            storage_function="Candidates",
        )

        candidate_list = candidates.value if candidates else []

        if output_json:
            json_console.print_json(
                json.dumps({"candidates": candidate_list}, default=str)
            )
            return

        if not candidate_list:
            console.print("[dim]No TC election candidates found.[/dim]")
            return

        table = Table(
            Column("#", style="bold"),
            Column("Candidate", style="cyan"),
            Column("Deposit", style="yellow"),
            title="TC Election Candidates",
            box=box.ROUNDED,
        )

        for i, (candidate, deposit) in enumerate(candidate_list, 1):
            table.add_row(
                str(i),
                str(candidate),
                f"{deposit / 1e9:.4f} MESH" if isinstance(deposit, (int, float)) else str(deposit),
            )

        console.print(table)

    except Exception as e:
        print_error(f"Error fetching TC candidates: {e}")


# ============================================================================
# meshcli tc vote
# ============================================================================

async def tc_vote(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    candidates: list[str],
    stake: float,
    quiet: bool = False,
    verbose: bool = False,
):
    """Vote in a TC election."""

    stake_raw = int(stake * 1e9)

    if not quiet:
        console.print(f"\n[bold]Voting in TC Election[/bold]")
        console.print(f"  Candidates: {len(candidates)}")
        for c in candidates:
            console.print(f"    - {c[:16]}...")
        console.print(f"  Stake: {stake} MESH")

    if not confirm_action("Cast TC election vote?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="Elections",
            call_function="vote",
            call_params={
                "votes": candidates,
                "value": stake_raw,
            },
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success(f"TC election vote cast for {len(candidates)} candidate(s)")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to vote: {await response.error_message}")
    except Exception as e:
        print_error(f"Error voting in TC election: {e}")


# ============================================================================
# meshcli tc emergency-propose
# ============================================================================

async def tc_emergency_propose(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    call_data: str,
    quiet: bool = False,
    verbose: bool = False,
):
    """Submit a TC emergency proposal."""

    if not quiet:
        console.print(f"\n[bold]Submitting TC Emergency Proposal[/bold]")
        console.print(f"  Call data length: {len(call_data)} chars")

    if not confirm_action("Submit this emergency proposal?"):
        return

    if not unlock_key(wallet):
        return

    try:
        # Decode the call data to a runtime call
        inner_call = await meshtensor.substrate.compose_call(
            call_module="System",
            call_function="remark",
            call_params={"remark": call_data},
        )

        call = await meshtensor.substrate.compose_call(
            call_module="TcEmergency",
            call_function="propose",
            call_params={"call": inner_call},
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success("TC emergency proposal submitted")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to submit: {await response.error_message}")
    except Exception as e:
        print_error(f"Error submitting emergency proposal: {e}")


# ============================================================================
# meshcli tc emergency-approve
# ============================================================================

async def tc_emergency_approve(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    proposal_id: int,
    quiet: bool = False,
    verbose: bool = False,
):
    """Approve a TC emergency proposal."""

    if not quiet:
        console.print(f"\n[bold]Approving TC Emergency Proposal #{proposal_id}[/bold]")

    if not confirm_action("Approve this emergency proposal?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="TcEmergency",
            call_function="approve",
            call_params={"proposal_id": proposal_id},
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success(f"Emergency proposal #{proposal_id} approved")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to approve: {await response.error_message}")
    except Exception as e:
        print_error(f"Error approving emergency proposal: {e}")


# ============================================================================
# meshcli tc emergency-execute
# ============================================================================

async def tc_emergency_execute(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    proposal_id: int,
    quiet: bool = False,
    verbose: bool = False,
):
    """Execute a TC emergency proposal after delay."""

    if not quiet:
        console.print(f"\n[bold]Executing TC Emergency Proposal #{proposal_id}[/bold]")

    if not confirm_action("Execute this emergency proposal?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="TcEmergency",
            call_function="execute",
            call_params={"proposal_id": proposal_id},
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success(f"Emergency proposal #{proposal_id} executed")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to execute: {await response.error_message}")
    except Exception as e:
        print_error(f"Error executing emergency proposal: {e}")


# ============================================================================
# meshcli tc emergency-cancel
# ============================================================================

async def tc_emergency_cancel(
    meshtensor: "MeshtensorInterface",
    wallet: Wallet,
    proposal_id: int,
    quiet: bool = False,
    verbose: bool = False,
):
    """Cancel a TC emergency proposal. Root-only."""

    if not quiet:
        console.print(f"\n[bold]Cancelling TC Emergency Proposal #{proposal_id}[/bold]")

    if not confirm_action("Cancel this emergency proposal?"):
        return

    if not unlock_key(wallet):
        return

    try:
        call = await meshtensor.substrate.compose_call(
            call_module="TcEmergency",
            call_function="cancel",
            call_params={"proposal_id": proposal_id},
        )

        extrinsic = await meshtensor.substrate.create_signed_extrinsic(
            call=call, keypair=wallet.coldkey
        )
        response = await meshtensor.substrate.submit_extrinsic(
            extrinsic, wait_for_inclusion=True
        )

        if await response.is_success:
            print_success(f"Emergency proposal #{proposal_id} cancelled")
            await print_extrinsic_id(response)
        else:
            print_error(f"Failed to cancel: {await response.error_message}")
    except Exception as e:
        print_error(f"Error cancelling emergency proposal: {e}")


# ============================================================================
# meshcli tc emergency-list
# ============================================================================

async def tc_emergency_list(
    meshtensor: "MeshtensorInterface",
    quiet: bool = False,
    verbose: bool = False,
    output_json: bool = False,
):
    """List active TC emergency proposals."""

    try:
        proposals = await meshtensor.substrate.query_map(
            module="TcEmergency",
            storage_function="Proposals",
        )

        results = []
        async for proposal_id, proposal_info in proposals:
            pid = proposal_id.value if hasattr(proposal_id, "value") else proposal_id
            data = proposal_info.value if hasattr(proposal_info, "value") else proposal_info
            results.append({
                "id": pid,
                "proposer": data.get("proposer", "Unknown") if isinstance(data, dict) else "Unknown",
                "submitted_at": data.get("submitted_at", 0) if isinstance(data, dict) else 0,
                "threshold_reached": data.get("threshold_reached_at") is not None if isinstance(data, dict) else False,
            })

        if output_json:
            json_console.print_json(json.dumps(results, default=str))
            return

        if not results:
            console.print("[dim]No active TC emergency proposals.[/dim]")
            return

        table = Table(
            Column("ID", style="bold"),
            Column("Proposer", style="cyan"),
            Column("Submitted", style="dim"),
            Column("Threshold", style="green"),
            title="TC Emergency Proposals",
            box=box.ROUNDED,
        )

        for p in sorted(results, key=lambda x: x["id"]):
            table.add_row(
                str(p["id"]),
                str(p["proposer"])[:16] + "...",
                str(p["submitted_at"]),
                "Reached" if p["threshold_reached"] else "Pending",
            )

        console.print(table)

    except Exception as e:
        print_error(f"Error listing emergency proposals: {e}")
