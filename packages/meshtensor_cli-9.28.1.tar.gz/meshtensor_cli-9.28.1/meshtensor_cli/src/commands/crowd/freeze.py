import json
from typing import Optional

from meshtensor_wallet import Wallet

from meshtensor_cli.src.meshtensor.meshtensor_interface import MeshtensorInterface
from meshtensor_cli.src.meshtensor.utils import (
    confirm_action,
    console,
    json_console,
    print_extrinsic_id,
    print_error,
    unlock_key,
)


async def freeze_crowdloan(
    meshtensor: MeshtensorInterface,
    wallet: Wallet,
    proxy: Optional[str],
    crowdloan_id: int,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = False,
    prompt: bool = True,
    decline: bool = False,
    quiet: bool = False,
    json_output: bool = False,
) -> tuple[bool, str]:
    """Freeze a crowdloan via sudo (Root origin).

    Freezing blocks contribute, finalize, and refund but still allows withdraw.

    Args:
        meshtensor: MeshtensorInterface object for chain interaction.
        wallet: Wallet object containing the sudo key.
        proxy: Optional proxy to use for extrinsic submission.
        crowdloan_id: ID of the crowdloan to freeze.
        wait_for_inclusion: Wait for transaction inclusion.
        wait_for_finalization: Wait for transaction finalization.
        prompt: Whether to prompt for confirmation.
        json_output: Whether to output as JSON or human-readable.

    Returns:
        tuple[bool, str]: Success status and message.
    """
    crowdloan = await meshtensor.get_single_crowdloan(crowdloan_id)
    if not crowdloan:
        error_msg = f"Crowdloan #{crowdloan_id} not found."
        if json_output:
            json_console.print(json.dumps({"success": False, "error": error_msg}))
        else:
            print_error(f"[red]{error_msg}[/red]")
        return False, error_msg

    frozen_result = await meshtensor.substrate.query(
        module="Crowdloan",
        storage_function="FrozenCrowdloans",
        params=[crowdloan_id],
    )
    if frozen_result and frozen_result.value:
        error_msg = f"Crowdloan #{crowdloan_id} is already frozen."
        if json_output:
            json_console.print(json.dumps({"success": False, "error": error_msg}))
        else:
            print_error(f"[red]{error_msg}[/red]")
        return False, error_msg

    if prompt and not confirm_action(
        f"\n[bold]Proceed with freezing crowdloan #{crowdloan_id}?[/bold]\n"
        "[yellow]This will block contributions, finalization, and refunds.[/yellow]",
        default=False,
        decline=decline,
        quiet=quiet,
    ):
        if json_output:
            json_console.print(
                json.dumps({"success": False, "error": "Freeze cancelled by user."})
            )
        else:
            console.print("[yellow]Freeze cancelled.[/yellow]")
        return False, "Freeze cancelled by user."

    unlock_status = unlock_key(wallet)
    if not unlock_status.success:
        if json_output:
            json_console.print(
                json.dumps({"success": False, "error": unlock_status.message})
            )
        else:
            print_error(f"[red]{unlock_status.message}[/red]")
        return False, unlock_status.message

    with console.status(
        ":satellite: Submitting freeze transaction (sudo)...", spinner="aesthetic"
    ):
        inner_call = await meshtensor.substrate.compose_call(
            call_module="Crowdloan",
            call_function="freeze_crowdloan",
            call_params={"crowdloan_id": crowdloan_id},
        )
        sudo_call = await meshtensor.substrate.compose_call(
            call_module="Sudo",
            call_function="sudo",
            call_params={"call": inner_call},
        )
        (
            success,
            error_message,
            extrinsic_receipt,
        ) = await meshtensor.sign_and_send_extrinsic(
            call=sudo_call,
            wallet=wallet,
            proxy=proxy,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    if not success:
        if json_output:
            json_console.print(
                json.dumps(
                    {
                        "success": False,
                        "error": error_message or "Failed to freeze crowdloan.",
                    }
                )
            )
        else:
            print_error(f"[red]Failed to freeze crowdloan.[/red]\n{error_message}")
        return False, error_message

    if json_output:
        extrinsic_id = await extrinsic_receipt.get_extrinsic_identifier()
        output_dict = {
            "success": True,
            "error": None,
            "extrinsic_identifier": extrinsic_id,
            "data": {"crowdloan_id": crowdloan_id},
        }
        json_console.print(json.dumps(output_dict))
    else:
        await print_extrinsic_id(extrinsic_receipt)
        console.print(f"[green]Crowdloan #{crowdloan_id} has been frozen.[/green]")

    return True, f"Crowdloan #{crowdloan_id} frozen successfully."


async def unfreeze_crowdloan(
    meshtensor: MeshtensorInterface,
    wallet: Wallet,
    proxy: Optional[str],
    crowdloan_id: int,
    wait_for_inclusion: bool = True,
    wait_for_finalization: bool = False,
    prompt: bool = True,
    decline: bool = False,
    quiet: bool = False,
    json_output: bool = False,
) -> tuple[bool, str]:
    """Unfreeze a previously frozen crowdloan via sudo (Root origin).

    Args:
        meshtensor: MeshtensorInterface object for chain interaction.
        wallet: Wallet object containing the sudo key.
        proxy: Optional proxy to use for extrinsic submission.
        crowdloan_id: ID of the crowdloan to unfreeze.
        wait_for_inclusion: Wait for transaction inclusion.
        wait_for_finalization: Wait for transaction finalization.
        prompt: Whether to prompt for confirmation.
        json_output: Whether to output as JSON or human-readable.

    Returns:
        tuple[bool, str]: Success status and message.
    """
    crowdloan = await meshtensor.get_single_crowdloan(crowdloan_id)
    if not crowdloan:
        error_msg = f"Crowdloan #{crowdloan_id} not found."
        if json_output:
            json_console.print(json.dumps({"success": False, "error": error_msg}))
        else:
            print_error(f"[red]{error_msg}[/red]")
        return False, error_msg

    frozen_result = await meshtensor.substrate.query(
        module="Crowdloan",
        storage_function="FrozenCrowdloans",
        params=[crowdloan_id],
    )
    if not (frozen_result and frozen_result.value):
        error_msg = f"Crowdloan #{crowdloan_id} is not frozen."
        if json_output:
            json_console.print(json.dumps({"success": False, "error": error_msg}))
        else:
            print_error(f"[red]{error_msg}[/red]")
        return False, error_msg

    if prompt and not confirm_action(
        f"\n[bold]Proceed with unfreezing crowdloan #{crowdloan_id}?[/bold]",
        default=False,
        decline=decline,
        quiet=quiet,
    ):
        if json_output:
            json_console.print(
                json.dumps({"success": False, "error": "Unfreeze cancelled by user."})
            )
        else:
            console.print("[yellow]Unfreeze cancelled.[/yellow]")
        return False, "Unfreeze cancelled by user."

    unlock_status = unlock_key(wallet)
    if not unlock_status.success:
        if json_output:
            json_console.print(
                json.dumps({"success": False, "error": unlock_status.message})
            )
        else:
            print_error(f"[red]{unlock_status.message}[/red]")
        return False, unlock_status.message

    with console.status(
        ":satellite: Submitting unfreeze transaction (sudo)...", spinner="aesthetic"
    ):
        inner_call = await meshtensor.substrate.compose_call(
            call_module="Crowdloan",
            call_function="unfreeze_crowdloan",
            call_params={"crowdloan_id": crowdloan_id},
        )
        sudo_call = await meshtensor.substrate.compose_call(
            call_module="Sudo",
            call_function="sudo",
            call_params={"call": inner_call},
        )
        (
            success,
            error_message,
            extrinsic_receipt,
        ) = await meshtensor.sign_and_send_extrinsic(
            call=sudo_call,
            wallet=wallet,
            proxy=proxy,
            wait_for_inclusion=wait_for_inclusion,
            wait_for_finalization=wait_for_finalization,
        )

    if not success:
        if json_output:
            json_console.print(
                json.dumps(
                    {
                        "success": False,
                        "error": error_message or "Failed to unfreeze crowdloan.",
                    }
                )
            )
        else:
            print_error(f"[red]Failed to unfreeze crowdloan.[/red]\n{error_message}")
        return False, error_message

    if json_output:
        extrinsic_id = await extrinsic_receipt.get_extrinsic_identifier()
        output_dict = {
            "success": True,
            "error": None,
            "extrinsic_identifier": extrinsic_id,
            "data": {"crowdloan_id": crowdloan_id},
        }
        json_console.print(json.dumps(output_dict))
    else:
        await print_extrinsic_id(extrinsic_receipt)
        console.print(f"[green]Crowdloan #{crowdloan_id} has been unfrozen.[/green]")

    return True, f"Crowdloan #{crowdloan_id} unfrozen successfully."
