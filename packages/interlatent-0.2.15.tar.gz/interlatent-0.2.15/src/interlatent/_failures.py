"""Failure taxonomy framework for RL episode classification (pure Python)."""
from __future__ import annotations

import ast
import asyncio
import json
import logging
import operator
from dataclasses import dataclass, field
from typing import Any, Callable, Sequence

__all__ = [
    "DEFAULT_SUCCESS_LABEL",
    "FailureRule",
    "FailureTaxonomy",
    "auto_failures",
    "detect_failure_in_context",
    "is_failure_outcome",
    "SafeExpressionError",
]

DEFAULT_SUCCESS_LABEL = "success"


class SafeExpressionError(Exception):
    """Raised when a failure rule expression is invalid or unsafe."""


# ---------------------------------------------------------------------------
# Safe expression evaluator using Python's ast module
# ---------------------------------------------------------------------------

_COMPARE_OPS = {
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
}

_BOOL_OPS = {
    ast.And: all,
    ast.Or: any,
}

_UNARY_OPS = {
    ast.USub: operator.neg,
    ast.Not: operator.not_,
}


def _compile_expression(expr: str) -> Callable[[dict], bool]:
    """Parse and compile a safe boolean expression."""
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as e:
        raise SafeExpressionError(f"Invalid expression syntax: {expr!r}") from e

    _validate_node(tree.body)
    return lambda ns: _eval_node(tree.body, ns)


def _validate_node(node: ast.AST) -> None:
    """Walk the AST and reject anything unsafe."""
    if isinstance(node, ast.Expression):
        _validate_node(node.body)
    elif isinstance(node, ast.BoolOp):
        for v in node.values:
            _validate_node(v)
    elif isinstance(node, ast.UnaryOp):
        if type(node.op) not in _UNARY_OPS:
            raise SafeExpressionError(f"Unsupported unary operator: {type(node.op).__name__}")
        _validate_node(node.operand)
    elif isinstance(node, ast.Compare):
        _validate_node(node.left)
        for op, comparator in zip(node.ops, node.comparators):
            if type(op) not in _COMPARE_OPS:
                raise SafeExpressionError(f"Unsupported comparison: {type(op).__name__}")
            _validate_node(comparator)
    elif isinstance(node, ast.BinOp):
        allowed = (ast.Add, ast.Sub, ast.Mult, ast.Div)
        if type(node.op) not in allowed:
            raise SafeExpressionError(f"Unsupported binary operator: {type(node.op).__name__}")
        _validate_node(node.left)
        _validate_node(node.right)
    elif isinstance(node, ast.Name):
        pass
    elif isinstance(node, ast.Constant):
        if not isinstance(node.value, (int, float, bool, type(None))):
            raise SafeExpressionError(f"Unsupported literal type: {type(node.value).__name__}")
    else:
        raise SafeExpressionError(
            f"Unsupported expression node: {type(node).__name__}. "
            "Only comparisons, and/or/not, variables, and numeric literals are allowed."
        )


_BIN_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
}


def _eval_node(node: ast.AST, ns: dict) -> Any:
    """Evaluate a validated AST node against a namespace."""
    if isinstance(node, ast.BoolOp):
        fn = _BOOL_OPS[type(node.op)]
        return fn(_eval_node(v, ns) for v in node.values)

    if isinstance(node, ast.UnaryOp):
        operand = _eval_node(node.operand, ns)
        return _UNARY_OPS[type(node.op)](operand)

    if isinstance(node, ast.Compare):
        left = _eval_node(node.left, ns)
        for op, comparator in zip(node.ops, node.comparators):
            right = _eval_node(comparator, ns)
            if not _COMPARE_OPS[type(op)](left, right):
                return False
            left = right
        return True

    if isinstance(node, ast.BinOp):
        left = _eval_node(node.left, ns)
        right = _eval_node(node.right, ns)
        return _BIN_OPS[type(node.op)](left, right)

    if isinstance(node, ast.Name):
        if node.id not in ns:
            return 0.0
        return ns[node.id]

    if isinstance(node, ast.Constant):
        return node.value

    raise SafeExpressionError(f"Cannot evaluate node: {type(node).__name__}")


# ---------------------------------------------------------------------------
# LLM description → expression translation
# ---------------------------------------------------------------------------

_log = logging.getLogger(__name__)

_TRANSLATION_PROMPT = """\
You are an expert at writing boolean expressions for RL failure detection.

Environment: {env_name}
Available variables (you MUST only use these, no others): {available_vars}

RL semantics:
- "done" = episode ended naturally (e.g. crash, goal reached, terminal state)
- "truncated" = episode ended by time limit / max steps (the agent didn't crash, it just ran out of time)
- "episode_reward" = cumulative reward over the entire episode so far
- "reward" = reward for the current single step
- Use >= / <= instead of > / < when the boundary value itself should count

Grammar (only these constructs are allowed):
- Comparisons: <, >, <=, >=, ==, !=
- Logic: and, or, not
- Arithmetic: +, -, *, /
- ONLY variables from the list above — do NOT invent new variable names
- Numeric literals and True/False
- NO function calls (abs, min, max, len, etc. are NOT allowed)
- NO string literals, subscripts, or attribute access

Translate each failure description into a valid boolean expression.
Pick reasonable thresholds for the environment.
Return a JSON object mapping each failure name to its expression string.
Example: {{"crashed": "reward < -50 and done", "drifted": "x_velocity > 2.0"}}

Failure descriptions:
{descriptions_json}

Return ONLY the JSON object, no explanation."""


async def _descriptions_to_expressions_async(
    descriptions: dict[str, str],
    env_name: str,
    available_vars: list[str],
    model: str = "gpt-4o-mini",
) -> dict[str, str]:
    """Translate natural-language failure descriptions to safe expressions via LLM."""
    from openai import AsyncOpenAI

    prompt = _TRANSLATION_PROMPT.format(
        env_name=env_name,
        available_vars=", ".join(available_vars),
        descriptions_json=json.dumps(descriptions, indent=2),
    )

    client = AsyncOpenAI()
    messages = [{"role": "user", "content": prompt}]

    for attempt in range(2):
        resp = await client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=0,
        )

        raw = resp.choices[0].message.content.strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[1].rsplit("```", 1)[0].strip()

        try:
            result = json.loads(raw)
        except json.JSONDecodeError as e:
            raise SafeExpressionError(f"LLM returned invalid JSON: {raw!r}") from e

        if not isinstance(result, dict):
            raise SafeExpressionError(
                f"LLM returned non-dict: {type(result).__name__}"
            )

        # Validate every expression compiles
        errors: list[str] = []
        for name, expr in result.items():
            try:
                _compile_expression(expr)
            except SafeExpressionError as e:
                errors.append(f"{name}: {expr!r} — {e}")

        if not errors:
            _log.info("LLM translated %d descriptions → expressions", len(result))
            return result

        # Retry: send errors back to the LLM for correction
        if attempt == 0:
            _log.warning("LLM produced invalid expressions, retrying: %s", errors)
            messages.append({"role": "assistant", "content": raw})
            messages.append({
                "role": "user",
                "content": (
                    "Some expressions failed validation. Remember: NO function calls "
                    "(abs, min, max, etc.), NO string literals, NO subscripts.\n"
                    "Errors:\n" + "\n".join(errors)
                    + "\n\nPlease fix and return the complete JSON again."
                ),
            })

    raise SafeExpressionError(
        f"LLM failed to produce valid expressions after retry: {errors}"
    )


def _descriptions_to_expressions(
    descriptions: dict[str, str],
    env_name: str,
    available_vars: list[str],
    model: str = "gpt-4o-mini",
) -> dict[str, str]:
    """Sync wrapper around :func:`_descriptions_to_expressions_async`."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is not None and loop.is_running():
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(
                asyncio.run,
                _descriptions_to_expressions_async(
                    descriptions, env_name, available_vars, model
                ),
            ).result()
    return asyncio.run(
        _descriptions_to_expressions_async(
            descriptions, env_name, available_vars, model
        )
    )


# ---------------------------------------------------------------------------
# FailureRule / FailureTaxonomy
# ---------------------------------------------------------------------------


@dataclass
class FailureRule:
    """A single failure detection rule."""

    name: str
    expression: str
    _compiled: Callable[[dict], bool] = field(repr=False, default=None)  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self._compiled is None:
            self._compiled = _compile_expression(self.expression)

    def evaluate(self, namespace: dict) -> bool:
        try:
            return bool(self._compiled(namespace))
        except Exception:
            return False


_BUILTIN_SUCCESS_OUTCOMES = frozenset({
    "success", "landed", "soft_landing", "completed", "solved",
    "running", "incomplete",
})


def is_failure_outcome(
    name: str | None,
    taxonomy: "FailureTaxonomy | None" = None,
) -> bool:
    if not name:
        return False
    if taxonomy is not None:
        return taxonomy.is_failure_outcome(name)
    return name not in _BUILTIN_SUCCESS_OUTCOMES


def detect_failure_in_context(
    ctx: dict | None,
    *,
    failure_keys: Sequence[str],
    metrics_key: str = "metrics",
    return_value: bool = False,
) -> Any:
    ctx = ctx or {}

    failures = ctx.get("failures")
    if failures and isinstance(failures, dict):
        for key in failure_keys:
            if key in failures:
                return key
        first = next(iter(failures), None)
        if first is not None:
            return first

    ft = ctx.get("failure_type")
    if ft and isinstance(ft, str):
        if not failure_keys or ft in failure_keys:
            return ft

    metrics = ctx.get(metrics_key, {}) or {}
    for key in failure_keys:
        if key in metrics and metrics[key] not in (None, False, 0, 0.0, "", "0"):
            return metrics[key] if return_value else key
        if key in ctx and ctx[key] not in (None, False, 0, 0.0, "", "0"):
            return ctx[key] if return_value else key
    return None


class FailureTaxonomy:
    """Container for user-defined failure and success rules."""

    def __init__(
        self,
        rules: dict[str, str],
        successes: dict[str, str] | None = None,
    ) -> None:
        self.rules: list[FailureRule] = []
        for name, expr in rules.items():
            self.rules.append(FailureRule(name=name, expression=expr))

        user_success_names: set[str] = set()
        if successes:
            for name, expr in successes.items():
                self.rules.append(FailureRule(name=name, expression=expr))
                user_success_names.add(name)

        self.success_outcomes: frozenset[str] = (
            _BUILTIN_SUCCESS_OUTCOMES | frozenset(user_success_names)
        )

    @property
    def failure_names(self) -> list[str]:
        return [r.name for r in self.rules if r.name not in self.success_outcomes]

    @property
    def success_names(self) -> list[str]:
        return [r.name for r in self.rules if r.name in self.success_outcomes]

    def is_failure_outcome(self, name: str) -> bool:
        return name not in self.success_outcomes

    def evaluate_step(
        self,
        *,
        obs: Any = None,
        reward: float = 0.0,
        metrics: dict[str, float] | None = None,
        done: bool = False,
        truncated: bool = False,
        episode_reward: float = 0.0,
        extra: dict[str, Any] | None = None,
    ) -> str | None:
        ns = self._build_namespace(
            obs=obs, reward=reward, metrics=metrics,
            done=done, truncated=truncated,
            episode_reward=episode_reward, extra=extra,
        )
        for rule in self.rules:
            if rule.evaluate(ns):
                return rule.name
        return None

    def evaluate_step_all(
        self,
        *,
        obs: Any = None,
        reward: float = 0.0,
        metrics: dict[str, float] | None = None,
        done: bool = False,
        truncated: bool = False,
        episode_reward: float = 0.0,
        extra: dict[str, Any] | None = None,
    ) -> dict[str, dict]:
        ns = self._build_namespace(
            obs=obs, reward=reward, metrics=metrics,
            done=done, truncated=truncated,
            episode_reward=episode_reward, extra=extra,
        )
        matches: dict[str, dict] = {}
        for rule in self.rules:
            if rule.evaluate(ns):
                evidence = self._extract_evidence(rule, ns)
                matches[rule.name] = {"evidence": evidence}
        return matches

    def classify_episode(self, episode_steps: list[dict]) -> dict:
        episode_reward = 0.0
        first_failure: str | None = None
        trigger_step: int | None = None
        evidence: dict = {}
        all_failures: dict[str, dict] = {}

        for i, step_data in enumerate(episode_steps):
            reward = float(step_data.get("reward", 0.0))
            episode_reward += reward

            matches = self.evaluate_step_all(
                obs=step_data.get("obs"),
                reward=reward,
                metrics=step_data.get("metrics"),
                done=step_data.get("done", False),
                truncated=step_data.get("truncated", False),
                episode_reward=episode_reward,
                extra=step_data.get("extra"),
            )
            if matches:
                for name, detail in matches.items():
                    if name not in all_failures:
                        all_failures[name] = {"trigger_step": i, **detail}
                if first_failure is None:
                    first_failure = next(iter(matches))
                    trigger_step = i
                    evidence = matches[first_failure].get("evidence", {})

        return {
            "failure_type": first_failure,
            "trigger_step": trigger_step,
            "evidence": evidence,
            "all_failures": all_failures,
        }

    def _build_namespace(
        self,
        *,
        obs: Any,
        reward: float,
        metrics: dict[str, float] | None,
        done: bool,
        truncated: bool,
        episode_reward: float,
        extra: dict[str, Any] | None,
    ) -> dict[str, Any]:
        ns: dict[str, Any] = {
            "reward": reward,
            "done": done,
            "truncated": truncated,
            "episode_reward": episode_reward,
        }
        if metrics:
            ns.update(metrics)
        if isinstance(obs, dict):
            ns.update(obs)
        elif obs is not None:
            try:
                import numpy as np
                arr = np.asarray(obs).flatten()
                for i in range(min(len(arr), 32)):
                    ns[f"obs_{i}"] = float(arr[i])
            except Exception:
                pass
        if extra:
            ns.update(extra)
        return ns

    def _extract_evidence(self, rule: FailureRule, ns: dict) -> dict[str, Any]:
        try:
            tree = ast.parse(rule.expression, mode="eval")
            names = {node.id for node in ast.walk(tree) if isinstance(node, ast.Name)}
            return {name: ns.get(name) for name in sorted(names) if name in ns}
        except Exception:
            return {}

    def to_dict(self) -> dict[str, Any]:
        return {
            "rules": {r.name: r.expression for r in self.rules},
            "success_outcomes": sorted(
                name for name in self.success_outcomes
                if name not in _BUILTIN_SUCCESS_OUTCOMES
                or any(r.name == name for r in self.rules)
            ),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "FailureTaxonomy":
        if "rules" in data and isinstance(data["rules"], dict):
            all_rules = data["rules"]
            success_names = set(data.get("success_outcomes", []))
            failures = {n: e for n, e in all_rules.items() if n not in success_names}
            successes = {n: e for n, e in all_rules.items() if n in success_names}
            return cls(failures, successes=successes or None)
        return cls(data)

    @classmethod
    def from_descriptions(
        cls,
        descriptions: dict[str, str],
        env_name: str = "Unknown",
        available_vars: list[str] | None = None,
        model: str = "gpt-4o-mini",
    ) -> "FailureTaxonomy":
        """Create a taxonomy from natural-language failure descriptions.

        Uses an LLM to translate descriptions like ``"The lander crashed hard"``
        into safe boolean expressions, then constructs a normal taxonomy.

        Args:
            descriptions: ``{failure_name: natural_language_description}``.
            env_name: Environment name for context (e.g. ``"LunarLander-v3"``).
            available_vars: Variable names expressions may reference.
                Defaults to common RL vars if not provided.
            model: OpenAI model to use for translation.
        """
        if available_vars is None:
            available_vars = [
                "reward", "done", "truncated", "episode_reward",
                "obs_0", "obs_1", "obs_2", "obs_3",
            ]
        expressions = _descriptions_to_expressions(
            descriptions, env_name, available_vars, model
        )
        return cls(expressions)

    def __repr__(self) -> str:
        failure_str = ", ".join(
            f"{r.name!r}: {r.expression!r}" for r in self.rules
            if r.name not in self.success_outcomes
        )
        success_str = ", ".join(
            f"{r.name!r}: {r.expression!r}" for r in self.rules
            if r.name in self.success_outcomes
        )
        parts = [f"{{{failure_str}}}"]
        if success_str:
            parts.append(f"successes={{{success_str}}}")
        return f"FailureTaxonomy({', '.join(parts)})"


# ---------------------------------------------------------------------------
# Factory: auto_failures
# ---------------------------------------------------------------------------


def auto_failures(env) -> FailureTaxonomy:
    """Return a default FailureTaxonomy based on the environment."""
    from ._metrics import extract_env_id

    env_id = extract_env_id(env)

    if "LunarLander" in env_id:
        return FailureTaxonomy(
            {"crashed": "reward < -50 and done"},
            successes={"success": "reward > 100 and done"},
        )

    if "Ant" in env_id:
        return FailureTaxonomy({
            "fallen": "obs_0 < 0.2",
            "backward": "x_velocity < -0.1",
        })

    if "CartPole" in env_id:
        return FailureTaxonomy({
            "failed": "done and not truncated",
        })

    if "MountainCar" in env_id:
        return FailureTaxonomy(
            {"stuck": "truncated and episode_reward < -199"},
            successes={"reached_goal": "obs_0 > 0.5 and done"},
        )

    return FailureTaxonomy({
        "low_reward": "episode_reward < -1.0 and done",
    })
