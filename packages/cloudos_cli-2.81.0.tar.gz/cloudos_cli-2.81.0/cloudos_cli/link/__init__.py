"""
Functions and classes related to datasets.
"""

from .link import Link


__all__ = ['link']
