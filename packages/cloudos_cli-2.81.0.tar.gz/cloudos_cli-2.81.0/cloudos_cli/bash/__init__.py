"""Bash job-related CLI commands."""
