"""Backward-compatible app shim. Implementation moved to modules/enforce/."""

from specfact_cli.modules.enforce.src.commands import app


__all__ = ["app"]
