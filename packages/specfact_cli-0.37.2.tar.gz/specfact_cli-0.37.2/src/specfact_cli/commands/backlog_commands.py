"""Backward-compatible app shim. Implementation moved to modules/backlog/."""

from specfact_cli.modules.backlog.src.commands import app


__all__ = ["app"]
