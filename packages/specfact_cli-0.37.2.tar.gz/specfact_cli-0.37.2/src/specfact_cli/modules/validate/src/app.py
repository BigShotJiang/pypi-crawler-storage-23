"""validate command entrypoint."""

from specfact_cli.modules.validate.src.commands import app


__all__ = ["app"]
