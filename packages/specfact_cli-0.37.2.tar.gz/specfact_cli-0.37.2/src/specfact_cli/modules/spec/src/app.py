"""spec command entrypoint."""

from specfact_cli.modules.spec.src.commands import app


__all__ = ["app"]
