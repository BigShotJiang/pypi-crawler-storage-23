"""Report generation system for pipen"""

from . import _patch_copier  # noqa: F401
from .versions import __version__
