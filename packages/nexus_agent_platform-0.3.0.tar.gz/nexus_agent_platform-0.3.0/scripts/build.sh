#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

echo "=== Building frontend ==="
cd "$PROJECT_ROOT/frontend"
pnpm install
pnpm build    # next build → output: export → out/
cd "$PROJECT_ROOT"

echo "=== Copying static files ==="
rm -rf nexus_agent/static
cp -r frontend/out nexus_agent/static

echo "=== Building Python wheel ==="
uv build

echo "=== Done ==="
ls -la dist/
