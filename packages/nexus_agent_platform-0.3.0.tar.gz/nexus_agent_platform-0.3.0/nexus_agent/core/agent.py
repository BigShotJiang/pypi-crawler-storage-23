import json
from typing import List, Dict, Any

from nexus_agent.core.llm import llm_client
from nexus_agent.core.mcp_manager import mcp_manager, parse_namespaced_tool
from nexus_agent.core.memory_manager import memory_manager
from nexus_agent.core.skill_manager import skill_manager, SKILL_TOOL_NAMES

SKILL_SYSTEM_PROMPT = """당신은 Nexus Agent 플랫폼의 AI 어시스턴트입니다.
아래 등록된 스킬을 활용하여 사용자를 도울 수 있습니다.

## 스킬 사용 방법
1. 사용자의 요청을 분석하여 관련 스킬이 있는지 확인합니다
2. 관련 스킬이 있으면 read_skill 도구로 전체 지시사항을 읽고 따릅니다
3. 스킬의 scripts/ 디렉토리에 실행 스크립트가 있으면 run_skill_script로 활용합니다
4. references/ 디렉토리의 참조 문서가 필요하면 read_skill_reference로 로드합니다

{available_skills_xml}"""


class AgentOrchestrator:
    def __init__(self):
        self.llm = llm_client

    def _build_system_prompt(self) -> str | None:
        parts = []

        # 사용자 커스텀 시스템 프롬프트
        custom = self.llm.get_system_prompt()
        if custom:
            parts.append(custom)

        # 장기 기억 주입
        memory_prompt = memory_manager.build_memory_prompt()
        if memory_prompt:
            parts.append(memory_prompt)

        # 스킬 시스템 프롬프트
        skills_xml = skill_manager.generate_skills_xml()
        if skills_xml:
            parts.append(SKILL_SYSTEM_PROMPT.format(available_skills_xml=skills_xml))

        return "\n\n".join(parts) if parts else None

    async def run(self, messages: List[Dict[str, Any]]) -> Dict[str, Any]:
        # Shallow copy to avoid mutating the caller's list
        messages = list(messages)

        # Inject system prompt with skill metadata
        system_prompt = self._build_system_prompt()
        if system_prompt:
            messages = [{"role": "system", "content": system_prompt}] + messages

        # Merge MCP tools + skill tools
        active_tools = await mcp_manager.get_all_tools()
        skill_tools = skill_manager.get_skill_tools()
        all_tools = active_tools + skill_tools

        # Step 1: LLM Call with Tools
        response = await self.llm.chat_completion(
            messages, tools=all_tools if all_tools else None
        )

        message = response["choices"][0]["message"]

        # Step 2: Handle Tool Calls
        if message.get("tool_calls"):
            tool_calls = message["tool_calls"]
            messages.append(message)

            for tool_call in tool_calls:
                function_name = tool_call["function"]["name"]
                arguments_str = tool_call["function"]["arguments"]
                tool_call_id = tool_call["id"]

                args = json.loads(arguments_str) if isinstance(arguments_str, str) else arguments_str

                # Route: skill tools vs MCP tools
                if function_name in SKILL_TOOL_NAMES:
                    result = await skill_manager.handle_tool_call(function_name, args)
                else:
                    try:
                        server_name, tool_name = parse_namespaced_tool(function_name)
                        result = await mcp_manager.call_tool(server_name, tool_name, args)
                    except ValueError:
                        result = f"Error: Invalid tool name format '{function_name}'"

                messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call_id,
                    "name": function_name,
                    "content": str(result),
                })

            # Step 3: Final LLM Call after tool results
            final_response = await self.llm.chat_completion(messages)
            return final_response

        return response


orchestrator = AgentOrchestrator()
