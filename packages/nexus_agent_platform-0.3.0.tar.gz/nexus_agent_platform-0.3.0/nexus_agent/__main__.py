from nexus_agent.cli import main

main()
