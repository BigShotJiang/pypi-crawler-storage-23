from typing import List, Optional, Union
from pydantic import BaseModel


class SessionMessage(BaseModel):
    role: str  # "user" | "assistant" | "tool"
    content: Union[str, list]  # str or multimodal array
    name: Optional[str] = None
    tool_call_id: Optional[str] = None
    timestamp: Optional[str] = None


class SessionInfo(BaseModel):
    id: str
    title: str
    created_at: str  # ISO 8601
    updated_at: str  # ISO 8601
    message_count: int = 0
    preview: str = ""


class CreateSessionRequest(BaseModel):
    title: str = ""


class UpdateSessionRequest(BaseModel):
    title: str


class SaveMessagesRequest(BaseModel):
    messages: List[SessionMessage]


class SessionDetail(BaseModel):
    """세션 상세 (메타 + 메시지)"""
    info: SessionInfo
    messages: List[SessionMessage]
