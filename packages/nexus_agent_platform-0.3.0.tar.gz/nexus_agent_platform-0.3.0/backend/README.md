# Nexus Agent Backend

FastAPI 기반 백엔드. MCP 서버 관리, Agent Skills 관리, Custom Pages 폴더 트리, LLM 설정 및 도구 호출 오케스트레이션을 담당합니다.

## 실행

```bash
cp .env.example .env  # GOOGLE_API_KEY, LITELLM_MODEL 설정
uv sync
uv run uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## 환경 변수

`backend/.env` 파일에 설정 (`backend/.env.example` 참고):

| 변수 | 필수 | 기본값 | 설명 |
|------|------|--------|------|
| `GOOGLE_API_KEY` | O | — | Gemini API 키 |
| `LITELLM_MODEL` | O | `gemini/gemini-3-flash-preview` | LLM 모델 이름 |
| `LITELLM_BASE_URL` | X | — | 커스텀 LLM 엔드포인트 |

## 구조

```
app/
├── main.py                      # FastAPI 앱, lifespan, CORS, 라우터 등록
├── core/
│   ├── llm.py                   # LLMClient (LiteLLM 래퍼, 동적 설정 로드)
│   ├── agent.py                 # AgentOrchestrator (시스템 프롬프트 + 도구 라우팅)
│   ├── mcp_manager.py           # MCPClientManager (MCP 서버 연결 관리)
│   ├── skill_manager.py         # SkillManager (스킬 탐색/로드/실행)
│   ├── page_manager.py          # PageManager (페이지/폴더/북마크 트리 관리)
│   └── settings_manager.py      # SettingsManager (LLM 설정 관리)
├── api/endpoints/
│   ├── chat.py                  # POST /api/chat/
│   ├── mcp.py                   # MCP 서버/도구 CRUD API
│   ├── skills.py                # Agent Skills CRUD API
│   ├── pages.py                 # Pages/폴더/북마크 CRUD API
│   └── settings.py              # LLM 설정 및 헬스체크 API
└── models/
    ├── mcp.py                   # MCPServerConfig, MCPServerInfo, MCPToolInfo
    ├── skill.py                 # SkillInfo, SkillDetail, CreateSkillRequest
    ├── page.py                  # PageInfo, CreateFolderRequest, CreateBookmarkRequest
    └── settings.py              # LLMSettings, AppSettings, UpdateLLMRequest
```

### 설정 파일

| 파일 | 설명 |
|------|------|
| `.env` | 환경 변수 (API 키, 모델 이름) |
| `mcp.json` | MCP 서버 연결 설정 (자동 생성) |
| `skills.json` | 스킬 비활성화 상태 관리 (자동 생성) |
| `pages.json` | 페이지 메타데이터 및 트리 구조 (자동 생성) |
| `settings.json` | LLM 설정 — 모델, 온도, 시스템 프롬프트 등 (자동 생성) |

### 데이터 디렉토리

| 디렉토리 | 설명 |
|----------|------|
| `skills/` | Agent Skills 저장 (SKILL.md + scripts/ + references/) |
| `pages/` | 업로드된 HTML 파일 저장 |

## API 엔드포인트

### Chat

| 메서드 | 경로 | 설명 |
|--------|------|------|
| POST | `/api/chat/` | 메시지 전송 및 AI 응답 |

### MCP 서버 관리

| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | `/api/mcp/servers` | 전체 서버 목록 + 상태 |
| GET | `/api/mcp/servers/{name}` | 특정 서버 상세 |
| POST | `/api/mcp/servers` | 서버 추가 + 연결 |
| PATCH | `/api/mcp/servers/{name}` | 서버 설정 수정 |
| DELETE | `/api/mcp/servers/{name}` | 서버 삭제 |
| POST | `/api/mcp/servers/{name}/connect` | 수동 연결 |
| POST | `/api/mcp/servers/{name}/disconnect` | 수동 연결 해제 |
| POST | `/api/mcp/servers/{name}/restart` | 재시작 |

### MCP 도구

| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | `/api/mcp/tools` | 전체 도구 목록 |
| GET | `/api/mcp/tools/{server_name}` | 특정 서버 도구 목록 |

### MCP 설정

| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | `/api/mcp/config` | mcp.json 조회 |
| PUT | `/api/mcp/config` | mcp.json 전체 덮어쓰기 |
| POST | `/api/mcp/reload` | 설정 재로드 |

### Agent Skills 관리

| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | `/api/skills/` | 전체 스킬 목록 |
| GET | `/api/skills/{name}` | 스킬 상세 (SKILL.md 전체 내용 포함) |
| POST | `/api/skills/` | 스킬 생성 |
| PATCH | `/api/skills/{name}` | 스킬 업데이트 (enabled, description, instructions) |
| DELETE | `/api/skills/{name}` | 스킬 삭제 |
| POST | `/api/skills/{name}/execute` | 스킬 스크립트 실행 |
| POST | `/api/skills/reload` | 스킬 디렉토리 재스캔 |
| POST | `/api/skills/upload` | ZIP 파일로 스킬 업로드 |
| POST | `/api/skills/import` | 로컬 경로에서 스킬 임포트 |

### Custom Pages 관리

| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | `/api/pages/` | 페이지 목록 (parent_id 쿼리로 하위 필터) |
| GET | `/api/pages/{page_id}` | 페이지 상세 정보 |
| GET | `/api/pages/{page_id}/content` | HTML 콘텐츠 또는 URL 리다이렉트 |
| POST | `/api/pages/upload` | HTML 파일 업로드 |
| POST | `/api/pages/import` | 로컬 경로에서 HTML 임포트 |
| POST | `/api/pages/bookmark` | URL 북마크 생성 |
| POST | `/api/pages/folders` | 폴더 생성 |
| POST | `/api/pages/check-frameable/{page_id}` | URL iframe 지원 여부 확인 |
| GET | `/api/pages/breadcrumb/{page_id}` | 브레드크럼 네비게이션 경로 |
| PATCH | `/api/pages/{page_id}` | 페이지 메타데이터 수정 |
| DELETE | `/api/pages/{page_id}` | 페이지 삭제 (폴더는 재귀 삭제) |

### Settings

| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | `/api/settings/health` | 서버 헬스체크 |
| GET | `/api/settings/llm` | LLM 설정 조회 (API 키 마스킹) |
| PATCH | `/api/settings/llm` | LLM 설정 업데이트 |

## 도구 라우팅

AgentOrchestrator는 LLM의 tool_call을 두 경로로 분기합니다:

| tool_call name | 라우팅 | 처리 |
|----------------|--------|------|
| `read_skill` | SkillManager | 스킬 SKILL.md 전체 내용 로드 |
| `run_skill_script` | SkillManager | 스킬 스크립트 실행 (60초 타임아웃) |
| `read_skill_reference` | SkillManager | 참조 문서 로드 |
| `{server}__{tool}` | MCPClientManager | MCP 서버로 도구 호출 전달 |

## MCP 서버 설정 (mcp.json)

Claude Desktop 호환 스키마를 사용합니다.

```json
{
  "mcpServers": {
    "server-name": {
      "transport": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-everything"],
      "env": { "DEBUG": "true" },
      "enabled": true
    }
  }
}
```

지원 transport: `stdio`, `sse`, `streamable-http`

## Agent Skills 저장 경로

스킬은 `backend/skills/` 디렉토리에 저장됩니다:

```
backend/skills/
├── my-skill/
│   ├── SKILL.md              # 필수: YAML frontmatter + Markdown 지시사항
│   ├── scripts/              # 선택: 실행 스크립트 (.py, .sh, .js)
│   └── references/           # 선택: 참조 문서 (.md, .txt, .json, .yaml)
└── another-skill/
    └── SKILL.md
```

- 서버 시작 시 `skills/` 하위 폴더를 자동 스캔
- `POST /api/skills/reload`로 수동 재스캔
- UI(`/skills`)에서 등록/관리, ZIP 업로드 및 경로 임포트 지원

## Pages 트리 구조

페이지는 폴더 기반 트리로 관리됩니다. `pages.json`에 메타데이터, `pages/` 디렉토리에 HTML 파일이 저장됩니다.

- `content_type`: `html` (업로드된 파일), `url` (북마크), `folder` (폴더)
- `parent_id`: 상위 폴더 ID (`null`이면 루트)
- 폴더 삭제 시 하위 항목 재귀 삭제
- 기존 카테고리 형식에서 자동 마이그레이션 지원
