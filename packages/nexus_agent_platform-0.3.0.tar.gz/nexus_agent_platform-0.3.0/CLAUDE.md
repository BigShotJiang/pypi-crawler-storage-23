# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

**Nexus Agent** — a full-stack AI agent platform with a chat interface and dynamic tool registration system. Packaged as a single CLI tool (`nexus-agent`).

- **Frontend**: Next.js 16 (App Router) + React 19 + TypeScript, using pnpm
- **Backend**: Python 3.13 + FastAPI, using uv
- **LLM**: Google Gemini 2.0 Flash via LiteLLM abstraction layer
- **Package**: `nexus-agent` (CLI via click, installable via `pipx` or `uv tool`)

## Development Commands

### Quick Start
```bash
uv run nexus-agent init             # ~/.nexus-agent/ 초기 설정 생성
uv run nexus-agent start --dev      # 개발 모드 (CORS 허용, 리로드)
```

### Frontend (`frontend/`)
```bash
cd frontend && pnpm dev          # Dev server on :3000
cd frontend && pnpm build        # Production build (static export → out/)
cd frontend && pnpm lint         # ESLint
```

### Backend (직접 실행)
```bash
uv run uvicorn nexus_agent.server:app --reload --host 0.0.0.0 --port 8000
```

### Full Build (프론트엔드 포함 wheel 빌드)
```bash
./scripts/build.sh    # frontend build → nexus_agent/static/ → uv build
```

### Environment
설정 파일은 `~/.nexus-agent/`에 저장됨:
- `.env` — `GOOGLE_API_KEY` 등
- `settings.json` — LLM 설정
- `mcp.json` — MCP 서버 설정
- `skills.json`, `pages.json` — 런타임 데이터

## Architecture

### Request Flow
```
User → ChatInterface (React) → POST /api/chat/ → AgentOrchestrator.run()
  → LLMClient (LiteLLM acompletion) → Gemini API
  → If tool_calls in response:
      → MCP tool call or Skill tool call
      → Tool result appended to messages
      → Second LLM call with tool results
  → Final response → ChatInterface
```

### Package Structure
- `nexus_agent/` — Python 패키지 (최상위)
  - `cli.py` — click CLI 엔트리포인트 (`nexus-agent` 명령)
  - `server.py` — FastAPI 앱, 정적 파일 서빙, CORS 설정
  - `config.py` — `~/.nexus-agent/` 데이터 디렉토리 관리
  - `core/` — agent, llm, mcp_manager, skill_manager, page_manager, settings_manager
  - `api/endpoints/` — chat, mcp, skills, pages, settings
  - `models/` — mcp, skill, page, settings
  - `static/` — 빌드된 프론트엔드 (wheel에 포함, git에서 제외)

### Frontend Structure
- `frontend/src/app/page.tsx` — Home page rendering ChatInterface
- `frontend/src/app/pages/page.tsx` — Pages Dashboard
- `frontend/src/app/pages/viewer/page.tsx` — Page viewer (`?id=xxx` query param)
- `frontend/src/app/tools/page.tsx` — MCP Server management
- `frontend/src/app/skills/page.tsx` — Skills management
- `frontend/src/app/settings/page.tsx` — LLM Settings
- `frontend/src/lib/config.ts` — API_BASE_URL (빈 문자열 = same origin)

### Key Patterns
- **Path alias**: `@/*` maps to `./src/*` in tsconfig
- **shadcn/ui config**: `frontend/components.json` — new-york style, Lucide icons, CSS variables
- **Static export**: `next.config.ts`에 `output: "export"` — 빌드 시 정적 HTML 생성
- **Data directory**: 모든 런타임 데이터는 `~/.nexus-agent/`에 저장
- **Styling**: oklch color space, dark theme with glassmorphism (backdrop-blur, low-opacity borders), amber/orange primary color

## Git Commit Convention

- **커밋 시 반드시 `/commit` (git-commit-formatter 스킬)을 사용할 것**
- Follow **Conventional Commits**: `<type>(scope): <description>`
- Types: feat, fix, docs, style, refactor, perf, test, chore
- Commit messages must be written in **Korean (한글)**
- Do NOT include `Co-Authored-By` in commit messages

## Ports

| Service | URL |
|---------|-----|
| Frontend (dev) | http://localhost:3000 |
| Backend API / UI (production) | http://localhost:8000 |
| Swagger Docs | http://localhost:8000/docs |
