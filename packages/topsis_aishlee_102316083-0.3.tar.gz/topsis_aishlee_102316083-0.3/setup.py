
from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="topsis-aishlee-102316083",
    version="0.3",
    packages=find_packages(),
    author="Aishlee Joshi",
    author_email="ajoshi1_be23@thapar.edu",
    description="TOPSIS command-line implementation in Python",
    long_description=long_description,
    long_description_content_type="text/markdown",
    install_requires=["numpy","pandas"],
    entry_points={
        "console_scripts":[
            "topsis=mytopsis.main:run"
        ]
    }
)
