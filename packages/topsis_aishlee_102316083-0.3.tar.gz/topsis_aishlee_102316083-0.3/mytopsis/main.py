
import sys
import pandas as pd
import numpy as np


def main():

    if len(sys.argv) != 5:
        print("Usage: python topsis.py input.csv weights impacts output.csv")
        return

    file = sys.argv[1]
    weights = sys.argv[2]
    impacts = sys.argv[3]
    output = sys.argv[4]

    try:
        df = pd.read_csv(file)
    except:
        print("File not found")
        return

    if df.shape[1] < 3:
        print("Need at least 3 columns")
        return

    data = df.iloc[:, 1:].values

    try:
        data = data.astype(float)
    except:
        print("Columns must be numeric")
        return

    weights = list(map(float, weights.split(",")))
    impacts = impacts.split(",")

    if len(weights) != data.shape[1]:
        print("Wrong weights")
        return

    if len(impacts) != data.shape[1]:
        print("Wrong impacts")
        return

    for i in impacts:
        if i not in ['+', '-']:
            print("Impacts must be + or -")
            return

    norm = np.sqrt((data ** 2).sum(axis=0))
    data = data / norm

    data = data * weights

    best = []
    worst = []

    for i in range(len(impacts)):
        if impacts[i] == '+':
            best.append(data[:, i].max())
            worst.append(data[:, i].min())
        else:
            best.append(data[:, i].min())
            worst.append(data[:, i].max())

    best = np.array(best)
    worst = np.array(worst)

    d1 = np.sqrt(((data - best) ** 2).sum(axis=1))
    d2 = np.sqrt(((data - worst) ** 2).sum(axis=1))

    score = d2 / (d1 + d2)

    df["Topsis Score"] = score
    df["Rank"] = df["Topsis Score"].rank(ascending=False)

    df.to_csv(output, index=False)

    print("Saved in", output)


def run():
    main()
