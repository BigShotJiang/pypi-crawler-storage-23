
# TOPSIS Assignment

TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) is a multi-criteria decision-making method.

This package provides a command-line implementation of the TOPSIS method in Python. It helps users rank multiple alternatives based on different criteria, weights, and impacts.

## Features
- Accepts CSV input files
- Supports user-defined weights and impacts
- Handles invalid inputs and errors
- Generates ranked output with TOPSIS scores
- Easy to use command-line interface

## Installation
pip install topsis-aishlee-102316083

## Usage
topsis input.csv weights impacts output.csv

Example:
topsis data.csv 1,1,1,1,1 +,+,+,+,+ result.csv

## Author
Aishlee Joshi
