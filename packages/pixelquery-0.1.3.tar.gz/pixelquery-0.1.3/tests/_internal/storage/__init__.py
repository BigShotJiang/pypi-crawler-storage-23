"""
Tests for storage layer
"""
