"""
PixelQuery Internal Module

⚠️ PRIVATE API - Do not use directly!

This module contains internal implementation details.
The API may change without notice.
"""

# No exports - internal use only
__all__: list[str] = []
