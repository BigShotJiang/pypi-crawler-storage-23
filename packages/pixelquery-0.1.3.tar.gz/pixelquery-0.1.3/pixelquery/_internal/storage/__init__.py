"""
Internal Storage Module

⚠️ PRIVATE API - Do not use directly!
"""

__all__: list[str] = []
