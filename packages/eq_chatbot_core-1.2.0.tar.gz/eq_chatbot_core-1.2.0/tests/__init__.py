"""Tests for chatbot-core package."""
