"""AFMB case registry schema and validation helpers.

This module defines a lightweight schema for an AFMB case registry and provides
validators to ensure uniqueness and taxonomy consistency.
"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

CASE_REGISTRY_SCHEMA_VERSION = "afmb_cases/v1"


@dataclass(slots=True, frozen=True)
class CaseEntry:
    case_id: str
    name: str
    failure_mode: str
    expected_intervention: str | None = None
    primary_variables: tuple[str, ...] = ()
    description: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "case_id": self.case_id,
            "name": self.name,
            "failure_mode": self.failure_mode,
        }
        if self.expected_intervention:
            payload["expected_intervention"] = self.expected_intervention
        if self.primary_variables:
            payload["primary_variables"] = list(self.primary_variables)
        if self.description:
            payload["description"] = self.description
        return payload

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> CaseEntry:
        case_id = _require_str(payload.get("case_id"), "case.case_id")
        name = _require_str(payload.get("name"), "case.name")
        failure_mode = _require_str(payload.get("failure_mode"), "case.failure_mode")
        expected_intervention = _optional_str(
            payload.get("expected_intervention"), "case.expected_intervention"
        )
        variables = _normalize_str_sequence(
            payload.get("primary_variables"), "case.primary_variables"
        )
        description = _optional_str(payload.get("description"), "case.description")
        return cls(
            case_id=case_id,
            name=name,
            failure_mode=failure_mode,
            expected_intervention=expected_intervention,
            primary_variables=variables,
            description=description,
        )


@dataclass(slots=True, frozen=True)
class CaseRegistry:
    schema_version: str
    taxonomy: Mapping[str, tuple[str, ...]]
    cases: tuple[CaseEntry, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version,
            "taxonomy": {k: list(v) for k, v in self.taxonomy.items()},
            "cases": [c.to_dict() for c in self.cases],
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> CaseRegistry:
        schema_version = (
            _optional_str(payload.get("schema_version"), "schema_version")
            or CASE_REGISTRY_SCHEMA_VERSION
        )
        taxonomy_raw = _require_mapping(payload.get("taxonomy"), "taxonomy")
        taxonomy: dict[str, tuple[str, ...]] = {}
        for key, seq in taxonomy_raw.items():
            if not isinstance(key, str):
                raise ValueError("taxonomy keys must be strings")
            taxonomy[key] = _normalize_str_sequence(seq, f"taxonomy.{key}")
        cases_value = payload.get("cases")
        if not isinstance(cases_value, Sequence):
            raise ValueError("cases must be a sequence")
        cases = tuple(CaseEntry.from_dict(_require_mapping(item, "case")) for item in cases_value)
        registry = cls(schema_version=schema_version, taxonomy=taxonomy, cases=cases)
        validate_case_registry(registry)
        return registry

    @classmethod
    def load(cls, path: str | Path) -> CaseRegistry:
        text = Path(path).read_text(encoding="utf-8")
        data = json.loads(text)
        if not isinstance(data, Mapping):
            raise ValueError("case registry JSON must decode to an object")
        return cls.from_dict(data)


def validate_case_registry(registry: CaseRegistry) -> None:
    """Validate uniqueness and taxonomy membership.

    - Case IDs must be unique.
    - failure_mode must exist in taxonomy.failure_modes.
    - expected_intervention (when present) must exist in taxonomy.interventions.
    - primary_variables must be in taxonomy.variables.
    """

    ids: set[str] = set()
    failure_modes = set(registry.taxonomy.get("failure_modes", ()))
    interventions = set(registry.taxonomy.get("interventions", ()))
    variables = set(registry.taxonomy.get("variables", ()))
    for case in registry.cases:
        if case.case_id in ids:
            raise ValueError(f"duplicate case_id: {case.case_id}")
        ids.add(case.case_id)
        if case.failure_mode not in failure_modes:
            raise ValueError(f"case {case.case_id} has unknown failure_mode: {case.failure_mode}")
        if case.expected_intervention and case.expected_intervention not in interventions:
            msg = (
                f"case {case.case_id} has unknown expected_intervention: "
                f"{case.expected_intervention}"
            )
            raise ValueError(msg)
        for var in case.primary_variables:
            if var not in variables:
                raise ValueError(f"case {case.case_id} references unknown variable: {var}")


def _require_mapping(value: Any, field: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{field} must be a mapping")
    return value


def _require_str(value: Any, field: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field} must be a string")
    return value


def _optional_str(value: Any, field: str) -> str | None:
    if value is None:
        return None
    return _require_str(value, field)


def _normalize_str_sequence(value: Any, field: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        raise ValueError(f"{field} must be a sequence of strings")
    if not isinstance(value, Sequence):
        raise ValueError(f"{field} must be a sequence")
    return tuple(_require_str(item, f"{field}[{idx}]") for idx, item in enumerate(value))


__all__ = [
    "CASE_REGISTRY_SCHEMA_VERSION",
    "CaseEntry",
    "CaseRegistry",
    "validate_case_registry",
]
