"""Offline AFMB smoke suite runner (packaged).

Runs synthetic, offline scenarios that trip common agent failure modes and
writes ledgers under the requested output directory. Mirrors the behavior of
the legacy scripts/run_afmb_suite.py runner but is importable for packaging.
"""

from __future__ import annotations

import json
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ultrastable.agent import AgentGuard, StepMetrics
from ultrastable.cli.demos import build_agent_loop_controller, build_budget_controller
from ultrastable.core import (
    Controller,
    EssentialVariable,
    EssentialVariableSpace,
    HealthModel,
    ViabilityPolicy,
)
from ultrastable.detectors import ContextPressureDetector
from ultrastable.interventions import ResetContextTrim
from ultrastable.ledger import JsonlLedger

ScenarioRunner = Callable[[Path], "ScenarioRunResult"]


@dataclass(frozen=True)
class Scenario:
    case_id: str
    name: str
    description: str
    runner: ScenarioRunner

    @property
    def slug(self) -> str:
        return _slugify(self.name)


@dataclass(frozen=True)
class ScenarioRunResult:
    ledger_path: Path
    steps: int


def _slugify(value: str) -> str:
    return "".join(ch if ch.isalnum() else "_" for ch in value.lower()).strip("_")


def _scenario_tags(case_id: str, scenario_name: str) -> dict[str, str]:
    return {"suite": "afmb", "case_id": case_id, "scenario": scenario_name}


def _create_guard(
    controller: Controller,
    path: Path,
    *,
    context_budget_chars: int | None,
) -> tuple[AgentGuard, JsonlLedger]:
    path.parent.mkdir(parents=True, exist_ok=True)
    ledger = JsonlLedger(str(path))
    guard = AgentGuard(
        controller=controller,
        ledger=ledger,
        context_budget_chars=context_budget_chars,
    )
    return guard, ledger


def _run_lexical_repeat(path: Path) -> ScenarioRunResult:
    guard, ledger = _create_guard(
        build_agent_loop_controller(),
        path,
        context_budget_chars=4000,
    )
    tags = _scenario_tags("s1", "lexical_repeat_loop")
    conversation = [{"id": "sys", "role": "system", "content": "Reply concisely."}]
    guard.start_run(run_id="afmb-s1", tags=tags)
    guard.pre_step(conversation)
    repeated_response = "Understood. Continuing with the requested action."
    prompt = "Confirm the deployment checklist."
    steps = 0
    try:
        for idx in range(8):
            metrics = StepMetrics(
                tokens_prompt=18,
                tokens_completion=24,
                tokens_total=42,
                cost_usd=0.004,
                retries=1 if idx % 2 == 1 else 0,
            )
            decision = guard.post_step(
                step_id=f"s1-loop-{idx}",
                role="assistant",
                kind="llm",
                model="offline-demo-model",
                prompt_text=prompt,
                response_text=repeated_response,
                metrics=metrics,
                tags={**tags, "iteration": idx},
            )
            steps += 1
            conversation.extend(
                [
                    {"id": f"user-{idx}", "role": "user", "content": prompt},
                    {"id": f"assistant-{idx}", "role": "assistant", "content": repeated_response},
                ]
            )
            guard.pre_step(conversation)
            if decision.policy_status == "critical":
                break
    finally:
        guard.end_run()
        ledger.close()
    return ScenarioRunResult(ledger_path=path, steps=steps)


def _run_tool_loop(path: Path) -> ScenarioRunResult:
    guard, ledger = _create_guard(
        build_agent_loop_controller(),
        path,
        context_budget_chars=4000,
    )
    tags = _scenario_tags("s2", "tool_loop")
    guard.start_run(run_id="afmb-s2", tags=tags)
    guard.pre_step(
        [{"id": "sys", "role": "system", "content": "Use search to answer the question."}]
    )
    steps = 0
    try:
        for idx in range(6):
            guard.post_step(
                step_id=f"s2-tool-{idx}",
                role="tool",
                kind="tool",
                tool_name="search",
                tool_args_hash="afmb",
                response_text="synthetic tool output",
                metrics=StepMetrics(tokens_total=15, cost_usd=0.001),
                tags={
                    **tags,
                    "status": "error" if idx >= 2 else "ok",
                    "tool_name": "search",
                },
            )
            steps += 1
    finally:
        guard.end_run()
        ledger.close()
    return ScenarioRunResult(ledger_path=path, steps=steps)


def _run_retry_storm(path: Path) -> ScenarioRunResult:
    guard, ledger = _create_guard(
        build_agent_loop_controller(),
        path,
        context_budget_chars=4000,
    )
    tags = _scenario_tags("s3", "retry_storm")
    guard.start_run(run_id="afmb-s3", tags=tags)
    conversation = [{"id": "sys", "role": "system", "content": "Retry flaky tools up to 3 times."}]
    guard.pre_step(conversation)
    steps = 0
    try:
        for idx in range(8):
            metrics = StepMetrics(
                tokens_prompt=16,
                tokens_completion=10,
                tokens_total=26,
                cost_usd=0.003,
                retries=2,
            )
            response = (
                "Attempt failed; retrying tool call." if idx % 2 == 0 else "Still retrying..."
            )
            decision = guard.post_step(
                step_id=f"s3-retry-{idx}",
                role="assistant",
                kind="llm",
                model="offline-demo-model",
                prompt_text="Invoke the reconciliation tool.",
                response_text=response,
                metrics=metrics,
                tags={**tags, "status": "error", "iteration": idx},
            )
            steps += 1
            conversation.extend(
                [
                    {
                        "id": f"user-{idx}",
                        "role": "user",
                        "content": "Why is the tool still failing?",
                    },
                    {"id": f"assistant-{idx}", "role": "assistant", "content": response},
                ]
            )
            guard.pre_step(conversation)
            if decision.policy_status == "critical":
                break
    finally:
        guard.end_run()
        ledger.close()
    return ScenarioRunResult(ledger_path=path, steps=steps)


def _build_context_pressure_controller() -> Controller:
    space = EssentialVariableSpace(
        [
            EssentialVariable.bounded("context_util", min=0.0, max=0.95, scale=0.95),
            EssentialVariable.monotonic("tokens_total", hard_limit=2200, scale=2200),
        ]
    )
    policy = ViabilityPolicy(space=space, health=HealthModel("l2"), bounded_warn_fraction=0.2)
    detectors = [
        ContextPressureDetector(max_tokens=2200, warn_fraction=0.75, critical_fraction=0.92)
    ]
    interventions = [ResetContextTrim(keep_last_turns=3)]
    return Controller(
        policy=policy,
        detectors=detectors,
        interventions=interventions,
        cooldown_steps=1,
    )


def _run_context_bloat(path: Path) -> ScenarioRunResult:
    guard, ledger = _create_guard(
        _build_context_pressure_controller(),
        path,
        context_budget_chars=2200,
    )
    tags = _scenario_tags("s4", "context_bloat")
    guard.start_run(run_id="afmb-s4", tags=tags)
    conversation = [{"id": "sys", "role": "system", "content": "Provide exhaustive detail."}]
    guard.pre_step(conversation)
    steps = 0
    tokens = 400
    try:
        for idx in range(8):
            tokens += 320
            metrics = StepMetrics(tokens_total=tokens, cost_usd=0.002 * (idx + 1))
            decision = guard.post_step(
                step_id=f"s4-context-{idx}",
                role="assistant",
                kind="llm",
                model="offline-demo-model",
                prompt_text="List every dependency in detail.",
                response_text="Here is an expanded list of dependencies..." * 2,
                metrics=metrics,
                tags={**tags, "iteration": idx},
            )
            steps += 1
            conversation.append(
                {"id": f"user-{idx}", "role": "user", "content": "Add more elaboration."}
            )
            conversation.append(
                {
                    "id": f"assistant-{idx}",
                    "role": "assistant",
                    "content": "Here is an expanded list of dependencies..." * 2,
                }
            )
            guard.pre_step(conversation)
            if decision.policy_status == "critical":
                break
    finally:
        guard.end_run()
        ledger.close()
    return ScenarioRunResult(ledger_path=path, steps=steps)


def _run_cost_spike(path: Path) -> ScenarioRunResult:
    guard, ledger = _create_guard(
        build_budget_controller(),
        path,
        context_budget_chars=None,
    )
    tags = _scenario_tags("s5", "cost_spike")
    guard.start_run(run_id="afmb-s5", tags=tags)
    guard.pre_step([{"id": "sys", "role": "system", "content": "Keep expenses minimal."}])
    steps = 0
    costs = [0.0015, 0.0015, 0.35, 0.05]
    try:
        for idx, cost in enumerate(costs):
            decision = guard.post_step(
                step_id=f"s5-cost-{idx}",
                role="assistant",
                kind="llm",
                model="offline-demo-model",
                prompt_text="Process the next invoice.",
                response_text="Processing...",
                metrics=StepMetrics(tokens_total=40 + idx * 5, cost_usd=cost),
                tags={**tags, "iteration": idx},
            )
            steps += 1
            if decision.policy_status == "critical":
                break
    finally:
        guard.end_run()
        ledger.close()
    return ScenarioRunResult(ledger_path=path, steps=steps)


SCENARIOS: tuple[Scenario, ...] = (
    Scenario(
        case_id="s1",
        name="lexical_repeat_loop",
        description="Assistant repeats the same response, tripping lexical repeat detectors.",
        runner=_run_lexical_repeat,
    ),
    Scenario(
        case_id="s2",
        name="tool_loop",
        description="Tool call churn with repeated failures and identical arguments.",
        runner=_run_tool_loop,
    ),
    Scenario(
        case_id="s3",
        name="retry_storm",
        description="Agent spins on retries after persistent tool errors.",
        runner=_run_retry_storm,
    ),
    Scenario(
        case_id="s4",
        name="context_bloat",
        description="Context window balloons past safe thresholds, forcing trims.",
        runner=_run_context_bloat,
    ),
    Scenario(
        case_id="s5",
        name="cost_spike",
        description="Spend jumps suddenly, tripping monotonic guardrails.",
        runner=_run_cost_spike,
    ),
)


def run_afmb_suite(
    output_dir: Path,
    *,
    max_duration_seconds: float = 600.0,
    summary_filename: str = "afmb_suite_summary.json",
) -> dict[str, Any]:
    """Run every AFMB scenario and ensure the total runtime stays below the limit."""

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    results: list[dict[str, Any]] = []
    total_duration = 0.0
    for scenario in SCENARIOS:
        ledger_path = output_dir / f"{scenario.case_id}_{scenario.slug}_ledger.jsonl"
        start = time.perf_counter()
        scenario_result = scenario.runner(ledger_path)
        duration = time.perf_counter() - start
        total_duration += duration
        results.append(
            {
                "case_id": scenario.case_id,
                "name": scenario.name,
                "description": scenario.description,
                "ledger": str(scenario_result.ledger_path),
                "steps": scenario_result.steps,
                "duration_seconds": round(duration, 3),
            }
        )

    if total_duration > max_duration_seconds:
        raise RuntimeError(
            f"AFMB suite exceeded {max_duration_seconds} seconds (actual: {total_duration:.2f}s)"
        )

    summary_path = output_dir / summary_filename
    summary = {
        "suite": "afmb",
        "variant": "smoke",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "total_duration_seconds": round(total_duration, 3),
        "max_duration_seconds": float(max_duration_seconds),
        "scenarios": results,
        "summary_path": str(summary_path),
    }
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


__all__ = ["SCENARIOS", "run_afmb_suite", "Scenario", "ScenarioRunResult"]
