from __future__ import annotations

from pathlib import Path

from ultrastable.cli.main import main as cli_main


def test_cli_benchmark_run_emits_artifacts(tmp_path: Path) -> None:
    outdir = tmp_path / "afmb"
    cfg = Path("benchmarks/afmb_baselines.json")
    assert cli_main(["benchmark", "run", "--config", str(cfg), "--output-dir", str(outdir)]) == 0
    manifest = outdir / "manifest.json"
    results = outdir / "results.json"
    report = outdir / "report.md"
    logs_dir = outdir / "logs"
    assert manifest.exists()
    assert results.exists()
    assert report.exists()
    assert logs_dir.exists() and logs_dir.is_dir()

    # Validate via CLI
    assert cli_main(["benchmark", "validate", "config", str(cfg)]) == 0
    assert cli_main(["benchmark", "validate", "manifest", str(manifest)]) == 0
    assert cli_main(["benchmark", "validate", "results", str(results)]) == 0
