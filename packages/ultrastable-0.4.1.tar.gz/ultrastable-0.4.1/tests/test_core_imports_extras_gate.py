from __future__ import annotations

import subprocess
import sys


def _run(code: str) -> str:
    result = subprocess.run(
        [sys.executable, "-c", code], capture_output=True, text=True, check=True
    )
    return result.stdout.strip()


def test_core_import_does_not_import_extras_modules() -> None:
    code = "\n".join(
        [
            "import sys; import ultrastable",
            "mods=set(sys.modules.keys())",
            "print(any(m.startswith('gymnasium') for m in mods))",
            "print(any(m.startswith('torch') for m in mods))",
            "print(any(m.startswith('opentelemetry') for m in mods))",
            "print(any(m.startswith('rich') for m in mods))",
            "print(any(m.startswith('typer') for m in mods))",
        ]
    )
    out = _run(code).splitlines()
    assert out == ["False", "False", "False", "False", "False"], out
