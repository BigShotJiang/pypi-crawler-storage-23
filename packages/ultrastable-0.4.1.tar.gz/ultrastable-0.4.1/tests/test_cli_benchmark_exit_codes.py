from __future__ import annotations

from pathlib import Path

import pytest

from ultrastable.cli.main import main as cli_main


def test_benchmark_run_missing_config_returns_error(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    missing = tmp_path / "missing_config.json"
    assert (
        cli_main(["benchmark", "run", "--config", str(missing), "--output-dir", str(tmp_path)]) == 2
    )
    out = capsys.readouterr().out
    assert "Failed to load harness config" in out
