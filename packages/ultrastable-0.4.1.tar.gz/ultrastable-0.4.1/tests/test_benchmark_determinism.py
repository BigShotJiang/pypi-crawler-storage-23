from __future__ import annotations

import json
from pathlib import Path
from typing import Any, cast

from ultrastable.cli.main import main as cli_main


def _load_results(path: Path) -> dict[str, Any]:
    return cast(dict[str, Any], json.loads(path.read_text(encoding="utf-8")))


def test_seeded_benchmark_kpis_are_stable(tmp_path: Path) -> None:
    cfg = Path("benchmarks/afmb_baselines.json")
    out1 = tmp_path / "afmb1"
    out2 = tmp_path / "afmb2"
    args = ["benchmark", "run", "--config", str(cfg), "--seed", "123"]

    # First run
    assert cli_main([*args, "--output-dir", str(out1)]) == 0
    # Second run
    assert cli_main([*args, "--output-dir", str(out2)]) == 0

    r1 = _load_results(out1 / "results.json")
    r2 = _load_results(out2 / "results.json")

    # Compare KPIs and per-case statuses (ignore timestamps/run_id differences)
    assert r1.get("kpis") == r2.get("kpis")
    cases1 = sorted([(c["case_id"], c["status"]) for c in r1.get("cases", [])])
    cases2 = sorted([(c["case_id"], c["status"]) for c in r2.get("cases", [])])
    assert cases1 == cases2
