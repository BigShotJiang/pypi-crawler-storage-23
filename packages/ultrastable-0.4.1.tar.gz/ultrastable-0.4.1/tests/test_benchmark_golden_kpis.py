from __future__ import annotations

import json
from pathlib import Path
from typing import Any, cast

import pytest

from ultrastable.cli.main import main as cli_main


def _load_json(path: Path) -> dict[str, Any]:
    return cast(dict[str, Any], json.loads(path.read_text(encoding="utf-8")))


def test_benchmark_smoke_kpis_match_golden(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    cfg = Path("benchmarks/afmb_baselines.json")
    out = tmp_path / "afmb_golden"
    args = [
        "benchmark",
        "run",
        "--config",
        str(cfg),
        "--output-dir",
        str(out),
        "--seed",
        "123",
        "--emit-kpis",
    ]
    assert cli_main(args) == 0

    results = _load_json(out / "results.json")
    golden = _load_json(Path("tests/data/golden_benchmark/afmb_smoke_kpis.json"))

    diffs: list[str] = []
    # Compare kpis subset
    golden_kpis = golden.get("kpis", {})
    result_kpis = results.get("kpis", {})
    for key, gval in golden_kpis.items():
        rval = result_kpis.get(key)
        if rval != gval:
            diffs.append(f"kpis.{key}: expected {gval}, got {rval}")

    # Compare case IDs and total
    exp_ids = set(golden.get("case_ids", []))
    got_ids = set(c.get("case_id") for c in results.get("cases", []))
    if exp_ids != got_ids:
        diffs.append(f"case_ids: expected {sorted(exp_ids)}, got {sorted(got_ids)}")
    exp_total = golden.get("cases_total")
    got_total = len(results.get("cases", []))
    if exp_total is not None and exp_total != got_total:
        diffs.append(f"cases_total: expected {exp_total}, got {got_total}")

    if diffs:
        print("\n".join(diffs))
    assert not diffs
