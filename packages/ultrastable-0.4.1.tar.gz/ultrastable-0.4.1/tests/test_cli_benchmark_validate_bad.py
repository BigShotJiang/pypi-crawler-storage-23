from __future__ import annotations

import json
from pathlib import Path

import pytest

from ultrastable.cli.main import main as cli_main


def test_validate_config_rejects_non_sequence_baselines(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    cfg = tmp_path / "bad_config.json"
    payload = {
        "suite": {"name": "afmb", "version": "v1"},
        "baselines": {"not": "a list"},
    }
    cfg.write_text(json.dumps(payload), encoding="utf-8")
    assert cli_main(["benchmark", "validate", "config", str(cfg)]) == 2
    out = capsys.readouterr().out
    assert "Validation failed" in out and "baselines" in out


def test_validate_manifest_requires_suite(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    manifest = tmp_path / "bad_manifest.json"
    payload = {
        "schema_version": "run_manifest/v1",
        "seeds": {"global": 0},
        "env": {
            "platform": {"system": "Linux"},
            "python": {"implementation": "Py", "version": "3.10"},
            "ultrastable_version": "0.4.0",
        },
    }
    manifest.write_text(json.dumps(payload), encoding="utf-8")
    assert cli_main(["benchmark", "validate", "manifest", str(manifest)]) == 2
    out = capsys.readouterr().out
    assert "Validation failed" in out and "suite" in out


def test_validate_results_rejects_string_cases(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    results = tmp_path / "bad_results.json"
    payload = {
        "schema_version": "benchmark_results/v1",
        "suite": {"name": "afmb", "version": "v1"},
        "summary": {"status": "completed", "cases_total": 1},
        "cases": "not a list",
    }
    results.write_text(json.dumps(payload), encoding="utf-8")
    assert cli_main(["benchmark", "validate", "results", str(results)]) == 2
    out = capsys.readouterr().out
    assert "Validation failed" in out and "cases" in out


def test_validate_cases_registry_rejects_unknown_taxonomy(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
) -> None:
    registry = tmp_path / "bad_cases.json"
    payload = {
        "schema_version": "afmb_cases/v1",
        "taxonomy": {
            "failure_modes": ["runaway_retries"],
            "interventions": ["RESET_REPLAN"],
            "variables": ["tokens_total"],
        },
        "cases": [
            {
                "case_id": "s1",
                "name": "Retries escalate",
                "failure_mode": "unknown_mode",
                "expected_intervention": "RESET_REPLAN",
                "primary_variables": ["tokens_total"],
            }
        ],
    }
    registry.write_text(json.dumps(payload), encoding="utf-8")
    assert cli_main(["benchmark", "validate", "cases", str(registry)]) == 2
    out = capsys.readouterr().out
    assert "Validation failed" in out and "failure_mode" in out
