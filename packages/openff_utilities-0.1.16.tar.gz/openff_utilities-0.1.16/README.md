openff-utilities
==============================
[//]: # (Badges)
[![GitHub Actions Build Status](https://github.com/openforcefield/openff-utilities/workflows/CI/badge.svg)](https://github.com/openforcefield/openff-utilities/actions?query=workflow%3ACI)
[![codecov](https://codecov.io/gh/openforcefield/openff-utilities/branch/main/graph/badge.svg)](https://codecov.io/gh/openforcefield/openff-utilities/branch/main)


A collection of miscellaneous utility functions used throughout the OpenFF stack

### Copyright

Copyright (c) 2021, The Open Force Field Initiative


#### Acknowledgements

Project based on the
[Computational Molecular Science Python Cookiecutter](https://github.com/molssi/cookiecutter-cms) version 1.5.
