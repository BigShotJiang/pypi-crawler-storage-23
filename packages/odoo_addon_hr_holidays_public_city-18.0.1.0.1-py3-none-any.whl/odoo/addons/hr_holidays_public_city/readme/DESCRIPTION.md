This module adds the cities at the public vacation line level as an
extra discriminant.
