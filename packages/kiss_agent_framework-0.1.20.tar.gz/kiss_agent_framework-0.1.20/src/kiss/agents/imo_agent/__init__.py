import kiss.agents.imo_agent.config  # type: ignore # noqa: F401
