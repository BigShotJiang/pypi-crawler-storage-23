"""
agentcents Proxy Core
Generic LLM API proxy with cost tracking, budget enforcement,
exact-match cache, semantic cache, and auto-routing.

Start: uvicorn agentcents.proxy:app --port 8082 --reload
"""

import json
import time
import uuid
import hashlib
import logging
from typing import Optional

import httpx
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse

from agentcents.catalog import get_model_price
from agentcents.ledger import record_call

logger = logging.getLogger("agentcents.proxy")
logging.basicConfig(level=logging.INFO)

app = FastAPI(title="agentcents proxy", version="0.5.0")

from agentcents.dashboard import router as dashboard_router
app.include_router(dashboard_router)

from agentcents.local import router as local_router
app.include_router(local_router)

@app.on_event("startup")
async def startup():
    from agentcents.cache import init_cache_tables
    init_cache_tables()
    # Ensure exact_cache table exists at startup rather than lazily on first write
    _exact_cache_init()

# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    return {"status": "ok", "version": "0.5.0"}


# ---------------------------------------------------------------------------
# Generic catch-all proxy
# ---------------------------------------------------------------------------

@app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"])
async def proxy(path: str, request: Request):
    """
    Intercepts every LLM API call.

    Required header:
        X-Agentcents-Target:  https://api.openai.com

    Optional headers:
        X-Agentcents-Tag:     my-project
        X-Agentcents-Session: agent-1
        X-Agentcents-Cache:   off        disable all caching
        X-Agentcents-Cache:   exact      exact-match only (skip semantic)
    """

    # -- 1. Resolve target -----------------------------------------------
    target_base = request.headers.get("X-Agentcents-Target")
    if not target_base:
        raise HTTPException(
            status_code=400,
            detail="Missing header: X-Agentcents-Target"
        )

    tag          = request.headers.get("X-Agentcents-Tag", "default")
    session_id   = request.headers.get("X-Agentcents-Session", _generate_session_id())
    cache_header = request.headers.get("X-Agentcents-Cache", "on").lower()
    cache_on     = cache_header != "off"
    semantic_on  = cache_header not in ("off", "exact")
    target_url   = f"{target_base.rstrip('/')}/{path}"

    # -- 2. Read request body --------------------------------------------
    body_bytes = await request.body()
    body_json: Optional[dict] = None
    try:
        body_json = json.loads(body_bytes) if body_bytes else None
    except Exception:
        pass

    # -- 3. Extract model id ---------------------------------------------
    model_id = body_json.get("model") if body_json else None

    # -- 4. Phase 8: Auto-routing check ----------------------------------
    routed_model      = None
    routed_body_json  = body_json
    routed_body_bytes = body_bytes
    extra_response_headers = {}

    if request.method == "POST" and body_json and model_id:
        try:
            from agentcents.router import check_routing, apply_routing
            routing = check_routing(model_id, body_json, tag)

            if routing["action"] == "warn":
                logger.warning(
                    f"[{tag}|{session_id}] ⚠ ROUTING WARN  {routing['reason']}"
                )
                extra_response_headers["X-Agentcents-Suggest"] = routing["suggested"] or ""

            elif routing["action"] == "swap":
                routed_model      = routing["suggested"]
                routed_body_json  = apply_routing(body_json, routed_model)
                routed_body_bytes = json.dumps(routed_body_json).encode()
                extra_response_headers["X-Agentcents-Routed"] = routed_model
                logger.warning(
                    f"[{tag}|{session_id}] 🔀 ROUTED  "
                    f"{model_id} → {routed_model}  "
                    f"saves {routing['savings_pct']}%"
                )
                model_id = routed_model
        except Exception as e:
            logger.warning(f"Routing check failed: {e}")

    # -- 5. Pricing lookup -----------------------------------------------
    pricing = get_model_price(model_id) if model_id else None
    if pricing and pricing["input"] > 0:
        logger.info(f"[{tag}|{session_id}] -> {model_id}  input=${pricing['input']}/M  output=${pricing['output']}/M")
    else:
        logger.info(f"[{tag}|{session_id}] -> {model_id or 'unknown'}  (no pricing data)")

    # -- 6. Phase 4: Budget enforcement ----------------------------------
    if request.method == "POST" and body_json:
        blocked, block_msg = _check_budget_block(tag)
        if blocked:
            logger.warning(f"[{tag}|{session_id}] ✗ BLOCKED  {model_id}  {block_msg}")
            return JSONResponse(
                status_code=429,
                content={"error": {"type": "budget_exceeded", "message": block_msg, "tag": tag}}
            )

    is_streaming = body_json.get("stream", False) if body_json else False
    effective_body = routed_body_json or body_json
    cache_key = None

    # Detect provider once — used by streaming handler and OpenAI injection
    provider = _detect_provider(target_base, model_id)

    # For OpenAI streaming: inject stream_options.include_usage so the final
    # SSE chunk carries token counts. Safe no-op for non-OpenAI targets.
    if is_streaming and provider == "openai" and body_json:
        routed_body_bytes = _inject_openai_stream_usage(
            routed_body_json or body_json, routed_body_bytes
        )

    if request.method == "POST" and body_json and model_id and not is_streaming:

        # -- 7. Phase 7: Exact-match cache --------------------------------
        if cache_on:
            cache_key = _exact_cache_key(model_id, effective_body)
            hit = _exact_cache_get(cache_key)
            if hit:
                logger.info(f"[{tag}|{session_id}] ⚡ EXACT HIT  {model_id}  $0.000000")
                record_call(
                    model_id=model_id, tag=tag, session_id=session_id,
                    prompt_tokens=_usage(hit, "prompt"),
                    completion_tokens=_usage(hit, "completion"),
                    cost_usd=0.0, elapsed_s=0.0, status=200,
                )
                return JSONResponse(
                    content=hit, status_code=200,
                    headers={"X-Agentcents-Cache": "exact-hit", **extra_response_headers},
                )

        # -- 8. Phase 9: Semantic cache -----------------------------------
        if cache_on and semantic_on:
            try:
                from agentcents.features import check
                if check("semantic_cache"):
                    from agentcents.cache import lookup as semantic_lookup
                    sem_hit = semantic_lookup(effective_body, model_id)
                    if sem_hit:
                        logger.info(f"[{tag}|{session_id}] 🧠 SEMANTIC HIT  {model_id}  $0.000000")
                        record_call(
                            model_id=model_id, tag=tag, session_id=session_id,
                            prompt_tokens=_usage(sem_hit, "prompt"),
                            completion_tokens=_usage(sem_hit, "completion"),
                            cost_usd=0.0, elapsed_s=0.0, status=200,
                        )
                        return JSONResponse(
                            content=sem_hit, status_code=200,
                            headers={"X-Agentcents-Cache": "semantic-hit", **extra_response_headers},
                        )
            except Exception as e:
                logger.warning(f"Semantic cache lookup failed: {e}")

    # -- 9. Forward request to provider ----------------------------------
    forward_headers = _strip_agentcents_headers(dict(request.headers))
    t0 = time.monotonic()

    async with httpx.AsyncClient(timeout=120) as client:
        if is_streaming:
            return await _handle_streaming(
                client, request.method, target_url,
                forward_headers, routed_body_bytes,
                model_id, pricing, tag, session_id, t0,
                provider=provider,
                extra_headers=extra_response_headers,
            )
        else:
            return await _handle_standard(
                client, request.method, target_url,
                forward_headers, routed_body_bytes, effective_body,
                model_id, pricing, tag, session_id, t0,
                cache_on=cache_on,
                semantic_on=semantic_on,
                cache_key=cache_key,
                extra_headers=extra_response_headers,
            )


# ---------------------------------------------------------------------------
# Phase 4: Budget blocking
# ---------------------------------------------------------------------------

def _check_budget_block(tag: str) -> tuple[bool, str]:
    try:
        from agentcents.config import load as load_config
        cfg     = load_config()
        budgets = cfg.get("budgets", {})

        daily_limit = budgets.get("daily")
        if daily_limit:
            spent = _get_spend_24h()
            if spent >= daily_limit:
                return True, (
                    f"Daily budget exceeded: ${spent:.4f} spent of ${daily_limit:.2f} limit. "
                    f"Update ~/.agentcents.toml to increase budget."
                )

        tag_limit = budgets.get("tags", {}).get(tag, {}).get("daily")
        if tag_limit:
            spent = _get_spend_24h(tag=tag)
            if spent >= tag_limit:
                return True, (
                    f"Tag [{tag}] daily budget exceeded: ${spent:.4f} of ${tag_limit:.2f}. "
                    f"Update ~/.agentcents.toml to increase budget."
                )
    except Exception as e:
        logger.warning(f"Budget check error: {e}")
    return False, ""


def _get_spend_24h(tag: Optional[str] = None) -> float:
    import sqlite3
    from pathlib import Path
    db = Path(__file__).parent / "data" / "ledger.db"
    if not db.exists():
        return 0.0
    since  = time.time() - 86400
    conn   = sqlite3.connect(db)
    q      = "SELECT SUM(cost_usd) FROM calls WHERE ts >= ? AND cost_usd IS NOT NULL"
    params = [since]
    if tag:
        q += " AND tag = ?"
        params.append(tag)
    row = conn.execute(q, params).fetchone()
    conn.close()
    return row[0] or 0.0


# ---------------------------------------------------------------------------
# Phase 7: Exact-match cache
# ---------------------------------------------------------------------------

def _exact_cache_init():
    import sqlite3
    from pathlib import Path
    db = Path(__file__).parent / "data" / "ledger.db"
    try:
        db.parent.mkdir(exist_ok=True)
        conn = sqlite3.connect(db)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS exact_cache (
                cache_key     TEXT    NOT NULL,
                ts            REAL    NOT NULL,
                response_json TEXT    NOT NULL,
                hit_count     INTEGER DEFAULT 0,
                PRIMARY KEY (cache_key)
            )
        """)
        conn.commit()
        conn.close()
    except Exception as e:
        logger.warning(f"Exact cache init failed: {e}")

def _exact_cache_key(model_id: str, body_json: dict) -> str:
    messages = body_json.get("messages") or body_json.get("prompt") or ""
    raw = json.dumps({"model": model_id, "messages": messages}, sort_keys=True)
    return hashlib.sha256(raw.encode()).hexdigest()


def _exact_cache_get(key: str) -> Optional[dict]:
    import sqlite3
    from pathlib import Path
    db = Path(__file__).parent / "data" / "ledger.db"
    if not db.exists():
        return None
    try:
        conn  = sqlite3.connect(db)
        conn.row_factory = sqlite3.Row
        since = time.time() - 86400
        row   = conn.execute("""
            SELECT response_json FROM exact_cache
            WHERE cache_key = ? AND ts >= ?
            ORDER BY ts DESC LIMIT 1
        """, (key, since)).fetchone()
        if row:
            conn.execute(
                "UPDATE exact_cache SET hit_count = hit_count + 1 WHERE cache_key = ?",
                (key,)
            )
            conn.commit()
        conn.close()
        return json.loads(row["response_json"]) if row else None
    except Exception:
        return None


def _exact_cache_put(key: str, response_json: dict):
    import sqlite3
    from pathlib import Path
    db = Path(__file__).parent / "data" / "ledger.db"
    try:
        conn = sqlite3.connect(db)
        conn.execute("""
            INSERT INTO exact_cache (cache_key, ts, response_json)
            VALUES (?, ?, ?)
            ON CONFLICT(cache_key) DO UPDATE SET
                ts            = excluded.ts,
                response_json = excluded.response_json
        """, (key, time.time(), json.dumps(response_json)))
        conn.commit()
        conn.close()
    except Exception as e:
        logger.warning(f"Exact cache put failed: {e}")


# ---------------------------------------------------------------------------
# Standard (non-streaming) response
# ---------------------------------------------------------------------------

async def _handle_standard(
    client, method, url, headers, body, body_json,
    model_id, pricing, tag, session_id, t0,
    cache_on=True, semantic_on=True, cache_key=None, extra_headers=None,
):
    resp    = await client.request(method, url, headers=headers, content=body)
    elapsed = time.monotonic() - t0

    resp_json     = None
    actual_cost   = None
    prompt_tokens = completion_tokens = None

    try:
        resp_json         = resp.json()
        prompt_tokens     = _usage(resp_json, "prompt")
        completion_tokens = _usage(resp_json, "completion")

        if pricing and prompt_tokens is not None and completion_tokens is not None:
            actual_cost = (
                (prompt_tokens     / 1_000_000) * pricing["input"] +
                (completion_tokens / 1_000_000) * pricing["output"]
            )
    except Exception:
        pass

    record_call(
        model_id=model_id, tag=tag, session_id=session_id,
        prompt_tokens=prompt_tokens, completion_tokens=completion_tokens,
        cost_usd=actual_cost, elapsed_s=elapsed, status=resp.status_code,
    )

    if actual_cost is not None:
        logger.info(
            f"[{tag}|{session_id}] ✓ {model_id}  "
            f"in={prompt_tokens} out={completion_tokens}  "
            f"cost=${actual_cost:.6f}  {elapsed:.2f}s"
        )

    # Store in exact cache on success
    if cache_on and cache_key and resp.status_code < 300 and resp_json:
        _exact_cache_put(cache_key, resp_json)

    # Store in semantic cache on success (Pro only)
    if cache_on and semantic_on and resp.status_code < 300 and resp_json and body_json and model_id:
        try:
            from agentcents.features import check
            if check("semantic_cache"):
                from agentcents.cache import store as semantic_store
                semantic_store(
                    body_json, model_id, resp_json,
                    cost_usd=actual_cost or 0.0
                )
        except Exception as e:
            logger.warning(f"Semantic cache store failed: {e}")

    response_headers = _safe_response_headers(resp.headers)
    if extra_headers:
        response_headers.update(extra_headers)

    return JSONResponse(
        content=resp_json if resp_json else {},
        status_code=resp.status_code,
        headers=response_headers,
    )


# ---------------------------------------------------------------------------
# Streaming response (SSE pass-through)
# ---------------------------------------------------------------------------

async def _handle_streaming(
    client, method, url, headers, body,
    model_id, pricing, tag, session_id, t0,
    provider: str = "unknown",
    extra_headers=None,
):
    """
    SSE pass-through that parses token usage from each chunk so streaming
    calls get the same cost data as non-streaming ones.

    OpenAI  — reads the final chunk's `usage` field (requires stream_options
              include_usage=true, injected by the caller before forwarding).
    Anthropic — reads `message_start` (input tokens) and `message_delta`
                (output tokens) events.

    Every line is yielded unchanged — the client sees the exact same SSE
    stream the provider sent.
    """
    prompt_tokens:     int = 0
    completion_tokens: int = 0
    status_code:       int = 200

    async def stream_generator():
        nonlocal prompt_tokens, completion_tokens, status_code

        async with client.stream(method, url, headers=headers, content=body) as resp:
            status_code = resp.status_code

            async for line in resp.aiter_lines():
                # Re-emit the line — SSE lines end with \n; blank lines (\n
                # alone) preserve the \n\n event-separator SSE requires.
                yield (line + "\n").encode()

                if not line.startswith("data: "):
                    continue
                data_str = line[6:]
                if data_str == "[DONE]":
                    continue

                try:
                    chunk = json.loads(data_str)
                except Exception:
                    continue

                # ---- OpenAI / OpenRouter ----
                # With stream_options.include_usage the LAST data chunk
                # (just before [DONE]) carries the full usage object.
                if provider == "openai":
                    usage = chunk.get("usage") or {}
                    if usage:
                        prompt_tokens     = usage.get("prompt_tokens",     0) or prompt_tokens
                        completion_tokens = usage.get("completion_tokens", 0) or completion_tokens

                # ---- Anthropic ----
                # message_start  → input_tokens
                # message_delta  → output_tokens
                elif provider == "anthropic":
                    event_type = chunk.get("type", "")
                    if event_type == "message_start":
                        msg_usage     = chunk.get("message", {}).get("usage", {})
                        prompt_tokens = msg_usage.get("input_tokens", 0)
                    elif event_type == "message_delta":
                        delta_usage       = chunk.get("usage", {})
                        completion_tokens = delta_usage.get("output_tokens", 0)

        # ---- record after stream closes --------------------------------
        elapsed     = time.monotonic() - t0
        actual_cost = None
        pt          = prompt_tokens     or None
        ct          = completion_tokens or None

        if pricing and pt and ct:
            actual_cost = (
                (pt / 1_000_000) * pricing["input"] +
                (ct / 1_000_000) * pricing["output"]
            )

        record_call(
            model_id=model_id, tag=tag, session_id=session_id,
            prompt_tokens=pt, completion_tokens=ct,
            cost_usd=actual_cost, elapsed_s=elapsed,
            status=status_code, streamed=True,
        )

        if actual_cost is not None:
            logger.info(
                f"[{tag}|{session_id}] ✓ {model_id} (streamed)  "
                f"in={pt} out={ct}  cost=${actual_cost:.6f}  {elapsed:.2f}s"
            )
        else:
            logger.info(
                f"[{tag}|{session_id}] ✓ {model_id} (streamed, no usage parsed)  {elapsed:.2f}s"
            )

    return StreamingResponse(
        stream_generator(),
        media_type="text/event-stream",
        headers=extra_headers or {},
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _usage(resp_json: dict, kind: str) -> Optional[int]:
    """Extract token count from response usage block."""
    usage = resp_json.get("usage", {})
    if kind == "prompt":
        return usage.get("prompt_tokens") or usage.get("input_tokens")
    return usage.get("completion_tokens") or usage.get("output_tokens")


def _detect_provider(target_url: str, model_id: Optional[str]) -> str:
    """
    Infer the API provider from the target URL or model name.
    Returns: "openai" | "anthropic" | "unknown"
    """
    url_lower = (target_url or "").lower()
    if "anthropic.com" in url_lower:
        return "anthropic"
    if "openai.com" in url_lower or "openrouter.ai" in url_lower:
        return "openai"
    # Fall back to model prefix
    model = (model_id or "").lower()
    if model.startswith("claude") or "anthropic/" in model:
        return "anthropic"
    if any(model.startswith(p) for p in ("gpt-", "o1", "o3", "openai/")):
        return "openai"
    return "unknown"


def _inject_openai_stream_usage(body_json: Optional[dict], body_bytes: bytes) -> bytes:
    """
    Inject stream_options.include_usage into an OpenAI streaming request so
    the final SSE chunk carries token counts. Returns modified body bytes.
    No-op if body is not JSON or stream_options already set.
    """
    if not body_json:
        return body_bytes
    if body_json.get("stream_options", {}).get("include_usage"):
        return body_bytes  # already requested
    import copy
    patched = copy.copy(body_json)
    patched["stream_options"] = {**body_json.get("stream_options", {}), "include_usage": True}
    return json.dumps(patched).encode()


def _generate_session_id() -> str:
    return f"s-{uuid.uuid4().hex[:8]}"


def _strip_agentcents_headers(headers: dict) -> dict:
    return {
        k: v for k, v in headers.items()
        if not k.lower().startswith("x-agentcents") and k.lower() != "host"
    }


def _safe_response_headers(headers) -> dict:
    passthrough = {
        "content-type", "x-request-id",
        "x-ratelimit-limit-requests", "x-ratelimit-remaining-requests", "retry-after"
    }
    return {k: v for k, v in headers.items() if k.lower() in passthrough}
