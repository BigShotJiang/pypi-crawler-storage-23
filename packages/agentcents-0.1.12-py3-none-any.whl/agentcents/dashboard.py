"""
agentcents dashboard.py
Mount this onto the proxy app to serve a live cost dashboard at /dashboard
"""

from fastapi import APIRouter
from fastapi.responses import HTMLResponse, JSONResponse
from agentcents.ledger import summary, recent
from agentcents.alerts import get_recent_alerts

router = APIRouter()


@router.get("/api/stats")
async def stats():
    return JSONResponse({
        "summary": summary(since_hours=24),
        "recent":  recent(n=50),
        "alerts":  get_recent_alerts(n=10),
    })


DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>agentcents</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@300;400;500;600&family=IBM+Plex+Sans:wght@300;400;500&display=swap" rel="stylesheet">
<style>
  :root {
    --bg:       #0a0a0a;
    --surface:  #111111;
    --border:   #1e1e1e;
    --accent:   #00ff88;
    --accent2:  #00aaff;
    --warn:     #ff6b35;
    --critical: #ff3366;
    --text:     #e0e0e0;
    --muted:    #555;
    --mono:     'IBM Plex Mono', monospace;
  }

  * { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    background: var(--bg);
    color: var(--text);
    font-family: var(--mono);
    font-size: 13px;
    min-height: 100vh;
  }

  body::before {
    content: '';
    position: fixed;
    inset: 0;
    background: repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.03) 2px, rgba(0,0,0,0.03) 4px);
    pointer-events: none;
    z-index: 100;
  }

  header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 18px 32px;
    border-bottom: 1px solid var(--border);
    background: var(--surface);
  }

  .logo { font-size: 16px; font-weight: 600; letter-spacing: 0.08em; color: var(--accent); }
  .logo span { color: var(--muted); font-weight: 300; }

  .status { display: flex; align-items: center; gap: 8px; font-size: 11px; color: var(--muted); }
  .dot {
    width: 7px; height: 7px; border-radius: 50%;
    background: var(--accent); box-shadow: 0 0 8px var(--accent);
    animation: pulse 2s infinite;
  }
  @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }

  main { padding: 28px 32px; max-width: 1400px; margin: 0 auto; }

  .kpis {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
    margin-bottom: 28px;
  }
  .kpi {
    background: var(--surface);
    border: 1px solid var(--border);
    padding: 20px 22px;
    position: relative;
    overflow: hidden;
  }
  .kpi::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 2px;
    background: var(--accent);
    opacity: 0.6;
  }
  .kpi.alert-active::before { background: var(--warn); opacity: 1; }
  .kpi-label { font-size: 10px; letter-spacing: 0.12em; text-transform: uppercase; color: var(--muted); margin-bottom: 10px; }
  .kpi-value { font-size: 28px; font-weight: 500; color: var(--accent); line-height: 1; }
  .kpi-value.warn { color: var(--warn); }
  .kpi-value.critical { color: var(--critical); }
  .kpi-sub { font-size: 10px; color: var(--muted); margin-top: 6px; }

  .section { margin-bottom: 32px; }
  .section-title {
    font-size: 10px; letter-spacing: 0.15em; text-transform: uppercase;
    color: var(--muted); margin-bottom: 12px; padding-bottom: 8px;
    border-bottom: 1px solid var(--border);
    display: flex; align-items: center; gap: 10px;
  }
  .alert-badge {
    background: var(--warn);
    color: #000;
    font-size: 9px;
    font-weight: 600;
    padding: 1px 6px;
    border-radius: 2px;
    letter-spacing: 0.05em;
  }
  .alert-badge.critical { background: var(--critical); color: #fff; }

  table { width: 100%; border-collapse: collapse; }
  th {
    text-align: left; font-size: 10px; letter-spacing: 0.1em;
    text-transform: uppercase; color: var(--muted);
    padding: 8px 12px; border-bottom: 1px solid var(--border); font-weight: 400;
  }
  th.right, td.right { text-align: right; }
  td { padding: 9px 12px; border-bottom: 1px solid #161616; color: var(--text); font-size: 12px; }
  tr:hover td { background: #141414; }

  .model-id { color: var(--accent2); }
  .tag-pill {
    display: inline-block; background: #1a1a1a; border: 1px solid var(--border);
    padding: 1px 7px; font-size: 10px; color: var(--muted); border-radius: 2px;
  }
  .cost-val { color: var(--accent); }
  .error-val { color: var(--warn); }
  .status-200 { color: var(--accent); }
  .status-4xx { color: var(--warn); }
  .status-5xx { color: var(--critical); }
  .ts { color: var(--muted); font-size: 11px; }

  /* Alert rows */
  .alert-warn { color: var(--warn); }
  .alert-critical { color: var(--critical); }
  .alert-row td { border-left: 2px solid var(--warn); }
  .alert-row.critical td { border-left-color: var(--critical); }

  .bar-wrap { display: flex; align-items: center; gap: 8px; }
  .bar { height: 4px; background: var(--accent); opacity: 0.7; min-width: 2px; transition: width 0.4s ease; }

  .empty { padding: 40px; text-align: center; color: var(--muted); font-size: 12px; letter-spacing: 0.05em; }
  .refresh-info { font-size: 10px; color: var(--muted); text-align: right; margin-top: -20px; margin-bottom: 16px; }
  #countdown { color: var(--accent); }
</style>
</head>
<body>

<header>
  <div class="logo">agent<span>cents</span></div>
  <div class="status">
    <div class="dot"></div>
    <span id="last-updated">connecting...</span>
  </div>
</header>

<main>
  <div class="kpis">
    <div class="kpi" id="kpi-cost-card">
      <div class="kpi-label">Total Cost (24h)</div>
      <div class="kpi-value" id="kpi-cost">—</div>
      <div class="kpi-sub">USD</div>
    </div>
    <div class="kpi">
      <div class="kpi-label">API Calls (24h)</div>
      <div class="kpi-value" id="kpi-calls">—</div>
      <div class="kpi-sub">requests</div>
    </div>
    <div class="kpi">
      <div class="kpi-label">Tokens In</div>
      <div class="kpi-value" id="kpi-in">—</div>
      <div class="kpi-sub">prompt tokens</div>
    </div>
    <div class="kpi">
      <div class="kpi-label">Tokens Out</div>
      <div class="kpi-value" id="kpi-out">—</div>
      <div class="kpi-sub">completion tokens</div>
    </div>
  </div>

  <div class="refresh-info">auto-refresh in <span id="countdown">5</span>s</div>

  <!-- Alerts section (hidden when empty) -->
  <div class="section" id="alerts-section" style="display:none">
    <div class="section-title">
      Budget Alerts
      <span class="alert-badge" id="alert-badge">0</span>
    </div>
    <table>
      <thead>
        <tr>
          <th>Time</th>
          <th>Level</th>
          <th>Scope</th>
          <th>Message</th>
          <th class="right">Spent</th>
          <th class="right">Budget</th>
        </tr>
      </thead>
      <tbody id="alerts-body"></tbody>
    </table>
  </div>

  <div class="section">
    <div class="section-title">Cost by Model — last 24h</div>
    <table>
      <thead>
        <tr>
          <th>Model</th><th>Tag</th>
          <th class="right">Calls</th><th class="right">In Tokens</th>
          <th class="right">Out Tokens</th><th class="right">Cost $</th>
          <th class="right">Avg Lat</th><th class="right">Errors</th>
          <th style="width:120px">Share</th>
        </tr>
      </thead>
      <tbody id="summary-body">
        <tr><td colspan="9" class="empty">Loading...</td></tr>
      </tbody>
    </table>
  </div>

  <div class="section">
    <div class="section-title">Recent Calls</div>
    <table>
      <thead>
        <tr>
          <th>Time</th><th>Model</th><th>Tag</th>
          <th class="right">In</th><th class="right">Out</th>
          <th class="right">Cost $</th><th class="right">Latency</th><th class="right">Status</th>
        </tr>
      </thead>
      <tbody id="recent-body">
        <tr><td colspan="8" class="empty">Loading...</td></tr>
      </tbody>
    </table>
  </div>
</main>

<script>
let countdown = 5;

function fmt(n, d=2)   { return n == null ? '—' : Number(n).toFixed(d); }
function fmtCost(n)    { return (n == null || n === 0) ? '$0.000000' : '$' + Number(n).toFixed(6); }
function fmtInt(n)     { return n == null ? '—' : Number(n).toLocaleString(); }
function fmtTs(ts) {
  const d = new Date(ts * 1000);
  return d.toLocaleTimeString('en-US', {hour12:false}) + ' ' +
         d.toLocaleDateString('en-US', {month:'2-digit', day:'2-digit'});
}
function statusClass(s) {
  if (!s) return '';
  if (s < 300) return 'status-200';
  if (s < 500) return 'status-4xx';
  return 'status-5xx';
}

async function fetchAndRender() {
  try {
    const r    = await fetch('/api/stats');
    const data = await r.json();
    const summary = data.summary || [];
    const recent  = data.recent  || [];
    const alerts  = data.alerts  || [];

    // KPIs
    const totalCost  = summary.reduce((a,r) => a + (r.total_cost  || 0), 0);
    const totalCalls = summary.reduce((a,r) => a + (r.calls       || 0), 0);
    const totalIn    = summary.reduce((a,r) => a + (r.total_prompt || 0), 0);
    const totalOut   = summary.reduce((a,r) => a + (r.total_completion || 0), 0);

    const hasCritical = alerts.some(a => a.level === 'critical');
    const hasWarn     = alerts.some(a => a.level === 'warn');
    const costEl      = document.getElementById('kpi-cost');
    const costCard    = document.getElementById('kpi-cost-card');

    costEl.textContent = fmtCost(totalCost);
    costEl.className   = 'kpi-value' + (hasCritical ? ' critical' : hasWarn ? ' warn' : '');
    costCard.className = 'kpi' + (alerts.length > 0 ? ' alert-active' : '');

    document.getElementById('kpi-calls').textContent = totalCalls;
    document.getElementById('kpi-in').textContent    = fmtInt(totalIn);
    document.getElementById('kpi-out').textContent   = fmtInt(totalOut);

    // Alerts section
    const alertsSection = document.getElementById('alerts-section');
    const alertsBadge   = document.getElementById('alert-badge');
    const alertsBody    = document.getElementById('alerts-body');

    if (alerts.length > 0) {
      alertsSection.style.display = '';
      alertsBadge.textContent = alerts.length;
      alertsBadge.className   = 'alert-badge' + (hasCritical ? ' critical' : '');
      alertsBody.innerHTML = alerts.map(a => `
        <tr class="alert-row ${a.level}">
          <td class="ts">${fmtTs(a.ts)}</td>
          <td class="alert-${a.level}">${a.level.toUpperCase()}</td>
          <td>${a.scope}</td>
          <td>${a.message}</td>
          <td class="right alert-${a.level}">$${Number(a.spent).toFixed(6)}</td>
          <td class="right">$${Number(a.budget).toFixed(4)}</td>
        </tr>`).join('');
    } else {
      alertsSection.style.display = 'none';
    }

    // Summary table
    const maxCost = Math.max(...summary.map(r => r.total_cost || 0), 0.000001);
    const sb = document.getElementById('summary-body');
    sb.innerHTML = summary.length === 0
      ? '<tr><td colspan="9" class="empty">No calls yet — route an API call through the proxy</td></tr>'
      : summary.map(r => {
          const pct = Math.round(((r.total_cost || 0) / maxCost) * 100);
          return `<tr>
            <td class="model-id">${r.model_id || 'unknown'}</td>
            <td><span class="tag-pill">${r.tag || 'default'}</span></td>
            <td class="right">${r.calls}</td>
            <td class="right">${fmtInt(r.total_prompt)}</td>
            <td class="right">${fmtInt(r.total_completion)}</td>
            <td class="right cost-val">${fmtCost(r.total_cost)}</td>
            <td class="right">${fmt(r.avg_latency)}s</td>
            <td class="right ${r.errors > 0 ? 'error-val' : ''}">${r.errors || 0}</td>
            <td><div class="bar-wrap"><div class="bar" style="width:${pct}%"></div><span style="font-size:10px;color:var(--muted)">${pct}%</span></div></td>
          </tr>`;
        }).join('');

    // Recent table
    const rb = document.getElementById('recent-body');
    rb.innerHTML = recent.length === 0
      ? '<tr><td colspan="8" class="empty">No calls yet</td></tr>'
      : recent.map(r => `<tr>
          <td class="ts">${fmtTs(r.ts)}</td>
          <td class="model-id">${r.model_id || 'unknown'}</td>
          <td><span class="tag-pill">${r.tag || 'default'}</span></td>
          <td class="right">${fmtInt(r.prompt_tokens)}</td>
          <td class="right">${fmtInt(r.completion_tokens)}</td>
          <td class="right cost-val">${fmtCost(r.cost_usd)}</td>
          <td class="right">${r.elapsed_s ? fmt(r.elapsed_s) + 's' : '—'}</td>
          <td class="right ${statusClass(r.status)}">${r.status || '—'}</td>
        </tr>`).join('');

    document.getElementById('last-updated').textContent =
      'updated ' + new Date().toLocaleTimeString('en-US', {hour12:false});

  } catch(e) {
    document.getElementById('last-updated').textContent = 'connection error';
  }
}

setInterval(() => {
  countdown--;
  document.getElementById('countdown').textContent = countdown;
  if (countdown <= 0) { countdown = 5; fetchAndRender(); }
}, 1000);

fetchAndRender();
</script>
</body>
</html>
"""

@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard():
    return HTMLResponse(content=DASHBOARD_HTML)
