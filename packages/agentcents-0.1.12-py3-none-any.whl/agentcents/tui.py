"""
agentcents tui.py — Phase 6
Textual TUI dashboard. Launch with: agentcents dashboard

Requires: pip install textual
"""

from textual.app import App, ComposeResult
from textual.widgets import Header, Footer, DataTable, Label, Static
from textual.containers import Horizontal, Vertical, ScrollableContainer
from textual.reactive import reactive
from textual import work
import time
import datetime


REFRESH_INTERVAL = 3  # seconds


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def fmt_cost(v):
    if v is None: return "—"
    return f"${v:.6f}"

def fmt_int(v):
    if v is None: return "—"
    return f"{int(v):,}"

def fmt_ts(ts):
    if not ts: return "—"
    return datetime.datetime.fromtimestamp(ts).strftime("%H:%M:%S")

def fmt_dur(seconds):
    if not seconds: return "—"
    h, r = divmod(int(seconds), 3600)
    m, s = divmod(r, 60)
    if h: return f"{h}h {m}m"
    if m: return f"{m}m {s}s"
    return f"{s}s"


# ---------------------------------------------------------------------------
# Widgets
# ---------------------------------------------------------------------------

class KpiBar(Static):
    """Row of KPI metrics at the top."""

    DEFAULT_CSS = """
    KpiBar {
        height: 5;
        background: $surface;
        border: solid $primary;
        padding: 1 2;
        margin-bottom: 1;
    }
    """

    def compose(self) -> ComposeResult:
        yield Horizontal(
            Static("", id="kpi-cost",  classes="kpi"),
            Static("", id="kpi-calls", classes="kpi"),
            Static("", id="kpi-in",    classes="kpi"),
            Static("", id="kpi-out",   classes="kpi"),
            Static("", id="kpi-30d",   classes="kpi"),
        )

    def update_kpis(self, total_cost, calls, total_in, total_out, spend_30d, budget_30d):
        self.query_one("#kpi-cost").update(
            f"[bold green]COST 24H[/]\n[bold]{fmt_cost(total_cost)}[/]"
        )
        self.query_one("#kpi-calls").update(
            f"[bold cyan]CALLS 24H[/]\n[bold]{calls}[/]"
        )
        self.query_one("#kpi-in").update(
            f"[bold cyan]TOKENS IN[/]\n[bold]{fmt_int(total_in)}[/]"
        )
        self.query_one("#kpi-out").update(
            f"[bold cyan]TOKENS OUT[/]\n[bold]{fmt_int(total_out)}[/]"
        )
        budget_str = f"/ ${budget_30d:.2f}" if budget_30d else ""
        color = "red" if (budget_30d and spend_30d >= budget_30d) else "green"
        self.query_one("#kpi-30d").update(
            f"[bold {color}]SPEND 30D[/]\n[bold]{fmt_cost(spend_30d)} {budget_str}[/]"
        )


# ---------------------------------------------------------------------------
# Main App
# ---------------------------------------------------------------------------

class AgentCentsDashboard(App):
    """agentcents TUI Dashboard"""

    CSS = """
    Screen {
        background: #0a0a0a;
    }
    .kpi {
        width: 1fr;
        height: 3;
        content-align: center middle;
        background: #111;
        border: solid #1e1e1e;
        margin: 0 1;
        padding: 0 1;
    }
    .section-label {
        color: #555;
        text-style: bold;
        padding: 1 0 0 0;
        height: 2;
    }
    DataTable {
        height: auto;
        max-height: 20;
        background: #0a0a0a;
        border: solid #1e1e1e;
        margin-bottom: 1;
    }
    #status-bar {
        height: 1;
        color: #555;
        padding: 0 1;
    }
    """

    BINDINGS = [
        ("q", "quit",    "Quit"),
        ("r", "refresh", "Refresh"),
    ]

    TITLE = "agentcents"

    def compose(self) -> ComposeResult:
        yield Header()
        yield KpiBar(id="kpi-bar")
        yield Label("● AGENTS (24H)", classes="section-label")
        yield DataTable(id="agents-table", cursor_type="row")
        yield Label("● COST BY MODEL (24H)", classes="section-label")
        yield DataTable(id="model-table",  cursor_type="row")
        yield Label("● RECENT CALLS", classes="section-label")
        yield DataTable(id="recent-table", cursor_type="row")
        yield Static("", id="status-bar")
        yield Footer()

    def on_mount(self):
        # Setup agents table
        at = self.query_one("#agents-table", DataTable)
        at.add_columns("Session", "Tag", "Calls", "In Tok", "Out Tok", "Cost $", "Avg Lat", "Active", "Errors")

        # Setup model table
        mt = self.query_one("#model-table", DataTable)
        mt.add_columns("Model", "Tag", "Calls", "In Tok", "Out Tok", "Cost $", "Avg Lat", "Errors")

        # Setup recent table
        rt = self.query_one("#recent-table", DataTable)
        rt.add_columns("Time", "Session", "Model", "Tag", "In", "Out", "Cost $", "Lat", "St")

        self.refresh_data()
        self.set_interval(REFRESH_INTERVAL, self.refresh_data)

    def refresh_data(self):
        try:
            from agentcents.ledger import summary, recent, agent_summary, rolling_spend
            from agentcents.config import load as load_config

            cfg        = load_config()
            budget_30d = cfg.get("budgets", {}).get("monthly")
            spend_30d  = rolling_spend(days=30)
            agents     = agent_summary(since_hours=24)
            models     = summary(since_hours=24)
            calls      = recent(n=30)

            total_cost  = sum(r.get("total_cost") or 0 for r in models)
            total_calls = sum(r.get("calls")      or 0 for r in models)
            total_in    = sum(r.get("total_prompt") or 0 for r in models)
            total_out   = sum(r.get("total_completion") or 0 for r in models)

            # KPIs
            self.query_one("#kpi-bar", KpiBar).update_kpis(
                total_cost, total_calls, total_in, total_out, spend_30d, budget_30d
            )

            # Agents table
            at = self.query_one("#agents-table", DataTable)
            at.clear()
            for r in agents:
                sid     = (r["session_id"] or "default")[:20]
                tag     = (r["tag"]        or "")[:12]
                dur     = fmt_dur(time.time() - (r["first_call"] or time.time()))
                at.add_row(
                    sid,
                    tag,
                    str(r["calls"]           or 0),
                    fmt_int(r["total_prompt"]),
                    fmt_int(r["total_completion"]),
                    fmt_cost(r["total_cost"]),
                    f"{(r['avg_latency'] or 0):.2f}s",
                    dur,
                    str(r["errors"] or 0),
                )

            # Model table
            mt = self.query_one("#model-table", DataTable)
            mt.clear()
            for r in models:
                mt.add_row(
                    (r["model_id"] or "unknown")[:40],
                    (r["tag"]      or "")[:12],
                    str(r["calls"] or 0),
                    fmt_int(r["total_prompt"]),
                    fmt_int(r["total_completion"]),
                    fmt_cost(r["total_cost"]),
                    f"{(r['avg_latency'] or 0):.2f}s",
                    str(r["errors"] or 0),
                )

            # Recent calls
            rt = self.query_one("#recent-table", DataTable)
            rt.clear()
            for r in calls:
                rt.add_row(
                    fmt_ts(r["ts"]),
                    (r["session_id"] or "default")[:16],
                    (r["model_id"]   or "unknown")[:32],
                    (r["tag"]        or "")[:10],
                    str(r["prompt_tokens"]     or "—"),
                    str(r["completion_tokens"] or "—"),
                    fmt_cost(r["cost_usd"]),
                    f"{(r['elapsed_s'] or 0):.2f}s",
                    str(r["status"] or "—"),
                )

            now = datetime.datetime.now().strftime("%H:%M:%S")
            self.query_one("#status-bar").update(
                f" refreshed {now} · {REFRESH_INTERVAL}s interval · [q] quit"
            )

        except Exception as e:
            self.query_one("#status-bar").update(f" error: {e}")

    def action_refresh(self):
        self.refresh_data()


def launch():
    AgentCentsDashboard().run()
