"""mnemo.memory: Context and memory management for AI agents."""

from __future__ import annotations
