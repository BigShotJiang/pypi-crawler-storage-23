"""mnemo connectors module: HTTP fetch and REST API tools."""

from __future__ import annotations
