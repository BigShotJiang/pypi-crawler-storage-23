"""mnemo hooks: Claude Code hook scripts."""
