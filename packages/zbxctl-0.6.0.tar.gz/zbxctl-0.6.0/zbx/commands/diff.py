"""zbx diff — compare YAML config against live Zabbix state."""

from __future__ import annotations

from pathlib import Path

import typer

from zbx import formatter
from zbx.config_loader import ConfigLoader
from zbx.deployer import Deployer
from zbx.zabbix_client import ZabbixAPIError, ZabbixClient

app = typer.Typer()


def diff_cmd(
    path: Path = typer.Argument(..., help="Path to a YAML file or directory of configs."),
    env_file: Path = typer.Option(
        Path(".env"), "--env-file", "-e", help="Path to .env file with Zabbix credentials."
    ),
) -> None:
    """Show differences between local config and current Zabbix state."""
    loader = ConfigLoader()

    try:
        settings = loader.load_settings(env_file)
        templates, hosts = loader.load_all(path)
    except (FileNotFoundError, ValueError, EnvironmentError) as exc:
        formatter.print_error(str(exc))
        raise typer.Exit(1) from exc

    try:
        with ZabbixClient(settings) as client:
            deployer = Deployer(client, dry_run=True)
            template_diffs = [deployer.plan(t) for t in templates]
            host_diffs = [deployer.plan_host(h) for h in hosts]
    except ZabbixAPIError as exc:
        formatter.print_error(f"Zabbix API: {exc}")
        raise typer.Exit(1) from exc

    formatter.print_diff(template_diffs, title="Diff")
    formatter.print_host_diff(host_diffs, title="Diff")
