from italy_opendata_mcp.server import main

main()
