from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="agnipod",
    version="0.1.4",
    author="AgniPod",
    author_email="support@agnipod.com",
    description="Official Python SDK for the AgniPod LLM API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://agnipod.com",
    project_urls={
        "Documentation": "https://docs.agnipod.com",
        "Source": "https://github.com/agnipod/agnipod-python",
        "Issues": "https://github.com/agnipod/agnipod-python/issues",
    },
    packages=find_packages(exclude=["tests", "tests.*"]),
    package_data={"agnipod": ["py.typed"]},
    python_requires=">=3.9",
    install_requires=[
        "requests>=2.28.0",
    ],
    entry_points={
        "console_scripts": [
            "agnipod=agnipod._cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Typing :: Typed",
    ],
    keywords="agnipod llm ai inference api sdk gpu",
)