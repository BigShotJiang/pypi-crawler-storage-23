"""
AgniPod SDK — Models
======================

Usage::

    from agnipod import AgniPod

    client = AgniPod()

    # List all models
    models = client.models.list()
    for m in models:
        print(m.id)

    # Get a specific model
    model = client.models.get("qwen3:8b")
    print(model.id, model.owned_by)
"""

from __future__ import annotations

from ._client import HttpClient
from ._types import Model, ModelList


class Models:
    """Namespace for ``/models`` operations."""

    def __init__(self, client: HttpClient):
        self._client = client

    def list(self) -> ModelList:
        """List all available models.

        Returns
        -------
        ModelList
            Iterable of ``Model`` objects.
        """
        data = self._client.get("/models")
        return ModelList(data)

    def get(self, model_id: str) -> Model:
        """Retrieve a specific model by name.

        Parameters
        ----------
        model_id : str
            The model name / identifier.

        Returns
        -------
        Model
        """
        data = self._client.get(f"/models/{model_id}")
        return Model(data)
