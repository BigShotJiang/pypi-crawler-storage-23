"""
AgniPod SDK — Billing & Wallet
=================================

Usage::

    from agnipod import AgniPod

    client = AgniPod()

    # Check balance
    balance = client.billing.balance()
    print(balance)  # $1.2345 USD

    # Get full wallet
    wallet = client.billing.wallet()

    # Transaction history
    txns = client.billing.transactions(limit=10)
    for t in txns:
        print(t.transaction_type, t.amount)

    # Usage summary
    usage = client.billing.usage(days=7)
"""

from __future__ import annotations
from typing import Optional

from ._client import HttpClient
from ._types import Balance, Wallet, TransactionList, UsageSummary


class Billing:
    """Namespace for wallet / billing operations."""

    _PREFIX = "/api/compute/llm/wallet"

    def __init__(self, client: HttpClient):
        self._client = client

    def wallet(self) -> Wallet:
        """Get full wallet details.

        Returns
        -------
        Wallet
        """
        data = self._client.get(self._PREFIX)
        wallet_data = data.get("wallet", data)
        return Wallet(wallet_data)

    def balance(self) -> Balance:
        """Get current balance (quick endpoint).

        Returns
        -------
        Balance
            Has ``.balance`` (float), ``.currency`` (str).
        """
        data = self._client.get(f"{self._PREFIX}/balance")
        return Balance(data)

    def transactions(
        self,
        *,
        page: int = 1,
        limit: int = 20,
        transaction_type: Optional[str] = None,
    ) -> TransactionList:
        """Get transaction history.

        Parameters
        ----------
        page : int
        limit : int
        transaction_type : str, optional
            Filter: ``topup``, ``deduction``, ``refund``, ``adjustment``, ``credit``.

        Returns
        -------
        TransactionList
            Iterable of ``Transaction`` objects.
        """
        data = self._client.get(f"{self._PREFIX}/transactions", params={
            "page": page,
            "limit": limit,
            "transaction_type": transaction_type,
        })
        return TransactionList(data)

    def usage(self, *, days: int = 30) -> UsageSummary:
        """Get aggregated usage summary.

        Parameters
        ----------
        days : int
            Look-back period (1–90, default 30).

        Returns
        -------
        UsageSummary
        """
        data = self._client.get(f"{self._PREFIX}/usage", params={"days": days})
        usage_data = data.get("usage", data)
        return UsageSummary(usage_data)
