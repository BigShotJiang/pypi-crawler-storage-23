import asyncio
import logging
import sys
import tempfile
from asyncio import create_subprocess_exec, subprocess
from collections.abc import Iterable, Mapping, MutableMapping
from pathlib import Path
from typing import Any

from .logging import BraceStyleAdapter

logger = BraceStyleAdapter(logging.getLogger())


async def write_file(
    variables: Mapping[str, Any],
    filename: str,
    body: Iterable[str],
    mode: str = "644",
    append: bool = False,
) -> None:
    filename = filename.format_map(variables)
    open_mode = "w" + ("+" if append else "")
    filepath = Path(filename)

    def _write() -> None:
        with filepath.open(open_mode) as fw:
            fw.writelines(line.format_map(variables) + "\n" for line in body)
        filepath.chmod(int(mode, 8))

    await asyncio.to_thread(_write)


async def write_tempfile(
    variables: Mapping[str, Any],
    body: Iterable[str],
    mode: str = "644",
) -> str | None:
    def _write() -> str:
        with tempfile.NamedTemporaryFile(
            "w", encoding="utf-8", suffix=".py", delete=False
        ) as config:
            for line in body:
                config.write(line.format_map(variables))
        Path(config.name).chmod(int(mode, 8))
        return config.name

    return await asyncio.to_thread(_write)


async def run_command(
    variables: Mapping[str, Any],
    command: Iterable[str],
    echo: bool = False,
) -> MutableMapping[str, str] | None:
    proc = await create_subprocess_exec(
        *(str(piece).format_map(variables) for piece in command),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    out, err = await proc.communicate()
    if echo:
        sys.stdout.buffer.write(out)
        sys.stdout.flush()
        sys.stderr.buffer.write(err)
        sys.stderr.flush()
    return {"out": out.decode("utf8"), "err": err.decode("utf8")}


async def mkdir(
    variables: Mapping[str, Any],
    path: str,
) -> None:
    Path(path.format_map(variables)).mkdir(parents=True, exist_ok=True)


async def log(
    variables: Mapping[str, Any],
    message: str,
    debug: bool = False,
) -> None:
    message = message.format_map(variables).replace("{", "{{").replace("}", "}}")
    if debug:
        logger.debug(message)
    else:
        logger.info(message)
