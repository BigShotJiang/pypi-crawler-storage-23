Clear all ACE learned strategies.

IMPORTANT: Ask the user to confirm they want to delete ALL learned strategies before proceeding.

If confirmed, run:
```bash
ace-learn clear --confirm
```

This will:
- Reset the skillbook to empty
- Update CLAUDE.md to remove all learned strategies
- ACE will start fresh with no prior learnings

This action cannot be undone.
