"""Allow running with `python -m mcp_gitlab`."""

from mcp_gitlab import main

main()
