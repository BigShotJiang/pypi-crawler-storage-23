"""Performance benchmark tests for Confiture Rust extensions."""
