## Summary

<!-- Brief description of the changes -->

## Checklist

- [ ] Tests pass (`pytest tests/ -v`)
- [ ] Code formatted (`ruff format src/ tests/`)
- [ ] Lint clean (`ruff check src/ tests/`)
- [ ] CHANGELOG.md updated (if user-facing change)
