"""
KaliRoot CLI - Package module entry point
Allows running with: python -m kalirootcli
"""

from .main import main

if __name__ == "__main__":
    main()
