# TikHub 小红书 API - 极简参考

**学习日期：** 2026-03-04  
**主人交代：** 只需要记录给的信息，不堆叠

---

## 两个核心接口

### 1. 获取笔记信息 V2
```
GET /api/v1/xiaohongshu/app/get_note_info_v2
```
**用途：** 通过笔记 ID 或分享链接获取单篇笔记详情  
**参数：** `note_id` 或 `share_text`（二选一）  
**特点：** 能拿到曝光量、阅读量（其他接口没有）

### 2. 搜索笔记
```
GET /api/v1/xiaohongshu/app_v2/search_notes
```
**用途：** 关键词搜索笔记  
**参数：** `keyword`（必需）+ 筛选条件  
**关键：** 翻页需要保存 `search_id` 和 `search_session_id`

---

## Python SDK

```python
from tikhub_xiaohongshu import TikHubClient

client = TikHubClient(api_key="your_api_key")

# 获取笔记
note = client.get_note_info(note_id="665f95200000000006005624")

# 搜索笔记（单页）
result = client.search_notes(keyword="美食推荐", page=1)

# 搜索笔记（自动翻页）
notes = client.search_notes_all("美食推荐", max_pages=5)
```

---

## 认证

```
Authorization: Bearer YOUR_API_KEY
```

---

## 文档链接

- 获取笔记信息 V2: https://docs.tikhub.io/334614201e0
- 搜索笔记：https://docs.tikhub.io/420136398e0
- TikHub 官网：https://tikhub.io

---

_简单直接，不堆叠。_
