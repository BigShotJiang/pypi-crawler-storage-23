## Summary

Closes #

## Changes

-

## Testing

- [ ] Unit tests added/updated
- [ ] `uv run pytest` passes
- [ ] `uv run ruff check .` passes
- [ ] `uv run pyright` passes
