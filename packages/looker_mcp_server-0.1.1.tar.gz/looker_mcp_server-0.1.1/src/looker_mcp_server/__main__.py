"""Allow ``python -m looker_mcp_server``."""

from .main import cli

cli()
