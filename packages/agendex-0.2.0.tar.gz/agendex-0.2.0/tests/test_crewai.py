"""Tests for CrewAI integration."""
import pytest
from unittest.mock import Mock, patch

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))


# Skip if CrewAI not installed
pytest.importorskip("crewai")


class TestGovernedCrew:
    """Test GovernedCrew functionality."""
    
    def test_import(self):
        """Test that GovernedCrew can be imported."""
        from agendex.integrations.crewai import GovernedCrew
        assert GovernedCrew is not None
    
    def test_crewai_available_flag(self):
        """Test that CREWAI_AVAILABLE is True."""
        from agendex.integrations.crewai import CREWAI_AVAILABLE
        assert CREWAI_AVAILABLE is True
    
    def test_tool_wrapping(self):
        """Test that CrewAI tools are wrapped for governance."""
        from agendex.integrations.crewai import _wrap_crewai_tool
        from agendex import AgendexClient
        from crewai.tools import BaseTool
        from pydantic import BaseModel, Field
        
        class TestInput(BaseModel):
            value: str = Field(description="Test value")
        
        class TestTool(BaseTool):
            name: str = "test_tool"
            description: str = "Test tool"
            args_schema = TestInput
            
            def _run(self, value: str) -> str:
                return f"Result: {value}"
        
        tool = TestTool()
        
        # Create mock client
        mock_client = Mock(spec=AgendexClient)
        mock_client.invoke = Mock(return_value={"_agendex": "shadow"})
        
        # Wrap the tool
        wrapped = _wrap_crewai_tool(
            tool=tool,
            agendex=mock_client,
            task="test",
            agent_role="Test Agent",
        )
        
        # Tool should still work
        result = wrapped._run("hello")
        
        # Client should have been called
        mock_client.invoke.assert_called_once()


