"""
Agendex SDK Configuration

Action name configuration and defaults registry.
Allows customizing action names at per-client or global level.

Priority: per-client override → global config → hardcoded default
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional


# Default action names (matching current hardcoded values for backward compatibility)
DEFAULT_ACTIONS: Dict[str, str] = {
    "db.query": "db.query.run",
    "s3.get": "s3.reports.fetch",
    "s3.put": "s3.reports.put",
    "s3.list": "s3.reports.list",
    "http.request": "http.service.call",
    "crm.lookup": "crm.lookup",
    "crm.update": "crm.update",
}


@dataclass
class ActionConfig:
    """
    Configuration for action name mapping.

    Example:
        config = ActionConfig()
        config.set_action("db.query", "database.execute")
        action = config.get_action("db.query")  # "database.execute"
    """

    actions: Dict[str, str] = field(default_factory=lambda: DEFAULT_ACTIONS.copy())

    def get_action(self, key: str, default: Optional[str] = None) -> str:
        """
        Get action name for a key.

        Args:
            key: Action key (e.g., "db.query", "s3.get")
            default: Fallback if key not found

        Returns:
            Action name string
        """
        return self.actions.get(key, default or DEFAULT_ACTIONS.get(key, key))

    def set_action(self, key: str, action: str) -> None:
        """
        Set a custom action name.

        Args:
            key: Action key (e.g., "db.query")
            action: Action name to use (e.g., "database.execute")
        """
        self.actions[key] = action


# Global configuration singleton
_global_config: Optional[ActionConfig] = None


def get_global_config() -> ActionConfig:
    """Get or create global action configuration."""
    global _global_config
    if _global_config is None:
        _global_config = ActionConfig()
    return _global_config


def configure_actions(**kwargs: str) -> None:
    """
    Configure global action name mappings.

    Example:
        configure_actions(
            db_query="database.execute",
            http_request="api.call",
        )

    Note: Use underscores in kwargs, they map to dot notation:
        db_query → db.query
        s3_get → s3.get
    """
    config = get_global_config()
    for key, action in kwargs.items():
        # Convert underscore to dot notation (db_query → db.query)
        normalized_key = key.replace("_", ".")
        config.set_action(normalized_key, action)


def reset_config() -> None:
    """Reset global configuration to defaults. Useful for testing."""
    global _global_config
    _global_config = None
