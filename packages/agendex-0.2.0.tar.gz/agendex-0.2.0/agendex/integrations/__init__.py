"""
Agendex Framework Integrations

Provides drop-in replacements for popular agent frameworks:
- LangChain: GovernedAgentExecutor
- CrewAI: GovernedCrew

Each integration automatically:
1. Wraps all tools to route through Agendex governance
2. Captures agent reasoning for audit
3. Handles DeniedError and PendingApprovalError appropriately
"""

__all__ = [
    "GovernedAgentExecutor",
    "GovernedCrew",
    "AgentXGovernanceConfig",
    "AgentXGovernanceHooks",
    "GovernedAgentBuilder",
    "enable_agentx_governance",
    "install_agentx_runtime_shims",
]

# Lazy imports to avoid requiring all dependencies
def __getattr__(name: str):
    if name == "GovernedAgentExecutor":
        from .langchain import GovernedAgentExecutor
        return GovernedAgentExecutor
    
    if name == "GovernedCrew":
        from .crewai import GovernedCrew
        return GovernedCrew

    if name in {
        "AgentXGovernanceConfig",
        "AgentXGovernanceHooks",
        "GovernedAgentBuilder",
        "enable_agentx_governance",
        "install_agentx_runtime_shims",
    }:
        from .agentx import (
            AgentXGovernanceConfig,
            AgentXGovernanceHooks,
            GovernedAgentBuilder,
            enable_agentx_governance,
            install_agentx_runtime_shims,
        )
        return {
            "AgentXGovernanceConfig": AgentXGovernanceConfig,
            "AgentXGovernanceHooks": AgentXGovernanceHooks,
            "GovernedAgentBuilder": GovernedAgentBuilder,
            "enable_agentx_governance": enable_agentx_governance,
            "install_agentx_runtime_shims": install_agentx_runtime_shims,
        }[name]
    
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

