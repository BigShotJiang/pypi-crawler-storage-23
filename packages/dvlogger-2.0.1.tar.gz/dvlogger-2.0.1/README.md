# dvlogger (v2.0.1)

## Requirements

- colorama

## TODO

- AWS CloudWatch support - refer to `watchtower`
- Take list of multiple levels in `file_config.level` to create multiple files
- CSV support in `file_config.file_mode`
- Asyncio patch - add support for `uvloop` (patch `asyncio.DefaultEventLoopPolicy.new_event_loop`) and other implementations

## Usage

```
import logging
import dvlogger

dvlogger.setup(level=logging.DEBUG, capture_warnings=True, exception_hook=True, use_tg_handler=False, use_file_handler=False, file_config=None, tg_config=None)

dvlogger.tg_send_file(FILE_PATH, 'file_name')
dvlogger.tg_send_file(FILE_OBJECT, 'file_name', 'caption', is_error=True)
```

```
file_config
    name [os.path.basename(sys.argv[0]).strip(), dvlogger]
    kind [BASIC] # ROTATING, TIMED, BASIC
    level [logging.DEBUG]
    file_mode [text]

    rotating_size [1e6]
    rotating_count [3]

    timed_when ['midnight']
    timed_interval [1]
    timed_count [7]

    basic_date_format ['%Y_%m_%d_%H_%M%_S_%f']
    basic_put_date [False]
    basic_append [True]

tg_config
    level [logging.ERROR]
    level_bypass_prefix ["TG - "]
    message_skip_prefix ["NTG - "]
    bot_key
    chat_id
    thread_id [None]
    error_chat_id [None]
    error_thread_id [None]
    flush_interval [5000] # ms
```
