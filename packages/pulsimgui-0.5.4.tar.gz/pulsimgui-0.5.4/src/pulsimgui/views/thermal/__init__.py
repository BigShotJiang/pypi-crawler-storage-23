"""Thermal viewer widgets."""

from pulsimgui.views.thermal.thermal_viewer import ThermalViewerWidget

__all__ = ["ThermalViewerWidget"]
