"""Presenters (business logic) for PulsimGui."""
