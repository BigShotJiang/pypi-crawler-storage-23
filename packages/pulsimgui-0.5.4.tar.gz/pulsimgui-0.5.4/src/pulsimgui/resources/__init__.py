"""Application resources."""
