"""PulsimGui - Cross-platform GUI for Pulsim power electronics simulator."""

__version__ = "0.5.3"
__author__ = "Luiz Gili"
