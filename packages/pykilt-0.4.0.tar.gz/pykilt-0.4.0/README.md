# KILT – Kinetic Inverse-Laplace Toolbox

A Python package for performing 1D and 2D MEM (Maximum Entropy Method) inverse Laplace transforms for fluorescence lifetime analysis.

## Installation
```bash
pip install pyKilt