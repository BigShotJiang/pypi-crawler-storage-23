"""Basic tests for holoviz_utils package."""

import holoviz_utils


def test_version():
    """Test that version is defined."""
    assert hasattr(holoviz_utils, "__version__")
    assert isinstance(holoviz_utils.__version__, str)
