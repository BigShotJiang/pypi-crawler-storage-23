"""Tests for graphql"""
