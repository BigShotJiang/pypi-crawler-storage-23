"""Tests for graphql.type"""
