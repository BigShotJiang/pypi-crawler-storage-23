import{H as i}from"./index.Khxe51PN.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};
