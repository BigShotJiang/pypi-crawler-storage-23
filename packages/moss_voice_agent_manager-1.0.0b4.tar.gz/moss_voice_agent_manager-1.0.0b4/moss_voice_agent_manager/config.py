"""Configuration management for Moss Agent."""

import os
import httpx
from pydantic import BaseModel


class MossConfig(BaseModel):
    """Moss Agent configuration."""

    agent_id: str
    llm_model: str
    stt_model: str
    stt_language: str = "en"
    tts_model: str
    tts_voice: str
    min_endpointing_delay: float
    max_endpointing_delay: float
    preemptive_generation: bool
    platform_ws_url: str
    platform_api_key: str
    platform_api_secret: str
    deepgram_api_key: str
    cartesia_api_key: str
    google_api_key: str

    @classmethod
    def from_platform(cls) -> "MossConfig":
        """Load configuration from platform."""
        try:
            base_url = os.getenv("MOSS_PLATFORM_API_URL", "https://service.usemoss.dev")
            project_id = os.getenv("MOSS_PROJECT_ID")
            project_key = os.getenv("MOSS_PROJECT_KEY")
            voice_agent_id = os.getenv("MOSS_VOICE_AGENT_ID")

            if not project_id or not project_key:
                raise RuntimeError("Missing MOSS_PROJECT_ID or MOSS_PROJECT_KEY")
            if not voice_agent_id:
                raise RuntimeError("Missing MOSS_VOICE_AGENT_ID")

            headers = {
                "X-Project-Id": project_id,
                "X-Project-Key": project_key,
            }

            # Fetch runtime config
            runtime_response = httpx.get(
                f"{base_url}/api/voice-agent/get-runtime-config",
                headers=headers,
                params={"voice_agent_id": voice_agent_id},
                timeout=10.0,
            )
            runtime_response.raise_for_status()
            runtime_config = runtime_response.json()

            # Fetch voice agent credentials
            credentials_response = httpx.get(
                f"{base_url}/api/voice-agent/get-voice-agent",
                headers=headers,
                params={"voice_agent_id": voice_agent_id},
                timeout=10.0,
            )
            credentials_response.raise_for_status()
            credentials = credentials_response.json()

            # Get provider API keys from environment
            deepgram_key = os.getenv("DEEPGRAM_API_KEY")
            cartesia_key = os.getenv("CARTESIA_API_KEY")
            google_key = os.getenv("GOOGLE_API_KEY")

            if not deepgram_key or not cartesia_key or not google_key:
                raise RuntimeError("Missing provider API keys: DEEPGRAM_API_KEY, CARTESIA_API_KEY, GOOGLE_API_KEY")

            return cls(
                agent_id=voice_agent_id,
                llm_model=runtime_config["llm_model"],
                stt_model=runtime_config["stt_model"],
                stt_language=runtime_config["stt_language"],
                tts_model=runtime_config["tts_model"],
                tts_voice=runtime_config["tts_voice"],
                min_endpointing_delay=runtime_config["min_endpointing_delay"],
                max_endpointing_delay=runtime_config["max_endpointing_delay"],
                preemptive_generation=runtime_config["preemptive_generation"],
                platform_ws_url=credentials["voice_agent_url"],
                platform_api_key=credentials["voice_agent_api_key"],
                platform_api_secret=credentials["voice_agent_api_secret"],
                deepgram_api_key=deepgram_key,
                cartesia_api_key=cartesia_key,
                google_api_key=google_key,
            )
        except AttributeError as e:
            raise RuntimeError(f"Missing platform config attribute: {e}")
        except Exception as e:
            raise RuntimeError(f"Failed to load config: {e}")
