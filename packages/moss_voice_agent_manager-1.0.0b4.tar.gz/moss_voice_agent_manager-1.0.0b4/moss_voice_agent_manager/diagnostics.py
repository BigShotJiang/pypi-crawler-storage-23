"""
Diagnostics and performance monitoring for Moss agents.

Provides detailed metrics tracking for:
- LLM: TTFT, duration, tokens, speed
- TTS: TTFB, duration, audio length, characters
- STT: transcription delay, count
- VAD: inference time, count
- EOU: end-of-utterance delay

Formula for Time to First Word:
  TTFW = STT_delay + VAD_inference + EOU_delay + LLM_ttft + TTS_ttfb
"""

import time
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from collections import defaultdict


@dataclass
class LLMMetric:
    """LLM generation metrics."""
    ttft_ms: float  # Time to first token
    duration_ms: float  # Total generation duration
    tokens_input: int  # Input tokens
    tokens_output: int  # Output tokens
    tokens_total: int  # Total tokens
    speed_tps: float  # Tokens per second
    timestamp: float  # When this metric was recorded


@dataclass
class TTSMetric:
    """TTS generation metrics."""
    ttfb_ms: float  # Time to first byte
    duration_ms: float  # Total generation duration
    audio_duration_ms: float  # Length of generated audio
    chars: int  # Number of characters
    timestamp: float


@dataclass
class STTMetric:
    """STT transcription metrics."""
    transcription_delay_ms: float  # Delay in transcription
    timestamp: float


@dataclass
class VADMetric:
    """VAD detection metrics."""
    inference_ms: float  # Inference time
    idle_ms: float  # Idle time
    timestamp: float


@dataclass
class EOUMetric:
    """End-of-utterance detection metrics."""
    eou_delay_ms: float  # EOU delay
    stt_processing_ms: float  # STT processing time
    timestamp: float


@dataclass
class TurnMetric:
    """Complete turn metrics (user or agent)."""
    turn_number: int
    turn_type: str  # "user" or "agent"
    text: str
    timestamp: float
    # Breakdown
    stt_delay_ms: Optional[float] = None
    vad_inference_ms: Optional[float] = None
    eou_delay_ms: Optional[float] = None
    llm_ttft_ms: Optional[float] = None
    tts_ttfb_ms: Optional[float] = None
    # Calculated
    time_to_first_word_ms: Optional[float] = None


@dataclass
class MetricsCollector:
    """
    Collects and aggregates metrics for an agent session.

    Tracks all timing metrics and provides formatted reports
    similar to the JavaScript orchestrator.
    """

    session_id: str
    session_start: float = field(default_factory=time.time)

    # Collections
    llm_metrics: List[LLMMetric] = field(default_factory=list)
    tts_metrics: List[TTSMetric] = field(default_factory=list)
    stt_metrics: List[STTMetric] = field(default_factory=list)
    vad_metrics: List[VADMetric] = field(default_factory=list)
    eou_metrics: List[EOUMetric] = field(default_factory=list)
    turns: List[TurnMetric] = field(default_factory=list)

    # Counters
    user_turn_count: int = 0
    agent_turn_count: int = 0

    def add_llm_metric(self, ttft_ms: float, duration_ms: float,
                      tokens_input: int, tokens_output: int,
                      tokens_total: int) -> None:
        """Add LLM generation metric."""
        speed_tps = tokens_output / (duration_ms / 1000) if duration_ms > 0 else 0
        self.llm_metrics.append(LLMMetric(
            ttft_ms=ttft_ms,
            duration_ms=duration_ms,
            tokens_input=tokens_input,
            tokens_output=tokens_output,
            tokens_total=tokens_total,
            speed_tps=speed_tps,
            timestamp=time.time()
        ))

    def add_tts_metric(self, ttfb_ms: float, duration_ms: float,
                      audio_duration_ms: float, chars: int) -> None:
        """Add TTS generation metric."""
        self.tts_metrics.append(TTSMetric(
            ttfb_ms=ttfb_ms,
            duration_ms=duration_ms,
            audio_duration_ms=audio_duration_ms,
            chars=chars,
            timestamp=time.time()
        ))

    def add_stt_metric(self, transcription_delay_ms: float) -> None:
        """Add STT transcription metric."""
        self.stt_metrics.append(STTMetric(
            transcription_delay_ms=transcription_delay_ms,
            timestamp=time.time()
        ))

    def add_vad_metric(self, inference_ms: float, idle_ms: float) -> None:
        """Add VAD detection metric."""
        self.vad_metrics.append(VADMetric(
            inference_ms=inference_ms,
            idle_ms=idle_ms,
            timestamp=time.time()
        ))

    def add_eou_metric(self, eou_delay_ms: float, stt_processing_ms: float) -> None:
        """Add end-of-utterance metric."""
        self.eou_metrics.append(EOUMetric(
            eou_delay_ms=eou_delay_ms,
            stt_processing_ms=stt_processing_ms,
            timestamp=time.time()
        ))

    def add_user_turn(self, text: str, stt_delay_ms: Optional[float] = None,
                     vad_inference_ms: Optional[float] = None,
                     eou_delay_ms: Optional[float] = None) -> None:
        """Add user turn metric."""
        self.user_turn_count += 1
        self.turns.append(TurnMetric(
            turn_number=self.user_turn_count,
            turn_type="user",
            text=text,
            timestamp=time.time(),
            stt_delay_ms=stt_delay_ms,
            vad_inference_ms=vad_inference_ms,
            eou_delay_ms=eou_delay_ms
        ))

    def add_agent_turn(self, text: str, llm_ttft_ms: Optional[float] = None,
                      tts_ttfb_ms: Optional[float] = None) -> None:
        """Add agent turn metric."""
        self.agent_turn_count += 1

        # Calculate time to first word
        ttfw = None
        if llm_ttft_ms and tts_ttfb_ms:
            # Get most recent metrics
            stt_delay = self.stt_metrics[-1].transcription_delay_ms if self.stt_metrics else 0
            vad_inference = self.vad_metrics[-1].inference_ms if self.vad_metrics else 0
            eou_delay = self.eou_metrics[-1].eou_delay_ms if self.eou_metrics else 0

            ttfw = stt_delay + vad_inference + eou_delay + llm_ttft_ms + tts_ttfb_ms

        self.turns.append(TurnMetric(
            turn_number=self.agent_turn_count,
            turn_type="agent",
            text=text,
            timestamp=time.time(),
            llm_ttft_ms=llm_ttft_ms,
            tts_ttfb_ms=tts_ttfb_ms,
            time_to_first_word_ms=ttfw
        ))

    def generate_report(self) -> str:
        """
        Generate a formatted metrics report similar to JavaScript orchestrator.

        Format:
        ╔════════════════════════════════════════════════╗
        ║          MOSS AGENT METRICS REPORT            ║
        ║ Session ID: xxx                               ║
        ║ Duration: XX.XXs                              ║
        ╠════════════════════════════════════════════════╣
        ║              RUNTIME METRICS SUMMARY          ║
        ╠════════════════════════════════════════════════╣
        ║ Conversation: X user turns, X agent turns     ║
        ║                                               ║
        ║ LLM (X requests):                             ║
        ║   TTFT:     avg XXms | min XXms | max XXms    ║
        ║   Duration: avg XXms                          ║
        ║   Tokens:   XXX total | Speed: XX.X tok/s     ║
        ║                                               ║
        ║ TTS (X requests):                             ║
        ║   TTFB:     avg XXms | min XXms | max XXms    ║
        ║   Duration: avg XXms                          ║
        ║   Chars:    XXX total                         ║
        ║                                               ║
        ║ STT (X transcriptions):                       ║
        ║   Transcription delay: avg XXms               ║
        ║                                               ║
        ║ VAD (X detections):                           ║
        ║   Inference: avg XXms                         ║
        ║   Idle:      avg XXms                         ║
        ║                                               ║
        ║ EOU (X detections):                           ║
        ║   EOU Delay:      avg XXms                    ║
        ║   STT Processing: avg XXms                    ║
        ╠════════════════════════════════════════════════╣
        ║          TIME TO FIRST WORD BREAKDOWN         ║
        ╠════════════════════════════════════════════════╣
        ║ Formula: STT + VAD + EOU + LLM + TTS          ║
        ║                                               ║
        ║ Latest agent response:                        ║
        ║   STT:        XXms                            ║
        ║   VAD:        XXms                            ║
        ║   EOU:        XXms                            ║
        ║   LLM TTFT:   XXms                            ║
        ║   TTS TTFB:   XXms                            ║
        ║   ─────────────────                           ║
        ║   TOTAL:      XXms                            ║
        ╚════════════════════════════════════════════════╝
        """
        lines = []
        width = 80

        def pad(text: str) -> str:
            """Pad text to fit within box."""
            if len(text) > width - 4:
                return f"║ {text[:width-7]}... ║"
            return f"║ {text.ljust(width - 4)} ║"

        # Header
        lines.append("╔" + "═" * (width - 2) + "╗")
        lines.append(pad("MOSS AGENT METRICS REPORT".center(width - 4)))
        lines.append(pad(f"Session ID: {self.session_id}"))

        session_duration = time.time() - self.session_start
        lines.append(pad(f"Duration: {session_duration:.2f}s ({session_duration * 1000:.0f}ms)"))

        # Runtime Metrics Summary
        lines.append("╠" + "═" * (width - 2) + "╣")
        lines.append(pad("RUNTIME METRICS SUMMARY".center(width - 4)))
        lines.append("╠" + "═" * (width - 2) + "╣")

        # LLM Metrics
        if self.llm_metrics:
            lines.append(pad(""))
            avg_ttft = sum(m.ttft_ms for m in self.llm_metrics) / len(self.llm_metrics)
            avg_duration = sum(m.duration_ms for m in self.llm_metrics) / len(self.llm_metrics)
            total_tokens = sum(m.tokens_total for m in self.llm_metrics)
            avg_speed = sum(m.speed_tps for m in self.llm_metrics) / len(self.llm_metrics)
            min_ttft = min(m.ttft_ms for m in self.llm_metrics)
            max_ttft = max(m.ttft_ms for m in self.llm_metrics)

            lines.append(pad(f"LLM ({len(self.llm_metrics)} requests):"))
            lines.append(pad(f"  TTFT:     avg {avg_ttft:.0f}ms | min {min_ttft:.0f}ms | max {max_ttft:.0f}ms"))
            lines.append(pad(f"  Duration: avg {avg_duration:.0f}ms"))
            lines.append(pad(f"  Tokens:   {total_tokens} total | Speed: {avg_speed:.1f} tok/s"))
            has_content = True

        # TTS Metrics
        if self.tts_metrics:
            lines.append(pad(""))
            avg_ttfb = sum(m.ttfb_ms for m in self.tts_metrics) / len(self.tts_metrics)
            avg_duration = sum(m.duration_ms for m in self.tts_metrics) / len(self.tts_metrics)
            total_chars = sum(m.chars for m in self.tts_metrics)
            min_ttfb = min(m.ttfb_ms for m in self.tts_metrics)
            max_ttfb = max(m.ttfb_ms for m in self.tts_metrics)

            lines.append(pad(f"TTS ({len(self.tts_metrics)} requests):"))
            lines.append(pad(f"  TTFB:     avg {avg_ttfb:.0f}ms | min {min_ttfb:.0f}ms | max {max_ttfb:.0f}ms"))
            lines.append(pad(f"  Duration: avg {avg_duration:.0f}ms"))
            lines.append(pad(f"  Chars:    {total_chars} total"))
            has_content = True

        # STT Metrics
        if self.stt_metrics:
            lines.append(pad(""))
            avg_delay = sum(m.transcription_delay_ms for m in self.stt_metrics) / len(self.stt_metrics)
            lines.append(pad(f"STT ({len(self.stt_metrics)} transcriptions):"))
            lines.append(pad(f"  Transcription delay: avg {avg_delay:.0f}ms"))
            has_content = True

        # VAD Metrics
        if self.vad_metrics:
            lines.append(pad(""))
            avg_inference = sum(m.inference_ms for m in self.vad_metrics) / len(self.vad_metrics)
            avg_idle = sum(m.idle_ms for m in self.vad_metrics) / len(self.vad_metrics)
            lines.append(pad(f"VAD ({len(self.vad_metrics)} detections):"))
            lines.append(pad(f"  Inference: avg {avg_inference:.2f}ms"))
            lines.append(pad(f"  Idle:      avg {avg_idle:.0f}ms"))
            has_content = True

        # EOU Metrics
        if self.eou_metrics:
            lines.append(pad(""))
            avg_eou = sum(m.eou_delay_ms for m in self.eou_metrics) / len(self.eou_metrics)
            avg_stt = sum(m.stt_processing_ms for m in self.eou_metrics) / len(self.eou_metrics)
            lines.append(pad(f"EOU ({len(self.eou_metrics)} detections):"))
            lines.append(pad(f"  EOU Delay:      avg {avg_eou:.0f}ms"))
            lines.append(pad(f"  STT Processing: avg {avg_stt:.0f}ms"))
            has_content = True

        # Footer
        lines.append("╚" + "═" * (width - 2) + "╝")

        return "\n".join(lines)

    def get_summary_dict(self) -> Dict:
        """Get metrics summary as a dictionary for logging."""
        return {
            "session_id": self.session_id,
            "duration_s": time.time() - self.session_start,
            "turns": {
                "user": self.user_turn_count,
                "agent": self.agent_turn_count,
            },
            "llm": {
                "count": len(self.llm_metrics),
                "avg_ttft_ms": sum(m.ttft_ms for m in self.llm_metrics) / len(self.llm_metrics) if self.llm_metrics else 0,
                "avg_speed_tps": sum(m.speed_tps for m in self.llm_metrics) / len(self.llm_metrics) if self.llm_metrics else 0,
            },
            "tts": {
                "count": len(self.tts_metrics),
                "avg_ttfb_ms": sum(m.ttfb_ms for m in self.tts_metrics) / len(self.tts_metrics) if self.tts_metrics else 0,
            },
            "stt": {
                "count": len(self.stt_metrics),
                "avg_delay_ms": sum(m.transcription_delay_ms for m in self.stt_metrics) / len(self.stt_metrics) if self.stt_metrics else 0,
            },
            "vad": {
                "count": len(self.vad_metrics),
                "avg_inference_ms": sum(m.inference_ms for m in self.vad_metrics) / len(self.vad_metrics) if self.vad_metrics else 0,
            },
            "eou": {
                "count": len(self.eou_metrics),
                "avg_delay_ms": sum(m.eou_delay_ms for m in self.eou_metrics) / len(self.eou_metrics) if self.eou_metrics else 0,
            },
        }
