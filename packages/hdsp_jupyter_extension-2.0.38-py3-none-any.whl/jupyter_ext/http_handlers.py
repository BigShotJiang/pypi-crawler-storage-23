"""
HDSP Jupyter Extension Handlers.

ServiceFactory-based handlers for in-process execution.
"""

import asyncio
import json
import logging
import os
import subprocess
import time
from typing import Any, Awaitable, Callable, Dict, Optional
from uuid import uuid4

import httpx
from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join

from .resource_usage import get_integrated_resources

# Lazy imports: these pull in deepagents/langgraph which may fail in some environments.
# Import failures here must NOT prevent basic handler registration.
try:
    from langgraph.checkpoint.memory import MemorySaver as _MemorySaver

    _LANGGRAPH_AVAILABLE = True
except ImportError:
    _MemorySaver = None  # type: ignore[assignment,misc]
    _LANGGRAPH_AVAILABLE = False

try:
    from .agent.json_repair_utils import ensure_str, safe_json_dumps, safe_parse_json

    _AGENT_UTILS_AVAILABLE = True
except ImportError:
    _AGENT_UTILS_AVAILABLE = False

    def ensure_str(v: Any) -> str:  # type: ignore[misc]
        return str(v) if v is not None else ""

    def safe_json_dumps(v: Any) -> str:  # type: ignore[misc]
        import json as _json

        return _json.dumps(v)

    def safe_parse_json(v: Any) -> Any:  # type: ignore[misc]
        import json as _json

        try:
            return _json.loads(v)
        except Exception:
            return None

logger = logging.getLogger(__name__)
if not logger.handlers and not logger.parent.handlers:
    logger.setLevel(logging.INFO)

DEFAULT_EXECUTE_COMMAND_TIMEOUT_MS = 600_000
MAX_EXECUTE_COMMAND_STREAM_BYTES = 1_000_000


def _resolve_timeout_ms(
    value: Any, default: int = DEFAULT_EXECUTE_COMMAND_TIMEOUT_MS
) -> int:
    """Resolve timeout in milliseconds with a safe default."""
    try:
        timeout_ms = int(value)
    except (TypeError, ValueError):
        return default
    if timeout_ms <= 0:
        return default
    return timeout_ms


def _resolve_stream_timeout_ms(
    value: Any, default: int = DEFAULT_EXECUTE_COMMAND_TIMEOUT_MS
) -> Optional[int]:
    """Resolve timeout in milliseconds; non-positive disables timeout."""
    try:
        timeout_ms = int(value)
    except (TypeError, ValueError):
        return default
    if timeout_ms <= 0:
        return None
    return timeout_ms


def _resolve_workspace_root(server_root: str) -> str:
    """Resolve workspace root by walking up to the project root if needed."""
    current = os.path.abspath(server_root)
    while True:
        if os.path.isdir(os.path.join(current, "extensions")):
            return current
        parent = os.path.dirname(current)
        if parent == current:
            return os.path.abspath(server_root)
        current = parent


def _get_effective_workspace_root(
    server_root: str, user_workspace_root: str | None
) -> str:
    """Get effective workspace root, respecting user's setting if provided.

    Args:
        server_root: The Jupyter server's root directory
        user_workspace_root: User-provided workspace root from settings

    Returns:
        The effective workspace root to use for file operations
    """
    resolved_root = _resolve_workspace_root(server_root)

    if user_workspace_root and os.path.isabs(user_workspace_root):
        return user_workspace_root
    elif user_workspace_root:
        return os.path.join(resolved_root, user_workspace_root)
    else:
        return resolved_root


def _get_service_factory():
    """Get ServiceFactory instance (lazy import to avoid circular imports)"""
    from hdsp_agent_core.factory import get_service_factory

    return get_service_factory()


def _is_embedded_mode() -> bool:
    """Check if running in embedded mode"""
    try:
        factory = _get_service_factory()
        return factory.is_embedded
    except Exception:
        return False


def _run_shell_command(
    command: str, timeout_ms: int, cwd: str, stdin_input: Optional[str] = None
) -> Dict[str, Any]:
    """Run a shell command with timeout and capture output.

    Args:
        command: Shell command to execute
        timeout_ms: Timeout in milliseconds
        cwd: Working directory
        stdin_input: Optional input to provide to the command (for interactive prompts)
    """
    timeout_sec = max(0.1, timeout_ms / 1000)
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            cwd=cwd,
            input=stdin_input,  # Provide stdin if specified
        )
        return {
            "success": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode,
            "cwd": cwd,
        }
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "error": f"Command timed out after {timeout_sec}s. If the command requires user input, use stdin parameter or non-interactive flags.",
            "cwd": cwd,
        }
    except Exception as exc:
        return {"success": False, "error": str(exc), "cwd": cwd}


def _append_stream_output(
    current: str,
    chunk: str,
    max_bytes: int = MAX_EXECUTE_COMMAND_STREAM_BYTES,
) -> tuple[str, bool]:
    """Append output chunk, truncating when max_bytes is reached."""
    if not chunk:
        return current, False
    current_bytes = current.encode("utf-8")
    if len(current_bytes) >= max_bytes:
        return current, True
    chunk_bytes = chunk.encode("utf-8")
    remaining = max_bytes - len(current_bytes)
    if len(chunk_bytes) <= remaining:
        return current + chunk, False
    truncated_chunk = chunk_bytes[:remaining].decode("utf-8", errors="ignore")
    return current + truncated_chunk, True


async def _stream_subprocess_output(
    stream: Optional[asyncio.StreamReader],
    stream_name: str,
    emit: Callable[[str, Dict[str, Any]], Awaitable[None]],
    append: Callable[[str], None],
) -> None:
    """Stream subprocess output lines and collect them."""
    if stream is None:
        return
    while True:
        chunk = await stream.readline()
        if not chunk:
            break
        text = chunk.decode("utf-8", errors="replace")
        await emit("output", {"stream": stream_name, "text": text})
        append(text)


def _resolve_path_in_workspace(
    path: str, workspace_root: str, requested_cwd: Optional[str] = None
) -> str:
    """Resolve a relative path within the workspace root."""
    if os.path.isabs(path):
        raise ValueError("absolute paths are not allowed")
    if ".." in path:
        raise ValueError("parent directory traversal is not allowed")

    normalized_path = os.path.normpath(path)
    base_dir = workspace_root
    if requested_cwd:
        if os.path.isabs(requested_cwd):
            resolved_cwd = os.path.abspath(requested_cwd)
        else:
            resolved_cwd = os.path.abspath(os.path.join(workspace_root, requested_cwd))
        if os.path.commonpath([workspace_root, resolved_cwd]) != workspace_root:
            raise ValueError("cwd escapes workspace root")
        base_dir = resolved_cwd

        rel_cwd = os.path.normpath(os.path.relpath(resolved_cwd, workspace_root))
        if rel_cwd != ".":
            prefix = rel_cwd + os.sep
            if normalized_path == rel_cwd:
                normalized_path = "."
            elif normalized_path.startswith(prefix):
                normalized_path = normalized_path[len(prefix) :]

    resolved_path = os.path.abspath(os.path.join(base_dir, normalized_path))
    if os.path.commonpath([workspace_root, resolved_path]) != workspace_root:
        raise ValueError("path escapes workspace root")
    return resolved_path


def _resolve_command_cwd(
    server_root: str, workspace_root: str, requested_cwd: Optional[str] = None
) -> str:
    """Resolve command cwd within workspace root."""
    default_cwd = os.path.abspath(server_root)
    if os.path.commonpath([workspace_root, default_cwd]) != workspace_root:
        default_cwd = workspace_root

    if not requested_cwd:
        return default_cwd

    if os.path.isabs(requested_cwd):
        resolved_cwd = os.path.abspath(requested_cwd)
    else:
        resolved_cwd = os.path.abspath(os.path.join(default_cwd, requested_cwd))

    if os.path.commonpath([workspace_root, resolved_cwd]) != workspace_root:
        raise ValueError("cwd escapes workspace root")

    return resolved_cwd


def _write_file(
    resolved_path: str, content: str, encoding: str, overwrite: bool
) -> Dict[str, Any]:
    """Write content to a file on disk."""
    print(
        f"[WRITE DEBUG] resolved_path={resolved_path}, overwrite={overwrite}, type={type(overwrite)}",
        flush=True,
    )
    try:
        dir_path = os.path.dirname(resolved_path)
        if dir_path:
            os.makedirs(dir_path, exist_ok=True)
        mode = "w" if overwrite else "x"
        print(f"[WRITE DEBUG] mode={mode}", flush=True)
        with open(resolved_path, mode, encoding=encoding) as f:
            f.write(content)
        return {
            "success": True,
            "size": len(content),
        }
    except FileExistsError:
        return {
            "success": False,
            "error": "File already exists. Set overwrite=true to overwrite.",
        }
    except Exception as exc:
        return {"success": False, "error": str(exc)}


def _is_ripgrep_available() -> bool:
    """Check if ripgrep (rg) is installed."""
    import shutil

    return shutil.which("rg") is not None


def _build_search_command(
    pattern: str,
    file_types: list,
    path: str,
    case_sensitive: bool,
    max_results: int,
) -> tuple:
    """Build grep/ripgrep command for searching files."""
    use_ripgrep = _is_ripgrep_available()

    if use_ripgrep:
        cmd_parts = ["rg", "--line-number", "--with-filename"]
        if not case_sensitive:
            cmd_parts.append("--ignore-case")
        for ft in file_types:
            cmd_parts.extend(["--glob", ft])
        cmd_parts.extend(["--max-count", str(max_results)])
        escaped_pattern = pattern.replace("'", "'\\''")
        cmd_parts.append(f"'{escaped_pattern}'")
        cmd_parts.append(path)
        return " ".join(cmd_parts), "rg"
    else:
        find_parts = ["find", path, "-type", "f", "\\("]
        for i, ft in enumerate(file_types):
            if i > 0:
                find_parts.append("-o")
            find_parts.extend(["-name", f"'{ft}'"])
        find_parts.append("\\)")
        grep_flags = "n" + ("" if case_sensitive else "i")
        escaped_pattern = pattern.replace("'", "'\\''")
        cmd = f"{' '.join(find_parts)} 2>/dev/null | xargs grep -{grep_flags} '{escaped_pattern}' 2>/dev/null | head -n {max_results}"
        return cmd, "grep"


def _parse_grep_output(output: str, workspace_root: str) -> list:
    """Parse grep/ripgrep output into structured results."""
    results = []
    for line in output.strip().split("\n"):
        if not line:
            continue
        parts = line.split(":", 2)
        if len(parts) >= 2:
            file_path = parts[0]
            try:
                line_num = int(parts[1])
                content = parts[2] if len(parts) > 2 else ""
            except ValueError:
                line_num = 0
                content = line
            try:
                rel_path = os.path.relpath(file_path, workspace_root)
            except ValueError:
                rel_path = file_path
            results.append(
                {
                    "file_path": rel_path,
                    "line_number": line_num,
                    "content": content.strip()[:200],
                    "match_type": "line",
                }
            )
    return results


def _search_in_notebook(
    notebook_path: str, pattern: str, cell_type: Optional[str], case_sensitive: bool
) -> list:
    """Search for pattern in notebook cells."""
    import re

    results = []
    flags = 0 if case_sensitive else re.IGNORECASE

    try:
        compiled = re.compile(pattern, flags)
    except re.error:
        compiled = re.compile(re.escape(pattern), flags)

    try:
        with open(notebook_path, "r", encoding="utf-8") as f:
            notebook = json.load(f)
        cells = notebook.get("cells", [])
        for idx, cell in enumerate(cells):
            current_type = cell.get("cell_type", "code")
            if cell_type and current_type != cell_type:
                continue
            source = cell.get("source", [])
            if isinstance(source, list):
                source = "".join(source)
            if compiled.search(source):
                matching_lines = []
                for line_num, line in enumerate(source.split("\n"), 1):
                    if compiled.search(line):
                        matching_lines.append(
                            {"line": line_num, "content": line.strip()[:150]}
                        )
                results.append(
                    {
                        "cell_index": idx,
                        "cell_type": current_type,
                        "content": source[:300] + "..."
                        if len(source) > 300
                        else source,
                        "matching_lines": matching_lines[:5],
                        "match_type": "cell",
                    }
                )
    except Exception as e:
        logger.warning(f"Error searching notebook {notebook_path}: {e}")
    return results


def _execute_search_workspace(
    pattern: str,
    file_types: list,
    path: str,
    max_results: int,
    case_sensitive: bool,
    workspace_root: str,
) -> Dict[str, Any]:
    """Execute workspace search using subprocess."""
    search_path = os.path.normpath(os.path.join(workspace_root, path))
    if not os.path.exists(search_path):
        return {
            "success": False,
            "error": f"Path does not exist: {path}",
            "results": [],
            "total_results": 0,
        }

    command, tool_used = _build_search_command(
        pattern, file_types, search_path, case_sensitive, max_results
    )
    print(f"[SEARCH DEBUG] Executing search: {command}", flush=True)
    print(
        f"[SEARCH DEBUG] cwd: {workspace_root}, search_path: {search_path}", flush=True
    )

    # Debug: test find command separately
    find_only = f"find {search_path} -type f -name '*.py' | head -5"
    find_result = subprocess.run(
        find_only,
        shell=True,
        capture_output=True,
        text=True,
        timeout=10,
        cwd=workspace_root,
    )
    print(
        f"[SEARCH DEBUG] find only stdout: {find_result.stdout[:300] if find_result.stdout else 'EMPTY'}",
        flush=True,
    )

    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30,
            cwd=workspace_root,
        )
        print(
            f"[SEARCH DEBUG] stdout: {result.stdout[:500] if result.stdout else 'EMPTY'}",
            flush=True,
        )
        print(
            f"[SEARCH DEBUG] stderr: {result.stderr[:500] if result.stderr else 'EMPTY'}",
            flush=True,
        )
        print(f"[SEARCH DEBUG] returncode: {result.returncode}", flush=True)
        results = _parse_grep_output(result.stdout, workspace_root)

        # Also search in notebook cell contents
        notebook_results = []
        if any("ipynb" in ft for ft in file_types):
            find_cmd = f"find {search_path} -name '*.ipynb' -type f 2>/dev/null"
            nb_result = subprocess.run(
                find_cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=10,
                cwd=workspace_root,
            )
            if nb_result.returncode == 0 and nb_result.stdout:
                notebooks = nb_result.stdout.strip().split("\n")
                for nb_path in notebooks[:20]:
                    if nb_path and os.path.exists(nb_path):
                        nb_matches = _search_in_notebook(
                            nb_path, pattern, None, case_sensitive
                        )
                        for m in nb_matches:
                            try:
                                m["file_path"] = os.path.relpath(
                                    nb_path, workspace_root
                                )
                            except ValueError:
                                m["file_path"] = nb_path
                        notebook_results.extend(nb_matches)
                        if len(notebook_results) >= max_results:
                            break

        all_results = results + notebook_results
        return {
            "success": True,
            "command": command,
            "tool_used": tool_used,
            "results": all_results[:max_results],
            "total_results": len(all_results),
        }
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "error": "Search timed out",
            "results": [],
            "total_results": 0,
        }
    except Exception as e:
        return {"success": False, "error": str(e), "results": [], "total_results": 0}


def _execute_search_notebook_cells(
    pattern: str,
    notebook_path: Optional[str],
    cell_type: Optional[str],
    max_results: int,
    case_sensitive: bool,
    workspace_root: str,
) -> Dict[str, Any]:
    """Execute notebook cell search."""
    results = []
    notebooks_searched = 0

    try:
        if notebook_path:
            full_path = os.path.normpath(os.path.join(workspace_root, notebook_path))
            if os.path.exists(full_path) and full_path.endswith(".ipynb"):
                matches = _search_in_notebook(
                    full_path, pattern, cell_type, case_sensitive
                )
                for m in matches:
                    m["file_path"] = notebook_path
                results.extend(matches)
                notebooks_searched = 1
            else:
                return {
                    "success": False,
                    "error": f"Notebook not found: {notebook_path}",
                    "results": [],
                    "total_results": 0,
                    "notebooks_searched": 0,
                }
        else:
            find_cmd = f"find {workspace_root} -name '*.ipynb' -type f 2>/dev/null"
            find_result = subprocess.run(
                find_cmd,
                shell=True,
                capture_output=True,
                text=True,
                timeout=10,
                cwd=workspace_root,
            )
            if find_result.returncode == 0 and find_result.stdout:
                notebooks = find_result.stdout.strip().split("\n")
                for nb_full_path in notebooks:
                    if not nb_full_path or not os.path.exists(nb_full_path):
                        continue
                    notebooks_searched += 1
                    matches = _search_in_notebook(
                        nb_full_path, pattern, cell_type, case_sensitive
                    )
                    try:
                        rel_path = os.path.relpath(nb_full_path, workspace_root)
                    except ValueError:
                        rel_path = nb_full_path
                    for m in matches:
                        m["file_path"] = rel_path
                    results.extend(matches)
                    if len(results) >= max_results:
                        break

        return {
            "success": True,
            "results": results[:max_results],
            "total_results": len(results),
            "notebooks_searched": notebooks_searched,
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "results": [],
            "total_results": 0,
            "notebooks_searched": 0,
        }


# ============ Service-Based Handlers ============


class AgentPlanHandler(APIHandler):
    """Handler for /agent/plan endpoint using ServiceFactory."""

    async def post(self):
        """Generate execution plan."""
        try:
            from hdsp_agent_core.models.agent import PlanRequest

            factory = _get_service_factory()
            agent_service = factory.get_agent_service()

            # Parse request
            body = json.loads(self.request.body.decode("utf-8"))
            request = PlanRequest(**body)

            # Call service
            response = await agent_service.generate_plan(request)

            self.set_header("Content-Type", "application/json")
            self.write(response.model_dump(mode="json"))

        except Exception as e:
            logger.error(f"Plan generation failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AgentRefineHandler(APIHandler):
    """Handler for /agent/refine endpoint using ServiceFactory."""

    async def post(self):
        """Refine code after error."""
        try:
            from hdsp_agent_core.models.agent import RefineRequest

            factory = _get_service_factory()
            agent_service = factory.get_agent_service()

            body = json.loads(self.request.body.decode("utf-8"))
            request = RefineRequest(**body)

            response = await agent_service.refine_code(request)

            self.set_header("Content-Type", "application/json")
            self.write(response.model_dump(mode="json"))

        except Exception as e:
            logger.error(f"Refine failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AgentReplanHandler(APIHandler):
    """Handler for /agent/replan endpoint using ServiceFactory."""

    async def post(self):
        """Determine how to handle failed step."""
        try:
            from hdsp_agent_core.models.agent import ReplanRequest

            factory = _get_service_factory()
            agent_service = factory.get_agent_service()

            body = json.loads(self.request.body.decode("utf-8"))
            request = ReplanRequest(**body)

            response = await agent_service.replan(request)

            self.set_header("Content-Type", "application/json")
            self.write(response.model_dump(mode="json"))

        except Exception as e:
            logger.error(f"Replan failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AgentValidateHandler(APIHandler):
    """Handler for /agent/validate endpoint using ServiceFactory."""

    async def post(self):
        """Validate code before execution."""
        try:
            factory = _get_service_factory()
            agent_service = factory.get_agent_service()

            body = json.loads(self.request.body.decode("utf-8"))
            code = body.get("code", "")
            notebook_context = body.get("notebookContext")

            response = await agent_service.validate_code(code, notebook_context)

            self.set_header("Content-Type", "application/json")
            self.write(response)

        except Exception as e:
            logger.error(f"Validate failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ChatMessageHandler(APIHandler):
    """Handler for /chat/message endpoint using ServiceFactory."""

    async def post(self):
        """Send chat message and get response."""
        try:
            from hdsp_agent_core.models.chat import ChatRequest

            factory = _get_service_factory()
            chat_service = factory.get_chat_service()

            body = json.loads(self.request.body.decode("utf-8"))
            request = ChatRequest(**body)

            response = await chat_service.send_message(request)

            self.set_header("Content-Type", "application/json")
            self.write(response.model_dump(mode="json"))

        except Exception as e:
            logger.error(f"Chat message failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ChatStreamHandler(APIHandler):
    """Handler for /chat/stream endpoint using ServiceFactory."""

    async def post(self):
        """Send chat message and get streaming response."""
        try:
            from hdsp_agent_core.models.chat import ChatRequest

            factory = _get_service_factory()
            chat_service = factory.get_chat_service()

            body = json.loads(self.request.body.decode("utf-8"))
            request = ChatRequest(**body)

            # Set SSE headers
            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")
            self.set_header("X-Accel-Buffering", "no")

            async for chunk in chat_service.send_message_stream(request):
                self.write(f"data: {json.dumps(chunk)}\n\n")
                await self.flush()

            self.finish()

        except Exception as e:
            logger.error(f"Chat stream failed: {e}", exc_info=True)
            self.write(f"data: {json.dumps({'error': str(e)})}\n\n")
            self.finish()


class RAGSearchHandler(APIHandler):
    """Handler for /rag/search endpoint using ServiceFactory."""

    async def post(self):
        """Search knowledge base."""
        try:
            from hdsp_agent_core.models.rag import SearchRequest

            factory = _get_service_factory()
            rag_service = factory.get_rag_service()

            body = json.loads(self.request.body.decode("utf-8"))
            request = SearchRequest(**body)

            response = await rag_service.search(request)

            self.set_header("Content-Type", "application/json")
            self.write(response.model_dump(mode="json"))

        except Exception as e:
            logger.error(f"RAG search failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ExecuteCommandHandler(APIHandler):
    """Handler for /execute-command endpoint (runs on Jupyter server)."""

    async def post(self):
        """Execute shell command after user approval."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            command = (body.get("command") or "").strip()
            timeout_ms = _resolve_timeout_ms(body.get("timeout"))
            requested_cwd = (body.get("cwd") or "").strip()
            stdin_input = body.get("stdin")  # Optional stdin for interactive commands
            user_workspace_root = body.get("workspaceRoot")

            if not command:
                self.set_status(400)
                self.write({"error": "command is required"})
                return

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root, user_workspace_root
            )

            try:
                cwd = _resolve_command_cwd(server_root, workspace_root, requested_cwd)
            except ValueError as exc:
                self.set_status(400)
                self.write({"error": str(exc)})
                return

            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                lambda: _run_shell_command(command, timeout_ms, cwd, stdin_input),
            )

            self.set_header("Content-Type", "application/json")
            self.write(result)

        except Exception as e:
            logger.error(f"Execute command failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ExecuteCommandStreamHandler(APIHandler):
    """Handler for /execute-command/stream endpoint (runs on Jupyter server)."""

    async def post(self):
        """Execute shell command and stream output."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            command = (body.get("command") or "").strip()
            timeout_ms = _resolve_stream_timeout_ms(body.get("timeout"))
            requested_cwd = (body.get("cwd") or "").strip()
            stdin_input = body.get("stdin")  # Optional stdin for interactive commands
            user_workspace_root = body.get("workspaceRoot")

            if not command:
                self.set_status(400)
                self.write({"error": "command is required"})
                return

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root, user_workspace_root
            )

            try:
                cwd = _resolve_command_cwd(server_root, workspace_root, requested_cwd)
            except ValueError as exc:
                self.set_status(400)
                self.write({"error": str(exc)})
                return

            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")
            self.set_header("X-Accel-Buffering", "no")

            async def emit(event: str, payload: Dict[str, Any]) -> None:
                self.write(f"event: {event}\n")
                self.write(f"data: {json.dumps(payload)}\n\n")
                await self.flush()

            start_time = time.monotonic()
            await emit("start", {"command": command, "cwd": cwd})

            # Use PIPE for stdin if input is provided
            stdin_pipe = asyncio.subprocess.PIPE if stdin_input else None
            process = await asyncio.create_subprocess_shell(
                command,
                stdin=stdin_pipe,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
            )

            # Write stdin if provided
            if stdin_input and process.stdin:
                process.stdin.write(stdin_input.encode())
                await process.stdin.drain()
                process.stdin.close()
                await process.stdin.wait_closed()

            stdout_text = ""
            stderr_text = ""
            stdout_truncated = False
            stderr_truncated = False

            def append_stdout(text: str) -> None:
                nonlocal stdout_text, stdout_truncated
                stdout_text, truncated = _append_stream_output(stdout_text, text)
                stdout_truncated = stdout_truncated or truncated

            def append_stderr(text: str) -> None:
                nonlocal stderr_text, stderr_truncated
                stderr_text, truncated = _append_stream_output(stderr_text, text)
                stderr_truncated = stderr_truncated or truncated

            stdout_task = asyncio.create_task(
                _stream_subprocess_output(process.stdout, "stdout", emit, append_stdout)
            )
            stderr_task = asyncio.create_task(
                _stream_subprocess_output(process.stderr, "stderr", emit, append_stderr)
            )

            timed_out = False
            timeout_sec = None if timeout_ms is None else max(0.1, timeout_ms / 1000)
            try:
                if timeout_sec is None:
                    await process.wait()
                else:
                    await asyncio.wait_for(process.wait(), timeout=timeout_sec)
            except asyncio.TimeoutError:
                timed_out = True
                process.kill()
                await process.wait()

            try:
                await asyncio.wait_for(
                    asyncio.gather(stdout_task, stderr_task),
                    timeout=0.5,
                )
            except asyncio.TimeoutError:
                stdout_task.cancel()
                stderr_task.cancel()
                await asyncio.gather(stdout_task, stderr_task, return_exceptions=True)

            duration_ms = int((time.monotonic() - start_time) * 1000)
            truncated = stdout_truncated or stderr_truncated
            if timed_out:
                result = {
                    "success": False,
                    "stdout": stdout_text,
                    "stderr": stderr_text,
                    "returncode": process.returncode,
                    "error": f"Command timed out after {timeout_sec}s",
                    "truncated": truncated,
                    "cwd": cwd,
                    "duration_ms": duration_ms,
                }
            else:
                result = {
                    "success": process.returncode == 0,
                    "stdout": stdout_text,
                    "stderr": stderr_text,
                    "returncode": process.returncode,
                    "truncated": truncated,
                    "cwd": cwd,
                    "duration_ms": duration_ms,
                }

            await emit("result", result)
            self.finish()

        except Exception as e:
            logger.error(f"Execute command stream failed: {e}", exc_info=True)
            self.set_header("Content-Type", "text/event-stream")
            self.write(f"event: error\ndata: {json.dumps({'error': str(e)})}\n\n")
            self.finish()


class ResourceUsageHandler(APIHandler):
    """Handler for /resource-usage endpoint (runs on Jupyter server)."""

    async def get(self):
        """Return resource usage summary for the client host."""
        try:
            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _resolve_workspace_root(server_root)

            resource = get_integrated_resources(workspace_root=workspace_root)

            self.set_header("Content-Type", "application/json")
            self.write({"resource": resource})

        except Exception as e:
            logger.error(f"Resource usage collection failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class CheckResourceHandler(APIHandler):
    """Handler for /check-resource endpoint (runs on Jupyter server).

    Checks system resources, file sizes, and DataFrame shapes for resource-aware
    code generation.
    """

    async def post(self):
        """Check resources for the requested files and dataframes."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            files = body.get("files", [])
            dataframes = body.get("dataframes", [])
            dataframe_check_code = body.get("dataframe_check_code", "")
            user_workspace_root = body.get("workspaceRoot")

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root, user_workspace_root
            )

            result: Dict[str, Any] = {"success": True}

            # 1. Get system resources
            resource = get_integrated_resources(workspace_root=workspace_root)
            memory = resource.get("memory", {})
            result["system"] = {
                "ram_available_mb": round((memory.get("available_gb") or 0) * 1024, 2),
                "ram_total_mb": round((memory.get("total_gb") or 0) * 1024, 2),
                "cpu_cores": resource.get("cpu", {}).get("cores"),
                "environment": resource.get("environment"),
            }

            # 2. Get file sizes
            file_info = []
            for file_path in files:
                # Resolve path relative to server_root (Jupyter's working directory)
                # NOT workspace_root (project root) to match list_files_tool behavior
                if os.path.isabs(file_path):
                    abs_path = file_path
                else:
                    abs_path = os.path.join(server_root, file_path)

                try:
                    stat = os.stat(abs_path)
                    info = {
                        "name": os.path.basename(file_path),
                        "path": file_path,
                        "size_bytes": stat.st_size,
                        "size_mb": round(stat.st_size / (1024 * 1024), 2),
                        "exists": True,
                    }

                    # CSV files: include column schema so LLM uses real column names
                    if abs_path.lower().endswith(".csv"):
                        try:
                            import pandas as pd

                            df_sample = pd.read_csv(abs_path, nrows=5)
                            # Count total rows efficiently (without loading full file)
                            with open(abs_path, "r") as f:
                                rows_total = sum(1 for _ in f) - 1  # subtract header
                            info["schema"] = {
                                "columns": list(df_sample.columns),
                                "dtypes": {
                                    c: str(d) for c, d in df_sample.dtypes.items()
                                },
                                "rows_total": rows_total,
                                "sample_rows": df_sample.head(3).to_dict(
                                    orient="records"
                                ),
                            }
                            # Warn about boolean columns (is_numeric_dtype=True but describe() gives categorical stats)
                            bool_cols = [
                                c for c, d in df_sample.dtypes.items() if d == "bool"
                            ]
                            if bool_cols:
                                info["schema"]["dtype_warnings"] = (
                                    f"Columns {bool_cols} have dtype 'bool'. "
                                    "Do NOT use .describe()['mean'] on bool columns — "
                                    "use .mean() or .sum() directly."
                                )
                        except Exception as e:
                            info["schema_error"] = str(e)

                    file_info.append(info)
                except (OSError, IOError) as e:
                    file_info.append(
                        {
                            "name": os.path.basename(file_path),
                            "path": file_path,
                            "exists": False,
                            "error": str(e),
                        }
                    )
            result["files"] = file_info

            # 3. Get DataFrame info (if dataframe_check_code provided)
            df_info = []
            if dataframe_check_code and dataframes:
                try:
                    # Execute the code in the active kernel
                    kernel_manager = self.settings.get("kernel_manager")
                    if kernel_manager:
                        # Try to get the active kernel
                        kernel_ids = list(kernel_manager.list_kernel_ids())
                        if kernel_ids:
                            kernel_id = kernel_ids[0]
                            kernel = kernel_manager.get_kernel(kernel_id)
                            if kernel and hasattr(kernel, "client"):
                                client = kernel.client()
                                # Execute code and get result
                                msg_id = client.execute(
                                    dataframe_check_code, silent=True
                                )
                                # Wait for result (with timeout)
                                import asyncio

                                try:
                                    reply = await asyncio.wait_for(
                                        asyncio.to_thread(
                                            client.get_shell_msg, msg_id, timeout=5
                                        ),
                                        timeout=10,
                                    )
                                    # Parse output
                                    if reply.get("content", {}).get("status") == "ok":
                                        # Get stdout from iopub
                                        while True:
                                            try:
                                                iopub_msg = client.get_iopub_msg(
                                                    timeout=1
                                                )
                                                if (
                                                    iopub_msg.get("msg_type")
                                                    == "stream"
                                                ):
                                                    text = iopub_msg.get(
                                                        "content", {}
                                                    ).get("text", "")
                                                    if text:
                                                        df_info = json.loads(text)
                                                        break
                                            except Exception:
                                                break
                                except asyncio.TimeoutError:
                                    logger.warning("DataFrame check timed out")
                except Exception as e:
                    logger.warning(f"DataFrame check failed: {e}")
                    # Return placeholder for requested dataframes
                    for df_name in dataframes:
                        df_info.append(
                            {
                                "name": df_name,
                                "exists": False,
                                "error": "Kernel execution failed",
                            }
                        )
            result["dataframes"] = df_info

            self.set_header("Content-Type", "application/json")
            self.write(result)

        except Exception as e:
            logger.error(f"Resource check failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"success": False, "error": str(e)})


class ReadFileHandler(APIHandler):
    """Handler for /read-file endpoint (runs on Jupyter server)."""

    async def post(self):
        """Read file content."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            path = (body.get("path") or "").strip()
            encoding = body.get("encoding") or "utf-8"
            requested_cwd = (body.get("cwd") or "").strip()
            user_workspace_root = body.get("workspaceRoot")

            if not path:
                self.set_status(400)
                self.write({"success": False, "error": "path is required"})
                return

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root, user_workspace_root
            )

            # If no cwd requested, use server_root as default (notebook directory)
            effective_cwd = requested_cwd
            if not effective_cwd:
                abs_server_root = os.path.abspath(server_root)
                if (
                    os.path.commonpath([workspace_root, abs_server_root])
                    == workspace_root
                ):
                    effective_cwd = abs_server_root
                else:
                    effective_cwd = workspace_root

            try:
                resolved_path = _resolve_path_in_workspace(
                    path, workspace_root, effective_cwd
                )
            except ValueError as exc:
                self.set_status(400)
                self.write({"success": False, "error": str(exc)})
                return

            try:
                with open(resolved_path, "r", encoding=encoding) as f:
                    content = f.read()
                result = {
                    "success": True,
                    "path": path,
                    "resolved_path": resolved_path,
                    "content": content,
                    "size": len(content),
                }
            except FileNotFoundError:
                result = {
                    "success": False,
                    "path": path,
                    "error": f"File not found: {path}",
                }
            except Exception as exc:
                result = {
                    "success": False,
                    "path": path,
                    "error": str(exc),
                }

            self.set_header("Content-Type", "application/json")
            self.write(result)

        except Exception as e:
            logger.error(f"Read file failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"success": False, "error": str(e)})


class WriteFileHandler(APIHandler):
    """Handler for /write-file endpoint (runs on Jupyter server)."""

    async def post(self):
        """Write file content after user approval."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            path = (body.get("path") or "").strip()
            content = body.get("content") or ""
            encoding = body.get("encoding") or "utf-8"
            overwrite = bool(body.get("overwrite", False))
            requested_cwd = (body.get("cwd") or "").strip()
            user_workspace_root = body.get("workspaceRoot")

            if not path:
                self.set_status(400)
                self.write({"error": "path is required"})
                return

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root, user_workspace_root
            )

            # If no cwd requested, use server_root as default (notebook directory)
            # This ensures files are saved relative to where Jupyter was started
            effective_cwd = requested_cwd
            if not effective_cwd:
                abs_server_root = os.path.abspath(server_root)
                # Use server_root if it's within workspace_root, otherwise use workspace_root
                if (
                    os.path.commonpath([workspace_root, abs_server_root])
                    == workspace_root
                ):
                    effective_cwd = abs_server_root
                else:
                    effective_cwd = workspace_root

            try:
                resolved_path = _resolve_path_in_workspace(
                    path, workspace_root, effective_cwd
                )
            except ValueError as exc:
                self.set_status(400)
                self.write({"error": str(exc)})
                return

            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None, _write_file, resolved_path, content, encoding, overwrite
            )

            result.update(
                {
                    "path": path,
                    "resolved_path": resolved_path,
                    "overwrite": overwrite,
                }
            )
            self.set_header("Content-Type", "application/json")
            self.write(result)

        except Exception as e:
            logger.error(f"Write file failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class RAGStatusHandler(APIHandler):
    """Handler for /rag/status endpoint using ServiceFactory."""

    async def get(self):
        """Get RAG system status."""
        try:
            factory = _get_service_factory()
            rag_service = factory.get_rag_service()

            status = await rag_service.get_index_status()

            self.set_header("Content-Type", "application/json")
            self.write(status)

        except Exception as e:
            logger.error(f"RAG status failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


# ============ Embedded Config Handlers ============


def _get_config_manager():
    """Lazy import ConfigManager to avoid circular imports."""
    from hdsp_agent_core.managers.config_manager import get_config_manager

    return get_config_manager()


def _is_admin_mode() -> tuple:
    """
    Detect if running in admin mode based on environment variables.

    Returns:
        tuple[bool, str | None]: (is_admin, reason)
    """
    sagemaker_space = os.environ.get("SAGEMAKER_SPACE_NAME")
    hdsp_prj_id = os.environ.get("HDSP_PRJ_ID")

    if sagemaker_space is None and hdsp_prj_id is None:
        return True, "development_environment"
    if sagemaker_space and "pl2wadmprj" in sagemaker_space:
        return True, "sagemaker_admin_space"
    if hdsp_prj_id == "pl2wadmprj":
        return True, "hdsp_admin_project"
    return False, None


def _mask_api_key(key: str) -> str:
    """Mask an API key for safe display."""
    if not key or len(key) < 8:
        return "***" if key else ""
    return key[:4] + "..." + key[-4:]


def _mask_config_keys(config: dict) -> dict:
    """Return a copy of config with API keys masked."""
    import copy

    masked = copy.deepcopy(config)
    key_fields = {"apiKey", "apiKeys"}
    for section_key, section_val in masked.items():
        if isinstance(section_val, dict):
            for field_key in list(section_val.keys()):
                if field_key == "apiKey" and isinstance(section_val[field_key], str):
                    section_val[field_key] = _mask_api_key(section_val[field_key])
                elif field_key == "apiKeys" and isinstance(
                    section_val[field_key], list
                ):
                    section_val[field_key] = [
                        _mask_api_key(k) for k in section_val[field_key]
                    ]
        elif section_key in key_fields and isinstance(section_val, str):
            masked[section_key] = _mask_api_key(section_val)
    return masked


# ============ Health Handler ============


class HealthHandler(APIHandler):
    """Health check handler."""

    async def get(self):
        """Return extension health status."""
        try:
            factory = _get_service_factory()
            mode = factory.mode.value if factory.is_initialized else "not_initialized"

            status = {
                "status": "healthy",
                "extension_version": "2.0.2",
                "mode": mode,
            }

            rag_service = factory.get_rag_service()
            status["rag"] = {
                "ready": rag_service.is_ready(),
            }

            self.write(status)

        except Exception as e:
            logger.error(f"Health check failed: {e}")
            self.write(
                {
                    "status": "degraded",
                    "error": str(e),
                }
            )


class ConfigHandler(APIHandler):
    """GET: full config, POST: save config."""

    async def get(self):
        try:
            cm = _get_config_manager()
            self.write(_mask_config_keys(cm.get_config()))
        except Exception as e:
            logger.error(f"ConfigHandler GET error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            cm = _get_config_manager()
            cm.save_config(body)
            self.write({"status": "ok"})
        except Exception as e:
            logger.error(f"ConfigHandler POST error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


def _get_default_prompts() -> dict:
    """기본 에이전트 프롬프트 반환."""
    from .agent.subagent_prompts import (
        ATHENA_QUERY_SYSTEM_PROMPT,
        PLANNER_SYSTEM_PROMPT,
        PYTHON_DEVELOPER_SYSTEM_PROMPT,
        RESEARCHER_SYSTEM_PROMPT,
    )

    return {
        "planner": PLANNER_SYSTEM_PROMPT,
        "python_developer": PYTHON_DEVELOPER_SYSTEM_PROMPT,
        "researcher": RESEARCHER_SYSTEM_PROMPT,
        "athena_query": ATHENA_QUERY_SYSTEM_PROMPT,
    }


# Frontend fallback string — if this was saved to config, treat as null
_FALLBACK_SENTINEL = "(프롬프트를 불러오는 중...)"


def _resolve_prompts(stored: dict) -> dict:
    """저장된 프롬프트에 기본값을 채워 반환. 폴백 문자열은 무시."""
    defaults = _get_default_prompts()
    result = {}
    for key in defaults:
        val = stored.get(key)
        if val and val != _FALLBACK_SENTINEL:
            result[key] = val
        else:
            result[key] = defaults[key]
    return result


class ConfigPromptsHandler(APIHandler):
    """GET: return prompts (custom if set, otherwise defaults)."""

    async def get(self):
        try:
            cm = _get_config_manager()
            config = cm.get_config()
            stored = config.get("prompts", {})
            self.write(_resolve_prompts(stored))
        except Exception as e:
            logger.error(f"ConfigPromptsHandler error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ConfigIsAdminHandler(APIHandler):
    """GET: return admin mode status."""

    async def get(self):
        try:
            is_admin, reason = _is_admin_mode()
            self.write({"isAdmin": is_admin, "reason": reason})
        except Exception as e:
            logger.error(f"ConfigIsAdminHandler error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ConfigAdminHandler(APIHandler):
    """GET: admin config (API keys masked), POST: update admin config.

    Normal mode: LLM settings hidden (managed by K8s env vars).
    Admin mode: returns prompts/server settings only (LLM settings in localStorage).
    """

    async def get(self):
        try:
            is_admin, _ = _is_admin_mode()
            if not is_admin:
                # 일반모드: LLM 설정 없이 반환
                self.write({"message": "LLM settings managed by system"})
                return
            # 관리자모드: 프롬프트/서버 설정만 서버에서 반환
            cm = _get_config_manager()
            config = cm.get_admin_config()
            masked = _mask_config_keys(config)
            masked["prompts"] = _resolve_prompts(masked.get("prompts", {}))
            self.write(masked)
        except Exception as e:
            logger.error(f"ConfigAdminHandler GET error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})

    async def post(self):
        try:
            is_admin, _ = _is_admin_mode()
            if not is_admin:
                self.set_status(403)
                self.write({"error": "Admin only"})
                return
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            cm = _get_config_manager()
            # 관리자모드: 프롬프트/서버 설정만 서버에 저장 (LLM 설정은 localStorage)
            server_fields = {
                k: v for k, v in body.items() if k in ("prompts", "idleTimeout")
            }
            if server_fields:
                cm.update_admin_config(server_fields)
            self.write({"status": "ok"})
        except Exception as e:
            logger.error(f"ConfigAdminHandler POST error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ConfigUserHandler(APIHandler):
    """GET: user config, POST: update user config."""

    async def get(self):
        try:
            cm = _get_config_manager()
            self.write(cm.get_user_config())
        except Exception as e:
            logger.error(f"ConfigUserHandler GET error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            cm = _get_config_manager()
            cm.update_user_config(body)
            self.write({"status": "ok"})
        except Exception as e:
            logger.error(f"ConfigUserHandler POST error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


# ============ Notebook Generation Handlers ============

# Module-level task store for notebook generation
_notebook_tasks: Dict[str, Dict[str, Any]] = {}  # taskId → task state
_notebook_task_queues: Dict[str, asyncio.Queue] = {}  # taskId → SSE event queue

_NOTEBOOK_SYSTEM_PROMPT = """\
You are a Jupyter notebook generator. Given a user's request, create a well-structured \
Jupyter notebook with markdown explanations and Python code cells.

Output format - use these exact delimiters:

FIRST, output a short English filename (no extension) on the very first line:
---FILENAME---
short_descriptive_name
(e.g. eda_sales_2024, lstm_stock_prediction, pandas_data_cleaning)

THEN, output notebook cells:
---MARKDOWN---
(markdown cell content)
---CODE---
(python code cell content)
---MARKDOWN---
(next markdown cell)
...

Rules:
- The filename must be lowercase, use underscores, 2-5 words, descriptive of the notebook content
- Start with a title markdown cell
- Include explanatory markdown between code cells
- Write complete, runnable Python code
- Add comments in code for clarity
- Do NOT wrap cell content in code fences
- CRITICAL: All markdown cell text MUST be written entirely in Korean (한국어). No English in markdown cells.
- CRITICAL: Code comments MUST also be in Korean (한국어)
- Do NOT use Chinese characters (한자 금지)
- Variable names, function names, and Python keywords remain in English (코드 자체는 영어 유지)
"""


def _parse_notebook_cells(llm_response: str) -> list[dict]:
    """Parse LLM response into a list of {cell_type, source} dicts."""
    import re

    cells: list[dict] = []
    # Split by ---MARKDOWN--- or ---CODE--- delimiters
    parts = re.split(r"---(?:MARKDOWN|CODE)---", llm_response)
    types = re.findall(r"---(MARKDOWN|CODE)---", llm_response)

    for cell_type_str, content in zip(types, parts[1:]):
        source = content.strip()
        if not source:
            continue
        cell_type = "markdown" if cell_type_str == "MARKDOWN" else "code"
        cells.append({"cell_type": cell_type, "source": source})

    # Fallback: if no delimiters found, treat entire response as a single markdown cell
    if not cells:
        cells.append({"cell_type": "markdown", "source": llm_response.strip()})

    return cells


def _extract_filename(llm_response: str) -> str | None:
    """Extract the LLM-generated filename from ---FILENAME--- block."""
    import re

    m = re.search(r"---FILENAME---\s*\n\s*(.+)", llm_response)
    if not m:
        return None
    raw = m.group(1).strip()
    # Sanitize: keep only alphanumeric, underscores, hyphens
    sanitized = re.sub(r"[^\w-]", "_", raw).strip("_")
    # Collapse multiple underscores
    sanitized = re.sub(r"_+", "_", sanitized)
    return sanitized[:60] if sanitized else None


async def _update_notebook_task(task_id: str, updates: Dict[str, Any]) -> None:
    """Update task state and push event to SSE queue."""
    task = _notebook_tasks.get(task_id)
    if not task:
        return
    task.update(updates)
    queue = _notebook_task_queues.get(task_id)
    if queue:
        await queue.put(dict(task))


async def _generate_notebook_task(
    task_id: str,
    prompt: str,
    output_dir: str,
    llm_overrides: dict | None = None,
) -> None:
    """Background coroutine: call LLM, parse response, write .ipynb file."""
    from datetime import datetime, timezone

    try:
        await _update_notebook_task(
            task_id,
            {
                "status": "running",
                "progress": 0,
                "message": "LLM에 노트북 구조 요청 중...",
                "startedAt": datetime.now(timezone.utc).isoformat(),
            },
        )

        # Get LLM config
        cm = _get_config_manager()
        config_dict = cm.get_config()

        # Apply LLM overrides (from admin localStorage or env vars)
        if llm_overrides:
            config_dict.update(llm_overrides)

        # Validate apiKey is not masked or empty
        from hdsp_agent_core.managers.config_manager import _is_masked_api_key

        vllm_cfg = config_dict.get("vllm", {})
        api_key = vllm_cfg.get("apiKey", "")
        if not api_key:
            raise ValueError(
                "LLM API 키가 설정되지 않았습니다. "
                "관리자 설정 패널에서 API 키를 입력해주세요."
            )
        if _is_masked_api_key(api_key):
            raise ValueError(
                "API 키가 손상되었습니다. "
                "관리자 설정 패널에서 API 키를 다시 입력해주세요."
            )

        from hdsp_agent_core.llm.service import LLMService

        llm = LLMService(config_dict)

        # Call LLM
        full_prompt = f"{_NOTEBOOK_SYSTEM_PROMPT}\n\nUser request:\n{prompt}"
        llm_response = await llm.generate_response(full_prompt)

        # Check if cancelled during LLM call
        task = _notebook_tasks.get(task_id)
        if not task or task.get("status") == "cancelled":
            return

        await _update_notebook_task(
            task_id, {"progress": 50, "message": "LLM 응답 파싱 중..."}
        )

        # Parse response into cells
        parsed_cells = _parse_notebook_cells(llm_response)

        # Build notebook
        import nbformat

        nb = nbformat.v4.new_notebook()
        for cell_info in parsed_cells:
            if cell_info["cell_type"] == "code":
                nb.cells.append(nbformat.v4.new_code_cell(cell_info["source"]))
            else:
                nb.cells.append(nbformat.v4.new_markdown_cell(cell_info["source"]))

        await _update_notebook_task(
            task_id, {"progress": 80, "message": "노트북 파일 저장 중..."}
        )

        # Generate filename from LLM response, fallback to prompt-based
        import re as _re

        llm_filename = _extract_filename(llm_response)
        if llm_filename:
            safe_name = llm_filename
        else:
            safe_name = _re.sub(r"[^\w\s-]", "", prompt[:40]).strip()
            safe_name = _re.sub(r"\s+", "_", safe_name) or "notebook"
        filename = f"{safe_name}_{task_id[:8]}.ipynb"
        filepath = os.path.join(output_dir, filename)

        with open(filepath, "w", encoding="utf-8") as f:
            nbformat.write(nb, f)

        now = datetime.now(timezone.utc).isoformat()
        await _update_notebook_task(
            task_id,
            {
                "status": "completed",
                "progress": 100,
                "message": "노트북 생성 완료",
                "notebookPath": filename,
                "completedAt": now,
            },
        )

    except Exception as e:
        logger.error(
            f"Notebook generation failed for task {task_id}: {e}",
            exc_info=True,
        )
        from datetime import datetime, timezone

        await _update_notebook_task(
            task_id,
            {
                "status": "failed",
                "error": str(e),
                "message": f"생성 실패: {e}",
                "completedAt": datetime.now(timezone.utc).isoformat(),
            },
        )
    finally:
        # Send sentinel to close SSE stream
        queue = _notebook_task_queues.get(task_id)
        if queue:
            await queue.put(None)


class NotebookEnrichHandler(APIHandler):
    """POST /hdsp-agent/notebook/enrich — AST-based cell analysis + local module resolution."""

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            notebook_path = (body.get("notebookPath") or "").strip()
            cells_input = body.get("cells") or []

            if not cells_input:
                self.write(
                    {"cells": [], "crossCellDependencies": [], "moduleSummary": {}}
                )
                return

            from hdsp_agent_core.core.code_validator import CodeValidator

            validator = CodeValidator()

            # Resolve notebook directory for local module lookup
            notebook_dir = ""
            if notebook_path:
                server_root = self.settings.get("server_root_dir", os.getcwd())
                server_root = os.path.expanduser(server_root)
                abs_notebook = os.path.join(os.path.abspath(server_root), notebook_path)
                notebook_dir = os.path.dirname(abs_notebook)

            # --- Per-cell AST analysis ---
            enriched_cells = []
            all_defined_by_cell: list[list[str]] = []  # cell_index -> defined_names

            for cell_data in cells_input:
                idx = cell_data.get("index", 0)
                content = cell_data.get("content", "")

                deps = validator.analyze_dependencies(content)
                all_defined_by_cell.append(deps.defined_names)

                enriched_cells.append(
                    {
                        "index": idx,
                        "dependencies": deps.to_dict(),
                        "localModuleSources": {},
                    }
                )

            # --- Cross-cell dependency calculation ---
            cross_cell_deps = []
            cumulative_defined: set[str] = set()
            for i, cell_data in enumerate(enriched_cells):
                if i == 0:
                    cumulative_defined.update(all_defined_by_cell[0])
                    continue
                used = set(cell_data["dependencies"]["used_names"])
                for prev_idx in range(i):
                    prev_defined = set(all_defined_by_cell[prev_idx])
                    shared = used & prev_defined
                    # Exclude names also defined in current cell (local override)
                    shared -= set(all_defined_by_cell[i])
                    if shared:
                        cross_cell_deps.append(
                            {
                                "cellIndex": cells_input[i].get("index", i),
                                "usesFrom": cells_input[prev_idx].get(
                                    "index", prev_idx
                                ),
                                "variables": sorted(shared),
                            }
                        )
                cumulative_defined.update(all_defined_by_cell[i])

            # --- Local module resolution ---
            module_summary = {}
            total_source_bytes = 0
            MAX_SOURCE_BYTES = 30 * 1024  # 30KB budget
            MAX_LINES_PER_MODULE = 200
            seen_modules: set[str] = set()

            for cell_data in enriched_cells:
                deps = cell_data["dependencies"]
                from_imports = deps.get("from_imports", {})

                for module_name in from_imports:
                    if module_name in seen_modules or not module_name:
                        continue
                    seen_modules.add(module_name)

                    if not notebook_dir:
                        continue
                    if total_source_bytes >= MAX_SOURCE_BYTES:
                        break

                    resolved = _resolve_local_module(module_name, notebook_dir)
                    if not resolved:
                        continue

                    try:
                        with open(resolved, "r", encoding="utf-8") as f:
                            lines = f.readlines()
                        truncated = len(lines) > MAX_LINES_PER_MODULE
                        if truncated:
                            lines = lines[:MAX_LINES_PER_MODULE]
                        source = "".join(lines)
                        if truncated:
                            source += "\n# ... [truncated] ...\n"

                        remaining = MAX_SOURCE_BYTES - total_source_bytes
                        if len(source.encode("utf-8")) > remaining:
                            source = (
                                source[:remaining]
                                + "\n# ... [truncated by budget] ...\n"
                            )
                            truncated = True

                        total_source_bytes += len(source.encode("utf-8"))

                        cell_data["localModuleSources"][module_name] = source
                        module_summary[module_name] = {
                            "path": os.path.relpath(resolved, notebook_dir),
                            "lines": len(lines),
                            "truncated": truncated,
                        }
                    except (OSError, UnicodeDecodeError):
                        pass

            self.write(
                {
                    "cells": enriched_cells,
                    "crossCellDependencies": cross_cell_deps,
                    "moduleSummary": module_summary,
                }
            )

        except Exception as e:
            logger.exception("NotebookEnrichHandler error")
            self.set_status(500)
            self.write({"error": str(e)})


def _resolve_local_module(module_name: str, notebook_dir: str) -> str | None:
    """Return file path if module_name is a local module relative to notebook_dir, else None."""
    # Relative import (starts with '.')
    if module_name.startswith("."):
        rel_path = module_name.lstrip(".").replace(".", "/")
        candidate = os.path.join(notebook_dir, f"{rel_path}.py")
        if os.path.isfile(candidate):
            return candidate
        return None

    # Absolute path: look for file in notebook_dir
    candidate = os.path.join(notebook_dir, module_name.replace(".", "/") + ".py")
    if os.path.isfile(candidate):
        return candidate

    # Package __init__.py
    candidate_pkg = os.path.join(
        notebook_dir, module_name.replace(".", "/"), "__init__.py"
    )
    if os.path.isfile(candidate_pkg):
        return candidate_pkg

    return None


class NotebookGenerateHandler(APIHandler):
    """POST /hdsp-agent/notebook/generate — start notebook generation task."""

    async def post(self):
        try:
            from datetime import datetime, timezone

            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            prompt = body.get("prompt", "").strip()
            if not prompt:
                self.set_status(400)
                self.write({"error": "prompt is required"})
                return

            task_id = str(uuid4())
            output_dir = body.get("outputDir") or os.getcwd()

            # Resolve LLM overrides based on admin/normal mode
            llm_overrides = None
            is_admin, _ = _is_admin_mode()
            if is_admin and "llmConfig" in body:
                llm_overrides = {}
                llm_config = body["llmConfig"]
                for key in ("provider", "vllm", "summarization", "embedding"):
                    if key in llm_config:
                        llm_overrides[key] = llm_config[key]
            elif not is_admin:
                from hdsp_agent_core.managers.config_manager import ConfigManager as _CM

                env_config = _CM.get_env_llm_config()
                if env_config:
                    llm_overrides = env_config
                else:
                    self.set_status(400)
                    self.write(
                        {
                            "error": "LLM 설정이 구성되지 않았습니다. 관리자에게 문의하세요."
                        }
                    )
                    return

            now = datetime.now(timezone.utc).isoformat()
            task_state = {
                "taskId": task_id,
                "prompt": prompt,
                "status": "pending",
                "progress": 0,
                "message": "작업이 시작되었습니다",
                "result": None,
                "error": None,
                "notebookPath": None,
                "createdAt": now,
                "startedAt": None,
                "completedAt": None,
            }
            _notebook_tasks[task_id] = task_state
            _notebook_task_queues[task_id] = asyncio.Queue()

            # Spawn background task
            asyncio.create_task(
                _generate_notebook_task(task_id, prompt, output_dir, llm_overrides)
            )

            self.write(
                {
                    "taskId": task_id,
                    "status": "pending",
                    "message": "작업이 시작되었습니다",
                }
            )
        except Exception as e:
            logger.error(f"NotebookGenerate error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class TaskStatusHandler(APIHandler):
    """GET /hdsp-agent/task/<taskId>/status — poll task status."""

    async def get(self, task_id: str):
        task = _notebook_tasks.get(task_id)
        if not task:
            self.set_status(404)
            self.write({"error": "Task not found"})
            return
        self.write(task)


class TaskStreamHandler(APIHandler):
    """GET /hdsp-agent/task/<taskId>/stream — SSE stream of task status updates."""

    async def get(self, task_id: str):
        task = _notebook_tasks.get(task_id)
        if not task:
            self.set_status(404)
            self.write({"error": "Task not found"})
            return

        queue = _notebook_task_queues.get(task_id)
        if not queue:
            self.set_status(404)
            self.write({"error": "Task stream not found"})
            return

        self.set_header("Content-Type", "text/event-stream")
        self.set_header("Cache-Control", "no-cache")
        self.set_header("Connection", "keep-alive")
        self.set_header("X-Accel-Buffering", "no")

        # Send current state immediately
        self.write(f"data: {json.dumps(task)}\n\n")
        await self.flush()

        # If already terminal, close
        if task.get("status") in ("completed", "failed", "cancelled"):
            self.finish()
            return

        while True:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=15.0)
            except asyncio.TimeoutError:
                # Heartbeat
                self.write(": heartbeat\n\n")
                await self.flush()
                continue

            if event is None:
                # Sentinel — stream done
                break

            self.write(f"data: {json.dumps(event)}\n\n")
            await self.flush()

            if event.get("status") in ("completed", "failed", "cancelled"):
                break

        self.finish()


class TaskCancelHandler(APIHandler):
    """POST /hdsp-agent/task/<taskId>/cancel — cancel a running task."""

    async def post(self, task_id: str):
        task = _notebook_tasks.get(task_id)
        if not task:
            self.set_status(404)
            self.write({"error": "Task not found"})
            return

        from datetime import datetime, timezone

        await _update_notebook_task(
            task_id,
            {
                "status": "cancelled",
                "message": "작업이 취소되었습니다",
                "completedAt": datetime.now(timezone.utc).isoformat(),
            },
        )

        # Push sentinel to close SSE stream
        queue = _notebook_task_queues.get(task_id)
        if queue:
            await queue.put(None)

        self.write({"status": "cancelled", "taskId": task_id})


# ============ Embedded Agent Handlers ============

# Module-level agent session management
_active_agents: dict = {}  # thread_id → AgentRunner (실행 중만)
_agent_locks: dict = {}

# Global checkpointer & agent cache (Phase 1: 대화 지속성)
_global_checkpointer = _MemorySaver() if _LANGGRAPH_AVAILABLE else None  # 모든 스레드 공유 (thread_id로 네임스페이스 분리)
_agent_cache: dict = {}  # cache_key → CompiledStateGraph
_thread_metadata: dict = {}  # thread_id → {emitted_contents: set, ...}


def _get_agent_runner(thread_id: str):
    """Get an active AgentRunner by thread_id."""
    return _active_agents.get(thread_id)


def _get_agent_cache_key(config_dict: dict, workspace_root: str) -> str:
    """Agent 캐시 키 생성 — 동일 모델/엔드포인트/모드/프롬프트면 그래프 재사용."""
    import hashlib

    vllm = config_dict.get("vllm", {})
    # 관리자 커스텀 프롬프트가 변경되면 캐시 무효화
    prompts = config_dict.get("prompts", {})
    data = json.dumps(
        {
            "model": vllm.get("model", ""),
            "endpoint": vllm.get("endpoint", ""),
            "mode": config_dict.get("mode", "default"),
            "agentMode": config_dict.get("agentMode", "multi"),
            "prompts": prompts,
        },
        sort_keys=True,
    )
    return hashlib.md5(f"{data}|{workspace_root}".encode()).hexdigest()


def _inject_workspace_root(body: dict, settings: dict) -> dict:
    """Inject resolved workspaceRoot into request body."""
    server_root = settings.get("server_root_dir", os.getcwd())
    server_root = os.path.expanduser(server_root)
    resolved_root = _resolve_workspace_root(server_root)
    workspace_root = body.get("workspaceRoot")

    if not workspace_root or workspace_root == ".":
        body["workspaceRoot"] = resolved_root
    elif not os.path.isabs(workspace_root):
        body["workspaceRoot"] = os.path.join(resolved_root, workspace_root)
    return body


class LangChainStreamHandler(APIHandler):
    """POST: run agent with SSE streaming."""

    async def post(self):
        try:
            from .agent.agent_factory import (
                AgentFactory,
                AgentEvent,
                config_from_dict,
            )
            from .tools import NotebookContextManager

            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            body = _inject_workspace_root(body, self.settings)

            body_len = len(self.request.body) if self.request.body else 0
            logger.info("LangChainStream: request body size=%d bytes", body_len)

            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")
            self.set_header("X-Accel-Buffering", "no")

            thread_id = body.get("threadId", "")
            request_text = body.get("request", "")
            workspace_root = body.get("workspaceRoot", "")

            # /reset 명령 감지
            if request_text.strip().startswith("/reset"):
                effective_thread_id = thread_id or ""
                _active_agents.pop(effective_thread_id, None)
                _thread_metadata.pop(effective_thread_id, None)
                try:
                    storage = getattr(_global_checkpointer, "storage", {})
                    storage.pop(effective_thread_id, None)
                except Exception:
                    pass
                self.write(
                    f"event: complete\ndata: {json.dumps({'thread_id': effective_thread_id, 'reset': True})}\n\n"
                )
                await self.flush()
                self.finish()
                return

            # Build agent config from request body
            is_admin, _ = _is_admin_mode()
            cm = _get_config_manager()
            config_dict = cm.get_config()
            config_dict.update(
                {
                    k: v
                    for k, v in body.items()
                    if k in ("temperature", "mode", "autoApprove", "agentMode")
                }
            )

            if is_admin and "llmConfig" in body:
                # 관리자모드: 프론트엔드 localStorage에서 받은 LLM 설정 사용
                llm_config = body["llmConfig"]
                for key in (
                    "provider",
                    "vllm",
                    "summarization",
                    "embedding",
                    "prompts",
                    "idleTimeout",
                ):
                    if key in llm_config:
                        config_dict[key] = llm_config[key]
            elif not is_admin:
                # 일반모드: 환경변수에서 LLM 설정 읽기
                from hdsp_agent_core.managers.config_manager import ConfigManager as _CM

                env_config = _CM.get_env_llm_config()
                if env_config:
                    config_dict.update(env_config)
                else:
                    error_msg = "LLM 설정이 구성되지 않았습니다. 관리자에게 문의하세요."
                    self.write(f"data: {json.dumps({'error': error_msg})}\n\n")
                    self.write(
                        f"event: complete\ndata: {json.dumps({'thread_id': ''})}\n\n"
                    )
                    await self.flush()
                    self.finish()
                    return

            agent_config = config_from_dict(config_dict)

            # API 키 사전 검증: 빈/마스킹된 키로 불필요한 LLM 호출 방지
            from hdsp_agent_core.managers.config_manager import _is_masked_api_key

            if not agent_config.api_key or _is_masked_api_key(agent_config.api_key):
                if agent_config.api_key and _is_masked_api_key(agent_config.api_key):
                    error_msg = "API 키가 손상되었습니다. 설정 패널에서 API 키를 다시 입력해주세요."
                else:
                    error_msg = "LLM API 키가 설정되지 않았습니다. 설정 패널에서 API 키를 입력해주세요."
                self.write(f"data: {json.dumps({'error': error_msg})}\n\n")
                self.write(
                    f"event: complete\ndata: {json.dumps({'thread_id': ''})}\n\n"
                )
                await self.flush()
                self.finish()
                return

            # SSE event queue for streaming
            event_queue: asyncio.Queue = asyncio.Queue()

            async def on_event(event: AgentEvent):
                await event_queue.put(event)

            notebook_context = NotebookContextManager(
                kernel_manager=None,
                contents_manager=getattr(self, "contents_manager", None),
            )

            # Initialize notebook context from frontend's notebookContext
            nb_ctx = body.get("notebookContext", {})
            nb_path = nb_ctx.get("notebook_path", "") if nb_ctx else ""
            if nb_path:
                cm = getattr(self, "contents_manager", None)
                loaded = False
                if cm:
                    try:
                        nb_model = cm.get(nb_path, content=True, type="notebook")
                        notebook_context.set_notebook(nb_path, nb_model)
                        loaded = True
                    except Exception as e:
                        logger.warning("Failed to load notebook %s: %s", nb_path, e)

                if not loaded:
                    # Fallback: build minimal model from frontend data
                    recent_cells = nb_ctx.get("recent_cells", [])
                    minimal_model = {
                        "content": {
                            "cells": [
                                {
                                    "cell_type": "code",
                                    "source": c.get("source", ""),
                                    "outputs": [],
                                    "metadata": {},
                                }
                                for c in recent_cells
                            ],
                            "metadata": {"kernelspec": {"name": "python3"}},
                        }
                    }
                    notebook_context.set_notebook(nb_path, minimal_model)
                logger.info(
                    "LangChainStream: notebook context set for %s (loaded=%s)",
                    nb_path,
                    loaded,
                )
            else:
                logger.info(
                    "LangChainStream: notebookContext=%s, no notebook_path",
                    bool(nb_ctx),
                )

            # Agent 캐시 키 생성 및 그래프 재사용
            from .agent.agent_factory import AgentRunner

            cache_key = _get_agent_cache_key(config_dict, workspace_root)
            effective_thread_id = thread_id or str(uuid4())

            if cache_key in _agent_cache:
                # 캐시된 그래프 재사용 → AgentRunner만 새로 생성
                runner = AgentRunner(
                    agent=_agent_cache[cache_key],
                    config=agent_config,
                    on_event=on_event,
                    thread_id=effective_thread_id,
                )
            else:
                # 새 agent 생성 (global checkpointer 전달)
                factory = AgentFactory(
                    notebook_context=notebook_context,
                    workspace_root=workspace_root,
                    on_event=on_event,
                )
                runner = factory.create_agent(
                    agent_config,
                    checkpointer=_global_checkpointer,
                    thread_id=effective_thread_id,
                )
                _agent_cache[cache_key] = runner.agent

            logger.info(
                "LangChainStream: provider=%s model=%s base_url=%s thread=%s cached=%s",
                agent_config.provider,
                agent_config.model,
                getattr(agent_config, "base_url", None),
                effective_thread_id,
                cache_key in _agent_cache,
            )
            _active_agents[effective_thread_id] = runner

            # Phase 2: 기존 상태 확인 + Todo 리셋
            config = {
                "configurable": {"thread_id": effective_thread_id},
                "recursion_limit": 1000,
            }
            previous_todos_context = None
            existing_todos = []
            try:
                existing_state = await runner.agent.aget_state(config)
                if existing_state and hasattr(existing_state, "values"):
                    existing_todos = existing_state.values.get("todos", [])
                    if existing_todos:
                        await asyncio.to_thread(
                            runner.agent.update_state,
                            config,
                            {"todos": [], "todo_active": False},
                        )
                        completed = [
                            t.get("content", "") if isinstance(t, dict) else t.content
                            for t in existing_todos
                            if (t.get("status") if isinstance(t, dict) else t.status)
                            == "completed"
                        ]
                        if completed:
                            items_summary = ", ".join(completed[:5]) + (
                                "..." if len(completed) > 5 else ""
                            )
                            previous_todos_context = (
                                f"[SYSTEM] 이전 todo list 완료. 완료 작업: {items_summary}. "
                                f"새 작업을 시작합니다. 간단한 작업이면 write_todos 없이 바로 실행하세요."
                            )
            except Exception as e:
                logger.warning("State check failed: %s", e)

            # Todos 리셋 SSE 이벤트 전송
            if existing_todos:
                await event_queue.put(
                    AgentEvent(type="todos", data={"todos": [], "reset": True})
                )

            # 이전 맥락 주입
            full_prompt = request_text
            if previous_todos_context:
                full_prompt = f"{previous_todos_context}\n\n{request_text}"

            # Run agent in background, stream events via queue
            async def run_agent():
                try:
                    await runner.run(full_prompt)
                except Exception as e:
                    logger.error(f"LangChainStream run error: {e}", exc_info=True)
                    await event_queue.put(
                        AgentEvent(type="error", data={"message": str(e)})
                    )
                finally:
                    await event_queue.put(None)  # sentinel

            task = asyncio.create_task(run_agent())

            import time as _time

            _stream_start = _time.monotonic()
            _HEARTBEAT_TIMEOUT = 15  # seconds per queue.get
            _ABSOLUTE_TIMEOUT = 300  # 5 min absolute

            _hitl_pending = False

            try:
                while True:
                    try:
                        event = await asyncio.wait_for(
                            event_queue.get(), timeout=_HEARTBEAT_TIMEOUT
                        )
                    except asyncio.TimeoutError:
                        elapsed = _time.monotonic() - _stream_start
                        if elapsed > _ABSOLUTE_TIMEOUT:
                            logger.error("LangChainStream absolute timeout exceeded")
                            self.write(
                                f"data: {json.dumps({'error': 'Agent timeout (5 min)'})}\n\n"
                            )
                            # 타임아웃 후에도 complete 이벤트 전송 — 프론트엔드 정상 종료 보장
                            self.write(
                                f"event: complete\ndata: {json.dumps({'thread_id': effective_thread_id})}\n\n"
                            )
                            await self.flush()
                            break
                        self.write(": heartbeat\n\n")
                        await self.flush()
                        continue
                    if event is None:
                        break

                    etype = event.type
                    edata = event.data or {}

                    if etype == "start":
                        self.write(
                            f"data: {json.dumps({'status': '에이전트 시작'})}\n\n"
                        )
                    elif etype == "progress":
                        msg = edata.get("message", "Thinking...")
                        icon = edata.get("icon")
                        payload_progress: dict = {"status": msg}
                        if icon:
                            payload_progress["icon"] = icon
                        if edata.get("turn") is not None:
                            payload_progress["turn"] = edata["turn"]
                        if edata.get("step") is not None:
                            payload_progress["step"] = edata["step"]
                        self.write(f"data: {json.dumps(payload_progress)}\n\n")
                    elif etype == "tool_call":
                        name = edata.get("name", "unknown")
                        # 셀 생성 도구 + 멀티에이전트 도구만 tool_call SSE 전송
                        if name in (
                            "jupyter_cell",
                            "jupyter_markdown",
                            "shell_execute",
                            "file_write",
                            "task",
                            "ask_user_tool",
                            "final_summary_tool",
                        ):
                            args = edata.get("arguments", {})
                            if not isinstance(args, dict):
                                args = {}
                            payload: dict = {"tool": name}
                            if name == "jupyter_markdown":
                                payload["content"] = args.get("content", "")
                            elif name == "shell_execute":
                                payload["command"] = args.get("command", "")
                                payload["code"] = args.get("command", "")
                            elif name == "task":
                                payload["agent_name"] = args.get(
                                    "subagent_type", args.get("agent_name", "")
                                )
                                payload["description"] = args.get("description", "")
                            elif name == "final_summary_tool":
                                payload["summary"] = args.get("summary", "")
                                payload["next_items"] = args.get("next_items", [])
                            else:
                                payload["code"] = args.get("code", "")
                            self.write(
                                f"event: tool_call\ndata: {json.dumps(payload)}\n\n"
                            )
                    elif etype == "tool_result":
                        name = edata.get("name", "unknown")
                        # final_summary_tool 결과를 별도 SSE 이벤트로 전송
                        if name in ("final_summary_tool", "final_summary"):
                            result_data = edata.get("result", {})
                            tool_output = ensure_str(result_data.get("data", ""))
                            summary_data = safe_parse_json(tool_output) or {
                                "summary": tool_output
                            }
                            self.write(
                                f"event: summary\ndata: {safe_json_dumps(summary_data)}\n\n"
                            )
                        self.write(
                            f"data: {json.dumps({'status': f'{name} 완료'})}\n\n"
                        )
                    elif etype == "stream":
                        content = edata.get("content", "")
                        if content:
                            self.write(f"data: {json.dumps({'content': content})}\n\n")
                    elif etype == "complete":
                        # Response was already streamed via 'stream' events,
                        # just send the completion signal.
                        self.write(
                            f"event: complete\ndata: {json.dumps({'thread_id': effective_thread_id})}\n\n"
                        )
                    elif etype == "hitl_request":
                        _hitl_pending = True
                        # hitl_request에 thread_id 보장
                        if "thread_id" not in edata:
                            edata["thread_id"] = effective_thread_id
                        hitl_json = json.dumps(edata)
                        logger.warning(
                            "HITL_SSE: sending hitl_request event, action=%s, data_len=%d, thread_id=%s",
                            edata.get("action", "?"),
                            len(hitl_json),
                            edata.get("thread_id", "?"),
                        )
                        self.write(f"event: hitl_request\ndata: {hitl_json}\n\n")
                    elif etype == "todos":
                        todos_list = edata.get("todos", [])
                        self.write(
                            f"event: todos\ndata: {json.dumps({'todos': todos_list})}\n\n"
                        )
                    elif etype == "debug_clear":
                        self.write(f"event: debug_clear\ndata: {json.dumps({})}\n\n")
                    elif etype == "done":
                        edata.setdefault("thread_id", effective_thread_id)
                        self.write(f"event: done\ndata: {json.dumps(edata)}\n\n")
                    elif etype == "cancelled":
                        edata.setdefault("thread_id", effective_thread_id)
                        self.write(f"event: cancelled\ndata: {json.dumps(edata)}\n\n")
                    elif etype == "error":
                        msg = edata.get("error", edata.get("message", "Unknown error"))
                        self.write(f"data: {json.dumps({'error': str(msg)})}\n\n")
                    else:
                        self.write(f"data: {json.dumps({'status': str(edata)})}\n\n")

                    await self.flush()
            finally:
                # hitl_request 대기 중이면 runner를 유지 + thread_metadata 저장
                if _hitl_pending:
                    _thread_metadata.setdefault(effective_thread_id, {})[
                        "emitted_contents"
                    ] = runner.emitted_content_hashes.copy()
                else:
                    _active_agents.pop(effective_thread_id, None)
                if not task.done():
                    task.cancel()

        except Exception as e:
            logger.error(f"LangChainStream error: {e}", exc_info=True)
            self.write(f"data: {json.dumps({'error': str(e)})}\n\n")
        finally:
            self.finish()


def _transform_decisions_for_middleware(
    frontend_decisions: list,
    pending_tool_names: list[str] | None = None,
) -> list:
    """프론트엔드 decision → HumanInTheLoopMiddleware 포맷.

    Args:
        frontend_decisions: 프론트엔드에서 전달된 decision 목록
        pending_tool_names: 인터럽트된 도구 이름 목록 (state에서 추출)
    """
    result = []
    for i, d in enumerate(frontend_decisions):
        dtype = d.get("type", "approve")
        logger.debug(
            "TRANSFORM_DECISION: type=%s, keys=%s",
            dtype,
            list(d.keys()),
        )
        if dtype == "approve":
            result.append({"type": "approve"})
        elif dtype == "edit":
            args = d.get("args", {})
            exec_result = args.get("execution_result", {})
            logger.debug(
                "TRANSFORM_DECISION edit: args_keys=%s, exec_result_keys=%s, "
                "success=%s, error=%s",
                list(args.keys()) if isinstance(args, dict) else type(args),
                list(exec_result.keys())
                if isinstance(exec_result, dict)
                else type(exec_result),
                exec_result.get("success") if isinstance(exec_result, dict) else "N/A",
                exec_result.get("error", "")[:100]
                if isinstance(exec_result, dict)
                else "N/A",
            )
            if isinstance(exec_result, dict) and (
                exec_result.get("success") is False or exec_result.get("error")
            ):
                # 실행 실패 → reject로 변환하여 에러를 LLM에 전달
                logger.debug("TRANSFORM_DECISION: -> REJECT (execution failed)")
                result.append(
                    {
                        "type": "reject",
                        "message": json.dumps({"execution_result": exec_result}),
                    }
                )
            else:
                # 실행 성공 → edit (execution_result 포함하여 도구에 전달)
                tool_name = (
                    pending_tool_names[i]
                    if pending_tool_names and i < len(pending_tool_names)
                    else "jupyter_cell"
                )
                logger.debug(
                    "TRANSFORM_DECISION: -> EDIT (execution succeeded, tool=%s)",
                    tool_name,
                )
                result.append(
                    {
                        "type": "edit",
                        "edited_action": {"name": tool_name, "args": args},
                    }
                )
        elif dtype == "reject":
            result.append(
                {"type": "reject", "message": d.get("feedback", "User rejected")}
            )
        else:
            result.append({"type": "approve"})
    return result


class LangChainResumeHandler(APIHandler):
    """POST: resume agent after HITL decision with SSE streaming."""

    async def post(self):
        try:
            from langgraph.types import Command

            from .agent.agent_factory import _transform_interrupt_to_frontend

            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            body = _inject_workspace_root(body, self.settings)

            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")
            self.set_header("X-Accel-Buffering", "no")

            thread_id = body.get("threadId", "")
            decisions = body.get("decisions", [])
            _hitl_pending = False

            runner = _get_agent_runner(thread_id)
            if not runner:
                self.write(
                    f"data: {json.dumps({'error': '세션을 찾을 수 없습니다.', 'code': 'CHECKPOINT_NOT_FOUND'})}\n\n"
                )
                self.finish()
                return

            config = {
                "configurable": {"thread_id": thread_id},
                "recursion_limit": 1000,
            }

            # decisions 포맷 변환 + 딕셔너리로 감싸기
            # HumanInTheLoopMiddleware는 interrupt된 tool call 수만큼
            # decisions를 요구하므로, 프론트엔드가 보낸 단일 decision을
            # hanging tool call 개수에 맞게 확장.
            # 가장 신뢰할 수 있는 방법: agent state에서 직접 pending interrupt 수를 읽음
            actual_interrupt_count = 0
            pending_tool_names: list[str] = []
            try:
                pre_state = await runner.agent.aget_state(config)
                if pre_state.tasks:
                    for ts in pre_state.tasks:
                        if ts.interrupts:
                            hitl_val = ts.interrupts[0].value
                            if isinstance(hitl_val, dict):
                                action_requests = hitl_val.get("action_requests", [])
                                actual_interrupt_count = len(action_requests)
                                for ar in action_requests:
                                    pending_tool_names.append(ar.get("name", "unknown"))
                            break
            except Exception as exc:
                logger.warning("LangChainResume: aget_state failed: %s", exc)
            transformed = _transform_decisions_for_middleware(
                decisions, pending_tool_names
            )
            # fallback: 프론트엔드가 보낸 actionCount 사용
            action_count = actual_interrupt_count or body.get("actionCount", 1)
            logger.warning(
                "LangChainResume: decisions=%d, actionCount=%d (actual=%d), transformed=%d",
                len(decisions),
                action_count,
                actual_interrupt_count,
                len(transformed),
            )
            if len(transformed) == 1 and action_count > 1:
                transformed = transformed * action_count
                logger.warning(
                    "LangChainResume: expanded to %d decisions", len(transformed)
                )

            # 코드 히스토리 기록: edit + 성공한 실행 결과 추적
            try:
                from .agent.code_history_middleware import track_tool_execution

                for i, d in enumerate(decisions):
                    if d.get("type") == "edit":
                        args = d.get("args", {})
                        exec_result = args.get("execution_result", {})
                        exec_failed = isinstance(exec_result, dict) and (
                            exec_result.get("success") is False
                            or exec_result.get("error")
                        )
                        if not exec_failed:
                            tool_name = (
                                pending_tool_names[i]
                                if i < len(pending_tool_names)
                                else ""
                            )
                            if tool_name in ("jupyter_cell", "file_write"):
                                track_tool_execution(tool_name, args, thread_id)
            except Exception as exc:
                logger.debug("CodeHistory tracking failed: %s", exc)

            resume_value = {"decisions": transformed}

            import time as _time

            _resume_start = _time.monotonic()
            _RESUME_ABSOLUTE_TIMEOUT = 300  # 5분
            _resume_timed_out = False

            try:
                from .agent.agent_factory import (
                    _dbg,
                    _get_tool_status_message,
                    _repair_summary_json_content,
                )

                # reasoning filter: on_chat_model_start/end 버퍼링
                _stream_buffer: list[str] = []
                # Turn/step tracking for resume
                _iteration_r: int = (
                    runner.iteration if hasattr(runner, "iteration") else 0
                )
                _tool_count_r: int = (
                    runner._tool_count if hasattr(runner, "_tool_count") else 0
                )
                # Resume 시 dedup 복원
                _emitted_hashes: set = set()
                meta = _thread_metadata.get(thread_id, {})
                if "emitted_contents" in meta:
                    _emitted_hashes = meta["emitted_contents"].copy()
                # Auto-terminate 상태
                _last_todos_data: list = []
                _all_todos_completed: bool = False
                # Subagent tracking: task 도구 실행 중 서브에이전트 LLM 응답 필터링
                _inside_subagent: bool = False

                # 실행 재개 상태 메시지
                _dbg(
                    f"=== RESUME START === thread_id={thread_id} decisions={len(transformed)}"
                )
                self.write(
                    f"data: {json.dumps({'status': '실행 재개 중', 'icon': 'play'})}\n\n"
                )
                await self.flush()

                async for event in runner.agent.astream_events(
                    Command(resume=resume_value),
                    config=config,
                    version="v2",
                ):
                    # Cancel 체크: 사용자가 작업 중지 시 즉시 종료
                    if runner._is_cancelled:
                        _dbg("RESUME_CANCELLED: user cancelled, breaking loop")
                        self.write(
                            f"event: cancelled\ndata: {json.dumps({'threadId': thread_id})}\n\n"
                        )
                        await self.flush()
                        break

                    event_kind = event.get("event", "")
                    event_data = None
                    event_name = event.get("name", "")
                    logger.debug(
                        "RESUME_EVENT: kind=%s name=%s",
                        event_kind,
                        event_name,
                    )

                    # 주요 이벤트 디버그 로깅
                    if event_kind in (
                        "on_chat_model_start",
                        "on_chat_model_end",
                        "on_tool_start",
                        "on_tool_end",
                    ):
                        _dbg(
                            f"RESUME_EVENT: kind={event_kind} name={event_name} "
                            f"inside_subagent={_inside_subagent}"
                        )

                    if event_kind == "on_chat_model_start":
                        # 서브에이전트 내부 LLM은 무시
                        if _inside_subagent:
                            continue
                        _iteration_r += 1
                        _stream_buffer = []
                        self.write(
                            f"data: {json.dumps({'status': 'LLM 응답 대기 중', 'icon': 'thinking', 'turn': _iteration_r, 'step': _tool_count_r})}\n\n"
                        )
                        await self.flush()
                        continue

                    elif event_kind == "on_chat_model_end":
                        # 서브에이전트 내부 LLM은 무시
                        if _inside_subagent:
                            continue
                        output_msg = event.get("data", {}).get("output", None)
                        if output_msg and hasattr(output_msg, "message"):
                            output_msg = output_msg.message
                        has_tool_calls = bool(
                            output_msg
                            and hasattr(output_msg, "tool_calls")
                            and output_msg.tool_calls
                        )

                        # Resume 중 LLM 응답 로깅
                        if has_tool_calls and output_msg:
                            tc_summary = [
                                {
                                    "name": tc.get("name"),
                                    "args_keys": list(tc.get("args", {}).keys()),
                                }
                                for tc in output_msg.tool_calls
                            ]
                            _dbg(f"RESUME_LLM_END: tool_calls={tc_summary}")
                        elif output_msg:
                            content_preview = getattr(output_msg, "content", "")[:100]
                            _dbg(
                                f"RESUME_LLM_END: no_tool_calls content_preview={repr(content_preview)}"
                            )

                        # Summarization 감지
                        if output_msg and hasattr(output_msg, "additional_kwargs"):
                            if (output_msg.additional_kwargs or {}).get(
                                "lc_source"
                            ) == "summarization":
                                self.write(
                                    f"data: {json.dumps({'status': '대화가 자동으로 압축되었습니다.'})}\n\n"
                                )
                                await self.flush()

                        if has_tool_calls and output_msg:
                            # Tool calling content 제거 (context window 절약)
                            if getattr(output_msg, "content", ""):
                                try:
                                    output_msg.content = ""
                                except (AttributeError, TypeError):
                                    pass
                            # Premature summary 필터링
                            if _stream_buffer:
                                buf_check = "".join(_stream_buffer)
                                if (
                                    '"summary"' in buf_check
                                    and '"next_items"' in buf_check
                                ):
                                    non_todo_tools = [
                                        tc
                                        for tc in output_msg.tool_calls
                                        if tc.get("name") not in ("write_todos",)
                                    ]
                                    if non_todo_tools:
                                        _stream_buffer = []

                        if _stream_buffer and not has_tool_calls:
                            # tool_calls 없는 턴 → 최종 응답
                            buf = "".join(_stream_buffer)
                            if "assistantfinal" in buf:
                                buf = buf[
                                    buf.index("assistantfinal")
                                    + len("assistantfinal") :
                                ]
                            # JSON tool response 필터링
                            if buf:
                                stripped = buf.strip()
                                is_json_tool = (
                                    stripped.startswith('{"tool":')
                                    or stripped.startswith('{"status":')
                                    or '"pending_execution"' in stripped
                                )
                                if is_json_tool:
                                    buf = ""
                            # Summary JSON repair + content hash dedup
                            if buf:
                                buf = _repair_summary_json_content(buf)
                                content_hash = hash(buf)
                                if content_hash not in _emitted_hashes:
                                    _emitted_hashes.add(content_hash)
                                    event_data = json.dumps({"content": buf})
                                    logger.info(
                                        "RESUME_CONTENT: sending %d chars to frontend",
                                        len(buf),
                                    )
                                else:
                                    logger.info("RESUME_CONTENT: dedup skipped")
                            # Auto-terminate: summary 감지 후 자동 종료
                            if _all_todos_completed and buf:
                                if '"summary"' in buf and '"next_items"' in buf:
                                    self.write(
                                        f"event: debug_clear\ndata: {json.dumps({})}\n\n"
                                    )
                                    self.write(
                                        f"event: done\ndata: {json.dumps({'reason': 'all_todos_completed', 'thread_id': thread_id})}\n\n"
                                    )
                                    await self.flush()
                                    break
                        elif not _stream_buffer and not has_tool_calls and output_msg:
                            # List content 핸들링 (multimodal)
                            raw_content = getattr(output_msg, "content", "")
                            if isinstance(raw_content, list):
                                text_parts = []
                                for part in raw_content:
                                    if isinstance(part, str):
                                        text_parts.append(part)
                                    elif (
                                        isinstance(part, dict)
                                        and part.get("type") == "text"
                                    ):
                                        text_parts.append(part.get("text", ""))
                                buf = "".join(text_parts)
                            else:
                                buf = raw_content or ""
                            if buf:
                                content_hash = hash(buf)
                                if content_hash not in _emitted_hashes:
                                    _emitted_hashes.add(content_hash)
                                    event_data = json.dumps({"content": buf})
                        elif _stream_buffer and has_tool_calls:
                            logger.info(
                                "RESUME_CONTENT: discarding reasoning (%d chars, has_tool_calls)",
                                len("".join(_stream_buffer)),
                            )
                        _stream_buffer = []

                    elif event_kind == "on_chat_model_stream":
                        # 서브에이전트 내부 LLM 스트리밍은 무시
                        if _inside_subagent:
                            continue
                        chunk = event.get("data", {}).get("chunk", None)
                        if chunk and hasattr(chunk, "content") and chunk.content:
                            _stream_buffer.append(chunk.content)

                    elif event_kind == "on_tool_start":
                        tool_name = event.get("name", "unknown")
                        tool_input = event.get("data", {}).get("input", {}) or {}
                        if not isinstance(tool_input, dict):
                            tool_input = {}
                        # 서브에이전트 진입 추적
                        if tool_name == "task":
                            _inside_subagent = True
                        _tool_count_r += 1
                        # 도구별 한국어 상태 메시지
                        status_msg = _get_tool_status_message(tool_name, tool_input)
                        payload_progress_r: dict = {"status": status_msg["status"]}
                        if status_msg.get("icon"):
                            payload_progress_r["icon"] = status_msg["icon"]
                        payload_progress_r["turn"] = _iteration_r
                        payload_progress_r["step"] = _tool_count_r
                        self.write(f"data: {json.dumps(payload_progress_r)}\n\n")
                        await self.flush()

                        # 셀 생성 도구 + 멀티에이전트 도구만 tool_call SSE 전송
                        if tool_name in (
                            "jupyter_cell",
                            "jupyter_markdown",
                            "execute",
                            "file_write",
                            "task",
                            "ask_user_tool",
                            "final_summary_tool",
                        ):
                            resume_payload: dict = {"tool": tool_name}
                            if tool_name == "jupyter_markdown":
                                resume_payload["content"] = tool_input.get(
                                    "content", ""
                                )
                            elif tool_name == "execute":
                                resume_payload["command"] = tool_input.get(
                                    "command", ""
                                )
                                resume_payload["code"] = tool_input.get("command", "")
                            elif tool_name == "task":
                                resume_payload["agent_name"] = tool_input.get(
                                    "subagent_type", tool_input.get("agent_name", "")
                                )
                                resume_payload["description"] = tool_input.get(
                                    "description", ""
                                )
                            elif tool_name == "final_summary_tool":
                                resume_payload["summary"] = tool_input.get(
                                    "summary", ""
                                )
                                resume_payload["next_items"] = tool_input.get(
                                    "next_items", []
                                )
                            else:
                                resume_payload["code"] = tool_input.get("code", "")
                            self.write(
                                f"event: tool_call\ndata: {json.dumps(resume_payload)}\n\n"
                            )
                            await self.flush()
                        # write_todos → 즉시 todos SSE emit + auto-terminate 캡처
                        # 서브에이전트 내부 write_todos는 프론트엔드에 전송하지 않음
                        if (
                            tool_name == "write_todos"
                            and isinstance(tool_input, dict)
                            and not _inside_subagent
                        ):
                            todos_data = tool_input.get("todos", [])
                            _last_todos_data = todos_data
                            if todos_data:
                                self.write(
                                    f"event: todos\ndata: {json.dumps({'todos': todos_data})}\n\n"
                                )
                                await self.flush()
                        continue  # skip duplicate write below
                    elif event_kind == "on_tool_end":
                        tool_name = event.get("name", "unknown")
                        # 서브에이전트 이탈 추적
                        if tool_name == "task":
                            _inside_subagent = False
                        # final_summary_tool 결과를 별도 SSE 이벤트로 전송
                        if tool_name in (
                            "final_summary_tool",
                            "final_summary",
                        ):
                            tool_output = ensure_str(
                                event.get("data", {}).get("output", "")
                            )
                            summary_data = safe_parse_json(tool_output) or {
                                "summary": tool_output
                            }
                            self.write(
                                f"event: summary\ndata: {safe_json_dumps(summary_data)}\n\n"
                            )
                            await self.flush()
                        event_data = json.dumps(
                            {
                                "status": f"{tool_name} 완료",
                            }
                        )
                        # Auto-terminate: write_todos 완료 체크
                        if tool_name == "write_todos" and _last_todos_data:
                            all_completed = all(
                                t.get("status") == "completed"
                                for t in _last_todos_data
                                if isinstance(t, dict)
                            )
                            if all_completed and _last_todos_data:
                                _all_todos_completed = True

                    if event_data:
                        self.write(f"data: {event_data}\n\n")
                        await self.flush()

                    # 절대 타임아웃 체크
                    elapsed = _time.monotonic() - _resume_start
                    if elapsed > _RESUME_ABSOLUTE_TIMEOUT:
                        logger.error(
                            "LangChainResume absolute timeout exceeded (%.1fs)",
                            elapsed,
                        )
                        self.write(
                            f"data: {json.dumps({'error': 'Agent resume timeout (5 min)'})}\n\n"
                        )
                        _resume_timed_out = True
                        await self.flush()
                        break

                # Resume 후 체인된 인터럽트 감지
                _dbg("=== RESUME STREAM DONE === astream_events loop completed")
                logger.debug("RESUME_STREAM_DONE: astream_events loop completed")
                if not _resume_timed_out:
                    state = await runner.agent.aget_state(config)
                    logger.debug(
                        "RESUME_STATE: tasks=%d, next=%s",
                        len(state.tasks) if state.tasks else 0,
                        state.next if hasattr(state, "next") else "N/A",
                    )

                    # 최종 todos state emit (일관성 보장)
                    # 서브에이전트 실행 중 중단된 경우 오염된 todos 전송 방지
                    if not _inside_subagent:
                        state_values = state.values if hasattr(state, "values") else {}
                        final_todos = state_values.get("todos", [])
                        if final_todos:
                            serializable = [
                                {
                                    "content": t["content"]
                                    if isinstance(t, dict)
                                    else t.content,
                                    "status": t["status"]
                                    if isinstance(t, dict)
                                    else t.status,
                                }
                                for t in final_todos
                            ]
                            self.write(
                                f"event: todos\ndata: {json.dumps({'todos': serializable})}\n\n"
                            )
                            await self.flush()

                    if state.tasks:
                        for task_state in state.tasks:
                            if task_state.interrupts:
                                hitl_request = task_state.interrupts[0].value
                                hitl_event = _transform_interrupt_to_frontend(
                                    hitl_request, thread_id
                                )
                                if "thread_id" not in hitl_event:
                                    hitl_event["thread_id"] = thread_id
                                _hitl_pending = True
                                _dbg(
                                    f"CHAINED_INTERRUPT: action={hitl_event.get('action')} "
                                    f"args_keys={list(hitl_event.get('args', {}).keys())}"
                                )
                                # HITL 대기 시 dedup 상태 저장
                                _thread_metadata.setdefault(thread_id, {})[
                                    "emitted_contents"
                                ] = _emitted_hashes.copy()
                                self.write(
                                    f"data: {json.dumps({'status': '사용자 승인 대기 중', 'icon': 'pause'})}\n\n"
                                )
                                self.write(
                                    f"event: hitl_request\ndata: {json.dumps(hitl_event)}\n\n"
                                )
                                await self.flush()
                                break

                    if not _hitl_pending:
                        # 인터럽트 없으면 정상 완료
                        logger.info(
                            "RESUME_COMPLETE: sending complete event for thread=%s",
                            thread_id,
                        )
                        self.write(f"event: debug_clear\ndata: {json.dumps({})}\n\n")
                        self.write(
                            f"event: complete\ndata: {json.dumps({'thread_id': thread_id})}\n\n"
                        )
                        await self.flush()

            except Exception as run_err:
                logger.error(f"LangChainResume run error: {run_err}", exc_info=True)
                self.write(f"data: {json.dumps({'error': str(run_err)})}\n\n")
                await self.flush()

        except Exception as e:
            logger.error(f"LangChainResume error: {e}", exc_info=True)
            self.write(f"data: {json.dumps({'error': str(e)})}\n\n")
            await self.flush()
        finally:
            # hitl_pending이면 runner 유지, 아니면 정리
            if not _hitl_pending:
                _active_agents.pop(thread_id, None)
            if not self._finished:
                self.finish()


class LangChainCancelHandler(APIHandler):
    """POST: cancel running agent."""

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            thread_id = body.get("threadId", "")

            runner = _get_agent_runner(thread_id)
            if runner:
                runner.cancel()
                # Cancel 시 todo_active 리셋
                try:
                    config = {"configurable": {"thread_id": thread_id}}
                    runner.agent.update_state(config, {"todo_active": False})
                except Exception:
                    pass
                _active_agents.pop(thread_id, None)
                self.write({"status": "cancelled", "threadId": thread_id})
            else:
                self.write({"status": "not_found", "threadId": thread_id})
        except Exception as e:
            logger.error(f"LangChainCancel error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class LangChainResetHandler(APIHandler):
    """POST: reset agent session."""

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            thread_id = body.get("threadId", "")

            runner = _get_agent_runner(thread_id)
            if runner:
                runner.cancel()
                _active_agents.pop(thread_id, None)
            _thread_metadata.pop(thread_id, None)
            # global checkpointer에서 해당 thread 데이터 제거
            try:
                storage = getattr(_global_checkpointer, "storage", {})
                storage.pop(thread_id, None)
            except Exception:
                pass

            self.write({"status": "reset", "threadId": thread_id})
        except Exception as e:
            logger.error(f"LangChainReset error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class LangChainHealthHandler(APIHandler):
    """GET: agent health status."""

    async def get(self):
        try:
            self.write(
                {
                    "status": "healthy",
                    "active_agents": len(_active_agents),
                    "agent_threads": list(_active_agents.keys()),
                }
            )
        except Exception as e:
            logger.error(f"LangChainHealth error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


# ============ Context Autocomplete Handler ============


class ContextAutocompleteHandler(APIHandler):
    """GET: @file and command autocomplete."""

    async def get(self):
        try:
            import glob as glob_mod

            partial_command = self.get_argument("partialCommand", default=None)
            base_dir = self.get_argument("baseDir", default=None)

            server_root = self.settings.get("server_root_dir", os.getcwd())
            base_directory = base_dir or os.path.expanduser(server_root)

            # Available providers
            providers = {
                "@file": {
                    "id": "@file",
                    "description": "파일 내용을 프롬프트에 포함",
                    "requires_arg": True,
                    "only_start": False,
                },
                "/reset": {
                    "id": "/reset",
                    "description": "세션 초기화 및 에이전트 리셋",
                    "requires_arg": False,
                    "only_start": False,
                },
                "/compact": {
                    "id": "/compact",
                    "description": "대화 기록 압축 및 요약",
                    "requires_arg": False,
                    "only_start": False,
                },
                "/help": {
                    "id": "/help",
                    "description": "도움말 및 사용 가이드",
                    "requires_arg": False,
                    "only_start": False,
                },
                "/create-notebook": {
                    "id": "/create-notebook",
                    "description": "프롬프트로 노트북 자동생성",
                    "requires_arg": False,
                    "only_start": True,
                },
            }

            if not partial_command:
                options = []
                for p in providers.values():
                    label = f"{p['id']}:" if p["requires_arg"] else p["id"]
                    options.append(
                        {
                            "id": p["id"],
                            "label": label,
                            "description": p["description"],
                            "only_start": p["only_start"],
                            "is_complete": not p["requires_arg"],
                        }
                    )
                self.write({"options": options})
                return

            if ":" not in partial_command:
                options = []
                for cmd_id, p in providers.items():
                    if cmd_id.startswith(partial_command):
                        label = f"{p['id']}:" if p["requires_arg"] else p["id"]
                        options.append(
                            {
                                "id": p["id"],
                                "label": label,
                                "description": p["description"],
                                "only_start": p["only_start"],
                                "is_complete": not p["requires_arg"],
                            }
                        )
                self.write({"options": options})
                return

            cmd_id, _, arg_prefix = partial_command.partition(":")

            if cmd_id == "@file":
                # File autocomplete
                if os.path.isabs(arg_prefix):
                    path_prefix = arg_prefix
                else:
                    path_prefix = os.path.join(base_directory, arg_prefix)

                path_prefix = os.path.normpath(path_prefix)

                if arg_prefix.endswith("/") and os.path.isdir(path_prefix):
                    glob_pattern = os.path.join(path_prefix, "*")
                else:
                    glob_pattern = path_prefix + "*"

                try:
                    path_matches = glob_mod.glob(glob_pattern)
                except Exception:
                    path_matches = []

                path_matches = sorted(
                    path_matches,
                    key=lambda p: (not os.path.isdir(p), os.path.basename(p).lower()),
                )

                SUPPORTED_EXTS = {
                    ".py",
                    ".md",
                    ".txt",
                    ".json",
                    ".yaml",
                    ".yml",
                    ".toml",
                    ".ini",
                    ".cfg",
                    ".sh",
                    ".bash",
                    ".ipynb",
                    ".js",
                    ".ts",
                    ".jsx",
                    ".tsx",
                    ".html",
                    ".css",
                    ".scss",
                    ".sql",
                    ".r",
                    ".R",
                    ".Rmd",
                    ".jl",
                    ".csv",
                    ".xml",
                    ".env",
                    ".gitignore",
                    ".dockerignore",
                    ".tex",
                }
                SPECIAL_FILES = {"Dockerfile", "Makefile"}

                options = []
                for path in path_matches[:20]:
                    is_dir = os.path.isdir(path)
                    if not is_dir:
                        ext = os.path.splitext(path)[1]
                        basename = os.path.basename(path)
                        if ext not in SUPPORTED_EXTS and basename not in SPECIAL_FILES:
                            continue

                    try:
                        if os.path.isabs(arg_prefix):
                            display_path = path
                        else:
                            display_path = os.path.relpath(path, base_directory)
                    except ValueError:
                        display_path = path

                    label_path = display_path + "/" if is_dir else display_path
                    if " " in label_path:
                        label_path = f"'{label_path}'"

                    options.append(
                        {
                            "id": "@file",
                            "label": f"@file:{label_path}",
                            "description": "디렉토리" if is_dir else "파일",
                            "only_start": False,
                            "is_complete": not is_dir,
                        }
                    )
                self.write({"options": options})
            elif cmd_id in providers and not providers[cmd_id]["requires_arg"]:
                p = providers[cmd_id]
                self.write(
                    {
                        "options": [
                            {
                                "id": p["id"],
                                "label": p["id"],
                                "description": p["description"],
                                "only_start": p["only_start"],
                                "is_complete": True,
                            }
                        ]
                    }
                )
            else:
                self.write({"options": []})

        except Exception as e:
            logger.error(f"ContextAutocomplete error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


# ============ Remaining Embedded Handlers ============


class AgentReflectHandler(APIHandler):
    """POST: agent reflection via ServiceFactory."""

    async def post(self):
        try:
            factory = _get_service_factory()
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            agent_service = factory.get_agent_service()
            result = await agent_service.reflect(body)
            self.write(result.model_dump() if hasattr(result, "model_dump") else result)
        except Exception as e:
            logger.error(f"AgentReflect error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AgentVerifyStateHandler(APIHandler):
    """POST: agent state verification via ServiceFactory."""

    async def post(self):
        try:
            factory = _get_service_factory()
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            agent_service = factory.get_agent_service()
            result = await agent_service.verify_state(body)
            self.write(result.model_dump() if hasattr(result, "model_dump") else result)
        except Exception as e:
            logger.error(f"AgentVerifyState error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AgentPlanStreamHandler(APIHandler):
    """POST: plan generation with SSE streaming via ServiceFactory."""

    async def post(self):
        try:
            factory = _get_service_factory()
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            agent_service = factory.get_agent_service()

            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")
            self.set_header("X-Accel-Buffering", "no")

            async for chunk in agent_service.plan_stream(body):
                data = json.dumps(chunk) if isinstance(chunk, dict) else chunk
                self.write(f"data: {data}\n\n")
                await self.flush()

        except Exception as e:
            logger.error(f"AgentPlanStream error: {e}", exc_info=True)
            self.write(f"data: {json.dumps({'error': str(e)})}\n\n")
        finally:
            self.finish()


class CellActionHandler(APIHandler):
    """POST: cell action execution via ServiceFactory."""

    async def post(self):
        try:
            factory = _get_service_factory()
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            agent_service = factory.get_agent_service()
            result = await agent_service.cell_action(body)
            self.write(result.model_dump() if hasattr(result, "model_dump") else result)
        except Exception as e:
            logger.error(f"CellAction error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class FileActionHandler(APIHandler):
    """POST: file action execution via ServiceFactory."""

    async def post(self):
        try:
            factory = _get_service_factory()
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            agent_service = factory.get_agent_service()
            result = await agent_service.file_action(body)
            self.write(result.model_dump() if hasattr(result, "model_dump") else result)
        except Exception as e:
            logger.error(f"FileAction error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class FileResolveHandler(APIHandler):
    """POST: resolve file path in workspace."""

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )

            # Convert notebookDir to absolute path
            if "notebookDir" in body and body["notebookDir"]:
                server_root = self.settings.get("server_root_dir", os.getcwd())
                server_root = os.path.expanduser(server_root)
                notebook_dir = body["notebookDir"]
                if not os.path.isabs(notebook_dir):
                    body["notebookDir"] = os.path.join(server_root, notebook_dir)

            factory = _get_service_factory()
            agent_service = factory.get_agent_service()
            result = await agent_service.file_resolve(body)
            self.write(result.model_dump() if hasattr(result, "model_dump") else result)
        except Exception as e:
            logger.error(f"FileResolve error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class FileSelectHandler(APIHandler):
    """POST: file selection via ServiceFactory."""

    async def post(self):
        try:
            factory = _get_service_factory()
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            agent_service = factory.get_agent_service()
            result = await agent_service.file_select(body)
            self.write(result.model_dump() if hasattr(result, "model_dump") else result)
        except Exception as e:
            logger.error(f"FileSelect error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ChatCompactHandler(APIHandler):
    """POST: compact/summarize conversation via ServiceFactory."""

    async def post(self):
        try:
            factory = _get_service_factory()
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            chat_service = factory.get_chat_service()
            result = await chat_service.compact(body)
            self.write(result.model_dump() if hasattr(result, "model_dump") else result)
        except Exception as e:
            logger.error(f"ChatCompact error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class SearchWorkspaceHandler(APIHandler):
    """Handler for /search-workspace endpoint (runs on Jupyter server)."""

    async def post(self):
        """Execute workspace search."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            pattern = (body.get("pattern") or "").strip()
            file_types = body.get("file_types") or ["*.py", "*.ipynb"]
            path = body.get("path") or "."
            max_results = body.get("max_results", 50)
            case_sensitive = bool(body.get("case_sensitive", False))
            user_workspace_root = body.get("workspaceRoot")

            if not pattern:
                self.set_status(400)
                self.write({"error": "pattern is required"})
                return

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root, user_workspace_root
            )

            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                _execute_search_workspace,
                pattern,
                file_types,
                path,
                max_results,
                case_sensitive,
                workspace_root,
            )

            self.set_header("Content-Type", "application/json")
            self.write(result)

        except Exception as e:
            logger.error(f"Search workspace failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class SearchNotebookCellsHandler(APIHandler):
    """Handler for /search-notebook-cells endpoint (runs on Jupyter server)."""

    async def post(self):
        """Execute notebook cells search."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            pattern = (body.get("pattern") or "").strip()
            notebook_path = body.get("notebook_path")
            cell_type = body.get("cell_type")
            max_results = body.get("max_results", 30)
            case_sensitive = bool(body.get("case_sensitive", False))
            user_workspace_root = body.get("workspaceRoot")

            if not pattern:
                self.set_status(400)
                self.write({"error": "pattern is required"})
                return

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root, user_workspace_root
            )

            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                _execute_search_notebook_cells,
                pattern,
                notebook_path,
                cell_type,
                max_results,
                case_sensitive,
                workspace_root,
            )

            self.set_header("Content-Type", "application/json")
            self.write(result)

        except Exception as e:
            logger.error(f"Search notebook cells failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class RAGReindexHandler(APIHandler):
    """Handler for /rag/reindex endpoint using ServiceFactory."""

    async def post(self):
        """Trigger reindex operation."""
        try:
            factory = _get_service_factory()
            rag_service = factory.get_rag_service()

            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            force = body.get("force", False)

            response = await rag_service.trigger_reindex(force=force)

            self.set_header("Content-Type", "application/json")
            self.write(response)

        except Exception as e:
            logger.error(f"RAG reindex failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


# ============ Idle Shutdown Handler ============


class IdleShutdownHandler(APIHandler):
    """Handler for idle timeout shutdown - calls HDSP API from server side."""

    @property
    def hdsp_env(self) -> Optional[str]:
        return os.environ.get("HDSP_ENV")

    @property
    def hdsp_prj_id(self) -> Optional[str]:
        return os.environ.get("HDSP_PRJ_ID")

    @property
    def jupyterhub_user(self) -> Optional[str]:
        return os.environ.get("JUPYTERHUB_USER")

    async def post(self):
        """Trigger idle shutdown by calling HDSP API."""
        try:
            hdsp_env = self.hdsp_env
            project_id = self.hdsp_prj_id
            user_id = self.jupyterhub_user

            # Check required environment variables
            if not hdsp_env or not project_id or not user_id:
                logger.warning(
                    f"[IdleShutdown] Missing env vars: HDSP_ENV={hdsp_env}, "
                    f"HDSP_PRJ_ID={project_id}, JUPYTERHUB_USER={user_id}"
                )
                self.set_status(400)
                self.write(
                    {
                        "success": False,
                        "error": "Missing required environment variables",
                        "details": {
                            "HDSP_ENV": hdsp_env is not None,
                            "HDSP_PRJ_ID": project_id is not None,
                            "JUPYTERHUB_USER": user_id is not None,
                        },
                    }
                )
                return

            # Build API URL based on environment
            if hdsp_env == "dev":
                api_base_url = "https://hdsp-api-dev.hyundaicard.com"
            elif hdsp_env == "prod":
                api_base_url = "https://hdsp-api.hyundaicard.com"
            else:
                logger.warning(f"[IdleShutdown] Unknown HDSP_ENV: {hdsp_env}")
                self.set_status(400)
                self.write(
                    {"success": False, "error": f"Unknown HDSP_ENV value: {hdsp_env}"}
                )
                return

            api_url = f"{api_base_url}/k8s/jupyter/{project_id}/{user_id}"
            logger.info(f"[IdleShutdown] Calling shutdown API: {api_url}")

            # Call DELETE API
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.delete(api_url)

            if response.status_code in (200, 204):
                logger.info("[IdleShutdown] Shutdown API call successful")
                self.write(
                    {
                        "success": True,
                        "message": "Shutdown initiated",
                        "api_url": api_url,
                    }
                )
            else:
                logger.error(
                    f"[IdleShutdown] API call failed: {response.status_code} {response.text}"
                )
                self.set_status(response.status_code)
                self.write(
                    {
                        "success": False,
                        "error": f"API call failed: {response.status_code}",
                        "details": response.text,
                    }
                )

        except httpx.TimeoutException:
            logger.error("[IdleShutdown] API call timeout")
            self.set_status(504)
            self.write({"success": False, "error": "API call timeout"})
        except Exception as e:
            logger.error(f"[IdleShutdown] Error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"success": False, "error": str(e)})


# ============ Handler Setup ============


def _get_websocket_handler_entry(base_url: str) -> list:
    """Return [(url, AgentWebSocketHandler)] or [] if deepagents is unavailable."""
    try:
        from .handlers.websocket import AgentWebSocketHandler as _WS

        return [(url_path_join(base_url, "hdsp-agent", "agent", "ws"), _WS)]
    except Exception as e:
        logger.warning("AgentWebSocketHandler unavailable (deepagents missing?): %s", e)
        return []


class _IdleResetMixin:
    """Mixin that resets server-side idle monitor on every request."""

    def prepare(self):
        monitor = self.settings.get("hdsp_idle_monitor")
        if monitor:
            monitor.reset()
        return super().prepare()


def setup_handlers(web_app):
    """Register all handlers based on execution mode."""
    host_pattern = ".*$"
    base_url = web_app.settings["base_url"]

    handlers = [
        # Health check
        (url_path_join(base_url, "hdsp-agent", "health"), HealthHandler),
        # Config endpoints (embedded)
        (url_path_join(base_url, "hdsp-agent", "config"), ConfigHandler),
        (
            url_path_join(base_url, "hdsp-agent", "config", "prompts"),
            ConfigPromptsHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "config", "is-admin"),
            ConfigIsAdminHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "config", "admin"),
            ConfigAdminHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "config", "user"),
            ConfigUserHandler,
        ),
        # ===== ServiceFactory-based handlers =====
        # Agent endpoints
        (url_path_join(base_url, "hdsp-agent", "auto-agent", "plan"), AgentPlanHandler),
        (
            url_path_join(base_url, "hdsp-agent", "auto-agent", "refine"),
            AgentRefineHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "auto-agent", "replan"),
            AgentReplanHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "auto-agent", "validate"),
            AgentValidateHandler,
        ),
        # Chat endpoints
        (url_path_join(base_url, "hdsp-agent", "chat", "message"), ChatMessageHandler),
        (url_path_join(base_url, "hdsp-agent", "chat", "stream"), ChatStreamHandler),
        (url_path_join(base_url, "hdsp-agent", "chat", "compact"), ChatCompactHandler),
        # LangChain agent endpoints (embedded)
        (
            url_path_join(base_url, "hdsp-agent", "agent", "langchain", "stream"),
            LangChainStreamHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "agent", "langchain", "resume"),
            LangChainResumeHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "agent", "langchain", "health"),
            LangChainHealthHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "agent", "langchain", "cancel"),
            LangChainCancelHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "agent", "langchain", "reset"),
            LangChainResetHandler,
        ),
        # Shell command execution (server-side, approval required)
        (
            url_path_join(base_url, "hdsp-agent", "execute-command"),
            ExecuteCommandHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "execute-command", "stream"),
            ExecuteCommandStreamHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "resource-usage"),
            ResourceUsageHandler,
        ),
        # Resource check for data processing (server-side, auto-approved)
        (
            url_path_join(base_url, "hdsp-agent", "check-resource"),
            CheckResourceHandler,
        ),
        # File read/write execution (server-side)
        (url_path_join(base_url, "hdsp-agent", "read-file"), ReadFileHandler),
        (url_path_join(base_url, "hdsp-agent", "write-file"), WriteFileHandler),
        # Search endpoints (server-side, no approval required)
        (
            url_path_join(base_url, "hdsp-agent", "search-workspace"),
            SearchWorkspaceHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "search-notebook-cells"),
            SearchNotebookCellsHandler,
        ),
        # RAG endpoints
        (url_path_join(base_url, "hdsp-agent", "rag", "search"), RAGSearchHandler),
        (url_path_join(base_url, "hdsp-agent", "rag", "status"), RAGStatusHandler),
        (url_path_join(base_url, "hdsp-agent", "rag", "reindex"), RAGReindexHandler),
        # Idle shutdown endpoint (server-side API call)
        (
            url_path_join(base_url, "hdsp-agent", "idle-shutdown"),
            IdleShutdownHandler,
        ),
        # WebSocket handler for ReAct Agent (lazy import: requires deepagents)
        *_get_websocket_handler_entry(base_url),
        # Embedded handlers (previously proxied to agent-server)
        (
            url_path_join(base_url, "hdsp-agent", "auto-agent", "reflect"),
            AgentReflectHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "auto-agent", "verify-state"),
            AgentVerifyStateHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "auto-agent", "plan", "stream"),
            AgentPlanStreamHandler,
        ),
        # Cell/File action endpoints (embedded)
        (
            url_path_join(base_url, "hdsp-agent", "cell", "action"),
            CellActionHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "file", "action"),
            FileActionHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "file", "resolve"),
            FileResolveHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "file", "select"),
            FileSelectHandler,
        ),
        # Context provider endpoints (@file autocomplete, embedded)
        (
            url_path_join(base_url, "hdsp-agent", "context", "autocomplete"),
            ContextAutocompleteHandler,
        ),
        # Notebook endpoints
        (
            url_path_join(base_url, "hdsp-agent", "notebook", "enrich"),
            NotebookEnrichHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "notebook", "generate"),
            NotebookGenerateHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "task", r"([^/]+)", "status"),
            TaskStatusHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "task", r"([^/]+)", "stream"),
            TaskStreamHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "task", r"([^/]+)", "cancel"),
            TaskCancelHandler,
        ),
    ]

    # 모든 핸들러에 idle reset mixin 주입
    patched = []
    for entry in handlers:
        url_pattern = entry[0]
        handler_cls = entry[1]
        rest = entry[2:]
        # _IdleResetMixin을 동적으로 주입 (WebSocket 핸들러 제외)
        if issubclass(handler_cls, APIHandler) and _IdleResetMixin not in handler_cls.__mro__:
            handler_cls = type(handler_cls.__name__, (_IdleResetMixin, handler_cls), {})
        patched.append((url_pattern, handler_cls, *rest))

    web_app.add_handlers(host_pattern, patched)
