import networkx as nx
import numpy as np
from typing import Tuple, Optional

def compute_cg(
    G: nx.Graph,
    weights: Tuple[float, float, float] = (1.0, 1.0, 1.0),
    use_full_ricci: bool = False,
) -> float:
    """
    Compute Graph Robustness Score C(G).
    
    use_full_ricci=True uses the real Ollivier–Ricci curvature (requires GraphRicciCurvature).
    Default is fast clustering proxy (exactly as your original Streamlit app).
    """
    if G.number_of_nodes() < 2:
        return 0.0

    A = nx.adjacency_matrix(G).todense()

    # Spectral gap
    ev = np.real(np.linalg.eigvals(A))
    ev_sorted = np.sort(ev)[::-1]
    spectral_gap = ev_sorted[0] - ev_sorted[1] if len(ev_sorted) > 1 else ev_sorted[0]

    # Singular-value variance
    sigma = np.linalg.svd(A, compute_uv=False)
    sing_var = np.var(sigma)

    # Curvature part
    if use_full_ricci:
        try:
            from GraphRicciCurvature.OllivierRicci import OllivierRicci
            orc = OllivierRicci(G, alpha=0.5)
            orc.compute_ricci_curvature()
            ricci_values = list(orc.ricci_curvature.values())
            curvature = np.mean(ricci_values) * 10.0   # scale to match original range
        except ImportError:
            print("Warning: GraphRicciCurvature not installed. Falling back to clustering proxy.")
            curvature = nx.average_clustering(G) * 10.0
    else:
        # Fast clustering proxy (original demo version)
        curvature = nx.average_clustering(G) * 10.0

    w1, w2, w3 = weights
    score = w1 * spectral_gap - w2 * sing_var + w3 * curvature
    return float(score)
