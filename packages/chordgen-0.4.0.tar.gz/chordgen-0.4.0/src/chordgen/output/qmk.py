from pathlib import Path
from chordgen.chord import Chord
from pydantic import BaseModel
from chordgen.pydantic import File


qmk_key_codes = {
    ";": "KC_SCLN",
    ",": "KC_COMMA",
    ".": "KC_DOT",
    "'": "KC_QUOT",
    "-": "KC_MINUS",
}


class QmkOutput(BaseModel):
    file: File = Path.cwd() / "qmk_chords.def"
    combo_keys: list[str] = ["KC_COMBO"]
    shift_keys: list[str] = ["KC_COMBO_SFT"]
    alt1_keys: list[str] = ["KC_COMBO_ALT1"]
    alt2_keys: list[str] = ["KC_COMBO_ALT2"]
    alt3_keys: list[str] = ["KC_COMBO_ALT1", "KC_COMBO_ALT2"]
    key_codes: dict[str, str] = {
        "C": "KC_SFT_C",
        "I": "KC_ALT_I",
        "E": "KC_GUI_E",
        "A": "KC_CTL_A",
        "H": "KC_CTL_H",
        "T": "KC_GUI_T",
        "S": "KC_ALT_S",
        "N": "KC_SFT_N",
        "J": "KC_CAG_J",
        "M": "KC_CAG_M",
    }

    def translate_keys(self, combo):
        result = self.combo_keys.copy()
        key_codes = qmk_key_codes | self.key_codes

        for k in combo:
            k = k.upper()
            if k in key_codes:
                result.append(key_codes[k])
            elif k.isalnum():
                result.append(f"KC_{k}")
            else:
                raise Exception(
                    f"Unknown QMK code to map '{k}', add it to the chordgen config"
                )

        return result

    def output(self, chords: list[Chord]):
        alt_keys = [self.alt1_keys, self.alt2_keys, self.alt3_keys]
        output = ""
        for chord in chords:
            if not chord["chord"]:
                continue
            words = [chord["word"], chord["alt1"], chord["alt2"], chord["alt3"]]
            for i, word in enumerate(words):
                if not word:
                    continue
                keys = self.translate_keys(chord["chord"] + ",")
                alt = []
                if i > 0:
                    alt = alt_keys[i - 1]
                name = f"c_{word}{i}".replace("'", "_").replace("-", "_")

                output += f'SUBS({name}, "{word} ", {", ".join(keys + alt)})\n'
                output += f'SUBS({name}s, "{word.capitalize()} ", {", ".join(keys + alt + self.shift_keys)})\n'

        print(f"Writing {self.file}")
        with open(self.file, "w") as file:
            file.write(output)
