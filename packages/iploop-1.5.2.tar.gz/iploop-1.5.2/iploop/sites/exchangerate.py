"""ExchangeRate site preset."""
import re


class ExchangeRate:
    def __init__(self, client):
        self.client = client

    def extract(self, url):
        try:
            m = re.search(r'/latest/([A-Z]{3})', url)
            base = m.group(1) if m else "USD"
            resp = self.client.fetch(f"https://api.exchangerate-api.com/v4/latest/{base}", timeout=10)
            d = resp.json()
            rates = d.get("rates", {})
            return {"success": True, "data": {
                "base": d.get("base"), "date": d.get("date"),
                "rates": {k: rates.get(k) for k in ("EUR", "GBP", "ILS", "JPY", "CAD", "AUD") if k in rates},
                "total_currencies": len(rates),
            }, "source": "exchangerate-api", "error": None}
        except Exception as e:
            return {"success": False, "data": {}, "source": "exchangerate-api", "error": str(e)}
