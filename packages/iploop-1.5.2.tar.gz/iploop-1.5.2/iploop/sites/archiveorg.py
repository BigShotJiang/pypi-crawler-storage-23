"""Archive.org site preset."""
import re


class ArchiveOrg:
    def __init__(self, client):
        self.client = client

    def extract(self, url):
        try:
            m = re.search(r'/details/([^/?#]+)', url)
            identifier = m.group(1) if m else url.rstrip("/").split("/")[-1]
            resp = self.client.fetch(f"https://archive.org/metadata/{identifier}", timeout=10)
            meta = resp.json().get("metadata", {})
            return {"success": bool(meta.get("title")), "data": {
                "title": meta.get("title"), "creator": meta.get("creator"),
                "description": (meta.get("description") or "")[:300],
                "mediatype": meta.get("mediatype"),
            }, "source": "archiveorg-api", "error": None}
        except Exception as e:
            return {"success": False, "data": {}, "source": "archiveorg-api", "error": str(e)}
