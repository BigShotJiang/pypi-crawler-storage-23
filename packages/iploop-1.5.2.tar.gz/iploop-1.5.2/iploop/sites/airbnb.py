"""Airbnb site preset."""
import re


class Airbnb:
    def __init__(self, client):
        self.client = client

    def extract(self, url):
        try:
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
            resp = self.client.fetch(url, headers=headers, timeout=15)
            if resp.status_code != 200:
                return {"success": False, "data": {}, "source": "airbnb-http", "error": f"HTTP {resp.status_code}"}

            html = resp.text
            data = {}

            t = re.search(r'<title>([^<]*)</title>', html)
            if t:
                data["title"] = t.group(1).strip()

            # og:title often has cleaner name
            og = re.search(r'<meta property="og:title" content="([^"]*)"', html)
            if og:
                data["title"] = og.group(1).strip()

            # Location from meta or JSON-LD
            loc = re.search(r'"addressLocality"\s*:\s*"([^"]*)"', html)
            if loc:
                data["location"] = loc.group(1)
            else:
                loc2 = re.search(r'"address"\s*:\s*\{[^}]*"addressLocality"\s*:\s*"([^"]*)"', html)
                if loc2:
                    data["location"] = loc2.group(1)

            # Price hint from meta
            price = re.search(r'<meta[^>]*name="description"[^>]*content="[^"]*(\$[\d,]+)[^"]*"', html)
            if price:
                data["price"] = price.group(1)

            # Rating
            rv = re.search(r'"ratingValue"\s*:\s*"?([0-9.]+)"?', html)
            if rv:
                data["rating"] = float(rv.group(1))

            return {"success": bool(data.get("title")), "data": data, "source": "airbnb-http", "error": None}
        except Exception as e:
            return {"success": False, "data": {}, "source": "airbnb-http", "error": str(e)}
