"""Spotify site preset."""


class Spotify:
    def __init__(self, client):
        self.client = client

    def extract(self, url):
        try:
            resp = self.client.fetch(f"https://open.spotify.com/oembed?url={url}", timeout=10)
            if resp.status_code == 200:
                d = resp.json()
                return {"success": True, "data": {
                    "title": d.get("title"),
                    "thumbnail_url": d.get("thumbnail_url"),
                    "provider": d.get("provider_name"),
                }, "source": "spotify-oembed", "error": None}
            return {"success": False, "data": {}, "source": "spotify-oembed", "error": f"HTTP {resp.status_code}"}
        except Exception as e:
            return {"success": False, "data": {}, "source": "spotify-oembed", "error": str(e)}
