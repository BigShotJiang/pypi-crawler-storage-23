"""RemoteOK site preset."""


class RemoteOK:
    def __init__(self, client):
        self.client = client

    def extract(self, url):
        try:
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
            resp = self.client.fetch("https://remoteok.com/api", headers=headers, timeout=15)
            if resp.status_code != 200:
                return {"success": False, "data": {}, "source": "remoteok-api", "error": f"HTTP {resp.status_code}"}

            raw = resp.json()
            # First item is usually legal/meta info, skip it
            items = raw[1:] if len(raw) > 1 else raw
            jobs = []
            for item in items[:25]:
                if not isinstance(item, dict):
                    continue
                jobs.append({
                    "title": item.get("position", ""),
                    "company": item.get("company", ""),
                    "location": item.get("location", ""),
                    "tags": item.get("tags", []),
                    "salary": item.get("salary_min", ""),
                    "url": item.get("url", ""),
                })

            return {"success": len(jobs) > 0, "data": {"jobs": jobs, "count": len(jobs)}, "source": "remoteok-api", "error": None}
        except Exception as e:
            return {"success": False, "data": {}, "source": "remoteok-api", "error": str(e)}
