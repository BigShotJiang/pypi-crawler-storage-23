"""PokeAPI site preset."""
import re


class PokeAPI:
    def __init__(self, client):
        self.client = client

    def extract(self, url):
        try:
            m = re.search(r'/pokemon/([^/?#]+)', url)
            name = m.group(1) if m else "pikachu"
            resp = self.client.fetch(f"https://pokeapi.co/api/v2/pokemon/{name}", timeout=10)
            d = resp.json()
            return {"success": True, "data": {
                "name": d.get("name"), "weight": d.get("weight"), "height": d.get("height"),
                "types": [t["type"]["name"] for t in d.get("types", [])],
                "abilities": [a["ability"]["name"] for a in d.get("abilities", [])],
            }, "source": "pokeapi", "error": None}
        except Exception as e:
            return {"success": False, "data": {}, "source": "pokeapi", "error": str(e)}
