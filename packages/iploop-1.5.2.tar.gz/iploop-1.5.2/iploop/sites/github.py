"""GitHub site preset."""
from urllib.parse import urlparse


class GitHub:
    def __init__(self, client):
        self.client = client

    def extract(self, url):
        try:
            parts = [p for p in urlparse(url).path.strip("/").split("/") if p]
            if len(parts) < 2:
                return {"success": False, "data": {}, "source": "github-api", "error": "Need owner/repo in URL"}
            owner, repo = parts[0], parts[1]
            resp = self.client.fetch(f"https://api.github.com/repos/{owner}/{repo}", timeout=10)
            if resp.status_code == 200:
                d = resp.json()
                return {"success": True, "data": {
                    "full_name": d.get("full_name"),
                    "description": d.get("description"),
                    "stars": d.get("stargazers_count"),
                    "forks": d.get("forks_count"),
                    "language": d.get("language"),
                    "open_issues": d.get("open_issues_count"),
                }, "source": "github-api", "error": None}
            return {"success": False, "data": {}, "source": "github-api", "error": f"HTTP {resp.status_code}"}
        except Exception as e:
            return {"success": False, "data": {}, "source": "github-api", "error": str(e)}
