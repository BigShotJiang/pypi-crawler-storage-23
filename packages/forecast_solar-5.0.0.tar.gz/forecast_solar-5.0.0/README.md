<!--
*** To avoid retyping too much info. Do a search and replace for the following:
*** github_username, repo_name
-->

## Python API fetching Solarpanels forecast information.
<!-- PROJECT SHIELDS -->
![Project Maintenance][maintenance-shield]
[![License][license-shield]](LICENSE)

[![GitHub Activity][commits-shield]][commits]
[![GitHub Last Commit][last-commit-shield]][commits]
[![Contributors][contributors-shield]][contributors-url]

[![Forks][forks-shield]][forks-url]
[![Stargazers][stars-shield]][stars-url]
[![Issues][issues-shield]][issues-url]

## About

With this python library you can request data from [forecast.solar](https://forecast.solar) and see what your solar panels may produce in the coming days.

## Installation

```bash
pip install forecast-solar
```

## Data

This library returns a lot of different data, based on the API:

### Energy

- Total Estimated Energy Production - today/tomorrow (kWh)
- Estimated Energy Production - This Hour (kWh)
- Estimated Energy Production - Next Hour (kWh)
- Estimated Energy Production - Remaining today (kWh)

### Power

- Highest Power Peak Time - Today (datetime)
- Highest Power Peak Time - Tomorrow (datetime)
- Estimated Power Production - Now (W)
- Estimated Power Production - Next Hour (W)
- Estimated Power Production - In +6 Hours (W)
- Estimated Power Production - In +12 Hours (W)
- Estimated Power Production - In +24 Hours (W)

### API Info

- Timezone
- Rate limit
- Account type
- Rate remaining

### Validation

- API key (bool)
- Plane (bool)

## Example

```python
import asyncio

from forecast_solar import ForecastSolar


async def main() -> None:
    """Show example on how to use the library."""
    async with ForecastSolar(
        api_key="YOUR_API_KEY",
        latitude=52.16,
        longitude=4.47,
        declination=20,
        azimuth=10,
        kwp=2.160,
        damping=0,
        damping_morning=0.5,
        damping_evening=0.5,
        horizon="0,0,0,10,10,20,20,30,30",
    ) as forecast:
        estimate = await forecast.estimate(actual=2.315)
        print(estimate)


if __name__ == "__main__":
    asyncio.run(main())
```

### Multiple Planes

If you have solar panels facing different directions, you can specify multiple planes.

**Note:** Using multiple planes requires both an API key and a Personal Plus (or higher) subscription. If no API key is provided, additional planes will be silently ignored. See the [subscription plan overview][forecast-subscription] for more information.

```python
import asyncio

from forecast_solar import ForecastSolar, Plane


async def main() -> None:
    """Show example with multiple planes."""
    async with ForecastSolar(
        api_key="YOUR_API_KEY",
        latitude=52.16,
        longitude=4.47,
        # First plane (primary)
        declination=20,
        azimuth=10,
        kwp=2.160,
        # Additional planes
        planes=[
            Plane(declination=30, azimuth=-90, kwp=1.5),  # Second plane
            Plane(declination=25, azimuth=90, kwp=1.0),   # Third plane
        ],
    ) as forecast:
        estimate = await forecast.estimate()
        print(estimate)


if __name__ == "__main__":
    asyncio.run(main())
```

## ForecastSolar object

| Parameter | value type | Description                                                                                                 |
| --------- | ---------- |-------------------------------------------------------------------------------------------------------------|
| `api_key` | `str` | Your API key from [forecast.solar](https://forecast.solar) (optional)                                       |
| `declination` | `int` | The tilt of the solar panels (required)                                                                     |
| `azimuth` | `int` | The direction the solar panels are facing (required)                                                        |
| `kwp` | `float` | The size of the solar panels in kWp (required)                                                              |
| `damping` | `float` | The damping of the solar panels, [read this][forecast-damping] for more information (optional)              |
| `damping_morning` | `float` | The damping of the solar panels in the morning (optional)                                                   |
| `damping_evening` | `float` | The damping of the solar panels in the evening (optional)                                                   |
| `inverter` | `float` | The maximum power of your inverter in kilo watts (optional)                                                 |
| `horizon` | `str` | A list of **comma separated** degrees values, [read this][forecast-horizon] for more information (optional) |
| `planes` | `list[Plane]` | A list of additional Plane objects for multi-plane setups. Only used when an API key is provided (optional)                                                  |

## Plane object

| Parameter | value type | Description |
| --------- | ---------- | ----------- |
| `declination` | `float` | The tilt of the solar panels (required) |
| `azimuth` | `float` | The direction the solar panels are facing (required) |
| `kwp` | `float` | The size of the solar panels in kWp (required) |

## estimate() method

| Parameter | value type | Description                                                                                        |
| --------- | ---------- | -------------------------------------------------------------------------------------------------- |
| `actual`  | `float`    | The production in kWh for the current day so far. Only used when an API key is provided (optional) |

## Contributing

Would you like to contribute to the development of this project? Then read the prepared [contribution guidelines](CONTRIBUTING.md) and go ahead!

Thank you for being involved! :heart_eyes:

## Setting up development environment

This Python project relies on [Poetry][poetry] as its dependency manager,
providing comprehensive management and control over project dependencies.

You need at least:

- Python 3.12+
- [Poetry][poetry-install]

### Installation

Install all packages, including all development requirements:

```bash
poetry install
```

_Poetry creates by default an virtual environment where it installs all
necessary pip packages_.

### Prek

This repository uses the [prek][prek] framework, all changes
are linted and tested with each commit. To setup the prek check, run:

```bash
poetry run prek install
```

And to run all checks and tests manually, use the following command:

```bash
poetry run prek run --all-files
```

### Testing

It uses [pytest](https://docs.pytest.org/en/stable/) as the test framework. To run the tests:

```bash
poetry run pytest
```

To update the [syrupy](https://github.com/tophat/syrupy) snapshot tests:

```bash
poetry run pytest --snapshot-update
```

## License

MIT License

Copyright (c) 2021-2026 Klaas Schoute

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

<!-- LINKS -->
[forecast-horizon]: https://doc.forecast.solar/doku.php?id=api#horizon
[forecast-damping]: https://doc.forecast.solar/doku.php?id=damping
[forecast-subscription]: https://doc.forecast.solar/account_models

<!-- MARKDOWN LINKS & IMAGES -->
[maintenance-shield]: https://img.shields.io/maintenance/yes/2026.svg?style=for-the-badge
[contributors-shield]: https://img.shields.io/github/contributors/home-assistant-libs/forecast_solar.svg?style=for-the-badge
[contributors-url]: https://github.com/home-assistant-libs/forecast_solar/graphs/contributors
[forks-shield]: https://img.shields.io/github/forks/home-assistant-libs/forecast_solar.svg?style=for-the-badge
[forks-url]: https://github.com/home-assistant-libs/forecast_solar/network/members
[stars-shield]: https://img.shields.io/github/stars/home-assistant-libs/forecast_solar.svg?style=for-the-badge
[stars-url]: https://github.com/home-assistant-libs/forecast_solar/stargazers
[issues-shield]: https://img.shields.io/github/issues/home-assistant-libs/forecast_solar.svg?style=for-the-badge
[issues-url]: https://github.com/home-assistant-libs/forecast_solar/issues
[license-shield]: https://img.shields.io/github/license/home-assistant-libs/forecast_solar.svg?style=for-the-badge
[commits-shield]: https://img.shields.io/github/commit-activity/y/home-assistant-libs/forecast_solar.svg?style=for-the-badge
[commits]: https://github.com/home-assistant-libs/forecast_solar/commits/master
[last-commit-shield]: https://img.shields.io/github/last-commit/home-assistant-libs/forecast_solar.svg?style=for-the-badge

[poetry-install]: https://python-poetry.org/docs/#installation
[poetry]: https://python-poetry.org
[prek]: https://github.com/j178/prek
