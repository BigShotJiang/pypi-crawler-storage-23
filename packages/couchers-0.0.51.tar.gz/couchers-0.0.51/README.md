# Couchers.org Python Client

The next-generation couch surfing platform. Free forever. Community‑led. Non‑profit. Modern. Read more about us at [Couchers.org](https://couchers.org).

This is the Couchers.org Python Client, mainly used for administrative purposes and the like.

Usage of the Couchers.org service provided by Couchers, Inc. is governed under our [Terms of Service](https://couchers.org/terms).
