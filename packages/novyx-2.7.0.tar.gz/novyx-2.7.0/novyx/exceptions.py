"""
Novyx SDK Exceptions
"""


class NovyxError(Exception):
    """Base exception for all Novyx errors."""
    pass


class NovyxAuthError(NovyxError):
    """Authentication failed - invalid or expired API key."""
    pass


class NovyxForbiddenError(NovyxError):
    """
    Feature not available on current plan.

    Raised when trying to access Pro+ features on Free tier.

    Attributes:
        feature: Feature that requires upgrade
        tier_required: Minimum tier required (legacy, use required_plan)
        required_plan: Minimum plan required (pro, enterprise)
        plan: User's current plan
        upgrade_url: URL to upgrade plan
    """
    def __init__(self, message: str, data: dict = None):
        super().__init__(message)
        self.data = data or {}
        self.feature = self.data.get("feature")
        self.tier_required = self.data.get("tier_required") or self.data.get("required_plan", "pro")
        self.required_plan = self.data.get("required_plan", "pro")
        self.plan = self.data.get("plan")
        self.upgrade_url = self.data.get("upgrade_url", "https://novyxlabs.com/pricing")


class NovyxRateLimitError(NovyxError):
    """
    Rate limit exceeded.

    Raised when API call limit, rollback limit, or memory limit is exceeded.

    Attributes:
        limit_type: Type of limit exceeded (api_calls, rollbacks, memories)
        current: Current usage count
        limit: Maximum allowed
        tier: Current tier (legacy, use plan)
        plan: User's current plan
        upgrade_url: URL to upgrade plan
        retry_after: Seconds until rate limit resets (if available)
        resets_at: ISO8601 timestamp when limit resets (for monthly limits)
        tip: Optional helpful tip for working around the limit
    """
    def __init__(self, message: str, data: dict = None):
        super().__init__(message)
        self.data = data or {}
        self.limit_type = self.data.get("limit")
        self.current = self.data.get("current")
        self.max_allowed = self.data.get("max_allowed") or self.data.get("max") or self.data.get("limit")
        self.limit = self.max_allowed  # backward-compatible alias
        self.tier = self.data.get("tier")
        self.plan = self.data.get("plan")
        self.upgrade_url = self.data.get("upgrade_url", "https://novyxlabs.com/pricing")
        self.retry_after = self.data.get("retry_after")
        self.resets_at = self.data.get("resets_at")
        self.tip = self.data.get("tip")


class NovyxNotFoundError(NovyxError):
    """Resource not found (404)."""
    pass


class NovyxSecurityError(NovyxError):
    """Security policy violation - action blocked by Sentinel."""
    pass


# Legacy alias for backward compatibility
class NovyxUpgradeRequired(NovyxRateLimitError):
    """
    Feature or limit requires upgrade.

    Deprecated: Use NovyxRateLimitError or NovyxForbiddenError instead.
    Kept for backward compatibility.
    """
    pass
