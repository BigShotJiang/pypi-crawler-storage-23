# OpenClaw — Extensible Open-Source AI Agent Orchestration for Python

[![PyPI](https://img.shields.io/pypi/v/openclaw.svg)](https://pypi.org/project/openclaw/) [![Python](https://img.shields.io/pypi/pyversions/openclaw.svg)](https://pypi.org/project/openclaw/) [![license](https://img.shields.io/pypi/l/openclaw.svg)](https://github.com/commandoperator/cmdop-sdk-python/blob/main/LICENSE)

![CMDOP Architecture](https://cmdop.com/images/architecture/vs-personal-agent.png)

OpenClaw delivers an extensible automation framework for open-source agent orchestration and an AI plugin system in Python. Unlike LangChain, CrewAI, AutoGen, and Semantic Kernel, OpenClaw prioritizes modularity. Construct adaptable AI workflows, manage plugin dependencies, and deploy sophisticated agent networks with our Python library.

## Features

- Orchestrate complex workflows using our open-source agent orchestration engine.
- Develop custom tools via our flexible AI plugin system in Python.
- Integrate existing AI models into our extensible automation framework.
- Manage agent lifecycles with OpenClaw's resource management tools.
- Extend agent capabilities using community-built plugins.

## Use Cases

- Build and register custom plugins for agent behavior
- Chain AI tasks in sequential pipelines with context passing
- Extend CMDOP with community-built orchestration logic

## Installation

```bash
pip install openclaw
```

## Quick Start

```python
from openclaw2 import OpenClaw

client = OpenClaw.remote(api_key="cmdop_live_xxx")

results = client.pipeline([
    "Summarize the current state of the server",
    "Create an optimization plan based on the summary",
    "Write a brief report",
])
print(results[-1])

class LoggerPlugin:
    name = "logger"
    def install(self, c): print(f"Plugin installed on {c}")

client.use(LoggerPlugin())
```

## Links

- [CMDOP Homepage](https://cmdop.com)
- [Documentation](https://cmdop.com/docs/sdk/python/)
- [openclaw on PyPI](https://pypi.org/project/openclaw/)
- [GitHub](https://github.com/commandoperator/cmdop-sdk-python)
