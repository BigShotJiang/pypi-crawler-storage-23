"""CLI-specific middleware for pydantic-deep."""

from __future__ import annotations

__all__: list[str] = []
