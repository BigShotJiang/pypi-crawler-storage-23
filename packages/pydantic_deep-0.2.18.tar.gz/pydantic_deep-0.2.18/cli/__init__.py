"""pydantic-deep CLI — terminal agent for coding tasks."""

from __future__ import annotations

__all__: list[str] = []
