"""Harbor agent adapter for pydantic-deep CLI.

Install harbor separately: ``uv pip install harbor``
Do NOT add it to pyproject.toml (requires Python >= 3.12).
"""
