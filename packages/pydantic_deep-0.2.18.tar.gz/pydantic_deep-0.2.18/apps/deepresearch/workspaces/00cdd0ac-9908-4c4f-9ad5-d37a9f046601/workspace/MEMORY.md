# Agent Memory

Persistent notes and context that carry across sessions.
Use this file to remember user preferences, project context, and important findings.

## User Preferences
<!-- Agent: add notes about user preferences here -->

## Project Context
<!-- Agent: add notes about the current project here -->

## Key Findings
<!-- Agent: store important research findings for cross-session reference -->
