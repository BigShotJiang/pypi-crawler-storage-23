# Agent Memory

Persistent notes and context that carry across sessions.
