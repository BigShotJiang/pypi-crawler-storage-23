def add(a, b):
    return a + b


if __name__ == "__main__":
    print(add(3, 4))
