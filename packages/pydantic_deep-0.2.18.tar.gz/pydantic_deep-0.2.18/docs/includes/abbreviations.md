*[AI]: Artificial Intelligence
*[LLM]: Large Language Model
*[API]: Application Programming Interface
*[CLI]: Command Line Interface
*[HITL]: Human-in-the-Loop
*[SDK]: Software Development Kit
*[JSON]: JavaScript Object Notation
*[YAML]: YAML Ain't Markup Language
*[async]: Asynchronous
*[sync]: Synchronous
