// Extra JavaScript for pydantic-deep documentation
// Currently empty - using Material for MkDocs defaults
