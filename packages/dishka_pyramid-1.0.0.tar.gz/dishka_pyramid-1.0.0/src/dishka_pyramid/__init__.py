from dishka import FromDishka

from ._pyramid import (
    PyramidProvider,
    inject,
    setup_dishka,
)

__all__ = (
    "FromDishka",
    "PyramidProvider",
    "inject",
    "setup_dishka",
)
