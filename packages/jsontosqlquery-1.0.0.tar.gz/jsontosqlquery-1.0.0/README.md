# json2sql

[![PyPI](https://img.shields.io/pypi/v/json2sql)](https://pypi.org/project/json2sql/)
[![Python](https://img.shields.io/pypi/pyversions/json2sql)](https://pypi.org/project/json2sql/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

> Convert JSON arrays to SQL INSERT statements without manual work.

## Install

```bash
pip install jsontosqlquery
```

## Usage

```bash
# From file
jsontosqlquery users.json --table users

# From stdin
cat data.json | jsontosqlquery --table orders

# Write to file + include CREATE TABLE
jsontosqlquery data.json --table products --output products.sql --create-table

# Multi-row batches (faster for large datasets)
jsontosqlquery big.json --table events --batch 500

# MySQL dialect
jsontosqlquery data.json --table items --dialect mysql
```

### Input (users.json)

```json
[
  {"id": 1, "name": "Alice", "active": true},
  {"id": 2, "name": "Bob",   "active": false}
]
```

### Output

```sql
INSERT INTO "users" ("id", "name", "active") VALUES
    (1, 'Alice', TRUE);

INSERT INTO "users" ("id", "name", "active") VALUES
    (2, 'Bob', FALSE);
```

## Options

| Flag | Description |
|------|-------------|
| `--table`, `-t` | Target table name **(required)** |
| `--output`, `-o` | Write SQL to a file (default: stdout) |
| `--dialect` | `standard` (default) / `postgres` / `mysql` |
| `--create-table` | Prepend `CREATE TABLE IF NOT EXISTS` |
| `--batch N` | Emit multi-row INSERT batches of N rows |

## Type inference

| JSON type | SQL type |
|-----------|----------|
| `null` | `NULL` |
| `true` / `false` | `BOOLEAN` |
| Integer | `INTEGER` |
| Float | `REAL` |
| String | `VARCHAR(255)` |
| Array / Object | `TEXT` (serialised as JSON) |

Missing keys in mixed-key records become `NULL`.

## License

MIT
