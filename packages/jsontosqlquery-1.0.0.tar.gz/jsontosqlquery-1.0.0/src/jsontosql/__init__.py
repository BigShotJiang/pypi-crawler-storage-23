"""jsontosqlquery: convert JSON arrays to SQL INSERT statements."""

__version__ = "1.0.0"
__all__ = ["generator", "type_inference", "cli"]
