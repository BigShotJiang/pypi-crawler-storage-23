"""
SQL INSERT statement generator.

Supports:
  - Flat JSON objects
  - Mixed-key records (missing keys become NULL)
  - Optional CREATE TABLE preamble
  - Dialect-specific quoting (standard / mysql / postgres)
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

from .type_inference import infer_sql_type, sql_literal


def _quote_identifier(name: str, dialect: str) -> str:
    """Quote a column/table name according to the SQL dialect."""
    if dialect == "mysql":
        return f"`{name}`"
    # postgres / standard: double-quotes
    return f'"{name}"'


def _collect_columns(records: List[Dict[str, Any]]) -> List[str]:
    """
    Return an ordered list of all column names that appear across all records.
    Order is preserved (insertion order of first occurrence).
    """
    seen: dict = {}
    for record in records:
        for key in record.keys():
            seen[key] = None
    return list(seen.keys())


def _infer_column_types(
    records: List[Dict[str, Any]], columns: List[str]
) -> Dict[str, str]:
    """
    For each column, find the first non-null value and infer the SQL type.
    Falls back to VARCHAR(255) if all values are null.
    """
    types: Dict[str, str] = {}
    for col in columns:
        for record in records:
            val = record.get(col)
            if val is not None:
                types[col] = infer_sql_type(val)
                break
        else:
            types[col] = "VARCHAR(255)"
    return types


def generate_create_table(
    table: str,
    columns: List[str],
    col_types: Dict[str, str],
    dialect: str = "standard",
) -> str:
    """Generate a CREATE TABLE statement."""
    q = lambda n: _quote_identifier(n, dialect)  # noqa: E731
    col_defs = ",\n    ".join(f"{q(col)} {col_types[col]}" for col in columns)
    return f"CREATE TABLE IF NOT EXISTS {q(table)} (\n    {col_defs}\n);\n"


def generate_insert_statements(
    records: List[Dict[str, Any]],
    table: str,
    dialect: str = "standard",
    create_table: bool = False,
    batch_size: Optional[int] = None,
) -> str:
    """
    Generate SQL INSERT statements for a list of records.

    Args:
        records:      List of dicts parsed from JSON.
        table:        Target table name.
        dialect:      "standard" | "postgres" | "mysql"
        create_table: Prepend a CREATE TABLE IF NOT EXISTS statement.
        batch_size:   If set, emit multi-row INSERT batches of this size.
                      If None, emit one INSERT per row.

    Returns:
        A string containing all SQL statements, ready to execute or save.
    """
    if not records:
        return "-- Warning: empty array, no INSERT statements generated.\n"

    columns = _collect_columns(records)
    col_types = _infer_column_types(records, columns)
    q = lambda n: _quote_identifier(n, dialect)  # noqa: E731

    lines: List[str] = []

    if create_table:
        lines.append(generate_create_table(table, columns, col_types, dialect))

    col_list = ", ".join(q(c) for c in columns)
    header = f"INSERT INTO {q(table)} ({col_list}) VALUES"

    def record_to_values(record: Dict[str, Any]) -> str:
        vals = ", ".join(sql_literal(record.get(col)) for col in columns)
        return f"({vals})"

    if batch_size:
        # Multi-row batches
        for i in range(0, len(records), batch_size):
            chunk = records[i : i + batch_size]
            rows = ",\n    ".join(record_to_values(r) for r in chunk)
            lines.append(f"{header}\n    {rows};\n")
    else:
        # One INSERT per record
        for record in records:
            lines.append(f"{header}\n    {record_to_values(record)};\n")

    return "\n".join(lines)


def parse_json_input(raw: str) -> List[Dict[str, Any]]:
    """
    Parse raw JSON string.  Accepts:
      - A JSON array of objects  → returned as-is
      - A single JSON object     → wrapped in a list

    Raises ValueError with a clear message on parse failure.
    """
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"Invalid JSON at line {exc.lineno}, column {exc.colno}: {exc.msg}"
        ) from exc

    if isinstance(data, dict):
        data = [data]

    if not isinstance(data, list):
        raise ValueError(
            f"Expected a JSON array or object, got {type(data).__name__}."
        )

    non_obj = [i for i, item in enumerate(data) if not isinstance(item, dict)]
    if non_obj:
        raise ValueError(
            f"All array elements must be JSON objects. "
            f"Non-object element(s) at index: {non_obj[:5]}"
        )

    return data
