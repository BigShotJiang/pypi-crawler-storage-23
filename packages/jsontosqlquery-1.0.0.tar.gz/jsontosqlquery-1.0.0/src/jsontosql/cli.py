"""
CLI entry point for jsontosqlquery.

Usage examples:
    jsontosqlquery data.json --table users
    cat data.json | jsontosqlquery --table users
    jsontosqlquery data.json --table orders --output out.sql --create-table
    jsontosqlquery data.json --table items --dialect mysql --batch 500
"""

import sys
from pathlib import Path

import click
import colorama
from colorama import Fore, Style

from .generator import generate_insert_statements, parse_json_input

colorama.init(autoreset=True)

BANNER = (
    f"{Fore.CYAN}{Style.BRIGHT}"
    "jsontosqlquery v1.0  |  JSON -> SQL INSERT converter\n"
    f"{Style.RESET_ALL}"
)


@click.command()
@click.argument("input_file", required=False, type=click.Path(exists=True))
@click.option("--table", "-t", required=True, help="Target SQL table name.")
@click.option(
    "--output",
    "-o",
    default=None,
    type=click.Path(),
    help="Write SQL to this file instead of stdout.",
)
@click.option(
    "--dialect",
    "-d",
    default="standard",
    type=click.Choice(["standard", "postgres", "mysql"], case_sensitive=False),
    show_default=True,
    help="SQL dialect for identifier quoting.",
)
@click.option(
    "--create-table",
    "create_table",
    is_flag=True,
    default=False,
    help="Prepend CREATE TABLE IF NOT EXISTS statement.",
)
@click.option(
    "--batch",
    "batch_size",
    default=None,
    type=int,
    help="Group rows into multi-row INSERT batches of this size.",
)
@click.version_option("1.0.0", prog_name="jsontosqlquery")
def main(
    input_file: str,
    table: str,
    output: str,
    dialect: str,
    create_table: bool,
    batch_size: int,
) -> None:
    """
    \b
    Convert a JSON file (or stdin) to SQL INSERT statements.

    INPUT_FILE  Path to a JSON file.  Omit to read from stdin.

    Examples:
    \b
        jsontosqlquery users.json --table users
        cat data.json | jsontosqlquery --table orders --create-table
        jsontosqlquery items.json --table items --output items.sql --batch 100
    """
    click.echo(BANNER, err=True)

    # ── Read input ────────────────────────────────────────────────────────
    if input_file:
        try:
            raw = Path(input_file).read_text(encoding="utf-8")
        except OSError as exc:
            click.echo(
                f"{Fore.RED}Cannot read file '{input_file}': {exc}{Style.RESET_ALL}",
                err=True,
            )
            sys.exit(1)
    else:
        if sys.stdin.isatty():
            click.echo(
                f"{Fore.YELLOW}Waiting for JSON input on stdin "
                f"(Ctrl+D to finish)...{Style.RESET_ALL}",
                err=True,
            )
        raw = sys.stdin.read()

    if not raw.strip():
        click.echo(f"{Fore.RED}No JSON input provided.{Style.RESET_ALL}", err=True)
        sys.exit(1)

    # ── Parse ─────────────────────────────────────────────────────────────
    try:
        records = parse_json_input(raw)
    except ValueError as exc:
        click.echo(f"{Fore.RED}JSON parse error: {exc}{Style.RESET_ALL}", err=True)
        sys.exit(1)

    if not records:
        click.echo(
            f"{Fore.YELLOW}Warning: JSON array is empty — no INSERT statements generated.{Style.RESET_ALL}",
            err=True,
        )
        sys.exit(0)

    click.echo(
        f"{Fore.CYAN}Parsed {len(records)} record(s). "
        f"Target table: {Style.BRIGHT}{table}{Style.RESET_ALL}",
        err=True,
    )

    # ── Generate SQL ──────────────────────────────────────────────────────
    sql = generate_insert_statements(
        records=records,
        table=table,
        dialect=dialect,
        create_table=create_table,
        batch_size=batch_size,
    )

    # ── Output ────────────────────────────────────────────────────────────
    if output:
        try:
            Path(output).write_text(sql, encoding="utf-8")
            click.echo(
                f"{Fore.GREEN}SQL written to: {Style.BRIGHT}{output}{Style.RESET_ALL}",
                err=True,
            )
        except OSError as exc:
            click.echo(
                f"{Fore.RED}Cannot write to '{output}': {exc}{Style.RESET_ALL}",
                err=True,
            )
            sys.exit(1)
    else:
        click.echo(sql, nl=False)
