"""
Infer SQL column types from Python values parsed out of JSON.
"""

from __future__ import annotations
from typing import Any


def infer_sql_type(value: Any) -> str:
    """
    Map a Python value to the most appropriate SQL type string.

    Rules:
      None        → NULL  (we store the *default* type; actual value is NULL)
      bool        → BOOLEAN       (must check before int, bool is subclass of int)
      int         → INTEGER
      float       → REAL
      list/dict   → TEXT          (serialised as JSON string)
      everything else → VARCHAR(255)
    """
    if value is None:
        return "VARCHAR(255)"  # column still needs a type even if first value is null
    if isinstance(value, bool):
        return "BOOLEAN"
    if isinstance(value, int):
        return "INTEGER"
    if isinstance(value, float):
        return "REAL"
    if isinstance(value, (list, dict)):
        return "TEXT"          # stored as JSON string
    return "VARCHAR(255)"


def sql_literal(value: Any) -> str:
    """
    Convert a Python value to a safe SQL literal string.

    - None       → NULL
    - bool       → TRUE / FALSE
    - int/float  → bare number
    - list/dict  → JSON-encoded, escaped, quoted
    - str        → escaped single-quotes, quoted
    """
    import json

    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return repr(value)
    if isinstance(value, (list, dict)):
        # Serialise nested structures as JSON text
        encoded = json.dumps(value, ensure_ascii=False)
        escaped = encoded.replace("'", "''")
        return f"'{escaped}'"
    # String: escape single-quotes and backslashes
    escaped = str(value).replace("\\", "\\\\").replace("'", "''")
    return f"'{escaped}'"
