"""Unit tests for jsontosqlquery generator and type inference."""

import pytest
from jsontosqlquery.type_inference import infer_sql_type, sql_literal
from jsontosqlquery.generator import (
    generate_insert_statements,
    parse_json_input,
    generate_create_table,
)


# ── type inference ────────────────────────────────────────────────────────────

def test_infer_int():
    assert infer_sql_type(42) == "INTEGER"

def test_infer_float():
    assert infer_sql_type(3.14) == "REAL"

def test_infer_bool():
    assert infer_sql_type(True) == "BOOLEAN"
    assert infer_sql_type(False) == "BOOLEAN"

def test_infer_none():
    assert infer_sql_type(None) == "VARCHAR(255)"

def test_infer_string():
    assert infer_sql_type("hello") == "VARCHAR(255)"

def test_infer_list():
    assert infer_sql_type([1, 2, 3]) == "TEXT"

def test_infer_dict():
    assert infer_sql_type({"a": 1}) == "TEXT"


# ── sql_literal ───────────────────────────────────────────────────────────────

def test_literal_none():
    assert sql_literal(None) == "NULL"

def test_literal_bool_true():
    assert sql_literal(True) == "TRUE"

def test_literal_bool_false():
    assert sql_literal(False) == "FALSE"

def test_literal_int():
    assert sql_literal(7) == "7"

def test_literal_float():
    assert sql_literal(1.5) == "1.5"

def test_literal_string_escapes_single_quote():
    assert sql_literal("O'Brien") == "'O''Brien'"

def test_literal_string_escapes_backslash():
    assert sql_literal("C:\\path") == "'C:\\\\path'"

def test_literal_nested_list():
    result = sql_literal([1, 2])
    assert result.startswith("'") and result.endswith("'")
    assert "1" in result


# ── parse_json_input ──────────────────────────────────────────────────────────

def test_parse_valid_array():
    records = parse_json_input('[{"id": 1}, {"id": 2}]')
    assert len(records) == 2

def test_parse_single_object_wrapped_in_list():
    records = parse_json_input('{"id": 1, "name": "Alice"}')
    assert len(records) == 1

def test_parse_invalid_json_raises():
    with pytest.raises(ValueError, match="Invalid JSON"):
        parse_json_input("{bad json}")

def test_parse_non_array_raises():
    with pytest.raises(ValueError):
        parse_json_input('"just a string"')


# ── generate_insert_statements ────────────────────────────────────────────────

SAMPLE = [
    {"id": 1, "name": "Alice", "active": True},
    {"id": 2, "name": "Bob",   "active": False},
]

def test_generates_two_inserts():
    sql = generate_insert_statements(SAMPLE, table="users")
    assert sql.count("INSERT INTO") == 2

def test_table_name_in_output():
    sql = generate_insert_statements(SAMPLE, table="my_table")
    assert '"my_table"' in sql

def test_mysql_dialect_backticks():
    sql = generate_insert_statements(SAMPLE, table="users", dialect="mysql")
    assert "`users`" in sql

def test_create_table_preamble():
    sql = generate_insert_statements(SAMPLE, table="users", create_table=True)
    assert "CREATE TABLE IF NOT EXISTS" in sql

def test_batch_insert():
    sql = generate_insert_statements(SAMPLE, table="users", batch_size=10)
    assert sql.count("INSERT INTO") == 1  # both rows in one batch

def test_missing_keys_become_null():
    records = [{"id": 1, "name": "Alice"}, {"id": 2}]
    sql = generate_insert_statements(records, table="users")
    assert "NULL" in sql

def test_empty_array_returns_comment():
    sql = generate_insert_statements([], table="users")
    assert "Warning" in sql or "empty" in sql.lower()

def test_unicode_string():
    records = [{"greeting": "Привет мир"}]
    sql = generate_insert_statements(records, table="t")
    assert "Привет мир" in sql

def test_create_table_infers_types():
    sql = generate_insert_statements(SAMPLE, table="users", create_table=True)
    assert "INTEGER" in sql
    assert "BOOLEAN" in sql
    assert "VARCHAR(255)" in sql
