from .shell import MiniShell

KernelBridge = MiniShell

__all__ = ["KernelBridge", "MiniShell"]
