"""Streaming insert helpers for Ibis backends."""
