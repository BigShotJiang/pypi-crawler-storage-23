from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.unstructured_file_input import UnstructuredFileInput


T = TypeVar("T", bound="IngestFilesRequest")


@_attrs_define
class IngestFilesRequest:
    """
    Attributes:
        files (list[UnstructuredFileInput]): File metadata records to ingest or refresh.
        force (bool | Unset): Whether to force a refresh even when the file metadata already exists. Default: False.
    """

    files: list[UnstructuredFileInput]
    force: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        files = []
        for files_item_data in self.files:
            files_item = files_item_data.to_dict()
            files.append(files_item)

        force = self.force

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "files": files,
            }
        )
        if force is not UNSET:
            field_dict["force"] = force

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.unstructured_file_input import UnstructuredFileInput

        d = dict(src_dict)
        files = []
        _files = d.pop("files")
        for files_item_data in _files:
            files_item = UnstructuredFileInput.from_dict(files_item_data)

            files.append(files_item)

        force = d.pop("force", UNSET)

        ingest_files_request = cls(
            files=files,
            force=force,
        )

        ingest_files_request.additional_properties = d
        return ingest_files_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
