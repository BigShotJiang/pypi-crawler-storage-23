from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.unstructured_file_metadata import UnstructuredFileMetadata


T = TypeVar("T", bound="RetrieveFilesResponse")


@_attrs_define
class RetrieveFilesResponse:
    """
    Attributes:
        query (str): Original retrieval query text.
        files (list[UnstructuredFileMetadata]): Matched file metadata records.
    """

    query: str
    files: list[UnstructuredFileMetadata]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        query = self.query

        files = []
        for files_item_data in self.files:
            files_item = files_item_data.to_dict()
            files.append(files_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "query": query,
                "files": files,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.unstructured_file_metadata import UnstructuredFileMetadata

        d = dict(src_dict)
        query = d.pop("query")

        files = []
        _files = d.pop("files")
        for files_item_data in _files:
            files_item = UnstructuredFileMetadata.from_dict(files_item_data)

            files.append(files_item)

        retrieve_files_response = cls(
            query=query,
            files=files,
        )

        retrieve_files_response.additional_properties = d
        return retrieve_files_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
