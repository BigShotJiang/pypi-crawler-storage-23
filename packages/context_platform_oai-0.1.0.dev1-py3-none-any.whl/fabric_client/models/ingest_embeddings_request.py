from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.embedding_document_input import EmbeddingDocumentInput


T = TypeVar("T", bound="IngestEmbeddingsRequest")


@_attrs_define
class IngestEmbeddingsRequest:
    """
    Attributes:
        source (str): Source identifier whose embeddings index should be updated.
        documents (list[EmbeddingDocumentInput] | Unset): Embedded document payloads to store for the source.
    """

    source: str
    documents: list[EmbeddingDocumentInput] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        source = self.source

        documents: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.documents, Unset):
            documents = []
            for documents_item_data in self.documents:
                documents_item = documents_item_data.to_dict()
                documents.append(documents_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "source": source,
            }
        )
        if documents is not UNSET:
            field_dict["documents"] = documents

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.embedding_document_input import EmbeddingDocumentInput

        d = dict(src_dict)
        source = d.pop("source")

        _documents = d.pop("documents", UNSET)
        documents: list[EmbeddingDocumentInput] | Unset = UNSET
        if _documents is not UNSET:
            documents = []
            for documents_item_data in _documents:
                documents_item = EmbeddingDocumentInput.from_dict(documents_item_data)

                documents.append(documents_item)

        ingest_embeddings_request = cls(
            source=source,
            documents=documents,
        )

        ingest_embeddings_request.additional_properties = d
        return ingest_embeddings_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
