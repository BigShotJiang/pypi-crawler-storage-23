from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="RetrieveKnowledgeQuery")


@_attrs_define
class RetrieveKnowledgeQuery:
    """
    Attributes:
        query (None | str | Unset): Free-text query used to search for relevant table and column metadata.
        table_name (None | str | Unset): Exact fully qualified table name to retrieve directly.
        top_k (int | None | Unset): Maximum number of table matches to return for the query.
        column_limit (int | None | Unset): Maximum number of column matches to return per query result.
    """

    query: None | str | Unset = UNSET
    table_name: None | str | Unset = UNSET
    top_k: int | None | Unset = UNSET
    column_limit: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        query: None | str | Unset
        if isinstance(self.query, Unset):
            query = UNSET
        else:
            query = self.query

        table_name: None | str | Unset
        if isinstance(self.table_name, Unset):
            table_name = UNSET
        else:
            table_name = self.table_name

        top_k: int | None | Unset
        if isinstance(self.top_k, Unset):
            top_k = UNSET
        else:
            top_k = self.top_k

        column_limit: int | None | Unset
        if isinstance(self.column_limit, Unset):
            column_limit = UNSET
        else:
            column_limit = self.column_limit

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if query is not UNSET:
            field_dict["query"] = query
        if table_name is not UNSET:
            field_dict["table_name"] = table_name
        if top_k is not UNSET:
            field_dict["top_k"] = top_k
        if column_limit is not UNSET:
            field_dict["column_limit"] = column_limit

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_query(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        query = _parse_query(d.pop("query", UNSET))

        def _parse_table_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        table_name = _parse_table_name(d.pop("table_name", UNSET))

        def _parse_top_k(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        top_k = _parse_top_k(d.pop("top_k", UNSET))

        def _parse_column_limit(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        column_limit = _parse_column_limit(d.pop("column_limit", UNSET))

        retrieve_knowledge_query = cls(
            query=query,
            table_name=table_name,
            top_k=top_k,
            column_limit=column_limit,
        )

        retrieve_knowledge_query.additional_properties = d
        return retrieve_knowledge_query

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
