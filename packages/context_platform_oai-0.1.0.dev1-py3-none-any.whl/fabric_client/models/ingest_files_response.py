from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="IngestFilesResponse")


@_attrs_define
class IngestFilesResponse:
    """
    Attributes:
        status (str): High-level ingestion status.
        files_ingested (int): Number of file records successfully ingested.
        errors (list[str] | Unset): Per-item ingestion errors, if any.
    """

    status: str
    files_ingested: int
    errors: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        status = self.status

        files_ingested = self.files_ingested

        errors: list[str] | Unset = UNSET
        if not isinstance(self.errors, Unset):
            errors = self.errors

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
                "files_ingested": files_ingested,
            }
        )
        if errors is not UNSET:
            field_dict["errors"] = errors

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = d.pop("status")

        files_ingested = d.pop("files_ingested")

        errors = cast(list[str], d.pop("errors", UNSET))

        ingest_files_response = cls(
            status=status,
            files_ingested=files_ingested,
            errors=errors,
        )

        ingest_files_response.additional_properties = d
        return ingest_files_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
