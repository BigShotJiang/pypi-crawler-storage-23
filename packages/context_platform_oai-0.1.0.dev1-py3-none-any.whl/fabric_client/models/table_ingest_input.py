from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.table_column_input import TableColumnInput


T = TypeVar("T", bound="TableIngestInput")


@_attrs_define
class TableIngestInput:
    """
    Attributes:
        table_name (str): Fully qualified table name, for example `catalog.schema.table`.
        table_desc (None | str | Unset): Human-readable description of the table.
        table_type (None | str | Unset): Table kind from the source system, for example `table` or `view`.
        table_tags (list[str] | Unset): Optional tags associated with the table.
        table_usage_count (int | Unset): Observed usage count or popularity score for the table. Default: 0.
        table_deprecated (bool | Unset): Whether the table should be treated as deprecated. Default: False.
        columns (list[TableColumnInput] | Unset): Column metadata records to ingest for the table.
    """

    table_name: str
    table_desc: None | str | Unset = UNSET
    table_type: None | str | Unset = UNSET
    table_tags: list[str] | Unset = UNSET
    table_usage_count: int | Unset = 0
    table_deprecated: bool | Unset = False
    columns: list[TableColumnInput] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        table_name = self.table_name

        table_desc: None | str | Unset
        if isinstance(self.table_desc, Unset):
            table_desc = UNSET
        else:
            table_desc = self.table_desc

        table_type: None | str | Unset
        if isinstance(self.table_type, Unset):
            table_type = UNSET
        else:
            table_type = self.table_type

        table_tags: list[str] | Unset = UNSET
        if not isinstance(self.table_tags, Unset):
            table_tags = self.table_tags

        table_usage_count = self.table_usage_count

        table_deprecated = self.table_deprecated

        columns: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.columns, Unset):
            columns = []
            for columns_item_data in self.columns:
                columns_item = columns_item_data.to_dict()
                columns.append(columns_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "table_name": table_name,
            }
        )
        if table_desc is not UNSET:
            field_dict["table_desc"] = table_desc
        if table_type is not UNSET:
            field_dict["table_type"] = table_type
        if table_tags is not UNSET:
            field_dict["table_tags"] = table_tags
        if table_usage_count is not UNSET:
            field_dict["table_usage_count"] = table_usage_count
        if table_deprecated is not UNSET:
            field_dict["table_deprecated"] = table_deprecated
        if columns is not UNSET:
            field_dict["columns"] = columns

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.table_column_input import TableColumnInput

        d = dict(src_dict)
        table_name = d.pop("table_name")

        def _parse_table_desc(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        table_desc = _parse_table_desc(d.pop("table_desc", UNSET))

        def _parse_table_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        table_type = _parse_table_type(d.pop("table_type", UNSET))

        table_tags = cast(list[str], d.pop("table_tags", UNSET))

        table_usage_count = d.pop("table_usage_count", UNSET)

        table_deprecated = d.pop("table_deprecated", UNSET)

        _columns = d.pop("columns", UNSET)
        columns: list[TableColumnInput] | Unset = UNSET
        if _columns is not UNSET:
            columns = []
            for columns_item_data in _columns:
                columns_item = TableColumnInput.from_dict(columns_item_data)

                columns.append(columns_item)

        table_ingest_input = cls(
            table_name=table_name,
            table_desc=table_desc,
            table_type=table_type,
            table_tags=table_tags,
            table_usage_count=table_usage_count,
            table_deprecated=table_deprecated,
            columns=columns,
        )

        table_ingest_input.additional_properties = d
        return table_ingest_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
