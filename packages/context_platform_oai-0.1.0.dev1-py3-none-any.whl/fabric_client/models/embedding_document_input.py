from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.embedding_document_input_payload import EmbeddingDocumentInputPayload


T = TypeVar("T", bound="EmbeddingDocumentInput")


@_attrs_define
class EmbeddingDocumentInput:
    """
    Attributes:
        doc_id (str): Stable identifier for the chunk or document being embedded.
        text (str): Raw text content to index into the embeddings backend.
        payload (EmbeddingDocumentInputPayload | Unset): Additional metadata stored alongside the embedded document.
    """

    doc_id: str
    text: str
    payload: EmbeddingDocumentInputPayload | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        doc_id = self.doc_id

        text = self.text

        payload: dict[str, Any] | Unset = UNSET
        if not isinstance(self.payload, Unset):
            payload = self.payload.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "doc_id": doc_id,
                "text": text,
            }
        )
        if payload is not UNSET:
            field_dict["payload"] = payload

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.embedding_document_input_payload import EmbeddingDocumentInputPayload

        d = dict(src_dict)
        doc_id = d.pop("doc_id")

        text = d.pop("text")

        _payload = d.pop("payload", UNSET)
        payload: EmbeddingDocumentInputPayload | Unset
        if isinstance(_payload, Unset):
            payload = UNSET
        else:
            payload = EmbeddingDocumentInputPayload.from_dict(_payload)

        embedding_document_input = cls(
            doc_id=doc_id,
            text=text,
            payload=payload,
        )

        embedding_document_input.additional_properties = d
        return embedding_document_input

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
