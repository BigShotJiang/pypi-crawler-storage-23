from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.retrieve_files_query import RetrieveFilesQuery


T = TypeVar("T", bound="RetrieveFilesBatchRequest")


@_attrs_define
class RetrieveFilesBatchRequest:
    """
    Attributes:
        queries (list[RetrieveFilesQuery] | Unset): Batch of file retrieval requests to execute.
    """

    queries: list[RetrieveFilesQuery] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        queries: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.queries, Unset):
            queries = []
            for queries_item_data in self.queries:
                queries_item = queries_item_data.to_dict()
                queries.append(queries_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if queries is not UNSET:
            field_dict["queries"] = queries

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.retrieve_files_query import RetrieveFilesQuery

        d = dict(src_dict)
        _queries = d.pop("queries", UNSET)
        queries: list[RetrieveFilesQuery] | Unset = UNSET
        if _queries is not UNSET:
            queries = []
            for queries_item_data in _queries:
                queries_item = RetrieveFilesQuery.from_dict(queries_item_data)

                queries.append(queries_item)

        retrieve_files_batch_request = cls(
            queries=queries,
        )

        retrieve_files_batch_request.additional_properties = d
        return retrieve_files_batch_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
