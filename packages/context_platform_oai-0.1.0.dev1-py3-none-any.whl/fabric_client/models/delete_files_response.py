from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="DeleteFilesResponse")


@_attrs_define
class DeleteFilesResponse:
    """
    Attributes:
        status (str): High-level deletion status.
        requested (int): Number of file IDs requested for deletion.
        metadata_deleted (int): Number of file metadata records removed.
        embeddings_deleted (int | Unset): Number of embeddings records removed. Default: 0.
        errors (list[str] | Unset): Per-item deletion errors, if any.
    """

    status: str
    requested: int
    metadata_deleted: int
    embeddings_deleted: int | Unset = 0
    errors: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        status = self.status

        requested = self.requested

        metadata_deleted = self.metadata_deleted

        embeddings_deleted = self.embeddings_deleted

        errors: list[str] | Unset = UNSET
        if not isinstance(self.errors, Unset):
            errors = self.errors

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
                "requested": requested,
                "metadata_deleted": metadata_deleted,
            }
        )
        if embeddings_deleted is not UNSET:
            field_dict["embeddings_deleted"] = embeddings_deleted
        if errors is not UNSET:
            field_dict["errors"] = errors

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = d.pop("status")

        requested = d.pop("requested")

        metadata_deleted = d.pop("metadata_deleted")

        embeddings_deleted = d.pop("embeddings_deleted", UNSET)

        errors = cast(list[str], d.pop("errors", UNSET))

        delete_files_response = cls(
            status=status,
            requested=requested,
            metadata_deleted=metadata_deleted,
            embeddings_deleted=embeddings_deleted,
            errors=errors,
        )

        delete_files_response.additional_properties = d
        return delete_files_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
