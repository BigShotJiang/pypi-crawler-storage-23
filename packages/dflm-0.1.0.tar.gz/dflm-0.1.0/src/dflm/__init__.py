"""dLLM: A fast and easy-to-use library for diffusion LLM inference and serving."""

__version__ = "0.1.0"
