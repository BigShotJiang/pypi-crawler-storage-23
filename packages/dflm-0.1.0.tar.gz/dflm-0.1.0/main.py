def main():
    print("Hello from dllm!")


if __name__ == "__main__":
    main()
