"""
ProxyDL - HTTP/FTP Folder Downloader with Browser & Proxy Support
A powerful GUI downloader that can recursively download HTTP/FTP directories
with SOCKS5/HTTP proxy support.
"""

__version__ = "1.0.0"
__author__ = "rakib"
__email__ = ""
__license__ = "MIT"

from .downloader_gui import main, HttpDownloaderGUI, EnhancedBrowser

__all__ = ["main", "HttpDownloaderGUI", "EnhancedBrowser"]
