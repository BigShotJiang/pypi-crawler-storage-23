# mkdocs-markdoc: MkDocs plugin that renders pages with Stripe's Markdoc
