```{include} ../developing.md
:start-line: 0
:relative-docs: www.biosustain.com/growthcurves/docs
:relative-images:
```
