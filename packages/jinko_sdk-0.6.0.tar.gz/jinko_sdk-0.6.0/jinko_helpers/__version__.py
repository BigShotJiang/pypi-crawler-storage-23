"""
jinko_helpers package version number (auto-generated).
"""

__version__ = "0.6.0"
