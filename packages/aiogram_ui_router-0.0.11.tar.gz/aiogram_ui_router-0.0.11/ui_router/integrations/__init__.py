from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ui_router.integrations.apscheduler_scheduler import APSchedulerEventScheduler
    from ui_router.integrations.taskiq_scheduler import TaskiqEventScheduler

__all__ = ["APSchedulerEventScheduler", "TaskiqEventScheduler"]


def __getattr__(name: str) -> Any:
    if name == "APSchedulerEventScheduler":
        from ui_router.integrations.apscheduler_scheduler import APSchedulerEventScheduler

        return APSchedulerEventScheduler

    if name == "TaskiqEventScheduler":
        from ui_router.integrations.taskiq_scheduler import TaskiqEventScheduler

        return TaskiqEventScheduler

    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)
