# 🩺 doctor-chrome

A simple, interactive TUI tool to detect and fix **Chrome ↔ ChromeDriver version conflicts**.

No more guessing.
No more Selenium errors.
Just run one command and fix it.

---

## 🚀 Why doctor-chrome?

If you’ve ever seen this:
``The chromedriver version (...) might not be compatible with the detected chrome version (...)``


## You know the pain.

`doctor-chrome` detects:
- Installed Chrome version
- Installed ChromeDriver version
- Major version mismatches
- Missing binaries
- PATH conflicts

And gives you clear, actionable options to fix them.

---

## 🖥 Features

- ✅ Detect Chrome version (macOS & Linux)
- ✅ Detect ChromeDriver version
- ✅ Highlight mismatches
- ✅ Interactive TUI interface
- ✅ Suggest safe fixes
- ✅ Remove conflicting drivers
- ✅ Developer-friendly output

---

## 📦 Installation

```bash
pip install doctor-chrome
```

## Usage

```sh
doctor-chrome
```