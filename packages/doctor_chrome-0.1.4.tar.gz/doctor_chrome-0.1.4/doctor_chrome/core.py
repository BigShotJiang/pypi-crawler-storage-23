import subprocess
import platform
import re
import shutil

def run(cmd):
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL).decode().strip()
    except:
        return None

def get_chrome_version():
    system = platform.system()
    if system == "Darwin":
        out = run('/Applications/Google\\ Chrome.app/Contents/MacOS/Google\\ Chrome --version')
    else:
        out = run('google-chrome --version') or run('chromium --version')
    if not out:
        return None
    match = re.search(r'(\d+\.\d+\.\d+\.\d+)', out)
    return match.group(1) if match else None

def get_driver_version():
    if not shutil.which("chromedriver"):
        return None
    out = run('chromedriver --version')
    if not out:
        return None
    match = re.search(r'(\d+\.\d+\.\d+\.\d+)', out)
    return match.group(1) if match else None

def major(v):
    return v.split('.')[0] if v else None

def status():
    chrome = get_chrome_version()
    driver = get_driver_version()
    if not chrome:
        return chrome, driver, "Chrome not found"
    if not driver:
        return chrome, driver, "Driver not found"
    if major(chrome) == major(driver):
        return chrome, driver, "OK"
    return chrome, driver, "Mismatch"