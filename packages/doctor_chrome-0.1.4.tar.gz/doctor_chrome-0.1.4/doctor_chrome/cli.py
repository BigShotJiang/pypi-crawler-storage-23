from .tui import run

def main():
    run()