# branthebuilder

[![Documentation Status](https://readthedocs.org/projects/branthebuilder/badge/?version=latest)](https://branthebuilder.readthedocs.io/en/latest)
[![codecov](https://img.shields.io/codecov/c/github/endremborza/branthebuilder)](https://codecov.io/gh/endremborza/branthebuilder)
[![pypi](https://img.shields.io/pypi/v/branthebuilder.svg)](https://pypi.org/project/branthebuilder/)

Utility CLI for creating, documenting, testing minimal python packages. Uses a [cookiecutter template](https://github.com/endremborza/python-boilerplate-v2).
