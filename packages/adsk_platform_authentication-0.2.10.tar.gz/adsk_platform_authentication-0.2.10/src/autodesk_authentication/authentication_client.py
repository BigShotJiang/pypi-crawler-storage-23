"""Authentication client module.

This is the Python equivalent of the C# ``AuthenticationClient``.
"""
from __future__ import annotations

from typing import Optional

import httpx
from kiota_abstractions.authentication import AnonymousAuthenticationProvider
from kiota_http.httpx_request_adapter import HttpxRequestAdapter

from autodesk_common_httpclient import HttpClientFactory

from autodesk_authentication.authentication_client_helper import (
    AuthenticationClientHelper,
)
from autodesk_authentication.generated_code.base_authentication_client import (
    BaseAuthenticationClient,
)


class AuthenticationClient:
    """High-level Autodesk Authentication client.

    Wraps the generated :class:`BaseAuthenticationClient` and provides an
    :class:`AuthenticationClientHelper` for common authentication flows.

    Args:
        http_client: Optional ``httpx.AsyncClient`` to use. If ``None``, a new
            client with Kiota defaults is created.
    """

    def __init__(self, http_client: Optional[httpx.AsyncClient] = None) -> None:
        if http_client is None:
            http_client = HttpClientFactory.create()

        adapter = HttpxRequestAdapter(
            authentication_provider=AnonymousAuthenticationProvider(),
            http_client=http_client,
        )

        self._api = BaseAuthenticationClient(adapter)
        self._helper = AuthenticationClientHelper(self._api, http_client)

    @property
    def api(self) -> BaseAuthenticationClient:
        """The full generated Authentication API client."""
        return self._api

    @property
    def helper(self) -> AuthenticationClientHelper:
        """Convenience helper for common authentication flows."""
        return self._helper
