"""Helper utilities for the Autodesk Authentication SDK.

This is the Python equivalent of the C# ``AuthenticationClientHelper``.
"""
from __future__ import annotations

import base64
import hashlib
import os
import secrets
import string
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import Optional
from urllib.parse import parse_qs, urlencode, urlparse

import httpx

from autodesk_authentication.generated_code.base_authentication_client import (
    BaseAuthenticationClient,
)
from autodesk_authentication.generated_code.authentication.v2.token.token_post_request_body import (
    TokenPostRequestBody,
)
from autodesk_authentication.generated_code.models.granttype import Granttype
from autodesk_authentication.models.auth_token_extended import AuthTokenExtended
from autodesk_authentication.models.authentication_scope import AuthenticationScope
from autodesk_authentication.models.token_store import TokenStore


@dataclass
class UserInfo:
    """User profile information returned by the Autodesk ``/userinfo`` endpoint."""

    email: Optional[str] = None
    email_verified: Optional[bool] = None
    family_name: Optional[str] = None
    given_name: Optional[str] = None
    locale: Optional[str] = None
    name: Optional[str] = None
    picture: Optional[str] = None
    preferred_username: Optional[str] = None
    profile: Optional[str] = None
    sub: Optional[str] = None
    updated_at: Optional[int] = None


class AuthenticationClientHelper:
    """Helper class for the Autodesk Authentication SDK.

    Provides convenience methods for common authentication flows
    (2-legged, 3-legged, PKCE, token refresh, etc.).
    """

    def __init__(
        self,
        api: BaseAuthenticationClient,
        http_client: httpx.AsyncClient,
    ) -> None:
        self._api = api
        self._http_client = http_client

    @property
    def api(self) -> BaseAuthenticationClient:
        """The underlying generated Authentication API client."""
        return self._api

    # ── Authentication URL builders ──────────────────────────────────────

    @staticmethod
    def create_authentication_url(
        client_id: str,
        redirect_uri: str,
        scope: list[AuthenticationScope] | list[str],
        nonce: str = "",
        state: str = "",
        force_login: bool = False,
    ) -> str:
        """Create the URL for reaching the Autodesk login page (3-legged auth).

        Args:
            client_id: Autodesk App Id.
            redirect_uri: Callback URL.
            scope: Token scopes.
            nonce: Optional, except if scope includes ``openid``.
            state: Optional opaque state parameter.
            force_login: If ``True``, ignore the current session and force re-login.

        Returns:
            URL for the Autodesk login page.
        """
        scope_str = _create_scope_string(scope)
        params: dict[str, str] = {
            "response_type": "code",
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "scope": scope_str,
        }

        if nonce:
            params["nonce"] = nonce
        if state:
            params["state"] = state
        if force_login:
            params["prompt"] = "login"

        return f"https://developer.api.autodesk.com/authentication/v2/authorize?{urlencode(params)}"

    @staticmethod
    def create_pkce_authentication_url(
        client_id: str,
        redirect_uri: str,
        scope: list[AuthenticationScope] | list[str],
        code_challenge: str,
        nonce: str = "",
        state: str = "",
        force_login: bool = False,
    ) -> str:
        """Create the URL for reaching the Autodesk login page with PKCE authentication.

        Args:
            client_id: Autodesk App Id.
            redirect_uri: Callback URL.
            scope: Token scopes.
            code_challenge: PKCE code challenge (S256).
            nonce: Optional, except if scope includes ``openid``.
            state: Optional opaque state parameter.
            force_login: If ``True``, ignore the current session and force re-login.

        Returns:
            URL for Autodesk PKCE authentication.
        """
        base_url = AuthenticationClientHelper.create_authentication_url(
            client_id, redirect_uri, scope, nonce, state, force_login
        )
        return f"{base_url}&{urlencode({'code_challenge': code_challenge, 'code_challenge_method': 'S256'})}"

    @staticmethod
    def create_pkce_code_challenge() -> tuple[str, str]:
        """Generate a PKCE code verifier and its corresponding code challenge.

        Returns:
            A ``(code_verifier, code_challenge)`` tuple.
        """
        code_verifier = _generate_random_code_verifier()
        digest = hashlib.sha256(code_verifier.encode("ascii")).digest()
        code_challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
        return code_verifier, code_challenge

    @staticmethod
    def extract_code_from_url(url: str) -> Optional[str]:
        """Extract the authorization ``code`` query parameter from a callback URL.

        Args:
            url: The full callback URL from Autodesk Authentication.

        Returns:
            The code value, or ``None`` if not present.
        """
        parsed = urlparse(url)
        qs = parse_qs(parsed.query)
        codes = qs.get("code")
        return codes[0] if codes else None

    # ── Token helpers ────────────────────────────────────────────────────

    async def get_two_legged_token(
        self,
        client_id: str,
        client_secret: str,
        scopes: list[str] | list[AuthenticationScope],
    ) -> AuthTokenExtended:
        """Obtain a 2-legged (client credentials) token.

        Args:
            client_id: Autodesk App Id.
            client_secret: Autodesk App Secret.
            scopes: List of scopes.

        Returns:
            An :class:`AuthTokenExtended` with an ``expires_at`` timestamp.
        """
        body = TokenPostRequestBody()
        body.grant_type = Granttype.Client_credentials
        body.scope = _create_scope_string(scopes)

        auth_string = self.create_authorization_string(client_id, client_secret)

        result = await self._api.authentication.v2.token.post(
            body,
            request_configuration=lambda r: r.headers.add("Authorization", auth_string),
        )

        return AuthTokenExtended(result)

    async def refresh_three_legged_token(
        self,
        client_id: str,
        client_secret: str,
        refresh_token: str,
        scopes: Optional[list[str] | list[AuthenticationScope]] = None,
    ) -> AuthTokenExtended:
        """Refresh a 3-legged token.

        Args:
            client_id: Autodesk App Id.
            client_secret: Autodesk App Secret.
            refresh_token: Refresh token returned by the previous authentication.
            scopes: Optional new scopes (can only reduce the initial scope).

        Returns:
            A fresh :class:`AuthTokenExtended`.

        Raises:
            ValueError: If the returned token is ``None``.
        """
        body = TokenPostRequestBody()
        body.grant_type = Granttype.Refresh_token
        body.refresh_token = refresh_token
        body.scope = _create_scope_string(scopes) if scopes else None

        auth_string = self.create_authorization_string(client_id, client_secret)

        result = await self._api.authentication.v2.token.post(
            body,
            request_configuration=lambda r: r.headers.add("Authorization", auth_string),
        )

        if result is None:
            raise ValueError("Token response is None")

        return AuthTokenExtended(result)

    def create_two_legged_auto_refresh_token(
        self,
        client_id: str,
        client_secret: str,
        scopes: list[str] | list[AuthenticationScope],
        token_store: TokenStore,
    ) -> Callable[[], Awaitable[str]]:
        """Create an auto-refreshing 2-legged token function.

        The returned async callable checks the ``token_store`` for a valid token.
        If the token is missing or about to expire (< 10 s remaining), a new
        token is fetched automatically.

        Args:
            client_id: Autodesk App Id.
            client_secret: Autodesk App Secret.
            scopes: List of scopes.
            token_store: Storage backend for caching the token.

        Returns:
            An async function that always returns a valid access token string.
        """

        async def _get_token() -> str:
            current_token = token_store.get()

            if current_token is None or not current_token.is_valid:
                new_token = await self.get_two_legged_token(client_id, client_secret, scopes)
                token_store.set(new_token)
                current_token = new_token

            return current_token.access_token or ""

        return _get_token

    async def get_user_info(self, three_legged_token: str) -> UserInfo:
        """Get user profile information.

        Args:
            three_legged_token: A valid 3-legged access token.

        Returns:
            A :class:`UserInfo` dataclass with the user's profile.

        Raises:
            httpx.HTTPStatusError: If the request fails.
        """
        userinfo_url = "https://api.userprofile.autodesk.com/userinfo"

        response = await self._http_client.get(
            userinfo_url,
            headers={"Authorization": f"Bearer {three_legged_token}"},
        )
        response.raise_for_status()

        data = response.json()
        return UserInfo(
            email=data.get("email"),
            email_verified=data.get("email_verified"),
            family_name=data.get("family_name"),
            given_name=data.get("given_name"),
            locale=data.get("locale"),
            name=data.get("name"),
            picture=data.get("picture"),
            preferred_username=data.get("preferred_username"),
            profile=data.get("profile"),
            sub=data.get("sub"),
            updated_at=data.get("updated_at"),
        )

    # ── Utility methods ──────────────────────────────────────────────────

    @staticmethod
    def create_authorization_string(client_id: str, client_secret: str) -> str:
        """Combine client id and client secret into a Basic auth header value.

        Args:
            client_id: Autodesk App Id.
            client_secret: Autodesk App Secret.

        Returns:
            ``Basic <base64(client_id:client_secret)>``.
        """
        credentials = f"{client_id}:{client_secret}"
        encoded = base64.b64encode(credentials.encode("utf-8")).decode("utf-8")
        return f"Basic {encoded}"

    @staticmethod
    def is_valid_token(auth_token: Optional[AuthTokenExtended]) -> bool:
        """Check if a token is still valid (expires in more than 10 seconds).

        Args:
            auth_token: The token to check.

        Returns:
            ``True`` if the token is valid.
        """
        if auth_token is None:
            return False
        return auth_token.is_valid


# ── Private helpers ──────────────────────────────────────────────────────

_ALLOWED_CHARS = string.ascii_letters + string.digits + "-._~"


def _generate_random_code_verifier(length: int = 64) -> str:
    """Generate a random PKCE code verifier (43–128 chars, RFC 7636).

    Args:
        length: The length of the verifier (between 43 and 128).

    Returns:
        A random string containing only ``[A-Za-z0-9\\-._~]``.

    Raises:
        ValueError: If *length* is not in the valid range.
    """
    if length < 43 or length > 128:
        raise ValueError("Length must be between 43 and 128.")
    return "".join(secrets.choice(_ALLOWED_CHARS) for _ in range(length))


def _create_scope_string(scopes: list[str] | list[AuthenticationScope]) -> str:
    """Join a list of scopes into a space-separated string."""
    return " ".join(str(s.value) if isinstance(s, AuthenticationScope) else s for s in scopes)
