"""Token store abstractions and in-memory implementation."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from autodesk_authentication.models.auth_token_extended import AuthTokenExtended


class TokenStore(ABC):
    """Abstract base for storing and retrieving an :class:`AuthTokenExtended`."""

    @abstractmethod
    def get(self) -> Optional[AuthTokenExtended]:
        """Read the token from the store."""
        ...

    @abstractmethod
    def set(self, auth_token: AuthTokenExtended) -> None:
        """Save the token in the store."""
        ...


class InMemoryTokenStore(TokenStore):
    """Simple in-memory token store."""

    def __init__(self) -> None:
        self._token: Optional[AuthTokenExtended] = None

    def get(self) -> Optional[AuthTokenExtended]:
        return self._token

    def set(self, auth_token: AuthTokenExtended) -> None:
        self._token = auth_token
