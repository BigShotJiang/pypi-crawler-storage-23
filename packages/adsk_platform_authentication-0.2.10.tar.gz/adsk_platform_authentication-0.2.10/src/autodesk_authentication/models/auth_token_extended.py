"""Extended auth token with expiration date tracking."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Optional

from autodesk_authentication.generated_code.models.auth_token import AuthToken


@dataclass
class AuthTokenExtended:
    """Wraps an :class:`AuthToken` and adds an absolute ``expires_at`` timestamp.

    Args:
        auth_token: The raw token returned by the Autodesk authentication API.
        created_at: The UTC time when the token was created. Defaults to ``datetime.now(timezone.utc)``.
    """

    access_token: Optional[str] = None
    expires_in: Optional[int] = None
    refresh_token: Optional[str] = None
    id_token: Optional[str] = None
    expires_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def __init__(
        self,
        auth_token: Optional[AuthToken] = None,
        created_at: Optional[datetime] = None,
    ) -> None:
        if created_at is None:
            created_at = datetime.now(timezone.utc)

        if auth_token is not None:
            self.access_token = auth_token.access_token
            self.expires_in = auth_token.expires_in
            self.refresh_token = auth_token.refresh_token
            self.id_token = auth_token.id_token
            self.expires_at = created_at + timedelta(
                seconds=auth_token.expires_in or 0
            )
        else:
            self.access_token = None
            self.expires_in = None
            self.refresh_token = None
            self.id_token = None
            self.expires_at = created_at

    @property
    def is_valid(self) -> bool:
        """Return ``True`` if the token expires in more than 10 seconds."""
        remaining = (self.expires_at - datetime.now(timezone.utc)).total_seconds()
        return remaining > 10
