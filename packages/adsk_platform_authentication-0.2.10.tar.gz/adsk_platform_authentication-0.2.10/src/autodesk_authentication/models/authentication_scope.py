"""Authentication scope constants for Autodesk Platform Services."""
from __future__ import annotations

from enum import Enum


class AuthenticationScope(str, Enum):
    """OAuth 2.0 scopes supported by Autodesk Platform Services."""

    USER_PROFILE_READ = "user-profile:read"
    USER_READ = "user:read"
    USER_WRITE = "user:write"
    VIEWABLES_READ = "viewables:read"
    DATA_READ = "data:read"
    DATA_WRITE = "data:write"
    DATA_CREATE = "data:create"
    DATA_SEARCH = "data:search"
    BUCKET_CREATE = "bucket:create"
    BUCKET_READ = "bucket:read"
    BUCKET_UPDATE = "bucket:update"
    BUCKET_DELETE = "bucket:delete"
    CODE_ALL = "code:all"
    ACCOUNT_READ = "account:read"
    ACCOUNT_WRITE = "account:write"
    OPENID = "openid"
