from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

class AuthorizeRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /authentication/v2/authorize
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new AuthorizeRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/authentication/v2/authorize?client_id={client_id}&redirect_uri={redirect_uri}&response_type={response_type}&state={state}{&authoptions*,code_challenge*,code_challenge_method*,nonce*,prompt*,response_mode*,scope*}", path_parameters)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[AuthorizeRequestBuilderGetQueryParameters]] = None) -> None:
        """
        To obtain an authorization code grant or id_token grant.We rate limit this endpoint. When rate limit reached, then Apigee will throw HTTP 429 Too Many Requests error. See Forge docs on the rate limit: [Forge rate limit](https://forge.autodesk.com/en/docs/oauth/v2/developers_guide/rate-limiting/forge-rate-limits/)Errors came from OKTA/PF directly.Please refer forge v2 api document for more details <Link>
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: None
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        return await self.request_adapter.send_no_response_content_async(request_info, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[AuthorizeRequestBuilderGetQueryParameters]] = None) -> RequestInformation:
        """
        To obtain an authorization code grant or id_token grant.We rate limit this endpoint. When rate limit reached, then Apigee will throw HTTP 429 Too Many Requests error. See Forge docs on the rate limit: [Forge rate limit](https://forge.autodesk.com/en/docs/oauth/v2/developers_guide/rate-limiting/forge-rate-limits/)Errors came from OKTA/PF directly.Please refer forge v2 api document for more details <Link>
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def with_url(self,raw_url: str) -> AuthorizeRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: AuthorizeRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return AuthorizeRequestBuilder(self.request_adapter, raw_url)
    
    @dataclass
    class AuthorizeRequestBuilderGetQueryParameters():
        """
        To obtain an authorization code grant or id_token grant.We rate limit this endpoint. When rate limit reached, then Apigee will throw HTTP 429 Too Many Requests error. See Forge docs on the rate limit: [Forge rate limit](https://forge.autodesk.com/en/docs/oauth/v2/developers_guide/rate-limiting/forge-rate-limits/)Errors came from OKTA/PF directly.Please refer forge v2 api document for more details <Link>
        """
        # A Json object carries information to Identity.
        authoptions: Optional[str] = None

        # Client ID.
        client_id: Optional[str] = None

        # A challenge for PKCE. The challenge is verified in the access token request.
        code_challenge: Optional[str] = None

        # Method used to derive the code challenge for PKCE. Must be S256 if `code_challenge` is present.
        code_challenge_method: Optional[str] = None

        # A string value used to associate a Client session with an ID Token, and to mitigate replay attacks. Required if `response_type` is `id_token` or `token`
        nonce: Optional[str] = None

        # Values supported: `login` and `none`.`login`: Always prompt the user for authentication, regardless of the login session.`prompt`: Do not prompt user for authentication. If user is not logged in, the calling application receives an error.
        prompt: Optional[str] = None

        # URL-encoded callback URL.
        redirect_uri: Optional[str] = None

        # The mode of response for the supplied `response_type`. Supported values are `fragment`, `form_post` or `query`. `query` is not supported if the `response_type` is `token`.
        response_mode: Optional[str] = None

        # Must be `code` for authorization code grant, `id_token` for an OpenID Connect ID token.
        response_type: Optional[str] = None

        # URL-encoded, a space-delimited list of scopes. Supported values:1. device_sso2. All scopes mentioned in [Forge Developers Guide](https://forge.autodesk.com/en/docs/oauth/v3/developers_guide/scopes/)
        scope: Optional[str] = None

        # The payload that authorization flow will pass back verbatim in state query parameter to the callback URL. It can contain alphanumeric, comma, period, underscore, and hyphen characters.
        state: Optional[str] = None

    
    @dataclass
    class AuthorizeRequestBuilderGetRequestConfiguration(RequestConfiguration[AuthorizeRequestBuilderGetQueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

