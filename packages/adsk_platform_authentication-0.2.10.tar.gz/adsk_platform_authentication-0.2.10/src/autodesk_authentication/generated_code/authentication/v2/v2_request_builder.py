from __future__ import annotations
from collections.abc import Callable
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.request_adapter import RequestAdapter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .authorize.authorize_request_builder import AuthorizeRequestBuilder
    from .introspect.introspect_request_builder import IntrospectRequestBuilder
    from .keys.keys_request_builder import KeysRequestBuilder
    from .logout.logout_request_builder import LogoutRequestBuilder
    from .revoke.revoke_request_builder import RevokeRequestBuilder
    from .token.token_request_builder import TokenRequestBuilder

class V2RequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /authentication/v2
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new V2RequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/authentication/v2", path_parameters)
    
    @property
    def authorize(self) -> AuthorizeRequestBuilder:
        """
        The authorize property
        """
        from .authorize.authorize_request_builder import AuthorizeRequestBuilder

        return AuthorizeRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def introspect(self) -> IntrospectRequestBuilder:
        """
        The introspect property
        """
        from .introspect.introspect_request_builder import IntrospectRequestBuilder

        return IntrospectRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def keys(self) -> KeysRequestBuilder:
        """
        The keys property
        """
        from .keys.keys_request_builder import KeysRequestBuilder

        return KeysRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def logout(self) -> LogoutRequestBuilder:
        """
        The logout property
        """
        from .logout.logout_request_builder import LogoutRequestBuilder

        return LogoutRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def revoke(self) -> RevokeRequestBuilder:
        """
        The revoke property
        """
        from .revoke.revoke_request_builder import RevokeRequestBuilder

        return RevokeRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def token(self) -> TokenRequestBuilder:
        """
        The token property
        """
        from .token.token_request_builder import TokenRequestBuilder

        return TokenRequestBuilder(self.request_adapter, self.path_parameters)
    

