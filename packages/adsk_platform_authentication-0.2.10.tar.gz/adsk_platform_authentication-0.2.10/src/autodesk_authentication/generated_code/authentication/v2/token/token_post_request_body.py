from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

if TYPE_CHECKING:
    from ....models.granttype import Granttype

@dataclass
class TokenPostRequestBody(Parsable):
    # Required if `grant_type` is `urn:ietf:params:oauth:grant-type:jwt-bearer`
    assertion: Optional[str] = None
    # This field is required for public client
    client_id: Optional[str] = None
    # Required if `grant_type` is `authorization_code`
    code: Optional[str] = None
    # Required if `grant_type` is `authorization_code` and `code_challenge` was specified in /authorize request
    code_verifier: Optional[str] = None
    # Enum for grant types
    grant_type: Optional[Granttype] = None
    # Required if `grant_type` is `authorization_code`
    redirect_uri: Optional[str] = None
    # Required if `grant_type` is `refresh_token`
    refresh_token: Optional[str] = None
    # Required if `grant_type` is `client_credentials. Scopes must be separated by a space.`
    scope: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> TokenPostRequestBody:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: TokenPostRequestBody
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return TokenPostRequestBody()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from ....models.granttype import Granttype

        from ....models.granttype import Granttype

        fields: dict[str, Callable[[Any], None]] = {
            "assertion": lambda n : setattr(self, 'assertion', n.get_str_value()),
            "client_id": lambda n : setattr(self, 'client_id', n.get_str_value()),
            "code": lambda n : setattr(self, 'code', n.get_str_value()),
            "code_verifier": lambda n : setattr(self, 'code_verifier', n.get_str_value()),
            "grant_type": lambda n : setattr(self, 'grant_type', n.get_enum_value(Granttype)),
            "redirect_uri": lambda n : setattr(self, 'redirect_uri', n.get_str_value()),
            "refresh_token": lambda n : setattr(self, 'refresh_token', n.get_str_value()),
            "scope": lambda n : setattr(self, 'scope', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("assertion", self.assertion)
        writer.write_str_value("client_id", self.client_id)
        writer.write_str_value("code", self.code)
        writer.write_str_value("code_verifier", self.code_verifier)
        writer.write_enum_value("grant_type", self.grant_type)
        writer.write_str_value("redirect_uri", self.redirect_uri)
        writer.write_str_value("refresh_token", self.refresh_token)
        writer.write_str_value("scope", self.scope)
    

