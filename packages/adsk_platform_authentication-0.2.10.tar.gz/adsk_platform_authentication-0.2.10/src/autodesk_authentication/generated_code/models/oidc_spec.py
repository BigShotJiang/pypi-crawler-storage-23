from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class OidcSpec(Parsable):
    """
    OIDC Specification
    """
    # The authorization_endpoint property
    authorization_endpoint: Optional[str] = None
    # The grant_types_supported property
    grant_types_supported: Optional[list[str]] = None
    # The id_token_signing_alg_values_supported property
    id_token_signing_alg_values_supported: Optional[list[str]] = None
    # The introspection_endpoint property
    introspection_endpoint: Optional[str] = None
    # The issuer property
    issuer: Optional[str] = None
    # The jwks_uri property
    jwks_uri: Optional[str] = None
    # The response_modes_supported property
    response_modes_supported: Optional[list[str]] = None
    # The response_types_supported property
    response_types_supported: Optional[list[str]] = None
    # The revocation_endpoint property
    revocation_endpoint: Optional[str] = None
    # The scopes_supported property
    scopes_supported: Optional[list[str]] = None
    # The subject_types_supported property
    subject_types_supported: Optional[list[str]] = None
    # The token_endpoint property
    token_endpoint: Optional[str] = None
    # The userinfo_endpoint property
    userinfo_endpoint: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> OidcSpec:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: OidcSpec
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return OidcSpec()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "authorization_endpoint": lambda n : setattr(self, 'authorization_endpoint', n.get_str_value()),
            "grant_types_supported": lambda n : setattr(self, 'grant_types_supported', n.get_collection_of_primitive_values(str)),
            "id_token_signing_alg_values_supported": lambda n : setattr(self, 'id_token_signing_alg_values_supported', n.get_collection_of_primitive_values(str)),
            "introspection_endpoint": lambda n : setattr(self, 'introspection_endpoint', n.get_str_value()),
            "issuer": lambda n : setattr(self, 'issuer', n.get_str_value()),
            "jwks_uri": lambda n : setattr(self, 'jwks_uri', n.get_str_value()),
            "response_modes_supported": lambda n : setattr(self, 'response_modes_supported', n.get_collection_of_primitive_values(str)),
            "response_types_supported": lambda n : setattr(self, 'response_types_supported', n.get_collection_of_primitive_values(str)),
            "revocation_endpoint": lambda n : setattr(self, 'revocation_endpoint', n.get_str_value()),
            "scopes_supported": lambda n : setattr(self, 'scopes_supported', n.get_collection_of_primitive_values(str)),
            "subject_types_supported": lambda n : setattr(self, 'subject_types_supported', n.get_collection_of_primitive_values(str)),
            "token_endpoint": lambda n : setattr(self, 'token_endpoint', n.get_str_value()),
            "userinfo_endpoint": lambda n : setattr(self, 'userinfo_endpoint', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("authorization_endpoint", self.authorization_endpoint)
        writer.write_collection_of_primitive_values("grant_types_supported", self.grant_types_supported)
        writer.write_collection_of_primitive_values("id_token_signing_alg_values_supported", self.id_token_signing_alg_values_supported)
        writer.write_str_value("introspection_endpoint", self.introspection_endpoint)
        writer.write_str_value("issuer", self.issuer)
        writer.write_str_value("jwks_uri", self.jwks_uri)
        writer.write_collection_of_primitive_values("response_modes_supported", self.response_modes_supported)
        writer.write_collection_of_primitive_values("response_types_supported", self.response_types_supported)
        writer.write_str_value("revocation_endpoint", self.revocation_endpoint)
        writer.write_collection_of_primitive_values("scopes_supported", self.scopes_supported)
        writer.write_collection_of_primitive_values("subject_types_supported", self.subject_types_supported)
        writer.write_str_value("token_endpoint", self.token_endpoint)
        writer.write_str_value("userinfo_endpoint", self.userinfo_endpoint)
    

