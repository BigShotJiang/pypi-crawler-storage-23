from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class UserInfo(Parsable):
    # The email property
    email: Optional[str] = None
    # The email_verified property
    email_verified: Optional[bool] = None
    # The family_name property
    family_name: Optional[str] = None
    # The given_name property
    given_name: Optional[str] = None
    # The locale property
    locale: Optional[str] = None
    # The name property
    name: Optional[str] = None
    # The picture property
    picture: Optional[str] = None
    # The preferred_username property
    preferred_username: Optional[str] = None
    # The profile property
    profile: Optional[str] = None
    # The sub property
    sub: Optional[str] = None
    # The updated_at property
    updated_at: Optional[int] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> UserInfo:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: UserInfo
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return UserInfo()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "email": lambda n : setattr(self, 'email', n.get_str_value()),
            "email_verified": lambda n : setattr(self, 'email_verified', n.get_bool_value()),
            "family_name": lambda n : setattr(self, 'family_name', n.get_str_value()),
            "given_name": lambda n : setattr(self, 'given_name', n.get_str_value()),
            "locale": lambda n : setattr(self, 'locale', n.get_str_value()),
            "name": lambda n : setattr(self, 'name', n.get_str_value()),
            "picture": lambda n : setattr(self, 'picture', n.get_str_value()),
            "preferred_username": lambda n : setattr(self, 'preferred_username', n.get_str_value()),
            "profile": lambda n : setattr(self, 'profile', n.get_str_value()),
            "sub": lambda n : setattr(self, 'sub', n.get_str_value()),
            "updated_at": lambda n : setattr(self, 'updated_at', n.get_int_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("email", self.email)
        writer.write_bool_value("email_verified", self.email_verified)
        writer.write_str_value("family_name", self.family_name)
        writer.write_str_value("given_name", self.given_name)
        writer.write_str_value("locale", self.locale)
        writer.write_str_value("name", self.name)
        writer.write_str_value("picture", self.picture)
        writer.write_str_value("preferred_username", self.preferred_username)
        writer.write_str_value("profile", self.profile)
        writer.write_str_value("sub", self.sub)
        writer.write_int_value("updated_at", self.updated_at)
    

