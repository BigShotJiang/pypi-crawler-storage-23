from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.api_error import APIError
from kiota_abstractions.serialization import Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class Error(APIError, Parsable):
    # A short explanation, typically meant to assist diagnose the cause of the error
    developer_message: Optional[str] = None
    # The errorCode property
    error_code: Optional[str] = None
    # The moreInfo property
    more_info: Optional[str] = None
    # A short, generic description of the error, meant for an end-user audience.
    user_message: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Error:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Error
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Error()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "developerMessage": lambda n : setattr(self, 'developer_message', n.get_str_value()),
            "errorCode": lambda n : setattr(self, 'error_code', n.get_str_value()),
            "more info": lambda n : setattr(self, 'more_info', n.get_str_value()),
            "userMessage": lambda n : setattr(self, 'user_message', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("developerMessage", self.developer_message)
        writer.write_str_value("errorCode", self.error_code)
        writer.write_str_value("more info", self.more_info)
        writer.write_str_value("userMessage", self.user_message)
    
    @property
    def primary_message(self) -> Optional[str]:
        """
        The primary error message.
        """
        return super().message

