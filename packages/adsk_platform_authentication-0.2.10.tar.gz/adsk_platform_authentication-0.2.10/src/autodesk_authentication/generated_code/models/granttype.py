from enum import Enum

class Granttype(str, Enum):
    Client_credentials = "client_credentials",
    Authorization_code = "authorization_code",
    Refresh_token = "refresh_token",
    UrnIetfParamsOauthGrantTypeJwtBearer = "urn:ietf:params:oauth:grant-type:jwt-bearer",

