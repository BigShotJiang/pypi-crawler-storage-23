"""Autodesk Platform Services: Authentication SDK for Python."""

from autodesk_authentication.authentication_client import AuthenticationClient
from autodesk_authentication.authentication_client_helper import (
    AuthenticationClientHelper,
    UserInfo,
)
from autodesk_authentication.models.auth_token_extended import AuthTokenExtended
from autodesk_authentication.models.authentication_scope import AuthenticationScope
from autodesk_authentication.models.token_store import InMemoryTokenStore, TokenStore

__all__ = [
    "AuthenticationClient",
    "AuthenticationClientHelper",
    "AuthenticationScope",
    "AuthTokenExtended",
    "InMemoryTokenStore",
    "TokenStore",
    "UserInfo",
]
__version__ = "0.1.0"
