# autodesk-authentication - Autodesk Authentication SDK for Python

A Python SDK providing a [Fluent API](https://dzone.com/articles/java-fluent-api) for the [Autodesk Authentication](https://aps.autodesk.com/en/docs/oauth/v2/overview/) APIs, generated from the official OpenAPI specifications using [Microsoft Kiota](https://learn.microsoft.com/en-us/openapi/kiota/overview).

## Installation

```bash
pip install adsk-platform-authentication
```

## Quick Start

```python
from autodesk_authentication import AuthenticationClient

# Initialize the Authentication client
auth_client = AuthenticationClient()
```

### 2-Legged Token (Client Credentials)

```python
import os
from autodesk_authentication import AuthenticationClient

client_id = os.environ["APS_CLIENT_ID"]
client_secret = os.environ["APS_CLIENT_SECRET"]

auth_client = AuthenticationClient()

token = await auth_client.helper.get_two_legged_token(
    client_id,
    client_secret,
    scopes=["data:read", "data:write", "account:read"],
)

print(f"Access Token: {token.access_token}")
print(f"Expires At: {token.expires_at}")
```

### Auto-Refreshing Token

```python
from autodesk_authentication import AuthenticationClient, InMemoryTokenStore

auth_client = AuthenticationClient()
token_store = InMemoryTokenStore()

get_token = auth_client.helper.create_two_legged_auto_refresh_token(
    client_id,
    client_secret,
    scopes=["data:read", "data:write"],
    token_store=token_store,
)

# This callable auto-refreshes when the token is about to expire
access_token = await get_token()
```

### Using Scope Enum

```python
from autodesk_authentication import AuthenticationClient, AuthenticationScope

auth_client = AuthenticationClient()

token = await auth_client.helper.get_two_legged_token(
    client_id,
    client_secret,
    scopes=[AuthenticationScope.DATA_READ, AuthenticationScope.ACCOUNT_READ],
)
```

### 3-Legged Authentication (Authorization Code)

```python
from autodesk_authentication import AuthenticationClient, AuthenticationClientHelper, AuthenticationScope

# Step 1: Generate the login URL
login_url = AuthenticationClientHelper.create_authentication_url(
    client_id=client_id,
    redirect_uri="http://localhost:3000/callback",
    scope=[AuthenticationScope.DATA_READ, AuthenticationScope.VIEWABLES_READ],
)
print(f"Open this URL in a browser: {login_url}")

# Step 2: Extract the code from the callback URL
code = AuthenticationClientHelper.extract_code_from_url(callback_url)
```

### 3-Legged with PKCE

```python
from autodesk_authentication import AuthenticationClientHelper, AuthenticationScope

# Generate PKCE challenge
code_verifier, code_challenge = AuthenticationClientHelper.create_pkce_code_challenge()

# Build the PKCE login URL
login_url = AuthenticationClientHelper.create_pkce_authentication_url(
    client_id=client_id,
    redirect_uri="http://localhost:3000/callback",
    scope=[AuthenticationScope.DATA_READ],
    code_challenge=code_challenge,
)
```

### Refresh a 3-Legged Token

```python
auth_client = AuthenticationClient()

refreshed = await auth_client.helper.refresh_three_legged_token(
    client_id=client_id,
    client_secret=client_secret,
    refresh_token="REFRESH_TOKEN_FROM_PREVIOUS_AUTH",
)
print(f"New access token: {refreshed.access_token}")
```

### Get User Info

```python
auth_client = AuthenticationClient()

user_info = await auth_client.helper.get_user_info(three_legged_token="YOUR_3L_TOKEN")
print(f"Name: {user_info.name}, Email: {user_info.email}")
```

### Using the `.api` Property

The full generated API surface is accessible via `auth_client.api`:

```python
# Direct API call (equivalent to what .helper methods do internally)
from autodesk_authentication.generated_code.authentication.v2.token.token_post_request_body import (
    TokenPostRequestBody,
)
from autodesk_authentication.generated_code.models.granttype import Granttype

body = TokenPostRequestBody()
body.grant_type = Granttype.Client_credentials
body.scope = "data:read"

result = await auth_client.api.authentication.v2.token.post(
    body,
    request_configuration=lambda r: r.headers.add("Authorization", auth_string),
)
```

## Custom HTTP Client

You can provide your own `httpx.AsyncClient` instance:

```python
import httpx

http_client = httpx.AsyncClient(timeout=60.0)
auth_client = AuthenticationClient(http_client=http_client)
```

## Error Handling

```python
from kiota_abstractions.api_error import APIError

try:
    token = await auth_client.helper.get_two_legged_token(client_id, client_secret, scopes)
except APIError as e:
    print(f"Request failed: {e.message}")
    print(f"Status code: {e.response_status_code}")
```

## Requirements

- Python 3.10 or later
- Valid Autodesk Platform Services (APS) application credentials

### Dependencies

- `microsoft-kiota-abstractions`
- `microsoft-kiota-http`
- `microsoft-kiota-serialization-json`
- `microsoft-kiota-serialization-text`
- `microsoft-kiota-serialization-form`
- `microsoft-kiota-serialization-multipart`
- `httpx`

## Documentation

- [Authentication API Documentation](https://aps.autodesk.com/en/docs/oauth/v2/overview/)
- [Autodesk Platform Services](https://aps.autodesk.com/)
- [Microsoft Kiota Documentation](https://learn.microsoft.com/en-us/openapi/kiota/overview)

## License

This project is licensed under the MIT License.
