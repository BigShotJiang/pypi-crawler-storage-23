"""Dual-container mesh integration tests.

Tests real LXMF message delivery through the full RNS stack using two
independent styrened containers connected via TCP mesh transport.
"""
