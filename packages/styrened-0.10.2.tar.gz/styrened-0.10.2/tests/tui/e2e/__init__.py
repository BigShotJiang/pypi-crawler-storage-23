"""End-to-end tests for Styrene multi-node mesh network.

These tests require:
1. Real network connectivity to the Styrene mesh
2. Configuration in tests/e2e_config.yaml
3. Hub (brutus) and/or edge nodes (q502) online

Run with: make test-e2e
"""
