#!/usr/bin/env python3
"""
小红书搜索命令行工具

Usage:
    xhs-search <keyword> [options]
    xhs-search --help
    xhs-search --version

Options:
    -p, --page <n>         页码，默认 1
    -n, --max-pages <n>    最大页数（自动翻页），默认 1
    -o, --output <file>    输出文件路径（JSON 格式）
    --excel <file>         输出 Excel 文件路径
    --sort <type>          排序方式 [general|time_descending|popularity_descending|comment_descending|collect_descending]
    --type <note_type>     笔记类型 [不限 | 视频笔记 | 普通笔记 | 直播笔记]
    --time <time_filter>   时间筛选 [不限 | 一天内 | 一周内 | 半年内]
    -w, --workers <n>      并发工作线程数，默认 1
    -d, --delay <sec>      请求间隔（秒），默认 0.1
    --fetch-details        获取笔记详情（慢）
    -v, --verbose          显示详细信息
    --help                 显示帮助
    --version              显示版本
"""

import sys
import os
import logging
from pathlib import Path
from datetime import datetime
from typing import Optional

from dotenv import load_dotenv

from xiaohongshu_search import __version__
from xiaohongshu_search.core.search_processor import SearchProcessor
from xiaohongshu_search.backend.cookie_manager import CookiePool


# 配置日志
def setup_logging(verbose: bool = False) -> None:
    """配置日志"""
    level = logging.DEBUG if verbose else logging.INFO
    format_str = "%(asctime)s [%(levelname)s] %(message)s"
    
    # 控制台日志
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(logging.Formatter(format_str))
    
    # 文件日志
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)
    log_file = log_dir / f"xhs_search_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter(format_str))
    
    # 根日志器
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)
    
    logging.info(f"日志文件：{log_file}")


def search(
    keyword: str,
    page: int = 1,
    max_pages: int = 1,
    output: Optional[str] = None,
    excel: Optional[str] = None,
    sort_type: str = "general",
    note_type: str = "不限",
    time_filter: str = "不限",
    workers: int = 1,
    delay: float = 0.1,
    fetch_details: bool = False,
    verbose: bool = False,
) -> None:
    """执行搜索"""
    
    # 加载环境变量
    load_dotenv()
    api_key = os.getenv("TIKHUB_API_KEY")
    
    if not api_key:
        logging.error("错误：未找到 TIKHUB_API_KEY")
        logging.error("请设置环境变量或创建 .env 文件")
        logging.error("示例：TIKHUB_API_KEY=your_api_key")
        sys.exit(1)
    
    # 创建处理器
    processor = SearchProcessor(
        api_key=api_key,
        max_workers=workers,
        delay=delay,
    )
    
    logging.info(f"🔍 搜索：{keyword}")
    logging.info(f"   排序：{sort_type} | 类型：{note_type} | 时间：{time_filter}")
    logging.info(f"   并发：{workers} | 延迟：{delay}秒")
    logging.info()
    
    # 执行搜索
    try:
        notes = processor.search(
            keyword=keyword,
            max_pages=max_pages,
            sort_type=sort_type,
            note_type=note_type,
            time_filter=time_filter,
        )
        
        if not notes:
            logging.warning("⚠️  未找到相关笔记")
            return
        
        # 获取详情（可选）
        if fetch_details:
            note_ids = [n.get("note_id") for n in notes if n.get("note_id")]
            if note_ids:
                details = processor.fetch_details(note_ids, max_workers=workers)
                logging.info(f"✓ 获取到 {len(details)} 篇笔记详情")
        
        # 显示统计
        stats = processor.get_stats()
        logging.info()
        logging.info("📊 统计信息:")
        logging.info(f"   找到笔记：{stats.total_found} 篇")
        logging.info(f"   获取页数：{stats.pages_fetched} 页")
        logging.info(f"   搜索耗时：{stats.search_time:.2f}秒")
        if stats.detail_time > 0:
            logging.info(f"   详情耗时：{stats.detail_time:.2f}秒")
        logging.info()
        
        # 显示结果（详细模式）
        if verbose:
            for i, note in enumerate(notes[:10], 1):
                title = note.get("title", "无标题")[:50]
                user = note.get("user", {}).get("nickname", "未知用户")
                liked = note.get("interact_info", {}).get("liked_count", 0)
                logging.info(f"{i}. {title}")
                logging.info(f"   作者：{user} | 点赞：{liked}")
                if note.get("ip_location"):
                    logging.info(f"   IP: {note.get('ip_location')}")
                logging.info()
        
        # 导出到文件
        if output:
            processor.export_json(output)
        
        # 导出到 Excel
        if excel:
            processor.export_excel(excel)
        
        logging.info("✅ 完成")
        
    except Exception as e:
        logging.error(f"❌ 搜索失败：{e}", exc_info=True)
        sys.exit(1)


def main():
    """命令行入口"""
    args = sys.argv[1:]
    
    # 解析参数
    if not args or "--help" in args or "-h" in args:
        print(__doc__)
        return
    
    if "--version" in args:
        print(f"xiaohongshu-search v{__version__}")
        return
    
    # 提取参数
    keyword = None
    page = 1
    max_pages = 1
    output = None
    excel = None
    sort_type = "general"
    note_type = "不限"
    time_filter = "不限"
    workers = 1
    delay = 0.1
    fetch_details = False
    verbose = False
    
    i = 0
    while i < len(args):
        arg = args[i]
        
        if arg.startswith("-"):
            if arg in ["-p", "--page"] and i + 1 < len(args):
                i += 1
                page = int(args[i])
            elif arg in ["-n", "--max-pages"] and i + 1 < len(args):
                i += 1
                max_pages = int(args[i])
            elif arg in ["-o", "--output"] and i + 1 < len(args):
                i += 1
                output = args[i]
            elif arg == "--excel" and i + 1 < len(args):
                i += 1
                excel = args[i]
            elif arg == "--sort" and i + 1 < len(args):
                i += 1
                sort_type = args[i]
            elif arg == "--type" and i + 1 < len(args):
                i += 1
                note_type = args[i]
            elif arg == "--time" and i + 1 < len(args):
                i += 1
                time_filter = args[i]
            elif arg in ["-w", "--workers"] and i + 1 < len(args):
                i += 1
                workers = int(args[i])
            elif arg in ["-d", "--delay"] and i + 1 < len(args):
                i += 1
                delay = float(args[i])
            elif arg == "--fetch-details":
                fetch_details = True
            elif arg in ["-v", "--verbose"]:
                verbose = True
            else:
                print(f"未知选项：{arg}", file=sys.stderr)
                sys.exit(1)
        else:
            if keyword is None:
                keyword = arg
        
        i += 1
    
    if not keyword:
        print("错误：请提供搜索关键词", file=sys.stderr)
        print("用法：xhs-search <keyword> [options]", file=sys.stderr)
        sys.exit(1)
    
    # 配置日志
    setup_logging(verbose)
    
    # 执行搜索
    search(
        keyword=keyword,
        page=page,
        max_pages=max_pages,
        output=output,
        excel=excel,
        sort_type=sort_type,
        note_type=note_type,
        time_filter=time_filter,
        workers=workers,
        delay=delay,
        fetch_details=fetch_details,
        verbose=verbose,
    )


if __name__ == "__main__":
    main()
