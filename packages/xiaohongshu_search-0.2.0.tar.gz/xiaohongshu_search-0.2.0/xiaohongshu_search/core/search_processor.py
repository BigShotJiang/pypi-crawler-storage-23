"""
搜索处理器 - 核心业务逻辑
"""

import os
import time
import json
import threading
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field

from tikhub_xiaohongshu import TikHubClient, TikHubResponse
from xiaohongshu_search.backend.cookie_manager import CookiePool

import logging
logger = logging.getLogger(__name__)


@dataclass
class SearchStats:
    """搜索统计信息"""
    keyword: str = ""
    total_found: int = 0
    pages_fetched: int = 0
    search_time: float = 0.0
    detail_time: float = 0.0
    success_count: int = 0
    failed_count: int = 0
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "keyword": self.keyword,
            "total_found": self.total_found,
            "pages_fetched": self.pages_fetched,
            "search_time_sec": round(self.search_time, 2),
            "detail_time_sec": round(self.detail_time, 2),
            "success_count": self.success_count,
            "failed_count": self.failed_count,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
        }


class SearchProcessor:
    """
    搜索处理器
    
    功能：
    - 执行搜索
    - 并发获取笔记详情
    - 限流控制
    - 统计信息
    - 数据导出
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        cookie_pool: Optional[CookiePool] = None,
        max_workers: int = 1,
        delay: float = 0.1,
        task_id: Optional[str] = None,
    ):
        """
        初始化处理器
        
        Args:
            api_key: TikHub API Key
            cookie_pool: Cookie 池（可选，用于高级模式）
            max_workers: 并发工作线程数
            delay: 请求间隔（秒）
            task_id: 任务 ID
        """
        self.api_key = api_key or os.getenv("TIKHUB_API_KEY")
        self.cookie_pool = cookie_pool
        self.max_workers = max_workers
        self.delay = delay
        self.task_id = task_id or datetime.now().strftime("%Y%m%d%H%M%S")
        
        self.client = TikHubClient(self.api_key) if self.api_key else None
        self.stats = SearchStats()
        self._lock = threading.Lock()
        self._results: List[Dict[str, Any]] = []
        
        # 限流控制
        self._last_request_time = 0.0
    
    def _rate_limit(self) -> None:
        """限流控制"""
        if self.delay <= 0:
            return
        
        with self._lock:
            elapsed = time.time() - self._last_request_time
            if elapsed < self.delay:
                time.sleep(self.delay - elapsed)
            self._last_request_time = time.time()
    
    def search(
        self,
        keyword: str,
        max_pages: int = 1,
        sort_type: str = "general",
        note_type: str = "不限",
        time_filter: str = "不限",
    ) -> List[Dict[str, Any]]:
        """
        执行搜索
        
        Args:
            keyword: 搜索关键词
            max_pages: 最大页数
            sort_type: 排序方式
            note_type: 笔记类型
            time_filter: 时间筛选
            
        Returns:
            搜索结果列表
        """
        if not self.client:
            raise ValueError("未配置 TikHub API Key")
        
        self.stats = SearchStats(
            keyword=keyword,
            start_time=datetime.now()
        )
        
        logger.info(f"🔍 开始搜索：{keyword}")
        logger.info(f"   排序：{sort_type} | 类型：{note_type} | 时间：{time_filter}")
        
        start_time = time.time()
        all_notes = []
        search_id = None
        search_session_id = None
        
        try:
            for page in range(1, max_pages + 1):
                self._rate_limit()
                
                logger.info(f"📄 获取第 {page} 页...")
                
                result = self.client.search_notes(
                    keyword=keyword,
                    page=page,
                    sort_type=sort_type,
                    note_type=note_type,
                    time_filter=time_filter,
                    search_id=search_id,
                    search_session_id=search_session_id,
                )
                
                if not result.success:
                    logger.warning(f"搜索失败：{result.message_zh}")
                    self.stats.failed_count += 1
                    break
                
                notes = result.data.get("notes", []) if result.data else []
                if not notes:
                    logger.info("无更多数据")
                    break
                
                all_notes.extend(notes)
                self.stats.pages_fetched += 1
                self.stats.success_count += 1
                
                # 更新翻页参数
                if result.data:
                    search_id = result.data.get("search_id")
                    search_session_id = result.data.get("search_session_id")
                
                # 检查是否有更多
                if not result.data.get("has_more"):
                    logger.info("已到达最后一页")
                    break
                
                logger.info(f"   当前共 {len(all_notes)} 篇笔记")
            
            self._results = all_notes
            self.stats.total_found = len(all_notes)
            
        except Exception as e:
            logger.error(f"搜索异常：{e}")
            raise
        
        finally:
            self.stats.search_time = time.time() - start_time
            self.stats.end_time = datetime.now()
        
        logger.info(f"✓ 搜索完成：找到 {len(all_notes)} 篇笔记，耗时 {self.stats.search_time:.2f}秒")
        return all_notes
    
    def fetch_details(
        self,
        note_ids: List[str],
        max_workers: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """
        并发获取笔记详情
        
        Args:
            note_ids: 笔记 ID 列表
            max_workers: 并发数
            
        Returns:
            笔记详情列表
        """
        if not note_ids:
            return []
        
        max_workers = max_workers or self.max_workers
        details = []
        start_time = time.time()
        
        logger.info(f"📝 开始获取 {len(note_ids)} 篇笔记详情（并发：{max_workers}）")
        
        def fetch_one(note_id: str) -> Optional[Dict[str, Any]]:
            try:
                self._rate_limit()
                result = self.client.get_note_info(note_id=note_id)
                if result.success:
                    return result.data
                else:
                    logger.warning(f"获取笔记 {note_id} 失败：{result.message_zh}")
                    return None
            except Exception as e:
                logger.error(f"获取笔记 {note_id} 异常：{e}")
                return None
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(fetch_one, nid): nid for nid in note_ids}
            
            for future in as_completed(futures):
                result = future.result()
                if result:
                    details.append(result)
        
        self.stats.detail_time = time.time() - start_time
        logger.info(f"✓ 详情获取完成：{len(details)}/{len(note_ids)}，耗时 {self.stats.detail_time:.2f}秒")
        
        return details
    
    def get_results(self) -> List[Dict[str, Any]]:
        """获取搜索结果"""
        return self._results
    
    def get_stats(self) -> SearchStats:
        """获取统计信息"""
        return self.stats
    
    def export_json(self, output_path: str, include_stats: bool = True) -> None:
        """
        导出为 JSON
        
        Args:
            output_path: 输出文件路径
            include_stats: 是否包含统计信息
        """
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        
        data = {
            "results": self._results,
        }
        
        if include_stats:
            data["stats"] = self.stats.to_dict()
        
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"✓ 已导出 JSON: {output_path}")
    
    def export_excel(self, output_path: str) -> None:
        """
        导出为 Excel
        
        Args:
            output_path: 输出文件路径
        """
        try:
            import pandas as pd
            
            # 扁平化数据
            flat_notes = []
            for note in self._results:
                flat_note = {
                    "note_id": note.get("note_id", ""),
                    "title": note.get("title", "")[:200] if note.get("title") else "",
                    "desc": note.get("desc", "")[:500] if note.get("desc") else "",
                    "type": note.get("type", ""),
                    "user_id": note.get("user", {}).get("user_id", ""),
                    "user_nickname": note.get("user", {}).get("nickname", ""),
                    "liked_count": note.get("interact_info", {}).get("liked_count", 0),
                    "collected_count": note.get("interact_info", {}).get("collected_count", 0),
                    "comment_count": note.get("interact_info", {}).get("comment_count", 0),
                    "share_count": note.get("interact_info", {}).get("share_count", 0),
                    "ip_location": note.get("ip_location", ""),
                    "time": note.get("time", 0),
                }
                
                # 转换时间
                if flat_note["time"]:
                    try:
                        flat_note["time_str"] = datetime.fromtimestamp(
                            int(flat_note["time"]) / 1000
                        ).strftime("%Y-%m-%d %H:%M:%S")
                    except:
                        flat_note["time_str"] = ""
                
                # 图片
                image_list = note.get("image_list", [])
                if image_list:
                    flat_note["images"] = "; ".join(
                        [img.get("url", "") for img in image_list[:3]]
                    )
                else:
                    flat_note["images"] = ""
                
                flat_notes.append(flat_note)
            
            df = pd.DataFrame(flat_notes)
            
            # 调整列顺序
            columns = [
                "note_id", "title", "desc", "type",
                "user_id", "user_nickname",
                "liked_count", "collected_count", "comment_count", "share_count",
                "ip_location", "time", "time_str", "images"
            ]
            df = df[[col for col in columns if col in df.columns]]
            
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            df.to_excel(output_path, index=False, sheet_name="搜索结果")
            
            logger.info(f"✓ 已导出 Excel: {output_path}")
            
        except ImportError:
            logger.error("导出 Excel 需要安装 pandas 和 openpyxl")
            logger.error("运行：pip install pandas openpyxl")
            raise
        except Exception as e:
            logger.error(f"导出 Excel 失败：{e}")
            raise
