"""
Cookie 池管理 - 从后端服务获取和管理 Cookie
"""

import os
import logging
from typing import Optional, List, Tuple
from dataclasses import dataclass
from dotenv import load_dotenv
import requests
from retrying import retry

load_dotenv()

logger = logging.getLogger(__name__)


@dataclass
class CookieData:
    """Cookie 数据"""
    id: str
    cookies: str
    ori_cookies: str = ""
    
    def validate(self) -> bool:
        """验证 Cookie 是否有效"""
        return bool(self.id and self.cookies)
    
    @classmethod
    def from_dict(cls, data: dict) -> "CookieData":
        """从字典创建"""
        return cls(
            id=data.get("id", ""),
            cookies=data.get("cookies", ""),
            ori_cookies=data.get("ori_cookies", "")
        )


class CookiePool:
    """
    Cookie 池管理器
    
    支持：
    - 从环境变量加载 Cookie
    - 从后端 API 获取 Cookie
    - Cookie 轮换
    - Cookie 失效标记
    """
    
    def __init__(self, backend_url: Optional[str] = None, source: str = "xiaohongshu"):
        """
        初始化 Cookie 池
        
        Args:
            backend_url: 后端服务 URL，默认从环境变量读取
            source: 业务来源标识
        """
        self.backend_url = backend_url or os.getenv("BACK_END_API_BASE_URL", "https://ms.jr.jd.com")
        self.source = source
        self.cookie_pool: List[CookieData] = []
        self.current_index = 0
        self._lock = __import__('threading').Lock()
        
        # 从环境变量加载 Cookie
        self._load_cookies_from_env()
    
    def _load_cookies_from_env(self) -> None:
        """从环境变量加载 Cookie"""
        cookie_str = os.getenv("COOKIES", "")
        if cookie_str:
            # 支持多个 Cookie，用分号分隔
            cookies = [c.strip() for c in cookie_str.split(";") if c.strip()]
            for i, cookie in enumerate(cookies):
                self.cookie_pool.append(CookieData(id=f"env_{i}", cookies=cookie))
            logger.info(f"从环境变量加载了 {len(cookies)} 个 Cookie")
    
    def get_cookie(self) -> Optional[str]:
        """
        获取下一个可用 Cookie
        
        Returns:
            Cookie 字符串，如果没有返回 None
        """
        with self._lock:
            # 优先使用环境变量中的 Cookie
            if self.cookie_pool:
                if self.current_index >= len(self.cookie_pool):
                    self.current_index = 0
                cookie = self.cookie_pool[self.current_index].cookies
                self.current_index = (self.current_index + 1) % len(self.cookie_pool)
                return cookie
            
            # 从后端获取
            return self._fetch_cookie_from_backend()
    
    def _fetch_cookie_from_backend(self) -> Optional[str]:
        """从后端 API 获取 Cookie"""
        try:
            cookie_data, _ = self.fetch_cookie_dto_from_backend()
            if cookie_data:
                # 加入池中
                self.cookie_pool.append(cookie_data)
                return cookie_data.cookies
        except Exception as e:
            logger.error(f"从后端获取 Cookie 失败：{e}")
        return None
    
    @retry(
        stop_max_attempt_number=1,
        wait_exponential_multiplier=1000,
        wait_exponential_max=10000,
    )
    def fetch_cookie_dto_from_backend(self) -> Tuple[Optional[CookieData], Optional[str]]:
        """
        从后端 API 获取 Cookie DTO
        
        Returns:
            (CookieData, cookie_id) 元组
        """
        try:
            url = f"{self.backend_url}/gw2/generic/jylyscrawl/h5/m/getAvailableCookie"
            req_params = {"type": 4, "sources": [self.source]}
            
            logger.info(f"请求 Cookie: {url}")
            response = requests.post(url, json={"reqData": req_params}, timeout=10)
            response.raise_for_status()
            
            result = response.json()
            result_code = result.get("resultCode")
            if result_code != 0:
                logger.error(f"获取 Cookie 失败：{result}")
                return None, None
            
            data = result.get("resultData", {}).get("data", {})
            cookie_data = CookieData.from_dict(data)
            
            if cookie_data.validate():
                logger.info(f"获取到 Cookie: {cookie_data.id}")
                return cookie_data, cookie_data.id
            
            return None, None
            
        except requests.RequestException as e:
            logger.error(f"请求后端失败：{e}")
            raise
        except (KeyError, ValueError, TypeError) as e:
            logger.error(f"解析响应失败：{e}")
            raise
    
    def disable_cookie(self, cookie_id: str) -> bool:
        """
        失效 Cookie
        
        Args:
            cookie_id: Cookie ID
            
        Returns:
            是否成功
        """
        try:
            url = f"{self.backend_url}/gw2/generic/jylyscrawl/h5/m/disableAccount"
            logger.info(f"失效 Cookie: {cookie_id}")
            
            response = requests.post(url, json={"reqData": str(cookie_id)}, timeout=10)
            response.raise_for_status()
            
            result = response.json()
            result_code = result.get("resultCode")
            if result_code != 0:
                logger.error(f"失效 Cookie 失败：{result}")
                return False
            
            # 从池中移除
            self.cookie_pool = [c for c in self.cookie_pool if c.id != cookie_id]
            logger.info(f"Cookie {cookie_id} 已失效并从池中移除")
            return True
            
        except Exception as e:
            logger.error(f"失效 Cookie 失败：{e}")
            return False
    
    def pool_size(self) -> int:
        """返回池中 Cookie 数量"""
        return len(self.cookie_pool)
