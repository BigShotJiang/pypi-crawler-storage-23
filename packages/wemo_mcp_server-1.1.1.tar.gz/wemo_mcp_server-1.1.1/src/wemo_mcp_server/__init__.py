"""WeMo MCP Server - Network scanning and device discovery for WeMo devices."""

__version__ = "1.1.1"

from .server import main

__all__ = ["main"]