"""Google Gemini model implementations."""
