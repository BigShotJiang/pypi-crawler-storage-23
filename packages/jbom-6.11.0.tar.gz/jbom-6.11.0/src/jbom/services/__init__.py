"""jBOM Services - Pure business logic components."""
