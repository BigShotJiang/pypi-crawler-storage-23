Ipctools
########

Ipctools is a library to facilitate inter-process communication.


Installation
************

.. code-block:: shell

   pip install ipctools

Usage
*****

The ``store`` API is used to get or set values in a key-value store. This store
is implemented as a temporary file on the system. The default file location may
be overridden with the ``IPCTOOLS_STORE`` environment variable.

Set, and get a value from the store.

.. code-block:: shell

    from ipctools import store

    store.set_value("my_key", "my_value")
    value = store.get_value("my_key")
    assert value == "my_value"

Setting a value updates it if exists.

.. code-block:: shell

    store.set_value("my_key", "my_value_1")
    store.set_value("my_key", "my_value_2")
    value = store.get_value("my_key")
    assert value == "my_value_2"

However, creating a value will fail if it already exits. You can perform leader
election across multiple processes by having each one try to set a value. Only
one process will succeed, so that one can be the leader.

.. code-block:: shell

    import os

    from ipctools import store

    is_leader = store.create_value("leader", str(os.getpid()))

Since the value of ``leader`` was set to the process ID of a single process,
any process can also determine who the leader is.

.. code-block:: shell

    def am_i_the_leader() -> bool:
        return store.get_value("leader") == str(os.getpid())

If mutliple processes try to set a value at the same time, some of them may
fail. You can try to set a value with retries.

.. code-block:: shell

    store.try_set_value("my_key", "my_value", retries=2)
