"""The main package."""

from importlib import metadata

__project__ = "Ipctools"
__distribution__ = "ipctools"
__version__ = metadata.version("ipctools")
__authors__ = ["Narvin Singh"]
