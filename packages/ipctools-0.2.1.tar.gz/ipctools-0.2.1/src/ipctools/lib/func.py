"""Function tools."""

from __future__ import annotations

import functools
import logging
from typing import TYPE_CHECKING, Literal, TypedDict, TypeGuard

if TYPE_CHECKING:
    from collections.abc import Callable


class _UnknownState[T](TypedDict):
    has_run: bool
    result: T | None


class _RunState[T](TypedDict):
    has_run: Literal[True]
    result: T


def _is_run_state[T](obj: _UnknownState[T] | _RunState[T]) -> TypeGuard[_RunState[T]]:
    return obj["has_run"]


def _to_run_state[T](obj: _UnknownState[T] | _RunState[T]) -> TypeGuard[_RunState[T]]:
    obj["has_run"] = True
    return True


def once[TRet, **P](fn: Callable[P, TRet]) -> Callable[P, TRet]:
    """Ensure a function is run at most once.

    Caches, and returns the result of running the function the first time.

    The function may be forced to run again by passing the keyword argument
    ``_rerun=True``, in which case the new result will be cached and returned
    by subsequent calls to the function.
    """
    state: _UnknownState[TRet] | _RunState[TRet] = _UnknownState(has_run=False, result=None)

    @functools.wraps(fn)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> TRet:
        rerun = kwargs.get("_rerun")

        if not rerun and _is_run_state(state):
            return state["result"]

        if rerun:
            del kwargs["_rerun"]

        logging.getLogger(__name__).debug(
            "calling %s with args: %s, kwargs: %s", fn.__name__, args, kwargs
        )
        state["result"] = fn(*args, **kwargs)
        if _to_run_state(state):
            return state["result"]

        msg = "unreachable"  # pragma: no cover
        raise AssertionError(msg)  # pragma: no cover

    return wrapper
