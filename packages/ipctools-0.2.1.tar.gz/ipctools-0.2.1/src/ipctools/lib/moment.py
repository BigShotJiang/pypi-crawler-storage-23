"""Time tools."""

from __future__ import annotations

import secrets
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable


def delay(
    min_tick: int,
    max_tick: int,
    *,
    tick_size: float,
    _randbelow: Callable[[int], int] = secrets.randbelow,
) -> float:
    """Get a bounded delay.

    The delay is a random number of ticks between ``min_tick`` and
    ``max_tick``, inclusive. A tick is ``tick_size`` seconds.
    """
    return (_randbelow(max_tick - min_tick + 1) + min_tick) * tick_size


def until_next(interval_s: int, _time: Callable[[], float] = time.time) -> float:
    """Get the duration until the start of the next interval.

    Example:

        .. code-block:: python

            seconds_until_next_minute = until_next(60)
            seconds_until_next_minute_or_half_minute = until_next(30)
            seconds_until_next_hour = until_next(60 * 60)
    """
    return interval_s - (_time() % interval_s)
