"""sagellm-compression: Model Compression & Acceleration Module for sageLLM."""

from __future__ import annotations

from sagellm_compression._version import __version__
from sagellm_compression.quantization import (
    Calibrator,
    Exporter,
    FP8Config,
    QuantizationConfig,
    Quantizer,
    W4A16Config,
    W8A8Config,
)
from sagellm_compression.speculative import (
    DraftModel,
    SpeculativeController,
    SpeculativeMetrics,
    SpeculativeResult,
    VerificationResult,
    Verifier,
)

# Public API
__all__ = [
    "__version__",
    # Quantization (Task 3.1)
    "Calibrator",
    "Quantizer",
    "Exporter",
    "QuantizationConfig",
    "W8A8Config",
    "W4A16Config",
    "FP8Config",
    # Speculative decoding (Task 3.3)
    "DraftModel",
    "Verifier",
    "VerificationResult",
    "SpeculativeController",
    "SpeculativeResult",
    "SpeculativeMetrics",
    # Future: Sparsity, KernelFusion
]
