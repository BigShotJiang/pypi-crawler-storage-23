# Handoff: Publish + Local Install Test

**From**: Claude session in `/Users/fausto/Documents/code_2026/applied_ai_collab`
**Date**: 2026-03-03
**Goal**: Republish plugin, then install project-scoped in the DSTV pilot workspace

## What Happened

The DSTV pilot workspace (`applied_ai_collab`) has been using this plugin via local dev path:
```json
"command": "uv",
"args": ["--directory", "/Users/fausto/code_projects_work/gemini-research-mcp", "run", "video-research-mcp"]
```

We want to switch to the published version installed via npx, to dogfood the plugin as a real user would — not as the developer.

## Steps

### Step 1: Check what's changed since last publish
```bash
git log --oneline $(git describe --tags --abbrev=0)..HEAD
```
Review unpublished changes. Decide if version bump is needed.

### Step 2: Bump version + publish
- Bump version in `pyproject.toml` (and `package.json` for the npx installer)
- Build + publish to PyPI: `uv build && uv publish`
- Build + publish npx installer: `cd installer && npm publish`
- Tag: `git tag vX.Y.Z && git push --tags`

### Step 3: Install project-scoped in DSTV pilot
After publishing, go to the DSTV pilot workspace and run:
```bash
cd /Users/fausto/Documents/code_2026/applied_ai_collab
npx video-research-mcp@latest --local
```

This should:
- Write `.mcp.json` with `uvx video-research-mcp` (published, not local dev path)
- Copy commands/skills/agents to `.claude/` (project-scoped)
- Set `LOCAL_FILE_ACCESS_ROOT` for the project

### Step 4: Verify
- Restart Claude Code in the DSTV workspace
- Run `/gr:doctor quick` — should show the published version, not local dev
- Run a quick test: `/gr:research "test query"` or `video_metadata` smoke test

### Step 5: Clean up
- Delete this HANDOFF.md after completing the steps
- The old local `.mcp.json` in the DSTV workspace will be overwritten by the installer

## Context: Why This Matters

The DSTV pilot workspace is the first real-world validation target for this plugin:
- 4 stakeholder call videos analyzed via `video_batch_analyze`
- 5 parallel research agents using `research_deep`, `web_search`, `knowledge_search`
- 4 YouTube videos analyzed via `video_analyze`
- 1,862 objects in Weaviate knowledge store
- 14 slash commands + 5 skills actively used

If the published version works as well as the local dev version, the plugin is production-ready for other users.

## What NOT to Do

- Don't change anything in the DSTV workspace from here — that project has its own CLAUDE.md policy
- Don't break the existing `.mcp.json` in the DSTV workspace until the new version is confirmed working
