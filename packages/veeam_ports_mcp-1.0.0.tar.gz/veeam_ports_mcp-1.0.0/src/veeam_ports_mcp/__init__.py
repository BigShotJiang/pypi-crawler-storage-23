"""MCP server for Veeam product network port requirements."""

__version__ = "1.0.0"
