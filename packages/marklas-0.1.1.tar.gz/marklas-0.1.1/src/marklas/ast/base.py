from dataclasses import dataclass


@dataclass
class Node:
    pass
