from marklas.ast.blocks import Document

__all__ = ["Document"]
