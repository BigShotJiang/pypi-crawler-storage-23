from ._time import interval as interval, sleep as sleep, time as time, timeout as timeout
