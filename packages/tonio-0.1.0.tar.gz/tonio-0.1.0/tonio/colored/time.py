from .._colored._time import interval as interval, sleep as sleep, timeout as timeout
from .._time import time as time
