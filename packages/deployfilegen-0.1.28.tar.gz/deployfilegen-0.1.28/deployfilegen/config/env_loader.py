import os
from pathlib import Path
from dotenv import load_dotenv
from typing import List, Dict, Tuple

from deployfilegen.exceptions import EnvConfigError
from deployfilegen.utils.logger import logger

# Only required for production mode
PROD_REQUIRED_ENV_VARS = [
    "DOCKER_USERNAME",
    "BACKEND_IMAGE_NAME",
    "FRONTEND_IMAGE_NAME",
    "DEPLOY_HOST",
    "DEPLOY_USER",
]

def load_environment(project_root: Path) -> List[Path]:
    """
    Loads .env files in layered order:
    1. project-root/.env
    2. backend/.env
    3. frontend/.env
    
    Later files override earlier ones.
    Returns a list of .env file paths that were found and loaded.
    """
    env_files = [
        project_root / ".env",
        project_root / "backend" / ".env",
        project_root / "frontend" / ".env",
    ]
    
    loaded_files = []
    for env_file in env_files:
        if env_file.exists():
            load_dotenv(env_file, override=True)
            logger.info(f"Loaded environment from: {env_file}")
            loaded_files.append(env_file)
            
    if not loaded_files:
        raise EnvConfigError("No .env files found in likely locations.")
    
    return loaded_files

def validate_environment(mode: str = "prod") -> Dict[str, str]:
    """
    Validates that required environment variables are set.
    In dev mode, no deployment variables are required.
    In prod mode, all deployment variables are required.
    Returns a dictionary of the variables found.
    """
    config = {}
    
    if mode == "dev":
        # Dev mode: no strict requirements. Just collect whatever is available.
        for var in PROD_REQUIRED_ENV_VARS:
            value = os.getenv(var)
            if value:
                config[var] = value
        
        # Provide sensible defaults for image names if not set (needed by compose generator signature)
        config.setdefault("BACKEND_IMAGE_NAME", "backend")
        config.setdefault("FRONTEND_IMAGE_NAME", "frontend")
        return config
    
    # Prod mode: strict validation
    missing = []
    for var in PROD_REQUIRED_ENV_VARS:
        value = os.getenv(var)
        if not value:
            missing.append(var)
        else:
            config[var] = value
            
    if missing:
        raise EnvConfigError(f"Missing required environment variables: {', '.join(missing)}")
        
    return config
