"""docs2static — Fetch collaborative documents and generate static sites."""
__version__ = "0.1.0"
