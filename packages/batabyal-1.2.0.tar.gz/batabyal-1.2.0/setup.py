from setuptools import setup, find_packages

setup(
    name="batabyal",
    version="1.2.0",
    packages=find_packages(),
    install_requires=[
        "pandas>=1.5.0",
        "scikit-learn>=1.2.0",
        "xgboost >= 1.7.0",
        "catboost >= 1.2.0",
        "wittgenstein >= 0.3.4",
        "skl2onnx>=1.15",
        "onnx>=1.14",
        "onnxmltools>=1.11",
        "onnxruntime>=1.16",
        "imodels>=1.3", 
        "numpy>=1.21"
    ],
    python_requires='>=3.10',
    author="T Batabyal",
    description="A lightweight Python package for Machine Learning utilities",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    license_files=["LICENSE"]
)