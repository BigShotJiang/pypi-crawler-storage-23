import stardag as sd

# Makes sure all tasks in `stardag.utils.testing` have dedicated namespace
sd.auto_namespace(__name__)
