"""
Browser-based authentication and credential caching for the Sidekick CLI.

Handles:
- Resolving backend URL from frontend via GET /api/config
- Credential cache in ~/.sidekick/credentials.json (keyed by frontend URL)
- Browser-based CLI auth (opens /cli/authorize)
- Browser-based runner registration (opens /cli/register)
"""

import asyncio
import json
import logging
import os
import pathlib
import sys
import secrets
import tempfile
import webbrowser
from datetime import datetime, timezone
from html import escape as html_escape
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread
from typing import Any
from urllib.parse import parse_qs, urlparse

import httpx

logger = logging.getLogger("agent_runtime.auth")

CREDENTIALS_PATH = pathlib.Path.home() / ".sidekick" / "credentials.json"
AUTH_TIMEOUT_SECONDS = 120


# ---------------------------------------------------------------------------
# Backend URL resolution
# ---------------------------------------------------------------------------

def resolve_backend_url(frontend_url: str) -> str:
    """Resolve the backend API URL by querying the frontend's /api/config endpoint.

    Falls back to the frontend URL itself on any failure (works for
    single-origin deployments where frontend and backend share a URL).
    """
    config_url = f"{frontend_url.rstrip('/')}/api/config"
    try:
        resp = httpx.get(config_url, timeout=10.0, follow_redirects=True)
        resp.raise_for_status()
        data = resp.json()
        backend_url = data.get("backendUrl")
        if backend_url:
            logger.info("Resolved backend URL: %s", backend_url)
            return backend_url.rstrip("/")
    except Exception as exc:
        logger.warning("Could not resolve backend URL from %s: %s", config_url, exc)

    logger.info("Falling back to frontend URL as backend: %s", frontend_url)
    return frontend_url.rstrip("/")


# ---------------------------------------------------------------------------
# Credential cache — ~/.sidekick/credentials.json
# ---------------------------------------------------------------------------

def _read_credentials() -> dict[str, Any]:
    """Read and return the credential cache, migrating old format if needed."""
    if not CREDENTIALS_PATH.exists():
        return {}
    try:
        data = json.loads(CREDENTIALS_PATH.read_text())
    except (json.JSONDecodeError, OSError):
        return {}
    return _migrate_credentials(data)


def _write_credentials(creds: dict[str, Any]) -> None:
    """Persist the credential cache to disk atomically.

    Writes to a temp file in the same directory, sets permissions,
    then renames — so readers never see a half-written file.
    """
    CREDENTIALS_PATH.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_path = tempfile.mkstemp(
        dir=CREDENTIALS_PATH.parent,
        prefix=".credentials_",
        suffix=".tmp",
    )
    try:
        os.write(fd, json.dumps(creds, indent=2, default=str).encode())
        if sys.platform != "win32":
            os.fchmod(fd, 0o600)
        os.close(fd)
        fd = -1  # mark as closed
        os.replace(tmp_path, CREDENTIALS_PATH)
    except BaseException:
        if fd >= 0:
            os.close(fd)
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise


def _migrate_credentials(creds: dict[str, Any]) -> dict[str, Any]:
    """Migrate old flat-format entries to the nested structure.

    Old format (per-URL):
        {"token": "...", "user_id": "...", "display_name": "...", "expires_at": "..."}

    New format (per-URL):
        {"api_url": "...", "cli": {"token": "...", ...}, "runner": {"token": "...", ...}}
    """
    changed = False
    for key, value in list(creds.items()):
        if key.startswith("_"):
            continue
        if not isinstance(value, dict):
            continue
        # Already migrated if it has cli/runner sub-keys
        if "cli" in value or "runner" in value:
            continue
        # Old format has a flat "token" key
        if "token" in value:
            old_api_url = value.get("api_url")
            creds[key] = {
                **({"api_url": old_api_url} if old_api_url else {}),
                "cli": {
                    "token": value.get("token"),
                    "user_id": value.get("user_id"),
                    "display_name": value.get("display_name"),
                    "expires_at": value.get("expires_at"),
                },
            }
            changed = True
    if changed:
        _write_credentials(creds)
    return creds


# --- Default URL ---

def get_default_url() -> str | None:
    """Return the cached default frontend URL, or None."""
    creds = _read_credentials()
    return creds.get("_default_url")


def set_default_url(url: str) -> None:
    """Persist the default frontend URL."""
    creds = _read_credentials()
    creds["_default_url"] = url
    _write_credentials(creds)


# --- CLI credentials ---

def get_cached_cli_credentials(url: str) -> dict[str, Any] | None:
    """Return cached CLI credentials for *url*, or None if missing/expired."""
    creds = _read_credentials()
    entry = creds.get(url, {})
    cli = entry.get("cli")
    if not cli or not cli.get("token"):
        return None
    # Check expiry
    expires_at = cli.get("expires_at")
    if expires_at:
        try:
            exp = datetime.fromisoformat(expires_at)
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp < datetime.now(timezone.utc):
                logger.info("Cached CLI token has expired")
                return None
        except (ValueError, TypeError):
            pass
    return {**cli, "api_url": entry.get("api_url")}


def cache_cli_token(
    url: str,
    token: str,
    user_id: str,
    display_name: str,
    expires_at: str,
    api_url: str | None = None,
) -> None:
    """Cache a CLI auth token for *url*."""
    creds = _read_credentials()
    entry = creds.setdefault(url, {})
    if api_url:
        entry["api_url"] = api_url
    entry["cli"] = {
        "token": token,
        "user_id": user_id,
        "display_name": display_name,
        "expires_at": expires_at,
    }
    _write_credentials(creds)
    logger.info("Cached CLI token for %s", url)


# --- Runner credentials ---

def get_cached_runner_credentials(url: str) -> dict[str, Any] | None:
    """Return cached runner credentials for *url*, or None if missing."""
    creds = _read_credentials()
    entry = creds.get(url, {})
    runner = entry.get("runner")
    if not runner or not runner.get("token"):
        return None
    return {**runner, "api_url": entry.get("api_url")}


def cache_runner_token(
    url: str,
    token: str,
    runner_id: str,
    runner_name: str,
    api_url: str | None = None,
) -> None:
    """Cache a runner token for *url*."""
    creds = _read_credentials()
    entry = creds.setdefault(url, {})
    if api_url:
        entry["api_url"] = api_url
    entry["runner"] = {
        "token": token,
        "runner_id": runner_id,
        "runner_name": runner_name,
    }
    _write_credentials(creds)
    logger.info("Cached runner token for %s", url)


# ---------------------------------------------------------------------------
# Browser-based CLI authentication
# ---------------------------------------------------------------------------

async def browser_auth(url: str) -> dict:
    """Run the browser-based auth flow and return credentials.

    Args:
        url: Sidekick frontend URL (e.g. https://sidekick.example.com).

    Returns:
        Dict with 'token' (CLI token) and 'api_url' (backend URL).

    Raises:
        RuntimeError: If auth flow times out or fails.
    """
    # Check for cached credentials first
    cached = get_cached_cli_credentials(url)
    if cached:
        logger.info("Using cached CLI credentials")
        return {"token": cached["token"], "api_url": cached.get("api_url", "")}

    # Generate CSRF state parameter
    state = secrets.token_urlsafe(32)
    result: dict = {}
    error: str | None = None

    class CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            nonlocal result, error
            parsed = urlparse(self.path)

            if parsed.path == "/callback":
                params = parse_qs(parsed.query)
                received_state = params.get("state", [None])[0]
                token = params.get("token", [None])[0]
                user_id = params.get("user_id", [None])[0]
                display_name = params.get("display_name", [None])[0]
                expires_at = params.get("expires_at", [None])[0]
                api_url_param = params.get("api_url", [None])[0]
                err = params.get("error", [None])[0]

                if err:
                    error = err
                    self._send_response(
                        400,
                        "<html><body><h2>Authorization Failed</h2>"
                        f"<p>{html_escape(err)}</p>"
                        "<p>You can close this tab.</p></body></html>",
                    )
                elif received_state != state:
                    error = "State mismatch — possible CSRF attack"
                    self._send_response(
                        400,
                        "<html><body><h2>Authorization Failed</h2>"
                        "<p>State parameter mismatch. Please try again.</p>"
                        "<p>You can close this tab.</p></body></html>",
                    )
                elif not token:
                    error = "No token received"
                    self._send_response(
                        400,
                        "<html><body><h2>Authorization Failed</h2>"
                        "<p>No token received. Please try again.</p>"
                        "<p>You can close this tab.</p></body></html>",
                    )
                else:
                    result = {
                        "token": token,
                        "user_id": user_id or "",
                        "display_name": display_name or "",
                        "expires_at": expires_at or "",
                        "api_url": api_url_param or "",
                    }
                    self._send_response(
                        200,
                        "<html><body><h2>Authorized!</h2>"
                        "<p>You can close this tab and return to the terminal.</p>"
                        "</body></html>",
                    )
            else:
                self._send_response(404, "Not found")

        def _send_response(self, code: int, body: str):
            self.send_response(code)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(body.encode())

        def log_message(self, format, *args):
            pass  # Suppress default HTTP server logging

    # Start ephemeral HTTP server on random port
    server = HTTPServer(("127.0.0.1", 0), CallbackHandler)
    port = server.server_address[1]
    logger.info("Listening for auth callback on port %d", port)

    # Run server in background thread
    server_thread = Thread(target=server.serve_forever, daemon=True)
    server_thread.start()

    try:
        # Open browser to authorization page
        auth_url = f"{url.rstrip('/')}/cli/authorize?port={port}&state={state}"
        print("\nOpening browser for authentication...")
        print(f"If the browser doesn't open, visit:\n  {auth_url}\n")
        webbrowser.open(auth_url)

        # Wait for callback with timeout
        deadline = asyncio.get_event_loop().time() + AUTH_TIMEOUT_SECONDS
        while not result and not error:
            remaining = deadline - asyncio.get_event_loop().time()
            if remaining <= 0:
                raise RuntimeError(
                    f"Authentication timed out after {AUTH_TIMEOUT_SECONDS}s. "
                    "Please try again."
                )
            await asyncio.sleep(0.5)

        if error:
            raise RuntimeError(f"Authentication failed: {error}")

        # SEC-04: Verify the token actually works before caching
        api_url_for_verify = result.get("api_url") or resolve_backend_url(url)
        try:
            verify_resp = httpx.get(
                f"{api_url_for_verify.rstrip('/')}/api/runtime/v1/agents",
                headers={"Authorization": f"Bearer {result['token']}"},
                timeout=10.0,
            )
            if verify_resp.status_code in (401, 403):
                raise RuntimeError(
                    "Token verification failed — the server rejected the token. "
                    "Please try authenticating again."
                )
        except httpx.HTTPError as exc:
            # Non-fatal: the endpoint may not exist on older backends
            logger.warning("Token verification request failed (non-fatal): %s", exc)

        # Cache the token
        cache_cli_token(
            url,
            result["token"],
            result["user_id"],
            result["display_name"],
            result["expires_at"],
            api_url=result.get("api_url", ""),
        )

        print(f"Authenticated as {result.get('display_name', 'user')}\n")
        return {"token": result["token"], "api_url": result.get("api_url", "")}

    finally:
        server.shutdown()


# ---------------------------------------------------------------------------
# Browser-based runner registration
# ---------------------------------------------------------------------------

def browser_register(url: str) -> dict[str, str]:
    """Open a browser to register/select a runner and receive a token via callback.

    Opens ``{url}/cli/register?port={port}&state={state}`` and waits for the
    frontend to redirect to ``http://127.0.0.1:{port}/callback`` with the
    runner token and metadata.

    Returns a dict with keys: token, runner_id, runner_name, api_url.
    """
    state = secrets.token_urlsafe(32)
    result: dict[str, str] = {}
    error: list[str] = []

    class _Handler(BaseHTTPRequestHandler):
        def do_GET(self):  # noqa: N802
            parsed = urlparse(self.path)
            if parsed.path != "/callback":
                self.send_response(404)
                self.end_headers()
                return

            params = parse_qs(parsed.query)

            # CSRF check
            received_state = params.get("state", [""])[0]
            if received_state != state:
                error.append("State mismatch — possible CSRF attack")
                self.send_response(403)
                self.end_headers()
                self.wfile.write(b"State mismatch. Please try again.")
                return

            result["token"] = params.get("token", [""])[0]
            result["runner_id"] = params.get("runner_id", [""])[0]
            result["runner_name"] = params.get("runner_name", [""])[0]
            result["api_url"] = params.get("api_url", [""])[0]

            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(
                b"<html><body><h2>Runner registered!</h2>"
                b"<p>You can close this tab and return to the terminal.</p>"
                b"</body></html>"
            )

        def log_message(self, *args):
            pass  # Suppress default stderr logging

    server = HTTPServer(("127.0.0.1", 0), _Handler)
    server.timeout = AUTH_TIMEOUT_SECONDS  # SEC-05: bound the wait
    port = server.server_address[1]

    register_url = f"{url.rstrip('/')}/cli/register?port={port}&state={state}"
    logger.info("Opening browser for runner registration: %s", register_url)
    print("\nOpening browser for runner registration...")
    print(f"If the browser doesn't open, visit:\n  {register_url}\n")
    webbrowser.open(register_url)

    # Wait for exactly one callback request (with timeout)
    server.handle_request()
    server.server_close()

    # If handle_request timed out, result will still be empty
    if not result and not error:
        raise RuntimeError(
            f"Runner registration timed out after {AUTH_TIMEOUT_SECONDS}s. "
            "Please try again."
        )

    if error:
        raise RuntimeError(error[0])

    if not result.get("token"):
        raise RuntimeError("No runner token received from browser registration")

    # Cache the credentials
    api_url = result.get("api_url") or resolve_backend_url(url)
    cache_runner_token(
        url=url,
        token=result["token"],
        runner_id=result["runner_id"],
        runner_name=result["runner_name"],
        api_url=api_url,
    )
    result["api_url"] = api_url

    logger.info("Runner '%s' registered successfully", result.get("runner_name"))
    return result
