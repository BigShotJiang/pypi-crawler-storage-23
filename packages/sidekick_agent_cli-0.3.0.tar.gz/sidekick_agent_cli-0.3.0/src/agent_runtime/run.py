"""
Non-interactive agent invocation for Sidekick.

Usage: sidekick agent run --agent "My Agent" --prompt "Do something"

Sends a single prompt to an agent, runs to completion, and exits.
Designed for scripts, cron jobs, and automation pipelines.
"""

from __future__ import annotations

import json
import logging
import os
import pathlib
import sys
from typing import Dict

from .api_client import RuntimeAPIClient
from .auth import browser_auth
from .runner import _setup_workspace
from .runtime import AgentRuntime

logger = logging.getLogger("agent_runtime.run")


async def resolve_agent(
    api: RuntimeAPIClient,
    agent_name: str | None = None,
) -> Dict[str, str]:
    """Resolve an agent with cascading fallback.

    1. ``--agent`` flag → case-insensitive name match
    2. ``SIDEKICK_AGENT_ID`` env var → direct lookup
    3. User's default agent

    Returns:
        Dict with ``id`` and ``name`` keys.

    Raises:
        SystemExit: If no agent can be resolved.
    """
    # 1. Explicit agent name
    if agent_name:
        try:
            agents = await api.list_agents()
        except Exception as e:
            print(f"Error: Failed to list agents: {e}", file=sys.stderr)
            sys.exit(1)

        match = next(
            (a for a in agents if a.get("name", "").lower() == agent_name.lower()),
            None,
        )
        if not match:
            available = ", ".join(a.get("name", "?") for a in agents)
            print(
                f"Error: Agent '{agent_name}' not found. Available: {available}",
                file=sys.stderr,
            )
            sys.exit(1)
        return {"id": match["id"], "name": match.get("name", agent_name)}

    # 2. SIDEKICK_AGENT_ID env var (tool-call context)
    env_agent_id = os.environ.get("SIDEKICK_AGENT_ID")
    if env_agent_id:
        agent = await api.get_agent(env_agent_id)
        if agent:
            return {"id": agent["id"], "name": agent.get("name", "Agent")}
        print(
            f"Error: Agent from SIDEKICK_AGENT_ID '{env_agent_id}' not found.",
            file=sys.stderr,
        )
        sys.exit(1)

    # 3. Default agent
    agent = await api.get_default_agent()
    if agent:
        return {"id": agent["id"], "name": agent.get("name", "Agent")}

    print(
        "Error: No agent specified and no default agent found. "
        "Use --agent <name> or set a default agent.",
        file=sys.stderr,
    )
    sys.exit(1)


async def run_prompt(
    url: str,
    prompt: str,
    agent_name: str | None = None,
    conversation_id: str | None = None,
    token: str | None = None,
    workspace: str | None = None,
    title: str | None = None,
    json_output: bool = False,
    no_stream: bool = False,
    allow_insecure: bool = False,
    runner_id: str | None = None,
) -> None:
    """Run a single prompt against a Sidekick agent and exit.

    Args:
        url: Sidekick backend URL.
        prompt: Prompt text to send.
        agent_name: Agent name (case-insensitive match). Optional — falls back
            to SIDEKICK_AGENT_ID env var or user's default agent.
        conversation_id: Continue an existing conversation (skip creation).
        token: CLI token for headless auth (skips browser flow).
        workspace: Override working directory.
        title: Conversation title (default: "CLI Run: <agent>").
        json_output: Output structured JSON to stdout.
        no_stream: Wait for completion, print final text instead of streaming.
        allow_insecure: Allow unencrypted HTTP to non-localhost backends.
        runner_id: Self-hosted runner ID to route the conversation to.
    """
    from urllib.parse import urlparse

    # SEC-06: Block unencrypted HTTP to non-localhost unless explicitly allowed
    parsed = urlparse(url)
    if parsed.scheme == "http" and parsed.hostname not in (
        "localhost",
        "127.0.0.1",
        "::1",
    ):
        if not allow_insecure:
            print(
                f"Error: Refusing to connect over unencrypted HTTP to {parsed.hostname}. "
                "Your token would be transmitted in plaintext. "
                "Use HTTPS or pass --allow-insecure to override.",
                file=sys.stderr,
            )
            sys.exit(1)
        logger.warning(
            "WARNING: Connecting over unencrypted HTTP to %s (--allow-insecure). "
            "Token will be transmitted in plaintext.",
            parsed.hostname,
        )

    # 1. Authenticate
    api_url = url
    if not token:
        try:
            credentials = await browser_auth(url)
            token = credentials["token"]
            if credentials.get("api_url"):
                api_url = credentials["api_url"]
        except Exception as e:
            print(f"Error: Authentication failed: {e}", file=sys.stderr)
            sys.exit(1)

    # 2. Set up API client and runtime
    api = RuntimeAPIClient(base_url=api_url, token=token)
    runtime = AgentRuntime(api=api)

    try:
        # 3. Resolve agent (by name, env var, or default)
        resolved = await resolve_agent(api, agent_name)
        agent_id = resolved["id"]
        selected_agent_name = resolved["name"]

        # 4. Set up workspace
        if workspace:
            ws_path = pathlib.Path(workspace).expanduser().resolve()
            ws_path.mkdir(parents=True, exist_ok=True)
            os.chdir(ws_path)
        else:
            ws_path = pathlib.Path(_setup_workspace(selected_agent_name))
        runtime._workspace = str(ws_path)

        # 5. Create or reuse conversation
        if conversation_id:
            ref_name = "main"
        else:
            conv_title = title or f"CLI Run: {selected_agent_name}"
            conv = await api.create_conversation(
                agent_id, title=conv_title, runner_id=runner_id,
            )
            conversation_id = conv["conversation_id"]
            ref_name = conv.get("ref_name", "main")

        # 6. Send prompt
        msg = await api.send_message(conversation_id, prompt, ref_name)
        node_id = msg["node_id"]
        ref_name = msg.get("ref_name", ref_name)

        # 7. Run agent turn with output handling
        response_parts: list[str] = []
        tools_used: list[str] = []

        def on_delta(token_text: str) -> None:
            if json_output or no_stream:
                response_parts.append(token_text)
            else:
                sys.stdout.write(token_text)
                sys.stdout.flush()

        def on_tool_start(tool_name: str) -> None:
            tools_used.append(tool_name)
            print(f"[tool] {tool_name}: started", file=sys.stderr)

        def on_tool_complete(tool_name: str, success: bool) -> None:
            status = "done" if success else "FAILED"
            print(f"[tool] {tool_name}: {status}", file=sys.stderr)

        await runtime.run_turn(
            conversation_id,
            node_id,
            ref_name,
            on_delta=on_delta,
            on_tool_start=on_tool_start,
            on_tool_complete=on_tool_complete,
        )

        # 8. Output final result
        collected = "".join(response_parts)

        if json_output:
            output = {
                "conversation_id": conversation_id,
                "response": collected,
                "tools_used": tools_used,
            }
            print(json.dumps(output, indent=2))
        elif no_stream:
            print(collected)
        else:
            # Streaming already printed tokens; ensure trailing newline
            if not collected and not json_output:
                pass  # tokens already flushed to stdout
            sys.stdout.write("\n")
            sys.stdout.flush()

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        await api.close()
