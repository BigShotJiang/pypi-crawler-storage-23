"""
Rich TUI display for the Agent Runtime.

Prints a styled ASCII art banner and status at startup, then uses RichHandler
for formatted log output below. Status changes print as compact inline updates.
Falls back to plain logging when disabled (--no-tui or non-TTY).
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field


BANNER_ART = r"""
  _____ _     _      _    _      _
 / ____(_)   | |    | |  (_)    | |
| (___  _  __| | ___| | ___  ___| | __
 \___ \| |/ _` |/ _ \ |/ / |/ __| |/ /
 ____) | | (_| |  __/   <| | (__|   <
|_____/|_|\__,_|\___|_|\_\_|\___|_|\_\
"""


@dataclass
class DisplayState:
    """Mutable state tracked by the display."""

    connection_status: str = "connecting"  # connecting, online, disconnected
    runner_name: str = ""
    runner_id: str = ""
    server_url: str = ""
    workspace: str = ""
    start_time: float = field(default_factory=time.monotonic)
    turns_completed: int = 0
    tool_executions: int = 0
    active_turns: int = 0
    current_conversation_id: str = ""
    current_step: str = ""
    current_agent_name: str = ""


class RuntimeDisplay:
    """Rich TUI display with null-object pattern when disabled."""

    def __init__(self, enabled: bool = True):
        self._enabled = enabled
        self._state = DisplayState()
        self._console = None

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def state(self) -> DisplayState:
        return self._state

    def setup_logging(self, log_level: str = "INFO") -> None:
        """Configure logging — RichHandler when TUI is on, basic otherwise."""
        level = getattr(logging, log_level.upper(), logging.INFO)

        if not self._enabled:
            logging.basicConfig(
                level=level,
                format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            )
            return

        from rich.console import Console
        from rich.logging import RichHandler

        self._console = Console(stderr=True)
        handler = RichHandler(
            console=self._console,
            show_path=False,
            rich_tracebacks=True,
            tracebacks_show_locals=False,
            markup=True,
        )
        logging.basicConfig(
            level=level,
            format="%(message)s",
            datefmt="[%X]",
            handlers=[handler],
        )

    async def __aenter__(self):
        if self._enabled and self._console:
            self._print_banner()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._enabled and self._console:
            self._print_status_line("Stopped", style="dim")
        return False

    # -- Event methods --

    def on_connecting(self, url: str, display_name: str) -> None:
        self._state.connection_status = "connecting"
        self._state.server_url = url
        self._state.runner_name = display_name

    def on_connected(self, runner_name: str, runner_id: str) -> None:
        self._state.connection_status = "online"
        self._state.runner_name = runner_name
        self._state.runner_id = runner_id
        self._print_status_line("Connected", style="bold green")

    def on_disconnected(self, reason: str, reconnect_delay: float) -> None:
        self._state.connection_status = "disconnected"
        self._print_status_line(
            f"Disconnected — reconnecting in {reconnect_delay:.0f}s",
            style="bold red",
        )

    def on_workspace_set(self, path: str) -> None:
        self._state.workspace = path

    def on_turn_started(
        self,
        conversation_id: str,
        agent_name: str,
    ) -> None:
        self._state.active_turns += 1
        self._state.current_conversation_id = conversation_id
        self._state.current_agent_name = agent_name
        self._state.current_step = "starting"

    def on_llm_call(self, iteration: int, turn_id: str) -> None:
        self._state.current_step = f"LLM call #{iteration}"

    def on_tools_registered(self, tool_names: list[str]) -> None:
        self._state.current_step = f"tools: {', '.join(tool_names)}"

    def on_tool_executed(self, tool_name: str, success: bool, execution: str) -> None:
        self._state.tool_executions += 1

    def on_turn_completed(self, turn_id: str, iterations: int) -> None:
        self._state.turns_completed += 1
        self._state.active_turns = max(0, self._state.active_turns - 1)
        if self._state.active_turns == 0:
            self._state.current_conversation_id = ""
            self._state.current_step = ""
            self._state.current_agent_name = ""

    def on_turn_failed(self, error: str) -> None:
        self._state.active_turns = max(0, self._state.active_turns - 1)
        if self._state.active_turns == 0:
            self._state.current_step = ""

    def on_turn_cancelled(self, turn_id: str) -> None:
        self._state.active_turns = max(0, self._state.active_turns - 1)
        if self._state.active_turns == 0:
            self._state.current_step = ""

    def on_shutdown(self) -> None:
        self._state.connection_status = "offline"

    # -- Internal --

    def _format_uptime(self) -> str:
        elapsed = int(time.monotonic() - self._state.start_time)
        hours, remainder = divmod(elapsed, 3600)
        minutes, seconds = divmod(remainder, 60)
        if hours > 0:
            return f"{hours}h {minutes:02d}m"
        if minutes > 0:
            return f"{minutes}m {seconds:02d}s"
        return f"{seconds}s"

    def _print_banner(self) -> None:
        """Print the startup banner and status panel once."""
        from rich.console import Group
        from rich.panel import Panel
        from rich.rule import Rule
        from rich.table import Table
        from rich.text import Text

        banner = Text(BANNER_ART.rstrip(), style="bold cyan")
        subtitle = Text("                        Agent Runtime\n", style="bold white")

        # Status grid
        grid = Table.grid(padding=(0, 2))
        grid.add_column(style="dim", min_width=12)
        grid.add_column()

        # Status line
        status = self._state.connection_status
        if status == "online":
            status_text = Text("● Online", style="bold green")
        elif status == "connecting":
            status_text = Text("◌ Connecting", style="bold yellow")
        else:
            status_text = Text("● Offline", style="dim")

        row1 = Text()
        row1.append_text(status_text)
        if self._state.runner_name:
            row1.append(f" │ Runner: {self._state.runner_name}", style="white")
        grid.add_row("", row1)

        if self._state.server_url:
            grid.add_row("  Server:", Text(self._state.server_url, style="blue"))

        if self._state.workspace:
            import pathlib

            workspace = self._state.workspace.replace(
                str(pathlib.Path.home()), "~"
            )
            grid.add_row("  Workspace:", Text(workspace, style="white"))

        panel = Panel(
            Group(banner, subtitle, grid),
            border_style="cyan",
            padding=(0, 1),
        )

        self._console.print(panel)
        self._console.print(Rule(style="cyan"))

    def _build_header(self):
        """Build the banner panel (used by tests)."""
        from rich.console import Group
        from rich.panel import Panel
        from rich.table import Table
        from rich.text import Text

        banner = Text(BANNER_ART.rstrip(), style="bold cyan")
        subtitle = Text("                        Agent Runtime\n", style="bold white")

        grid = Table.grid(padding=(0, 2))
        grid.add_column(style="dim", min_width=12)
        grid.add_column()

        status = self._state.connection_status
        if status == "online":
            status_text = Text("● Online", style="bold green")
        elif status == "connecting":
            status_text = Text("◌ Connecting", style="bold yellow")
        elif status == "disconnected":
            status_text = Text("● Disconnected", style="bold red")
        else:
            status_text = Text("● Offline", style="dim")

        row1 = Text()
        row1.append_text(status_text)
        if self._state.runner_name:
            row1.append(f" │ Runner: {self._state.runner_name}", style="white")
        row1.append(f" │ ↑ {self._format_uptime()}", style="dim")
        grid.add_row("", row1)

        if self._state.server_url:
            grid.add_row("  Server:", Text(self._state.server_url, style="blue"))

        if self._state.workspace:
            import pathlib

            workspace = self._state.workspace.replace(
                str(pathlib.Path.home()), "~"
            )
            grid.add_row("  Workspace:", Text(workspace, style="white"))

        stats = Text()
        stats.append(f"Turns: {self._state.turns_completed}", style="white")
        stats.append(f" │ Tools: {self._state.tool_executions}", style="white")
        stats.append(f" │ Active: {self._state.active_turns}", style="white")
        grid.add_row("  Stats:", stats)

        if self._state.current_conversation_id:
            current = Text()
            conv_short = self._state.current_conversation_id[:8]
            current.append(f"conv-{conv_short}", style="cyan")
            if self._state.current_agent_name:
                current.append(f" ▸ {self._state.current_agent_name}", style="white")
            if self._state.current_step:
                current.append(f" ▸ {self._state.current_step}", style="dim")
            grid.add_row("  Current:", current)

        return Panel(
            Group(banner, subtitle, grid),
            border_style="cyan",
            padding=(0, 1),
        )

    def _print_status_line(self, message: str, style: str = "bold") -> None:
        """Print a compact status update inline with logs."""
        if not self._enabled or not self._console:
            return
        from rich.text import Text

        line = Text()
        line.append(" ● ", style=style)
        line.append(message, style=style)
        if self._state.runner_name:
            line.append(f" │ {self._state.runner_name}", style="dim")
        line.append(f" │ ↑ {self._format_uptime()}", style="dim")
        self._console.print(line)
