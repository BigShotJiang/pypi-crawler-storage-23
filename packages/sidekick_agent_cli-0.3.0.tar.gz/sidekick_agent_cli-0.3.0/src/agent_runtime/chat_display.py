"""
Rich-formatted display for interactive chat mode.

Streams LLM tokens to the terminal as they arrive and shows
tool execution inline with minimal chrome.
"""

from __future__ import annotations

import sys
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.text import Text


class ChatDisplay:
    """Display handler for interactive chat sessions."""

    def __init__(self):
        self._console = Console()
        self._streaming = False

    def print_banner(self, url: str) -> None:
        """Print the chat mode welcome banner."""
        banner = Text()
        banner.append("Sidekick CLI", style="bold cyan")
        banner.append(" — interactive chat mode\n", style="dim")
        banner.append(f"Connected to {url}", style="dim")
        self._console.print(Panel(banner, border_style="cyan", padding=(0, 1)))
        self._console.print()

    def print_agent_selected(self, agent_name: str, conversation_id: str) -> None:
        """Show which agent was selected."""
        self._console.print(
            f"  Agent: [bold]{agent_name}[/bold]  |  "
            f"Conversation: [dim]{conversation_id[:8]}...[/dim]\n"
        )

    def prompt_agent_choice(self, agents: list[dict]) -> Optional[dict]:
        """Show interactive agent picker. Returns selected agent or None."""
        if not agents:
            self._console.print("[red]No agents available.[/red]")
            return None

        self._console.print("[bold]Available agents:[/bold]\n")
        for i, agent in enumerate(agents, 1):
            name = agent.get("name", "Unknown")
            desc = agent.get("description", "")
            self._console.print(f"  [cyan]{i}.[/cyan] [bold]{name}[/bold]")
            if desc:
                # Truncate long descriptions
                short = desc[:80] + "..." if len(desc) > 80 else desc
                self._console.print(f"     [dim]{short}[/dim]")

        self._console.print()

        while True:
            try:
                choice = input("Select agent (number): ").strip()
                if not choice:
                    continue
                idx = int(choice) - 1
                if 0 <= idx < len(agents):
                    return agents[idx]
                self._console.print(f"[red]Please enter 1-{len(agents)}[/red]")
            except ValueError:
                self._console.print("[red]Please enter a number[/red]")
            except (EOFError, KeyboardInterrupt):
                return None

    def get_user_input(self) -> Optional[str]:
        """Prompt for user input. Returns None on EOF/exit."""
        try:
            text = input("\nYou: ").strip()
            if text.lower() in ("exit", "quit", "/quit", "/exit"):
                return None
            return text if text else None
        except (EOFError, KeyboardInterrupt):
            return None

    def begin_assistant_response(self) -> None:
        """Mark the start of an assistant response."""
        self._console.print()
        self._console.print("[bold]Assistant:[/bold]", end=" ")
        self._streaming = True

    def stream_token(self, token: str) -> None:
        """Write a single streamed token to the terminal."""
        sys.stdout.write(token)
        sys.stdout.flush()

    def end_assistant_response(self) -> None:
        """Mark the end of an assistant response."""
        if self._streaming:
            sys.stdout.write("\n")
            sys.stdout.flush()
            self._streaming = False

    def show_tool_start(self, tool_name: str) -> None:
        """Show that a tool is being executed."""
        # End streaming line if we're mid-stream
        if self._streaming:
            sys.stdout.write("\n")
            sys.stdout.flush()
            self._streaming = False
        self._console.print(f"  [dim][Running: {tool_name}][/dim]", end=" ")

    def show_tool_result(self, tool_name: str, success: bool) -> None:
        """Show tool execution result."""
        if success:
            self._console.print("[green]done[/green]")
        else:
            self._console.print("[red]failed[/red]")

    def show_error(self, message: str) -> None:
        """Show an error message."""
        if self._streaming:
            sys.stdout.write("\n")
            sys.stdout.flush()
            self._streaming = False
        self._console.print(f"\n[red]Error: {message}[/red]")

    def show_info(self, message: str) -> None:
        """Show an informational message."""
        self._console.print(f"[dim]{message}[/dim]")

    def show_goodbye(self) -> None:
        """Show exit message."""
        self._console.print("\n[dim]Goodbye![/dim]")
