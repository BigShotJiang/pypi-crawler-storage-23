"""Allow running as: python -m agent_runtime"""
from .cli import main

main()
