"""
CLI entry point for the Sidekick Agent Runtime.

Usage:
    sidekick serve --url https://sidekick.example.com
    sidekick chat --url https://sidekick.example.com
    sidekick agent run --agent "My Agent" --prompt "Do something"
    sidekick agent list
    sidekick agent self
    sidekick agent create --name "New Agent"
    sidekick models list
    sidekick --version

All subcommands accept --url pointing at the Sidekick frontend.
Authentication happens via browser OAuth; the frontend returns the
backend API URL in the callback.  Pass --token to skip browser auth.
"""

import argparse
import asyncio
import logging
import os
import signal
import sys

logger = logging.getLogger("agent_runtime.cli")

try:
    from importlib.metadata import version as _pkg_version

    __version__ = _pkg_version("sidekick-agent-cli")
except Exception:
    __version__ = "0.2.0"


def _add_common_args(parser: argparse.ArgumentParser) -> None:
    """Add common CLI arguments shared across most subcommands."""
    parser.add_argument(
        "--url",
        default=None,
        help="Sidekick frontend URL (env: SIDEKICK_URL). Cached after first use.",
    )
    parser.add_argument(
        "--token",
        default=os.environ.get("SIDEKICK_CLI_TOKEN"),
        help="CLI token for headless auth (env: SIDEKICK_CLI_TOKEN)",
    )
    parser.add_argument(
        "--log-level",
        default=os.environ.get("LOG_LEVEL", "WARNING"),
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
    )
    parser.add_argument(
        "--allow-env-passthrough",
        action="store_true",
        default=os.environ.get("SIDEKICK_ALLOW_ENV_PASSTHROUGH", "").lower()
        in ("1", "true", "yes"),
        help="Pass all server-provided env vars to CLI tools (default: strip sensitive vars)",
    )
    parser.add_argument(
        "--allow-insecure",
        action="store_true",
        default=os.environ.get("SIDEKICK_ALLOW_INSECURE", "").lower()
        in ("1", "true", "yes"),
        help="Allow unencrypted HTTP connections to non-localhost backends",
    )


def _build_parser() -> argparse.ArgumentParser:
    """Build the top-level argument parser with subcommands."""
    parser = argparse.ArgumentParser(
        prog="sidekick",
        description="Sidekick Agent Runtime — run agents locally or interactively",
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )

    subparsers = parser.add_subparsers(dest="command")

    # --- serve subcommand (current runner behavior) ---
    serve = subparsers.add_parser(
        "serve",
        help="Run as a remote agent runtime (WebSocket listener)",
        description="Connect to Sidekick via WebSocket and execute turns assigned by the backend.",
    )
    serve.add_argument(
        "--url",
        default=None,
        help="Sidekick frontend URL (env: SIDEKICK_URL). Cached after first use.",
    )
    serve.add_argument(
        "--token",
        default=os.environ.get("RUNNER_TOKEN", ""),
        help="Runner token (env: RUNNER_TOKEN). If omitted, opens browser to register.",
    )
    serve.add_argument(
        "--name",
        default=os.environ.get("RUNNER_NAME"),
        help="Display name for this runner (defaults to hostname)",
    )
    serve.add_argument(
        "--workspace",
        default=os.environ.get("RUNNER_WORKSPACE"),
        help="Override working directory (default: ~/.sidekick/<name>/workspace)",
    )
    serve.add_argument(
        "--log-level",
        default=os.environ.get("LOG_LEVEL", "INFO"),
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
    )
    serve.add_argument(
        "--no-tui",
        action="store_true",
        default=os.environ.get("SIDEKICK_NO_TUI", "").lower()
        in ("1", "true", "yes"),
        help="Disable Rich TUI, use plain logging",
    )
    serve.add_argument(
        "--allow-env-passthrough",
        action="store_true",
        default=os.environ.get("SIDEKICK_ALLOW_ENV_PASSTHROUGH", "").lower()
        in ("1", "true", "yes"),
        help="Pass all server-provided env vars to CLI tools (default: strip sensitive vars)",
    )
    serve.add_argument(
        "--allow-insecure",
        action="store_true",
        default=os.environ.get("SIDEKICK_ALLOW_INSECURE", "").lower()
        in ("1", "true", "yes"),
        help="Allow unencrypted HTTP connections to non-localhost backends",
    )

    # --- chat subcommand (interactive REPL) ---
    chat = subparsers.add_parser(
        "chat",
        help="Interactive chat with a Sidekick agent",
        description="Authenticate via browser, select an agent, and chat interactively.",
    )
    _add_common_args(chat)
    chat.add_argument(
        "--agent",
        default=None,
        help="Agent name to use (skips interactive picker)",
    )
    chat.add_argument(
        "--conversation",
        default=None,
        help="Resume an existing conversation by ID",
    )
    chat.add_argument(
        "--workspace",
        default=os.environ.get("RUNNER_WORKSPACE"),
        help="Override working directory (default: ~/.sidekick/<agent-name>/workspace)",
    )

    # --- agent command group ---
    agent_parser = subparsers.add_parser(
        "agent",
        help="Manage and run agents",
    )
    agent_sub = agent_parser.add_subparsers(dest="agent_command")

    # agent run
    agent_run = agent_sub.add_parser(
        "run",
        help="Run a single agent prompt (non-interactive)",
        description="Send a prompt to a Sidekick agent, run to completion, and exit.",
    )
    _add_common_args(agent_run)
    agent_run.add_argument(
        "--agent",
        default=None,
        help="Agent name (optional — defaults to SIDEKICK_AGENT_ID env or user's default agent)",
    )
    agent_run.add_argument(
        "--prompt",
        required=True,
        help="Prompt text, or '-' to read from stdin",
    )
    agent_run.add_argument(
        "--title",
        default=None,
        help="Conversation title (default: 'CLI Run: <agent>')",
    )
    agent_run.add_argument(
        "--workspace",
        default=os.environ.get("RUNNER_WORKSPACE"),
        help="Override working directory (default: ~/.sidekick/<agent-name>/workspace)",
    )
    agent_run.add_argument(
        "--conversation",
        default=None,
        help="Continue existing conversation by ID",
    )
    agent_run.add_argument(
        "--json",
        action="store_true",
        dest="json_output",
        help="Output structured JSON",
    )
    agent_run.add_argument(
        "--no-stream",
        action="store_true",
        help="Wait for completion, print final text",
    )

    # agent list
    agent_list = agent_sub.add_parser(
        "list",
        help="List accessible agents",
    )
    _add_common_args(agent_list)
    agent_list.add_argument(
        "--search",
        default=None,
        help="Filter agents by name (case-insensitive substring match)",
    )

    # agent self
    agent_self = agent_sub.add_parser(
        "self",
        help="Show the current/default agent",
    )
    _add_common_args(agent_self)

    # agent create
    agent_create = agent_sub.add_parser(
        "create",
        help="Create a new agent",
    )
    _add_common_args(agent_create)
    agent_create.add_argument(
        "--name",
        required=True,
        help="Agent name",
    )
    agent_create.add_argument(
        "--description",
        default=None,
        help="Agent description",
    )
    agent_create.add_argument(
        "--system-prompt",
        default=None,
        help="System prompt for the agent",
    )
    agent_create.add_argument(
        "--model",
        default=None,
        help="LLM model ID (use 'sidekick models list' to see available models)",
    )

    # --- models command group ---
    models_parser = subparsers.add_parser(
        "models",
        help="Discover available LLM models",
    )
    models_sub = models_parser.add_subparsers(dest="models_command")

    # models list
    models_list = models_sub.add_parser(
        "list",
        help="List available LLM models",
    )
    _add_common_args(models_list)
    models_list.add_argument(
        "--tools-only",
        action="store_true",
        help="Only show models that support tool calling",
    )

    # models detail
    models_detail = models_sub.add_parser(
        "detail",
        help="Show detailed information about a model",
    )
    _add_common_args(models_detail)
    models_detail.add_argument(
        "model",
        help="Model ID (e.g. 'anthropic/claude-sonnet-4') or display name",
    )

    return parser


def _resolve_url(args_url: str | None) -> str:
    """Resolve frontend URL from flag -> env -> cached default."""
    from .auth import get_default_url

    url = args_url or os.environ.get("SIDEKICK_URL") or get_default_url()
    if not url:
        logger.error(
            "No Sidekick URL provided. Use --url, set SIDEKICK_URL, "
            "or run once with --url to cache a default."
        )
        sys.exit(1)
    return url


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------


def _run_serve(args: argparse.Namespace) -> None:
    """Execute the serve subcommand."""
    from .auth import (
        browser_register,
        get_cached_runner_credentials,
        resolve_backend_url,
        set_default_url,
    )
    from .display import RuntimeDisplay
    from .local_tools import set_allow_env_passthrough
    from .runner import run

    tui_enabled = not args.no_tui and sys.stdout.isatty()
    display = RuntimeDisplay(enabled=tui_enabled)
    display.setup_logging(args.log_level)

    # SEC-02: env-var passthrough
    set_allow_env_passthrough(args.allow_env_passthrough)

    # SEC-08: suppress httpx debug logging (may contain tokens/headers)
    logging.getLogger("httpx").setLevel(logging.WARNING)

    frontend_url = _resolve_url(args.url)
    token = args.token
    api_url: str | None = None

    if token:
        # Explicit token provided — just resolve the backend URL
        api_url = resolve_backend_url(frontend_url)
    else:
        # Try cached runner credentials
        cached = get_cached_runner_credentials(frontend_url)
        if cached:
            token = cached["token"]
            api_url = cached.get("api_url") or resolve_backend_url(frontend_url)
            logger.info("Using cached runner credentials for %s", frontend_url)
        else:
            # Open browser for runner registration
            logger.info("No runner token found — opening browser for registration...")
            try:
                result = browser_register(frontend_url)
                token = result["token"]
                api_url = result["api_url"]
            except Exception as exc:
                logger.error("Browser registration failed: %s", exc)
                sys.exit(1)

    set_default_url(frontend_url)

    loop = asyncio.new_event_loop()
    task = loop.create_task(
        run(
            api_url,
            token,
            name=args.name,
            workspace=args.workspace,
            display=display,
            allow_insecure=args.allow_insecure,
        )
    )

    if sys.platform != "win32":
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, task.cancel)

    try:
        loop.run_until_complete(task)
    except asyncio.CancelledError:
        pass
    except KeyboardInterrupt:
        task.cancel()
        try:
            loop.run_until_complete(task)
        except asyncio.CancelledError:
            pass
    finally:
        loop.close()


def _run_chat(args: argparse.Namespace) -> None:
    """Execute the chat subcommand."""
    from .cli_common import resolve_cli_context, run_async
    from .chat import run_chat

    ctx = resolve_cli_context(args)

    run_async(
        run_chat(
            url=ctx.api_url,
            agent_name=args.agent,
            conversation_id=args.conversation,
            token=ctx.token,
            workspace=args.workspace,
            allow_insecure=args.allow_insecure,
            runner_id=ctx.runner_id,
        )
    )


def _run_agent_run(args: argparse.Namespace) -> None:
    """Execute the agent run subcommand (non-interactive, single prompt)."""
    from .cli_common import resolve_cli_context, run_async
    from .run import run_prompt

    ctx = resolve_cli_context(args)

    # Handle stdin prompt
    prompt = args.prompt
    if prompt == "-":
        prompt = sys.stdin.read()
        if not prompt.strip():
            print("Error: empty prompt from stdin", file=sys.stderr)
            sys.exit(1)

    run_async(
        run_prompt(
            url=ctx.api_url,
            prompt=prompt,
            agent_name=args.agent,
            conversation_id=args.conversation,
            token=ctx.token,
            workspace=args.workspace,
            title=args.title,
            json_output=args.json_output,
            no_stream=args.no_stream,
            allow_insecure=args.allow_insecure,
            runner_id=ctx.runner_id,
        )
    )


def _run_agent_list(args: argparse.Namespace) -> None:
    """Execute the agent list subcommand."""
    from .cli_common import resolve_cli_context, run_async

    ctx = resolve_cli_context(args)

    async def _list():
        from .api_client import RuntimeAPIClient
        from rich.console import Console
        from rich.table import Table

        api = RuntimeAPIClient(base_url=ctx.api_url, token=ctx.token)
        try:
            agents = await api.list_agents()

            # Client-side search filter
            if args.search:
                term = args.search.lower()
                agents = [
                    a for a in agents
                    if term in a.get("name", "").lower()
                    or term in (a.get("description") or "").lower()
                ]

            console = Console()
            if not agents:
                console.print("[dim]No agents found.[/dim]")
                return

            table = Table(title="Agents")
            table.add_column("Name", style="bold")
            table.add_column("ID", style="dim")
            table.add_column("Description")

            for a in agents:
                table.add_row(
                    a.get("name", "?"),
                    a.get("id", "?"),
                    a.get("description") or "",
                )

            console.print(table)
        finally:
            await api.close()

    run_async(_list())


def _run_agent_self(args: argparse.Namespace) -> None:
    """Execute the agent self subcommand."""
    from .cli_common import resolve_cli_context, run_async

    ctx = resolve_cli_context(args)

    async def _self():
        from .api_client import RuntimeAPIClient
        from rich.console import Console
        from rich.table import Table

        api = RuntimeAPIClient(base_url=ctx.api_url, token=ctx.token)
        try:
            agent = None
            source = "User default"

            # Check SIDEKICK_AGENT_ID env var first (set when running as a tool inside an agent turn)
            env_agent_id = os.environ.get("SIDEKICK_AGENT_ID")
            if env_agent_id:
                agent = await api.get_agent(env_agent_id)
                if agent:
                    source = "SIDEKICK_AGENT_ID env var (current agent turn)"

            # Fall back to SIDEKICK_CONVERSATION_ID → look up agent from conversation
            if not agent:
                env_conv_id = os.environ.get("SIDEKICK_CONVERSATION_ID")
                if env_conv_id:
                    # The conversation's agent is the one invoking us
                    # For now, fall through to default — future: add conversation→agent lookup
                    pass

            # Fall back to default agent
            if not agent:
                agent = await api.get_default_agent()

            console = Console()
            if not agent:
                console.print("[red]No current or default agent found.[/red]")
                sys.exit(1)

            table = Table(title="Current Agent")
            table.add_column("Field", style="bold")
            table.add_column("Value")

            table.add_row("Name", agent.get("name", "?"))
            table.add_row("ID", agent.get("id", "?"))
            table.add_row("Description", agent.get("description") or "")
            table.add_row("Model", agent.get("model") or "(default)")
            table.add_row("Default", "Yes" if agent.get("is_default") else "No")
            table.add_row("Source", source)

            console.print(table)
        finally:
            await api.close()

    run_async(_self())


def _run_agent_create(args: argparse.Namespace) -> None:
    """Execute the agent create subcommand."""
    from .cli_common import resolve_cli_context, run_async

    ctx = resolve_cli_context(args)

    async def _create():
        from .api_client import RuntimeAPIClient
        from rich.console import Console

        api = RuntimeAPIClient(base_url=ctx.api_url, token=ctx.token)
        try:
            agent = await api.create_agent(
                name=args.name,
                description=args.description,
                system_prompt=args.system_prompt,
                model=args.model,
            )

            console = Console()
            console.print(f"[green]Agent created:[/green] {agent.get('name')}")
            console.print(f"  ID: {agent.get('id')}")
            if agent.get("model"):
                console.print(f"  Model: {agent.get('model')}")
            if agent.get("description"):
                console.print(f"  Description: {agent.get('description')}")
        finally:
            await api.close()

    run_async(_create())


def _run_models_list(args: argparse.Namespace) -> None:
    """Execute the models list subcommand."""
    from .cli_common import resolve_cli_context, run_async

    ctx = resolve_cli_context(args)

    async def _list():
        from .api_client import RuntimeAPIClient
        from rich.console import Console
        from rich.table import Table

        api = RuntimeAPIClient(base_url=ctx.api_url, token=ctx.token)
        try:
            models = await api.list_models(tools_only=args.tools_only)

            console = Console()
            if not models:
                console.print("[dim]No models found.[/dim]")
                return

            table = Table(title="Available Models")
            table.add_column("Model ID", style="bold")
            table.add_column("Name")
            table.add_column("Context", justify="right")
            table.add_column("Tools", justify="center")
            table.add_column("Vision", justify="center")

            for m in models:
                ctx_len = ""
                if m.get("context_length"):
                    ctx_len = f"{m['context_length']:,}"

                table.add_row(
                    m.get("model_id", "?"),
                    m.get("name", "?"),
                    ctx_len,
                    "Yes" if m.get("supports_tools") else "",
                    "Yes" if m.get("supports_vision") else "",
                )

            console.print(table)
        finally:
            await api.close()

    run_async(_list())


def _run_models_detail(args: argparse.Namespace) -> None:
    """Execute the models detail subcommand."""
    from .cli_common import resolve_cli_context, run_async

    ctx = resolve_cli_context(args)

    async def _detail():
        from .api_client import RuntimeAPIClient
        from rich.console import Console
        from rich.table import Table

        api = RuntimeAPIClient(base_url=ctx.api_url, token=ctx.token)
        try:
            model = await api.get_model(args.model)

            console = Console()
            if not model:
                console.print(f"[red]Model '{args.model}' not found.[/red]")
                sys.exit(1)

            table = Table(title=model.get("name", "Model Detail"))
            table.add_column("Field", style="bold")
            table.add_column("Value")

            table.add_row("Model ID", model.get("model_id", "?"))
            table.add_row("Name", model.get("name", "?"))
            table.add_row("Description", model.get("description") or "")

            if model.get("context_length"):
                table.add_row("Context Length", f"{model['context_length']:,} tokens")

            table.add_row("Supports Tools", "Yes" if model.get("supports_tools") else "No")
            table.add_row("Supports Vision", "Yes" if model.get("supports_vision") else "No")
            table.add_row("Supports JSON Mode", "Yes" if model.get("supports_json_mode") else "No")
            table.add_row("Enabled", "Yes" if model.get("is_enabled") else "No")

            if model.get("pricing_prompt") is not None:
                table.add_row("Pricing (Prompt)", f"${model['pricing_prompt']:.9f}/token")
            if model.get("pricing_completion") is not None:
                table.add_row("Pricing (Completion)", f"${model['pricing_completion']:.9f}/token")

            if model.get("architecture"):
                arch = model["architecture"]
                if isinstance(arch, dict):
                    for k, v in arch.items():
                        table.add_row(f"Architecture: {k}", str(v))

            if model.get("parameters"):
                params = model["parameters"]
                if isinstance(params, list):
                    table.add_row("Parameters", ", ".join(str(p) for p in params))

            console.print(table)
        finally:
            await api.close()

    run_async(_detail())


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------


def main() -> None:
    """CLI entry point."""
    parser = _build_parser()
    args = parser.parse_args()

    if args.command == "serve":
        _run_serve(args)
    elif args.command == "chat":
        _run_chat(args)
    elif args.command == "agent":
        agent_cmd = getattr(args, "agent_command", None)
        if agent_cmd == "run":
            _run_agent_run(args)
        elif agent_cmd == "list":
            _run_agent_list(args)
        elif agent_cmd == "self":
            _run_agent_self(args)
        elif agent_cmd == "create":
            _run_agent_create(args)
        else:
            # Print agent subcommand help
            parser.parse_args(["agent", "--help"])
    elif args.command == "models":
        models_cmd = getattr(args, "models_command", None)
        if models_cmd == "list":
            _run_models_list(args)
        elif models_cmd == "detail":
            _run_models_detail(args)
        else:
            parser.parse_args(["models", "--help"])
    else:
        parser.print_help()
        sys.exit(0)


if __name__ == "__main__":
    main()
