"""
Local tool executors for the agent runtime.

These execute tools using the local system (subprocess, filesystem)
rather than calling back to Sidekick. This is the key advantage of
running the runtime inside a VM — zero-hop tool execution.
"""

import asyncio
import logging
import os
from pathlib import Path
from .api_client import ToolNode, ToolResult

logger = logging.getLogger(__name__)

# Maximum file size to read (1MB)
MAX_READ_SIZE = 1024 * 1024

# Maximum command output size (5MB)
MAX_OUTPUT_SIZE = 5 * 1024 * 1024

# Maximum entries for recursive listing
MAX_LIST_ENTRIES = 500

# Maximum recursion depth for listing
MAX_LIST_DEPTH = 3

# Environment variables that should NOT be passed to CLI tool subprocesses
# unless --allow-env-passthrough is set.  This is a security allowlist approach:
# by default we strip everything sensitive.
SENSITIVE_ENV_VARS = frozenset({
    # Dynamic linker injection
    "LD_PRELOAD", "LD_LIBRARY_PATH", "DYLD_INSERT_LIBRARIES",
    "DYLD_LIBRARY_PATH",
    # Language-level code injection / path manipulation
    "PYTHONPATH", "PATH", "PYTHONSTARTUP", "PYTHONHOME", "NODE_OPTIONS",
    # Home / config directories (information leakage)
    "HOME", "XDG_CONFIG_HOME", "XDG_DATA_HOME",
    "USERPROFILE", "APPDATA", "LOCALAPPDATA",
    # Windows system paths and shell
    "COMSPEC", "PATHEXT", "SYSTEMROOT", "WINDIR",
    # Proxy settings (traffic redirection)
    "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY",
    # TLS / certificate overrides
    "SSL_CERT_FILE", "SSL_CERT_DIR", "REQUESTS_CA_BUNDLE", "CURL_CA_BUNDLE",
    # Git credential / config manipulation
    "GIT_SSH_COMMAND", "GIT_ASKPASS", "GIT_CONFIG_GLOBAL",
    # Cloud provider credentials
    "AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN",
    "AZURE_CLIENT_SECRET", "GOOGLE_APPLICATION_CREDENTIALS",
    # Editor hijacking
    "EDITOR", "VISUAL",
})

# Module-level flag: when True, cli_metadata env vars are passed through
# without filtering against SENSITIVE_ENV_VARS.
_allow_env_passthrough = False


def set_allow_env_passthrough(value: bool) -> None:
    """Enable or disable env-var passthrough for CLI tools."""
    global _allow_env_passthrough
    _allow_env_passthrough = value


async def execute_local_tool(node: ToolNode, workspace: str | None = None) -> ToolResult:
    """
    Execute a tool using local system resources.

    Args:
        node: The tool invocation descriptor.
        workspace: Explicit workspace directory for resolving relative paths.
                   Falls back to os.getcwd() when None.
    """
    executors = {
        "RunCommand": _run_command,
        "WriteFile": _write_file,
        "ReadFile": _read_file,
        "ListFiles": _list_files,
        "GetSessionInfo": _get_session_info,
    }

    executor = executors.get(node.tool_name)
    if executor:
        try:
            return await executor(node, workspace=workspace)
        except Exception as e:
            logger.error(f"Local tool {node.tool_name} failed: {e}", exc_info=True)
            return ToolResult(
                node_id=node.node_id,
                call_id=node.call_id,
                success=False,
                result=f"Tool execution failed: {type(e).__name__}",
                metadata={"error_type": "execution_error"},
            )

    # CLI tool: has cli_metadata attached by register_tool_calls
    if node.cli_metadata:
        try:
            return await _run_cli_tool(node, workspace=workspace)
        except Exception as e:
            logger.error(f"CLI tool {node.tool_name} failed: {e}", exc_info=True)
            return ToolResult(
                node_id=node.node_id,
                call_id=node.call_id,
                success=False,
                result=f"CLI tool execution failed: {type(e).__name__}",
                metadata={"error_type": "execution_error"},
            )

    return ToolResult(
        node_id=node.node_id,
        call_id=node.call_id,
        success=False,
        result=f"Unknown local tool: {node.tool_name}",
        metadata={"error_type": "unknown_tool"},
    )


async def _run_command(node: ToolNode, workspace: str | None = None) -> ToolResult:
    """Execute a shell command using subprocess."""
    command = node.arguments.get("command", "")
    if not command:
        return ToolResult(
            node_id=node.node_id,
            call_id=node.call_id,
            success=False,
            result="Error: 'command' is required",
            metadata={"error_type": "validation_error"},
        )

    working_dir = node.arguments.get("working_directory") or workspace
    timeout = node.arguments.get("timeout_seconds", 60)

    try:
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=working_dir,
        )

        stdout, stderr = await asyncio.wait_for(
            process.communicate(), timeout=timeout
        )

        stdout_str = stdout.decode("utf-8", errors="replace")[:MAX_OUTPUT_SIZE] if stdout else ""
        stderr_str = stderr.decode("utf-8", errors="replace")[:MAX_OUTPUT_SIZE] if stderr else ""
        exit_code = process.returncode or 0

        truncated = len(stdout) > MAX_OUTPUT_SIZE or len(stderr) > MAX_OUTPUT_SIZE

        output_parts = []
        if stdout_str:
            output_parts.append(stdout_str)
        if stderr_str:
            output_parts.append(f"[stderr]\n{stderr_str}")
        if truncated:
            output_parts.append(f"\n[output truncated at {MAX_OUTPUT_SIZE // (1024 * 1024)}MB]")

        output = "\n".join(output_parts) if output_parts else "(no output)"

        return ToolResult(
            node_id=node.node_id,
            call_id=node.call_id,
            success=exit_code == 0,
            result=output,
            metadata={
                "tool_type": "computer_use",
                "tool_name": "RunCommand",
                "command": command,
                "exit_code": exit_code,
                "working_directory": working_dir or os.getcwd(),
                "truncated": truncated,
            },
        )

    except asyncio.TimeoutError:
        return ToolResult(
            node_id=node.node_id,
            call_id=node.call_id,
            success=False,
            result=f"Command timed out after {timeout} seconds",
            metadata={
                "tool_type": "computer_use",
                "tool_name": "RunCommand",
                "error_type": "timeout",
            },
        )


async def _write_file(node: ToolNode, workspace: str | None = None) -> ToolResult:
    """Write content to a file."""
    path = node.arguments.get("path", "")
    content = node.arguments.get("content", "")

    if not path:
        return ToolResult(
            node_id=node.node_id,
            call_id=node.call_id,
            success=False,
            result="Error: 'path' is required",
            metadata={"error_type": "validation_error"},
        )

    try:
        file_path = Path(path)
        if not file_path.is_absolute() and workspace:
            file_path = Path(workspace) / file_path
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # Run file I/O in thread to avoid blocking
        def _write():
            file_path.write_text(content, encoding="utf-8")
            return len(content.encode("utf-8"))

        bytes_written = await asyncio.to_thread(_write)

        return ToolResult(
            node_id=node.node_id,
            call_id=node.call_id,
            success=True,
            result=f"File written: {path} ({bytes_written} bytes)",
            metadata={
                "tool_type": "computer_use",
                "tool_name": "WriteFile",
                "path": path,
                "bytes_written": bytes_written,
            },
        )
    except Exception as e:
        return ToolResult(
            node_id=node.node_id,
            call_id=node.call_id,
            success=False,
            result=f"File write failed: {str(e)}",
            metadata={"error_type": "execution_error", "error": str(e)},
        )


async def _read_file(node: ToolNode, workspace: str | None = None) -> ToolResult:
    """Read contents of a file."""
    path = node.arguments.get("path", "")

    if not path:
        return ToolResult(
            node_id=node.node_id,
            call_id=node.call_id,
            success=False,
            result="Error: 'path' is required",
            metadata={"error_type": "validation_error"},
        )

    try:
        file_path = Path(path)
        if not file_path.is_absolute() and workspace:
            file_path = Path(workspace) / file_path

        def _read():
            size = file_path.stat().st_size
            truncated = size > MAX_READ_SIZE
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read(MAX_READ_SIZE)
            return content, size, truncated

        content, size, truncated = await asyncio.to_thread(_read)

        suffix = "\n\n[truncated — file exceeds 1MB]" if truncated else ""

        return ToolResult(
            node_id=node.node_id,
            call_id=node.call_id,
            success=True,
            result=f"{content}{suffix}",
            metadata={
                "tool_type": "computer_use",
                "tool_name": "ReadFile",
                "path": path,
                "size_bytes": size,
                "truncated": truncated,
            },
        )
    except FileNotFoundError:
        return ToolResult(
            node_id=node.node_id,
            call_id=node.call_id,
            success=False,
            result=f"File not found: {path}",
            metadata={"error_type": "not_found"},
        )
    except Exception as e:
        return ToolResult(
            node_id=node.node_id,
            call_id=node.call_id,
            success=False,
            result=f"File read failed: {str(e)}",
            metadata={"error_type": "execution_error", "error": str(e)},
        )


async def _list_files(node: ToolNode, workspace: str | None = None) -> ToolResult:
    """List files in a directory."""
    path = node.arguments.get("path", ".")
    recursive = node.arguments.get("recursive", False)

    try:
        dir_path = Path(path)
        if not dir_path.is_absolute() and workspace:
            dir_path = Path(workspace) / dir_path

        def _list():
            if not dir_path.is_dir():
                raise NotADirectoryError(f"Not a directory: {path}")

            entries = []
            if recursive:
                _list_recursive(dir_path, entries, depth=0)
            else:
                for entry in sorted(dir_path.iterdir()):
                    try:
                        stat = entry.stat()
                        entries.append(
                            {
                                "name": entry.name,
                                "type": "directory" if entry.is_dir() else "file",
                                "size": stat.st_size if entry.is_file() else 0,
                            }
                        )
                    except (PermissionError, OSError):
                        entries.append(
                            {"name": entry.name, "type": "unknown", "size": 0}
                        )
            return entries

        entries = await asyncio.to_thread(_list)

        if not entries:
            output = f"Directory '{path}' is empty."
        else:
            lines = []
            for entry in entries:
                etype = "d" if entry["type"] == "directory" else "-"
                lines.append(f"{etype} {entry['size']:>10}  {entry['name']}")
            output = "\n".join(lines)

        return ToolResult(
            node_id=node.node_id,
            call_id=node.call_id,
            success=True,
            result=output,
            metadata={
                "tool_type": "computer_use",
                "tool_name": "ListFiles",
                "path": path,
                "entry_count": len(entries),
                "entries": entries,
            },
        )
    except Exception as e:
        return ToolResult(
            node_id=node.node_id,
            call_id=node.call_id,
            success=False,
            result=f"File listing failed: {str(e)}",
            metadata={"error_type": "execution_error", "error": str(e)},
        )


async def _get_session_info(node: ToolNode, workspace: str | None = None) -> ToolResult:
    """Return information about the local runner session."""
    import platform
    import socket

    cwd = os.getcwd()
    info_lines = [
        "Status: online",
        f"Working Directory: {cwd}",
        "Backend: self-hosted",
        f"Hostname: {socket.gethostname()}",
        f"OS: {platform.system()} {platform.release()}",
    ]

    return ToolResult(
        node_id=node.node_id,
        call_id=node.call_id,
        success=True,
        result="\n".join(info_lines),
        metadata={
            "tool_type": "computer_use",
            "tool_name": "GetSessionInfo",
        },
    )


async def _run_cli_tool(node: ToolNode, workspace: str | None = None) -> ToolResult:
    """Execute a CLI tool as a subprocess via uvx using cli_metadata."""
    import shlex

    meta = node.cli_metadata
    module_name = meta["module_name"]
    package_name = meta["package_name"]
    package_version = meta.get("package_version", "latest")
    command = node.arguments.get("command", "").strip()
    timeout = meta.get("timeout_seconds", 60)

    # Strip redundant tool name prefix if the LLM included it
    # e.g. tool=cowsay, command="cowsay --text hello" → "--text hello"
    if command.startswith(node.tool_name):
        rest = command[len(node.tool_name):]
        if not rest or rest[0] in (" ", "\t"):
            command = rest.strip()

    # Build uvx command: uvx --from <package_spec> <module> <args>
    if package_version and package_version != "latest":
        from_spec = f"{package_name}=={package_version}"
    else:
        from_spec = package_name

    cmd_parts = ["uvx", "--from", from_spec, module_name] + shlex.split(command)

    # Merge environment variables from cli_metadata
    env = os.environ.copy()
    env_vars = meta.get("env_vars", {})
    if _allow_env_passthrough:
        logger.debug("Env passthrough enabled — passing all %d cli_metadata env vars", len(env_vars))
        env.update(env_vars)
    else:
        blocked = [k for k in env_vars if k.upper() in SENSITIVE_ENV_VARS]
        if blocked:
            logger.warning("Stripped sensitive env vars from cli_metadata: %s", blocked)
        env.update({k: v for k, v in env_vars.items() if k.upper() not in SENSITIVE_ENV_VARS})

    logger.info(f"Executing CLI tool '{node.tool_name}': {' '.join(cmd_parts)}")

    # Execute via create_subprocess_exec (no shell interpolation)
    process = await asyncio.create_subprocess_exec(
        *cmd_parts,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        env=env,
    )

    stdout, stderr = await asyncio.wait_for(
        process.communicate(), timeout=timeout
    )

    stdout_str = stdout.decode("utf-8", errors="replace")[:MAX_OUTPUT_SIZE] if stdout else ""
    stderr_str = stderr.decode("utf-8", errors="replace")[:MAX_OUTPUT_SIZE] if stderr else ""
    exit_code = process.returncode or 0

    truncated = len(stdout) > MAX_OUTPUT_SIZE or len(stderr) > MAX_OUTPUT_SIZE

    output_parts = []
    if stdout_str:
        output_parts.append(stdout_str)
    if stderr_str:
        output_parts.append(f"[stderr]\n{stderr_str}")
    if truncated:
        output_parts.append(f"\n[output truncated at {MAX_OUTPUT_SIZE // (1024 * 1024)}MB]")

    output = "\n".join(output_parts) if output_parts else "(no output)"

    return ToolResult(
        node_id=node.node_id,
        call_id=node.call_id,
        success=exit_code == 0,
        result=output,
        metadata={
            "tool_type": "cli_tool",
            "tool_name": node.tool_name,
            "module_name": module_name,
            "command": command,
            "exit_code": exit_code,
            "truncated": truncated,
        },
    )


def _list_recursive(
    dir_path: Path, entries: list, depth: int, prefix: str = ""
):
    """Recursively list directory entries up to MAX_LIST_DEPTH."""
    if depth > MAX_LIST_DEPTH or len(entries) >= MAX_LIST_ENTRIES:
        return

    try:
        for entry in sorted(dir_path.iterdir()):
            if len(entries) >= MAX_LIST_ENTRIES:
                return

            name = f"{prefix}{entry.name}" if prefix else entry.name
            try:
                stat = entry.stat()
                entries.append(
                    {
                        "name": name,
                        "type": "directory" if entry.is_dir() else "file",
                        "size": stat.st_size if entry.is_file() else 0,
                    }
                )
            except (PermissionError, OSError):
                entries.append({"name": name, "type": "unknown", "size": 0})

            if entry.is_dir():
                _list_recursive(
                    entry, entries, depth + 1, prefix=f"{name}/"
                )
    except PermissionError:
        pass
