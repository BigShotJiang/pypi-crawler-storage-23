"""
RuntimeAPIClient — HTTP + SSE client for the Sidekick Runtime API.

All communication between the agent runtime and Sidekick backend
goes through this client. It handles authentication, request/response
serialization, and SSE stream parsing.
"""

import json
import logging
from typing import Any, Callable, Dict, List, Optional

import httpx
import httpx_sse
from pydantic import BaseModel, ConfigDict, Field

logger = logging.getLogger(__name__)

# Maximum accumulated content size from LLM streaming (10MB)
MAX_CONTENT_SIZE = 10 * 1024 * 1024


class TurnContext(BaseModel):
    """Context for an active turn."""

    model_config = ConfigDict(populate_by_name=True)

    turn_id: str
    conversation_id: str
    ref_name: str
    messages: List[Dict[str, Any]]
    tool_definitions: List[Dict[str, Any]] = Field(default_factory=list)
    tool_choice: Optional[Any] = None
    model: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    reasoning: Optional[Any] = None
    agent_id: Optional[str] = None
    agent_name: Optional[str] = None
    agent_config: Optional[Dict[str, Any]] = None


class EvaluationContext(BaseModel):
    """Context returned from starting an evaluation turn."""

    model_config = ConfigDict(populate_by_name=True)

    needed: bool
    evaluation_id: Optional[str] = None
    turn_id: Optional[str] = None
    branch_name: Optional[str] = None
    messages: List[Dict[str, Any]] = Field(default_factory=list)
    tool_definitions: List[Dict[str, Any]] = Field(default_factory=list)
    tool_choice: Optional[Any] = None
    model: Optional[str] = None
    temperature: float = 0.0
    original_token_count: Optional[int] = None


class LLMResponse(BaseModel):
    """Parsed response from an LLM streaming call."""

    model_config = ConfigDict(populate_by_name=True)

    content: str = ""
    reasoning_content: str = ""
    tool_calls: List[Dict[str, Any]] = Field(default_factory=list)
    finish_reason: Optional[str] = None
    parts: List[Dict[str, Any]] = Field(default_factory=list)


class ToolNode(BaseModel):
    """A tool node created by register_tool_calls."""

    model_config = ConfigDict(populate_by_name=True)

    node_id: str
    call_id: str
    tool_name: str
    execution: str  # "local" or "remote"
    arguments: Dict[str, Any] = Field(default_factory=dict)
    cli_metadata: Optional[Dict[str, Any]] = None


class ToolResult(BaseModel):
    """Result of executing a tool."""

    model_config = ConfigDict(populate_by_name=True)

    node_id: str
    call_id: str
    success: bool
    result: str
    result_format: str = "text"
    metadata: Optional[Dict[str, Any]] = None


class RuntimeAPIClient:
    """HTTP + SSE client for the Sidekick Runtime API."""

    def __init__(self, base_url: str, token: str, timeout: float = 600.0):
        """
        Initialize the client.

        Args:
            base_url: Sidekick backend URL (e.g. https://sidekick.example.com)
            token: Runner token for authentication
            timeout: Base timeout in seconds (used for read timeout on streaming)
        """
        self.base_url = base_url.rstrip("/")
        self.token = token
        self._client: Optional[httpx.AsyncClient] = None
        self._timeout = httpx.Timeout(
            connect=30.0,   # Connection establishment
            read=timeout,   # Time between data chunks (generous for streaming)
            write=30.0,     # Request write timeout
            pool=30.0,      # Connection pool wait
        )

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=f"{self.base_url}/api/runtime/v1",
                headers={
                    "Authorization": f"Bearer {self.token}",
                    "Content-Type": "application/json",
                },
                timeout=self._timeout,
                verify=True,
            )
        return self._client

    async def close(self):
        """Close the HTTP client."""
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    # --- Turn Lifecycle ---

    async def start_turn(
        self,
        conversation_id: str,
        node_id: str,
        ref_name: str = "main",
        user_id: Optional[str] = None,
    ) -> TurnContext:
        """Begin a new turn: load context and get ready for LLM call."""
        client = await self._get_client()
        body: Dict[str, Any] = {
            "conversation_id": conversation_id,
            "node_id": node_id,
            "ref_name": ref_name,
        }
        if user_id:
            body["user_id"] = user_id
        response = await client.post("/turns/start", json=body)
        response.raise_for_status()
        data = response.json()

        try:
            return TurnContext(**data)
        except Exception as e:
            raise RuntimeError(f"Invalid server response for start_turn: {e}") from e

    async def stream_llm(
        self,
        turn_id: str,
        context: TurnContext,
        on_delta: Optional[Callable[[str], None]] = None,
    ) -> LLMResponse:
        """
        Call LLM via the proxy endpoint (SSE stream).

        Sidekick handles fan-out to frontend. This method consumes
        the stream and returns the accumulated response.

        Args:
            turn_id: Current turn ID.
            context: Turn context with messages and model config.
            on_delta: Optional callback invoked with each content delta string
                      as it arrives. Useful for streaming text to a terminal.
        """
        client = await self._get_client()

        payload = {
            "turn_id": turn_id,
            "messages": context.messages,
            "model": context.model or "anthropic/claude-3.5-sonnet",
            "temperature": context.temperature,
            "max_tokens": context.max_tokens,
            "tools": context.tool_definitions if context.tool_definitions else None,
            "tool_choice": context.tool_choice,
            "reasoning": context.reasoning,
        }

        result = LLMResponse()

        async with httpx_sse.aconnect_sse(
            client, "POST", "/chat/completions", json=payload
        ) as event_source:
            async for event in event_source.aiter_sse():
                if event.data == "[DONE]":
                    break

                try:
                    chunk = json.loads(event.data)
                except json.JSONDecodeError:
                    continue

                if "error" in chunk:
                    raise RuntimeError(chunk["error"].get("message", "LLM error"))

                choices = chunk.get("choices", [])
                if not choices:
                    continue

                delta = choices[0].get("delta", {})
                finish_reason = choices[0].get("finish_reason")

                if delta.get("content"):
                    delta_content = delta["content"]
                    if len(result.content) + len(delta_content) > MAX_CONTENT_SIZE:
                        raise RuntimeError(
                            f"LLM response exceeded maximum content size ({MAX_CONTENT_SIZE // (1024 * 1024)}MB)"
                        )
                    result.content += delta_content
                    if on_delta:
                        on_delta(delta_content)

                if delta.get("reasoning_content"):
                    delta_reasoning = delta["reasoning_content"]
                    if len(result.reasoning_content) + len(delta_reasoning) > MAX_CONTENT_SIZE:
                        raise RuntimeError(
                            f"LLM reasoning exceeded maximum content size ({MAX_CONTENT_SIZE // (1024 * 1024)}MB)"
                        )
                    result.reasoning_content += delta_reasoning

                if delta.get("tool_calls"):
                    for tc_delta in delta["tool_calls"]:
                        idx = tc_delta.get("index", 0)
                        # Extend list if needed
                        while len(result.tool_calls) <= idx:
                            result.tool_calls.append(
                                {"id": "", "type": "function", "function": {"name": "", "arguments": ""}}
                            )

                        tc = result.tool_calls[idx]
                        if "id" in tc_delta and tc_delta["id"]:
                            tc["id"] = tc_delta["id"]
                        func_delta = tc_delta.get("function", {})
                        if func_delta.get("name"):
                            tc["function"]["name"] += func_delta["name"]
                        if func_delta.get("arguments"):
                            tc["function"]["arguments"] += func_delta["arguments"]

                if finish_reason:
                    result.finish_reason = finish_reason

        # Build parts from accumulated content
        if result.content:
            result.parts.append(
                {"kind": "text", "payload": {"text": result.content}}
            )
        if result.reasoning_content:
            result.parts.append(
                {"kind": "reasoning", "payload": {"text": result.reasoning_content}}
            )
        if result.tool_calls:
            for tc in result.tool_calls:
                args_str = tc["function"]["arguments"]
                try:
                    args = json.loads(args_str) if args_str else {}
                except json.JSONDecodeError:
                    args = {}

                result.parts.append(
                    {
                        "kind": "tool_call",
                        "payload": {
                            "call_id": tc["id"],
                            "tool_id": tc["function"]["name"],
                            "arguments": args,
                        },
                    }
                )

        return result

    async def register_tool_calls(
        self,
        turn_id: str,
        parts: List[Dict[str, Any]],
        tool_calls: List[Dict[str, Any]],
        tool_definitions: List[Dict[str, Any]] = None,
    ) -> List[ToolNode]:
        """Register tool calls with Sidekick and create tool_result nodes."""
        client = await self._get_client()

        # Determine execution mode and CLI metadata for each tool call
        tool_exec_map = {}
        tool_cli_map = {}
        if tool_definitions:
            for td in tool_definitions:
                name = td.get("function", {}).get("name", "")
                tool_exec_map[name] = td.get("execution", "remote")
                if td.get("cli_metadata"):
                    tool_cli_map[name] = td["cli_metadata"]

        tool_call_infos = []
        for tc in tool_calls:
            name = tc["function"]["name"]
            args_str = tc["function"]["arguments"]
            try:
                args = json.loads(args_str) if isinstance(args_str, str) else args_str
            except json.JSONDecodeError:
                args = {}

            tool_call_infos.append(
                {
                    "call_id": tc["id"],
                    "tool_name": name,
                    "arguments": args,
                    "execution": tool_exec_map.get(name, "remote"),
                }
            )

        response = await client.post(
            f"/turns/{turn_id}/tool-calls",
            json={
                "assistant_parts": parts,
                "tool_calls": tool_call_infos,
            },
        )
        response.raise_for_status()
        data = response.json()

        try:
            tool_nodes_data = data["tool_nodes"]
        except KeyError as e:
            raise RuntimeError(f"Invalid server response for register_tool_calls: missing field {e}") from e

        try:
            return [
                ToolNode(
                    node_id=tn["node_id"],
                    call_id=tn["call_id"],
                    tool_name=tn["tool_name"],
                    execution=tn["execution"],
                    arguments=tn["arguments"],
                    cli_metadata=tool_cli_map.get(tn["tool_name"]),
                )
                for tn in tool_nodes_data
            ]
        except (KeyError, Exception) as e:
            raise RuntimeError(f"Invalid server response for register_tool_calls: {e}") from e

    async def submit_tool_results(
        self, turn_id: str, results: List[ToolResult]
    ):
        """Submit tool execution results to Sidekick."""
        client = await self._get_client()

        response = await client.post(
            f"/turns/{turn_id}/tool-results",
            json={
                "results": [
                    {
                        "node_id": r.node_id,
                        "call_id": r.call_id,
                        "success": r.success,
                        "result": r.result,
                        "result_format": r.result_format,
                        "metadata": r.metadata,
                    }
                    for r in results
                ]
            },
        )
        response.raise_for_status()

    async def continue_turn(self, turn_id: str) -> TurnContext:
        """Get updated context after tool results for next LLM call."""
        client = await self._get_client()
        response = await client.post(f"/turns/{turn_id}/continue")
        response.raise_for_status()
        data = response.json()

        try:
            # Return a partial TurnContext with updated messages
            return TurnContext(
                turn_id=turn_id,
                conversation_id="",  # Not needed for continuation
                ref_name="",
                messages=data["messages"],
                tool_definitions=data.get("tool_definitions", []),
            )
        except KeyError as e:
            raise RuntimeError(f"Invalid server response for continue_turn: missing field {e}") from e

    async def complete_turn(
        self, turn_id: str, final_parts: List[Dict[str, Any]]
    ):
        """Finalize a turn: save parts, advance ref."""
        client = await self._get_client()
        response = await client.post(
            f"/turns/{turn_id}/complete",
            json={"final_parts": final_parts},
        )
        response.raise_for_status()

    async def is_cancelled(self, turn_id: str) -> bool:
        """Check if a turn has been cancelled."""
        client = await self._get_client()
        response = await client.get(f"/turns/{turn_id}/status")
        response.raise_for_status()
        return response.json().get("cancelled", False)

    async def execute_remote_tool(
        self, tool_node: ToolNode, conversation_id: str, node_id: str, ref_name: str
    ) -> ToolResult:
        """Execute a tool on-cluster via the Runtime API."""
        client = await self._get_client()
        response = await client.post(
            "/tools/execute",
            json={
                "tool_name": tool_node.tool_name,
                "arguments": tool_node.arguments,
                "conversation_id": conversation_id,
                "node_id": node_id,
                "ref_name": ref_name,
            },
        )
        response.raise_for_status()
        data = response.json()

        return ToolResult(
            node_id=tool_node.node_id,
            call_id=tool_node.call_id,
            success=data.get("success", False),
            result=data.get("result", ""),
            result_format=data.get("result_format", "text"),
            metadata=data.get("metadata"),
        )

    # --- Context Evaluation ---

    async def start_evaluation(
        self, turn_id: str, node_id: str
    ) -> EvaluationContext:
        """Start an evaluation turn for a tool result node."""
        client = await self._get_client()
        response = await client.post(
            f"/turns/{turn_id}/evaluations/start",
            json={"node_id": node_id},
        )
        response.raise_for_status()
        return EvaluationContext(**response.json())

    async def apply_evaluation(
        self, turn_id: str, request: dict
    ) -> dict:
        """Apply an evaluation decision to the main branch."""
        client = await self._get_client()
        response = await client.post(
            f"/turns/{turn_id}/evaluations/apply",
            json=request,
        )
        response.raise_for_status()
        return response.json()

    # --- Chat Mode (CLI) ---

    async def list_agents(self) -> List[Dict[str, Any]]:
        """List agents accessible to the authenticated user (CLI mode)."""
        client = await self._get_client()
        response = await client.get("/agents")
        response.raise_for_status()
        return response.json()

    async def create_conversation(
        self, agent_id: str, title: str | None = None, runner_id: str | None = None,
    ) -> Dict[str, Any]:
        """Create a new conversation (CLI mode).

        Returns dict with conversation_id and ref_name.
        """
        client = await self._get_client()
        payload: Dict[str, Any] = {"agent_id": agent_id}
        if title:
            payload["title"] = title
        if runner_id:
            payload["runner_id"] = runner_id
        response = await client.post("/conversations", json=payload)
        response.raise_for_status()
        return response.json()

    async def send_message(
        self, conversation_id: str, content: str, ref_name: str = "main"
    ) -> Dict[str, Any]:
        """Send a user message in a conversation (CLI mode).

        Returns dict with node_id and ref_name.
        """
        client = await self._get_client()
        response = await client.post(
            f"/conversations/{conversation_id}/messages",
            json={"content": content, "ref_name": ref_name},
        )
        response.raise_for_status()
        return response.json()

    async def get_default_agent(self) -> Dict[str, Any] | None:
        """Get the user's default agent. Returns None on 404."""
        client = await self._get_client()
        response = await client.get("/agents/default")
        if response.status_code == 404:
            return None
        response.raise_for_status()
        return response.json()

    async def get_agent(self, agent_id: str) -> Dict[str, Any] | None:
        """Get a specific agent by ID. Returns None on 404."""
        client = await self._get_client()
        response = await client.get(f"/agents/{agent_id}")
        if response.status_code == 404:
            return None
        response.raise_for_status()
        return response.json()

    async def create_agent(
        self,
        name: str,
        description: str | None = None,
        system_prompt: str | None = None,
        model: str | None = None,
    ) -> Dict[str, Any]:
        """Create a new agent. Returns the created agent details."""
        client = await self._get_client()
        payload: Dict[str, Any] = {"name": name}
        if description:
            payload["description"] = description
        if system_prompt:
            payload["system_prompt"] = system_prompt
        if model:
            payload["model"] = model
        response = await client.post("/agents", json=payload)
        response.raise_for_status()
        return response.json()

    async def list_models(self, tools_only: bool = False) -> List[Dict[str, Any]]:
        """List available LLM models."""
        client = await self._get_client()
        params: Dict[str, Any] = {}
        if tools_only:
            params["supports_tools"] = "true"
        response = await client.get("/models", params=params)
        response.raise_for_status()
        return response.json()

    async def get_model(self, model_id: str) -> Dict[str, Any] | None:
        """Get detailed information about a specific model. Returns None on 404."""
        client = await self._get_client()
        response = await client.get(f"/models/{model_id}")
        if response.status_code == 404:
            return None
        response.raise_for_status()
        return response.json()
