"""
AgentRuntime — the core agent loop.

This is the portable agent execution engine. The same code runs:
- In a Fly.io VM (connected to Sidekick over the internet)
- In a Hatchet worker (connected over localhost)
- On a user's laptop (connected to their Sidekick instance)

The runtime communicates exclusively through the RuntimeAPIClient.
It never touches databases, Redis, or LLM providers directly.
"""

import asyncio
import json
import logging
import os
from typing import Dict, List, Optional

from .api_client import (
    LLMResponse,
    RuntimeAPIClient,
    ToolNode,
    ToolResult,
    TurnContext,
)
from .local_tools import execute_local_tool

logger = logging.getLogger(__name__)


class AgentRuntime:
    """Portable agent execution engine."""

    def __init__(self, api: RuntimeAPIClient, display=None, workspace: str | None = None):
        self.api = api
        self._display = display
        self._workspace = workspace

    async def run_turn(
        self, conversation_id: str, node_id: str, ref_name: str = "main",
        on_delta=None, user_id: str = None,
        on_tool_start=None, on_tool_complete=None,
    ) -> None:
        """
        Execute a complete agent turn.

        This is the core loop:
        1. Start turn (loads context from Sidekick)
        2. Call LLM (Sidekick proxies and handles frontend streaming)
        3. If tool calls: register, execute, submit results, continue
        4. If no tool calls: complete the turn

        Args:
            conversation_id: The conversation to process
            node_id: The user/tool node that triggered this turn
            ref_name: The ref/branch to advance
            on_delta: Optional callback invoked with each content token as it
                      streams from the LLM.  Used by chat mode to display
                      tokens in real time.
            user_id: Optional user ID for token attribution (e.g. service account)
            on_tool_start: Optional callback(tool_name: str) called when a tool begins execution.
            on_tool_complete: Optional callback(tool_name: str, success: bool) called when a tool finishes.
        """
        turn = await self.api.start_turn(conversation_id, node_id, ref_name, user_id=user_id)

        # Expose agent/conversation context as env vars so local tools
        # (RunCommand, etc.) inherit them in their subprocess environment.
        if turn.agent_id:
            os.environ["SIDEKICK_AGENT_ID"] = turn.agent_id
        os.environ["SIDEKICK_CONVERSATION_ID"] = conversation_id

        logger.info(
            f"Turn started: {turn.turn_id} | "
            f"conversation={conversation_id} | "
            f"agent={turn.agent_name} | "
            f"{len(turn.messages)} messages, {len(turn.tool_definitions)} tools"
        )
        if self._display:
            self._display.on_turn_started(conversation_id, turn.agent_name)

        iteration = 0
        max_iterations = 25  # Safety limit

        try:
            while iteration < max_iterations:
                iteration += 1

                # Check cancellation
                if await self.api.is_cancelled(turn.turn_id):
                    logger.info(f"Turn {turn.turn_id} cancelled")
                    if self._display:
                        self._display.on_turn_cancelled(turn.turn_id)
                    break

                # Call LLM (Sidekick handles frontend streaming as a side effect)
                logger.info(f"LLM call #{iteration} for turn {turn.turn_id}")
                if self._display:
                    self._display.on_llm_call(iteration, turn.turn_id)
                response = await self.api.stream_llm(turn.turn_id, turn, on_delta=on_delta)

                if not response.tool_calls:
                    # No tool calls — finalize the turn
                    await self.api.complete_turn(turn.turn_id, response.parts)
                    logger.info(
                        f"Turn {turn.turn_id} completed (no tools) after {iteration} iteration(s)"
                    )
                    if self._display:
                        self._display.on_turn_completed(turn.turn_id, iteration)
                    return

                # Register tool calls with Sidekick (creates pending nodes)
                tool_nodes = await self.api.register_tool_calls(
                    turn.turn_id,
                    response.parts,
                    response.tool_calls,
                    turn.tool_definitions,
                )

                tool_names = [tn.tool_name for tn in tool_nodes]
                logger.info(
                    f"Registered {len(tool_nodes)} tool calls: "
                    f"{', '.join(tool_names)}"
                )
                if self._display:
                    self._display.on_tools_registered(tool_names)

                # Execute tools (local or remote)
                results = await self._execute_tools(
                    tool_nodes, conversation_id, node_id, ref_name,
                    on_tool_start=on_tool_start, on_tool_complete=on_tool_complete,
                )

                # Submit results to Sidekick
                await self.api.submit_tool_results(turn.turn_id, results)

                # Evaluate oversized tool results via ephemeral branches
                eval_config = (turn.agent_config or {}).get("context_evaluation", {})
                if eval_config.get("enabled"):
                    await self._evaluate_tool_results(
                        turn, results, eval_config, tool_nodes
                    )

                # Get updated context for next LLM call
                continuation = await self.api.continue_turn(turn.turn_id)
                turn.messages = continuation.messages
                turn.tool_definitions = continuation.tool_definitions

            if iteration >= max_iterations:
                logger.warning(
                    f"Turn {turn.turn_id} hit max iterations ({max_iterations})"
                )
                # Still complete the turn with whatever we have
                await self.api.complete_turn(turn.turn_id, [])
        finally:
            # Clean up turn-scoped env vars
            os.environ.pop("SIDEKICK_AGENT_ID", None)
            os.environ.pop("SIDEKICK_CONVERSATION_ID", None)

    async def _execute_single_tool(
        self,
        node: ToolNode,
        conversation_id: str,
        node_id: str,
        ref_name: str,
        on_tool_start=None,
        on_tool_complete=None,
    ) -> ToolResult:
        """Execute a single tool (local or remote)."""
        if on_tool_start:
            on_tool_start(node.tool_name)
        if node.execution == "local":
            logger.debug(f"Executing local tool: {node.tool_name}")
            result = await execute_local_tool(node, workspace=self._workspace)
        else:
            logger.debug(f"Executing remote tool: {node.tool_name}")
            result = await self.api.execute_remote_tool(
                node, conversation_id, node_id, ref_name
            )

        if result.success:
            logger.info(
                f"Tool {node.tool_name} ({'local' if node.execution == 'local' else 'remote'}): success"
            )
        else:
            logger.warning(
                f"Tool {node.tool_name} ({'local' if node.execution == 'local' else 'remote'}): FAILED"
            )
        logger.debug(
            f"Tool {node.tool_name} result: "
            f"{result.result[:200]}{'...' if len(result.result) > 200 else ''}",
        )
        if on_tool_complete:
            on_tool_complete(node.tool_name, result.success)
        if self._display:
            self._display.on_tool_executed(node.tool_name, result.success, node.execution)
        return result

    async def _execute_tools(
        self,
        tool_nodes: List[ToolNode],
        conversation_id: str,
        node_id: str,
        ref_name: str,
        on_tool_start=None,
        on_tool_complete=None,
    ) -> List[ToolResult]:
        """
        Execute a batch of tools in parallel.

        Local tools run directly (subprocess, filesystem).
        Remote tools are proxied through Sidekick.
        All tools in a batch are independent and execute concurrently.
        """
        results = await asyncio.gather(
            *(
                self._execute_single_tool(
                    node, conversation_id, node_id, ref_name,
                    on_tool_start=on_tool_start, on_tool_complete=on_tool_complete,
                )
                for node in tool_nodes
            )
        )
        return list(results)

    # Tools whose results should never be evaluated
    EVAL_EXEMPT_TOOLS = {"RetrieveOriginalContent"}

    async def _evaluate_tool_results(
        self,
        turn: TurnContext,
        results: List[ToolResult],
        eval_config: dict,
        tool_nodes: Optional[List[ToolNode]] = None,
    ) -> None:
        """
        Evaluate oversized tool results via ephemeral branches.

        For each successful tool result that exceeds the character threshold,
        starts an evaluation turn on an ephemeral branch, makes an LLM call
        with the evaluate_context_value tool, and applies the decision to
        the main branch.
        """
        # Rough char estimate: 1 token ~= 4 chars
        threshold_chars = eval_config.get("token_threshold", 3000) * 4

        # Map node_id → tool_name for exemption checks
        tool_name_map = {}
        if tool_nodes:
            tool_name_map = {tn.node_id: tn.tool_name for tn in tool_nodes}

        for result in results:
            if not result.success or len(result.result) < threshold_chars:
                continue

            tool_name = tool_name_map.get(result.node_id, "")
            if tool_name in self.EVAL_EXEMPT_TOOLS:
                logger.debug(
                    f"Skipping evaluation for {tool_name} result {result.node_id}"
                )
                continue

            logger.info(
                f"Tool result {result.node_id} exceeds threshold "
                f"({len(result.result)} chars >= {threshold_chars}), "
                f"requesting evaluation"
            )

            try:
                # 1. Start evaluation — backend checks exact token count and
                #    creates ephemeral branch if needed
                eval_ctx = await self.api.start_evaluation(
                    turn.turn_id, result.node_id
                )
                if not eval_ctx.needed:
                    logger.debug(
                        f"Evaluation not needed for {result.node_id} "
                        f"(under token threshold)"
                    )
                    continue

                logger.info(
                    f"Evaluation started for {result.node_id}: "
                    f"branch={eval_ctx.branch_name}, "
                    f"tokens={eval_ctx.original_token_count}"
                )

                # 2. Build TurnContext for the evaluation LLM call
                eval_turn = TurnContext(
                    turn_id=eval_ctx.turn_id,
                    conversation_id=turn.conversation_id,
                    ref_name=eval_ctx.branch_name,
                    messages=eval_ctx.messages,
                    tool_definitions=eval_ctx.tool_definitions,
                    tool_choice=eval_ctx.tool_choice,
                    model=eval_ctx.model,
                    temperature=eval_ctx.temperature,
                )

                # 3. LLM call on ephemeral branch (same stream_llm as normal turns)
                eval_response = await self.api.stream_llm(
                    eval_ctx.turn_id, eval_turn
                )

                # 4. Parse evaluate_context_value tool call from response
                decision = _parse_eval_decision(eval_response)
                if not decision:
                    logger.warning(
                        f"Could not parse evaluation decision for {result.node_id}, "
                        f"completing eval turn without applying"
                    )
                    await self.api.complete_turn(
                        eval_ctx.turn_id, eval_response.parts
                    )
                    continue

                action = decision.get("action", "keep")
                logger.info(
                    f"Evaluation decision for {result.node_id}: {action} "
                    f"(reason: {decision.get('reasoning', '')})"
                )

                # 5. Apply decision to main branch
                apply_result = await self.api.apply_evaluation(
                    turn.turn_id,
                    {
                        "evaluation_id": eval_ctx.evaluation_id,
                        "node_id": result.node_id,
                        "decision": decision,
                        "assistant_parts": eval_response.parts,
                    },
                )

                if apply_result.get("applied"):
                    logger.info(
                        f"Applied evaluation to {result.node_id}: "
                        f"{apply_result.get('original_token_count')} -> "
                        f"{apply_result.get('replacement_token_count')} tokens"
                    )

            except Exception as e:
                logger.error(
                    f"Context evaluation failed for {result.node_id}: {e}",
                    exc_info=True,
                )
                # Non-fatal — continue with unmodified tool result


def _parse_eval_decision(response: LLMResponse) -> Optional[Dict]:
    """Extract decision from evaluate_context_value tool call in LLM response."""
    for tc in response.tool_calls:
        func = tc.get("function", {})
        if func.get("name") == "evaluate_context_value":
            args = func.get("arguments", "")
            if isinstance(args, str):
                try:
                    return json.loads(args)
                except json.JSONDecodeError:
                    return None
            return args
    return None
