"""
Shared CLI context and helpers.

Extracts the repeated auth/setup boilerplate shared by chat, run,
and the new agent/models commands.
"""

from __future__ import annotations

import asyncio
import logging
import signal
import sys
from dataclasses import dataclass

logger = logging.getLogger("agent_runtime.cli_common")


@dataclass
class CLIContext:
    """Resolved CLI connection context."""

    frontend_url: str
    api_url: str
    token: str | None
    runner_id: str | None


def resolve_cli_context(args) -> CLIContext:
    """Resolve auth + connection context from CLI args / env / cache.

    Configures logging, env passthrough, httpx suppression, then
    resolves URL -> token (from args/env/cache) -> runner_id.
    """
    from .auth import (
        get_cached_cli_credentials,
        get_cached_runner_credentials,
        resolve_backend_url,
        set_default_url,
    )
    from .local_tools import set_allow_env_passthrough

    logging.basicConfig(level=getattr(logging, args.log_level))

    # SEC-02: env-var passthrough
    if getattr(args, "allow_env_passthrough", False):
        set_allow_env_passthrough(True)

    # SEC-08: suppress httpx debug logging (may contain tokens/headers)
    logging.getLogger("httpx").setLevel(logging.WARNING)

    # Resolve frontend URL
    from .cli import _resolve_url

    frontend_url = _resolve_url(args.url)
    token = args.token
    api_url: str | None = None

    if token:
        api_url = resolve_backend_url(frontend_url)
    else:
        cached = get_cached_cli_credentials(frontend_url)
        if cached:
            token = cached["token"]
            api_url = cached.get("api_url") or resolve_backend_url(frontend_url)
            logger.info("Using cached CLI credentials for %s", frontend_url)

    set_default_url(frontend_url)

    # Look up runner_id from cached runner credentials
    runner_id: str | None = None
    runner_creds = get_cached_runner_credentials(frontend_url)
    if runner_creds:
        runner_id = runner_creds.get("runner_id")

    return CLIContext(
        frontend_url=frontend_url,
        api_url=api_url or frontend_url,
        token=token,
        runner_id=runner_id,
    )


def run_async(coro) -> None:
    """Run an async coroutine with signal handling."""
    loop = asyncio.new_event_loop()
    task = loop.create_task(coro)

    if sys.platform != "win32":
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, task.cancel)

    try:
        loop.run_until_complete(task)
    except asyncio.CancelledError:
        pass
    except KeyboardInterrupt:
        task.cancel()
        try:
            loop.run_until_complete(task)
        except asyncio.CancelledError:
            pass
    finally:
        loop.close()
