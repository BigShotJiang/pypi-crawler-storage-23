"""
Runner loop for self-hosted agent runtimes.

The runner:
1. Connects to Sidekick via WebSocket for notifications
2. Sends machine info (hostname, OS, version) on connect
3. When a new turn arrives, executes it via the Runtime API
4. Reconnects automatically on disconnect (exponential backoff)

Use via CLI: sidekick serve --url <url> --token <token>
Or import: from agent_runtime.runner import run
"""

import asyncio
import json
import logging
import os
import pathlib
import platform
import re
import socket
from urllib.parse import urlparse

logger = logging.getLogger("agent_runtime.runner")

try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("sidekick-agent-cli")
except Exception:
    __version__ = "0.1.0"  # Fallback for editable installs / development


def _is_wsl() -> bool:
    """Detect if running inside Windows Subsystem for Linux."""
    try:
        with open("/proc/version") as f:
            return "microsoft" in f.read().lower()
    except Exception:
        return False


def _get_machine_info(name: str | None = None) -> dict:
    """Collect machine info to send on WebSocket connect."""
    system = platform.system()
    os_label = f"{system} {platform.release()}"
    if system == "Linux" and _is_wsl():
        os_label += " (WSL)"

    info: dict = {
        "hostname": socket.gethostname(),
        "os": os_label,
        "platform": platform.platform(),
        "python_version": platform.python_version(),
        "agent_runtime_version": __version__,
        "name": name,
    }

    # CPU info
    info["cpu_cores"] = os.cpu_count()
    info["cpu_arch"] = platform.machine()
    if system == "Darwin":
        info["cpu_name"] = _run_quiet(["sysctl", "-n", "machdep.cpu.brand_string"])
    elif system == "Windows":
        raw = _run_quiet(["wmic", "cpu", "get", "name", "/value"])
        info["cpu_name"] = raw.split("=", 1)[1].strip() if raw and "=" in raw else None
    else:
        info["cpu_name"] = _read_file_line("/proc/cpuinfo", "model name")
    if not info["cpu_name"]:
        info["cpu_name"] = platform.processor() or None

    # Memory (total physical RAM in bytes)
    mem_bytes: int | None = None
    if system == "Darwin":
        raw = _run_quiet(["sysctl", "-n", "hw.memsize"])
        if raw:
            mem_bytes = int(raw)
    elif system == "Windows":
        raw = _run_quiet(["wmic", "OS", "get", "TotalVisibleMemorySize", "/value"])
        if raw and "=" in raw:
            try:
                mem_bytes = int(raw.split("=", 1)[1].strip()) * 1024  # KB -> bytes
            except (ValueError, IndexError):
                pass
    elif system == "Linux":
        raw = _read_file_line("/proc/meminfo", "MemTotal")
        if raw:
            # Format: "16384000 kB" (after splitting on ":" in _read_file_line)
            parts = raw.split()
            if parts:
                mem_bytes = int(parts[0]) * 1024
    info["memory_total_bytes"] = mem_bytes

    # GPU (best-effort detection) — list of {name, cores?}
    gpus: list[dict] = []
    if system == "Darwin":
        raw = _run_quiet(["system_profiler", "SPDisplaysDataType", "-detailLevel", "mini"])
        if raw:
            current_gpu: dict | None = None
            for line in raw.splitlines():
                stripped = line.strip()
                if stripped.startswith("Chipset Model:") or stripped.startswith("Chip:"):
                    current_gpu = {"name": stripped.split(":", 1)[1].strip()}
                    gpus.append(current_gpu)
                elif stripped.startswith("Total Number of Cores:") and current_gpu:
                    try:
                        current_gpu["cores"] = int(stripped.split(":", 1)[1].strip())
                    except ValueError:
                        pass
    else:
        # Try nvidia-smi for NVIDIA GPUs (name + memory as proxy for size)
        raw = _run_quiet([
            "nvidia-smi",
            "--query-gpu=name,memory.total",
            "--format=csv,noheader,nounits",
        ])
        if raw:
            for line in raw.strip().splitlines():
                parts = [p.strip() for p in line.split(",")]
                if parts:
                    gpu: dict = {"name": parts[0]}
                    if len(parts) >= 2:
                        try:
                            gpu["memory_mb"] = int(parts[1])
                        except ValueError:
                            pass
                    gpus.append(gpu)
    info["gpus"] = gpus if gpus else None

    return info


def _run_quiet(cmd: list[str]) -> str | None:
    """Run a command and return stripped stdout, or None on failure."""
    import subprocess
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
        return result.stdout.strip() or None
    except Exception:
        return None


def _read_file_line(path: str, prefix: str) -> str | None:
    """Read a file and return the value of the first line matching prefix."""
    try:
        with open(path) as f:
            for line in f:
                if line.startswith(prefix):
                    return line.split(":", 1)[1].strip()
    except Exception:
        pass
    return None


class _nullcontext:
    """Async no-op context manager (fallback when display is disabled)."""
    async def __aenter__(self):
        return self
    async def __aexit__(self, *args):
        return False


def _sanitize_name(name: str) -> str:
    """Sanitize a runner name for use as a directory name."""
    sanitized = re.sub(r"[^a-zA-Z0-9_-]", "-", name)
    sanitized = re.sub(r"-{2,}", "-", sanitized).strip("-").lower()
    return sanitized or "default"


def _setup_workspace(runner_name: str) -> str:
    """Create and chdir into ~/.sidekick/<runner_name>/workspace. Returns the path."""
    safe_name = _sanitize_name(runner_name)
    workspace = pathlib.Path.home() / ".sidekick" / safe_name / "workspace"
    workspace.mkdir(parents=True, exist_ok=True)
    os.chdir(workspace)
    return str(workspace)


async def run(
    url: str,
    token: str,
    name: str | None = None,
    workspace: str | None = None,
    display=None,
    allow_insecure: bool = False,
):
    """Main runner loop."""
    import websockets

    from .api_client import RuntimeAPIClient
    from .runtime import AgentRuntime

    api = RuntimeAPIClient(base_url=url, token=token, timeout=600.0)
    runtime = AgentRuntime(api=api, display=display)

    # If --workspace was provided, set it up immediately (skip WS-based setup)
    workspace_override = False
    if workspace:
        ws_path = pathlib.Path(workspace).expanduser().resolve()
        ws_path.mkdir(parents=True, exist_ok=True)
        os.chdir(ws_path)
        runtime._workspace = str(ws_path)
        workspace_override = True
        logger.info(f"Working directory (override): {ws_path}")

    # SEC-06: Block unencrypted HTTP to non-localhost unless explicitly allowed
    parsed = urlparse(url)
    if parsed.scheme == "http" and parsed.hostname not in ("localhost", "127.0.0.1", "::1"):
        if not allow_insecure:
            raise SystemExit(
                f"Refusing to connect over unencrypted HTTP to {parsed.hostname}. "
                "Your token would be transmitted in plaintext. "
                "Use HTTPS or pass --allow-insecure to override."
            )
        logger.warning(
            "WARNING: Connecting over unencrypted HTTP to %s (--allow-insecure). "
            "Token will be transmitted in plaintext.",
            parsed.hostname,
        )

    ws_url = url.replace("https://", "wss://").replace("http://", "ws://")
    ws_endpoint = f"{ws_url}/api/runtime/v1/ws"

    display_name = name or socket.gethostname()
    logger.info(f"Runner '{display_name}' connecting to Sidekick: {url}")

    if display:
        display.on_connecting(url, display_name)

    reconnect_delay = 1.0
    max_reconnect_delay = 30.0

    async with display if display else _nullcontext():
        while True:
            try:
                async with websockets.connect(
                    ws_endpoint,
                    additional_headers={"Authorization": f"Bearer {token}"},
                    max_size=1 * 1024 * 1024,  # 1MB max message size (SEC-12)
                ) as ws:
                    logger.info("Connected to Sidekick WebSocket")
                    reconnect_delay = 1.0  # Reset on successful connect

                    # Wait for `connected` message from backend to get authoritative runner name
                    runner_name = display_name
                    deferred_msg: dict | None = None
                    if not workspace_override:
                        try:
                            raw = await asyncio.wait_for(ws.recv(), timeout=10.0)
                            msg = json.loads(raw)
                            if msg.get("type") == "connected":
                                runner_name = msg.get("runner_name", display_name)
                                runner_id = msg.get("runner_id", "")
                                logger.info(f"Registered as '{runner_name}' (id={runner_id})")
                                if display:
                                    display.on_connected(runner_name, str(runner_id))
                            else:
                                # Not a connected message — old backend; process it after setup
                                logger.debug("No connected message received, using fallback name")
                                deferred_msg = msg
                        except asyncio.TimeoutError:
                            logger.debug("Timed out waiting for connected message, using fallback name")

                        ws_path = _setup_workspace(runner_name)
                        runtime._workspace = ws_path
                        logger.info(f"Working directory: {ws_path}")
                        if display:
                            display.on_workspace_set(ws_path)

                    # Send machine info on connect
                    machine_info = _get_machine_info(name)
                    machine_info["workspace"] = str(pathlib.Path.cwd())
                    await ws.send(json.dumps({
                        "type": "machine_info",
                        **machine_info,
                    }))

                    # Start ping task
                    ping_task = asyncio.create_task(_ping_loop(ws))

                    # Track active turn tasks for cleanup on disconnect
                    active_turns: dict[str, asyncio.Task] = {}

                    async def _run_turn_task(conv_id: str, n_id: str, r_name: str):
                        try:
                            await runtime.run_turn(conv_id, n_id, r_name)
                        except Exception as e:
                            logger.error(f"Turn execution failed: {type(e).__name__}: {e}")
                            logger.debug("Turn execution traceback:", exc_info=True)
                            if display:
                                display.on_turn_failed(str(e))
                        finally:
                            active_turns.pop(conv_id, None)

                    def _handle_msg(msg: dict) -> None:
                        """Dispatch a single WS message."""
                        msg_type = msg.get("type")

                        if msg_type == "new_turn":
                            conversation_id = msg["conversation_id"]
                            node_id = msg["node_id"]
                            ref_name = msg.get("ref_name", "main")

                            logger.info(
                                f"New turn: conversation={conversation_id}, node={node_id}"
                            )

                            task = asyncio.create_task(
                                _run_turn_task(conversation_id, node_id, ref_name)
                            )
                            active_turns[conversation_id] = task

                        elif msg_type == "cancel":
                            turn_id = msg.get("turn_id")
                            logger.info(f"Cancel requested: turn={turn_id}")

                        elif msg_type == "pong":
                            pass

                        else:
                            logger.debug(f"Unknown message type: {msg_type}")

                    try:
                        # Process any message consumed during connected-wait
                        if deferred_msg is not None:
                            _handle_msg(deferred_msg)

                        async for raw_msg in ws:
                            msg = json.loads(raw_msg)
                            _handle_msg(msg)

                    finally:
                        # Cancel any in-flight turns on disconnect
                        for task in active_turns.values():
                            task.cancel()
                        if active_turns:
                            await asyncio.gather(*active_turns.values(), return_exceptions=True)
                        active_turns.clear()

                        ping_task.cancel()
                        try:
                            await ping_task
                        except asyncio.CancelledError:
                            pass

            except asyncio.CancelledError:
                logger.info("Runner cancelled, shutting down")
                if display:
                    display.on_shutdown()
                break

            except Exception as e:
                error_msg = str(e)
                if "403" in error_msg:
                    logger.error(
                        "WebSocket connection rejected (HTTP 403): invalid or expired runner token. "
                        "Check the token in the Sidekick admin UI under Runners."
                    )
                    if display:
                        display.on_disconnected(
                            "Invalid runner token (403). Check token in admin UI.",
                            reconnect_delay,
                        )
                else:
                    logger.warning(
                        f"WebSocket connection lost: {e}. Reconnecting in {reconnect_delay}s..."
                    )
                    if display:
                        display.on_disconnected(error_msg, reconnect_delay)
                await asyncio.sleep(reconnect_delay)
                reconnect_delay = min(reconnect_delay * 2, max_reconnect_delay)

    await api.close()
    logger.info("Runner stopped")


async def _ping_loop(ws):
    """Send periodic pings to keep the connection alive."""
    try:
        while True:
            await asyncio.sleep(30)
            await ws.send(json.dumps({"type": "ping"}))
    except asyncio.CancelledError:
        pass
    except Exception:
        pass


