"""
Interactive chat mode for Sidekick Agent Runtime.

Usage: sidekick chat --url https://sidekick.example.com
"""

from __future__ import annotations

import logging
import os
import pathlib
from typing import Optional

from .api_client import RuntimeAPIClient
from .auth import browser_auth
from .chat_display import ChatDisplay
from .runner import _setup_workspace
from .runtime import AgentRuntime

logger = logging.getLogger("agent_runtime.chat")


async def run_chat(
    url: str,
    agent_name: str | None = None,
    conversation_id: str | None = None,
    token: str | None = None,
    workspace: str | None = None,
    allow_insecure: bool = False,
    runner_id: str | None = None,
) -> None:
    """Run the interactive chat REPL.

    Args:
        url: Sidekick backend URL.
        agent_name: Agent name to use (skips picker if provided).
        conversation_id: Resume an existing conversation.
        token: CLI token for headless auth (skips browser flow).
        workspace: Override working directory (default: ~/.sidekick/<agent-name>/workspace).
        allow_insecure: Allow unencrypted HTTP to non-localhost backends.
        runner_id: Self-hosted runner ID to route the conversation to.
    """
    from urllib.parse import urlparse

    # SEC-06: Block unencrypted HTTP to non-localhost unless explicitly allowed
    parsed = urlparse(url)
    if parsed.scheme == "http" and parsed.hostname not in ("localhost", "127.0.0.1", "::1"):
        if not allow_insecure:
            raise SystemExit(
                f"Refusing to connect over unencrypted HTTP to {parsed.hostname}. "
                "Your token would be transmitted in plaintext. "
                "Use HTTPS or pass --allow-insecure to override."
            )
        logger.warning(
            "WARNING: Connecting over unencrypted HTTP to %s (--allow-insecure). "
            "Token will be transmitted in plaintext.",
            parsed.hostname,
        )

    display = ChatDisplay()
    display.print_banner(url)

    # 1. Authenticate — browser_auth returns {token, api_url}
    api_url = url  # fallback: treat --url as backend URL (e.g. with --token)
    if not token:
        display.show_info("Authenticating via browser...")
        try:
            credentials = await browser_auth(url)
            token = credentials["token"]
            if credentials.get("api_url"):
                api_url = credentials["api_url"]
        except Exception as e:
            display.show_error(f"Authentication failed: {e}")
            return
    display.show_info("Authenticated.")

    # 2. Set up API client and runtime (api_url is the backend)
    api = RuntimeAPIClient(base_url=api_url, token=token)
    runtime = AgentRuntime(api=api)

    try:
        # 3. Select agent
        agent = await _select_agent(api, display, agent_name)
        if agent is None:
            return

        agent_id = agent["id"]
        selected_agent_name = agent.get("name", "Unknown")

        # 3b. Set up workspace directory
        if workspace:
            ws_path = pathlib.Path(workspace).expanduser().resolve()
            ws_path.mkdir(parents=True, exist_ok=True)
            os.chdir(ws_path)
            logger.info(f"Working directory (override): {ws_path}")
        else:
            ws_path = _setup_workspace(selected_agent_name)
            logger.info(f"Working directory: {ws_path}")

        # SEC-10: thread explicit workspace to tool executors
        runtime._workspace = str(ws_path)

        # 4. Create or resume conversation
        if conversation_id:
            ref_name = "main"
            display.print_agent_selected(selected_agent_name, conversation_id)
        else:
            conv = await api.create_conversation(agent_id, runner_id=runner_id)
            conversation_id = conv["conversation_id"]
            ref_name = conv.get("ref_name", "main")
            display.print_agent_selected(selected_agent_name, conversation_id)

        # 5. REPL loop
        while True:
            user_input = display.get_user_input()
            if user_input is None:
                break

            try:
                # Send user message
                msg = await api.send_message(conversation_id, user_input, ref_name)
                node_id = msg["node_id"]
                ref_name = msg.get("ref_name", ref_name)

                # Begin streaming response
                display.begin_assistant_response()

                # Run the agent turn with streaming callback
                await runtime.run_turn(
                    conversation_id,
                    node_id,
                    ref_name,
                    on_delta=display.stream_token,
                )

                display.end_assistant_response()

            except KeyboardInterrupt:
                display.end_assistant_response()
                display.show_info("Interrupted.")
                continue
            except Exception as e:
                display.end_assistant_response()
                display.show_error(str(e))
                logger.exception("Error during turn")

    finally:
        await api.close()

    display.show_goodbye()


async def _select_agent(
    api: RuntimeAPIClient,
    display: ChatDisplay,
    agent_name: Optional[str],
) -> Optional[dict]:
    """Pick an agent — by name flag or interactive chooser."""
    try:
        agents = await api.list_agents()
    except Exception as e:
        display.show_error(f"Failed to list agents: {e}")
        return None

    if not agents:
        display.show_error("No agents available.")
        return None

    # If --agent flag was provided, match by name
    if agent_name:
        for a in agents:
            if a.get("name", "").lower() == agent_name.lower():
                return a
        display.show_error(f"Agent '{agent_name}' not found.")
        return None

    # Single agent — auto-select
    if len(agents) == 1:
        return agents[0]

    # Multiple agents — interactive picker
    return display.prompt_agent_choice(agents)
