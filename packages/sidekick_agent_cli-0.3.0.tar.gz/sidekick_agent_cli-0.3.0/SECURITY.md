# Security Policy

## Reporting Vulnerabilities

If you discover a security vulnerability in the Sidekick Agent Runtime, please report it responsibly:

- **Email**: security@datexlabs.com
- **Subject prefix**: `[sidekick-agent-runtime]`

Please include:
1. A description of the vulnerability
2. Steps to reproduce
3. Potential impact
4. Suggested fix (if any)

We will acknowledge receipt within 48 hours and aim to provide a fix or mitigation within 7 days for critical issues.

## Scope

The following are in scope for security reports:

- Authentication bypass or token leakage
- Arbitrary code execution beyond intended tool boundaries
- Credential exposure via logs, environment, or filesystem
- Man-in-the-middle vulnerabilities
- Privilege escalation

The following are **out of scope** (intentional design decisions):

- **Package auto-install via `uvx`** (SEC-01): CLI tools are installed on demand. This is by design — the runtime trusts the connected Sidekick backend to provide valid tool definitions.
- **Filesystem access** (SEC-03): Local tools (ReadFile, WriteFile, ListFiles, RunCommand) have full filesystem access within the runtime's working directory. Sandboxing is the responsibility of the deployment environment (VM, container, etc.).

## Trust Model

The Sidekick Agent Runtime operates under a **trusted server** model:

1. **The runtime trusts the Sidekick backend it connects to.** It executes commands, installs packages, and accesses files as directed by the backend. Only connect to Sidekick instances you trust.

2. **The backend authenticates the runtime** via runner tokens (for `serve` mode) or CLI tokens (for `chat` mode). Tokens are cached locally in `~/.sidekick/credentials.json` with `0600` permissions.

3. **Transport security**: By default, the runtime refuses unencrypted HTTP connections to non-localhost backends. Use `--allow-insecure` to override (not recommended for production).

4. **Environment isolation**: Sensitive environment variables (credentials, proxy settings, path manipulation) are stripped from CLI tool subprocesses by default. Use `--allow-env-passthrough` to override.
