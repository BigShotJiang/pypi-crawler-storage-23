---
name: Feature request
about: Suggest an improvement
title: "[feature]"
labels: enhancement
assignees: ''
---

**Problem / use case**
What’s hard or missing today?

**Proposed solution**
What would you like to see?

**Additional context**
Examples, references, or alternatives (optional).
