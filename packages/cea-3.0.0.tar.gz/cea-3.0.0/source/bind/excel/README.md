The Excel interface is not currently supported or distributed. This folder
contains experimental artifacts and is a priority upgrade area. Contributions
and feedback are welcome.
