To compile the docs in html format run the following command in this directory:

  make html BUILDDIR=.

The docs can then be viewed by opening the `index.html` file:

  open ./html/index.html