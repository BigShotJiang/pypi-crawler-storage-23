from lobsterdata.client import LobsterClient

__all__ = ["LobsterClient"]


def main() -> None:
    print("Hello from lobsterdata!")
