"""
QTI Transport Layer

HTTP transport for QTI API communication.
Uses page-based pagination (page/limit/total/pages in response body).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from timeback_common import BaseTransport, QtiPaths, TokenManager

if TYPE_CHECKING:
    import httpx


@dataclass
class PaginatedResponse:
    """Normalized paginated response."""

    data: dict[str, Any]
    has_more: bool
    total: int | None = None


class Transport(BaseTransport):
    """HTTP transport layer for QTI API communication."""

    def __init__(
        self,
        *,
        base_url: str,
        token_manager: TokenManager | None = None,
        paths: QtiPaths,
        timeout: float = 30.0,
        http_client: httpx.AsyncClient | None = None,
        no_auth: bool = False,
    ) -> None:
        super().__init__(
            base_url=base_url,
            timeout=timeout,
            token_manager=token_manager,
            http_client=http_client,
            no_auth=no_auth,
        )
        self.paths = paths

    async def request_paginated(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> PaginatedResponse:
        """
        Make a paginated request using QTI's page-based pagination format.

        QTI list endpoints return pagination metadata in the response body:
        - total: Total items across all pages
        - page: Current page number (1-indexed)
        - pages: Total number of pages
        - limit: Items per page
        - sort: Sort field
        - order: Sort order (asc/desc)
        """
        body = await self.get(path, params=params)

        total: int | None = None
        raw_total = body.get("total")
        if isinstance(raw_total, int):
            total = raw_total

        pages: int | None = None
        raw_pages = body.get("pages")
        if isinstance(raw_pages, int):
            pages = raw_pages

        page: int | None = None
        raw_page = body.get("page")
        if isinstance(raw_page, int):
            page = raw_page

        has_more = False
        if pages is not None and page is not None:
            has_more = page < pages

        return PaginatedResponse(data=body, has_more=has_more, total=total)


__all__ = ["PaginatedResponse", "Transport"]
