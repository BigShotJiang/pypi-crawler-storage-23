"""QTI API resources."""
