"""
QTI Exceptions

Re-exports common errors and adds QTI-specific exceptions.
"""

from timeback_common import (
    APIError,
    AuthenticationError,
    ForbiddenError,
    InputValidationError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimebackError,
    ValidationError,
    ValidationIssue,
    create_input_validation_error,
)

QtiError = TimebackError


__all__ = [
    "APIError",
    "AuthenticationError",
    "ForbiddenError",
    "InputValidationError",
    "NotFoundError",
    "QtiError",
    "RateLimitError",
    "ServerError",
    "TimebackError",
    "ValidationError",
    "ValidationIssue",
    "create_input_validation_error",
]
