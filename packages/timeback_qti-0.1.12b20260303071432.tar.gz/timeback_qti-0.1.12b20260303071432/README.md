# timeback-qti

Python client for the Timeback QTI assessment API.

## Installation

```bash
pip install timeback-qti
```

## Quick Start

```python
from timeback_qti import QtiClient

async def main():
    client = QtiClient(
        env="staging",
        client_id="your-client-id",
        client_secret="your-client-secret",
    )

    # List assessment items
    result = await client.assessment_items.list()

    # Create an item from QTI XML
    item = await client.assessment_items.create_from_xml({
        "format": "xml",
        "xml": "<qti-assessment-item>...</qti-assessment-item>",
    })

    # Validate QTI XML
    validation = await client.validate.validate({
        "schema": "item",
        "xml": "<qti-assessment-item>...</qti-assessment-item>",
    })

    await client.close()
```

## Resources

- `client.assessment_items` - Assessment item CRUD, XML/metadata creation, response processing
- `client.assessment_tests` - Assessment test CRUD with nested test parts, sections, and items
- `client.stimuli` - Stimulus material CRUD
- `client.validate` - QTI XML validation (single and batch)
- `client.lesson` - Lesson and question feedback
- `client.general` - General operations (delete by ID)
