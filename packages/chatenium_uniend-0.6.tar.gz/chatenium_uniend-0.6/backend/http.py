from dataclasses import dataclass, is_dataclass, fields
from typing import Generic, TypeVar, Optional
from enum import Enum
from .environments import Environments
from backend.session_manager import SessionManager
import aiohttp
import json

T = TypeVar("T")
S = TypeVar("S")
E = TypeVar("E")


class ResultType(Enum):
    SUCCESS = "success"
    ERROR = "error"


class HttpMethod(Enum):
    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    DELETE = "DELETE"
    PATCH = "PATCH"


@dataclass
class GenericErrorBody:
    error: str


@dataclass
class GenericSuccessBody:
    response: str


@dataclass
class Result(Generic[S, E]):
    type: ResultType
    success: S = None
    error: E = None

    @classmethod
    def ok(cls, value: S) -> "Result[S, E]":
        return cls(type=ResultType.SUCCESS, success=value)

    @classmethod
    def fail(cls, value: E) -> "Result[S, E]":
        return cls(type=ResultType.ERROR, error=value)


def from_dict(cls: type, data: dict):
    """
    Recursively convert a dict into a dataclass because Py does not do that automatically for some reason
    """
    if not is_dataclass(cls):
        return data

    init_kwargs = {}
    for f in fields(cls):
        value = data.get(f.name)
        if value is None:
            init_kwargs[f.name] = None
            continue

        if is_dataclass(f.type):
            init_kwargs[f.name] = from_dict(f.type, value)
        elif getattr(f.type, "__origin__", None) is list:
            sub_type = f.type.__args__[0]
            if is_dataclass(sub_type):
                init_kwargs[f.name] = [from_dict(sub_type, item) for item in value]
            else:
                init_kwargs[f.name] = value
        else:
            init_kwargs[f.name] = value

    return cls(**init_kwargs)


async def Http(method: HttpMethod, path: str, data: Optional[T], successType: type(S) = GenericSuccessBody,
               errorType: type(E) = GenericErrorBody, cdn_req=False) -> Result[S, E]:
    from backend.websocket import WebSocket  # Prevent circular-import error

    headers: dict[str, str] = {}

    session = SessionManager.instance().currentSession
    if session is not None:
        token = session[0]
        if token is not None:
            headers["Authorization"] = str(token)

    if WebSocket.connectionId is not None:
        headers["X-WS-ID"] = WebSocket.connectionId

    async with aiohttp.ClientSession(headers=headers) as session:
        server_url = Environments.instance().api_url
        if cdn_req:
            server_url = Environments.instance().cdn_url

        todo = session.get(f"{server_url}/{path}")

        if method == HttpMethod.POST:
            todo = session.post(f"{server_url}/{path}", data=json.dumps(data))

        if method == HttpMethod.PATCH:
            todo = session.patch(f"{server_url}/{path}", data=json.dumps(data))

        async with todo as resp:
            body = await resp.json()

            if 200 <= resp.status < 300:
                if isinstance(body, list):
                    result = [from_dict(successType, item) for item in body]
                    return Result.ok(result)
                else:
                    return Result.ok(from_dict(successType, body))
            else:
                return Result.fail(from_dict(errorType, body))
