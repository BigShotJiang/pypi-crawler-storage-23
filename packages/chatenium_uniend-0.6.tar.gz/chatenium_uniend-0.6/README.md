A python backend library to unify API communications across all Chatenium On Linux variants.
