# eCTF Tools

## Setup
[uv](https://docs.astral.sh/uv/) is required to run the tools

Once installed, you can run the eCTF tools with:

```commandline
uvx run ectf --help
```

See https://rules.ectf.mitre.org/2026/system/ectf_tools.html
for full tool documentation