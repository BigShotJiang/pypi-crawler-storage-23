"""Interact with the eCTF hardware"""
