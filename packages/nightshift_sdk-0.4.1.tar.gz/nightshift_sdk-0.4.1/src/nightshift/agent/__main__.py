"""Allow running as `python -m nightshift.agent`."""

from nightshift.agent.entry import main

main()
