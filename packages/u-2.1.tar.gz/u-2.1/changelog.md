# 2.1

- `Quantity.to_number` now raises `ValueError` if an incompatible unit is passed

# 2.0

- Removed `.unit` attribute of `Quantity` objects
- Renamed `ton` to `tonne`
