# threshold-mcp

MCP server that exposes the [Threshold API](https://api.threshold-immigration.com) as tools for LLMs. Provides programmatic access to H-1B prevailing wage data, SOC codes, employer intelligence, and geographic optimization.

## Install

Requires Python 3.11+.

```bash
pip install threshold-mcp
```

## Quick Start

Set your API key and start the server:

```bash
export THRESHOLD_API_KEY=your_key_here
threshold-mcp
```

### Claude Desktop

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "threshold": {
      "command": "threshold-mcp",
      "env": {
        "THRESHOLD_API_KEY": "your_key_here"
      }
    }
  }
}
```

## Tools

### Wages

| Tool | Description |
|------|-------------|
| `lookup_prevailing_wage` | Get prevailing wage data for a SOC code and location (ZIP, CBSA, or city+state) |
| `calculate_wage_level` | Calculate the wage level for a given SOC code, location, and offered wage |

### SOC Codes

| Tool | Description |
|------|-------------|
| `search_soc_codes` | Search for SOC codes by job title or keyword |
| `get_soc_details` | Get full details for a SOC code including description and LCA filing statistics |

### Employers

| Tool | Description |
|------|-------------|
| `search_employers` | Search for H-1B sponsor employers by name |
| `get_employer_profile` | Get a detailed employer profile with filing history and wage stats |

### Intelligence (Pro)

| Tool | Description |
|------|-------------|
| `optimize_geography` | Find metro areas where a wage qualifies for the best H-1B lottery advantage |
| `analyze_classification` | Find alternative SOC classifications with wage and lottery implications |
| `get_employer_intelligence` | Comprehensive H-1B program analysis for a specific employer |

## Configuration

| Environment Variable | Default | Description |
|---------------------|---------|-------------|
| `THRESHOLD_API_KEY` | (required) | API key for authentication |
| `THRESHOLD_API_URL` | `https://api.threshold-immigration.com` | API base URL |

## Development

```bash
pip install -e ".[dev]"

pytest                    # Run tests
ruff check src/ tests/    # Lint
ruff format src/ tests/   # Format
mypy src/                 # Type check
```
