# CLAUDE.md — threshold-mcp

## What This Is

MCP (Model Context Protocol) server that exposes Threshold API intelligence as tools for LLMs. Thin HTTP client layer — all logic, auth, rate limiting, and billing lives in the API.

## Development

```bash
# Install in dev mode
pip install -e ".[dev]"

# Run the server locally (stdio)
threshold-mcp

# Run tests
pytest

# Lint + format
ruff check src/ tests/
ruff format src/ tests/

# Type check
mypy src/
```

## Architecture

- `src/threshold_mcp/server.py` — MCP server setup and entry point
- `src/threshold_mcp/client.py` — Async httpx client for the Threshold API
- `src/threshold_mcp/tools/` — One module per tool group (wages, soc, employers, etc.)

## Key Decisions

- **API key passthrough**: Users set `THRESHOLD_API_KEY` env var. No auth logic here.
- **stdio transport**: Local-first. SSE transport is a future option.
- **Tool registration**: Each tool module has a `register_*_tools(server, get_client)` function.
- **Location flexibility**: Tools accept ZIP, CBSA, or "City, State" — the API resolves it.

## Testing

Tests use `respx` to mock HTTP calls. No real API calls in tests.

```bash
pytest                  # All tests
pytest -x              # Stop on first failure
pytest tests/test_client.py  # Specific file
```
