"""Shared test fixtures."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest


@pytest.fixture(autouse=True)
def _no_retry_sleep() -> object:  # type: ignore[misc]
    """Patch asyncio.sleep in the client module so retries are instant."""
    with patch("threshold_mcp.client.asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
        yield mock_sleep
