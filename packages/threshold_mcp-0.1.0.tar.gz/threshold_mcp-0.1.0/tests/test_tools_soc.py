"""Tests for SOC tools."""

from __future__ import annotations

import json

import httpx
import pytest
import respx

from threshold_mcp.client import ThresholdClient
from threshold_mcp.tools.soc import handle_tool

BASE = "https://api.threshold-immigration.com"


def make_client() -> ThresholdClient:
    return ThresholdClient(api_key="test-key")


@respx.mock
@pytest.mark.asyncio
async def test_search_soc_codes() -> None:
    payload = [
        {"code": "15-1252", "title": "Software Developers"},
        {"code": "15-1256", "title": "Software Developers and Programmers, All Other"},
    ]
    respx.get(f"{BASE}/api/v1/soc/search").mock(return_value=httpx.Response(200, json=payload))

    result = await handle_tool(
        "search_soc_codes",
        {"query": "software developer"},
        make_client,
    )

    assert len(result) == 1
    assert json.loads(result[0].text) == payload


@respx.mock
@pytest.mark.asyncio
async def test_search_soc_codes_uses_q_param() -> None:
    route = respx.get(f"{BASE}/api/v1/soc/search").mock(return_value=httpx.Response(200, json=[]))

    await handle_tool(
        "search_soc_codes",
        {"query": "data scientist"},
        make_client,
    )

    params = route.calls[0].request.url.params
    assert params["q"] == "data scientist"
    assert "query" not in params


@respx.mock
@pytest.mark.asyncio
async def test_get_soc_details() -> None:
    payload = {
        "soc_code": "15-1252",
        "title": "Software Developers",
        "description": "Research, design, and develop...",
        "major_group": {"code": "15", "title": "Computer and Mathematical Occupations"},
        "lca_statistics": {"total_filings": 1332167},
    }
    route = respx.get(f"{BASE}/api/v1/soc/15-1252").mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = await handle_tool("get_soc_details", {"soc_code": "15-1252"}, make_client)

    assert json.loads(result[0].text) == payload
    assert route.calls[0].request.url.path == "/api/v1/soc/15-1252"


@pytest.mark.asyncio
async def test_unknown_tool_raises() -> None:
    with pytest.raises(ValueError, match="Unknown SOC tool"):
        await handle_tool("nonexistent", {}, make_client)
