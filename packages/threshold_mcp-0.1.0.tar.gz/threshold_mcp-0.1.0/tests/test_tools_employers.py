"""Tests for employer tools."""

from __future__ import annotations

import json

import httpx
import pytest
import respx

from threshold_mcp.client import ThresholdClient
from threshold_mcp.tools.employers import handle_tool

BASE = "https://api.threshold-immigration.com"


def make_client() -> ThresholdClient:
    return ThresholdClient(api_key="test-key")


# --- search_employers ---


@respx.mock
@pytest.mark.asyncio
async def test_search_employers_basic() -> None:
    payload = {"results": [{"name": "Acme Corp", "filings": 42}]}
    route = respx.get(f"{BASE}/api/v1/employers/search").mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = await handle_tool("search_employers", {"q": "Acme"}, make_client)

    assert json.loads(result[0].text) == payload
    params = route.calls[0].request.url.params
    assert params["q"] == "Acme"
    assert "limit" not in params
    assert "offset" not in params


@respx.mock
@pytest.mark.asyncio
async def test_search_employers_all_params() -> None:
    route = respx.get(f"{BASE}/api/v1/employers/search").mock(
        return_value=httpx.Response(200, json={"results": []})
    )

    await handle_tool(
        "search_employers",
        {"q": "Google", "limit": 10, "offset": 20, "min_filings": 5, "state": "CA"},
        make_client,
    )

    params = route.calls[0].request.url.params
    assert params["q"] == "Google"
    assert params["limit"] == "10"
    assert params["offset"] == "20"
    assert params["min_filings"] == "5"
    assert params["state"] == "CA"


@respx.mock
@pytest.mark.asyncio
async def test_search_employers_ignores_none_optionals() -> None:
    route = respx.get(f"{BASE}/api/v1/employers/search").mock(
        return_value=httpx.Response(200, json={"results": []})
    )

    await handle_tool(
        "search_employers",
        {"q": "Meta", "limit": None, "state": None},
        make_client,
    )

    params = route.calls[0].request.url.params
    assert params["q"] == "Meta"
    assert "limit" not in params
    assert "state" not in params


# --- get_employer_profile ---


@respx.mock
@pytest.mark.asyncio
async def test_get_employer_profile_basic() -> None:
    payload = {"name": "Acme Corp", "fein": "00-1234567", "total_filings": 42}
    route = respx.get(f"{BASE}/api/v1/employers/12345").mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = await handle_tool(
        "get_employer_profile",
        {"employer_identifier": "12345"},
        make_client,
    )

    assert json.loads(result[0].text) == payload
    assert "include_filings" not in str(route.calls[0].request.url)


@respx.mock
@pytest.mark.asyncio
async def test_get_employer_profile_with_filings() -> None:
    payload = {"name": "Acme Corp", "filings": [{"case": "I-200-12345"}]}
    route = respx.get(f"{BASE}/api/v1/employers/00-1234567").mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = await handle_tool(
        "get_employer_profile",
        {"employer_identifier": "00-1234567", "include_filings": True, "filings_limit": 100},
        make_client,
    )

    assert json.loads(result[0].text) == payload
    params = route.calls[0].request.url.params
    assert params["include_filings"] == "true"
    assert params["filings_limit"] == "100"


# --- error handling ---


@pytest.mark.asyncio
async def test_unknown_tool_raises() -> None:
    with pytest.raises(ValueError, match="Unknown employer tool"):
        await handle_tool("nonexistent", {}, make_client)
