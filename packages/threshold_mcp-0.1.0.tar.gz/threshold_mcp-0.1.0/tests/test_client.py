"""Tests for the Threshold API client."""

from __future__ import annotations

import httpx
import pytest
import respx

from threshold_mcp.client import ThresholdClient


@respx.mock
@pytest.mark.asyncio
async def test_get_request() -> None:
    respx.get("https://api.threshold-immigration.com/api/v1/health").mock(
        return_value=httpx.Response(200, json={"status": "ok"})
    )

    async with ThresholdClient(api_key="test-key") as client:
        result = await client.get("/api/v1/health")
        assert result == {"status": "ok"}


@respx.mock
@pytest.mark.asyncio
async def test_api_key_header() -> None:
    route = respx.get("https://api.threshold-immigration.com/api/v1/test").mock(
        return_value=httpx.Response(200, json={})
    )

    async with ThresholdClient(api_key="my-secret-key") as client:
        await client.get("/api/v1/test")

    assert route.calls[0].request.headers["X-API-Key"] == "my-secret-key"
