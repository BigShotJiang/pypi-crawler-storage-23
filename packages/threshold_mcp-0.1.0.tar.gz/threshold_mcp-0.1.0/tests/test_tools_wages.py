"""Tests for wage tools."""

from __future__ import annotations

import json

import httpx
import pytest
import respx

from threshold_mcp.client import ThresholdClient
from threshold_mcp.tools.wages import _location_params, handle_tool

BASE = "https://api.threshold-immigration.com"


def make_client() -> ThresholdClient:
    return ThresholdClient(api_key="test-key")


# --- _location_params ---


def test_location_params_zip() -> None:
    assert _location_params({"zip": "94105", "soc_code": "15-1252"}) == {"zip": "94105"}


def test_location_params_cbsa() -> None:
    assert _location_params({"cbsa": "41860"}) == {"cbsa": "41860"}


def test_location_params_city_state() -> None:
    assert _location_params({"city": "San Francisco", "state": "CA"}) == {
        "city": "San Francisco",
        "state": "CA",
    }


def test_location_params_ignores_empty() -> None:
    assert _location_params({"zip": "", "cbsa": "41860"}) == {"cbsa": "41860"}


# --- lookup_prevailing_wage ---


@respx.mock
@pytest.mark.asyncio
async def test_lookup_prevailing_wage_zip() -> None:
    payload = {"soc_code": "15-1252", "wages": {"level_1": 120000}}
    route = respx.get(f"{BASE}/api/v1/wages/prevailing").mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = await handle_tool(
        "lookup_prevailing_wage",
        {"soc_code": "15-1252", "zip": "94105"},
        make_client,
    )

    assert json.loads(result[0].text) == payload
    params = route.calls[0].request.url.params
    assert params["soc_code"] == "15-1252"
    assert params["zip"] == "94105"


@respx.mock
@pytest.mark.asyncio
async def test_lookup_prevailing_wage_city_state() -> None:
    route = respx.get(f"{BASE}/api/v1/wages/prevailing").mock(
        return_value=httpx.Response(200, json={})
    )

    await handle_tool(
        "lookup_prevailing_wage",
        {"soc_code": "15-1252", "city": "San Francisco", "state": "CA"},
        make_client,
    )

    params = route.calls[0].request.url.params
    assert params["city"] == "San Francisco"
    assert params["state"] == "CA"


# --- calculate_wage_level ---


@respx.mock
@pytest.mark.asyncio
async def test_calculate_wage_level() -> None:
    payload = {"wage_level": 2, "percentile": 62}
    route = respx.get(f"{BASE}/api/v1/wages/level").mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = await handle_tool(
        "calculate_wage_level",
        {"soc_code": "15-1252", "zip": "94105", "salary": 150000},
        make_client,
    )

    assert json.loads(result[0].text) == payload
    params = route.calls[0].request.url.params
    assert params["soc_code"] == "15-1252"
    assert params["wage"] == "150000"
    assert params["zip"] == "94105"
    assert "salary" not in params


# --- error handling ---


@pytest.mark.asyncio
async def test_unknown_tool_raises() -> None:
    with pytest.raises(ValueError, match="Unknown wage tool"):
        await handle_tool("nonexistent", {}, make_client)
