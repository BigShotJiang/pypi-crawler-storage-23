"""Tests for server tool registration."""

from __future__ import annotations

import json

import httpx
import pytest
import respx

from threshold_mcp.server import call_tool, list_tools


@pytest.mark.asyncio
async def test_all_tools_listed() -> None:
    tools = await list_tools()
    names = {t.name for t in tools}
    assert names == {
        "lookup_prevailing_wage",
        "calculate_wage_level",
        "search_soc_codes",
        "get_soc_details",
        "search_employers",
        "get_employer_profile",
        "optimize_geography",
        "analyze_classification",
        "get_employer_intelligence",
    }


@pytest.mark.asyncio
async def test_unknown_tool_raises() -> None:
    with pytest.raises(ValueError, match="Unknown tool"):
        await call_tool("does_not_exist", {})


BASE = "https://api.threshold-immigration.com"


@respx.mock
@pytest.mark.asyncio
async def test_api_error_401_returns_friendly_message() -> None:
    respx.get(f"{BASE}/api/v1/soc/search").mock(
        return_value=httpx.Response(401, json={"detail": "Unauthorized"})
    )

    result = await call_tool("search_soc_codes", {"query": "software"})

    body = json.loads(result[0].text)
    assert body["error"] is True
    assert body["status_code"] == 401
    assert "API key" in body["message"]


@respx.mock
@pytest.mark.asyncio
async def test_api_error_429_returns_rate_limit_message() -> None:
    respx.get(f"{BASE}/api/v1/soc/search").mock(
        return_value=httpx.Response(429, json={"detail": "Too many requests"})
    )

    result = await call_tool("search_soc_codes", {"query": "software"})

    body = json.loads(result[0].text)
    assert body["error"] is True
    assert body["status_code"] == 429
    assert "Rate limit" in body["message"]


@respx.mock
@pytest.mark.asyncio
async def test_api_error_422_returns_detail() -> None:
    respx.get(f"{BASE}/api/v1/soc/search").mock(
        return_value=httpx.Response(422, json={"error": {"message": "Invalid SOC code format"}})
    )

    result = await call_tool("search_soc_codes", {"query": "software"})

    body = json.loads(result[0].text)
    assert body["error"] is True
    assert body["status_code"] == 422
    assert "Invalid SOC code" in body["message"]
