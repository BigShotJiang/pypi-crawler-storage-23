"""Tests for client retry logic."""

from __future__ import annotations

from unittest.mock import AsyncMock

import httpx
import pytest
import respx

from threshold_mcp.client import (
    _BACKOFF_BASE,
    _BACKOFF_FACTOR,
    ThresholdClient,
    _get_retry_delay,
)

BASE = "https://api.threshold-immigration.com"


@respx.mock
@pytest.mark.asyncio
async def test_retry_on_429_then_success() -> None:
    route = respx.get(f"{BASE}/api/v1/test").mock(
        side_effect=[
            httpx.Response(429, json={"detail": "rate limited"}),
            httpx.Response(200, json={"ok": True}),
        ]
    )

    async with ThresholdClient(api_key="k") as client:
        result = await client.get("/api/v1/test")

    assert result == {"ok": True}
    assert route.call_count == 2


@respx.mock
@pytest.mark.asyncio
async def test_retry_on_500_then_success() -> None:
    route = respx.get(f"{BASE}/api/v1/test").mock(
        side_effect=[
            httpx.Response(500, text="Internal Server Error"),
            httpx.Response(200, json={"ok": True}),
        ]
    )

    async with ThresholdClient(api_key="k") as client:
        result = await client.get("/api/v1/test")

    assert result == {"ok": True}
    assert route.call_count == 2


@respx.mock
@pytest.mark.asyncio
async def test_retry_through_multiple_failures() -> None:
    route = respx.get(f"{BASE}/api/v1/test").mock(
        side_effect=[
            httpx.Response(502, text="Bad Gateway"),
            httpx.Response(503, text="Service Unavailable"),
            httpx.Response(504, text="Gateway Timeout"),
            httpx.Response(200, json={"ok": True}),
        ]
    )

    async with ThresholdClient(api_key="k") as client:
        result = await client.get("/api/v1/test")

    assert result == {"ok": True}
    assert route.call_count == 4


@respx.mock
@pytest.mark.asyncio
async def test_retry_exhaustion_raises() -> None:
    respx.get(f"{BASE}/api/v1/test").mock(
        side_effect=[
            httpx.Response(500, text="fail"),
            httpx.Response(500, text="fail"),
            httpx.Response(500, text="fail"),
            httpx.Response(500, text="fail"),
        ]
    )

    async with ThresholdClient(api_key="k") as client:
        with pytest.raises(httpx.HTTPStatusError) as exc_info:
            await client.get("/api/v1/test")

    assert exc_info.value.response.status_code == 500


@respx.mock
@pytest.mark.asyncio
async def test_no_retry_on_401() -> None:
    route = respx.get(f"{BASE}/api/v1/test").mock(
        return_value=httpx.Response(401, json={"detail": "Unauthorized"})
    )

    async with ThresholdClient(api_key="k") as client:
        with pytest.raises(httpx.HTTPStatusError) as exc_info:
            await client.get("/api/v1/test")

    assert exc_info.value.response.status_code == 401
    assert route.call_count == 1


@respx.mock
@pytest.mark.asyncio
async def test_no_retry_on_404() -> None:
    route = respx.get(f"{BASE}/api/v1/test").mock(
        return_value=httpx.Response(404, json={"detail": "Not found"})
    )

    async with ThresholdClient(api_key="k") as client:
        with pytest.raises(httpx.HTTPStatusError) as exc_info:
            await client.get("/api/v1/test")

    assert exc_info.value.response.status_code == 404
    assert route.call_count == 1


@respx.mock
@pytest.mark.asyncio
async def test_retry_after_header_honored(_no_retry_sleep: AsyncMock) -> None:
    respx.get(f"{BASE}/api/v1/test").mock(
        side_effect=[
            httpx.Response(429, headers={"Retry-After": "5"}, json={}),
            httpx.Response(200, json={"ok": True}),
        ]
    )

    async with ThresholdClient(api_key="k") as client:
        result = await client.get("/api/v1/test")

    assert result == {"ok": True}
    _no_retry_sleep.assert_awaited_once_with(5.0)


# --- Unit tests for _get_retry_delay ---


def test_get_retry_delay_with_header() -> None:
    response = httpx.Response(429, headers={"Retry-After": "10"})
    assert _get_retry_delay(response, 0) == 10.0


def test_get_retry_delay_without_header() -> None:
    response = httpx.Response(500)
    assert _get_retry_delay(response, 0) == _BACKOFF_BASE * (_BACKOFF_FACTOR**0)
    assert _get_retry_delay(response, 1) == _BACKOFF_BASE * (_BACKOFF_FACTOR**1)
    assert _get_retry_delay(response, 2) == _BACKOFF_BASE * (_BACKOFF_FACTOR**2)


def test_get_retry_delay_invalid_header_falls_back() -> None:
    response = httpx.Response(429, headers={"Retry-After": "not-a-number"})
    assert _get_retry_delay(response, 1) == _BACKOFF_BASE * (_BACKOFF_FACTOR**1)
