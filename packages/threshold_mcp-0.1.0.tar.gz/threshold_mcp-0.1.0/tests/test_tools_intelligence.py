"""Tests for intelligence tools."""

from __future__ import annotations

import json

import httpx
import pytest
import respx

from threshold_mcp.client import ThresholdClient
from threshold_mcp.tools.intelligence import handle_tool

BASE = "https://api.threshold-immigration.com"


def make_client() -> ThresholdClient:
    return ThresholdClient(api_key="test-key")


# --- optimize_geography ---


@respx.mock
@pytest.mark.asyncio
async def test_optimize_geography_basic() -> None:
    payload = {"soc_code": "15-1252", "results": [{"area_name": "Austin"}]}
    route = respx.get(f"{BASE}/api/v1/intelligence/geographic-optimizer").mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = await handle_tool(
        "optimize_geography", {"soc_code": "15-1252", "wage": 160000}, make_client
    )

    assert json.loads(result[0].text) == payload
    params = route.calls[0].request.url.params
    assert params["soc_code"] == "15-1252"
    assert params["wage"] == "160000"
    assert "state" not in params
    assert "wage_source" not in params


@respx.mock
@pytest.mark.asyncio
async def test_optimize_geography_all_params() -> None:
    route = respx.get(f"{BASE}/api/v1/intelligence/geographic-optimizer").mock(
        return_value=httpx.Response(200, json={"results": []})
    )

    await handle_tool(
        "optimize_geography",
        {"soc_code": "15-1252", "wage": 160000, "state": "CA,TX", "wage_source": "acwia"},
        make_client,
    )

    params = route.calls[0].request.url.params
    assert params["soc_code"] == "15-1252"
    assert params["wage"] == "160000"
    assert params["state"] == "CA,TX"
    assert params["wage_source"] == "acwia"


@respx.mock
@pytest.mark.asyncio
async def test_optimize_geography_ignores_none_optionals() -> None:
    route = respx.get(f"{BASE}/api/v1/intelligence/geographic-optimizer").mock(
        return_value=httpx.Response(200, json={"results": []})
    )

    await handle_tool(
        "optimize_geography",
        {"soc_code": "15-1252", "wage": 150000, "state": None, "wage_source": None},
        make_client,
    )

    params = route.calls[0].request.url.params
    assert params["soc_code"] == "15-1252"
    assert params["wage"] == "150000"
    assert "state" not in params
    assert "wage_source" not in params


# --- analyze_classification ---


@respx.mock
@pytest.mark.asyncio
async def test_analyze_classification_by_soc() -> None:
    payload = {"primary": {"soc_code": "15-1252"}, "alternatives": []}
    route = respx.get(f"{BASE}/api/v1/intelligence/classification-analyzer").mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = await handle_tool("analyze_classification", {"soc_code": "15-1252"}, make_client)

    assert json.loads(result[0].text) == payload
    params = route.calls[0].request.url.params
    assert params["soc_code"] == "15-1252"
    assert "job_title" not in params


@respx.mock
@pytest.mark.asyncio
async def test_analyze_classification_all_params() -> None:
    route = respx.get(f"{BASE}/api/v1/intelligence/classification-analyzer").mock(
        return_value=httpx.Response(200, json={"primary": {}, "alternatives": []})
    )

    await handle_tool(
        "analyze_classification",
        {
            "soc_code": "15-1252",
            "job_title": "Software Engineer",
            "zip": "10001",
            "wage": 160000,
            "wage_source": "oews",
            "limit": 5,
        },
        make_client,
    )

    params = route.calls[0].request.url.params
    assert params["soc_code"] == "15-1252"
    assert params["job_title"] == "Software Engineer"
    assert params["zip"] == "10001"
    assert params["wage"] == "160000"
    assert params["wage_source"] == "oews"
    assert params["limit"] == "5"


@respx.mock
@pytest.mark.asyncio
async def test_analyze_classification_ignores_none_optionals() -> None:
    route = respx.get(f"{BASE}/api/v1/intelligence/classification-analyzer").mock(
        return_value=httpx.Response(200, json={"primary": {}, "alternatives": []})
    )

    await handle_tool(
        "analyze_classification",
        {"soc_code": "15-1252", "zip": None, "wage": None},
        make_client,
    )

    params = route.calls[0].request.url.params
    assert params["soc_code"] == "15-1252"
    assert "zip" not in params
    assert "wage" not in params


# --- get_employer_intelligence ---


@respx.mock
@pytest.mark.asyncio
async def test_get_employer_intelligence_by_name() -> None:
    payload = {"employer": {"name": "GOOGLE LLC"}, "program_health": {}}
    route = respx.get(f"{BASE}/api/v1/intelligence/employer-profile").mock(
        return_value=httpx.Response(200, json=payload)
    )

    result = await handle_tool("get_employer_intelligence", {"name": "Google"}, make_client)

    assert json.loads(result[0].text) == payload
    params = route.calls[0].request.url.params
    assert params["name"] == "Google"
    assert "fein" not in params


@respx.mock
@pytest.mark.asyncio
async def test_get_employer_intelligence_by_fein() -> None:
    route = respx.get(f"{BASE}/api/v1/intelligence/employer-profile").mock(
        return_value=httpx.Response(200, json={"employer": {}})
    )

    await handle_tool("get_employer_intelligence", {"fein": "77-0493581"}, make_client)

    params = route.calls[0].request.url.params
    assert params["fein"] == "77-0493581"
    assert "name" not in params


@respx.mock
@pytest.mark.asyncio
async def test_get_employer_intelligence_ignores_none_optionals() -> None:
    route = respx.get(f"{BASE}/api/v1/intelligence/employer-profile").mock(
        return_value=httpx.Response(200, json={"employer": {}})
    )

    await handle_tool("get_employer_intelligence", {"name": "Meta", "fein": None}, make_client)

    params = route.calls[0].request.url.params
    assert params["name"] == "Meta"
    assert "fein" not in params


# --- error handling ---


@pytest.mark.asyncio
async def test_unknown_tool_raises() -> None:
    with pytest.raises(ValueError, match="Unknown intelligence tool"):
        await handle_tool("nonexistent", {}, make_client)
