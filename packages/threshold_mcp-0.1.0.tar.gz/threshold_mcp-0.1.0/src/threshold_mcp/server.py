"""MCP server exposing Threshold API tools."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from threshold_mcp.client import ThresholdClient
from threshold_mcp.tools import employers, intelligence, soc, wages

logger = logging.getLogger(__name__)

server = Server("threshold-mcp")
client: ThresholdClient | None = None

# All tool modules — add new modules here.
_tool_modules = [wages, soc, employers, intelligence]


def get_client() -> ThresholdClient:
    global client
    if client is None:
        client = ThresholdClient()
    return client


@server.list_tools()  # type: ignore[no-untyped-call, untyped-decorator]
async def list_tools() -> list[Tool]:
    tools: list[Tool] = []
    for module in _tool_modules:
        tools.extend(module.TOOLS)
    return tools


_ERROR_MESSAGES: dict[int, str] = {
    401: "Invalid or missing API key. Set THRESHOLD_API_KEY.",
    403: "Access denied. Your plan may not include this endpoint.",
    404: "Resource not found. Check your parameters.",
    429: "Rate limit exceeded. Please slow down and retry.",
}


def _format_api_error(exc: httpx.HTTPStatusError) -> list[TextContent]:
    """Turn an HTTP error into a user-friendly MCP text response."""
    status = exc.response.status_code
    message = _ERROR_MESSAGES.get(status)
    if message is None:
        # Try to extract detail from JSON body
        try:
            body = exc.response.json()
            detail = body.get("error", {}).get("message", body.get("detail", ""))
        except Exception:
            detail = exc.response.text[:200]
        message = f"API error {status}: {detail}" if detail else f"API error {status}"
    error_payload = {"error": True, "status_code": status, "message": message}
    return [TextContent(type="text", text=json.dumps(error_payload, indent=2))]


@server.call_tool()  # type: ignore[untyped-decorator]
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    start = time.monotonic()
    logger.info("Tool call: %s", name)

    for module in _tool_modules:
        if name in module.TOOL_NAMES:
            try:
                result: list[TextContent] = await module.handle_tool(name, arguments, get_client)
                elapsed = time.monotonic() - start
                logger.info("Tool %s completed in %.3fs", name, elapsed)
                return result
            except httpx.HTTPStatusError as exc:
                elapsed = time.monotonic() - start
                logger.error(
                    "Tool %s failed with HTTP %d after %.3fs",
                    name,
                    exc.response.status_code,
                    elapsed,
                )
                return _format_api_error(exc)
    raise ValueError(f"Unknown tool: {name}")


def main() -> None:
    """Entry point for the MCP server."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    async def run() -> None:
        global client
        logger.info("Starting threshold-mcp server")
        try:
            async with stdio_server() as (read_stream, write_stream):
                await server.run(read_stream, write_stream, server.create_initialization_options())
        finally:
            if client is not None:
                await client.close()
                logger.info("Client closed")
                client = None

    asyncio.run(run())


if __name__ == "__main__":
    main()
