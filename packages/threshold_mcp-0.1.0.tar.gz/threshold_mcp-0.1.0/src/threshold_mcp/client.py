"""HTTP client for the Threshold API."""

from __future__ import annotations

import asyncio
import logging
import os
import time
from typing import Any

import httpx

DEFAULT_BASE_URL = "https://api.threshold-immigration.com"
DEFAULT_TIMEOUT = 30.0

_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}
_MAX_RETRIES = 3
_BACKOFF_BASE = 1.0
_BACKOFF_FACTOR = 2.0

logger = logging.getLogger(__name__)


def _get_retry_delay(response: httpx.Response, attempt: int) -> float:
    """Compute retry delay from Retry-After header or exponential backoff."""
    retry_after = response.headers.get("Retry-After")
    if retry_after is not None:
        try:
            return float(retry_after)
        except (ValueError, OverflowError):
            pass
    return _BACKOFF_BASE * (_BACKOFF_FACTOR**attempt)


class ThresholdClient:
    """Thin async wrapper around the Threshold API."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.api_key = api_key or os.environ.get("THRESHOLD_API_KEY", "")
        self.base_url = (base_url or os.environ.get("THRESHOLD_API_URL", DEFAULT_BASE_URL)).rstrip(
            "/"
        )
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"X-API-Key": self.api_key},
            timeout=timeout,
        )

    async def get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        """Make a GET request with retry logic and return the JSON response."""
        last_exc: httpx.HTTPStatusError | None = None

        for attempt in range(_MAX_RETRIES + 1):
            start = time.monotonic()
            response = await self._client.get(path, params=params)
            elapsed = time.monotonic() - start

            logger.debug(
                "GET %s -> %d (%.3fs)",
                path,
                response.status_code,
                elapsed,
            )

            if response.status_code < 400:
                return response.json()  # type: ignore[no-any-return]

            try:
                response.raise_for_status()
            except httpx.HTTPStatusError as exc:
                last_exc = exc

                if response.status_code not in _RETRYABLE_STATUS_CODES:
                    raise

                if attempt < _MAX_RETRIES:
                    delay = _get_retry_delay(response, attempt)
                    logger.warning(
                        "Retryable %d on GET %s, retrying in %.1fs (attempt %d/%d)",
                        response.status_code,
                        path,
                        delay,
                        attempt + 1,
                        _MAX_RETRIES,
                    )
                    await asyncio.sleep(delay)
                else:
                    logger.error(
                        "GET %s failed after %d attempts: %d",
                        path,
                        _MAX_RETRIES + 1,
                        response.status_code,
                    )
                    raise

        # Should never reach here, but satisfy type checker
        assert last_exc is not None
        raise last_exc

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> ThresholdClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
