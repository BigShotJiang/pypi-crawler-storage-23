"""Pro-tier intelligence tools (M3)."""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

from mcp.types import TextContent, Tool

from threshold_mcp.client import ThresholdClient

TOOLS: list[Tool] = [
    Tool(
        name="optimize_geography",
        description=(
            "Find metro areas where a given wage qualifies for the best H-1B lottery "
            "advantage. Returns ranked locations with wage levels, lottery entries, and "
            "filing counts for a specific SOC code and salary."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "soc_code": {
                    "type": "string",
                    "description": "SOC code in XX-XXXX format (e.g., '15-1252')",
                },
                "wage": {
                    "type": "number",
                    "description": "Offered annual salary in USD",
                },
                "state": {
                    "type": "string",
                    "description": (
                        "Comma-separated two-letter state codes to filter results "
                        "(e.g., 'CA,TX,NY')"
                    ),
                },
                "wage_source": {
                    "type": "string",
                    "description": "Wage data source: 'oews' (default) or 'acwia'",
                },
            },
            "required": ["soc_code", "wage"],
        },
    ),
    Tool(
        name="analyze_classification",
        description=(
            "Find alternative SOC classifications for an H-1B role with wage and lottery "
            "implications. Provide a SOC code or job title to discover related occupations "
            "with filing volumes, certification rates, and optional wage comparison at a "
            "specific location."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "soc_code": {
                    "type": "string",
                    "description": "SOC code in XX-XXXX format (e.g., '15-1252')",
                },
                "job_title": {
                    "type": "string",
                    "description": "Job title to search for (e.g., 'Software Engineer')",
                },
                "zip": {
                    "type": "string",
                    "description": "5-digit ZIP code for location-specific wage comparison",
                },
                "cbsa": {
                    "type": "string",
                    "description": "CBSA code for location-specific wage comparison",
                },
                "wage": {
                    "type": "number",
                    "description": "Offered annual wage in USD for level calculation",
                },
                "wage_source": {
                    "type": "string",
                    "description": "Wage data source: 'oews' (default) or 'acwia'",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of alternatives to return",
                },
            },
            "required": [],
        },
    ),
    Tool(
        name="get_employer_intelligence",
        description=(
            "Get comprehensive H-1B program analysis for a specific employer, including "
            "filing trends, denial benchmarks, wage distribution, top occupations, "
            "geographic footprint, and overall program health rating. Identify by name or FEIN."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Employer name to search for (e.g., 'Google')",
                },
                "fein": {
                    "type": "string",
                    "description": (
                        "FEIN with or without hyphen (e.g., '20-1665019' or '201665019')"
                    ),
                },
            },
            "required": [],
        },
    ),
]

TOOL_NAMES = {tool.name for tool in TOOLS}

_GEO_OPTIONAL_KEYS = {"state", "wage_source"}
_CLASS_OPTIONAL_KEYS = {"soc_code", "job_title", "zip", "cbsa", "wage", "wage_source", "limit"}
_EMPLOYER_INTEL_OPTIONAL_KEYS = {"name", "fein"}


async def handle_tool(
    name: str, arguments: dict[str, Any], get_client: Callable[[], ThresholdClient]
) -> list[TextContent]:
    """Handle an intelligence tool call."""
    client = get_client()

    if name == "optimize_geography":
        params: dict[str, Any] = {
            "soc_code": arguments["soc_code"],
            "wage": arguments["wage"],
        }
        for key in _GEO_OPTIONAL_KEYS:
            if key in arguments and arguments[key] is not None:
                params[key] = arguments[key]
        result = await client.get("/api/v1/intelligence/geographic-optimizer", params=params)
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    if name == "analyze_classification":
        params = {}
        for key in _CLASS_OPTIONAL_KEYS:
            if key in arguments and arguments[key] is not None:
                params[key] = arguments[key]
        result = await client.get("/api/v1/intelligence/classification-analyzer", params=params)
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    if name == "get_employer_intelligence":
        params = {}
        for key in _EMPLOYER_INTEL_OPTIONAL_KEYS:
            if key in arguments and arguments[key] is not None:
                params[key] = arguments[key]
        result = await client.get("/api/v1/intelligence/employer-profile", params=params)
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    raise ValueError(f"Unknown intelligence tool: {name}")
