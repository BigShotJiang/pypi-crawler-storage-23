"""Wage lookup and calculation tools."""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

from mcp.types import TextContent, Tool

from threshold_mcp.client import ThresholdClient

_LOCATION_PROPERTIES = {
    "zip": {
        "type": "string",
        "description": "5-digit ZIP code (e.g., '94105')",
    },
    "cbsa": {
        "type": "string",
        "description": "CBSA (metro area) code (e.g., '41860')",
    },
    "city": {
        "type": "string",
        "description": "City name (use with state)",
    },
    "state": {
        "type": "string",
        "description": "Two-letter state abbreviation (e.g., 'CA')",
    },
    "county": {
        "type": "string",
        "description": "County name — needed when a ZIP or CBSA spans multiple counties",
    },
}

TOOLS: list[Tool] = [
    Tool(
        name="lookup_prevailing_wage",
        description=(
            "Look up prevailing wage data for a given SOC code and location. "
            "Provide location as zip, cbsa, or city+state."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "soc_code": {
                    "type": "string",
                    "description": (
                        "SOC code in XX-XXXX format (e.g., '15-1252' for Software Developers)"
                    ),
                },
                **_LOCATION_PROPERTIES,
            },
            "required": ["soc_code"],
        },
    ),
    Tool(
        name="calculate_wage_level",
        description=(
            "Calculate the wage level (1-4) for a specific salary against prevailing wage data. "
            "Returns which level the salary falls into and context."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "soc_code": {
                    "type": "string",
                    "description": "SOC code in XX-XXXX format (e.g., '15-1252')",
                },
                "salary": {
                    "type": "number",
                    "description": "Offered annual salary in USD",
                },
                **_LOCATION_PROPERTIES,
            },
            "required": ["soc_code", "salary"],
        },
    ),
]

TOOL_NAMES = {tool.name for tool in TOOLS}

_LOCATION_KEYS = {"zip", "cbsa", "city", "state", "county"}


def _location_params(arguments: dict[str, Any]) -> dict[str, str]:
    """Extract location params from tool arguments."""
    return {k: v for k, v in arguments.items() if k in _LOCATION_KEYS and v}


async def handle_tool(
    name: str, arguments: dict[str, Any], get_client: Callable[[], ThresholdClient]
) -> list[TextContent]:
    """Handle a wage tool call."""
    client = get_client()

    if name == "lookup_prevailing_wage":
        params: dict[str, Any] = {"soc_code": arguments["soc_code"]}
        params.update(_location_params(arguments))
        result = await client.get("/api/v1/wages/prevailing", params=params)
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    if name == "calculate_wage_level":
        params = {"soc_code": arguments["soc_code"], "wage": arguments["salary"]}
        params.update(_location_params(arguments))
        result = await client.get("/api/v1/wages/level", params=params)
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    raise ValueError(f"Unknown wage tool: {name}")
