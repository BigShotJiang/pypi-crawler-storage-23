"""Employer search and intelligence tools (M2)."""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

from mcp.types import TextContent, Tool

from threshold_mcp.client import ThresholdClient

TOOLS: list[Tool] = [
    Tool(
        name="search_employers",
        description=(
            "Search for H-1B sponsor employers by name. Returns matching employers "
            "with filing counts and basic info. Use this to find employers before "
            "looking up their full profile."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "q": {
                    "type": "string",
                    "description": "Search query — employer name or keyword (min 2 characters)",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max results to return (default 20, max 100)",
                },
                "offset": {
                    "type": "integer",
                    "description": "Number of results to skip for pagination (default 0)",
                },
                "min_filings": {
                    "type": "integer",
                    "description": "Only include employers with at least this many filings",
                },
                "state": {
                    "type": "string",
                    "description": "Filter by two-letter state code (e.g., 'CA')",
                },
            },
            "required": ["q"],
        },
    ),
    Tool(
        name="get_employer_profile",
        description=(
            "Get a detailed profile for a specific H-1B sponsor employer, including "
            "filing history, top SOC codes, and wage statistics. Identify the employer "
            "by database ID or FEIN."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "employer_identifier": {
                    "type": "string",
                    "description": "Employer database ID or FEIN (e.g., '12345' or '00-1234567')",
                },
                "include_filings": {
                    "type": "boolean",
                    "description": "Include individual LCA filings in the response (default false)",
                },
                "filings_limit": {
                    "type": "integer",
                    "description": (
                        "Max filings to return when include_filings is true (default 50, max 500)"
                    ),
                },
            },
            "required": ["employer_identifier"],
        },
    ),
]

TOOL_NAMES = {tool.name for tool in TOOLS}

_SEARCH_OPTIONAL_KEYS = {"limit", "offset", "min_filings", "state"}


async def handle_tool(
    name: str, arguments: dict[str, Any], get_client: Callable[[], ThresholdClient]
) -> list[TextContent]:
    """Handle an employer tool call."""
    client = get_client()

    if name == "search_employers":
        params: dict[str, Any] = {"q": arguments["q"]}
        for key in _SEARCH_OPTIONAL_KEYS:
            if key in arguments and arguments[key] is not None:
                params[key] = arguments[key]
        result = await client.get("/api/v1/employers/search", params=params)
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    if name == "get_employer_profile":
        identifier = arguments["employer_identifier"]
        params = {}
        if arguments.get("include_filings"):
            params["include_filings"] = "true"
        if "filings_limit" in arguments and arguments["filings_limit"] is not None:
            params["filings_limit"] = arguments["filings_limit"]
        result = await client.get(f"/api/v1/employers/{identifier}", params=params or None)
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    raise ValueError(f"Unknown employer tool: {name}")
