"""SOC code search and lookup tools."""

from __future__ import annotations

import json
from collections.abc import Callable
from typing import Any

from mcp.types import TextContent, Tool

from threshold_mcp.client import ThresholdClient

TOOLS: list[Tool] = [
    Tool(
        name="search_soc_codes",
        description=(
            "Search for SOC (Standard Occupational Classification) codes by job title "
            "or keyword. Returns matching codes with titles and descriptions. "
            "Use this to find the right SOC code for an H-1B petition."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": (
                        "Job title or keyword to search "
                        "(e.g., 'software developer', 'data scientist')"
                    ),
                },
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="get_soc_details",
        description=(
            "Get detailed information for a specific SOC code, including the full "
            "occupation description, major/minor group classification, and LCA filing "
            "statistics (total filings, certified, denied, withdrawn)."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "soc_code": {
                    "type": "string",
                    "description": (
                        "SOC code in XX-XXXX format or O*NET code in XX-XXXX.XX format "
                        "(e.g., '15-1252')"
                    ),
                },
            },
            "required": ["soc_code"],
        },
    ),
]

TOOL_NAMES = {tool.name for tool in TOOLS}


async def handle_tool(
    name: str, arguments: dict[str, Any], get_client: Callable[[], ThresholdClient]
) -> list[TextContent]:
    """Handle a SOC tool call."""
    client = get_client()

    if name == "search_soc_codes":
        results = await client.get(
            "/api/v1/soc/search",
            params={"q": arguments["query"]},
        )
        return [TextContent(type="text", text=json.dumps(results, indent=2))]

    if name == "get_soc_details":
        soc_code = arguments["soc_code"]
        result = await client.get(f"/api/v1/soc/{soc_code}")
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    raise ValueError(f"Unknown SOC tool: {name}")
