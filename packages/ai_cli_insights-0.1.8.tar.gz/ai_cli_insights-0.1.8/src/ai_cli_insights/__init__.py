"""Cross-tool usage analytics for Claude Code and Codex CLI."""

__version__ = "0.1.8"
