from setuptools import setup, find_packages

setup(
    name='s6r-hubspot',  # Replace with your package's name
    version='0.1.0',  # Version of your package
    author='Khalid BENTALEB',  # Your name or your organization/company name
    author_email='your.email@example.com',  # Your email or your organization's email
    description='A small example package',  # A short, one-sentence summary of the package
    long_description=open('README.md').read(),  # A long description from the README file
    long_description_content_type='text/markdown',  # Type of the long description, often markdown
    url='https://github.com/yourusername/example_package',  # URL to the homepage of the package
    packages=find_packages(),  # Automatically find all packages and subpackages
    install_requires=[
        'numpy',  # Dependencies of your package
        'pandas'  # You can list all necessary dependencies here
    ],
    classifiers=[
        'Development Status :: 3 - Alpha',  # Development status of your package
        'Intended Audience :: Developers',  # Define the audience for your package
        'License :: OSI Approved :: MIT License',  # License for your package
        'Programming Language :: Python :: 3',  # Supported versions of Python
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10'
    ],
    python_requires='>=3.7',  # Minimum version requirement of Python
    keywords='example package',  # Keywords that define your package best
    project_urls={  # Optional additional URLs for your package
        'Bug Reports': 'https://github.com/yourusername/example_package/issues',
        'Source': 'https://github.com/yourusername/example_package/',
    },
)