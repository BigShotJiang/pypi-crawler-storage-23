PineAPPL's Python API
=====================

.. automodule:: pineappl
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pineappl.bin
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pineappl.channel
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pineappl.evolution
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pineappl.fk_table
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pineappl.grid
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pineappl.subgrid
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: pineappl.import_only_subgrid
   :members:
   :undoc-members:
   :show-inheritance:
