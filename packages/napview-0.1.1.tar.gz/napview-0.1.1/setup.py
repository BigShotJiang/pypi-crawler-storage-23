from setuptools import setup

install_requires = [
    "scipy>=1.17.0,<1.18",
    "numpy>=2.3.4,<2.4",
    "mne==1.11.0",
    "Flask==3.0.3",
    "peewee>=3.19.0,<3.20",
    "pylsl==1.16.2",
    "setuptools",
    "edfio==0.4.3",
    "pandas>=2.3.3,<2.4",
    "psg_utils",
    "nidra>=0.2.3",
]

setup(
    install_requires=install_requires,
)
