import os
import time
from datetime import datetime, timezone
import json
import shutil
import logging
import multiprocessing
multiprocessing.set_start_method('spawn', True)
import threading
from pathlib import Path
import webbrowser
import socket
import platform
import subprocess
from http.server import HTTPServer, SimpleHTTPRequestHandler
from email.parser import BytesParser
from email.policy import default
import mne
import sys
from appdirs import user_data_dir

from .data_producer import DataProducer
from .data_recorder import DataRecorder
from .data_analyzer import Analyzer
from .data_visualizer import Visualizer
from .database_handler import DatabaseHandler
from .helpers import configure_logger, ConfigManager, get_resource_root


class ProcessManager:
    def __init__(self):
        self.processes = {}

    @staticmethod
    def run_pipeline_component(component_class, **kwargs):
        component = component_class(**kwargs)
        try:
            component.run()
        finally:
            component.shutdown()

    def start_process(self, role, component_class, **kwargs):
        if self.is_process_running(role):
            print(f"Process {role} is already running.")
            return
        process = multiprocessing.Process(target=self.run_pipeline_component, args=(component_class,), kwargs=kwargs)
        process.start()
        self.processes[role] = process

    def stop_process(self, role):
        process = self.processes.get(role)
        if process and process.is_alive():
            process.terminate()
            process.join()
            del self.processes[role]

    def stop_processes(self):
        for process in self.processes.values():
            if process.is_alive():
                process.terminate()
                process.join()
        self.processes.clear()

    def is_process_running(self, role):
        process = self.processes.get(role)
        return process is not None and process.is_alive()

    def any_process_running(self):
        return any(process.is_alive() for process in self.processes.values())

    def launch_components(self, base_path, config_manager, components):
        with config_manager.config_lock:
            config_manager.load_config(instance=self)
        component_map = {
            'producer': (DataProducer, {'mode': self.config.get('eeg_amp', 'Simulator')}),
            'recorder': (DataRecorder, {'mode': ''}),
            'analyzer': (Analyzer, {'mode': self.config.get('sleep_staging_model', 'U-Sleep')}),
            'visualizer': (Visualizer, {'mode': ''})
        }

        for component in components:
            if component in component_map:
                component_class, kwargs = component_map[component]
                kwargs['base_path'] = base_path
                self.start_process(component, component_class, **kwargs)


dialog_lock = threading.Lock()


def get_default_base_path():
    return Path(user_data_dir()) / "napview" / "data"


def init_base_path(base_path, logger):
    try:
        data_path = Path(base_path) / "temp"
        data_path.mkdir(parents=True, exist_ok=True)
        (data_path / "db").mkdir(parents=True, exist_ok=True)
        logger.info(f'Init: Data directories created in {base_path}')
    except Exception as e:
        logger.error(f'Init: Failed to create data directories in {base_path} : {str(e)}', exc_info=True)

    eeg_file_name = 'eeg.edf'
    src_eeg_file_path = get_resource_root() / "assets" / eeg_file_name
    dest_eeg_file_path = Path(base_path) / eeg_file_name
    if not dest_eeg_file_path.exists():
        try:
            shutil.copy(src_eeg_file_path, dest_eeg_file_path)
            logger.info(f"Init: Copied simulation {eeg_file_name} to {base_path}")
        except Exception as e:
            logger.error(f"Init: Failed to copy {eeg_file_name}: {e}", exc_info=True)


def open_native_directory_dialog(logger, title):
    if not dialog_lock.acquire(blocking=False):
        logger.warning("File dialog blocked because another is already open.")
        return {'status': 'error', 'message': 'Another file dialog is already open.'}

    try:
        if platform.system() == "Darwin":
            script = f'POSIX path of (choose folder with prompt "{title}")'
            try:
                out = subprocess.check_output(["osascript", "-e", script], text=True)
                path = out.strip()
                if path:
                    return {'status': 'success', 'path': path}
                return {'status': 'cancelled'}
            except subprocess.CalledProcessError:
                return {'status': 'cancelled'}
            except Exception as e:
                logger.error(f"AppleScript dialog failed: {e}", exc_info=True)
                return {'status': 'error', 'message': 'Could not open the dialog.'}

        result = {}
        def open_dialog_thread():
            import tkinter as tk
            from tkinter import filedialog
            try:
                root = tk.Tk()
                root.withdraw()
                root.attributes('-topmost', True)
                path = filedialog.askdirectory(title=title)
                if path:
                    result['path'] = path
            except Exception as e:
                logger.error(f"An error occurred in the tkinter dialog thread: {e}", exc_info=True)
                result['error'] = "Could not open the file dialog. Please ensure you have a graphical environment configured."
            finally:
                if 'root' in locals() and root:
                    root.destroy()

        dialog_thread = threading.Thread(target=open_dialog_thread)
        dialog_thread.start()
        dialog_thread.join()

        if 'error' in result:
            return {'status': 'error', 'message': result['error']}
        if 'path' in result:
            return {'status': 'success', 'path': result['path']}
        return {'status': 'cancelled'}
    finally:
        if dialog_lock.locked():
            dialog_lock.release()


class NapviewRequestHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, process_manager=None, base_path=None, config_manager=None, db_handler=None, logger=None, **kwargs):
        self.process_manager = process_manager
        self.base_path = base_path
        self.config_manager = config_manager
        self.logger = logger
        self.db_handler = db_handler
        super().__init__(*args, **kwargs)

    def end_headers(self):
        # Prevent stale GUI pages from being cached by the browser.
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()

    def do_GET(self):
        if self.path == '/':
            self.path = '/templates/gui.html'

        elif self.path == '/load_config':
            with self.config_manager.config_lock:
                self.config = self.config_manager.load_config(instance=self)
            self.config['app_running'] = self.process_manager.any_process_running()
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(self.config).encode('utf-8'))
            return

        elif self.path == '/select-data-dir':
            if self.process_manager.any_process_running():
                response = {'status': 'error', 'message': 'Stop napview before changing the data directory.'}
                self.send_response(409)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(response).encode('utf-8'))
                return

            result = open_native_directory_dialog(self.logger, "Select Napview data folder")
            if result.get('status') == 'success':
                update_result = self.update_base_path(result.get('path'))
                response = update_result
                status_code = 200 if update_result.get('status') == 'success' else 500
            else:
                response = result
                status_code = 200 if result.get('status') != 'error' else 500

            self.send_response(status_code)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(response).encode('utf-8'))
            return

        try:
            return super().do_GET()
        except BrokenPipeError:
            self.logger.warning("BrokenPipeError: Client disconnected before response was fully sent.", exc_info=True)
        except Exception as e:
            self.logger.error(f"Unexpected error: {e}", exc_info=True)

    def do_POST(self):
        try:
            if self.path == '/start':
                ready = True
                self.config = self.config_manager.load_config(instance=self)
                separate_session_log = self.config.get('separate_session_log', True)
                if separate_session_log:
                    record_name = self.config.get('record_name')
                    if not record_name or not str(record_name).strip():
                        self.logger.error("GUI: start_attempt: missing record name")
                        response = {'status': 'error', 'message': 'Record name is required'}
                        ready = False
                    if ready:
                        safe_record_name = ''.join(
                            c if c.isalnum() or c in ('-', '_') else '_'
                            for c in str(record_name).strip()
                        ).strip('_')
                        if not safe_record_name:
                            self.logger.error("GUI: start_attempt: invalid record name")
                            response = {'status': 'error', 'message': 'Record name is invalid'}
                            ready = False
                        else:
                            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
                            log_filename = f"napview_log_{safe_record_name}_{timestamp}.log"
                            temp_log_path = Path(self.base_path) / "napview_log_temp.log"
                            session_log_path = Path(self.base_path) / log_filename
                            for handler in self.logger.handlers:
                                if isinstance(handler, logging.FileHandler):
                                    handler.flush()
                            if not temp_log_path.exists():
                                raise FileNotFoundError(f"Temp log file not found at {temp_log_path}")
                            with open(temp_log_path, 'r') as src, open(session_log_path, 'w') as dst:
                                dst.write(src.read())
                            self.config_manager.save_config({'log_file_name': log_filename})
                            self.logger = configure_logger(self.base_path, log_filename=log_filename, force=True)
                            temp_log_path.unlink()

                if self.config.get('eeg_amp') == 'Simulator' and not self.validate_eeg_file():
                    self.logger.error(f"GUI: start_attempt: invalid EEG file")
                    response = {'status': 'error', 'message': 'Invalid EEG file'}
                    ready = False

                if self.process_manager.any_process_running():
                    self.logger.error(f"GUI: start_attempt: process already running")
                    response = {'status': 'error', 'message': 'A process is already running'}
                    ready = False

                if ready:
                    try:
                        self.process_manager.launch_components(self.base_path, self.config_manager, ['producer', 'recorder'])
                        response = {'status': 'success', 'message': 'Producer and recorder started'}
                    except Exception as e:
                        self.logger.error(f"GUI: Connection failed: {e}", exc_info=True)
                        self.process_manager.stop_processes()
                        response = {'status': 'error', 'message': f'Connection failed: {str(e)}'}
                        ready = False
                if ready:
                    self.process_manager.launch_components(
                        self.base_path,
                        self.config_manager,
                        ['analyzer', 'visualizer']
                    )

            elif self.path == '/check_eeg_file':
                self.validate_eeg_file()
                response = {'status': 'eeg file checked'}

            elif self.path == '/start_data_producer':
                if not self.process_manager.is_process_running('producer'):
                    self.process_manager.launch_components(self.base_path, self.config_manager, ['producer'])
                    response = {'status': 'Data producer started'}
                else:
                    response = {'status': 'Data producer already running'}

            elif self.path == '/stop_data_producer':
                self.process_manager.stop_process('producer')

                with self.config_manager.config_lock:
                    self.config = self.config_manager.load_config(instance=self)
                    self.config['app_running'] = False
                    self.config_manager.save_config(self.config)

                response = {'status': 'Data producer stopped'}

            elif self.path == '/shutdown_and_save':
                self.config = self.config_manager.load_config(instance=self)
                self.process_manager.stop_processes()
                timestamp = time.strftime('%Y%m%d_%H%M%S')
                output_directory = os.path.join(self.base_path, 'output', timestamp)
                os.makedirs(output_directory, exist_ok=True)
                messages = []
                
                eeg_result = self.save_eeg_data_as_edf(self.config.get('db_file_path'), output_directory, timestamp)
                messages.append(eeg_result['message'])

                results_result = self.save_results_files(output_directory, timestamp)
                messages.extend(results_result['messages'])

                if eeg_result['success'] and results_result['success']:
                    response_status = 'success'
                    messages.append(f"Files were saved in: {output_directory}")
                elif not eeg_result['success'] and not results_result['success']:
                    response_status = 'error'
                else:
                    response_status = 'partial_success'
                    messages.append(f"Files were saved in: {output_directory}")

                response = {'status': response_status, 'messages': messages}

                # Close the database connection
                if self.db_handler:
                    self.db_handler.close()
                    self.logger.info("Shutdown: Database connection closed.")
                time.sleep(0.5)

                data_path = os.path.join(self.base_path, "temp")
                directories_to_clean = ['db', 'edfs', 'results']
                for dirname in directories_to_clean:
                    dirpath = os.path.join(data_path, dirname)
                    for root, dirs, files in os.walk(dirpath):
                        for file in files:
                            file_path = os.path.join(root, file)
                            os.remove(file_path)
                            self.logger.info(f"Shutdown: Deleted file: {file_path}")

                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(response).encode('utf-8'))

                shutdown_thread = threading.Thread(target=self.shutdown_server)
                shutdown_thread.start()
                return

            elif self.path == '/update_config':
                content_length = int(self.headers['Content-Length'])
                config_updates = json.loads(self.rfile.read(content_length).decode('utf-8'))
                with self.config_manager.config_lock:
                    self.config = self.config_manager.load_config(instance=self)
                    self.config.update(config_updates)
                    self.config_manager.save_config(self.config)
                response = {'status': 'Configuration updated'}


            elif self.path == '/upload_eeg_file':
                content_type = self.headers.get('Content-Type')
                if content_type and 'multipart/form-data' in content_type:
                    content_length = int(self.headers.get('Content-Length', 0))
                    post_data = self.rfile.read(content_length)

                    message_data = b'Content-Type: ' + content_type.encode('utf-8') + b'\r\n\r\n' + post_data

                    parser = BytesParser(policy=default)
                    message = parser.parsebytes(message_data)

                    if message.is_multipart():
                        for part in message.iter_parts():
                            content_disposition = part.get('Content-Disposition', '')
                            if 'form-data' in content_disposition:
                                name = part.get_param('name', header='content-disposition', unquote=True)
                                filename = part.get_param('filename', header='content-disposition', unquote=True)
                                payload = part.get_payload(decode=True)
                                if name == 'eegFile' and payload:
                                    if not filename:
                                        filename = 'eeg.edf'
                                    save_path = os.path.join(self.base_path, filename)
                                    with open(save_path, 'wb') as f:
                                        f.write(payload)
                                    self.validate_eeg_file()
                                    response = {'status': 'success'}
                                    break
                        else:
                            response = {'status': 'error', 'message': 'No file uploaded'}
                    else:
                        response = {'status': 'error', 'message': 'Expected multipart content'}
                else:
                    response = {'status': 'error', 'message': 'Invalid content type'}

                self.send_response(200)
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps(response).encode('utf-8'))
                time.sleep(.1)
                return

            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(response).encode('utf-8'))
            time.sleep(.1)
            return

        except BrokenPipeError:
            self.logger.warning("Client disconnected before response was fully sent.", exc_info=True)
        except Exception as e:
            self.logger.error(f"Unexpected error: {e}", exc_info=True)

    def shutdown_server(self):
        time.sleep(2)
        self.logger.info("Shutdown: Initiating server shutdown...")
        self.server.shutdown()
        self.server.server_close()
        self.logger.info("Shutdown: Server shut down successfully.")

    def update_base_path(self, new_base_path):
        try:
            new_base_path = Path(new_base_path).expanduser().resolve()
        except Exception as e:
            return {'status': 'error', 'message': f'Invalid data directory: {e}'}

        try:
            new_base_path.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            return {'status': 'error', 'message': f'Failed to create data directory: {e}'}

        with self.config_manager.config_lock:
            current_config = self.config_manager.load_config()

        if self.db_handler:
            self.db_handler.close()

        init_base_path(new_base_path, self.logger)

        new_config_manager = ConfigManager(new_base_path, load_defaults=True)
        current_config['base_path'] = str(new_base_path)
        new_config_manager.save_config(current_config)
        self.config_manager = new_config_manager

        log_filename = current_config.get('log_file_name', 'napview_log.log')
        self.logger = configure_logger(new_base_path, log_filename=log_filename, force=True)

        self.base_path = new_base_path
        self.db_handler = DatabaseHandler(new_base_path)
        self.db_handler.setup_database(create_tables=True)

        return {'status': 'success', 'path': str(new_base_path)}

    def validate_eeg_file(self):
        try:
            self.config = self.config_manager.load_config(instance=self)
            filename = self.config.get('sim_input_file_path', 'eeg.edf')
            full_path = Path(self.base_path) / filename
            mne.io.read_raw_edf(full_path, preload=False)
            eeg_file_valid = True
            self.logger.info(f"Init: EEG file is valid.")
        except Exception as e:
            self.logger.error(f"Init: Invalid EEG file: {e}", exc_info=True)
            eeg_file_valid = False
        with self.config_manager.config_lock:
            self.config['eeg_file_valid'] = eeg_file_valid
            self.config_manager.save_config(self.config)
        return eeg_file_valid

    def save_eeg_data_as_edf(self, db_file_path, output_directory, timestamp):
        result = {'success': True, 'message': ''}
        try:
            eeg_info = self.db_handler.retrieve_info()
            total_samples = self.db_handler.get_total_n_samples()
            end_sample_index = total_samples - 1
            eeg_data = self.db_handler.retrieve_data(0, end_sample_index)
            channel_names = json.loads(eeg_info.channel_names)
            info = mne.create_info(
                ch_names=channel_names,
                sfreq=eeg_info.sample_rate,
                ch_types=['eeg'] * eeg_info.n_channels
            )
            raw = mne.io.RawArray(eeg_data, info)
            raw.set_meas_date(datetime.now(timezone.utc))

            edf_file_path = os.path.join(output_directory, f'recording_{timestamp}.edf')
            mne.export.export_raw(edf_file_path, raw, fmt='edf', overwrite=True)
            self.logger.info(f"Shutdown: EEG data saved to {edf_file_path}")
            result['message'] = f"EEG data saved to {edf_file_path}"

        except ValueError as ve:
            self.logger.warning(f"Shutdown: {str(ve)}")
            result['success'] = False
            result['message'] = str(ve)
        except Exception as e:
            self.logger.error(f"Shutdown: Unexpected error while saving EEG data: {e}", exc_info=True)
            result['success'] = False
            result['message'] = "An error occurred while saving EEG data."
        return result

    def save_results_files(self, output_directory, timestamp):
        result = {'success': True, 'messages': []}
        try:
            staging_results_file = os.path.join(self.base_path, 'temp', 'results', 'staging_results.txt')
            staging_results_dest = os.path.join(output_directory, f'staging_results_{timestamp}.txt')
            if os.path.exists(staging_results_file):
                shutil.copy2(staging_results_file, staging_results_dest)
                self.logger.info(f"Copied {staging_results_file} to {staging_results_dest}")
                result['messages'].append(f"Staging results saved to {staging_results_dest}")
            else:
                warning_msg = f"Staging results file {staging_results_file} does not exist."
                self.logger.warning(warning_msg)
                result['messages'].append(warning_msg)


        except Exception as e:
            self.logger.error(f"Shutdown: Unexpected error while saving results files: {e}", exc_info=True)
            result['success'] = False
            result['messages'].append("An error occurred while saving results files.")

        return result




def main():

    if getattr(sys, "frozen", False):
        app_root = Path(sys.executable).resolve().parent
    else:
        app_root = Path(__file__).resolve().parent.parent

    #########################################
    ###  ESTABLISH BASE PATH
    base_path = get_default_base_path()
    base_path.mkdir(parents=True, exist_ok=True)


    #########################################
    ###  START LOGGER
    #logger_timestamp = time.strftime('%Y%m%d_%H%M%S')
    temp_log_filename = "napview_log_temp.log"
    logger = configure_logger(base_path, log_filename=temp_log_filename, force=True)
    logger.info('')
    logger.info('')
    logger.info('Init: #############################################################')
    logger.warning('Init: #################### New run started ########################')
    logger.info('Init: #############################################################')


    #########################################
    ###  MAKE PATHS AND FOLDERS
    init_base_path(base_path, logger)

    try:
        data_path = os.path.join(base_path, "temp")
        for root, dirs, files in os.walk(data_path):
            # if root == os.path.join(data_path, "db"):
            #     continue
            for file in files:
                file_path = os.path.join(root, file)
                os.remove(file_path)
                logger.info(f"Init: Deleted file: {file_path}")
    except Exception as e:
        logger.error(f'Init: Failed to remove old db files : {str(e)}', exc_info=True)

    ########################################
    ### INIT MANAGERS
    config_manager = ConfigManager(base_path, load_defaults = True)
    config = config_manager.load_config()
    separate_session_log = config.get('separate_session_log', True)
    if separate_session_log:
        config_manager.save_config({'log_file_name': temp_log_filename})
    else:
        default_log_filename = "napview_log.log"
        temp_log_path = Path(base_path) / temp_log_filename
        default_log_path = Path(base_path) / default_log_filename
        for handler in logger.handlers:
            if isinstance(handler, logging.FileHandler):
                handler.flush()
        if not temp_log_path.exists():
            raise FileNotFoundError(f"Temp log file not found at {temp_log_path}")
        with open(temp_log_path, 'r') as src, open(default_log_path, 'a') as dst:
            dst.write(src.read())
        logger = configure_logger(base_path, log_filename=default_log_filename, force=True)
        temp_log_path.unlink()
        config_manager.save_config({'log_file_name': default_log_filename})
    
    db_handler = DatabaseHandler(base_path)
    db_handler.setup_database(create_tables=True)
    
    process_manager = ProcessManager()

    ##################################################
    ### START GUI
    def find_free_port(start_port, logger):
        for attempt in range(5000):
            port = start_port + attempt
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                if s.connect_ex(('localhost', port)) != 0:
                    return port
        logger.error(f"Init: Failed to find a free port after 5000 attempts", exc_info=True)
        raise RuntimeError(f"Init: Unable to find a free port after 5000 attempts")

    gui_server_port = find_free_port(8145, logger)
    visualizer_port = find_free_port(gui_server_port + 100, logger)
    config_manager.save_config({
        'gui_server_port': gui_server_port,
        'visualizer_port': visualizer_port
    })
    logger.info(f'Init: Ports - - - gui: {gui_server_port},  visualizer: {visualizer_port}')

    # log config values
    c = config_manager.load_config()
    logger.info(f"Init: config.json:")
    for key, value in c.items():
        logger.info(f"      {key}: {value}")

    # start http request handler
    root_dir = get_resource_root()
    gui_server_handler = lambda *args, **kwargs: NapviewRequestHandler(
        *args,
        directory=root_dir,
        process_manager=process_manager,
        base_path=base_path,
        config_manager=config_manager,
        db_handler=db_handler,
        logger=logger,
        **kwargs
    )

    try:
        httpd = HTTPServer(('localhost', gui_server_port), gui_server_handler)
        print(f"Server started at http://localhost:{gui_server_port}")
        logger.info(f"Server started at http://localhost:{gui_server_port}")
        time.sleep(1)
        if os.environ.get("NAPVIEW_NO_AUTO_BROWSER") != "1":
            webbrowser.open(f"http://localhost:{gui_server_port}", new=1)
        logger.info("GUI: Server starting...")
        httpd.serve_forever()
    except KeyboardInterrupt:
        logger.info("GUI: Server interrupted by user")
    except Exception as e:
        logger.error(f"GUI: An unexpected error occurred: {str(e)}", exc_info=True)
    finally:
        httpd.shutdown()
        httpd.server_close()
        process_manager.stop_processes()


if __name__ == "__main__":
    main()
