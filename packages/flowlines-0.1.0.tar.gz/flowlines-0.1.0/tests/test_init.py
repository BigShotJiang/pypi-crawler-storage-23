"""Tests for the Flowlines class."""

import logging
import threading
from unittest.mock import MagicMock, call, patch

import pytest
from opentelemetry.sdk.trace import TracerProvider

from flowlines._context import FlowlinesSpanProcessor
from flowlines._init import Flowlines, _validate_endpoint


@pytest.fixture(autouse=True)
def _reset_singleton() -> None:
    """Reset the Flowlines singleton before each test."""
    Flowlines._reset()


class TestValidateEndpoint:
    def test_https_is_valid(self) -> None:
        _validate_endpoint("https://api.flowlines.io")

    def test_http_localhost_is_valid(self) -> None:
        _validate_endpoint("http://localhost:4318")

    def test_http_127_0_0_1_is_valid(self) -> None:
        _validate_endpoint("http://127.0.0.1:4318")

    def test_http_non_localhost_raises(self) -> None:
        with pytest.raises(ValueError, match="must use HTTPS"):
            _validate_endpoint("http://api.flowlines.io")

    def test_no_scheme_raises(self) -> None:
        with pytest.raises(ValueError, match="must use HTTPS"):
            _validate_endpoint("api.flowlines.io")

    def test_https_localhost_is_valid(self) -> None:
        _validate_endpoint("https://localhost:4318")

    def test_http_ipv6_loopback_is_valid(self) -> None:
        _validate_endpoint("http://[::1]:4318")


class TestValidateApiKey:
    @patch("flowlines._init.atexit", autospec=True)
    def test_empty_api_key_raises(self, _mock_atexit: MagicMock) -> None:
        """An empty api_key raises ValueError."""
        with pytest.raises(ValueError, match="api_key must not be empty"):
            Flowlines(
                api_key="", endpoint="https://example.com", has_external_otel=True
            )

    @patch("flowlines._init.atexit", autospec=True)
    def test_whitespace_api_key_raises(self, _mock_atexit: MagicMock) -> None:
        """A whitespace-only api_key raises ValueError."""
        with pytest.raises(ValueError, match="api_key must not be empty"):
            Flowlines(
                api_key="   ", endpoint="https://example.com", has_external_otel=True
            )


class TestSingleton:
    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_second_instance_raises(
        self,
        _mock_exporter_cls: MagicMock,
        _mock_trace: MagicMock,
    ) -> None:
        """Creating a second Flowlines instance raises RuntimeError."""
        Flowlines(api_key="key", endpoint="https://example.com")

        with pytest.raises(RuntimeError, match="singleton"):
            Flowlines(api_key="key2", endpoint="https://example.com")

    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_can_create_after_reset(
        self,
        _mock_exporter_cls: MagicMock,
        _mock_trace: MagicMock,
    ) -> None:
        """After _reset(), a new instance can be created."""
        Flowlines(api_key="key", endpoint="https://example.com")
        Flowlines._reset()
        Flowlines(api_key="key2", endpoint="https://example.com")

    def test_mutually_exclusive_flags(self) -> None:
        """Setting both has_external_otel and has_traceloop raises ValueError."""
        with pytest.raises(ValueError, match="mutually exclusive"):
            Flowlines(
                api_key="key",
                endpoint="https://example.com",
                has_external_otel=True,
                has_traceloop=True,
            )

    @patch("flowlines._init.atexit", autospec=True)
    def test_concurrent_init_only_one_succeeds(
        self,
        _mock_atexit: MagicMock,
    ) -> None:
        """Only one thread succeeds when multiple threads init concurrently."""
        results: list[Flowlines | Exception] = []
        barrier = threading.Barrier(4)

        def _init() -> None:
            barrier.wait()
            try:
                instance = Flowlines(
                    api_key="key",
                    endpoint="https://example.com",
                    has_external_otel=True,
                )
                results.append(instance)
            except RuntimeError as exc:
                results.append(exc)

        threads = [threading.Thread(target=_init) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        successes = [r for r in results if isinstance(r, Flowlines)]
        failures = [r for r in results if isinstance(r, RuntimeError)]
        assert len(successes) == 1
        assert len(failures) == 3


class TestModeA:
    """Mode A: no existing OTEL setup."""

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_creates_tracer_provider_and_sets_global(
        self,
        mock_exporter_cls: MagicMock,
        mock_bsp_cls: MagicMock,
        mock_trace: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """Mode A creates a TracerProvider and sets it as global."""
        fl = Flowlines(api_key="my-key", endpoint="https://api.flowlines.io")

        mock_exporter_cls.assert_called_once_with(
            api_key="my-key",
            endpoint="https://api.flowlines.io",
        )
        mock_bsp_cls.assert_called_once_with(mock_exporter_cls.return_value)
        mock_trace.set_tracer_provider.assert_called_once()
        assert fl._provider is not None

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    @patch("flowlines._init.Flowlines.get_instrumentors")
    def test_registers_instrumentors(
        self,
        mock_get_instrumentors: MagicMock,
        mock_exporter_cls: MagicMock,
        mock_bsp_cls: MagicMock,
        mock_trace: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """Mode A calls instrument() on all discovered instrumentors."""
        mock_inst1 = MagicMock()
        mock_inst2 = MagicMock()
        mock_get_instrumentors.return_value = [mock_inst1, mock_inst2]

        fl = Flowlines(api_key="key", endpoint="https://example.com")

        mock_inst1.instrument.assert_called_once_with(tracer_provider=fl._provider)
        mock_inst2.instrument.assert_called_once_with(tracer_provider=fl._provider)

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_validates_endpoint(
        self,
        _mock_exporter_cls: MagicMock,
        _mock_trace: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """Mode A raises ValueError for non-HTTPS non-localhost endpoints."""
        with pytest.raises(ValueError, match="must use HTTPS"):
            Flowlines(api_key="key", endpoint="http://api.flowlines.io")

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_allows_localhost(
        self,
        _mock_exporter_cls: MagicMock,
        _mock_bsp_cls: MagicMock,
        _mock_trace: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """Mode A allows HTTP for localhost endpoints."""
        Flowlines(api_key="key", endpoint="http://localhost:4318")

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_registers_atexit_handler(
        self,
        _mock_exporter_cls: MagicMock,
        _mock_bsp_cls: MagicMock,
        _mock_trace: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """Mode A registers shutdown as an atexit handler."""
        fl = Flowlines(api_key="key", endpoint="https://example.com")
        mock_atexit.register.assert_called_once_with(fl.shutdown)

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    @patch("flowlines._init.Flowlines.get_instrumentors")
    def test_resets_singleton_on_instrumentor_failure(
        self,
        mock_get_instrumentors: MagicMock,
        _mock_exporter_cls: MagicMock,
        _mock_bsp_cls: MagicMock,
        _mock_trace: MagicMock,
        _mock_atexit: MagicMock,
    ) -> None:
        """Mode A resets the singleton if an instrumentor raises."""
        failing_instrumentor = MagicMock()
        failing_instrumentor.instrument.side_effect = RuntimeError("instrument failed")
        mock_get_instrumentors.return_value = [failing_instrumentor]

        with pytest.raises(RuntimeError, match="instrument failed"):
            Flowlines(api_key="key", endpoint="https://example.com")

        assert Flowlines._instance is None


class TestModeB1:
    """Mode B1: has_external_otel=True — user manages everything."""

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_does_not_create_provider_or_instrument(
        self,
        mock_exporter_cls: MagicMock,
        mock_bsp_cls: MagicMock,
        mock_trace: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """Mode B1 skips TracerProvider creation and instrumentor registration."""
        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
        )

        assert fl._provider is None
        assert fl._processor is None
        mock_trace.set_tracer_provider.assert_not_called()
        # No exporter or processor created during construction.
        mock_exporter_cls.assert_not_called()
        mock_bsp_cls.assert_not_called()

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_create_span_processor_returns_processor(
        self,
        mock_exporter_cls: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """User can call create_span_processor() in Mode B1."""
        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
        )
        processor = fl.create_span_processor()

        assert isinstance(processor, FlowlinesSpanProcessor)
        mock_exporter_cls.assert_called_once_with(
            api_key="key",
            endpoint="https://example.com",
        )

    @patch("flowlines._init.atexit", autospec=True)
    def test_get_instrumentors_returns_list(
        self,
        mock_atexit: MagicMock,
    ) -> None:
        """User can call get_instrumentors() in Mode B1."""
        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
        )
        result = fl.get_instrumentors()

        assert isinstance(result, list)

    @patch("flowlines._init.atexit", autospec=True)
    def test_registers_atexit_handler(
        self,
        mock_atexit: MagicMock,
    ) -> None:
        """Mode B1 still registers shutdown as an atexit handler."""
        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
        )
        mock_atexit.register.assert_called_once_with(fl.shutdown)


class TestModeB2:
    """Mode B2: has_traceloop=True — Traceloop already initialized."""

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_adds_processor_to_existing_provider(
        self,
        mock_exporter_cls: MagicMock,
        mock_bsp_cls: MagicMock,
        mock_trace: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """Mode B2 adds a span processor to the existing TracerProvider."""
        existing_provider = MagicMock(spec=TracerProvider)
        mock_trace.get_tracer_provider.return_value = existing_provider

        Flowlines(
            api_key="key",
            endpoint="https://api.flowlines.io",
            has_traceloop=True,
        )

        mock_exporter_cls.assert_called_once_with(
            api_key="key",
            endpoint="https://api.flowlines.io",
        )
        mock_bsp_cls.assert_called_once_with(mock_exporter_cls.return_value)
        existing_provider.add_span_processor.assert_called_once()
        added_processor = existing_provider.add_span_processor.call_args[0][0]
        assert isinstance(added_processor, FlowlinesSpanProcessor)
        # Does NOT create a new provider or set global.
        mock_trace.set_tracer_provider.assert_not_called()

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    def test_raises_if_no_sdk_provider(
        self,
        mock_trace: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """Mode B2 raises RuntimeError if no SDK TracerProvider is found."""
        # Return a non-SDK provider (e.g., ProxyTracerProvider).
        mock_trace.get_tracer_provider.return_value = MagicMock(spec=[])

        with pytest.raises(RuntimeError, match="no SDK TracerProvider found"):
            Flowlines(
                api_key="key",
                endpoint="https://example.com",
                has_traceloop=True,
            )

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    def test_resets_singleton_on_failure(
        self,
        mock_trace: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """Mode B2 resets the singleton if initialization fails."""
        mock_trace.get_tracer_provider.return_value = MagicMock(spec=[])

        with pytest.raises(RuntimeError):
            Flowlines(
                api_key="key",
                endpoint="https://example.com",
                has_traceloop=True,
            )

        # Should be able to create a new instance after failure.
        assert Flowlines._instance is None

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_validates_endpoint(
        self,
        _mock_exporter_cls: MagicMock,
        _mock_bsp_cls: MagicMock,
        mock_trace: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """Mode B2 still validates the endpoint."""
        with pytest.raises(ValueError, match="must use HTTPS"):
            Flowlines(
                api_key="key",
                endpoint="http://api.flowlines.io",
                has_traceloop=True,
            )


class TestGetInstrumentors:
    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init._load_instrumentor")
    @patch("flowlines._init.importlib.util")
    def test_returns_instrumentors_for_installed_libs(
        self,
        mock_importlib_util: MagicMock,
        mock_load: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """get_instrumentors() returns instrumentors for installed libraries."""

        # Simulate: openai installed, anthropic not installed, rest not installed.
        def find_spec_side_effect(name: str) -> object | None:
            if name == "openai":
                return MagicMock()
            return None

        mock_importlib_util.find_spec.side_effect = find_spec_side_effect
        mock_instrumentor = MagicMock()
        mock_load.return_value = mock_instrumentor

        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
        )
        result = fl.get_instrumentors()

        assert len(result) == 1
        assert result[0] is mock_instrumentor
        mock_load.assert_called_once_with(
            "opentelemetry.instrumentation.openai",
            "OpenAIInstrumentor",
        )

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.importlib.util")
    def test_returns_empty_list_when_no_libs_installed(
        self,
        mock_importlib_util: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """get_instrumentors() returns empty list when no libraries are installed."""
        mock_importlib_util.find_spec.return_value = None

        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
        )
        result = fl.get_instrumentors()

        assert result == []

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init._load_instrumentor")
    @patch("flowlines._init.importlib.util")
    def test_skips_instrumentor_on_import_error(
        self,
        mock_importlib_util: MagicMock,
        mock_load: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """get_instrumentors() skips instrumentors that fail to import."""
        mock_importlib_util.find_spec.return_value = MagicMock()
        mock_load.side_effect = ImportError("missing module")

        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
        )
        result = fl.get_instrumentors()

        assert result == []


class TestCreateSpanProcessor:
    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_returns_flowlines_span_processor(
        self,
        mock_exporter_cls: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """create_span_processor() returns a FlowlinesSpanProcessor."""
        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
        )
        result = fl.create_span_processor()

        assert isinstance(result, FlowlinesSpanProcessor)
        mock_exporter_cls.assert_called_once_with(
            api_key="key",
            endpoint="https://example.com",
        )

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_tracks_batch_processor_for_shutdown(
        self,
        mock_exporter_cls: MagicMock,
        mock_bsp_cls: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """create_span_processor() stores the inner BatchSpanProcessor for shutdown."""
        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
        )
        processor = fl.create_span_processor()

        assert isinstance(processor, FlowlinesSpanProcessor)
        assert fl._processor is mock_bsp_cls.return_value

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_raises_on_second_call(
        self,
        _mock_exporter_cls: MagicMock,
        _mock_bsp_cls: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """create_span_processor() raises RuntimeError when called twice."""
        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
        )
        fl.create_span_processor()

        with pytest.raises(RuntimeError, match="already been called"):
            fl.create_span_processor()


class TestShutdown:
    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_mode_a_flushes_and_shuts_down_provider(
        self,
        _mock_exporter_cls: MagicMock,
        _mock_bsp_cls: MagicMock,
        mock_trace: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """In Mode A, shutdown() flushes and shuts down the TracerProvider."""
        fl = Flowlines(api_key="key", endpoint="https://example.com")

        # Replace provider with mock to verify calls.
        mock_provider = MagicMock(spec=TracerProvider)
        fl._provider = mock_provider
        fl.shutdown()

        mock_provider.force_flush.assert_called_once()
        mock_provider.shutdown.assert_called_once()
        mock_provider.assert_has_calls(
            [call.force_flush(), call.shutdown()],
        )

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_mode_b2_flushes_and_shuts_down_processor(
        self,
        _mock_exporter_cls: MagicMock,
        mock_bsp_cls: MagicMock,
        mock_trace: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """In Mode B2, shutdown() flushes and shuts down the span processor."""
        existing_provider = MagicMock(spec=TracerProvider)
        mock_trace.get_tracer_provider.return_value = existing_provider
        mock_processor = mock_bsp_cls.return_value

        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_traceloop=True,
        )
        fl.shutdown()

        mock_processor.force_flush.assert_called_once()
        mock_processor.shutdown.assert_called_once()
        mock_processor.assert_has_calls(
            [call.force_flush(), call.shutdown()],
        )

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_mode_b1_shutdown_after_create_processor(
        self,
        _mock_exporter_cls: MagicMock,
        mock_bsp_cls: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """In Mode B1, shutdown() flushes the user-created processor."""
        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
        )
        fl.create_span_processor()
        mock_processor = mock_bsp_cls.return_value

        fl.shutdown()

        mock_processor.force_flush.assert_called_once()
        mock_processor.shutdown.assert_called_once()

    @patch("flowlines._init.atexit", autospec=True)
    @patch("flowlines._init.trace", autospec=True)
    @patch("flowlines._init.BatchSpanProcessor", autospec=True)
    @patch("flowlines._init.FlowlinesExporter", autospec=True)
    def test_shutdown_is_idempotent(
        self,
        _mock_exporter_cls: MagicMock,
        mock_bsp_cls: MagicMock,
        mock_trace: MagicMock,
        mock_atexit: MagicMock,
    ) -> None:
        """Calling shutdown() multiple times only flushes/shuts down once."""
        existing_provider = MagicMock(spec=TracerProvider)
        mock_trace.get_tracer_provider.return_value = existing_provider
        mock_processor = mock_bsp_cls.return_value

        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_traceloop=True,
        )
        fl.shutdown()
        fl.shutdown()
        fl.shutdown()

        assert mock_processor.force_flush.call_count == 1
        assert mock_processor.shutdown.call_count == 1

    @patch("flowlines._init.atexit", autospec=True)
    def test_mode_b1_shutdown_without_processor_is_safe(
        self,
        mock_atexit: MagicMock,
    ) -> None:
        """In Mode B1, shutdown() without create_span_processor() is safe."""
        fl = Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
        )
        fl.shutdown()  # Should not raise


class TestVerboseMode:
    """Tests for verbose logging mode."""

    @pytest.fixture(autouse=True)
    def _cleanup_logger(self) -> None:
        """Remove handlers added by verbose mode after each test."""
        yield  # type: ignore[misc]
        flowlines_logger = logging.getLogger("flowlines")
        flowlines_logger.handlers.clear()
        flowlines_logger.setLevel(logging.WARNING)

    @patch("flowlines._init.atexit", autospec=True)
    def test_verbose_enables_debug_logging(
        self,
        _mock_atexit: MagicMock,
    ) -> None:
        """verbose=True sets the flowlines logger to DEBUG with a handler."""
        Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
            verbose=True,
        )

        flowlines_logger = logging.getLogger("flowlines")
        assert flowlines_logger.level == logging.DEBUG
        assert len(flowlines_logger.handlers) >= 1

    @patch("flowlines._init.atexit", autospec=True)
    def test_no_verbose_does_not_add_handler(
        self,
        _mock_atexit: MagicMock,
    ) -> None:
        """Without verbose, the flowlines logger has no handlers added."""
        flowlines_logger = logging.getLogger("flowlines")
        handlers_before = len(flowlines_logger.handlers)

        Flowlines(
            api_key="key",
            endpoint="https://example.com",
            has_external_otel=True,
        )

        assert len(flowlines_logger.handlers) == handlers_before

    @patch("flowlines._init.atexit", autospec=True)
    def test_verbose_emits_init_messages(
        self,
        _mock_atexit: MagicMock,
        caplog: pytest.LogCaptureFixture,
    ) -> None:
        """verbose=True emits initialization log messages."""
        with caplog.at_level(logging.DEBUG, logger="flowlines"):
            Flowlines(
                api_key="key",
                endpoint="https://example.com",
                has_external_otel=True,
                verbose=True,
            )

        assert any("Initializing Flowlines SDK" in r.message for r in caplog.records)
        assert any("initialized successfully" in r.message for r in caplog.records)
