"""Shared fixtures for integration tests."""

from __future__ import annotations

import contextlib
import gzip
import json
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import TYPE_CHECKING

import pytest
from google.protobuf.json_format import MessageToDict
from opentelemetry.proto.collector.trace.v1.trace_service_pb2 import (
    ExportTraceServiceRequest,
)

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator

# ---------------------------------------------------------------------------
# Skip helpers for API keys
# ---------------------------------------------------------------------------


def _skip_unless_openai() -> None:
    """Skip the current test unless the OpenAI API key and package are available."""
    if not os.environ.get("OPENAI_API_KEY"):
        pytest.skip("OPENAI_API_KEY not set")
    try:
        import openai  # noqa: F401
    except ImportError:
        pytest.skip("openai not installed")


def _skip_unless_anthropic() -> None:
    """Skip the current test unless the Anthropic API key and package are available."""
    if not os.environ.get("ANTHROPIC_API_KEY"):
        pytest.skip("ANTHROPIC_API_KEY not set")
    try:
        import anthropic  # noqa: F401
    except ImportError:
        pytest.skip("anthropic not installed")


def _skip_unless_gemini() -> None:
    """Skip the current test unless the Gemini API key and package are available."""
    if not os.environ.get("GEMINI_API_KEY"):
        pytest.skip("GEMINI_API_KEY not set")
    try:
        import google.genai  # noqa: F401
    except ImportError:
        pytest.skip("google-genai not installed")


# ---------------------------------------------------------------------------
# In-process OTLP capture server
# ---------------------------------------------------------------------------


class OTLPCaptureServer:
    """Threaded HTTP server that captures OTLP trace export requests."""

    def __init__(self) -> None:
        self._records: list[dict] = []
        self._lock = threading.Lock()

        # Create a per-instance handler class to avoid shared state
        server_ref = self

        class _Handler(BaseHTTPRequestHandler):
            def do_POST(self) -> None:  # noqa: N802
                if self.path != "/v1/traces":
                    self.send_response(404)
                    self.end_headers()
                    return

                content_length = int(self.headers.get("Content-Length", 0))
                raw_body = self.rfile.read(content_length)

                if self.headers.get("Content-Encoding") == "gzip":
                    raw_body = gzip.decompress(raw_body)

                content_type = self.headers.get("Content-Type", "")
                if "application/json" in content_type:
                    body: dict = json.loads(raw_body)
                else:
                    req = ExportTraceServiceRequest()
                    req.ParseFromString(raw_body)
                    body = MessageToDict(req, preserving_proto_field_name=True)

                headers = {k: v for k, v in self.headers.items()}
                record = {
                    "headers": headers,
                    "body": body,
                }

                with server_ref._lock:
                    server_ref._records.append(record)

                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b"{}")

            def log_message(self, format: str, *args: object) -> None:  # noqa: A002
                pass

        self._server = HTTPServer(("127.0.0.1", 0), _Handler)
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    @property
    def port(self) -> int:
        return self._server.server_address[1]

    @property
    def endpoint(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    def get_records(self) -> list[dict]:
        with self._lock:
            return list(self._records)

    def get_spans(self) -> list[dict]:
        """Extract a flat list of spans from all received records."""
        spans: list[dict] = []
        for record in self.get_records():
            for rs in record["body"].get("resource_spans", []):
                for ss in rs.get("scope_spans", []):
                    spans.extend(ss.get("spans", []))
        return spans

    def wait_for_spans(self, min_count: int = 1, timeout: float = 30.0) -> list[dict]:
        """Poll until at least *min_count* spans have been received."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            spans = self.get_spans()
            if len(spans) >= min_count:
                return spans
            time.sleep(0.25)
        return self.get_spans()

    def shutdown(self) -> None:
        self._server.shutdown()
        self._thread.join(timeout=5)


# ---------------------------------------------------------------------------
# capture_server factory fixture
# ---------------------------------------------------------------------------


@pytest.fixture()
def capture_server() -> Iterator[Callable[[], OTLPCaptureServer]]:
    """Factory fixture: call it to create a new capture server.

    All servers created during the test are shut down automatically.
    """
    servers: list[OTLPCaptureServer] = []

    def _factory() -> OTLPCaptureServer:
        srv = OTLPCaptureServer()
        servers.append(srv)
        return srv

    yield _factory

    for srv in servers:
        srv.shutdown()


# ---------------------------------------------------------------------------
# OTEL state reset (runs after each test)
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_otel_state() -> Iterator[None]:
    """Reset all OpenTelemetry / Traceloop / Flowlines global state after each test."""
    yield

    # 1. Reset Flowlines singleton
    from flowlines import Flowlines

    Flowlines._reset()

    # 2. Shut down the active TracerProvider if it's an SDK provider
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider as SDKTracerProvider

    provider = trace.get_tracer_provider()
    if isinstance(provider, SDKTracerProvider):
        with contextlib.suppress(Exception):
            provider.shutdown()

    # 3. Reset OTel global tracer provider
    from opentelemetry.util._once import Once

    trace._TRACER_PROVIDER = None  # type: ignore[attr-defined]
    trace._TRACER_PROVIDER_SET_ONCE = Once()  # type: ignore[attr-defined]

    # 4. Reset Traceloop's TracerWrapper singleton
    try:
        from traceloop.sdk.tracing.tracing import TracerWrapper

        if hasattr(TracerWrapper, "instance"):
            del TracerWrapper.instance
        TracerWrapper.endpoint = None  # type: ignore[assignment]
    except ImportError:
        pass

    # 5. Uninstrument OpenAI instrumentor
    try:
        from opentelemetry.instrumentation.openai import OpenAIInstrumentor

        OpenAIInstrumentor().uninstrument()
    except Exception:
        pass

    # 6. Uninstrument Anthropic instrumentor
    try:
        from opentelemetry.instrumentation.anthropic import AnthropicInstrumentor

        AnthropicInstrumentor().uninstrument()
    except Exception:
        pass

    # 7. Uninstrument Google Generative AI instrumentor
    try:
        from opentelemetry.instrumentation.google_generativeai import (
            GoogleGenerativeAiInstrumentor,
        )

        GoogleGenerativeAiInstrumentor().uninstrument()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Helper: simple OpenAI call
# ---------------------------------------------------------------------------


def make_openai_call(
    flowlines: object | None = None,
    *,
    user_id: str | None = None,
    session_id: str | None = None,
    agent_id: str | None = None,
) -> str:
    """Make a minimal OpenAI chat completion call and return the response text.

    When *flowlines* is a ``Flowlines`` instance and *user_id* or
    *session_id* are provided, the call is wrapped in
    ``flowlines.context()`` so that the resulting spans carry those attributes.
    """
    from openai import OpenAI

    client = OpenAI()

    def _call() -> str:
        response = client.chat.completions.create(
            model="gpt-4.1-nano",
            messages=[{"role": "user", "content": "Say 'hello' and nothing else."}],
        )
        return response.choices[0].message.content or ""

    if flowlines is not None and (user_id is not None or session_id is not None):
        with flowlines.context(  # type: ignore[union-attr]
            user_id=user_id, session_id=session_id, agent_id=agent_id
        ):
            return _call()
    return _call()


def make_openai_responses_call(
    flowlines: object | None = None,
    *,
    user_id: str | None = None,
    session_id: str | None = None,
    agent_id: str | None = None,
) -> str:
    """Make a minimal OpenAI Responses API call and return the response text.

    When *flowlines* is a ``Flowlines`` instance and *user_id* or
    *session_id* are provided, the call is wrapped in
    ``flowlines.context()`` so that the resulting spans carry those attributes.
    """
    from openai import OpenAI

    client = OpenAI()

    def _call() -> str:
        response = client.responses.create(
            model="gpt-4.1-nano",
            input=[{"role": "user", "content": "Say 'hello' and nothing else."}],
        )
        return response.output_text or ""

    if flowlines is not None and (user_id is not None or session_id is not None):
        with flowlines.context(  # type: ignore[union-attr]
            user_id=user_id, session_id=session_id, agent_id=agent_id
        ):
            return _call()
    return _call()


# ---------------------------------------------------------------------------
# Helper: simple Anthropic call
# ---------------------------------------------------------------------------


def make_anthropic_call(
    flowlines: object | None = None,
    *,
    user_id: str | None = None,
    session_id: str | None = None,
    agent_id: str | None = None,
) -> str:
    """Make a minimal Anthropic message call and return the response text.

    When *flowlines* is a ``Flowlines`` instance and *user_id* or
    *session_id* are provided, the call is wrapped in
    ``flowlines.context()`` so that the resulting spans carry those attributes.
    """
    from anthropic import Anthropic

    client = Anthropic()

    def _call() -> str:
        response = client.messages.create(
            model="claude-haiku-4-5",
            max_tokens=100,
            messages=[{"role": "user", "content": "Say 'hello' and nothing else."}],
        )
        return response.content[0].text if response.content else ""

    if flowlines is not None and (user_id is not None or session_id is not None):
        with flowlines.context(  # type: ignore[union-attr]
            user_id=user_id, session_id=session_id, agent_id=agent_id
        ):
            return _call()
    return _call()


# ---------------------------------------------------------------------------
# Helper: simple Gemini call
# ---------------------------------------------------------------------------


def make_gemini_call(
    flowlines: object | None = None,
    *,
    user_id: str | None = None,
    session_id: str | None = None,
    agent_id: str | None = None,
) -> str:
    """Make a minimal Google Gemini call and return the response text.

    When *flowlines* is a ``Flowlines`` instance and *user_id* or
    *session_id* are provided, the call is wrapped in
    ``flowlines.context()`` so that the resulting spans carry those attributes.
    """
    from google import genai

    client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])

    def _call() -> str:
        response = client.models.generate_content(
            model="gemini-2.5-flash-lite",
            contents="Say 'hello' and nothing else.",
        )
        return response.text or ""

    if flowlines is not None and (user_id is not None or session_id is not None):
        with flowlines.context(  # type: ignore[union-attr]
            user_id=user_id, session_id=session_id, agent_id=agent_id
        ):
            return _call()
    return _call()
