# OpenAI Conversational Agent Example

A simple interactive agent that uses the OpenAI Responses API with tool calling, fully instrumented by the Flowlines SDK.

## Prerequisites

- Python 3.11+
- An OpenAI API key
- A Flowlines API key

## Setup

1. Install dependencies from the repo root:

   ```bash
   uv sync --group examples
   ```

2. Copy the environment template and fill in your keys:

   ```bash
   cp examples/openai/.env.example examples/openai/.env
   ```

3. Run the agent:

   ```bash
   uv run python examples/openai/agent.py
   ```

## What it demonstrates

- **Flowlines Mode A** (automatic setup) — `Flowlines(api_key=...)` creates a `TracerProvider` and registers all available instrumentors.
- **Auto-instrumentation** — The `OpenAI()` client is created *after* Flowlines initialisation, so all API calls are traced automatically.
- **Context propagation** — `flowlines.context(user_id=..., session_id=...)` attaches user and session identifiers to every span in the session.
- **Tool calling** — The agent uses a `get_city_info` tool. The tool-call loop shows how multi-step interactions appear in traces.

## Available cities

Paris, Tokyo, New York, Sydney, Nairobi.

Try asking: *"Tell me about Tokyo"* or *"What's a fun fact about Nairobi?"*
