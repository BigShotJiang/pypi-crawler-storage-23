# Publishing to PyPI

## Prerequisites

1. Install the build tools:

   ```bash
   uv tool install twine
   ```

2. Create accounts and API tokens:
   - **TestPyPI**: https://test.pypi.org/account/register/ — create an API token at https://test.pypi.org/manage/account/
   - **PyPI**: https://pypi.org/account/register/ — create an API token at https://pypi.org/manage/account/

## Bump the version

Edit `version` in `pyproject.toml`:

```toml
version = "0.2.0"
```

## Build

```bash
rm -rf dist/
uv build
```

This produces `dist/flowlines-<version>.tar.gz` and `dist/flowlines-<version>-py3-none-any.whl`.

## Publish to TestPyPI

```bash
uvx twine upload --repository testpypi dist/*
```

You will be prompted for credentials. Use `__token__` as the username and your TestPyPI API token as the password.

Verify the result at `https://test.pypi.org/project/flowlines/`.

To install from TestPyPI and check it works:

```bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ flowlines
```

(`--extra-index-url` is needed so that dependencies are still fetched from the real PyPI.)

## Publish to PyPI

Once you're satisfied with the TestPyPI release:

```bash
uvx twine upload dist/*
```

Use `__token__` as the username and your PyPI API token as the password.

Verify the result at `https://pypi.org/project/flowlines/`.
