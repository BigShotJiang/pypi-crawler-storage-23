"""Filtering logic for LLM-related spans."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from opentelemetry.sdk.trace import ReadableSpan


def is_llm_span(span: ReadableSpan) -> bool:
    """Determine whether a span is LLM-related.

    Returns True if the span has any attribute whose key starts with
    'gen_ai.' or 'ai.'.
    """
    attributes = span.attributes
    if attributes is None:
        return False
    return any(key.startswith("gen_ai.") or key.startswith("ai.") for key in attributes)
