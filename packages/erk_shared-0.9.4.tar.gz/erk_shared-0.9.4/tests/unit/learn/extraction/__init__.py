"""Tests for extraction module."""
