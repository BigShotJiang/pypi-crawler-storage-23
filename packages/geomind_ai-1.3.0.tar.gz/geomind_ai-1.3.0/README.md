<div align="center">

<img src="docs/assets/geomind_git.png" alt="GeoMind Logo" width="200"/>

# GeoMind

**An AI agent for geospatial analysis with Sentinel-2 satellite imagery.**  
Type a plain-English query - GeoMind handles everything else.

[PyPI](https://pypi.org/project/geomind-ai/) · [Docs](https://harshshinde0.github.io/GeoMind)

</div>

---

GeoMind lets you interact with satellite data through natural language. No code, no GIS software, no manual downloads. Describe what you want - GeoMind geocodes the location, searches the satellite archive, streams only the data it needs, and saves the result to your machine in seconds.

It can generate RGB true-color composites, calculate NDVI vegetation indices, apply cloud cover filters, retrieve band statistics, and handle multiple products in a single query. Queries can reference place names, cities, regions, or raw coordinates. A single instruction like "get a recent image of Scotland and its NDVI" will trigger search, composite generation, and vegetation analysis automatically.

---

## How It Works

```
Your query  ->  Geocoding  ->  Catalog search  ->  Stream band data  ->  Image output
"Paris RGB"     Paris coords   Recent scenes      ~1-5 MB via Zarr    outputs/*.png
```

1. **Geocoding** - place name is converted to coordinates and a bounding box
2. **Catalog search** - recent Sentinel-2 L2A scenes retrieved from STAC API
3. **Cloud-native streaming** - only the required band chunks are downloaded (~1–5 MB instead of ~720 MB full scene)
4. **Processing** - bands are scaled, stacked, and rendered as PNG
5. **Output** - image saved to `outputs/` and opened automatically

### Traditional vs GeoMind

```
Traditional:  Full Scene Download -> Local Storage -> Process -> Result
                   ~720 MB            Disk I/O       Slow

GeoMind:      HTTP Range Request  -> Stream Chunks -> Process -> Result
                   ~1-5 MB           No disk         Fast
```

---

## Installation

```bash
pip install geomind-ai
```

---

## Quick Start

**1. Get a free API key** at [openrouter.ai/settings/keys](https://openrouter.ai/settings/keys)

**2. Launch GeoMind:**

```bash
geomind
```

**3. Enter your key on first run** (saved automatically - never asked again):

```
OpenRouter API key required (FREE)
Get yours at: https://openrouter.ai/settings/keys

Enter your API key: sk-or-v1-xxxxxxxxxxxxxxxxxxxxxxxx
API key saved!
```

**4. Start querying:**

```
> get me a recent image of scotland and its ndvi
```

```
Executing: list_recent_imagery({'location_name': 'Scotland'})
Executing: create_rgb_composite({...})
Executing: calculate_ndvi({...})

RGB composite:  outputs/rgb_composite_7066.png
NDVI:           outputs/ndvi_9664.png
NDVI stats:     min -0.72 / max 0.91 / mean 0.34
```

### Single Query Mode

```bash
geomind --query "Find recent imagery of Paris with less than 10% cloud cover"
```

---

## Key Facts

| | |
|:--|:--|
| **Data source** | Sentinel-2 Level-2A (surface reflectance) |
| **Resolution** | 10 m (RGB, NDVI), 20 m (Red Edge, SWIR) |
| **Default AI model** | `nvidia/nemotron-3-nano-30b-a3b:free` via OpenRouter |
| **API key required** | Free OpenRouter account |
| **Output format** | PNG saved to `outputs/` |
| **Data per query** | ~1–5 MB (cloud-native streaming) |
| **Search lookback** | 14 days by default, auto-extends if no results |
| **Max cloud cover** | 50% default, configurable per query |

---

## Requirements

- Python 3.10+
- Free [OpenRouter](https://openrouter.ai) API key

---

## Documentation

Full documentation at **[harshshinde0.github.io/GeoMind](https://harshshinde0.github.io/GeoMind)**

- [Usage Examples](https://harshshinde0.github.io/GeoMind/examples/)
- [CLI Reference](https://harshshinde0.github.io/GeoMind/cli_reference/)
- [Tools Reference](https://harshshinde0.github.io/GeoMind/tools_reference/)
- [Architecture](https://harshshinde0.github.io/GeoMind/architecture/)

