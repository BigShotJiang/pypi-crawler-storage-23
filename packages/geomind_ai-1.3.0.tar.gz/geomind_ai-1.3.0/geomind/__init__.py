"""
GeoMind - Geospatial AI Agent

"""

__version__ = "1.2.0"
__author__ = "Harsh Shinde, Rajat Shinde"

from .agent import GeoMindAgent

__all__ = ["GeoMindAgent"]
