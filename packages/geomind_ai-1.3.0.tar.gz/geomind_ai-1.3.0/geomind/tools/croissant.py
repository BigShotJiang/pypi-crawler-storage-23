"""
Croissant ML metadata generation tools.

Generates GeoCroissant JSON-LD metadata for Sentinel-2 STAC items.
"""

import json
import random
from pathlib import Path
from typing import Optional
from datetime import datetime

from ..config import OUTPUT_DIR
from .stac_search import get_item_details

def generate_croissant_metadata(
    item_id: str,
    location_name: Optional[str] = None,
    output_path: Optional[str] = None,
) -> dict:
    """
    Generate GeoCroissant ML metadata for a Sentinel-2 STAC item.

    Args:
        item_id: STAC item ID
        location_name: Optional location name
        output_path: Optional output path

    Returns:
        Dictionary with path to the generated JSON file and success status.
    """
    try:
        # Fetch item details
        details = get_item_details(item_id)
        if not details["success"]:
            return {"success": False, "error": details["error"]}
        
        item = details["item"]
        properties = item.get("properties", {})
        bbox = item.get("bbox", [-180.0, -90.0, 180.0, 90.0])
        datetime_str = properties.get("datetime", "")
        
        # Build GeoCroissant skeleton based on Croissant standard
        croissant_data = {
          "@context": {
            "@language": "en",
            "@vocab": "https://schema.org/",
            "citeAs": "cr:citeAs",
            "column": "cr:column",
            "conformsTo": "dct:conformsTo",
            "cr": "http://mlcommons.org/croissant/",
            "geocr": "http://mlcommons.org/croissant/geo/",
            "rai": "http://mlcommons.org/croissant/RAI/",
            "dct": "http://purl.org/dc/terms/",
            "sc": "https://schema.org/",
            "data": {
              "@id": "cr:data",
              "@type": "@json"
            },
            "examples": {
              "@id": "cr:examples",
              "@type": "@json"
            },
            "dataType": {
              "@id": "cr:dataType",
              "@type": "@vocab"
            },
            "extract": "cr:extract",
            "field": "cr:field",
            "fileProperty": "cr:fileProperty",
            "fileObject": "cr:fileObject",
            "fileSet": "cr:fileSet",
            "format": "cr:format",
            "includes": "cr:includes",
            "isLiveDataset": "cr:isLiveDataset",
            "jsonPath": "cr:jsonPath",
            "key": "cr:key",
            "md5": "cr:md5",
            "parentField": "cr:parentField",
            "path": "cr:path",
            "recordSet": "cr:recordSet",
            "references": "cr:references",
            "regex": "cr:regex",
            "repeated": "cr:repeated",
            "replace": "cr:replace",
            "samplingRate": "cr:samplingRate",
            "separator": "cr:separator",
            "source": "cr:source",
            "subField": "cr:subField",
            "transform": "cr:transform",
            "equivalentProperty": "cr:equivalentProperty"
          },
          "@type": "sc:Dataset",
          "@id": item.get("id", "dataset_id"),
          "name": item.get("id", "Sentinel-2-Image"),
          "description": f"Sentinel-2 L2A Imagery for {location_name or 'Unknown Location'}",
          "version": "1.0.0",
          "license": "https://creativecommons.org/licenses/by/4.0/",
          "conformsTo": [
            "http://mlcommons.org/croissant/1.1",
            "http://mlcommons.org/croissant/geo/1.0"
          ],
          "citeAs": f"@dataset{{sentinel2_{item_id}, title={{Sentinel-2 {item_id}}}, year={{{datetime.now().year}}}, url={{https://stac.core.eopf.eodc.eu/}}}}",
          "datePublished": datetime.now().strftime("%Y-%m-%d"),
          "spatialCoverage": {
            "@type": "Place",
            "geo": {
              "@type": "GeoShape",
              "box": f"{bbox[1]} {bbox[0]} {bbox[3]} {bbox[2]}"
            }
          },
          "geocr:coordinateReferenceSystem": "EPSG:4326",
          "geocr:spatialResolution": {
            "@type": "QuantitativeValue",
            "value": 10.0,
            "unitText": "meters"
          },
          "temporalCoverage": f"{datetime_str}/{datetime_str}",
          "keywords": [
            "sentinel-2",
            "satellite",
            "imagery",
            "earth-observation"
          ],
          "distribution": [],
          "recordSet": [
            {
              "@type": "cr:RecordSet",
              "@id": "record_set_imagery_bands",
              "name": "imagery_bands",
              "field": []
            }
          ]
        }
        
        # Add assets
        assets = item.get("assets", {})
        
        # To avoid Croissant join validation errors with multiple FileObjects in a single RecordSet,
        # we will use the base Product URL as the single Distribution element
        # and extract variables as properties from that single source
        product_url = ""
        for key, asset in assets.items():
            if key == "product" or "zarr" in asset.get("type", "").lower():
                product_url = asset.get("href", "")
                if key == "product":
                    break

        file_obj_id = "asset_product"
        croissant_data["distribution"].append({
            "@type": "cr:FileObject",
            "@id": file_obj_id,
            "name": "product",
            "contentUrl": product_url,
            "encodingFormat": "application/vnd+zarr",
            "sha256": "placeholder"
        })
        
        band_names = []
        for key, asset in assets.items():
            if "zarr" in asset.get("type", "").lower() or key == "product":
                if "zarr" in asset.get("type", "").lower() and key != "product":
                    band_names.append(key)
                
                # Add to fields pointing to the single file_obj_id source
                # Extract the relative subpath if it differs from the root Zarr URL
                source_dict = {
                    "fileObject": {
                        "@id": file_obj_id
                    }
                }
                
                asset_href = asset.get("href", "")
                if product_url and asset_href.startswith(product_url) and asset_href != product_url:
                    subpath = asset_href[len(product_url):].lstrip("/")
                    source_dict["extract"] = {
                        "column": subpath
                    }

                croissant_data["recordSet"][0]["field"].append({
                    "@type": "cr:Field",
                    "@id": f"field_{key}",
                    "name": key,
                    "description": asset.get("title", f"Sentinel-2 Band {key}"),
                    "dataType": "sc:Float",
                    "source": source_dict
                })
        
        # Add GeoCroissant band metadata mapping
        if band_names:
            croissant_data["geocr:bandConfiguration"] = {
                "@type": "geocr:BandConfiguration",
                "geocr:totalBands": len(band_names),
                "geocr:bandNamesList": band_names
            }
        
        # Save to file
        if output_path is None:
            output_dir = Path(OUTPUT_DIR)
            output_dir.mkdir(exist_ok=True, parents=True)
            output_path = output_dir / f"croissant_{item_id}_{random.randint(1000, 9999)}.json"
        else:
            output_path = Path(output_path)
            
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(croissant_data, f, indent=2)
            
        return {
            "success": True,
            "output_path": str(output_path),
            "item_id": item_id,
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }
