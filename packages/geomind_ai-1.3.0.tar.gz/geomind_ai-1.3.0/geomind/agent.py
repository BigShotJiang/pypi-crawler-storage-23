"""
GeoMind Agent - Simplified AI agent for satellite imagery analysis.
"""

import json
from typing import Optional
from datetime import datetime
from openai import OpenAI

from .config import OPENROUTER_API_KEY, OPENROUTER_API_URL, OPENROUTER_MODEL
from .tools import (
    list_recent_imagery,
    create_rgb_composite,
    calculate_ndvi,
    search_imagery,
    get_bbox_from_location,
    geocode_location,
    get_item_details,
    get_band_statistics,
    generate_croissant_metadata,
)

# Tool function mapping
TOOL_FUNCTIONS = {
    "list_recent_imagery": list_recent_imagery,
    "create_rgb_composite": create_rgb_composite,
    "calculate_ndvi": calculate_ndvi,
    "search_imagery": search_imagery,
    "get_bbox_from_location": get_bbox_from_location,
    "geocode_location": geocode_location,
    "get_item_details": get_item_details,
    "get_band_statistics": get_band_statistics,
    "generate_croissant_metadata": generate_croissant_metadata,
}

# Simplified tool definitions
TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "list_recent_imagery",
            "description": "Find recent Sentinel-2 imagery for a location",
            "parameters": {
                "type": "object",
                "properties": {
                    "location_name": {"type": "string", "description": "Location name"},
                    "days": {"type": "integer", "description": "Days to look back (default: 14)"},
                    "max_cloud_cover": {"type": "number", "description": "Max cloud cover %"},
                    "max_items": {"type": "integer", "description": "Max results"},
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_rgb_composite",
            "description": "Create RGB composite from Sentinel-2 data",
            "parameters": {
                "type": "object",
                "properties": {
                    "zarr_url": {"type": "string", "description": "SR_10m Zarr URL"},
                    "location_name": {"type": "string", "description": "Location for title"},
                    "subset_size": {"type": "integer", "description": "Image size (default: 1000)"},
                },
                "required": ["zarr_url"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "calculate_ndvi",
            "description": "Calculate NDVI vegetation index",
            "parameters": {
                "type": "object",
                "properties": {
                    "zarr_url": {"type": "string", "description": "SR_10m Zarr URL"},
                    "location_name": {"type": "string", "description": "Location for title"},
                    "subset_size": {"type": "integer", "description": "Image size (default: 1000)"},
                },
                "required": ["zarr_url"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search_imagery",
            "description": "Search Sentinel-2 imagery by parameters",
            "parameters": {
                "type": "object",
                "properties": {
                    "bbox": {"type": "array", "items": {"type": "number"}, "description": "Bounding box"},
                    "start_date": {"type": "string", "description": "Start date YYYY-MM-DD"},
                    "end_date": {"type": "string", "description": "End date YYYY-MM-DD"},
                    "max_cloud_cover": {"type": "number", "description": "Max cloud cover %"},
                    "max_items": {"type": "integer", "description": "Max results"},
                },
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_bbox_from_location",
            "description": "Get bounding box for a location",
            "parameters": {
                "type": "object",
                "properties": {
                    "place_name": {"type": "string", "description": "Location name"},
                    "buffer_km": {"type": "number", "description": "Buffer distance in km"},
                },
                "required": ["place_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "generate_croissant_metadata",
            "description": "Generate GeoCroissant ML-ready dataset metadata (JSON) for a Sentinel-2 imagery item",
            "parameters": {
                "type": "object",
                "properties": {
                    "item_id": {"type": "string", "description": "STAC item ID (from search results)"},
                    "location_name": {"type": "string", "description": "Optional location name context"},
                },
                "required": ["item_id"],
            },
        },
    },
]


class GeoMindAgent:
    """Simplified GeoMind agent for satellite imagery analysis."""

    def __init__(self, model: Optional[str] = None, api_key: Optional[str] = None):
        self.api_key = api_key or OPENROUTER_API_KEY
        self.model_name = model or OPENROUTER_MODEL
        
        if not self.api_key:
            raise ValueError("OpenRouter API key required")
            
        print(f"GeoMind Agent initialized with {self.model_name}")
        self.client = OpenAI(base_url=OPENROUTER_API_URL, api_key=self.api_key)
        self.history = []

    def _get_system_prompt(self) -> str:
        """Short, focused system prompt."""
        return f"""You are GeoMind, an AI assistant for satellite imagery analysis using Sentinel-2 data.

Current date: {datetime.now().strftime('%Y-%m-%d')}

KEY RULES:
1. Use list_recent_imagery to find satellite data for locations
2. Extract Zarr URLs from results: item['zarr_assets']['SR_10m']['href'] 
3. Always include location_name parameter when creating images
4. Use actual function response data in your answers (don't make up paths/stats)
5. Let functions use default output paths (saves to outputs/ folder as .png)
6. When the user asks for ML-ready data, JSON datasets, GeoCroissant, or Croissant metadata: FIRST use list_recent_imagery to find an item_id, THEN call generate_croissant_metadata with that item_id, and confirm to the user that the file was generated with the saved path.

Be helpful and accurate - always use real data from function responses."""

    def chat(self, message: str, verbose: bool = True) -> str:
        """Send message to agent and get response."""
        if verbose:
            print(f"\nUser: {message}")
            print("Processing...")

        self.history.append({"role": "user", "content": message})
        messages = [{"role": "system", "content": self._get_system_prompt()}] + self.history

        for _ in range(10):  # Max 10 iterations
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=messages,
                tools=TOOLS,
                tool_choice="auto",
                max_tokens=4096,
            )

            choice = response.choices[0]
            assistant_message = choice.message

            tool_calls = assistant_message.tool_calls
            if tool_calls:
                # Add assistant message with tool calls
                messages.append({
                    "role": "assistant",
                    "content": assistant_message.content or "",
                    "tool_calls": [
                        {
                            "id": tc.id,
                            "type": "function",
                            "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                        }
                        for tc in tool_calls
                    ],
                })

                # Execute tool calls
                for tool_call in tool_calls:
                    func_name = tool_call.function.name
                    func_args = json.loads(tool_call.function.arguments)
                    
                    print(f"  Executing: {func_name}({func_args})")
                    
                    try:
                        result = TOOL_FUNCTIONS[func_name](**func_args)
                    except Exception as e:
                        result = {"error": str(e)}

                    messages.append({
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": json.dumps(result, default=str),
                    })
            else:
                # Final response
                final_text = assistant_message.content or ""
                self.history.append({"role": "assistant", "content": final_text})
                
                if verbose:
                    print(f"\nGeoMind: {final_text}")
                    
                return final_text

        return "Max iterations reached"

    def reset(self):
        """Reset chat history."""
        self.history = []
