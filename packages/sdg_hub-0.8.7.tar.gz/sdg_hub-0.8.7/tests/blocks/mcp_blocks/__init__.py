# SPDX-License-Identifier: Apache-2.0
"""Tests for MCP blocks."""
