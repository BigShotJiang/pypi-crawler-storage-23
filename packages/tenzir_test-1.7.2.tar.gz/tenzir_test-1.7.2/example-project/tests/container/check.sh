#!/bin/sh
set -eu

echo "container runtime: ${CONTAINER_RUNTIME}"
