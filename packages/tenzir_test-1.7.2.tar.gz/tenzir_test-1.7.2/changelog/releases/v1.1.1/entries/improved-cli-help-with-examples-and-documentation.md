---
title: Improved CLI help with examples and documentation
type: change
authors:
  - mavam
  - claude
pr: 12
created: 2026-02-02T16:39:09.760492Z
---

The help text for the `tenzir-test` command now provides more context and guidance.

The command description now explains the baseline comparison behavior and shows how to regenerate baselines with the `--update` flag.
