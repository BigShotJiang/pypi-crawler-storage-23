#! /usr/bin/env bash

alias @academy=bluer_academy

# ignore

alias @a=bluer_academy
