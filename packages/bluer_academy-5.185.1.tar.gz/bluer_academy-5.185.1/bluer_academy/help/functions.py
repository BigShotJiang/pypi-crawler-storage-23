from bluer_ai.help.generic import help_functions as generic_help_functions

from bluer_academy import ALIAS


help_functions = generic_help_functions(plugin_name=ALIAS)
