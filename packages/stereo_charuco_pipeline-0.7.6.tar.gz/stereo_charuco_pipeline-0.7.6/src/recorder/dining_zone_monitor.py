"""Dining Zone Monitor — 就餐区域占用检测 + IP 摄像头触发

独立于姿态录制系统，并行运行。

状态机
------
                    ┌─── 人进入 zone ───────────────────────────────┐
                    │                                               │
    EMPTY ──────────┤           OCCUPIED                   COOLDOWN│
    (无人)          │  (有人，每 photo_interval 秒拍一张)   (人离开，等待)
                    │                   │                           │
                    │          人离开 zone                  5分钟无人
                    │                   └─────────────────→ EMPTY  │
                    │                                               │
                    └───────────────────── 人回来 ──────────────────┘

"人在 zone" 的判断规则
---------------------
overlap_ratio = 交叉面积 / 人的 bbox 面积
如果 overlap_ratio >= overlap_threshold (默认 0.5)，视为"人在 zone 内"。
即：人的身体有一半以上在 zone 范围内 → 算进入。
"""
from __future__ import annotations

import json
import logging
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from .ip_camera_trigger import IPCameraTrigger, StubIPCameraTrigger

logger = logging.getLogger(__name__)

# 归一化 bbox 类型: (x1, y1, x2, y2)，坐标范围 [0, 1]
NormBox = Tuple[float, float, float, float]


class DiningZoneMonitor:
    """
    监控就餐区域，驱动 IP 摄像头拍照。

    参数
    ----
    zone : dict
        {x1, y1, x2, y2} 归一化坐标（来自 dining_zone.toml）。
    trigger : IPCameraTrigger
        摄像头触发实现（StubIPCameraTrigger / RTSPIPCameraTrigger 等）。
    recordings_dir : Path
        照片保存的根目录，每次就餐创建子目录。
    absence_timeout : float
        多少秒无人 → 就餐结束（默认 300 = 5 分钟）。
    photo_interval : float
        多少秒拍一张（默认 30 秒）。
    overlap_threshold : float
        bbox 与 zone 的重叠比例阈值（默认 0.5 = 身体一半进入）。
    on_state_change : Callable[[str, dict], None]
        状态变化回调，供 UI 更新显示。
        参数: (new_state, info_dict)
        info_dict 包含 session_id, photo_count, cooldown_remaining 等。
    on_session_end : Callable[[str, Path, dict], None]
        会话结束回调，供分析器使用。
        参数: (session_id, save_dir, session_meta_dict)
        在 session_meta.json 保存后调用。
    """

    EMPTY    = "empty"
    OCCUPIED = "occupied"
    COOLDOWN = "cooldown"

    def __init__(
        self,
        zone: dict,
        trigger: Optional[IPCameraTrigger] = None,
        recordings_dir: Path = Path("recordings"),
        absence_timeout: float = 300.0,
        photo_interval: float = 30.0,
        overlap_threshold: float = 0.5,
        on_state_change: Optional[Callable[[str, dict], None]] = None,
        on_session_end: Optional[Callable[[str, Path, dict], None]] = None,
    ):
        self.zone = zone
        self.trigger = trigger or StubIPCameraTrigger()
        self.recordings_dir = recordings_dir
        self.absence_timeout = absence_timeout
        self.photo_interval = photo_interval
        self.overlap_threshold = overlap_threshold
        self.on_state_change = on_state_change
        self.on_session_end = on_session_end

        self._state = self.EMPTY
        self._session_id: Optional[str] = None
        self._save_dir: Optional[Path] = None
        self._photo_index = 0
        self._photo_timestamps: List[Dict] = []   # per-photo timestamp records
        self._session_start: float = 0.0
        self._last_seen: float = 0.0      # 最近一次检测到人的时间
        self._last_photo: float = 0.0     # 最近一次拍照时间
        self._lock = threading.Lock()

    # ── 公开属性（供 UI 读取）────────────────────────────────

    @property
    def state(self) -> str:
        return self._state

    @property
    def session_id(self) -> Optional[str]:
        return self._session_id

    @property
    def photo_count(self) -> int:
        return self._photo_index

    @property
    def cooldown_remaining(self) -> float:
        if self._state != self.COOLDOWN:
            return 0.0
        return max(0.0, self.absence_timeout - (time.time() - self._last_seen))

    @property
    def session_elapsed(self) -> float:
        if self._session_start == 0.0:
            return 0.0
        return time.time() - self._session_start

    # ── 核心更新（每帧调用）──────────────────────────────────

    def update(self, person_boxes_norm: List[NormBox]):
        """
        每帧从 UI 定时器调用。

        person_boxes_norm : 检测到的人的 bbox 列表，已归一化到 [0,1]。
            坐标相对于左相机画面（与 zone 坐标系一致）。
            格式: [(x1, y1, x2, y2), ...]
            空列表 = 本帧没有检测到人。
        """
        now = time.time()
        in_zone = self._any_person_in_zone(person_boxes_norm)

        with self._lock:
            if self._state == self.EMPTY:
                if in_zone:
                    self._enter_occupied(now)

            elif self._state == self.OCCUPIED:
                if in_zone:
                    self._last_seen = now
                    if now - self._last_photo >= self.photo_interval:
                        self._shoot(now)
                else:
                    self._last_seen = now
                    self._state = self.COOLDOWN
                    logger.info(
                        f"[DiningZone] Person left zone, cooldown started "
                        f"({self.absence_timeout:.0f}s)"
                    )
                    self._notify()

            elif self._state == self.COOLDOWN:
                if in_zone:
                    self._last_seen = now
                    self._state = self.OCCUPIED
                    logger.info("[DiningZone] Person returned, resuming session")
                    self._notify()
                elif now - self._last_seen >= self.absence_timeout:
                    self._end_session(now)

    # ── 状态转换 ─────────────────────────────────────────────

    def _enter_occupied(self, now: float):
        self._state = self.OCCUPIED
        self._session_start = now
        self._last_seen = now
        self._photo_index = 0
        self._photo_timestamps = []
        ts = datetime.fromtimestamp(now).strftime("%Y%m%d_%H%M%S")
        self._session_id = f"dining_{ts}"
        self._save_dir = (
            self.recordings_dir / self._session_id / "dining_photos"
        )
        self._save_dir.mkdir(parents=True, exist_ok=True)

        logger.info(f"[DiningZone] Session started: {self._session_id}")
        try:
            self.trigger.start_session(self._session_id, self._save_dir)
        except Exception as e:
            logger.error(f"[DiningZone] trigger.start_session error: {e}")

        self._shoot(now)   # 立刻拍第一张
        self._notify()

    def _shoot(self, now: float):
        self._last_photo = now
        idx = self._photo_index
        self._photo_index += 1
        # 记录照片时间戳
        self._photo_timestamps.append({
            "index": idx,
            "timestamp": now,
            "filename": f"photo_{idx:03d}.jpg",
        })
        # 在独立线程中拍照，避免阻塞 UI
        threading.Thread(
            target=self._shoot_worker,
            args=(self._session_id, idx, self._save_dir),
            daemon=True,
        ).start()

    def _shoot_worker(self, session_id: str, index: int, save_dir: Path):
        try:
            self.trigger.take_photo(session_id, index, save_dir)
        except Exception as e:
            logger.error(f"[DiningZone] trigger.take_photo error: {e}")

    def _end_session(self, now: float):
        duration = now - self._session_start
        sid = self._session_id
        save_dir = self._save_dir
        logger.info(
            f"[DiningZone] Session ended: {sid}  "
            f"duration={duration/60:.1f}min  photos={self._photo_index}"
        )
        try:
            self.trigger.stop_session(sid)
        except Exception as e:
            logger.error(f"[DiningZone] trigger.stop_session error: {e}")

        # 保存会话元数据（供 DiningAnalyzer 使用）
        meta = {
            "session_id": sid,
            "session_start": self._session_start,
            "session_end": now,
            "duration_seconds": duration,
            "photo_count": self._photo_index,
            "photos": list(self._photo_timestamps),
        }
        if save_dir is not None:
            try:
                meta_path = save_dir / "session_meta.json"
                meta_path.write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
                logger.info(f"[DiningZone] session_meta.json saved: {meta_path}")
            except Exception as e:
                logger.error(f"[DiningZone] failed to save session_meta.json: {e}")

        self._state = self.EMPTY
        self._session_id = None
        self._save_dir = None
        self._photo_index = 0
        self._photo_timestamps = []
        self._session_start = 0.0
        self._notify()

        # 触发分析回调（在状态清空后调用，避免竞态）
        if self.on_session_end is not None and save_dir is not None:
            try:
                self.on_session_end(sid, save_dir, meta)
            except Exception as e:
                logger.warning(f"[DiningZone] on_session_end callback error: {e}")

    def _notify(self):
        if self.on_state_change is None:
            return
        info = {
            "session_id": self._session_id,
            "photo_count": self._photo_index,
            "cooldown_remaining": self.cooldown_remaining,
            "session_elapsed": self.session_elapsed,
        }
        try:
            self.on_state_change(self._state, info)
        except Exception as e:
            logger.warning(f"[DiningZone] on_state_change callback error: {e}")

    # ── 区域检测 ─────────────────────────────────────────────

    def _any_person_in_zone(self, boxes: List[NormBox]) -> bool:
        """
        判断规则: bbox 与 zone 的重叠面积 / bbox 面积 >= overlap_threshold。
        即"人的身体有一半以上进入 zone" → 视为在 zone 内。
        """
        z = self.zone
        for (px1, py1, px2, py2) in boxes:
            person_area = (px2 - px1) * (py2 - py1)
            if person_area <= 0:
                continue
            # 计算交叉矩形
            ix1 = max(z["x1"], px1)
            iy1 = max(z["y1"], py1)
            ix2 = min(z["x2"], px2)
            iy2 = min(z["y2"], py2)
            if ix2 <= ix1 or iy2 <= iy1:
                continue   # 无重叠
            overlap_area = (ix2 - ix1) * (iy2 - iy1)
            ratio = overlap_area / person_area
            if ratio >= self.overlap_threshold:
                return True
        return False
