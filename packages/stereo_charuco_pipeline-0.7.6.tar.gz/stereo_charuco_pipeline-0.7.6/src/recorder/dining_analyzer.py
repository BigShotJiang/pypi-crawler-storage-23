"""Dining Session Photo Analyzer — 就餐照片选择 + GPT-4o 食物分析

从一次就餐会话的系列照片中自动选出 3 张代表性照片（开始 / 中间 / 结束），
然后调用 GPT-4o Vision API 分析食物摄入情况，保存结构化的 analysis.json。

照片选择算法
------------
1. 有效照片池  —— 质量过滤（清晰度 ≥ 70 + 亮度 [100,200]）
               + 食物内容过滤（中心区域饱和度 > 40 的像素 ≥ 10%）
2. 开始照片    —— 连续 3 张偏差 < 10% 的第一张（盘面稳定），退路：第一张有效照片
3. 结束照片    —— 最后一张有效照片
4. 中间照片    —— 时间轴 10%–90% 窗口内食物变化量最大的照片；
               若所有变化 < 5% 则退路为最接近中点的照片
5. 最终验证    —— 时间跨度 ≥ 80% 总时长；每张照片有效性复核 + 最近有效替换；
               有效照片 < 3 张则跳过分析
6. GPT-4o 分析 —— 3 张 base64 编码 → 固定 JSON 提示词 → analysis.json

依赖
----
    pip install openai>=1.0.0
    opencv-contrib-python（已在 pyproject.toml 中）
"""
from __future__ import annotations

import base64
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

logger = logging.getLogger(__name__)

# ── GPT 提示词（固定，英文以保证 GPT-4o 识别准确率）─────────────────────
_ANALYSIS_PROMPT = """\
You are analyzing a Chinese dining session. I will provide three photos taken \
at roughly equal intervals during the meal:
  - Photo 1: START  — food just served / beginning of the meal
  - Photo 2: MIDDLE — meal in progress
  - Photo 3: END    — after eating, near departure

Please compare the food portions across the three photos and return a JSON \
object with EXACTLY this structure (no extra text):

{
  "dishes": [
    {
      "name": "dish name (Chinese or English)",
      "category": "staple | vegetable | meat | soup | fruit | other",
      "start_portion": "full | partial | empty | unknown",
      "end_portion":   "full | partial | empty | unknown",
      "consumed_percent": 0-100
    }
  ],
  "overall_consumption_percent": 0-100,
  "eating_duration_assessment": "short (<15min) | normal (15-60min) | long (>60min)",
  "anomaly": null,
  "notes": "one-sentence observation"
}

Rules:
- If a dish is not visible in Photo 1 but appears later, set start_portion to "unknown".
- If you cannot distinguish individual dishes, list them as a single "mixed dishes" entry.
- overall_consumption_percent = weighted average of consumed_percent across dishes.
- anomaly: null, or a short string if something is concerning (e.g., "food barely touched").
"""


# ────────────────────────────────────────────────────────────────────────────
# Data structures
# ────────────────────────────────────────────────────────────────────────────

@dataclass
class PhotoInfo:
    """一张照片的元数据 + 懒加载图像。"""
    index: int
    timestamp: float
    path: Path
    _img: Optional[np.ndarray] = field(default=None, repr=False, compare=False)

    def load(self) -> np.ndarray:
        if self._img is None:
            img = cv2.imread(str(self.path))
            if img is None:
                raise IOError(f"Cannot read image: {self.path}")
            self._img = img
        return self._img

    def release(self) -> None:
        """释放缓存图像，节省内存。"""
        self._img = None

    # ── 质量指标 ──────────────────────────────────────────────────────────

    def sharpness(self) -> float:
        """Laplacian 方差，越高越清晰。"""
        gray = cv2.cvtColor(self.load(), cv2.COLOR_BGR2GRAY)
        return float(cv2.Laplacian(gray, cv2.CV_64F).var())

    def brightness(self) -> float:
        """灰度均值，范围 [0, 255]。"""
        gray = cv2.cvtColor(self.load(), cv2.COLOR_BGR2GRAY)
        return float(gray.mean())

    def food_area_ratio(self) -> float:
        """
        中心 60% 区域中，HSV 饱和度 > 40 的像素占比。
        饱和度高 → 有颜色 → 大概率是食物（而非白色桌布/盘子）。
        """
        img = self.load()
        h, w = img.shape[:2]
        crop = img[int(h * 0.2):int(h * 0.8), int(w * 0.2):int(w * 0.8)]
        hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
        s = hsv[:, :, 1]
        return float((s > 40).sum() / s.size)

    def is_valid(
        self,
        sharpness_thresh: float = 70.0,
        brightness_lo: float = 100.0,
        brightness_hi: float = 200.0,
        food_thresh: float = 0.10,
    ) -> bool:
        """返回 True 如果照片通过所有质量 + 内容过滤。"""
        try:
            return (
                self.sharpness() >= sharpness_thresh
                and brightness_lo <= self.brightness() <= brightness_hi
                and self.food_area_ratio() >= food_thresh
            )
        except Exception as e:
            logger.warning(f"[DiningAnalyzer] PhotoInfo.is_valid error ({self.path.name}): {e}")
            return False


# ────────────────────────────────────────────────────────────────────────────
# Photo pool
# ────────────────────────────────────────────────────────────────────────────

class PhotoPool:
    """
    从 session_meta.json 加载照片列表，过滤出有效照片。

    Parameters
    ----------
    session_dir : Path
        就餐照片目录（dining_photos/）。
    meta : dict
        session_meta.json 的内容。
    sharpness_thresh : float
    brightness_lo / brightness_hi : float
    food_thresh : float
    """

    def __init__(
        self,
        session_dir: Path,
        meta: Dict,
        sharpness_thresh: float = 70.0,
        brightness_lo: float = 100.0,
        brightness_hi: float = 200.0,
        food_thresh: float = 0.10,
    ):
        self.session_dir = session_dir
        self.meta = meta
        self._sharpness_thresh = sharpness_thresh
        self._brightness_lo = brightness_lo
        self._brightness_hi = brightness_hi
        self._food_thresh = food_thresh

        self.all_photos: List[PhotoInfo] = self._load_all()
        self.valid_photos: List[PhotoInfo] = [
            p for p in self.all_photos
            if p.is_valid(sharpness_thresh, brightness_lo, brightness_hi, food_thresh)
        ]
        logger.info(
            f"[DiningAnalyzer] PhotoPool: {len(self.all_photos)} total, "
            f"{len(self.valid_photos)} valid"
        )

    def _load_all(self) -> List[PhotoInfo]:
        photos_info = self.meta.get("photos", [])
        result = []
        for p in photos_info:
            path = self.session_dir / p["filename"]
            if path.exists():
                result.append(PhotoInfo(p["index"], p["timestamp"], path))
            else:
                logger.debug(f"[DiningAnalyzer] Photo file missing: {path}")
        # 按 index 排序（通常已排序，但以防万一）
        result.sort(key=lambda x: x.index)
        return result


# ────────────────────────────────────────────────────────────────────────────
# Photo selection helpers
# ────────────────────────────────────────────────────────────────────────────

def _center_crop(img: np.ndarray, ratio: float = 0.6) -> np.ndarray:
    h, w = img.shape[:2]
    margin_h = int(h * (1 - ratio) / 2)
    margin_w = int(w * (1 - ratio) / 2)
    return img[margin_h:h - margin_h, margin_w:w - margin_w]


def _normalized_diff(a: np.ndarray, b: np.ndarray) -> float:
    """中心裁剪归一化像素差（0=完全相同，1=完全不同）。"""
    fa = _center_crop(a).astype(np.float32) / 255.0
    fb = _center_crop(b).astype(np.float32) / 255.0
    # 统一尺寸（容错不同分辨率）
    if fa.shape != fb.shape:
        fb = cv2.resize(fb, (fa.shape[1], fa.shape[0]))
    return float(np.abs(fa - fb).mean())


def _food_saturation_map(img: np.ndarray) -> np.ndarray:
    """返回中心裁剪区域的 HSV 饱和度图（float32，[0,1]）。"""
    crop = _center_crop(img)
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    return hsv[:, :, 1].astype(np.float32) / 255.0


def _food_change_score(prev: PhotoInfo, curr: PhotoInfo) -> float:
    """两张照片之间食物饱和度变化量（0=无变化，1=完全变化）。"""
    try:
        s1 = _food_saturation_map(prev.load())
        s2 = _food_saturation_map(curr.load())
        if s1.shape != s2.shape:
            s2 = cv2.resize(s2, (s1.shape[1], s1.shape[0]))
        return float(np.abs(s1 - s2).mean())
    except Exception as e:
        logger.warning(f"[DiningAnalyzer] food_change_score error: {e}")
        return 0.0


# ────────────────────────────────────────────────────────────────────────────
# Selection functions
# ────────────────────────────────────────────────────────────────────────────

def select_start_photo(pool: PhotoPool, stability_thresh: float = 0.10) -> Optional[PhotoInfo]:
    """
    开始照片：找第一张盘面稳定的有效照片。
    稳定 = 连续 3 张有效照片，相邻归一化差均 < stability_thresh。
    退路：返回有效池中第一张。
    """
    valid = pool.valid_photos
    if not valid:
        return None
    if len(valid) < 3:
        return valid[0]

    for i in range(len(valid) - 2):
        try:
            d12 = _normalized_diff(valid[i].load(), valid[i + 1].load())
            d23 = _normalized_diff(valid[i + 1].load(), valid[i + 2].load())
            if d12 < stability_thresh and d23 < stability_thresh:
                logger.debug(
                    f"[DiningAnalyzer] Start photo: #{valid[i].index} "
                    f"(d12={d12:.3f}, d23={d23:.3f})"
                )
                return valid[i]
        except Exception as e:
            logger.warning(f"[DiningAnalyzer] Stability check error at index {i}: {e}")

    logger.debug("[DiningAnalyzer] No stable triple found, using first valid photo as start")
    return valid[0]


def select_end_photo(pool: PhotoPool) -> Optional[PhotoInfo]:
    """结束照片：有效池中最后一张。"""
    if not pool.valid_photos:
        return None
    return pool.valid_photos[-1]


def select_middle_photo(
    pool: PhotoPool,
    meta: Dict,
    min_change_ratio: float = 0.05,
) -> Optional[PhotoInfo]:
    """
    中间照片：时间轴 10%–90% 窗口内食物变化量最大的照片。

    如果所有候选照片的食物变化量 < min_change_ratio（5%），
    退路：返回最接近时间中点的有效照片。
    """
    valid = pool.valid_photos
    if not valid:
        return None

    t_start = meta.get("session_start", valid[0].timestamp)
    t_end = meta.get("session_end", valid[-1].timestamp)
    duration = t_end - t_start

    if duration <= 0:
        return valid[len(valid) // 2]

    t_lo = t_start + 0.10 * duration
    t_hi = t_start + 0.90 * duration
    candidates = [p for p in valid if t_lo <= p.timestamp <= t_hi]

    if not candidates:
        # 窗口内无照片，退路：最接近中点
        t_mid = t_start + 0.50 * duration
        return min(valid, key=lambda p: abs(p.timestamp - t_mid))

    # 计算每张候选照片相对于前一张有效照片的食物变化量
    valid_set_idx = {id(p): i for i, p in enumerate(valid)}
    scores: List[Tuple[float, PhotoInfo]] = []

    for p in candidates:
        vi = valid_set_idx.get(id(p), -1)
        if vi > 0:
            score = _food_change_score(valid[vi - 1], p)
        else:
            score = 0.0
        scores.append((score, p))

    max_score = max(s for s, _ in scores)

    if max_score < min_change_ratio:
        # 食物变化不明显，退路：最接近中点
        t_mid = t_start + 0.50 * duration
        chosen = min(candidates, key=lambda p: abs(p.timestamp - t_mid))
        logger.debug(
            f"[DiningAnalyzer] Middle photo: max change {max_score:.3f} < {min_change_ratio}, "
            f"using time-midpoint photo #{chosen.index}"
        )
        return chosen

    chosen = max(scores, key=lambda x: x[0])[1]
    logger.debug(
        f"[DiningAnalyzer] Middle photo: #{chosen.index} "
        f"(food_change={max_score:.3f})"
    )
    return chosen


def validate_selection(
    pool: PhotoPool,
    start: PhotoInfo,
    middle: PhotoInfo,
    end: PhotoInfo,
    meta: Dict,
    time_span_ratio: float = 0.80,
) -> Optional[Tuple[PhotoInfo, PhotoInfo, PhotoInfo]]:
    """
    最终验证：
    1. 时间跨度 ≥ 80% 总时长（否则扩展到绝对首尾）
    2. 每张照片有效性复核；若无效则替换为最近的有效照片
    3. 有效照片 < 3 张则返回 None（跳过分析）

    返回 (start, middle, end) 或 None。
    """
    valid = pool.valid_photos
    if len(valid) < 3:
        logger.warning(
            f"[DiningAnalyzer] Only {len(valid)} valid photo(s), need ≥ 3. Skipping analysis."
        )
        return None

    t_start = meta.get("session_start", valid[0].timestamp)
    t_end = meta.get("session_end", valid[-1].timestamp)
    duration = t_end - t_start

    # 时间跨度检查
    if duration > 0:
        actual_span = end.timestamp - start.timestamp
        if actual_span / duration < time_span_ratio:
            logger.info(
                f"[DiningAnalyzer] Time span {actual_span:.0f}s < "
                f"{time_span_ratio*100:.0f}% of {duration:.0f}s — expanding to full range"
            )
            start = valid[0]
            end = valid[-1]

    # 有效性复核 + 替换
    valid_ids = {id(p) for p in valid}

    def nearest_valid(target: PhotoInfo) -> PhotoInfo:
        if id(target) in valid_ids:
            return target
        return min(valid, key=lambda p: abs(p.timestamp - target.timestamp))

    start = nearest_valid(start)
    middle = nearest_valid(middle)
    end = nearest_valid(end)

    # 确保三者不完全相同
    if start is middle:
        idx = valid.index(middle)
        middle = valid[min(idx + 1, len(valid) - 1)]
    if middle is end:
        idx = valid.index(middle)
        middle = valid[max(idx - 1, 0)]

    logger.info(
        f"[DiningAnalyzer] Selected: start=#{start.index} "
        f"middle=#{middle.index} end=#{end.index}"
    )
    return start, middle, end


# ────────────────────────────────────────────────────────────────────────────
# GPT-4o Vision API call
# ────────────────────────────────────────────────────────────────────────────

def _encode_image_b64(path: Path, max_side: int = 1024) -> str:
    """
    将照片缩放到 max_side px 以内，编码为 base64 JPEG 字符串。
    缩放减少 token 消耗（GPT-4o 以 512px tile 计费）。
    """
    img = cv2.imread(str(path))
    if img is None:
        raise IOError(f"Cannot read image: {path}")
    h, w = img.shape[:2]
    scale = min(1.0, max_side / max(h, w))
    if scale < 1.0:
        img = cv2.resize(img, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 85])
    if not ok:
        raise RuntimeError("JPEG encode failed")
    return base64.b64encode(buf.tobytes()).decode("utf-8")


def call_gpt4o_vision(
    start_path: Path,
    middle_path: Path,
    end_path: Path,
    api_key: str,
    model: str = "gpt-4o",
) -> Dict:
    """
    调用 GPT-4o Vision API，返回解析后的 JSON 分析结果。

    Parameters
    ----------
    start_path / middle_path / end_path : Path
        三张代表性照片路径。
    api_key : str
        OpenAI API key。
    model : str
        默认 "gpt-4o"（也可用 "gpt-4o-mini" 降低成本）。

    Returns
    -------
    dict
        解析后的 JSON 响应（analysis 字典）。

    Raises
    ------
    ImportError  : openai 包未安装
    RuntimeError : API 调用失败或 JSON 解析失败
    """
    try:
        from openai import OpenAI
    except ImportError:
        raise ImportError(
            "openai package not installed. Install with:\n"
            "  pip install openai>=1.0.0"
        )

    client = OpenAI(api_key=api_key)

    logger.info(f"[DiningAnalyzer] Encoding photos for GPT-4o Vision...")
    start_b64 = _encode_image_b64(start_path)
    mid_b64 = _encode_image_b64(middle_path)
    end_b64 = _encode_image_b64(end_path)

    messages = [
        {
            "role": "user",
            "content": [
                {"type": "text", "text": _ANALYSIS_PROMPT},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{start_b64}", "detail": "low"},
                },
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{mid_b64}", "detail": "low"},
                },
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{end_b64}", "detail": "low"},
                },
            ],
        }
    ]

    logger.info(f"[DiningAnalyzer] Calling {model}...")
    try:
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=1024,
            response_format={"type": "json_object"},
        )
    except Exception as e:
        raise RuntimeError(f"GPT-4o API call failed: {e}") from e

    raw = response.choices[0].message.content
    logger.debug(f"[DiningAnalyzer] GPT raw response: {raw[:200]}...")

    try:
        result = json.loads(raw)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"GPT-4o returned invalid JSON: {e}\nRaw: {raw}") from e

    return result


# ────────────────────────────────────────────────────────────────────────────
# Main analyzer class
# ────────────────────────────────────────────────────────────────────────────

class DiningAnalyzer:
    """
    就餐照片分析器。

    典型用法
    --------
    analyzer = DiningAnalyzer(api_key="sk-...")
    result = analyzer.analyze_session(session_dir=Path("recordings/dining_xxx/dining_photos"))
    # result is None if not enough valid photos, else dict (also saved as analysis.json)
    """

    def __init__(
        self,
        api_key: str = "",
        model: str = "gpt-4o",
        sharpness_thresh: float = 70.0,
        brightness_lo: float = 100.0,
        brightness_hi: float = 200.0,
        food_thresh: float = 0.10,
        time_span_ratio: float = 0.80,
    ):
        self.api_key = api_key
        self.model = model
        self.sharpness_thresh = sharpness_thresh
        self.brightness_lo = brightness_lo
        self.brightness_hi = brightness_hi
        self.food_thresh = food_thresh
        self.time_span_ratio = time_span_ratio

    def analyze_session(
        self,
        session_dir: Path,
        meta_filename: str = "session_meta.json",
        skip_gpt: bool = False,
    ) -> Optional[Dict]:
        """
        完整分析流程：照片选择 → (可选) GPT-4o 分析 → 保存 analysis.json。

        Parameters
        ----------
        session_dir : Path
            就餐照片目录（含 session_meta.json 和 photo_*.jpg）。
        meta_filename : str
            元数据文件名，默认 "session_meta.json"。
        skip_gpt : bool
            True = 只做照片选择，不调用 GPT-4o（用于测试或无网络场景）。

        Returns
        -------
        dict  — 分析结果（同时写入 analysis.json）
        None  — 有效照片不足，跳过分析
        """
        session_dir = Path(session_dir)
        meta_path = session_dir / meta_filename
        if not meta_path.exists():
            logger.warning(f"[DiningAnalyzer] session_meta.json not found: {meta_path}")
            return None

        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except Exception as e:
            logger.error(f"[DiningAnalyzer] Failed to parse session_meta.json: {e}")
            return None

        # ── Step 1: 构建有效照片池 ─────────────────────────────────────
        pool = PhotoPool(
            session_dir, meta,
            self.sharpness_thresh,
            self.brightness_lo,
            self.brightness_hi,
            self.food_thresh,
        )

        if len(pool.valid_photos) < 3:
            logger.warning(
                f"[DiningAnalyzer] Not enough valid photos "
                f"({len(pool.valid_photos)}/3). Skipping."
            )
            return None

        # ── Step 2: 开始照片 ───────────────────────────────────────────
        start = select_start_photo(pool)
        # ── Step 3: 结束照片 ───────────────────────────────────────────
        end = select_end_photo(pool)
        # ── Step 4: 中间照片 ───────────────────────────────────────────
        middle = select_middle_photo(pool, meta)

        if start is None or middle is None or end is None:
            logger.warning("[DiningAnalyzer] Photo selection returned None. Skipping.")
            return None

        # ── Step 5: 最终验证 ───────────────────────────────────────────
        validated = validate_selection(pool, start, middle, end, meta, self.time_span_ratio)
        if validated is None:
            return None
        start, middle, end = validated

        # 释放未使用图像的内存
        selected_ids = {id(start), id(middle), id(end)}
        for p in pool.all_photos:
            if id(p) not in selected_ids:
                p.release()

        # ── Step 6: GPT-4o 分析 ───────────────────────────────────────
        selection_info = {
            "session_id": meta.get("session_id"),
            "session_start": meta.get("session_start"),
            "session_end": meta.get("session_end"),
            "duration_seconds": meta.get("duration_seconds"),
            "total_photos": len(pool.all_photos),
            "valid_photos": len(pool.valid_photos),
            "selected_start": {
                "index": start.index,
                "timestamp": start.timestamp,
                "filename": start.path.name,
            },
            "selected_middle": {
                "index": middle.index,
                "timestamp": middle.timestamp,
                "filename": middle.path.name,
            },
            "selected_end": {
                "index": end.index,
                "timestamp": end.timestamp,
                "filename": end.path.name,
            },
        }

        if skip_gpt or not self.api_key:
            logger.info("[DiningAnalyzer] GPT-4o skipped (no api_key or skip_gpt=True)")
            result = {**selection_info, "gpt_analysis": None, "status": "photos_selected_only"}
        else:
            try:
                gpt_result = call_gpt4o_vision(
                    start.path, middle.path, end.path,
                    self.api_key, self.model,
                )
                result = {**selection_info, "gpt_analysis": gpt_result, "status": "complete"}
            except Exception as e:
                logger.error(f"[DiningAnalyzer] GPT-4o analysis failed: {e}")
                result = {**selection_info, "gpt_analysis": None, "status": f"gpt_error: {e}"}

        # ── 保存 analysis.json ────────────────────────────────────────
        out_path = session_dir / "analysis.json"
        try:
            out_path.write_text(
                json.dumps(result, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            logger.info(f"[DiningAnalyzer] analysis.json saved: {out_path}")
        except Exception as e:
            logger.error(f"[DiningAnalyzer] Failed to save analysis.json: {e}")

        return result


# ────────────────────────────────────────────────────────────────────────────
# Convenience function
# ────────────────────────────────────────────────────────────────────────────

def analyze_session(
    session_dir: Path,
    api_key: str = "",
    model: str = "gpt-4o",
    skip_gpt: bool = False,
) -> Optional[Dict]:
    """
    便捷函数，直接分析一个就餐会话目录。

    Parameters
    ----------
    session_dir : Path
        就餐照片目录（含 session_meta.json）。
    api_key : str
        OpenAI API Key（空字符串 = 跳过 GPT，只做照片选择）。
    model : str
        OpenAI 模型，默认 "gpt-4o"。
    skip_gpt : bool
        强制跳过 GPT（无论 api_key 是否为空）。
    """
    analyzer = DiningAnalyzer(api_key=api_key, model=model)
    return analyzer.analyze_session(session_dir, skip_gpt=skip_gpt)
