"""Headless auto-calibration pipeline for caliscope.

Calls caliscope's core APIs directly (no GUI) to run the full
calibration workflow: intrinsic calibration, 2D extraction,
extrinsic calibration (bundle adjustment), and origin alignment.

Usage:
  from recorder.auto_calibrate import AutoCalibConfig, run_auto_calibration
  config = AutoCalibConfig(project_dir=Path("path/to/caliscope_project"))
  result = run_auto_calibration(config, on_progress=print)
"""

from __future__ import annotations

import logging
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

from concurrent.futures import ThreadPoolExecutor

import av
import numpy as np
import pandas as pd

from caliscope.cameras.camera_array import CameraArray, CameraData
from caliscope.core.calibrate_intrinsics import run_intrinsic_calibration
from caliscope.core.charuco import Charuco
from caliscope.core.point_data import ImagePoints
from caliscope.core.point_data_bundle import PointDataBundle
from caliscope.core.bootstrap_pose.build_paired_pose_network import build_paired_pose_network
from caliscope.persistence import (
  save_camera_array,
  save_charuco,
  save_image_points_csv,
)
from caliscope.recording.frame_source import FrameSource
from caliscope.recording.frame_sync import compute_sync_indices
from caliscope.repositories.point_data_bundle_repository import PointDataBundleRepository
from caliscope.trackers.charuco_tracker import CharucoTracker

logger = logging.getLogger(__name__)

# Type alias for progress callbacks
# (stage_name, message, percent_0_to_100)
ProgressCallback = Callable[[str, str, int], None]

FILTERED_FRACTION = 0.025  # 2.5% outlier removal


def _patch_caliscope_for_avi() -> None:
  """Enable caliscope to read port_*.avi when port_*.mp4 is missing.

  Keeps MP4 priority so UI workflows are unaffected.
  """
  try:
    import caliscope.managers.synchronized_stream_manager as ssm
    import caliscope.recording.frame_source as fs
  except Exception as exc:
    logger.warning("AVI patch skipped (caliscope import failed): %s", exc)
    return

  if getattr(ssm, "_avi_patch_applied", False):
    return

  if hasattr(ssm, "read_video_properties"):
    _orig_rvp = ssm.read_video_properties

    def _read_video_properties_avi_fallback(source_path):
      p = Path(str(source_path))
      if p.suffix.lower() == ".mp4":
        alt = p.with_suffix(".avi")
        if alt.exists():
          source_path = alt
      return _orig_rvp(source_path)

    ssm.read_video_properties = _read_video_properties_avi_fallback

  if hasattr(fs, "FrameSource"):
    _orig_init = fs.FrameSource.__init__

    def _init_avi_fallback(self, video_directory: Path, port: int) -> None:
      video_directory = Path(video_directory)
      avi_path = video_directory / f"port_{port}.avi"
      mp4_path = video_directory / f"port_{port}.mp4"
      if avi_path.exists():
        self.video_path = avi_path
      elif mp4_path.exists():
        self.video_path = mp4_path
      else:
        raise FileNotFoundError(f"Video file not found: {avi_path} or {mp4_path}")

      # Call original init; if it insists on mp4, re-run with mp4 then restore.
      orig_path = getattr(self, "video_path", None)
      try:
        return _orig_init(self, video_directory, port)
      except FileNotFoundError:
        self.video_path = mp4_path
        _orig_init(self, video_directory, port)
        self.video_path = orig_path

    fs.FrameSource.__init__ = _init_avi_fallback

  ssm._avi_patch_applied = True


def _find_port_video(directory: Path, port: int) -> Path:
  """Find port_N video file, trying .mp4 first then .avi."""
  mp4 = directory / f"port_{port}.mp4"
  if mp4.exists():
    return mp4
  avi = directory / f"port_{port}.avi"
  if avi.exists():
    return avi
  raise FileNotFoundError(f"Video not found: {mp4} or {avi}")


@dataclass
class AutoCalibConfig:
  """Configuration for headless auto-calibration pipeline."""
  project_dir: Path
  # Charuco board parameters (must match the physical board)
  charuco_columns: int = 10
  charuco_rows: int = 16
  board_height_cm: float = 80.0
  board_width_cm: float = 50.0
  dictionary: str = "DICT_4X4_100"
  aruco_scale: float = 0.7
  square_size_cm: float = 5.0
  units: str = "cm"
  # Camera setup
  ports: list[int] = field(default_factory=lambda: [1, 2])
  image_size: tuple[int, int] = (1600, 1200)
  # Processing parameters
  intrinsic_subsample: int = 10  # process every Nth frame for intrinsic
  extrinsic_subsample: int = 12  # process every Nth sync index for extrinsic

  @classmethod
  def from_yaml(cls, yaml_data: dict, project_dir: Path) -> "AutoCalibConfig":
    """Create config from YAML dictionary (default.yaml charuco section)."""
    charuco = yaml_data.get("charuco", {})
    split = yaml_data.get("split", {})
    # Derive image size from split config
    xsplit = split.get("xsplit", 1600)
    full_h = split.get("full_h", 1200)
    return cls(
      project_dir=project_dir,
      charuco_columns=charuco.get("columns", 10),
      charuco_rows=charuco.get("rows", 16),
      board_height_cm=charuco.get("board_height_cm", 80.0),
      board_width_cm=charuco.get("board_width_cm", 50.0),
      dictionary=charuco.get("dictionary", "DICT_4X4_100"),
      aruco_scale=charuco.get("aruco_scale", 0.7),
      square_size_cm=charuco.get("square_size_cm", 5.0),
      image_size=(xsplit, full_h),
    )


@dataclass
class CalibrationResult:
  """Result of the auto-calibration pipeline."""
  camera_array: CameraArray
  bundle: PointDataBundle
  origin_sync_index: int
  intrinsic_rmse: dict[int, float]  # port -> RMSE
  extrinsic_cost: float  # final_cost from bundle adjustment
  success: bool = True
  error_message: str = ""


def _emit(on_progress: Optional[ProgressCallback], stage: str, msg: str, pct: int):
  """Helper to safely emit progress."""
  if on_progress:
    on_progress(stage, msg, pct)
  logger.info(f"[{stage}] {msg} ({pct}%)")


def _collect_charuco_points_from_video(
  video_dir: Path,
  port: int,
  tracker: CharucoTracker,
  subsample: int = 10,
  on_progress: Optional[ProgressCallback] = None,
) -> list[tuple[int, object]]:
  """Iterate video frames and collect charuco corner detections.

  Uses sequential decoding (single pass) instead of per-frame seeking
  for ~10x speedup on H.264 video.

  Returns list of (frame_index, PointPacket) tuples.
  """
  video_path = _find_port_video(video_dir, port)

  container = av.open(str(video_path))
  stream = container.streams.video[0]
  time_base = float(stream.time_base)
  fps = float(stream.average_rate)
  total_frames = stream.frames
  if total_frames == 0 and container.duration is not None:
    total_frames = int(container.duration / 1_000_000 * fps)

  collected = []
  sampled = 0

  try:
    for frame in container.decode(stream):
      if frame.pts is None:
        continue
      frame_idx = round(frame.pts * time_base * fps)

      # Only process every Nth frame
      if frame_idx % subsample != 0:
        continue

      img = frame.to_ndarray(format="bgr24")
      points = tracker.get_points(img, port, 0)
      sampled += 1

      if points is not None and len(points.point_id) > 0:
        collected.append((frame_idx, points))

      if on_progress and sampled % 20 == 0:
        pct = int(frame_idx / max(total_frames, 1) * 100)
        _emit(on_progress, "intrinsic", f"Port {port}: scanning frame {frame_idx}/{total_frames}", pct)
  finally:
    container.close()

  logger.info(f"Port {port}: collected {len(collected)} frames with charuco detections out of {sampled} sampled")
  return collected


def _build_image_points_from_packets(
  collected_points: list[tuple[int, object]],
  port: int,
) -> ImagePoints:
  """Convert (frame_index, PointPacket) list to ImagePoints DataFrame.

  Replicates the pattern from IntrinsicCalibrationPresenter._build_image_points().
  """
  rows = []
  for frame_index, points in collected_points:
    point_count = len(points.point_id)
    if point_count == 0:
      continue

    obj_loc_x, obj_loc_y, obj_loc_z = points.obj_loc_list

    for i in range(point_count):
      rows.append({
        "sync_index": frame_index,
        "port": port,
        "frame_index": frame_index,
        "frame_time": 0.0,
        "point_id": int(points.point_id[i]),
        "img_loc_x": float(points.img_loc[i, 0]),
        "img_loc_y": float(points.img_loc[i, 1]),
        "obj_loc_x": obj_loc_x[i],
        "obj_loc_y": obj_loc_y[i],
        "obj_loc_z": obj_loc_z[i],
      })

  if not rows:
    df = pd.DataFrame(columns=[
      "sync_index", "port", "frame_index", "frame_time",
      "point_id", "img_loc_x", "img_loc_y",
      "obj_loc_x", "obj_loc_y", "obj_loc_z",
    ])
    return ImagePoints(df)

  df = pd.DataFrame(rows)
  return ImagePoints(df)


def _decode_and_track_port(
  video_path: Path,
  port: int,
  needed_frames: set[int],
  charuco,
  rotation: int,
) -> dict[int, object]:
  """Decode one port's video sequentially and run charuco detection.

  Each thread gets its own CharucoTracker instance to avoid shared state.
  OpenCV and PyAV both release the GIL, so threads run in true parallelism.

  Returns:
    {frame_index: PointPacket} for all needed frames.
  """
  # Each thread gets its own tracker — CharucoTracker is lightweight
  tracker = CharucoTracker(charuco)

  results: dict[int, object] = {}
  needed = set(needed_frames)  # local copy

  container = av.open(str(video_path))
  stream = container.streams.video[0]
  time_base = float(stream.time_base)
  fps = float(stream.average_rate)

  for frame in container.decode(stream):
    if frame.pts is None:
      continue
    frame_idx = round(frame.pts * time_base * fps)

    if frame_idx in needed:
      img = frame.to_ndarray(format="bgr24")
      points = tracker.get_points(img, port, rotation)
      results[frame_idx] = points
      needed.discard(frame_idx)

      if not needed:
        break

  container.close()
  logger.info(f"Port {port}: tracked {len(results)} frames (parallel)")
  return results


def _process_extrinsic_sequential(
  recording_dir: Path,
  cameras: dict[int, CameraData],
  tracker: CharucoTracker,
  subsample: int = 3,
  on_progress: Optional[ProgressCallback] = None,
) -> ImagePoints:
  """Optimized extrinsic 2D extraction.

  Two key optimizations over process_synchronized_recording():
    1. Sequential decode (single pass) instead of per-frame H.264 seeking
    2. All ports processed in parallel threads (OpenCV releases GIL)
  """
  # Load sync map
  timestamps_csv = recording_dir / "frame_timestamps.csv"
  sync_map = compute_sync_indices(timestamps_csv)

  # Load frame times
  timestamps_df = pd.read_csv(timestamps_csv)
  frame_times: dict[tuple[int, int], float] = {}
  for port_key, group in timestamps_df.groupby("port"):
    sorted_group = group.sort_values("frame_time").reset_index(drop=True)
    for frame_index, row in sorted_group.iterrows():
      frame_times[(int(port_key), int(frame_index))] = float(row["frame_time"])

  # Determine which sync indices to process
  all_sync_indices = sorted(sync_map.keys())
  sync_indices_to_process = all_sync_indices[::subsample]
  total = len(sync_indices_to_process)

  logger.info(f"Parallel extrinsic: {total} sync indices (subsample={subsample}, total={len(all_sync_indices)})")

  # Pre-compute needed frame indices per port
  port_needed: dict[int, set[int]] = {port: set() for port in cameras}
  for sync_index in sync_indices_to_process:
    for port, frame_index in sync_map[sync_index].items():
      if frame_index is not None and port in cameras:
        port_needed[port].add(frame_index)

  # ── Parallel decode + track per port ──────────────────────────
  port_results: dict[tuple[int, int], object] = {}

  with ThreadPoolExecutor(max_workers=len(cameras)) as pool:
    futures = {}
    for port in cameras:
      needed = port_needed.get(port, set())
      if not needed:
        continue
      try:
        video_path = _find_port_video(recording_dir, port)
      except FileNotFoundError:
        logger.warning(f"Video not found for port {port} in {recording_dir}")
        continue

      futures[port] = pool.submit(
        _decode_and_track_port,
        video_path, port, needed,
        tracker.charuco,  # pass charuco config, thread creates own tracker
        cameras[port].rotation_count,
      )

    for port, future in futures.items():
      for frame_idx, points in future.result().items():
        port_results[(port, frame_idx)] = points

  # Assemble results in sync index order
  point_rows: list[dict] = []
  for i, sync_index in enumerate(sync_indices_to_process):
    for port, frame_index in sync_map[sync_index].items():
      if frame_index is None or port not in cameras:
        continue
      points = port_results.get((port, frame_index))
      if points is None or len(points.point_id) == 0:
        continue

      obj_loc_x, obj_loc_y, obj_loc_z = points.obj_loc_list
      frame_time = frame_times.get((port, frame_index), 0.0)

      for j in range(len(points.point_id)):
        point_rows.append({
          "sync_index": sync_index,
          "port": port,
          "frame_index": frame_index,
          "frame_time": frame_time,
          "point_id": int(points.point_id[j]),
          "img_loc_x": float(points.img_loc[j, 0]),
          "img_loc_y": float(points.img_loc[j, 1]),
          "obj_loc_x": obj_loc_x[j],
          "obj_loc_y": obj_loc_y[j],
          "obj_loc_z": obj_loc_z[j],
        })

    if on_progress and (i + 1) % 50 == 0:
      on_progress(i + 1, total)

  if on_progress:
    on_progress(total, total)

  if not point_rows:
    df = pd.DataFrame(columns=[
      "sync_index", "port", "frame_index", "frame_time",
      "point_id", "img_loc_x", "img_loc_y",
      "obj_loc_x", "obj_loc_y", "obj_loc_z",
    ])
    return ImagePoints(df)

  return ImagePoints(pd.DataFrame(point_rows))


def _generate_frame_timestamps(
  recording_dir: Path,
  ports: list[int],
) -> None:
  """Generate synthetic frame_timestamps.csv for perfectly synchronized stereo videos.

  Since both views come from a single stereo USB camera,
  frames are inherently synchronized. We create a CSV where
  both ports share identical timestamps based on video FPS.
  """
  rows = []
  for port in ports:
    source = FrameSource(recording_dir, port)
    fps = source.fps
    frame_count = source.frame_count
    source.close()

    for i in range(frame_count):
      rows.append({"port": port, "frame_time": i / fps})

  df = pd.DataFrame(rows)
  csv_path = recording_dir / "frame_timestamps.csv"
  df.to_csv(csv_path, index=False)
  logger.info(f"Generated frame_timestamps.csv at {csv_path} ({len(rows)} rows, {len(ports)} ports)")


def _find_best_origin_sync_index(bundle: PointDataBundle) -> int:
  """Find the sync_index with the most world points for origin alignment.

  Picks the frame where the charuco board is most visible across all cameras.
  """
  world_df = bundle.world_points.df
  counts = world_df.groupby("sync_index").size()
  best_sync_index = int(counts.idxmax())
  logger.info(f"Selected sync_index {best_sync_index} for origin alignment ({counts[best_sync_index]} world points)")
  return best_sync_index


def run_auto_calibration(
  config: AutoCalibConfig,
  on_progress: Optional[ProgressCallback] = None,
) -> CalibrationResult:
  """Execute complete auto-calibration pipeline.

  Steps:
    1. Create charuco board and tracker
    2. Intrinsic calibration for each camera
    3. Generate frame_timestamps.csv for extrinsic videos
    4. 2D extraction from extrinsic videos
    5. Bootstrap extrinsic poses (PnP)
    6. Bundle adjustment optimization
    7. Outlier filtering and re-optimization
    8. Origin alignment
    9. Save all results

  Args:
    config: Pipeline configuration
    on_progress: Optional callback for progress updates

  Returns:
    CalibrationResult with calibrated camera array and bundle
  """
  project = config.project_dir
  intrinsic_dir = project / "calibration" / "intrinsic"
  extrinsic_dir = project / "calibration" / "extrinsic"
  charuco_dir = extrinsic_dir / "CHARUCO"
  charuco_dir.mkdir(parents=True, exist_ok=True)

  intrinsic_rmse = {}

  try:
    # ── Step 1: Create charuco and tracker ──────────────────────────
    _emit(on_progress, "init", "Creating charuco board and tracker...", 0)

    charuco = Charuco(
      columns=config.charuco_columns,
      rows=config.charuco_rows,
      board_height=config.board_height_cm,
      board_width=config.board_width_cm,
      dictionary=config.dictionary,
      units=config.units,
      aruco_scale=config.aruco_scale,
      square_size_overide_cm=config.square_size_cm,
    )
    tracker = CharucoTracker(charuco)

    # Save charuco.toml
    save_charuco(charuco, project / "charuco.toml")
    _emit(on_progress, "init", "Charuco board configured", 5)

    # ── Step 2: Build initial camera array ──────────────────────────
    cameras = {}
    for port in config.ports:
      cameras[port] = CameraData(
        port=port,
        size=config.image_size,
        rotation_count=0,
      )
    camera_array = CameraArray(cameras)

    # ── Step 3: Intrinsic calibration (parallel collection) ────────
    total_ports = len(config.ports)

    # Verify all videos exist first
    for port in config.ports:
      _find_port_video(intrinsic_dir, port)  # raises FileNotFoundError

    # Collect charuco points from ALL ports in parallel
    _emit(on_progress, "intrinsic",
          f"Scanning {total_ports} cameras in parallel...", 10)

    def _collect_for_port(port):
      """Thread worker: decode + detect charuco for one port."""
      # Each thread gets its own tracker (lightweight, just references charuco)
      t = CharucoTracker(charuco)
      video_path = _find_port_video(intrinsic_dir, port)
      container = av.open(str(video_path))
      stream = container.streams.video[0]
      tb = float(stream.time_base)
      fps_val = float(stream.average_rate)
      collected = []
      sampled = 0
      try:
        for frame in container.decode(stream):
          if frame.pts is None:
            continue
          fidx = round(frame.pts * tb * fps_val)
          if fidx % config.intrinsic_subsample != 0:
            continue
          img = frame.to_ndarray(format="bgr24")
          pts = t.get_points(img, port, 0)
          sampled += 1
          if pts is not None and len(pts.point_id) > 0:
            collected.append((fidx, pts))
      finally:
        container.close()
      logger.info(f"Port {port}: collected {len(collected)} charuco frames out of {sampled} sampled")
      return port, collected

    with ThreadPoolExecutor(max_workers=total_ports) as pool:
      futures = [pool.submit(_collect_for_port, p) for p in config.ports]
      collected_by_port = {}
      for f in futures:
        port, collected = f.result()
        collected_by_port[port] = collected

    _emit(on_progress, "intrinsic", "Parallel scanning complete", 25)

    # Run calibration for each port (fast — uses only ~30 selected frames)
    for idx, port in enumerate(config.ports):
      collected = collected_by_port[port]
      if not collected:
        raise ValueError(f"No charuco corners detected in intrinsic video for port {port}")

      image_points = _build_image_points_from_packets(collected, port)
      camera = camera_array.cameras[port]
      output = run_intrinsic_calibration(camera, image_points)

      camera_array.cameras[port] = output.camera
      intrinsic_rmse[port] = output.report.rmse

      _emit(on_progress, "intrinsic",
            f"Camera {port} calibrated: RMSE={output.report.rmse:.3f}px, "
            f"frames={output.report.frames_used}",
            30 + (idx + 1) * 5)

    # Save intermediate camera array
    save_camera_array(camera_array, project / "camera_array.toml")
    _emit(on_progress, "intrinsic", "All intrinsic calibrations complete", 40)

    # ── Step 4: Generate frame_timestamps.csv ───────────────────────
    _emit(on_progress, "extrinsic_2d", "Generating synchronization timestamps...", 42)
    _generate_frame_timestamps(extrinsic_dir, config.ports)

    # ── Step 5: 2D extraction from extrinsic videos (sequential) ────
    _emit(on_progress, "extrinsic_2d", "Extracting 2D charuco points (sequential decode)...", 45)

    image_points = _process_extrinsic_sequential(
      recording_dir=extrinsic_dir,
      cameras=camera_array.cameras,
      tracker=tracker,
      subsample=config.extrinsic_subsample,
      on_progress=lambda cur, total: _emit(
        on_progress, "extrinsic_2d",
        f"Processing sync index {cur}/{total}",
        45 + int(cur / total * 15),
      ),
    )

    # Save image points
    save_image_points_csv(image_points, charuco_dir / "image_points.csv")
    _emit(on_progress, "extrinsic_2d", f"2D extraction complete: {len(image_points.df)} observations", 60)

    # ── Step 6: Bootstrap extrinsic poses ───────────────────────────
    _emit(on_progress, "extrinsic_3d", "Bootstrapping camera poses (PnP)...", 62)

    pose_network = build_paired_pose_network(image_points, camera_array, method="pnp")
    pose_network.apply_to(camera_array)

    # ── Step 7: Triangulate initial 3D points ───────────────────────
    _emit(on_progress, "extrinsic_3d", "Triangulating 3D points...", 65)

    world_points = image_points.triangulate(camera_array)

    # ── Step 8: Bundle adjustment ───────────────────────────────────
    _emit(on_progress, "extrinsic_3d", "Running bundle adjustment (first pass)...", 70)

    bundle = PointDataBundle(camera_array, image_points, world_points)
    optimized = bundle.optimize(ftol=1e-4, verbose=2)

    initial_cost = optimized.optimization_status.final_cost if optimized.optimization_status else 0.0
    _emit(on_progress, "extrinsic_3d",
          f"First pass cost: {initial_cost:.4f}", 75)

    # ── Step 9: Filter outliers and re-optimize ─────────────────────
    _emit(on_progress, "extrinsic_3d", "Filtering outliers and re-optimizing...", 78)

    filtered = optimized.filter_by_percentile_error(FILTERED_FRACTION * 100)
    final_bundle = filtered.optimize(ftol=1e-4, verbose=2)

    final_cost = final_bundle.optimization_status.final_cost if final_bundle.optimization_status else 0.0
    _emit(on_progress, "extrinsic_3d",
          f"Final cost: {final_cost:.4f}", 85)

    # ── Step 10: Origin alignment ───────────────────────────────────
    _emit(on_progress, "extrinsic_3d", "Aligning coordinate origin...", 88)

    origin_sync_index = _find_best_origin_sync_index(final_bundle)
    aligned_bundle = final_bundle.align_to_object(origin_sync_index)

    # ── Step 11: Save everything ────────────────────────────────────
    _emit(on_progress, "save", "Saving calibration results...", 92)

    # Save final camera array to project root
    save_camera_array(aligned_bundle.camera_array, project / "camera_array.toml")

    # Save bundle to extrinsic/CHARUCO/
    bundle_repo = PointDataBundleRepository(charuco_dir)
    bundle_repo.save(aligned_bundle)

    # Save project settings
    _save_project_settings(project)

    _emit(on_progress, "done", "Calibration complete!", 100)

    return CalibrationResult(
      camera_array=aligned_bundle.camera_array,
      bundle=aligned_bundle,
      origin_sync_index=origin_sync_index,
      intrinsic_rmse=intrinsic_rmse,
      extrinsic_cost=final_cost,
      success=True,
    )

  except Exception as e:
    logger.error(f"Auto-calibration failed: {e}", exc_info=True)
    _emit(on_progress, "error", f"Calibration failed: {e}", -1)
    return CalibrationResult(
      camera_array=CameraArray({}),
      bundle=None,
      origin_sync_index=-1,
      intrinsic_rmse=intrinsic_rmse,
      extrinsic_cost=0.0,
      success=False,
      error_message=str(e),
    )


def _save_project_settings(project_dir: Path):
  """Save minimal project settings for caliscope compatibility."""
  import rtoml
  from datetime import datetime

  settings_path = project_dir / "project_settings.toml"
  settings = {
    "creation_date": datetime.now().isoformat(),
    "save_tracked_points_video": True,
    "fps_sync_stream_processing": 100,
  }

  # Only create if doesn't exist (don't overwrite user settings)
  if not settings_path.exists():
    settings_path.parent.mkdir(parents=True, exist_ok=True)
    with open(settings_path, "w") as f:
      rtoml.dump(settings, f)
    logger.info(f"Created project settings at {settings_path}")


def _filter_xyz_outliers(
  csv_path: Path,
  abs_limit: float = 10.0,
  iqr_k: float = 2.0,
  max_displacement: float = 0.5,
) -> tuple[int, int]:
  """Remove outlier 3D points using multi-stage filtering.

  Stages:
    1. Drop rows with inf / NaN coordinates
    2. Absolute range clip (±abs_limit meters, default 10m)
    3. Per-keypoint IQR filtering — for each point_id, remove rows where
       any coordinate is outside [Q1 - k*IQR, Q3 + k*IQR]
    4. Velocity filtering — remove rows where a keypoint jumps more than
       max_displacement meters between consecutive frames

  The file is overwritten in-place; returns (n_before, n_after).
  """
  import pandas as pd

  df = pd.read_csv(csv_path)
  n_before = len(df)
  coord_cols = ["x_coord", "y_coord", "z_coord"]

  # 1. Drop inf / NaN
  for col in coord_cols:
    df = df[np.isfinite(df[col])]

  # 2. Absolute range clip
  for col in coord_cols:
    df = df[(df[col] >= -abs_limit) & (df[col] <= abs_limit)]

  # 3. Per-keypoint IQR filtering
  keep_mask = np.ones(len(df), dtype=bool)
  for pid, grp in df.groupby("point_id"):
    for col in coord_cols:
      vals = grp[col]
      q1 = vals.quantile(0.25)
      q3 = vals.quantile(0.75)
      iqr = q3 - q1
      lo = q1 - iqr_k * iqr
      hi = q3 + iqr_k * iqr
      outlier_idx = grp.index[(vals < lo) | (vals > hi)]
      keep_mask[df.index.get_indexer(outlier_idx)] = False

  n_iqr_removed = (~keep_mask).sum()
  if n_iqr_removed > 0:
    logger.info(f"IQR filter: removed {n_iqr_removed} outlier points")
  df = df[keep_mask]

  # 4. Velocity filtering — remove points with impossible frame-to-frame jumps
  df = df.sort_values(["point_id", "sync_index"]).reset_index(drop=True)
  keep_mask = np.ones(len(df), dtype=bool)
  for pid, grp in df.groupby("point_id"):
    if len(grp) < 2:
      continue
    coords = grp[coord_cols].values  # (N, 3)
    diffs = np.sqrt(np.sum(np.diff(coords, axis=0) ** 2, axis=1))
    # Mark frames where incoming displacement is too large
    bad_idx = grp.index[1:][diffs > max_displacement]
    keep_mask[df.index.get_indexer(bad_idx)] = False

  n_vel_removed = (~keep_mask).sum()
  if n_vel_removed > 0:
    logger.info(f"Velocity filter: removed {n_vel_removed} jump points "
                f"(threshold={max_displacement}m)")
  df = df[keep_mask]

  n_after = len(df)
  removed = n_before - n_after
  if removed > 0:
    logger.info(f"Outlier filter total: removed {removed} of {n_before} points "
                f"({removed / max(n_before, 1) * 100:.1f}%)")

  df.to_csv(csv_path, index=False)
  return n_before, n_after


class _TrackerEnumCompat:
  """Duck-type wrapper that mimics a TrackerEnum member.

  Allows custom trackers (not registered in caliscope's TrackerEnum) to
  be passed to caliscope's Reconstructor, which expects `enum.name` and
  `enum.value()`.
  """

  def __init__(self, name: str, tracker_class):
    self.name = name
    self.value = tracker_class


def run_auto_reconstruction(
  project_dir: Path,
  recording_name: str,
  tracker_name: str = "HOLISTIC",
  fps_target: int = 10,
  model_size: str = "n",
  imgsz: int = 480,
  on_progress: Optional[ProgressCallback] = None,
) -> Path:
  """Run 3D reconstruction on a recording session.

  Args:
    project_dir: Path to caliscope project directory
    recording_name: Name of recording subdirectory under recordings/
    tracker_name: Tracker to use (HOLISTIC, POSE, HAND, etc.)
    fps_target: Target FPS for 2D landmark detection (lower = faster)
    model_size: YOLOv8 model size variant (n/s/m) — only used for YOLOV8_POSE
    imgsz: YOLOv8 inference resolution in pixels — only used for YOLOV8_POSE
    on_progress: Optional callback for progress updates

  Returns:
    Path to output xyz CSV file
  """
  from caliscope.persistence import load_camera_array
  from caliscope.reconstruction.reconstructor import Reconstructor

  # Allow AVI recordings (port_*.avi) without breaking existing MP4 workflows.
  _patch_caliscope_for_avi()

  _emit(on_progress, "reconstruction", "Loading calibration data...", 0)

  camera_array = load_camera_array(project_dir / "camera_array.toml")
  recording_path = project_dir / "recordings" / recording_name

  if not recording_path.exists():
    raise FileNotFoundError(f"Recording not found: {recording_path}")

  # Resolve tracker: use duck-type wrapper for custom trackers,
  # caliscope TrackerEnum for built-in ones.
  if tracker_name == "YOLOV8_POSE":
    from functools import partial
    from .yolov8_pose_tracker import YoloV8PoseTracker
    tracker_factory = partial(YoloV8PoseTracker, model_size=model_size, imgsz=imgsz)
    tracker_enum = _TrackerEnumCompat("YOLOV8_POSE", tracker_factory)
  else:
    from caliscope.trackers.tracker_enum import TrackerEnum
    tracker_enum = TrackerEnum[tracker_name]

  # Stage 1: 2D detection — skip if xy CSV already exists (real-time mode)
  xy_csv_path = recording_path / tracker_enum.name / f"xy_{tracker_enum.name}.csv"

  if xy_csv_path.exists():
    _emit(on_progress, "reconstruction",
          f"Using existing 2D keypoints: {xy_csv_path.name}", 10)
    logger.info(f"Skipping 2D detection, using existing CSV: {xy_csv_path}")
  else:
    _emit(on_progress, "reconstruction", "Starting 2D landmark detection...", 5)

    if tracker_name == "YOLOV8_POSE":
      from .fast_detect import fast_create_xy
      fast_create_xy(
        recording_path, camera_array,
        model_size=model_size, imgsz=imgsz,
        fps_target=fps_target, batch_size=1,
      )
    else:
      reconstructor = Reconstructor(camera_array, recording_path, tracker_enum)
      completed = reconstructor.create_xy(include_video=False, fps_target=fps_target)
      if not completed:
        raise RuntimeError("2D landmark detection was cancelled or failed")

  _emit(on_progress, "reconstruction", "Starting 3D triangulation...", 80)

  # Stage 2: 3D triangulation
  # Check if video files exist — if not (real-time mode), triangulate directly
  has_video = any(
    (recording_path / f"port_{p}.mp4").exists() or
    (recording_path / f"port_{p}.avi").exists()
    for p in camera_array.cameras
  )

  output_path = recording_path / tracker_enum.name / f"xyz_{tracker_enum.name}.csv"

  if has_video:
    # Normal path: Reconstructor reads video metadata for sync
    reconstructor = Reconstructor(camera_array, recording_path, tracker_enum)
    reconstructor.create_xyz()
  else:
    # Real-time path: no video files, triangulate directly from xy CSV
    logger.info("No video files found, triangulating directly from xy CSV")
    xy_data = ImagePoints.from_csv(xy_csv_path)
    if xy_data.df.empty:
      raise RuntimeError("No 2D keypoints found in xy CSV")
    filled_xy = xy_data.fill_gaps(max_gap_size=3)
    xyz_data = filled_xy.triangulate(camera_array)
    if xyz_data.df.empty:
      raise RuntimeError("Triangulation produced no 3D points")
    xyz_data.df.to_csv(output_path, index=False)
    logger.info(f"Saved {len(xyz_data.df)} 3D points to {output_path}")

  # Stage 3: Filter outlier 3D points (critical for narrow-baseline stereo)
  _emit(on_progress, "reconstruction", "Filtering 3D outliers...", 90)
  n_before, n_after = _filter_xyz_outliers(output_path)
  _emit(on_progress, "reconstruction",
        f"Filtered {n_before - n_after} outlier points ({n_before} -> {n_after})", 95)

  # Stage 4: VideoPose3D monocular fusion (optional, requires torch)
  if tracker_name == "YOLOV8_POSE":
    try:
      from .videopose3d_lifter import fuse_stereo_and_monocular
      xy_csv_path = recording_path / tracker_enum.name / f"xy_{tracker_enum.name}.csv"
      _emit(on_progress, "reconstruction", "Running VideoPose3D fusion...", 96)
      fuse_stereo_and_monocular(output_path, xy_csv_path, port=1)
      _emit(on_progress, "reconstruction", "VideoPose3D fusion complete", 98)
    except ImportError:
      logger.info("torch not installed, skipping VideoPose3D fusion")
    except Exception as e:
      logger.warning(f"VideoPose3D fusion failed: {e}")

  _emit(on_progress, "reconstruction", f"Reconstruction complete: {output_path}", 100)

  return output_path
