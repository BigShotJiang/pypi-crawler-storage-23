# Example usage on synthetic survey data

Files in this folder have been run with the OPENAI API on varied use cases to test the library's functionality.