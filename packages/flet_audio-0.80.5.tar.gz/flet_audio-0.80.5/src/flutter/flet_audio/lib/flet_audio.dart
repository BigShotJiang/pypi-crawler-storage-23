library flet_audio;

export "src/extension.dart" show Extension;
