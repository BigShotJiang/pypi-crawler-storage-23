from fractal_repositories.contrib.django.mixins import DjangoModelRepositoryMixin

__all__ = ["DjangoModelRepositoryMixin"]
