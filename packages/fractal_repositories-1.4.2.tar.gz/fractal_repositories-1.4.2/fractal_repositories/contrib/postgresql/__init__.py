from fractal_repositories.contrib.postgresql.mixins import PostgresRepositoryMixin

__all__ = ["PostgresRepositoryMixin"]
