from fractal_repositories.contrib.duckdb.mixins import DuckDBRepositoryMixin

__all__ = ["DuckDBRepositoryMixin"]
