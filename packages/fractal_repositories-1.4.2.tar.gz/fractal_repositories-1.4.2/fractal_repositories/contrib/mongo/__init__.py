from fractal_repositories.contrib.mongo.mixins import MongoRepositoryMixin

__all__ = ["MongoRepositoryMixin"]
