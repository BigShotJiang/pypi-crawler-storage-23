"""Utilities for converting attrs objects to pandas DataFrames.

The main entry points are:

- :func:`attrs_flatten` – flatten a single attrs object (or dict/list/scalar)
  into a flat ``{column: value}`` dict.
- :func:`attrs_to_dataframe` – convert a sequence of attrs objects into a
  ``pd.DataFrame`` with automatic column detection and optional filtering.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import pandas as pd


def _resolve_dotpath(obj: Any, path: str) -> Any:
    """Resolve a dot-notation attribute path on *obj*.

    Each segment is resolved with ``getattr``; if a segment is missing,
    ``None`` is returned.  If the resolved value is callable it is called
    with no arguments before being returned.

    Examples::

        _resolve_dotpath(seg, "attitude.mode")   # → seg.attitude.mode
        _resolve_dotpath(seg, "status")          # → seg.status (or seg.status())
    """
    value: Any = obj
    for part in path.split("."):
        value = getattr(value, part, None)
        if value is None:
            return None
    return value() if callable(value) else value


def _get_class_properties(cls: type) -> list[str]:
    """Return the names of all public ``@property`` members defined on *cls*.

    Private names (leading ``_``) are excluded.
    """
    import inspect
    return [
        name
        for name, _ in inspect.getmembers(cls, predicate=lambda v: isinstance(v, property))
        if not name.startswith("_")
    ]


def attrs_flatten(
    obj: Any,
    *,
    prefix: str = "",
    sep: str = ".",
    max_depth: int = 3,
    include_properties: bool = False,
    extra_fields: dict[str, Any] | None = None,
    extra_attrs: list[str] | None = None,
    _depth: int = 0,
) -> dict[str, Any]:
    """Flatten an attrs object (or dict / list / scalar) into a flat dict.

    Rules:

    - **attrs object**: each public field (no leading ``_``) is recursed into,
      with ``sep`` inserted between the parent key and the field name, e.g.
      field ``inner`` with sub-field ``x`` → key ``inner<sep>x``.
    - **dict**: each key is recursed into using the same naming convention,
      supporting arbitrary nesting, e.g. ``{"a": {"b": 1}}`` →
      ``{"params<sep>a<sep>b": 1}``.
    - **list**: stored as a single cell value.  Fan-out by index is not
      performed because different rows may have different list lengths,
      producing ragged columns that cause confusion in DataFrames.
    - **scalar**: stored as-is.

    Args:
        obj: The object to flatten.  Can be an attrs instance, dict, list,
             or any scalar.
        prefix: Column name prefix accumulated during recursion.  Leave as
                ``""`` for the root call.
        sep: Separator inserted between key segments.  Default is ``"."``.
        max_depth: Maximum recursion depth.  Objects deeper than this are
                   stored as-is.  Default is ``3``.
        extra_fields: Optional dict mapping column names to pre-computed values
                      (typically properties or computed fields).  These are
                      added directly to the result at the top level.
        include_properties: If ``True``, all public ``@property`` members of
                            the root object's class are automatically extracted
                            and added as columns.  Properties already covered
                            by attrs fields, ``extra_fields``, or ``extra_attrs``
                            are skipped.  Default is ``False``.
        extra_attrs: Optional list of attribute paths (dot notation supported)
                     to extract from the root object.  Each path is resolved
                     via successive ``getattr`` calls; if the final value is
                     callable it is called with no arguments.  The column name
                     used is the path as given (e.g. ``"attitude.mode"`` →
                     column ``"attitude.mode"``).  Paths that are already
                     present as flattened attrs fields are skipped.
        _depth: Internal recursion counter – do not set manually.

    Returns:
        A flat ``{str: Any}`` dict ready to become a DataFrame row.

    Examples:
        >>> import attrs
        >>> @attrs.define
        ... class Inner:
        ...     x: float = 1.0
        ...     y: float = 2.0
        ...
        >>> @attrs.define
        ... class Outer:
        ...     name: str = "a"
        ...     inner: Inner = attrs.Factory(Inner)
        ...     tags: list = attrs.Factory(list)
        ...     meta: dict = attrs.Factory(dict)
        ...
        >>> attrs_flatten(Outer(name="a", inner=Inner(x=3, y=4),
        ...                     tags=["x"], meta={"k": 1}))
        {'name': 'a', 'inner.x': 3.0, 'inner.y': 4.0, 'tags': ['x'], 'meta.k': 1}
    """
    import attrs as _attrs

    result: dict[str, Any] = {}

    if _depth > max_depth:
        result[prefix] = obj
        return result

    if _attrs.has(type(obj)):
        for f in _attrs.fields(type(obj)):
            if f.name.startswith("_"):
                continue
            key = f"{prefix}{sep}{f.name}" if prefix else f.name
            val = getattr(obj, f.name)
            result.update(
                attrs_flatten(val, prefix=key, sep=sep, max_depth=max_depth, _depth=_depth + 1)
            )
    elif isinstance(obj, dict):
        if not obj:
            # Empty dict: contribute no columns for this row; pandas will NaN-fill
            # any nested keys that other rows produced from this same field.
            pass
        else:
            for k, v in obj.items():
                key = f"{prefix}{sep}{k}" if prefix else str(k)
                result.update(
                    attrs_flatten(v, prefix=key, sep=sep, max_depth=max_depth, _depth=_depth + 1)
                )

    elif isinstance(obj, list):
        result[prefix] = obj

    else:
        result[prefix] = obj

    # Add extra fields at the top level only (when prefix is empty)
    if _depth == 0:
        import attrs as _attrs
        
        # Build set of existing field names to avoid duplicates
        existing_fields = set(result.keys())
        
        # Also check for attrs fields if object is an attrs class
        if _attrs.has(type(obj)):
            existing_fields.update(f.name for f in _attrs.fields(type(obj)))
        
        # Automatically add public @property members
        if include_properties:
            for prop_name in _get_class_properties(type(obj)):
                if prop_name not in existing_fields:
                    try:
                        result[prop_name] = getattr(obj, prop_name)
                    except Exception:
                        result[prop_name] = None
                    existing_fields.add(prop_name)
        
        # Add extra_fields, checking for duplicates
        if extra_fields:
            for field_name, value in extra_fields.items():
                if field_name not in existing_fields:
                    result[field_name] = value
        
        # Add extra_attrs (dot-notation supported), checking for duplicates
        if extra_attrs:
            for attr_path in extra_attrs:
                if attr_path not in existing_fields:
                    result[attr_path] = _resolve_dotpath(obj, attr_path)

    return result


def attrs_to_dataframe(
    objects: list[Any],
    *,
    sep: str = ".",
    max_depth: int = 3,
    include: list[str] | None = None,
    exclude: list[str] | None = None,
    include_properties: bool = True,
    extra_fields: dict[str, Any] | None = None,
    extra_attrs: list[str] | None = None,
) -> "pd.DataFrame":
    """Convert a sequence of attrs objects into a pandas DataFrame.

    Each object is flattened with :func:`attrs_flatten` and becomes one row.
    Column names are derived automatically: nested attrs objects and dicts
    produce ``parent<sep>child`` column names (default separator is ``"."``).

    Args:
        objects: Sequence of attrs instances (or dicts/scalars) to convert.
        sep: Separator inserted between key segments when building column names
             from nested structures.  Default is ``"."``.
        max_depth: Maximum recursion depth for nested attrs objects / dicts.
                   Default is ``3``.
        include: If given, only columns whose name is in this list are kept.
                 Use the full flattened name for nested columns
                 (e.g. ``"inner.x"`` with the default separator).
        exclude: Field names (or flattened column names) to drop from every row.
        include_properties: If ``True``, all public ``@property`` members of
                            each object's class are automatically extracted and
                            added as columns.  Properties already covered by
                            attrs fields, ``extra_fields``, or ``extra_attrs``
                            are skipped.  Default is ``False``.
        extra_fields: Optional dict mapping column names to callables that
                      extract values from each object.  The callables receive
                      the object and return the column value.  Useful for
                      arbitrary computed fields.  Names already present as
                      flattened attrs fields are skipped.
        extra_attrs: Optional list of attribute paths (dot notation supported)
                     to extract from each object.  Each path is resolved via
                     successive ``getattr`` calls
                     (e.g. ``"attitude.mode"`` → ``obj.attitude.mode``); if
                     the resolved value is callable it is called with no
                     arguments.  The column is named after the path as given.
                     Paths already covered by attrs fields or ``extra_fields``
                     are skipped.

    Returns:
        ``pd.DataFrame`` with one row per object.

    Examples:
        >>> df = attrs_to_dataframe(plan.activities)
        >>> df = attrs_to_dataframe(plan.activities, include=["id", "unit", "start"])
        >>> df = attrs_to_dataframe(plan.activities, exclude=["instrument_area"])
        >>> df = attrs_to_dataframe(plan.activities, sep="__", max_depth=2)
        >>> df = attrs_to_dataframe(
        ...     plan.activities,
        ...     extra_fields={
        ...         "duration": lambda x: x.end_time - x.start_time,
        ...         "category": lambda x: getattr(x, "category", "default")
        ...     }
        ... )
        >>> df = attrs_to_dataframe(
        ...     plan.activities,
        ...     extra_attrs=["status", "attitude.mode", "computed_priority"]
        ... )
        >>> df = attrs_to_dataframe(
        ...     plan.activities,
        ...     include_properties=True,
        ... )
    """
    import pandas as pd

    exclude_set: set[str] = set(exclude or [])
    
    # Filter extra_attrs: exclude those that are already in extra_fields
    extra_fields_set = set(extra_fields.keys()) if extra_fields else set()
    filtered_extra_attrs = None
    if extra_attrs:
        filtered_extra_attrs = [
            attr for attr in extra_attrs 
            if attr not in extra_fields_set
        ]

    rows = []
    for obj in objects:
        # Compute extra field values for this object
        computed_extra = {}
        if extra_fields:
            for field_name, extractor in extra_fields.items():
                computed_extra[field_name] = extractor(obj)

        row = attrs_flatten(obj, sep=sep, max_depth=max_depth, include_properties=include_properties, extra_fields=computed_extra, extra_attrs=filtered_extra_attrs)

        if include is not None:
            row = {k: v for k, v in row.items() if k in include}
        if exclude_set:
            row = {k: v for k, v in row.items() if k not in exclude_set}

        rows.append(row)

    return pd.DataFrame(rows)
