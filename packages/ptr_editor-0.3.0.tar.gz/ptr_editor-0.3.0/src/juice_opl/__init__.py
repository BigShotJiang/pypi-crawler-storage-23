"""juice_opl – backward-compatible re-export shim.

The canonical location is now :mod:`juice_jsoc.opl`::

    from juice_jsoc.opl import Timeline, TimelineItem
    # or
    from juice_jsoc import opl

This module re-exports everything from ``juice_jsoc.opl`` so that existing
import statements continue to work without modification::

    from juice_opl import Timeline  # still works
"""

import warnings

warnings.warn(
    "juice_opl is deprecated. Import from juice_jsoc.opl instead: "
    "from juice_jsoc.opl import ... or from juice_jsoc import opl",
    DeprecationWarning,
    stacklevel=2,
)

from juice_jsoc.opl import (  # noqa: F401
    Configuration,
    Header,
    OplBaseItem,
    Profile,
    RelativeTime,
    Timeline,
    TimelineItem,
    ValidityRange,
    fetch_schema,
    get_schema_cache_path,
    make_opl_differ,
    structure_opl,
    unstructure_opl,
    validate_opl_json,
)
