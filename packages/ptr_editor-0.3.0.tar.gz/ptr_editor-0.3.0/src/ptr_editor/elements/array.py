from __future__ import annotations

from collections.abc import Sequence

import attrs
import numpy as np
from attrs import fields_dict

from attrs_xml import attr, element_define, text
from attrs_xml.core.decorators_utils import classproperty
from ptr_editor.core.ptr_element import PtrElement
from ptr_editor.elements.units import (
    ANGULAR_UNITS_LITERAL,
    ANGULAR_VELOCITY_UNITS_LITERAL,
    DELTA_TIME_UNITS_LITERAL,
)


@element_define
class VectorWithUnits(PtrElement):
    units: str = attr(default="", kw_only=True, converter=str)
    values: np.ndarray = text(
        factory=lambda: np.array([0, 0, 1.0]),
        converter=np.array,
        eq=lambda arr: arr.tobytes(),
    )

    @classmethod
    def from_string(cls, value: Sequence[float | int]) -> VectorWithUnits | None:
        if isinstance(value, Sequence) and not isinstance(value, str):
            try:
                values = [float(v) for v in value]
                return cls(values=np.array(values), units=cls.default_units)
            except ValueError:
                raise ValueError(f"Invalid string format for VectorWithUnits: {value}")

        return None

    def __iter__(self):
        return iter(self.values)

    @classproperty
    def default_units(cls) -> str:
        """This duplicates logic that is also in the Values classes."""

        default_units = fields_dict(cls)["units"].default

        # Handle attrs.Factory objects (from disable_defaults wrapping)
        if isinstance(default_units, attrs.Factory):
            return default_units.factory()

        # defaults units might be a callable, so we need to call it if it is
        if callable(default_units):
            return default_units()

        return default_units

    def __str__(self) -> str:
        return f"{self.values} {self.units}"


@element_define
class TimesVector(VectorWithUnits):
    units: DELTA_TIME_UNITS_LITERAL = attr(
        default="sec",
    )


@element_define
class AnglesVector(VectorWithUnits):
    units: ANGULAR_UNITS_LITERAL = attr(
        default="deg",
    )


@element_define
class AngularVelocityVector(VectorWithUnits):
    units: ANGULAR_VELOCITY_UNITS_LITERAL = attr(
        default="deg/sec",
    )


ARRAYS = TimesVector | AnglesVector | AngularVelocityVector
