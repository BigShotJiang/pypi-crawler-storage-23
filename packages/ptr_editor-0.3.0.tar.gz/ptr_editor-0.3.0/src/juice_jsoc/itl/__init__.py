"""juice_jsoc.itl – JUICE Science Operations Instrument Timeline (ITL) sub-package.

Provides element classes and utilities for working with ITL JSON files::

    from juice_jsoc.itl import Timeline, TimelineItem, Header

Or via the top-level namespace::

    from juice_jsoc import itl
    itl.Timeline.from_json_file("itl.json")
"""

from juice_jsoc.diffing import make_itl_differ

from .elements import (
    Configuration,
    Header,
    ItlBaseItem,
    Profile,
    RelativeTime,
    Timeline,
    TimelineItem,
    ValidityRange,
    fetch_schema,
    get_schema_cache_path,
    structure_itl,
    unstructure_itl,
    validate_itl_json,
)

__all__ = [
    "Configuration",
    "Header",
    "ItlBaseItem",
    "Profile",
    "RelativeTime",
    "Timeline",
    "TimelineItem",
    "ValidityRange",
    "fetch_schema",
    "get_schema_cache_path",
    "make_itl_differ",
    "structure_itl",
    "unstructure_itl",
    "validate_itl_json",
]
