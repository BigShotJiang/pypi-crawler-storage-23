"""JUICE Science Operations JSON Planning (JSOC) package.

This package unifies the former stand-alone ``juice_opl`` and ``juice_apl``
packages under a single namespace::

    from juice_jsoc import opl, apl

    plan = opl.Timeline.from_json_file("opl.json")
    apl_plan = apl.ActivityPlan.from_json_file("apl.json")

Backward-compatible imports from the original packages still work::

    from juice_opl import Timeline        # → juice_jsoc.opl.Timeline
    from juice_apl import ActivityPlan    # → juice_jsoc.apl.ActivityPlan
"""

from juice_jsoc import apl, itl, opl

__all__ = ["apl", "itl", "opl"]
