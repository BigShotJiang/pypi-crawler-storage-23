"""Shared JSON-schema utilities for juice_jsoc (OPL and APL).

Provides :func:`fetch_schema`, :func:`validate_json`, and the internal
helper :func:`_make_schema_strict` used by both the OPL and APL sub-packages.
"""

from __future__ import annotations

import json
from pathlib import Path


def get_schema_cache_path(app_name: str, filename: str) -> Path:
    """Return the path to the schema cache file for *app_name*.

    Args:
        app_name: Application name used as the cache directory name
                  (e.g. ``"juice_opl"`` or ``"juice_apl"``).
        filename: Cache file name (e.g. ``"jsoc-opl-schema.json"``).

    Returns:
        Absolute path inside the OS user-cache directory.
    """
    from platformdirs import user_cache_dir

    cache_dir = Path(user_cache_dir(app_name, "ptr-editor"))
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir / filename


def fetch_schema(local_schema_path: Path, *, force_refresh: bool = False) -> dict:  # noqa: ARG001
    """Load a bundled JSON schema from disk.

    Remote fetching is deliberately not implemented here; the schema shipped
    with the package is always used.

    Args:
        local_schema_path: Path to the bundled ``*.json`` schema file.
        force_refresh: Ignored — kept for API compatibility.

    Returns:
        Parsed schema dictionary.

    Raises:
        FileNotFoundError: If *local_schema_path* does not exist.
    """
    if not local_schema_path.exists():
        msg = f"Bundled schema not found at {local_schema_path}"
        raise FileNotFoundError(msg)

    with local_schema_path.open("r") as f:
        return json.load(f, strict=False)


def _make_schema_strict(schema: dict) -> dict:
    """Return a deep copy of *schema* with ``additionalProperties`` set to
    ``false`` everywhere an object with ``properties`` is found.

    Args:
        schema: The JSON schema dict to process.

    Returns:
        Modified copy of the schema.
    """
    import copy

    schema = copy.deepcopy(schema)

    def _recurse(obj):
        if isinstance(obj, dict):
            if "properties" in obj and obj.get("additionalProperties") is not False:
                obj["additionalProperties"] = False
            for v in obj.values():
                _recurse(v)
        elif isinstance(obj, list):
            for item in obj:
                _recurse(item)

    _recurse(schema)
    return schema


def validate_json(
    data: dict | str | Path,
    schema: dict,
    label: str = "JSON",
    *,
    strict: bool = False,
    warn_extra_fields: bool = False,
) -> tuple[bool, list[str]]:
    """Validate *data* against a JSON schema.

    Args:
        data: Data as a ``dict``, JSON string, or file path.
        schema: Schema dict to validate against.
        label: Human-readable label used in error messages (e.g. ``"OPL"``).
        strict: If ``True``, modify the schema to disallow additional
                properties everywhere.
        warn_extra_fields: If ``True``, perform an extra strict-mode pass
                and emit warnings for extra fields rather than errors.

    Returns:
        Tuple of ``(is_valid, messages)`` where *messages* contains any
        error or warning strings.
    """
    try:
        import jsonschema
    except ImportError as err:
        msg = (
            "jsonschema package required for validation. "
            "Install with: pip install jsonschema"
        )
        raise ImportError(msg) from err

    # Resolve data from file path or raw JSON string
    if isinstance(data, (str, Path)):
        path = Path(data)
        try:
            path_exists = path.exists()
        except OSError:
            path_exists = False
        if path_exists:
            with path.open("r") as f:
                data = json.load(f)
        else:
            data = json.loads(str(data))

    messages: list[str] = []

    # Optional extra-field warning pass
    if warn_extra_fields and not strict:
        strict_schema = _make_schema_strict(schema)
        try:
            jsonschema.validate(instance=data, schema=strict_schema)
        except jsonschema.ValidationError as e:
            if "Additional properties are not allowed" in e.message:
                messages.append(f"⚠ Warning: {e.message}")
                if e.path:
                    messages.append(f"  Path: {' -> '.join(str(p) for p in e.path)}")
        except jsonschema.SchemaError:
            pass

    validation_schema = _make_schema_strict(schema) if strict else schema

    try:
        jsonschema.validate(instance=data, schema=validation_schema)
    except jsonschema.ValidationError as e:
        messages.append(f"✗ {label} validation error: {e.message}")
        if e.path:
            messages.append(f"  Path: {' -> '.join(str(p) for p in e.path)}")
        if e.schema_path:
            messages.append(
                f"  Schema path: {' -> '.join(str(p) for p in e.schema_path)}",
            )
        return False, messages
    except jsonschema.SchemaError as e:
        messages.append(f"✗ Schema error: {e.message}")
        return False, messages
    else:
        return True, messages
