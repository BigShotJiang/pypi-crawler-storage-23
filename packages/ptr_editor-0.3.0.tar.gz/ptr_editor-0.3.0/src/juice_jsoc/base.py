"""Shared base class for juice_jsoc (OPL and APL) elements."""

from __future__ import annotations

from attrs_xml import BaseElement


class JsocBaseItem(BaseElement):
    """Abstract base class for all JUICE JSOC (OPL/APL) domain objects.

    Subclasses in :mod:`juice_jsoc.opl` and :mod:`juice_jsoc.apl` implement
    :meth:`to_json_string` with their own serialisation converter and
    ``None``-handling rules.
    """

    @property
    def source(self) -> tuple[str, str]:
        """Return ``(json_string, 'json')`` for source-format inspection."""
        return self.to_json_string(), "json"

    def to_json_string(self, indent: int = 2) -> str:
        """Convert this element to a JSON string.

        Sub-packages must override this method with a converter-aware
        implementation.
        """
        raise NotImplementedError
