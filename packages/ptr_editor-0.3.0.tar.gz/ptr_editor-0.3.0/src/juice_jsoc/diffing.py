"""Shared diffing utilities for juice_jsoc (OPL, APL, and ITL).

Provides :func:`get_fields` and :func:`make_differ`, a generic factory that
:mod:`juice_jsoc.opl`, :mod:`juice_jsoc.apl`, and :mod:`juice_jsoc.itl`
use to build their format-specific :class:`~ptr_editor.diffing.TimelineDiffer`.
"""

from __future__ import annotations

from attrs import fields as attrs_fields

from ptr_editor.diffing import TimelineDiffer
from ptr_editor.diffing.timeline_differ_simple import (
    AttributeChangeChecker,
    CheckerBase,
    MoveChecker,
    TimeAttributeChecker,
)


def get_fields(cls) -> list[str]:
    """Return all public (non-underscore) attrs field names for *cls*."""
    return [f.name for f in attrs_fields(cls) if not f.name.startswith("_")]


def make_differ(
    cls,
    temporal_attrs: set[str],
    *,
    include_temporal: bool = True,
    custom_checkers: list[CheckerBase] | None = None,
) -> TimelineDiffer:
    """Create a :class:`~ptr_editor.diffing.TimelineDiffer` for *cls*.

    Args:
        cls: The attrs element class to build checkers for
             (e.g. :class:`~juice_jsoc.opl.elements.TimelineItem` or
             :class:`~juice_jsoc.apl.elements.Activity`).
        temporal_attrs: Set of attribute names that represent time fields
                        (used for :class:`TimeAttributeChecker` instances
                        and excluded from :class:`AttributeChangeChecker`).
        include_temporal: When ``True`` (default), prepend a
                          :class:`MoveChecker` and one
                          :class:`TimeAttributeChecker` per entry in
                          *temporal_attrs*.
        custom_checkers: Extra checker instances appended after auto-generated
                         ones.

    Returns:
        Configured :class:`~ptr_editor.diffing.TimelineDiffer` instance.
    """
    checkers: list[CheckerBase] = []

    if include_temporal:
        checkers.append(MoveChecker())
        for attr in sorted(temporal_attrs):
            checkers.append(TimeAttributeChecker(attr))

    all_fields = get_fields(cls)
    checkers.extend(
        AttributeChangeChecker(attr)
        for attr in all_fields
        if attr not in temporal_attrs
    )

    if custom_checkers:
        checkers.extend(custom_checkers)

    return TimelineDiffer(checkers=checkers)


# Format-specific convenience functions


def make_apl_differ(
    *,
    include_temporal: bool = True,
    custom_checkers: list[CheckerBase] | None = None,
) -> TimelineDiffer:
    """Create a :class:`~ptr_editor.diffing.TimelineDiffer` for APL
    :class:`~juice_jsoc.apl.elements.Activity` objects.

    Args:
        include_temporal: Include temporal change checkers
                          (move, start, end, duration).
        custom_checkers: Additional custom checker instances.

    Returns:
        Configured :class:`~ptr_editor.diffing.TimelineDiffer` instance.

    Example:
        >>> differ = make_apl_differ(include_temporal=True)
        >>> diff_result = differ.diff(match_result)
        >>> for change in diff_result.changes:
        ...     print(change.describe_changes())
    """
    # Import here to avoid circular dependencies
    from juice_jsoc.apl.elements import Activity

    return make_differ(
        Activity,
        temporal_attrs={"start", "end", "duration"},
        include_temporal=include_temporal,
        custom_checkers=custom_checkers,
    )


def make_itl_differ(
    *,
    include_temporal: bool = True,
    custom_checkers: list[CheckerBase] | None = None,
) -> TimelineDiffer:
    """Create a :class:`~ptr_editor.diffing.TimelineDiffer` for ITL
    :class:`~juice_jsoc.itl.elements.TimelineItem` objects.

    Args:
        include_temporal: Include temporal change checkers
                          (move, start_time, end_time, duration).
        custom_checkers: Additional custom checker instances.

    Returns:
        Configured :class:`~ptr_editor.diffing.TimelineDiffer` instance.

    Example:
        >>> differ = make_itl_differ(include_temporal=True)
        >>> diff_result = differ.diff(match_result)
        >>> for change in diff_result.changes:
        ...     print(change.describe_changes())
    """
    # Import here to avoid circular dependencies
    from juice_jsoc.itl.elements import TimelineItem

    return make_differ(
        TimelineItem,
        temporal_attrs={"start_time", "end_time", "duration"},
        include_temporal=include_temporal,
        custom_checkers=custom_checkers,
    )


def make_opl_differ(
    *,
    include_temporal: bool = True,
    custom_checkers: list[CheckerBase] | None = None,
) -> TimelineDiffer:
    """Create a :class:`~ptr_editor.diffing.TimelineDiffer` for OPL
    :class:`~juice_jsoc.opl.elements.TimelineItem` objects.

    Args:
        include_temporal: Include temporal change checkers
                          (move, start_time, end_time, duration).
        custom_checkers: Additional custom checker instances.

    Returns:
        Configured :class:`~ptr_editor.diffing.TimelineDiffer` instance.

    Example:
        >>> differ = make_opl_differ(include_temporal=True)
        >>> diff_result = differ.diff(match_result)
        >>> for change in diff_result.changes:
        ...     print(change.describe_changes())
    """
    # Import here to avoid circular dependencies
    from juice_jsoc.opl.elements import TimelineItem

    return make_differ(
        TimelineItem,
        temporal_attrs={"start_time", "end_time", "duration"},
        include_temporal=include_temporal,
        custom_checkers=custom_checkers,
    )
