import json
import os
from pathlib import Path
from typing import Any, Literal, Self

import pandas as pd
from attrs import field
from cattrs.preconf.json import make_converter
from loguru import logger as log

from attrs_xml import element_define
from attrs_xml.formatting import parse_delta_time_string
from attrs_xml.xml.converter import register_pandas_times_hooks

# Shared juice_jsoc utilities
from juice_jsoc.base import JsocBaseItem
from juice_jsoc.schema import (
    fetch_schema as _fetch_schema_generic,
)
from juice_jsoc.schema import (
    get_schema_cache_path as _get_schema_cache_path_generic,
)
from juice_jsoc.schema import (
    validate_json,
)
from juice_jsoc.utils import _enforce_naive_utc_timestamp, remove_none_values
from ptr_editor.diffing import DiffResult
from time_segments.segment_mixin import TimeSegmentMixin
from time_segments.segments_collection_mixin import SegmentsCollectionMixin

# Create a converter instance for OPL schemas
converter = make_converter()

# OPL Schema URL
OPL_SCHEMA_URL = "https://juicesoc.esac.esa.int/data/schemas/jsoc-opl-schema.json"
_LOCAL_OPL_SCHEMA_PATH = Path(__file__).parent / "jsoc-opl-schema.json"


def get_schema_cache_path() -> Path:
    """Get the path to the OPL schema cache file."""
    return _get_schema_cache_path_generic("juice_opl", "jsoc-opl-schema.json")


def fetch_schema(url: str = OPL_SCHEMA_URL, *, force_refresh: bool = False) -> dict:  # noqa: ARG001
    """Load the bundled OPL schema from disk (jsoc-opl-schema.json)."""
    return _fetch_schema_generic(_LOCAL_OPL_SCHEMA_PATH, force_refresh=force_refresh)



def validate_opl_json(
    data: dict | str | Path,
    schema: dict | None = None,
    *,
    strict: bool = False,
    warn_extra_fields: bool = False,
) -> tuple[bool, list[str]]:
    """Validate OPL JSON data against the schema.

    Args:
        data: OPL data as dict, JSON string, or file path
        schema: Schema dict (if None, uses the bundled schema)
        strict: If True, modify schema to disallow additionalProperties
        warn_extra_fields: If True, validate twice and report extra fields as warnings

    Returns:
        Tuple of (is_valid, messages) where messages include errors and warnings

    Example:
        >>> is_valid, errors = validate_opl_json("opl.json")
        >>> if not is_valid:
        ...     for error in errors:
        ...         print(error)
    """
    if schema is None:
        schema = fetch_schema()
    return validate_json(data, schema, "OPL", strict=strict, warn_extra_fields=warn_extra_fields)


class OplBaseItem(JsocBaseItem):
    """Base class for OPL items (serialises to JSON with None-stripping)."""

    def to_json_string(self, indent: int = 2) -> str:
        """Convert OPL element to a JSON string with None values removed.

        Args:
            indent: JSON indentation level (default: 2)

        Returns:
            JSON string representation

        Example:
            >>> json_str = opl.to_json_string()
        """
        data = converter.unstructure(self)
        data = remove_none_values(data)
        return json.dumps(data, indent=indent, ensure_ascii=False)



@element_define
class RelativeTime(OplBaseItem):
    """Relative time specification."""

    # Event name for relative time
    name: str = field()
    # Counter associated with the event
    counter: int = field()
    # Relative time format [[ddd.]hh:]mm:ss[.SSS]
    delta_time: pd.Timedelta = field(converter=parse_delta_time_string)

    # Not part of the official schema, used for internal calculations
    event_abs_time: pd.Timestamp | None = field(
        default=None,
        converter=lambda x: (
            _enforce_naive_utc_timestamp(pd.Timestamp(x)) if x is not None else None
        ),
    )

    @property
    def abs_time(self) -> pd.Timestamp | None:
        """Get absolute time if calculated."""
        if self.event_abs_time is not None:
            return self.event_abs_time + self.delta_time
        msg = (
            "Absolute time not known for this RelativeTime"
            " instance. Cannot compute an abs time."
        )
        raise ValueError(msg)

    @abs_time.setter
    def abs_time(self, value: pd.Timestamp | None) -> None:
        """Set absolute time."""
        if self.event_abs_time is not None:
            self.delta = (
                _enforce_naive_utc_timestamp(pd.Timestamp(value)) - self.event_abs_time
            )
        else:
            msg = (
                "Cannot set time on RelativeTime"
                " without event_abs_time defined."
            )
            raise ValueError(msg)


@element_define
class Configuration(OplBaseItem):
    """Configuration object containing schema information and applicable event files."""

    # OPL JSON Schema used
    json_schema_version: str | None = field(default=None)
    # Flight Control Team User Event file (UEVT) in use
    evt_fct: str | None = field(default=None)
    # Flight Dynamics STP/MTP Event file (EVTC, EVTM) in use
    evt_fdy: str | None = field(default=None)
    # Science Operations Center Event file (EVT_SOC) in use
    evt_soc: str | None = field(default=None)


@element_define
class ValidityRange(OplBaseItem):
    """Validity range with start and end times."""

    # Start time in UTC format YYYY-MM-DDThh:mm:ss[.mmm]Z
    start_time: str = field()
    # End time in UTC format YYYY-MM-DDThh:mm:ss[.mmm]Z
    end_time: str = field()


@element_define
class Header(OplBaseItem):
    """OPL file header."""

    creation_date: pd.Timestamp = field(
        converter=lambda x: pd.Timestamp(x) if not isinstance(x, pd.Timestamp) else x,
    )
    # Author(s) of the file - Single author or Multiple authors
    author: str | list[str] = field()

    # Filename matching pattern ^OPL_.*\.json$
    filename: str | None = field(default=None)
    # Creation date of the file in UTC format YYYY-MM-DDThh:mm:ss[.mmm]Z

    # Origin of the file
    origin: str | None = field(default=None)
    # Version of the file
    version: str | None = field(default=None)
    # Configuration object containing schema, session file, and version details
    configuration: Configuration | None = field(default=None)
    # Validity range with start and end times
    validity_range: ValidityRange | None = field(default=None)
    # Scenario name for which this planning file was created
    scenario: str | None = field(default=None)
    # Instrument area for free usage by the originator
    instrument_area_header: dict[str, Any] | None = field(default=None)

    def renew_creation_date(self) -> Self:
        """Renew the creation date to the current time."""
        self.creation_date = pd.Timestamp.utcnow()
        return self

    def _repr_html_(self) -> str:
        """Generate HTML representation for Jupyter notebooks."""
        # --- badge helper ---
        badge_style = (
            "display:inline-block;padding:2px 8px;border-radius:4px;"
            "color:#fff;font-size:11px;font-weight:bold;margin-right:4px;"
            "vertical-align:middle;"
        )

        # --- author display ---
        if isinstance(self.author, list):
            author_display = ", ".join(self.author)
        else:
            author_display = self.author or "N/A"

        # --- creation date ---
        creation_date_str = str(self.creation_date) if self.creation_date else "N/A"

        # --- validity range ---
        validity_str = "N/A"
        if self.validity_range:
            start = self.validity_range.start_time or "N/A"
            end = self.validity_range.end_time or "N/A"
            validity_str = f"{start} → {end}"

        lbl = (
            "font-weight:bold;color:#1976D2;font-size:13px;"
        )
        val = "color:#333;font-size:13px;"
        mono = "font-family:'Courier New',monospace;word-break:break-all;"

        html = f"""\
<div style="border:2px solid #FF9800;border-radius:8px;\
padding:12px;background:#fff3e0;\
font-family:'Segoe UI',Arial,sans-serif;max-width:900px;">
  <div style="margin-bottom:12px;">
    <div style="font-size:16px;font-weight:bold;color:#E65100;">\
\U0001F4A1 OPL Header</div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;\
gap:4px 12px;margin-bottom:10px;\
padding:6px 0;border-top:1px solid #FFE0B2;border-bottom:1px solid #FFE0B2;">
    <div>
      <div style="{lbl}👤 Author</div>
      <div style="{val}">{author_display}</div>
    </div>
    <div>
      <div style="{lbl}📅 Created</div>
      <div style="{val}{mono}">{creation_date_str}</div>
    </div>
    <div>
      <div style="{lbl}📄 Filename</div>
      <div style="{val}{mono}">{self.filename or 'N/A'}</div>
    </div>
    <div>
      <div style="{lbl}🏷️ Version</div>
      <div style="{val}">{self.version or 'N/A'}</div>
    </div>
  </div>"""

        # Scenario badge
        if self.scenario:
            scenario_badge = (
                f"<span style='{badge_style}background:#1976D2;'>"
                f"📍 {self.scenario}</span>"
            )
            html += f"<div style='margin-bottom:8px;'>{scenario_badge}</div>"

        # Origin
        if self.origin:
            html += (
                "<div style='margin-bottom:8px;'>"
                "<div style='font-weight:bold;color:#1976D2;"
                f"font-size:13px;'>🌐 Origin</div>"
                f"<div style='color:#333;font-size:13px;"
                f"margin-left:8px;'>{self.origin}</div></div>"
            )

        # Validity range
        if self.validity_range:
            html += (
                "<div style='margin-bottom:8px;'>"
                "<div style='font-weight:bold;color:#1976D2;"
                f"font-size:13px;'>⏱️ Validity Range</div>"
                f"<div style='color:#333;font-size:13px;"
                f"margin-left:8px;{mono}'>{validity_str}</div></div>"
            )

        # Configuration
        if self.configuration:
            config_parts = []
            if self.configuration.schema:
                config_parts.append(f"Schema: {self.configuration.schema}")
            if self.configuration.session_file:
                config_parts.append(f"Session: {self.configuration.session_file}")
            if self.configuration.version:
                config_parts.append(f"Config Ver: {self.configuration.version}")

            if config_parts:
                config_html = "<br>".join(config_parts)
                html += (
                    "<div style='margin-bottom:8px;'>"
                    "<div style='font-weight:bold;color:#1976D2;"
                    f"font-size:13px;'>⚙️ Configuration</div>"
                    f"<div style='color:#333;font-size:12px;"
                    f"margin-left:8px;line-height:1.4;'>{config_html}</div></div>"
                )

        # Instrument area
        if self.instrument_area_header:
            inst_html = "<br>".join(
                f"<b>{k}</b>: {v}" for k, v in self.instrument_area_header.items()
            )
            html += (
                "<div style='margin-bottom:8px;'>"
                "<div style='font-weight:bold;color:#1976D2;"
                f"font-size:13px;'>🔧 Instrument Area</div>"
                f"<div style='color:#333;font-size:12px;"
                f"margin-left:8px;line-height:1.4;'>{inst_html}</div></div>"
            )

        html += "</div>"
        return html


@element_define
class Profile(OplBaseItem):
    """Generic profile for power, data rate, or data volume."""

    # Unit of measurement for the profile
    unit: str = field()
    # Key-value pairs, no enforced format on keys
    values: dict[str, float] = field()
    # Optional name for the profile
    name: str | None = field(default=None)


def _parse_timeline_item_time_argument(
    value: pd.Timestamp | RelativeTime | str,
) -> pd.Timestamp | RelativeTime:
    """Parse a time argument for TimelineItem start/end properties."""
    if isinstance(value, pd.Timestamp):
        return _enforce_naive_utc_timestamp(value)

    if isinstance(value, RelativeTime):
        return value
    try:
        return _enforce_naive_utc_timestamp(pd.Timestamp(value))
    except Exception as e:
        msg = f"Unrecognized time value: {value}"
        raise ValueError(msg) from e


@element_define
class TimelineItem(TimeSegmentMixin, OplBaseItem):
    """Timeline item representing an observation or action."""

    # Indicates that the activity is an observation, segmentation, or generic
    type: Literal["OBSERVATION", "SEGMENTATION", "GENERIC"] = field(
        converter=lambda x: str(x).upper(),
    )
    # Instrument/Unit responsible for the activity
    instrument: Literal[
        "3GM",
        "RPWI",
        "GALA",
        "RIME",
        "JMAG",
        "JANUS",
        "UVS",
        "MAJIS",
        "SWI",
        "PEPLO",
        "PEPHI",
        "NAVCAM",
        "RADEM",
        "GENERIC",
        "SPC",
        "JUICE",
        "POINTING",
        "COSMO",
        "COPAS",
        "WG1",
        "WG2",
        "WG3",
        "WG4",
        "WGX",
        "PTG",
        "COS",
        "COP",
    ] = field()
    # Name of the action or observation, must correspond
    # to an observation definition or a modelled action
    name: str = field()
    # Start time of the activity, either absolute or relative
    start_time: pd.Timestamp | RelativeTime = field(
        converter=_parse_timeline_item_time_argument,
    )
    # End time of the activity, either absolute
    # (UTC format YYYY-MM-DDThh:mm:ss[.mmm]Z) or relative
    end_time: pd.Timestamp | RelativeTime = field(
        converter=_parse_timeline_item_time_argument,
    )
    # Unique ID of the action or observation, must correspond
    # to an observation definition or a modelled action
    unique_id: str | None = field(default=None)
    # Indicates the observation type if it is PRIME or RIDER
    observation_type: Literal["RIDER", "PRIME", "OBSERVATION"] | None = field(
        default=None,
    )
    # Target of the activity as a LID of a PDS4 Target
    # (e.g., satellite.earth.moon) or array of targets
    # Find valid targets here https://pds.nasa.gov/data/pds4/context-pds4/target/
    target: str | list[str] | None = field(default=None)
    # Observation parameters as an array of parameter name and value pairs
    parameters: dict[str, Any] | None = field(default=None)
    # Optional power usage profile keyed by HH:MM:SS
    power_profile: Profile | None = field(default=None)
    # Optional data-rate profile keyed by HH:MM:SS
    data_rate_profile: Profile | None = field(default=None)
    # Optional Data Volume profile keyed by HH:MM:SS
    data_volume_profile: Profile | None = field(default=None)
    # Pointing type as defined by the JUICE SOC Pointing Type table, can be null
    pointing: str | None = field(default=None)
    # Description of the pointing if needs to be expanded
    # from the inherent pointing type description, can be null
    pointing_description: str | None = field(default=None)
    # Attribute that describes whether if the instrument team
    # requests to design the pointing for the prime observation
    pointing_designer: bool | None = field(default=None)
    # Observation or action textual description, can be null
    description: str | None = field(default=None)
    # Rules for scheduling the activity, can be null
    scheduling_rules: str | None = field(default=None)
    # Free text comments related to the activity, can be null
    comment: str | None = field(default=None)
    # Instrument area for free usage by the originator
    instrument_area: dict[str, Any] | None = field(factory=dict)
    # Internal field to track segment_definition format for CSV roundtrip
    _csv_segment_definition: str | None = field(default=None, repr=False)

    @property
    def start(self) -> pd.Timestamp | None:
        """Get start time as pd.Timestamp for TimeSegmentMixin compatibility."""
        if isinstance(self.start_time, RelativeTime):
            return self.start_time.abs_time
        return self.start_time

    @start.setter
    def start(self, value: pd.Timestamp | str) -> None:
        """Set start time from pd.Timestamp for TimeSegmentMixin compatibility."""
        if isinstance(self.start_time, RelativeTime):
            self.start_time.abs_time = value
        else:
            self.start_time = value

    @property
    def end(self) -> pd.Timestamp | None:
        if isinstance(self.end_time, RelativeTime):
            return self.end_time.abs_time
        return self.end_time

    @end.setter
    def end(self, value: pd.Timestamp | RelativeTime | str) -> None:
        """Set end time from pd.Timestamp for TimeSegmentMixin compatibility."""
        if isinstance(self.end_time, RelativeTime):
            self.end_time.abs_time = value
        else:
            self.end_time = value

    @property
    def id(self) -> str | None:
        """Get ID for TimeSegmentMixin compatibility."""
        return self.unique_id or self.name

    @staticmethod
    def _format_profile_html(profile: Profile, icon: str) -> str:
        """Format a Profile as an HTML snippet for _repr_html_."""
        label = profile.name or ""
        rows = "".join(
            f"<tr><td style='padding:1px 8px;font-family:monospace;'>"
            f"{k}</td><td style='padding:1px 8px;text-align:right;'>"
            f"{v}</td></tr>"
            for k, v in profile.values.items()
        )
        return (
            f"<div style='margin-bottom:8px;'>"
            f"<div style='font-weight:bold;color:#1976D2;"
            f"font-size:14px;'>{icon} {label}</div>"
            f"<div style='margin-left:8px;color:#555;"
            f"font-size:12px;'>Unit: {profile.unit}</div>"
            f"<table style='margin-left:8px;font-size:12px;"
            f"border-collapse:collapse;'>{rows}</table></div>"
        )

    def _repr_html_(self) -> str:  # noqa: C901
        """Generate HTML representation for Jupyter notebooks."""
        # --- badge helper ---
        badge_style = (
            "display:inline-block;padding:2px 8px;border-radius:4px;"
            "color:#fff;font-size:11px;font-weight:bold;margin-right:4px;"
            "vertical-align:middle;"
        )
        type_colors = {
            "OBSERVATION": "#1976D2",
            "SEGMENTATION": "#7B1FA2",
            "GENERIC": "#616161",
        }
        obs_colors = {
            "PRIME": "#2E7D32",
            "RIDER": "#E65100",
            "OBSERVATION": "#1565C0",
        }
        type_bg = type_colors.get(self.type, "#616161")
        type_badge = (
            f"<span style='{badge_style}background:{type_bg};'>"
            f"{self.type}</span>"
        )
        obs_badge = ""
        if self.observation_type:
            obs_bg = obs_colors.get(self.observation_type, "#757575")
            obs_badge = (
                f"<span style='{badge_style}background:{obs_bg};'>"
                f"{self.observation_type}</span>"
            )
        designer_flag = ""
        if self.pointing_designer:
            designer_flag = (
                f"<span style='{badge_style}background:#FF6F00;'"
                " title='Pointing designer requested'>"
                "\U0001F3AF Designer</span>"
            )
        elif self.pointing_designer is False:
            designer_flag = (
                f"<span style='{badge_style}background:#9E9E9E;"
                "text-decoration:line-through;'"
                " title='Pointing designer NOT requested'>"
                "\U0001F3AF Designer</span>"
            )
        instrument_badge = (
            f"<span style='{badge_style}background:#00695C;'>"
            f"\U0001F52D {self.instrument}</span>"
        )

        # --- duration ---
        duration_str = "N/A"
        if self.duration is not None:
            total_sec = int(self.duration.total_seconds())
            hours, remainder = divmod(total_sec, 3600)
            minutes, seconds = divmod(remainder, 60)
            duration_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"

        # --- target display ---
        if isinstance(self.target, list):
            target_display = ", ".join(self.target)
        else:
            target_display = self.target or "N/A"

        # --- unique id display ---
        uid = self.unique_id or "N/A"

        # --- description (shown early, under name) ---
        desc_html = ""
        if self.description:
            desc_html = (
                "<div style='color:#555;font-size:12px;"
                "margin-top:2px;line-height:1.4;'>"
                f"{self.description}</div>"
            )

        # --- target badge ---
        target_badge = ""
        if target_display != "N/A":
            target_badge = (
                f"<span style='{badge_style}background:#4E342E;'>"
                f"\U0001F3AF {target_display}</span>"
            )

        lbl = (
            "font-weight:bold;color:#1976D2;font-size:13px;"
        )
        val = "color:#333;font-size:13px;"
        mono = "font-family:'Courier New',monospace;"

        html = f"""\
<div style="border:2px solid #2196F3;border-radius:8px;\
padding:12px;background:#f5f5f5;\
font-family:'Segoe UI',Arial,sans-serif;max-width:900px;">
  <div style="display:flex;align-items:center;\
justify-content:space-between;margin-bottom:6px;">
    <div style="display:flex;align-items:center;gap:6px;\
flex-wrap:wrap;">
      <button onclick="navigator.clipboard.writeText('{uid}')" \
style="background:none;border:1px solid #bbb;border-radius:3px;\
cursor:pointer;font-size:11px;padding:1px 5px;\
vertical-align:middle;color:#888;" \
title="Copy ID to clipboard">\U0001F4CB</button>\
<span style="color:#444;font-size:11px;{mono}\
word-break:break-all;" title="Unique ID">{uid}</span>
      {type_badge}{obs_badge}{designer_flag}
    </div>
    <div>{instrument_badge}{target_badge}</div>
  </div>
  <div style="margin-bottom:8px;">
    <div style="font-size:16px;font-weight:bold;color:#222;">\
{self.name}</div>
    {desc_html}
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;\
gap:4px 12px;margin-bottom:10px;\
padding:6px 0;border-top:1px solid #ddd;border-bottom:1px solid #ddd;">
    <div>
      <div style="{lbl}">\u25B6 Start</div>
      <div style="{val}{mono}">{self.start_time}</div>
    </div>
    <div>
      <div style="{lbl}">\u25A0 End</div>
      <div style="{val}{mono}">{self.end_time}</div>
    </div>
    <div>
      <div style="{lbl}">\u23F1 Duration</div>
      <div style="{val}{mono}">{duration_str}</div>
    </div>
  </div>"""

        # --- optional text sections (description already shown) ---
        # Pointing + pointing description merged
        if self.pointing:
            ptg_desc = ""
            if self.pointing_description:
                ptg_desc = (
                    f"<div style='color:#555;font-size:12px;"
                    f"margin-left:8px;line-height:1.4;'>"
                    f"{self.pointing_description}</div>"
                )
            html += (
                "<div style='margin-bottom:8px;'>"
                "<div style='font-weight:bold;color:#1976D2;"
                f"font-size:13px;'>\U0001F9ED Pointing</div>"
                f"<div style='color:#333;font-size:13px;"
                f"margin-left:8px;'>{self.pointing}</div>"
                f"{ptg_desc}</div>"
            )
        elif self.pointing_description:
            html += (
                "<div style='margin-bottom:8px;'>"
                "<div style='font-weight:bold;color:#1976D2;"
                f"font-size:13px;'>\U0001F9ED Pointing</div>"
                f"<div style='color:#555;font-size:13px;"
                f"margin-left:8px;line-height:1.4;'>"
                f"{self.pointing_description}</div></div>"
            )

        _optional_sections: list[tuple[str, str | None, str]] = [
            (
                "\U0001F4C5 Scheduling Rules",
                self.scheduling_rules,
                "#555",
            ),
            ("\U0001F4AC Comment", self.comment, "#555"),
        ]
        for label, value, color in _optional_sections:
            if value:
                italic = (
                    "font-style:italic;" if "Comment" in label else ""
                )
                html += (
                    f"<div style='margin-bottom:8px;'>"
                    f"<div style='font-weight:bold;color:#1976D2;"
                    f"font-size:13px;'>{label}</div>"
                    f"<div style='color:{color};font-size:13px;"
                    f"margin-left:8px;line-height:1.4;{italic}'>"
                    f"{value}</div></div>"
                )

        # --- parameters ---
        if self.parameters:
            params_rows = "".join(
                f"<tr><td style='padding:1px 8px;font-weight:bold;'>"
                f"{k}</td><td style='padding:1px 8px;'>{v}</td></tr>"
                for k, v in self.parameters.items()
            )
            html += (
                "<div style='margin-bottom:8px;'>"
                "<div style='font-weight:bold;color:#1976D2;"
                "font-size:14px;'>\u2699 Parameters</div>"
                "<table style='margin-left:8px;font-size:12px;"
                f"border-collapse:collapse;'>{params_rows}</table>"
                "</div>"
            )

        # --- profiles ---
        if self.power_profile:
            html += self._format_profile_html(
                self.power_profile, "\u26A1 Power Profile",
            )
        if self.data_rate_profile:
            html += self._format_profile_html(
                self.data_rate_profile,
                "\U0001F4E1 Data Rate Profile",
            )
        if self.data_volume_profile:
            html += self._format_profile_html(
                self.data_volume_profile,
                "\U0001F4BE Data Volume Profile",
            )

        # --- instrument_area ---
        if self.instrument_area:
            import json as _json

            area_json = _json.dumps(
                self.instrument_area, indent=2, ensure_ascii=False,
            )
            html += (
                "<div style='margin-bottom:8px;'>"
                "<div style='font-weight:bold;color:#1976D2;"
                "font-size:14px;'>\U0001F4E6 Instrument Area</div>"
                "<pre style='margin-left:8px;font-size:12px;"
                "background:#e8e8e8;padding:6px;border-radius:4px;"
                f"overflow-x:auto;'>{area_json}</pre></div>"
            )

        html += "</div>"
        return html


@element_define
class Timeline(SegmentsCollectionMixin[TimelineItem], OplBaseItem):
    """JUICE Science Operations Observation Plan Input File Schema v04-draft."""

    # Optional header with metadata
    header: Header | None = field(default=None, kw_only=True)
    # Array of timeline items (observations and actions)
    timeline: list[TimelineItem] = field(factory=list)



    @property
    def _segments_(self) -> list[TimelineItem]:
        """Return timeline items as segments for SegmentsCollectionMixin."""
        return self.timeline

    def _create_empty_segment(self, start, end, **kwargs) -> TimelineItem:
        """Create an empty segment with the given start and end times."""

        defaults = {
            "name": "UNDEFINED",
            "type": "GENERIC",
            "instrument": "GENERIC",
        }

        defaults.update(kwargs)

        return TimelineItem(**{"start_time": start, "end_time": end, **defaults})

    def add(self, item: TimelineItem):
        self.timeline.append(item)

    def diff(self, other: Self) -> DiffResult:
        from juice_jsoc.diffing import make_opl_differ
        from ptr_editor.diffing import make_robust_matcher

        matcher = make_robust_matcher()

        mm = matcher.match(self.timeline, other.timeline)

        differ = make_opl_differ()
        return differ.diff(mm)

    def as_pandas(self, *, attrs: list[str] | None = None) -> pd.DataFrame:
        """Convert the timeline to a pandas DataFrame for analysis.

        Columns are ordered with id, start, end, designer appearing first (if present),
        followed by all other columns in their natural order.

        Args:
            attrs: Optional list of additional attribute names to extract from blocks.
                Common attributes: ["id", "designer"]

        Returns:
            pd.DataFrame with blocks as rows and attributes as columns.

        Example:
            >>> df = timeline.as_pandas(
            ...     attrs=[
            ...         "id",
            ...         "designer",
            ...         "target",
            ...     ]
            ... )
        """
        from ptr_editor.io.simplified_converter2 import tabletize_block

        # Default attributes to extract if not specified
        if attrs is None:
            attrs = ["id", "designer"]

        # Handle empty timeline
        if not self._segments_:
            return pd.DataFrame(columns=["start_time", "end_time", *attrs])

        data = []
        for item in self._segments_:
            series = tabletize_block(item, attrs=attrs)
            data.append(series)

        tab = pd.DataFrame(data).reset_index(drop=True)
        tab["start_time"] = pd.to_datetime(tab["start_time"], format="mixed", utc=False)
        tab["end_time"] = pd.to_datetime(tab["end_time"], format="mixed", utc=False)

        return tab

    def plot(self, *args, **kwargs):
        """Plot the timeline.

        Uses the built-in plotting from SegmentsCollectionMixin.
        """
        return super().plot(*args, x_start="start_time", x_end="end_time", **kwargs)

    def to_csv_file(
        self,
        path: str,
        *,
        include_header: bool = False,
        **kwargs,
    ) -> None:
        """Save timeline to a CSV file in the OPL CSV format.

        CSV columns: segment_definition, start, end, name, timeline

        Args:
            path: Path to the output CSV file
            include_header: If True, include column headers (default: False)
            **kwargs: Additional arguments passed to DataFrame.to_csv()

        Example:
            >>> opl = Timeline.from_json_file(
            ...     "opl.json"
            ... )
            >>> opl.to_csv_file(
            ...     "output.csv",
            ...     index=False,
            ... )
        """
        from .csv import timeline_to_csv_file

        timeline_to_csv_file(self, path, include_header=include_header, **kwargs)

    @classmethod
    def from_csv_file(
        cls,
        path: str,
        *,
        has_header: bool = False,
    ) -> "Timeline":
        """Load OPL from a CSV file in OPL CSV format.

        CSV columns: segment_definition, start, end, name, timeline

        The segment_definition column contains values like:
        INSTRUMENT_[PRIME|RIDER]_OBSERVATION which will be decomposed
        to extract instrument, type, and observation_type.

        Args:
            path: Path to the CSV file
            has_header: If True, CSV has a header row (default: False)

        Returns:
            Timeline object with parsed items

        Example:
            >>> opl = Timeline.from_csv_file(
            ...     "opl.csv"
            ... )
            >>> # Without header
            >>> opl = Timeline.from_csv_file(
            ...     "opl.csv",
            ...     has_header=False,
            ... )
        """
        from .csv import timeline_from_csv_file

        return timeline_from_csv_file(path, has_header=has_header)

    @classmethod
    def from_json_file(
        cls,
        path: os.PathLike,
        *,
        validate: bool = True,
        strict: bool = False,
        warn_extra_fields: bool = False,
    ) -> "Timeline":
        """Load OPL from a JSON file.

        Args:
            path: Path to the JSON file
            validate: If True, validate against schema before parsing (default: True)
            strict: If True, treat extra fields as errors (default: False)
            warn_extra_fields: If True, warn about extra fields (default: False)

        Returns:
            Parsed OPL schema object

        Raises:
            ValueError: If validation fails

        Example:
            >>> opl = Timeline.from_json_file(
            ...     "opl.json"
            ... )
            >>> # Skip validation
            >>> opl = Timeline.from_json_file(
            ...     "opl.json",
            ...     validate=False,
            ... )
            >>> # Warn about extra fields
            >>> opl = Timeline.from_json_file(
            ...     "opl.json",
            ...     warn_extra_fields=True,
            ... )
            >>> # Strict mode (extra fields = error)
            >>> opl = Timeline.from_json_file(
            ...     "opl.json",
            ...     strict=True,
            ... )
        """
        import json
        from pathlib import Path

        with Path(path).open("r", encoding="utf-8") as f:
            data = json.load(f, strict=False)

        # Validate if requested
        if validate:
            is_valid, messages = validate_opl_json(
                data,
                strict=strict,
                warn_extra_fields=warn_extra_fields,
            )
            if not is_valid:
                error_msg = f"OPL validation failed for {path}:\n" + "\n".join(messages)
                log.error(error_msg)
                raise ValueError(error_msg)
            if messages:
                # Log warnings
                for msg in messages:
                    log.warning(msg)
            log.info(f"OPL validation successful for {path}")

        return converter.structure(data, cls)

    def to_json_file(self, path: str, indent: int = 2) -> None:
        """Save OPL to a JSON file.

        Args:
            path: Path to the output JSON file
            indent: JSON indentation level (default: 2)

        Example:
            >>> opl.to_json_file(
            ...     "output.json"
            ... )
        """
        import json
        from pathlib import Path

        data = converter.unstructure(self)

        # For JSON, only remove None values but keep empty dicts/lists
        data = remove_none_values(data)
        with Path(path).open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=indent, ensure_ascii=False)

    @classmethod
    def from_json_string(
        cls,
        json_str: str,
        *,
        validate: bool = True,
        strict: bool = False,
        warn_extra_fields: bool = False,
    ) -> "Timeline":
        """Load OPL from a JSON string.

        Args:
            json_str: JSON string to parse
            validate: If True, validate against schema before parsing (default: True)
            strict: If True, treat extra fields as errors (default: False)
            warn_extra_fields: If True, warn about extra fields (default: False)

        Returns:
            Parsed OPL schema object

        Raises:
            ValueError: If validation fails

        Example:
            >>> opl = Timeline.from_json_string(
            ...     json_data
            ... )
            >>> # Skip validation
            >>> opl = Timeline.from_json_string(
            ...     json_data,
            ...     validate=False,
            ... )
            >>> # Warn about extra fields
            >>> opl = Timeline.from_json_string(
            ...     json_data,
            ...     warn_extra_fields=True,
            ... )
            >>> # Strict mode (extra fields = error)
            >>> opl = Timeline.from_json_string(
            ...     json_data,
            ...     strict=True,
            ... )
        """
        import json

        data = json.loads(json_str, strict=False)

        # Validate if requested
        if validate:
            is_valid, messages = validate_opl_json(
                data,
                strict=strict,
                warn_extra_fields=warn_extra_fields,
            )
            if not is_valid:
                error_msg = "OPL validation failed:\n" + "\n".join(messages)
                log.error(error_msg)
                raise ValueError(error_msg)
            if messages:
                # Log warnings
                for msg in messages:
                    log.warning(msg)
            log.info("OPL validation successful")

        return converter.structure(data, cls)


# Configure cattrs converter for union types
def _structure_time(val: str | dict, _type) -> pd.Timedelta | RelativeTime:
    """Structure function for time fields that can be string or RelativeTime."""
    if isinstance(val, str):
        return converter.structure(val, pd.Timedelta)
    return converter.structure(val, RelativeTime)


def _unstructure_time(val: str | RelativeTime) -> str | dict:
    """Unstructure function for time fields."""
    if isinstance(val, str):
        return val
    return converter.unstructure(val)


def _structure_str_or_list(val: str | list | None, _type) -> str | list[str] | None:
    """Structure function for fields that can be string, list of strings, or None."""
    if val is None or isinstance(val, str):
        return val
    if isinstance(val, list):
        return [str(item) for item in val]
    return str(val)


def _structure_str_or_list_required(val: str | list, _type) -> str | list[str]:
    """Structure for fields that can be string or list of strings."""
    if isinstance(val, str):
        return val
    if isinstance(val, list):
        return [str(item) for item in val]
    return str(val)


def _unstructure_str_or_list(val: str | list[str] | None) -> str | list[str] | None:
    """Unstructure function for string or list fields."""
    return val


def _unstructure_str_or_list_required(val: str | list[str]) -> str | list[str]:
    """Unstructure function for string or list fields (not None)."""
    return val


def _structure_timestamp_or_relative(
    val: str | dict,
    _type,
) -> pd.Timestamp | RelativeTime:
    """Structure function for time fields that can be pd.Timestamp or RelativeTime."""
    if isinstance(val, str):
        # Convert string to pd.Timestamp
        return converter.structure(val, pd.Timestamp)

    if isinstance(val, dict):
        # Convert dict to RelativeTime
        return converter.structure(val, RelativeTime)
    return val


def _unstructure_timestamp_or_relative(
    val: pd.Timestamp | RelativeTime,
) -> str | dict:
    """Unstructure function for pd.Timestamp or RelativeTime fields."""
    if isinstance(val, pd.Timestamp):
        return converter.unstructure(val, pd.Timestamp)
    return converter.unstructure(val, RelativeTime)


# Register hooks for time union types
converter.register_structure_hook(pd.Timestamp | RelativeTime, _structure_time)
converter.register_unstructure_hook(pd.Timestamp | RelativeTime, _unstructure_time)

# Register hooks for pd.Timestamp | RelativeTime union types
converter.register_structure_hook(
    pd.Timestamp | RelativeTime,
    _structure_timestamp_or_relative,
)
converter.register_unstructure_hook(
    pd.Timestamp | RelativeTime,
    _unstructure_timestamp_or_relative,
)

# Register hooks for str | list[str] | None union types
converter.register_structure_hook(str | list[str] | None, _structure_str_or_list)
converter.register_unstructure_hook(str | list[str] | None, _unstructure_str_or_list)

# Register hooks for str | list[str] union types (without None)
converter.register_structure_hook(str | list[str], _structure_str_or_list_required)
converter.register_unstructure_hook(str | list[str], _unstructure_str_or_list_required)

# Register pandas hooks with UTC enforcement for OPL compliance
register_pandas_times_hooks(converter, enforce_utc=True)
# register_numpy_hooks(converter)


# Helper functions for serialization/deserialization
def structure_opl(data: dict) -> Timeline:
    """Deserialize a dictionary to an OPL schema object."""
    return converter.structure(data, Timeline)


def unstructure_opl(
    obj: Timeline,
) -> dict:
    """Serialize an OPL schema object to a dictionary."""
    return converter.unstructure(obj)
