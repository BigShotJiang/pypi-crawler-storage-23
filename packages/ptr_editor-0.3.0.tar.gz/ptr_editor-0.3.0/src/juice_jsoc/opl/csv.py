"""CSV reading and writing functionality for JUICE OPL files."""

import pandas as pd
from loguru import logger as log


INSTRUMENT_REPLACEMENTS = {
    "SOC": "GENERIC",
    "PEL": "PEPLO",
    "": "GENERIC",
}


def timeline_to_csv_file(
    timeline,
    path: str,
    *,
    include_header: bool = False,
    **kwargs,
) -> None:
    """Save timeline to a CSV file in the OPL CSV format.

    CSV columns: segment_definition, start, end, name, timeline

    Args:
        timeline: Timeline object to save
        path: Path to the output CSV file
        include_header: If True, include column headers (default: False)
        **kwargs: Additional arguments passed to DataFrame.to_csv()

    Example:
        >>> from juice_opl import (
        ...     Timeline,
        ... )
        >>> from juice_opl.csv import (
        ...     timeline_to_csv_file,
        ... )
        >>> opl = Timeline.from_json_file(
        ...     "opl.json"
        ... )
        >>> timeline_to_csv_file(
        ...     opl,
        ...     "output.csv",
        ...     index=False,
        ... )
    """
    rows = []
    for item in timeline.timeline:
        # Use the stored segment_definition if available (from CSV roundtrip)
        # \todo this is a stupid trick to pass the test! we really need to refactor the TimelineItem to have a proper segment_definition property that can be round-tripped instead of relying on this hacky approach
        if hasattr(item, "_csv_segment_definition") and item._csv_segment_definition:
            segment_definition = item._csv_segment_definition
        # Compose segment_definition from instrument and observation_type
        elif item.observation_type == "PRIME":
            segment_definition = f"{item.instrument}_PRIME_OBSERVATION"
        elif item.observation_type == "RIDER":
            segment_definition = f"{item.instrument}_RIDER_OBSERVATION"
        elif item.instrument:
            segment_definition = f"{item.instrument}_OBSERVATION"
        else:
            segment_definition = item.type

        # Format timestamps
        start = item.start.isoformat() if item.start else ""
        end = item.end.isoformat() if item.end else ""

        rows.append(
            {
                "segment_definition": segment_definition,
                "start": start,
                "end": end,
                "name": item.name,
                "timeline": item.instrument
                if (item.instrument and item.instrument != "")
                else pd.NA,
            },
        )

    df = pd.DataFrame(rows)
    df.to_csv(path, header=include_header, **kwargs)


def timeline_from_csv_file(
    path: str,
    has_header: bool = False,
):
    """Load OPL Timeline from a CSV file in OPL CSV format.

    CSV columns: segment_definition, start, end, name, timeline

    The segment_definition column contains values like:
    INSTRUMENT_[PRIME|RIDER]_OBSERVATION which will be decomposed
    to extract instrument, type, and observation_type.

    Args:
        path: Path to the CSV file
        has_header: If True, CSV has a header row (default: False)

    Returns:
        Timeline object with parsed items

    Example:
        >>> from juice_opl.csv import (
        ...     timeline_from_csv_file,
        ... )
        >>> opl = timeline_from_csv_file(
        ...     "opl.csv"
        ... )
        >>> # Without header
        >>> opl = timeline_from_csv_file(
        ...     "opl.csv",
        ...     has_header=False,
        ... )
    """
    from .elements import Timeline, TimelineItem

    # Read CSV with proper header handling
    if has_header:
        df = pd.read_csv(path)
        # Normalize column names to standard format
        column_mapping = {
            "Type": "segment_definition",
            "Start_Time": "start",
            "End_Time": "end",
            "Observation": "name",
            "Instrument": "timeline",
        }
        df.rename(columns=column_mapping, inplace=True)
    else:
        df = pd.read_csv(
            path,
            header=None,
            names=["segment_definition", "start", "end", "name", "timeline"],
        )

    # Drop rows that are completely NaN and empty rows
    df = df.dropna(how="all")
    df = df[df["segment_definition"].notna()]

    timeline_items = []
    replacement_counts = {key: 0 for key in INSTRUMENT_REPLACEMENTS.keys()}
    for _, row in df.iterrows():
        segment_def_col = row["segment_definition"]

        # Skip comment lines (starting with #)
        if str(segment_def_col).startswith("#"):
            continue

        # Parse timestamps - let pandas handle the parsing, will raise on invalid format
        start_time = pd.Timestamp(row["start"])
        end_time = pd.Timestamp(row["end"])

        # Parse timestamps - let pandas handle the parsing, will raise on invalid format
        start_time = pd.Timestamp(row["start"])
        end_time = pd.Timestamp(row["end"])

        # Decompose segment_definition to extract type information
        segment_definition = row["segment_definition"]

        # Determine observation type from segment_definition
        # Format: <INSTRUMENT>(_PRIME/_RIDER)_OBSERVATION
        if "_PRIME_OBSERVATION" in str(segment_definition):
            observation_type = "PRIME"
        elif "_RIDER_OBSERVATION" in str(segment_definition):
            observation_type = "RIDER"
        else:
            observation_type = None

        # Get instrument from the timeline column (5th column)
        instrument = row["timeline"] if pd.notna(row["timeline"]) else ""

        for key, replacement in INSTRUMENT_REPLACEMENTS.items():
            if str(instrument).upper().strip() == key:
                instrument = replacement
                replacement_counts[key] += 1

        # Use name column
        name = row["name"]

        item_data = {
            "type": "OBSERVATION",
            "name": str(name),
            "start_time": start_time,
            "end_time": end_time,
            "instrument": str(instrument),
            "unique_id": str(name),
            "csv_segment_definition": str(segment_definition),  # Store for roundtrip
        }

        # Add observation_type if it's PRIME or RIDER
        if observation_type:
            item_data["observation_type"] = observation_type

        timeline_items.append(TimelineItem(**item_data))

    for key, count in replacement_counts.items():
        if count > 0:
            log.warning(
                f"Transformed {count} {key} instrument(s) to {INSTRUMENT_REPLACEMENTS[key]} while loading CSV"
            )

    return Timeline(timeline=timeline_items)
