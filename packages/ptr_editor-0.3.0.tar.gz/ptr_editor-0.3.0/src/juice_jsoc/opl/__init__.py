"""juice_jsoc.opl – JUICE Science Operations Observation Plan (OPL) sub-package.

Imports from here are identical to the former stand-alone ``juice_opl`` package::

    from juice_jsoc.opl import Timeline, TimelineItem, Header

Or via the top-level namespace::

    from juice_jsoc import opl
    opl.Timeline.from_json_file("opl.json")
"""

from juice_jsoc.diffing import make_opl_differ

from .elements import (
    Configuration,
    Header,
    OplBaseItem,
    Profile,
    RelativeTime,
    Timeline,
    TimelineItem,
    ValidityRange,
    fetch_schema,
    get_schema_cache_path,
    structure_opl,
    unstructure_opl,
    validate_opl_json,
)

__all__ = [
    "Configuration",
    "Header",
    "OplBaseItem",
    "Profile",
    "RelativeTime",
    "Timeline",
    "TimelineItem",
    "ValidityRange",
    "fetch_schema",
    "get_schema_cache_path",
    "make_opl_differ",
    "structure_opl",
    "unstructure_opl",
    "validate_opl_json",
]
