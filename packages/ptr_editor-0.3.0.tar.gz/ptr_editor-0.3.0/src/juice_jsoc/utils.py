"""Shared runtime utilities for juice_jsoc (OPL and APL).

Contains helpers that are used identically in both sub-packages:
- :func:`remove_none_values`
- :func:`_enforce_naive_utc_timestamp`
- :func:`_parse_optional_timestamp`
"""

from __future__ import annotations

import pandas as pd


def remove_none_values(data):
    """Remove ``None`` values while preserving empty dicts and lists.

    Recursively processes dicts and lists.

    Args:
        data: The data structure to process (dict, list, or scalar).

    Returns:
        A copy of *data* with all ``None`` values removed.
    """
    if isinstance(data, dict):
        return {k: remove_none_values(v) for k, v in data.items() if v is not None}
    if isinstance(data, list):
        return [remove_none_values(item) for item in data if item is not None]
    return data


def _enforce_naive_utc_timestamp(item: pd.Timestamp) -> pd.Timestamp:
    """Ensure *item* is a timezone-naive UTC :class:`pandas.Timestamp`.

    If the timestamp carries timezone info it is converted to UTC and then
    made naive (tz_localize(None)).
    """
    if item.tz:
        item = item.tz_convert("UTC").tz_localize(None)
    return item


def _parse_optional_timestamp(
    value: pd.Timestamp | str | None,
) -> pd.Timestamp | None:
    """Parse an optional timestamp field, returning ``None`` if *value* is ``None``."""
    if value is None:
        return None
    if isinstance(value, pd.Timestamp):
        return _enforce_naive_utc_timestamp(value)
    return _enforce_naive_utc_timestamp(pd.Timestamp(value))
