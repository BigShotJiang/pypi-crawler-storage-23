"""JUICE Activity Plan (APL) elements and JSON serialization.

This module targets the APL JSON schema (jsoc-apl-schema.json): the
top-level document contains an *activities* list instead of a *timeline*
list, and the header/configuration layout is slightly different from OPL.
"""

import json
import os
from pathlib import Path
from typing import Self

import pandas as pd
from attrs import field
from cattrs.preconf.json import make_converter
from loguru import logger as log

from attrs_xml import element_define
from attrs_xml.formatting import parse_delta_time_string
from attrs_xml.xml.converter import register_pandas_times_hooks

# Shared juice_jsoc utilities
from juice_jsoc.base import JsocBaseItem
from juice_jsoc.schema import (
    fetch_schema as _fetch_schema_generic,
)
from juice_jsoc.schema import (
    get_schema_cache_path as _get_schema_cache_path_generic,
)
from juice_jsoc.schema import (
    validate_json,
)
from juice_jsoc.utils import (
    _parse_optional_timestamp,
)
from time_segments import SegmentsCollectionMixin, TimeSegmentMixin

# Create a converter instance for APL schemas
converter = make_converter()

# APL Schema URL
APL_SCHEMA_URL = "https://juicesoc.esac.esa.int/data/schemas/jsoc-apl-schema.json"
_LOCAL_APL_SCHEMA_PATH = Path(__file__).parent / "jsoc-apl-schema.json"


def get_schema_cache_path() -> Path:
    """Get the path to the APL schema cache file."""
    return _get_schema_cache_path_generic("juice_apl", "jsoc-apl-schema.json")


def fetch_schema(url: str = APL_SCHEMA_URL, *, force_refresh: bool = False) -> dict:  # noqa: ARG001
    """Load the bundled APL schema from disk (jsoc-apl-schema.json)."""
    return _fetch_schema_generic(_LOCAL_APL_SCHEMA_PATH, force_refresh=force_refresh)


def validate_apl_json(
    data: dict | str | Path,
    schema: dict | None = None,
    *,
    strict: bool = False,
    warn_extra_fields: bool = False,
) -> tuple[bool, list[str]]:
    """Validate APL JSON data against the schema.

    Args:
        data: APL data as dict, JSON string, or file path
        schema: Schema dict (if None, uses the bundled schema)
        strict: If True, modify schema to disallow additionalProperties
        warn_extra_fields: If True, validate twice and report extra fields as warnings

    Returns:
        Tuple of (is_valid, messages) where messages include errors and warnings

    Example:
        >>> is_valid, errors = validate_apl_json("apl.json")
        >>> if not is_valid:
        ...     for error in errors:
        ...         print(error)
    """
    if schema is None:
        schema = fetch_schema()
    return validate_json(data, schema, "APL", strict=strict, warn_extra_fields=warn_extra_fields)



# These must be present in the JSON output even when their value is null.
_REQUIRED_NULLABLE_ACTIVITY_FIELDS: frozenset[str] = frozenset(
    {"scheduling_rules", "tc_budget", "hk_budget"},
)


def _unstructure_activity_for_json(data: dict) -> dict:
    """Selectively strip None values from an unstructured Activity dict.

    Required-nullable fields (scheduling_rules, tc_budget, hk_budget) are
    kept even when None.  All other None values are removed so that fields
    whose schema does not accept null (e.g. ``target``) are simply absent.
    """
    return {
        k: v
        for k, v in data.items()
        if v is not None or k in _REQUIRED_NULLABLE_ACTIVITY_FIELDS
    }


class AplBaseItem(JsocBaseItem):
    """Base class for APL items (serialises to JSON preserving nullable fields)."""

    def to_json_string(self, indent: int = 2) -> str:
        """Convert APL element to a JSON string.

        Unlike OPL, None values are NOT globally stripped because the APL
        schema requires certain nullable fields (e.g. ``scheduling_rules``,
        ``tc_budget``, ``hk_budget``) to be explicitly present even when null.

        Args:
            indent: JSON indentation level (default: 2)

        Returns:
            JSON string representation

        Example:
            >>> json_str = activity.to_json_string()
        """
        data = converter.unstructure(self)
        return json.dumps(data, indent=indent, ensure_ascii=False)




# ---------------------------------------------------------------------------
# Header sub-elements
# ---------------------------------------------------------------------------


@element_define
class AplConfiguration(AplBaseItem):
    """Single entry in the header configuration array."""

    # APL JSON Schema used
    json_schema: str = field()


@element_define
class Header(AplBaseItem):
    """APL file header."""

    # Name of the JSON file
    filename: str = field()
    # Creation date of the file in UTC format YYYY-MM-DDThh:mm:ssZ
    creation_date: pd.Timestamp = field(
        converter=lambda x: pd.Timestamp(x) if not isinstance(x, pd.Timestamp) else x,
    )
    # Author of the file
    author: str = field()
    # Configuration entries (each records the schema used)
    configuration: list[AplConfiguration] | None = field(default=None)

    def renew_creation_date(self) -> Self:
        """Renew the creation date to the current time."""
        self.creation_date = pd.Timestamp.utcnow()
        return self

    def _repr_html_(self) -> str:
        """Generate HTML representation for Jupyter notebooks."""
        lbl = "font-weight:bold;color:#1976D2;font-size:13px;"
        val = "color:#333;font-size:13px;"
        mono = "font-family:'Courier New',monospace;word-break:break-all;"
        creation_date_str = str(self.creation_date) if self.creation_date else "N/A"

        schema_str = "N/A"
        if self.configuration:
            schema_str = ", ".join(c.json_schema for c in self.configuration)

        html = f"""\
<div style="border:2px solid #7B1FA2;border-radius:8px;\
padding:12px;background:#f3e5f5;\
font-family:'Segoe UI',Arial,sans-serif;max-width:900px;">
  <div style="margin-bottom:12px;">
    <div style="font-size:16px;font-weight:bold;color:#4A148C;">\
\U0001F4CB APL Header</div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;\
gap:4px 12px;margin-bottom:10px;\
padding:6px 0;border-top:1px solid #CE93D8;border-bottom:1px solid #CE93D8;">
    <div>
      <div style="{lbl}👤 Author</div>
      <div style="{val}">{self.author or 'N/A'}</div>
    </div>
    <div>
      <div style="{lbl}📅 Created</div>
      <div style="{val}{mono}">{creation_date_str}</div>
    </div>
    <div>
      <div style="{lbl}📄 Filename</div>
      <div style="{val}{mono}">{self.filename or 'N/A'}</div>
    </div>
    <div>
      <div style="{lbl}⚙️ Schema</div>
      <div style="{val}{mono}">{schema_str}</div>
    </div>
  </div>
</div>"""
        return html


# ---------------------------------------------------------------------------
# Uevt
# ---------------------------------------------------------------------------


@element_define
class Uevt(AplBaseItem):
    """User-defined event used by the Cruise Timeline Tool."""

    # Mnemonic for the user-defined event
    mnemonic: str = field()
    # Human-readable name of the event
    name: str = field()


# ---------------------------------------------------------------------------
# Activity (the main timeline element)
# ---------------------------------------------------------------------------


@element_define
class Activity(AplBaseItem, TimeSegmentMixin):
    """A single activity in the APL activities list."""

    # Unique identifier for the activity within the planning period
    id: str = field()
    # Unit / instrument responsible for the activity
    unit: str = field()
    # Intended POR / group of the activity
    stack: str = field()
    # Human-readable description
    description: str = field()
    # Rules for scheduling the activity (required, can be null)
    scheduling_rules: str | None = field(default=None)
    # Duration in format ddd.hh:mm:ss[.SSS] (required)
    duration: pd.Timedelta | None = field(
        default=None,
        converter=lambda x: parse_delta_time_string(x) if x is not None else None,
    )
    # TC telecommand budget (required, can be null)
    tc_budget: int | None = field(default=None)
    # Housekeeping data volume/rate (required, can be null)
    hk_budget: str | None = field(default=None)

    # --- optional scheduling fields ---
    # Event that schedules the activity start
    event: str | None = field(default=None)
    # Event counter
    counter: int | None = field(default=None)
    # Relative time to the event, format [[ddd.]hh:]mm:ss[.SSS]
    relative: pd.Timedelta | None = field(
        default=None,
        converter=lambda x: parse_delta_time_string(x) if x is not None else None,
    )

    # --- optional target and data budgets ---
    # Target of the activity (string or list of strings)
    target: str | list[str] | None = field(default=None)
    # Science data volume/rate in X-band
    data_resource_x: str | None = field(default=None)
    # Science data volume/rate in Ka-band
    data_resource_ka: str | None = field(default=None)

    # --- filled-in absolute times (computed or provided by SOC) ---
    # Start time in UTC format YYYY-MM-DDThh:mm:ssZ
    start: pd.Timestamp | None = field(
        default=None,
        converter=_parse_optional_timestamp,
    )
    # End time in UTC format YYYY-MM-DDThh:mm:ssZ
    end: pd.Timestamp | None = field(
        default=None,
        converter=_parse_optional_timestamp,
    )

    # --- SOC-provided scheduling ---
    # SOC event mnemonic for scheduling the activity start
    soc_event: str | None = field(default=None)
    # SOC event counter
    soc_counter: int | None = field(default=None)
    # SOC relative time, format [[ddd.]hh:]mm:ss[.SSS]
    soc_relative: pd.Timedelta | None = field(
        default=None,
        converter=lambda x: parse_delta_time_string(x) if x is not None else None,
    )

    def _repr_html_(self) -> str:
        """Generate HTML representation for Jupyter notebooks."""
        badge_style = (
            "display:inline-block;padding:2px 8px;border-radius:4px;"
            "color:#fff;font-size:11px;font-weight:bold;margin-right:4px;"
            "vertical-align:middle;"
        )
        unit_badge = (
            f"<span style='{badge_style}background:#00695C;'>"
            f"\U0001F52D {self.unit}</span>"
        )
        stack_badge = (
            f"<span style='{badge_style}background:#1565C0;'>"
            f"\U0001F4E6 {self.stack}</span>"
        )

        # Duration display
        duration_str = "N/A"
        if self.duration is not None:
            total_sec = int(self.duration.total_seconds())
            hours, remainder = divmod(total_sec, 3600)
            minutes, seconds = divmod(remainder, 60)
            duration_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"

        # Target display
        if isinstance(self.target, list):
            target_display = ", ".join(self.target)
        else:
            target_display = self.target or "N/A"

        lbl = "font-weight:bold;color:#7B1FA2;font-size:13px;"
        val = "color:#333;font-size:13px;"
        mono = "font-family:'Courier New',monospace;"

        html = f"""\
<div style="border:2px solid #7B1FA2;border-radius:8px;\
padding:12px;background:#f9f5fc;\
font-family:'Segoe UI',Arial,sans-serif;max-width:900px;">
  <div style="display:flex;align-items:center;\
justify-content:space-between;margin-bottom:6px;">
    <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap;">
      <span style="color:#444;font-size:11px;{mono}">{self.id}</span>
      {unit_badge}{stack_badge}
    </div>
  </div>
  <div style="margin-bottom:8px;">
    <div style="color:#555;font-size:12px;margin-top:2px;line-height:1.4;">\
{self.description}</div>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;\
gap:4px 12px;margin-bottom:10px;\
padding:6px 0;border-top:1px solid #ddd;border-bottom:1px solid #ddd;">
    <div>
      <div style="{lbl}▶ Start</div>
      <div style="{val}{mono}">{self.start or 'N/A'}</div>
    </div>
    <div>
      <div style="{lbl}■ End</div>
      <div style="{val}{mono}">{self.end or 'N/A'}</div>
    </div>
    <div>
      <div style="{lbl}⏱ Duration</div>
      <div style="{val}{mono}">{duration_str}</div>
    </div>
  </div>"""

        # Scheduling info
        sched_parts = []
        if self.event:
            ctr = f" #{self.counter}" if self.counter is not None else ""
            rel = f" + {self.relative}" if self.relative is not None else ""
            sched_parts.append(f"<b>Event:</b> {self.event}{ctr}{rel}")
        if self.soc_event:
            ctr = f" #{self.soc_counter}" if self.soc_counter is not None else ""
            rel = (
                f" + {self.soc_relative}"
                if self.soc_relative is not None
                else ""
            )
            sched_parts.append(f"<b>SOC event:</b> {self.soc_event}{ctr}{rel}")
        if sched_parts:
            html += (
                "<div style='margin-bottom:8px;'>"
                "<div style='font-weight:bold;color:#7B1FA2;"
                "font-size:13px;'>📅 Scheduling</div>"
                "<div style='color:#333;font-size:12px;"
                "margin-left:8px;line-height:1.6;'>"
                + "<br>".join(sched_parts)
                + "</div></div>"
            )

        if self.scheduling_rules:
            html += (
                "<div style='margin-bottom:8px;'>"
                "<div style='font-weight:bold;color:#7B1FA2;"
                "font-size:13px;'>📅 Scheduling Rules</div>"
                f"<div style='color:#555;font-size:13px;"
                f"margin-left:8px;line-height:1.4;'>{self.scheduling_rules}</div></div>"
            )

        # Budgets
        budget_parts = []
        if self.tc_budget is not None:
            budget_parts.append(f"<b>TC budget:</b> {self.tc_budget}")
        if self.hk_budget is not None:
            budget_parts.append(f"<b>HK budget:</b> {self.hk_budget}")
        if self.data_resource_x is not None:
            budget_parts.append(f"<b>Data X-band:</b> {self.data_resource_x}")
        if self.data_resource_ka is not None:
            budget_parts.append(f"<b>Data Ka-band:</b> {self.data_resource_ka}")
        if budget_parts:
            html += (
                "<div style='margin-bottom:8px;'>"
                "<div style='font-weight:bold;color:#7B1FA2;"
                "font-size:13px;'>📊 Budgets</div>"
                "<div style='color:#333;font-size:12px;"
                "margin-left:8px;line-height:1.6;'>"
                + "<br>".join(budget_parts)
                + "</div></div>"
            )

        if target_display != "N/A":
            html += (
                "<div style='margin-bottom:8px;'>"
                "<div style='font-weight:bold;color:#7B1FA2;"
                "font-size:13px;'>🎯 Target</div>"
                f"<div style='color:#333;font-size:13px;"
                f"margin-left:8px;'>{target_display}</div></div>"
            )

        html += "</div>"
        return html


# ---------------------------------------------------------------------------
# ActivityPlan (top-level document)
# ---------------------------------------------------------------------------


@element_define
class ActivityPlan(AplBaseItem, SegmentsCollectionMixin[Activity]):
    """JUICE Science Operations Activity Plan File.

    Top-level container matching the jsoc-apl-schema.json structure.
    """

    # Array of activities (required by schema)
    activities: list[Activity] = field(factory=list)
    # Optional file header
    header: Header | None = field(default=None, kw_only=True)
    # Optional user-defined event used by the Cruise Timeline Tool
    uevt: Uevt | None = field(default=None, kw_only=True)

    @property
    def _segments_(self) -> list[Activity]:
        """Return the list of activities for time segments processing."""
        return self.activities

    def add(self, activity: Activity) -> None:
        """Append an activity to the plan."""
        self.activities.append(activity)

    def to_json_string(self, indent: int = 2) -> str:
        """Convert the ActivityPlan to a JSON string.

        Args:
            indent: JSON indentation level (default: 2)

        Returns:
            JSON string representation

        Note:
            Top-level optional keys (``header``, ``uevt``) that are ``None``
            are omitted.  Inside each activity, fields that are *required* by
            the schema but may be null (``scheduling_rules``, ``tc_budget``,
            ``hk_budget``) are kept as ``null``; all other null fields are
            omitted.

        Example:
            >>> json_str = plan.to_json_string()
        """
        data = converter.unstructure(self)
        # Strip absent optional top-level keys
        data = {k: v for k, v in data.items() if v is not None}
        # Selectively preserve required-nullable fields inside activities
        if "activities" in data:
            data["activities"] = [
                _unstructure_activity_for_json(act) for act in data["activities"]
            ]
        return json.dumps(data, indent=indent, ensure_ascii=False)

    # def as_pandas(self, *, attrs: list[str] | None = None) -> pd.DataFrame:
    #     """Convert activities to a pandas DataFrame.

    #     Args:
    #         attrs: Optional list of attribute names to include (in addition to
    #                the default columns id, unit, stack, start, end, duration).

    #     Returns:
    #         pd.DataFrame with one row per activity.

    #     Example:
    #         >>> df = plan.as_pandas(attrs=["target", "tc_budget"])
    #     """
    #     if not self.activities:
    #         return pd.DataFrame(
    #             columns=["id", "unit", "stack", "start", "end", "duration"]
    #         )

    #     extra_attrs = attrs or []
    #     rows = []
    #     for act in self.activities:
    #         row: dict[str, Any] = {
    #             "id": act.id,
    #             "unit": act.unit,
    #             "stack": act.stack,
    #             "description": act.description,
    #             "start": act.start,
    #             "end": act.end,
    #             "duration": act.duration,
    #         }
    #         for attr in extra_attrs:
    #             row[attr] = getattr(act, attr, None)
    #         rows.append(row)

    #     df = pd.DataFrame(rows)
    #     for col in ("start", "end"):
    #         if col in df.columns:
    #             df[col] = pd.to_datetime(df[col], errors="coerce", utc=False)
    #     return df

    @classmethod
    def from_json_file(
        cls,
        path: os.PathLike,
        *,
        validate: bool = True,
        strict: bool = False,
        warn_extra_fields: bool = False,
    ) -> "ActivityPlan":
        """Load an APL from a JSON file.

        Args:
            path: Path to the JSON file
            validate: If True, validate against schema before parsing (default: True)
            strict: If True, treat extra fields as errors (default: False)
            warn_extra_fields: If True, warn about extra fields (default: False)

        Returns:
            Parsed ActivityPlan object

        Raises:
            ValueError: If validation fails

        Example:
            >>> plan = ActivityPlan.from_json_file("apl.json")
            >>> plan = ActivityPlan.from_json_file("apl.json", validate=False)
            >>> plan = ActivityPlan.from_json_file("apl.json", warn_extra_fields=True)
        """
        with Path(path).open("r", encoding="utf-8") as f:
            data = json.load(f, strict=False)

        if validate:
            is_valid, messages = validate_apl_json(
                data,
                strict=strict,
                warn_extra_fields=warn_extra_fields,
            )
            if not is_valid:
                error_msg = f"APL validation failed for {path}:\n" + "\n".join(messages)
                log.error(error_msg)
                raise ValueError(error_msg)
            if messages:
                for msg in messages:
                    log.warning(msg)
            log.info(f"APL validation successful for {path}")

        return converter.structure(data, cls)

    def to_json_file(self, path: str, indent: int = 2) -> None:
        """Save the ActivityPlan to a JSON file.

        Args:
            path: Path to the output JSON file
            indent: JSON indentation level (default: 2)

        Example:
            >>> plan.to_json_file("output.json")
        """
        data = converter.unstructure(self)
        # Strip absent optional top-level keys
        data = {k: v for k, v in data.items() if v is not None}
        # Selectively preserve required-nullable fields inside activities
        if "activities" in data:
            data["activities"] = [
                _unstructure_activity_for_json(act) for act in data["activities"]
            ]
        with Path(path).open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=indent, ensure_ascii=False)

    @classmethod
    def from_json_string(
        cls,
        json_str: str,
        *,
        validate: bool = True,
        strict: bool = False,
        warn_extra_fields: bool = False,
    ) -> "ActivityPlan":
        """Load an APL from a JSON string.

        Args:
            json_str: JSON string to parse
            validate: If True, validate against schema before parsing (default: True)
            strict: If True, treat extra fields as errors (default: False)
            warn_extra_fields: If True, warn about extra fields (default: False)

        Returns:
            Parsed ActivityPlan object

        Raises:
            ValueError: If validation fails

        Example:
            >>> plan = ActivityPlan.from_json_string(json_data)
            >>> plan = ActivityPlan.from_json_string(json_data, validate=False)
        """
        data = json.loads(json_str, strict=False)

        if validate:
            is_valid, messages = validate_apl_json(
                data,
                strict=strict,
                warn_extra_fields=warn_extra_fields,
            )
            if not is_valid:
                error_msg = "APL validation failed:\n" + "\n".join(messages)
                log.error(error_msg)
                raise ValueError(error_msg)
            if messages:
                for msg in messages:
                    log.warning(msg)
            log.info("APL validation successful")

        return converter.structure(data, cls)


# ---------------------------------------------------------------------------
# cattrs hooks
# ---------------------------------------------------------------------------


def _format_apl_duration(td: pd.Timedelta) -> str:
    """Format a Timedelta as ``ddd.hh:mm:ss[.SSS]`` for the APL duration field.

    The APL schema pattern for *duration* is:
    ``^\\d{1,3}\\.\\d{2}:\\d{2}:\\d{2}(\\.\\d{1,3})?$``

    Unlike the OPL / XML format (which uses a leading sign), APL duration
    always starts with a three-digit (or fewer) day count followed by a dot.
    """
    total_seconds = int(td.total_seconds())
    milliseconds = int(td.microseconds // 1000) if td.microseconds else 0
    days = total_seconds // 86400
    remainder = total_seconds % 86400
    hours = remainder // 3600
    remainder = remainder % 3600
    minutes = remainder // 60
    seconds = remainder % 60
    base = f"{days:03d}.{hours:02d}:{minutes:02d}:{seconds:02d}"
    if milliseconds:
        return f"{base}.{milliseconds:03d}"
    return base


def _structure_str_or_list(val: str | list | None, _type) -> str | list[str] | None:
    if val is None or isinstance(val, str):
        return val
    if isinstance(val, list):
        return [str(item) for item in val]
    return str(val)


def _unstructure_str_or_list(val: str | list[str] | None) -> str | list[str] | None:
    return val


# Register hooks for optional str | list union
converter.register_structure_hook(str | list[str] | None, _structure_str_or_list)
converter.register_unstructure_hook(str | list[str] | None, _unstructure_str_or_list)

# Register pandas timestamp/timedelta hooks with UTC enforcement
register_pandas_times_hooks(converter, enforce_utc=True)

# Register custom Activity unstructure hook that enforces the APL duration format
# (ddd.hh:mm:ss) instead of the default OPL/XML ±hh:mm:ss format.
_base_activity_unstructure = converter.gen_unstructure_attrs_fromdict(Activity)


def _unstructure_activity(act: "Activity") -> dict:
    """Unstructure an Activity applying APL-specific duration formatting."""
    data = _base_activity_unstructure(act)
    if act.duration is not None and isinstance(act.duration, pd.Timedelta):
        data["duration"] = _format_apl_duration(act.duration)
    return data


converter.register_unstructure_hook(Activity, _unstructure_activity)


# ---------------------------------------------------------------------------
# Convenience helpers
# ---------------------------------------------------------------------------


def structure_apl(data: dict) -> ActivityPlan:
    """Deserialize a dictionary to an ActivityPlan object."""
    return converter.structure(data, ActivityPlan)


def unstructure_apl(obj: ActivityPlan) -> dict:
    """Serialize an ActivityPlan object to a dictionary."""
    return converter.unstructure(obj)
