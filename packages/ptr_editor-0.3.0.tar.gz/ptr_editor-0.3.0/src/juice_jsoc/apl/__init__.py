"""juice_jsoc.apl – JUICE Science Operations Activity Plan (APL) sub-package.

Imports from here are identical to the former stand-alone ``juice_apl`` package::

    from juice_jsoc.apl import ActivityPlan, Activity, Header

Or via the top-level namespace::

    from juice_jsoc import apl
    apl.ActivityPlan.from_json_file("apl.json")
"""

from juice_jsoc.diffing import make_apl_differ

from .elements import (
    Activity,
    ActivityPlan,
    AplBaseItem,
    AplConfiguration,
    Header,
    Uevt,
    fetch_schema,
    get_schema_cache_path,
    structure_apl,
    unstructure_apl,
    validate_apl_json,
)

__all__ = [
    "Activity",
    "ActivityPlan",
    "AplBaseItem",
    "AplConfiguration",
    "Header",
    "Uevt",
    "fetch_schema",
    "get_schema_cache_path",
    "make_apl_differ",
    "structure_apl",
    "unstructure_apl",
    "validate_apl_json",
]
