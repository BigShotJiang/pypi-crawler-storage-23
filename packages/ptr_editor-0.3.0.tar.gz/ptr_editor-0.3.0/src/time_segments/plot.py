"""
Plotting functionalities for time segments.
"""

from typing import Protocol, runtime_checkable

import pandas as pd


@runtime_checkable
class HasPandas(Protocol):
    """Protocol for objects that can be converted to a pandas DataFrame.

    Any object implementing this protocol must have an as_pandas method
    that returns a pandas DataFrame representation of the object.

    Example:
        >>> class MyData:
        ...     def as_pandas(
        ...         self,
        ...     ) -> (
        ...         pd.DataFrame
        ...     ):
        ...         return pd.DataFrame(
        ...             {
        ...                 "col": [
        ...                     1,
        ...                     2,
        ...                     3,
        ...                 ]
        ...             }
        ...         )
        >>>
        >>> data: HasPandas = (
        ...     MyData()
        ... )  # Type checks!
    """

    def as_pandas(self, **kwargs) -> pd.DataFrame:
        """Convert the object to a pandas DataFrame.

        Returns:
            pd.DataFrame: DataFrame representation of the object
        """
        ...


def _wrap_for_hover(
    tab: pd.DataFrame,
    cols: list[str],
    line_width: int = 60,
) -> pd.DataFrame:
    """Wrap long string values in selected columns using <br> for hover display."""
    import textwrap

    tab = tab.copy()
    for col in cols:
        if col in tab.columns and tab[col].dtype == object:
            tab[col] = tab[col].apply(
                lambda v: "<br>".join(textwrap.wrap(str(v), line_width))
                if isinstance(v, str) and len(v) > line_width
                else v,
            )
    return tab


def _build_hover_texts(
    tab: pd.DataFrame,
    cols: list[str],
) -> list[str]:
    """Build preformatted hover HTML strings for each row."""
    existing_cols = [c for c in cols if c in tab.columns]
    texts = []
    for _, row in tab.iterrows():
        parts = []
        for col in existing_cols:
            val = row[col]
            if val is None or (isinstance(val, float) and pd.isna(val)):
                continue
            parts.append(f"<b>{col}</b>: {val}")
        texts.append("<br>".join(parts))
    return texts


def plot(
    obj: HasPandas,
    height=400,
    hover_cols=None,
    hover_line_width: int = 60,
    **kwargs,
):
    """Plot the observations in a timeline with plotly.

    Args:
        obj: Object that can be converted to pandas DataFrame
        height: Height of the plot in pixels
        hover_cols: List of column names to show in hover. If None, all
            non-basic columns are included.
        hover_line_width: Maximum characters per line in hover tooltips.
            Longer values are wrapped to new lines. Default: 60.
        **kwargs: Additional arguments passed to px.timeline()
    """
    import plotly.express as px

    tab = obj.as_pandas().copy()
    tab["timeline"] = "timeline"

    # Set default parameters
    if "timeline" in tab.columns and "y" not in kwargs:
        kwargs["y"] = "timeline"
    if "name" in tab.columns and "color" not in kwargs:
        kwargs["color"] = "name"

    # Determine columns to show in hover
    excluded_cols = {"start", "end", "timeline"}
    if hover_cols is None:
        hover_cols = [col for col in tab.columns if col not in excluded_cols]

    # Wrap long text values to keep hover readable
    tab = _wrap_for_hover(tab, hover_cols, line_width=hover_line_width)

    # Build hover text per row and store as a column
    tab["_hover_text"] = _build_hover_texts(tab, hover_cols)

    time_config = {"x_start": "start", "x_end": "end"}
    time_keys = {"x_start", "x_end"}
    time_config.update({k: kwargs.pop(k) for k in time_keys if k in kwargs})

    # Create the timeline plot without any hover_data / custom_data
    fig = px.timeline(tab, **time_config, **kwargs)

    # Assign preformatted hover text to each trace.
    # px.timeline splits data by the color column — match rows accordingly.
    color_col = kwargs.get("color", "name")
    for trace in fig.data:
        mask = tab[color_col] == trace.name
        trace.hovertext = tab.loc[mask, "_hover_text"].values
        trace.hovertemplate = "%{hovertext}<extra></extra>"

    # Compact hover styling
    fig.update_layout(
        height=height,
        hovermode="closest",
        hoverlabel=dict(
            namelength=-1,
            font=dict(size=11, family="Arial, sans-serif"),
            bgcolor="white",
            bordercolor="#333",
            align="left",
        ),
    )

    return fig
