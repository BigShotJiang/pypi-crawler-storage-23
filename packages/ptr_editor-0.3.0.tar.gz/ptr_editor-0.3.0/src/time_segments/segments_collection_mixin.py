"""Mixin for handling collections of time segments."""

from __future__ import annotations

import warnings
from collections import defaultdict
from collections.abc import Iterator, Sequence
from fnmatch import fnmatch
from typing import TYPE_CHECKING, Generic, Literal, TypeVar, overload

import pandas as pd
from loguru import logger as log

if TYPE_CHECKING:
    from collections.abc import Callable
    from typing import Self

    from time_segments.merging import MergeResult, SegmentMerger

from .segment_mixin import TimeSegmentMixin

SegT = TypeVar("SegT", bound="TimeSegmentMixin")


class SegmentsCollectionMixin(Generic[SegT]):
    """
    Mixin providing rich functionality for collections of time segments.

    Can be mixed into any class that manages a collection of segments,
    where each segment inherits from TimeSegmentMixin.

    Usage:
        class MySegment(TimeSegmentMixin):
            def __init__(self, start, end):
                self.start = start
                self.end = end

        class MySegmentCollection(SegmentsCollectionMixin[MySegment]):
            def __init__(self, segments):
                self._segments_ = segments

        collection = MySegmentCollection([seg1, seg2, seg3])
        collection.total_duration
        collection.gaps()
    """

    # Type hint for the collection attribute (to be provided by implementing class)
    # Segments must inherit from TimeSegmentMixin to have methods like
    # intersects, copy, etc.
    _segments_: list[SegT]

    @property
    def total_duration(self) -> pd.Timedelta:
        """Return the total duration of all timed segments in the collection."""
        total = pd.Timedelta(0)
        for seg in self._segments_:
            if seg.start is not None and seg.end is not None:
                total += seg.end - seg.start
        return total

    @property
    def start(self) -> pd.Timestamp | None:
        """Return the earliest start time across all segments."""
        starts = [seg.start for seg in self._segments_ if seg.start is not None]
        return min(starts) if starts else None

    @property
    def end(self) -> pd.Timestamp | None:
        """Return the latest end time across all segments."""
        ends = [seg.end for seg in self._segments_ if seg.end is not None]
        return max(ends) if ends else None

    @property
    def timespan(self) -> pd.Timedelta | None:
        """Return the total timespan from earliest start to latest end."""
        start = self.start
        end = self.end
        if start is None or end is None:
            return None
        return end - start

    @property
    def is_empty(self) -> bool:
        """Return True if the collection has no segments."""
        return len(self._segments_) == 0

    @property
    def encompassing_segment(self) -> SegT | None:
        """Return a single segment spanning the entire collection.

        Returns None if collection is empty.
        """
        if self.is_empty:
            return None

        # Create a copy of the first segment and modify its times
        return self._create_empty_segment(self.start, self.end)

    @property
    def is_time_resolved(self) -> bool:
        """Check if all segments in the timeline have defined start and end times."""
        return all(
            seg.start is not None and seg.end is not None for seg in self._segments_
        )

    @property
    def is_sorted(self) -> bool:
        """Check if segments are sorted by start time.

        Segments with None start times are considered to be in valid position.
        Returns True if all consecutive pairs with defined start times are in order.
        """
        return all(
            current.start is None
            or next_seg.start is None
            or current.start <= next_seg.start
            for current, next_seg in zip(
                self._segments_,
                self._segments_[1:],
                strict=False,
            )
        )

    def sort(
        self,
        *,
        by: Literal["start", "end", "duration"] = "start",
        reverse: bool = False,
    ) -> None:
        """Sort segments in place.

        Args:
            by: Sort key - "start" for start time, "end" for end time,
                "duration" for duration
            reverse: If True, sort in descending order
        """
        if by == "start":
            self._segments_.sort(
                key=lambda seg: (
                    seg.start if seg.start is not None else pd.Timestamp.min
                ),
                reverse=reverse,
            )
        elif by == "end":
            self._segments_.sort(
                key=lambda seg: seg.end if seg.end is not None else pd.Timestamp.max,
                reverse=reverse,
            )
        elif by == "duration":
            self._segments_.sort(
                key=lambda seg: (
                    seg.duration if seg.duration is not None else pd.Timedelta.min
                ),
                reverse=reverse,
            )
        else:
            msg = f"Unknown sort key '{by}'. Use 'start', 'end', or 'duration'."
            raise ValueError(msg)

    def filter(self, predicate: Callable[[SegT], bool]) -> Self:
        """Return a new collection with segments matching the predicate.

        Args:
            predicate: Function that returns True for segments to keep
        """
        filtered_segments = [seg for seg in self._segments_ if predicate(seg)]
        return self._create_new_collection(filtered_segments)

    def filter_by_time_range(
        self,
        start: (pd.Timestamp | str | SegT | Sequence[SegT] | None) = None,
        end: pd.Timestamp | str | None = None,
    ) -> Self:
        """Return segments that overlap with the given time range.

        Can be called with:
        - Two arguments: start and end timestamps
        - One argument: an object with start/end attributes (e.g., a segment)
        - One argument: a sequence of segments (uses min start, max end)

        Args:
            start: One of:
                - Start timestamp (inclusive)
                - An object with start/end attributes (e.g., a segment)
                - A sequence of segments (computes encompassing time range)
            end: End of time range (inclusive).
                 Ignored if start is a segment or sequence.

        Returns:
            A new collection containing segments that overlap with the time range.

        Example:
            >>> # Filter by explicit start/end
            >>> filtered = collection.filter_by_time_range(
            ...     start="2024-01-01",
            ...     end="2024-01-31",
            ... )
            >>>
            >>> # Filter by segment's time range
            >>> filtered = collection.filter_by_time_range(
            ...     reference_segment
            ... )
            >>>
            >>> # Filter by encompassing range of multiple segments
            >>> filtered = collection.filter_by_time_range(
            ...     other_collection
            ... )
        """
        # Handle sequence of segments - compute min/max time range
        if isinstance(start, Sequence) and not isinstance(start, str):
            segments = list(start)
            if not segments:
                # Empty sequence - return empty collection
                return self._create_new_collection([])
            starts = [s.start for s in segments if s.start is not None]
            ends = [s.end for s in segments if s.end is not None]
            start = min(starts) if starts else None
            end = max(ends) if ends else None
        # Handle single object with start/end attributes
        elif hasattr(start, "start") and hasattr(start, "end"):
            range_obj = start
            start = range_obj.start
            end = range_obj.end

        if start is not None:
            start = pd.Timestamp(start)
        if end is not None:
            end = pd.Timestamp(end)

        def overlaps_range(seg: SegT) -> bool:
            if seg.start is None or seg.end is None:
                return False
            if start is not None and seg.end < start:
                return False
            return not (end is not None and seg.start > end)

        return self.filter(overlaps_range)

    def _find_gaps(self) -> list[tuple[pd.Timestamp, pd.Timestamp]]:
        """Find gaps between segments.

        Returns a list of (start, end) tuples representing gaps.

        Works correctly even when segments overlap: creates an encompassing
        segment spanning the full collection range and subtracts all existing
        segments from it. The remaining pieces are the gaps.
        """
        if len(self._segments_) < 1:
            return []

        # Filter to valid (timed) segments only
        valid_segments = [
            seg
            for seg in self._segments_
            if seg.start is not None and seg.end is not None
        ]
        if not valid_segments:
            return []

        # Create an encompassing segment covering the full range
        encompassing = self._create_empty_segment(self.start, self.end)

        # Subtract all segments from the encompassing one
        from .ops import subtract

        remaining = subtract(encompassing, valid_segments)

        # Convert remaining segments to (start, end) tuples
        return [
            (seg.start, seg.end)
            for seg in remaining
            if seg.start is not None and seg.end is not None
        ]

    def find_overlaps(
        self, other: SegT | Sequence[SegT] | Self | None = None
    ) -> list[tuple[SegT, SegT]]:
        """Find all pairs of overlapping segments.

        Args:
            other: Optional. If provided, finds overlaps between segments in self
                   and segments in other. Can be a single segment, sequence of segments,
                   or another collection. If None, finds overlaps within self.

        Returns:
            List of tuples, each containing two overlapping segments.
            When other is provided: (seg_from_self, seg_from_other)
            When other is None: (seg1, seg2) where both are from self

        Example:
            >>> # Find overlaps within collection
            >>> internal_overlaps = collection.find_overlaps()
            >>>
            >>> # Find overlaps with another collection
            >>> overlaps = collection.find_overlaps(
            ...     other_collection
            ... )
            >>>
            >>> # Find overlaps with a single segment
            >>> overlaps = collection.find_overlaps(
            ...     target_segment
            ... )
        """
        if other is None:
            # Original behavior: find overlaps within self
            return [
                (seg1, seg2)
                for i, seg1 in enumerate(self._segments_)
                for seg2 in self._segments_[i + 1 :]
                if seg1.intersects(seg2)
            ]

        # Find overlaps between self and other
        # Normalize other to a list of segments
        if isinstance(other, TimeSegmentMixin):
            other_segments = [other]
        elif isinstance(other, SegmentsCollectionMixin):
            other_segments = other._segments_
        else:
            other_segments = list(other)

        return [
            (seg1, seg2)
            for seg1 in self._segments_
            for seg2 in other_segments
            if seg1.intersects(seg2)
        ]

    def has_overlaps(self) -> bool:
        """Check if any segments in the collection overlap.

        Returns True if at least one pair of segments overlaps, False otherwise.
        This is more efficient than find_overlaps() when you only need to know
        if overlaps exist.
        """
        for i, seg1 in enumerate(self._segments_):
            for seg2 in self._segments_[i + 1 :]:
                if seg1.intersects(seg2):
                    return True
        return False

    def merge_overlapping(self) -> Self:
        """Merge all overlapping segments into non-overlapping segments.

        Returns a new collection with merged segments.
        """
        if not self._segments_:
            return self._create_new_collection([])

        # Sort by start time
        sorted_segs = sorted(
            self._segments_,
            key=lambda seg: seg.start if seg.start is not None else pd.Timestamp.min,
        )

        merged = []
        current = sorted_segs[0].copy()

        for seg in sorted_segs[1:]:
            if seg.start is None or seg.end is None:
                continue
            if current.end is None:
                merged.append(current)
                current = seg.copy()
                continue

            # Check if segments overlap or touch
            if seg.start <= current.end:
                # Merge by extending current
                if seg.end is not None and seg.end > current.end:
                    current.end = seg.end
            else:
                # No overlap, save current and start new
                merged.append(current)
                current = seg.copy()

        merged.append(current)
        return self._create_new_collection(merged)

    def split_at_time(self, time: pd.Timestamp | str) -> tuple[Self, Self]:
        """Split collection into two at the given time.

        Returns:
            Tuple of (before, after) collections
        """
        time = pd.Timestamp(time)
        before = []
        after = []

        for seg in self._segments_:
            if seg.end is not None and seg.end <= time:
                before.append(seg)
            elif seg.start is not None and seg.start >= time:
                after.append(seg)
            else:
                # Segment spans the split time
                split_segs = seg.split(time)
                num_splits = 2
                if len(split_segs) == num_splits:
                    before.append(split_segs[0])
                    after.append(split_segs[1])
                elif seg.start is not None and seg.start < time:
                    before.append(split_segs[0])
                else:
                    after.append(split_segs[0])

        return (
            self._create_new_collection(before),
            self._create_new_collection(after),
        )

    def filter_by_time(self, time: pd.Timestamp | str) -> Self:
        """Return segments that contain the given time.

        Args:
            time: The timestamp to check

        Returns:
            A new collection containing only segments that contain the given time.

        Example:
            >>> # Find all segments active at a specific time
            >>> active = collection.filter_by_time(
            ...     "2024-01-01 12:00:00"
            ... )
        """
        time = pd.Timestamp(time)
        return self.filter(lambda seg: seg.contains(time))

    def filter_around(
        self,
        time: pd.Timestamp | str,
        delta: pd.Timedelta | str,
    ) -> Self:
        """Return segments that fall within a time interval around a central time.

        Creates an interval [time - delta, time + delta] and returns segments
        that overlap with this interval.

        Args:
            time: The central timestamp
            delta: The time delta to extend in both directions.
                   Can be a string like "1h", "30m", or pd.Timedelta.

        Returns:
            A new collection containing segments that overlap with the interval.

        Example:
            >>> # Find segments within 1 hour of a specific time
            >>> nearby = collection.filter_around(
            ...     "2024-01-01 12:00:00",
            ...     "1h",
            ... )
            >>> # Returns segments overlapping with 11:00:00 to 13:00:00
            >>>
            >>> # Find segments within 30 minutes
            >>> nearby = collection.filter_around(
            ...     "2024-01-01 12:00:00",
            ...     pd.Timedelta(
            ...         "30min"
            ...     ),
            ... )
            >>> # Returns segments overlapping with 11:30:00 to 12:30:00
        """
        time = pd.Timestamp(time)
        delta = pd.Timedelta(delta)

        start = time - delta
        end = time + delta

        return self.filter_by_time_range(start=start, end=end)

    def filter_intersecting(
        self,
        other: SegT | Sequence[SegT],
    ) -> Self:
        """Return segments that intersect with the given segment(s).

        Args:
            other: A single segment or sequence of segments to check for intersections.
                   Returns all segments from self that intersect with ANY of the
                   provided segments.

        Returns:
            A new collection containing segments that overlap with any of the
            provided segments.

        Example:
            >>> # Find segments overlapping a single segment
            >>> overlapping = collection.filter_intersecting(
            ...     segment
            ... )
            >>>
            >>> # Find segments overlapping any of the provided segments
            >>> overlapping = collection.filter_intersecting(
            ...     [
            ...         seg1,
            ...         seg2,
            ...         seg3,
            ...     ]
            ... )
            >>>
            >>> # Use with diff result deletions
            >>> (
            ...     additions,
            ...     deletions,
            ...     changes,
            ... ) = differ.diff(
            ...     match_result
            ... )
            >>> affected = collection.filter_intersecting(
            ...     deletions
            ... )
        """
        # Normalize to sequence
        others = [other] if isinstance(other, TimeSegmentMixin) else list(other)

        def intersects_any(seg: SegT) -> bool:
            return any(seg.intersects(o) for o in others)

        return self.filter(intersects_any)

    @property
    def ids(self) -> list[str | int]:
        """Return a list of IDs for all segments in the collection.

        Segments without an 'id' attribute will be skipped.

        Example:
            >>> # Get all segment IDs
            >>> ids = collection.ids
        """
        return [seg.id for seg in self._segments_]

    @property
    def duplicated_ids(self) -> list[str | int]:
        """Return a list of IDs that appear more than once in the collection.

        Returns:
            List of IDs that are duplicated. Empty list if no duplicates exist.

        Example:
            >>> # Find all duplicate IDs
            >>> dupes = collection.duplicated_ids
            >>> if dupes:
            ...     print(
            ...         f"Found {len(dupes)} duplicate IDs: {dupes}"
            ...     )
        """
        id_counts: defaultdict[str | int, int] = defaultdict(int)
        for seg in self._segments_:
            if hasattr(seg, "id"):
                id_counts[seg.id] += 1
        return [seg_id for seg_id, count in id_counts.items() if count > 1]

    def is_id_unique(self, segment_id: str | int) -> bool:
        """Check if an ID is unique in the collection.

        Args:
            segment_id: The ID to check

        Returns:
            True if the ID appears exactly once or not at all,
            False if it appears multiple times

        Example:
            >>> if not collection.is_id_unique(
            ...     "obs_001"
            ... ):
            ...     print(
            ...         "Warning: Duplicate ID found!"
            ...     )
        """
        count = 0
        for seg in self._segments_:
            if hasattr(seg, "id") and seg.id == segment_id:
                count += 1
                if count > 1:
                    return False
        return True

    def find_by_id(self, segment_id: str | int) -> SegT | None:
        """Find one segment by its ID.

        Args:
            segment_id: The ID to search for

        Returns:
            The segment with the matching ID, or None if not found

        Raises:
            ValueError: If multiple segments with the same ID are found

        Example:
            >>> segment = collection.find_by_id(
            ...     "obs_001"
            ... )
            >>> if segment:
            ...     print(
            ...         f"Found: {segment.start} - {segment.end}"
            ...     )
        """
        if not self.is_id_unique(segment_id):
            msg = f"Multiple segments found with id '{segment_id}'. IDs must be unique. Use filter_by_id instead."
            raise ValueError(msg)

        for seg in self._segments_:
            if hasattr(seg, "id") and seg.id == segment_id:
                return seg
        return None

    def find_nearest_segment(
        self,
        time: pd.Timestamp | str,
        mode: Literal["start", "end", "middle", "both"] = "both",
    ) -> SegT | None:
        """Find the segment nearest to a given time.

        Args:
            time: The reference time.
            mode: How to measure distance:
                - ``"start"``: nearest segment based on start time
                - ``"end"``: nearest segment based on end time
                - ``"middle"``: nearest segment based on middle time
                - ``"both"``: nearest segment considering both start and end times

        Returns:
            The nearest segment, or None if collection is empty.

        Example:
            >>> # Find segment with start time closest to now
            >>> seg = collection.find_nearest_segment(
            ...     "2024-06-15 12:00:00",
            ...     mode="start",
            ... )
            >>>
            >>> # Find segment whose start or end is closest
            >>> seg = collection.find_nearest_segment(
            ...     "2024-06-15 12:00:00",
            ...     mode="both",
            ... )
        """
        if self.is_empty:
            return None

        time = pd.Timestamp(time)

        if mode == "start":
            return min(
                (seg for seg in self._segments_ if seg.start is not None),
                key=lambda seg: abs(seg.start - time),
                default=None,
            )
        elif mode == "end":
            return min(
                (seg for seg in self._segments_ if seg.end is not None),
                key=lambda seg: abs(seg.end - time),
                default=None,
            )
        elif mode == "middle":
            return min(
                (
                    seg
                    for seg in self._segments_
                    if seg.start is not None and seg.end is not None
                ),
                key=lambda seg: abs(seg.start + (seg.end - seg.start) / 2 - time),
                default=None,
            )
        elif mode == "both":
            return min(
                self._segments_,
                key=lambda seg: min(
                    abs(seg.start - time) if seg.start is not None else float("inf"),
                    abs(seg.end - time) if seg.end is not None else float("inf"),
                ),
                default=None,
            )
        else:
            msg = f"Invalid mode '{mode}'. Use 'start', 'end', 'middle', or 'both'."
            raise ValueError(msg)

    def filter_by_id(
        self,
        pattern: str | list[str],
        mode: Literal["any", "all"] = "any",
    ) -> Self:
        """Filter segments by their ID using wildcards.

        Supports Unix shell-style wildcards:
        - `*` matches everything
        - `?` matches any single character
        - `[seq]` matches any character in seq
        - `[!seq]` matches any character not in seq

        Args:
            pattern: ID pattern(s) with optional wildcards. Can be a single string
                    or a list of patterns.
            mode: Match mode when multiple patterns are provided:
                - "any": Match segments that match ANY of the patterns (default)
                - "all": Match segments that match ALL of the patterns

        Returns:
            A new collection containing only the segments with matching IDs

        Example:
            >>> # Find all observation blocks
            >>> obs_blocks = collection.filter_by_id(
            ...     "obs_*"
            ... )
            >>>
            >>> # Find blocks matching any of the patterns
            >>> blocks = collection.filter_by_id(
            ...     [
            ...         "COSMIC_*",
            ...         "MAJ_*",
            ...     ],
            ...     mode="any",
            ... )
            >>>
            >>> # Find blocks matching all patterns (ID must contain all substrings)
            >>> blocks = collection.filter_by_id(
            ...     [
            ...         "*_SAT_*",
            ...         "*_SCAN_*",
            ...     ],
            ...     mode="all",
            ... )
            >>>
            >>> # Exact match (no wildcards)
            >>> block = collection.filter_by_id(
            ...     "obs_001"
            ... )
        """
        # Normalize pattern to list
        patterns = [pattern] if isinstance(pattern, str) else pattern

        if mode == "any":
            # Match if ANY pattern matches
            filtered = [
                seg
                for seg in self._segments_
                if hasattr(seg, "id")
                and any(fnmatch(str(seg.id), pat) for pat in patterns)
            ]
        elif mode == "all":
            # Match if ALL patterns match
            filtered = [
                seg
                for seg in self._segments_
                if hasattr(seg, "id")
                and all(fnmatch(str(seg.id), pat) for pat in patterns)
            ]
        else:
            msg = f"Invalid mode '{mode}'. Use 'any' or 'all'."
            raise ValueError(msg)

        return self._create_new_collection(filtered)

    @staticmethod
    def _resolve_attr(obj: object, attr: str) -> object:
        """Resolve a possibly dot-notated attribute path on *obj*.

        Args:
            obj: The root object.
            attr: Attribute name, optionally using dots for nesting
                  (e.g. ``"header.author"``).

        Returns:
            The resolved value.

        Raises:
            AttributeError: If any part of the path does not exist.
        """
        for part in attr.split("."):
            obj = getattr(obj, part)
        return obj

    def filter_by_attribute(
        self,
        attr: str,
        pattern: str | list[str],
        mode: Literal["any", "all"] = "any",
    ) -> Self:
        """Filter segments by an arbitrary attribute using wildcards.

        Works like :meth:`filter_by_id` but on any attribute.  Supports
        dot-notation for nested attributes (e.g. ``"header.author"``).

        Supports Unix shell-style wildcards:
        - ``*`` matches everything
        - ``?`` matches any single character
        - ``[seq]`` matches any character in *seq*
        - ``[!seq]`` matches any character not in *seq*

        Args:
            attr: Attribute name (dot-notation supported for nested access).
            pattern: Value pattern(s) with optional wildcards.
            mode: Match mode when multiple patterns are provided:
                - ``"any"``: match segments whose attribute matches
                  **any** pattern (default)
                - ``"all"``: match segments whose attribute matches
                  **all** patterns

        Returns:
            A new collection containing only the matching segments.

        Example:
            >>> # Filter by instrument
            >>> janus = collection.filter_by_attribute(
            ...     "instrument",
            ...     "JANUS",
            ... )
            >>>
            >>> # Filter by pointing (wildcard)
            >>> nadir = collection.filter_by_attribute(
            ...     "pointing",
            ...     "NAD*",
            ... )
            >>>
            >>> # Nested attribute
            >>> by_author = collection.filter_by_attribute(
            ...     "header.author",
            ...     "Alice*",
            ... )
            >>>
            >>> # Multiple patterns, any match
            >>> subset = collection.filter_by_attribute(
            ...     "instrument",
            ...     [
            ...         "JANUS",
            ...         "MAJIS",
            ...     ],
            ... )
        """
        patterns = [pattern] if isinstance(pattern, str) else pattern

        def _matches(seg: SegT) -> bool:
            try:
                value = str(self._resolve_attr(seg, attr))
            except AttributeError:
                return False
            if mode == "any":
                return any(fnmatch(value, p) for p in patterns)
            return all(fnmatch(value, p) for p in patterns)

        if mode not in ("any", "all"):
            msg = f"Invalid mode '{mode}'. Use 'any' or 'all'."
            raise ValueError(msg)

        return self.filter(_matches)

    def set_attribute(
        self,
        attr: str,
        value: object,
        *,
        inplace: bool = True,
    ) -> Self:
        """Set an attribute to a specific value on all segments.

        Supports dot-notation for nested attributes (e.g. ``"header.author"``).

        Args:
            attr: Attribute name (dot-notation supported for nested access).
            value: The value to set.
            inplace: If True, modify segments in place. If False (default),
                    return a new collection with copied segments.

        Returns:
            Self - either the modified collection (inplace=True) or a new
            collection with modified copies (inplace=False).

        Example:
            >>> # Set name on all segments
            >>> collection.set_attribute(
            ...     "name",
            ...     "updated_name",
            ... )
            >>>
            >>> # Set a nested attribute
            >>> collection.set_attribute(
            ...     "header.author",
            ...     "Alice",
            ... )
            >>>
            >>> # Modify in place
            >>> collection.set_attribute(
            ...     "pointing",
            ...     "NADIR",
            ...     inplace=True,
            ... )
        """
        if not inplace:
            # Create new collection with copied segments
            new_segments = []
            for seg in self._segments_:
                seg_copy = seg.copy() if hasattr(seg, "copy") else seg
                self._set_attr_recursive(seg_copy, attr, value)
                new_segments.append(seg_copy)
            return self._create_new_collection(new_segments)
        else:
            # Modify segments in place
            for seg in self._segments_:
                self._set_attr_recursive(seg, attr, value)
            return self

    @staticmethod
    def _set_attr_recursive(obj: object, attr: str, value: object) -> None:
        """Set a possibly dot-notated attribute on *obj* to *value*.

        Args:
            obj: The root object.
            attr: Attribute name, optionally using dots for nesting
                  (e.g. ``"header.author"``).
            value: The value to set.

        Raises:
            AttributeError: If any part of the path does not exist.
        """
        parts = attr.split(".")
        # Navigate to the parent object
        current = obj
        for part in parts[:-1]:
            current = getattr(current, part)
        # Set the final attribute
        setattr(current, parts[-1], value)

    def remove_by_id(self, ids: str | Sequence[str], *, inplace: bool = False) -> Self:
        """Remove segments by their IDs using wildcards or exact matches.

        Supports Unix shell-style wildcards:
        - `*` matches everything
        - `?` matches any single character
        - `[seq]` matches any character in seq
        - `[!seq]` matches any character not in seq

        Args:
            ids: Single ID or sequence of IDs to remove. Supports wildcards.
            inplace: If True, modify the collection in place. If False (default),
                    return a new collection with segments removed.

        Returns:
            Self - either the modified collection (inplace=True) or a new collection (inplace=False)

        Example:
            >>> # Remove a single observation (returns new collection)
            >>> filtered = collection.remove_by_id(
            ...     "obs_001"
            ... )
            >>>
            >>> # Remove multiple observations (exact match)
            >>> filtered = collection.remove_by_id(
            ...     [
            ...         "obs_001",
            ...         "obs_002",
            ...     ]
            ... )
            >>>
            >>> # Remove using wildcards
            >>> filtered = collection.remove_by_id(
            ...     "obs_*"
            ... )
            >>>
            >>> # Remove in place
            >>> collection.remove_by_id(
            ...     "obs_*",
            ...     inplace=True,
            ... )
        """
        # Normalize to sequence
        patterns = [ids] if isinstance(ids, str) else list(ids)

        # Collect segments to remove
        removed_segments = []
        filtered = []

        for seg in self._segments_:
            if hasattr(seg, "id") and any(
                fnmatch(str(seg.id), pat) for pat in patterns
            ):
                removed_segments.append(seg)
            else:
                filtered.append(seg)

        # Log removed IDs
        if removed_segments:
            removed_ids = [str(seg.id) for seg in removed_segments]
            log.info(f"Removed {len(removed_ids)} segment(s): {removed_ids}")

        if inplace:
            self._segments_[:] = filtered
            return self
        else:
            return self._create_new_collection(filtered)

    def filter_before(
        self, timestamp: pd.Timestamp | str, *, inplace: bool = False
    ) -> Self:
        """Filter to keep only segments that end before the given timestamp.

        Args:
            timestamp: The cutoff timestamp. Can be a pd.Timestamp or string parseable by pandas.
            inplace: If True, modify the collection in place. If False (default),
                    return a new collection.

        Returns:
            Self - either the modified collection (inplace=True) or a new collection (inplace=False)

        Example:
            >>> # Keep segments before a specific date
            >>> early = collection.filter_before(
            ...     "2025-01-01"
            ... )
            >>>
            >>> # Keep segments before a timestamp
            >>> early = collection.filter_before(
            ...     pd.Timestamp(
            ...         "2025-06-15 12:00:00"
            ...     )
            ... )
            >>>
            >>> # Filter in place
            >>> collection.filter_before(
            ...     "2025-01-01",
            ...     inplace=True,
            ... )
        """
        if isinstance(timestamp, str):
            timestamp = pd.Timestamp(timestamp)

        filtered = [
            seg
            for seg in self._segments_
            if seg.end is not None and seg.end <= timestamp
        ]

        log.info(
            f"Filtered to {len(filtered)}/{len(self._segments_)} segment(s) "
            f"ending before {timestamp}"
        )

        if inplace:
            self._segments_[:] = filtered
            return self
        return self._create_new_collection(filtered)

    def filter_after(
        self, timestamp: pd.Timestamp | str, *, inplace: bool = False
    ) -> Self:
        """Filter to keep only segments that start after the given timestamp.

        Args:
            timestamp: The cutoff timestamp. Can be a pd.Timestamp or string parseable by pandas.
            inplace: If True, modify the collection in place. If False (default),
                    return a new collection.

        Returns:
            Self - either the modified collection (inplace=True) or a new collection (inplace=False)

        Example:
            >>> # Keep segments after a specific date
            >>> recent = collection.filter_after(
            ...     "2025-06-01"
            ... )
            >>>
            >>> # Keep segments after a timestamp
            >>> recent = collection.filter_after(
            ...     pd.Timestamp(
            ...         "2025-06-15 12:00:00"
            ...     )
            ... )
            >>>
            >>> # Filter in place
            >>> collection.filter_after(
            ...     "2025-06-01",
            ...     inplace=True,
            ... )
        """
        if isinstance(timestamp, str):
            timestamp = pd.Timestamp(timestamp)

        filtered = [
            seg
            for seg in self._segments_
            if seg.start is not None and seg.start >= timestamp
        ]

        log.info(
            f"Filtered to {len(filtered)}/{len(self._segments_)} segment(s) "
            f"starting after {timestamp}"
        )

        if inplace:
            self._segments_[:] = filtered
            return self
        return self._create_new_collection(filtered)

    def find_overlapping_groups(self) -> list[list[SegT]]:
        """Find groups of mutually overlapping segments.

        Returns:
            List of lists, where each inner list contains segments that
            overlap with each other. Only groups with 2+ segments are included.

        Example:
            >>> # Find all groups of overlapping segments
            >>> overlap_groups = collection.find_overlapping_groups()
            >>> for (
            ...     group
            ... ) in overlap_groups:
            ...     print(
            ...         f"Found {len(group)} overlapping segments"
            ...     )
        """
        if not self._segments_:
            return []

        # Track which segment indices have been assigned to groups
        unassigned_indices = set(range(len(self._segments_)))
        groups = []

        while unassigned_indices:
            # Start a new group with one unassigned segment
            current_idx = next(iter(unassigned_indices))
            group_indices = {current_idx}
            unassigned_indices.remove(current_idx)

            # Keep expanding the group by finding overlapping segments
            changed = True
            while changed:
                changed = False
                for idx in list(unassigned_indices):
                    seg = self._segments_[idx]
                    # Check if this segment overlaps with any in the current group
                    if any(
                        seg.intersects(self._segments_[g_idx])
                        for g_idx in group_indices
                    ):
                        group_indices.add(idx)
                        unassigned_indices.remove(idx)
                        changed = True

            # Only add groups with overlaps (2+ segments)
            if len(group_indices) > 1:
                groups.append([self._segments_[idx] for idx in group_indices])

        return groups

    def drop_overlapping(
        self,
        other: SegT | Sequence[SegT] | Self | None = None,
        keep: Literal[
            "first",
            "last",
            "none",
            "longest",
            "shortest",
        ] = "first",
        *,
        inplace: bool = False,
    ) -> Self:
        """Remove overlapping segments from the collection.

        Args:
            other: Optional. If provided, removes segments from self that overlap
                   with segments in other. Can be a single segment, sequence of
                   segments, or another collection. If None, removes internal
                   overlaps within self.
            keep: Which segments to keep from each overlapping group:
                - "first": Keep the first occurrence (by position in collection)
                - "last": Keep the last occurrence (by position in collection)
                - "none": Remove all overlapping segments
                - "longest": Keep the segment with longest duration
                - "shortest": Keep the segment with shortest duration
            inplace: If True, modify collection in place. If False (default),
                    return a new collection.

        Returns:
            Self - either the modified collection (inplace=True)
            or a new collection (inplace=False)

        Example:
            >>> # Remove internal overlapping segments, keep first
            >>> no_overlaps = collection.drop_overlapping(
            ...     keep="first"
            ... )
            >>>
            >>> # Remove segments that overlap with other collection
            >>> filtered = collection.drop_overlapping(
            ...     other=other_collection,
            ...     keep="first",
            ... )
            >>>
            >>> # Keep the longest segment from each overlapping group
            >>> no_overlaps = collection.drop_overlapping(
            ...     keep="longest"
            ... )
            >>>
            >>> # Remove all overlapping segments
            >>> no_overlaps = collection.drop_overlapping(
            ...     keep="none"
            ... )
            >>>
            >>> # Remove overlaps in place
            >>> collection.drop_overlapping(
            ...     keep="first",
            ...     inplace=True,
            ... )
        """
        # Handle case when other is provided: remove segments from self that overlap
        if other is not None:
            # Normalize other to a list of segments
            if isinstance(other, TimeSegmentMixin):
                other_segments = [other]
            elif isinstance(other, SegmentsCollectionMixin):
                other_segments = other._segments_
            else:
                other_segments = list(other)

            # Find segments from self that overlap with other
            overlapping = [
                seg
                for seg in self._segments_
                if any(seg.intersects(o) for o in other_segments)
            ]

            if not overlapping:
                log.info("No overlapping segments found with other collection")
                if inplace:
                    return self
                return self.copy()

            # Build filtered list without the overlapping segments
            filtered = [seg for seg in self._segments_ if seg not in overlapping]

            removed_count = len(overlapping)
            kept_count = len(filtered)
            removed_ids = [
                getattr(seg, "id", f"#{self._segments_.index(seg)}")
                for seg in overlapping
            ]
            log.info(
                f"Dropped {removed_count} segment(s) overlapping with other "
                f"collection: {removed_ids}. {kept_count} segment(s) remaining."
            )

            if inplace:
                self._segments_[:] = filtered
                return self
            return self._create_new_collection(filtered)

        # Original behavior: handle internal overlaps
        overlap_groups = self.find_overlapping_groups()

        if not overlap_groups:
            log.info("No overlapping segments found")
            if inplace:
                return self
            return self.copy()

        # Collect segment indices to remove
        indices_to_remove = set()

        for group in overlap_groups:
            if keep == "first":
                # Keep the first in collection order
                first_idx = min(self._segments_.index(seg) for seg in group)
                indices_to_remove.update(
                    self._segments_.index(seg)
                    for seg in group
                    if self._segments_.index(seg) != first_idx
                )

            elif keep == "last":
                # Keep the last in collection order
                last_idx = max(self._segments_.index(seg) for seg in group)
                indices_to_remove.update(
                    self._segments_.index(seg)
                    for seg in group
                    if self._segments_.index(seg) != last_idx
                )

            elif keep == "longest":
                # Keep the segment with longest duration
                longest = max(
                    group,
                    key=lambda s: (
                        s.duration if s.duration is not None else pd.Timedelta(0)
                    ),
                )
                longest_idx = self._segments_.index(longest)
                indices_to_remove.update(
                    self._segments_.index(seg)
                    for seg in group
                    if self._segments_.index(seg) != longest_idx
                )

            elif keep == "shortest":
                # Keep the segment with shortest duration
                shortest = min(
                    group,
                    key=lambda s: (
                        s.duration if s.duration is not None else pd.Timedelta.max
                    ),
                )
                shortest_idx = self._segments_.index(shortest)
                indices_to_remove.update(
                    self._segments_.index(seg)
                    for seg in group
                    if self._segments_.index(seg) != shortest_idx
                )

            elif keep == "none":
                # Remove all overlapping segments
                indices_to_remove.update(self._segments_.index(seg) for seg in group)

            else:
                msg = (
                    f"Unknown keep mode '{keep}'. "
                    "Use 'first', 'last', 'longest', 'shortest', or 'none'."
                )
                raise ValueError(msg)

        # Build filtered list
        filtered = [
            seg
            for idx, seg in enumerate(self._segments_)
            if idx not in indices_to_remove
        ]

        # Log the operation
        removed_count = len(indices_to_remove)
        kept_count = len(filtered)
        removed_ids = [
            getattr(self._segments_[idx], "id", f"#{idx}") for idx in indices_to_remove
        ]
        log.info(
            f"Dropped {removed_count} overlapping segment(s) "
            f"(keep='{keep}'): {removed_ids}. {kept_count} segment(s) remaining."
        )

        if inplace:
            self._segments_[:] = filtered
            return self
        return self._create_new_collection(filtered)

    def insert(
        self,
        segment: SegT | list[SegT],
        *,
        strategy: str | SegmentMerger = "error",
    ) -> MergeResult:
        """Insert a segment or list of segments into the collection with conflict resolution.


        Args:
            segment: The segment(s) to insert. Can be a single segment or a list of segments.
            strategy: Strategy for handling overlapping segments:
                - "error": Raise ValueError if segment overlaps
                - "skip": Skip insertion if segment overlaps
                - "replace": Remove overlapping segments and insert new one
                - "force": Insert regardless of overlaps

        Returns:
            MergeResult containing information about the insertion operation

        Raises:
            ValueError: If strategy="error" and segment overlaps with existing

        Example:
            >>> # Insert a single segment
            >>> result = collection.insert(
            ...     new_segment
            ... )
            >>>
            >>> # Insert multiple segments
            >>> result = collection.insert(
            ...     [
            ...         seg1,
            ...         seg2,
            ...         seg3,
            ...     ]
            ... )
            >>>
            >>> # Use different strategy
            >>> result = collection.insert(
            ...     segment,
            ...     strategy="replace",
            ... )
        """
        from time_segments.merging import SegmentMerger

        if isinstance(strategy, SegmentMerger):
            merger = strategy

        elif isinstance(strategy, str):
            # Use the new merger system
            merger = SegmentMerger(strategy=strategy)

        else:
            msg = (
                f"Invalid strategy type '{type(strategy)}'. "
                "Must be a string or SegmentMerger instance."
            )
            raise ValueError(msg)

        # Handle both single segment and list of segments
        if isinstance(segment, list):
            return merger.insert_many(self._segments_, segment)

        return merger.insert(self._segments_, segment)

    def append(self, segment: SegT | list[SegT]) -> Self:
        """Append a segment or list of segments to the collection.

        Args:
            segment: Single segment or list of segments to append

        Returns:
            Self for method chaining
        """
        if isinstance(segment, list):
            self._segments_.extend(segment)
        else:
            self._segments_.append(segment)
        return self

    def extend(self, segments: Sequence[SegT]) -> Self:
        """Extend the collection by appending segments from an iterable.

        Mimics Python's list.extend() - adds all elements from the iterable
        to the collection.

        Args:
            segments: Sequence of segments to add (list, tuple, another collection, etc.)

        Returns:
            Self for method chaining

        Example:
            >>> collection.extend(
            ...     [
            ...         seg1,
            ...         seg2,
            ...         seg3,
            ...     ]
            ... )
            >>> collection.extend(
            ...     other_collection
            ... )
        """
        # Convert to list if it's a SegmentsCollectionMixin to access _segments_
        if isinstance(segments, SegmentsCollectionMixin):
            self._segments_.extend(segments._segments_)
        else:
            self._segments_.extend(segments)
        return self

    def __add__(
        self,
        other: SegmentsCollectionMixin | Sequence[SegT] | SegT,
    ) -> Self:
        """Create a new collection by concatenating segments from another source.

        The original collections remain untouched; incoming segments are copied to
        avoid sharing parent references between collections.
        """
        new_collection = self.copy()

        if isinstance(other, SegmentsCollectionMixin):
            incoming_segments: Sequence[SegT] = other._segments_
        elif isinstance(other, TimeSegmentMixin):
            incoming_segments = [other]
        elif isinstance(other, Sequence):
            incoming_segments = list(other)
        else:
            return NotImplemented

        for segment in incoming_segments:
            segment_to_add = segment.copy() if hasattr(segment, "copy") else segment
            new_collection.append(segment_to_add)

        return new_collection

    def __radd__(
        self,
        other: SegmentsCollectionMixin | Sequence[SegT] | SegT,
    ) -> Self:
        """Support reversed addition so sequences or collections can lead."""
        if isinstance(other, SegmentsCollectionMixin):
            new_collection = other.copy()
            leading_segments: Sequence[SegT] = []
            trailing_segments = self._segments_
        elif isinstance(other, TimeSegmentMixin):
            new_collection = self._create_new_collection([])
            leading_segments = [other]
            trailing_segments = self._segments_
        elif isinstance(other, Sequence):
            new_collection = self._create_new_collection([])
            leading_segments = list(other)
            trailing_segments = self._segments_
        else:
            return NotImplemented

        for segment in leading_segments:
            segment_to_add = segment.copy() if hasattr(segment, "copy") else segment
            new_collection.append(segment_to_add)

        for segment in trailing_segments:
            segment_to_add = segment.copy() if hasattr(segment, "copy") else segment
            new_collection.append(segment_to_add)

        return new_collection

    def __sub__(
        self,
        other: SegmentsCollectionMixin | Sequence[SegT] | SegT,
    ) -> Self:
        """Create a new collection by subtracting segments from another source.

        Subtracts all segments in `other` from all segments in `self`,
        producing the remaining pieces where `other` segments do not overlap.

        Args:
            other: Segments to subtract from this collection.
                   Can be another collection, sequence, or single segment.

        Returns:
            A new collection with segments representing `self - other`.

        Example:
            >>> # Subtract one collection from another
            >>> result = (
            ...     collection1
            ...     - collection2
            ... )
            >>>
            >>> # Subtract a single segment
            >>> result = (
            ...     collection
            ...     - segment
            ... )
        """
        from .ops import subtract

        # Normalize `other` to a list of segments
        if isinstance(other, SegmentsCollectionMixin):
            segments_to_subtract: Sequence[SegT] = other._segments_
        elif isinstance(other, TimeSegmentMixin):
            segments_to_subtract = [other]
        elif isinstance(other, Sequence):
            segments_to_subtract = list(other)
        else:
            return NotImplemented

        # Subtract segments and collect results
        result_segments: list[SegT] = []
        for seg in self._segments_:
            remaining = subtract(seg, segments_to_subtract)
            result_segments.extend(remaining)

        return self._create_new_collection(result_segments)

    def __iadd__(
        self,
        other: SegmentsCollectionMixin | Sequence[SegT] | SegT,
    ) -> Self:
        """Support in-place addition using += operator.

        Segments are appended to this collection. The append method handles
        any necessary copying or parent reference management.
        """
        if isinstance(other, SegmentsCollectionMixin):
            segments_to_add: Sequence[SegT] = other._segments_
        elif isinstance(other, TimeSegmentMixin):
            segments_to_add = [other]
        elif isinstance(other, Sequence):
            segments_to_add = list(other)
        else:
            return NotImplemented

        for segment in segments_to_add:
            self.append(segment)

        return self

    def drop(self, segment: SegT | list[SegT]) -> Self:
        """Remove a segment or list of segments from the collection.

        Args:
            segment: Single segment or list of segments to remove

        Returns:
            Self for method chaining
        """
        if isinstance(segment, list):
            # Create a copy to avoid issues when segment is self.segments
            to_remove = list(segment)
            for seg in to_remove:
                if seg in self._segments_:
                    self._segments_.remove(seg)
        elif segment in self._segments_:
            self._segments_.remove(segment)
        return self

    def replace(
        self,
        old_segment: SegT | Sequence[SegT] | Sequence[tuple[SegT, SegT]],
        new_segments: SegT | Sequence[SegT] | None = None,
        *,
        strategy: str | SegmentMerger = "error",
    ) -> MergeResult:
        """Replace one or more segments with new segment(s) using conflict resolution.

        Supports multiple calling conventions:

        1. Two arguments: old_segment(s) and new_segment(s)
           ```python
           collection.replace(
               old_block,
               new_block,
           )
           collection.replace(
               [old1, old2],
               [new1, new2],
           )
           ```

        2. One-to-many: replace a single segment with multiple segments
           ```python
           # Replace one segment with the results of a split
           a, b = block.split(
               block.middle,
               gap="2m",
           )
           collection.replace(
               block, [a, b]
           )
           ```

        3. Single argument: sequence of (old, new) pairs (unpackable)
           ```python
           # From DiffResult.changed_blocks or MatchResult.matched_blocks
           collection.replace(
               diff_result.changed_blocks
           )

           # Or explicit pairs
           collection.replace(
               [
                   (
                       old1,
                       new1,
                   ),
                   (
                       old2,
                       new2,
                   ),
               ]
           )
           ```

        Args:
            old_segment: Either:
                - The segment(s) to replace (when new_segments is provided)
                - A sequence of (old, new) tuples to replace (when new_segments is None)
            new_segments: A single segment or sequence of segments to replace with.
                         If None, old_segment must be a sequence of (old, new) pairs.
            strategy: Strategy for handling overlapping segments when inserting new ones:
                - "error": Raise error if new segments overlap with remaining segments (default)
                - "skip": Skip insertion if new segments overlap
                - "replace": Remove overlapping segments and insert new ones
                - "force": Insert regardless of overlaps
                - Or pass a SegmentMerger instance for custom behavior

        Returns:
            MergeResult containing information about the replacement operation

        Raises:
            ValueError: If old_segment is not in the collection

        Example:
            >>> # Replace a single segment with another
            >>> result = collection.replace(
            ...     old_segment,
            ...     new_segment,
            ... )
            >>>
            >>> # Replace one segment with multiple (e.g., after split)
            >>> a, b = block.split(
            ...     block.middle,
            ...     gap="2m",
            ... )
            >>> result = collection.replace(
            ...     block, [a, b]
            ... )
            >>>
            >>> # Replace using (old, new) pairs from diff result
            >>> (
            ...     additions,
            ...     deletions,
            ...     changes,
            ... ) = differ.diff(
            ...     match_result
            ... )
            >>> result = collection.replace(
            ...     changes
            ... )
            >>>
            >>> # Replace using explicit pairs
            >>> result = collection.replace(
            ...     [
            ...         (
            ...             old1,
            ...             new1,
            ...         ),
            ...         (
            ...             old2,
            ...             new2,
            ...         ),
            ...     ]
            ... )
        """
        from time_segments.merging import SegmentMerger

        if isinstance(strategy, SegmentMerger):
            merger = strategy
        elif isinstance(strategy, str):
            merger = SegmentMerger(strategy=strategy)
        else:
            msg = (
                f"Invalid strategy type '{type(strategy)}'. "
                "Must be a string or SegmentMerger instance."
            )
            raise ValueError(msg)

        # Handle single argument case: sequence of (old, new) pairs
        if new_segments is None:
            # old_segment should be a sequence of (old, new) tuples
            pairs = list(old_segment)
            if not pairs:
                # Empty sequence, nothing to do
                from time_segments.merging import MergeResult

                return MergeResult(
                    success=True, strategy_used=merger._strategy_instance.name()
                )

            # Build list of (old_segs, new_segs) for merger.replace
            replacements = []
            for pair in pairs:
                old, new = pair  # Unpack the pair
                old_list = [old] if isinstance(old, TimeSegmentMixin) else list(old)
                new_list = [new] if isinstance(new, TimeSegmentMixin) else list(new)
                replacements.append((old_list, new_list))

            # Pass the strategy to replace so it's used for insertions
            return merger.replace(
                self._segments_,
                replacements,
                strategy=merger._strategy_instance,
            )

        # Two argument case: old_segment(s) and new_segment(s)
        old_segs = (
            [old_segment]
            if isinstance(old_segment, TimeSegmentMixin)
            else list(old_segment)
        )
        new_segs = (
            [new_segments]
            if isinstance(new_segments, TimeSegmentMixin)
            else list(new_segments)
        )

        # Use merger's replace method, passing the strategy for insertions
        return merger.replace(
            self._segments_,
            [(old_segs, new_segs)],
            strategy=merger._strategy_instance,
        )

    def copy(self, *, deep: bool = True) -> Self:
        """Create a copy of the collection.

        Args:
            deep: If True, create deep copy of segments; otherwise shallow copy

        Returns:
            New collection instance
        """
        if deep:
            from copy import deepcopy

            copied_segments = [deepcopy(seg) for seg in self._segments_]
        else:
            copied_segments = self._segments_.copy()

        return self._create_new_collection(copied_segments)

    def union(self) -> Self:
        """Merge all overlapping or contiguous segments into non-overlapping ones.

        This is similar to merge_overlapping but also merges segments that touch
        (end of one equals start of another).

        Returns:
            New collection with merged segments
        """
        if self.is_empty:
            return self._create_new_collection([])

        # Sort by start time
        sorted_segs = sorted(
            self._segments_,
            key=lambda seg: seg.start if seg.start is not None else pd.Timestamp.min,
        )

        merged = []
        _current = sorted_segs[0]
        current = self._create_empty_segment(_current.start, _current.end)

        for seg in sorted_segs[1:]:
            if seg.start is None or seg.end is None:
                continue
            if current.end is None:
                merged.append(current)
                current = self._create_empty_segment(seg.start, seg.end)
                continue

            # Check if segments overlap or touch (<=  instead of <)
            if seg.start <= current.end:
                # Merge by extending current
                if seg.end is not None and seg.end > current.end:
                    current.end = seg.end
            else:
                # No overlap, save current and start new
                merged.append(current)
                current = seg.copy()

        merged.append(current)
        return self._create_new_collection(merged)

    def subtract(
        self,
        other: SegT | list[SegT] | Self,
        gap: pd.Timedelta | str | None = None,
    ) -> Self:
        """Subtract segments from this collection.

        Args:
            other: Segment(s) to subtract from this collection

        Returns:
            New collection with remaining segments after subtraction
        """
        # Normalize input to list
        if isinstance(other, TimeSegmentMixin):
            segments_to_subtract = [other]
        elif hasattr(other, "segments"):
            segments_to_subtract = other._segments_
        else:
            segments_to_subtract = other

        # Start with all segments
        remaining = [seg.copy() for seg in self._segments_]

        # Subtract each segment
        for sub_seg in segments_to_subtract:
            new_remaining = []
            for seg in remaining:
                # Use the segment's subtract method
                subtracted = seg.subtract(sub_seg, gap=gap)
                if not isinstance(subtracted, list):
                    subtracted = [subtracted]
                new_remaining.extend(subtracted)
            remaining = new_remaining

        return self._create_new_collection(remaining)

    def intersect(
        self,
        other: SegT | list[SegT] | Self,
    ) -> Self:
        """Get intersection of this collection with other segment(s).

        Args:
            other: Segment(s) to intersect with

        Returns:
            New collection with intersecting segments
        """
        # Normalize input to list
        if isinstance(other, TimeSegmentMixin):
            segments_to_intersect = [other]
        elif hasattr(other, "segments"):
            segments_to_intersect = other._segments_
        else:
            segments_to_intersect = other

        # Collect all intersections
        intersections = []
        for seg in self._segments_:
            for other_seg in segments_to_intersect:
                intersection = seg.intersect(other_seg)
                if intersection is not None:
                    intersections.append(intersection)

        return self._create_new_collection(intersections)

    def gaps(self) -> Self:
        """Return the gaps between segments as a new collection.

        Returns:
            New collection containing segments representing gaps

        Raises:
            ValueError: If collection is empty (no segments to derive type from)
        """
        gaps = self._find_gaps()

        # Create segments from gaps using factory method
        gap_segments = []
        for gap_start, gap_end in gaps:
            gap_seg = self._create_empty_segment(gap_start, gap_end)
            gap_segments.append(gap_seg)

        return self._create_new_collection(gap_segments)

    def empty_spaces(self) -> Self:
        """Return the gaps between segments as a new collection.

        .. deprecated::
            Use :meth:`gaps` instead. ``empty_spaces`` will be removed in a
            future release.
        """
        warnings.warn(
            "empty_spaces() is deprecated, use gaps() instead",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.gaps()

    def drop_small_segments(
        self,
        threshold: str | pd.Timedelta = "0s",
        *,
        inplace: bool = True,
    ) -> Self:
        """Remove segments with duration smaller than threshold.

        Args:
            threshold: Minimum duration (segments below this are removed)
            inplace: If True, modify this collection; otherwise return new one

        Returns:
            Self (if inplace=True) or new collection (if inplace=False)
        """
        threshold = pd.Timedelta(threshold)

        result = self if inplace else self.copy()

        # Filter out small segments
        to_drop = [
            seg
            for seg in result._segments_
            if seg.duration is not None and seg.duration <= threshold
        ]

        result.drop(to_drop)
        return result

    def drop_long_segments(
        self,
        threshold: str | pd.Timedelta = "0s",
        *,
        inplace: bool = True,
    ) -> Self:
        """Remove segments with duration longer than threshold.

        Args:
            threshold: Maximum duration (segments above this are removed)
            inplace: If True, modify this collection; otherwise return new one

        Returns:
            Self (if inplace=True) or new collection (if inplace=False)
        """
        threshold = pd.Timedelta(threshold)

        result = self if inplace else self.copy()

        # Filter out long segments
        to_drop = [
            seg
            for seg in result._segments_
            if seg.duration is not None and seg.duration >= threshold
        ]

        result.drop(to_drop)
        return result

    def as_pandas(
        self,
        *,
        include: list[str] | None = None,
        exclude: list[str] | None = None,
        nested_sep: str = ".",
        max_depth: int = 3,
        include_properties: bool = False,
        extra_attrs: list[str] | None = None,
        extra_fields: dict | None = None,
    ) -> pd.DataFrame:
        """Convert the collection to a pandas DataFrame.

        All public fields from each segment are extracted automatically as columns
        using :func:`attrs_xml.pandas.attrs_to_dataframe`.
        Nested attrs objects and dicts are flattened with ``nested_sep``
        (default ``"."``) separating key segments, e.g. a nested attrs field
        ``inner`` with sub-field ``x`` becomes column ``inner.x``.
        Dict fields are expanded similarly; lists are kept as single cell values.

        Args:
            include: If given, only columns whose name is in this list are kept.
                     Use the full flattened name for nested columns
                     (e.g. ``"inner.x"`` with default ``nested_sep``).
            exclude: Column names (full flattened names) to drop.
            nested_sep: Separator used when building column names from nested
                        structures.  Default is ``"."``.
            max_depth: Maximum recursion depth for nested attrs objects / dicts.
                       Default is ``3``.
            include_properties: If ``True``, all public ``@property`` members of
                                 each segment's class are automatically extracted
                                 and added as columns (unless already present as
                                 attrs fields).  Default is ``False``.
            extra_attrs: Optional list of attribute paths (dot notation supported)
                         to extract from each segment.
            extra_fields: Optional dict mapping column names to callables that
                          extract values from each segment.

        Returns:
            DataFrame with one row per segment and one column per field.

        Example:
            >>> df = (
            ...     plan.as_pandas()
            ... )
            >>> df = plan.as_pandas(
            ...     include=[
            ...         "id",
            ...         "unit",
            ...         "start",
            ...         "end",
            ...     ]
            ... )
            >>> df = plan.as_pandas(
            ...     exclude=[
            ...         "instrument_area"
            ...     ]
            ... )
            >>> df = plan.as_pandas(include_properties=True)
            >>> df = plan.as_pandas(
            ...     extra_attrs=["attitude.mode", "duration"]
            ... )
        """
        from attrs_xml.pandas import attrs_to_dataframe

        return attrs_to_dataframe(
            self._segments_,
            sep=nested_sep,
            max_depth=max_depth,
            include=include,
            exclude=exclude,
            include_properties=include_properties,
            extra_attrs=extra_attrs,
            extra_fields=extra_fields or {'duration': lambda x: x.duration},
        )

    def groupby(self, by: str) -> dict[any, Self]:
        """Group segments by an attribute value.

        The 'by' parameter is resolved as an attribute path on each segment,
        supporting nested attributes using dot notation (e.g., 'metadata.instrument_area.fov').

        Args:
            by: Attribute path to group by. Supports nested attributes with dot notation.
               Example: 'metadata.instrument_area.fov' resolves to
               segment.metadata.instrument_area.fov

        Returns:
            Dictionary mapping attribute values to collections of segments with that value.
            Segments where the attribute cannot be resolved are excluded.

        Example:
            >>> # Group by a simple attribute
            >>> by_name = collection.groupby(
            ...     "name"
            ... )
            >>> for (
            ...     name,
            ...     group_collection,
            ... ) in (
            ...     by_name.items()
            ... ):
            ...     print(
            ...         f"{name}: {len(group_collection)} segments"
            ...     )
            >>>
            >>> # Group by nested attribute
            >>> by_fov = collection.groupby(
            ...     "metadata.instrument_area.fov"
            ... )
            >>> for (
            ...     fov,
            ...     group_collection,
            ... ) in by_fov.items():
            ...     print(
            ...         f"FOV {fov}: {group_collection.total_duration}"
            ...     )
        """
        groups: dict[any, list[SegT]] = {}

        for segment in self._segments_:
            try:
                # Resolve nested attribute path
                value = segment
                for attr_name in by.split("."):
                    value = getattr(value, attr_name)

                # Add segment to appropriate group
                if value not in groups:
                    groups[value] = []
                groups[value].append(segment)
            except (AttributeError, TypeError):
                # Skip segments where the attribute path cannot be resolved
                continue

        # Convert each group to a collection instance
        return {key: self._create_new_collection(segs) for key, segs in groups.items()}

    def groupby_gap(self, max_gap: str | pd.Timedelta) -> dict[int, Self]:
        """Group segments by gaps between them.

        Segments are sorted by start time. When a gap larger than max_gap is found
        between consecutive segments, they are placed in different groups.
        This creates groups of segments that are "close together" in time.

        Args:
            max_gap: Maximum gap allowed within a group. If gap exceeds this,
                    a new group starts. Can be a string like '1h', '30min' or pd.Timedelta.

        Returns:
            Dictionary mapping group index (int) to collections of segments.
            Groups are ordered by their first segment's start time.

        Example:
            >>> # Group segments that are within 2 hours of each other
            >>> groups = collection.groupby_gap(
            ...     "2h"
            ... )
            >>> for (
            ...     group_id,
            ...     group_collection,
            ... ) in groups.items():
            ...     print(
            ...         f"Group {group_id}: {group_collection.total_duration}"
            ...     )
            ...     print(
            ...         f"  Spans from {group_collection.start} to {group_collection.end}"
            ...     )
            >>>
            >>> # Use timedelta
            >>> groups = collection.groupby_gap(
            ...     pd.Timedelta(
            ...         hours=1
            ...     )
            ... )
        """
        # Parse max_gap
        if isinstance(max_gap, str):
            max_gap = pd.Timedelta(max_gap)

        if self.is_empty:
            return {}

        # Sort segments by start time
        sorted_segs = sorted(
            self._segments_,
            key=lambda seg: seg.start if seg.start is not None else pd.Timestamp.min,
        )

        groups: dict[int, list[SegT]] = {}
        current_group_id = 0
        groups[current_group_id] = [sorted_segs[0]]

        # Iterate through remaining segments
        for i in range(1, len(sorted_segs)):
            current_seg = sorted_segs[i]
            prev_seg = sorted_segs[i - 1]

            # Check if we should start a new group
            gap = None
            if prev_seg.end is not None and current_seg.start is not None:
                gap = current_seg.start - prev_seg.end

            # If gap exceeds max_gap, start a new group
            if gap is not None and gap > max_gap:
                current_group_id += 1
                groups[current_group_id] = []

            groups[current_group_id].append(current_seg)

        # Convert each group to a collection instance
        return {key: self._create_new_collection(segs) for key, segs in groups.items()}

    def plot(self, *args, **kwargs):
        # simple wrapper to call the plot function from time_segments.plot with this collection as input
        from time_segments.plot import plot

        return plot(self, *args, **kwargs)

    def _create_new_collection(self, segments: list[SegT]) -> Self:
        """Create a new collection instance with the given segments.

        This method should be overridden by subclasses if they need
        special initialization logic.
        """
        # Create new instance of the same type
        return self.__class__(segments)

    def _create_empty_segment(self, start, end, **kwargs) -> SegT:
        """Create a minimal segment with only start/end times.

        Subclasses should override this to create appropriate empty segments.
        Default tries to construct using the type of the first segment.
        kwargs can be used to set additional attributes if needed.

        Args:
            start: Start timestamp for the segment
            end: End timestamp for the segment

        Returns:
            New segment instance with specified start/end times

        Raises:
            ValueError: If collection is empty and construction fails
        """
        if not self._segments_:
            msg = "Cannot create empty segment - collection is empty"
            raise ValueError(msg)

        seg_type = type(self._segments_[0])
        # Try to construct with just start and end
        seg = seg_type(start=start, end=end, **kwargs)

        return seg

    def __len__(self) -> int:
        """Return the number of segments in the collection."""
        return len(self._segments_)

    def __iter__(self) -> Iterator[SegT]:
        """Iterate over segments in the collection."""
        return iter(self._segments_)

    def _repr_html_(self) -> str:
        """Return a rich HTML representation for Jupyter notebooks."""

        # Check for overlaps using SegmentsCollectionMixin
        has_overlaps = self.has_overlaps()
        if has_overlaps:
            num_overlaps = len(self.find_overlaps())
            overlap_info = (
                f'<span style="color: #d32f2f;">⚠ {num_overlaps} overlap(s)</span>'
            )
        else:
            overlap_info = '<span style="color: #388e3c;">✓ No overlaps</span>'

        # Check time ordering using SegmentsCollectionMixin
        is_ordered = self.is_sorted
        order_info = (
            '<span style="color: #388e3c;">✓ Ordered</span>'
            if is_ordered
            else '<span style="color: #d32f2f;">⚠ Not ordered</span>'
        )

        # Check for unique IDs
        ids = [b.id for b in self if hasattr(b, "id") and b.id]
        has_unique_ids = len(ids) == len(set(ids))
        ids_info = (
            '<span style="color: #388e3c;">✓ Unique IDs</span>'
            if has_unique_ids
            else f'<span style="color: #d32f2f;">⚠ {len(ids) - len(set(ids))} duplicate ID(s)</span>'
        )

        # Build header with timeline statistics
        header = f"""
        <div style="margin-bottom: 15px; padding: 8px 0; border-bottom: 1px solid var(--jp-border-color2, #e0e0e0);">
            <div style="margin-top: 8px; font-size: 0.9em;">
                <span style="margin-right: 15px;">Total: {len(self)}</span>
            </div>
            <div style="margin-top: 4px; font-size: 0.9em;">
                <span style="margin-right: 15px;">Start: {self.start if self.start else "N/A"}</span>
                <span style="margin-right: 15px;">End: {self.end if self.end else "N/A"}</span>
            </div>
            <div style="margin-top: 4px; font-size: 0.9em;">
                <span style="margin-right: 15px;">{overlap_info}</span>
                <span style="margin-right: 15px;">{order_info}</span>
                <span>{ids_info}</span>
            </div>
        </div>
        """

        # Combine header with the DataFrame HTML
        return header + self.as_pandas()._repr_html_()

    @overload
    def __getitem__(self, index: slice) -> Self: ...

    @overload
    def __getitem__(self, index: int) -> SegT: ...

    @overload
    def __getitem__(self, index: str) -> SegT: ...

    def __getitem__(self, index) -> Self | SegT:
        # If it's a slice, return a new Timeline with block references
        if isinstance(index, slice):
            result = self._segments_[index]
            return self._create_new_collection(result)
        # if it is an int, return the block at that index
        if isinstance(index, int):
            return self._segments_[index]
        # If it's a string, treat it as an ID lookup
        if isinstance(index, str):
            result = self.find_by_id(index)
            if result is None:
                msg = f"No block found with id '{index}'"
                raise KeyError(msg)
            return result
        return self._segments_[index]
