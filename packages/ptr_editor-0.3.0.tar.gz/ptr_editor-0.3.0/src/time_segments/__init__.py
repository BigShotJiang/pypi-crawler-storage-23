"""Time segments package."""

# Legacy exports (existing code)
# from .segment import AnySegment, RangeSegment
# # from .segments_collection import SegmentsCollection

# # New mixin-based architecture exports
# from .interface import TimeSegmentInterface
# from .time_segment_accessor import TimeSegmentMixin
# from .segment_impl import Segment

# __all__ = [
#     # Legacy
#     "AnySegment",
#     "RangeSegment",
#     "SegmentsCollection",
#     # New architecture
#     "TimeSegmentInterface",
#     "TimeSegmentMixin",
#     "Segment",
# ]


from .segment_mixin import TimeSegmentMixin
from .segments_collection_mixin import SegmentsCollectionMixin


__all__ = [
    "TimeSegmentMixin",
    "SegmentsCollectionMixin",
]