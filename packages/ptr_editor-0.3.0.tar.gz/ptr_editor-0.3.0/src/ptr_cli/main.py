"""Main CLI application for ptr-editor."""

import typer
from typing import Annotated

from ptr_editor import set_logger_level

from .commands import validate, version

app = typer.Typer(
    name="ptr-editor",
    help="Command-line tools for PTR file editing and validation",
    add_completion=False,
    context_settings={"help_option_names": ["-h", "--help"]},
)


@app.callback()
def main(
    verbose: Annotated[
        int,
        typer.Option(
            "--verbose",
            "-v",
            count=True,
            help="Increase verbosity (-v for INFO, -vv for DEBUG, -vvv for TRACE)",
        ),
    ] = 0,
) -> None:
    """
    PTR Editor CLI - Tools for PTR file editing and validation.

    Use -v to increase verbosity level:
    - No flag: WARNING level
    - -v: INFO level
    - -vv: DEBUG level
    - -vvv: TRACE level
    """

    level_to_level = {0: "WARNING", 1: "INFO", 2: "DEBUG", 3: "TRACE"}
    verbose = min(verbose, 3)
    set_logger_level(level_to_level[verbose])


# Register commands
app.command()(validate)
app.command()(version)


if __name__ == "__main__":
    app()
