"""CLI for ptr-editor."""

from .main import app

__all__ = ["app"]
