# PTR CLI

Command-line interface for ptr-editor.

> **Note:** The CLI is an optional component of ptr-editor. For basic Python API usage in notebooks and scripts, it is not required.

## Installation

Install with the CLI dependencies:

```bash
pip install "ptr-editor[cli]"
```

Or with uv in your uv-based environment:

```bash
uv add ptr-editor[cli]
```

## Commands

### Validate

Validate a PTR file using the default validation registry:

```bash
ptr-editor validate path/to/file.ptx
```

With verbose output showing sources:

```bash
ptr-editor validate path/to/file.ptx --verbose
```

### Version

Show the ptr-editor version:

```bash
ptr-editor version
```

