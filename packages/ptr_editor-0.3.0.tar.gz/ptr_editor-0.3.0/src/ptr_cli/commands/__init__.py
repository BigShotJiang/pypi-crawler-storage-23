"""CLI commands for ptr-editor."""

from .validate import validate
from .version import version

__all__ = ["validate", "version"]
