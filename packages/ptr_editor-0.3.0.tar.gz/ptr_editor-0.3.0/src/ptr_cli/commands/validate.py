"""Validate command for ptr-editor CLI."""

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from ptr_editor import read_ptr
from ptr_editor.services.quick_access import get_validation_registry

console = Console()


def validate(
    ptr_file: Path = typer.Argument(
        ...,
        help="Path to the PTR file to validate",
        exists=True,
        file_okay=True,
        dir_okay=False,
        readable=True,
    ),
) -> None:
    """
    Validate a PTR file using the default validation registry.

    Reads the PTR file as a Timeline and validates it against all
    registered validation rules.

    Example:
        ptr-editor validate my_file.ptx
        ptr-editor -v validate my_file.ptx
    """
    try:
        # Read the PTR file
        console.print(f"[blue]Reading PTR file:[/blue] {ptr_file}")
        timeline = read_ptr(str(ptr_file))
        console.print(
            f"[green]✓[/green] Successfully loaded timeline with "
            f"{len(timeline)} blocks"
        )

        # Get validation registry and validate
        console.print("[blue]Validating timeline...[/blue]")
        registry = get_validation_registry()

        from ptr_editor.validation.ptr_validators import get_ruleset
        result = registry.validate(timeline, ruleset=get_ruleset('ptr'))

        # Display results
        if result.ok:
            console.print("\n[bold green]✓ Validation passed![/bold green]")
            console.print("No issues found.")
            raise typer.Exit(0)

        console.print("\n[bold red]✗ Validation failed![/bold red]")
        console.print(f"Found {len(result.issues)} issue(s):\n")

        # Use the as_pandas() method to get the DataFrame
        df = result.as_pandas()

        # Create a table from the DataFrame
        table = Table(show_header=True, header_style="bold magenta")

        # Add all columns from the DataFrame
        for col in df.columns:
            if col == "severity":
                table.add_column("Severity", style="dim")
            elif col == "path":
                table.add_column("Path", style="cyan")
            elif col == "message":
                table.add_column("Message", style="white")
            elif col == "source":
                table.add_column("Source", style="dim")
            else:
                table.add_column(col.capitalize())

        # Add rows from DataFrame
        for _, row in df.iterrows():
            severity_style = {
                "critical": "[bold red]",
                "error": "[red]",
                "warning": "[yellow]",
                "info": "[blue]",
            }.get(row["severity"], "")

            table_row = []
            for col in df.columns:
                if col == "severity":
                    table_row.append(f"{severity_style}{row[col].upper()}[/]")
                else:
                    table_row.append(str(row[col]) if row[col] else "-")

            table.add_row(*table_row)

        console.print(table)
        raise typer.Exit(1)

    except FileNotFoundError:
        console.print(f"[bold red]Error:[/bold red] File not found: {ptr_file}")
        raise typer.Exit(1) from None
    except typer.Exit:
        # Re-raise typer.Exit without catching it
        raise
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] {type(e).__name__}: {e}")
        console.print_exception()
        raise typer.Exit(1) from None
