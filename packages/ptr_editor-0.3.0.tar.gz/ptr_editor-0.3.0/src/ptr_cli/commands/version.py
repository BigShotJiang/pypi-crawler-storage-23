"""Version command for ptr-editor CLI."""

import typer
from rich.console import Console
from rich.table import Table

console = Console()


def version(
    env: bool = typer.Option(
        False,
        "--env",
        help="Show versions of key packages in the environment",
    ),
) -> None:
    """Show the ptr-editor version."""
    try:
        from importlib.metadata import version as get_version

        ver = get_version("ptr-editor")
        console.print(f"ptr-editor version: [bold cyan]{ver}[/bold cyan]")

        if env:
            console.print("\n[bold]Environment core packages:[/bold]")
            packages = [
                "ptwrapper",
                "osve",
                "planetary-coverage",
                "quick-spice-manager",
                "pandas",
                "numpy",
                "attrs",
                "cattrs",
                "loguru",
            ]

            # Create a table for package versions
            table = Table(show_header=True, header_style="bold magenta")
            table.add_column("Package", style="cyan")
            table.add_column("Version", style="white")

            for package in packages:
                try:
                    pkg_version = get_version(package)
                    table.add_row(package, pkg_version)
                except Exception:
                    table.add_row(package, "[dim]not installed[/dim]")

            console.print(table)

    except Exception:
        console.print("ptr-editor version: [dim]unknown[/dim]")
