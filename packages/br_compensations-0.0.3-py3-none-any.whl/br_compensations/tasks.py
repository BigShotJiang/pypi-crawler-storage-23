from celery import shared_task
from django.db import transaction, models
from django.db.models import Q
from .models import BattleReport
from django.utils import timezone
from allianceauth.services.tasks import QueueOnce
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from allianceauth.services.hooks import get_extension_logger
from .models import  KillCompensation
from .services import BattleReportsService

logger = get_extension_logger(__name__)

# Конфигурация
MAX_RETRIES = 3
BATCH_SIZE = 5
BACKOFF_SCHEDULE = [1, 5, 15]  # Минуты для экспоненциального бэк-оффа
PROCESSING_TIMEOUT = 300  # 5 минут на обработку

@shared_task(bind=True, base=QueueOnce)
def process_queued_links(self):
    """
    Обрабатывает отложенные ссылки из очереди.
    Использует блокировку записей для предотвращения обработки одной ссылки несколькими воркерами.
    """
    start_time = timezone.now()
    channel_layer = get_channel_layer()
    reports = BattleReport.objects.exclude(status = BattleReport.PROCESS_COMPLETE).all()
    
    # Уведомляем об начале обработки
    async_to_sync(channel_layer.group_send)(
        "all_users",  # Группа для всех пользователей
        {
            "type": "queue.processing.started",
            "timestamp": timezone.now().isoformat()
        }
    )
    
    processed_count = 0
    failed_count = 0
    
    try:
        with transaction.atomic():
            # Блокируем записи для обработки (используем select_for_update)
            # Фильтруем записи со статусом PENDING, у которых время следующей попытки уже наступило
            start_time = timezone.now()
            queue_items = reports.select_for_update(skip_locked=True)[
                :BATCH_SIZE  # Ограничиваем количество обрабатываемых за раз
            ]
            
            for item in queue_items:
                item.status = BattleReport.PROCESS_PROCESSING
                item.save()
                
                try:
                    count = BattleReportsService.process(item.link)
                    
                    if len(count) > 0:
                        # Успех - помечаем как завершенную
                        item.status = BattleReport.PROCESS_COMPLETE
                        item.save() 
                        processed_count += len(count)
                    else:
                        # Нет целевых киллов, но данные получены
                        item.status = BattleReport.PROCESS_COMPLETE
                        item.save() 
                        logger.info(f"No targeted kills found in {item.link}")
                
                except Exception as e:
                    logger.error(f'При обработке отчета произошла ошибка {e}',e)
                    item.status = BattleReport.PROCESS_FAILED
                    item.save()
                    
                # Прерываем обработку, если превышено время выполнения
                if (timezone.now() - start_time).total_seconds() > PROCESSING_TIMEOUT:
                    logger.info("Processing timeout reached, stopping batch")
                    break
    
    except Exception as e:
        logger.exception("Error in process_queued_links task")
        async_to_sync(channel_layer.group_send)(
            "all_users",  # Группа для всех пользователей
            {
                "type": "queue.processing.error",
                "error": str(e),
                "timestamp": timezone.now().isoformat()
            }
        )
        raise e
    
    # Уведомляем об окончании обработки
    async_to_sync(channel_layer.group_send)(
        "all_users",  # Группа для всех пользователей
        {
            "type": "queue.processing.complete",
            "processed_count": processed_count,
            "failed_count": failed_count,
            "timestamp": timezone.now().isoformat()
        }
    )
    
    # Обновляем статистику для всех клиентов
    async_to_sync(channel_layer.group_send)(
        "all_users",  # Группа для всех пользователей
        {
            "type": "queue.stats.updated",
            "stats": {
                'total_pending': BattleReport.objects.filter(status=BattleReport.PROCESS_NEW).count(),
                'total_processing': BattleReport.objects.filter(status=BattleReport.PROCESS_PROCESSING).count(),
                'total_failed': BattleReport.objects.filter(status=BattleReport.PROCESS_FAILED).count()
            }
        }
    )
    
    return {
        "status": "completed",
        "processed_count": processed_count,
        "failed_count": failed_count,
        "duration": (timezone.now() - start_time).total_seconds()
    }

@shared_task
def cleanup_old_killmails():
    pass

