from rest_framework import viewsets, mixins
from rest_framework.response import Response
from rest_framework.decorators import action
from ..models import FilterEntity, KillCompensation
from .serializers import FilterEntrySerializer
from ..permissions import HasCompensationsPluginAccess

class BrCompensationsViewSet(viewsets.ModelViewSet,mixins.UpdateModelMixin):
    """
    API для управления киллмэйлами
    """
    queryset = FilterEntity.objects.all()
    permission_classes = [HasCompensationsPluginAccess]
    
    
    def get_queryset(self):
        """Оптимизация запросов"""
        return super().get_queryset()
    
    serializer_class = FilterEntrySerializer(partial=True)
    
    @action(detail=True,methods=['GET'])
    def get_filters(self, request):
        data = self.get_serializer(FilterEntity.objects.all())
        return Response(data)      
      
    # @action(detail=True,methods=['DELETE'])
    def destroy(self, request, pk=None, *args, **kwargs):
        if pk:
            filter = FilterEntity.objects.get(entity_id = pk)
            filter.delete(keep_parents=True)
            return Response(status=200, data=pk)
            #return super().destroy(filter,*args,**kwargs)
        return Response(status=404)