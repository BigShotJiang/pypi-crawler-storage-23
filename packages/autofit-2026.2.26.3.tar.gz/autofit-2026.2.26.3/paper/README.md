PyAutoFit JOSS Paper
====================

Paper accompanying [PyAutoFit](https://github.com/rhayes777/PyAutoFit) for submission to the Journal of Open Source 
Software (JOSS).