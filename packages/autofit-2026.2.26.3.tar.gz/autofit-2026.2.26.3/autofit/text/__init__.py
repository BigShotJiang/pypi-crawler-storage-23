from autofit.text import samples_text as Samples
