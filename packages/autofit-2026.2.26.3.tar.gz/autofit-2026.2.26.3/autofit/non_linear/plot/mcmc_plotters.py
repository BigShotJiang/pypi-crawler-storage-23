import logging

from autofit.non_linear.plot.samples_plotters import SamplesPlotter

logger = logging.getLogger(__name__)

class MCMCPlotter(SamplesPlotter):

    pass

