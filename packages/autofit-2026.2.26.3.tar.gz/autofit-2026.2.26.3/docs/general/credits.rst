.. _credits:

Credits
-------

**Developers:**

`Richard Hayes <https://github.com/rhayes777>`_ - Lead developer

`James Nightingale <https://github.com/Jammy2211>`_ - Lead developer

`Matthew Griffiths <https://github.com/matthewghgriffiths>`_ - Graphical models guru