# stock-gen

언어: [English (canonical)](README.md) | 한국어

`stock-gen`은 가상 주식 실험용 이벤트 기반 단일자산 CLOB 시뮬레이터입니다.

> 한국어 문서는 빠른 진입용 요약입니다. API/계약의 기준 문서는 영문 문서입니다.

## 빠른 시작

```bash
python -m pip install stock-gen
```

```python
from stock_gen import StockGenerator, StockGeneratorConfig

cfg = StockGeneratorConfig(seed=123, end_time=5.0)
sim = StockGenerator(cfg).gen()
print(len(sim.frames), len(sim.events), len(sim.trades))
```

## 핵심 변경 (v0.8)

- 휴면 호가 삽입 시 `best_bid > best_ask` 교차 상태를 방지합니다.
- `replace` 이벤트는 체결을 일으킬 수 있으며, 전량 체결 시 `order_id=None`이 될 수 있습니다.
- `step()` 도중 예외가 나면 정책과 무관하게 상태/히스토리를 롤백한 뒤 예외를 다시 올립니다.
- `viz.plot_l2_heatmap` 기본값이 빈 세로영역을 줄이도록 바뀌었습니다:
  - `price_window_ticks="auto"`
  - `y_range="auto"` (단일 side는 `side`, 양 side는 `occupied`)

## 문서 링크 (영문 기준)

- 문서 인덱스: [docs/index.md](docs/index.md)
- API: [docs/api.md](docs/api.md)
- 설정: [docs/config-reference.md](docs/config-reference.md)
- 데이터 계약: [docs/data-contract.md](docs/data-contract.md)
- 시각화: [docs/viz.md](docs/viz.md)
- 재현성: [docs/reproducibility.md](docs/reproducibility.md)
- 마이그레이션:
  - [docs/archive/migration-v0.8.md](docs/archive/migration-v0.8.md)
  - [docs/archive/migration-v0.7.md](docs/archive/migration-v0.7.md)
  - [docs/archive/legacy-migrations.md](docs/archive/legacy-migrations.md)

## 변경 이력

- [CHANGELOG.md](CHANGELOG.md)
