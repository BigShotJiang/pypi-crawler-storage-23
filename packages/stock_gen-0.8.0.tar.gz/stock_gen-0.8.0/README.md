# stock-gen

Language: English (canonical) | [한국어](README.ko.md)

`stock-gen` is an event-driven single-asset CLOB simulator for virtual stock experiments.
It models limit placement, market orders, cancel/partial-cancel, replace, and synthetic maintenance events.

## Requirements

- Python >= 3.11

## Install

```bash
python -m pip install stock-gen
```

For local development:

```bash
python -m pip install -e '.[dev]'
```

## Quickstart

```python
from stock_gen import StockGenerator, StockGeneratorConfig

cfg = StockGeneratorConfig(seed=123, end_time=5.0)
sim = StockGenerator(cfg).gen()
print(len(sim.frames), len(sim.events), len(sim.trades))
```

## Behavior Highlights (v0.8)

- Default `tick_size` is `1.0`.
- Built-in stochastic pattern diversity is generated internally from RNG state (no separate pattern config API).
- Resting book invariants reject crossed resting inserts (`best_bid > best_ask`).
- `replace` can generate trades and may finish with `order_id=None` when fully executed.
- `step()` now rolls back state/history on any exception before re-raising.
- `viz.plot_l2_heatmap` defaults to compact price-space output:
  - `price_window_ticks="auto"`
  - `y_range="auto"` (`side` for single-side plots, `occupied` for both-side plots)

## Documentation

- Canonical docs index: [docs/index.md](docs/index.md)
- API reference: [docs/api.md](docs/api.md)
- Config reference: [docs/config-reference.md](docs/config-reference.md)
- Data contract: [docs/data-contract.md](docs/data-contract.md)
- Visualization guide: [docs/viz.md](docs/viz.md)
- Reproducibility: [docs/reproducibility.md](docs/reproducibility.md)
- Architecture notes: [docs/architecture.md](docs/architecture.md)
- Migration notes:
  - [docs/archive/migration-v0.8.md](docs/archive/migration-v0.8.md)
  - [docs/archive/migration-v0.7.md](docs/archive/migration-v0.7.md)
  - [docs/archive/legacy-migrations.md](docs/archive/legacy-migrations.md)
- Examples: [examples/basic_run.py](examples/basic_run.py), [examples/plot_demo.py](examples/plot_demo.py)

## Version History

- Project changelog: [CHANGELOG.md](CHANGELOG.md)
