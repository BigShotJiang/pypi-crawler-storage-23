from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Protocol

from numpy.random import Generator

from ..config import StockGeneratorConfig
from ..models_cancel import choose_cancel_order_id, sample_cancel_qty, select_order_by_priority_index
from ..models_placement import sample_placement
from ..models_size import sample_limit_qty, sample_market_qty
from ..orderbook import OrderBook
from ..sim_state import SimulationState
from ..types import EventType, PlacementMode, Side, Trade


class EventAppender(Protocol):
    def __call__(
        self,
        *,
        event_type: EventType,
        side: Side,
        price_ticks: int | None,
        qty: int | None,
        order_id: int | None,
        synthetic: bool = False,
        reason: str | None = None,
        placement_mode: PlacementMode | None = None,
        deep_distance: int | None = None,
        replaced_order_id: int | None = None,
    ) -> None: ...


@dataclass(slots=True)
class EventHandlerContext:
    """Runtime dependencies used by event handlers and dispatcher."""

    cfg: StockGeneratorConfig
    rng: Generator
    ob: OrderBook
    state: SimulationState
    anchor_bests: Callable[[], tuple[int, int]]
    append_event: EventAppender


EventHandler = Callable[[float, int, int, int], list[Trade]]


class EventDispatcher:
    """Route sampled event types to concrete order-book mutations."""

    def __init__(self, context: EventHandlerContext) -> None:
        self._ctx = context
        self._handlers: dict[EventType, EventHandler] = {
            EventType.L_B: self._handle_limit_bid,
            EventType.L_A: self._handle_limit_ask,
            EventType.M_B: self._handle_market_bid,
            EventType.M_A: self._handle_market_ask,
            EventType.C_B: self._handle_cancel_bid,
            EventType.C_A: self._handle_cancel_ask,
            EventType.R_B: self._handle_replace_bid,
            EventType.R_A: self._handle_replace_ask,
        }

    def process(self, *, event_type: EventType, imbalance: float) -> list[Trade]:
        """Process one sampled event type and return generated trades."""

        handler = self._handlers.get(event_type)
        if handler is None:
            raise ValueError(f"unknown event_type: {event_type}")

        best_bid_anchor, best_ask_anchor = self._ctx.anchor_bests()
        spread_ticks = int(best_ask_anchor - best_bid_anchor)
        return handler(float(imbalance), best_bid_anchor, best_ask_anchor, spread_ticks)

    def apply_pattern_jump(self, *, side: Side, qty_scale: float) -> list[Trade]:
        """Apply a synthetic jump shock as an aggressive market order."""

        base_qty = sample_market_qty(cfg=self._ctx.cfg.size, rng=self._ctx.rng)
        scaled = float(base_qty) * max(0.25, float(qty_scale))
        qty = max(1, min(int(round(scaled)), int(self._ctx.cfg.size.max_order_qty)))
        trades = self._ctx.ob.process_market(side=side, qty=qty, t=self._ctx.state.t)
        self._ctx.append_event(
            event_type=EventType.M_B if side is Side.BID else EventType.M_A,
            side=side,
            price_ticks=None,
            qty=int(qty),
            order_id=None,
            synthetic=True,
            reason="pattern_jump",
        )
        return trades

    def _handle_limit_bid(
        self, imbalance: float, best_bid_anchor: int, best_ask_anchor: int, spread_ticks: int
    ) -> list[Trade]:
        return self._handle_limit(
            event_type=EventType.L_B,
            side=Side.BID,
            imbalance=imbalance,
            best_bid_anchor=best_bid_anchor,
            best_ask_anchor=best_ask_anchor,
            spread_ticks=spread_ticks,
        )

    def _handle_limit_ask(
        self, imbalance: float, best_bid_anchor: int, best_ask_anchor: int, spread_ticks: int
    ) -> list[Trade]:
        return self._handle_limit(
            event_type=EventType.L_A,
            side=Side.ASK,
            imbalance=imbalance,
            best_bid_anchor=best_bid_anchor,
            best_ask_anchor=best_ask_anchor,
            spread_ticks=spread_ticks,
        )

    def _handle_market_bid(
        self, _imbalance: float, _best_bid_anchor: int, _best_ask_anchor: int, _spread_ticks: int
    ) -> list[Trade]:
        return self._handle_market(event_type=EventType.M_B, side=Side.BID)

    def _handle_market_ask(
        self, _imbalance: float, _best_bid_anchor: int, _best_ask_anchor: int, _spread_ticks: int
    ) -> list[Trade]:
        return self._handle_market(event_type=EventType.M_A, side=Side.ASK)

    def _handle_cancel_bid(
        self, _imbalance: float, _best_bid_anchor: int, _best_ask_anchor: int, _spread_ticks: int
    ) -> list[Trade]:
        return self._handle_cancel(event_type=EventType.C_B, side=Side.BID)

    def _handle_cancel_ask(
        self, _imbalance: float, _best_bid_anchor: int, _best_ask_anchor: int, _spread_ticks: int
    ) -> list[Trade]:
        return self._handle_cancel(event_type=EventType.C_A, side=Side.ASK)

    def _handle_replace_bid(
        self, imbalance: float, best_bid_anchor: int, best_ask_anchor: int, spread_ticks: int
    ) -> list[Trade]:
        return self._handle_replace(
            event_type=EventType.R_B,
            side=Side.BID,
            imbalance=imbalance,
            best_bid_anchor=best_bid_anchor,
            best_ask_anchor=best_ask_anchor,
            spread_ticks=spread_ticks,
        )

    def _handle_replace_ask(
        self, imbalance: float, best_bid_anchor: int, best_ask_anchor: int, spread_ticks: int
    ) -> list[Trade]:
        return self._handle_replace(
            event_type=EventType.R_A,
            side=Side.ASK,
            imbalance=imbalance,
            best_bid_anchor=best_bid_anchor,
            best_ask_anchor=best_ask_anchor,
            spread_ticks=spread_ticks,
        )

    def _handle_limit(
        self,
        *,
        event_type: EventType,
        side: Side,
        imbalance: float,
        best_bid_anchor: int,
        best_ask_anchor: int,
        spread_ticks: int,
    ) -> list[Trade]:
        mode, price_ticks, deep_distance = sample_placement(
            cfg=self._ctx.cfg.placement,
            rng=self._ctx.rng,
            side=side,
            best_bid_ticks=best_bid_anchor,
            best_ask_ticks=best_ask_anchor,
            spread_ticks=spread_ticks,
            imbalance=float(imbalance),
            side_bias=float(self._ctx.state.pattern_placement_side_bias),
            deep_distance_scale=float(self._ctx.state.pattern_deep_distance_scale),
        )
        qty = sample_limit_qty(cfg=self._ctx.cfg.size, rng=self._ctx.rng, mode=mode)
        order_id, trades = self._ctx.ob.process_limit(
            side=side,
            price_ticks=price_ticks,
            qty=qty,
            t=self._ctx.state.t,
        )
        self._ctx.append_event(
            event_type=event_type,
            side=side,
            price_ticks=int(price_ticks),
            qty=int(qty),
            order_id=order_id,
            placement_mode=mode,
            deep_distance=deep_distance,
        )
        return trades

    def _handle_market(self, *, event_type: EventType, side: Side) -> list[Trade]:
        qty = sample_market_qty(cfg=self._ctx.cfg.size, rng=self._ctx.rng)
        trades = self._ctx.ob.process_market(side=side, qty=qty, t=self._ctx.state.t)
        self._ctx.append_event(
            event_type=event_type,
            side=side,
            price_ticks=None,
            qty=int(qty),
            order_id=None,
        )
        return trades

    def _handle_cancel(self, *, event_type: EventType, side: Side) -> list[Trade]:
        order_id = choose_cancel_order_id(
            ob=self._ctx.ob,
            side=side,
            cfg=self._ctx.cfg.cancel,
            rng=self._ctx.rng,
            xi_shift=float(self._ctx.state.pattern_cancel_xi_shift),
        )
        if order_id is None:
            return []

        order = self._ctx.ob.get_order(order_id)
        if order is None:
            return []
        _order_side, _order_price, order_qty = order
        cancel_qty = sample_cancel_qty(cfg=self._ctx.cfg.cancel, rng=self._ctx.rng, order_qty=order_qty)
        canceled = self._ctx.ob.cancel_partial(order_id, qty=cancel_qty)
        if canceled is None:
            return []

        _side, price_ticks, qty, _remaining = canceled
        self._ctx.append_event(
            event_type=event_type,
            side=side,
            price_ticks=int(price_ticks),
            qty=int(qty),
            order_id=int(order_id),
        )
        return []

    def _handle_replace(
        self,
        *,
        event_type: EventType,
        side: Side,
        imbalance: float,
        best_bid_anchor: int,
        best_ask_anchor: int,
        spread_ticks: int,
    ) -> list[Trade]:
        order_id = select_order_by_priority_index(
            self._ctx.ob,
            side=side,
            xi=float(self._ctx.rng.uniform()),
        )
        if order_id is None:
            return []

        mode, price_ticks, deep_distance = sample_placement(
            cfg=self._ctx.cfg.placement,
            rng=self._ctx.rng,
            side=side,
            best_bid_ticks=best_bid_anchor,
            best_ask_ticks=best_ask_anchor,
            spread_ticks=spread_ticks,
            imbalance=float(imbalance),
            side_bias=float(self._ctx.state.pattern_placement_side_bias),
            deep_distance_scale=float(self._ctx.state.pattern_deep_distance_scale),
        )
        qty = sample_limit_qty(cfg=self._ctx.cfg.size, rng=self._ctx.rng, mode=mode)
        new_order_id, trades = self._ctx.ob.replace(
            order_id,
            new_price_ticks=price_ticks,
            new_qty=qty,
            t=self._ctx.state.t,
        )
        self._ctx.append_event(
            event_type=event_type,
            side=side,
            price_ticks=int(price_ticks),
            qty=int(qty),
            order_id=None if new_order_id is None else int(new_order_id),
            placement_mode=mode,
            deep_distance=deep_distance,
            replaced_order_id=int(order_id),
        )
        return trades
