from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from numpy.random import Generator

from ..config import StockGeneratorConfig
from ..orderbook import OrderBook
from ..sim_loop import StepStats
from ..sim_policies import resolve_event_cap
from ..sim_state import SimulationState
from ..types import FrameSnapshot, Trade
from .event_handlers import EventDispatcher
from .features import compute_event_loop_features, sample_event_type
from .snapshot import build_frame_snapshot
from .stochastic_pattern import (
    advance_pattern_state,
    current_pattern_view,
    ensure_pattern_state,
    maybe_sample_pattern_jump,
)


@dataclass(slots=True)
class FrameRunnerContext:
    """Execution dependencies required for one frame simulation loop."""

    cfg: StockGeneratorConfig
    rng: Generator
    ob: OrderBook
    state: SimulationState
    event_dispatcher: EventDispatcher
    events_len: Callable[[], int]
    apply_liquidity_policy: Callable[[str], None]
    apply_depth_maintenance: Callable[[], int]
    decay_recent_flow: Callable[[float], None]
    record_trades: Callable[[list[Trade]], None]
    update_last_mid_ticks_from_book: Callable[[], None]


@dataclass(frozen=True, slots=True)
class FrameRunResult:
    """Frame snapshot and accounting metadata returned by :func:`run_frame`."""

    frame: FrameSnapshot
    stats: StepStats
    event_start: int


def run_frame(*, ctx: FrameRunnerContext, dt: float) -> FrameRunResult:
    """Run one simulation frame and return snapshot plus event counters."""

    t_end = ctx.state.t + float(dt)
    stats = StepStats()
    max_events = int(ctx.cfg.max_events_per_step)
    event_start = int(ctx.events_len())
    ensure_pattern_state(state=ctx.state, rng=ctx.rng)

    while True:
        ctx.apply_liquidity_policy("pre_event_loop")
        pattern_view = current_pattern_view(state=ctx.state)
        loop_features = compute_event_loop_features(
            ob=ctx.ob,
            state=ctx.state,
            cfg=ctx.cfg,
            pattern_imbalance_shift=pattern_view.imbalance_shift,
            pattern_intensity_multiplier=pattern_view.intensity_multiplier,
        )
        if loop_features.total_intensity <= 0.0:
            break

        delta = float(ctx.rng.exponential(1.0 / loop_features.total_intensity))
        if ctx.state.t + delta > t_end:
            break

        if stats.events_processed >= max_events:
            stats.truncated = resolve_event_cap(
                policy=ctx.cfg.event_cap_policy,
                max_events_per_step=max_events,
                current_time=float(ctx.state.t),
                step_end_time=float(t_end),
            )
            if stats.truncated:
                break

        ctx.state.t += delta
        ctx.decay_recent_flow(delta)
        advance_pattern_state(state=ctx.state, rng=ctx.rng, elapsed=delta)

        pattern_view = current_pattern_view(state=ctx.state)
        event_features = compute_event_loop_features(
            ob=ctx.ob,
            state=ctx.state,
            cfg=ctx.cfg,
            pattern_imbalance_shift=pattern_view.imbalance_shift,
            pattern_intensity_multiplier=pattern_view.intensity_multiplier,
        )
        if event_features.total_intensity <= 0.0:
            continue

        jump = maybe_sample_pattern_jump(
            state=ctx.state,
            rng=ctx.rng,
            elapsed=delta,
            has_bid=event_features.has_bid,
            has_ask=event_features.has_ask,
        )
        if jump is not None:
            ctx.record_trades(ctx.event_dispatcher.apply_pattern_jump(side=jump.side, qty_scale=jump.qty_scale))
            ctx.apply_liquidity_policy("pattern_jump")
            pattern_view = current_pattern_view(state=ctx.state)
            event_features = compute_event_loop_features(
                ob=ctx.ob,
                state=ctx.state,
                cfg=ctx.cfg,
                pattern_imbalance_shift=pattern_view.imbalance_shift,
                pattern_intensity_multiplier=pattern_view.intensity_multiplier,
            )
            if event_features.total_intensity <= 0.0:
                continue

        event_type = sample_event_type(
            rng=ctx.rng,
            lambdas=event_features.lambdas,
            total_intensity=event_features.total_intensity,
        )
        trades = ctx.event_dispatcher.process(
            event_type=event_type,
            imbalance=0.0 if event_features.imbalance is None else float(event_features.imbalance),
        )
        ctx.record_trades(trades)
        stats.record_event(t=ctx.state.t)

    remaining = max(0.0, t_end - ctx.state.t)
    if remaining > 0.0:
        ctx.decay_recent_flow(remaining)
        advance_pattern_state(state=ctx.state, rng=ctx.rng, elapsed=remaining)

    ctx.state.t = t_end
    ctx.apply_liquidity_policy("pre_snapshot")
    _ = ctx.apply_depth_maintenance()
    ctx.update_last_mid_ticks_from_book()

    frame = build_frame_snapshot(
        ob=ctx.ob,
        state=ctx.state,
        depth_levels=int(ctx.cfg.depth_levels),
        tick_size=float(ctx.cfg.tick_size),
    )
    return FrameRunResult(frame=frame, stats=stats, event_start=event_start)
