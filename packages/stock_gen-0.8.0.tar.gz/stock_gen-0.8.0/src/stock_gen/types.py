from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any

import numpy as np
from numpy.typing import NDArray


class Side(str, Enum):
    """Order side."""

    BID = "bid"
    ASK = "ask"


class EventType(str, Enum):
    """Supported event types in the event-driven simulator."""

    L_B = "L_b"  # bid limit add
    L_A = "L_a"  # ask limit add
    M_B = "M_b"  # aggressive buy (eats asks)
    M_A = "M_a"  # aggressive sell (eats bids)
    C_B = "C_b"  # bid cancel
    C_A = "C_a"  # ask cancel
    R_B = "R_b"  # bid replace (v1: disabled by default)
    R_A = "R_a"  # ask replace (v1: disabled by default)


class PlacementMode(str, Enum):
    """Sampling mode used for limit-order placement."""

    IMPROVE = "improve"
    JOIN = "join"
    DEEP = "deep"


class LiquidityPolicy(str, Enum):
    """Controls how one-sided or empty order-book states are handled."""

    REPAIR = "repair"
    ALLOW_EMPTY = "allow_empty"
    HALT_ON_EMPTY = "halt_on_empty"


class EventCapPolicy(str, Enum):
    """Controls behavior when a step reaches max_events_per_step."""

    RAISE = "raise"
    TRUNCATE_AND_FLAG = "truncate_and_flag"


class DepthMaintenancePolicy(str, Enum):
    """Controls synthetic replenishment used to maintain visible L2 depth."""

    OFF = "off"
    SOFT_TARGET = "soft_target"
    STRICT_TARGET = "strict_target"


@dataclass(frozen=True, slots=True)
class Order:
    """Order-level resting liquidity entry."""

    order_id: int
    side: Side
    price_ticks: int
    qty: int


@dataclass(frozen=True, slots=True)
class Trade:
    """Trade record emitted by matching."""

    t: float
    price_ticks: int
    qty: int
    aggressor: Side


@dataclass(frozen=True, slots=True)
class Event:
    """Event record for placements, cancels, replaces, and market actions."""

    seq: int
    frame_index: int
    t: float
    event_type: EventType
    side: Side
    price_ticks: int | None
    qty: int | None
    order_id: int | None
    synthetic: bool = False
    reason: str | None = None
    placement_mode: PlacementMode | None = None
    deep_distance: int | None = None
    replaced_order_id: int | None = None


@dataclass(frozen=True, slots=True)
class L2Snapshot:
    """Immutable top-K depth snapshot."""

    bid_px: NDArray[np.float64] | NDArray[np.int64]
    bid_qty: NDArray[np.int64]
    bid_px_valid: NDArray[np.bool_]
    ask_px: NDArray[np.float64] | NDArray[np.int64]
    ask_qty: NDArray[np.int64]
    ask_px_valid: NDArray[np.bool_]


@dataclass(frozen=True, slots=True)
class FrameSnapshot:
    """Per-frame feature snapshot."""

    t: float
    best_bid_ticks: int | None
    best_ask_ticks: int | None
    mid_price: float | None
    spread_ticks: int | None
    bid_px_ticks: NDArray[np.int64]
    bid_qty: NDArray[np.int64]
    ask_px_ticks: NDArray[np.int64]
    ask_qty: NDArray[np.int64]
    imbalance: float | None
    recent_flow: float


@dataclass(frozen=True, slots=True)
class MarketHistory:
    """Immutable simulation history and vectorized export helper."""

    tick_size: float
    frames: tuple[FrameSnapshot, ...]
    events: tuple[Event, ...]
    trades: tuple[Trade, ...]

    def to_numpy(self, *, as_ticks: bool = False) -> dict[str, NDArray[Any]]:
        """Vectorize immutable frame history into NumPy arrays.

        Args:
            as_ticks: When ``True``, keep prices in integer tick-space. When ``False``,
                additional float price arrays are exported with ``NaN`` for missing levels.
        """

        n = len(self.frames)
        if n == 0:
            return {
                "t": np.asarray([], dtype=np.float64),
                "mid": np.asarray([], dtype=np.float64),
                "mid_valid": np.asarray([], dtype=bool),
                "spread_ticks": np.asarray([], dtype=np.int64),
                "spread_valid": np.asarray([], dtype=bool),
                "best_bid_ticks": np.asarray([], dtype=np.int64),
                "best_ask_ticks": np.asarray([], dtype=np.int64),
                "best_bid_valid": np.asarray([], dtype=bool),
                "best_ask_valid": np.asarray([], dtype=bool),
                "imbalance": np.asarray([], dtype=np.float64),
                "imbalance_valid": np.asarray([], dtype=bool),
                "recent_flow": np.asarray([], dtype=np.float64),
                "bid_px_ticks": np.asarray([], dtype=np.int64),
                "bid_qty": np.asarray([], dtype=np.int64),
                "ask_px_ticks": np.asarray([], dtype=np.int64),
                "ask_qty": np.asarray([], dtype=np.int64),
                "bid_px_valid": np.asarray([], dtype=bool),
                "ask_px_valid": np.asarray([], dtype=bool),
            }

        k = int(self.frames[0].bid_px_ticks.shape[0])
        t = np.empty(n, dtype=np.float64)
        mid = np.empty(n, dtype=np.float64)
        mid_valid = np.zeros(n, dtype=bool)
        spread_ticks = np.empty(n, dtype=np.int64)
        spread_valid = np.zeros(n, dtype=bool)
        best_bid_ticks = np.empty(n, dtype=np.int64)
        best_ask_ticks = np.empty(n, dtype=np.int64)
        best_bid_valid = np.zeros(n, dtype=bool)
        best_ask_valid = np.zeros(n, dtype=bool)
        imbalance = np.empty(n, dtype=np.float64)
        imbalance_valid = np.zeros(n, dtype=bool)
        recent_flow = np.empty(n, dtype=np.float64)

        bid_px_ticks = np.empty((n, k), dtype=np.int64)
        bid_qty = np.empty((n, k), dtype=np.int64)
        ask_px_ticks = np.empty((n, k), dtype=np.int64)
        ask_qty = np.empty((n, k), dtype=np.int64)
        bid_px_valid = np.zeros((n, k), dtype=bool)
        ask_px_valid = np.zeros((n, k), dtype=bool)

        for i, fr in enumerate(self.frames):
            t[i] = fr.t
            mid_valid[i] = fr.mid_price is not None
            mid[i] = np.nan if fr.mid_price is None else float(fr.mid_price)
            spread_valid[i] = fr.spread_ticks is not None
            spread_ticks[i] = -1 if fr.spread_ticks is None else int(fr.spread_ticks)
            best_bid_valid[i] = fr.best_bid_ticks is not None
            best_bid_ticks[i] = -1 if fr.best_bid_ticks is None else int(fr.best_bid_ticks)
            best_ask_valid[i] = fr.best_ask_ticks is not None
            best_ask_ticks[i] = -1 if fr.best_ask_ticks is None else int(fr.best_ask_ticks)
            imbalance_valid[i] = fr.imbalance is not None
            imbalance[i] = np.nan if fr.imbalance is None else float(fr.imbalance)
            recent_flow[i] = float(fr.recent_flow)
            bid_px_ticks[i, :] = fr.bid_px_ticks
            bid_qty[i, :] = fr.bid_qty
            ask_px_ticks[i, :] = fr.ask_px_ticks
            ask_qty[i, :] = fr.ask_qty
            bid_px_valid[i, :] = fr.bid_px_ticks >= 0
            ask_px_valid[i, :] = fr.ask_px_ticks >= 0

        out: dict[str, NDArray[Any]] = {
            "t": t,
            "mid": mid,
            "mid_valid": mid_valid,
            "spread_ticks": spread_ticks,
            "spread_valid": spread_valid,
            "best_bid_ticks": best_bid_ticks,
            "best_ask_ticks": best_ask_ticks,
            "best_bid_valid": best_bid_valid,
            "best_ask_valid": best_ask_valid,
            "imbalance": imbalance,
            "imbalance_valid": imbalance_valid,
            "recent_flow": recent_flow,
            "bid_px_ticks": bid_px_ticks,
            "bid_qty": bid_qty,
            "ask_px_ticks": ask_px_ticks,
            "ask_qty": ask_qty,
            "bid_px_valid": bid_px_valid,
            "ask_px_valid": ask_px_valid,
        }

        if not as_ticks:
            tick = float(self.tick_size)
            best_bid = np.full(n, np.nan, dtype=np.float64)
            best_ask = np.full(n, np.nan, dtype=np.float64)
            best_bid[best_bid_valid] = best_bid_ticks[best_bid_valid].astype(np.float64) * tick
            best_ask[best_ask_valid] = best_ask_ticks[best_ask_valid].astype(np.float64) * tick

            bid_px = np.full((n, k), np.nan, dtype=np.float64)
            ask_px = np.full((n, k), np.nan, dtype=np.float64)
            bid_px[bid_px_valid] = bid_px_ticks[bid_px_valid].astype(np.float64) * tick
            ask_px[ask_px_valid] = ask_px_ticks[ask_px_valid].astype(np.float64) * tick

            out["best_bid"] = best_bid
            out["best_ask"] = best_ask
            out["bid_px"] = bid_px
            out["ask_px"] = ask_px

        return out


@dataclass(frozen=True, slots=True)
class StepResult:
    """Per-frame result produced by StockGenerator.step()."""

    frame: FrameSnapshot
    truncated: bool
    events_user: int
    events_synthetic: int
    events_total: int
    t_last_event: float | None

    @property
    def events_processed(self) -> int:
        """Backward-compatible alias for ``events_user``."""

        return int(self.events_user)


@dataclass(frozen=True, slots=True)
class SimulationResult:
    """Cumulative result returned by StockGenerator.gen()."""

    history: MarketHistory
    steps: tuple[StepResult, ...]

    @property
    def frames(self) -> tuple[FrameSnapshot, ...]:
        """Alias for history.frames."""

        return self.history.frames

    @property
    def events(self) -> tuple[Event, ...]:
        """Alias for history.events."""

        return self.history.events

    @property
    def trades(self) -> tuple[Trade, ...]:
        """Alias for history.trades."""

        return self.history.trades
