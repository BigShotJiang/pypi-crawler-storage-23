from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class SimulationStateSnapshot:
    """Immutable state checkpoint used for atomic step rollback."""

    t: float
    recent_flow: float
    last_mid_ticks: int | None
    frame_index: int
    next_event_seq: int
    pattern_regime: int
    pattern_time_remaining: float
    pattern_intensity_multiplier: float
    pattern_imbalance_shift: float
    pattern_placement_side_bias: float
    pattern_deep_distance_scale: float
    pattern_cancel_xi_shift: float
    pattern_jump_cooldown: float


@dataclass(slots=True)
class SimulationState:
    t: float = 0.0
    recent_flow: float = 0.0
    last_mid_ticks: int | None = None
    frame_index: int = 0
    _next_event_seq: int = 1
    pattern_regime: int = -1
    pattern_time_remaining: float = 0.0
    pattern_intensity_multiplier: float = 1.0
    pattern_imbalance_shift: float = 0.0
    pattern_placement_side_bias: float = 0.0
    pattern_deep_distance_scale: float = 1.0
    pattern_cancel_xi_shift: float = 0.0
    pattern_jump_cooldown: float = 0.0

    def reset(self) -> None:
        self.t = 0.0
        self.recent_flow = 0.0
        self.last_mid_ticks = None
        self.frame_index = 0
        self._next_event_seq = 1
        self.pattern_regime = -1
        self.pattern_time_remaining = 0.0
        self.pattern_intensity_multiplier = 1.0
        self.pattern_imbalance_shift = 0.0
        self.pattern_placement_side_bias = 0.0
        self.pattern_deep_distance_scale = 1.0
        self.pattern_cancel_xi_shift = 0.0
        self.pattern_jump_cooldown = 0.0

    def next_event_seq(self) -> int:
        seq = self._next_event_seq
        self._next_event_seq += 1
        return seq

    def snapshot(self) -> SimulationStateSnapshot:
        """Capture a state snapshot for rollback."""

        return SimulationStateSnapshot(
            t=float(self.t),
            recent_flow=float(self.recent_flow),
            last_mid_ticks=None if self.last_mid_ticks is None else int(self.last_mid_ticks),
            frame_index=int(self.frame_index),
            next_event_seq=int(self._next_event_seq),
            pattern_regime=int(self.pattern_regime),
            pattern_time_remaining=float(self.pattern_time_remaining),
            pattern_intensity_multiplier=float(self.pattern_intensity_multiplier),
            pattern_imbalance_shift=float(self.pattern_imbalance_shift),
            pattern_placement_side_bias=float(self.pattern_placement_side_bias),
            pattern_deep_distance_scale=float(self.pattern_deep_distance_scale),
            pattern_cancel_xi_shift=float(self.pattern_cancel_xi_shift),
            pattern_jump_cooldown=float(self.pattern_jump_cooldown),
        )

    def restore(self, snapshot: SimulationStateSnapshot) -> None:
        """Restore state from ``snapshot``."""

        self.t = float(snapshot.t)
        self.recent_flow = float(snapshot.recent_flow)
        self.last_mid_ticks = None if snapshot.last_mid_ticks is None else int(snapshot.last_mid_ticks)
        self.frame_index = int(snapshot.frame_index)
        self._next_event_seq = int(snapshot.next_event_seq)
        self.pattern_regime = int(snapshot.pattern_regime)
        self.pattern_time_remaining = float(snapshot.pattern_time_remaining)
        self.pattern_intensity_multiplier = float(snapshot.pattern_intensity_multiplier)
        self.pattern_imbalance_shift = float(snapshot.pattern_imbalance_shift)
        self.pattern_placement_side_bias = float(snapshot.pattern_placement_side_bias)
        self.pattern_deep_distance_scale = float(snapshot.pattern_deep_distance_scale)
        self.pattern_cancel_xi_shift = float(snapshot.pattern_cancel_xi_shift)
        self.pattern_jump_cooldown = float(snapshot.pattern_jump_cooldown)
