# API Reference

## Public Imports (Preferred)

```python
from stock_gen import (
    DepthMaintenanceConfig,
    DepthMaintenancePolicy,
    EventCapExceededError,
    EventCapPolicy,
    LiquidityPolicy,
    SimulationResult,
    StepResult,
    StockGenerator,
    StockGeneratorConfig,
)
```

## Explicit Module Paths (Types / Exceptions)

```python
from stock_gen.config import DepthMaintenanceConfig, StockGeneratorConfig
from stock_gen.types import DepthMaintenancePolicy, EventCapPolicy, LiquidityPolicy, SimulationResult, StepResult
from stock_gen.sim_policies import EventCapExceededError
```

Additional return types:

```python
from stock_gen.types import Event, FrameSnapshot, L2Snapshot, MarketHistory, Trade
```

## Core Objects

- `StockGeneratorConfig`: immutable simulator configuration.
- `DepthMaintenanceConfig`: depth replenishment policy settings (`StockGeneratorConfig.depth_maintenance`).
- `StockGenerator`: stateful simulator.
- `StepResult`: per-step output.
- `SimulationResult`: cumulative output.

## `StockGenerator`

- `StockGenerator(config: StockGeneratorConfig | None = None)`
- `step(dt: float | None = None) -> StepResult`
- `gen(until_time: float | None = None) -> SimulationResult`
- `reset(seed: int | None = None) -> None`
- `get_history() -> MarketHistory`
- `get_step_results() -> tuple[StepResult, ...]`
- `get_events() -> tuple[Event, ...]`
- `get_trades() -> tuple[Trade, ...]`
- `get_l2(levels: int | None = None, *, as_ticks: bool = False) -> L2Snapshot`
- `get_time() -> float`
- `get_price() -> float`
- `get_best_bid_ask() -> tuple[tuple[float, int], tuple[float, int]]`

Notes:
- `gen()` is stateful and continues from current simulator time.
- Returned history/event/trade/step containers are immutable tuples.
- `get_price()` returns `NaN` when either side of the book is missing.
- `get_best_bid_ask()` returns `(price, qty)` pairs per side; when a side is missing the price is `NaN` and quantity is `0`.

## `StepResult`

- `frame: FrameSnapshot`
- `truncated: bool`
- `events_user: int`
- `events_synthetic: int`
- `events_total: int`
- `t_last_event: float | None`
- `events_processed: int` (compatibility alias of `events_user`)

## `SimulationResult`

- `history: MarketHistory`
- `steps: tuple[StepResult, ...]`
- `frames`, `events`, `trades`: convenience aliases to `history`.

## `L2Snapshot`

- `bid_px`, `ask_px`: prices (`int64` when `as_ticks=True`, `float64` when `as_ticks=False`)
- `bid_qty`, `ask_qty`: quantities (`int64`)
- `bid_px_valid`, `ask_px_valid`: validity masks (`bool`)

Contract:
- `as_ticks=True`: missing levels use tick sentinel `-1`.
- `as_ticks=False`: missing levels use `NaN`.

## Visualization API

```python
from stock_gen import viz
```

- `viz.plot_mid(obj, *, ax=None)`
- `viz.plot_spread(obj, *, ax=None, in_ticks=True)`
- `viz.plot_l2_heatmap(obj, *, side="both", space="price", price_window_ticks="auto", y_range="auto", cmap="viridis", mask_invalid=True, normalize="log1p", vmax_quantile=0.99)`

`plot_l2_heatmap` options:
- `space="rank"`: y-axis is L2 level index (0 = best).
- `space="price"` (default): y-axis is relative ticks from frame mid price.
- `price_window_ticks`: positive `int` or `"auto"` (default).
- `y_range`: `"auto"` (default), `"full"`, `"side"`, or `"occupied"`.
  - `side in {"bid", "ask"}` with `space="price"` and `y_range="auto"` uses compact side range.
  - `side="both"` with `space="price"` and `y_range="auto"` uses occupied-bin cropping.

Compatibility note:
- To reproduce legacy symmetric y-range behavior, pass integer `price_window_ticks` with `y_range="full"`.

## Policy Enums

### `LiquidityPolicy`

- `REPAIR` (default): inserts synthetic liquidity for one-sided states.
- `ALLOW_EMPTY`: allows one-sided states.
- `HALT_ON_EMPTY`: raises `RuntimeError` on one-sided states.

### `EventCapPolicy`

- `RAISE` (default): raises `EventCapExceededError` and rolls back the step atomically.
- `TRUNCATE_AND_FLAG`: truncates step and sets `StepResult.truncated=True`.

### `DepthMaintenancePolicy`

- `OFF`: disable synthetic depth replenishment.
- `SOFT_TARGET` (default): replenish toward minimum per-level depth.
- `STRICT_TARGET`: replenish toward target per-level depth.

## Internal Random Pattern Behavior

`stock-gen` v0.7 adds internal stochastic pattern transitions (trend/quiet/volatile regimes) to diversify paths.
There is no separate public pattern-configuration API; reproducibility is controlled via `seed`.

## Error Behavior

Common exceptions:
- `StockGeneratorConfig(...)`: `ValueError` / `TypeError` for invalid ranges or types.
- `step(dt=...)`: `ValueError` if `dt <= 0`.
- `gen(until_time=...)`: `ValueError` if `until_time < current time`.
- `get_l2(levels=...)`: `ValueError` if `levels <= 0`.
- `LiquidityPolicy.HALT_ON_EMPTY`: `RuntimeError`.
- `EventCapPolicy.RAISE`: `stock_gen.sim_policies.EventCapExceededError`.

Step transaction guarantee:
- `step()` restores simulator state/history on any raised exception before re-raising.

Replace event note:
- A replace event may have `order_id=None` when the replacement order is fully filled immediately.
