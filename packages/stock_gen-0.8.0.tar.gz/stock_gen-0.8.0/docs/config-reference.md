# Config Reference

`StockGeneratorConfig` is the single entry point for simulator configuration.

## Import Paths

```python
from stock_gen import StockGeneratorConfig, DepthMaintenanceConfig, DepthMaintenancePolicy
```

Explicit module paths:

```python
from stock_gen.config import StockGeneratorConfig, DepthMaintenanceConfig
from stock_gen.types import DepthMaintenancePolicy
```

## Top-Level Fields (`StockGeneratorConfig`)

| Field | Default | Validation |
| --- | --- | --- |
| `tick_size` | `1.0` | `> 0` |
| `dt` | `1.0` | `> 0` |
| `end_time` | `600.0` | `>= 0` |
| `depth_levels` | `10` | `> 0` |
| `seed` | `123` | `int | None` |
| `initial_mid_price` | `None` | `None` or `> 0` |
| `initial_spread_ticks` | `2` | `> 0` |
| `init_levels_per_side` | `50` | `> 0` |
| `init_orders_per_level` | `3` | `> 0` |
| `max_events_per_step` | `50000` | `> 0` |
| `flow_half_life` | `10.0` | `>= 0` |
| `liquidity_policy` | `LiquidityPolicy.REPAIR` | must be `LiquidityPolicy` |
| `event_cap_policy` | `EventCapPolicy.RAISE` | must be `EventCapPolicy` |
| `intensity` | `ExpLinearIntensityConfig.default()` | must be `ExpLinearIntensityConfig` |
| `placement` | `PlacementConfig()` | must be `PlacementConfig` |
| `size` | `SizeConfig()` | must be `SizeConfig` |
| `cancel` | `CancelConfig()` | must be `CancelConfig` |
| `regime` | `RegimeConfig()` | must be `RegimeConfig` |
| `depth_maintenance` | `DepthMaintenanceConfig()` | must be `DepthMaintenanceConfig` |

## `ExpLinearIntensityConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `theta` | default per-event vectors | keys must be `EventType`, vector shape `(6,)` |
| `min_lambda` | `1e-12` | `> 0` |
| `exp_clip` | `50.0` | `> 0` |

Feature vector order:
`[1, log1p(spread_ticks), log1p(best_bid_qty), log1p(best_ask_qty), imbalance, recent_flow]`

## `PlacementConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `W` | `3x3` matrix | shape `(3, 3)` |
| `p_deep` | `0.40` | `(0, 1]` |
| `deep_max_ticks` | `200` | `> 0` |

## `SizeConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `market_mu` | `0.95` | - |
| `market_sigma` | `0.85` | `>= 0` |
| `improve_mu` | `1.35` | - |
| `improve_sigma` | `0.8` | `>= 0` |
| `join_mu` | `1.25` | - |
| `join_sigma` | `0.85` | `>= 0` |
| `deep_mu` | `1.15` | - |
| `deep_sigma` | `0.9` | `>= 0` |
| `max_order_qty` | `1000` | `> 0` |

## `CancelConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `beta_a` | `4.6` | `> 0` |
| `beta_b` | `2.3` | `> 0` |
| `partial_cancel_prob` | `0.30` | `[0, 1]` |
| `partial_min_ratio` | `0.2` | `(0, 1]` |

## `RegimeConfig`

`RegimeConfig.segments` is a tuple of `RegimeSegment(start_time, end_time, multiplier)`.

Rules:
- segments must be sorted by `start_time`
- segments must not overlap
- `multiplier > 0`

The active multiplier is applied to event intensities at current simulation time.

## `DepthMaintenanceConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `policy` | `DepthMaintenancePolicy.SOFT_TARGET` | must be `DepthMaintenancePolicy` |
| `target_levels` | `10` | `> 0` |
| `min_level_qty` | `2` | `> 0` |
| `target_level_qty` | `7` | `> 0` and `>= min_level_qty` |
| `level_decay` | `0.30` | `>= 0` |
| `max_synthetic_orders_per_step` | `8` | `>= 0` |
| `warmup_frames` | `0` | `>= 0` |

Policy values:
- `OFF`: disable synthetic depth maintenance.
- `SOFT_TARGET`: maintain minimum per-level depth.
- `STRICT_TARGET`: maintain target per-level depth.

## Notes on Pattern Diversity

v0.7 introduces internal stochastic pattern transitions for richer generated paths.
This behavior is intentionally not user-configurable; reproducibility remains controlled by `seed`.
