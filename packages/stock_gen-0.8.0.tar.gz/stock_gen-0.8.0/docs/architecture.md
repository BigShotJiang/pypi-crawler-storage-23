# Architecture Overview

`stock-gen` is an event-driven single-asset CLOB simulator with deterministic replay boundaries and policy-driven safety behavior.

## Design Goals

- deterministic replay for fixed config + seed
- explicit contracts for frames/events/trades exports
- robust handling of edge states (one-sided books, event caps)
- extensible microstructure model internals without widening public API

## Module Layout

- `stock_gen/generator.py`
  - public orchestration API (`step`, `gen`, `reset`, snapshot getters)
- `stock_gen/orderbook.py`
  - price-time-priority matching engine, partial cancel, replace, no-cross resting invariants
- `stock_gen/engine/`
  - `frame_runner.py`: per-frame event loop kernel
  - `event_handlers.py`: concrete event application
  - `features.py`: feature and intensity assembly
  - `depth_policy.py`: synthetic depth replenishment
  - `snapshot.py`: immutable L2/frame snapshots
  - `stochastic_pattern.py`: internal random regime process (v0.7)
- `stock_gen/runtime/`
  - `history_store.py`: centralized history buffers and immutable views (v0.7)
  - `checkpoint.py`: rollback checkpoint capture/restore
  - `step_transaction.py`: policy-driven transactional step wrapper (v0.7)
- `stock_gen/models_*`
  - intensity, placement, size, cancel samplers

## Step Execution Flow

1. Start frame interval `[t, t+dt]`.
2. Ensure two-sided liquidity according to `LiquidityPolicy`.
3. Build event-loop features and intensities.
4. Sample next event time and event type.
5. Advance stochastic pattern state (internal), apply optional jump shocks.
6. Apply event through dispatcher and record events/trades.
7. Repeat until interval end or event-cap policy stop.
8. Apply snapshot-time liquidity checks.
9. Apply depth maintenance (`OFF` / `SOFT_TARGET` / `STRICT_TARGET`).
10. Build immutable frame snapshot and append `StepResult`.

## Atomic Rollback Path

For every `step()` call:

- `run_step_transaction(...)` captures checkpoint.
- Frame execution runs.
- If any exception is raised (including `EventCapExceededError`), checkpoint is restored and the exception is re-raised.

This guarantees no partial frame mutation escapes on failed steps.

## Depth Maintenance Strategy (v0.7)

Depth maintenance now builds candidate deficits across levels and allocates limited synthetic budget by weighted deficit score.
This reduces persistent near-touch concentration and improves long-horizon depth visibility.

## Internal Stochastic Pattern Engine (v0.7)

- Internal hidden regimes perturb intensity, imbalance, placement depth bias, and cancel priority.
- Rare synthetic jump shocks are emitted as market-style events with `reason="pattern_jump"`.
- There is no public pattern configuration API.
- Fixed seed still yields deterministic replay.

## Determinism Boundaries

Deterministic when all are fixed:

- package version
- Python/NumPy environment
- full config
- seed

Potential drift sources:

- `seed=None`
- environment/version changes
- changed defaults or parameter values between releases
