# Legacy Migration Notes (v0.2 -> v0.6)

This file consolidates legacy migration notes that were previously split across multiple files.
Use this for historical upgrades only. For current upgrades, use:

- [migration-v0.8.md](migration-v0.8.md)
- [migration-v0.7.md](migration-v0.7.md)

## v0.2 -> v0.3

- Public history/event/trade/step containers became immutable tuples.
- Snapshot arrays became read-only exports.
- `get_l2(levels<=0)` now raises `ValueError`.
- Release process moved to tag-driven GitHub Actions OIDC publishing.

## v0.4 -> v0.5

- `get_l2(as_ticks=False)` missing prices changed to `NaN`.
- `L2Snapshot` validity masks were added.
- `StepResult` primary counters changed to `events_user/events_synthetic/events_total`.
- Runtime config type checks became strict.

## v0.5 -> v0.6

- Depth-maintenance policy controls were introduced.
- Heatmap visibility/scaling controls were introduced.
- Default runs began including synthetic depth-maintenance events.

## Reference

For full release details including historical rationale, see [../../CHANGELOG.md](../../CHANGELOG.md).
