# Data Contract

Stable output semantics for downstream consumers.

## `StepResult`

- `frame`: frame snapshot at step end.
- `truncated`: `True` only for `EventCapPolicy.TRUNCATE_AND_FLAG` when cap is hit.
- `events_user`: count of non-synthetic in-step events.
- `events_synthetic`: count of synthetic in-step events (liquidity repair + depth maintenance + internal pattern jumps).
- `events_total`: `events_user + events_synthetic`.
- `t_last_event`: last non-synthetic event time in the step, else `None`.
- `events_processed`: compatibility alias for `events_user`.

Event-cap behavior:
- `EventCapPolicy.RAISE`: raises `EventCapExceededError` and rolls back atomically.
- `EventCapPolicy.TRUNCATE_AND_FLAG`: returns `StepResult(truncated=True)`.
- Any other runtime exception during `step()` also rolls back atomically before re-raising.

## `SimulationResult`

- `history.frames/events/trades` are immutable tuples.
- `steps` is an immutable tuple and accumulates prior `step()` calls on the instance.

## `FrameSnapshot`

- Scalar fields: `t`, `best_bid_ticks`, `best_ask_ticks`, `mid_price`, `spread_ticks`, `imbalance`, `recent_flow`.
- L2 arrays: `bid_px_ticks`, `bid_qty`, `ask_px_ticks`, `ask_qty`.
- L2 arrays are shape `(depth_levels,)`, dtype `int64`, read-only.
- Missing level sentinels: price `-1`, qty `0`.

## `L2Snapshot`

- Fields: `bid_px`, `ask_px`, `bid_qty`, `ask_qty`, `bid_px_valid`, `ask_px_valid`.
- Masks (`*_px_valid`) indicate whether each level has a real price.

Encoding:
- `as_ticks=True`: missing price level -> `-1`.
- `as_ticks=False`: missing price level -> `NaN`.

## `MarketHistory.to_numpy()`

`to_numpy(as_ticks=True)` returns:
- `t`
- `mid`, `mid_valid`
- `spread_ticks`, `spread_valid`
- `best_bid_ticks`, `best_ask_ticks`, `best_bid_valid`, `best_ask_valid`
- `imbalance`, `imbalance_valid`
- `recent_flow`
- `bid_px_ticks`, `bid_qty`, `bid_px_valid`
- `ask_px_ticks`, `ask_qty`, `ask_px_valid`

`to_numpy(as_ticks=False)` additionally returns:
- `best_bid`, `best_ask`, `bid_px`, `ask_px`

Missing-value policy:
- float price arrays use `NaN` for missing values.
- tick-space price arrays use `-1` with validity masks.

## `Event`

Stable fields:
- `seq`, `frame_index`, `t`, `event_type`, `side`
- `price_ticks`, `qty`, `order_id`
- `synthetic`, `reason`, `placement_mode`, `deep_distance`, `replaced_order_id`

Replace event note:
- Replacement events can have `order_id=None` when the replacement order is fully executed and no new resting order remains.

Notable synthetic reasons:
- `pre_event_loop`, `pre_snapshot`, `reset` (liquidity repair)
- `depth_maintenance`
- `pattern_jump`

## `Trade`

- `t: float`: execution time in simulation clock.
- `price_ticks: int`: execution price in tick-space.
- `qty: int`: executed quantity.
- `aggressor: Side`: side of aggressive order (`bid` means buy market order consumed asks).
