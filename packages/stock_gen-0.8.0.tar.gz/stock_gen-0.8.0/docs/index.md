# Documentation Index

English documentation is the canonical source for this project. All normative API and data-contract semantics are defined in English docs.

## Getting Started

- Project overview and quickstart: [../README.md](../README.md)
- Reproducibility checklist: [reproducibility.md](reproducibility.md)
- Example scripts: [../examples/basic_run.py](../examples/basic_run.py), [../examples/plot_demo.py](../examples/plot_demo.py)

## Public API and Contracts

- API reference: [api.md](api.md)
- Config reference: [config-reference.md](config-reference.md)
- Data contract: [data-contract.md](data-contract.md)
- Visualization guide: [viz.md](viz.md)

## Maintainer Docs

- Architecture notes: [architecture.md](architecture.md)
- Release flow: [release.md](release.md)
- Migration notes:
  - [archive/migration-v0.8.md](archive/migration-v0.8.md)
  - [archive/migration-v0.7.md](archive/migration-v0.7.md)
  - [archive/legacy-migrations.md](archive/legacy-migrations.md)

## Language

- Korean landing page: [../README.ko.md](../README.ko.md)

## Version History

- Changelog: [../CHANGELOG.md](../CHANGELOG.md)
