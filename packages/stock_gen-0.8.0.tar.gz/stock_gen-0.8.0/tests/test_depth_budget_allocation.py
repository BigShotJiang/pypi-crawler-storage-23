from stock_gen import DepthMaintenancePolicy, StockGeneratorConfig
from stock_gen.config import DepthMaintenanceConfig
from stock_gen.engine.depth_policy import apply_depth_maintenance
from stock_gen.orderbook import OrderBook
from stock_gen.sim_state import SimulationState
from stock_gen.types import EventType, PlacementMode, Side


def test_depth_budget_uses_deficit_weighting_not_front_first() -> None:
    cfg = StockGeneratorConfig(
        depth_levels=2,
        depth_maintenance=DepthMaintenanceConfig(
            policy=DepthMaintenancePolicy.STRICT_TARGET,
            target_levels=2,
            min_level_qty=1,
            target_level_qty=10,
            level_decay=0.10,
            max_synthetic_orders_per_step=1,
        ),
    )
    ob = OrderBook()
    _ = ob.add_limit_resting(side=Side.BID, price_ticks=100, qty=9)  # level 0 deficit=1
    _ = ob.add_limit_resting(side=Side.ASK, price_ticks=101, qty=10)
    _ = ob.add_limit_resting(side=Side.ASK, price_ticks=102, qty=10)

    state = SimulationState()
    captured: list[tuple[Side, int | None, PlacementMode | None, int | None, EventType]] = []

    inserted = apply_depth_maintenance(
        ob=ob,
        state=state,
        cfg=cfg,
        anchor_bests=lambda: (100, 101),
        append_event=lambda **kwargs: captured.append(
            (
                kwargs["side"],
                kwargs["price_ticks"],
                kwargs["placement_mode"],
                kwargs["deep_distance"],
                kwargs["event_type"],
            )
        ),
    )

    assert inserted == 1
    assert len(captured) == 1
    side, price_ticks, mode, deep_distance, event_type = captured[0]
    assert side is Side.BID
    assert event_type is EventType.L_B
    assert price_ticks == 99  # level 1 has larger weighted deficit than level 0
    assert mode is PlacementMode.DEEP
    assert deep_distance == 1
