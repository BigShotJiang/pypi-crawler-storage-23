# rye:signed:2026-02-26T06:42:42Z:92135959fc270503eadbcebca8b86044e2c8542e11b5e6748d5970012de441ed:S82kZQQrEuvtZWFmd-9yf5WwtbFqlX9t0yoR8M0Eqix4o3gbRU2TuebRb58FkxDftytn-zUfhzECYXLKpM68Aw==:4b987fd4e40303ac
"""Python runtime library package."""

__version__ = "1.0.0"
__tool_type__ = "python"
__category__ = "rye/core/runtimes/python/lib"
__tool_description__ = "Python runtime library package"
