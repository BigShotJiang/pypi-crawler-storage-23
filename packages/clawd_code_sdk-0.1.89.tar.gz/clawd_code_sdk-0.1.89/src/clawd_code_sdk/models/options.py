"""ClaudeAgentOptions - main options dataclass."""

from __future__ import annotations

from dataclasses import dataclass, field
import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any


if TYPE_CHECKING:
    from collections.abc import Callable

    from clawd_code_sdk.models.base import ModelName

    from .agents import AgentDefinition, SystemPromptPreset, ToolsPreset
    from .base import PermissionMode, ReasoningEffort, SettingSource, ThinkingConfig
    from .hooks import HookEvent, HookMatcher
    from .mcp import McpServerConfig, SdkPluginConfig
    from .permissions import CanUseTool
    from .sandbox import SandboxSettings

logger = logging.getLogger(__name__)


@dataclass
class ClaudeAgentOptions:
    """Query options for Claude SDK."""

    tools: list[str] | ToolsPreset | None = None
    """Tools available to the agent."""
    allowed_tools: list[str] | None = None
    """Tools which execute without prompting for permission."""
    system_prompt: str | SystemPromptPreset | None = None
    """System prompt for the agent."""
    mcp_servers: dict[str, McpServerConfig] | str | Path = field(default_factory=dict)
    """MCP servers for the agent."""
    permission_mode: PermissionMode | None = None
    """Permission mode."""
    session_id: str | None = None
    """Deterministic session ID for a new session."""
    continue_conversation: bool = False
    """Continue most recent conversation."""
    resume: str | None = None
    """Resume a conversation by session id."""
    max_turns: int | None = None
    """Maximum allowed amount of agentic turns."""
    max_budget_usd: float | None = None
    """Maximum amount of USD budget which may be consumed."""
    disallowed_tools: list[str] | None = None
    """Tools that are removed from agent context and cant be used."""
    model: ModelName | str | None = None
    """Session model."""
    fallback_model: ModelName | str | None = None
    """Fallback model in case default one is overloaded."""
    permission_prompt_tool_name: str | None = None
    """MCP tool to handle permission prompts."""
    cwd: str | Path | None = None
    """The working directory for the agent."""
    cli_path: str | Path | None = None
    """CLI path override (auto-detects by default)."""
    settings: str | None = None
    """Path to a settings JSON file or a JSON string."""
    add_dirs: list[str | Path] = field(default_factory=list)
    """Add additional working directories."""
    env: dict[str, str] = field(default_factory=dict)
    """Environment variables for the CLI subprocess."""
    extra_args: dict[str, str | None] = field(default_factory=dict)
    """Arbitrary extra CLI flags."""
    max_buffer_size: int | None = None
    """Max bytes when buffering CLI stdout."""
    stderr: Callable[[str], None] | None = None
    """Callback for stderr output from CLI."""
    can_use_tool: CanUseTool | None = None
    """Tool permission callback."""
    hooks: dict[HookEvent, list[HookMatcher]] | None = None
    """Hook configurations."""
    user: str | None = None
    """User for the AnyIO process."""
    fork_session: bool = False
    """Make resumed sessions forked to a new session ID instead of continuing."""
    agents: dict[str, AgentDefinition] | None = None
    """SubAgent definitions."""
    setting_sources: list[SettingSource] | None = None
    """List of sources to load settings from."""
    sandbox: SandboxSettings | None = None
    """Sandbox configuration for bash command isolation.

    Filesystem and network restrictions are derived from permission rules (Read/Edit/WebFetch),
    not from these sandbox settings.
    """
    plugins: list[SdkPluginConfig] = field(default_factory=list)
    """"Plugin configurations to load."""
    thinking: ThinkingConfig | None = None
    """Controls thinking behavior."""
    effort: ReasoningEffort | None = None
    """Effort level for thinking depth."""
    output_format: dict[str, Any] | None = None
    """Output format for structured outputs (matches Messages API structure)

    Example: {"type": "json_schema", "schema": {"type": "object", "properties": {...}}}
    """
    enable_file_checkpointing: bool = False
    """Enable file checkpointing to track file changes during the session.

    When enabled, files can be rewound to their state at any user message
    using `ClaudeSDKClient.rewind_files()`.
    """
    agent: str | None = None
    """Agent name for the main thread. The agent must be defined in `agents` or settings."""
    persist_session: bool | None = None
    """Whether to persist the session to disk."""
    allow_dangerously_skip_permissions: bool = False
    """Must be True when using permission_mode='bypassPermissions'."""
    resume_session_at: str | None = None
    """Resume from a specific message UUID (use with `resume`)."""
    debug_file: str | None = None
    """Write debug logs to a specific file path. Implicitly enables debug mode."""
    strict_mcp_config: bool = False
    """Enforce strict validation of MCP server configurations."""
    context_1m: bool = False
    """Enable 1M token context window (Sonnet 4/4.5 only)."""
    prompt_suggestions: bool | None = None
    """Whether to  create prompt suggestions."""
    worktree: bool | str = False
    """Create a new git worktree for the session (with optional name)."""
    chrome: bool = False
    """Add the chrome-tools MCP server (-> Claude Code browser extension) to the agent."""

    def build_settings_value(self) -> str | None:
        """Build settings value, merging sandbox settings if provided.

        Returns the settings value as either:
        - A JSON string (if sandbox is provided or settings is JSON)
        - A file path (if only settings path is provided without sandbox)
        - None if neither settings nor sandbox is provided
        """
        import anyenv

        has_settings = self.settings is not None
        has_sandbox = self.sandbox is not None

        if not has_settings and not has_sandbox:
            return None

        # If only settings path and no sandbox, pass through as-is
        if has_settings and not has_sandbox:
            return self.settings

        # If we have sandbox settings, we need to merge into a JSON object
        settings_obj: dict[str, Any] = {}

        if has_settings:
            assert self.settings is not None
            settings_str = self.settings.strip()
            # Check if settings is a JSON string or a file path
            if settings_str.startswith("{") and settings_str.endswith("}"):
                settings_obj = anyenv.load_json(settings_str)
            else:
                settings_path = Path(settings_str)
                if settings_path.exists():
                    with settings_path.open(encoding="utf-8") as f:
                        settings_obj = json.load(f)
                else:
                    logger.warning("Settings file not found: %s", settings_path)

        # Merge sandbox settings
        if has_sandbox:
            assert self.sandbox is not None
            settings_obj["sandbox"] = self.sandbox.model_dump(by_alias=True, exclude_none=True)

        return anyenv.dump_json(settings_obj)

    def validate(self) -> None:
        """Validate option constraints.

        Raises:
            ValueError: If mutually exclusive options are set.
        """
        if self.can_use_tool and self.permission_prompt_tool_name:
            msg = (
                "can_use_tool callback cannot be used with permission_prompt_tool_name. "
                "Please use one or the other."
            )
            raise ValueError(msg)
