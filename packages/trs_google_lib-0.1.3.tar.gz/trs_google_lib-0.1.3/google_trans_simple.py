import httpx
import urllib.parse
from typing import Optional
from loguru import logger
import json

class GoogleTranslate:
    """
    Асинхронный клиент для быстрого перевода текста через Google Translate API (gtx).
    Поддерживает использование прокси.
    """
    def __init__(self, proxy: Optional[str] = None, timeout: float = 10.0):
        """
        :param proxy: URL прокси-сервиса, например, "http://user:pass@proxy.server:port". Если None, прокси не используется.
        :param timeout: Время ожидания ответа в секундах.
        """
        self.proxy = proxy
        self.timeout = timeout
        self.url = "https://translate.googleapis.com/translate_a/single"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                          "(KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        }

    async def translate(self, text: str, source_lang: str = "ru", target_lang: str = "en") -> str:
        """
        Переводит заданный текст с source_lang на target_lang.
        """
        params = {
            "client": "gtx",
            "sl": source_lang,
            "tl": target_lang,
            "dt": "t",
            "q": text,
        }

        logger.debug(f"GoogleTranslate: using proxy: {self.proxy}")

        # Передаём proxy в клиент
        async with httpx.AsyncClient(proxy=self.proxy, timeout=self.timeout) as client:
            response = await client.get(self.url, params=params, headers=self.headers)
            response.raise_for_status()
            
            try:
                # Ответ выглядит так: [[["Translated text","Original text",null,null,1]],null,"en",...]
                data = response.json()
                # Склеиваем все переведенные предложения
                translated_text = "".join([sentence[0] for sentence in data[0] if sentence[0]])
                return translated_text
            except (json.JSONDecodeError, IndexError, TypeError) as e:
                logger.error(f"Failed to parse translation response. Status: {response.status_code}, Body: {response.text[:200]}")
                raise Exception(f"Translation parsing error: {e}")

# Пример использования
if __name__ == "__main__":
    import asyncio

    async def main():
        translator = GoogleTranslate(proxy=None)  # Замените proxy на нужное значение, если требуется
        text = "Чуть чуть хреново поел еды. Много соли, как будто бомжа облизал. Чур не меня!"
        result = await translator.translate(text)
        print("Результат перевода:")
        print(result)

    asyncio.run(main())
