BOJ_HOST = 'https://www.acmicpc.net'
SOLVED_HOST = 'https://solved.ac'
SOLVED_V3_PROB = f'{SOLVED_HOST}/api/v3/search/problem'
STATUS_NONE = 0
STATUS_AC = 1
STATUS_WA = 2
