# to copy and execute in odooly inside the photovoltaic_mgmt_extended dir

import base64

with open('static/img/cross.png', 'rb') as img:
    image = base64.b64encode(img.read()).decode('utf8')

for plant in env['photovoltaic.power.station'].search([]):
    print(plant.name)
    if len(plant.image_ids) == 0:
        print(' adding images')
        plant.image_ids = [
            (0, 0, {
                'name': 'Aérea',
                'comments': 'Foto aérea de la planta en el que se indiquen sus principales componentes y accesos',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            (0, 0, {
                'name': 'Unifilar',
                'comments': 'Unifilar de la instalación',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            (0, 0, {
                'name': 'CGPM',
                'comments': 'Detalle del CGPM',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            (0, 0, {
                'name': 'Contador',
                'comments': 'Detalle del contador en el que se vea bien el S/N',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            (0, 0, {
                'name': 'Cuadro protecciones CC',
                'comments': 'Detalle cuadro protecciones CC',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            (0, 0, {
                'name': 'Cuadro protecciones CA',
                'comments': 'Detalle cuadro protecciones CA',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            (0, 0, {
                'name': 'Inversores',
                'comments': 'Detalle inversores',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            (0, 0, {
                'name': 'General',
                'comments': 'Foto general',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            (0, 0, {
                'name': 'Cuadro comunicaciones',
                'comments': 'Detalle cuadro de comunicaciones y sus equipos',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            (0, 0, {
                'name': 'Riesgos',
                'comments': 'Detalle riesgos y medios de protección instalados',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            (0, 0, {
                'name': 'Lucernarios',
                'comments': 'Fotos lucernarios (tapados o sin tapar)',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            })
        ]
