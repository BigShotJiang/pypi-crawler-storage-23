from odoo import models, fields

class PhotovoltaicDistributor(models.Model):
    _description = 'Photovoltaic power distributor'
    _name = 'photovoltaic.distributor'

    name = fields.Char()
    contact = fields.Many2one('res.partner')