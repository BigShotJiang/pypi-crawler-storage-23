from odoo import models, fields

class PhotovoltaicMarketRepresentative(models.Model):
    _description = 'Photovoltaic market representative'
    _name = 'photovoltaic.market_representative'

    name = fields.Char()
    contact = fields.Many2one('res.partner')