import logging
import base64
from odoo import models, fields, tools, api, _
from odoo.exceptions import ValidationError
from odoo.modules.module import get_resource_path

_logger = logging.getLogger(__name__)


class PhotovoltaicPowerStation(models.Model):
    _name = "photovoltaic.power.station"
    _inherit = ["photovoltaic.power.station", "mail.thread", "base_multi_image.owner"]

    tecnical_memory_link = fields.Char(string="Enlace memoria técnica")

    station_typology = fields.Many2one('photovoltaic.station.typology')

    eq_family_consumption = fields.Float(
        string='Consumo equivalente en familia',
        compute='_compute_eq_family_consumption',
        tracking=True)

    short_term_investment = fields.Boolean(string='Plant available for sort term investment')
    long_term_investment = fields.Boolean(string='Plant available for long term investment')

    stock_location = fields.Many2one('stock.location', domain=[('usage', '=', 'internal')])
    stock_quants = fields.Many2many('stock.quant', compute='_compute_stock_quant')

    owners = fields.One2many('photovoltaic.power.station.owner','station')
    lessors = fields.Many2many('photovoltaic.lessor')

    royal_decree = fields.Selection([
        ('RD_661_2007','RD 661/2007'),
        ('RD_1578_2008','RD 1578/ 2008'),
        ('RD_413_2014','RD 413/2014')
    ])
    quota = fields.Char(
        string='quota',
        tracking=True
    )
    RAIPRE_code = fields.Char(
        tracking=True
    )
    date = fields.Date() 
    
    RAIPRE_owner = fields.Char(
        tracking=True
    )
    remunerative_power = fields.Float(
        string='Remunerative power [Kw]',
        tracking=True
    )
    RIPRE_code = fields.Char(
        tracking=True
    )
    RIPRE_owner = fields.Char(
        tracking=True
    )
    typology_invoice = fields.Many2one('photovoltaic.power.station.it.code')
    connection_date = fields.Date()
    CIL_installation = fields.Char()
    CIL_aggregation = fields.Char()

    remunerative_power_ripre = fields.Float(
        string='Remunerative power [Kw]',
        digits=[1,2],
        tracking=True
    )
    stamp_date = fields.Date()
    CIE_owner = fields.Char(
        tracking=True
    )
    installation_company = fields.Many2one(
        'res.partner',
        domain=[('supplier_rank','>', 1)]
    )
    CIE_power = fields.Float(
        string='CIE power [Kw]',
        digits=[1,2],
        tracking=True
    )
    file_number = fields.Char(  
        tracking=True
    )
    connection_point_date = fields.Date()
    assigned_power = fields.Float(
        string="Assigned power [MW]",
        digits=[1,4],
        tracking=True
    )
    connection_point_location = fields.Text()
    distributor = fields.Many2one('photovoltaic.distributor', no_quick_create=True)
    distributor_contract_number = fields.Char(
        tracking=True
    )
    current_market_representative = fields.Many2one('photovoltaic.market_representative')
    market_representative_contract_number = fields.Char(
        tracking=True
    )

    farm_type = fields.Many2many('photovoltaic.farm.type')
    access_notification = fields.Boolean()
    notification_format = fields.Many2many('notification.format')
    contact_person = fields.Many2one('res.partner')
    contact_data_email = fields.Char(related='contact_person.email', store=True)
    contact_data_phone = fields.Char(related='contact_person.phone', store=True)
    access_schedule = fields.Char()
    farm_alarm = fields.Boolean()
    access_instructions = fields.Text()
    access_point = fields.Char()
    maintenance_deck_type = fields.Many2many('maintenance.deck.type')
    deck_access_notification = fields.Boolean()
    CGPM_location = fields.Char()
    key_type = fields.Many2many('photovoltaic.key.type')
    CGPM_identification = fields.Binary()
    inversors_location = fields.Char()
    CC_panel = fields.Char()
    CA_panel = fields.Char()
    CT = fields.Boolean()
    CT_comments = fields.Char()
    medium_voltage_line= fields.Boolean()

    photovoltaic_lifting_height = fields.Float(
        string='Lifting height [m]'
    )
    photovoltaic_lifting_type = fields.Many2many('photovoltaic.lifting.type')
    platform_entity = fields.Many2one('res.partner')
    deck_type = fields.Selection([
        ('passable', 'Passable'),
        ('not_passable','Not passable')
    ])
    configuration = fields.Selection([
        ('flat', 'Flat'),
        ('one_pitched', 'One-pitched'),
        ('multi_pitched', 'Multi-pitched')
    ])
    skylights = fields.Boolean()
    lifelines = fields.Boolean()
    handrails = fields.Boolean()
    other_protections = fields.Char(
        string='Other necessary protections',
        tracking=True)
    comments = fields.Char(
        string='Comments',
        tracking=True)
    
    consumption_type = fields.Selection([
        ('individualized', 'Individualized'),
        ('totalizer', 'Totalizer')
    ])
    consumption_contract_state = fields.Selection([
        ('yes', 'Yes'),
        ('no', 'No'),
        ('in_process', 'In process')
    ])
    CUPS = fields.Char()
    meter_number = fields.Char()
    trading_company_contract_number = fields.Char()
    consumption_contract_type = fields.Selection([
        ('2.0TD', '2.0TD'),
        ('2.1TD', '2.1TD'),
        ('3.0TD', '3.0TD'),
        ('6.0TD', '6.0TD')
    ])
    hired_power = fields.One2many('photovoltaic.hired.power', 'station')
    other_consumption_contracts = fields.One2many('photovoltaic.consumption.contract', 'station')
    intrussion_protection_system_type = fields.Many2many('photovoltaic.ips.type')
    intrussion_protection_system_state = fields.Many2many('photovoltaic.ips.state')
    intrussion_protection_system_provider = fields.Many2one('res.partner')
    ips_provider_phone = fields.Char(related='intrussion_protection_system_provider.phone', store=True)
    ips_provider_email = fields.Char(related='intrussion_protection_system_provider.email', store=True)
    fire_protection_system_type = fields.Many2many('photovoltaic.fps.type')
    fire_protection_system_state = fields.Many2many('photovoltaic.fps.state')
    fire_protection_system_provider = fields.Many2one('res.partner')
    fps_provider_phone = fields.Char(related='fire_protection_system_provider.phone', store=True)
    fps_provider_email = fields.Char(related='fire_protection_system_provider.email', store=True)
    necessary_sprouts = fields.Boolean()
    sprouts_provider = fields.Many2one('res.partner')
    sprouts_provider_phone = fields.Char(related='sprouts_provider.phone', store=True)
    sprouts_provider_email = fields.Char(related='sprouts_provider.email', store=True)
    full_maintenance = fields.Boolean()
    BT_provider = fields.Many2one('res.partner')
    BT_description = fields.Char()
    BT_contract = fields.Char()
    AT_provider = fields.Many2one('res.partner')
    AT_description = fields.Char()
    AT_contract = fields.Char()

    @api.model
    def create(self, vals):
        record = super().create(vals)

        with open(get_resource_path('photovoltaic_mgmt_extended', 'static/img/cross.png'), 'rb') as img:
            image = base64.b64encode(img.read())

        record.image_ids = [
            fields.Command.create({
                'name': 'Aérea',
                'comments': 'Foto aérea de la planta en el que se indiquen sus principales componentes y accesos',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            fields.Command.create({
                'name': 'Unifilar',
                'comments': 'Unifilar de la instalación',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            fields.Command.create({
                'name': 'CGPM',
                'comments': 'Detalle del CGPM',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            fields.Command.create({
                'name': 'Contador',
                'comments': 'Detalle del contador en el que se vea bien el S/N',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            fields.Command.create({
                'name': 'Cuadro protecciones CC',
                'comments': 'Detalle cuadro protecciones CC',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            fields.Command.create({
                'name': 'Cuadro protecciones CA',
                'comments': 'Detalle cuadro protecciones CA',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            fields.Command.create({
                'name': 'Inversores',
                'comments': 'Detalle inversores',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            fields.Command.create({
                'name': 'General',
                'comments': 'Foto general',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            fields.Command.create({
                'name': 'Cuadro comunicaciones',
                'comments': 'Detalle cuadro de comunicaciones y sus equipos',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            fields.Command.create({
                'name': 'Riesgos',
                'comments': 'Detalle riesgos y medios de protección instalados',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            }),
            fields.Command.create({
                'name': 'Lucernarios',
                'comments': 'Fotos lucernarios (tapados o sin tapar)',
                'image_1920': image,
                'owner_model': 'photovoltaic.power.station',
            })
        ]

        return record

    def _compute_eq_family_consumption(self):
        for record in self:
            record.eq_family_consumption = sum(record.photovoltaic_power_energy_ids.mapped('eq_family_consum'))

    def _compute_stock_quant(self):
        for record in self:
            if record.stock_location:
                record.stock_quants = self.env['stock.quant'].search([
                    ('location_id', '=', record.stock_location.id)
                ])
            else:
                record.stock_quants = []

    def toggle_short_term(self):
        self.short_term_investment = not self.short_term_investment

    def toggle_long_term(self):
        self.long_term_investment = not self.long_term_investment

    @tools.ormcache()
    def _compute_installed_power(self):
        plants = self.env['photovoltaic.power.station'].sudo().search([('name','!=','SDL')])
        return round(sum(plants.mapped('peak_power')) / 1000, 2)

    @tools.ormcache()
    def _compute_plants_with_reservation(self):
        plants_with_reservation = self.env['photovoltaic.power.station'].sudo().search(
            [('reservation', '>=', 0)])
        return len(plants_with_reservation)

    @api.constrains('short_term_investment', 'long_term_investment')
    def _check_start_date(self):
        for record in self:
            if ((record.short_term_investment or record.long_term_investment) and not record.start_date):
                raise ValidationError(_('A power station can\'t be open for investment if it has no start date'))
    
    @api.onchange('remunerative_power')
    def _onchange_remunerative_power(self):
        for record in self:
            if record.remunerative_power_ripre == 0:
                record.remunerative_power_ripre = record.remunerative_power 
    

    @api.onchange('owners')
    def _onchange_owners(self):
        for record in self:
            for owner in record.owners:
                if owner.original == True:
                    if record.RIPRE_owner == False:
                        record.RIPRE_owner = owner.owner.translated_display_name
                    if record.RAIPRE_owner == False:
                        record.RAIPRE_owner = owner.owner.translated_display_name
                    if record.CIE_owner == False:
                        record.CIE_owner = owner.owner.translated_display_name   
    
    @api.onchange('stamp_date')
    def _onchange_stamp_date(self):
        for record in self:
            if record.connection_date:
                return
            else:
                record.connection_date = record.stamp_date

    @api.constrains('owners')
    def _check_unique_ownership(self):
        for record in self:
            original_found = False
            current_found = False
            for owner in record.owners:
                if owner.original and not original_found:
                    original_found = True
                elif owner.original:
                    raise ValidationError("There can only be one original owner")
                if owner.current and not current_found:
                    current_found = True
                elif owner.current:
                    raise ValidationError("There can only be one current owner")