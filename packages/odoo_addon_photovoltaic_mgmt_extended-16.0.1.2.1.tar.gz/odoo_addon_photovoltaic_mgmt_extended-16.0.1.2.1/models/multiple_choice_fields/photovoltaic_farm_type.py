from odoo import fields, models

class PhotovoltaicFarmType(models.Model):
    _name='photovoltaic.farm.type'

    name=fields.Char()