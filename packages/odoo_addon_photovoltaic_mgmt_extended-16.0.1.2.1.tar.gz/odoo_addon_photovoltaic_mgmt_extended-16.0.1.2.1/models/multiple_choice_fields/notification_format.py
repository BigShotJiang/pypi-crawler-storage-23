from odoo import fields, models

class NotificationFormat(models.Model):
    _name='notification.format'

    name=fields.Char()