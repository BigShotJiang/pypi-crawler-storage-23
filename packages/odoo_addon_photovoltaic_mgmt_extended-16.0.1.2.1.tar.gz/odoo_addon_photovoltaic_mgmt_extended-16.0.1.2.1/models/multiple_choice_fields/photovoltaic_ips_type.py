from odoo import fields, models

# Photovoltaic power station intrussion protection system (IPS) type
class PhotovoltaicIpsType(models.Model):
    _name='photovoltaic.ips.type'

    name=fields.Char()