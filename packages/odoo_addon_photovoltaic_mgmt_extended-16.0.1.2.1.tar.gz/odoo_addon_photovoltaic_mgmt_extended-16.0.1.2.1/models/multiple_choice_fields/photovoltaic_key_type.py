from odoo import fields, models

class PhotovoltaicKeyType(models.Model):
    _name='photovoltaic.key.type'

    name=fields.Char()