from odoo import fields, models

# Photovoltaic power station fire protection system (FPS) state
class PhotovoltaicFpsState(models.Model):
    _name='photovoltaic.fps.state'

    name=fields.Char()