Para instalar este módulo, es necesario el módulo *account_tax_balance*,
disponible en:

<https://github.com/OCA/account-financial-reporting>
