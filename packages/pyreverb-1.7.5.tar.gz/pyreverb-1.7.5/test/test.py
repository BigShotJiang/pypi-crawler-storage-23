class A:
    def __init__(self):
        self.name_of_var = 1
        self.a = 1
        self.b = 2
        self.c = 3
        self.d = 4
        self.e = 5
        print(dict(self.__dict__.items()))


a = A()
d = {"A": 0, "B": 1, "C":2}
for key, arg in dict(zip(list(a.__dict__.keys())[:2],
                                 list(a.__dict__.values())[:2])).items():
    print(key, arg)

print("OK")







print(dict(zip(list(d.values())[:1], list(d.keys())[:1])))
