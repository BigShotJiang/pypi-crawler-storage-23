# Nothing hihi but you can follow my twitch chanel! https://twitch.tv/LeLaboTTV <3
__version__ = "1.6.0"
