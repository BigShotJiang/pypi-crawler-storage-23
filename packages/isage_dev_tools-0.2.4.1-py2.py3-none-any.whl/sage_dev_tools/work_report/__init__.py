"""work_report module for sage-dev-tools."""
