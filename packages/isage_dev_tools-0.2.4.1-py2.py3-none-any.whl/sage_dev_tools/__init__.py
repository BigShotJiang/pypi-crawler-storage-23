"""SAGE Dev Tools - Development utilities for SAGE framework ecosystem."""

__version__ = "0.1.0.0"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"

from sage_dev_tools.cli.main import cli

__all__ = ["cli", "__version__"]
