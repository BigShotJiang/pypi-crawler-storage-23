"""Version information for sage-dev-tools."""

__version__ = "0.2.4.1"
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
