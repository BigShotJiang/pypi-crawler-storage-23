"""CLI module for sage-dev-tools."""

from sage_dev_tools.cli.main import cli

__all__ = ["cli"]
