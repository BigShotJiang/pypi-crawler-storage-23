from mcp.server.fastmcp import FastMCP

mcp = FastMCP("file-size")

UNITS = ["B", "KB", "MB", "GB", "TB", "PB"]

@mcp.tool()
def convert_size(size: float, from_unit: str = "B", to_unit: str = "MB", binary: bool = True) -> str:
    """文件大小单位互转（如 B 换算成 GB）。binary=True 表示 1024 进制，否则 1000 进制。"""
    try:
        fr = from_unit.upper().strip()
        to = to_unit.upper().strip()
        
        idx_from = UNITS.index(fr)
        idx_to = UNITS.index(to)
        
        base = 1024.0 if binary else 1000.0
        
        # 将 from_unit 统一转成 Bytes
        bytes_val = size * (base ** idx_from)
        
        # Bytes 转目标单位
        target_val = bytes_val / (base ** idx_to)
        
        return f"{size} {fr} = {target_val:.4f} {to}"
    except ValueError:
        return f"不支持的单位。支持列表: {', '.join(UNITS)}"
    except Exception as e:
        return f"转换失败: {e}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
