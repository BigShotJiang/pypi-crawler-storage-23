# mcpzoo-file-size

> 大小转换 — 文件大小单位互转

## Installation

```bash
uvx mcpzoo-file-size
```

## uvx JSON

```json
{
  "mcpServers": {
    "file-size": {
      "args": ["mcpzoo-file-size"],
      "command": "uvx"
    }
  }
}
```
