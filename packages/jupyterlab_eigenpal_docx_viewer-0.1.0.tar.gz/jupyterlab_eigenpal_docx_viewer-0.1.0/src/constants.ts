export const NS = "jupyterlab-eigenpal-docx-viewer";

export const PLUGIN_ID = `${NS}:plugin`;
export const PLUGIN_DESC = "Preview .docx files directly in JupyterLab.";

export const MIME_TYPE =
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
export const FILE_TYPE = "Microsoft Word (OpenXML)";
export const FILE_EXTENSION = ".docx";
export const CLASS_NAME = "mimerenderer-docx";
export const FILE_FORMAT = "base64";
