import type { DocxInput } from "@eigenpal/docx-js-editor";
import { DocxEditor } from "@eigenpal/docx-js-editor";
import type { IRenderMime } from "@jupyterlab/rendermime-interfaces";
import { ReactWidget } from "@jupyterlab/ui-components";
import React from "react";

import { CLASS_NAME } from "../constants";

interface Props {
  buffer: DocxInput | null;
}

function ViewerComponent(props: Props) {
  return (
    <DocxEditor
      documentBuffer={props.buffer}
      readOnly={true}
      showToolbar={false}
      showVariablePanel={false}
      showZoomControl={false}
      showPageNumbers={false}
      enablePageNavigation={false}
      showRuler={false}
    />
  );
}

export class ViewerWidget extends ReactWidget {
  constructor(options: IRenderMime.IRendererOptions) {
    super();

    this._mimeType = options.mimeType;
    this.addClass(CLASS_NAME);
  }

  renderModel(model: IRenderMime.IMimeModel): Promise<void> {
    const base64Data = model.data[this._mimeType] as string;
    this._buffer = Uint8Array.from(atob(base64Data), (c) => c.charCodeAt(0));

    this.update();

    return Promise.resolve();
  }

  render() {
    return <ViewerComponent buffer={this._buffer} />;
  }

  private _mimeType: string;
  private _buffer: DocxInput | null = null;
}
