import type { IRenderMime } from "@jupyterlab/rendermime-interfaces";

import docsIcon from "../style/docs.svg";
import {
  FILE_EXTENSION,
  FILE_FORMAT,
  FILE_TYPE,
  MIME_TYPE,
  NS,
  PLUGIN_DESC,
  PLUGIN_ID,
} from "./constants";
import { ViewerWidget } from "./widgets/viewer";

export const rendererFactory: IRenderMime.IRendererFactory = {
  safe: true,
  mimeTypes: [MIME_TYPE],
  createRenderer: (options) => new ViewerWidget(options),
};

const extension: IRenderMime.IExtension = {
  id: PLUGIN_ID,
  description: PLUGIN_DESC,
  rendererFactory,
  rank: 100,
  dataType: "string",
  fileTypes: [
    {
      name: FILE_TYPE,
      mimeTypes: [MIME_TYPE],
      extensions: [FILE_EXTENSION],
      fileFormat: FILE_FORMAT,
      icon: {
        name: `${NS}:docx`,
        svgstr: docsIcon,
      },
    },
  ],
  documentWidgetFactoryOptions: {
    name: NS,
    primaryFileType: FILE_TYPE,
    fileTypes: [FILE_TYPE],
    defaultFor: [FILE_TYPE],
    modelName: FILE_FORMAT,
  },
};

export default extension;
