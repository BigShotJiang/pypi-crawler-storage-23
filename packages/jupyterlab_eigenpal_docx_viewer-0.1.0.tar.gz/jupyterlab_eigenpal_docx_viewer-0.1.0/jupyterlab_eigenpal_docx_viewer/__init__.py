from typing import TypedDict

from ._version import __version__


class LabExt(TypedDict):
    """Configuration for a prebuilt JupyterLab extension."""

    src: str
    dest: str


# https://github.com/jupyterlab/jupyterlab/blob/v4.3.2/jupyterlab/federated_labextensions.py#L400
# https://github.com/jupyterlab/jupyterlab/blob/v4.3.2/jupyterlab/federated_labextensions.py#L168
def _jupyter_labextension_paths() -> list[LabExt]:
    return [{"src": "labextension", "dest": "jupyterlab-eigenpal-docx-viewer"}]
