"""Custom exceptions for Azure discovery."""


class InvalidTargetError(ValueError):
    """Raised when a provided target identifier is malformed."""


class AzureClientError(RuntimeError):
    """Raised when Azure SDK clients report a fatal error."""


class VisualizationError(RuntimeError):
    """Raised when graph generation fails."""
