"""Data models for authentication."""

from typing import List, Optional
from pydantic import BaseModel, Field


class UserContext(BaseModel):
    """Authenticated user context."""
    
    id: str = Field(..., description="Unique user identifier")
    email: Optional[str] = Field(None, description="User email address")
    name: Optional[str] = Field(None, description="Display name")
    roles: List[str] = Field(default_factory=list, description="Assigned roles")
    scopes: List[str] = Field(default_factory=list, description="Granted scopes/permissions")
    tenant_id: Optional[str] = Field(None, description="Azure AD tenant ID")
    source: str = Field(..., description="Authentication source (azure_ad, api_key)")
    
    class Config:
        json_schema_extra = {
            "example": {
                "id": "user@example.com",
                "email": "user@example.com",
                "name": "John Doe",
                "roles": ["Discovery.Reader"],
                "scopes": ["Discovery.Read"],
                "tenant_id": "12345678-1234-1234-1234-123456789012",
                "source": "azure_ad",
            }
        }


class AuthenticationError(Exception):
    """Raised when authentication fails."""
    pass
