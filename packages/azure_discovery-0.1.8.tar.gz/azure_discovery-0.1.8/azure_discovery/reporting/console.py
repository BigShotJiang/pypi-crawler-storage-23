"""Console reporting utilities."""

from __future__ import annotations

from ..adt_types import AzureDiscoveryResponse
from ..utils.logging import get_logger

LOGGER = get_logger()


def emit_console_summary(response: AzureDiscoveryResponse) -> None:
    """Log a concise discovery summary."""

    if not response:
        LOGGER.warning("Discovery response missing")
        return

    context: dict = {
        "tenant_id": response.tenant_id,
        "subscriptions": response.discovered_subscriptions,
        "nodes": response.total_resources,
        "relationships": len(response.relationships),
        "report": response.html_report_path,
    }

    if response.metrics:
        context["merge_metrics"] = response.metrics.merge.model_dump()
        context["phases"] = [p.model_dump() for p in response.metrics.phases]

    LOGGER.info(
        "Discovery summary",
        extra={"context": context},
    )
