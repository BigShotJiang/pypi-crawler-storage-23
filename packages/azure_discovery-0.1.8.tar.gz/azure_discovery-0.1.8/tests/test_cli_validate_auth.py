"""CLI validate-auth tests."""

from typer.testing import CliRunner

from azure_discovery.cli import cli


def test_validate_auth_exits_zero(monkeypatch):
    # Patch at the CLI module level where the function is actually bound
    monkeypatch.setattr(
        "azure_discovery.cli.validate_auth",
        lambda request, probe_connectivity=False: {
            "ok": True,
            "environment": "azure_public",
            "scopes": [],
            "probe_connectivity": probe_connectivity,
        },
    )

    runner = CliRunner()

    # Try with subcommand first, fall back to inlined (typer single-command behavior)
    result = runner.invoke(
        cli,
        [
            "discover",
            "--tenant-id",
            "tenant-1",
            "--validate-auth",
        ],
    )
    if result.exit_code != 0:
        result = runner.invoke(
            cli,
            [
                "--tenant-id",
                "tenant-1",
                "--validate-auth",
            ],
        )
    assert result.exit_code == 0
    assert "\"ok\": true" in result.stdout.lower()
