"""
Tests for the MCP server (scripts/mcp_server.py).

Covers WebviewSession lifecycle, file I/O, port finding, and MCP tool logic.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path

import pytest

# Ensure scripts/ is importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from mcp_server import MAX_MERGE_DEPTH, WebviewSession, _deep_merge, _expand_preset


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def work_dir(tmp_path):
    """Temporary working directory for a test session."""
    return tmp_path


@pytest.fixture
def session(work_dir):
    """WebviewSession pointed at a temp directory (browser disabled for tests)."""
    return WebviewSession(work_dir=work_dir, open_browser=False)


def inject_action(data_dir: Path, action_id: str = "approve", action_type: str = "approve", value=True):
    """Write a fake action to actions.json (simulates a user click in the browser)."""
    actions = {
        "version": 1,
        "actions": [
            {
                "id": "test-uuid",
                "action_id": action_id,
                "type": action_type,
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "value": value,
            }
        ],
    }
    actions_path = data_dir / "actions.json"
    tmp = actions_path.with_suffix(".tmp")
    tmp.write_text(json.dumps(actions, indent=2))
    tmp.replace(actions_path)


# ---------------------------------------------------------------------------
# WebviewSession — path resolution
# ---------------------------------------------------------------------------


class TestSessionPaths:
    def test_data_dir_under_work_dir(self, session, work_dir):
        assert session.data_dir == work_dir / ".opencode" / "webview"

    def test_default_ports(self, session):
        assert session.http_port == 18420
        assert session.ws_port == 18421

    def test_not_started_initially(self, session):
        assert not session._started
        assert not session.is_alive()


# ---------------------------------------------------------------------------
# Asset discovery
# ---------------------------------------------------------------------------


class TestAssetDiscovery:
    def test_find_assets_dir(self, session):
        assets = session._find_assets_dir()
        assert assets.is_dir()
        assert (assets / "sdk" / "openwebgoggles-sdk.js").is_file()
        assert (assets / "apps" / "dynamic" / "app.js").is_file()


# ---------------------------------------------------------------------------
# App copy
# ---------------------------------------------------------------------------


class TestAppCopy:
    def test_copy_dynamic_app(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        (session.data_dir / "apps").mkdir(exist_ok=True)

        session._copy_app("dynamic")

        app_dir = session.data_dir / "apps" / "dynamic"
        assert app_dir.is_dir()
        assert (app_dir / "index.html").is_file()
        assert (app_dir / "app.js").is_file()
        assert (app_dir / "openwebgoggles-sdk.js").is_file()

    def test_unknown_app_raises(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        (session.data_dir / "apps").mkdir(exist_ok=True)

        with pytest.raises(FileNotFoundError, match="not found"):
            session._copy_app("nonexistent-app-xyz")


# ---------------------------------------------------------------------------
# Manifest generation
# ---------------------------------------------------------------------------


class TestManifest:
    def test_manifest_structure(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session.session_id = "test-session-id"
        session.http_port = 18420
        session.ws_port = 18421

        session._write_manifest("dynamic")

        manifest = json.loads((session.data_dir / "manifest.json").read_text())
        assert manifest["version"] == "1.0"
        assert manifest["app"]["name"] == "dynamic"
        assert manifest["session"]["id"] == "test-session-id"
        assert manifest["server"]["http_port"] == 18420
        assert manifest["server"]["ws_port"] == 18421

    def test_manifest_token_redacted(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session.session_token = "supersecret"

        session._write_manifest("dynamic")

        manifest = json.loads((session.data_dir / "manifest.json").read_text())
        assert manifest["session"]["token"] == "REDACTED"
        assert "supersecret" not in (session.data_dir / "manifest.json").read_text()


# ---------------------------------------------------------------------------
# Data contract initialization
# ---------------------------------------------------------------------------


class TestDataContract:
    def test_init_creates_state_and_actions(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)

        session._init_data_contract()

        state = json.loads((session.data_dir / "state.json").read_text())
        assert state["version"] == 0
        assert state["status"] == "initializing"
        assert "updated_at" in state

        actions = json.loads((session.data_dir / "actions.json").read_text())
        assert actions["version"] == 0
        assert actions["actions"] == []

    def test_state_version_resets_on_init(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session._state_version = 42

        session._init_data_contract()

        assert session._state_version == 0


# ---------------------------------------------------------------------------
# State write / read
# ---------------------------------------------------------------------------


class TestStateIO:
    def test_write_state_creates_valid_json(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session._init_data_contract()

        session.write_state({"title": "Test", "data": {}})

        state = json.loads((session.data_dir / "state.json").read_text())
        assert state["title"] == "Test"
        assert state["version"] == 1
        assert "updated_at" in state
        assert state["status"] == "waiting_input"

    def test_write_state_increments_version(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session._init_data_contract()

        session.write_state({"title": "V1"})
        session.write_state({"title": "V2"})
        session.write_state({"title": "V3"})

        state = json.loads((session.data_dir / "state.json").read_text())
        assert state["version"] == 3
        assert state["title"] == "V3"

    def test_write_state_preserves_explicit_status(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session._init_data_contract()

        session.write_state({"title": "Test", "status": "pending_review"})

        state = json.loads((session.data_dir / "state.json").read_text())
        assert state["status"] == "pending_review"


# ---------------------------------------------------------------------------
# Actions read / clear
# ---------------------------------------------------------------------------


class TestActionsIO:
    def test_read_actions_empty(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session._init_data_contract()

        actions = session.read_actions()
        assert actions["actions"] == []

    def test_read_actions_after_inject(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session._init_data_contract()

        inject_action(session.data_dir, "approve", "approve", True)

        actions = session.read_actions()
        assert len(actions["actions"]) == 1
        assert actions["actions"][0]["action_id"] == "approve"

    def test_clear_actions(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session._init_data_contract()

        inject_action(session.data_dir, "approve", "approve", True)
        session.clear_actions()

        actions = session.read_actions()
        assert actions["actions"] == []

    def test_read_actions_no_file(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        actions = session.read_actions()
        assert actions == {"version": 0, "actions": []}


# ---------------------------------------------------------------------------
# Wait for action (async polling)
# ---------------------------------------------------------------------------


class TestWaitForAction:
    async def test_returns_on_action(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session._init_data_contract()

        # Inject action after a short delay
        async def delayed_inject():
            await asyncio.sleep(0.3)
            inject_action(session.data_dir, "submit", "submit", {"name": "test"})

        task = asyncio.create_task(delayed_inject())
        result = await session.wait_for_action(timeout=5.0)
        await task

        assert result is not None
        assert len(result["actions"]) == 1
        assert result["actions"][0]["action_id"] == "submit"

    async def test_returns_none_on_timeout(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session._init_data_contract()

        result = await session.wait_for_action(timeout=0.5)
        assert result is None


# ---------------------------------------------------------------------------
# Port finding
# ---------------------------------------------------------------------------


class TestPortFinding:
    def test_finds_ports(self, session):
        http_port, ws_port = session._find_free_ports()
        assert 1 <= http_port <= 65535
        assert ws_port == http_port + 1

    def test_port_available_check(self):
        # Port 0 is special but a high random port should be available
        import socket

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
        # Port is in use
        assert not WebviewSession._port_available(port)
        s.close()
        # Port should now be free
        assert WebviewSession._port_available(port)


# ---------------------------------------------------------------------------
# File permissions
# ---------------------------------------------------------------------------


class TestPermissions:
    @pytest.mark.skipif(sys.platform == "win32", reason="Unix permissions only")
    def test_set_permissions(self, session):
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session._init_data_contract()
        session._write_manifest("dynamic")

        session._set_permissions()

        assert oct(session.data_dir.stat().st_mode & 0o777) == oct(0o700)
        assert oct((session.data_dir / "manifest.json").stat().st_mode & 0o777) == oct(0o600)
        assert oct((session.data_dir / "state.json").stat().st_mode & 0o777) == oct(0o600)


# ---------------------------------------------------------------------------
# Chrome detection
# ---------------------------------------------------------------------------


class TestChromeDetection:
    def test_find_chrome_returns_string_or_none(self):
        result = WebviewSession._find_chrome()
        assert result is None or isinstance(result, str)


# ---------------------------------------------------------------------------
# Integration: full server lifecycle (requires subprocess)
# ---------------------------------------------------------------------------


@pytest.mark.slow
class TestServerLifecycle:
    async def test_ensure_started_and_health(self, session):
        """Start the server, verify health, and clean up."""
        try:
            await session.ensure_started("dynamic")

            assert session._started
            assert session.is_alive()
            assert session.http_port > 0

            # Verify health endpoint responds
            import urllib.request

            with urllib.request.urlopen(f"http://127.0.0.1:{session.http_port}/_health", timeout=5) as resp:
                assert resp.status == 200
                data = json.loads(resp.read())
                assert data["status"] == "ok"
        finally:
            await session.close()
            assert not session.is_alive()

    async def test_write_state_reflected_via_api(self, session):
        """Write state via file, read back via HTTP API."""
        try:
            await session.ensure_started("dynamic")

            session.write_state(
                {
                    "title": "Integration Test",
                    "message": "Hello from test",
                    "data": {},
                    "actions_requested": [],
                }
            )

            # Give the file watcher time to pick it up
            await asyncio.sleep(1.0)

            import urllib.request

            req = urllib.request.Request(
                f"http://127.0.0.1:{session.http_port}/_api/state",
                headers={"Authorization": f"Bearer {session.session_token}"},
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                state = json.loads(resp.read())
                assert state["title"] == "Integration Test"
        finally:
            await session.close()

    async def test_ask_flow_with_injected_action(self, session):
        """Simulate the webview_ask flow: write state, inject action, read back."""
        try:
            await session.ensure_started("dynamic")

            session.clear_actions()
            session.write_state(
                {
                    "title": "Review",
                    "message": "Please review",
                    "data": {},
                    "actions_requested": [
                        {"id": "approve", "label": "Approve", "type": "approve"},
                    ],
                }
            )

            # Inject an action after a delay (simulating user click)
            async def delayed_action():
                await asyncio.sleep(0.5)
                inject_action(session.data_dir, "approve", "approve", True)

            task = asyncio.create_task(delayed_action())
            result = await session.wait_for_action(timeout=5.0)
            await task

            assert result is not None
            assert result["actions"][0]["action_id"] == "approve"
        finally:
            await session.close()

    async def test_close_is_idempotent(self, session):
        """Closing twice should not raise."""
        await session.ensure_started("dynamic")
        await session.close()
        await session.close()  # Should not raise


# ---------------------------------------------------------------------------
# Version detection & auto-reload
# ---------------------------------------------------------------------------


class TestVersionDetection:
    """Test the installed version detection utilities."""

    def test_get_installed_version_info_returns_tuple(self):
        """Should return a (version, path) tuple."""
        from mcp_server import _get_installed_version_info

        version, path = _get_installed_version_info()
        # Package may or may not be installed in test env
        assert isinstance(version, str)
        assert path is None or isinstance(path, Path)

    def test_read_version_fresh_returns_string(self):
        """Should return a version string (or 'unknown')."""
        from mcp_server import _read_version_fresh

        version = _read_version_fresh()
        assert isinstance(version, str)


class TestTrackToolCall:
    """Test the _track_tool_call decorator for in-flight call tracking."""

    async def test_increments_and_decrements(self):
        """Counter should be 0 -> 1 -> 0 around a tool call."""
        import mcp_server

        original = mcp_server._active_tool_calls
        mcp_server._active_tool_calls = 0
        mcp_server._reload_pending = False

        @mcp_server._track_tool_call
        async def dummy():
            assert mcp_server._active_tool_calls == 1
            return {"ok": True}

        result = await dummy()
        assert result == {"ok": True}
        assert mcp_server._active_tool_calls == 0
        mcp_server._active_tool_calls = original

    async def test_decrements_on_exception(self):
        """Counter should decrement even if the tool raises."""
        import mcp_server

        mcp_server._active_tool_calls = 0
        mcp_server._reload_pending = False

        @mcp_server._track_tool_call
        async def boom():
            raise ValueError("test error")

        with pytest.raises(ValueError, match="test error"):
            await boom()
        assert mcp_server._active_tool_calls == 0

    async def test_rejects_during_reload(self):
        """Should return error dict when _reload_pending is True."""
        import mcp_server

        mcp_server._reload_pending = True

        @mcp_server._track_tool_call
        async def dummy():
            return {"ok": True}

        result = await dummy()
        assert "error" in result
        assert "reloading" in result["error"].lower()
        mcp_server._reload_pending = False


class TestExecReload:
    """Test the _exec_reload function constructs correct arguments."""

    def test_exec_constructs_correct_args(self, monkeypatch):
        """Should call os.execv with sys.executable and sys.argv."""
        from mcp_server import _exec_reload

        captured = {}

        def fake_execv(executable, args):
            captured["executable"] = executable
            captured["args"] = args
            raise SystemExit(0)  # Prevent actual exec

        monkeypatch.setattr(os, "execv", fake_execv)

        with pytest.raises(SystemExit):
            _exec_reload()

        assert captured["executable"] == sys.executable
        assert captured["args"][0] == sys.executable


class TestVersionMonitor:
    """Test the _version_monitor background task."""

    async def test_exits_when_not_installed(self, monkeypatch):
        """Monitor should return immediately when package is not pip-installed."""
        import mcp_server

        monkeypatch.setattr(mcp_server, "_get_installed_version_info", lambda: ("unknown", None))
        # Should return without error (not hang)
        await mcp_server._version_monitor()


# ---------------------------------------------------------------------------
# App name security — path traversal prevention
# ---------------------------------------------------------------------------


class TestAppNameSecurity:
    """App names must not be usable as path traversal vectors.

    _copy_app builds a candidate list from known directories; names containing
    '..' or absolute paths simply won't match any candidate and raise
    FileNotFoundError rather than escaping the assets directory.
    """

    def test_dotdot_app_name_raises_not_found(self, session):
        """'../../../etc' must not traverse out of assets dir."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        (session.data_dir / "apps").mkdir(exist_ok=True)

        with pytest.raises(FileNotFoundError, match="not found"):
            session._copy_app("../../../etc")

    def test_absolute_path_app_name_raises_not_found(self, session):
        """/tmp must be rejected immediately — absolute paths bypass candidate allowlist.

        Pathlib resolves Path(base) / '/abs' to '/abs' on Unix, so without this guard an
        absolute app_name would silently escape the assets directory.
        """
        session.data_dir.mkdir(parents=True, exist_ok=True)
        (session.data_dir / "apps").mkdir(exist_ok=True)

        with pytest.raises(FileNotFoundError, match="not found"):
            session._copy_app("/tmp")

    def test_null_byte_app_name_raises_not_found(self, session):
        """Null-byte injection in app name must not bypass path checks."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        (session.data_dir / "apps").mkdir(exist_ok=True)

        with pytest.raises((FileNotFoundError, ValueError)):
            session._copy_app("dynamic\x00../../etc")

    def test_valid_app_name_succeeds(self, session):
        """A legitimate app name (dynamic) must copy successfully."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        (session.data_dir / "apps").mkdir(exist_ok=True)

        session._copy_app("dynamic")  # Should not raise
        assert (session.data_dir / "apps" / "dynamic" / "index.html").is_file()


class TestMarkdownAssetCopy:
    """Verify that markdown libraries are copied alongside the SDK."""

    def test_marked_js_copied(self, session):
        """marked.min.js must be copied into the app directory."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        (session.data_dir / "apps").mkdir(exist_ok=True)

        session._copy_app("dynamic")

        app_dir = session.data_dir / "apps" / "dynamic"
        assert (app_dir / "marked.min.js").is_file(), "marked.min.js not found in deployed app"

    def test_purify_js_copied(self, session):
        """purify.min.js (DOMPurify) must be copied into the app directory."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        (session.data_dir / "apps").mkdir(exist_ok=True)

        session._copy_app("dynamic")

        app_dir = session.data_dir / "apps" / "dynamic"
        assert (app_dir / "purify.min.js").is_file(), "purify.min.js not found in deployed app"

    def test_all_sdk_js_files_copied(self, session):
        """Every .js file in assets/sdk/ must be copied to the app directory."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        (session.data_dir / "apps").mkdir(exist_ok=True)

        session._copy_app("dynamic")

        app_dir = session.data_dir / "apps" / "dynamic"
        assets_dir = session._find_assets_dir()
        sdk_dir = assets_dir / "sdk"
        assert sdk_dir.is_dir(), f"SDK directory not found: {sdk_dir}"

        sdk_files = [f.name for f in sdk_dir.iterdir() if f.suffix == ".js"]
        assert len(sdk_files) >= 3, f"Expected at least 3 SDK JS files, found: {sdk_files}"
        for name in sdk_files:
            assert (app_dir / name).is_file(), f"SDK file {name} not copied to app dir"

    def test_sdk_copy_idempotent(self, session):
        """Repeated _copy_app calls should overwrite cleanly."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        (session.data_dir / "apps").mkdir(exist_ok=True)

        session._copy_app("dynamic")
        session._copy_app("dynamic")  # Second call

        app_dir = session.data_dir / "apps" / "dynamic"
        assert (app_dir / "marked.min.js").is_file()
        assert (app_dir / "purify.min.js").is_file()
        assert (app_dir / "openwebgoggles-sdk.js").is_file()


# ---------------------------------------------------------------------------
# V2: Deep Merge
# ---------------------------------------------------------------------------


class TestDeepMerge:
    """Tests for _deep_merge utility."""

    def test_basic_merge(self):
        base = {"a": 1, "b": 2}
        _deep_merge(base, {"b": 3, "c": 4})
        assert base == {"a": 1, "b": 3, "c": 4}

    def test_nested_dict_merge(self):
        base = {"data": {"x": 1, "y": 2}}
        _deep_merge(base, {"data": {"y": 3, "z": 4}})
        assert base == {"data": {"x": 1, "y": 3, "z": 4}}

    def test_list_replacement(self):
        """Lists should be replaced, not appended."""
        base = {"items": [1, 2, 3]}
        _deep_merge(base, {"items": [4, 5]})
        assert base == {"items": [4, 5]}

    def test_override_dict_with_non_dict(self):
        base = {"data": {"x": 1}}
        _deep_merge(base, {"data": "replaced"})
        assert base == {"data": "replaced"}

    def test_override_non_dict_with_dict(self):
        base = {"data": "string"}
        _deep_merge(base, {"data": {"x": 1}})
        assert base == {"data": {"x": 1}}

    def test_deeply_nested_merge(self):
        base = {"a": {"b": {"c": 1, "d": 2}}}
        _deep_merge(base, {"a": {"b": {"c": 99}}})
        assert base == {"a": {"b": {"c": 99, "d": 2}}}

    def test_empty_override(self):
        base = {"a": 1}
        _deep_merge(base, {})
        assert base == {"a": 1}

    def test_new_key_added(self):
        base = {}
        _deep_merge(base, {"new_key": "value"})
        assert base == {"new_key": "value"}


# ---------------------------------------------------------------------------
# V2: State Presets
# ---------------------------------------------------------------------------


class TestPresetExpansion:
    """Tests for _expand_preset function."""

    def test_progress_preset(self):
        tasks = [{"label": "Test", "status": "completed"}]
        result = _expand_preset("progress", {"tasks": tasks, "percentage": 50, "title": "Build"})
        assert result["title"] == "Build"
        assert result["status"] == "processing"
        sections = result["data"]["sections"]
        assert len(sections) == 1
        assert sections[0]["type"] == "progress"
        assert sections[0]["tasks"] == tasks
        assert sections[0]["percentage"] == 50

    def test_confirm_preset(self):
        result = _expand_preset("confirm", {"title": "Delete?", "message": "Are you sure?"})
        assert result["title"] == "Delete?"
        assert result["message"] == "Are you sure?"
        assert result["status"] == "pending_review"
        actions = result["actions_requested"]
        assert len(actions) == 2
        assert actions[0]["id"] == "confirm"
        assert actions[1]["id"] == "cancel"

    def test_confirm_preset_with_details(self):
        result = _expand_preset("confirm", {"title": "T", "message": "M", "details": "Extra info"})
        sections = result["data"]["sections"]
        assert len(sections) == 1
        assert sections[0]["type"] == "text"
        assert sections[0]["content"] == "Extra info"
        assert sections[0]["format"] == "markdown"

    def test_log_preset(self):
        lines = ["line1", "line2"]
        result = _expand_preset("log", {"lines": lines, "title": "Output"})
        assert result["title"] == "Output"
        sections = result["data"]["sections"]
        assert len(sections) == 1
        assert sections[0]["type"] == "log"
        assert sections[0]["lines"] == lines

    def test_unknown_preset_raises(self):
        with pytest.raises(ValueError):
            _expand_preset("unknown", {})

    def test_preset_merges_user_overrides(self):
        result = _expand_preset("progress", {"tasks": [], "status": "completed"})
        # User override of status should be merged in
        assert result["status"] == "completed"


# ---------------------------------------------------------------------------
# V2: read_state and merge_state
# ---------------------------------------------------------------------------


class TestReadMergeState:
    """Tests for WebviewSession.read_state() and merge_state()."""

    def test_read_state_empty(self, session):
        """read_state() returns empty dict when no state written."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        result = session.read_state()
        assert result == {}

    def test_read_state_after_write(self, session):
        """read_state() returns what was written."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session.write_state({"title": "Hello", "status": "ready"})
        result = session.read_state()
        assert result["title"] == "Hello"

    def test_merge_state(self, session):
        """merge_state() deep-merges into current state."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session.write_state({"title": "Original", "status": "ready", "data": {"x": 1, "y": 2}})
        merged = session.merge_state({"data": {"y": 99, "z": 3}})
        assert merged["title"] == "Original"
        assert merged["data"]["x"] == 1
        assert merged["data"]["y"] == 99
        assert merged["data"]["z"] == 3

    def test_merge_state_preserves_version(self, session):
        """merge_state() preserves version tracking from write_state."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        session.write_state({"title": "V1"})
        v1 = session.read_state().get("version", 0)
        session.merge_state({"title": "V2"})
        v2 = session.read_state().get("version", 0)
        # version should increase
        assert v2 > v1


# ---------------------------------------------------------------------------
# V2: Module files copied on _copy_app
# ---------------------------------------------------------------------------


class TestModuleFileCopy:
    """Ensure the new JS module files are copied during _copy_app."""

    def test_new_module_files_copied(self, session):
        """utils.js, sections.js, validation.js, behaviors.js must be copied."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        (session.data_dir / "apps").mkdir(exist_ok=True)
        session._copy_app("dynamic")

        app_dir = session.data_dir / "apps" / "dynamic"
        for name in ["utils.js", "sections.js", "validation.js", "behaviors.js"]:
            assert (app_dir / name).is_file(), f"{name} not copied to app dir"

    def test_app_js_still_present(self, session):
        """app.js (orchestrator) must still be copied."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        (session.data_dir / "apps").mkdir(exist_ok=True)
        session._copy_app("dynamic")

        app_dir = session.data_dir / "apps" / "dynamic"
        assert (app_dir / "app.js").is_file()


# ---------------------------------------------------------------------------
# Fix 1: _deep_merge recursion depth limit
# ---------------------------------------------------------------------------


class TestDeepMergeDepthLimit:
    """Ensure _deep_merge rejects excessively nested dicts (defense-in-depth)."""

    @staticmethod
    def _make_nested(depth, leaf_value="ok"):
        """Build a dict nested to `depth` levels: {n: {n: {... leaf: val}}}."""
        root = {}
        inner = root
        for _ in range(depth):
            inner["nested"] = {}
            inner = inner["nested"]
        inner["leaf"] = leaf_value
        return root

    def test_within_limit_passes(self):
        """15-level nested dict merges successfully (well under MAX_MERGE_DEPTH)."""
        # Both base and override must have dicts at each key for recursion
        base = self._make_nested(15, "old")
        override = self._make_nested(15, "new")

        _deep_merge(base, override)
        node = base
        for _ in range(15):
            node = node["nested"]
        assert node["leaf"] == "new"

    def test_exceeds_limit_rejects(self):
        """Nesting beyond MAX_MERGE_DEPTH raises ValueError."""
        depth = MAX_MERGE_DEPTH + 5
        # Both must have matching nested dicts so _deep_merge actually recurses
        base = self._make_nested(depth, "old")
        override = self._make_nested(depth, "boom")

        with pytest.raises(ValueError, match="Merge depth exceeds maximum"):
            _deep_merge(base, override)

    def test_flat_merge_unaffected(self):
        """Flat merges (depth 0) still work normally."""
        base = {"a": 1, "b": 2}
        _deep_merge(base, {"b": 3, "c": 4})
        assert base == {"a": 1, "b": 3, "c": 4}


# ---------------------------------------------------------------------------
# Fix 2: merge_state pre-write validation via validator callback
# ---------------------------------------------------------------------------


class TestMergeStateValidator:
    """Ensure merge_state validator runs BEFORE writing to disk."""

    def test_validator_prevents_write(self, session):
        """When validator raises, state.json must NOT be updated."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        state_file = session.data_dir / "state.json"

        # Write initial good state
        initial = {"title": "Before", "version": 1}
        state_file.write_text(json.dumps(initial))

        def bad_validator(merged):
            raise ValueError("Invalid merged state")

        with pytest.raises(ValueError, match="Invalid merged state"):
            session.merge_state({"title": "After"}, validator=bad_validator)

        # State on disk must be unchanged
        on_disk = json.loads(state_file.read_text())
        assert on_disk["title"] == "Before"

    def test_validator_passes_allows_write(self, session):
        """When validator passes (no exception), state is written."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        state_file = session.data_dir / "state.json"

        initial = {"title": "Before", "version": 1}
        state_file.write_text(json.dumps(initial))

        def ok_validator(merged):
            pass  # No exception — accept

        result = session.merge_state({"title": "After"}, validator=ok_validator)
        assert result["title"] == "After"

        on_disk = json.loads(state_file.read_text())
        assert on_disk["title"] == "After"

    def test_no_validator_still_works(self, session):
        """merge_state without validator behaves as before."""
        session.data_dir.mkdir(parents=True, exist_ok=True)
        state_file = session.data_dir / "state.json"

        initial = {"title": "Old", "version": 1}
        state_file.write_text(json.dumps(initial))

        result = session.merge_state({"title": "New"})
        assert result["title"] == "New"
