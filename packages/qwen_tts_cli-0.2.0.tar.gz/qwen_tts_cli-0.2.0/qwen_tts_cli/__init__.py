"""Whisper-style CLI for Qwen3-TTS."""

__version__ = "0.2.0"
