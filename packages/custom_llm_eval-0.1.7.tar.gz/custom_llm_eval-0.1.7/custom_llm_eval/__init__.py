"""
Custom LLM Eval - A comprehensive framework for evaluating Large Language Models

This package provides an easy-to-use interface for evaluating LLM outputs using various metrics
including bias, toxicity, relevancy, faithfulness, hallucination, and custom evaluations.

Key Features:
- Built-in support for 15+ evaluation metrics
- Automatic database persistence via API
- Token counting and usage tracking
- Test suite organization with release tracking
- Support for both standard and conversational test cases

Usage:
    from custom_llm_eval import LLMEvaluator
    from deepeval.models import OpenAIModel
    from deepeval.test_case import LLMTestCase

    # Initialize evaluator
    model = OpenAIModel(model="gpt-4")
    evaluator = LLMEvaluator(
        llm=model,
        test_suite_name="my_test_suite",
        release_name="v1.0.0",
        save_to_db=True
    )

    # Create test case
    test_case = LLMTestCase(
        name="test_001",
        input="Test input",
        actual_output="Test output"
    )

    # Run evaluation
    result = evaluator.evaluate_bias(test_case, threshold=0.5)
"""

from .eval_metrics import LLMEvaluator

__version__ = "0.1.6"
__all__ = ["LLMEvaluator"]
