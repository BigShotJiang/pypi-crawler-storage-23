# ProtoAuth

The open source, self-hostable auth platform for every language and framework.

Coming soon. Follow https://github.com/protoauth-labs/protoauth