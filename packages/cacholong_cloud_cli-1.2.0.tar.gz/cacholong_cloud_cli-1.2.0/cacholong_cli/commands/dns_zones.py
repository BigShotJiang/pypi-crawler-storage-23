import asyncio
import typer
from typing import List, Optional, Dict, Any, Union, Type
from typing_extensions import Annotated
from rich.table import Column
from uuid import UUID
from datetime import datetime, date, timezone
from cacholong_cli.AsyncTyper import AsyncTyper
from cacholong_cli.common import (
    list_resources,
    list_relation_resources,
    show_resource,
    print_document_error,
    TableDef,
)
from cacholong_cli.connection import Connection
from cacholong_sdk import Filter, Inclusion, DocumentError, ResourceTuple
from cacholong_sdk import DnsZoneCreate, DnsZoneCreateModel

from cacholong_sdk.api_schema import api_schema

# Create typer object
app = AsyncTyper()


@app.async_command(help="Retrieve a paginated list of DNS zones")
async def list(
    ctx: typer.Context,
    domain: Annotated[
        Optional[str], typer.Option(help="The domain name for this DNS zone")
    ] = None,
    active: Annotated[
        Optional[str],
        typer.Option(help="Enable or disable active DNS resolution for this zone"),
    ] = None,
    dnssec: Annotated[
        Optional[str],
        typer.Option(help="Enable DNSSEC cryptographic signing for this zone"),
    ] = None,
    status: Annotated[
        Optional[str],
        typer.Option(
            help="Processing status (pending, processing, verifying, retrying, failed, success)"
        ),
    ] = None,
    administratively_disabled: Annotated[
        Optional[str],
        typer.Option(help="Administrative disable status (overrides active setting)"),
    ] = None,
    dnssec_status: Annotated[
        Optional[str],
        typer.Option(help="DNSSEC status (active, pending, or null if disabled)"),
    ] = None,
    dnssec_flags: Annotated[
        Optional[str], typer.Option(help="DNSSEC key flags (257 for KSK, 256 for ZSK)")
    ] = None,
    dnssec_algorithm: Annotated[
        Optional[str],
        typer.Option(
            help="DNSSEC algorithm (13=ECDSA P-256, 8=RSA/SHA-256, 14=ECDSA P-384)"
        ),
    ] = None,
    dnssec_public_key: Annotated[
        Optional[str],
        typer.Option(help="DNSSEC public key for creating DS records in parent zone"),
    ] = None,
    account: Annotated[
        Optional[UUID], typer.Option(help="The account that owns this DNS zone")
    ] = None,
    product: Annotated[
        Optional[UUID], typer.Option(help="The product associated with this DNS zone")
    ] = None,
    name_server_group: Annotated[
        Optional[UUID],
        typer.Option(help="Authoritative nameservers serving this zone's DNS records"),
    ] = None,
    created_at: Annotated[
        Optional[datetime],
        typer.Option(help="Creation timestamp in ISO 8601 format (exact match)"),
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Creation timestamp in ISO 8601 format (greater than or equal)"
        ),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(help="Creation timestamp in ISO 8601 format (less than or equal)"),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime],
        typer.Option(help="Creation timestamp in ISO 8601 format (greater than)"),
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Creation timestamp in ISO 8601 format (less than)"),
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(help="Last update timestamp in ISO 8601 format (exact match)"),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Last update timestamp in ISO 8601 format (greater than or equal)"
        ),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Last update timestamp in ISO 8601 format (less than or equal)"
        ),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(help="Last update timestamp in ISO 8601 format (greater than)"),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Last update timestamp in ISO 8601 format (less than)"),
    ] = None,
):

    # Build modifier
    modifier = []

    if domain is not None:
        modifier.append(Filter(domain=domain))

    if active is not None:
        modifier.append(Filter(active=active))

    if dnssec is not None:
        modifier.append(Filter(dnssec=dnssec))

    if status is not None:
        modifier.append(Filter(status=status))

    if administratively_disabled is not None:
        modifier.append(
            Filter(
                query_str="filter[administratively_disabled]="
                + str(administratively_disabled)
            )
        )

    if dnssec_status is not None:
        modifier.append(Filter(query_str="filter[dnssec_status]=" + str(dnssec_status)))

    if dnssec_flags is not None:
        modifier.append(Filter(query_str="filter[dnssec_flags]=" + str(dnssec_flags)))

    if dnssec_algorithm is not None:
        modifier.append(
            Filter(query_str="filter[dnssec_algorithm]=" + str(dnssec_algorithm))
        )

    if dnssec_public_key is not None:
        modifier.append(
            Filter(query_str="filter[dnssec_public_key]=" + str(dnssec_public_key))
        )

    if account is not None:
        modifier.append(Filter(account=str(account)))

    if product is not None:
        modifier.append(Filter(product=str(product)))

    if name_server_group is not None:
        modifier.append(
            Filter(query_str="filter[name-server-group]=" + str(name_server_group))
        )

    if created_at is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at]="
                + created_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gte]="
                + created_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lte]="
                + created_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gt]="
                + created_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lt]="
                + created_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if updated_at is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at]="
                + updated_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gte]="
                + updated_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lte]="
                + updated_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gt]="
                + updated_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lt]="
                + updated_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    modifier.append(Inclusion("account"))

    # Table definition
    tabledef: TableDef = [
        {"header": Column("Id", no_wrap=True), "column": "id"},
        {
            "header": "Account",
            "column": "account",
            "column_kebab": "account",
            "nested_column": "name",
        },
        {"header": "Domain", "column": "domain"},
        {"header": "Status", "column": "status"},
        {"header": "Active", "column": "active"},
        {"header": "Created", "column": "created_at"},
        {"header": "Updated", "column": "updated_at"},
    ]

    async with Connection() as conn:
        await list_resources(ctx, DnsZoneCreate(conn, api_schema), tabledef, modifier)


@app.async_command(help="Retrieve detailed information about a specific DNS zone")
async def show(
    ctx: typer.Context,
    dns_zone_id: Annotated[UUID, typer.Argument(help="Resource ID to show")],
):
    # Show resource
    try:
        async with Connection() as conn:
            ctrl = DnsZoneCreate(conn, api_schema)
            model = await ctrl.fetch(dns_zone_id)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Create a new DNS zone for a domain")
async def create(
    ctx: typer.Context,
    domain: Annotated[str, typer.Option(help="The domain name for this DNS zone")],
    account: Annotated[UUID, typer.Option(help="The account that owns this DNS zone")],
    product: Annotated[
        UUID, typer.Option(help="The product associated with this DNS zone")
    ],
    active: Annotated[
        Optional[bool],
        typer.Option(help="Enable or disable active DNS resolution for this zone"),
    ] = None,
    dnssec: Annotated[
        Optional[bool],
        typer.Option(help="Enable DNSSEC cryptographic signing for this zone"),
    ] = None,
):
    try:
        async with Connection() as conn:
            ctrl = DnsZoneCreate(conn, api_schema)
            model = ctrl.create()

            model["domain"] = domain
            if active is not None:
                model["active"] = active
            if dnssec is not None:
                model["dnssec"] = dnssec

            model["account"] = ResourceTuple(account, "accounts")
            model["product"] = ResourceTuple(product, "products")

            await ctrl.store(model, ctx.obj["create_issue"])

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(
    help="Update DNS zone attributes like domain, active state, or DNSSEC settings"
)
async def update(
    ctx: typer.Context,
    dns_zone_id: Annotated[UUID, typer.Argument(help="Resource ID to update")],
    domain: Annotated[
        Optional[str], typer.Option(help="The domain name for this DNS zone")
    ] = None,
    active: Annotated[
        Optional[bool],
        typer.Option(help="Enable or disable active DNS resolution for this zone"),
    ] = None,
    dnssec: Annotated[
        Optional[bool],
        typer.Option(help="Enable DNSSEC cryptographic signing for this zone"),
    ] = None,
):
    try:
        async with Connection() as conn:
            ctrl = DnsZoneCreate(conn, api_schema)
            model = await ctrl.fetch(dns_zone_id)

            if domain is not None:
                model["domain"] = domain
            if active is not None:
                model["active"] = active
            if dnssec is not None:
                model["dnssec"] = dnssec

            await ctrl.update(model)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Permanently delete a DNS zone and all associated DNS records")
async def delete(
    ctx: typer.Context,
    dns_zone_id: Annotated[List[UUID], typer.Argument(help="Resource ID(s) to delete")],
):
    try:
        async with Connection() as conn, asyncio.TaskGroup() as tg:
            ctrl = DnsZoneCreate(conn, api_schema)
            for resource_id in dns_zone_id:
                tg.create_task(ctrl.destroy(resource_id))
    except DocumentError as e:
        await print_document_error(e)
