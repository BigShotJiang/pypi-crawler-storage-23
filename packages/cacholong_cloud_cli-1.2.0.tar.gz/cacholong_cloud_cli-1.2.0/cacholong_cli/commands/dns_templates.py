import asyncio
import typer
from typing import List, Optional, Dict, Any, Union, Type
from typing_extensions import Annotated
from rich.table import Column
from uuid import UUID
from datetime import datetime, date, timezone
from cacholong_cli.AsyncTyper import AsyncTyper
from cacholong_cli.common import (
    list_resources,
    list_relation_resources,
    show_resource,
    print_document_error,
    TableDef,
)
from cacholong_cli.connection import Connection
from cacholong_sdk import Filter, Inclusion, DocumentError, ResourceTuple
from cacholong_sdk import DnsTemplateShow, DnsTemplateShowModel

from cacholong_sdk.api_schema import api_schema

# Create typer object
app = AsyncTyper()


@app.async_command(help="Retrieve a paginated list of DNS templates")
async def list(
    ctx: typer.Context,
    name: Annotated[
        Optional[str], typer.Option(help="Unique name for this DNS template")
    ] = None,
    account: Annotated[
        Optional[UUID],
        typer.Option(
            help="Account that owns this template (or null for global templates)"
        ),
    ] = None,
    created_at: Annotated[
        Optional[datetime],
        typer.Option(help="Creation timestamp in ISO 8601 format (exact match)"),
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Creation timestamp in ISO 8601 format (greater than or equal)"
        ),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(help="Creation timestamp in ISO 8601 format (less than or equal)"),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime],
        typer.Option(help="Creation timestamp in ISO 8601 format (greater than)"),
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Creation timestamp in ISO 8601 format (less than)"),
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(help="Last update timestamp in ISO 8601 format (exact match)"),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Last update timestamp in ISO 8601 format (greater than or equal)"
        ),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Last update timestamp in ISO 8601 format (less than or equal)"
        ),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(help="Last update timestamp in ISO 8601 format (greater than)"),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Last update timestamp in ISO 8601 format (less than)"),
    ] = None,
):

    # Build modifier
    modifier = []

    if name is not None:
        modifier.append(Filter(name=name))

    if account is not None:
        modifier.append(Filter(account=str(account)))

    if created_at is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at]="
                + created_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gte]="
                + created_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lte]="
                + created_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gt]="
                + created_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lt]="
                + created_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if updated_at is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at]="
                + updated_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gte]="
                + updated_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lte]="
                + updated_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gt]="
                + updated_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lt]="
                + updated_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    modifier.append(Inclusion("account"))

    # Table definition
    tabledef: TableDef = [
        {"header": Column("Id", no_wrap=True), "column": "id"},
        {
            "header": "Account",
            "column": "account",
            "column_kebab": "account",
            "nested_column": "name",
        },
        {"header": "Name", "column": "name"},
        {"header": "Created", "column": "created_at"},
        {"header": "Updated", "column": "updated_at"},
    ]

    async with Connection() as conn:
        await list_resources(ctx, DnsTemplateShow(conn, api_schema), tabledef, modifier)


@app.async_command(help="Retrieve detailed information about a specific DNS template")
async def show(
    ctx: typer.Context,
    dns_template_id: Annotated[UUID, typer.Argument(help="Resource ID to show")],
):
    # Show resource
    try:
        async with Connection() as conn:
            ctrl = DnsTemplateShow(conn, api_schema)
            model = await ctrl.fetch(dns_template_id)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Create a new DNS template")
async def create(
    ctx: typer.Context,
    name: Annotated[str, typer.Option(help="Unique name for this DNS template")],
    account: Annotated[
        Optional[UUID],
        typer.Option(
            help="Account that owns this template (or null for global templates)"
        ),
    ] = None,
):
    try:
        async with Connection() as conn:
            ctrl = DnsTemplateShow(conn, api_schema)
            model = ctrl.create()

            model["name"] = name

            if account is not None:
                model["account"] = ResourceTuple(account, "accounts")

            await ctrl.store(model, ctx.obj["create_issue"])

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Update DNS template attributes like name")
async def update(
    ctx: typer.Context,
    dns_template_id: Annotated[UUID, typer.Argument(help="Resource ID to update")],
    name: Annotated[
        Optional[str], typer.Option(help="Unique name for this DNS template")
    ] = None,
):
    try:
        async with Connection() as conn:
            ctrl = DnsTemplateShow(conn, api_schema)
            model = await ctrl.fetch(dns_template_id)

            if name is not None:
                model["name"] = name

            await ctrl.update(model)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Permanently delete a DNS template")
async def delete(
    ctx: typer.Context,
    dns_template_id: Annotated[
        List[UUID], typer.Argument(help="Resource ID(s) to delete")
    ],
):
    try:
        async with Connection() as conn, asyncio.TaskGroup() as tg:
            ctrl = DnsTemplateShow(conn, api_schema)
            for resource_id in dns_template_id:
                tg.create_task(ctrl.destroy(resource_id))
    except DocumentError as e:
        await print_document_error(e)
