import asyncio
import typer
from typing import List, Optional, Dict, Any, Union, Type
from typing_extensions import Annotated
from rich.table import Column
from uuid import UUID
from datetime import datetime, date, timezone
from cacholong_cli.AsyncTyper import AsyncTyper
from cacholong_cli.common import (
    list_resources,
    list_relation_resources,
    show_resource,
    print_document_error,
    TableDef,
)
from cacholong_cli.connection import Connection
from cacholong_sdk import Filter, Inclusion, DocumentError, ResourceTuple
from cacholong_sdk import DnsRecordBase, DnsRecordBaseModel
from cacholong_sdk import DnsRecordCreateWithZone, DnsRecordCreateWithZoneModel
from cacholong_sdk import DnsRecordCreateWithTemplate, DnsRecordCreateWithTemplateModel

from cacholong_sdk.api_schema import api_schema

# Create typer object
app = AsyncTyper()


@app.async_command(help="Retrieve a paginated list of DNS records")
async def list(
    ctx: typer.Context,
    status: Annotated[
        Optional[str],
        typer.Option(
            help="Processing status (pending, processing, verifying, retrying, failed, success)"
        ),
    ] = None,
    dns_record_type: Annotated[
        Optional[str],
        typer.Option(
            help="DNS record type (A, AAAA, CAA, CNAME, MX, NS, SRV, SSHFP, TLSA, TXT)"
        ),
    ] = None,
    name: Annotated[
        Optional[str], typer.Option(help="Hostname or subdomain for this record")
    ] = None,
    content: Annotated[
        Optional[str],
        typer.Option(help="Record content (IP address, hostname, text value, etc.)"),
    ] = None,
    ttl: Annotated[
        Optional[str],
        typer.Option(
            help="Cache duration in seconds (1, 300, 900, 3600, 86400, 604800)"
        ),
    ] = None,
    priority: Annotated[
        Optional[str],
        typer.Option(help="Priority (required for MX and SRV records only)"),
    ] = None,
    dns_zone: Annotated[
        Optional[UUID], typer.Option(help="DNS zone that owns this record")
    ] = None,
    dns_template: Annotated[
        Optional[UUID], typer.Option(help="DNS template that owns this record")
    ] = None,
    created_at: Annotated[
        Optional[datetime],
        typer.Option(help="When this record was created (exact match)"),
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(help="When this record was created (greater than or equal)"),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(help="When this record was created (less than or equal)"),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime],
        typer.Option(help="When this record was created (greater than)"),
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="When this record was created (less than)"),
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(help="When this record was last updated (exact match)"),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(help="When this record was last updated (greater than or equal)"),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(help="When this record was last updated (less than or equal)"),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(help="When this record was last updated (greater than)"),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="When this record was last updated (less than)"),
    ] = None,
):
    # Validate mutually exclusive required parameters
    _require_one_of_group = [dns_zone, dns_template]
    _provided_count = sum(1 for param in _require_one_of_group if param is not None)
    if _provided_count == 0:
        raise typer.BadParameter("Either --dns-zone or --dns-template is required.")
    if _provided_count > 1:
        raise typer.BadParameter(
            "Only one of --dns-zone or --dns-template is required."
        )

    # Build modifier
    modifier = []

    if status is not None:
        modifier.append(Filter(status=status))

    if dns_record_type is not None:
        modifier.append(
            Filter(query_str="filter[dns_record_type]=" + str(dns_record_type))
        )

    if name is not None:
        modifier.append(Filter(name=name))

    if content is not None:
        modifier.append(Filter(content=content))

    if ttl is not None:
        modifier.append(Filter(ttl=ttl))

    if priority is not None:
        modifier.append(Filter(priority=priority))

    if dns_zone is not None:
        modifier.append(Filter(query_str="filter[dns-zone]=" + str(dns_zone)))

    if dns_template is not None:
        modifier.append(Filter(query_str="filter[dns-template]=" + str(dns_template)))

    if created_at is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at]="
                + created_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gte]="
                + created_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lte]="
                + created_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gt]="
                + created_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lt]="
                + created_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if updated_at is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at]="
                + updated_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gte]="
                + updated_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lte]="
                + updated_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gt]="
                + updated_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lt]="
                + updated_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    # Table definition
    tabledef: TableDef = [
        {"header": Column("Id", no_wrap=True), "column": "id"},
        {"header": "Dns Record Type", "column": "dns_record_type"},
        {"header": "Name", "column": "name"},
        {"header": "Content", "column": "content"},
        {"header": "Ttl", "column": "ttl"},
        {"header": "Status", "column": "status"},
        {"header": "Created", "column": "created_at"},
        {"header": "Updated", "column": "updated_at"},
    ]

    async with Connection() as conn:
        await list_resources(ctx, DnsRecordBase(conn, api_schema), tabledef, modifier)


@app.async_command(help="Retrieve detailed information about a specific DNS record")
async def show(
    ctx: typer.Context,
    dns_record_id: Annotated[UUID, typer.Argument(help="Resource ID to show")],
):
    # Show resource
    try:
        async with Connection() as conn:
            ctrl = DnsRecordBase(conn, api_schema)
            model = await ctrl.fetch(dns_record_id)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Create a new DNS record in a zone or template")
async def create(
    ctx: typer.Context,
    dns_record_type: Annotated[
        str,
        typer.Option(
            help="DNS record type (A, AAAA, CAA, CNAME, MX, NS, SRV, SSHFP, TLSA, TXT)"
        ),
    ],
    name: Annotated[str, typer.Option(help="Hostname or subdomain for this record")],
    content: Annotated[
        str,
        typer.Option(help="Record content (IP address, hostname, text value, etc.)"),
    ],
    dns_zone: Annotated[UUID, typer.Option(help="DNS zone that will own this record")],
    dns_template: Annotated[
        UUID, typer.Option(help="DNS template that will own this record")
    ],
    ttl: Annotated[
        Optional[int],
        typer.Option(
            help="Cache duration in seconds (1, 300, 900, 3600, 86400, 604800)"
        ),
    ] = None,
    priority: Annotated[
        Optional[int],
        typer.Option(help="Priority (required for MX and SRV records only)"),
    ] = None,
):
    # Validate mutually exclusive required parameters
    _require_one_of_group = [dns_zone, dns_template]
    _provided_count = sum(1 for param in _require_one_of_group if param is not None)
    if _provided_count == 0:
        raise typer.BadParameter("Either --dns-zone or --dns-template is required.")
    if _provided_count > 1:
        raise typer.BadParameter(
            "Only one of --dns-zone or --dns-template is required."
        )
    # Select controller based on provided parameter
    ctrl_class: Type[Union[DnsRecordCreateWithZone, DnsRecordCreateWithTemplate]]
    if dns_zone is not None:
        ctrl_class = DnsRecordCreateWithZone
    elif dns_template is not None:
        ctrl_class = DnsRecordCreateWithTemplate
    else:
        raise typer.BadParameter("Internal error: no valid parameter provided")
    try:
        async with Connection() as conn:
            ctrl = ctrl_class(conn, api_schema)
            model = ctrl.create()

            model["dns_record_type"] = dns_record_type
            model["name"] = name
            model["content"] = content
            if ttl is not None:
                model["ttl"] = ttl
            if priority is not None:
                model["priority"] = priority

            if dns_zone is not None:
                model["dns-zone"] = ResourceTuple(dns_zone, "dns-zones")
            if dns_template is not None:
                model["dns-template"] = ResourceTuple(dns_template, "dns-templates")

            await ctrl.store(model, ctx.obj["create_issue"])  # type: ignore[arg-type]

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(
    help="Update DNS record attributes like type, name, content, TTL, or priority"
)
async def update(
    ctx: typer.Context,
    dns_record_id: Annotated[UUID, typer.Argument(help="Resource ID to update")],
    dns_record_type: Annotated[
        Optional[str],
        typer.Option(
            help="DNS record type (A, AAAA, CAA, CNAME, MX, NS, SRV, SSHFP, TLSA, TXT)"
        ),
    ] = None,
    name: Annotated[
        Optional[str], typer.Option(help="Hostname or subdomain for this record")
    ] = None,
    content: Annotated[
        Optional[str],
        typer.Option(help="Record content (IP address, hostname, text value, etc.)"),
    ] = None,
    ttl: Annotated[
        Optional[int],
        typer.Option(
            help="Cache duration in seconds (1, 300, 900, 3600, 86400, 604800)"
        ),
    ] = None,
    priority: Annotated[
        Optional[int],
        typer.Option(help="Priority (required for MX and SRV records only)"),
    ] = None,
):
    try:
        async with Connection() as conn:
            ctrl = DnsRecordBase(conn, api_schema)
            model = await ctrl.fetch(dns_record_id)

            if dns_record_type is not None:
                model["dns_record_type"] = dns_record_type
            if name is not None:
                model["name"] = name
            if content is not None:
                model["content"] = content
            if ttl is not None:
                model["ttl"] = ttl
            if priority is not None:
                model["priority"] = priority

            await ctrl.update(model)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Permanently delete a DNS record")
async def delete(
    ctx: typer.Context,
    dns_record_id: Annotated[
        List[UUID], typer.Argument(help="Resource ID(s) to delete")
    ],
):
    try:
        async with Connection() as conn, asyncio.TaskGroup() as tg:
            ctrl = DnsRecordBase(conn, api_schema)
            for resource_id in dns_record_id:
                tg.create_task(ctrl.destroy(resource_id))
    except DocumentError as e:
        await print_document_error(e)
