import asyncio
import typer
from typing import List, Optional, Dict, Any, Union, Type
from typing_extensions import Annotated
from rich.table import Column
from uuid import UUID
from datetime import datetime, date, timezone
from cacholong_cli.AsyncTyper import AsyncTyper
from cacholong_cli.common import (
    list_resources,
    list_relation_resources,
    show_resource,
    print_document_error,
    TableDef,
)
from cacholong_cli.connection import Connection
from cacholong_sdk import Filter, Inclusion, DocumentError, ResourceTuple
from cacholong_sdk import ProductBase, ProductBaseModel

from cacholong_sdk.api_schema import api_schema

# Create typer object
app = AsyncTyper()


@app.async_command(help="Retrieve a collection of products")
async def list(
    ctx: typer.Context,
    name: Annotated[Optional[str], typer.Option(help="Product name")] = None,
    product_type: Annotated[
        Optional[str],
        typer.Option(help="Type of product (option only available for child products)"),
    ] = None,
    price: Annotated[Optional[str], typer.Option(help="Product price")] = None,
    default_bill_sequence: Annotated[
        Optional[str],
        typer.Option(help="Default billing sequence (only for management products)"),
    ] = None,
    invoice_description: Annotated[
        Optional[str], typer.Option(help="Default description for the invoice item")
    ] = None,
    options: Annotated[
        Optional[str], typer.Option(help="Product options in JSON format")
    ] = None,
    account: Annotated[
        Optional[UUID],
        typer.Option(help="The account this product is tied to (if applicable)"),
    ] = None,
    parent: Annotated[
        Optional[UUID],
        typer.Option(help="The parent product (if this is a child product)"),
    ] = None,
    publish_start: Annotated[
        Optional[datetime], typer.Option(help="Start date of the product (exact match)")
    ] = None,
    publish_start_gte: Annotated[
        Optional[datetime],
        typer.Option(help="Start date of the product (greater than or equal)"),
    ] = None,
    publish_start_lte: Annotated[
        Optional[datetime],
        typer.Option(help="Start date of the product (less than or equal)"),
    ] = None,
    publish_start_gt: Annotated[
        Optional[datetime],
        typer.Option(help="Start date of the product (greater than)"),
    ] = None,
    publish_start_lt: Annotated[
        Optional[datetime], typer.Option(help="Start date of the product (less than)")
    ] = None,
    publish_end: Annotated[
        Optional[datetime], typer.Option(help="End date of the product (exact match)")
    ] = None,
    publish_end_gte: Annotated[
        Optional[datetime],
        typer.Option(help="End date of the product (greater than or equal)"),
    ] = None,
    publish_end_lte: Annotated[
        Optional[datetime],
        typer.Option(help="End date of the product (less than or equal)"),
    ] = None,
    publish_end_gt: Annotated[
        Optional[datetime], typer.Option(help="End date of the product (greater than)")
    ] = None,
    publish_end_lt: Annotated[
        Optional[datetime], typer.Option(help="End date of the product (less than)")
    ] = None,
    created_at: Annotated[
        Optional[datetime], typer.Option(help=" (exact match)")
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime], typer.Option(help=" (greater than or equal)")
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime], typer.Option(help=" (less than or equal)")
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime], typer.Option(help=" (greater than)")
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime], typer.Option(help=" (less than)")
    ] = None,
    updated_at: Annotated[
        Optional[datetime], typer.Option(help=" (exact match)")
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime], typer.Option(help=" (greater than or equal)")
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime], typer.Option(help=" (less than or equal)")
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime], typer.Option(help=" (greater than)")
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime], typer.Option(help=" (less than)")
    ] = None,
):

    # Build modifier
    modifier = []

    if name is not None:
        modifier.append(Filter(name=name))

    if product_type is not None:
        modifier.append(Filter(query_str="filter[product_type]=" + str(product_type)))

    if price is not None:
        modifier.append(Filter(price=price))

    if default_bill_sequence is not None:
        modifier.append(
            Filter(
                query_str="filter[default_bill_sequence]=" + str(default_bill_sequence)
            )
        )

    if invoice_description is not None:
        modifier.append(
            Filter(query_str="filter[invoice_description]=" + str(invoice_description))
        )

    if options is not None:
        modifier.append(Filter(options=options))

    if account is not None:
        modifier.append(Filter(account=str(account)))

    if parent is not None:
        modifier.append(Filter(parent=str(parent)))

    if publish_start is not None:
        modifier.append(
            Filter(
                query_str="filter[publish_start]="
                + publish_start.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if publish_start_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[publish_start_gte]="
                + publish_start_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if publish_start_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[publish_start_lte]="
                + publish_start_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if publish_start_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[publish_start_gt]="
                + publish_start_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if publish_start_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[publish_start_lt]="
                + publish_start_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if publish_end is not None:
        modifier.append(
            Filter(
                query_str="filter[publish_end]="
                + publish_end.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if publish_end_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[publish_end_gte]="
                + publish_end_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if publish_end_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[publish_end_lte]="
                + publish_end_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if publish_end_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[publish_end_gt]="
                + publish_end_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if publish_end_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[publish_end_lt]="
                + publish_end_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if created_at is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at]="
                + created_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gte]="
                + created_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lte]="
                + created_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gt]="
                + created_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lt]="
                + created_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if updated_at is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at]="
                + updated_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gte]="
                + updated_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lte]="
                + updated_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gt]="
                + updated_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lt]="
                + updated_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    # Table definition
    tabledef: TableDef = [
        {"header": Column("Id", no_wrap=True), "column": "id"},
        {"header": "Name", "column": "name"},
        {"header": "Product Type", "column": "product_type"},
        {"header": "Price", "column": "price"},
        {"header": "Publish Start", "column": "publish_start"},
        {"header": "Created", "column": "created_at"},
        {"header": "Updated", "column": "updated_at"},
    ]

    async with Connection() as conn:
        await list_resources(ctx, ProductBase(conn, api_schema), tabledef, modifier)


@app.async_command(help="Retrieve details of a specific product")
async def show(
    ctx: typer.Context,
    product_id: Annotated[UUID, typer.Argument(help="Resource ID to show")],
):
    # Show resource
    try:
        async with Connection() as conn:
            ctrl = ProductBase(conn, api_schema)
            model = await ctrl.fetch(product_id)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)
