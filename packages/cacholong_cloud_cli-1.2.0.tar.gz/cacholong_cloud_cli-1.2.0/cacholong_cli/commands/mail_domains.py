import asyncio
import typer
from typing import List, Optional, Dict, Any, Union, Type
from typing_extensions import Annotated
from rich.table import Column
from uuid import UUID
from datetime import datetime, date, timezone
from cacholong_cli.AsyncTyper import AsyncTyper
from cacholong_cli.common import (
    list_resources,
    list_relation_resources,
    show_resource,
    print_document_error,
    TableDef,
)
from cacholong_cli.connection import Connection
from cacholong_sdk import Filter, Inclusion, DocumentError, ResourceTuple
from cacholong_sdk import MailDomainBase, MailDomainBaseModel

from cacholong_sdk.api_schema import api_schema

# Create typer object
app = AsyncTyper()


@app.async_command(help="Retrieve a paginated collection of mail domains.")
async def list(
    ctx: typer.Context,
    domain: Annotated[
        Optional[str], typer.Option(help="The domain name for this mail domain.")
    ] = None,
    quota: Annotated[
        Optional[str], typer.Option(help="Storage quota for mail domain in MB.")
    ] = None,
    hidden: Annotated[
        Optional[str], typer.Option(help="Is mail domain hidden or not?")
    ] = None,
    enabled: Annotated[
        Optional[str], typer.Option(help="Is mail domain enabled or not?")
    ] = None,
    status: Annotated[
        Optional[str],
        typer.Option(help="Current processing status of the mail domain."),
    ] = None,
    account: Annotated[
        Optional[UUID],
        typer.Option(help="The account associated with this mail domain."),
    ] = None,
    service_mail: Annotated[
        Optional[UUID],
        typer.Option(help="The service mail configuration for this mail domain."),
    ] = None,
    created_at: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the mail domain was created. (exact match)"),
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail domain was created. (greater than or equal)"
        ),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail domain was created. (less than or equal)"
        ),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the mail domain was created. (greater than)"),
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the mail domain was created. (less than)"),
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail domain was last updated. (exact match)"
        ),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail domain was last updated. (greater than or equal)"
        ),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail domain was last updated. (less than or equal)"
        ),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail domain was last updated. (greater than)"
        ),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail domain was last updated. (less than)"
        ),
    ] = None,
):

    # Build modifier
    modifier = []

    if domain is not None:
        modifier.append(Filter(domain=domain))

    if quota is not None:
        modifier.append(Filter(quota=quota))

    if hidden is not None:
        modifier.append(Filter(hidden=hidden))

    if enabled is not None:
        modifier.append(Filter(enabled=enabled))

    if status is not None:
        modifier.append(Filter(status=status))

    if account is not None:
        modifier.append(Filter(account=str(account)))

    if service_mail is not None:
        modifier.append(Filter(query_str="filter[service-mail]=" + str(service_mail)))

    if created_at is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at]="
                + created_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gte]="
                + created_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lte]="
                + created_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gt]="
                + created_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lt]="
                + created_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if updated_at is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at]="
                + updated_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gte]="
                + updated_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lte]="
                + updated_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gt]="
                + updated_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lt]="
                + updated_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    # Table definition
    tabledef: TableDef = [
        {"header": Column("Id", no_wrap=True), "column": "id"},
        {"header": "Domain", "column": "domain"},
        {"header": "Status", "column": "status"},
        {"header": "Quota", "column": "quota"},
        {"header": "Enabled", "column": "enabled"},
        {"header": "Created", "column": "created_at"},
        {"header": "Updated", "column": "updated_at"},
    ]

    async with Connection() as conn:
        await list_resources(ctx, MailDomainBase(conn, api_schema), tabledef, modifier)


@app.async_command(help="Retrieve details of a specific mail domain.")
async def show(
    ctx: typer.Context,
    mail_domain_id: Annotated[UUID, typer.Argument(help="Resource ID to show")],
):
    # Show resource
    try:
        async with Connection() as conn:
            ctrl = MailDomainBase(conn, api_schema)
            model = await ctrl.fetch(mail_domain_id)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(
    name="show-account", help="Retrieve the account associated with a mail domain."
)
async def show_account(
    ctx: typer.Context,
    mail_domain_id: Annotated[UUID, typer.Argument(help="Parent resource ID")],
):
    """Retrieve the account associated with a mail domain."""
    try:
        async with Connection() as conn:
            # Fetch parent resource
            parent_ctrl = MailDomainBase(conn, api_schema)
            parent_model = await parent_ctrl.fetch(mail_domain_id)

            # Fetch and show related resource
            await parent_model["account"].fetch()
            related = parent_model["account"].resource

            show_resource(ctx, related)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(
    name="list-mail-addresses", help="Retrieve all mail addresses for a mail domain."
)
async def list_mail_addresses(
    ctx: typer.Context,
    mail_domain_id: Annotated[UUID, typer.Argument(help="Parent resource ID")],
    status: Annotated[
        Optional[str],
        typer.Option(help="Current processing status of the mail address."),
    ] = None,
    name: Annotated[
        Optional[str], typer.Option(help="The local part of the email address.")
    ] = None,
    password: Annotated[
        Optional[str], typer.Option(help="Password for the mail address.")
    ] = None,
    password_confirmation: Annotated[
        Optional[str], typer.Option(help="Password confirmation must match password.")
    ] = None,
    enabled: Annotated[
        Optional[str], typer.Option(help="Is mail address enabled or not?")
    ] = None,
    catchall: Annotated[
        Optional[str], typer.Option(help="Is mail address a catch-all filter?")
    ] = None,
    allow_sending: Annotated[
        Optional[str], typer.Option(help="Is mail address allowed to send email?")
    ] = None,
    allow_receiving: Annotated[
        Optional[str], typer.Option(help="Is mail address allowed to receive email?")
    ] = None,
    keep_mail_on_forward: Annotated[
        Optional[str],
        typer.Option(help="Will mail address receive email when forward exists?"),
    ] = None,
    mail_domain: Annotated[
        Optional[UUID],
        typer.Option(help="The mail domain associated with this mail address."),
    ] = None,
    created_at: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the mail address was created. (exact match)"),
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was created. (greater than or equal)"
        ),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was created. (less than or equal)"
        ),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was created. (greater than)"
        ),
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the mail address was created. (less than)"),
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was last updated. (exact match)"
        ),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was last updated. (greater than or equal)"
        ),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was last updated. (less than or equal)"
        ),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was last updated. (greater than)"
        ),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was last updated. (less than)"
        ),
    ] = None,
):
    """Retrieve all mail addresses for a mail domain."""
    try:
        async with Connection() as conn:
            # Fetch parent resource
            parent_ctrl = MailDomainBase(conn, api_schema)
            parent_model = await parent_ctrl.fetch(mail_domain_id)

            # Build modifier for filtering and includes
            modifier = []

            if status is not None:
                modifier.append(Filter(status=status))

            if name is not None:
                modifier.append(Filter(name=name))

            if password is not None:
                modifier.append(Filter(password=password))

            if password_confirmation is not None:
                modifier.append(
                    Filter(
                        query_str="filter[password_confirmation]="
                        + str(password_confirmation)
                    )
                )

            if enabled is not None:
                modifier.append(Filter(enabled=enabled))

            if catchall is not None:
                modifier.append(Filter(catchall=catchall))

            if allow_sending is not None:
                modifier.append(
                    Filter(query_str="filter[allow_sending]=" + str(allow_sending))
                )

            if allow_receiving is not None:
                modifier.append(
                    Filter(query_str="filter[allow_receiving]=" + str(allow_receiving))
                )

            if keep_mail_on_forward is not None:
                modifier.append(
                    Filter(
                        query_str="filter[keep_mail_on_forward]="
                        + str(keep_mail_on_forward)
                    )
                )

            if mail_domain is not None:
                modifier.append(
                    Filter(query_str="filter[mail-domain]=" + str(mail_domain))
                )

            if created_at is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at]="
                        + created_at.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_gte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_gte]="
                        + created_at_gte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_lte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_lte]="
                        + created_at_lte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_gt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_gt]="
                        + created_at_gt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_lt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_lt]="
                        + created_at_lt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )

            if updated_at is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at]="
                        + updated_at.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_gte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_gte]="
                        + updated_at_gte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_lte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_lte]="
                        + updated_at_lte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_gt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_gt]="
                        + updated_at_gt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_lt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_lt]="
                        + updated_at_lt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )

            # Table definition
            tabledef: TableDef = [
                {"header": Column("Id", no_wrap=True), "column": "id"},
                {"header": "Created", "column": "created_at"},
                {"header": "Updated", "column": "updated_at"},
            ]

            # List related resources
            await list_relation_resources(
                ctx, parent_model, "mail-addresses", tabledef, modifier
            )
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(
    name="show-service-mail",
    help="Retrieve the service mail configuration for a mail domain.",
)
async def show_service_mail(
    ctx: typer.Context,
    mail_domain_id: Annotated[UUID, typer.Argument(help="Parent resource ID")],
):
    """Retrieve the service mail configuration for a mail domain."""
    try:
        async with Connection() as conn:
            # Fetch parent resource
            parent_ctrl = MailDomainBase(conn, api_schema)
            parent_model = await parent_ctrl.fetch(mail_domain_id)

            # Fetch and show related resource
            await parent_model["service-mail"].fetch()
            related = parent_model["service-mail"].resource

            show_resource(ctx, related)
    except DocumentError as e:
        await print_document_error(e)
