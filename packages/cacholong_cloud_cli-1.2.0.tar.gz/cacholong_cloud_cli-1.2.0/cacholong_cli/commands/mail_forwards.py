import asyncio
import typer
from typing import List, Optional, Dict, Any, Union, Type
from typing_extensions import Annotated
from rich.table import Column
from uuid import UUID
from datetime import datetime, date, timezone
from cacholong_cli.AsyncTyper import AsyncTyper
from cacholong_cli.common import (
    list_resources,
    list_relation_resources,
    show_resource,
    print_document_error,
    TableDef,
)
from cacholong_cli.connection import Connection
from cacholong_sdk import Filter, Inclusion, DocumentError, ResourceTuple
from cacholong_sdk import MailForwardBase, MailForwardBaseModel

from cacholong_sdk.api_schema import api_schema

# Create typer object
app = AsyncTyper()


@app.async_command(help="Get mail forwards.")
async def list(
    ctx: typer.Context,
    src_address: Annotated[
        Optional[str], typer.Option(help="Source email address for forwarding.")
    ] = None,
    dst_address: Annotated[
        Optional[str], typer.Option(help="Array of destination email addresses.")
    ] = None,
    status: Annotated[
        Optional[str],
        typer.Option(help="Current processing status of the mail forward."),
    ] = None,
    mail_domain: Annotated[
        Optional[UUID],
        typer.Option(help="The mail domain associated with this mail forward."),
    ] = None,
    created_at: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the mail forward was created. (exact match)"),
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail forward was created. (greater than or equal)"
        ),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail forward was created. (less than or equal)"
        ),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail forward was created. (greater than)"
        ),
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the mail forward was created. (less than)"),
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail forward was last updated. (exact match)"
        ),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail forward was last updated. (greater than or equal)"
        ),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail forward was last updated. (less than or equal)"
        ),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail forward was last updated. (greater than)"
        ),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail forward was last updated. (less than)"
        ),
    ] = None,
):

    # Build modifier
    modifier = []

    if src_address is not None:
        modifier.append(Filter(query_str="filter[src_address]=" + str(src_address)))

    if dst_address is not None:
        modifier.append(Filter(query_str="filter[dst_address]=" + str(dst_address)))

    if status is not None:
        modifier.append(Filter(status=status))

    if mail_domain is not None:
        modifier.append(Filter(query_str="filter[mail-domain]=" + str(mail_domain)))

    if created_at is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at]="
                + created_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gte]="
                + created_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lte]="
                + created_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gt]="
                + created_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lt]="
                + created_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if updated_at is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at]="
                + updated_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gte]="
                + updated_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lte]="
                + updated_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gt]="
                + updated_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lt]="
                + updated_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    # Table definition
    tabledef: TableDef = [
        {"header": Column("Id", no_wrap=True), "column": "id"},
        {"header": "Src Address", "column": "src_address"},
        {"header": "Dst Address", "column": "dst_address"},
        {"header": "Status", "column": "status"},
        {"header": "Created", "column": "created_at"},
        {"header": "Updated", "column": "updated_at"},
    ]

    async with Connection() as conn:
        await list_resources(ctx, MailForwardBase(conn, api_schema), tabledef, modifier)


@app.async_command(help="Get mail forward with mail forward id.")
async def show(
    ctx: typer.Context,
    mail_forward_id: Annotated[UUID, typer.Argument(help="Resource ID to show")],
):
    # Show resource
    try:
        async with Connection() as conn:
            ctrl = MailForwardBase(conn, api_schema)
            model = await ctrl.fetch(mail_forward_id)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Create new mail forward.")
async def create(
    ctx: typer.Context,
    src_address: Annotated[
        str, typer.Option(help="Source email address for forwarding.")
    ],
    dst_address: Annotated[
        List[str], typer.Option(help="Array of destination email addresses.")
    ],
    mail_domain: Annotated[
        UUID, typer.Option(help="The mail domain to associate with this mail forward.")
    ],
):
    try:
        async with Connection() as conn:
            ctrl = MailForwardBase(conn, api_schema)
            model = ctrl.create()

            model["src_address"] = src_address
            model["dst_address"] = dst_address

            model["mail-domain"] = ResourceTuple(mail_domain, "mail-domains")

            await ctrl.store(model, ctx.obj["create_issue"])

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Update mail forward with mail forward id.")
async def update(
    ctx: typer.Context,
    mail_forward_id: Annotated[UUID, typer.Argument(help="Resource ID to update")],
    src_address: Annotated[
        Optional[str], typer.Option(help="Source email address for forwarding.")
    ] = None,
    dst_address: Annotated[
        Optional[List[str]], typer.Option(help="Array of destination email addresses.")
    ] = None,
):
    try:
        async with Connection() as conn:
            ctrl = MailForwardBase(conn, api_schema)
            model = await ctrl.fetch(mail_forward_id)

            if src_address is not None:
                model["src_address"] = src_address
            if dst_address is not None:
                model["dst_address"] = dst_address

            await ctrl.update(model)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Delete mail forward with mail forward id.")
async def delete(
    ctx: typer.Context,
    mail_forward_id: Annotated[
        List[UUID], typer.Argument(help="Resource ID(s) to delete")
    ],
):
    try:
        async with Connection() as conn, asyncio.TaskGroup() as tg:
            ctrl = MailForwardBase(conn, api_schema)
            for resource_id in mail_forward_id:
                tg.create_task(ctrl.destroy(resource_id))
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(
    name="show-mail-domain",
    help="Retrieve the mail domain associated with a specific mail forward.",
)
async def show_mail_domain(
    ctx: typer.Context,
    mail_forward_id: Annotated[UUID, typer.Argument(help="Parent resource ID")],
):
    """Retrieve the mail domain associated with a specific mail forward."""
    try:
        async with Connection() as conn:
            # Fetch parent resource
            parent_ctrl = MailForwardBase(conn, api_schema)
            parent_model = await parent_ctrl.fetch(mail_forward_id)

            # Fetch and show related resource
            await parent_model["mail-domain"].fetch()
            related = parent_model["mail-domain"].resource

            show_resource(ctx, related)
    except DocumentError as e:
        await print_document_error(e)
