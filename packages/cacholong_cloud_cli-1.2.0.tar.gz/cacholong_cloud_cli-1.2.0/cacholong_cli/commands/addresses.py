import asyncio
import typer
from typing import List, Optional, Dict, Any, Union, Type
from typing_extensions import Annotated
from rich.table import Column
from uuid import UUID
from datetime import datetime, date, timezone
from cacholong_cli.AsyncTyper import AsyncTyper
from cacholong_cli.common import (
    list_resources,
    list_relation_resources,
    show_resource,
    print_document_error,
    TableDef,
)
from cacholong_cli.connection import Connection
from cacholong_sdk import Filter, Inclusion, DocumentError, ResourceTuple
from cacholong_sdk import AddressShow, AddressShowModel
from cacholong_sdk import AddressCreateWithUser, AddressCreateWithUserModel
from cacholong_sdk import AddressCreateWithCompany, AddressCreateWithCompanyModel

from cacholong_sdk.api_schema import api_schema

# Create typer object
app = AsyncTyper()


@app.async_command(help="Retrieve a paginated collection of addresses")
async def list(
    ctx: typer.Context,
    street: Annotated[
        Optional[str],
        typer.Option(
            help="Can contain any letter (combined with accent) from any language, any kind of hyphen or dash, single or alternative quote or space."
        ),
    ] = None,
    number: Annotated[
        Optional[str], typer.Option(help="Can contain any number from any language.")
    ] = None,
    suffix: Annotated[
        Optional[str],
        typer.Option(
            help="Can contain any letter or number from any language or space."
        ),
    ] = None,
    zipcode: Annotated[
        Optional[str],
        typer.Option(help="Must contain valid zipcode from NL,BE,DE,GB or US."),
    ] = None,
    city: Annotated[
        Optional[str],
        typer.Option(help="Can contain any letter from any language or space."),
    ] = None,
    state: Annotated[
        Optional[str],
        typer.Option(
            help="Can contain any letter (combined with accent) from any language, any kind of hyphen or dash, single or alternative quote or space."
        ),
    ] = None,
    country: Annotated[
        Optional[str], typer.Option(help="Must contain two uppercase letters (A-Z).")
    ] = None,
    user: Annotated[
        Optional[UUID], typer.Option(help="The user associated with this address.")
    ] = None,
    company: Annotated[
        Optional[UUID], typer.Option(help="The company associated with this address.")
    ] = None,
    created_at: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the address was created. (exact match)"),
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the address was created. (greater than or equal)"
        ),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the address was created. (less than or equal)"
        ),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the address was created. (greater than)"),
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the address was created. (less than)"),
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the address was last updated. (exact match)"),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the address was last updated. (greater than or equal)"
        ),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the address was last updated. (less than or equal)"
        ),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the address was last updated. (greater than)"
        ),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the address was last updated. (less than)"),
    ] = None,
):
    # Validate mutually exclusive required parameters
    _require_one_of_group = [user, company]
    _provided_count = sum(1 for param in _require_one_of_group if param is not None)
    if _provided_count == 0:
        raise typer.BadParameter("Either --user or --company is required.")
    if _provided_count > 1:
        raise typer.BadParameter("Only one of --user or --company is required.")

    # Build modifier
    modifier = []

    if street is not None:
        modifier.append(Filter(street=street))

    if number is not None:
        modifier.append(Filter(number=number))

    if suffix is not None:
        modifier.append(Filter(suffix=suffix))

    if zipcode is not None:
        modifier.append(Filter(zipcode=zipcode))

    if city is not None:
        modifier.append(Filter(city=city))

    if state is not None:
        modifier.append(Filter(state=state))

    if country is not None:
        modifier.append(Filter(country=country))

    if user is not None:
        modifier.append(Filter(user=str(user)))

    if company is not None:
        modifier.append(Filter(company=str(company)))

    if created_at is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at]="
                + created_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gte]="
                + created_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lte]="
                + created_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gt]="
                + created_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lt]="
                + created_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if updated_at is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at]="
                + updated_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gte]="
                + updated_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lte]="
                + updated_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gt]="
                + updated_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lt]="
                + updated_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    modifier.append(Inclusion("company"))
    modifier.append(Inclusion("user"))

    # Table definition
    tabledef: TableDef = [
        {"header": Column("Id", no_wrap=True), "column": "id"},
        {
            "header": "Company",
            "column": "company",
            "column_kebab": "company",
            "nested_column": "name",
        },
        {
            "header": "User",
            "column": "user",
            "column_kebab": "user",
            "nested_column": "name",
        },
        {"header": "Street", "column": "street"},
        {"header": "Number", "column": "number"},
        {"header": "City", "column": "city"},
        {"header": "Created", "column": "created_at"},
        {"header": "Updated", "column": "updated_at"},
    ]

    async with Connection() as conn:
        await list_resources(ctx, AddressShow(conn, api_schema), tabledef, modifier)


@app.async_command(help="Retrieve a specific address by ID")
async def show(
    ctx: typer.Context,
    address_id: Annotated[UUID, typer.Argument(help="Resource ID to show")],
):
    # Show resource
    try:
        async with Connection() as conn:
            ctrl = AddressShow(conn, api_schema)
            model = await ctrl.fetch(address_id)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Create a new address for a user or company")
async def create(
    ctx: typer.Context,
    street: Annotated[
        str,
        typer.Option(
            help="Can contain any letter (combined with accent) from any language, any kind of hyphen or dash, single or alternative quote or space."
        ),
    ],
    number: Annotated[
        str, typer.Option(help="Can contain any number from any language.")
    ],
    zipcode: Annotated[
        str, typer.Option(help="Must contain valid zipcode from NL,BE,DE,GB or US.")
    ],
    city: Annotated[
        str, typer.Option(help="Can contain any letter from any language or space.")
    ],
    country: Annotated[
        str, typer.Option(help="Must contain two uppercase letters (A-Z).")
    ],
    user: Annotated[
        UUID, typer.Option(help="The user to associate with this address.")
    ],
    company: Annotated[
        UUID, typer.Option(help="The company to associate with this address.")
    ],
    suffix: Annotated[
        Optional[str],
        typer.Option(
            help="Can contain any letter or number from any language or space."
        ),
    ] = None,
    state: Annotated[
        Optional[str],
        typer.Option(
            help="Can contain any letter (combined with accent) from any language, any kind of hyphen or dash, single or alternative quote or space."
        ),
    ] = None,
):
    # Validate mutually exclusive required parameters
    _require_one_of_group = [user, company]
    _provided_count = sum(1 for param in _require_one_of_group if param is not None)
    if _provided_count == 0:
        raise typer.BadParameter("Either --user or --company is required.")
    if _provided_count > 1:
        raise typer.BadParameter("Only one of --user or --company is required.")
    # Select controller based on provided parameter
    ctrl_class: Type[Union[AddressCreateWithUser, AddressCreateWithCompany]]
    if user is not None:
        ctrl_class = AddressCreateWithUser
    elif company is not None:
        ctrl_class = AddressCreateWithCompany
    else:
        raise typer.BadParameter("Internal error: no valid parameter provided")
    try:
        async with Connection() as conn:
            ctrl = ctrl_class(conn, api_schema)
            model = ctrl.create()

            model["street"] = street
            model["number"] = number
            if suffix is not None:
                model["suffix"] = suffix
            model["zipcode"] = zipcode
            model["city"] = city
            if state is not None:
                model["state"] = state
            model["country"] = country

            if user is not None:
                model["user"] = ResourceTuple(user, "users")
            if company is not None:
                model["company"] = ResourceTuple(company, "companies")

            await ctrl.store(model, ctx.obj["create_issue"])  # type: ignore[arg-type]

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Update a specific address")
async def update(
    ctx: typer.Context,
    address_id: Annotated[UUID, typer.Argument(help="Resource ID to update")],
    street: Annotated[
        Optional[str],
        typer.Option(
            help="Can contain any letter (combined with accent) from any language, any kind of hyphen or dash, single or alternative quote or space."
        ),
    ] = None,
    number: Annotated[
        Optional[str], typer.Option(help="Can contain any number from any language.")
    ] = None,
    suffix: Annotated[
        Optional[str],
        typer.Option(
            help="Can contain any letter or number from any language or space."
        ),
    ] = None,
    zipcode: Annotated[
        Optional[str],
        typer.Option(help="Must contain valid zipcode from NL,BE,DE,GB or US."),
    ] = None,
    city: Annotated[
        Optional[str],
        typer.Option(help="Can contain any letter from any language or space."),
    ] = None,
    state: Annotated[
        Optional[str],
        typer.Option(
            help="Can contain any letter (combined with accent) from any language, any kind of hyphen or dash, single or alternative quote or space."
        ),
    ] = None,
    country: Annotated[
        Optional[str], typer.Option(help="Must contain two uppercase letters (A-Z).")
    ] = None,
):
    try:
        async with Connection() as conn:
            ctrl = AddressShow(conn, api_schema)
            model = await ctrl.fetch(address_id)

            if street is not None:
                model["street"] = street
            if number is not None:
                model["number"] = number
            if suffix is not None:
                model["suffix"] = suffix
            if zipcode is not None:
                model["zipcode"] = zipcode
            if city is not None:
                model["city"] = city
            if state is not None:
                model["state"] = state
            if country is not None:
                model["country"] = country

            await ctrl.update(model)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Delete a specific address")
async def delete(
    ctx: typer.Context,
    address_id: Annotated[List[UUID], typer.Argument(help="Resource ID(s) to delete")],
):
    try:
        async with Connection() as conn, asyncio.TaskGroup() as tg:
            ctrl = AddressShow(conn, api_schema)
            for resource_id in address_id:
                tg.create_task(ctrl.destroy(resource_id))
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(
    name="show-company", help="Retrieve the company that owns a specific address"
)
async def show_company(
    ctx: typer.Context,
    address_id: Annotated[UUID, typer.Argument(help="Parent resource ID")],
):
    """Retrieve the company that owns a specific address"""
    try:
        async with Connection() as conn:
            # Fetch parent resource
            parent_ctrl = AddressShow(conn, api_schema)
            parent_model = await parent_ctrl.fetch(address_id)

            # Fetch and show related resource
            await parent_model["company"].fetch()
            related = parent_model["company"].resource

            show_resource(ctx, related)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(
    name="show-user", help="Retrieve the user who owns a specific address"
)
async def show_user(
    ctx: typer.Context,
    address_id: Annotated[UUID, typer.Argument(help="Parent resource ID")],
):
    """Retrieve the user who owns a specific address"""
    try:
        async with Connection() as conn:
            # Fetch parent resource
            parent_ctrl = AddressShow(conn, api_schema)
            parent_model = await parent_ctrl.fetch(address_id)

            # Fetch and show related resource
            await parent_model["user"].fetch()
            related = parent_model["user"].resource

            show_resource(ctx, related)
    except DocumentError as e:
        await print_document_error(e)
