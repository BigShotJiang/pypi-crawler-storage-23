import asyncio
import typer
from typing import List, Optional, Dict, Any, Union, Type
from typing_extensions import Annotated
from rich.table import Column
from uuid import UUID
from datetime import datetime, date, timezone
from cacholong_cli.AsyncTyper import AsyncTyper
from cacholong_cli.common import (
    list_resources,
    list_relation_resources,
    show_resource,
    print_document_error,
    TableDef,
)
from cacholong_cli.connection import Connection
from cacholong_sdk import Filter, Inclusion, DocumentError, ResourceTuple
from cacholong_sdk import AccountBase, AccountBaseModel

from cacholong_sdk.api_schema import api_schema

# Create typer object
app = AsyncTyper()


@app.async_command(help="Get accounts")
async def list(
    ctx: typer.Context,
    name: Annotated[Optional[str], typer.Option(help="The unique account name")] = None,
    description: Annotated[
        Optional[str], typer.Option(help="Optional description of the account")
    ] = None,
    account_type: Annotated[
        Optional[str], typer.Option(help="The account type")
    ] = None,
    account_account_id: Annotated[
        Optional[str], typer.Option(help="Parent account ID")
    ] = None,
    account_account_relation: Annotated[
        Optional[str], typer.Option(help="Parent account relationship type")
    ] = None,
    company: Annotated[
        Optional[UUID], typer.Option(help="The company associated with this account")
    ] = None,
    created_at: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the account was created (exact match)"),
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the account was created (greater than or equal)"
        ),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the account was created (less than or equal)"
        ),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the account was created (greater than)"),
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the account was created (less than)"),
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the account was last updated (exact match)"),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the account was last updated (greater than or equal)"
        ),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the account was last updated (less than or equal)"
        ),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the account was last updated (greater than)"),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the account was last updated (less than)"),
    ] = None,
):

    # Build modifier
    modifier = []

    if name is not None:
        modifier.append(Filter(name=name))

    if description is not None:
        modifier.append(Filter(description=description))

    if account_type is not None:
        modifier.append(Filter(query_str="filter[account_type]=" + str(account_type)))

    if account_account_id is not None:
        modifier.append(
            Filter(query_str="filter[account_account_id]=" + str(account_account_id))
        )

    if account_account_relation is not None:
        modifier.append(
            Filter(
                query_str="filter[account_account_relation]="
                + str(account_account_relation)
            )
        )

    if company is not None:
        modifier.append(Filter(company=str(company)))

    if created_at is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at]="
                + created_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gte]="
                + created_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lte]="
                + created_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gt]="
                + created_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lt]="
                + created_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if updated_at is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at]="
                + updated_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gte]="
                + updated_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lte]="
                + updated_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gt]="
                + updated_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lt]="
                + updated_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    # Table definition
    tabledef: TableDef = [
        {"header": Column("Id", no_wrap=True), "column": "id"},
        {"header": "Name", "column": "name"},
        {"header": "Created", "column": "created_at"},
        {"header": "Updated", "column": "updated_at"},
    ]

    async with Connection() as conn:
        await list_resources(ctx, AccountBase(conn, api_schema), tabledef, modifier)


@app.async_command(help="Get account with account id")
async def show(
    ctx: typer.Context,
    account_id: Annotated[UUID, typer.Argument(help="Resource ID to show")],
):
    # Show resource
    try:
        async with Connection() as conn:
            ctrl = AccountBase(conn, api_schema)
            model = await ctrl.fetch(account_id)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(name="list-user-roles", help="List all user-roles for an account")
async def list_user_roles(
    ctx: typer.Context,
    account_id: Annotated[UUID, typer.Argument(help="Parent resource ID")],
    account: Annotated[Optional[UUID], typer.Option(help="The account")] = None,
    user: Annotated[Optional[UUID], typer.Option(help="The user")] = None,
    role: Annotated[Optional[UUID], typer.Option(help="The role")] = None,
    created_at: Annotated[
        Optional[datetime], typer.Option(help="Timestamp when created (exact match)")
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when created (greater than or equal)"),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when created (less than or equal)"),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime], typer.Option(help="Timestamp when created (greater than)")
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime], typer.Option(help="Timestamp when created (less than)")
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when last updated (exact match)"),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when last updated (greater than or equal)"),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when last updated (less than or equal)"),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when last updated (greater than)"),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime], typer.Option(help="Timestamp when last updated (less than)")
    ] = None,
):
    """List all user-roles for an account"""
    try:
        async with Connection() as conn:
            # Fetch parent resource
            parent_ctrl = AccountBase(conn, api_schema)
            parent_model = await parent_ctrl.fetch(account_id)

            # Build modifier for filtering and includes
            modifier = []

            if account is not None:
                modifier.append(Filter(account=str(account)))

            if user is not None:
                modifier.append(Filter(user=str(user)))

            if role is not None:
                modifier.append(Filter(role=str(role)))

            if created_at is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at]="
                        + created_at.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_gte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_gte]="
                        + created_at_gte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_lte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_lte]="
                        + created_at_lte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_gt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_gt]="
                        + created_at_gt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_lt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_lt]="
                        + created_at_lt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )

            if updated_at is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at]="
                        + updated_at.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_gte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_gte]="
                        + updated_at_gte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_lte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_lte]="
                        + updated_at_lte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_gt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_gt]="
                        + updated_at_gt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_lt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_lt]="
                        + updated_at_lt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )

            # Table definition
            tabledef: TableDef = [
                {"header": Column("Id", no_wrap=True), "column": "id"},
                {"header": "Id", "column": "id"},
                {"header": "Created", "column": "created_at"},
                {"header": "Updated", "column": "updated_at"},
            ]

            # List related resources
            await list_relation_resources(
                ctx, parent_model, "user-roles", tabledef, modifier
            )
    except DocumentError as e:
        await print_document_error(e)
