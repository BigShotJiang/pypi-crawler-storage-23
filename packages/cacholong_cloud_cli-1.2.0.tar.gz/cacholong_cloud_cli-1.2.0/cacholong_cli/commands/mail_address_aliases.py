import asyncio
import typer
from typing import List, Optional, Dict, Any, Union, Type
from typing_extensions import Annotated
from rich.table import Column
from uuid import UUID
from datetime import datetime, date, timezone
from cacholong_cli.AsyncTyper import AsyncTyper
from cacholong_cli.common import (
    list_resources,
    list_relation_resources,
    show_resource,
    print_document_error,
    TableDef,
)
from cacholong_cli.connection import Connection
from cacholong_sdk import Filter, Inclusion, DocumentError, ResourceTuple
from cacholong_sdk import MailAddressAliasBase, MailAddressAliasBaseModel

from cacholong_sdk.api_schema import api_schema

# Create typer object
app = AsyncTyper()


@app.async_command(help="Get mail address aliases.")
async def list(
    ctx: typer.Context,
    status: Annotated[
        Optional[str],
        typer.Option(help="Current processing status of the mail address alias."),
    ] = None,
    alias: Annotated[
        Optional[str], typer.Option(help="The local part of the alias email address.")
    ] = None,
    enabled: Annotated[
        Optional[str], typer.Option(help="Is mail address alias enabled or not?")
    ] = None,
    hidden: Annotated[
        Optional[str], typer.Option(help="Is mail address alias hidden or not?")
    ] = None,
    mail_address: Annotated[
        Optional[UUID],
        typer.Option(help="The mail address associated with this alias."),
    ] = None,
    created_at: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was created. (exact match)"
        ),
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was created. (greater than or equal)"
        ),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was created. (less than or equal)"
        ),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was created. (greater than)"
        ),
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was created. (less than)"
        ),
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was last updated. (exact match)"
        ),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was last updated. (greater than or equal)"
        ),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was last updated. (less than or equal)"
        ),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was last updated. (greater than)"
        ),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was last updated. (less than)"
        ),
    ] = None,
):

    # Build modifier
    modifier = []

    if status is not None:
        modifier.append(Filter(status=status))

    if alias is not None:
        modifier.append(Filter(alias=alias))

    if enabled is not None:
        modifier.append(Filter(enabled=enabled))

    if hidden is not None:
        modifier.append(Filter(hidden=hidden))

    if mail_address is not None:
        modifier.append(Filter(query_str="filter[mail-address]=" + str(mail_address)))

    if created_at is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at]="
                + created_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gte]="
                + created_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lte]="
                + created_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gt]="
                + created_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lt]="
                + created_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if updated_at is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at]="
                + updated_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gte]="
                + updated_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lte]="
                + updated_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gt]="
                + updated_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lt]="
                + updated_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    # Table definition
    tabledef: TableDef = [
        {"header": Column("Id", no_wrap=True), "column": "id"},
        {"header": "Created", "column": "created_at"},
        {"header": "Updated", "column": "updated_at"},
    ]

    async with Connection() as conn:
        await list_resources(
            ctx, MailAddressAliasBase(conn, api_schema), tabledef, modifier
        )


@app.async_command(help="Get mail address alias with mail address alias id.")
async def show(
    ctx: typer.Context,
    mail_address_alias_id: Annotated[UUID, typer.Argument(help="Resource ID to show")],
):
    # Show resource
    try:
        async with Connection() as conn:
            ctrl = MailAddressAliasBase(conn, api_schema)
            model = await ctrl.fetch(mail_address_alias_id)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Create new mail address alias.")
async def create(
    ctx: typer.Context,
    alias: Annotated[
        str, typer.Option(help="The local part of the alias email address.")
    ],
    enabled: Annotated[
        bool, typer.Option(help="Is mail address alias enabled or not?")
    ],
    mail_address: Annotated[
        UUID, typer.Option(help="The mail address to associate with this alias.")
    ],
    hidden: Annotated[
        Optional[bool], typer.Option(help="Is mail address alias hidden or not?")
    ] = None,
):
    try:
        async with Connection() as conn:
            ctrl = MailAddressAliasBase(conn, api_schema)
            model = ctrl.create()

            model["alias"] = alias
            model["enabled"] = enabled
            if hidden is not None:
                model["hidden"] = hidden

            model["mail-address"] = ResourceTuple(mail_address, "mail-addresses")

            await ctrl.store(model, ctx.obj["create_issue"])

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Update mail address alias with mail address alias id.")
async def update(
    ctx: typer.Context,
    mail_address_alias_id: Annotated[
        UUID, typer.Argument(help="Resource ID to update")
    ],
    alias: Annotated[
        Optional[str], typer.Option(help="The local part of the alias email address.")
    ] = None,
    enabled: Annotated[
        Optional[bool], typer.Option(help="Is mail address alias enabled or not?")
    ] = None,
    hidden: Annotated[
        Optional[bool], typer.Option(help="Is mail address alias hidden or not?")
    ] = None,
):
    try:
        async with Connection() as conn:
            ctrl = MailAddressAliasBase(conn, api_schema)
            model = await ctrl.fetch(mail_address_alias_id)

            if alias is not None:
                model["alias"] = alias
            if enabled is not None:
                model["enabled"] = enabled
            if hidden is not None:
                model["hidden"] = hidden

            await ctrl.update(model)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Delete mail address alias with mail address alias id.")
async def delete(
    ctx: typer.Context,
    mail_address_alias_id: Annotated[
        List[UUID], typer.Argument(help="Resource ID(s) to delete")
    ],
):
    try:
        async with Connection() as conn, asyncio.TaskGroup() as tg:
            ctrl = MailAddressAliasBase(conn, api_schema)
            for resource_id in mail_address_alias_id:
                tg.create_task(ctrl.destroy(resource_id))
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(
    name="show-mail-address",
    help="Retrieve the mail address associated with a specific mail address alias.",
)
async def show_mail_address(
    ctx: typer.Context,
    mail_address_alias_id: Annotated[UUID, typer.Argument(help="Parent resource ID")],
):
    """Retrieve the mail address associated with a specific mail address alias."""
    try:
        async with Connection() as conn:
            # Fetch parent resource
            parent_ctrl = MailAddressAliasBase(conn, api_schema)
            parent_model = await parent_ctrl.fetch(mail_address_alias_id)

            # Fetch and show related resource
            await parent_model["mail-address"].fetch()
            related = parent_model["mail-address"].resource

            show_resource(ctx, related)
    except DocumentError as e:
        await print_document_error(e)
