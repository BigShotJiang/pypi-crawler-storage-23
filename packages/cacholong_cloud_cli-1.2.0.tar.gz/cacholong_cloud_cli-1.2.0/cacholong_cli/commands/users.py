import asyncio
import typer
from typing import List, Optional, Dict, Any, Union, Type
from typing_extensions import Annotated
from rich.table import Column
from uuid import UUID
from datetime import datetime, date, timezone
from cacholong_cli.AsyncTyper import AsyncTyper
from cacholong_cli.common import (
    list_resources,
    list_relation_resources,
    show_resource,
    print_document_error,
    TableDef,
)
from cacholong_cli.connection import Connection
from cacholong_sdk import Filter, Inclusion, DocumentError, ResourceTuple
from cacholong_sdk import UserBase, UserBaseModel

from cacholong_sdk.api_schema import api_schema

# Create typer object
app = AsyncTyper()


@app.async_command(name="list-user-roles", help="List all user-roles for a user")
async def list_user_roles(
    ctx: typer.Context,
    user_id: Annotated[UUID, typer.Argument(help="Parent resource ID")],
    account: Annotated[Optional[UUID], typer.Option(help="The account")] = None,
    user: Annotated[Optional[UUID], typer.Option(help="The user")] = None,
    role: Annotated[Optional[UUID], typer.Option(help="The role")] = None,
    created_at: Annotated[
        Optional[datetime], typer.Option(help="Timestamp when created (exact match)")
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when created (greater than or equal)"),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when created (less than or equal)"),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime], typer.Option(help="Timestamp when created (greater than)")
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime], typer.Option(help="Timestamp when created (less than)")
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when last updated (exact match)"),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when last updated (greater than or equal)"),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when last updated (less than or equal)"),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when last updated (greater than)"),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime], typer.Option(help="Timestamp when last updated (less than)")
    ] = None,
):
    """List all user-roles for a user"""
    try:
        async with Connection() as conn:
            # Fetch parent resource
            parent_ctrl = UserBase(conn, api_schema)
            parent_model = await parent_ctrl.fetch(user_id)

            # Build modifier for filtering and includes
            modifier = []

            if account is not None:
                modifier.append(Filter(account=str(account)))

            if user is not None:
                modifier.append(Filter(user=str(user)))

            if role is not None:
                modifier.append(Filter(role=str(role)))

            if created_at is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at]="
                        + created_at.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_gte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_gte]="
                        + created_at_gte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_lte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_lte]="
                        + created_at_lte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_gt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_gt]="
                        + created_at_gt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_lt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_lt]="
                        + created_at_lt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )

            if updated_at is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at]="
                        + updated_at.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_gte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_gte]="
                        + updated_at_gte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_lte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_lte]="
                        + updated_at_lte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_gt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_gt]="
                        + updated_at_gt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_lt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_lt]="
                        + updated_at_lt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )

            # Table definition
            tabledef: TableDef = [
                {"header": Column("Id", no_wrap=True), "column": "id"},
                {"header": "Id", "column": "id"},
                {"header": "Created", "column": "created_at"},
                {"header": "Updated", "column": "updated_at"},
            ]

            # List related resources
            await list_relation_resources(
                ctx, parent_model, "user-roles", tabledef, modifier
            )
    except DocumentError as e:
        await print_document_error(e)
