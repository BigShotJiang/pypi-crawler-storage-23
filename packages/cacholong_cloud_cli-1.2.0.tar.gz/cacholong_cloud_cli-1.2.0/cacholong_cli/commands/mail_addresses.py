import asyncio
import typer
from typing import List, Optional, Dict, Any, Union, Type
from typing_extensions import Annotated
from rich.table import Column
from uuid import UUID
from datetime import datetime, date, timezone
from cacholong_cli.AsyncTyper import AsyncTyper
from cacholong_cli.common import (
    list_resources,
    list_relation_resources,
    show_resource,
    print_document_error,
    TableDef,
)
from cacholong_cli.connection import Connection
from cacholong_sdk import Filter, Inclusion, DocumentError, ResourceTuple
from cacholong_sdk import MailAddressBase, MailAddressBaseModel

from cacholong_sdk.api_schema import api_schema

# Create typer object
app = AsyncTyper()


@app.async_command(help="Retrieve a paginated collection of mail addresses.")
async def list(
    ctx: typer.Context,
    status: Annotated[
        Optional[str],
        typer.Option(help="Current processing status of the mail address."),
    ] = None,
    name: Annotated[
        Optional[str], typer.Option(help="The local part of the email address.")
    ] = None,
    password: Annotated[
        Optional[str], typer.Option(help="Password for the mail address.")
    ] = None,
    password_confirmation: Annotated[
        Optional[str], typer.Option(help="Password confirmation must match password.")
    ] = None,
    enabled: Annotated[
        Optional[str], typer.Option(help="Is mail address enabled or not?")
    ] = None,
    catchall: Annotated[
        Optional[str], typer.Option(help="Is mail address a catch-all filter?")
    ] = None,
    allow_sending: Annotated[
        Optional[str], typer.Option(help="Is mail address allowed to send email?")
    ] = None,
    allow_receiving: Annotated[
        Optional[str], typer.Option(help="Is mail address allowed to receive email?")
    ] = None,
    keep_mail_on_forward: Annotated[
        Optional[str],
        typer.Option(help="Will mail address receive email when forward exists?"),
    ] = None,
    mail_domain: Annotated[
        Optional[UUID],
        typer.Option(help="The mail domain associated with this mail address."),
    ] = None,
    created_at: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the mail address was created. (exact match)"),
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was created. (greater than or equal)"
        ),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was created. (less than or equal)"
        ),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was created. (greater than)"
        ),
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Timestamp when the mail address was created. (less than)"),
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was last updated. (exact match)"
        ),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was last updated. (greater than or equal)"
        ),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was last updated. (less than or equal)"
        ),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was last updated. (greater than)"
        ),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address was last updated. (less than)"
        ),
    ] = None,
):

    # Build modifier
    modifier = []

    if status is not None:
        modifier.append(Filter(status=status))

    if name is not None:
        modifier.append(Filter(name=name))

    if password is not None:
        modifier.append(Filter(password=password))

    if password_confirmation is not None:
        modifier.append(
            Filter(
                query_str="filter[password_confirmation]=" + str(password_confirmation)
            )
        )

    if enabled is not None:
        modifier.append(Filter(enabled=enabled))

    if catchall is not None:
        modifier.append(Filter(catchall=catchall))

    if allow_sending is not None:
        modifier.append(Filter(query_str="filter[allow_sending]=" + str(allow_sending)))

    if allow_receiving is not None:
        modifier.append(
            Filter(query_str="filter[allow_receiving]=" + str(allow_receiving))
        )

    if keep_mail_on_forward is not None:
        modifier.append(
            Filter(
                query_str="filter[keep_mail_on_forward]=" + str(keep_mail_on_forward)
            )
        )

    if mail_domain is not None:
        modifier.append(Filter(query_str="filter[mail-domain]=" + str(mail_domain)))

    if created_at is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at]="
                + created_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gte]="
                + created_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lte]="
                + created_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gt]="
                + created_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lt]="
                + created_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if updated_at is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at]="
                + updated_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gte]="
                + updated_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lte]="
                + updated_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gt]="
                + updated_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lt]="
                + updated_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    # Table definition
    tabledef: TableDef = [
        {"header": Column("Id", no_wrap=True), "column": "id"},
        {"header": "Created", "column": "created_at"},
        {"header": "Updated", "column": "updated_at"},
    ]

    async with Connection() as conn:
        await list_resources(ctx, MailAddressBase(conn, api_schema), tabledef, modifier)


@app.async_command(help="Retrieve details of a specific mail address.")
async def show(
    ctx: typer.Context,
    mail_address_id: Annotated[UUID, typer.Argument(help="Resource ID to show")],
):
    # Show resource
    try:
        async with Connection() as conn:
            ctrl = MailAddressBase(conn, api_schema)
            model = await ctrl.fetch(mail_address_id)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Create a new mail address for a mail domain.")
async def create(
    ctx: typer.Context,
    name: Annotated[str, typer.Option(help="The local part of the email address.")],
    password: Annotated[
        Optional[str], typer.Option(help="Password for the mail address.")
    ],
    password_confirmation: Annotated[
        Optional[str], typer.Option(help="Password confirmation must match password.")
    ],
    allow_sending: Annotated[
        bool, typer.Option(help="Is mail address allowed to send email?")
    ],
    allow_receiving: Annotated[
        bool, typer.Option(help="Is mail address allowed to receive email?")
    ],
    keep_mail_on_forward: Annotated[
        bool, typer.Option(help="Will mail address receive email when forward exists?")
    ],
    mail_domain: Annotated[
        UUID, typer.Option(help="The mail domain to associate with this mail address.")
    ],
    enabled: Annotated[
        Optional[bool], typer.Option(help="Is mail address enabled or not?")
    ] = None,
    catchall: Annotated[
        Optional[bool], typer.Option(help="Is mail address a catch-all filter?")
    ] = None,
):
    try:
        async with Connection() as conn:
            ctrl = MailAddressBase(conn, api_schema)
            model = ctrl.create()

            model["name"] = name
            model["password"] = password
            model["password_confirmation"] = password_confirmation
            if enabled is not None:
                model["enabled"] = enabled
            if catchall is not None:
                model["catchall"] = catchall
            model["allow_sending"] = allow_sending
            model["allow_receiving"] = allow_receiving
            model["keep_mail_on_forward"] = keep_mail_on_forward

            model["mail-domain"] = ResourceTuple(mail_domain, "mail-domains")

            await ctrl.store(model, ctx.obj["create_issue"])

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Update a mail address configuration.")
async def update(
    ctx: typer.Context,
    mail_address_id: Annotated[UUID, typer.Argument(help="Resource ID to update")],
    name: Annotated[
        Optional[str], typer.Option(help="The local part of the email address.")
    ] = None,
    password: Annotated[
        Optional[str], typer.Option(help="Password for the mail address.")
    ] = None,
    password_confirmation: Annotated[
        Optional[str], typer.Option(help="Password confirmation must match password.")
    ] = None,
    enabled: Annotated[
        Optional[bool], typer.Option(help="Is mail address enabled or not?")
    ] = None,
    catchall: Annotated[
        Optional[bool], typer.Option(help="Is mail address a catch-all filter?")
    ] = None,
    allow_sending: Annotated[
        Optional[bool], typer.Option(help="Is mail address allowed to send email?")
    ] = None,
    allow_receiving: Annotated[
        Optional[bool], typer.Option(help="Is mail address allowed to receive email?")
    ] = None,
    keep_mail_on_forward: Annotated[
        Optional[bool],
        typer.Option(help="Will mail address receive email when forward exists?"),
    ] = None,
):
    try:
        async with Connection() as conn:
            ctrl = MailAddressBase(conn, api_schema)
            model = await ctrl.fetch(mail_address_id)

            if name is not None:
                model["name"] = name
            if password is not None:
                model["password"] = password
            if password_confirmation is not None:
                model["password_confirmation"] = password_confirmation
            if enabled is not None:
                model["enabled"] = enabled
            if catchall is not None:
                model["catchall"] = catchall
            if allow_sending is not None:
                model["allow_sending"] = allow_sending
            if allow_receiving is not None:
                model["allow_receiving"] = allow_receiving
            if keep_mail_on_forward is not None:
                model["keep_mail_on_forward"] = keep_mail_on_forward

            await ctrl.update(model)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(help="Delete a mail address permanently.")
async def delete(
    ctx: typer.Context,
    mail_address_id: Annotated[
        List[UUID], typer.Argument(help="Resource ID(s) to delete")
    ],
):
    try:
        async with Connection() as conn, asyncio.TaskGroup() as tg:
            ctrl = MailAddressBase(conn, api_schema)
            for resource_id in mail_address_id:
                tg.create_task(ctrl.destroy(resource_id))
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(
    name="show-mail-domain",
    help="Retrieve the mail domain associated with a mail address.",
)
async def show_mail_domain(
    ctx: typer.Context,
    mail_address_id: Annotated[UUID, typer.Argument(help="Parent resource ID")],
):
    """Retrieve the mail domain associated with a mail address."""
    try:
        async with Connection() as conn:
            # Fetch parent resource
            parent_ctrl = MailAddressBase(conn, api_schema)
            parent_model = await parent_ctrl.fetch(mail_address_id)

            # Fetch and show related resource
            await parent_model["mail-domain"].fetch()
            related = parent_model["mail-domain"].resource

            show_resource(ctx, related)
    except DocumentError as e:
        await print_document_error(e)


@app.async_command(name="list-aliases", help="Retrieve all aliases for a mail address.")
async def list_aliases(
    ctx: typer.Context,
    mail_address_id: Annotated[UUID, typer.Argument(help="Parent resource ID")],
    status: Annotated[
        Optional[str],
        typer.Option(help="Current processing status of the mail address alias."),
    ] = None,
    alias: Annotated[
        Optional[str], typer.Option(help="The local part of the alias email address.")
    ] = None,
    enabled: Annotated[
        Optional[str], typer.Option(help="Is mail address alias enabled or not?")
    ] = None,
    hidden: Annotated[
        Optional[str], typer.Option(help="Is mail address alias hidden or not?")
    ] = None,
    mail_address: Annotated[
        Optional[UUID],
        typer.Option(help="The mail address associated with this alias."),
    ] = None,
    created_at: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was created. (exact match)"
        ),
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was created. (greater than or equal)"
        ),
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was created. (less than or equal)"
        ),
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was created. (greater than)"
        ),
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was created. (less than)"
        ),
    ] = None,
    updated_at: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was last updated. (exact match)"
        ),
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was last updated. (greater than or equal)"
        ),
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was last updated. (less than or equal)"
        ),
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was last updated. (greater than)"
        ),
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime],
        typer.Option(
            help="Timestamp when the mail address alias was last updated. (less than)"
        ),
    ] = None,
):
    """Retrieve all aliases for a mail address."""
    try:
        async with Connection() as conn:
            # Fetch parent resource
            parent_ctrl = MailAddressBase(conn, api_schema)
            parent_model = await parent_ctrl.fetch(mail_address_id)

            # Build modifier for filtering and includes
            modifier = []

            if status is not None:
                modifier.append(Filter(status=status))

            if alias is not None:
                modifier.append(Filter(alias=alias))

            if enabled is not None:
                modifier.append(Filter(enabled=enabled))

            if hidden is not None:
                modifier.append(Filter(hidden=hidden))

            if mail_address is not None:
                modifier.append(
                    Filter(query_str="filter[mail-address]=" + str(mail_address))
                )

            if created_at is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at]="
                        + created_at.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_gte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_gte]="
                        + created_at_gte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_lte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_lte]="
                        + created_at_lte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_gt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_gt]="
                        + created_at_gt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if created_at_lt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[created_at_lt]="
                        + created_at_lt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )

            if updated_at is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at]="
                        + updated_at.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_gte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_gte]="
                        + updated_at_gte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_lte is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_lte]="
                        + updated_at_lte.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_gt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_gt]="
                        + updated_at_gt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )
            if updated_at_lt is not None:
                modifier.append(
                    Filter(
                        query_str="filter[updated_at_lt]="
                        + updated_at_lt.astimezone(timezone.utc)
                        .replace(tzinfo=None)
                        .isoformat(timespec="milliseconds")
                        + "Z"
                    )
                )

            # Table definition
            tabledef: TableDef = [
                {"header": Column("Id", no_wrap=True), "column": "id"},
                {"header": "Id", "column": "id"},
                {"header": "Alias", "column": "alias"},
                {"header": "Enabled", "column": "enabled"},
                {"header": "Hidden", "column": "hidden"},
                {"header": "Created", "column": "created_at"},
                {"header": "Updated", "column": "updated_at"},
            ]

            # List related resources
            await list_relation_resources(
                ctx, parent_model, "aliases", tabledef, modifier
            )
    except DocumentError as e:
        await print_document_error(e)
