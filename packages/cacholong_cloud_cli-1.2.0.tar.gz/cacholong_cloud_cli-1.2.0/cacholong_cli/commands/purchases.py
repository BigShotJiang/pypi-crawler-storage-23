import asyncio
import typer
from typing import List, Optional, Dict, Any, Union, Type
from typing_extensions import Annotated
from rich.table import Column
from uuid import UUID
from datetime import datetime, date, timezone
from cacholong_cli.AsyncTyper import AsyncTyper
from cacholong_cli.common import (
    list_resources,
    list_relation_resources,
    show_resource,
    print_document_error,
    TableDef,
)
from cacholong_cli.connection import Connection
from cacholong_sdk import Filter, Inclusion, DocumentError, ResourceTuple
from cacholong_sdk import PurchaseBase, PurchaseBaseModel

from cacholong_sdk.api_schema import api_schema

# Create typer object
app = AsyncTyper()


@app.async_command(help="Retrieve a collection of purchases")
async def list(
    ctx: typer.Context,
    description: Annotated[
        Optional[str], typer.Option(help="Description of the purchase")
    ] = None,
    units: Annotated[
        Optional[str], typer.Option(help="Number of units purchased")
    ] = None,
    bill_sequence: Annotated[
        Optional[str],
        typer.Option(help="Billing sequence (e.g. 1M = monthly, 1Y = yearly)"),
    ] = None,
    product_type: Annotated[
        Optional[str],
        typer.Option(help="Product type (automatically set based on chosen product)"),
    ] = None,
    account: Annotated[
        Optional[UUID], typer.Option(help="The account this purchase belongs to")
    ] = None,
    parent: Annotated[
        Optional[UUID],
        typer.Option(help="The parent purchase (if this is a child purchase)"),
    ] = None,
    product: Annotated[
        Optional[UUID], typer.Option(help="The product being purchased")
    ] = None,
    date_activation: Annotated[
        Optional[datetime],
        typer.Option(help="Activation date (stored as UTC) (exact match)"),
    ] = None,
    date_activation_gte: Annotated[
        Optional[datetime],
        typer.Option(help="Activation date (stored as UTC) (greater than or equal)"),
    ] = None,
    date_activation_lte: Annotated[
        Optional[datetime],
        typer.Option(help="Activation date (stored as UTC) (less than or equal)"),
    ] = None,
    date_activation_gt: Annotated[
        Optional[datetime],
        typer.Option(help="Activation date (stored as UTC) (greater than)"),
    ] = None,
    date_activation_lt: Annotated[
        Optional[datetime],
        typer.Option(help="Activation date (stored as UTC) (less than)"),
    ] = None,
    date_purchase: Annotated[
        Optional[datetime], typer.Option(help=" (exact match)")
    ] = None,
    date_purchase_gte: Annotated[
        Optional[datetime], typer.Option(help=" (greater than or equal)")
    ] = None,
    date_purchase_lte: Annotated[
        Optional[datetime], typer.Option(help=" (less than or equal)")
    ] = None,
    date_purchase_gt: Annotated[
        Optional[datetime], typer.Option(help=" (greater than)")
    ] = None,
    date_purchase_lt: Annotated[
        Optional[datetime], typer.Option(help=" (less than)")
    ] = None,
    date_deactivation: Annotated[
        Optional[datetime], typer.Option(help=" (exact match)")
    ] = None,
    date_deactivation_gte: Annotated[
        Optional[datetime], typer.Option(help=" (greater than or equal)")
    ] = None,
    date_deactivation_lte: Annotated[
        Optional[datetime], typer.Option(help=" (less than or equal)")
    ] = None,
    date_deactivation_gt: Annotated[
        Optional[datetime], typer.Option(help=" (greater than)")
    ] = None,
    date_deactivation_lt: Annotated[
        Optional[datetime], typer.Option(help=" (less than)")
    ] = None,
    date_next_bill: Annotated[
        Optional[datetime], typer.Option(help=" (exact match)")
    ] = None,
    date_next_bill_gte: Annotated[
        Optional[datetime], typer.Option(help=" (greater than or equal)")
    ] = None,
    date_next_bill_lte: Annotated[
        Optional[datetime], typer.Option(help=" (less than or equal)")
    ] = None,
    date_next_bill_gt: Annotated[
        Optional[datetime], typer.Option(help=" (greater than)")
    ] = None,
    date_next_bill_lt: Annotated[
        Optional[datetime], typer.Option(help=" (less than)")
    ] = None,
    created_at: Annotated[
        Optional[datetime], typer.Option(help=" (exact match)")
    ] = None,
    created_at_gte: Annotated[
        Optional[datetime], typer.Option(help=" (greater than or equal)")
    ] = None,
    created_at_lte: Annotated[
        Optional[datetime], typer.Option(help=" (less than or equal)")
    ] = None,
    created_at_gt: Annotated[
        Optional[datetime], typer.Option(help=" (greater than)")
    ] = None,
    created_at_lt: Annotated[
        Optional[datetime], typer.Option(help=" (less than)")
    ] = None,
    updated_at: Annotated[
        Optional[datetime], typer.Option(help=" (exact match)")
    ] = None,
    updated_at_gte: Annotated[
        Optional[datetime], typer.Option(help=" (greater than or equal)")
    ] = None,
    updated_at_lte: Annotated[
        Optional[datetime], typer.Option(help=" (less than or equal)")
    ] = None,
    updated_at_gt: Annotated[
        Optional[datetime], typer.Option(help=" (greater than)")
    ] = None,
    updated_at_lt: Annotated[
        Optional[datetime], typer.Option(help=" (less than)")
    ] = None,
):

    # Build modifier
    modifier = []

    if description is not None:
        modifier.append(Filter(description=description))

    if units is not None:
        modifier.append(Filter(units=units))

    if bill_sequence is not None:
        modifier.append(Filter(query_str="filter[bill_sequence]=" + str(bill_sequence)))

    if product_type is not None:
        modifier.append(Filter(query_str="filter[product_type]=" + str(product_type)))

    if account is not None:
        modifier.append(Filter(account=str(account)))

    if parent is not None:
        modifier.append(Filter(parent=str(parent)))

    if product is not None:
        modifier.append(Filter(product=str(product)))

    if date_activation is not None:
        modifier.append(
            Filter(
                query_str="filter[date_activation]="
                + date_activation.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_activation_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[date_activation_gte]="
                + date_activation_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_activation_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[date_activation_lte]="
                + date_activation_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_activation_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[date_activation_gt]="
                + date_activation_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_activation_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[date_activation_lt]="
                + date_activation_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if date_purchase is not None:
        modifier.append(
            Filter(
                query_str="filter[date_purchase]="
                + date_purchase.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_purchase_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[date_purchase_gte]="
                + date_purchase_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_purchase_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[date_purchase_lte]="
                + date_purchase_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_purchase_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[date_purchase_gt]="
                + date_purchase_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_purchase_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[date_purchase_lt]="
                + date_purchase_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if date_deactivation is not None:
        modifier.append(
            Filter(
                query_str="filter[date_deactivation]="
                + date_deactivation.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_deactivation_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[date_deactivation_gte]="
                + date_deactivation_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_deactivation_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[date_deactivation_lte]="
                + date_deactivation_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_deactivation_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[date_deactivation_gt]="
                + date_deactivation_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_deactivation_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[date_deactivation_lt]="
                + date_deactivation_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if date_next_bill is not None:
        modifier.append(
            Filter(
                query_str="filter[date_next_bill]="
                + date_next_bill.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_next_bill_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[date_next_bill_gte]="
                + date_next_bill_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_next_bill_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[date_next_bill_lte]="
                + date_next_bill_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_next_bill_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[date_next_bill_gt]="
                + date_next_bill_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if date_next_bill_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[date_next_bill_lt]="
                + date_next_bill_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if created_at is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at]="
                + created_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gte]="
                + created_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lte]="
                + created_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_gt]="
                + created_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if created_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[created_at_lt]="
                + created_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    if updated_at is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at]="
                + updated_at.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gte]="
                + updated_at_gte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lte is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lte]="
                + updated_at_lte.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_gt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_gt]="
                + updated_at_gt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )
    if updated_at_lt is not None:
        modifier.append(
            Filter(
                query_str="filter[updated_at_lt]="
                + updated_at_lt.astimezone(timezone.utc)
                .replace(tzinfo=None)
                .isoformat(timespec="milliseconds")
                + "Z"
            )
        )

    modifier.append(Inclusion("account"))
    modifier.append(Inclusion("product"))

    # Table definition
    tabledef: TableDef = [
        {"header": Column("Id", no_wrap=True), "column": "id"},
        {
            "header": "Account",
            "column": "account",
            "column_kebab": "account",
            "nested_column": "name",
        },
        {
            "header": "Product",
            "column": "product",
            "column_kebab": "product",
            "nested_column": "name",
        },
        {"header": "Description", "column": "description"},
        {"header": "Units", "column": "units"},
        {"header": "Date Activation", "column": "date_activation"},
        {"header": "Created", "column": "created_at"},
        {"header": "Updated", "column": "updated_at"},
    ]

    async with Connection() as conn:
        await list_resources(ctx, PurchaseBase(conn, api_schema), tabledef, modifier)


@app.async_command(help="Retrieve details of a specific purchase")
async def show(
    ctx: typer.Context,
    purchase_id: Annotated[UUID, typer.Argument(help="Resource ID to show")],
):
    # Show resource
    try:
        async with Connection() as conn:
            ctrl = PurchaseBase(conn, api_schema)
            model = await ctrl.fetch(purchase_id)

            show_resource(ctx, model)
    except DocumentError as e:
        await print_document_error(e)
