from typing import Optional
from .common import BaseController, BaseModel


class DnsRecordShowModel(BaseModel):
    pass


class DnsRecordShow(BaseController[DnsRecordShowModel]):
    _class = DnsRecordShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "dns-records"

        super().__init__(connection, api_schema)
