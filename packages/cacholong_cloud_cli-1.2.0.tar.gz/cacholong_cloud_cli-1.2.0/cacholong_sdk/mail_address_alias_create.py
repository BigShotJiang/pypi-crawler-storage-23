from typing import Optional
from .common import BaseController, BaseModel


class MailAddressAliasCreateModel(BaseModel):
    pass


class MailAddressAliasCreate(BaseController[MailAddressAliasCreateModel]):
    _class = MailAddressAliasCreateModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-address-aliases"

        super().__init__(connection, api_schema)
