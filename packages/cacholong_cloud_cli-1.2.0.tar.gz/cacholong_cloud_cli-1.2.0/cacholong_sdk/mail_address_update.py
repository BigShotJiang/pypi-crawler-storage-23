from typing import Optional
from .common import BaseController, BaseModel


class MailAddressUpdateModel(BaseModel):
    pass


class MailAddressUpdate(BaseController[MailAddressUpdateModel]):
    _class = MailAddressUpdateModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-addresses"

        super().__init__(connection, api_schema)
