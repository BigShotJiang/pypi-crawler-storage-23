from typing import Optional
from .common import BaseController, BaseModel


class MailForwardShowModel(BaseModel):
    pass


class MailForwardShow(BaseController[MailForwardShowModel]):
    _class = MailForwardShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-forwards"

        super().__init__(connection, api_schema)
