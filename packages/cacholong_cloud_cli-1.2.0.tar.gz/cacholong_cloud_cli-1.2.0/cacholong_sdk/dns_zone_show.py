from typing import Optional
from .common import BaseController, BaseModel


class DnsZoneShowModel(BaseModel):
    pass


class DnsZoneShow(BaseController[DnsZoneShowModel]):
    _class = DnsZoneShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "dns-zones"

        super().__init__(connection, api_schema)
