from typing import Optional
from .common import BaseController, BaseModel


class PurchaseShowModel(BaseModel):
    pass


class PurchaseShow(BaseController[PurchaseShowModel]):
    _class = PurchaseShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "purchases"

        super().__init__(connection, api_schema)
