from typing import Optional
from .common import BaseController, BaseModel


class AccountShowModel(BaseModel):
    pass


class AccountShow(BaseController[AccountShowModel]):
    _class = AccountShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "accounts"

        super().__init__(connection, api_schema)
