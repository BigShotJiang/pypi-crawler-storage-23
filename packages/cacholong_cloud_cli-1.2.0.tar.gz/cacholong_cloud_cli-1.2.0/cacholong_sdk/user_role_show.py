from typing import Optional
from .common import BaseController, BaseModel


class UserRoleShowModel(BaseModel):
    pass


class UserRoleShow(BaseController[UserRoleShowModel]):
    _class = UserRoleShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "user-roles"

        super().__init__(connection, api_schema)
