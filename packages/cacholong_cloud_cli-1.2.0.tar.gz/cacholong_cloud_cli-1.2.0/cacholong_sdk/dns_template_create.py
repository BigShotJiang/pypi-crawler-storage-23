from typing import Optional
from .common import BaseController, BaseModel


class DnsTemplateCreateModel(BaseModel):
    pass


class DnsTemplateCreate(BaseController[DnsTemplateCreateModel]):
    _class = DnsTemplateCreateModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "dns-templates"

        super().__init__(connection, api_schema)
