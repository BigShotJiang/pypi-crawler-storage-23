from typing import Generic, TypeVar, Optional, Any, Union, Awaitable, Type, Dict
from jsonapi_client.resourceobject import ResourceObject
from jsonapi_client import Modifier, Filter
from jsonapi_client.exceptions import DocumentError
from .exception import ValidationException

from rich.console import Console, ConsoleOptions, RenderResult
from rich.json import JSON
from uuid import UUID
import json
import jsonschema


class UUIDEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, UUID):
            return str(obj)
        return json.JSONEncoder.default(self, obj)


class BaseModel:
    def __init__(self, obj: ResourceObject):
        self._obj = obj

    @property
    def id(self):
        return self._obj.id

    @id.setter
    def id(self, value):
        self._obj.id = value

    @property
    def json(self):
        return self._obj.json

    @property
    def url(self) -> str:
        return self._obj.url

    def __rich_console__(
        self, console: Console, options: ConsoleOptions
    ) -> RenderResult:
        yield JSON(json.dumps(self.json, cls=UUIDEncoder), indent=4)

    def __getitem__(self, item: str) -> Any:
        return self._obj[item]

    def __setitem__(self, item: str, value: Any) -> None:
        self._obj[item] = value

    def commit(
        self, custom_url: str = "", meta: Optional[dict] = None
    ) -> Awaitable[ResourceObject]:
        return self._obj.commit(custom_url, meta)


Model = TypeVar("Model", bound=BaseModel)


class BaseController(Generic[Model]):
    _class: Type[Model]
    _resource: str

    def __init__(self, connection, api_schema: Optional[dict] = None) -> None:
        self._connection = connection
        self._api_schema = api_schema or {}
        if not issubclass(self._class, BaseModel):
            raise ValueError("_class attribute is not set")

    @property
    def resource(self):
        return self._resource

    def _validate_operation(self, model: Model, operation: str) -> None:
        """Validate model data against operation-specific schema.

        Args:
            model: The model instance to validate
            operation: Operation type ('create', 'update', or 'delete')

        Raises:
            ValidationException: If validation fails
        """
        if not self._api_schema:
            return  # No schema available, skip validation

        # Try operation-specific schema first (e.g., "dns-templates:create")
        # For alternative create schemas, use custom operation suffix (e.g., "create-with-template")
        if hasattr(self, "_operation_suffix") and self._operation_suffix:
            operation_key = f"{self._resource}:{self._operation_suffix}"
        else:
            operation_key = f"{self._resource}:{operation}"
        schema = self._api_schema.get(operation_key)

        # Fall back to resource-type schema if operation-specific doesn't exist
        if schema is None:
            schema = self._api_schema.get(self._resource)

        # If still no schema, skip validation
        if schema is None:
            return

        # Build JSON Schema for validation
        json_schema = {
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        }

        # Extract data from model for validation
        data_to_validate: Dict[str, Any] = {}

        if "properties" in schema:
            for prop_name, prop_spec in schema["properties"].items():
                # Add property to JSON schema
                if "type" in prop_spec:
                    json_schema["properties"][prop_name] = {"type": prop_spec["type"]}  # type: ignore[index]
                elif "relation" in prop_spec:
                    # Relationship properties are validated separately by jsonapi-client
                    # Just allow them in the schema without type validation
                    json_schema["properties"][prop_name] = {}  # type: ignore[index]

                # Extract value from model if present
                try:
                    value = model[prop_name]
                    if value is not None:
                        data_to_validate[prop_name] = value
                except (KeyError, AttributeError):
                    pass  # Property not set in model

        # Validate the data
        try:
            jsonschema.validate(data_to_validate, json_schema)
        except jsonschema.ValidationError as e:
            raise ValidationException(f"Validation failed for {operation}", [str(e)])

    async def fetch(self, resource_id) -> Model:
        doc = await self._connection.get(self._resource, resource_id)
        return self._class(doc.resource)

    async def fetch_all(self, modifier: Modifier = None):
        async for resource in self._connection.iterate(self._resource, modifier):
            yield self._class(resource)

    def create(self) -> Model:
        model = self._class(self._connection.create(self._resource))
        return model

    async def store(
        self, model: Model, create_issue: bool = False, meta: Optional[dict] = None
    ):
        # Validate against create operation schema
        self._validate_operation(model, "create")

        custom_url = ""
        if create_issue:
            custom_url = model._obj.post_url
            custom_url = custom_url + "?issue=1"
        await model.commit(custom_url, meta)

    async def update(
        self, model: Model, create_issue: bool = False, meta: Optional[dict] = None
    ):
        # Validate against update operation schema
        self._validate_operation(model, "update")

        custom_url = ""
        if create_issue:
            custom_url = model._obj.url
            custom_url = custom_url + "?issue=1"
        await model.commit(custom_url, meta)

    async def destroy(self, resource_id, create_issue: bool = False):
        resource = self._connection.create(self._resource)
        resource.id = resource_id
        resource.delete()
        try:
            custom_url = ""
            if create_issue:
                custom_url = resource.url
                custom_url = custom_url + "?issue=1"
            await resource.commit(custom_url)
        except KeyError:
            # Because we didn't fetch the record first it is not stored in
            # the cache, just handle the exception and that's it. The resource
            # is succesfully removed from the server.
            pass
        except DocumentError as e:
            raise ValidationException("Validation failed", e.errors)
