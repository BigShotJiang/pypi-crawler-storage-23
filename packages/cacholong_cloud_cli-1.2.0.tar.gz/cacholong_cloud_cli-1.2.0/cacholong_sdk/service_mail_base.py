from typing import Optional
from .common import BaseController, BaseModel


class ServiceMailBaseModel(BaseModel):
    pass


class ServiceMailBase(BaseController[ServiceMailBaseModel]):
    _class = ServiceMailBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "service-mails"

        super().__init__(connection, api_schema)
