from typing import Optional
from .common import BaseController, BaseModel


class AccountBaseModel(BaseModel):
    pass


class AccountBase(BaseController[AccountBaseModel]):
    _class = AccountBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "accounts"

        super().__init__(connection, api_schema)
