from typing import Optional
from .common import BaseController, BaseModel


class CompanyShowModel(BaseModel):
    pass


class CompanyShow(BaseController[CompanyShowModel]):
    _class = CompanyShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "companies"

        super().__init__(connection, api_schema)
