from typing import Optional
from .common import BaseController, BaseModel


class ProductBaseModel(BaseModel):
    pass


class ProductBase(BaseController[ProductBaseModel]):
    _class = ProductBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "products"

        super().__init__(connection, api_schema)
