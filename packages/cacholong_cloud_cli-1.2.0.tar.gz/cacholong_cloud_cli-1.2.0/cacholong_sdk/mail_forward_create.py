from typing import Optional
from .common import BaseController, BaseModel


class MailForwardCreateModel(BaseModel):
    pass


class MailForwardCreate(BaseController[MailForwardCreateModel]):
    _class = MailForwardCreateModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-forwards"

        super().__init__(connection, api_schema)
