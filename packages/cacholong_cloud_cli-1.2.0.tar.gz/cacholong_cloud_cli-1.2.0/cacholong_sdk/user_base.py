from typing import Optional
from .common import BaseController, BaseModel


class UserBaseModel(BaseModel):
    pass


class UserBase(BaseController[UserBaseModel]):
    _class = UserBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "users"

        super().__init__(connection, api_schema)
