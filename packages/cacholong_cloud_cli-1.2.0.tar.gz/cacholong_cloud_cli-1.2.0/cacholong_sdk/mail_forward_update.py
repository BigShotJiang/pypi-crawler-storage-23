from typing import Optional
from .common import BaseController, BaseModel


class MailForwardUpdateModel(BaseModel):
    pass


class MailForwardUpdate(BaseController[MailForwardUpdateModel]):
    _class = MailForwardUpdateModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-forwards"

        super().__init__(connection, api_schema)
