from typing import Optional
from .common import BaseController, BaseModel


class AddressCreateWithCompanyModel(BaseModel):
    pass


class AddressCreateWithCompany(BaseController[AddressCreateWithCompanyModel]):
    _class = AddressCreateWithCompanyModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "addresses"
        # Use operation-specific validation for alternative create schemas
        self._operation_suffix = "create-with-company"

        super().__init__(connection, api_schema)
