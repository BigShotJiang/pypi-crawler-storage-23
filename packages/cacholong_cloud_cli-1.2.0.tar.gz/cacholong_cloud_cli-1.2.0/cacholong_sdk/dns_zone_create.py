from typing import Optional
from .common import BaseController, BaseModel


class DnsZoneCreateModel(BaseModel):
    pass


class DnsZoneCreate(BaseController[DnsZoneCreateModel]):
    _class = DnsZoneCreateModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "dns-zones"

        super().__init__(connection, api_schema)
