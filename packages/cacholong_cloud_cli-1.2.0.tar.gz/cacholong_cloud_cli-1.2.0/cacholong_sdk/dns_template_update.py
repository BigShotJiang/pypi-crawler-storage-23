from typing import Optional
from .common import BaseController, BaseModel


class DnsTemplateUpdateModel(BaseModel):
    pass


class DnsTemplateUpdate(BaseController[DnsTemplateUpdateModel]):
    _class = DnsTemplateUpdateModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "dns-templates"

        super().__init__(connection, api_schema)
