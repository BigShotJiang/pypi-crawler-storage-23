from typing import Optional
from .common import BaseController, BaseModel


class PurchaseBaseModel(BaseModel):
    pass


class PurchaseBase(BaseController[PurchaseBaseModel]):
    _class = PurchaseBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "purchases"

        super().__init__(connection, api_schema)
