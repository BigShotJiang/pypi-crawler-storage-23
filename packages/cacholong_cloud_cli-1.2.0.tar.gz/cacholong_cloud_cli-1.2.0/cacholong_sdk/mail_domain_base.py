from typing import Optional
from .common import BaseController, BaseModel


class MailDomainBaseModel(BaseModel):
    pass


class MailDomainBase(BaseController[MailDomainBaseModel]):
    _class = MailDomainBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-domains"

        super().__init__(connection, api_schema)
