from typing import Optional
from .common import BaseController, BaseModel


class UserRoleBaseModel(BaseModel):
    pass


class UserRoleBase(BaseController[UserRoleBaseModel]):
    _class = UserRoleBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "user-roles"

        super().__init__(connection, api_schema)
