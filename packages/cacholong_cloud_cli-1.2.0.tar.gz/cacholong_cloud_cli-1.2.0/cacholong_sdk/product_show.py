from typing import Optional
from .common import BaseController, BaseModel


class ProductShowModel(BaseModel):
    pass


class ProductShow(BaseController[ProductShowModel]):
    _class = ProductShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "products"

        super().__init__(connection, api_schema)
