from typing import Optional
from .common import BaseController, BaseModel


class DnsRecordCreateWithTemplateModel(BaseModel):
    pass


class DnsRecordCreateWithTemplate(BaseController[DnsRecordCreateWithTemplateModel]):
    _class = DnsRecordCreateWithTemplateModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "dns-records"
        # Use operation-specific validation for alternative create schemas
        self._operation_suffix = "create-with-template"

        super().__init__(connection, api_schema)
