from typing import Optional
from .common import BaseController, BaseModel


class MailAddressAliasBaseModel(BaseModel):
    pass


class MailAddressAliasBase(BaseController[MailAddressAliasBaseModel]):
    _class = MailAddressAliasBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-address-aliases"

        super().__init__(connection, api_schema)
