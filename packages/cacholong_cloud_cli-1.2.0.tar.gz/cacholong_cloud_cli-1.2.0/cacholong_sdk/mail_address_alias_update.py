from typing import Optional
from .common import BaseController, BaseModel


class MailAddressAliasUpdateModel(BaseModel):
    pass


class MailAddressAliasUpdate(BaseController[MailAddressAliasUpdateModel]):
    _class = MailAddressAliasUpdateModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-address-aliases"

        super().__init__(connection, api_schema)
