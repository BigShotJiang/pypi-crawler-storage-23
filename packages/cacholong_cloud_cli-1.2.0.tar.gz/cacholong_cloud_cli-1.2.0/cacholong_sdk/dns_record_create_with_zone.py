from typing import Optional
from .common import BaseController, BaseModel


class DnsRecordCreateWithZoneModel(BaseModel):
    pass


class DnsRecordCreateWithZone(BaseController[DnsRecordCreateWithZoneModel]):
    _class = DnsRecordCreateWithZoneModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "dns-records"
        # Use operation-specific validation for alternative create schemas
        self._operation_suffix = "create-with-zone"

        super().__init__(connection, api_schema)
