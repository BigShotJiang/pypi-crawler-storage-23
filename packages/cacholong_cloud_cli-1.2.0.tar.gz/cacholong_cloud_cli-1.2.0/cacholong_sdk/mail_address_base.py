from typing import Optional
from .common import BaseController, BaseModel


class MailAddressBaseModel(BaseModel):
    pass


class MailAddressBase(BaseController[MailAddressBaseModel]):
    _class = MailAddressBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-addresses"

        super().__init__(connection, api_schema)
