from typing import Optional
from .common import BaseController, BaseModel


class MailForwardBaseModel(BaseModel):
    pass


class MailForwardBase(BaseController[MailForwardBaseModel]):
    _class = MailForwardBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-forwards"

        super().__init__(connection, api_schema)
