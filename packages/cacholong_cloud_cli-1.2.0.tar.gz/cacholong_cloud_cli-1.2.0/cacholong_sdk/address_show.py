from typing import Optional
from .common import BaseController, BaseModel


class AddressShowModel(BaseModel):
    pass


class AddressShow(BaseController[AddressShowModel]):
    _class = AddressShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "addresses"

        super().__init__(connection, api_schema)
