from typing import Optional
from .common import BaseController, BaseModel


class AddressUpdateModel(BaseModel):
    pass


class AddressUpdate(BaseController[AddressUpdateModel]):
    _class = AddressUpdateModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "addresses"

        super().__init__(connection, api_schema)
