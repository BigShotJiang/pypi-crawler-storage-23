# API Schema for jsonapi-client validation and CLI operation-specific validation
#
# Resource-type keys (e.g., "dns-templates"): Used by jsonapi-client for runtime validation
# Operation-specific keys (e.g., "dns-templates:create", "dns-templates:update"):
#   Used by CLI commands for operation-specific validation with correct required/readonly constraints
#
# When multiple OpenAPI schemas map to the same JSON:API resource type, the resource-type key
# uses the primary schema (precedence: base schema > Show > Create > Update > Delete).
# All schema variants are preserved as operation-specific keys.

api_schema = {
    "addresses": {
        "properties": {
            "street": {"type": ["string"]},
            "number": {"type": ["string"]},
            "suffix": {"type": ["string"]},
            "zipcode": {"type": ["string"]},
            "city": {"type": ["string"]},
            "state": {"type": ["string"]},
            "country": {"type": ["string"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "user": {"relation": "to-one", "resource": "users"},
            "company": {"relation": "to-one", "resource": "companies"},
        }
    },
    "addresses:show": {
        "properties": {
            "street": {"type": ["string"]},
            "number": {"type": ["string"]},
            "suffix": {"type": ["string"]},
            "zipcode": {"type": ["string"]},
            "city": {"type": ["string"]},
            "state": {"type": ["string"]},
            "country": {"type": ["string"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "user": {"relation": "to-one", "resource": "users"},
            "company": {"relation": "to-one", "resource": "companies"},
        }
    },
    "addresses:base": {
        "properties": {
            "street": {"type": ["string"]},
            "number": {"type": ["string"]},
            "suffix": {"type": ["string"]},
            "zipcode": {"type": ["string"]},
            "city": {"type": ["string"]},
            "state": {"type": ["string"]},
            "country": {"type": ["string"]},
        }
    },
    "addresses:create-with-user": {
        "properties": {
            "street": {"type": ["string"]},
            "number": {"type": ["string"]},
            "suffix": {"type": ["string"]},
            "zipcode": {"type": ["string"]},
            "city": {"type": ["string"]},
            "state": {"type": ["string"]},
            "country": {"type": ["string"]},
            "user": {"relation": "to-one", "resource": "users"},
        }
    },
    "addresses:create-with-company": {
        "properties": {
            "street": {"type": ["string"]},
            "number": {"type": ["string"]},
            "suffix": {"type": ["string"]},
            "zipcode": {"type": ["string"]},
            "city": {"type": ["string"]},
            "state": {"type": ["string"]},
            "country": {"type": ["string"]},
            "company": {"relation": "to-one", "resource": "companies"},
        }
    },
    "addresses:update": {
        "properties": {
            "street": {"type": ["string"]},
            "number": {"type": ["string"]},
            "suffix": {"type": ["string"]},
            "zipcode": {"type": ["string"]},
            "city": {"type": ["string"]},
            "state": {"type": ["string"]},
            "country": {"type": ["string"]},
        }
    },
    "dns-records": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "dns_record_type": {"type": ["string"]},
            "name": {"type": ["string"]},
            "content": {"type": ["string"]},
            "ttl": {"type": ["integer"]},
            "priority": {"type": ["integer", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "dns-zone": {"relation": "to-one", "resource": "dns-zones"},
            "dns-template": {"relation": "to-one", "resource": "dns-templates"},
        }
    },
    "dns-records:base": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "dns_record_type": {"type": ["string"]},
            "name": {"type": ["string"]},
            "content": {"type": ["string"]},
            "ttl": {"type": ["integer"]},
            "priority": {"type": ["integer", "null"]},
        }
    },
    "dns-records:create-with-zone": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "dns_record_type": {"type": ["string"]},
            "name": {"type": ["string"]},
            "content": {"type": ["string"]},
            "ttl": {"type": ["integer"]},
            "priority": {"type": ["integer", "null"]},
            "dns-zone": {"relation": "to-one", "resource": "dns-zones"},
        }
    },
    "dns-records:create-with-template": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "dns_record_type": {"type": ["string"]},
            "name": {"type": ["string"]},
            "content": {"type": ["string"]},
            "ttl": {"type": ["integer"]},
            "priority": {"type": ["integer", "null"]},
            "dns-template": {"relation": "to-one", "resource": "dns-templates"},
        }
    },
    "dns-records:update": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "dns_record_type": {"type": ["string"]},
            "name": {"type": ["string"]},
            "content": {"type": ["string"]},
            "ttl": {"type": ["integer"]},
            "priority": {"type": ["integer", "null"]},
            "dns-zone": {"relation": "to-one", "resource": "dns-zones"},
            "dns-template": {"relation": "to-one", "resource": "dns-templates"},
        }
    },
    "dns-records:show": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "dns_record_type": {"type": ["string"]},
            "name": {"type": ["string"]},
            "content": {"type": ["string"]},
            "ttl": {"type": ["integer"]},
            "priority": {"type": ["integer", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "dns-zone": {"relation": "to-one", "resource": "dns-zones"},
            "dns-template": {"relation": "to-one", "resource": "dns-templates"},
        }
    },
    "dns-templates": {
        "properties": {
            "name": {"type": ["string"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "dns-records": {"relation": "to-many", "resource": "dns-records"},
        }
    },
    "dns-templates:show": {
        "properties": {
            "name": {"type": ["string"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "dns-records": {"relation": "to-many", "resource": "dns-records"},
        }
    },
    "dns-templates:create": {
        "properties": {
            "name": {"type": ["string"]},
            "account": {"relation": "to-one", "resource": "accounts"},
        }
    },
    "dns-templates:update": {
        "properties": {
            "name": {"type": ["string"]},
            "dns-records": {"relation": "to-many", "resource": "dns-records"},
        }
    },
    "dns-templates:base": {
        "properties": {
            "name": {"type": ["string"]},
            "account": {"relation": "to-one", "resource": "accounts"},
        }
    },
    "dns-zones": {
        "properties": {
            "domain": {"type": ["string"]},
            "active": {"type": ["boolean"]},
            "dnssec": {"type": ["boolean"]},
            "status": {"type": ["string", "null"]},
            "administratively_disabled": {"type": ["boolean", "null"]},
            "dnssec_status": {"type": ["string", "null"]},
            "dnssec_flags": {"type": ["number", "null"]},
            "dnssec_algorithm": {"type": ["number", "null"]},
            "dnssec_public_key": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "product": {"relation": "to-one", "resource": "products"},
            "name-server-group": {
                "relation": "to-one",
                "resource": "name-server-groups",
            },
            "dns-records": {"relation": "to-many", "resource": "dns-records"},
        }
    },
    "dns-zones:create": {
        "properties": {
            "domain": {"type": ["string"]},
            "active": {"type": ["boolean"]},
            "dnssec": {"type": ["boolean"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "product": {"relation": "to-one", "resource": "products"},
        }
    },
    "dns-zones:update": {
        "properties": {
            "domain": {"type": ["string"]},
            "active": {"type": ["boolean"]},
            "dnssec": {"type": ["boolean"]},
        }
    },
    "dns-zones:base": {
        "properties": {
            "domain": {"type": ["string"]},
            "active": {"type": ["boolean"]},
            "dnssec": {"type": ["boolean"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "product": {"relation": "to-one", "resource": "products"},
        }
    },
    "dns-zones:show": {
        "properties": {
            "domain": {"type": ["string"]},
            "active": {"type": ["boolean"]},
            "dnssec": {"type": ["boolean"]},
            "status": {"type": ["string", "null"]},
            "administratively_disabled": {"type": ["boolean", "null"]},
            "dnssec_status": {"type": ["string", "null"]},
            "dnssec_flags": {"type": ["number", "null"]},
            "dnssec_algorithm": {"type": ["number", "null"]},
            "dnssec_public_key": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "product": {"relation": "to-one", "resource": "products"},
            "name-server-group": {
                "relation": "to-one",
                "resource": "name-server-groups",
            },
            "dns-records": {"relation": "to-many", "resource": "dns-records"},
        }
    },
    "accounts": {
        "properties": {
            "name": {"type": ["string"]},
            "description": {"type": ["string"]},
            "account_type": {"type": ["string", "null"]},
            "account_account_id": {"type": ["string", "null"]},
            "account_account_relation": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "company": {"relation": "to-one", "resource": "companies"},
            "user-roles": {"relation": "to-many", "resource": "user-roles"},
        }
    },
    "accounts:base": {
        "properties": {
            "name": {"type": ["string"]},
            "description": {"type": ["string"]},
            "account_type": {"type": ["string", "null"]},
            "account_account_id": {"type": ["string", "null"]},
            "account_account_relation": {"type": ["string", "null"]},
        }
    },
    "accounts:show": {
        "properties": {
            "name": {"type": ["string"]},
            "description": {"type": ["string"]},
            "account_type": {"type": ["string", "null"]},
            "account_account_id": {"type": ["string", "null"]},
            "account_account_relation": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "company": {"relation": "to-one", "resource": "companies"},
            "user-roles": {"relation": "to-many", "resource": "user-roles"},
        }
    },
    "user-roles": {
        "properties": {
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "user": {"relation": "to-one", "resource": "users"},
            "role": {"relation": "to-one", "resource": "roles"},
        }
    },
    "user-roles:base": {"properties": {}},
    "user-roles:show": {
        "properties": {
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "user": {"relation": "to-one", "resource": "users"},
            "role": {"relation": "to-one", "resource": "roles"},
        }
    },
    "companies": {
        "properties": {
            "name": {"type": ["string"]},
            "kvknr": {"type": ["string", "null"]},
            "phone": {"type": ["string", "null"]},
            "email": {"type": ["string", "null"]},
            "email_invoice": {"type": ["string", "null"]},
            "vat_number": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "addresses": {"relation": "to-many", "resource": "addresses"},
        }
    },
    "companies:base": {
        "properties": {
            "name": {"type": ["string"]},
            "kvknr": {"type": ["string", "null"]},
            "phone": {"type": ["string", "null"]},
            "email": {"type": ["string", "null"]},
            "email_invoice": {"type": ["string", "null"]},
            "vat_number": {"type": ["string", "null"]},
        }
    },
    "companies:show": {
        "properties": {
            "name": {"type": ["string"]},
            "kvknr": {"type": ["string", "null"]},
            "phone": {"type": ["string", "null"]},
            "email": {"type": ["string", "null"]},
            "email_invoice": {"type": ["string", "null"]},
            "vat_number": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "addresses": {"relation": "to-many", "resource": "addresses"},
        }
    },
    "companies:update": {
        "properties": {
            "name": {"type": ["string"]},
            "kvknr": {"type": ["string", "null"]},
            "phone": {"type": ["string", "null"]},
            "email": {"type": ["string", "null"]},
            "email_invoice": {"type": ["string", "null"]},
            "vat_number": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "addresses": {"relation": "to-many", "resource": "addresses"},
        }
    },
    "users": {
        "properties": {
            "phone": {"type": ["string", "null"]},
            "email": {"type": ["string"]},
            "password": {"type": ["string", "null"]},
            "password_confirmation": {"type": ["string", "null"]},
            "firstname": {"type": ["string", "null"]},
            "lastname": {"type": ["string", "null"]},
            "active": {"type": ["boolean", "null"]},
            "invited_at": {"type": ["string", "null"]},
            "invite_accepted_at": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "addresses": {"relation": "to-many", "resource": "addresses"},
            "accounts": {"relation": "to-many", "resource": "accounts"},
            "user-roles": {"relation": "to-many", "resource": "user-roles"},
        }
    },
    "users:base": {
        "properties": {
            "phone": {"type": ["string", "null"]},
            "email": {"type": ["string"]},
            "password": {"type": ["string", "null"]},
            "password_confirmation": {"type": ["string", "null"]},
            "firstname": {"type": ["string", "null"]},
            "lastname": {"type": ["string", "null"]},
            "active": {"type": ["boolean", "null"]},
        }
    },
    "users:show": {
        "properties": {
            "phone": {"type": ["string", "null"]},
            "email": {"type": ["string"]},
            "password": {"type": ["string", "null"]},
            "password_confirmation": {"type": ["string", "null"]},
            "firstname": {"type": ["string", "null"]},
            "lastname": {"type": ["string", "null"]},
            "active": {"type": ["boolean", "null"]},
            "invited_at": {"type": ["string", "null"]},
            "invite_accepted_at": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "addresses": {"relation": "to-many", "resource": "addresses"},
            "accounts": {"relation": "to-many", "resource": "accounts"},
            "user-roles": {"relation": "to-many", "resource": "user-roles"},
        }
    },
    "mail-addresses": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "name": {"type": ["string"]},
            "password": {"type": ["string", "null"]},
            "password_confirmation": {"type": ["string", "null"]},
            "enabled": {"type": ["boolean", "null"]},
            "catchall": {"type": ["boolean"]},
            "allow_sending": {"type": ["boolean"]},
            "allow_receiving": {"type": ["boolean"]},
            "keep_mail_on_forward": {"type": ["boolean"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "mail-domain": {"relation": "to-one", "resource": "mail-domains"},
            "aliases": {"relation": "to-many", "resource": "mail-address-aliases"},
        }
    },
    "mail-addresses:base": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "name": {"type": ["string"]},
            "password": {"type": ["string", "null"]},
            "password_confirmation": {"type": ["string", "null"]},
            "enabled": {"type": ["boolean", "null"]},
            "catchall": {"type": ["boolean"]},
            "allow_sending": {"type": ["boolean"]},
            "allow_receiving": {"type": ["boolean"]},
            "keep_mail_on_forward": {"type": ["boolean"]},
        }
    },
    "mail-addresses:show": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "name": {"type": ["string"]},
            "password": {"type": ["string", "null"]},
            "password_confirmation": {"type": ["string", "null"]},
            "enabled": {"type": ["boolean", "null"]},
            "catchall": {"type": ["boolean"]},
            "allow_sending": {"type": ["boolean"]},
            "allow_receiving": {"type": ["boolean"]},
            "keep_mail_on_forward": {"type": ["boolean"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "mail-domain": {"relation": "to-one", "resource": "mail-domains"},
            "aliases": {"relation": "to-many", "resource": "mail-address-aliases"},
        }
    },
    "mail-addresses:create": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "name": {"type": ["string"]},
            "password": {"type": ["string", "null"]},
            "password_confirmation": {"type": ["string", "null"]},
            "enabled": {"type": ["boolean", "null"]},
            "catchall": {"type": ["boolean"]},
            "allow_sending": {"type": ["boolean"]},
            "allow_receiving": {"type": ["boolean"]},
            "keep_mail_on_forward": {"type": ["boolean"]},
            "mail-domain": {"relation": "to-one", "resource": "mail-domains"},
        }
    },
    "mail-addresses:update": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "name": {"type": ["string"]},
            "password": {"type": ["string", "null"]},
            "password_confirmation": {"type": ["string", "null"]},
            "enabled": {"type": ["boolean", "null"]},
            "catchall": {"type": ["boolean"]},
            "allow_sending": {"type": ["boolean"]},
            "allow_receiving": {"type": ["boolean"]},
            "keep_mail_on_forward": {"type": ["boolean"]},
            "mail-domain": {"relation": "to-one", "resource": "mail-domains"},
            "aliases": {"relation": "to-many", "resource": "mail-address-aliases"},
        }
    },
    "mail-domains": {
        "properties": {
            "domain": {"type": ["string"]},
            "quota": {"type": ["integer"]},
            "hidden": {"type": ["boolean", "null"]},
            "enabled": {"type": ["boolean", "null"]},
            "status": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "mail-addresses": {"relation": "to-many", "resource": "mail-addresses"},
            "service-mail": {"relation": "to-one", "resource": "service-mails"},
        }
    },
    "mail-domains:base": {
        "properties": {
            "domain": {"type": ["string"]},
            "quota": {"type": ["integer"]},
            "hidden": {"type": ["boolean", "null"]},
            "enabled": {"type": ["boolean", "null"]},
        }
    },
    "mail-domains:show": {
        "properties": {
            "domain": {"type": ["string"]},
            "quota": {"type": ["integer"]},
            "hidden": {"type": ["boolean", "null"]},
            "enabled": {"type": ["boolean", "null"]},
            "status": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "mail-addresses": {"relation": "to-many", "resource": "mail-addresses"},
            "service-mail": {"relation": "to-one", "resource": "service-mails"},
        }
    },
    "mail-address-aliases": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "alias": {"type": ["string"]},
            "enabled": {"type": ["boolean"]},
            "hidden": {"type": ["boolean"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "mail-address": {"relation": "to-one", "resource": "mail-addresses"},
        }
    },
    "mail-address-aliases:base": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "alias": {"type": ["string"]},
            "enabled": {"type": ["boolean"]},
            "hidden": {"type": ["boolean"]},
        }
    },
    "mail-address-aliases:show": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "alias": {"type": ["string"]},
            "enabled": {"type": ["boolean"]},
            "hidden": {"type": ["boolean"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "mail-address": {"relation": "to-one", "resource": "mail-addresses"},
        }
    },
    "mail-address-aliases:create": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "alias": {"type": ["string"]},
            "enabled": {"type": ["boolean"]},
            "hidden": {"type": ["boolean"]},
            "mail-address": {"relation": "to-one", "resource": "mail-addresses"},
        }
    },
    "mail-address-aliases:update": {
        "properties": {
            "status": {"type": ["string", "null"]},
            "alias": {"type": ["string"]},
            "enabled": {"type": ["boolean"]},
            "hidden": {"type": ["boolean"]},
            "mail-address": {"relation": "to-one", "resource": "mail-addresses"},
        }
    },
    "service-mails": {
        "properties": {
            "name": {"type": ["string"]},
            "description": {"type": ["string"]},
            "imap_address": {"type": ["string", "null"]},
            "pop_address": {"type": ["string", "null"]},
            "smtp_address": {"type": ["string", "null"]},
            "webmail_address": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "program-instances": {
                "relation": "to-many",
                "resource": "program-instances",
            },
        }
    },
    "service-mails:base": {
        "properties": {
            "name": {"type": ["string"]},
            "description": {"type": ["string"]},
            "imap_address": {"type": ["string", "null"]},
            "pop_address": {"type": ["string", "null"]},
            "smtp_address": {"type": ["string", "null"]},
            "webmail_address": {"type": ["string", "null"]},
        }
    },
    "service-mails:show": {
        "properties": {
            "name": {"type": ["string"]},
            "description": {"type": ["string"]},
            "imap_address": {"type": ["string", "null"]},
            "pop_address": {"type": ["string", "null"]},
            "smtp_address": {"type": ["string", "null"]},
            "webmail_address": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "program-instances": {
                "relation": "to-many",
                "resource": "program-instances",
            },
        }
    },
    "mail-forwards": {
        "properties": {
            "src_address": {"type": ["string"]},
            "dst_address": {"type": ["array"]},
            "status": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "mail-domain": {"relation": "to-one", "resource": "mail-domains"},
        }
    },
    "mail-forwards:base": {
        "properties": {
            "src_address": {"type": ["string"]},
            "dst_address": {"type": ["array"]},
        }
    },
    "mail-forwards:show": {
        "properties": {
            "src_address": {"type": ["string"]},
            "dst_address": {"type": ["array"]},
            "status": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "mail-domain": {"relation": "to-one", "resource": "mail-domains"},
        }
    },
    "mail-forwards:create": {
        "properties": {
            "src_address": {"type": ["string"]},
            "dst_address": {"type": ["array"]},
            "mail-domain": {"relation": "to-one", "resource": "mail-domains"},
        }
    },
    "mail-forwards:update": {
        "properties": {
            "src_address": {"type": ["string"]},
            "dst_address": {"type": ["array"]},
            "mail-domain": {"relation": "to-one", "resource": "mail-domains"},
        }
    },
    "products": {
        "properties": {
            "name": {"type": ["string"]},
            "product_type": {"type": ["string"]},
            "price": {"type": ["number", "null"]},
            "default_bill_sequence": {"type": ["string"]},
            "invoice_description": {"type": ["string"]},
            "options": {"type": ["object", "null"]},
            "publish_start": {"type": ["string"]},
            "publish_end": {"type": ["string"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "parent": {"relation": "to-one", "resource": "products"},
            "children": {"relation": "to-many", "resource": "products"},
            "service-bundles": {"relation": "to-many", "resource": "service-bundles"},
            "tlds": {"relation": "to-many", "resource": "tlds"},
        }
    },
    "products:base": {
        "properties": {
            "name": {"type": ["string"]},
            "product_type": {"type": ["string"]},
            "price": {"type": ["number", "null"]},
            "default_bill_sequence": {"type": ["string"]},
            "invoice_description": {"type": ["string"]},
            "options": {"type": ["object", "null"]},
            "publish_start": {"type": ["string"]},
            "publish_end": {"type": ["string"]},
        }
    },
    "products:show": {
        "properties": {
            "name": {"type": ["string"]},
            "product_type": {"type": ["string"]},
            "price": {"type": ["number", "null"]},
            "default_bill_sequence": {"type": ["string"]},
            "invoice_description": {"type": ["string"]},
            "options": {"type": ["object", "null"]},
            "publish_start": {"type": ["string"]},
            "publish_end": {"type": ["string"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "parent": {"relation": "to-one", "resource": "products"},
            "children": {"relation": "to-many", "resource": "products"},
            "service-bundles": {"relation": "to-many", "resource": "service-bundles"},
            "tlds": {"relation": "to-many", "resource": "tlds"},
        }
    },
    "purchases": {
        "properties": {
            "description": {"type": ["string"]},
            "units": {"type": ["integer"]},
            "date_activation": {"type": ["string", "null"]},
            "bill_sequence": {"type": ["string", "null"]},
            "product_type": {"type": ["string", "null"]},
            "date_purchase": {"type": ["string", "null"]},
            "date_deactivation": {"type": ["string", "null"]},
            "date_next_bill": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "children": {"relation": "to-many", "resource": "purchases"},
            "parent": {"relation": "to-one", "resource": "purchases"},
            "product": {"relation": "to-one", "resource": "products"},
        }
    },
    "purchases:base": {
        "properties": {
            "description": {"type": ["string"]},
            "units": {"type": ["integer"]},
            "date_activation": {"type": ["string", "null"]},
            "bill_sequence": {"type": ["string", "null"]},
        }
    },
    "purchases:show": {
        "properties": {
            "description": {"type": ["string"]},
            "units": {"type": ["integer"]},
            "date_activation": {"type": ["string", "null"]},
            "bill_sequence": {"type": ["string", "null"]},
            "product_type": {"type": ["string", "null"]},
            "date_purchase": {"type": ["string", "null"]},
            "date_deactivation": {"type": ["string", "null"]},
            "date_next_bill": {"type": ["string", "null"]},
            "created_at": {"type": ["string", "null"]},
            "updated_at": {"type": ["string", "null"]},
            "account": {"relation": "to-one", "resource": "accounts"},
            "children": {"relation": "to-many", "resource": "purchases"},
            "parent": {"relation": "to-one", "resource": "purchases"},
            "product": {"relation": "to-one", "resource": "products"},
        }
    },
}
