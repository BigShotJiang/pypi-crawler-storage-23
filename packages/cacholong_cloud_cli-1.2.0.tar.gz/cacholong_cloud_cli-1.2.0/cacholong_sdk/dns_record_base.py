from typing import Optional
from .common import BaseController, BaseModel


class DnsRecordBaseModel(BaseModel):
    pass


class DnsRecordBase(BaseController[DnsRecordBaseModel]):
    _class = DnsRecordBaseModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "dns-records"

        super().__init__(connection, api_schema)
