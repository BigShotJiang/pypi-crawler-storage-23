from typing import Optional
from .common import BaseController, BaseModel


class MailAddressAliasShowModel(BaseModel):
    pass


class MailAddressAliasShow(BaseController[MailAddressAliasShowModel]):
    _class = MailAddressAliasShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-address-aliases"

        super().__init__(connection, api_schema)
