from typing import Optional
from .common import BaseController, BaseModel


class AddressCreateWithUserModel(BaseModel):
    pass


class AddressCreateWithUser(BaseController[AddressCreateWithUserModel]):
    _class = AddressCreateWithUserModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "addresses"
        # Use operation-specific validation for alternative create schemas
        self._operation_suffix = "create-with-user"

        super().__init__(connection, api_schema)
