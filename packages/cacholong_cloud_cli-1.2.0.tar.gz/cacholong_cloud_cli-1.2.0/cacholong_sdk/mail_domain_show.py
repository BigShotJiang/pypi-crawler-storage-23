from typing import Optional
from .common import BaseController, BaseModel


class MailDomainShowModel(BaseModel):
    pass


class MailDomainShow(BaseController[MailDomainShowModel]):
    _class = MailDomainShowModel

    def __init__(self, connection, api_schema: Optional[dict] = None):
        self._resource = "mail-domains"

        super().__init__(connection, api_schema)
