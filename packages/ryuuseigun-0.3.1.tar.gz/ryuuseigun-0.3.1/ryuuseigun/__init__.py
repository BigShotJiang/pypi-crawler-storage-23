from __future__ import annotations
from time import time
from os import urandom
from enum import StrEnum
from hashlib import sha1
from pathlib import Path
from http import HTTPStatus
from base64 import b64encode
from mimetypes import guess_type
from secrets import token_urlsafe
from logging import Logger, getLogger
from .exceptions import HTTPException
from html import escape as html_escape
from dataclasses import field, dataclass
from ssl import SSLContext, create_default_context
from http.client import HTTPConnection, HTTPSConnection
from inspect import getmro, signature, iscoroutinefunction
from urllib.parse import quote, unquote, parse_qs, urlsplit
from re import Match, compile, Pattern, finditer, escape as regex_escape
from json import loads as default_json_loads, dumps as default_json_dumps
from asyncio import wait, to_thread, create_task, open_connection, FIRST_COMPLETED
from typing import (
    Any,
    cast,
    Self,
    Union,
    Literal,
    TypeVar,
    overload,
    Iterator,
    Callable,
    Optional,
    Sequence,
    Protocol,
    Awaitable,
    TypeAlias,
    AsyncIterator,
)

#region Types
Header: TypeAlias = Union['KnownHeader', str]
HeaderValue: TypeAlias = Union[str, list[str]]
Headers: TypeAlias = dict[Header, HeaderValue]
RouteResult: TypeAlias = Any
RouteHandler: TypeAlias = Callable[..., Awaitable[RouteResult]]
ErrorHandler: TypeAlias = Callable[['Context', BaseException], Awaitable[RouteResult]]
Decorator: TypeAlias = Callable[[RouteHandler], RouteHandler]
BeforeRequestHandler: TypeAlias = Callable[[Optional['Context']], Awaitable[Optional[RouteResult]]]
AfterRequestHandler: TypeAlias = Callable[['Response'], Awaitable['Response']]
ResponseNext: TypeAlias = Callable[[], Awaitable['Response']]
ResponseMiddleware: TypeAlias = Callable[['Context', ResponseNext], Awaitable['Response']]
TeardownHandler: TypeAlias = Callable[['Context', Optional[BaseException]], Awaitable[None]]
LifespanHandler: TypeAlias = Callable[..., Awaitable[None]]
RequestMethod: TypeAlias = Literal['GET', 'HEAD', 'POST', 'PUT', 'DELETE', 'CONNECT', 'OPTIONS', 'TRACE', 'PATCH']
RequestMethods: TypeAlias = list[RequestMethod]
RouteParam: TypeAlias = Any
RouteParams: TypeAlias = dict[str, RouteParam]
ByteStream: TypeAlias = Union[AsyncIterator[bytes], Iterator[bytes]]
ResponseBodyKind: TypeAlias = Literal['body', 'stream']
FormPayload: TypeAlias = dict[str, list[str]]
JSONPayload: TypeAlias = Union[dict[str, 'JSONPayload'], list['JSONPayload'], str, int, float, bool, None]
RequestPayload: TypeAlias = Union[FormPayload, JSONPayload, bytes]
JSONLoads: TypeAlias = Callable[[Any], Any]
JSONDumps: TypeAlias = Callable[[Any], Union[str, bytes]]
LoggerLike: TypeAlias = Logger
RouteParser: TypeAlias = Callable[[str], RouteParam]
RouteFormatter: TypeAlias = Callable[[RouteParam], str]
ContentTypeMatcher: TypeAlias = Union[str, Callable[[str], bool]]
RequestPayloadParser: TypeAlias = Callable[['Request'], RequestPayload]
ResponseCoercer: TypeAlias = Callable[[Any], Optional['Response']]
SameSite: TypeAlias = Union['KnownSameSite', str]
WebSocketHandler: TypeAlias = Callable[..., Awaitable[None]]
WebSocketMessage: TypeAlias = dict[str, Any]
ErrorStage: TypeAlias = Literal[
    'asgi.query_decode',
    'asgi.header_decode',
    'asgi.content_length',
    'asgi.body_drain',
    'request.exception',
]
ErrorRenderer: TypeAlias = Callable[['ErrorRenderContext'], RouteResult]

_T = TypeVar('_T')
#endregion

_STATIC_PRECOMPRESSED_SUFFIXES: dict[str, str] = {
    'br': '.br',
    'gzip': '.gz',
}
_WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'
_HOP_BY_HOP_HEADERS = {
    'connection',
    'keep-alive',
    'proxy-authenticate',
    'proxy-authorization',
    'te',
    'trailer',
    'transfer-encoding',
    'upgrade',
}

#region Enums
class KnownHeader(StrEnum):
    """Known HTTP header names exposed as lowercase values."""
    CACHE_CONTROL = 'cache-control'
    CONNECTION = 'connection'
    KEEP_ALIVE = 'keep-alive'
    DATE = 'date'
    PRAGMA = 'pragma'
    TRAILER = 'trailer'
    TRANSFER_ENCODING = 'transfer-encoding'
    UPGRADE = 'upgrade'
    VIA = 'via'
    WARNING = 'warning'

    ACCEPT = 'accept'
    ACCEPT_CHARSET = 'accept-charset'
    ACCEPT_ENCODING = 'accept-encoding'
    ACCEPT_LANGUAGE = 'accept-language'
    ACCEPT_RANGES = 'accept-ranges'
    USER_AGENT = 'user-agent'

    HOST = 'host'
    REFERER = 'referer'
    ORIGIN = 'origin'

    AUTHORIZATION = 'authorization'
    PROXY_AUTHORIZATION = 'proxy-authorization'
    COOKIE = 'cookie'

    CONTENT_TYPE = 'content-type'
    CONTENT_LENGTH = 'content-length'

    IF_MATCH = 'if-match'
    IF_NONE_MATCH = 'if-none-match'
    IF_MODIFIED_SINCE = 'if-modified-since'
    IF_UNMODIFIED_SINCE = 'if-unmodified-since'
    IF_RANGE = 'if-range'

    RANGE = 'range'

    SERVER = 'server'
    ALLOW = 'allow'
    LOCATION = 'location'
    RETRY_AFTER = 'retry-after'

    CONTENT_ENCODING = 'content-encoding'
    CONTENT_DISPOSITION = 'content-disposition'
    CONTENT_LANGUAGE = 'content-language'
    CONTENT_LOCATION = 'content-location'
    CONTENT_RANGE = 'content-range'
    LAST_MODIFIED = 'last-modified'
    ETAG = 'etag'

    SET_COOKIE = 'set-cookie'
    WWW_AUTHENTICATE = 'www-authenticate'
    PROXY_AUTHENTICATE = 'proxy-authenticate'

    EXPIRES = 'expires'
    AGE = 'age'
    VARY = 'vary'
    LINK = 'link'

    ACCESS_CONTROL_ALLOW_ORIGIN = 'access-control-allow-origin'
    ACCESS_CONTROL_ALLOW_METHODS = 'access-control-allow-methods'
    ACCESS_CONTROL_ALLOW_HEADERS = 'access-control-allow-headers'
    ACCESS_CONTROL_ALLOW_CREDENTIALS = 'access-control-allow-credentials'
    ACCESS_CONTROL_EXPOSE_HEADERS = 'access-control-expose-headers'
    ACCESS_CONTROL_MAX_AGE = 'access-control-max-age'
    ACCESS_CONTROL_REQUEST_METHOD = 'access-control-request-method'
    ACCESS_CONTROL_REQUEST_HEADERS = 'access-control-request-headers'

    CONTENT_SECURITY_POLICY = 'content-security-policy'
    STRICT_TRANSPORT_SECURITY = 'strict-transport-security'
    X_CONTENT_TYPE_OPTIONS = 'x-content-type-options'
    X_FRAME_OPTIONS = 'x-frame-options'
    X_XSS_PROTECTION = 'x-xss-protection'
    REFERRER_POLICY = 'referrer-policy'
    PERMISSIONS_POLICY = 'permissions-policy'
    CROSS_ORIGIN_EMBEDDER_POLICY = 'cross-origin-embedder-policy'
    CROSS_ORIGIN_OPENER_POLICY = 'cross-origin-opener-policy'
    CROSS_ORIGIN_RESOURCE_POLICY = 'cross-origin-resource-policy'
    CLEAR_SITE_DATA = 'clear-site-data'

    X_FORWARDED_FOR = 'x-forwarded-for'
    X_FORWARDED_PROTO = 'x-forwarded-proto'
    X_FORWARDED_HOST = 'x-forwarded-host'
    X_FORWARDED_PORT = 'x-forwarded-port'
    X_FORWARDED_PREFIX = 'x-forwarded-prefix'
    FORWARDED = 'forwarded'

    SEC_FETCH_DEST = 'sec-fetch-dest'
    SEC_FETCH_MODE = 'sec-fetch-mode'
    SEC_FETCH_SITE = 'sec-fetch-site'
    SEC_FETCH_USER = 'sec-fetch-user'

    X_REQUEST_ID = 'x-request-id'
    X_REAL_IP = 'x-real-ip'
    X_POWERED_BY = 'x-powered-by'
    X_DNS_PREFETCH_CONTROL = 'x-dns-prefetch-control'
    X_PERMITTED_CROSS_DOMAIN_POLICIES = 'x-permitted-cross-domain-policies'
    DNT = 'dnt'
    TE = 'te'

class KnownContentType(StrEnum):
    """Common content-type values used by the framework."""
    JSON = 'application/json'
    HTML = 'text/html'
    PLAIN_TEXT = 'text/plain'
    FORM_URLENCODED = 'application/x-www-form-urlencoded'
    FORM_MULTIPART = 'multipart/form-data'
    OCTET_STREAM = 'application/octet-stream'
    JAVASCRIPT = 'application/javascript'
    XML = 'application/xml'

class KnownSameSite(StrEnum):
    """Supported SameSite cookie attribute values."""
    LAX = 'Lax'
    STRICT = 'Strict'
    NONE = 'None'

class KnownCacheDirective(StrEnum):
    """Common cache-control directives."""
    NO_CACHE = 'no-cache'
    NO_STORE = 'no-store'
    PUBLIC = 'public'
    PRIVATE = 'private'
    MUST_REVALIDATE = 'must-revalidate'
    PROXY_REVALIDATE = 'proxy-revalidate'
    MAX_AGE = 'max-age'
    S_MAXAGE = 's-maxage'
    IMMUTABLE = 'immutable'
    STALE_WHILE_REVALIDATE = 'stale-while-revalidate'
    STALE_IF_ERROR = 'stale-if-error'
#endregion

def _sanitize_header_value(value: str) -> str:
    return value.replace('\r', '').replace('\n', '')

def _encode_cookie_value(value: str) -> str:
    # Preserve existing percent-encoded sequences while preventing delimiter injection.
    return quote(value, safe="!#$%&'()*+-./:<=>?@[]^_`{|}~%")

def _append_set_cookie_header(headers: Headers, cookie: str) -> None:
    cookie = _sanitize_header_value(cookie)
    existing = headers.get(KnownHeader.SET_COOKIE.value)
    if existing is None:
        headers[KnownHeader.SET_COOKIE] = [cookie]
    else:
        if isinstance(existing, list):
            existing.append(cookie)
        else:
            headers[KnownHeader.SET_COOKIE] = [_sanitize_header_value(str(existing)), cookie]

def _normalize_headers(
    headers: Headers,
    *,
    sanitize_values: bool = False,
) -> Headers:
    normalized: Headers = {}
    for raw_key, raw_value in headers.items():
        key = str(raw_key).lower()
        values = raw_value if isinstance(raw_value, list) else [raw_value]
        for value in values:
            value_str = str(value)
            safe_value = _sanitize_header_value(value_str) if sanitize_values else value_str
            _append_request_header(normalized, key, safe_value)

    return normalized

def _encode_headers_for_asgi(headers: Headers) -> list[list[bytes]]:
    encoded: list[list[bytes]] = []
    for key, value in headers.items():
        key_str = str(key)
        values = value if isinstance(value, list) else [value]
        for header_value in values:
            safe_value = _sanitize_header_value(str(header_value))
            encoded.append([key_str.encode('utf-8'), safe_value.encode('utf-8')])

    return encoded

def _append_request_header(headers: Headers, name: str, value: str) -> None:
    key = str(name).lower()
    existing = headers.get(key)
    if existing is None:
        headers[key] = value
    elif isinstance(existing, list):
        existing.append(value)
    else:
        headers[key] = [existing, value]

def _max_content_length(headers: Headers) -> Optional[int]:
    raw_value = headers.get(KnownHeader.CONTENT_LENGTH)
    if raw_value is None:
        return None

    values = raw_value if isinstance(raw_value, list) else [raw_value]
    parsed_values: list[int] = []
    for value in values:
        try:
            parsed_values.append(int(str(value)))
        except ValueError:
            continue

    if not parsed_values:
        return None

    return max(parsed_values)

@dataclass(frozen=True)
class RouteConverter:
    """Configuration for a typed route parameter converter.

    Attributes:
        regex: Regular expression used to match the raw path segment.
        parse: Callable that converts matched text to a Python value.
        format: Callable that converts a Python value to a URL segment.
        allows_slash: Whether formatted/matched values may include `/`.
    """

    regex: str
    parse: RouteParser = str
    format: RouteFormatter = str
    allows_slash: bool = False

def _default_route_converters() -> dict[str, RouteConverter]:
    return {
        'int': RouteConverter(regex=r'\d+', parse=int, format=lambda value: str(int(value))),
        'float': RouteConverter(regex=r'\d+\.?\d*', parse=float, format=lambda value: str(float(value))),
        'path': RouteConverter(regex=r'.+', parse=str, format=str, allows_slash=True),
    }

class Blueprint:
    """A group of routes, hooks, and error handlers that share a URL prefix."""

    def __init__(self, name: str, *, url_prefix: Optional[str] = None, strict_slashes: Optional[bool] = None):
        """Create a blueprint.

        Args:
            name: Blueprint name used in endpoint naming.
            url_prefix: Optional path prefix applied to routes in this blueprint.
            strict_slashes: Optional slash behavior override for blueprint routes.
        """
        self.name = name
        self.url_prefix = url_prefix or ''
        self.strict_slashes = strict_slashes
        self._route_converters: dict[str, RouteConverter] = _default_route_converters()
        self.routes: list[Route] = []
        self.websocket_routes: list[WebSocketRoute] = []
        self.before_request_handlers: list[BeforeRequestHandler] = []
        self.after_request_handlers: list[AfterRequestHandler] = []
        self.error_handlers: dict[type, ErrorHandler] = {}

    def register_converter(
        self,
        name: str,
        *,
        regex: str,
        parse: RouteParser = str,
        format: RouteFormatter = str,
        allows_slash: bool = False,
    ) -> None:
        """Register a custom route converter for this blueprint.

        Args:
            name: Converter name used in `<name:param>` path segments.
            regex: Segment matching pattern.
            parse: Function that parses the matched string.
            format: Function that formats a value for URL generation.
            allows_slash: Whether the converter can consume `/`.

        Raises:
            ValueError: If `name` or `regex` is empty.
            TypeError: If `parse` or `format` is not callable.
        """
        if not name:
            raise ValueError('converter name cannot be empty.')
        if not regex:
            raise ValueError('converter regex cannot be empty.')
        if not callable(parse):
            raise TypeError('converter parse must be callable.')
        if not callable(format):
            raise TypeError('converter format must be callable.')

        self._route_converters[name] = RouteConverter(
            regex=regex,
            parse=parse,
            format=format,
            allows_slash=allows_slash,
        )

    def _route_pattern(self, pattern: str) -> 'RoutePattern':
        return RoutePattern(pattern, converters=self._route_converters)

    def route(
        self,
        pattern: str,
        *,
        methods: Optional[RequestMethods] = None,
        endpoint: Optional[str] = None,
        strict_slashes: Optional[bool] = None,
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a route decorator on the blueprint.

        Args:
            pattern: Route pattern, optionally containing typed params.
            methods: Allowed HTTP methods. Defaults to `['GET']`.
            endpoint: Optional endpoint name. Defaults to `"{blueprint}.{func}"`.
            strict_slashes: Per-route slash behavior override.

        Returns:
            A decorator that registers the wrapped handler.
        """
        if methods is None:
            methods = ['GET']

        def decorator(func: RouteHandler) -> RouteHandler:
            route_endpoint = endpoint or f'{self.name}.{func.__name__}'
            full_pattern = self.url_prefix + pattern

            route = Route(
                pattern=self._route_pattern(full_pattern),
                handler=func,
                methods=methods,
                endpoint=route_endpoint,
                strict_slashes=strict_slashes,
                blueprint=self.name,
            )

            self.routes.append(route)

            return func
        return decorator

    def get(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `GET` route on this blueprint."""
        return self.route(pattern, methods=['GET'], endpoint=endpoint, strict_slashes=strict_slashes)

    def head(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `HEAD` route on this blueprint."""
        return self.route(pattern, methods=['HEAD'], endpoint=endpoint, strict_slashes=strict_slashes)

    def post(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `POST` route on this blueprint."""
        return self.route(pattern, methods=['POST'], endpoint=endpoint, strict_slashes=strict_slashes)

    def put(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `PUT` route on this blueprint."""
        return self.route(pattern, methods=['PUT'], endpoint=endpoint, strict_slashes=strict_slashes)

    def delete(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `DELETE` route on this blueprint."""
        return self.route(pattern, methods=['DELETE'], endpoint=endpoint, strict_slashes=strict_slashes)

    def connect(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `CONNECT` route on this blueprint."""
        return self.route(pattern, methods=['CONNECT'], endpoint=endpoint, strict_slashes=strict_slashes)

    def options(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register an `OPTIONS` route on this blueprint."""
        return self.route(pattern, methods=['OPTIONS'], endpoint=endpoint, strict_slashes=strict_slashes)

    def trace(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `TRACE` route on this blueprint."""
        return self.route(pattern, methods=['TRACE'], endpoint=endpoint, strict_slashes=strict_slashes)

    def patch(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `PATCH` route on this blueprint."""
        return self.route(pattern, methods=['PATCH'], endpoint=endpoint, strict_slashes=strict_slashes)

    def websocket(
        self,
        pattern: str,
        *,
        endpoint: Optional[str] = None,
        strict_slashes: Optional[bool] = None,
    ) -> Callable[[WebSocketHandler], WebSocketHandler]:
        """Register a websocket route on this blueprint."""
        def decorator(func: WebSocketHandler) -> WebSocketHandler:
            route_endpoint = endpoint or f'{self.name}.{func.__name__}'
            full_pattern = self.url_prefix + pattern
            route = WebSocketRoute(
                pattern=self._route_pattern(full_pattern),
                handler=func,
                endpoint=route_endpoint,
                strict_slashes=strict_slashes,
                blueprint=self.name,
            )
            self.websocket_routes.append(route)
            return func
        return decorator

    def before_request(self, func: BeforeRequestHandler) -> BeforeRequestHandler:
        """Register a before-request hook for this blueprint."""
        self.before_request_handlers.append(func)
        return func

    def after_request(self, func: AfterRequestHandler) -> AfterRequestHandler:
        """Register an after-request hook for this blueprint."""
        self.after_request_handlers.append(func)
        return func

    def error_handler(self, exception: type) -> Callable[[ErrorHandler], ErrorHandler]:
        """Register an exception handler for this blueprint."""
        def decorator(func: ErrorHandler) -> ErrorHandler:
            self.error_handlers[exception] = func
            return func
        return decorator

    def register_blueprint(self, blueprint: 'Blueprint') -> None:
        """Nest another blueprint under this blueprint's URL prefix."""
        for route in blueprint.routes:
            full_pattern = self.url_prefix + route.pattern.pattern
            endpoint = (
                route.endpoint
                if route.endpoint.startswith(f'{self.name}.')
                else f'{self.name}.{route.endpoint}'
            )
            use_strict = (
                route.strict_slashes
                if route.strict_slashes is not None
                else blueprint.strict_slashes
                if blueprint.strict_slashes is not None
                else self.strict_slashes
            )
            nested_route = Route(
                pattern=RoutePattern(full_pattern, converters=route.pattern.converters),
                handler=route.handler,
                methods=route.methods,
                endpoint=endpoint,
                decorators=route.decorators,
                strict_slashes=use_strict,
                blueprint=self.name,
            )
            self.routes.append(nested_route)

        for route in blueprint.websocket_routes:
            full_pattern = self.url_prefix + route.pattern.pattern
            endpoint = (
                route.endpoint
                if route.endpoint.startswith(f'{self.name}.')
                else f'{self.name}.{route.endpoint}'
            )
            use_strict = (
                route.strict_slashes
                if route.strict_slashes is not None
                else blueprint.strict_slashes
                if blueprint.strict_slashes is not None
                else self.strict_slashes
            )
            nested_websocket_route = WebSocketRoute(
                pattern=RoutePattern(full_pattern, converters=route.pattern.converters),
                handler=route.handler,
                endpoint=endpoint,
                strict_slashes=use_strict,
                blueprint=self.name,
            )
            self.websocket_routes.append(nested_websocket_route)

        self.before_request_handlers.extend(blueprint.before_request_handlers)
        self.after_request_handlers.extend(blueprint.after_request_handlers)
        self.error_handlers.update(blueprint.error_handlers)
#endregion

#region Routing
@dataclass
class Route:
    """Registered route metadata and handler binding."""

    pattern: RoutePattern
    handler: RouteHandler
    methods: RequestMethods
    endpoint: str
    decorators: list[Decorator] = field(default_factory=list)
    strict_slashes: Optional[bool] = None
    blueprint: Optional[str] = None
    _resolved_handler: Optional[RouteHandler] = field(default=None, init=False, repr=False)
    _resolved_handler_accepts_ctx: Optional[bool] = field(default=None, init=False, repr=False)
    _resolved_handler_decorator_count: int = field(default=-1, init=False, repr=False)


@dataclass
class WebSocketRoute:
    """Registered websocket route metadata and handler binding."""

    pattern: RoutePattern
    handler: WebSocketHandler
    endpoint: str
    strict_slashes: Optional[bool] = None
    blueprint: Optional[str] = None

class RoutePattern:
    """Compiled representation of a route pattern."""

    def __init__(
        self,
        pattern: str,
        *,
        converters: Optional[dict[str, RouteConverter]] = None,
    ):
        self.pattern = pattern
        self.converters = dict(converters or _default_route_converters())
        self.param_names: list[str] = []
        self.param_types: list[Optional[str]] = []
        self.param_group_names: list[str] = []
        self.param_converters: list[Optional[RouteConverter]] = []
        self.segments: tuple[str, ...] = tuple()
        self.segment_count: int = 0
        self.first_segment_literal: Optional[str] = None
        self.is_static = True
        self.fixed_segment_count: Optional[int] = 0
        self.static_segment_count: int = 0
        self.typed_dynamic_segment_count: int = 0
        self.plain_dynamic_segment_count: int = 0
        self.path_converter_count: int = 0
        self.specificity: tuple[int, int, int, int, int, int] = (0, 0, 0, 0, 0, 0)
        self._analyze_segments(pattern)
        self.regex = self._compile_pattern(pattern)

    def _analyze_segments(self, pattern: str) -> None:
        normalized = pattern.strip('/')
        if not normalized:
            segments: tuple[str, ...] = tuple()
        else:
            segments = tuple(normalized.split('/'))

        self.segments = segments
        self.segment_count = len(segments)
        self.first_segment_literal = None
        self.is_static = True
        has_path_converter = False
        self.static_segment_count = 0
        self.typed_dynamic_segment_count = 0
        self.plain_dynamic_segment_count = 0
        self.path_converter_count = 0

        for i, segment in enumerate(segments):
            if segment.startswith('<') and segment.endswith('>'):
                self.is_static = False
                inner = segment[1:-1]
                converter = inner.split(':', 1)[0] if ':' in inner else None
                converter_config = self.converters.get(converter) if converter else None
                if converter_config is not None and converter_config.allows_slash:
                    has_path_converter = True
                    self.path_converter_count += 1
                elif converter_config is not None:
                    self.typed_dynamic_segment_count += 1
                else:
                    self.plain_dynamic_segment_count += 1
            elif i == 0:
                self.first_segment_literal = segment
                self.static_segment_count += 1
            else:
                self.static_segment_count += 1

        if has_path_converter:
            self.fixed_segment_count = None
        else:
            self.fixed_segment_count = len(segments)

        self.specificity = (
            1 if self.is_static else 0,
            self.static_segment_count,
            self.typed_dynamic_segment_count,
            self.plain_dynamic_segment_count,
            -self.path_converter_count,
            self.segment_count,
        )

    def _compile_pattern(self, pattern: str) -> Pattern:
        param_pattern = r'<(?:(\w+):)?(\w+)>'

        def replacer(match: Match) -> str:
            type_name = match.group(1)
            param_name = match.group(2)
            converter = self.converters.get(type_name) if type_name else None
            self.param_names.append(param_name)
            self.param_types.append(type_name)
            self.param_converters.append(converter)
            group_name = f'_p{len(self.param_group_names)}'
            self.param_group_names.append(group_name)

            converter_regex = converter.regex if converter is not None else r'[^/]+'
            return f'(?P<{group_name}>{converter_regex})'

        regex_parts: list[str] = []
        last_end = 0
        for match in finditer(param_pattern, pattern):
            static_part = pattern[last_end:match.start()]
            regex_parts.append(regex_escape(static_part))
            regex_parts.append(replacer(match))
            last_end = match.end()
        regex_parts.append(regex_escape(pattern[last_end:]))
        regex_pattern = ''.join(regex_parts)
        regex_pattern = f'^{regex_pattern}$'

        return compile(regex_pattern)

    def match(self, path: str) -> Optional[RouteParams]:
        """Match a URL path and return parsed route params when matched."""
        match = self.regex.match(path)
        if not match:
            return None

        params: RouteParams = {}
        for name, group_name, converter in zip(
            self.param_names,
            self.param_group_names,
            self.param_converters,
        ):
            value = match.group(group_name)
            value = unquote(value)

            if converter is not None:
                try:
                    value = converter.parse(value)
                except Exception:
                    return None

            params[name] = value

        return params
#endregion

#region Request/Response
@dataclass(frozen=True)
class ErrorRenderContext:
    """Error metadata passed to `Ryuuseigun.error_renderer`."""

    status: int
    phrase: str
    message: str
    code: str
    stage: ErrorStage
    exc: Optional[BaseException] = None
    request: Optional['Request'] = None
    context: Optional['Context'] = None
    allowed_methods: Optional[list[str]] = None


@dataclass(frozen=True)
class _ProxyTarget:
    scheme_http: Literal['http', 'https']
    scheme_ws: Literal['ws', 'wss']
    host: str
    port: int
    host_header: str
    base_path: str

@dataclass
class Request:
    """Represents an HTTP request and provides parsed access helpers."""

    method: str
    path: str
    query_string: str
    headers: Headers
    body: bytes = b''
    json_loads: JSONLoads = field(default=default_json_loads, repr=False)
    body_receive: Optional[Callable[[], Awaitable[dict[str, Any]]]] = field(default=None, repr=False)
    max_body_size: Optional[int] = field(default=None, repr=False)
    payload_parser: Optional[RequestPayloadParser] = field(default=None, repr=False)
    route_params: RouteParams = field(default_factory=dict)
    _query: Optional[dict[str, list[str]]] = field(default=None, init=False)
    _json: Optional[Any] = field(default=None, init=False)
    _json_loaded: bool = field(default=False, init=False)
    _json_valid: bool = field(default=True, init=False)
    _form: Optional[dict[str, list[str]]] = field(default=None, init=False)
    _cookies: Optional[dict[str, str]] = field(default=None, init=False)
    _body_fully_read: bool = field(default=True, init=False)
    _body_read_size: int = field(default=0, init=False)
    _client_disconnected: bool = field(default=False, init=False)

    def __post_init__(self) -> None:
        """Normalize headers and initialize body streaming state."""
        self.headers = _normalize_headers(self.headers, sanitize_values=False)
        self._body_fully_read = self.body_receive is None
        self._body_read_size = len(self.body)

    async def _read_next_body_chunk(self, *, enforce_limit: bool) -> Optional[bytes]:
        while not self._body_fully_read:
            if self.body_receive is None:
                self._body_fully_read = True
                return None

            message = await self.body_receive()
            message_type = message.get('type')
            if message_type == 'http.disconnect':
                self._body_fully_read = True
                self._client_disconnected = True
                return None
            if message_type != 'http.request':
                continue

            chunk = message.get('body', b'')
            if not message.get('more_body', False):
                self._body_fully_read = True

            self._body_read_size += len(chunk)
            if (
                enforce_limit
                and self.max_body_size is not None
                and self._body_read_size > self.max_body_size
            ):
                raise HTTPException(
                    413,
                    'Request body exceeds configured maximum size.',
                )

            if chunk:
                return chunk

        return None

    async def read(self) -> bytes:
        """Read and cache the full request body.

        Returns:
            The full request body bytes.

        Raises:
            HTTPException: If the configured body-size limit is exceeded.
        """
        if self._body_fully_read:
            return self.body

        chunks = [self.body] if self.body else []
        while True:
            chunk = await self._read_next_body_chunk(enforce_limit=True)
            if chunk is None:
                break
            chunks.append(chunk)

        self.body = b''.join(chunks)
        return self.body

    async def iter_body(self, *, cache: bool = False) -> AsyncIterator[bytes]:
        """Iterate request body chunks as they arrive.

        Args:
            cache: If `True`, rebuild `request.body` from streamed chunks.

        Yields:
            Sequential body chunks.

        Raises:
            HTTPException: If the configured body-size limit is exceeded.
        """
        cached_chunks: Optional[list[bytes]] = [] if cache else None
        if self.body:
            yield self.body
            if cached_chunks is not None:
                cached_chunks.append(self.body)

        while True:
            chunk = await self._read_next_body_chunk(enforce_limit=True)
            if chunk is None:
                if cached_chunks is not None:
                    self.body = b''.join(cached_chunks)
                return
            if cached_chunks is not None:
                cached_chunks.append(chunk)
            yield chunk

    async def drain_unread_body(self) -> bool:
        """Consume any unread body bytes without raising on size limits.

        Returns:
            `True` when the drained body exceeded `max_body_size`, else `False`.
        """
        if self._body_fully_read:
            return False

        over_limit = False
        while not self._body_fully_read:
            chunk = await self._read_next_body_chunk(enforce_limit=False)
            if (
                not over_limit
                and self.max_body_size is not None
                and self._body_read_size > self.max_body_size
            ):
                over_limit = True
            if chunk is None:
                continue

        return over_limit

    @property
    def client_disconnected(self) -> bool:
        """Whether the client disconnected while streaming the body."""
        return self._client_disconnected

    @property
    def query(self) -> dict[str, list[str]]:
        """Parsed query string values."""
        if self._query is None:
            self._query = parse_qs(self.query_string)

        return self._query

    @property
    def json(self) -> JSONPayload:
        """Body parsed as JSON.

        Raises:
            RuntimeError: If the body is still streamed and unread.
        """
        if not self._body_fully_read:
            raise RuntimeError('Request body is streamed. Use `await request.json_async()`.')
        if not self._json_loaded:
            try:
                self._json = self.json_loads(self.body)
                self._json_valid = True
            except Exception:
                self._json = None
                self._json_valid = False
            self._json_loaded = True

        return self._json

    @property
    def is_json_valid(self) -> bool:
        """Whether the current body is valid JSON.

        Raises:
            RuntimeError: If the body is still streamed and unread.
        """
        if not self._body_fully_read:
            raise RuntimeError('Request body is streamed. Use `await request.is_json_valid_async()`.')
        _ = self.json
        return self._json_valid

    @property
    def form(self) -> FormPayload:
        """Body parsed as URL-encoded form data.

        Raises:
            RuntimeError: If the body is still streamed and unread.
        """
        if not self._body_fully_read:
            raise RuntimeError('Request body is streamed. Use `await request.form_async()`.')
        if self._form is None:
            content_type = (self.get_header(KnownHeader.CONTENT_TYPE, '') or '').lower()
            if KnownContentType.FORM_URLENCODED in content_type:
                try:
                    self._form = parse_qs(self.body.decode('utf-8'))
                except UnicodeDecodeError:
                    self._form = {}
            else:
                self._form = {}

        return self._form

    @property
    def cookies(self) -> dict[str, str]:
        """Cookies parsed from the `Cookie` header."""
        if self._cookies is None:
            cookies: dict[str, str] = {}
            cookie_header = self.get_header(KnownHeader.COOKIE, '')
            if cookie_header:
                for chunk in cookie_header.split(';'):
                    if '=' not in chunk:
                        continue
                    name, value = chunk.split('=', 1)
                    cookies[name.strip()] = unquote(value.strip())
            self._cookies = cookies

        return self._cookies

    @property
    def payload(self) -> RequestPayload:
        """Body parsed through configured payload parser rules.

        Raises:
            RuntimeError: If the body is still streamed and unread.
        """
        if not self._body_fully_read:
            raise RuntimeError('Request body is streamed. Use `await request.payload_async()`.')
        if self.payload_parser is not None:
            return self.payload_parser(self)
        content_type = (self.get_header(KnownHeader.CONTENT_TYPE, '') or '').lower()
        if KnownContentType.JSON in content_type:
            return self.json
        if KnownContentType.FORM_URLENCODED in content_type:
            return self.form
        return self.body

    async def json_async(self) -> JSONPayload:
        """Asynchronously read and parse the body as JSON."""
        await self.read()
        return self.json

    async def is_json_valid_async(self) -> bool:
        """Asynchronously read the body and validate it as JSON."""
        _ = await self.json_async()
        return self._json_valid

    async def form_async(self) -> FormPayload:
        """Asynchronously read and parse the body as URL-encoded form data."""
        await self.read()
        return self.form

    async def payload_async(self) -> RequestPayload:
        """Asynchronously read and parse the body using payload parser rules."""
        await self.read()
        return self.payload

    def get_header(self, name: Header, default: Optional[str] = None) -> Optional[str]:
        """Get a request header value by name.

        Args:
            name: Header name (case-insensitive).
            default: Value returned when header is missing.

        Returns:
            Header value, flattened to a string when multiple values exist.
        """
        value = self.headers.get(str(name).lower())
        if value is None:
            return default
        if isinstance(value, list):
            if str(name).lower() == KnownHeader.COOKIE.value:
                return '; '.join(value)
            return ', '.join(value)
        return value

    @overload
    def route_param(self, name: str) -> RouteParam:
        """Return a parsed route parameter value."""
        ...

    @overload
    def route_param(self, name: str, *, as_type: type[_T]) -> _T:
        """Return a parsed route parameter coerced to `as_type`."""
        ...

    def route_param(self, name: str, *, as_type: Optional[type[Any]] = None) -> Any:
        """Return a route parameter, optionally coerced to a type.

        Args:
            name: Route parameter key.
            as_type: Optional type used for coercion.

        Returns:
            Parsed route parameter value.
        """
        value = self.route_params[name]
        if as_type is None or isinstance(value, as_type):
            return value

        return as_type(value)

class Response:
    """HTTP response container for buffered and streamed payloads."""

    def __init__(
        self,
        body: Union[str, bytes] = '',
        status: int = 200,
        headers: Optional[Headers] = None,
        *,
        stream: Optional[ByteStream] = None,
    ):
        """Create a response.

        Args:
            body: Buffered body value.
            status: HTTP status code.
            headers: Optional response headers.
            stream: Optional iterator/async iterator for streaming responses.
        """
        self.status = status
        self.body: Union[str, bytes] = body
        self.stream: Optional[ByteStream] = None
        self._body_kind: ResponseBodyKind = 'body'
        self.headers: Headers = _normalize_headers(dict(headers or {}), sanitize_values=True)

        if stream is not None:
            self._body_kind = 'stream'
            self.stream = stream
            self.body = b''
            self._set_default_header(KnownHeader.CONTENT_TYPE, KnownContentType.OCTET_STREAM)
        elif self._find_header_key(KnownHeader.CONTENT_TYPE) is None:
            if isinstance(self.body, str):
                self.headers[KnownHeader.CONTENT_TYPE] = f'{KnownContentType.HTML}; charset=utf-8'
            else:
                self.headers[KnownHeader.CONTENT_TYPE] = KnownContentType.OCTET_STREAM

    @classmethod
    def stream(
        cls,
        stream: ByteStream,
        status: int = 200,
        headers: Optional[Headers] = None,
    ) -> Self:
        """Create a streaming response."""
        return cls(status=status, headers=headers, stream=stream)

    @property
    def is_stream(self) -> bool:
        """Whether this response is streaming."""
        return self._body_kind != 'body'

    @property
    def is_buffered(self) -> bool:
        """Whether this response is buffered in memory."""
        return self._body_kind == 'body'

    def _find_header_key(self, name: Header) -> Optional[Header]:
        target = str(name).lower()
        if target in self.headers:
            return target
        return None

    def _set_default_header(self, name: Header, value: str) -> None:
        key = str(name).lower()
        if key not in self.headers:
            self.headers[key] = value

    def set_header(self, name: Header, value: str) -> Self:
        """Set or replace a response header."""
        self.headers[str(name).lower()] = _sanitize_header_value(value)
        return self

    def set_cookie(
        self,
        name: str,
        value: str,
        max_age: Optional[int] = None,
        path: str = '/',
        domain: Optional[str] = None,
        secure: bool = False,
        httponly: bool = False,
        samesite: Optional[SameSite] = None,
    ) -> Self:
        """Append a `Set-Cookie` header.

        Args:
            name: Cookie name.
            value: Cookie value.
            max_age: Cookie lifetime in seconds.
            path: Cookie path scope.
            domain: Optional cookie domain.
            secure: Whether to set the `Secure` attribute.
            httponly: Whether to set the `HttpOnly` attribute.
            samesite: Optional `SameSite` attribute.
        """
        cookie = f'{name}={_encode_cookie_value(value)}'
        if max_age is not None:
            cookie += f';Max-Age={max_age}'
        cookie += f';Path={path}'
        if domain:
            cookie += f';Domain={domain}'
        if secure:
            cookie += ';Secure'
        if httponly:
            cookie += ';HttpOnly'
        if samesite:
            cookie += f';SameSite={samesite}'

        _append_set_cookie_header(self.headers, cookie)

        return self

    async def iter_chunks(self) -> AsyncIterator[bytes]:
        """Yield response body bytes for ASGI sending."""
        if self._body_kind == 'body':
            body_bytes = self.body.encode('utf-8') if isinstance(self.body, str) else self.body
            if body_bytes:
                yield body_bytes
            return

        if self.stream is None:
            return

        if hasattr(self.stream, '__aiter__'):
            async for item in self.stream:  # type: ignore[misc]
                yield item.encode('utf-8') if isinstance(item, str) else item
        else:
            for item in self.stream:  # type: ignore[union-attr]
                yield item.encode('utf-8') if isinstance(item, str) else item

class StreamResponse(Response):
    """Convenience response type for stream-first handlers."""

    def __init__(
        self,
        stream: ByteStream,
        status: int = 200,
        headers: Optional[Headers] = None,
    ):
        """Create a streaming response."""
        super().__init__(status=status, headers=headers, stream=stream)


class WebSocket:
    """ASGI websocket connection helper used by websocket route handlers."""

    def __init__(
        self,
        *,
        app: 'Ryuuseigun',
        request: Request,
        receive: Callable[[], Awaitable[WebSocketMessage]],
        send: Callable[[WebSocketMessage], Awaitable[None]],
    ) -> None:
        self.app = app
        self.request = request
        self._receive = receive
        self._send = send
        self.accepted = False
        self.closed = False
        self.close_code: Optional[int] = None

    async def accept(self, *, subprotocol: Optional[str] = None, headers: Optional[Headers] = None) -> None:
        """Accept the websocket connection."""
        if self.accepted or self.closed:
            return
        message: WebSocketMessage = {'type': 'websocket.accept'}
        if subprotocol:
            message['subprotocol'] = subprotocol
        if headers:
            message['headers'] = _encode_headers_for_asgi(_normalize_headers(headers, sanitize_values=True))
        await self._send(message)
        self.accepted = True

    async def close(self, code: int = 1000, reason: str = '') -> None:
        """Close the websocket connection."""
        if self.closed:
            return
        message: WebSocketMessage = {'type': 'websocket.close', 'code': int(code)}
        if reason:
            message['reason'] = str(reason)
        await self._send(message)
        self.closed = True
        self.close_code = int(code)

    async def receive_message(self) -> Optional[WebSocketMessage]:
        """Receive the next websocket event.

        Returns:
            A raw ASGI `websocket.receive` message, or `None` after disconnect.
        """
        if self.closed:
            return None
        message = await self._receive()
        message_type = message.get('type')
        if message_type == 'websocket.disconnect':
            self.closed = True
            code = message.get('code')
            self.close_code = int(code) if code is not None else 1000
            return None
        if message_type != 'websocket.receive':
            return None
        return message

    async def receive_text(self) -> Optional[str]:
        """Receive the next text frame payload or `None` when disconnected."""
        if not self.accepted and not self.closed:
            await self.accept()
        message = await self.receive_message()
        if message is None:
            return None
        text = message.get('text')
        if text is not None:
            return str(text)
        data = message.get('bytes')
        if data is None:
            return ''
        return bytes(data).decode('utf-8', errors='replace')

    async def receive_bytes(self) -> Optional[bytes]:
        """Receive the next binary frame payload or `None` when disconnected."""
        if not self.accepted and not self.closed:
            await self.accept()
        message = await self.receive_message()
        if message is None:
            return None
        data = message.get('bytes')
        if data is not None:
            return bytes(data)
        text = message.get('text')
        if text is None:
            return b''
        return str(text).encode('utf-8')

    async def send_text(self, payload: str) -> None:
        """Send a text frame."""
        if self.closed:
            return
        if not self.accepted:
            await self.accept()
        await self._send({'type': 'websocket.send', 'text': str(payload)})

    async def send_bytes(self, payload: bytes) -> None:
        """Send a binary frame."""
        if self.closed:
            return
        if not self.accepted:
            await self.accept()
        await self._send({'type': 'websocket.send', 'bytes': bytes(payload)})

@dataclass
class _SessionRecord:
    data: dict[str, Any]
    expires_at: Optional[float]
    last_access: float

class SessionEngine(Protocol):
    """Protocol for pluggable async session storage backends."""

    async def load(self, session_id: str) -> Optional[dict[str, Any]]:
        """Load session data for a session id."""
        ...

    async def create(self) -> tuple[str, dict[str, Any]]:
        """Create and return a new `(session_id, data)` pair."""
        ...

    async def save(self, session_id: str, data: dict[str, Any]) -> None:
        """Persist session data."""
        ...

    async def destroy(self, session_id: str) -> None:
        """Delete session state for a session id."""
        ...

class InMemorySessionEngine:
    """Built-in in-process session storage backend."""

    def __init__(
        self,
        *,
        ttl: Optional[int] = None,
        purge_interval: int = 60,
        max_entries: Optional[int] = 10_000,
    ):
        """Create an in-memory session engine.

        Args:
            ttl: Optional session TTL in seconds.
            purge_interval: Seconds between expired-session purges.
            max_entries: Optional capacity limit for LRU-style eviction.

        Raises:
            ValueError: If `ttl`, `purge_interval`, or `max_entries` is invalid.
        """
        if ttl is not None and ttl <= 0:
            raise ValueError('ttl must be > 0 or None.')
        if purge_interval < 0:
            raise ValueError('purge_interval must be >= 0.')
        if max_entries is not None and max_entries <= 0:
            raise ValueError('max_entries must be > 0 or None.')

        self.ttl = ttl
        self.purge_interval = purge_interval
        self.max_entries = max_entries
        self._sessions: dict[str, _SessionRecord] = {}
        self._last_session_purge = 0.0

    def _generate_session_id(self) -> str:
        while True:
            session_id = token_urlsafe(32)
            if session_id not in self._sessions:
                return session_id

    def _is_expired(self, record: _SessionRecord, now: float) -> bool:
        return record.expires_at is not None and record.expires_at <= now

    def _touch(self, record: _SessionRecord, now: float) -> None:
        record.last_access = now
        if self.ttl is not None:
            record.expires_at = now + self.ttl

    def _purge_expired_sessions(self, now: float) -> None:
        if self.ttl is None:
            return
        if self.purge_interval > 0 and now - self._last_session_purge < self.purge_interval:
            return

        expired_ids = [
            session_id
            for session_id, record in self._sessions.items()
            if self._is_expired(record, now)
        ]
        for session_id in expired_ids:
            del self._sessions[session_id]

        self._last_session_purge = now

    def _enforce_capacity(self) -> None:
        if self.max_entries is None or len(self._sessions) <= self.max_entries:
            return

        overflow = len(self._sessions) - self.max_entries
        evict_ids = sorted(
            self._sessions.items(),
            key=lambda item: item[1].last_access,
        )[:overflow]
        for session_id, _ in evict_ids:
            self._sessions.pop(session_id, None)

    async def load(self, session_id: str) -> Optional[dict[str, Any]]:
        """Load session data by id."""
        now = time()
        self._purge_expired_sessions(now)

        record = self._sessions.get(session_id)
        if record is None:
            return None
        if self._is_expired(record, now):
            self._sessions.pop(session_id, None)
            return None

        self._touch(record, now)
        return dict(record.data)

    async def create(self) -> tuple[str, dict[str, Any]]:
        """Allocate a new session id and initial empty data."""
        now = time()
        self._purge_expired_sessions(now)

        session_id = self._generate_session_id()
        return session_id, {}

    async def save(self, session_id: str, data: dict[str, Any]) -> None:
        """Persist session data and refresh access metadata."""
        now = time()
        self._purge_expired_sessions(now)

        record = self._sessions.get(session_id)
        if record is None:
            record = _SessionRecord(data={}, expires_at=None, last_access=now)
            self._sessions[session_id] = record

        record.data = dict(data)
        self._touch(record, now)
        self._enforce_capacity()

    async def destroy(self, session_id: str) -> None:
        """Delete a session if it exists."""
        self._sessions.pop(session_id, None)

class Session:
    """Mutable session state wrapper exposed to route handlers."""

    def __init__(
        self,
        session_id: str,
        data: dict[str, Any],
        *,
        new: bool = False,
    ):
        """Create a session view.

        Args:
            session_id: Unique storage key.
            data: Session key-value payload.
            new: Whether this session was just created for the request.
        """
        self.id = session_id
        self.data = data
        self.new = new
        self.destroyed = False
        self.modified = False

    def get(self, key: str, default: Any = None) -> Any:
        """Get a value from the session payload."""
        return self.data.get(key, default)

    def __getitem__(self, key: str) -> Any:
        return self.data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.data[key] = value
        self.modified = True

    def __delitem__(self, key: str) -> None:
        del self.data[key]
        self.modified = True

    def __contains__(self, key: str) -> bool:
        return key in self.data

    def __iter__(self) -> Iterator[str]:
        return iter(self.data)

    def __len__(self) -> int:
        return len(self.data)

    def items(self):
        """Return key/value pairs from the session payload."""
        return self.data.items()

    def clear(self) -> None:
        """Clear all session values and mark the session modified."""
        self.data.clear()
        self.modified = True

    def destroy(self) -> None:
        """Mark the session for deletion and clear its local data."""
        if self.destroyed:
            return
        self.destroyed = True
        self.modified = True
        self.data.clear()

@dataclass
class Context:
    """Per-request context passed into handlers and hooks."""

    request: Request
    app: 'Ryuuseigun'
    g: dict[str, Any] = field(default_factory=dict)
    _after_request_callbacks: list[AfterRequestHandler] = field(default_factory=list, init=False)
    _session: Optional[Session] = field(default=None, init=False)

    def url_for(self, endpoint: str, *, full_url: bool = False, **params: Any) -> str:
        """Build a URL for an endpoint from request context."""
        if full_url and not self.app.base_url:
            relative_url = self.app.url_for(endpoint, full_url=False, **params)
            return self.app._build_full_url_from_request(relative_url, self.request)

        return self.app.url_for(endpoint, full_url=full_url, **params)

    def after_this_request(self, func: AfterRequestHandler) -> AfterRequestHandler:
        """Register a one-off after-request callback for this request."""
        self._after_request_callbacks.append(func)
        return func

    @property
    def session(self) -> Session:
        """Return the already-loaded session.

        Raises:
            RuntimeError: If session state has not been loaded asynchronously.
        """
        if self._session is None:
            raise RuntimeError(
                'Sessions are async-only. Use `await ctx.session_async()`.',
            )
        return self._session

    async def session_async(self) -> Session:
        """Load or create and return the request session."""
        if self._session is None:
            self._session = await self.app._get_or_create_session(self.request)
        return self._session
#endregion

class Ryuuseigun:
    def __init__(
        self,
        name: str,
        base_url: str = '',
        *,
        trust_proxy_headers: bool = False,
        strict_slashes: bool = True,
        public_dir: Optional[str] = None,
        static_precompressed: bool = False,
        static_precompressed_encodings: Sequence[str] = ('br', 'gzip'),
        dev_proxy_target: Optional[str] = None,
        dev_proxy_exclude_prefixes: Sequence[str] = ('/api',),
        dev_proxy_fallback_only: bool = True,
        spa_fallback_index: Optional[str] = None,
        spa_fallback_exclude_prefixes: Sequence[str] = (),
        spa_fallback_require_html_accept: bool = True,
        session_cookie_name: str = 'session',
        session_cookie_path: str = '/',
        session_cookie_secure: bool = False,
        session_cookie_httponly: bool = True,
        session_cookie_samesite: Optional[SameSite] = KnownSameSite.LAX,
        session_ttl: Optional[int] = None,
        session_purge_interval: int = 60,
        session_max_entries: Optional[int] = 10_000,
        session_engine: Optional[SessionEngine] = None,
        max_request_body_size: Optional[int] = 16 * 1024 * 1024,
        loads: JSONLoads = default_json_loads,
        dumps: JSONDumps = default_json_dumps,
        error_renderer: Optional[ErrorRenderer] = None,
        logger: Optional[LoggerLike] = None,
    ):
        """Create a Ryuuseigun application instance.

        Args:
            name: Application name, usually `__name__`.
            base_url: Optional base URL used for absolute URL generation.
            trust_proxy_headers: Trust forwarding headers for URL generation.
            strict_slashes: Whether routes treat trailing slashes as distinct.
            public_dir: Optional directory served for static files.
            static_precompressed: Serve precompressed static variants when available.
            static_precompressed_encodings: Preferred encodings in selection order.
            dev_proxy_target: Optional upstream dev server (for example Vite at
                `http://127.0.0.1:5173`).
            dev_proxy_exclude_prefixes: Path prefixes that should never be proxied.
            dev_proxy_fallback_only: If `True`, proxy only when no static file/route matches.
            spa_fallback_index: Optional static file path (for example `/index.html`) served
                when a request has no route/static match and qualifies for SPA fallback.
            spa_fallback_exclude_prefixes: Path prefixes where SPA fallback is disabled.
            spa_fallback_require_html_accept: When `True`, fallback requires `Accept: text/html`.
            session_cookie_name: Session cookie key name.
            session_cookie_path: Session cookie path scope.
            session_cookie_secure: Set `Secure` on session cookies.
            session_cookie_httponly: Set `HttpOnly` on session cookies.
            session_cookie_samesite: Optional `SameSite` on session cookies.
            session_ttl: Optional in-memory session TTL in seconds.
            session_purge_interval: Interval for in-memory expired session purge.
            session_max_entries: Optional in-memory session capacity limit.
            session_engine: Optional custom async session backend.
            max_request_body_size: Optional maximum request body size in bytes.
            loads: JSON parser callable.
            dumps: JSON serializer callable.
            error_renderer: Optional callback for rendering framework-generated errors.
            logger: Optional logger instance.

        Raises:
            ValueError: If numeric configuration values are invalid.
            TypeError: If callables or logger/session engine are invalid.
        """
        if session_ttl is not None and session_ttl <= 0:
            raise ValueError('session_ttl must be > 0 or None.')
        if session_purge_interval < 0:
            raise ValueError('session_purge_interval must be >= 0.')
        if session_max_entries is not None and session_max_entries <= 0:
            raise ValueError('session_max_entries must be > 0 or None.')
        if max_request_body_size is not None and max_request_body_size <= 0:
            raise ValueError('max_request_body_size must be > 0 or None.')
        if not callable(loads):
            raise TypeError('loads must be callable.')
        if not callable(dumps):
            raise TypeError('dumps must be callable.')
        if not isinstance(static_precompressed, bool):
            raise TypeError('static_precompressed must be bool.')
        if isinstance(static_precompressed_encodings, str):
            raise TypeError('static_precompressed_encodings must be a sequence of encodings.')
        if dev_proxy_target is not None and not isinstance(dev_proxy_target, str):
            raise TypeError('dev_proxy_target must be str or None.')
        if isinstance(dev_proxy_exclude_prefixes, str):
            raise TypeError('dev_proxy_exclude_prefixes must be a sequence of path prefixes.')
        if not isinstance(dev_proxy_fallback_only, bool):
            raise TypeError('dev_proxy_fallback_only must be bool.')
        if spa_fallback_index is not None and not isinstance(spa_fallback_index, str):
            raise TypeError('spa_fallback_index must be str or None.')
        if isinstance(spa_fallback_exclude_prefixes, str):
            raise TypeError('spa_fallback_exclude_prefixes must be a sequence of path prefixes.')
        if not isinstance(spa_fallback_require_html_accept, bool):
            raise TypeError('spa_fallback_require_html_accept must be bool.')
        if error_renderer is not None and not callable(error_renderer):
            raise TypeError('error_renderer must be callable.')
        if logger is not None and not isinstance(logger, Logger):
            raise TypeError('logger must be a logging.Logger instance or None.')

        normalized_static_precompressed_encodings: list[str] = []
        for raw_encoding in static_precompressed_encodings:
            if not isinstance(raw_encoding, str):
                raise TypeError('static_precompressed_encodings must contain only strings.')
            encoding = raw_encoding.strip().lower()
            if not encoding:
                raise ValueError('static_precompressed_encodings cannot contain empty values.')
            if encoding not in _STATIC_PRECOMPRESSED_SUFFIXES:
                supported = ', '.join(sorted(_STATIC_PRECOMPRESSED_SUFFIXES))
                raise ValueError(
                    f'Unsupported static precompressed encoding: {encoding}. Supported: {supported}.',
                )
            normalized_static_precompressed_encodings.append(encoding)
        if static_precompressed and not normalized_static_precompressed_encodings:
            raise ValueError(
                'static_precompressed_encodings must contain at least one encoding when '
                'static_precompressed is enabled.',
            )

        proxy_target: Optional[_ProxyTarget] = None
        normalized_dev_proxy_target: Optional[str] = None
        if dev_proxy_target is not None:
            raw_target = dev_proxy_target.strip()
            if not raw_target:
                raise ValueError('dev_proxy_target cannot be empty.')
            parsed_target = urlsplit(raw_target)
            if parsed_target.scheme not in ('http', 'https', 'ws', 'wss'):
                raise ValueError(
                    'dev_proxy_target must use one of: http, https, ws, wss.',
                )
            if not parsed_target.hostname:
                raise ValueError('dev_proxy_target must include a host.')
            if parsed_target.query or parsed_target.fragment:
                raise ValueError('dev_proxy_target cannot include query or fragment.')
            if parsed_target.username is not None or parsed_target.password is not None:
                raise ValueError('dev_proxy_target does not support user-info in URL.')

            scheme_http: Literal['http', 'https'] = (
                'https' if parsed_target.scheme in ('https', 'wss') else 'http'
            )
            scheme_ws: Literal['ws', 'wss'] = (
                'wss' if parsed_target.scheme in ('https', 'wss') else 'ws'
            )
            default_port = 443 if scheme_http == 'https' else 80
            port = parsed_target.port or default_port
            base_path = parsed_target.path.rstrip('/')
            host = parsed_target.hostname
            if host is None:
                raise ValueError('dev_proxy_target must include a host.')
            if parsed_target.port is None:
                host_header = host
            else:
                host_header = f'{host}:{port}'

            proxy_target = _ProxyTarget(
                scheme_http=scheme_http,
                scheme_ws=scheme_ws,
                host=host,
                port=port,
                host_header=host_header,
                base_path=base_path,
            )
            normalized_dev_proxy_target = raw_target

        normalized_dev_proxy_excluded_prefixes: list[str] = []
        for raw_prefix in dev_proxy_exclude_prefixes:
            if not isinstance(raw_prefix, str):
                raise TypeError('dev_proxy_exclude_prefixes must contain only strings.')
            prefix = raw_prefix.strip()
            if not prefix:
                raise ValueError('dev_proxy_exclude_prefixes cannot contain empty values.')
            if not prefix.startswith('/'):
                prefix = f'/{prefix}'
            if prefix != '/':
                prefix = prefix.rstrip('/')
            normalized_dev_proxy_excluded_prefixes.append(prefix)

        normalized_spa_index: Optional[str] = None
        if spa_fallback_index is not None:
            normalized_index = spa_fallback_index.strip()
            if not normalized_index:
                raise ValueError('spa_fallback_index cannot be empty.')
            if not normalized_index.startswith('/'):
                normalized_index = f'/{normalized_index}'
            normalized_spa_index = normalized_index

        normalized_excluded_prefixes: list[str] = []
        for raw_prefix in spa_fallback_exclude_prefixes:
            if not isinstance(raw_prefix, str):
                raise TypeError('spa_fallback_exclude_prefixes must contain only strings.')
            prefix = raw_prefix.strip()
            if not prefix:
                raise ValueError('spa_fallback_exclude_prefixes cannot contain empty values.')
            if not prefix.startswith('/'):
                prefix = f'/{prefix}'
            if prefix != '/':
                prefix = prefix.rstrip('/')
            normalized_excluded_prefixes.append(prefix)

        self.name = name
        self.base_url = base_url
        self.trust_proxy_headers = trust_proxy_headers
        self.strict_slashes = strict_slashes
        self.public_dir = public_dir
        self.static_precompressed = static_precompressed
        self.static_precompressed_encodings = tuple(
            dict.fromkeys(normalized_static_precompressed_encodings),
        )
        self.dev_proxy_target = normalized_dev_proxy_target
        self.dev_proxy_exclude_prefixes = tuple(
            dict.fromkeys(normalized_dev_proxy_excluded_prefixes),
        )
        self.dev_proxy_fallback_only = dev_proxy_fallback_only
        self._dev_proxy_target = proxy_target
        self.spa_fallback_index = normalized_spa_index
        self.spa_fallback_exclude_prefixes = tuple(dict.fromkeys(normalized_excluded_prefixes))
        self.spa_fallback_require_html_accept = spa_fallback_require_html_accept
        self.session_cookie_name = session_cookie_name
        self.session_cookie_path = session_cookie_path
        self.session_cookie_secure = session_cookie_secure
        self.session_cookie_httponly = session_cookie_httponly
        self.session_cookie_samesite = session_cookie_samesite
        self.session_ttl = session_ttl
        self.session_purge_interval = session_purge_interval
        self.session_max_entries = session_max_entries
        self.max_request_body_size = max_request_body_size
        self.loads = loads
        self.dumps = dumps
        self.error_renderer: ErrorRenderer = error_renderer or self._default_error_renderer
        self.logger = logger if logger is not None else getLogger(__name__)
        self._route_converters: dict[str, RouteConverter] = _default_route_converters()
        self._request_payload_parsers: list[tuple[Callable[[str], bool], RequestPayloadParser]] = []
        self._response_coercers: list[ResponseCoercer] = []
        self._install_default_request_payload_parsers()
        self._install_default_response_coercers()

        if session_engine is None:
            self.session_engine: SessionEngine = InMemorySessionEngine(
                ttl=session_ttl,
                purge_interval=session_purge_interval,
                max_entries=session_max_entries,
            )
        else:
            missing_methods = [
                method_name
                for method_name in ('load', 'create', 'save', 'destroy')
                if not callable(getattr(session_engine, method_name, None))
            ]
            if missing_methods:
                missing = ', '.join(missing_methods)
                raise TypeError(f'session_engine is missing required callable methods: {missing}.')
            self.session_engine = session_engine
        non_async_methods = [
            method_name
            for method_name in ('load', 'create', 'save', 'destroy')
            if not iscoroutinefunction(getattr(self.session_engine, method_name, None))
        ]
        if non_async_methods:
            methods = ', '.join(non_async_methods)
            raise TypeError(f'session_engine methods must be async: {methods}.')

        self.routes: list[Route] = []
        self.websocket_routes: list[WebSocketRoute] = []
        self.blueprints: list[Blueprint] = []
        self.before_request_handlers: list[BeforeRequestHandler] = []
        self.after_request_handlers: list[AfterRequestHandler] = []
        self.teardown_handlers: list[TeardownHandler] = []
        self.startup_handlers: list[LifespanHandler] = []
        self.shutdown_handlers: list[LifespanHandler] = []
        self.error_handlers: dict[type, ErrorHandler] = {}
        self._blueprint_before_request_handlers: dict[str, list[BeforeRequestHandler]] = {}
        self._blueprint_after_request_handlers: dict[str, list[AfterRequestHandler]] = {}
        self._blueprint_error_handlers: dict[str, dict[type, ErrorHandler]] = {}
        self._endpoint_map: dict[str, Route] = {}
        self._handler_accepts_ctx_cache: dict[Callable[..., Any], bool] = {}
        self._route_resolution_cache: dict[
            tuple[str, str],
            tuple[Optional[Route], Optional[tuple[tuple[str, RouteParam], ...]], tuple[str, ...]],
        ] = {}
        self._route_cache_max_size = 4096
        self._route_indexes_dirty = True
        self._http_routes_by_index: list[Route] = []
        self._http_exact_route_indices: dict[str, list[int]] = {}
        self._http_dynamic_route_indices: dict[Optional[str], list[int]] = {}

    def _cache_set(self, cache: dict[Any, Any], key: Any, value: Any, max_size: int) -> None:
        cache[key] = value
        if len(cache) > max_size:
            cache.pop(next(iter(cache)))

    def _invalidate_route_resolution_cache(self) -> None:
        self._route_resolution_cache.clear()
        self._route_indexes_dirty = True
        self._http_routes_by_index.clear()
        self._http_exact_route_indices.clear()
        self._http_dynamic_route_indices.clear()

    @staticmethod
    def _path_segment_info(path: str) -> tuple[Optional[str], int]:
        normalized = path.strip('/')
        if not normalized:
            return None, 0

        segments = normalized.split('/')
        return segments[0], len(segments)

    @staticmethod
    def _toggle_trailing_slash(path: str) -> str:
        if path == '/':
            return path
        if path.endswith('/'):
            normalized = path.rstrip('/')
            return normalized or '/'
        return f'{path}/'

    @staticmethod
    def _route_is_strict(route: Union[Route, WebSocketRoute], default_strict: bool) -> bool:
        if route.strict_slashes is None:
            return default_strict
        return route.strict_slashes

    def _route_sort_key(self, route_index: int) -> tuple[int, int, int, int, int, int, int]:
        route = self._http_routes_by_index[route_index]
        return route.pattern.specificity + (-route_index,)

    def _websocket_route_sort_key(self, route_index: int) -> tuple[int, int, int, int, int, int, int]:
        route = self.websocket_routes[route_index]
        return route.pattern.specificity + (-route_index,)

    def _ensure_route_indexes(self) -> None:
        if not self._route_indexes_dirty:
            return

        self._http_routes_by_index = list(self.routes)
        self._http_exact_route_indices = {}
        self._http_dynamic_route_indices = {}
        for index, route in enumerate(self._http_routes_by_index):
            pattern = route.pattern
            if pattern.is_static:
                self._http_exact_route_indices.setdefault(pattern.pattern, []).append(index)
            else:
                bucket_key = pattern.first_segment_literal
                self._http_dynamic_route_indices.setdefault(bucket_key, []).append(index)

        self._route_indexes_dirty = False

    def _callable_accepts_ctx(self, func: Callable[..., Any]) -> bool:
        cached = self._handler_accepts_ctx_cache.get(func)
        if cached is not None:
            return cached

        accepts_ctx = bool(signature(func).parameters)
        self._handler_accepts_ctx_cache[func] = accepts_ctx

        return accepts_ctx

    def _resolve_route_handler(self, route: Route) -> tuple[RouteHandler, bool]:
        if (
            route._resolved_handler is None
            or route._resolved_handler_decorator_count != len(route.decorators)
        ):
            handler = route.handler
            for decorator in reversed(route.decorators):
                handler = decorator(handler)
            route._resolved_handler = handler
            route._resolved_handler_accepts_ctx = self._callable_accepts_ctx(handler)
            route._resolved_handler_decorator_count = len(route.decorators)

        return route._resolved_handler, bool(route._resolved_handler_accepts_ctx)

    def register_converter(
        self,
        name: str,
        *,
        regex: str,
        parse: RouteParser = str,
        format: RouteFormatter = str,
        allows_slash: bool = False,
    ) -> None:
        """Register a custom route converter on the app.

        Args:
            name: Converter name used in `<name:param>` segments.
            regex: Segment matching pattern.
            parse: Function that parses matched strings.
            format: Function that formats values for URL generation.
            allows_slash: Whether this converter may consume `/`.

        Raises:
            ValueError: If `name` or `regex` is empty.
            TypeError: If `parse` or `format` is not callable.
        """
        if not name:
            raise ValueError('converter name cannot be empty.')
        if not regex:
            raise ValueError('converter regex cannot be empty.')
        if not callable(parse):
            raise TypeError('converter parse must be callable.')
        if not callable(format):
            raise TypeError('converter format must be callable.')

        self._route_converters[name] = RouteConverter(
            regex=regex,
            parse=parse,
            format=format,
            allows_slash=allows_slash,
        )
        self._invalidate_route_resolution_cache()

    def _route_pattern(self, pattern: str) -> RoutePattern:
        return RoutePattern(pattern, converters=self._route_converters)

    def route(
            self,
            pattern: str,
            *,
            methods: Optional[RequestMethods] = None,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a route decorator on the app.

        Args:
            pattern: Route pattern, optionally containing typed params.
            methods: Allowed HTTP methods. Defaults to `['GET']`.
            endpoint: Optional endpoint name. Defaults to handler name.
            strict_slashes: Per-route slash behavior override.

        Returns:
            A decorator that registers the wrapped handler.
        """
        if methods is None:
            methods = ['GET']

        def decorator(func: RouteHandler) -> RouteHandler:
            route_endpoint = endpoint or func.__name__
            use_strict = strict_slashes if strict_slashes is not None else self.strict_slashes
            route = Route(
                pattern=self._route_pattern(pattern),
                handler=func,
                methods=methods,
                endpoint=route_endpoint,
                strict_slashes=use_strict,
            )
            self.routes.append(route)
            self._endpoint_map[route_endpoint] = route
            self._invalidate_route_resolution_cache()
            return func
        return decorator

    #region HTTP method shortcuts
    def get(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `GET` route."""
        return self.route(pattern, methods=['GET'], endpoint=endpoint, strict_slashes=strict_slashes)

    def head(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `HEAD` route."""
        return self.route(pattern, methods=['HEAD'], endpoint=endpoint, strict_slashes=strict_slashes)

    def post(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `POST` route."""
        return self.route(pattern, methods=['POST'], endpoint=endpoint, strict_slashes=strict_slashes)

    def put(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `PUT` route."""
        return self.route(pattern, methods=['PUT'], endpoint=endpoint, strict_slashes=strict_slashes)

    def delete(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `DELETE` route."""
        return self.route(pattern, methods=['DELETE'], endpoint=endpoint, strict_slashes=strict_slashes)

    def connect(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `CONNECT` route."""
        return self.route(pattern, methods=['CONNECT'], endpoint=endpoint, strict_slashes=strict_slashes)

    def options(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register an `OPTIONS` route."""
        return self.route(pattern, methods=['OPTIONS'], endpoint=endpoint, strict_slashes=strict_slashes)

    def trace(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `TRACE` route."""
        return self.route(pattern, methods=['TRACE'], endpoint=endpoint, strict_slashes=strict_slashes)

    def patch(
            self,
            pattern: str,
            *,
            endpoint: Optional[str] = None,
            strict_slashes: Optional[bool] = None
    ) -> Callable[[RouteHandler], RouteHandler]:
        """Register a `PATCH` route."""
        return self.route(pattern, methods=['PATCH'], endpoint=endpoint, strict_slashes=strict_slashes)

    def websocket(
        self,
        pattern: str,
        *,
        endpoint: Optional[str] = None,
        strict_slashes: Optional[bool] = None,
    ) -> Callable[[WebSocketHandler], WebSocketHandler]:
        """Register a websocket route."""
        def decorator(func: WebSocketHandler) -> WebSocketHandler:
            route_endpoint = endpoint or func.__name__
            use_strict = strict_slashes if strict_slashes is not None else self.strict_slashes
            route = WebSocketRoute(
                pattern=self._route_pattern(pattern),
                handler=func,
                endpoint=route_endpoint,
                strict_slashes=use_strict,
            )
            self.websocket_routes.append(route)
            return func
        return decorator
    #endregion

    def register_blueprint(self, blueprint: Blueprint) -> None:
        """Register a blueprint and merge its routes/hooks/handlers."""
        self.blueprints.append(blueprint)

        for route in blueprint.routes:
            use_strict = (
                route.strict_slashes
                if route.strict_slashes is not None
                else blueprint.strict_slashes
                if blueprint.strict_slashes is not None
                else self.strict_slashes
            )
            app_route = Route(
                pattern=RoutePattern(route.pattern.pattern, converters=route.pattern.converters),
                handler=route.handler,
                methods=route.methods,
                endpoint=route.endpoint,
                decorators=route.decorators,
                strict_slashes=use_strict,
                blueprint=route.blueprint,
            )
            self.routes.append(app_route)
            self._endpoint_map[route.endpoint] = app_route

        for route in blueprint.websocket_routes:
            use_strict = (
                route.strict_slashes
                if route.strict_slashes is not None
                else blueprint.strict_slashes
                if blueprint.strict_slashes is not None
                else self.strict_slashes
            )
            app_websocket_route = WebSocketRoute(
                pattern=RoutePattern(route.pattern.pattern, converters=route.pattern.converters),
                handler=route.handler,
                endpoint=route.endpoint,
                strict_slashes=use_strict,
                blueprint=route.blueprint,
            )
            self.websocket_routes.append(app_websocket_route)

        self._blueprint_before_request_handlers.setdefault(blueprint.name, []).extend(
            blueprint.before_request_handlers,
        )
        self._blueprint_after_request_handlers.setdefault(blueprint.name, []).extend(
            blueprint.after_request_handlers,
        )
        self._blueprint_error_handlers.setdefault(blueprint.name, {}).update(
            blueprint.error_handlers,
        )
        self._invalidate_route_resolution_cache()

    def before_request(self, func: BeforeRequestHandler) -> BeforeRequestHandler:
        """Register a global before-request hook."""
        self.before_request_handlers.append(func)
        return func

    def after_request(self, func: AfterRequestHandler) -> AfterRequestHandler:
        """Register a global after-request hook."""
        self.after_request_handlers.append(func)
        return func

    def teardown_context(self, func: TeardownHandler) -> TeardownHandler:
        """Register a teardown handler that always runs after each request."""
        self.teardown_handlers.append(func)
        return func

    def on_startup(self, func: LifespanHandler) -> LifespanHandler:
        """Register an ASGI lifespan startup handler."""
        self.startup_handlers.append(func)
        return func

    def on_shutdown(self, func: LifespanHandler) -> LifespanHandler:
        """Register an ASGI lifespan shutdown handler."""
        self.shutdown_handlers.append(func)
        return func

    def error_handler(self, exception: type) -> Callable[[ErrorHandler], ErrorHandler]:
        """Register an application-level exception handler."""
        def decorator(func: ErrorHandler) -> ErrorHandler:
            self.error_handlers[exception] = func
            return func
        return decorator

    @staticmethod
    def _first_header_token(value: Optional[str]) -> Optional[str]:
        if not value:
            return None
        token = value.split(',', 1)[0].strip()
        return token or None

    @classmethod
    def _forwarded_header_param(cls, value: Optional[str], key: str) -> Optional[str]:
        first_value = cls._first_header_token(value)
        if not first_value:
            return None

        for part in first_value.split(';'):
            name, separator, raw_value = part.partition('=')
            if not separator:
                continue
            if name.strip().lower() != key:
                continue
            parsed = raw_value.strip().strip('"')
            if parsed:
                return parsed

        return None

    def _build_full_url_from_request(self, url: str, request: Request) -> str:
        proto: Optional[str] = None
        host: Optional[str] = None

        if self.trust_proxy_headers:
            proto = self._first_header_token(request.get_header(KnownHeader.X_FORWARDED_PROTO))
            if proto is None:
                proto = self._forwarded_header_param(
                    request.get_header(KnownHeader.FORWARDED),
                    'proto',
                )

            host = self._first_header_token(request.get_header(KnownHeader.X_FORWARDED_HOST))
            if host is None:
                host = self._forwarded_header_param(
                    request.get_header(KnownHeader.FORWARDED),
                    'host',
                )

        if proto is None:
            proto = 'http'

        if host is None:
            host = self._first_header_token(request.get_header(KnownHeader.HOST))
        if host is None:
            if self.trust_proxy_headers:
                raise ValueError('full_url requires base_url or a Host/X-Forwarded-Host/Forwarded header.')

            raise ValueError('full_url requires base_url or a Host header.')

        if url.startswith('/'):
            return f'{proto}://{host}{url}'

        return f'{proto}://{host}/{url}'

    def url_for(
        self,
        endpoint: str,
        *,
        full_url: bool = False,
        **params: Any,
    ) -> str:
        """Build a URL path (or full URL) for an endpoint.

        Args:
            endpoint: Registered endpoint name.
            full_url: If `True`, include scheme and host.
            **params: Route parameter values used to fill placeholders.

        Returns:
            Generated URL string.

        Raises:
            ValueError: If endpoint is unknown or required params are missing.
        """
        route = self._endpoint_map.get(endpoint)
        if not route:
            raise ValueError(f'Unknown endpoint: {endpoint}')

        pattern = route.pattern.pattern
        url = pattern
        missing_params = [name for name in route.pattern.param_names if name not in params]
        if missing_params:
            missing = ', '.join(sorted(set(missing_params)))
            raise ValueError(f'Missing route params for endpoint {endpoint}: {missing}')

        for name, type_name, converter in zip(
            route.pattern.param_names,
            route.pattern.param_types,
            route.pattern.param_converters,
        ):
            value = params[name]

            if converter is None:
                raw_value = str(value)
                safe = ''
                placeholder = f'<{name}>'
            else:
                raw_value = str(converter.format(value))
                safe = '/' if converter.allows_slash else ''
                if type_name is None:
                    placeholder = f'<{name}>'
                else:
                    placeholder = f'<{type_name}:{name}>'

            encoded_value = quote(raw_value, safe=safe)
            url = url.replace(placeholder, encoded_value)

        if not full_url:
            return url

        if not self.base_url:
            raise ValueError('full_url requires base_url to be set.')

        base_url = self.base_url.rstrip('/')
        if url.startswith('/'):
            return f'{base_url}{url}'

        return f'{base_url}/{url}'

    @staticmethod
    def _normalize_session_create_result(result: Any) -> tuple[str, dict[str, Any]]:
        if not isinstance(result, tuple) or len(result) != 2:
            raise TypeError('session_engine.create() must return (session_id, dict).')

        session_id, data = result
        if not isinstance(session_id, str):
            raise TypeError('session_engine.create() must return (session_id: str, dict).')

        if not isinstance(data, dict):
            raise TypeError('session_engine.create() must return (session_id, dict).')

        return session_id, data

    async def _get_or_create_session(self, request: Request) -> Session:
        session_id = request.cookies.get(self.session_cookie_name)
        if session_id:
            loaded = await self.session_engine.load(session_id)
            if loaded is not None:
                if not isinstance(loaded, dict):
                    raise TypeError('session_engine.load() must return dict or None.')

                return Session(session_id, dict(loaded), new=False)

        created = await self.session_engine.create()
        session_id, data = self._normalize_session_create_result(created)

        return Session(session_id, dict(data), new=True)

    async def _persist_session(self, session: Session) -> None:
        if session.destroyed:
            await self.session_engine.destroy(session.id)
            return

        await self.session_engine.save(session.id, session.data)

    async def _apply_session_cookie(
        self,
        ctx: Context,
        response: Response,
    ) -> Response:
        session = ctx._session
        if session is None:
            return response

        if session.destroyed:
            await self._persist_session(session)
            response.set_cookie(
                self.session_cookie_name,
                '',
                max_age=0,
                path=self.session_cookie_path,
                secure=self.session_cookie_secure,
                httponly=self.session_cookie_httponly,
                samesite=self.session_cookie_samesite,
            )
            return response

        if session.new and not session.modified and not session.data:
            return response

        should_set_cookie = session.new

        await self._persist_session(session)

        if should_set_cookie:
            response.set_cookie(
                self.session_cookie_name,
                session.id,
                path=self.session_cookie_path,
                secure=self.session_cookie_secure,
                httponly=self.session_cookie_httponly,
                samesite=self.session_cookie_samesite,
            )

        return response

    @staticmethod
    def _parse_accept_encoding(value: Optional[str]) -> dict[str, float]:
        if not value:
            return {}

        parsed: dict[str, float] = {}
        for chunk in value.split(','):
            token = chunk.strip()
            if not token:
                continue
            parts = [part.strip() for part in token.split(';')]
            encoding = parts[0].lower()
            if not encoding:
                continue

            quality = 1.0
            for part in parts[1:]:
                name, separator, raw_value = part.partition('=')
                if not separator or name.strip().lower() != 'q':
                    continue
                try:
                    quality = float(raw_value.strip())
                except ValueError:
                    quality = 0.0
                break

            quality = min(1.0, max(0.0, quality))
            previous = parsed.get(encoding)
            if previous is None or quality > previous:
                parsed[encoding] = quality

        return parsed

    @staticmethod
    def _accept_encoding_allows(encoding: str, accepted: dict[str, float]) -> bool:
        if not accepted:
            return False
        value = accepted.get(encoding)
        if value is not None:
            return value > 0
        wildcard = accepted.get('*')
        if wildcard is not None:
            return wildcard > 0
        return False

    def _select_static_representation(
        self,
        fs_path: Path,
        accept_encoding: Optional[str],
    ) -> tuple[Path, Optional[str]]:
        if not self.static_precompressed:
            return fs_path, None

        accepted = self._parse_accept_encoding(accept_encoding)
        for encoding in self.static_precompressed_encodings:
            if not self._accept_encoding_allows(encoding, accepted):
                continue

            suffix = _STATIC_PRECOMPRESSED_SUFFIXES[encoding]
            candidate = Path(f'{fs_path}{suffix}')
            if candidate.is_file():
                return candidate, encoding

        return fs_path, None

    async def _try_static_response(
        self,
        path: str,
        method: RequestMethod,
        *,
        accept_encoding: Optional[str] = None,
    ) -> Optional[Response]:
        if not self.public_dir or method not in ('GET', 'HEAD'):
            return None

        request_path = unquote(path).lstrip('/')
        if not request_path:
            return None

        base_dir = Path(self.public_dir).resolve()
        fs_path = (base_dir / request_path).resolve()
        if not fs_path.is_relative_to(base_dir):
            return None

        if not fs_path.is_file():
            return None

        selected_path, selected_encoding = self._select_static_representation(
            fs_path,
            accept_encoding,
        )

        try:
            file_size = await to_thread(lambda: selected_path.stat().st_size)
        except OSError:
            raise HTTPException(403)

        # Probe readability before returning a streaming response.
        try:
            handle = await to_thread(open, selected_path, 'rb')
            await to_thread(handle.close)
        except OSError:
            raise HTTPException(403)

        content_type, _ = guess_type(fs_path)
        headers: Headers = {
            KnownHeader.CONTENT_TYPE: content_type or KnownContentType.OCTET_STREAM,
            KnownHeader.CONTENT_LENGTH: str(file_size),
        }
        if self.static_precompressed:
            headers[KnownHeader.VARY] = KnownHeader.ACCEPT_ENCODING
            if selected_encoding is not None:
                headers[KnownHeader.CONTENT_ENCODING] = selected_encoding

        if method == 'HEAD':
            return Response(body=b'', status=200, headers=headers)

        chunk_size = 64 * 1024

        async def stream_file() -> AsyncIterator[bytes]:
            handle = await to_thread(open, selected_path, 'rb')
            try:
                while True:
                    chunk = await to_thread(handle.read, chunk_size)
                    if not chunk:
                        return
                    yield chunk
            finally:
                await to_thread(handle.close)

        return StreamResponse(stream=stream_file(), status=200, headers=headers)

    @staticmethod
    def _path_looks_like_file(path: str) -> bool:
        normalized = path.rstrip('/')
        if not normalized:
            return False

        last_segment = normalized.rsplit('/', 1)[-1]

        return '.' in last_segment

    def _path_has_spa_excluded_prefix(self, path: str) -> bool:
        for prefix in self.spa_fallback_exclude_prefixes:
            if prefix == '/':
                return True
            if path == prefix or path.startswith(f'{prefix}/'):
                return True

        return False

    def _request_accepts_html(self, request: Request) -> bool:
        accept = (request.get_header(KnownHeader.ACCEPT, '') or '').lower()
        return 'text/html' in accept

    async def _try_spa_fallback_response(self, request: Request) -> Optional[Response]:
        if self.spa_fallback_index is None:
            return None
        if request.method not in ('GET', 'HEAD'):
            return None
        if self._path_has_spa_excluded_prefix(request.path):
            return None
        if self._path_looks_like_file(request.path):
            return None
        if self.spa_fallback_require_html_accept and not self._request_accepts_html(request):
            return None

        return await self._try_static_response(
            self.spa_fallback_index,
            cast(RequestMethod, request.method),
            accept_encoding=request.get_header(KnownHeader.ACCEPT_ENCODING),
        )

    def _path_has_dev_proxy_excluded_prefix(self, path: str) -> bool:
        for prefix in self.dev_proxy_exclude_prefixes:
            if prefix == '/':
                return True
            if path == prefix or path.startswith(f'{prefix}/'):
                return True

        return False

    @staticmethod
    def _join_proxy_path(base_path: str, path: str) -> str:
        normalized_path = path if path.startswith('/') else f'/{path}'
        if not base_path:
            return normalized_path

        return f'{base_path.rstrip("/")}/{normalized_path.lstrip("/")}'

    def _dev_proxy_request_target(self, path: str, query_string: str) -> str:
        target = self._dev_proxy_target
        if target is None:
            raise RuntimeError('dev proxy target is not configured.')

        request_target = self._join_proxy_path(target.base_path, path)

        if query_string:
            return f'{request_target}?{query_string}'

        return request_target

    @staticmethod
    def _flatten_request_header_value(name: str, value: HeaderValue) -> str:
        if isinstance(value, list):
            if name == KnownHeader.COOKIE.value:
                return '; '.join(str(item) for item in value)

            return ', '.join(str(item) for item in value)

        return str(value)

    @staticmethod
    def _proxy_response_headers(headers: list[tuple[str, str]]) -> Headers:
        proxied_headers: Headers = {}
        for name, value in headers:
            lower_name = name.lower()
            if lower_name in _HOP_BY_HOP_HEADERS:
                continue

            _append_request_header(proxied_headers, lower_name, value)

        return proxied_headers

    def _proxy_request_headers(self, request: Request) -> dict[str, str]:
        target = self._dev_proxy_target
        if target is None:
            raise RuntimeError('dev proxy target is not configured.')

        forwarded: dict[str, str] = {'host': target.host_header}
        for raw_name, raw_value in request.headers.items():
            name = str(raw_name).lower()
            if name in _HOP_BY_HOP_HEADERS or name == KnownHeader.HOST.value:
                continue

            forwarded[name] = self._flatten_request_header_value(name, raw_value)

        return forwarded

    def _proxy_http_request_blocking(
        self,
        request: Request,
        body: bytes,
    ) -> tuple[int, list[tuple[str, str]], bytes]:
        target = self._dev_proxy_target
        if target is None:
            raise RuntimeError('dev proxy target is not configured.')

        connection: HTTPConnection | HTTPSConnection
        if target.scheme_http == 'https':
            connection = HTTPSConnection(target.host, target.port, timeout=30)
        else:
            connection = HTTPConnection(target.host, target.port, timeout=30)

        try:
            connection.request(
                request.method,
                self._dev_proxy_request_target(request.path, request.query_string),
                body=body if body else None,
                headers=self._proxy_request_headers(request),
            )
            response = connection.getresponse()
            response_body = response.read()
            response_headers = [(name, value) for name, value in response.getheaders()]

            return response.status, response_headers, response_body
        finally:
            connection.close()

    async def _try_dev_proxy_response(self, request: Request) -> Optional[Response]:
        if self._dev_proxy_target is None:
            return None
        if self._path_has_dev_proxy_excluded_prefix(request.path):
            return None

        body = await request.read()
        try:
            status, raw_headers, response_body = await to_thread(
                self._proxy_http_request_blocking,
                request,
                body,
            )
        except Exception:
            self.logger.exception(
                'Failed to reach development proxy for %s %s.',
                request.method,
                request.path,
            )
            raise HTTPException(502, 'Failed to reach development proxy.')

        return Response(
            body=response_body,
            status=status,
            headers=self._proxy_response_headers(raw_headers),
        )

    @staticmethod
    def _encode_ws_frame(opcode: int, payload: bytes, *, masked: bool) -> bytes:
        fin_opcode = 0x80 | (opcode & 0x0F)
        payload_len = len(payload)
        mask_bit = 0x80 if masked else 0x00

        if payload_len < 126:
            header = bytearray([fin_opcode, mask_bit | payload_len])
        elif payload_len <= 0xFFFF:
            header = bytearray([fin_opcode, mask_bit | 126])
            header.extend(payload_len.to_bytes(2, 'big'))
        else:
            header = bytearray([fin_opcode, mask_bit | 127])
            header.extend(payload_len.to_bytes(8, 'big'))

        if not masked:
            return bytes(header) + payload

        mask_key = urandom(4)
        masked_payload = bytes(byte ^ mask_key[i % 4] for i, byte in enumerate(payload))
        return bytes(header) + mask_key + masked_payload

    @staticmethod
    async def _read_ws_frame(reader: Any) -> tuple[bool, int, bytes]:
        first_two = await reader.readexactly(2)
        first = first_two[0]
        second = first_two[1]

        fin = bool(first & 0x80)
        opcode = first & 0x0F
        masked = bool(second & 0x80)
        payload_len = second & 0x7F
        if payload_len == 126:
            payload_len = int.from_bytes(await reader.readexactly(2), 'big')
        elif payload_len == 127:
            payload_len = int.from_bytes(await reader.readexactly(8), 'big')

        mask_key = await reader.readexactly(4) if masked else b''
        payload = await reader.readexactly(payload_len)
        if masked:
            payload = bytes(byte ^ mask_key[i % 4] for i, byte in enumerate(payload))

        return fin, opcode, payload

    async def _open_dev_proxy_websocket(
        self,
        scope: dict[str, Any],
    ) -> tuple[Any, Any, dict[str, str]]:
        target = self._dev_proxy_target
        if target is None:
            raise RuntimeError('dev proxy target is not configured.')

        tls_context: Optional[SSLContext] = None
        if target.scheme_ws == 'wss':
            tls_context = create_default_context()

        reader, writer = await open_connection(
            host=target.host,
            port=target.port,
            ssl=tls_context,
            server_hostname=target.host if tls_context else None,
        )

        raw_query = scope.get('query_string', b'')
        if isinstance(raw_query, bytes):
            query_string = raw_query.decode('latin-1')
        else:
            query_string = str(raw_query or '')
        path = str(scope.get('path', '/') or '/')
        request_target = self._dev_proxy_request_target(path, query_string)

        ws_key = b64encode(urandom(16)).decode('ascii')
        request_lines = [
            f'GET {request_target} HTTP/1.1',
            f'Host: {target.host_header}',
            'Upgrade: websocket',
            'Connection: Upgrade',
            f'Sec-WebSocket-Key: {ws_key}',
            'Sec-WebSocket-Version: 13',
        ]

        incoming_headers = scope.get('headers', []) or []
        for raw_name, raw_value in incoming_headers:
            try:
                name = raw_name.decode('latin-1').lower()
                value = raw_value.decode('latin-1')
            except Exception:
                continue
            if name in _HOP_BY_HOP_HEADERS or name in ('host', 'sec-websocket-key'):
                continue
            if name == 'sec-websocket-version':
                continue
            if name == 'sec-websocket-extensions':
                continue
            request_lines.append(f'{name}: {value}')

        writer.write('\r\n'.join(request_lines).encode('latin-1') + b'\r\n\r\n')
        await writer.drain()

        status_line = await reader.readline()
        if not status_line:
            raise RuntimeError('Empty websocket handshake response from dev proxy.')
        try:
            _version, status_code_raw, _reason = status_line.decode('latin-1').strip().split(' ', 2)
            status_code = int(status_code_raw)
        except Exception as exc:
            raise RuntimeError('Malformed websocket handshake response from dev proxy.') from exc

        response_headers: dict[str, str] = {}
        while True:
            line = await reader.readline()
            if line in (b'', b'\r\n'):
                break

            decoded = line.decode('latin-1').rstrip('\r\n')
            name, separator, value = decoded.partition(':')
            if not separator:
                continue

            response_headers[name.strip().lower()] = value.strip()

        if status_code != 101:
            raise RuntimeError(f'Dev proxy websocket upgrade failed with status {status_code}.')

        expected_accept = b64encode(sha1(f'{ws_key}{_WS_GUID}'.encode('ascii')).digest()).decode('ascii')
        if response_headers.get('sec-websocket-accept') != expected_accept:
            raise RuntimeError('Invalid websocket accept key from dev proxy.')

        return reader, writer, response_headers

    async def _relay_client_to_upstream_ws(self, receive: Callable, writer: Any) -> None:
        while True:
            message = await receive()
            message_type = message.get('type')
            if message_type == 'websocket.receive':
                if message.get('text') is not None:
                    payload = str(message['text']).encode('utf-8')
                    writer.write(self._encode_ws_frame(0x1, payload, masked=True))
                    await writer.drain()
                elif message.get('bytes') is not None:
                    payload = bytes(message['bytes'])
                    writer.write(self._encode_ws_frame(0x2, payload, masked=True))
                    await writer.drain()
            elif message_type == 'websocket.disconnect':
                code = int(message.get('code') or 1000)
                writer.write(self._encode_ws_frame(0x8, code.to_bytes(2, 'big'), masked=True))
                await writer.drain()
                return

    async def _relay_upstream_to_client_ws(self, reader: Any, writer: Any, send: Callable) -> None:
        fragment_opcode: Optional[int] = None
        fragment_payloads: list[bytes] = []
        while True:
            fin, opcode, payload = await self._read_ws_frame(reader)
            if opcode == 0x9:  # ping
                writer.write(self._encode_ws_frame(0xA, payload, masked=True))
                await writer.drain()
                continue
            if opcode == 0xA:  # pong
                continue
            if opcode == 0x8:  # close
                close_code = 1000
                if len(payload) >= 2:
                    close_code = int.from_bytes(payload[:2], 'big')
                await send({'type': 'websocket.close', 'code': close_code})
                return

            if opcode in (0x1, 0x2):
                if fin:
                    if opcode == 0x1:
                        await send({'type': 'websocket.send', 'text': payload.decode('utf-8', errors='replace')})
                    else:
                        await send({'type': 'websocket.send', 'bytes': payload})

                    continue
                fragment_opcode = opcode
                fragment_payloads = [payload]
                continue

            if opcode == 0x0 and fragment_opcode is not None:
                fragment_payloads.append(payload)
                if not fin:
                    continue

                combined = b''.join(fragment_payloads)
                if fragment_opcode == 0x1:
                    await send({'type': 'websocket.send', 'text': combined.decode('utf-8', errors='replace')})
                else:
                    await send({'type': 'websocket.send', 'bytes': combined})
                fragment_opcode = None
                fragment_payloads = []
                continue

    async def _try_dev_proxy_websocket(self, scope: dict[str, Any], receive: Callable, send: Callable) -> bool:
        target = self._dev_proxy_target
        if target is None:
            return False

        path = str(scope.get('path', '/') or '/')
        if self._path_has_dev_proxy_excluded_prefix(path):
            return False

        connect_message = await receive()
        if connect_message.get('type') != 'websocket.connect':
            await send({'type': 'websocket.close', 'code': 1002})
            return True

        try:
            reader, writer, response_headers = await self._open_dev_proxy_websocket(scope)
        except Exception:
            self.logger.exception(
                'Failed to open dev proxy websocket for path %s.',
                path,
            )
            await send({'type': 'websocket.close', 'code': 1011})
            return True

        accept_message: dict[str, Any] = {'type': 'websocket.accept'}
        subprotocol = response_headers.get('sec-websocket-protocol')
        if subprotocol:
            accept_message['subprotocol'] = subprotocol
        await send(accept_message)

        client_task = create_task(self._relay_client_to_upstream_ws(receive, writer))
        upstream_task = create_task(self._relay_upstream_to_client_ws(reader, writer, send))
        done, pending = await wait(
            {client_task, upstream_task},
            return_when=FIRST_COMPLETED,
        )
        for task in pending:
            task.cancel()
        for task in done:
            exc = task.exception()
            if exc is not None:
                self.logger.exception(
                    'Dev proxy websocket relay failed.',
                    exc_info=(type(exc), exc, exc.__traceback__),
                )
                await send({'type': 'websocket.close', 'code': 1011})
                break

        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass

        return True

    def _resolve_route(
        self,
        path: str,
        method: str,
    ) -> tuple[Optional[tuple[Route, RouteParams]], list[str]]:
        self._ensure_route_indexes()
        cache_key = (path, method)
        cached = self._route_resolution_cache.get(cache_key)
        if cached is not None:
            cached_route, frozen_params, cached_allowed_methods = cached
            if cached_route is not None and frozen_params is not None:
                return (cached_route, dict(frozen_params)), list(cached_allowed_methods)

            return None, list(cached_allowed_methods)

        first_segment, segment_count = self._path_segment_info(path)
        path_variants: list[tuple[str, int]] = [(path, segment_count)]
        if path != '/':
            alt_path = self._toggle_trailing_slash(path)
            if alt_path != path:
                _, alt_segment_count = self._path_segment_info(alt_path)
                path_variants.append((alt_path, alt_segment_count))

        candidate_indices: list[int] = []
        for candidate_path, _ in path_variants:
            candidate_indices.extend(self._http_exact_route_indices.get(candidate_path, []))

        candidate_indices.extend(self._http_dynamic_route_indices.get(first_segment, []))

        if first_segment is not None:
            candidate_indices.extend(self._http_dynamic_route_indices.get(None, []))

        seen_indices: set[int] = set(candidate_indices)
        ordered_candidate_indices = sorted(
            seen_indices,
            key=self._route_sort_key,
            reverse=True,
        )

        methods_for_path: list[str] = []
        for index in ordered_candidate_indices:
            route = self._http_routes_by_index[index]
            pattern = route.pattern
            route_is_strict = self._route_is_strict(route, self.strict_slashes)
            variants_to_match = path_variants[:1] if route_is_strict else path_variants

            params: Optional[RouteParams] = None
            for candidate_path, candidate_segment_count in variants_to_match:
                fixed_segment_count = pattern.fixed_segment_count
                if (
                    fixed_segment_count is not None
                    and candidate_segment_count != fixed_segment_count
                ):
                    continue

                params = route.pattern.match(candidate_path)
                if params is not None:
                    break

            if params is None:
                continue

            method_allowed = method in route.methods or (method == 'HEAD' and 'GET' in route.methods)
            if method_allowed:
                self._cache_set(
                    self._route_resolution_cache,
                    cache_key,
                    (route, tuple(params.items()), tuple()),
                    self._route_cache_max_size,
                )
                return (route, params), []

            methods_for_path.extend(route.methods)
            if 'GET' in route.methods:
                methods_for_path.append('HEAD')

        # Preserve registration order while removing duplicates.
        allowed_methods = list(dict.fromkeys(methods_for_path))
        self._cache_set(
            self._route_resolution_cache,
            cache_key,
            (None, None, tuple(allowed_methods)),
            self._route_cache_max_size,
        )

        return None, allowed_methods

    def _resolve_websocket_route(self, path: str) -> Optional[tuple[WebSocketRoute, RouteParams]]:
        _, segment_count = self._path_segment_info(path)
        path_variants: list[tuple[str, int]] = [(path, segment_count)]
        if path != '/':
            alt_path = self._toggle_trailing_slash(path)
            if alt_path != path:
                _, alt_segment_count = self._path_segment_info(alt_path)
                path_variants.append((alt_path, alt_segment_count))

        ordered_candidate_indices = sorted(
            range(len(self.websocket_routes)),
            key=self._websocket_route_sort_key,
            reverse=True,
        )
        for index in ordered_candidate_indices:
            route = self.websocket_routes[index]
            pattern = route.pattern
            route_is_strict = self._route_is_strict(route, self.strict_slashes)
            variants_to_match = path_variants[:1] if route_is_strict else path_variants

            params: Optional[RouteParams] = None
            for candidate_path, candidate_segment_count in variants_to_match:
                fixed_segment_count = pattern.fixed_segment_count
                if (
                    fixed_segment_count is not None
                    and candidate_segment_count != fixed_segment_count
                ):
                    continue

                params = pattern.match(candidate_path)
                if params is not None:
                    break

            if params is not None:
                return route, params

        return None

    def _match_route(self, path: str, method: str) -> Optional[tuple[Route, RouteParams]]:
        match, _ = self._resolve_route(path, method)
        return match

    def _allowed_methods_for_path(self, path: str) -> list[str]:
        _, allowed_methods = self._resolve_route(path, '__allowed__')
        return allowed_methods

    @staticmethod
    def _normalize_content_type_matcher(matcher: ContentTypeMatcher) -> Callable[[str], bool]:
        if isinstance(matcher, str):
            needle = matcher.lower()

            def matches(content_type: str) -> bool:
                return needle in content_type

            return matches
        if callable(matcher):
            return matcher

        raise TypeError('matcher must be a content-type substring or callable.')

    def add_request_payload_parser(
        self,
        matcher: ContentTypeMatcher,
        parser: RequestPayloadParser,
        *,
        first: bool = False,
    ) -> None:
        """Register a custom request payload parser.

        Args:
            matcher: Content-type substring or predicate callable.
            parser: Parser callable that returns parsed request payload.
            first: Insert at the front of parser chain.

        Raises:
            TypeError: If `parser` is not callable.
        """
        if not callable(parser):
            raise TypeError('parser must be callable.')

        normalized_matcher = self._normalize_content_type_matcher(matcher)
        entry = (normalized_matcher, parser)

        if first:
            self._request_payload_parsers.insert(0, entry)
        else:
            self._request_payload_parsers.append(entry)

    def clear_request_payload_parsers(self) -> None:
        """Remove all request payload parsers."""
        self._request_payload_parsers.clear()

    def _install_default_request_payload_parsers(self) -> None:
        self.add_request_payload_parser(KnownContentType.JSON, lambda request: request.json)
        self.add_request_payload_parser(KnownContentType.FORM_URLENCODED, lambda request: request.form)

    def _parse_request_payload(self, request: Request) -> RequestPayload:
        content_type = (request.get_header(KnownHeader.CONTENT_TYPE, '') or '').lower()
        for matcher, parser in self._request_payload_parsers:
            if matcher(content_type):
                return parser(request)

        return request.body

    def add_response_coercer(
        self,
        coercer: ResponseCoercer,
        *,
        first: bool = False,
    ) -> None:
        """Register a response coercer for handler return values.

        Args:
            coercer: Callable returning `Response` or `None`.
            first: Insert at the front of coercer chain.

        Raises:
            TypeError: If `coercer` is not callable.
        """
        if not callable(coercer):
            raise TypeError('coercer must be callable.')
        if first:
            self._response_coercers.insert(0, coercer)
        else:
            self._response_coercers.append(coercer)

    def clear_response_coercers(self) -> None:
        """Remove all response coercers."""
        self._response_coercers.clear()

    def _install_default_response_coercers(self) -> None:
        self.add_response_coercer(self._coerce_response_instance)
        self.add_response_coercer(self._coerce_response_tuple)
        self.add_response_coercer(self._coerce_response_dict)
        self.add_response_coercer(self._coerce_response_fallback)

    def _coerce_response_instance(self, result: Any) -> Optional[Response]:
        if isinstance(result, Response):
            return result

        return None

    def _coerce_response_tuple(self, result: Any) -> Optional[Response]:
        if not isinstance(result, tuple):
            return None

        if len(result) == 2:
            body, status = result
            if isinstance(body, dict):
                return self._json_response(body, status=status)

            return Response(body=body, status=status)

        if len(result) == 3:
            body, status, headers = result
            if isinstance(body, dict):
                return self._json_response(body, status=status, headers=headers)

            return Response(body=body, status=status, headers=headers)

        raise ValueError('Tuple must be (body, status) or (body, status, headers)')

    def _coerce_response_dict(self, result: Any) -> Optional[Response]:
        if isinstance(result, dict):
            return self._json_response(result)

        return None

    @staticmethod
    def _coerce_response_fallback(result: Any) -> Optional[Response]:
        return Response(body=result)

    @staticmethod
    def _headers_have_content_type(headers: Headers) -> bool:
        return KnownHeader.CONTENT_TYPE.value in headers

    def _json_response(
        self,
        payload: dict[str, Any],
        *,
        status: int = 200,
        headers: Optional[Headers] = None,
    ) -> Response:
        body = self.dumps(payload)
        if not isinstance(body, (str, bytes)):
            raise TypeError('dumps must return str or bytes.')

        resolved_headers: Headers = dict(headers or {})
        if not self._headers_have_content_type(resolved_headers):
            resolved_headers[KnownHeader.CONTENT_TYPE] = KnownContentType.JSON

        return Response(body=body, status=status, headers=resolved_headers)

    def _make_response(self, result: RouteResult) -> Response:
        for coercer in self._response_coercers:
            response = coercer(result)
            if response is None:
                continue

            if not isinstance(response, Response):
                raise TypeError('response coercers must return Response or None.')

            return response

        raise TypeError(f'No response coercer handled result type: {type(result).__name__}')

    async def _run_before_handlers(
        self,
        ctx: Context,
        handlers: list[BeforeRequestHandler],
    ) -> Optional[Response]:
        for handler in handlers:
            if self._callable_accepts_ctx(handler):
                result = await handler(ctx)
            else:
                result = await handler()

            if result is not None:
                return self._make_response(result)

        return None

    async def _run_after_handlers(
        self,
        ctx: Context,
        response: Response,
        handlers: list[AfterRequestHandler],
        *,
        include_after_this_request_callbacks: bool = False,
    ) -> Response:
        for handler in handlers:
            response = await handler(response)

        if include_after_this_request_callbacks:
            for handler in ctx._after_request_callbacks:
                response = await handler(response)

        return response

    async def _run_response_middleware_chain(
        self,
        ctx: Context,
        terminal_handler: ResponseNext,
        middlewares: list[ResponseMiddleware],
    ) -> Response:
        async def dispatch(index: int) -> Response:
            if index >= len(middlewares):
                return await terminal_handler()

            middleware = middlewares[index]

            async def next_call() -> Response:
                return await dispatch(index + 1)

            return await middleware(ctx, next_call)

        return await dispatch(0)

    def _app_hook_middleware(self) -> ResponseMiddleware:
        async def middleware(ctx: Context, next_call: ResponseNext) -> Response:
            early_response = await self._run_before_handlers(ctx, self.before_request_handlers)
            if early_response is None:
                response = await next_call()
            else:
                response = early_response

            return await self._run_after_handlers(
                ctx,
                response,
                self.after_request_handlers,
                include_after_this_request_callbacks=True,
            )

        return middleware

    def _blueprint_hook_middleware(self, blueprint_name: str) -> ResponseMiddleware:
        before_handlers = self._blueprint_before_request_handlers.get(blueprint_name, [])
        after_handlers = self._blueprint_after_request_handlers.get(blueprint_name, [])

        async def middleware(ctx: Context, next_call: ResponseNext) -> Response:
            early_response = await self._run_before_handlers(ctx, before_handlers)
            if early_response is None:
                response = await next_call()
            else:
                response = early_response

            return await self._run_after_handlers(ctx, response, after_handlers)

        return middleware

    def _error_response_middleware(
        self,
        blueprint_name_getter: Callable[[], Optional[str]],
        error_sink: Callable[[BaseException], None],
    ) -> ResponseMiddleware:
        async def middleware(ctx: Context, next_call: ResponseNext) -> Response:
            try:
                return await next_call()
            except Exception as e:
                error_sink(e)
                return await self._handle_error(ctx, e, blueprint_name=blueprint_name_getter())

        return middleware

    @staticmethod
    def _status_phrase(status: int) -> str:
        try:
            return HTTPStatus(status).phrase
        except ValueError:
            return 'Unknown Status'

    @staticmethod
    def _default_error_code(
        *,
        status: int,
        stage: ErrorStage,
        exc: Optional[BaseException],
    ) -> str:
        if stage == 'asgi.query_decode':
            return 'malformed_query_utf8'
        if stage == 'asgi.header_decode':
            return 'malformed_header_utf8'
        if stage in ('asgi.content_length', 'asgi.body_drain'):
            return 'request_body_too_large'
        if isinstance(exc, HTTPException):
            return f'http_{status}'
        if status >= 500:
            return 'internal_server_error'
        return f'http_{status}'

    @staticmethod
    def _default_error_renderer(error: ErrorRenderContext) -> RouteResult:
        escaped_phrase = html_escape(error.phrase)
        escaped_message = html_escape(error.message)
        return Response(
            body=f'<h1>{error.status} {escaped_phrase}</h1><p>{escaped_message}</p>',
            status=error.status,
        )

    def _render_error_response(self, error: ErrorRenderContext) -> Response:
        rendered = self.error_renderer(error)
        response = self._make_response(rendered)
        if response.status == 200 and error.status != 200:
            response.status = error.status
        if error.allowed_methods:
            response.set_header(KnownHeader.ALLOW, ', '.join(error.allowed_methods))
        return response

    async def _run_teardown(self, ctx: Context, exc: Optional[BaseException]) -> None:
        for handler in self.teardown_handlers:
            try:
                await handler(ctx, exc)
            except Exception:
                self.logger.exception('Error in teardown handler.')

    async def _handle_error(
        self,
        ctx: Context,
        exc: BaseException,
        *,
        blueprint_name: Optional[str] = None,
    ) -> Response:
        allowed_methods = getattr(exc, 'allowed_methods', None)

        if blueprint_name:
            blueprint_error_handlers = self._blueprint_error_handlers.get(blueprint_name, {})
            for exc_type in getmro(type(exc)):
                if exc_type in blueprint_error_handlers:
                    handler = blueprint_error_handlers[exc_type]
                    result = await handler(ctx, exc)
                    response = self._make_response(result)
                    if allowed_methods:
                        response.set_header(KnownHeader.ALLOW, ', '.join(allowed_methods))

                    return response

        for exc_type in getmro(type(exc)):
            if exc_type in self.error_handlers:
                handler = self.error_handlers[exc_type]
                result = await handler(ctx, exc)
                response = self._make_response(result)
                if allowed_methods:
                    response.set_header(KnownHeader.ALLOW, ', '.join(allowed_methods))

                return response

        raw_status = getattr(exc, 'status_code', 500)
        try:
            status = int(raw_status)
        except (TypeError, ValueError):
            status = 500

        phrase = self._status_phrase(status)
        message = str(exc) or phrase
        if status >= 500:
            self.logger.exception(
                'Unhandled request exception for %s %s.',
                ctx.request.method,
                ctx.request.path,
                exc_info=(type(exc), exc, exc.__traceback__),
            )
        return self._render_error_response(
            ErrorRenderContext(
                status=status,
                phrase=phrase,
                message=message,
                code=self._default_error_code(
                    status=status,
                    stage='request.exception',
                    exc=exc,
                ),
                stage='request.exception',
                exc=exc,
                request=ctx.request,
                context=ctx,
                allowed_methods=allowed_methods,
            )
        )

    async def _run_lifespan_handlers(self, handlers: list[LifespanHandler]) -> None:
        for handler in handlers:
            if self._callable_accepts_ctx(handler):
                await handler(self)
            else:
                await handler()

    async def _handle_lifespan(self, receive: Callable, send: Callable) -> None:
        while True:
            message = await receive()
            if message['type'] == 'lifespan.startup':
                try:
                    await self._run_lifespan_handlers(self.startup_handlers)
                except Exception as e:
                    self.logger.exception('Startup handler failed.')
                    await send({'type': 'lifespan.startup.failed', 'message': str(e)})
                    return

                await send({'type': 'lifespan.startup.complete'})
            elif message['type'] == 'lifespan.shutdown':
                try:
                    await self._run_lifespan_handlers(self.shutdown_handlers)
                except Exception as e:
                    self.logger.exception('Shutdown handler failed.')
                    await send({'type': 'lifespan.shutdown.failed', 'message': str(e)})
                    return

                await send({'type': 'lifespan.shutdown.complete'})

                return

    async def _handle_websocket_scope(self, scope: dict[str, Any], receive: Callable, send: Callable) -> bool:
        path = str(scope.get('path', '/') or '/')
        raw_query = scope.get('query_string', b'')
        if isinstance(raw_query, bytes):
            try:
                query_string = raw_query.decode('utf-8')
            except UnicodeDecodeError:
                await send({'type': 'websocket.close', 'code': 1002})
                return True
        else:
            query_string = str(raw_query or '')

        headers: Headers = {}
        for raw_name, raw_value in scope.get('headers', []):
            try:
                header_name = raw_name.decode('utf-8').lower()
                header_value = raw_value.decode('utf-8')
            except UnicodeDecodeError:
                await send({'type': 'websocket.close', 'code': 1002})
                return True
            _append_request_header(headers, header_name, header_value)

        match = self._resolve_websocket_route(path)
        if match is None:
            return False

        connect_message = await receive()
        if connect_message.get('type') != 'websocket.connect':
            await send({'type': 'websocket.close', 'code': 1002})
            return True

        route, params = match
        request = Request(
            method='GET',
            path=path,
            query_string=query_string,
            headers=headers,
            body=b'',
            json_loads=self.loads,
            payload_parser=self._parse_request_payload,
            max_body_size=self.max_request_body_size,
        )
        request.route_params = params

        ctx = Context(request=request, app=self)
        if self.session_cookie_name in request.cookies:
            ctx._session = await self._get_or_create_session(request)

        websocket = WebSocket(
            app=self,
            request=request,
            receive=receive,
            send=send,
        )

        handler_exc: Optional[BaseException] = None
        try:
            await websocket.accept()
            handler = route.handler
            param_count = len(signature(handler).parameters)
            if param_count == 0:
                await handler()
            elif param_count == 1:
                await handler(websocket)
            else:
                await handler(websocket, ctx)
        except Exception as exc:
            handler_exc = exc
            self.logger.exception('Websocket handler failed.')
            if not websocket.closed:
                await websocket.close(1011)
        finally:
            await self._run_teardown(ctx, handler_exc)

        if not websocket.closed:
            await websocket.close(1000)

        return True

    async def _handle_request_object(self, request: Request) -> Response:
        method = request.method
        path = request.path
        ctx = Context(request=request, app=self)
        if self.session_cookie_name in request.cookies:
            ctx._session = await self._get_or_create_session(request)

        exc: Optional[BaseException] = None
        active_blueprint_name: Optional[str] = None
        handled_exception: Optional[BaseException] = None

        def remember_exception(error: BaseException) -> None:
            nonlocal handled_exception
            handled_exception = error

        async def endpoint_dispatch() -> Response:
            nonlocal active_blueprint_name

            if not self.dev_proxy_fallback_only:
                dev_proxy_response = await self._try_dev_proxy_response(request)
                if dev_proxy_response is not None:
                    return dev_proxy_response

            static_response = await self._try_static_response(
                path,
                cast(RequestMethod, method),
                accept_encoding=request.get_header(KnownHeader.ACCEPT_ENCODING),
            )
            if static_response is not None:
                return static_response

            match, allowed_methods = self._resolve_route(path, method)
            if not match:
                if allowed_methods:
                    method_not_allowed = HTTPException(405)
                    method_not_allowed.allowed_methods = allowed_methods
                    raise method_not_allowed

                dev_proxy_response = await self._try_dev_proxy_response(request)
                if dev_proxy_response is not None:
                    return dev_proxy_response

                spa_fallback_response = await self._try_spa_fallback_response(request)
                if spa_fallback_response is not None:
                    return spa_fallback_response

                raise HTTPException(404)

            route, params = match
            request.route_params = params
            active_blueprint_name = route.blueprint

            async def invoke_route_handler() -> Response:
                handler, handler_accepts_ctx = self._resolve_route_handler(route)
                if handler_accepts_ctx:
                    result = await handler(ctx)
                else:
                    result = await handler()

                return self._make_response(result)

            if active_blueprint_name:
                return await self._run_response_middleware_chain(
                    ctx,
                    invoke_route_handler,
                    [self._blueprint_hook_middleware(active_blueprint_name)],
                )

            return await invoke_route_handler()

        middlewares: list[ResponseMiddleware] = [
            self._error_response_middleware(
                lambda: active_blueprint_name,
                remember_exception,
            ),
            self._app_hook_middleware(),
        ]

        try:
            response = await self._run_response_middleware_chain(
                ctx,
                endpoint_dispatch,
                middlewares,
            )
        except BaseException as e:
            exc = e
            raise
        finally:
            if exc is None:
                exc = handled_exception
            await self._run_teardown(ctx, exc)

        response = await self._apply_session_cookie(ctx, response)
        return response

    async def handle_request(
            self,
            method: RequestMethod,
            path: str,
            query_string: str,
            headers: Headers,
            body: bytes
    ) -> Response:
        """Handle a synthetic request and return a response.

        This helper is primarily intended for tests and direct invocation.
        """
        request = Request(
            method=method,
            path=path,
            query_string=query_string,
            headers=headers,
            body=body,
            json_loads=self.loads,
            payload_parser=self._parse_request_payload,
            max_body_size=self.max_request_body_size,
        )
        return await self._handle_request_object(request)

    async def __call__(self, scope: dict, receive: Callable, send: Callable) -> None:
        """ASGI application entrypoint."""
        if scope['type'] == 'lifespan':
            await self._handle_lifespan(receive, send)
            return

        if scope['type'] == 'websocket':
            if not self.dev_proxy_fallback_only:
                if await self._try_dev_proxy_websocket(scope, receive, send):
                    return

            if await self._handle_websocket_scope(scope, receive, send):
                return

            if await self._try_dev_proxy_websocket(scope, receive, send):
                return

            await send({'type': 'websocket.close', 'code': 1003})
            return

        if scope['type'] != 'http':
            return

        method = scope['method']
        path = scope['path']

        async def send_early_response(response: Response) -> None:
            await send({
                'type': 'http.response.start',
                'status': response.status,
                'headers': _encode_headers_for_asgi(response.headers),
            })
            await send({
                'type': 'http.response.body',
                'body': b'' if method == 'HEAD' else (
                    response.body.encode('utf-8') if isinstance(response.body, str) else response.body
                ),
            })

        async def send_early_error(
            *,
            status: int,
            message: str,
            stage: ErrorStage,
            phrase: Optional[str] = None,
            request: Optional[Request] = None,
        ) -> None:
            error = ErrorRenderContext(
                status=status,
                phrase=phrase or self._status_phrase(status),
                message=message,
                code=self._default_error_code(
                    status=status,
                    stage=stage,
                    exc=None,
                ),
                stage=stage,
                request=request,
            )
            await send_early_response(self._render_error_response(error))

        try:
            query_string = scope.get('query_string', b'').decode('utf-8')
        except UnicodeDecodeError:
            await send_early_error(
                status=400,
                message='Malformed UTF-8 in query string.',
                stage='asgi.query_decode',
            )
            return

        headers = {}
        for name, value in scope.get('headers', []):
            try:
                header_name = name.decode('utf-8').lower()
                header_value = value.decode('utf-8')
            except UnicodeDecodeError:
                await send_early_error(
                    status=400,
                    message='Malformed UTF-8 in request headers.',
                    stage='asgi.header_decode',
                )
                return

            _append_request_header(
                headers,
                header_name,
                header_value,
            )

        if self.max_request_body_size is not None:
            content_length = _max_content_length(headers)
            if content_length is not None and content_length > self.max_request_body_size:
                await send_early_error(
                    status=413,
                    message='Request body exceeds configured maximum size.',
                    stage='asgi.content_length',
                    phrase='Request Entity Too Large',
                )
                return

        request = Request(
            method=method,
            path=path,
            query_string=query_string,
            headers=headers,
            body=b'',
            json_loads=self.loads,
            payload_parser=self._parse_request_payload,
            body_receive=receive,
            max_body_size=self.max_request_body_size,
        )
        response = await self._handle_request_object(request)
        over_limit = await request.drain_unread_body()
        if request.client_disconnected:
            return
        if over_limit:
            response = self._render_error_response(
                ErrorRenderContext(
                    status=413,
                    phrase='Request Entity Too Large',
                    message='Request body exceeds configured maximum size.',
                    code=self._default_error_code(
                        status=413,
                        stage='asgi.body_drain',
                        exc=None,
                    ),
                    stage='asgi.body_drain',
                    request=request,
                )
            )

        await send({
            'type': 'http.response.start',
            'status': response.status,
            'headers': _encode_headers_for_asgi(response.headers),
        })

        if method == 'HEAD':
            await send({
                'type': 'http.response.body',
                'body': b'',
                'more_body': False,
            })
            return

        if response.is_stream:
            async for chunk in response.iter_chunks():
                if not chunk:
                    continue

                await send({
                    'type': 'http.response.body',
                    'body': chunk,
                    'more_body': True,
                })
            await send({
                'type': 'http.response.body',
                'body': b'',
                'more_body': False,
            })
            return

        body_bytes = response.body.encode('utf-8') if isinstance(response.body, str) else response.body
        await send({
            'type': 'http.response.body',
            'body': body_bytes,
        })
