from html import escape
from functools import wraps
from hashlib import blake2b
from datetime import datetime, timezone
from ryuuseigun.exceptions import HTTPException
from typing import Any, Optional, Callable, NoReturn, Union
from email.utils import format_datetime, parsedate_to_datetime
from ryuuseigun import Context, Response, KnownHeader, RouteHandler

type HTTPDateLike = Union[datetime, int, float, str]

def _parse_http_date(value: str) -> Optional[datetime]:
    try:
        parsed = parsedate_to_datetime(value)
    except (TypeError, ValueError, IndexError, OverflowError):
        return None

    if parsed is None:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)

    return parsed.astimezone(timezone.utc)

def _coerce_datetime(value: Union[datetime, int, float]) -> datetime:
    if isinstance(value, datetime):
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)

    return datetime.fromtimestamp(float(value), tz=timezone.utc)

def _normalize_etag(etag: str) -> str:
    raw = etag.strip()
    if not raw:
        raise ValueError('etag cannot be empty.')

    weak = False
    if raw.startswith('W/'):
        weak = True
        raw = raw[2:].strip()

    if not (raw.startswith('"') and raw.endswith('"')):
        raw = f'"{raw}"'

    if weak:
        return f'W/{raw}'
    return raw

def _etag_opaque(tag: str) -> str:
    raw = tag.strip()
    if raw.startswith('W/'):
        raw = raw[2:].strip()
    if len(raw) >= 2 and raw.startswith('"') and raw.endswith('"'):
        raw = raw[1:-1]
    return raw

def _if_none_match_matches(if_none_match: str, etag: str) -> bool:
    target = _etag_opaque(etag)
    for token in if_none_match.split(','):
        candidate = token.strip()
        if not candidate:
            continue
        if candidate == '*':
            return True
        if _etag_opaque(candidate) == target:
            return True
    return False

def _response_header(response: Response, name: str) -> Optional[str]:
    target = name.lower()
    for key, value in response.headers.items():
        if str(key).lower() != target:
            continue
        if isinstance(value, list):
            return ', '.join(str(v) for v in value)
        return str(value)
    return None

def _remove_header(response: Response, name: str) -> None:
    target = name.lower()
    for key in list(response.headers.keys()):
        if str(key).lower() == target:
            del response.headers[key]

def _normalize_last_modified(
    value: HTTPDateLike,
) -> tuple[str, Optional[datetime]]:
    if isinstance(value, str):
        header_value = value.strip()
        if not header_value:
            raise ValueError('last_modified cannot be empty when provided as str.')
        return header_value, _parse_http_date(header_value)

    header_value = format_http_date(value)
    parsed = _parse_http_date(header_value)
    return header_value, parsed

def _not_modified_response(
    *,
    etag: Optional[str],
    last_modified: Optional[str],
    cache_control: Optional[str],
) -> Response:
    headers = {}
    if etag is not None:
        headers[KnownHeader.ETAG] = etag
    if last_modified is not None:
        headers[KnownHeader.LAST_MODIFIED] = last_modified
    if cache_control is not None:
        headers[KnownHeader.CACHE_CONTROL] = cache_control

    response = Response(body=b'', status=304, headers=headers)
    _remove_header(response, KnownHeader.CONTENT_TYPE.value)
    return response

def format_http_date(value: Union[datetime, int, float]) -> str:
    dt = _coerce_datetime(value)
    return format_datetime(dt, usegmt=True)

def make_etag(value: Union[str, bytes], *, weak: bool = False) -> str:
    payload = value.encode('utf-8') if isinstance(value, str) else value
    digest = blake2b(payload, digest_size=16).hexdigest()
    base = f'"{digest}"'
    if weak:
        return f'W/{base}'
    return base

def apply_conditional_response(
    ctx: Context,
    response: Response,
    *,
    etag: Optional[str] = None,
    last_modified: Optional[HTTPDateLike] = None,
    cache_control: Optional[str] = None,
) -> Response:
    resolved_etag: Optional[str] = None
    resolved_last_modified: Optional[str] = None
    resolved_last_modified_dt: Optional[datetime] = None

    if cache_control is not None:
        response.set_header(KnownHeader.CACHE_CONTROL, cache_control)

    if etag is not None:
        resolved_etag = _normalize_etag(etag)
        response.set_header(KnownHeader.ETAG, resolved_etag)
    else:
        existing_etag = _response_header(response, KnownHeader.ETAG.value)
        if existing_etag:
            resolved_etag = _normalize_etag(existing_etag)
            response.set_header(KnownHeader.ETAG, resolved_etag)

    if last_modified is not None:
        resolved_last_modified, resolved_last_modified_dt = _normalize_last_modified(last_modified)
        response.set_header(KnownHeader.LAST_MODIFIED, resolved_last_modified)
    else:
        existing_last_modified = _response_header(response, KnownHeader.LAST_MODIFIED.value)
        if existing_last_modified:
            resolved_last_modified, resolved_last_modified_dt = _normalize_last_modified(existing_last_modified)
            response.set_header(KnownHeader.LAST_MODIFIED, resolved_last_modified)

    if response.status != 200 or ctx.request.method not in ('GET', 'HEAD'):
        return response

    request_if_none_match = ctx.request.get_header(KnownHeader.IF_NONE_MATCH)
    if request_if_none_match and resolved_etag is not None:
        if _if_none_match_matches(request_if_none_match, resolved_etag):
            return _not_modified_response(
                etag=resolved_etag,
                last_modified=resolved_last_modified,
                cache_control=_response_header(response, KnownHeader.CACHE_CONTROL.value),
            )
        return response

    request_if_modified_since = ctx.request.get_header(KnownHeader.IF_MODIFIED_SINCE)
    if request_if_modified_since and resolved_last_modified_dt is not None:
        parsed_if_modified_since = _parse_http_date(request_if_modified_since)
        if parsed_if_modified_since is not None:
            if int(resolved_last_modified_dt.timestamp()) <= int(parsed_if_modified_since.timestamp()):
                return _not_modified_response(
                    etag=resolved_etag,
                    last_modified=resolved_last_modified,
                    cache_control=_response_header(response, KnownHeader.CACHE_CONTROL.value),
                )

    return response

def with_json_body(func: RouteHandler) -> RouteHandler:
    @wraps(func)
    async def wrapper(ctx: Context) -> Any:
        if not await ctx.request.is_json_valid_async():
            raise HTTPException(400, 'Invalid or missing JSON body')
        return await func(ctx)
    return wrapper

def require_method(*methods: str) -> Callable[[RouteHandler], RouteHandler]:
    allow = ', '.join(methods)
    def decorator(func: RouteHandler) -> RouteHandler:
        @wraps(func)
        async def wrapper(ctx: Context) -> Any:
            if ctx.request.method not in methods:
                response = Response(body=b'', status=405)
                response.set_header('Allow', allow)
                return response
            return await func(ctx)
        return wrapper
    return decorator

def redirect(location: str, status: int = 302) -> Response:
    escaped_location = escape(location, quote=True)
    body = f'''<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><title>Redirecting...</title></head>
<body>
<p>Redirecting to <a href="{escaped_location}">{escaped_location}</a></p>
</body>
</html>'''
    return Response(
        body=body,
        status=status,
        headers={KnownHeader.LOCATION: location},
    )

def abort(status: int, message: Optional[str] = None) -> NoReturn:
    raise HTTPException(status, message)
