"""Metal template assets for kernel discovery."""
