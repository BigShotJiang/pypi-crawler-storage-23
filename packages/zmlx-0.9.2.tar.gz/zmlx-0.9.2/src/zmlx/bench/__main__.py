"""Allow ``python -m zmlx.bench.report <capsule.json>``."""

from .report import main

main()
