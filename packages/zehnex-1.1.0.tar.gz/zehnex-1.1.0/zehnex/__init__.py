"""
ZEHNEX 1.1.0 - Next-Gen Telegram Framework
"""

__version__ = "1.1.0"
__author__ = "Zehnex Team"

from zehnex.bot import Zehnex
from zehnex.downloader import VideoDownloader
from zehnex.currency import CurrencyConverter
from zehnex.wiki import WikiToPDF
from zehnex.qrcode_gen import QRGenerator
from zehnex.filters import Router, Filter
from zehnex.context import Context

# Alias for old Zentel users if needed
ZehnexBot = Zehnex

__all__ = [
    "Zehnex",
    "ZehnexBot",
    "VideoDownloader",
    "CurrencyConverter",
    "WikiToPDF",
    "QRGenerator",
    "Router",
    "Filter",
    "Context",
]
