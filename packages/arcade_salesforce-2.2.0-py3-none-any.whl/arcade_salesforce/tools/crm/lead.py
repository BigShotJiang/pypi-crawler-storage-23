import asyncio
from typing import Annotated

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import OAuth2
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)

from arcade_salesforce.exceptions import SalesforceToolExecutionError
from arcade_salesforce.models import SalesforceClient
from arcade_salesforce.utils import (
    build_dynamic_soql,
    build_validation_error,
    clamp_pagination,
    paginated_response,
    remove_none_values,
    sanitize_soql_id,
    sanitize_soql_like_argument,
    sanitize_soql_string_literal,
    validate_salesforce_id,
    validate_soql_date,
)


async def _check_lead_converted(
    client: SalesforceClient,
    lead_id: str,
) -> ToolExecutionError | None:
    """Return a ToolExecutionError if the lead is already converted, else None.

    Best-effort: if the query fails the caller re-raises its original error.
    """
    try:
        safe_id = sanitize_soql_id(lead_id)
        lead_data = await client.query(
            f"SELECT IsConverted, ConvertedContactId, ConvertedAccountId, "  # noqa: S608
            f"ConvertedOpportunityId FROM Lead WHERE Id = '{safe_id}'"
        )
    except SalesforceToolExecutionError:
        return None

    records = lead_data.get("records") or []
    if not records:
        return None

    rec = records[0]
    if not rec.get("IsConverted"):
        return None

    return ToolExecutionError(
        f"Lead '{lead_id}' has already been converted. "
        f"Contact: {rec.get('ConvertedContactId')}, "
        f"Account: {rec.get('ConvertedAccountId')}, "
        f"Opportunity: {rec.get('ConvertedOpportunityId')}. "
        f"Use SearchContacts or GetAccountDataByID instead."
    )


async def _validate_lead_picklist(
    client: SalesforceClient,
    field_api_name: str,
    value: str,
    field_label: str,
) -> None:
    try:
        valid_values = await client.describe_picklist("Lead", field_api_name)
    except SalesforceToolExecutionError:
        return
    if valid_values and value not in valid_values:
        raise ToolExecutionError(build_validation_error(field_label, value, valid_values))


@tool(
    requires_auth=OAuth2(id="salesforce", scopes=["read_lead"]),
    requires_secrets=["SALESFORCE_ORG_SUBDOMAIN", "SALESFORCE_MAX_CONCURRENT_REQUESTS"],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def search_leads(
    context: Context,
    query: Annotated[
        str | None,
        "Keyword search against lead name, company, title, and email.",
    ] = None,
    status: Annotated[
        str | None,
        "Filter by lead status. Must match one of the org's configured status values.",
    ] = None,
    owner: Annotated[
        str,
        "Filter by owner. Defaults to the current user. Pass 'all' to search across all owners.",
    ] = "me",
    lead_source: Annotated[
        str | None,
        "Filter by lead source. Must match the org's configured lead source values.",
    ] = None,
    created_after: Annotated[
        str | None, "Only return leads created on or after this date (YYYY-MM-DD)."
    ] = None,
    limit: Annotated[int, "Maximum results to return (1-50). Defaults to 20."] = 20,
    page: Annotated[int, "Page number for pagination. Defaults to 1 (first page)."] = 1,
) -> Annotated[dict, "Paginated list of leads matching the search criteria."]:
    """Searches for leads in Salesforce with optional filters.

    Always excludes already-converted leads. Use owner='me' (default) for your leads,
    or owner='all' for all leads in the org.
    """
    client = SalesforceClient(context)
    pp = clamp_pagination(limit, page)

    if status:
        await _validate_lead_picklist(client, "Status", status, "status")
    if lead_source:
        await _validate_lead_picklist(client, "LeadSource", lead_source, "lead_source")

    where: list[str] = ["IsConverted = false"]

    if owner != "all":
        if owner == "me":
            user_id = await client.get_current_user_id()
        else:
            user_id = sanitize_soql_id(owner)
        where.append(f"OwnerId = '{user_id}'")

    if query:
        kw = sanitize_soql_like_argument(query)
        where.append(
            f"(Name LIKE '%{kw}%' OR Company LIKE '%{kw}%' "
            f"OR Title LIKE '%{kw}%' OR Email LIKE '%{kw}%')"
        )

    if status:
        where.append(f"Status = '{sanitize_soql_string_literal(status)}'")

    if lead_source:
        where.append(f"LeadSource = '{sanitize_soql_string_literal(lead_source)}'")

    if created_after:
        where.append(f"CreatedDate >= {validate_soql_date(created_after)}T00:00:00Z")

    select = (
        "Id, Name, FirstName, LastName, Company, Title, Status, "
        "Email, Phone, LeadSource, Owner.Name, CreatedDate"
    )

    count_soql = build_dynamic_soql(
        select="COUNT()",
        from_obj="Lead",
        where_clauses=where,
    )
    data_soql = build_dynamic_soql(
        select=select,
        from_obj="Lead",
        where_clauses=where,
        order_by="CreatedDate DESC",
        limit=pp.limit,
        offset=pp.offset,
    )

    count_result, data_result = await asyncio.gather(
        client.query(count_soql),
        client.query(data_soql),
    )

    total_count = count_result["totalSize"]
    records = data_result["records"]

    leads = []
    for rec in records:
        owner_data = rec.get("Owner") or {}
        leads.append({
            "lead_id": rec["Id"],
            "name": rec.get("Name"),
            "first_name": rec.get("FirstName"),
            "last_name": rec.get("LastName"),
            "company": rec.get("Company"),
            "title": rec.get("Title"),
            "status": rec.get("Status"),
            "email": rec.get("Email"),
            "phone": rec.get("Phone"),
            "lead_source": rec.get("LeadSource"),
            "owner_name": owner_data.get("Name"),
            "created_date": rec.get("CreatedDate"),
        })

    return paginated_response(total_count, pp, "leads", leads)


@tool(
    requires_auth=OAuth2(id="salesforce", scopes=["write_lead"]),
    requires_secrets=["SALESFORCE_ORG_SUBDOMAIN", "SALESFORCE_MAX_CONCURRENT_REQUESTS"],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_lead(
    context: Context,
    last_name: Annotated[str, "The last name of the lead."],
    company: Annotated[str, "The company the lead works for."],
    first_name: Annotated[str | None, "The first name of the lead."] = None,
    email: Annotated[str | None, "The lead's email address."] = None,
    phone: Annotated[str | None, "The lead's phone number."] = None,
    title: Annotated[str | None, "The lead's job title."] = None,
    status: Annotated[
        str | None,
        "Initial lead status. Must match the org's configured values. "
        "Defaults to the org's default status if not provided.",
    ] = None,
    lead_source: Annotated[
        str | None,
        "How this lead originated. Must match the org's configured lead source values.",
    ] = None,
    industry: Annotated[str | None, "The lead's industry."] = None,
    description: Annotated[str | None, "Notes about the lead."] = None,
    website: Annotated[str | None, "The lead's company website."] = None,
) -> Annotated[dict, "The created lead ID."]:
    """Creates a new lead in Salesforce.

    Use this when someone is a potential customer but isn't yet associated with
    an existing account. For contacts under existing accounts, use create_contact.
    """
    client = SalesforceClient(context)

    if status:
        await _validate_lead_picklist(client, "Status", status, "status")
    if lead_source:
        await _validate_lead_picklist(client, "LeadSource", lead_source, "lead_source")

    data = remove_none_values({
        "LastName": last_name,
        "Company": company,
        "FirstName": first_name,
        "Email": email,
        "Phone": phone,
        "Title": title,
        "Status": status,
        "LeadSource": lead_source,
        "Industry": industry,
        "Description": description,
        "Website": website,
    })

    result = await client.create_record("Lead", data)

    if not result.get("success"):
        raise SalesforceToolExecutionError(
            message="Failed to create lead",
            errors=result.get("errors", []),
            status_code=422,
        )

    return {"success": True, "lead_id": result["id"]}


@tool(
    requires_auth=OAuth2(id="salesforce", scopes=["write_lead"]),
    requires_secrets=["SALESFORCE_ORG_SUBDOMAIN", "SALESFORCE_MAX_CONCURRENT_REQUESTS"],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def update_lead(
    context: Context,
    lead_id: Annotated[str, "The Salesforce ID of the lead to update."],
    status: Annotated[
        str | None, "New lead status. Must match the org's configured values."
    ] = None,
    first_name: Annotated[str | None, "Updated first name."] = None,
    last_name: Annotated[str | None, "Updated last name."] = None,
    email: Annotated[str | None, "Updated email address."] = None,
    phone: Annotated[str | None, "Updated phone number."] = None,
    title: Annotated[str | None, "Updated job title."] = None,
    company: Annotated[str | None, "Updated company name."] = None,
    description: Annotated[str | None, "Updated notes."] = None,
    lead_source: Annotated[
        str | None,
        "Updated lead source. Must match the org's configured lead source values.",
    ] = None,
    rating: Annotated[str | None, "Updated lead rating. Allowed values: Hot, Warm, Cold."] = None,
) -> Annotated[dict, "Update result."]:
    """Updates fields on an existing lead. Only provided fields are changed.

    If the lead has already been converted, returns an error with the converted
    record IDs so the agent can redirect to the correct contact/account.
    """
    validate_salesforce_id(lead_id, "lead_id", search_hint="SearchLeads")

    client = SalesforceClient(context)

    field_map = {
        "Status": status,
        "FirstName": first_name,
        "LastName": last_name,
        "Email": email,
        "Phone": phone,
        "Title": title,
        "Company": company,
        "Description": description,
        "LeadSource": lead_source,
        "Rating": rating,
    }
    data = remove_none_values(field_map)

    if not data:
        raise ToolExecutionError("At least one field must be provided to update.")

    if status:
        await _validate_lead_picklist(client, "Status", status, "status")
    if lead_source:
        await _validate_lead_picklist(client, "LeadSource", lead_source, "lead_source")
    if rating and rating not in ("Hot", "Warm", "Cold"):
        raise ToolExecutionError(build_validation_error("rating", rating, ["Hot", "Warm", "Cold"]))

    try:
        await client.update_record("Lead", lead_id, data)
    except SalesforceToolExecutionError:
        lead_data = await _check_lead_converted(client, lead_id)
        if lead_data:
            raise lead_data
        raise

    return {"success": True, "lead_id": lead_id}


@tool(
    requires_auth=OAuth2(
        id="salesforce",
        scopes=["write_lead", "write_contact", "write_opportunity"],
    ),
    requires_secrets=["SALESFORCE_ORG_SUBDOMAIN", "SALESFORCE_MAX_CONCURRENT_REQUESTS"],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.UPDATE, Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def convert_lead(
    context: Context,
    lead_id: Annotated[str, "The Salesforce ID of the lead to convert."],
    account_id: Annotated[
        str | None,
        "Existing Account ID to link the converted lead to. "
        "If omitted, Salesforce creates a new Account from the lead's Company.",
    ] = None,
    opportunity_name: Annotated[
        str | None, "Name for the new opportunity created during conversion."
    ] = None,
    converted_status: Annotated[
        str | None,
        "The lead status to set upon conversion. Auto-detected if not provided.",
    ] = None,
    skip_opportunity: Annotated[
        bool, "If true, no opportunity is created during conversion. Defaults to False."
    ] = False,
) -> Annotated[dict, "Conversion result with new contact, account, and opportunity IDs."]:
    """Converts a lead into a Contact (and optionally Account + Opportunity).

    This is the canonical lead-to-deal transition in Salesforce. The lead record
    is marked as converted and new Contact/Account/Opportunity records are created.
    """
    client = SalesforceClient(context)

    safe_id = validate_salesforce_id(lead_id, "lead_id", search_hint="SearchLeads")

    if converted_status:
        try:
            converted_statuses = await client.get_converted_lead_statuses()
        except SalesforceToolExecutionError:
            converted_statuses = []
        if converted_statuses and converted_status not in converted_statuses:
            raise ToolExecutionError(
                build_validation_error("converted_status", converted_status, converted_statuses)
            )

    lead_check = await client.query(
        f"SELECT IsConverted, ConvertedContactId, ConvertedAccountId, "  # noqa: S608
        f"ConvertedOpportunityId FROM Lead WHERE Id = '{safe_id}'"
    )

    if not lead_check["records"]:
        return {"success": False, "error": f"No lead found with id '{lead_id}'"}

    lead_rec = lead_check["records"][0]
    if lead_rec.get("IsConverted"):
        return {
            "success": False,
            "error": f"Lead '{lead_id}' has already been converted.",
            "lead_id": lead_id,
            "contact_id": lead_rec.get("ConvertedContactId"),
            "account_id": lead_rec.get("ConvertedAccountId"),
            "opportunity_id": lead_rec.get("ConvertedOpportunityId"),
        }

    warnings: list[dict] = []
    if skip_opportunity and opportunity_name:
        warnings.append({
            "code": "OPPORTUNITY_NAME_IGNORED",
            "field": "opportunity_name",
            "message": (
                "opportunity_name was provided but skip_opportunity is true. "
                "The opportunity_name will be ignored."
            ),
        })

    result = await client.convert_lead(
        lead_id=lead_id,
        account_id=account_id,
        opportunity_name=opportunity_name,
        converted_status=converted_status,
        skip_opportunity=skip_opportunity,
    )

    if not result.get("isSuccess"):
        error_messages = result.get("errors") or ["Unknown conversion error"]
        raise SalesforceToolExecutionError(
            error_messages,
            message="Lead conversion failed",
            status_code=422,
        )

    contact_id = result.get("contactId")
    if not contact_id:
        raise SalesforceToolExecutionError(
            [
                "Lead conversion response did not include a contactId. "
                "The conversion may not have completed successfully."
            ],
            status_code=502,
        )

    return {
        "success": True,
        "lead_id": lead_id,
        "contact_id": contact_id,
        "account_id": result.get("accountId"),
        "opportunity_id": result.get("opportunityId"),
        "warnings": warnings,
    }
