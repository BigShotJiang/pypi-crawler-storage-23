import asyncio
from typing import Annotated

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import OAuth2
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)

from arcade_salesforce.enums import SalesforceObject
from arcade_salesforce.models import SalesforceClient
from arcade_salesforce.utils import clean_account_data, validate_salesforce_id


# TODO: We only return up to 10 items of each related object (e.g. contacts). Need to implement
# separate tools for each related object, so that we can return more items, when needed.
@tool(
    requires_auth=OAuth2(
        id="salesforce",
        scopes=[
            "read_account",
            "read_contact",
            "read_lead",
            "read_note",
            "read_opportunity",
            "read_task",
        ],
    ),
    requires_secrets=[
        "SALESFORCE_ORG_SUBDOMAIN",
        "SALESFORCE_MAX_CONCURRENT_REQUESTS",
    ],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_account_data_by_keywords(
    context: Context,
    query: Annotated[
        str,
        "The query to search for accounts. MUST be longer than one character. It will match the "
        "keywords against all account fields, such as name, website, phone, address, etc. "
        "E.g. 'Acme'",
    ],
    # Note: Salesforce supports up to 200 results, but since we're enriching each account with
    # related objects, we limit to 10, so that the response is not too lengthy for LLMs.
    limit: Annotated[
        int,
        "The maximum number of accounts to return. Defaults to 10. Maximum allowed is 10.",
    ] = 10,
    page: Annotated[int, "The page number to return. Defaults to 1 (first page of results)."] = 1,
) -> Annotated[
    dict,
    "The accounts matching the query with related info: contacts, leads, notes, calls, "
    "opportunities, tasks, emails, and events (up to 10 items of each type)",
]:
    """Searches for accounts in Salesforce and returns them with related info: contacts, leads,
    notes, calls, opportunities, tasks, emails, and events (up to 10 items of each type).

    An account is an organization (such as a customer, supplier, or partner, though more commonly
    a customer). In some Salesforce account setups, an account can also represent a person.
    """
    if len(query) < 2:
        raise ToolExecutionError(
            f"The `query` argument must have two or more characters "
            f"(received {len(query)}). Use account name, domain, or other keywords to search."
        )

    original_limit, original_page = limit, page
    limit = max(1, min(limit, 10))
    page = max(1, page)

    client = SalesforceClient(context)

    params = {
        "q": query,
        "sobjects": [
            {
                "name": "Account",
                "fields": await client.get_object_fields(SalesforceObject.ACCOUNT),
            }
        ],
        "in": "ALL",
        "overallLimit": limit,
        "offset": (page - 1) * limit,
    }
    response = await client.post("parameterizedSearch", json_data=params)
    search_results = response["searchRecords"]

    accounts = await asyncio.gather(*[
        client.enrich_account(
            account_data=account,
            limit_per_association=10,
        )
        for account in search_results
    ])
    result: dict = {"accounts": [clean_account_data(account) for account in accounts]}

    warnings: list[dict] = []
    if original_limit != limit:
        warnings.append({
            "code": "LIMIT_CLAMPED",
            "message": f"Requested limit={original_limit} was adjusted to {limit} (max 10).",
            "applied_limit": limit,
        })
    if original_page != page:
        warnings.append({
            "code": "PAGE_CLAMPED",
            "message": f"Requested page={original_page} was adjusted to {page} (min 1).",
            "applied_page": page,
        })
    if warnings:
        result["warnings"] = warnings

    return result


@tool(
    requires_auth=OAuth2(
        id="salesforce",
        scopes=[
            "read_account",
            "read_contact",
            "read_lead",
            "read_note",
            "read_opportunity",
            "read_task",
        ],
    ),
    requires_secrets=[
        "SALESFORCE_ORG_SUBDOMAIN",
        "SALESFORCE_MAX_CONCURRENT_REQUESTS",
    ],
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CRM],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_account_data_by_id(
    context: Context,
    account_id: Annotated[
        str,
        "The ID of the account to get data for.",
    ],
) -> Annotated[
    dict,
    "The account with related info: contacts, leads, notes, calls, opportunities, tasks, emails, "
    "and events (up to 10 items of each type)",
]:
    """Gets the account with related info: contacts, leads, notes, calls, opportunities, tasks,
    emails, and events (up to 10 items of each type).

    An account is an organization (such as a customer, supplier, or partner, though more commonly
    a customer). In some Salesforce account setups, an account can also represent a person.
    """
    validate_salesforce_id(account_id, "account_id", search_hint="GetAccountDataByKeywords")

    client = SalesforceClient(context)

    account = await client.get_account(account_id)

    if not account:
        return {
            "account": None,
            "error": (
                f"No account found with id '{account_id}'. "
                f"Use GetAccountDataByKeywords to search by name or domain."
            ),
        }

    account = await client.enrich_account(account_data=account)
    account = clean_account_data(account)

    return {"account": account}
