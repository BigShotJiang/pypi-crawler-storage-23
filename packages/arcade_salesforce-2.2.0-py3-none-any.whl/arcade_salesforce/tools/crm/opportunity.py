import asyncio
from typing import Annotated, Any

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import OAuth2
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)

from arcade_salesforce.enums import ForecastCategory
from arcade_salesforce.exceptions import ResourceNotFoundError, SalesforceToolExecutionError
from arcade_salesforce.models import SalesforceClient
from arcade_salesforce.utils import (
    build_dynamic_soql,
    build_validation_error,
    clamp_pagination,
    paginated_response,
    remove_none_values,
    sanitize_soql_id,
    sanitize_soql_like_argument,
    sanitize_soql_string_literal,
    validate_salesforce_id,
    validate_soql_date,
)


async def _validate_picklist(
    client: SalesforceClient,
    sobject: str,
    field_api_name: str,
    value: str,
    field_label: str,
) -> None:
    """Validate a value against an org's picklist and raise with ranked suggestions if invalid."""
    try:
        valid_values = await client.describe_picklist(sobject, field_api_name)
    except SalesforceToolExecutionError:
        return
    if valid_values and value not in valid_values:
        raise ToolExecutionError(build_validation_error(field_label, value, valid_values))


@tool(
    requires_auth=OAuth2(id="salesforce", scopes=["read_opportunity"]),
    requires_secrets=["SALESFORCE_ORG_SUBDOMAIN", "SALESFORCE_MAX_CONCURRENT_REQUESTS"],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def search_opportunities(
    context: Context,
    query: Annotated[str | None, "Keyword search against opportunity name."] = None,
    stage: Annotated[
        str | None,
        "Filter by pipeline stage. Must match one of the org's configured stage names.",
    ] = None,
    close_date_from: Annotated[
        str | None,
        "Only return opportunities closing on or after this date. ISO format (YYYY-MM-DD).",
    ] = None,
    close_date_to: Annotated[
        str | None,
        "Only return opportunities closing on or before this date. ISO format (YYYY-MM-DD).",
    ] = None,
    owner: Annotated[
        str,
        "Filter by owner. Defaults to the current user. Pass 'all' to search across all owners.",
    ] = "me",
    min_amount: Annotated[float | None, "Minimum deal amount filter."] = None,
    limit: Annotated[int, "Maximum results to return (1-50). Defaults to 20."] = 20,
    page: Annotated[int, "Page number for pagination. Defaults to 1 (first page)."] = 1,
) -> Annotated[dict, "Paginated list of opportunities matching the search criteria."]:
    """Searches for opportunities (deals) in Salesforce with optional filters.

    Returns a paginated list of opportunities with key fields like stage, amount,
    close date, and associated account. Use owner='me' (default) to see your deals,
    or owner='all' for the whole pipeline.
    """
    client = SalesforceClient(context)
    pp = clamp_pagination(limit, page)

    if stage:
        await _validate_picklist(client, "Opportunity", "StageName", stage, "stage")

    where: list[str] = []

    if owner != "all":
        if owner == "me":
            user_id = await client.get_current_user_id()
        else:
            user_id = sanitize_soql_id(owner)
        where.append(f"OwnerId = '{user_id}'")

    if query:
        kw = sanitize_soql_like_argument(query)
        where.append(f"Name LIKE '%{kw}%'")

    if stage:
        where.append(f"StageName = '{sanitize_soql_string_literal(stage)}'")

    if close_date_from:
        where.append(f"CloseDate >= {validate_soql_date(close_date_from)}")

    if close_date_to:
        where.append(f"CloseDate <= {validate_soql_date(close_date_to)}")

    if min_amount is not None:
        where.append(f"Amount >= {float(min_amount)}")

    select = (
        "Id, Name, StageName, Amount, CloseDate, AccountId, Account.Name, "
        "Owner.Name, Probability, NextStep"
    )
    count_soql = build_dynamic_soql(
        select="COUNT()",
        from_obj="Opportunity",
        where_clauses=where,
    )
    data_soql = build_dynamic_soql(
        select=select,
        from_obj="Opportunity",
        where_clauses=where,
        order_by="CloseDate ASC",
        limit=pp.limit,
        offset=pp.offset,
    )

    count_result, data_result = await asyncio.gather(
        client.query(count_soql),
        client.query(data_soql),
    )

    total_count = count_result["totalSize"]
    records = data_result["records"]

    opportunities = []
    for rec in records:
        account = rec.get("Account") or {}
        owner_data = rec.get("Owner") or {}
        opportunities.append({
            "opportunity_id": rec["Id"],
            "name": rec.get("Name"),
            "stage": rec.get("StageName"),
            "amount": rec.get("Amount"),
            "close_date": rec.get("CloseDate"),
            "account_id": rec.get("AccountId"),
            "account_name": account.get("Name"),
            "owner_name": owner_data.get("Name"),
            "probability": rec.get("Probability"),
            "next_step": rec.get("NextStep"),
        })

    return paginated_response(total_count, pp, "opportunities", opportunities)


@tool(
    requires_auth=OAuth2(
        id="salesforce",
        scopes=["read_opportunity", "read_contact", "read_task", "read_note"],
    ),
    requires_secrets=["SALESFORCE_ORG_SUBDOMAIN", "SALESFORCE_MAX_CONCURRENT_REQUESTS"],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_opportunity_by_id(  # noqa: C901
    context: Context,
    opportunity_id: Annotated[str, "The Salesforce ID of the opportunity."],
) -> Annotated[dict, "The opportunity with enriched related data."]:
    """Gets a single opportunity with enriched related data: contact roles, line items,
    open tasks, and recent notes.
    """
    client = SalesforceClient(context)

    safe_id = validate_salesforce_id(
        opportunity_id, "opportunity_id", search_hint="SearchOpportunities"
    )

    try:
        opp = await client.get(f"sobjects/Opportunity/{safe_id}")
    except ResourceNotFoundError:
        return {
            "opportunity": None,
            "error": (
                f"No opportunity found with id '{opportunity_id}'. "
                f"Use SearchOpportunities to find the correct opportunity."
            ),
        }

    warnings: list[dict] = []

    async def _get_contact_roles() -> list[dict]:
        try:
            result = await client.query(
                f"SELECT Id, ContactId, Contact.Name, Role, IsPrimary "  # noqa: S608
                f"FROM OpportunityContactRole "
                f"WHERE OpportunityId = '{safe_id}' "
                f"LIMIT 10"
            )
            return [
                {
                    "contact_id": r.get("ContactId"),
                    "contact_name": (r.get("Contact") or {}).get("Name"),
                    "role": r.get("Role"),
                    "is_primary": r.get("IsPrimary", False),
                }
                for r in result["records"]
            ]
        except (ResourceNotFoundError, SalesforceToolExecutionError):
            warnings.append({
                "code": "ENRICHMENT_FAILED",
                "field": "contact_roles",
                "message": "Could not retrieve contact roles for this opportunity.",
            })
            return []

    async def _get_line_items() -> list[dict]:
        try:
            result = await client.query(
                f"SELECT Id, Product2Id, Product2.Name, Quantity, UnitPrice, TotalPrice "  # noqa: S608
                f"FROM OpportunityLineItem "
                f"WHERE OpportunityId = '{safe_id}' "
                f"LIMIT 10"
            )
            return [
                {
                    "line_item_id": r["Id"],
                    "product_id": r.get("Product2Id"),
                    "product_name": (r.get("Product2") or {}).get("Name"),
                    "quantity": r.get("Quantity"),
                    "unit_price": r.get("UnitPrice"),
                    "total_price": r.get("TotalPrice"),
                }
                for r in result["records"]
            ]
        except (ResourceNotFoundError, SalesforceToolExecutionError):
            warnings.append({
                "code": "ENRICHMENT_FAILED",
                "field": "line_items",
                "message": "Could not retrieve line items for this opportunity.",
            })
            return []

    async def _get_open_tasks() -> list[dict]:
        try:
            result = await client.query(
                f"SELECT Id, Subject, ActivityDate, Priority, Status "  # noqa: S608
                f"FROM Task "
                f"WHERE WhatId = '{safe_id}' "
                f"AND IsClosed = false "
                f"LIMIT 10"
            )
            return [
                {
                    "task_id": r["Id"],
                    "subject": r.get("Subject"),
                    "due_date": r.get("ActivityDate"),
                    "priority": r.get("Priority"),
                    "status": r.get("Status"),
                }
                for r in result["records"]
            ]
        except (ResourceNotFoundError, SalesforceToolExecutionError):
            warnings.append({
                "code": "ENRICHMENT_FAILED",
                "field": "open_tasks",
                "message": "Could not retrieve open tasks for this opportunity.",
            })
            return []

    async def _get_recent_notes() -> list[dict]:
        try:
            result = await client.query(
                f"SELECT Id, Title, Body, CreatedDate "  # noqa: S608
                f"FROM Note "
                f"WHERE ParentId = '{safe_id}' "
                f"ORDER BY CreatedDate DESC "
                f"LIMIT 10"
            )
            return [
                {
                    "note_id": r["Id"],
                    "title": r.get("Title"),
                    "body": r.get("Body"),
                    "created_date": r.get("CreatedDate"),
                }
                for r in result["records"]
            ]
        except (ResourceNotFoundError, SalesforceToolExecutionError):
            warnings.append({
                "code": "ENRICHMENT_FAILED",
                "field": "recent_notes",
                "message": "Could not retrieve notes for this opportunity.",
            })
            return []

    contact_roles, line_items, open_tasks, recent_notes = await asyncio.gather(
        _get_contact_roles(),
        _get_line_items(),
        _get_open_tasks(),
        _get_recent_notes(),
    )

    account = opp.get("Account") or {}
    if not account and opp.get("AccountId"):
        try:
            acct_data = await client.get(f"sobjects/Account/{opp['AccountId']}")
            account = {"Name": acct_data.get("Name"), "Industry": acct_data.get("Industry")}
        except ResourceNotFoundError:
            account = {}

    owner = opp.get("Owner") or {}
    if not owner and opp.get("OwnerId"):
        try:
            owner_data = await client.get(f"sobjects/User/{opp['OwnerId']}")
            owner = {"Name": owner_data.get("Name")}
        except ResourceNotFoundError:
            owner = {}

    result: dict[str, Any] = {
        "opportunity": {
            "opportunity_id": opp["Id"],
            "name": opp.get("Name"),
            "stage": opp.get("StageName"),
            "amount": opp.get("Amount"),
            "close_date": opp.get("CloseDate"),
            "next_step": opp.get("NextStep"),
            "description": opp.get("Description"),
            "probability": opp.get("Probability"),
            "forecast_category": opp.get("ForecastCategoryName"),
            "type": opp.get("Type"),
            "lead_source": opp.get("LeadSource"),
            "account": {
                "account_id": opp.get("AccountId"),
                "name": account.get("Name"),
                "industry": account.get("Industry"),
            },
            "owner": {
                "user_id": opp.get("OwnerId"),
                "name": owner.get("Name"),
            },
            "contact_roles": contact_roles,
            "line_items": line_items,
            "open_tasks": open_tasks,
            "recent_notes": recent_notes,
        },
    }
    if warnings:
        result["warnings"] = warnings
    return result


@tool(
    requires_auth=OAuth2(id="salesforce", scopes=["write_opportunity"]),
    requires_secrets=["SALESFORCE_ORG_SUBDOMAIN", "SALESFORCE_MAX_CONCURRENT_REQUESTS"],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_opportunity(
    context: Context,
    account_id: Annotated[str, "The Salesforce ID of the Account to associate with."],
    name: Annotated[str, "A descriptive name for the opportunity."],
    stage: Annotated[
        str,
        "The initial pipeline stage. Must match one of the org's configured stage names.",
    ],
    close_date: Annotated[str, "Expected close date in ISO format (YYYY-MM-DD)."],
    amount: Annotated[float | None, "Deal amount in the org's default currency."] = None,
    description: Annotated[str | None, "Free-text description or notes about the deal."] = None,
    next_step: Annotated[str | None, "The immediate next action to advance this deal."] = None,
    lead_source: Annotated[
        str | None,
        "How this opportunity originated. Must match the org's configured lead source values.",
    ] = None,
    type: Annotated[  # noqa: A002
        str | None,
        "The opportunity type. Must match the org's configured opportunity type values.",
    ] = None,
) -> Annotated[dict, "The created opportunity ID."]:
    """Creates a new opportunity (deal) in Salesforce.

    Requires an account, name, stage, and close date. Validates stage, lead source,
    and type against the org's configured picklist values.
    """
    client = SalesforceClient(context)

    validate_salesforce_id(account_id, "account_id", search_hint="GetAccountDataByKeywords")
    validate_soql_date(close_date)

    await _validate_picklist(client, "Opportunity", "StageName", stage, "stage")
    if lead_source:
        await _validate_picklist(client, "Opportunity", "LeadSource", lead_source, "lead_source")
    if type:
        await _validate_picklist(client, "Opportunity", "Type", type, "type")

    data = remove_none_values({
        "AccountId": account_id,
        "Name": name,
        "StageName": stage,
        "CloseDate": close_date,
        "Amount": amount,
        "Description": description,
        "NextStep": next_step,
        "LeadSource": lead_source,
        "Type": type,
    })

    result = await client.create_record("Opportunity", data)

    if not result.get("success"):
        raise SalesforceToolExecutionError(
            message="Failed to create opportunity",
            errors=result.get("errors", []),
            status_code=422,
        )

    return {"success": True, "opportunity_id": result["id"]}


@tool(
    requires_auth=OAuth2(id="salesforce", scopes=["write_opportunity"]),
    requires_secrets=["SALESFORCE_ORG_SUBDOMAIN", "SALESFORCE_MAX_CONCURRENT_REQUESTS"],
    metadata=ToolMetadata(
        classification=Classification(service_domains=[ServiceDomain.CRM]),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def update_opportunity(
    context: Context,
    opportunity_id: Annotated[str, "The Salesforce ID of the opportunity to update."],
    stage: Annotated[
        str | None,
        "New pipeline stage. Must match one of the org's configured stage names.",
    ] = None,
    close_date: Annotated[str | None, "New expected close date (YYYY-MM-DD)."] = None,
    amount: Annotated[
        float | None,
        "Updated deal amount. May be ignored if the opportunity has line items.",
    ] = None,
    next_step: Annotated[str | None, "Updated next action to advance the deal."] = None,
    description: Annotated[str | None, "Updated description or notes."] = None,
    name: Annotated[str | None, "Updated opportunity name."] = None,
    probability: Annotated[float | None, "Override win probability (0-100)."] = None,
    forecast_category: Annotated[
        ForecastCategory | None,
        "Override forecast category.",
    ] = None,
) -> Annotated[dict, "Update result with any warnings."]:
    """Updates fields on an existing opportunity. Only provided fields are changed.

    Returns a success indicator and any warnings (e.g., amount ignored due to line items).
    """
    validate_salesforce_id(opportunity_id, "opportunity_id", search_hint="SearchOpportunities")

    client = SalesforceClient(context)

    field_map: dict[str, Any] = {
        "StageName": stage,
        "CloseDate": close_date,
        "Amount": amount,
        "NextStep": next_step,
        "Description": description,
        "Name": name,
        "Probability": probability,
        "ForecastCategoryName": forecast_category.value if forecast_category else None,
    }
    data = remove_none_values(field_map)

    if not data:
        raise ToolExecutionError("At least one field must be provided to update.")

    if close_date:
        validate_soql_date(close_date)

    if stage:
        await _validate_picklist(client, "Opportunity", "StageName", stage, "stage")

    if probability is not None and (probability < 0 or probability > 100):
        raise ToolExecutionError("probability must be between 0 and 100.")

    await client.update_record("Opportunity", opportunity_id, data)

    warnings: list[dict] = []
    if amount is not None:
        try:
            safe_opp_id = sanitize_soql_id(opportunity_id)
            li_result = await client.query(
                f"SELECT COUNT() FROM OpportunityLineItem "  # noqa: S608
                f"WHERE OpportunityId = '{safe_opp_id}'"
            )
            if li_result["totalSize"] > 0:
                warnings.append({
                    "code": "AMOUNT_IGNORED_LINE_ITEMS",
                    "field": "amount",
                    "message": (
                        "Amount update was sent but may have been ignored because this "
                        "opportunity has line items. Salesforce enforces Amount as read-only "
                        "when line items exist."
                    ),
                })
        except SalesforceToolExecutionError:
            warnings.append({
                "code": "AMOUNT_CHECK_FAILED",
                "field": "amount",
                "message": (
                    "Could not verify whether this opportunity has line items. "
                    "If it does, the amount update may have been ignored by Salesforce."
                ),
            })

    return {
        "success": True,
        "opportunity_id": opportunity_id,
        "warnings": warnings,
    }
