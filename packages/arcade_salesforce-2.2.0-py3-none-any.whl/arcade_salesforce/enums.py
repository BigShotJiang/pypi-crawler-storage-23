from enum import Enum
from typing import cast


class ForecastCategory(str, Enum):
    PIPELINE = "Pipeline"
    BEST_CASE = "Best Case"
    COMMIT = "Commit"
    MOST_LIKELY = "Most Likely"
    OMITTED = "Omitted"
    CLOSED = "Closed"


class SalesforceObject(Enum):
    ACCOUNT = "Account"
    CALL = "Call"
    CONTACT = "Contact"
    EMAIL = "Email"
    EVENT = "Event"
    LEAD = "Lead"
    NOTE = "Note"
    OPPORTUNITY = "Opportunity"
    TASK = "Task"
    USER = "User"

    @property
    def plural(self) -> str:
        if self == SalesforceObject.OPPORTUNITY:
            return "Opportunities"
        return cast(str, self.value) + "s"
