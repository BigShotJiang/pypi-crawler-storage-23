SALESFORCE_API_VERSION = "v63.0"

ASSOCIATION_REFERENCE_FIELDS = [
    "AccountId",
    "OwnerId",
    "AssociatedToWhom",
    "ContactId",
]

GLOBALLY_IGNORED_FIELDS = [
    "attributes",
    "CleanStatus",
    "CreatedById",
    "CreatedDate",
    "IsDeleted",
    "LastModifiedById",
    "LastModifiedDate",
    "LastReferencedDate",
    "LastViewedDate",
    "PhotoUrl",
    "SystemModstamp",
]

# Fields stripped only in the account enrichment path (not globally,
# because task/opportunity tools need WhatId for association)
ACCOUNT_ENRICHMENT_IGNORED_FIELDS = ["WhatId"]
