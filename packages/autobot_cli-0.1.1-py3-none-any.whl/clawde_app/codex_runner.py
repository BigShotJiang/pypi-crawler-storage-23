from __future__ import annotations

import asyncio
import json
import logging
import os
import shlex
import sys
import shutil
import tempfile
import time
import signal
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence

from .config import AppConfig, AppPaths
from .models import RunMode, StructuredResponse, parse_structured_response

# Re-use ClaudeRunResult as the common result type for all backends.
from .claude_runner import ClaudeRunResult


class CodexRunnerError(RuntimeError):
    pass


def _build_unix_process_tree(root_pid: int) -> list[int]:
    """Build a pid tree rooted at ``root_pid`` using /proc."""
    parent_to_children: dict[int, list[int]] = {}
    try:
        for d in os.listdir("/proc"):
            if not d.isdigit():
                continue
            pid = int(d)
            try:
                with open(f"/proc/{pid}/stat", "r", encoding="utf-8") as f:
                    parts = f.read().split()
                ppid = int(parts[3])
            except Exception:
                continue
            parent_to_children.setdefault(ppid, []).append(pid)
    except Exception:
        return [root_pid]

    ordered: list[int] = []
    stack = [root_pid]
    while stack:
        pid = stack.pop()
        if pid in ordered:
            continue
        ordered.append(pid)
        stack.extend(parent_to_children.get(pid, []))

    # Kill deepest descendants first.
    return ordered


def kill_process_tree(pid: int) -> None:
    """Kill a process and all its children.

    Needed on Windows where child MCP processes keep pipes open after
    the parent exits.  Reusable by other modules (e.g. telegram_service
    for run cancellation).
    """
    if sys.platform == "win32":
        import subprocess as _sp
        try:
            _sp.run(
                ["taskkill", "/F", "/T", "/PID", str(pid)],
                stdout=_sp.DEVNULL, stderr=_sp.DEVNULL,
                timeout=10,
            )
        except Exception:
            pass
    else:
        if pid <= 0:
            return

        # Avoid killing the entire parent process group. On Linux, the child
        # runner can inherit the app's group, so os.killpg() could terminate
        # the main gateway. We only kill the known descendant tree instead.
        pids = _build_unix_process_tree(pid)
        if not pids:
            return
        for child_pid in sorted(set(pids), reverse=True):
            try:
                os.kill(int(child_pid), signal.SIGKILL)
            except ProcessLookupError:
                continue
            except Exception:
                pass


class CodexRunner:
    """
    Async wrapper around the OpenAI `codex` CLI.

    Uses `codex exec` for new runs and `codex exec resume <thread_id>` for
    session continuation.  Output is captured via `--json` (JSONL event stream)
    and `-o <tmpfile>` (final agent message).
    """

    def __init__(self, cfg: AppConfig, paths: AppPaths):
        self.cfg = cfg
        self.paths = paths

    @staticmethod
    async def _read_stream(stream) -> bytes:
        chunks = []
        while True:
            chunk = await stream.read(8192)
            if not chunk:
                break
            chunks.append(chunk)
        return b"".join(chunks)

    def _map_tool_profile_to_sandbox(self, tool_profile_name: str) -> str:
        profile = self.cfg.get_tool_profile(tool_profile_name)
        if profile.dangerously_skip_permissions:
            return "danger-full-access"
        if not profile.tools:
            return "read-only"
        return "workspace-write"

    @staticmethod
    def _resolve_executable(exe: str) -> str:
        """Resolve a runnable codex command on the current platform."""
        exe = (exe or "codex").strip().strip('"')
        if os.name != "nt":
            exe_normalized = exe.replace("\\", "/")
            direct = shutil.which(exe_normalized)
            if direct:
                return direct

            exe_name = Path(exe_normalized).name
            base_name = exe_name
            if exe_name.lower().endswith((".cmd", ".bat", ".exe")):
                base_name = exe_name.rsplit(".", 1)[0]

            fallback = shutil.which(base_name)
            if fallback:
                return fallback

            return base_name
        resolved = shutil.which(exe)
        return resolved or exe

    def _build_command(
        self,
        prompt: str,
        *,
        mode: RunMode,
        tool_profile_name: str,
        resume_session_id: Optional[str] = None,
        append_system_prompt_file: Optional[Path] = None,
        output_file: Path,
        extra_args: Optional[Sequence[str]] = None,
    ) -> tuple[List[str], str]:
        """Build the codex CLI command and return (cmd, full_prompt)."""

        # Prepend context to prompt if a system prompt file is provided
        if append_system_prompt_file is not None:
            try:
                context_text = append_system_prompt_file.read_text(encoding="utf-8")
                full_prompt = f"{context_text}\n\n---\n\nUser message:\n{prompt}"
            except Exception:
                full_prompt = prompt
        else:
            full_prompt = prompt

        # Resolve executable path (on Windows, npm installs .cmd shims that
        # asyncio.create_subprocess_exec can't find without the full path)
        exe = self._resolve_executable(self.cfg.codex.executable)
        cmd: List[str] = [exe]

        # Determine approval mode based on tool profile
        profile = self.cfg.get_tool_profile(tool_profile_name)
        use_full_bypass = profile.dangerously_skip_permissions

        if resume_session_id:
            # exec resume — limited flags available (no -o, --sandbox, -C)
            cmd += ["exec", "resume", resume_session_id]
            cmd.append("--json")
            if self.cfg.codex.model:
                cmd += ["--model", self.cfg.codex.model]
            cmd.append("--skip-git-repo-check")
            # Must set approval mode to avoid interactive prompts
            if use_full_bypass:
                cmd.append("--dangerously-bypass-approvals-and-sandbox")
            else:
                cmd.append("--full-auto")
        else:
            cmd += ["exec"]
            cmd.append("--json")
            if self.cfg.codex.model:
                cmd += ["--model", self.cfg.codex.model]
            # Sandbox policy
            sandbox = self._map_tool_profile_to_sandbox(tool_profile_name)
            cmd += ["--sandbox", sandbox]
            # Must set approval mode to avoid interactive prompts
            if use_full_bypass:
                cmd.append("--dangerously-bypass-approvals-and-sandbox")
            else:
                cmd.append("--full-auto")
            # Skip git repo check
            cmd.append("--skip-git-repo-check")
            # Output file for reliable structured output capture (only on exec, not resume)
            cmd += ["-o", str(output_file)]

        if extra_args:
            cmd += list(extra_args)

        # Use "-" as the prompt argument to read from stdin.
        # This avoids Windows command-line length limits (~32k chars)
        # when the context-prepended prompt is large.
        cmd.append("-")
        return cmd, full_prompt

    def _format_stream_event(self, event: Dict[str, Any]) -> str:
        etype = event.get("type", "?")

        if etype == "thread.started":
            tid = event.get("thread_id", "?")[:12]
            return f"[init] thread={tid}...\n"

        if etype == "turn.started":
            return "[turn] started\n"

        if etype == "item.started":
            item = event.get("item", {})
            itype = item.get("type", "?")
            if itype == "mcp_tool_call":
                return f"[item.started] {json.dumps(event, ensure_ascii=False)[:500]}\n"
            return f"[item.started] {itype}\n"

        if etype == "item.completed":
            item = event.get("item", {})
            itype = item.get("type", "?")
            text = item.get("text", "")
            if itype == "agent_message":
                preview = text[:200] + "..." if len(text) > 200 else text
                return f"[agent] {preview}\n"
            elif itype == "reasoning":
                preview = text[:200] + "..." if len(text) > 200 else text
                return f"[reasoning] {preview}\n"
            elif itype == "tool_call":
                name = item.get("name", "?")
                return f"[tool_call] {name}\n"
            elif itype == "tool_output":
                preview = text[:200] + "..." if len(text) > 200 else text
                return f"[tool_output] {preview}\n"
            elif itype == "mcp_tool_call":
                server = item.get("server", "?")
                tool = item.get("tool", "?")
                return f"[item] mcp_tool_call: {server}/{tool}\n"
            return f"[item] {itype}: {text[:200]}\n"

        if etype == "turn.completed":
            usage = event.get("usage", {})
            inp = usage.get("input_tokens", 0)
            cached = usage.get("cached_input_tokens", 0)
            out = usage.get("output_tokens", 0)
            return f"[turn.completed] input={inp} cached={cached} output={out}\n"

        if etype == "error":
            msg = event.get("message", "?")
            return f"[error] {msg[:500]}\n"

        if etype == "turn.failed":
            err = event.get("error", {})
            msg = err.get("message", "?") if isinstance(err, dict) else str(err)
            return f"[turn.failed] {msg[:500]}\n"

        return f"[{etype}] {json.dumps(event, ensure_ascii=False)[:300]}\n"

    def make_log_path(self, mode: RunMode) -> Path:
        """Generate the log file path for a run."""
        log_dir = self.paths.stderr_log_dir
        log_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return log_dir / f"codex_{mode.value}_{timestamp}.log"

    async def run(
        self,
        prompt: str,
        *,
        mode: RunMode,
        tool_profile_name: str,
        resume_session_id: Optional[str] = None,
        no_session_persistence: bool = False,
        append_system_prompt_file: Optional[Path] = None,
        max_turns: Optional[int] = None,
        json_schema: Optional[str] = None,
        extra_args: Optional[Sequence[str]] = None,
        timeout_seconds: Optional[int] = None,
        raise_on_error: bool = False,
        env_overrides: Optional[Dict[str, str]] = None,
        cwd_override: Optional[Path] = None,
        on_event: Optional[Callable[[Dict[str, Any]], Any]] = None,
        on_proc_started: Optional[Callable[[asyncio.subprocess.Process], Any]] = None,
        log_path: Optional[Path] = None,
    ) -> ClaudeRunResult:
        """
        Execute the `codex` CLI and parse its output.

        Returns ClaudeRunResult to maintain interface compatibility with ClaudeRunner.
        """
        # Create temp file for output capture
        output_tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", delete=False, dir=str(self.paths.runtime_dir),
            encoding="utf-8",
        )
        output_tmp_path = Path(output_tmp.name)
        output_tmp.close()

        try:
            return await self._run_impl(
                prompt,
                mode=mode,
                tool_profile_name=tool_profile_name,
                resume_session_id=resume_session_id,
                append_system_prompt_file=append_system_prompt_file,
                output_file=output_tmp_path,
                extra_args=extra_args,
                timeout_seconds=timeout_seconds,
                raise_on_error=raise_on_error,
                env_overrides=env_overrides,
                cwd_override=cwd_override,
                on_event=on_event,
                on_proc_started=on_proc_started,
                log_path=log_path,
            )
        finally:
            try:
                output_tmp_path.unlink(missing_ok=True)
            except Exception:
                pass

    async def _run_impl(
        self,
        prompt: str,
        *,
        mode: RunMode,
        tool_profile_name: str,
        resume_session_id: Optional[str],
        append_system_prompt_file: Optional[Path],
        output_file: Path,
        extra_args: Optional[Sequence[str]],
        timeout_seconds: Optional[int],
        raise_on_error: bool,
        env_overrides: Optional[Dict[str, str]],
        cwd_override: Optional[Path],
        on_event: Optional[Callable[[Dict[str, Any]], Any]],
        on_proc_started: Optional[Callable[[asyncio.subprocess.Process], Any]] = None,
        log_path: Optional[Path] = None,
    ) -> ClaudeRunResult:
        cmd, full_prompt = self._build_command(
            prompt,
            mode=mode,
            tool_profile_name=tool_profile_name,
            resume_session_id=resume_session_id,
            append_system_prompt_file=append_system_prompt_file,
            output_file=output_file,
            extra_args=extra_args,
        )

        cwd = str(cwd_override) if cwd_override else str(self.paths.repo_root)

        env = os.environ.copy()
        if env_overrides:
            env.update(env_overrides)

        # Prepare log file
        if log_path is None:
            log_path = self.make_log_path(mode)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_file = open(log_path, "w", encoding="utf-8")

        log = logging.getLogger("clawde.codex_runner")
        log.info("Codex streaming to: %s", log_path)

        start = time.monotonic()
        # Use a large buffer limit (16 MB) so that big tool results
        # (e.g. Chrome MCP take_snapshot) don't crash readline() with
        # LimitOverrunError.  The default is only 64 KB.
        _STREAM_LIMIT = 16 * 1024 * 1024  # 16 MB — match Claude runner
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=cwd,
            env=env,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            limit=_STREAM_LIMIT,
        )

        # Feed prompt via stdin (avoids Windows command-line length limits)
        assert proc.stdin is not None
        proc.stdin.write(full_prompt.encode("utf-8"))
        proc.stdin.close()

        if on_proc_started is not None:
            try:
                on_proc_started(proc)
            except Exception:
                pass

        stdout_lines: List[str] = []
        thread_id: Optional[str] = None
        last_agent_message: Optional[str] = None
        had_error: Optional[str] = None
        turn_completed = asyncio.Event()
        force_killed_after_completion = False
        # Track in-progress MCP tool calls for crash diagnostics
        active_mcp_calls: Dict[str, Dict[str, Any]] = {}

        async def _stream_stdout_ndjson():
            nonlocal thread_id, last_agent_message, had_error
            assert proc.stdout is not None
            while True:
                line_b = await proc.stdout.readline()
                if not line_b:
                    break
                line = line_b.decode("utf-8", errors="replace").rstrip("\n\r")
                if not line:
                    continue
                stdout_lines.append(line)
                try:
                    event = json.loads(line)
                    formatted = self._format_stream_event(event)
                    log_file.write(formatted)
                    log_file.flush()

                    # Capture thread_id
                    if event.get("type") == "thread.started":
                        thread_id = event.get("thread_id")

                    # Track in-progress MCP tool calls
                    if event.get("type") == "item.started":
                        item = event.get("item", {})
                        item_id = item.get("id", "")
                        if item.get("type") == "mcp_tool_call" and item_id:
                            active_mcp_calls[item_id] = {
                                "server": item.get("server", "?"),
                                "tool": item.get("tool", "?"),
                                "arguments": item.get("arguments", {}),
                            }

                    if event.get("type") == "item.completed":
                        item = event.get("item", {})
                        item_id = item.get("id", "")
                        # Remove from active tracking
                        active_mcp_calls.pop(item_id, None)
                        # Capture last agent message
                        if item.get("type") == "agent_message":
                            last_agent_message = item.get("text")

                    # Capture errors
                    if event.get("type") in ("error", "turn.failed"):
                        err_obj = event.get("error") or event.get("message")
                        if isinstance(err_obj, dict):
                            had_error = err_obj.get("message", str(err_obj))
                        else:
                            had_error = str(err_obj)

                    # Signal that the turn is done
                    if event.get("type") == "turn.completed":
                        turn_completed.set()

                    if on_event is not None:
                        try:
                            ret = on_event(event)
                            if asyncio.iscoroutine(ret):
                                await ret
                        except Exception:
                            pass

                except json.JSONDecodeError:
                    log_file.write(f"[raw] {line[:500]}\n")
                    log_file.flush()

        async def _run_and_wait():
            """Stream stdout/stderr then wait for process exit.

            Codex CLI may hang after turn.completed when MCP stdio servers
            were used (the child MCP process keeps stdout/stderr open).
            To handle this, once we see turn.completed we give the process
            a short grace period to exit, then force-kill the process tree.
            """

            # Start both stream readers
            stream_task = asyncio.ensure_future(asyncio.gather(
                _stream_stdout_ndjson(),
                self._read_stream(proc.stderr),
            ))

            # Wait for either: streams finish naturally, or turn_completed + grace period
            done = False
            while not done:
                if stream_task.done():
                    done = True
                    break
                # Check if turn completed
                try:
                    await asyncio.wait_for(turn_completed.wait(), timeout=2.0)
                except asyncio.TimeoutError:
                    continue
                # turn_completed is set — give process a grace period to exit
                try:
                    await asyncio.wait_for(stream_task, timeout=5.0)
                except asyncio.TimeoutError:
                    nonlocal force_killed_after_completion
                    force_killed_after_completion = True
                    log_file.write("[info] Process still alive 5s after turn.completed, force-killing\n")
                    log_file.flush()
                    kill_process_tree(proc.pid)
                    # Cancel the stream task since pipes may now be broken
                    stream_task.cancel()
                    try:
                        await stream_task
                    except (asyncio.CancelledError, Exception):
                        pass
                done = True

            # Get stderr bytes from the gather result
            stderr_bytes = b""
            try:
                if stream_task.done() and not stream_task.cancelled():
                    _, stderr_bytes = stream_task.result()
            except BaseException:
                pass

            # Wait for process to actually exit (should be immediate after kill)
            try:
                await asyncio.wait_for(proc.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                proc.kill()
                try:
                    await asyncio.wait_for(proc.wait(), timeout=3.0)
                except asyncio.TimeoutError:
                    pass

            return stderr_bytes

        try:
            if timeout_seconds is None:
                stderr_b = await _run_and_wait()
            else:
                stderr_b = await asyncio.wait_for(_run_and_wait(), timeout=timeout_seconds)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            duration = time.monotonic() - start
            res = ClaudeRunResult(
                ok=False,
                exit_code=124,
                duration_seconds=duration,
                command=cmd,
                cwd=cwd,
                stdout_text="",
                stderr_text="",
                raw_json=None,
                session_id=thread_id,
                structured=None,
                error=f"Codex CLI timed out after {timeout_seconds}s",
                log_file=str(log_path),
            )
            if raise_on_error:
                raise CodexRunnerError(res.error or "Timeout")
            return res
        finally:
            log_file.close()

        exit_code = int(proc.returncode or 0)
        duration = time.monotonic() - start
        stderr_text = stderr_b.decode("utf-8", errors="replace")

        # If we force-killed after turn.completed, treat as clean exit
        if force_killed_after_completion and exit_code != 0:
            log_path.open("a", encoding="utf-8").write(
                f"[info] Overriding exit code {exit_code} -> 0 (force-killed after turn.completed)\n"
            )
            exit_code = 0

        # Log stderr and exit code
        if stderr_text.strip():
            log_path.open("a", encoding="utf-8").write(f"[stderr] {stderr_text.strip()}\n")
        if exit_code != 0:
            log_path.open("a", encoding="utf-8").write(f"[exit] code={exit_code}\n")

        # If process crashed mid-turn with active MCP calls, log them
        if exit_code != 0 and active_mcp_calls:
            active_info = "; ".join(
                f"{v['server']}/{v['tool']}" for v in active_mcp_calls.values()
            )
            log_path.open("a", encoding="utf-8").write(
                f"[crash-context] Active MCP calls at exit: {active_info}\n"
            )

        stdout_text = "\n".join(stdout_lines)
        structured: Optional[StructuredResponse] = None
        err: Optional[str] = had_error

        if exit_code != 0 and not err:
            # Build a descriptive error with crash context
            parts = [f"Codex CLI exited with code {exit_code}"]
            if active_mcp_calls:
                active_info = ", ".join(
                    f"{v['server']}/{v['tool']}" for v in active_mcp_calls.values()
                )
                parts.append(f"crashed during MCP calls: {active_info}")
            if stderr_text.strip():
                # Include last 500 chars of stderr for diagnostics
                stderr_tail = stderr_text.strip()[-500:]
                parts.append(f"stderr: {stderr_tail}")
            err = " | ".join(parts)

        # Try to parse structured output from -o file first, then from last agent message
        output_text: Optional[str] = None
        try:
            if output_file.exists() and output_file.stat().st_size > 0:
                output_text = output_file.read_text(encoding="utf-8").strip()
        except Exception:
            pass

        if not output_text and last_agent_message:
            output_text = last_agent_message.strip()

        if not output_text:
            # Fall back to captured raw stdout lines if the CLI omitted the output file.
            # This is critical for environments where the file-based output path is not
            # supported by the installed `codex` package.
            non_json_lines = []
            for line in stdout_lines:
                cleaned = line.strip()
                if not cleaned:
                    continue
                try:
                    json.loads(cleaned)
                except Exception:
                    non_json_lines.append(cleaned)
            if non_json_lines:
                output_text = "\n".join(non_json_lines).strip()

        if not output_text and stdout_text.strip():
            output_text = stdout_text.strip()

        if output_text and not err:
            try:
                raw = json.loads(output_text)
                structured = parse_structured_response(raw)
            except json.JSONDecodeError:
                # Model returned non-JSON text — wrap it as a plain reply
                structured = StructuredResponse(reply=output_text, actions=[])
            except Exception:
                # Schema validation failed — try plain text fallback
                structured = StructuredResponse(reply=output_text, actions=[])

        if not structured and not err:
            if output_text:
                structured = StructuredResponse(reply=output_text, actions=[])
            else:
                stderr_tail = stderr_text.strip()
                if stderr_tail:
                    err = f"No output received from Codex CLI | stderr: {stderr_tail[-500:]}"
                else:
                    err = "No output received from Codex CLI"

        ok = (exit_code == 0) and (structured is not None) and (err is None)

        res = ClaudeRunResult(
            ok=ok,
            exit_code=exit_code,
            duration_seconds=duration,
            command=cmd,
            cwd=cwd,
            stdout_text=stdout_text,
            stderr_text=stderr_text,
            raw_json=None,
            session_id=thread_id,
            structured=structured,
            error=err,
            log_file=str(log_path),
        )

        if raise_on_error and not ok:
            debug = (
                f"{res.error}\n"
                f"cwd={res.cwd}\n"
                f"cmd={shlex.join(res.command)}\n"
                f"stderr={res.stderr_text[-4000:]}"
            )
            raise CodexRunnerError(debug)

        return res
