"""
Hybrid memory search index: BM25 (FTS5) + Qdrant vector search.

Chunks markdown files, embeds via OpenAI, stores vectors in Qdrant
and metadata + FTS5 in SQLite. Search combines vector similarity and
BM25 (keyword) with configurable weighting.

Falls back to keyword-only if OPENAI_API_KEY is not set or Qdrant is
unreachable.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Set, Tuple

import aiosqlite
import numpy as np

from .config import AppConfig, AppPaths
from .memory_retrieval import MemorySnippet, _safe_read, _extract_first_heading

log = logging.getLogger("clawde.memory_index")

# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------

_HEADING_RE = re.compile(r"^(#{1,4})\s+(.+)", re.MULTILINE)


def _chunk_markdown(
    text: str,
    *,
    target_chars: int = 1600,
    overlap_chars: int = 50,
) -> List[Tuple[Optional[str], str]]:
    """
    Split markdown text into chunks at heading/paragraph boundaries.

    Returns list of (heading, content) tuples.
    """
    if not text.strip():
        return []

    # Split into sections by headings
    sections: List[Tuple[Optional[str], str]] = []
    last_heading: Optional[str] = None
    last_pos = 0

    for m in _HEADING_RE.finditer(text):
        if m.start() > last_pos:
            body = text[last_pos:m.start()].strip()
            if body:
                sections.append((last_heading, body))
        last_heading = m.group(2).strip()
        last_pos = m.end()

    # Trailing content after last heading
    tail = text[last_pos:].strip()
    if tail:
        sections.append((last_heading, tail))

    if not sections:
        sections = [(None, text.strip())]

    # Split oversized sections on paragraph boundaries
    chunks: List[Tuple[Optional[str], str]] = []
    for heading, body in sections:
        if len(body) <= target_chars:
            chunks.append((heading, body))
            continue

        paragraphs = re.split(r"\n\s*\n", body)
        current = ""
        for para in paragraphs:
            if current and len(current) + len(para) + 2 > target_chars:
                chunks.append((heading, current.strip()))
                # Overlap: keep tail of previous chunk
                if overlap_chars and len(current) > overlap_chars:
                    current = current[-overlap_chars:] + "\n\n" + para
                else:
                    current = para
            else:
                current = current + "\n\n" + para if current else para

        if current.strip():
            chunks.append((heading, current.strip()))

    return chunks


# ---------------------------------------------------------------------------
# Embedding helpers
# ---------------------------------------------------------------------------

def _has_openai_key() -> bool:
    return bool(os.environ.get("OPENAI_API_KEY"))


async def _embed_texts(texts: List[str], model: str = "text-embedding-3-small") -> List[np.ndarray]:
    """Batch-embed texts via OpenAI API. Returns list of float32 arrays."""
    from openai import AsyncOpenAI  # lazy import

    client = AsyncOpenAI()
    # OpenAI supports up to 2048 inputs per batch
    all_embeddings: List[np.ndarray] = []
    batch_size = 50
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i + batch_size]
        resp = await client.embeddings.create(input=batch, model=model)
        for item in resp.data:
            all_embeddings.append(np.array(item.embedding, dtype=np.float32))
    return all_embeddings


# ---------------------------------------------------------------------------
# Qdrant helpers
# ---------------------------------------------------------------------------

def _get_qdrant_client(url: str):
    """Lazy-import and create an async Qdrant client."""
    from qdrant_client import AsyncQdrantClient
    return AsyncQdrantClient(url=url)


async def _ensure_qdrant_collection(client, collection_name: str, vector_size: int = 1536) -> None:
    """Create the Qdrant collection if it doesn't exist."""
    from qdrant_client.models import Distance, VectorParams

    collections = await client.get_collections()
    existing = {c.name for c in collections.collections}
    if collection_name not in existing:
        await client.create_collection(
            collection_name=collection_name,
            vectors_config=VectorParams(size=vector_size, distance=Distance.COSINE),
        )
        log.info("Created Qdrant collection '%s' (dim=%d)", collection_name, vector_size)


# ---------------------------------------------------------------------------
# MemoryIndex
# ---------------------------------------------------------------------------

class MemoryIndex:
    """Hybrid memory index: SQLite FTS5 for BM25 + Qdrant for vector search."""

    def __init__(self, db_path: Path, cfg: AppConfig):
        self.db_path = db_path
        self.cfg = cfg
        self._conn: Optional[aiosqlite.Connection] = None
        self._lock = asyncio.Lock()
        self._qdrant = None  # Lazy-initialized async Qdrant client
        self._qdrant_ready = False

    async def _get_conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            self._conn = await aiosqlite.connect(str(self.db_path))
            self._conn.row_factory = aiosqlite.Row
            await self._conn.execute("PRAGMA journal_mode=WAL;")
        return self._conn

    async def _get_qdrant(self):
        """Get or create the async Qdrant client. Returns None if unavailable."""
        if self._qdrant is not None:
            return self._qdrant
        rcfg = self.cfg.memory.retrieval
        try:
            self._qdrant = _get_qdrant_client(rcfg.qdrant_url)
            await _ensure_qdrant_collection(self._qdrant, rcfg.qdrant_collection)
            self._qdrant_ready = True
            return self._qdrant
        except Exception as e:
            log.warning("Qdrant unavailable at %s: %s (vector search disabled)", rcfg.qdrant_url, e)
            self._qdrant = None
            self._qdrant_ready = False
            return None

    async def close(self) -> None:
        if self._conn:
            await self._conn.close()
            self._conn = None
        if self._qdrant:
            try:
                await self._qdrant.close()
            except Exception:
                pass
            self._qdrant = None

    # -------------------------------------------------------------------
    # Indexing
    # -------------------------------------------------------------------

    @staticmethod
    def _content_hash(text: str) -> str:
        """SHA-256 hash of text content."""
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    async def _lookup_cached_embeddings(
        self, conn: aiosqlite.Connection, hashes: List[str], model: str
    ) -> Dict[str, np.ndarray]:
        """Look up cached embeddings by content hash. Returns {hash: embedding}."""
        if not hashes:
            return {}
        placeholders = ",".join("?" * len(hashes))
        rows = await (await conn.execute(
            f"SELECT content_hash, embedding FROM memory_embedding_cache "
            f"WHERE content_hash IN ({placeholders}) AND model=?",
            (*hashes, model),
        )).fetchall()
        result: Dict[str, np.ndarray] = {}
        for r in rows:
            result[r["content_hash"]] = np.frombuffer(r["embedding"], dtype=np.float32)
        return result

    async def _store_cached_embeddings(
        self, conn: aiosqlite.Connection, items: List[Tuple[str, np.ndarray, str]]
    ) -> None:
        """Store embeddings in cache. items = [(content_hash, embedding, model), ...]"""
        now = datetime.now(timezone.utc).isoformat()
        for content_hash, emb, model in items:
            await conn.execute(
                "INSERT OR REPLACE INTO memory_embedding_cache "
                "(content_hash, model, embedding, created_at) VALUES (?, ?, ?, ?)",
                (content_hash, model, emb.tobytes(), now),
            )

    async def reindex_file(self, agent_name: str, file_path: Path) -> int:
        """
        Chunk file, embed chunks, upsert into SQLite + Qdrant. Returns chunk count.

        Uses content hash to skip reindexing unchanged files and an embedding
        cache to avoid re-embedding unchanged chunks.
        """
        if not file_path.exists() or not file_path.is_file():
            await self._remove_file_chunks(agent_name, file_path)
            return 0

        mtime = file_path.stat().st_mtime
        rel_path = str(file_path.as_posix())

        text = _safe_read(file_path)
        if not text.strip():
            await self._remove_file_chunks(agent_name, file_path)
            return 0

        file_hash = self._content_hash(text)

        async with self._lock:
            conn = await self._get_conn()

            # Check if already indexed with same content hash (more reliable than mtime)
            row = await (await conn.execute(
                "SELECT content_hash FROM memory_chunks WHERE agent_name=? AND file_path=? LIMIT 1",
                (agent_name, rel_path),
            )).fetchone()
            if row and row["content_hash"] == file_hash:
                return 0  # Content unchanged, skip

            rcfg = self.cfg.memory.retrieval
            chunks = _chunk_markdown(
                text,
                target_chars=rcfg.chunk_target_tokens * 4,
                overlap_chars=rcfg.chunk_overlap_chars,
            )
            if not chunks:
                return 0

            # Compute content hashes for each chunk
            chunk_hashes = [self._content_hash(c[1]) for c in chunks]

            # Embed if OpenAI key available (with cache lookup)
            embeddings: List[Optional[np.ndarray]] = [None] * len(chunks)
            if _has_openai_key():
                try:
                    model = rcfg.embedding_model
                    # Look up cached embeddings
                    cached = await self._lookup_cached_embeddings(conn, chunk_hashes, model)
                    cache_misses: List[int] = []  # indices needing embedding
                    for i, h in enumerate(chunk_hashes):
                        if h in cached:
                            embeddings[i] = cached[h]
                        else:
                            cache_misses.append(i)

                    # Embed only cache misses
                    if cache_misses:
                        miss_texts = [chunks[i][1] for i in cache_misses]
                        new_embs = await _embed_texts(miss_texts, model=model)
                        to_cache: List[Tuple[str, np.ndarray, str]] = []
                        for j, idx in enumerate(cache_misses):
                            embeddings[idx] = new_embs[j]
                            to_cache.append((chunk_hashes[idx], new_embs[j], model))
                        await self._store_cached_embeddings(conn, to_cache)

                    if cached:
                        log.debug(
                            "%s: %d cached, %d embedded",
                            file_path.name, len(cached), len(cache_misses),
                        )
                except Exception as e:
                    log.warning("Embedding failed for %s: %s", file_path.name, e)

            # Delete old chunks for this file (SQLite)
            # Clean FTS first (before deleting the base rows it references)
            old_ids = await (await conn.execute(
                "SELECT chunk_id FROM memory_chunks WHERE agent_name=? AND file_path=?",
                (agent_name, rel_path),
            )).fetchall()
            for r in old_ids:
                await conn.execute("DELETE FROM memory_chunks_fts WHERE rowid=?", (r["chunk_id"],))
            await conn.execute(
                "DELETE FROM memory_chunks WHERE agent_name=? AND file_path=?",
                (agent_name, rel_path),
            )

            # Insert new chunks into SQLite (metadata + FTS only, no embedding BLOB)
            now = datetime.now(timezone.utc).isoformat()
            chunk_ids: List[int] = []
            for idx, (heading, content) in enumerate(chunks):
                cur = await conn.execute(
                    """
                    INSERT INTO memory_chunks
                        (agent_name, file_path, file_mtime, chunk_index, heading, content,
                         content_hash, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (agent_name, rel_path, mtime, idx, heading, content,
                     file_hash, now),
                )
                # Sync FTS index
                chunk_id = cur.lastrowid
                chunk_ids.append(chunk_id)
                await conn.execute(
                    "INSERT INTO memory_chunks_fts(rowid, content, heading) VALUES (?, ?, ?)",
                    (chunk_id, content, heading or ""),
                )

            await conn.commit()

        # Upsert embeddings to Qdrant (outside SQLite lock)
        qdrant = await self._get_qdrant()
        if qdrant and any(e is not None for e in embeddings):
            try:
                from qdrant_client.models import PointStruct
                points = []
                for idx, emb in enumerate(embeddings):
                    if emb is not None and idx < len(chunk_ids):
                        points.append(PointStruct(
                            id=chunk_ids[idx],
                            vector=emb.tolist(),
                            payload={
                                "agent_name": agent_name,
                                "file_path": rel_path,
                                "chunk_index": idx,
                            },
                        ))
                if points:
                    await qdrant.upsert(
                        collection_name=rcfg.qdrant_collection,
                        points=points,
                    )
            except Exception as e:
                log.warning("Qdrant upsert failed for %s: %s", file_path.name, e)

        log.debug("Indexed %s: %d chunks for agent=%s", file_path.name, len(chunks), agent_name)
        return len(chunks)

    async def _remove_file_chunks(self, agent_name: str, file_path: Path) -> None:
        """Remove all chunks for a file that no longer exists."""
        rel_path = str(file_path.as_posix())
        chunk_ids: List[int] = []

        async with self._lock:
            conn = await self._get_conn()
            # Get chunk IDs for FTS + Qdrant cleanup
            rows = await (await conn.execute(
                "SELECT chunk_id FROM memory_chunks WHERE agent_name=? AND file_path=?",
                (agent_name, rel_path),
            )).fetchall()
            chunk_ids = [r["chunk_id"] for r in rows]
            for cid in chunk_ids:
                await conn.execute("DELETE FROM memory_chunks_fts WHERE rowid=?", (cid,))
            await conn.execute(
                "DELETE FROM memory_chunks WHERE agent_name=? AND file_path=?",
                (agent_name, rel_path),
            )
            await conn.commit()

        # Delete from Qdrant
        if chunk_ids:
            qdrant = await self._get_qdrant()
            if qdrant:
                try:
                    from qdrant_client.models import PointIdsList
                    await qdrant.delete(
                        collection_name=self.cfg.memory.retrieval.qdrant_collection,
                        points_selector=PointIdsList(points=chunk_ids),
                    )
                except Exception as e:
                    log.debug("Qdrant delete failed: %s", e)

    async def reindex_agent(self, agent_name: str, memory_dir: Path) -> int:
        """
        Full reindex of an agent's memory directory.
        Also removes stale entries for deleted files.
        Returns total chunk count.
        """
        if not memory_dir.is_dir():
            return 0

        files = list(memory_dir.rglob("*.md"))
        total = 0
        for f in files:
            n = await self.reindex_file(agent_name, f)
            total += n

        # Remove stale entries for files that no longer exist
        async with self._lock:
            conn = await self._get_conn()
            rows = await (await conn.execute(
                "SELECT DISTINCT file_path FROM memory_chunks WHERE agent_name=?",
                (agent_name,),
            )).fetchall()
            for r in rows:
                fp = Path(r["file_path"])
                if not fp.exists():
                    await self._remove_file_chunks(agent_name, fp)

        return total

    # -------------------------------------------------------------------
    # Search
    # -------------------------------------------------------------------

    async def search(
        self,
        agent_name: str,
        query: str,
        *,
        top_k: int = 6,
        max_chars: int = 1500,
    ) -> List[MemorySnippet]:
        """Hybrid search: BM25 + vector cosine similarity."""
        rcfg = self.cfg.memory.retrieval

        # BM25 search (4x candidates for better merge coverage)
        bm25_results = await self._bm25_search(agent_name, query, limit=top_k * 4)

        # Vector search (if embeddings available and Qdrant reachable)
        vector_results: List[Tuple[int, float]] = []
        if _has_openai_key():
            try:
                query_embs = await _embed_texts([query], model=rcfg.embedding_model)
                query_emb = query_embs[0]
                vector_results = await self._vector_search(
                    agent_name, query_emb, limit=top_k * 4
                )
            except Exception as e:
                log.warning("Vector search failed: %s", e)

        # Combine scores
        combined = self._merge_scores(
            bm25_results, vector_results,
            text_weight=rcfg.text_weight,
            vector_weight=rcfg.vector_weight,
        )

        # Filter by minimum score threshold
        min_score = rcfg.min_score
        combined = [(cid, score) for cid, score in combined if score >= min_score]

        # Fetch chunk data and build snippets
        top_ids = [cid for cid, _ in combined[:top_k]]
        if not top_ids:
            return []

        async with self._lock:
            conn = await self._get_conn()
            placeholders = ",".join("?" * len(top_ids))
            rows = await (await conn.execute(
                f"SELECT chunk_id, file_path, heading, content FROM memory_chunks "
                f"WHERE chunk_id IN ({placeholders})",
                top_ids,
            )).fetchall()

        # Map rows by chunk_id
        row_map = {r["chunk_id"]: r for r in rows}
        score_map = {cid: score for cid, score in combined[:top_k]}

        snippets: List[MemorySnippet] = []
        for cid in top_ids:
            r = row_map.get(cid)
            if not r:
                continue
            fp = Path(r["file_path"])
            content = r["content"]
            if len(content) > max_chars:
                content = content[:max_chars] + "\n..."

            kind = "daily" if "daily" in r["file_path"] else "topic"
            snippets.append(MemorySnippet(
                source_path=fp,
                score=score_map.get(cid, 0),
                kind=kind,
                title=r["heading"] or _extract_first_heading(content),
                excerpt=content,
            ))

        return snippets

    @staticmethod
    def _build_fts_query(query: str) -> str:
        """Tokenize and quote a query for FTS5 MATCH.

        Extracts word tokens (>=2 chars), quotes each, and AND-joins them.
        This prevents FTS5 syntax errors from special characters and produces
        more precise matches than raw query strings.
        """
        tokens = re.findall(r"\w+", query.lower())
        tokens = [t for t in tokens if len(t) >= 2]
        if not tokens:
            return ""
        return " AND ".join(f'"{t}"' for t in tokens)

    async def _bm25_search(
        self, agent_name: str, query: str, limit: int = 20
    ) -> List[Tuple[int, float]]:
        """FTS5 BM25 search. Returns (chunk_id, normalized_score) pairs."""
        fts_query = self._build_fts_query(query)
        if not fts_query:
            return []

        async with self._lock:
            conn = await self._get_conn()
            try:
                rows = await (await conn.execute(
                    """
                    SELECT mc.chunk_id, bm25(memory_chunks_fts) AS rank
                    FROM memory_chunks_fts fts
                    JOIN memory_chunks mc ON mc.chunk_id = fts.rowid
                    WHERE memory_chunks_fts MATCH ? AND mc.agent_name = ?
                    ORDER BY rank
                    LIMIT ?
                    """,
                    (fts_query, agent_name, limit),
                )).fetchall()
            except Exception:
                # FTS5 MATCH can fail on edge cases
                return []

        if not rows:
            return []

        # BM25 returns negative scores (lower = better).
        # Use absolute normalization: score = 1 / (1 + abs(rank))
        # This produces stable [0, 1] scores comparable to cosine similarity.
        return [
            (r["chunk_id"], 1.0 / (1.0 + abs(r["rank"])))
            for r in rows
        ]

    async def _vector_search(
        self, agent_name: str, query_embedding: np.ndarray, limit: int = 20
    ) -> List[Tuple[int, float]]:
        """Vector search via Qdrant. Returns (chunk_id, normalized_score) pairs."""
        qdrant = await self._get_qdrant()
        if not qdrant:
            return []

        rcfg = self.cfg.memory.retrieval
        try:
            from qdrant_client.models import Filter, FieldCondition, MatchValue

            results = await qdrant.query_points(
                collection_name=rcfg.qdrant_collection,
                query=query_embedding.tolist(),
                query_filter=Filter(
                    must=[FieldCondition(key="agent_name", match=MatchValue(value=agent_name))]
                ),
                limit=limit,
            )

            if not results.points:
                return []

            # Qdrant cosine similarity returns scores in [0, 1] (for cosine distance).
            # Normalize to [0, 1] relative to top score.
            pairs = [(p.id, p.score) for p in results.points]
            max_score = pairs[0][1] if pairs[0][1] > 0 else 1
            return [(cid, score / max_score if max_score else 0) for cid, score in pairs]

        except Exception as e:
            log.warning("Qdrant search failed: %s", e)
            return []

    @staticmethod
    def _merge_scores(
        bm25: List[Tuple[int, float]],
        vector: List[Tuple[int, float]],
        *,
        text_weight: float = 0.3,
        vector_weight: float = 0.7,
    ) -> List[Tuple[int, float]]:
        """Merge BM25 and vector scores. Returns sorted (chunk_id, combined_score)."""
        scores: Dict[int, float] = {}
        for cid, s in bm25:
            scores[cid] = scores.get(cid, 0) + text_weight * s
        for cid, s in vector:
            scores[cid] = scores.get(cid, 0) + vector_weight * s
        combined = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return combined

    # -------------------------------------------------------------------
    # File watcher
    # -------------------------------------------------------------------

    async def start_watcher(
        self,
        memory_dirs: List[Tuple[str, Path]],
    ) -> None:
        """
        Background task: watch memory dirs, reindex changed files.

        *memory_dirs* is a list of (agent_name, memory_dir) tuples.
        """
        try:
            from watchfiles import awatch, Change
        except ImportError:
            log.warning("watchfiles not installed — memory file watcher disabled")
            return

        paths = [d for _, d in memory_dirs if d.is_dir()]
        if not paths:
            return

        # Build path → agent_name mapping
        path_to_agent: Dict[str, str] = {}
        for agent_name, mem_dir in memory_dirs:
            path_to_agent[str(mem_dir.resolve())] = agent_name

        def _resolve_agent(file_path: Path) -> Optional[str]:
            for dir_str, name in path_to_agent.items():
                if str(file_path.resolve()).startswith(dir_str):
                    return name
            return None

        log.info("Memory file watcher started for %d directories", len(paths))
        try:
            async for changes in awatch(*paths):
                for change_type, path_str in changes:
                    p = Path(path_str)
                    if p.suffix != ".md":
                        continue
                    agent = _resolve_agent(p)
                    if agent is None:
                        continue
                    try:
                        await self.reindex_file(agent, p)
                    except Exception:
                        log.debug("Watcher reindex failed for %s", p, exc_info=True)
        except asyncio.CancelledError:
            log.info("Memory file watcher stopped")
        except Exception:
            log.error("Memory file watcher crashed", exc_info=True)
