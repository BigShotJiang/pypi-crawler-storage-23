"""Agent profile helpers: path resolution, listing, scaffolding, validation."""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


@dataclass(frozen=True)
class AgentPaths:
    """Resolved filesystem paths for a single agent."""

    name: str
    soul_file: Path           # agents/{name}/soul.md
    memory_dir: Path          # agents/{name}/memory
    memory_topics_dir: Path   # agents/{name}/memory/topics
    memory_daily_dir: Path    # agents/{name}/memory/daily
    skills_dir: Path          # agents/{name}/skills
    goals_dir: Path           # agents/{name}/goals


def resolve_agent(agents_dir: Path, name: str) -> Optional[AgentPaths]:
    """Return :class:`AgentPaths` if the agent directory exists, else ``None``."""
    agent_dir = agents_dir / name
    if not agent_dir.is_dir():
        return None
    return AgentPaths(
        name=name,
        soul_file=agent_dir / "soul.md",
        memory_dir=agent_dir / "memory",
        memory_topics_dir=agent_dir / "memory" / "topics",
        memory_daily_dir=agent_dir / "memory" / "daily",
        skills_dir=agent_dir / "skills",
        goals_dir=agent_dir / "goals",
    )


def list_agents(agents_dir: Path) -> List[str]:
    """Return sorted list of agent names (subdirs that contain ``soul.md``)."""
    if not agents_dir.is_dir():
        return []
    return sorted(
        d.name
        for d in agents_dir.iterdir()
        if d.is_dir() and (d / "soul.md").exists()
    )


def ensure_agent_scaffold(agent: AgentPaths) -> None:
    """Create the agent's memory, skills, and goals directories if they don't exist."""
    agent.memory_dir.mkdir(parents=True, exist_ok=True)
    agent.memory_topics_dir.mkdir(parents=True, exist_ok=True)
    agent.memory_daily_dir.mkdir(parents=True, exist_ok=True)
    agent.skills_dir.mkdir(parents=True, exist_ok=True)
    agent.goals_dir.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

_AGENT_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{0,31}$")
_RESERVED_NAMES = frozenset({"admin", "system", "bot", "all", "help", "default", "none"})
_TOKEN_RE = re.compile(r"^\d+:[A-Za-z0-9_-]{30,}$")


def validate_agent_name(name: str) -> Optional[str]:
    """Return an error message if *name* is invalid, else ``None``."""
    if not name:
        return "Agent name cannot be empty."
    if name in _RESERVED_NAMES:
        return f"'{name}' is a reserved name."
    if not _AGENT_NAME_RE.match(name):
        return "Name must be 1-32 chars, lowercase letters/digits/underscore, starting with a letter."
    return None


def validate_bot_token_format(token: str) -> Optional[str]:
    """Return an error message if *token* doesn't look like a Telegram bot token."""
    if not token:
        return "Bot token cannot be empty."
    if not _TOKEN_RE.match(token):
        return "Token format looks wrong. Expected: digits:alphanumeric (get one from @BotFather)."
    return None


# ---------------------------------------------------------------------------
# Scaffold creation
# ---------------------------------------------------------------------------

_DEFAULT_SOUL_TEMPLATE = """\
# Soul

You are **{display_name}**: an automation agent running through the clawde gateway.

- Be direct, calm, and precise.
- Prefer safe defaults and least privilege.

(Customize this file to define your personality and behavior.)
"""


def create_agent_scaffold(
    agents_dir: Path,
    name: str,
    soul_text: Optional[str] = None,
) -> AgentPaths:
    """Create a new agent's directory structure with soul.md and memory dirs.

    Returns the :class:`AgentPaths` for the new agent.
    Raises :class:`FileExistsError` if the agent directory already exists.
    """
    agent_dir = agents_dir / name
    if agent_dir.exists():
        raise FileExistsError(f"Agent directory already exists: {agent_dir}")

    paths = AgentPaths(
        name=name,
        soul_file=agent_dir / "soul.md",
        memory_dir=agent_dir / "memory",
        memory_topics_dir=agent_dir / "memory" / "topics",
        memory_daily_dir=agent_dir / "memory" / "daily",
        skills_dir=agent_dir / "skills",
        goals_dir=agent_dir / "goals",
    )

    agent_dir.mkdir(parents=True, exist_ok=True)
    ensure_agent_scaffold(paths)

    if soul_text is None:
        display_name = name.replace("_", " ").title()
        soul_text = _DEFAULT_SOUL_TEMPLATE.format(display_name=display_name)
    paths.soul_file.write_text(soul_text, encoding="utf-8")

    return paths
