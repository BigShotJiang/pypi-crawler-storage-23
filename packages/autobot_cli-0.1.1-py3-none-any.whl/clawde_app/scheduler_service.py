from __future__ import annotations

import asyncio
import json
import os
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Protocol, Set

from apscheduler.schedulers.asyncio import AsyncIOScheduler  # type: ignore
from apscheduler.triggers.cron import CronTrigger  # type: ignore
from apscheduler.triggers.date import DateTrigger  # type: ignore
from apscheduler.triggers.interval import IntervalTrigger  # type: ignore

import logging

from .activity_feed import activity_feed

from .actions import ActionExecContext, ActionExecutor
from .agent_tag import extract_agent_tag
from .backend_tag import extract_backend_tag
from .claude_runner import ClaudeRunner
from .codex_runner import CodexRunner
from .gemini_runner import GeminiRunner
from .config import AppConfig, AppPaths
from .context_builder import ContextBuilder
from .db import Database, utc_now_iso
from .models import EventRole, EventSource, JobScheduleType, RunMode


def _get_tz(tz_str: str):
    tz_str = tz_str or "Europe/London"
    try:
        from zoneinfo import ZoneInfo

        return ZoneInfo(tz_str)
    except Exception:
        try:
            import pytz  # type: ignore

            return pytz.timezone(tz_str)
        except Exception:
            return tz_str


class TelegramBridge(Protocol):
    async def send_cron_post(self, chat_id: int, text: str, *, job_id: int, job_name: str, skip_ingest: bool = False) -> None:
        ...


@dataclass
class SchedulerJobInfo:
    job_id: int
    name: str
    enabled: bool
    schedule_type: str
    schedule_value: str
    timezone: str
    prompt: str
    target_chat_id: Optional[int]
    tool_profile: str
    active_start: Optional[str] = None
    active_end: Optional[str] = None
    backend: Optional[str] = None
    agent_profile: Optional[str] = None
    sessionful: bool = False
    claude_session_id: Optional[str] = None
    use_chat_session: bool = False
    project_dir: Optional[str] = None
    autodev_config: Optional[str] = None
    custom_instructions: Optional[str] = None
    model: Optional[str] = None
    thinking: Optional[str] = None


class SchedulerService:
    """
    APScheduler-based cron system. Jobs are stored in SQLite (our DB), not APScheduler.

    - On start: load enabled jobs from DB and schedule them.
    - On reload: resync scheduler jobs with DB.
    - On fire: run Claude stateless (--no-session-persistence), execute actions, optionally post to Telegram,
      and then (if target chat exists) ask TelegramService to ingest the cron post into session.
    """

    def __init__(
        self,
        cfg: AppConfig,
        paths: AppPaths,
        db: Database,
        claude: ClaudeRunner,
        codex: CodexRunner,
        gemini: GeminiRunner,
        context_builder: ContextBuilder,
        actions: ActionExecutor,
        telegram_services: Dict[str, TelegramBridge],
    ):
        self.cfg = cfg
        self.paths = paths
        self.db = db
        self.claude = claude
        self.codex = codex
        self.gemini = gemini
        self.context_builder = context_builder
        self.actions = actions
        self.telegram_services = telegram_services
        self._log = logging.getLogger("clawde.scheduler")

        self.scheduler = AsyncIOScheduler(timezone=_get_tz(self.cfg.scheduler.timezone))
        self._sem = asyncio.Semaphore(max(1, int(self.cfg.scheduler.max_concurrent_jobs)))
        self._running_jobs: Set[int] = set()
        self._running_procs: Dict[int, asyncio.subprocess.Process] = {}
        self._started = False

    async def start(self) -> None:
        if self._started:
            return
        self.scheduler.start()
        await self.reload_jobs()
        self._started = True

    async def shutdown(self) -> None:
        try:
            self.scheduler.shutdown(wait=False)
        except Exception:
            pass
        self._started = False

    async def reload_jobs(self) -> None:
        """
        Clear all jobs from APScheduler and re-add enabled jobs from DB.
        """
        # Remove all existing jobs
        for j in self.scheduler.get_jobs():
            try:
                self.scheduler.remove_job(j.id)
            except Exception:
                pass

        rows = await self.db.list_jobs(enabled_only=True)
        for row in rows:
            info = self._row_to_info(row)
            try:
                trigger = self._build_trigger(info)
            except Exception:
                # If trigger invalid, disable job to prevent repeated errors
                await self.db.set_job_enabled(info.job_id, False)
                continue

            self.scheduler.add_job(
                self._run_job,
                trigger=trigger,
                args=[info.job_id],
                id=str(info.job_id),
                name=info.name,
                replace_existing=True,
                misfire_grace_time=int(self.cfg.scheduler.misfire_grace_seconds),
                coalesce=bool(self.cfg.scheduler.coalesce),
                max_instances=1,
            )

            # next run time bookkeeping
            job = self.scheduler.get_job(str(info.job_id))
            if job and job.next_run_time:
                await self.db.update_job_run_times(info.job_id, next_run_ts=job.next_run_time.isoformat())

    def _get_runner(self, backend: Optional[str] = None):
        """Return the appropriate runner based on backend string."""
        b = backend or self.cfg.default_backend
        if b == "codex":
            return self.codex
        if b == "gemini":
            return self.gemini
        return self.claude

    @staticmethod
    def _parse_cli_timeout(env_value: str) -> Optional[int]:
        """Parse a CLI timeout env value.

        Returns None for empty or invalid values.
        """
        raw = (env_value or "").strip()
        if not raw:
            return None
        try:
            parsed = int(raw)
        except ValueError:
            return None
        return parsed if parsed > 0 else None

    def _resolve_run_timeout(self, backend: str) -> Optional[int]:
        backend_key = (backend or "claude").upper()
        for key in [
            f"CLAWDE_{backend_key}_CLI_TIMEOUT_SECONDS",
            "CLAWDE_CLI_TIMEOUT_SECONDS",
        ]:
            timeout = self._parse_cli_timeout(os.getenv(key, ""))
            if timeout is not None:
                return timeout
        return None

    def _row_to_info(self, row: Dict[str, Any]) -> SchedulerJobInfo:
        return SchedulerJobInfo(
            job_id=int(row["job_id"]),
            name=str(row["name"]),
            enabled=bool(row["enabled"]),
            schedule_type=str(row["schedule_type"]),
            schedule_value=str(row["schedule_value"]),
            timezone=str(row.get("timezone") or self.cfg.scheduler.timezone),
            prompt=str(row["prompt"]),
            target_chat_id=row.get("target_chat_id"),
            tool_profile=str(row.get("tool_profile") or "read_only"),
            active_start=row.get("active_start"),
            active_end=row.get("active_end"),
            backend=row.get("backend"),
            agent_profile=row.get("agent_profile"),
            sessionful=bool(row.get("sessionful", 0)),
            claude_session_id=row.get("claude_session_id"),
            use_chat_session=bool(row.get("use_chat_session", 0)),
            project_dir=row.get("project_dir"),
            autodev_config=row.get("autodev_config"),
            custom_instructions=row.get("custom_instructions"),
            model=row.get("model"),
            thinking=row.get("thinking"),
        )

    def _is_in_active_window(self, info: SchedulerJobInfo) -> bool:
        """Return True if current time is within the job's active window (or no window set)."""
        if not info.active_start or not info.active_end:
            return True
        tz = _get_tz(info.timezone)
        now_time = datetime.now(tz=tz).time()
        start = datetime.strptime(info.active_start, "%H:%M").time()
        end = datetime.strptime(info.active_end, "%H:%M").time()
        if start <= end:
            return start <= now_time <= end
        else:
            # Overnight range: e.g. 23:00-09:00
            return now_time >= start or now_time <= end

    def _next_window_start(self, info: SchedulerJobInfo) -> datetime:
        """Compute the next datetime when the active window opens."""
        tz = _get_tz(info.timezone)
        now = datetime.now(tz=tz)
        start = datetime.strptime(info.active_start, "%H:%M").time()
        candidate = now.replace(hour=start.hour, minute=start.minute, second=0, microsecond=0)
        if candidate <= now:
            candidate += timedelta(days=1)
        return candidate

    def _build_trigger(self, info: SchedulerJobInfo):
        tz = _get_tz(info.timezone)
        st = info.schedule_type

        if st == JobScheduleType.cron.value:
            # 5-field crontab
            return CronTrigger.from_crontab(info.schedule_value, timezone=tz)

        if st == JobScheduleType.interval.value:
            # JSON dict like {"minutes":30}
            obj = json.loads(info.schedule_value)
            if not isinstance(obj, dict):
                raise ValueError("interval schedule_value must be JSON object")
            # Ensure ints
            kwargs = {k: int(v) for k, v in obj.items()}
            return IntervalTrigger(timezone=tz, **kwargs)

        if st == JobScheduleType.once.value:
            s = info.schedule_value.replace("Z", "+00:00")
            dt = datetime.fromisoformat(s)
            # If naive datetime, assume configured timezone
            if dt.tzinfo is None:
                # Attach timezone without conversion
                dt = dt.replace(tzinfo=tz)
            return DateTrigger(run_date=dt, timezone=tz)

        if st == JobScheduleType.gapped.value:
            obj = json.loads(info.schedule_value)
            if not isinstance(obj, dict):
                raise ValueError("gapped schedule_value must be JSON object")
            kwargs = {k: int(v) for k, v in obj.items()}
            next_run = datetime.now(tz=tz) + timedelta(**kwargs)
            return DateTrigger(run_date=next_run, timezone=tz)

        raise ValueError(f"Unknown schedule_type: {st}")

    async def trigger_job(self, job_id: int) -> None:
        """Trigger a job immediately, bypassing enabled/window guards.

        Raises RuntimeError if job is already running, ValueError if not found.
        The job runs in the background via create_task.
        """
        row = await self.db.get_job(job_id)
        if not row:
            raise ValueError(f"Job {job_id} not found")
        if job_id in self._running_jobs:
            raise RuntimeError(f"Job {job_id} is already running")
        asyncio.create_task(self._run_job(job_id, force=True))

    @property
    def running_job_ids(self) -> Set[int]:
        return set(self._running_jobs)

    async def stop_job(self, job_id: int) -> bool:
        """Stop a running job by killing its process. Returns True if killed."""
        proc = self._running_procs.pop(job_id, None)
        if proc is None:
            return False
        pid = proc.pid
        if pid is not None:
            from .codex_runner import kill_process_tree
            kill_process_tree(pid)
        else:
            try:
                proc.kill()
            except Exception:
                pass
        return True

    async def _run_job(self, job_id: int, *, force: bool = False) -> None:
        if job_id in self._running_jobs:
            raise RuntimeError(f"Job {job_id} is already running")
        self._running_jobs.add(job_id)
        try:
            await self._run_job_impl(job_id, force=force)
        finally:
            self._running_jobs.discard(job_id)
            self._running_procs.pop(job_id, None)

    async def _run_job_impl(self, job_id: int, *, force: bool = False) -> None:
        async with self._sem:
            row = await self.db.get_job(job_id)
            if not row:
                return
            info = self._row_to_info(row)
            if not force and not info.enabled:
                return

            # Rebuild prompt from autodev config if this is an autodev job
            if info.autodev_config:
                try:
                    from .actions import build_autodev_prompt
                    config = json.loads(info.autodev_config)
                    info.prompt = build_autodev_prompt(config, info.custom_instructions)
                except Exception:
                    self._log.warning("Failed to rebuild autodev prompt for job #%d, using stored prompt", job_id)

            # Check active window
            if not force and not self._is_in_active_window(info):
                # For gapped jobs: defer to next window start
                if info.schedule_type == JobScheduleType.gapped.value:
                    try:
                        tz = _get_tz(info.timezone)
                        next_start = self._next_window_start(info)
                        try:
                            self.scheduler.remove_job(str(job_id))
                        except Exception:
                            pass
                        self.scheduler.add_job(
                            self._run_job,
                            trigger=DateTrigger(run_date=next_start, timezone=tz),
                            args=[job_id],
                            id=str(job_id),
                            name=info.name,
                            replace_existing=True,
                            misfire_grace_time=int(self.cfg.scheduler.misfire_grace_seconds),
                            coalesce=True,
                            max_instances=1,
                        )
                        await self.db.update_job_run_times(job_id, next_run_ts=next_start.isoformat())
                    except Exception:
                        pass
                return

            # Extract inline overrides from job prompt (tags stay in DB)
            backend_override, clean_prompt = extract_backend_tag(info.prompt)
            agent_override, clean_prompt = extract_agent_tag(clean_prompt)

            # Resolve effective agent: inline tag > job's agent_profile > first configured agent
            effective_agent = agent_override or info.agent_profile
            if not effective_agent and self.cfg.agents:
                effective_agent = next(iter(self.cfg.agents))

            activity_feed.emit(effective_agent or "scheduler", "job", f"Job #{job_id} '{info.name}' fired")

            # Build context pack for cron run
            ctx_info = await self.context_builder.build_and_write(
                mode=RunMode.cron,
                query_text=clean_prompt,
                chat_id=None,
                job_id=job_id,
                is_admin=False,
                tool_profile=info.tool_profile,
                last_ingested_event_id=0,
                agent_name=effective_agent,
                project_dir=info.project_dir,
            )

            # Select backend runner for this job (inline tag overrides job backend)
            if backend_override:
                backend = backend_override
            elif info.backend:
                backend = info.backend
            elif effective_agent and effective_agent in self.cfg.agents:
                backend = self.cfg.agents[effective_agent].default_backend
            else:
                backend = self.cfg.default_backend
            runner = self._get_runner(backend)
            if backend == "codex":
                max_turns = self.cfg.codex.max_turns_cron
            elif backend == "gemini":
                max_turns = self.cfg.gemini.max_turns_cron
            else:
                max_turns = self.cfg.claude.max_turns_cron

            # Pre-create log path so it's available in DB before the run starts
            run_log_path = runner.make_log_path(RunMode.cron)

            # Session resolution: use_chat_session borrows the Telegram chat's
            # session; sessionful uses the job's own; otherwise stateless.
            chat_session_before: Optional[str] = None
            using_chat_session = False

            if info.use_chat_session and info.target_chat_id is not None:
                chat_row = await self.db.get_chat(effective_agent or "", info.target_chat_id)
                if chat_row and chat_row.backend and chat_row.backend != backend:
                    self._log.warning(
                        "use_chat_session job #%d: backend mismatch (job=%s, chat=%s) — "
                        "falling back to own session",
                        job_id, backend, chat_row.backend,
                    )
                    resume_sid = info.claude_session_id
                    no_persist = False
                else:
                    using_chat_session = True
                    chat_session_before = chat_row.claude_session_id if chat_row else None
                    resume_sid = chat_session_before  # None on first-ever run → new session
                    no_persist = False
            elif info.sessionful:
                resume_sid = info.claude_session_id  # None on first run
                no_persist = False
            else:
                resume_sid = None
                no_persist = True

            run_id = await self.db.start_run(
                mode=RunMode.cron,
                chat_id=info.target_chat_id,
                job_id=job_id,
                claude_session_id=resume_sid if (info.use_chat_session or info.sessionful) else None,
                prompt_preview=(clean_prompt[:200] + "…") if len(clean_prompt) > 200 else clean_prompt,
                agent_name=effective_agent or "",
                log_file=str(run_log_path),
                prompt_full=clean_prompt,
            )

            cwd_override = Path(info.project_dir) if info.project_dir else None

            # Sync MCP server configs into working directory before run
            try:
                from .mcp_sync import sync_mcp_to_cwd, ensure_mcp_scaffold
                ensure_mcp_scaffold(self.paths.mcp_servers_dir)
                effective_cwd = cwd_override or self.paths.repo_root
                sync_mcp_to_cwd(
                    self.paths.mcp_servers_dir, effective_cwd, backend,
                    agent_name=effective_agent or "", repo_root=self.paths.repo_root,
                )
            except Exception:
                self._log.debug("MCP sync skipped", exc_info=True)

            def _on_job_event(event: Dict[str, Any]) -> None:
                from .telegram_service import TelegramService
                line = TelegramService._format_progress_line(event)
                if line:
                    activity_feed.emit(effective_agent or "scheduler", "cli", f"[Job {info.name}] {line}")

            def _on_proc_started(proc: asyncio.subprocess.Process) -> None:
                self._running_procs[job_id] = proc

            # Per-job model + thinking overrides
            job_extra_args: List[str] = []
            job_env_overrides: Dict[str, str] = {}

            if info.model:
                # All three CLIs use --model; appending via extra_args
                # overrides any global model from _build_command (last flag wins)
                job_extra_args += ["--model", info.model]

            if info.thinking:
                if backend == "claude":
                    # Claude uses env var for effort level
                    job_env_overrides["CLAUDE_CODE_EFFORT_LEVEL"] = info.thinking
                elif backend == "codex":
                    # Codex uses -c config override
                    job_extra_args += ["-c", f'model_reasoning_effort="{info.thinking}"']
                # gemini: no CLI flag for thinking — skip

            res = await runner.run(
                prompt=clean_prompt,
                mode=RunMode.cron,
                tool_profile_name=info.tool_profile,
                resume_session_id=resume_sid,
                no_session_persistence=no_persist,
                append_system_prompt_file=ctx_info.context_file,
                max_turns=max_turns,
                timeout_seconds=self._resolve_run_timeout(backend),
                cwd_override=cwd_override,
                log_path=run_log_path,
                on_event=_on_job_event,
                on_proc_started=_on_proc_started,
                extra_args=job_extra_args or None,
                env_overrides=job_env_overrides or None,
            )

            await self.db.finish_run(
                run_id=run_id,
                stdout_json=res.stdout_text if res.stdout_text else None,
                exit_code=res.exit_code,
                error=res.error,
                log_file=res.log_file,
            )
            activity_feed.emit(effective_agent or "scheduler", "job", f"Job #{job_id} '{info.name}' completed (exit={res.exit_code})")

            # Persist or clear session
            if using_chat_session and info.target_chat_id is not None:
                # Write the (possibly new) session ID back to the chat row.
                # Never clear the chat session on failure — the user can investigate
                # on Telegram, and the next cron run gets a fresh prompt anyway.
                if res.ok and res.session_id and res.session_id != chat_session_before:
                    await self.db.update_chat_session_id(
                        effective_agent or "", info.target_chat_id, res.session_id,
                    )
                    self._log.info(
                        "use_chat_session job #%d: updated chat session_id=%s",
                        job_id, res.session_id[:12],
                    )
            elif info.sessionful:
                if res.ok and res.session_id:
                    if res.session_id != info.claude_session_id:
                        await self.db.update_job_session_id(job_id, res.session_id)
                        self._log.info(
                            "Sessionful job #%d: stored session_id=%s",
                            job_id, res.session_id[:12],
                        )
                elif not res.ok and info.claude_session_id:
                    # Session may be corrupted; clear so next run starts fresh
                    await self.db.update_job_session_id(job_id, None)
                    self._log.warning(
                        "Sessionful job #%d failed; cleared session for fresh start",
                        job_id,
                    )

            if not res.ok or not res.structured:
                # Mark last_run time but don't disable automatically
                await self.db.update_job_run_times(job_id, last_run_ts=utc_now_iso())
                return

            structured = res.structured

            # Execute actions
            action_summary = await self.actions.execute_actions(
                structured,
                ctx=ActionExecContext(
                    mode=RunMode.cron,
                    actor_chat_id=None,
                    actor_is_admin=False,
                    agent_name=effective_agent,
                    tool_profile=info.tool_profile,
                    backend=backend,
                ),
            )

            if action_summary.scheduler_changed:
                await self.reload_jobs()

            for jid in action_summary.trigger_job_ids:
                if jid != job_id:  # don't self-trigger
                    try:
                        await self.trigger_job(jid)
                    except (RuntimeError, ValueError):
                        pass

            # Post to telegram if configured
            if info.target_chat_id is not None:
                # Send reply and ingest into session handled by TelegramService.
                reply_text = (structured.reply or "").strip() or "(no reply)"
                # Append action notices if any (cron user-facing)
                if action_summary.user_notices:
                    reply_text = reply_text.rstrip() + "\n\n" + "\n".join(action_summary.user_notices)

                # Route to the correct agent's Telegram service
                tg_service = self.telegram_services.get(effective_agent or "")
                if tg_service is None and self.telegram_services:
                    tg_service = next(iter(self.telegram_services.values()))
                if tg_service is not None:
                    await tg_service.send_cron_post(
                        info.target_chat_id,
                        reply_text,
                        job_id=job_id,
                        job_name=info.name,
                        skip_ingest=using_chat_session,
                    )
                else:
                    self._log.warning("No Telegram service available for cron post (job_id=%d)", job_id)

            # Update job run times in DB
            last_run = utc_now_iso()
            next_run = None
            sched_job = self.scheduler.get_job(str(job_id))
            if sched_job and sched_job.next_run_time:
                next_run = sched_job.next_run_time.isoformat()

            await self.db.update_job_run_times(job_id, last_run_ts=last_run, next_run_ts=next_run)

            # If once job: disable after it ran
            if info.schedule_type == JobScheduleType.once.value:
                await self.db.set_job_enabled(job_id, False)
                try:
                    self.scheduler.remove_job(str(job_id))
                except Exception:
                    pass

            # If gapped job: schedule next run after completion + gap
            elif info.schedule_type == JobScheduleType.gapped.value:
                try:
                    tz = _get_tz(info.timezone)
                    obj = json.loads(info.schedule_value)
                    gap = timedelta(**{k: int(v) for k, v in obj.items()})
                    next_run_dt = datetime.now(tz=tz) + gap

                    try:
                        self.scheduler.remove_job(str(job_id))
                    except Exception:
                        pass
                    self.scheduler.add_job(
                        self._run_job,
                        trigger=DateTrigger(run_date=next_run_dt, timezone=tz),
                        args=[job_id],
                        id=str(job_id),
                        name=info.name,
                        replace_existing=True,
                        misfire_grace_time=int(self.cfg.scheduler.misfire_grace_seconds),
                        coalesce=True,
                        max_instances=1,
                    )
                    await self.db.update_job_run_times(
                        job_id, last_run_ts=last_run, next_run_ts=next_run_dt.isoformat(),
                    )
                except Exception:
                    pass

            # Trigger declarative linked jobs (after full completion)
            try:
                linked_ids = await self.db.get_enabled_job_links(job_id)
                for lid in linked_ids:
                    if lid != job_id:
                        try:
                            await self.trigger_job(lid)
                            self._log.info("Linked trigger: job #%d -> job #%d", job_id, lid)
                        except (RuntimeError, ValueError):
                            pass  # already running or not found
            except Exception:
                self._log.warning("Failed to process linked jobs for job #%d", job_id, exc_info=True)
