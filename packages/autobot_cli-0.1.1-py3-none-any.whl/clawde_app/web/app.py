"""FastAPI app factory for the AutoBot web dashboard."""
from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .routers import system, runs, jobs, events, agents, memory, skills, goals, ws


def create_app(
    cfg,
    paths,
    db,
    scheduler,
    telegram_services: dict,
    context_builder,
    actions,
) -> FastAPI:
    app = FastAPI(title="AutoBot Dashboard", version="1.0.0")

    # CORS for Vite dev server
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Store shared references
    app.state.cfg = cfg
    app.state.paths = paths
    app.state.db = db
    app.state.scheduler = scheduler
    app.state.telegram_services = telegram_services
    app.state.context_builder = context_builder
    app.state.actions = actions

    # Mount API routers
    app.include_router(system.router, prefix="/api/system", tags=["system"])
    app.include_router(runs.router, prefix="/api/runs", tags=["runs"])
    app.include_router(jobs.router, prefix="/api/jobs", tags=["jobs"])
    app.include_router(events.router, prefix="/api", tags=["events"])
    app.include_router(agents.router, prefix="/api/agents", tags=["agents"])
    app.include_router(memory.router, prefix="/api/memory", tags=["memory"])
    app.include_router(skills.router, prefix="/api/skills", tags=["skills"])
    app.include_router(goals.router, prefix="/api/goals", tags=["goals"])
    app.include_router(ws.router, prefix="/api/ws", tags=["websocket"])

    # Serve Vue SPA in production (built files)
    # Check bundled assets first (pip install), then data_home/dashboard/dist
    from .._bundled import get_bundled_dashboard_dir
    dashboard_dist = get_bundled_dashboard_dir()
    # Allow user-level override in data_home
    user_dashboard = Path(paths.data_home) / "dashboard" / "dist"
    if user_dashboard.is_dir():
        dashboard_dist = user_dashboard
    if dashboard_dist and dashboard_dist.is_dir():
        from fastapi.staticfiles import StaticFiles

        # Serve index.html for SPA routes
        @app.get("/{full_path:path}", include_in_schema=False)
        async def serve_spa(full_path: str):
            from fastapi.responses import FileResponse

            file_path = dashboard_dist / full_path
            if file_path.is_file():
                return FileResponse(file_path)
            return FileResponse(dashboard_dist / "index.html")

    return app
