"""WebSocket endpoints for real-time log streaming."""
from __future__ import annotations

import asyncio
from pathlib import Path

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from ...activity_feed import activity_feed

router = APIRouter()


@router.websocket("/logs/{run_id}")
async def stream_run_log(websocket: WebSocket, run_id: str):
    """Stream log file lines for a run in real time."""
    await websocket.accept()

    db = websocket.app.state.db

    try:
        run = await db.get_run(run_id)
        if not run:
            await websocket.send_json({"error": "Run not found"})
            await websocket.close()
            return

        log_file = run.get("log_file")
        if not log_file:
            await websocket.send_json({"error": "No log file for this run"})
            await websocket.close()
            return

        log_path = Path(log_file)
        if not log_path.exists():
            await websocket.send_json({"error": "Log file not found"})
            await websocket.close()
            return

        # Send existing lines
        line_offset = 0
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                await websocket.send_json({"type": "line", "data": line.rstrip("\n")})
                line_offset += 1

        # If run is complete, no need to tail
        if run.get("ts_end"):
            await websocket.send_json({"type": "done"})
            await websocket.close()
            return

        # Tail-follow mode: poll for new lines
        while True:
            await asyncio.sleep(0.5)

            # Check if run completed
            run = await db.get_run(run_id)
            run_done = run and run.get("ts_end")

            # Read any new lines
            try:
                with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                    all_lines = f.readlines()
                new_lines = all_lines[line_offset:]
                for line in new_lines:
                    await websocket.send_json({"type": "line", "data": line.rstrip("\n")})
                line_offset += len(new_lines)
            except Exception:
                pass

            if run_done:
                await websocket.send_json({"type": "done"})
                break

    except WebSocketDisconnect:
        pass
    except Exception:
        try:
            await websocket.close()
        except Exception:
            pass


@router.websocket("/activity")
async def stream_activity(websocket: WebSocket):
    """Stream real-time activity feed to connected dashboard clients."""
    await websocket.accept()
    q = activity_feed.subscribe()
    try:
        # Replay recent buffer
        for event in activity_feed.get_buffer():
            await websocket.send_json(event)

        # Stream new events
        while True:
            event = await q.get()
            await websocket.send_json(event)
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        activity_feed.unsubscribe(q)
        try:
            await websocket.close()
        except Exception:
            pass
