"""Chat and event/message endpoints."""
from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from ..dependencies import get_db

router = APIRouter()


@router.get("/chats")
async def list_chats(agent_name: Optional[str] = Query(None), db=Depends(get_db)):
    chats = await db.list_chats(agent_name=agent_name)
    return chats


@router.get("/chats/{agent_name}/{chat_id}")
async def get_chat(agent_name: str, chat_id: int, db=Depends(get_db)):
    chat = await db.get_chat(agent_name, chat_id)
    if not chat:
        raise HTTPException(404, "Chat not found")
    return chat


@router.get("/events/{agent_name}/{chat_id}")
async def get_events(
    agent_name: str,
    chat_id: int,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db=Depends(get_db),
):
    rows, total = await db.get_events_paginated(agent_name, chat_id, limit, offset)
    return {"items": rows, "total": total, "limit": limit, "offset": offset}
