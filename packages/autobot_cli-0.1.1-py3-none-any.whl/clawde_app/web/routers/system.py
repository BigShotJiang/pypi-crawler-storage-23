"""System status and control endpoints."""
from __future__ import annotations

import os
import time

from fastapi import APIRouter, Depends

from ..dependencies import get_cfg, get_paths, get_telegram_services

router = APIRouter()

_start_time = time.time()


@router.get("/status")
async def system_status(
    cfg=Depends(get_cfg),
    paths=Depends(get_paths),
    telegram_services=Depends(get_telegram_services),
):
    pid = os.getpid()
    uptime = time.time() - _start_time

    active_runs = 0
    for ts in telegram_services.values():
        active_runs += len(getattr(ts, "_active_runs", {}))

    return {
        "running": True,
        "pid": pid,
        "uptime_seconds": round(uptime, 1),
        "agents": list(cfg.agents.keys()),
        "active_runs": active_runs,
        "repo_root": str(paths.repo_root),
    }


@router.get("/config")
async def system_config(cfg=Depends(get_cfg)):
    """Return non-sensitive config summary."""
    agents_summary = {}
    for name, agent_cfg in cfg.agents.items():
        agents_summary[name] = {
            "default_backend": agent_cfg.default_backend,
            "respond_in_groups": agent_cfg.respond_in_groups,
            "max_reply_chars": agent_cfg.max_reply_chars,
        }

    return {
        "agents": agents_summary,
        "default_backend": cfg.default_backend,
        "scheduler": {
            "timezone": cfg.scheduler.timezone,
            "max_concurrent_jobs": cfg.scheduler.max_concurrent_jobs,
        },
        "features": {"goals": cfg.features.goals},
        "web": {"port": cfg.web.port, "host": cfg.web.host},
    }
