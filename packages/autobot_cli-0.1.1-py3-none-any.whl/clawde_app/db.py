from __future__ import annotations

import asyncio
import json
import uuid
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, AsyncIterator, Dict, List, Optional, Sequence, Tuple

import aiosqlite  # type: ignore

from .models import (
    ChatStatus,
    EventRole,
    EventSource,
    JobScheduleType,
    RunMode,
)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


SCHEMA_VERSION = 1


@dataclass
class TelegramChatRow:
    agent_name: str
    chat_id: int
    status: str
    pairing_code: Optional[str]
    claude_session_id: Optional[str]
    tool_profile: str
    last_update_id: int
    last_ingested_event_id: int
    created_at: str
    updated_at: str
    project_dir: Optional[str] = None
    backend: Optional[str] = None
    agent_profile: Optional[str] = None
    disabled_skills: Optional[str] = None  # JSON: {"disabled": [...], "enabled": [...]}
    clear_after_event_id: int = 0
    turns_since_flush: int = 0
    text_len_since_flush: int = 0
    model: Optional[str] = None
    thinking: Optional[str] = None


class Database:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self._conn: Optional[aiosqlite.Connection] = None
        self._lock = asyncio.Lock()

    @property
    def conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("Database not connected. Call await db.connect() first.")
        return self._conn

    async def connect(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = await aiosqlite.connect(self.db_path.as_posix())
        self._conn.row_factory = aiosqlite.Row
        # Pragmas for reliability/perf
        await self._conn.execute("PRAGMA journal_mode=WAL;")
        await self._conn.execute("PRAGMA synchronous=NORMAL;")
        await self._conn.execute("PRAGMA foreign_keys=ON;")
        await self._conn.commit()
        await self.init_schema()

    async def close(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None

    async def init_schema(self) -> None:
        async with self._lock:
            await self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS schema_version (
                    version INTEGER NOT NULL
                );
                """
            )
            row = await (await self.conn.execute("SELECT version FROM schema_version LIMIT 1")).fetchone()
            if row is None:
                await self.conn.execute("INSERT INTO schema_version(version) VALUES (?);", (SCHEMA_VERSION,))
                await self.conn.commit()

            # Telegram chats — compound PK (agent_name, chat_id)
            await self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS telegram_chats (
                    agent_name TEXT NOT NULL DEFAULT '',
                    chat_id INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    pairing_code TEXT,
                    claude_session_id TEXT,
                    tool_profile TEXT NOT NULL,
                    last_update_id INTEGER NOT NULL DEFAULT 0,
                    last_ingested_event_id INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    project_dir TEXT,
                    backend TEXT,
                    agent_profile TEXT,
                    PRIMARY KEY (agent_name, chat_id)
                );
                """
            )

            # Migration: old table had chat_id INTEGER PRIMARY KEY (no agent_name).
            # Detect by checking if agent_name column exists on an already-populated table.
            await self._migrate_chats_to_compound_pk()

            # Events ledger
            await self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS events (
                    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_name TEXT NOT NULL DEFAULT '',
                    chat_id INTEGER NOT NULL,
                    ts TEXT NOT NULL,
                    role TEXT NOT NULL,
                    source TEXT NOT NULL,
                    telegram_message_id INTEGER,
                    text TEXT NOT NULL,
                    meta_json TEXT
                );
                """
            )
            await self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_events_agent_chat_event ON events(agent_name, chat_id, event_id);"
            )
            await self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_events_agent_chat_ts ON events(agent_name, chat_id, ts);"
            )

            # Jobs
            await self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS jobs (
                    job_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    enabled INTEGER NOT NULL,
                    schedule_type TEXT NOT NULL,
                    schedule_value TEXT NOT NULL,
                    timezone TEXT NOT NULL,
                    prompt TEXT NOT NULL,
                    target_chat_id INTEGER,
                    tool_profile TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    last_run_ts TEXT,
                    next_run_ts TEXT
                );
                """
            )
            await self.conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_enabled ON jobs(enabled);")
            await self.conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_target_chat ON jobs(target_chat_id);")

            # Job links (post-completion triggers)
            await self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS job_links (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id INTEGER NOT NULL,
                    linked_job_id INTEGER NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL,
                    UNIQUE(job_id, linked_job_id)
                );
                """
            )
            await self.conn.execute("CREATE INDEX IF NOT EXISTS idx_job_links_job ON job_links(job_id);")

            # Migration: add active_start, active_end columns if missing
            for col in ("active_start", "active_end"):
                try:
                    await self.conn.execute(f"ALTER TABLE jobs ADD COLUMN {col} TEXT;")
                    await self.conn.commit()
                except Exception:
                    pass

            # Migration: add backend column to jobs
            try:
                await self.conn.execute("ALTER TABLE jobs ADD COLUMN backend TEXT;")
                await self.conn.commit()
            except Exception:
                pass

            # Migration: add agent_profile column to jobs
            try:
                await self.conn.execute("ALTER TABLE jobs ADD COLUMN agent_profile TEXT;")
                await self.conn.commit()
            except Exception:
                pass

            # Migration: add disabled_skills column to telegram_chats
            try:
                await self.conn.execute("ALTER TABLE telegram_chats ADD COLUMN disabled_skills TEXT;")
                await self.conn.commit()
            except Exception:
                pass

            # Migration: add clear_after_event_id column to telegram_chats
            try:
                await self.conn.execute(
                    "ALTER TABLE telegram_chats ADD COLUMN clear_after_event_id INTEGER NOT NULL DEFAULT 0;"
                )
                await self.conn.commit()
            except Exception:
                pass

            # Migration: add sessionful flag and session_id to jobs
            for col, col_def in [
                ("sessionful", "INTEGER NOT NULL DEFAULT 0"),
                ("claude_session_id", "TEXT"),
            ]:
                try:
                    await self.conn.execute(f"ALTER TABLE jobs ADD COLUMN {col} {col_def};")
                    await self.conn.commit()
                except Exception:
                    pass

            # Migration: add project_dir to jobs
            try:
                await self.conn.execute("ALTER TABLE jobs ADD COLUMN project_dir TEXT;")
                await self.conn.commit()
            except Exception:
                pass

            # Migration: add autodev_config and custom_instructions to jobs
            for col in ["autodev_config TEXT", "custom_instructions TEXT"]:
                try:
                    await self.conn.execute(f"ALTER TABLE jobs ADD COLUMN {col};")
                    await self.conn.commit()
                except Exception:
                    pass

            # Migration: add use_chat_session flag to jobs
            try:
                await self.conn.execute("ALTER TABLE jobs ADD COLUMN use_chat_session INTEGER NOT NULL DEFAULT 0;")
                await self.conn.commit()
            except Exception:
                pass

            # Migration: add model and thinking columns to jobs
            for col in ["model TEXT", "thinking TEXT"]:
                try:
                    await self.conn.execute(f"ALTER TABLE jobs ADD COLUMN {col};")
                    await self.conn.commit()
                except Exception:
                    pass

            # Runs
            await self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS runs (
                    run_id TEXT PRIMARY KEY,
                    ts_start TEXT NOT NULL,
                    ts_end TEXT,
                    mode TEXT NOT NULL,
                    chat_id INTEGER,
                    job_id INTEGER,
                    claude_session_id TEXT,
                    prompt_preview TEXT,
                    stdout_json TEXT,
                    exit_code INTEGER,
                    error TEXT
                );
                """
            )
            await self.conn.execute("CREATE INDEX IF NOT EXISTS idx_runs_ts_start ON runs(ts_start);")

            # Migration: add agent_name to runs
            try:
                await self.conn.execute("ALTER TABLE runs ADD COLUMN agent_name TEXT NOT NULL DEFAULT '';")
                await self.conn.commit()
            except Exception:
                pass

            # Migration: add log_file to runs
            try:
                await self.conn.execute("ALTER TABLE runs ADD COLUMN log_file TEXT;")
                await self.conn.commit()
            except Exception:
                pass

            # Migration: add prompt_full to runs
            try:
                await self.conn.execute("ALTER TABLE runs ADD COLUMN prompt_full TEXT;")
                await self.conn.commit()
            except Exception:
                pass

            # Memory chunks for hybrid search (FTS5 + Qdrant vectors)
            await self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS memory_chunks (
                    chunk_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_name TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    file_mtime REAL NOT NULL,
                    chunk_index INTEGER NOT NULL,
                    heading TEXT,
                    content TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(agent_name, file_path, chunk_index)
                );
                """
            )

            # Migration: drop embedding BLOB column (vectors now stored in Qdrant)
            try:
                await self.conn.execute("ALTER TABLE memory_chunks DROP COLUMN embedding;")
                await self.conn.commit()
            except Exception:
                pass  # Column doesn't exist (new DB) or SQLite < 3.35
            await self.conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_chunks_agent_file ON memory_chunks(agent_name, file_path);"
            )

            # FTS5 virtual table for BM25 search over chunks
            try:
                await self.conn.execute(
                    """
                    CREATE VIRTUAL TABLE IF NOT EXISTS memory_chunks_fts USING fts5(
                        content, heading,
                        content='memory_chunks', content_rowid='chunk_id'
                    );
                    """
                )
            except Exception:
                pass

            # Embedding cache: avoids re-embedding unchanged chunks
            await self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS memory_embedding_cache (
                    content_hash TEXT NOT NULL,
                    model TEXT NOT NULL,
                    embedding BLOB NOT NULL,
                    created_at TEXT NOT NULL,
                    PRIMARY KEY (content_hash, model)
                );
                """
            )

            # Migration: add content_hash column to memory_chunks
            try:
                await self.conn.execute(
                    "ALTER TABLE memory_chunks ADD COLUMN content_hash TEXT NOT NULL DEFAULT '';"
                )
                await self.conn.commit()
            except Exception:
                pass

            # Migration: add flush tracking columns to telegram_chats
            for col, col_def in [
                ("turns_since_flush", "INTEGER NOT NULL DEFAULT 0"),
                ("text_len_since_flush", "INTEGER NOT NULL DEFAULT 0"),
            ]:
                try:
                    await self.conn.execute(f"ALTER TABLE telegram_chats ADD COLUMN {col} {col_def};")
                    await self.conn.commit()
                except Exception:
                    pass

            await self.conn.commit()

            # Migration: add model and thinking columns to telegram_chats
            for col in ["model TEXT", "thinking TEXT"]:
                try:
                    await self.conn.execute(f"ALTER TABLE telegram_chats ADD COLUMN {col};")
                    await self.conn.commit()
                except Exception:
                    pass

    async def _migrate_chats_to_compound_pk(self) -> None:
        """Migrate old telegram_chats (chat_id PK) to compound PK (agent_name, chat_id).

        Also migrates events table: adds agent_name column and removes the old
        FOREIGN KEY(chat_id) that becomes invalid after the PK change.
        """
        # Check if old-format table exists (chat_id as sole INTEGER PRIMARY KEY)
        cur = await self.conn.execute("PRAGMA table_info(telegram_chats)")
        cols = {row[1]: row for row in await cur.fetchall()}

        if "agent_name" in cols:
            return  # Already migrated

        import logging
        log = logging.getLogger("clawde.db")
        log.info("Migrating telegram_chats to compound PK (agent_name, chat_id)...")

        # Disable FK checks during migration (renaming tables confuses FK references)
        await self.conn.execute("PRAGMA foreign_keys=OFF")

        # Step 1: Rename old chats table
        await self.conn.execute("ALTER TABLE telegram_chats RENAME TO _tc_old")

        # Step 2: Create new chats table with compound PK
        await self.conn.execute(
            """
            CREATE TABLE telegram_chats (
                agent_name TEXT NOT NULL DEFAULT '',
                chat_id INTEGER NOT NULL,
                status TEXT NOT NULL,
                pairing_code TEXT,
                claude_session_id TEXT,
                tool_profile TEXT NOT NULL,
                last_update_id INTEGER NOT NULL DEFAULT 0,
                last_ingested_event_id INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                project_dir TEXT,
                backend TEXT,
                agent_profile TEXT,
                PRIMARY KEY (agent_name, chat_id)
            );
            """
        )

        # Step 3: Copy chat data (old rows get agent_name='')
        new_cols_from_old = []
        for c in ("chat_id", "status", "pairing_code", "claude_session_id", "tool_profile",
                   "last_update_id", "last_ingested_event_id", "created_at", "updated_at",
                   "project_dir", "backend", "agent_profile"):
            if c in cols:
                new_cols_from_old.append(c)

        col_list = ", ".join(new_cols_from_old)
        await self.conn.execute(
            f"INSERT INTO telegram_chats (agent_name, {col_list}) SELECT '', {col_list} FROM _tc_old"
        )
        await self.conn.execute("DROP TABLE _tc_old")

        # Step 4: Rebuild events table — add agent_name, remove old FK to telegram_chats
        # (SQLite rewrites FK targets when we rename tables, leaving a dangling reference)
        await self.conn.execute("ALTER TABLE events RENAME TO _events_old")
        await self.conn.execute(
            """
            CREATE TABLE events (
                event_id INTEGER PRIMARY KEY AUTOINCREMENT,
                agent_name TEXT NOT NULL DEFAULT '',
                chat_id INTEGER NOT NULL,
                ts TEXT NOT NULL,
                role TEXT NOT NULL,
                source TEXT NOT NULL,
                telegram_message_id INTEGER,
                text TEXT NOT NULL,
                meta_json TEXT
            );
            """
        )
        # Check which columns exist in old events table
        ev_cur = await self.conn.execute("PRAGMA table_info(_events_old)")
        ev_cols = {row[1] for row in await ev_cur.fetchall()}
        has_agent = "agent_name" in ev_cols
        if has_agent:
            await self.conn.execute(
                """INSERT INTO events (event_id, agent_name, chat_id, ts, role, source,
                   telegram_message_id, text, meta_json)
                   SELECT event_id, agent_name, chat_id, ts, role, source,
                   telegram_message_id, text, meta_json FROM _events_old"""
            )
        else:
            await self.conn.execute(
                """INSERT INTO events (event_id, agent_name, chat_id, ts, role, source,
                   telegram_message_id, text, meta_json)
                   SELECT event_id, '', chat_id, ts, role, source,
                   telegram_message_id, text, meta_json FROM _events_old"""
            )
        await self.conn.execute("DROP TABLE _events_old")

        # Recreate indexes
        await self.conn.execute("DROP INDEX IF EXISTS idx_events_chat_event")
        await self.conn.execute("DROP INDEX IF EXISTS idx_events_chat_ts")
        await self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_events_agent_chat_event ON events(agent_name, chat_id, event_id)"
        )
        await self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_events_agent_chat_ts ON events(agent_name, chat_id, ts)"
        )

        # Re-enable FK checks
        await self.conn.execute("PRAGMA foreign_keys=ON")
        await self.conn.commit()
        log.info("Migration complete: telegram_chats now uses (agent_name, chat_id) PK")

    # ----------------------------
    # Chat helpers
    # ----------------------------
    async def get_chat(self, agent_name: str, chat_id: int) -> Optional[TelegramChatRow]:
        cur = await self.conn.execute(
            "SELECT * FROM telegram_chats WHERE agent_name = ? AND chat_id = ?;",
            (agent_name, chat_id),
        )
        row = await cur.fetchone()
        if row is None:
            return None
        return TelegramChatRow(**dict(row))

    async def create_chat(
        self,
        agent_name: str,
        chat_id: int,
        status: ChatStatus = ChatStatus.unpaired,
        pairing_code: Optional[str] = None,
        tool_profile: str = "safe_chat",
    ) -> None:
        now = utc_now_iso()
        await self.conn.execute(
            """
            INSERT OR IGNORE INTO telegram_chats(
                agent_name,chat_id,status,pairing_code,claude_session_id,tool_profile,
                last_update_id,last_ingested_event_id,created_at,updated_at
            ) VALUES (?,?,?,?,?,?,0,0,?,?);
            """,
            (agent_name, chat_id, status.value, pairing_code, None, tool_profile, now, now),
        )
        await self.conn.commit()

    async def update_chat_status(self, agent_name: str, chat_id: int, status: ChatStatus, pairing_code: Optional[str] = None) -> None:
        now = utc_now_iso()
        await self.conn.execute(
            """
            UPDATE telegram_chats
            SET status = ?, pairing_code = ?, updated_at = ?
            WHERE agent_name = ? AND chat_id = ?;
            """,
            (status.value, pairing_code, now, agent_name, chat_id),
        )
        await self.conn.commit()

    async def update_chat_session_id(self, agent_name: str, chat_id: int, session_id: Optional[str]) -> None:
        now = utc_now_iso()
        await self.conn.execute(
            """
            UPDATE telegram_chats
            SET claude_session_id = ?, updated_at = ?
            WHERE agent_name = ? AND chat_id = ?;
            """,
            (session_id, now, agent_name, chat_id),
        )
        await self.conn.commit()

    async def clear_chat_session(self, agent_name: str, chat_id: int) -> None:
        """Clear session and set clear point to hide prior chat history from context."""
        now = utc_now_iso()
        cur = await self.conn.execute(
            "SELECT MAX(event_id) FROM events WHERE agent_name = ? AND chat_id = ?;",
            (agent_name, chat_id),
        )
        row = await cur.fetchone()
        max_eid = row[0] if row and row[0] else 0
        await self.conn.execute(
            """
            UPDATE telegram_chats
            SET claude_session_id = NULL, last_ingested_event_id = 0,
                clear_after_event_id = ?, updated_at = ?
            WHERE agent_name = ? AND chat_id = ?;
            """,
            (max_eid, now, agent_name, chat_id),
        )
        await self.conn.commit()

    async def update_chat_backend(self, agent_name: str, chat_id: int, backend: str) -> None:
        """Switch backend and clear session (sessions aren't cross-compatible)."""
        now = utc_now_iso()
        await self.conn.execute(
            """
            UPDATE telegram_chats
            SET backend = ?, claude_session_id = NULL, updated_at = ?
            WHERE agent_name = ? AND chat_id = ?;
            """,
            (backend, now, agent_name, chat_id),
        )
        await self.conn.commit()

    async def update_chat_model(self, agent_name: str, chat_id: int, model: Optional[str]) -> None:
        """Set per-chat model override (None to clear back to default)."""
        now = utc_now_iso()
        await self.conn.execute(
            "UPDATE telegram_chats SET model = ?, updated_at = ? WHERE agent_name = ? AND chat_id = ?;",
            (model, now, agent_name, chat_id),
        )
        await self.conn.commit()

    async def update_chat_thinking(self, agent_name: str, chat_id: int, thinking: Optional[str]) -> None:
        """Set per-chat reasoning effort override (None to clear back to default)."""
        now = utc_now_iso()
        await self.conn.execute(
            "UPDATE telegram_chats SET thinking = ?, updated_at = ? WHERE agent_name = ? AND chat_id = ?;",
            (thinking, now, agent_name, chat_id),
        )
        await self.conn.commit()

    async def update_chat_tool_profile(self, agent_name: str, chat_id: int, tool_profile: str) -> None:
        now = utc_now_iso()
        await self.conn.execute(
            """
            UPDATE telegram_chats
            SET tool_profile = ?, updated_at = ?
            WHERE agent_name = ? AND chat_id = ?;
            """,
            (tool_profile, now, agent_name, chat_id),
        )
        await self.conn.commit()

    async def update_chat_project_dir(self, agent_name: str, chat_id: int, project_dir: Optional[str]) -> None:
        now = utc_now_iso()
        await self.conn.execute(
            """
            UPDATE telegram_chats
            SET project_dir = ?, claude_session_id = NULL, updated_at = ?
            WHERE agent_name = ? AND chat_id = ?;
            """,
            (project_dir, now, agent_name, chat_id),
        )
        await self.conn.commit()

    async def update_chat_agent_profile(self, agent_name: str, chat_id: int, agent_profile: str) -> None:
        now = utc_now_iso()
        await self.conn.execute(
            """
            UPDATE telegram_chats
            SET agent_profile = ?, updated_at = ?
            WHERE agent_name = ? AND chat_id = ?;
            """,
            (agent_profile, now, agent_name, chat_id),
        )
        await self.conn.commit()

    async def update_chat_skill_overrides(self, agent_name: str, chat_id: int, overrides_json: str) -> None:
        now = utc_now_iso()
        await self.conn.execute(
            """
            UPDATE telegram_chats
            SET disabled_skills = ?, updated_at = ?
            WHERE agent_name = ? AND chat_id = ?;
            """,
            (overrides_json, now, agent_name, chat_id),
        )
        await self.conn.commit()

    async def update_chat_last_update_id(self, agent_name: str, chat_id: int, update_id: int) -> None:
        now = utc_now_iso()
        await self.conn.execute(
            """
            UPDATE telegram_chats
            SET last_update_id = ?, updated_at = ?
            WHERE agent_name = ? AND chat_id = ?;
            """,
            (update_id, now, agent_name, chat_id),
        )
        await self.conn.commit()

    async def update_flush_tracking(
        self, agent_name: str, chat_id: int, turns_since_flush: int, text_len_since_flush: int
    ) -> None:
        now = utc_now_iso()
        await self.conn.execute(
            """
            UPDATE telegram_chats
            SET turns_since_flush = ?, text_len_since_flush = ?, updated_at = ?
            WHERE agent_name = ? AND chat_id = ?;
            """,
            (turns_since_flush, text_len_since_flush, now, agent_name, chat_id),
        )
        await self.conn.commit()

    async def get_flush_tracking(self, agent_name: str, chat_id: int) -> tuple[int, int]:
        """Return (turns_since_flush, text_len_since_flush)."""
        row = await (await self.conn.execute(
            "SELECT turns_since_flush, text_len_since_flush FROM telegram_chats WHERE agent_name = ? AND chat_id = ?;",
            (agent_name, chat_id),
        )).fetchone()
        if row:
            return int(row[0] or 0), int(row[1] or 0)
        return 0, 0

    async def update_last_ingested_event_id(self, agent_name: str, chat_id: int, event_id: int) -> None:
        now = utc_now_iso()
        await self.conn.execute(
            """
            UPDATE telegram_chats
            SET last_ingested_event_id = ?, updated_at = ?
            WHERE agent_name = ? AND chat_id = ?;
            """,
            (event_id, now, agent_name, chat_id),
        )
        await self.conn.commit()

    # ----------------------------
    # Event ledger
    # ----------------------------
    async def insert_event(
        self,
        agent_name: str,
        chat_id: int,
        role: EventRole,
        source: EventSource,
        text: str,
        telegram_message_id: Optional[int] = None,
        meta: Optional[Dict[str, Any]] = None,
        ts: Optional[str] = None,
    ) -> int:
        if ts is None:
            ts = utc_now_iso()
        meta_json = None if meta is None else json.dumps(meta, ensure_ascii=False)
        cur = await self.conn.execute(
            """
            INSERT INTO events(agent_name,chat_id,ts,role,source,telegram_message_id,text,meta_json)
            VALUES (?,?,?,?,?,?,?,?);
            """,
            (agent_name, chat_id, ts, role.value, source.value, telegram_message_id, text, meta_json),
        )
        await self.conn.commit()
        return int(cur.lastrowid)

    async def get_events_since(
        self,
        agent_name: str,
        chat_id: int,
        after_event_id: int,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        cur = await self.conn.execute(
            """
            SELECT * FROM events
            WHERE agent_name = ? AND chat_id = ? AND event_id > ?
            ORDER BY event_id ASC
            LIMIT ?;
            """,
            (agent_name, chat_id, after_event_id, limit),
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def get_recent_events(
        self,
        agent_name: str,
        chat_id: int,
        limit: int = 30,
        after_event_id: int = 0,
    ) -> List[Dict[str, Any]]:
        """Return the last N events for a chat, in chronological order.

        If *after_event_id* > 0, only events with ``event_id > after_event_id``
        are considered (used by /clear to hide prior history).
        """
        cur = await self.conn.execute(
            """
            SELECT * FROM (
                SELECT * FROM events
                WHERE agent_name = ? AND chat_id = ? AND event_id > ?
                ORDER BY event_id DESC
                LIMIT ?
            ) sub ORDER BY event_id ASC;
            """,
            (agent_name, chat_id, after_event_id, limit),
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def get_last_event_id(self, agent_name: str, chat_id: int) -> int:
        cur = await self.conn.execute(
            "SELECT event_id FROM events WHERE agent_name = ? AND chat_id = ? ORDER BY event_id DESC LIMIT 1;",
            (agent_name, chat_id),
        )
        row = await cur.fetchone()
        return int(row["event_id"]) if row else 0

    # ----------------------------
    # Jobs
    # ----------------------------
    async def create_job(
        self,
        name: str,
        enabled: bool,
        schedule_type: JobScheduleType,
        schedule_value: str,
        timezone_str: str,
        prompt: str,
        target_chat_id: Optional[int],
        tool_profile: str,
        active_start: Optional[str] = None,
        active_end: Optional[str] = None,
        backend: Optional[str] = None,
        agent_profile: Optional[str] = None,
        sessionful: bool = False,
        project_dir: Optional[str] = None,
        autodev_config: Optional[str] = None,
        custom_instructions: Optional[str] = None,
        use_chat_session: bool = False,
        model: Optional[str] = None,
        thinking: Optional[str] = None,
    ) -> int:
        now = utc_now_iso()
        cur = await self.conn.execute(
            """
            INSERT INTO jobs(
                name, enabled, schedule_type, schedule_value, timezone,
                prompt, target_chat_id, tool_profile,
                active_start, active_end, backend, agent_profile,
                sessionful, project_dir, autodev_config, custom_instructions,
                use_chat_session, model, thinking,
                created_at, updated_at
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);
            """,
            (
                name,
                1 if enabled else 0,
                schedule_type.value,
                schedule_value,
                timezone_str,
                prompt,
                target_chat_id,
                tool_profile,
                active_start,
                active_end,
                backend,
                agent_profile,
                1 if sessionful else 0,
                project_dir,
                autodev_config,
                custom_instructions,
                1 if use_chat_session else 0,
                model,
                thinking,
                now,
                now,
            ),
        )
        await self.conn.commit()
        return int(cur.lastrowid)

    async def update_job_session_id(self, job_id: int, session_id: Optional[str]) -> None:
        """Store or clear the CLI session ID for a sessionful cron job."""
        now = utc_now_iso()
        await self.conn.execute(
            "UPDATE jobs SET claude_session_id = ?, updated_at = ? WHERE job_id = ?;",
            (session_id, now, job_id),
        )
        await self.conn.commit()

    async def list_jobs(self, enabled_only: bool = False) -> List[Dict[str, Any]]:
        if enabled_only:
            cur = await self.conn.execute("SELECT * FROM jobs WHERE enabled = 1 ORDER BY job_id ASC;")
        else:
            cur = await self.conn.execute("SELECT * FROM jobs ORDER BY job_id ASC;")
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def get_job(self, job_id: int) -> Optional[Dict[str, Any]]:
        cur = await self.conn.execute("SELECT * FROM jobs WHERE job_id = ?;", (job_id,))
        row = await cur.fetchone()
        return dict(row) if row else None

    async def set_job_enabled(self, job_id: int, enabled: bool) -> None:
        now = utc_now_iso()
        await self.conn.execute(
            "UPDATE jobs SET enabled = ?, updated_at = ? WHERE job_id = ?;",
            (1 if enabled else 0, now, job_id),
        )
        await self.conn.commit()

    async def delete_job(self, job_id: int) -> None:
        await self.conn.execute(
            "DELETE FROM job_links WHERE job_id = ? OR linked_job_id = ?;", (job_id, job_id),
        )
        await self.conn.execute("DELETE FROM jobs WHERE job_id = ?;", (job_id,))
        await self.conn.commit()

    async def update_job_run_times(
        self,
        job_id: int,
        last_run_ts: Optional[str] = None,
        next_run_ts: Optional[str] = None,
    ) -> None:
        now = utc_now_iso()
        await self.conn.execute(
            """
            UPDATE jobs
            SET last_run_ts = COALESCE(?, last_run_ts),
                next_run_ts = COALESCE(?, next_run_ts),
                updated_at = ?
            WHERE job_id = ?;
            """,
            (last_run_ts, next_run_ts, now, job_id),
        )
        await self.conn.commit()

    async def update_job_fields(self, job_id: int, **kwargs: Any) -> bool:
        """Update arbitrary job fields. Only non-None kwargs are applied.

        Allowed fields: tool_profile, backend, prompt, enabled, schedule_value, sessionful, project_dir.
        Returns True if a row was updated.
        """
        _ALLOWED = {
            "name", "tool_profile", "backend", "prompt", "enabled",
            "schedule_type", "schedule_value", "timezone", "sessionful",
            "project_dir", "agent_profile", "target_chat_id",
            "active_start", "active_end",
            "autodev_config", "custom_instructions",
            "use_chat_session",
            "model", "thinking",
        }
        # Fields that can be explicitly set to NULL (to clear back to default)
        _NULLABLE = {"model", "thinking"}
        updates = {
            k: v for k, v in kwargs.items()
            if k in _ALLOWED and (v is not None or k in _NULLABLE)
        }
        if not updates:
            return False
        # Convert bools to int for SQLite
        if "enabled" in updates:
            updates["enabled"] = int(updates["enabled"])
        if "sessionful" in updates:
            updates["sessionful"] = int(updates["sessionful"])
        if "use_chat_session" in updates:
            updates["use_chat_session"] = int(updates["use_chat_session"])
        set_parts = [f"{k} = ?" for k in updates]
        set_parts.append("updated_at = ?")
        vals = list(updates.values()) + [utc_now_iso(), job_id]
        sql = f"UPDATE jobs SET {', '.join(set_parts)} WHERE job_id = ?;"
        cur = await self.conn.execute(sql, vals)
        await self.conn.commit()
        return cur.rowcount > 0

    # ----------------------------
    # Job links (post-completion triggers)
    # ----------------------------
    async def create_job_link(self, job_id: int, linked_job_id: int, enabled: bool = True) -> int:
        now = utc_now_iso()
        cur = await self.conn.execute(
            "INSERT INTO job_links(job_id, linked_job_id, enabled, created_at) VALUES (?, ?, ?, ?);",
            (job_id, linked_job_id, 1 if enabled else 0, now),
        )
        await self.conn.commit()
        return int(cur.lastrowid)

    async def list_job_links(self, job_id: int) -> List[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT * FROM job_links WHERE job_id = ? ORDER BY id ASC;", (job_id,),
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def get_enabled_job_links(self, job_id: int) -> List[int]:
        cur = await self.conn.execute(
            "SELECT linked_job_id FROM job_links WHERE job_id = ? AND enabled = 1;", (job_id,),
        )
        rows = await cur.fetchall()
        return [int(r["linked_job_id"]) for r in rows]

    async def update_job_link_enabled(self, link_id: int, enabled: bool) -> bool:
        cur = await self.conn.execute(
            "UPDATE job_links SET enabled = ? WHERE id = ?;", (1 if enabled else 0, link_id),
        )
        await self.conn.commit()
        return cur.rowcount > 0

    async def delete_job_link(self, link_id: int) -> None:
        await self.conn.execute("DELETE FROM job_links WHERE id = ?;", (link_id,))
        await self.conn.commit()

    # ----------------------------
    # Run logging
    # ----------------------------
    async def start_run(
        self,
        mode: RunMode,
        chat_id: Optional[int] = None,
        job_id: Optional[int] = None,
        claude_session_id: Optional[str] = None,
        prompt_preview: Optional[str] = None,
        agent_name: str = "",
        log_file: Optional[str] = None,
        prompt_full: Optional[str] = None,
    ) -> str:
        run_id = str(uuid.uuid4())
        ts_start = utc_now_iso()
        await self.conn.execute(
            """
            INSERT INTO runs(run_id, ts_start, mode, chat_id, job_id, claude_session_id, prompt_preview, agent_name, log_file, prompt_full)
            VALUES (?,?,?,?,?,?,?,?,?,?);
            """,
            (run_id, ts_start, mode.value, chat_id, job_id, claude_session_id, prompt_preview, agent_name, log_file, prompt_full),
        )
        await self.conn.commit()
        return run_id

    async def finish_run(
        self,
        run_id: str,
        stdout_json: Optional[str],
        exit_code: Optional[int],
        error: Optional[str],
        log_file: Optional[str] = None,
    ) -> None:
        ts_end = utc_now_iso()
        await self.conn.execute(
            """
            UPDATE runs
            SET ts_end = ?, stdout_json = ?, exit_code = ?, error = ?, log_file = ?
            WHERE run_id = ?;
            """,
            (ts_end, stdout_json, exit_code, error, log_file, run_id),
        )
        await self.conn.commit()

    async def get_recent_runs(self, limit: int = 20) -> List[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT * FROM runs ORDER BY ts_start DESC LIMIT ?;",
            (limit,),
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def get_run(self, run_id: str) -> Optional[Dict[str, Any]]:
        cur = await self.conn.execute("SELECT * FROM runs WHERE run_id = ?;", (run_id,))
        row = await cur.fetchone()
        return dict(row) if row else None

    async def get_runs_filtered(
        self,
        agent_name: Optional[str] = None,
        mode: Optional[str] = None,
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
        chat_id: Optional[int] = None,
        job_id: Optional[int] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[List[Dict[str, Any]], int]:
        """Filtered + paginated runs query. Returns (rows, total_count)."""
        wheres: List[str] = []
        params: List[Any] = []
        if agent_name:
            wheres.append("agent_name = ?")
            params.append(agent_name)
        if mode:
            wheres.append("mode = ?")
            params.append(mode)
        if date_from:
            wheres.append("ts_start >= ?")
            params.append(date_from)
        if date_to:
            wheres.append("ts_start <= ?")
            params.append(date_to)
        if chat_id is not None:
            wheres.append("chat_id = ?")
            params.append(chat_id)
        if job_id is not None:
            wheres.append("job_id = ?")
            params.append(job_id)
        where_clause = (" WHERE " + " AND ".join(wheres)) if wheres else ""
        # Count
        count_cur = await self.conn.execute(
            f"SELECT COUNT(*) FROM runs{where_clause};", params
        )
        total = (await count_cur.fetchone())[0]
        # Rows
        cur = await self.conn.execute(
            f"SELECT * FROM runs{where_clause} ORDER BY ts_start DESC LIMIT ? OFFSET ?;",
            params + [limit, offset],
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows], total

    async def get_runs_for_job(self, job_id: int, limit: int = 20) -> List[Dict[str, Any]]:
        cur = await self.conn.execute(
            "SELECT * FROM runs WHERE job_id = ? ORDER BY ts_start DESC LIMIT ?;",
            (job_id, limit),
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def list_chats(self, agent_name: Optional[str] = None) -> List[Dict[str, Any]]:
        if agent_name:
            cur = await self.conn.execute(
                "SELECT * FROM telegram_chats WHERE agent_name = ? ORDER BY updated_at DESC;",
                (agent_name,),
            )
        else:
            cur = await self.conn.execute("SELECT * FROM telegram_chats ORDER BY updated_at DESC;")
        rows = await cur.fetchall()
        return [dict(r) for r in rows]

    async def get_events_paginated(
        self,
        agent_name: str,
        chat_id: int,
        limit: int = 50,
        offset: int = 0,
    ) -> tuple[List[Dict[str, Any]], int]:
        count_cur = await self.conn.execute(
            "SELECT COUNT(*) FROM events WHERE agent_name = ? AND chat_id = ?;",
            (agent_name, chat_id),
        )
        total = (await count_cur.fetchone())[0]
        cur = await self.conn.execute(
            "SELECT * FROM events WHERE agent_name = ? AND chat_id = ? ORDER BY event_id DESC LIMIT ? OFFSET ?;",
            (agent_name, chat_id, limit, offset),
        )
        rows = await cur.fetchall()
        return [dict(r) for r in rows], total
