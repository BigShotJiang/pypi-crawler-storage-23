#!/usr/bin/env python3
"""
Send email via Gmail SMTP.

Usage:
    python <SKILL_DIR>/send_email.py --to recipient@example.com --subject "Subject" --body "Body text"
    python <SKILL_DIR>/send_email.py --to recipient@example.com --subject "Subject" --body-file /path/to/body.txt
    python <SKILL_DIR>/send_email.py --to recipient@example.com --subject "Subject" --body "Body" --html "<h1>HTML body</h1>"

Config is read from email_config.json in the same directory as this script.
"""

import argparse
import json
import smtplib
import sys
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

CONFIG_PATH = Path(__file__).parent / "email_config.json"


def load_config():
    if not CONFIG_PATH.exists():
        print(f"ERROR: Config file not found: {CONFIG_PATH}", file=sys.stderr)
        sys.exit(1)
    with open(CONFIG_PATH) as f:
        return json.load(f)


def send_email(to: str, subject: str, body: str, html: str = None):
    config = load_config()
    sender = config["gmail_address"]
    app_password = config["app_password"]

    msg = MIMEMultipart("alternative")
    msg["From"] = sender
    msg["To"] = to
    msg["Subject"] = subject

    msg.attach(MIMEText(body, "plain"))
    if html:
        msg.attach(MIMEText(html, "html"))

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        server.login(sender, app_password)
        server.sendmail(sender, to, msg.as_string())

    print(f"Email sent to {to}: {subject}")


def main():
    parser = argparse.ArgumentParser(description="Send email via Gmail SMTP")
    parser.add_argument("--to", required=True, help="Recipient email address")
    parser.add_argument("--subject", required=True, help="Email subject")
    parser.add_argument("--body", help="Plain text body")
    parser.add_argument("--body-file", help="Read body from file")
    parser.add_argument("--html", help="HTML body (optional)")
    args = parser.parse_args()

    if args.body_file:
        body = Path(args.body_file).read_text()
    elif args.body:
        body = args.body
    else:
        print("ERROR: Provide --body or --body-file", file=sys.stderr)
        sys.exit(1)

    send_email(args.to, args.subject, body, args.html)


if __name__ == "__main__":
    main()
