#!/usr/bin/env python3
"""
Read emails via Gmail IMAP.

Usage:
    python <SKILL_DIR>/read_email.py inbox                  # List latest 10 emails from inbox
    python <SKILL_DIR>/read_email.py inbox --count 20       # List latest 20 emails
    python <SKILL_DIR>/read_email.py read <uid>             # Read a specific email by UID
    python <SKILL_DIR>/read_email.py search "from:someone@example.com"  # Search emails
    python <SKILL_DIR>/read_email.py search "subject:invoice"
    python <SKILL_DIR>/read_email.py search "keyword"       # Full-text search
    python <SKILL_DIR>/read_email.py folders                # List available folders/labels

Config is read from email_config.json in the same directory as this script.
"""

import argparse
import email
import email.header
import imaplib
import json
import sys
from email.utils import parsedate_to_datetime
from pathlib import Path

CONFIG_PATH = Path(__file__).parent / "email_config.json"


def load_config():
    if not CONFIG_PATH.exists():
        print(f"ERROR: Config file not found: {CONFIG_PATH}", file=sys.stderr)
        sys.exit(1)
    with open(CONFIG_PATH) as f:
        return json.load(f)


def connect():
    config = load_config()
    mail = imaplib.IMAP4_SSL("imap.gmail.com", 993)
    mail.login(config["gmail_address"], config["app_password"])
    return mail


def decode_header_value(value):
    if value is None:
        return ""
    decoded_parts = email.header.decode_header(value)
    result = []
    for part, charset in decoded_parts:
        if isinstance(part, bytes):
            result.append(part.decode(charset or "utf-8", errors="replace"))
        else:
            result.append(part)
    return "".join(result)


def get_body(msg):
    """Extract plain text body from email message."""
    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            if content_type == "text/plain":
                payload = part.get_payload(decode=True)
                charset = part.get_content_charset() or "utf-8"
                return payload.decode(charset, errors="replace")
        # Fallback to HTML if no plain text
        for part in msg.walk():
            content_type = part.get_content_type()
            if content_type == "text/html":
                payload = part.get_payload(decode=True)
                charset = part.get_content_charset() or "utf-8"
                return f"[HTML content]\n{payload.decode(charset, errors='replace')}"
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            charset = msg.get_content_charset() or "utf-8"
            return payload.decode(charset, errors="replace")
    return "(no body)"


def list_folders(mail):
    status, folders = mail.list()
    if status != "OK":
        print("ERROR: Could not list folders", file=sys.stderr)
        return
    for f in folders:
        print(f.decode())


def list_inbox(mail, folder="INBOX", count=10):
    mail.select(folder, readonly=True)
    status, messages = mail.search(None, "ALL")
    if status != "OK":
        print("ERROR: Could not search mailbox", file=sys.stderr)
        return

    msg_ids = messages[0].split()
    if not msg_ids:
        print("(no emails)")
        return

    # Get latest N
    latest = msg_ids[-count:]
    latest.reverse()

    for mid in latest:
        status, data = mail.fetch(mid, "(UID BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
        if status != "OK":
            continue
        uid = None
        # Extract UID from fetch response
        resp_line = data[0][0].decode() if isinstance(data[0][0], bytes) else str(data[0][0])
        if b"UID" in data[0][0] if isinstance(data[0][0], bytes) else "UID" in resp_line:
            import re
            uid_match = re.search(r"UID (\d+)", resp_line)
            if uid_match:
                uid = uid_match.group(1)

        header_data = data[0][1]
        msg = email.message_from_bytes(header_data)

        from_val = decode_header_value(msg.get("From", ""))
        subject_val = decode_header_value(msg.get("Subject", "(no subject)"))
        date_val = msg.get("Date", "")

        uid_str = f"[UID:{uid}]" if uid else f"[SEQ:{mid.decode()}]"
        print(f"{uid_str} {date_val}  From: {from_val}  Subject: {subject_val}")


def read_message(mail, uid, folder="INBOX"):
    mail.select(folder, readonly=True)
    status, data = mail.uid("fetch", uid.encode(), "(RFC822)")
    if status != "OK" or not data[0]:
        print(f"ERROR: Could not fetch message UID {uid}", file=sys.stderr)
        return

    msg = email.message_from_bytes(data[0][1])

    print(f"From: {decode_header_value(msg.get('From', ''))}")
    print(f"To: {decode_header_value(msg.get('To', ''))}")
    print(f"Date: {msg.get('Date', '')}")
    print(f"Subject: {decode_header_value(msg.get('Subject', ''))}")
    print("---")
    print(get_body(msg))


def search_emails(mail, query, folder="INBOX", count=10):
    mail.select(folder, readonly=True)

    # Build IMAP search criteria
    if query.startswith("from:"):
        criteria = f'(FROM "{query[5:]}")'
    elif query.startswith("subject:"):
        criteria = f'(SUBJECT "{query[8:]}")'
    elif query.startswith("to:"):
        criteria = f'(TO "{query[3:]}")'
    elif query.startswith("since:"):
        criteria = f'(SINCE "{query[6:]}")'
    else:
        # General text search
        criteria = f'(TEXT "{query}")'

    status, messages = mail.search(None, criteria)
    if status != "OK":
        print("ERROR: Search failed", file=sys.stderr)
        return

    msg_ids = messages[0].split()
    if not msg_ids:
        print("(no matching emails)")
        return

    latest = msg_ids[-count:]
    latest.reverse()

    for mid in latest:
        status, data = mail.fetch(mid, "(UID BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])")
        if status != "OK":
            continue
        uid = None
        resp_line = data[0][0].decode() if isinstance(data[0][0], bytes) else str(data[0][0])
        import re
        uid_match = re.search(r"UID (\d+)", resp_line)
        if uid_match:
            uid = uid_match.group(1)

        header_data = data[0][1]
        msg = email.message_from_bytes(header_data)

        from_val = decode_header_value(msg.get("From", ""))
        subject_val = decode_header_value(msg.get("Subject", "(no subject)"))
        date_val = msg.get("Date", "")

        uid_str = f"[UID:{uid}]" if uid else f"[SEQ:{mid.decode()}]"
        print(f"{uid_str} {date_val}  From: {from_val}  Subject: {subject_val}")


def main():
    parser = argparse.ArgumentParser(description="Read emails via Gmail IMAP")
    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # inbox
    inbox_p = subparsers.add_parser("inbox", help="List latest emails")
    inbox_p.add_argument("--folder", default="INBOX", help="Folder to read (default: INBOX)")
    inbox_p.add_argument("--count", type=int, default=10, help="Number of emails to show (default: 10)")

    # read
    read_p = subparsers.add_parser("read", help="Read a specific email by UID")
    read_p.add_argument("uid", help="Email UID")
    read_p.add_argument("--folder", default="INBOX", help="Folder (default: INBOX)")

    # search
    search_p = subparsers.add_parser("search", help="Search emails")
    search_p.add_argument("query", help="Search query (from:, subject:, to:, since:, or free text)")
    search_p.add_argument("--folder", default="INBOX", help="Folder (default: INBOX)")
    search_p.add_argument("--count", type=int, default=10, help="Max results (default: 10)")

    # folders
    subparsers.add_parser("folders", help="List available folders/labels")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    mail = connect()
    try:
        if args.command == "inbox":
            list_inbox(mail, folder=args.folder, count=args.count)
        elif args.command == "read":
            read_message(mail, args.uid, folder=args.folder)
        elif args.command == "search":
            search_emails(mail, args.query, folder=args.folder, count=args.count)
        elif args.command == "folders":
            list_folders(mail)
    finally:
        mail.logout()


if __name__ == "__main__":
    main()
