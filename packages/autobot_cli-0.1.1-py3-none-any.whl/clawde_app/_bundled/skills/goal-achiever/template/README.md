
# Goal Achiever Template (Claude Code)

This is a **repository template** for turning an LLM CLI agent (Claude Code) into a long-horizon goal pursuer.

You use it by:
1. Filling in `GOAL.md`
2. Optionally customizing metrics definitions in `status/METRICS.md`
3. Running Claude Code repeatedly in this repo and prompting: **“iterate the project”**

Each run should:
- pick the next best actions,
- execute a small batch of work,
- update metrics and state,
- and write back the next actions for the following run.

## Quick start

1. Edit `GOAL.md`:
   - objective
   - key results (measurable)
   - constraints
   - definition of done

2. Start with an initial baseline in `status/METRICS.md`.

3. Run Claude Code in this repo and prompt:
   - “iterate the project”
   - “do the next iteration”
   - “advance toward the goal”

4. After each run, review:
   - `status/STATUS.md`
   - `status/NEXT_ACTIONS.md`
   - `tasks/BOARD.md`
   - `logs/ITERATIONS.md`

## Design principles

- **State lives in files**, not chat history.
- **Parallel thinking** is tracked as hypotheses + experiments.
- **Progress is measured**, not assumed.
- **Iteration is bounded**: do 1–3 actions per run and stop.

See `CLAUDE.md` for the full agent operating protocol.
