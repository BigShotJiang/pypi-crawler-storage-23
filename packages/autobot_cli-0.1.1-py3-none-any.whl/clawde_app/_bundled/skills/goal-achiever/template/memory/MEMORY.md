
# Working memory (compact)

This file is **compact working memory** for the agent.
It should NOT become a giant log.

## Size rule
- Target: <= 200 lines.
- If it grows too long, summarize older content into `memory/daily/YYYY-MM-DD.md`
  and trim this file back down.

## What belongs here
- Stable facts that are frequently needed
- Current strategy and key constraints
- Important “do/don’t” lessons learned
- Links to the most important artifacts

## Current working memory
- Goal: (short)
- Constraints: (short)
- Current strategy: (short)
- Top lessons:
  - …
- Pointers:
  - Status: `status/STATUS.md`
  - Next actions: `status/NEXT_ACTIONS.md`
  - Task board: `tasks/BOARD.md`
