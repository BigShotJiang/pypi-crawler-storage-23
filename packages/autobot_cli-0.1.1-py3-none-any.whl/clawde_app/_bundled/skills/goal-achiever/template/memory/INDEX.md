
# Memory index (topics)

Use this file to keep pointers to topic notes and key artifacts.

## Topics
- Market / customers: `memory/topics/market.md`
- Product: `memory/topics/product.md`
- Pricing: `memory/topics/pricing.md`
- Tech / implementation: `memory/topics/tech.md`

## Key decisions (ADRs)
- …

## Key hypotheses (validated)
- …

## Key failures (rejected hypotheses to avoid repeating)
- …
