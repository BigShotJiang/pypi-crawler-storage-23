
---
id: T-YYYYMMDD-###
status: todo  # todo | next | in_progress | blocked | done
priority: P0  # P0 | P1 | P2
owner: agent
created: YYYY-MM-DD
links:
  # All paths are repo-root relative (e.g., "status/STATUS.md")
  goal: GOAL.md
  status: status/STATUS.md
  hypothesis: hypotheses/active/H-YYYYMMDD-###.md
  experiment: experiments/E-YYYYMMDD-###/plan.md
---

# Task: <short title>

## Why
(What problem does this solve for the goal?)

## Definition of done
- [ ] …

## Steps
1. …

## Notes / context
- …

## Updates / progress
- YYYY-MM-DD: …
