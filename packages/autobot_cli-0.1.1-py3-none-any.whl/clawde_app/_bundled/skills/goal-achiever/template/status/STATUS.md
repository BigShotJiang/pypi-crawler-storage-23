
# Status (current truth)

> Keep this file short (target <= 160 lines).  
> This is the **single best snapshot** of where the goal stands right now.

## Last updated
- Date: YYYY-MM-DD
- By: agent

## Goal progress summary
- Objective: (from `GOAL.md`)
- Current best estimate vs target: (e.g., KR1: +6% vs +20% target)

## What changed since last iteration
- …

## Current situation (facts)
- …

## Active strategy
(One paragraph: what we’re doing right now and why.)

## Active hypotheses (top 3–7)
- [H-YYYYMMDD-###](../hypotheses/active/H-YYYYMMDD-###.md): status + next test
- …

## In-flight experiments
- [E-YYYYMMDD-###](../experiments/E-YYYYMMDD-###/plan.md): status

## Blockers / needs from user
- …

## Next checkpoint
- Next metric update expected: YYYY-MM-DD
- Next decision needed: …
