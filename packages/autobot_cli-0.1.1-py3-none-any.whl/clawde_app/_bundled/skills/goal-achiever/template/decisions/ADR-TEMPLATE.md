
# ADR-YYYYMMDD-###: <Decision title>

## Status
- Proposed | Accepted | Rejected | Superseded

## Context
(What problem are we solving? What constraints matter?)

## Decision
(What did we choose?)

## Alternatives considered
- Option A:
- Option B:

## Consequences
- Positive:
- Negative:
- Risks:

## Links
- Goal: `GOAL.md`
- Related tasks: (e.g., `tasks/T-YYYYMMDD-001.md`)
- Related hypotheses: (e.g., `hypotheses/active/H-YYYYMMDD-001.md`)
- Related experiments: (e.g., `experiments/E-YYYYMMDD-001/plan.md`)
