
# Hypotheses index

## Active
- (link active hypothesis files in `hypotheses/active/`)

## Validated
- (link validated hypothesis files in `hypotheses/validated/`)

## Rejected (do not repeat)
- (link rejected hypothesis files in `hypotheses/rejected/`)
