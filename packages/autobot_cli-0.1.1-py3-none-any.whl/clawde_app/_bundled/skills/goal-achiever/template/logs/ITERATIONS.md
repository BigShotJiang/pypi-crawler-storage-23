
# Iteration log

Append one entry per iteration (newest first is optional; pick one ordering and stay consistent).

---

## YYYY-MM-DD HH:MM (Iteration N)
### Goal focus
- …

### Inputs read
- GOAL.md
- status/STATUS.md
- status/METRICS.md
- status/NEXT_ACTIONS.md
- tasks/BOARD.md
- memory/MEMORY.md
- (other files…)

### Actions taken
- …

### Outputs / changes
- Files changed:
  - …
- New artifacts created:
  - …

### Results
- …

### Decisions
- (link ADR if made)

### Next actions queued
- (copy from status/NEXT_ACTIONS.md)

### Blockers / questions
- …
