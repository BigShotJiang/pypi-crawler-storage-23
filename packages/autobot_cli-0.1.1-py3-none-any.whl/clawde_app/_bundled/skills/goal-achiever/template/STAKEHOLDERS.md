
# Stakeholders

List the people/systems involved.

| Name | Role | Contact | Decision rights | Notes |
|------|------|---------|-----------------|-------|
|      |      |         |                 |       |

## Communication cadence
- Weekly update:
- Async updates:
- Approval process:
