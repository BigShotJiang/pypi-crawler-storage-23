"""Helpers for locating bundled assets shipped with the package.

In a wheel install, ``force-include`` puts assets under
``clawde_app/_bundled/``.  In an editable / dev install the directory
doesn't exist — helpers fall back to repo-relative paths.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional


def _package_dir() -> Path:
    """Return the ``clawde_app/`` package directory."""
    return Path(__file__).resolve().parent.parent


def _bundled_dir() -> Path:
    """Return ``clawde_app/_bundled/``."""
    return Path(__file__).resolve().parent


def _repo_root() -> Path:
    """Return the repo root (parent of ``clawde_app/``)."""
    return _package_dir().parent


def _is_dev_mode() -> bool:
    """True when running from an editable install / source repo."""
    root = _repo_root()
    return (root / "CLAUDE.md").exists() or (root / ".claude").exists()


# ------------------------------------------------------------------
# Public helpers — each returns the dir if it can be located, else None
# ------------------------------------------------------------------

def get_builtin_skills_dir() -> Optional[Path]:
    """Built-in skills (goal-achiever, email-sender, kanban-autonomous)."""
    bundled = _bundled_dir() / "skills"
    if bundled.is_dir():
        return bundled
    dev = _repo_root() / "skills"
    if dev.is_dir():
        return dev
    return None


def get_bundled_rules_dir() -> Optional[Path]:
    """.claude/rules/ markdown files."""
    bundled = _bundled_dir() / "rules"
    if bundled.is_dir():
        return bundled
    dev = _repo_root() / ".claude" / "rules"
    if dev.is_dir():
        return dev
    return None


def get_bundled_hooks_dir() -> Optional[Path]:
    """.claude/hooks/ Python scripts."""
    bundled = _bundled_dir() / "hooks"
    if bundled.is_dir():
        return bundled
    dev = _repo_root() / ".claude" / "hooks"
    if dev.is_dir():
        return dev
    return None


def get_bundled_settings_json() -> Optional[Path]:
    """.claude/settings.json."""
    bundled = _bundled_dir() / "settings.json"
    if bundled.is_file():
        return bundled
    dev = _repo_root() / ".claude" / "settings.json"
    if dev.is_file():
        return dev
    return None


def get_bundled_claude_md() -> Optional[Path]:
    """CLAUDE.md project instructions."""
    bundled = _bundled_dir() / "CLAUDE.md"
    if bundled.is_file():
        return bundled
    dev = _repo_root() / "CLAUDE.md"
    if dev.is_file():
        return dev
    return None


def get_bundled_mcp_templates_dir() -> Optional[Path]:
    """MCP server JSON templates (memory.json, kanban.json, etc.)."""
    bundled = _bundled_dir() / "mcp_templates"
    if bundled.is_dir():
        return bundled
    dev = _repo_root() / "mcp" / "servers"
    if dev.is_dir():
        return dev
    return None


def get_bundled_mcp_dir() -> Optional[Path]:
    """Bundled MCP files (e.g. kanban-mcp-server.mjs)."""
    bundled = _bundled_dir() / "mcp"
    if bundled.is_dir():
        return bundled
    dev = _repo_root() / "mcp"
    if dev.is_dir():
        return dev
    return None


def get_bundled_dashboard_dir() -> Optional[Path]:
    """Pre-built Vue dashboard (dashboard/dist/)."""
    bundled = _bundled_dir() / "dashboard_dist"
    if bundled.is_dir():
        return bundled
    dev = _repo_root() / "dashboard" / "dist"
    if dev.is_dir():
        return dev
    return None
