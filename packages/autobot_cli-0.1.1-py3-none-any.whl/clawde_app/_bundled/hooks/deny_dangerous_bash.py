#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from typing import Any, Optional


def _read_stdin_json() -> Optional[dict[str, Any]]:
    raw = sys.stdin.read()
    if not raw.strip():
        return None
    try:
        obj = json.loads(raw)
        if isinstance(obj, dict):
            return obj
        return None
    except Exception:
        return None


def _deny(reason: str) -> None:
    out = {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": reason,
        }
    }
    sys.stdout.write(json.dumps(out))


def _norm_cmd(cmd: str) -> str:
    return cmd.strip()


def _is_dangerous(cmd: str) -> Optional[str]:
    """
    Return a human-readable reason if dangerous, else None.
    Keep this conservative: block obviously destructive / irreversible commands.
    """
    c = _norm_cmd(cmd)
    cl = c.lower()

    # Block wipe-the-world rm patterns
    rm_root_patterns = [
        r"\brm\s+-rf\s+/\s*$",
        r"\brm\s+-rf\s+/\s+",
        r"\brm\s+-rf\s+/\*\b",
        r"\brm\s+-rf\s+~\b",
        r"\brm\s+-rf\s+\$home\b",
        r"\brm\s+-rf\s+--no-preserve-root\b",
    ]
    for pat in rm_root_patterns:
        if re.search(pat, cl):
            return "Destructive delete (rm -rf on root/home) is blocked."

    # Windows destructive deletes
    if re.search(r"\bdel\s+/s\b", cl) or re.search(r"\brmdir\s+/s\b", cl):
        return "Recursive Windows delete (del/rmdir /s) is blocked."

    # Disk formatting / low-level destructive tools
    if re.search(r"\bmkfs(\.\w+)?\b", cl) or re.search(r"\bformat\s+[a-z]:", cl):
        return "Disk/volume formatting commands are blocked."

    if re.search(r"\bdd\s+if=", cl) and ("/dev/" in cl or "\\\\.\\physicaldrive" in cl):
        return "Low-level disk write (dd to /dev/*) is blocked."

    # System power controls
    if re.search(r"\bshutdown\b", cl) or re.search(r"\breboot\b", cl) or re.search(r"\bpoweroff\b", cl):
        return "System shutdown/reboot commands are blocked."

    # Remote script execution via pipe
    if re.search(r"\b(curl|wget)\b.+\|\s*(bash|sh|zsh)\b", cl):
        return "Piping remote content into a shell (curl/wget | sh) is blocked."

    # PowerShell remote execution
    if re.search(r"\b(iwr|invoke-webrequest|curl)\b.+\|\s*(iex|invoke-expression)\b", cl):
        return "Piping remote content into PowerShell execution (… | iex) is blocked."

    # Obvious forkbomb signature (very rough)
    if ":(){ :|:& };:" in cl:
        return "Fork bomb pattern is blocked."

    return None


def main() -> int:
    data = _read_stdin_json()
    if not data:
        return 0

    tool_name = (data.get("tool_name") or "").strip()
    tool_input = data.get("tool_input") if isinstance(data.get("tool_input"), dict) else {}

    if tool_name != "Bash":
        return 0

    command = tool_input.get("command")
    if not isinstance(command, str) or not command.strip():
        return 0

    reason = _is_dangerous(command)
    if reason:
        _deny(reason)
        return 0

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
