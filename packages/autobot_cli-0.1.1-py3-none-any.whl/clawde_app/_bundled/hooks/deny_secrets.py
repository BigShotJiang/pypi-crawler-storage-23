#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from fnmatch import fnmatch
from pathlib import Path
from typing import Any, Optional, Tuple


def _read_stdin_json() -> Optional[dict[str, Any]]:
    raw = sys.stdin.read()
    if not raw.strip():
        return None
    try:
        obj = json.loads(raw)
        if isinstance(obj, dict):
            return obj
        return None
    except Exception:
        return None


def _norm(s: str) -> str:
    # Normalize for pattern matching across Windows/Linux.
    return s.replace("\\", "/").strip()


def _safe_relpath(abs_path: str, cwd: str) -> Optional[str]:
    try:
        p = Path(abs_path).resolve()
        c = Path(cwd).resolve()
        rel = p.relative_to(c)
        return _norm(rel.as_posix())
    except Exception:
        return None


def _matches_any(path: str, patterns: list[str]) -> Optional[str]:
    for pat in patterns:
        if fnmatch(path, pat):
            return pat
    return None


def _is_sensitive_path(path_str: str) -> Optional[Tuple[str, str]]:
    """
    Returns (pattern, reason) if sensitive, else None.

    We keep this conservative: block common secret locations/files, but
    avoid overly-broad patterns that would break normal development.
    """
    p = _norm(path_str)
    pl = p.lower()

    # Quick substring guards for known secret dirs
    if "/.ssh/" in pl or pl.endswith("/.ssh") or pl.endswith("/.ssh/"):
        return (".ssh", "SSH directory is sensitive.")
    if "/.aws/" in pl or pl.endswith("/.aws") or pl.endswith("/.aws/"):
        return (".aws", "AWS credentials/config directory is sensitive.")
    if "/data/" in pl or pl.endswith("/data") or pl.endswith("/data/"):
        # Note: we *do not* block all data/* here by substring alone because sometimes
        # teams store non-secrets there. We'll block specific files/patterns below.
        pass

    # Filename-based checks
    name = Path(pl).name

    # .env files
    if name == ".env" or name.startswith(".env."):
        return (".env", "Environment files often contain secrets (tokens/keys).")

    # Key material
    key_exts = (".pem", ".key", ".p12", ".pfx", ".kdbx")
    if any(name.endswith(ext) for ext in key_exts):
        return ("key-material", "Private key/certificate material is sensitive.")

    if name.startswith("id_rsa") or name.startswith("id_ed25519"):
        return ("ssh-key", "Private SSH keys are sensitive.")

    # Common credential filenames
    cred_like = ("secret", "secrets", "credential", "credentials", "password", "passwords", "apikey", "api_key")
    stem = Path(pl).stem
    if any(tok in stem for tok in cred_like):
        # Only block if it looks like a config-ish file (reduce false positives)
        if Path(pl).suffix.lower() in (".json", ".yaml", ".yml", ".txt", ".env", ".toml", ".ini"):
            return ("credential-file", "Credential-like config file is sensitive.")

    # Project-specific: block clawde runtime config + db by convention
    # (These commonly contain bot tokens/session ids.)
    protected_globs = [
        "data/config.yaml",
        "data/config.yml",
        "data/*.db",
        "data/*.sqlite",
        "data/*.sqlite3",
        "data/*.json"  # common place to accidentally store tokens
    ]
    hit = _matches_any(pl, protected_globs)
    if hit:
        return (hit, "clawde runtime data/config/database may contain secrets.")

    return None


def _deny(reason: str) -> None:
    # IMPORTANT: stdout must be JSON ONLY on exit 0.
    out = {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": reason,
        }
    }
    sys.stdout.write(json.dumps(out))


def main() -> int:
    data = _read_stdin_json()
    if not data:
        return 0

    tool_name = (data.get("tool_name") or "").strip()
    tool_input = data.get("tool_input") if isinstance(data.get("tool_input"), dict) else {}
    cwd = (data.get("cwd") or "").strip()

    candidates: list[str] = []

    if tool_name in {"Read", "Edit", "Write"}:
        fp = tool_input.get("file_path")
        if isinstance(fp, str) and fp.strip():
            candidates.append(_norm(fp))

            if cwd:
                rel = _safe_relpath(fp, cwd)
                if rel:
                    candidates.append(rel)

    elif tool_name == "Glob":
        pat = tool_input.get("pattern")
        path = tool_input.get("path")
        if isinstance(path, str) and path.strip():
            candidates.append(_norm(path))
        if isinstance(pat, str) and pat.strip():
            # A glob pattern that explicitly targets secrets should be blocked.
            candidates.append(_norm(pat))

    elif tool_name == "Grep":
        path = tool_input.get("path")
        glob_pat = tool_input.get("glob")
        if isinstance(path, str) and path.strip():
            candidates.append(_norm(path))
        if isinstance(glob_pat, str) and glob_pat.strip():
            candidates.append(_norm(glob_pat))

    else:
        # Not a tool we care about here; allow.
        return 0

    # Evaluate candidates
    for c in candidates:
        hit = _is_sensitive_path(c)
        if hit:
            pattern, why = hit
            _deny(f"Blocked sensitive access ({pattern}). {why}")
            return 0

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
