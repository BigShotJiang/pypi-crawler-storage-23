"""Lightweight process manager API — always-on, manages gateway lifecycle."""
from __future__ import annotations

import time
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .config import build_paths
from .main import (
    is_process_alive,
    read_pid,
    remove_pid,
    start_background,
    stop_process,
)

app = FastAPI(title="Clawde Manager", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Resolved at startup via configure()
_config_path: Path | None = None
_log_level: str = "INFO"


def _paths():
    return build_paths(_config_path)


def configure(config_path: Path, log_level: str = "INFO") -> None:
    """Set the config path before starting the server."""
    global _config_path, _log_level
    _config_path = config_path
    _log_level = log_level


@app.get("/status")
async def gateway_status():
    """Check if the gateway is running."""
    paths = _paths()
    pid = read_pid(paths)
    if pid is None:
        return {"running": False, "pid": None}
    if is_process_alive(pid):
        return {"running": True, "pid": pid}
    # Stale PID
    remove_pid(paths)
    return {"running": False, "pid": None}


@app.post("/start")
async def gateway_start():
    """Start the gateway as a background process."""
    paths = _paths()
    pid = read_pid(paths)
    if pid is not None and is_process_alive(pid):
        raise HTTPException(409, f"Already running (PID {pid})")
    if pid is not None:
        remove_pid(paths)

    new_pid = start_background(_config_path, _log_level)
    time.sleep(2)
    if is_process_alive(new_pid):
        return {"ok": True, "pid": new_pid}
    raise HTTPException(500, "Gateway process exited immediately. Check runtime/logs/clawde.log.")


@app.post("/stop")
async def gateway_stop():
    """Stop the running gateway."""
    paths = _paths()
    pid = read_pid(paths)
    if pid is None or not is_process_alive(pid):
        if pid is not None:
            remove_pid(paths)
        return {"ok": True, "message": "Gateway is not running."}

    stopped = stop_process(paths, timeout=10)
    if stopped:
        return {"ok": True, "message": "Gateway stopped."}
    raise HTTPException(500, "Failed to stop gateway.")


@app.post("/restart")
async def gateway_restart():
    """Stop the gateway (if running), then start a new process."""
    paths = _paths()
    pid = read_pid(paths)
    if pid is not None and is_process_alive(pid):
        stopped = stop_process(paths, timeout=10)
        if not stopped:
            raise HTTPException(500, "Failed to stop current gateway.")
        time.sleep(2)

    new_pid = start_background(_config_path, _log_level)
    time.sleep(2)
    if is_process_alive(new_pid):
        return {"ok": True, "pid": new_pid}
    raise HTTPException(500, "New gateway process exited immediately. Check runtime/logs/clawde.log.")


def run_manager(config_path: Path, log_level: str = "INFO", port: int = 8421) -> None:
    """Run the manager API server (blocking)."""
    configure(config_path, log_level)
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="warning")
