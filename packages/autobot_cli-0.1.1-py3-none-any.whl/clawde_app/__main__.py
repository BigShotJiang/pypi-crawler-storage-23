"""Allow running as ``python -m clawde_app``."""

from clawde_app.cli import main

raise SystemExit(main())
