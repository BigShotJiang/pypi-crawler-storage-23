from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Literal, Optional

import yaml

try:
    from pydantic import BaseModel, Field, SecretStr  # type: ignore
except Exception as e:  # pragma: no cover
    raise RuntimeError(
        "pydantic is required. Install dependencies from requirements/pyproject."
    ) from e

from .models import TelegramMode


class TelegramConfig(BaseModel):
    """Legacy single-bot config. Kept for backward compatibility."""
    bot_token: SecretStr
    mode: TelegramMode = TelegramMode.polling

    allowed_chat_ids: List[int] = Field(default_factory=list)
    admin_chat_ids: List[int] = Field(default_factory=list)

    respond_in_groups: bool = False
    require_mention_in_groups: bool = True

    max_reply_chars: int = 3500
    send_long_as_file: bool = True


class AgentConfig(BaseModel):
    """Per-agent configuration. Each agent is a separate Telegram bot."""
    bot_token: SecretStr
    default_backend: str = "claude"

    allowed_chat_ids: List[int] = Field(default_factory=list)
    admin_chat_ids: List[int] = Field(default_factory=list)

    respond_in_groups: bool = False
    require_mention_in_groups: bool = True

    max_reply_chars: int = 3500
    send_long_as_file: bool = True

    def is_allowed_chat(self, chat_id: int) -> bool:
        return chat_id in set(self.allowed_chat_ids)

    def is_admin_chat(self, chat_id: int) -> bool:
        return chat_id in set(self.admin_chat_ids)


class ToolProfile(BaseModel):
    """
    `tools` restricts tool availability (stronger).
    `allowed_tools` auto-approves those tools in print mode.
    `dangerously_skip_permissions` bypasses all permission checks (YOLO mode).
    """
    tools: str = ""
    allowed_tools: str = ""
    dangerously_skip_permissions: bool = False


class ClaudeConfig(BaseModel):
    executable: str = "claude"
    model: Optional[str] = None

    max_turns_telegram: Optional[int] = None
    max_turns_cron: Optional[int] = None
    max_turns_ingest: int = 1

    output_format: Literal["json", "stream-json"] = "stream-json"

    tool_profiles: Dict[str, ToolProfile] = Field(default_factory=dict)


class CodexConfig(BaseModel):
    executable: str = "codex"
    model: Optional[str] = None
    max_turns_telegram: Optional[int] = None
    max_turns_cron: Optional[int] = None
    max_turns_ingest: int = 1


class GeminiConfig(BaseModel):
    executable: str = "gemini"
    model: Optional[str] = None
    max_turns_telegram: Optional[int] = None
    max_turns_cron: Optional[int] = None
    max_turns_ingest: int = 1


class MemoryRetrievalConfig(BaseModel):
    strategy: Literal["keyword", "hybrid"] = "keyword"
    max_snippets: int = 6
    max_chars_per_snippet: int = 1500
    keyword_min_hits: int = 1
    # Hybrid search settings (used when strategy="hybrid")
    min_score: float = 0.15  # Filter out results below this combined score
    vector_weight: float = 0.7
    text_weight: float = 0.3
    chunk_target_tokens: int = 400
    chunk_overlap_chars: int = 50
    embedding_model: str = "text-embedding-3-small"
    # Qdrant vector database settings
    qdrant_url: str = "http://localhost:6333"
    qdrant_collection: str = "memory_vectors"


class MemoryFlushConfig(BaseModel):
    """Pre-compaction memory flush settings."""
    enabled: bool = True
    turn_threshold: int = 15
    text_len_threshold: int = 50000


class MemoryConfig(BaseModel):
    daily_include_days: int = 2
    retrieval: MemoryRetrievalConfig = Field(default_factory=MemoryRetrievalConfig)
    flush: MemoryFlushConfig = Field(default_factory=MemoryFlushConfig)


class SchedulerConfig(BaseModel):
    timezone: str = "Europe/London"
    misfire_grace_seconds: int = 120
    coalesce: bool = True
    max_concurrent_jobs: int = 2


class SecurityConfig(BaseModel):
    secrets_path_globs: List[str] = Field(default_factory=list)
    deny_bash_patterns: List[str] = Field(default_factory=list)


class WebConfig(BaseModel):
    """Web dashboard configuration."""
    enabled: bool = True
    host: str = "0.0.0.0"
    port: int = 8420


class FeaturesConfig(BaseModel):
    """Feature flags for experimental features."""
    goals: bool = False  # Goal-achiever skill (long-horizon goal pursuit)


class AppConfig(BaseModel):
    # --- Multi-agent (preferred) ---
    agents: Dict[str, AgentConfig] = Field(default_factory=dict)

    # --- Legacy single-bot (backward compat) ---
    telegram: Optional[TelegramConfig] = None

    # --- Shared settings ---
    claude: ClaudeConfig = Field(default_factory=ClaudeConfig)
    codex: CodexConfig = Field(default_factory=CodexConfig)
    gemini: GeminiConfig = Field(default_factory=GeminiConfig)
    default_backend: str = "claude"
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    scheduler: SchedulerConfig = Field(default_factory=SchedulerConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    features: FeaturesConfig = Field(default_factory=FeaturesConfig)
    web: WebConfig = Field(default_factory=WebConfig)

    def get_tool_profile(self, name: str) -> ToolProfile:
        # Provide safe defaults even if config is incomplete
        if name in self.claude.tool_profiles:
            return self.claude.tool_profiles[name]
        # fallback: safe_chat if present, else "no tools"
        if "safe_chat" in self.claude.tool_profiles:
            return self.claude.tool_profiles["safe_chat"]
        return ToolProfile(tools="", allowed_tools="")


@dataclass(frozen=True)
class AppPaths:
    """
    Derived paths used by the application.

    ``data_home`` is the root directory for all user data.  In development
    (editable install) this is the repository root.  In a pip-installed
    deployment it defaults to ``~/.autobot/``.

    ``repo_root`` is kept as an alias for ``data_home`` so that existing
    code that references ``paths.repo_root`` keeps working.
    """
    data_home: Path
    package_dir: Path
    config_path: Path
    data_dir: Path
    db_path: Path
    runtime_dir: Path
    runtime_context_file: Path
    memory_dir: Path
    memory_topics_dir: Path
    memory_daily_dir: Path
    claude_rules_dir: Path
    stderr_log_dir: Path
    agents_dir: Path
    skills_dir: Path
    mcp_dir: Path
    mcp_servers_dir: Path

    @property
    def repo_root(self) -> Path:
        """Backward-compat alias for ``data_home``."""
        return self.data_home


# ---------------------------------------------------------------------------
# Package location helpers
# ---------------------------------------------------------------------------

def _package_dir() -> Path:
    """Return the directory containing the installed ``clawde_app`` package."""
    return Path(__file__).resolve().parent


def _bundled_dir() -> Path:
    """Return the ``_bundled/`` directory inside the package (wheel builds)."""
    return _package_dir() / "_bundled"


def is_dev_mode() -> bool:
    """True when running from an editable install / source repo."""
    pkg = _package_dir()
    parent = pkg.parent
    return (parent / "CLAUDE.md").exists() or (parent / ".claude").exists()


# ---------------------------------------------------------------------------
# Data-home discovery
# ---------------------------------------------------------------------------

_DEFAULT_DATA_HOME = Path.home() / ".autobot"


def discover_data_home(
    config_path: Optional[Path] = None,
    data_dir_override: Optional[Path] = None,
) -> Path:
    """Find the data home directory.

    Resolution order:
    1. Explicit *data_dir_override* (``--data-dir`` CLI flag).
    2. ``AUTOBOT_DATA_DIR`` environment variable.
    3. Walk up from *config_path* looking for ``.autobot-root`` sentinel.
    4. **Legacy:** walk up looking for ``CLAUDE.md`` or ``.claude/``
       (keeps development repos working).
    5. Default: ``~/.autobot/``.
    """
    # 1. Explicit override
    if data_dir_override:
        return Path(data_dir_override).expanduser().resolve()

    # 2. Environment variable
    env_dir = os.environ.get("AUTOBOT_DATA_DIR")
    if env_dir:
        return Path(env_dir).expanduser().resolve()

    # 3 + 4. Walk up from config path
    if config_path:
        p = Path(config_path).expanduser().resolve()
        cur = p.parent if p.is_file() else p
        for _ in range(12):
            # New sentinel
            if (cur / ".autobot-root").exists():
                return cur
            # Legacy dev-repo sentinel
            if (cur / "CLAUDE.md").exists() or (cur / ".claude").exists():
                return cur
            if cur.parent == cur:
                break
            cur = cur.parent

    # 5. Default
    return _DEFAULT_DATA_HOME


def discover_repo_root(start: Optional[Path] = None) -> Path:
    """**Deprecated** — use :func:`discover_data_home` instead.

    Kept for backward compatibility with code that calls this directly.
    """
    return discover_data_home(config_path=start)


def build_paths(
    config_path: Path,
    data_dir_override: Optional[Path] = None,
) -> AppPaths:
    """Build all application paths from a config file location.

    If *data_dir_override* is given it takes precedence over automatic
    discovery for determining the data home.
    """
    data_home = discover_data_home(config_path, data_dir_override)
    pkg_dir = _package_dir()

    # Legacy dev-repo layout has data/ subdir; packaged layout is flat.
    _legacy_data_dir = data_home / "data"
    if _legacy_data_dir.is_dir():
        data_dir = _legacy_data_dir
        db_path = _legacy_data_dir / "clawde.db"
    else:
        data_dir = data_home
        db_path = data_home / "clawde.db"

    runtime_dir = data_home / "runtime"
    runtime_context_file = runtime_dir / "context" / "current.md"
    memory_dir = data_home / "memory"
    memory_topics_dir = memory_dir / "topics"
    memory_daily_dir = memory_dir / "daily"
    claude_rules_dir = data_home / ".claude" / "rules"
    stderr_log_dir = runtime_dir / "logs"
    agents_dir = data_home / "agents"
    skills_dir = data_home / "skills"
    mcp_dir = data_home / "mcp"
    mcp_servers_dir = mcp_dir / "servers"
    return AppPaths(
        data_home=data_home,
        package_dir=pkg_dir,
        config_path=config_path.expanduser().resolve(),
        data_dir=data_dir,
        db_path=db_path,
        runtime_dir=runtime_dir,
        runtime_context_file=runtime_context_file,
        memory_dir=memory_dir,
        memory_topics_dir=memory_topics_dir,
        memory_daily_dir=memory_daily_dir,
        claude_rules_dir=claude_rules_dir,
        stderr_log_dir=stderr_log_dir,
        agents_dir=agents_dir,
        skills_dir=skills_dir,
        mcp_dir=mcp_dir,
        mcp_servers_dir=mcp_servers_dir,
    )


def _migrate_legacy_telegram(raw: dict) -> dict:
    """
    Backward compat: if old-style ``telegram:`` key exists and no ``agents:``
    key, convert to ``agents: {clawde: ...}`` format.

    Mutates *raw* in-place and returns it.
    """
    if "agents" in raw and raw["agents"]:
        return raw  # already using new format

    telegram = raw.pop("telegram", None)
    if telegram is None:
        return raw  # nothing to migrate

    # Map old TelegramConfig fields → AgentConfig fields
    agent_entry: dict = {
        "bot_token": telegram["bot_token"],
        "default_backend": raw.get("default_backend", "claude"),
    }
    for key in (
        "allowed_chat_ids", "admin_chat_ids",
        "respond_in_groups", "require_mention_in_groups",
        "max_reply_chars", "send_long_as_file",
    ):
        if key in telegram:
            agent_entry[key] = telegram[key]

    raw["agents"] = {"clawde": agent_entry}
    return raw


def load_config(
    config_path: str | Path,
    data_dir_override: Optional[Path] = None,
) -> tuple[AppConfig, AppPaths]:
    """
    Load YAML config and derive application paths.

    Returns (AppConfig, AppPaths).
    """
    path = Path(config_path).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}

    # Migrate old single-bot config to multi-agent format
    _migrate_legacy_telegram(raw)

    if not raw.get("agents"):
        raise ValueError(
            "Config must define at least one agent under 'agents:' "
            "(or use legacy 'telegram:' section)."
        )

    # Pydantic v2 uses model_validate; v1 uses parse_obj
    if hasattr(AppConfig, "model_validate"):
        cfg = AppConfig.model_validate(raw)  # type: ignore[attr-defined]
    else:
        cfg = AppConfig.parse_obj(raw)  # type: ignore[attr-defined]

    paths = build_paths(path, data_dir_override=data_dir_override)
    return cfg, paths


def _serialize_config_dict(cfg: AppConfig) -> dict:
    """Convert AppConfig to a plain dict suitable for YAML serialization."""
    if hasattr(cfg, "model_dump"):
        raw = cfg.model_dump(mode="json")  # pydantic v2
    else:
        raw = cfg.dict()  # pydantic v1

    # Ensure bot_token values are plain strings (v1 returns SecretStr objects)
    if "agents" in raw:
        for agent_name, agent_dict in raw["agents"].items():
            agent_cfg = cfg.agents.get(agent_name)
            if agent_cfg and hasattr(agent_cfg.bot_token, "get_secret_value"):
                agent_dict["bot_token"] = agent_cfg.bot_token.get_secret_value()

    # Remove legacy telegram key
    raw.pop("telegram", None)

    return raw


def save_config(cfg: AppConfig, config_path: Path) -> None:
    """Write the current AppConfig to disk as YAML (atomic)."""
    from .utils import atomic_write_text

    raw = _serialize_config_dict(cfg)
    yaml_text = yaml.dump(raw, default_flow_style=False, sort_keys=False, allow_unicode=True)
    header = "# clawde config (auto-saved)\n\n"
    atomic_write_text(config_path, header + yaml_text)
