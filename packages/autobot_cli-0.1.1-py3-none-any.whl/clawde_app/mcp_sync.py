"""
Central MCP (Model Context Protocol) server registry and sync.

Reads server definitions from ``mcp/servers/*.json`` and generates
CLI-specific config files into the target working directory before each run.

Supports three backends:
- Claude Code: ``<cwd>/.mcp.json``
- Codex CLI:   ``<cwd>/.codex/config.toml``
- Gemini CLI:  ``<cwd>/.gemini/settings.json``
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger("clawde.mcp_sync")

_NAME_RE = re.compile(r"^[A-Za-z0-9_-]+$")


@dataclass(frozen=True)
class PreLaunchDef:
    """A background process dependency that the gateway manages before the MCP server runs."""
    command: str
    args: Optional[List[str]] = None
    port: Optional[int] = None
    find_executable: Optional[str] = None
    env: Optional[Dict[str, str]] = None


@dataclass(frozen=True)
class MCPServerDef:
    name: str
    description: str = ""
    type: str = "stdio"  # "stdio" | "http" | "sse"
    command: Optional[str] = None
    args: Optional[List[str]] = None
    env: Optional[Dict[str, str]] = None
    url: Optional[str] = None
    headers: Optional[Dict[str, str]] = None
    enabled: bool = True
    port: Optional[int] = None  # For gateway-managed HTTP servers
    pre_launch: Optional[PreLaunchDef] = None  # Background process dependency


def has_pre_launch(s: MCPServerDef) -> bool:
    """True if the server declares a pre-launch background dependency."""
    return s.pre_launch is not None


def is_managed_mcp_server(s: MCPServerDef) -> bool:
    """True if the gateway should manage this server's lifecycle via supergateway."""
    return s.type == "http" and s.command is not None and s.port is not None


def managed_mcp_url(s: MCPServerDef) -> str:
    """Return the HTTP URL for a managed MCP server."""
    return f"http://localhost:{s.port}/mcp"


def ensure_mcp_scaffold(mcp_servers_dir: Path) -> None:
    """Create ``mcp/servers/`` if missing."""
    mcp_servers_dir.mkdir(parents=True, exist_ok=True)


def _safe_read_json(path: Path) -> Optional[Dict[str, Any]]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def _parse_server_file(path: Path) -> Optional[MCPServerDef]:
    raw = _safe_read_json(path)
    if not raw or not isinstance(raw, dict):
        return None
    name = raw.get("name") or path.stem
    if not _NAME_RE.match(name):
        log.warning("Invalid MCP server name %r in %s, skipping", name, path)
        return None
    # Parse pre_launch block if present
    pre_launch: Optional[PreLaunchDef] = None
    pl_raw = raw.get("pre_launch")
    if isinstance(pl_raw, dict) and pl_raw.get("command"):
        pre_launch = PreLaunchDef(
            command=pl_raw["command"],
            args=pl_raw.get("args"),
            port=pl_raw.get("port"),
            find_executable=pl_raw.get("find_executable"),
            env=pl_raw.get("env"),
        )

    return MCPServerDef(
        name=name,
        description=raw.get("description", ""),
        type=raw.get("type", "stdio"),
        command=raw.get("command"),
        args=raw.get("args"),
        env=raw.get("env"),
        url=raw.get("url"),
        headers=raw.get("headers"),
        enabled=raw.get("enabled", True),
        port=raw.get("port"),
        pre_launch=pre_launch,
    )


def _toml_quote(value: Any) -> str:
    """Quote and escape a TOML double-quoted string value."""
    if value is None:
        return '""'
    escaped = str(value)
    escaped = (
        escaped
        .replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\b", "\\b")
        .replace("\t", "\\t")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
    )
    return f'"{escaped}"'


def list_mcp_servers(mcp_servers_dir: Path) -> List[MCPServerDef]:
    """Return all MCP server definitions from ``mcp/servers/*.json``."""
    if not mcp_servers_dir.is_dir():
        return []
    servers: List[MCPServerDef] = []
    for p in sorted(mcp_servers_dir.glob("*.json")):
        srv = _parse_server_file(p)
        if srv is not None:
            servers.append(srv)
    return servers


def list_enabled_mcp_servers(mcp_servers_dir: Path) -> List[MCPServerDef]:
    return [s for s in list_mcp_servers(mcp_servers_dir) if s.enabled]


# ---------------------------------------------------------------------------
# Backend-specific config generation
# ---------------------------------------------------------------------------

def _build_claude_config(servers: List[MCPServerDef]) -> Dict[str, Any]:
    """Build ``.mcp.json`` content for Claude Code."""
    mcp_servers: Dict[str, Any] = {}
    for s in servers:
        entry: Dict[str, Any] = {}
        if is_managed_mcp_server(s):
            entry["type"] = "http"
            entry["url"] = managed_mcp_url(s)
        elif s.type == "stdio":
            entry["type"] = "stdio"
            if s.command:
                entry["command"] = s.command
            if s.args:
                entry["args"] = s.args
            if s.env:
                entry["env"] = s.env
        elif s.type in ("http", "sse"):
            entry["type"] = s.type
            if s.url:
                entry["url"] = s.url
            if s.headers:
                entry["headers"] = s.headers
        if not entry:
            continue  # Skip prelaunch-only servers with no MCP config
        mcp_servers[s.name] = entry
    return {"mcpServers": mcp_servers}


def _build_codex_toml(servers: List[MCPServerDef]) -> str:
    """Build ``.codex/config.toml`` MCP section for Codex CLI."""
    lines: List[str] = ["# Auto-generated by clawde MCP sync\n"]
    for s in servers:
        # Skip prelaunch-only servers with no MCP config
        if not is_managed_mcp_server(s) and not s.command and not s.url:
            continue
        lines.append(f"[mcp_servers.{s.name}]")
        if is_managed_mcp_server(s):
            lines.append(f"url = {_toml_quote(managed_mcp_url(s))}")
        elif s.type == "stdio":
            if s.command:
                lines.append(f"command = {_toml_quote(s.command)}")
            if s.args:
                args_str = ", ".join(_toml_quote(a) for a in s.args)
                lines.append(f"args = [{args_str}]")
        elif s.type in ("http", "sse"):
            if s.url:
                lines.append(f"url = {_toml_quote(s.url)}")
        lines.append("")
        if not is_managed_mcp_server(s) and s.env:
            lines.append(f"[mcp_servers.{s.name}.env]")
            for k, v in s.env.items():
                lines.append(f'{_toml_quote(k)} = {_toml_quote(v)}')
            lines.append("")
        if s.headers:
            lines.append(f"[mcp_servers.{s.name}.http_headers]")
            for k, v in s.headers.items():
                lines.append(f'{_toml_quote(k)} = {_toml_quote(v)}')
            lines.append("")
    return "\n".join(lines)


def _build_gemini_config(servers: List[MCPServerDef]) -> Dict[str, Any]:
    """Build ``.gemini/settings.json`` content for Gemini CLI."""
    mcp_servers: Dict[str, Any] = {}
    for s in servers:
        entry: Dict[str, Any] = {}
        if is_managed_mcp_server(s):
            entry["httpUrl"] = managed_mcp_url(s)
        elif s.type == "stdio":
            if s.command:
                entry["command"] = s.command
            if s.args:
                entry["args"] = s.args
            if s.env:
                entry["env"] = s.env
        elif s.type == "http":
            if s.url:
                entry["httpUrl"] = s.url
            if s.headers:
                entry["headers"] = s.headers
        elif s.type == "sse":
            if s.url:
                entry["url"] = s.url
            if s.headers:
                entry["headers"] = s.headers
        if not entry:
            continue  # Skip prelaunch-only servers with no MCP config
        mcp_servers[s.name] = entry
    return {"mcpServers": mcp_servers}


def _merge_codex_user_config(target: Path, mcp_toml: str) -> None:
    """Merge MCP server sections into the user-level ~/.codex/config.toml.

    Preserves existing non-MCP settings (model, approval_policy, etc.)
    while replacing all [mcp_servers.*] sections with the new ones.
    """
    target.parent.mkdir(parents=True, exist_ok=True)

    # Read existing config, strip out old [mcp_servers.*] sections
    existing_lines: List[str] = []
    if target.exists():
        try:
            raw = target.read_text(encoding="utf-8")
        except Exception:
            raw = ""
        in_mcp_section = False
        for line in raw.splitlines():
            stripped = line.strip()
            if stripped.startswith("[mcp_servers."):
                in_mcp_section = True
                continue
            if in_mcp_section:
                # A new top-level section header ends the MCP section
                if stripped.startswith("[") and not stripped.startswith("[mcp_servers."):
                    in_mcp_section = False
                    existing_lines.append(line)
                # Otherwise skip (still in an mcp_servers block or its keys)
                continue
            existing_lines.append(line)

    # Remove trailing blank lines from existing content
    while existing_lines and not existing_lines[-1].strip():
        existing_lines.pop()

    # Combine: existing settings + blank line + MCP sections
    parts = []
    if existing_lines:
        parts.append("\n".join(existing_lines))
    mcp_stripped = mcp_toml.strip()
    # Remove the auto-generated comment header if present (avoid duplicating it)
    for prefix in ("# Auto-generated by clawde MCP sync\n", "# Auto-generated by clawde MCP sync"):
        if mcp_stripped.startswith(prefix):
            mcp_stripped = mcp_stripped[len(prefix):].lstrip("\n")
    if mcp_stripped:
        parts.append(mcp_stripped)
    content = "\n\n".join(parts) + "\n"
    _write_if_changed(target, content)


def _write_if_changed(path: Path, content: str) -> bool:
    """Write ``content`` to ``path`` only if it differs. Returns True if written."""
    try:
        existing = path.read_text(encoding="utf-8")
        if existing == content:
            return False
    except FileNotFoundError:
        pass
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return True


def sync_mcp_to_cwd(
    mcp_servers_dir: Path,
    cwd: Path,
    backend: str,
    *,
    agent_name: str = "",
    repo_root: Optional[Path] = None,
) -> None:
    """
    Generate CLI-specific MCP config files in ``cwd`` for the given backend.

    Reads all enabled servers from ``mcp_servers_dir`` and writes the
    appropriate config file. Idempotent (only writes if changed).

    If *agent_name* and *repo_root* are provided, the memory MCP server
    receives ``CLAWDE_AGENT_NAME`` and ``CLAWDE_REPO_ROOT`` env vars so it
    can search the correct agent's memory directory.
    """
    servers = list_enabled_mcp_servers(mcp_servers_dir)

    # Resolve <package_mcp> placeholder in server args
    from ._bundled import get_bundled_mcp_dir
    _mcp_dir = get_bundled_mcp_dir()
    _mcp_dir_str = str(_mcp_dir) if _mcp_dir else ""

    # Inject runtime env vars into the memory MCP server
    import sys
    patched: List[MCPServerDef] = []
    for s in servers:
        new_args = s.args
        # Substitute <package_mcp> in args (e.g. kanban-mcp-server.mjs path)
        if s.args and _mcp_dir_str:
            new_args = [a.replace("<package_mcp>", _mcp_dir_str) for a in s.args]

        if s.name == "memory" and s.type == "stdio":
            env = dict(s.env or {})
            if repo_root:
                env["CLAWDE_REPO_ROOT"] = str(repo_root)
                # Ensure clawde_app is importable even when cwd is external
                env["PYTHONPATH"] = str(repo_root)
            if agent_name:
                env["CLAWDE_AGENT_NAME"] = agent_name
            # Use the gateway's own Python interpreter (venv) so deps are available
            command = sys.executable
            # Rebuild with updated env and absolute Python path (frozen dataclass)
            s = MCPServerDef(
                name=s.name, description=s.description, type=s.type,
                command=command, args=new_args, env=env, url=s.url,
                headers=s.headers, enabled=s.enabled, port=s.port,
                pre_launch=s.pre_launch,
            )
        elif new_args is not s.args:
            s = MCPServerDef(
                name=s.name, description=s.description, type=s.type,
                command=s.command, args=new_args, env=s.env, url=s.url,
                headers=s.headers, enabled=s.enabled, port=s.port,
                pre_launch=s.pre_launch,
            )
        patched.append(s)
    servers = patched
    if not servers:
        return

    if backend == "claude":
        config = _build_claude_config(servers)
        content = json.dumps(config, indent=2, ensure_ascii=False) + "\n"
        target = cwd / ".mcp.json"
        if _write_if_changed(target, content):
            log.debug("Synced %d MCP server(s) to %s", len(servers), target)

    elif backend == "codex":
        # Codex CLI requires trusted projects for project-level config.
        # Write MCP servers to user-level ~/.codex/config.toml instead,
        # merging with any existing settings (model, approval_policy, etc.)
        user_codex_dir = Path.home() / ".codex"
        target = user_codex_dir / "config.toml"
        mcp_toml = _build_codex_toml(servers)
        _merge_codex_user_config(target, mcp_toml)
        log.debug("Synced %d MCP server(s) to %s (user-level)", len(servers), target)

    elif backend == "gemini":
        config = _build_gemini_config(servers)
        content = json.dumps(config, indent=2, ensure_ascii=False) + "\n"
        target = cwd / ".gemini" / "settings.json"
        if _write_if_changed(target, content):
            log.debug("Synced %d MCP server(s) to %s", len(servers), target)
