"""
Alfred Prompts - Modular prompt assembly.

Prompt injection, persona, and example content is provided by each domain
via DomainConfig methods. Use get_current_domain() to access domain-specific
prompt content rather than importing directly from this package.
"""

