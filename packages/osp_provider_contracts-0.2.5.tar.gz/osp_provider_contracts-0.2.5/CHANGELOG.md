# Changelog

## 0.2.4 - 2026-02-20

- Added shared provider update envelope contracts in
  `osp_provider_contracts.provider_updates`:
  - `ProviderUpdateEnvelope`
  - `ProviderTaskEvent`
  - `build_provider_update_envelope()`
  - `parse_provider_update_envelope()`
- Exported provider update contracts from package root.
- Added regression tests for update envelope build/parse behavior.

## 0.2.3 - 2026-02-20

- Exported approval TypedDict contracts at package root to simplify imports
  for provider and orchestrator consumers.
- Hardened capabilities validation to reject string values for
  `capabilities.resources` while still accepting generic mappings.
- Renamed conformance helpers from `testing` to `conformance` and reorganized
  tests under `tests/unit/` with matching docs updates.
- Added broader module and API documentation polish for maintainers.

## 0.2.2 - 2026-02-17

- Added typed approval payload contracts for violations-first gate
  evidence:
  - `CommentKind`
  - `GateViolation`
  - `ApprovalTargets`
  - `ApprovalDetails`
  - `ApprovalRequiredExtra`
- Aligns provider and orchestrator/CLI consumers on the
  `violations[]` contract shape for gate explainability.

## 0.2.1 - 2026-02-17

- Added canonical `GateCode` enum for approval gate responses in
  `osp_provider_contracts.approval`.
- Added `GateCode.EXTRA_EYES_REQUIRED = 432` for orchestrator
  dual-control approval gating.

## 0.2.0 - 2026-02-12

- Removed ambiguous `ProviderResult.state`; providers now return result payload via `data`.
- Kept `external_id` as the canonical top-level identifier field on `ProviderResult`.
- Hardened idempotency hashing input encoding to avoid delimiter-collision ambiguity.
- Removed unused `osp_provider_contracts.conformance.fixtures` helpers.
- Reduced repository `.gitignore` to a focused package-level set.

## 0.1.0 - 2026-02-12

- Initial alpha release.
- Added provider protocol, shared types, and canonical errors.
- Added capabilities validation and idempotency key helper.
- Added lightweight conformance assertions for provider tests.
