"""Verify public top-level exports stay stable for consumers."""

import osp_provider_contracts as contracts

EXPECTED_EXPORTS = {
    "ApprovalDetails",
    "ApprovalRequiredExtra",
    "ApprovalTargets",
    "CommentKind",
    "GateReason",
    "GateViolation",
    "PROVIDER_UPDATE_KIND_TASK_EVENT",
    "ProviderTaskEvent",
    "ProviderUpdateEnvelope",
    "build_provider_update_envelope",
    "parse_provider_update_envelope",
}


def test_approval_types_exported_at_top_level() -> None:
    """Expose approval TypedDicts and aliases from package root."""
    missing = sorted(name for name in EXPECTED_EXPORTS if not hasattr(contracts, name))
    assert missing == []


def test_approval_types_in_dunder_all() -> None:
    """Keep ``__all__`` aligned with the documented public API."""
    exported = set(contracts.__all__)
    assert EXPECTED_EXPORTS.issubset(exported)
