from osp_provider_contracts import GateReason


def test_gate_reason_surface_is_stable() -> None:
    assert GateReason.APPROVAL_REQUIRED.value == "approval_required"
    assert GateReason.PROVIDER_APPROVAL_REQUIRED.value == "provider_approval_required"
    assert GateReason.LIMITS_EXCEEDED.value == "limits_exceeded"
    assert GateReason.PLACEMENT_VIOLATION.value == "placement_violation"
    assert GateReason.POLICY_EXCEPTION_REQUIRED.value == "policy_exception_required"
    assert GateReason.AUTHZ_REQUIRED.value == "authz_required"
    assert GateReason.EXTRA_EYES_REQUIRED.value == "extra_eyes_required"
