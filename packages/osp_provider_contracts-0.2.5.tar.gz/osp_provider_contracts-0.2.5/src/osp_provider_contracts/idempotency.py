"""Idempotency key generation for provider operations.

Providers use idempotency keys to detect and reject duplicate requests. The key
is a deterministic hash derived from orchestrator task metadata and the specific
action/resource, ensuring retries and re-deliveries are safely deduplicated.

Contracts:
    - Keys are stable: same inputs always produce the same SHA256 hex digest.
    - Keys use structured JSON encoding to avoid delimiter-collision ambiguities.
    - Keys are globally unique across all tasks, requests, actions, and resources.

Usage:
    Providers call this during execute() to generate a deduplication key before
    performing side-effecting operations against external APIs.
"""

from __future__ import annotations

import hashlib
import json

from .types import RequestContext


def build_idempotency_key(
    *,
    context: RequestContext,
    action: str,
    resource_key: str,
) -> str:
    """Generate a stable idempotency key for a provider operation.

    The key is a SHA256 hash of a JSON array containing [task_id, task_ref, action,
    resource_key]. This ensures duplicate requests (e.g., message redelivery, retry)
    produce the same key and can be safely deduplicated by the provider.

    Args:
        context: Orchestrator-provided request context containing task_id and task_ref.
        action: The provider action being executed (e.g., "create", "delete").
        resource_key: Provider-specific resource identifier (e.g., hostname, uuid).

    Returns:
        64-character lowercase hex digest (SHA256) that uniquely identifies this
        operation across all tasks, requests, actions, and resources.

    Example:
        >>> ctx = RequestContext(task_id="t123", task_ref="task-123")
        >>> key = build_idempotency_key(context=ctx, action="create", resource_key="vm-foo")
        >>> len(key)
        64

    """
    # Use a structured encoding to avoid delimiter-collision ambiguities.
    base = json.dumps(
        [context.task_id, context.task_ref, action, resource_key],
        separators=(",", ":"),
        ensure_ascii=True,
    )
    return hashlib.sha256(base.encode("utf-8")).hexdigest()
