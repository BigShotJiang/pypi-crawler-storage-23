"""Core request/result types for provider protocol.

These frozen dataclasses define the stable interface for provider execute() calls.
All fields are immutable to ensure safe concurrent access and serialization.

Contracts:
    - RequestContext is provided by the orchestrator and must not be mutated.
    - ProviderRequest.payload structure is action-specific; providers validate internally.
    - ProviderResult.success=False should be used for business-logic failures that don't
      warrant an exception (e.g., VM already exists on idempotent create).
    - external_id in ProviderResult is the provider's stable identifier for the resource.

Usage:
    The orchestrator constructs these objects and passes them to Provider.execute().
    Providers return ProviderResult or raise ProviderError on failure.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any


# DOCS:BEGIN request_context
@dataclass(frozen=True, slots=True)
class RequestContext:
    """Orchestrator-provided context for each provider request.

    Contains stable task/request identifiers for idempotency, audit, and correlation.
    Providers should not modify these fields; use them for logging and key generation.

    Attributes:
        task_id: Orchestrator task UUID (stable across retries).
        task_ref: Task-scoped correlation reference.
        actor: Optional username or service principal that initiated the task.
        idempotency_key: Optional pre-computed idempotency key (future use).
        metadata: Optional provider-specific metadata forwarded from the task.

    """

    task_id: str
    task_ref: str
    actor: str | None = None
    idempotency_key: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


# DOCS:END request_context


# DOCS:BEGIN provider_request
@dataclass(frozen=True, slots=True)
class ProviderRequest:
    """Provider action request payload.

    Contains the action name, resource kind, and action-specific parameters.
    Providers validate the payload structure internally based on capabilities.

    Attributes:
        action: Action to perform (e.g., "create", "delete"). Must match one of the
            actions declared in the provider's capabilities for this resource_kind.
        resource_kind: Resource type being operated on (e.g., "vm", "network").
        payload: Action-specific parameters (e.g., {"hostname": "foo", "cpus": 4}).
            Structure varies by resource_kind and action.

    """

    action: str
    resource_kind: str
    payload: Mapping[str, Any]


# DOCS:END provider_request


# DOCS:BEGIN provider_result
@dataclass(frozen=True, slots=True)
class ProviderResult:
    """Provider action result.

    Returned by Provider.execute() to indicate success or business-logic failure.
    For exceptions (auth failures, rate limits, etc.), raise ProviderError instead.

    Attributes:
        success: Whether the operation succeeded. Use False for idempotent no-ops
            (e.g., resource already exists) or soft failures that don't warrant exceptions.
        external_id: Optional provider-assigned identifier for the resource (e.g., VM UUID,
            instance ID). The orchestrator stores this for future operations and audit.
        message: Optional human-readable result message for logs and UI.
        data: Optional structured result data (e.g., IP addresses, resource metadata).

    """

    success: bool
    external_id: str | None = None
    message: str | None = None
    data: Mapping[str, Any] = field(default_factory=dict)


# DOCS:END provider_result
