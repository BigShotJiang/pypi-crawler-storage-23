"""Testing utilities for provider conformance verification.

Provides lightweight assertions that provider implementations conform to the
Provider protocol and capabilities schema. Use these in provider test suites
to catch integration issues early.

Usage:
    from osp_provider_contracts.conformance import assert_provider_conforms

    def test_provider_conforms():
        provider = MyProvider()
        assert_provider_conforms(provider)
"""

from .assertions import assert_provider_conforms

__all__ = ["assert_provider_conforms"]
