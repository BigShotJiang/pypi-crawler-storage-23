# Testing (Conformance Assertions)

Lightweight assertions for verifying that a provider implementation satisfies
the `Provider` protocol and returns a valid capabilities document. Intended
for use in provider test suites — not a pytest plugin.

## What lives here

- `assertions.py` — `assert_provider_conforms(provider)`: the only public
  function in this subpackage.

## Usage

```python
from osp_provider_contracts.conformance import assert_provider_conforms

def test_provider_conforms():
    provider = MyProvider()
    assert_provider_conforms(provider)
```

Import from `osp_provider_contracts.conformance`, not from the submodule directly.

## What it checks

1. `provider.capabilities` is callable.
2. `provider.execute` is callable.
3. `capabilities()` requires 0 parameters (excluding `self`).
4. `execute()` requires exactly 3 parameters (excluding `self`): `action`,
   `request`, `context`.
5. `capabilities()` returns a `Mapping`.
6. The returned mapping passes `validate_capabilities()` — i.e., it has
   `provider` (str), `version` (str), and `resources` (list of dicts with
   `kind` and `actions`).

Failures raise `AssertionError` with a message identifying the violation.

## What it does NOT check

- Runtime behavior of `execute()` — no actual tasks are run.
- Idempotency — that is a behavioral property tested separately.
- External API integration — no network calls are made.
- Error handling — correct use of `ProviderError` subclasses.
- Thread safety of `execute()`.

Use `assert_provider_conforms` as a smoke test that catches structural
mismatches early. Integration behavior must be tested in provider-specific
test suites.

## Design rules

- No network calls, no side effects.
- Only imports from `osp_provider_contracts.capabilities` (stdlib + contracts).
- Raises `AssertionError`, not `ProviderError` — these are test failures,
  not runtime errors.
