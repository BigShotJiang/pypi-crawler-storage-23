"""Conformance assertions for provider implementations.

Provider test suites should call assert_provider_conforms() to verify that their
implementation satisfies the Provider protocol and returns valid capabilities.

Contracts:
    - Assertion failures raise AssertionError with actionable error messages.
    - Checks method presence, arity, and capabilities schema validity.
    - Does NOT check runtime behavior or external API integration.

Usage:
    from osp_provider_contracts.conformance import assert_provider_conforms

    def test_my_provider_conforms():
        provider = MyProvider()
        assert_provider_conforms(provider)  # Raises AssertionError on violations
"""

from __future__ import annotations

import inspect
from collections.abc import Mapping
from typing import Any

from osp_provider_contracts.capabilities import validate_capabilities


def _assert_method_arity(method: Any, expected: int, name: str) -> None:
    """Verify a method has exactly the expected number of required parameters.

    Args:
        method: The method to check (must be callable with a signature).
        expected: Number of required positional parameters (excluding self).
        name: Method name for error messages.

    Raises:
        AssertionError: If the method has a different number of required parameters.

    """
    params = list(inspect.signature(method).parameters.values())
    required = [
        p
        for p in params
        if p.default is inspect.Signature.empty
        and p.kind in (inspect.Parameter.POSITIONAL_ONLY, inspect.Parameter.POSITIONAL_OR_KEYWORD)
    ]
    if len(required) != expected:
        message = f"{name} requires exactly {expected} parameters, found {len(required)}"
        raise AssertionError(message)


def assert_provider_conforms(provider: Any) -> None:
    """Assert that a provider conforms to the Provider protocol and schema.

    Verifies that the provider object has callable capabilities() and execute() methods
    with the correct arity, and that capabilities() returns a valid capabilities document.

    This assertion does NOT test runtime behavior, idempotency, or external API integration.
    Use it as a basic smoke test in provider test suites.

    Args:
        provider: The provider instance to check (any object).

    Raises:
        AssertionError: When the provider is missing required methods, has incorrect
            method signatures, or returns invalid capabilities. The error message
            identifies the specific conformance violation.

    Example:
        >>> from my_provider import MyProvider
        >>> provider = MyProvider()
        >>> assert_provider_conforms(provider)  # Passes if conformant, raises otherwise

    """
    if not hasattr(provider, "capabilities") or not callable(provider.capabilities):
        raise AssertionError("provider must define callable capabilities()")
    if not hasattr(provider, "execute") or not callable(provider.execute):
        raise AssertionError("provider must define callable execute(action, request, context)")

    _assert_method_arity(provider.capabilities, expected=0, name="capabilities")
    _assert_method_arity(provider.execute, expected=3, name="execute")

    capabilities = provider.capabilities()
    if not isinstance(capabilities, Mapping):
        raise AssertionError("capabilities() must return a mapping")
    validate_capabilities(capabilities)
