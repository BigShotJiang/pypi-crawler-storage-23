"""Provider protocol defining the stable interface between providers and orchestrator.

All OSP providers (VMware, NREC, etc.) must implement the Provider protocol.
The orchestrator calls capabilities() during registration and execute() for each
task routed to the provider.

Contracts:
    - capabilities() may be called at startup and via capabilities RPC.
      It must return a valid, stable mapping shape.
    - execute() is called concurrently for multiple tasks; implementations must be thread-safe.
    - execute() must handle idempotency internally using build_idempotency_key().
    - execute() errors must inherit from ProviderError for correct retry behavior.

Usage:
    Providers implement this protocol and register with the orchestrator:

        class MyProvider:
            def capabilities(self) -> dict[str, Any]:
                return {"provider": "my-provider", "version": "1.0.0", "resources": [...]}

            def execute(self, action: str, request: ProviderRequest, context: RequestContext):
                # Perform operation, return ProviderResult or raise ProviderError
                ...
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Protocol, runtime_checkable

from .types import ProviderRequest, ProviderResult, RequestContext


@runtime_checkable
class Provider(Protocol):
    """Runtime-checkable protocol for OSP provider implementations.

    The orchestrator expects providers to implement these two methods. Use
    `isinstance(obj, Provider)` or `assert_provider_conforms(obj)` to verify.
    """

    def capabilities(self) -> Mapping[str, Any]:
        """Return provider capabilities document.

        Called during provider startup and for capabilities RPC requests. The
        returned document must conform to validate_capabilities() schema:
        provider (str), version (str), resources (sequence of {kind, actions}).

        Returns:
            Mapping containing provider metadata and supported resource/action pairs.

        """
        ...

    def execute(
        self,
        action: str,
        request: ProviderRequest,
        context: RequestContext,
    ) -> ProviderResult:
        """Execute a provider action against a resource.

        This method is called for each task routed to the provider. Implementations
        must be thread-safe and idempotent (use build_idempotency_key() to deduplicate).

        Args:
            action: The action to perform (e.g., "create", "delete", "update").
            request: Request payload containing resource_kind and action-specific data.
            context: Orchestrator metadata (task_id, task_ref, actor, etc.).

        Returns:
            ProviderResult indicating success/failure, optional external_id, and data.

        Raises:
            ProviderError: (or subclass) on failure. Retryable errors trigger retry;
                non-retryable errors move the task to FAILED status immediately.

        """
        ...
