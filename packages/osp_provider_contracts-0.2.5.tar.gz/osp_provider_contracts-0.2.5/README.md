# osp-provider-contracts

Shared Python contract package for OSP providers and orchestrator:
typed interfaces, canonical errors, capabilities schema, idempotency helpers,
and lightweight conformance assertions.

For maintainer-facing internals and invariants, see `src/README.md`.

## Scope (v0.1)

- Small, explicit provider protocol
- Shared request/result/context types
- Canonical error taxonomy with retry metadata
- Capabilities schema validation
- Conformance assertions for provider test suites
- Canonical gate code enum for approval-required flows

No pytest plugin is included in v0.1.

## Approval-Required Contract

Providers that need human approval should raise `ValidationError` with
`detail="approval_required"` and include a structured `extra` payload:

- `gate_code`: one of `osp_provider_contracts.GateCode` values (4xx)
- `importance`: integer risk/urgency indicator when applicable
- `reason`: stable machine-readable reason string
- `details`: provider-specific context for operators and audit

## Install

```bash
pip install osp-provider-contracts
```

## Development

```bash
env -u VIRTUAL_ENV uv sync --extra dev
hatch shell
hatch run check
hatch run build
hatch run verify
```

## Release

See `docs/release.md` for the manual/gated publish flow.

Tag and push:

```bash
git tag v0.2.0
git push origin v0.2.0
```
