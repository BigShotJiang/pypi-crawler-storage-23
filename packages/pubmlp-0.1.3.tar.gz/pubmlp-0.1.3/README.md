<img src="https://raw.githubusercontent.com/mshin77/pubmlp/main/docs_src/_static/logo.svg" alt="pubmlp Logo" align="right" width="220px"/>

[![PyPI version](https://img.shields.io/pypi/v/pubmlp?cacheSeconds=0)](https://pypi.org/project/pubmlp/)
[![Python versions](https://img.shields.io/pypi/pyversions/pubmlp?cacheSeconds=0)](https://pypi.org/project/pubmlp/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

Multimodal publication classifier with LLM and deep learning. Fuses transformer embeddings with tabular features through a multilayer perceptron (MLP) for human-in-the-loop screening workflows.

## Installation

```bash
pip install pubmlp
```

With optional dependencies:

```bash
pip install pubmlp[screening]  # screening tools (openpyxl, nltk)
```

From GitHub:

```bash
pip install git+https://github.com/mshin77/pubmlp.git
```

## Getting Started

See [Quick Start](https://mshin77.github.io/pubmlp/getting-started.html) and [Screening Workflow](https://mshin77.github.io/pubmlp/vignettes/screening-workflow.html) for tutorials.

## Citation

- Shin, M. (2026). *pubmlp: Multimodal publication classifier with LLM and deep learning* (Python package version 0.1.3) [Computer software]. <https://github.com/mshin77/pubmlp>
