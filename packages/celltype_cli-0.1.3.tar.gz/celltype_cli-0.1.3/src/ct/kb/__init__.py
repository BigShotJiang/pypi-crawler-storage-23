"""Knowledge substrate package for ct."""

from ct.kb.substrate import KnowledgeSubstrate

__all__ = ["KnowledgeSubstrate"]
