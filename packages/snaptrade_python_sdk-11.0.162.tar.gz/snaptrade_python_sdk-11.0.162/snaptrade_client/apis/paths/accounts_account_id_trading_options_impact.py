from snaptrade_client.paths.accounts_account_id_trading_options_impact.post import ApiForpost


class AccountsAccountIdTradingOptionsImpact(
    ApiForpost,
):
    pass
