from snaptrade_client.paths.accounts_account_id_orders_v2.get import ApiForget


class AccountsAccountIdOrdersV2(
    ApiForget,
):
    pass
