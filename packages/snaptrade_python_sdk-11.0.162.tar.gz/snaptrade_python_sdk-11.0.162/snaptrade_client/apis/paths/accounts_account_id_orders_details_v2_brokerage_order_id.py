from snaptrade_client.paths.accounts_account_id_orders_details_v2_brokerage_order_id.get import ApiForget


class AccountsAccountIdOrdersDetailsV2BrokerageOrderId(
    ApiForget,
):
    pass
