from snaptrade_client.paths.security_types.get import ApiForget


class SecurityTypes(
    ApiForget,
):
    pass
