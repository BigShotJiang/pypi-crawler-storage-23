from snaptrade_client.paths.accounts_account_id_balances.get import ApiForget


class AccountsAccountIdBalances(
    ApiForget,
):
    pass
