from snaptrade_client.paths.accounts_account_id_quotes.get import ApiForget


class AccountsAccountIdQuotes(
    ApiForget,
):
    pass
