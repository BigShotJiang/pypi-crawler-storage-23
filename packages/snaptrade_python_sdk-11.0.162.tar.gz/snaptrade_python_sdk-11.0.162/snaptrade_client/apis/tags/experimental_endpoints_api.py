# coding: utf-8

from snaptrade_client.apis.tags.experimental_endpoints_api_generated import ExperimentalEndpointsApiGenerated

class ExperimentalEndpointsApi(ExperimentalEndpointsApiGenerated):
    pass
