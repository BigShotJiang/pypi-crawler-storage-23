## Byte tries in Rust
