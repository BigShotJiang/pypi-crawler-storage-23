"""Text embedding models."""

from .embedding import ImageEmbeddingModel, TextEmbeddingModel

__all__ = ["TextEmbeddingModel", "ImageEmbeddingModel"]
