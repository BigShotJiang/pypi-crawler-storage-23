#!/bin/bash
#sudo /usr/local/sbin/add_share.sh $share_name $share_root $force_group
