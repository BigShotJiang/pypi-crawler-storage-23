import json
import uuid

try:
    import prison
except ImportError:
    prison = None

__all__ = ["uuid_namegen", "rison_loads"]


def uuid_namegen(filename: str) -> str:
    """
    Generates a unique filename by combining a UUID and the original filename.

    Args:
        filename (str): The original filename to be used in the unique name.

    Returns:
        str: The generated unique filename.
    """
    return str(uuid.uuid1()) + "_sep_" + filename


def rison_loads(v: str, fallback_to_json=True):
    """
    Load a string as either rison or JSON.

    Args:
        v (str): The string to be loaded as rison or JSON.
        fallback_to_json (bool, optional): Whether to fallback to JSON parsing if rison parsing fails. Defaults to True.

    Raises:
        ValueError: If the string is not a valid rison string and fallback_to_json is False.
        ImportError: If prison is not installed and JSON parsing fails.
        json.JSONDecodeError: If JSON parsing fails and prison is not installed.

    Returns:
        Any: The loaded rison or JSON object.
    """
    if prison:
        try:
            return prison.loads(v)
        except prison.decoder.ParserException:
            if not fallback_to_json:
                raise ValueError(
                    "Not a valid rison string",
                    "Please provide a valid rison string or set fallback_to_json to True to attempt JSON parsing.",
                    input=v,
                )

    try:
        return json.loads(v)
    except json.JSONDecodeError:
        if not prison:
            raise ImportError(
                "prison is required for rison parsing. JSON parsing failed as well. ",
                "Please install fastapi-rtk[fab] or prison for backward compatibility with flask-appbuilder rison-encoded query features.",
            )
        raise
