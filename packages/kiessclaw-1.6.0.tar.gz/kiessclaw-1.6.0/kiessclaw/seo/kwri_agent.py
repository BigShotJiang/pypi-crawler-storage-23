"""KWRI SEO writer agent."""

from __future__ import annotations

from typing import Any

from kiessclaw.core.agent import BaseAgent
from kiessclaw.core.memory import MemoryEngine


class KiessWriterAgent(BaseAgent):
    """Generate SEO briefs and metadata suggestions."""

    codename = "KWRI"
    name = "KiessWriter"
    description = "SEO content briefs and title/meta generation"

    def __init__(self, config: dict[str, Any], memory: MemoryEngine):
        """Initialize writer agent."""
        super().__init__(config, memory)

    def run(self, task: str, **kwargs: Any) -> str:
        """Execute SEO writing tasks."""
        self.update_status("running", task)
        try:
            if task == "brief" or "brief" in task.lower():
                return self._brief(kwargs.get("keyword", "seo strategy"))
            if task == "meta" or "title" in task.lower():
                return self._metadata(kwargs.get("keyword", "seo strategy"), kwargs.get("brand", "KIESSCLAW"))
            return self.think(task).content
        finally:
            self.update_status("idle")

    def _brief(self, keyword: str) -> str:
        """Create a simple SEO content brief."""
        return (
            "**KWRI Content Brief**\n\n"
            f"- Primary keyword: {keyword}\n"
            "- Search intent: informational/commercial investigation\n"
            "- H2 ideas: problem, approach, implementation, results, FAQ\n"
            "- CTA: request technical SEO + outreach audit"
        )

    def _metadata(self, keyword: str, brand: str) -> str:
        """Generate deterministic SEO title and meta description suggestions."""
        title = f"{keyword.title()} Guide | {brand}"
        meta = f"Learn practical {keyword} tactics with clear steps, examples, and measurable outcomes."
        return f"Title: {title}\nMeta: {meta}"

