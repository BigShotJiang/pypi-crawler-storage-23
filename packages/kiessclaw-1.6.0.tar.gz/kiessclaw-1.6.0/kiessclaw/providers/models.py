"""Provider result models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class ProviderResult:
    """Normalized response payload from provider operations."""

    ok: bool
    data: dict[str, Any] = field(default_factory=dict)
    provider: str = ""
    error: str | None = None
    confidence: float = 0.0
