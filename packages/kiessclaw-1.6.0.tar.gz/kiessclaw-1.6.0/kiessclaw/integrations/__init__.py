"""External integration helpers for optional runtime notifications."""

from kiessclaw.integrations.slack import SlackIntegration

__all__ = ["SlackIntegration"]
