"""Shared testing helpers for KIESSCLAW unit tests."""

from __future__ import annotations

from typing import Any


def base_config() -> dict[str, Any]:
    """Return a deterministic test config without external dependencies."""
    return {
        "llm": {
            "provider": "ollama",
            "default_model": "unit-test-model",
            "api_key": "",
            "base_url": "http://localhost:11434/v1",
        },
        "agents": {
            "KPRO": {"enabled": True, "settings": {"min_icp_score": 60}},
            "KSEQ": {
                "enabled": True,
                "settings": {
                    "max_daily_sends": 500,
                    "warmup_enabled": False,
                    "sending_window_start": "08:00",
                    "sending_window_end": "18:00",
                },
            },
            "KPEN": {"enabled": True, "settings": {"min_confidence": 0.7}},
            "KINB": {"enabled": True, "settings": {"classification_threshold": 0.8}},
            "KMET": {"enabled": True},
            "KRAWL": {"enabled": True, "settings": {"max_pages": 20, "request_timeout": 5}},
            "KANA": {"enabled": True},
            "KWRI": {"enabled": True},
            "KSCO": {"enabled": True},
            "KREP": {"enabled": True},
        },
        "email": {
            "provider": "smtp",
            "smtp": {
                "host": "smtp.test.local",
                "port": 587,
                "username": "sender@test.local",
                "password": "secret",
                "use_tls": True,
            },
            "tracking": {"opens": False, "clicks": False, "tracking_domain": ""},
        },
        "providers": {
            "email_finder": "mock",
            "enrichment": "mock",
            "crm": "mock",
            "inbox": "mock",
        },
        "safety": {"max_sends_per_hour": 50, "warmup_schedule": {}},
        "workspace": {"root": "./workspace"},
    }
