"""Tests for deterministic prompt rendering and lint checks."""

from __future__ import annotations

import unittest

from kiessclaw.prompting.prompt_factory import lint_prompt, render_prompt, render_prompt_pack


class PromptFactoryTest(unittest.TestCase):
    """Validate placeholder rendering and deterministic output behavior."""

    def _inputs(self) -> dict[str, str]:
        return {
            "target_segment": "B2B SaaS CTOs",
            "offer": "Pipeline diagnostics",
            "sender_name": "Alex",
            "sender_email": "alex@example.com",
            "cta": "Open to 15 minutes next week?",
        }

    def test_render_prompt_fills_placeholders(self) -> None:
        """System template should include provided inputs after rendering."""
        text = render_prompt(
            usecase_id="outreach_sdr",
            template_name="system",
            inputs=self._inputs(),
            deterministic=True,
        )
        self.assertIn("B2B SaaS CTOs", text)
        self.assertIn("alex@example.com", text)

    def test_lint_prompt_flags_missing_placeholders(self) -> None:
        """Lint should detect unresolved placeholder markers."""
        result = lint_prompt("Plan for {{missing_field}} with output format: json")
        self.assertFalse(result["valid"])
        self.assertIn("missing_field", result["missing_placeholders"])

    def test_deterministic_prompt_pack_is_stable(self) -> None:
        """Deterministic render should produce identical output over repeated calls."""
        first = render_prompt_pack("outreach_sdr", inputs=self._inputs(), deterministic=True)
        second = render_prompt_pack("outreach_sdr", inputs=self._inputs(), deterministic=True)
        self.assertEqual(first, second)


if __name__ == "__main__":
    unittest.main()
