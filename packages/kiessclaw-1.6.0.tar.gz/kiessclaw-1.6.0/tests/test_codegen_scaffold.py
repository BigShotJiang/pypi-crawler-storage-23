"""Tests for safe code scaffolding behavior."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from kiessclaw.codegen.scaffold import scaffold_usecase


class CodegenScaffoldTest(unittest.TestCase):
    """Verify generated files and overwrite safety rules."""

    def _inputs(self) -> dict[str, str]:
        return {
            "target_segment": "SMB SaaS",
            "offer": "diagnostic",
            "sender_name": "Dev",
            "sender_email": "dev@example.com",
            "cta": "Reply yes",
        }

    def test_scaffold_usecase_creates_expected_files(self) -> None:
        """Scaffold command should generate the default use case template set."""
        with tempfile.TemporaryDirectory() as tempdir:
            result = scaffold_usecase("outreach_sdr", target_dir=tempdir, inputs=self._inputs(), overwrite=False)
            created = [item for item in result if item["status"] == "created"]
            self.assertEqual(5, len(created))
            agent_file = Path(tempdir) / "outreach_sdr" / "outreach_sdr_agent.py"
            test_file = Path(tempdir) / "outreach_sdr" / "tests" / "test_outreach_sdr.py"
            self.assertTrue(agent_file.exists())
            self.assertTrue(test_file.exists())

            content = agent_file.read_text(encoding="utf-8")
            self.assertIn('"""', content)
            self.assertIn("->", content)

    def test_scaffold_usecase_no_overwrite_unless_force(self) -> None:
        """Existing files should be skipped without overwrite flag."""
        with tempfile.TemporaryDirectory() as tempdir:
            _ = scaffold_usecase("outreach_sdr", target_dir=tempdir, inputs=self._inputs(), overwrite=False)
            second = scaffold_usecase("outreach_sdr", target_dir=tempdir, inputs=self._inputs(), overwrite=False)
            self.assertTrue(any(item["status"] == "skipped" for item in second))
            forced = scaffold_usecase("outreach_sdr", target_dir=tempdir, inputs=self._inputs(), overwrite=True)
            self.assertTrue(all(item["status"] == "created" for item in forced))


if __name__ == "__main__":
    unittest.main()
