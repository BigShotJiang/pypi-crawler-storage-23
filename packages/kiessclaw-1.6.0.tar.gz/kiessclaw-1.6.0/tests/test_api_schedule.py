"""API tests for schedule management endpoints."""

from __future__ import annotations

import importlib
import os
import tempfile
import unittest
from pathlib import Path

import yaml

from tests.test_helpers import base_config

try:  # pragma: no cover
    from fastapi.testclient import TestClient
except ImportError:  # pragma: no cover
    TestClient = None


@unittest.skipIf(TestClient is None, "fastapi not installed in this environment")
class ApiScheduleTest(unittest.TestCase):
    """Validate schedule CRUD and run-now API routes."""

    @classmethod
    def setUpClass(cls) -> None:
        """Initialize API with isolated workspace and config."""
        cls._tempdir = tempfile.TemporaryDirectory()
        root = Path(cls._tempdir.name)
        workspace = root / "workspace"
        config_path = root / "config.yaml"

        config = base_config()
        config["workspace"]["root"] = str(workspace)
        config["llm"]["provider"] = "ollama"
        config["llm"]["api_key"] = ""
        config["email"]["smtp"]["host"] = "localhost"
        config["email"]["smtp"]["username"] = "test"
        config["email"]["smtp"]["password"] = "test"

        with config_path.open("w", encoding="utf-8") as handle:
            yaml.safe_dump(config, handle)

        os.environ["KIESSCLAW_CONFIG"] = str(config_path)
        import kiessclaw.api.app as api_app

        cls.api = importlib.reload(api_app)
        cls.client = TestClient(cls.api.app)

    @classmethod
    def tearDownClass(cls) -> None:
        """Dispose temp workspace resources."""
        cls._tempdir.cleanup()

    def test_get_schedule_returns_list(self) -> None:
        """GET /schedule should return an array payload."""
        response = self.client.get("/schedule")
        self.assertEqual(200, response.status_code)
        self.assertTrue(isinstance(response.json(), list))

    def test_post_schedule_creates_job(self) -> None:
        """POST /schedule should create and return a job ID."""
        response = self.client.post(
            "/schedule",
            json={
                "usecase_id": "outreach_sdr",
                "cron": "0 9 * * 1-5",
                "inputs": {
                    "company": "Acme",
                    "domain": "acme.com",
                    "contacts": [{"email": "cto@acme.com", "title": "CTO", "industry": "software", "employee_count": 80}],
                },
                "dry_run": True,
                "job_id": "api_job_1",
            },
        )
        self.assertEqual(200, response.status_code)
        self.assertEqual("api_job_1", response.json()["job_id"])

    def test_delete_schedule_removes_job(self) -> None:
        """DELETE /schedule/{job_id} should remove persisted job."""
        self.client.post(
            "/schedule",
            json={
                "usecase_id": "outreach_sdr",
                "cron": "0 9 * * 1-5",
                "inputs": {
                    "company": "Acme",
                    "domain": "acme.com",
                    "contacts": [{"email": "cto2@acme.com", "title": "CTO", "industry": "software", "employee_count": 80}],
                },
                "dry_run": True,
                "job_id": "api_job_2",
            },
        )
        response = self.client.delete("/schedule/api_job_2")
        self.assertEqual(200, response.status_code)
        self.assertTrue(response.json()["ok"])

    def test_post_schedule_run_returns_result(self) -> None:
        """POST /schedule/{job_id}/run should execute and return WorkflowResult JSON."""
        self.client.post(
            "/schedule",
            json={
                "usecase_id": "outreach_sdr",
                "cron": "0 9 * * 1-5",
                "inputs": {
                    "company": "Acme",
                    "domain": "acme.com",
                    "contacts": [{"email": "vp@acme.com", "title": "VP", "industry": "software", "employee_count": 80}],
                },
                "dry_run": True,
                "job_id": "api_job_3",
            },
        )
        response = self.client.post("/schedule/api_job_3/run")
        self.assertEqual(200, response.status_code)
        body = response.json()
        self.assertEqual("outreach_sdr", body["usecase_id"])
        self.assertIn("steps_run", body)


if __name__ == "__main__":
    unittest.main()
