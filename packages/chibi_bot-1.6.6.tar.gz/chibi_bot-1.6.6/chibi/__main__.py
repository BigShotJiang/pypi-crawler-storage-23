from chibi.runners.telegram import run_chibi

if __name__ == "__main__":
    run_chibi()
