"""Models."""

from .command_result import ExecuteResult

__all__ = ["ExecuteResult"]
