import yt_dlp
import os
import sys
import time
import requests
import tempfile
import atexit
from colorama import Fore, Style, init
import pyfiglet
from . import cookies

try:
    from cfonts import render
    CFONTS_AVAILABLE = True
except ImportError:
    CFONTS_AVAILABLE = False

init(autoreset=True)

# Colors
C_PRIMARY = Fore.LIGHTRED_EX
C_SECONDARY = Fore.LIGHTCYAN_EX
C_SUCCESS = Fore.LIGHTGREEN_EX
C_WARN = Fore.LIGHTYELLOW_EX
C_ERROR = Fore.LIGHTRED_EX
C_INFO = Fore.LIGHTMAGENTA_EX
C_BORDER = Fore.LIGHTRED_EX
C_RESET = Style.RESET_ALL

_temp_files = []

def cleanup_temp_files():
    for f in _temp_files:
        try:
            os.unlink(f)
        except:
            pass

atexit.register(cleanup_temp_files)

def print_separator(char='═', color=C_BORDER, length=60):
    print(color + char * length + C_RESET)

def print_centered(text, color=C_PRIMARY, width=60):
    print(color + text.center(width) + C_RESET)

def print_header(title, color=C_PRIMARY):
    print_separator('═', color)
    print_centered(f'🔥 {title} 🔥', color)
    print_separator('═', color)

def print_info_box(title, items, border_color=C_BORDER, text_color=Fore.WHITE):
    max_key_len = max(len(str(k)) for k, _ in items) if items else 0
    print(border_color + '┌' + '─' * 58 + '┐' + C_RESET)
    print(border_color + '│' + C_RESET + f' {title}'.ljust(57) + border_color + '│' + C_RESET)
    print(border_color + '├' + '─' * 58 + '┤' + C_RESET)
    for key, value in items:
        line = f'  {key}:'.ljust(max_key_len + 3) + str(value)
        print(border_color + '│' + C_RESET + f' {line}'.ljust(57) + border_color + '│' + C_RESET)
    print(border_color + '└' + '─' * 58 + '┘' + C_RESET)

def print_status(message, status='info'):
    emoji_map = {
        'info': 'ℹ️',
        'success': '✅',
        'warning': '⚠️',
        'error': '❌',
        'download': '📥',
        'processing': '🔄'
    }
    color_map = {
        'info': C_INFO,
        'success': C_SUCCESS,
        'warning': C_WARN,
        'error': C_ERROR,
        'download': C_SECONDARY,
        'processing': C_SECONDARY
    }
    emoji = emoji_map.get(status, '•')
    color = color_map.get(status, Fore.WHITE)
    print(f"{color}  {emoji} {message}{C_RESET}")

def print_credit():
    print(f"{C_SECONDARY}  🔥 CREDIT:{C_RESET} {Fore.LIGHTYELLOW_EX}t.me/DANGER_FF_LIKE{Style.RESET_ALL}")

def detect_platform(url):
    url_lower = url.lower()
    if 'tiktok.com' in url_lower:
        return 'tiktok'
    elif 'instagram.com' in url_lower:
        if '/stories/' in url_lower:
            return 'instagram_story'
        elif '/reel/' in url_lower or '/p/' in url_lower:
            return 'instagram_post'
        else:
            return 'instagram'
    elif 'youtube.com' in url_lower or 'youtu.be' in url_lower:
        if '/shorts/' in url_lower:
            return 'youtube_shorts'
        else:
            return 'youtube'
    elif 'facebook.com' in url_lower or 'fb.watch' in url_lower or 'fb.com' in url_lower:
        return 'facebook'
    else:
        return 'unknown'

def resolve_tiktok_url(url):
    try:
        if "vt.tiktok.com" in url or "vm.tiktok.com" in url:
            print_status("Converting TikTok short link...", 'info')
            response = requests.head(url, allow_redirects=True, timeout=10)
            return response.url
    except Exception as e:
        print_status(f"Link resolution failed: {str(e)}", 'error')
    return url

def progress_hook(d):
    if d['status'] == 'downloading':
        try:
            p = d.get('_percent_str', '0%').replace('%','')
            progress = float(p)
            bar_length = 30
            filled_length = int(bar_length * progress // 100)
            bar = '█' * filled_length + '░' * (bar_length - filled_length)
            sys.stdout.write(f"\r{C_SECONDARY}  📥 DOWNLOADING {C_RESET}|{C_PRIMARY}{bar}{C_RESET}| {int(progress)}% ")
            sys.stdout.flush()
        except:
            pass
    elif d['status'] == 'finished':
        print(f"\n{C_SUCCESS}  ✅ Download complete.{C_RESET}")

def get_cookies_file(platform, user_cookies_file):
    if user_cookies_file and os.path.isfile(user_cookies_file):
        return user_cookies_file
    cookie_data = cookies.EMBEDDED_COOKIES.get(platform)
    if cookie_data:
        tmp = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt')
        tmp.write(cookie_data)
        tmp.close()
        _temp_files.append(tmp.name)
        return tmp.name
    return None

def download_tiktok(url, download_dir, cookies_file=None):
    print_status("Processing TikTok video...", 'processing')
    full_url = resolve_tiktok_url(url)
    subfolder = 'TikTok'
    target_dir = os.path.join(download_dir, subfolder)
    os.makedirs(target_dir, exist_ok=True)

    ydl_opts = {
        'format': 'best',
        'outtmpl': os.path.join(target_dir, '%(uploader)s - %(title)s.%(ext)s'),
        'noplaylist': True,
        'quiet': True,
        'no_warnings': True,
        'ignoreerrors': True,
        'nocheckcertificate': True,
        'http_headers': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        },
        'progress_hooks': [progress_hook],
    }
    if cookies_file:
        ydl_opts['cookiefile'] = cookies_file

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(full_url, download=False)
            if not info:
                print_status("Video not found.", 'error')
                return False

            video_title = info.get('title', 'Unknown')[:40]
            uploader = info.get('uploader', 'Unknown')
            items = [
                ('📌 Title', video_title),
                ('👤 User', f'@{uploader}'),
                ('💾 Folder', subfolder)
            ]
            print_info_box('TIKTOK VIDEO', items, border_color=C_PRIMARY)
            ydl.download([full_url])
            print_status(f"Saved to: {target_dir}", 'success')
            return True
    except Exception as e:
        print_status(f"TikTok error: {str(e)}", 'error')
        return False

def download_instagram(url, download_dir, cookies_file=None, story_mode=False):
    content_type = "STORY" if story_mode else "POST/REEL"
    print_status(f"Processing Instagram {content_type}...", 'processing')
    subfolder = 'Stories' if story_mode else 'Instagram'
    target_dir = os.path.join(download_dir, subfolder)
    os.makedirs(target_dir, exist_ok=True)

    ydl_opts = {
        'format': 'best',
        'outtmpl': os.path.join(target_dir, '%(uploader)s - %(title)s.%(ext)s'),
        'noplaylist': True,
        'quiet': True,
        'no_warnings': True,
        'ignoreerrors': True,
        'nocheckcertificate': True,
        'http_headers': {
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1',
        },
        'progress_hooks': [progress_hook],
    }
    if cookies_file:
        ydl_opts['cookiefile'] = cookies_file

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if not info:
                print_status("Instagram content not found.", 'error')
                return False

            title = info.get('title', 'Unknown')[:40]
            uploader = info.get('uploader', 'Unknown')
            items = [
                ('📌 Title', title),
                ('👤 User', f'@{uploader}'),
                ('💾 Folder', subfolder)
            ]
            print_info_box(f'INSTAGRAM {content_type}', items, border_color=C_PRIMARY)
            ydl.download([url])
            print_status(f"Saved to: {target_dir}", 'success')
            return True
    except Exception as e:
        print_status(f"Instagram error: {str(e)}", 'error')
        return False

def download_youtube(url, download_dir, cookies_file=None, shorts_mode=False):
    content_type = "SHORTS" if shorts_mode else "VIDEO"
    print_status(f"Processing YouTube {content_type}...", 'processing')
    subfolder = 'YouTube'
    target_dir = os.path.join(download_dir, subfolder)
    os.makedirs(target_dir, exist_ok=True)

    ydl_opts = {
        'outtmpl': os.path.join(target_dir, '%(uploader)s - %(title)s.%(ext)s'),
        'noplaylist': True,
        'quiet': True,
        'no_warnings': True,
        'ignoreerrors': True,
        'nocheckcertificate': True,
        'progress_hooks': [progress_hook],
        'merge_output_format': 'mp4',
    }
    if cookies_file:
        ydl_opts['cookiefile'] = cookies_file

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if not info:
                print_status("YouTube video not found.", 'error')
                return False

            title = info.get('title', 'Unknown')[:40]
            uploader = info.get('uploader', 'Unknown')
            duration = info.get('duration', 0)
            duration_str = f"{duration//60}:{duration%60:02d}"
            items = [
                ('📌 Title', title),
                ('👤 Channel', uploader),
                ('⏱️ Duration', duration_str),
                ('💾 Folder', subfolder)
            ]
            print_info_box(f'YOUTUBE {content_type}', items, border_color=C_PRIMARY)
            ydl.download([url])
            print_status(f"Saved to: {target_dir}", 'success')
            return True
    except Exception as e:
        print_status(f"YouTube error: {str(e)}", 'error')
        return False

def download_facebook(url, download_dir, cookies_file=None):
    print_status("Processing Facebook video...", 'processing')
    subfolder = 'Facebook'
    target_dir = os.path.join(download_dir, subfolder)
    os.makedirs(target_dir, exist_ok=True)

    ydl_opts = {
        'format': 'best',
        'outtmpl': os.path.join(target_dir, '%(uploader)s - %(title)s.%(ext)s'),
        'noplaylist': True,
        'quiet': True,
        'no_warnings': True,
        'ignoreerrors': True,
        'nocheckcertificate': True,
        'http_headers': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        },
        'progress_hooks': [progress_hook],
    }
    if cookies_file:
        ydl_opts['cookiefile'] = cookies_file

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if not info:
                print_status("Facebook video not found.", 'error')
                return False

            title = info.get('title', 'Unknown')[:40]
            uploader = info.get('uploader', 'Unknown')
            items = [
                ('📌 Title', title),
                ('👤 User', uploader),
                ('💾 Folder', subfolder)
            ]
            print_info_box('FACEBOOK VIDEO', items, border_color=C_PRIMARY)
            ydl.download([url])
            print_status(f"Saved to: {target_dir}", 'success')
            return True
    except Exception as e:
        print_status(f"Facebook error: {str(e)}", 'error')
        return False

def auto_download(url, download_dir, user_cookies_file=None):
    if not url:
        print_status("No URL provided", 'warning')
        return False

    platform = detect_platform(url)
    print_status(f"Auto-detected: {platform.upper()}", 'info')
    print_credit()

    cookies_file = get_cookies_file(platform, user_cookies_file)

    if platform == 'tiktok':
        return download_tiktok(url, download_dir, cookies_file)
    elif platform == 'instagram':
        return download_instagram(url, download_dir, cookies_file)
    elif platform == 'instagram_story':
        return download_instagram(url, download_dir, cookies_file, story_mode=True)
    elif platform == 'instagram_post':
        return download_instagram(url, download_dir, cookies_file)
    elif platform == 'youtube':
        return download_youtube(url, download_dir, cookies_file)
    elif platform == 'youtube_shorts':
        return download_youtube(url, download_dir, cookies_file, shorts_mode=True)
    elif platform == 'facebook':
        return download_facebook(url, download_dir, cookies_file)
    else:
        print_status("Unsupported platform or invalid URL", 'error')
        print_status("Supported: TikTok, Instagram (posts/reels/stories), YouTube, Facebook", 'warning')
        return False