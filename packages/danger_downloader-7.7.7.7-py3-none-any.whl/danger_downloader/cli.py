#!/usr/bin/env python3
import argparse
import os
import sys
from .core import auto_download, print_credit, C_PRIMARY, C_RESET

def main():
    parser = argparse.ArgumentParser(
        description="DANGER Downloader – Auto‑download videos from TikTok, Instagram, YouTube, Facebook."
    )
    parser.add_argument('url', help='URL of the video/post/reel/story')
    parser.add_argument('folder', nargs='?', default=None,
                        help='Target folder (default: ./DANGER)')
    parser.add_argument('--cookies', '-c', default=None,
                        help='Path to Netscape format cookies file (overrides embedded cookies)')
    args = parser.parse_args()

    download_dir = os.path.abspath(args.folder) if args.folder else os.path.join(os.getcwd(), 'DANGER')
    os.makedirs(download_dir, exist_ok=True)

    print(f"{C_PRIMARY}╔════════════════════════════════════════════════╗{C_RESET}")
    print(f"{C_PRIMARY}║      🔥 DANGER DOWNLOADER (COMMAND LINE)     ║{C_RESET}")
    print(f"{C_PRIMARY}╚════════════════════════════════════════════════╝{C_RESET}")
    print_credit()
    print(f"📁 Download folder: {download_dir}")
    if args.cookies:
        print(f"🍪 Using user cookies: {args.cookies}")
    else:
        print(f"🍪 Using embedded cookies (if available)")
    print()

    success = auto_download(args.url, download_dir, args.cookies)
    sys.exit(0 if success else 1)

if __name__ == '__main__':
    main()