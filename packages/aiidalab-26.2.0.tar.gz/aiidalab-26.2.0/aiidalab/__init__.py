"""AiiDAlab core tools."""

from .config import _DEVELOP_MODE as DEVELOP_MODE

__all__ = ["DEVELOP_MODE"]

__version__ = "26.2.0"
