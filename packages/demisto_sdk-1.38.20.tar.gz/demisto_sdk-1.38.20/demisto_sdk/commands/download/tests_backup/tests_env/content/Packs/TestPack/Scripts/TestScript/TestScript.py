def main():
    print("Test Script")  # noqa: T201


if __name__ in ["__main__", "builtins"]:
    main()
