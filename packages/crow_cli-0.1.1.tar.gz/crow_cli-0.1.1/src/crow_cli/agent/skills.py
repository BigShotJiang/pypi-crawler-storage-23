"""
file:           skills.py
description:    a place for functions which
                1. configure skills
                2. analyze user context for keywords
                3. append context to user message


"""
