
# NB: setup.py parses this file manually and crudely, so be careful changing any syntax
__version__='1.0.14'
