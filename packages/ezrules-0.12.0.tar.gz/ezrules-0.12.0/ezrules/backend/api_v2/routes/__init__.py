"""API route handlers for FastAPI."""
