import sys

import pytest

if __name__ == "__main__":
    sys.exit(pytest.main([__file__.rsplit("/", 1)[0], "-v"]))
