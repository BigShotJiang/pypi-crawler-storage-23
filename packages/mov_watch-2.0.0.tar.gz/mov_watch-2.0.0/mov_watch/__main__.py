"""
Entry point for running mov-watch as a module
Usage: python -m mov_watch
"""
from mov_watch.app import main

if __name__ == "__main__":
    main()
