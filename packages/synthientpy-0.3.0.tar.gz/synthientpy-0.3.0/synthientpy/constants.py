"""Constants for the Synthient API."""

API_URL = "https://v3api.synthient.com/api/v3/"
FEEDS_URL = "https://feeds.synthient.com/v3/"
DEFAULT_TIMEOUT = 5
