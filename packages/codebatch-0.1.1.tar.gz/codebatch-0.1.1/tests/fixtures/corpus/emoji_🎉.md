# Party Time

This file has an emoji in its filename.

Testing UTF-8 with emojis in paths.
