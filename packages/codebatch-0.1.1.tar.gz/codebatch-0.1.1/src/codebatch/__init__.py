"""CodeBatch - Content-addressed batch execution engine."""

__version__ = "0.1.0"
