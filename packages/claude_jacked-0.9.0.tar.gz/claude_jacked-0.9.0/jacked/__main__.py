"""Allow running jacked via `python -m jacked`."""
from jacked.cli import main

main()
