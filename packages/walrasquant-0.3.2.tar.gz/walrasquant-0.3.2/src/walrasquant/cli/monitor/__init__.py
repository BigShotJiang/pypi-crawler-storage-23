"""Strategy monitoring utilities."""
