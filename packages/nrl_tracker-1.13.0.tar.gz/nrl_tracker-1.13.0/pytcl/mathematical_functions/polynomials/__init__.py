"""polynomials functions."""

__all__ = []
