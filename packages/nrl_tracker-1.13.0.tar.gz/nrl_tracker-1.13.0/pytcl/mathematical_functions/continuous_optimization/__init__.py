"""continuous_optimization functions."""

__all__ = []
