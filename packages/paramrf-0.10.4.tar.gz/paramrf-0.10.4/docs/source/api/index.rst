API Reference
=============

Core API
--------

.. autosummary::
   :toctree: generated/

   pmrf.Model
   pmrf.Parameter
   pmrf.Frequency
   pmrf.load
   pmrf.save
   pmrf.extract_features

Modules
-------

.. autosummary::
   :toctree: generated/
   :recursive:

   pmrf.algorithms
   pmrf.constants
   pmrf.distributions
   pmrf.fitting
   pmrf.math_functions
   pmrf.models
   pmrf.parameters
   pmrf.results
   pmrf.rf_functions
   pmrf.runner
   pmrf.sampling