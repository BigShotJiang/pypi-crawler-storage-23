


transformed
===========

.. automodule:: pmrf.models.composite.transformed
   :no-members:
   :no-inherited-members:







.. rubric:: Classes

.. autosummary::
   :toctree:
   :template: autosummary/class.rst


   Flipped
   Renumbered
   Stacked





