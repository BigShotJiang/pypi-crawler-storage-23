"""
The index.html file has been uploaded to 'danialcalayt' >
yta_resources > otros > web_resources > discord_message_image'
"""
from yta_web_resources import _WebResource
from yta_general_utils.url.dataclasses import UrlParameters, UrlParameter
from typing import Union


class _DiscordMessageImageWebResource(_WebResource):
    """
    *For internal use only*

    Web resource to create a Discord message and download
    it as an image.

    This is associated with the `web.discord.index.html`
    resource.
    """

    _element_id: str = 'discord-message'

    # TODO: I should limitate it to a specific width (?)
    def get_frame(
        self,
        username: str = 'Usuario',
        avatar_url: str = 'https://static.vecteezy.com/system/resources/previews/023/741/147/non_2x/discord-logo-icon-social-media-icon-free-png.png',
        message: str = 'Texto de mensaje de prueba',
        do_include_alpha: bool = True,
        output_filename: Union[str, None] = None
    ):
        parameters = UrlParameters([
            UrlParameter('username', username),
            UrlParameter('avatar_url', avatar_url),
            UrlParameter('message', message),
        ])

        return self._get_frame(
            parameters = parameters,
            do_include_alpha = do_include_alpha,
            output_filename = output_filename
        )

# Instances to export here below
DiscordMessageImageWebResource = lambda do_use_local_url = True, do_use_gui = False: _DiscordMessageImageWebResource(
    local_path = 'src/yta_web_resources/web/discord/index.html',
    google_drive_direct_download_url = 'https://drive.google.com/file/d/1JG3O5I6lTYpd5iebqdnd6fLpIB1WcFCQ/view?usp=sharing',
    do_use_local_url = do_use_local_url,
    do_use_gui = do_use_gui
)