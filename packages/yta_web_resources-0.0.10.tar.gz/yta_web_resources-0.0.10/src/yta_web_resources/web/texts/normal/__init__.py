"""
The index.html file has been uploaded to 'danialcalayt >
yta_resources > otros > web_resources > texts > normal'
"""
from yta_web_resources import _WebResource


class _TextNormalQuizzWebResource(_WebResource):
    """
    *For internal use only*

    Web resource to create a quizz and download the
    different elements.

    This is associated with the next file:
    - `web.texts.normal.index.html`
    """

    _element_id: str = 'capture'

    # TODO: Add 'color' to be more customizable

# Instances to export here below
TextNormalQuizzWebResource = lambda do_use_local_url = True, do_use_gui = False: _TextNormalQuizzWebResource(
    local_path = 'src/yta_web_resources/web/text/normal/index.html',
    google_drive_direct_download_url = 'https://drive.google.com/file/d/1rpp1ravsHeYFQeOPHQmODH44Ze6nDwx7/view?usp=sharing',
    do_use_local_url = do_use_local_url,
    do_use_gui = do_use_gui
)