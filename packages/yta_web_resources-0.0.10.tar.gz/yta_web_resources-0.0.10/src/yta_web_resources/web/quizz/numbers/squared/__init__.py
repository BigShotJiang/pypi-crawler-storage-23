"""
The index.html file has been uploaded to 'danialcalayt >
yta_resources > otros > web_resources > quizz > numbers >
squared'
"""
from yta_web_resources import _WebResource
from yta_general_utils.url.dataclasses import UrlParameters, UrlParameter
from typing import Union


class _NumberSquaredQuizzWebResource(_WebResource):
    """
    *For internal use only*

    Web resource to create a quizz and download the
    different elements.

    This is associated with the next file:
    - `web.quizz.numbers.squared.index.html`
    """

    _element_id: str = 'capture'

    def get_frame(
        self,
        number: str,
        do_include_alpha: bool = True,
        output_filename: Union[str, None] = None
    ) -> Union[str, bytes]:
        parameters = UrlParameters([
            UrlParameter('n', number)
        ])

        return self._get_frame(
            parameters = parameters,
            do_include_alpha = do_include_alpha,
            output_filename = output_filename
        )
    
    # TODO: Add 'color' to be more customizable

# Instances to export here below
NumberSquaredQuizzWebResource = lambda do_use_local_url = True, do_use_gui = False: _NumberSquaredQuizzWebResource(
    local_path = 'src/yta_web_resources/web/quizz/numbers/squared/index.html',
    google_drive_direct_download_url = 'https://drive.google.com/file/d/1Mfry0uaA0yz4UmDWfcvSSrGUC4w-Yrbx/view?usp=sharing',
    do_use_local_url = do_use_local_url,
    do_use_gui = do_use_gui
)