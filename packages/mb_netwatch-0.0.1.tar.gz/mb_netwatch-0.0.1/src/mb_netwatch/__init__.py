"""mb-netwatch — macOS internet connection monitor."""
