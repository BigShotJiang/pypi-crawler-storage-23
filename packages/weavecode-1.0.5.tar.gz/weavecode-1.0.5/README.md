# weavecode

Local JSONL logging and terminal UI for [Weights & Biases Weave](https://wandb.ai/site/weave) traces — with git snapshotting so you can replay exactly what code ran at each trace.

## Install

```bash
pip install weavecode
```

## Usage

```python
import weave
import weavecode

# 1. Init weave as normal, then wrap with weavecode
client = weave.init("my-project")
weavecode.init(client, git_path="/path/to/your/repo")

# 2. Decorate functions you want to trace
@weave.op
def my_function(prompt: str) -> str:
    ...

# 3. Run your code
my_function("hello")
```

Every call is logged locally to `~/.cache/codeweave/<project>/` as a JSONL file, with a git snapshot of your repo at the time of the run.

## View traces

```bash
weavecode
# or pass a project name directly:
weavecode my-project
```

This opens a terminal UI with:

- **Runs list** — all logged runs for the selected project, with 📸 if a git snapshot exists
- **Call tree** — the full trace tree for the selected run
- **Source viewer** — the exact source code at snapshot time, with the traced function and callsite highlighted
- **Detail panel** — inputs, outputs, errors, git info, and a clickable W&B link

### Keybindings

| Key | Action |
|-----|--------|
| `p` | Pick project (modal list) |
| `r` | Back to runs list |
| `1` / `2` | Focus runs / calls panel |
| `c` | Copy trace to clipboard |
| `o` | Open trace in W&B browser |
| `j` | Jump to callsite in VS Code |
| `q` | Quit |

## Git snapshotting

When you pass `git_path`, weavecode commits a snapshot of your repo at the start of each run (stashing any dirty changes first). The snapshot SHA is stored in each log entry. The source viewer uses `git show <sha>:<file>` to display the code — it never modifies your working tree.

## Requirements

- Python >= 3.8
- `textual >= 0.50.0`
- `weave` (Weights & Biases)
