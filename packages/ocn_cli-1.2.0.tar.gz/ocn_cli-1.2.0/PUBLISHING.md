# Publishing OCN CLI to PyPI

This guide explains how to publish the OCN CLI package to PyPI (Python Package Index) using GitHub Actions.

---

## Prerequisites

Before you can publish, you need:

1. ✅ **GitHub Repository** - OCN repository with the CLI code
2. ✅ **PyPI Account** - Account on https://pypi.org
3. ✅ **Test PyPI Account** - Account on https://test.pypi.org (for testing)
4. ✅ **GitHub Permissions** - Admin access to repository settings

---

## Initial Setup (One-Time)

### Step 1: Create PyPI Accounts

1. **Production PyPI:**
   - Go to https://pypi.org/account/register/
   - Create an account
   - Verify your email

2. **Test PyPI (for testing releases):**
   - Go to https://test.pypi.org/account/register/
   - Create an account (separate from production)
   - Verify your email

### Step 2: Set Up Trusted Publishing (Recommended)

Trusted Publishing is the secure, token-free way to publish from GitHub Actions.

#### On PyPI (Production):

1. Log in to https://pypi.org
2. Go to your account settings
3. Navigate to **Publishing** section
4. Click **Add a new pending publisher**
5. Fill in the form:
   - **PyPI Project Name**: `ocn-cli`
   - **Owner**: `your-org` (your GitHub username or organization)
   - **Repository name**: `ocn`
   - **Workflow name**: `publish-ocn-cli.yml`
   - **Environment name**: `pypi`
6. Click **Add**

#### On Test PyPI:

1. Log in to https://test.pypi.org
2. Repeat the same process with:
   - **Environment name**: `test-pypi`

### Step 3: Configure GitHub Environments

1. Go to your GitHub repository
2. Navigate to **Settings** → **Environments**
3. Create two environments:

#### Environment: `pypi`
- Click **New environment**
- Name: `pypi`
- (Optional) Add protection rules:
  - Required reviewers (recommended for production)
  - Deployment branches: only `main`
- Save

#### Environment: `test-pypi`
- Click **New environment**
- Name: `test-pypi`
- Save

---

## Alternative: API Token Method (If Not Using Trusted Publishing)

If you prefer API tokens instead of trusted publishing:

### Create PyPI API Token

1. Log in to https://pypi.org
2. Go to **Account settings** → **API tokens**
3. Click **Add API token**
4. Name: `github-actions-ocn-cli`
5. Scope: **Project** → Select `ocn-cli` (after first manual upload)
6. Copy the token (starts with `pypi-`)

### Add Token to GitHub Secrets

1. Go to GitHub repository → **Settings** → **Secrets and variables** → **Actions**
2. Click **New repository secret**
3. Name: `PYPI_API_TOKEN`
4. Value: Paste the PyPI token
5. Click **Add secret**

Repeat for Test PyPI with secret name `TEST_PYPI_API_TOKEN`.

### Modify Workflow for Token Auth

If using tokens instead of trusted publishing, update `.github/workflows/publish-ocn-cli.yml`:

```yaml
# In publish-pypi job, replace:
permissions:
  id-token: write

# With:
# (no permissions block needed)

# And in the publish step, add:
- name: Publish to PyPI
  uses: pypa/gh-action-pypi-publish@release/v1
  with:
    password: ${{ secrets.PYPI_API_TOKEN }}  # Add this line
```

---

## Publishing Workflow

### Option 1: Automatic Release (Recommended)

When you create a GitHub release, the package is automatically published to PyPI.

**Steps:**

1. **Update Version Number**
   ```bash
   cd cli
   # Edit ocn_cli/version.py
   __version__ = "1.1.0"  # Increment version
   ```

2. **Update CHANGELOG**
   ```bash
   # Edit CHANGELOG.md
   # Add entry for new version
   ```

3. **Commit Changes**
   ```bash
   git add cli/ocn_cli/version.py cli/CHANGELOG.md
   git commit -m "Bump OCN CLI version to 1.1.0"
   git push origin main
   ```

4. **Create GitHub Release**
   - Go to GitHub repository
   - Click **Releases** → **Create a new release**
   - Click **Choose a tag** → Create new tag: `cli-v1.1.0`
   - Release title: `OCN CLI v1.1.0`
   - Description: Copy from CHANGELOG.md
   - Click **Publish release**

5. **Automatic Publishing**
   - GitHub Actions automatically triggers
   - Runs tests on Python 3.9, 3.10, 3.11, 3.12
   - Builds the package
   - Publishes to PyPI
   - Uploads wheels to GitHub release

6. **Verify Publication**
   - Check https://pypi.org/project/ocn-cli/
   - Test install: `pip install ocn-cli==1.1.0`

### Option 2: Manual Trigger (Test PyPI)

For testing the publishing workflow:

1. **Go to Actions Tab**
   - Navigate to GitHub repository → **Actions**
   - Click on **Publish OCN CLI to PyPI** workflow

2. **Run Workflow**
   - Click **Run workflow**
   - Select branch: `main`
   - Check **Publish to Test PyPI**: `true`
   - Click **Run workflow**

3. **Monitor Progress**
   - Watch the workflow run
   - Check for any errors

4. **Test Installation from Test PyPI**
   ```bash
   pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ ocn-cli
   ```
   
   Note: `--extra-index-url` is needed because dependencies are on production PyPI

### Option 3: Local Build and Upload (Manual)

For testing or emergency releases:

```bash
cd cli

# Install build tools
pip install build twine

# Build package
python -m build

# Check package
twine check dist/*

# Upload to Test PyPI (test first!)
twine upload --repository testpypi dist/*

# Upload to Production PyPI
twine upload dist/*
```

---

## Version Numbering

Follow Semantic Versioning (semver):

- **Major** (1.0.0 → 2.0.0): Breaking changes
- **Minor** (1.0.0 → 1.1.0): New features, backward compatible
- **Patch** (1.0.0 → 1.0.1): Bug fixes, backward compatible

**Examples:**
- `1.0.0` - Initial release
- `1.1.0` - Added diagnostics feature
- `1.1.1` - Bug fix in diagnostics
- `2.0.0` - Breaking API changes

---

## Workflow Triggers

The workflow runs on:

1. **Release Published** (automatic)
   - Publishes to production PyPI
   - Uploads to GitHub release assets
   - Creates release notes

2. **Manual Trigger** (workflow_dispatch)
   - Can choose Test PyPI or Production PyPI
   - Useful for testing or emergency releases

---

## First-Time Publishing Checklist

Before your first publish:

- [ ] Package name `ocn-cli` is available on PyPI (check https://pypi.org/project/ocn-cli/)
- [ ] Version in `ocn_cli/version.py` is set correctly (e.g., `1.0.0`)
- [ ] `pyproject.toml` has correct metadata (name, description, author, license, URLs)
- [ ] `README.md` is complete and accurate
- [ ] `CHANGELOG.md` has entry for the version
- [ ] `LICENSE` file exists
- [ ] All dependencies are listed in `pyproject.toml`
- [ ] Trusted publishing is configured on PyPI (or API token added to GitHub secrets)
- [ ] GitHub environments created (`pypi`, `test-pypi`)

---

## Testing Before Publishing

Always test before publishing to production:

### 1. Local Installation Test
```bash
cd cli
pip install -e .
ocn-cli --version
ocn-cli --help
```

### 2. Build Test
```bash
cd cli
python -m build
ls -lh dist/
```

### 3. Test PyPI Upload
```bash
# Upload to Test PyPI first
twine upload --repository testpypi dist/*

# Test installation from Test PyPI
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ ocn-cli

# Verify it works
ocn-cli --version
```

### 4. Production Upload
Only after successful Test PyPI verification:
```bash
twine upload dist/*
```

---

## Troubleshooting

### "Package name already exists"

If `ocn-cli` is already taken on PyPI:
1. Choose a different name (e.g., `ocn-diagnostic-cli`)
2. Update `pyproject.toml` → `name = "ocn-diagnostic-cli"`
3. Update README and documentation

### "Authentication failed"

For Trusted Publishing:
- Verify publisher is configured on PyPI
- Check environment name matches (`pypi` or `test-pypi`)
- Ensure workflow is running from the configured repository

For API Tokens:
- Verify token is added to GitHub secrets
- Check token hasn't expired
- Ensure token has correct scope (project-level)

### "Version already exists"

You cannot overwrite a version on PyPI:
1. Increment version number in `ocn_cli/version.py`
2. Commit and push changes
3. Create new release with new version

### "Build failed"

Check the workflow logs for specific errors:
- Syntax errors in Python files
- Missing dependencies in `pyproject.toml`
- Invalid package structure

### "Tests failed"

Fix test failures before publishing:
```bash
cd cli
pytest
```

---

## Security Best Practices

### Secrets Management

- ✅ **Use Trusted Publishing** (no tokens needed, most secure)
- ✅ **Never commit tokens** to the repository
- ✅ **Use environment protection** for production PyPI
- ✅ **Require approvals** for production releases
- ✅ **Rotate tokens** regularly if using API tokens

### Release Process

- ✅ **Always test on Test PyPI first**
- ✅ **Run full test suite** before publishing
- ✅ **Review changes** before creating release
- ✅ **Use semantic versioning** consistently
- ✅ **Tag releases** properly (e.g., `cli-v1.0.0`)

---

## Continuous Deployment Pipeline

```mermaid
graph LR
    A[Code Changes] --> B[Commit to main]
    B --> C[Update version.py]
    C --> D[Update CHANGELOG.md]
    D --> E[Create Git Tag]
    E --> F[Create GitHub Release]
    F --> G[GitHub Action Triggers]
    G --> H[Run Tests]
    H --> I{Tests Pass?}
    I -->|Yes| J[Build Package]
    I -->|No| K[Fail - Fix Tests]
    J --> L[Publish to PyPI]
    L --> M[Upload to GitHub Release]
    M --> N[Users: pip install ocn-cli]
```

---

## Manual Release Process

If you prefer manual releases without GitHub Actions:

### 1. Prepare Release

```bash
# Update version
cd cli
vim ocn_cli/version.py  # Change __version__

# Update changelog
vim CHANGELOG.md

# Commit
git add ocn_cli/version.py CHANGELOG.md
git commit -m "Release v1.1.0"
git tag cli-v1.1.0
git push origin main --tags
```

### 2. Build Package

```bash
cd cli

# Clean old builds
rm -rf dist/ build/ *.egg-info

# Build
python -m build
```

### 3. Upload to PyPI

```bash
# Test PyPI first
twine upload --repository testpypi dist/*

# Verify on Test PyPI
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ ocn-cli

# Production PyPI
twine upload dist/*
```

---

## Post-Publication

After successful publication:

1. **Verify Installation**
   ```bash
   pip install ocn-cli
   ocn-cli --version
   ```

2. **Update Documentation**
   - Announce on team channels
   - Update installation instructions if needed
   - Create upgrade guide if breaking changes

3. **Monitor Issues**
   - Watch for GitHub issues
   - Monitor PyPI download stats
   - Address any installation problems quickly

---

## Quick Reference

### Publish Checklist

- [ ] Update `ocn_cli/version.py`
- [ ] Update `CHANGELOG.md`
- [ ] Run tests locally
- [ ] Commit and push changes
- [ ] Create GitHub release with tag `cli-vX.Y.Z`
- [ ] Monitor GitHub Actions workflow
- [ ] Verify package on PyPI
- [ ] Test installation: `pip install ocn-cli`
- [ ] Announce release

### Common Commands

```bash
# Build package
cd cli && python -m build

# Check package
twine check dist/*

# Upload to Test PyPI
twine upload --repository testpypi dist/*

# Upload to PyPI
twine upload dist/*

# Install from Test PyPI
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ ocn-cli

# Install from PyPI
pip install ocn-cli
```

---

## Support

For issues with publishing:

- GitHub Actions logs: Check workflow run for detailed error messages
- PyPI status: https://status.python.org/
- Test PyPI: Use for all testing, never test on production PyPI
- Community help: https://github.com/pypa/packaging-problems/discussions

---

## See Also

- [Python Packaging Guide](https://packaging.python.org/)
- [PyPI Trusted Publishing](https://docs.pypi.org/trusted-publishers/)
- [GitHub Actions Documentation](https://docs.github.com/en/actions)
- [Semantic Versioning](https://semver.org/)

