# OCN CLI Resources

This directory is reserved for future embedded resources.

## SSH Keys

OCN CLI uses SSH key-based authentication. Users must provide their own SSH private key via the `--key` argument.

## Generating SSH Keys

To generate a new SSH keypair for use with OCN CLI:

```bash
# Generate RSA key (2048-bit or higher recommended)
ssh-keygen -t rsa -b 4096 -f ~/.ssh/ocn_key -C "OCN CLI Key"

# Or generate Ed25519 key (more modern, more secure)
ssh-keygen -t ed25519 -f ~/.ssh/ocn_key -C "OCN CLI Key"

# Set secure permissions
chmod 600 ~/.ssh/ocn_key
chmod 644 ~/.ssh/ocn_key.pub
```

## Authorizing Keys on OCN Server

Add the public key to the OCN server's authorized keys:

```bash
# Copy public key to OCN server
ssh-copy-id -i ~/.ssh/ocn_key.pub user@ocn-server.local

# Or manually:
cat ~/.ssh/ocn_key.pub | ssh user@ocn-server.local "mkdir -p ~/.ssh && cat >> ~/.ssh/authorized_keys"
```

## Security Best Practices

- Always use key-based authentication (never passwords)
- Keep private keys secure with proper file permissions (600)
- Use strong key types (RSA 4096-bit or Ed25519)
- Consider using passphrase-protected keys for additional security
- Rotate keys regularly
- Use different keys for different servers/environments

