"""Entry point for running OCN CLI as a module (python -m ocn_cli)."""

from ocn_cli.cli import app

if __name__ == "__main__":
    app()

