"""Base interface for helper commands."""

from typing import List, Protocol

from ocn_cli.ssh.command_executor import CommandExecutor


class HelperCommand(Protocol):
    """Protocol defining the interface for helper commands."""
    
    @property
    def name(self) -> str:
        """
        Command name.
        
        Returns:
            str: Command name
        """
        ...
    
    @property
    def description(self) -> str:
        """
        Command description.
        
        Returns:
            str: Brief description of what the command does
        """
        ...
    
    @property
    def aliases(self) -> List[str]:
        """
        Command aliases.
        
        Returns:
            List[str]: List of alternative names for this command
        """
        ...
    
    def execute(self, executor: CommandExecutor, args: List[str]) -> str:
        """
        Execute the command.
        
        Args:
            executor: Command executor for running remote commands
            args: Command arguments
            
        Returns:
            str: Command output to display
        """
        ...


