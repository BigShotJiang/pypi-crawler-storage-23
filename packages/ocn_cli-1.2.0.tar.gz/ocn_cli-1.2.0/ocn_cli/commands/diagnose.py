"""Diagnose command implementation."""

import asyncio
import shlex
from typing import List, Optional

from rich.progress import Progress, SpinnerColumn, TextColumn

from ocn_cli.diagnostics.formatter import get_formatter
from ocn_cli.diagnostics.runner import DiagnosticRunner
from ocn_cli.ssh.command_executor import CommandExecutor
from ocn_cli.ui.formatters import console, format_error


class DiagnoseCommand:
    """Run comprehensive OCN server diagnostics."""
    
    @property
    def name(self) -> str:
        """Command name."""
        return "diagnose"
    
    @property
    def description(self) -> str:
        """Command description."""
        return "Run comprehensive OCN server diagnostics"
    
    @property
    def aliases(self) -> List[str]:
        """Command aliases."""
        return ["diag", "check"]
    
    def execute(self, executor: CommandExecutor, args: List[str]) -> str:
        """
        Execute the diagnose command.
        
        Args:
            executor: Command executor for running remote commands
            args: Command arguments
            
        Returns:
            str: Diagnostic report
        """
        # Parse arguments
        opts: dict = self._parse_args(args)
        
        if opts.get("help"):
            return self._show_help()
        
        # Create diagnostic runner
        runner: DiagnosticRunner = DiagnosticRunner(executor)
        runner.register_all_checks()
        
        # Apply filters
        if opts.get("quick"):
            runner.filter_checks(quick_mode=True)
        elif opts.get("category"):
            runner.filter_checks(categories=[opts["category"]])
        elif opts.get("check"):
            runner.filter_checks(check_names=[opts["check"]])
        
        # Get hostname first
        hostname: str = asyncio.run(runner.get_hostname())
        
        # Run diagnostics with progress indicator
        try:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
                transient=True,
            ) as progress:
                task = progress.add_task(
                    f"Running {len(runner.checks)} diagnostic checks...",
                    total=None
                )
                
                results = asyncio.run(runner.run_all(parallel=True))
                progress.update(task, completed=True)
        
        except KeyboardInterrupt:
            console.print("\n[yellow]Diagnostics interrupted. Showing partial results...[/yellow]\n")
            results = runner.results
        
        # Get summary and categories
        summary = runner.get_summary()
        summary.server_hostname = hostname
        categories = runner.get_results_by_category()
        
        # Format results
        format_type: str = opts.get("format", "text")
        formatter = get_formatter(format_type)
        
        # Output to file if requested
        if opts.get("output"):
            # Get string report for file output
            if format_type == "text":
                # Use plain text version for file
                report: str = formatter.format_to_file(summary, results, categories)  # type: ignore
            else:
                report = formatter.format(summary, results, categories)
            
            try:
                with open(opts["output"], 'w') as f:
                    f.write(report)
                console.print(f"[green]✅ Report saved to {opts['output']}[/green]\n")
                return ""
            except Exception as e:
                format_error(f"Could not save report: {e}")
                return ""
        
        # For console output
        if format_type == "text":
            # Print directly with Rich formatting
            formatter.format(summary, results, categories)
            return ""
        else:
            # Return string for JSON/HTML
            report = formatter.format(summary, results, categories)
            return report
    
    def _parse_args(self, args: List[str]) -> dict:
        """
        Parse command arguments.
        
        Args:
            args: Command arguments
            
        Returns:
            dict: Parsed options
        """
        opts: dict = {}
        i: int = 0
        
        while i < len(args):
            arg: str = args[i]
            
            if arg in ("--help", "-h"):
                opts["help"] = True
            elif arg == "--quick":
                opts["quick"] = True
            elif arg == "--verbose":
                opts["verbose"] = True
            elif arg == "--category" and i + 1 < len(args):
                opts["category"] = args[i + 1]
                i += 1
            elif arg == "--check" and i + 1 < len(args):
                opts["check"] = args[i + 1]
                i += 1
            elif arg == "--output" and i + 1 < len(args):
                opts["output"] = args[i + 1]
                i += 1
            elif arg == "--format" and i + 1 < len(args):
                opts["format"] = args[i + 1]
                i += 1
            
            i += 1
        
        return opts
    
    def _show_help(self) -> str:
        """Show help for diagnose command."""
        help_text: str = """
[bold cyan]diagnose[/bold cyan] - Run OCN server diagnostics

[bold]Usage:[/bold]
  diagnose [options]

[bold]Options:[/bold]
  --quick               Run only critical checks (faster)
  --category <name>     Run checks from specific category
                        (network, docker, resources, services)
  --check <name>        Run a specific check by name
  --verbose            Show detailed output
  --output <file>      Save report to file
  --format <type>      Output format: text, json, html (default: text)
  --help               Show this help message

[bold]Examples:[/bold]
  diagnose                                 # Run all diagnostics
  diagnose --quick                         # Run critical checks only
  diagnose --category docker               # Check Docker only
  diagnose --output report.html --format html  # Save HTML report
  
[bold]Categories:[/bold]
  • network    - Internet, DNS, keygen.sh connectivity
  • docker     - Docker installation and containers
  • resources  - CPU, memory, disk usage
  • services   - Docker daemon, nginx, firewall

[bold]Common Checks:[/bold]
  • internet_connectivity  - Test internet access
  • dns_resolution        - Test DNS resolution
  • docker_installation   - Validate Docker source
  • container_status      - Check container health
  • dpkg_lock            - Check for package locks
  • cpu_usage            - Check CPU usage
  • memory_usage         - Check RAM and swap
  • disk_space           - Check disk usage
  • docker_daemon        - Check Docker service
  • nginx_service        - Check nginx status
"""
        return help_text


# Create instance for registration
diagnose_command = DiagnoseCommand()

