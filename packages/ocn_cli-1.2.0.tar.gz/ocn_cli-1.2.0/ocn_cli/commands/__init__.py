"""Helper commands module for OCN CLI."""

from ocn_cli.commands.base import HelperCommand
from ocn_cli.commands.registry import CommandRegistry
from ocn_cli.commands.help import HelpCommand
from ocn_cli.commands.status import StatusCommand
from ocn_cli.commands.diagnose import DiagnoseCommand
from ocn_cli.commands.offline_update import OfflineUpdateCommand
from ocn_cli.commands.onboard import OnboardCommand

# Create global command registry
command_registry = CommandRegistry()

# Register all helper commands
help_cmd = HelpCommand()
help_cmd.set_registry(command_registry)  # Set registry reference
command_registry.register(help_cmd)
command_registry.register(StatusCommand())
command_registry.register(DiagnoseCommand())
command_registry.register(OfflineUpdateCommand())
command_registry.register(OnboardCommand())

__all__ = [
    "HelperCommand",
    "CommandRegistry",
    "HelpCommand",
    "StatusCommand",
    "DiagnoseCommand",
    "OfflineUpdateCommand",
    "OnboardCommand",
    "command_registry",
]


