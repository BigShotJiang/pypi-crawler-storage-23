"""Offline update command implementation."""

import asyncio
from pathlib import Path
from typing import List

from rich.panel import Panel
from rich.prompt import Confirm

from ocn_cli.offline.uploader import FileUploader
from ocn_cli.offline.validator import PackageValidator
from ocn_cli.ssh.command_executor import CommandExecutor
from ocn_cli.ui.formatters import console, format_error, format_info, format_success, format_warning


class OfflineUpdateCommand:
    """Upload and apply offline OCN update package."""
    
    @property
    def name(self) -> str:
        """Command name."""
        return "offline-update"
    
    @property
    def description(self) -> str:
        """Command description."""
        return "Upload and apply offline OCN update package"
    
    @property
    def aliases(self) -> List[str]:
        """Command aliases."""
        return ["upload-update"]
    
    def execute(self, executor: CommandExecutor, args: List[str]) -> str:
        """
        Execute the offline update command.
        
        Args:
            executor: Command executor for running remote commands
            args: Command arguments [--package <path>] [--skip-confirmation]
            
        Returns:
            str: Update result message
        """
        # Parse arguments
        if not args or "--help" in args:
            return self._show_help()
        
        package_path: str = ""
        skip_confirmation: bool = False
        
        for i, arg in enumerate(args):
            if arg == "--package" and i + 1 < len(args):
                package_path = args[i + 1]
            elif arg == "--skip-confirmation":
                skip_confirmation = True
        
        if not package_path:
            format_error("No package specified. Use: offline-update --package /path/to/update.tar.gz")
            return ""
        
        # Check if local file exists
        local_path: Path = Path(package_path).expanduser()
        if not local_path.exists():
            format_error(f"Package file not found: {local_path}")
            return ""
        
        console.print()
        console.print("[bold cyan]═══ OCN Offline Update ═══[/bold cyan]")
        console.print()
        
        # Get SSH connection from executor
        from ocn_cli.ssh.connection import SSHConnection
        connection: SSHConnection = executor.connection
        
        try:
            # Step 1: Upload package
            format_info(f"📦 Uploading package: {local_path.name} ({local_path.stat().st_size / 1024 / 1024:.1f}MB)")
            console.print()
            
            uploader = FileUploader(connection)
            remote_package_path: str = "/tmp/ocn-offline-update.tar.gz"
            
            success: bool = uploader.upload_with_progress(local_path, remote_package_path)
            
            if not success:
                format_error("Upload failed")
                return ""
            
            console.print()
            format_success("✅ Package uploaded successfully")
            console.print()
            
            # Step 2: Validate package
            format_info("🔍 Validating package structure...")
            
            validator = PackageValidator(executor)
            validation: dict = validator.validate_package(remote_package_path)
            
            if not all(validation.values()):
                format_error("Package validation failed:")
                for check, passed in validation.items():
                    icon: str = "✅" if passed else "❌"
                    console.print(f"  {icon} {check}")
                return ""
            
            format_success("✅ Package validation passed")
            console.print()
            
            # Step 3: Extract and get info
            format_info("📂 Extracting package...")
            extract_result = executor.execute("sudo rm -rf /tmp/ocn && sudo mkdir -p /tmp/ocn && sudo tar -xzf /tmp/ocn-offline-update.tar.gz -C /tmp/ocn", stream=False)
            
            if extract_result.exit_code != 0:
                format_error(f"Extraction failed: {extract_result.stderr}")
                return ""
            
            format_success("✅ Package extracted")
            console.print()
            
            # Get package version and images
            version: str = validator.get_package_version("/tmp/ocn")
            images: List[str] = validator.list_images("/tmp/ocn")
            
            # Display update info
            update_info: str = f"""
[cyan]Update Package Information:[/cyan]

Version: [bold]{version}[/bold]

Docker Images:
{chr(10).join(f'  • {img}' for img in images)}

[yellow]This will:[/yellow]
  1. Stop all OCN containers
  2. Update installer files
  3. Load new Docker images
  4. Restart containers with new images

[bold red]Estimated downtime: ~2-5 minutes[/bold red]
"""
            
            panel = Panel(
                update_info,
                title="[bold]Update Preview[/bold]",
                border_style="yellow",
                padding=(1, 2)
            )
            console.print(panel)
            console.print()
            
            # Step 4: Confirm
            if not skip_confirmation:
                confirmed: bool = Confirm.ask(
                    "[bold yellow]Proceed with offline update?[/bold yellow]",
                    console=console
                )
                
                if not confirmed:
                    format_warning("Update cancelled by user")
                    executor.execute("sudo rm -rf /tmp/ocn /tmp/ocn-offline-update.tar.gz", stream=False)
                    return ""
                
                console.print()
            
            # Step 5: Apply update
            format_info("🚀 Applying update...")
            console.print()
            
            # Run offline update script
            update_script: str = self._generate_offline_update_script(version)
            
            # Create the script on remote server
            script_path: str = "/tmp/ocn-offline-update.sh"
            create_script = executor.execute(
                f"cat > {script_path} << 'EOF'\n{update_script}\nEOF",
                stream=False
            )
            
            if create_script.exit_code != 0:
                format_error("Failed to create update script")
                return ""
            
            # Make script executable
            executor.execute(f"sudo chmod +x {script_path}", stream=False)
            
            # Execute update script (stream output)
            console.print("[dim]Running update script...[/dim]")
            console.print()
            
            update_result = executor.execute(f"sudo {script_path}", stream=True)
            
            console.print()
            
            if update_result.exit_code != 0:
                format_error("Update script failed. Check output above for details.")
                return ""
            
            format_success(f"✅ Update completed successfully! OCN v{version} is now running")
            console.print()
            
            # Cleanup
            executor.execute("sudo rm -rf /tmp/ocn /tmp/ocn-offline-update.tar.gz /tmp/ocn-offline-update.sh", stream=False)
            
            return ""
            
        except Exception as e:
            format_error(f"Update failed: {e}")
            # Cleanup on error
            executor.execute("sudo rm -rf /tmp/ocn /tmp/ocn-offline-update.tar.gz", stream=False)
            return ""
    
    def _generate_offline_update_script(self, version: str) -> str:
        """
        Generate offline update script based on update.sh.
        
        Args:
            version: OCN version being installed
            
        Returns:
            str: Update script content
        """
        return f"""#!/bin/bash
# OCN Offline Update Script (Generated by ocn-cli)
# Based on /etc/ocn/ocn-installer/scripts/update.sh

TEXT_RED='\\033[0;31m'
TEXT_COLOR='\\033[0;35m'
NC='\\033[0m'

set -e  # Exit on error

INSTALL_DIR="/etc/ocn/ocn-installer"
UPDATE_DIR="/tmp/ocn/ocn-installer"

# Get local IP address
LOCAL_IP=$(hostname -I | cut -d' ' -f1)

# Get the fingerprint of the local machine
FINGERPRINT=$(python3 /etc/ocn/ocn-installer/fingerprint.py)

# Get channel from license or existing config
if [ -f /etc/ocn/channel.json ]; then
    CHANNEL=$(python3 /etc/ocn/ocn-installer/channel.py --get)
else
    CHANNEL=$(python3 /etc/ocn/ocn-installer/license.py --channel | tail -n -1)
    python3 /etc/ocn/ocn-installer/channel.py --set $CHANNEL
fi

# Create .env file
echo -e "${{TEXT_COLOR}}Creating .env file${{NC}}"
echo "LOCAL_IP=$LOCAL_IP" > $INSTALL_DIR/.env
echo "FINGERPRINT=$FINGERPRINT" >> $INSTALL_DIR/.env
echo "CHANNEL=$CHANNEL" >> $INSTALL_DIR/.env
echo "VERSION={version}" >> $INSTALL_DIR/.env

# Get Timezone
TZ=$(cat /etc/timezone)
echo "TZ=$TZ" >> $INSTALL_DIR/.env

# Stop containers
echo -e "${{TEXT_COLOR}}Stopping containers${{NC}}"
docker-compose -f $INSTALL_DIR/docker-compose.yml down || true

# Remove all docker networks
echo -e "${{TEXT_COLOR}}Removing docker networks${{NC}}"
docker network prune -f || true

# Update installer files
echo -e "${{TEXT_COLOR}}Updating installer files${{NC}}"
cp -fr $UPDATE_DIR/* $INSTALL_DIR/
chmod +x $INSTALL_DIR/scripts/*.sh

# Load Docker images
echo -e "${{TEXT_COLOR}}Loading Docker images${{NC}}"

# Load all images from the images directory
for image in $INSTALL_DIR/images/*.tar.gz; do
    if [ -f "$image" ]; then
        echo "Loading $(basename $image)..."
        docker load -i "$image"
    fi
done

# Remove old containers
echo -e "${{TEXT_COLOR}}Removing old containers${{NC}}"
docker rm $(docker ps -a -q) 2>/dev/null || true

# Start containers
echo -e "${{TEXT_COLOR}}Starting containers${{NC}}"
docker-compose -f $INSTALL_DIR/docker-compose.yml up -d

# Run setup script
echo -e "${{TEXT_COLOR}}Running setup script${{NC}}"
$INSTALL_DIR/scripts/setup.sh

echo -e "${{TEXT_COLOR}}OCN version {version} installed${{NC}}"
"""
    
    def _show_help(self) -> str:
        """Show help for offline-update command."""
        return """
[bold cyan]offline-update[/bold cyan] - Upload and apply offline OCN update

[bold]Usage:[/bold]
  offline-update --package <local-path> [options]

[bold]Options:[/bold]
  --package <path>      Path to offline update package (required)
  --skip-confirmation   Skip confirmation prompt
  --help               Show this help message

[bold]Examples:[/bold]
  # Upload and apply update with confirmation
  offline-update --package /path/to/ocn-update-2.1.10.tar.gz
  
  # Skip confirmation (automated)
  offline-update --package ~/ocn-update.tar.gz --skip-confirmation

[bold]Package Requirements:[/bold]
  The offline update package must contain:
  • ocn-installer/ directory with updated files
  • ocn-installer/images/ with Docker image .tar.gz files
  • ocn-installer/VERSION file

[bold]Notes:[/bold]
  • Docker CE must already be installed (no migration in offline mode)
  • Update will cause ~2-5 minutes downtime
  • Ensure sudo password was provided when connecting
  • Package is uploaded via SFTP (may take time for large files)

[bold]Creating Update Packages:[/bold]
  On a machine with internet access:
  1. Download OCN release from keygen.sh
  2. Extract it
  3. Ensure images/ directory contains all Docker images as .tar.gz
  4. Create tarball: tar -czf ocn-update-2.1.10.tar.gz ocn-installer/
  5. Transfer to offline network and use ocn-cli to apply
"""

