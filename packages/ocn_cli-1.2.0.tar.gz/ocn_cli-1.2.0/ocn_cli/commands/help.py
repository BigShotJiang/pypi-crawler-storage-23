"""Help command implementation."""

from typing import TYPE_CHECKING, List

from rich.table import Table

from ocn_cli.ssh.command_executor import CommandExecutor
from ocn_cli.ui.formatters import console

if TYPE_CHECKING:
    from ocn_cli.commands.registry import CommandRegistry


class HelpCommand:
    """Display available helper commands."""
    
    def __init__(self) -> None:
        """Initialize help command."""
        from typing import Optional
        self._registry: "Optional[CommandRegistry]" = None
    
    def set_registry(self, registry: "CommandRegistry") -> None:
        """Set the command registry reference."""
        self._registry = registry
    
    @property
    def name(self) -> str:
        """Command name."""
        return "help"
    
    @property
    def description(self) -> str:
        """Command description."""
        return "Show this help message"
    
    @property
    def aliases(self) -> List[str]:
        """Command aliases."""
        return []
    
    def execute(self, executor: CommandExecutor, args: List[str]) -> str:
        """
        Execute the help command.
        
        Args:
            executor: Command executor (not used)
            args: Command arguments (not used)
            
        Returns:
            str: Empty string (output is printed directly)
        """
        # Create a table for helper commands
        table = Table(
            title="OCN CLI Helper Commands",
            show_header=True,
            header_style="bold cyan",
            border_style="cyan",
            padding=(0, 2),
        )
        
        table.add_column("Command", style="bright_cyan bold", no_wrap=True)
        table.add_column("Description", style="white")
        
        # Add all registered commands
        if self._registry:
            commands = self._registry.get_all_commands()
        else:
            commands = []
        for cmd in commands:
            table.add_row(cmd.name, cmd.description)
        
        # Print the table
        console.print()
        console.print(table)
        console.print()
        console.print(
            "[yellow]Any other command is executed on the remote OCN server[/yellow]",
            justify="center"
        )
        console.print()
        
        return ""


