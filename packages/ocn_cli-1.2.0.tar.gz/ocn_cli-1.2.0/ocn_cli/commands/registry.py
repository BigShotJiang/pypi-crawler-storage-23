"""Command registry for managing helper commands."""

from typing import Dict, List, Optional, Set

from ocn_cli.commands.base import HelperCommand


class CommandRegistry:
    """Registry for helper commands."""
    
    def __init__(self) -> None:
        """Initialize the command registry."""
        self._commands: Dict[str, HelperCommand] = {}
    
    def register(self, command: HelperCommand) -> None:
        """
        Register a helper command.
        
        Args:
            command: Helper command to register
        """
        # Register by primary name
        self._commands[command.name] = command
        
        # Register by aliases
        for alias in command.aliases:
            self._commands[alias] = command
    
    def lookup(self, name: str) -> Optional[HelperCommand]:
        """
        Look up a command by name or alias.
        
        Args:
            name: Command name or alias
            
        Returns:
            Optional[HelperCommand]: Command if found, None otherwise
        """
        return self._commands.get(name)
    
    def is_helper_command(self, name: str) -> bool:
        """
        Check if a command name is a registered helper command.
        
        Args:
            name: Command name to check
            
        Returns:
            bool: True if it's a helper command
        """
        return name in self._commands
    
    def get_all_commands(self) -> List[HelperCommand]:
        """
        Get all registered commands (deduplicated).
        
        Returns:
            List[HelperCommand]: List of unique commands
        """
        # Use a set to deduplicate (same command registered under multiple names)
        seen_commands: Set[HelperCommand] = set()
        unique_commands: List[HelperCommand] = []
        
        for cmd in self._commands.values():
            if cmd not in seen_commands:
                seen_commands.add(cmd)
                unique_commands.append(cmd)
        
        # Sort by name
        return sorted(unique_commands, key=lambda c: c.name)


