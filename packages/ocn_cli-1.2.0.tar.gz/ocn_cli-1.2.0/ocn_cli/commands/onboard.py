"""Onboard OCN server to OCN-cloud command implementation."""

import re
import shlex
from typing import List, Optional, Tuple

from ocn_cli.ssh.command_executor import CommandExecutor
from ocn_cli.ui.formatters import console, format_error, format_info, format_success


# OpenVPN-related package names (Debian/Ubuntu)
OPENVPN_PACKAGES: List[str] = [
    "openvpn",
    "openvpn3",
    "openvpn-cloud-client",
    "openvpn-connexa",
    "connexa",
]

# RFC 1123: hostname labels: [a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])? (max 63 per label)
# Total hostname max 253 chars. No spaces.
HOSTNAME_LABEL_RE: re.Pattern[str] = re.compile(
    r"^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?$|^[a-zA-Z0-9]$"
)


def _validate_hostname(hostname: str) -> Tuple[bool, Optional[str]]:
    """
    Validate hostname per RFC 1123 (no spaces, alphanumeric + hyphen only).

    Args:
        hostname: Hostname string to validate.

    Returns:
        Tuple of (is_valid, error_message). error_message is None when valid.
    """
    if not hostname:
        return (False, "Hostname cannot be empty")
    if " " in hostname:
        return (False, "Hostname cannot contain spaces")
    if len(hostname) > 253:
        return (False, "Hostname exceeds maximum length (253 characters)")
    labels: List[str] = hostname.split(".")
    for label in labels:
        if not label:
            return (False, "Hostname labels cannot be empty")
        if len(label) > 63:
            return (False, "Hostname label exceeds 63 characters")
        if not HOSTNAME_LABEL_RE.match(label):
            return (
                False,
                "Hostname must contain only letters, digits, and hyphens; "
                "no underscores or leading/trailing hyphens in labels",
            )
    return (True, None)


def _parse_args(args: List[str]) -> Tuple[Optional[str], Optional[str]]:
    """
    Parse --auth-key and --hostname from args.

    Handles shell passing args as single string (shlex.split) or list of tokens.

    Returns:
        Tuple of (auth_key, hostname). Either may be None if missing.
    """
    tokens: List[str]
    if len(args) == 1 and isinstance(args[0], str) and " " in args[0]:
        tokens = shlex.split(args[0])
    else:
        tokens = list(args)

    auth_key: Optional[str] = None
    hostname: Optional[str] = None

    i: int = 0
    while i < len(tokens):
        if tokens[i] == "--auth-key":
            if i + 1 < len(tokens):
                auth_key = tokens[i + 1]
                i += 2
                continue
            else:
                return (None, None)  # Missing value
        if tokens[i] == "--hostname":
            if i + 1 < len(tokens):
                hostname = tokens[i + 1]
                i += 2
                continue
            else:
                return (None, None)
        i += 1

    return (auth_key, hostname)


class OnboardCommand:
    """Onboard OCN server to OCN-cloud (remove OpenVPN, set hostname, join Tailscale, reboot)."""

    @property
    def name(self) -> str:
        """Command name."""
        return "onboard"

    @property
    def description(self) -> str:
        """Command description."""
        return "Onboard OCN server to OCN-cloud (remove OpenVPN, set hostname, join Tailscale, reboot)"

    @property
    def aliases(self) -> List[str]:
        """Command aliases."""
        return ["ocn-cloud-onboard"]

    def execute(self, executor: CommandExecutor, args: List[str]) -> str:
        """
        Execute the onboard command.

        Args:
            executor: Command executor for running remote commands.
            args: Command arguments [--auth-key <TOKEN>] [--hostname <NAME>].

        Returns:
            str: Empty string (output via format_*).
        """
        if not args or "--help" in args:
            return self._show_help()

        auth_key, hostname = _parse_args(args)

        if not auth_key:
            format_error(
                "Missing --auth-key. Usage: onboard --auth-key <TAILSCALE_AUTH_KEY> --hostname <HOSTNAME>"
            )
            return ""

        if not hostname:
            format_error(
                "Missing --hostname. Usage: onboard --auth-key <TAILSCALE_AUTH_KEY> --hostname <HOSTNAME>"
            )
            return ""

        valid, err_msg = _validate_hostname(hostname)
        if not valid and err_msg:
            format_error(f"Invalid hostname: {err_msg}")
            return ""

        console.print()
        console.print("[bold cyan]═══ OCN Cloud Onboard ═══[/bold cyan]")
        console.print()

        # Step 1: OpenVPN removal
        format_info("Step 1/4: Removing OpenVPN...")
        if not self._step_openvpn_removal(executor):
            return ""
        format_success("OpenVPN removed / services disabled")
        console.print()

        # Step 2: Hostname
        format_info("Step 2/4: Setting hostname...")
        if not self._step_hostname(executor, hostname):
            return ""
        format_success("Hostname set")
        console.print()

        # Step 3: Tailscale
        format_info("Step 3/4: Onboarding Tailscale...")
        if not self._step_tailscale(executor, auth_key):
            return ""
        format_success("Tailscale joined")
        console.print()

        # Step 4: Reboot
        format_info("Step 4/4: Rebooting...")
        if not self._step_reboot(executor):
            return ""
        format_info("Server rebooting. Session will disconnect.")
        return ""

    def _step_openvpn_removal(self, executor: CommandExecutor) -> bool:
        """Remove OpenVPN packages and disable/mask openvpn* services. Returns False on failure."""
        # Find installed OpenVPN-related packages
        pkg_pattern: str = "|".join(OPENVPN_PACKAGES)
        check_cmd: str = (
            f"dpkg-query -W -f='${{Package}}\n' 2>/dev/null | grep -E '^({pkg_pattern})$' || true"
        )
        result = executor.execute(check_cmd, stream=False)
        installed: List[str] = [p for p in result.stdout.strip().splitlines() if p]

        if installed:
            pkg_list: str = " ".join(installed)
            rm_result = executor.execute(
                f"sudo DEBIAN_FRONTEND=noninteractive apt-get remove -y {pkg_list}",
                stream=False,
            )
            if rm_result.exit_code != 0:
                format_error(
                    "OpenVPN package removal failed",
                    hints=[rm_result.stderr.strip() or rm_result.stdout.strip()],
                )
                return False

        # Disable and mask all openvpn* systemd units
        list_cmd: str = (
            "systemctl list-unit-files --no-legend --no-pager -o name 'openvpn*' 2>/dev/null || true"
        )
        list_result = executor.execute(list_cmd, stream=False)
        units: List[str] = [u.strip() for u in list_result.stdout.strip().splitlines() if u]

        for unit in units:
            exec_result = executor.execute(
                f"sudo systemctl disable --now {unit} 2>/dev/null; sudo systemctl mask {unit}",
                stream=False,
            )
            if exec_result.exit_code != 0:
                format_error(
                    f"Failed to disable/mask {unit}",
                    hints=[exec_result.stderr.strip() or exec_result.stdout.strip()],
                )
                return False

        return True

    def _step_hostname(self, executor: CommandExecutor, hostname: str) -> bool:
        """Set hostname via hostnamectl. Returns False on failure."""
        escaped: str = hostname.replace("'", "'\"'\"'")
        result = executor.execute(f"sudo hostnamectl set-hostname '{escaped}'", stream=False)
        if result.exit_code != 0:
            format_error(
                "Hostname configuration failed",
                hints=[result.stderr.strip() or result.stdout.strip()],
            )
            return False
        return True

    def _step_tailscale(self, executor: CommandExecutor, auth_key: str) -> bool:
        """Install Tailscale if needed, join with auth key. Returns False on failure."""
        check_result = executor.execute("which tailscale 2>/dev/null", stream=False)
        installed: bool = check_result.exit_code == 0 and bool(check_result.stdout.strip())

        if not installed:
            install_result = executor.execute(
                "sudo sh -c 'curl -fsSL https://tailscale.com/install.sh | sh'",
                stream=True,
            )
            if install_result.exit_code != 0:
                format_error(
                    "Tailscale installation failed",
                    hints=[install_result.stderr.strip() or install_result.stdout.strip()],
                )
                return False

        escaped_key: str = auth_key.replace("'", "'\"'\"'")
        up_result = executor.execute(
            f"sudo tailscale up --auth-key='{escaped_key}'",
            stream=False,
        )
        if up_result.exit_code != 0:
            format_error(
                "Tailscale join failed",
                hints=[up_result.stderr.strip() or up_result.stdout.strip()],
            )
            return False
        return True

    def _step_reboot(self, executor: CommandExecutor) -> bool:
        """Trigger reboot. Returns False only if reboot command fails before disconnect."""
        result = executor.execute("sudo reboot", stream=False)
        # reboot may not return; exit_code can be unreliable
        if result.exit_code not in (0, -1) and "Connection" not in str(result.stderr):
            format_error(
                "Reboot command failed",
                hints=[result.stderr.strip() or result.stdout.strip()],
            )
            return False
        return True

    def _show_help(self) -> str:
        """Return help text for onboard command."""
        return """
[bold cyan]onboard[/bold cyan] - Onboard OCN server to OCN-cloud

[bold]Usage:[/bold]
  onboard --auth-key <TAILSCALE_AUTH_KEY> --hostname <HOSTNAME>

[bold]Required:[/bold]
  --auth-key <key>   Tailscale auth key (e.g. tskey-xxx)
  --hostname <name> Server hostname (RFC-compliant, no spaces)

[bold]What it does:[/bold]
  1. Removes OpenVPN/openvpn3/connexa packages and disables/masks openvpn* services
  2. Sets hostname via hostnamectl
  3. Installs Tailscale (if needed) and joins with auth key
  4. Reboots the server

[bold]Examples:[/bold]
  onboard --auth-key tskey-auth-xxx --hostname ocn-server-01
  onboard --hostname myserver --auth-key tskey-auth-xxx

[bold]Notes:[/bold]
  • Debian/Ubuntu only. Requires sudo password when connecting.
  • No confirmation; runs non-interactively.
  • Server reboots at the end; SSH session will disconnect.
"""
