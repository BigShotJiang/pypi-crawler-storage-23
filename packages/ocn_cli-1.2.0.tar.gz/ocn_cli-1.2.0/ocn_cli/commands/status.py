"""Status command implementation."""

import re
from typing import Dict, List, Optional

from rich.panel import Panel

from ocn_cli.ssh.command_executor import CommandExecutor
from ocn_cli.ui.formatters import console


class StatusCommand:
    """Display OCN server system status."""
    
    @property
    def name(self) -> str:
        """Command name."""
        return "status"
    
    @property
    def description(self) -> str:
        """Command description."""
        return "Display OCN server system status"
    
    @property
    def aliases(self) -> List[str]:
        """Command aliases."""
        return []
    
    def execute(self, executor: CommandExecutor, args: List[str]) -> str:
        """
        Execute the status command.
        
        Args:
            executor: Command executor for running remote commands
            args: Command arguments (not used)
            
        Returns:
            str: Empty string (output is printed directly)
        """
        status_lines: List[str] = []
        
        # Get uptime
        try:
            result = executor.execute("uptime", stream=False)
            if result.exit_code == 0:
                uptime_text: str = result.stdout.strip()
                # Extract uptime portion (varies by system)
                match = re.search(r"up\s+(.+?),\s+\d+\s+user", uptime_text)
                if match:
                    uptime: str = match.group(1).strip()
                else:
                    uptime = uptime_text
                status_lines.append(f"[cyan]Uptime:[/cyan]    {uptime}")
        except Exception:
            status_lines.append("[cyan]Uptime:[/cyan]    [red]unavailable[/red]")
        
        # Get load average
        try:
            result = executor.execute("cat /proc/loadavg", stream=False)
            if result.exit_code == 0:
                load_parts: List[str] = result.stdout.strip().split()
                if len(load_parts) >= 3:
                    load_avg: str = f"{load_parts[0]}, {load_parts[1]}, {load_parts[2]}"
                    status_lines.append(f"[cyan]CPU Load:[/cyan]  {load_avg} (1/5/15 min)")
        except Exception:
            status_lines.append("[cyan]CPU Load:[/cyan]  [red]unavailable[/red]")
        
        # Get memory usage
        try:
            result = executor.execute("free -h | grep Mem:", stream=False)
            if result.exit_code == 0:
                mem_parts: List[str] = result.stdout.strip().split()
                if len(mem_parts) >= 3:
                    total: str = mem_parts[1]
                    used: str = mem_parts[2]
                    # Calculate percentage
                    try:
                        used_val: float = self._parse_size(used)
                        total_val: float = self._parse_size(total)
                        if total_val > 0:
                            pct: int = int((used_val / total_val) * 100)
                            status_lines.append(
                                f"[cyan]Memory:[/cyan]    {used} / {total} ({pct}%)"
                            )
                        else:
                            status_lines.append(f"[cyan]Memory:[/cyan]    {used} / {total}")
                    except Exception:
                        status_lines.append(f"[cyan]Memory:[/cyan]    {used} / {total}")
        except Exception:
            status_lines.append("[cyan]Memory:[/cyan]    [red]unavailable[/red]")
        
        # Get disk usage
        try:
            result = executor.execute("df -h / | tail -1", stream=False)
            if result.exit_code == 0:
                disk_parts: List[str] = result.stdout.strip().split()
                if len(disk_parts) >= 5:
                    total: str = disk_parts[1]
                    used: str = disk_parts[2]
                    pct: str = disk_parts[4]
                    status_lines.append(f"[cyan]Disk:[/cyan]      {used} / {total} ({pct})")
        except Exception:
            status_lines.append("[cyan]Disk:[/cyan]      [red]unavailable[/red]")
        
        # Create panel with status information
        content: str = "\n".join(status_lines)
        panel = Panel(
            content,
            title="[bold]System Status[/bold]",
            border_style="cyan",
            padding=(1, 2),
        )
        
        console.print()
        console.print(panel)
        console.print()
        
        return ""
    
    def _parse_size(self, size_str: str) -> float:
        """
        Parse a size string (e.g., '4.2G', '512M') to bytes.
        
        Args:
            size_str: Size string to parse
            
        Returns:
            float: Size in bytes
        """
        # Remove 'i' if present (e.g., 'Gi' -> 'G')
        size_str = size_str.replace("i", "")
        
        multipliers: Dict[str, float] = {
            "K": 1024,
            "M": 1024 ** 2,
            "G": 1024 ** 3,
            "T": 1024 ** 4,
        }
        
        # Extract number and unit
        match = re.match(r"([\d.]+)([KMGT])?", size_str)
        if match:
            value: float = float(match.group(1))
            unit: Optional[str] = match.group(2)
            if unit:
                value *= multipliers.get(unit, 1)
            return value
        
        return 0.0


