"""Security utilities for safe credential handling."""

import ctypes
import stat
from pathlib import Path
from typing import List, Optional


def clear_memory(buffer: bytearray) -> None:
    """
    Securely clear a memory buffer by overwriting with zeros.
    
    Args:
        buffer: Bytearray buffer to clear
    """
    # Overwrite with zeros
    for i in range(len(buffer)):
        buffer[i] = 0
    
    # Additional platform-specific clearing if available
    try:
        # Try to use ctypes to zero memory more securely
        if len(buffer) > 0:
            ctypes.memset(id(buffer) + 32, 0, len(buffer))  # 32-byte offset for bytearray header
    except (AttributeError, TypeError, ValueError):
        # Fall back to simple zeroing if ctypes fails
        pass


def check_key_permissions(path: Path) -> Optional[str]:
    """
    Check if an SSH key file has secure permissions.
    
    Args:
        path: Path to the key file
        
    Returns:
        Optional[str]: Warning message if permissions are insecure, None if OK
    """
    try:
        # Get file stat
        file_stat = path.stat()
        
        # Check file mode (permissions)
        mode: int = file_stat.st_mode
        
        # Extract permission bits (last 9 bits)
        perms: int = stat.S_IMODE(mode)
        
        # Check if group or others have any permissions (should be 0o600 or 0o400)
        if perms & 0o077:  # Check group (0o070) and others (0o007)
            return (
                f"⚠️  Warning: Key file has insecure permissions ({oct(perms)}). "
                f"Recommended: chmod 600 {path}"
            )
        
        return None
        
    except (OSError, IOError) as e:
        # If we can't check permissions, return a generic warning
        return f"⚠️  Warning: Could not verify key file permissions: {e}"


def validate_key_format(key_data: bytes) -> bool:
    """
    Validate that data appears to be a valid SSH private key format.
    
    Args:
        key_data: Raw key file data
        
    Returns:
        bool: True if data appears to be a valid SSH key format
    """
    # Check for common SSH private key headers
    valid_headers: List[bytes] = [
        b"-----BEGIN RSA PRIVATE KEY-----",
        b"-----BEGIN DSA PRIVATE KEY-----",
        b"-----BEGIN EC PRIVATE KEY-----",
        b"-----BEGIN OPENSSH PRIVATE KEY-----",
        b"-----BEGIN PRIVATE KEY-----",
        b"-----BEGIN ENCRYPTED PRIVATE KEY-----",
    ]
    
    # Check if data starts with any valid header
    for header in valid_headers:
        if key_data.startswith(header):
            return True
    
    return False


