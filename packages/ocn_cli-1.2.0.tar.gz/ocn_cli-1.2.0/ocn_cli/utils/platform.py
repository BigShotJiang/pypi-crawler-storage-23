"""Platform-specific utilities for cross-platform compatibility."""

import getpass
import os
import platform
import shutil
from pathlib import Path
from typing import Tuple


def get_default_username() -> str:
    """
    Get the default username.
    
    Returns:
        str: Current username
    """
    return 'ocn'


def normalize_path(path: str) -> Path:
    """
    Normalize a file path for cross-platform compatibility.
    
    Args:
        path: Path string to normalize
        
    Returns:
        Path: Normalized pathlib.Path object
    """
    # Expand user home directory (~)
    expanded: str = os.path.expanduser(path)
    
    # Convert to Path object (handles platform differences)
    path_obj: Path = Path(expanded)
    
    # Resolve to absolute path
    return path_obj.resolve()


def get_terminal_size() -> Tuple[int, int]:
    """
    Get the current terminal size.
    
    Returns:
        Tuple[int, int]: (columns, lines) of terminal
    """
    size = shutil.get_terminal_size(fallback=(80, 24))
    return (size.columns, size.lines)


def get_os_type() -> str:
    """
    Detect the operating system type.
    
    Returns:
        str: Operating system name (Windows, macOS, Linux, or Unknown)
    """
    system: str = platform.system()
    
    if system == "Windows":
        return "Windows"
    elif system == "Darwin":
        return "macOS"
    elif system == "Linux":
        return "Linux"
    else:
        return "Unknown"


