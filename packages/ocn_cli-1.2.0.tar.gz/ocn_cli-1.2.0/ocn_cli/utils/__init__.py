"""Utilities module for OCN CLI."""

from ocn_cli.utils.platform import (
    get_default_username,
    normalize_path,
    get_terminal_size,
    get_os_type,
)
from ocn_cli.utils.security import (
    clear_memory,
    check_key_permissions,
    validate_key_format,
)

__all__ = [
    "get_default_username",
    "normalize_path",
    "get_terminal_size",
    "get_os_type",
    "clear_memory",
    "check_key_permissions",
    "validate_key_format",
]


