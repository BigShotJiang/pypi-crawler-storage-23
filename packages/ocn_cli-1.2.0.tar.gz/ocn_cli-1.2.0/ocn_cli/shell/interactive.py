"""Interactive shell for OCN CLI."""

from typing import List, Optional

from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.styles import Style

from ocn_cli.commands import command_registry
from ocn_cli.shell.completer import OCNCompleter
from ocn_cli.shell.highlighter import OCN_STYLE, OCNLexer
from ocn_cli.shell.history import SessionHistory
from ocn_cli.ssh.command_executor import CommandExecutor
from ocn_cli.ssh.connection import SSHConnection
from ocn_cli.ui.formatters import console, format_info
from ocn_cli.ui.messages import messages


class InteractiveShell:
    """Interactive shell for executing commands on OCN server."""
    
    def __init__(
        self,
        ssh_connection: SSHConnection,
        command_executor: CommandExecutor,
        hostname: str,
    ) -> None:
        """
        Initialize the interactive shell.
        
        Args:
            ssh_connection: Active SSH connection
            command_executor: Command executor instance
            hostname: Hostname for prompt display
        """
        self.ssh_connection: SSHConnection = ssh_connection
        self.executor: CommandExecutor = command_executor
        self.hostname: str = hostname
        self.should_exit: bool = False
        
        # Create prompt session with history, completion, and syntax highlighting
        self.history: SessionHistory = SessionHistory()
        self.completer: OCNCompleter = OCNCompleter(command_registry)
        self.lexer: OCNLexer = OCNLexer()
        
        # Create custom key bindings
        self.key_bindings: KeyBindings = self._create_key_bindings()
        
        # Create custom style
        self.style: Style = Style.from_dict({
            **OCN_STYLE,
            "prompt": "#00ff88 bold",
        })
        
        self.session: PromptSession[str] = PromptSession(
            history=self.history,
            completer=self.completer,
            lexer=self.lexer,
            style=self.style,
            key_bindings=self.key_bindings,
            enable_history_search=True,
            mouse_support=False,
        )
    
    def _create_key_bindings(self) -> KeyBindings:
        """
        Create custom key bindings.
        
        Returns:
            KeyBindings: Custom key bindings
        """
        kb = KeyBindings()
        
        # Ctrl+C during command input (not during execution)
        @kb.add("c-c")
        def _(event) -> None:  # type: ignore
            """Handle Ctrl+C - clear current line."""
            event.app.current_buffer.reset()
        
        return kb
    
    def run(self) -> None:
        """Run the interactive shell REPL."""
        # Display welcome message
        format_info(messages.SHELL_STARTED)
        console.print()
        
        while not self.should_exit:
            try:
                # Check connection
                if not self.ssh_connection.is_connected():
                    console.print(messages.SSH_DISCONNECTED, style="error")
                    console.print(
                        messages.SSH_CONNECTION_CLOSED.format(host=self.hostname),
                        style="warning"
                    )
                    break
                
                # Display prompt and get input
                prompt_text: HTML = self._get_prompt_text()
                command: str = self.session.prompt(prompt_text)
                
                # Process command
                self.process_command(command)
                
            except KeyboardInterrupt:
                # Ctrl+C pressed - just display new prompt
                console.print()
                continue
                
            except EOFError:
                # Ctrl+D pressed - exit
                console.print()
                self.should_exit = True
                break
        
        # Shutdown
        self.shutdown()
    
    def _get_prompt_text(self) -> HTML:
        """
        Get formatted prompt text.
        
        Returns:
            HTML: Formatted prompt
        """
        return HTML(f'<prompt>ocn@{self.hostname}&gt;&gt;</prompt> ')
    
    def process_command(self, command: str) -> None:
        """
        Process a user command.
        
        Args:
            command: Command string to process
        """
        # Strip whitespace
        command = command.strip()
        
        # Ignore empty commands
        if not command:
            return
        
        # Split into command name and args
        parts: List[str] = command.split(maxsplit=1)
        cmd_name: str = parts[0]
        args: List[str] = parts[1:] if len(parts) > 1 else []
        
        # Check for built-in shell commands
        if cmd_name in ("exit", "quit"):
            self.should_exit = True
            return
        
        if cmd_name == "clear":
            console.clear()
            return
        
        # Check if it's a helper command
        helper_cmd = command_registry.lookup(cmd_name)
        if helper_cmd:
            try:
                output: str = helper_cmd.execute(self.executor, args)
                if output:
                    console.print(output)
            except Exception as e:
                console.print(f"Error executing '{cmd_name}': {e}", style="error")
        else:
            # Execute as raw command on remote server
            try:
                result = self.executor.execute(command, stream=True)
                
                # Print newline after streamed output if needed
                console.print()
                
                # Show exit code if non-zero
                if result.exit_code != 0:
                    console.print(
                        f"[Command exited with code {result.exit_code}]",
                        style="warning"
                    )
                
            except RuntimeError as e:
                console.print(f"Error: {e}", style="error")
            except KeyboardInterrupt:
                # Ctrl+C during command execution
                console.print("\n" + messages.COMMAND_INTERRUPTED)
                self.executor.send_interrupt()
    
    def shutdown(self) -> None:
        """Clean up and exit the shell."""
        console.print(messages.SHELL_EXITING, style="success")


