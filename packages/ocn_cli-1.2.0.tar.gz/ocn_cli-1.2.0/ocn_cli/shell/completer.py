"""Command autocompletion for interactive shell."""

from typing import Iterable, List

from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.document import Document


class OCNCompleter(Completer):
    """Autocompleter for OCN CLI commands."""
    
    def __init__(self, command_registry) -> None:  # type: ignore
        """
        Initialize the completer.
        
        Args:
            command_registry: Registry of helper commands
        """
        self.command_registry = command_registry
        
        # Common Linux commands for completion
        self.linux_commands: List[str] = [
            "ls", "cd", "pwd", "cat", "grep", "find", "ps", "top", "htop",
            "docker", "systemctl", "journalctl", "tail", "head", "less", "more",
            "df", "du", "free", "uptime", "whoami", "hostname", "ip", "ifconfig",
            "ping", "curl", "wget", "ssh", "scp", "rsync", "tar", "gzip", "zip",
            "chmod", "chown", "sudo", "su", "kill", "killall", "service", "man",
        ]
    
    def get_completions(
        self,
        document: Document,
        complete_event,  # type: ignore
    ) -> Iterable[Completion]:
        """
        Get completion suggestions.
        
        Args:
            document: Current document
            complete_event: Completion event
            
        Yields:
            Completion: Completion suggestions
        """
        # Get the text before cursor
        text_before_cursor: str = document.text_before_cursor
        
        # If no text or just whitespace, don't complete
        if not text_before_cursor or text_before_cursor.isspace():
            return
        
        # Split into words
        words: List[str] = text_before_cursor.split()
        
        if not words:
            return
        
        # Get current word being typed
        current_word: str = words[-1] if not text_before_cursor.endswith(" ") else ""
        
        # If this is the first word, complete commands
        if len(words) == 1 and not text_before_cursor.endswith(" "):
            # Complete with helper commands first
            helper_commands: List = self.command_registry.get_all_commands()
            for cmd in helper_commands:
                if cmd.name.startswith(current_word):
                    yield Completion(
                        cmd.name,
                        start_position=-len(current_word),
                        display=cmd.name,
                        display_meta=cmd.description,
                    )
            
            # Then Linux commands
            for cmd in sorted(self.linux_commands):
                if cmd.startswith(current_word):
                    yield Completion(
                        cmd,
                        start_position=-len(current_word),
                        display=cmd,
                        display_meta="Linux command",
                    )


