"""Command history management for interactive shell."""

from typing import AsyncGenerator, Iterable, List

from prompt_toolkit.history import History


class SessionHistory(History):
    """In-memory command history for a single session."""
    
    def __init__(self, max_size: int = 1000) -> None:
        """
        Initialize session history.
        
        Args:
            max_size: Maximum number of history entries to keep
        """
        self.max_size: int = max_size
        self._history: List[str] = []
        self._loaded: bool = False
        self._loaded_strings: List[str] = []
    
    async def load(self) -> AsyncGenerator[str, None]:
        """
        Load history asynchronously (required by prompt_toolkit).
        
        Yields:
            str: History strings in reverse order (most recent first)
        """
        # Yield in reverse order so most recent commands appear first
        for item in reversed(self._history):
            yield item
        self._loaded = True
        self._loaded_strings = list(reversed(self._history))
    
    def load_history_strings(self) -> Iterable[str]:
        """
        Load history strings (synchronous fallback).
        
        Returns:
            Iterable[str]: History strings in reverse order (most recent first)
        """
        return iter(reversed(self._history))
    
    def store_string(self, string: str) -> None:
        """
        Store a command in history.
        
        Args:
            string: Command string to store
        """
        # Don't store empty strings or duplicates of the last command
        if string and (not self._history or self._history[-1] != string):
            self._history.append(string)
            
            # Also update the loaded_strings for prompt_toolkit (at beginning since reversed)
            if self._loaded:
                self._loaded_strings.insert(0, string)
            
            # Rotate if exceeding max size
            if len(self._history) > self.max_size:
                self._history = self._history[-self.max_size:]
                if self._loaded:
                    self._loaded_strings = self._loaded_strings[:self.max_size]


