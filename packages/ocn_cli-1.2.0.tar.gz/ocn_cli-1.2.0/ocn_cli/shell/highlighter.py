"""Syntax highlighting for interactive shell."""

from typing import Callable, List, Set

from prompt_toolkit.document import Document
from prompt_toolkit.formatted_text import StyleAndTextTuples
from prompt_toolkit.lexers import Lexer


class OCNLexer(Lexer):
    """Syntax highlighter for OCN CLI commands."""
    
    # Helper commands (built-in)
    HELPER_COMMANDS: Set[str] = {"help", "status", "clear", "exit", "quit"}
    
    # Common Linux commands
    COMMON_COMMANDS: Set[str] = {
        "ls", "cd", "pwd", "cat", "grep", "find", "ps", "top", "htop",
        "docker", "systemctl", "journalctl", "tail", "head", "less", "more",
        "df", "du", "free", "uptime", "whoami", "hostname", "ip", "ifconfig",
        "ping", "curl", "wget", "ssh", "scp", "rsync", "tar", "gzip", "zip",
        "chmod", "chown", "sudo", "su", "kill", "killall", "service",
        "apt", "yum", "dnf", "pip", "npm", "git", "vim", "nano", "echo",
    }
    
    def lex_document(self, document: Document) -> Callable[[int], StyleAndTextTuples]:
        """
        Lexer function for syntax highlighting.
        
        Args:
            document: Current document
            
        Returns:
            Callable: Function that returns styled text tuples for a line
        """
        def get_line_tokens(line_number: int) -> StyleAndTextTuples:
            """
            Get styled tokens for a specific line.
            
            Args:
                line_number: Line number to tokenize
                
            Returns:
                StyleAndTextTuples: List of (style, text) tuples
            """
            if line_number >= len(document.lines):
                return []
            
            line: str = document.lines[line_number]
            tokens: StyleAndTextTuples = []
            
            # Split line into tokens
            parts: List[str] = line.split()
            
            if not parts:
                return [("", line)]
            
            # First token is the command
            command: str = parts[0]
            
            # Determine command style
            if command in self.HELPER_COMMANDS:
                # Helper commands in cyan/bold
                tokens.append(("class:helper", command))
            elif command in self.COMMON_COMMANDS:
                # Known Linux commands in green
                tokens.append(("class:known-command", command))
            else:
                # Unknown commands in default color
                tokens.append(("class:command", command))
            
            # Add rest of line after command
            cmd_start: int = line.find(command)
            cmd_end: int = cmd_start + len(command)
            
            if cmd_end < len(line):
                # Get everything after the command
                rest: str = line[cmd_end:]
                tokens.extend(self._highlight_text(rest))
            
            return tokens
        
        return get_line_tokens
    
    def _highlight_text(self, text: str) -> StyleAndTextTuples:
        """
        Highlight special characters in command arguments.
        
        Args:
            text: Text to highlight
            
        Returns:
            StyleAndTextTuples: Styled tokens
        """
        tokens: StyleAndTextTuples = []
        current: str = ""
        in_string: bool = False
        quote_char: str = ""
        
        i: int = 0
        while i < len(text):
            char: str = text[i]
            
            # Handle quoted strings
            if char in ('"', "'") and not in_string:
                if current:
                    tokens.append(("class:argument", current))
                    current = ""
                in_string = True
                quote_char = char
                current = char
            elif in_string and char == quote_char:
                current += char
                tokens.append(("class:string", current))
                current = ""
                in_string = False
                quote_char = ""
            elif in_string:
                current += char
            # Handle pipes and redirects
            elif char in ("|", ">", "<"):
                if current:
                    tokens.append(("class:argument", current))
                    current = ""
                # Check for >> or <<
                if i + 1 < len(text) and text[i + 1] in (">", "<"):
                    tokens.append(("class:operator", char + text[i + 1]))
                    i += 1
                else:
                    tokens.append(("class:operator", char))
            else:
                current += char
            
            i += 1
        
        # Add remaining text
        if current:
            if in_string:
                tokens.append(("class:string", current))
            else:
                tokens.append(("class:argument", current))
        
        return tokens


# Define custom style for the lexer
from typing import Dict

OCN_STYLE: Dict[str, str] = {
    "helper": "#00ffff bold",  # Bright cyan, bold
    "known-command": "#00ff00",  # Green
    "command": "#ffffff",  # White
    "argument": "#ffffff",  # White
    "string": "#ffff00",  # Yellow
    "operator": "#ff00ff",  # Magenta
}


