"""
OCN CLI - Diagnostic Tool for OCN Servers

A cross-platform command-line interface for remote troubleshooting and diagnostics
of OCN (Open Control Network) server installations.
"""

from ocn_cli.version import __version__

__all__ = ["__version__"]

