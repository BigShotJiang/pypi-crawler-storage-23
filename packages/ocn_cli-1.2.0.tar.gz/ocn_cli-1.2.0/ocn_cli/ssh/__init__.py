"""SSH module for OCN CLI."""

from ocn_cli.ssh.connection import SSHConnection
from ocn_cli.ssh.command_executor import CommandExecutor, CommandResult
from ocn_cli.ssh.errors import (
    SSHConnectionError,
    NetworkUnreachableError,
    AuthenticationFailedError,
    ConnectionTimeoutError,
    SSHConnectionRefusedError,
    HostKeyChangedError,
)

__all__ = [
    "SSHConnection",
    "CommandExecutor",
    "CommandResult",
    "SSHConnectionError",
    "NetworkUnreachableError",
    "AuthenticationFailedError",
    "ConnectionTimeoutError",
    "SSHConnectionRefusedError",
    "HostKeyChangedError",
]


