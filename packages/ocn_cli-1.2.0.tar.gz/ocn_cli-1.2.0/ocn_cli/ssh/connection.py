"""SSH connection management."""

import errno
import socket
from typing import List, Optional

import paramiko

from ocn_cli.ssh.errors import (
    AuthenticationFailedError,
    SSHConnectionRefusedError,
    ConnectionTimeoutError,
    HostKeyChangedError,
    NetworkUnreachableError,
    SSHConnectionError,
)
from ocn_cli.ui.formatters import format_warning
from ocn_cli.ui.messages import messages


class SSHConnection:
    """Manages SSH connection to OCN server."""
    
    def __init__(self) -> None:
        """Initialize the SSH connection manager."""
        self.client: paramiko.SSHClient = paramiko.SSHClient()
        self.host: str = ""
        self.port: int = 22
        self.username: str = ""
        self._is_connected: bool = False
        
        # Configure SSH client
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        # Warn about auto-adding host keys
        format_warning(
            "⚠️  Host keys are automatically accepted. "
            "Verify server identity when connecting to new hosts."
        )
    
    def connect(
        self,
        host: str,
        port: int,
        username: str,
        pkey: paramiko.PKey,
    ) -> None:
        """
        Establish SSH connection to the server.
        
        Args:
            host: Hostname or IP address
            port: SSH port number
            username: SSH username
            pkey: SSH private key
            
        Raises:
            SSHConnectionError: If connection fails
        """
        self.host = host
        self.port = port
        self.username = username
        
        try:
            # Attempt connection
            self.client.connect(
                hostname=host,
                port=port,
                username=username,
                pkey=pkey,
                timeout=30.0,  # Connection timeout
                auth_timeout=10.0,  # Authentication timeout
                banner_timeout=10.0,
                look_for_keys=False,  # Don't search for keys, use provided
                allow_agent=False,  # Don't use SSH agent
            )
            
            # Enable keep-alive
            transport: Optional[paramiko.Transport] = self.client.get_transport()
            if transport:
                transport.set_keepalive(60)  # Send keepalive every 60 seconds
            
            self._is_connected = True
            
        except paramiko.AuthenticationException as e:
            hints: List[str] = messages.format_hints(
                messages.HINTS_AUTH_FAILED,
                user=username,
                host=host,
                port=str(port)
            )
            raise AuthenticationFailedError(
                f"SSH authentication failed for {username}@{host}",
                hints=hints
            ) from e
            
        except paramiko.SSHException as e:
            error_str: str = str(e).lower()
            
            if "host key" in error_str:
                raise HostKeyChangedError(
                    f"Host key verification failed for {host}. "
                    "This may indicate a man-in-the-middle attack or server reinstallation.",
                    hints=[
                        "Verify the server identity manually",
                        "If server was reinstalled, remove old host key:",
                        f"  ssh-keygen -R {host}",
                        "DO NOT proceed if you suspect a security issue",
                    ]
                ) from e
            else:
                raise SSHConnectionError(
                    f"SSH error: {e}",
                    hints=[
                        f"Check SSH service on {host}:{port}",
                        "Verify network connectivity",
                        "Check firewall rules",
                    ]
                ) from e
                
        except socket.timeout as e:
            hints = messages.format_hints(
                messages.HINTS_CONNECTION_TIMEOUT,
                host=host,
                port=str(port)
            )
            raise ConnectionTimeoutError(
                f"Connection to {host}:{port} timed out",
                hints=hints
            ) from e
            
        except socket.gaierror as e:
            hints = messages.format_hints(
                messages.HINTS_NETWORK_UNREACHABLE,
                host=host,
                port=str(port)
            )
            raise NetworkUnreachableError(
                f"Could not resolve hostname: {host}",
                hints=hints
            ) from e
            
        except OSError as e:
            # Catch connection refused and other network errors
            if getattr(e, "errno", None) == errno.ECONNREFUSED:
                hints = messages.format_hints(
                    messages.HINTS_CONNECTION_REFUSED,
                    host=host,
                    port=str(port)
                )
                raise SSHConnectionRefusedError(
                    f"Connection refused by {host}:{port}",
                    hints=hints
                ) from e

            error_str = str(e).lower()
            if "unreachable" in error_str or "no route" in error_str:
                hints = messages.format_hints(
                    messages.HINTS_NETWORK_UNREACHABLE,
                    host=host,
                    port=str(port)
                )
                raise NetworkUnreachableError(
                    f"Network unreachable: {host}",
                    hints=hints
                ) from e
            else:
                raise SSHConnectionError(
                    f"Connection error: {e}",
                    hints=[
                        f"Check network connectivity to {host}",
                        "Verify firewall settings",
                        "Ensure SSH service is running",
                    ]
                ) from e
    
    def is_connected(self) -> bool:
        """
        Check if SSH connection is active.
        
        Returns:
            bool: True if connected and active
        """
        if not self._is_connected:
            return False
        
        transport: Optional[paramiko.Transport] = self.client.get_transport()
        if transport is None:
            self._is_connected = False
            return False
        
        return transport.is_active()
    
    def get_client(self) -> paramiko.SSHClient:
        """
        Get the underlying Paramiko SSH client.
        
        Returns:
            paramiko.SSHClient: SSH client instance
        """
        return self.client
    
    def close(self) -> None:
        """Close the SSH connection."""
        if self.client:
            self.client.close()
            self._is_connected = False


