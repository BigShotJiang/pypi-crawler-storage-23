"""Remote command execution via SSH."""

import select
from dataclasses import dataclass
from typing import Iterator, Optional, Tuple

import paramiko

from ocn_cli.ssh.connection import SSHConnection


@dataclass
class CommandResult:
    """Result of command execution."""
    
    stdout: str
    stderr: str
    exit_code: int


class CommandExecutor:
    """Executes commands on remote server via SSH."""
    
    def __init__(self, connection: SSHConnection, sudo_password: Optional[str] = None) -> None:
        """
        Initialize command executor.
        
        Args:
            connection: Active SSH connection
            sudo_password: Optional sudo password for commands requiring elevated privileges
        """
        self.connection: SSHConnection = connection
        self.sudo_password: Optional[str] = sudo_password
        self._current_channel: Optional[paramiko.Channel] = None
    
    def execute(self, command: str, stream: bool = True) -> CommandResult:
        """
        Execute a command on the remote server.
        
        Args:
            command: Command to execute
            stream: Whether to stream output in real-time
            
        Returns:
            CommandResult: Command execution result
            
        Raises:
            RuntimeError: If not connected or execution fails
        """
        if not self.connection.is_connected():
            raise RuntimeError("Not connected to SSH server")
        
        client: paramiko.SSHClient = self.connection.get_client()
        
        # Use sudo -S (read password from stdin) when sudo is needed; password passed via stdin, not shell
        actual_command: str = command
        needs_sudo_password: bool = (
            command.strip().startswith("sudo") and self.sudo_password is not None
        )
        if needs_sudo_password:
            actual_command = "sudo -S " + command.strip()[4:].strip()
        
        try:
            stdin, stdout, stderr = client.exec_command(actual_command, get_pty=False)
            
            if needs_sudo_password and self.sudo_password:
                stdin.write(self.sudo_password + "\n")
                stdin.flush()
                try:
                    stdin.channel.shutdown_write()
                except (OSError, AttributeError):
                    pass
            
            # Get channel for streaming
            channel: paramiko.Channel = stdout.channel
            self._current_channel = channel
            
            stdout_data: str = ""
            stderr_data: str = ""
            
            if stream:
                # Stream output in real-time
                for stream_name, chunk in self.stream_output(channel):
                    if stream_name == "stdout":
                        stdout_data += chunk
                    else:
                        stderr_data += chunk
            else:
                # Buffer all output
                stdout_data = stdout.read().decode("utf-8", errors="replace")
                stderr_data = stderr.read().decode("utf-8", errors="replace")
            
            # Get exit code
            exit_code: int = channel.recv_exit_status()
            
            self._current_channel = None
            
            return CommandResult(
                stdout=stdout_data,
                stderr=stderr_data,
                exit_code=exit_code
            )
            
        except UnicodeDecodeError:
            # Handle binary output
            return CommandResult(
                stdout="[Binary output - cannot display]",
                stderr="",
                exit_code=-1
            )
        except Exception as e:
            raise RuntimeError(f"Command execution failed: {e}") from e
    
    def stream_output(self, channel: paramiko.Channel) -> Iterator[Tuple[str, str]]:
        """
        Stream command output in real-time.
        
        Args:
            channel: SSH channel
            
        Yields:
            Tuple[str, str]: (stream_name, chunk) where stream_name is 'stdout' or 'stderr'
        """
        from ocn_cli.ui.formatters import console
        
        # Set channel to non-blocking
        channel.setblocking(False)
        
        while not channel.exit_status_ready():
            # Use select to check for available data
            readable, _, _ = select.select([channel], [], [], 0.1)
            
            if channel in readable:
                # Check for stdout
                if channel.recv_ready():
                    try:
                        data: bytes = channel.recv(4096)
                        if data:
                            text: str = data.decode("utf-8", errors="replace")
                            console.print(text, end="", markup=False, highlight=False)
                            yield ("stdout", text)
                    except Exception:
                        pass
                
                # Check for stderr
                if channel.recv_stderr_ready():
                    try:
                        data = channel.recv_stderr(4096)
                        if data:
                            text = data.decode("utf-8", errors="replace")
                            console.print(f"[red]{text}[/red]", end="", markup=True)
                            yield ("stderr", text)
                    except Exception:
                        pass
        
        # Read any remaining output
        while channel.recv_ready():
            try:
                data = channel.recv(4096)
                if data:
                    text = data.decode("utf-8", errors="replace")
                    console.print(text, end="", markup=False, highlight=False)
                    yield ("stdout", text)
            except Exception:
                break
        
        while channel.recv_stderr_ready():
            try:
                data = channel.recv_stderr(4096)
                if data:
                    text = data.decode("utf-8", errors="replace")
                    console.print(f"[red]{text}[/red]", end="", markup=True)
                    yield ("stderr", text)
            except Exception:
                break
    
    def send_interrupt(self) -> None:
        """Send interrupt signal (Ctrl+C) to current command."""
        if self._current_channel and not self._current_channel.closed:
            try:
                self._current_channel.send(b"\x03")  # Send Ctrl+C
            except Exception:
                pass


