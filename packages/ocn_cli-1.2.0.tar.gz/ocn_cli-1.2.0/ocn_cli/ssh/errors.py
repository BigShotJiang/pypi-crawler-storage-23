"""SSH-specific error types and classification."""

from typing import List, Optional


class SSHConnectionError(Exception):
    """Base class for SSH connection errors."""
    
    def __init__(self, message: str, hints: Optional[List[str]] = None) -> None:
        """
        Initialize SSH connection error.
        
        Args:
            message: Error message
            hints: Optional troubleshooting hints
        """
        super().__init__(message)
        self.message: str = message
        self.hints: List[str] = hints or []


class NetworkUnreachableError(SSHConnectionError):
    """Raised when the network is unreachable."""
    pass


class AuthenticationFailedError(SSHConnectionError):
    """Raised when SSH authentication fails."""
    pass


class ConnectionTimeoutError(SSHConnectionError):
    """Raised when SSH connection times out."""
    pass


class SSHConnectionRefusedError(SSHConnectionError):
    """Raised when SSH connection is refused."""
    pass


class HostKeyChangedError(SSHConnectionError):
    """Raised when SSH host key has changed (potential MITM)."""
    pass


