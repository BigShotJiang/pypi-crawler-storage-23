"""Version information for OCN CLI."""

__version__ = "1.2.0"


