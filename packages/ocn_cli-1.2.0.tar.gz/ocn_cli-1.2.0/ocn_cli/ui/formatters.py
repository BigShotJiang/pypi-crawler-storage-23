"""Rich-based output formatting utilities."""

from typing import List, Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.theme import Theme

# Custom theme for OCN CLI
ocn_theme = Theme({
    "success": "bold green",
    "error": "bold red",
    "warning": "bold yellow",
    "info": "bold cyan",
    "prompt": "bright_green",
    "command": "white",
    "helper": "bright_cyan bold",
})

# Global console instance
console = Console(theme=ocn_theme)


def format_success(message: str) -> None:
    """
    Display a success message.
    
    Args:
        message: Success message to display
    """
    console.print(message, style="success")


def format_error(message: str, hints: Optional[List[str]] = None) -> None:
    """
    Display an error message with optional troubleshooting hints.
    
    Args:
        message: Error message to display
        hints: Optional list of troubleshooting hints
    """
    console.print(message, style="error")
    
    if hints:
        console.print("\nTroubleshooting hints:", style="warning")
        for hint in hints:
            console.print(f"  • {hint}", style="warning")


def format_warning(message: str) -> None:
    """
    Display a warning message.
    
    Args:
        message: Warning message to display
    """
    console.print(message, style="warning")


def format_info(message: str) -> None:
    """
    Display an informational message.
    
    Args:
        message: Info message to display
    """
    console.print(message, style="info")


def format_panel(title: str, content: str, border_style: str = "cyan") -> Panel:
    """
    Create a Rich Panel for grouped content.
    
    Args:
        title: Panel title
        content: Panel content
        border_style: Border color style
        
    Returns:
        Panel: Rich Panel object
    """
    return Panel(content, title=title, border_style=border_style, padding=(1, 2))


def format_table(
    headers: List[str],
    rows: List[List[str]],
    title: Optional[str] = None,
    show_header: bool = True,
) -> Table:
    """
    Create a Rich Table for structured data.
    
    Args:
        headers: Column headers
        rows: Data rows
        title: Optional table title
        show_header: Whether to show the header row
        
    Returns:
        Table: Rich Table object
    """
    table = Table(title=title, show_header=show_header, border_style="cyan")
    
    # Add columns
    for header in headers:
        table.add_column(header, style="cyan")
    
    # Add rows
    for row in rows:
        table.add_row(*row)
    
    return table


def print_panel(title: str, content: str, border_style: str = "cyan") -> None:
    """
    Print a Rich Panel to the console.
    
    Args:
        title: Panel title
        content: Panel content
        border_style: Border color style
    """
    panel: Panel = format_panel(title, content, border_style)
    console.print(panel)


def print_table(
    headers: List[str],
    rows: List[List[str]],
    title: Optional[str] = None,
    show_header: bool = True,
) -> None:
    """
    Print a Rich Table to the console.
    
    Args:
        headers: Column headers
        rows: Data rows
        title: Optional table title
        show_header: Whether to show the header row
    """
    table: Table = format_table(headers, rows, title, show_header)
    console.print(table)


