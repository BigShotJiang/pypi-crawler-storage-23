"""Standardized user messages for the OCN CLI."""

from typing import Dict, List


class Messages:
    """Container for all user-facing messages."""
    
    # Welcome and version
    WELCOME: str = "🔧 OCN CLI v{version}"
    
    # Connection messages
    CONNECTING: str = "Connecting to {host} as {user}..."
    CONNECTED: str = "✅ Connected to {host}"
    CONNECTION_FAILED: str = "❌ Connection failed: {error}"
    
    
    # SSH messages
    SSH_ESTABLISHING: str = "🔌 Establishing SSH connection..."
    SSH_DISCONNECTED: str = "⚠️  SSH connection lost"
    SSH_CONNECTION_CLOSED: str = "Connection to {host} closed unexpectedly"
    
    # Shell messages
    SHELL_STARTED: str = "Interactive shell started. Type 'help' for available commands."
    SHELL_EXITING: str = "Goodbye! 👋"
    
    # Error troubleshooting hints
    HINTS_NETWORK_UNREACHABLE: List[str] = [
        "Check network connectivity to {host}",
        "Verify the hostname/IP address is correct",
        "Test with: ping {host}",
        "Check if a VPN connection is required",
    ]
    
    HINTS_CONNECTION_REFUSED: List[str] = [
        "Verify SSH service is running on port {port}",
        "Check firewall rules allow SSH connections",
        "Test with: telnet {host} {port}",
        "Confirm the OCN server is online",
    ]
    
    HINTS_CONNECTION_TIMEOUT: List[str] = [
        "Check network connectivity to {host}",
        "Verify SSH service is running on port {port}",
        "Check firewall rules allow SSH connections",
        "Test network latency: ping {host}",
    ]
    
    HINTS_AUTH_FAILED: List[str] = [
        "Verify the SSH key is authorized on the server",
        "Check ~/.ssh/authorized_keys on the OCN server",
        "Ensure the user '{user}' exists on the server",
        "Verify key file permissions (should be 600)",
        "Try using --key with a different SSH key",
    ]
    
    HINTS_KEY_ERROR: List[str] = [
        "Verify the key file exists and is readable",
        "Check key file format (should be valid SSH private key)",
        "Ensure key file has correct permissions (chmod 600)",
        "Try generating a new SSH keypair",
        "Ensure the key is authorized on the OCN server",
    ]
    
    # General messages
    NO_OUTPUT: str = "(no output)"
    COMMAND_INTERRUPTED: str = "^C"
    INVALID_ARGUMENTS: str = "❌ Invalid arguments. Use --help for usage information."
    
    @staticmethod
    def format_hints(hints: List[str], **kwargs: str) -> List[str]:
        """
        Format troubleshooting hints with variable substitution.
        
        Args:
            hints: List of hint templates
            **kwargs: Variables to substitute in hints
            
        Returns:
            List[str]: Formatted hints
        """
        return [hint.format(**kwargs) for hint in hints]


# Global messages instance
messages = Messages()

