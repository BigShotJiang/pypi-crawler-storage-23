"""Main CLI entry point using Typer."""

import sys
from pathlib import Path
from typing import List, Optional

import typer

from ocn_cli.auth import KeyManager
from ocn_cli.shell import InteractiveShell
from ocn_cli.ssh import (
    CommandExecutor,
    SSHConnection,
    SSHConnectionError,
)
from ocn_cli.ui.formatters import console, format_error, format_info
from ocn_cli.ui.messages import messages
from ocn_cli.utils.platform import get_default_username
from ocn_cli.version import __version__

# Create Typer app
app = typer.Typer(
    name="ocn-cli",
    help="OCN CLI - Diagnostic tool for OCN (Open Control Network) servers",
    add_completion=False,
    rich_markup_mode="rich",
)


def version_callback(value: bool) -> None:
    """
    Display version information.
    
    Args:
        value: Whether --version was specified
    """
    if value:
        console.print(f"OCN CLI version {__version__}")
        raise typer.Exit()


@app.command()
def main(
    host: str = typer.Option(
        ...,
        "--host",
        "-h",
        help="OCN server hostname or IP address",
        show_default=False,
    ),
    key: Path = typer.Option(
        ...,
        "--key",
        "-k",
        help="Path to SSH private key",
        exists=False,  # We'll check existence ourselves
        show_default=False,
    ),
    user: Optional[str] = typer.Option(
        None,
        "--user",
        "-u",
        help="SSH username (defaults to current user)",
    ),
    port: int = typer.Option(
        22,
        "--port",
        "-p",
        help="SSH port number",
    ),
    sudo_password: Optional[str] = typer.Option(
        None,
        "--sudo-password",
        help="Sudo password for remote commands (will prompt if not provided)",
        hide_input=True,
    ),
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
) -> None:
    """
    Connect to an OCN server and start an interactive diagnostic shell.
    
    Examples:
    
      # Connect to a server:
      
      ocn-cli --host server.ocn.local --key ~/.ssh/id_rsa
      
      # Specify custom user and port:
      
      ocn-cli --host 192.168.1.100 --key ~/.ssh/ocn_key --user admin --port 2222
    """
    # Set default user if not provided
    if user is None:
        user = get_default_username()
    
    # Display welcome
    console.print(messages.WELCOME.format(version=__version__), style="info")
    console.print(messages.CONNECTING.format(host=host, user=user))
    console.print()
    
    # Initialize components
    key_manager: Optional[KeyManager] = None
    ssh_connection: Optional[SSHConnection] = None
    
    try:
        with KeyManager() as key_manager:
            # Load user-provided SSH key
            format_info(f"Loading SSH key: {key}")
            ssh_key = key_manager.load_user_key(key)
            
            # Establish SSH connection
            ssh_connection = _connect_to_server(host, port, user, ssh_key)
            
            # Prompt for sudo password if not provided and needed
            sudo_pwd: Optional[str] = sudo_password
            if sudo_pwd is None:
                from rich.prompt import Prompt
                console.print()
                sudo_pwd = Prompt.ask(
                    "🔑 Enter sudo password for remote server (optional, press Enter to skip)",
                    password=True,
                    console=console,
                    default=""
                )
                if not sudo_pwd:
                    sudo_pwd = None
            
            # Create command executor with sudo password
            executor = CommandExecutor(ssh_connection, sudo_password=sudo_pwd)
            
            # Validate sudo password if provided
            if sudo_pwd:
                format_info("Validating sudo credentials...")
                if not _validate_sudo_password(executor):
                    format_error(
                        "Sudo password validation failed",
                        hints=[
                            "The provided sudo password is incorrect",
                            "Continuing without sudo - some diagnostics may fail",
                            "You can exit and reconnect with the correct password",
                        ]
                    )
                    # Clear the invalid password
                    executor.sudo_password = None
                    console.print()
                else:
                    format_info("✅ Sudo credentials validated")
                    console.print()
            
            # Start interactive shell
            shell = InteractiveShell(ssh_connection, executor, host)
            shell.run()
            
    except SSHConnectionError as e:
        # SSH connection errors
        format_error(e.message, hints=e.hints)
        sys.exit(3)
        
    except ValueError as e:
        # Key loading/decryption errors
        hints_key: List[str] = messages.format_hints(
            messages.HINTS_KEY_ERROR,
            host=host,
            user=user,
            port=str(port)
        )
        format_error(str(e), hints=hints_key)
        sys.exit(2)
        
    except FileNotFoundError as e:
        format_error(str(e))
        sys.exit(1)
        
    except KeyboardInterrupt:
        console.print("\n\n" + messages.SHELL_EXITING, style="success")
        sys.exit(0)
        
    except Exception as e:
        format_error(f"Unexpected error: {e}")
        import traceback
        console.print("\n[dim]" + traceback.format_exc() + "[/dim]")
        sys.exit(1)
        
    finally:
        # Clean up
        if ssh_connection:
            ssh_connection.close()


def _connect_to_server(host: str, port: int, username: str, pkey) -> SSHConnection:  # type: ignore
    """
    Establish SSH connection to OCN server.
    
    Args:
        host: Hostname or IP
        port: SSH port
        username: SSH username
        pkey: SSH private key
        
    Returns:
        SSHConnection: Established connection
        
    Raises:
        SSHConnectionError: If connection fails
    """
    format_info(messages.SSH_ESTABLISHING)
    
    connection = SSHConnection()
    connection.connect(host, port, username, pkey)
    
    console.print(messages.CONNECTED.format(host=host), style="success")
    console.print()
    
    return connection


def _validate_sudo_password(executor: CommandExecutor) -> bool:
    """
    Validate that the sudo password works.
    
    Args:
        executor: Command executor with sudo password
        
    Returns:
        bool: True if password is valid
    """
    try:
        # Try a simple sudo command
        result = executor.execute("sudo whoami", stream=False)
        
        # Check if it succeeded and returned "root"
        if result.exit_code == 0 and "root" in result.stdout.strip():
            return True
        
        # Check if stderr indicates password failure
        if "password" in result.stderr.lower() or "incorrect" in result.stderr.lower():
            return False
        
        # If command failed for other reasons, still consider password invalid
        return False
        
    except Exception:
        return False


if __name__ == "__main__":
    app()

