"""Package validation for offline updates."""

import os
import shlex
from typing import Dict, List

from ocn_cli.ssh.command_executor import CommandExecutor


class PackageValidator:
    """Validate offline update packages."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """
        Initialize package validator.
        
        Args:
            executor: Command executor for remote commands
        """
        self.executor: CommandExecutor = executor
    
    def validate_package(self, package_path: str) -> Dict[str, bool]:
        """
        Validate an offline update package structure.
        
        Args:
            package_path: Path to the package on remote server
            
        Returns:
            Dict[str, bool]: Validation results
        """
        results: Dict[str, bool] = {
            "package_exists": False,
            "is_tarball": False,
            "has_installer": False,
            "has_images": False,
            "has_version": False,
        }
        
        safe_package_path: str = shlex.quote(package_path)
        
        # Check if package exists
        check_result = self.executor.execute(f"test -f {safe_package_path} && echo 'exists'", stream=False)
        results["package_exists"] = check_result.exit_code == 0 and "exists" in check_result.stdout
        
        if not results["package_exists"]:
            return results
        
        # Check if it's a valid tar.gz
        check_result = self.executor.execute(
            f"file {safe_package_path} | grep -q 'gzip compressed' && echo 'valid'",
            stream=False,
        )
        results["is_tarball"] = check_result.exit_code == 0 and "valid" in check_result.stdout
        
        # Extract to temp location for validation
        temp_dir: str = f"/tmp/ocn-validate-{id(self)}"
        safe_temp_dir: str = shlex.quote(temp_dir)
        self.executor.execute(f"sudo mkdir -p {safe_temp_dir}", stream=False)
        extract_result = self.executor.execute(
            f"sudo tar -xzf {safe_package_path} -C {safe_temp_dir}",
            stream=False,
        )
        
        if extract_result.exit_code == 0:
            # Check for required components (paths passed to _check_path_exists are already quoted there)
            results["has_installer"] = self._check_path_exists(f"{temp_dir}/ocn-installer")
            results["has_images"] = self._check_path_exists(f"{temp_dir}/ocn-installer/images")
            results["has_version"] = self._check_path_exists(f"{temp_dir}/ocn-installer/VERSION")
        
        # Cleanup validation temp dir
        self.executor.execute(f"sudo rm -rf {safe_temp_dir}", stream=False)
        
        return results
    
    def _check_path_exists(self, path: str) -> bool:
        """Check if a path exists on remote server."""
        safe_path: str = shlex.quote(path)
        result = self.executor.execute(f"test -e {safe_path} && echo 'exists'", stream=False)
        return result.exit_code == 0 and "exists" in result.stdout
    
    def get_package_version(self, extracted_path: str) -> str:
        """
        Get version from extracted package.
        
        Args:
            extracted_path: Path to extracted package directory
            
        Returns:
            str: Version string or "unknown"
        """
        version_path: str = os.path.join(extracted_path, "ocn-installer", "VERSION")
        safe_version_path: str = shlex.quote(version_path)
        result = self.executor.execute(f"cat {safe_version_path}", stream=False)
        
        if result.exit_code == 0 and result.stdout.strip():
            return result.stdout.strip()
        
        return "unknown"
    
    def list_images(self, extracted_path: str) -> List[str]:
        """
        List Docker images in the package.
        
        Args:
            extracted_path: Path to extracted package directory
            
        Returns:
            List[str]: List of image filenames
        """
        images_dir: str = os.path.join(extracted_path, "ocn-installer", "images")
        safe_images_dir: str = shlex.quote(images_dir)
        result = self.executor.execute(
            f"find {safe_images_dir} -maxdepth 1 -name '*.tar.gz' -print0 2>/dev/null",
            stream=False,
        )
        
        if result.exit_code == 0 and result.stdout:
            parts: List[str] = [p for p in result.stdout.rstrip("\0").split("\0") if p]
            return [os.path.basename(path) for path in parts]
        
        return []

