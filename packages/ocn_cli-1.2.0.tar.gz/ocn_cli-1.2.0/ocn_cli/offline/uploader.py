"""File upload utilities for offline updates."""

from pathlib import Path
from typing import Callable, Optional

import paramiko

from ocn_cli.ssh.connection import SSHConnection
from ocn_cli.ui.formatters import console


class FileUploader:
    """Upload files to remote server via SFTP."""
    
    def __init__(self, connection: SSHConnection) -> None:
        """
        Initialize file uploader.
        
        Args:
            connection: Active SSH connection
        """
        self.connection: SSHConnection = connection
    
    def upload(
        self,
        local_path: Path,
        remote_path: str,
        progress_callback: Optional[Callable[[int, int], None]] = None
    ) -> bool:
        """
        Upload a file to the remote server.
        
        Args:
            local_path: Local file path
            remote_path: Remote destination path
            progress_callback: Optional callback for progress updates (bytes_transferred, total_bytes)
            
        Returns:
            bool: True if upload successful
            
        Raises:
            FileNotFoundError: If local file doesn't exist
            RuntimeError: If upload fails
        """
        if not local_path.exists():
            raise FileNotFoundError(f"Local file not found: {local_path}")
        
        if not local_path.is_file():
            raise ValueError(f"Path is not a file: {local_path}")
        
        sftp: Optional[paramiko.SFTPClient] = None
        try:
            sftp = self.connection.get_client().open_sftp()
            
            # Get file size for progress tracking
            file_size: int = local_path.stat().st_size
            bytes_transferred: int = 0
            
            def sftp_callback(transferred: int, total: int) -> None:
                """SFTP progress callback."""
                nonlocal bytes_transferred
                bytes_transferred = transferred
                if progress_callback:
                    progress_callback(transferred, total)
            
            # Upload file
            sftp.put(
                str(local_path),
                remote_path,
                callback=sftp_callback if progress_callback else None
            )
            return True
            
        except Exception as e:
            raise RuntimeError(f"Upload failed: {e}") from e
        finally:
            if sftp is not None:
                sftp.close()
    
    def upload_with_progress(self, local_path: Path, remote_path: str) -> bool:
        """
        Upload file with Rich progress bar.
        
        Args:
            local_path: Local file path
            remote_path: Remote destination path
            
        Returns:
            bool: True if upload successful
        """
        from rich.progress import (
            BarColumn,
            DownloadColumn,
            Progress,
            TaskID,
            TextColumn,
            TimeRemainingColumn,
            TransferSpeedColumn,
        )
        
        file_size: int = local_path.stat().st_size
        
        with Progress(
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeRemainingColumn(),
            console=console,
        ) as progress:
            task: TaskID = progress.add_task(
                f"Uploading {local_path.name}",
                total=file_size
            )
            
            def update_progress(transferred: int, total: int) -> None:
                progress.update(task, completed=transferred)
            
            success: bool = self.upload(local_path, remote_path, update_progress)
            
            if success:
                progress.update(task, completed=file_size)
            
            return success

