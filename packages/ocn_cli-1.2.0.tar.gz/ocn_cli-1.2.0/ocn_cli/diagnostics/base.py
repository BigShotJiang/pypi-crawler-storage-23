"""Base classes and types for diagnostic checks."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List


class CheckSeverity(Enum):
    """Severity level for diagnostic checks."""
    
    CRITICAL = "critical"
    WARNING = "warning"
    INFO = "info"


@dataclass
class CheckResult:
    """Result of a diagnostic check execution."""
    
    check_name: str
    category: str
    passed: bool
    severity: CheckSeverity
    message: str
    details: Dict[str, Any] = field(default_factory=dict)
    remediation: List[str] = field(default_factory=list)
    execution_time_ms: float = 0.0
    
    def __post_init__(self) -> None:
        """Validate result data."""
        if not self.check_name:
            raise ValueError("check_name is required")
        if not self.category:
            raise ValueError("category is required")
        if not self.message:
            raise ValueError("message is required")


class DiagnosticCheck(ABC):
    """Abstract base class for all diagnostic checks."""
    
    @property
    @abstractmethod
    def name(self) -> str:
        """
        Unique name for this check.
        
        Returns:
            str: Check name (e.g., "internet_connectivity")
        """
        pass
    
    @property
    @abstractmethod
    def category(self) -> str:
        """
        Category this check belongs to.
        
        Returns:
            str: Category name (e.g., "network", "docker", "system")
        """
        pass
    
    @property
    @abstractmethod
    def severity(self) -> CheckSeverity:
        """
        Severity level of this check.
        
        Returns:
            CheckSeverity: Severity level
        """
        pass
    
    @property
    def description(self) -> str:
        """
        Human-readable description of what this check does.
        
        Returns:
            str: Check description
        """
        return f"{self.name} check"
    
    async def can_run(self) -> bool:
        """
        Check if this diagnostic can run (dependencies available).
        
        Returns:
            bool: True if check can run
        """
        # Default: assume all checks can run
        return True
    
    @abstractmethod
    async def execute(self) -> CheckResult:
        """
        Execute the diagnostic check.
        
        Returns:
            CheckResult: Result of the check
        """
        pass

