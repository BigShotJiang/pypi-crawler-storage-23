"""Critical services diagnostic checks."""

import re
from typing import Dict, List

from ocn_cli.diagnostics.base import CheckResult, CheckSeverity, DiagnosticCheck
from ocn_cli.ssh.command_executor import CommandExecutor


class DockerDaemonCheck(DiagnosticCheck):
    """Check Docker daemon status."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "docker_daemon"
    
    @property
    def category(self) -> str:
        return "services"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.CRITICAL
    
    @property
    def description(self) -> str:
        return "Check Docker daemon service status"
    
    async def execute(self) -> CheckResult:
        """Execute Docker daemon check."""
        # Check systemd service status
        result = self.executor.execute("systemctl is-active docker", stream=False)
        
        is_active: bool = result.exit_code == 0 and result.stdout.strip() == "active"
        
        if not is_active:
            # Get detailed status
            status_result = self.executor.execute("systemctl status docker", stream=False)
            
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Docker daemon is not running",
                details={"status_output": status_result.stdout},
                remediation=[
                    "Docker daemon is not active",
                    "",
                    "Actions:",
                    "  1. Start Docker: sudo systemctl start docker",
                    "  2. Enable on boot: sudo systemctl enable docker",
                    "  3. Check status: sudo systemctl status docker",
                    "  4. Check logs: sudo journalctl -u docker -n 50",
                    "",
                    "If Docker fails to start, check:",
                    "  - Disk space availability",
                    "  - Configuration: /etc/docker/daemon.json",
                ]
            )
        
        # Verify Docker daemon is responding
        docker_info = self.executor.execute("sudo docker info", stream=False)
        
        if docker_info.exit_code != 0:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Docker daemon running but not responding",
                remediation=[
                    "Docker service is active but 'docker info' fails",
                    "This may indicate permission or daemon issues",
                    "",
                    "Actions:",
                    "  1. Restart Docker: sudo systemctl restart docker",
                    "  2. Check logs: sudo journalctl -u docker -n 100",
                    "  3. Verify socket: sudo ls -l /var/run/docker.sock",
                    "  4. Check permissions: groups (ensure user in docker group)",
                ]
            )
        
        # Check if enabled
        enabled_result = self.executor.execute("systemctl is-enabled docker", stream=False)
        is_enabled: bool = enabled_result.exit_code == 0 and 'enabled' in enabled_result.stdout
        
        if not is_enabled:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.WARNING,
                message="Docker daemon active but not enabled on boot",
                remediation=[
                    "Docker will not start automatically after reboot",
                    "Enable Docker: sudo systemctl enable docker",
                ]
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=self.severity,
            message="Docker daemon active and enabled",
        )


class NginxServiceCheck(DiagnosticCheck):
    """Check nginx web server status."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "nginx_service"
    
    @property
    def category(self) -> str:
        return "services"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.CRITICAL
    
    @property
    def description(self) -> str:
        return "Check nginx web server status"
    
    async def execute(self) -> CheckResult:
        """Execute nginx service check."""
        # Check if nginx is active
        result = self.executor.execute("systemctl is-active nginx", stream=False)
        
        is_active: bool = result.exit_code == 0 and result.stdout.strip() == "active"
        
        if not is_active:
            status_result = self.executor.execute("systemctl status nginx", stream=False)
            
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="nginx is not running",
                details={"status_output": status_result.stdout},
                remediation=[
                    "nginx web server is not active",
                    "",
                    "Actions:",
                    "  1. Test config: sudo nginx -t",
                    "  2. Start nginx: sudo systemctl start nginx",
                    "  3. Enable on boot: sudo systemctl enable nginx",
                    "  4. Check logs: sudo journalctl -u nginx -n 50",
                    "",
                    "If nginx fails to start:",
                    "  - Check port conflicts: sudo netstat -tlnp | grep ':80\\|:443'",
                    "  - Verify config syntax: sudo nginx -t",
                ]
            )
        
        # Check if nginx is listening on expected ports
        port_result = self.executor.execute("sudo netstat -tlnp | grep nginx || sudo ss -tlnp | grep nginx", stream=False)
        
        listening_ports: List[int] = []
        if port_result.exit_code == 0:
            for match in re.finditer(r':(\d+)\s', port_result.stdout):
                port: int = int(match.group(1))
                listening_ports.append(port)
        
        missing_ports: List[int] = []
        for expected_port in [80, 443]:
            if expected_port not in listening_ports:
                missing_ports.append(expected_port)
        
        if missing_ports:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.WARNING,
                message=f"nginx active but not listening on ports: {missing_ports}",
                details={"listening_ports": listening_ports},
                remediation=[
                    f"nginx is not listening on expected ports: {missing_ports}",
                    "Check nginx configuration: /etc/nginx/sites-enabled/",
                    "Verify listen directives in config",
                    "Reload nginx: sudo systemctl reload nginx",
                ]
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=self.severity,
            message=f"nginx active and listening on ports {listening_ports[:2]}",
            details={"listening_ports": listening_ports}
        )


class FirewallCheck(DiagnosticCheck):
    """Check firewall status and configuration."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "firewall"
    
    @property
    def category(self) -> str:
        return "services"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.WARNING
    
    @property
    def description(self) -> str:
        return "Check firewall status and rules"
    
    async def execute(self) -> CheckResult:
        """Execute firewall check."""
        # Try to detect firewall type
        # Check ufw first (most common on Ubuntu)
        ufw_result = self.executor.execute("sudo ufw status", stream=False)
        
        if ufw_result.exit_code == 0 and 'Status: active' in ufw_result.stdout:
            # ufw is active, check rules
            # Map service names to ports
            service_port_map: Dict[str, List[int]] = {
                'OpenSSH': [22],
                'Nginx Full': [80, 443],
            }
            
            required_ports: List[int] = [22, 80, 443]
            allowed_ports: List[int] = []
            
            for line in ufw_result.stdout.split('\n'):
                # Match explicit port rules (e.g., "22/tcp ALLOW Anywhere")
                port_match = re.search(r'(\d+)(?:/tcp|/udp)?\s+ALLOW', line)
                if port_match:
                    port: int = int(port_match.group(1))
                    allowed_ports.append(port)
                else:
                    # Match service name rules (e.g., "OpenSSH ALLOW Anywhere")
                    for service_name, ports in service_port_map.items():
                        if service_name in line and 'ALLOW' in line:
                            allowed_ports.extend(ports)
            
            # Deduplicate
            allowed_ports = list(set(allowed_ports))
            missing_ports: List[int] = [p for p in required_ports if p not in allowed_ports]
            
            if missing_ports:
                return CheckResult(
                    check_name=self.name,
                    category=self.category,
                    passed=True,
                    severity=CheckSeverity.WARNING,
                    message=f"Firewall active (ufw) but ports may be blocked: {missing_ports}",
                    details={"firewall": "ufw", "allowed_ports": allowed_ports},
                    remediation=[
                        f"Required ports may not be allowed: {missing_ports}",
                        "Allow ports:",
                        f"  sudo ufw allow 22/tcp   # SSH",
                        f"  sudo ufw allow 80/tcp   # HTTP",
                        f"  sudo ufw allow 443/tcp  # HTTPS",
                        "Check status: sudo ufw status verbose",
                    ]
                )
            
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.INFO,  # INFO for success, not WARNING
                message="Firewall active (ufw) with required ports open",
                details={"firewall": "ufw", "allowed_ports": allowed_ports}
            )
        
        # Check firewalld
        firewalld_result = self.executor.execute("sudo firewall-cmd --state", stream=False)
        
        if firewalld_result.exit_code == 0 and 'running' in firewalld_result.stdout:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.INFO,  # INFO for success
                message="Firewall active (firewalld)",
                details={"firewall": "firewalld"},
                remediation=[
                    "Verify required ports are open:",
                    "  sudo firewall-cmd --list-all",
                ]
            )
        
        # Check iptables
        iptables_result = self.executor.execute("sudo iptables -L -n | head -20", stream=False)
        
        if iptables_result.exit_code == 0:
            has_rules: bool = len(iptables_result.stdout.split('\n')) > 10
            
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.INFO,  # Already INFO, keeping it
                message=f"Firewall configured (iptables, {'has rules' if has_rules else 'minimal rules'})",
                details={"firewall": "iptables"}
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=CheckSeverity.INFO,
            message="No active firewall detected",
            remediation=[
                "No firewall detected - consider enabling for security:",
                "  sudo apt install ufw",
                "  sudo ufw enable",
            ]
        )

