"""Time synchronization diagnostic checks."""

import re
from datetime import datetime, timezone
from typing import Dict

from ocn_cli.diagnostics.base import CheckResult, CheckSeverity, DiagnosticCheck
from ocn_cli.ssh.command_executor import CommandExecutor


class TimeSynchronizationCheck(DiagnosticCheck):
    """Check system time synchronization with NTP."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "time_synchronization"
    
    @property
    def category(self) -> str:
        return "system"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.CRITICAL
    
    @property
    def description(self) -> str:
        return "Check system time synchronization (critical for BACnet)"
    
    async def execute(self) -> CheckResult:
        """Execute time synchronization check."""
        # Get timedatectl status
        result = self.executor.execute("timedatectl status", stream=False)
        
        if result.exit_code != 0:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Could not check time synchronization",
                remediation=[
                    "timedatectl command not available",
                    "Verify systemd is installed",
                ]
            )
        
        output: str = result.stdout
        
        # Check if NTP is enabled
        ntp_enabled: bool = False
        ntp_synchronized: bool = False
        system_timezone: str = "unknown"
        
        for line in output.split('\n'):
            if 'NTP service:' in line or 'Network time on:' in line:
                ntp_enabled = 'yes' in line.lower() or 'active' in line.lower()
            if 'NTP synchronized:' in line or 'System clock synchronized:' in line:
                ntp_synchronized = 'yes' in line.lower()
            if 'Time zone:' in line:
                # Extract timezone (e.g., "America/New_York")
                match = re.search(r'Time zone:\s*([^\(]+)', line)
                if match:
                    system_timezone = match.group(1).strip()
        
        # Get system time and compare with local time
        date_result = self.executor.execute("date -u +%s", stream=False)
        
        system_time_drift: float = 0.0
        if date_result.exit_code == 0:
            try:
                system_timestamp: int = int(date_result.stdout.strip())
                local_timestamp: int = int(datetime.now(timezone.utc).timestamp())
                system_time_drift = abs(system_timestamp - local_timestamp)
            except (ValueError, AttributeError):
                pass
        
        details: Dict = {
            "ntp_enabled": ntp_enabled,
            "ntp_synchronized": ntp_synchronized,
            "timezone": system_timezone,
            "time_drift_seconds": system_time_drift,
        }
        
        # Check for critical issues
        if not ntp_enabled:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="NTP time synchronization is disabled",
                details=details,
                remediation=[
                    "NTP is not enabled - system time may drift",
                    "This is CRITICAL for BACnet time synchronization",
                    "",
                    "Enable NTP:",
                    "  sudo timedatectl set-ntp true",
                    "",
                    "Verify status:",
                    "  timedatectl status",
                    "",
                    "Check time sync service:",
                    "  sudo systemctl status systemd-timesyncd",
                    "  OR",
                    "  sudo systemctl status chrony",
                ]
            )
        
        if not ntp_synchronized:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="NTP enabled but not synchronized",
                details=details,
                remediation=[
                    "NTP is enabled but system clock is not synchronized",
                    "",
                    "Actions:",
                    "  1. Check NTP service: sudo systemctl status systemd-timesyncd",
                    "  2. Restart NTP: sudo systemctl restart systemd-timesyncd",
                    "  3. Check NTP servers: timedatectl show-timesync --all",
                    "  4. Force sync: sudo timedatectl set-ntp false && sudo timedatectl set-ntp true",
                    "",
                    "If using chrony:",
                    "  sudo systemctl restart chrony",
                    "  chronyc sources",
                ]
            )
        
        # Check for significant time drift
        if system_time_drift > 5:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.WARNING,
                message=f"Time synchronized but drift detected ({system_time_drift:.0f}s)",
                details=details,
                remediation=[
                    f"System time drift: {system_time_drift:.0f} seconds",
                    "This may affect BACnet time synchronization",
                    "",
                    "Actions:",
                    "  - Force time sync: sudo timedatectl set-ntp false && sudo timedatectl set-ntp true",
                    "  - Check NTP servers: timedatectl show-timesync --all",
                    "  - Verify network connectivity to NTP servers",
                ]
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=CheckSeverity.INFO,
            message=f"Time synchronized (NTP active, timezone: {system_timezone})",
            details=details
        )

