"""Container status diagnostic checks."""

import re
from typing import Dict, List

from ocn_cli.diagnostics.base import CheckResult, CheckSeverity, DiagnosticCheck
from ocn_cli.ssh.command_executor import CommandExecutor


class ContainerStatusCheck(DiagnosticCheck):
    """Check status of all Docker containers, especially OCN containers."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "container_status"
    
    @property
    def category(self) -> str:
        return "docker"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.CRITICAL
    
    @property
    def description(self) -> str:
        return "Check Docker container status"
    
    async def execute(self) -> CheckResult:
        """Execute container status check."""
        # List all containers
        result = self.executor.execute(
            "sudo docker ps -a --format '{{.ID}}|{{.Names}}|{{.Status}}|{{.Image}}'",
            stream=False
        )
        
        if result.exit_code != 0:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Failed to list Docker containers",
                details={"error": result.stderr},
                remediation=[
                    "Verify Docker daemon is running: sudo systemctl status docker",
                    "Try starting Docker: sudo systemctl start docker",
                    "Check Docker socket: ls -l /var/run/docker.sock",
                ]
            )
        
        # Parse containers
        containers: List[Dict[str, str]] = []
        for line in result.stdout.strip().split('\n'):
            if not line:
                continue
            parts: List[str] = line.split('|')
            if len(parts) >= 4:
                containers.append({
                    "id": parts[0],
                    "name": parts[1],
                    "status": parts[2],
                    "image": parts[3],
                })
        
        if not containers:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.WARNING,
                message="No Docker containers found",
                remediation=[
                    "No containers found on the system",
                    "Verify OCN is installed and containers created",
                ]
            )
        
        # Filter OCN containers
        ocn_containers: List[Dict[str, str]] = [
            c for c in containers
            if 'ocn' in c['name'].lower() or 'ocn' in c['image'].lower()
        ]
        
        # Analyze container problems
        problems: List[Dict[str, str]] = []
        
        for container in ocn_containers:
            status_lower: str = container['status'].lower()
            
            # Check for exited containers
            if status_lower.startswith('exited'):
                # Extract exit code
                exit_code_match = re.search(r'exited \((\d+)\)', status_lower)
                exit_code: str = exit_code_match.group(1) if exit_code_match else "unknown"
                
                # Get container logs
                logs_result = self.executor.execute(
                    f"sudo docker logs --tail 20 {container['id']}", 
                    stream=False
                )
                logs: str = logs_result.stdout if logs_result.exit_code == 0 else "Could not retrieve logs"
                
                problems.append({
                    "container": container['name'],
                    "issue": f"Exited with code {exit_code}",
                    "logs": logs,
                })
            
            # Check for restarting containers
            elif 'restarting' in status_lower:
                # Get restart count from docker inspect
                inspect_result = self.executor.execute(
                    f"sudo docker inspect --format '{{{{.RestartCount}}}}' {container['id']}",
                    stream=False
                )
                restart_count: str = inspect_result.stdout.strip() if inspect_result.exit_code == 0 else "unknown"
                
                problems.append({
                    "container": container['name'],
                    "issue": f"Stuck in restart loop (restarts: {restart_count})",
                })
            
            # Check for unhealthy containers
            elif 'unhealthy' in status_lower:
                problems.append({
                    "container": container['name'],
                    "issue": "Health check failing",
                })
        
        if problems:
            remediation: List[str] = [
                f"Found {len(problems)} container(s) with issues:",
                ""
            ]
            
            for problem in problems:
                remediation.append(f"• {problem['container']}: {problem['issue']}")
                remediation.append(f"  - View logs: sudo docker logs {problem['container']}")
                remediation.append(f"  - Restart: sudo docker restart {problem['container']}")
                remediation.append(f"  - Inspect: sudo docker inspect {problem['container']}")
                if 'logs' in problem:
                    remediation.append(f"  - Recent error: {problem['logs'][:200]}")
                remediation.append("")
            
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message=f"{len(problems)} container(s) have issues",
                details={"problems": problems, "total_containers": len(ocn_containers)},
                remediation=remediation
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=self.severity,
            message=f"All containers OK ({len(ocn_containers)} OCN containers running)",
            details={"container_count": len(ocn_containers)}
        )

