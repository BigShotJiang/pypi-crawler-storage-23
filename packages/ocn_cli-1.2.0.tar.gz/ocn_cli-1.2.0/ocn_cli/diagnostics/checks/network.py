"""Network connectivity diagnostic checks."""

import re
from typing import List, Tuple

from ocn_cli.diagnostics.base import CheckResult, CheckSeverity, DiagnosticCheck
from ocn_cli.ssh.command_executor import CommandExecutor


class InternetConnectivityCheck(DiagnosticCheck):
    """Check internet connectivity to public endpoints."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "internet_connectivity"
    
    @property
    def category(self) -> str:
        return "network"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.CRITICAL
    
    @property
    def description(self) -> str:
        return "Verify internet connectivity to public endpoints"
    
    async def execute(self) -> CheckResult:
        """Execute internet connectivity check."""
        endpoints: List[Tuple[str, str]] = [
            ("8.8.8.8", "Google DNS"),
            ("1.1.1.1", "Cloudflare DNS"),
            ("google.com", "Google"),
        ]
        
        reachable: List[str] = []
        unreachable: List[str] = []
        latencies: List[float] = []
        
        for endpoint, name in endpoints:
            # Try ICMP ping
            result = self.executor.execute(f"ping -c 1 -W 2 {endpoint}", stream=False)
            
            if result.exit_code == 0:
                reachable.append(name)
                # Extract latency from ping output
                latency: float = self._extract_latency(result.stdout)
                if latency > 0:
                    latencies.append(latency)
            else:
                unreachable.append(name)
        
        avg_latency: float = sum(latencies) / len(latencies) if latencies else 0
        
        if not reachable:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="No internet connectivity detected",
                details={"unreachable": unreachable},
                remediation=[
                    "Check physical network cables/WiFi connection",
                    "Verify network interface is up: ip link show",
                    "Check routing table: ip route",
                    "Verify default gateway is configured",
                    "Check firewall rules: sudo ufw status",
                    "Test with: ping 8.8.8.8",
                ]
            )
        
        # Check for high latency
        if avg_latency > 500:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.WARNING,
                message=f"Internet connectivity OK but latency is high ({avg_latency:.0f}ms)",
                details={
                    "reachable": reachable,
                    "unreachable": unreachable,
                    "avg_latency_ms": avg_latency,
                },
                remediation=[
                    f"High network latency detected ({avg_latency:.0f}ms)",
                    "Check network quality and bandwidth",
                    "Verify no bandwidth-heavy processes running",
                    "Consider network infrastructure issues",
                ]
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=self.severity,
            message=f"Internet connectivity OK ({len(reachable)}/{len(endpoints)} endpoints reachable)",
            details={
                "reachable": reachable,
                "avg_latency_ms": avg_latency,
            }
        )
    
    def _extract_latency(self, ping_output: str) -> float:
        """Extract latency from ping output."""
        # Look for "time=XX.X ms" pattern
        match = re.search(r"time[=\s]+([\d.]+)\s*ms", ping_output)
        if match:
            return float(match.group(1))
        return 0.0


class NetworkInterfaceCheck(DiagnosticCheck):
    """Check network interface status."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "network_interfaces"
    
    @property
    def category(self) -> str:
        return "network"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.CRITICAL
    
    @property
    def description(self) -> str:
        return "Verify network interfaces are up"
    
    async def execute(self) -> CheckResult:
        """Execute network interface check."""
        result = self.executor.execute("ip link show", stream=False)
        
        if result.exit_code != 0:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Failed to check network interfaces",
                remediation=["Verify 'ip' command is available"]
            )
        
        # Parse interfaces and their status
        interfaces_up: List[str] = []
        interfaces_down: List[str] = []
        
        for line in result.stdout.split('\n'):
            # Match interface line (e.g., "2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP>")
            match = re.match(r'^\d+:\s+([^:]+):\s+<([^>]+)>', line)
            if match:
                iface_name: str = match.group(1).strip()
                flags: str = match.group(2)
                
                # Skip loopback
                if iface_name == 'lo':
                    continue
                
                if 'UP' in flags:
                    interfaces_up.append(iface_name)
                else:
                    interfaces_down.append(iface_name)
        
        if not interfaces_up:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="No network interfaces are up",
                details={"down_interfaces": interfaces_down},
                remediation=[
                    "Bring up network interface: sudo ip link set <interface> up",
                    "Check network configuration: cat /etc/netplan/*.yaml",
                    "Check NetworkManager: systemctl status NetworkManager",
                    "Verify physical connection (cable/WiFi)",
                ]
            )
        
        if interfaces_down:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.WARNING,
                message=f"Network interfaces OK ({len(interfaces_up)} up, {len(interfaces_down)} down)",
                details={
                    "up_interfaces": interfaces_up,
                    "down_interfaces": interfaces_down,
                },
                remediation=[
                    f"Some interfaces are down: {', '.join(interfaces_down)}",
                    "Check if this is expected or requires attention",
                ]
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=self.severity,
            message=f"All network interfaces up ({len(interfaces_up)} active)",
            details={"up_interfaces": interfaces_up}
        )


class DefaultGatewayCheck(DiagnosticCheck):
    """Check default gateway configuration and reachability."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "default_gateway"
    
    @property
    def category(self) -> str:
        return "network"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.CRITICAL
    
    @property
    def description(self) -> str:
        return "Verify default gateway is configured and reachable"
    
    async def execute(self) -> CheckResult:
        """Execute default gateway check."""
        # Get default gateway
        result = self.executor.execute("ip route show default", stream=False)
        
        if result.exit_code != 0 or not result.stdout.strip():
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="No default gateway configured",
                remediation=[
                    "Configure default gateway in network settings",
                    "Check routing: ip route",
                    "Verify network configuration: cat /etc/netplan/*.yaml",
                    "Restart networking: sudo systemctl restart systemd-networkd",
                ]
            )
        
        # Extract gateway IP
        match = re.search(r'default via ([\d.]+)', result.stdout)
        if not match:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Could not parse default gateway",
                details={"route_output": result.stdout}
            )
        
        gateway_ip: str = match.group(1)
        
        # Ping gateway
        ping_result = self.executor.execute(f"ping -c 1 -W 2 {gateway_ip}", stream=False)
        
        if ping_result.exit_code != 0:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message=f"Default gateway {gateway_ip} is not reachable",
                details={"gateway_ip": gateway_ip},
                remediation=[
                    f"Gateway {gateway_ip} is not responding",
                    "Check physical network connection",
                    "Verify gateway device is powered on",
                    "Check network cable/WiFi connection",
                    "Restart network: sudo systemctl restart networking",
                ]
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=self.severity,
            message=f"Default gateway OK ({gateway_ip})",
            details={"gateway_ip": gateway_ip}
        )

