"""DNS resolution diagnostic checks."""

import re
from typing import List

from ocn_cli.diagnostics.base import CheckResult, CheckSeverity, DiagnosticCheck
from ocn_cli.ssh.command_executor import CommandExecutor


class DNSResolutionCheck(DiagnosticCheck):
    """Check DNS resolution of critical domains."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "dns_resolution"
    
    @property
    def category(self) -> str:
        return "network"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.CRITICAL
    
    @property
    def description(self) -> str:
        return "Verify DNS resolution of critical domains"
    
    async def execute(self) -> CheckResult:
        """Execute DNS resolution check."""
        test_domains: List[str] = ["google.com", "docker.io", "github.com", "keygen.sh"]
        
        resolved: List[str] = []
        failed: List[str] = []
        
        for domain in test_domains:
            # Try nslookup first, fall back to dig
            result = self.executor.execute(f"nslookup {domain}", stream=False)
            
            if result.exit_code != 0:
                # Try dig as fallback
                result = self.executor.execute(f"dig +short {domain}", stream=False)
            
            if result.exit_code == 0 and result.stdout.strip():
                resolved.append(domain)
            else:
                failed.append(domain)
        
        if failed:
            # Critical domains that must resolve
            critical_domains: List[str] = ["keygen.sh", "docker.io"]
            critical_failed: List[str] = [d for d in failed if d in critical_domains]
            
            if critical_failed:
                return CheckResult(
                    check_name=self.name,
                    category=self.category,
                    passed=False,
                    severity=self.severity,
                    message=f"DNS resolution failed for critical domains: {', '.join(critical_failed)}",
                    details={"failed": failed, "resolved": resolved},
                    remediation=[
                        "Check /etc/resolv.conf for valid nameservers",
                        "Test DNS manually: nslookup google.com",
                        "Add public DNS servers to /etc/resolv.conf:",
                        "  nameserver 8.8.8.8",
                        "  nameserver 1.1.1.1",
                        "Check systemd-resolved: systemctl status systemd-resolved",
                        "Restart systemd-resolved: sudo systemctl restart systemd-resolved",
                    ]
                )
            else:
                return CheckResult(
                    check_name=self.name,
                    category=self.category,
                    passed=True,
                    severity=CheckSeverity.WARNING,
                    message=f"DNS resolution OK, but some domains failed: {', '.join(failed)}",
                    details={"failed": failed, "resolved": resolved},
                    remediation=[
                        f"Non-critical domains failed: {', '.join(failed)}",
                        "Check DNS configuration if these domains are needed",
                    ]
                )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=self.severity,
            message=f"DNS resolution OK (all {len(test_domains)} domains resolved)",
            details={"resolved": resolved}
        )