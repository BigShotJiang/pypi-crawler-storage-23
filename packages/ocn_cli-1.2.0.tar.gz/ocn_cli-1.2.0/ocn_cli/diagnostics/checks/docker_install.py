"""Docker installation validation check."""

import re
from typing import Dict, List

from ocn_cli.diagnostics.base import CheckResult, CheckSeverity, DiagnosticCheck
from ocn_cli.ssh.command_executor import CommandExecutor


class DockerInstallationCheck(DiagnosticCheck):
    """Validate Docker is installed from official repository."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "docker_installation"
    
    @property
    def category(self) -> str:
        return "docker"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.CRITICAL
    
    @property
    def description(self) -> str:
        return "Verify Docker is installed from official repository"
    
    async def execute(self) -> CheckResult:
        """Execute Docker installation check."""
        # Check which Docker packages are installed
        result = self.executor.execute("dpkg -l | grep -E 'docker|containerd'", stream=False)
        
        if result.exit_code != 0 or not result.stdout.strip():
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Docker is not installed",
                remediation=[
                    "Install Docker from official repository:",
                    "  curl -fsSL https://get.docker.com -o get-docker.sh",
                    "  sudo sh get-docker.sh",
                    "Or manually:",
                    "  https://docs.docker.com/engine/install/ubuntu/",
                ]
            )
        
        # Parse package list
        packages: Dict[str, str] = {}
        for line in result.stdout.split('\n'):
            # Match dpkg output line
            match = re.match(r'^ii\s+(\S+)\s+(\S+)', line)
            if match:
                pkg_name: str = match.group(1)
                pkg_version: str = match.group(2)
                packages[pkg_name] = pkg_version
        
        # Check for problematic docker.io package
        has_docker_io: bool = 'docker.io' in packages
        has_docker_ce: bool = 'docker-ce' in packages
        has_docker_ce_cli: bool = 'docker-ce-cli' in packages
        has_containerd_io: bool = 'containerd.io' in packages
        
        if has_docker_io and not has_docker_ce:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=CheckSeverity.WARNING,
                message="Docker installed from docker.io package (PROBLEMATIC)",
                details={"packages": list(packages.keys())},
                remediation=[
                    "⚠️  docker.io package is known to cause issues with OCN",
                    "",
                    "Migrate to official Docker:",
                    "1. Stop OCN containers: cd /path/to/ocn && sudo docker-compose down",
                    "2. Remove docker.io: sudo apt remove docker.io docker-doc docker-compose",
                    "3. Add official Docker repository:",
                    "   curl -fsSL https://get.docker.com -o get-docker.sh",
                    "   sudo sh get-docker.sh",
                    "4. Verify installation: sudo docker version",
                    "5. Start OCN: cd /path/to/ocn && sudo docker-compose up -d",
                ]
            )
        
        # Check for official Docker packages
        if has_docker_ce and has_docker_ce_cli and has_containerd_io:
            docker_version: str = packages.get('docker-ce', 'unknown')
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=self.severity,
                message=f"Docker CE installed from official repository (v{docker_version})",
                details={"packages": list(packages.keys()), "version": docker_version}
            )
        
        # Check if Docker works
        docker_check = self.executor.execute("sudo docker version", stream=False)
        if docker_check.exit_code == 0:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.WARNING,
                message="Docker installed but package source unclear",
                details={"packages": list(packages.keys())},
                remediation=[
                    "Docker is working but installation method unclear",
                    "Consider migrating to official Docker CE for best support",
                ]
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=False,
            severity=self.severity,
            message="Docker packages found but Docker daemon not responding",
            details={"packages": list(packages.keys())},
            remediation=[
                "Docker is installed but not working",
                "Check Docker service: sudo systemctl status docker",
                "Try starting: sudo systemctl start docker",
                "Check logs: sudo journalctl -u docker -n 50",
            ]
        )

