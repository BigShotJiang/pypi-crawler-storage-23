"""Log file size diagnostic checks."""

import re
from typing import Dict, List

from ocn_cli.diagnostics.base import CheckResult, CheckSeverity, DiagnosticCheck
from ocn_cli.ssh.command_executor import CommandExecutor


class LogSizeCheck(DiagnosticCheck):
    """Check log file sizes to prevent disk exhaustion."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "log_size"
    
    @property
    def category(self) -> str:
        return "system"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.WARNING
    
    @property
    def description(self) -> str:
        return "Check log file sizes"
    
    async def execute(self) -> CheckResult:
        """Execute log size check."""
        # Check /var/log size
        varlog_result = self.executor.execute("sudo du -sh /var/log 2>/dev/null", stream=False)
        
        if varlog_result.exit_code != 0:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Could not check log directory size",
            )
        
        # Parse size (e.g., "1.2G")
        varlog_size_str: str = varlog_result.stdout.strip().split()[0]
        varlog_size_mb: float = self._parse_size_to_mb(varlog_size_str)
        
        # Check journal size
        journal_result = self.executor.execute(
            "sudo journalctl --disk-usage 2>/dev/null | grep -oP 'Archived and active journals take up \\K[^ ]+'",
            stream=False
        )
        
        journal_size_mb: float = 0.0
        if journal_result.exit_code == 0 and journal_result.stdout.strip():
            journal_size_str: str = journal_result.stdout.strip()
            journal_size_mb = self._parse_size_to_mb(journal_size_str)
        
        # Check Docker container logs
        docker_logs_result = self.executor.execute(
            "sudo du -sh /var/lib/docker/containers 2>/dev/null",
            stream=False
        )
        
        docker_logs_size_mb: float = 0.0
        if docker_logs_result.exit_code == 0 and docker_logs_result.stdout.strip():
            docker_logs_size_str: str = docker_logs_result.stdout.strip().split()[0]
            docker_logs_size_mb = self._parse_size_to_mb(docker_logs_size_str)
        
        # Calculate total
        total_logs_mb: float = varlog_size_mb + journal_size_mb + docker_logs_size_mb
        
        # Thresholds
        warning_threshold_mb: float = 2048  # 2GB
        critical_threshold_mb: float = 5120  # 5GB
        
        details: Dict[str, float] = {
            "varlog_size_mb": varlog_size_mb,
            "journal_size_mb": journal_size_mb,
            "docker_logs_size_mb": docker_logs_size_mb,
            "total_logs_mb": total_logs_mb,
        }
        
        if total_logs_mb > critical_threshold_mb:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=CheckSeverity.CRITICAL,
                message=f"Log files CRITICAL ({total_logs_mb:.0f}MB total)",
                details=details,
                remediation=[
                    f"Log files consuming {total_logs_mb:.0f}MB (>{critical_threshold_mb}MB)",
                    "",
                    "Clean up logs immediately:",
                    f"  • /var/log: {varlog_size_mb:.0f}MB",
                    f"    - Find large logs: sudo du -sh /var/log/* | sort -h",
                    f"    - Compress old logs: sudo gzip /var/log/*.log",
                    "",
                    f"  • Journal: {journal_size_mb:.0f}MB",
                    f"    - Clean journal: sudo journalctl --vacuum-size=100M",
                    f"    - Or by time: sudo journalctl --vacuum-time=7d",
                    "",
                    f"  • Docker logs: {docker_logs_size_mb:.0f}MB",
                    f"    - Prune logs: sudo docker system prune -f",
                    f"    - Configure log rotation: /etc/docker/daemon.json",
                ]
            )
        
        if total_logs_mb > warning_threshold_mb:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.WARNING,
                message=f"Log files HIGH ({total_logs_mb:.0f}MB total)",
                details=details,
                remediation=[
                    f"Log files consuming {total_logs_mb:.0f}MB",
                    f"  • /var/log: {varlog_size_mb:.0f}MB",
                    f"  • Journal: {journal_size_mb:.0f}MB",
                    f"  • Docker logs: {docker_logs_size_mb:.0f}MB",
                    "",
                    "Consider cleaning:",
                    "  - Journal: sudo journalctl --vacuum-time=30d",
                    "  - Docker: sudo docker system prune",
                    "  - Old logs: sudo find /var/log -name '*.gz' -mtime +30 -delete",
                ]
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=CheckSeverity.INFO,
            message=f"Log files OK ({total_logs_mb:.0f}MB total)",
            details=details
        )
    
    def _parse_size_to_mb(self, size_str: str) -> float:
        """
        Parse size string to MB.
        
        Args:
            size_str: Size string (e.g., "1.2G", "512M", "100K")
            
        Returns:
            float: Size in MB
        """
        # Remove any trailing whitespace
        size_str = size_str.strip()
        
        # Match number and unit
        match = re.match(r'([\d.]+)([KMGT])?', size_str, re.IGNORECASE)
        if not match:
            return 0.0
        
        value: float = float(match.group(1))
        unit: str = match.group(2).upper() if match.group(2) else 'M'
        
        # Convert to MB
        multipliers: Dict[str, float] = {
            'K': 1 / 1024,
            'M': 1,
            'G': 1024,
            'T': 1024 * 1024,
        }
        
        return value * multipliers.get(unit, 1)

