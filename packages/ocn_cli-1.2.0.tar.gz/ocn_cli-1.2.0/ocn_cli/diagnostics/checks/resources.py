"""System resource diagnostic checks."""

import re
from typing import Dict, List

from ocn_cli.diagnostics.base import CheckResult, CheckSeverity, DiagnosticCheck
from ocn_cli.ssh.command_executor import CommandExecutor


class CPUUsageCheck(DiagnosticCheck):
    """Check CPU usage."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "cpu_usage"
    
    @property
    def category(self) -> str:
        return "resources"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.WARNING
    
    @property
    def description(self) -> str:
        return "Check CPU usage"
    
    async def execute(self) -> CheckResult:
        """Execute CPU usage check."""
        # Get CPU usage from top
        result = self.executor.execute("top -bn1 | head -5", stream=False)
        
        if result.exit_code != 0:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Could not check CPU usage",
            )
        
        # Parse CPU usage (look for idle percentage)
        # Example: "%Cpu(s):  5.2 us,  2.3 sy,  0.0 ni, 92.1 id"
        match = re.search(r'%Cpu\(s\):[^,]+,[^,]+,[^,]+,\s*([\d.]+)\s*id', result.stdout)
        
        if match:
            idle_pct: float = float(match.group(1))
            cpu_usage: float = 100.0 - idle_pct
            
            if cpu_usage > 95:
                # Get top processes
                top_procs = self.executor.execute("ps aux --sort=-%cpu | head -6", stream=False)
                
                return CheckResult(
                    check_name=self.name,
                    category=self.category,
                    passed=False,
                    severity=CheckSeverity.CRITICAL,
                    message=f"CPU usage CRITICAL ({cpu_usage:.1f}%)",
                    details={"cpu_usage": cpu_usage, "top_processes": top_procs.stdout},
                    remediation=[
                        f"CPU usage is very high ({cpu_usage:.1f}%)",
                        "Top CPU consuming processes:",
                        top_procs.stdout,
                        "",
                        "Actions:",
                        "  - Identify runaway processes",
                        "  - Check for infinite loops or CPU-intensive tasks",
                        "  - Consider restarting problematic services",
                    ]
                )
            elif cpu_usage > 80:
                return CheckResult(
                    check_name=self.name,
                    category=self.category,
                    passed=True,
                    severity=CheckSeverity.WARNING,
                    message=f"CPU usage HIGH ({cpu_usage:.1f}%)",
                    details={"cpu_usage": cpu_usage},
                    remediation=[
                        f"CPU usage is elevated ({cpu_usage:.1f}%)",
                        "Check top processes: top or htop",
                        "Monitor if issue persists",
                    ]
                )
            
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.INFO,  # Changed from WARNING to INFO
                message=f"CPU usage OK ({cpu_usage:.1f}%)",
                details={"cpu_usage": cpu_usage}
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=self.severity,
            message="CPU usage check completed (could not parse percentage)",
        )


class MemoryUsageCheck(DiagnosticCheck):
    """Check memory (RAM and swap) usage."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "memory_usage"
    
    @property
    def category(self) -> str:
        return "resources"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.WARNING
    
    @property
    def description(self) -> str:
        return "Check memory and swap usage"
    
    async def execute(self) -> CheckResult:
        """Execute memory usage check."""
        result = self.executor.execute("free -m", stream=False)
        
        if result.exit_code != 0:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Could not check memory usage",
            )
        
        # Parse memory output
        lines: List[str] = result.stdout.strip().split('\n')
        mem_line: str = ""
        swap_line: str = ""
        
        for line in lines:
            if line.startswith('Mem:'):
                mem_line = line
            elif line.startswith('Swap:'):
                swap_line = line
        
        if not mem_line:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Could not parse memory information",
            )
        
        # Parse memory values (in MB)
        mem_parts: List[str] = mem_line.split()
        if len(mem_parts) >= 3:
            total_mb: int = int(mem_parts[1])
            used_mb: int = int(mem_parts[2])
            mem_usage_pct: float = (used_mb / total_mb * 100) if total_mb > 0 else 0
        else:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Could not parse memory values",
            )
        
        # Parse swap if available
        swap_usage_pct: float = 0.0
        if swap_line:
            swap_parts: List[str] = swap_line.split()
            if len(swap_parts) >= 3:
                swap_total_mb: int = int(swap_parts[1])
                swap_used_mb: int = int(swap_parts[2])
                if swap_total_mb > 0:
                    swap_usage_pct = (swap_used_mb / swap_total_mb * 100)
        
        # Determine status
        remediation: List[str] = []
        
        if mem_usage_pct > 90:
            # Get top memory consumers
            top_procs = self.executor.execute("ps aux --sort=-%mem | head -6", stream=False)
            
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=CheckSeverity.CRITICAL,
                message=f"Memory usage CRITICAL ({mem_usage_pct:.1f}%)",
                details={
                    "memory_usage_pct": mem_usage_pct,
                    "total_mb": total_mb,
                    "used_mb": used_mb,
                    "swap_usage_pct": swap_usage_pct,
                    "top_processes": top_procs.stdout
                },
                remediation=[
                    f"Memory usage is critically high ({mem_usage_pct:.1f}%)",
                    "Top memory consuming processes:",
                    top_procs.stdout,
                    "",
                    "Actions:",
                    "  - Identify memory leaks",
                    "  - Restart high-memory services",
                    "  - Check Docker container memory limits",
                    "  - Consider adding more RAM",
                ]
            )
        
        if swap_usage_pct > 50:
            remediation.append(f"Swap usage is high ({swap_usage_pct:.1f}%)")
            remediation.append("System may be experiencing memory pressure")
        
        if mem_usage_pct > 80 or swap_usage_pct > 50:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.WARNING,
                message=f"Memory usage HIGH (RAM: {mem_usage_pct:.1f}%, Swap: {swap_usage_pct:.1f}%)",
                details={
                    "memory_usage_pct": mem_usage_pct,
                    "total_mb": total_mb,
                    "used_mb": used_mb,
                    "swap_usage_pct": swap_usage_pct,
                },
                remediation=remediation if remediation else [
                    "Monitor memory usage",
                    "Check for memory leaks: ps aux --sort=-%mem",
                ]
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=CheckSeverity.INFO,  # Changed from WARNING to INFO
            message=f"Memory usage OK (RAM: {mem_usage_pct:.1f}%, Swap: {swap_usage_pct:.1f}%)",
            details={
                "memory_usage_pct": mem_usage_pct,
                "total_mb": total_mb,
                "used_mb": used_mb,
                "swap_usage_pct": swap_usage_pct,
            }
        )


class DiskSpaceCheck(DiagnosticCheck):
    """Check disk space usage."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "disk_space"
    
    @property
    def category(self) -> str:
        return "resources"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.CRITICAL
    
    @property
    def description(self) -> str:
        return "Check disk space usage"
    
    async def execute(self) -> CheckResult:
        """Execute disk space check."""
        result = self.executor.execute("df -h", stream=False)
        
        if result.exit_code != 0:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Could not check disk space",
            )
        
        # Parse df output
        critical_mounts: List[str] = ['/', '/var', '/var/lib/docker', '/home']
        filesystem_usage: Dict[str, float] = {}
        
        for line in result.stdout.split('\n')[1:]:  # Skip header
            parts: List[str] = line.split()
            if len(parts) >= 6:
                mount_point: str = parts[5]
                use_pct_str: str = parts[4].rstrip('%')
                
                try:
                    use_pct: float = float(use_pct_str)
                    filesystem_usage[mount_point] = use_pct
                except ValueError:
                    continue
        
        # Check critical filesystems
        critical_high: List[str] = []
        critical_full: List[str] = []
        
        for mount in critical_mounts:
            if mount in filesystem_usage:
                usage: float = filesystem_usage[mount]
                if usage > 95:
                    critical_full.append(f"{mount} ({usage:.0f}%)")
                elif usage > 85:
                    critical_high.append(f"{mount} ({usage:.0f}%)")
        
        if critical_full:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=CheckSeverity.CRITICAL,
                message=f"Disk space CRITICAL: {', '.join(critical_full)}",
                details={"filesystem_usage": filesystem_usage},
                remediation=[
                    "Disk space critically low!",
                    "",
                    "Free up space immediately:",
                    "  - Clean Docker: docker system prune -a",
                    "  - Clean logs: sudo journalctl --vacuum-size=100M",
                    "  - Clean apt cache: sudo apt-get clean",
                    "  - Check large files: du -sh /var/* | sort -h",
                    "  - Remove old backups if any",
                ]
            )
        
        if critical_high:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.WARNING,
                message=f"Disk space HIGH: {', '.join(critical_high)}",
                details={"filesystem_usage": filesystem_usage},
                remediation=[
                    "Disk space is running low",
                    "Actions:",
                    "  - Clean Docker images: docker system prune",
                    "  - Clean logs: sudo journalctl --vacuum-time=7d",
                    "  - Clean package cache: sudo apt-get clean",
                    "  - Find large files: du -sh /var/* | sort -h",
                ]
            )
        
        root_usage: float = filesystem_usage.get('/', 0)
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=self.severity,
            message=f"Disk space OK (/ at {root_usage:.0f}%)",
            details={"filesystem_usage": filesystem_usage}
        )


class SystemLoadCheck(DiagnosticCheck):
    """Check system load average."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "system_load"
    
    @property
    def category(self) -> str:
        return "resources"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.WARNING
    
    @property
    def description(self) -> str:
        return "Check system load average"
    
    async def execute(self) -> CheckResult:
        """Execute system load check."""
        # Get load average
        uptime_result = self.executor.execute("uptime", stream=False)
        
        if uptime_result.exit_code != 0:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Could not check system load",
            )
        
        # Parse load average (e.g., "load average: 0.52, 0.58, 0.59")
        match = re.search(r'load average:\s*([\d.]+),\s*([\d.]+),\s*([\d.]+)', uptime_result.stdout)
        
        if not match:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=self.severity,
                message="System load check completed (could not parse)",
            )
        
        load_1min: float = float(match.group(1))
        load_5min: float = float(match.group(2))
        load_15min: float = float(match.group(3))
        
        # Get CPU core count
        nproc_result = self.executor.execute("nproc", stream=False)
        cpu_cores: int = int(nproc_result.stdout.strip()) if nproc_result.exit_code == 0 else 1
        
        # Load average threshold (2x CPU cores)
        threshold: float = cpu_cores * 2.0
        
        if load_1min > threshold:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=CheckSeverity.WARNING,
                message=f"System load HIGH ({load_1min:.2f}, {load_5min:.2f}, {load_15min:.2f})",
                details={
                    "load_1min": load_1min,
                    "load_5min": load_5min,
                    "load_15min": load_15min,
                    "cpu_cores": cpu_cores,
                },
                remediation=[
                    f"Load average ({load_1min:.2f}) exceeds 2x CPU cores ({cpu_cores})",
                    "System may be overloaded",
                    "Check running processes: top",
                    "Check I/O wait: top (look for 'wa' percentage)",
                    "Consider scaling resources",
                ]
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=CheckSeverity.INFO,  # Changed from WARNING to INFO
            message=f"System load OK ({load_1min:.2f}, {load_5min:.2f}, {load_15min:.2f})",
            details={
                "load_1min": load_1min,
                "load_5min": load_5min,
                "load_15min": load_15min,
                "cpu_cores": cpu_cores,
            }
        )

