"""keygen.sh accessibility diagnostic check."""

import re

from ocn_cli.diagnostics.base import CheckResult, CheckSeverity, DiagnosticCheck
from ocn_cli.ssh.command_executor import CommandExecutor


class KeygenAccessibilityCheck(DiagnosticCheck):
    """Check accessibility to keygen.sh license service."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "keygen_accessibility"
    
    @property
    def category(self) -> str:
        return "network"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.CRITICAL
    
    @property
    def description(self) -> str:
        return "Verify connectivity to keygen.sh license service"
    
    async def execute(self) -> CheckResult:
        """Execute keygen.sh accessibility check."""
        # First, test DNS resolution
        dns_result = self.executor.execute("nslookup keygen.sh", stream=False)
        
        if dns_result.exit_code != 0:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message="Cannot resolve keygen.sh (DNS failure)",
                remediation=[
                    "DNS resolution failed for keygen.sh",
                    "Check /etc/resolv.conf has valid nameservers",
                    "Test DNS: nslookup keygen.sh",
                    "Try with public DNS: nslookup keygen.sh 8.8.8.8",
                ]
            )
        
        # Test HTTPS connectivity
        curl_result = self.executor.execute(
            "curl -I --max-time 10 --silent --fail https://keygen.sh",
            stream=False
        )
        
        if curl_result.exit_code != 0:
            # Determine failure type
            error_msg: str = curl_result.stderr.lower()
            
            if "ssl" in error_msg or "certificate" in error_msg:
                return CheckResult(
                    check_name=self.name,
                    category=self.category,
                    passed=False,
                    severity=self.severity,
                    message="keygen.sh SSL/TLS certificate validation failed",
                    details={"error": curl_result.stderr},
                    remediation=[
                        "SSL certificate issue detected",
                        "Update CA certificates: sudo apt update && sudo apt install ca-certificates",
                        "Check system date/time: date",
                        "Test manually: curl -v https://keygen.sh",
                    ]
                )
            elif "timeout" in error_msg or "timed out" in error_msg:
                return CheckResult(
                    check_name=self.name,
                    category=self.category,
                    passed=False,
                    severity=self.severity,
                    message="Connection to keygen.sh timed out",
                    remediation=[
                        "Check firewall allows HTTPS (port 443) outbound",
                        "Verify no proxy blocking access",
                        "Test connectivity: curl -v https://keygen.sh",
                        "Check for network latency issues",
                    ]
                )
            else:
                return CheckResult(
                    check_name=self.name,
                    category=self.category,
                    passed=False,
                    severity=self.severity,
                    message="Cannot reach keygen.sh",
                    details={"error": curl_result.stderr},
                    remediation=[
                        "Check internet connectivity",
                        "Verify firewall allows HTTPS outbound",
                        "Test manually: curl -v https://keygen.sh",
                        "Check for HTTP proxy configuration",
                    ]
                )
        
        # Parse HTTP response code
        http_code: int = 0
        match = re.search(r'HTTP/[\d.]+ (\d+)', curl_result.stdout)
        if match:
            http_code = int(match.group(1))
        
        if http_code >= 500:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.WARNING,
                message=f"keygen.sh reachable but returned HTTP {http_code} (server error)",
                details={"http_code": http_code},
                remediation=[
                    f"keygen.sh returned HTTP {http_code}",
                    "This may be a temporary issue with the service",
                    "Try again in a few minutes",
                    "Contact OCN support if issue persists",
                ]
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=self.severity,
            message=f"keygen.sh accessible (HTTP {http_code if http_code else 'OK'})",
            details={"http_code": http_code}
        )

