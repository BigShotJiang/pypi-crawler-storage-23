"""dpkg lock detection check."""

import re
from typing import Dict, List

from ocn_cli.diagnostics.base import CheckResult, CheckSeverity, DiagnosticCheck
from ocn_cli.ssh.command_executor import CommandExecutor


class DpkgLockCheck(DiagnosticCheck):
    """Check if dpkg is locked, preventing package operations."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """Initialize check with command executor."""
        self.executor: CommandExecutor = executor
    
    @property
    def name(self) -> str:
        return "dpkg_lock"
    
    @property
    def category(self) -> str:
        return "system"
    
    @property
    def severity(self) -> CheckSeverity:
        return CheckSeverity.WARNING
    
    @property
    def description(self) -> str:
        return "Check for dpkg locks that prevent updates"
    
    async def execute(self) -> CheckResult:
        """Execute dpkg lock check."""
        lock_files: List[str] = [
            "/var/lib/dpkg/lock",
            "/var/lib/dpkg/lock-frontend",
            "/var/lib/apt/lists/lock",
            "/var/cache/apt/archives/lock",
        ]
        
        locks_found: List[Dict[str, str]] = []
        
        for lock_file in lock_files:
            # Check if lock file exists
            exist_result = self.executor.execute(f"test -f {lock_file} && echo 'exists'", stream=False)
            
            if exist_result.exit_code == 0 and 'exists' in exist_result.stdout:
                # Check if a process is holding the lock
                lsof_result = self.executor.execute(f"sudo lsof {lock_file} 2>/dev/null", stream=False)
                
                if lsof_result.exit_code == 0 and lsof_result.stdout.strip():
                    # Parse lsof output to get process info
                    lines: List[str] = lsof_result.stdout.strip().split('\n')
                    if len(lines) > 1:  # Skip header
                        # Extract process info from lsof output
                        parts: List[str] = lines[1].split()
                        if len(parts) >= 2:
                            process_name: str = parts[0]
                            pid: str = parts[1]
                            
                            locks_found.append({
                                "file": lock_file,
                                "process": process_name,
                                "pid": pid,
                                "type": "active"
                            })
                        else:
                            locks_found.append({
                                "file": lock_file,
                                "process": "unknown",
                                "pid": "unknown",
                                "type": "active"
                            })
                else:
                    # Lock file exists but no process holding it (stale)
                    locks_found.append({
                        "file": lock_file,
                        "process": "none",
                        "pid": "none",
                        "type": "stale"
                    })
        
        # Separate active locks from stale locks
        active_locks: List[Dict[str, str]] = [l for l in locks_found if l['type'] == 'active']
        stale_locks: List[Dict[str, str]] = [l for l in locks_found if l['type'] == 'stale']
        
        # Only FAIL if there are ACTIVE locks (process holding them)
        if active_locks:
            lock: Dict[str, str] = active_locks[0]
            message: str = f"dpkg is locked by process {lock['process']} (PID: {lock['pid']})"
            
            remediation: List[str] = [
                f"Process holding lock: {lock['process']} (PID {lock['pid']})",
                "",
                "If process is active:",
                f"  - Check process: ps aux | grep {lock['pid']}",
                "  - Wait for process to complete (apt/dpkg operation in progress)",
                "",
                "If process is hung/stuck:",
                f"  - Kill process: sudo kill {lock['pid']}",
                "  - Clean up: sudo dpkg --configure -a",
            ]
            
            # Check for interrupted installations
            interrupted_result = self.executor.execute("dpkg -l | grep '^iU'", stream=False)
            if interrupted_result.exit_code == 0 and interrupted_result.stdout.strip():
                remediation.append("")
                remediation.append("Interrupted package installations detected:")
                remediation.append("  sudo dpkg --configure -a")
                remediation.append("  sudo apt-get install -f")
            
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=False,
                severity=self.severity,
                message=message,
                details={"locks": locks_found},
                remediation=remediation
            )
        
        # Stale locks are OK - informational only
        if stale_locks:
            return CheckResult(
                check_name=self.name,
                category=self.category,
                passed=True,
                severity=CheckSeverity.INFO,
                message=f"dpkg not locked (found {len(stale_locks)} stale lock files, safe to ignore)",
                details={"stale_locks": stale_locks},
                remediation=[
                    "Stale lock files exist but no process is holding them",
                    "These are safe to ignore - they won't block package operations",
                    "",
                    "Optional cleanup (if you want to remove them):",
                    "  sudo rm /var/lib/dpkg/lock*",
                    "  sudo rm /var/lib/apt/lists/lock",
                    "  sudo rm /var/cache/apt/archives/lock",
                ]
            )
        
        return CheckResult(
            check_name=self.name,
            category=self.category,
            passed=True,
            severity=self.severity,
            message="dpkg not locked",
            details={}
        )

