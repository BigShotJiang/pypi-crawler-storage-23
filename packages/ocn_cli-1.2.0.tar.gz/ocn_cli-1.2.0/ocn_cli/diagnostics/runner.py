"""Diagnostic runner for executing checks."""

import asyncio
import time
from datetime import datetime
from typing import Dict, List, Optional

from ocn_cli.diagnostics.base import CheckResult, CheckSeverity, DiagnosticCheck
from ocn_cli.diagnostics.result import CategoryResult, DiagnosticSummary
from ocn_cli.ssh.command_executor import CommandExecutor


class DiagnosticRunner:
    """Orchestrates execution of diagnostic checks."""
    
    def __init__(self, executor: CommandExecutor) -> None:
        """
        Initialize diagnostic runner.
        
        Args:
            executor: SSH command executor for running commands on remote server
        """
        self.executor: CommandExecutor = executor
        self.checks: List[DiagnosticCheck] = []
        self.results: List[CheckResult] = []
        self._hostname: str = ""
    
    def register_check(self, check: DiagnosticCheck) -> None:
        """
        Register a diagnostic check.
        
        Args:
            check: Diagnostic check to register
        """
        self.checks.append(check)
    
    def register_all_checks(self) -> None:
        """Register all available diagnostic checks."""
        # Import all check modules
        from ocn_cli.diagnostics.checks import (
            network,
            dns,
            keygen,
            docker_install,
            containers,
            dpkg_lock,
            resources,
            services,
            logs,
            time_sync,
        )
        
        # Network checks
        self.register_check(network.InternetConnectivityCheck(self.executor))
        self.register_check(network.NetworkInterfaceCheck(self.executor))
        self.register_check(network.DefaultGatewayCheck(self.executor))
        
        # DNS checks
        self.register_check(dns.DNSResolutionCheck(self.executor))
        
        # keygen.sh check
        self.register_check(keygen.KeygenAccessibilityCheck(self.executor))
        
        # Docker checks
        self.register_check(docker_install.DockerInstallationCheck(self.executor))
        self.register_check(containers.ContainerStatusCheck(self.executor))
        
        # System checks
        self.register_check(dpkg_lock.DpkgLockCheck(self.executor))
        self.register_check(resources.CPUUsageCheck(self.executor))
        self.register_check(resources.MemoryUsageCheck(self.executor))
        self.register_check(resources.DiskSpaceCheck(self.executor))
        self.register_check(resources.SystemLoadCheck(self.executor))
        self.register_check(logs.LogSizeCheck(self.executor))
        self.register_check(time_sync.TimeSynchronizationCheck(self.executor))
        
        # Service checks
        self.register_check(services.DockerDaemonCheck(self.executor))
        self.register_check(services.NginxServiceCheck(self.executor))
        self.register_check(services.FirewallCheck(self.executor))
    
    def filter_checks(
        self,
        categories: Optional[List[str]] = None,
        check_names: Optional[List[str]] = None,
        quick_mode: bool = False
    ) -> None:
        """
        Filter checks based on criteria.
        
        Args:
            categories: List of categories to include (None = all)
            check_names: List of check names to include (None = all)
            quick_mode: If True, only run critical checks
        """
        filtered: List[DiagnosticCheck] = []
        
        for check in self.checks:
            # Filter by category
            if categories and check.category not in categories:
                continue
            
            # Filter by name
            if check_names and check.name not in check_names:
                continue
            
            # Filter by quick mode (only critical checks)
            if quick_mode and check.severity != CheckSeverity.CRITICAL:
                continue
            
            filtered.append(check)
        
        self.checks = filtered
    
    async def run_all(
        self,
        parallel: bool = True,
        fail_fast: bool = False
    ) -> List[CheckResult]:
        """
        Execute all registered checks.
        
        Args:
            parallel: Run independent checks in parallel
            fail_fast: Stop on first failure
            
        Returns:
            List[CheckResult]: Results from all checks
        """
        self.results = []
        
        # Sort checks: critical first
        sorted_checks: List[DiagnosticCheck] = sorted(
            self.checks,
            key=lambda c: (c.severity != CheckSeverity.CRITICAL, c.name)
        )
        
        if parallel:
            # Run checks in parallel
            tasks: List = []
            for check in sorted_checks:
                if not await check.can_run():
                    continue
                tasks.append(self._execute_check(check))
            
            results: List[CheckResult] = await asyncio.gather(*tasks, return_exceptions=True)
            
            for result in results:
                if isinstance(result, CheckResult):
                    self.results.append(result)
                    if fail_fast and not result.passed:
                        break
        else:
            # Run checks sequentially
            for check in sorted_checks:
                if not await check.can_run():
                    continue
                
                result: CheckResult = await self._execute_check(check)
                self.results.append(result)
                
                if fail_fast and not result.passed:
                    break
        
        return self.results
    
    async def _execute_check(self, check: DiagnosticCheck) -> CheckResult:
        """
        Execute a single check with timing.
        
        Args:
            check: Check to execute
            
        Returns:
            CheckResult: Result of the check
        """
        start_time: float = time.time()
        
        try:
            result: CheckResult = await check.execute()
            result.execution_time_ms = (time.time() - start_time) * 1000
            return result
        except Exception as e:
            # If check fails with exception, return error result
            return CheckResult(
                check_name=check.name,
                category=check.category,
                passed=False,
                severity=check.severity,
                message=f"Check failed with error: {str(e)}",
                execution_time_ms=(time.time() - start_time) * 1000
            )
    
    def get_summary(self) -> DiagnosticSummary:
        """
        Get summary statistics from results.
        
        Returns:
            DiagnosticSummary: Summary statistics
        """
        passed: int = sum(1 for r in self.results if r.passed)
        failed: int = sum(1 for r in self.results if not r.passed)
        warnings: int = sum(
            1 for r in self.results
            if not r.passed and r.severity == CheckSeverity.WARNING
        )
        total_time: float = sum(r.execution_time_ms for r in self.results)
        
        return DiagnosticSummary(
            total_checks=len(self.results),
            passed=passed,
            failed=failed,
            warnings=warnings,
            execution_time_ms=total_time,
            server_hostname=self._hostname,
            timestamp=datetime.now().isoformat(),
        )
    
    def get_results_by_category(self) -> List[CategoryResult]:
        """
        Group results by category.
        
        Returns:
            List[CategoryResult]: Results grouped by category
        """
        categories: Dict[str, List[CheckResult]] = {}
        
        for result in self.results:
            if result.category not in categories:
                categories[result.category] = []
            categories[result.category].append(result)
        
        return [
            CategoryResult(category=cat, checks=checks)
            for cat, checks in sorted(categories.items())
        ]
    
    async def get_hostname(self) -> str:
        """
        Get the remote server hostname.
        
        Returns:
            str: Hostname
        """
        if not self._hostname:
            try:
                result = self.executor.execute("hostname", stream=False)
                self._hostname = result.stdout.strip() if result.exit_code == 0 else "unknown"
            except Exception:
                self._hostname = "unknown"
        return self._hostname

