"""Report formatters for diagnostic results."""

import json
from abc import ABC, abstractmethod
from typing import List

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from ocn_cli.diagnostics.base import CheckResult, CheckSeverity
from ocn_cli.diagnostics.result import CategoryResult, DiagnosticSummary


class DiagnosticFormatter(ABC):
    """Base class for diagnostic formatters."""
    
    @abstractmethod
    def format(
        self,
        summary: DiagnosticSummary,
        results: List[CheckResult],
        categories: List[CategoryResult],
    ) -> str:
        """
        Format diagnostic results.
        
        Args:
            summary: Diagnostic summary statistics
            results: All check results
            categories: Results grouped by category
            
        Returns:
            str: Formatted report
        """
        pass


class TextFormatter(DiagnosticFormatter):
    """Text formatter using Rich for terminal output."""
    
    def __init__(self) -> None:
        """Initialize text formatter."""
        # Import console from ui.formatters to use shared instance
        from ocn_cli.ui.formatters import console as shared_console
        self.console: Console = shared_console
    
    def format_to_file(
        self,
        summary: DiagnosticSummary,
        results: List[CheckResult],
        categories: List[CategoryResult],
    ) -> str:
        """
        Format results as plain text string for file output.
        
        Args:
            summary: Diagnostic summary
            results: All check results
            categories: Results grouped by category
            
        Returns:
            str: Formatted report as plain text
        """
        lines: List[str] = []
        
        # Header
        lines.append("=" * 80)
        lines.append("OCN Server Diagnostic Report")
        lines.append("=" * 80)
        lines.append(f"Server: {summary.server_hostname}")
        lines.append(f"Date: {summary.timestamp}")
        lines.append(f"OCN Version: {summary.ocn_version}")
        lines.append(f"Health Score: {summary.health_score:.0f}% ({summary.passed}/{summary.total_checks} checks passed)")
        lines.append("=" * 80)
        lines.append("")
        
        # Categories
        for category in categories:
            lines.append(f"--- {category.category.title()} Diagnostics ---")
            lines.append("")
            
            for check in category.checks:
                icon: str = "✅" if check.passed else "❌"
                lines.append(f"{icon} {check.check_name}: {check.message}")
                
                if check.remediation:
                    lines.append("   Remediation:")
                    for step in check.remediation:
                        lines.append(f"   {step}")
                lines.append("")
            
            lines.append("")
        
        # Footer
        if summary.has_failures:
            lines.append(f"⚠️  {summary.failed} check(s) failed.")
        else:
            lines.append("✅ All checks passed!")
        
        lines.append(f"\nDiagnostics completed in {summary.execution_time_ms:.0f}ms")
        
        return "\n".join(lines)
    
    def format(
        self,
        summary: DiagnosticSummary,
        results: List[CheckResult],
        categories: List[CategoryResult],
    ) -> str:
        """
        Format results as Rich text and print directly to console.
        
        Args:
            summary: Diagnostic summary
            results: All check results
            categories: Results grouped by category
            
        Returns:
            str: Empty string (output printed directly)
        """
        # Create header panel
        header_content: str = (
            f"Server: {summary.server_hostname}\n"
            f"Date: {summary.timestamp}\n"
            f"OCN Version: {summary.ocn_version}\n\n"
            f"Health Score: {summary.health_score:.0f}% "
            f"({summary.passed}/{summary.total_checks} checks passed)"
        )
        
        header: Panel = Panel(
            header_content,
            title="[bold]OCN Server Diagnostic Report[/bold]",
            border_style="cyan",
            padding=(1, 2),
        )
        
        # Print header
        self.console.print(header)
        self.console.print()
        
        # Format each category
        for category in categories:
            self.console.print(f"[bold cyan]━━━ {category.category.title()} Diagnostics ━━━[/bold cyan]")
            
            for check in category.checks:
                self._format_check_result(check)
            
            self.console.print()
        
        # Summary footer
        if summary.has_failures:
            self.console.print(
                f"[red]⚠️  {summary.failed} check(s) failed. Review remediation steps above.[/red]"
            )
        else:
            self.console.print(
                f"[green]✅ All checks passed! OCN server is healthy.[/green]"
            )
        
        self.console.print(
            f"\n[dim]Diagnostics completed in {summary.execution_time_ms:.0f}ms[/dim]"
        )
        
        # Return empty string since we printed directly
        return ""
    
    def _format_check_result(self, check: CheckResult) -> None:
        """Format a single check result."""
        # Choose icon based on result
        if check.passed and check.severity == CheckSeverity.WARNING:
            icon: str = "⚠️ "
            style: str = "yellow"
        elif check.passed:
            icon = "✅"
            style = "green"
        else:
            icon = "❌"
            style = "red"
        
        # Format check line
        self.console.print(
            f"{icon} {check.check_name:<25} {check.message}",
            style=style
        )
        
        # Show remediation for failures
        if not check.passed or (check.passed and check.severity == CheckSeverity.WARNING and check.remediation):
            if check.remediation:
                self.console.print("   [dim]Remediation:[/dim]")
                for step in check.remediation:
                    if step:  # Skip empty lines in main output, show as spacing
                        self.console.print(f"   [yellow]{step}[/yellow]")
                    else:
                        self.console.print()


class JSONFormatter(DiagnosticFormatter):
    """JSON formatter for machine-readable output."""
    
    def format(
        self,
        summary: DiagnosticSummary,
        results: List[CheckResult],
        categories: List[CategoryResult],
    ) -> str:
        """Format results as JSON."""
        # Convert to dict
        output: dict = {
            "summary": {
                "server_hostname": summary.server_hostname,
                "timestamp": summary.timestamp,
                "ocn_version": summary.ocn_version,
                "health_score": summary.health_score,
                "total_checks": summary.total_checks,
                "passed": summary.passed,
                "failed": summary.failed,
                "warnings": summary.warnings,
                "execution_time_ms": summary.execution_time_ms,
            },
            "categories": [],
            "results": [],
        }
        
        # Add categories
        for category in categories:
            output["categories"].append({
                "name": category.category,
                "total": category.total,
                "passed": category.passed,
                "failed": category.failed,
            })
        
        # Add all results
        for check in results:
            output["results"].append({
                "check_name": check.check_name,
                "category": check.category,
                "passed": check.passed,
                "severity": check.severity.value,
                "message": check.message,
                "details": check.details,
                "remediation": check.remediation,
                "execution_time_ms": check.execution_time_ms,
            })
        
        return json.dumps(output, indent=2)


class HTMLFormatter(DiagnosticFormatter):
    """HTML formatter for web-viewable reports."""
    
    def format(
        self,
        summary: DiagnosticSummary,
        results: List[CheckResult],
        categories: List[CategoryResult],
    ) -> str:
        """Format results as HTML."""
        # Build HTML report
        html: str = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OCN Diagnostic Report - {summary.server_hostname}</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
            line-height: 1.6;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: #f5f5f5;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 20px;
        }}
        .header h1 {{ margin: 0 0 10px 0; }}
        .health-score {{
            font-size: 2em;
            font-weight: bold;
            margin: 10px 0;
        }}
        .category {{
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .category h2 {{
            margin-top: 0;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }}
        .check {{
            padding: 15px;
            margin: 10px 0;
            border-left: 4px solid;
            border-radius: 4px;
        }}
        .check.pass {{ 
            border-color: #10b981; 
            background: #f0fdf4;
        }}
        .check.fail {{ 
            border-color: #ef4444; 
            background: #fef2f2;
        }}
        .check.warning {{ 
            border-color: #f59e0b; 
            background: #fffbeb;
        }}
        .check-header {{
            font-weight: bold;
            margin-bottom: 5px;
        }}
        .check-message {{
            color: #666;
            margin-bottom: 10px;
        }}
        .remediation {{
            background: #fef3c7;
            border-left: 3px solid #f59e0b;
            padding: 10px;
            margin-top: 10px;
            font-family: monospace;
            font-size: 0.9em;
        }}
        .remediation-title {{
            font-weight: bold;
            margin-bottom: 5px;
        }}
        .footer {{
            text-align: center;
            color: #666;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🔧 OCN Server Diagnostic Report</h1>
        <div>Server: {summary.server_hostname}</div>
        <div>Date: {summary.timestamp}</div>
        <div>OCN Version: {summary.ocn_version}</div>
        <div class="health-score">
            Health Score: {summary.health_score:.0f}%
            ({summary.passed}/{summary.total_checks} checks passed)
        </div>
    </div>
"""
        
        # Add each category
        for category in categories:
            html += f'    <div class="category">\n'
            html += f'        <h2>{category.category.title()} Diagnostics</h2>\n'
            
            for check in category.checks:
                css_class: str = "pass" if check.passed else ("warning" if check.severity == CheckSeverity.WARNING else "fail")
                icon: str = "✅" if check.passed else ("⚠️" if check.severity == CheckSeverity.WARNING else "❌")
                
                html += f'        <div class="check {css_class}">\n'
                html += f'            <div class="check-header">{icon} {check.check_name}</div>\n'
                html += f'            <div class="check-message">{check.message}</div>\n'
                
                if check.remediation:
                    html += '            <div class="remediation">\n'
                    html += '                <div class="remediation-title">Remediation:</div>\n'
                    for step in check.remediation:
                        html += f'                <div>{step}</div>\n'
                    html += '            </div>\n'
                
                html += '        </div>\n'
            
            html += '    </div>\n'
        
        # Footer
        html += f"""
    <div class="footer">
        Report generated in {summary.execution_time_ms:.0f}ms by OCN CLI
    </div>
</body>
</html>
"""
        
        return html


def get_formatter(format_type: str) -> DiagnosticFormatter:
    """
    Get a formatter instance based on format type.
    
    Args:
        format_type: Format type (text, json, html)
        
    Returns:
        DiagnosticFormatter: Formatter instance
    """
    if format_type == "json":
        return JSONFormatter()
    elif format_type == "html":
        return HTMLFormatter()
    else:
        return TextFormatter()

