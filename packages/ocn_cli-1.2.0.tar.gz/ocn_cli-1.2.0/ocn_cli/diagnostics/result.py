"""Result data structures for diagnostics."""

from dataclasses import dataclass, field
from typing import List

from ocn_cli.diagnostics.base import CheckResult


@dataclass
class CategoryResult:
    """Results grouped by category."""
    
    category: str
    checks: List[CheckResult] = field(default_factory=list)
    
    @property
    def passed(self) -> int:
        """Count of passed checks in this category."""
        return sum(1 for check in self.checks if check.passed)
    
    @property
    def failed(self) -> int:
        """Count of failed checks in this category."""
        return sum(1 for check in self.checks if not check.passed)
    
    @property
    def total(self) -> int:
        """Total number of checks in this category."""
        return len(self.checks)


@dataclass
class DiagnosticSummary:
    """Summary statistics for diagnostic run."""
    
    total_checks: int = 0
    passed: int = 0
    failed: int = 0
    warnings: int = 0
    execution_time_ms: float = 0.0
    server_hostname: str = ""
    timestamp: str = ""
    ocn_version: str = "unknown"
    
    @property
    def health_score(self) -> float:
        """
        Calculate health score as percentage of passed checks.
        
        Returns:
            float: Health score (0.0 to 100.0)
        """
        if self.total_checks == 0:
            return 0.0
        return (self.passed / self.total_checks) * 100.0
    
    @property
    def has_failures(self) -> bool:
        """Check if any checks failed."""
        return self.failed > 0
    
    @property
    def has_warnings(self) -> bool:
        """Check if any checks raised warnings."""
        return self.warnings > 0

