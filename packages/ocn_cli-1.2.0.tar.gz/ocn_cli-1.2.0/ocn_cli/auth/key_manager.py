"""SSH key management for user-provided keys."""

from pathlib import Path
from typing import Optional

import paramiko

from ocn_cli.utils.security import check_key_permissions, validate_key_format


class KeyManager:
    """Manages user-provided SSH keys."""
    
    def __init__(self) -> None:
        """Initialize the key manager."""
        pass
    
    def __enter__(self) -> "KeyManager":
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # type: ignore
        """Context manager exit."""
        pass
    
    def load_user_key(self, key_path: Path) -> paramiko.PKey:
        """
        Load a user-provided SSH private key.
        
        Args:
            key_path: Path to the SSH private key file
            
        Returns:
            paramiko.PKey: Loaded SSH key (RSA, Ed25519, ECDSA, or DSS)
            
        Raises:
            FileNotFoundError: If key file doesn't exist
            ValueError: If key file is invalid or has insecure permissions
        """
        # Check if file exists
        if not key_path.exists():
            raise FileNotFoundError(f"SSH key file not found: {key_path}")
        
        # Check if file is readable
        if not key_path.is_file():
            raise ValueError(f"Path is not a file: {key_path}")
        
        # Check permissions
        perm_warning: Optional[str] = check_key_permissions(key_path)
        if perm_warning:
            # Print warning but continue
            from ocn_cli.ui.formatters import format_warning
            format_warning(perm_warning)
        
        # Read and validate key data
        try:
            with open(key_path, "rb") as f:
                key_data: bytes = f.read()
            
            if not validate_key_format(key_data):
                raise ValueError(
                    f"File does not appear to be a valid SSH private key: {key_path}"
                )
            
            # Try to load the key (will handle various key types)
            try:
                return paramiko.RSAKey.from_private_key_file(str(key_path))
            except paramiko.PasswordRequiredException:
                raise ValueError(
                    f"SSH key is encrypted with a passphrase: {key_path}\n"
                    "Please provide an unencrypted key or decrypt it first."
                )
            except paramiko.SSHException:
                # Try other key types
                try:
                    return paramiko.Ed25519Key.from_private_key_file(str(key_path))
                except paramiko.SSHException:
                    try:
                        return paramiko.ECDSAKey.from_private_key_file(str(key_path))
                    except paramiko.SSHException:
                        try:
                            return paramiko.DSSKey.from_private_key_file(str(key_path))
                        except paramiko.SSHException as e:
                            raise ValueError(f"Could not load SSH key: {e}")
                            
        except (OSError, IOError) as e:
            raise ValueError(f"Error reading key file: {e}")

