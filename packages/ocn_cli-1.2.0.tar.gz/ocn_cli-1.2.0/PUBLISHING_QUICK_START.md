# Quick Start: Publishing OCN CLI

A condensed guide for publishing OCN CLI to PyPI.

---

## One-Time Setup (5 minutes)

### 1. Create PyPI Account
```
Visit: https://pypi.org/account/register/
Create account and verify email
```

### 2. Configure Trusted Publishing on PyPI
```
1. Login to https://pypi.org
2. Account Settings → Publishing
3. Add pending publisher:
   - PyPI Project: ocn-cli
   - Owner: your-github-org
   - Repo: ocn
   - Workflow: publish-ocn-cli.yml
   - Environment: pypi
```

### 3. Create GitHub Environment
```
1. GitHub repo → Settings → Environments
2. Create environment: "pypi"
3. (Optional) Add protection rules
```

### 4. Test with Test PyPI (Recommended)
```
Repeat steps 2-3 for test.pypi.org with environment "test-pypi"
```

✅ **Setup complete!** You only need to do this once.

---

## Publishing a New Version (2 minutes)

### Method 1: GitHub Release (Automated) ⭐ Recommended

```bash
# 1. Update version
vim cli/ocn_cli/version.py
# Change: __version__ = "1.1.0"

# 2. Update changelog
vim cli/CHANGELOG.md
# Add entry for v1.1.0

# 3. Commit and push
git add cli/ocn_cli/version.py cli/CHANGELOG.md
git commit -m "Release OCN CLI v1.1.0"
git push origin main

# 4. Create GitHub release
# Go to: https://github.com/your-org/ocn/releases/new
# - Tag: cli-v1.1.0
# - Title: OCN CLI v1.1.0
# - Description: Copy from CHANGELOG.md
# - Click "Publish release"

# ✅ Done! GitHub Actions automatically publishes to PyPI
```

### Method 2: Manual Trigger (For Testing)

```bash
# Go to: Actions → Publish OCN CLI → Run workflow
# Select: Publish to Test PyPI = true
# Click: Run workflow
```

### Method 3: Local Manual Upload

```bash
cd cli

# Build
python -m build

# Upload to Test PyPI (test first!)
twine upload --repository testpypi dist/*

# Upload to Production PyPI
twine upload dist/*
```

---

## Verification (1 minute)

```bash
# Check PyPI
open https://pypi.org/project/ocn-cli/

# Test installation
pip install --upgrade ocn-cli

# Verify version
ocn-cli --version
```

---

## Troubleshooting

| Error | Fix |
|-------|-----|
| Version already exists | Increment version number |
| Authentication failed | Check PyPI trusted publishing setup |
| Build failed | Run `python -m build` locally to see errors |
| Tests failed | Fix failing tests before publishing |

---

## Release Checklist

- [ ] Version updated in `ocn_cli/version.py`
- [ ] CHANGELOG.md updated
- [ ] Tests passing locally
- [ ] Committed and pushed to main
- [ ] GitHub release created with tag `cli-vX.Y.Z`
- [ ] Workflow completed successfully
- [ ] Package visible on PyPI
- [ ] Installation tested: `pip install ocn-cli`

---

**For detailed instructions, see [PUBLISHING.md](PUBLISHING.md)**

