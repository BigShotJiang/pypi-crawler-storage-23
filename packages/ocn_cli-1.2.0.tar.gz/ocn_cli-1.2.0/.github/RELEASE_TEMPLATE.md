# OCN CLI Release vX.Y.Z

## What's New

<!-- Describe the main features/fixes in this release -->

### New Features
- Feature 1
- Feature 2

### Bug Fixes
- Fix 1
- Fix 2

### Improvements
- Improvement 1
- Improvement 2

---

## Installation

Install or upgrade to this version:

```bash
pip install --upgrade ocn-cli
```

Verify installation:
```bash
ocn-cli --version
```

Should show: `OCN CLI version X.Y.Z`

---

## Breaking Changes

<!-- List any breaking changes that require user action -->

- None

---

## Documentation

- [README](https://github.com/your-org/ocn/blob/main/cli/README.md)
- [Diagnostics Guide](https://github.com/your-org/ocn/blob/main/cli/DIAGNOSTICS.md)
- [Changelog](https://github.com/your-org/ocn/blob/main/cli/CHANGELOG.md)

---

## Full Changelog

See [CHANGELOG.md](https://github.com/your-org/ocn/blob/main/cli/CHANGELOG.md) for complete version history.

