# OCN CLI - Offline Updates Guide

This guide explains how to update OCN servers that are **completely offline** (no internet access) using the `offline-update` command.

---

## Overview

The `offline-update` command allows you to:
1. **Upload** an OCN update package from your local machine
2. **Validate** the package structure
3. **Apply** the update automatically
4. **Monitor** the update progress in real-time

**No internet required on the OCN server!**

---

## Prerequisites

### On the OCN Server (Offline)
- ✅ Docker CE already installed (docker.io or docker-ce)
- ✅ OCN currently running
- ✅ SSH access enabled
- ✅ User has sudo privileges
- ✅ Sufficient disk space for update package

### On Your Machine (With Internet)
- ✅ ocn-cli installed
- ✅ SSH key for OCN server
- ✅ Downloaded OCN update package

---

## Quick Start

### Step 1: Get Update Package

On a machine with internet access, download the OCN release:

```bash
# Option A: Download from keygen.sh (if you have access)
python3 /etc/ocn/ocn-installer/keygen.py --download \
    -a 5f751d4e-b1ae-4cd6-9c8c-a5076e8fb8b5 \
    -p 68ed0479-06a1-4f58-8562-24a24219f551 \
    -l /path/to/key.key \
    -d /tmp \
    -c stable

# This downloads: OCN-2.1.X-stable.tar.gz
```

The package structure should be:
```
ocn-installer/
├── docker-compose.yml
├── scripts/
├── images/              # ← Docker images as .tar.gz
│   ├── ocn-api.tar.gz
│   ├── ocn-v2.tar.gz
│   └── ocn-ai-services.tar.gz
├── VERSION              # ← Version file
└── ... other files
```

### Step 2: Transfer to Offline Network

Transfer the package file to a machine that can reach the offline OCN server:

```bash
# Use USB drive, internal network, or any available method
cp OCN-2.1.10-stable.tar.gz /media/usb/
```

### Step 3: Connect to OCN Server

```bash
ocn-cli --host offline-server.local --key ~/.ssh/ocn_key
```

When prompted, enter sudo password (required for update).

### Step 4: Apply Offline Update

```bash
ocn@offline-server>> offline-update --package /local/path/to/OCN-2.1.10-stable.tar.gz
```

**Interactive process:**
```
═══ OCN Offline Update ═══

📦 Uploading package: OCN-2.1.10-stable.tar.gz (245.3MB)

Uploading OCN-2.1.10... ████████████████████ 100% 245.3 MB 15.2 MB/s 0:00:00

✅ Package uploaded successfully

🔍 Validating package structure...
✅ Package validation passed

📂 Extracting package...
✅ Package extracted

╭─── Update Preview ───────────────────────────────╮
│                                                  │
│ Update Package Information:                     │
│                                                  │
│ Version: 2.1.10                                  │
│                                                  │
│ Docker Images:                                   │
│   • ocn-api.tar.gz                              │
│   • ocn-v2.tar.gz                               │
│   • ocn-ai-services.tar.gz                      │
│                                                  │
│ This will:                                       │
│   1. Stop all OCN containers                     │
│   2. Update installer files                      │
│   3. Load new Docker images                      │
│   4. Restart containers with new images          │
│                                                  │
│ Estimated downtime: ~2-5 minutes                 │
│                                                  │
╰──────────────────────────────────────────────────╯

Proceed with offline update? (y/n): y

🚀 Applying update...

Running update script...
Stopping containers...
Updating installer files...
Loading Docker images...
  Loading ocn-api.tar.gz...
  Loading ocn-v2.tar.gz...
  Loading ocn-ai-services.tar.gz...
Starting containers...

✅ Update completed successfully! OCN v2.1.10 is now running
```

---

## Creating Offline Update Packages

### Method 1: From Existing Installation

On an online OCN server with the target version:

```bash
# Save all Docker images
cd /tmp
docker save -o ocn-api.tar.gz stratoautomation/ocn-api:stable
docker save -o ocn-v2.tar.gz stratoautomation/ocn-v2:stable
docker save -o ocn-ai-services.tar.gz stratoautomation/ocn-ai-services:stable

# Create images directory
mkdir -p ocn-installer/images
mv *.tar.gz ocn-installer/images/

# Copy installer files
cp -r /etc/ocn/ocn-installer/* ocn-installer/

# Create package
tar -czf ocn-update-2.1.10-offline.tar.gz ocn-installer/

# Transfer this file to offline network
```

### Method 2: From GitHub Container Registry

```bash
# Pull images
docker pull ghcr.io/stratoautomation/ocn-api:stable
docker pull ghcr.io/stratoautomation/ocn-v2:stable
docker pull ghcr.io/stratoautomation/ocn-ai-services:stable

# Save images
docker save -o ocn-api.tar.gz ghcr.io/stratoautomation/ocn-api:stable
docker save -o ocn-v2.tar.gz ghcr.io/stratoautomation/ocn-v2:stable
docker save -o ocn-ai-services.tar.gz ghcr.io/stratoautomation/ocn-ai-services:stable

# Get installer files from GitHub
git clone https://github.com/your-org/ocn.git
cd ocn/ocn-installer

# Create package
mkdir -p package/ocn-installer/images
cp -r * package/ocn-installer/
mv *.tar.gz package/ocn-installer/images/
cd package
tar -czf ocn-update-2.1.10-offline.tar.gz ocn-installer/
```

---

## Advanced Usage

### Dry-Run Mode (Check Without Applying)

```bash
# Just validate the package without applying
ocn@server>> offline-update --package update.tar.gz --help
```

### Skip Confirmation (Automation)

```bash
# For automated deployments
ocn@server>> offline-update --package update.tar.gz --skip-confirmation
```

### Check Current Version First

```bash
ocn@server>> cat /etc/ocn/ocn-installer/VERSION
2.0.5

ocn@server>> offline-update --package ocn-update-2.1.10.tar.gz
# Will upgrade: 2.0.5 → 2.1.10
```

---

## Troubleshooting

### Upload Fails

**Error:** `Upload failed: Connection timeout`

**Solutions:**
- Package too large - split if needed
- Network unstable - retry
- SFTP disabled - enable in sshd_config

### Package Validation Fails

**Error:** `has_images: False`

**Solutions:**
```bash
# Check package contents
tar -tzf update.tar.gz | grep images

# Should show:
ocn-installer/images/ocn-api.tar.gz
ocn-installer/images/ocn-v2.tar.gz
```

### Docker Load Fails

**Error:** `Error loading image`

**Solutions:**
- Check disk space: `df -h`
- Verify image integrity: `gzip -t image.tar.gz`
- Check Docker daemon: `systemctl status docker`

### Containers Won't Start

**Error:** `docker-compose up fails`

**Solutions:**
```bash
# Check logs
docker-compose -f /etc/ocn/ocn-installer/docker-compose.yml logs

# Verify images loaded
docker images | grep ocn

# Check docker-compose file
cat /etc/ocn/ocn-installer/docker-compose.yml
```

---

## Limitations (Phase 1)

**What is NOT supported in offline mode:**

❌ **Docker migration** (docker.io → docker-ce)
   - Requires pre-installed Docker CE
   - Or manual migration before offline update

❌ **System package updates** (apt packages)
   - Must be done separately if needed

❌ **Kernel updates**
   - Must be done separately

❌ **Download from keygen.sh**
   - Package must be pre-downloaded

**What IS supported:**

✅ **OCN version updates** (installer + Docker images)
✅ **Container updates** (all OCN services)
✅ **Configuration updates** (docker-compose.yml, scripts)
✅ **Automated rollout** (upload once, apply to multiple servers)

---

## Workflow for Multiple Offline Servers

### Scenario: Update 10 offline OCN servers

1. **Download once** (online machine):
   ```bash
   # Download OCN-2.1.10-stable.tar.gz
   ```

2. **Transfer to offline network** (USB/sneakernet):
   ```bash
   cp OCN-2.1.10-stable.tar.gz /media/usb/
   ```

3. **Copy to jump box** in offline network

4. **Apply to each server** via ocn-cli:
   ```bash
   # Server 1
   ocn-cli --host server1 --key ~/.ssh/ocn_key
   ocn@server1>> offline-update --package ~/OCN-2.1.10-stable.tar.gz
   
   # Server 2
   ocn-cli --host server2 --key ~/.ssh/ocn_key
   ocn@server2>> offline-update --package ~/OCN-2.1.10-stable.tar.gz
   
   # ... repeat for all servers
   ```

---

## Safety Features

✅ **Package validation** before applying
✅ **Version display** in preview
✅ **Confirmation prompt** (can skip with --skip-confirmation)
✅ **Progress tracking** during upload
✅ **Real-time output** during update
✅ **Automatic cleanup** of temporary files
✅ **Error recovery** (cleanup on failure)

---

## Next Steps (Future Phases)

### Phase 2: Docker Migration Support
- Bundle Docker CE .deb packages
- Offline docker-migration.sh script
- Dependency resolution

### Phase 3: System Updates
- Bundle system packages
- Kernel updates
- Full offline capability

---

## See Also

- [README.md](README.md) - Main OCN CLI documentation
- [DIAGNOSTICS.md](DIAGNOSTICS.md) - Diagnostic checks
- [ocn-installer/scripts/update.sh](../ocn-installer/scripts/update.sh) - Online update script (reference)

---

**Status:** ✅ Phase 1 implemented - Basic offline updates without Docker migration

