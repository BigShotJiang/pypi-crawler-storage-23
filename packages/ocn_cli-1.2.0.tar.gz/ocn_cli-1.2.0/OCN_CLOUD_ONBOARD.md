# Complete Guide: Onboarding an OCN Server to OCN-Cloud

This guide walks you through the **entire process** of onboarding an OCN server to OCN-cloud — from installing Python on your computer to running the onboard command.

---

## Table of Contents

1. [Overview](#overview)
2. [Prerequisites Checklist](#prerequisites-checklist)
3. [Step 1: Install Python](#step-1-install-python)
4. [Step 2: Install OCN CLI](#step-2-install-ocn-cli)
5. [Step 3: Get a Tailscale Auth Key](#step-3-get-a-tailscale-auth-key)
6. [Step 4: Connect to the OCN Server](#step-4-connect-to-the-ocn-server)
7. [Step 5: Run the Onboard Command](#step-5-run-the-onboard-command)
8. [What Happens During Onboarding](#what-happens-during-onboarding)
9. [Verifying Success](#verifying-success)
10. [Troubleshooting](#troubleshooting)

---

## Overview

The `onboard` command prepares an OCN server for OCN-cloud connectivity by:

1. **Removing OpenVPN** — Uninstalls openvpn, openvpn3, connexa packages and disables any openvpn* services
2. **Setting hostname** — Configures a stable hostname for the server
3. **Joining Tailscale** — Installs Tailscale (if needed) and joins the machine to your Tailscale network
4. **Rebooting** — Restarts the server so all changes take effect

**Supported platforms:** Debian and Ubuntu only (the OCN server).

**Your machine (where you run ocn-cli):** Windows, macOS, or Linux.

---

## Prerequisites Checklist

Before you begin, ensure you have:

| Requirement | Details |
|-------------|---------|
| OCN server reachable | You can SSH to the server (hostname or IP) |
| OCN server OS | Debian or Ubuntu |
| Sudo password | You know the sudo password for the OCN server user |
| Tailscale account | Access to generate an auth key in the Tailscale admin console |
| Network access | Your machine and the OCN server both have internet (for Tailscale install) |

---

## Step 1: Install Python

OCN CLI requires **Python 3.9 or higher**. Check if Python is already installed:

```bash
python3 --version
# or
python --version
```

You should see something like `Python 3.10.12` or higher. If not, install Python:

### macOS

**Option A: Homebrew (recommended)**

```bash
# Install Homebrew if you don't have it: https://brew.sh
brew install python@3.11
```

**Option B: Official installer**

1. Download from [python.org/downloads](https://www.python.org/downloads/)
2. Run the installer
3. During setup, check **"Add Python to PATH"**

### Windows

**Option A: Microsoft Store**

1. Open Microsoft Store
2. Search for **Python 3.11** (or 3.12)
3. Click **Get** / **Install**

**Option B: Official installer**

1. Download from [python.org/downloads](https://www.python.org/downloads/)
2. Run the installer
3. Check **"Add python.exe to PATH"** before clicking Install
4. Restart your terminal after installation

### Linux (Debian/Ubuntu)

```bash
sudo apt update
sudo apt install python3 python3-pip
```

### Verify Installation

```bash
python3 --version
pip3 --version
```

---

## Step 2: Install OCN CLI

### Install from PyPI (recommended)
On windows, you must open a terminal as **administrator** to install the ocn-cli.

```bash
pip install ocn-cli
```

Or with `pip3`:

```bash
pip3 install ocn-cli
```
Or on windows, you can use the following command:
```bash
python -m pip install ocn-cli
```

### Install from Source (development)

```bash
git clone https://github.com/stratoautomation/ocn.git
cd ocn/cli
pip install -e .
```

### Verify Installation

```bash
ocn-cli --help
```

You should see the OCN CLI help output. If you get "command not found":

- **Windows:** Restart your terminal or add Python's `Scripts` folder to PATH
- **macOS/Linux:** Try `python3 -m ocn_cli --help` or ensure `~/.local/bin` is in your PATH

## Step 3: Get a Tailscale Auth Key

You need a **Tailscale auth key** to join the OCN server to your Tailscale network.

1. Go to [Tailscale Admin Console](https://login.tailscale.com/admin/settings/keys)
2. Log in with your Tailscale account
3. Click **Generate auth key**
4. Configure:
   - **Reusable:** Yes (if onboarding multiple servers) or No (one-time use)
   - **Tags:** Optional (e.g. `tag:ocn-servers`)
   - **Expiration:** Set as needed
5. Click **Generate key**
6. **Copy the key** — it looks like `tskey-auth-xxxxxxxxxx`

⚠️ **Store the key securely.** You won't be able to view it again after closing the dialog.

---

## Step 4: Connect to the OCN Server

Start the OCN CLI and connect:

```bash
ocn-cli --host ocn-server.local --key ~/.ssh/ocn_dev_key
```

Replace:
- `ocn-server.local` — hostname or IP of your OCN server
- `~/.ssh/ocn_dev_key` — path to your SSH private key


### When Prompted for Sudo Password

`ocn` is the default password for the `ocn` user on the OCN server.
```
🔑 Enter sudo password for remote server (optional, press Enter to skip):
```

**You must enter the sudo password.** The onboard command requires root to:
- Remove packages
- Set hostname
- Install Tailscale
- Reboot

Enter the password and press Enter (input is hidden).

### Successful Connection

You'll see:

```
OCN CLI v1.1.0 - Diagnostic tool for OCN servers
Connecting to ocn-server.local...
✅ Connected to ocn-server.local

ocn@ocn-server.local>>
```

---

## Step 5: Run the Onboard Command

At the interactive shell prompt, run:

```bash
onboard --auth-key tskey-auth-xxxxxxxxxx --hostname my-server-name
```

Replace:
- `tskey-auth-xxxxxxxxxx` — your Tailscale auth key will be provided by the Tailscale overlord. Please ask the Tailscale overlord for the auth key.
- `my-server-name` — the hostname you want for this server (lowercase letters, digits, hyphens only; no spaces)

### Get Help

```bash
onboard --help
```

---

## What Happens During Onboarding

The command runs four steps automatically:

```
═══ OCN Cloud Onboard ═══

Step 1/4: Removing OpenVPN...
OpenVPN removed / services disabled

Step 2/4: Setting hostname...
Hostname set

Step 3/4: Onboarding Tailscale...
[Install script output if Tailscale was not installed]
Tailscale joined

Step 4/4: Rebooting...
Server rebooting. Session will disconnect.
```

- **Step 1:** Uninstalls OpenVPN-related packages, disables and masks openvpn* systemd services
- **Step 2:** Runs `hostnamectl set-hostname <your-hostname>`
- **Step 3:** Installs Tailscale via official script (if needed), runs `tailscale up --auth-key=...`
- **Step 4:** Runs `sudo reboot` — the server restarts and your SSH session will disconnect

**Total time:** Typically 2–5 minutes (longer if Tailscale needs to install).

---

## Verifying Success

After the server reboots:

1. **Check Tailscale Admin Console**
   - Go to [Tailscale Machines](https://login.tailscale.com/admin/machines)
   - Look for your hostname (e.g. `ocn-server-01`)
   - Status should be **Online**

2. **Reconnect via SSH (optional)**

   If the server has a static IP or is reachable via Tailscale:

   ```bash
   ocn-cli --host ocn-server-01 --key ~/.ssh/ocn_key
   ```

3. **Verify hostname**

   ```bash
   hostname
   # Should show: ocn-server-01
   ```

---

## Troubleshooting

### Python Not Found / Command Not Found

- Ensure Python is in your PATH
- On Windows: Reinstall Python and check "Add to PATH"
- Try `python3` instead of `python`

### pip: command not found

```bash
# macOS/Linux
python3 -m ensurepip --upgrade

# Or install pip separately
sudo apt install python3-pip   # Debian/Ubuntu
brew install python            # macOS (includes pip)
```

### ocn-cli: command not found

```bash
# Run as module instead
python3 -m ocn_cli --host server --key ~/.ssh/key

# Or add user install location to PATH (Linux/macOS)
export PATH="$PATH:$HOME/.local/bin"
```

### SSH Connection Refused

- Verify SSH is enabled on the OCN server: `systemctl status ssh` or `systemctl status sshd`
- Check firewall allows SSH (port 22)
- Confirm hostname/IP and port

### Authentication Failed (SSH)

- Ensure your public key is in `~/.ssh/authorized_keys` on the server
- Verify key path: `ocn-cli --key /full/path/to/private_key`
- Check key permissions: `chmod 600 ~/.ssh/ocn_key`

### Sudo Password Validation Failed

- Enter the correct sudo password when prompted
- The user must have sudo privileges on the OCN server

### Invalid hostname

- Use only letters, digits, and hyphens
- No spaces or underscores
- Each label max 63 characters, total max 253 characters
- Example valid: `ocn-server-01`, `building-a-hvac`

### OpenVPN package removal failed

- Ensure the OCN server is Debian or Ubuntu
- Check you have sudo access
- Run `apt update` on the server if packages are outdated

### Tailscale installation failed

- OCN server needs internet access to download the install script
- Check firewall allows outbound HTTPS (port 443)
- Verify the auth key is valid and not expired

### Tailscale join failed

- Auth key may be expired or invalid — generate a new one
- Ensure the key has not reached its device limit (for single-use keys)
- Check Tailscale admin console for error details

### Reboot failed

- Confirm sudo password was provided when connecting
- User must have permission to run `reboot`

---

## Quick Reference

| Step | Command / Action |
|------|------------------|
| Check Python | `python3 --version` |
| Install OCN CLI | `pip install ocn-cli` |
| Connect | `ocn-cli --host <server> --key ~/.ssh/ocn_key` |
| Onboard | `onboard --auth-key <key> --hostname <name>` |
| Help | `onboard --help` |

---

## See Also

- [README.md](README.md) — General OCN CLI documentation
- [OFFLINE_UPDATES.md](OFFLINE_UPDATES.md) — Updating servers without internet
- [Tailscale Auth Keys](https://login.tailscale.com/admin/settings/keys) — Generate auth keys
