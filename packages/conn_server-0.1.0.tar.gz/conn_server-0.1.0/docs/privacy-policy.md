# Privacy Policy

**Conn** — Remote control for Claude Code
**Last updated:** February 24, 2026

## Overview

Conn is a mobile app that connects to a self-hosted server you run on your own hardware. We do not operate any cloud services, user accounts, or centralized servers. Your data stays on your devices and network.

## Data Collection

### Messages and Photos

Chat messages and photos you send through the app are transmitted over your local network to the Conn server running on your own machine. From there, they are forwarded to the Claude API (operated by Anthropic) for processing.

- Messages and photos are **not** collected, stored, or processed by us
- All communication occurs directly between your device and your self-hosted server over an encrypted TLS connection
- Data sent to the Claude API is subject to [Anthropic's privacy policy](https://www.anthropic.com/privacy)

### Crash Logs

The app uses Firebase Crashlytics (operated by Google) to collect crash reports. This includes:

- Crash stack traces
- Device model and operating system version
- Crashlytics installation identifiers

Crash data is used solely to diagnose and fix bugs. It is not used for advertising or sold to third parties. Crash data collection is subject to [Google's privacy policy](https://policies.google.com/privacy).

### What We Do Not Collect

- No personal information (name, email, phone number)
- No location data
- No contacts or address book data
- No browsing history
- No advertising identifiers
- No analytics beyond crash reporting

## Data Storage

- **Authentication tokens and TLS certificates** are stored locally on your device and are never transmitted to us
- **Chat history** is cached locally on your device for offline access and synced with your self-hosted server
- **No data is stored on any server we operate**

## Third-Party Services

| Service | Purpose | Privacy Policy |
|---------|---------|----------------|
| Firebase Crashlytics (Google) | Crash reporting | [Google Privacy Policy](https://policies.google.com/privacy) |
| Claude API (Anthropic) | AI processing | [Anthropic Privacy Policy](https://www.anthropic.com/privacy) |

## Security

- All communication between the app and server uses TLS encryption with certificate pinning
- Authentication uses bearer tokens shared via QR code on your local network
- The server runs entirely on your own hardware

## Children's Privacy

Conn is not directed at children under 13. We do not knowingly collect data from children.

## Changes to This Policy

Updates to this privacy policy will be posted in the project repository. Continued use of the app after changes constitutes acceptance.

## Contact

For questions about this privacy policy, open an issue on [GitHub](https://github.com/PatrickBucaria/conn-server/issues).
