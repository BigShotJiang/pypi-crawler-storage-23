"""Conn Server — remote control server for Claude CLI."""

__version__ = "0.1.0"
