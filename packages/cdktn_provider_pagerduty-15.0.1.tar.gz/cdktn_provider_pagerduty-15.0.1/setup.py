import json
import setuptools

kwargs = json.loads(
    """
{
    "name": "cdktn-provider-pagerduty",
    "version": "15.0.1",
    "description": "Prebuilt pagerduty Provider for CDK Terrain (cdktn)",
    "license": "MPL-2.0",
    "url": "https://github.com/cdktn-io/cdktn-provider-pagerduty.git",
    "long_description_content_type": "text/markdown",
    "author": "CDK Terrain Maintainers",
    "bdist_wheel": {
        "universal": true
    },
    "project_urls": {
        "Source": "https://github.com/cdktn-io/cdktn-provider-pagerduty.git"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "cdktn_provider_pagerduty",
        "cdktn_provider_pagerduty._jsii",
        "cdktn_provider_pagerduty.addon",
        "cdktn_provider_pagerduty.alert_grouping_setting",
        "cdktn_provider_pagerduty.automation_actions_action",
        "cdktn_provider_pagerduty.automation_actions_action_service_association",
        "cdktn_provider_pagerduty.automation_actions_action_team_association",
        "cdktn_provider_pagerduty.automation_actions_runner",
        "cdktn_provider_pagerduty.automation_actions_runner_team_association",
        "cdktn_provider_pagerduty.business_service",
        "cdktn_provider_pagerduty.business_service_subscriber",
        "cdktn_provider_pagerduty.data_pagerduty_alert_grouping_setting",
        "cdktn_provider_pagerduty.data_pagerduty_automation_actions_action",
        "cdktn_provider_pagerduty.data_pagerduty_automation_actions_runner",
        "cdktn_provider_pagerduty.data_pagerduty_business_service",
        "cdktn_provider_pagerduty.data_pagerduty_escalation_policy",
        "cdktn_provider_pagerduty.data_pagerduty_event_orchestration",
        "cdktn_provider_pagerduty.data_pagerduty_event_orchestration_global_cache_variable",
        "cdktn_provider_pagerduty.data_pagerduty_event_orchestration_integration",
        "cdktn_provider_pagerduty.data_pagerduty_event_orchestration_service_cache_variable",
        "cdktn_provider_pagerduty.data_pagerduty_event_orchestrations",
        "cdktn_provider_pagerduty.data_pagerduty_extension_schema",
        "cdktn_provider_pagerduty.data_pagerduty_incident_custom_field",
        "cdktn_provider_pagerduty.data_pagerduty_incident_type",
        "cdktn_provider_pagerduty.data_pagerduty_incident_type_custom_field",
        "cdktn_provider_pagerduty.data_pagerduty_incident_workflow",
        "cdktn_provider_pagerduty.data_pagerduty_jira_cloud_account_mapping",
        "cdktn_provider_pagerduty.data_pagerduty_license",
        "cdktn_provider_pagerduty.data_pagerduty_licenses",
        "cdktn_provider_pagerduty.data_pagerduty_priority",
        "cdktn_provider_pagerduty.data_pagerduty_ruleset",
        "cdktn_provider_pagerduty.data_pagerduty_schedule",
        "cdktn_provider_pagerduty.data_pagerduty_service",
        "cdktn_provider_pagerduty.data_pagerduty_service_custom_field",
        "cdktn_provider_pagerduty.data_pagerduty_service_custom_field_value",
        "cdktn_provider_pagerduty.data_pagerduty_service_integration",
        "cdktn_provider_pagerduty.data_pagerduty_standards",
        "cdktn_provider_pagerduty.data_pagerduty_standards_resource_scores",
        "cdktn_provider_pagerduty.data_pagerduty_standards_resources_scores",
        "cdktn_provider_pagerduty.data_pagerduty_tag",
        "cdktn_provider_pagerduty.data_pagerduty_team",
        "cdktn_provider_pagerduty.data_pagerduty_team_members",
        "cdktn_provider_pagerduty.data_pagerduty_teams",
        "cdktn_provider_pagerduty.data_pagerduty_user",
        "cdktn_provider_pagerduty.data_pagerduty_user_contact_method",
        "cdktn_provider_pagerduty.data_pagerduty_users",
        "cdktn_provider_pagerduty.data_pagerduty_vendor",
        "cdktn_provider_pagerduty.enablement",
        "cdktn_provider_pagerduty.escalation_policy",
        "cdktn_provider_pagerduty.event_orchestration",
        "cdktn_provider_pagerduty.event_orchestration_global",
        "cdktn_provider_pagerduty.event_orchestration_global_cache_variable",
        "cdktn_provider_pagerduty.event_orchestration_integration",
        "cdktn_provider_pagerduty.event_orchestration_router",
        "cdktn_provider_pagerduty.event_orchestration_service",
        "cdktn_provider_pagerduty.event_orchestration_service_cache_variable",
        "cdktn_provider_pagerduty.event_orchestration_unrouted",
        "cdktn_provider_pagerduty.event_rule",
        "cdktn_provider_pagerduty.extension",
        "cdktn_provider_pagerduty.extension_servicenow",
        "cdktn_provider_pagerduty.incident_custom_field",
        "cdktn_provider_pagerduty.incident_custom_field_option",
        "cdktn_provider_pagerduty.incident_type",
        "cdktn_provider_pagerduty.incident_type_custom_field",
        "cdktn_provider_pagerduty.incident_workflow",
        "cdktn_provider_pagerduty.incident_workflow_trigger",
        "cdktn_provider_pagerduty.jira_cloud_account_mapping_rule",
        "cdktn_provider_pagerduty.maintenance_window",
        "cdktn_provider_pagerduty.provider",
        "cdktn_provider_pagerduty.response_play",
        "cdktn_provider_pagerduty.ruleset",
        "cdktn_provider_pagerduty.ruleset_rule",
        "cdktn_provider_pagerduty.schedule",
        "cdktn_provider_pagerduty.service",
        "cdktn_provider_pagerduty.service_custom_field",
        "cdktn_provider_pagerduty.service_custom_field_value",
        "cdktn_provider_pagerduty.service_dependency",
        "cdktn_provider_pagerduty.service_event_rule",
        "cdktn_provider_pagerduty.service_integration",
        "cdktn_provider_pagerduty.slack_connection",
        "cdktn_provider_pagerduty.tag",
        "cdktn_provider_pagerduty.tag_assignment",
        "cdktn_provider_pagerduty.team",
        "cdktn_provider_pagerduty.team_membership",
        "cdktn_provider_pagerduty.user",
        "cdktn_provider_pagerduty.user_contact_method",
        "cdktn_provider_pagerduty.user_handoff_notification_rule",
        "cdktn_provider_pagerduty.user_notification_rule",
        "cdktn_provider_pagerduty.webhook_subscription"
    ],
    "package_data": {
        "cdktn_provider_pagerduty._jsii": [
            "provider-pagerduty@15.0.1.jsii.tgz"
        ],
        "cdktn_provider_pagerduty": [
            "py.typed"
        ]
    },
    "python_requires": "~=3.9",
    "install_requires": [
        "cdktn>=0.22.0, <0.23.0",
        "constructs>=10.4.2, <11.0.0",
        "jsii>=1.126.0, <2.0.0",
        "publication>=0.0.3",
        "typeguard==2.13.3"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Typing :: Typed",
        "Development Status :: 5 - Production/Stable",
        "License :: OSI Approved"
    ],
    "scripts": []
}
"""
)

with open("README.md", encoding="utf8") as fp:
    kwargs["long_description"] = fp.read()


setuptools.setup(**kwargs)
