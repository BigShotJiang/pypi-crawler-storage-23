<h1 align="center">EDMT — Environmental Data Management Toolbox</h1>

<p align="center">
  <!-- PyPI -->
  <a href="https://pypi.org/project/edmt/">
    <img src="https://img.shields.io/pypi/v/edmt.svg" alt="PyPI version" />
  </a>

  <!-- Codecov -->
  <a href="https://codecov.io/gh/envdmt/EDMT">
  <img src="https://codecov.io/gh/envdmt/EDMT/branch/main/graph/badge.svg" alt="codecov" />
</a>


  <!-- Docs -->
  <a href="https://envdmt.github.io/EDMT/">
    <img src="https://img.shields.io/badge/docs-passing-brightgreen.svg" alt="docs" />
  </a>

  <!-- Jupyter -->
  <img src="https://img.shields.io/badge/Jupyter-Lab-orange.svg" alt="Jupyter Lab" />

  <!-- License -->
  <img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="license" />
</p>


## Overview

**EDMT (Environmental Data Management Toolbox)** is a lightweight Python library designed to make environmental data ingestion, cleaning, transformation, and basic analysis workflows easier and more reproducible. It provides a set of tools and helper functions tailored to the common needs of environmental scientists, data engineers, and analysts working with diverse observational and sensor-derived datasets.

It provides modular tools for:

- Data ingestion (CSV, sensors, exports, logs)
- Cleaning & quality control
- Time-series handling
- Spatial & temporal transformations
- Basic analytics & summaries
- Reusable, reproducible workflows

Why EDMT?

Environmental data workflows often require stitching together formats, checks, and cleaning steps that are repetitive and error-prone. EDMT centralizes these common operations into reusable Python functions and classes, helping you:

- Save development time and reduce duplication
- Standardize procedures across different projects
- Improve reproducibility and traceability of results

---

## Installation

```bash
pip install edmt
