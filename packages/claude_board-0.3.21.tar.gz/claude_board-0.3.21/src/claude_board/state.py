"""
State Manager for Claude Board

Manages the console state and coordinates between:
- Hook scripts (via HTTP)
- Web clients (via WebSocket)
- Future: Bluetooth clients (via BLE GATT)

Uses asyncio.Future for blocking permission requests until
a decision is received from any connected client.

Supports multi-project state management where each project
maintains its own pending requests, todos, and statistics.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from pathlib import Path
from typing import TYPE_CHECKING

from .models import (
    ClaudeSession,
    CompletedTask,
    ConsoleState,
    DecisionStatus,
    PermissionRequest,
    ProjectState,
    TodoItem,
    TodoStatus,
    utc_now,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

# Tools that require user interaction in Claude Code's TUI.
# These must never be auto-approved by YOLO mode.
INTERACTIVE_TOOLS = {"AskUserQuestion", "ExitPlanMode", "EnterPlanMode"}


def is_claude_probe(project_path: str) -> bool:
    """Check if this is a ClaudeProbe project (should not be recorded)."""
    if not project_path:
        return False
    name = Path(project_path).resolve().name
    return "ClaudeProbe" in name or "ClaudeProbe" in project_path


class StateManager:
    """
    Manages the console state and coordinates between
    hook scripts and clients (web/bluetooth).

    Thread-safe using asyncio.Lock.
    """

    def __init__(self, *, yolo_default: bool = False) -> None:
        self.state = ConsoleState(yolo_mode=yolo_default)
        self._pending_futures: dict[str, asyncio.Future[DecisionStatus]] = {}
        self._broadcast_callback: (
            Callable[[dict[str, object]], Awaitable[None]] | None
        ) = None
        self._ble_callback: Callable[[bytes], Awaitable[None]] | None = None
        self._lock = asyncio.Lock()

    def set_broadcast_callback(
        self, callback: Callable[[dict[str, object]], Awaitable[None]]
    ) -> None:
        """Set the callback for broadcasting state changes to WebSocket clients"""
        self._broadcast_callback = callback

    def set_ble_callback(self, callback: Callable[[bytes], Awaitable[None]]) -> None:
        """Set the callback for sending state to Bluetooth client (future)"""
        self._ble_callback = callback

    async def _broadcast_state(self) -> None:
        """Broadcast current state to all connected clients"""
        # Web clients (WebSocket)
        if self._broadcast_callback:
            await self._broadcast_callback(self.state.to_dict())

        # Bluetooth client (future)
        if self._ble_callback and self.state.ble_connected:
            await self._ble_callback(self.state.to_ble_bytes())

    async def add_permission_request(
        self, request: PermissionRequest
    ) -> asyncio.Future[DecisionStatus]:
        """
        Add a new permission request and return a Future that will
        resolve when a decision is made.

        If YOLO mode is enabled (global or per-session), automatically approves.
        Multiple pending requests are now supported (from different sessions).

        The request is stored both in global state (for backward compatibility)
        and in the project-specific state (for multi-project support).
        """
        async with self._lock:
            # Get or create project state
            project_path = request.project_path or str(Path.cwd())
            project_state = self.state.get_project_state(project_path)

            # Add to project state's pending requests list
            project_state.pending_requests.append(request)
            project_state.stats.total_requests += 1

            # Also add to global state's pending requests list
            self.state.pending_requests.append(request)
            self.state.stats.total_requests += 1

            # Update session stats if session exists
            session = self.state.claude_sessions.get(request.session_id)
            if session:
                session.stats.total_requests += 1

            # Check YOLO mode - first global (master override), then per-session
            yolo_enabled = self.state.yolo_mode
            if not yolo_enabled and session:
                yolo_enabled = session.yolo_mode

            if yolo_enabled:
                loop = asyncio.get_event_loop()
                future: asyncio.Future[DecisionStatus] = loop.create_future()
                future.set_result(DecisionStatus.APPROVED)
                await self._complete_request(request.id, DecisionStatus.APPROVED)
                return future

            # Create a future for the decision
            loop = asyncio.get_event_loop()
            future = loop.create_future()
            self._pending_futures[request.id] = future

            await self._broadcast_state()
            return future

    async def make_decision(self, request_id: str, decision: DecisionStatus) -> bool:
        """
        Make a decision on a pending request.

        Can be called from:
        - Web UI (via HTTP API)
        - Bluetooth client (future, via BLE GATT)

        Returns True if the decision was applied.
        """
        async with self._lock:
            # Find the request in the pending list
            request = None
            for r in self.state.pending_requests:
                if r.id == request_id:
                    request = r
                    break

            if not request:
                return False

            # Resolve the future
            if request_id in self._pending_futures:
                future = self._pending_futures.pop(request_id)
                if not future.done():
                    future.set_result(decision)

            await self._complete_request(request_id, decision)
            return True

    async def _complete_request(
        self, request_id: str, decision: DecisionStatus
    ) -> None:
        """Move request from pending to completed.

        Updates at all levels: global, project, session.
        """
        # Find and remove the request from global pending list
        request = None
        for r in self.state.pending_requests:
            if r.id == request_id:
                request = r
                self.state.pending_requests.remove(r)
                break

        if not request:
            return

        # Find and remove from project state
        project_state = None
        for ps in self.state.projects.values():
            for r in ps.pending_requests:
                if r.id == request_id:
                    ps.pending_requests.remove(r)
                    project_state = ps
                    break
            if project_state:
                break

        approved = decision == DecisionStatus.APPROVED

        completed = CompletedTask(
            id=request.id,
            tool_name=request.tool_name,
            display_text=request.get_display_text(),
            timestamp=utc_now(),
            approved=approved,
            project_path=request.project_path,
            session_id=request.session_id,  # Store session_id for per-session tracking
        )

        # Update global state
        self.state.completed_tasks.append(completed)

        if approved:
            self.state.stats.approved_count += 1
        else:
            self.state.stats.denied_count += 1

        # Update project state
        if project_state:
            project_state.completed_tasks.append(completed)
            if approved:
                project_state.stats.approved_count += 1
            else:
                project_state.stats.denied_count += 1

        # Update session state (primary storage for per-session data)
        session = self.state.claude_sessions.get(request.session_id)
        if session:
            session.completed_tasks.append(completed)
            if approved:
                session.stats.approved_count += 1
            else:
                session.stats.denied_count += 1

        await self._broadcast_state()

    async def set_yolo_mode(self, *, enabled: bool) -> None:
        """Toggle global YOLO (auto-approve) mode.

        When enabled, all sessions are auto-approved (master override).
        """
        async with self._lock:
            self.state.yolo_mode = enabled

            # If enabling global YOLO, auto-approve all pending requests
            if enabled:
                for request in list(self.state.pending_requests):
                    if request.id in self._pending_futures:
                        future = self._pending_futures.pop(request.id)
                        if not future.done():
                            future.set_result(DecisionStatus.APPROVED)
                    await self._complete_request(request.id, DecisionStatus.APPROVED)

            await self._broadcast_state()

    async def set_session_yolo_mode(self, session_id: str, *, enabled: bool) -> bool:
        """Toggle YOLO mode for a specific session.

        Returns True if session was found and updated.
        """
        async with self._lock:
            session = self.state.claude_sessions.get(session_id)
            if not session:
                return False

            session.yolo_mode = enabled

            # If enabling YOLO, auto-approve pending requests for this session
            if enabled:
                requests_to_approve = [
                    r for r in self.state.pending_requests if r.session_id == session_id
                ]
                for request in requests_to_approve:
                    if request.id in self._pending_futures:
                        future = self._pending_futures.pop(request.id)
                        if not future.done():
                            future.set_result(DecisionStatus.APPROVED)
                    await self._complete_request(request.id, DecisionStatus.APPROVED)

            await self._broadcast_state()
            return True

    async def set_current_task(self, task: str | None) -> None:
        """Update the current task description"""
        async with self._lock:
            self.state.current_task = task
            await self._broadcast_state()

    async def update_web_client_count(self, count: int) -> None:
        """Update the connected web client count"""
        self.state.web_clients = count
        self.state.connected_clients = count + (1 if self.state.ble_connected else 0)
        await self._broadcast_state()

    async def set_ble_connected(self, *, connected: bool) -> None:
        """Update Bluetooth connection status (future)"""
        async with self._lock:
            self.state.ble_connected = connected
            self.state.connected_clients = self.state.web_clients + (
                1 if connected else 0
            )
            await self._broadcast_state()

    async def reset_session(self) -> None:
        """Reset the session state"""
        async with self._lock:
            yolo = self.state.yolo_mode  # Preserve YOLO setting
            self.state = ConsoleState(yolo_mode=yolo)
            self._pending_futures.clear()
            await self._broadcast_state()

    async def update_todos(
        self,
        todos: list[dict[str, object]],
        project_path: str | None = None,
        session_id: str | None = None,
    ) -> None:
        """Update the TODO list from Claude Code for a specific session.

        TODOs are now stored per-session (primary) with aggregation to
        project and global levels for backward compatibility.
        """
        async with self._lock:
            todo_items = [
                TodoItem(
                    content=str(t.get("content", "")),
                    status=TodoStatus(str(t.get("status", "pending"))),
                    active_form=str(t.get("activeForm", "")),
                    project_path=project_path or "",
                    session_id=session_id or "",
                )
                for t in todos
            ]

            # Store at session level (primary storage)
            if session_id and session_id in self.state.claude_sessions:
                session = self.state.claude_sessions[session_id]
                session.todos = todo_items

            self._sync_todo_aggregates(project_path or "")
            await self._broadcast_state()

    async def add_todo(
        self,
        subject: str,
        description: str = "",  # noqa: ARG002
        active_form: str = "",
        project_path: str = "",
        session_id: str = "",
    ) -> None:
        """Add a single todo item (from TaskCreate hook)."""
        async with self._lock:
            todo = TodoItem(
                content=subject,
                status=TodoStatus.PENDING,
                active_form=active_form,
                project_path=project_path,
                session_id=session_id,
            )

            # Store at session level (primary)
            if session_id and session_id in self.state.claude_sessions:
                self.state.claude_sessions[session_id].todos.append(todo)

            self._sync_todo_aggregates(project_path)
            await self._broadcast_state()

    async def update_todo(
        self,
        task_id: str,
        status: str | None = None,
        subject: str | None = None,
        active_form: str | None = None,
        project_path: str = "",
        session_id: str = "",
    ) -> None:
        """Update a single todo item (from TaskUpdate hook).

        task_id is the 1-based index string from Claude Code's TaskUpdate.
        """
        async with self._lock:
            # Find the todo in the session's list by index (task_id is 1-based)
            session = self.state.claude_sessions.get(session_id) if session_id else None
            if not session:
                return

            try:
                idx = int(task_id) - 1  # Convert 1-based to 0-based
            except (ValueError, TypeError):
                return

            if idx < 0 or idx >= len(session.todos):
                return

            todo = session.todos[idx]

            # Handle deletion
            if status == "deleted":
                session.todos.pop(idx)
            else:
                if status:
                    with contextlib.suppress(ValueError):
                        todo.status = TodoStatus(status)
                if subject:
                    todo.content = subject
                if active_form:
                    todo.active_form = active_form

            self._sync_todo_aggregates(project_path)
            await self._broadcast_state()

    def _sync_todo_aggregates(self, project_path: str = "") -> None:
        """Re-aggregate todos from sessions to project and global levels."""
        # Update project-specific state
        if project_path:
            project_state = self.state.get_project_state(project_path)
            project_todos: list[TodoItem] = []
            for s in self.state.claude_sessions.values():
                if s.project_path == str(Path(project_path).resolve()):
                    project_todos.extend(s.todos)
            project_state.todos = project_todos

        # Update global state
        all_todos: list[TodoItem] = []
        for s in self.state.claude_sessions.values():
            all_todos.extend(s.todos)
        self.state.todos = all_todos

    async def set_active_project(self, project_path: str | None) -> None:
        """Set the currently active project in the UI"""
        async with self._lock:
            if project_path:
                # Normalize path
                self.state.active_project = str(Path(project_path).resolve())
            else:
                self.state.active_project = None
            await self._broadcast_state()

    def get_project_state(self, project_path: str) -> ProjectState:
        """Get state for a specific project"""
        return self.state.get_project_state(project_path)

    def get_all_projects(self) -> list[ProjectState]:
        """Get all project states"""
        return list(self.state.projects.values())

    async def register_claude_session(
        self,
        session_id: str,
        project_path: str,
        chat_session_id: str | None = None,
        *,
        is_external: bool = True,
    ) -> ClaudeSession:
        """
        Register a new Claude Code session.

        Called when:
        - session_start_hook notifies us of a new external session
        - claude-board chat creates a new session (with chat_session_id linked)
        """
        async with self._lock:
            # ClaudeProbe projects are not recorded (server-side safety net)
            if is_claude_probe(project_path):
                # Return a transient session object without storing it
                return ClaudeSession(
                    session_id=session_id,
                    project_path=str(Path(project_path).resolve()),
                    is_external=is_external,
                )

            # Check if session already exists
            if session_id in self.state.claude_sessions:
                session = self.state.claude_sessions[session_id]
                # Update chat_session_id if provided
                if chat_session_id:
                    session.chat_session_id = chat_session_id
                    session.is_external = False
                return session

            # Create new session
            session = ClaudeSession(
                session_id=session_id,
                project_path=str(Path(project_path).resolve()),
                chat_session_id=chat_session_id,
                is_external=is_external,
            )
            self.state.claude_sessions[session_id] = session

            # Set as active session
            self.state.active_session_id = session_id

            # Also ensure project state exists
            self.state.get_project_state(project_path)

            await self._broadcast_state()
            return session

    async def set_active_session(self, session_id: str | None) -> None:
        """Set the currently active Claude session in the UI"""
        async with self._lock:
            self.state.active_session_id = session_id
            await self._broadcast_state()

    def get_claude_session(self, session_id: str) -> ClaudeSession | None:
        """Get a Claude session by ID"""
        return self.state.claude_sessions.get(session_id)

    async def handle_session_stop(
        self,
        session_id: str | None = None,
        project_path: str | None = None,
    ) -> None:
        """
        Handle session stop event from Claude Code.

        This is called when Claude finishes responding (Stop hook).
        We mark the session as ended, clear pending requests for this session,
        and notify clients so the UI can show that the session ended.
        """
        logger = logging.getLogger(__name__)

        async with self._lock:
            logger.info(
                "handle_session_stop called:"
                " session_id=%s, project_path=%s",
                session_id,
                project_path,
            )
            logger.info(
                "Current claude_sessions: %s",
                list(self.state.claude_sessions.keys()),
            )

            # Mark the Claude session as ended
            if session_id and session_id in self.state.claude_sessions:
                session = self.state.claude_sessions[session_id]
                session.ended = True
                session.end_time = utc_now()
                logger.info("Marked session %s as ended", session_id)
            elif session_id and project_path:
                # Session not found (e.g., server restarted)
                # Create ended record so UI shows it ended
                logger.info("Creating ended session record for %s", session_id)
                session = ClaudeSession(
                    session_id=session_id,
                    project_path=str(Path(project_path).resolve()),
                    is_external=True,
                    ended=True,
                    end_time=utc_now(),
                )
                self.state.claude_sessions[session_id] = session
                # Don't set as active since it's already ended
            else:
                logger.warning(
                    "Session %s not found and no project_path provided",
                    session_id,
                )

            # Find and timeout pending requests from this session
            requests_to_timeout: list[str] = []

            for request in self.state.pending_requests:
                # Match by session_id if provided, otherwise match by project_path
                if (session_id and request.session_id == session_id) or (
                    project_path
                    and request.project_path == project_path
                    and not session_id
                ):
                    requests_to_timeout.append(request.id)

            # Timeout matched requests
            for request_id in requests_to_timeout:
                if request_id in self._pending_futures:
                    future = self._pending_futures.pop(request_id)
                    if not future.done():
                        future.set_result(DecisionStatus.TIMEOUT)
                await self._complete_request(request_id, DecisionStatus.TIMEOUT)

            # Clear current task since Claude stopped
            self.state.current_task = None

            # Broadcast updated state to notify clients
            await self._broadcast_state()

    async def remove_claude_session(self, session_id: str) -> bool:
        """
        Remove a Claude session from tracking.

        This is typically called when user closes an ended session tab.
        Only allows removing sessions that have ended.

        Returns True if session was removed.
        """
        async with self._lock:
            if session_id not in self.state.claude_sessions:
                return False

            session = self.state.claude_sessions[session_id]

            # Only allow removing ended sessions
            if not session.ended:
                return False

            # Remove the session
            del self.state.claude_sessions[session_id]

            # If this was the active session, select another one
            if self.state.active_session_id == session_id:
                # Find another non-ended session, or the most recent ended one
                active_sessions = [
                    s for s in self.state.claude_sessions.values() if not s.ended
                ]
                if active_sessions:
                    self.state.active_session_id = active_sessions[0].session_id
                elif self.state.claude_sessions:
                    # Pick the first remaining session
                    self.state.active_session_id = next(
                        iter(self.state.claude_sessions.keys())
                    )
                else:
                    self.state.active_session_id = None

            await self._broadcast_state()
            return True
