from __future__ import annotations

import shutil
import sys
from typing import Annotated

import typer
from rich.console import Console

from .. import __app_name__, __version__

app = typer.Typer(
    name=__app_name__,
    help=(
        "Physical console for Claude Code - approve/deny"
        " permissions from your phone or (future)"
        " hardware device."
    ),
    add_completion=False,
)
console = Console()


def version_callback(value: bool) -> None:  # noqa: FBT001
    if value:
        exe = shutil.which(__app_name__) or sys.argv[0]
        console.print(f"[bold]{__app_name__}[/bold] version {__version__}")
        console.print(f"[dim]{exe}[/dim]")
        raise typer.Exit


@app.callback()
def main(
    *,
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            "-v",
            help="Show version and exit.",
            callback=version_callback,
            is_eager=True,
        ),
    ] = False,
) -> None:
    """
    Claude Board - Permission approval console for Claude Code.

    Use your phone or a physical device to approve/deny Claude Code's
    permission requests.
    """

