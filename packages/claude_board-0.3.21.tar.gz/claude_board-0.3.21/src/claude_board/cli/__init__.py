"""
Claude Board CLI package entrypoint.

All command modules are imported here so their `@app.command` decorators run
before the CLI is executed.
"""

from __future__ import annotations

from . import commands_chat, commands_config, commands_rpc, commands_server
from .app import app

_REGISTERED_COMMAND_MODULES = (
    commands_server,
    commands_config,
    commands_rpc,
    commands_chat,
)


def cli() -> None:
    """Console script entry point."""
    app()
