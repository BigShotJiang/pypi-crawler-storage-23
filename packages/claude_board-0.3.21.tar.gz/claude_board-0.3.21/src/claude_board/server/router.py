from __future__ import annotations

from fastapi import APIRouter

from .routes_core import router as core_router
from .routes_hooks import router as hooks_router
from .routes_sessions import router as sessions_router
from .routes_ws import router as ws_router

router = APIRouter()
router.include_router(core_router)
router.include_router(hooks_router)
router.include_router(sessions_router)
router.include_router(ws_router)

