from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# Web UI static files directory
WEB_DIR = Path(__file__).resolve().parents[1] / "web"

