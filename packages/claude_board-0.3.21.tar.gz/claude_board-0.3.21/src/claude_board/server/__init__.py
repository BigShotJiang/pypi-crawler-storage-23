"""
Claude Board Web Server package facade.

This package re-exports server components from submodules to preserve
backward compatibility for `claude_board.server` imports.
"""

import asyncio
from pathlib import Path

from fastapi import FastAPI

from ..config import AppConfig
from . import app_factory as _app_factory
from .router import router
from .routes_core import (
    approve_request,
    deny_request,
    get_project_state,
    get_state,
    health_check,
    list_projects,
    manifest,
    reset_session,
    root,
    service_worker,
    set_active_project,
    toggle_yolo,
)
from .routes_hooks import (
    handle_hook,
    handle_task_operation,
    remove_session,
    session_notify,
    set_active_session,
    toggle_session_yolo,
    update_todos,
)
from .routes_sessions import (
    create_session,
    get_session,
    list_sessions,
    send_session_input,
    send_session_prompt,
    stop_session,
)
from .routes_ws import session_terminal_websocket, websocket_endpoint
from .rpc import RPCServer

WEB_DIR = _app_factory.WEB_DIR


def create_app(config: AppConfig | None = None) -> FastAPI:
    """
    Compatibility wrapper.

    Keeps monkeypatch compatibility for `claude_board.server.WEB_DIR`.
    """
    _app_factory.WEB_DIR = WEB_DIR
    return _app_factory.create_app(config)


def run_server(
    host: str = "0.0.0.0",
    port: int = 8765,
    config: AppConfig | None = None,
    socket_path: Path | None = None,
) -> None:
    """
    Compatibility wrapper.

    Keeps monkeypatch compatibility for `claude_board.server.RPCServer`.
    """
    _app_factory.RPCServer = RPCServer
    _app_factory.WEB_DIR = WEB_DIR
    _app_factory.run_server(
        host=host,
        port=port,
        config=config,
        socket_path=socket_path,
    )


__all__ = [
    "WEB_DIR",
    "AppConfig",
    "RPCServer",
    "approve_request",
    "asyncio",
    "create_app",
    "create_session",
    "deny_request",
    "get_project_state",
    "get_session",
    "get_state",
    "handle_hook",
    "handle_task_operation",
    "health_check",
    "list_projects",
    "list_sessions",
    "manifest",
    "remove_session",
    "reset_session",
    "root",
    "router",
    "run_server",
    "send_session_input",
    "send_session_prompt",
    "service_worker",
    "session_notify",
    "session_terminal_websocket",
    "set_active_project",
    "set_active_session",
    "stop_session",
    "toggle_session_yolo",
    "toggle_yolo",
    "update_todos",
    "websocket_endpoint",
]
