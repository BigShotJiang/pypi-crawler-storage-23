"""
Cygn Enterprise SDK — Python type definitions.
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class DeepfakeSignal:
    name: str
    weight: float
    description: str


@dataclass
class EnterpriseInfo:
    company_name: str
    label: str
    signed_at: Optional[str] = None


# ── Deepfake Detection ──────────────────────────────────────────────────────


@dataclass
class DetectDeepfakeResult:
    success: bool
    media_type: str
    score: float
    verdict: str  # likely_authentic | suspicious | likely_ai_generated
    signals: list[DeepfakeSignal] = field(default_factory=list)
    remaining: Optional[int] = None


@dataclass
class DetectVideoDeepfakeResult:
    success: bool
    score: float
    verdict: str
    frame_analysis: dict = field(default_factory=dict)
    audio_analysis: dict = field(default_factory=dict)


# ── C2PA Signing ────────────────────────────────────────────────────────────


@dataclass
class SignImageResult:
    success: bool
    signed_image: str  # base64
    mime_type: str
    provenance: str
    signed_at: str
    enterprise: Optional[EnterpriseInfo] = None


@dataclass
class SignDocumentResult:
    success: bool
    signed_document: str  # base64
    mime_type: str
    signed_at: str
    enterprise: Optional[EnterpriseInfo] = None


# ── Provenance Bundle ───────────────────────────────────────────────────────


@dataclass
class DeepfakeAnalysis:
    score: float
    verdict: str
    signals: list[DeepfakeSignal] = field(default_factory=list)


@dataclass
class ProvenanceBundleResult:
    success: bool
    signed_image: str  # base64
    mime_type: str
    deepfake: DeepfakeAnalysis = field(default_factory=lambda: DeepfakeAnalysis(0, "skipped"))
    signed_at: str = ""
    enterprise: Optional[EnterpriseInfo] = None


# ── Sonic Watermarking ──────────────────────────────────────────────────────


@dataclass
class SonicEmbedResult:
    success: bool
    watermark_id: str
    audio_hash: str
    payload_hash: str
    embedded_at: str
    audio: str  # base64


@dataclass
class SonicDetectResult:
    success: bool
    detected: bool
    watermark_id: Optional[str] = None
    did: Optional[str] = None
    confidence: Optional[float] = None


@dataclass
class SonicRegisterResult:
    success: bool
    registration_id: str
    registered_at: str


@dataclass
class SonicLookupResult:
    success: bool
    found: bool
    did: Optional[str] = None
    display_name: Optional[str] = None
    registered_at: Optional[str] = None


# ── Voice ID ────────────────────────────────────────────────────────────────


@dataclass
class VoiceEnrollResult:
    success: bool
    enrollment_id: str
    did: str
    enrolled_at: str


@dataclass
class VoiceVerifyResult:
    success: bool
    match: bool
    confidence: float
    did: str


# ── Usage ───────────────────────────────────────────────────────────────────


@dataclass
class UsageSummary:
    balance: int  # paise
    total_spent: int  # paise
    current_month: dict = field(default_factory=dict)
