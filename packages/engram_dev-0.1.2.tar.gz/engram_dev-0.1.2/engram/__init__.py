"""
Engram - Local, persistent memory for AI development workflows.

Your AI finally remembers your codebase.
"""

__version__ = "0.1.0"
__author__ = "Project Engram"
