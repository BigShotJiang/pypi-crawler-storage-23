"""eip-search: CLI intelligence tool for the Exploit Intelligence Platform."""

__version__ = "0.3.19"
