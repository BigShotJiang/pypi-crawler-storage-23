"""Entry point: python -m retracesoftware.dap

Two transport modes:
  - **stdio** (default): DAP over stdin/stdout. Target output is captured
    via fd-level pipe redirection and forwarded as DAP output events.
  - **socket**: Set RETRACE_DAP_SOCKET to a path.  The adapter creates a
    Unix domain socket, listens, and accepts one connection.
"""

from __future__ import annotations

import logging
import os
import socket
import sys

from .adapter import Adapter


def _run_socket(socket_path: str) -> None:
    log = logging.getLogger("retracesoftware.dap")

    if os.path.exists(socket_path):
        os.unlink(socket_path)

    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    server.bind(socket_path)
    server.listen(1)
    log.info("Listening on %s", socket_path)

    conn, _ = server.accept()
    log.info("Client connected")
    server.close()

    rfile = conn.makefile("rb")
    wfile = conn.makefile("wb")

    try:
        adapter = Adapter(rfile, wfile)
        adapter.run()
    finally:
        rfile.close()
        wfile.close()
        conn.close()
        try:
            os.unlink(socket_path)
        except OSError:
            pass
        log.info("Disconnected")


def _run_stdio() -> None:
    from .protocol.stdio import setup_stdio

    # setup_stdio must be called before any target code runs — it does the
    # dup/dup2/pipe dance and redirects logging to the saved stderr fd.
    dap_rfile, dap_wfile, capture = setup_stdio()

    log = logging.getLogger("retracesoftware.dap")
    log.info("stdio transport active")

    adapter = Adapter(dap_rfile, dap_wfile)
    adapter.output_capture = capture
    capture.start(adapter)

    try:
        adapter.run()
    finally:
        capture.stop()
        dap_rfile.close()
        dap_wfile.close()
        log.info("Disconnected")


def main() -> None:
    logging.basicConfig(
        level=logging.DEBUG if os.environ.get("RETRACE_DEBUG") else logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        stream=sys.stderr,
    )

    socket_path = os.environ.get("RETRACE_DAP_SOCKET")

    if socket_path:
        _run_socket(socket_path)
    else:
        _run_stdio()


main()
