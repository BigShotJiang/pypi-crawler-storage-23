"""Retrace DAP debug adapter.

Extends :class:`Dispatcher` with handlers for every DAP command that
retracesoftware supports.  This is the main class — instantiate it with
a connected socket and call :meth:`run`.
"""

from __future__ import annotations

import logging
from typing import Any

from .protocol.dispatch import Dispatcher
from .protocol import types
from .debug.cursor import Cursor
from .debug.breakpoints import BreakpointManager
from .debug.stepping import StepManager
from .debug.inspection import Inspector
from .debug.runner import TargetRunner, THREAD_ID

log = logging.getLogger(__name__)


class Adapter(Dispatcher):

    def __init__(self, rfile, wfile) -> None:
        super().__init__(rfile, wfile)
        self.cursor = Cursor()
        self.breakpoints = BreakpointManager()
        self.step_manager = StepManager(self.cursor)
        self.inspector = Inspector()
        self.runner: TargetRunner | None = None
        self.output_capture = None  # set by _run_stdio when using stdio transport
        self._configured = False
        self._launched = False

    # -- lifecycle ----------------------------------------------------------

    def handle_initialize(self, request: dict) -> dict:
        self.send_event("initialized")
        return types.CAPABILITIES

    def handle_launch(self, request: dict) -> dict:
        args = request.get("arguments", {})
        self._recording = args.get("recording", "")
        self._pid = args.get("pid", 0)
        program = args.get("program", "")
        stop_on_entry = args.get("stopOnEntry", True)
        self._launched = True

        if program:
            self.runner = TargetRunner(self)
            self.runner.launch(program, stop_on_entry=stop_on_entry)
        else:
            self.send(types.stopped_event("entry", thread_id=0))
        return {}

    def handle_configurationDone(self, request: dict) -> dict:
        self._configured = True
        return {}

    def handle_disconnect(self, request: dict) -> dict:
        if self.runner and self.runner.is_paused:
            self.runner.set_step_mode(None)
            self.runner.resume()
        self.stop()
        return {}

    def handle_terminate(self, request: dict) -> dict:
        self.send(types.terminated_event())
        self.stop()
        return {}

    def handle_restart(self, request: dict) -> dict:
        self.cursor.reset()
        self.send(types.stopped_event("entry", thread_id=0))
        return {}

    # -- threads ------------------------------------------------------------

    def handle_threads(self, request: dict) -> dict:
        if self.runner:
            return {"threads": [{"id": THREAD_ID, "name": "MainThread"}]}
        return {"threads": [{"id": 0, "name": "MainThread"}]}

    # -- breakpoints --------------------------------------------------------

    def handle_setBreakpoints(self, request: dict) -> dict:
        args = request.get("arguments", {})
        source = args.get("source", {})
        path = source.get("path", "")
        bp_specs = args.get("breakpoints", [])
        result = self.breakpoints.set_breakpoints(path, bp_specs)
        return {"breakpoints": result}

    def handle_setFunctionBreakpoints(self, request: dict) -> dict:
        args = request.get("arguments", {})
        bp_specs = args.get("breakpoints", [])
        result = self.breakpoints.set_function_breakpoints(bp_specs)
        return {"breakpoints": result}

    def handle_setExceptionBreakpoints(self, request: dict) -> dict:
        args = request.get("arguments", {})
        filters = args.get("filters", [])
        self.breakpoints.set_exception_filters(filters)
        return {}

    # -- stepping -----------------------------------------------------------

    def handle_continue(self, request: dict) -> dict:
        if self.runner and self.runner.is_paused:
            self.runner.set_step_mode(None)
            self.runner.resume()
        else:
            self.step_manager.do_continue(self, 0)
        return {"allThreadsContinued": True}

    def handle_next(self, request: dict) -> dict:
        if self.runner and self.runner.is_paused:
            depth = self._paused_depth()
            self.runner.set_step_mode("next", depth)
            self.runner.resume()
        else:
            args = request.get("arguments", {})
            self.step_manager.do_next(self, args.get("threadId", 0))
        return {}

    def handle_stepIn(self, request: dict) -> dict:
        if self.runner and self.runner.is_paused:
            self.runner.set_step_mode("step_in")
            self.runner.resume()
        else:
            args = request.get("arguments", {})
            self.step_manager.do_step_in(self, args.get("threadId", 0))
        return {}

    def handle_stepOut(self, request: dict) -> dict:
        if self.runner and self.runner.is_paused:
            depth = self._paused_depth()
            self.runner.set_step_mode("step_out", depth)
            self.runner.resume()
        else:
            args = request.get("arguments", {})
            self.step_manager.do_step_out(self, args.get("threadId", 0))
        return {}

    def handle_pause(self, request: dict) -> dict:
        if self.runner and not self.runner.is_paused:
            self.runner.request_pause()
        else:
            self.step_manager.do_pause(self)
        return {}

    # -- inspection ---------------------------------------------------------

    def handle_stackTrace(self, request: dict) -> dict:
        args = request.get("arguments", {})
        thread_id = args.get("threadId", 0)
        start_frame = args.get("startFrame", 0)
        levels = args.get("levels", 0)

        if self.runner and self.runner.is_paused and self.runner.paused_frame:
            return self.inspector.stack_trace_from_frame(
                self.runner.paused_frame, thread_id, start_frame, levels,
            )
        return self.inspector.stack_trace(thread_id, start_frame, levels)

    def handle_scopes(self, request: dict) -> dict:
        args = request.get("arguments", {})
        frame_id = args.get("frameId", 0)
        return self.inspector.scopes(frame_id)

    def handle_variables(self, request: dict) -> dict:
        args = request.get("arguments", {})
        ref = args.get("variablesReference", 0)
        start = args.get("start", 0)
        count = args.get("count", 0)
        return self.inspector.variables(ref, start, count)

    def handle_evaluate(self, request: dict) -> dict:
        args = request.get("arguments", {})
        expression = args.get("expression", "")
        frame_id = args.get("frameId")
        return self.inspector.evaluate(expression, frame_id)

    def handle_exceptionInfo(self, request: dict) -> dict:
        args = request.get("arguments", {})
        thread_id = args.get("threadId", 0)
        return self.inspector.exception_info(thread_id)

    # -- goto ---------------------------------------------------------------

    def handle_gotoTargets(self, request: dict) -> dict:
        args = request.get("arguments", {})
        source = args.get("source", {})
        line = args.get("line", 0)
        return {
            "targets": [{
                "id": line,
                "label": f"Line {line}",
                "line": line,
            }]
        }

    def handle_goto(self, request: dict) -> dict:
        args = request.get("arguments", {})
        target_id = args.get("targetId", 0)
        thread_id = args.get("threadId", 0)
        self.send(types.stopped_event("goto", thread_id=thread_id))
        return {}

    # -- retrace custom extensions ------------------------------------------

    def handle_retrace_getCursor(self, request: dict) -> dict:
        """Custom: retrace/getCursor"""
        return {"cursor": self.cursor.to_dict()}

    def handle_retrace_runToCursor(self, request: dict) -> dict:
        """Custom: retrace/runToCursor"""
        args = request.get("arguments", {})
        counter = args.get("counter", 0)
        self.send(types.stopped_event("goto", thread_id=0))
        return {}

    def handle_retrace_fork(self, request: dict) -> dict:
        """Custom: retrace/fork"""
        args = request.get("arguments", {})
        fork_id = args.get("fork_id", "")
        return {}

    def handle_retrace_listPids(self, request: dict) -> dict:
        """Custom: retrace/listPids"""
        return {"pids": []}

    # -- override dispatch to handle slash commands -------------------------

    def _handle_request(self, request: dict) -> None:
        command = request.get("command", "")
        method_name = f"handle_{command.replace('/', '_')}"
        handler = getattr(self, method_name, None)

        if handler is None:
            self.send_error(request, f"Unsupported command: {command}")
            return

        try:
            result = handler(request)
            if isinstance(result, dict):
                self.send_response(request, result)
            elif result is None:
                self.send_response(request)
        except Exception as exc:
            log.exception("Handler error for %s", command)
            self.send_error(request, str(exc))

        # After sending the launch response, let the target thread run
        if command == "launch" and self.runner:
            self.runner.release()

    # -- helpers ------------------------------------------------------------

    def _paused_depth(self) -> int:
        """Return the call stack depth of the paused target frame."""
        if not self.runner or not self.runner.paused_frame:
            return 0
        return TargetRunner._frame_depth(self.runner.paused_frame)
