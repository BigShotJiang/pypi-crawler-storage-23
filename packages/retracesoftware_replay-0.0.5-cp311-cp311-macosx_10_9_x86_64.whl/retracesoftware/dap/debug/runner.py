"""Target program runner with sys.monitoring hooks.

Executes a Python script in a dedicated thread.  sys.monitoring LINE
callbacks check breakpoints and stepping conditions; when a stop is
required the target thread blocks until the DAP client resumes it.
"""

from __future__ import annotations

import os
import sys
import threading
import logging
from types import CodeType, FrameType
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..adapter import Adapter

log = logging.getLogger(__name__)

_has_monitoring = hasattr(sys, "monitoring")
_TOOL_ID = sys.monitoring.DEBUGGER_ID if _has_monitoring else 0

THREAD_ID = 1


class TargetRunner:
    """Runs a target Python script with debugging hooks."""

    def __init__(self, adapter: Adapter) -> None:
        self.adapter = adapter
        self._thread: threading.Thread | None = None
        self._resume = threading.Event()
        self._paused = False
        self._target_frame: FrameType | None = None
        self._stop_reason: str = ""
        self._program: str = ""
        self._finished = False
        self._exit_code = 0

        # Stepping state
        self._step_mode: str | None = None  # 'next', 'step_in', 'step_out'
        self._step_depth: int = 0

        # Stop-on-entry flag
        self._stop_on_entry = True

        # Set when we want to request a pause from another thread
        self._pause_requested = False

        # Gate so the target doesn't start executing until after the
        # launch response has been written to the socket.
        self._start_gate = threading.Event()

    @property
    def is_paused(self) -> bool:
        return self._paused

    @property
    def paused_frame(self) -> FrameType | None:
        return self._target_frame

    @property
    def is_finished(self) -> bool:
        return self._finished

    def launch(self, program: str, stop_on_entry: bool = True) -> None:
        """Start the target program in a new thread.

        The thread blocks until :meth:`release` is called (which the
        adapter does right after sending the launch response).
        """
        self._program = os.path.abspath(program)
        self._stop_on_entry = stop_on_entry
        self._finished = False
        self._thread = threading.Thread(
            target=self._run, name="retrace-target", daemon=True,
        )
        self._thread.start()

    def release(self) -> None:
        """Allow the target thread to begin execution."""
        self._start_gate.set()

    def resume(self) -> None:
        """Resume the target thread (continue, step, etc.)."""
        self._paused = False
        self._target_frame = None
        self.adapter.inspector.invalidate()
        self._resume.set()

    def request_pause(self) -> None:
        """Ask the target to pause at the next LINE event."""
        self._pause_requested = True

    def set_step_mode(self, mode: str | None, depth: int = 0) -> None:
        """Configure the next stopping condition before resuming.

        mode: 'next' (same depth), 'step_in' (any depth), 'step_out' (shallower), None (run)
        depth: current call stack depth at the time of the step request
        """
        self._step_mode = mode
        self._step_depth = depth

    # -- internal -----------------------------------------------------------

    def _run(self) -> None:
        """Execute the target script."""
        self._start_gate.wait()
        self._install_hooks()

        program = self._program
        code = compile(open(program).read(), program, "exec")

        target_globals: dict[str, Any] = {
            "__name__": "__main__",
            "__file__": program,
            "__builtins__": __builtins__,
        }

        sys.argv = [program]

        try:
            exec(code, target_globals)  # noqa: S102
        except SystemExit as e:
            self._exit_code = e.code if isinstance(e.code, int) else 1
        except Exception:
            log.exception("Target raised an exception")
            self._exit_code = 1
        finally:
            self._uninstall_hooks()
            self._finished = True

            # Flush any captured target output before sending terminal events
            # so the DAP client sees all output before "exited"/"terminated".
            sys.stdout.flush()
            sys.stderr.flush()
            if self.adapter.output_capture is not None:
                self.adapter.output_capture.flush()

            from ..protocol import types
            self.adapter.send(types.exited_event(self._exit_code))
            self.adapter.send(types.terminated_event())

    def _install_hooks(self) -> None:
        if not _has_monitoring:
            return

        try:
            sys.monitoring.use_tool_id(_TOOL_ID, "retrace")
        except ValueError:
            pass

        sys.monitoring.set_events(
            _TOOL_ID,
            sys.monitoring.events.LINE
            | sys.monitoring.events.PY_RETURN
            | sys.monitoring.events.RAISE,
        )
        sys.monitoring.register_callback(_TOOL_ID, sys.monitoring.events.LINE, self._on_line)
        sys.monitoring.register_callback(_TOOL_ID, sys.monitoring.events.PY_RETURN, self._on_return)
        sys.monitoring.register_callback(_TOOL_ID, sys.monitoring.events.RAISE, self._on_raise)

    def _uninstall_hooks(self) -> None:
        if not _has_monitoring:
            return
        try:
            sys.monitoring.set_events(_TOOL_ID, 0)
        except Exception:
            pass

    def _on_line(self, code: CodeType, line_number: int) -> object:
        frame = sys._getframe(1)
        filename = code.co_filename
        func_name = code.co_name

        self.adapter.cursor.advance(THREAD_ID, filename, line_number, func_name)

        if self._should_skip(filename):
            return sys.monitoring.DISABLE

        # Stop-on-entry: pause at the first line of the target file
        if self._stop_on_entry and os.path.abspath(filename) == self._program:
            self._stop_on_entry = False
            self._pause_target(frame, "entry")
            return None

        # Pause request from the adapter thread
        if self._pause_requested:
            self._pause_requested = False
            self._pause_target(frame, "pause")
            return None

        # Breakpoint check
        if self.adapter.breakpoints.has_breakpoint(filename, line_number):
            bp = self.adapter.breakpoints.get_breakpoint(filename, line_number)
            if bp and bp.get("condition"):
                try:
                    if not eval(bp["condition"], frame.f_globals, frame.f_locals):  # noqa: S307
                        return None
                except Exception:
                    pass
            self._pause_target(frame, "breakpoint")
            return None

        # Stepping check
        if self._step_mode == "step_in":
            self._step_mode = None
            self._pause_target(frame, "step")
            return None

        if self._step_mode == "next":
            depth = self._frame_depth(frame)
            if depth <= self._step_depth:
                self._step_mode = None
                self._pause_target(frame, "step")
            return None

        return None

    def _on_return(self, code: CodeType, instruction_offset: int, retval: object) -> object:
        if self._step_mode == "step_out":
            frame = sys._getframe(1)
            depth = self._frame_depth(frame)
            if depth <= self._step_depth - 1:
                self._step_mode = None
                self._pause_target(frame, "step")
        return None

    def _on_raise(self, code: CodeType, instruction_offset: int, exception: BaseException) -> object:
        if self.adapter.breakpoints.break_on_raised:
            frame = sys._getframe(1)
            self._pause_target(frame, "exception")
        return None

    def _pause_target(self, frame: FrameType, reason: str) -> None:
        """Block the target thread until resumed by the adapter."""
        self._target_frame = frame
        self._paused = True
        self._stop_reason = reason
        self._resume.clear()

        from ..protocol import types
        self.adapter.send(types.stopped_event(reason, thread_id=THREAD_ID))

        self._resume.wait()

    def _should_skip(self, filename: str) -> bool:
        """Skip files that are part of the adapter itself."""
        return "retracesoftware/dap" in filename

    @staticmethod
    def _frame_depth(frame: FrameType) -> int:
        depth = 0
        f: FrameType | None = frame
        while f is not None:
            depth += 1
            f = f.f_back
        return depth
