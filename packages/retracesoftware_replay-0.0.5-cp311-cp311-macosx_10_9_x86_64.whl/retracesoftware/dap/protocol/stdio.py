"""stdio transport: fd-level redirection for DAP over stdin/stdout.

Performs a dup/dup2/pipe dance so that:
- DAP protocol reads/writes use the original fd 0 and fd 1
- Adapter logging uses the original fd 2
- The target program's stdout (fd 1) and stderr (fd 2) are redirected to
  pipes, drained by background threads, and forwarded as DAP output events
"""

from __future__ import annotations

import io
import logging
import os
import sys
import threading
from typing import TYPE_CHECKING, BinaryIO

if TYPE_CHECKING:
    from ..adapter import Adapter

log = logging.getLogger(__name__)


class OutputCapture:
    """Drains captured stdout/stderr pipes and sends DAP output events."""

    def __init__(self, out_read_fd: int, err_read_fd: int) -> None:
        self._out_fd = out_read_fd
        self._err_fd = err_read_fd
        self._threads: list[threading.Thread] = []
        self._adapter: Adapter | None = None

    def start(self, adapter: Adapter) -> None:
        self._adapter = adapter
        for fd, category in [(self._out_fd, "stdout"), (self._err_fd, "stderr")]:
            t = threading.Thread(
                target=self._drain, args=(fd, category),
                name=f"retrace-capture-{category}", daemon=True,
            )
            self._threads.append(t)
            t.start()

    def flush(self) -> None:
        """Drain any pending data from the pipes synchronously.

        Call this before sending exited/terminated events so that all
        target output is delivered to the DAP client first.
        """
        import select
        for fd, category in [(self._out_fd, "stdout"), (self._err_fd, "stderr")]:
            while True:
                ready, _, _ = select.select([fd], [], [], 0.05)
                if not ready:
                    break
                data = os.read(fd, 4096)
                if not data:
                    break
                self._send_output(data, category)

    def stop(self) -> None:
        for fd in (self._out_fd, self._err_fd):
            try:
                os.close(fd)
            except OSError:
                pass
        for t in self._threads:
            t.join(timeout=1.0)

    def _drain(self, fd: int, category: str) -> None:
        try:
            while True:
                data = os.read(fd, 4096)
                if not data:
                    break
                self._send_output(data, category)
        except OSError:
            pass

    def _send_output(self, data: bytes, category: str) -> None:
        from .types import output_event
        text = data.decode("utf-8", errors="replace")
        if self._adapter is not None:
            self._adapter.send(output_event(text, category))


def setup_stdio() -> tuple[BinaryIO, BinaryIO, OutputCapture]:
    """Redirect fds so DAP owns original stdio and target output is captured.

    Returns (dap_rfile, dap_wfile, capture).
    """
    dap_in_fd = os.dup(0)
    dap_out_fd = os.dup(1)
    log_fd = os.dup(2)

    out_r, out_w = os.pipe()
    err_r, err_w = os.pipe()

    os.dup2(out_w, 1)
    os.close(out_w)
    os.dup2(err_w, 2)
    os.close(err_w)

    # Rebuild Python-level sys.stdout/stderr on the new fd 1/2
    sys.stdout = io.TextIOWrapper(
        io.FileIO(1, "w", closefd=False), line_buffering=True,
    )
    sys.stderr = io.TextIOWrapper(
        io.FileIO(2, "w", closefd=False), line_buffering=True,
    )

    # Point stdin at /dev/null so the target can't accidentally
    # read DAP protocol bytes from the original fd 0
    devnull = os.open(os.devnull, os.O_RDONLY)
    os.dup2(devnull, 0)
    os.close(devnull)
    sys.stdin = io.TextIOWrapper(
        io.FileIO(0, "r", closefd=False),
    )

    # Redirect logging to the saved stderr fd (visible in VS Code debug console)
    log_stream = io.TextIOWrapper(
        io.FileIO(log_fd, "w", closefd=False), line_buffering=True,
    )
    root = logging.getLogger()
    for handler in root.handlers[:]:
        root.removeHandler(handler)
    handler = logging.StreamHandler(log_stream)
    handler.setFormatter(logging.Formatter(
        "%(asctime)s %(name)s %(levelname)s %(message)s",
    ))
    root.addHandler(handler)

    dap_rfile: BinaryIO = io.FileIO(dap_in_fd, "r", closefd=True)  # type: ignore[assignment]
    dap_wfile: BinaryIO = io.open(dap_out_fd, "wb", closefd=True)  # type: ignore[assignment]

    return dap_rfile, dap_wfile, OutputCapture(out_r, err_r)
