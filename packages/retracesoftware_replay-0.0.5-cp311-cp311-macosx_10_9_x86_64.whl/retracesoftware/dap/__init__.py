import os
import sys


def _exec_replay():
    """Entry point shim: find (or build) the Go replay binary and exec it."""
    pkg_dir = os.path.dirname(os.path.abspath(__file__))

    # Packaged binary (inside installed wheel)
    go_bin = os.path.join(pkg_dir, 'replay')
    if os.path.isfile(go_bin) and os.access(go_bin, os.X_OK):
        os.execvp(go_bin, [go_bin] + sys.argv[1:])

    # Dev build: compile from source if needed
    repo_root = os.path.normpath(os.path.join(pkg_dir, '..', '..', '..'))
    go_bin = os.path.join(repo_root, '_build', 'replay')

    if not os.path.isfile(go_bin):
        import subprocess
        os.makedirs(os.path.dirname(go_bin), exist_ok=True)
        print(f"replay: building Go binary → {go_bin}", file=sys.stderr)
        subprocess.check_call(['go', 'build', '-o', go_bin, '.'], cwd=repo_root)

    os.execvp(go_bin, [go_bin] + sys.argv[1:])
