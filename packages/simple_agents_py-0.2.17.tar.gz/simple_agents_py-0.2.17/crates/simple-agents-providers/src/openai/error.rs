//! OpenAI-specific error handling.

use simple_agent_type::ProviderError;
use std::time::Duration;
use thiserror::Error;

/// OpenAI-specific errors
#[derive(Error, Debug)]
pub enum OpenAIError {
    /// Invalid API key
    #[error("Invalid API key")]
    InvalidApiKey,

    /// Model not found or not accessible
    #[error("Model not found: {0}")]
    ModelNotFound(String),

    /// Rate limit exceeded
    #[error("Rate limit exceeded")]
    RateLimit {
        /// Time to wait before retrying
        retry_after: Option<Duration>,
    },

    /// Context length exceeded
    #[error("Context length exceeded: {0}")]
    ContextLengthExceeded(String),

    /// Server error (5xx)
    #[error("Server error: {0}")]
    ServerError(String),

    /// Bad request (4xx)
    #[error("Bad request: {0}")]
    BadRequest(String),

    /// Unknown error
    #[error("Unknown error: {0}")]
    Unknown(String),
}

impl OpenAIError {
    /// Parse OpenAI error from HTTP response
    ///
    /// # Arguments
    ///
    /// * `status` - HTTP status code
    /// * `body` - Response body text
    pub fn from_response(status: u16, body: &str, retry_after_hint: Option<Duration>) -> Self {
        // Try to parse as OpenAI error response
        if let Ok(error_response) = serde_json::from_str::<super::OpenAIErrorResponse>(body) {
            return Self::from_error_details(
                status,
                &error_response.error.message,
                retry_after_hint,
            );
        }

        // If not JSON, still check for specific patterns in plain text
        Self::from_error_details(status, body, retry_after_hint)
    }

    /// Parse error from error details
    fn from_error_details(status: u16, message: &str, retry_after_hint: Option<Duration>) -> Self {
        let message_lower = message.to_lowercase();

        // Check for specific error patterns
        if message_lower.contains("invalid") && message_lower.contains("api key") {
            return Self::InvalidApiKey;
        }

        if message_lower.contains("model") && message_lower.contains("not found") {
            return Self::ModelNotFound(message.to_string());
        }

        if message_lower.contains("rate limit") {
            return Self::RateLimit {
                retry_after: retry_after_hint,
            };
        }

        if message_lower.contains("context length") {
            return Self::ContextLengthExceeded(message.to_string());
        }

        // Fall back to status-based error
        match status {
            401 => Self::InvalidApiKey,
            404 => Self::ModelNotFound(message.to_string()),
            429 => Self::RateLimit {
                retry_after: retry_after_hint,
            },
            400..=499 => Self::BadRequest(message.to_string()),
            500..=599 => Self::ServerError(message.to_string()),
            _ => Self::Unknown(message.to_string()),
        }
    }
}

/// Convert OpenAIError to ProviderError
impl From<OpenAIError> for ProviderError {
    fn from(error: OpenAIError) -> Self {
        match error {
            OpenAIError::InvalidApiKey => ProviderError::InvalidApiKey,
            OpenAIError::ModelNotFound(msg) => ProviderError::ModelNotFound(msg),
            OpenAIError::RateLimit { retry_after } => ProviderError::RateLimit { retry_after },
            OpenAIError::ContextLengthExceeded(msg) => ProviderError::BadRequest(msg),
            OpenAIError::ServerError(msg) => ProviderError::ServerError(msg),
            OpenAIError::BadRequest(msg) => ProviderError::BadRequest(msg),
            OpenAIError::Unknown(msg) => ProviderError::InvalidResponse(msg),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_invalid_api_key_error() {
        let error = OpenAIError::from_response(401, "Incorrect API key provided", None);
        assert!(matches!(error, OpenAIError::InvalidApiKey));
    }

    #[test]
    fn test_model_not_found_error() {
        let error = OpenAIError::from_response(404, "Model gpt-5 not found", None);
        assert!(matches!(error, OpenAIError::ModelNotFound(_)));
    }

    #[test]
    fn test_rate_limit_error() {
        let error =
            OpenAIError::from_response(429, "Rate limit exceeded", Some(Duration::from_secs(7)));
        assert!(matches!(error, OpenAIError::RateLimit { .. }));
        assert!(matches!(
            error,
            OpenAIError::RateLimit {
                retry_after: Some(d)
            } if d == Duration::from_secs(7)
        ));
    }

    #[test]
    fn test_server_error() {
        let error = OpenAIError::from_response(500, "Internal server error", None);
        assert!(matches!(error, OpenAIError::ServerError(_)));
    }

    #[test]
    fn test_parse_json_error() {
        let json = r#"{
            "error": {
                "message": "Invalid API key provided",
                "type": "invalid_request_error",
                "code": "invalid_api_key"
            }
        }"#;

        let error = OpenAIError::from_response(401, json, None);
        assert!(matches!(error, OpenAIError::InvalidApiKey));
    }

    #[test]
    fn test_context_length_exceeded() {
        let error = OpenAIError::from_response(
            400,
            "This model's maximum context length is 4096 tokens",
            None,
        );
        assert!(matches!(error, OpenAIError::ContextLengthExceeded(_)));
    }

    #[test]
    fn test_status_matrix_mapping() {
        let retry_after = Some(Duration::from_secs(5));

        let unauthorized = OpenAIError::from_response(401, "unauthorized", None);
        assert!(matches!(unauthorized, OpenAIError::InvalidApiKey));

        let forbidden = OpenAIError::from_response(403, "forbidden", None);
        assert!(matches!(forbidden, OpenAIError::BadRequest(_)));

        let not_found = OpenAIError::from_response(404, "missing model", None);
        assert!(matches!(not_found, OpenAIError::ModelNotFound(_)));

        let timeout = OpenAIError::from_response(408, "request timeout", None);
        assert!(matches!(timeout, OpenAIError::BadRequest(_)));

        let rate = OpenAIError::from_response(429, "rate limited", retry_after);
        assert!(matches!(
            rate,
            OpenAIError::RateLimit {
                retry_after: Some(d)
            } if d == Duration::from_secs(5)
        ));

        let server = OpenAIError::from_response(500, "server error", None);
        assert!(matches!(server, OpenAIError::ServerError(_)));

        let unavailable = OpenAIError::from_response(503, "unavailable", None);
        assert!(matches!(unavailable, OpenAIError::ServerError(_)));
    }
}
