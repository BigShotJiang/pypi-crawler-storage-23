"""Tests for poster2json."""
