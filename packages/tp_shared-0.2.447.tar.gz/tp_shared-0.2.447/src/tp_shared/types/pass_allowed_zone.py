from enum import Enum, StrEnum


class PassAllowedZone(str, Enum):
    MKAD = "МКАД"
    SK = "СК"
    TTK = "ТТК"
    MO = "МО"

    @classmethod
    def _missing_(cls, value):
        if value == "Московская область":
            return cls.MO
        return None


class PassAllowedZoneEn(StrEnum):
    MO = "MO"
    MKAD = "MKAD"
    TTK = "TTK"
    SK = "SK"
    NoZone = "NoZone"
