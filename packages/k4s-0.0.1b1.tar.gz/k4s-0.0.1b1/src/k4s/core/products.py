from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Optional


@dataclass(frozen=True)
class Step:
    title: str
    run: Optional[Callable[[], None]] = None


def run_steps(ui, steps: List[Step], *, dry_run: bool) -> None:
    """Execute a list of steps, or print the plan if dry_run is True."""
    if dry_run:
        ui.log("Dry-run mode. No changes will be applied.")
        ui.info("Planned steps:")
        for s in steps:
            ui.info(f"- {s.title}")
        return

    for s in steps:
        with ui.step(s.title):
            if s.run:
                s.run()
