"""UI helpers for k4s.

This module is responsible for rendering user-facing output. The core logic
must stay deterministic; the UI only changes presentation (verbosity, typing,
spinners, etc.).
"""

