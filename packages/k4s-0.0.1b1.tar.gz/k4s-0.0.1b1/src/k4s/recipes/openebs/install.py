"""OpenEBS installation recipe (Helm-based, LocalPV Hostpath engine).

Installs OpenEBS into an existing Kubernetes cluster and optionally marks
``openebs-hostpath`` as the default StorageClass — useful for on-prem
vanilla clusters that ship without a built-in provisioner.

Requires:
- cluster-admin privileges in the target cluster
- helm and kubectl available locally
"""

from __future__ import annotations

import json
import os
import shlex
import time

from k4s.core.executor import Executor, ExecutorError
from k4s.core.products import Step
from k4s.recipes.common.helm import which
from k4s.recipes.common.run import check, q, run
from k4s.recipes.openebs.model import (
    DEFAULT_OPENEBS_REPO_NAME,
    DEFAULT_OPENEBS_REPO_URL,
    DEFAULT_OPENEBS_STORAGE_CLASS,
    OpenEbsInstallPlan,
)
from k4s.ui.ui import Ui


def _kube(plan: OpenEbsInstallPlan, *args: str) -> str:
    """Build a kubectl command string with kubeconfig/context flags."""
    flags = " ".join(shlex.quote(f) for f in plan.kubectl_flags())
    rest = " ".join(shlex.quote(a) for a in args)
    return f"kubectl {flags} {rest}"


def _helm(plan: OpenEbsInstallPlan, *args: str) -> str:
    """Build a helm command string with kubeconfig/context flags."""
    flags = " ".join(shlex.quote(f) for f in plan.helm_flags())
    rest = " ".join(shlex.quote(a) for a in args)
    return f"helm {flags} {rest}"


def build_install_steps(
    ui: Ui,
    ex: Executor,
    plan: OpenEbsInstallPlan,
) -> list[Step]:
    """Return the ordered steps to install OpenEBS via Helm."""

    def _helm_install():
        # --- pre-checks (shown as log lines, not a separate step) ---
        if not os.path.exists(plan.kubeconfig_path):
            raise ExecutorError(f"Kubeconfig not found: {plan.kubeconfig_path}")
        if not which(ex, "kubectl"):
            raise ExecutorError("kubectl is not installed locally. Install it and retry.")
        if not which(ex, "helm"):
            raise ExecutorError("helm is not installed locally. Install it and retry.")

        rc, _, err = run(ex, _kube(plan, "get", "nodes"))
        if rc != 0:
            raise ExecutorError(f"Cannot access cluster:\n{err}")

        # OpenEBS creates CRDs, ClusterRoles, and DaemonSets — cluster-admin is required.
        rc, out, _ = run(ex, _kube(plan, "auth", "can-i", "*", "*", "--all-namespaces"))
        if rc != 0 or out.strip().lower() != "yes":
            raise ExecutorError(
                "OpenEBS requires cluster-admin privileges.\n"
                "The current kubeconfig user does not have sufficient permissions.\n"
                "Run: kubectl auth can-i '*' '*' --all-namespaces"
            )

        # --- helm install ---
        ui.log(f"Adding OpenEBS Helm repo ({DEFAULT_OPENEBS_REPO_URL}).")
        run(ex, f"helm repo add {q(DEFAULT_OPENEBS_REPO_NAME)} {q(DEFAULT_OPENEBS_REPO_URL)}")
        check(ex, f"helm repo update {q(DEFAULT_OPENEBS_REPO_NAME)}")

        # The upstream `openebs/openebs` umbrella chart enables many heavy
        # components by default (Loki/MinIO/Alloy, Mayastor, LVM/ZFS engines).
        # On small / single-node clusters this frequently leads to Pod evictions
        # (DiskPressure/MemoryPressure) and Helm `--wait` timeouts.
        #
        # k4s defaults to a minimal install focused on LocalPV Hostpath.
        minimal_sets = [
            # LocalPV Hostpath data directory on the node.
            f"localpv-provisioner.hostpathClass.basePath={plan.storage_path}",
            # Disable engines we don't need for the minimal default.
            "engines.local.lvm.enabled=false",
            "engines.local.zfs.enabled=false",
            "engines.replicated.mayastor.enabled=false",
            # Disable observability/logging stack (very resource heavy).
            "loki.enabled=false",
            "alloy.enabled=false",
            # Avoid managing VolumeSnapshot CRDs (commonly pre-installed by distros like RKE2).
            "openebs-crds.csi.volumeSnapshots.enabled=false",
        ]

        cmd_parts = [
            "helm",
            *plan.helm_flags(),
            "upgrade", "--install",
            plan.release_name,
            f"{DEFAULT_OPENEBS_REPO_NAME}/{plan.release_name}",
            "--namespace", plan.namespace,
            "--create-namespace",
            "--timeout", plan.timeout,
            "--wait",
        ]
        if plan.values_files:
            for vf in plan.values_files:
                cmd_parts += ["--values", vf]
        for s in minimal_sets:
            cmd_parts += ["--set", s]
        if plan.set_values:
            for s in plan.set_values:
                cmd_parts += ["--set", s]
        if plan.chart_version:
            cmd_parts += ["--version", plan.chart_version]

        helm_cmd = " ".join(shlex.quote(p) for p in cmd_parts)

        for attempt in range(3):
            ui.log(f"Running helm upgrade --install openebs (namespace: {plan.namespace}).")
            rc, out, err = run(ex, helm_cmd)
            if rc == 0:
                break

            msg = f"{err or ''}\n{out or ''}".lower()
            transient = (
                "context deadline exceeded" in msg
                or "the server was unable to return a response in the time allotted" in msg
            )
            if transient and attempt < 2:
                ui.log(
                    f"Helm install did not complete in time (attempt {attempt + 1}/3); "
                    "waiting 10 s and retrying..."
                )
                time.sleep(10)
                continue

            raise ExecutorError(
                f"Command failed (rc={rc}): {helm_cmd}\n{err or out}"
            )

    def _set_default_storage_class():
        if not plan.set_default_storage_class:
            return
        sc = DEFAULT_OPENEBS_STORAGE_CLASS
        patch = json.dumps({
            "metadata": {
                "annotations": {
                    "storageclass.kubernetes.io/is-default-class": "true"
                }
            }
        })
        ui.log(f"Marking '{sc}' as the default StorageClass.")
        rc, _, err = run(ex, _kube(plan, "patch", "storageclass", sc, "-p", patch))
        if rc != 0:
            ui.warning(
                f"Could not patch StorageClass '{sc}': {err}\n"
                "You can set it manually:\n"
                f"  kubectl patch storageclass {sc} "
                "-p '{\"metadata\":{\"annotations\":{\"storageclass.kubernetes.io/is-default-class\":\"true\"}}}'"
            )

    return [
        Step(title="Install OpenEBS via Helm", run=_helm_install),
        Step(title="Set default StorageClass", run=_set_default_storage_class),
    ]
