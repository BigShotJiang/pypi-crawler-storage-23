"""OpenEBS uninstallation recipe (Helm-based).

Runs ``helm uninstall`` for the OpenEBS release and optionally deletes
the namespace.  CRDs installed by OpenEBS are left intact by default
(Helm does not delete CRDs on uninstall) so that existing PVCs are not
silently orphaned; the operator can remove them manually if desired.
"""

from __future__ import annotations

import shlex

from k4s.core.executor import Executor
from k4s.core.products import Step
from k4s.recipes.common.run import run
from k4s.recipes.openebs.model import OpenEbsUninstallPlan
from k4s.ui.ui import Ui


def _kube(plan: OpenEbsUninstallPlan, *args: str) -> str:
    flags = " ".join(shlex.quote(f) for f in plan.kubectl_flags())
    rest = " ".join(shlex.quote(a) for a in args)
    return f"kubectl {flags} {rest}"


def build_uninstall_steps(
    ui: Ui,
    ex: Executor,
    plan: OpenEbsUninstallPlan,
) -> list[Step]:
    """Return the ordered steps to uninstall OpenEBS via Helm."""

    def _helm_uninstall():
        helm_flags = " ".join(shlex.quote(f) for f in plan.helm_flags())
        cmd = (
            f"helm {helm_flags} uninstall {shlex.quote(plan.release_name)}"
            f" --namespace {shlex.quote(plan.namespace)}"
            f" --timeout {plan.timeout}"
            f" --wait"
        )
        ui.log(f"Running helm uninstall {plan.release_name} (namespace: {plan.namespace}).")
        rc, _, err = run(ex, cmd)
        if rc != 0:
            # Treat "not found" as a no-op — idempotent uninstall.
            if "not found" in (err or "").lower() or "release: not found" in (err or "").lower():
                ui.log(f"Release '{plan.release_name}' not found — nothing to uninstall.")
            else:
                from k4s.core.executor import ExecutorError
                raise ExecutorError(f"helm uninstall failed:\n{err}")

        ui.log("Note: OpenEBS CRDs are NOT removed automatically (Helm never deletes CRDs).")
        ui.log("To remove them manually: kubectl get crd | grep openebs | awk '{print $1}' | xargs kubectl delete crd")

    def _delete_namespace():
        if not plan.delete_namespace:
            return
        ui.log(f"Deleting namespace '{plan.namespace}'.")
        rc, _, err = run(ex, _kube(plan, "delete", "namespace", plan.namespace, "--ignore-not-found"))
        if rc != 0:
            ui.warning(f"Could not delete namespace '{plan.namespace}': {err}")

    return [
        Step(title=f"Uninstall OpenEBS ({plan.release_name})", run=_helm_uninstall),
        Step(title="Delete namespace", run=_delete_namespace),
    ]
