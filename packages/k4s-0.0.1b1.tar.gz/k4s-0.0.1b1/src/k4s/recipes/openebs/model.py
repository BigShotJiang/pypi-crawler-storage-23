"""OpenEBS installation model."""

from __future__ import annotations

from dataclasses import dataclass

DEFAULT_OPENEBS_NAMESPACE = "openebs"
DEFAULT_OPENEBS_REPO_NAME = "openebs"
DEFAULT_OPENEBS_REPO_URL = "https://openebs.github.io/openebs"
DEFAULT_OPENEBS_CHART_NAME = "openebs"
DEFAULT_OPENEBS_STORAGE_CLASS = "openebs-hostpath"
DEFAULT_OPENEBS_STORAGE_PATH = "/var/openebs/local"


@dataclass(frozen=True)
class OpenEbsUninstallPlan:
    """Plan inputs for uninstalling OpenEBS via Helm."""

    kubeconfig_path: str
    kubectl_context: str | None = None

    namespace: str = DEFAULT_OPENEBS_NAMESPACE
    release_name: str = "openebs"

    # When True, delete the namespace after helm uninstall.
    delete_namespace: bool = False

    timeout: str = "5m"

    def kubectl_flags(self) -> list[str]:
        flags: list[str] = ["--kubeconfig", self.kubeconfig_path]
        if self.kubectl_context:
            flags += ["--context", self.kubectl_context]
        return flags

    def helm_flags(self) -> list[str]:
        flags: list[str] = ["--kubeconfig", self.kubeconfig_path]
        if self.kubectl_context:
            flags += ["--kube-context", self.kubectl_context]
        return flags


@dataclass(frozen=True)
class OpenEbsInstallPlan:
    """Plan inputs for installing OpenEBS via Helm."""

    kubeconfig_path: str
    kubectl_context: str | None = None

    namespace: str = DEFAULT_OPENEBS_NAMESPACE
    release_name: str = "openebs"
    chart_version: str | None = None
    storage_path: str = DEFAULT_OPENEBS_STORAGE_PATH

    values_files: list[str] | None = None
    set_values: list[str] | None = None

    # When True, patch openebs-hostpath as the cluster default StorageClass.
    set_default_storage_class: bool = True

    timeout: str = "5m"

    def kubectl_flags(self) -> list[str]:
        flags: list[str] = ["--kubeconfig", self.kubeconfig_path]
        if self.kubectl_context:
            flags += ["--context", self.kubectl_context]
        return flags

    def helm_flags(self) -> list[str]:
        flags: list[str] = ["--kubeconfig", self.kubeconfig_path]
        if self.kubectl_context:
            flags += ["--kube-context", self.kubectl_context]
        return flags
