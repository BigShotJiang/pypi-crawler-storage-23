"""Starburst recipes."""

