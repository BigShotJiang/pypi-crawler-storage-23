"""User Isolation Framework (UIF) integration for Dataiku DSS.

Automates system-level UIF setup using ``dssadmin install-impersonation`` and
configures cgroups v2 (or v1) resource control, producing a production-ready
isolated DSS installation.

Steps performed:
1. Stop DSS.
2. Run ``dssadmin install-impersonation`` as root.
3. Patch ``/etc/dataiku-security/<INSTALL_ID>/security-config.ini``
   (allowed groups, auto-user creation, cgroup allowed dirs).
4. Create the cgroup directory and enable controllers (cgroups v2) or
   create per-controller directories (cgroups v1).
5. Patch ``/etc/dataiku/<INSTALL_ID>/dataiku-boot.conf``
   (DSS_CGROUPS, DSS_CGROUP_CONTROLLERS).
6. Patch ``DATA_DIR/config/general-settings.json`` with the user impersonation
   rule *before* DSS starts, so DSS reads the correct rule type on boot.
   Writing directly to the config file bypasses the REST API's normalisation,
   which silently drops the ``type`` field for user rules.
7. Start DSS via systemd so boot-time cgroup initialisation hooks run.

Reference:
- https://doc.dataiku.com/dss/latest/user-isolation/initial-setup.html
- https://doc.dataiku.com/dss/latest/operations/cgroups.html
"""

from __future__ import annotations

import json
import uuid

from k4s.core.executor import Executor, ExecutorError
from k4s.core.products import Step
from k4s.recipes.common.run import check, q, run
from k4s.recipes.dataiku.model import DataikuUifPlan
from k4s.recipes.dataiku.utils import detect_dss_cgroup_name, dss_start, dss_stop
from k4s.ui.ui import Ui


# ---------------------------------------------------------------------------
# INI file helpers
# ---------------------------------------------------------------------------

def _update_ini(content: str, section: str, updates: dict[str, str]) -> str:
    """Update or add key=value pairs in a specific INI section.

    Preserves existing comments, whitespace, and unrelated sections.
    Missing keys are appended at the end of the target section.
    """
    lines = content.splitlines()
    result: list[str] = []
    in_section = False
    section_header = f"[{section}]"
    updated: set[str] = set()

    for i, line in enumerate(lines):
        stripped = line.strip()

        if stripped.startswith("["):
            if in_section:
                # Leaving our section — flush any keys not yet written.
                for k, v in updates.items():
                    if k not in updated:
                        result.append(f"{k} = {v}")
                        updated.add(k)
            in_section = stripped == section_header
            result.append(line)
            continue

        if in_section and "=" in stripped and not stripped.startswith("#"):
            k = line.split("=", 1)[0].strip()
            if k in updates:
                result.append(f"{k} = {updates[k]}")
                updated.add(k)
                continue

        result.append(line)

    # If still in our section at EOF, flush remaining keys.
    if in_section:
        for k, v in updates.items():
            if k not in updated:
                result.append(f"{k} = {v}")

    return "\n".join(result) + "\n"


def _update_shell_vars(content: str, updates: dict[str, str]) -> str:
    """Update shell variable assignments (KEY="VALUE") in a conf file.

    Preserves existing comments and unknown lines. Missing keys are appended.
    """
    lines = content.splitlines()
    result: list[str] = []
    updated: set[str] = set()

    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            result.append(line)
            continue
        if "=" in stripped:
            k = stripped.split("=", 1)[0].strip()
            if k in updates:
                result.append(f'{k}="{updates[k]}"')
                updated.add(k)
                continue
        result.append(line)

    for k, v in updates.items():
        if k not in updated:
            result.append(f'{k}="{v}"')

    return "\n".join(result) + "\n"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_install_id(ex: Executor, data_dir: str) -> str:
    """Read the DSS INSTALL_ID from DATA_DIR/install.ini (via sudo)."""
    ini = f"{data_dir}/install.ini"
    rc, out, err = run(
        ex,
        f"sudo -n grep -i 'installid' {q(ini)} | head -1 | cut -d= -f2 | tr -d ' \\t'",
    )
    if not out.strip():
        raise ExecutorError(
            f"Could not read INSTALL_ID from {ini}.\n"
            f"Ensure DSS is installed before running UIF setup.\n"
            f"{err or ''}".rstrip()
        )
    return out.strip()


def _read_root_file(ex: Executor, path: str) -> str:
    """Read a root-owned remote file via sudo cat."""
    rc, content, err = run(ex, f"sudo -n cat {q(path)}")
    if rc != 0:
        raise ExecutorError(f"Cannot read {path}: {err or 'permission denied'}")
    return content


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_uif_steps(
    ui: Ui,
    ex: Executor,
    plan: DataikuUifPlan,
) -> list[Step]:
    """Return the ordered steps to configure UIF + cgroups for Dataiku DSS."""

    # Resolved lazily on first use so detection runs inside a step (with SSH
    # connection active) rather than at plan-build time.
    _resolved: dict[str, str] = {}

    def _cgroup_name() -> str:
        if "cgroup_name" not in _resolved:
            if plan.cgroup_name is not None:
                _resolved["cgroup_name"] = plan.cgroup_name
            else:
                detected = detect_dss_cgroup_name(ex, plan.data_dir)
                ui.log(f"Auto-detected cgroup name: {detected!r}.")
                _resolved["cgroup_name"] = detected
        return _resolved["cgroup_name"]

    def _preflight():
        ui.log("Checking non-interactive sudo and DSS installation.")
        check(ex, "sudo -n true", error_hint="Configure passwordless sudo (NOPASSWD) for the SSH user.")

        rc, _, _ = run(ex, f"test -x {q(f'{plan.data_dir}/bin/dssadmin')}")
        if rc != 0:
            raise ExecutorError(
                f"dssadmin not found at {plan.data_dir}/bin/dssadmin.\n"
                "Install DSS first with `k4s install dataiku`, or pass the correct "
                "--root-dir / --data-dir-name."
            )

        ui.log("Checking cgroups support on host.")
        if plan.cgroup_version == 2:
            rc2, _, _ = run(ex, "test -f /sys/fs/cgroup/cgroup.controllers")
            if rc2 != 0:
                raise ExecutorError(
                    "cgroups v2 not found at /sys/fs/cgroup/cgroup.controllers.\n"
                    "Either the host uses cgroups v1 (pass --cgroup-version 1) "
                    "or cgroups is not mounted."
                )

    def _install_impersonation():
        ui.log("Stopping DSS before running dssadmin install-impersonation.")
        dss_stop(ex, ui, plan.os_user, plan.data_dir)

        ui.log(f"Running dssadmin install-impersonation {plan.os_user}.")
        check(
            ex,
            f"cd {q(plan.data_dir)} && sudo -n ./bin/dssadmin install-impersonation {q(plan.os_user)}",
            error_hint=(
                "dssadmin install-impersonation failed. "
                "Check /var/log/auth.log or run with -vv for details."
            ),
        )

    def _configure_security_ini():
        install_id = _get_install_id(ex, plan.data_dir)
        sec_ini = f"/etc/dataiku-security/{install_id}/security-config.ini"
        ui.log(f"Patching {sec_ini}.")

        current = _read_root_file(ex, sec_ini)

        cgroup_dir = _cgroup_allowed_dirs(plan, _cgroup_name())

        users_updates: dict[str, str] = {
            "allowed_user_groups": plan.allowed_user_groups,
        }
        if plan.auto_create_users:
            users_updates["auto_create_users"] = "yes"
            users_updates["auto_created_users_group"] = plan.auto_created_users_group
            users_updates["auto_created_users_prefix"] = plan.auto_created_users_prefix

        updated = _update_ini(current, "users", users_updates)
        updated = _update_ini(updated, "dirs", {
            "additional_allowed_file_dirs": cgroup_dir,
        })

        ex.write_remote_file_content(sec_ini, updated, use_sudo=True)

    def _setup_cgroups():
        name = _cgroup_name()
        if plan.cgroup_version == 2:
            cgroup_path = f"{plan.cgroup_root.rstrip('/')}/{name}"
            ui.log(f"Creating cgroup directory {cgroup_path} and enabling controllers.")
            check(ex, f"sudo -n mkdir -p {q(cgroup_path)}")
            controllers = " ".join(f"+{c}" for c in plan.cgroup_controllers.split())
            check(ex, f"echo {q(controllers)} | sudo -n tee {q(f'{plan.cgroup_root}/cgroup.subtree_control')} > /dev/null")
            check(ex, f"echo {q(controllers)} | sudo -n tee {q(f'{cgroup_path}/cgroup.subtree_control')} > /dev/null")
            check(ex, f"sudo -n chown {q(plan.os_user)} {q(cgroup_path)} {q(f'{cgroup_path}/cgroup.procs')}")
        else:
            # cgroups v1: one directory per controller.
            for ctrl in plan.cgroup_controllers.split():
                cgroup_path = f"{plan.cgroup_root.rstrip('/')}/{ctrl}/{name}"
                ui.log(f"Creating cgroup v1 directory {cgroup_path}.")
                check(ex, f"sudo -n mkdir -p {q(cgroup_path)}")
                check(ex, f"sudo -n chown -Rh {q(plan.os_user)} {q(cgroup_path)}")

    def _configure_boot_conf():
        install_id = _get_install_id(ex, plan.data_dir)
        boot_conf = f"/etc/dataiku/{install_id}/dataiku-boot.conf"
        ui.log(f"Patching {boot_conf}.")

        current = _read_root_file(ex, boot_conf)

        name = _cgroup_name()
        if plan.cgroup_version == 1:
            cgroups_val = ":".join(
                f"{ctrl}/{name}" for ctrl in plan.cgroup_controllers.split()
            )
        else:
            cgroups_val = name

        updates: dict[str, str] = {
            "DSS_CGROUPS": cgroups_val,
        }
        if plan.cgroup_version == 2:
            updates["DSS_CGROUP_CONTROLLERS"] = plan.cgroup_controllers

        updated = _update_shell_vars(current, updates)
        ex.write_remote_file_content(boot_conf, updated, use_sudo=True)

    def _configure_impersonation_rules():
        """Write user impersonation rules directly into DATA_DIR/config/general-settings.json.

        The DSS REST API endpoint for general-settings normalises user rules and
        silently drops the ``type`` field, making it impossible to set "Pattern
        matching" rules through the API.  Writing to the config file directly
        (before DSS boots) avoids this normalisation entirely.

        A UUID-named temp file is used to prevent symlink / pre-creation attacks
        that a fixed path like ``/tmp/.k4s_dss_settings.json`` would be
        vulnerable to.
        """
        settings_file = f"{plan.data_dir}/config/general-settings.json"
        src = plan.impersonation_source_pattern
        tgt_unix = plan.impersonation_target_unix
        tgt_hadoop = plan.impersonation_target_hadoop

        ui.log(f"Patching {settings_file} with user impersonation rule.")

        rc, out, err = run(ex, f"sudo -n cat {q(settings_file)}", silent=True)
        if rc != 0:
            raise ExecutorError(
                f"Cannot read {settings_file}.\n"
                f"{err or out}\n"
                "Ensure dssadmin install-impersonation ran successfully."
            )

        try:
            settings = json.loads(out)
        except json.JSONDecodeError as exc:
            raise ExecutorError(
                f"Invalid JSON in {settings_file}: {exc}"
            ) from exc

        impersonation = settings.setdefault("impersonation", {})
        impersonation["userRules"] = [
            {
                "type": "REGEXP_RULE",
                "scope": "GLOBAL",
                "ruleFrom": src,
                "targetUnix": tgt_unix,
                "targetHadoop": tgt_hadoop,
            }
        ]

        tmp_path = f"/tmp/.k4s_{uuid.uuid4().hex}.json"
        ex.write_remote_file_content(tmp_path, json.dumps(settings))
        run(ex, f"sudo -n cp {q(tmp_path)} {q(settings_file)}", silent=True)
        run(ex, f"sudo -n chown dataiku: {q(settings_file)}", silent=True)
        run(ex, f"rm -f {q(tmp_path)}", silent=True)

        ui.log(
            f"Rule: {src!r} → {tgt_unix!r}"
            + (f" / {tgt_hadoop!r} (Hadoop)" if tgt_hadoop else "")
        )
        json_lines = json.dumps(impersonation, indent=2).splitlines()
        indented_json = "\n".join("  " + line for line in json_lines)
        ui.log(f"Impersonation section written:\n{indented_json}")

    def _start():
        ui.log("Starting DSS (via systemd to trigger cgroup boot hooks).")
        dss_start(ex, ui, plan.os_user, plan.data_dir)

    return [
        Step(title=f"Preflight (UIF) on {ex.host}", run=_preflight),
        Step(title="Initialize User Isolation Framework", run=_install_impersonation),
        Step(title="Configure security-config.ini", run=_configure_security_ini),
        Step(title="Setup cgroup directory", run=_setup_cgroups),
        Step(title="Configure dataiku-boot.conf", run=_configure_boot_conf),
        Step(title="Configure user impersonation rules", run=_configure_impersonation_rules),
        Step(title="Start Dataiku", run=_start),
    ]


def _cgroup_allowed_dirs(plan: DataikuUifPlan, cgroup_name: str) -> str:
    """Return the semicolon-separated cgroup path(s) for additional_allowed_file_dirs."""
    if plan.cgroup_version == 2:
        return f"{plan.cgroup_root.rstrip('/')}/{cgroup_name}"
    # cgroups v1: one path per controller
    return ";".join(
        f"{plan.cgroup_root.rstrip('/')}/{ctrl}/{cgroup_name}"
        for ctrl in plan.cgroup_controllers.split()
    )
