"""Standalone Hadoop integration recipe for Dataiku DSS.

Wraps ``dssadmin install-hadoop-integration`` in standalone mode to add Hadoop
connectivity to an existing DSS instance without requiring a full Cloudera/CDP
cluster.  Optionally uploads a local archive before running the dssadmin command.

Used by:
- ``k4s install dataiku --with-hadoop``
- ``k4s install hadoop`` (post-install enablement)

Reference: https://doc.dataiku.com/dss/latest/hadoop/installation.html
"""

from __future__ import annotations

from k4s.core.downloader import AssetDownloader, DownloaderError
from k4s.core.executor import Executor, ExecutorError
from k4s.core.products import Step
from k4s.recipes.common.run import check, q
from k4s.recipes.dataiku.utils import detect_dss_version, dss_start, dss_stop
from k4s.ui.ui import Ui

_DEFAULT_FLAVOR = "generic-hadoop3"


def build_hadoop_steps(
    ui: Ui,
    ex: Executor,
    *,
    data_dir: str,
    os_user: str,
    install_dir: str,
    dss_version: str | None = None,
    hadoop_archive_path: str | None = None,
    hadoop_flavor: str = _DEFAULT_FLAVOR,
) -> list[Step]:
    """Build steps to install standalone Hadoop integration on an existing DSS instance.

    Downloads (or uploads, for air-gapped) the Dataiku standalone Hadoop libs
    archive, then passes it directly to ``dssadmin install-hadoop-integration
    -standaloneArchive`` — no extraction required.

    Args:
        ui: UI renderer.
        ex: Executor (SSH or local).
        data_dir: DSS data directory (e.g. /data/dataiku/DATA_DIR).
        os_user: OS user that owns the DSS installation.
        install_dir: Remote directory under which archives are placed.
        dss_version: DSS version. Auto-detected from ``dss-version.json`` if
            ``None`` (can also be overridden via ``--dss-version``).
        hadoop_archive_path: Local archive path to upload (air-gapped).
        hadoop_flavor: Standalone distribution identifier passed to
            ``-standalone`` (default: ``generic-hadoop3``).
    """
    if not install_dir:
        raise ValueError("install_dir is required")

    steps: list[Step] = []

    # Shared mutable state across step closures.
    _state: dict = {"dss_version": dss_version, "remote_archive_path": None}

    # ── Preflight ──────────────────────────────────────────────────────────

    def _preflight():
        rc, _, _ = ex.execute(f"test -x {q(f'{data_dir}/bin/dssadmin')}")
        if rc != 0:
            raise ExecutorError(
                f"Dataiku not found at {data_dir}.\n"
                "Install DSS first with `k4s install dataiku`, or pass the correct "
                "--root-dir/--data-dir-name."
            )
        if not _state["dss_version"]:
            v = detect_dss_version(ex, data_dir)
            if not v:
                raise ExecutorError(
                    "Unable to detect DSS version from dss-version.json.\n"
                    f"  DATADIR: {data_dir}\n"
                    "  Pass --dss-version explicitly."
                )
            _state["dss_version"] = v
        v = _state["dss_version"]
        _state["remote_archive_path"] = (
            f"{install_dir.rstrip('/')}/"
            f"dataiku-dss-hadoop-standalone-libs-{hadoop_flavor}-{v}.tar.gz"
        )

    steps.append(Step(title="Preflight checks", run=_preflight))

    # ── Candidate download URLs ────────────────────────────────────────────

    def _candidate_urls() -> list[str]:
        v = _state["dss_version"]
        filename = _state["remote_archive_path"].split("/")[-1]
        base_paths = [
            f"https://downloads.dataiku.com/public/dss/{v}",
            f"https://cdn.downloads.dataiku.com/public/dss/{v}",
            f"https://downloads.dataiku.com/public/studio/{v}",
            f"https://cdn.downloads.dataiku.com/public/studio/{v}",
        ]
        return [f"{b}/{filename}" for b in base_paths]

    # ── Download or upload ─────────────────────────────────────────────────

    if hadoop_archive_path:
        def _upload():
            remote = _state["remote_archive_path"]
            ui.log(f"Uploading Hadoop standalone archive to {remote}.")
            ex.upload_file(hadoop_archive_path, remote, use_sudo=True)

        steps.append(Step(title="Upload Hadoop standalone archive", run=_upload))
    else:
        def _download():
            remote = _state["remote_archive_path"]
            v = _state["dss_version"]
            ui.log("Downloading Dataiku Hadoop standalone libraries.")
            dl = AssetDownloader(ex)
            last_err: str | None = None
            for url in _candidate_urls():
                try:
                    ui.log(f"Downloading: {url}")
                    dl.download(url, remote, sudo=True)
                    return
                except DownloaderError as e:
                    last_err = str(e)
                    continue
            raise DownloaderError(
                "Failed to download the Dataiku Hadoop standalone libraries archive.\n"
                f"  DSS version: {v}\n"
                f"  Expected filename: {remote.split('/')[-1]}\n"
                "  Tip: check the directory index at:\n"
                f"    https://downloads.dataiku.com/public/dss/{v}/\n"
                f"  Last error: {last_err}"
            )

        steps.append(Step(title="Download Hadoop standalone libraries", run=_download))

    # ── Install via dssadmin ───────────────────────────────────────────────

    def _install():
        remote = _state["remote_archive_path"]
        dss_stop(ex, ui, os_user, data_dir)
        cmd = (
            f"{data_dir}/bin/dssadmin install-hadoop-integration"
            f" -standalone {hadoop_flavor}"
            f" -standaloneArchive {q(remote)}"
        )
        ui.log("Running dssadmin install-hadoop-integration (standalone).")
        check(ex, f"sudo -n -u {q(os_user)} -i -- sh -c {q(cmd)}")
        dss_start(ex, ui, os_user, data_dir)

    steps.append(Step(title="Install Hadoop integration", run=_install))
    return steps
