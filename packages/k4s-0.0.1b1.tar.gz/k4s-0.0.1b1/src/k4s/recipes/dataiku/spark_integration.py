"""Spark integration recipe for Dataiku DSS.

Wraps ``dssadmin install-spark-integration`` to add Apache Spark support to an
existing DSS instance.  Downloads (or uploads, for air-gapped) Dataiku's Spark
standalone package, extracts its contents directly into ``spark_home_dir``, and
passes that directory to ``dssadmin``.

Used by:
- ``k4s install dataiku --with-spark``
- ``k4s install spark`` (post-install enablement)

Reference: https://doc.dataiku.com/dss/latest/spark/installation.html
"""

from __future__ import annotations

import shlex

from k4s.core.downloader import AssetDownloader, DownloaderError
from k4s.core.executor import Executor, ExecutorError
from k4s.core.products import Step
from k4s.recipes.common.run import check, q
from k4s.recipes.dataiku.utils import detect_dss_version, dss_start, dss_stop
from k4s.ui.ui import Ui

_FALLBACK_SPARK_VERSION = "3.5.3"


def _candidate_urls(dss_version: str, filename: str) -> list[str]:
    bases = [
        f"https://downloads.dataiku.com/public/dss/{dss_version}",
        f"https://cdn.downloads.dataiku.com/public/dss/{dss_version}",
        f"https://downloads.dataiku.com/public/studio/{dss_version}",
        f"https://cdn.downloads.dataiku.com/public/studio/{dss_version}",
    ]
    return [f"{b}/{filename}" for b in bases]


def _detect_spark_filename(ex: Executor, dss_version: str, spark_flavor: str) -> str | None:
    """Fetch the Dataiku download index to auto-detect the Spark tarball filename.

    Parses the HTML directory listing for the DSS version and returns the
    filename of the spark-standalone package matching the given flavor.
    Uses ``[A-Za-z0-9._-]+`` instead of a negated-quote class to avoid
    single-quote escaping issues inside shell single-quoted strings.
    """
    for base in [
        f"https://downloads.dataiku.com/public/dss/{dss_version}/",
        f"https://cdn.downloads.dataiku.com/public/dss/{dss_version}/",
        f"https://downloads.dataiku.com/public/studio/{dss_version}/",
        f"https://cdn.downloads.dataiku.com/public/studio/{dss_version}/",
    ]:
        rc, out, _ = ex.execute(
            f"curl -fsSL {shlex.quote(base)} 2>/dev/null"
            f" | grep -oE 'dataiku-dss-spark-standalone-{dss_version}-[A-Za-z0-9._-]+\\.tar\\.gz'"
            f" | grep {shlex.quote(spark_flavor)}"
            f" | head -1"
        )
        if rc == 0 and out.strip():
            return out.strip()
    return None


def build_spark_steps(
    ui: Ui,
    ex: Executor,
    *,
    data_dir: str,
    os_user: str,
    install_dir: str,
    dss_version: str | None = None,
    spark_home_dir: str,
    spark_version: str | None = None,
    spark_flavor: str = "generic-hadoop3",
    spark_archive_path: str | None = None,
) -> list[Step]:
    """Build steps to install Spark integration on an existing DSS instance.

    Downloads (or uploads) Dataiku's Spark standalone package, extracts its
    contents directly into ``spark_home_dir`` (using ``--strip-components=1``),
    and passes ``spark_home_dir`` to ``dssadmin install-spark-integration
    -sparkHome``.

    Args:
        ui: UI renderer.
        ex: Executor (SSH or local).
        data_dir: DSS data directory (e.g. /data/dataiku/DATA_DIR).
        os_user: OS user that owns the DSS installation.
        install_dir: Remote directory where the tarball is stored.
        dss_version: DSS version. Auto-detected from ``dss-version.json`` if
            ``None`` (can also be overridden via ``--dss-version``).
        spark_home_dir: Directory that becomes the Spark home (e.g.
            /data/dataiku/SPARK_HOME). Tarball is extracted directly into it.
        spark_version: Spark version string in the tarball filename.
            ``None`` = auto-detect from the Dataiku download index; falls back
            to ``3.5.3`` if detection fails.
        spark_flavor: Standalone flavor string in the filename
            (default: ``generic-hadoop3``).
        spark_archive_path: Local archive path to upload instead of
            downloading (air-gapped installs).
    """
    if not install_dir:
        raise ValueError("install_dir is required")

    steps: list[Step] = []

    # Shared mutable state across step closures.
    _state: dict = {"dss_version": dss_version, "filename": None}

    # ── Preflight ──────────────────────────────────────────────────────────

    def _preflight():
        rc, _, _ = ex.execute(f"test -x {q(f'{data_dir}/bin/dssadmin')}")
        if rc != 0:
            raise ExecutorError(
                f"Dataiku not found at {data_dir}.\n"
                "Install DSS first with `k4s install dataiku`, or pass the correct "
                "--root-dir/--data-dir-name."
            )
        if not _state["dss_version"]:
            v = detect_dss_version(ex, data_dir)
            if not v:
                raise ExecutorError(
                    "Unable to detect DSS version from dss-version.json.\n"
                    f"  DATADIR: {data_dir}\n"
                    "  Pass --dss-version explicitly."
                )
            _state["dss_version"] = v

    steps.append(Step(title="Preflight checks", run=_preflight))

    # ── Resolve tarball filename ───────────────────────────────────────────

    def _resolve_filename() -> str:
        v = _state["dss_version"]
        if spark_version:
            return f"dataiku-dss-spark-standalone-{v}-{spark_version}-{spark_flavor}.tar.gz"
        ui.log("Auto-detecting Spark version from Dataiku download index.")
        detected = _detect_spark_filename(ex, v, spark_flavor)
        if detected:
            ui.log(f"Detected Spark package: {detected}")
            return detected
        ui.log(f"Auto-detection failed; using fallback Spark version {_FALLBACK_SPARK_VERSION}.")
        return f"dataiku-dss-spark-standalone-{v}-{_FALLBACK_SPARK_VERSION}-{spark_flavor}.tar.gz"

    # ── Download or upload ─────────────────────────────────────────────────

    if spark_archive_path:
        def _upload():
            filename = spark_archive_path.split("/")[-1]
            _state["filename"] = filename
            remote_archive = f"{install_dir.rstrip('/')}/{filename}"
            ui.log(f"Uploading Spark standalone archive to {remote_archive}.")
            ex.upload_file(spark_archive_path, remote_archive, use_sudo=True)

        steps.append(Step(title="Upload Spark standalone archive", run=_upload))
    else:
        def _download():
            filename = _resolve_filename()
            _state["filename"] = filename
            v = _state["dss_version"]
            remote_archive = f"{install_dir.rstrip('/')}/{filename}"
            ui.log(f"Downloading {filename}.")
            dl = AssetDownloader(ex)
            last_err: str | None = None
            for url in _candidate_urls(v, filename):
                try:
                    dl.download(url, remote_archive, sudo=True)
                    return
                except DownloaderError as e:
                    last_err = str(e)
                    continue
            raise DownloaderError(
                "Failed to download the Dataiku Spark standalone package.\n"
                f"  DSS version: {v}\n"
                f"  Expected filename: {filename}\n"
                "  Tip: check the directory index at:\n"
                f"    https://downloads.dataiku.com/public/dss/{v}/\n"
                f"  Last error: {last_err}"
            )

        steps.append(Step(title="Download Spark standalone package", run=_download))

    # ── Extract ────────────────────────────────────────────────────────────

    def _extract():
        filename = _state["filename"] or (
            spark_archive_path.split("/")[-1] if spark_archive_path else None
        )
        remote_archive = f"{install_dir.rstrip('/')}/{filename}"
        ui.log(f"Extracting Spark standalone package into {spark_home_dir}.")
        check(ex, f"sudo -n mkdir -p {q(spark_home_dir)}")
        # --strip-components=1 extracts the tarball's top-level directory
        # contents directly into spark_home_dir, so spark_home_dir itself
        # becomes the Spark home (e.g. contains bin/spark-submit).
        check(ex, f"sudo -n tar xzf {q(remote_archive)} -C {q(spark_home_dir)} --strip-components=1")
        ui.log(f"Spark home: {spark_home_dir}")

    steps.append(Step(title="Extract Spark standalone package", run=_extract))

    # ── Install via dssadmin ───────────────────────────────────────────────

    def _install():
        dss_stop(ex, ui, os_user, data_dir)
        cmd = f"{data_dir}/bin/dssadmin install-spark-integration -sparkHome {q(spark_home_dir)}"
        ui.log("Running dssadmin install-spark-integration.")
        check(ex, f"sudo -n -u {q(os_user)} -i -- sh -c {q(cmd)}")
        dss_start(ex, ui, os_user, data_dir)

    steps.append(Step(title="Install Spark integration", run=_install))
    return steps
