from __future__ import annotations

from dataclasses import dataclass
from urllib.parse import urlparse


@dataclass(frozen=True)
class NexusInstallPlan:
    """Plan inputs for installing Sonatype Nexus Repository Manager 3.x."""

    version: str
    install_dir: str
    data_dir: str
    os_user: str
    java_package: str
    http_port: int
    verify_checksum: bool = True
    docker_repo_enabled: bool = False
    docker_repo_name: str = "dataiku"
    docker_repo_routing: str = "path"

    @property
    def archive_urls(self) -> list[str]:
        """Return candidate archive URLs for this version.

        Sonatype has used multiple naming schemes over time, e.g.
        - nexus-<ver>-unix.tar.gz
        - nexus-<ver>-linux-x86_64.tar.gz

        k4s will try these in order.
        """
        base = f"https://download.sonatype.com/nexus/3/nexus-{self.version}"
        return [
            f"{base}-unix.tar.gz",
            f"{base}-linux-x86_64.tar.gz",
        ]

    @property
    def archive_sha256_urls(self) -> list[str]:
        return [f"{u}.sha256" for u in self.archive_urls]

    @property
    def archive_filenames(self) -> list[str]:
        return [urlparse(u).path.split("/")[-1] for u in self.archive_urls]

