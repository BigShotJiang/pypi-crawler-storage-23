"""Datafloem upgrade recipe (helm upgrade)."""

from __future__ import annotations

import shlex

from k4s.core.executor import Executor, ExecutorError
from k4s.core.products import Step
from k4s.recipes.common.helm import (
    force_delete_pods,
    postcheck_pods,
    release_exists,
    snapshot_release_pods,
    wait_for_rollout,
)
from k4s.recipes.common.run import check
from k4s.recipes.datafloem.install import build_common_steps, build_helm_value_args
from k4s.recipes.datafloem.model import DatafloemInstallPlan
from k4s.ui.ui import Ui


def build_upgrade_steps(
    ui: Ui, ex: Executor, plan: DatafloemInstallPlan, *, force: bool = False,
) -> list[Step]:
    """Build Datafloem upgrade steps using ``helm upgrade``.

    ``helm upgrade`` runs without ``--wait``. Readiness is verified via
    ``kubectl rollout status``.

    With *force*, pre-upgrade pods are force-deleted before the rollout wait.
    """
    steps = build_common_steps(ui, ex, plan, is_upgrade=True)

    _pre_upgrade_pods: list[str] = []

    def _upgrade():
        if not release_exists(ex, plan):
            raise ExecutorError(
                f"Helm release '{plan.release_name}' not found in namespace '{plan.namespace}'.\n"
                "Install first with `k4s install datafloem`."
            )

        if force:
            _pre_upgrade_pods.extend(snapshot_release_pods(ui, ex, plan))

        chart_ref = f"{plan.repo_name}/{plan.chart_name}"
        ui.log("Running helm upgrade for Datafloem")
        cmd_parts: list[str] = [
            "helm",
            "upgrade",
            plan.release_name,
            chart_ref,
            "--namespace",
            plan.namespace,
        ] + plan.helm_flags() + build_helm_value_args(plan)

        cmd = " ".join(shlex.quote(p) for p in cmd_parts)
        check(ex, cmd)

    steps.append(Step(title=f"Upgrade Datafloem release '{plan.release_name}'", run=_upgrade))
    if force:
        steps.append(Step(
            title="Delete pods now (best-effort)",
            run=lambda: force_delete_pods(ui, ex, plan, _pre_upgrade_pods),
        ))
    steps.append(Step(title="Wait for rollout to complete", run=lambda: wait_for_rollout(ui, ex, plan)))
    steps.append(Step(title="Post-check (pods)", run=lambda: postcheck_pods(ui, ex, plan)))
    return steps

