"""Shared context resolution logic for CLI commands."""
from __future__ import annotations

import os
import time
from typing import Optional

from k4s.cli.state import CliState
from k4s.core.context_store import Context


def context_label(c: Context) -> str:
    """Build a human-readable label for a context.

    VM contexts show the host, k8s contexts show namespace or
    kubectl-context.  Always includes a parenthetical detail so the
    user can immediately identify what the context points to.
    """
    if c.type == "vm":
        detail = c.host or "no host"
    else:
        detail = c.namespace or "none"
    return f"{c.name}({detail})"


_COUNTDOWN_SECONDS = 3


def _context_countdown(state: CliState) -> None:
    """Show a brief countdown after the context line so users can abort if wrong.

    Skipped when ``-y/--yes`` is passed globally or ``K4S_YES=1`` is set in the
    environment.  The countdown is rendered in-place on a single line; pressing
    Ctrl+C aborts cleanly.
    """
    if state.yes or os.environ.get("K4S_YES"):
        return

    console = state.ui.console
    max_len = 0
    try:
        for remaining in range(_COUNTDOWN_SECONDS, 0, -1):
            line = f"  Proceeding in {remaining}s... (Ctrl+C to abort)"
            max_len = max(max_len, len(line))
            console.print(line, end="\r", highlight=False, markup=False)
            time.sleep(1)
    except KeyboardInterrupt:
        # Clear the countdown line before letting Click print "Aborted!".
        console.print(" " * max_len, end="\r", highlight=False, markup=False)
        raise
    # Clear the countdown line — it served its purpose.
    console.print(" " * max_len, end="\r", highlight=False, markup=False)


def _show_context(state: CliState, c: Context) -> None:
    """Print the resolved context name once per invocation, then count down."""
    if getattr(state, "_context_shown", False):
        return
    state.ui.info(f"Context: {context_label(c)}")
    _context_countdown(state)
    state.ui.info("")
    object.__setattr__(state, "_context_shown", True)


def resolve_target(state: CliState, context_name: Optional[str]) -> Context:
    """Resolve a context name to a VM Context object.

    - ``'local'`` is a built-in shortcut for localhost execution.
    - ``None`` falls back to the current context (set via ``k4s context use-context``
      or ``k4s context add ... --current``).

    Raises ValueError if the resolved context is not a VM context.
    """
    if context_name and context_name.lower() == "local":
        local = Context(name="local", host="localhost")
        _show_context(state, local)
        return local

    # state.contexts.resolve(None) returns the current context.
    c = state.contexts.resolve(context_name)
    if c.type != "vm":
        raise ValueError(
            f"Context '{c.name}' is type '{c.type}', but this command requires a 'vm' context.\n"
            "  Add one:  k4s context add <name> --host <ip> --username <user> -i <key>"
        )
    if not c.host:
        raise ValueError(f"Context '{c.name}' has no host configured.")
    _show_context(state, c)
    return c


def resolve_k8s_target(state: CliState, context_name: Optional[str]) -> Context:
    """Resolve a context name to a Kubernetes Context, validating type.

    Returns the resolved Context with a guaranteed kubeconfig path (either
    explicitly set or derived from ``~/.kube/config`` when only
    ``kubectl_context`` is provided).

    Raises ValueError if the resolved context is not a k8s context or has no
    kubeconfig/kubectl-context configured.
    """
    c = state.contexts.resolve(context_name)
    if c.type != "k8s":
        raise ValueError(
            f"Context '{c.name}' is type '{c.type}', but this command requires a 'k8s' context.\n"
            "  Add one:  k4s context add <name> --type k8s --kubeconfig <path>\n"
            "  Or set:   k4s context use-context <k8s-context-name>"
        )
    if not c.kubeconfig and not c.kubectl_context:
        raise ValueError(f"K8s context '{c.name}' has no kubeconfig or kubectl-context configured.")
    _show_context(state, c)
    return c


def kubeconfig_path_for(c: Context) -> str:
    """Return the effective kubeconfig file path for a k8s context.

    If the context specifies an explicit ``kubeconfig`` path, that is used.
    Otherwise falls back to ``~/.kube/config`` (the kubectl default).
    """
    if c.kubeconfig:
        return c.kubeconfig
    return os.path.expanduser("~/.kube/config")
