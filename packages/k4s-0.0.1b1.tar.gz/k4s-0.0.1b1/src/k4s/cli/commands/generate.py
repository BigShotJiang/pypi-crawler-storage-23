"""CLI commands for generating configuration files (k4s generate ...)."""

from __future__ import annotations

import os
from pathlib import Path

import click

from k4s.cli.state import CliState


class OrderedGenerateGroup(click.Group):
    """Generate subgroup with stable command order in --help."""

    def list_commands(self, ctx):
        return list(self.commands)


@click.group(cls=OrderedGenerateGroup)
@click.pass_context
def generate(ctx):
    """Generate configuration files and templates."""
    pass


# ---------------------------------------------------------------------------
# k4s generate values ...
# ---------------------------------------------------------------------------


class OrderedValuesGroup(click.Group):
    _order = ["starburst", "hive", "ranger", "cache", "datafloem"]

    def list_commands(self, ctx):
        names = list(self.commands)
        ordered = [c for c in self._order if c in self.commands]
        rest = [c for c in names if c not in ordered]
        return ordered + rest


@generate.group("values", cls=OrderedValuesGroup)
@click.pass_context
def values(ctx):
    """Generate Helm values file templates for supported products."""
    pass


@values.command("starburst")
@click.option(
    "--output", "-o",
    type=click.Path(dir_okay=False),
    default=None,
    help="Output file path (default: ~/.k4s/values/starburst-values.yaml).",
)
@click.option(
    "--profile",
    type=click.Choice(["basic", "production"], case_sensitive=False),
    default="basic",
    show_default=True,
    help="Template profile.",
)
@click.option("--force", is_flag=True, help="Overwrite existing file without asking.")
@click.pass_context
def starburst(ctx, output: str | None, profile: str, force: bool):
    """Generate a Starburst Enterprise Helm values template."""
    from k4s.recipes.starburst.template import render

    state: CliState = ctx.obj["state"]
    ui = state.ui

    if output is None:
        base = Path(os.path.expanduser("~/.k4s/values"))
        output_path = base / "starburst-values.yaml"
    else:
        output_path = Path(output)

    if output_path.exists() and not force:
        overwrite = click.prompt(
            f"File already exists: {output_path}\nOverwrite?",
            type=click.Choice(["y", "n"], case_sensitive=False),
            default="n",
        )
        if overwrite.lower() != "y":
            ui.info("Aborted.")
            ctx.exit(0)
            return

    output_path.parent.mkdir(parents=True, exist_ok=True)
    content = render(profile=profile)
    output_path.write_text(content, encoding="utf-8")

    ui.success(f"Generated Starburst values file ({profile}): {output_path}")
    ui.info("")
    ui.info("Next steps:")
    ui.info("  1. Edit the file and replace all CHANGE_ME placeholders")
    ui.info(f"  2. Validate: k4s validate values {output_path}")
    ui.info(f"  3. Install:  k4s install starburst --chart-version <ver> --values-file {output_path}")
