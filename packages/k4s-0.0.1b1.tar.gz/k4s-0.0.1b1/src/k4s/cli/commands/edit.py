"""CLI commands for editing configuration files (k4s edit ...)."""

from __future__ import annotations

import os
import shlex
import subprocess
import traceback
from pathlib import Path

import click

from k4s.cli.state import CliState
from k4s.core.validate import product_label, validate_values


class OrderedEditGroup(click.Group):
    def list_commands(self, ctx):
        return list(self.commands)


@click.group(cls=OrderedEditGroup)
@click.pass_context
def edit(ctx):
    """Edit configuration files."""
    pass


@edit.command("values")
@click.argument("target", required=False, default=None)
@click.option("--context", "context_name", default=None, help="Context name. Uses current context if omitted.")
@click.option("--no-validate", is_flag=True, help="Skip validation after saving (or set K4S_NO_VALIDATE=1).")
@click.pass_context
def values(ctx, target: str | None, context_name: str | None, no_validate: bool):
    """Open a Helm values file in your editor and validate on save.

    TARGET is a file path. If omitted, opens the last values file
    used in the current context (from history).

    \b
    Editor selection (first match wins):
      $K4S_EDITOR  →  $VISUAL  →  $EDITOR  →  vi

    \b
    Examples:
      k4s edit values                          # open last used values file
      k4s edit values /path/to/values.yaml     # open specific file
      export EDITOR=nano                       # use nano for this session
      export EDITOR="code --wait"              # use VS Code (--wait is required)

    \b
    To disable validation permanently:
      export K4S_NO_VALIDATE=1
    """
    state: CliState = ctx.obj["state"]
    ui = state.ui

    if not no_validate and os.environ.get("K4S_NO_VALIDATE", "").strip() in ("1", "true", "yes"):
        no_validate = True

    ctx_name = context_name or state.contexts.get_current_name()

    if target is None:
        last = state.history.last_values_file(context=ctx_name)
        if not last:
            msg = "No values file found in history"
            if ctx_name:
                msg += f" for context '{ctx_name}'"
            ui.error(f"{msg}.")
            ui.info("  Specify a file path: k4s edit values /path/to/values.yaml")
            ctx.exit(2)
            return
        path = Path(last)
    else:
        path = Path(target)

    if not path.exists():
        ui.error(f"File not found: {path}")
        ctx.exit(2)
        return

    product: str | None = None

    editor = (
        os.environ.get("K4S_EDITOR")
        or os.environ.get("VISUAL")
        or os.environ.get("EDITOR")
        or "vi"
    )

    try:
        abs_path = str(Path(path).resolve())
        editor_cmd = shlex.split(editor) + [abs_path]
        if target is None:
            ctx_part = ctx_name or "none"
            ui.info(f"Opening {abs_path} (resolved from {ctx_part} context history)")
        else:
            ui.info(f"Opening {abs_path}")
        rc = subprocess.call(editor_cmd)
        if rc != 0:
            ui.error(f"Editor exited with code {rc}")
            ctx.exit(rc)
            return

        state.history.append(
            action="edit",
            product="values",
            context=ctx_name,
            params={"values_files": [abs_path]},
        )

        if no_validate:
            return

        ui.info("")
        ui.info("Running validation...")
        ui.info("")
        result = validate_values(path, product=product)

        if result.product:
            ui.info(f"Detected product: {product_label(result.product)}")
            ui.info("")

        from k4s.cli.commands.validate import _print_findings

        _print_findings(ui, result)

        if result.ok:
            resolved_product = product or result.product
            ui.info("")
            if resolved_product:
                ui.info("To apply changes:")
                ui.info(
                    f"  k4s upgrade {resolved_product} --chart-version <ver> --values-file {path}"
                )
            else:
                ui.info("To apply changes:")
                ui.info(f"  k4s install <product> --values-file {path}")
    except Exception as e:
        ui.error(str(e))
        ui.console.print(f"[dim]{traceback.format_exc()}[/dim]")
        ctx.exit(1)
