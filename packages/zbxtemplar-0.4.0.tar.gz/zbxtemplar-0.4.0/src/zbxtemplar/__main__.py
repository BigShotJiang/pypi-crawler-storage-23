from zbxtemplar.main import main

raise SystemExit(main())