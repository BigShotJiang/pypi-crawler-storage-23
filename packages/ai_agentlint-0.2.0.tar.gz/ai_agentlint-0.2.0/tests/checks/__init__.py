"""Check tests package."""
