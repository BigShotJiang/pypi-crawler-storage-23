"""Allow running with `python -m infershrink`."""
from infershrink.cli import main

main()
