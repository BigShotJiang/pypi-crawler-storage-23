"""SDK wrapper — the core of InferShrink's one-line integration.

Usage::

    import openai
    from infershrink import optimize

    client = optimize(openai.Client())
    # All chat.completions.create() calls now go through InferShrink
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from .classifier import classify
from .compressor import compress
from .config import build_config
from .router import route
from .tracker import Tracker
from .types import Config


class _InferShrinkCompletionProxy:
    """Proxy for ``client.chat.completions`` that intercepts ``create()``."""

    def __init__(
        self,
        original_completions: Any,
        config: Dict[str, Any],
        tracker: Tracker,
    ) -> None:
        self._original = original_completions
        self._config = config
        self._tracker = tracker

    def create(self, **kwargs: Any) -> Any:
        """Intercept chat.completions.create() to compress + route."""
        messages = kwargs.get("messages", [])
        original_model = kwargs.get("model", "gpt-4o")

        # 1. Classify
        classification = classify(messages)

        # 2. Compress
        compression = compress(messages, classification.complexity, self._config)

        # 3. Route
        routing = route(original_model, classification.complexity, self._config)

        # 4. Build the modified kwargs
        modified_kwargs = dict(kwargs)
        modified_kwargs["messages"] = compression.messages
        modified_kwargs["model"] = routing.routed_model

        # 5. Track
        if self._config.get("cost_tracking", True):
            self._tracker.record(
                original_model=original_model,
                routed_model=routing.routed_model,
                original_tokens=compression.original_tokens,
                compressed_tokens=compression.compressed_tokens,
                complexity=classification.complexity,
            )

        # 6. Call the real API
        return self._original.create(**modified_kwargs)

    def __getattr__(self, name: str) -> Any:
        """Forward all other attribute access to the original completions object."""
        return getattr(self._original, name)


class _InferShrinkChatProxy:
    """Proxy for ``client.chat`` that replaces ``.completions``."""

    def __init__(
        self,
        original_chat: Any,
        config: Dict[str, Any],
        tracker: Tracker,
    ) -> None:
        self._original = original_chat
        self._config = config
        self._tracker = tracker
        self.completions = _InferShrinkCompletionProxy(
            original_chat.completions, config, tracker
        )

    def __getattr__(self, name: str) -> Any:
        if name == "completions":
            return self.completions
        return getattr(self._original, name)


class _InferShrinkAnthropicProxy:
    """Proxy for Anthropic client that intercepts messages.create()."""

    def __init__(
        self,
        original_client: Any,
        config: Dict[str, Any],
        tracker: Tracker,
    ) -> None:
        self._original = original_client
        self._config = config
        self._tracker = tracker
        self.messages = _AnthropicMessagesProxy(
            original_client.messages, config, tracker
        )

    @property
    def infershrink_tracker(self) -> Tracker:
        return self._tracker

    def __getattr__(self, name: str) -> Any:
        if name == "messages":
            return self.messages
        return getattr(self._original, name)


class _AnthropicMessagesProxy:
    """Proxy for ``client.messages`` on Anthropic clients."""

    def __init__(
        self,
        original_messages: Any,
        config: Dict[str, Any],
        tracker: Tracker,
    ) -> None:
        self._original = original_messages
        self._config = config
        self._tracker = tracker

    def create(self, **kwargs: Any) -> Any:
        """Intercept messages.create() for Anthropic clients."""
        messages = kwargs.get("messages", [])
        original_model = kwargs.get("model", "claude-sonnet-4-20250514")

        # Anthropic puts system prompt separately
        system = kwargs.get("system", "")
        # Build combined messages for classification
        classify_messages = []
        if system:
            if isinstance(system, str):
                classify_messages.append({"role": "system", "content": system})
            elif isinstance(system, list):
                classify_messages.append({"role": "system", "content": " ".join(
                    p.get("text", "") if isinstance(p, dict) else str(p) for p in system
                )})
        classify_messages.extend(messages)

        # 1. Classify
        classification = classify(classify_messages)

        # 2. Compress (only the messages, not system)
        compression = compress(messages, classification.complexity, self._config)

        # 3. Route
        routing = route(original_model, classification.complexity, self._config)

        # 4. Build modified kwargs
        modified_kwargs = dict(kwargs)
        modified_kwargs["messages"] = compression.messages
        modified_kwargs["model"] = routing.routed_model

        # 5. Track
        if self._config.get("cost_tracking", True):
            self._tracker.record(
                original_model=original_model,
                routed_model=routing.routed_model,
                original_tokens=compression.original_tokens,
                compressed_tokens=compression.compressed_tokens,
                complexity=classification.complexity,
            )

        # 6. Call the real API
        return self._original.create(**modified_kwargs)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class InferShrinkClient:
    """Wrapped OpenAI client with InferShrink optimizations.

    Behaves exactly like the original client, but ``chat.completions.create()``
    calls are intercepted for compression and routing.
    """

    def __init__(
        self,
        original_client: Any,
        config: Dict[str, Any],
        tracker: Tracker,
    ) -> None:
        self._original = original_client
        self._config = config
        self._tracker = tracker
        self.chat = _InferShrinkChatProxy(
            original_client.chat, config, tracker
        )

    @property
    def infershrink_tracker(self) -> Tracker:
        """Access the cost tracker for this client."""
        return self._tracker

    def __getattr__(self, name: str) -> Any:
        """Forward everything else to the original client."""
        if name == "chat":
            return self.chat
        return getattr(self._original, name)


def _detect_client_type(client: Any) -> str:
    """Detect whether client is OpenAI-like or Anthropic-like."""
    client_type = type(client).__module__ or ""
    client_class = type(client).__name__ or ""

    if "anthropic" in client_type.lower() or "anthropic" in client_class.lower():
        return "anthropic"

    # Check for chat.completions pattern (OpenAI)
    if hasattr(client, "chat") and hasattr(getattr(client, "chat", None), "completions"):
        return "openai"

    # Check for messages pattern (Anthropic)
    if hasattr(client, "messages") and hasattr(getattr(client, "messages", None), "create"):
        return "anthropic"

    # Default to openai-compatible
    return "openai"


def optimize(
    client: Any,
    config: Optional[Config] = None,
) -> Any:
    """Wrap an LLM client with InferShrink optimizations.

    This is the main entry point — one line to cut your LLM costs.

    Parameters
    ----------
    client:
        An OpenAI or Anthropic client instance.
    config:
        Optional configuration overrides. Merged with defaults.

    Returns
    -------
    A wrapped client that transparently compresses prompts and routes
    to cheaper models when possible.

    Examples
    --------
    >>> import openai
    >>> from infershrink import optimize
    >>> client = optimize(openai.Client())
    >>> # Now use client.chat.completions.create() as usual
    """
    effective_config = build_config(config)
    tracker = Tracker(effective_config)
    client_type = _detect_client_type(client)

    if client_type == "anthropic":
        return _InferShrinkAnthropicProxy(client, effective_config, tracker)

    return InferShrinkClient(client, effective_config, tracker)
