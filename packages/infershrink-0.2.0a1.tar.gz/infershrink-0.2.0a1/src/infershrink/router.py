"""Model router — picks the cheapest model that meets the quality floor."""

from __future__ import annotations

from typing import Any, Dict

from .config import COMPLEXITY_TO_TIER
from .types import Complexity, RoutingDecision


# Ordered from cheapest to most expensive
_TIER_ORDER = ["tier1", "tier2", "tier3"]


def _tier_index(tier_name: str) -> int:
    try:
        return _TIER_ORDER.index(tier_name)
    except ValueError:
        return len(_TIER_ORDER)


def _find_tier_for_model(model: str, tiers: Dict[str, Any]) -> str | None:
    """Return the tier name that lists *model*, or None."""
    for tier_name, tier_cfg in tiers.items():
        if model in tier_cfg.get("models", []):
            return tier_name
    return None


def route(
    original_model: str,
    complexity: Complexity,
    config: Dict[str, Any],
) -> RoutingDecision:
    """Determine which model to actually use.

    Parameters
    ----------
    original_model:
        The model the caller originally requested.
    complexity:
        Classified complexity of the task.
    config:
        The full InferShrink configuration dict.

    Returns
    -------
    RoutingDecision
    """
    tiers = config.get("tiers", {})

    # Which tier does this complexity map to?
    target_tier_name = COMPLEXITY_TO_TIER.get(complexity.value, "tier3")
    target_tier = tiers.get(target_tier_name, {})

    # Which tier is the original model in?
    original_tier_name = _find_tier_for_model(original_model, tiers)

    # If the original model isn't in any known tier, keep it for COMPLEX/SECURITY
    if original_tier_name is None:
        if complexity in (Complexity.SECURITY_CRITICAL, Complexity.COMPLEX):
            return RoutingDecision(
                original_model=original_model,
                routed_model=original_model,
                complexity=complexity,
            )
        # For simpler tasks, still try to route to a cheaper model
        target_models = target_tier.get("models", [])
        routed = target_models[0] if target_models else original_model
        return RoutingDecision(
            original_model=original_model,
            routed_model=routed,
            complexity=complexity,
            was_downgraded=target_models and target_models[0] != original_model,
        )

    original_tier_idx = _tier_index(original_tier_name)
    target_tier_idx = _tier_index(target_tier_name)

    # Never upgrade beyond what the user asked for
    # (i.e., if they asked for tier1, don't push to tier3)
    # But we CAN downgrade if the task is simpler than the model

    if target_tier_idx < original_tier_idx:
        # Task is simpler than the requested model → downgrade
        target_models = target_tier.get("models", [])
        routed = target_models[0] if target_models else original_model
        return RoutingDecision(
            original_model=original_model,
            routed_model=routed,
            complexity=complexity,
            was_downgraded=bool(target_models),
        )

    if target_tier_idx > original_tier_idx:
        # Task is more complex than the requested model → keep original
        # (we don't silently upgrade to avoid cost surprises)
        return RoutingDecision(
            original_model=original_model,
            routed_model=original_model,
            complexity=complexity,
            was_upgraded=False,
        )

    # Same tier — keep the original model
    return RoutingDecision(
        original_model=original_model,
        routed_model=original_model,
        complexity=complexity,
    )
