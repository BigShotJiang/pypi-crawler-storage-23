"""InferShrink — Cost Tracking Example.

Shows how to monitor savings across multiple requests.
"""

import openai
from infershrink import optimize

client = optimize(openai.Client())

# Simulate a batch of requests with varying complexity
requests = [
    # Simple questions → routed to cheap models
    {"model": "gpt-4o", "messages": [{"role": "user", "content": "What is 2+2?"}]},
    {"model": "gpt-4o", "messages": [{"role": "user", "content": "Hello!"}]},
    {"model": "gpt-4o", "messages": [{"role": "user", "content": "What day is it?"}]},
    # Moderate task → might stay on gpt-4o
    {
        "model": "gpt-4o",
        "messages": [
            {
                "role": "user",
                "content": "Summarize the key differences between Python and JavaScript in a table format with code examples.",
            }
        ],
    },
    # Complex task → stays on the requested model
    {
        "model": "gpt-4o",
        "messages": [
            {
                "role": "user",
                "content": (
                    "Write a detailed step by step guide to building a REST API "
                    "with authentication, rate limiting, and database integration. "
                    "Include code examples for each component."
                ),
            }
        ],
    },
]

print("Running requests...\n")

for i, req in enumerate(requests, 1):
    try:
        response = client.chat.completions.create(**req)
        print(f"Request {i}: OK")
    except Exception as e:
        # In this example we might not have a real API key
        print(f"Request {i}: {type(e).__name__} (expected without API key)")

# Show detailed stats
print("\n" + client.infershrink_tracker.summary())

# Programmatic access to stats
stats = client.infershrink_tracker.stats()
print(f"\nProgrammatic access:")
print(f"  Total requests:  {stats.total_requests}")
print(f"  Tokens saved:    {stats.total_tokens_saved:,}")
print(f"  Estimated saved: ${stats.total_estimated_savings_usd:.4f}")
print(f"  Downgraded:      {stats.requests_downgraded}/{stats.total_requests}")

# Individual request records
if stats.records:
    print(f"\nPer-request breakdown:")
    for i, record in enumerate(stats.records, 1):
        print(
            f"  {i}. {record.original_model} → {record.routed_model} "
            f"({record.complexity.value}) "
            f"saved ${record.savings:.4f}"
        )

# Reset tracking for a new session
client.infershrink_tracker.reset()
print(f"\nAfter reset: {client.infershrink_tracker.stats().total_requests} requests tracked")
