"""InferShrink — Basic Usage Example.

The simplest possible integration: one line to optimize your LLM costs.
"""

import openai
from infershrink import optimize

# Wrap your client — that's it!
client = optimize(openai.Client())

# Use it exactly as before
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "What is the capital of France?"}],
)

print(response.choices[0].message.content)

# This simple question was automatically routed to gpt-4o-mini,
# saving you ~95% on this request.
#
# Check your savings:
print(client.infershrink_tracker.summary())
