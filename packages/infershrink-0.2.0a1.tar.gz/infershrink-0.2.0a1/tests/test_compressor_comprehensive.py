"""Comprehensive compressor tests — mock tokenshrink, edge cases, graceful degradation."""

import copy
import pytest
from unittest.mock import patch, MagicMock

from infershrink.compressor import compress, is_tokenshrink_available, _estimate_tokens
from infershrink.config import build_config
from infershrink.types import Complexity


class TestCompressorEdgeCases:
    """Edge cases and boundary conditions."""

    def test_empty_messages_list(self):
        config = build_config()
        result = compress([], Complexity.SIMPLE, config)
        assert result.messages == []
        assert result.original_tokens == 0
        assert result.compressed_tokens == 0
        assert result.compression_ratio == 1.0
        assert result.was_compressed is False

    def test_message_with_empty_content(self):
        config = build_config()
        messages = [{"role": "user", "content": ""}]
        result = compress(messages, Complexity.SIMPLE, config)
        assert result.original_tokens >= 0

    def test_message_with_none_content(self):
        """Content=None is common for tool_calls messages."""
        config = build_config()
        messages = [{"role": "assistant", "content": None}]
        result = compress(messages, Complexity.SIMPLE, config)
        assert result.original_tokens == 0

    def test_message_missing_content_key(self):
        config = build_config()
        messages = [{"role": "user"}]
        result = compress(messages, Complexity.SIMPLE, config)
        # _estimate_tokens("") returns 1 (minimum), so empty content = 1 token
        assert result.original_tokens >= 0

    def test_does_not_mutate_input(self):
        config = build_config()
        messages = [
            {"role": "system", "content": "System prompt"},
            {"role": "user", "content": "Hello world"},
        ]
        original = copy.deepcopy(messages)
        compress(messages, Complexity.SIMPLE, config)
        assert messages == original

    def test_multipart_content_with_image(self):
        config = build_config()
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Describe this image"},
                    {"type": "image_url", "image_url": {"url": "https://example.com/img.png"}},
                ],
            }
        ]
        result = compress(messages, Complexity.SIMPLE, config)
        assert result.original_tokens > 0
        # Image URL part should not count as tokens (no text)
        # Only the text part should contribute

    def test_multipart_content_strings_in_list(self):
        config = build_config()
        messages = [
            {
                "role": "user",
                "content": ["Hello", "World"],
            }
        ]
        result = compress(messages, Complexity.SIMPLE, config)
        assert result.original_tokens > 0

    def test_many_messages(self):
        config = build_config()
        messages = [{"role": "user", "content": f"Message {i}"} for i in range(100)]
        result = compress(messages, Complexity.SIMPLE, config)
        assert len(result.messages) == 100

    def test_mixed_roles(self):
        config = build_config()
        messages = [
            {"role": "system", "content": "Be helpful"},
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi!"},
            {"role": "user", "content": "Thanks"},
            {"role": "tool", "content": '{"result": 42}', "tool_call_id": "1"},
        ]
        result = compress(messages, Complexity.SIMPLE, config)
        assert len(result.messages) == 5


class TestCompressionDecisionLogic:
    """Test when compression is triggered vs skipped."""

    def test_skips_for_each_skip_complexity(self):
        """Test that each complexity in skip_for list is respected."""
        config = build_config({
            "compression": {"skip_for": ["SECURITY_CRITICAL", "COMPLEX"]}
        })
        long_text = "word " * 1000
        messages = [{"role": "user", "content": long_text}]

        for complexity_val in ["SECURITY_CRITICAL", "COMPLEX"]:
            complexity = Complexity(complexity_val)
            result = compress(messages, complexity, config)
            assert result.was_compressed is False

    def test_does_not_skip_for_unlisted_complexity(self):
        """Compression should try for complexities NOT in skip_for."""
        config = build_config({
            "compression": {"skip_for": ["SECURITY_CRITICAL"]}
        })
        long_text = "word " * 1000
        messages = [{"role": "user", "content": long_text}]
        result = compress(messages, Complexity.MODERATE, config)
        # Won't actually compress without tokenshrink, but should attempt
        # (was_compressed depends on tokenshrink availability)
        if is_tokenshrink_available():
            assert result.was_compressed is True
        else:
            assert result.was_compressed is False  # graceful degradation

    def test_min_tokens_threshold(self):
        config = build_config({"compression": {"min_tokens": 10000}})
        messages = [{"role": "user", "content": "word " * 200}]  # ~200 tokens
        result = compress(messages, Complexity.MODERATE, config)
        assert result.was_compressed is False

    def test_low_min_tokens_threshold(self):
        config = build_config({"compression": {"min_tokens": 5}})
        messages = [{"role": "user", "content": "This has enough tokens to compress"}]
        result = compress(messages, Complexity.MODERATE, config)
        # Whether compressed depends on tokenshrink availability
        if not is_tokenshrink_available():
            assert result.was_compressed is False

    def test_empty_skip_for_list(self):
        """No complexities to skip → always try to compress."""
        config = build_config({"compression": {"skip_for": []}})
        long_text = "word " * 1000
        messages = [{"role": "user", "content": long_text}]
        result = compress(messages, Complexity.SECURITY_CRITICAL, config)
        # Should try to compress even SECURITY_CRITICAL when not in skip_for
        # (won't actually compress without tokenshrink)
        if is_tokenshrink_available():
            assert result.was_compressed is True


class TestCompressionWithMockedTokenShrink:
    """Test compression behavior by mocking tokenshrink."""

    def test_compresses_user_messages(self):
        """When tokenshrink is available, user messages get compressed."""
        long_text = "This is verbose text that should be compressed. " * 50

        with patch("infershrink.compressor._tokenshrink_available", True), \
             patch("infershrink.compressor._compress_fn", return_value="compressed text"):
            config = build_config({"compression": {"min_tokens": 10}})
            messages = [{"role": "user", "content": long_text}]
            result = compress(messages, Complexity.MODERATE, config)
            assert result.was_compressed is True
            assert result.messages[0]["content"] == "compressed text"

    def test_preserves_system_messages_during_compression(self):
        """System messages should never be compressed."""
        system_content = "You are a helpful assistant with specific instructions."
        long_text = "Verbose user message. " * 50

        with patch("infershrink.compressor._tokenshrink_available", True), \
             patch("infershrink.compressor._compress_fn", return_value="compressed"):
            config = build_config({"compression": {"min_tokens": 10}})
            messages = [
                {"role": "system", "content": system_content},
                {"role": "user", "content": long_text},
            ]
            result = compress(messages, Complexity.MODERATE, config)
            assert result.was_compressed is True
            assert result.messages[0]["content"] == system_content  # Preserved!
            assert result.messages[1]["content"] == "compressed"

    def test_compresses_assistant_messages(self):
        """Assistant messages in history should also be compressed."""
        long_text = "Verbose response. " * 50

        with patch("infershrink.compressor._tokenshrink_available", True), \
             patch("infershrink.compressor._compress_fn", return_value="compressed"):
            config = build_config({"compression": {"min_tokens": 10}})
            messages = [
                {"role": "assistant", "content": long_text},
            ]
            result = compress(messages, Complexity.MODERATE, config)
            assert result.messages[0]["content"] == "compressed"

    def test_compresses_multipart_text_blocks(self):
        """Multipart content text blocks should be compressed."""
        with patch("infershrink.compressor._tokenshrink_available", True), \
             patch("infershrink.compressor._compress_fn", return_value="short"):
            config = build_config({"compression": {"min_tokens": 5}})
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "This is a long text block " * 20},
                        {"type": "image_url", "image_url": {"url": "http://example.com/img.png"}},
                    ],
                }
            ]
            result = compress(messages, Complexity.MODERATE, config)
            assert result.was_compressed is True
            # Text block should be compressed
            assert result.messages[0]["content"][0]["text"] == "short"
            # Image block should be preserved
            assert result.messages[0]["content"][1]["type"] == "image_url"

    def test_compression_ratio_calculated(self):
        """Compression ratio should reflect the actual compression."""
        original = "word " * 500  # ~500 tokens
        compressed = "w " * 250   # ~250 chars -> ~62 tokens

        def mock_compress(text):
            return compressed

        with patch("infershrink.compressor._tokenshrink_available", True), \
             patch("infershrink.compressor._compress_fn", side_effect=mock_compress):
            config = build_config({"compression": {"min_tokens": 10}})
            messages = [{"role": "user", "content": original}]
            result = compress(messages, Complexity.MODERATE, config)
            assert result.was_compressed is True
            assert result.compression_ratio < 1.0
            assert result.compressed_tokens < result.original_tokens


class TestEstimateTokens:
    """Test the internal _estimate_tokens function."""

    def test_empty_string(self):
        assert _estimate_tokens("") == 1  # minimum of 1

    def test_short_string(self):
        assert _estimate_tokens("hi") == 1

    def test_known_length(self):
        assert _estimate_tokens("a" * 400) == 100

    def test_unicode(self):
        # Unicode chars may be multi-byte but the estimate is char-based
        result = _estimate_tokens("こんにちは")
        assert result >= 1


class TestGracefulDegradation:
    """Test that the compressor degrades gracefully without tokenshrink."""

    def test_is_tokenshrink_available_returns_bool(self):
        result = is_tokenshrink_available()
        assert isinstance(result, bool)

    def test_no_crash_without_tokenshrink(self):
        """Full compress call should work fine without tokenshrink."""
        config = build_config()
        messages = [{"role": "user", "content": "word " * 1000}]
        result = compress(messages, Complexity.MODERATE, config)
        # Should not raise, just return uncompressed
        assert result.messages is not None
        assert result.original_tokens > 0
