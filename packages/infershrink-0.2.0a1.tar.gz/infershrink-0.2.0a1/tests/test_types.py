"""Tests for type definitions — dataclasses, enums, defaults."""

import pytest
from dataclasses import fields

from infershrink.types import (
    Complexity,
    ClassificationResult,
    CompressionResult,
    RoutingDecision,
    RequestRecord,
    SessionStats,
)


class TestComplexity:
    def test_has_four_levels(self):
        assert len(Complexity) == 4

    def test_values(self):
        assert Complexity.SIMPLE.value == "SIMPLE"
        assert Complexity.MODERATE.value == "MODERATE"
        assert Complexity.COMPLEX.value == "COMPLEX"
        assert Complexity.SECURITY_CRITICAL.value == "SECURITY_CRITICAL"

    def test_from_string(self):
        assert Complexity("SIMPLE") == Complexity.SIMPLE
        assert Complexity("SECURITY_CRITICAL") == Complexity.SECURITY_CRITICAL

    def test_invalid_raises(self):
        with pytest.raises(ValueError):
            Complexity("INVALID")

    def test_comparison(self):
        """Enum members can be compared for equality."""
        assert Complexity.SIMPLE == Complexity.SIMPLE
        assert Complexity.SIMPLE != Complexity.COMPLEX

    def test_is_hashable(self):
        """Enums should be usable as dict keys."""
        d = {Complexity.SIMPLE: "easy", Complexity.COMPLEX: "hard"}
        assert d[Complexity.SIMPLE] == "easy"


class TestClassificationResult:
    def test_defaults(self):
        r = ClassificationResult(
            complexity=Complexity.SIMPLE,
            reason="test",
        )
        assert r.estimated_tokens == 0
        assert r.signals == {}

    def test_with_all_fields(self):
        r = ClassificationResult(
            complexity=Complexity.COMPLEX,
            reason="many code blocks",
            estimated_tokens=5000,
            signals={"code_blocks": 5},
        )
        assert r.complexity == Complexity.COMPLEX
        assert r.estimated_tokens == 5000
        assert r.signals["code_blocks"] == 5


class TestCompressionResult:
    def test_all_fields(self):
        r = CompressionResult(
            messages=[{"role": "user", "content": "hi"}],
            original_tokens=100,
            compressed_tokens=50,
            compression_ratio=0.5,
            was_compressed=True,
        )
        assert r.was_compressed is True
        assert r.compression_ratio == 0.5
        assert len(r.messages) == 1


class TestRoutingDecision:
    def test_defaults(self):
        r = RoutingDecision(
            original_model="gpt-4o",
            routed_model="gpt-4o-mini",
            complexity=Complexity.SIMPLE,
        )
        assert r.was_downgraded is False
        assert r.was_upgraded is False

    def test_downgraded(self):
        r = RoutingDecision(
            original_model="gpt-4o",
            routed_model="gpt-4o-mini",
            complexity=Complexity.SIMPLE,
            was_downgraded=True,
        )
        assert r.was_downgraded is True


class TestRequestRecord:
    def test_defaults(self):
        r = RequestRecord(
            original_model="gpt-4o",
            routed_model="gpt-4o-mini",
            original_tokens=1000,
            compressed_tokens=800,
            complexity=Complexity.SIMPLE,
        )
        assert r.estimated_cost_original == 0.0
        assert r.estimated_cost_routed == 0.0
        assert r.savings == 0.0

    def test_with_costs(self):
        r = RequestRecord(
            original_model="gpt-4o",
            routed_model="gpt-4o-mini",
            original_tokens=1000,
            compressed_tokens=800,
            complexity=Complexity.SIMPLE,
            estimated_cost_original=0.0025,
            estimated_cost_routed=0.00012,
            savings=0.00238,
        )
        assert r.savings == 0.00238


class TestSessionStats:
    def test_defaults(self):
        s = SessionStats()
        assert s.total_requests == 0
        assert s.total_original_tokens == 0
        assert s.total_compressed_tokens == 0
        assert s.total_tokens_saved == 0
        assert s.total_estimated_savings_usd == 0.0
        assert s.requests_downgraded == 0
        assert s.requests_compressed == 0
        assert s.compression_ratio == 1.0
        assert s.records == []

    def test_records_default_factory(self):
        """Each SessionStats instance should have its own records list."""
        s1 = SessionStats()
        s2 = SessionStats()
        s1.records.append("item")
        assert len(s2.records) == 0  # Should not be shared
