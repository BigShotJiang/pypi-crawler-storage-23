"""Tests for the task complexity classifier."""

import pytest

from infershrink.classifier import classify
from infershrink.types import Complexity


class TestSimpleClassification:
    """Tasks that should be classified as SIMPLE."""

    def test_short_greeting(self):
        messages = [{"role": "user", "content": "Hello!"}]
        result = classify(messages)
        assert result.complexity == Complexity.SIMPLE

    def test_short_question(self):
        messages = [{"role": "user", "content": "What is the capital of France?"}]
        result = classify(messages)
        assert result.complexity == Complexity.SIMPLE

    def test_yes_no_question(self):
        messages = [{"role": "user", "content": "Is Python a programming language?"}]
        result = classify(messages)
        assert result.complexity == Complexity.SIMPLE

    def test_returns_low_token_estimate(self):
        messages = [{"role": "user", "content": "Hi there"}]
        result = classify(messages)
        assert result.estimated_tokens < 500


class TestModerateClassification:
    """Tasks that should be classified as MODERATE."""

    def test_single_code_block(self):
        messages = [
            {
                "role": "user",
                "content": "What does this do?\n```python\nprint('hello')\n```",
            }
        ]
        result = classify(messages)
        assert result.complexity == Complexity.MODERATE

    def test_medium_length_message(self):
        # ~600 tokens worth of text (need enough chars for >500 token estimate at 4 chars/token)
        long_text = "This is a moderately long message that needs to be verbose enough. " * 40
        messages = [{"role": "user", "content": long_text}]
        result = classify(messages)
        assert result.complexity in (Complexity.MODERATE, Complexity.COMPLEX)

    def test_multi_turn_conversation(self):
        messages = [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "Tell me about Python."},
            {"role": "assistant", "content": "Python is a language..."},
            {"role": "user", "content": "How about JavaScript?"},
            {"role": "assistant", "content": "JavaScript is..."},
            {"role": "user", "content": "Which is better for web?"},
        ]
        result = classify(messages)
        assert result.complexity in (Complexity.MODERATE, Complexity.COMPLEX)

    def test_multiple_inline_code(self):
        messages = [
            {
                "role": "user",
                "content": "Compare `map()`, `filter()`, and `reduce()` in Python.",
            }
        ]
        result = classify(messages)
        assert result.complexity == Complexity.MODERATE


class TestComplexClassification:
    """Tasks that should be classified as COMPLEX."""

    def test_many_code_blocks(self):
        code = "```python\nprint('hello')\n```\n"
        messages = [{"role": "user", "content": f"Review this code:\n{code * 4}"}]
        result = classify(messages)
        assert result.complexity == Complexity.COMPLEX

    def test_very_long_prompt(self):
        # > 2000 tokens (need > 8000 chars at 4 chars/token estimate)
        long_text = "Explain this concept in great detail with thorough analysis. " * 200
        messages = [{"role": "user", "content": long_text}]
        result = classify(messages)
        assert result.complexity == Complexity.COMPLEX

    def test_tool_calls_present(self):
        messages = [
            {"role": "user", "content": "What's the weather?"},
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "call_1",
                        "type": "function",
                        "function": {
                            "name": "get_weather",
                            "arguments": '{"city": "Tokyo"}',
                        },
                    }
                ],
            },
        ]
        result = classify(messages)
        assert result.complexity == Complexity.COMPLEX

    def test_step_by_step_keyword(self):
        messages = [
            {"role": "user", "content": "Solve this step by step: what is 15! / 12!?"}
        ]
        result = classify(messages)
        assert result.complexity == Complexity.COMPLEX

    def test_creative_writing_keyword(self):
        messages = [
            {"role": "user", "content": "Write a story about a dragon in Tokyo."}
        ]
        result = classify(messages)
        assert result.complexity == Complexity.COMPLEX

    def test_complex_system_prompt(self):
        # System prompt > 500 tokens
        system = "You are an expert. " * 120
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": "Hi"},
        ]
        result = classify(messages)
        assert result.complexity == Complexity.COMPLEX


class TestSecurityCriticalClassification:
    """Tasks that should be classified as SECURITY_CRITICAL."""

    def test_password_keyword(self):
        messages = [
            {"role": "user", "content": "My password is hunter2, can you store it?"}
        ]
        result = classify(messages)
        assert result.complexity == Complexity.SECURITY_CRITICAL

    def test_api_key_keyword(self):
        messages = [
            {"role": "user", "content": "Here's my api_key: sk-1234567890abcdef"}
        ]
        result = classify(messages)
        assert result.complexity == Complexity.SECURITY_CRITICAL

    def test_credit_card_keyword(self):
        messages = [
            {"role": "user", "content": "My credit card number is 4111-1111-1111-1111"}
        ]
        result = classify(messages)
        assert result.complexity == Complexity.SECURITY_CRITICAL

    def test_explicit_metadata_marker(self):
        messages = [
            {
                "role": "user",
                "content": "Process this data",
                "metadata": {"security_critical": True},
            }
        ]
        result = classify(messages)
        assert result.complexity == Complexity.SECURITY_CRITICAL

    def test_financial_keyword(self):
        messages = [
            {"role": "user", "content": "Analyze this financial report for Q4."}
        ]
        result = classify(messages)
        assert result.complexity == Complexity.SECURITY_CRITICAL


class TestClassificationResult:
    """Test the structure of classification results."""

    def test_has_reason(self):
        messages = [{"role": "user", "content": "Hello"}]
        result = classify(messages)
        assert result.reason
        assert isinstance(result.reason, str)

    def test_has_signals(self):
        messages = [{"role": "user", "content": "Hello"}]
        result = classify(messages)
        assert "estimated_tokens" in result.signals
        assert "code_blocks" in result.signals
        assert "has_tool_calls" in result.signals

    def test_multipart_content(self):
        """Classifier handles multi-part content arrays."""
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "What's in this image?"},
                    {"type": "image_url", "image_url": {"url": "https://example.com/img.png"}},
                ],
            }
        ]
        result = classify(messages)
        assert result.complexity in (Complexity.SIMPLE, Complexity.MODERATE)
