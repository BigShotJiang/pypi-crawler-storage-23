"""Tests for the model router."""

import pytest

from infershrink.config import build_config
from infershrink.router import route
from infershrink.types import Complexity


@pytest.fixture
def config():
    return build_config()


class TestSimpleRouting:
    def test_downgrades_expensive_model_for_simple_task(self, config):
        decision = route("gemini-3-pro-preview", Complexity.SIMPLE, config)
        assert decision.routed_model == "qwen2.5:32b"
        assert decision.was_downgraded is True

    def test_keeps_cheap_model_for_simple_task(self, config):
        decision = route("qwen2.5:32b", Complexity.SIMPLE, config)
        assert decision.routed_model == "qwen2.5:32b"
        assert decision.was_downgraded is False

    def test_downgrades_tier3_for_simple_task(self, config):
        decision = route("claude-opus-4-6", Complexity.SIMPLE, config)
        assert decision.routed_model == "qwen2.5:32b"
        assert decision.was_downgraded is True


class TestModerateRouting:
    def test_downgrades_tier3_to_tier2(self, config):
        decision = route("claude-opus-4-6", Complexity.MODERATE, config)
        assert decision.routed_model == "gemini-3-pro-preview"
        assert decision.was_downgraded is True

    def test_keeps_tier2_for_moderate(self, config):
        decision = route("gemini-3-pro-preview", Complexity.MODERATE, config)
        assert decision.routed_model == "gemini-3-pro-preview"
        assert decision.was_downgraded is False

    def test_does_not_upgrade_tier1_for_moderate(self, config):
        """We don't silently upgrade to avoid cost surprises."""
        decision = route("qwen2.5:32b", Complexity.MODERATE, config)
        assert decision.routed_model == "qwen2.5:32b"
        assert decision.was_upgraded is False


class TestComplexRouting:
    def test_keeps_tier3_for_complex(self, config):
        decision = route("claude-opus-4-6", Complexity.COMPLEX, config)
        assert decision.routed_model == "claude-opus-4-6"

    def test_does_not_upgrade_tier1_for_complex(self, config):
        decision = route("qwen2.5:32b", Complexity.COMPLEX, config)
        assert decision.routed_model == "qwen2.5:32b"


class TestSecurityCriticalRouting:
    def test_keeps_tier3_for_security(self, config):
        decision = route("claude-opus-4-6", Complexity.SECURITY_CRITICAL, config)
        assert decision.routed_model == "claude-opus-4-6"

    def test_keeps_claude_sonnet_for_security(self, config):
        decision = route("claude-sonnet-4-20250514", Complexity.SECURITY_CRITICAL, config)
        assert decision.routed_model == "claude-sonnet-4-20250514"

    def test_never_downgrades_security(self, config):
        """Security critical should never be downgraded, even from tier3."""
        decision = route("claude-opus-4-6", Complexity.SECURITY_CRITICAL, config)
        assert decision.was_downgraded is False


class TestUnknownModel:
    def test_unknown_model_simple_task_gets_routed(self, config):
        decision = route("my-custom-model", Complexity.SIMPLE, config)
        assert decision.routed_model == "qwen2.5:32b"
        assert decision.was_downgraded is True

    def test_unknown_model_complex_task_kept(self, config):
        decision = route("my-custom-model", Complexity.COMPLEX, config)
        assert decision.routed_model == "my-custom-model"

    def test_unknown_model_security_kept(self, config):
        decision = route("my-custom-model", Complexity.SECURITY_CRITICAL, config)
        assert decision.routed_model == "my-custom-model"


class TestCustomConfig:
    def test_custom_tier1_model(self):
        config = build_config({
            "tiers": {
                "tier1": {"models": ["my-cheap-model"], "max_complexity": "SIMPLE"}
            }
        })
        decision = route("claude-opus-4-6", Complexity.SIMPLE, config)
        assert decision.routed_model == "my-cheap-model"

    def test_routing_decision_fields(self, config):
        decision = route("gemini-3-pro-preview", Complexity.SIMPLE, config)
        assert decision.original_model == "gemini-3-pro-preview"
        assert decision.complexity == Complexity.SIMPLE
