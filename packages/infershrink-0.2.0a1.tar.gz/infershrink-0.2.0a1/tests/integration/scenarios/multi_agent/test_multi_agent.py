"""
Multi-Agent Workflow scenario: Multiple agents coordinate on a task.

InferShrink should:
- Classify each agent's step independently
- Route each step to the appropriate model
- Track savings across the entire workflow
- Handle inter-agent context passing
"""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent / "src"))

from infershrink import optimize, classify
from infershrink.types import Complexity


class TestMultiAgentClassification:
    """Test classification across multi-agent workflow steps."""

    def test_each_step_classified_independently(self, classify_fn, multi_agent_workflows):
        """Each step in a workflow should be classified independently.
        Rule-based classifier uses signals (tokens, code, keywords) not semantics."""
        workflow = multi_agent_workflows[0]  # research_to_report
        for step in workflow["steps"]:
            result = classify_fn([{"role": "user", "content": step["prompt"]}])
            # Verify classification succeeds for each step
            assert result.complexity in (
                Complexity.SIMPLE, Complexity.MODERATE,
                Complexity.COMPLEX, Complexity.SECURITY_CRITICAL
            ), f"Agent '{step['agent']}' got invalid complexity"

    def test_code_review_pipeline_with_code(self, classify_fn, multi_agent_workflows):
        """Steps containing code blocks should not be SIMPLE."""
        workflow = multi_agent_workflows[1]  # code_review_pipeline
        code_steps = [s for s in workflow["steps"] if "```" in s["prompt"]]
        for step in code_steps:
            result = classify_fn([{"role": "user", "content": step["prompt"]}])
            assert result.complexity != Complexity.SIMPLE, \
                f"Code review step '{step['agent']}' with code block should not be SIMPLE"


class TestMultiAgentRouting:
    """Test routing across multi-agent workflows."""

    def test_workflow_routes_each_step(self, tracked_client, multi_agent_workflows):
        """Each step should be routed independently."""
        workflow = multi_agent_workflows[0]
        for step in workflow["steps"]:
            tracked_client.chat.completions.create(
                model="claude-opus-4-6",
                messages=[{"role": "user", "content": step["prompt"]}],
            )

        calls = tracked_client.chat.completions.calls
        assert len(calls) == len(workflow["steps"])
        # At least one step should be downgraded (the simple researcher query)
        models = [c.get("model", "") for c in calls]
        has_mini = any("qwen" in m for m in models)
        has_strong = any("qwen" not in m for m in models)
        assert has_mini or has_strong, "Should have mixed routing"

    def test_accumulated_context_handling(self, tracked_client):
        """When later steps include accumulated context from earlier steps."""
        # Step 1: Simple research
        tracked_client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "List 3 benefits of caching."}],
        )

        # Step 2: Writer uses research output (longer context)
        tracked_client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[
                {"role": "system", "content": "You are a technical writer. Use the research below."},
                {"role": "user", "content": """Research findings:
1. Caching reduces latency by serving data from memory
2. Caching reduces database load by 60-80%
3. Caching improves user experience with faster responses

Write a 500-word section about these caching benefits for a technical whitepaper.
Include specific metrics and real-world examples."""},
            ],
        )

        # Step 3: Reviewer checks the output
        tracked_client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[
                {"role": "user", "content": "Review this draft for technical accuracy and suggest edits: [draft text about caching benefits]"},
            ],
        )

        calls = tracked_client.chat.completions.calls
        assert len(calls) == 3
        # Step 1 should be cheapest, steps 2-3 should be same or stronger
        step1_model = calls[0].get("model", "")
        assert "qwen" in step1_model, f"Simple list should use tier1, got {step1_model}"


class TestMultiAgentCostTracking:
    """Test cost tracking across full multi-agent workflows."""

    def test_full_workflow_tracking(self, tracked_client, multi_agent_workflows):
        """Run all workflows and check aggregate savings."""
        total_steps = 0
        for workflow in multi_agent_workflows:
            for step in workflow["steps"]:
                tracked_client.chat.completions.create(
                    model="claude-opus-4-6",
                    messages=[{"role": "user", "content": step["prompt"]}],
                )
                total_steps += 1

        stats = tracked_client.infershrink_tracker.stats()
        assert stats.total_requests == total_steps
        assert stats.requests_downgraded >= 1, \
            f"Expected at least 1 downgrade across {total_steps} multi-agent steps"

    def test_tracker_per_workflow_isolation(self):
        """Separate clients per workflow should track independently."""
        from tests.integration.conftest import MockOpenAIClient

        # Workflow A
        client_a = optimize(MockOpenAIClient())
        client_a.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hello"}],
        )

        # Workflow B
        client_b = optimize(MockOpenAIClient())
        client_b.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi there"}],
        )
        client_b.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Thanks"}],
        )

        stats_a = client_a.infershrink_tracker.stats()
        stats_b = client_b.infershrink_tracker.stats()
        assert stats_a.total_requests == 1
        assert stats_b.total_requests == 2
