"""
Data Analysis scenario: Agent processes data and generates insights.

InferShrink should:
- Route simple calculations to cheap models
- Route complex statistical analysis to strong models
- Handle data-heavy prompts (tables, JSON) without over-classifying
- Track savings across a data analysis session
"""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent / "src"))

from infershrink import classify
from infershrink.types import Complexity


class TestDataClassification:
    """Test classification of data analysis tasks."""

    def test_simple_math(self, classify_fn, data_tasks):
        simple = [t for t in data_tasks if t["expected_complexity"] == Complexity.SIMPLE]
        for task in simple:
            result = classify_fn([{"role": "user", "content": task["prompt"]}])
            assert result.complexity == Complexity.SIMPLE, \
                f"Simple math '{task['category']}' classified as {result.complexity}"

    def test_analysis_not_simple(self, classify_fn, data_tasks):
        moderate = [t for t in data_tasks if t["expected_complexity"] == Complexity.MODERATE]
        for task in moderate:
            result = classify_fn([{"role": "user", "content": task["prompt"]}])
            assert result.complexity != Complexity.SIMPLE, \
                f"Analysis task '{task['category']}' should not be SIMPLE"

    def test_modeling_complex(self, classify_fn, data_tasks):
        complex_tasks = [t for t in data_tasks if t["expected_complexity"] == Complexity.COMPLEX]
        for task in complex_tasks:
            result = classify_fn([{"role": "user", "content": task["prompt"]}])
            assert result.complexity in (Complexity.COMPLEX, Complexity.MODERATE), \
                f"Modeling task classified as {result.complexity}"


class TestDataRouting:
    """Test routing for data analysis tasks."""

    def test_simple_calc_routed_cheap(self, tracked_client):
        tracked_client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "What is 15% of 200?"}],
        )
        model = tracked_client.chat.completions.calls[-1].get("model", "")
        assert "qwen" in model, f"Simple calc routed to {model}"

    def test_statistical_analysis_stays_strong(self, tracked_client):
        """Statistical analysis with code + complex keywords should stay on strong model."""
        prompt = """Implement a multi-variate regression analysis step by step on this dataset.
Include comprehensive error handling:
- Feature correlation matrix
- VIF scores for multicollinearity  
- Residual analysis plots interpretation
- Cross-validated R² scores
- Feature importance ranking with confidence intervals

```python
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
# Dataset: 15 features, 10,000 rows
df = pd.read_csv('data.csv')
```

Design a reusable analysis pipeline with unit tests."""
        tracked_client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": prompt}],
        )
        model = tracked_client.chat.completions.calls[-1].get("model", "")
        assert "qwen" not in model, f"Statistical analysis should not be downgraded, got {model}"

    def test_data_session_savings(self, tracked_client, data_tasks):
        """Full data session should show savings on simple queries."""
        for task in data_tasks:
            tracked_client.chat.completions.create(
                model="claude-opus-4-6",
                messages=[{"role": "user", "content": task["prompt"]}],
            )
        stats = tracked_client.infershrink_tracker.stats()
        simple_count = sum(1 for t in data_tasks if t["expected_complexity"] == Complexity.SIMPLE)
        assert stats.requests_downgraded >= simple_count * 0.5, \
            f"Expected downgrades from {simple_count} simple tasks"


class TestDataWithLargePayloads:
    """Test handling of data-heavy prompts."""

    def test_large_json_classified_appropriately(self, classify_fn):
        """Large JSON payload with simple question should not auto-upgrade to COMPLEX."""
        data = '{"records": [' + ','.join(f'{{"id": {i}, "value": {i*10}}}' for i in range(50)) + ']}'
        messages = [{"role": "user", "content": f"Here's the data: {data}\n\nWhat is the total count of records?"}]
        result = classify_fn(messages)
        # Simple counting question even with large data
        assert result.complexity in (Complexity.SIMPLE, Complexity.MODERATE), \
            f"Simple count on large data classified as {result.complexity}"

    def test_large_table_with_complex_analysis(self, classify_fn):
        """Large data + complex analysis request = COMPLEX."""
        table = "| id | revenue | cost | region | quarter |\n|---|---|---|---|---|\n"
        table += "\n".join(f"| {i} | ${i*1000} | ${i*500} | {'N' if i%2 else 'S'} | Q{(i%4)+1} |" 
                          for i in range(30))
        prompt = f"""{table}

Perform the following analysis:
1. Calculate quarterly revenue growth by region
2. Identify loss-making quarters
3. Build a seasonal decomposition model
4. Forecast next 4 quarters with confidence intervals
5. Recommend cost optimization strategies per region"""
        messages = [{"role": "user", "content": prompt}]
        result = classify_fn(messages)
        assert result.complexity in (Complexity.COMPLEX, Complexity.MODERATE), \
            f"Complex analysis on large table classified as {result.complexity}"
