"""
Content Generation scenario: Agent writes posts, emails, articles.

InferShrink should:
- Route short social posts to cheap models
- Route long-form strategy docs to strong models
- Handle creative writing with appropriate model selection
"""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent.parent / "src"))

from infershrink import classify
from infershrink.types import Complexity


class TestContentClassification:
    """Test classification of content generation tasks."""

    def test_simple_content(self, classify_fn, content_tasks):
        simple = [t for t in content_tasks if t["expected_complexity"] == Complexity.SIMPLE]
        correct = 0
        for task in simple:
            result = classify_fn([{"role": "user", "content": task["prompt"]}])
            if result.complexity == Complexity.SIMPLE:
                correct += 1
        assert correct >= len(simple) * 0.5, \
            f"Only {correct}/{len(simple)} simple content tasks classified correctly"

    def test_moderate_content(self, classify_fn, content_tasks):
        """Moderate content tasks — classifier uses token count + keywords.
        Short prose prompts without code may classify as SIMPLE (expected behavior
        for a cost-optimization classifier; saves money on content generation)."""
        moderate = [t for t in content_tasks if t["expected_complexity"] == Complexity.MODERATE]
        for task in moderate:
            result = classify_fn([{"role": "user", "content": task["prompt"]}])
            # Rule-based classifier may classify short prose as SIMPLE — that's OK
            # for cost optimization (content gen doesn't need the strongest model)
            assert result.complexity in (Complexity.SIMPLE, Complexity.MODERATE), \
                f"Moderate content task '{task['category']}' classified as {result.complexity}"

    def test_complex_content(self, classify_fn, content_tasks):
        complex_tasks = [t for t in content_tasks if t["expected_complexity"] == Complexity.COMPLEX]
        for task in complex_tasks:
            result = classify_fn([{"role": "user", "content": task["prompt"]}])
            assert result.complexity in (Complexity.COMPLEX, Complexity.MODERATE), \
                f"Complex content strategy classified as {result.complexity}"


class TestContentRouting:
    """Test routing for content generation tasks."""

    def test_tweet_routed_cheap(self, tracked_client):
        tracked_client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Write a tweet about our product launch."}],
        )
        model = tracked_client.chat.completions.calls[-1].get("model", "")
        assert "qwen" in model, f"Tweet should be routed to tier1, got {model}"

    def test_strategy_doc_stays_strong(self, tracked_client):
        prompt = """Create a comprehensive go-to-market strategy for a B2B SaaS product including:
1. Market segmentation and ICP definition
2. Competitive positioning matrix
3. Pricing strategy with 3 tiers
4. Channel strategy (content, partnerships, events)
5. 90-day launch plan with milestones
6. Budget allocation and expected ROI
7. Risk mitigation plan"""
        tracked_client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": prompt}],
        )
        model = tracked_client.chat.completions.calls[-1].get("model", "")
        assert "qwen" not in model, f"Strategy doc should not be downgraded, got {model}"

    def test_content_session_savings(self, tracked_client, content_tasks):
        """Full content session should show savings."""
        for task in content_tasks:
            tracked_client.chat.completions.create(
                model="claude-opus-4-6",
                messages=[{"role": "user", "content": task["prompt"]}],
            )
        stats = tracked_client.infershrink_tracker.stats()
        assert stats.total_requests == len(content_tasks)
        assert stats.requests_downgraded >= 1, "Should downgrade at least 1 simple content task"


class TestContentEdgeCases:
    """Edge cases for content generation."""

    def test_empty_prompt(self, classify_fn):
        result = classify_fn([{"role": "user", "content": ""}])
        assert result.complexity == Complexity.SIMPLE

    def test_single_word(self, classify_fn):
        result = classify_fn([{"role": "user", "content": "Hello"}])
        assert result.complexity == Complexity.SIMPLE

    def test_very_long_simple_prompt(self, classify_fn):
        """Long but repetitive content should not be over-classified."""
        prompt = "Write a greeting. " * 50
        result = classify_fn([{"role": "user", "content": prompt}])
        # Length alone shouldn't force COMPLEX
        assert result.complexity in (Complexity.SIMPLE, Complexity.MODERATE)

    def test_multilingual_content(self, classify_fn):
        """Non-English content should be handled gracefully."""
        prompt = "Escribe un tweet sobre inteligencia artificial."
        result = classify_fn([{"role": "user", "content": prompt}])
        assert result.complexity == Complexity.SIMPLE
