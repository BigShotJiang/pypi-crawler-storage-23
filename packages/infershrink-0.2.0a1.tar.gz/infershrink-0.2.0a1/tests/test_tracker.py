"""Tests for the cost tracker — thread safety, accuracy, edge cases."""

import threading
import pytest

from infershrink.tracker import Tracker, _MODEL_COST_INPUT
from infershrink.config import build_config
from infershrink.types import Complexity, SessionStats, RequestRecord


class TestTrackerBasics:
    """Basic tracker operations."""

    def test_initial_stats_are_zero(self):
        t = Tracker(persist_path="")
        s = t.stats()
        assert s.total_requests == 0
        assert s.total_original_tokens == 0
        assert s.total_compressed_tokens == 0
        assert s.total_tokens_saved == 0
        assert s.total_estimated_savings_usd == 0.0
        assert s.requests_downgraded == 0
        assert s.requests_compressed == 0
        assert s.compression_ratio == 1.0
        assert s.records == []

    def test_record_single_request(self):
        t = Tracker(build_config(), persist_path="")
        record = t.record(
            original_model="claude-opus-4-6",
            routed_model="qwen2.5:32b",
            original_tokens=1000,
            compressed_tokens=1000,
            complexity=Complexity.SIMPLE,
        )
        assert isinstance(record, RequestRecord)
        assert record.original_model == "claude-opus-4-6"
        assert record.routed_model == "qwen2.5:32b"
        assert record.original_tokens == 1000
        assert record.savings >= 0

    def test_record_increments_stats(self):
        t = Tracker(build_config(), persist_path="")
        t.record("claude-opus-4-6", "qwen2.5:32b", 1000, 1000, Complexity.SIMPLE)
        s = t.stats()
        assert s.total_requests == 1
        assert s.total_original_tokens == 1000
        assert s.total_compressed_tokens == 1000

    def test_multiple_records_accumulate(self):
        t = Tracker(build_config(), persist_path="")
        for _ in range(10):
            t.record("claude-opus-4-6", "qwen2.5:32b", 100, 80, Complexity.SIMPLE)
        s = t.stats()
        assert s.total_requests == 10
        assert s.total_original_tokens == 1000
        assert s.total_compressed_tokens == 800
        assert s.total_tokens_saved == 200

    def test_reset_clears_everything(self):
        t = Tracker(build_config(), persist_path="")
        t.record("claude-opus-4-6", "qwen2.5:32b", 1000, 500, Complexity.SIMPLE)
        t.reset()
        s = t.stats()
        assert s.total_requests == 0
        assert s.total_original_tokens == 0
        assert s.records == []


class TestTrackerCostCalculations:
    """Verify cost and savings calculations are correct."""

    def test_same_model_no_savings_from_routing(self):
        t = Tracker(build_config(), persist_path="")
        record = t.record("claude-opus-4-6", "claude-opus-4-6", 1000, 1000, Complexity.COMPLEX)
        assert record.savings == 0.0
        assert record.estimated_cost_original == record.estimated_cost_routed

    def test_downgrade_produces_savings(self):
        config = build_config()
        t = Tracker(config, persist_path="")
        record = t.record("claude-opus-4-6", "qwen2.5:32b", 1000, 1000, Complexity.SIMPLE)
        # claude-opus-4-6: 0.015 per 1k; qwen2.5:32b: 0.0 per 1k
        expected_original = (1000 / 1000) * 0.015
        expected_routed = 0.0
        assert abs(record.estimated_cost_original - expected_original) < 1e-10
        assert abs(record.estimated_cost_routed - expected_routed) < 1e-10
        assert abs(record.savings - expected_original) < 1e-10

    def test_compression_reduces_cost(self):
        t = Tracker(build_config(), persist_path="")
        record = t.record("claude-opus-4-6", "claude-opus-4-6", 1000, 500, Complexity.COMPLEX)
        assert record.estimated_cost_routed < record.estimated_cost_original
        assert record.savings > 0

    def test_both_routing_and_compression_savings(self):
        t = Tracker(build_config(), persist_path="")
        record = t.record("claude-opus-4-6", "qwen2.5:32b", 1000, 500, Complexity.SIMPLE)
        # Cheaper model AND fewer tokens
        expected_original = (1000 / 1000) * 0.015
        expected_routed = 0.0  # qwen is free
        assert abs(record.savings - expected_original) < 1e-10

    def test_savings_never_negative(self):
        """If routed model is MORE expensive (shouldn't happen, but test), savings = 0."""
        t = Tracker(build_config(), persist_path="")
        record = t.record("qwen2.5:32b", "claude-opus-4-6", 1000, 1000, Complexity.COMPLEX)
        assert record.savings == 0.0

    def test_zero_tokens(self):
        t = Tracker(build_config(), persist_path="")
        record = t.record("claude-opus-4-6", "qwen2.5:32b", 0, 0, Complexity.SIMPLE)
        assert record.estimated_cost_original == 0.0
        assert record.estimated_cost_routed == 0.0
        assert record.savings == 0.0

    def test_unknown_model_uses_default_cost(self):
        t = Tracker(build_config(), persist_path="")
        record = t.record("unknown-model", "unknown-model", 1000, 1000, Complexity.MODERATE)
        assert record.estimated_cost_original > 0

    def test_tier_config_overrides_builtin_costs(self):
        """Cost from config tiers takes precedence over _MODEL_COST_INPUT."""
        config = build_config({
            "tiers": {
                "tier1": {
                    "models": ["qwen2.5:32b"],
                    "cost_per_1k_input": 0.001,
                }
            }
        })
        t = Tracker(config, persist_path="")
        record = t.record("qwen2.5:32b", "qwen2.5:32b", 1000, 1000, Complexity.SIMPLE)
        expected = (1000 / 1000) * 0.001
        assert abs(record.estimated_cost_original - expected) < 1e-10


class TestTrackerStats:
    """Test stats tracking accuracy."""

    def test_downgraded_count(self):
        t = Tracker(build_config(), persist_path="")
        t.record("claude-opus-4-6", "qwen2.5:32b", 100, 100, Complexity.SIMPLE)
        t.record("claude-opus-4-6", "claude-opus-4-6", 100, 100, Complexity.COMPLEX)
        t.record("claude-sonnet-4-20250514", "qwen2.5:32b", 100, 100, Complexity.SIMPLE)
        s = t.stats()
        assert s.requests_downgraded == 2

    def test_compressed_count(self):
        t = Tracker(build_config(), persist_path="")
        t.record("claude-opus-4-6", "claude-opus-4-6", 100, 80, Complexity.COMPLEX)   # compressed
        t.record("claude-opus-4-6", "claude-opus-4-6", 100, 100, Complexity.COMPLEX)  # not
        t.record("claude-opus-4-6", "claude-opus-4-6", 200, 150, Complexity.COMPLEX)  # compressed
        s = t.stats()
        assert s.requests_compressed == 2

    def test_compression_ratio(self):
        t = Tracker(build_config(), persist_path="")
        t.record("claude-opus-4-6", "claude-opus-4-6", 1000, 500, Complexity.COMPLEX)
        s = t.stats()
        assert abs(s.compression_ratio - 0.5) < 1e-10

    def test_cumulative_savings(self):
        t = Tracker(build_config(), persist_path="")
        r1 = t.record("claude-opus-4-6", "qwen2.5:32b", 1000, 1000, Complexity.SIMPLE)
        r2 = t.record("claude-opus-4-6", "qwen2.5:32b", 2000, 2000, Complexity.SIMPLE)
        s = t.stats()
        assert abs(s.total_estimated_savings_usd - (r1.savings + r2.savings)) < 1e-10

    def test_records_list_grows(self):
        t = Tracker(build_config(), persist_path="")
        for i in range(5):
            t.record("claude-opus-4-6", "qwen2.5:32b", 100, 100, Complexity.SIMPLE)
        s = t.stats()
        assert len(s.records) == 5

    def test_stats_returns_copy(self):
        """Mutating returned stats should not affect tracker internal state."""
        t = Tracker(build_config(), persist_path="")
        t.record("claude-opus-4-6", "qwen2.5:32b", 100, 100, Complexity.SIMPLE)
        s = t.stats()
        s.total_requests = 999
        s.records.clear()
        s2 = t.stats()
        assert s2.total_requests == 1
        assert len(s2.records) == 1


class TestTrackerSummary:
    """Test human-readable summary output."""

    def test_summary_contains_key_fields(self):
        t = Tracker(build_config(), persist_path="")
        t.record("claude-opus-4-6", "qwen2.5:32b", 1000, 800, Complexity.SIMPLE)
        summary = t.summary()
        assert "Total requests:" in summary
        assert "Requests downgraded:" in summary
        assert "Requests compressed:" in summary
        assert "Original tokens:" in summary
        assert "Compressed tokens:" in summary
        assert "Tokens saved:" in summary
        assert "Estimated savings:" in summary

    def test_summary_empty_tracker(self):
        t = Tracker(persist_path="")
        summary = t.summary()
        assert "Total requests:       0" in summary

    def test_summary_shows_percentage(self):
        t = Tracker(build_config(), persist_path="")
        t.record("claude-opus-4-6", "claude-opus-4-6", 1000, 500, Complexity.COMPLEX)
        summary = t.summary()
        assert "50.0%" in summary


class TestTrackerThreadSafety:
    """Test concurrent access to the tracker."""

    def test_concurrent_records(self):
        t = Tracker(build_config(), persist_path="")
        num_threads = 20
        records_per_thread = 50

        def worker():
            for _ in range(records_per_thread):
                t.record("claude-opus-4-6", "qwen2.5:32b", 100, 80, Complexity.SIMPLE)

        threads = [threading.Thread(target=worker) for _ in range(num_threads)]
        for th in threads:
            th.start()
        for th in threads:
            th.join()

        s = t.stats()
        assert s.total_requests == num_threads * records_per_thread
        assert s.total_original_tokens == num_threads * records_per_thread * 100
        assert s.total_compressed_tokens == num_threads * records_per_thread * 80

    def test_concurrent_record_and_stats(self):
        t = Tracker(build_config(), persist_path="")
        errors = []

        def writer():
            for _ in range(100):
                t.record("claude-opus-4-6", "qwen2.5:32b", 100, 80, Complexity.SIMPLE)

        def reader():
            for _ in range(100):
                s = t.stats()
                if s.total_requests < 0:
                    errors.append("negative requests")

        threads = (
            [threading.Thread(target=writer) for _ in range(5)]
            + [threading.Thread(target=reader) for _ in range(5)]
        )
        for th in threads:
            th.start()
        for th in threads:
            th.join()

        assert len(errors) == 0

    def test_concurrent_record_and_reset(self):
        t = Tracker(build_config(), persist_path="")

        def writer():
            for _ in range(100):
                try:
                    t.record("claude-opus-4-6", "qwen2.5:32b", 100, 80, Complexity.SIMPLE)
                except Exception:
                    pass

        def resetter():
            for _ in range(10):
                t.reset()

        threads = (
            [threading.Thread(target=writer) for _ in range(5)]
            + [threading.Thread(target=resetter) for _ in range(2)]
        )
        for th in threads:
            th.start()
        for th in threads:
            th.join()

        s = t.stats()
        assert s.total_requests >= 0


class TestModelCostTable:
    """Verify the built-in cost table."""

    def test_known_models_have_costs(self):
        expected_models = [
            "qwen2.5:32b", "gemini-2.5-flash",
            "gemini-3-pro-preview", "gemini-3-flash-preview", "gemini-2.5-pro",
            "claude-opus-4-6", "claude-sonnet-4-20250514",
        ]
        for model in expected_models:
            assert model in _MODEL_COST_INPUT, f"{model} missing from cost table"

    def test_costs_are_reasonable(self):
        """All costs should be non-negative and less than $1 per 1k tokens."""
        for model, cost in _MODEL_COST_INPUT.items():
            assert 0 <= cost < 1.0, f"{model} has unreasonable cost: {cost}"

    def test_tier1_tier2_are_free(self):
        free_models = ["qwen2.5:32b", "gemini-2.5-flash", "gemini-3-pro-preview",
                       "gemini-3-flash-preview", "gemini-2.5-pro"]
        for model in free_models:
            assert _MODEL_COST_INPUT[model] == 0.0

    def test_tier3_has_costs(self):
        assert _MODEL_COST_INPUT["claude-opus-4-6"] == 0.015
        assert _MODEL_COST_INPUT["claude-sonnet-4-20250514"] == 0.003
