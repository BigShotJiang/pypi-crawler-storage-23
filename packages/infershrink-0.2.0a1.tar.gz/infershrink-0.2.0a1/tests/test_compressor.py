"""Tests for the prompt compressor."""

import pytest

from infershrink.compressor import compress, is_tokenshrink_available
from infershrink.config import build_config
from infershrink.types import Complexity


@pytest.fixture
def config():
    return build_config()


@pytest.fixture
def config_disabled():
    return build_config({"compression": {"enabled": False}})


class TestCompressionSkipping:
    """Test cases where compression should be skipped."""

    def test_skips_for_security_critical(self, config):
        messages = [{"role": "user", "content": "My password is hunter2 " * 200}]
        result = compress(messages, Complexity.SECURITY_CRITICAL, config)
        assert result.was_compressed is False
        assert result.messages == messages

    def test_skips_for_short_messages(self, config):
        messages = [{"role": "user", "content": "Hello world"}]
        result = compress(messages, Complexity.SIMPLE, config)
        assert result.was_compressed is False
        # Short messages (< min_tokens) should not be compressed

    def test_skips_when_disabled(self, config_disabled):
        long_text = "This is a long message. " * 200
        messages = [{"role": "user", "content": long_text}]
        result = compress(messages, Complexity.MODERATE, config_disabled)
        assert result.was_compressed is False

    def test_skips_when_tokenshrink_not_available(self, config):
        """If tokenshrink isn't installed, compression is skipped silently."""
        if is_tokenshrink_available():
            pytest.skip("tokenshrink is installed — can't test absence")

        long_text = "This is a long enough message to trigger compression. " * 100
        messages = [{"role": "user", "content": long_text}]
        result = compress(messages, Complexity.MODERATE, config)
        assert result.was_compressed is False


class TestCompressionResult:
    """Test the structure of compression results."""

    def test_returns_original_tokens(self, config):
        messages = [{"role": "user", "content": "Hello world!"}]
        result = compress(messages, Complexity.SIMPLE, config)
        assert result.original_tokens > 0

    def test_compression_ratio_is_1_when_not_compressed(self, config):
        messages = [{"role": "user", "content": "Short"}]
        result = compress(messages, Complexity.SIMPLE, config)
        assert result.compression_ratio == 1.0

    def test_messages_unchanged_when_not_compressed(self, config):
        messages = [
            {"role": "system", "content": "Be helpful."},
            {"role": "user", "content": "Hi"},
        ]
        result = compress(messages, Complexity.SIMPLE, config)
        assert result.messages == messages

    def test_multipart_content_handled(self, config):
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "What is this?"},
                    {"type": "image_url", "image_url": {"url": "https://example.com/img.png"}},
                ],
            }
        ]
        result = compress(messages, Complexity.SIMPLE, config)
        assert result.original_tokens > 0


class TestCompressionWithTokenShrink:
    """Tests that only run when TokenShrink is installed."""

    @pytest.fixture(autouse=True)
    def skip_without_tokenshrink(self):
        if not is_tokenshrink_available():
            pytest.skip("tokenshrink not installed")

    def test_compresses_long_messages(self, config):
        long_text = "This is a very long and verbose message that contains a lot of unnecessary words and filler content that could be compressed significantly. " * 30
        messages = [{"role": "user", "content": long_text}]
        result = compress(messages, Complexity.MODERATE, config)
        assert result.was_compressed is True
        assert result.compressed_tokens <= result.original_tokens

    def test_preserves_system_messages(self, config):
        long_text = "Explain this concept in detail. " * 50
        system_content = "You are a helpful assistant."
        messages = [
            {"role": "system", "content": system_content},
            {"role": "user", "content": long_text},
        ]
        result = compress(messages, Complexity.MODERATE, config)
        # System message should be preserved exactly
        assert result.messages[0]["content"] == system_content


class TestCustomCompressionConfig:
    def test_custom_min_tokens_threshold(self):
        config = build_config({"compression": {"min_tokens": 10}})
        messages = [{"role": "user", "content": "This has more than ten tokens of content right here."}]
        result = compress(messages, Complexity.MODERATE, config)
        # With low threshold, it would try to compress (if tokenshrink available)
        # Either way, should not error
        assert result.original_tokens > 0

    def test_custom_skip_for(self):
        config = build_config({
            "compression": {"skip_for": ["SECURITY_CRITICAL", "COMPLEX"]}
        })
        long_text = "This is a long message. " * 200
        messages = [{"role": "user", "content": long_text}]
        result = compress(messages, Complexity.COMPLEX, config)
        assert result.was_compressed is False
