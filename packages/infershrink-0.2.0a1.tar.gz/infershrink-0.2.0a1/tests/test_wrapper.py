"""Tests for the SDK wrapper (optimize function)."""

import pytest
from unittest.mock import MagicMock, patch

from infershrink.wrapper import optimize, InferShrinkClient, _detect_client_type
from infershrink.tracker import Tracker


class MockCompletions:
    """Mock for openai.Client().chat.completions"""

    def create(self, **kwargs):
        return MagicMock(
            choices=[
                MagicMock(message=MagicMock(content="Hello!", role="assistant"))
            ],
            model=kwargs.get("model", "qwen2.5:32b"),
            usage=MagicMock(prompt_tokens=10, completion_tokens=5, total_tokens=15),
        )


class MockChat:
    """Mock for openai.Client().chat"""

    def __init__(self):
        self.completions = MockCompletions()


class MockOpenAIClient:
    """Mock OpenAI client."""

    def __init__(self):
        self.chat = MockChat()
        self.api_key = "sk-test"


class MockAnthropicMessages:
    """Mock for anthropic.Anthropic().messages"""

    def create(self, **kwargs):
        return MagicMock(
            content=[MagicMock(text="Hello!", type="text")],
            model=kwargs.get("model", "claude-sonnet-4-20250514"),
            usage=MagicMock(input_tokens=10, output_tokens=5),
        )


class MockAnthropicClient:
    """Mock Anthropic client."""

    def __init__(self):
        self.messages = MockAnthropicMessages()
        self.api_key = "sk-ant-test"

    class __class__:
        __module__ = "anthropic"
        __name__ = "Anthropic"


class TestOptimizeOpenAI:
    """Test optimize() with OpenAI-like clients."""

    def test_returns_wrapped_client(self):
        client = optimize(MockOpenAIClient())
        assert isinstance(client, InferShrinkClient)

    def test_preserves_original_attributes(self):
        client = optimize(MockOpenAIClient())
        assert client.api_key == "sk-test"

    def test_has_tracker(self):
        client = optimize(MockOpenAIClient())
        assert isinstance(client.infershrink_tracker, Tracker)

    def test_chat_completions_create_works(self):
        client = optimize(MockOpenAIClient())
        response = client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hello!"}],
        )
        assert response is not None

    def test_simple_task_gets_routed(self):
        mock = MockOpenAIClient()
        client = optimize(mock)

        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi!"}],
        )

        # Check that the underlying create was called with a cheaper model
        # The mock's create was called — check the tracker
        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 1
        assert stats.requests_downgraded == 1

    def test_complex_task_not_downgraded(self):
        mock = MockOpenAIClient()
        client = optimize(mock)

        # Long prompt with code blocks and step-by-step keyword
        long_code = "```python\n" + "x = 1\n" * 100 + "```\n"
        client.chat.completions.create(
            model="gpt-5.2",
            messages=[
                {"role": "user", "content": f"Debug step by step:\n{long_code * 3}"}
            ],
        )

        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 1
        assert stats.requests_downgraded == 0

    def test_security_critical_never_downgraded(self):
        mock = MockOpenAIClient()
        client = optimize(mock)

        client.chat.completions.create(
            model="gpt-5.2",
            messages=[
                {"role": "user", "content": "Store this password: supersecret123"}
            ],
        )

        stats = client.infershrink_tracker.stats()
        assert stats.requests_downgraded == 0

    def test_tracks_multiple_requests(self):
        mock = MockOpenAIClient()
        client = optimize(mock)

        for _ in range(5):
            client.chat.completions.create(
                model="claude-opus-4-6",
                messages=[{"role": "user", "content": "What is 2+2?"}],
            )

        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 5


class TestOptimizeAnthropic:
    """Test optimize() with Anthropic-like clients."""

    def test_detects_anthropic_client(self):
        client_type = _detect_client_type(MockAnthropicClient())
        assert client_type == "anthropic"

    def test_messages_create_works(self):
        client = optimize(MockAnthropicClient())
        response = client.messages.create(
            model="claude-opus-4-6",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello!"}],
        )
        assert response is not None

    def test_has_tracker(self):
        client = optimize(MockAnthropicClient())
        assert isinstance(client.infershrink_tracker, Tracker)


class TestOptimizeWithConfig:
    """Test optimize() with custom configuration."""

    def test_custom_tier_models(self):
        mock = MockOpenAIClient()
        client = optimize(mock, config={
            "tiers": {
                "tier1": {"models": ["my-cheap-model"], "max_complexity": "SIMPLE"}
            }
        })

        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
        )

        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 1

    def test_disabled_compression(self):
        mock = MockOpenAIClient()
        client = optimize(mock, config={"compression": {"enabled": False}})

        long_text = "This is a long message. " * 200
        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": long_text}],
        )

        stats = client.infershrink_tracker.stats()
        assert stats.requests_compressed == 0

    def test_disabled_cost_tracking(self):
        mock = MockOpenAIClient()
        client = optimize(mock, config={"cost_tracking": False})

        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
        )

        stats = client.infershrink_tracker.stats()
        assert stats.total_requests == 0  # tracking disabled


class TestTrackerIntegration:
    def test_reset_clears_stats(self):
        mock = MockOpenAIClient()
        client = optimize(mock)

        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hi"}],
        )

        assert client.infershrink_tracker.stats().total_requests == 1

        client.infershrink_tracker.reset()
        assert client.infershrink_tracker.stats().total_requests == 0

    def test_summary_is_string(self):
        mock = MockOpenAIClient()
        client = optimize(mock)

        client.chat.completions.create(
            model="claude-opus-4-6",
            messages=[{"role": "user", "content": "Hello"}],
        )

        summary = client.infershrink_tracker.summary()
        assert isinstance(summary, str)
        assert "InferShrink Session Stats" in summary
