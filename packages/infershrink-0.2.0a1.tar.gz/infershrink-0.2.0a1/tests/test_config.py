"""Tests for configuration — deep merge, build_config, edge cases."""

import copy
import pytest

from infershrink.config import build_config, DEFAULT_CONFIG, _deep_merge, COMPLEXITY_TO_TIER


class TestDefaultConfig:
    """Verify the shape and content of DEFAULT_CONFIG."""

    def test_has_tiers(self):
        assert "tiers" in DEFAULT_CONFIG
        assert "tier1" in DEFAULT_CONFIG["tiers"]
        assert "tier2" in DEFAULT_CONFIG["tiers"]
        assert "tier3" in DEFAULT_CONFIG["tiers"]

    def test_tiers_have_models(self):
        for tier_name, tier_cfg in DEFAULT_CONFIG["tiers"].items():
            assert "models" in tier_cfg, f"{tier_name} missing 'models'"
            assert isinstance(tier_cfg["models"], list)
            assert len(tier_cfg["models"]) > 0

    def test_tiers_have_costs(self):
        for tier_name, tier_cfg in DEFAULT_CONFIG["tiers"].items():
            assert "cost_per_1k_input" in tier_cfg
            assert "cost_per_1k_output" in tier_cfg
            assert tier_cfg["cost_per_1k_input"] >= 0
            assert tier_cfg["cost_per_1k_output"] >= 0

    def test_cost_increases_by_tier(self):
        t1 = DEFAULT_CONFIG["tiers"]["tier1"]["cost_per_1k_input"]
        t2 = DEFAULT_CONFIG["tiers"]["tier2"]["cost_per_1k_input"]
        t3 = DEFAULT_CONFIG["tiers"]["tier3"]["cost_per_1k_input"]
        # tier1 and tier2 are free, tier3 is paid
        assert t1 <= t2 < t3

    def test_has_compression_settings(self):
        assert "compression" in DEFAULT_CONFIG
        assert "enabled" in DEFAULT_CONFIG["compression"]
        assert "min_tokens" in DEFAULT_CONFIG["compression"]
        assert "skip_for" in DEFAULT_CONFIG["compression"]

    def test_has_quality_floor(self):
        assert "quality_floor" in DEFAULT_CONFIG
        assert 0 < DEFAULT_CONFIG["quality_floor"] <= 1.0

    def test_has_cost_tracking(self):
        assert "cost_tracking" in DEFAULT_CONFIG
        assert DEFAULT_CONFIG["cost_tracking"] is True


class TestComplexityToTier:
    """Verify COMPLEXITY_TO_TIER mapping."""

    def test_simple_maps_to_tier1(self):
        assert COMPLEXITY_TO_TIER["SIMPLE"] == "tier1"

    def test_moderate_maps_to_tier2(self):
        assert COMPLEXITY_TO_TIER["MODERATE"] == "tier2"

    def test_complex_maps_to_tier3(self):
        assert COMPLEXITY_TO_TIER["COMPLEX"] == "tier3"

    def test_security_critical_maps_to_tier3(self):
        assert COMPLEXITY_TO_TIER["SECURITY_CRITICAL"] == "tier3"

    def test_all_complexity_levels_mapped(self):
        from infershrink.types import Complexity
        for c in Complexity:
            assert c.value in COMPLEXITY_TO_TIER


class TestDeepMerge:
    """Test the _deep_merge helper."""

    def test_empty_override(self):
        base = {"a": 1, "b": {"c": 2}}
        result = _deep_merge(base, {})
        assert result == base

    def test_simple_override(self):
        base = {"a": 1, "b": 2}
        result = _deep_merge(base, {"b": 3})
        assert result == {"a": 1, "b": 3}

    def test_nested_override(self):
        base = {"a": {"b": 1, "c": 2}, "d": 3}
        result = _deep_merge(base, {"a": {"c": 99}})
        assert result == {"a": {"b": 1, "c": 99}, "d": 3}

    def test_deeply_nested_override(self):
        base = {"a": {"b": {"c": {"d": 1}}}}
        result = _deep_merge(base, {"a": {"b": {"c": {"d": 2, "e": 3}}}})
        assert result == {"a": {"b": {"c": {"d": 2, "e": 3}}}}

    def test_new_key_added(self):
        base = {"a": 1}
        result = _deep_merge(base, {"b": 2})
        assert result == {"a": 1, "b": 2}

    def test_dict_replaced_by_scalar(self):
        base = {"a": {"b": 1}}
        result = _deep_merge(base, {"a": "scalar"})
        assert result == {"a": "scalar"}

    def test_scalar_replaced_by_dict(self):
        base = {"a": "scalar"}
        result = _deep_merge(base, {"a": {"b": 1}})
        assert result == {"a": {"b": 1}}

    def test_does_not_mutate_base(self):
        base = {"a": {"b": 1}}
        base_copy = copy.deepcopy(base)
        _deep_merge(base, {"a": {"b": 99}})
        assert base == base_copy

    def test_does_not_mutate_override(self):
        override = {"a": {"b": 1}}
        override_copy = copy.deepcopy(override)
        _deep_merge({"x": 1}, override)
        assert override == override_copy

    def test_list_override_replaces(self):
        """Lists are replaced, not merged."""
        base = {"a": [1, 2, 3]}
        result = _deep_merge(base, {"a": [4, 5]})
        assert result == {"a": [4, 5]}

    def test_none_value_override(self):
        base = {"a": 1}
        result = _deep_merge(base, {"a": None})
        assert result == {"a": None}


class TestBuildConfig:
    """Test build_config merging."""

    def test_no_override_returns_defaults(self):
        config = build_config()
        assert config == DEFAULT_CONFIG

    def test_no_override_returns_copy(self):
        config = build_config()
        config["tiers"]["tier1"]["models"].append("mutated")
        assert "mutated" not in DEFAULT_CONFIG["tiers"]["tier1"]["models"]

    def test_none_override_returns_defaults(self):
        config = build_config(None)
        assert config == DEFAULT_CONFIG

    def test_partial_tier_override(self):
        config = build_config({
            "tiers": {
                "tier1": {"models": ["my-model"]}
            }
        })
        # tier1 models should be overridden
        assert config["tiers"]["tier1"]["models"] == ["my-model"]
        # tier1 costs should be preserved from defaults
        assert "cost_per_1k_input" in config["tiers"]["tier1"]
        # tier2 and tier3 should be untouched
        assert config["tiers"]["tier2"] == DEFAULT_CONFIG["tiers"]["tier2"]

    def test_disable_compression(self):
        config = build_config({"compression": {"enabled": False}})
        assert config["compression"]["enabled"] is False
        # Other compression settings preserved
        assert config["compression"]["min_tokens"] == DEFAULT_CONFIG["compression"]["min_tokens"]

    def test_override_quality_floor(self):
        config = build_config({"quality_floor": 0.8})
        assert config["quality_floor"] == 0.8

    def test_add_custom_key(self):
        config = build_config({"custom_key": "custom_value"})
        assert config["custom_key"] == "custom_value"
        # Defaults still present
        assert "tiers" in config

    def test_empty_override(self):
        config = build_config({})
        assert config == DEFAULT_CONFIG

    def test_completely_custom_config(self):
        custom = {
            "tiers": {
                "tier1": {
                    "models": ["llama-3-8b"],
                    "max_complexity": "SIMPLE",
                    "cost_per_1k_input": 0.0001,
                    "cost_per_1k_output": 0.0002,
                },
            },
            "compression": {"enabled": False},
            "quality_floor": 0.9,
            "cost_tracking": False,
        }
        config = build_config(custom)
        assert config["tiers"]["tier1"]["models"] == ["llama-3-8b"]
        assert config["compression"]["enabled"] is False
        assert config["cost_tracking"] is False
