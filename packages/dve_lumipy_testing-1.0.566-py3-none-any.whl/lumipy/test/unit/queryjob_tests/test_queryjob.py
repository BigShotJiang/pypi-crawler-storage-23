import unittest
from unittest.mock import MagicMock, patch
from lumipy.helpers.backoff_handler import BackoffHandler
from lumipy.query_job import QueryJob


def _make_job(delete_side_effect=None, print_fn=None):
    """Helper: build a QueryJob with a mock client."""
    mock_client = MagicMock()
    mock_client.get_status.return_value = {
        'progress': '',
        'row_count': '0',
        'status': 'RanToCompletion',
        'state': 'Completed',
    }
    if delete_side_effect is not None:
        mock_client.delete_query.side_effect = delete_side_effect

    kwargs = {}
    if print_fn is not None:
        kwargs['_print_fn'] = print_fn

    job = QueryJob('fake-exec-id', mock_client, **kwargs)
    return job, mock_client


class TestQueryJob(unittest.TestCase):
    def test_pause_time_smaller_than_max_pause_time(self):
        backoff_handler_test = BackoffHandler(pause_time = 0.5, max_pause_time=20, beta=1.0001)
        backoff_handler_test.sleep()
        self.assertAlmostEqual(backoff_handler_test.pause_time, 0.50005, places = 5)

    def test_pause_time_equals_max_pause_time(self):
        backoff_handler_test = BackoffHandler(pause_time = 30, max_pause_time=30, beta=1.001)
        backoff_handler_test.sleep()
        self.assertEqual(backoff_handler_test.pause_time, 30)

    def test_pause_time_bigger_than_max_pause_time(self):
        with self.assertRaises(ValueError) as ve:  # test that the ctor is raising a ValueError
            _ = BackoffHandler(pause_time=100, max_pause_time=20, beta=1.1)

        ex = str(ve.exception)
        self.assertIn("Pause time must be between 0.1 and 20, both inclusive.", ex)

    def test_default_optional_values(self):
        backoff_handler_test = BackoffHandler()
        backoff_handler_test.sleep()
        self.assertAlmostEqual(backoff_handler_test.pause_time, 0.105127109637602, places = 5)

    def test_call_1000_times_pause_time_equals_max_pause_time(self):
        backoff_handler_test = BackoffHandler()
        # I have checked that this is constant after 94 requests
        for i in range(100):
            backoff_handler_test._update_pause_time()
        self.assertEqual(backoff_handler_test.pause_time, 10)


class TestInteractiveMonitor(unittest.TestCase):

    def test_keyboard_interrupt_propagates_when_delete_succeeds(self):
        job, _ = _make_job()
        with patch.object(job, 'monitor', side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                job.interactive_monitor()

    def test_keyboard_interrupt_propagates_when_delete_raises(self):
        job, _ = _make_job(delete_side_effect=RuntimeError('cancel failed'))
        with patch.object(job, 'monitor', side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                job.interactive_monitor()

    def test_cancel_failure_is_reported_via_print_fn(self):
        printed = []
        job, _ = _make_job(
            delete_side_effect=RuntimeError('network timeout'),
            print_fn=printed.append,
        )
        with patch.object(job, 'monitor', side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                job.interactive_monitor()

        warning_lines = [line for line in printed if 'Warning' in line and 'network timeout' in line]
        self.assertTrue(len(warning_lines) > 0, "Expected a cancel-failure warning to be printed")
