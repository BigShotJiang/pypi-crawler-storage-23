# <Title>

## Summary

What we're building, how, and what approach. 2-3 sentences.

## Important Decisions

Important choices made - the non obvious. This is your section to explain anything that was not obvious from the start, so anywhere where we had to put in some kind of a decision, something that can be challenged. You can mention what alternative was rejected if there were close contenders.

## Files Affected

- `path/to/file` — files that will be altered, added, or removed, and what exactly will be done
- `path/to/file` — files that will be altered, added, or removed, and what exactly will be done
- ...

## Implementation Order

1. Step or phase description — why first
2. Next step — what it depends on

## Details

The full plan. Describe the architecture, structure, data flow, and how the pieces connect. Explain the idea and the design — not the implementation. The implementer is capable; they don't need to be told how to write it, only what to build and why it's structured that way. No code, no pseudocode, no line-by-line instructions.

