# <Title>

## What

What needs to be done. Describe the change, feature, or fix in plain language. Be direct — no need to explain why or how here, just what.

## What Not [optional]

What is explicitly out of scope. What should not change, not be touched, or not be built.

## Why [optional]

The motivation or business reason behind this task. What problem does it solve and for whom.

## Before [optional]

What exists today. How the current behavior works before this change is made.

## Examples [optional]

Concrete examples of inputs, outputs, behaviors, or scenarios that illustrate what done looks like.

## Story [optional]

A narrative or user journey that describes the experience end-to-end. Useful for feature work where flow matters.

## Notes [optional]

Anything else worth capturing — rough thoughts, open questions, things to watch out for, links, references or background information that helps understand the space — prior decisions, related systems, constraints, or anything that shapes the approach.

## Inspiration [optional]

References, links, screenshots, prior art, or examples from other products that inform the direction.
