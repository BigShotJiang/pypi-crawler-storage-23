# Task Workflow

The task workflow produces `task.md` — the starting point for any unit of work. It takes instructions and structures them into a task file following the template.

## Inputs

- `session_folder` (required) — where the task will be created. Created automatically if it doesn't exist.
- `instructions` — what needs to be done. Free-text guidance for the artifact builder agent.
- `lite` — use a smaller, faster model (default: false).

## Orchestration

The orchestrator (`create_task.py`) sets up the session folder and context, then delegates to the artifact builder agent. Module resolution is handled by the Studio pre-flight check or CLI router, not by the task workflow itself.

## Agents

**Artifact Builder** (`shared/artifact_builder.py`, stage `task`, model L) — takes instructions and structures them into `task.md` following the template. Extracts clear requirements, preserves original intent. No frontmatter — plain markdown only.

**Router** (`task_router.py`, model M, read-only) — determines which project modules a task affects. Returns a comma-separated list of module names or `"all"`. Called by the Studio start endpoint as a pre-flight check, not by the task workflow directly.
