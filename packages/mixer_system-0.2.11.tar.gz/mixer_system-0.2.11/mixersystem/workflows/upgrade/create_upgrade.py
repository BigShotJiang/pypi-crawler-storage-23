from pathlib import Path

from mixersystem.data.repository import context_scope, update_session_run
from mixersystem.workflows.shared import artifact_builder as builder
from mixersystem.workflows.shared.implementation_checker import run as check_implementation


async def run(session_folder: str, lite: bool = False,
              depth: int | None = None,
              instructions: str | None = None,
              use_questions: bool = True) -> None:
    """Analyze agent logs and apply rule upgrades."""
    wf = Path(session_folder)
    wf.mkdir(parents=True, exist_ok=True)

    with context_scope(
        session_folder=str(wf.resolve()),
        lite=lite,
        depth=depth,
    ):
        update_session_run(str(wf.resolve()), "upgrade", lite=lite)
        await builder.run(stage="upgrade", instructions=instructions, use_questions=use_questions)
        await check_implementation("upgrade")


if __name__ == "__main__":
    from mixersystem.data.repository import run_cli
    run_cli(run)
