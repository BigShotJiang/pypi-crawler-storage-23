# <Title>

## What Changed

- `path/to/file` — what changed and why, one line per file

## Key Findings

The most important things learned — curated insights, unexpected discoveries, deviations from the plan, open issues, and anything that should inform the next run or the next person picking this up.

## Build Log

A full chronological account of the implementation — every meaningful step taken, what was built, what was revised, what was tested, what failed, what was retried, and how it was resolved. This is a raw, honest dump of what actually happened during the build, not a polished summary.

