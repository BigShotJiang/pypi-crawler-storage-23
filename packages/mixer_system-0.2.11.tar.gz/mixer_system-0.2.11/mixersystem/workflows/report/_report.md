# Report Workflow

The report workflow reads session artifacts and produces `report.md` — a concise summary of all changes made in the session, formatted as a conventional commit message.

## Inputs

- `session_folder` (required) — should typically contain completed artifacts (work.md, update.md, upgrade.md).
- `instructions` — optional free-text guidance injected into the artifact builder's prompt.

## Orchestration

The orchestrator (`create_report.py`) is straightforward — it calls the artifact builder once. No loops or sub-agents.

## Agents

**Artifact Builder** (`shared/artifact_builder.py`, stage `report`, model L) — reads all session artifacts (task.md, plan.md, work.md, update.md, upgrade.md) and synthesizes a concise report. Uses `type(scope): description` format with a bullet-point body. Only describes changes that actually happened — no invented additions. Writes `report.md` as the output.
