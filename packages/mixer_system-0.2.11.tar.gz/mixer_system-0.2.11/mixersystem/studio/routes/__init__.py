"""FastAPI dependency helpers for studio routes."""

from __future__ import annotations

from fastapi import Request

from mixersystem.studio.config import StudioConfig
from mixersystem.studio.event_bus import EventBus
from mixersystem.studio.process_manager import ProcessManager


def get_config(request: Request) -> StudioConfig:
    return request.app.state.config


def get_event_bus(request: Request) -> EventBus:
    return request.app.state.event_bus


def get_process_manager(request: Request) -> ProcessManager:
    return request.app.state.process_manager
