"""Push API route — git commit + archive + push."""

from __future__ import annotations

import asyncio

from fastapi import APIRouter, Depends

from mixersystem.studio.config import StudioConfig
from mixersystem.studio.routes import get_config

router = APIRouter(prefix="/api/v1", tags=["push"])


@router.post("/push")
async def trigger_push(config: StudioConfig = Depends(get_config)):
    from mixersystem.push import push

    exit_code = await asyncio.to_thread(push, project_root=str(config.project_root))

    if exit_code == 0:
        return {"status": "ok", "message": "Push complete."}
    else:
        return {"status": "error", "message": f"Push failed (exit code {exit_code})."}
