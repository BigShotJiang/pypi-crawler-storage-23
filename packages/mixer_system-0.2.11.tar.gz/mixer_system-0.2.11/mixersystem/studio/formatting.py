"""Shared formatting helpers for Studio."""

from __future__ import annotations


def fmt_duration(secs: float | None) -> str:
    if secs is None:
        return ""
    if secs < 60:
        return f"{secs:.1f}s"
    m, s = divmod(int(secs), 60)
    return f"{m}m {s}s"


def fmt_cost(cost: float | None) -> str:
    if cost is None:
        return "n/a"
    return f"${cost:.4f}"
