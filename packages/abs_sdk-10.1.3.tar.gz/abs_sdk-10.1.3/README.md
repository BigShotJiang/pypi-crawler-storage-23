# ABS Core Python SDK

Official Python SDK for [ABS Core](https://abscore.app) — AI Agent Governance Infrastructure.

## Installation

```bash
pip install abs-sdk
```

## Quick Start

```python
from abs_sdk import ABSClient

client = ABSClient(
    dsn="abs://my-workspace.abscore.app",
    token="abs_pat_xxx"
)

# Evaluate a tool call before executing
verdict = client.evaluate_tool("fs.write", {
    "path": "/etc/passwd",
    "content": "malicious"
})

if verdict.decision == "DENY":
    raise PermissionError(f"Blocked by ABS: {verdict.policy_result.reason}")

# Send agent heartbeat
client.heartbeat("agent-123")

# Check bond status
bond = client.get_bond("agent-123")
print(f"Bond balance: ${bond.balance}")
```

## Features

- **MCP Bridge**: Evaluate tool calls against the ABS Policy Engine (`evaluate_tool`, `evaluate_batch`)
- **Agent Management**: Register agents, send heartbeats, get status
- **Bond/Slash**: Create financial bonds, check slashing history
- **Audit Export**: Export governance audit trail
- **Local Entropy**: Calculate Shannon entropy offline (no API call)
- **Zero Dependencies**: Uses only Python stdlib (`urllib`, `json`, `math`)

## DSN Format

```
abs://<workspace-id>.abscore.app
```

## License

MIT — See [LICENSE](../../LICENSE) for details.
