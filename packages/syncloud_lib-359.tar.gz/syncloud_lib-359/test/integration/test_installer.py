from syncloudlib.integration.installer import local_install

def test_import():
    assert True