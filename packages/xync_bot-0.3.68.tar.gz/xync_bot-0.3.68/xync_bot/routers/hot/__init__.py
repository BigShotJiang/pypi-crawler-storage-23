import logging
from typing import Literal

from aiogram import Router, F
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.filters.callback_data import CallbackData
from aiogram.types import Message, CallbackQuery

from xync_bot.shared import BoolCd
from xync_schema import models

hot = Router(name="hot")


class HotCd(CallbackData, prefix="hot"):
    typ: Literal["sell", "buy"]
    cex: int = 4


@hot.message(Command("hot"))
async def start(msg: Message, xbt: "XyncBot"):  # noqa: F821
    me = msg.from_user
    user, _ = await models.User.tg_upsert(me, False)
    await xbt.go_hot(user, [4])


@hot.callback_query(BoolCd.filter(F.req.__eq__("is_you")))
async def is_you(query: CallbackQuery, callback_data: BoolCd, xbt: "XyncBot"):  # noqa: F821
    if not callback_data.res:
        try:
            await query.message.delete()
        except TelegramBadRequest as e:
            logging.error(e)
        return await query.answer("ok, sorry")

    order = await models.Order.get(id=callback_data.xtr).prefetch_related(
        "ad__pair_side__pair", "ad__my_ad", "ad__maker", "taker"
    )
    err, txt, user = await models.Actor.set_user(order.taker_id, query.from_user.id)
    if err == 1:
        await query.message.delete()
        return await query.answer(txt)

    await xbt.send_order(193017646, order.exid, txt)

    taker_user = await models.User.get(username_id=query.from_user.id)
    order.hot = await taker_user.get_last_hot()
    await order.save(update_fields=["hot_id"])

    try:
        await query.message.delete()
    except TelegramBadRequest as e:
        logging.error(e)
    return await query.answer("ok")
