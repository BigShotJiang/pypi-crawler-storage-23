# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

XyncBot is a Telegram bot for XyncPay - a peer-to-peer cryptocurrency and fiat payment network. Built with Python 3.12+, aiogram framework, and Tortoise ORM with PostgreSQL.

## Build & Development Commands

```bash
make install      # Install dependencies + setup pre-commit hooks
make build        # Build and publish to PyPI
make patch        # Create git tag with semantic version and push
make clean        # Remove build artifacts
```

**Running the bot:**
```bash
python -m xync_bot
```

**Running tests:**
```bash
pytest
```

**Linting/formatting:** Handled automatically by pre-commit hooks (Ruff with `--fix --unsafe-fixes`).

## Environment Variables

Copy `.env.dist` to `.env` and configure:
- `TOKEN` - Telegram bot token
- `POSTGRES_USER`, `POSTGRES_PASSWORD`, `POSTGRES_HOST`, `POSTGRES_PORT`, `POSTGRES_DB` - Database connection
- `API_DOMAIN` - API domain for webhook URL
- `WH_DOMAIN`, `TWA_DOMAIN` - Webhook and Telegram Web App domains

## Architecture

### Entry Point
`xync_bot/__main__.py` - Initializes Tortoise ORM and starts XyncBot with webhook.

### Core Classes
- **XyncBot** (`xync_bot/__init__.py`) - Extends `PGram.Bot`, registers routers, handles hot ads, orders, and transfers
- **Store** (`xync_bot/store.py`) - State management with:
  - `Store.Global` - Singleton with cached coins, currencies, exchanges, payment methods
  - `Store.Personal` - Per-user session state (actors, credentials)
  - `Store.Pr` - Payment request state

### Router Organization (in order of priority)
| Router | Path | Purpose |
|--------|------|---------|
| hot | `routers/hot/` | P2P "hot" trading ads from Bybit |
| send | `routers/send/` | User-to-user `/send` transfers |
| cond | `routers/cond/` | `/cond` - Parse trading condition synonyms |
| pay | `routers/pay/` | `/pay` - Payment request flow with FSM states |
| main | `routers/main/` | `/start`, referrals, forum management |
| last | `routers/__init__.py` | Fallback - deletes unwanted messages |

Additional handlers: `routers/vpn.py` (VPN config), `routers/photo.py` (admin exchange logo upload).

### Payment Flow FSM States (`routers/pay/dep.py`)
- `CredState` - Credential input (detail, name)
- `PaymentState` - Amount, timer settings
- `Report` - Payment complaints

### External Dependencies
- **PGram** - Custom aiogram wrapper (dev dependency)
- **xync-schema** - ORM models (User, Order, Transfer, Actor, Cred, etc.)
- **xn-auth** - Role-based permissions (Role enum: ADMIN, RESTRICTED, etc.)
- **x-model** - Tortoise ORM utilities

## Code Conventions

- Line length: 120 characters (Ruff)
- Parse mode: HTML for Telegram messages
- Comments/UI text: Russian language
- Callback data: Strongly-typed classes with prefixes (e.g., `pay_nav:`, `hot:`)
- Async/await throughout - asyncio + Tortoise ORM

## Git Workflow

Pre-commit hooks auto-run on:
- **pre-commit**: Ruff lint + format
- **post-commit**: Auto-tag if commit message starts with "feat" or contains "fix"
- **pre-push**: Auto-build and publish to PyPI on main branch

Versioning: Semantic versioning via `setuptools-scm` from git tags.