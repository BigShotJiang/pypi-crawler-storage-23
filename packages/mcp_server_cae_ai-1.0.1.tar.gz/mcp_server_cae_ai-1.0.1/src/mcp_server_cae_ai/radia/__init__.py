"""Radia MCP server: BEM/PEEC linting and documentation (21 rules, 8 tools)."""
