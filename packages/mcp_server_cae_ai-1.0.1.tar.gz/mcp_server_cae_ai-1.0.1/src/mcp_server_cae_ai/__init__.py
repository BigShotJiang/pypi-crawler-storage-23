"""
mcp-server-cae-ai: MCP servers for CAE simulation workflows.

Consolidates domain knowledge from Kindai University Sugahara Lab:
- Radia BEM/PEEC magnetostatics (fork) - linting & API docs
- NGSolve/ngbem FEM/BEM - usage patterns & pitfalls
- Coreform Cubit meshing - export workflows & scripting
- Cubit-to-Netgen high-order curving workflows
"""

__version__ = "1.0.1"
