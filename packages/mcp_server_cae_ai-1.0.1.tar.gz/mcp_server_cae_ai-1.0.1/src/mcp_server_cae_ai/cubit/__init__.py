"""Cubit MCP server: mesh export linting and documentation (16 rules, 12 tools)."""
