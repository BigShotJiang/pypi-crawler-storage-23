# tests/conftest.py
"""Shared test fixtures and utilities."""

# This file is automatically loaded by pytest and makes fixtures available to all tests.
# Note: Functions defined here are not importable directly - use pytest fixtures instead.
