#!/usr/bin/env python3

result = {
    "status": 200,
    "error": False,
    "data": {
        "movie": [
            {
                "id": "4218",
                "title": "Jujutsu Kaisen",
                "synopsis": "Terlibat dalam aktivitas paranormal yang tidak berdasar dengan Klub Ilmu Gaib, siswa SMA Yuuji Itadori menghabiskan hari-harinya di ruang klub atau rumah sakit, tempat ia mengunjungi kakeknya yang terbaring di tempat tidur. Namun, gaya hidup santai ini segera berubah menjadi aneh ketika ia tanpa sadar menemukan benda terkutuk. Memicu serangkaian kejadian supernatural, Yuuji mendapati dirinya tiba-tiba terlempar ke dunia Kutukan—makhluk mengerikan yang terbentuk dari kebencian dan kenegatifan manusia—setelah menelan benda tersebut, yang ternyata adalah jari milik iblis Sukuna Ryoumen, Raja Kutukan.\r\n\r\nYuuji mengalami sendiri ancaman Kutukan ini terhadap masyarakat saat ia menemukan kekuatan barunya sendiri. Diperkenalkan ke Sekolah Menengah Jujutsu Prefektur Tokyo, ia mulai berjalan di jalan yang tidak dapat ia lalui kembali—jalan seorang penyihir Jujutsu.",
                "synonyms": "Sorcery Fight, JJK, 呪術廻戦",
                "image_poster": "https://api.animein.net/assets/images/movie/poster/f945fb40d51bbe5be0ec01b87395baaf.jpg",
                "image_cover": "https://api.animein.net//assets/images/movie/cover/fa74358ee6d4a1d17e5533fd634e9d77.jpg",
                "type": "SERIES",
                "year": "2021",
                "day": "RANDOM",
                "status": "FINISHED",
                "views": "823288",
                "favorites": "16203",
                "aired_start": "2020-10-03",
                "genre": "Action,Comedy,Demons,Horror,School,Shounen,Supernatural"
            },
            {
                "id": "4722",
                "title": "Jujutsu Kaisen 2nd Season",
                "synopsis": "Tahun 2006, dan aula Sekolah Menengah Jujutsu Prefektur Tokyo bergema dengan pertengkaran tak berujung dan perdebatan sengit antara dua sahabat karib yang tak terpisahkan. Memancarkan kepercayaan diri yang tak tergoyahkan, Satoru Gojou dan Suguru Getou percaya tidak ada tantangan yang terlalu besar bagi penyihir Kelas Khusus yang muda dan kuat seperti mereka. Mereka ditugaskan untuk mengantarkan seorang gadis waras bernama Riko Amanai dengan selamat ke entitas yang keberadaannya merupakan inti dari dunia jujutsu. Namun, misi tersebut menjerumuskan mereka ke dalam pusaran konflik moral yang melelahkan yang mengancam untuk menghancurkan persahabatan yang sudah lemah antara penyihir dan manusia biasa.\n\nDua belas tahun kemudian, para siswa dan penyihir menjadi garis depan pertahanan terhadap meningkatnya jumlah kutukan tingkat tinggi yang lahir dari emosi negatif manusia. Saat entitas tersebut tumbuh dalam kekuatan, kesadaran diri dan ambisi mereka juga meningkat. Kutukan-kutukan itu bersatu untuk tujuan bersama yaitu membasmi manusia dan menciptakan dunia yang hanya berisi pengguna energi terkutuk, yang dipimpin oleh roh terkutuk kuno yang berbahaya. Untuk menyingkirkan rintangan terbesar mereka—penyihir terkuat, Gojou—mereka mengatur serangan di Stasiun Shibuya pada hari Halloween. Terbagi menjadi beberapa tim, para penyihir memasuki pertarungan dengan siap mempertaruhkan segalanya untuk melindungi orang-orang yang tidak bersalah dan kaum mereka sendiri.",
                "synonyms": "Sorcery Fight, JJK 2, 呪術廻戦 第2期",
                "image_poster": "https://api.animein.net//assets/images/movie/poster/5182d48e4b8020f50280c44218f3a40d.jpg",
                "image_cover": "https://api.animein.net//assets/images/movie/cover/f224e6d03c519d6968f5fc93112d255e.jpg",
                "type": "SERIES",
                "year": "2023",
                "day": "RANDOM",
                "status": "FINISHED",
                "views": "704244",
                "favorites": "7754",
                "aired_start": "2023-07-05",
                "genre": "Action,Fantasy,Mystery,Psychological,School,Shounen,Supernatural"
            },
            {
                "id": "6178",
                "title": "Jujutsu Kaisen: Shimetsu Kaiyuu - Zenpen",
                "synopsis": "Sequel dari Jujutsu Kaisen season ke-2",
                "synonyms": "Jujutsu Kaisen: The Culling Game Part 1, Jujutsu Kaisen 3rd Season",
                "image_poster": "https://xyz-api.animein.net//assets_xyz/images/movie/poster/27fb26140ed2f99638e9b23310159c63.jpg",
                "image_cover": "https://xyz-api.animein.net//assets_xyz/images/movie/cover/9de35e0d5c449aa250ca6294b2893bf7.jpg",
                "type": "SERIES",
                "year": "2026",
                "day": "KAMIS",
                "status": "ONGOING",
                "views": "136954",
                "favorites": "7627",
                "aired_start": "2026-01-09",
                "genre": "Action,School,Supernatural"
            },
            {
                "id": "4488",
                "title": "Jujutsu Kaisen 0 Movie",
                "synopsis": "Kemalangan yang hebat sering terjadi di sekitar Yuuta Okkotsu yang berusia 16 tahun, seorang korban bullying di sekolah menengah yang pemalu. Yuuta dibebani dengan kutukan yang mengerikan, kekuatan yang memberikan balas dendam brutal terhadap para pengganggunya. Rika Orimoto, kutukan Yuuta, adalah bayangan dari masa kecilnya yang tragis dan ancaman yang berpotensi mematikan bagi siapa pun yang berani menyakitinya.\n\nSituasi unik Yuuta menarik perhatian Satoru Gojou, seorang penyihir kuat yang mengajar di Sekolah Menengah Jujutsu Prefektur Tokyo. Gojou melihat potensi yang sangat besar dalam diri Yuuta, dan dia berharap dapat membantu bocah itu menyalurkan beban mematikannya menjadi kekuatan untuk kebaikan. Namun Yuuta berjuang untuk menemukan tempatnya di antara teman-teman sekelasnya yang berbakat: Toge Inumaki yang bisu selektif, ahli senjata Maki Zenin, dan Panda.\n\nYuuta dengan kikuk memanfaatkan Rika dalam misi bersama siswa tahun pertama lainnya, tetapi akibat mengerikan dari pertunjukan kekuatan luar biasa Rika menarik minat pengguna kutukan yang penuh perhitungan, Suguru Getou. Saat Getou berusaha keras untuk mendapatkan kekuatan Rika dan menggunakannya untuk melenyapkan semua pengguna non-jujutsu di dunia, Yuuta bertarung bersama teman-temannya untuk menghentikan rencana genosida.",
                "synonyms": "Gekijouban Jujutsu Kaisen 0, 劇場版 呪術廻戦 0",
                "image_poster": "https://api.animein.net//assets/images/movie/poster/1b9ef4d49813e93d283978e92c36761b.jpg",
                "image_cover": "https://api.animein.net//assets/images/movie/cover/117973674283cc42af498303ccf23d93.jpg",
                "type": "MOVIE",
                "year": "2021",
                "day": "RANDOM",
                "status": "FINISHED",
                "views": "76399",
                "favorites": "4269",
                "aired_start": "2021-12-24",
                "genre": "Action,Demons,School,Shounen,Supernatural"
            },
            {
                "id": "5388",
                "title": "JJK as BABIES",
                "synopsis": "Animasi Buatan Fans\r\n\r\nThis scene is inspired by/based on the anime (audio and original frames, all credits to) Gakuen Babysitters. \r\n\r\nI do not intend to own the audio nor the frames of the anime, I only recreated this scene for fanmade entertainment. \r\n\r\nCredits to the following for the original anime/manga: \r\n\r\nManga Series Title: School Babysitters \r\nManga Author : Hari Tokeino\r\nAnimation Studio: Brain's Base\r\nPublished by: Hakusensha\r\nVoice Actors : Yūko Sanpei, Nozomi Furuki, Konami Kohara\r\n\r\nIf you guys want to repost this video, please make sure to give me and the mentioned creators, voice actors, and studio for credits and provide the link of this video. I hope you consider the time and effort I spent to reproduce the video. Thank you! \r\n\r\nSource : Youtube \"Akacchi\"",
                "synonyms": "Jujutsu Kaisen as Babies, JJK",
                "image_poster": "https://api.animein.net//assets/images/movie/poster/977a1a1e4309d21628ee7742cc99c6f3.jpg",
                "image_cover": "https://api.animein.net//assets/images/movie/cover/56e4dff71cf994890e66e8549fd1209c.jpg",
                "type": "SPECIAL",
                "year": "2024",
                "day": "RANDOM",
                "status": "FINISHED",
                "views": "15069",
                "favorites": "1262",
                "aired_start": "2024-02-14",
                "genre": "Comedy,Parody"
            },
            {
                "id": "6274",
                "title": "Jujutsu Kaisen: Kaigyoku/Gyokusetsu",
                "synopsis": "Film kompilasi dari arc Inventaris Tersembunyi dan Kematian Dini dari Jujutsu Kaisen.\n\nSebelum menjadi musuh, Satoru Gojo dan Suguru Geto adalah teman sekelas dan sahabat di sekolah menengah. Kedua penyihir berkuasa ini ditugaskan untuk melindungi Riko Amanai, seorang siswa yang ditunjuk sebagai Star Plasma Vessel, hingga ia dapat menunaikan tugasnya. Dikejar oleh sekte agama dan pengguna kutukan lainnya, mereka adalah penyihir-penyihir satu-satunya yang mampu melaksanakan tugas sulit ini – namun misi ini akan menentukan nasib mereka dan menantang kedua penyihir tersebut dengan cara yang tak terbayangkan. Arc “Hidden Inventory / Premature Death” yang sangat dicintai dan penuh emosi dari fenomena global JUJUTSU KAISEN kembali ke layar lebar, mencapai puncak baru bagi penggemar dan pendatang baru.",
                "synonyms": "Jujutsu Kaisen: Hidden Inventory/Premature Death",
                "image_poster": "https://xyz-api.animein.net//assets_xyz/images/movie/poster/49c33bee6bb80aaedaee80071a60b1ab.jpg",
                "image_cover": "https://xyz-api.animein.net//assets_xyz/images/movie/cover/c0286eabee06e95f3e4461fe2a1127c9.jpg",
                "type": "MOVIE",
                "year": "2026",
                "day": "RANDOM",
                "status": "FINISHED",
                "views": "6155",
                "favorites": "662",
                "aired_start": "2025-05-30",
                "genre": "Action,School,Shounen,Supernatural"
            }
        ]
    }
}

data_list = result['data']['movie']

# print(data_list[1]['id'])

# get_id =[ x for x in (lambda x: x.get('id') if x else None)]
# anime_id =  sorted(data_list, key=lambda x: x['id'])
# anime_id = list(map(lambda x: x.get('id'), data_list))
# print(anime_id)

# rs = get_id(data_list)
# print(rs)
# for idx in data_list:
    # print(idx['id'])
    
# BASE_URL = r'https?://animeinweb\.com/%s'
# 
# print(BASE_URL)
# p = []
# if not p:
    # print('d')
# print(type([]))


au = '720p'
# au = int(au)
# print(au.group(1))

import re
match = re.match(r'^(\d+)p?$', au, re.IGNORECASE)
if match:
    print(int(match.group(1)))