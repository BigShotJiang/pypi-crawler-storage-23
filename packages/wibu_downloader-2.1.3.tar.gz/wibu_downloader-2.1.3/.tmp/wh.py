#!/usr/bin/env python3


from yt_dlp.utils import int_or_none, urljoin, str_to_int, float_or_none, parse_resolution

f = parse_resolution('360p')
if f and isinstance(f,dict):
    print(type(f['height']))
