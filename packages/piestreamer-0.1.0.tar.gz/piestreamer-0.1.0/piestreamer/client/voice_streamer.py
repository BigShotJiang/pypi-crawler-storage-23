import base64
import io
import struct
import wave
from multiprocessing import Process, Queue
from typing import Optional

import socketio
from pvrecorder import PvRecorder


class VoiceStreamer(object):
    def __init__(self, url: str, auth_token: str, duration: Optional[float] = None):
        super(VoiceStreamer, self).__init__()
        self.url = url
        self.auth_token = auth_token
        self.duration = duration

    def run(self, logger=True, namespaces=["/"]):
        sio = socketio.Client(logger=logger, engineio_logger=True)

        self.chunks_queue = Queue()
        self.commands_queue = Queue()
        self.recording_process = Process(
            target=self.start_recording_worker,
            args=(
                self.commands_queue,
                self.chunks_queue,
            ),
        )
        self.recording_process.start()

        @sio.on("connect")
        def connect():
            print("Connected.")

        @sio.on("disconnect")
        def disconnect():
            print("Disconnected.")

        @sio.on("success")
        def on_success(data):
            print("Success.", data)
            self.send_chunk(sio)

        @sio.on("error")
        def on_error(data):
            print("Error.", data)
            self.stop_recording()

        @sio.on("auth_success")
        def on_auth_success(data):
            print("Auth Success.", data)
            self.start_recording()
            self.send_chunk(sio)

        @sio.on("auth_error")
        def on_auth_error(data):
            print("Auth Error.", data)

        sio.connect(self.url, namespaces=namespaces)
        sio.emit("auth", {"auth_token": self.auth_token})

        try:
            sio.wait()
        except KeyboardInterrupt:
            self.stop_recording()
            self.send_chunk(sio, block=False)
            sio.emit("stop", {})

    def start_recording(self):
        self.commands_queue.put("RUN")

    def stop_recording(self):
        self.commands_queue.put("STOP")
        self.recording_process.join()
        self.recording_process.close()

    def pop_chunk(self, block=True):
        return self.chunks_queue.get(block=block)

    def send_chunk(self, sio, block=True):
        chunk = self.pop_chunk(block=block)
        if chunk is None:
            return

        try:
            sio.emit(
                "audio",
                {
                    "audio": {
                        "dataURL": f"data:audio/wav;base64,{base64.b64encode(chunk).decode('utf-8')}"
                    },
                    # "end_dt": datetime.now(tz=timezone.utc)
                },
            )
        except Exception:
            return

    def start_recording_worker(self, commands: Queue, queue: Queue):
        recorder = PvRecorder(device_index=-1, frame_length=512)
        command = commands.get(block=True)
        if command != "RUN":
            return

        print("Starting recording worker")
        recorder.start()

        while True:
            print("Iterating recording worker")
            try:
                command = commands.get(block=False)
                if command == "STOP":
                    break
            except Exception:
                pass

            frame = recorder.read()
            buffer = io.BytesIO()
            with wave.open(buffer, "w") as f:
                f.setparams((1, 2, 16000, 512, "NONE", "NONE"))
                f.writeframes(struct.pack("h" * len(frame), *frame))
            buffer.flush()
            buffer.seek(0)
            queue.put(buffer.getvalue())
            buffer.close()

        print("Stopping recording worker")
        recorder.stop()
        recorder.delete()
