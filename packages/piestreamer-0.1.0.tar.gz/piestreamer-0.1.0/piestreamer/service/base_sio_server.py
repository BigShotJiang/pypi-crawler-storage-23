import os
import sys
import tempfile
from datetime import timedelta
from pathlib import Path
from urllib.request import urlopen

import redis
from fastapi_socketio import SocketManager

from ..db.media_segment_storage import MediaSegmentStorage
from ..streamers.utils import get_duration_ffmpeg


class BaseSIOServer:
    def __init__(
        self,
        storage: MediaSegmentStorage,
        sio: SocketManager,
        cache: redis.StrictRedis,
        audio_format=".mp3",
        video_format=".mp4",
        kAuthName="auth",
        kStopName="stop",
        kGetAudioName="audio",
        kGetVideoName="video",
        kAuthSuccess="auth_success",
        kAuthError="auth_error",
        kSuccess="success",
        kError="error",
    ):
        self.sio = sio
        self.storage = storage
        self.cache = cache
        self.cache.ping()

        self.audio_format = audio_format
        self.video_format = video_format

        self.kSuccess = kSuccess
        self.kError = kError
        self.kAuthSuccess = kAuthSuccess
        self.kAuthError = kAuthError

        @sio.on(kAuthName)
        async def handle_auth(sid, data):
            try:
                data = self.retrieve(data)
            except Exception:
                await self.emit_auth_error(
                    sid, f"Event: {kAuthName}; Error: Can't retrieve from data."
                )
                return

            if data is None:
                await self.emit_auth_error(
                    sid, f"Event: {kAuthName}; Error: No auth data."
                )
                return

            try:
                filename = await self.authenticate(sid, data)
            except Exception:
                await self.emit_auth_error(
                    sid, f"Event: {kAuthName}; Error: Can't authenticate with data."
                )
                return

            if filename is None:
                await self.emit_auth_error(
                    sid, f"Event: {kAuthName}; Error: User not found"
                )
                return

            self.cache.set(sid, filename)
            await self.emit_auth_success(sid, f"Event: {kAuthName}")

        @sio.on(kStopName)
        async def handle_stop(sid, data):
            self.cache.delete(sid)
            await self.emit_success(sid, f"Event: {kStopName}")

        @sio.on(kGetAudioName)
        async def handle_audio_stream(sid, data: dict):
            filename = self.cache.get(sid)
            if filename is None:
                await self.emit_error(
                    sid, f"Event: {kGetAudioName}; Error: User/sid not found."
                )
                return

            try:
                data: dict = self.retrieve(data)
            except Exception as exc:
                await self.emit_error(
                    sid,
                    f"Event: {kGetAudioName}; Error: Can't retrieve from data. {exc}",
                )
                return

            try:
                audio_data = urlopen(data["audio"])
                content = audio_data.read()
            except Exception as exc:
                await self.emit_error(
                    sid,
                    f"Event: {kGetAudioName}; Error: Can't decode {self.audio_format} format. {exc}",
                )
                return

            with tempfile.TemporaryDirectory() as temp_dir:
                audio_path = Path(os.path.join(temp_dir, f"temp{self.audio_format}"))
                with audio_path.open("wb") as f:
                    f.write(content)

                start_dt = data.get("start_dt")
                end_dt = data["end_dt"]
                if "start_dt" not in data:
                    duration = get_duration_ffmpeg(audio_path)
                    start_dt = end_dt - timedelta(seconds=duration)
                else:
                    start_dt = data["start_dt"]

                try:
                    grid_id = self.storage.add(
                        filename=filename,
                        start_dt=start_dt,
                        end_dt=end_dt,
                        path=audio_path,
                    )
                except Exception as exc:
                    await self.emit_error(
                        sid, f"Event: {kGetAudioName}; Error: Can't access CDN. {exc}"
                    )
                    return
                print(f"Got Grid ID {grid_id}")

            await self.emit_success(sid, f"Event: {kGetAudioName}; Grid ID: {grid_id}")

        @sio.on(kGetVideoName)
        async def handle_video_stream(sid, data: dict):
            filename = self.cache.get(sid)
            if filename is None:
                await self.emit_error(
                    sid, f"Event: {kGetVideoName}; Error: User/sid not found"
                )
                return
            try:
                data: dict = self.retrieve(data)
            except Exception as exc:
                await self.emit_error(
                    sid,
                    f"Event: {kGetVideoName}; Error: Can't retrieve from data. {exc}",
                )
                return

            with tempfile.TemporaryDirectory() as temp_dir:
                video_path = Path(os.path.join(temp_dir, f"temp{self.video_format}"))
                with video_path.open("wb") as f:
                    video_data = urlopen(data["video"])
                    f.write(video_data.read())

                start_dt = data.get("start_dt")
                end_dt = data["end_dt"]
                if not start_dt:
                    duration = get_duration_ffmpeg(video_path)
                    start_dt = end_dt - timedelta(seconds=duration)

                grid_id = self.storage.add(
                    filename=filename, start_dt=start_dt, end_dt=end_dt, path=video_path
                )
                print(f"Got Grid ID {grid_id}", file=sys.stderr)

            await self.emit_success(sid, f"Event: {kGetVideoName}; Grid ID: {grid_id}")

    def retrieve(self, data):
        raise NotImplementedError()

    async def authenticate(self, sid, data):
        raise NotImplementedError()

    async def emit_success(self, sid, message):
        await self.sio.emit(self.kSuccess, {"message": message}, to=sid)

    async def emit_error(self, sid, message):
        await self.sio.emit(self.kError, {"message": message}, to=sid)

    async def emit_auth_success(self, sid, message):
        await self.sio.emit(self.kAuthSuccess, {"message": message}, to=sid)

    async def emit_auth_error(self, sid, message):
        await self.sio.emit(self.kAuthError, {"message": message}, to=sid)


class SimpleSIOServer(BaseSIOServer):
    async def authenticate(self, sid, data):
        return sid

    def retrieve(self, data):
        return data
