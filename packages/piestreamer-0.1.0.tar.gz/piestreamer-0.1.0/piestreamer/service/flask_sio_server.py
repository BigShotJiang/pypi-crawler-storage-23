import os
import sys
import tempfile
from datetime import timedelta
from pathlib import Path
from urllib.request import urlopen

import redis
from flask import request
from flask_socketio import SocketIO, emit

from ..db.media_segment_storage import MediaSegmentStorage
from ..streamers.utils import get_duration_ffmpeg


class BaseSIOServer(object):
    def __init__(
        self,
        storage: MediaSegmentStorage,
        sio: SocketIO,
        cache: redis.StrictRedis,
        audio_format=".mp3",
        video_format=".mp4",
        kAuthName="auth",
        kStopName="stop",
        kGetAudioName="audio",
        kGetVideoName="video",
        kAuthSuccess="auth_success",
        kAuthError="auth_error",
        kSuccess="success",
        kError="error",
    ):
        super(BaseSIOServer, self).__init__()
        self.sio = sio
        self.storage = storage
        self.cache = cache
        self.cache.ping()

        self.audio_format = audio_format
        self.video_format = video_format

        self.kSuccess = kSuccess
        self.kError = kError
        self.kAuthSuccess = kAuthSuccess
        self.kAuthError = kAuthError

        @sio.on(kAuthName)
        def handle_auth(data):
            sid = request.sid
            try:
                data = self.retrieve(data)
            except Exception:
                self.emit_auth_error(
                    f"Event: {kAuthName}; Error: Can't retrieve from data"
                )
                return

            if data is None:
                self.emit_auth_error(f"Event: {kAuthName}; Error: No auth data")
                return

            try:
                filename = self.authenticate(sid, data)
            except Exception:
                self.emit_auth_error(
                    f"Event: {kAuthName}; Error: Can't authenticate with data"
                )
                return

            if filename is None:
                self.emit_auth_error(f"Event: {kAuthName}; Error: User not found")
                return

            self.cache.set(sid, filename)
            self.emit_auth_success(f"Event: {kAuthName}")

        @sio.on(kStopName)
        def handle_stop(data):
            sid = request.sid
            self.cache.delete(sid)
            self.emit_success(f"Event: {kStopName}")

        @sio.on(kGetAudioName)
        def handle_audio_stream(data):
            sid = request.sid
            filename = self.cache.get(sid)
            if filename is None:
                self.emit_error(f"Event: {kGetAudioName}; Error: User/sid not found")
                return

            try:
                data = self.retrieve(data)
            except Exception:
                self.emit_error(
                    f"Event: {kGetAudioName}; Error: Can't retrieve from data"
                )
                return

            try:
                content = urlopen(data["audio"]).read()
            except Exception:
                self.emit_error(
                    f"Event: {kGetAudioName}; Error: Can't decode {self.audio_format} format."
                )
                return
            with tempfile.TemporaryDirectory() as temp_dir:
                audio_path = Path(os.path.join(temp_dir, f"temp{audio_format}"))
                with audio_path.open("wb") as f:
                    f.write(content)

                end_dt = data["end_dt"]
                if "start_dt" not in data:
                    duration = get_duration_ffmpeg(audio_path)
                    start_dt = end_dt - timedelta(seconds=duration)
                else:
                    start_dt = data["start_dt"]

                try:
                    grid_id = self.storage.add(
                        filename=filename,
                        start_dt=start_dt,
                        end_dt=end_dt,
                        path=audio_path,
                    )
                except Exception:
                    self.emit_error(f"Event: {kGetAudioName}; Error: Can't access CDN.")
                    return
                print(f"Got Grid ID {grid_id}")

            self.emit_success(f"Event: {kGetAudioName}; Grid ID: {grid_id}")

        @sio.on(kGetVideoName)
        def handle_video_stream(data):
            sid = request.sid
            filename = self.cache.get(sid)
            if filename is None:
                self.emit_error(f"Event: {kGetVideoName}; Error: User/sid not found")
                return
            try:
                data = self.retrieve(data)
            except Exception:
                self.emit_error(
                    f"Event: {kGetVideoName}; Error: Can't retrieve from data"
                )
                return

            with tempfile.TemporaryDirectory() as temp_dir:
                video_path = Path(os.path.join(temp_dir, f"temp{video_format}"))
                with video_path.open("wb") as f:
                    f.write(urlopen(data["video"]).read())

                end_dt = data["end_dt"]
                if "start_dt" not in data:
                    duration = get_duration_ffmpeg(video_path)
                    start_dt = end_dt - timedelta(seconds=duration)
                else:
                    start_dt = data["start_dt"]

                grid_id = self.storage.add(
                    filename=filename, start_dt=start_dt, end_dt=end_dt, path=video_path
                )
                print(f"Got Grid ID {grid_id}", file=sys.stderr)

            self.emit_success(f"Event: {kGetVideoName}; Grid ID: {grid_id}")

    def run(self, *args, **kwargs):
        return self.sio.run(*args, **kwargs)

    def retrieve(self, data):
        raise NotImplementedError()

    def authenticate(self, sid, data):
        raise NotImplementedError()

    def emit_success(self, message):
        sid = request.sid
        emit(self.kSuccess, {"message": message}, to=sid)

    def emit_error(self, message):
        sid = request.sid
        emit(self.kError, {"message": message}, to=sid)

    def emit_auth_success(self, message):
        sid = request.sid
        emit(self.kAuthSuccess, {"message": message}, to=sid)

    def emit_auth_error(self, message):
        sid = request.sid
        emit(self.kAuthError, {"message": message}, to=sid)


class SimpleSIOServer(BaseSIOServer):
    def authenticate(self, sid, data):
        return sid

    def retrieve(self, data):
        return data
