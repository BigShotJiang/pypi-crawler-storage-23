import asyncio
import random
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from time import sleep
from typing import Dict

from ..cdn.async_base import AsyncBaseCDN
from ..db.async_video_storage import AsyncVideoStorage
from ..streamers.async_ffmpeg import AsyncFfmpegStreamer


class AsyncCaptureService(object):
    def __init__(
        self,
        storage: AsyncVideoStorage,
        fps: int = 1,
        segment_time: int = 8,
        segment_frames_num: int = 128,
        cache_dir: Path = None,
        debug: bool = False,
    ):
        super(AsyncCaptureService, self).__init__()
        if cache_dir is None:
            cache_dir = tempfile.TemporaryDirectory().name
        self.cache_dir = Path(cache_dir)

        self.storage = storage
        self.streamers: Dict[str, AsyncFfmpegStreamer] = {}

        self.fps = fps
        self.segment_time = segment_time
        self.segment_frames_num = segment_frames_num
        self.debug = debug

    async def capture_frames(self, dry_run=False):
        capture_frames_start_dt = datetime.now()
        if self.debug:
            print("Capturing frames...", file=sys.stderr)
        rooms = await self.get_rooms()
        room_ids = [str(room["_id"]) for room in rooms]

        for room in rooms:
            room_id = str(room["_id"])
            if (
                room_id not in self.streamers
                or str(self.streamers[room_id].rtsp_url) != str(room["room_url"])
                or (not self.streamers[room_id].running)
            ):
                if room_id in self.streamers:
                    await self.streamers.pop(room_id).stop()
                self.streamers[room_id] = AsyncFfmpegStreamer(
                    rtsp_url=str(room["room_url"]),
                    output_dir=self.cache_dir / f"{room_id}",
                    fps=self.fps,
                    segment_frames_num=self.segment_frames_num,
                    segment_time=self.segment_time,
                    debug=self.debug,
                )
                await self.streamers[room_id].run(dry_run=dry_run)

            if dry_run:
                continue

            saved_video_paths = sorted(list((self.cache_dir / f"{room_id}").iterdir()))
            if len(saved_video_paths) >= 2:
                await self.storage.add(
                    filename=str(room_id),
                    video_path=saved_video_paths[0],
                    fps=self.fps,
                    force_frames_num=self.segment_frames_num,
                    delete_after=True,
                )
                if self.debug:
                    print(
                        f"Uploaded: {str(room_id)}; Path: {saved_video_paths[0].name}",
                        file=sys.stderr,
                    )

        if dry_run:
            return

        for room_id in list(self.streamers.keys()):
            if room_id not in room_ids:
                await self.streamers.pop(room_id).stop()

        if self.debug and len(rooms) > 0:
            capture_frames_end_dt = datetime.now()
            print(
                f"Capture frames duration: {(capture_frames_end_dt - capture_frames_start_dt).total_seconds()}\n",
                f"Cache dir: {self.cache_dir}\n",
                f"Number of streamers: {len(self.streamers)}\n",
                file=sys.stderr,
            )
            room = random.choice(rooms)
            print(
                "Random room status:\n",
                await self.streamers[str(room["_id"])].status(),
                file=sys.stderr,
            )

    async def run(self, dry_run=False):
        if dry_run:
            return await self.capture_frames(dry_run=dry_run)

        while True:
            await self.capture_frames()
            await asyncio.sleep(1)

    async def get_rooms(self):
        raise NotImplementedError()

    async def stop(self):
        for room_id in list(self.streamers.keys()):
            await self.streamers.pop(room_id).stop()
