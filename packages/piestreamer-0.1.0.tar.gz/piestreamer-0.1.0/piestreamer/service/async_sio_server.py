import asyncio
import os
import sys
import tempfile
from datetime import timedelta
from pathlib import Path
from typing import Any
from urllib.request import urlopen

import aiofiles
from fastapi_socketio import SocketManager
from redis.asyncio import Redis

from ..db.async_media_storage import AsyncMediaStorage
from ..streamers.utils import get_duration_ffmpeg


class AsyncSIOServer:
    def __init__(
        self,
        storage: AsyncMediaStorage,
        sio: SocketManager,
        cache: Redis,
        audio_format: str = ".mp3",
        video_format: str = ".mp4",
        kAuthName: str = "auth",
        kStopName: str = "stop",
        kGetAudioName: str = "audio",
        kGetVideoName: str = "video",
        kAuthSuccess: str = "auth_success",
        kAuthError: str = "auth_error",
        kSuccess: str = "success",
        kError: str = "error",
    ):
        self.sio = sio
        self.storage = storage
        self.cache = cache

        asyncio.create_task(self._check_redis_connection())

        self.audio_format = audio_format
        self.video_format = video_format
        self.kSuccess = kSuccess
        self.kError = kError
        self.kAuthSuccess = kAuthSuccess
        self.kAuthError = kAuthError

        @sio.on(kAuthName)
        async def handle_auth(sid, data: dict):
            try:
                data = await self.retrieve(data)
            except Exception as exc:
                await self.emit_auth_error(
                    sid, f"Event: {kAuthName}; Error: Can't retrieve from data. {exc}"
                )
                return

            if data is None:
                await self.emit_auth_error(
                    sid, f"Event: {kAuthName}; Error: No auth data."
                )
                return

            try:
                filename = await self.authenticate(sid, data)
            except Exception as exc:
                await self.emit_auth_error(
                    sid,
                    f"Event: {kAuthName}; Error: Can't authenticate with data. {exc}",
                )
                return

            if not filename:
                await self.emit_auth_error(
                    sid, f"Event: {kAuthName}; Error: User not found."
                )
                return

            await self.cache.set(sid, filename)
            await self.emit_auth_success(sid, f"Event: {kAuthName}")

        @sio.on(kStopName)
        async def handle_stop(sid, data: dict):
            await self.cache.delete(sid)
            await self.emit_success(sid, f"Event: {kStopName}")

        @sio.on(kGetAudioName)
        async def handle_audio_stream(sid, data: dict):
            filename = await self.cache.get(sid)
            if not filename:
                await self.emit_error(
                    sid, f"Event: {kGetAudioName}; Error: User/sid not found"
                )
                return

            try:
                data: dict = await self.retrieve(data)
            except Exception as exc:
                await self.emit_error(
                    sid,
                    f"Event: {kGetAudioName}; Error: Can't retrieve from data. {exc}",
                )
                return

            try:
                audio_data = urlopen(data["audio"])
                content = audio_data.read()
            except Exception as exc:
                format = self.audio_format
                await self.emit_error(
                    sid,
                    f"Event: {kGetAudioName}; Error: Can't decode {format} format. {exc}",
                )
                return

            with tempfile.TemporaryDirectory() as temp_dir:
                try:
                    audio_path = Path(
                        os.path.join(temp_dir, f"temp{self.audio_format}")
                    )
                    async with aiofiles.open(audio_path, "wb") as f:
                        await f.write(content)

                    start_dt = data.get("start_dt")
                    end_dt = data["end_dt"]
                    if not start_dt:
                        duration = await asyncio.to_thread(
                            get_duration_ffmpeg, audio_path
                        )
                        start_dt = end_dt - timedelta(seconds=duration)
                except Exception as exc:
                    await self.emit_error(
                        sid,
                        f"Event: {kGetAudioName}; Error: Can't handle audio {audio_path}. {exc}",
                    )
                    return

                try:
                    grid_id = await self.storage.add(
                        filename, start_dt=start_dt, end_dt=end_dt, path=audio_path
                    )
                except Exception as exc:
                    await self.emit_error(
                        sid, f"Event: {kGetAudioName}; Error: Can't access CDN. {exc}"
                    )
                    return
                print(f"Got Grid ID {grid_id}", file=sys.stderr)

            await self.emit_success(sid, f"Event: {kGetAudioName}; Grid ID: {grid_id}")

        @sio.on(kGetVideoName)
        async def handle_video_stream(sid, data: dict):
            filename = await self.cache.get(sid)
            if not filename:
                await self.emit_error(
                    sid, f"Event: {kGetVideoName}; Error: User/sid not found"
                )
                return
            try:
                data: dict = await self.retrieve(data)
            except Exception as exc:
                await self.emit_error(
                    sid,
                    f"Event: {kGetVideoName}; Error: Can't retrieve from data. {exc}",
                )
                return

            video_url = data.get("video")
            if not video_url:
                await self.emit_error(
                    sid, f"Event: {kGetVideoName}; Error: Missing video URL."
                )
                return

            with tempfile.TemporaryDirectory() as temp_dir:
                video_path = Path(os.path.join(temp_dir, f"temp{self.video_format}"))
                try:
                    video_data = urlopen(data["video"])
                    async with aiofiles.open(video_path, "wb") as f:
                        await f.write(video_data.read())
                except Exception as exc:
                    await self.emit_error(
                        sid,
                        f"Event: {kGetVideoName}; Error: Can't fetch video URL. {exc}",
                    )
                    return

                start_dt = data.get("start_dt")
                end_dt = data["end_dt"]
                if not start_dt:
                    duration = await asyncio.to_thread(get_duration_ffmpeg, video_path)
                    start_dt = end_dt - timedelta(seconds=duration)

                try:
                    grid_id = await self.storage.add(
                        filename, start_dt=start_dt, end_dt=end_dt, path=video_path
                    )
                except Exception as exc:
                    await self.emit_error(
                        sid, f"Event: {kGetVideoName}; Error: Can't access CDN. {exc}"
                    )
                    return

                grid_id = self.storage.add(
                    filename=filename, start_dt=start_dt, end_dt=end_dt, path=video_path
                )
                print(f"Got Grid ID {grid_id}", file=sys.stderr)

            await self.emit_success(sid, f"Event: {kGetVideoName}; Grid ID: {grid_id}")

    async def retrieve(self, data: Any):
        raise NotImplementedError()

    async def authenticate(self, sid: str, data: Any):
        raise NotImplementedError()

    async def emit_success(self, sid, message):
        await self.sio.emit(self.kSuccess, {"message": message}, to=sid)

    async def emit_error(self, sid, message):
        await self.sio.emit(self.kError, {"message": message}, to=sid)

    async def emit_auth_success(self, sid, message):
        await self.sio.emit(self.kAuthSuccess, {"message": message}, to=sid)

    async def emit_auth_error(self, sid, message):
        await self.sio.emit(self.kAuthError, {"message": message}, to=sid)

    async def _check_redis_connection(self):
        try:
            await self.cache.ping()
        except Exception as exc:
            print(f"Redis ping failed: {exc}", file=sys.stderr)


class SimpleSIOServer(AsyncSIOServer):
    async def authenticate(self, sid, data):
        return sid

    async def retrieve(self, data):
        return data
