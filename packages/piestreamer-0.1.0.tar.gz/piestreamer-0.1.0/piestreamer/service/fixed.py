from pathlib import Path

from ..cdn.base import BaseCDN
from ..db.video_frames_storage import VideoFramesStorage
from .stable import CaptureService


class FixedCaptureService(CaptureService):
    def __init__(
        self,
        rooms,
        cdn: BaseCDN,
        storage: VideoFramesStorage,
        fps: int = 1,
        segment_time: int = 128,
        cache_dir: Path = None,
    ):
        super(FixedCaptureService, self).__init__(
            cdn=cdn,
            storage=storage,
            fps=fps,
            segment_time=segment_time,
            cache_dir=cache_dir,
        )
        self.rooms = rooms

    def get_rooms(self):
        return self.rooms
