import random
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from time import sleep

from ..cdn.base import BaseCDN
from ..db.video_frames_storage import VideoFramesStorage
from ..streamers.ffmpeg import FfmpegStreamer


class CaptureService(object):
    def __init__(
        self,
        cdn: BaseCDN,
        storage: VideoFramesStorage,
        fps: int = 1,
        segment_time: int = 8,
        speed: int = 16,
        frames_num: int = 128,
        cache_dir: Path = None,
        debug: bool = False,
    ):
        super(CaptureService, self).__init__()
        if cache_dir is None:
            cache_dir = Path(tempfile.TemporaryDirectory().name)
        self.cache_dir = Path(cache_dir)

        self.cdn = cdn
        self.storage = storage
        self.streamers: dict[str, FfmpegStreamer] = {}

        self.fps = fps
        self.speed = speed
        self.segment_time = segment_time
        self.frames_num = frames_num
        self.debug = debug

        if self.frames_num != self.segment_time * self.speed:
            raise RuntimeError(
                f"frames_num ({self.frames_num}) != segment_time ({self.segment_time}) * speed ({self.speed})"
            )

    def capture_frames(self):
        capture_frames_start_dt = datetime.now()
        if self.debug:
            print("Capturing frames...", file=sys.stderr)
        rooms = self.get_rooms()
        room_ids = [str(room["_id"]) for room in rooms]
        for room in rooms:
            room_id = str(room["_id"])
            if (
                room_id not in self.streamers
                or self.streamers[room_id].rtsp_url != room["room_url"]
                or (not self.streamers[room_id].running)
            ):
                if room_id in self.streamers:
                    self.streamers.pop(room_id).stop()
                self.streamers[room_id] = FfmpegStreamer(
                    room["room_url"],
                    self.cache_dir / f"{room_id}",
                    fps=self.fps,
                    frames_num=self.frames_num,
                    speed=self.speed,
                    segment_time=self.segment_time,
                    debug=self.debug,
                )
                self.streamers[room_id].run()

            saved_video_paths = sorted(list((self.cache_dir / f"{room_id}").iterdir()))
            if len(saved_video_paths) > 1:
                self.storage.add(
                    str(room_id),
                    saved_video_paths[0],
                    fps=self.fps,
                    force_frames_num=self.frames_num,
                    delete_after=True,
                )
                if self.debug:
                    print(
                        f"Uploaded: {str(room_id)}; Path: {saved_video_paths[0].name}",
                        file=sys.stderr,
                    )

        for room_id in list(self.streamers.keys()):
            if room_id not in room_ids:
                self.streamers.pop(room_id).stop()

        if self.debug:
            capture_frames_end_dt = datetime.now()
            print(
                f"Capture frames duration: {(capture_frames_end_dt - capture_frames_start_dt).total_seconds()}\n",
                f"Cache dir: {self.cache_dir}\n",
                f"Number of streamers: {len(self.streamers)}\n",
                file=sys.stderr,
            )
            room = random.choice(rooms)
            print(
                "Random room status:\n",
                self.streamers[str(room["_id"])].status(),
                file=sys.stderr,
            )

    def run(self):
        while True:
            self.capture_frames()
            sleep(1)

    def get_rooms(self):
        raise NotImplementedError()

    def stop(self):
        for room_id in list(self.streamers.keys()):
            self.streamers.pop(room_id).stop()
