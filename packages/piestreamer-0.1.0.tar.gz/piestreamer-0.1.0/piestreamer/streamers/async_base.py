import asyncio
import os
import signal
from pathlib import Path
from typing import Optional

import psutil


class AsyncBaseStreamer:
    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.proc: Optional[asyncio.subprocess.Process] = None
        self.pid: Optional[int] = None

    async def run(self):
        raise NotImplementedError("run() must be implemented by subclass")

    async def stop(self):
        if self.proc:
            self.proc.terminate()
            try:
                await asyncio.wait_for(self.proc.wait(), timeout=5)
            except asyncio.TimeoutError:
                self.proc.kill()
                await self.proc.wait()
        elif self.pid:
            try:
                os.kill(self.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        self.pid = None
        self.proc = None
        return self

    @property
    def running(self) -> bool:
        return self.proc is not None and self.proc.returncode is None

