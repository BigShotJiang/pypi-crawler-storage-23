import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional
from PIL import Image

from .base import BaseStreamer


class FfmpegStreamer(BaseStreamer):
    def __init__(
        self,
        rtsp_url: str,
        output_dir: Path,
        fps=1,
        segment_time=8,
        frames_num=128,
        speed=16,
        debug=False,
    ):
        super(FfmpegStreamer, self).__init__(output_dir=output_dir)
        self.rtsp_url = str(rtsp_url)
        self.segment_time = segment_time
        self.fps = fps
        self.speed = speed
        self.frames_num = frames_num
        self.pts = self.fps * self.speed
        self.proc: Optional[subprocess.Popen] = None
        self.debug = debug
        if self.frames_num != self.segment_time * self.speed:
            raise RuntimeError(
                f"frames_num ({self.frames_num}) != segment_time ({self.segment_time}) * speed ({self.speed})"
            )

    def run(self):
        os.makedirs(self.output_dir, exist_ok=True)
        ffmpeg_cmd = (
            f"ffmpeg -rtsp_transport tcp -i '{self.rtsp_url}' "
            "-c:v libx264 -preset medium -crf 34 "
            f"-filter:v 'fps={self.pts}, setpts=PTS/{self.pts}' "
            "-x264-params keyint=1:min-keyint=1 -an "
            "-use_wallclock_as_timestamps 1 -f segment -reset_timestamps 1 "
            f"-segment_time {self.segment_time} -segment_format mp4 "
            f"-strftime 1 {self.output_dir}/%Y%m%dT%H%M%S.mp4"
        )
        print(f"FFmpeg command: \n{ffmpeg_cmd}", file=sys.stderr)
        self.proc = subprocess.Popen(
            ffmpeg_cmd,
            shell=True,
            stdout=subprocess.PIPE if self.debug else subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )
        if self.debug:
            os.set_blocking(self.proc.stdout.fileno(), False)
        self.pid = self.proc.pid
        print(f"FFmpeg subprocess pid: {self.pid}", file=sys.stderr)
        return self

    def status(self):
        if not self.debug:
            raise RuntimeError("Please use debug option for this purpose")
        out = self.proc.stdout.read()
        if out is not None:
            out = out.decode("utf-8")
        else:
            out = ""

        err = self.proc.stderr.read()
        if err is not None:
            err = err.decode("utf-8")
        else:
            err = ""
        return f"Output: {out}\nError: {err}\n"

    @property
    def running(self):
        if self.proc is None:
            return False
        return self.proc.poll() is None

    @staticmethod
    def test_rtsp_url(rtsp_url: str) -> bool:
        try:
            cmd = [
                "ffmpeg",
                "-rtsp_transport", "tcp",
                "-i", rtsp_url,
                "-t", "2",
                "-frames:v", "1",
                "-f", "null", "-"
            ]
            result = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=5)
            return result.returncode == 0
        except subprocess.TimeoutExpired:
            return False
        except Exception:
            return False

    @staticmethod
    def read_frame_from_rtsp(rtsp_url: str) -> Image.Image:
        with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tmp_file:
            tmp_path = tmp_file.name

        try:
            cmd = [
                "ffmpeg",
                "-rtsp_transport", "tcp",
                "-i", rtsp_url,
                "-frames:v", "1",
                "-q:v", "2",
                tmp_path
            ]
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
            image = Image.open(tmp_path).convert("RGB")
            return image
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
