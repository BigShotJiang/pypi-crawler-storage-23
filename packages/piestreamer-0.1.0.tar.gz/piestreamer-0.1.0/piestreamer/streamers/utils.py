import os
import subprocess
from fractions import Fraction


def get_file_size(video_path):
    try:
        size_bytes = os.path.getsize(video_path)
        size_mb = round(size_bytes / (1024 * 1024), 2)
        return size_mb
    except FileNotFoundError as e:
        raise RuntimeError(f"Error getting file size of {video_path}: {e}")


def count_frames_ffmpeg(video_path):
    command = [
        "ffprobe",
        "-v",
        "error",
        "-select_streams",
        "v:0",
        "-count_frames",
        "-show_entries",
        "stream=nb_read_frames",
        "-of",
        "default=nokey=1:noprint_wrappers=1",
        os.path.abspath(video_path),
    ]
    print(' '.join(command))
    try:
        output = subprocess.check_output(command, stderr=subprocess.STDOUT).decode(
            "utf-8"
        )

        return int(output.split('\n')[0].strip())
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Error counting frames in {video_path}: {e}")


def get_duration_ffmpeg(video_path):
    command = [
        "ffprobe",
        "-v",
        "error",
        "-select_streams",
        "v:0",
        "-show_entries",
        "format=duration",
        "-of",
        "default=nokey=1:noprint_wrappers=1",
        os.path.abspath(video_path),
    ]
    print(' '.join(command))
    try:
        output = subprocess.check_output(command, stderr=subprocess.STDOUT).decode(
            "utf-8"
        )
        return float(output.split('\n')[0].strip())
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Error counting frames in {video_path}: {e}")


def get_fps_ffmpeg(video_path):
    command = [
        "ffprobe",
        "-v",
        "error",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=r_frame_rate",
        "-of",
        "default=nokey=1:noprint_wrappers=1",
        os.path.abspath(video_path),
    ]
    print(' '.join(command))
    try:
        output = subprocess.check_output(command, stderr=subprocess.STDOUT).decode(
            "utf-8"
        )
        f, s = output.strip().split('\n')[0].split("/")
        return Fraction(int(f), int(s))
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Error counting frames in {video_path}: {e}")
