import os
from pathlib import Path

from .base import BaseStreamer


class SocketIOStreamer(BaseStreamer):
    def __init__(self, sid, output_dir: Path):
        super(SocketIOStreamer, self).__init__(output_dir=output_dir)

    def run(self):
        os.makedirs(self.output_dir, exist_ok=True)
        pass
