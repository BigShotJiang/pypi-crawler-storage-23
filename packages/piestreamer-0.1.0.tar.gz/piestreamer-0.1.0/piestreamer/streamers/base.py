import os
import signal
from pathlib import Path

import psutil


class BaseStreamer(object):
    def __init__(self, output_dir: Path):
        super(BaseStreamer, self).__init__()
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.pid = None

    def run(self):
        raise NotImplementedError()

    def stop(self):
        if self.pid is not None:
            os.kill(self.pid, signal.SIGABRT)
        self.pid = None
        return self

    @property
    def running(self):
        if self.pid is None:
            return False
        if not psutil.pid_exists(self.pid):
            self.pid = None
            return False
        return True
