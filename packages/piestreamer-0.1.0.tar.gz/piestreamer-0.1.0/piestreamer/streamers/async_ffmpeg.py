import asyncio
from datetime import datetime
import os
import sys
from pathlib import Path
from PIL import Image
from io import BytesIO

from .async_base import AsyncBaseStreamer


class AsyncFfmpegStreamer(AsyncBaseStreamer):
    def __init__(
            self,
            rtsp_url: str,
            output_dir: Path,
            fps=1,
            segment_time=8,
            segment_frames_num=128,
            debug=False,
    ):
        super(AsyncFfmpegStreamer, self).__init__(output_dir=output_dir)
        self.rtsp_url = str(rtsp_url)
        self.pid = None
        self.fps = fps
        self.segment_frames_num = segment_frames_num
        self.segment_time = segment_time
        self.debug = debug

        # Calculate output FPS: frames_num / segment_time
        # Example: 128 frames / 8 seconds = 16 fps output
        self.output_fps = self.segment_frames_num / self.segment_time

    async def run(self,
                  dry_run: bool = False):
        os.makedirs(self.output_dir, exist_ok=True)
        ffmpeg_cmd = ["ffmpeg"]
        is_rtsp = self.rtsp_url.startswith("rtsp://")
        # current_time = datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ")

        if is_rtsp:
            ffmpeg_cmd.extend([
                "-rtsp_transport", "tcp",
            ])
        else:
            ffmpeg_cmd.extend([
                "-re"
            ])

        ffmpeg_cmd.extend([
            "-i", self.rtsp_url,
            "-c:v", "libx264",
            "-preset", "medium",
            "-crf", "34",
        ])
        # if not is_rtsp:
        #     ffmpeg_cmd.extend([
        #         "-metadata", f"creation_time={current_time}",
        #     ])
        if is_rtsp:
            ffmpeg_cmd.extend([
                "-filter:v",
                f"fps={self.output_fps},setpts=PTS/{self.output_fps}"
            ])
        else:
            ffmpeg_cmd.extend([
                "-filter:v",
                f"fps=256,setpts=N/{self.output_fps}",
                "-r", f"{self.output_fps}",
            ])

        ffmpeg_cmd.extend(["-x264-params", "keyint=1:min-keyint=1",
                           "-an"])

        if is_rtsp:
            ffmpeg_cmd.extend([ "-use_wallclock_as_timestamps", "1"])
        # else:
        #     ffmpeg_cmd.extend([ "-segment_atclocktime", "1" ])

        ffmpeg_cmd.extend([
            "-f", "segment",
            "-reset_timestamps", "1",
            "-segment_time", str(self.segment_time),
            "-segment_format", "mp4",
            "-strftime", "1",
            f"{self.output_dir}/%Y%m%dT%H%M%S.mp4"
        ])
        print(f"FFmpeg command:\n{' '.join(ffmpeg_cmd)}", file=sys.stderr)
        if dry_run:
            return ffmpeg_cmd

        self.proc = await asyncio.create_subprocess_exec(
            *ffmpeg_cmd,
            stdout=asyncio.subprocess.PIPE if self.debug else asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE
        )
        self.pid = self.proc.pid
        print(f"FFmpeg subprocess pid: {self.pid}", file=sys.stderr)
        return ffmpeg_cmd

    async def status(self):
        if not self.debug:
            raise RuntimeError("Please use debug option for this purpose")

        out_lines, err_lines = [], []

        if self.proc.stdout:
            while True:
                try:
                    line = await asyncio.wait_for(self.proc.stdout.readline(), timeout=0.01)
                    if not line:
                        break
                    out_lines.append(line.decode(errors='ignore'))
                except asyncio.TimeoutError:
                    break

        if self.proc.stderr:
            while True:
                try:
                    line = await asyncio.wait_for(self.proc.stderr.readline(), timeout=0.01)
                    if not line:
                        break
                    err_lines.append(line.decode(errors='ignore'))
                except asyncio.TimeoutError:
                    break

        return f"Output: {''.join(out_lines)}\nError: {''.join(err_lines)}"

    @staticmethod
    async def test_rtsp_url(rtsp_url: str) -> bool:
        try:
            is_rtsp = rtsp_url.startswith("rtsp://")
            cmd = ["ffmpeg"]
            if is_rtsp:
                cmd += ["-rtsp_transport", "tcp"]
            cmd += ["-i", rtsp_url, "-t", "2", "-frames:v", "1", "-f", "null", "-"]

            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL
            )
            try:
                await asyncio.wait_for(proc.wait(), timeout=5)
            except asyncio.TimeoutError:
                proc.kill()
                return False
            return proc.returncode == 0
        except Exception:
            return False

    @staticmethod
    async def read_frame_from_rtsp(rtsp_url: str) -> Image.Image:
        is_rtsp = rtsp_url.startswith("rtsp://")
        cmd = ["ffmpeg"]
        if is_rtsp:
            cmd += ["-rtsp_transport", "tcp"]
        cmd += [
            "-i", rtsp_url,
            "-frames:v", "1", "-f", "image2", "-q:v", "2", "pipe:1"
        ]

        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL
        )

        try:
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=10)
            if proc.returncode != 0:
                raise RuntimeError("ffmpeg failed to capture frame")
            return Image.open(BytesIO(stdout)).convert("RGB")
        except asyncio.TimeoutError:
            proc.kill()
            raise
