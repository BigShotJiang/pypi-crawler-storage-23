import argparse
import base64
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from time import sleep

import redis
import yaml
from pymongo import MongoClient

from piestreamer.db.media_segment_storage import MediaSegmentStorage
from piestreamer.service.base_sio_server import SimpleSIOServer

from .cdn.cloudflare import CloudFlareCDN
from .db.video_frames_storage import VideoFramesStorage
from .service.fixed import FixedCaptureService
from .streamers.ffmpeg import FfmpegStreamer
from .streamers.utils import (count_frames_ffmpeg, get_duration_ffmpeg,
                              get_file_size, get_fps_ffmpeg)


def parse_args():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(
        help="start some service!", description="startup commands", dest="command"
    )

    capture_parser = subparsers.add_parser("capture")
    capture_parser.add_argument("--config", default="./configuration.yml")
    capture_parser.add_argument("--db_name", default="test")
    capture_parser.add_argument("--table_name", default="test")

    host_parser = subparsers.add_parser("host")
    host_parser.add_argument("video_path")
    host_parser.add_argument("--config", default="./configuration.yml")

    clean_parser = subparsers.add_parser("clean")
    clean_parser.add_argument("--config", default="./configuration.yml")

    stream_parser = subparsers.add_parser("stream")
    stream_parser.add_argument("rtsp_url")
    stream_parser.add_argument("output_dir", type=Path)
    stream_parser.add_argument("--fps", default=2, type=int)
    stream_parser.add_argument("--segment_time", default=32, type=int)
    stream_parser.add_argument("--config", default="./configuration.yml")

    server_parser = subparsers.add_parser("server")
    server_parser.add_argument("--config", default="./configuration.yml")
    server_parser.add_argument("--host", default="0.0.0.0")
    server_parser.add_argument("--port", default=6006, type=int)
    server_parser.add_argument("--db_name", default="test")
    server_parser.add_argument("--table_name", default="test")
    server_parser.add_argument("--audio_format", default=".mp3")
    server_parser.add_argument("--video_format", default=".mp4")

    client_parser = subparsers.add_parser("push")
    client_parser.add_argument("--host", default="0.0.0.0")
    client_parser.add_argument("--port", default=6006, type=int)
    client_parser.add_argument("--audio", type=Path)

    count_parser = subparsers.add_parser("count")
    count_parser.add_argument("video_path")

    args = parser.parse_args()
    return args


def run_host(config, video_path):
    with open(config, "r") as f:
        config = yaml.safe_load(f)
    if config["cdn"].pop("type") == "cloudflare":
        cdn = CloudFlareCDN(**config["cdn"])
    else:
        raise NotImplementedError()

    _id = cdn.host(video_path)
    print(cdn.url_for(_id))


def run_clean(config):
    with open(config, "r") as f:
        config = yaml.safe_load(f)
    if config["cdn"].pop("type") == "cloudflare":
        cdn = CloudFlareCDN(**config["cdn"])
    else:
        raise NotImplementedError()
    cdn.delete(*cdn.list())


def run_stream(config, rtsp_url, output_dir, fps: int, segment_time: int):
    streamer = FfmpegStreamer(
        rtsp_url=rtsp_url, output_dir=output_dir, fps=fps, segment_time=segment_time
    )
    streamer.run()
    try:
        while True:
            sleep(1)
    except KeyboardInterrupt:
        streamer.stop()
    print("Stream stopped.")


def run_count(video_path):
    try:
        frames_num = count_frames_ffmpeg(video_path)
    except Exception:
        frames_num = "N/A"

    try:
        fps = get_fps_ffmpeg(video_path)
    except Exception:
        fps = "N/A"

    try:
        duration = get_duration_ffmpeg(video_path)
    except Exception:
        duration = "N/A"

    try:
        size = get_file_size(video_path)
    except Exception:
        size = "N/A"

    print(
        f"Video: {video_path}; "
        f"Duration: {duration}s; "
        f"FPS: {fps}; "
        f"Frames: {frames_num} "
        f"Size: {size} Mb; "
    )


def run_capture(config, db_name: str, table_name: str):
    with open(config, "r") as f:
        config = yaml.safe_load(f)

    if config["cdn"].pop("type") == "cloudflare":
        cdn = CloudFlareCDN(**config["cdn"])
    else:
        raise NotImplementedError()

    segment_time = 128
    fps = 1

    if "MONGO_HOST" not in os.environ:
        raise RuntimeError("Missing MONGO_HOST")
    client = MongoClient(host=os.environ["MONGO_HOST"])

    client.drop_database(db_name)
    info_collection = client[db_name][table_name]
    storage = VideoFramesStorage(
        cdn=cdn,
        info_collection=info_collection,
    )
    rooms = config["rooms"]
    service = FixedCaptureService(
        rooms, cdn=cdn, storage=storage, segment_time=segment_time, fps=fps
    )
    try:
        service.run()
    except KeyboardInterrupt:
        service.stop()


def run_server(config, db_name, table_name, host, port, audio_format, video_format):
    from flask import Flask
    from flask_socketio import SocketIO

    with open(config, "r") as f:
        config = yaml.safe_load(f)

    if config["cdn"].pop("type") == "cloudflare":
        cdn = CloudFlareCDN(**config["cdn"])
    else:
        raise NotImplementedError()

    if "MONGO_HOST" not in os.environ:
        raise RuntimeError("Missing MONGO_HOST")

    client = MongoClient(host=os.environ["MONGO_HOST"])

    client.drop_database(db_name)
    info_collection = client[db_name][table_name]
    storage = MediaSegmentStorage(
        cdn=cdn, info_collection=info_collection, delete_after=True
    )

    app = Flask("Test SIO Server")
    sio = SocketIO(app, async_mode="threading", engineio_logger=True)
    cache = redis.Redis()
    SimpleSIOServer(
        storage=storage,
        sio=sio,
        cache=cache,
        audio_format=audio_format,
        video_format=video_format,
    )
    sio.run(app, host=host, port=port)


def run_push(host, port, audio):
    import socketio

    ext = os.path.splitext(audio)[1][1:]

    with open(audio, "rb") as f:
        audio_content = base64.b64encode(f.read()).decode("utf-8")

    client = socketio.SimpleClient()
    client.connect(f"{host}:{port}")
    client.emit("auth", {})
    for _ in range(10):
        client.emit(
            "audio",
            {
                "start_dt": (
                    datetime.now(tz=timezone.utc) - timedelta(seconds=60)
                ).strftime("%Y-%m-%d %H:%M:%S.%f"),
                "end_dt": datetime.now(tz=timezone.utc).strftime(
                    "%Y-%m-%d %H:%M:%S.%f"
                ),
                "audio": f"data:audio/{ext};base64,{audio_content}",
            },
        )
    client.emit("stop", {})


def startup(command, **kwargs):
    if command == "host":
        run_host(**kwargs)
    elif command == "clean":
        run_clean(**kwargs)
    elif command == "stream":
        run_stream(**kwargs)
    elif command == "count":
        run_count(**kwargs)
    elif command == "capture":
        run_capture(**kwargs)
    elif command == "server":
        run_server(**kwargs)
    elif command == "push":
        run_push(**kwargs)
    else:
        raise RuntimeError("No such command")


if __name__ == "__main__":
    startup(**vars(parse_args()))
