import asyncio
import os
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional, Union

import aiofiles
import httpx
import imageio.v2 as iio
import numpy as np
import pymongo
import pytz
import tzlocal
from motor.motor_asyncio import AsyncIOMotorCollection
from PIL import Image

from ..cdn.async_base import AsyncBaseCDN
from ..cdn.async_cloudflare import AsyncCloudFlareCDN
from ..streamers.utils import count_frames_ffmpeg, get_fps_ffmpeg  # noqa F401


class AsyncVideoStorage:

    def __init__(self, cdn: AsyncCloudFlareCDN, info_collection: AsyncIOMotorCollection):
        super().__init__()
        self.cdn = cdn
        self.info_collection = info_collection

    async def init_index(self):
        await self.info_collection.create_index([("filename", 1), ("dt", 1)])
        await self.info_collection.create_index([("grid_id", 1), ("index", 1)])

    async def add(
        self,
        filename: str,
        video_path: Path,
        fps: float,
        force_frames_num: int = None,
        delete_after: bool = False,
    ):
        try:
            frames_num = await asyncio.to_thread(count_frames_ffmpeg, video_path)
        except Exception:
            print(f"Can't count frames, when capture {filename}",
                  file=sys.stderr)
            return None
        if force_frames_num is not None and frames_num != force_frames_num:
            print(
                f"Frames: {frames_num}, but need {force_frames_num}, when capture {filename}",
                file=sys.stderr,
            )
            if delete_after:
                await asyncio.to_thread(os.remove, video_path)
            return None

        async with self.cdn:
            grid_id = await self.cdn.host(video_path,
                                          content_type=f"video/{video_path.suffix}",
                                          key=f"{filename}/{video_path.name}")
        local_tz = pytz.timezone(tzlocal.get_localzone().key)
        try:
            dt = datetime.strptime(video_path.stem, "%Y%m%dT%H%M%S")
            dt = local_tz.localize(dt)
            dt = dt.astimezone(pytz.UTC)
        except ValueError:
            dt = datetime.now(tz=timezone.utc)

        index_list = [("index", i) for i in range(frames_num)]
        size_list = [("size", frames_num) for _ in range(frames_num)]
        dt_list = [("dt", dt + timedelta(seconds=i / fps)) for i in range(frames_num)]
        grid_id_list = [("grid_id", grid_id) for _ in range(frames_num)]
        filename_list = [("filename", filename) for _ in range(frames_num)]
        documents = list(
            map(dict, zip(dt_list, index_list, size_list, filename_list, grid_id_list))
        )
        await self.info_collection.insert_many(documents)
        if delete_after:
            await asyncio.to_thread(os.remove, video_path)
        return grid_id

    async def get_total_size(
        self,
        filename: str,
        start_dt: Optional[datetime] = None,
        end_dt: Optional[datetime] = None,
    ):
        if start_dt is None:
            start_dt = datetime.min
        if end_dt is None:
            end_dt = datetime.max
        grid_ids = await self.info_collection.find(
            {"filename": filename, "dt": {"$gte": start_dt, "$lte": end_dt}}
        ).distinct("grid_id")
        sizes = await asyncio.gather(*[self.cdn.getsize(gid) for gid in grid_ids],
                                     return_exceptions=True)
        sizes = list(filter(lambda size: isinstance(size, int), sizes))
        return sum(sizes)

    async def estimate_memory_occupancy_speed(
        self, filename, duration=timedelta(hours=6)
    ):
        end_dt = datetime.now(tz=timezone.utc)
        start_dt = end_dt - duration
        size = await self.get_total_size(filename, start_dt=start_dt, end_dt=end_dt)
        return 3600 * size / (end_dt - start_dt).total_seconds() / 1e6

    async def get_total_segment(self, filename: str):
        cursor = self.info_collection.aggregate(
            [
                {"$match": {"filename": filename}},
                {
                    "$group": {
                        "_id": 0,
                        "start_dt": {"$min": "$dt"},
                        "end_dt": {"$max": "$dt"},
                    }
                },
            ]
        )
        result = await cursor.to_list(None)
        if not result:
            return None, None
        return result[0]["start_dt"], result[0]["end_dt"]

    async def count_frames(self, filename: str):
        return await self.info_collection.count_documents({"filename": filename})

    async def count_segments(self, filename: str):
        pipeline = [
            {"$match": {"filename": filename}},
            {"$group": {"_id": "$grid_id"}},
            {"$count": "count"}
        ]
        result = await self.info_collection.aggregate(pipeline).to_list(1)
        return result[0]["count"] if result else 0

    async def get_segments(
        self, filename: str, start_dt: datetime, end_dt: datetime, th=10
    ):
        cursor = self.info_collection.aggregate(
            [
                {
                    "$match": {
                        "filename": filename,
                        "dt": {"$lt": end_dt, "$gt": start_dt},
                    }
                },
                {"$project": {"_id": 0, "dt": 1}},
                {"$sort": {"dt": pymongo.ASCENDING}},
                {"$group": {"_id": 0, "dts": {"$push": "$dt"}}},
            ]
        )
        docs = await cursor.to_list(None)
        if not docs:
            return []
        dts = docs[0]["dts"]
        if len(dts) < 2:
            return [(dts[0], dts[0])] if dts else []
        diff = np.array(
            [(t2 - t1).total_seconds() for t1, t2 in zip(dts[:-1], dts[1:])]
        )
        idx = np.where(diff >= th)[0]
        controls = [dts[0]] + sum([[dts[i], dts[i + 1]] for i in idx], []) + [dts[-1]]
        return [
            (controls[2 * i], controls[2 * i + 1]) for i in range(len(controls) // 2)
        ]

    async def get_total_duration(self, filename: str):
        cursor = self.info_collection.aggregate(
            [
                {"$match": {"filename": filename}},
                {
                    "$group": {
                        "_id": "$grid_id",
                        "start_dt": {"$min": "$dt"},
                        "end_dt": {"$max": "$dt"},
                    }
                },
            ]
        )
        docs = await cursor.to_list(None)
        if not docs:
            return 0
        return sum([(d["end_dt"] - d["start_dt"]).total_seconds() for d in docs])

    async def get_video_url_list(
        self,
        filename: str,
        start_dt: datetime = None,
        end_dt: datetime = None,
        strict_inner=False,
        strict_whole=False,
    ):
        videos = await self.get_videos(
            filename=filename,
            start_dt=start_dt,
            end_dt=end_dt,
            strict_inner=strict_inner,
            strict_whole=strict_whole,
        )
        return [self.cdn.url_for(v["_id"]) for v in videos]

    async def delete_videos(
        self,
        filename: Optional[str] = None,
        start_dt: Optional[datetime] = None,
        end_dt: Optional[datetime] = None,
        strict_inner: bool = True,
        with_metadata: bool = False,
    ):
        videos = await self.get_videos(
            filename=filename,
            start_dt=start_dt,
            end_dt=end_dt,
            strict_inner=strict_inner,
        )
        grid_ids = [v["_id"] for v in videos]
        async with self.cdn:
            await self.cdn.delete(*grid_ids)
        if with_metadata:
            await self.info_collection.delete_many({"grid_id": {"$in": grid_ids}})
        return len(grid_ids)

    async def get_whole_videos(
        self,
        filename: str,
        start_dt: Optional[datetime] = None,
        end_dt: Optional[datetime] = None,
    ):
        filename = str(filename)
        cursor = self.info_collection.aggregate(
            [
                {
                    "$match": {
                        "filename": filename,
                        "dt": {"$lte": end_dt, "$gte": start_dt},
                    }
                },
                {
                    "$group": {
                        "_id": "$grid_id",
                        "start_dt": {"$min": "$dt"},
                        "start_index": {"$min": "$index"},
                        "end_dt": {"$max": "$dt"},
                        "end_index": {"$max": "$index"},
                        "filename": {"$first": "$filename"},
                        "size": {"$first": "$size"},
                    }
                },
                {"$sort": {"start_dt": pymongo.ASCENDING}},
            ]
        )


    async def get_videos(
        self,
        filename: Optional[Union[str, dict]] = None,
        start_dt: Optional[datetime] = None,
        end_dt: Optional[datetime] = None,
        strict_inner: bool = True,
        strict_whole: bool = False,
    ):
        if filename is None:
            filename = {"$exists": True}
        if start_dt is None:
            start_dt = datetime.min
        if end_dt is None:
            end_dt = datetime.max
        if strict_inner:
            cursor = self.info_collection.aggregate(
                [
                    {
                        "$match": {
                            "filename": filename,
                            "$expr": {
                                "$or": [
                                    {"$eq": ["$index", {"$subtract": ["$size", 1]}]},
                                    {"$eq": ["$index", 0]},
                                ]
                            },
                            "dt": {"$lte": end_dt, "$gte": start_dt},
                        }
                    },
                    {
                        "$group": {
                            "_id": "$grid_id",
                            "start_dt": {"$min": "$dt"},
                            "start_index": {"$min": "$index"},
                            "end_dt": {"$max": "$dt"},
                            "end_index": {"$max": "$index"},
                            "filename": {"$first": "$filename"},
                            "size": {"$first": "$size"},
                            "count": {"$sum": 1},
                        }
                    },
                    {"$match": {"count": 2}},
                    {
                        "$project": {
                            "_id": 1,
                            "start_dt": 1,
                            "start_index": 1,
                            "end_dt": 1,
                            "end_index": 1,
                            "filename": 1,
                            "size": 1,
                        }
                    },
                    {"$sort": {"start_dt": pymongo.ASCENDING}},
                ]
            )
            return await cursor.to_list(None)
        else:
            cursor = self.info_collection.aggregate(
                [
                    {
                        "$match": {
                            "filename": filename,
                            "dt": {"$lte": end_dt, "$gte": start_dt},
                        }
                    },
                    {
                        "$group": {
                            "_id": "$grid_id",
                            "start_dt": {"$min": "$dt"},
                            "start_index": {"$min": "$index"},
                            "end_dt": {"$max": "$dt"},
                            "end_index": {"$max": "$index"},
                            "filename": {"$first": "$filename"},
                            "size": {"$first": "$size"},
                        }
                    },
                    {"$sort": {"start_dt": pymongo.ASCENDING}},
                ]
            )
            videos = await cursor.to_list(None)
            if strict_whole and videos:
                videos[0]["start_index"] = 0
                videos[0]["end_index"] = videos[0]["size"] - 1
                videos[-1]["start_index"] = 0
                videos[-1]["end_index"] = videos[-1]["size"] - 1
                first_first = await self.info_collection.find_one(
                    {"filename": filename, "index": 0, "grid_id": videos[0]["_id"]}
                )
                first_last = await self.info_collection.find_one(
                    {
                        "filename": filename,
                        "index": videos[0]["size"] - 1,
                        "grid_id": videos[0]["_id"],
                    }
                )
                last_first = await self.info_collection.find_one(
                    {"filename": filename, "index": 0, "grid_id": videos[-1]["_id"]}
                )
                last_last = await self.info_collection.find_one(
                    {
                        "filename": filename,
                        "index": videos[-1]["size"] - 1,
                        "grid_id": videos[-1]["_id"],
                    }
                )
                if first_first and first_last:
                    videos[0]["start_dt"] = first_first["dt"]
                    videos[0]["end_dt"] = first_last["dt"]
                if last_first and last_last:
                    videos[-1]["start_dt"] = last_first["dt"]
                    videos[-1]["end_dt"] = last_last["dt"]
            return videos

    async def list_filenames(self):
        return await self.info_collection.distinct("filename")

    async def iter(self, filename, start_dt: datetime, end_dt: datetime):
        videos = await self.get_videos(
            filename=filename, start_dt=start_dt, end_dt=end_dt, strict_inner=False
        )
        async with httpx.AsyncClient() as client:
            for v in videos:
                video_url = self.cdn.url_for(v["_id"])
                r = await client.get(video_url)
                frames = iio.mimread(r.content, format="ts", memtest=False)
                frames = frames[v["start_index"] : v["end_index"] + 1]  # noqa E203
                for frame in frames:
                    yield Image.fromarray(frame).convert("RGB")

    async def get_frame_near_dt(self, filename: str, dt: datetime, none_if_more=1):
        frame_before_dt = await self.info_collection.find_one(
            {"filename": filename, "dt": {"$lte": dt}},
            sort=[("dt", pymongo.DESCENDING)],
        )
        frame_after_dt = await self.info_collection.find_one(
            {"filename": filename, "dt": {"$gte": dt}}, sort=[("dt", pymongo.ASCENDING)]
        )
        if not frame_before_dt and not frame_after_dt:
            return None
        if frame_after_dt and frame_before_dt:
            if (frame_after_dt["dt"] - dt) < (dt - frame_before_dt["dt"]):
                frame_near_dt = frame_after_dt
            else:
                frame_near_dt = frame_before_dt
        elif frame_after_dt:
            frame_near_dt = frame_after_dt
        else:
            frame_near_dt = frame_before_dt
        if abs((frame_near_dt["dt"] - dt).total_seconds()) > none_if_more:
            return None
        video_url = self.cdn.url_for(frame_near_dt["grid_id"])
        index = frame_near_dt["index"]
        print(f"Video: {video_url}; Index: {index};", file=sys.stderr)
        async with httpx.AsyncClient() as client:
            r = await client.get(video_url)
            frames = iio.mimread(r.content, format="ts", memtest=False)
        return Image.fromarray(frames[index]).convert("RGB")

    async def export_segment(self, filename, start_dt, end_dt, export_path):
        videos = await self.get_videos(
            filename=filename,
            start_dt=start_dt,
            end_dt=end_dt,
            strict_inner=False,
            strict_whole=True,
        )

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_dir = os.path.abspath(temp_dir)
            url_list_path = os.path.join(temp_dir, "output.txt")
            concat_list_path = os.path.join(temp_dir, "input.txt")
            async with aiofiles.open(url_list_path, "w") as f:
                await f.write("\n".join([self.cdn.url_for(v["_id"]) for v in videos]))
            async with aiofiles.open(concat_list_path, "w") as f:
                await f.write(
                    "\n".join(
                        [
                            f"file '{os.path.join(temp_dir, str(v['_id']))}'"
                            for v in videos
                        ]
                    )
                )
            await asyncio.to_thread(
                os.system,
                f"cat {url_list_path} | xargs -IURL -P8 wget 'URL' -P {temp_dir}",
            )
            await asyncio.to_thread(os.remove, url_list_path)
            await asyncio.to_thread(
                os.system,
                f"ffmpeg -safe 0 -f concat -i {concat_list_path} -c copy {export_path}",
            )
            await asyncio.to_thread(os.remove, concat_list_path)
        return export_path
