import os
from datetime import datetime
from pathlib import Path

import pymongo
from pymongo.collection import Collection

from ..cdn.base import BaseCDN


class MediaSegmentStorage(object):
    def __init__(
        self, cdn: BaseCDN, info_collection: Collection, delete_after: bool = False
    ):
        super(MediaSegmentStorage, self).__init__()
        self.cdn = cdn
        self.info_collection = info_collection
        self.info_collection.create_index(["filename", "grid_id"])
        self.delete_after = delete_after

    def add(self, filename: str, start_dt: datetime, end_dt: datetime, path: Path):
        grid_id = self.cdn.host(path)
        document = {
            "filename": filename,
            "grid_id": grid_id,
            "start_dt": start_dt,
            "end_dt": end_dt,
        }
        self.info_collection.insert_one(document)
        if self.delete_after:
            os.remove(path)
        return grid_id

    def ping(self):
        cdn_status = self.cdn.ping()
        pymongo_status = self.info_collection.database.command("ping")
        return {"cdn": cdn_status, "pymongo": pymongo_status}

    def get_total_size(
        self,
        filename: str,
        start_dt: datetime | None = None,
        end_dt: datetime | None = None,
    ):
        if start_dt is None:
            start_dt = datetime.min

        if end_dt is None:
            end_dt = datetime.max

        grid_ids = self.info_collection.find(
            {
                "filename": filename,
                "end_dt": {"$gt": start_dt},
                "start_dt": {"$lt": end_dt},
            }
        ).distinct("grid_id")
        return sum([self.cdn.getsize(grid_id) for grid_id in grid_ids], 0)

    def get_total_segment(self, filename: str):
        result = list(
            self.info_collection.aggregate(
                [
                    {"$match": {"filename": filename}},
                    {
                        "$group": {
                            "_id": 0,
                            "start_dt": {"$min": "$start_dt"},
                            "end_dt": {"$max": "$end_dt"},
                        }
                    },
                ]
            )
        )
        if len(result) == 0:
            return None, None
        return result[0]["start_dt"], result[0]["end_dt"]

    def get_segments(self, filename: str, start_dt: datetime, end_dt: datetime, th=10):
        filename = str(filename)
        result = list(
            self.info_collection.aggregate(
                [
                    {
                        "$match": {
                            "filename": filename,
                            "end_dt": {"$gt": start_dt},
                            "start_dt": {"$lt": end_dt},
                        }
                    },
                    {"$sort": {"end_dt": pymongo.ASCENDING}},
                ]
            )
        )

        if len(result) == 0:
            return []

        segments = [None]
        for chunk in result:
            latest_segment = segments[-1]
            if latest_segment is None:
                latest_segment = [chunk["start_dt"], chunk["end_dt"]]
                segments[-1] = latest_segment
                continue
            if (chunk["start_dt"] - latest_segment[1]).total_seconds() > th:
                segments.append([chunk["start_dt"], chunk["end_dt"]])
            else:
                segments[-1][1] = chunk["end_dt"]
        return segments

    def list_filenames(self):
        return self.info_collection.distinct("filename")

    def get_media_url_list(
        self,
        filename: str,
        start_dt: datetime = None,
        end_dt: datetime = None,
        strict_inner=False,
    ):
        filename = str(filename)
        result = self.get_media_list(
            filename=filename,
            start_dt=start_dt,
            end_dt=end_dt,
            strict_inner=strict_inner,
        )
        return [self.cdn.url_for(r["_id"]) for r in result]

    def get_media_list(
        self,
        filename: str | dict | None = None,
        start_dt: datetime | None = None,
        end_dt: datetime | None = None,
        strict_inner: bool = True,
    ):
        if filename is None:
            filename = {"$exists": True}
        if start_dt is None:
            start_dt = datetime.min
        if end_dt is None:
            end_dt = datetime.max

        if strict_inner:
            return list(
                self.info_collection.aggregate(
                    [
                        {
                            "$match": {
                                "filename": filename,
                                "end_dt": {"$lt": end_dt},
                                "start_dt": {"$gt": start_dt},
                            }
                        },
                        {"$sort": {"start_dt": pymongo.ASCENDING}},
                    ]
                )
            )
        else:
            return list(
                self.info_collection.aggregate(
                    [
                        {
                            "$match": {
                                "filename": filename,
                                "end_dt": {"$gt": start_dt},
                                "start_dt": {"$lt": end_dt},
                            }
                        },
                        {"$sort": {"start_dt": pymongo.ASCENDING}},
                    ]
                )
            )

    def delete_media_list(
        self,
        filename: str | None = None,
        start_dt: datetime | None = None,
        end_dt: datetime | None = None,
        strict_inner: bool = True,
        with_metadata: bool = False,
    ):
        media_list = self.get_media_list(
            filename=filename,
            start_dt=start_dt,
            end_dt=end_dt,
            strict_inner=strict_inner,
        )
        grid_ids = list(map(lambda x: x["grid_id"], media_list))
        self.cdn.delete(*grid_ids)
        if with_metadata:
            self.info_collection.delete_many({"grid_id": {"$in": grid_ids}})
        return len(grid_ids)
