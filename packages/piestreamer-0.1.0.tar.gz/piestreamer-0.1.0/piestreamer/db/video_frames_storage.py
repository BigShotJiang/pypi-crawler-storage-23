import os
import sys
import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Union

import imageio.v2 as iio
import numpy as np
import pymongo
import requests
from PIL import Image
from pymongo.collection import Collection
from tqdm import tqdm  # noqa F401

from ..cdn.base import BaseCDN
from ..streamers.utils import count_frames_ffmpeg, get_fps_ffmpeg  # noqa F401


class VideoFramesStorage(object):
    """
    segment - (start_dt, end_dt)
    video - frames with same grid_id
    video_url - Link to grid in CDN
    """

    def __init__(self, cdn: BaseCDN, info_collection: Collection):
        super(VideoFramesStorage, self).__init__()
        self.cdn = cdn
        self.info_collection = info_collection
        self.info_collection.create_index(["filename", "dt"])
        self.info_collection.create_index(["grid_id", "index"])

    def add(
        self,
        filename: str,
        video_path: Path,
        fps: float,
        force_frames_num: int = None,
        delete_after: bool = False,
    ):
        try:
            frames_num = count_frames_ffmpeg(video_path)
        except Exception:
            frames_num = None
        if force_frames_num is not None and frames_num != force_frames_num:
            print(
                f"Frames: {frames_num}, but need {force_frames_num}, when capture {filename}",
                file=sys.stderr,
            )
            if delete_after:
                os.remove(video_path)
            return None
        grid_id = self.cdn.host(video_path)
        dt = datetime.strptime(video_path.stem, "%Y%m%dT%H%M%S")

        index_list = [("index", index) for index in range(frames_num)]
        size_list = [("size", frames_num) for _ in range(frames_num)]
        dt_list = [("dt", dt + timedelta(seconds=i / fps)) for i in range(frames_num)]
        grid_id_list = [("grid_id", grid_id) for _ in range(frames_num)]
        filename_list = [("filename", filename) for _ in range(frames_num)]
        documents = list(
            map(dict, zip(dt_list, index_list, size_list, filename_list, grid_id_list))
        )
        self.info_collection.insert_many(documents)
        if delete_after:
            os.remove(video_path)
        return grid_id

    def get_total_size(
        self,
        filename: str,
        start_dt: Optional[datetime] = None,
        end_dt: Optional[datetime] = None,
    ):
        if start_dt is None:
            start_dt = datetime.min
        if end_dt is None:
            end_dt = datetime.max
        grid_ids = self.info_collection.find(
            {"filename": filename, "dt": {"$gte": start_dt, "$lte": end_dt}}
        ).distinct("grid_id")
        return sum([self.cdn.getsize(grid_id) for grid_id in grid_ids], 0)

    def estimate_memory_occupancy_speed(self, filename, duration=timedelta(hours=6)):
        """
        Estimates the memory occupancy speed in MB/h
        :param filename:
        :param duration:
        :return:
        """
        end_dt = datetime.now()
        start_dt = end_dt - duration
        size = self.get_total_size(filename, start_dt=start_dt, end_dt=end_dt)
        return 3600 * size / (end_dt - start_dt).total_seconds() / 1e6

    def get_total_segment(self, filename: str):
        result = list(
            self.info_collection.aggregate(
                [
                    {"$match": {"filename": filename}},
                    {
                        "$group": {
                            "_id": 0,
                            "start_dt": {"$min": "$dt"},
                            "end_dt": {"$max": "$dt"},
                        }
                    },
                ]
            )
        )
        if len(result) == 0:
            return None, None
        return result[0]["start_dt"], result[0]["end_dt"]

    def get_segments(self, filename: str, start_dt: datetime, end_dt: datetime, th=10):
        filename = str(filename)
        result = list(
            self.info_collection.aggregate(
                [
                    {
                        "$match": {
                            "filename": filename,
                            "dt": {"$lt": end_dt, "$gt": start_dt},
                        }
                    },
                    {"$project": {"_id": 0, "dt": 1}},
                    {"$sort": {"dt": pymongo.ASCENDING}},
                    {"$group": {"_id": 0, "dts": {"$push": "$dt"}}},
                ]
            )
        )
        if len(result) == 0:
            return []

        dts = result[0]["dts"]
        diff = np.array(
            [(dt2 - dt1).total_seconds() for dt1, dt2 in zip(dts[:-1], dts[1:])]
        )
        idx = np.where(diff >= th)[0]
        controls = [dts[0]] + sum([[dts[i], dts[i + 1]] for i in idx], []) + [dts[-1]]
        return [
            (controls[2 * i], controls[2 * i + 1]) for i in range(len(controls) // 2)
        ]

    def get_total_duration(self, filename: str):
        result = list(
            self.info_collection.aggregate(
                [
                    {"$match": {"filename": filename}},
                    {
                        "$group": {
                            "_id": "$grid_id",
                            "start_dt": {"$min": "$dt"},
                            "end_dt": {"$max": "$dt"},
                        }
                    },
                ]
            )
        )
        if len(result) == 0:
            return 0
        return sum([(r["end_dt"] - r["start_dt"]).total_seconds() for r in result], 0)

    def get_video_url_list(
        self,
        filename: str,
        start_dt: datetime = None,
        end_dt: datetime = None,
        strict_inner=False,
        strict_whole=False,
    ):
        filename = str(filename)
        result = self.get_videos(
            filename=filename,
            start_dt=start_dt,
            end_dt=end_dt,
            strict_inner=strict_inner,
            strict_whole=strict_whole,
        )
        return [self.cdn.url_for(r["_id"]) for r in result]

    def delete_videos(
        self,
        filename: Optional[str] = None,
        start_dt: Optional[datetime] = None,
        end_dt: Optional[datetime] = None,
        strict_inner: bool = True,
        with_metadata: bool = False,
    ):
        videos = self.get_videos(
            filename=filename,
            start_dt=start_dt,
            end_dt=end_dt,
            strict_inner=strict_inner,
        )
        grid_ids = list(map(lambda x: x["_id"], videos))
        self.cdn.delete(*grid_ids)
        if with_metadata:
            self.info_collection.delete_many({"grid_id": {"$in": grid_ids}})
        return len(grid_ids)

    def get_videos(
        self,
        filename: Optional[Union[str, dict]] = None,
        start_dt: Optional[datetime] = None,
        end_dt: Optional[datetime] = None,
        strict_inner: bool = True,
        strict_whole: bool = False,
    ):
        """
        1. Common match
        2. Group
        3. Precise match
        """
        if filename is None:
            filename = {"$exists": True}
        if start_dt is None:
            start_dt = datetime.min
        if end_dt is None:
            end_dt = datetime.max

        if strict_inner:
            return list(
                self.info_collection.aggregate(
                    [
                        {
                            "$match": {
                                "filename": filename,
                                "$expr": {
                                    "$or": [
                                        {
                                            "$eq": [
                                                "$index",
                                                {"$subtract": ["$size", 1]},
                                            ]
                                        },
                                        {"$eq": ["$index", 0]},
                                    ]
                                },
                                "dt": {"$lte": end_dt, "$gte": start_dt},
                            }
                        },
                        {
                            "$group": {
                                "_id": "$grid_id",
                                "start_dt": {"$min": "$dt"},
                                "start_index": {"$min": "$index"},
                                "end_dt": {"$max": "$dt"},
                                "end_index": {"$max": "$index"},
                                "filename": {"$first": "$filename"},
                                "size": {"$first": "$size"},
                                "count": {"$sum": 1},
                            }
                        },
                        {"$match": {"count": 2}},
                        {
                            "$project": {
                                "_id": 1,
                                "start_dt": 1,
                                "start_index": 1,
                                "end_dt": 1,
                                "end_index": 1,
                                "filename": 1,
                                "size": 1,
                            }
                        },
                        {"$sort": {"start_dt": pymongo.ASCENDING}},
                    ]
                )
            )
        else:
            videos = list(
                self.info_collection.aggregate(
                    [
                        {
                            "$match": {
                                "filename": filename,
                                "dt": {"$lte": end_dt, "$gte": start_dt},
                            }
                        },
                        {
                            "$group": {
                                "_id": "$grid_id",
                                "start_dt": {"$min": "$dt"},
                                "start_index": {"$min": "$index"},
                                "end_dt": {"$max": "$dt"},
                                "end_index": {"$max": "$index"},
                                "filename": {"$first": "$filename"},
                                "size": {"$first": "$size"},
                            }
                        },
                        {"$sort": {"start_dt": pymongo.ASCENDING}},
                    ]
                )
            )
            if strict_whole:
                videos[0]["start_index"] = 0
                videos[0]["end_index"] = videos[0]["size"] - 1
                videos[-1]["start_index"] = 0
                videos[-1]["end_index"] = videos[-1]["size"] - 1
                videos[0]["start_dt"] = self.info_collection.find_one(
                    {"filename": filename, "index": 0, "grid_id": videos[0]["_id"]}
                )["dt"]
                videos[0]["end_dt"] = self.info_collection.find_one(
                    {
                        "filename": filename,
                        "index": videos[0]["size"] - 1,
                        "grid_id": videos[0]["_id"],
                    }
                )["dt"]

                videos[-1]["start_dt"] = self.info_collection.find_one(
                    {"filename": filename, "index": 0, "grid_id": videos[-1]["_id"]}
                )["dt"]
                videos[-1]["end_dt"] = self.info_collection.find_one(
                    {
                        "filename": filename,
                        "index": videos[-1]["size"] - 1,
                        "grid_id": videos[-1]["_id"],
                    }
                )["dt"]
            return videos

    def list_filenames(self):
        return self.info_collection.distinct("filename")

    def iter(self, filename, start_dt: datetime, end_dt: datetime):
        videos = self.get_videos(
            filename=filename, start_dt=start_dt, end_dt=end_dt, strict_inner=False
        )
        for video in videos:
            video_url = self.cdn.url_for(video["_id"])
            content = requests.get(video_url).content
            frames = iio.mimread(content, format="mp4", memtest=False)
            frames = frames[video["start_index"] : video["end_index"] + 1]  # noqa E203
            for frame in frames:
                yield Image.fromarray(frame).convert("RGB")

    def get_frame_near_dt(self, filename: str, dt: datetime, none_if_more=1):
        frame_before_dt = self.info_collection.find_one(
            {"filename": filename, "dt": {"$lte": dt}},
            sort=[("dt", pymongo.DESCENDING)],
        )
        frame_after_dt = self.info_collection.find_one(
            {"filename": filename, "dt": {"$gte": dt}}, sort=[("dt", pymongo.ASCENDING)]
        )
        if (frame_after_dt["dt"] - dt) < (dt - frame_before_dt["dt"]):
            frame_near_dt = frame_after_dt
        else:
            frame_near_dt = frame_before_dt
        if abs((frame_near_dt["dt"] - dt).total_seconds()) > none_if_more:
            return None
        video_url = self.cdn.url_for(frame_near_dt["grid_id"])
        index = frame_near_dt["index"]
        print(f"Video: {video_url}; Index: {index};", file=sys.stderr)
        content = requests.get(video_url).content
        frames = iio.mimread(content, format="mp4", memtest=False)
        return Image.fromarray(frames[index]).convert("RGB")

    def export_segment(self, filename, start_dt, end_dt, export_path):
        videos = self.get_videos(
            filename=filename,
            start_dt=start_dt,
            end_dt=end_dt,
            strict_inner=False,
            strict_whole=True,
        )

        with tempfile.TemporaryDirectory() as temp_dir:
            temp_dir = os.path.abspath(temp_dir)
            url_list_path = os.path.join(temp_dir, "output.txt")
            concat_list_path = os.path.join(temp_dir, "input.txt")
            with open(url_list_path, "w") as f:
                f.write("\n".join([self.cdn.url_for(video["_id"]) for video in videos]))
            with open(concat_list_path, "w") as f:
                f.write(
                    "\n".join(
                        [
                            f"file '{os.path.join(temp_dir, str(video['_id']))}'"
                            for video in videos
                        ]
                    )
                )
            os.system(f"cat {url_list_path} | xargs -IURL -P8 wget 'URL' -P {temp_dir}")
            os.remove(url_list_path)
            os.system(
                f"ffmpeg -safe 0 -f concat -i {concat_list_path} -c copy {export_path}"
            )
            os.remove(concat_list_path)
        return export_path
