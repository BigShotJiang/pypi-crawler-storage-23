import asyncio
import os
from datetime import datetime
from pathlib import Path
from typing import Optional, Union

import pymongo
from motor.motor_asyncio import AsyncIOMotorCollection

from ..cdn.async_base import AsyncBaseCDN


class AsyncMediaStorage:
    def __init__(
        self,
        cdn: AsyncBaseCDN,
        info_collection: AsyncIOMotorCollection,
        delete_after: bool = False,
    ):
        super().__init__()
        self.cdn = cdn
        self.info_collection = info_collection
        self.delete_after = delete_after

    async def init_index(self):
        await self.info_collection.create_index([("filename", 1), ("grid_id", 1)])

    async def add(
        self, filename: str, start_dt: datetime, end_dt: datetime, path: Path
    ) -> Union[str, object]:
        grid_id = await self.cdn.host(path)
        document = {
            "filename": filename,
            "grid_id": grid_id,
            "start_dt": start_dt,
            "end_dt": end_dt,
        }
        await self.info_collection.insert_one(document)
        if self.delete_after:
            await asyncio.to_thread(os.remove, path)
        return grid_id

    async def ping(self):
        cdn_status = await self.cdn.ping()
        pymongo_status = await self.info_collection.database.command("ping")
        return {"cdn": cdn_status, "pymongo": pymongo_status}

    async def get_total_size(
        self,
        filename: str,
        start_dt: Optional[datetime] = None,
        end_dt: Optional[datetime] = None,
    ) -> int:
        if start_dt is None:
            start_dt = datetime.min
        if end_dt is None:
            end_dt = datetime.max
        distinct_ids = await self.info_collection.distinct(
            "grid_id",
            {
                "filename": filename,
                "end_dt": {"$gt": start_dt},
                "start_dt": {"$lt": end_dt},
            },
        )
        sizes = await asyncio.gather(*[self.cdn.getsize(gid) for gid in distinct_ids])
        return sum(sizes)

    async def get_total_segment(self, filename: str):
        cursor = self.info_collection.aggregate(
            [
                {"$match": {"filename": filename}},
                {
                    "$group": {
                        "_id": 0,
                        "start_dt": {"$min": "$start_dt"},
                        "end_dt": {"$max": "$end_dt"},
                    }
                },
            ]
        )
        result = await cursor.to_list(None)
        if not result:
            return None, None
        return result[0]["start_dt"], result[0]["end_dt"]

    async def get_segments(
        self, filename: str, start_dt: datetime, end_dt: datetime, th: int = 10
    ):
        cursor = self.info_collection.aggregate(
            [
                {
                    "$match": {
                        "filename": filename,
                        "end_dt": {"$gt": start_dt},
                        "start_dt": {"$lt": end_dt},
                    }
                },
                {"$sort": {"end_dt": pymongo.ASCENDING}},
            ]
        )
        rows = await cursor.to_list(None)
        if not rows:
            return []
        segments = [None]
        for chunk in rows:
            latest_segment = segments[-1]
            if latest_segment is None:
                segments[-1] = [chunk["start_dt"], chunk["end_dt"]]
                continue
            gap = (chunk["start_dt"] - latest_segment[1]).total_seconds()
            if gap > th:
                segments.append([chunk["start_dt"], chunk["end_dt"]])
            else:
                segments[-1][1] = chunk["end_dt"]
        return segments

    async def list_filenames(self):
        return await self.info_collection.distinct("filename")

    async def get_media_url_list(
        self,
        filename: str,
        start_dt: Optional[datetime] = None,
        end_dt: Optional[datetime] = None,
        strict_inner: bool = False,
    ):
        result = await self.get_media_list(
            filename=filename,
            start_dt=start_dt,
            end_dt=end_dt,
            strict_inner=strict_inner,
        )
        return [self.cdn.url_for(r["_id"]) for r in result]

    async def get_media_list(
        self,
        filename: Union[str, dict, None] = None,
        start_dt: Optional[datetime] = None,
        end_dt: Optional[datetime] = None,
        strict_inner: bool = True,
    ):
        if filename is None:
            filename = {"$exists": True}
        if start_dt is None:
            start_dt = datetime.min
        if end_dt is None:
            end_dt = datetime.max
        if strict_inner:
            cursor = self.info_collection.aggregate(
                [
                    {
                        "$match": {
                            "filename": filename,
                            "end_dt": {"$lt": end_dt},
                            "start_dt": {"$gt": start_dt},
                        }
                    },
                    {"$sort": {"start_dt": pymongo.ASCENDING}},
                ]
            )
        else:
            cursor = self.info_collection.aggregate(
                [
                    {
                        "$match": {
                            "filename": filename,
                            "end_dt": {"$gt": start_dt},
                            "start_dt": {"$lt": end_dt},
                        }
                    },
                    {"$sort": {"start_dt": pymongo.ASCENDING}},
                ]
            )

        return await cursor.to_list(None)

    async def delete_media_list(
        self,
        filename: Optional[str] = None,
        start_dt: Optional[datetime] = None,
        end_dt: Optional[datetime] = None,
        strict_inner: bool = True,
    ):
        media_list = await self.get_media_list(
            filename=filename,
            start_dt=start_dt,
            end_dt=end_dt,
            strict_inner=strict_inner,
        )
        grid_ids = [x["grid_id"] for x in media_list]
        await self.cdn.delete(*grid_ids)
        await self.info_collection.delete_many({"grid_id": {"$in": grid_ids}})
        return len(grid_ids)
