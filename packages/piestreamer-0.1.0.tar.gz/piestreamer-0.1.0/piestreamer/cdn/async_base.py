from abc import ABC, abstractmethod
from pathlib import Path
from typing import Generic, TypeVar

KeyType = TypeVar("KeyType")


class AsyncBaseCDN(ABC, Generic[KeyType]):
    def __init__(self):
        super().__init__()

    @abstractmethod
    async def host(self, path: Path, **kwargs) -> KeyType:
        raise NotImplementedError()

    @abstractmethod
    def url_for(self, key: KeyType) -> str:
        raise NotImplementedError()

    @abstractmethod
    async def delete(self, *keys: KeyType):
        raise NotImplementedError()

    @abstractmethod
    async def getsize(self, key: KeyType) -> int:
        raise NotImplementedError()

    @abstractmethod
    async def ping(self):
        raise NotImplementedError()
