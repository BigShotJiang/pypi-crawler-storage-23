import os
import sys
import traceback
from pathlib import Path
from typing import Literal, Optional, Union

import aioboto3
import aiofiles
import filetype
from bson import ObjectId
from tqdm.asyncio import tqdm

from .async_base import AsyncBaseCDN


class AsyncCloudFlareCDN(AsyncBaseCDN[str]):
    def __init__(
        self,
        endpoint_url: str,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        bucket_name: str,
        folder_name: str = "",
        public_url: Optional[str] = None,
        preserve_filenames: bool = False,
        preserve_suffixes: bool = False,
        **kwargs,
    ):
        super().__init__()
        self.endpoint_url = endpoint_url
        self.public_url = public_url or endpoint_url

        self.preserve_filenames = preserve_filenames
        self.preserve_suffixes = preserve_suffixes

        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key

        self.bucket_name = bucket_name
        self.kwargs = kwargs

        self.session = aioboto3.Session()

        print("PieStreamer CDN: ")
        print(f"Use Bucket: {self.bucket_name}")

        self.folder_name = folder_name
        print(f"Use folder: {self.folder_name}")

    async def __aenter__(self):
        self.resource_context_creator = self.session.resource(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.aws_access_key_id,
            aws_secret_access_key=self.aws_secret_access_key,
            **self.kwargs,
        )
        self.s3 = await self.resource_context_creator.__aenter__()
        try:
            self.bucket = await anext(
                (
                    bucket
                    async for bucket in self.s3.buckets.all()
                    if bucket.name == self.bucket_name
                ),
                None,
            )
            if self.bucket is None:
                print("WARNING: bucket not found, skipping", dict(
                    endpoint_url=self.endpoint_url,
                    aws_access_key_id=self.aws_access_key_id,
                    aws_secret_access_key=self.aws_secret_access_key,
                    **self.kwargs,
                ), file=sys.stderr)
                print("Available: ", file=sys.stderr)
                async for bucket in self.s3.buckets.all():
                    print(bucket.name, file=sys.stderr)
        except:
            traceback.print_exc()
            self.bucket = await self.s3.Bucket(self.bucket_name)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.bucket = None
        self.s3 = None
        await self.resource_context_creator.__aexit__(exc_type, exc_val, exc_tb)

    async def list_available_bucket_names(self):
        return [bucket async for bucket in self.s3.buckets.all()]

    def key4path(self, path: Path, key: Optional[str] = None):
        path = Path(path)
        if key is None:
            key = str(ObjectId() if not self.preserve_filenames else path.stem)

        if self.preserve_suffixes:
            key = key + path.suffix

        if self.folder_name:
            key = self.folder_name + "/" + key
        return key

    def key2id(self, key):
        if self.folder_name:
            key = key[len(self.folder_name) + 1 :]

        if self.preserve_suffixes:
            key = os.path.splitext(key)[0]

        if not self.preserve_filenames:
            key = ObjectId(key)
        return key

    def url2key(self, url):
        if not url.startswith(self.public_url):
            raise RuntimeError(f"Invalid URL: {url}")
        prefix = self.public_url
        if not prefix.endswith("/"):
            prefix = prefix + "/"
        return url[len(prefix) :]

    def url2id(self, url):
        return self.key2id(self.url2key(url))

    def is_valid_url(self, url: str):
        return url.startswith(self.public_url)

    async def host(
        self,
        path: Path,
        content_type: Optional[str] = None,
        key: Optional[str] = None,
        mode: Literal["rb", "r+", "r"] = "rb",
    ) -> str:
        path = Path(path)
        if content_type is None:
            content_type = filetype.guess(path).mime

        key = self.key4path(path=path, key=key)

        async with aiofiles.open(path, mode) as f:
            await self.bucket.put_object(
                Key=key,
                ACL="public-read",
                Body=await f.read(),
                Metadata={"Content-Type": content_type},
                ContentType=content_type,
            )
        return key

    def url_for(self, _id: Union[str, ObjectId]) -> str:
        return os.path.join(self.public_url, str(_id))

    def get_id_from_url(self, url):
        return self.url2id(url)

    async def list_keys(self):
        return [
            obj.key
            async for obj in self.bucket.objects.all()
            if not self.folder_name or obj.key.startswith(self.folder_name + "/")
        ]

    async def iter_keys(self):
        async for obj in tqdm(self.bucket.objects.iterator()):
            if not self.folder_name or obj.key.startswith(self.folder_name + "/"):
                yield obj.key

    async def iter_keys_by_pages(self):
        async for objs in tqdm(self.bucket.objects.pages()):
            yield [obj.key for obj in objs]

    async def iter_ids_by_pages(self):
        async for keys in self.iter_keys_by_pages():
            yield [self.key2id(key) for key in keys]

    async def list_ids(self):
        return [self.key2id(key) for key in await self.list_keys()]

    async def iter_ids(self):
        async for key in self.iter_keys():
            yield self.key2id(key)

    async def delete(self, *keys: str):
        return await self.delete_keys(*keys)

    async def delete_keys(self, *keys: str):
        if len(keys) == 0:
            return
        await self.bucket.delete_objects(
            Delete={
                "Objects": [{"Key": key} for key in keys[:1000]],
                "Quiet": True,
            },
        )
        if len(keys) > 1000:
            await self.delete_keys(*keys[1000:])

    async def drop(self):
        async for keys in self.iter_keys_by_pages():
            await self.delete_keys(*keys)

    async def get_size_by_key(self, key: str) -> int:
        obj = await self.bucket.Object(key=key)
        return await obj.content_length

    async def getsize(self, key: str) -> int:
        return await self.get_size_by_key(key)

    async def ping(self) -> dict:
        return {"status": "ok"}
