import os
import sys
from pathlib import Path
from typing import Optional

import boto3
import filetype
from bson import ObjectId
from tqdm import tqdm

from .base import BaseCDN


class CloudFlareCDN(BaseCDN[str]):
    """
    url = public_url/key
    key = transform(id)
    """

    def __init__(
        self,
        endpoint_url: str,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        bucket_name: str,
        folder_name: str = "",
        public_url: Optional[str] = None,
        preserve_filenames: bool = False,
        preserve_suffixes: bool = False,
        **kwargs,
    ):
        super().__init__()
        self.endpoint_url = endpoint_url
        self.public_url = public_url or endpoint_url

        self.preserve_filenames = preserve_filenames
        self.preserve_suffixes = preserve_suffixes

        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key

        self.s3 = boto3.resource(
            "s3",
            endpoint_url=endpoint_url,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
            **kwargs,
        )
        self.bucket = next(
            (bucket for bucket in self.s3.buckets.all() if bucket.name == bucket_name),
            None,
        )

        if self.bucket is None:
            self.bucket = self.s3.Bucket(bucket_name)
            print("WARN: Bucket is None", file=sys.stderr)
            print("Buckets: ", list(self.s3.buckets.all()), file=sys.stderr)

        print("PieStreamer CDN: ")
        print(f"Use Bucket: {self.bucket}")

        self.folder_name = folder_name
        print(f"Use folder: {self.folder_name}")

    def list_available_bucket_names(self):
        return [bucket.name for bucket in self.s3.buckets.all()]

    def key4path(self, path: Path, key: Optional[str] = None):
        path = Path(path)
        if key is None:
            key = str(ObjectId() if not self.preserve_filenames else path.stem)

        if self.preserve_suffixes:
            key = key + path.suffix

        if self.folder_name:
            key = self.folder_name + "/" + key
        return key

    def key2id(self, key):
        if self.folder_name:
            key = key[len(self.folder_name) + 1 :]

        if self.preserve_suffixes:
            key = os.path.splitext(key)[0]

        if not self.preserve_filenames:
            key = ObjectId(key)
        return key

    def url2key(self, url):
        if not url.startswith(self.public_url):
            raise RuntimeError(f"Invalid URL: {url}")
        prefix = self.public_url
        if not prefix.endswith("/"):
            prefix = prefix + "/"
        return url[len(prefix) :]

    def url2id(self, url):
        return self.key2id(self.url2key(url))

    def host(
        self,
        path: Path,
        content_type: Optional[str] = None,
        key: Optional[str] = None,
        mode="rb",
    ) -> str:
        path = Path(path)
        if content_type is None:
            content_type = filetype.guess(path).mime

        key = self.key4path(path=path, key=key)

        with path.open(mode) as f:
            self.bucket.put_object(
                Key=key, Body=f, Metadata={"Content-Type": content_type}
            )
        return key

    def url_for(self, key: str):
        return os.path.join(self.public_url, str(key))

    def is_valid_url(self, url: str):
        return url.startswith(self.public_url)

    def get_id_from_url(self, url):
        return self.url2id(url)

    def list_keys(self):
        return [
            obj.key
            for obj in self.bucket.objects.all()
            if not self.folder_name or obj.key.startswith(self.folder_name + "/")
        ]

    def iter_keys(self):
        for obj in tqdm(self.bucket.objects.iterator()):
            if not self.folder_name or obj.key.startswith(self.folder_name + "/"):
                yield obj.key

    def iter_keys_by_pages(self):
        for objs in tqdm(self.bucket.objects.pages()):
            yield [obj.key for obj in objs]

    def iter_ids_by_pages(self):
        for keys in self.iter_keys_by_pages():
            yield [self.key2id(key) for key in keys]

    def list_ids(self):
        return [self.key2id(key) for key in self.list_keys()]

    def iter_ids(self):
        for key in self.iter_keys():
            yield self.key2id(key)

    def delete(self, *keys: str):
        return self.delete_keys(*keys)

    def delete_keys(self, *keys: str):
        if len(keys) == 0:
            return
        self.bucket.delete_objects(
            Delete={
                "Objects": [{"Key": key} for key in keys[:1000]],
                "Quiet": True,
            },
        )
        if len(keys) > 1000:
            self.delete_keys(*keys[1000:])

    def drop(self):
        for keys in self.iter_keys_by_pages():
            self.delete_keys(*keys)

    def get_size_by_key(self, key: str) -> int:
        obj = self.bucket.Object(key=key)
        return obj.content_length

    def getsize(self, key: str) -> int:
        return self.get_size_by_key(key)

    def ping(self):
        return {"status": "ok"}
