from abc import ABC, abstractmethod
from pathlib import Path
from typing import Generic, TypeVar

KeyType = TypeVar("KeyType")


class BaseCDN(ABC, Generic[KeyType]):
    def __init__(self):
        super().__init__()

    @abstractmethod
    def host(self, path: Path, **kwargs) -> KeyType:
        raise NotImplementedError()

    @abstractmethod
    def url_for(self, key: KeyType) -> str:
        raise NotImplementedError()

    @abstractmethod
    def delete(self, *keys: KeyType):
        raise NotImplementedError()

    @abstractmethod
    def getsize(self, key: KeyType) -> int:
        raise NotImplementedError()

    @abstractmethod
    def ping(self):
        raise NotImplementedError()
