"""Compatibility module for base client types."""

from databricks_api.clients.base import BaseDatabricksClient, ClientOptions

__all__ = ["BaseDatabricksClient", "ClientOptions"]
