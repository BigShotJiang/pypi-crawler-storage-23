"""Compatibility client package namespace."""

from databricks_api.clients import AccountClient, WorkspaceClient

__all__ = ["AccountClient", "WorkspaceClient"]
