"""Compatibility generated endpoint namespace."""

from databricks_api.endpoints.generated.account_endpoints import ACCOUNT_2_0_ENDPOINTS, ACCOUNT_PREVIEW_ENDPOINTS
from databricks_api.endpoints.generated.workspace_endpoints import (
    WORKSPACE_2_0_ENDPOINTS,
    WORKSPACE_2_1_ENDPOINTS,
    WORKSPACE_PREVIEW_ENDPOINTS,
)

__all__ = [
    "ACCOUNT_2_0_ENDPOINTS",
    "ACCOUNT_PREVIEW_ENDPOINTS",
    "WORKSPACE_2_0_ENDPOINTS",
    "WORKSPACE_2_1_ENDPOINTS",
    "WORKSPACE_PREVIEW_ENDPOINTS",
]
