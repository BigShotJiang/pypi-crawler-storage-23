"""Compatibility module for endpoint catalog."""

from databricks_api.endpoints.catalog import ENDPOINT_CATALOG

__all__ = ["ENDPOINT_CATALOG"]
