"""Auto-generated endpoint constants.

Do not edit manually; regenerate with tools/generate_endpoints.py
"""


ACCOUNT_2_0_ENDPOINTS = {
    "budget_policies_create": "/api/2.0/accounts/budget-policies",
    "budget_policies_delete": "/api/2.0/accounts/budget-policies/{budget_policy_id}",
    "budget_policies_get": "/api/2.0/accounts/budget-policies/{budget_policy_id}",
    "budget_policies_list": "/api/2.0/accounts/budget-policies",
    "budget_policies_update": "/api/2.0/accounts/budget-policies/{budget_policy_id}",
    "credentials_create": "/api/2.0/accounts/credentials",
    "credentials_delete": "/api/2.0/accounts/credentials/{credentials_id}",
    "credentials_list": "/api/2.0/accounts/credentials",
    "customer_managed_keys_create": "/api/2.0/accounts/customer-managed-keys",
    "customer_managed_keys_delete": "/api/2.0/accounts/customer-managed-keys/{customer_managed_key_id}",
    "customer_managed_keys_list": "/api/2.0/accounts/customer-managed-keys",
    "groups_create": "/api/2.0/accounts/scim/v2/Groups",
    "groups_delete": "/api/2.0/accounts/scim/v2/Groups/{group_id}",
    "groups_get": "/api/2.0/accounts/scim/v2/Groups/{group_id}",
    "groups_list": "/api/2.0/accounts/scim/v2/Groups",
    "groups_patch": "/api/2.0/accounts/scim/v2/Groups/{group_id}",
    "log_delivery_create": "/api/2.0/accounts/log-delivery",
    "log_delivery_delete": "/api/2.0/accounts/log-delivery/{log_delivery_configuration_id}",
    "log_delivery_get": "/api/2.0/accounts/log-delivery/{log_delivery_configuration_id}",
    "log_delivery_list": "/api/2.0/accounts/log-delivery",
    "log_delivery_patch": "/api/2.0/accounts/log-delivery/{log_delivery_configuration_id}",
    "networks_create": "/api/2.0/accounts/networks",
    "networks_delete": "/api/2.0/accounts/networks/{network_id}",
    "networks_list": "/api/2.0/accounts/networks",
    "private_access_settings_create": "/api/2.0/accounts/private-access-settings",
    "private_access_settings_delete": "/api/2.0/accounts/private-access-settings/{private_access_settings_id}",
    "private_access_settings_list": "/api/2.0/accounts/private-access-settings",
    "storage_configurations_create": "/api/2.0/accounts/storage-configurations",
    "storage_configurations_delete": "/api/2.0/accounts/storage-configurations/{storage_configuration_id}",
    "storage_configurations_list": "/api/2.0/accounts/storage-configurations",
    "users_create": "/api/2.0/accounts/scim/v2/Users",
    "users_delete": "/api/2.0/accounts/scim/v2/Users/{user_id}",
    "users_get": "/api/2.0/accounts/scim/v2/Users/{user_id}",
    "users_list": "/api/2.0/accounts/scim/v2/Users",
    "users_patch": "/api/2.0/accounts/scim/v2/Users/{user_id}",
    "vpc_endpoints_create": "/api/2.0/accounts/vpc-endpoints",
    "vpc_endpoints_delete": "/api/2.0/accounts/vpc-endpoints/{vpc_endpoint_id}",
    "vpc_endpoints_list": "/api/2.0/accounts/vpc-endpoints",
    "workspaces_create": "/api/2.0/accounts/workspaces",
    "workspaces_delete": "/api/2.0/accounts/workspaces/{workspace_id}",
    "workspaces_get": "/api/2.0/accounts/workspaces/{workspace_id}",
    "workspaces_list": "/api/2.0/accounts/workspaces",
    "workspaces_update": "/api/2.0/accounts/workspaces/{workspace_id}",
}

ACCOUNT_PREVIEW_ENDPOINTS = {
}
