from bot_framework.domain.language_management.loaders.language_loader import (
    LanguageLoader,
)
from bot_framework.domain.language_management.loaders.phrase_loader import PhraseLoader

__all__ = ["LanguageLoader", "PhraseLoader"]
