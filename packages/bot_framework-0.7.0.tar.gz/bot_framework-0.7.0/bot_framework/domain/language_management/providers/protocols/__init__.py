from bot_framework.domain.language_management.providers.protocols.i_phrase_provider import (
    IPhraseProvider,
)

__all__ = ["IPhraseProvider"]
