from __future__ import annotations

from bot_framework.domain.flow_management.entities.flow_stack_entry import (
    FlowStackEntry,
)

__all__ = ["FlowStackEntry"]
