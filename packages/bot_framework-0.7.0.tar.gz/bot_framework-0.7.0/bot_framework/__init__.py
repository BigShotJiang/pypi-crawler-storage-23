"""
Bot Framework - A reusable Python library for building Telegram bots.

This package provides core components for building Telegram bots with
Clean Architecture principles.
"""

from bot_framework.domain.decorators.role_checker import (
    OperationNotAllowedError,
    check_message_roles,
    check_roles,
)
from bot_framework.core.entities.bot_callback import BotCallback
from bot_framework.core.entities.bot_message import BotMessage, BotMessageUser
from bot_framework.core.entities.bot_user import BotUser
from bot_framework.core.entities.button import Button
from bot_framework.core.entities.keyboard import Keyboard
from bot_framework.core.entities.language_code import LanguageCode
from bot_framework.core.entities.parse_mode import ParseMode
from bot_framework.core.entities.role import Role
from bot_framework.core.entities.role_name import RoleName
from bot_framework.core.entities.user import User
from bot_framework.core.protocols.i_callback_answerer import ICallbackAnswerer
from bot_framework.core.protocols.i_callback_handler import ICallbackHandler
from bot_framework.core.protocols.i_callback_handler_registry import (
    ICallbackHandlerRegistry,
)
from bot_framework.core.protocols.i_document_downloader import IDocumentDownloader
from bot_framework.core.protocols.i_document_sender import IDocumentSender
from bot_framework.core.protocols.i_flow_router import IFlowRouter
from bot_framework.core.protocols.i_message_deleter import IMessageDeleter
from bot_framework.core.protocols.i_message_handler import IMessageHandler
from bot_framework.core.protocols.i_message_handler_registry import (
    IMessageHandlerRegistry,
)
from bot_framework.core.protocols.i_message_replacer import IMessageReplacer
from bot_framework.core.protocols.i_message_sender import IMessageSender
from bot_framework.core.protocols.i_notify_replacer import INotifyReplacer

__version__ = "0.1.0"

__all__ = [
    # Decorators
    "OperationNotAllowedError",
    "check_message_roles",
    "check_roles",
    # Entities
    "BotCallback",
    "BotMessage",
    "BotMessageUser",
    "BotUser",
    "Button",
    "Keyboard",
    "LanguageCode",
    "ParseMode",
    "Role",
    "RoleName",
    "User",
    # Protocols
    "ICallbackAnswerer",
    "ICallbackHandler",
    "ICallbackHandlerRegistry",
    "IDocumentDownloader",
    "IDocumentSender",
    "IFlowRouter",
    "IMessageDeleter",
    "IMessageHandler",
    "IMessageHandlerRegistry",
    "IMessageReplacer",
    "IMessageSender",
    "INotifyReplacer",
]
