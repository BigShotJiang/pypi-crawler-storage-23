-- Rollback 0004: Max dialogs table

DROP TABLE IF EXISTS max_dialogs;
