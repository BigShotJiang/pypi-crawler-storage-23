DELETE FROM roles WHERE name IN ('user', 'supervisors');
DELETE FROM languages WHERE code IN ('en', 'ru');
