from setuptools import setup
from setuptools.command.build_py import build_py
import os
import shutil


class CustomBuildPy(build_py):
    """Custom build command that copies proto files into the package."""

    def run(self):
        super().run()
        protos_src = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'protos')
        protos_dst = os.path.join(self.build_lib, 'nexus_proto', 'protos')
        if os.path.exists(protos_src):
            if os.path.exists(protos_dst):
                shutil.rmtree(protos_dst)
            shutil.copytree(protos_src, protos_dst)


setup(
    cmdclass={'build_py': CustomBuildPy},
)
