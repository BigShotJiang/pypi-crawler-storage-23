"""
File domain module.

Sections:
1. Domain Events
2. Agent Runners
3. Public Entrypoint
4. Resolution
"""

import logging
from collections.abc import Awaitable
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from typing_extensions import override

from claude_agent_sdk import ResultMessage

from .agents import run_agent
from .agents.files import FilesClassifier, FilesClassifierInput
from .agents.observability import observe
from .csv_utils import ValidationIssue
from .events import Event, event, log_events, publish
from .file_schemas import (
    FILES_MANIFEST,
    FilesManifestEntry,
)
from .models import File
from .runs import with_run_context
from .sandbox import create_agent_sandbox_dir
from .storage import (
    discover_files,
    materialize,
    stage_files_to_sandbox,
)

# ============================================
# 1. DOMAIN EVENTS
# ============================================


@event
class FilesClassificationStarted(Event, frozen=True):
    """Emitted when the Files Classifier agent begins analyzing files."""

    files: list[File]
    discovered_count: int

    @override
    def message(self) -> str:
        n = len(self.files)
        if n == self.discovered_count:
            return f"Classifying {n} files"
        return f"Classifying {n}/{self.discovered_count} files"


@event
class FilesClassificationCompleted(Event, frozen=True):
    """Emitted when the Files Classifier agent finishes classifying files."""

    files: list[File]
    artifact_uri: str

    @override
    def message(self) -> str:
        headers = ("Name", "Records", "Aggregation", "Frequency", "Date Range")
        rows: list[tuple[str, ...]] = []
        for f in self.files:
            rows.append(
                (
                    f.name,
                    ", ".join(f.records) or "—",
                    ", ".join(f.aggregations) or "—",
                    ", ".join(f.frequencies) or "—",
                    f"{f.date_range.min:%Y-%m} – {f.date_range.max:%Y-%m}" if f.date_range else "—",
                )
            )
        # Column widths: max of header and all cell values, plus 2 gutter
        widths = [max(len(h), *(len(r[i]) for r in rows)) + 2 for i, h in enumerate(headers)]
        lines = [f"{len(self.files)} files classified"]
        lines.append("  " + "".join(h.ljust(w) for h, w in zip(headers, widths)))
        for row in rows:
            lines.append("  " + "".join(cell.ljust(w) for cell, w in zip(row, widths)))
        lines.append(f"  Details: {self.artifact_uri}")
        return "\n".join(lines)


@event
class FilesClassificationFailed(Event, frozen=True):
    """Emitted when file classification fails."""

    files: list[File]
    error: str

    @override
    def message(self) -> str:
        return f"File classification failed: {self.error}"

    @override
    def level(self) -> int:
        return logging.ERROR


# ============================================
# 2. AGENT RUNNERS
# ============================================


@dataclass(frozen=True)
class FileResult:
    """Materialized file and its validation issues."""

    file: File
    issues: tuple[ValidationIssue, ...]


@dataclass(frozen=True)
class FilesClassifierResult:
    """Output from a files classifier run."""

    classified: list[File]
    manifest: FileResult
    result: ResultMessage


class FilesClassifierRunner(Protocol):
    def __call__(
        self,
        files: list["File"],
        /,
        discovered_count: int,
        *,
        model: str | None = None,
        trace: bool = True,
    ) -> Awaitable[FilesClassifierResult]: ...


@observe(name="files_classifier")
async def _run_files_classifier(
    files: list[File],
    /,
    discovered_count: int,
    *,
    model: str | None = None,
    trace: bool = True,
) -> FilesClassifierResult:
    """
    Classify files by running the FilesClassifier agent in a sandbox.

    Returns classified files matching the input IDs.
    """
    publish(FilesClassificationStarted(files=files, discovered_count=discovered_count))

    try:
        # Create temp sandbox dir
        with create_agent_sandbox_dir() as sandbox_dir:
            # Stage files for classification
            staged_files = stage_files_to_sandbox(files, sandbox_dir)

            # Write a manifest so the agent can enumerate files.
            staged_entries = [FilesManifestEntry.from_model(f, sandbox_dir) for f in staged_files]
            files_manifest_path = FILES_MANIFEST.dump(sandbox_dir, staged_entries)

            # Agent input schema — path is relative to sandbox root
            agent_input = FilesClassifierInput(files_manifest_path=files_manifest_path)

            # Run the agent (writes classification.csv to .ansel via output model).
            result_message = await run_agent(
                FilesClassifier(), agent_input, sandbox_dir, model=model, trace=trace
            )

            # Validate agent output in sandbox before materialization
            files_manifest_validation_result = FILES_MANIFEST.validate_file(
                sandbox_dir,
                immutable_values=FILES_MANIFEST.immutable_row_values(staged_entries),
            )

            # Persist agent output to durable storage (audit artifact)
            files_manifest = materialize(FILES_MANIFEST, sandbox_dir, agent_name="files_classifier")

            files_manifest_entries = FILES_MANIFEST.load(sandbox_dir)

        entries_by_id = {e.id: e for e in files_manifest_entries}
        classified_files = [
            entries_by_id[f.id].to_model(f) if f.id in entries_by_id else f for f in files
        ]

        publish(
            FilesClassificationCompleted(
                files=classified_files,
                artifact_uri=files_manifest.relative_path or files_manifest.name,
            )
        )
        return FilesClassifierResult(
            classified=classified_files,
            manifest=FileResult(
                file=files_manifest, issues=files_manifest_validation_result.issues
            ),
            result=result_message,
        )
    except Exception as exc:
        publish(FilesClassificationFailed(files=files, error=str(exc)))
        raise


# ============================================
# 3. PUBLIC ENTRYPOINT
# ============================================


@log_events
async def files(
    files: File | list[File] | None = None,
    *,
    data_dir: str | None = None,
    model: str | None = None,
    trace: bool = True,
) -> list[File]:
    """
    Public entrypoint: discover and classify data files.

    Files are auto-discovered from the default data directory when
    omitted. Provided files are classified if not already.

    Args:
        files: Input data files. Accepts a single File, a list, or None
            to discover from the default data directory.
        data_dir: Directory to scan for files during auto-discovery.
        model: LLM model override for agent calls.
        trace: Whether to enable tracing for agent calls.

    Returns:
        Classified files.
    """
    resolved_dir = Path(data_dir) if data_dir is not None else None
    with with_run_context():
        if files is None:
            return await resolve_files(data_dir=resolved_dir, model=model, trace=trace)

        input_files = [files] if isinstance(files, File) else files
        return await resolve_files(input_files, data_dir=resolved_dir, model=model, trace=trace)


# ============================================
# 4. RESOLUTION
# ============================================


async def resolve_files(
    files: list[File] | None = None,
    runner: FilesClassifierRunner = _run_files_classifier,
    /,
    *,
    data_dir: Path | None = None,
    model: str | None = None,
    trace: bool = True,
) -> list[File]:
    """
    Ensure files exist and are classified.

    - If `files` is None, discover files from the default data source.
    - Raises ValueError if no files are available after discovery.
    - Only unclassified files are sent to the classifier; pre-classified inputs are preserved.
    - The returned list preserves input order.

    Args:
            files: Input files. When omitted, collect from the default data directory.
            runner: Callable used to classify files when needed.
            data_dir: Directory to scan for files during auto-discovery.

    Returns:
            Classified files.

    Raises:
            ValueError: If no files are available.
    """
    if files is None:
        files = discover_files(data_dir)
    if not files:
        raise ValueError("files required")

    files_need_classification = [file for file in files if not file.is_classified]
    if not files_need_classification:
        return files

    # Run the classifier agent
    classifier_result = await runner(
        files_need_classification, discovered_count=len(files), model=model, trace=trace
    )
    files_classified_by_id = {file.id: file for file in classifier_result.classified}

    missing_file_ids = [
        file.id for file in files_need_classification if file.id not in files_classified_by_id
    ]
    if missing_file_ids:
        raise ValueError(f"Missing classifications for: {', '.join(missing_file_ids)}")

    # Return the full input set in order, merging newly classified files with any pre-classified ones.
    return [files_classified_by_id.get(file.id, file) for file in files]
