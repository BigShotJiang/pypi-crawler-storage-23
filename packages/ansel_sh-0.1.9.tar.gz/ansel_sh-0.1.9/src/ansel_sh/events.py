"""
Base event module.

Contents:
1) Base Types
2) Internal Bus
3) Public Helpers
4) Logging and Env Configuration
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from collections.abc import Awaitable, Callable, Coroutine
from datetime import datetime
from functools import wraps
from typing import ClassVar, ParamSpec, TypeVar

from typing_extensions import override

from pydantic import BaseModel, Field

from .utils import utc_now

logger = logging.getLogger(__name__)
event_logger = logging.getLogger("ansel")

EventType = TypeVar("EventType", bound="Event")
P = ParamSpec("P")
R = TypeVar("R")
# ============================================
# 1) BASE TYPES
# ============================================


class Event(BaseModel, frozen=True):
    """
    Base class for all domain events.

    Attributes:
        timestamp: When the event occurred.
    """

    timestamp: datetime = Field(default_factory=utc_now)

    def message(self) -> str:
        """Return a human-friendly log message, or ``""`` to suppress logging."""
        return ""

    def level(self) -> int:
        """Return the logging level for the event."""
        return logging.INFO


EventHandlerReturn = None | Awaitable[None]
EventHandler = Callable[[Event], EventHandlerReturn]


# ============================================
# 2) INTERNAL BUS
# ============================================


class _Bus:
    """
    In-process event bus for domain events.

    This is a lightweight, SDK-only bus: events are delivered to in-process
    subscribers immediately (sync or async callbacks).

    Considerations:
    - No persistence, no delivery guarantees, no cross-process fan-out.
    - Order is best-effort based on publish sequence.

    Future extensions (adapters) can subscribe to this bus and relay events to:
    - SSE/WebSocket streams for UI/remote consumers.
    - Message queues (Kafka/NATS) for durable processing.
    - Tracing/metrics sinks for observability.
    """

    _subscribers: ClassVar[dict[type[Event], list[EventHandler]]] = {}
    _global_subscribers: ClassVar[list[EventHandler]] = []
    _registry: ClassVar[set[type[Event]]] = set()

    @classmethod
    def register(cls, event_type: type[EventType]) -> type[EventType]:
        """Register an event type for discovery/introspection."""
        cls._registry.add(event_type)
        return event_type

    @classmethod
    def registered(cls) -> tuple[type[Event], ...]:
        """Return registered event types."""
        return tuple(cls._registry)

    @classmethod
    def publish(cls, event: Event) -> None:
        """Publish event to all subscribers."""
        event_type = type(event)

        for callback in cls._subscribers.get(event_type, []):
            cls._dispatch(callback, event)

        for callback in cls._global_subscribers:
            cls._dispatch(callback, event)

    @classmethod
    def subscribe(
        cls,
        event_type: type[Event],
        callback: EventHandler,
    ) -> Callable[[], None]:
        """Subscribe to a specific event type. Returns unsubscribe function."""
        cls._subscribers.setdefault(event_type, []).append(callback)

        def unsubscribe() -> None:
            cls._subscribers[event_type].remove(callback)

        return unsubscribe

    @classmethod
    def subscribe_all(cls, callback: EventHandler) -> Callable[[], None]:
        """Subscribe to all events. Returns unsubscribe function."""
        cls._global_subscribers.append(callback)

        def unsubscribe() -> None:
            cls._global_subscribers.remove(callback)

        return unsubscribe

    @classmethod
    def clear(cls) -> None:
        """Clear all subscribers (for testing)."""
        cls._subscribers.clear()
        cls._global_subscribers.clear()
        cls._registry.clear()

    @classmethod
    def _dispatch(cls, callback: EventHandler, event: Event) -> None:
        try:
            result = callback(event)
            if asyncio.iscoroutine(result):
                _ = asyncio.create_task(result)
        except Exception as exc:
            logger.error("Event handler error: %s", exc, exc_info=True)


# ============================================
# 3) PUBLIC HELPERS
# ============================================


def event(cls: type[EventType]) -> type[EventType]:
    """Register a domain event type with the internal bus."""
    return _Bus.register(cls)


def publish(event: Event) -> None:
    """Publish a domain event via the internal bus."""
    _Bus.publish(event)


def subscribe_all(callback: EventHandler) -> Callable[[], None]:
    """Subscribe to all domain events. Returns an unsubscribe function."""
    return _Bus.subscribe_all(callback)


def log_events(func: Callable[P, Awaitable[R]]) -> Callable[P, Coroutine[None, None, R]]:
    """
    Decorator that enables env-driven event logging.

    Use on public SDK entrypoints to keep event wiring internal.
    """

    @wraps(func)
    async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        _configure_event_logging_from_env()
        return await func(*args, **kwargs)

    return wrapper


# ============================================
# 4) LOGGING AND ENV CONFIGURATION
# ============================================

_logging_initialized = False
_logging_unsubscribe: Callable[[], None] | None = None
_t0: float = 0.0


class _ElapsedFormatter(logging.Formatter):
    """Log formatter that prefixes each line with elapsed time since init."""

    @override
    def format(self, record: logging.LogRecord) -> str:
        elapsed = time.monotonic() - _t0
        msg = record.getMessage()
        first, *rest = msg.splitlines()
        lines = [f"[{elapsed:6.1f}s] {first}"]
        for line in rest:
            lines.append(f"         {line}")
        return "\n".join(lines)


def _parse_logging_level(value: str) -> int | None:
    normalized = value.strip().upper()
    if not normalized:
        return None
    return logging._nameToLevel.get(normalized)  # pyright:ignore [reportPrivateUsage]


def configure_event_logging(verbose: bool = False) -> None:
    """
    Enable event logging.

    Precedence: ANSEL_LOGGING_LEVEL env var > ``verbose`` flag > default (INFO).
    No-op after the first successful call.
    """
    global _logging_initialized
    global _logging_unsubscribe
    global _t0

    if _logging_initialized:
        return

    env_level = os.getenv("ANSEL_LOGGING_LEVEL")
    if env_level is not None:
        # Env var is set (even if empty) — it wins
        if not env_level:
            _logging_initialized = True
            return  # empty string = suppress all
        level = _parse_logging_level(env_level)
        if level is None:
            logger.warning(
                "Invalid ANSEL_LOGGING_LEVEL=%r; expected DEBUG/INFO/WARNING/ERROR",
                env_level,
            )
            return
    else:
        # No env var — use verbose flag
        level = logging.DEBUG if verbose else logging.INFO

    _t0 = time.monotonic()
    is_debug = level <= logging.DEBUG

    event_logger.setLevel(level)
    event_logger.propagate = False
    if not event_logger.handlers:
        handler = logging.StreamHandler()
        handler.setLevel(level)
        if is_debug:
            handler.setFormatter(
                logging.Formatter(
                    "%(levelname)-5s Ansel %(asctime)s %(message)s",
                    datefmt="%H:%M:%S",
                )
            )
        else:
            # In INFO mode, only show records from the event bus callback.
            # Direct logger.warning() calls (e.g. validation issues) are
            # suppressed — they surface in DEBUG mode instead.
            handler.addFilter(lambda record: getattr(record, "_from_event_bus", False))
            handler.setFormatter(_ElapsedFormatter())
        event_logger.addHandler(handler)

    def log_event(ev: Event) -> None:
        msg = ev.message()
        tag = type(ev).__name__
        if is_debug:
            line = f"{tag}: {msg}" if msg else tag
            event_logger.log(ev.level(), "%s", line)
        elif msg:
            event_logger.log(ev.level(), "%s", msg, extra={"_from_event_bus": True})

    _logging_unsubscribe = _Bus.subscribe_all(log_event)
    _logging_initialized = True

    from .env import detect_auth_method

    _ = detect_auth_method()


def _configure_event_logging_from_env() -> None:
    """Fallback for ``@log_events`` decorator — delegates with default verbose."""
    configure_event_logging(verbose=False)
