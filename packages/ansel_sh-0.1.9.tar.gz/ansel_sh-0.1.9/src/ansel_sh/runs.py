"""Run context and output directory helpers."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path

from pydantic import BaseModel

_RUN_CONTEXT: ContextVar[RunContext | None] = ContextVar("ansel_run_context", default=None)


class RunContext(BaseModel):
    """Represents a single SDK run and its output directory."""

    run_id: int
    output_dir: Path


def _next_run_id(base_dir: Path, /) -> int:
    if not base_dir.exists():
        return 1
    run_ids: list[int] = []
    for entry in base_dir.iterdir():
        if entry.is_dir() and entry.name.isdigit():
            run_ids.append(int(entry.name))
    return max(run_ids, default=0) + 1


def get_current_run_context() -> RunContext:
    """
    Return the current run context, creating one lazily if needed.

    Runs are stored under .ansel/<run_id>.
    """
    current = _RUN_CONTEXT.get()
    if current is not None:
        return current

    base_dir = Path.cwd() / ".ansel"
    run_id = _next_run_id(base_dir)
    output_dir = base_dir / str(run_id)
    current = RunContext(run_id=run_id, output_dir=output_dir)
    _ = _RUN_CONTEXT.set(current)
    return current


@contextmanager
def with_run_context(run_id: int | None = None, /) -> Iterator[RunContext]:
    """
    Establish a run context for the duration of the block.

    If run_id is omitted and a context already exists, it is reused.
    """
    current = _RUN_CONTEXT.get()
    if run_id is None and current is not None:
        yield current
        return

    base_dir = Path.cwd() / ".ansel"
    if run_id is None:
        run_id = _next_run_id(base_dir)
    run = RunContext(run_id=run_id, output_dir=base_dir / str(run_id))
    token = _RUN_CONTEXT.set(run)
    try:
        yield run
    finally:
        _RUN_CONTEXT.reset(token)
