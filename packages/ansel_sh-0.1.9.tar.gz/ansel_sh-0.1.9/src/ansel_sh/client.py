"""Ansel client — holds configuration for SDK calls."""

from __future__ import annotations

import asyncio

from .events import configure_event_logging
from .files import files as files_async
from .forecast_models import ForecastModel
from .forecast_models import forecast_models as forecast_models_async
from .forecasts import Forecast
from .forecasts import forecasts as forecasts_async
from .models import File, Series
from .series import series as series_async


class Ansel:
    """Ansel client. Holds configuration for SDK calls.

    Args:
        model: LLM model override for all agent calls. None uses agent defaults.
        verbose: False → INFO logging (elapsed time only).
                 True  → DEBUG logging (timestamps, class names, all events).
    """

    model: str | None
    verbose: bool

    def __init__(
        self,
        *,
        model: str | None = None,
        verbose: bool = False,
    ) -> None:
        self.model = model
        self.verbose = verbose

    def forecasts(
        self,
        files: File | list[File] | None = None,
        series: Series | list[Series] | None = None,
        *,
        data_dir: str | None = None,
    ) -> list[Forecast]:
        """Generate forecasts."""
        configure_event_logging(self.verbose)
        return asyncio.run(
            forecasts_async(
                files=files,
                series=series,
                data_dir=data_dir,
                model=self.model,
                trace=True,
            )
        )

    def models(
        self,
        files: File | list[File] | None = None,
        series: Series | list[Series] | None = None,
    ) -> list[ForecastModel]:
        """Train forecast models."""
        configure_event_logging(self.verbose)
        return asyncio.run(
            forecast_models_async(
                files=files,
                series=series,
                model=self.model,
                trace=True,
            )
        )

    def series(
        self,
        files: File | list[File] | None = None,
        series: Series | list[Series] | None = None,
    ) -> list[Series]:
        """Extract series from files."""
        configure_event_logging(self.verbose)
        return asyncio.run(
            series_async(
                files=files,
                series=series,
                model=self.model,
                trace=True,
            )
        )

    def files(
        self,
        files: File | list[File] | None = None,
        *,
        data_dir: str | None = None,
    ) -> list[File]:
        """Resolve and classify files."""
        configure_event_logging(self.verbose)
        return asyncio.run(
            files_async(
                files=files,
                data_dir=data_dir,
                model=self.model,
                trace=True,
            )
        )
