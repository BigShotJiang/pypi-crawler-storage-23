"""Shared utility functions and constants."""

import asyncio
from collections.abc import Awaitable, Iterable
from datetime import datetime, timezone
from typing import Callable, Literal, TypeVar
from uuid import uuid4

T = TypeVar("T")
R = TypeVar("R")

# Type aliases
ForecastInterval = Literal["week", "month", "quarter"]

# Defaults
DEFAULT_CONCURRENCY = 10
DEFAULT_TARGET = "demand"
DEFAULT_FORECAST_INTERVAL: ForecastInterval = "month"
DEFAULT_HORIZON = 12
DEFAULT_SERIES_TO_EXTRACT = 10


def utc_now() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(timezone.utc)


def generate_id(prefix: str) -> str:
    """Generate a prefixed unique ID."""
    return f"{prefix}_{uuid4().hex[:12]}"


async def pool(
    items: Iterable[T],
    worker: Callable[[T], Awaitable[R]],
    concurrency: int = DEFAULT_CONCURRENCY,
) -> list[R | BaseException]:
    """Like asyncio.gather(*[worker(x) for x in items], return_exceptions=True) with bounded concurrency."""
    semaphore = asyncio.Semaphore(concurrency)

    async def bounded(item: T) -> R:
        async with semaphore:
            return await worker(item)

    return await asyncio.gather(
        *[bounded(item) for item in items],
        return_exceptions=True,
    )
