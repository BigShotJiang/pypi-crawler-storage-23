"""Error types for agent operations.

Extends Claude SDK's error hierarchy so users can catch all errors uniformly.
"""

from claude_agent_sdk import ClaudeSDKError, ResultMessage

__all__ = [
    "ClaudeSDKError",
    "AgentError",
    "AuthenticationError",
    "StructuredOutputRetriesError",
    "raise_for_result",
]


class AgentError(ClaudeSDKError):
    """
    Agent returned an error result.

    Attributes:
            result: The ResultMessage from Claude with is_error=True.
    """

    result: ResultMessage

    def __init__(self, result: ResultMessage) -> None:
        self.result = result
        super().__init__(result.result or "Unknown agent error")


class AuthenticationError(AgentError):
    """
    Invalid or missing API key.

    Not retryable without fixing credentials.
    """

    pass


class StructuredOutputRetriesError(AgentError):
    """
    Agent exceeded retries while producing structured output.

    See https://platform.claude.com/docs/en/agent-sdk/structured-outputs
    """

    pass


def raise_for_result(result: ResultMessage) -> None:
    """
    Raise appropriate error if result indicates failure.

    No-op when the result is successful (is_error=False and no error subtype).

    Args:
            result: The ResultMessage to check.

    Raises:
            StructuredOutputRetriesError: If the agent exhausted structured output
                    retries (checked regardless of is_error).
            AuthenticationError: If the error is due to invalid/missing API key.
            AgentError: For other agent errors (is_error=True).
    """
    if result.subtype == "error_max_structured_output_retries":
        raise StructuredOutputRetriesError(result)
    if not result.is_error:
        return

    msg = result.result or ""
    if msg.startswith("Invalid API key"):
        raise AuthenticationError(result)
    raise AgentError(result)
