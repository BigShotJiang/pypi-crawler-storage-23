from __future__ import annotations

import logging
import os
import socket
from collections.abc import Callable
from typing import TypeVar, cast, overload

logger = logging.getLogger(__name__)

# Dev-only Laminar helpers: initialize the client and provide a safe observe decorator.

F = TypeVar("F", bound=Callable[..., object])


@overload
def observe(func: F) -> F: ...


@overload
def observe(*, name: str | None = None) -> Callable[[F], F]: ...


def _is_reachable(host: str, port: int, timeout: float = 0.5) -> bool:
    """Check if a TCP port is accepting connections."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def init_laminar() -> None:
    """
    Initialize Laminar for dev/test usage.

    Skips initialization when the Laminar server is not reachable.
    """
    try:
        from lmnr import Laminar
    except ImportError:
        return

    grpc_port = 8001
    if not _is_reachable("localhost", grpc_port):
        logger.debug("Laminar server not reachable on port %d, skipping tracing", grpc_port)
        return

    Laminar.initialize(
        project_api_key=os.getenv("LMNR_PROJECT_API_KEY"),
        base_url="http://localhost",
        http_port=8000,
        grpc_port=grpc_port,
        disable_batch=True,
    )


def observe(*args: object, **kwargs: object) -> Callable[[F], F] | F:
    """
    Provide a no-op observe decorator when lmnr isn't installed.
    """
    try:
        from lmnr import observe as _observe
    except ImportError:
        if args and callable(args[0]) and len(args) == 1 and not kwargs:
            return cast(F, args[0])

        def decorator(func: F) -> F:
            return func

        return decorator
    return cast(Callable[[F], F] | F, _observe(*args, **kwargs))


def get_trace_url() -> str | None:
    """
    Best-effort helper to read the current Laminar trace URL.

    Returns None if lmnr isn't installed, no trace is active, or no base URL is set.
    """
    try:
        from lmnr import Laminar  # type: ignore[import-not-found]
    except ImportError:
        return None

    try:
        trace_id = Laminar.get_trace_id()
    except Exception:
        return None
    if not trace_id:
        return None

    # TODO: make UI base URL dynamic/configurable.
    ui_base_url = "http://localhost:5667"

    # TODO: remove hardcoded project ID
    PROJECT_ID = "559f25fb-2383-49d3-9936-c9b9bfb9777f"

    return f"{ui_base_url.rstrip('/')}/project/{PROJECT_ID}/traces?traceId={trace_id}"


def add_trace_tags(tags: list[str]) -> None:
    """
    Best-effort helper to add tags to the current Laminar span.
    """
    try:
        from lmnr import Laminar  # type: ignore[import-not-found]
    except ImportError:
        return
    try:
        Laminar.add_span_tags(tags)
    except Exception:
        return
