# remottxrea/config/apis.py
import random
from typing import List, Tuple

# ساختار:
# x[0] -> API_ID
# x[1] -> API_HASH

APIS = [
    (33059517, "f7f7200dcbd0f8038bb5af206b1e5c19"),
    (31232274, "92f38a47924736eb004db1a9a648b748"),
    (36633592, "42d3ac08e68ab1226d26f5fa3adbcdbd"),
    (32269886, "951fe1e373f0ff5cc41c9fcf9df20483"),
    (36146173, "777603fa155da92027e89705f2b08c4b"),
    (34377439, "41fcf8737f473591e76868b03c5e677f"),
    (20190576, "5e869142c67a9faa1a0f7c47319ab7cf"),
    (38869775, "1bebdef7ac8aaea4b07373b637663ec4"),
    (36158550, "7591167b73855e29eb7b7dcdc090e679"),
    (33031011, "d826294cf03f8b66dbea9ff5a8ba67b1"),
    (37425600, "d9842a21ebdbbe6d6626be362cec25a0"),
]


def get_apis():
    """
    Returns list of (api_id, api_hash)
    Usage:
        for api_id, api_hash in get_apis():
            ...
    """
    api= random.randint(0,10)
    return APIS[api]
