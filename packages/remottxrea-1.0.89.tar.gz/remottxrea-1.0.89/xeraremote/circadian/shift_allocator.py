# remottxrea/circadian/shift_allocator.py

from math import ceil


class ShiftAllocator:

    def __init__(self, accounts, duration_hours: int):

        if 24 % duration_hours != 0:
            raise ValueError(
                "Duration must divide 24 evenly."
            )

        self.accounts = accounts
        self.duration = duration_hours
        self.shift_count = 24 // duration_hours

    # ---------- SPLIT ----------
    def allocate(self):

        per_shift = ceil(
            len(self.accounts) /
            self.shift_count
        )

        shifts = []

        for i in range(self.shift_count):

            start = i * per_shift
            end = start + per_shift

            shifts.append(
                self.accounts[start:end]
            )

        return shifts
