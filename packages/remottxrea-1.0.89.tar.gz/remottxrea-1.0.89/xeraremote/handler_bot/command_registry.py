# remottxrea/bot/command_registry.py

from .handlers.add_account import AddAccountHandler
from .handlers.change_name import ChangeNameHandler
from .handlers.change_photo import ChangePhotoHandler
from .handlers.join_leave import JoinLeaveHandler
from .handlers.list_account import AccountOverviewHandler
from .handlers.start import Start

from ..runner.multi_session_runner import MultiSessionRunner


class CommandRegistry:
    """
    Central command → handler registry
    All dependencies injected here
    """

    def __init__(self):

        # ---- shared runner ----
        self.runner = MultiSessionRunner()

        # ---- handlers ----
        self.add_account = AddAccountHandler()
        self.change_name = ChangeNameHandler(self.runner)
        self.change_photo = ChangePhotoHandler(self.runner)
        self.join_leave = JoinLeaveHandler(self.runner)
        self.list_accounts = AccountOverviewHandler(self.runner)
        self.start_bot = Start()

        # ---- command map ----
        self.command_map = {
            # start
            "/start": self.start_bot,
            # add account (stateful)
            "/addaccount": self.add_account,

            #list account
            "/listacc":self.list_accounts,

            # name
            "/changefname": self.change_name,
            "/changename": self.change_name,

            # photo (reply-based)
            "/changephoto": self.change_photo,

            # join / leave
            "/join": self.join_leave,
            "/leave": self.join_leave,
                        
        }

    # --------------------------------------------------
    def resolve(self, message):
        """
        Resolve handler based on message content
        """

        if not message or not message.text:
            return None

        text = message.text.strip()

        # گرفتن اولین بخش (دستور)
        command = text.split(" ", 1)[0].lower()

        # حذف اسلش ابتدای دستور
        if command.startswith("/"):
            command = command[1:]

        # حذف @botusername اگر وجود داشت
        if "@" in command:
            command = command.split("@", 1)[0]

        return self.command_map.get(command)