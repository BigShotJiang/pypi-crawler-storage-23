# remottxrea/bot/command_router.py

from ..config.main_config import is_admin
from .command_registry import CommandRegistry


class CommandRouter:
    """
    Single entry point for all messages
    """

    def __init__(self):
        self.registry = CommandRegistry()

    # --------------------------------------------------
    async def dispatch(self, client, message):

        # ---- validation ----
        if not message or not message.from_user:
            return

        # ---- admin guard ----
        # if not is_admin(message.from_user.id):
        #     return

        # ---- resolve handler ----
        handler = self.registry.resolve(message)

        if not handler:
            return

        # ---- dispatch ----
        await handler.handle(message)