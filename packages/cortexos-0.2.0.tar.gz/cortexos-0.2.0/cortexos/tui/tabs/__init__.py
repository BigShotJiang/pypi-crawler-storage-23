"""CortexOS TUI tabs."""

from .agents import AgentsTab
from .claims import ClaimsTab
from .feed import FeedTab
from .inspect import InspectTab
from .memory import MemoryTab

__all__ = [
    "AgentsTab",
    "ClaimsTab",
    "FeedTab",
    "InspectTab",
    "MemoryTab",
]
