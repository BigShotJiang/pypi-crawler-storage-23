"""CortexOS TUI — real-time verification monitor."""
