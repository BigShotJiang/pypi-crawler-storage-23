def main():
    print("Hello from citable-corpus!")


if __name__ == "__main__":
    main()