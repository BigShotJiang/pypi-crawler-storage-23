from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("citable_corpus") # 'name' of package from pyproject.toml
except PackageNotFoundError:
    # Package is not installed (e.g., running from a local script)
    __version__ = "unknown"


from .passage import CitablePassage
from .corpus import CitableCorpus
from .markupreader import TEIDivAbReader
from .editionbuilders import extract_text, TEIDiplomatic, TEINormalized


__all__ = ["CitablePassage", 
           "CitableCorpus",
           "TEIDivAbReader", 
           "extract_text", "TEIDiplomatic", "TEINormalized"]