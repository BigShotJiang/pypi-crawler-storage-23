"""Entry point for python -m toolwright."""

from toolwright.cli.main import cli

if __name__ == "__main__":
    cli()
