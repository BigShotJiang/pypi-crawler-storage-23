"""Package assets for Toolwright."""
