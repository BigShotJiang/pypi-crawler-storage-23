"""Branding constants."""

from __future__ import annotations

PRODUCT_NAME = "Toolwright"
CLI_PRIMARY_COMMAND = "toolwright"
CLI_ALIAS = "tw"
USER_AGENT = "Toolwright/1.0"
