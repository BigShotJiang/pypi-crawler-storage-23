"""Toolwright: Self-expanding, self-repairing, human-correctable tool infrastructure for AI agents."""

__version__ = "1.0.0a2"
