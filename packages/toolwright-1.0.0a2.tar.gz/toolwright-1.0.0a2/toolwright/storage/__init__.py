"""Storage layer for Toolwright."""

from toolwright.storage.filesystem import Storage

__all__ = ["Storage"]
