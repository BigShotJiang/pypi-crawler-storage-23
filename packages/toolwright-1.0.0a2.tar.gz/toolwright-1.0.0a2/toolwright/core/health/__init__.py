"""HEAL pillar: Health checking for tool endpoints."""
