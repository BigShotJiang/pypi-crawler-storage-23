"""CORRECT pillar: behavioral rule engine for durable tool-usage constraints."""
