"""KILL pillar: circuit breakers and safety gates."""
