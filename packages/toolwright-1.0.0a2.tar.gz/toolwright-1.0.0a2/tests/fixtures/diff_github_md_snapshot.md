# Toolwright Diff (GitHub)

**Toolpack:** `tp_demo`
**Runtime:** `local`
**Baseline:** `.toolwright/approvals/appr_3478e71e6c9e/artifacts`
**Status:** ⚠️ Changes detected

## Summary

| Signal | Count |
| --- | ---: |
| Tools added | 1 |
| Tools removed | 0 |
| Tools modified | 0 |
| Schemas changed | 1 |
| Policy rules changed | 0 |
| Toolsets changed | 0 |
| Evidence | unchanged |

## Tool Changes

| Change | Tool ID | Name |
| --- | --- | --- |
| `added` | `sig_create_user` | `create_user` |

## Schema Changes

| Change | Tool ID |
| --- | --- |
| `added` | `sig_create_user` |

## Policy Changes

- none

## Toolset Changes

- none

## Evidence

- expected: `none`
- actual: `none`
- changed: `false`
