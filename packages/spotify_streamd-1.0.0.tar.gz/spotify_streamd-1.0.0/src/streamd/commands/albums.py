"""streamd albums — rank albums from a Spotify data export by play count."""

import sys
from pathlib import Path
from datetime import datetime
from collections import defaultdict
from zoneinfo import ZoneInfo

from streamd.client import SpotifyClient, load_plays, log, _STREAMD_DIR

CACHE_FILE = _STREAMD_DIR / "cache" / "track_albums.json"


def register(subparsers):
    p = subparsers.add_parser("albums", help="Rank albums from a Spotify data export")
    p.add_argument("folder", help="Path to unzipped Spotify export folder")
    p.add_argument("--since", default="2026-01-01", help="Cutoff date YYYY-MM-DD (default: 2026-01-01)")
    p.add_argument("--min-ms", type=int, default=20000, help="Ignore plays shorter than this (ms, default: 20000)")
    p.add_argument("--output", default="albums_since_output.txt", help="Output file (default: albums_since_output.txt)")
    p.set_defaults(func=run)


def run(args):
    tz = ZoneInfo("America/New_York")
    cutoff = datetime.strptime(args.since, "%Y-%m-%d").replace(tzinfo=tz)

    # Clear the log file each run
    from streamd.client import _LOG_FILE
    _LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    _LOG_FILE.write_text("", encoding="utf-8")

    # Load all plays from the Spotify export, filtered by date and duration
    plays = load_plays(args.folder, cutoff=cutoff, min_ms=args.min_ms)

    if not plays:
        print("No plays found since cutoff (after filtering).")
        return

    # Deduplicate — we only need to look up each (artist, track) once
    uniq_tracks = sorted(set(plays))
    print(f"Cutoff: {cutoff.isoformat()}")
    print(f"Plays since cutoff (>= {args.min_ms}ms): {len(plays)}")
    print(f"Unique tracks to look up: {len(uniq_tracks)}")

    # Load previously looked-up results from disk so we don't re-fetch them
    cache = SpotifyClient.load_cache(CACHE_FILE)

    # Only fetch tracks we haven't seen before
    uncached = [t for t in uniq_tracks if t not in cache]
    print(f"Cached: {len(uniq_tracks) - len(uncached)}, need to fetch: {len(uncached)}")

    if uncached:
        client = SpotifyClient()
        log(f"start cutoff={cutoff.isoformat()} plays={len(plays)} uniq={len(uniq_tracks)} fetch={len(uncached)}")
        print(f"API calls needed: {len(uncached)}")

        def lookup(pair):
            return client.search_album(pair[0], pair[1])

        fresh = {}
        try:
            fresh = client.parallel(lookup, uncached, label="tracks")
        except RuntimeError as e:
            # Hit a fatal rate limit — save whatever we got so we don't
            # lose progress, then exit. Next run will pick up where we left off.
            print(f"\nABORT: {e}", file=sys.stderr)
            cache.update(fresh)
            SpotifyClient.save_cache(cache, CACHE_FILE)
            print(f"Partial cache saved ({len(cache)} entries).")
            return

        # Merge new results into cache and save to disk
        cache.update(fresh)
        SpotifyClient.save_cache(cache, CACHE_FILE)

    # Build a lookup from each track to its album
    track_to_album = {t: cache.get(t) for t in uniq_tracks}

    # Aggregate: count unique songs and total plays per album
    album_songs = defaultdict(set)   # album -> set of (artist, track) pairs
    album_plays = defaultdict(int)   # album -> total play count
    for pair in plays:
        alb = track_to_album.get(pair)
        if not alb:
            continue
        album_songs[alb].add(pair)
        album_plays[alb] += 1

    # Rank albums: most unique songs first, break ties by total plays
    ranked = sorted(album_songs, key=lambda a: (len(album_songs[a]), album_plays[a]), reverse=True)

    # Write results to file
    out_path = Path(args.output)
    lines = []
    lines.append(f"Albums found: {len(ranked)}\n")
    lines.append("Rank | Unique songs | Total plays | Album — Album artist")
    lines.append("-" * 90)
    for i, alb in enumerate(ranked, 1):
        lines.append(f"{i:>4} | {len(album_songs[alb]):>11} | {album_plays[alb]:>10} | {alb[0]} — {alb[1]}")

    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"\nAlbums found: {len(ranked)}")
    print(f"Results written to {out_path}")
