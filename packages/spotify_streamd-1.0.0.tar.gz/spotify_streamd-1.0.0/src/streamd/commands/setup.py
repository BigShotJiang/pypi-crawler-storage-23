"""streamd setup — interactive first-time configuration."""

import webbrowser
from pathlib import Path

from streamd.client import _STREAMD_DIR


ENV_PATH = _STREAMD_DIR / ".env"
DASHBOARD_URL = "https://developer.spotify.com/dashboard"


def register(subparsers):
    p = subparsers.add_parser("setup", help="Configure Spotify API credentials")
    p.set_defaults(func=run)


def run(args):
    print("streamd setup")
    print("=" * 40)
    print()

    if ENV_PATH.exists():
        print(f"Existing config found at {ENV_PATH}")
        resp = input("Overwrite? [y/N] ").strip().lower()
        if resp != "y":
            print("Aborted.")
            return
        print()

    print("streamd needs your own Spotify API credentials (free).")
    print()
    print(f"Step 1: Create an app at {DASHBOARD_URL}")
    print("        - Name and description can be anything")
    print("        - Set redirect URI to http://localhost")
    print("        - Check the 'Web API' checkbox")
    print()

    resp = input("Open the Spotify dashboard in your browser? [Y/n] ").strip().lower()
    if resp != "n":
        webbrowser.open(DASHBOARD_URL)

    print()
    print("Step 2: Go to your app's Settings and copy the Client ID and Client Secret.")
    print()

    client_id = input("  Client ID: ").strip()
    if not client_id:
        print("Error: Client ID is required.")
        return

    client_secret = input("  Client Secret: ").strip()
    if not client_secret:
        print("Error: Client Secret is required.")
        return

    ENV_PATH.parent.mkdir(parents=True, exist_ok=True)
    ENV_PATH.write_text(
        f"SPOTIFY_CLIENT_ID={client_id}\n"
        f"SPOTIFY_CLIENT_SECRET={client_secret}\n",
        encoding="utf-8",
    )
    # Don't let other users read the credentials
    ENV_PATH.chmod(0o600)

    print()
    print(f"Credentials saved to {ENV_PATH}")
    print()
    print("You're all set! Next steps:")
    print("  1. Download your Spotify data export from https://www.spotify.com/account/privacy")
    print("  2. Unzip it and run:")
    print("     streamd albums ~/path/to/spotify-export")
