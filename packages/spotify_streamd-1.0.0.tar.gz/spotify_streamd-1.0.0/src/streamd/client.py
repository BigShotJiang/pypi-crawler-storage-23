"""Reusable Spotify Web API client with adaptive rate limiting and concurrency.

Provides:
  - AdaptiveRateLimiter: auto-tunes RPS and concurrency to avoid 429s
  - SpotifyClient: authenticated, rate-limited requests with retries
  - log / load_env / normalize / parse_time / load_plays: shared utilities

Environment variables (loaded from ~/.streamd/.env, then cwd .env):
  SPOTIFY_CLIENT_ID      - required
  SPOTIFY_CLIENT_SECRET  - required
  SPOTIFY_WORKERS=4      - max concurrent in-flight requests (ramped up from 1)
  SPOTIFY_RPS=2          - initial requests/sec (adaptive)
  SPOTIFY_MAX_RETRY_AFTER=3600 - abort if Retry-After exceeds this
"""

import base64, json, os, sys, time, random, threading
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

_STREAMD_DIR = Path.home() / ".streamd"

# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

LOG_LOCK = threading.Lock()
_LOG_FILE = _STREAMD_DIR / "run.log"
_LOG_VERBOSE = False

def configure_log(path=None, verbose=False):
    """Set the log file path and verbose mode. Call once at startup."""
    global _LOG_FILE, _LOG_VERBOSE
    if path is not None:
        _LOG_FILE = Path(path)
    _LOG_VERBOSE = verbose

def log(line):
    """Append a line to the log file (thread-safe). If verbose, also print to stderr."""
    text = line.rstrip()
    with LOG_LOCK:
        _LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(text + "\n")
        if _LOG_VERBOSE:
            print(text, file=sys.stderr)

def _read_env_file(path):
    """Parse key=value pairs from a file into os.environ (setdefault)."""
    p = Path(path)
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

def load_env():
    """Load env vars from ~/.streamd/.env, then cwd .env as fallback.

    Real env vars always take priority (setdefault is used).
    ~/.streamd/.env is the canonical location for self-hosted installs.
    A local .env is checked second so development workflows still work.
    """
    _read_env_file(_STREAMD_DIR / ".env")
    _read_env_file(".env")

def normalize(s: str) -> str:
    """Collapse whitespace and strip a string. Returns '' for None/empty."""
    return " ".join((s or "").strip().split())

def parse_time(s, tz):
    """Parse a Spotify export timestamp like '2026-01-15 14:30' and attach a timezone."""
    from datetime import datetime
    return datetime.strptime(s, "%Y-%m-%d %H:%M").replace(tzinfo=tz)

def load_plays(folder, cutoff=None, min_ms=20000):
    """Load (artist, track) plays from a Spotify data export folder.

    Reads all StreamingHistory_music_*.json files recursively.
    - cutoff: if set, skip plays before this datetime (uses cutoff's tzinfo)
    - min_ms: skip plays shorter than this many milliseconds (default 20s)
    Returns a list of (artist, track) tuples in chronological order.
    """
    root = Path(folder).expanduser().resolve()
    files = sorted(root.rglob("StreamingHistory_music_*.json"))
    if not files:
        return []
    plays = []
    for fp in files:
        for o in json.loads(fp.read_text(encoding="utf-8")):
            # Filter out plays before the cutoff date
            if cutoff and parse_time(o["endTime"], cutoff.tzinfo) < cutoff:
                continue
            # Filter out short plays (skips, previews, etc.)
            if int(o.get("msPlayed", 0) or 0) < min_ms:
                continue
            artist = normalize(o.get("artistName"))
            track = normalize(o.get("trackName"))
            if artist and track:
                plays.append((artist, track))
    return plays


# ---------------------------------------------------------------------------
# Adaptive rate limiter
# ---------------------------------------------------------------------------

class AdaptiveRateLimiter:
    """Controls both request spacing (RPS) and concurrency (in-flight count).

    Starts conservative (1 concurrent request, low RPS) and ramps up with
    sustained success.  On any 429, both knobs are cut and ALL threads pause.

    The abort event is a kill switch — once set (e.g. on a fatal rate limit),
    all threads bail out immediately instead of making more requests.
    """

    def __init__(self, initial_rps: float, max_workers: int,
                 min_rps: float = 0.5, max_rps: float = 30.0,
                 ramp_up_factor: float = 1.05, backoff_factor: float = 0.5,
                 ramp_up_every: int = 10):
        self.rps = max(min_rps, float(initial_rps))
        self.min_rps = min_rps
        self.max_rps = max_rps
        self.max_workers = max_workers
        self.ramp_up_factor = ramp_up_factor    # multiply RPS by this on ramp-up
        self.backoff_factor = backoff_factor    # multiply RPS by this on 429
        self.ramp_up_every = ramp_up_every      # successes needed before ramping up

        self.lock = threading.Lock()
        self.next_time = 0.0                    # earliest time the next request can go out
        self.successes_since_backoff = 0
        self.global_pause_until = 0.0           # all threads sleep until this time after a 429
        self.abort = threading.Event()          # set this to stop all threads immediately

        # Start with 1 concurrent request, ramp up as we see successes
        self._concurrency = 1
        self._semaphore = threading.Semaphore(1)

    @property
    def concurrency(self):
        with self.lock:
            return self._concurrency

    def acquire(self):
        """Block until a concurrency slot opens."""
        self._semaphore.acquire()

    def release(self):
        """Free a concurrency slot."""
        self._semaphore.release()

    def wait(self):
        """Pace the request rate. Call after acquire(), before the HTTP call.

        Calculates the earliest allowed time for the next request based on
        current RPS and any global pause, then sleeps until that time.
        A small random jitter is added to avoid thundering herd.
        """
        with self.lock:
            now = time.monotonic()
            # Don't fire before: the scheduled next slot, OR the global pause
            earliest = max(now, self.next_time, self.global_pause_until)
            interval = 1.0 / self.rps
            self.next_time = earliest + interval
            wake_at = earliest
        sleep_for = wake_at - time.monotonic() + random.uniform(0.0, 0.03)
        if sleep_for > 0:
            time.sleep(sleep_for)

    def on_success(self):
        """Track a successful request. After enough successes, ramp up speed."""
        with self.lock:
            self.successes_since_backoff += 1
            if self.successes_since_backoff >= self.ramp_up_every:
                old_rps = self.rps
                self.rps = min(self.rps * self.ramp_up_factor, self.max_rps)
                self.successes_since_backoff = 0
                # Also allow one more concurrent request (up to max)
                if self._concurrency < self.max_workers:
                    self._concurrency += 1
                    self._semaphore.release()
                    log(f"[limiter] concurrency {self._concurrency - 1} -> {self._concurrency}")
                if self.rps != old_rps:
                    log(f"[limiter] ramp up {old_rps:.2f} -> {self.rps:.2f} rps")

    def on_rate_limit(self, retry_after: int):
        """Called by any thread on 429. Pauses ALL threads and cuts concurrency.

        Halves the RPS, resets the success counter, sets a global pause so
        every thread waits, and pulls back concurrency slots to reduce pressure.
        """
        with self.lock:
            old_rps, old_conc = self.rps, self._concurrency
            self.rps = max(self.rps * self.backoff_factor, self.min_rps)
            self.successes_since_backoff = 0
            # Force all threads to wait for retry_after + a small buffer
            self.global_pause_until = time.monotonic() + retry_after + 0.5
            # Drain concurrency back toward 1 by reclaiming semaphore slots
            while self._concurrency > 1:
                acquired = self._semaphore.acquire(blocking=False)
                if acquired:
                    self._concurrency -= 1
                else:
                    break
            log(f"[limiter] 429! rps {old_rps:.2f}->{self.rps:.2f}, "
                f"concurrency {old_conc}->{self._concurrency}, pause {retry_after}s")


# ---------------------------------------------------------------------------
# Spotify client
# ---------------------------------------------------------------------------

# Each thread gets its own requests.Session for connection pooling
THREAD_LOCAL = threading.local()

def _session():
    """Get or create a per-thread requests.Session."""
    s = getattr(THREAD_LOCAL, "s", None)
    if s is None:
        s = requests.Session()
        THREAD_LOCAL.s = s
    return s

def _spotify_token(cid, secret):
    """Exchange client credentials for a bearer token (OAuth client_credentials flow)."""
    auth = base64.b64encode(f"{cid}:{secret}".encode()).decode()
    r = requests.post(
        "https://accounts.spotify.com/api/token",
        headers={"Authorization": f"Basic {auth}"},
        data={"grant_type": "client_credentials"},
        timeout=20,
    )
    r.raise_for_status()
    return r.json()["access_token"]


class SpotifyClient:
    """Authenticated Spotify Web API client with adaptive rate limiting.

    Usage:
        client = SpotifyClient()              # reads env vars
        data = client.get("/v1/search", params={"q": "...", "type": "track"})
        results = client.parallel(fn, items)  # threaded map with progress
    """

    def __init__(self, workers=None, rps=None, max_retry_after=None):
        load_env()
        cid = os.getenv("SPOTIFY_CLIENT_ID")
        secret = os.getenv("SPOTIFY_CLIENT_SECRET")
        if not cid or not secret:
            raise RuntimeError(
                "Missing Spotify credentials. Run 'streamd setup' to configure them.\n"
                f"  (looked in ~/.streamd/.env and ./.env)"
            )

        self.workers = workers or int(os.getenv("SPOTIFY_WORKERS", "4"))
        # If Spotify says "wait longer than this", abort instead of waiting
        self.max_retry_after = max_retry_after or int(os.getenv("SPOTIFY_MAX_RETRY_AFTER", "3600"))
        initial_rps = rps or float(os.getenv("SPOTIFY_RPS", "2"))

        self.token = _spotify_token(cid, secret)
        self.limiter = AdaptiveRateLimiter(initial_rps=initial_rps, max_workers=self.workers)

    def get(self, path, params=None):
        """Rate-limited GET with retries.  Returns parsed JSON or None on miss.

        `path` can be a full URL or just the path (e.g. "/v1/search").
        Raises RuntimeError on 401 or excessive Retry-After.

        Retry logic:
          - Up to 8 attempts per request
          - On network error: exponential backoff (1s -> 2s -> 4s ... capped at 20s)
          - On 429: respect Retry-After header, back off the limiter
          - On 429 with Retry-After > max_retry_after: set abort flag and raise
          - Checks the abort flag before each attempt so threads stop quickly
        """
        url = path if path.startswith("http") else f"https://api.spotify.com{path}"
        headers = {"Authorization": f"Bearer {self.token}"}

        backoff = 1.0
        for attempt in range(1, 9):
            # Bail out if another thread triggered a fatal error
            if self.limiter.abort.is_set():
                return None
            self.limiter.acquire()
            try:
                self.limiter.wait()
                # Check again after waiting — abort may have been set while we slept
                if self.limiter.abort.is_set():
                    self.limiter.release()
                    return None
                try:
                    r = _session().get(url, headers=headers, params=params, timeout=20)
                except Exception as e:
                    log(f"[net] {url} params={params} attempt={attempt} err={e}")
                    time.sleep(backoff + random.uniform(0.0, 0.25))
                    backoff = min(backoff * 2, 20)
                    continue
                finally:
                    self.limiter.release()
            except Exception:
                self.limiter.release()
                raise

            if r.status_code == 429:
                ra = int(r.headers.get("Retry-After", "1"))
                log(f"[429] retry_after={ra}s | {url}")
                # If we're locked out for too long (e.g. 24h), give up entirely
                if ra > self.max_retry_after:
                    self.limiter.abort.set()
                    raise RuntimeError(f"Rate-limited with Retry-After={ra}s (too large).")
                self.limiter.on_rate_limit(ra)
                time.sleep(ra + random.uniform(0.0, 0.5))
                continue

            if r.status_code == 401:
                raise RuntimeError("401 Unauthorized (bad/expired token).")

            if r.status_code != 200:
                log(f"[http {r.status_code}] {url} body={r.text[:120]!r}")
                time.sleep(backoff + random.uniform(0.0, 0.25))
                backoff = min(backoff * 2, 20)
                continue

            # Success — tell the limiter so it can ramp up
            self.limiter.on_success()
            return r.json()

        log(f"[giveup] {url} params={params}")
        return None

    def search_album(self, artist, track):
        """Look up the album for a given artist + track via Spotify search.

        Searches for the track by name and artist, returns the album info
        from the first result.
        Returns (album_name, album_artist) or None if not found.
        """
        artist, track = normalize(artist), normalize(track)
        q = f'track:"{track}" artist:"{artist}"'
        data = self.get("/v1/search", params={"q": q, "type": "track", "limit": 1})
        if data is None:
            return None

        items = data.get("tracks", {}).get("items", [])
        if not items:
            log(f"[miss] {artist} — {track}")
            return None

        a = items[0].get("album", {})
        name = a.get("name")
        # Fall back to the input artist if the album has no artist listed
        alb_artist = (a.get("artists") or [{}])[0].get("name") or artist
        log(f"[hit] {artist} — {track} -> {name} by {alb_artist}")
        return (name, alb_artist) if name else None

    @staticmethod
    def load_cache(path):
        """Load a {tuple_key: tuple_value} cache from a JSON file.

        The JSON format uses JSON-encoded lists as keys (since JSON keys must
        be strings). Example: {"[\"artist\", \"track\"]": ["album", "artist"]}
        Returns a dict of {(str, str): (str, str) or None}.
        """
        p = Path(path)
        if not p.exists():
            return {}
        cache = {}
        for k, v in json.loads(p.read_text(encoding="utf-8")).items():
            cache[tuple(json.loads(k))] = tuple(v) if v else None
        return cache

    @staticmethod
    def save_cache(cache, path):
        """Save a {tuple_key: tuple_value} cache to a JSON file.

        Inverse of load_cache — converts tuple keys to JSON strings.
        """
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(
            {json.dumps(list(k)): list(v) if v else None for k, v in cache.items()},
            ensure_ascii=False, indent=1,
        ), encoding="utf-8")

    def parallel(self, fn, items, label="items"):
        """Run fn(item) across items using the thread pool.  Returns {item: result}.

        Submits all items to a thread pool, collects results as they complete.
        Prints progress every 100 items.

        If any task raises RuntimeError (e.g. fatal rate limit), cancels all
        remaining futures and re-raises so the caller can save partial results.
        """
        results = {}
        total = len(items)
        error = None
        with ThreadPoolExecutor(max_workers=self.workers) as ex:
            futures = {ex.submit(fn, item): item for item in items}
            for i, fut in enumerate(as_completed(futures), 1):
                item = futures[fut]
                try:
                    results[item] = fut.result()
                except RuntimeError as e:
                    error = e
                    # Tell all other threads to stop and cancel queued work
                    for pending in futures:
                        pending.cancel()
                    break
                if i % 100 == 0 or i == total:
                    print(f"  {label}: {i}/{total}", flush=True)
        if error:
            raise RuntimeError(str(error))
        return results
