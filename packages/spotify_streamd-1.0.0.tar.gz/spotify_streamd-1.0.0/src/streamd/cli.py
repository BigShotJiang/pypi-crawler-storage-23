"""streamd CLI — entry point and subcommand dispatch."""

import argparse

from streamd.client import configure_log
from streamd.commands import albums, setup


def main():
    parser = argparse.ArgumentParser(prog="streamd", description="Spotify data tools")
    parser.add_argument("-v", "--verbose", action="store_true", help="Print debug log lines to stderr")
    parser.add_argument("--log-file", default=None, help="Log file path (default: ~/.streamd/run.log)")
    sub = parser.add_subparsers(dest="command")

    setup.register(sub)
    albums.register(sub)

    args = parser.parse_args()
    if args.command is None:
        parser.print_help()
        raise SystemExit(1)

    configure_log(path=args.log_file, verbose=args.verbose)
    args.func(args)
