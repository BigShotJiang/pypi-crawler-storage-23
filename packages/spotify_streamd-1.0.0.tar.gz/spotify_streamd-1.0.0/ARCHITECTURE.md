# Architecture

## Overview

streamd (published on PyPI as `spotify-streamd`) is a self-hosted CLI tool that processes Spotify data exports and enriches them with metadata from the Spotify Web API. Each user brings their own Spotify developer app credentials — there's no shared backend or API key.

The main design constraint is Spotify's rate limiting: development mode apps have a rolling 30-second request window with a relatively low threshold. Every design decision optimizes for minimizing API calls through aggressive caching.

## Project layout

```
src/streamd/
├── cli.py              # argparse entry point, global flags (-v, --log-file)
├── client.py           # Spotify API client, rate limiter, shared utilities
└── commands/
    ├── setup.py        # "setup" subcommand — interactive credential config
    └── albums.py       # "albums" subcommand — ranks albums by play count
```

## Key components

### `client.py` — Spotify API client

Three layers work together:

1. **`AdaptiveRateLimiter`** — controls request pacing and concurrency. Starts at 1 concurrent request and 2 RPS, ramps up with sustained success, cuts back hard on any 429. Uses a semaphore for concurrency slots and a monotonic clock for request spacing. An `abort` event acts as a kill switch — when a Retry-After value exceeds the configured max, all threads bail immediately.

2. **`SpotifyClient`** — authenticated HTTP client. Handles OAuth client_credentials token exchange, retries with exponential backoff, and delegates pacing to the rate limiter. Each thread gets its own `requests.Session` for connection pooling.

3. **Utilities** — `load_plays()` reads Spotify data export JSON files, `log()` provides thread-safe logging, `load_env()` reads credentials from `~/.streamd/.env` (then cwd `.env` as fallback).

### `commands/setup.py` — credential configuration

Interactive setup that walks users through creating a Spotify developer app and saves credentials to `~/.streamd/.env` with `0600` permissions. Checks for existing config and prompts before overwriting.

### `commands/albums.py` — album ranking

The pipeline:

1. **Load plays** from the Spotify export folder, filtering by cutoff date and minimum play duration
2. **Deduplicate** — only unique (artist, track) pairs need API lookups
3. **Check cache** — `~/.streamd/cache/track_albums.json` maps (artist, track) → (album, album_artist). Only uncached tracks hit the API
4. **Fetch** — parallel API lookups for uncached tracks. If aborted mid-run (rate limited), partial results are saved to cache so the next run picks up where it left off
5. **Aggregate** — count unique songs and total plays per album, rank by unique songs (tiebreak: total plays)
6. **Write results** to a text file

### Cache strategy

The cache is the most important optimization. It lives at `~/.streamd/cache/track_albums.json` (global, not per-project) and maps `(artist, track)` → `(album, album_artist)`. Format: JSON with JSON-encoded list keys (since JSON requires string keys).

A typical Spotify export has 2,000–5,000 unique tracks. After the cache is fully populated, every subsequent run costs zero API calls.

Partial saves on abort mean you never lose progress — if you get rate-limited mid-run, everything fetched so far is persisted.

### Rate limiting strategy

Spotify rate limits development mode apps using a rolling 30-second window. The exact threshold isn't published, but it's low enough that naive concurrent requests will trigger 429s quickly.

- **Initial**: 2 RPS, 1 concurrent request, max 4 workers
- **Ramp up**: after every 10 consecutive successes, RPS increases by 5% and concurrency increases by 1 (up to max workers)
- **Backoff**: on any 429, RPS is halved, concurrency drops to 1, and all threads pause for the Retry-After duration
- **Abort**: if Retry-After exceeds the configured max (default 1 hour), the abort flag is set and all threads stop. Partial results are saved.

### Logging

`log()` writes to `~/.streamd/run.log` by default. With `-v`, lines are also printed to stderr. The log captures rate limiter adjustments, cache hits/misses, HTTP errors, and request details — useful for diagnosing rate limit issues.

## Adding a new subcommand

1. Create `src/streamd/commands/yourcommand.py`
2. Implement `register(subparsers)` to add args and `run(args)` as the entry point
3. Import and register it in `cli.py`
