"""CLI commands for edcli."""

from __future__ import annotations

import sys

import click

from edcli.config import Config
from edcli.display import (
    console,
    print_categories,
    print_course_info,
    print_courses,
    print_json,
    print_thread_detail,
    print_threads,
)
from edcli.exceptions import EdCliError


@click.group()
@click.option("--format", "output_format", type=click.Choice(["table", "json"]), default=None,
              help="Output format (default: table)")
@click.pass_context
def cli(ctx: click.Context, output_format: str | None) -> None:
    """EdStem Discussion CLI."""
    ctx.ensure_object(dict)
    cfg = Config.load()
    if output_format:
        cfg.output_format = output_format
    ctx.obj["config"] = cfg


def _client(ctx: click.Context):
    from edcli.client import EdClient
    cfg: Config = ctx.obj["config"]
    return EdClient(cfg.require_token(), cfg.base_url)


# -- configure -------------------------------------------------------------

@cli.command()
@click.pass_context
def configure(ctx: click.Context) -> None:
    """Set API token and default course (interactive)."""
    from edcli.client import EdClient

    cfg: Config = ctx.obj["config"]
    token = click.prompt("Ed API token (JWT)", hide_input=True)
    cfg.token = token.strip()

    try:
        with EdClient(cfg.token, cfg.base_url) as client:
            user, courses = client.get_user()
        console.print(f"Authenticated as [bold]{user.name}[/bold] ({user.email})")
    except EdCliError as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(1)

    if courses:
        console.print("\nAvailable courses:")
        for i, c in enumerate(courses, 1):
            console.print(f"  {i}. [{c.id}] {c.code} - {c.name}")
        choice = click.prompt(
            "Default course number (or 0 for none)",
            type=int,
            default=1,
        )
        if 1 <= choice <= len(courses):
            cfg.default_course_id = courses[choice - 1].id

    cfg.save()
    console.print("[green]Configuration saved.[/green]")


# -- courses ---------------------------------------------------------------

@cli.command()
@click.pass_context
def courses(ctx: click.Context) -> None:
    """List enrolled courses."""
    cfg: Config = ctx.obj["config"]
    with _client(ctx) as client:
        _, course_list = client.get_user()
    if cfg.output_format == "json":
        print_json(course_list)
    else:
        print_courses(course_list)


# -- threads ---------------------------------------------------------------

@cli.command()
@click.option("-c", "--course", "course_id", type=int, default=None, help="Course ID")
@click.option("--type", "thread_type", multiple=True,
              type=click.Choice(["announcement", "question", "post"]),
              help="Filter by thread type (repeatable)")
@click.option("--category", multiple=True, help="Filter by category name (repeatable)")
@click.option("--pinned", is_flag=True, help="Show only pinned threads")
@click.option("--answered", is_flag=True, help="Show only answered threads")
@click.option("--unread", is_flag=True, help="Show only unread threads")
@click.option("--limit", "-n", type=int, default=30, help="Max threads to fetch (default 30)")
@click.option("--sort", type=click.Choice(["new"]), default="new", help="Sort order")
@click.pass_context
def threads(
    ctx: click.Context,
    course_id: int | None,
    thread_type: tuple[str, ...],
    category: tuple[str, ...],
    pinned: bool,
    answered: bool,
    unread: bool,
    limit: int,
    sort: str,
) -> None:
    """List discussion threads."""
    cfg: Config = ctx.obj["config"]
    cid = cfg.require_course(course_id)

    with _client(ctx) as client:
        items = client.list_threads(cid, limit=limit, sort=sort)

    # Client-side filtering
    if thread_type:
        items = [t for t in items if t.type in thread_type]
    if category:
        cat_lower = {c.lower() for c in category}
        items = [t for t in items if t.category.lower() in cat_lower]
    if pinned:
        items = [t for t in items if t.is_pinned]
    if answered:
        items = [t for t in items if t.is_answered or t.is_staff_answered or t.is_student_answered]
    if unread:
        items = [t for t in items if not t.is_seen]

    if cfg.output_format == "json":
        print_json(items)
    else:
        print_threads(items)


# -- search ----------------------------------------------------------------

@cli.command()
@click.argument("query")
@click.option("-c", "--course", "course_id", type=int, default=None, help="Course ID")
@click.option("-n", "--limit", type=int, default=20, help="Max results (default 20)")
@click.option("--sort", type=click.Choice(["relevance", "new"]), default="relevance")
@click.pass_context
def search(ctx: click.Context, query: str, course_id: int | None, limit: int, sort: str) -> None:
    """Search discussion threads."""
    cfg: Config = ctx.obj["config"]
    cid = cfg.require_course(course_id)

    with _client(ctx) as client:
        results = client.search_threads(cid, query, limit=limit, sort=sort)

    if cfg.output_format == "json":
        print_json(results)
    else:
        print_threads(results)


# -- thread detail ---------------------------------------------------------

@cli.command()
@click.argument("thread_id", type=int)
@click.pass_context
def thread(ctx: click.Context, thread_id: int) -> None:
    """Show full thread detail with answers and comments."""
    cfg: Config = ctx.obj["config"]
    with _client(ctx) as client:
        t = client.get_thread(thread_id)
    if cfg.output_format == "json":
        print_json(t)
    else:
        print_thread_detail(t)


# -- categories ------------------------------------------------------------

@cli.command()
@click.option("-c", "--course", "course_id", type=int, default=None, help="Course ID")
@click.pass_context
def categories(ctx: click.Context, course_id: int | None) -> None:
    """List discussion categories for a course."""
    cfg: Config = ctx.obj["config"]
    cid = cfg.require_course(course_id)

    with _client(ctx) as client:
        _, course_list = client.get_user()

    course = next((c for c in course_list if c.id == cid), None)
    if not course:
        console.print(f"[red]Course {cid} not found in your enrollments.[/red]")
        sys.exit(1)

    if cfg.output_format == "json":
        print_json(course.categories)
    else:
        print_categories(course.categories)


# -- info ------------------------------------------------------------------

@cli.command()
@click.option("-c", "--course", "course_id", type=int, default=None, help="Course ID")
@click.pass_context
def info(ctx: click.Context, course_id: int | None) -> None:
    """Show course info."""
    cfg: Config = ctx.obj["config"]
    cid = cfg.require_course(course_id)

    with _client(ctx) as client:
        _, course_list = client.get_user()

    course = next((c for c in course_list if c.id == cid), None)
    if not course:
        console.print(f"[red]Course {cid} not found in your enrollments.[/red]")
        sys.exit(1)

    if cfg.output_format == "json":
        print_json(course)
    else:
        print_course_info(course)


# -- renew -----------------------------------------------------------------

@cli.command()
@click.pass_context
def renew(ctx: click.Context) -> None:
    """Renew/refresh the JWT token."""
    cfg: Config = ctx.obj["config"]
    with _client(ctx) as client:
        new_token = client.renew_token()
    cfg.token = new_token
    cfg.save()
    console.print("[green]Token renewed and saved.[/green]")
