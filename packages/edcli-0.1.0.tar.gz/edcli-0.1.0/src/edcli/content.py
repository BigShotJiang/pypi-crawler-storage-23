"""XML document to plaintext extraction."""

from __future__ import annotations

import html
import re


def strip_xml_tags(text: str) -> str:
    """Strip XML tags from EdStem document content, returning plaintext."""
    if not text:
        return ""
    # Unescape HTML entities
    text = html.unescape(text)
    # Remove web-snippet blocks entirely
    text = re.sub(r"<web-snippet[^>]*>.*?</web-snippet>", "", text, flags=re.DOTALL)
    # Replace <break/> with newline
    text = re.sub(r"<break\s*/?>", "\n", text)
    # Replace block-level closing tags with newlines
    text = re.sub(r"</(?:paragraph|heading|list-item)>", "\n", text)
    # Strip remaining tags
    text = re.sub(r"<[^>]+>", "", text)
    # Collapse multiple blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def truncate(text: str, max_len: int = 80) -> str:
    """Truncate text to max_len, adding ellipsis if needed."""
    text = text.replace("\n", " ").strip()
    if len(text) <= max_len:
        return text
    return text[: max_len - 1] + "\u2026"
