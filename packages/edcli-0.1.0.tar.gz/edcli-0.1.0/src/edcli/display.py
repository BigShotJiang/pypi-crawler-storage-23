"""Rich terminal rendering for edcli."""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from edcli.content import strip_xml_tags, truncate
from edcli.models import Category, Comment, Course, Thread

console = Console()


def _parse_ts(ts: str) -> str:
    """Parse ISO timestamp to a short display string."""
    if not ts:
        return ""
    try:
        dt = datetime.fromisoformat(ts)
        return dt.strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return ts[:16]


def _type_badge(thread_type: str) -> Text:
    colors = {"announcement": "bold magenta", "question": "bold cyan", "post": "bold green"}
    return Text(thread_type, style=colors.get(thread_type, ""))


def _status_icons(t: Thread) -> str:
    parts = []
    if t.is_pinned:
        parts.append("pinned")
    if t.is_answered or t.is_staff_answered:
        parts.append("answered")
    elif t.is_student_answered:
        parts.append("student-answered")
    if t.is_endorsed:
        parts.append("endorsed")
    if t.is_locked:
        parts.append("locked")
    if not t.is_seen:
        parts.append("NEW")
    return " ".join(parts)


# -- JSON output -----------------------------------------------------------

def print_json(data) -> None:
    """Print any data as JSON."""
    if hasattr(data, "__iter__") and not isinstance(data, dict):
        items = [asdict(item) if hasattr(item, "__dataclass_fields__") else item for item in data]
        console.print_json(json.dumps(items, default=str))
    elif hasattr(data, "__dataclass_fields__"):
        console.print_json(json.dumps(asdict(data), default=str))
    else:
        console.print_json(json.dumps(data, default=str))


# -- Courses ---------------------------------------------------------------

def print_courses(courses: list[Course]) -> None:
    table = Table(title="Enrolled Courses")
    table.add_column("ID", style="cyan", justify="right")
    table.add_column("Code", style="bold")
    table.add_column("Name")
    table.add_column("Session")
    table.add_column("Role", style="green")
    table.add_column("Status")
    for c in courses:
        table.add_row(str(c.id), c.code, c.name, f"{c.session} {c.year}".strip(), c.role, c.status)
    console.print(table)


# -- Threads list ----------------------------------------------------------

def print_threads(threads: list[Thread]) -> None:
    table = Table(title=f"Threads ({len(threads)})")
    table.add_column("#", style="dim", justify="right")
    table.add_column("Type", width=14)
    table.add_column("Title", max_width=50)
    table.add_column("Category", style="yellow", max_width=25)
    table.add_column("Replies", justify="right")
    table.add_column("Votes", justify="right")
    table.add_column("Status", max_width=30)
    table.add_column("Date", style="dim")
    for t in threads:
        table.add_row(
            str(t.number),
            _type_badge(t.type),
            truncate(t.title, 50),
            truncate(t.category, 25),
            str(t.reply_count),
            str(t.vote_count),
            _status_icons(t),
            _parse_ts(t.created_at),
        )
    console.print(table)


# -- Thread detail ---------------------------------------------------------

def _render_comment(c: Comment, indent: int = 0) -> None:
    prefix = "  " * indent
    style = "bold green" if c.is_endorsed else ""
    endorsed = " [endorsed]" if c.is_endorsed else ""
    resolved = " [resolved]" if c.is_resolved else ""
    header = f"{prefix}{c.user_name or f'User {c.user_id}'} ({_parse_ts(c.created_at)}){endorsed}{resolved}"
    console.print(header, style=style)

    body = c.document or strip_xml_tags(c.content)
    if body:
        for line in body.splitlines():
            console.print(f"{prefix}  {line}")
    if c.vote_count:
        console.print(f"{prefix}  [{c.vote_count} votes]", style="dim")
    console.print()

    for reply in c.comments:
        _render_comment(reply, indent + 1)


def print_thread_detail(t: Thread) -> None:
    # Header panel
    status = _status_icons(t)
    subtitle = f"#{t.number} | {t.type} | {t.category}"
    if t.subcategory:
        subtitle += f" > {t.subcategory}"
    meta_lines = [
        f"By: {t.user_name or f'User {t.user_id}'}  |  {_parse_ts(t.created_at)}",
        f"Views: {t.view_count}  |  Votes: {t.vote_count}  |  Replies: {t.reply_count}",
    ]
    if status:
        meta_lines.append(f"Status: {status}")
    body = t.document or strip_xml_tags(t.content)
    content = "\n".join(meta_lines) + "\n\n" + body
    console.print(Panel(content, title=t.title, subtitle=subtitle, expand=True))

    # Answers
    if t.answers:
        console.print(f"\n[bold]Answers ({len(t.answers)}):[/bold]")
        for a in t.answers:
            _render_comment(a)

    # Comments
    if t.comments:
        console.print(f"\n[bold]Comments ({len(t.comments)}):[/bold]")
        for c in t.comments:
            _render_comment(c)


# -- Categories ------------------------------------------------------------

def print_categories(categories: list[Category]) -> None:
    table = Table(title="Discussion Categories")
    table.add_column("Category", style="bold yellow")
    table.add_column("Subcategories")
    for cat in categories:
        subs = ", ".join(cat.subcategories) if cat.subcategories else "-"
        table.add_row(cat.name, subs)
    console.print(table)


# -- Course info -----------------------------------------------------------

def print_course_info(course: Course) -> None:
    lines = [
        f"[bold]ID:[/bold] {course.id}",
        f"[bold]Code:[/bold] {course.code}",
        f"[bold]Name:[/bold] {course.name}",
        f"[bold]Session:[/bold] {course.session} {course.year}",
        f"[bold]Status:[/bold] {course.status}",
        f"[bold]Role:[/bold] {course.role}",
        f"[bold]Categories:[/bold] {len(course.categories)}",
    ]
    console.print(Panel("\n".join(lines), title=course.code))
