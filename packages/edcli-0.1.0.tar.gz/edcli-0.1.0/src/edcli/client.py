"""Synchronous HTTP client for the EdStem API."""

from __future__ import annotations

import time

import httpx

from edcli.exceptions import ApiError, AuthenticationError
from edcli.models import Course, Thread, User


class EdClient:
    """Sync EdStem API client."""

    def __init__(self, token: str, base_url: str = "https://us.edstem.org"):
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={"X-Token": token},
            timeout=30.0,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # -- low-level ---------------------------------------------------------

    def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        """Make a request with retry on 429 and 5xx."""
        last_exc: Exception | None = None
        for attempt in range(3):
            try:
                resp = self._client.request(method, path, **kwargs)
            except httpx.TransportError as exc:
                last_exc = exc
                time.sleep(2**attempt)
                continue

            if resp.status_code == 401:
                raise AuthenticationError("Token expired or invalid. Run 'edcli renew' or 'edcli configure'.")
            if resp.status_code == 429 or resp.status_code >= 500:
                last_exc = ApiError(resp.status_code, resp.text)
                time.sleep(2**attempt)
                continue
            if resp.status_code >= 400:
                raise ApiError(resp.status_code, resp.text)
            return resp

        raise last_exc  # type: ignore[misc]

    def _get(self, path: str, **params) -> dict:
        resp = self._request("GET", path, params=params)
        return resp.json()

    def _post(self, path: str, **kwargs) -> dict:
        resp = self._request("POST", path, **kwargs)
        if resp.headers.get("content-type", "").startswith("application/json"):
            return resp.json()
        return {}

    # -- endpoints ---------------------------------------------------------

    def get_user(self) -> tuple[User, list[Course]]:
        """GET /api/user -> (user, courses)."""
        data = self._get("/api/user")
        user = User.from_dict(data["user"])
        courses = [Course.from_dict(e) for e in data.get("courses", [])]
        return user, courses

    def list_threads(
        self, course_id: int, limit: int = 30, sort: str = "new"
    ) -> list[Thread]:
        """GET /api/courses/{id}/threads."""
        data = self._get(f"/api/courses/{course_id}/threads", limit=limit, sort=sort)
        return [Thread.from_dict(t) for t in data.get("threads", [])]

    def search_threads(
        self, course_id: int, query: str, limit: int = 20, sort: str = "relevance"
    ) -> list[Thread]:
        """GET /api/courses/{id}/threads/search."""
        data = self._get(
            f"/api/courses/{course_id}/threads/search",
            query=query,
            limit=limit,
            sort=sort,
        )
        return [Thread.from_dict(t) for t in data.get("threads", [])]

    def get_thread(self, thread_id: int) -> Thread:
        """GET /api/threads/{id}?view=1 -> thread with answers/comments."""
        data = self._get(f"/api/threads/{thread_id}", view=1)
        users_list = data.get("users", [])
        users = {u["id"]: User.from_dict(u) for u in users_list}
        return Thread.from_dict(data["thread"], users)

    def renew_token(self) -> str:
        """POST /api/renew_token -> new JWT string."""
        data = self._post("/api/renew_token")
        return data["token"]
