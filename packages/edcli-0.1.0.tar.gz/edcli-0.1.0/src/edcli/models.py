"""Data models for EdStem API responses."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class User:
    id: int
    name: str
    email: str = ""
    role: str = ""
    course_role: str | None = None
    avatar: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> User:
        return cls(
            id=d["id"],
            name=d.get("name", ""),
            email=d.get("email", ""),
            role=d.get("role", ""),
            course_role=d.get("course_role"),
            avatar=d.get("avatar"),
        )


@dataclass
class Category:
    name: str
    subcategories: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict) -> Category:
        subs = []
        for s in d.get("subcategories", []):
            if isinstance(s, str):
                subs.append(s)
            elif isinstance(s, dict):
                subs.append(s.get("name", ""))
        return cls(name=d["name"], subcategories=subs)


@dataclass
class Course:
    id: int
    code: str
    name: str
    year: str = ""
    session: str = ""
    status: str = ""
    role: str = ""
    categories: list[Category] = field(default_factory=list)

    @classmethod
    def from_dict(cls, enrollment: dict) -> Course:
        c = enrollment["course"]
        role_data = enrollment.get("role", {})
        cats = []
        try:
            cat_list = c["settings"]["discussion"]["categories"]
            cats = [Category.from_dict(cat) for cat in cat_list]
        except (KeyError, TypeError):
            pass
        return cls(
            id=c["id"],
            code=c.get("code", ""),
            name=c.get("name", ""),
            year=c.get("year", ""),
            session=c.get("session", ""),
            status=c.get("status", ""),
            role=role_data.get("role", "") if role_data else "",
            categories=cats,
        )


@dataclass
class Comment:
    id: int
    user_id: int
    type: str  # "comment" or "answer"
    document: str = ""
    content: str = ""
    is_anonymous: bool = False
    is_endorsed: bool = False
    is_resolved: bool = False
    vote_count: int = 0
    created_at: str = ""
    user_name: str = ""
    comments: list[Comment] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict, users: dict[int, User] | None = None) -> Comment:
        users = users or {}
        user_name = ""
        if d.get("is_anonymous"):
            user_name = "Anonymous"
        elif d.get("user_id") and d["user_id"] in users:
            user_name = users[d["user_id"]].name
        replies = [cls.from_dict(r, users) for r in d.get("comments", []) or []]
        return cls(
            id=d["id"],
            user_id=d.get("user_id", 0),
            type=d.get("type", "comment"),
            document=d.get("document", ""),
            content=d.get("content", ""),
            is_anonymous=d.get("is_anonymous", False),
            is_endorsed=d.get("is_endorsed", False),
            is_resolved=d.get("is_resolved", False),
            vote_count=d.get("vote_count", 0),
            created_at=d.get("created_at", ""),
            user_name=user_name,
            comments=replies,
        )


@dataclass
class Thread:
    id: int
    number: int
    type: str  # "announcement", "question", "post"
    title: str
    document: str = ""
    content: str = ""
    category: str = ""
    subcategory: str = ""
    user_id: int = 0
    user_name: str = ""
    vote_count: int = 0
    reply_count: int = 0
    view_count: int = 0
    unique_view_count: int = 0
    is_pinned: bool = False
    is_locked: bool = False
    is_private: bool = False
    is_answered: bool = False
    is_student_answered: bool = False
    is_staff_answered: bool = False
    is_endorsed: bool = False
    is_anonymous: bool = False
    is_seen: bool = False
    is_starred: bool = False
    new_reply_count: int = 0
    unresolved_count: int = 0
    created_at: str = ""
    updated_at: str = ""
    answers: list[Comment] = field(default_factory=list)
    comments: list[Comment] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict, users: dict[int, User] | None = None) -> Thread:
        users = users or {}
        user_name = ""
        if d.get("is_anonymous"):
            user_name = "Anonymous"
        elif d.get("user_id") and d["user_id"] in users:
            user_name = users[d["user_id"]].name
        answers = [Comment.from_dict(a, users) for a in d.get("answers", []) or []]
        comments = [Comment.from_dict(c, users) for c in d.get("comments", []) or []]
        return cls(
            id=d["id"],
            number=d.get("number", 0),
            type=d.get("type", ""),
            title=d.get("title", ""),
            document=d.get("document", ""),
            content=d.get("content", ""),
            category=d.get("category", ""),
            subcategory=d.get("subcategory", ""),
            user_id=d.get("user_id", 0),
            user_name=user_name,
            vote_count=d.get("vote_count", 0),
            reply_count=d.get("reply_count", 0),
            view_count=d.get("view_count", 0),
            unique_view_count=d.get("unique_view_count", 0),
            is_pinned=d.get("is_pinned", False),
            is_locked=d.get("is_locked", False),
            is_private=d.get("is_private", False),
            is_answered=d.get("is_answered", False),
            is_student_answered=d.get("is_student_answered", False),
            is_staff_answered=d.get("is_staff_answered", False),
            is_endorsed=d.get("is_endorsed", False),
            is_anonymous=d.get("is_anonymous", False),
            is_seen=d.get("is_seen", False),
            is_starred=d.get("is_starred", False),
            new_reply_count=d.get("new_reply_count", 0),
            unresolved_count=d.get("unresolved_count", 0),
            created_at=d.get("created_at", ""),
            updated_at=d.get("updated_at", ""),
            answers=answers,
            comments=comments,
        )
