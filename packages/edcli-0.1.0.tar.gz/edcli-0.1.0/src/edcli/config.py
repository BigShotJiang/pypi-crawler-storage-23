"""Config management: ~/.config/edcli/config.toml"""

from __future__ import annotations

import os
import stat
import tomllib
from dataclasses import dataclass
from pathlib import Path

import tomli_w
from platformdirs import user_config_dir

from edcli.exceptions import ConfigError

CONFIG_DIR = Path(user_config_dir("edcli"))
CONFIG_FILE = CONFIG_DIR / "config.toml"


@dataclass
class Config:
    token: str = ""
    base_url: str = "https://us.edstem.org"
    default_course_id: int | None = None
    output_format: str = "table"

    @classmethod
    def load(cls) -> Config:
        """Load config from disk, returning defaults if file doesn't exist."""
        if not CONFIG_FILE.exists():
            return cls()
        with open(CONFIG_FILE, "rb") as f:
            data = tomllib.load(f)
        return cls(
            token=data.get("token", ""),
            base_url=data.get("base_url", "https://us.edstem.org"),
            default_course_id=data.get("default_course_id"),
            output_format=data.get("output_format", "table"),
        )

    def save(self) -> None:
        """Save config to disk with restricted permissions."""
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        data: dict = {
            "token": self.token,
            "base_url": self.base_url,
            "output_format": self.output_format,
        }
        if self.default_course_id is not None:
            data["default_course_id"] = self.default_course_id
        with open(CONFIG_FILE, "wb") as f:
            tomli_w.dump(data, f)
        os.chmod(CONFIG_FILE, stat.S_IRUSR | stat.S_IWUSR)

    def require_token(self) -> str:
        if not self.token:
            raise ConfigError(
                "No token configured. Run 'edcli configure' first."
            )
        return self.token

    def require_course(self, course_id: int | None) -> int:
        cid = course_id or self.default_course_id
        if cid is None:
            raise ConfigError(
                "No course specified. Use -c COURSE_ID or set a default with 'edcli configure'."
            )
        return cid
