from __future__ import annotations

from trajectly.cli import app

app()
