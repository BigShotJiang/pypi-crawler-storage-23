"""File detection, collection, preparation, and git utilities."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    from pathspec import PathSpec
    from pathspec.patterns import GitWildMatchPattern
    HAS_PATHSPEC = True
except ImportError:
    HAS_PATHSPEC = False

from .config import HackiGitError

# ---------------------------------------------------------------------------
# File type detection
# ---------------------------------------------------------------------------

DEPENDENCY_FILES: set[str] = {
    # Python
    "requirements.txt", "pipfile", "pipfile.lock", "poetry.lock", "pyproject.toml",
    # Node.js
    "package.json", "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
    # PHP
    "composer.json", "composer.lock",
    # Ruby
    "gemfile", "gemfile.lock",
    # Rust
    "cargo.toml", "cargo.lock",
    # Go
    "go.mod", "go.sum",
    # Java
    "pom.xml",
}

IAC_EXTENSIONS: set[str] = {".tf", ".bicep", ".rego", ".jsonnet"}

IAC_NAMES: set[str] = {
    "dockerfile", "docker-compose.yml", "docker-compose.yaml",
    "serverless.yml", "serverless.yaml", "serverless.json",
    ".gitlab-ci.yml", ".travis.yml", "jenkinsfile",
    "chart.yaml", "values.yaml",
    "playbook.yml", "site.yml",
}

IAC_DIRECTORIES: set[str] = {
    ".github/workflows", ".circleci", "terraform", "kubernetes",
    "k8s", "helm", "charts", "templates",
}

EXTENSION_TO_LANGUAGE: dict[str, str] = {
    ".py": "python", ".pyw": "python",
    ".js": "javascript", ".jsx": "javascript",
    ".ts": "typescript", ".tsx": "typescript",
    ".java": "java",
    ".go": "go",
    ".rs": "rust",
    ".c": "c", ".h": "c",
    ".cpp": "cpp", ".cc": "cpp", ".hpp": "cpp",
    ".cs": "csharp",
    ".rb": "ruby",
    ".php": "php",
    ".swift": "swift",
    ".kt": "kotlin",
    ".scala": "scala",
    ".sh": "bash", ".bash": "bash",
    ".ps1": "powershell",
    ".sql": "sql",
    ".html": "html",
    ".css": "css",
    ".vue": "vuejs",
    ".svelte": "svelte",
    ".dart": "dart",
    ".hs": "haskell",
    ".lua": "lua",
    ".r": "r",
    ".jl": "julia",
    ".ex": "elixir", ".exs": "elixir",
    ".erl": "erlang",
    ".nim": "nim",
    ".zig": "zig",
    ".bat": "batch", ".cmd": "batch",
    ".json": "json",
    ".yml": "yaml", ".yaml": "yaml",
    ".xml": "xml",
    ".toml": "toml",
}


def detect_file_type(path: Path) -> str:
    """Detect file type with priority: dependency > infrastructure > code."""
    name_lower = path.name.lower()

    # 1. Dependency files (by exact name, case-insensitive)
    if name_lower in DEPENDENCY_FILES:
        return "dependency"

    # 2. Infrastructure as code
    if _is_iac(path):
        return "infrastructure"

    # 3. Code (by extension or Dockerfile pattern)
    return "code"


def _is_iac(path: Path) -> bool:
    name_lower = path.name.lower()

    # By extension
    if path.suffix.lower() in IAC_EXTENSIONS:
        return True

    # .tf.json
    if path.name.lower().endswith(".tf.json"):
        return True

    # By name
    if name_lower in IAC_NAMES:
        return True

    # Dockerfile and variants
    if name_lower == "dockerfile" or name_lower.startswith("dockerfile."):
        return True

    # By parent directory
    parts_lower = [p.lower() for p in path.parts]
    for iac_dir in IAC_DIRECTORIES:
        # Check if any consecutive path parts match the iac_dir path
        iac_parts = iac_dir.split("/")
        for i in range(len(parts_lower) - len(iac_parts)):
            if parts_lower[i : i + len(iac_parts)] == iac_parts:
                # yaml/json/yml files in IaC directories
                if path.suffix.lower() in (".yml", ".yaml", ".json"):
                    return True

    return False


def detect_language(path: Path) -> str:
    """Detect the language string expected by the HackiAI API."""
    # GitHub Actions: .github/workflows/*.yml
    parts = [p.lower() for p in path.parts]
    try:
        gw_idx = parts.index(".github")
        if gw_idx + 1 < len(parts) and parts[gw_idx + 1] == "workflows":
            if path.suffix.lower() in (".yml", ".yaml"):
                return "github-actions"
    except ValueError:
        pass

    # Dockerfile variants
    name_lower = path.name.lower()
    if name_lower == "dockerfile" or name_lower.startswith("dockerfile."):
        return "dockerfile"

    return EXTENSION_TO_LANGUAGE.get(path.suffix.lower(), "")


# ---------------------------------------------------------------------------
# Line numbering
# ---------------------------------------------------------------------------

def add_line_numbers(content: str) -> str:
    """Prefix each line with its 1-based line number: 'N: content'."""
    lines = content.splitlines(keepends=True)
    numbered = []
    for i, line in enumerate(lines, 1):
        numbered.append(f"{i}: {line}")
    return "".join(numbered)


# ---------------------------------------------------------------------------
# PreparedFile
# ---------------------------------------------------------------------------

@dataclass
class PreparedFile:
    path: Path
    filename: str
    code: str
    language: str
    file_type: str
    diff: str | None = None
    git_metadata: dict[str, Any] | None = None
    is_binary: bool = False


def prepare_file(path: Path, include_diff: bool = False) -> PreparedFile | None:
    """Read a file, detect type/language, add line numbers.

    Returns None for binary files (with a note).
    """
    try:
        raw_bytes = path.read_bytes()
    except OSError:
        return None

    # Binary detection
    if b"\x00" in raw_bytes[:8192]:
        return PreparedFile(
            path=path,
            filename=path.name,
            code="[binary file omitted]",
            language="",
            file_type="code",
            is_binary=True,
        )

    try:
        content = raw_bytes.decode("utf-8", errors="replace")
    except Exception:
        content = raw_bytes.decode("latin-1", errors="replace")

    file_type = detect_file_type(path)
    language = detect_language(path)

    # Only add line numbers for code files
    if file_type == "code":
        code = add_line_numbers(content)
    else:
        code = content

    diff = None
    git_meta = None
    if include_diff:
        diff = get_git_diff(path)
        git_meta = get_git_metadata(path)

    return PreparedFile(
        path=path,
        filename=path.name,
        code=code,
        language=language,
        file_type=file_type,
        diff=diff,
        git_metadata=git_meta,
    )


# ---------------------------------------------------------------------------
# .hackiignore support
# ---------------------------------------------------------------------------

def find_hackiignore(start: Path) -> Path | None:
    """Walk up from start searching for .hackiignore or .git root."""
    current = start.resolve()
    root = Path(current.anchor)

    while current != root:
        hackiignore = current / ".hackiignore"
        if hackiignore.exists():
            return hackiignore
        # Stop at git root
        if (current / ".git").exists():
            return None
        current = current.parent
    return None


def build_pathspec_matcher(hackiignore_path: Path):
    """Build a pathspec matcher from a .hackiignore file.

    Returns a PathSpec object or None if pathspec is unavailable.
    """
    if not HAS_PATHSPEC:
        return None
    try:
        lines = hackiignore_path.read_text().splitlines()
        spec = PathSpec.from_lines(GitWildMatchPattern, lines)
        return spec
    except Exception:
        return None


def filter_files(paths: list[Path], base_dir: Path, spec) -> list[Path]:
    """Filter paths using a pathspec matcher relative to base_dir."""
    if spec is None:
        return paths

    result = []
    for p in paths:
        try:
            relative = p.relative_to(base_dir)
            rel_str = str(relative)
        except ValueError:
            rel_str = str(p)

        if not spec.match_file(rel_str):
            result.append(p)
    return result


def collect_files(directory: Path) -> list[Path]:
    """Collect all non-directory files under directory, respecting .hackiignore."""
    directory = directory.resolve()
    all_files = [p for p in directory.rglob("*") if p.is_file()]

    hackiignore = find_hackiignore(directory)
    if hackiignore:
        spec = build_pathspec_matcher(hackiignore)
        base_dir = hackiignore.parent
        all_files = filter_files(all_files, base_dir, spec)

    return sorted(all_files)


# ---------------------------------------------------------------------------
# Git utilities
# ---------------------------------------------------------------------------

def _run_git(*args: str, cwd: Path | None = None) -> str | None:
    """Run a git command and return stdout, or None on failure."""
    try:
        result = subprocess.run(
            ["git", *args],
            capture_output=True,
            text=True,
            timeout=10,
            cwd=str(cwd) if cwd else None,
        )
        if result.returncode == 0:
            return result.stdout
        return None
    except FileNotFoundError:
        # git not installed
        return None
    except subprocess.TimeoutExpired:
        return None


def get_git_diff(path: Path) -> str | None:
    """Return git diff HEAD for a specific file, or None."""
    output = _run_git("diff", "HEAD", "--", str(path), cwd=path.parent)
    return output if output else None


def get_git_metadata(path: Path) -> dict[str, Any] | None:
    """Return metadata of the last commit touching path, or None."""
    fmt = "%an%x00%ae%x00%aI%x00%s%x00%H"
    output = _run_git(
        "log", "-1", f"--format={fmt}", "--", str(path), cwd=path.parent
    )
    if not output:
        return None
    parts = output.strip().split("\x00")
    if len(parts) < 5:
        return None
    return {
        "author": parts[0],
        "email": parts[1],
        "date": parts[2],
        "message": parts[3],
        "sha": parts[4],
    }


def get_staged_files() -> list[Path]:
    """Return list of staged file paths.

    Raises HackiGitError if not in a git repo or git is unavailable.
    """
    try:
        result = subprocess.run(
            ["git", "diff", "--cached", "--name-only"],
            capture_output=True,
            text=True,
            timeout=10,
        )
    except FileNotFoundError as exc:
        raise HackiGitError("git is not installed or not in PATH.") from exc
    except subprocess.TimeoutExpired as exc:
        raise HackiGitError("git command timed out.") from exc

    if result.returncode != 0:
        raise HackiGitError(
            f"Not a git repository or git error: {result.stderr.strip()}"
        )

    files = []
    for line in result.stdout.splitlines():
        line = line.strip()
        if line:
            files.append(Path(line).resolve())
    return files


def get_staged_diff() -> str | None:
    """Return git diff --cached output, or None."""
    output = _run_git("diff", "--cached")
    return output if output else None


def get_git_branch() -> str | None:
    """Return current git branch name, or None."""
    output = _run_git("rev-parse", "--abbrev-ref", "HEAD")
    return output.strip() if output else None


def get_git_commit_sha() -> str | None:
    """Return current HEAD commit SHA, or None."""
    output = _run_git("rev-parse", "HEAD")
    return output.strip() if output else None
