# CLI Reviews API - Documentación

Esta documentación describe los endpoints disponibles para que el CLI obtenga información de reviews y hallazgos sin necesidad de almacenarla localmente.

## Autenticación

Todos los endpoints requieren autenticación mediante API Key en el header:

```
X-API-Key: <tu-api-key>
```

## Base URL

Todos los endpoints están bajo el prefijo `/analisis-cli`:

```
https://api.hackademy.com/analisis-cli/...
```

---

## Endpoints

### 1. Listar Reviews del Usuario

Obtiene una lista paginada de todos los reviews que el usuario ha realizado.

#### Endpoint

```
GET /analisis-cli/reviews
```

#### Query Parameters

| Parámetro | Tipo | Requerido | Default | Descripción |
|-----------|------|-----------|---------|-------------|
| `page` | integer | No | 1 | Número de página (≥ 1) |
| `size` | integer | No | 20 | Tamaño de página (1-100) |
| `start_date` | datetime (ISO 8601) | No | - | Fecha de inicio para filtrar (incluye el día completo) |
| `end_date` | datetime (ISO 8601) | No | - | Fecha de fin para filtrar (incluye el día completo) |
| `type` | string | No | - | Filtrar por tipo de review |
| `filename` | string | No | - | Búsqueda parcial por nombre de archivo (case-insensitive) |
| `sort` | string | No | `created_at_desc` | Orden de resultados (ver opciones abajo) |

#### Opciones de Ordenamiento (`sort`)

- `created_at_desc` - Más recientes primero (default)
- `created_at_asc` - Más antiguos primero
- `filename_asc` - Orden alfabético por nombre de archivo (A-Z)
- `filename_desc` - Orden alfabético inverso (Z-A)

#### Ejemplo de Request

```bash
curl -X GET "https://api.hackademy.com/analisis-cli/reviews?page=1&size=20&start_date=2026-01-01T00:00:00Z&end_date=2026-01-31T23:59:59Z&sort=created_at_desc" \
  -H "X-API-Key: tu-api-key-aqui"
```

#### Response (200 OK)

```json
{
  "items": [
    {
      "id": "123e4567-e89b-12d3-a456-426614174000",
      "filename": "app.py",
      "type": "security",
      "total_issues": 15,
      "low_quantity": 5,
      "medium_quantity": 6,
      "high_quantity": 3,
      "critical_quantity": 1,
      "unknown_quantity": 0,
      "created_at": "2026-01-15T10:30:00"
    },
    {
      "id": "223e4567-e89b-12d3-a456-426614174001",
      "filename": "utils.py",
      "type": "security",
      "total_issues": 8,
      "low_quantity": 3,
      "medium_quantity": 4,
      "high_quantity": 1,
      "critical_quantity": 0,
      "unknown_quantity": 0,
      "created_at": "2026-01-14T09:15:00"
    }
  ],
  "pagination": {
    "total": 45,
    "page": 1,
    "size": 20,
    "pages": 3,
    "has_next": true,
    "has_prev": false
  }
}
```

#### Códigos de Error

- `401 Unauthorized` - API key inválida o no proporcionada
- `403 Forbidden` - No se encontró licencia asociada al usuario
- `500 Internal Server Error` - Error interno del servidor

---

### 2. Listar Hallazgos de un Review

Obtiene una lista paginada de todos los hallazgos (issues) de un review específico.

#### Endpoint

```
GET /analisis/reviews-cli/{review_id}/issues
```

#### Path Parameters

| Parámetro | Tipo | Descripción |
|-----------|------|-------------|
| `review_id` | UUID | ID del review |

#### Query Parameters

| Parámetro | Tipo | Requerido | Default | Descripción |
|-----------|------|-----------|---------|-------------|
| `page` | integer | No | 1 | Número de página (≥ 1) |
| `size` | integer | No | 50 | Tamaño de página (1-200) |
| `severity` | string[] | No | - | Filtrar por severidad (puede repetirse): `LOW`, `MEDIUM`, `HIGH`, `CRITICAL`, `UNKNOWN` |
| `status` | string[] | No | - | Filtrar por status (puede repetirse): `pending`, `resolved`, `ignored` |
| `filename` | string | No | - | Búsqueda parcial por nombre de archivo (case-insensitive) |
| `sort` | string | No | `severity_asc` | Orden de resultados (ver opciones abajo) |

#### Opciones de Ordenamiento (`sort`)

- `severity_asc` - Por severidad ascendente: CRITICAL > HIGH > MEDIUM > LOW > UNKNOWN (default)
- `severity_desc` - Por severidad descendente
- `line_asc` - Por número de línea ascendente
- `line_desc` - Por número de línea descendente
- `created_at_desc` - Más recientes primero
- `created_at_asc` - Más antiguos primero

#### Ejemplo de Request

```bash
# Obtener solo issues críticos y de alta severidad que están pendientes
curl -X GET "https://api.hackademy.com/analisis-cli/reviews/123e4567-e89b-12d3-a456-426614174000/issues?severity=CRITICAL&severity=HIGH&status=pending&page=1&size=50" \
  -H "X-API-Key: tu-api-key-aqui"
```

```bash
# Filtrar por archivo específico
curl -X GET "https://api.hackademy.com/analisis-cli/reviews/123e4567-e89b-12d3-a456-426614174000/issues?filename=app.py&status=pending" \
  -H "X-API-Key: tu-api-key-aqui"
```

#### Response (200 OK)

```json
{
  "items": [
    {
      "id": "323e4567-e89b-12d3-a456-426614174002",
      "filename": "app.py",
      "line": 42,
      "issue": "SQL Injection vulnerability detected",
      "description": "User input is directly concatenated into SQL query without sanitization",
      "severity": "CRITICAL",
      "suggestion": "Use parameterized queries or prepared statements",
      "fixed_code": "cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))",
      "status": "pending",
      "created_at": "2026-01-15T10:30:00"
    },
    {
      "id": "423e4567-e89b-12d3-a456-426614174003",
      "filename": "app.py",
      "line": 78,
      "issue": "Hardcoded password",
      "description": "Password is hardcoded in source code",
      "severity": "HIGH",
      "suggestion": "Move password to environment variables or secure vault",
      "fixed_code": null,
      "status": "pending",
      "created_at": "2026-01-15T10:30:00"
    }
  ],
  "pagination": {
    "total": 15,
    "page": 1,
    "size": 50,
    "pages": 1,
    "has_next": false,
    "has_prev": false
  },
  "total_issues_in_review": 15
}
```

#### Campos del Issue

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `id` | UUID | ID único del issue |
| `filename` | string | Nombre del archivo donde se encontró el issue |
| `line` | integer \| null | Número de línea (puede ser null) |
| `issue` | string | Título/categoría del issue |
| `description` | string \| null | Descripción detallada del problema |
| `severity` | string | Severidad: `LOW`, `MEDIUM`, `HIGH`, `CRITICAL`, `UNKNOWN` |
| `suggestion` | string \| null | Sugerencia de cómo resolver el issue |
| `fixed_code` | string \| null | Código sugerido de ejemplo |
| `status` | string | Estado: `pending`, `resolved`, `ignored` |
| `created_at` | datetime | Fecha de creación (ISO 8601) |

#### Códigos de Error

- `401 Unauthorized` - API key inválida o no proporcionada
- `403 Forbidden` - No se encontró licencia asociada al usuario
- `404 Not Found` - Review no encontrado o no tienes acceso a él
- `500 Internal Server Error` - Error interno del servidor

---

### 3. Actualizar Status de un Issue

Marca un issue como resuelto, ignorado, o vuelve a marcarlo como pendiente.

#### Endpoint

```
PATCH /analisis/reviews-cli/{review_id}/issues/{issue_id}/status
```

#### Path Parameters

| Parámetro | Tipo | Descripción |
|-----------|------|-------------|
| `review_id` | UUID | ID del review |
| `issue_id` | UUID | ID del issue |

#### Request Body

```json
{
  "status": "resolved"
}
```

#### Valores de Status

| Valor | Descripción |
|-------|-------------|
| `pending` | Issue pendiente de resolver (estado inicial) |
| `resolved` | Issue resuelto/fixed |
| `ignored` | Issue ignorado/wontfix |

#### Ejemplo de Request

```bash
# Marcar un issue como resuelto
curl -X PATCH "https://api.hackademy.com/analisis-cli/reviews/123e4567-e89b-12d3-a456-426614174000/issues/323e4567-e89b-12d3-a456-426614174002/status" \
  -H "X-API-Key: tu-api-key-aqui" \
  -H "Content-Type: application/json" \
  -d '{"status": "resolved"}'
```

```bash
# Marcar un issue como ignorado
curl -X PATCH "https://api.hackademy.com/analisis-cli/reviews/123e4567-e89b-12d3-a456-426614174000/issues/323e4567-e89b-12d3-a456-426614174002/status" \
  -H "X-API-Key: tu-api-key-aqui" \
  -H "Content-Type: application/json" \
  -d '{"status": "ignored"}'
```

#### Response (200 OK)

Retorna el issue actualizado:

```json
{
  "id": "323e4567-e89b-12d3-a456-426614174002",
  "filename": "app.py",
  "line": 42,
  "issue": "SQL Injection vulnerability detected",
  "description": "User input is directly concatenated into SQL query without sanitization",
  "severity": "CRITICAL",
  "suggestion": "Use parameterized queries or prepared statements",
  "fixed_code": "cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))",
  "status": "resolved",
  "created_at": "2026-01-15T10:30:00"
}
```

#### Códigos de Error

- `401 Unauthorized` - API key inválida o no proporcionada
- `403 Forbidden` - No se encontró licencia asociada al usuario
- `404 Not Found` - Review o issue no encontrado, o no tienes acceso a él
- `422 Unprocessable Entity` - Status inválido o formato de request incorrecto
- `500 Internal Server Error` - Error interno del servidor

---

## Ejemplos de Uso Comunes

### Obtener todos los issues críticos pendientes de todos los reviews

```bash
# 1. Primero obtén la lista de reviews
REVIEWS=$(curl -s -X GET "https://api.hackademy.com/analisis-cli/reviews" \
  -H "X-API-Key: tu-api-key-aqui")

# 2. Para cada review_id, obtén los issues críticos pendientes
for review_id in $(echo $REVIEWS | jq -r '.items[].id'); do
  curl -s -X GET "https://api.hackademy.com/analisis-cli/reviews/$review_id/issues?severity=CRITICAL&status=pending" \
    -H "X-API-Key: tu-api-key-aqui"
done
```

### Filtrar reviews de los últimos 7 días

```bash
START_DATE=$(date -u -d '7 days ago' +%Y-%m-%dT00:00:00Z)
END_DATE=$(date -u +%Y-%m-%dT23:59:59Z)

curl -X GET "https://api.hackademy.com/analisis-cli/reviews?start_date=$START_DATE&end_date=$END_DATE" \
  -H "X-API-Key: tu-api-key-aqui"
```

### Obtener estadísticas de resolución

```bash
# Issues totales
TOTAL=$(curl -s -X GET "https://api.hackademy.com/analisis-cli/reviews/REVIEW_ID/issues" \
  -H "X-API-Key: tu-api-key-aqui" | jq '.total_issues_in_review')

# Issues resueltos
RESOLVED=$(curl -s -X GET "https://api.hackademy.com/analisis-cli/reviews/REVIEW_ID/issues?status=resolved" \
  -H "X-API-Key: tu-api-key-aqui" | jq '.pagination.total')

# Calcular porcentaje
echo "Resolved: $RESOLVED / $TOTAL ($((RESOLVED * 100 / TOTAL))%)"
```

---

## Notas de Implementación

### Paginación

- Todos los endpoints que devuelven listas usan paginación
- Usa `pagination.has_next` y `pagination.has_prev` para navegar
- El campo `pagination.pages` indica el total de páginas disponibles
- `pagination.total` indica el total de elementos (después de aplicar filtros)

### Filtros Múltiples

Los parámetros `severity` y `status` pueden repetirse en la URL para filtrar por múltiples valores:

```
?severity=CRITICAL&severity=HIGH&status=pending
```

Esto retornará issues que sean **CRITICAL o HIGH** Y que tengan status **pending**.

### Fechas

Las fechas deben estar en formato ISO 8601:

- `2026-01-15T10:30:00Z` - UTC
- `2026-01-15T10:30:00+00:00` - UTC con timezone
- `2026-01-15` - Solo fecha (se incluye todo el día)

### Manejo de Errores

Siempre verifica los códigos de respuesta HTTP:

- `200` - Éxito
- `401` - Autenticación fallida
- `403` - Sin permisos
- `404` - Recurso no encontrado
- `422` - Request mal formado
- `500` - Error del servidor

### Rate Limiting

Consulta la documentación general de la API para conocer los límites de rate limiting aplicables.

---

## Preguntas Frecuentes

**P: ¿Cómo sé si un review tiene issues pendientes?**  
R: Obtén la lista de issues con `status=pending` y revisa `pagination.total`.

**P: ¿Puedo filtrar por múltiples severidades y múltiples status al mismo tiempo?**  
R: Sí, puedes combinar múltiples filtros. Ejemplo: `?severity=CRITICAL&severity=HIGH&status=pending&status=ignored`

**P: ¿Qué pasa si cambio el status de un issue a "resolved" y luego vuelvo a analizar el código?**  
R: El status se mantiene. Si el mismo issue se detecta nuevamente, se creará un nuevo issue con status "pending".

**P: ¿Los filtros son case-sensitive?**  
R: No, los filtros de `severity`, `status` y `filename` son case-insensitive. Sin embargo, se recomienda usar los valores exactos como se muestran en la documentación para mayor claridad.

**P: ¿Cómo obtengo solo los issues críticos de todos mis reviews?**  
R: Necesitas hacer dos llamadas: primero obtener la lista de reviews, y luego para cada review obtener los issues con `severity=CRITICAL`.

---

## Changelog

- **2026-01-16**: Versión inicial
  - Endpoint para listar reviews del usuario
  - Endpoint para listar issues de un review
  - Endpoint para actualizar status de un issue
  - Soporte para filtros por severidad, status, fecha y filename
  - Paginación completa en todos los endpoints
