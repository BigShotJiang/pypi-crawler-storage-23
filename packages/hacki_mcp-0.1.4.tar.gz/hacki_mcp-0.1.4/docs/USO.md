# hacki-graph — Documentación

Instalación:

```
pip install hacki-graph
# o desde el wheel local:
pip install dist/hacki_graph-0.1.0-py3-none-any.whl
Dependencias: tree-sitter>=0.20.4, tree-sitter-languages>=1.10.2, networkx>=3.6, requests>=2.32.3
```
## Punto de entrada recomendado: GraphOrchestrator
Es el orquestador de alto nivel. Detecta cambios de rama Git, valida consistencia y decide si reconstruir o reutilizar el análisis en caché.

```
from hacki_graph import GraphOrchestrator

orchestrator = GraphOrchestrator("/ruta/al/proyecto")

results = orchestrator.ensure_analysis_ready([
    "src/main.py",
    "src/utils.py"
])
```
Retorno de `ensure_analysis_ready(file_paths)`
```
{
    "tree_sitter_graph": {
        "nodes": [...],   # lista de nodos (file, function, class, import, call)
        "edges": [...],   # lista de relaciones (contains, calls, imports, defines)
        "metadata": {...}
    },
    "static_analysis": {
        "ir_files": {...},   # Intermediate Representation por archivo
        "cfg_files": {...},  # Control Flow Graph por archivo
        "dfg_files": {...},  # Data Flow Graph por archivo
        "stats": {...}
    },
    "metadata": {
        "git_branch": "main",
        "git_commit": "abc123...",
        "last_updated": "2026-02-24T...",
        "total_files": 42
    },
    "validation": {
        "is_valid": True,
        "errors": [],
        "warnings": []
    },
    "actions_taken": [
        "Construyendo graph.json completo",
        ...
    ]
}
```
## EnhancedGraphManager (alias: GraphManager)
Control más granular sobre el grafo Tree-sitter y el análisis estático.

```
from hacki_graph import GraphManager  # alias de EnhancedGraphManager

manager = GraphManager("/ruta/al/proyecto")  # default: "."
```
### API Tree-sitter (grafo de dependencias)
Método	                             Descripción
build_full_graph() -> dict	         Construye el grafo completo desde cero
update_incremental_graph() -> dict	 Actualiza el grafo solo con archivos modificados
save_graph(graph: dict)	             Persiste en .hacki/graph.json
load_graph() -> dict	             Carga desde .hacki/graph.json
graph_exists() -> bool	             Verifica si hay grafo guardado

```
graph = manager.build_full_graph()
manager.save_graph(graph)

# Estructura del grafo:
# graph["nodes"] -> lista de GraphNode
# graph["edges"] -> lista de GraphEdge
# graph["metadata"] -> { project_root, total_files, total_nodes, branch, ... }
```
### API análisis estático (IR / CFG / DFG)
Método	                                                Descripción
build_full_static_analysis(file_paths) -> dict	        Construye IR+CFG+DFG completo
update_incremental_static_analysis(file_paths) -> dict	Actualiza solo archivos cambiados
static_analysis_exists() -> bool	                    Verifica si hay análisis guardado
get_function_analysis(file_path, function_name) -> dict	CFG+DFG de una función concreta
get_analysis_stats() -> dict	                        Estadísticas del análisis (funciones, bloques, nodos)
find_complex_functions(min_blocks=10) -> list	        Funciones con alta complejidad ciclomática
find_data_flow_issues() -> dict	                        Variables no usadas, usos sin inicializar, dependencias circulares

### API incremental y de cambios
Método	                                                Descripción
detect_file_changes(file_paths) -> dict	                Detecta qué archivos cambiaron sin actualizar análisis
get_dependency_graph(file_paths) -> dict	            Grafo de dependencias entre archivos
find_affected_files(changed_files, all_files) -> set	Archivos impactados por un cambio
force_rebuild_file(file_path) -> dict	                Fuerza reconstrucción de un archivo específico
get_incremental_stats() -> dict	                        Estadísticas del sistema incremental

## Estructuras de datos del grafo

### GraphNode (dataclass)
```
{
    "id": "node_1",
    "type": "function",    # "file" | "function" | "class" | "import" | "call"
    "name": "my_function",
    "file_path": "src/utils.py",
    "line_start": 10,
    "line_end": 25,
    "metadata": {
        # Para "function":
        "parameters": ["x", "y"],
        "return_type": "int",
        "is_async": False,
        "is_class_method": True,
        "class_name": "MyClass",
        "visibility": "public"  # "public" | "private" | "protected"
    }
}
```
### GraphEdge (dataclass)
```
{
    "id": "edge_1",
    "source": "node_5",   # ID del nodo origen
    "target": "node_12",  # ID del nodo destino
    "type": "calls",      # "contains" | "calls" | "imports" | "defines"
    "metadata": {}
}
```
## Clases de soporte

### GraphValidator
```
from hacki_graph import GraphValidator

validator = GraphValidator("/ruta/al/proyecto")
result = validator.validate_consistency()
# result["is_valid"], result["errors"], result["warnings"]

validator.validate_files_exist()   # Verifica que archivos referenciados existan
validator.validate_hashes()        # Compara hashes guardados vs. actuales
```

### GraphMetadata
```
from hacki_graph import GraphMetadata

meta = GraphMetadata("/ruta/al/proyecto")
meta.load()

meta.get_branch()           # -> "main" | None
meta.get_commit()           # -> "abc123..." | None
meta.is_branch_changed("feature-x")  # -> bool
meta.update_branch("main")
meta.update_commit("abc123")
meta.to_dict()              # -> dict completo
meta.save()
```

### LanguageRegistry / get_language_registry()
```
from hacki_graph import get_language_registry, LanguageRegistry

registry = get_language_registry()  # singleton global

registry.get_supported_languages()   # ["python", "javascript", "typescript", "java", "csharp", "php", "go"]
registry.get_supported_extensions()  # {".py", ".js", ".ts", ".java", ...}
registry.is_file_supported("main.py")  # True
registry.get_language_by_file("app.ts")  # LanguageConfig
registry.get_language_by_extension(".go")  # LanguageConfig
```

## Archivos generados (.hacki/)
El paquete persiste su trabajo en el directorio .hacki/ dentro del proyecto:

```
.hacki/
├── graph.json          # Grafo Tree-sitter (nodos + edges)
├── graph_metadata.json # Metadata (branch, commit, timestamps)
├── file_hashes.json    # Hashes SHA1 de archivos para detección incremental
└── graphs/
    ├── ir.json         # Intermediate Representation
    ├── cfg.json        # Control Flow Graphs
    └── dfg.json        # Data Flow Graphs
```

## Flujo de uso típico
```
from hacki_graph import GraphOrchestrator

# 1. Modo simple: orquestador automático
orchestrator = GraphOrchestrator(".")
results = orchestrator.ensure_analysis_ready(["src/api.py", "src/models.py"])

graph = results["tree_sitter_graph"]
print(f"{len(graph['nodes'])} nodos, {len(graph['edges'])} relaciones")

# 2. Modo manual: mayor control
from hacki_graph import GraphManager

manager = GraphManager(".")

if not manager.graph_exists():
    graph = manager.build_full_graph()
    manager.save_graph(graph)
else:
    graph = manager.load_graph()

# Obtener análisis de una función concreta
analysis = manager.get_function_analysis("src/api.py", "handle_request")
# analysis["cfg"] -> Control Flow Graph
# analysis["dfg"] -> Data Flow Graph

# Detectar funciones complejas
complex_fns = manager.find_complex_functions(min_blocks=5)

# Detectar problemas de flujo de datos
issues = manager.find_data_flow_issues()
# issues["unused_definitions"], issues["uninitialized_uses"]
```

## Lenguajes soportados
Lenguaje	  Extensiones
Python	      .py, .pyx, .pyi
JavaScript	  .js, .jsx, .mjs
TypeScript	  .ts, .tsx
Java	      .java
C#	          .cs
Go	          .go
PHP	          .php, .phtml
