# WebSocket Commit Review - Especificación de Comunicación

## Endpoint

**URL:** `ws://<host>/analisis/commit-review`

**Autenticación:** API Key enviada como query parameter: `?api_key=<your_api_key>`

---
## Mensaje del commit
- Lo genera el backend con nuestra inteligencia artificial.
- Si no es muy complejo pudieramos implementar la fución de que el usuario pueda editar el mensaje antes de confirmar el commit

## Formato de Comunicación

### **Stream de Mensajes (Bidireccional)**

La comunicación es un **stream de mensajes JSON** donde:
- El cliente envía **1 mensaje inicial** para iniciar el análisis
- El servidor envía **múltiples mensajes** durante el proceso:
  - Mensajes de progreso (`progress`)
  - Mensajes de tarea completada (`task_completed`)
  - Mensaje final con resultados completos (`analysis_complete`)
  - Mensajes de error (`error`) si algo falla

---

## Estructura del Mensaje Inicial (Cliente → Servidor)

El endpoint soporta **dos protocolos** para manejar archivos grandes:

### Protocolo 1: Simple (Compatibilidad hacia atrás)

**Para archivos pequeños (< 1MB total):** Un solo mensaje con todos los archivos.

#### Request: `CommitReviewStartRequest`

```json
{
  "type": "start_analysis",
  "files": [
    {
      "filename": "app.py",
      "code": "def hello():\n    print('Hello')\n    password = 'secret123'",
      "type": "code",
      "processed": false
    }
  ],
  "code_graph": {
    "tree_sitter": {
      "nodes": [...],
      "edges": [...]
    },
    "static_analysis": {
      "cfg": {...},
      "dfg": {...},
      "ir": {...}
    }
  },
  "commit_message_style": "conventional"  // "conventional" | "simple"
}
```

### Protocolo 2: Múltiples Mensajes (Para archivos grandes)

**Para archivos grandes o muchos archivos:** Envía metadata primero, luego archivos uno por uno.

#### Paso 1: Metadata - `CommitReviewStartMetadata`

```json
{
  "type": "start_analysis",
  "file_count": 6,
  "file_names": ["app.py", "utils.py", "config.py", "main.py", "test.py", "requirements.txt"],
  "code_graph": {
    "tree_sitter": {...},
    "static_analysis": {...}
  },
  "commit_message_style": "conventional"
}
```

#### Paso 2-N: Archivos Individuales - `CommitReviewFileChunk`

```json
{
  "type": "file_chunk",
  "filename": "app.py",
  "code": "def hello():\n    print('Hello')\n    password = 'secret123'",
  "file_type": "code",
  "processed": false,
  "chunk_index": 0,
  "total_files": 6
}
```

**El servidor confirma cada archivo recibido:**

```json
{
  "type": "file_received",
  "filename": "app.py",
  "chunk_index": 0,
  "status": "ok"
}
```

### Campos Comunes:

- **`type`** (string, requerido): `"start_analysis"` (metadata) o `"file_chunk"` (archivos)
- **`files`** (array, Protocolo 1): Lista de archivos a analizar
  - `filename` (string): Nombre del archivo
  - `code` (string): Contenido del archivo
  - `type` (string): Tipo de archivo (default: `"code"`)
  - `processed` (boolean): Si el archivo ya fue procesado (default: `false`)
- **`file_count`** (int, Protocolo 2): Número total de archivos que se enviarán
- **`file_names`** (array, Protocolo 2): Lista de nombres de archivos (para validación)
- **`chunk_index`** (int, Protocolo 2): Índice del archivo (0-based)
- **`total_files`** (int, Protocolo 2): Total de archivos
- **`code_graph`** (object, opcional): Grafo de código generado por tree-sitter (igual que `/analisis/review`)
- **`commit_message_style`** (string, opcional): Estilo del mensaje de commit
  - `"conventional"`: Formato Conventional Commits (default)
  - `"simple"`: Formato simple

**Nota:** El payload es **similar a `/analisis/review`** pero con campos adicionales:
- ✅ `commit_message_style` (nuevo)
- ✅ El mensaje final incluye `commit_message` y `commit_message_body` (nuevo)
- ✅ Protocolo de múltiples mensajes para archivos grandes (nuevo)

---

## Estructura de Mensajes del Servidor

### 1. Mensaje de Progreso: `CommitReviewProgressMessage`

```json
{
  "type": "progress",
  "current_task": 1,
  "total_tasks": 3,
  "current_file": "app.py",
  "status": "analyzing"  // "analyzing" | "completed" | "error"
}
```

**Cuándo se envía:** Al iniciar el análisis de cada archivo.

---

### 2. Mensaje de Tarea Completada: `CommitReviewTaskCompletedMessage`

```json
{
  "type": "task_completed",
  "task_id": "abc-123-def",
  "filename": "app.py",
  "issues_found": 5,
  "severity_summary": {
    "critical": 0,
    "high": 2,
    "medium": 2,
    "low": 1
  }
}
```

**Cuándo se envía:** Cuando cada archivo termina de analizarse (en tiempo real).

---

### 3. Mensaje Final: `CommitReviewCompleteMessage`

```json
{
  "type": "analysis_complete",
  "findings": [
    {
      "filename": "app.py",
      "issues": [
        {
          "issue": "Hardcoded password detected",
          "description": "A hardcoded password was found in the source code",
          "suggestion": "Use environment variables for sensitive data",
          "suggestion_code": "password = os.getenv('DB_PASSWORD')",
          "line": 15,
          "severity": "high",
          "category": "security",
          "confidence": 0.9
        }
      ]
    }
  ],
  "findings_summary": {
    "critical": 0,
    "high": 2,
    "medium": 2,
    "low": 1,
    "total": 5
  },
  "commit_message": "fix(security): remove hardcoded credentials",
  "commit_message_body": "Replace hardcoded password with environment variable\n\n- Remove hardcoded password in app.py:15\n- Add environment variable usage",
  "files_analyzed": ["app.py", "utils.py"],
  "analysis_time": 12.5,
  "task_ids": ["abc-123-def", "xyz-789-ghi"]
}
```

**Campos:**

- **`type`** (string): `"analysis_complete"`
- **`findings`** (array): Lista de findings agrupados por archivo
  - `filename` (string): Nombre del archivo
  - `issues` (array): Lista de issues encontrados (mismo formato que `/analisis/review`)
- **`findings_summary`** (object): Resumen de severidades
  - `critical`, `high`, `medium`, `low` (int): Cantidad por severidad
  - `total` (int): Total de issues
- **`commit_message`** (string): **Mensaje de commit sugerido** (formato Conventional Commits)
- **`commit_message_body`** (string, opcional): Cuerpo del mensaje de commit con detalles
- **`files_analyzed`** (array): Lista de archivos analizados
- **`analysis_time`** (float): Tiempo total de análisis en segundos
- **`task_ids`** (array): IDs de las tareas Celery ejecutadas

**Cuándo se envía:** Al finalizar todo el análisis (después de todos los mensajes de progreso).

---

### 4. Mensaje de Error: `CommitReviewErrorMessage`

```json
{
  "type": "error",
  "message": "Invalid API key",
  "partial_results": {
    "completed": 2,
    "total": 3
  }
}
```

**Campos:**

- **`type`** (string): `"error"`
- **`message`** (string): Mensaje de error descriptivo
- **`partial_results`** (object, opcional): Resultados parciales si el error ocurre durante el análisis

**Cuándo se envía:** Si ocurre un error en cualquier momento del proceso.

---

## Flujo de Comunicación

### Protocolo Simple (Archivos Pequeños)

```
Cliente                          Servidor
  |                                |
  |--- start_analysis (con files) ->|
  |                                |--- progress (archivo 1) --->|
  |                                |--- task_completed (archivo 1) --->|
  |                                |--- progress (archivo 2) --->|
  |                                |--- task_completed (archivo 2) --->|
  |                                |--- analysis_complete ------->|
  |                                |--- [cierra conexión] ------->|
```

### Protocolo de Múltiples Mensajes (Archivos Grandes)

```
Cliente                          Servidor
  |                                |
  |--- start_analysis (metadata) -->|
  |--- file_chunk (archivo 0) ----->|
  |<--- file_received (archivo 0) --|
  |--- file_chunk (archivo 1) ----->|
  |<--- file_received (archivo 1) --|
  |--- file_chunk (archivo 2) ----->|
  |<--- file_received (archivo 2) --|
  |                                |--- progress (archivo 1) --->|
  |                                |--- task_completed (archivo 1) --->|
  |                                |--- progress (archivo 2) --->|
  |                                |--- task_completed (archivo 2) --->|
  |                                |--- analysis_complete ------->|
  |                                |--- [cierra conexión] ------->|
```

---

## Comparación con `/analisis/review`

### Similitudes:
- ✅ Mismo formato de `files` (array de `FileData`)
- ✅ Mismo formato de `code_graph` (opcional)
- ✅ Mismo formato de `issues` en los resultados
- ✅ Misma estructura de `findings`

### Diferencias:
- ✅ **WebSocket:** Stream de mensajes en tiempo real
- ✅ **WebSocket:** Incluye `commit_message` y `commit_message_body` en la respuesta
- ✅ **WebSocket:** Incluye `commit_message_style` en el request
- ✅ **WebSocket:** Mensajes de progreso (`progress`, `task_completed`)
- ❌ **REST:** Un solo request/response
- ❌ **REST:** No incluye mensaje de commit sugerido

---

## Ejemplo Completo de Uso

### Cliente (JavaScript/TypeScript) - Protocolo Simple

```javascript
const ws = new WebSocket('ws://localhost:8000/analisis/commit-review?api_key=your_api_key');

ws.onopen = () => {
  // Enviar mensaje inicial con todos los archivos (para archivos pequeños)
  ws.send(JSON.stringify({
    type: "start_analysis",
    files: [
      {
        filename: "app.py",
        code: "def hello():\n    print('Hello')",
        type: "code",
        processed: false
      }
    ],
    commit_message_style: "conventional"
  }));
};
```

### Cliente (JavaScript/TypeScript) - Protocolo de Múltiples Mensajes

```javascript
const ws = new WebSocket('ws://localhost:8000/analisis/commit-review?api_key=your_api_key');

const files = [
  { filename: "app.py", code: "def hello():\n    print('Hello')" },
  { filename: "utils.py", code: "def helper():\n    pass" },
  // ... más archivos grandes
];

ws.onopen = () => {
  // Paso 1: Enviar metadata
  ws.send(JSON.stringify({
    type: "start_analysis",
    file_count: files.length,
    file_names: files.map(f => f.filename),
    commit_message_style: "conventional"
  }));
  
  // Paso 2: Enviar archivos uno por uno
  files.forEach((file, index) => {
    ws.send(JSON.stringify({
      type: "file_chunk",
      filename: file.filename,
      code: file.code,
      file_type: "code",
      processed: false,
      chunk_index: index,
      total_files: files.length
    }));
  });
};

ws.onmessage = (event) => {
  const message = JSON.parse(event.data);
  
  switch (message.type) {
    case "file_received":
      console.log(`✓ Archivo recibido: ${message.filename}`);
      break;
      
    case "progress":
      console.log(`Analizando ${message.current_file} (${message.current_task}/${message.total_tasks})`);
      break;
      
    case "task_completed":
      console.log(`✓ ${message.filename}: ${message.issues_found} issues encontrados`);
      break;
      
    case "analysis_complete":
      console.log("Análisis completo!");
      console.log("Mensaje de commit sugerido:", message.commit_message);
      console.log("Cuerpo:", message.commit_message_body);
      console.log("Findings:", message.findings);
      break;
      
    case "error":
      console.error("Error:", message.message);
      break;
  }
};


---

## Notas Importantes

1. **Autenticación:** La API key se envía como query parameter, no en el header
2. **Cierre de Conexión:** El servidor cierra la conexión después de enviar `analysis_complete` o `error`
3. **Timeout:** El análisis tiene un timeout de 300 segundos (5 minutos)
4. **Orden de Mensajes:** Los mensajes de progreso pueden llegar en cualquier orden, pero `analysis_complete` siempre llega al final
5. **Mensaje de Commit:** Se genera automáticamente basado en los findings usando el estilo especificado (Conventional Commits por defecto)
6. **Archivos Grandes:** Si recibes error `1009 (message too big)`, usa el Protocolo de Múltiples Mensajes
7. **Límite de Mensaje WebSocket:** Los mensajes WebSocket típicamente tienen un límite de ~1MB. Para archivos grandes o muchos archivos, usa el Protocolo 2
8. **Manejo de Desconexiones:** El servidor maneja correctamente las desconexiones del cliente sin errores


## Flujo de interacción
Así es el flujo
```
1. Usuario ejecuta `hacki commit`
2. Se obtienen archivos staged
3. Se conecta por WebSocket y envía análisis
4. Se reciben hallazgos + mensaje del commit
5. Se muestra al usuario
6. Se pregunta: "¿Quieres hacer commit con este mensaje?"
7. Si sí → `git commit -m "mensaje"`
8. Si no → cancelar
```

## Modo no interactivo
En esta versión no nos preocupamos por eso, seguirá activo el comando "hacki review --commit"

## Manejo de errores
- Si el WebSocket falla deberíamos de hacer un reitento y en caso de que vuelva a fallar decirle al usuario que puede correr hacki review --commit
-Si hay issues críticos, en esta versión, debemos de mostrar todos los hallazgos y seguir el flujo de preguntarle al developer si quiere hacer el commit.
- En esta pregunta tuya "¿Qué pasa si git commit falla (por ejemplo, no hay cambios staged)?" se supone que ya tenemos la logica implementada para validar si hay o no archivos en staged, el comando no puede continuar si no hay archivos en staged para un commit.

## Biblioteca WebSocket

websockets (asyncio)

## Parámetros del comando

Este está bien

- hacki commit --auto (hacer commit automáticamente si no hay críticos)

## URL del WebSocket
En producción será wss:// porque todo lo tenemos con SSL. En dev y prod la dirección se construye "API_URL/analisis/commit-review?api_key=XXX" solo que ahorita en dev va a ser "ws://"

El API_URL viene de hacki/cli/constants.py

## Timeout y espera

Yo creo que un timeout suficiente es de 60 segundo, en cuanto al indicador de progeso sería bueno implementarlo.

## Validación pre-commit

Claro que debe de valirdar que hay archivos en staged, no tiene sentido que el comando siga el flujo si no hay archivos en staged.
Debemos de validar que estamos en un repo de git
