# Commit Review API - Documentación para CLI

## Resumen

El endpoint `/commit-review` permite analizar archivos staged y generar un mensaje de commit sugerido usando LLM. Es similar a `/review` pero incluye generación automática de mensaje de commit basado en los hallazgos encontrados.

**Características principales:**
- ✅ Análisis asíncrono (igual que `/review`)
- ✅ Detección automática de archivos de dependencias
- ✅ Generación de mensaje de commit con LLM
- ✅ Soporte para grafos de código (tree-sitter)
- ✅ Formato Conventional Commits o simple

---

## Endpoints

### 1. Iniciar Análisis de Commit

**Endpoint:** `POST /analisis/commit-review`

**Autenticación:** API Key en header `X-API-Key`

**Request Body:**

```json
{
  "files": [
    {
      "filename": "app.py",
      "code": "def hello():\n    print('Hello')\n    password = 'secret123'",
      "type": "code",
      "processed": false
    },
    {
      "filename": "requirements.txt",
      "code": "flask==2.0.0\nrequests==2.28.0",
      "type": "dependency",
      "processed": false
    }
  ],
  "code_graph": {
    "tree_sitter": {
      "nodes": [...],
      "edges": [...]
    },
    "static_analysis": {
      "cfg": {...},
      "dfg": {...},
      "ir": {...}
    }
  },
  "commit_message_style": "conventional",
  "project_id": "uuid-opcional",
  "repo_id": "uuid-opcional"
}
```

**Campos:**

- **`files`** (array, requerido): Lista de archivos a analizar (mismo formato que `/review`)
  - `filename` (string): Nombre del archivo
  - `code` (string): Contenido del archivo
  - `type` (string): Tipo de archivo (`"code"`, `"dependency"`, `"iac"`)
  - `processed` (boolean): Si el archivo ya fue procesado (default: `false`)
- **`code_graph`** (object, opcional): Grafo de código generado por tree-sitter
  - `tree_sitter`: Nodos y edges del AST
  - `static_analysis`: Análisis estático (CFG, DFG, IR)
- **`commit_message_style`** (string, opcional): Estilo del mensaje
  - `"conventional"`: Formato Conventional Commits (default)
  - `"simple"`: Formato simple
- **`project_id`** (UUID, opcional): ID del proyecto para reglas personalizadas
- **`repo_id`** (UUID, opcional): ID del repositorio para reglas personalizadas

**Response (202 Accepted):**

```json
{
  "tasks": [
    {
      "filename": "app.py",
      "type": "code",
      "task_id": "abc-123-def-456",
      "user_id": "user-uuid",
      "related_files": null,
      "error": null
    },
    {
      "filename": "requirements.txt",
      "type": "dependency",
      "task_id": "xyz-789-ghi-012",
      "user_id": "user-uuid",
      "related_files": null,
      "error": null
    }
  ],
  "commit_review_id": "commit-review-uuid-12345"
}
```

**Campos de Response:**

- **`tasks`** (array): Lista de tareas creadas (igual que `/review`)
  - `task_id`: ID de la tarea Celery para consultar resultados
  - `filename`: Nombre del archivo
  - `type`: Tipo de archivo
  - `user_id`: ID del usuario
- **`commit_review_id`** (string): **ID único para consultar resultados completos** (incluye mensaje de commit)

**Errores:**

- `400 Bad Request`: Archivos inválidos o formato incorrecto
- `403 Forbidden`: Plan no permite generar mensajes de commit (requiere acceso a LLM)
- `429 Too Many Requests`: Límite de análisis alcanzado
- `500 Internal Server Error`: Error interno del servidor

---

### 2. Consultar Resultados

**Endpoint:** `GET /analisis/commit-review/{commit_review_id}/results`

**Autenticación:** API Key en header `X-API-Key`

**Path Parameters:**

- `commit_review_id` (string): ID retornado por `POST /commit-review`

**Response (200 OK):**

**Estado: `pending`** (aún procesando):

```json
{
  "status": "pending",
  "findings": null,
  "findings_summary": null,
  "commit_message": null,
  "commit_message_body": null,
  "files_analyzed": null,
  "analysis_time": null,
  "task_ids": null,
  "error": null
}
```

**Estado: `completed`** (procesamiento completo):

```json
{
  "status": "completed",
  "findings": [
    {
      "filename": "app.py",
      "issues": [
        {
          "issue": "Hardcoded password detected",
          "description": "A hardcoded password was found in the source code",
          "suggestion": "Use environment variables for sensitive data",
          "suggestion_code": "password = os.getenv('DB_PASSWORD')",
          "line": 15,
          "severity": "high",
          "category": "security",
          "confidence": 0.9
        }
      ]
    }
  ],
  "findings_summary": {
    "critical": 0,
    "high": 2,
    "medium": 3,
    "low": 1,
    "total": 6
  },
  "commit_message": "fix(security): remove hardcoded credentials",
  "commit_message_body": "Replace hardcoded password with environment variable\n\n- Remove hardcoded password in app.py:15\n- Add environment variable usage",
  "files_analyzed": ["app.py", "utils.py"],
  "analysis_time": 12.5,
  "task_ids": ["abc-123-def", "xyz-789-ghi"],
  "error": null
}
```

**Estado: `error`** (error durante procesamiento):

```json
{
  "status": "error",
  "findings": null,
  "findings_summary": null,
  "commit_message": null,
  "commit_message_body": null,
  "files_analyzed": null,
  "analysis_time": null,
  "task_ids": ["abc-123-def"],
  "error": "Error message describing what went wrong"
}
```

**Campos de Response:**

- **`status`** (string): Estado del procesamiento
  - `"pending"`: Aún procesando
  - `"completed"`: Procesamiento completo
  - `"error"`: Error durante procesamiento
- **`findings`** (array, cuando `status="completed"`): Hallazgos agrupados por archivo
  - `filename`: Nombre del archivo
  - `issues`: Lista de issues encontrados (mismo formato que `/review`)
- **`findings_summary`** (object, cuando `status="completed"`): Resumen de severidades
  - `critical`, `high`, `medium`, `low`: Cantidad por severidad
  - `total`: Total de issues
- **`commit_message`** (string, cuando `status="completed"`): **Mensaje de commit sugerido** (formato Conventional Commits o simple)
- **`commit_message_body`** (string, opcional): Cuerpo del mensaje de commit con detalles
- **`files_analyzed`** (array): Lista de archivos analizados
- **`analysis_time`** (float): Tiempo total de análisis en segundos
- **`task_ids`** (array): IDs de las tareas Celery ejecutadas
- **`error`** (string, cuando `status="error"`): Mensaje de error

**Errores:**

- `404 Not Found`: `commit_review_id` no encontrado o expirado (TTL: 1 hora)
- `503 Service Unavailable`: Redis no disponible
- `500 Internal Server Error`: Error interno del servidor

---

## Flujo de Trabajo

### Flujo Completo

```
1. Cliente → POST /commit-review
   └─ Envía archivos staged + grafos
   
2. Servidor → 202 Accepted
   └─ Retorna task_ids + commit_review_id
   └─ Encola tareas de análisis a Celery
   └─ Encola tarea de consolidación
   
3. [Procesamiento en background]
   └─ Celery analiza archivos (igual que /review)
   └─ Tarea de consolidación espera resultados
   └─ Genera mensaje de commit con LLM
   └─ Guarda resultados en Redis
   
4. Cliente → GET /commit-review/{commit_review_id}/results
   └─ Consulta resultados (puede hacer polling)
   
5. Servidor → 200 OK
   └─ Retorna "pending" si aún procesando
   └─ Retorna "completed" con resultados completos
```

### Ejemplo de Uso (JavaScript/TypeScript)

```javascript
// Paso 1: Iniciar análisis
const startCommitReview = async (files, codeGraph) => {
  const response = await fetch('https://api.hacki.ai/analisis/commit-review', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': 'your-api-key'
    },
    body: JSON.stringify({
      files: files,
      code_graph: codeGraph,
      commit_message_style: 'conventional'
    })
  });
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  const data = await response.json();
  return data.commit_review_id;
};

// Paso 2: Consultar resultados (con polling)
const getCommitReviewResults = async (commitReviewId, maxAttempts = 60) => {
  for (let i = 0; i < maxAttempts; i++) {
    const response = await fetch(
      `https://api.hacki.ai/analisis/commit-review/${commitReviewId}/results`,
      {
        headers: {
          'X-API-Key': 'your-api-key'
        }
      }
    );
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const results = await response.json();
    
    if (results.status === 'completed') {
      return results;
    } else if (results.status === 'error') {
      throw new Error(results.error);
    }
    
    // Esperar 2 segundos antes de volver a consultar
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
  
  throw new Error('Timeout esperando resultados');
};

// Uso completo
const analyzeCommit = async (stagedFiles, codeGraph) => {
  try {
    // Iniciar análisis
    const commitReviewId = await startCommitReview(stagedFiles, codeGraph);
    console.log(`Análisis iniciado: ${commitReviewId}`);
    
    // Consultar resultados (con polling)
    const results = await getCommitReviewResults(commitReviewId);
    
    // Usar resultados
    console.log('Mensaje de commit sugerido:', results.commit_message);
    console.log('Cuerpo:', results.commit_message_body);
    console.log('Hallazgos:', results.findings);
    console.log('Resumen:', results.findings_summary);
    
    // El CLI puede usar el mensaje para automatizar el commit
    return results;
  } catch (error) {
    console.error('Error en análisis de commit:', error);
    throw error;
  }
};
```

### Ejemplo de Uso (Python)

```python
import requests
import time

def start_commit_review(files, code_graph=None, api_key=None):
    """Inicia análisis de commit y retorna commit_review_id."""
    url = "https://api.hacki.ai/analisis/commit-review"
    headers = {
        "Content-Type": "application/json",
        "X-API-Key": api_key
    }
    payload = {
        "files": files,
        "code_graph": code_graph,
        "commit_message_style": "conventional"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    response.raise_for_status()
    
    data = response.json()
    return data["commit_review_id"]


def get_commit_review_results(commit_review_id, api_key=None, max_attempts=60):
    """Consulta resultados con polling."""
    url = f"https://api.hacki.ai/analisis/commit-review/{commit_review_id}/results"
    headers = {"X-API-Key": api_key}
    
    for attempt in range(max_attempts):
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        
        results = response.json()
        
        if results["status"] == "completed":
            return results
        elif results["status"] == "error":
            raise Exception(results["error"])
        
        # Esperar 2 segundos antes de volver a consultar
        time.sleep(2)
    
    raise TimeoutError("Timeout esperando resultados")


# Uso completo
def analyze_commit(staged_files, code_graph=None, api_key=None):
    """Analiza archivos staged y genera mensaje de commit."""
    # Iniciar análisis
    commit_review_id = start_commit_review(staged_files, code_graph, api_key)
    print(f"Análisis iniciado: {commit_review_id}")
    
    # Consultar resultados
    results = get_commit_review_results(commit_review_id, api_key)
    
    # Usar resultados
    print(f"Mensaje de commit: {results['commit_message']}")
    print(f"Cuerpo: {results['commit_message_body']}")
    print(f"Hallazgos: {len(results['findings'])} archivos")
    print(f"Resumen: {results['findings_summary']}")
    
    return results
```

---

## Comparación con `/review`

### Similitudes

- ✅ Mismo formato de `files` (array de `FileData`)
- ✅ Mismo formato de `code_graph` (opcional)
- ✅ Misma detección de tipos de archivo (dependency, iac, code)
- ✅ Mismo encolado de tareas Celery
- ✅ Mismo formato de `findings` en resultados
- ✅ Misma validación de acceso y archivos

### Diferencias

| Característica | `/review` | `/commit-review` |
|---------------|-----------|------------------|
| **Response inicial** | Solo `tasks` | `tasks` + `commit_review_id` |
| **Mensaje de commit** | ❌ No incluye | ✅ Generado con LLM |
| **Consulta resultados** | ❌ No hay endpoint | ✅ `GET /commit-review/{id}/results` |
| **Requisito LLM** | ❌ Opcional (puede usar análisis estático) | ✅ Requerido (para generar mensaje) |
| **Almacenamiento** | ❌ No guarda resultados | ✅ Guarda en Redis (TTL: 1 hora) |

---

## Detección de Archivos

El endpoint usa la misma lógica que `/review` para detectar tipos de archivo:

### Archivos de Dependencias

Se detectan automáticamente por nombre:
- `package.json`, `package-lock.json`, `yarn.lock`
- `requirements.txt`, `Pipfile`, `pyproject.toml`
- `pom.xml`, `go.mod`, `Gemfile`, `composer.json`
- `cargo.toml`, `mix.exs`

**Procesamiento:** Se agrupan archivos relacionados (manifest + lock files) y se analizan juntos con Trivy.

### Archivos de Infraestructura (IaC)

Se detectan por extensión o nombre:
- `.tf`, `.tfvars` (Terraform)
- `Dockerfile`, `docker-compose.yml`
- Archivos YAML en directorios `k8s/`, `helm/`, `.github/workflows/`

**Procesamiento:** Se analizan con Trivy para detectar vulnerabilidades de configuración.

### Archivos de Código

Cualquier otro archivo se trata como código:
- `.py`, `.js`, `.java`, `.go`, `.rb`, `.php`, `.cs`, etc.

**Procesamiento:** Se analizan con LLM (o análisis estático si no hay acceso a LLM).

---

## Mensaje de Commit

### Generación con LLM

El mensaje de commit se genera usando Groq LLM basado en:
- Archivos modificados
- Hallazgos encontrados (issues críticos/altos tienen prioridad)
- Resumen de severidades

### Formato Conventional Commits

**Ejemplos:**

```
fix(security): remove hardcoded credentials
feat(auth): add user authentication
refactor(api): improve error handling
chore: update dependencies
```

**Estructura:**
- `<type>(<scope>): <description>`
- Tipos comunes: `feat`, `fix`, `refactor`, `chore`, `test`, `docs`
- Scope opcional: `auth`, `api`, `db`, `test`, etc.

### Formato Simple

**Ejemplos:**

```
Fix security issues
Add new features
Refactor code
Update files
```

---

## Manejo de Errores

### Errores Comunes

1. **`403 Forbidden: El plan actual no permite generar mensajes de commit`**
   - **Causa:** Plan sin acceso a LLM
   - **Solución:** Usar `/review` o actualizar plan

2. **`404 Not Found` en `/results`**
   - **Causa:** `commit_review_id` no existe o expiró (TTL: 1 hora)
   - **Solución:** Iniciar nuevo análisis

3. **`503 Service Unavailable: Redis no disponible`**
   - **Causa:** Redis no está disponible
   - **Solución:** Reintentar más tarde

4. **`status: "error"` en resultados**
   - **Causa:** Error durante procesamiento
   - **Solución:** Revisar `error` field y reintentar

### Estrategia de Polling

**Recomendaciones:**

- **Intervalo inicial:** 2 segundos
- **Máximo de intentos:** 60 (2 minutos total)
- **Backoff exponencial:** Opcional, aumentar intervalo después de 10 intentos
- **Timeout total:** 5 minutos (300 segundos es el timeout del servidor)

**Ejemplo con backoff:**

```javascript
const pollResults = async (commitReviewId, maxAttempts = 60) => {
  let attempt = 0;
  let delay = 2000; // 2 segundos inicial
  
  while (attempt < maxAttempts) {
    const results = await getResults(commitReviewId);
    
    if (results.status === 'completed') return results;
    if (results.status === 'error') throw new Error(results.error);
    
    attempt++;
    
    // Backoff exponencial después de 10 intentos
    if (attempt > 10) {
      delay = Math.min(delay * 1.5, 10000); // Máximo 10 segundos
    }
    
    await sleep(delay);
  }
  
  throw new Error('Timeout esperando resultados');
};
```

---

## Límites y Consideraciones

### Límites

- **Archivos por request:** Máximo 10 archivos (igual que `/review`)
- **Tamaño de archivo:** Sin límite específico (pero archivos muy grandes pueden tardar más)
- **TTL de resultados:** 1 hora en Redis
- **Timeout de procesamiento:** 300 segundos (5 minutos)

### Consideraciones

1. **Requisito de LLM:** Este endpoint requiere acceso a LLM (no funciona con plan Free que solo tiene análisis estático)
2. **Costo:** Generar mensaje de commit consume tokens de LLM
3. **Polling:** El cliente debe implementar polling para consultar resultados
4. **Grafos:** Los grafos son opcionales pero mejoran la calidad del análisis

---

## Ejemplo Completo de Integración

```javascript
// CLI Command: hacki commit
async function commitCommand(stagedFiles, options) {
  const apiKey = getApiKey();
  
  // 1. Preparar archivos y grafos
  const files = stagedFiles.map(file => ({
    filename: file.path,
    code: file.content,
    type: detectFileType(file.path),
    processed: false
  }));
  
  const codeGraph = await buildCodeGraph(stagedFiles);
  
  // 2. Iniciar análisis
  console.log('📋 Analizando archivos staged...');
  const commitReviewId = await startCommitReview(files, codeGraph, apiKey);
  
  // 3. Mostrar progreso y consultar resultados
  console.log('🔍 Analizando código...');
  const results = await pollResults(commitReviewId, apiKey);
  
  // 4. Mostrar hallazgos
  console.log('\n📊 Hallazgos encontrados:');
  console.log(`   - Críticos: ${results.findings_summary.critical}`);
  console.log(`   - Altos: ${results.findings_summary.high}`);
  console.log(`   - Medios: ${results.findings_summary.medium}`);
  console.log(`   - Bajos: ${results.findings_summary.low}`);
  
  // 5. Mostrar mensaje de commit sugerido
  console.log('\n💬 Mensaje de commit sugerido:');
  console.log(`   ${results.commit_message}`);
  if (results.commit_message_body) {
    console.log(`\n   ${results.commit_message_body.replace(/\n/g, '\n   ')}`);
  }
  
  // 6. Preguntar al usuario si quiere usar el mensaje
  const useMessage = await promptUser('¿Usar este mensaje de commit? (y/n)');
  
  if (useMessage) {
    // 7. Crear commit con el mensaje sugerido
    await createGitCommit(results.commit_message, results.commit_message_body);
    console.log('✅ Commit creado exitosamente');
  } else {
    console.log('ℹ️  Commit cancelado por el usuario');
  }
}
```

---

## Notas Adicionales

1. **Compatibilidad:** El endpoint es compatible con el formato de `/review`, por lo que puedes reutilizar la lógica de preparación de archivos
2. **Grafos:** Los grafos mejoran significativamente la calidad del análisis, especialmente para detectar problemas cross-file
3. **Mensaje de commit:** El mensaje se genera basado en los hallazgos, por lo que es más preciso que un mensaje genérico
4. **Performance:** El procesamiento es asíncrono, por lo que el endpoint responde rápidamente y el cliente puede hacer otras cosas mientras espera

---

## Soporte

Para preguntas o problemas, contactar al equipo de backend o revisar los logs del servidor.

