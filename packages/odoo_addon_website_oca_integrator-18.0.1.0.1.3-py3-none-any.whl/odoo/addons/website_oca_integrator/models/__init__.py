from . import contributor_module_line
from . import odoo_author
from . import res_partner
from . import sponsorship
