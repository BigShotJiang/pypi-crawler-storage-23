This module adds menu "Integrators" in website, which displays
integrators, contributors, members and modules related information.
