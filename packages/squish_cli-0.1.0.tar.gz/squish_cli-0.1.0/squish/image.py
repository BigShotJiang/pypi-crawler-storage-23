from pathlib import Path
from typing import Optional
from PIL import Image

from squish.utils import parse_resolution, parse_percentage_resolution


# Map output format strings to Pillow format names
FORMAT_MAP = {
    "jpg": "JPEG",
    "jpeg": "JPEG",
    "png": "PNG",
    "webp": "WEBP",
    "bmp": "BMP",
    "tiff": "TIFF",
}


def compress_image(
    input_path: Path,
    output_path: Path,
    quality: int = 80,
    resolution: Optional[str] = None,
    out_format: Optional[str] = None,
) -> Path:
    """
    Compress an image file.

    Args:
        input_path: Source image path
        output_path: Destination path
        quality: Compression quality (1-100)
        resolution: Target resolution ("1920x1080" or "50%")
        out_format: Output format (jpg, png, webp, etc.)

    Returns:
        Path to compressed file
    """
    img = Image.open(input_path)

    # Convert RGBA to RGB for formats that don't support alpha
    target_format = _resolve_format(out_format, output_path)
    if target_format == "JPEG" and img.mode in ("RGBA", "LA", "P"):
        img = img.convert("RGB")

    # Resize if resolution specified
    if resolution:
        img = _resize_image(img, resolution)

    # Save with compression
    save_kwargs = _get_save_kwargs(target_format, quality)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    img.save(output_path, format=target_format, **save_kwargs)

    return output_path


def _resize_image(img: Image.Image, resolution: str) -> Image.Image:
    """Resize image based on resolution string."""

    # Check for percentage
    pct = parse_percentage_resolution(resolution)
    if pct is not None:
        new_width = int(img.width * pct)
        new_height = int(img.height * pct)
        return img.resize((new_width, new_height), Image.LANCZOS)

    # Absolute resolution
    target_w, target_h = parse_resolution(resolution)

    # Maintain aspect ratio - fit within target dimensions
    img.thumbnail((target_w, target_h), Image.LANCZOS)
    return img


def _resolve_format(out_format: Optional[str], output_path: Path) -> str:
    """Resolve the Pillow format string."""
    if out_format:
        fmt = FORMAT_MAP.get(out_format.lower())
        if fmt:
            return fmt
        raise ValueError(f"Unsupported image format: {out_format}")

    # Infer from output extension
    ext = output_path.suffix.lower().lstrip(".")
    fmt = FORMAT_MAP.get(ext)
    if fmt:
        return fmt

    return "JPEG"  # default


def _get_save_kwargs(format: str, quality: int) -> dict:
    """Get format-specific save parameters."""
    kwargs = {}

    if format == "JPEG":
        kwargs["quality"] = quality
        kwargs["optimize"] = True
        # Progressive JPEG for better perceived loading
        if quality < 95:
            kwargs["progressive"] = True

    elif format == "PNG":
        # PNG quality maps to compress_level (0-9, inverse of quality)
        compress_level = max(0, min(9, int((100 - quality) / 11)))
        kwargs["compress_level"] = compress_level
        kwargs["optimize"] = True

    elif format == "WEBP":
        kwargs["quality"] = quality
        kwargs["method"] = 4  # compression effort (0=fast, 6=slow)
        if quality >= 100:
            kwargs["lossless"] = True

    return kwargs
