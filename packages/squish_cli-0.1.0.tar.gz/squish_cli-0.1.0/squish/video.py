import json
import subprocess
import shutil
from pathlib import Path
from typing import Optional

from squish.utils import parse_resolution, parse_percentage_resolution


# CRF mapping: quality% → CRF value (lower CRF = higher quality)
# CRF range for h264: 0 (lossless) to 51 (worst)
# Good range: 18 (visually lossless) to 28 (decent quality)
def _quality_to_crf(quality: int) -> int:
    """Map quality percentage (1-100) to FFmpeg CRF value."""
    # quality 100 → CRF 15 (near lossless)
    # quality 80  → CRF 23 (default, good quality)
    # quality 50  → CRF 30 (medium)
    # quality 1   → CRF 40 (low quality)
    return int(40 - (quality / 100) * 25)


FORMAT_CODECS = {
    "mp4": {"vcodec": "libx264", "acodec": "aac"},
    "webm": {"vcodec": "libvpx-vp9", "acodec": "libopus"},
    "mkv": {"vcodec": "libx264", "acodec": "aac"},
    "mov": {"vcodec": "libx264", "acodec": "aac"},
}


def _check_ffmpeg():
    """Verify FFmpeg is installed."""
    if shutil.which("ffmpeg") is None:
        raise RuntimeError(
            "FFmpeg not found. Install it:\n"
            "  macOS:  brew install ffmpeg\n"
            "  Ubuntu: sudo apt install ffmpeg\n"
            "  Windows: https://ffmpeg.org/download.html"
        )


def compress_video(
    input_path: Path,
    output_path: Path,
    quality: int = 80,
    resolution: Optional[str] = None,
    out_format: Optional[str] = None,
) -> Path:
    """
    Compress a video file using FFmpeg.

    Args:
        input_path: Source video path
        output_path: Destination path
        quality: Compression quality (1-100)
        resolution: Target resolution ("1920x1080" or "50%")
        out_format: Output format (mp4, webm, etc.)

    Returns:
        Path to compressed file
    """
    _check_ffmpeg()

    target_format = out_format or output_path.suffix.lstrip(".").lower() or "mp4"
    codecs = FORMAT_CODECS.get(target_format, FORMAT_CODECS["mp4"])

    crf = _quality_to_crf(quality)

    cmd = [
        "ffmpeg",
        "-i", str(input_path),
        "-c:v", codecs["vcodec"],
        "-crf", str(crf),
        "-preset", "medium",
        "-c:a", codecs["acodec"],
        "-b:a", "128k",
    ]

    # Resolution handling
    if resolution:
        scale_filter = _build_scale_filter(resolution)
        cmd.extend(["-vf", scale_filter])

    # Format-specific options
    if target_format == "mp4":
        cmd.extend(["-movflags", "+faststart"])  # web-optimized
    elif target_format == "webm":
        cmd.extend(["-b:v", "0"])  # required for CRF mode in VP9

    cmd.extend([
        "-y",  # overwrite
        str(output_path),
    ])

    output_path.parent.mkdir(parents=True, exist_ok=True)

    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        error_msg = result.stderr.strip().split("\n")[-1] if result.stderr else "Unknown error"
        raise RuntimeError(f"FFmpeg failed: {error_msg}")

    return output_path


def _build_scale_filter(resolution: str) -> str:
    """Build FFmpeg scale filter string."""

    # Percentage scaling
    pct = parse_percentage_resolution(resolution)
    if pct is not None:
        return f"scale=iw*{pct}:ih*{pct}"

    # Absolute resolution - maintain aspect ratio
    w, h = parse_resolution(resolution)
    # -2 ensures dimensions are divisible by 2 (required by most codecs)
    return f"scale={w}:{h}:force_original_aspect_ratio=decrease,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2"


def get_video_info(input_path: Path) -> Optional[dict]:
    """Get video file metadata using ffprobe."""
    if shutil.which("ffprobe") is None:
        return None

    cmd = [
        "ffprobe",
        "-v", "quiet",
        "-print_format", "json",
        "-show_format",
        "-show_streams",
        str(input_path),
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            return None

        data = json.loads(result.stdout)

        # Find video stream
        video_stream = None
        for stream in data.get("streams", []):
            if stream.get("codec_type") == "video":
                video_stream = stream
                break

        if not video_stream:
            return None

        format_info = data.get("format", {})

        return {
            "width": video_stream.get("width"),
            "height": video_stream.get("height"),
            "codec": video_stream.get("codec_name"),
            "duration": round(float(format_info.get("duration", 0)), 2),
            "bitrate": format_info.get("bit_rate", "unknown"),
            "fps": _parse_fps(video_stream.get("r_frame_rate", "0/1")),
        }
    except Exception:
        return None


def _parse_fps(fps_str: str) -> float:
    """Parse FFmpeg fps fraction string like '30/1'."""
    try:
        num, den = fps_str.split("/")
        return round(int(num) / int(den), 2)
    except (ValueError, ZeroDivisionError):
        return 0.0
