import typer
from rich.console import Console
from pathlib import Path
from typing import Optional

from squish.image import compress_image
from squish.video import compress_video
from squish.utils import get_file_type, format_size, get_compression_summary

app = typer.Typer(
    name="squish",
    help="🗜️  Fast image & video compression CLI tool",
    add_completion=False,
)
console = Console()


@app.command()
def compress(
    input_path: Path = typer.Argument(..., help="Path to file or directory"),
    output: Optional[Path] = typer.Option(None, "-o", "--output", help="Output path (default: <name>_compressed.<ext>)"),
    quality: int = typer.Option(80, "-q", "--quality", min=1, max=100, help="Quality percentage (1-100)"),
    resolution: Optional[str] = typer.Option(None, "-r", "--resolution", help="Target resolution (e.g. 1920x1080, 1280x720, 50%%)"),
    format: Optional[str] = typer.Option(None, "-f", "--format", help="Output format (jpg, png, webp, mp4, webm)"),
    preset: Optional[str] = typer.Option(None, "-p", "--preset", help="Preset: web, mobile, thumbnail, social"),
    overwrite: bool = typer.Option(False, "--overwrite", help="Overwrite output file if it exists"),
):
    """
    Compress an image or video file.

    Examples:
        squish photo.jpg -q 60
        squish video.mp4 -q 70 -r 1280x720
        squish photo.png -f webp -q 80
        squish ./photos/ -q 60 -f webp
    """

    if not input_path.exists():
        console.print(f"[red]Error:[/red] '{input_path}' not found")
        raise typer.Exit(1)

    # Handle directory (batch mode)
    if input_path.is_dir():
        _compress_directory(input_path, output, quality, resolution, format, preset, overwrite)
        return

    # Single file
    _compress_file(input_path, output, quality, resolution, format, preset, overwrite)


def _compress_file(
    input_path: Path,
    output: Optional[Path],
    quality: int,
    resolution: Optional[str],
    format: Optional[str],
    preset: Optional[str],
    overwrite: bool,
):
    file_type = get_file_type(input_path)

    if file_type is None:
        console.print(f"[red]Error:[/red] Unsupported file type: {input_path.suffix}")
        raise typer.Exit(1)

    # Apply preset overrides
    if preset:
        quality, resolution = _apply_preset(preset, file_type, quality, resolution)

    # Determine output path
    if output is None:
        ext = f".{format}" if format else input_path.suffix
        output = input_path.parent / f"{input_path.stem}_compressed{ext}"

    if output.exists() and not overwrite:
        console.print(f"[yellow]Warning:[/yellow] '{output}' already exists. Use --overwrite to replace.")
        raise typer.Exit(1)

    original_size = input_path.stat().st_size

    console.print(f"\n[bold]🗜️  Compressing:[/bold] {input_path.name}")
    console.print(f"   Type: {file_type} | Quality: {quality}% | Resolution: {resolution or 'original'}")

    try:
        if file_type == "image":
            compress_image(input_path, output, quality=quality, resolution=resolution, out_format=format)
        elif file_type == "video":
            compress_video(input_path, output, quality=quality, resolution=resolution, out_format=format)

        compressed_size = output.stat().st_size
        summary = get_compression_summary(original_size, compressed_size)

        console.print(f"\n   [green]✓ Done:[/green] {output.name}")
        console.print(f"   {format_size(original_size)} → {format_size(compressed_size)} ({summary})")
        console.print()

    except Exception as e:
        console.print(f"\n   [red]✗ Failed:[/red] {e}")
        raise typer.Exit(1)


def _compress_directory(
    dir_path: Path,
    output: Optional[Path],
    quality: int,
    resolution: Optional[str],
    format: Optional[str],
    preset: Optional[str],
    overwrite: bool,
):
    from squish.utils import SUPPORTED_EXTENSIONS

    files = [f for f in dir_path.iterdir() if f.suffix.lower() in SUPPORTED_EXTENSIONS]

    if not files:
        console.print(f"[yellow]No supported files found in {dir_path}[/yellow]")
        raise typer.Exit(0)

    output_dir = output or dir_path / "compressed"
    output_dir.mkdir(parents=True, exist_ok=True)

    console.print(f"\n[bold]🗜️  Batch compressing {len(files)} files[/bold]")
    console.print(f"   Output: {output_dir}\n")

    total_original = 0
    total_compressed = 0
    success = 0
    failed = 0

    for file in files:
        try:
            ext = f".{format}" if format else file.suffix
            out_path = output_dir / f"{file.stem}{ext}"

            file_type = get_file_type(file)
            q, r = (quality, resolution)
            if preset:
                q, r = _apply_preset(preset, file_type, quality, resolution)

            original_size = file.stat().st_size

            if file_type == "image":
                compress_image(file, out_path, quality=q, resolution=r, out_format=format)
            elif file_type == "video":
                compress_video(file, out_path, quality=q, resolution=r, out_format=format)

            compressed_size = out_path.stat().st_size
            total_original += original_size
            total_compressed += compressed_size
            success += 1

            summary = get_compression_summary(original_size, compressed_size)
            console.print(f"   [green]✓[/green] {file.name} → {format_size(compressed_size)} ({summary})")

        except Exception as e:
            failed += 1
            console.print(f"   [red]✗[/red] {file.name}: {e}")

    console.print(f"\n[bold]Summary:[/bold] {success} compressed, {failed} failed")
    if total_original > 0:
        console.print(f"   Total: {format_size(total_original)} → {format_size(total_compressed)} ({get_compression_summary(total_original, total_compressed)})")
    console.print()


def _apply_preset(preset: str, file_type: str, quality: int, resolution: Optional[str]):
    """Apply preset configurations."""
    presets = {
        "web": {"image": (80, "1920x1080"), "video": (75, "1920x1080")},
        "mobile": {"image": (70, "1080x1080"), "video": (65, "720x1280")},
        "thumbnail": {"image": (60, "400x400"), "video": (50, "480x360")},
        "social": {"image": (85, "1080x1080"), "video": (70, "1080x1920")},
    }

    if preset not in presets:
        console.print(f"[yellow]Unknown preset '{preset}'. Using defaults.[/yellow]")
        return quality, resolution

    p = presets[preset].get(file_type, {})
    if isinstance(p, tuple):
        return p[0], resolution or p[1]

    return quality, resolution


@app.command()
def info(
    input_path: Path = typer.Argument(..., help="Path to file"),
):
    """Show file info (dimensions, size, codec, duration)."""
    if not input_path.exists():
        console.print(f"[red]Error:[/red] '{input_path}' not found")
        raise typer.Exit(1)

    file_type = get_file_type(input_path)
    size = input_path.stat().st_size

    console.print(f"\n[bold]📄 File Info:[/bold] {input_path.name}")
    console.print(f"   Size: {format_size(size)}")
    console.print(f"   Type: {file_type or 'unknown'}")

    if file_type == "image":
        from PIL import Image
        with Image.open(input_path) as img:
            console.print(f"   Dimensions: {img.width}x{img.height}")
            console.print(f"   Format: {img.format}")
            console.print(f"   Mode: {img.mode}")

    elif file_type == "video":
        from squish.video import get_video_info
        info = get_video_info(input_path)
        if info:
            console.print(f"   Dimensions: {info.get('width', '?')}x{info.get('height', '?')}")
            console.print(f"   Duration: {info.get('duration', '?')}s")
            console.print(f"   Codec: {info.get('codec', '?')}")
            console.print(f"   Bitrate: {info.get('bitrate', '?')}")

    console.print()


if __name__ == "__main__":
    app()
