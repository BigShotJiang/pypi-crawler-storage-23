from pathlib import Path
from typing import Optional

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tiff", ".tif"}
VIDEO_EXTENSIONS = {".mp4", ".mov", ".avi", ".mkv", ".webm", ".flv", ".wmv", ".m4v"}
SUPPORTED_EXTENSIONS = IMAGE_EXTENSIONS | VIDEO_EXTENSIONS


def get_file_type(path: Path) -> Optional[str]:
    """Detect if file is image or video based on extension."""
    ext = path.suffix.lower()
    if ext in IMAGE_EXTENSIONS:
        return "image"
    if ext in VIDEO_EXTENSIONS:
        return "video"
    return None


def format_size(size_bytes: int) -> str:
    """Format bytes into human readable size."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"


def get_compression_summary(original: int, compressed: int) -> str:
    """Get a human readable compression summary."""
    if original == 0:
        return "N/A"

    ratio = (1 - compressed / original) * 100

    if ratio > 0:
        return f"[green]-{ratio:.1f}%[/green]"
    elif ratio < 0:
        return f"[red]+{abs(ratio):.1f}%[/red]"
    else:
        return "no change"


def parse_resolution(resolution: str) -> tuple[int, int]:
    """
    Parse resolution string into (width, height).

    Supports:
        - "1920x1080" → (1920, 1080)
        - "1280x720"  → (1280, 720)
        - "50%"       → handled separately in callers
    """
    if "x" in resolution.lower():
        parts = resolution.lower().split("x")
        return int(parts[0]), int(parts[1])

    raise ValueError(f"Invalid resolution format: '{resolution}'. Use WIDTHxHEIGHT (e.g. 1920x1080) or PERCENT% (e.g. 50%)")


def parse_percentage_resolution(resolution: str) -> Optional[float]:
    """Parse percentage resolution like '50%' → 0.5"""
    if resolution.endswith("%"):
        return float(resolution[:-1]) / 100.0
    return None
