# 🗜️ squish

Fast image & video compression CLI tool.

## Install

```bash
pip install -e .
```

> **Requires FFmpeg** for video compression: `brew install ffmpeg` / `sudo apt install ffmpeg`

## Usage

### Compress an image

```bash
squish compress photo.jpg -q 60
squish compress photo.png -f webp -q 80
squish compress photo.jpg -r 1920x1080 -q 70
squish compress photo.jpg -r 50%
```

### Compress a video

```bash
squish compress video.mp4 -q 70
squish compress video.mp4 -r 1280x720 -q 60
squish compress video.mov -f mp4 -q 75
```

### Batch compress a directory

```bash
squish compress ./photos/ -q 60 -f webp
squish compress ./videos/ -q 70 -r 1280x720
```

### Presets

```bash
squish compress photo.jpg -p web        # 1920x1080, q80
squish compress video.mp4 -p mobile     # 720x1280, q65
squish compress photo.jpg -p thumbnail  # 400x400, q60
squish compress video.mp4 -p social     # 1080x1920, q70
```

### File info

```bash
squish info photo.jpg
squish info video.mp4
```

## Options

| Flag | Short | Description |
|------|-------|-------------|
| `--quality` | `-q` | Quality 1-100 (default: 80) |
| `--resolution` | `-r` | Target resolution: `1920x1080` or `50%` |
| `--format` | `-f` | Output format: jpg, png, webp, mp4, webm |
| `--preset` | `-p` | Preset: web, mobile, thumbnail, social |
| `--output` | `-o` | Custom output path |
| `--overwrite` | | Overwrite existing files |

## How quality maps to compression

### Images
- **90-100**: Near lossless, minimal size reduction
- **70-89**: Good quality, noticeable size reduction
- **40-69**: Decent quality, significant compression
- **1-39**: Low quality, maximum compression

### Videos (CRF mapping)
- **quality 100** → CRF 15 (near lossless)
- **quality 80** → CRF 23 (good quality)
- **quality 50** → CRF 30 (medium)
- **quality 1** → CRF 40 (low quality, small file)
