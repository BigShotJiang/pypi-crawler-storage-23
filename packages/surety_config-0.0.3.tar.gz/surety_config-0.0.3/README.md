# Surety Config

Configuration layer for the Surety ecosystem.

`surety-config` provides structured configuration management
for contract-driven service testing using Surety.

---

## Installation

```bash
pip install surety-config
