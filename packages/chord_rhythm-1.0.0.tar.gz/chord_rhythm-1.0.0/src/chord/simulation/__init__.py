"""Simulation utilities for generating synthetic rhythmic signals."""
