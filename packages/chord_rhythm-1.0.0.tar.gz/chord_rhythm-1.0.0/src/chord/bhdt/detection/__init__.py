"""Detection stage modules for CHORD."""
