"""Analysis utilities for post-hoc rhythm characterisation."""
