"""Benchmarks for evaluating rhythm detection methods."""
