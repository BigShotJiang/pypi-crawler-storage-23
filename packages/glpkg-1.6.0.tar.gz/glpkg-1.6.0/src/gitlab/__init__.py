"""GitLab packages initialization module"""

from gitlab.packages import Packages

__version__ = "1.6.0"
