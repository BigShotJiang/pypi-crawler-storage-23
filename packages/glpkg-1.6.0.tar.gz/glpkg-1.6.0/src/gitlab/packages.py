"""GitLab generic packages module"""

from glob import glob
import logging
import os
from urllib import parse
from gitlab.lib.gitlab_api import GitLabAPI

logger = logging.getLogger(__name__)


class Packages:
    """Class to interact with GitLab packages REST API"""

    def __init__(self, host: str, token_type: str, token: str):
        """
        Creates a new instance of class.

        Parameters
        ----------
        host : str
            The GitLab instance hostname, without schema.
            The host will be used for the package API interaction.
            For example gitlab.com.
        token_type : str
            The token type or "user" to authenticate with GitLab REST API.
            For personal, project, and group tokens this is `PRIVATE-TOKEN`.
            For `CI_JOB_TOKEN` this is `JOB-TOKEN`.
            Can be left empty when authentication is not used.
        token : str
            The token (secret) to authenticate with GitLab REST API.
            This can be a personal token, project token, or`CI_JOB_TOKEN`.
            Leave empty when authentication is not used.
        """
        self.gl_api = GitLabAPI(host, token_type, token)

    def get_versions(self, project_id: str, package_name: str) -> list:
        """
        Lists the available versions of the package

        Parameters
        ----------
        project_id : str
            The project ID or path, including namespace.
            Examples: `123` or `namespace/project`.
        package_name : str
            The name of the package that is listed.

        Returns
        -------
        list
            List of {package: name, version: version} that are available.
        """
        packages = []
        logger.debug("Listing packages with name %s", package_name)
        data = self.gl_api.get_all(
            "projects",
            parse.quote_plus(project_id),
            "packages",
            package_name=package_name,
            package_type="generic",
        )
        for package in data:
            name = parse.unquote(package["name"])
            version = parse.unquote(package["version"])
            # GitLab API returns packages that have some match to the filter;
            # let's filter out non-exact matches
            if package_name != name:
                continue
            packages.append({"name": name, "version": version})
        return packages

    def get_files(self, project_id: str, package_id: int) -> dict:
        """
        Lists all files of a specific package ID from GitLab REST API

        Parameters
        ----------
        project_id : str
            The project ID or path, including namespace.
            Examples: `123` or `namespace/project`.
        package_id : int
            The package ID that is listed

        Return
        ------
        dict
            Dictionary of file (names) that are in the package, with
            each element containing a dictionary containing information
            of the file
        """
        files = {}
        logger.debug("Listing package %d files", package_id)
        data = self.gl_api.get_all(
            "projects",
            parse.quote_plus(project_id),
            "packages",
            str(package_id),
            "package_files",
        )
        for package in data:
            # Only append the filename once to the list of files
            # as there's no way to download them separately through
            # the API
            filename = parse.unquote(package["file_name"])
            file_id = package["id"]
            if not files.get(filename):
                files[filename] = {"id": file_id}
        return files

    def get_id(self, project_id: str, package_name: str, package_version: str) -> int:
        """
        Gets the package ID of a specific package version.

        Parameters
        ----------
        project_id : str
            The project ID or path, including namespace.
            Examples: `123` or `namespace/project`.
        package_name : str
            The name of the package.
        package_version : str
            The version of the package

        Return
        ------
        int
            The ID of the package. -1 if no ID was found.
        """
        package_id = -1
        logger.debug("Fetching package %s (%s) ID", package_name, package_version)
        data = self.gl_api.get_all(
            "projects",
            parse.quote_plus(project_id),
            "packages",
            package_name=package_name,
            package_version=package_version,
            package_type="generic",
        )
        if len(data) == 1:
            package = data.pop()
            package_id = package["id"]
        return package_id

    def download(
        self,
        project_id: str,
        package_name: str,
        package_version: str,
        destination: str,
        force: bool,
    ) -> int:
        """
        Downloads a package from a GitLab generic package registry

        Parameters
        ----------
        project_id : str
            The project ID or path, including namespace.
            Examples: `123` or `namespace/project`.
        package_name : str
            The name of the generic package.
        package_version : str
            The version of the generic package
        destination : str
            The destination folder of the downloaded file. If not set,
            current working directory is used.
        force : bool
            Whether to force download of the files, in case local filesystem
            already contains any of the downloaded files.

        Return
        ------
        int
            Zero if everything went fine, non-zero coke otherwise.
            Two in case package was not found.
        """
        ret = 2
        package_id = self.get_id(project_id, package_name, package_version)
        if package_id:
            files = self.get_files(project_id, package_id).keys()
            abort = False
            if not force:
                # When force is not used, let's find out if local file system
                # already contains the downloaded files
                for filename in files:
                    fpath = os.path.join(destination, filename)
                    if os.path.isfile(fpath):
                        logger.debug(
                            "File %s exists already in the local file system", fpath
                        )
                        abort = True
                        break
            if not abort:
                # Since we are here, no conflicts with files were found or the force
                # option was enabled. Do not double check the file existence for
                # per-file downloads as they were checked above. May the force be with you.
                force = True
                for file in files:
                    ret = self.download_file(
                        project_id,
                        package_name,
                        package_version,
                        file,
                        destination,
                        force,
                    )
                    if ret:
                        break
            else:
                ret = 3
                logger.debug("Aborting download of files")
        return ret

    def download_file(
        self,
        project_id: str,
        package_name: str,
        package_version: str,
        filename: str,
        destination: str,
        force: bool,
    ) -> int:
        """
        Downloads a file from a GitLab generic package

        Parameters
        ----------
        project_id : str
            The project ID or path, including namespace.
            Examples: `123` or `namespace/project`.
        package_name : str
            The name of the generic package.
        package_version : str
            The version of the generic package
        filename : str
            The file that is downloaded
        destination : str
            The destination folder of the downloaded file. If not set,
            current working directory is used.
        force : bool
            Whether to force download of the file, in case local filesystem
            already contains the file.

        Return
        ------
        int
            Zero if everything went fine, non-zero coke otherwise.
        """
        ret = 1
        abort = False
        logger.debug("Downloading file %s", filename)
        if not force:
            # When force is not used, let's find out if local file system
            # already contains the downloaded files
            fpath = os.path.join(destination, filename)
            if os.path.isfile(fpath):
                logger.debug("File %s exists already in the local file system", fpath)
                abort = True
        if not abort:
            status, data, _ = self.gl_api.get(
                "projects",
                parse.quote_plus(project_id),
                "packages",
                "generic",
                parse.quote_plus(package_name),
                parse.quote_plus(package_version),
                parse.quote(filename),
            )
            if status == 200:
                fpath = os.path.join(destination, filename)
                parent = os.path.dirname(fpath)
                if parent:
                    # Create missing directories if needed
                    # In case path has no parent, current
                    # workind directory is used
                    os.makedirs(os.path.dirname(fpath), exist_ok=True)
                with open(fpath, "wb") as file:
                    file.write(data)
                    ret = 0
        else:
            ret = 3
            logger.debug("Aborting download of file")
        return ret

    def upload(
        self,
        project_id: str,
        package_name: str,
        package_version: str,
        source: str,
        force: bool,
    ) -> int:
        """
        Uploads file(s) to a GitLab generic package.

        Parameters
        ----------
        project_id : str
            The project ID or path, including namespace.
            Examples: `123` or `namespace/project`.
        package_name : str
            The name of the generic package.
        package_version : str
            The version of the generic package
        source : str
            The source folder that is used as root when uploading. If empty,
            current working directory is used.
        force : bool
            Whether to force upload of the files, in case of the package
            already contains any of the uploaded files.

        Return
        ------
        int
            Zero if everything went fine, non-zero coke otherwise.
        """
        files = []
        ret = 1
        filelist = glob(os.path.join(source, "**"), recursive=True)
        abort = False
        for item in filelist:
            # Only add files, not folders
            if os.path.isfile(os.path.join(item)):
                # Remove the source folder from the path of the files
                files.append(os.path.relpath(item, source))
        if not force:
            # When force is not used, let's find out if the package registry has
            # files with names that would conflict with the uploads. Doing this
            # in upload avoids making individual API requests for each file.
            abort = self.files_exists(project_id, package_name, package_version, *files)
        if not abort:
            # Since we are here, no conflicts with files were found or the force
            # option was enabled. Do not double check the file existence for
            # per-file uploads as they were checked above. May the force be with you.
            force = True
            for afile in files:
                ret = self.upload_file(
                    project_id, package_name, package_version, source, afile, force
                )
                if ret:
                    break
        else:
            ret = 3
            logger.debug("Aborting upload: some files already exists in the package.")
        return ret

    def upload_file(
        self,
        project_id: str,
        package_name: str,
        package_version: str,
        source: str,
        filename: str,
        force: bool,
    ) -> int:
        """
        Uploads a file to a GitLab generic package.

        Parameters
        ----------
        project_id : str
            The project ID or path, including namespace.
            Examples: `123` or `namespace/project`.
        package_name : str
            The name of the generic package.
        package_version : str
            The version of the generic package
        source : str
            The source folder that is used as root when uploading.
        filename : str
            The relative path of the file that is uploaded.
        force : bool
            Whether to force upload of the file, in case of the package
            already contains the uploaded file.

        Return
        ------
        int
            Zero if everything went fine, non-zero coke otherwise.
        """
        ret = 1
        abort = False
        if not force:
            # No force used; check if a file already exists
            abort = self.files_exists(
                project_id, package_name, package_version, filename
            )
        if not abort:
            fpath = os.path.join(source, filename)
            logger.debug("Uploading file %s from %s", filename, source)
            with open(fpath, "rb") as data:
                ret = self.gl_api.put(
                    data.read(),
                    "projects",
                    parse.quote_plus(project_id),
                    "packages",
                    "generic",
                    parse.quote_plus(package_name),
                    parse.quote_plus(package_version),
                    parse.quote(filename),
                )
        else:
            ret = 3
            logger.debug(
                "Aborting upload: file %s already exists in the package", filename
            )
        return ret

    def files_exists(
        self, project_id: str, package_name: str, package_verion: str, *filenames: str
    ) -> bool:
        """
        Checks whether given files already exists in a GitLab generic package.

        Parameters
        ----------
        project_id : str
            The project ID or path, including namespace.
            Examples: `123` or `namespace/project`.
        package_name : str
            The name of the generic package.
        package_version : str
            The version of the generic package that is deleted
        filenames : *str
            The filenames that are looked in the package. If any of the files
            exists in the package, True is returned.

        Return
        ------
        bool
            True if any of the files exists in the package, false otherwise.
        """
        exists = False
        package_id = self.get_id(project_id, package_name, package_verion)
        if package_id >= 0:
            existing_files = self.get_files(project_id, package_id).keys()
            if any(file in existing_files for file in filenames):
                logger.debug("File(s) existed already in package %d!", package_id)
                exists = True
        return exists

    def delete(self, project_id: str, package_name: str, package_version: str) -> int:
        """
        Deletes a version of a GitLab generic package.

        Parameters
        ----------
        project_id : str
            The project ID or path, including namespace.
            Examples: `123` or `namespace/project`.
        package_name : str
            The name of the generic package.
        package_version : str
            The version of the generic package that is deleted

        Return
        ------
        int
            Zero if everything went fine, non-zero coke otherwise.
        """
        ret = 1
        package_id = self.get_id(project_id, package_name, package_version)
        if package_id > 0:
            ret = self.gl_api.delete(
                "projects", parse.quote_plus(project_id), "packages", str(package_id)
            )
        return ret

    def delete_file(
        self,
        project_id: str,
        package_name: str,
        package_version: str,
        filename: str,
    ) -> int:
        """
        Deletes a file from a GitLab generic package.

        Parameters
        ----------
        project_id : str
            The project ID or path, including namespace.
            Examples: `123` or `namespace/project`.
        package_name : str
            The name of the generic package.
        package_version : str
            The version of the generic package
        filename : str
            The path of the file to be deleted in the package.

        Return
        ------
        int
            Zero if everything went fine, non-zero coke otherwise.
        """
        ret = 1
        package_id = self.get_id(project_id, package_name, package_version)
        if package_id > 0:
            package_files = self.get_files(project_id, package_id)
            file_id = package_files.get(filename)
            if file_id and file_id.get("id"):
                file_id = file_id.get("id")
                ret = self._delete_file(project_id, package_id, file_id)
        return ret

    def _delete_file(self, project_id: str, package_id: int, file_id: int) -> int:
        ret = 1
        logger.info(
            "Deleting file %d from package %d from project %s",
            file_id,
            package_id,
            project_id,
        )
        ret = self.gl_api.delete(
            "projects",
            parse.quote_plus(project_id),
            "packages",
            str(package_id),
            "package_files",
            str(file_id),
        )
        return ret
