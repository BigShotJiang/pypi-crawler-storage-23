"""HTTP helper"""

from http.client import HTTPMessage
import logging
from urllib import request

logger = logging.getLogger(__name__)


def get(url: str, headers: dict) -> tuple[int, bytes, HTTPMessage]:
    """
    Makes a raw GET request to the given URL, and returns
    the response status, body, and headers.

    Parameters
    ----------
    url : str
        The URL of the HTTP request to make.
    headers: dict
        The HTTP headers used in the request.

    Returns
    -------
    int
        The HTTP response code, such as 200
    bytes
        The HTTP response body read as bytes
    HTTPMessage
        The HTTP response headers
    """
    logger.debug("Getting %s", url)
    req = request.Request(url, headers=headers)
    with request.urlopen(req) as response:
        return response.status, response.read(), response.headers


def put(url: str, data: bytes, headers: dict) -> tuple[int, bytes, HTTPMessage]:
    """
    Makes a raw PUT request to the given URL, and returns
    the response status, body, and headers.

    Parameters
    ----------
    url : str
        The URL of the HTTP request to make.
    data : bytes
        The data to PUT
    headers: dict
        The HTTP headers used in the request.

    Returns
    -------
    int
        The HTTP response code, such as 200
    bytes
        The HTTP response body read as bytes
    HTTPMessage
        The HTTP response headers
    """
    logger.debug("Putting %s", url)
    req = request.Request(url, method="PUT", data=data, headers=headers)
    with request.urlopen(req) as response:
        return response.status, response.read(), response.headers


def delete(url, headers):
    """
    Makes a raw DELETE request to the given URL, and returns
    the response status, body, and headers.

    Parameters
    ----------
    url : str
        The URL of the HTTP request to make.
    headers: dict
        The HTTP headers used in the request.

    Returns
    -------
    int
        The HTTP response code, such as 200
    bytes
        The HTTP response body read as bytes
    HTTPMessage
        The HTTP response headers
    """
    logger.debug("Deleting %s", url)
    req = request.Request(url, method="DELETE", headers=headers)
    with request.urlopen(req) as response:
        return response.status, response.read(), response.headers
