from http.client import HTTPMessage
from unittest.mock import patch
import urllib

import pytest

from gitlab.lib import http


class HttpResponseMock:

    def __init__(self, status, data, headers=HTTPMessage()):
        self.status = status
        self.headers = headers
        self.data = data

    def read(self):
        return self.data

    def getcode(self):
        return self.status

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


@pytest.fixture
def mock_get_ok():
    return HttpResponseMock(200, "ok", {"header": "value"})


@pytest.fixture
def mock_request():
    return object()


class TestHttp:

    def test_get(self, mock_get_ok, mock_request):
        with patch.object(
            urllib.request, "Request", return_value=mock_request
        ) as request:
            with patch.object(urllib.request, "urlopen", return_value=mock_get_ok):
                status, response, headers = http.get(
                    "http://test.get", {"hkey": "hval"}
                )
                assert status == 200
                assert response == "ok"
                assert headers == {"header": "value"}
                request.assert_called_once_with(
                    "http://test.get", headers={"hkey": "hval"}
                )

    def test_put(self, mock_get_ok, mock_request):
        with patch.object(
            urllib.request, "Request", return_value=mock_request
        ) as request:
            with patch.object(urllib.request, "urlopen", return_value=mock_get_ok):
                status, response, headers = http.put(
                    "http://test.put", "data", {"hkey": "hval"}
                )
                assert status == 200
                assert response == "ok"
                assert headers == {"header": "value"}
                request.assert_called_once_with(
                    "http://test.put",
                    method="PUT",
                    data="data",
                    headers={"hkey": "hval"},
                )

    def test_delete(self, mock_get_ok, mock_request):
        with patch.object(
            urllib.request, "Request", return_value=mock_request
        ) as request:
            with patch.object(urllib.request, "urlopen", return_value=mock_get_ok):
                status, response, headers = http.delete(
                    "http://test.delete", {"hkey": "hval"}
                )
                assert status == 200
                assert response == "ok"
                assert headers == {"header": "value"}
                request.assert_called_once_with(
                    "http://test.delete", method="DELETE", headers={"hkey": "hval"}
                )
