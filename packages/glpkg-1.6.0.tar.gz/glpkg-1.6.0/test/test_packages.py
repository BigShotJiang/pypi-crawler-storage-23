from unittest.mock import mock_open, patch

from testutils import (
    test_gitlab,
    mock_empty_response,
    mock_one_response,
    mock_five_response,
    mock_paginate_1,
    mock_paginate_2,
)
from gitlab.lib import http


class TestPackages:

    def test_list_packages_none(self, test_gitlab, mock_empty_response):
        url = "https://gl-host/api/v4/projects/24/packages?package_name=package-name&package_type=generic"
        headers = {"token-name": "token-value"}
        with patch.object(http, "get", return_value=mock_empty_response) as _get:
            packages = test_gitlab.get_versions("24", "package-name")
            assert len(packages) == 0
            _get.assert_called_once_with(url, headers)

    def test_list_packages_one(self, test_gitlab, mock_one_response):
        url = "https://gl-host/api/v4/projects/18105942/packages?package_name=ABCComponent&package_type=generic"
        headers = {"token-name": "token-value"}
        with patch.object(http, "get", return_value=mock_one_response) as _get:
            packages = test_gitlab.get_versions("18105942", "ABCComponent")
            assert len(packages) == 1
            _get.assert_called_once_with(url, headers)

    def test_list_packages_paginate(
        self, test_gitlab, mock_paginate_1, mock_paginate_2
    ):
        url1 = "https://gl-host/api/v4/projects/18105942/packages?package_name=ABCComponent&package_type=generic"
        url2 = "https://gl-host/api/v4/projects/18105942/packages?id=18105942&order_by=created_at&page=2&per_page=10&sort=asc"
        headers = {"token-name": "token-value"}
        side_effects = [mock_paginate_1, mock_paginate_2]
        with patch.object(http, "get", side_effect=side_effects) as _get:
            packages = test_gitlab.get_versions("18105942", "ABCComponent")
            assert len(packages) == 18
            _get.assert_any_call(url1, headers)
            _get.assert_called_with(url2, headers)

    def test_list_name_packages_filter(self, test_gitlab):
        data = (
            200,
            '[{"name": "package-name", "version": "0.1.2"}, {"name": "package-name-something", "version": "0.1.2"}]',
            {},
        )
        url = "https://gl-host/api/v4/projects/24/packages?package_name=package-name&package_type=generic"
        headers = {"token-name": "token-value"}
        with patch.object(http, "get", return_value=data) as _get:
            packages = test_gitlab.get_versions("24", "package-name")
            assert len(packages) == 1
            _get.assert_called_once_with(url, headers)

    def test_list_name_packages_five(self, test_gitlab, mock_five_response):
        url = "https://gl-host/api/v4/projects/18105942/packages?package_name=ABCComponent&package_type=generic"
        headers = {"token-name": "token-value"}
        with patch.object(http, "get", return_value=mock_five_response) as _get:
            packages = test_gitlab.get_versions("18105942", "ABCComponent")
            assert len(packages) == 5
            _get.assert_called_once_with(url, headers)

    def test_list_files_none(self, test_gitlab, mock_empty_response):
        url = "https://gl-host/api/v4/projects/24/packages/123/package_files"
        headers = {"token-name": "token-value"}
        with patch.object(http, "get", return_value=mock_empty_response) as _get:
            packages = test_gitlab.get_files("24", "123").keys()
            assert len(packages) == 0
            _get.assert_called_once_with(url, headers)

    def test_list_files_one(self, test_gitlab):
        data = (200, '[{"id": 1, "file_name": "filea.txt"}]', {})
        with patch.object(http, "get", return_value=data):
            packages = test_gitlab.get_files("24", "123").keys()
            assert len(packages) == 1

    def test_list_files_five(self, test_gitlab):
        data = (
            200,
            '[{"id": 1, "file_name": "filea.txt"}, {"id": 2, "file_name": "fileb.txt"}, {"id": 3, "file_name": "filec.txt"}, {"id": 4, "file_name": "filed.txt"}, {"id": 5, "file_name": "filee.txt"}]',
            {},
        )
        with patch.object(http, "get", return_value=data):
            packages = test_gitlab.get_files("24", "123").keys()
            assert len(packages) == 5

    def test_package_id_none(self, test_gitlab, mock_empty_response):
        url = "https://gl-host/api/v4/projects/24/packages?package_name=package-name&package_version=0.1&package_type=generic"
        headers = {"token-name": "token-value"}
        with patch.object(http, "get", return_value=mock_empty_response) as _get:
            packages = test_gitlab.get_id("24", "package-name", "0.1")
            assert packages == -1
            _get.assert_called_once_with(url, headers)

    def test_package_id_one(self, test_gitlab):
        data = (200, '[{"id": 123}]', {})
        with patch.object(http, "get", return_value=data):
            packages = test_gitlab.get_id("24", "package-name", "0.1")
            assert packages == 123

    def test_upload_file(self, test_gitlab):
        data = (201, "[]", {})
        file = "Data"
        url = (
            "https://gl-host/api/v4/projects/24/packages/generic/package-name/0.1/file"
        )
        headers = {"token-name": "token-value"}
        with patch("builtins.open", mock_open(read_data=file)):
            with patch.object(http, "put", return_value=data) as _put:
                success = test_gitlab.upload_file(
                    "24", "package-name", "0.1", "", "file", True
                )
                assert success == 0
                _put.assert_called_once_with(url, file, headers)

    def test_upload(self, test_gitlab):
        data = (201, "[]", {})
        file = "Data"
        url = "https://gl-host/api/v4/projects/24/packages/generic/package-name/0.1/packages_empty.body"
        headers = {"token-name": "token-value"}
        with patch("builtins.open", mock_open(read_data=file)) as p_open:
            with patch.object(http, "put", return_value=data) as _put:
                success = test_gitlab.upload(
                    "24", "package-name", "0.1", "test/data", True
                )
                # This magic number is just the number of files in test/data folder.
                # In case files are added or removed... This should be updated.
                assert p_open.call_count == 11
                assert success == 0
                _put.assert_any_call(url, file, headers)

    def test_download(self, test_gitlab):
        data3 = (200, '[{"id": 123}]', {})
        data2 = (200, '[{"id": 14, "file_name": "file2.txt"}]', {})
        data = (200, "file-content", {})
        side_effects = [data3, data2, data]
        url = "https://gl-host/api/v4/projects/24/packages/generic/package-name/0.12/file2.txt"
        headers = {"token-name": "token-value"}
        with patch("builtins.open", mock_open()) as file_mock:
            with patch.object(http, "get", side_effect=side_effects) as _get:
                ret = test_gitlab.download("24", "package-name", "0.12", "", True)
                assert ret == 0
                _get.assert_called_with(url, headers)
                assert _get.call_count == 3
            file_mock.assert_called_once_with("file2.txt", "wb")
            file_mock().write.assert_called_once_with("file-content")

    def test_download(self, test_gitlab):
        data3 = (200, '[{"id": 123}]', {})
        data2 = (200, '[{"id": 14, "file_name": "dummy.file"}]', {})
        data = (200, "file-content", {})
        side_effects = [data3, data2, data]
        url = "https://gl-host/api/v4/projects/24/packages/generic/package-name/0.12/dummy.file"
        headers = {"token-name": "token-value"}
        with patch("builtins.open", mock_open()) as file_mock:
            with patch.object(http, "get", side_effect=side_effects) as _get:
                ret = test_gitlab.download(
                    "24", "package-name", "0.12", "test/data", True
                )
                assert ret == 0
                _get.assert_called_with(url, headers)
                assert _get.call_count == 3
            file_mock.assert_called_once_with("test/data/dummy.file", "wb")
            file_mock().write.assert_called_once_with("file-content")

    def test_download_existing(self, test_gitlab):
        data3 = (200, '[{"id": 123}]', {})
        data2 = (200, '[{"id": 14, "file_name": "dummy.file"}]', {})
        side_effects = [data3, data2]
        with patch.object(http, "get", side_effect=side_effects) as _get:
            ret = test_gitlab.download("24", "package-name", "0.12", "test/data", False)
            assert ret == 3
            assert _get.call_count == 2

    def test_download_existing_file(self, test_gitlab):
        with patch("builtins.open", mock_open()):
            # mock_open.write.return_value = 0
            ret = test_gitlab.download_file(
                "24", "package-name", "0.1", "dummy.file", "test/data", False
            )
            assert ret == 3

    def test_download_existing_file_force(self, test_gitlab):
        data3 = (200, '[{"id": 123}]', {})
        data2 = (200, '[{"id": 14, "file_name": "dummy.file"}]', {})
        data = (200, "file-content", {})
        side_effects = [data3, data2, data]
        url = "https://gl-host/api/v4/projects/24/packages/generic/package-name/0.12/dummy.file"
        headers = {"token-name": "token-value"}
        with patch("builtins.open", mock_open()) as file_mock:
            with patch.object(http, "get", side_effect=side_effects) as _get:
                ret = test_gitlab.download(
                    "24", "package-name", "0.12", "test/data", True
                )
                assert ret == 0
                _get.assert_called_with(url, headers)
                assert _get.call_count == 3
            file_mock.assert_called_once_with("test/data/dummy.file", "wb")
            file_mock().write.assert_called_once_with("file-content")

    def test_download_file(self, test_gitlab):
        data = (200, "file-content", {})
        url = "https://gl-host/api/v4/projects/24/packages/generic/package-name/0.1/file.txt"
        headers = {"token-name": "token-value"}
        with patch("builtins.open", mock_open()) as file_mock:
            # mock_open.write.return_value = 0
            with patch.object(http, "get", return_value=data) as _get:
                ret = test_gitlab.download_file(
                    "24", "package-name", "0.1", "file.txt", "", True
                )
                assert ret == 0
                _get.assert_called_once_with(url, headers)
            file_mock.assert_called_once_with("file.txt", "wb")
            file_mock().write.assert_called_once_with("file-content")

    def test_delete_file(self, test_gitlab):
        packages = (200, '[{"id": 123}]', {})
        files = (200, '[{"id": 2, "file_name": "file.txt"}]', {})
        data = (204, None, {})
        side_effects = [packages, files]
        url = "https://gl-host/api/v4/projects/24/packages/123/package_files/2"
        headers = {"token-name": "token-value"}
        # mock_open.write.return_value = 0
        with patch.object(http, "get", side_effect=side_effects):
            with patch.object(http, "delete", return_value=data) as _delete:
                ret = test_gitlab.delete_file("24", "package-name", "0.1", "file.txt")
                assert ret == 0
                _delete.assert_called_once_with(url, headers)

    def test_delete_package(self, test_gitlab):
        packages = (200, '[{"id": 123}]', {})
        data = (204, None, {})
        url = "https://gl-host/api/v4/projects/24/packages/123"
        headers = {"token-name": "token-value"}
        # mock_open.write.return_value = 0
        with patch.object(http, "get", return_value=packages):
            with patch.object(http, "delete", return_value=data) as _delete:
                ret = test_gitlab.delete("24", "package-name", "0.1")
                assert ret == 0
                _delete.assert_called_once_with(url, headers)

    def test_files_exists(self, test_gitlab):
        packages = (200, '[{"id": 123}]', {})
        files = (
            200,
            '[{"id": 1, "file_name": "filea.txt"}, {"id": 2, "file_name": "fileb.txt"}, {"id": 3, "file_name": "filec.txt"}, {"id": 4, "file_name": "filed.txt"}, {"id": 5, "file_name": "filee.txt"}]',
            {},
        )
        side_effects = [packages, files]
        url = "https://gl-host/api/v4/projects/24/packages/123/package_files"
        headers = {"token-name": "token-value"}
        with patch.object(http, "get", side_effect=side_effects) as _get:
            val = test_gitlab.files_exists("24", "package-name", "0.12", "filea.txt")
            assert val == True
            _get.assert_called_with(url, headers)
            assert _get.call_count == 2

    def test_files_exists_not_found(self, test_gitlab):
        packages = (200, '[{"id": 123}]', {})
        files = (
            200,
            '[{"id": 1, "file_name": "filea.txt"}, {"id": 2, "file_name": "fileb.txt"}, {"id": 3, "file_name": "filec.txt"}, {"id": 4, "file_name": "filed.txt"}, {"id": 5, "file_name": "filee.txt"}]',
            {},
        )
        side_effects = [packages, files]
        url = "https://gl-host/api/v4/projects/24/packages/123/package_files"
        headers = {"token-name": "token-value"}
        with patch.object(http, "get", side_effect=side_effects) as _get:
            val = test_gitlab.files_exists("24", "package-name", "0.12", "not-found")
            assert val == False
            _get.assert_called_with(url, headers)
            assert _get.call_count == 2

    def test_files_exists_no_package(self, test_gitlab):
        packages = (200, "[]", {})
        with patch.object(http, "get", return_value=packages) as _get:
            val = test_gitlab.files_exists(
                "24", "package-name", "0.999.999", "not-found"
            )
            assert val == False
            assert _get.call_count == 1

    def test_files_exists_not_found(self, test_gitlab):
        packages = (200, '[{"id": 123}]', {})
        files = (
            200,
            '[{"id": 1, "file_name": "filea.txt"}, {"id": 2, "file_name": "fileb.txt"}, {"id": 3, "file_name": "filec.txt"}, {"id": 4, "file_name": "filed.txt"}, {"id": 5, "file_name": "filee.txt"}]',
            {},
        )
        side_effects = [packages, files]
        url = "https://gl-host/api/v4/projects/24/packages/123/package_files"
        headers = {"token-name": "token-value"}
        with patch.object(http, "get", side_effect=side_effects) as _get:
            val = test_gitlab.files_exists(
                "24",
                "package-name",
                "0.12",
                "not-found",
                "neither-this",
                "this-should-not-too",
                "fileb.txt",
            )
            assert val == True
            _get.assert_called_with(url, headers)
            assert _get.call_count == 2
