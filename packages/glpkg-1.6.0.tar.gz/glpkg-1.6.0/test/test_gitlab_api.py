from urllib import parse

import pytest
from gitlab.lib.gitlab_api import GitLabAPI


@pytest.fixture
def test_gitlab_api():
    return GitLabAPI("gl-host", "token-name", "token-value")


class TestGitLabAPI:

    def test_api_url(self, test_gitlab_api):
        url = "https://gl-host/api/v4/"
        assert url == test_gitlab_api._url()

    def test_project_path(self, test_gitlab_api):
        url = "projects/24"
        assert url == test_gitlab_api._build_path("projects", "24")

    def test_build_query_empty(self, test_gitlab_api):
        args = ""
        assert args == test_gitlab_api._build_query()

    def test_build_query_one(self, test_gitlab_api):
        args = "?package_name=name"
        assert args == test_gitlab_api._build_query(package_name="name")

    def test_build_query_two(self, test_gitlab_api):
        args = "?package_name=name&package_version=version"
        assert args == test_gitlab_api._build_query(
            package_name="name", package_version="version"
        )

    def test_project_path_name(self, test_gitlab_api):
        url = "projects/namespace%2Fpath"
        assert url == test_gitlab_api._build_path(
            "projects", parse.quote_plus("namespace/path")
        )

    def test_get_headers(self, test_gitlab_api):
        assert test_gitlab_api._get_headers() == {"token-name": "token-value"}

    def test_get_headers_no_name(self):
        test_gitlab = GitLabAPI("gl-host", "", "token-value")
        assert test_gitlab._get_headers() == {}

    def test_get_headers_no_value(self):
        test_gitlab = GitLabAPI("gl-host", "token-name", "")
        assert test_gitlab._get_headers() == {}

    def test_get_headers_no_name_no_value(self):
        test_gitlab = GitLabAPI("gl-host", "", "")
        assert test_gitlab._get_headers() == {}
