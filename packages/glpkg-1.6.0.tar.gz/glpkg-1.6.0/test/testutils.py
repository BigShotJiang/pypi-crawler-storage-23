import email
import pytest

from gitlab.packages import Packages


@pytest.fixture
def mock_paginate_1():
    with open("test/data/packages_paginate_1.body", "r") as body:
        with open("test/data/packages_paginate_1.header", "r") as header:
            headers = email.message_from_file(header)
            return 200, body.read(), headers


@pytest.fixture
def mock_paginate_2():
    with open("test/data/packages_paginate_2.body", "r") as body:
        with open("test/data/packages_paginate_2.header", "r") as header:
            headers = email.message_from_file(header)
            return 200, body.read(), headers


@pytest.fixture
def mock_empty_response():
    with open("test/data/packages_empty.body", "r") as body:
        with open("test/data/packages_empty.header", "r") as header:
            headers = email.message_from_file(header)
            return 200, body.read(), headers


@pytest.fixture
def mock_one_response():
    with open("test/data/packages_one.body", "r") as body:
        with open("test/data/packages_one.header", "r") as header:
            headers = email.message_from_file(header)
            return 200, body.read(), headers


@pytest.fixture
def mock_five_response():
    with open("test/data/packages_five.body", "r") as body:
        with open("test/data/packages_five.header", "r") as header:
            headers = email.message_from_file(header)
            return 200, body.read(), headers


@pytest.fixture
def test_gitlab():
    return Packages("gl-host", "token-name", "token-value")
