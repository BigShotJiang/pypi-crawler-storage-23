"""Tests for DuckDuckGo search results parser."""

from __future__ import annotations

from search_parser.parsers.duckduckgo import DuckDuckGoParser
from search_parser.utils import make_soup


class TestDuckDuckGoParser:
    def setup_method(self) -> None:
        self.parser = DuckDuckGoParser()

    def test_engine_name(self) -> None:
        assert self.parser.engine_name == "duckduckgo"

    def test_can_parse_duckduckgo_html(self, duckduckgo_organic_html: str) -> None:
        soup = make_soup(duckduckgo_organic_html)
        confidence = self.parser.can_parse(soup)
        assert confidence >= 0.8

    def test_can_parse_non_duckduckgo_html(self) -> None:
        html = "<html><body><p>Not a search page</p></body></html>"
        soup = make_soup(html)
        confidence = self.parser.can_parse(soup)
        assert confidence == 0.0

    def test_parse_organic_results(self, duckduckgo_organic_html: str) -> None:
        results = self.parser.parse(duckduckgo_organic_html)
        assert results.search_engine == "duckduckgo"
        assert len(results.results) == 3
        assert results.query == "python web scraping"

        first = results.results[0]
        assert first.title == "Web Scraping with Python - Real Python"
        assert first.url == "https://realpython.com/python-web-scraping/"
        assert first.position == 1
        assert first.result_type == "organic"

    def test_parse_result_descriptions(self, duckduckgo_organic_html: str) -> None:
        results = self.parser.parse(duckduckgo_organic_html)
        for result in results.results:
            assert result.description is not None
            assert len(result.description) > 0

    def test_parse_result_positions(self, duckduckgo_organic_html: str) -> None:
        results = self.parser.parse(duckduckgo_organic_html)
        positions = [r.position for r in results.results]
        assert positions == [1, 2, 3]

    def test_parse_div_based_results(self) -> None:
        """Test fallback to div.result layout."""
        html = """
        <html>
        <head><link rel="canonical" href="https://duckduckgo.com/?q=test"></head>
        <body>
            <div class="result">
                <a class="result__a" href="https://example.com/1">First Result</a>
                <a class="result__snippet">First description here.</a>
            </div>
            <div class="result">
                <a class="result__a" href="https://example.com/2">Second Result</a>
                <a class="result__snippet">Second description here.</a>
            </div>
        </body>
        </html>
        """
        results = self.parser.parse(html)
        assert len(results.results) == 2
        assert results.results[0].title == "First Result"
        assert results.results[1].title == "Second Result"

    def test_parse_empty_html(self) -> None:
        results = self.parser.parse("<html><body></body></html>")
        assert results.search_engine == "duckduckgo"
        assert len(results.results) == 0

    def test_detection_confidence(self, duckduckgo_organic_html: str) -> None:
        results = self.parser.parse(duckduckgo_organic_html)
        assert results.detection_confidence >= 0.8

    def test_parse_github_repos_results(self, duckduckgo_github_repos_html: str) -> None:
        results = self.parser.parse(duckduckgo_github_repos_html)
        assert results.search_engine == "duckduckgo"
        assert results.query == "github repos"
        assert results.detection_confidence >= 0.8
        assert len(results.results) == 4

        first = results.results[0]
        assert first.title == "Trending repositories on GitHub today"
        assert first.url == "https://github.com/trending"
        assert first.position == 1
        assert first.result_type == "organic"
        assert first.description is not None

    def test_parse_github_repos_positions(self, duckduckgo_github_repos_html: str) -> None:
        results = self.parser.parse(duckduckgo_github_repos_html)
        positions = [r.position for r in results.results]
        assert positions == [1, 2, 3, 4]

    def test_parse_github_repos_all_have_descriptions(
        self, duckduckgo_github_repos_html: str
    ) -> None:
        results = self.parser.parse(duckduckgo_github_repos_html)
        for r in results.results:
            assert r.description is not None
            assert len(r.description) > 0
