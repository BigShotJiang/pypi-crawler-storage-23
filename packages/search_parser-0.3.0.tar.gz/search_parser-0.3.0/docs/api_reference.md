# API Reference

## SearchParser

::: search_parser.SearchParser
    options:
      show_root_heading: true
      members:
        - parse

## Models

::: search_parser.core.models.SearchResult
    options:
      show_root_heading: true

::: search_parser.core.models.SearchResults
    options:
      show_root_heading: true

## Parsers

::: search_parser.parsers.base.BaseParser
    options:
      show_root_heading: true

## Formatters

::: search_parser.formatters.base.BaseFormatter
    options:
      show_root_heading: true

## Exceptions

::: search_parser.exceptions
    options:
      show_root_heading: true
