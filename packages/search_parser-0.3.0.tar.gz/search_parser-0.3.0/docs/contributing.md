# Contributing

See [CONTRIBUTING.md](https://github.com/getlinksc/search-parser/blob/main/CONTRIBUTING.md) for full contributing guidelines.

## Quick Start for Contributors

```bash
git clone https://github.com/getlinksc/search-parser.git
cd search-parser
uv sync --all-extras
uv run pytest
```

## Adding a New Search Engine

See the [Adding a Search Engine](adding_search_engine.md) guide.
