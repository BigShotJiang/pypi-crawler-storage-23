"""Core module for search engine parser."""
