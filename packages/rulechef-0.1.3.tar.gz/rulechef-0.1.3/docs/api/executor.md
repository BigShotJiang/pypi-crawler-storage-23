# Executor

Rule execution engine.

## RuleExecutor

::: rulechef.executor.RuleExecutor
    options:
      members:
        - __init__
        - apply_rules
        - execute_rule

## Functions

### substitute_template

::: rulechef.executor.substitute_template
