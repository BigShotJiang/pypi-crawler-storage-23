#!/usr/bin/env python3
"""BFCL Function Calling Benchmark for RuleChef

Evaluates RuleChef's ability to learn function-calling rules from the
Salesforce xLAM-60k dataset. Groups examples by tool signature and learns
rules per group to route queries to the correct function with arguments.

Compares against published BFCL leaderboard numbers (GLM-4.5, Claude, GPT-5, xLAM).

Usage:
    # Quick test (1 group, 10 test examples)
    python benchmarks/benchmark_bfcl.py --num-groups 1 --test-limit 10 \
        --base-url https://api.groq.com/openai/v1 \
        --model moonshotai/kimi-k2-instruct

    # Full benchmark (10 groups)
    python benchmarks/benchmark_bfcl.py --model gpt-4o-mini --num-groups 10

    # With agentic coordinator
    python benchmarks/benchmark_bfcl.py --agentic --num-groups 5

Requirements:
    pip install datasets rulechef openai
"""

import argparse
import json
import os
import random
import sys
import time
import uuid
from collections import defaultdict
from pathlib import Path

# Published BFCL baselines for comparison
BFCL_BASELINES = {
    "GLM-4.5 (FC)": {"score": 70.85, "cost": "$$$", "latency": "~1s"},
    "Claude Opus 4.1": {"score": 70.36, "cost": "$$", "latency": "~1s"},
    "Claude Sonnet 4": {"score": 70.29, "cost": "$$", "latency": "~1s"},
    "GPT-5": {"score": 59.22, "cost": "$$$", "latency": "~1s"},
    "xLAM-2-3b": {"score": 65.74, "cost": "$ (GPU)", "latency": "~100ms"},
    "xLAM-2-1b": {"score": 53.97, "cost": "$ (GPU)", "latency": "~50ms"},
}

# ── Dataset Loading ─────────────────────────────────────────


def load_xlam_60k():
    """Load Salesforce/xlam-function-calling-60k from HuggingFace."""
    try:
        from datasets import load_dataset
    except ImportError:
        print("ERROR: pip install datasets")
        sys.exit(1)

    print("Loading Salesforce/xlam-function-calling-60k...")
    ds = load_dataset("Salesforce/xlam-function-calling-60k")

    records = []
    for row in ds["train"]:
        tools = json.loads(row["tools"]) if isinstance(row["tools"], str) else row["tools"]
        answers = json.loads(row["answers"]) if isinstance(row["answers"], str) else row["answers"]
        records.append(
            {
                "query": row["query"],
                "tools": tools,
                "answers": answers,
            }
        )

    print(f"  Loaded {len(records)} examples")
    return records


# ── Tool-Group Clustering ───────────────────────────────────


def group_by_tool_signature(records):
    """Group examples by their available tool set (sorted function names)."""
    groups = defaultdict(list)
    for record in records:
        tool_names = tuple(sorted(t["name"] for t in record["tools"]))
        groups[tool_names].append(record)
    return groups


def select_tool_groups(groups, num_groups=10, min_size=20, multi_tool_only=True, seed=42):
    """Select the N largest tool groups with at least min_size examples."""
    eligible = {k: v for k, v in groups.items() if len(v) >= min_size}
    if multi_tool_only:
        eligible = {k: v for k, v in eligible.items() if len(k) >= 2}
    sorted_groups = sorted(eligible.items(), key=lambda x: -len(x[1]))
    selected = sorted_groups[:num_groups]
    return selected


def sample_group(examples, shots, seed=42):
    """Split a tool group into train, eval, and test sets."""
    rng = random.Random(seed)
    shuffled = list(examples)
    rng.shuffle(shuffled)
    train = shuffled[:shots]
    remaining = shuffled[shots:]
    # Use some remaining for eval (refinement), rest for test
    eval_split = min(len(remaining) // 2, 50)
    eval_data = remaining[:eval_split]
    test_data = remaining[eval_split:]
    return train, eval_data, test_data


# ── Function Call Matching ──────────────────────────────────


def values_match(expected, actual):
    """Compare values with type coercion."""
    if expected == actual:
        return True
    # String comparison
    if str(expected).strip().lower() == str(actual).strip().lower():
        return True
    # List comparison (order-independent)
    if isinstance(expected, list) and isinstance(actual, list):
        if len(expected) != len(actual):
            return False
        return sorted(map(str, expected)) == sorted(map(str, actual))
    return False


def args_match(expected_args, actual_args):
    """Flexible argument comparison with type coercion."""
    if set(expected_args.keys()) != set(actual_args.keys()):
        return False
    return all(values_match(expected_args[k], actual_args.get(k)) for k in expected_args)


def compute_bfcl_metrics(test_data, rules, apply_fn, task_type, text_field):
    """Compute function calling metrics: name accuracy, argument accuracy, overall."""
    name_correct = 0
    args_correct = 0
    overall_correct = 0
    total = 0

    for record in test_data:
        input_data = {"text": record["query"]}
        result = apply_fn(rules, input_data, task_type, text_field)

        exp_calls = record["answers"]
        act_calls = result.get("function_calls", [])
        total += 1

        # Compare function names
        exp_names = sorted(c["name"] for c in exp_calls)
        act_names = sorted(c.get("name", "") for c in act_calls)

        if exp_names == act_names:
            name_correct += 1

            # Compare arguments (only if names match)
            all_args_ok = True
            exp_sorted = sorted(exp_calls, key=lambda x: x["name"])
            act_sorted = sorted(act_calls, key=lambda x: x.get("name", ""))
            for exp, act in zip(exp_sorted, act_sorted):
                if not args_match(exp.get("arguments", {}), act.get("arguments", {})):
                    all_args_ok = False
                    break
            if all_args_ok:
                args_correct += 1
                overall_correct += 1

    return {
        "function_name_accuracy": name_correct / total if total else 0,
        "argument_accuracy": args_correct / total if total else 0,
        "overall_accuracy": overall_correct / total if total else 0,
        "total": total,
        "name_correct": name_correct,
        "args_correct": args_correct,
        "overall_correct": overall_correct,
    }


# ── Per-Group Benchmark ────────────────────────────────────


def run_group_benchmark(group_idx, tool_names, examples, args, client):
    """Run benchmark for a single tool group."""
    from rulechef import RuleChef
    from rulechef.core import Dataset, Example, RuleFormat, Task, TaskType

    # Sample
    train, eval_data, test_data = sample_group(examples, args.shots, seed=args.seed)

    if args.test_limit:
        test_data = test_data[: args.test_limit]

    if len(test_data) == 0:
        print("  Skipping: no test data after sampling")
        return None

    tools_short = ", ".join(tool_names[:3])
    if len(tool_names) > 3:
        tools_short += f" (+{len(tool_names) - 3} more)"

    print(f"\n  Tools: {tools_short}")
    print(f"  Train: {len(train)}, Eval: {len(eval_data)}, Test: {len(test_data)}")

    # Build tool schema description (compact)
    tool_defs = examples[0]["tools"]
    tools_description = _compact_tool_description(tool_defs)

    task = Task(
        name=f"Function Calling: {tools_short}",
        description=(
            f"Given a user query, determine which function to call and extract "
            f"the correct arguments. Return the result as a list of function calls.\n\n"
            f"Available tools:\n{tools_description}\n\n"
            f'Output format: {{"function_calls": [{{"name": "func_name", '
            f'"arguments": {{...}}}}]}}'
        ),
        input_schema={"text": "str"},
        output_schema={"function_calls": "List[Dict]"},
        type=TaskType.TRANSFORMATION,
        text_field="text",
    )

    format_map = {
        "code": [RuleFormat.CODE],
        "regex": [RuleFormat.REGEX],
        "both": [RuleFormat.REGEX, RuleFormat.CODE],
    }
    allowed_formats = format_map.get(args.format, [RuleFormat.CODE])

    import tempfile

    from rulechef.training_logger import TrainingDataLogger

    storage_dir = tempfile.mkdtemp(prefix=f"rulechef_bfcl_g{group_idx}_")

    log_path = Path(args.output).parent / f"training_log_bfcl_g{group_idx}.jsonl"
    logger = TrainingDataLogger(
        str(log_path),
        run_metadata={
            "benchmark": "bfcl",
            "group_idx": group_idx,
            "model": args.model,
            "tools": list(tool_names),
        },
    )

    coordinator = None
    if args.agentic:
        from rulechef.coordinator import AgenticCoordinator

        coordinator = AgenticCoordinator(client, model=args.model)

    chef = RuleChef(
        task=task,
        client=client,
        dataset_name=f"bfcl_group_{group_idx}",
        storage_path=storage_dir,
        allowed_formats=allowed_formats,
        model=args.model,
        use_grex=not args.no_grex,
        max_rules=args.max_rules,
        max_samples=args.max_samples,
        coordinator=coordinator,
        training_logger=logger,
    )

    # Add training examples
    for record in train:
        chef.add_example(
            {"text": record["query"]},
            {"function_calls": record["answers"]},
        )

    # Build eval dataset
    eval_dataset = Dataset(name=f"bfcl_eval_g{group_idx}", task=task)
    for record in eval_data:
        eval_dataset.examples.append(
            Example(
                id=str(uuid.uuid4())[:8],
                input={"text": record["query"]},
                expected_output={"function_calls": record["answers"]},
                source="benchmark",
            )
        )

    # Learn rules
    t0 = time.time()
    result = chef.learn_rules(run_evaluation=False)
    t_learn = time.time() - t0

    if result is None:
        print("  ERROR: Learning failed!")
        import shutil

        shutil.rmtree(storage_dir, ignore_errors=True)
        return None

    rules, _ = result
    print(f"  Synthesis: {len(rules)} rules ({t_learn:.1f}s)")

    # Refine
    iteration_metrics = []

    def on_iteration(iteration, iter_rules, eval_result):
        iteration_metrics.append(
            {
                "iteration": iteration,
                "num_rules": len(iter_rules),
                "exact_match": eval_result.exact_match,
            }
        )

    if args.max_iterations > 0 and len(eval_data) > 0:
        t0_refine = time.time()
        rules, refine_eval = chef.learner.evaluate_and_refine(
            rules,
            eval_dataset,
            max_iterations=args.max_iterations,
            coordinator=chef.coordinator,
            iteration_callback=on_iteration,
        )
        t_refine = time.time() - t0_refine
        t_learn += t_refine
        print(f"  Refinement: {len(rules)} rules ({t_refine:.1f}s)")

    # BFCL-specific evaluation
    from rulechef.core import TaskType

    t0 = time.time()
    bfcl = compute_bfcl_metrics(
        test_data, rules, chef.learner._apply_rules, TaskType.TRANSFORMATION, "text"
    )
    t_eval = time.time() - t0

    print(f"  Function name accuracy: {bfcl['function_name_accuracy']:.1%}")
    print(f"  Argument accuracy:      {bfcl['argument_accuracy']:.1%}")
    print(f"  Overall accuracy:       {bfcl['overall_accuracy']:.1%}")
    print(f"  Eval time:              {t_eval:.3f}s ({t_eval / len(test_data) * 1000:.2f}ms/query)")

    # Cleanup
    import shutil

    shutil.rmtree(storage_dir, ignore_errors=True)

    return {
        "group_idx": group_idx,
        "tool_names": list(tool_names),
        "num_tools": len(tool_names),
        "config": {
            "train_size": len(train),
            "eval_size": len(eval_data),
            "test_size": len(test_data),
        },
        "results": {
            "function_name_accuracy": bfcl["function_name_accuracy"],
            "argument_accuracy": bfcl["argument_accuracy"],
            "overall_accuracy": bfcl["overall_accuracy"],
            "num_rules": len(rules),
            "learning_time_s": round(t_learn, 1),
            "eval_time_s": round(t_eval, 3),
            "per_query_ms": round(t_eval / len(test_data) * 1000, 2),
        },
        "iteration_metrics": iteration_metrics,
        "rules": [
            {
                "name": r.name,
                "format": r.format.value,
                "content": r.content[:200],  # Truncate for JSON size
                "priority": r.priority,
                "output_template": r.output_template,
            }
            for r in rules
        ],
    }


def _compact_tool_description(tool_defs):
    """Create a compact description of tools for the task description."""
    lines = []
    for tool in tool_defs:
        params = tool.get("parameters", {})
        param_strs = []
        for pname, pinfo in params.items():
            ptype = pinfo.get("type", "any") if isinstance(pinfo, dict) else "any"
            required = pinfo.get("required", False) if isinstance(pinfo, dict) else False
            param_strs.append(f"{pname}: {ptype}{'*' if required else ''}")
        params_line = ", ".join(param_strs)
        desc = tool.get("description", "")[:80]
        lines.append(f"- {tool['name']}({params_line}): {desc}")
    return "\n".join(lines)


# ── Main Benchmark Runner ──────────────────────────────────


def run_benchmark(args):
    from openai import OpenAI

    client = OpenAI(
        api_key=os.environ.get("OPENAI_API_KEY"),
        base_url=args.base_url,
    )

    # Load dataset
    records = load_xlam_60k()

    # Group by tool signature
    groups = group_by_tool_signature(records)
    print(f"  {len(groups)} unique tool signatures")

    selected = select_tool_groups(
        groups,
        num_groups=args.num_groups,
        min_size=args.min_group_size,
        multi_tool_only=not args.include_single_tool,
        seed=args.seed,
    )
    print(f"  Selected {len(selected)} groups (min {args.min_group_size} examples each)")

    # Run per-group benchmarks
    all_results = []
    agg = {"name_total": 0, "args_total": 0, "overall_total": 0, "count": 0}

    for group_idx, (tool_names, examples) in enumerate(selected):
        print(f"\n{'=' * 70}")
        print(f"TOOL GROUP {group_idx + 1}/{len(selected)} ({len(examples)} examples)")
        print(f"{'=' * 70}")

        result = run_group_benchmark(group_idx, tool_names, examples, args, client)
        if result:
            all_results.append(result)
            n = result["config"]["test_size"]
            agg["name_total"] += result["results"]["function_name_accuracy"] * n
            agg["args_total"] += result["results"]["argument_accuracy"] * n
            agg["overall_total"] += result["results"]["overall_accuracy"] * n
            agg["count"] += n

    if not all_results:
        print("\nERROR: No groups completed successfully!")
        return

    # Aggregate metrics
    total = agg["count"]
    agg_name = agg["name_total"] / total
    agg_args = agg["args_total"] / total
    agg_overall = agg["overall_total"] / total
    total_rules = sum(r["results"]["num_rules"] for r in all_results)
    total_learn = sum(r["results"]["learning_time_s"] for r in all_results)
    avg_ms = sum(r["results"]["per_query_ms"] for r in all_results) / len(all_results)

    # Summary
    print(f"\n{'=' * 80}")
    print("BFCL FUNCTION CALLING BENCHMARK RESULTS")
    print(f"{'=' * 80}")
    print(f"  Model:                    {args.model}")
    print(f"  Format:                   {args.format}")
    print(f"  Shots per group:          {args.shots}")
    print(f"  Tool groups evaluated:    {len(all_results)}")
    print(f"  Total test examples:      {total}")
    print()
    print("  Aggregate Results:")
    print(f"    Function name accuracy: {agg_name:.1%}")
    print(f"    Argument accuracy:      {agg_args:.1%}")
    print(f"    Overall accuracy:       {agg_overall:.1%}")
    print(f"    Total rules:            {total_rules}")
    print(f"    Total learning time:    {total_learn:.1f}s")
    print(f"    Avg query latency:      {avg_ms:.2f}ms")

    # Comparison table
    print(f"\n  {'─' * 60}")
    print("  BFCL COMPARISON (approximate — different eval methodology)")
    print(f"  {'─' * 60}")
    print(f"  {'Approach':<22} {'Score':>8} {'Cost':>12} {'Latency':>10}")
    print(f"  {'─' * 60}")
    for name, info in BFCL_BASELINES.items():
        print(f"  {name:<22} {info['score']:>7.1f}% {info['cost']:>12} {info['latency']:>10}")
    print(f"  {'RuleChef rules':<22} {agg_overall * 100:>7.1f}% {'Free':>12} {'<1ms':>10}")
    print(f"  {'─' * 60}")
    print(f"{'=' * 80}")

    # Per-group breakdown
    print("\n  Per-group breakdown:")
    for r in all_results:
        tools_short = ", ".join(r["tool_names"][:2])
        if len(r["tool_names"]) > 2:
            tools_short += "..."
        print(
            f"    [{r['group_idx']}] {tools_short:40s} "
            f"name={r['results']['function_name_accuracy']:.0%} "
            f"args={r['results']['argument_accuracy']:.0%} "
            f"overall={r['results']['overall_accuracy']:.0%} "
            f"({r['results']['num_rules']} rules)"
        )

    # Save results
    output = {
        "config": {
            "model": args.model,
            "format": args.format,
            "shots": args.shots,
            "num_groups": args.num_groups,
            "min_group_size": args.min_group_size,
            "max_rules": args.max_rules,
            "max_samples": args.max_samples,
            "max_iterations": args.max_iterations,
            "seed": args.seed,
            "use_grex": not args.no_grex,
            "agentic": args.agentic,
        },
        "aggregate": {
            "function_name_accuracy": agg_name,
            "argument_accuracy": agg_args,
            "overall_accuracy": agg_overall,
            "total_test_examples": total,
            "total_rules": total_rules,
            "total_learning_time_s": round(total_learn, 1),
            "avg_per_query_ms": round(avg_ms, 2),
        },
        "groups": all_results,
        "published_baselines": BFCL_BASELINES,
    }

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(output, indent=2, default=str))
    print(f"\nResults saved to {output_path}")


# ── CLI ─────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        description="BFCL Function Calling Benchmark for RuleChef (using xLAM-60k)"
    )
    parser.add_argument(
        "--num-groups",
        type=int,
        default=10,
        help="Number of tool groups to benchmark (default: 10)",
    )
    parser.add_argument(
        "--min-group-size",
        type=int,
        default=20,
        help="Minimum examples per tool group (default: 20)",
    )
    parser.add_argument(
        "--shots",
        type=int,
        default=5,
        help="Training examples per group (default: 5)",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="gpt-4o-mini",
        help="LLM model for rule synthesis (default: gpt-4o-mini)",
    )
    parser.add_argument(
        "--base-url",
        type=str,
        default=None,
        help="OpenAI-compatible base URL",
    )
    parser.add_argument(
        "--format",
        type=str,
        default="code",
        choices=["regex", "code", "both"],
        help="Rule format (default: code)",
    )
    parser.add_argument(
        "--max-rules",
        type=int,
        default=50,
        help="Max rules per group synthesis (default: 50)",
    )
    parser.add_argument(
        "--max-samples",
        type=int,
        default=200,
        help="Max training examples in LLM prompt (default: 200)",
    )
    parser.add_argument(
        "--max-iterations",
        type=int,
        default=2,
        help="Max refinement iterations per group (default: 2)",
    )
    parser.add_argument(
        "--test-limit",
        type=int,
        default=None,
        help="Limit test examples per group for quick runs",
    )
    parser.add_argument("--seed", type=int, default=42, help="Random seed (default: 42)")
    parser.add_argument(
        "--output",
        type=str,
        default="benchmarks/results_bfcl.json",
        help="Save results to JSON (default: benchmarks/results_bfcl.json)",
    )
    parser.add_argument(
        "--agentic",
        action="store_true",
        help="Use AgenticCoordinator for LLM-guided refinement",
    )
    parser.add_argument(
        "--no-grex",
        action="store_true",
        help="Disable grex regex pattern suggestions",
    )
    parser.add_argument(
        "--include-single-tool",
        action="store_true",
        help="Include single-tool groups (default: multi-tool only for real routing)",
    )

    args = parser.parse_args()
    run_benchmark(args)


if __name__ == "__main__":
    main()
