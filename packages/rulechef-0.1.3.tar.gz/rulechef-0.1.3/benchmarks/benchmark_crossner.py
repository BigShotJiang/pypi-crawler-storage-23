#!/usr/bin/env python3
"""CrossNER Named Entity Recognition Benchmark for RuleChef

Evaluates RuleChef's ability to learn NER rules across 5 domains from the CrossNER
dataset (AAAI 2021). Compares against published GLiNER / GPT-4o baselines.

Domains: AI, Literature, Music, Politics, Science

Usage:
    # Single domain, quick test
    python benchmarks/benchmark_crossner.py --domains ai --test-limit 50 \
        --base-url https://api.groq.com/openai/v1 \
        --model moonshotai/kimi-k2-instruct

    # All domains
    python benchmarks/benchmark_crossner.py --model gpt-4o-mini

    # With agentic coordinator
    python benchmarks/benchmark_crossner.py --domains music,politics --agentic

Requirements:
    pip install datasets rulechef openai
"""

import argparse
import json
import os
import random
import sys
import time
import uuid
from pathlib import Path

CROSSNER_DOMAINS = ["ai", "literature", "music", "politics", "science"]

# Published baselines for comparison (from GLiNER / GLiNER2 papers)
PUBLISHED_BASELINES = {
    "ai": {"GLiNER2": 0.526, "GPT-4o": 0.547, "GLiNER-M": 0.518},
    "literature": {"GLiNER2": 0.564, "GPT-4o": 0.561, "GLiNER-M": 0.597},
    "music": {"GLiNER2": 0.632, "GPT-4o": 0.736, "GLiNER-M": 0.694},
    "politics": {"GLiNER2": 0.679, "GPT-4o": 0.632, "GLiNER-M": 0.686},
    "science": {"GLiNER2": 0.547, "GPT-4o": 0.518, "GLiNER-M": 0.581},
}

# ── BIO → Span Conversion ──────────────────────────────────


def convert_bio_to_spans(row, tag_names):
    """Convert BIO-tagged tokens to character-level entity spans.

    Args:
        row: Dataset row with 'tokens' and 'ner_tags' fields.
        tag_names: List of tag name strings (e.g. ["O", "B-field", "I-field", ...]).

    Returns:
        {"text": str, "entities": [{"text": str, "start": int, "end": int, "type": str}]}
    """
    tokens = row["tokens"]
    tags = row["ner_tags"]

    # Reconstruct text with spaces, tracking char offsets per token
    token_offsets = []
    current_pos = 0
    for i, token in enumerate(tokens):
        if i > 0:
            current_pos += 1  # space
        start = current_pos
        end = current_pos + len(token)
        token_offsets.append((start, end))
        current_pos = end

    text = " ".join(tokens)

    # Parse BIO tags into entity spans
    entities = []
    current_entity = None  # {"type": str, "start_tok": int, "end_tok": int}

    for i, tag_id in enumerate(tags):
        tag_name = tag_names[tag_id]

        if tag_name.startswith("B-"):
            if current_entity:
                entities.append(_finalize_entity(current_entity, token_offsets, tokens))
            current_entity = {"type": tag_name[2:], "start_tok": i, "end_tok": i + 1}

        elif tag_name.startswith("I-"):
            entity_type = tag_name[2:]
            if current_entity and current_entity["type"] == entity_type:
                current_entity["end_tok"] = i + 1
            else:
                # Orphan I-tag or type mismatch — treat as B-tag
                if current_entity:
                    entities.append(_finalize_entity(current_entity, token_offsets, tokens))
                current_entity = {"type": entity_type, "start_tok": i, "end_tok": i + 1}
        else:
            if current_entity:
                entities.append(_finalize_entity(current_entity, token_offsets, tokens))
                current_entity = None

    if current_entity:
        entities.append(_finalize_entity(current_entity, token_offsets, tokens))

    return {"text": text, "entities": entities}


def _finalize_entity(entity_info, token_offsets, tokens):
    """Convert token-range entity to character-level span."""
    start_char = token_offsets[entity_info["start_tok"]][0]
    end_char = token_offsets[entity_info["end_tok"] - 1][1]
    entity_text = " ".join(tokens[entity_info["start_tok"] : entity_info["end_tok"]])
    return {
        "text": entity_text,
        "start": start_char,
        "end": end_char,
        "type": entity_info["type"],
    }


# ── Dataset Loading ─────────────────────────────────────────

# Entity types that are unique/characteristic to each domain
# Used to filter the combined parquet dataset into per-domain splits
DOMAIN_SIGNATURE_TYPES = {
    "ai": {"field", "task", "algorithm", "researcher", "metrics", "programlang", "product"},
    "literature": {"book", "writer", "poem", "magazine", "literarygenre"},
    "music": {"musicgenre", "song", "band", "album", "musicalartist", "musicalinstrument"},
    "politics": {"politician", "politicalparty", "election"},
    "science": {
        "scientist",
        "discipline",
        "enzyme",
        "protein",
        "chemicalcompound",
        "chemicalelement",
        "astronomicalobject",
        "theory",
    },
}

# Expected train sizes per domain (from the CrossNER paper)
DOMAIN_TRAIN_SIZES = {
    "ai": 100,
    "literature": 100,
    "music": 100,
    "politics": 200,
    "science": 200,
}

# All entity types per domain (including shared ones like person, location, etc.)
DOMAIN_ALL_TYPES = {
    "ai": {
        "field",
        "task",
        "product",
        "algorithm",
        "researcher",
        "metrics",
        "university",
        "country",
        "person",
        "organisation",
        "location",
        "programlang",
        "conference",
        "misc",
    },
    "literature": {
        "book",
        "writer",
        "award",
        "poem",
        "event",
        "magazine",
        "person",
        "location",
        "organisation",
        "country",
        "literarygenre",
        "misc",
    },
    "music": {
        "musicgenre",
        "song",
        "band",
        "album",
        "musicalartist",
        "musicalinstrument",
        "award",
        "event",
        "country",
        "location",
        "organisation",
        "person",
        "misc",
    },
    "politics": {
        "politician",
        "person",
        "organisation",
        "politicalparty",
        "event",
        "election",
        "country",
        "location",
        "misc",
    },
    "science": {
        "scientist",
        "person",
        "university",
        "organisation",
        "country",
        "location",
        "discipline",
        "enzyme",
        "protein",
        "chemicalcompound",
        "chemicalelement",
        "event",
        "astronomicalobject",
        "academicjournal",
        "award",
        "theory",
        "misc",
    },
}


def _get_row_entity_types(row, tag_names):
    """Get the set of entity types present in a row (without full span conversion)."""
    types = set()
    for tag_id in row["ner_tags"]:
        name = tag_names[tag_id]
        if name.startswith("B-"):
            types.add(name[2:])
    return types


def _classify_domain(row_types, conll_types=None):
    """Classify a row into a domain based on its entity types."""
    # Skip rows with only shared entity types (person, location, etc.)
    for domain, sig_types in DOMAIN_SIGNATURE_TYPES.items():
        if row_types & sig_types:
            return domain
    return None


def load_crossner(domain):
    """Load CrossNER for a specific domain, converting BIO → spans.

    Loads the combined parquet dataset and filters to the requested domain
    based on domain-characteristic entity types.

    Returns (train_data, test_data, entity_types).
    """
    try:
        from datasets import load_dataset
    except ImportError:
        print("ERROR: pip install datasets")
        sys.exit(1)

    ds = load_dataset("DFKI-SLT/cross_ner", revision="refs/convert/parquet")
    tag_names = ds["train"].features["ner_tags"].feature.names

    domain_types = DOMAIN_ALL_TYPES.get(domain, set())

    def filter_and_convert(split):
        records = []
        for row in split:
            row_types = _get_row_entity_types(row, tag_names)
            row_domain = _classify_domain(row_types)
            if row_domain == domain:
                record = convert_bio_to_spans(row, tag_names)
                # Filter entities to only this domain's types
                record["entities"] = [e for e in record["entities"] if e["type"] in domain_types]
                if record["entities"]:
                    records.append(record)
        return records

    train = filter_and_convert(ds["train"])
    test = filter_and_convert(ds["test"])

    # Extract entity types actually present
    entity_types = set()
    for record in train + test:
        for ent in record["entities"]:
            entity_types.add(ent["type"])

    return train, test, sorted(entity_types)


# ── Few-Shot Sampling ───────────────────────────────────────


def sample_ner_fewshot(train_data, shots, seed=42):
    """Sample examples ensuring entity type coverage.

    Strategy: greedily pick examples covering uncovered types first,
    then fill remaining with random examples.

    Returns (train_sample, eval_remaining).
    """
    rng = random.Random(seed)

    all_types = set()
    for record in train_data:
        for ent in record["entities"]:
            all_types.add(ent["type"])

    selected = []
    covered_types = set()
    remaining = list(train_data)
    rng.shuffle(remaining)

    # Phase 1: cover all entity types
    while covered_types != all_types and remaining and len(selected) < shots:
        best_idx = 0
        best_new = 0
        for i, record in enumerate(remaining):
            record_types = {ent["type"] for ent in record["entities"]}
            new_types = len(record_types - covered_types)
            if new_types > best_new:
                best_new = new_types
                best_idx = i
        chosen = remaining.pop(best_idx)
        selected.append(chosen)
        covered_types.update(ent["type"] for ent in chosen["entities"])

    # Phase 2: fill remaining randomly
    rng.shuffle(remaining)
    while len(selected) < shots and remaining:
        selected.append(remaining.pop(0))

    return selected, remaining


# ── Per-Domain Benchmark ────────────────────────────────────


def run_domain_benchmark(domain, args, client):
    """Run benchmark for a single CrossNER domain."""
    from rulechef import RuleChef
    from rulechef.core import Dataset, Example, RuleFormat, Task, TaskType
    from rulechef.evaluation import evaluate_dataset

    print(f"\nLoading CrossNER/{domain}...")
    train_all, test_all, entity_types = load_crossner(domain)
    print(f"  Train: {len(train_all)}, Test: {len(test_all)}, Entity types: {len(entity_types)}")
    print(f"  Types: {', '.join(entity_types)}")

    # Few-shot sample or use full train set
    if args.shots and args.shots < len(train_all):
        train_sample, eval_data = sample_ner_fewshot(train_all, args.shots, args.seed)
    else:
        rng = random.Random(args.seed)
        shuffled = list(train_all)
        rng.shuffle(shuffled)
        split = max(1, len(shuffled) // 5)  # 80/20 train/eval
        eval_data = shuffled[:split]
        train_sample = shuffled[split:]

    print(f"  Train sample: {len(train_sample)}, Eval: {len(eval_data)}")

    # Limit test set
    test_data = list(test_all)
    if args.test_limit:
        rng = random.Random(args.seed)
        rng.shuffle(test_data)
        test_data = test_data[: args.test_limit]
        print(f"  Test subset: {len(test_data)} (limited)")
    else:
        print(f"  Test: {len(test_data)} (full)")

    # Configure task
    task = Task(
        name=f"CrossNER {domain.upper()}",
        description=(
            f"Extract named entities from {domain} domain text. "
            f"Entity types: {', '.join(entity_types)}"
        ),
        input_schema={"text": "str"},
        output_schema={"entities": [{"text": "str", "start": "int", "end": "int", "type": "str"}]},
        type=TaskType.NER,
        text_field="text",
    )

    format_map = {
        "code": [RuleFormat.CODE],
        "regex": [RuleFormat.REGEX],
        "both": [RuleFormat.REGEX, RuleFormat.CODE],
    }
    allowed_formats = format_map.get(args.format, [RuleFormat.REGEX])

    import tempfile

    from rulechef.training_logger import TrainingDataLogger

    storage_dir = tempfile.mkdtemp(prefix=f"rulechef_crossner_{domain}_")

    # Training logger — captures all LLM calls for distillation
    log_path = Path(args.output).parent / f"training_log_crossner_{domain}.jsonl"
    logger = TrainingDataLogger(
        str(log_path),
        run_metadata={
            "benchmark": "crossner",
            "domain": domain,
            "model": args.model,
            "format": args.format,
        },
    )
    print(f"  Training log: {log_path}")

    coordinator = None
    if args.agentic:
        from rulechef.coordinator import AgenticCoordinator

        coordinator = AgenticCoordinator(
            client,
            model=args.model,
            prune_after_learn=False,
        )

    chef = RuleChef(
        task=task,
        client=client,
        dataset_name=f"crossner_{domain}_bench",
        storage_path=storage_dir,
        allowed_formats=allowed_formats,
        model=args.model,
        use_grex=not args.no_grex,
        max_rules=args.max_rules,
        max_samples=args.max_samples,
        coordinator=coordinator,
        training_logger=logger,
    )

    # Add training examples
    print(f"\nAdding {len(train_sample)} training examples...")
    t0 = time.time()
    for record in train_sample:
        chef.add_example(
            {"text": record["text"]},
            {"entities": record["entities"]},
        )
    t_add = time.time() - t0
    print(f"  Done ({t_add:.1f}s)")

    # Build eval dataset
    eval_dataset = Dataset(name=f"crossner_{domain}_eval", task=task)
    for record in eval_data:
        eval_dataset.examples.append(
            Example(
                id=str(uuid.uuid4())[:8],
                input={"text": record["text"]},
                expected_output={"entities": record["entities"]},
                source="benchmark",
            )
        )

    # Learn rules
    print(f"\nLearning rules (model={args.model})...")
    t0 = time.time()
    result = chef.learn_rules(run_evaluation=False)
    t_learn = time.time() - t0

    if result is None:
        print("  ERROR: Learning failed!")
        return None

    rules, _ = result
    print(f"  Synthesis: {len(rules)} rules ({t_learn:.1f}s)")

    # Refine
    iteration_metrics = []

    def on_iteration(iteration, iter_rules, eval_result):
        iteration_metrics.append(
            {
                "iteration": iteration,
                "num_rules": len(iter_rules),
                "micro_f1": eval_result.micro_f1,
                "micro_precision": eval_result.micro_precision,
                "micro_recall": eval_result.micro_recall,
            }
        )

    if args.max_iterations > 0 and len(eval_data) > 0:
        print(
            f"\nRefining ({len(eval_data)} eval examples, max {args.max_iterations} iterations)..."
        )
        t0_refine = time.time()
        rules, refine_eval = chef.learner.evaluate_and_refine(
            rules,
            eval_dataset,
            max_iterations=args.max_iterations,
            coordinator=chef.coordinator,
            iteration_callback=on_iteration,
        )
        t_refine = time.time() - t0_refine
        t_learn += t_refine
        print(f"  Refinement: {len(rules)} rules ({t_refine:.1f}s)")
        if refine_eval:
            print(f"  Eval F1: {refine_eval.micro_f1:.1%}")

    # Rule pruning via audit (if enabled)
    if args.prune and coordinator and hasattr(coordinator, "audit_rules"):
        import re as re_mod

        # Temporarily enable pruning for the audit call
        coordinator.prune_after_learn = True
        # Store rules in chef so get_rule_metrics can evaluate them
        chef.dataset.rules = rules
        rule_metrics = chef.get_rule_metrics(verbose=False)
        audit = coordinator.audit_rules(rules, rule_metrics)
        coordinator.prune_after_learn = False
        if audit.actions:
            pre_audit_rules = list(rules)
            rules_by_id = {r.id: r for r in rules}
            changed = False
            for action in audit.actions:
                if action.action == "merge" and len(action.rule_ids) >= 2:
                    sources = [rules_by_id[rid] for rid in action.rule_ids if rid in rules_by_id]
                    if len(sources) < 2:
                        continue
                    if action.merged_pattern:
                        try:
                            re_mod.compile(action.merged_pattern)
                        except re_mod.error:
                            continue
                    from rulechef.core import Rule

                    base = max(sources, key=lambda r: r.priority)
                    merged = Rule(
                        id=str(uuid.uuid4())[:8],
                        name=action.merged_name or base.name,
                        description=f"Merged: {action.reason}",
                        format=base.format,
                        content=action.merged_pattern or base.content,
                        priority=base.priority,
                        output_template=base.output_template,
                        output_key=base.output_key,
                    )
                    rules = [r for r in rules if r.id not in action.rule_ids]
                    rules.append(merged)
                    rules_by_id = {r.id: r for r in rules}
                    changed = True
                elif action.action == "remove":
                    for rid in action.rule_ids:
                        if rid in rules_by_id:
                            rules = [r for r in rules if r.id != rid]
                            del rules_by_id[rid]
                            changed = True
            if changed:
                # Safety net: revert if F1 dropped on eval set
                chef.dataset.rules = rules
                from rulechef.evaluation import evaluate_dataset as eval_ds

                post_eval = eval_ds(rules, eval_dataset, chef.learner._apply_rules)
                pre_eval = eval_ds(pre_audit_rules, eval_dataset, chef.learner._apply_rules)
                if post_eval.micro_f1 < pre_eval.micro_f1 - 0.01:
                    print(
                        f"  Audit dropped F1 ({pre_eval.micro_f1:.2f} -> {post_eval.micro_f1:.2f}), reverting"
                    )
                    rules = pre_audit_rules
                else:
                    print(f"  Audit: {len(pre_audit_rules)} -> {len(rules)} rules")

    # Final evaluation on held-out test
    test_dataset = Dataset(name=f"crossner_{domain}_test", task=task)
    for record in test_data:
        test_dataset.examples.append(
            Example(
                id=str(uuid.uuid4())[:8],
                input={"text": record["text"]},
                expected_output={"entities": record["entities"]},
                source="benchmark",
            )
        )

    print(f"\nEvaluating on test set ({len(test_data)} examples)...")
    t0 = time.time()
    test_eval = evaluate_dataset(rules, test_dataset, chef.learner._apply_rules)
    t_eval = time.time() - t0

    # Print results
    print(f"\n  Micro F1:        {test_eval.micro_f1:.1%}")
    print(f"  Micro Precision: {test_eval.micro_precision:.1%}")
    print(f"  Micro Recall:    {test_eval.micro_recall:.1%}")
    print(f"  Rules:           {len(rules)}")
    print(f"  Learning time:   {t_learn:.1f}s")
    print(f"  Eval time:       {t_eval:.3f}s ({t_eval / len(test_data) * 1000:.2f}ms/query)")
    print(f"  LLM calls:       {logger.count} ({logger.stats})")

    # Per-type breakdown
    if test_eval.per_class:
        sorted_types = sorted(test_eval.per_class, key=lambda c: c.f1, reverse=True)
        print("\n  Per-type (top 5):")
        for cm in sorted_types[:5]:
            print(
                f"    {cm.label:30s} F1={cm.f1:.0%} P={cm.precision:.0%} R={cm.recall:.0%} "
                f"(TP={cm.tp} FP={cm.fp} FN={cm.fn})"
            )
        if len(sorted_types) > 5:
            print("  Per-type (bottom 5):")
            for cm in sorted_types[-5:]:
                print(
                    f"    {cm.label:30s} F1={cm.f1:.0%} P={cm.precision:.0%} R={cm.recall:.0%} "
                    f"(TP={cm.tp} FP={cm.fp} FN={cm.fn})"
                )

    # Cleanup
    import shutil

    shutil.rmtree(storage_dir, ignore_errors=True)

    return {
        "domain": domain,
        "config": {
            "shots": args.shots or len(train_sample),
            "train_size": len(train_sample),
            "eval_size": len(eval_data),
            "test_size": len(test_data),
            "entity_types": entity_types,
        },
        "results": {
            "micro_precision": test_eval.micro_precision,
            "micro_recall": test_eval.micro_recall,
            "micro_f1": test_eval.micro_f1,
            "macro_f1": test_eval.macro_f1,
            "num_rules": len(rules),
            "learning_time_s": round(t_learn, 1),
            "eval_time_s": round(t_eval, 3),
            "per_query_ms": round(t_eval / len(test_data) * 1000, 2),
        },
        "per_class": [
            {
                "label": cm.label,
                "precision": cm.precision,
                "recall": cm.recall,
                "f1": cm.f1,
                "tp": cm.tp,
                "fp": cm.fp,
                "fn": cm.fn,
            }
            for cm in (test_eval.per_class or [])
        ],
        "iteration_metrics": iteration_metrics,
        "rules": [
            {
                "name": r.name,
                "format": r.format.value,
                "content": r.content,
                "priority": r.priority,
                "output_template": r.output_template,
                "output_key": r.output_key,
            }
            for r in rules
        ],
    }


# ── Main Benchmark Runner ──────────────────────────────────


def run_benchmark(args):
    from openai import OpenAI

    client = OpenAI(
        api_key=os.environ.get("OPENAI_API_KEY"),
        base_url=args.base_url,
    )

    domains = [d.strip() for d in args.domains.split(",")] if args.domains else CROSSNER_DOMAINS
    invalid = set(domains) - set(CROSSNER_DOMAINS)
    if invalid:
        print(f"ERROR: Unknown domains: {invalid}. Valid: {CROSSNER_DOMAINS}")
        sys.exit(1)

    all_results = {}
    for domain in domains:
        print(f"\n{'#' * 70}")
        print(f"# DOMAIN: {domain.upper()}")
        print(f"{'#' * 70}")

        result = run_domain_benchmark(domain, args, client)
        if result:
            all_results[domain] = result

    # Summary comparison table
    print(f"\n{'=' * 80}")
    print("CROSSNER BENCHMARK RESULTS")
    print(f"{'=' * 80}")
    print(f"  Model: {args.model}")
    print(f"  Format: {args.format}")
    print(f"  Grex: {not args.no_grex}")
    print(f"  Agentic: {args.agentic}")
    print()
    print(
        f"  {'Domain':<12} {'RuleChef F1':>12} {'GLiNER2':>10} {'GPT-4o':>10} "
        f"{'GLiNER-M':>10} {'Rules':>8} {'ms/query':>10}"
    )
    print(f"  {'-' * 72}")

    for domain in domains:
        if domain not in all_results:
            continue
        r = all_results[domain]["results"]
        b = PUBLISHED_BASELINES.get(domain, {})
        print(
            f"  {domain:<12} {r['micro_f1']:>11.1%} {b.get('GLiNER2', 0):>10.1%} "
            f"{b.get('GPT-4o', 0):>10.1%} {b.get('GLiNER-M', 0):>10.1%} "
            f"{r['num_rules']:>8} {r['per_query_ms']:>9.2f}"
        )

    if len(all_results) > 1:
        avg_f1 = sum(r["results"]["micro_f1"] for r in all_results.values()) / len(all_results)
        avg_gliner2 = sum(
            PUBLISHED_BASELINES.get(d, {}).get("GLiNER2", 0) for d in all_results
        ) / len(all_results)
        print(f"  {'-' * 72}")
        print(f"  {'AVERAGE':<12} {avg_f1:>11.1%} {avg_gliner2:>10.1%}")

    print(f"{'=' * 80}")

    # Save results
    output = {
        "config": {
            "model": args.model,
            "format": args.format,
            "max_rules": args.max_rules,
            "max_samples": args.max_samples,
            "max_iterations": args.max_iterations,
            "seed": args.seed,
            "use_grex": not args.no_grex,
            "agentic": args.agentic,
        },
        "domains": all_results,
        "published_baselines": PUBLISHED_BASELINES,
    }

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(output, indent=2))
    print(f"\nResults saved to {output_path}")


# ── CLI ─────────────────────────────────────────────────────


def main():
    parser = argparse.ArgumentParser(
        description="CrossNER Named Entity Recognition Benchmark for RuleChef"
    )
    parser.add_argument(
        "--domains",
        type=str,
        default=None,
        help=f"Comma-separated domains (default: all). Options: {', '.join(CROSSNER_DOMAINS)}",
    )
    parser.add_argument(
        "--shots",
        type=int,
        default=None,
        help="Training examples (default: use full train set)",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="gpt-4o-mini",
        help="LLM model for rule synthesis (default: gpt-4o-mini)",
    )
    parser.add_argument(
        "--base-url",
        type=str,
        default=None,
        help="OpenAI-compatible base URL",
    )
    parser.add_argument(
        "--format",
        type=str,
        default="regex",
        choices=["regex", "code", "both"],
        help="Rule format (default: regex)",
    )
    parser.add_argument(
        "--max-rules",
        type=int,
        default=100,
        help="Max rules per synthesis (default: 100)",
    )
    parser.add_argument(
        "--max-samples",
        type=int,
        default=200,
        help="Max training examples in LLM prompt (default: 200)",
    )
    parser.add_argument(
        "--max-iterations",
        type=int,
        default=3,
        help="Max refinement iterations (default: 3)",
    )
    parser.add_argument(
        "--test-limit",
        type=int,
        default=None,
        help="Limit test set size for quick runs",
    )
    parser.add_argument("--seed", type=int, default=42, help="Random seed (default: 42)")
    parser.add_argument(
        "--output",
        type=str,
        default="benchmarks/results_crossner.json",
        help="Save results to JSON (default: benchmarks/results_crossner.json)",
    )
    parser.add_argument(
        "--agentic",
        action="store_true",
        help="Use AgenticCoordinator for LLM-guided refinement",
    )
    parser.add_argument(
        "--no-grex",
        action="store_true",
        help="Disable grex regex pattern suggestions",
    )
    parser.add_argument(
        "--prune",
        action="store_true",
        help="Enable LLM-powered rule pruning/merging after refinement (requires --agentic)",
    )

    args = parser.parse_args()
    run_benchmark(args)


if __name__ == "__main__":
    main()
