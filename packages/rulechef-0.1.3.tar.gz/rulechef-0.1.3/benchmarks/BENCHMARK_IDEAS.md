# Benchmark Ideas

## 1. When2Call — Binary Tool-Call Pre-Filter

**Dataset:** NVIDIA When2Call (CC-BY-4.0)
- Test: 3,652 MCQ examples (from `nvidia/When2Call` on HuggingFace)
- Train: 15,000 SFT examples

**Task:** Binary classification — "does this query need a tool call or not?"
- `cannot_answer` (35.5%) → rules detect this, skip the LLM entirely
- `needs_tool` (64.5%) → default, pass through to the LLM

**Why it works for regex:**
The `cannot_answer` signal is a mismatch between query topic and available tool names.
E.g., "trending topics in NYC" but tools: `[get_stations_within_1_km]` — clearly unrelated.
Regex can detect: query mentions "weather" but no tool name contains "weather".

**Training data:** 7,572 `cannot_answer` examples in SFT split. No test leakage (1 overlap).

**Comparison:** GPT-4 Turbo gets 64.6% Macro F1 on full 4-class When2Call.
We benchmark the binary subtask: precision/recall/F1 for `cannot_answer` detection.

**Story:** "Use RuleChef as a <1ms pre-filter to catch obvious no-tool queries before they reach the LLM. Save 35% of LLM calls on queries that clearly don't need tools."

**Loading:**
```python
from datasets import load_dataset
mcq = load_dataset("nvidia/When2Call", "test", split="mcq")       # 3,652 test
sft = load_dataset("nvidia/When2Call", "train_sft", split="train") # 15,000 train
```

---

## 2. Progressive Learning Curve — LLM Offloading Over Time

**Concept:** Show how RuleChef progressively learns to replace LLM calls as it sees more examples.

**Setup:**
1. Take a dataset with gold labels (e.g., NER, classification, extraction)
2. Process examples one by one with an LLM (simulating production)
3. Feed each LLM result to RuleChef as a training example
4. Periodically: learn rules from accumulated examples, measure rule coverage on a held-out test set
5. Plot: "% of test cases rules handle correctly" vs "# examples seen"

**What to measure at each checkpoint:**
- Rule accuracy on test set (what % of cases rules get right)
- Rule coverage (what % of cases rules produce any output for)
- LLM calls saved (= rule coverage × rule accuracy on covered cases)
- Number of rules learned
- Rule inference time

**Expected curve:**
```
Rule coverage (%)
100% |
 80% |                              ●────●
 60% |                    ●────●───●
 40% |              ●────●
 20% |        ●────●
  0% |──●────●
     +--+--+--+--+--+--+--+--+-->
      0  10  25  50 100 200 500  examples seen
```

**Datasets to use:**
- Banking77 (classification, 77 classes, large test set)
- CrossNER (NER, 5 domains)
- Any extraction/transformation task

**The story:** "After seeing just 100 examples, RuleChef rules correctly handle 50% of cases at <1ms. You only need the LLM for the other 50%. As more examples flow through, rules keep improving — progressively offloading work from the LLM."

**Why this is compelling:**
- Shows real-world workflow, not just static benchmark comparison
- Demonstrates the learning curve (how fast rules catch up)
- Quantifies actual cost savings over time
- Not competing against BERT/GPT scores — showing a fundamentally different value prop
- Every ML practitioner understands "reduce LLM calls by X%"

**Implementation sketch:**
```python
for checkpoint in [10, 25, 50, 100, 200, 500]:
    # Take first `checkpoint` examples as training
    train = gold_data[:checkpoint]

    # Learn rules
    chef = RuleChef(task, client, ...)
    for ex in train:
        chef.add_example(ex)
    rules, metrics = chef.learn_rules()

    # Evaluate rules on held-out test set
    results = evaluate(rules, test_data)

    # Record: coverage, accuracy, rules_count, latency
    curve.append({
        "examples_seen": checkpoint,
        "rule_coverage": results.coverage,
        "rule_accuracy": results.accuracy,
        "llm_calls_saved": results.coverage * results.accuracy,
        "num_rules": len(rules),
        "avg_latency_ms": results.latency,
    })
```

**Bonus visualization:** Side-by-side with LLM cost
```
Cost per 1000 queries
$10  |████  LLM-only
 $8  |████
 $6  |████  ████
 $4  |      ████  ████
 $2  |            ████  ████
 $0  |                  ████
     +----+----+----+----+--->
       0   100  200  500  examples seen by RuleChef
```
