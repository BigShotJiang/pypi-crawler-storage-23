import logging
import os
import sys

from modulitiz_nano.ModuloDate import ModuloDate
from modulitiz_nano.files.ModuloFiles import ModuloFiles


class ModuloLogging(logging.Logger):
	CARTELLA_LOG="logs"
	NOMEFILE_PREFIX="log"
	NOMEFILE_EXT=".txt"
	
	MAX_FILE_SIZE=10*1024*1024
	"""
	Max file size for logs in bytes
	"""
	
	def __init__(self,nomefileFullPath:str|None=None,cartellaBase:str|None=None,isDebug:bool=False):
		super().__init__("modulitiz")
		logLevel=logging.INFO if not isDebug else logging.DEBUG
		self.setLevel(logLevel)
		# handlers
		self.addHandler(self.createConsoleHandler(logLevel))
		fileHandler=self.createFileHandler(nomefileFullPath,cartellaBase,isDebug)
		if fileHandler is not None:
			self.addHandler(fileHandler)
	
	def createConsoleHandler(self,logLevel:int) -> logging.StreamHandler:
		consoleHandler=logging.StreamHandler(sys.stdout)
		consoleHandler.setLevel(logLevel)
		consoleHandler.setFormatter(self.__getOutputFormatter(False))
		return consoleHandler
	
	def createFileHandler(self,nomefileFullPath: str|None,cartellaBase: str|None,isDebug: bool) -> logging.FileHandler|None:
		# controllo se loggare anche su file
		if nomefileFullPath is None and cartellaBase is None:
			return None
		# controllo che la cartella dei log esista
		if cartellaBase is None:
			cartellaBase=self.CARTELLA_LOG
		else:
			cartellaBase=ModuloFiles.pathJoin(cartellaBase,self.CARTELLA_LOG)
		if not os.path.exists(cartellaBase):
			os.makedirs(cartellaBase,exist_ok=True)
		
		# creo il nome del file
		if nomefileFullPath is None:
			nomefileFullPath=ModuloFiles.pathJoin(cartellaBase,self.NOMEFILE_PREFIX+self.NOMEFILE_EXT)
		# se il file e' troppo grande ne creo uno nuovo
		if ModuloFiles.getFileSize(nomefileFullPath)>=self.MAX_FILE_SIZE:
			os.rename(nomefileFullPath,nomefileFullPath+"_"+ModuloDate.dateToString(None,ModuloDate.FORMATO_DATA_ORA_NOMEFILE))
		fileHandler=logging.FileHandler(nomefileFullPath)
		fileHandler.setFormatter(self.__getOutputFormatter(isDebug))
		return fileHandler
	
	def close(self):
		self.handlers.clear()
	
	@staticmethod
	def __getOutputFormatter(isDebug:bool)->logging.Formatter:
		pattern='%(asctime)s [%(name)s] '+('[%(filename)s:%(lineno)s]\t' if isDebug is True else '')+'[%(levelname)s]\t%(message)s'
		return logging.Formatter(pattern)
