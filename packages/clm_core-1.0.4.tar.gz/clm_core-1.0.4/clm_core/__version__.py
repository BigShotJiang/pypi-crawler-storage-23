__title__ = "clm"
__description__ = "Natural Language compressor"
__version__ = "1.0.4"
