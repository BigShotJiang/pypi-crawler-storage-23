// SPDX-FileCopyrightText: 2023 Angus Morrison <github@angus-morrison.com>
// SPDX-FileCopyrightText: 2023 Helge Eichhorn <git@helgeeichhorn.de>
//
// SPDX-License-Identifier: MPL-2.0

//! Useful constants for the `i32` type.

/*
 * Julian date constants
 */

/// Julian Date at J2000 epoch.
pub const JD_J2000: i32 = 2451545;
