"""Tool System（协议 + 注册表 + 内置工具）。"""

from __future__ import annotations

__all__ = [
    "protocol",
    "registry",
]

