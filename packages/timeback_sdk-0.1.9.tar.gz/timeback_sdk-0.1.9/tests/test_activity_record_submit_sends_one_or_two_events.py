"""Tests for activity completion pipeline event emission behavior.

Verifies that:
- record_completion() sends exactly 1 event (ActivityCompletedEvent)
- send_time_spent() sends exactly 1 event (TimeSpentEvent)
- preview mode skips sending for record_completion()
- hook returning None skips sending for record_completion()
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from timeback.server.handlers.activity.submit import record_completion, send_time_spent
from timeback.server.types import (
    ActivityHandlerDeps,
    ActivityUserInfo,
    CompletionPayload,
    TimebackHooks,
)
from timeback.shared.types import SubjectGradeCourseRef


@dataclass
class MockAppConfig:
    """Mock app config for testing."""

    name: str = "Test App"
    sensor: str | None = "https://sensor.example.com"
    courses: list[dict[str, Any]] = field(
        default_factory=lambda: [
            {
                "subject": "Math",
                "grade": 3,
                "ids": {"staging": "course-123", "production": "course-456"},
                "sensor": "https://sensor.example.com",
            }
        ]
    )


@dataclass
class MockApiCredentials:
    """Mock API credentials for testing."""

    client_id: str = "test-client-id"
    client_secret: str = "test-client-secret"


def _make_mock_client() -> MagicMock:
    """Create a mock TimebackClient with necessary attributes."""
    mock_client = MagicMock()

    # Mock oneroster transport
    mock_transport = MagicMock()
    mock_transport.base_url = "https://api.example.com"
    mock_transport.paths = MagicMock()
    mock_transport.paths.rostering = "/ims/oneroster/rostering/v1p2"
    mock_client.oneroster.get_transport.return_value = mock_transport

    # Mock caliper events send
    mock_client.caliper.events.send = AsyncMock()

    # Mock close
    mock_client.close = AsyncMock()

    return mock_client


def _make_mock_deps() -> ActivityHandlerDeps:
    """Create mock dependencies."""
    return ActivityHandlerDeps(
        compute_progress=AsyncMock(return_value=None),
        maybe_write_completion_entry=AsyncMock(),
    )


def _make_completion_payload() -> CompletionPayload:
    """Create a valid completion payload."""
    return CompletionPayload(
        id="lesson-123",
        name="Test Activity",
        course=SubjectGradeCourseRef(subject="Math", grade=3),
        ended_at="2024-01-15T10:30:00Z",
        metrics={"totalQuestions": 10, "correctQuestions": 8, "xpEarned": 50},
    )


def _make_valid_body() -> dict[str, Any]:
    """Create a valid request body."""
    return {
        "id": "lesson-123",
        "name": "Test Activity",
        "course": {"subject": "Math", "grade": 3},
        "endedAt": "2024-01-15T10:30:00Z",
        "metrics": {"totalQuestions": 10, "correctQuestions": 8, "xpEarned": 50},
    }


class TestRecordCompletionEventEmission:
    """Tests for record_completion event emission behavior."""

    @pytest.mark.asyncio
    async def test_record_completion_sends_one_event(self) -> None:
        """record_completion() should send exactly 1 event (ActivityCompletedEvent)."""
        mock_client = _make_mock_client()
        mock_deps = _make_mock_deps()

        with (
            patch(
                "timeback.server.handlers.activity.submit.resolve_timeback_id",
                new_callable=AsyncMock,
                return_value="timeback-user-123",
            ),
            patch(
                "timeback.server.handlers.activity.submit.resolve_attempt_number",
                new_callable=AsyncMock,
                return_value=1,
            ),
        ):
            await record_completion(
                user_info=ActivityUserInfo(email="test@example.com"),
                body=_make_valid_body(),
                payload=_make_completion_payload(),
                course_config=MockAppConfig().courses[0],
                sensor="https://sensor.example.com",
                env="staging",
                api_env="staging",
                api=MockApiCredentials(),
                app_config=MockAppConfig(),
                get_client=lambda: mock_client,
                hooks=None,
                preview_requested=False,
                deps=mock_deps,
            )

            # Verify send was called once with exactly 1 event
            mock_client.caliper.events.send.assert_called_once()
            call_args = mock_client.caliper.events.send.call_args
            events_sent = call_args[0][1]  # Second positional arg is the events list
            assert len(events_sent) == 1, f"Expected 1 event, got {len(events_sent)}"

    @pytest.mark.asyncio
    async def test_preview_mode_skips_send(self) -> None:
        """When preview_requested=True, should not send any events."""
        mock_client = _make_mock_client()
        mock_deps = _make_mock_deps()

        with (
            patch(
                "timeback.server.handlers.activity.submit.resolve_timeback_id",
                new_callable=AsyncMock,
                return_value="timeback-user-123",
            ),
            patch(
                "timeback.server.handlers.activity.submit.resolve_attempt_number",
                new_callable=AsyncMock,
                return_value=1,
            ),
        ):
            result = await record_completion(
                user_info=ActivityUserInfo(email="test@example.com"),
                body=_make_valid_body(),
                payload=_make_completion_payload(),
                course_config=MockAppConfig().courses[0],
                sensor="https://sensor.example.com",
                env="staging",
                api_env="staging",
                api=MockApiCredentials(),
                app_config=MockAppConfig(),
                get_client=lambda: mock_client,
                hooks=None,
                preview_requested=True,
                deps=mock_deps,
            )

            # Verify send was NOT called
            mock_client.caliper.events.send.assert_not_called()

            # Verify result has preview=True and contains the built event
            assert result.success is True
            assert result.preview is True
            assert result.data.event is not None

    @pytest.mark.asyncio
    async def test_hook_returning_none_skips_send_and_returns_preview(self) -> None:
        """
        Regression test: Hook returning None should skip send AND return preview data.

        When before_activity_send hook returns None, the event should NOT be sent,
        AND the result should have preview=True with the built event data.
        """
        mock_client = _make_mock_client()
        mock_deps = _make_mock_deps()

        # Hook that returns None to skip sending
        def skip_hook(_data: object) -> None:
            return None

        hooks = TimebackHooks(before_activity_send=skip_hook)

        with (
            patch(
                "timeback.server.handlers.activity.submit.resolve_timeback_id",
                new_callable=AsyncMock,
                return_value="timeback-user-123",
            ),
            patch(
                "timeback.server.handlers.activity.submit.resolve_attempt_number",
                new_callable=AsyncMock,
                return_value=1,
            ),
        ):
            result = await record_completion(
                user_info=ActivityUserInfo(email="test@example.com"),
                body=_make_valid_body(),
                payload=_make_completion_payload(),
                course_config=MockAppConfig().courses[0],
                sensor="https://sensor.example.com",
                env="staging",
                api_env="staging",
                api=MockApiCredentials(),
                app_config=MockAppConfig(),
                get_client=lambda: mock_client,
                hooks=hooks,
                preview_requested=False,
                deps=mock_deps,
            )

            # Verify send was NOT called (hook skipped it)
            mock_client.caliper.events.send.assert_not_called()

            # Verify result has preview=True
            assert result.success is True
            assert result.preview is True
            assert result.data.event is not None


class TestSendTimeSpentEventEmission:
    """Tests for send_time_spent event emission behavior."""

    @pytest.mark.asyncio
    async def test_send_time_spent_sends_one_event(self) -> None:
        """send_time_spent() should send exactly 1 event (TimeSpentEvent)."""
        mock_client = _make_mock_client()

        with (
            patch(
                "timeback.server.handlers.activity.submit.resolve_timeback_id",
                new_callable=AsyncMock,
                return_value="timeback-user-123",
            ),
        ):
            await send_time_spent(
                user_info=ActivityUserInfo(email="test@example.com"),
                activity_id="lesson-123",
                activity_name="Test Activity",
                course_selector=SubjectGradeCourseRef(subject="Math", grade=3),
                course_config=MockAppConfig().courses[0],
                sensor="https://sensor.example.com",
                api_env="staging",
                api=MockApiCredentials(),
                app_config=MockAppConfig(),
                get_client=lambda: mock_client,
                elapsed_ms=1800000,
                paused_ms=60000,
                ended_at="2024-01-15T10:30:00Z",
                run_id="550e8400-e29b-41d4-a716-446655440000",
            )

            # Verify send was called once with exactly 1 event
            mock_client.caliper.events.send.assert_called_once()
            call_args = mock_client.caliper.events.send.call_args
            events_sent = call_args[0][1]
            assert len(events_sent) == 1, f"Expected 1 event, got {len(events_sent)}"


class TestRecordCompletionErrorHandling:
    """Tests for record_completion error handling."""

    @pytest.mark.asyncio
    async def test_missing_synced_course_id_raises(self) -> None:
        """Should raise MissingSyncedCourseIdError when course is not synced."""
        from timeback.server.handlers.activity.caliper import MissingSyncedCourseIdError

        mock_deps = _make_mock_deps()

        # Course config without ids
        course_config = {
            "subject": "Math",
            "grade": 3,
            "sensor": "https://sensor.example.com",
            # No "ids" field
        }

        with pytest.raises(MissingSyncedCourseIdError):
            await record_completion(
                user_info=ActivityUserInfo(email="test@example.com"),
                body=_make_valid_body(),
                payload=_make_completion_payload(),
                course_config=course_config,
                sensor="https://sensor.example.com",
                env="staging",
                api_env="staging",
                api=MockApiCredentials(),
                app_config=MockAppConfig(),
                get_client=lambda: _make_mock_client(),
                hooks=None,
                preview_requested=False,
                deps=mock_deps,
            )
