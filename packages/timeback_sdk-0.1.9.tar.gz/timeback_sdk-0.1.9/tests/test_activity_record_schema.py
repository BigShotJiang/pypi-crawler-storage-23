"""Tests for activity record input validation."""

import pytest

from timeback.server.namespaces.activity.record import _to_completion_payload
from timeback.server.namespaces.activity.schema import (
    ActivityRecordValidationError,
    ParsedActivityRecordInput,
    validate_activity_record_input,
)


class TestValidateActivityRecordInput:
    """Tests for activity record input validation."""

    def _valid_input_with_time(self) -> dict:
        """Return a valid input with time provided."""
        return {
            "user": {"email": "student@example.com"},
            "activity": {
                "id": "lesson-123",
                "name": "Algebra Basics",
                "course": {"subject": "Math", "grade": 3},
            },
            "metrics": {
                "total_questions": 10,
                "correct_questions": 8,
                "xp_earned": 50,
            },
            "time": {
                "started_at": "2024-01-15T10:00:00Z",
                "ended_at": "2024-01-15T10:30:00Z",
                "active_ms": 1800000,
                "inactive_ms": 60000,
            },
        }

    def _valid_input_completion_only(self) -> dict:
        """Return a valid input without time (completion-only mode)."""
        return {
            "user": {"email": "student@example.com"},
            "activity": {
                "id": "lesson-123",
                "name": "Algebra Basics",
                "course": {"subject": "Math", "grade": 3},
            },
            "metrics": {
                "xp_earned": 50,
            },
        }

    # ─────────────────────────────────────────────────────────────────────────
    # Valid Input Tests
    # ─────────────────────────────────────────────────────────────────────────

    def test_valid_input_with_time_passes(self) -> None:
        """Valid input with time should pass validation."""
        result = validate_activity_record_input(self._valid_input_with_time())
        assert result.user_email == "student@example.com"
        assert result.activity_id == "lesson-123"
        assert result.has_time is True

    def test_valid_input_completion_only_passes(self) -> None:
        """Valid input without time (completion-only) should pass validation."""
        result = validate_activity_record_input(self._valid_input_completion_only())
        assert result.user_email == "student@example.com"
        assert result.activity_id == "lesson-123"
        assert result.xp_earned == 50
        assert result.has_time is False

    def test_valid_input_with_timeback_id(self) -> None:
        """Input with pre-resolved timeback_id should pass."""
        input_data = self._valid_input_with_time()
        input_data["user"]["timeback_id"] = "tb-123"
        result = validate_activity_record_input(input_data)
        assert result.user_timeback_id == "tb-123"

    def test_valid_input_with_code_based_course(self) -> None:
        """Input with code-based course selector should pass."""
        input_data = self._valid_input_with_time()
        input_data["activity"]["course"] = {"code": "CS-101"}
        result = validate_activity_record_input(input_data)
        assert result.activity_course == {"code": "CS-101"}

    def test_valid_input_with_all_metrics(self) -> None:
        """Input with all metrics should pass."""
        input_data = self._valid_input_with_time()
        input_data["metrics"] = {
            "total_questions": 10,
            "correct_questions": 8,
            "xp_earned": 50.5,
            "pct_complete": 75,
            "mastered_units": 5,
        }
        result = validate_activity_record_input(input_data)
        assert result.total_questions == 10
        assert result.correct_questions == 8
        assert result.xp_earned == 50.5
        assert result.pct_complete == 75
        assert result.mastered_units == 5

    # ─────────────────────────────────────────────────────────────────────────
    # XP Rule Tests
    # ─────────────────────────────────────────────────────────────────────────

    def test_missing_xp_earned_fails_completion_only(self) -> None:
        """Completion-only mode without xp_earned should fail."""
        input_data = {
            "user": {"email": "student@example.com"},
            "activity": {
                "id": "lesson-123",
                "name": "Test",
                "course": {"subject": "Math", "grade": 3},
            },
            "metrics": {},  # No xp_earned
        }
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "xp_earned" in exc_info.value.field

    def test_missing_xp_earned_fails_with_time(self) -> None:
        """Even with time provided, missing xp_earned should fail."""
        input_data = self._valid_input_with_time()
        del input_data["metrics"]["xp_earned"]
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "xp_earned" in exc_info.value.field

    def test_missing_xp_earned_fails_with_time_and_pct_complete(self) -> None:
        """Even with time and pct_complete, xp_earned is still required."""
        input_data = self._valid_input_with_time()
        del input_data["metrics"]["xp_earned"]
        input_data["metrics"]["pct_complete"] = 50
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "xp_earned" in exc_info.value.field

    def test_with_time_and_explicit_xp_earned(self) -> None:
        """With time provided, explicit xp_earned is accepted."""
        input_data = self._valid_input_with_time()
        input_data["metrics"]["xp_earned"] = 100
        result = validate_activity_record_input(input_data)
        assert result.xp_earned == 100

    # ─────────────────────────────────────────────────────────────────────────
    # Required Field Tests
    # ─────────────────────────────────────────────────────────────────────────

    def test_missing_user_fails(self) -> None:
        """Missing user should fail."""
        input_data = self._valid_input_with_time()
        del input_data["user"]
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert exc_info.value.field == "user"

    def test_missing_user_email_fails(self) -> None:
        """Missing user.email should fail."""
        input_data = self._valid_input_with_time()
        del input_data["user"]["email"]
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert exc_info.value.field == "user.email"

    def test_missing_activity_fails(self) -> None:
        """Missing activity should fail."""
        input_data = self._valid_input_with_time()
        del input_data["activity"]
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert exc_info.value.field == "activity"

    def test_missing_activity_id_fails(self) -> None:
        """Missing activity.id should fail."""
        input_data = self._valid_input_with_time()
        del input_data["activity"]["id"]
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "activity.id" in exc_info.value.field

    def test_missing_activity_name_fails(self) -> None:
        """Missing activity.name should fail."""
        input_data = self._valid_input_with_time()
        del input_data["activity"]["name"]
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "activity.name" in exc_info.value.field

    def test_missing_activity_course_fails(self) -> None:
        """Missing activity.course should fail."""
        input_data = self._valid_input_with_time()
        del input_data["activity"]["course"]
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "activity.course" in exc_info.value.field

    # ─────────────────────────────────────────────────────────────────────────
    # Course Selector Tests
    # ─────────────────────────────────────────────────────────────────────────

    def test_invalid_subject_fails(self) -> None:
        """Invalid course.subject should fail."""
        input_data = self._valid_input_with_time()
        input_data["activity"]["course"]["subject"] = "InvalidSubject"
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "subject" in exc_info.value.field

    def test_invalid_grade_range_fails(self) -> None:
        """Grade outside 0-12 range should fail."""
        input_data = self._valid_input_with_time()
        input_data["activity"]["course"]["grade"] = 13
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "grade" in exc_info.value.field

    def test_missing_grade_without_code_fails(self) -> None:
        """Missing grade without code should fail."""
        input_data = self._valid_input_with_time()
        del input_data["activity"]["course"]["grade"]
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "course" in exc_info.value.field

    def test_empty_code_fails(self) -> None:
        """Empty code should fail."""
        input_data = self._valid_input_with_time()
        input_data["activity"]["course"] = {"code": ""}
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "code" in exc_info.value.field

    def test_all_valid_subjects_pass(self) -> None:
        """All valid subjects should pass."""
        for subject in ["Math", "Reading", "Science", "Social Studies", "Writing", "Other"]:
            input_data = self._valid_input_with_time()
            input_data["activity"]["course"]["subject"] = subject
            result = validate_activity_record_input(input_data)
            assert result.activity_course["subject"] == subject

    # ─────────────────────────────────────────────────────────────────────────
    # Metrics Pairing Tests
    # ─────────────────────────────────────────────────────────────────────────

    def test_total_without_correct_fails(self) -> None:
        """total_questions without correct_questions should fail."""
        input_data = self._valid_input_with_time()
        input_data["metrics"] = {"total_questions": 10, "xp_earned": 50}
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "total_questions and correct_questions must be provided together" in str(
            exc_info.value
        )

    def test_correct_without_total_fails(self) -> None:
        """correct_questions without total_questions should fail."""
        input_data = self._valid_input_with_time()
        input_data["metrics"] = {"correct_questions": 8, "xp_earned": 50}
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "total_questions and correct_questions must be provided together" in str(
            exc_info.value
        )

    def test_correct_exceeds_total_fails(self) -> None:
        """correct_questions > total_questions should fail."""
        input_data = self._valid_input_with_time()
        input_data["metrics"]["total_questions"] = 5
        input_data["metrics"]["correct_questions"] = 10
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "Cannot exceed total_questions" in str(exc_info.value)

    # ─────────────────────────────────────────────────────────────────────────
    # Time Field Tests
    # ─────────────────────────────────────────────────────────────────────────

    def test_invalid_started_at_format_fails(self) -> None:
        """Invalid started_at format should fail."""
        input_data = self._valid_input_with_time()
        input_data["time"]["started_at"] = "not-a-date"
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "started_at" in exc_info.value.field

    def test_invalid_ended_at_format_fails(self) -> None:
        """Invalid ended_at format should fail."""
        input_data = self._valid_input_with_time()
        input_data["time"]["ended_at"] = "2024-01-15"  # Missing time component
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "ended_at" in exc_info.value.field

    def test_negative_active_ms_fails(self) -> None:
        """Negative active_ms should fail."""
        input_data = self._valid_input_with_time()
        input_data["time"]["active_ms"] = -100
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "active_ms" in exc_info.value.field

    def test_negative_inactive_ms_fails(self) -> None:
        """Negative inactive_ms should fail."""
        input_data = self._valid_input_with_time()
        input_data["time"]["inactive_ms"] = -100
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "inactive_ms" in exc_info.value.field

    # ─────────────────────────────────────────────────────────────────────────
    # Type Validation Tests
    # ─────────────────────────────────────────────────────────────────────────

    def test_boolean_total_questions_fails(self) -> None:
        """Boolean total_questions should fail."""
        input_data = self._valid_input_with_time()
        input_data["metrics"]["total_questions"] = True
        input_data["metrics"]["correct_questions"] = False
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "total_questions" in exc_info.value.field

    def test_negative_xp_earned_fails(self) -> None:
        """Negative xp_earned should fail."""
        input_data = self._valid_input_completion_only()
        input_data["metrics"]["xp_earned"] = -10
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "xp_earned" in exc_info.value.field

    def test_float_xp_earned_passes(self) -> None:
        """Float xp_earned should pass."""
        input_data = self._valid_input_completion_only()
        input_data["metrics"]["xp_earned"] = 50.5
        result = validate_activity_record_input(input_data)
        assert result.xp_earned == 50.5

    def test_mastered_units_non_integer_fails(self) -> None:
        """Non-integer mastered_units should fail."""
        input_data = self._valid_input_with_time()
        input_data["metrics"]["mastered_units"] = "unit-1"  # Should be an integer
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "mastered_units" in exc_info.value.field

    def test_mastered_units_negative_fails(self) -> None:
        """Negative mastered_units should fail."""
        input_data = self._valid_input_with_time()
        input_data["metrics"]["mastered_units"] = -1
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "mastered_units" in exc_info.value.field

    # ─────────────────────────────────────────────────────────────────────────
    # Run ID Tests
    # ─────────────────────────────────────────────────────────────────────────

    def test_valid_run_id_passes(self) -> None:
        """Valid UUID run_id should pass."""
        input_data = self._valid_input_with_time()
        input_data["run_id"] = "550e8400-e29b-41d4-a716-446655440000"
        result = validate_activity_record_input(input_data)
        assert result.run_id == "550e8400-e29b-41d4-a716-446655440000"

    def test_missing_run_id_passes(self) -> None:
        """Missing run_id should pass (optional field)."""
        input_data = self._valid_input_with_time()
        result = validate_activity_record_input(input_data)
        assert result.run_id is None

    def test_invalid_run_id_fails(self) -> None:
        """Non-UUID run_id should fail."""
        input_data = self._valid_input_with_time()
        input_data["run_id"] = "not-a-uuid"
        with pytest.raises(ActivityRecordValidationError) as exc_info:
            validate_activity_record_input(input_data)
        assert "run_id" in exc_info.value.field


class TestToCompletionPayload:
    """Tests for _to_completion_payload function.

    Verifies that validated input is correctly converted to CompletionPayload.
    """

    def _make_parsed_input(self, **overrides: object) -> ParsedActivityRecordInput:
        """Create a parsed input with defaults, allowing overrides."""
        defaults = {
            "user_email": "student@example.com",
            "user_timeback_id": None,
            "activity_id": "lesson-123",
            "activity_name": "Test Lesson",
            "activity_course": {"subject": "Math", "grade": 3},
            "started_at": "2024-01-15T10:00:00Z",
            "ended_at": "2024-01-15T10:30:00Z",
            "active_ms": 1800000,
            "inactive_ms": 60000,
            "total_questions": 10,
            "correct_questions": 8,
            "xp_earned": 50,
            "pct_complete": None,
            "mastered_units": None,
            "run_id": None,
            "has_time": True,
        }
        defaults.update(overrides)
        return ParsedActivityRecordInput(**defaults)  # type: ignore[arg-type]

    def test_pct_complete_is_set_on_payload(self) -> None:
        """pct_complete should be set on CompletionPayload."""
        parsed = self._make_parsed_input(pct_complete=75)
        payload, body = _to_completion_payload(parsed)

        # Both payload and body should have pct_complete
        assert payload.pct_complete == 75
        assert body["pctComplete"] == 75

    def test_pct_complete_is_clamped_to_100(self) -> None:
        """pct_complete > 100 should be clamped to 100."""
        parsed = self._make_parsed_input(pct_complete=150)
        payload, body = _to_completion_payload(parsed)

        assert payload.pct_complete == 100
        assert body["pctComplete"] == 100

    def test_pct_complete_is_clamped_to_0(self) -> None:
        """pct_complete < 0 should be clamped to 0."""
        parsed = self._make_parsed_input(pct_complete=-10)
        payload, body = _to_completion_payload(parsed)

        assert payload.pct_complete == 0
        assert body["pctComplete"] == 0

    def test_pct_complete_none_not_in_body(self) -> None:
        """When pct_complete is None, it should not appear in body."""
        parsed = self._make_parsed_input(pct_complete=None)
        payload, body = _to_completion_payload(parsed)

        assert payload.pct_complete is None
        assert "pctComplete" not in body

    def test_metrics_are_set_on_payload(self) -> None:
        """Metrics should be correctly set on payload."""
        parsed = self._make_parsed_input(
            total_questions=10,
            correct_questions=8,
            xp_earned=50,
            mastered_units=5,
        )
        payload, _body = _to_completion_payload(parsed)

        assert payload.metrics["totalQuestions"] == 10
        assert payload.metrics["correctQuestions"] == 8
        assert payload.metrics["xpEarned"] == 50
        assert payload.metrics["masteredUnits"] == 5

    def test_no_time_fields_on_completion_payload(self) -> None:
        """CompletionPayload should not have time fields."""
        parsed = self._make_parsed_input()
        payload, _body = _to_completion_payload(parsed)

        assert not hasattr(payload, "started_at")
        assert not hasattr(payload, "elapsed_ms")
        assert not hasattr(payload, "paused_ms")

    def test_no_time_fields_in_body(self) -> None:
        """Body dict from _to_completion_payload should not have time fields."""
        parsed = self._make_parsed_input()
        _payload, body = _to_completion_payload(parsed)

        assert "startedAt" not in body
        assert "elapsedMs" not in body
        assert "pausedMs" not in body

    def test_run_id_included_in_body(self) -> None:
        """run_id should be set in body dict when provided."""
        parsed = self._make_parsed_input(
            run_id="550e8400-e29b-41d4-a716-446655440000",
        )
        _payload, body = _to_completion_payload(parsed)
        assert body["runId"] == "550e8400-e29b-41d4-a716-446655440000"

    def test_run_id_omitted_from_body_when_none(self) -> None:
        """run_id should not appear in body when None."""
        parsed = self._make_parsed_input(run_id=None)
        _payload, body = _to_completion_payload(parsed)
        assert "runId" not in body
