"""Tests for submit handler hook integration.

Verifies that the HTTP submit handler correctly:
- Delegates to record_completion() with hooks
- Returns preview response when hook skips send
- Returns 204 on normal submit
- Converts ValidatedSubmitPayload to CompletionPayload
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from timeback.server.handlers.activity.submit_handler import create_submit_handler
from timeback.server.types import (
    ActivityHandlerDeps,
    ActivityUserInfo,
    CompletionPayload,
    CompletionResult,
    CustomIdentityConfig,
    SubmitValidationSuccess,
    TimebackHooks,
    ValidatedSubmitPayload,
)
from timeback.shared.types import SubjectGradeCourseRef


@dataclass
class MockAppConfig:
    """Mock app config for testing."""

    name: str = "Test App"
    sensor: str | None = "https://sensor.example.com"
    courses: list[dict[str, Any]] = field(
        default_factory=lambda: [
            {
                "subject": "Math",
                "grade": 3,
                "ids": {"staging": "course-123", "production": "course-456"},
                "sensor": "https://sensor.example.com",
            }
        ]
    )


@dataclass
class MockApiCredentials:
    """Mock API credentials for testing."""

    client_id: str = "test-client-id"
    client_secret: str = "test-client-secret"


def _make_mock_request(body: dict[str, Any]) -> AsyncMock:
    """Create a mock Starlette Request with a JSON body."""
    request = AsyncMock()
    request.json = AsyncMock(return_value=body)
    return request


def _make_submit_body() -> dict[str, Any]:
    """Create a valid submit request body."""
    return {
        "id": "lesson-123",
        "name": "Test Activity",
        "course": {"subject": "Math", "grade": 3},
        "runId": "550e8400-e29b-41d4-a716-446655440000",
        "endedAt": "2024-01-15T10:30:00Z",
        "metrics": {"totalQuestions": 10, "correctQuestions": 8, "xpEarned": 50},
    }


_COURSE_CONFIG: dict[str, Any] = {
    "subject": "Math",
    "grade": 3,
    "ids": {"staging": "course-123", "production": "course-456"},
    "sensor": "https://sensor.example.com",
}


def _make_validated_payload() -> ValidatedSubmitPayload:
    """Create a validated submit payload matching the body."""
    return ValidatedSubmitPayload(
        id="lesson-123",
        name="Test Activity",
        course=SubjectGradeCourseRef(subject="Math", grade=3),
        run_id="550e8400-e29b-41d4-a716-446655440000",
        ended_at="2024-01-15T10:30:00Z",
        metrics={"totalQuestions": 10, "correctQuestions": 8, "xpEarned": 50},
    )


def _make_validation_success() -> SubmitValidationSuccess:
    """Create a successful validation result."""
    return SubmitValidationSuccess(
        ok=True,
        payload=_make_validated_payload(),
        course=_COURSE_CONFIG,
        sensor="https://sensor.example.com",
    )


def _make_mock_deps() -> ActivityHandlerDeps:
    """Create mock dependencies."""
    return ActivityHandlerDeps(
        compute_progress=AsyncMock(return_value=None),
        maybe_write_completion_entry=AsyncMock(),
    )


def _make_identity() -> CustomIdentityConfig:
    """Create a custom identity config that returns a test email."""

    async def get_email(_req: object) -> str:
        return "test@example.com"

    return CustomIdentityConfig(mode="custom", get_email=get_email)


class TestSubmitHandlerHookIntegration:
    """Tests for HTTP submit handler hook invocation via delegation."""

    @pytest.mark.asyncio
    async def test_submit_handler_passes_hooks_to_record_completion(self) -> None:
        """HTTP handler must pass hooks through to record_completion."""
        hook_fn = AsyncMock(return_value=None)
        hooks = TimebackHooks(before_activity_send=hook_fn)

        mock_record = AsyncMock(
            return_value=CompletionResult(success=True, preview=True, data=None)
        )

        handler = create_submit_handler(
            env="staging",
            api=MockApiCredentials(),
            identity=_make_identity(),
            app_config=MockAppConfig(),
            get_client=lambda: MagicMock(),
            hooks=hooks,
            deps=_make_mock_deps(),
        )

        with (
            patch(
                "timeback.server.handlers.activity.submit_handler.validate_submit_request",
                return_value=_make_validation_success(),
            ),
            patch(
                "timeback.server.handlers.activity.submit_handler.record_completion",
                mock_record,
            ),
        ):
            request = _make_mock_request(_make_submit_body())
            await handler(request)

            # Verify record_completion was called with the hooks
            mock_record.assert_called_once()
            call_kwargs = mock_record.call_args.kwargs
            assert call_kwargs["hooks"] is hooks

    @pytest.mark.asyncio
    async def test_submit_handler_returns_preview_when_submit_previews(self) -> None:
        """HTTP handler returns preview response when record_completion indicates preview."""
        hooks = TimebackHooks(before_activity_send=lambda _data: None)

        mock_record = AsyncMock(
            return_value=CompletionResult(success=True, preview=True, data=None)
        )

        handler = create_submit_handler(
            env="staging",
            api=MockApiCredentials(),
            identity=_make_identity(),
            app_config=MockAppConfig(),
            get_client=lambda: MagicMock(),
            hooks=hooks,
            deps=_make_mock_deps(),
        )

        with (
            patch(
                "timeback.server.handlers.activity.submit_handler.validate_submit_request",
                return_value=_make_validation_success(),
            ),
            patch(
                "timeback.server.handlers.activity.submit_handler.record_completion",
                mock_record,
            ),
        ):
            request = _make_mock_request(_make_submit_body())
            response = await handler(request)

            assert response.status_code == 200
            body = json.loads(response.body.decode())
            assert body == {"preview": True}

    @pytest.mark.asyncio
    async def test_submit_handler_returns_204_on_normal_submit(self) -> None:
        """HTTP handler returns 204 No Content on normal submit."""
        mock_record = AsyncMock(
            return_value=CompletionResult(success=True, preview=False, data=None)
        )

        handler = create_submit_handler(
            env="staging",
            api=MockApiCredentials(),
            identity=_make_identity(),
            app_config=MockAppConfig(),
            get_client=lambda: MagicMock(),
            hooks=None,
            deps=_make_mock_deps(),
        )

        with (
            patch(
                "timeback.server.handlers.activity.submit_handler.validate_submit_request",
                return_value=_make_validation_success(),
            ),
            patch(
                "timeback.server.handlers.activity.submit_handler.record_completion",
                mock_record,
            ),
        ):
            request = _make_mock_request(_make_submit_body())
            response = await handler(request)

            assert response.status_code == 204
            assert response.body == b""

    @pytest.mark.asyncio
    async def test_submit_handler_does_not_pass_event_mode(self) -> None:
        """HTTP handler does not pass event_mode — record_completion has no such param."""
        mock_record = AsyncMock(
            return_value=CompletionResult(success=True, preview=False, data=None)
        )

        handler = create_submit_handler(
            env="staging",
            api=MockApiCredentials(),
            identity=_make_identity(),
            app_config=MockAppConfig(),
            get_client=lambda: MagicMock(),
            hooks=None,
            deps=_make_mock_deps(),
        )

        with (
            patch(
                "timeback.server.handlers.activity.submit_handler.validate_submit_request",
                return_value=_make_validation_success(),
            ),
            patch(
                "timeback.server.handlers.activity.submit_handler.record_completion",
                mock_record,
            ),
        ):
            request = _make_mock_request(_make_submit_body())
            await handler(request)

            call_kwargs = mock_record.call_args.kwargs
            assert "event_mode" not in call_kwargs
            assert call_kwargs["preview_requested"] is False

    @pytest.mark.asyncio
    async def test_submit_handler_passes_completion_payload(self) -> None:
        """HTTP handler converts ValidatedSubmitPayload to CompletionPayload."""
        mock_record = AsyncMock(
            return_value=CompletionResult(success=True, preview=False, data=None)
        )

        handler = create_submit_handler(
            env="staging",
            api=MockApiCredentials(),
            identity=_make_identity(),
            app_config=MockAppConfig(),
            get_client=lambda: MagicMock(),
            hooks=None,
            deps=_make_mock_deps(),
        )

        with (
            patch(
                "timeback.server.handlers.activity.submit_handler.validate_submit_request",
                return_value=_make_validation_success(),
            ),
            patch(
                "timeback.server.handlers.activity.submit_handler.record_completion",
                mock_record,
            ),
        ):
            request = _make_mock_request(_make_submit_body())
            await handler(request)

            call_kwargs = mock_record.call_args.kwargs
            payload = call_kwargs["payload"]

            # Should be a CompletionPayload (no time fields)
            assert isinstance(payload, CompletionPayload)
            assert not hasattr(payload, "started_at")
            assert not hasattr(payload, "elapsed_ms")
            assert not hasattr(payload, "paused_ms")
            # Original fields preserved
            assert payload.id == "lesson-123"
            assert payload.name == "Test Activity"
            assert payload.ended_at == "2024-01-15T10:30:00Z"
            assert payload.metrics == {
                "totalQuestions": 10,
                "correctQuestions": 8,
                "xpEarned": 50,
            }

    @pytest.mark.asyncio
    async def test_submit_handler_returns_401_when_unauthenticated(self) -> None:
        """HTTP handler returns 401 when identity returns no user."""
        identity = CustomIdentityConfig(mode="custom", get_email=AsyncMock(return_value=None))

        handler = create_submit_handler(
            env="staging",
            api=MockApiCredentials(),
            identity=identity,
            app_config=MockAppConfig(),
            get_client=lambda: MagicMock(),
            hooks=None,
            deps=_make_mock_deps(),
        )

        request = _make_mock_request(_make_submit_body())
        response = await handler(request)

        assert response.status_code == 401
        body = json.loads(response.body.decode())
        assert body == {"error": {"code": "UNAUTHORIZED", "message": "Unauthorized"}}

    @pytest.mark.asyncio
    async def test_submit_handler_passes_user_info_from_identity(self) -> None:
        """HTTP handler resolves user from identity and passes to record_completion."""
        mock_record = AsyncMock(
            return_value=CompletionResult(success=True, preview=False, data=None)
        )

        handler = create_submit_handler(
            env="staging",
            api=MockApiCredentials(),
            identity=_make_identity(),
            app_config=MockAppConfig(),
            get_client=lambda: MagicMock(),
            hooks=None,
            deps=_make_mock_deps(),
        )

        with (
            patch(
                "timeback.server.handlers.activity.submit_handler.validate_submit_request",
                return_value=_make_validation_success(),
            ),
            patch(
                "timeback.server.handlers.activity.submit_handler.record_completion",
                mock_record,
            ),
        ):
            request = _make_mock_request(_make_submit_body())
            await handler(request)

            call_kwargs = mock_record.call_args.kwargs
            user_info = call_kwargs["user_info"]
            assert isinstance(user_info, ActivityUserInfo)
            assert user_info.email == "test@example.com"

    @pytest.mark.asyncio
    async def test_submit_handler_passes_time_spent_hook_through(self) -> None:
        """HTTP handler passes before_time_spent_send hook through to record_completion."""
        activity_hook = AsyncMock(return_value=None)
        time_spent_hook = AsyncMock(return_value=None)
        hooks = TimebackHooks(
            before_activity_send=activity_hook,
            before_time_spent_send=time_spent_hook,
        )

        mock_record = AsyncMock(
            return_value=CompletionResult(success=True, preview=True, data=None)
        )

        handler = create_submit_handler(
            env="staging",
            api=MockApiCredentials(),
            identity=_make_identity(),
            app_config=MockAppConfig(),
            get_client=lambda: MagicMock(),
            hooks=hooks,
            deps=_make_mock_deps(),
        )

        with (
            patch(
                "timeback.server.handlers.activity.submit_handler.validate_submit_request",
                return_value=_make_validation_success(),
            ),
            patch(
                "timeback.server.handlers.activity.submit_handler.record_completion",
                mock_record,
            ),
        ):
            request = _make_mock_request(_make_submit_body())
            await handler(request)

            call_kwargs = mock_record.call_args.kwargs
            assert call_kwargs["hooks"] is hooks
            assert call_kwargs["hooks"].before_time_spent_send is time_spent_hook
