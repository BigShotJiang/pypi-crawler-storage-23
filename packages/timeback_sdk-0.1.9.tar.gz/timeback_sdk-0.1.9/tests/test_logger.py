"""Tests for SDK configurable logging.

Verifies custom loggers, log levels, silent mode, scope prefixing,
lazy proxy behavior, cache invalidation, and handler calling patterns.
"""

from __future__ import annotations

import logging
from unittest.mock import MagicMock

import pytest

from timeback.server.lib.logger import (
    configure_sdk_logging,
    create_scoped_logger,
    oidc_log,
    reset_sdk_logging,
    sso_log,
)


@pytest.fixture(autouse=True)
def _reset_logging():
    """Reset SDK logging after each test."""
    yield
    reset_sdk_logging()


def _make_mock_logger() -> MagicMock:
    """Create a mock logger with debug/info/warning/error methods."""
    logger = MagicMock()
    logger.debug = MagicMock()
    logger.info = MagicMock()
    logger.warning = MagicMock()
    logger.error = MagicMock()
    return logger


# ─────────────────────────────────────────────────────────────────────────────
# Basic API
# ─────────────────────────────────────────────────────────────────────────────


class TestCreateScopedLogger:
    """Tests for create_scoped_logger."""

    def test_returns_logger_with_all_methods(self):
        log = create_scoped_logger("test")
        assert callable(log.debug)
        assert callable(log.info)
        assert callable(log.warning)
        assert callable(log.error)


# ─────────────────────────────────────────────────────────────────────────────
# Custom Logger Routing
# ─────────────────────────────────────────────────────────────────────────────


class TestCustomLoggerRouting:
    """Tests for routing log calls to a custom logger."""

    def test_routes_calls_to_custom_logger_with_scope(self):
        custom = _make_mock_logger()
        configure_sdk_logging(logger=custom)

        log = create_scoped_logger("handlers.user")
        log.info("User resolved", {"email": "test@example.com"})

        custom.info.assert_called_once()
        args = custom.info.call_args
        assert args[0][0] == "[timeback.handlers.user] User resolved"
        assert args[0][1] == {"email": "test@example.com"}

    def test_prefixes_each_level_with_scope(self):
        custom = _make_mock_logger()
        configure_sdk_logging(logger=custom)

        log = create_scoped_logger("resolve")
        log.debug("Looking up email")
        log.info("Resolved user")
        log.warning("User not found")
        log.error("Resolution failed")

        assert custom.debug.call_args[0][0] == "[timeback.resolve] Looking up email"
        assert custom.info.call_args[0][0] == "[timeback.resolve] Resolved user"
        assert custom.warning.call_args[0][0] == "[timeback.resolve] User not found"
        assert custom.error.call_args[0][0] == "[timeback.resolve] Resolution failed"

    def test_passes_extra_args_through(self):
        custom = _make_mock_logger()
        configure_sdk_logging(logger=custom)

        log = create_scoped_logger("test")
        log.error("Failed", "extra_arg")

        args = custom.error.call_args
        assert args[0] == ("[timeback.test] Failed", "extra_arg")


# ─────────────────────────────────────────────────────────────────────────────
# Handler Calling Patterns
# ─────────────────────────────────────────────────────────────────────────────


class TestHandlerCallingPatterns:
    """Tests that mirror the exact calling patterns used in real handlers."""

    def test_string_plus_context_dict(self):
        custom = _make_mock_logger()
        configure_sdk_logging(logger=custom)

        log = create_scoped_logger("handlers.user")
        log.warning("User resolution failed", extra={"email": "test@example.com"})

        custom.warning.assert_called_once()
        assert "[timeback.handlers.user] User resolution failed" in custom.warning.call_args[0][0]

    def test_string_only_no_trailing_none(self):
        custom = _make_mock_logger()
        configure_sdk_logging(logger=custom)

        log = create_scoped_logger("handlers.activity.heartbeat")
        log.debug("Heartbeat received")

        args, _kwargs = custom.debug.call_args
        assert args == ("[timeback.handlers.activity.heartbeat] Heartbeat received",)

    def test_heartbeat_pattern_with_context(self):
        custom = _make_mock_logger()
        configure_sdk_logging(logger=custom)

        log = create_scoped_logger("handlers.activity.heartbeat")
        log.debug("Duplicate heartbeat: run_id=%s", "run-123")

        args = custom.debug.call_args[0]
        assert args[0] == "[timeback.handlers.activity.heartbeat] Duplicate heartbeat: run_id=%s"
        assert args[1] == "run-123"


# ─────────────────────────────────────────────────────────────────────────────
# Multiple Concurrent Scopes
# ─────────────────────────────────────────────────────────────────────────────


class TestMultipleScopes:
    """Tests for multiple loggers routing to the same custom logger."""

    def test_different_scopes_get_correct_prefixes(self):
        custom = _make_mock_logger()
        configure_sdk_logging(logger=custom)

        user_log = create_scoped_logger("handlers.user")
        heartbeat_log = create_scoped_logger("handlers.activity.heartbeat")
        resolve_log = create_scoped_logger("resolve")

        user_log.info("User resolved")
        heartbeat_log.debug("Heartbeat received")
        resolve_log.warning("Ambiguous email")

        calls = (
            custom.info.call_args_list + custom.debug.call_args_list + custom.warning.call_args_list
        )
        messages = [c[0][0] for c in calls]

        assert "[timeback.handlers.user] User resolved" in messages
        assert "[timeback.handlers.activity.heartbeat] Heartbeat received" in messages
        assert "[timeback.resolve] Ambiguous email" in messages


# ─────────────────────────────────────────────────────────────────────────────
# logLevel Option
# ─────────────────────────────────────────────────────────────────────────────


class TestLogLevel:
    """Tests for the log_level configuration option."""

    def test_custom_logger_receives_all_levels_regardless_of_log_level(self):
        custom = _make_mock_logger()
        configure_sdk_logging(logger=custom, log_level="error")

        log = create_scoped_logger("test")
        log.debug("d")
        log.info("i")
        log.warning("w")
        log.error("e")

        assert custom.debug.call_count == 1
        assert custom.info.call_count == 1
        assert custom.warning.call_count == 1
        assert custom.error.call_count == 1

    def test_silent_suppresses_all_output(self):
        configure_sdk_logging(log_level="silent")

        log = create_scoped_logger("quiet")
        log.debug("nope")
        log.info("nope")
        log.warning("nope")
        log.error("nope")

        # Switch to custom logger and verify only new calls arrive
        custom = _make_mock_logger()
        configure_sdk_logging(logger=custom)
        log.info("after switch")

        assert custom.info.call_count == 1
        assert custom.info.call_args[0][0] == "[timeback.quiet] after switch"


# ─────────────────────────────────────────────────────────────────────────────
# Lazy Proxy (Module-Level Loggers)
# ─────────────────────────────────────────────────────────────────────────────


class TestLazyProxy:
    """Tests that module-level loggers pick up late configuration."""

    def test_proxy_created_before_config_uses_custom_logger(self):
        log = create_scoped_logger("early")
        custom = _make_mock_logger()

        configure_sdk_logging(logger=custom)
        log.info("Hello from early logger")

        custom.info.assert_called_once()
        assert custom.info.call_args[0][0] == "[timeback.early] Hello from early logger"

    def test_proxy_reflects_config_changes(self):
        log = create_scoped_logger("switch")

        first = _make_mock_logger()
        configure_sdk_logging(logger=first)
        log.info("First")
        assert first.info.call_count == 1

        second = _make_mock_logger()
        configure_sdk_logging(logger=second)
        log.info("Second")
        assert second.info.call_count == 1
        assert first.info.call_count == 1

    def test_sso_log_and_oidc_log_pick_up_late_config(self):
        custom = _make_mock_logger()
        configure_sdk_logging(logger=custom)

        sso_log.info("SSO initiated")
        oidc_log.debug("OIDC discovery")

        sso_msg = custom.info.call_args[0][0]
        oidc_msg = custom.debug.call_args[0][0]

        assert sso_msg == "[timeback.sso] SSO initiated"
        assert oidc_msg == "[timeback.oidc] OIDC discovery"


# ─────────────────────────────────────────────────────────────────────────────
# Cache Invalidation
# ─────────────────────────────────────────────────────────────────────────────


class TestCacheInvalidation:
    """Tests for cache invalidation on reconfiguration."""

    def test_all_scopes_reflect_new_config(self):
        first = _make_mock_logger()
        configure_sdk_logging(logger=first)

        log_a = create_scoped_logger("a")
        log_b = create_scoped_logger("b")
        log_a.info("to-first")
        log_b.info("to-first")
        assert first.info.call_count == 2

        second = _make_mock_logger()
        configure_sdk_logging(logger=second)
        log_a.info("to-second")
        log_b.info("to-second")
        assert second.info.call_count == 2
        assert first.info.call_count == 2

    def test_switching_back_to_builtin_does_not_leak(self):
        custom = _make_mock_logger()
        configure_sdk_logging(logger=custom)

        log = create_scoped_logger("leak-test")
        log.info("Through custom")
        assert custom.info.call_count == 1

        reset_sdk_logging()
        log.info("Through default")
        log.warning("Through default")
        assert custom.info.call_count == 1


# ─────────────────────────────────────────────────────────────────────────────
# Type Compatibility
# ─────────────────────────────────────────────────────────────────────────────


class TestTypeCompatibility:
    """Tests that standard-library Logger satisfies SdkLogger protocol."""

    def test_stdlib_logger_is_accepted(self):
        stdlib_logger = logging.getLogger("test-compat")
        configure_sdk_logging(logger=stdlib_logger)
        log = create_scoped_logger("compat")
        # Should not raise
        log.info("hello")
