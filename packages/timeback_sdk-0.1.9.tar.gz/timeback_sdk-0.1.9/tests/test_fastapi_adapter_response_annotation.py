"""Regression tests for FastAPI adapter response annotation resolution."""

from __future__ import annotations

from typing import get_type_hints

from starlette.responses import Response as StarletteResponse

from timeback.server.adapters import fastapi as fastapi_adapter


def test_fastapi_adapter_exposes_response_at_runtime() -> None:
    """Response must exist at runtime for Pydantic/FastAPI annotation resolution."""
    assert getattr(fastapi_adapter, "Response", None) is StarletteResponse


def test_forward_ref_response_resolves_with_adapter_namespace() -> None:
    """Forward-ref 'Response' should resolve using adapter module globals."""

    async def handler() -> StarletteResponse:
        return StarletteResponse(status_code=204)

    # Simulate postponed/forward-ref annotation that FastAPI/Pydantic must resolve.
    handler.__annotations__["return"] = "Response"
    resolved = get_type_hints(handler, globalns=fastapi_adapter.__dict__)
    assert resolved["return"] is StarletteResponse
