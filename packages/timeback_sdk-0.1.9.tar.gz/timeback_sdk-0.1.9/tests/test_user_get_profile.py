"""Tests for user.get_profile() namespace method.

Verifies that create_user_get_profile() produces a function that:
- Resolves a user by email and returns an enriched TimebackProfile
- Validates that email is provided
- Propagates TimebackUserResolutionError
- Uses a shared client without closing it (lifecycle managed externally)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from timeback.server.namespaces.user.get_profile import create_user_get_profile
from timeback.shared.types import (
    CourseInfo,
    GoalsInfo,
    IdentityClaims,
    SchoolInfo,
    TimebackAuthUser,
    TimebackProfile,
    XpInfo,
)

# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class MockApiCredentials:
    """Mock API credentials for testing."""

    client_id: str = "test-client-id"
    client_secret: str = "test-client-secret"


@dataclass
class MockAppConfig:
    """Mock app config for testing."""

    name: str = "Test App"
    sensor: str | None = "https://sensor.example.com"
    courses: list[dict[str, Any]] = field(
        default_factory=lambda: [
            {
                "subject": "Math",
                "grade": 5,
                "ids": {"staging": "course-123"},
                "course_code": "MATH5",
            }
        ]
    )


MOCK_USER = TimebackAuthUser(
    id="tb-user-123",
    email="student@example.com",
    name="Test Student",
    school=SchoolInfo(id="school-1", name="Test School"),
    grade=5,
    claims=IdentityClaims(sub="student@example.com", email="student@example.com"),
)

MOCK_PROFILE = TimebackProfile(
    id="tb-user-123",
    email="student@example.com",
    name="Test Student",
    school=SchoolInfo(id="school-1", name="Test School"),
    grade=5,
    courses=[CourseInfo(id="course-123", code="MATH5", name="Math Grade 5")],
    goals=GoalsInfo(daily_xp=100),
    xp=XpInfo(today=50, all=500),
)


def _make_mock_client() -> MagicMock:
    """Create a mock TimebackClient."""
    mock = MagicMock()
    mock.close = AsyncMock()
    return mock


def _make_get_profile(**overrides: Any):
    """Create a user get_profile function with default mocks."""
    mock_client = overrides.pop("mock_client", _make_mock_client())
    return create_user_get_profile(
        env=overrides.get("env", "staging"),
        api=overrides.get("api", MockApiCredentials()),
        app_config=overrides.get("app_config", MockAppConfig()),
        get_client=lambda: mock_client,
    )


# ─────────────────────────────────────────────────────────────────────────────
# Tests
# ─────────────────────────────────────────────────────────────────────────────


class TestUserGetProfileHappyPath:
    """Tests for successful user profile fetching."""

    @pytest.mark.asyncio
    async def test_returns_timeback_profile(self) -> None:
        """Should resolve user and return enriched profile."""
        mock_client = _make_mock_client()
        get_profile = _make_get_profile(mock_client=mock_client)

        with (
            patch(
                "timeback.server.namespaces.user.get_profile.resolve_timeback_user_by_email",
                new_callable=AsyncMock,
                return_value=MOCK_USER,
            ) as mock_resolve,
            patch(
                "timeback.server.namespaces.user.get_profile.build_user_profile",
                new_callable=AsyncMock,
                return_value=MOCK_PROFILE,
            ) as mock_build,
        ):
            profile = await get_profile("student@example.com")

        assert profile.id == "tb-user-123"
        assert profile.email == "student@example.com"
        assert profile.xp is not None
        assert profile.xp.today == 50
        assert profile.xp.all == 500

        mock_resolve.assert_called_once()
        mock_build.assert_called_once_with(
            client=mock_client,
            user=MOCK_USER,
            app_config=MockAppConfig(),
            api_env="staging",
        )

    @pytest.mark.asyncio
    async def test_passes_email_as_user_info(self) -> None:
        """Should pass email in OIDCUserInfo format to resolve."""
        get_profile = _make_get_profile()

        with (
            patch(
                "timeback.server.namespaces.user.get_profile.resolve_timeback_user_by_email",
                new_callable=AsyncMock,
                return_value=MOCK_USER,
            ) as mock_resolve,
            patch(
                "timeback.server.namespaces.user.get_profile.build_user_profile",
                new_callable=AsyncMock,
                return_value=MOCK_PROFILE,
            ),
        ):
            await get_profile("student@example.com")

        call_kwargs = mock_resolve.call_args.kwargs
        assert call_kwargs["user_info"]["email"] == "student@example.com"
        assert call_kwargs["user_info"]["sub"] == "student@example.com"

    @pytest.mark.asyncio
    async def test_uses_shared_client_from_get_client(self) -> None:
        """Should use the shared client from get_client, not create a new one."""
        mock_client = _make_mock_client()
        get_profile = _make_get_profile(mock_client=mock_client)

        with (
            patch(
                "timeback.server.namespaces.user.get_profile.resolve_timeback_user_by_email",
                new_callable=AsyncMock,
                return_value=MOCK_USER,
            ),
            patch(
                "timeback.server.namespaces.user.get_profile.build_user_profile",
                new_callable=AsyncMock,
                return_value=MOCK_PROFILE,
            ) as mock_build,
        ):
            await get_profile("student@example.com")

        # Verify the shared client was passed to build_user_profile
        mock_build.assert_called_once()
        assert mock_build.call_args.kwargs["client"] is mock_client


class TestUserGetProfileSharedClient:
    """Tests that the shared client is not closed per-call."""

    @pytest.mark.asyncio
    async def test_does_not_close_shared_client(self) -> None:
        """Should NOT close the shared client after get_profile (lifecycle managed externally)."""
        mock_client = _make_mock_client()
        get_profile = _make_get_profile(mock_client=mock_client)

        with (
            patch(
                "timeback.server.namespaces.user.get_profile.resolve_timeback_user_by_email",
                new_callable=AsyncMock,
                return_value=MOCK_USER,
            ),
            patch(
                "timeback.server.namespaces.user.get_profile.build_user_profile",
                new_callable=AsyncMock,
                return_value=MOCK_PROFILE,
            ),
        ):
            await get_profile("student@example.com")

        mock_client.close.assert_not_called()

    @pytest.mark.asyncio
    async def test_propagates_resolution_error_without_closing(self) -> None:
        """Should propagate resolution error without closing shared client."""
        from timeback.server.lib.resolve import TimebackUserResolutionError

        mock_client = _make_mock_client()
        get_profile = _make_get_profile(mock_client=mock_client)

        with (
            patch(
                "timeback.server.namespaces.user.get_profile.resolve_timeback_user_by_email",
                new_callable=AsyncMock,
                side_effect=TimebackUserResolutionError("not found", "user_not_found"),
            ),
            pytest.raises(TimebackUserResolutionError),
        ):
            await get_profile("missing@example.com")

        mock_client.close.assert_not_called()

    @pytest.mark.asyncio
    async def test_propagates_build_error_without_closing(self) -> None:
        """Should propagate build error without closing shared client."""
        mock_client = _make_mock_client()
        get_profile = _make_get_profile(mock_client=mock_client)

        with (
            patch(
                "timeback.server.namespaces.user.get_profile.resolve_timeback_user_by_email",
                new_callable=AsyncMock,
                return_value=MOCK_USER,
            ),
            patch(
                "timeback.server.namespaces.user.get_profile.build_user_profile",
                new_callable=AsyncMock,
                side_effect=RuntimeError("API failure"),
            ),
            pytest.raises(RuntimeError, match="API failure"),
        ):
            await get_profile("student@example.com")

        mock_client.close.assert_not_called()


class TestUserGetProfileValidation:
    """Tests for input validation."""

    @pytest.mark.asyncio
    async def test_raises_on_empty_email(self) -> None:
        """Should raise ValueError for empty email."""
        get_profile = _make_get_profile()

        with pytest.raises(ValueError, match="email is required"):
            await get_profile("")

    @pytest.mark.asyncio
    async def test_propagates_resolution_error(self) -> None:
        """Should propagate TimebackUserResolutionError with code."""
        from timeback.server.lib.resolve import TimebackUserResolutionError

        get_profile = _make_get_profile()

        with (
            patch(
                "timeback.server.namespaces.user.get_profile.resolve_timeback_user_by_email",
                new_callable=AsyncMock,
                side_effect=TimebackUserResolutionError("ambiguous", "multiple_users_found"),
            ),
            pytest.raises(TimebackUserResolutionError, match="ambiguous"),
        ):
            await get_profile("ambiguous@example.com")


class TestUserGetProfileEnvironment:
    """Tests for environment handling."""

    @pytest.mark.asyncio
    async def test_passes_staging_api_env_to_build(self) -> None:
        """Should pass 'staging' as API env to build_user_profile."""
        mock_client = _make_mock_client()
        get_profile = _make_get_profile(env="staging", mock_client=mock_client)

        with (
            patch(
                "timeback.server.namespaces.user.get_profile.resolve_timeback_user_by_email",
                new_callable=AsyncMock,
                return_value=MOCK_USER,
            ),
            patch(
                "timeback.server.namespaces.user.get_profile.build_user_profile",
                new_callable=AsyncMock,
                return_value=MOCK_PROFILE,
            ) as mock_build,
        ):
            await get_profile("student@example.com")

        assert mock_build.call_args.kwargs["api_env"] == "staging"

    @pytest.mark.asyncio
    async def test_passes_production_api_env_to_build(self) -> None:
        """Should pass 'production' as API env to build_user_profile."""
        mock_client = _make_mock_client()
        get_profile = _make_get_profile(env="production", mock_client=mock_client)

        with (
            patch(
                "timeback.server.namespaces.user.get_profile.resolve_timeback_user_by_email",
                new_callable=AsyncMock,
                return_value=MOCK_USER,
            ),
            patch(
                "timeback.server.namespaces.user.get_profile.build_user_profile",
                new_callable=AsyncMock,
                return_value=MOCK_PROFILE,
            ) as mock_build,
        ):
            await get_profile("student@example.com")

        assert mock_build.call_args.kwargs["api_env"] == "production"
