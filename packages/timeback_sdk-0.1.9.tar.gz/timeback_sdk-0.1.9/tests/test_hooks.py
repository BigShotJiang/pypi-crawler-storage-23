"""Tests for request lifecycle hooks."""

import pytest
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from timeback.server.lib.hooks import with_request_hooks
from timeback.server.types import TimebackHooks


def _make_request() -> Request:
    """Create a minimal Starlette request for testing."""
    return Request(scope={"type": "http", "method": "GET", "path": "/test", "headers": []})


async def _handler_200(_request: Request) -> Response:
    """Handler that returns 200."""
    return JSONResponse({"ok": True}, status_code=200)


async def _handler_502(_request: Request) -> Response:
    """Handler that returns 502."""
    return JSONResponse({"error": "bad gateway"}, status_code=502)


async def _handler_throws(_request: Request) -> Response:
    """Handler that raises an exception."""
    raise RuntimeError("unexpected")


# ─────────────────────────────────────────────────────────────────────────────
# Tests
# ─────────────────────────────────────────────────────────────────────────────


class TestWithRequestHooks:
    """Tests for with_request_hooks wrapper."""

    def test_returns_original_when_no_hooks(self) -> None:
        """Should return the original handler when hooks is None."""
        wrapped = with_request_hooks("activity.submit", None, _handler_200)
        assert wrapped is _handler_200

    def test_returns_original_when_no_lifecycle_hooks(self) -> None:
        """Should return the original handler when no lifecycle hooks are set."""
        hooks = TimebackHooks(before_activity_send=lambda _: None)
        wrapped = with_request_hooks("activity.submit", hooks, _handler_200)
        assert wrapped is _handler_200

    @pytest.mark.asyncio
    async def test_calls_on_request_start(self) -> None:
        """Should call on_request_start with the handler name."""
        calls: list[dict] = []
        hooks = TimebackHooks(on_request_start=lambda ctx: calls.append(ctx))

        wrapped = with_request_hooks("activity.heartbeat", hooks, _handler_200)
        await wrapped(_make_request())

        assert len(calls) == 1
        assert calls[0]["handler"] == "activity.heartbeat"

    @pytest.mark.asyncio
    async def test_calls_on_request_end_with_status(self) -> None:
        """Should call on_request_end with handler, duration, and status."""
        calls: list[dict] = []
        hooks = TimebackHooks(on_request_end=lambda ctx: calls.append(ctx))

        wrapped = with_request_hooks("user.me", hooks, _handler_200)
        await wrapped(_make_request())

        assert len(calls) == 1
        assert calls[0]["handler"] == "user.me"
        assert calls[0]["status"] == 200
        assert calls[0]["duration_ms"] >= 0

    @pytest.mark.asyncio
    async def test_reports_error_status(self) -> None:
        """Should report the actual HTTP status on error responses."""
        calls: list[dict] = []
        hooks = TimebackHooks(on_request_end=lambda ctx: calls.append(ctx))

        wrapped = with_request_hooks("activity.submit", hooks, _handler_502)
        await wrapped(_make_request())

        assert calls[0]["status"] == 502

    @pytest.mark.asyncio
    async def test_reports_500_on_throw(self) -> None:
        """Should report status 500 when the handler throws."""
        calls: list[dict] = []
        hooks = TimebackHooks(on_request_end=lambda ctx: calls.append(ctx))

        wrapped = with_request_hooks("user.verify", hooks, _handler_throws)

        with pytest.raises(RuntimeError, match="unexpected"):
            await wrapped(_make_request())

        assert len(calls) == 1
        assert calls[0]["status"] == 500

    @pytest.mark.asyncio
    async def test_execution_order(self) -> None:
        """Should call start before handler and end after handler."""
        order: list[str] = []

        hooks = TimebackHooks(
            on_request_start=lambda _: order.append("start"),
            on_request_end=lambda _: order.append("end"),
        )

        async def handler(_request: Request) -> Response:
            order.append("handler")
            return JSONResponse({"ok": True})

        wrapped = with_request_hooks("activity.submit", hooks, handler)
        await wrapped(_make_request())

        assert order == ["start", "handler", "end"]

    @pytest.mark.asyncio
    async def test_async_hooks(self) -> None:
        """Should support async on_request_start hooks."""
        order: list[str] = []

        async def on_start(_ctx: dict) -> None:
            order.append("start")

        hooks = TimebackHooks(on_request_start=on_start)

        async def handler(_request: Request) -> Response:
            order.append("handler")
            return JSONResponse({"ok": True})

        wrapped = with_request_hooks("activity.submit", hooks, handler)
        await wrapped(_make_request())

        assert order == ["start", "handler"]
