"""Tests for user.verify() namespace method.

Verifies that create_user_verify() produces a function that:
- Returns verified=True with timeback_id when the user exists
- Returns verified=False when the user is not found
- Raises on ambiguous or failed lookups
- Validates that email is provided
- Uses a shared client without closing it (lifecycle managed externally)
"""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from timeback.server.lib.resolve import TimebackUserResolutionError
from timeback.server.namespaces.user.verify import create_user_verify

# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────


def _make_mock_client() -> MagicMock:
    """Create a mock TimebackClient."""
    mock = MagicMock()
    mock.close = AsyncMock()
    return mock


def _make_verify(**overrides: Any):
    """Create a user verify function with default mocks."""
    mock_client = overrides.pop("mock_client", _make_mock_client())
    return create_user_verify(
        get_client=lambda: mock_client,
    ), mock_client


# ─────────────────────────────────────────────────────────────────────────────
# Tests
# ─────────────────────────────────────────────────────────────────────────────


class TestUserVerifyHappyPath:
    """Tests for successful user verification."""

    @pytest.mark.asyncio
    async def test_returns_verified_true_with_timeback_id(self) -> None:
        """Should return verified=True and timeback_id when user exists."""
        verify, mock_client = _make_verify()

        with patch(
            "timeback.server.namespaces.user.verify.lookup_timeback_id_by_email",
            new_callable=AsyncMock,
            return_value="tb-user-123",
        ) as mock_lookup:
            result = await verify("student@example.com")

        assert result.verified is True
        assert result.timeback_id == "tb-user-123"

        mock_lookup.assert_called_once_with(email="student@example.com", client=mock_client)

    @pytest.mark.asyncio
    async def test_returns_verified_false_when_not_found(self) -> None:
        """Should return verified=False when user does not exist."""
        verify, _ = _make_verify()

        with patch(
            "timeback.server.namespaces.user.verify.lookup_timeback_id_by_email",
            new_callable=AsyncMock,
            side_effect=TimebackUserResolutionError(
                "No Timeback user found", "timeback_user_not_found"
            ),
        ):
            result = await verify("unknown@example.com")

        assert result.verified is False
        assert result.timeback_id is None


class TestUserVerifyErrors:
    """Tests for error handling."""

    @pytest.mark.asyncio
    async def test_raises_on_ambiguous_user(self) -> None:
        """Should re-raise TimebackUserResolutionError for ambiguous matches."""
        verify, _ = _make_verify()

        with (
            patch(
                "timeback.server.namespaces.user.verify.lookup_timeback_id_by_email",
                new_callable=AsyncMock,
                side_effect=TimebackUserResolutionError(
                    "Multiple users found", "timeback_user_ambiguous"
                ),
            ),
            pytest.raises(TimebackUserResolutionError, match="Multiple users found"),
        ):
            await verify("ambiguous@example.com")

    @pytest.mark.asyncio
    async def test_raises_on_lookup_failed(self) -> None:
        """Should re-raise TimebackUserResolutionError for lookup failures."""
        verify, _ = _make_verify()

        with (
            patch(
                "timeback.server.namespaces.user.verify.lookup_timeback_id_by_email",
                new_callable=AsyncMock,
                side_effect=TimebackUserResolutionError("API error", "timeback_user_lookup_failed"),
            ),
            pytest.raises(TimebackUserResolutionError, match="API error"),
        ):
            await verify("student@example.com")

    @pytest.mark.asyncio
    async def test_raises_on_unexpected_error(self) -> None:
        """Should propagate unexpected exceptions."""
        verify, _ = _make_verify()

        with (
            patch(
                "timeback.server.namespaces.user.verify.lookup_timeback_id_by_email",
                new_callable=AsyncMock,
                side_effect=RuntimeError("network timeout"),
            ),
            pytest.raises(RuntimeError, match="network timeout"),
        ):
            await verify("student@example.com")


class TestUserVerifyValidation:
    """Tests for input validation."""

    @pytest.mark.asyncio
    async def test_raises_on_empty_email(self) -> None:
        """Should raise ValueError for empty email."""
        verify, _ = _make_verify()

        with pytest.raises(ValueError, match="email is required"):
            await verify("")


class TestUserVerifySharedClient:
    """Tests that the shared client is not closed per-call."""

    @pytest.mark.asyncio
    async def test_does_not_close_shared_client(self) -> None:
        """Should NOT close the shared client after verify (lifecycle managed externally)."""
        verify, mock_client = _make_verify()

        with patch(
            "timeback.server.namespaces.user.verify.lookup_timeback_id_by_email",
            new_callable=AsyncMock,
            return_value="tb-user-123",
        ):
            await verify("student@example.com")

        mock_client.close.assert_not_called()

    @pytest.mark.asyncio
    async def test_does_not_close_shared_client_on_error(self) -> None:
        """Should NOT close the shared client even when verification fails."""
        verify, mock_client = _make_verify()

        with patch(
            "timeback.server.namespaces.user.verify.lookup_timeback_id_by_email",
            new_callable=AsyncMock,
            side_effect=TimebackUserResolutionError("No user found", "timeback_user_not_found"),
        ):
            await verify("unknown@example.com")

        mock_client.close.assert_not_called()
