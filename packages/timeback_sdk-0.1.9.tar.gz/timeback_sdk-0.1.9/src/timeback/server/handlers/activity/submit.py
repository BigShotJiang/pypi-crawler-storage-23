"""
Activity Completion Pipeline

Focused functions for activity completion and time-spent event sending.
Used by both the HTTP submit handler and the programmatic activity.record() API.

- record_completion(): builds and sends ActivityCompletedEvent
- send_time_spent(): builds and sends TimeSpentEvent (standalone)
"""

from __future__ import annotations

import inspect
from typing import TYPE_CHECKING, Any, cast

from timeback_caliper import (
    TimebackUser,
)

from ...lib.logger import create_scoped_logger
from ...lib.resolve import lookup_timeback_id_by_email
from ...types import (
    ActivityBeforeSendData,
    ActivityHandlerDeps,
    ActivityUserInfo,
    CompletionPayload,
    CompletionResult,
    TimeSpentBeforeSendData,
)
from .attempts import compute_caliper_line_item_id, resolve_caliper_attempt_number
from .caliper import (
    MissingSyncedCourseIdError,
    build_activity_context,
    build_activity_metrics,
    build_canonical_activity_url,
    build_oneroster_user_url,
    build_submit_event,
    build_time_spent_event,
    build_time_spent_metrics,
)
from .completion import maybe_write_completion_entry as maybe_write_completion_entry_impl
from .progress import compute_progress as compute_progress_impl

if TYPE_CHECKING:
    from collections.abc import Callable

    from timeback_core import TimebackClient

    from ...timeback import AppConfig
    from ...types import ApiCredentials, Environment, TimebackHooks

log = create_scoped_logger("handlers.activity.submit")


# ─────────────────────────────────────────────────────────────────────────────
# Default Dependencies
# ─────────────────────────────────────────────────────────────────────────────

_default_deps = ActivityHandlerDeps(
    compute_progress=compute_progress_impl,
    maybe_write_completion_entry=maybe_write_completion_entry_impl,
)


# ─────────────────────────────────────────────────────────────────────────────
# User Resolution
# ─────────────────────────────────────────────────────────────────────────────


async def resolve_timeback_id(user_info: ActivityUserInfo, client: TimebackClient) -> str:
    """Resolve the timebackId, using cached value from SSO or looking up by email."""
    if user_info.timeback_id:
        return user_info.timeback_id
    return await lookup_timeback_id_by_email(email=user_info.email, client=client)


# ─────────────────────────────────────────────────────────────────────────────
# Attempt Resolution
# ─────────────────────────────────────────────────────────────────────────────


async def resolve_attempt_number(
    *,
    client: TimebackClient,
    timeback_id: str,
    synced_course_id: str,
    object_id: str,
    ended_at: str,
    preview_requested: bool,
) -> int:
    """
    Resolve the attempt number for activity completion.

    When process: true, timeback-api-2 creates assessment results using a
    deterministic line item ID. We query existing results to determine the
    correct attempt number before sending the event.
    """
    if preview_requested:
        return 1

    line_item_id = compute_caliper_line_item_id(object_id, synced_course_id)
    return await resolve_caliper_attempt_number(client, line_item_id, timeback_id, ended_at)


# ─────────────────────────────────────────────────────────────────────────────
# Record Completion
# ─────────────────────────────────────────────────────────────────────────────


async def record_completion(
    *,
    user_info: ActivityUserInfo,
    body: dict[str, Any],
    payload: CompletionPayload,
    course_config: dict[str, Any],
    sensor: str,
    env: Environment,
    api_env: str,
    api: ApiCredentials,  # noqa: ARG001
    app_config: AppConfig,
    get_client: Callable[[], TimebackClient],
    hooks: TimebackHooks | None,
    preview_requested: bool,
    deps: ActivityHandlerDeps = _default_deps,
) -> CompletionResult:
    """
    Record an activity completion by building and sending an ActivityCompletedEvent.

    This is the core completion pipeline used by the HTTP submit handler
    and the programmatic API (timeback.activity.record()).

    Only builds and sends ActivityCompletedEvent — time-spent events are
    handled separately by the heartbeat handler or send_time_spent().

    Args:
        user_info: User identity info (email, optional timeback_id)
        body: Request body as dict (for pctComplete mutation)
        payload: Validated completion payload (no time fields)
        course_config: Matched course config from timeback.config.json
        sensor: Resolved sensor URL
        env: Environment (local, staging, production)
        api_env: API environment (staging, production)
        api: API credentials
        app_config: App configuration
        hooks: Optional hooks for customizing behavior
        preview_requested: Whether to skip sending events (preview mode)
        deps: Dependency injection for testing

    Returns:
        CompletionResult with the built event and metadata

    Raises:
        MissingSyncedCourseIdError: Course is missing a synced ID for the environment
        TimebackUserResolutionError: Failed to resolve Timeback user
    """
    # ═══════════════════════════════════════════════════════════════════════
    # Step 1: Verify course is synced for this environment
    # ═══════════════════════════════════════════════════════════════════════
    synced_course_id = (course_config.get("ids") or {}).get(api_env)
    if not isinstance(synced_course_id, str) or not synced_course_id:
        raise MissingSyncedCourseIdError(course_config, api_env)

    # ═══════════════════════════════════════════════════════════════════════
    # Step 2: Resolve user via shared client
    # ═══════════════════════════════════════════════════════════════════════
    client = get_client()
    timeback_id = await resolve_timeback_id(user_info, client)
    effective_body = body

    # ═══════════════════════════════════════════════════════════════════════
    # Step 3: Compute pctComplete if not provided by client
    # ═══════════════════════════════════════════════════════════════════════
    if body.get("pctComplete") is None:
        computed_pct = await deps.compute_progress(
            client=client,
            course_id=synced_course_id,
            timeback_id=timeback_id,
            payload=body,
            course_config=course_config,
            env=env,
        )
        if computed_pct is not None:
            effective_body = {**body, "pctComplete": computed_pct}

    # ═══════════════════════════════════════════════════════════════════════
    # Step 4: Resolve attempt number
    # ═══════════════════════════════════════════════════════════════════════
    object_id = build_canonical_activity_url(sensor, payload.course, payload.id)
    attempt_number = await resolve_attempt_number(
        client=client,
        timeback_id=timeback_id,
        synced_course_id=synced_course_id,
        object_id=object_id,
        ended_at=payload.ended_at,
        preview_requested=preview_requested,
    )

    # ═══════════════════════════════════════════════════════════════════════
    # Step 5: Build Caliper ActivityCompletedEvent
    # ═══════════════════════════════════════════════════════════════════════
    or_transport = client.oneroster.get_transport()
    oneroster_base_url = cast("str", getattr(or_transport, "base_url", None))
    if not oneroster_base_url:
        raise RuntimeError("OneRoster base_url is not configured")

    oneroster_rostering_path = cast(
        "str",
        getattr(
            getattr(or_transport, "paths", None),
            "rostering",
            "/ims/oneroster/rostering/v1p2",
        ),
    )

    actor = TimebackUser(
        id=build_oneroster_user_url(
            base_url=oneroster_base_url,
            rostering_path=oneroster_rostering_path,
            user_sourced_id=timeback_id,
        ),
        type="TimebackUser",
        email=user_info.email,
    )

    activity_context = build_activity_context(
        activity_id=payload.id,
        activity_name=payload.name,
        course_selector=payload.course,
        course_config=course_config,
        app_name=app_config.name,
        api_env=api_env,
        sensor=sensor,
        oneroster_base_url=oneroster_base_url,
        oneroster_rostering_path=oneroster_rostering_path,
    )

    activity_metrics = build_activity_metrics(payload.metrics)

    # Extensions for generated metrics (pctCompleteApp)
    generated_extensions: dict[str, object] | None = None
    pct_complete = effective_body.get("pctComplete")
    if pct_complete is not None:
        generated_extensions = {"pctCompleteApp": pct_complete}

    # Build ActivityCompletedEvent
    activity_event = build_submit_event(
        actor=actor,
        activity_context=activity_context,
        activity_metrics=activity_metrics,
        event_time=payload.ended_at,
        attempt=attempt_number if attempt_number > 0 else None,
        generated_extensions=generated_extensions,
        course_id=synced_course_id,
        run_id=body.get("runId"),
    )

    # ═══════════════════════════════════════════════════════════════════════
    # Step 6: Run beforeActivitySend hook
    # ═══════════════════════════════════════════════════════════════════════
    built_data = ActivityBeforeSendData(
        sensor=sensor,
        actor={"id": actor.id, "type": actor.type, "email": actor.email},
        object=activity_context,
        event=activity_event,
        payload=effective_body,
        course=course_config,
        app_name=app_config.name,
        api_env=api_env,
        email=user_info.email,
        timeback_id=timeback_id,
    )

    hook_result = built_data
    if hooks and hooks.before_activity_send:
        hook_fn = hooks.before_activity_send
        result = hook_fn(built_data)
        hook_result = await result if inspect.isawaitable(result) else result

    effective_data = hook_result if hook_result is not None else built_data

    # ═══════════════════════════════════════════════════════════════════════
    # Step 7: Preview mode — return event without sending
    # ═══════════════════════════════════════════════════════════════════════
    skip_send = preview_requested or hook_result is None
    if skip_send:
        return CompletionResult(success=True, preview=True, data=effective_data)

    # ═══════════════════════════════════════════════════════════════════════
    # Step 8: Send Caliper event
    # ═══════════════════════════════════════════════════════════════════════
    await client.caliper.events.send(effective_data.sensor, [effective_data.event])

    # ═══════════════════════════════════════════════════════════════════════
    # Step 9: Write mastery completion entry if pctComplete is 100
    # ═══════════════════════════════════════════════════════════════════════
    await deps.maybe_write_completion_entry(
        client=client,
        course_id=synced_course_id,
        timeback_id=effective_data.timeback_id,
        pct_complete=effective_data.payload.get("pctComplete"),
        app_name=effective_data.app_name,
    )

    return CompletionResult(success=True, preview=False, data=effective_data)


# ─────────────────────────────────────────────────────────────────────────────
# Send Time Spent
# ─────────────────────────────────────────────────────────────────────────────


async def send_time_spent(
    *,
    user_info: ActivityUserInfo,
    activity_id: str,
    activity_name: str,
    course_selector: Any,
    course_config: dict[str, Any],
    sensor: str,
    api_env: str,
    api: ApiCredentials,  # noqa: ARG001
    app_config: AppConfig,
    get_client: Callable[[], TimebackClient],
    elapsed_ms: int,
    paused_ms: int,
    ended_at: str,
    run_id: str | None = None,
    hooks: TimebackHooks | None = None,
) -> None:
    """
    Build and send a standalone TimeSpentEvent.

    This is a self-contained function that creates its own client, resolves
    the user, builds the event, sends it, and cleans up. Used by the
    programmatic API (timeback.activity.record()) when time data is provided.

    Args:
        user_info: User identity info (email, optional timeback_id)
        activity_id: Activity slug/identifier
        activity_name: Human-readable activity name
        course_selector: Course selector (SubjectGradeCourseRef or CourseCodeRef)
        course_config: Matched course config from timeback.config.json
        sensor: Resolved sensor URL
        api_env: API environment (staging, production)
        api: API credentials
        app_config: App configuration
        elapsed_ms: Active time in milliseconds
        paused_ms: Paused/inactive time in milliseconds
        ended_at: ISO 8601 timestamp
        run_id: Optional client-generated UUID for correlation
    """
    synced_course_id = (course_config.get("ids") or {}).get(api_env)
    if not isinstance(synced_course_id, str) or not synced_course_id:
        raise MissingSyncedCourseIdError(course_config, api_env)

    client = get_client()
    timeback_id = await resolve_timeback_id(user_info, client)

    or_transport = client.oneroster.get_transport()
    oneroster_base_url = cast("str", getattr(or_transport, "base_url", None))
    if not oneroster_base_url:
        raise RuntimeError("OneRoster base_url is not configured")

    oneroster_rostering_path = cast(
        "str",
        getattr(
            getattr(or_transport, "paths", None),
            "rostering",
            "/ims/oneroster/rostering/v1p2",
        ),
    )

    actor = TimebackUser(
        id=build_oneroster_user_url(
            base_url=oneroster_base_url,
            rostering_path=oneroster_rostering_path,
            user_sourced_id=timeback_id,
        ),
        type="TimebackUser",
        email=user_info.email,
    )

    activity_context = build_activity_context(
        activity_id=activity_id,
        activity_name=activity_name,
        course_selector=course_selector,
        course_config=course_config,
        app_name=app_config.name,
        api_env=api_env,
        sensor=sensor,
        oneroster_base_url=oneroster_base_url,
        oneroster_rostering_path=oneroster_rostering_path,
    )

    time_spent_metrics = build_time_spent_metrics(elapsed_ms, paused_ms)

    time_spent_event = build_time_spent_event(
        actor=actor,
        activity_context=activity_context,
        time_spent_metrics=time_spent_metrics,
        event_time=ended_at,
        course_id=synced_course_id,
        run_id=run_id,
    )

    built = TimeSpentBeforeSendData(
        sensor=sensor,
        actor={"id": actor.id, "type": actor.type, "email": actor.email},
        object=activity_context,
        event=time_spent_event,
        payload={
            "id": activity_id,
            "name": activity_name,
            "course": course_selector,
            "startedAt": ended_at,
            "endedAt": ended_at,
            "elapsedMs": elapsed_ms,
            "pausedMs": paused_ms,
        },
        course=course_config,
        app_name=app_config.name,
        api_env=api_env,
        email=user_info.email,
        timeback_id=timeback_id,
        run_id=run_id,
    )

    hook = hooks.before_time_spent_send if hooks else None
    if hook:
        hook_result = hook(built)
        if inspect.isawaitable(hook_result):
            hook_result = await hook_result
    else:
        hook_result = built

    if hook_result is None:
        log.debug("Hook skipped time-spent send: activityId=%s", activity_id)
        return

    effective = hook_result

    await client.caliper.events.send(effective.sensor, [effective.event])
