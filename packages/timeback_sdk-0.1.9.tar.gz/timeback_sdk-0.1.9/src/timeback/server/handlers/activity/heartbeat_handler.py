"""
Heartbeat Handler

Minimal HTTP route handler for activity heartbeats (time-spent tracking).
Only builds and sends TimeSpentEvent — no progress, attempt, XP, or gradebook writes.
"""

from __future__ import annotations

import inspect
import time
from datetime import UTC
from typing import TYPE_CHECKING, cast

from starlette.responses import JSONResponse, Response

from timeback_caliper import TimebackUser

from ...lib.logger import create_scoped_logger
from ...lib.resolve import (
    TimebackUserResolutionError,
    lookup_timeback_id_by_email,
    resolve_status_for_user_resolution_error,
)
from ...lib.utils import error_response, map_env_for_api
from ...types import (
    TimeSpentBeforeSendData,
    ValidationError,
)
from .caliper import (
    MissingSyncedCourseIdError,
    build_activity_context,
    build_oneroster_user_url,
    build_time_spent_event,
    build_time_spent_metrics,
)
from .schema import validate_heartbeat_request
from .submit_handler import get_activity_user_info

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from starlette.requests import Request

    from timeback_core import TimebackClient

    from ...timeback import AppConfig
    from ...types import ApiCredentials, Environment, IdentityConfig, TimebackHooks

log = create_scoped_logger("handlers.activity.heartbeat")


# ─────────────────────────────────────────────────────────────────────────────
# Deduplication Cache
# ─────────────────────────────────────────────────────────────────────────────

# In-memory TTL cache for heartbeat deduplication.
# Key: `{runId}:{windowStartMs}` (windowKey)
# Value: timestamp (seconds) when the key was added
_dedupe_cache: dict[str, float] = {}

# TTL for deduplication cache entries (5 minutes).
_DEDUPE_TTL_S = 5 * 60


def _clean_dedupe_cache() -> None:
    """Clean expired entries from the deduplication cache."""
    now = time.monotonic()
    expired = [key for key, ts in _dedupe_cache.items() if now - ts > _DEDUPE_TTL_S]
    for key in expired:
        del _dedupe_cache[key]


def _is_duplicate(window_key: str) -> bool:
    """Check if a heartbeat has already been processed."""
    _clean_dedupe_cache()
    return window_key in _dedupe_cache


def _mark_processed(window_key: str) -> None:
    """Mark a heartbeat as processed."""
    _dedupe_cache[window_key] = time.monotonic()


# ─────────────────────────────────────────────────────────────────────────────
# Handler
# ─────────────────────────────────────────────────────────────────────────────


def create_heartbeat_handler(
    *,
    env: Environment,
    api: ApiCredentials,  # noqa: ARG001
    identity: IdentityConfig,
    app_config: AppConfig,
    get_client: Callable[[], TimebackClient],
    hooks: TimebackHooks | None = None,
) -> Callable[[Request], Awaitable[Response]]:
    """Create the heartbeat POST handler.

    This handler receives periodic time-tracking heartbeats and emits a single
    TimeSpentEvent per unique time window. Heartbeats are deduplicated using an
    in-memory TTL cache keyed by `{runId}:{windowStartMs}`.
    """
    api_env = map_env_for_api(env)

    async def handler(request: Request) -> Response:
        # ═══════════════════════════════════════════════════════════════════
        # Step 1: Authenticate
        # ═══════════════════════════════════════════════════════════════════
        user_info = await get_activity_user_info(identity, request)
        if not user_info:
            return error_response("UNAUTHORIZED", "Unauthorized", 401)

        # ═══════════════════════════════════════════════════════════════════
        # Step 2: Validate request
        # ═══════════════════════════════════════════════════════════════════
        body = await request.json()
        result = validate_heartbeat_request(body, app_config)

        if isinstance(result, ValidationError):
            return result.response

        payload = result.payload
        course_config = result.course
        sensor = result.sensor

        # ═══════════════════════════════════════════════════════════════════
        # Step 3: Check for duplicate (idempotency)
        # ═══════════════════════════════════════════════════════════════════
        window_start_ms = _parse_iso_to_ms(payload.started_at)
        window_key = f"{payload.run_id}:{window_start_ms}"

        if _is_duplicate(window_key):
            log.debug(
                "Duplicate heartbeat, skipping: runId=%s, windowKey=%s", payload.run_id, window_key
            )
            return JSONResponse({"duplicate": True})

        # ═══════════════════════════════════════════════════════════════════
        # Step 4: Verify course is synced
        # ═══════════════════════════════════════════════════════════════════
        synced_course_id = (course_config.get("ids") or {}).get(api_env)
        if not isinstance(synced_course_id, str) or not synced_course_id:
            err = MissingSyncedCourseIdError(course_config, api_env)
            log.warning("Course not synced: %s, env=%s", err.course, err.env)
            return error_response("MISSING_SYNCED_COURSE_ID", str(err), 503)

        # ═══════════════════════════════════════════════════════════════════
        # Step 5: Resolve user and send event
        # ═══════════════════════════════════════════════════════════════════
        client = get_client()

        try:
            timeback_id = (
                user_info.timeback_id
                if user_info.timeback_id
                else await lookup_timeback_id_by_email(email=user_info.email, client=client)
            )

            or_transport = client.oneroster.get_transport()
            oneroster_base_url = cast("str", getattr(or_transport, "base_url", None))
            if not oneroster_base_url:
                raise RuntimeError("OneRoster base_url is not configured")

            oneroster_rostering_path = cast(
                "str",
                getattr(
                    getattr(or_transport, "paths", None),
                    "rostering",
                    "/ims/oneroster/rostering/v1p2",
                ),
            )

            actor = TimebackUser(
                id=build_oneroster_user_url(
                    base_url=oneroster_base_url,
                    rostering_path=oneroster_rostering_path,
                    user_sourced_id=timeback_id,
                ),
                type="TimebackUser",
                email=user_info.email,
            )

            activity_context = build_activity_context(
                activity_id=payload.id,
                activity_name=payload.name,
                course_selector=payload.course,
                course_config=course_config,
                app_name=app_config.name,
                api_env=api_env,
                sensor=sensor,
                oneroster_base_url=oneroster_base_url,
                oneroster_rostering_path=oneroster_rostering_path,
            )

            time_spent_metrics = build_time_spent_metrics(payload.elapsed_ms, payload.paused_ms)

            time_spent_event = build_time_spent_event(
                actor=actor,
                activity_context=activity_context,
                time_spent_metrics=time_spent_metrics,
                event_time=payload.ended_at,
                course_id=synced_course_id,
                run_id=payload.run_id,
            )

            built = TimeSpentBeforeSendData(
                sensor=sensor,
                actor={"id": actor.id, "type": actor.type, "email": actor.email},
                object=activity_context,
                event=time_spent_event,
                payload={
                    "id": payload.id,
                    "name": payload.name,
                    "course": payload.course,
                    "startedAt": payload.started_at,
                    "endedAt": payload.ended_at,
                    "elapsedMs": payload.elapsed_ms,
                    "pausedMs": payload.paused_ms,
                },
                course=course_config,
                app_name=app_config.name,
                api_env=api_env,
                email=user_info.email,
                timeback_id=timeback_id,
                run_id=payload.run_id,
            )

            hook = hooks.before_time_spent_send if hooks else None
            if hook:
                hook_result = hook(built)
                if inspect.isawaitable(hook_result):
                    hook_result = await hook_result
            else:
                hook_result = built

            effective = hook_result if hook_result is not None else built

            if hook_result is None:
                _mark_processed(window_key)
                log.debug("Hook skipped heartbeat send: runId=%s", payload.run_id)
                return Response(status_code=204)

            await client.caliper.events.send(effective.sensor, [effective.event])

            _mark_processed(window_key)

            log.debug(
                "Sent heartbeat: runId=%s, activityId=%s, elapsedMs=%d",
                payload.run_id,
                payload.id,
                payload.elapsed_ms,
            )

            return Response(status_code=204)

        except TimebackUserResolutionError as e:
            log.warning("Failed to resolve Timeback user: %s", e.code)
            return error_response(
                "USER_RESOLUTION_FAILED",
                "Unable to resolve Timeback identity",
                resolve_status_for_user_resolution_error(e),
            )

        except MissingSyncedCourseIdError as e:
            log.warning("Course not synced: %s, env=%s", e.course, e.env)
            return error_response("MISSING_SYNCED_COURSE_ID", str(e), 503)

        except Exception as e:
            message = str(e) if str(e) else "Unknown error"
            log.error("Failed to send heartbeat: %s", message)
            return error_response("INTERNAL_ERROR", message, 502)

    return handler


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def _parse_iso_to_ms(iso_str: str) -> int:
    """Parse an ISO 8601 datetime to milliseconds since epoch.

    Uses a simple approach: parse with datetime and convert.
    """
    from datetime import datetime

    # Handle Z suffix
    normalized = iso_str.replace("Z", "+00:00")
    dt = datetime.fromisoformat(normalized)
    # Ensure UTC
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return int(dt.timestamp() * 1000)
