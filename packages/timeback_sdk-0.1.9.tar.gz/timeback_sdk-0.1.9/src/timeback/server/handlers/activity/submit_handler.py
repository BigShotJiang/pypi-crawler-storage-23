"""
Submit Handler

HTTP route handler for activity completion submissions.
Delegates to record_completion() for the shared completion pipeline.
Only sends ActivityCompletedEvent — heartbeats handle time-spent events separately.
"""

from __future__ import annotations

import inspect
from typing import TYPE_CHECKING

from starlette.responses import JSONResponse, Response

from timeback_common import ValidationError as CaliperValidationError

from ...lib.logger import create_scoped_logger
from ...lib.resolve import (
    TimebackUserResolutionError,
    resolve_status_for_user_resolution_error,
)
from ...lib.utils import error_response, map_env_for_api
from ...types import (
    ActivityHandlerDeps,
    ActivityUserInfo,
    CompletionPayload,
    CustomIdentityConfig,
    ValidationError,
)
from .caliper import (
    InvalidSensorUrlError,
    MissingSyncedCourseIdError,
)
from .completion import maybe_write_completion_entry as maybe_write_completion_entry_impl
from .progress import compute_progress as compute_progress_impl
from .schema import format_course_selector, validate_submit_request
from .submit import record_completion

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from starlette.requests import Request

    from timeback_core import TimebackClient

    from ...timeback import AppConfig
    from ...types import (
        ApiCredentials,
        Environment,
        IdentityConfig,
        TimebackHooks,
    )

log = create_scoped_logger("handlers.activity.submit")


# ─────────────────────────────────────────────────────────────────────────────
# Default Dependencies
# ─────────────────────────────────────────────────────────────────────────────

_default_deps = ActivityHandlerDeps(
    compute_progress=compute_progress_impl,
    maybe_write_completion_entry=maybe_write_completion_entry_impl,
)


# ─────────────────────────────────────────────────────────────────────────────
# User Resolution
# ─────────────────────────────────────────────────────────────────────────────


async def get_activity_user_info(
    identity: IdentityConfig,
    request: Request,
) -> ActivityUserInfo | None:
    """Get user info from the request based on identity mode."""
    if isinstance(identity, CustomIdentityConfig) or identity.mode == "custom":
        get_email = identity.get_email
        if not get_email:
            return None

        result = get_email(request)
        email = await result if inspect.isawaitable(result) else result
        return ActivityUserInfo(email=email) if email else None

    get_user = identity.get_user
    if not get_user:
        return None

    result = get_user(request)
    user = await result if inspect.isawaitable(result) else result
    return ActivityUserInfo(email=user.email, timeback_id=user.id) if user else None


# ─────────────────────────────────────────────────────────────────────────────
# Handler
# ─────────────────────────────────────────────────────────────────────────────


def create_submit_handler(
    *,
    env: Environment,
    api: ApiCredentials,
    identity: IdentityConfig,
    app_config: AppConfig,
    get_client: Callable[[], TimebackClient],
    hooks: TimebackHooks | None = None,
    deps: ActivityHandlerDeps = _default_deps,
) -> Callable[[Request], Awaitable[Response]]:
    """Create the submit POST handler.

    This handler receives activity completion submissions and delegates to the
    shared record_completion() pipeline. Time-spent tracking is handled separately
    by the heartbeat handler.
    """
    api_env = map_env_for_api(env)

    async def handler(request: Request) -> Response:
        # ═══════════════════════════════════════════════════════════════════
        # Step 1: Authenticate
        # ═══════════════════════════════════════════════════════════════════
        user_info = await get_activity_user_info(identity, request)
        if not user_info:
            return error_response("UNAUTHORIZED", "Unauthorized", 401)

        # ═══════════════════════════════════════════════════════════════════
        # Step 2: Validate request
        # ═══════════════════════════════════════════════════════════════════
        body = await request.json()
        result = validate_submit_request(body, app_config)

        if isinstance(result, ValidationError):
            return result.response

        payload = result.payload

        # ═══════════════════════════════════════════════════════════════════
        # Step 3: Delegate to record_completion
        # ═══════════════════════════════════════════════════════════════════
        try:
            completion_result = await record_completion(
                user_info=user_info,
                body=body,
                payload=CompletionPayload(
                    id=payload.id,
                    name=payload.name,
                    course=payload.course,
                    ended_at=payload.ended_at,
                    metrics=payload.metrics,
                    pct_complete=payload.pct_complete,
                ),
                course_config=result.course,
                sensor=result.sensor,
                env=env,
                api_env=api_env,
                api=api,
                app_config=app_config,
                get_client=get_client,
                hooks=hooks,
                preview_requested=False,
                deps=deps,
            )

            if completion_result.preview:
                return JSONResponse({"preview": True})

            selector_desc = format_course_selector(payload.course)
            log.debug(
                "Submitted activity: runId=%s, course=%s, id=%s",
                payload.run_id,
                selector_desc,
                payload.id,
            )

            return Response(status_code=204)

        except TimebackUserResolutionError as e:
            log.warning("Failed to resolve Timeback user: %s", e.code)
            return error_response(
                "USER_RESOLUTION_FAILED",
                "Unable to resolve Timeback identity",
                resolve_status_for_user_resolution_error(e),
            )

        except MissingSyncedCourseIdError as e:
            log.warning("Course not synced: %s, env=%s", e.course, e.env)
            return error_response("MISSING_SYNCED_COURSE_ID", str(e), 503)

        except InvalidSensorUrlError as e:
            log.error("Invalid sensor URL: %s", e.sensor)
            return error_response("INVALID_SENSOR_URL", str(e), 500)

        except CaliperValidationError as e:
            selector_desc = format_course_selector(payload.course)
            log.error(
                "Caliper validation error: course=%s, id=%s, error=%s",
                selector_desc,
                payload.id,
                str(e),
            )
            return error_response("INTERNAL_ERROR", str(e), 502, details=e.response)

        except Exception as e:
            selector_desc = format_course_selector(payload.course)
            log.error(
                "Failed to submit activity: course=%s, id=%s, error=%s",
                selector_desc,
                payload.id,
                str(e),
            )
            return error_response("INTERNAL_ERROR", str(e), 502)

    return handler
