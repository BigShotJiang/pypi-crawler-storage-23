"""
Activity Handler

Route handlers for activity tracking and submission.
"""

from ...lib.utils import safe_id_segment
from ...types import (
    ActivityHandlerDeps,
    ActivityUserInfo,
    CompletionPayload,
    HeartbeatValidationSuccess,
    SubmitValidationSuccess,
    ValidatedHeartbeatPayload,
    ValidatedSubmitPayload,
    ValidationError,
)
from .attempts import (
    compute_caliper_line_item_id,
    resolve_caliper_attempt_number,
)
from .caliper import (
    InvalidSensorUrlError,
    MissingSyncedCourseIdError,
    build_activity_context,
    build_activity_metrics,
    build_canonical_activity_url,
    build_oneroster_course_url,
    build_oneroster_user_url,
    build_submit_event,
    build_time_spent_event,
    build_time_spent_metrics,
)
from .completion import maybe_write_completion_entry
from .heartbeat_handler import create_heartbeat_handler
from .progress import (
    compute_progress,
    resolve_total_lessons,
)
from .resolve import (
    ActivityCourseResolutionError,
    resolve_activity_course,
)
from .schema import (
    format_course_selector,
    validate_heartbeat_request,
    validate_submit_request,
)
from .submit import (
    record_completion,
    resolve_attempt_number,
    resolve_timeback_id,
    send_time_spent,
)
from .submit_handler import create_submit_handler

__all__ = [
    "ActivityCourseResolutionError",
    "ActivityHandlerDeps",
    "ActivityUserInfo",
    "CompletionPayload",
    "HeartbeatValidationSuccess",
    "InvalidSensorUrlError",
    "MissingSyncedCourseIdError",
    "SubmitValidationSuccess",
    "ValidatedHeartbeatPayload",
    "ValidatedSubmitPayload",
    "ValidationError",
    "build_activity_context",
    "build_activity_metrics",
    "build_canonical_activity_url",
    "build_oneroster_course_url",
    "build_oneroster_user_url",
    "build_submit_event",
    "build_time_spent_event",
    "build_time_spent_metrics",
    "compute_caliper_line_item_id",
    "compute_progress",
    "create_heartbeat_handler",
    "create_submit_handler",
    "format_course_selector",
    "maybe_write_completion_entry",
    "record_completion",
    "resolve_activity_course",
    "resolve_attempt_number",
    "resolve_caliper_attempt_number",
    "resolve_timeback_id",
    "resolve_total_lessons",
    "safe_id_segment",
    "send_time_spent",
    "validate_heartbeat_request",
    "validate_submit_request",
]
