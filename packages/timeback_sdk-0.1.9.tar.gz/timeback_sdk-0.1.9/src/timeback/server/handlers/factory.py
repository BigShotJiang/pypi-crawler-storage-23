"""Handler factory."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from ..lib.hooks import with_request_hooks
from .activity import create_heartbeat_handler, create_submit_handler
from .identity import IdentityHandlers, create_identity_handlers
from .user import create_user_handler, create_user_verify_handler

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from starlette.requests import Request
    from starlette.responses import Response

    from timeback_core import TimebackClient

    from ..timeback import AppConfig
    from ..types import ApiCredentials, Environment, HandlerName, IdentityConfig, TimebackHooks


@dataclass
class UserHandlers:
    """User-related handlers."""

    me: Callable[[Request], Awaitable[Response]]
    verify: Callable[[Request], Awaitable[Response]]


@dataclass
class ActivityHandlers:
    """Activity-related handlers (new split API)."""

    heartbeat: Callable[[Request], Awaitable[Response]]
    """POST /activity/heartbeat — periodic time-tracking."""
    submit: Callable[[Request], Awaitable[Response]]
    """POST /activity/submit — activity completion."""


@dataclass
class Handlers:
    """All SDK handlers."""

    activity: ActivityHandlers
    identity: IdentityHandlers
    user: UserHandlers


def create_handlers(
    *,
    env: Environment,
    api: ApiCredentials,
    identity: IdentityConfig,
    app_config: AppConfig,
    get_client: Callable[[], TimebackClient],
    hooks: TimebackHooks | None = None,
) -> Handlers:
    """Create all SDK handlers.

    Args:
        env: Environment (local, staging, production)
        api: API credentials (required for full SDK)
        identity: Identity configuration
        app_config: App configuration from timeback.config.json
        get_client: Factory returning the shared TimebackClient
        hooks: Optional hooks for customizing behavior

    Returns:
        All SDK handlers
    """

    def wrap(
        name: HandlerName, fn: Callable[[Request], Awaitable[Response]]
    ) -> Callable[[Request], Awaitable[Response]]:
        """Bind lifecycle hooks to a handler."""
        return with_request_hooks(name, hooks, fn)

    identity_handlers = create_identity_handlers(env=env, identity=identity, api=api)

    return Handlers(
        activity=ActivityHandlers(
            heartbeat=wrap(
                "activity.heartbeat",
                create_heartbeat_handler(
                    env=env,
                    api=api,
                    identity=identity,
                    app_config=app_config,
                    get_client=get_client,
                    hooks=hooks,
                ),
            ),
            submit=wrap(
                "activity.submit",
                create_submit_handler(
                    env=env,
                    api=api,
                    identity=identity,
                    app_config=app_config,
                    get_client=get_client,
                    hooks=hooks,
                ),
            ),
        ),
        identity=IdentityHandlers(
            sign_in=wrap("identity.sign_in", identity_handlers.sign_in),
            callback=wrap("identity.callback", identity_handlers.callback),
            sign_out=identity_handlers.sign_out,
        ),
        user=UserHandlers(
            me=wrap(
                "user.me",
                create_user_handler(
                    env=env,
                    api=api,
                    identity=identity,
                    app_config=app_config,
                    get_client=get_client,
                ),
            ),
            verify=wrap(
                "user.verify",
                create_user_verify_handler(
                    env=env, api=api, identity=identity, get_client=get_client
                ),
            ),
        ),
    )
