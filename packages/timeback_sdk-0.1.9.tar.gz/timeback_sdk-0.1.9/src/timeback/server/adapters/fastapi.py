"""
FastAPI Adapter

Adapts Timeback handlers for FastAPI.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from fastapi import APIRouter, Request

# Keep this import at runtime: with postponed annotations, FastAPI/Pydantic resolves
# route return type strings (e.g. "Response") against module globals during schema
# generation. If Response is TYPE_CHECKING-only, annotation resolution fails.
from starlette.responses import Response  # noqa: TC002

from ..timeback import create_server

if TYPE_CHECKING:
    from ..timeback import ActivityNamespace, TimebackInstance, UserNamespace
    from ..types import TimebackConfig


class TimebackFastAPI:
    """
    FastAPI integration for the full Timeback SDK.

    Declare at module level with your config — the instance is created
    immediately, and the router is ready to mount. Callable as a FastAPI
    dependency via ``Depends(timeback)`` to inject the ``TimebackInstance``.

    Example::

        from timeback import ApiCredentials, TimebackConfig
        from timeback.server.adapters.fastapi import TimebackFastAPI

        timeback = TimebackFastAPI(TimebackConfig(
            env="staging",
            api=ApiCredentials(client_id="...", client_secret="..."),
            identity=...,
        ))

        app = FastAPI()
        app.include_router(timeback.router, prefix="/api/timeback")

    Args:
        config: Timeback SDK configuration.
        callback_path: Custom callback path for OAuth redirects. If your IdP
            has a pre-registered callback URL that differs from the SDK default
            (``/identity/callback``), specify the path here. The path should be
            relative to the router mount point (e.g., ``/auth/callback``).
    """

    def __init__(
        self,
        config: TimebackConfig,
        *,
        callback_path: str | None = None,
    ) -> None:
        self._instance: TimebackInstance = create_server(config)
        self._callback_path = callback_path
        self.router = self._build_router()

    def __call__(self) -> TimebackInstance:
        """Return the instance. Use as ``Depends(timeback)``."""
        return self._instance

    @property
    def instance(self) -> TimebackInstance:
        """The Timeback instance."""
        return self._instance

    @property
    def activity(self) -> ActivityNamespace:
        """Server-side activity namespace (e.g. ``timeback.activity.record(...)``)."""
        return self._instance.activity

    @property
    def user(self) -> UserNamespace:
        """Server-side user namespace (e.g. ``timeback.user.verify(...)``)."""
        return self._instance.user

    async def close(self) -> None:
        """Close the shared HTTP client.

        Optional — only needed if you want explicit cleanup during shutdown
        (e.g. to avoid connection pool buildup during hot-reload, or to
        suppress "unclosed client" warnings in tests).
        """
        await self._instance.close()

    def _build_router(self) -> APIRouter:
        """Build the FastAPI router with all Timeback routes."""
        router = APIRouter()

        # --- Identity routes ---

        @router.get("/identity/signin")
        async def identity_signin(request: Request) -> Response:
            return await self._instance.handle.identity.sign_in(request)

        @router.get("/identity/callback")
        async def identity_callback(request: Request) -> Response:
            return await self._instance.handle.identity.callback(request)

        if self._callback_path and self._callback_path != "/identity/callback":
            normalized_path = (
                self._callback_path
                if self._callback_path.startswith("/")
                else f"/{self._callback_path}"
            )

            @router.get(normalized_path)
            async def identity_callback_custom(request: Request) -> Response:
                return await self._instance.handle.identity.callback(request)

        @router.get("/identity/signout")
        async def identity_signout(_request: Request) -> Response:
            return self._instance.handle.identity.sign_out()

        # --- Full SDK routes ---

        @router.post("/activity/heartbeat", response_model=None)
        async def activity_heartbeat(request: Request) -> Response:
            return await self._instance.handle.activity.heartbeat(request)

        @router.post("/activity/submit", response_model=None)
        async def activity_submit(request: Request) -> Response:
            return await self._instance.handle.activity.submit(request)

        @router.get("/user/me")
        async def user_me(request: Request) -> Response:
            return await self._instance.handle.user.me(request)

        @router.get("/user/verify")
        async def user_verify(request: Request) -> Response:
            return await self._instance.handle.user.verify(request)

        return router
