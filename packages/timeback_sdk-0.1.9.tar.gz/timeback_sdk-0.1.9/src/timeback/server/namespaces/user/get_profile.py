"""
User Get Profile

Server-side programmatic API for fetching user profiles.
Programmatic equivalent of the ``/user/me`` HTTP handler.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...handlers.user.profile import build_user_profile
from ...lib.logger import create_scoped_logger
from ...lib.resolve import TimebackUserResolutionError, resolve_timeback_user_by_email
from ...lib.utils import map_env_for_api

if TYPE_CHECKING:
    from collections.abc import Callable

    from timeback_core import TimebackClient

    from ....shared.types import TimebackProfile
    from ...timeback import AppConfig
    from ...types import ApiCredentials, Environment

log = create_scoped_logger("user.get_profile")


def create_user_get_profile(
    *,
    env: Environment,
    api: ApiCredentials,
    app_config: AppConfig,
    get_client: Callable[[], TimebackClient],
) -> Any:
    """
    Create the user.get_profile() method for the TimebackInstance.

    This factory creates a bound async function that resolves a Timeback user
    by email and returns their enriched profile (identity, school, courses,
    goals, XP). Programmatic equivalent of the ``/user/me`` HTTP handler.

    Args:
        env: Environment (local, staging, production)
        api: API credentials
        app_config: App configuration
        get_client: Factory for the shared Timeback API client

    Returns:
        Async function for fetching user profiles
    """
    api_env = map_env_for_api(env)

    async def get_profile(email: str) -> TimebackProfile:
        """
        Get the full enriched profile for a user by email.

        Resolves the user via OneRoster, then builds the full profile
        including enrollments, courses, goals, and XP data. Programmatic
        equivalent of the ``/user/me`` HTTP handler.

        Args:
            email: The user's email address

        Returns:
            TimebackProfile with identity, school, courses, goals, and XP

        Raises:
            TimebackUserResolutionError: If the user cannot be found or is ambiguous
        """
        if not email:
            raise ValueError("email is required")

        log.debug("Building user profile by email")

        client = get_client()

        try:
            resolved = await resolve_timeback_user_by_email(
                env=env,
                api_credentials=api,
                user_info={"sub": email, "email": email},
                client=client,
            )

            profile = await build_user_profile(
                client=client,
                user=resolved,
                app_config=app_config,
                api_env=api_env,
            )

            return profile

        except TimebackUserResolutionError:
            raise
        except Exception as e:
            log.error("Failed to build user profile: %s", str(e))
            raise

    return get_profile
