"""
User Verify

Server-side programmatic API for verifying user existence.
Programmatic equivalent of the ``/user/verify`` HTTP handler.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ...lib.logger import create_scoped_logger
from ...lib.resolve import TimebackUserResolutionError, lookup_timeback_id_by_email

if TYPE_CHECKING:
    from collections.abc import Callable

    from timeback_core import TimebackClient

    from ....shared.types import TimebackVerifyResult

log = create_scoped_logger("user.verify")


def create_user_verify(
    *,
    get_client: Callable[[], TimebackClient],
) -> Any:
    """
    Create the user.verify() method for the TimebackInstance.

    This factory creates a bound async function that checks whether a Timeback
    user exists for the given email without building the full enriched profile.
    Programmatic equivalent of the ``/user/verify`` HTTP handler.

    Args:
        get_client: Factory for the shared Timeback API client

    Returns:
        Async function for verifying user existence
    """

    async def verify(email: str) -> TimebackVerifyResult:
        """
        Check whether a Timeback user exists for the given email.

        This is a lightweight check that does not build the full enriched
        profile. Returns the Timeback user ID if found.

        Args:
            email: The user's email address

        Returns:
            TimebackVerifyResult with ``verified`` and optional ``timeback_id``

        Raises:
            TimebackUserResolutionError: If the lookup is ambiguous or fails
        """
        from ....shared.types import TimebackVerifyResult

        if not email:
            raise ValueError("email is required")

        log.debug("Verifying user by email")

        client = get_client()

        try:
            timeback_id = await lookup_timeback_id_by_email(email=email, client=client)

            log.debug("User verified", extra={"timeback_id": timeback_id})
            return TimebackVerifyResult(verified=True, timeback_id=timeback_id)

        except TimebackUserResolutionError as e:
            if e.code == "timeback_user_not_found":
                log.debug("User not found in Timeback")
                return TimebackVerifyResult(verified=False)

            # Ambiguous or lookup_failed — re-raise
            raise

        except Exception as e:
            log.error("Failed to verify user: %s", str(e))
            raise

    return verify
