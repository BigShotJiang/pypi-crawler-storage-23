"""
Activity Record Schema

Validation logic for server-side activity recording input.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ...types import ActivityRecordInput


# ISO 8601 datetime pattern (matches Z or timezone offset)
_ISO_DATETIME_PATTERN = re.compile(
    r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$"
)


class ActivityRecordValidationError(Exception):
    """Error raised when activity record input validation fails."""

    def __init__(self, field: str, message: str) -> None:
        super().__init__(f"Validation error on '{field}': {message}")
        self.field = field
        self.message = message


# UUID v4 pattern (case-insensitive)
_UUID_PATTERN = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE
)


@dataclass
class ParsedActivityRecordInput:
    """Validated and parsed activity record input."""

    user_email: str
    user_timeback_id: str | None
    activity_id: str
    activity_name: str
    activity_course: dict[str, Any]
    # Metrics
    total_questions: int | None
    correct_questions: int | None
    mastered_units: int | None
    pct_complete: int | float | None
    xp_earned: int | float
    """XP earned (always required)."""
    # Time (optional)
    started_at: str | None
    ended_at: str | None
    active_ms: int | None
    inactive_ms: int | None
    # Correlation
    run_id: str | None
    """Optional client-generated UUID to correlate with heartbeats."""
    # Derived
    has_time: bool


def _require_dict(obj: Any, field: str) -> dict[str, Any]:
    """Require a dict field (None or non-dict fails)."""
    if obj is None or not isinstance(obj, dict):
        raise ActivityRecordValidationError(field, "Required and must be an object")
    return obj


def _require_str(obj: dict[str, Any], field: str, parent: str = "") -> str:
    """Require a non-empty string field."""
    full_field = f"{parent}.{field}" if parent else field
    value = obj.get(field)
    if not value or not isinstance(value, str):
        raise ActivityRecordValidationError(full_field, "Required and must be a non-empty string")
    return value


def _optional_str(obj: dict[str, Any], field: str, parent: str = "") -> str | None:
    """Validate an optional string field."""
    full_field = f"{parent}.{field}" if parent else field
    value = obj.get(field)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ActivityRecordValidationError(full_field, "Must be a string")
    return value


def _optional_iso_datetime(obj: dict[str, Any], field: str, parent: str = "") -> str | None:
    """Validate an optional ISO 8601 datetime field."""
    full_field = f"{parent}.{field}" if parent else field
    value = obj.get(field)
    if value is None:
        return None
    if not isinstance(value, str) or not _ISO_DATETIME_PATTERN.match(value):
        raise ActivityRecordValidationError(
            full_field, "Must be a valid ISO 8601 datetime (e.g., 2024-01-15T10:00:00Z)"
        )
    return value


def _optional_nonnegative_int(obj: dict[str, Any], field: str, parent: str = "") -> int | None:
    """Validate an optional nonnegative integer field."""
    full_field = f"{parent}.{field}" if parent else field
    value = obj.get(field)
    if value is None:
        return None
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ActivityRecordValidationError(full_field, "Must be a nonnegative integer")
    return value


def _optional_nonnegative_number(
    obj: dict[str, Any], field: str, parent: str = ""
) -> int | float | None:
    """Validate an optional nonnegative number (int or float)."""
    full_field = f"{parent}.{field}" if parent else field
    value = obj.get(field)
    if value is None:
        return None
    if not isinstance(value, int | float) or isinstance(value, bool) or value < 0:
        raise ActivityRecordValidationError(full_field, "Must be a nonnegative number")
    return value


def _require_nonnegative_number(obj: dict[str, Any], field: str, parent: str = "") -> int | float:
    """Require a nonnegative number (int or float)."""
    full_field = f"{parent}.{field}" if parent else field
    value = obj.get(field)
    if value is None:
        raise ActivityRecordValidationError(full_field, "Required")
    if not isinstance(value, int | float) or isinstance(value, bool) or value < 0:
        raise ActivityRecordValidationError(full_field, "Must be a nonnegative number")
    return value


def _optional_uuid(obj: dict[str, Any], field: str, parent: str = "") -> str | None:
    """Validate an optional UUID field."""
    full_field = f"{parent}.{field}" if parent else field
    value = obj.get(field)
    if value is None:
        return None
    if not isinstance(value, str) or not _UUID_PATTERN.match(value):
        raise ActivityRecordValidationError(full_field, "Must be a valid UUID")
    return value


def _validate_course_selector(course: dict[str, Any]) -> None:
    """Validate course selector format."""
    has_code_key = "code" in course
    has_grade = "grade" in course and course.get("grade") is not None

    # Check for empty code explicitly (user tried code-based but provided empty)
    if has_code_key:
        code_value = course.get("code")
        if not isinstance(code_value, str) or not code_value:
            raise ActivityRecordValidationError(
                "activity.course.code", "Must be a non-empty string"
            )
        # Valid code-based selector
        return

    # Grade-based selector
    if not course.get("subject") or not isinstance(course.get("subject"), str):
        raise ActivityRecordValidationError("activity.course.subject", "Required")

    if not has_grade:
        raise ActivityRecordValidationError(
            "activity.course",
            "Must have either 'code' (grade-less) or 'subject'+'grade' (grade-based)",
        )

    grade = course.get("grade")
    if not isinstance(grade, int) or isinstance(grade, bool):
        raise ActivityRecordValidationError("activity.course.grade", "Must be an integer")

    # Validate subject enum
    valid_subjects = {"Math", "Reading", "Science", "Social Studies", "Writing", "Other"}
    if course["subject"] not in valid_subjects:
        raise ActivityRecordValidationError(
            "activity.course.subject",
            f"Invalid value. Expected one of: {', '.join(repr(s) for s in sorted(valid_subjects))}",
        )

    # Validate grade range (0-12)
    if not (0 <= grade <= 12):
        raise ActivityRecordValidationError("activity.course.grade", "Must be between 0 and 12")


def validate_activity_record_input(
    input_data: ActivityRecordInput | dict[str, Any],
) -> ParsedActivityRecordInput:
    """
    Validate activity record input.

    Enforces:
    - user.email is required
    - activity.id, activity.name, activity.course are required
    - Course selector is valid ({subject, grade} or {code})
    - metrics.xp_earned is always required
    - Question count pairing (totalQuestions and correctQuestions must be together)
    - Optional run_id must be a valid UUID

    Args:
        input_data: Raw input dict or ActivityRecordInput

    Returns:
        Parsed and validated input

    Raises:
        ActivityRecordValidationError: If validation fails
    """
    data = dict(input_data)

    # ── Validate user ──
    user = _require_dict(data.get("user"), "user")
    user_email = _require_str(user, "email", "user")
    user_timeback_id = _optional_str(user, "timeback_id", "user")

    # ── Validate activity ──
    activity = _require_dict(data.get("activity"), "activity")
    activity_id = _require_str(activity, "id", "activity")
    activity_name = _require_str(activity, "name", "activity")
    activity_course = _require_dict(activity.get("course"), "activity.course")
    _validate_course_selector(activity_course)

    # ── Validate metrics (required — xp_earned is mandatory) ──
    raw_metrics = data.get("metrics")
    if raw_metrics is None:
        raise ActivityRecordValidationError("metrics", "Required")
    if not isinstance(raw_metrics, dict):
        raise ActivityRecordValidationError("metrics", "Must be an object")
    metrics: dict[str, Any] = raw_metrics

    # xp_earned is always required
    xp_earned = _require_nonnegative_number(metrics, "xp_earned", "metrics")

    total_questions = _optional_nonnegative_int(metrics, "total_questions", "metrics")
    correct_questions = _optional_nonnegative_int(metrics, "correct_questions", "metrics")
    mastered_units = _optional_nonnegative_int(metrics, "mastered_units", "metrics")
    pct_complete = _optional_nonnegative_number(metrics, "pct_complete", "metrics")

    # Paired validation: totalQuestions and correctQuestions
    has_total = total_questions is not None
    has_correct = correct_questions is not None
    if has_total != has_correct:
        raise ActivityRecordValidationError(
            "metrics", "total_questions and correct_questions must be provided together"
        )

    if has_total and has_correct and correct_questions > total_questions:  # type: ignore[operator]
        raise ActivityRecordValidationError(
            "metrics.correct_questions", "Cannot exceed total_questions"
        )

    # ── Validate time (optional) ──
    time_data = data.get("time")
    has_time = time_data is not None

    started_at: str | None = None
    ended_at: str | None = None
    active_ms: int | None = None
    inactive_ms: int | None = None

    if has_time:
        if not isinstance(time_data, dict):
            raise ActivityRecordValidationError("time", "Must be an object")
        started_at = _optional_iso_datetime(time_data, "started_at", "time")
        ended_at = _optional_iso_datetime(time_data, "ended_at", "time")
        active_ms = _optional_nonnegative_int(time_data, "active_ms", "time")
        inactive_ms = _optional_nonnegative_int(time_data, "inactive_ms", "time")

    # ── Optional run_id (UUID) ──
    run_id = _optional_uuid(data, "run_id")

    return ParsedActivityRecordInput(
        user_email=user_email,
        user_timeback_id=user_timeback_id,
        activity_id=activity_id,
        activity_name=activity_name,
        activity_course=activity_course,
        total_questions=total_questions,
        correct_questions=correct_questions,
        mastered_units=mastered_units,
        pct_complete=pct_complete,
        xp_earned=xp_earned,
        started_at=started_at,
        ended_at=ended_at,
        active_ms=active_ms,
        inactive_ms=inactive_ms,
        run_id=run_id,
        has_time=has_time,
    )
