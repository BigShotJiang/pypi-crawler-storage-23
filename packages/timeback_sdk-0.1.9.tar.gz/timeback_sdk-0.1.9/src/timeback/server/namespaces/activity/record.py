"""
Activity Record

Server-side programmatic API for recording activity completions.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, cast

from ...handlers.activity.resolve import ActivityCourseResolutionError, resolve_activity_course
from ...handlers.activity.submit import record_completion, send_time_spent
from ...lib.logger import create_scoped_logger
from ...lib.utils import map_env_for_api
from ...types import ActivityUserInfo, CompletionPayload
from .schema import (
    ParsedActivityRecordInput,
    validate_activity_record_input,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from timeback_core import TimebackClient

    from ....shared.types import ActivityCourseRef
    from ...timeback import AppConfig
    from ...types import (
        ActivityRecordInput,
        ApiCredentials,
        Environment,
        TimebackHooks,
    )

log = create_scoped_logger("namespaces.activity.record")


class ActivityRecordCourseError(Exception):
    """Error raised when course resolution fails for activity recording."""

    def __init__(self, selector: str, code: str) -> None:
        super().__init__(f"Course resolution failed for {selector}: {code}")
        self.selector = selector
        self.code = code


def _now_iso() -> str:
    """Get current UTC time as ISO 8601 string."""
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def _build_course_ref(course_data: dict[str, Any]) -> ActivityCourseRef:
    """Build a course ref from validated course data."""
    # Import here to avoid circular dependency
    from ....shared.types import (
        CourseCodeRef,
        SubjectGradeCourseRef,
        TimebackGrade,
        TimebackSubject,
    )

    if "code" in course_data and course_data.get("code"):
        return CourseCodeRef(code=course_data["code"])

    return SubjectGradeCourseRef(
        subject=cast("TimebackSubject", course_data["subject"]),
        grade=cast("TimebackGrade", course_data["grade"]),
    )


def _format_course_selector(course_data: dict[str, Any]) -> str:
    """Format course selector for error messages."""
    if "code" in course_data and course_data.get("code"):
        return f'code "{course_data["code"]}"'
    return f"{course_data.get('subject')} grade {course_data.get('grade')}"


def _to_completion_payload(
    parsed: ParsedActivityRecordInput,
) -> tuple[CompletionPayload, dict[str, Any]]:
    """
    Convert parsed record input to CompletionPayload and body dict.

    Only includes completion-related fields — no time fields.
    """
    ended_at = parsed.ended_at if parsed.ended_at else _now_iso()

    metrics: dict[str, Any] = {}
    if parsed.total_questions is not None:
        metrics["totalQuestions"] = parsed.total_questions
    if parsed.correct_questions is not None:
        metrics["correctQuestions"] = parsed.correct_questions
    if parsed.xp_earned is not None:
        metrics["xpEarned"] = parsed.xp_earned
    if parsed.mastered_units is not None:
        metrics["masteredUnits"] = parsed.mastered_units

    course_ref = _build_course_ref(parsed.activity_course)

    # Clamp pct_complete to 0-100 if provided
    pct_complete = (
        max(0, min(100, parsed.pct_complete)) if parsed.pct_complete is not None else None
    )

    payload = CompletionPayload(
        id=parsed.activity_id,
        name=parsed.activity_name,
        course=course_ref,
        ended_at=ended_at,
        metrics=metrics,
        pct_complete=pct_complete,
    )

    body: dict[str, Any] = {
        "id": parsed.activity_id,
        "name": parsed.activity_name,
        "course": parsed.activity_course,
        "endedAt": ended_at,
        "metrics": metrics,
    }

    if pct_complete is not None:
        body["pctComplete"] = pct_complete

    if parsed.run_id:
        body["runId"] = parsed.run_id

    return payload, body


def _resolve_course_and_sensor(
    course_data: dict[str, Any],
    app_config: AppConfig,
) -> tuple[dict[str, Any], str]:
    """
    Resolve course config and sensor from app config.

    Returns:
        Tuple of (course_config, sensor)

    Raises:
        ActivityRecordCourseError: If course resolution fails
    """
    course_ref = _build_course_ref(course_data)
    selector_desc = _format_course_selector(course_data)

    try:
        course_config = resolve_activity_course(
            cast("list[dict[str, Any]]", app_config.courses),
            course_ref,
        )
    except ActivityCourseResolutionError as e:
        raise ActivityRecordCourseError(selector_desc, e.code) from e

    sensor = course_config.get("sensor") or app_config.sensor

    if not sensor:
        raise ActivityRecordCourseError(
            selector_desc,
            f"Course '{selector_desc}' has no sensor configured",
        )

    return course_config, sensor


def create_activity_record(
    *,
    env: Environment,
    api: ApiCredentials,
    app_config: AppConfig,
    get_client: Callable[[], TimebackClient],
    hooks: TimebackHooks | None = None,
) -> Any:
    """
    Create the activity.record() method for the TimebackInstance.

    This factory creates a bound async function that validates input,
    converts it to the internal payload format, and calls the shared
    record_completion helper. When time data is provided, it also
    calls send_time_spent to emit a standalone TimeSpentEvent.

    Args:
        env: Environment (local, staging, production)
        api: API credentials
        app_config: App configuration
        hooks: Optional hooks

    Returns:
        Async function for recording activities
    """
    api_env = map_env_for_api(env)

    async def record(input_data: ActivityRecordInput) -> None:
        """
        Record an activity completion programmatically.

        This is the server-side equivalent of the client SDK's activity.end().
        Use this when the backend controls activity lifecycle (e.g., stateful activities).

        metrics.xp_earned is always required — auto-XP calculation has been removed.

        When time is not provided:
        - Only ActivityCompletedEvent is sent (no TimeSpentEvent)

        When time is provided:
        - ActivityCompletedEvent is sent via record_completion()
        - TimeSpentEvent is sent via send_time_spent()

        Optional run_id can be provided to correlate with heartbeats from the
        same activity session.

        Args:
            input_data: Activity record input

        Raises:
            ActivityRecordValidationError: If input validation fails
            ActivityRecordCourseError: If course resolution fails
            MissingSyncedCourseIdError: If course is not synced
        """
        # Step 1: Validate input
        parsed = validate_activity_record_input(input_data)

        # Step 2: Resolve course and sensor
        course_config, sensor = _resolve_course_and_sensor(
            parsed.activity_course,
            app_config,
        )

        # Step 3: Build user info
        user_info = ActivityUserInfo(
            email=parsed.user_email,
            timeback_id=parsed.user_timeback_id,
        )

        # Step 4: Convert to completion payload and submit
        payload, body = _to_completion_payload(parsed)

        selector_desc = _format_course_selector(parsed.activity_course)
        log.debug(
            "Recording activity: course=%s, id=%s, has_time=%s",
            selector_desc,
            parsed.activity_id,
            parsed.has_time,
        )

        await record_completion(
            user_info=user_info,
            body=body,
            payload=payload,
            course_config=course_config,
            sensor=sensor,
            env=env,
            api_env=api_env,
            api=api,
            app_config=app_config,
            get_client=get_client,
            hooks=hooks,
            preview_requested=False,
        )

        # Step 5: Send TimeSpentEvent if time data was provided
        if parsed.has_time:
            ended_at = parsed.ended_at if parsed.ended_at else _now_iso()
            elapsed_ms = parsed.active_ms or 0
            paused_ms = parsed.inactive_ms or 0
            course_ref = _build_course_ref(parsed.activity_course)

            await send_time_spent(
                user_info=user_info,
                activity_id=parsed.activity_id,
                activity_name=parsed.activity_name,
                course_selector=course_ref,
                course_config=course_config,
                sensor=sensor,
                api_env=api_env,
                api=api,
                app_config=app_config,
                get_client=get_client,
                elapsed_ms=elapsed_ms,
                paused_ms=paused_ms,
                ended_at=ended_at,
                run_id=parsed.run_id,
                hooks=hooks,
            )

    return record
