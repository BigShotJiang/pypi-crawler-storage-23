"""Activity namespace for server-side programmatic recording."""

from .record import ActivityRecordCourseError, create_activity_record
from .schema import ActivityRecordValidationError, validate_activity_record_input

__all__ = [
    "ActivityRecordCourseError",
    "ActivityRecordValidationError",
    "create_activity_record",
    "validate_activity_record_input",
]
