"""
SDK Logger

Configurable logging for the Timeback SDK server components.

All handler modules create loggers at import time::

    log = create_scoped_logger("handlers.user")

These loggers are lazy proxies — each call resolves the effective
logger at invocation time, so module-level loggers automatically
pick up configuration set later in ``create_server()``.
"""

from __future__ import annotations

import logging
import os
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..types import SdkLogger, SdkLogLevel

# ─────────────────────────────────────────────────────────────────────────────
# Global Configuration
# ─────────────────────────────────────────────────────────────────────────────

_custom_logger: SdkLogger | None = None
_log_level: SdkLogLevel | None = None

_LEVEL_MAP: dict[str, int] = {
    "debug": logging.DEBUG,
    "info": logging.INFO,
    "warning": logging.WARNING,
    "error": logging.ERROR,
}


def _is_debug() -> bool:
    """Check if debug mode is enabled via DEBUG environment variable."""
    debug = os.environ.get("DEBUG", "")
    return debug in ("1", "true", "True")


# ─────────────────────────────────────────────────────────────────────────────
# Logger Resolution
# ─────────────────────────────────────────────────────────────────────────────

_resolved_loggers: dict[str, SdkLogger] = {}


class _NoopLogger:
    """Logger that silently discards all output."""

    def debug(self, msg: str, *args: Any, **kwargs: Any) -> None:
        pass

    def info(self, msg: str, *args: Any, **kwargs: Any) -> None:
        pass

    def warning(self, msg: str, *args: Any, **kwargs: Any) -> None:
        pass

    def error(self, msg: str, *args: Any, **kwargs: Any) -> None:
        pass


_noop_logger = _NoopLogger()


class _ScopedCustomLogger:
    """Wrapper that prefixes each message with a scope tag."""

    def __init__(self, base: SdkLogger, scope: str) -> None:
        self._base = base
        self._prefix = f"[{scope}]"

    def debug(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._base.debug(f"{self._prefix} {msg}", *args, **kwargs)

    def info(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._base.info(f"{self._prefix} {msg}", *args, **kwargs)

    def warning(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._base.warning(f"{self._prefix} {msg}", *args, **kwargs)

    def error(self, msg: str, *args: Any, **kwargs: Any) -> None:
        self._base.error(f"{self._prefix} {msg}", *args, **kwargs)


def _build_stdlib_logger(scope: str, level: int) -> logging.Logger:
    """Build a standard-library logger with its own handler.

    Args:
        scope: Logger name (e.g., "timeback:handlers:user")
        level: Logging level constant

    Returns:
        Configured stdlib Logger
    """
    logger = logging.getLogger(scope)
    logger.setLevel(level)

    if not logger.hasHandlers():
        handler = logging.StreamHandler()
        handler.setFormatter(
            logging.Formatter(
                fmt="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
                datefmt="%H:%M:%S",
            )
        )
        logger.addHandler(handler)
        logger.propagate = False

    for h in logger.handlers:
        h.setLevel(level)

    return logger


def _resolve_logger(scope: str) -> Any:
    """Resolve the effective logger for a given scope.

    When a custom logger is set, wraps it to prepend the scope to each message.
    Otherwise, uses the built-in logger with the configured (or default) level.

    Args:
        scope: Full scope string (e.g., "timeback:handlers:user")

    Returns:
        Effective logger for this scope
    """
    cached = _resolved_loggers.get(scope)
    if cached is not None:
        return cached

    if _custom_logger is not None:
        logger: Any = _ScopedCustomLogger(_custom_logger, scope)
    else:
        level_name = _log_level or ("debug" if _is_debug() else "warning")
        if level_name == "silent":
            logger = _noop_logger
        else:
            logger = _build_stdlib_logger(scope, _LEVEL_MAP[level_name])

    _resolved_loggers[scope] = logger
    return logger


# ─────────────────────────────────────────────────────────────────────────────
# Lazy Proxy
# ─────────────────────────────────────────────────────────────────────────────


class _ScopedLoggerProxy:
    """Lazy proxy that resolves the effective logger on each call.

    Module-level loggers (``log = create_scoped_logger(...)``) capture
    this proxy at import time. Actual logging always uses the latest
    configuration set by ``configure_sdk_logging()``.
    """

    def __init__(self, scope: str) -> None:
        self._scope = scope

    def debug(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log a debug message."""
        _resolve_logger(self._scope).debug(msg, *args, **kwargs)

    def info(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log an info message."""
        _resolve_logger(self._scope).info(msg, *args, **kwargs)

    def warning(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log a warning message."""
        _resolve_logger(self._scope).warning(msg, *args, **kwargs)

    def error(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log an error message."""
        _resolve_logger(self._scope).error(msg, *args, **kwargs)


# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────


def configure_sdk_logging(
    *,
    logger: SdkLogger | None = None,
    log_level: SdkLogLevel | None = None,
) -> None:
    """Configure SDK-wide logging.

    Called by ``create_server()`` during initialization. Clears the logger
    cache so all existing proxies pick up the new configuration on their
    next call.

    Args:
        logger: Custom logger instance (or None for built-in)
        log_level: Minimum level for the built-in logger
    """
    global _custom_logger, _log_level
    _custom_logger = logger
    _log_level = log_level
    _resolved_loggers.clear()


def reset_sdk_logging() -> None:
    """Reset SDK logging to defaults.

    Intended for tests that need isolation between runs.
    """
    global _custom_logger, _log_level
    _custom_logger = None
    _log_level = None
    _resolved_loggers.clear()


def create_scoped_logger(scope: str) -> Any:
    """Create a scoped logger for SDK components.

    Returns a lazy proxy — each log call resolves the effective logger
    at invocation time. This allows module-level loggers to pick up
    configuration set after import.

    Args:
        scope: Logger scope name (e.g., "handlers:user", "resolve")

    Returns:
        Logger proxy scoped to ``timeback:{scope}``
    """
    return _ScopedLoggerProxy(f"timeback.{scope}")


# Pre-configured loggers for identity operations
sso_log = create_scoped_logger("sso")
"""Logger for SSO/identity operations."""

oidc_log = create_scoped_logger("oidc")
"""Logger for OIDC protocol operations."""
