"""Request lifecycle hook utilities.

Wraps request handlers with optional ``on_request_start`` / ``on_request_end``
hooks for timing, tracing, and metrics.
"""

from __future__ import annotations

import inspect
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from starlette.requests import Request
    from starlette.responses import Response

    from ..types import HandlerName, TimebackHooks


def with_request_hooks(
    handler: HandlerName,
    hooks: TimebackHooks | None,
    fn: Callable[[Request], Awaitable[Response]],
) -> Callable[[Request], Awaitable[Response]]:
    """Wrap a request handler with lifecycle hooks.

    When neither ``on_request_start`` nor ``on_request_end`` is configured the
    original handler is returned as-is (zero overhead).

    Args:
        handler: Handler name for identification.
        hooks: Hook configuration.
        fn: The request handler to wrap.

    Returns:
        Wrapped handler.
    """
    if not hooks or (not hooks.on_request_start and not hooks.on_request_end):
        return fn

    async def wrapped(request: Request) -> Response:
        if hooks.on_request_start:
            result = hooks.on_request_start({"handler": handler})
            if inspect.isawaitable(result):
                await result

        start_ns = time.monotonic_ns()
        status = 500

        try:
            response = await fn(request)
            status = response.status_code
            return response
        except Exception:
            raise
        finally:
            duration_ms = (time.monotonic_ns() - start_ns) / 1_000_000
            if hooks.on_request_end:
                result = hooks.on_request_end(
                    {"handler": handler, "duration_ms": duration_ms, "status": status}
                )
                if inspect.isawaitable(result):
                    await result

    return wrapped
