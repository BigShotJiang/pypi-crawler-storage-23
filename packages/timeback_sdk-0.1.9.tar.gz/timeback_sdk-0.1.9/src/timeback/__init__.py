"""
Timeback SDK for Python.

Server-side SDK for integrating Timeback into Python web applications.

Example (FastAPI with SSO)::

    from timeback import ApiCredentials, SsoIdentityConfig, TimebackConfig
    from timeback.server.adapters.fastapi import TimebackFastAPI

    timeback = TimebackFastAPI(TimebackConfig(
        env="staging",
        api=ApiCredentials(
            client_id=os.environ["TIMEBACK_API_CLIENT_ID"],
            client_secret=os.environ["TIMEBACK_API_CLIENT_SECRET"],
        ),
        identity=SsoIdentityConfig(
            mode="sso",
            client_id=os.environ["TIMEBACK_SSO_CLIENT_ID"],
            client_secret=os.environ["TIMEBACK_SSO_CLIENT_SECRET"],
            get_user=get_session_user,
            on_callback_success=handle_sso_success,
        ),
    ))

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        await timeback.init()
        yield
        await timeback.close()

    app = FastAPI(lifespan=lifespan)
    app.include_router(timeback.router, prefix="/api/timeback")

Example (FastAPI with custom auth)::

    from timeback import ApiCredentials, CustomIdentityConfig, TimebackConfig
    from timeback.server.adapters.fastapi import TimebackFastAPI

    timeback = TimebackFastAPI(TimebackConfig(
        env="staging",
        api=ApiCredentials(client_id="...", client_secret="..."),
        identity=CustomIdentityConfig(
            mode="custom",
            get_email=lambda req: get_session(req).email,
        ),
    ))
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("timeback-sdk")
except PackageNotFoundError:
    __version__ = "0.0.0"

from .server.types import (
    ApiCredentials,
    BuildStateContext,
    CallbackErrorContext,
    CallbackSuccessContext,
    CustomIdentityConfig,
    IdentityConfig,
    IdentityOnlyCallbackSuccessContext,
    IdentityOnlyConfig,
    IdentityOnlySsoConfig,
    IdpData,
    OIDCTokens,
    OIDCUserInfo,
    SsoIdentityConfig,
    TimebackConfig,
)
from .shared.types import (
    ActivityCourseRef,
    ActivityEndPayload,
    ActivityMetrics,
    ActivityParams,
    ActivityResponse,
    CourseCodeRef,
    Environment,
    IdentityClaims,
    SubjectGradeCourseRef,
    TimebackAuthUser,
    TimebackIdentity,
    TimebackProfile,
    TimebackSessionUser,
    TimebackUser,
    TimebackUserResolutionErrorCode,
    TimebackVerifyResult,
    is_subject_grade_course_ref,
)

__all__ = [
    "ActivityCourseRef",
    "ActivityEndPayload",
    "ActivityMetrics",
    "ActivityParams",
    "ActivityResponse",
    "ApiCredentials",
    "BuildStateContext",
    "CallbackErrorContext",
    "CallbackSuccessContext",
    "CourseCodeRef",
    "CustomIdentityConfig",
    "Environment",
    "IdentityClaims",
    "IdentityConfig",
    "IdentityOnlyCallbackSuccessContext",
    "IdentityOnlyConfig",
    "IdentityOnlySsoConfig",
    "IdpData",
    "OIDCTokens",
    "OIDCUserInfo",
    "SsoIdentityConfig",
    "SubjectGradeCourseRef",
    "TimebackAuthUser",
    "TimebackConfig",
    "TimebackIdentity",
    "TimebackProfile",
    "TimebackSessionUser",
    "TimebackUser",
    "TimebackUserResolutionErrorCode",
    "TimebackVerifyResult",
    "__version__",
    "is_subject_grade_course_ref",
]
