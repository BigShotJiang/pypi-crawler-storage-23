"""
AXIOM_Trainer - Full-Stack Training (Everything Automatic)
===========================================================

One-line training with automatic:
- TRAINABLE-QUANT: INT4 weights + FP16 error (1.6x weight compression)
- AXIOM optimizer (800x optimizer state compression)
- Gradient compression via register_hooks()
- Validation perplexity tracking
- Memory monitoring (peak VRAM)
- Results export (JSON + charts)
- Optional: Model checkpointing (off by default)

FULL STACK = 4.8x memory reduction!
    Train 774M models on 8GB GPU

Usage:
    from quarterbit import AXIOM_Trainer

    trainer = AXIOM_Trainer(model, train_loader, val_loader)
    results = trainer.fit(steps=2000)

    # Disable weight quantization:
    trainer = AXIOM_Trainer(model, train_loader, val_loader, quantize_weights=False)

February 2026
Clouthier Simulation Labs
"""

import gc
import json
import time
from datetime import datetime
from typing import Optional, Dict, List, Any
from dataclasses import dataclass, asdict, field

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    _HAS_NUMPY = False

try:
    import matplotlib.pyplot as plt
    _HAS_MATPLOTLIB = True
except ImportError:
    _HAS_MATPLOTLIB = False


@dataclass
class TrainerConfig:
    """Configuration for AXIOM_Trainer.

    All extensions that help automatically are ON by default.
    Model checkpointing is OFF by default (user opts in).
    """
    lr: float = 5e-4
    weight_decay: float = 0.01
    max_grad_norm: Optional[float] = 1.0  # Gradient clipping for stability

    # TRAINABLE-QUANT: INT4 weights + FP16 error (1.6x compression)
    # ON by default - the whole point of Full Stack!
    quantize_weights: bool = True

    # Auto-warmup: train with compressed gradients but normal LR for N steps
    # This dramatically improves convergence - keeps memory savings while stabilizing
    warmup_steps: int = 100  # 0 = disabled

    # Gradient checkpointing: recompute activations during backward pass
    # ON by default - saves 50-85% activation memory, critical for large models
    # Trade-off: ~20-30% slower training
    gradient_checkpointing: bool = True

    # Logging
    log_interval: int = 100
    eval_interval: int = 200

    # Model checkpointing (save model + optimizer state to disk)
    # OFF by default - user opts in by setting > 0
    checkpoint_interval: int = 0  # 0 = disabled, else save every N steps
    checkpoint_dir: str = "checkpoints"

    # Device
    device: str = "cuda"

    # Output
    save_results: bool = True
    results_prefix: str = "axiom_training"


class AXIOM_Trainer:
    """Full-stack trainer - everything automatic, nothing to configure.

    Automatically enables:
        - Gradient checkpointing (50-85% activation memory savings)
        - TRAINABLE-QUANT (INT4 + FP16 error, 1.6x weight compression)
        - AXIOM optimizer (800x optimizer state compression)
        - Gradient compression via register_hooks() (200x)
        - Validation perplexity tracking
        - Memory monitoring (peak VRAM)
        - Results export to JSON and PNG charts

    Optional (off by default):
        - Model checkpointing (set checkpoint_interval > 0)
        - Disable gradient_checkpointing=False for faster training

    Args:
        model: PyTorch model to train
        train_loader: Training DataLoader
        val_loader: Validation DataLoader (optional, for tracking perplexity)
        config: TrainerConfig or dict with config options
        **kwargs: Config options (lr, eval_interval, checkpoint_interval, etc.)

    Example:
        from quarterbit import AXIOM_Trainer

        trainer = AXIOM_Trainer(model, train_loader, val_loader)
        results = trainer.fit(steps=2000)

        # With checkpointing:
        trainer = AXIOM_Trainer(model, train_loader, val_loader, checkpoint_interval=500)
        results = trainer.fit(steps=5000)

        # Results dict includes:
        # - train_losses, val_losses, val_ppls
        # - peak_vram_gb, tokens_per_sec
        # - compression_total, compression_optimizer, compression_gradients
    """

    def __init__(
        self,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: Optional[DataLoader] = None,
        config: Optional[TrainerConfig] = None,
        **kwargs
    ):
        # Import here to avoid circular imports
        try:
            from .optimizer import AXIOM
            from .trainable_quant import make_trainable_quantized, verify_trainable
        except ImportError:
            from optimizer import AXIOM
            from trainable_quant import make_trainable_quantized, verify_trainable

        self.train_loader = train_loader
        self.val_loader = val_loader

        # Config
        if config is None:
            config = TrainerConfig(**kwargs)
        elif isinstance(config, dict):
            config = TrainerConfig(**config)
        self.config = config

        # Device
        self.device = torch.device(config.device if torch.cuda.is_available() else "cpu")

        # Apply gradient checkpointing if enabled (default: ON)
        # Must be done BEFORE quantization for some model architectures
        if config.gradient_checkpointing:
            if hasattr(model, 'gradient_checkpointing_enable'):
                model.gradient_checkpointing_enable()
                print("Gradient checkpointing enabled (saves 50-85% activation memory)")
            else:
                print("Warning: Model does not support gradient_checkpointing_enable()")

        # Apply TRAINABLE-QUANT if enabled (default: ON)
        if config.quantize_weights:
            print("Applying TRAINABLE-QUANT (INT4 + FP16 error)...")
            model = make_trainable_quantized(model, verbose=True)
            stats = verify_trainable(model)
            print(f"  Trainable params: {stats['trainable_params']:,} ({stats['trainable_pct']:.1f}%)")

        self.model = model

        # Model stats
        self.total_params = sum(p.numel() for p in model.parameters())
        self.trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        self.model_size_gb = sum(p.numel() * p.element_size() for p in model.parameters()) / 1e9

        # Create AXIOM optimizer (auto gradient compression with warmup)
        # Divide LR by 25 because register_hooks() will multiply by 25x after warmup
        # This way user passes their desired effective LR directly
        self.optimizer = AXIOM(
            model.parameters(),
            lr=config.lr / 25.0,
            weight_decay=config.weight_decay,
            max_grad_norm=config.max_grad_norm
        )

        # Calculate AXIOM memory usage
        n_groups = (self.total_params + 512 - 1) // 512
        self.axiom_opt_mb = (n_groups * 3) / 1e6
        self.axiom_grad_mb = (n_groups * 3) / 1e6

        # AdamW equivalent memory
        self.adamw_opt_gb = (self.total_params * 8) / 1e9
        self.adamw_grad_gb = (self.total_params * 2) / 1e9

        # Model checkpointing directory
        if config.checkpoint_interval > 0:
            import os
            os.makedirs(config.checkpoint_dir, exist_ok=True)

        # Training state
        self._hooks_registered = False
        self._results = None

        # Auto-detect model type (HuggingFace vs generic PyTorch)
        self._is_hf_model = self._detect_hf_model(model)

    def _detect_hf_model(self, model: nn.Module) -> bool:
        """Auto-detect if model is HuggingFace-style (accepts input_ids, returns .loss)."""
        import inspect
        try:
            sig = inspect.signature(model.forward)
            params = list(sig.parameters.keys())
            # HuggingFace models have input_ids and labels parameters
            return 'input_ids' in params or 'inputs_embeds' in params
        except (ValueError, TypeError):
            return False

    def _forward_pass(self, input_ids, attn_mask=None, labels=None):
        """Unified forward pass supporting both HuggingFace and generic models."""
        if self._is_hf_model:
            # HuggingFace style: model(input_ids=..., labels=...) -> outputs.loss
            if attn_mask is not None:
                outputs = self.model(input_ids=input_ids, attention_mask=attn_mask, labels=labels)
            else:
                outputs = self.model(input_ids=input_ids, labels=labels)
            return outputs.loss
        else:
            # Generic PyTorch model: model(x) -> logits, compute loss separately
            import torch.nn.functional as F
            if attn_mask is not None:
                logits = self.model(input_ids, attn_mask)
            else:
                logits = self.model(input_ids)
            # Compute cross-entropy loss
            if labels is None:
                labels = input_ids
            # Handle different output shapes
            if logits.dim() == 3:  # (batch, seq, vocab) - sequence model
                loss = F.cross_entropy(logits.view(-1, logits.size(-1)), labels.view(-1))
            elif logits.dim() == 2 and labels.dim() == 2:  # (batch, vocab) but labels is (batch, seq)
                # For pooled models, use first token as target
                loss = F.cross_entropy(logits, labels[:, 0])
            else:  # (batch, vocab) with (batch,) labels
                loss = F.cross_entropy(logits, labels.view(-1) if labels.dim() > 1 else labels)
            return loss

    def _reset_memory(self):
        """Aggressive memory cleanup."""
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.synchronize()
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()
        gc.collect()

    def _get_memory(self) -> Dict[str, float]:
        """Get current memory stats."""
        if not torch.cuda.is_available():
            return {"allocated_gb": 0, "peak_gb": 0}
        return {
            "allocated_gb": torch.cuda.memory_allocated() / 1e9,
            "peak_gb": torch.cuda.max_memory_allocated() / 1e9
        }

    @torch.no_grad()
    def evaluate(self, max_batches: int = 50) -> tuple:
        """Evaluate model on validation set.

        Returns:
            Tuple of (avg_loss, perplexity)
        """
        if self.val_loader is None:
            return 0.0, 0.0

        self.model.eval()
        total_loss = 0
        count = 0

        for batch in self.val_loader:
            if isinstance(batch, dict):
                input_ids = batch['input_ids'].to(self.device)
                attn_mask = batch.get('attention_mask')
                if attn_mask is not None:
                    attn_mask = attn_mask.to(self.device)
            elif isinstance(batch, (list, tuple)):
                input_ids = batch[0].to(self.device)
                attn_mask = batch[1].to(self.device) if len(batch) > 1 else None
            else:
                input_ids = batch.to(self.device)
                attn_mask = None

            loss = self._forward_pass(input_ids, attn_mask, labels=input_ids)
            total_loss += loss.item()
            count += 1

            if count >= max_batches:
                break

        self.model.train()

        if count == 0:
            return 0.0, 0.0

        avg_loss = total_loss / count
        ppl = float('inf')
        if _HAS_NUMPY:
            try:
                ppl = np.exp(avg_loss)
            except OverflowError:
                ppl = float('inf')
        else:
            import math
            try:
                ppl = math.exp(avg_loss)
            except OverflowError:
                ppl = float('inf')

        return avg_loss, ppl

    def fit(
        self,
        steps: int = 1000,
        log_interval: Optional[int] = None,
        eval_interval: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Train the model with full-stack AXIOM.

        Args:
            steps: Number of training steps
            log_interval: Steps between logging (default: config.log_interval)
            eval_interval: Steps between validation (default: config.eval_interval)

        Returns:
            Dict with training results
        """
        log_interval = log_interval or self.config.log_interval
        eval_interval = eval_interval or self.config.eval_interval

        # Enable gradient compression with auto-warmup
        # Compression starts immediately (memory savings), LR boost after warmup
        if not self._hooks_registered:
            self.optimizer.register_hooks(warmup_steps=self.config.warmup_steps)
            self._hooks_registered = True

        self.model.train()
        self._reset_memory()
        torch.cuda.reset_peak_memory_stats() if torch.cuda.is_available() else None

        # Initialize tracking
        train_losses: List[float] = []
        val_losses: List[float] = []
        val_ppls: List[float] = []

        train_iter = iter(self.train_loader)
        total_tokens = 0
        start_time = time.time()

        # Initial validation
        if self.val_loader is not None:
            init_val_loss, init_val_ppl = self.evaluate()
            val_losses.append(init_val_loss)
            val_ppls.append(init_val_ppl)
            print(f"Initial Val Loss: {init_val_loss:.4f} | Val PPL: {init_val_ppl:.2f}")

        print(f"\nTraining {self.total_params/1e9:.2f}B model for {steps} steps...")
        print(f"AXIOM: {self.axiom_opt_mb + self.axiom_grad_mb:.1f}MB vs AdamW: {(self.adamw_opt_gb + self.adamw_grad_gb)*1000:.0f}MB")
        print()

        for step in range(1, steps + 1):
            # Get batch
            try:
                batch = next(train_iter)
            except StopIteration:
                train_iter = iter(self.train_loader)
                batch = next(train_iter)

            # Handle different batch formats
            if isinstance(batch, dict):
                input_ids = batch['input_ids'].to(self.device)
                attn_mask = batch.get('attention_mask')
                if attn_mask is not None:
                    attn_mask = attn_mask.to(self.device)
            elif isinstance(batch, (list, tuple)):
                input_ids = batch[0].to(self.device)
                attn_mask = batch[1].to(self.device) if len(batch) > 1 else None
            else:
                input_ids = batch.to(self.device)
                attn_mask = None

            # Forward (auto-detects HuggingFace vs generic PyTorch)
            loss = self._forward_pass(input_ids, attn_mask, labels=input_ids)

            # Check for NaN/Inf
            if torch.isnan(loss) or torch.isinf(loss):
                print(f"NaN/Inf at step {step}!")
                break

            # Backward
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step(loss=loss.item())

            # Explicit float() to avoid Cython weakref issue
            train_losses.append(float(loss.item()))
            total_tokens += input_ids.numel()

            # Logging
            if step % log_interval == 0:
                elapsed = time.time() - start_time
                tps = total_tokens / elapsed
                mem = self._get_memory()
                print(f"Step {step:4d}/{steps} | Loss: {loss.item():.4f} | {tps:.0f} tok/s | Peak: {mem['peak_gb']:.1f}GB")

            # Validation
            if self.val_loader is not None and step % eval_interval == 0:
                v_loss, v_ppl = self.evaluate()
                val_losses.append(v_loss)
                val_ppls.append(v_ppl)
                print(f"         >>> Val Loss: {v_loss:.4f} | Val PPL: {v_ppl:.2f}")

            # Model checkpoint
            if self.config.checkpoint_interval > 0 and step % self.config.checkpoint_interval == 0:
                self.save_checkpoint(step)

        end_time = time.time()
        total_time = end_time - start_time
        final_mem = self._get_memory()

        # Final validation
        if self.val_loader is not None:
            final_val_loss, final_val_ppl = self.evaluate()
            val_losses.append(final_val_loss)
            val_ppls.append(final_val_ppl)

        # Compute compression stats
        compression_opt = self.adamw_opt_gb * 1000 / self.axiom_opt_mb if self.axiom_opt_mb > 0 else 0
        compression_grad = self.adamw_grad_gb * 1000 / self.axiom_grad_mb if self.axiom_grad_mb > 0 else 0
        compression_total = (self.adamw_opt_gb + self.adamw_grad_gb) * 1000 / (self.axiom_opt_mb + self.axiom_grad_mb)

        # Build results
        self._results = {
            "timestamp": datetime.now().isoformat(),
            "model_params_b": self.total_params / 1e9,
            "model_size_gb": self.model_size_gb,
            "steps": steps,
            "total_time_sec": total_time,
            "total_time_min": total_time / 60,
            "tokens_per_sec": total_tokens / total_time,
            "peak_vram_gb": final_mem["peak_gb"],

            # Training metrics
            "initial_train_loss": train_losses[0] if train_losses else 0,
            "final_train_loss": train_losses[-1] if train_losses else 0,
            "train_improvement_pct": (train_losses[0] - train_losses[-1]) / train_losses[0] * 100 if train_losses and train_losses[0] > 0 else 0,

            # Validation metrics
            "initial_val_loss": val_losses[0] if val_losses else 0,
            "final_val_loss": val_losses[-1] if val_losses else 0,
            "initial_val_ppl": val_ppls[0] if val_ppls else 0,
            "final_val_ppl": val_ppls[-1] if val_ppls else 0,
            "val_improvement_pct": (val_ppls[0] - val_ppls[-1]) / val_ppls[0] * 100 if val_ppls and val_ppls[0] > 0 else 0,

            # Compression stats
            "axiom_opt_mb": self.axiom_opt_mb,
            "axiom_grad_mb": self.axiom_grad_mb,
            "adamw_opt_gb": self.adamw_opt_gb,
            "adamw_grad_gb": self.adamw_grad_gb,
            "compression_optimizer": compression_opt,
            "compression_gradients": compression_grad,
            "compression_total": compression_total,

            # Raw data
            "train_losses": train_losses,
            "val_losses": val_losses,
            "val_ppls": val_ppls,
        }

        # Print summary
        print(f"\n{'='*70}")
        print("TRAINING COMPLETE!")
        print(f"{'='*70}")
        print(f"  Steps: {steps}")
        print(f"  Time: {total_time/60:.1f} minutes")
        print(f"  Speed: {total_tokens/total_time:.0f} tokens/sec")
        print(f"  Peak VRAM: {final_mem['peak_gb']:.1f} GB")
        print(f"\n  Train Loss: {train_losses[0]:.4f} -> {train_losses[-1]:.4f} ({self._results['train_improvement_pct']:.1f}% improvement)")
        if val_ppls:
            print(f"  Val PPL:    {val_ppls[0]:.2f} -> {val_ppls[-1]:.2f} ({self._results['val_improvement_pct']:.1f}% improvement)")
        print(f"\n  AXIOM Compression: {compression_total:.0f}x")

        # Save results
        if self.config.save_results:
            self._save_results()

        return self._results

    def _save_results(self):
        """Save results to JSON and plot to PNG."""
        if self._results is None:
            return

        prefix = self.config.results_prefix

        # Save JSON
        json_path = f"{prefix}_results.json"
        # Convert numpy arrays to lists for JSON serialization
        results_copy = self._results.copy()
        for key in ['train_losses', 'val_losses', 'val_ppls']:
            if key in results_copy and hasattr(results_copy[key], 'tolist'):
                results_copy[key] = results_copy[key].tolist()

        with open(json_path, 'w') as f:
            json.dump(results_copy, f, indent=2)
        print(f"\nResults saved to {json_path}")

        # Save chart
        if _HAS_MATPLOTLIB and _HAS_NUMPY:
            self._save_chart(f"{prefix}_chart.png")

    def _save_chart(self, path: str):
        """Generate and save training chart."""
        if not _HAS_MATPLOTLIB or not _HAS_NUMPY:
            return

        results = self._results
        train_losses = results['train_losses']
        val_ppls = results['val_ppls']

        fig, axes = plt.subplots(1, 3, figsize=(15, 4))

        # 1. Training Loss
        ax = axes[0]
        ax.plot(train_losses, color='#27ae60', alpha=0.5, linewidth=0.5)
        # Smoothed
        window = min(50, len(train_losses) // 10) or 1
        if window > 1:
            smoothed = np.convolve(train_losses, np.ones(window)/window, mode='valid')
            ax.plot(range(window-1, len(train_losses)), smoothed, color='#27ae60', linewidth=2)
        ax.set_xlabel('Step')
        ax.set_ylabel('Training Loss')
        ax.set_title('Training Loss')
        ax.grid(True, alpha=0.3)

        # 2. Validation Perplexity
        ax = axes[1]
        if val_ppls:
            eval_interval = self.config.eval_interval
            steps = results['steps']
            eval_steps = [0] + list(range(eval_interval, steps + 1, eval_interval))
            if len(eval_steps) < len(val_ppls):
                eval_steps.append(steps)
            ax.plot(eval_steps[:len(val_ppls)], val_ppls, 'o-', color='#3498db', linewidth=2)
        ax.set_xlabel('Step')
        ax.set_ylabel('Validation Perplexity')
        ax.set_title('Validation PPL (lower = better)')
        ax.grid(True, alpha=0.3)

        # 3. Memory Comparison
        ax = axes[2]
        labels = ['AdamW', 'AXIOM']
        adamw_mem = results['adamw_opt_gb'] + results['adamw_grad_gb']
        axiom_mem = (results['axiom_opt_mb'] + results['axiom_grad_mb']) / 1000
        bars = ax.bar(labels, [adamw_mem, axiom_mem], color=['#e74c3c', '#27ae60'])
        ax.set_ylabel('Opt+Grad Memory (GB)')
        ax.set_title(f"Memory: {results['compression_total']:.0f}x Compression")
        for bar, val in zip(bars, [adamw_mem, axiom_mem]):
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                    f'{val:.1f}GB' if val > 0.1 else f'{val*1000:.0f}MB',
                    ha='center', fontsize=10, fontweight='bold')

        plt.suptitle(f"AXIOM Training: {results['model_params_b']:.1f}B params, {results['steps']} steps",
                     fontsize=12, fontweight='bold')
        plt.tight_layout()
        plt.savefig(path, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"Chart saved to {path}")

    def save_checkpoint(self, step: int, path: Optional[str] = None):
        """Save model and optimizer checkpoint.

        Args:
            step: Current training step
            path: Optional custom path (default: checkpoints/step_{step}.pt)
        """
        import os
        if path is None:
            path = os.path.join(self.config.checkpoint_dir, f"step_{step}.pt")

        checkpoint = {
            'step': step,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'config': asdict(self.config),
        }

        torch.save(checkpoint, path)
        print(f"         >>> Checkpoint saved: {path}")

    def load_checkpoint(self, path: str) -> int:
        """Load model and optimizer checkpoint.

        Args:
            path: Path to checkpoint file

        Returns:
            Step number from checkpoint
        """
        checkpoint = torch.load(path, map_location=self.device)

        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])

        step = checkpoint.get('step', 0)
        print(f"Checkpoint loaded from {path} (step {step})")
        return step

    def cleanup(self):
        """Remove hooks and clean up."""
        if self._hooks_registered:
            self.optimizer.remove_hooks()
            self._hooks_registered = False
        self._reset_memory()

    def __del__(self):
        """Cleanup on deletion."""
        try:
            self.cleanup()
        except Exception:
            pass
