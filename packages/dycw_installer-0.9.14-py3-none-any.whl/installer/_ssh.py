from __future__ import annotations

from pathlib import Path
from shlex import join
from typing import TYPE_CHECKING, assert_never

import utilities.subprocess
from utilities.core import (
    PermissionsLike,
    normalize_multi_line_str,
    normalize_str,
    to_logger,
)
from utilities.subprocess import (
    BASH_LS,
    chmod,
    chmod_cmd,
    chown,
    chown_cmd,
    maybe_sudo_cmd,
    mkdir,
    mkdir_cmd,
    tee,
    tee_cmd,
)
from utilities.types import PathLike

from installer._utilities import get_home, get_root

if TYPE_CHECKING:
    from utilities.types import Group, Owner, PathLike, Retry

    from installer._types import SSH


_LOGGER = to_logger(__name__)


##


def set_up_authorized_keys(
    keys: list[str],
    /,
    *,
    home: PathLike | None = None,
    ssh: SSH | None = None,
    sudo: bool = False,
    perms: PermissionsLike | None = None,
    owner: Owner | None = None,
    group: Group | None = None,
    batch_mode: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up the SSH authorized keys."""
    _LOGGER.info("Setting up authorized keys...")
    path = get_home(home=home) / ".ssh/authorized_keys"
    text = normalize_str("\n".join(keys))
    match ssh:
        case None:
            tee(path, text, sudo=sudo)
            if perms is not None:
                chmod(path, perms, sudo=sudo, recursive=True)
            if (owner is not None) or (group is not None):
                chown(path, sudo=sudo, recursive=True, owner=owner, group=group)
        case user, hostname:
            utilities.subprocess.ssh(
                user,
                hostname,
                *maybe_sudo_cmd(*tee_cmd(path), sudo=sudo),
                batch_mode=batch_mode,
                input=text,
                retry=retry,
                logger=_LOGGER,
            )
            if perms is not None:
                utilities.subprocess.ssh(
                    user,
                    hostname,
                    *maybe_sudo_cmd(*chmod_cmd(path, perms, recursive=True), sudo=sudo),
                    retry=retry,
                    logger=_LOGGER,
                )
            if (owner is not None) or (group is not None):
                utilities.subprocess.ssh(
                    user,
                    hostname,
                    *maybe_sudo_cmd(
                        *chown_cmd(path, recursive=True, owner=owner, group=group),
                        sudo=sudo,
                    ),
                    retry=retry,
                    logger=_LOGGER,
                )
        case never:
            assert_never(never)


##


def set_up_ssh_config(
    *,
    home: PathLike | None = None,
    ssh: SSH | None = None,
    sudo: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up the SSH config."""
    _LOGGER.info("Setting up SSH config...")
    config = get_home(home=home) / ".ssh/config"
    config_d = get_home(home=home) / ".ssh/config.d"
    text = normalize_str(f"Include {config_d}/*.conf")
    match ssh:
        case None:
            tee(config, text, sudo=sudo)
            mkdir(config_d, sudo=sudo)
        case user, hostname:
            cmds: list[list[str]] = [
                mkdir_cmd(config, parent=True),
                mkdir_cmd(config_d),
            ]
            utilities.subprocess.ssh(
                user,
                hostname,
                *BASH_LS,
                input="\n".join(map(join, cmds)),
                retry=retry,
                logger=_LOGGER,
            )
            utilities.subprocess.ssh(
                user,
                hostname,
                *tee_cmd(config),
                input=text,
                retry=retry,
                logger=_LOGGER,
            )
        case never:
            assert_never(never)


##


def set_up_sshd_config(
    *,
    permit_root_login: bool = False,
    root: PathLike | None = None,
    ssh: SSH | None = None,
    sudo: bool = False,
    retry: Retry | None = None,
) -> None:
    _LOGGER.info("Setting up SSHD config...")
    path = get_root(root=root) / "etc/ssh/sshd_config.d/default.conf"
    text = sshd_config(permit_root_login=permit_root_login)
    match ssh:
        case None:
            tee(path, text, sudo=sudo)
        case user, hostname:
            path = Path("/etc/ssh/sshd_config.d/default.conf")
            utilities.subprocess.ssh(
                user,
                hostname,
                *maybe_sudo_cmd(*tee_cmd(path), sudo=sudo),
                input=text,
                retry=retry,
                logger=_LOGGER,
            )
        case never:
            assert_never(never)


##


def sshd_config(*, permit_root_login: bool = False) -> str:
    yes_no = "yes" if permit_root_login else "no"
    return normalize_multi_line_str(f"""
        PasswordAuthentication no
        PermitRootLogin {yes_no}
        PubkeyAcceptedAlgorithms ssh-ed25519
        PubkeyAuthentication yes
    """)


__all__ = [
    "set_up_authorized_keys",
    "set_up_ssh_config",
    "set_up_sshd_config",
    "sshd_config",
]
