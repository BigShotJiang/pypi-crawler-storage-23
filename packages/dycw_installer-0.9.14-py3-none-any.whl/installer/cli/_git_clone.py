from __future__ import annotations

from typing import TYPE_CHECKING

import utilities.click
from click import Command, command
from utilities.click import CONTEXT_SETTINGS, Str, argument, option
from utilities.core import is_pytest, set_up_logging

from installer import __version__
from installer._click import home_option, retry_option
from installer._constants import GIT_CLONE_HOST, GIT_CLONE_USER
from installer._git_clone import git_clone_deploy_key

if TYPE_CHECKING:
    from collections.abc import Callable

    from utilities.types import PathLike, Retry


def make_git_clone_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @argument("key", type=utilities.click.Path(exist="existing file"))
    @argument("owner", type=Str())
    @argument("repo", type=Str())
    @home_option
    @option("--user", type=Str(), default=GIT_CLONE_USER, help="'git' user")
    @option("--host", type=Str(), default=GIT_CLONE_HOST, help="Repository host")
    @option("--port", type=int, default=None, help="Repository port")
    @retry_option
    @option(
        "--dest",
        type=utilities.click.Path(exist="dir if exists"),
        default=None,
        help="Path to clone to",
    )
    @option("--branch", type=Str(), default=None, help="Branch to check out")
    def func(
        *,
        key: PathLike,
        owner: str,
        repo: str,
        home: PathLike | None,
        user: str,
        host: str,
        port: int | None,
        retry: Retry | None,
        dest: PathLike | None,
        branch: str | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        git_clone_deploy_key(
            key,
            owner,
            repo,
            home=home,
            user=user,
            host=host,
            port=port,
            retry=retry,
            dest=dest,
            branch=branch,
        )

    return cli(
        name=name, help="Clone a repository with a deploy key", **CONTEXT_SETTINGS
    )(func)


__all__ = ["make_git_clone_cmd"]
