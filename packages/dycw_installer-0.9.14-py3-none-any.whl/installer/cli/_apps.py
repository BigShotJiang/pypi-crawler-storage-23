from __future__ import annotations

from typing import TYPE_CHECKING

import utilities.click
from click import Command, command
from utilities.click import CONTEXT_SETTINGS, Str, argument, option
from utilities.core import PermissionsLike, is_pytest, set_up_logging
from utilities.types import PathLike, Retry

from installer import __version__
from installer._apps import (
    set_up_age,
    set_up_apt_package,
    set_up_bat,
    set_up_bottom,
    set_up_build_essential,
    set_up_curl,
    set_up_delta,
    set_up_direnv,
    set_up_docker,
    set_up_dust,
    set_up_eza,
    set_up_fd,
    set_up_fzf,
    set_up_gh,
    set_up_git,
    set_up_jq,
    set_up_just,
    set_up_neovim,
    set_up_pgbackrest,
    set_up_postgres,
    set_up_prek,
    set_up_pve,
    set_up_restic,
    set_up_ripgrep,
    set_up_rsync,
    set_up_ruff,
    set_up_sd,
    set_up_shellcheck,
    set_up_shfmt,
    set_up_sops,
    set_up_sqlite3,
    set_up_starship,
    set_up_stylua,
    set_up_taplo,
    set_up_tmux,
    set_up_uv,
    set_up_watchexec,
    set_up_yq,
    set_up_zoxide,
)
from installer._click import (
    etc_option,
    force_option,
    group_option,
    home_option,
    owner_option,
    path_binaries_option,
    perms_binary_option,
    perms_config_option,
    perms_option,
    retry_option,
    root_option,
    shell_option,
    ssh_option,
    sudo_option,
    token_option,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from utilities.shellingham import Shell
    from utilities.types import Group, Owner, PathLike, Retry, SecretLike

    from installer._types import SSH


def make_age_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_age(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'age'", **CONTEXT_SETTINGS)(func)


##


def make_apt_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @argument("package", type=Str())
    @sudo_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *, package: str, sudo: bool, ssh: SSH | None, force: bool, retry: Retry | None
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_apt_package(package, sudo=sudo, ssh=ssh, force=force, retry=retry)

    return cli(name=name, help="Set up a package using 'apt'", **CONTEXT_SETTINGS)(func)


##


def make_bat_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_bat(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'bat'", **CONTEXT_SETTINGS)(func)


##


def make_bottom_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_bottom(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'bottom'", **CONTEXT_SETTINGS)(func)


##


def make_build_essential_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @sudo_option
    @ssh_option
    @force_option
    @retry_option
    def func(*, sudo: bool, ssh: SSH | None, force: bool, retry: Retry | None) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_build_essential(sudo=sudo, ssh=ssh, force=force, retry=retry)

    return cli(name=name, help="Set up 'build-essential'", **CONTEXT_SETTINGS)(func)


##


def make_curl_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @sudo_option
    @ssh_option
    @force_option
    @retry_option
    def func(*, sudo: bool, ssh: SSH | None, force: bool, retry: Retry | None) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_curl(sudo=sudo, ssh=ssh, force=force, retry=retry)

    return cli(name=name, help="Set up 'curl'", **CONTEXT_SETTINGS)(func)


##


def make_delta_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_delta(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'delta'", **CONTEXT_SETTINGS)(func)


##


def make_direnv_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_binary_option
    @owner_option
    @group_option
    @etc_option
    @shell_option
    @home_option
    @perms_config_option
    @root_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms_binary: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        shell: Shell | None,
        etc: bool,
        home: PathLike | None,
        perms_config: PermissionsLike,
        root: PathLike | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_direnv(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms_binary=perms_binary,
            owner=owner,
            group=group,
            etc=etc,
            shell=shell,
            home=home,
            perms_config=perms_config,
            root=root,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'direnv'", **CONTEXT_SETTINGS)(func)


##


def make_docker_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @sudo_option
    @ssh_option
    @option(
        "--user", type=Str(), default=None, help="User to add to the 'docker' group"
    )
    @force_option
    @retry_option
    def func(
        *,
        sudo: bool,
        ssh: SSH | None,
        user: str | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_docker(sudo=sudo, ssh=ssh, user=user, force=force, retry=retry)

    return cli(name=name, help="Set up 'docker'", **CONTEXT_SETTINGS)(func)


##


def make_dust_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_dust(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'dust'", **CONTEXT_SETTINGS)(func)


##


def make_eza_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_eza(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'eza'", **CONTEXT_SETTINGS)(func)


##


def make_fd_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_fd(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'fd'", **CONTEXT_SETTINGS)(func)


##


def make_fzf_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_binary_option
    @owner_option
    @group_option
    @etc_option
    @shell_option
    @home_option
    @perms_config_option
    @root_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms_binary: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        etc: bool,
        shell: Shell | None,
        home: PathLike | None,
        perms_config: PermissionsLike,
        root: PathLike | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_fzf(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms_binary=perms_binary,
            owner=owner,
            group=group,
            etc=etc,
            shell=shell,
            home=home,
            perms_config=perms_config,
            root=root,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'fzf'", **CONTEXT_SETTINGS)(func)


##


def make_gh_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_gh(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'gh'", **CONTEXT_SETTINGS)(func)


##


def make_git_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @sudo_option
    @ssh_option
    @force_option
    @retry_option
    def func(*, sudo: bool, ssh: SSH | None, force: bool, retry: Retry | None) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_git(sudo=sudo, ssh=ssh, force=force, retry=retry)

    return cli(name=name, help="Set up 'git'", **CONTEXT_SETTINGS)(func)


##


def make_jq_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_jq(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'jq'", **CONTEXT_SETTINGS)(func)


##


def make_just_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_just(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'just'", **CONTEXT_SETTINGS)(func)


##


def make_neovim_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @option("--repo", type=Str(), default=None, help="Settings repo to clone")
    @home_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        repo: str | None,
        home: PathLike | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_neovim(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            repo=repo,
            home=home,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'neovim'", **CONTEXT_SETTINGS)(func)


##


def make_pgbackrest_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @sudo_option
    @ssh_option
    @force_option
    @retry_option
    def func(*, sudo: bool, ssh: SSH | None, force: bool, retry: Retry | None) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_pgbackrest(sudo=sudo, ssh=ssh, force=force, retry=retry)

    return cli(name=name, help="Set up 'pgbackrest'", **CONTEXT_SETTINGS)(func)


##


def make_postgres_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @sudo_option
    @ssh_option
    @force_option
    @retry_option
    def func(*, sudo: bool, ssh: SSH | None, force: bool, retry: Retry | None) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_postgres(sudo=sudo, ssh=ssh, force=force, retry=retry)

    return cli(name=name, help="Set up 'postgres'", **CONTEXT_SETTINGS)(func)


##


def make_prek_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_prek(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'prek'", **CONTEXT_SETTINGS)(func)


##


def make_pve_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *, token: SecretLike | None, ssh: SSH | None, force: bool, retry: Retry | None
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_pve(token=token, ssh=ssh, force=force, retry=retry)

    return cli(name=name, help="Set up 'pve'", **CONTEXT_SETTINGS)(func)


##


def make_restic_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_restic(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'restic'", **CONTEXT_SETTINGS)(func)


##


def make_ripgrep_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_ripgrep(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'ripgrep'", **CONTEXT_SETTINGS)(func)


##


def make_rsync_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @sudo_option
    @ssh_option
    @force_option
    @retry_option
    def func(*, sudo: bool, ssh: SSH | None, force: bool, retry: Retry | None) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_rsync(sudo=sudo, ssh=ssh, force=force, retry=retry)

    return cli(name=name, help="Set up 'rsync'", **CONTEXT_SETTINGS)(func)


##


def make_ruff_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_ruff(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'ruff'", **CONTEXT_SETTINGS)(func)


##


def make_sd_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_sd(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'sd'", **CONTEXT_SETTINGS)(func)


##


def make_shellcheck_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_shellcheck(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'shellcheck'", **CONTEXT_SETTINGS)(func)


##


def make_shfmt_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_shfmt(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'shfmt'", **CONTEXT_SETTINGS)(func)


##


def make_sops_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_sops(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'sops'", **CONTEXT_SETTINGS)(func)


##


def make_sqlite3_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @sudo_option
    @ssh_option
    @force_option
    @retry_option
    def func(*, sudo: bool, ssh: SSH | None, force: bool, retry: Retry | None) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_sqlite3(sudo=sudo, ssh=ssh, force=force, retry=retry)

    return cli(name=name, help="Set up 'sqlite3'", **CONTEXT_SETTINGS)(func)


##


def make_starship_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_binary_option
    @owner_option
    @group_option
    @etc_option
    @shell_option
    @home_option
    @perms_config_option
    @root_option
    @option(
        "--starship-toml",
        type=utilities.click.Path(exist="file if exists"),
        default=None,
    )
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms_binary: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        etc: bool,
        shell: Shell | None,
        home: PathLike | None,
        perms_config: PermissionsLike,
        root: PathLike | None,
        starship_toml: PathLike | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_starship(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms_binary=perms_binary,
            owner=owner,
            group=group,
            etc=etc,
            shell=shell,
            home=home,
            perms_config=perms_config,
            root=root,
            starship_toml=starship_toml,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'starship'", **CONTEXT_SETTINGS)(func)


##


def make_stylua_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_stylua(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'stylua'", **CONTEXT_SETTINGS)(func)


##


def make_taplo_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_taplo(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'taplo'", **CONTEXT_SETTINGS)(func)


##


def make_tmux_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_tmux(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'tmux'", **CONTEXT_SETTINGS)(func)


##


def make_uv_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @ssh_option
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @retry_option
    def func(
        *,
        ssh: SSH | None,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_uv(
            ssh=ssh,
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            retry=retry,
        )

    return cli(name=name, help="Set up 'uv'", **CONTEXT_SETTINGS)(func)


##


def make_watchexec_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_watchexec(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'watchexec'", **CONTEXT_SETTINGS)(func)


##


def make_yq_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_option
    @owner_option
    @group_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_yq(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'yq'", **CONTEXT_SETTINGS)(func)


##


def make_zoxide_cmd(
    *, cli: Callable[..., Command] = command, name: str | None = None
) -> Command:
    @token_option
    @path_binaries_option
    @sudo_option
    @perms_binary_option
    @owner_option
    @group_option
    @etc_option
    @shell_option
    @home_option
    @perms_config_option
    @root_option
    @ssh_option
    @force_option
    @retry_option
    def func(
        *,
        token: SecretLike | None,
        path_binaries: PathLike,
        sudo: bool,
        perms_binary: PermissionsLike,
        owner: Owner | None,
        group: Group | None,
        etc: bool,
        shell: Shell | None,
        home: PathLike | None,
        perms_config: PermissionsLike,
        root: PathLike | None,
        ssh: SSH | None,
        force: bool,
        retry: Retry | None,
    ) -> None:
        if is_pytest():
            return
        set_up_logging(__name__, root=True, log_version=__version__)
        set_up_zoxide(
            token=token,
            path_binaries=path_binaries,
            sudo=sudo,
            perms_binary=perms_binary,
            owner=owner,
            group=group,
            etc=etc,
            shell=shell,
            home=home,
            perms_config=perms_config,
            root=root,
            ssh=ssh,
            force=force,
            retry=retry,
        )

    return cli(name=name, help="Set up 'zoxide'", **CONTEXT_SETTINGS)(func)


__all__ = [
    "make_age_cmd",
    "make_apt_cmd",
    "make_bat_cmd",
    "make_bottom_cmd",
    "make_build_essential_cmd",
    "make_curl_cmd",
    "make_delta_cmd",
    "make_direnv_cmd",
    "make_docker_cmd",
    "make_dust_cmd",
    "make_eza_cmd",
    "make_fd_cmd",
    "make_fzf_cmd",
    "make_gh_cmd",
    "make_git_cmd",
    "make_jq_cmd",
    "make_just_cmd",
    "make_neovim_cmd",
    "make_pgbackrest_cmd",
    "make_postgres_cmd",
    "make_prek_cmd",
    "make_pve_cmd",
    "make_restic_cmd",
    "make_ripgrep_cmd",
    "make_rsync_cmd",
    "make_ruff_cmd",
    "make_sd_cmd",
    "make_shellcheck_cmd",
    "make_shfmt_cmd",
    "make_sops_cmd",
    "make_sqlite3_cmd",
    "make_starship_cmd",
    "make_stylua_cmd",
    "make_taplo_cmd",
    "make_uv_cmd",
    "make_watchexec_cmd",
    "make_yq_cmd",
    "make_zoxide_cmd",
]
