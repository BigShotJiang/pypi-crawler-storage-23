from __future__ import annotations

from click import Choice, Tuple
from utilities.click import Path, SecretStr, Str, flag, option
from utilities.shellingham import SHELL, Shell
from utilities.typing import get_literal_elements

from installer._constants import (
    GITHUB_TOKEN,
    PATH_BINARIES,
    PERMISSIONS_BINARY,
    PERMISSIONS_CONFIG,
)

etc_option = flag(
    "--etc",
    default=False,
    help="Set up in '/etc/profile.d/*.sh' instead of '~/.{bash,zsh}rc'",
)
force_option = flag(
    "--force",
    default=False,
    help="Force the installation even if the command already exists",
)
group_option = option("--group", type=Str(), default=None, help="Binary group")
home_option = option(
    "--home",
    type=Path(exist="dir if exists"),
    default=None,
    help="Path to the home directory",
)
owner_option = option("--owner", type=Str(), default=None, help="Binary owner")
path_binaries_option = option(
    "--path-binaries",
    type=Path(exist="dir if exists"),
    default=PATH_BINARIES,
    help="Path to the binaries",
)
permit_root_login_option = flag(
    "--permit-root-login", default=False, help="Permit root login"
)
perms_option, perms_binary_option = [
    option(p, type=Str(), default=PERMISSIONS_BINARY, help="Binary permissions")
    for p in ["--perms", "--perms-binary"]
]
perms_config_option = option(
    "--perms-config", type=Str(), default=PERMISSIONS_CONFIG, help="Config permissions"
)
root_option = option(
    "--root", type=Path(exist="dir if exists"), default=None, help="File system root"
)
shell_option = option(
    "--shell",
    type=Choice(get_literal_elements(Shell), case_sensitive=False),
    default=None,
    help=f"System shell. Defaults to {SHELL!r} for the current system",
)
ssh_option = option(
    "--ssh",
    type=Tuple([str, str]),
    default=None,
    metavar="<USER HOSTNAME>",
    help="SSH user & hostname",
)
sudo_option = flag("--sudo", default=False, help="Run as 'sudo'")
retry_option = option(
    "--retry",
    type=Tuple([int, int]),
    default=None,
    metavar="<ATTEMPTS DURATION>",
    help="SSH retry",
)
token_option = option(
    "--token", type=SecretStr(), default=GITHUB_TOKEN, help="GitHub token"
)


__all__ = [
    "etc_option",
    "force_option",
    "group_option",
    "home_option",
    "owner_option",
    "path_binaries_option",
    "permit_root_login_option",
    "perms_binary_option",
    "perms_config_option",
    "perms_option",
    "retry_option",
    "root_option",
    "shell_option",
    "ssh_option",
    "sudo_option",
    "token_option",
]
