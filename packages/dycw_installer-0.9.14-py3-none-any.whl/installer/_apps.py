from __future__ import annotations

import re
import shutil
from pathlib import Path
from shlex import join
from typing import TYPE_CHECKING, assert_never

import utilities.subprocess
from utilities.core import (
    extract_group,
    normalize_multi_line_str,
    normalize_str,
    one,
    to_logger,
)
from utilities.subprocess import (
    APT_UPDATE,
    BASH_LS,
    apt_install,
    apt_install_cmd,
    apt_remove,
    apt_update,
    chmod,
    cp,
    curl,
    curl_cmd,
    git_clone,
    install,
    maybe_sudo_cmd,
    rm,
    run,
    symlink,
    tee,
    yield_ssh_temp_dir,
)

from installer._constants import (
    GITHUB_TOKEN,
    PATH_BINARIES,
    PERMISSIONS_BINARY,
    PERMISSIONS_CONFIG,
    SHELL,
    SYSTEM_NAME,
)
from installer._download import (
    set_up_asset,
    yield_asset,
    yield_bz2_asset,
    yield_gzip_asset,
    yield_lzma_asset,
    yield_zip_asset,
)
from installer._utilities import (
    get_home,
    get_root,
    set_up_local_or_ssh,
    set_up_shell_config,
)

if TYPE_CHECKING:
    from utilities.core import PermissionsLike
    from utilities.shellingham import Shell
    from utilities.types import Group, Owner, PathLike, Retry, SecretLike

    from installer._types import SSH


_LOGGER = to_logger(__name__)


def set_up_apt_package(
    package: str,
    /,
    *,
    sudo: bool = False,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Setup an 'apt' package."""
    cmds: list[list[str]] = [
        maybe_sudo_cmd(*APT_UPDATE, sudo=sudo),
        maybe_sudo_cmd(*apt_install_cmd(package), sudo=sudo),
    ]

    def set_up_local() -> None:
        match SYSTEM_NAME:
            case "Darwin":
                msg = f"Unsupported system: {SYSTEM_NAME!r}"
                raise ValueError(msg)
            case "Linux":
                for cmds_i in cmds:
                    run(*cmds_i)
            case never:
                assert_never(never)

    set_up_local_or_ssh(
        package, set_up_local, "bash-ls", *cmds, ssh=ssh, force=force, retry=retry
    )


##


def set_up_age(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'age'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "FiloSottile",
            "age",
            token=token,
            match_system=True,
            match_machine=True,
            not_endswith=["proof"],
        ) as temp:
            srcs = {p for p in temp.iterdir() if p.name.startswith("age")}
            for src in srcs:
                dest = Path(path_binaries, src.name)
                cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "age",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_bat(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'bat'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "sharkdp",
            "bat",
            token=token,
            match_system=True,
            match_c_std_lib=True,
            match_machine=True,
        ) as temp:
            src = temp / "bat"
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "bat",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_bottom(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'bottom'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "ClementTsang",
            "bottom",
            token=token,
            match_system=True,
            match_c_std_lib=True,
            match_machine=True,
            not_matches=[r"\d+\.tar\.gz$"],
        ) as temp:
            src = temp / "btm"
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        ("btm", "bottom"),
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_build_essential(
    *,
    sudo: bool = False,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'build-essential'."""
    set_up_apt_package("build-essential", sudo=sudo, ssh=ssh, force=force, retry=retry)


##


def set_up_curl(
    *,
    sudo: bool = False,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'curl'."""
    set_up_apt_package("curl", sudo=sudo, ssh=ssh, force=force, retry=retry)


##


def set_up_delta(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'delta'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "dandavison",
            "delta",
            token=token,
            match_system=True,
            match_c_std_lib=True,
            match_machine=True,
        ) as temp:
            src = temp / "delta"
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "delta",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_direnv(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms_binary: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    etc: bool = False,
    shell: Shell | None = None,
    home: PathLike | None = None,
    perms_config: PermissionsLike = PERMISSIONS_CONFIG,
    root: PathLike | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'direnv'."""

    def set_up_local() -> None:
        dest = Path(path_binaries, "direnv")
        set_up_asset(
            "direnv",
            "direnv",
            dest,
            token=token,
            match_system=True,
            match_machine=True,
            sudo=sudo,
            perms=perms_binary,
            owner=owner,
            group=group,
        )
        set_up_shell_config(
            'eval "$(direnv hook bash)"',
            'eval "$(direnv hook fish)"',
            "direnv hook fish | source",
            etc="direnv" if etc else None,
            shell=SHELL if shell is None else shell,
            home=home,
            perms=perms_config,
            owner=owner,
            group=group,
            root=root,
        )

    set_up_local_or_ssh(
        "direnv",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms_binary=perms_binary,
        owner=owner,
        group=group,
        etc=etc,
        shell=shell,
        home=home,
        perms_config=perms_config,
        root=root,
        retry=retry,
    )


##


def set_up_docker(
    *,
    sudo: bool = False,
    user: str | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    def set_up_local() -> None:
        match SYSTEM_NAME:
            case "Darwin":
                msg = f"Unsupported system: {SYSTEM_NAME!r}"
                raise ValueError(msg)
            case "Linux":
                apt_remove(
                    "docker.io",
                    "docker-doc",
                    "docker-compose",
                    "podman-docker",
                    "containerd",
                    "runc",
                    sudo=sudo,
                )
                apt_update(sudo=sudo)
                apt_install("ca-certificates", "curl", sudo=sudo)
                docker_asc = Path("/etc/apt/keyrings/docker.asc")
                install(
                    docker_asc.parent, directory=True, mode="u=rwx,g=rx,o=rx", sudo=sudo
                )
                curl(
                    "https://download.docker.com/linux/debian/gpg",
                    output=docker_asc,
                    sudo=sudo,
                )
                chmod(docker_asc, "u=rw,g=r,o=r", sudo=sudo)
                release = Path("/etc/os-release").read_text()
                pattern = re.compile(r"^VERSION_CODENAME=(\w+)$")
                line = one(
                    line for line in release.splitlines() if pattern.search(line)
                )
                codename = extract_group(pattern, line)
                tee(
                    "/etc/apt/sources.list.d/docker.sources",
                    normalize_multi_line_str(f"""
                        Types: deb
                        URIs: https://download.docker.com/linux/debian
                        Suites: {codename}
                        Components: stable
                        Signed-By: /etc/apt/keyrings/docker.asc
                    """),
                    sudo=sudo,
                )
                apt_install(
                    "docker-ce",
                    "docker-ce-cli",
                    "containerd.io",
                    "docker-buildx-plugin",
                    "docker-compose-plugin",
                    update=True,
                    sudo=sudo,
                )
                if user is not None:
                    run(*maybe_sudo_cmd("usermod", "-aG", "docker", user, sudo=sudo))

    set_up_local_or_ssh(
        "docker",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        sudo=sudo,
        user=user,
        retry=retry,
    )


##


def set_up_dust(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'dust'."""

    def set_up_local() -> None:
        match SYSTEM_NAME:
            case "Darwin":
                match_machine = False
            case "Linux":
                match_machine = True
            case never:
                assert_never(never)
        with yield_gzip_asset(
            "bootandy",
            "dust",
            token=token,
            match_system=True,
            match_c_std_lib=True,
            match_machine=match_machine,
        ) as temp:
            src = temp / "dust"
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "dust",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_eza(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'eza'."""

    def set_up_local() -> None:
        match SYSTEM_NAME:
            case "Darwin":
                asset_owner = "cargo-bins"
                asset_repo = "cargo-quickinstall"
                tag = "eza"
                match_c_std_lib = False
                not_endswith = ["sig"]
            case "Linux":
                asset_owner = "eza-community"
                asset_repo = "eza"
                tag = None
                match_c_std_lib = True
                not_endswith = ["zip"]
            case never:
                assert_never(never)
        with yield_gzip_asset(
            asset_owner,
            asset_repo,
            tag=tag,
            token=token,
            match_system=True,
            match_c_std_lib=match_c_std_lib,
            match_machine=True,
            not_endswith=not_endswith,
        ) as src:
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "eza",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_fd(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'fd'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "sharkdp",
            "fd",
            token=token,
            match_system=True,
            match_c_std_lib=True,
            match_machine=True,
        ) as temp:
            src = temp / "fd"
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "fd",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_fzf(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms_binary: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    etc: bool = False,
    shell: Shell | None = None,
    home: PathLike | None = None,
    perms_config: PermissionsLike = PERMISSIONS_CONFIG,
    root: PathLike | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'fzf'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "junegunn", "fzf", token=token, match_system=True, match_machine=True
        ) as src:
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms_binary, owner=owner, group=group)
        set_up_shell_config(
            'eval "$(fzf --bash)"',
            "source <(fzf --zsh)",
            "fzf --fish | source",
            etc="fzf" if etc else None,
            shell=SHELL if shell is None else shell,
            home=home,
            perms=perms_config,
            owner=owner,
            group=group,
            root=root,
        )

    set_up_local_or_ssh(
        "fzf",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms_binary=perms_binary,
        owner=owner,
        group=group,
        etc=etc,
        shell=shell,
        home=home,
        perms_config=perms_config,
        root=root,
        retry=retry,
    )


##


def set_up_gh(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'gh'."""

    def set_up_local() -> None:
        match SYSTEM_NAME:
            case "Darwin":
                with yield_zip_asset(
                    "cli",
                    "cli",
                    token=token,
                    match_system=True,
                    match_machine=True,
                    not_matches=["RPM"],
                ) as temp:
                    src = temp / "bin/gh"
                    dest = Path(path_binaries, "gh")
                    cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)
            case "Linux":
                with yield_gzip_asset(
                    "cli",
                    "cli",
                    token=token,
                    match_system=True,
                    match_machine=True,
                    not_matches=["deb", "rpm"],
                ) as temp:
                    src = temp / "bin/gh"
                    dest = Path(path_binaries, "gh")
                    cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)
            case never:
                assert_never(never)

    set_up_local_or_ssh(
        "gh",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_git(
    *,
    sudo: bool = False,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'git'."""
    set_up_apt_package("git", sudo=sudo, ssh=ssh, force=force, retry=retry)


##


def set_up_jq(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'jq'."""

    def set_up_local() -> None:
        dest = Path(path_binaries, "jq")
        set_up_asset(
            "jqlang",
            "jq",
            dest,
            token=token,
            match_system=True,
            match_machine=True,
            not_endswith=["linux64"],
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
        )

    set_up_local_or_ssh(
        "jq",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_just(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'just'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "casey", "just", token=token, match_system=True, match_machine=True
        ) as temp:
            src = temp / "just"
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "just",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_neovim(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    repo: str | None = None,
    home: PathLike | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'neovim'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "neovim",
            "neovim",
            token=token,
            match_system=True,
            match_machine=True,
            not_endswith=["appimage", "zsync"],
        ) as temp:
            dest_dir = Path(path_binaries, "nvim-dir")
            cp(temp, dest_dir, sudo=sudo, perms=perms, owner=owner, group=group)
            dest_bin = Path(path_binaries, "nvim")
            symlink(dest_dir / "bin/nvim", dest_bin, sudo=sudo)
        if repo is not None:
            dest = get_home(home=home) / ".config/nvim"
            rm(dest, sudo=sudo)
            git_clone(repo, path=dest, sudo=sudo)
            run("nvim", "--headless", '"+Lazy! sync"', "+qa")

    set_up_local_or_ssh(
        ("nvim", "neovim"),
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        repo=repo,
        home=home,
        retry=retry,
    )


##


def set_up_pgbackrest(
    *,
    sudo: bool = False,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'pgbackrest'."""
    set_up_apt_package("pgbackrest", sudo=sudo, ssh=ssh, force=force, retry=retry)


##


def set_up_postgres(
    *,
    sudo: bool = False,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'postgres'."""
    set_up_apt_package("postgresql", sudo=sudo, ssh=ssh, force=force, retry=retry)


##


def set_up_prek(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'prek'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "j178",
            "prek",
            token=token,
            match_system=True,
            match_c_std_lib=True,
            match_machine=True,
            not_endswith=["sha256"],
        ) as temp:
            src = temp / "prek"
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "prek",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_pve(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'pve-fake-subscription'."""

    def set_up_local() -> None:
        match SYSTEM_NAME:
            case "Darwin":
                msg = f"Unsupported system: {SYSTEM_NAME!r}"
                raise ValueError(msg)
            case "Linux":
                with yield_asset(
                    "Jamesits", "pve-fake-subscription", token=token, endswith="deb"
                ) as temp:
                    run("dpkg", "-i", str(temp))
            case never:
                assert_never(never)

    set_up_local_or_ssh(
        "pve-fake-subscription",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        retry=retry,
    )


##


def set_up_restic(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'restic'."""

    def set_up_local() -> None:
        with yield_bz2_asset(
            "restic", "restic", token=token, match_system=True, match_machine=True
        ) as src:
            dest = Path(path_binaries, "restic")
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "restic",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_ripgrep(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'ripgrep'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "burntsushi",
            "ripgrep",
            token=token,
            match_system=True,
            match_machine=True,
            not_endswith=["sha256"],
        ) as temp:
            src = temp / "rg"
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        ("rg", "ripgrep"),
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_rsync(
    *,
    sudo: bool = False,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'rsync'."""
    set_up_apt_package("rsync", sudo=sudo, ssh=ssh, force=force, retry=retry)


##


def set_up_ruff(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'ruff'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "astral-sh",
            "ruff",
            token=token,
            match_system=True,
            match_c_std_lib=True,
            match_machine=True,
            not_endswith=["sha256"],
        ) as temp:
            src = temp / "ruff"
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "ruff",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_sd(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'sd'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "chmln",
            "sd",
            token=token,
            match_system=True,
            match_c_std_lib=True,
            match_machine=True,
        ) as temp:
            src = temp / "sd"
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "sd",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_shellcheck(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'shellcheck'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "koalaman",
            "shellcheck",
            token=token,
            match_system=True,
            match_machine=True,
            not_endswith=["tar.xz"],
        ) as temp:
            src = temp / "shellcheck"
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "shellcheck",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_shfmt(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'shfmt'."""

    def set_up_local() -> None:
        dest = Path(path_binaries, "shfmt")
        set_up_asset(
            "mvdan",
            "sh",
            dest,
            token=token,
            match_system=True,
            match_machine=True,
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
        )

    set_up_local_or_ssh(
        "sh",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_sops(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'sops'."""

    def set_up_local() -> None:
        dest = Path(path_binaries, "sops")
        set_up_asset(
            "getsops",
            "sops",
            dest,
            token=token,
            match_system=True,
            match_machine=True,
            not_endswith=["json"],
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
        )

    set_up_local_or_ssh(
        "sops",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_sqlite3(
    *,
    sudo: bool = False,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'sqlite3'."""
    set_up_apt_package("sqlite3", sudo=sudo, ssh=ssh, force=force, retry=retry)


##


def set_up_starship(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms_binary: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    etc: bool = False,
    shell: Shell | None = None,
    home: PathLike | None = None,
    perms_config: PermissionsLike = PERMISSIONS_CONFIG,
    root: PathLike | None = None,
    starship_toml: PathLike | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'starship'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "starship",
            "starship",
            token=token,
            match_system=True,
            match_c_std_lib=True,
            match_machine=True,
            not_endswith=["sha256"],
        ) as src:
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms_binary, owner=owner, group=group)
        export = ["export STARSHIP_CONFIG='/etc/starship.toml'"] if etc else []
        set_up_shell_config(
            [*export, 'eval "$(starship init bash)"'],
            [*export, 'eval "$(starship init zsh)"'],
            [*export, "starship init fish | source"],
            etc="starship" if etc else None,
            shell=SHELL if shell is None else shell,
            home=home,
            perms=perms_config,
            owner=owner,
            group=group,
            root=root,
        )
        if starship_toml is not None:
            if etc:
                dest = get_root(root=root) / "etc/starship.toml"
            else:
                dest = get_home(home=home) / ".config/starship.toml"
            cp(
                starship_toml,
                dest,
                sudo=sudo,
                perms=perms_config,
                owner=owner,
                group=group,
            )

    set_up_local_or_ssh(
        "starship",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms_binary=perms_binary,
        owner=owner,
        group=group,
        etc=etc,
        shell=shell,
        home=home,
        perms_config=perms_config,
        root=root,
        starship_toml=starship_toml,
        retry=retry,
    )


##


def set_up_stylua(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'stylua'."""

    def set_up_local() -> None:
        with yield_zip_asset(
            "JohnnyMorganz",
            "stylua",
            token=token,
            match_system=True,
            match_machine=True,
            not_matches="musl",
        ) as src:
            dest = Path(path_binaries, "stylua")
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "stylua",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_taplo(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'taplo'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "tamasfe", "taplo", token=token, match_system=True, match_machine=True
        ) as src:
            dest = Path(path_binaries, "taplo")
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "taplo",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_tmux(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'tmux'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "tmux", "tmux-builds", token=token, match_system=True, match_machine=True
        ) as src:
            dest = Path(path_binaries, "tmux")
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "tmux",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_uv(
    *,
    ssh: SSH | None = None,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'uv'."""
    _LOGGER.info("Setting up 'uv'...")
    match ssh, shutil.which("uv"), force:
        case (None, None, _) | (None, str(), True):
            _LOGGER.info("Setting up 'uv'...")
            with yield_gzip_asset(
                "astral-sh",
                "uv",
                token=token,
                match_system=True,
                match_c_std_lib=True,
                match_machine=True,
                not_endswith=["sha256"],
            ) as temp:
                src = temp / "uv"
                dest = Path(path_binaries, src.name)
                cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)
        case None, str(), False:
            _LOGGER.info("Setting up 'uv'...")
        case (ssh_user, ssh_hostname), _, _:
            _LOGGER.info("Setting up 'uv' on %r...", ssh_hostname)
            with yield_ssh_temp_dir(
                ssh_user, ssh_hostname, retry=retry, logger=_LOGGER
            ) as temp:
                utilities.subprocess.ssh(
                    ssh_user,
                    ssh_hostname,
                    *BASH_LS,
                    input=set_up_uv_cmd(temp, path_binaries=path_binaries, sudo=sudo),
                    retry=retry,
                    logger=_LOGGER,
                )
        case never:
            assert_never(never)


def set_up_uv_cmd(
    temp_dir: PathLike,
    /,
    *,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
) -> str:
    """Command to setup 'uv'."""
    output = Path(temp_dir, "install.sh")
    cmds: list[list[str]] = [
        curl_cmd("https://astral.sh/uv/install.sh", output=output),
        maybe_sudo_cmd(
            "env",
            f"UV_INSTALL_DIR={path_binaries}",
            "UV_NO_MODIFY_PATH=1",
            "sh",
            str(output),
            sudo=sudo,
        ),
    ]
    return normalize_str("\n".join(map(join, cmds)))


##


def set_up_watchexec(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'watchexec'."""

    def set_up_local() -> None:
        with yield_lzma_asset(
            "watchexec",
            "watchexec",
            token=token,
            match_system=True,
            match_c_std_lib=True,
            match_machine=True,
            not_endswith=["b3", "deb", "rpm", "sha256", "sha512"],
        ) as temp:
            src = temp / "watchexec"
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms, owner=owner, group=group)

    set_up_local_or_ssh(
        "watchexec",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_yq(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'yq'."""

    def set_up_local() -> None:
        dest = Path(path_binaries, "yq")
        set_up_asset(
            "mikefarah",
            "yq",
            dest,
            token=token,
            match_system=True,
            match_machine=True,
            not_endswith=["tar.gz"],
            sudo=sudo,
            perms=perms,
            owner=owner,
            group=group,
        )

    set_up_local_or_ssh(
        "yq",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms=perms,
        owner=owner,
        group=group,
        retry=retry,
    )


##


def set_up_zoxide(
    *,
    token: SecretLike | None = GITHUB_TOKEN,
    path_binaries: PathLike = PATH_BINARIES,
    sudo: bool = False,
    perms_binary: PermissionsLike = PERMISSIONS_BINARY,
    owner: Owner | None = None,
    group: Group | None = None,
    etc: bool = False,
    shell: Shell | None = None,
    home: PathLike | None = None,
    perms_config: PermissionsLike = PERMISSIONS_CONFIG,
    root: PathLike | None = None,
    ssh: SSH | None = None,
    force: bool = False,
    retry: Retry | None = None,
) -> None:
    """Set up 'zoxide'."""

    def set_up_local() -> None:
        with yield_gzip_asset(
            "ajeetdsouza",
            "zoxide",
            token=token,
            match_system=True,
            match_machine=True,
            not_matches="android",
        ) as temp:
            src = temp / "zoxide"
            dest = Path(path_binaries, src.name)
            cp(src, dest, sudo=sudo, perms=perms_binary, owner=owner, group=group)
        set_up_shell_config(
            'eval "$(zoxide init --cmd j bash)"',
            'eval "$(zoxide init --cmd j zsh)"',
            "zoxide init --cmd j fish | source",
            etc="zoxide" if etc else None,
            shell=SHELL if shell is None else shell,
            home=home,
            perms=perms_config,
            owner=owner,
            group=group,
            root=root,
        )

    set_up_local_or_ssh(
        "zoxide",
        set_up_local,
        "uv-tool",
        ssh=ssh,
        force=force,
        token=token,
        path_binaries=path_binaries,
        sudo=sudo,
        perms_binary=perms_binary,
        owner=owner,
        group=group,
        etc=etc,
        shell=shell,
        home=home,
        perms_config=perms_config,
        root=root,
        retry=retry,
    )


##


__all__ = [
    "set_up_age",
    "set_up_apt_package",
    "set_up_bat",
    "set_up_bottom",
    "set_up_build_essential",
    "set_up_curl",
    "set_up_delta",
    "set_up_direnv",
    "set_up_docker",
    "set_up_dust",
    "set_up_eza",
    "set_up_fd",
    "set_up_fzf",
    "set_up_gh",
    "set_up_git",
    "set_up_jq",
    "set_up_just",
    "set_up_neovim",
    "set_up_pgbackrest",
    "set_up_postgres",
    "set_up_prek",
    "set_up_pve",
    "set_up_restic",
    "set_up_ripgrep",
    "set_up_rsync",
    "set_up_ruff",
    "set_up_sd",
    "set_up_shellcheck",
    "set_up_shfmt",
    "set_up_sops",
    "set_up_sqlite3",
    "set_up_starship",
    "set_up_stylua",
    "set_up_taplo",
    "set_up_tmux",
    "set_up_uv",
    "set_up_uv_cmd",
    "set_up_yq",
    "set_up_zoxide",
]
