"""
Filter utilities for templates.

This module is intentionally minimal - filters should be registered
on TemplateEnvironment or individual PromptTemplate instances, not globally.
"""
