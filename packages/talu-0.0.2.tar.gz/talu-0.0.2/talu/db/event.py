"""
Event types for TaluDB storage operations.

Event types are defined in ``talu.types.events``.
"""
