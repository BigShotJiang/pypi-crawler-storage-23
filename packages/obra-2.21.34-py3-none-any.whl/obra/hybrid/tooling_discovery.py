"""LLM-powered tooling discovery for language-agnostic verification."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, ClassVar

logger = logging.getLogger(__name__)


@dataclass
class ToolingDiscovery:
    """Discover project languages and verification tooling.

    This uses lightweight manifest detection plus an LLM to infer
    test/lint commands and test file patterns. Results are cached
    in .obra/project_tooling.json for reuse.
    """

    working_dir: Path
    llm_config: dict[str, Any] = field(default_factory=dict)

    # Class variable: mapping of manifest filenames to their language
    MANIFEST_FILES: ClassVar[dict[str, str]] = {
        "package.json": "javascript",
        "go.mod": "go",
        "Cargo.toml": "rust",
        "pyproject.toml": "python",
        "requirements.txt": "python",
        "pom.xml": "java",
        "build.gradle": "java",
        "Gemfile": "ruby",
        "composer.json": "php",
    }
    CACHE_FILENAME: str = ".obra/project_tooling.json"

    # DEPRECATED: Use get_tooling_discovery_config() from obra.config.loaders
    # This is initialized from config in __post_init__
    MAX_MANIFEST_BYTES: int = 2048

    def __post_init__(self) -> None:
        # Load MAX_MANIFEST_BYTES from config (CHORE-CONFIG-DEFAULTS-001-E3 S2.T5)
        from obra.config.loaders import get_tooling_discovery_config

        tooling_config = get_tooling_discovery_config()
        self.MAX_MANIFEST_BYTES = tooling_config["max_manifest_bytes"]
        self.working_dir = Path(self.working_dir)

    def detect_manifests(self) -> dict[str, list[str]]:
        """Detect known manifest files and map to languages."""
        manifests: dict[str, list[str]] = {}
        for filename, language in self.MANIFEST_FILES.items():
            found_paths: list[str] = []
            root_path = self.working_dir / filename
            if root_path.exists():
                found_paths.append(str(root_path.relative_to(self.working_dir)))
            else:
                for path in self.working_dir.rglob(filename):
                    if path.is_file():
                        try:
                            found_paths.append(str(path.relative_to(self.working_dir)))
                        except ValueError:
                            found_paths.append(str(path))
                        break
            if found_paths:
                manifests.setdefault(language, []).extend(found_paths)
        return manifests

    def discover(self, force_refresh: bool = False) -> dict[str, Any]:
        """Discover tooling configuration, using cache when available."""
        if not force_refresh:
            cached = self._load_cache()
            if cached:
                return cached

        if not self.llm_config:
            logger.warning("Tooling discovery skipped: no llm_config provided")
            return {}

        manifests = self.detect_manifests()
        manifest_contents = self._read_manifest_contents(manifests)

        prompt = self._build_prompt(manifests, manifest_contents)
        response_text = self._run_discovery_llm(prompt)
        if not response_text:
            return {}

        parsed = self._parse_llm_response(response_text)
        if not parsed:
            return {}

        data = self._normalize_discovery(parsed)

        # FIX-HYBRID-040: Validate LLM discovery result has usable content.
        # If the LLM returned garbage (unknown language, no commands), cascade
        # to heuristic discovery instead of caching unusable results.
        if not self._is_discovery_adequate(data):
            logger.warning(
                "LLM tooling discovery returned inadequate results "
                "(primary=%s, commands=%d), falling back to heuristic",
                data.get("languages", {}).get("primary", "unknown"),
                self._count_verification_commands(data),
            )
            return self.discover_fast()

        self._save_cache(data)
        return data

    def discover_fast(self) -> dict[str, Any]:
        """Fast heuristic-based discovery without LLM.

        Uses manifest file analysis and common patterns to infer tooling.
        Much faster than full LLM discovery but may miss edge cases.
        Results are cached with source='heuristic'.

        Returns:
            Discovery dict with languages and verification tools.
        """
        manifests = self.detect_manifests()
        # Read full manifest contents for heuristics (no byte limit)
        manifest_contents = self._read_manifest_contents_full(manifests)

        # Determine primary language from manifests
        primary_lang = ""
        secondary_langs: list[str] = []
        lang_priority = ["python", "javascript", "go", "rust", "java", "ruby", "php"]

        # Proper capitalization for display
        lang_display = {
            "python": "Python",
            "javascript": "JavaScript",
            "go": "Go",
            "rust": "Rust",
            "java": "Java",
            "ruby": "Ruby",
            "php": "PHP",
        }

        for lang in lang_priority:
            if lang in manifests:
                display_name = lang_display.get(lang, lang.capitalize())
                if not primary_lang:
                    primary_lang = display_name
                else:
                    secondary_langs.append(display_name)

        # Infer verification tools from manifest contents
        verification: dict[str, dict[str, Any]] = {}

        # Helper to get all content matching a manifest filename
        def get_manifest_content(filename: str) -> str:
            return "\n".join(
                content for path, content in manifest_contents.items() if path.endswith(filename)
            )

        # Python heuristics
        if "python" in manifests:
            pyproject = get_manifest_content("pyproject.toml")
            requirements = get_manifest_content("requirements.txt")
            combined = pyproject + requirements

            # Test tool
            if "pytest" in combined:
                verification["test"] = {
                    "command": "pytest",
                    "patterns": ["test_*.py", "*_test.py"],
                }
            elif "unittest" in combined or "python" in manifests:
                verification["test"] = {
                    "command": "python -m unittest discover",
                    "patterns": ["test_*.py"],
                }

            # Lint tool
            if "ruff" in combined:
                verification["lint"] = {"command": "ruff check ."}
            elif "flake8" in combined:
                verification["lint"] = {"command": "flake8 ."}
            elif "ruff" in combined:
                verification["lint"] = {"command": "ruff check ."}
            elif "pylint" in combined:
                verification["lint"] = {"command": "ruff check ."}

            # Type checking
            if "mypy" in combined:
                verification["typecheck"] = {"command": "mypy ."}
            elif "pyright" in combined:
                verification["typecheck"] = {"command": "pyright ."}

            # Formatting
            if "black" in combined:
                verification["format"] = {"command": "black ."}
            elif "ruff" in combined:
                # ruff includes formatting capability
                verification["format"] = {"command": "ruff format ."}

        # JavaScript/TypeScript heuristics
        if "javascript" in manifests:
            pkg_json = get_manifest_content("package.json")

            # Check for scripts in package.json
            if '"test"' in pkg_json:
                if "jest" in pkg_json:
                    verification["test"] = {
                        "command": "npm test",
                        "patterns": ["*.test.js", "*.spec.js"],
                    }
                elif "vitest" in pkg_json:
                    verification["test"] = {
                        "command": "npm test",
                        "patterns": ["*.test.ts", "*.spec.ts"],
                    }
                elif "mocha" in pkg_json:
                    verification["test"] = {
                        "command": "npm test",
                        "patterns": ["test/**/*.js"],
                    }
                else:
                    verification["test"] = {"command": "npm test"}

            if '"lint"' in pkg_json:
                verification["lint"] = {"command": "npm run lint"}
            elif "eslint" in pkg_json:
                verification["lint"] = {"command": "npx eslint ."}

            if "typescript" in pkg_json:
                verification["typecheck"] = {"command": "npx tsc --noEmit"}

            if '"format"' in pkg_json:
                verification["format"] = {"command": "npm run format"}
            elif "prettier" in pkg_json:
                verification["format"] = {"command": "npx prettier --write ."}

        # Go heuristics
        if "go" in manifests:
            verification["test"] = {
                "command": "go test ./...",
                "patterns": ["*_test.go"],
            }
            verification["lint"] = {"command": "golangci-lint run"}
            verification["format"] = {"command": "gofmt -w ."}

        # Rust heuristics
        if "rust" in manifests:
            verification["test"] = {
                "command": "cargo test",
                "patterns": ["tests/**/*.rs"],
            }
            verification["lint"] = {"command": "cargo clippy"}
            verification["format"] = {"command": "cargo fmt"}

        normalized_verification = self._normalize_verification(
            verification,
            default_source="heuristic",
        )

        data = {
            "languages": {
                "primary": primary_lang or "Unknown",
                "secondary": secondary_langs,
            },
            "verification": normalized_verification,
            "excluded_dirs": [
                "node_modules",
                "__pycache__",
                ".git",
                "target",
                "dist",
                "build",
            ],
            "_meta": {
                "discovered_at": datetime.now(UTC).isoformat(),
                "source": "heuristic",
            },
        }

        self._save_cache(data)
        return data

    def load_cache(self) -> dict[str, Any] | None:
        """Load cached tooling discovery results without triggering discovery.

        External callers (e.g., Config Explorer) can use this to read cached
        results without invoking an LLM call.

        Returns:
            Cached discovery dict if exists, None otherwise.
        """
        return self._load_cache()

    def _read_manifest_contents(self, manifests: dict[str, list[str]]) -> dict[str, str]:
        """Read manifest contents with byte limit (for LLM prompts)."""
        contents: dict[str, str] = {}
        for paths in manifests.values():
            for rel_path in paths:
                path = self.working_dir / rel_path
                if not path.exists():
                    continue
                try:
                    raw = path.read_bytes()
                    snippet = raw[: self.MAX_MANIFEST_BYTES].decode("utf-8", errors="ignore")
                    contents[rel_path] = snippet
                except OSError:
                    continue
        return contents

    def _read_manifest_contents_full(self, manifests: dict[str, list[str]]) -> dict[str, str]:
        """Read full manifest contents (for heuristic analysis)."""
        contents: dict[str, str] = {}
        for paths in manifests.values():
            for rel_path in paths:
                path = self.working_dir / rel_path
                if not path.exists():
                    continue
                try:
                    # Read full file for heuristics (capped at 100KB for safety)
                    raw = path.read_bytes()[:102400]
                    contents[rel_path] = raw.decode("utf-8", errors="ignore")
                except OSError:
                    continue
        return contents

    def _build_prompt(self, manifests: dict[str, list[str]], contents: dict[str, str]) -> str:
        manifest_lines = []
        for language, paths in manifests.items():
            for rel_path in paths:
                snippet = contents.get(rel_path, "")
                manifest_lines.append(f"- {rel_path} ({language}):\n{snippet}\n")
        manifest_block = "\n".join(manifest_lines) if manifest_lines else "None"
        return (
            "You are an expert build tool detective. Analyze project manifests and "
            "determine the primary language(s) and verification tooling.\n\n"
            "Return ONLY valid JSON with this schema:\n"
            "{\n"
            '  "languages": {"primary": "<language>", "secondary": ["..."]},\n'
            '  "verification": {\n'
            '    "test": {"command": "<cmd>", "patterns": ["..."], "directory": "<dir or empty>", "install": ["<cmd>"]},\n'
            '    "lint": {"command": "<cmd>", "patterns": ["..."], "install": ["<cmd>"]},\n'
            '    "typecheck": {"command": "<cmd>", "install": ["<cmd>"]},\n'
            '    "format": {"command": "<cmd>", "install": ["<cmd>"]}\n'
            "  },\n"
            '  "excluded_dirs": ["..."]\n'
            "}\n\n"
            "Guidelines:\n"
            "- Prefer project scripts (npm/yarn/pnpm) when present\n"
            "- Use standard tool commands when manifests indicate tooling\n"
            "- Provide install commands as package-manager invocations (pip/poetry/uv, npm/yarn/pnpm/bun, cargo, go, gem, composer, mvn/gradle)\n"
            "- Avoid curl/wget/sudo or piping to shells in install commands\n"
            "- Provide test file patterns and common test directories\n"
            "- Provide excluded dirs for build artifacts and dependencies\n\n"
            f"Manifests:\n{manifest_block}\n"
        )

    def _run_discovery_llm(self, prompt: str) -> str:
        try:
            from obra.config.llm import DEFAULT_REASONING_LEVEL
            from obra.config.loaders import get_tooling_discovery_timeout
            from obra.llm import LLMSubprocessConfig, run_llm_subprocess

            provider = self.llm_config.get("provider", "anthropic")
            model = self.llm_config.get("model", "default")
            reasoning_level = self.llm_config.get("reasoning_level", DEFAULT_REASONING_LEVEL)
            auth_method = self.llm_config.get("auth_method", "oauth")

            config = LLMSubprocessConfig(
                prompt=prompt,
                cwd=self.working_dir,
                provider=provider,
                model=model,
                reasoning_level=reasoning_level,
                auth_method=auth_method,
                timeout_s=get_tooling_discovery_timeout(),
                skip_git_check=True,
                streaming=False,
                call_site="tooling_discovery",
                response_format="json",
            )
            result = run_llm_subprocess(config)
            if not result.success:
                logger.warning("Tooling discovery failed: %s", result.error)
                return ""
            return result.output.strip()
        except Exception as exc:
            logger.warning("Tooling discovery LLM error: %s", exc)
            return ""

    def _parse_llm_response(self, response_text: str) -> dict[str, Any] | None:
        response_text = response_text.strip()
        if not response_text:
            return None
        try:
            data = json.loads(response_text)
        except json.JSONDecodeError:
            return None

        try:
            from obra.hybrid.json_utils import (
                unwrap_claude_cli_json,
                unwrap_gemini_cli_json,
            )

            provider = self.llm_config.get("provider", "")
            if provider == "anthropic":
                unwrapped, was_wrapped = unwrap_claude_cli_json(data)
            elif provider == "google":
                unwrapped, was_wrapped = unwrap_gemini_cli_json(data)
            else:
                unwrapped, was_wrapped = data, False
            if was_wrapped:
                if isinstance(unwrapped, str):
                    unwrapped = unwrapped.strip()
                    if not unwrapped:
                        return None
                    data = json.loads(unwrapped)
                elif isinstance(unwrapped, dict):
                    data = unwrapped
        except Exception:
            pass

        if not isinstance(data, dict):
            return None
        return data

    def _normalize_discovery(self, data: dict[str, Any]) -> dict[str, Any]:
        now = datetime.now(UTC).isoformat()
        verification = self._normalize_verification(
            data.get("verification", {}),
            default_source="llm",
        )
        normalized: dict[str, Any] = {
            "_meta": {
                "discovered_at": now,
                "discovery_method": "llm",
            },
            "languages": data.get("languages", {}),
            "verification": verification,
            "excluded_dirs": data.get("excluded_dirs", []),
        }
        return normalized

    @staticmethod
    def _coerce_install_list(value: Any) -> list[str]:
        if isinstance(value, str):
            value = [value]
        if not isinstance(value, list):
            return []
        commands: list[str] = []
        for entry in value:
            if isinstance(entry, str):
                cleaned = entry.strip()
                if cleaned:
                    commands.append(cleaned)
        return commands

    @staticmethod
    def _coerce_string_list(value: Any) -> list[str]:
        if isinstance(value, str):
            value = [value]
        if not isinstance(value, list):
            return []
        cleaned: list[str] = []
        for entry in value:
            if isinstance(entry, str):
                text = entry.strip()
                if text:
                    cleaned.append(text)
        return cleaned

    @staticmethod
    def _infer_scope_type(command: str) -> str:
        normalized = " ".join(command.strip().split())
        if not normalized:
            return "unscoped"
        if "{files}" in normalized or "{paths}" in normalized:
            return "scoped"

        repo_wide_tokens = {
            ".",
            "./",
            "./...",
            "...",
            "--all",
            "--all-files",
            "--all-targets",
        }
        parts = normalized.split()
        if any(token in repo_wide_tokens for token in parts):
            return "unscoped"

        # Default to unscoped unless command explicitly supports path injection.
        return "unscoped"

    def _normalize_verification(
        self,
        verification: Any,
        *,
        default_source: str,
    ) -> dict[str, Any]:
        if not isinstance(verification, dict):
            return {}
        normalized: dict[str, Any] = {}
        for category in ["test", "lint", "typecheck", "format"]:
            entry = verification.get(category, {})
            if not isinstance(entry, dict):
                entry = {}
            normalized_entry = dict(entry)
            command = str(entry.get("command", "") or "").strip()
            patterns = self._coerce_string_list(entry.get("patterns", []))
            target_files = self._coerce_string_list(
                entry.get("target_files", entry.get("targets", patterns))
            )
            scope_type = str(entry.get("scope_type", "") or "").strip().lower()
            if scope_type not in {"scoped", "unscoped"}:
                scope_type = self._infer_scope_type(command)
            discovery_source = str(entry.get("discovery_source") or default_source).strip()
            if not discovery_source:
                discovery_source = default_source

            normalized_entry["command"] = command
            normalized_entry["patterns"] = patterns
            normalized_entry["target_files"] = target_files
            normalized_entry["scope_type"] = scope_type
            normalized_entry["discovery_source"] = discovery_source
            normalized_entry["install"] = self._coerce_install_list(entry.get("install", []))
            normalized[category] = normalized_entry
        return normalized

    @staticmethod
    def _count_verification_commands(data: dict[str, Any]) -> int:
        """Count how many verification categories have non-empty commands."""
        verification = data.get("verification", {})
        count = 0
        for category in ("test", "lint", "typecheck", "format"):
            entry = verification.get(category, {})
            if isinstance(entry, dict) and str(entry.get("command", "")).strip():
                count += 1
        return count

    def _is_discovery_adequate(self, data: dict[str, Any]) -> bool:
        """Check if discovery result has usable verification commands.

        Returns False if primary language is unknown/empty or if no
        verification category has a non-empty command string.
        """
        languages = data.get("languages", {})
        primary = str(languages.get("primary", "")).strip().lower()
        if primary in ("", "unknown"):
            return False
        return self._count_verification_commands(data) > 0

    def _load_cache(self) -> dict[str, Any] | None:
        cache_path = self.working_dir / self.CACHE_FILENAME
        if cache_path.exists():
            try:
                raw = cache_path.read_text(encoding="utf-8")
                raw = raw.strip()
                if not raw:
                    return None
                data = json.loads(raw)
                if not isinstance(data, dict):
                    return None
                # FIX-HYBRID-047: Validate cached results on load
                if not self._is_discovery_adequate(data):
                    logger.warning(
                        "Stale tooling cache has inadequate results "
                        "(primary=%s), deleting",
                        data.get("languages", {}).get("primary", "unknown"),
                    )
                    try:
                        cache_path.unlink()
                    except OSError:
                        pass
                    return None
                return data
            except Exception as exc:
                logger.warning("Failed to read tooling discovery cache: %s", exc)
                return None

        return None

    def _save_cache(self, data: dict[str, Any]) -> None:
        cache_path = self.working_dir / self.CACHE_FILENAME
        try:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            payload = json.dumps(data, indent=2, sort_keys=False)
            cache_path.write_text(payload + "\n", encoding="utf-8")
        except Exception as exc:
            logger.warning("Failed to write tooling discovery cache: %s", exc)
