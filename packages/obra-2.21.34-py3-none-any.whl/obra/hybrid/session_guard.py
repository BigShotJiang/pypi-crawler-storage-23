"""Session guard for preventing zombie Obra sessions.

FEAT-SESSION-GUARD-001: Provides runtime limits, user prompts, and
heartbeat tracking for long-running orchestration sessions.
"""

import json
import logging
import os
import sys
import threading
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

logger = logging.getLogger(__name__)

# Default locations
OBRA_RUN_DIR = Path.home() / ".obra" / "run"


@dataclass
class SessionHeartbeat:
    """Heartbeat data for a running session."""

    pid: int
    session_id: str
    short_id: str
    started: str  # ISO format
    last_heartbeat: str  # ISO format
    runtime_seconds: float
    iteration: int
    items_completed: int
    items_total: int
    current_phase: str
    working_dir: str
    warning_count: int = 0  # How many times user was warned

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "SessionHeartbeat":
        return cls(**data)


class SessionGuard:
    """Guard against zombie sessions with runtime limits and user prompts.

    Features:
    - Heartbeat file tracking session state
    - Warning prompt at configurable threshold (default 24h)
    - Hard limit termination (default 48h)
    - User input resets warning timer

    Usage:
        guard = SessionGuard(session_id, working_dir)
        guard.start()

        # In orchestration loop:
        guard.update(iteration=i, items_completed=n, phase="execution")

        # Check for timeout (prompts user if needed)
        if guard.check_timeout():
            # Session should terminate
            break

        guard.stop()
    """

    def __init__(
        self,
        session_id: str,
        working_dir: str | Path,
        warning_hours: float | None = None,
        max_hours: float | None = None,
        items_total: int = 0,
        on_warning: Callable[[float, int], bool] | None = None,
        run_dir: Path | None = None,
    ) -> None:
        """Initialize session guard.

        Args:
            session_id: Full session ID
            working_dir: Session working directory
            warning_hours: Hours before warning prompt (None = use config)
            max_hours: Hard limit hours (None = use config)
            items_total: Total items in session (for progress tracking)
            on_warning: Custom warning handler. Returns True to continue, False to stop.
                       If None, uses default TTY prompt.
            run_dir: Directory for heartbeat files (default: ~/.obra/run/)
        """
        from obra.config.loaders import get_session_max_hours, get_session_warning_hours

        self.session_id = session_id
        self.short_id = session_id.split("-")[0] if session_id else "unknown"
        self.working_dir = str(working_dir)
        self.warning_hours = warning_hours or get_session_warning_hours()
        self.max_hours = max_hours or get_session_max_hours()
        self.items_total = items_total
        self.on_warning = on_warning
        self.run_dir = run_dir or OBRA_RUN_DIR

        self._heartbeat_file = self.run_dir / f"session-{self.short_id}.json"
        self._started: datetime | None = None
        self._last_warning: datetime | None = None
        self._warning_count = 0
        self._iteration = 0
        self._items_completed = 0
        self._current_phase = "initializing"
        self._stop_event = threading.Event()
        self._heartbeat_thread: threading.Thread | None = None
        self._lock = threading.Lock()

    @property
    def heartbeat_file(self) -> Path:
        """Path to the heartbeat file."""
        return self._heartbeat_file

    @property
    def runtime_hours(self) -> float:
        """Current runtime in hours."""
        if not self._started:
            return 0.0
        elapsed = datetime.now(timezone.utc) - self._started
        return elapsed.total_seconds() / 3600

    @property
    def runtime_seconds(self) -> float:
        """Current runtime in seconds."""
        if not self._started:
            return 0.0
        elapsed = datetime.now(timezone.utc) - self._started
        return elapsed.total_seconds()

    def start(self) -> None:
        """Start the session guard."""
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self._started = datetime.now(timezone.utc)
        self._last_warning = self._started

        # Write initial heartbeat
        self._write_heartbeat()

        # Start background heartbeat thread (updates every 5 min)
        self._heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop,
            daemon=True,
            name=f"session-guard-{self.short_id}",
        )
        self._heartbeat_thread.start()

        logger.debug(f"Session guard started for {self.short_id}")

    def stop(self) -> None:
        """Stop the session guard and clean up."""
        self._stop_event.set()

        if self._heartbeat_thread and self._heartbeat_thread.is_alive():
            self._heartbeat_thread.join(timeout=2.0)

        # Remove heartbeat file
        try:
            if self._heartbeat_file.exists():
                self._heartbeat_file.unlink()
        except OSError as e:
            logger.debug(f"Failed to remove heartbeat file: {e}")

        logger.debug(f"Session guard stopped for {self.short_id}")

    def update(
        self,
        iteration: int | None = None,
        items_completed: int | None = None,
        items_total: int | None = None,
        phase: str | None = None,
    ) -> None:
        """Update session progress.

        Args:
            iteration: Current iteration number
            items_completed: Number of items completed
            items_total: Total items (if changed)
            phase: Current phase name
        """
        with self._lock:
            if iteration is not None:
                self._iteration = iteration
            if items_completed is not None:
                self._items_completed = items_completed
            if items_total is not None:
                self.items_total = items_total
            if phase is not None:
                self._current_phase = phase

    def check_timeout(self) -> bool:
        """Check if session should terminate due to timeout.

        This may prompt the user if warning threshold is reached.
        User input resets the warning timer.

        Returns:
            True if session should terminate, False to continue
        """
        if not self._started:
            return False

        runtime = self.runtime_hours

        # Hard limit - always terminate
        if runtime >= self.max_hours:
            logger.warning(
                f"Session {self.short_id} reached hard limit of {self.max_hours}h, terminating"
            )
            return True

        # Check if warning threshold reached since last warning/start
        hours_since_warning = 0.0
        if self._last_warning:
            elapsed = datetime.now(timezone.utc) - self._last_warning
            hours_since_warning = elapsed.total_seconds() / 3600

        if hours_since_warning >= self.warning_hours:
            # Time to warn user
            should_continue = self._prompt_user(runtime)
            if should_continue:
                # Reset warning timer
                self._last_warning = datetime.now(timezone.utc)
                self._warning_count += 1
                self._write_heartbeat()
                return False
            else:
                logger.info(f"Session {self.short_id} terminated by user after {runtime:.1f}h")
                return True

        return False

    def record_user_activity(self) -> None:
        """Record user activity to reset the warning timer.

        Call this when user provides any input during the session.
        """
        with self._lock:
            self._last_warning = datetime.now(timezone.utc)
        logger.debug(f"Session {self.short_id} warning timer reset due to user activity")

    def _prompt_user(self, runtime_hours: float) -> bool:
        """Prompt user to continue session.

        Args:
            runtime_hours: Current runtime in hours

        Returns:
            True to continue, False to stop
        """
        # Use custom handler if provided
        if self.on_warning:
            return self.on_warning(runtime_hours, self._warning_count)

        # Default: TTY prompt
        if not sys.stdin.isatty():
            logger.warning(
                f"Session {self.short_id} running for {runtime_hours:.1f}h "
                f"in non-interactive mode, continuing..."
            )
            return True

        print()
        print(f"Session has been running for {runtime_hours:.1f} hours.")
        print(f"Items completed: {self._items_completed}/{self.items_total}")
        print(f"Current phase: {self._current_phase}")
        print()

        try:
            from obra.display.prompting import prompt_input

            response = prompt_input("Continue session? [Y/n]: ").strip().lower()
            if response in ("", "y", "yes"):
                print("Continuing session...")
                return True
            else:
                print("Stopping session...")
                return False
        except (EOFError, KeyboardInterrupt):
            print("\nStopping session...")
            return False

    def _write_heartbeat(self) -> None:
        """Write current state to heartbeat file."""
        if not self._started:
            return

        now = datetime.now(timezone.utc)
        heartbeat = SessionHeartbeat(
            pid=os.getpid(),
            session_id=self.session_id,
            short_id=self.short_id,
            started=self._started.isoformat(),
            last_heartbeat=now.isoformat(),
            runtime_seconds=self.runtime_seconds,
            iteration=self._iteration,
            items_completed=self._items_completed,
            items_total=self.items_total,
            current_phase=self._current_phase,
            working_dir=self.working_dir,
            warning_count=self._warning_count,
        )

        try:
            self._heartbeat_file.write_text(
                json.dumps(heartbeat.to_dict(), indent=2),
                encoding="utf-8",
            )
        except OSError as e:
            logger.debug(f"Failed to write heartbeat: {e}")

    def _heartbeat_loop(self) -> None:
        """Background thread that updates heartbeat every 5 minutes."""
        interval = 300  # 5 minutes

        while not self._stop_event.is_set():
            self._stop_event.wait(timeout=interval)
            if not self._stop_event.is_set():
                with self._lock:
                    self._write_heartbeat()


def find_running_sessions(run_dir: Path | None = None) -> list[SessionHeartbeat]:
    """Find all tracked sessions and their status.

    Args:
        run_dir: Directory containing heartbeat files

    Returns:
        List of SessionHeartbeat objects for running sessions
    """
    run_dir = run_dir or OBRA_RUN_DIR
    results: list[SessionHeartbeat] = []

    if not run_dir.exists():
        return results

    for hb_file in run_dir.glob("session-*.json"):
        try:
            data = json.loads(hb_file.read_text(encoding="utf-8"))
            heartbeat = SessionHeartbeat.from_dict(data)

            # Check if process is still alive
            if _process_alive(heartbeat.pid):
                # Update runtime to current
                started = datetime.fromisoformat(heartbeat.started)
                heartbeat.runtime_seconds = (datetime.now(timezone.utc) - started).total_seconds()
                results.append(heartbeat)
            else:
                # Stale heartbeat file - process died
                try:
                    hb_file.unlink()
                except OSError:
                    pass
        except (json.JSONDecodeError, KeyError, OSError) as e:
            logger.debug(f"Failed to read heartbeat {hb_file}: {e}")

    return results


def _process_alive(pid: int) -> bool:
    """Check if a process with given PID is alive."""
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False
