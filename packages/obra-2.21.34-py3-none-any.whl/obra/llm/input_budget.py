"""Deterministic LLM input budget preflight checks.

Provides model-aware input budget validation at LLM invocation boundaries.
Uses context-window metadata from the model registry to detect oversized
prompts before they reach provider APIs or CLI subprocesses.

Architecture Decision:
    See docs/decisions/ADR-047-UNIFIED-LLM-SUBPROCESS-RUNNER.md

Related:
    - obra/model_registry.py (context window data)
    - obra/llm/invoker.py (direct API invocation path)
    - obra/llm/subprocess_runner.py (CLI subprocess invocation path)
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import Any

from obra.model_registry import get_max_prompt_tokens_for_model

logger = logging.getLogger(__name__)


class BudgetDecision(Enum):
    """Budget preflight decision outcomes."""

    OK = "ok"
    WARN = "warn"
    EXCEEDED = "exceeded"


@dataclass
class BudgetCheckResult:
    """Structured result from an input budget preflight check.

    Attributes:
        estimated_input_tokens: Estimated token count for the prompt text.
        max_prompt_tokens: Resolved maximum prompt tokens for the model.
        utilization_ratio: Ratio of estimated to max (0.0 - 1.0+).
        decision: Budget decision (ok, warn, exceeded).
        action: Recommended action based on decision and policy.
        provider: Provider name used for the check.
        model: Model name used for the check.
        warning_threshold: The warning threshold used for the check.
    """

    estimated_input_tokens: int
    max_prompt_tokens: int
    utilization_ratio: float
    decision: BudgetDecision
    action: str
    provider: str
    model: str
    warning_threshold: float = 0.85

    def to_log_fields(self) -> dict[str, Any]:
        """Return logger-safe payload fields for standardized budget events.

        Fields match the schema required by S1.T0 (FEAT-LLM-CONTEXT-BUDGET-001):
        provider, model, estimated_tokens, prompt_budget, utilization_pct,
        threshold_pct, decision, action_taken.
        """
        return {
            "provider": self.provider,
            "model": self.model,
            "estimated_tokens": self.estimated_input_tokens,
            "prompt_budget": self.max_prompt_tokens,
            "utilization_pct": round(self.utilization_ratio * 100, 1),
            "threshold_pct": round(self.warning_threshold * 100, 1),
            "decision": self.decision.value,
            "action_taken": self.action,
        }


def check_input_budget(
    provider: str,
    model: str,
    prompt_text: str,
    *,
    warning_threshold: float = 0.85,
    on_exceed: str = "warn",
    log_event: Callable[..., None] | None = None,
) -> BudgetCheckResult:
    """Run deterministic input budget preflight check.

    Estimates input tokens for the given prompt text and compares against
    the model's resolved maximum prompt tokens from the model registry.

    Args:
        provider: LLM provider name (anthropic, openai, google, ollama).
        model: Model identifier.
        prompt_text: The full prompt text to check (prompt + system_prompt).
        warning_threshold: Utilization ratio that triggers a warning (default 0.85).
        on_exceed: Policy when budget is exceeded - "warn" (log and continue)
            or "fail" (return error, no provider call).
        log_event: Optional callback for emitting budget events. Matches the
            LLMSubprocessConfig.log_event signature.

    Returns:
        BudgetCheckResult with estimated tokens, budget, decision, and action.

    Example:
        >>> result = check_input_budget("anthropic", "sonnet", "Hello world")
        >>> result.decision
        <BudgetDecision.OK: 'ok'>
        >>> result.action
        'proceed'
    """
    # Resolve max prompt tokens from model registry
    max_prompt_tokens = get_max_prompt_tokens_for_model(provider, model)

    # Estimate input tokens: len(text) // 4 matches provider estimate_tokens implementations
    estimated_input_tokens = len(prompt_text) // 4

    # Calculate utilization ratio
    utilization_ratio = (
        estimated_input_tokens / max_prompt_tokens if max_prompt_tokens > 0 else 1.0
    )

    # Determine decision
    if utilization_ratio > 1.0:
        decision = BudgetDecision.EXCEEDED
    elif utilization_ratio >= warning_threshold:
        decision = BudgetDecision.WARN
    else:
        decision = BudgetDecision.OK

    # Determine action based on decision and policy
    if decision == BudgetDecision.EXCEEDED:
        action = "fail" if on_exceed == "fail" else "warn_and_proceed"
    elif decision == BudgetDecision.WARN:
        action = "warn_and_proceed"
    else:
        action = "proceed"

    result = BudgetCheckResult(
        estimated_input_tokens=estimated_input_tokens,
        max_prompt_tokens=max_prompt_tokens,
        utilization_ratio=utilization_ratio,
        decision=decision,
        action=action,
        provider=provider,
        model=model,
        warning_threshold=warning_threshold,
    )

    # Emit standardized events (FEAT-LLM-CONTEXT-BUDGET-001 S1.T0)
    # Event names: llm_input_budget_checked (ok), llm_input_budget_warning, llm_input_budget_exceeded
    log_fields = result.to_log_fields()
    _EVENT_NAMES = {
        BudgetDecision.OK: "llm_input_budget_checked",
        BudgetDecision.WARN: "llm_input_budget_warning",
        BudgetDecision.EXCEEDED: "llm_input_budget_exceeded",
    }
    event_name = _EVENT_NAMES[decision]

    if log_event is not None:
        log_event(event_name, **log_fields)
    else:
        # Stdlib logging fallback so budget events are always visible
        if decision == BudgetDecision.OK:
            logger.info(
                "Input budget ok: %s/%s utilization at %.1f%% "
                "(estimated %d tokens, budget %d tokens)",
                provider,
                model,
                utilization_ratio * 100,
                estimated_input_tokens,
                max_prompt_tokens,
            )
        elif decision == BudgetDecision.WARN:
            logger.warning(
                "Input budget warning: %s/%s utilization at %.1f%% "
                "(estimated %d tokens, budget %d tokens, threshold %.0f%%)",
                provider,
                model,
                utilization_ratio * 100,
                estimated_input_tokens,
                max_prompt_tokens,
                warning_threshold * 100,
            )
        elif decision == BudgetDecision.EXCEEDED:
            logger.warning(
                "Input budget exceeded: %s/%s utilization at %.1f%% "
                "(estimated %d tokens, budget %d tokens) - action: %s",
                provider,
                model,
                utilization_ratio * 100,
                estimated_input_tokens,
                max_prompt_tokens,
                action,
            )

    return result


# Canonical resolution guidance fragment shared by all budget messages.
BUDGET_RESOLUTION_HINT = "Reduce prompt scope, use chunking, or adjust model/config."

# Standardized event names for cross-path parity (S1.T0).
BUDGET_EVENT_NAMES = {
    BudgetDecision.OK: "llm_input_budget_checked",
    BudgetDecision.WARN: "llm_input_budget_warning",
    BudgetDecision.EXCEEDED: "llm_input_budget_exceeded",
}

# Required fields in every budget event payload (S1.T0 schema).
BUDGET_EVENT_REQUIRED_FIELDS = frozenset({
    "provider",
    "model",
    "estimated_tokens",
    "prompt_budget",
    "utilization_pct",
    "threshold_pct",
    "decision",
    "action_taken",
})


def format_budget_error_message(result: BudgetCheckResult) -> str:
    """Format a user-facing error message for budget exceeded results.

    Produces a canonical message with cause and resolution guidance.

    Args:
        result: BudgetCheckResult from check_input_budget.

    Returns:
        Actionable error message explaining the budget situation.
    """
    return (
        f"Input budget exceeded: estimated {result.estimated_input_tokens:,} tokens "
        f"exceeds budget of {result.max_prompt_tokens:,} tokens "
        f"({result.utilization_ratio:.0%} utilization) for {result.provider}/{result.model}. "
        f"{BUDGET_RESOLUTION_HINT}"
    )


def format_budget_warning_message(result: BudgetCheckResult) -> str:
    """Format a user-facing warning message for budget warning results.

    Produces a canonical message with cause and resolution guidance.

    Args:
        result: BudgetCheckResult from check_input_budget.

    Returns:
        Actionable warning message explaining the budget situation.
    """
    return (
        f"Input budget warning: estimated {result.estimated_input_tokens:,} tokens "
        f"approaching budget of {result.max_prompt_tokens:,} tokens "
        f"({result.utilization_ratio:.0%} utilization) for {result.provider}/{result.model}. "
        f"{BUDGET_RESOLUTION_HINT}"
    )


__all__ = [
    "BUDGET_EVENT_NAMES",
    "BUDGET_EVENT_REQUIRED_FIELDS",
    "BUDGET_RESOLUTION_HINT",
    "BudgetCheckResult",
    "BudgetDecision",
    "check_input_budget",
    "format_budget_error_message",
    "format_budget_warning_message",
]
