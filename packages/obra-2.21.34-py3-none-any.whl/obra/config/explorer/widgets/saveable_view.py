"""Saveable View Mixin for Config Explorer.

Provides snapshot-based dirty tracking for views that support per-screen
save/discard functionality.
"""

from __future__ import annotations

from typing import Any


class SaveableViewMixin:
    """Mixin for views that support save/discard workflow.

    Views using this mixin can:
    - Track whether they have unsaved changes (is_dirty)
    - Return their pending changes for saving (get_pending_changes)
    - Discard changes and revert to initial state (discard_changes)
    - Mark themselves as clean after save (mark_saved)

    Usage:
        class MyView(SaveableViewMixin, Static):
            def __init__(self, initial_value: str, **kwargs):
                Static.__init__(self, **kwargs)
                self._value = initial_value
                # Take snapshot of initial state
                self._snapshot_state()

            def _get_saveable_state(self) -> dict[str, Any]:
                return {"value": self._value}

            def _restore_state(self, state: dict[str, Any]) -> None:
                self._value = state["value"]
                self._update_ui()
    """

    _initial_snapshot: dict[str, Any]

    def _snapshot_state(self) -> None:
        """Take a snapshot of current state as the initial/saved state.

        Call this in __init__ after setting initial values, and after
        successful saves via mark_saved().
        """
        self._initial_snapshot = self._get_saveable_state()

    def _get_saveable_state(self) -> dict[str, Any]:
        """Get current state that should be saved/compared.

        Override in subclass to return the current values that matter
        for dirty tracking and saving.

        Returns:
            Dict of current values (will be compared with snapshot).
        """
        msg = "Subclass must implement _get_saveable_state"
        raise NotImplementedError(msg)

    def _restore_state(self, state: dict[str, Any]) -> None:
        """Restore state from a snapshot.

        Override in subclass to restore UI and internal state from
        the given snapshot.

        Args:
            state: Previously captured state dict from _get_saveable_state.
        """
        msg = "Subclass must implement _restore_state"
        raise NotImplementedError(msg)

    def is_dirty(self) -> bool:
        """Check if view has unsaved changes.

        Returns:
            True if current values differ from initial snapshot.
        """
        if not hasattr(self, "_initial_snapshot"):
            return False
        current = self._get_saveable_state()
        is_diff = current != self._initial_snapshot

        # Debug logging
        try:
            from obra.config.explorer.debug import is_debug_enabled, log_action

            if is_debug_enabled():
                if is_diff:
                    # Show what changed
                    changes = []
                    for key in set(current.keys()) | set(self._initial_snapshot.keys()):
                        old_val = self._initial_snapshot.get(key, "<missing>")
                        new_val = current.get(key, "<missing>")
                        if old_val != new_val:
                            changes.append(f"{key}: {old_val!r} -> {new_val!r}")
                    log_action(
                        f"{type(self).__name__}.is_dirty",
                        f"DIRTY! changes=[{', '.join(changes)}]",
                    )
                else:
                    log_action(f"{type(self).__name__}.is_dirty", "CLEAN (no changes)")
        except ImportError:
            pass

        return is_diff

    def get_pending_changes(self) -> dict[str, tuple[Any, Any]]:
        """Get changes that should be saved.

        Returns:
            Dict mapping config paths to (old_value, new_value) tuples.
            Empty if not dirty.
        """
        if not self.is_dirty():
            return {}

        current = self._get_saveable_state()
        changes: dict[str, tuple[Any, Any]] = {}

        for key, new_value in current.items():
            old_value = self._initial_snapshot.get(key)
            if old_value != new_value:
                changes[key] = (old_value, new_value)

        return changes

    def discard_changes(self) -> None:
        """Discard all changes and revert to initial state.

        Restores internal state to match the snapshot taken on mount.
        """
        if hasattr(self, "_initial_snapshot"):
            self._restore_state(self._initial_snapshot)

    def mark_saved(self) -> None:
        """Mark the view as clean after successful save.

        Updates the internal snapshot to match current values.
        """
        self._snapshot_state()
