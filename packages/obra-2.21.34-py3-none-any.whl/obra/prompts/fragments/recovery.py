"""Prompt builders for recovery and retry banners."""

from __future__ import annotations

__all__ = ["build_interactive_recovery_banner"]


def build_interactive_recovery_banner(line: str | None) -> str:
    """Build prompt banner for interactive guard recovery retry.

    Args:
        line: Matched interactive prompt line

    Returns:
        Recovery banner string
    """
    line_text = line.strip() if line else "unknown"
    return (
        "## Recovery Notice\n"
        "The previous run was blocked due to interactive output:\n"
        f"> {line_text}\n"
        "Do not run interactive shell commands. If a command would prompt for input or "
        "confirmation, stop and return an error instead. Continue non-interactively."
    )
