"""Prompt builder for intent alignment QA (epic/story coverage).

This prompt asks an LLM to compare derived epics/stories against the intent
and return structured coverage feedback with actionable fixes.
"""


def build_plan_intent_alignment_prompt(
    objective: str,
    intent_markdown: str,
    epics_json: str,
    stories_json: str,
) -> str:
    """Build prompt for intent alignment review.

    Args:
        objective: Original objective string
        intent_markdown: Intent markdown content
        epics_json: JSON string of epics to evaluate
        stories_json: JSON string of stories to evaluate

    Returns:
        Prompt string for LLM review
    """
    return f"""You are auditing plan alignment against intent and providing fixes.

Objective:
"{objective}"

Intent:
{intent_markdown}

Epics (JSON):
{epics_json}

Stories (JSON):
{stories_json}

Task:
1) Evaluate whether epics and stories cover the intent requirements.
2) Identify missing requirements or scope creep.
3) Provide structured fixes: stories to add, stories to remove.

Rules:
- Ignore tasks/subtasks entirely (those are handled separately).
- Only judge epics/stories based on id, title, description, acceptance_criteria.
- Do not add features beyond intent scope.
- Be lean: only add stories for genuinely missing requirements.
- Mark scope creep stories for removal by ID.

Output format (JSON only):
{{
  "coverage_status": "pass|warn|fail",
  "story_assessments": [
    {{"id": "story-id", "status": "ok|scope_creep|missing_coverage", "note": "optional brief note"}}
  ],
  "missing_requirements": ["Requirement X not covered by any story"],
  "stories_to_add": [
    {{
      "title": "Story title",
      "description": "What this story accomplishes",
      "parent_id": "epic-id to attach to (from epics list)",
      "acceptance_criteria": ["criterion 1", "criterion 2"]
    }}
  ],
  "stories_to_remove": ["story-id-that-is-scope-creep"],
  "notes": ["Optional clarifying notes"]
}}

Requirements:
- `story_assessments`: One entry per input story showing its coverage status
- `stories_to_remove`: IDs of stories that are scope creep (subset of story_assessments with status=scope_creep)
- `stories_to_add`: New stories needed for missing requirements
- Every story in `stories_to_add` must include title, description, parent_id, acceptance_criteria
- Do NOT omit parent_id; choose a parent epic from the Epics list

If plan is sound: return {{"coverage_status": "pass", "story_assessments": [...all stories with status "ok"...], "missing_requirements": [], "stories_to_add": [], "stories_to_remove": [], "notes": []}}

One pass. Be direct. Stop after responding.
"""


def build_story_intent_alignment_prompt(
    objective: str,
    intent_markdown: str,
    story_json: str,
    epic_title: str | None = None,
) -> str:
    """Build prompt for per-story intent alignment review.

    Args:
        objective: Original objective string
        intent_markdown: Intent markdown content (full document for context)
        story_json: JSON string of the single story to evaluate
        epic_title: Title of the parent epic (for context)

    Returns:
        Prompt string for LLM review of single story
    """
    epic_context = f"\nParent Epic: {epic_title}" if epic_title else ""

    return f"""You are auditing a single story's alignment against the project intent.

Objective:
"{objective}"

Intent:
{intent_markdown}
{epic_context}

Story to evaluate (JSON):
{story_json}

Task:
Evaluate whether this story aligns with the intent requirements.

Assessment criteria:
- "ok": Story directly supports a requirement in the intent
- "scope_creep": Story adds functionality not specified in the intent
- "missing_coverage": Story is too vague to verify coverage (rare)

Rules:
- Judge only based on id, title, description, acceptance_criteria
- Be strict about scope creep: if not in intent, it's scope creep
- Be lenient about ok: reasonable implementation details are fine

Output format (JSON only):
{{
  "status": "ok|scope_creep|missing_coverage",
  "note": "Brief explanation (1-2 sentences)"
}}

One pass. Be direct. Stop after responding.
"""


def build_gap_detection_prompt(
    objective: str,
    intent_markdown: str,
    stories_json: str,
) -> str:
    """Build prompt for gap detection after per-story assessment.

    This prompt checks if any intent requirements are NOT covered by existing stories.

    Args:
        objective: Original objective string
        intent_markdown: Full intent document
        stories_json: JSON string of all stories that passed assessment

    Returns:
        Prompt string for LLM gap detection
    """
    return f"""You are auditing plan completeness against the project intent.

Objective:
"{objective}"

Intent:
{intent_markdown}

Stories in plan (JSON):
{stories_json}

Task:
Identify any requirements from the intent that are NOT covered by any existing story.

Rules:
- Only flag genuinely missing requirements
- Be conservative: if a story reasonably covers a requirement, don't flag it
- Don't suggest stories for implicit features not in the intent
- Focus on explicit requirements that have no corresponding story

Output format (JSON only):
{{
  "gaps_found": true|false,
  "missing_requirements": ["Requirement X from intent has no story", ...],
  "stories_to_add": [
    {{
      "title": "Story title for missing requirement",
      "description": "What this story accomplishes",
      "parent_id": "epic-id to attach to (from epics list)",
      "acceptance_criteria": ["criterion 1", "criterion 2"]
    }}
  ]
}}

If no gaps: return {{"gaps_found": false, "missing_requirements": [], "stories_to_add": []}}

One pass. Be direct. Stop after responding.
"""
