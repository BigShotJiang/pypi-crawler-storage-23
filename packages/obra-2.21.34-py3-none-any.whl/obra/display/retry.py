"""Retry banner helpers for transient LLM failures."""

from __future__ import annotations

import time

from obra.display import print_info
from obra.display.observability import VerbosityLevel, get_runtime_verbosity

_RETRY_BANNER_MIN_INTERVAL_S = 5.0
_last_retry_banner_ts: float | None = None


def maybe_show_retry_banner(
    *,
    attempt: int,
    max_attempts: int,
    delay_s: float,
    provider: str,
    summary: str,
) -> None:
    """Print a rate-limited retry status line if verbosity allows."""
    if get_runtime_verbosity() <= VerbosityLevel.QUIET:
        return

    global _last_retry_banner_ts
    now = time.time()
    if _last_retry_banner_ts is not None:
        if now - _last_retry_banner_ts < _RETRY_BANNER_MIN_INTERVAL_S:
            return

    summary = summary.strip()
    if not summary:
        summary = "Transient provider error"
    if provider:
        summary = f"{provider}: {summary}"

    print_info(f"{summary}. Retrying in {delay_s:.0f}s ({attempt}/{max_attempts})...")
    _last_retry_banner_ts = now


def show_rate_limit_exhaustion(*, provider: str, attempts: int) -> None:
    """Show actionable message when rate limit retries are exhausted."""
    if get_runtime_verbosity() <= VerbosityLevel.QUIET:
        return

    prefix = f"{provider}: " if provider else ""
    print_info(
        f"{prefix}Rate limit persists after {attempts} retries — quota may be exhausted. "
        f"Wait for quota reset or try a different model/tier."
    )


__all__ = ["maybe_show_retry_banner", "show_rate_limit_exhaustion"]
