"""U(1) lattice gauge-theory (QED) model helpers."""

import numpy as np
from numba import typed
from edlgt.modeling import LocalTerm, TwoBodyTerm, PlaquetteTerm
from edlgt.modeling import check_link_symmetry, staggered_mask, get_origin_surfaces
from .quantum_model import QuantumModel
from edlgt.operators import QED_dressed_site_operators, QED_gauge_invariant_states
import logging

logger = logging.getLogger(__name__)
__all__ = ["QED_Model"]


class QED_Model(QuantumModel):
    """QED lattice gauge model with optional matter fields."""

    def __init__(self, spin, pure_theory, bg_list=None, get_only_bulk=False, **kwargs):
        """Initialize the QED model and construct its symmetry sector.

        Parameters
        ----------
        spin : float
            Gauge-link spin representation.
        pure_theory : bool
            If ``True``, build the pure-gauge theory (no matter fields).
        bg_list : list, optional
            Optional background-charge configuration used during local-basis
            projection.
        get_only_bulk : bool, optional
            Restrict gauge-invariant local states to bulk-compatible ones when
            supported by the operator factory.
        **kwargs
            Arguments forwarded to :class:`~edlgt.models.quantum_model.QuantumModel`.
        """
        # Initialize base class with the common parameters
        super().__init__(**kwargs)
        self.spin = spin
        self.pure_theory = pure_theory
        self.background = int(max(np.abs(bg_list))) if bg_list is not None else 0
        self.bg_list = bg_list if self.background != 0 else None
        self.staggered_basis = False if self.pure_theory else True
        pure_label = "pure" if self.pure_theory else "with matter"
        logger.info(f"----------------------------------------------------")
        msg = f"({self.dim}+1)D QED MODEL {pure_label} j={spin}, bg={self.background}"
        logger.info(msg)
        # -------------------------------------------------------------------------------
        # Acquire gauge invariant basis and states
        self.gauge_basis, self.gauge_states = QED_gauge_invariant_states(
            self.spin,
            self.pure_theory,
            lattice_dim=self.dim,
            background=self.background,
            get_only_bulk=get_only_bulk,
        )
        # -------------------------------------------------------------------------------
        # Acquire operators
        ops = QED_dressed_site_operators(
            self.spin, self.pure_theory, self.dim, background=self.background
        )
        # Initialize the operators, local dimension and lattice labels
        self.project_operators(ops, self.bg_list)
        # -------------------------------------------------------------------------------
        # GLOBAL SYMMETRIES
        if self.pure_theory:
            global_ops = None
            global_sectors = None
        else:
            global_ops = [self.ops["N"]]
            global_sectors = [int(self.n_sites / 2)]
        # -------------------------------------------------------------------------------
        # LINK SYMMETRIES
        link_ops = [
            [self.ops[f"E_p{d}"], -self.ops[f"E_m{d}"]] for d in self.directions
        ]
        link_sectors = [0 for _ in self.directions]
        # -------------------------------------------------------------------------------
        # ELECTRIC-FLUX “NBODY” SYMMETRIES
        # only in the pure (no-matter) theory, more than 1D, *and* PBC
        # Constrain, for each cartesian direction, the corresponding
        # Electric flux on the face/line through the origin:
        # 3D: (Ex → yz-face at x=0) (Ey → xz-face at y=0) (Ez → xy-face at z=0)
        # 2D: (Ex → y-axis at x=0) (Ey → x-axis at y=0)
        if self.pure_theory and not any(self.has_obc):
            logger.info("fixing surface electric fluxes")
            # one flux‐constraint per cartesian direction
            nbody_sectors = np.zeros(self.dim, dtype=float)
            nbody_ops = []
            nbody_sites_list = typed.List()
            surfaces = get_origin_surfaces(self.lvals)
            nbody_sym_type = "U"
            if self.dim == 2:
                # in 2D we have two lines through (0,0):
                line_of = {"x": "y", "y": "x"}
                for dir in self.directions:
                    sites = np.array(surfaces[line_of[dir]][1], dtype=np.uint8)
                    nbody_sites_list.append(sites)
                    nbody_ops.append(self.ops[f"E_p{dir}"])
            elif self.dim == 3:
                # in 3D we have three faces through (0,0,0):
                face_of = {"x": "yz", "y": "xz", "z": "xy"}
                for dir in self.directions:
                    sites = np.array(surfaces[face_of[dir]][1], dtype=np.uint8)
                    nbody_sites_list.append(sites)
                    logger.debug(f"{dir} sites: {sites} {surfaces[face_of[dir]][0]}")
                    nbody_ops.append(self.ops[f"E_p{dir}"])
        else:
            # no electric‐flux constraint in 1D, or in OBC or with matter
            nbody_sectors = None
            nbody_ops = None
            nbody_sites_list = None
            nbody_sym_type = None
        # GET SYMMETRY SECTOR
        self.get_abelian_symmetry_sector(
            global_ops=global_ops,
            global_sectors=global_sectors,
            link_ops=link_ops,
            link_sectors=link_sectors,
            nbody_ops=nbody_ops,
            nbody_sectors=nbody_sectors,
            nbody_sites_list=nbody_sites_list,
            nbody_sym_type=nbody_sym_type,
        )
        # DEFAULT PARAMS
        self.default_params()

    def build_Hamiltonian(self, g, m=None, theta=0.0):
        """Assemble the QED Hamiltonian.

        Parameters
        ----------
        g : float
            Gauge coupling.
        m : float, optional
            Bare fermion mass (used only when matter is present).
        theta : float, optional
            Topological-angle coupling parameter.
        """
        logger.info(f"----------------------------------------------------")
        logger.info("BUILDING HAMILTONIAN")
        # Hamiltonian Coefficients
        self.QED_Hamiltonian_couplings(g, m, theta)
        h_terms = {}
        # -------------------------------------------------------------------------------
        # ELECTRIC ENERGY
        op_name = "E2"
        h_terms[op_name] = LocalTerm(self.ops[op_name], op_name, **self.def_params)
        self.H.add_term(h_terms[op_name].get_Hamiltonian(strength=self.coeffs["E"]))
        # -------------------------------------------------------------------------------
        # PLAQUETTE TERM: MAGNETIC INTERACTION
        if self.dim > 1:
            op_names_list = ["C_px,py", "C_py,mx", "C_my,px", "C_mx,my"]
            op_list = [self.ops[op] for op in op_names_list]
            h_terms["plaq_xy"] = PlaquetteTerm(
                ["x", "y"], op_list, op_names_list, **self.def_params
            )
            self.H.add_term(
                h_terms["plaq_xy"].get_Hamiltonian(
                    strength=self.coeffs["B"], add_dagger=True
                )
            )
        if self.dim == 3:
            # XZ Plane
            op_names_list = ["C_px,pz", "C_pz,mx", "C_mz,px", "C_mx,mz"]
            op_list = [self.ops[op] for op in op_names_list]
            h_terms["plaq_xz"] = PlaquetteTerm(
                ["x", "z"], op_list, op_names_list, **self.def_params
            )
            self.H.add_term(
                h_terms["plaq_xz"].get_Hamiltonian(
                    strength=self.coeffs["B"], add_dagger=True
                )
            )
            # YZ Plane
            op_names_list = ["C_py,pz", "C_pz,my", "C_mz,py", "C_my,mz"]
            op_list = [self.ops[op] for op in op_names_list]
            h_terms["plaq_yz"] = PlaquetteTerm(
                ["y", "z"], op_list, op_names_list, **self.def_params
            )
            self.H.add_term(
                h_terms["plaq_yz"].get_Hamiltonian(
                    strength=self.coeffs["B"], add_dagger=True
                )
            )
        # -------------------------------------------------------------------------------
        # TOPOLOGICAL TERM
        # -------------------------------------------------------------------------------
        if self.dim == 2 and np.abs(self.coeffs["theta"]) > 10e-10:
            logger.info("Adding topological term")
            op_names_list = ["C_px,py", "C_py,mx", "C_my,px", "C_mx,my"]
            op_list = [self.ops[op] for op in op_names_list]
            h_terms["plaq_xy"] = PlaquetteTerm(
                ["x", "y"], op_list, op_names_list, **self.def_params
            )
            self.H.add_term(
                h_terms["plaq_xy"].get_Hamiltonian(
                    strength=self.coeffs["theta"], add_dagger=True
                )
            )
        if self.dim == 3 and np.abs(self.coeffs["theta"]) > 10e-10:
            logger.info("Adding topological term")
            # XY Plane
            op_names_list = ["EzC_px,py", "C_py,mx", "C_my,px", "C_mx,my"]
            op_list = [self.ops[op] for op in op_names_list]
            h_terms["Ez_Bxy"] = PlaquetteTerm(
                ["x", "y"], op_list, op_names_list, **self.def_params
            )
            self.H.add_term(
                h_terms["Ez_Bxy"].get_Hamiltonian(
                    strength=self.coeffs["theta"], add_dagger=True
                )
            )
            # XZ Plane
            op_names_list = ["EyC_px,pz", "C_pz,mx", "C_mz,px", "C_mx,mz"]
            op_list = [self.ops[op] for op in op_names_list]
            h_terms["Ey_Bxz"] = PlaquetteTerm(
                ["x", "z"], op_list, op_names_list, **self.def_params
            )
            self.H.add_term(
                h_terms["Ey_Bxz"].get_Hamiltonian(
                    strength=self.coeffs["theta"], add_dagger=True
                )
            )
            # YZ Plane
            op_names_list = ["ExC_py,pz", "C_pz,my", "C_mz,py", "C_my,mz"]
            op_list = [self.ops[op] for op in op_names_list]
            h_terms["Ex_Byz"] = PlaquetteTerm(
                ["y", "z"], op_list, op_names_list, **self.def_params
            )
            self.H.add_term(
                h_terms["Ex_Byz"].get_Hamiltonian(
                    strength=self.coeffs["theta"], add_dagger=True
                )
            )
        # -------------------------------------------------------------------------------
        if not self.pure_theory:
            # ---------------------------------------------------------------------------
            # STAGGERED MASS TERM
            for stag_label in ["even", "odd"]:
                h_terms[f"N_{stag_label}"] = LocalTerm(
                    operator=self.ops["N"], op_name="N", **self.def_params
                )
                self.H.add_term(
                    h_terms[f"N_{stag_label}"].get_Hamiltonian(
                        self.coeffs[f"m_{stag_label}"],
                        staggered_mask(self.lvals, stag_label),
                    )
                )
            # ---------------------------------------------------------------------------
            # HOPPING
            for d in self.directions:
                for stag_label in ["even", "odd"]:
                    # Define the list of the 2 non trivial operators
                    op_names_list = [f"Q_p{d}_dag", f"Q_m{d}"]
                    op_list = [self.ops[op] for op in op_names_list]
                    # Define the Hamiltonian term
                    h_terms[f"{d}_hop_{stag_label}"] = TwoBodyTerm(
                        d, op_list, op_names_list, **self.def_params
                    )
                    self.H.add_term(
                        h_terms[f"{d}_hop_{stag_label}"].get_Hamiltonian(
                            strength=self.coeffs[f"t{d}_{stag_label}"],
                            add_dagger=True,
                            mask=staggered_mask(self.lvals, stag_label),
                        )
                    )
        self.H.build(format=self.ham_format)

    def check_symmetries(self):
        """Check link-symmetry constraints on measured electric fields."""
        # CHECK LINK SYMMETRIES
        for ax in self.directions:
            check_link_symmetry(
                ax,
                self.obs_list[f"E_p{ax}"],
                self.obs_list[f"E_m{ax}"],
                value=0,
                sign=1,
            )

    def QED_Hamiltonian_couplings(self, g, m=None, theta=0.0, magnetic_basis=False):
        """Set QED Hamiltonian couplings from physical parameters.

        Parameters
        ----------
        g : float
            Gauge coupling.
        m : float, optional
            Bare mass parameter (used only with matter).
        theta : float, optional
            Topological-angle parameter.
        magnetic_basis : bool, optional
            If ``True``, use the alternative magnetic-basis normalization.

        Returns
        -------
        None
            Stores couplings in ``self.coeffs``.
        """
        if not magnetic_basis:
            if self.dim == 1:
                E = g / 2
                B = -1 / (2 * g)
            elif self.dim == 2:
                E = g / 2
                B = -1 / (2 * g)
            else:
                E = g / 2
                B = -1 / (2 * g)
            # DICTIONARY WITH MODEL COEFFICIENTS
            coeffs = {
                "g": g,
                "E": E,  # ELECTRIC FIELD coupling
                "B": B,  # MAGNETIC FIELD coupling
                "theta": -theta * g,  # THETA TERM coupling
            }
            if not self.pure_theory and m is not None:
                t = 1 / 2
                coeffs |= {
                    "tx_even": -complex(0, t),  # x HOPPING (EVEN SITES)
                    "tx_odd": -complex(0, t),  # x HOPPING (ODD SITES)
                    "ty_even": -t,  # y HOPPING (EVEN SITES)
                    "ty_odd": t,  # y HOPPING (ODD SITES)
                    "tz_even": -complex(0, t),  # z HOPPING (EVEN SITES)
                    "tz_odd": complex(0, t),  # z HOPPING (ODD SITES)
                    "m": m,
                    "m_odd": -m,  # EFFECTIVE MASS for ODD SITES
                    "m_even": m,  # EFFECTIVE MASS for EVEN SITES
                }
        else:
            # DICTIONARY WITH MODEL COEFFICIENTS
            coeffs = {
                "g": g,
                "E": -g,
                "B": -0.5 / g,
            }
        self.coeffs = coeffs

    def overlap_QMB_state(self, name):
        """Return predefined benchmark basis configurations for selected labels.

        Parameters
        ----------
        name : str
            Label of a predefined reference configuration.

        Returns
        -------
        numpy.ndarray
            Configuration in the model symmetry-sector basis.
        """
        # MINIMAL STRING CONFIGURATIONS IN 3D QED WITH BACKGROUND charges
        if len(self.lvals) == 3 and self.bg_list == [-1, 0, 0, 0, 0, 0, 0, 1]:
            if name == "S1":
                config_state = np.array([4, 9, 9, 3, 6, 0, 3, 10])
            elif name == "S2":
                config_state = np.array([3, 9, 6, 0, 9, 3, 3, 11])
            elif name == "S3":
                config_state = np.array([1, 7, 9, 3, 9, 2, 3, 10])
            elif name == "S4":
                config_state = np.array([4, 9, 9, 3, 7, 3, 0, 8])
            elif name == "S5":
                config_state = np.array([1, 6, 9, 2, 9, 3, 3, 11])
            elif name == "S6":
                config_state = np.array([3, 9, 7, 3, 9, 3, 2, 8])
            else:
                raise ValueError(f"Unknown String name: {name}")
            return config_state
        else:
            raise NotImplementedError("Only 3D QED states are supported")

    def print_state_config(self, config, amplitude=None):
        """Log a readable per-site decomposition of a QED basis configuration."""
        logger.info(f"----------------------------------------------------")
        msg = f"CONFIG {config}"
        if amplitude is not None:
            msg += f" |psi|^2={np.abs(amplitude)**2:.8f}"
        logger.info(msg)
        logger.info(f"----------------------------------------------------")
        # Choose width (sign + digits).
        max_abs = 1
        max_abs = max(max_abs, int(abs(getattr(self, "spin", 1))))
        max_abs = max(max_abs, int(abs(getattr(self, "background", 0))))
        entry_width = len(str(max_abs)) + 2
        logger.info(f"{'':>19s}{self._format_header(entry_width)}")
        for ii, cfg_idx in enumerate(config):
            loc_basis_state = self.gauge_states_per_site[ii][cfg_idx]
            state_str = (
                "["
                + " ".join(f"{val:>{entry_width}d}" for val in loc_basis_state)
                + " ]"
            )
            logger.info(f"SITE {ii:>2d} state {cfg_idx:>3d}: {state_str}")

    def _local_state_labels(self) -> list[str]:
        """Return column labels used by :meth:`print_state_config`."""
        labels: list[str] = []
        # Background first (only if present in your effective gauge states)
        if getattr(self, "background", 0) > 0:
            labels.append("bg")
        # Matter occupation (only if not pure theory)
        if not getattr(self, "pure_theory", True):
            labels.append("M")
        # Links: -x,-y,-z,+x,+y,+z up to dim
        dim = int(getattr(self, "dim", 0))
        dirs = "xyz"[:dim]
        labels += [f"-{d}" for d in dirs] + [f"+{d}" for d in dirs]
        return labels

    def _format_header(self, entry_width: int) -> str:
        """Format the header row for :meth:`print_state_config`."""
        labels = self._local_state_labels()
        header = "[" + " ".join(f"{lab:>{entry_width}s}" for lab in labels) + " ]"
        return header
