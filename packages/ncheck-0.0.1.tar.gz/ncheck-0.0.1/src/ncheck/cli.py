import argparse
import socket
import sys


def check_host(host: str, port: int = 80, timeout: int = 3) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def main():
    parser = argparse.ArgumentParser(
        prog="ncheck",
        description="Simple network connectivity checker"
    )

    parser.add_argument("host", help="Host to test")
    parser.add_argument(
        "-p", "--port",
        type=int,
        default=80,
        help="Port to test (default: 80)"
    )

    args = parser.parse_args()

    print(f"Checking {args.host}:{args.port}...")

    if check_host(args.host, args.port):
        print("✅ Connection successful")
        sys.exit(0)
    else:
        print("❌ Connection failed")
        sys.exit(1)


if __name__ == "__main__":
    main()