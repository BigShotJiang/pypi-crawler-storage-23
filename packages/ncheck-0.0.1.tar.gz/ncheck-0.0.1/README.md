# ncheck

Simple CLI tool for network checks.
