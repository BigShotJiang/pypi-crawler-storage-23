# Area Plot

::: pyretailscience.plots.area
