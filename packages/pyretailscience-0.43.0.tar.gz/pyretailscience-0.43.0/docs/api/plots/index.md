# Index Plot

::: pyretailscience.plots.index
