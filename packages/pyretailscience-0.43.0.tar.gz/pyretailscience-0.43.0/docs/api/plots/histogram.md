# Histogram Plot

::: pyretailscience.plots.histogram
