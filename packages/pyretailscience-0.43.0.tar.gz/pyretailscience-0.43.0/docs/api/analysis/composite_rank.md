# Composite Rank

::: pyretailscience.analysis.composite_rank
