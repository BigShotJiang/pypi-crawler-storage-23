# Cross Shop Analysis

::: pyretailscience.analysis.cross_shop
