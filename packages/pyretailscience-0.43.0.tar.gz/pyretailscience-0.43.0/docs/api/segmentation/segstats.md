# SegTransactionStats Segmentation

::: pyretailscience.segmentation.segstats
