# HML Segmentation

::: pyretailscience.segmentation.hml
