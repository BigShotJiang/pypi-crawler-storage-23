from pyretailscience.plugin import plugin_manager

__all__ = ["plugin_manager"]
