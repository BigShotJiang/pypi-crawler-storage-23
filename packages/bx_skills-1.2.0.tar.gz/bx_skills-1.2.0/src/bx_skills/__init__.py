"""BX Skills Installer TUI."""

from bx_skills.__init__conf__ import version as __version__  # noqa: F401  # re-export
