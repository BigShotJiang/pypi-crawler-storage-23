# Linux Console

The Linux console is less graphically capable than the terminal emulator on your desktop.

If you find your app does not look great with the default configuration, see [font-for-textual](https://github.com/jsatchell/font-for-textual) for a possible solution.

---

**See also**

- [Getting Started](./getting_started.md) - Installation and platform-specific notes
- [FAQ](./FAQ.md) - Frequently asked questions
