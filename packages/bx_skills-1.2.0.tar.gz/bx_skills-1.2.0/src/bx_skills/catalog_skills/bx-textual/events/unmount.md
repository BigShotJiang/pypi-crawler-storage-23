*API reference: `textual.events.Unmount`*


## See also

- [Mount](mount.md) - The complementary event sent when a widget is added to the DOM
- [Hide](hide.md) - Sent when a widget is hidden
- [Events guide](../guide/events.md) - Introduction to Textual's event system
