*API reference: `textual.worker`*

## See also

- [Guide: Workers](../guide/workers.md) - In-depth guide to workers and concurrency
