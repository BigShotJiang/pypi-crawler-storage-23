*API reference: `textual.color`*

## See also

- [CSS Type: Color](../css_types/color.md) - Color type reference for CSS styles
