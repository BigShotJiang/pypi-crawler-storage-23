*API reference: `textual.command`*

## See also

- [Guide: Command Palette](../guide/command_palette.md) - In-depth guide to the command palette
