*API reference: `textual.dom`*

## See also

- [Guide: CSS](../guide/CSS.md) - In-depth guide to CSS and the DOM
