*API reference: `textual.getters`*
