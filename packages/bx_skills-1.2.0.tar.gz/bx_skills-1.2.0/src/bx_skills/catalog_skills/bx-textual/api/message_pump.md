*API reference: `textual.message_pump`*
