*API reference: `textual.validation`*

## See also

- [Widget: Input](../widgets/input.md) - Input widget that uses validators
