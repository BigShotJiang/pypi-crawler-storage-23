A collection of Rich renderables which may be returned from a widget's ``render()`` method.

*API reference: `textual.renderables.bar`*

*API reference: `textual.renderables.blank`*

*API reference: `textual.renderables.digits`*

*API reference: `textual.renderables.gradient`*

*API reference: `textual.renderables.sparkline`*
