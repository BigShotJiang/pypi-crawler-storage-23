*API reference: `textual.pilot`*

## See also

- [Guide: Testing](../guide/testing.md) - In-depth guide to testing Textual apps
