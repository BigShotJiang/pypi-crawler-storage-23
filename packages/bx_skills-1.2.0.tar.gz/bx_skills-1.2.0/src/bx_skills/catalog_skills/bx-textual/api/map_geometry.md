A data structure returned by `screen.find_widget`.

*API reference: `textual.map_geometry`*
