*API reference: `textual.screen`*

## See also

- [Guide: Screens](../guide/screens.md) - In-depth guide to screens
