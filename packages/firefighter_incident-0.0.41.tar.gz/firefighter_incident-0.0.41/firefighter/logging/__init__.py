"""Custom logging formatter for the Firefighter project."""
