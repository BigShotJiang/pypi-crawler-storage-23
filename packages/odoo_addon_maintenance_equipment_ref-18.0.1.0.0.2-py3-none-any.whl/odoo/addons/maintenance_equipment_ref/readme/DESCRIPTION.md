This module introduces an Internal reference to the maintenance equipment
