import hmac
import hashlib
import time
from typing import Dict, Tuple, Optional

class WebhookVerifier:
    """
    Helper class to verify webhook signatures
    
    Usage in your webhook receiver:
        verifier = WebhookVerifier(webhook_secret)
        if verifier.verify(request.body, signature, timestamp):
            # Process webhook
    """
    
    def __init__(self, secret: str):
        """
        Initialize verifier with webhook secret
        
        Args:
            secret: Secret key from webhook registration
        """
        self.secret = secret
    
    def verify(
        self,
        payload: bytes,
        signature: str,
        timestamp: str,
        tolerance: int = 300
    ) -> Tuple[bool, Optional[str]]:
        """
        Verify webhook signature
        
        Args:
            payload: Raw request body
            signature: X-Webhook-Signature header
            timestamp: X-Webhook-Timestamp header
            tolerance: Max age in seconds (default 5 minutes)
        
        Returns:
            Tuple of (is_valid, error_message)
        """
        # Check timestamp
        try:
            webhook_time = int(timestamp)
        except ValueError:
            return False, "Invalid timestamp format"
        
        current_time = int(time.time())
        if abs(current_time - webhook_time) > tolerance:
            return False, f"Timestamp too old (tolerance: {tolerance}s)"
        
        # Compute expected signature
        message = f"{timestamp}.{payload.decode('utf-8')}"
        expected_signature = hmac.new(
            self.secret.encode('utf-8'),
            message.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        
        # Constant-time comparison
        is_valid = hmac.compare_digest(signature, expected_signature)
        
        if not is_valid:
            return False, "Invalid signature"
        
        return True, None
    
    def verify_request(
        self,
        request_body: str,
        headers: Dict[str, str],
        tolerance: int = 300
    ) -> Tuple[bool, Optional[str]]:
        """
        Verify webhook from request headers
        
        Args:
            request_body: Raw request body as string
            headers: Request headers dict
            tolerance: Max age in seconds
        
        Returns:
            Tuple of (is_valid, error_message)
        """
        signature = headers.get('x-webhook-signature') or headers.get('X-Webhook-Signature')
        timestamp = headers.get('x-webhook-timestamp') or headers.get('X-Webhook-Timestamp')
        
        if not signature or not timestamp:
            return False, "Missing signature or timestamp header"
        
        return self.verify(
            request_body.encode('utf-8'),
            signature,
            timestamp,
            tolerance
        )


def create_webhook_receiver(secret: str):
    """
    Create a Flask/FastAPI webhook receiver decorator
    
    Usage with FastAPI:
        from ai_agent_payments.webhooks import create_webhook_receiver
        
        verify_webhook = create_webhook_receiver(webhook_secret)
        
        @app.post("/webhook")
        @verify_webhook
        async def receive_webhook(payload: dict):
            # Webhook is verified, process it
            print(f"Received: {payload['type']}")
            return {"status": "received"}
    
    Usage with Flask:
        verify_webhook = create_webhook_receiver(webhook_secret)
        
        @app.route("/webhook", methods=["POST"])
        @verify_webhook
        def receive_webhook():
            payload = request.get_json()
            print(f"Received: {payload['type']}")
            return {"status": "received"}
    """
    verifier = WebhookVerifier(secret)
    
    def decorator(func):
        def wrapper(*args, **kwargs):
            # Try to get request from context
            try:
                # FastAPI
                from fastapi import Request
                request = kwargs.get('request') or args[0]
                if isinstance(request, Request):
                    import asyncio
                    body = asyncio.run(request.body())
                    headers = dict(request.headers)
            except:
                # Flask
                try:
                    from flask import request
                    body = request.get_data()
                    headers = dict(request.headers)
                except:
                    raise ValueError("Could not detect FastAPI or Flask request")
            
            # Verify signature
            is_valid, error = verifier.verify(
                body,
                headers.get('x-webhook-signature', ''),
                headers.get('x-webhook-timestamp', '')
            )
            
            if not is_valid:
                from fastapi import HTTPException
                raise HTTPException(status_code=401, detail=f"Invalid webhook: {error}")
            
            return func(*args, **kwargs)
        
        return wrapper
    return decorator
