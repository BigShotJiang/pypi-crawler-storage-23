# SPDX-License-Identifier: MIT
"""Fenix Mine prompt - list work items assigned to the user."""

from __future__ import annotations

from typing import Any, Dict, List

from fenix_mcp.application.prompt_base import (
    Prompt,
    PromptArgument,
    PromptMessage,
    PromptResult,
)


class FenixMinePrompt(Prompt):
    """Prompt to list work items assigned to the current user."""

    name = "mine"
    description = "List all work items assigned to me"
    arguments: List[PromptArgument] = []

    def get_messages(self, arguments: Dict[str, Any]) -> PromptResult:
        instruction = """List all work items assigned to me using the \
`mcp__fenix__knowledge` tool with `action: work_mine`.

**Instructions:**
1. Fetch my assigned work items
2. Present them in a clear, organized format (table or list)
3. Include: key, title, status, priority, and type for each item
4. Group by status if there are many items (e.g., In Progress, Pending, etc.)
5. Highlight any high-priority or urgent items"""

        return PromptResult(
            description="List work items assigned to me",
            messages=[PromptMessage(role="user", text=instruction)],
        )
