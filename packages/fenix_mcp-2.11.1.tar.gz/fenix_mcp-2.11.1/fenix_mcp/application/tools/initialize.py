# SPDX-License-Identifier: MIT
"""Initialization tool implementation."""

from __future__ import annotations

import json
from enum import Enum

from pydantic import Field

from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import Tool, ToolRequest
from fenix_mcp.domain.initialization import InitializationService
from fenix_mcp.infrastructure.context import AppContext


class InitializeAction(str, Enum):
    INIT = "init"


class InitializeRequest(ToolRequest):
    action: InitializeAction = Field(description="Initialization operation to execute.")
    include_user_docs: bool = Field(
        default=True,
        description=("Include personal documents during initialization."),
    )


class InitializeTool(Tool):
    name = "initialize"
    description = (
        "Initializes the Fenix Cloud environment or processes the personalized setup."
    )
    request_model = InitializeRequest

    def __init__(self, context: AppContext):
        self._context = context
        self._service = InitializationService(context.api_client, context.logger)

    async def run(self, payload: InitializeRequest, context: AppContext):
        if payload.action is InitializeAction.INIT:
            return await self._handle_init(payload)
        return text("❌ Unknown initialization action.")

    async def _handle_init(self, payload: InitializeRequest):
        try:
            data = await self._service.gather_data(
                include_user_docs=payload.include_user_docs,
            )
        except Exception as exc:  # pragma: no cover - defensive
            self._context.logger.error("Initialize failed: %s", exc)
            return text(
                "❌ Failed to load initialization data. "
                "Verify that the token has API access."
            )

        if (
            not data.core_documents
            and (not data.user_documents or not payload.include_user_docs)
            and not data.profile
        ):
            return text(
                "⚠️ Could not load documents or profile. Confirm the token has API access."
            )

        payload_dict = {
            "profile": data.profile,
            "core_documents": data.core_documents,
            "user_documents": data.user_documents if payload.include_user_docs else [],
            "my_work_items": [
                {
                    "id": item.get("id"),
                    "key": item.get("key"),
                    "title": item.get("title"),
                    "item_type": item.get("item_type"),
                    "status": (
                        item.get("status", {}).get("name")
                        if isinstance(item.get("status"), dict)
                        else item.get("status")
                    ),
                    "priority": item.get("priority"),
                    "due_date": item.get("due_date"),
                }
                for item in data.my_work_items
            ],
        }

        # Extract key IDs for easy reference
        profile = data.profile or {}
        user_info = profile.get("user") or {}
        tenant_info = profile.get("tenant") or {}
        team_info = profile.get("team") or {}
        teams_list: list = profile.get("teams") or []

        # Auto-set active team if user has exactly one team
        if len(teams_list) == 1:
            active = teams_list[0]
            self._context.active_team_id = active["id"]
            self._context.active_team_name = active.get("name")
            self._context.api_client.set_active_team(active["id"])
        elif len(teams_list) == 0 and team_info.get("id"):
            # Fallback to legacy team field
            self._context.active_team_id = team_info["id"]
            self._context.active_team_name = team_info.get("name")
            self._context.api_client.set_active_team(team_info["id"])

        context_lines = ["📋 **User Context**"]
        if user_info.get("id"):
            context_lines.append(f"- **user_id**: `{user_info['id']}`")
        if user_info.get("name"):
            context_lines.append(f"- **user_name**: {user_info['name']}")
        if tenant_info.get("id"):
            context_lines.append(f"- **tenant_id**: `{tenant_info['id']}`")
        if tenant_info.get("name"):
            context_lines.append(f"- **tenant_name**: {tenant_info['name']}")

        if len(teams_list) <= 1:
            # Single team or legacy — show as before
            active_team = teams_list[0] if teams_list else team_info
            if active_team.get("id"):
                context_lines.append(f"- **team_id**: `{active_team['id']}`")
            if active_team.get("name"):
                context_lines.append(f"- **team_name**: {active_team['name']}")
        else:
            # Multiple teams — show all and instruct agent to ask
            context_lines.append(
                f"- **teams**: User belongs to **{len(teams_list)} teams**:"
            )
            for t in teams_list:
                role = t.get("role", "member")
                prefix = t.get("prefix", "")
                prefix_str = f" [{prefix}]" if prefix else ""
                context_lines.append(
                    f"  - `{t['id']}` — **{t.get('name', '?')}**{prefix_str} (role: {role})"
                )

        message_lines = context_lines + [
            "",
            "📦 **Complete initialization data**",
            "```json",
            json.dumps(payload_dict, ensure_ascii=False, indent=2),
            "```",
        ]

        # Add multi-team instructions if user has multiple teams
        if len(teams_list) > 1:
            message_lines.extend(
                [
                    "",
                    "🚨 **ACTION REQUIRED: Multi-Team User — Select a team NOW**",
                    "",
                    f"This user belongs to **{len(teams_list)} teams**. "
                    "You MUST ask the user which team they want to work with **right now**, "
                    "before doing anything else. Do NOT proceed with any other task until a team is selected.",
                    "",
                    "Available teams:",
                ]
            )
            for t in teams_list:
                prefix = t.get("prefix", "")
                prefix_str = f" ({prefix})" if prefix else ""
                message_lines.append(
                    f"- **{t.get('name', '?')}**{prefix_str} — `{t['id']}`"
                )
            message_lines.extend(
                [
                    "",
                    "**Steps:**",
                    '1. Ask the user: "Which team do you want to work with?" and show them the list above.',
                    '2. Once they choose, immediately call `knowledge(action="switch_active_team", id="<team_id>")`.',
                    "3. Only then proceed with the user's original request.",
                    "",
                    "⚠️ If you skip this step, work items will be created in the wrong team.",
                ]
            )

        # Add memory usage instructions
        message_lines.extend(
            [
                "",
                "🧠 **Memory Usage Instructions**",
                "",
                "To provide continuity across sessions, use the `intelligence` tool:",
                "",
                '1. **At conversation START**: Call `intelligence(action="memory_query", query="<relevant_topic>")` to retrieve context from previous sessions',
                '2. **When learning important info**: Call `intelligence(action="memory_smart_create", ...)` to save:',
                "   - User preferences and decisions",
                "   - Project context and architecture choices",
                "   - Problems solved and solutions found",
                "   - Technical learnings and patterns",
                "",
                "This prevents users from repeating themselves and enables personalized assistance.",
            ]
        )

        return text("\n".join(message_lines))
