# SPDX-License-Identifier: MIT
"""Intelligence tool implementation (memories)."""

from __future__ import annotations

from enum import Enum
from typing import Any, List, Optional

from pydantic import Field, field_validator

from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import (
    MERMAID_HINT,
    MarkdownStr,
    TagStr,
    TitleStr,
    Tool,
    ToolRequest,
    UUIDStr,
)
from fenix_mcp.domain.intelligence import IntelligenceService
from fenix_mcp.infrastructure.context import AppContext


class IntelligenceAction(str, Enum):
    def __new__(cls, value: str, description: str):
        obj = str.__new__(cls, value)
        obj._value_ = value
        obj.description = description
        return obj

    SAVE = (
        "memory_save",
        "INTELLIGENT save with automatic deduplication using AI embeddings. "
        "If similar memory exists (>80% semantic match): UPDATES existing memory (prevents duplicates). "
        "If no match found: CREATES new memory. "
        "REQUIRED: title, content (Markdown), tags (array, min 1). "
        "OPTIONAL: documentation_item_id, work_item_id, sprint_id (link to entities). "
        "EXAMPLES of what to save: architecture decisions, solutions found, user preferences, learnings.",
    )

    SEARCH = (
        "memory_search",
        "Semantic search using AI embeddings - NOT keyword matching. "
        "CALL THIS AT CONVERSATION START to recover context from previous sessions. "
        "REQUIRED: query (natural language, e.g., 'authentication decisions', 'database choices'). "
        "OPTIONAL: limit (1-20, default 5), tags (filter). "
        "RETURNS: Memories ranked by semantic similarity with scores. "
        "EXAMPLE: 'what did we decide about the API?' finds related memories even without exact words.",
    )

    @classmethod
    def choices(cls) -> List[str]:
        return [member.value for member in cls]


ACTION_FIELD_DESCRIPTION = "Memory action to execute. " + " | ".join(
    f"`{member.value}`: {member.description.split('.')[0]}."
    for member in IntelligenceAction
)


class IntelligenceRequest(ToolRequest):
    action: IntelligenceAction = Field(description=ACTION_FIELD_DESCRIPTION)

    # For memory_save
    title: Optional[TitleStr] = Field(
        default=None, description="Memory title. REQUIRED for memory_save."
    )
    content: Optional[MarkdownStr] = Field(
        default=None,
        description=f"Memory content (Markdown supported).{MERMAID_HINT} REQUIRED for memory_save.",
    )
    tags: Optional[List[TagStr]] = Field(
        default=None,
        description='Tags for categorization. REQUIRED for memory_save. Format: JSON array, e.g.: ["tag1", "tag2"].',
        json_schema_extra={"example": ["tag1", "tag2", "tag3"]},
    )
    documentation_item_id: Optional[UUIDStr] = Field(
        default=None, description="Link memory to a documentation item (UUID)."
    )
    work_item_id: Optional[UUIDStr] = Field(
        default=None, description="Link memory to a work item (UUID)."
    )
    sprint_id: Optional[UUIDStr] = Field(
        default=None, description="Link memory to a sprint (UUID)."
    )

    # For memory_search
    query: Optional[str] = Field(
        default=None,
        description="Search query (natural language). REQUIRED for memory_search.",
    )
    limit: int = Field(
        default=5,
        ge=1,
        le=20,
        description="Maximum number of results to return. Default: 5.",
    )

    @field_validator("tags", mode="before")
    @classmethod
    def validate_tags(cls, v: Any) -> Optional[List[str]]:
        """Validate and normalize tags field."""
        if v is None or v == "":
            return None

        if isinstance(v, (list, tuple, set)):
            return [str(item).strip() for item in v if str(item).strip()]

        if isinstance(v, str):
            try:
                import json

                parsed = json.loads(v)
                if isinstance(parsed, list):
                    return [str(item).strip() for item in parsed if str(item).strip()]
            except (json.JSONDecodeError, TypeError):
                pass
            return [item.strip() for item in v.split(",") if item.strip()]

        return [str(v).strip()] if str(v).strip() else None


class IntelligenceTool(Tool):
    name = "intelligence"
    description = """Fenix INTELLIGENT memory system with semantic understanding (uses AI embeddings, not keyword matching).

**memory_search** - CALL AT CONVERSATION START
- Uses AI embeddings for semantic similarity
- "what did we decide about auth?" finds related memories even without exact keywords
- Returns ranked results with similarity scores
- BEST PRACTICE: Always search before asking user to repeat context

**memory_save** - SMART SAVE with auto-deduplication
- Automatically detects similar existing memories via embeddings
- If >80% similar memory exists: UPDATES it (prevents duplicates)
- If no match: Creates new memory
- Requires: title, content, tags (at least one)

WORKFLOW:
1. START of conversation -> memory_search for relevant context
2. User shares decision/learning -> memory_save to persist
3. Similar topic later -> memory_search finds it automatically
"""
    request_model = IntelligenceRequest

    def __init__(self, context: AppContext):
        self._context = context
        self._service = IntelligenceService(context.api_client, context.logger)

    async def run(self, payload: IntelligenceRequest, context: AppContext):
        action = payload.action

        if action is IntelligenceAction.SAVE:
            return await self._handle_save(payload)

        if action is IntelligenceAction.SEARCH:
            return await self._handle_search(payload)

        return text(
            "Invalid action. Use: "
            + ", ".join(f"`{v}`" for v in IntelligenceAction.choices())
        )

    async def _handle_save(self, payload: IntelligenceRequest):
        """Save a memory (create or update based on similarity)."""
        if not payload.title:
            return text("Provide `title` to save a memory.")

        if not payload.content:
            return text("Provide `content` to save a memory.")

        tags = payload.tags
        if not tags or len(tags) == 0:
            return text("Provide `tags` to save a memory (at least one required).")

        result = await self._service.save_memory(
            title=payload.title,
            content=payload.content,
            tags=tags,
            documentation_item_id=payload.documentation_item_id,
            work_item_id=payload.work_item_id,
            sprint_id=payload.sprint_id,
        )

        action = result.get("action", "saved")
        memory_id = result.get("memoryId", "N/A")
        title = result.get("title", payload.title)
        version = result.get("version", 1)
        similarity = result.get("similarity")

        if action == "updated":
            similarity_str = f"{similarity * 100:.0f}%" if similarity else "N/A"
            return text(
                f"Memory updated (similarity: {similarity_str})\n"
                f"ID: {memory_id}\n"
                f"Title: {title}\n"
                f"Version: {version}"
            )
        else:
            return text(f"Memory created\nID: {memory_id}\nTitle: {title}")

    async def _handle_search(self, payload: IntelligenceRequest):
        """Search memories using semantic similarity."""
        if not payload.query:
            return text("Provide `query` to search memories.")

        memories = await self._service.search_memories(
            query=payload.query,
            limit=payload.limit,
            tags=payload.tags,
        )

        if not memories:
            return text("No memories found matching your query.")

        lines = [f"Found {len(memories)} relevant memories:\n"]

        for mem in memories:
            similarity = mem.get("similarity")
            similarity_str = f" ({similarity * 100:.0f}% match)" if similarity else ""

            lines.append(f"### {mem.get('title', 'Untitled')}{similarity_str}")
            lines.append(f"ID: {mem.get('id', 'N/A')}")
            lines.append(f"Tags: {', '.join(mem.get('tags', []))}")

            content = mem.get("content", "")
            if content:
                lines.append(f"\n{content}")

            lines.append("\n---\n")

        return text("\n".join(lines))
