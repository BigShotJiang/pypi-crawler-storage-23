# SPDX-License-Identifier: MIT
"""Domain helpers for intelligence (memory) operations."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from fenix_mcp.infrastructure.fenix_api.client import FenixApiClient


@dataclass(slots=True)
class IntelligenceService:
    api: FenixApiClient
    logger: Any

    async def save_memory(
        self,
        *,
        title: str,
        content: str,
        tags: List[str],
        documentation_item_id: Optional[str] = None,
        work_item_id: Optional[str] = None,
        sprint_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Smart save memory - creates or updates based on semantic similarity.

        Required:
        - title: Memory title
        - content: Memory content
        - tags: List of tags for categorization

        Optional:
        - documentation_item_id: Related documentation
        - work_item_id: Related work item
        - sprint_id: Related sprint
        """
        if not title or not title.strip():
            raise ValueError("title is required")
        if not content or not content.strip():
            raise ValueError("content is required")
        if not tags or not isinstance(tags, list) or len(tags) == 0:
            raise ValueError("tags is required and must be a non-empty list")

        payload = {
            "title": title.strip(),
            "content": content.strip(),
            "tags": [t.strip() for t in tags if t.strip()],
        }

        if documentation_item_id:
            payload["documentationItemId"] = documentation_item_id
        if work_item_id:
            payload["workItemId"] = work_item_id
        if sprint_id:
            payload["sprintId"] = sprint_id

        return await self._call(self.api.save_memory, payload)

    async def search_memories(
        self,
        *,
        query: str,
        limit: int = 5,
        tags: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Search memories using semantic similarity (embeddings).

        Required:
        - query: Natural language search query

        Optional:
        - limit: Maximum results (default 5)
        - tags: Filter by tags
        """
        if not query or not query.strip():
            raise ValueError("query is required")

        payload = {
            "query": query.strip(),
            "limit": limit,
        }

        if tags:
            payload["tags"] = [t.strip() for t in tags if t.strip()]

        return await self._call(self.api.search_memories, payload) or []

    async def _call(self, func, *args, **kwargs):
        return await asyncio.to_thread(func, *args, **kwargs)
