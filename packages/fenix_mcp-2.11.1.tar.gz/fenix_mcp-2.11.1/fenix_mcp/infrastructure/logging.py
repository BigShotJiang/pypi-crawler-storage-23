# SPDX-License-Identifier: MIT
"""Logging configuration utilities with JSON format for Railway/cloud environments."""

from __future__ import annotations

import logging
import os
import sys
from typing import Any, Dict

from pythonjsonlogger import jsonlogger


class _SensitiveJsonFormatter(jsonlogger.JsonFormatter):
    """JSON Formatter that removes obvious tokens from logs."""

    def add_fields(
        self,
        log_record: Dict[str, Any],
        record: logging.LogRecord,
        message_dict: Dict[str, Any],
    ) -> None:
        super().add_fields(log_record, record, message_dict)

        # Add standard fields
        log_record["level"] = record.levelname.lower()
        log_record["logger"] = record.name

        # Sanitize all string values for sensitive tokens
        for key, value in list(log_record.items()):
            log_record[key] = self._sanitize(value)

    def _sanitize(self, value: Any) -> Any:
        if isinstance(value, str) and "pat_" in value:
            return value[:10] + "..." + value[-4:]
        if isinstance(value, dict):
            return {k: self._sanitize(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [self._sanitize(v) for v in value]
        return value


class _SensitiveTextFormatter(logging.Formatter):
    """Text formatter that removes obvious tokens from logs (for local dev)."""

    def format(self, record: logging.LogRecord) -> str:
        if isinstance(record.args, dict):
            record.args = self._sanitize_dict(record.args)
        elif isinstance(record.args, tuple):
            record.args = tuple(self._sanitize(value) for value in record.args)
        return super().format(record)

    def _sanitize_dict(self, data: Dict[str, Any]) -> Dict[str, Any]:
        return {key: self._sanitize(value) for key, value in data.items()}

    def _sanitize(self, value: Any) -> Any:
        if isinstance(value, str) and "pat_" in value:
            return value[:10] + "..." + value[-4:]
        return value


def configure_logging(level: str = "INFO") -> None:
    """Configure root logger with JSON format for production, text for local dev.

    Uses JSON format when RAILWAY_ENVIRONMENT or similar cloud env vars are set.
    """
    is_production = os.getenv("RAILWAY_ENVIRONMENT") or os.getenv("PRODUCTION")

    handler = logging.StreamHandler(sys.stderr)
    formatter: logging.Formatter

    if is_production:
        # JSON format for Railway and cloud environments
        formatter = _SensitiveJsonFormatter(
            fmt="%(asctime)s %(levelname)s %(name)s %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S",
        )
    else:
        # Human-readable format for local development
        formatter = _SensitiveTextFormatter(
            fmt="%(asctime)s | %(name)s | %(levelname)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

    handler.setFormatter(formatter)

    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(level)
    root.addHandler(handler)

    # Suppress noisy aiohttp access logs (Railway parses them wrong)
    logging.getLogger("aiohttp.access").setLevel(logging.WARNING)
