#include "../../TopicModel/LLDA.h"

#include "module.h"
#include "utils.h"

using namespace std;

tomoto::RawDoc::MiscType LLDAModelObject::convertMisc(const tomoto::RawDoc::MiscType& o) const
{
	tomoto::RawDoc::MiscType ret;
	ret["labels"] = getValueFromMiscDefault<vector<string>>("labels", o, "`LLDAModel` requires a `labels` value in `Iterable[str]` type.");
	return ret;
}

LLDAModelObject::LLDAModelObject(size_t tw, size_t minCnt, size_t minDf, size_t rmTop,
	size_t k, PyObject* alpha, float eta, PyObject* seed,
	PyObject* corpus, PyObject* transform)
{
	if (PyErr_WarnEx(PyExc_DeprecationWarning, "`tomotopy.LLDAModel` is deprecated. Please use `tomotopy.PLDAModel` instead.", 1)) throw py::ExcPropagation{};

	tomoto::LDAArgs mArgs;
	mArgs.k = k;
	if (alpha)
	{
		mArgs.alpha = broadcastObj<tomoto::Float>(alpha, mArgs.k,
			[&]() { return "`alpha` must be an instance of `float` or `List[float]` with length `k` (given " + py::repr(alpha) + ")"; }
		);
	}
	mArgs.eta = eta;
	if (seed && seed != Py_None && !py::toCpp<size_t>(seed, mArgs.seed))
	{
		throw py::ValueError{ "`seed` must be an integer or None." };
	}

	inst = tomoto::ILLDAModel::create((tomoto::TermWeight)tw, mArgs);
	if (!inst) throw py::ValueError{ "unknown tw value" };
	isPrepared = false;
	seedGiven = !!seed;
	minWordCnt = minCnt;
	minWordDf = minDf;
	removeTopWord = rmTop;

	insertCorpus(corpus, transform);
}

std::optional<size_t> LLDAModelObject::addDoc(PyObject* words, PyObject* labels, bool ignoreEmptyWords)
{
	if (isPrepared) throw py::RuntimeError{ "cannot add_doc() after train()" };
	auto* inst = getInst<tomoto::ILLDAModel>();
	if (PyUnicode_Check(words))
	{
		if (PyErr_WarnEx(PyExc_RuntimeWarning, "`words` should be an iterable of str.", 1)) throw py::ExcPropagation{};
	}
	tomoto::RawDoc raw = buildRawDoc(words);
	if (labels)
	{
		if (PyUnicode_Check(labels))
		{
			if (PyErr_WarnEx(PyExc_RuntimeWarning, "`labels` should be an iterable of str.", 1)) throw py::ExcPropagation{};
		}
		vector<string> labelVec;
		if (!py::toCpp(labels, labelVec))
		{
			throw py::ValueError{ "`labels` must be an iterable of str." };
		}
		raw.misc["labels"] = labelVec;
	}
	try
	{
		auto ret = inst->addDoc(raw);
		return py::buildPyValue(ret);
	}
	catch (const tomoto::exc::EmptyWordArgument&)
	{
		if (ignoreEmptyWords)
		{
			return std::nullopt;
		}
		else
		{
			throw;
		}
	}
}

py::UniqueCObj<DocumentObject> LLDAModelObject::makeDoc(PyObject* words, PyObject* labels)
{
	if (!isPrepared) throw py::RuntimeError{ "`train()` should be called before `make_doc()`." };
	auto* inst = getInst<tomoto::ILLDAModel>();
	if (PyUnicode_Check(words))
	{
		if (PyErr_WarnEx(PyExc_RuntimeWarning, "`words` should be an iterable of str.", 1)) throw py::ExcPropagation{};
	}
	tomoto::RawDoc raw = buildRawDoc(words);

	if (labels)
	{
		if (PyUnicode_Check(labels))
		{
			if (PyErr_WarnEx(PyExc_RuntimeWarning, "`labels` should be an iterable of str.", 1)) throw py::ExcPropagation{};
		}
		vector<string> labelVec;
		if (!py::toCpp(labels, labelVec))
		{
			throw py::ValueError{ "`labels` must be an iterable of str." };
		}
		raw.misc["labels"] = labelVec;
	}
	auto doc = inst->makeDoc(raw);
	py::UniqueCObj<CorpusObject> corpus{ (CorpusObject*)PyObject_CallFunctionObjArgs((PyObject*)py::Type<CorpusObject>, Py_None, getObject(), nullptr) };
	auto ret = py::makeNewObject<DocumentObject>(getDocumentCls());
	ret->corpus = corpus.copy();
	ret->doc = doc.release();
	ret->owner = true;
	return ret;
}

py::UniqueCObj<VocabObject> LLDAModelObject::getTopicLabelDict() const
{
	auto* inst = getInst<tomoto::ILLDAModel>();
	auto ret = py::makeNewObject<VocabObject>();
	ret->dep = py::UniqueObj{ getObject() };
	Py_INCREF(ret->dep);
	ret->vocabs = const_cast<tomoto::Dictionary*>(&inst->getTopicLabelDict());
	ret->size = -1;
	return ret;
}

py::UniqueObj DocumentObject::getLabels() const
{
	if (corpus->isIndependent()) throw py::AttributeError{ "doc has no `labels` field!" };
	if (!doc) throw py::RuntimeError{ "doc is null!" };

	if (auto ret = docVisit<tomoto::DocumentLLDA>(getBoundDoc(), [&](auto* doc)
	{
		auto inst = corpus->tm->getInstDynamic<tomoto::ILLDAModel>();
		auto dict = inst->getTopicLabelDict();
		vector<pair<string, vector<float>>> r;
		auto topicDist = inst->getTopicsByDoc(doc);
		for (size_t i = 0; i < dict.size(); ++i)
		{
			if (doc->labelMask[i * inst->getNumTopicsPerLabel()])
			{
				r.emplace_back(inst->getTopicLabelDict().toWord(i), 
					vector<float>{ &topicDist[i * inst->getNumTopicsPerLabel()], &topicDist[(i + 1) * inst->getNumTopicsPerLabel()] });
			}
		}
		return py::buildPyValue(r);
	})) return ret;
		
	throw py::AttributeError{ "doc has no `labels` field!" };
}
