# python-fullykiosk
Python wrapper for Fully Kiosk Browser REST interface
