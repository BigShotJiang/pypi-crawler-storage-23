triangles, xy: This is the first example in:
https://matplotlib.org/stable/gallery/images_contours_and_fields/triplot_demo.html

voronoi: 
This is the voronoi tesselation of the second example.