# Benchmark Report

**Project Name:** clawagents
**Dependency Count:** 6

## Dependencies
- openai>=1.0.0
- google-genai>=0.1.0
- fastapi>=0.100.0
- uvicorn>=0.20.0
- python-dotenv>=1.0.0
- pydantic>=2.0.0