"""Contract tests for SDK blocks.

These tests verify that blocks comply with their declared contracts per CLAUDE.md Section 8.3:
- Emit required events (metrics, progress)
- Register expected artifacts
- Return outputs matching BlockSpec
- Handle missing inputs gracefully
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import pytest
from pydantic import BaseModel

from athena import BlockContext, block

if TYPE_CHECKING:
    from .conftest import ContractTestRecorder


# =============================================================================
# Sample blocks for contract testing
# =============================================================================


class SampleTrainConfig(BaseModel):
    """Config for sample train block."""

    epochs: int = 10
    emit_metrics: bool = True


@block(
    name="SampleTrainBlock",
    description="A sample training block for contract testing",
    outputs=["model", "samples"],
    config=SampleTrainConfig,
)
async def sample_train_block(ctx: BlockContext, config: SampleTrainConfig) -> dict[str, Any]:
    """Sample block that emits metrics and produces outputs."""
    # Emit progress
    await ctx.emit_progress(0, config.epochs, message="Starting training")

    # Simulate training epochs
    for epoch in range(config.epochs):
        if config.emit_metrics:
            await ctx.emit_metric("loss", 1.0 / (epoch + 1), epoch=epoch)
            await ctx.emit_metric("accuracy", epoch * 0.1, epoch=epoch)

        await ctx.emit_progress(epoch + 1, config.epochs)

    # Produce outputs as plain dicts (harness wraps in OutputHandle internally)
    model_data = {"weights": [1.0, 2.0, 3.0], "epoch": config.epochs}
    samples_data = [[0.1, 0.2], [0.3, 0.4]]

    return {
        "model": model_data,
        "samples": samples_data,
    }


class NoOpConfig(BaseModel):
    """Config for no-op block."""

    pass


@block(name="NoOpBlock", outputs=["done"], config=NoOpConfig)
async def noop_block(
    ctx: BlockContext,  # noqa: ARG001
    config: NoOpConfig,  # noqa: ARG001
) -> dict[str, Any]:
    """Block that does nothing - for testing minimal contract."""
    return {"done": True}


class FailingConfig(BaseModel):
    """Config for failing block."""

    fail_on_epoch: int = 5


@block(name="FailingBlock", outputs=["result"], config=FailingConfig)
async def failing_block(ctx: BlockContext, config: FailingConfig) -> dict[str, Any]:
    """Block that fails mid-execution - for testing error handling."""
    for epoch in range(10):
        await ctx.emit_metric("progress", float(epoch))
        if epoch == config.fail_on_epoch:
            raise RuntimeError(f"Simulated failure at epoch {epoch}")
    return {"result": True}


# =============================================================================
# Contract tests
# =============================================================================


class TestSampleTrainBlockContract:
    """Contract tests for SampleTrainBlock."""

    @pytest.mark.asyncio
    async def test_emits_required_metrics(
        self, contract_context: BlockContext, contract_recorder: ContractTestRecorder
    ) -> None:
        """Test: block emits required metric events (loss, accuracy)."""
        config = SampleTrainConfig(epochs=3, emit_metrics=True)

        await sample_train_block(contract_context, config)

        # Verify loss and accuracy metrics were emitted
        loss_metrics = contract_recorder.get_metrics("loss")
        accuracy_metrics = contract_recorder.get_metrics("accuracy")

        assert len(loss_metrics) == config.epochs, (
            f"Expected {config.epochs} loss metrics, got {len(loss_metrics)}"
        )
        assert len(accuracy_metrics) == config.epochs, (
            f"Expected {config.epochs} accuracy metrics, got {len(accuracy_metrics)}"
        )

    @pytest.mark.asyncio
    async def test_emits_progress_events(
        self, contract_context: BlockContext, contract_recorder: ContractTestRecorder
    ) -> None:
        """Test: block emits progress events from 0 to epochs."""
        config = SampleTrainConfig(epochs=3, emit_metrics=False)

        await sample_train_block(contract_context, config)

        # Should have epochs+1 progress events (0, 1, 2, 3 for 3 epochs)
        progress_events = [e for e in contract_recorder.events if e.event_type == "progress"]
        assert len(progress_events) == config.epochs + 1, (
            f"Expected {config.epochs + 1} progress events, got {len(progress_events)}"
        )

        # Verify first and last
        assert progress_events[0].payload["current"] == 0
        assert progress_events[-1].payload["current"] == config.epochs

    @pytest.mark.asyncio
    async def test_returns_declared_outputs(
        self,
        contract_context: BlockContext,
        contract_recorder: ContractTestRecorder,  # noqa: ARG002
    ) -> None:
        """Test: block returns all outputs declared in @block decorator."""
        config = SampleTrainConfig(epochs=1)

        result = await sample_train_block(contract_context, config)

        # Block declares outputs=["model", "samples"]
        expected_outputs = {"model", "samples"}
        assert set(result.keys()) == expected_outputs, (
            f"Expected outputs {expected_outputs}, got {set(result.keys())}"
        )

    @pytest.mark.asyncio
    async def test_outputs_have_data(
        self,
        contract_context: BlockContext,
        contract_recorder: ContractTestRecorder,  # noqa: ARG002
    ) -> None:
        """Test: block outputs contain actual data (non-None values)."""
        config = SampleTrainConfig(epochs=1)

        result = await sample_train_block(contract_context, config)

        for name, value in result.items():
            assert value is not None, f"Output {name!r} is None"

    @pytest.mark.asyncio
    async def test_can_skip_metrics(
        self, contract_context: BlockContext, contract_recorder: ContractTestRecorder
    ) -> None:
        """Test: block respects emit_metrics=False config."""
        config = SampleTrainConfig(epochs=3, emit_metrics=False)

        await sample_train_block(contract_context, config)

        # Should have no loss/accuracy metrics
        loss_metrics = contract_recorder.get_metrics("loss")
        accuracy_metrics = contract_recorder.get_metrics("accuracy")

        assert len(loss_metrics) == 0, "Should not emit loss metrics when emit_metrics=False"
        assert len(accuracy_metrics) == 0, (
            "Should not emit accuracy metrics when emit_metrics=False"
        )


class TestNoOpBlockContract:
    """Contract tests for NoOpBlock (minimal contract)."""

    @pytest.mark.asyncio
    async def test_returns_declared_output(
        self,
        contract_context: BlockContext,
        contract_recorder: ContractTestRecorder,  # noqa: ARG002
    ) -> None:
        """Test: minimal block returns declared output."""
        config = NoOpConfig()

        result = await noop_block(contract_context, config)

        assert "done" in result
        assert result["done"] is True

    @pytest.mark.asyncio
    async def test_no_unexpected_events(
        self, contract_context: BlockContext, contract_recorder: ContractTestRecorder
    ) -> None:
        """Test: minimal block emits no unexpected events."""
        config = NoOpConfig()

        await noop_block(contract_context, config)

        # NoOp should emit no events
        assert len(contract_recorder.events) == 0, (
            f"NoOp block should emit no events, got {contract_recorder.events}"
        )


class TestFailingBlockContract:
    """Contract tests for error handling."""

    @pytest.mark.asyncio
    async def test_partial_metrics_on_failure(
        self, contract_context: BlockContext, contract_recorder: ContractTestRecorder
    ) -> None:
        """Test: block emits metrics before failure."""
        config = FailingConfig(fail_on_epoch=3)

        with pytest.raises(RuntimeError) as exc_info:
            await failing_block(contract_context, config)

        assert "epoch 3" in str(exc_info.value)

        # Should have emitted metrics for epochs 0, 1, 2, 3 (up to and including failure)
        metric_events = [e for e in contract_recorder.events if e.event_type == "metric"]
        assert len(metric_events) == 4, (  # 0, 1, 2, 3
            f"Expected 4 metrics before failure, got {len(metric_events)}"
        )

    @pytest.mark.asyncio
    async def test_early_failure_emits_less(
        self, contract_context: BlockContext, contract_recorder: ContractTestRecorder
    ) -> None:
        """Test: block emits fewer metrics when failing earlier."""
        config = FailingConfig(fail_on_epoch=0)

        with pytest.raises(RuntimeError):
            await failing_block(contract_context, config)

        # Should have emitted only 1 metric (for epoch 0 before failure)
        metric_events = [e for e in contract_recorder.events if e.event_type == "metric"]
        assert len(metric_events) == 1, (
            f"Expected 1 metric before early failure, got {len(metric_events)}"
        )


class TestContractTestRecorder:
    """Tests for the ContractTestRecorder itself."""

    def test_record_event(self, contract_recorder: ContractTestRecorder) -> None:
        """Test recording events."""
        contract_recorder.record_event("metric", "loss", {"value": 0.5})

        assert len(contract_recorder.events) == 1
        assert contract_recorder.events[0].event_type == "metric"
        assert contract_recorder.events[0].event_name == "loss"
        assert contract_recorder.events[0].payload == {"value": 0.5}

    def test_assert_event_emitted_success(self, contract_recorder: ContractTestRecorder) -> None:
        """Test successful event assertion."""
        contract_recorder.record_event("metric", "loss", {"value": 0.5, "epoch": 1})

        event = contract_recorder.assert_event_emitted("metric", "loss", value=0.5)

        assert event.event_name == "loss"

    def test_assert_event_emitted_failure(self, contract_recorder: ContractTestRecorder) -> None:
        """Test failed event assertion."""
        contract_recorder.record_event("metric", "loss", {"value": 0.5})

        with pytest.raises(AssertionError) as exc_info:
            contract_recorder.assert_event_emitted("metric", "accuracy")

        assert "No event found" in str(exc_info.value)

    def test_assert_metric_emitted(self, contract_recorder: ContractTestRecorder) -> None:
        """Test metric-specific assertion."""
        contract_recorder.record_event("metric", "loss", {"value": 0.25})

        event = contract_recorder.assert_metric_emitted("loss", value=0.25)

        assert event.payload["value"] == 0.25

    def test_get_metrics_filters_correctly(self, contract_recorder: ContractTestRecorder) -> None:
        """Test filtering metrics by name."""
        contract_recorder.record_event("metric", "loss", {"value": 0.1})
        contract_recorder.record_event("metric", "loss", {"value": 0.2})
        contract_recorder.record_event("metric", "accuracy", {"value": 0.9})

        loss_metrics = contract_recorder.get_metrics("loss")

        assert len(loss_metrics) == 2
        assert all(e.event_name == "loss" for e in loss_metrics)
