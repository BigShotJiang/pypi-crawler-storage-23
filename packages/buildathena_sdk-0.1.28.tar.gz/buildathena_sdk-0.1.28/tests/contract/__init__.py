"""Contract tests for SDK block compliance.

This module provides a framework for testing that blocks comply with their declared contracts:
- Emit required events (metrics, progress)
- Register expected artifacts
- Return outputs matching BlockSpec
- Handle missing inputs gracefully

Per CLAUDE.md Section 8.3: "For each block: given minimal fake inputs, it emits required events,
registers expected artifacts, returns outputs matching BlockSpec, handles missing provider/inputs cleanly"
"""
