"""Test configuration for athena-sdk."""

import os
from unittest.mock import patch

import pytest


@pytest.fixture
def mock_server_url() -> str:
    """Mock server URL for testing."""
    return "http://test-server:8000"


@pytest.fixture
def mock_auth_token() -> str:
    """Mock auth token for testing."""
    return "test-token-12345"


@pytest.fixture(autouse=True)
def set_block_api_env():
    """Set ATHENA_BLOCK_API env var for all tests."""
    with patch.dict(os.environ, {"ATHENA_BLOCK_API": "http://127.0.0.1:8002"}):
        yield
