"""Tests for the config instantiate module.

Tests the recursive instantiation of config trees including:
- Primitive passthrough
- Dict/list recursion
- ObjectSpec instantiation
- CustomObjectSpec instantiation
- Pydantic model field instantiation
- instantiate_field helper
- Deep recursion scenarios
- Error propagation
"""

from typing import Any

import pytest
from pydantic import BaseModel

from athena.config import objects
from athena.config.instantiate import instantiate, instantiate_field
from athena.config.registry import RegistryError
from athena.config.specs import CustomObjectSpec, ObjectSpec

# ============================================================================
# Test classes - simple objects for registry
# ============================================================================


class Point:
    """Simple test class with x, y coordinates."""

    def __init__(self, x: int, y: int) -> None:
        self.x = x
        self.y = y


class LogTransform:
    """Test transform that applies log."""

    def __init__(self, base: float = 10) -> None:
        self.base = base


class NormalizeTransform:
    """Test transform that normalizes."""

    def __init__(self, mean: float, std: float) -> None:
        self.mean = mean
        self.std = std


class ComposeTransform:
    """Test transform that composes multiple transforms."""

    def __init__(self, transforms: list) -> None:
        self.transforms = transforms


class SimpleDataset:
    """Test dataset."""

    def __init__(self, folder_path: str, transform: Any = None) -> None:
        self.folder_path = folder_path
        self.transform = transform


class SimpleDataLoader:
    """Test dataloader."""

    def __init__(
        self,
        dataset: Any,
        batch_size: int = 32,
        num_workers: int = 4,
        shuffle: bool = True,
    ) -> None:
        self.dataset = dataset
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.shuffle = shuffle


class FailingConstructor:
    """Test class whose constructor raises."""

    def __init__(self) -> None:
        raise ValueError("Construction failed intentionally")


# ============================================================================
# Test Pydantic models
# ============================================================================


class InnerConfig(BaseModel):
    """A simple nested config model."""

    value: int = 0
    label: str = "default"


class SpecFieldConfig(BaseModel):
    """Config model with an ObjectSpec field."""

    name: str = "test"
    spec: Any = None


class NestedModelConfig(BaseModel):
    """Config model with a nested Pydantic model field."""

    name: str = "outer"
    inner: InnerConfig = InnerConfig()


class DictFieldConfig(BaseModel):
    """Config model with a dict field."""

    name: str = "test"
    options: dict[str, Any] = {}


class ListFieldConfig(BaseModel):
    """Config model with a list field."""

    name: str = "test"
    items: list[Any] = []


class MixedConfig(BaseModel):
    """Config model with multiple field types."""

    name: str = "mixed"
    count: int = 0
    spec: Any = None
    inner: InnerConfig = InnerConfig()
    tags: list[Any] = []
    metadata: dict[str, Any] = {}


class CustomSpecFieldConfig(BaseModel):
    """Config model with a CustomObjectSpec field."""

    name: str = "test"
    custom: Any = None


# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture(autouse=True)
def setup_registry():
    """Set up test registry before each test."""
    objects.clear()

    objects.register_class("point", Point)
    objects.register_class("log", LogTransform)
    objects.register_class("normalize", NormalizeTransform)
    objects.register_class("compose", ComposeTransform)
    objects.register_class("simple_dataset", SimpleDataset)
    objects.register_class("pytorch_dataloader", SimpleDataLoader)
    objects.register_class("failing", FailingConstructor)

    yield

    objects.clear()


# ============================================================================
# TestInstantiatePrimitives
# ============================================================================


class TestInstantiatePrimitives:
    """Tests that primitive values pass through unchanged."""

    def test_none_passthrough(self) -> None:
        """None is returned as-is."""
        assert instantiate(None) is None

    def test_int_passthrough(self) -> None:
        """Integers are returned as-is."""
        result = instantiate(42)
        assert result == 42
        assert isinstance(result, int)

    def test_str_passthrough(self) -> None:
        """Strings are returned as-is."""
        result = instantiate("hello")
        assert result == "hello"

    def test_float_passthrough(self) -> None:
        """Floats are returned as-is."""
        result = instantiate(3.14)
        assert result == 3.14

    def test_bool_passthrough(self) -> None:
        """Booleans are returned as-is."""
        assert instantiate(True) is True
        assert instantiate(False) is False


# ============================================================================
# TestInstantiateDict
# ============================================================================


class TestInstantiateDict:
    """Tests that dicts are recursively instantiated."""

    def test_empty_dict(self) -> None:
        """Empty dict returns empty dict."""
        result = instantiate({})
        assert result == {}

    def test_dict_with_primitives(self) -> None:
        """Dict with primitive values passes through unchanged."""
        d = {"a": 1, "b": "hello", "c": None}
        result = instantiate(d)
        assert result == {"a": 1, "b": "hello", "c": None}

    def test_dict_with_object_spec(self) -> None:
        """Dict containing an ObjectSpec instantiates it."""
        d = {"transform": ObjectSpec(type="log", params={"base": 2})}
        result = instantiate(d)

        assert isinstance(result["transform"], LogTransform)
        assert result["transform"].base == 2

    def test_nested_dicts(self) -> None:
        """Nested dicts are recursively processed."""
        d = {
            "level1": {
                "level2": {
                    "value": 42,
                }
            }
        }
        result = instantiate(d)
        assert result == {"level1": {"level2": {"value": 42}}}

    def test_dict_mixed_values(self) -> None:
        """Dict with mixed primitive and spec values."""
        d = {
            "name": "pipeline",
            "version": 2,
            "transform": ObjectSpec(type="normalize", params={"mean": 0.5, "std": 0.1}),
            "enabled": True,
        }
        result = instantiate(d)

        assert result["name"] == "pipeline"
        assert result["version"] == 2
        assert isinstance(result["transform"], NormalizeTransform)
        assert result["transform"].mean == 0.5
        assert result["enabled"] is True


# ============================================================================
# TestInstantiateList
# ============================================================================


class TestInstantiateList:
    """Tests that lists are recursively instantiated."""

    def test_empty_list(self) -> None:
        """Empty list returns empty list."""
        result = instantiate([])
        assert result == []

    def test_list_with_primitives(self) -> None:
        """List with primitive values passes through."""
        result = instantiate([1, "two", 3.0, None, True])
        assert result == [1, "two", 3.0, None, True]

    def test_list_with_object_specs(self) -> None:
        """List containing ObjectSpecs instantiates them."""
        items = [
            ObjectSpec(type="log", params={"base": 2}),
            ObjectSpec(type="normalize", params={"mean": 0, "std": 1}),
        ]
        result = instantiate(items)

        assert len(result) == 2
        assert isinstance(result[0], LogTransform)
        assert result[0].base == 2
        assert isinstance(result[1], NormalizeTransform)
        assert result[1].mean == 0

    def test_list_mixed_types(self) -> None:
        """List with mixed primitives and specs."""
        items = [
            "header",
            ObjectSpec(type="point", params={"x": 1, "y": 2}),
            42,
        ]
        result = instantiate(items)

        assert result[0] == "header"
        assert isinstance(result[1], Point)
        assert result[1].x == 1
        assert result[2] == 42


# ============================================================================
# TestInstantiateObjectSpec
# ============================================================================


class TestInstantiateObjectSpec:
    """Tests that ObjectSpecs are instantiated via their instantiate() method."""

    def test_simple_object_spec(self) -> None:
        """Simple ObjectSpec is instantiated."""
        spec = ObjectSpec(type="point", params={"x": 10, "y": 20})
        result = instantiate(spec)

        assert isinstance(result, Point)
        assert result.x == 10
        assert result.y == 20

    def test_object_spec_with_children(self) -> None:
        """ObjectSpec with children is fully instantiated."""
        spec = ObjectSpec(
            type="simple_dataset",
            params={"folder_path": "/data"},
            children={"transform": ObjectSpec(type="log", params={"base": 2})},
        )
        result = instantiate(spec)

        assert isinstance(result, SimpleDataset)
        assert result.folder_path == "/data"
        assert isinstance(result.transform, LogTransform)
        assert result.transform.base == 2

    def test_object_spec_default_params(self) -> None:
        """ObjectSpec with no params uses class defaults."""
        spec = ObjectSpec(type="log")
        result = instantiate(spec)

        assert isinstance(result, LogTransform)
        assert result.base == 10  # default


# ============================================================================
# TestInstantiateCustomObjectSpec
# ============================================================================


class TestInstantiateCustomObjectSpec:
    """Tests that CustomObjectSpecs are instantiated via their instantiate() method."""

    def test_happy_path(self) -> None:
        """CustomObjectSpec instantiates a class from a dotted path."""
        spec = CustomObjectSpec(
            target="collections.OrderedDict",
            params={},
        )
        result = instantiate(spec)

        from collections import OrderedDict

        assert isinstance(result, OrderedDict)

    def test_with_params(self) -> None:
        """CustomObjectSpec passes params to the constructor."""
        spec = CustomObjectSpec(
            target="collections.Counter",
            params={"a": 3, "b": 1},
        )
        result = instantiate(spec)

        from collections import Counter

        assert isinstance(result, Counter)
        assert result["a"] == 3
        assert result["b"] == 1

    def test_import_error(self) -> None:
        """CustomObjectSpec with non-existent module raises ModuleNotFoundError."""
        spec = CustomObjectSpec(
            target="nonexistent_module_xyz.SomeClass",
        )
        with pytest.raises(ModuleNotFoundError):
            instantiate(spec)

    def test_attribute_error(self) -> None:
        """CustomObjectSpec with non-existent class raises AttributeError."""
        spec = CustomObjectSpec(
            target="collections.NonExistentClassName",
        )
        with pytest.raises(AttributeError):
            instantiate(spec)


# ============================================================================
# TestInstantiatePydanticModel
# ============================================================================


class TestInstantiatePydanticModel:
    """Tests that Pydantic models have their fields recursively instantiated."""

    def test_no_specs_unchanged(self) -> None:
        """Model with no spec fields returns the same instance."""
        config = InnerConfig(value=5, label="test")
        result = instantiate(config)

        # Same instance because nothing changed
        assert result is config
        assert result.value == 5
        assert result.label == "test"

    def test_spec_field_instantiated(self) -> None:
        """Model with an ObjectSpec field has it instantiated."""
        spec = ObjectSpec(type="point", params={"x": 1, "y": 2})
        config = SpecFieldConfig(name="my_config", spec=spec)
        result = instantiate(config)

        assert isinstance(result, SpecFieldConfig)
        assert result.name == "my_config"
        assert isinstance(result.spec, Point)
        assert result.spec.x == 1
        assert result.spec.y == 2

    def test_nested_models(self) -> None:
        """Nested Pydantic models are recursively processed."""
        inner = InnerConfig(value=42, label="nested")
        outer = NestedModelConfig(name="outer", inner=inner)
        result = instantiate(outer)

        # Inner has no specs, so both models should be same instances
        assert result is outer
        assert result.inner is inner

    def test_preserves_non_spec_fields(self) -> None:
        """Non-spec fields are preserved when spec fields are instantiated."""
        spec = ObjectSpec(type="log")
        config = SpecFieldConfig(name="preserved", spec=spec)
        result = instantiate(config)

        assert result.name == "preserved"
        assert isinstance(result.spec, LogTransform)

    def test_returns_new_instance_when_changed(self) -> None:
        """A new model instance is created when fields are instantiated."""
        spec = ObjectSpec(type="point", params={"x": 0, "y": 0})
        config = SpecFieldConfig(name="original", spec=spec)
        result = instantiate(config)

        # Must be a different instance because spec field changed
        assert result is not config
        assert isinstance(result, SpecFieldConfig)

    def test_same_instance_when_no_change(self) -> None:
        """Same model instance returned when no fields need instantiation."""
        config = InnerConfig(value=10, label="unchanged")
        result = instantiate(config)

        assert result is config

    def test_dict_field_containing_spec(self) -> None:
        """Dict field within a model containing a spec is instantiated."""
        spec = ObjectSpec(type="log", params={"base": 5})
        config = DictFieldConfig(
            name="with_dict",
            options={"transform": spec, "count": 3},
        )
        result = instantiate(config)

        assert isinstance(result, DictFieldConfig)
        assert isinstance(result.options["transform"], LogTransform)
        assert result.options["transform"].base == 5
        assert result.options["count"] == 3

    def test_list_field_containing_spec(self) -> None:
        """List field within a model containing specs is instantiated."""
        spec1 = ObjectSpec(type="log")
        spec2 = ObjectSpec(type="normalize", params={"mean": 0, "std": 1})
        config = ListFieldConfig(
            name="with_list",
            items=[spec1, "plain_string", spec2],
        )
        result = instantiate(config)

        assert isinstance(result, ListFieldConfig)
        assert isinstance(result.items[0], LogTransform)
        assert result.items[1] == "plain_string"
        assert isinstance(result.items[2], NormalizeTransform)


# ============================================================================
# TestInstantiateField
# ============================================================================


class TestInstantiateField:
    """Tests for the instantiate_field helper function."""

    def test_field_with_spec(self) -> None:
        """instantiate_field instantiates a spec field."""
        spec = ObjectSpec(type="point", params={"x": 5, "y": 10})
        config = SpecFieldConfig(name="test", spec=spec)
        result = instantiate_field(config, "spec")

        assert isinstance(result, Point)
        assert result.x == 5
        assert result.y == 10

    def test_field_with_primitive(self) -> None:
        """instantiate_field returns a primitive field unchanged."""
        config = InnerConfig(value=99, label="hello")
        result = instantiate_field(config, "value")

        assert result == 99

    def test_nonexistent_field_raises(self) -> None:
        """instantiate_field raises AttributeError for missing fields."""
        config = InnerConfig(value=1, label="test")
        with pytest.raises(AttributeError):
            instantiate_field(config, "nonexistent_field")

    def test_field_with_custom_object_spec(self) -> None:
        """instantiate_field instantiates a CustomObjectSpec field."""
        spec = CustomObjectSpec(
            target="collections.Counter",
            params={"x": 5},
        )
        config = CustomSpecFieldConfig(name="custom_test", custom=spec)
        result = instantiate_field(config, "custom")

        from collections import Counter

        assert isinstance(result, Counter)
        assert result["x"] == 5


# ============================================================================
# TestInstantiateDeepRecursion
# ============================================================================


class TestInstantiateDeepRecursion:
    """Tests for deeply nested config trees."""

    def test_dict_nested_5_levels_with_spec(self) -> None:
        """A spec buried 5 dict levels deep is still instantiated."""
        spec = ObjectSpec(type="point", params={"x": 1, "y": 2})
        nested = {
            "l1": {
                "l2": {
                    "l3": {
                        "l4": {
                            "l5": spec,
                        }
                    }
                }
            }
        }
        result = instantiate(nested)

        point = result["l1"]["l2"]["l3"]["l4"]["l5"]
        assert isinstance(point, Point)
        assert point.x == 1

    def test_mixed_dict_list_nesting(self) -> None:
        """Specs nested inside alternating dict/list layers are instantiated."""
        data = {
            "transforms": [
                {
                    "primary": ObjectSpec(type="log", params={"base": 2}),
                    "fallback": ObjectSpec(type="normalize", params={"mean": 0, "std": 1}),
                },
                [
                    ObjectSpec(type="point", params={"x": 3, "y": 4}),
                ],
            ]
        }
        result = instantiate(data)

        assert isinstance(result["transforms"][0]["primary"], LogTransform)
        assert result["transforms"][0]["primary"].base == 2
        assert isinstance(result["transforms"][0]["fallback"], NormalizeTransform)
        assert isinstance(result["transforms"][1][0], Point)
        assert result["transforms"][1][0].x == 3

    def test_model_inside_dict_inside_list(self) -> None:
        """A Pydantic model inside a dict inside a list is processed."""
        spec = ObjectSpec(type="log", params={"base": 7})
        config = SpecFieldConfig(name="deep", spec=spec)
        data = [{"config": config}]

        result = instantiate(data)

        inner_config = result[0]["config"]
        assert isinstance(inner_config, SpecFieldConfig)
        assert isinstance(inner_config.spec, LogTransform)
        assert inner_config.spec.base == 7


# ============================================================================
# TestInstantiateErrors
# ============================================================================


class TestInstantiateErrors:
    """Tests for error handling during instantiation."""

    def test_unregistered_type_raises(self) -> None:
        """ObjectSpec with unregistered type raises RegistryError."""
        spec = ObjectSpec(type="nonexistent_type_xyz", params={"x": 1})
        with pytest.raises(RegistryError, match="Unknown"):
            instantiate(spec)

    def test_bad_target_raises(self) -> None:
        """CustomObjectSpec with invalid target raises ImportError or AttributeError."""
        spec = CustomObjectSpec(target="os.NonExistentClassName")
        with pytest.raises(AttributeError):
            instantiate(spec)

    def test_constructor_error_propagates(self) -> None:
        """Constructor errors from the registered class propagate through."""
        spec = ObjectSpec(type="failing")
        with pytest.raises(ValueError, match="Construction failed intentionally"):
            instantiate(spec)


# ============================================================================
# Additional edge case tests
# ============================================================================


class TestInstantiateEdgeCases:
    """Additional edge cases for completeness."""

    def test_mixed_config_model(self) -> None:
        """Model with multiple field types is correctly instantiated."""
        config = MixedConfig(
            name="full",
            count=5,
            spec=ObjectSpec(type="point", params={"x": 1, "y": 2}),
            inner=InnerConfig(value=99),
            tags=["a", ObjectSpec(type="log")],
            metadata={"key": ObjectSpec(type="normalize", params={"mean": 0, "std": 1})},
        )
        result = instantiate(config)

        assert isinstance(result, MixedConfig)
        assert result.name == "full"
        assert result.count == 5
        assert isinstance(result.spec, Point)
        assert result.spec.x == 1
        assert result.inner.value == 99
        assert result.tags[0] == "a"
        assert isinstance(result.tags[1], LogTransform)
        assert isinstance(result.metadata["key"], NormalizeTransform)

    def test_object_spec_inside_custom_object_spec_params(self) -> None:
        """CustomObjectSpec does not recursively instantiate its params.

        CustomObjectSpec passes params as-is to the target constructor,
        so an ObjectSpec in params remains an ObjectSpec (not instantiated).
        This is by design -- CustomObjectSpec is an escape hatch.
        """
        inner_spec = ObjectSpec(type="point", params={"x": 1, "y": 2})
        spec = CustomObjectSpec(
            target="collections.OrderedDict",
            params={"spec": inner_spec},
        )
        result = instantiate(spec)

        # The inner_spec is passed as-is to OrderedDict constructor
        # OrderedDict(**{"spec": ObjectSpec(...)}) stores the spec value
        from collections import OrderedDict

        assert isinstance(result, OrderedDict)

    def test_tuple_passthrough(self) -> None:
        """Tuples are treated as primitives and passed through unchanged."""
        t = (1, 2, 3)
        result = instantiate(t)
        assert result == (1, 2, 3)
        assert result is t

    def test_set_passthrough(self) -> None:
        """Sets are treated as primitives and passed through unchanged."""
        s = {1, 2, 3}
        result = instantiate(s)
        assert result == {1, 2, 3}
        assert result is s
