"""Tests for workspace scanner and discovery functionality."""

import tempfile
from pathlib import Path

from athena.discovery.scanner import (
    WorkspaceScanner,
    _load_module_from_path,
    _quick_detect_decorators,
)


class TestDecoratorDetector:
    """Tests for the AST-based decorator detector."""

    def test_detects_block_decorator(self) -> None:
        """Test detection of @block decorator."""
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False, mode="w") as f:
            f.write("""
from athena import block

@block(name="TestBlock")
def my_block(ctx):
    pass
""")
            f.flush()

            decorators, errors = _quick_detect_decorators(Path(f.name))
            assert ("my_block", "block") in decorators
            assert errors == []

    def test_detects_handler_decorator(self) -> None:
        """Test detection of @handler decorator."""
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False, mode="w") as f:
            f.write("""
from athena.handler import handler

@handler(schemes=["s3"])
async def s3_handler(storage_ref, env):
    yield b"data"
""")
            f.flush()

            decorators, errors = _quick_detect_decorators(Path(f.name))
            assert ("s3_handler", "handler") in decorators
            assert errors == []

    def test_detects_multiple_decorators(self) -> None:
        """Test detection of multiple decorated functions."""
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False, mode="w") as f:
            f.write("""
from athena import block
from athena.handler import handler

@block(name="BlockA")
def block_a(ctx):
    pass

@block(name="BlockB")
def block_b(ctx):
    pass

@handler(schemes=["gs"])
async def gcs_handler(ref, env):
    yield b""
""")
            f.flush()

            decorators, errors = _quick_detect_decorators(Path(f.name))
            assert ("block_a", "block") in decorators
            assert ("block_b", "block") in decorators
            assert ("gcs_handler", "handler") in decorators
            assert errors == []

    def test_handles_syntax_errors(self) -> None:
        """Test that syntax errors are captured."""
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False, mode="w") as f:
            f.write("def broken( <<<syntax error>>>")
            f.flush()

            decorators, errors = _quick_detect_decorators(Path(f.name))
            assert decorators == []
            assert len(errors) == 1
            assert "error" in errors[0]


class TestWorkspaceScanner:
    """Tests for the workspace scanner."""

    def test_scan_empty_workspace(self) -> None:
        """Test scanning an empty workspace."""
        with tempfile.TemporaryDirectory() as tmpdir:
            scanner = WorkspaceScanner(Path(tmpdir))
            registry = scanner.scan()

            assert registry.blocks == []
            assert registry.handlers == []
            # Compare resolved paths (handles macOS /var -> /private/var symlink)
            assert registry.workspace == str(Path(tmpdir).resolve())

    def test_scan_with_blocks(self) -> None:
        """Test scanning workspace with blocks."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a block file
            block_file = Path(tmpdir) / "my_block.py"
            block_file.write_text("""
from athena import block, BlockContext

@block(name="TestBlock", description="A test block")
async def test_block(ctx: BlockContext):
    pass
""")

            scanner = WorkspaceScanner(Path(tmpdir))
            registry = scanner.scan()

            assert len(registry.blocks) == 1
            assert registry.blocks[0].name == "TestBlock"
            assert registry.blocks[0].description == "A test block"
            assert registry.blocks[0].file_path == "my_block.py"
            assert registry.blocks[0].function_name == "test_block"

    def test_scan_with_handlers(self) -> None:
        """Test scanning workspace with handlers."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a handler file
            handler_file = Path(tmpdir) / "handlers" / "s3_handler.py"
            handler_file.parent.mkdir()
            handler_file.write_text("""
from collections.abc import AsyncIterator
from athena.handler import handler

@handler(schemes=["s3", "s3a"], name="S3Handler", description="Fetch from S3")
async def s3_fetch(storage_ref: str, env: dict) -> AsyncIterator[bytes]:
    '''Fetch data from S3.'''
    yield b"data"
""")

            scanner = WorkspaceScanner(Path(tmpdir))
            registry = scanner.scan()

            assert len(registry.handlers) == 1
            assert registry.handlers[0].name == "S3Handler"
            assert registry.handlers[0].schemes == ["s3", "s3a"]
            assert registry.handlers[0].description == "Fetch from S3"
            assert registry.handlers[0].file_path == "handlers/s3_handler.py"
            assert registry.handlers[0].function_name == "s3_fetch"

    def test_scan_with_all_types(self) -> None:
        """Test scanning workspace with blocks and handlers."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create files
            blocks_dir = Path(tmpdir) / "blocks"
            blocks_dir.mkdir()

            (blocks_dir / "train.py").write_text("""
from athena import block, BlockContext

@block(name="Train")
async def train(ctx: BlockContext):
    pass
""")

            handlers_dir = Path(tmpdir) / "handlers"
            handlers_dir.mkdir()

            (handlers_dir / "gcs.py").write_text("""
from collections.abc import AsyncIterator
from athena.handler import handler

@handler(schemes=["gs"])
async def gcs_handler(ref: str, env: dict) -> AsyncIterator[bytes]:
    '''GCS handler.'''
    yield b""
""")

            scanner = WorkspaceScanner(Path(tmpdir))
            registry = scanner.scan()

            assert len(registry.blocks) == 1
            assert registry.blocks[0].name == "Train"

            assert len(registry.handlers) == 1
            assert registry.handlers[0].name == "gcs_handler"
            assert registry.handlers[0].schemes == ["gs"]

    def test_scan_skips_venv(self) -> None:
        """Test that scanner skips .venv directories."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a block in .venv (should be skipped)
            venv_dir = Path(tmpdir) / ".venv" / "lib"
            venv_dir.mkdir(parents=True)

            (venv_dir / "ignored_block.py").write_text("""
from athena import block

@block(name="IgnoredBlock")
def ignored(ctx):
    pass
""")

            # Create a valid block
            (Path(tmpdir) / "valid_block.py").write_text("""
from athena import block, BlockContext

@block(name="ValidBlock")
async def valid(ctx: BlockContext):
    pass
""")

            scanner = WorkspaceScanner(Path(tmpdir))
            registry = scanner.scan()

            assert len(registry.blocks) == 1
            assert registry.blocks[0].name == "ValidBlock"

    def test_scan_with_scan_paths(self) -> None:
        """Test scanning only specific paths."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create blocks in different directories
            blocks_dir = Path(tmpdir) / "blocks"
            blocks_dir.mkdir()

            (blocks_dir / "included.py").write_text("""
from athena import block, BlockContext

@block(name="IncludedBlock")
async def included(ctx: BlockContext):
    pass
""")

            other_dir = Path(tmpdir) / "other"
            other_dir.mkdir()

            (other_dir / "excluded.py").write_text("""
from athena import block, BlockContext

@block(name="ExcludedBlock")
async def excluded(ctx: BlockContext):
    pass
""")

            scanner = WorkspaceScanner(Path(tmpdir), scan_paths=["blocks"])
            registry = scanner.scan()

            assert len(registry.blocks) == 1
            assert registry.blocks[0].name == "IncludedBlock"

    def test_scan_handlers_in_handlers_dir(self) -> None:
        """Test that handlers in handlers/ directory are discovered."""
        with tempfile.TemporaryDirectory() as tmpdir:
            handlers_dir = Path(tmpdir) / "handlers"
            handlers_dir.mkdir()

            # Multiple handlers in same file
            (handlers_dir / "cloud_handlers.py").write_text("""
from collections.abc import AsyncIterator
from athena.handler import handler

@handler(schemes=["s3", "s3a"])
async def s3_handler(ref: str, env: dict) -> AsyncIterator[bytes]:
    '''S3 storage handler.'''
    yield b""

@handler(schemes=["gs", "gcs"])
async def gcs_handler(ref: str, env: dict) -> AsyncIterator[bytes]:
    '''GCS storage handler.'''
    yield b""
""")

            scanner = WorkspaceScanner(Path(tmpdir))
            registry = scanner.scan()

            assert len(registry.handlers) == 2
            handler_names = {h.name for h in registry.handlers}
            assert handler_names == {"s3_handler", "gcs_handler"}

            # Verify schemes
            s3 = next(h for h in registry.handlers if h.name == "s3_handler")
            assert s3.schemes == ["s3", "s3a"]

            gcs = next(h for h in registry.handlers if h.name == "gcs_handler")
            assert gcs.schemes == ["gs", "gcs"]

    def test_scan_blocks_with_secrets(self) -> None:
        """Test scanning workspace discovers block secrets."""
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a block with secrets
            block_file = Path(tmpdir) / "api_block.py"
            block_file.write_text("""
from athena import block, BlockContext

@block(
    name="APIBlock",
    description="Block that calls external APIs",
    secrets=["OPENAI_API_KEY", "AWS_ACCESS_KEY_ID"],
)
async def api_block(ctx: BlockContext):
    pass
""")

            scanner = WorkspaceScanner(Path(tmpdir))
            registry = scanner.scan()

            assert len(registry.blocks) == 1
            assert registry.blocks[0].name == "APIBlock"
            assert registry.blocks[0].secrets == ["OPENAI_API_KEY", "AWS_ACCESS_KEY_ID"]

    def test_scan_blocks_secrets_defaults_empty(self) -> None:
        """Test that blocks without secrets have empty list."""
        with tempfile.TemporaryDirectory() as tmpdir:
            block_file = Path(tmpdir) / "simple_block.py"
            block_file.write_text("""
from athena import block, BlockContext

@block(name="SimpleBlock")
async def simple_block(ctx: BlockContext):
    pass
""")

            scanner = WorkspaceScanner(Path(tmpdir))
            registry = scanner.scan()

            assert len(registry.blocks) == 1
            assert registry.blocks[0].secrets == []


class TestTracebackCapture:
    """Tests for traceback capture in scanner (bug #2)."""

    def test_load_module_returns_traceback_on_failure(self) -> None:
        """Test that _load_module_from_path returns traceback on import failure."""
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False, mode="w") as f:
            f.write("import nonexistent_module_xyz_12345\n")
            f.flush()

            module, error, tb = _load_module_from_path(Path(f.name), "__test_mod")

            assert module is None
            assert error is not None
            assert "nonexistent_module_xyz_12345" in error
            assert tb is not None
            assert "Traceback" in tb
            assert "nonexistent_module_xyz_12345" in tb

    def test_load_module_returns_none_traceback_on_success(self) -> None:
        """Test that _load_module_from_path returns None traceback on success."""
        with tempfile.NamedTemporaryFile(suffix=".py", delete=False, mode="w") as f:
            f.write("x = 42\n")
            f.flush()

            module, error, tb = _load_module_from_path(Path(f.name), "__test_mod_ok")

            assert module is not None
            assert error is None
            assert tb is None

    def test_scan_errors_include_traceback(self) -> None:
        """Test that scan_errors include traceback for import failures."""
        with tempfile.TemporaryDirectory() as tmpdir:
            block_file = Path(tmpdir) / "broken_block.py"
            block_file.write_text("""
import nonexistent_dep_for_testing

from athena import block, BlockContext

@block(name="BrokenBlock")
async def broken_block(ctx: BlockContext):
    pass
""")

            scanner = WorkspaceScanner(Path(tmpdir))
            registry = scanner.scan()

            assert len(registry.blocks) == 0
            assert len(registry.scan_errors) == 1
            err = registry.scan_errors[0]
            assert err["file"] == "broken_block.py"
            assert "traceback" in err
            assert "Traceback" in err["traceback"]
            assert "nonexistent_dep_for_testing" in err["traceback"]
            assert "functions" in err
            assert "broken_block" in err["functions"]


class TestDuplicateBlockNames:
    """Tests for duplicate block name detection (bug #3)."""

    def test_duplicate_block_names_produce_scan_error(self) -> None:
        """Test that two blocks with the same name produce a scan error."""
        with tempfile.TemporaryDirectory() as tmpdir:
            file_a = Path(tmpdir) / "block_a.py"
            file_a.write_text("""
from athena import block, BlockContext

@block(name="Train")
async def train_a(ctx: BlockContext):
    pass
""")

            file_b = Path(tmpdir) / "block_b.py"
            file_b.write_text("""
from athena import block, BlockContext

@block(name="Train")
async def train_b(ctx: BlockContext):
    pass
""")

            scanner = WorkspaceScanner(Path(tmpdir))
            registry = scanner.scan()

            # Both blocks are still registered (blocks list is not deduplicated)
            assert len(registry.blocks) == 2

            # But a scan error is produced for the duplicate
            dup_errors = [
                e for e in registry.scan_errors if "Duplicate block name" in e.get("error", "")
            ]
            assert len(dup_errors) == 1
            assert "'Train'" in dup_errors[0]["error"]

    def test_unique_block_names_no_error(self) -> None:
        """Test that unique block names produce no duplicate error."""
        with tempfile.TemporaryDirectory() as tmpdir:
            file_a = Path(tmpdir) / "block_a.py"
            file_a.write_text("""
from athena import block, BlockContext

@block(name="TrainVAE")
async def train_vae(ctx: BlockContext):
    pass
""")

            file_b = Path(tmpdir) / "block_b.py"
            file_b.write_text("""
from athena import block, BlockContext

@block(name="TrainLDM")
async def train_ldm(ctx: BlockContext):
    pass
""")

            scanner = WorkspaceScanner(Path(tmpdir))
            registry = scanner.scan()

            assert len(registry.blocks) == 2
            dup_errors = [
                e for e in registry.scan_errors if "Duplicate block name" in e.get("error", "")
            ]
            assert len(dup_errors) == 0
