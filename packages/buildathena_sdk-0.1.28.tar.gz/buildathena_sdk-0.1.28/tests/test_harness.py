"""Tests for the harness input handling.

Verifies that the harness correctly reconstructs OutputHandles from
storage-reference dicts when passing inputs between blocks in the same run.
"""

from unittest.mock import AsyncMock, patch
from uuid import uuid4

import pytest

from athena.harness import _execute_task
from athena.output_handle import OutputHandle
from athena.storage import MemoryStorageBackend


@pytest.fixture
def memory_storage() -> MemoryStorageBackend:
    """Create an in-memory storage backend for testing."""
    return MemoryStorageBackend()


class TestHarnessStorageRefInputs:
    """Tests for harness handling of storage-reference inputs from upstream blocks."""

    @pytest.mark.asyncio
    async def test_storage_ref_input_reconstructs_output_handle(
        self, memory_storage: MemoryStorageBackend
    ) -> None:
        """Test that storage-ref inputs are reconstructed as OutputHandles with loaded data."""
        # Simulate what an upstream block does: materialize data to storage
        upstream_data = [1, 2, 3, 4, 5]
        upstream_handle = OutputHandle.from_data(
            upstream_data, name="dataset", schema_type="dataset"
        )
        content_hash = await upstream_handle.materialize(memory_storage)

        # Build the task dict as the daemon would send it
        # (storage_key + content_hash, no artifact_id)
        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {
                "dataset": {
                    "storage_key": upstream_handle.storage_key,
                    "content_hash": content_hash,
                    "schema_type": "dataset",
                    "name": "dataset",
                },
            },
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        # Create a simple block that reads the input and returns it
        captured_inputs: dict = {}

        async def fake_block(ctx):
            captured_inputs["dataset"] = ctx.inputs["dataset"]
            return {}

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with patch("athena.harness._load_block", return_value=(fake_block, None)):
            await _execute_task(AsyncMock(), "http://fake:8000", task, memory_storage)

        # The block should receive the actual data, not the raw dict
        assert captured_inputs["dataset"] == [1, 2, 3, 4, 5]

    @pytest.mark.asyncio
    async def test_storage_ref_input_without_storage_passes_handle(self) -> None:
        """Test that storage-ref inputs still create OutputHandle even without storage."""
        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {
                "dataset": {
                    "storage_key": "some/path",
                    "content_hash": "abc123",
                    "schema_type": "dataset",
                    "name": "dataset",
                },
            },
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        captured_inputs: dict = {}

        async def fake_block(ctx):
            # Without storage, the handle exists but has no data
            val = ctx.inputs["dataset"]
            captured_inputs["type"] = type(val).__name__
            captured_inputs["is_materialized"] = val.is_materialized
            return {}

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with patch("athena.harness._load_block", return_value=(fake_block, None)):
            # Pass storage=None to simulate missing storage
            await _execute_task(AsyncMock(), "http://fake:8000", task, None)

        # Should be an OutputHandle, even without loaded data
        assert captured_inputs["type"] == "OutputHandle"
        assert captured_inputs["is_materialized"] is True

    @pytest.mark.asyncio
    async def test_artifact_id_input_still_works(self) -> None:
        """Test that artifact_id inputs (ArtifactRef path) still work correctly."""
        artifact_id = uuid4()
        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {
                "ref": {
                    "artifact_id": str(artifact_id),
                    "schema_type": "model",
                    "name": "trained_model",
                },
            },
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        captured_inputs: dict = {}

        async def fake_block(ctx):
            val = ctx.inputs["ref"]
            captured_inputs["type"] = type(val).__name__
            captured_inputs["artifact_id"] = val.artifact_id
            return {}

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with patch("athena.harness._load_block", return_value=(fake_block, None)):
            await _execute_task(AsyncMock(), "http://fake:8000", task, None)

        assert captured_inputs["type"] == "ArtifactRef"
        assert captured_inputs["artifact_id"] == artifact_id

    @pytest.mark.asyncio
    async def test_plain_dict_input_passes_through(self) -> None:
        """Test that plain dicts (no artifact_id, no storage_key) pass through as-is."""
        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {
                "params": {"learning_rate": 0.01, "epochs": 100},
            },
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        captured_inputs: dict = {}

        async def fake_block(ctx):
            captured_inputs["params"] = ctx.inputs["params"]
            return {}

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with patch("athena.harness._load_block", return_value=(fake_block, None)):
            await _execute_task(AsyncMock(), "http://fake:8000", task, None)

        assert captured_inputs["params"] == {"learning_rate": 0.01, "epochs": 100}
