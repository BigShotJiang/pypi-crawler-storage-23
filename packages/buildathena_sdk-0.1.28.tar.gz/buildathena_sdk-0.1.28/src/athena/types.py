"""Type definitions for Athena SDK.

This module re-exports shared types from local generated schemas and
SDK-owned modules (StorageBackend, Handler).
"""

# Re-export shared types from local generated schemas
from athena._generated_schemas import (
    ArtifactRef,
    BlockConfig,
    BlockInput,
    BlockOutput,
    BlockSpec,
)
from athena.handler import HandlerSpec, get_handler_spec, handler
from athena.inspector_backend import (
    InspectorBackendProtocol,
    InspectorContext,
    get_inspector_backend_marker,
    inspector_backend,
    is_inspector_backend,
)
from athena.storage.protocol import StorageBackend

__all__ = [
    "ArtifactRef",
    "BlockConfig",
    "BlockInput",
    "BlockOutput",
    "BlockSpec",
    "HandlerSpec",
    "InspectorBackendProtocol",
    "InspectorContext",
    "StorageBackend",
    "get_handler_spec",
    "get_inspector_backend_marker",
    "handler",
    "inspector_backend",
    "is_inspector_backend",
]
