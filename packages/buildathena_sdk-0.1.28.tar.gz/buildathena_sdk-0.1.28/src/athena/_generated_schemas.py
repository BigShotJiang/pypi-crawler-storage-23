# AUTO-GENERATED — do not edit manually.
# Source of truth: packages/athena-common/src/athena_common/schemas.py
# Language-neutral contract: schemas/*.json
#
# Regenerate with: make generate-types

from enum import StrEnum
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class GateAction(StrEnum):
    """Actions a gate can take when fired."""

    PAUSE = "pause"
    KILL = "kill"
    NOTIFY = "notify"


class GateSource(StrEnum):
    """Source of a gate - where it was defined."""

    CONFIG = "config"  # From athena.yaml, auto-attached to runs
    RUNTIME = "runtime"  # Created via UI during a run


class ArtifactRef(BaseModel):
    """Reference to an artifact."""

    model_config = ConfigDict(frozen=True)

    artifact_id: UUID
    schema_type: str | None = None
    name: str | None = None

    def __str__(self) -> str:
        return f"ArtifactRef({self.artifact_id})"

    def __hash__(self) -> int:
        return hash((self.artifact_id, self.schema_type, self.name))


class BlockConfig(BaseModel):
    """Base class for block configuration."""

    model_config = ConfigDict(extra="allow")


class BlockInput(BaseModel):
    """Definition of a block input."""

    name: str
    type: str
    required: bool = True
    description: str | None = None


class BlockOutput(BaseModel):
    """Definition of a block output."""

    name: str
    type: str
    description: str | None = None


class BlockSpec(BaseModel):
    """Specification for a block."""

    name: str
    description: str | None = None
    inputs: list[BlockInput] = Field(default_factory=list)
    outputs: list[BlockOutput] = Field(default_factory=list)
    config_schema: dict[str, Any] | None = None
    config_path: str | None = Field(
        default=None,
        description="Path to config file, relative to workspace root (e.g., 'configs/blocks/train_vae.yaml')",
    )
    secrets: list[str] = Field(
        default_factory=list,
        description="List of required secret names resolved at runtime (e.g., ['OPENAI_API_KEY'])",
    )


class AfterStepPredicate(BaseModel):
    """Predicate that fires after a step completes."""

    model_config = ConfigDict(extra="allow")

    type: Literal["after_step"] = "after_step"
    node_id: str = Field(..., description="Node ID to wait for")
    status: str = Field(
        default="succeeded", description="Status to trigger on (succeeded, failed, any)"
    )


class MetricThresholdPredicate(BaseModel):
    """Predicate that fires when a metric crosses a threshold."""

    model_config = ConfigDict(extra="allow")

    type: Literal["metric_threshold"] = "metric_threshold"
    metric: str = Field(..., description="Metric name to monitor")
    op: Literal["<", "<=", ">", ">=", "==", "!="] = Field(..., description="Comparison operator")
    value: float = Field(..., description="Threshold value")
    node_id: str | None = Field(default=None, description="Optional node ID filter")


class MetricWindowPredicate(BaseModel):
    """Predicate that fires based on metric behavior over a window."""

    model_config = ConfigDict(extra="allow")

    type: Literal["metric_window"] = "metric_window"
    metric: str = Field(..., description="Metric name to monitor")
    window: int = Field(..., ge=2, description="Window size (number of samples)")
    reducer: Literal["slope", "mean", "min", "max", "std"] = Field(
        ..., description="Reduction function"
    )
    op: Literal["<", "<=", ">", ">=", "==", "!="] = Field(..., description="Comparison operator")
    value: float = Field(..., description="Threshold value")


class GateRefPredicate(BaseModel):
    """Predicate that references another gate's match result."""

    model_config = ConfigDict(extra="allow")

    type: Literal["gate_ref"] = "gate_ref"
    gate_id: str = Field(..., description="ID of the gate to reference")


class CompoundPredicate(BaseModel):
    """Predicate that combines multiple predicates with AND/OR logic."""

    model_config = ConfigDict(extra="allow")

    type: Literal["compound"] = "compound"
    operator: Literal["and", "or"] = Field(..., description="Logical operator")
    predicates: list["GatePredicate"] = Field(
        ..., description="Child predicates to combine", min_length=1
    )


class NotPredicate(BaseModel):
    """Predicate that negates another predicate."""

    model_config = ConfigDict(extra="allow")

    type: Literal["not"] = "not"
    when: "GatePredicate" = Field(..., description="Predicate to negate")


GatePredicate = (
    AfterStepPredicate
    | MetricThresholdPredicate
    | MetricWindowPredicate
    | GateRefPredicate
    | CompoundPredicate
    | NotPredicate
)


class GateDefinition(BaseModel):
    """Definition of a gate."""

    name: str
    description: str | None = None
    predicate: GatePredicate
    action: GateAction
    action_params: dict[str, Any] = Field(default_factory=dict)
    is_enabled: bool = True
    target_nodes: list[str] | None = Field(
        default=None,
        description="Node IDs to hold when gate fires. None = pause entire run (default).",
    )
    human_only: bool = Field(
        default=False,
        description="If True, only humans (JWT) can release held nodes; agent (MCP) cannot.",
    )


CompoundPredicate.model_rebuild()


NotPredicate.model_rebuild()
