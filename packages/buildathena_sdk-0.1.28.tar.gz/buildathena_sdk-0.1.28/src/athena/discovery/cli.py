"""CLI commands for discovery.

Provides the `athena-discover` command-line tool for scanning workspaces.
"""

import sys
from pathlib import Path

import click

from athena.discovery.scanner import scan_workspace
from athena.discovery.schemas import BlockRegistry


@click.group()
def discover() -> None:
    """Athena discovery CLI for finding blocks."""
    pass


@discover.command()
@click.option(
    "--path",
    "-p",
    default=".",
    type=click.Path(exists=True, file_okay=False, dir_okay=True),
    help="Workspace path to scan.",
)
@click.option(
    "--output",
    "-o",
    default=".athena/block_registry.json",
    type=click.Path(),
    help="Output file path for the registry JSON.",
)
@click.option(
    "--stdout",
    is_flag=True,
    help="Print output to stdout instead of file.",
)
@click.option(
    "--scan-paths",
    default=None,
    help="Comma-separated list of paths relative to workspace to scan.",
)
def blocks(path: str, output: str, stdout: bool, scan_paths: str | None) -> None:
    """Discover all @block decorated functions.

    Scans the workspace for Python files containing @block
    decorators and outputs a registry JSON file.
    """
    workspace_path = Path(path).resolve()

    click.echo(f"Scanning workspace: {workspace_path}", err=True)

    parsed_scan_paths = scan_paths.split(",") if scan_paths else None
    registry = scan_workspace(workspace_path, scan_paths=parsed_scan_paths)

    click.echo(
        f"Found {len(registry.blocks)} blocks",
        err=True,
    )

    # Output the registry
    registry_json = registry.model_dump_json(indent=2)

    if stdout:
        click.echo(registry_json)
    else:
        output_path = Path(output)
        if not output_path.is_absolute():
            output_path = workspace_path / output_path

        # Create parent directories if needed
        output_path.parent.mkdir(parents=True, exist_ok=True)

        output_path.write_text(registry_json, encoding="utf-8")
        click.echo(f"Registry written to: {output_path}", err=True)


@discover.command()
@click.option(
    "--path",
    "-p",
    default=".",
    type=click.Path(exists=True, file_okay=False, dir_okay=True),
    help="Workspace path.",
)
@click.option(
    "--registry",
    "-r",
    default=".athena/block_registry.json",
    type=click.Path(),
    help="Path to block registry JSON.",
)
def list_blocks(path: str, registry: str) -> None:
    """List discovered blocks from the registry."""
    workspace_path = Path(path).resolve()

    registry_path = Path(registry)
    if not registry_path.is_absolute():
        registry_path = workspace_path / registry_path

    if not registry_path.exists():
        click.echo(
            f"Error: Registry not found at {registry_path}. Run 'athena-discover blocks' first.",
            err=True,
        )
        sys.exit(1)

    try:
        registry_json = registry_path.read_text(encoding="utf-8")
        block_registry = BlockRegistry.model_validate_json(registry_json)
    except Exception as e:
        click.echo(f"Error: Could not load registry: {e}", err=True)
        sys.exit(1)

    click.echo("Blocks:")
    for block in block_registry.blocks:
        inputs_str = ", ".join(f"{i.name}: {i.type}" for i in block.inputs)
        outputs_str = ", ".join(f"{o.name}: {o.type}" for o in block.outputs)
        click.echo(f"  {block.name}")
        click.echo(f"    File: {block.file_path}:{block.function_name}")
        if inputs_str:
            click.echo(f"    Inputs: {inputs_str}")
        if outputs_str:
            click.echo(f"    Outputs: {outputs_str}")


def main() -> None:
    """Main entry point for the CLI."""
    discover()


if __name__ == "__main__":
    main()
