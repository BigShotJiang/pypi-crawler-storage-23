"""Pydantic models for discovery output.

These models define the JSON structure for block registry output.
"""

from typing import Any

from pydantic import BaseModel, Field


class InputSpec(BaseModel):
    """Specification for a block input."""

    name: str
    type: str
    required: bool = True


class OutputSpec(BaseModel):
    """Specification for a block output."""

    name: str
    type: str


class DiscoveredBlock(BaseModel):
    """A discovered block in the workspace."""

    name: str
    file_path: str = Field(description="Relative path to the block file")
    function_name: str = Field(description="Name of the decorated function")
    inputs: list[InputSpec] = Field(default_factory=list)
    outputs: list[OutputSpec] = Field(default_factory=list)
    config_schema: dict[str, Any] | None = None
    config_path: str | None = Field(
        default=None,
        description="Path to config file, relative to workspace root",
    )
    secrets: list[str] = Field(
        default_factory=list,
        description="List of required secret names (e.g., ['OPENAI_API_KEY'])",
    )

    description: str | None = None
    language: str = "python"


class DiscoveredHandler(BaseModel):
    """A discovered storage handler in the workspace."""

    name: str
    schemes: list[str] = Field(description="URI schemes this handler supports (e.g., ['s3', 'gs'])")
    file_path: str = Field(description="Relative path to the handler file")
    function_name: str = Field(description="Name of the decorated function")
    description: str | None = None
    language: str = "python"


class BlockRegistry(BaseModel):
    """Registry of all discovered blocks and handlers in a workspace."""

    version: str = "1.0"
    language: str = Field(description="Language of the scanner that produced this registry")
    workspace: str = Field(description="Absolute path to the workspace root")
    blocks: list[DiscoveredBlock] = Field(default_factory=list)
    handlers: list[DiscoveredHandler] = Field(default_factory=list)
    scan_errors: list[dict[str, Any]] = Field(default_factory=list)
