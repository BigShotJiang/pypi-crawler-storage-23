"""Discovery module for finding blocks in workspaces.

This module provides tools for:
- Scanning workspaces to discover @block decorated functions
- CLI commands for discovery operations
"""

from athena.discovery.scanner import WorkspaceScanner, scan_workspace
from athena.discovery.schemas import (
    BlockRegistry,
    DiscoveredBlock,
    InputSpec,
    OutputSpec,
)

__all__ = [
    # Scanner
    "WorkspaceScanner",
    "scan_workspace",
    # Schemas
    "BlockRegistry",
    "DiscoveredBlock",
    "InputSpec",
    "OutputSpec",
]
