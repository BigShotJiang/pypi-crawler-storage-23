"""ObjectSpec classes for config instantiation.

This module provides Pydantic models that represent configurable objects.
Each spec has a `type` field (registry lookup name) and can be instantiated
via the `instantiate()` method.

The module provides:
- ObjectSpec: Generic spec for any registry-backed object with children support
- CustomObjectSpec: Escape hatch for arbitrary class paths

Usage:
    from athena.config import objects, ObjectSpec

    @objects.register("point")
    class Point:
        def __init__(self, x: int, y: int):
            self.x, self.y = x, y

    spec = ObjectSpec(type="point", params={"x": 1, "y": 2})
    point = spec.instantiate()
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, ConfigDict, Field

if TYPE_CHECKING:
    from athena.config.registry import Registry


class ObjectSpec(BaseModel):
    """Generic spec for any registry-backed object.

    An ObjectSpec represents a configurable object with:
    - type: Name to look up in a registry
    - params: Parameters passed to the constructor
    - children: Named children to instantiate and pass as params

    Children are instantiated recursively before the parent, and their
    instantiated values are passed as constructor arguments.

    Example with params only:
        spec = ObjectSpec(type="point", params={"x": 1, "y": 2})
        point = spec.instantiate()

    Example with children:
        spec = ObjectSpec(
            type="pytorch_dataloader",
            params={"batch_size": 32},
            children={
                "dataset": ObjectSpec(
                    type="nc_dataset",
                    params={"folder_path": "/data"},
                )
            }
        )
        loader = spec.instantiate()

    Example with list of children (compose pattern):
        spec = ObjectSpec(
            type="compose",
            children={
                "transforms": [
                    ObjectSpec(type="log", params={"base": 10}),
                    ObjectSpec(type="normalize", params={"mean": 0.5, "std": 0.1}),
                ]
            }
        )
        transform = spec.instantiate()
    """

    model_config = ConfigDict(extra="forbid")

    type: str = Field(..., description="Registered type name")
    params: dict[str, Any] = Field(
        default_factory=dict,
        description="Parameters passed to constructor",
    )
    children: dict[str, ObjectSpec | list[ObjectSpec]] = Field(
        default_factory=dict,
        description="Named children to instantiate and pass as params",
    )

    def instantiate(self, registry: Registry | None = None) -> Any:
        """Instantiate the object using the registry.

        Args:
            registry: Optional registry override. Uses global objects registry
                     if not provided.

        Returns:
            An instance of the registered class.
        """
        if registry is None:
            from athena.config import objects

            registry = objects

        cls = registry.get(self.type)

        # Instantiate children recursively
        resolved_children: dict[str, Any] = {}
        for name, child in self.children.items():
            if isinstance(child, list):
                resolved_children[name] = [c.instantiate(registry) for c in child]
            else:
                resolved_children[name] = child.instantiate(registry)

        # Merge params + children (children become constructor args)
        all_params = {**self.params, **resolved_children}
        return cls(**all_params)


class CustomObjectSpec(BaseModel):
    """Escape hatch for arbitrary class instantiation.

    Use this when you need to instantiate a class that isn't in a registry.
    This is similar to Hydra's `_target_` pattern.

    WARNING: This bypasses the registry pattern and allows arbitrary class
    instantiation. Use sparingly and only when necessary.

    Example:
        spec = CustomObjectSpec(
            target="torch.optim.Adam",
            params={"lr": 0.001, "betas": [0.9, 0.999]},
        )
        optimizer = spec.instantiate(model.parameters())
    """

    model_config = ConfigDict(extra="forbid")

    target: str = Field(
        ...,
        description="Full class path (e.g., 'torch.optim.Adam')",
    )
    params: dict[str, Any] = Field(
        default_factory=dict,
        description="Parameters passed to the constructor",
    )

    def instantiate(self, *args: Any, **kwargs: Any) -> Any:
        """Instantiate the target class.

        Args:
            *args: Positional arguments passed before params.
            **kwargs: Keyword arguments merged with params.

        Returns:
            An instance of the target class.

        Raises:
            ImportError: If the module cannot be imported.
            AttributeError: If the class doesn't exist in the module.
        """
        # Import the class
        module_path, class_name = self.target.rsplit(".", 1)
        module = importlib.import_module(module_path)
        cls = getattr(module, class_name)

        # Merge kwargs with params (kwargs take precedence)
        merged_params = {**self.params, **kwargs}

        return cls(*args, **merged_params)
