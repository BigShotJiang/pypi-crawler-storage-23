"""YAML Gate DSL loading for Athena.

Usage:
    from athena.config.gates import load_gate, load_gates_from_dir

    gate = load_gate(Path("gates/pause_after_vae.yaml"))
    gates = load_gates_from_dir(Path("gates/"))
"""

from pathlib import Path

from athena._generated_schemas import (
    AfterStepPredicate,
    CompoundPredicate,
    GateAction,
    GateDefinition,
    GatePredicate,
    GateRefPredicate,
    MetricThresholdPredicate,
    MetricWindowPredicate,
    NotPredicate,
)
from athena.config.loader import ConfigLoadError, load_yaml


class GateLoadError(ConfigLoadError):
    """Error raised when gate loading fails."""

    pass


def load_gate(path: Path) -> GateDefinition:
    """Load a gate definition from a YAML file.

    Args:
        path: Path to the YAML file containing the gate definition.

    Returns:
        A GateDefinition instance.

    Raises:
        GateLoadError: If the file cannot be read or the gate is invalid.
    """
    raw = load_yaml(path)
    return parse_gate_dict(raw, source=str(path))


def parse_gate_dict(data: dict, source: str = "<dict>") -> GateDefinition:
    """Parse a gate definition from a dictionary.

    Args:
        data: Dictionary containing gate definition.
        source: Source identifier for error messages.

    Returns:
        A GateDefinition instance.

    Raises:
        GateLoadError: If the gate definition is invalid.
    """
    predicate_data = data.get("predicate")
    if predicate_data is None:
        raise GateLoadError(f"Gate in {source} missing 'predicate' field")

    predicate = _parse_predicate(predicate_data, source)

    action_str = data.get("action", "pause")
    try:
        action = GateAction(action_str)
    except ValueError:
        valid = [a.value for a in GateAction]
        raise GateLoadError(f"Invalid action '{action_str}' in {source}. Valid: {valid}")

    return GateDefinition(
        name=data.get("name", "unnamed_gate"),
        description=data.get("description"),
        predicate=predicate,
        action=action,
        action_params=data.get("action_params", {}),
        is_enabled=data.get("is_enabled", True),
    )


def _parse_predicate(predicate_data: dict, source: str, depth: int = 0) -> GatePredicate:
    """Parse a gate predicate from the 'predicate' field.

    Args:
        predicate_data: Dictionary containing the predicate definition.
        source: Source identifier for error messages.
        depth: Current nesting depth for compound predicates (max 10).

    Returns:
        A GatePredicate instance.

    Raises:
        GateLoadError: If the predicate is invalid or too deeply nested.
    """
    max_depth = 10
    if depth > max_depth:
        raise GateLoadError(f"Gate predicate in {source} exceeds max nesting depth of {max_depth}")

    pred_type = predicate_data.get("type")
    if pred_type is None:
        raise GateLoadError(f"Gate predicate in {source} missing 'type' field")

    if pred_type == "after_step":
        return AfterStepPredicate(**predicate_data)
    elif pred_type == "metric_threshold":
        return MetricThresholdPredicate(**predicate_data)
    elif pred_type == "metric_window":
        return MetricWindowPredicate(**predicate_data)
    elif pred_type == "gate_ref":
        return GateRefPredicate(**predicate_data)
    elif pred_type == "compound":
        child_predicates = predicate_data.get("predicates")
        if not child_predicates:
            raise GateLoadError(f"Compound predicate in {source} missing 'predicates' field")
        parsed_children = [
            _parse_predicate(p, f"{source}/compound[{i}]", depth + 1)
            for i, p in enumerate(child_predicates)
        ]
        return CompoundPredicate(
            type="compound",
            operator=predicate_data.get("operator", "and"),
            predicates=parsed_children,
        )
    elif pred_type == "not":
        child_predicate = predicate_data.get("when")
        if not child_predicate:
            raise GateLoadError(f"Not predicate in {source} missing 'when' field")
        parsed_child = _parse_predicate(child_predicate, f"{source}/not", depth + 1)
        return NotPredicate(type="not", when=parsed_child)
    else:
        raise GateLoadError(f"Unknown predicate type '{pred_type}' in {source}")


def load_gates_from_dir(
    directory: Path, pattern: str = "*.yaml", recursive: bool = False
) -> list[GateDefinition]:
    """Load all gate definitions from a directory.

    Args:
        directory: Directory containing gate YAML files.
        pattern: Glob pattern for matching gate files.
        recursive: If True, search subdirectories recursively.

    Returns:
        List of GateDefinition instances.

    Raises:
        GateLoadError: If the directory doesn't exist or a gate is invalid.
    """
    if not directory.is_dir():
        raise GateLoadError(f"Gate directory not found: {directory}")

    glob_pattern = f"**/{pattern}" if recursive else pattern
    return [load_gate(f) for f in sorted(directory.glob(glob_pattern)) if f.is_file()]


def load_gates_from_yaml(path: Path) -> list[GateDefinition]:
    """Load multiple gates from a single YAML file with 'gates' list.

    Args:
        path: Path to the YAML file.

    Returns:
        List of GateDefinition instances.

    Raises:
        GateLoadError: If the file cannot be read or gates are invalid.
    """
    raw = load_yaml(path)
    gates_data = raw.get("gates")
    if gates_data is None:
        # If no 'gates' list, try parsing as a single gate
        if "predicate" in raw:
            return [parse_gate_dict(raw, source=str(path))]
        raise GateLoadError(f"YAML file {path} must contain 'gates' list or be a single gate")
    return [parse_gate_dict(g, source=f"{path}[{i}]") for i, g in enumerate(gates_data)]
