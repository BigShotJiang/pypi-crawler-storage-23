<p align="center">
  <a href="https://latticeflow.ai"><img  style="max-height: 50px;" src="https://cdn.latticeflow.cloud/_aigo/assets/aigo_cover_v1.jpg" alt="LatticeFlow AI GO!">
</a>
</p>

<p>
<div align="center">
    AI GO! is a platform for AI governance operationalization developed by 

[LatticeFlow AI](https://latticeflow.ai/).
</div>

<div align="center">
</p>

[![Website](https://img.shields.io/badge/Website-LatticeFlow_AI-blue)](https://latticeflow.ai)
[![Documentation](https://img.shields.io/badge/Documentation-ReadMe-green)](https://aigo.latticeflow.io/docs)

</div>

# LatticeFlow AI GO! Python SDK

AI GO! enables organizations to mitigate AI risks and make informed decisions, by 
connecting the high-level governance and risk frameworks to deep technical AI
evaluations and their interpretation.

AI GO! CLI is distributed as a lightweight Python package that allows organizations
to automatize their AI governance processes.
