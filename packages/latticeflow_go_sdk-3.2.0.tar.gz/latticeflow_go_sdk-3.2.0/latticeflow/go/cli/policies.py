from __future__ import annotations

from pathlib import Path
from typing import Callable

import typer

import latticeflow.go.cli.utils.arguments as cli_args
import latticeflow.go.cli.utils.exceptions as cli_exc
import latticeflow.go.cli.utils.printing as cli_print
from latticeflow.go.cli.dtypes import CLICreateRunConfig
from latticeflow.go.cli.utils.helpers import dump_entity_to_yaml_file
from latticeflow.go.cli.utils.helpers import get_client_from_env
from latticeflow.go.cli.utils.helpers import load_ai_app_key
from latticeflow.go.cli.utils.run_config_processing import validate_run_config
from latticeflow.go.models import Policies
from latticeflow.go.models import PoliciesStatus
from latticeflow.go.models import PolicyRuleStatus
from latticeflow.go.models import Status


PRETTY_ENTITY_NAME = "policies"


POLICY_RULES_TABLE_COLUMNS: list[tuple[str, Callable[[PolicyRuleStatus], str]]] = [
    ("Rule Name", lambda rule_status: rule_status.display_name),
    (
        "Result",
        lambda rule_status: "[green]PASS[/green]"
        if rule_status.status == Status.PASS
        else "[red]FAIL[/red]",
    ),
    ("Explanation", lambda rule_status: rule_status.explanation),
]


def set_policies_command(
    path: Path = cli_args.single_config_path_option("run"),
    should_validate_only: bool = cli_args.should_validate_only_option,
) -> None:
    """Update policies for the AI app (replacing the existing ones)."""
    cli_print.log_preview_feature_info(feature_name="policy")
    ai_app_key = load_ai_app_key()
    client = get_client_from_env()

    if should_validate_only:
        # This validates them too
        _get_policies_from_file(path)
        return

    try:
        policies = _get_policies_from_file(path)
        ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)

        cli_print.log_info(
            f"Trying to assign the policies to the AI app with key '{ai_app_key}'."
        )
        client.policies.update_policies(ai_app.id, policies)
        policy_count = len(policies.policies)
        cli_print.log_info(
            f"Successfully assigned {policy_count} "
            f"{'policy' if policy_count == 1 else 'policies'} to AI app '{ai_app_key}'."
        )
        cli_print.log_info(
            "\nThe status of the policies can be viewed in the CLI:\n\tlf overview policies"
        )
    except Exception as error:
        raise cli_exc.CLICreateUpdateSingleEntityError(
            PRETTY_ENTITY_NAME, path
        ) from error


def export_policy_command(
    output: Path | None = cli_args.export_output_path_option,
) -> None:
    """Exports policies to a YAML file or prints them as JSON."""
    if not output:
        cli_print.suppress_logging()

    cli_print.log_preview_feature_info(feature_name="policy")

    ai_app_key = load_ai_app_key()
    client = get_client_from_env()

    try:
        ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)

        policies = client.policies.get_policies(ai_app.id)
        config = CLICreateRunConfig(policies=policies.policies)

        if output is not None:
            dump_entity_to_yaml_file(output, policies)
            cli_print.log_info(
                f"Exported policies for AI app with key '{ai_app_key}' to '{output}'."
            )
        else:
            cli_print.print_entities_as_json(config)

    except Exception as error:
        raise cli_exc.CLIExportError(
            PRETTY_ENTITY_NAME, ai_app_key, output_path=output
        ) from error


def overview_policies_command(
    key: str | None = typer.Option(
        None, "--key", help="Key of the policy to show overview for."
    ),
    is_json_output: bool = cli_args.json_flag_option,
) -> None:
    """Show an overview of policies (all or a specific one if key is provided) as JSON or in a table."""
    if is_json_output:
        cli_print.suppress_logging()

    cli_print.log_preview_feature_info(feature_name="policy")
    ai_app_key = load_ai_app_key()
    client = get_client_from_env()

    try:
        ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)

        status = client.policies.get_policies_status(ai_app.id)

        if key is not None:
            # Filter to show only the specific policy
            matching_policies = [
                policy for policy in status.policies if policy.key == key
            ]
            if len(matching_policies) == 0:
                raise cli_exc.CLIError(
                    f"No policy found with key '{key}' for AI app '{ai_app_key}'."
                )
            status = PoliciesStatus(policies=matching_policies)

        if is_json_output:
            cli_print.print_entities_as_json(status)
        else:
            _print_status_table(status)

    except Exception as error:
        raise cli_exc.CLIPoliciesStatusOverviewError(ai_app_key=ai_app_key) from error


def _print_status_table(status: PoliciesStatus) -> None:
    if len(status.policies) == 0:
        cli_print.log_info("No policies configured for this AI app.")
        return

    for policy_status in status.policies:
        num_passing_rules = sum(
            rule.status == Status.PASS for rule in policy_status.rules
        )
        num_rules = len(policy_status.rules)

        cli_print.log_info("")
        cli_print.log_info(f"Policy '{policy_status.key}':")
        cli_print.log_info(f"- Name: '{policy_status.display_name}'")
        cli_print.log_info(f"- Overview: {num_passing_rules}/{num_rules} rules passed")
        cli_print.log_info("")

        if len(policy_status.rules) > 0:
            cli_print.print_table(
                "Policy Rules", policy_status.rules, POLICY_RULES_TABLE_COLUMNS
            )
            cli_print.log_info("")
        else:
            cli_print.log_info("No rules configured for this policy.")
            cli_print.log_info("")


def _get_policies_from_run_config(config: CLICreateRunConfig) -> Policies:
    if len(config.policies) == 0:
        raise cli_exc.CLIValidationError(
            "policies",
            explanation="The `policies` section must be defined and include at least 1 policy.",
        )

    return Policies(policies=config.policies)


def _get_policies_from_file(config_file: Path) -> Policies:
    config = validate_run_config(config_file)
    return _get_policies_from_run_config(config)
