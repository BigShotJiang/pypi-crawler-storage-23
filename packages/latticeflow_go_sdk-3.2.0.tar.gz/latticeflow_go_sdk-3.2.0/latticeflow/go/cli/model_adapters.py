from __future__ import annotations

import re
from pathlib import Path
from typing import Callable

import questionary
import typer

import latticeflow.go.cli.utils.arguments as cli_args
import latticeflow.go.cli.utils.exceptions as cli_exc
import latticeflow.go.cli.utils.printing as cli_print
from latticeflow.go import Client
from latticeflow.go.cli.dtypes import CLICreateModelAdapter
from latticeflow.go.cli.utils.deprecated_group import DeprecatedGroup
from latticeflow.go.cli.utils.helpers import create_single_entity
from latticeflow.go.cli.utils.helpers import dump_entity_to_yaml_file
from latticeflow.go.cli.utils.helpers import get_client_from_env
from latticeflow.go.cli.utils.helpers import get_files_at_path
from latticeflow.go.cli.utils.helpers import is_update_payload_same_as_existing_entity
from latticeflow.go.cli.utils.helpers import load_ai_app_key
from latticeflow.go.cli.utils.helpers import register_app_callback
from latticeflow.go.cli.utils.helpers import update_single_entity
from latticeflow.go.cli.utils.schema_mappers import EntityByIdentifiersMap
from latticeflow.go.cli.utils.schema_mappers import map_model_adapter_api_to_cli_entity
from latticeflow.go.cli.utils.schema_mappers import map_model_adapter_cli_to_api_entity
from latticeflow.go.cli.utils.yaml_utils import load_yaml_recursively
from latticeflow.go.models import ModelAdapter
from latticeflow.go.models import ModelAdapterProviderId
from latticeflow.go.models import StoredModelAdapter


_MODEL_ADAPTER_PROVIDER_AND_KEY_REGEX = re.compile(
    r"^(?:(?P<provider>(?:latticeflow)[a-z0-9_-]*)/)?"
    r"(?P<model_adapter_key>[A-Za-z0-9._\-:@]+)$"
)
PRETTY_ENTITY_NAME = "model adapter"
TABLE_COLUMNS: list[tuple[str, Callable[[StoredModelAdapter], str]]] = [
    ("Key", lambda app: app.key),
    ("Name", lambda app: app.display_name),
]
model_adapter_app = typer.Typer(
    help="Model adapter commands", cls=DeprecatedGroup, deprecated=True, hidden=True
)
register_app_callback(model_adapter_app)


def list_model_adapters_command(
    is_json_output: bool = cli_args.json_flag_option,
) -> None:
    """List all model adapters as JSON or in a table. Equivalent to 'lf model-adapters'."""
    if is_json_output:
        cli_print.suppress_logging()

    ai_app_key = load_ai_app_key()
    client = get_client_from_env()
    ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)

    try:
        stored_model_adapters = client.model_adapters.get_model_adapters(
            ai_app.id
        ).model_adapters
        cli_model_adapters = [
            map_model_adapter_api_to_cli_entity(
                stored_model_adapter=stored_model_adapter
            )
            for stored_model_adapter in stored_model_adapters
        ]
        if is_json_output:
            cli_print.print_entities_as_json(cli_model_adapters)
        else:
            cli_print.print_table("Model adapters", cli_model_adapters, TABLE_COLUMNS)
    except Exception as error:
        raise cli_exc.CLIListError(PRETTY_ENTITY_NAME) from error


def add_model_adapters_command(
    path: Path | None = cli_args.glob_config_path_option(
        PRETTY_ENTITY_NAME, is_required=False
    ),
    model_adapter_provider_and_key: str
    | None = cli_args.model_adapter_provider_and_key_option,
    should_validate_only: bool = cli_args.should_validate_only_option,
) -> None:
    """Create/update model adapter(s) based on YAML configuration(s) or from a third-party provider."""
    is_provider_model_adapter = model_adapter_provider_and_key is not None
    if path is None and model_adapter_provider_and_key is None:
        is_provider_model_adapter = (
            questionary.select(
                "What type of model adapter to add:", choices=["custom", "provider"]
            ).ask()
            == "provider"
        )
    ai_app_key = load_ai_app_key()
    client = get_client_from_env()
    ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)

    model_adapters_map = EntityByIdentifiersMap(
        client.model_adapters.get_model_adapters(ai_app.id).model_adapters
    )
    if is_provider_model_adapter:
        add_model_adapter_from_provider(
            model_adapter_provider_and_key, model_adapters_map, client, ai_app.id
        )
        return

    if path is None:
        path = questionary.path(
            "Enter path to the model adapter definition YAML (tab for autocomplete):"
        ).ask()

    _add_custom_model_adapters(
        path=Path(path),
        should_validate_only=should_validate_only,
        client=client,
        ai_app_id=ai_app.id,
    )


def add_model_adapter_from_provider(
    model_adapter_provider_and_key: str | None,
    model_adapters_map: EntityByIdentifiersMap[StoredModelAdapter],
    client: Client,
    ai_app_id: str,
    verbosity: cli_print.Verbosity = "high",
) -> StoredModelAdapter:
    """Integrate a model adapter from a third-party provider (e.g. LatticeFlow)."""
    if model_adapter_provider_and_key is not None:
        selected_model_adapter = _get_provider_model_adapter_from_cli_parameter(
            model_adapter_provider_and_key, client
        )
    else:
        selected_model_adapter = _get_provider_model_adapter_interactively(client)

    if (
        existing_model_adapter := model_adapters_map.get_entity_by_key(
            selected_model_adapter.key
        )
    ) is not None:
        cli_print.log_already_integrated_info(
            PRETTY_ENTITY_NAME,
            existing_model_adapter.provider.value,
            existing_model_adapter.key.split("$")[1],
            selected_model_adapter.key,
            verbosity=verbosity,
        )
        return existing_model_adapter

    created_model_adapter = client.model_adapters.create_model_adapter(
        ai_app_id, selected_model_adapter
    )
    cli_print.log_integration_success_info(
        PRETTY_ENTITY_NAME,
        created_model_adapter.provider.value,
        created_model_adapter.key.split("$")[1],
        created_model_adapter.key,
        verbosity=verbosity,
    )
    return created_model_adapter


def _get_provider_model_adapter_from_cli_parameter(
    model_adapter_provider_and_key: str, client: Client
) -> ModelAdapter:
    if not (
        match := _MODEL_ADAPTER_PROVIDER_AND_KEY_REGEX.fullmatch(
            model_adapter_provider_and_key
        )
    ):
        raise cli_exc.CLIModelIntegrationError(
            f"Given model adapter provider and key '{model_adapter_provider_and_key}' has invalid format."
            " Must be in the format `<provider_id>/<model_adapter_key>`, where `<provider_id>` is one of: "
            + ", ".join(
                f"`{provider_id.value}`"
                for provider_id in ModelAdapterProviderId
                if provider_id != ModelAdapterProviderId.USER
            )
        )
    selected_provider_id = ModelAdapterProviderId(match.group("provider"))
    model_adapter_key = match.group("model_adapter_key")
    return get_model_adapter_by_provider_id_and_key(
        selected_provider_id, model_adapter_key, client
    )


def get_model_adapter_by_provider_id_and_key(
    provider_id: ModelAdapterProviderId, model_adapter_key: str, client: Client
) -> ModelAdapter:
    try:
        model_adapters = client.model_adapters.get_model_adapter_provider_by_id(
            provider_id.value
        ).model_adapters
    except Exception as error:
        raise cli_exc.CLIModelIntegrationError(
            f"Could not get model adapters from provider '{provider_id.value}'."
        ) from error

    if (
        matching_model_adapter := next(
            (
                model_adapter
                for model_adapter in model_adapters
                if model_adapter.key.split("$")[1] == model_adapter_key
            ),
            None,
        )
    ) is not None:
        return matching_model_adapter

    raise cli_exc.CLIModelIntegrationError(
        f"Could not get model adapter '{model_adapter_key}' from provider '{provider_id.value}'."
        " Make sure the model adapter key is correct."
    )


def _get_provider_model_adapter_interactively(client: Client) -> ModelAdapter:
    choices = [
        provider_id.value
        for provider_id in ModelAdapterProviderId
        if provider_id != ModelAdapterProviderId.USER
    ]
    if len(choices) == 1:
        selected_provider_id = ModelAdapterProviderId(choices[0])
    else:
        selected_provider_id = ModelAdapterProviderId(
            questionary.select(
                "Select the provider of the model adapter:", choices=choices
            ).ask()
        )

    try:
        model_adapters = client.model_adapters.get_model_adapter_provider_by_id(
            selected_provider_id.value
        ).model_adapters
    except Exception as error:
        raise cli_exc.CLIModelIntegrationError(
            f"Could not get model adapters from provider '{selected_provider_id.value}'."
        ) from error

    selected_model_adapter_name = questionary.autocomplete(
        "Select the model adapter to integrate (Press Tab to see all model adapters):",
        choices=[model_adapter.display_name for model_adapter in model_adapters],
        match_middle=True,
    ).ask()

    return next(
        (
            model_adapter
            for model_adapter in model_adapters
            if model_adapter.display_name == selected_model_adapter_name
        )
    )


def _add_custom_model_adapters(
    *, path: Path, should_validate_only: bool, client: Client, ai_app_id: str
) -> None:
    if not (config_files := get_files_at_path(path)):
        raise cli_exc.CLIConfigNotFoundError(PRETTY_ENTITY_NAME, path)

    if should_validate_only:
        _validate_model_adapters(config_files)
        return

    model_adapters_map = EntityByIdentifiersMap(
        client.model_adapters.get_model_adapters(ai_app_id).model_adapters
    )
    is_creating_single_entity = len(config_files) == 1
    failures = 0
    for config_file in config_files:
        try:
            cli_model_adapter = _get_cli_model_adapter_from_file(config_file)
            model_adapter = map_model_adapter_cli_to_api_entity(
                cli_model_adapter=cli_model_adapter, config_file=config_file
            )
            stored_model_adapter = model_adapters_map.get_entity_by_key(
                cli_model_adapter.key
            )
            new_stored_model_adapter = create_or_update_single_model_adapter(
                client=client,
                ai_app_id=ai_app_id,
                model_adapter=model_adapter,
                stored_model_adapter=stored_model_adapter,
            )
            model_adapters_map.update_entity(new_stored_model_adapter)
        except Exception as error:
            failures += 1
            if is_creating_single_entity:
                raise cli_exc.CLICreateUpdateSingleEntityError(
                    PRETTY_ENTITY_NAME, config_file
                ) from error
            cli_print.log_create_update_fail_error(
                PRETTY_ENTITY_NAME, config_file, error
            )
    if failures == len(config_files):
        raise cli_exc.CLICreateUpdateAllFailedError(PRETTY_ENTITY_NAME, config_file)


def delete_model_adapter_command(
    key: str = cli_args.delete_key_argument(PRETTY_ENTITY_NAME),
) -> None:
    """Delete the model adapter with the provided key."""
    ai_app_key = load_ai_app_key()
    client = get_client_from_env()
    ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)
    try:
        cli_print.log_delete_attempt_info(PRETTY_ENTITY_NAME, key)
        client.model_adapters.delete_model_adapter_by_key(ai_app=ai_app, key=key)
        cli_print.log_delete_success_info(PRETTY_ENTITY_NAME, key)
    except Exception as error:
        raise cli_exc.CLIDeleteError(PRETTY_ENTITY_NAME, key) from error


def export_model_adapter_command(
    key: str = cli_args.export_key_argument(PRETTY_ENTITY_NAME),
    output: Path | None = cli_args.export_output_path_option,
) -> None:
    """Export the model adapter with the provided key to a file or print as JSON."""
    if not output:
        cli_print.suppress_logging()

    ai_app_key = load_ai_app_key()
    client = get_client_from_env()
    ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)
    try:
        stored_model_adapter = client.model_adapters.get_model_adapter_by_key(
            ai_app=ai_app, key=key
        )
        cli_model_adapter = map_model_adapter_api_to_cli_entity(
            stored_model_adapter=stored_model_adapter
        )
        if output:
            dump_entity_to_yaml_file(output, cli_model_adapter)
            cli_print.log_export_success_info(PRETTY_ENTITY_NAME, output, key)
        else:
            cli_print.print_entities_as_json(cli_model_adapter)
    except Exception as error:
        raise cli_exc.CLIExportError(
            PRETTY_ENTITY_NAME, key, output_path=output
        ) from error


def _get_cli_model_adapter_from_file(config_file: Path) -> CLICreateModelAdapter:
    try:
        loaded_dict, _ = load_yaml_recursively(config_file)
        return CLICreateModelAdapter.model_validate(loaded_dict, ignore_extra=False)
    except Exception as error:
        raise cli_exc.CLIInvalidConfigError(
            PRETTY_ENTITY_NAME, config_file, "model-adapters"
        ) from error


def create_or_update_single_model_adapter(
    *,
    client: Client,
    ai_app_id: str,
    model_adapter: ModelAdapter,
    stored_model_adapter: StoredModelAdapter | None,
    verbosity: cli_print.Verbosity = "high",
) -> StoredModelAdapter:
    if stored_model_adapter and is_update_payload_same_as_existing_entity(
        model_adapter, stored_model_adapter
    ):
        cli_print.log_no_change_info(
            PRETTY_ENTITY_NAME, model_adapter.key, verbosity=verbosity
        )
        return stored_model_adapter
    elif stored_model_adapter:
        return update_single_model_adapter(
            client, ai_app_id, stored_model_adapter, model_adapter, verbosity
        )
    else:
        return create_single_model_adapter(client, ai_app_id, model_adapter, verbosity)


def update_single_model_adapter(
    client: Client,
    ai_app_id: str,
    stored_model_adapter: StoredModelAdapter,
    model_adapter: ModelAdapter,
    verbosity: cli_print.Verbosity,
) -> StoredModelAdapter:
    return update_single_entity(
        pretty_entity_name=PRETTY_ENTITY_NAME,
        update_fn=lambda: client.model_adapters.update_model_adapter(
            ai_app_id, stored_model_adapter.id, model_adapter
        ),
        entity_identifier_value=stored_model_adapter.key,
        verbosity=verbosity,
    )


def create_single_model_adapter(
    client: Client,
    ai_app_id: str,
    model_adapter: ModelAdapter,
    verbosity: cli_print.Verbosity,
) -> StoredModelAdapter:
    return create_single_entity(
        pretty_entity_name=PRETTY_ENTITY_NAME,
        create_fn=lambda: client.model_adapters.create_model_adapter(
            ai_app_id, model_adapter
        ),
        entity_identifier_value=model_adapter.key,
        verbosity=verbosity,
    )


def _validate_model_adapters(config_files: list[Path]) -> None:
    for config_file in config_files:
        try:
            _get_cli_model_adapter_from_file(config_file)
            cli_print.log_validation_success_info(config_file)
        except Exception as error:
            raise cli_exc.CLIValidationError(PRETTY_ENTITY_NAME) from error


def create_referenced_provider_model_adapter(
    model_adapter_key: str,
    client: Client,
    ai_app_id: str,
    verbosity: cli_print.Verbosity,
) -> StoredModelAdapter:
    key_segments = model_adapter_key.split("$")
    if len(key_segments) != 2:
        raise cli_exc.CLIConfigurationError(
            "Invalid value provided for model adapter key."
            " The key must contain the '$' character exactly once."
        )
    provider_id_as_str, adapter_key = key_segments
    try:
        provider_id = ModelAdapterProviderId(provider_id_as_str)
    except Exception:
        raise cli_exc.CLIConfigurationError(
            f"Invalid model adapter provider ID '{provider_id_as_str}'."
        )
    model_adapter = get_model_adapter_by_provider_id_and_key(
        provider_id, adapter_key, client
    )
    return create_single_model_adapter(
        client, ai_app_id, model_adapter, verbosity=verbosity
    )


#######################
# Command registrations
#######################


model_adapter_app.command("list")(list_model_adapters_command)
model_adapter_app.command("add")(add_model_adapters_command)
model_adapter_app.command("delete")(delete_model_adapter_command)
model_adapter_app.command("export")(export_model_adapter_command)
