from __future__ import annotations

from io import BytesIO
from pathlib import Path

import typer

import latticeflow.go.cli.utils.arguments as cli_args
import latticeflow.go.cli.utils.printing as cli_print
from latticeflow.go.cli.dtypes import CLICreateEvaluation
from latticeflow.go.cli.utils.env_vars import get_cli_env_vars
from latticeflow.go.cli.utils.helpers import app_callback
from latticeflow.go.cli.utils.helpers import get_client_from_env
from latticeflow.go.cli.utils.helpers import load_ai_app_key
from latticeflow.go.cli.utils.printing import summarize_exception_chain
from latticeflow.go.cli.utils.run_config_processing import add_entities_from_run_config
from latticeflow.go.cli.utils.run_config_processing import get_cli_run_config_from_file
from latticeflow.go.cli.utils.run_config_processing import validate_run_config
from latticeflow.go.cli.utils.single_commands import with_callback
from latticeflow.go.client import Client
from latticeflow.go.models import EvaluationAction
from latticeflow.go.models import StoredAIApp
from latticeflow.go.models import StoredEvaluation
from latticeflow.go.models import UploadTaskResultLogBody
from latticeflow.go.types import File


def register_run_command(app: typer.Typer) -> None:
    app.command(
        name="run",
        short_help="Create and run an evaluation and its dependencies from a run config file.",
        help=(
            "Create and run an evaluation along with its dependencies (models, model adapters, "
            "dataset generators, datasets, and tasks) as specified in a run config YAML file. "
            "You can optionally validate the configuration."
        ),
    )(with_callback(lambda: app_callback(get_cli_env_vars))(run_command))


def run_command(
    # TODO: Remove in https://app.clickup.com/t/86c861e9x
    path: Path | None = cli_args.single_config_path_argument(
        "run", is_deprecated=True, is_required=False
    ),
    path_option: Path | None = cli_args.single_config_path_option(
        "run", is_required=False
    ),
    should_validate_only: bool = cli_args.should_validate_only_option,
) -> None:
    """Create and run an evaluation along with its dependencies from a run config file."""
    # TODO: Remove in https://app.clickup.com/t/86c861e9x
    if path is not None and path_option is not None:
        raise typer.BadParameter(
            "Run config cannot be provided both as a positional argument and as an option."
            " Please use '--file' and remove the positional argument, which is deprecated."
        )

    validated_path = path or path_option
    if validated_path is None:
        raise typer.BadParameter("Missing option '--file' / '-f'.")

    run(validated_path, should_validate_only)


def run(validated_path: Path, should_validate_only: bool) -> None:
    """Create and run an evaluation along with its dependencies from a run config file."""
    if should_validate_only:
        validate_run_config(validated_path)
        return

    ai_app_key = load_ai_app_key()
    client = get_client_from_env()
    stored_ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)
    run_config, origin_info = get_cli_run_config_from_file(validated_path)

    result = add_entities_from_run_config(
        run_config=run_config,
        origin_info=origin_info,
        config_file=validated_path,
        client=client,
        stored_ai_app=stored_ai_app,
    )
    should_start_evaluation = False
    started_evaluation = False
    if (
        result.cli_evaluation is not None
        and result.created_stored_evaluation is not None
    ):
        should_start_evaluation = True
        _upload_logs_if_needed(
            client=client,
            cli_evaluation=result.cli_evaluation,
            stored_evaluation=result.created_stored_evaluation,
            config_file=validated_path,
            stored_ai_app=stored_ai_app,
        )
        started_evaluation = _start_evaluation(
            client, result.created_stored_evaluation, stored_ai_app
        )

    if (result.total_added < result.total_expected) or (
        should_start_evaluation and not started_evaluation
    ):
        raise typer.Exit(code=1)


def _upload_logs_if_needed(
    *,
    client: Client,
    cli_evaluation: CLICreateEvaluation,
    stored_evaluation: StoredEvaluation,
    config_file: Path,
    stored_ai_app: StoredAIApp,
) -> None:
    # This works because the BE guarantees that the returned task results are in the
    # same order as the order of the task specifications (at the time of the create-eval
    # API call).
    for cli_spec, task_result in zip(
        cli_evaluation.task_specifications, stored_evaluation.task_results, strict=True
    ):
        if cli_spec.task_result_log_path is None:
            continue

        log_path = Path(cli_spec.task_result_log_path)

        # Resolve relative paths relative to the run config file
        if not log_path.is_absolute():
            log_path = (config_file.parent / log_path).resolve()

        if not log_path.exists():
            cli_print.log_warning(
                f"[TaskResult(ID={task_result.id})] Log file not found at '{log_path}'. Skipping upload for task '{task_result.display_name}'."
            )
            continue

        try:
            client.task_results.upload_task_result_log(
                stored_ai_app.id,
                task_result_id=task_result.id,
                body=UploadTaskResultLogBody(
                    task_result_log=File(
                        payload=BytesIO(log_path.read_bytes()),
                        file_name="task_result_log.json",
                        mime_type="application/json",
                    )
                ),
            )
            cli_print.log_info(
                f"[TaskResult(ID={task_result.id})] Task result log uploaded successfully for task '{task_result.display_name}'."
            )
        except Exception as error:
            cli_print.log_error(
                f"[TaskResult(ID={task_result.id})] Failed to upload log for task result '{task_result.display_name}': {str(error)}"
            )


def _start_evaluation(
    client: Client, stored_evaluation: StoredEvaluation, stored_ai_app: StoredAIApp
) -> bool:
    try:
        client.evaluations.execute_action_evaluation(
            stored_ai_app.id, stored_evaluation.id, action=EvaluationAction.START
        )
        cli_print.log_info(
            f'[Evaluation(ID="{stored_evaluation.id}")] Started successfully.'
        )
        base_url = client.base_url.rstrip("/")
        cli_print.log_char_full_width("-")
        cli_print.log_info(
            f"""\
Evaluation overview available at:

{base_url}/ai-apps/{stored_ai_app.id}/evaluations

Or in the CLI using:

lf overview eval --id {stored_evaluation.id}
"""
        )

        return True
    except Exception as error:
        cli_print.log_error(
            f"Could not start evaluation with ID '{stored_evaluation.id}':"
            f"\n{summarize_exception_chain(error)}"
        )
        return False
