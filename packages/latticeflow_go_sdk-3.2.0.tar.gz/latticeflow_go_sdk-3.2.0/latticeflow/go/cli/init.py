from __future__ import annotations

import json
import os
import shutil
from enum import Enum
from pathlib import Path

import questionary
import typer

import latticeflow.go.cli.utils.exceptions as cli_exc
import latticeflow.go.cli.utils.printing as cli_print
from latticeflow.go.cli import ai_apps
from latticeflow.go.cli import run
from latticeflow.go.cli import top_level_commands
from latticeflow.go.cli.utils.env_vars import get_cli_env_vars
from latticeflow.go.cli.utils.helpers import app_callback
from latticeflow.go.cli.utils.helpers import get_client_from_env
from latticeflow.go.cli.utils.helpers import load_ai_app_key
from latticeflow.go.cli.utils.schema_mappers import EntityByIdentifiersMap
from latticeflow.go.cli.utils.single_commands import with_callback


def register_init_command(app: typer.Typer) -> None:
    app.command(
        name="init", short_help="Initialize and run a new project from a template."
    )(with_callback(lambda: app_callback(get_cli_env_vars))(_init))


class SupportedInitializationTemplates(str, Enum):
    MINIMAL = "minimal"


def _init(
    template: str | None = typer.Option(
        None,
        "--template",
        "-t",
        help="Which of the initialization templates to initialize.",
    ),
    should_not_run: bool | None = typer.Option(
        None,
        "--dry-run",
        "-dr",
        is_flag=True,
        help="If set, the initialization will just fetch the template, but not run it.",
    ),
) -> None:
    """Initialize and run a new project from a template."""
    # Interactive mode: prompt for template and dry-run
    if template is None:
        selection = questionary.select(
            "Select a template:",
            choices=[t.value for t in SupportedInitializationTemplates],
        ).ask()
        template = selection
    assert template is not None

    try:
        SupportedInitializationTemplates(template)
    except ValueError:
        supported = [e.value for e in SupportedInitializationTemplates]
        raise cli_exc.CLIConfigurationError(
            f"Template '{template}' is not supported."
            f" Supported templates: {', '.join(supported)}"
        )

    if should_not_run is None:
        dry_run_choice = questionary.confirm(
            "Do you want to run in dry-run mode (initialize but not run)?",
            default=False,
        ).ask()
        should_not_run = dry_run_choice

    template_source_path = Path(__file__).parent.parent / "data" / "init" / template
    if not template_source_path.exists():
        raise cli_exc.CLIConfigurationError(
            f"Template directory not found at '{template_source_path}'."
        )

    cli_print.log_info((template_source_path / "README.md").read_text())
    cli_print.log_char_full_width("-")

    target_dir = Path.cwd() / template
    _copy_template_files(
        template_source_path=template_source_path,
        target_dir=target_dir,
        template=template,
    )
    if should_not_run:
        return

    _check_required_env_vars(template_source_path)

    client = get_client_from_env()
    ai_apps_map = EntityByIdentifiersMap(client.ai_apps.get_ai_apps().ai_apps)

    # NOTE: AI app key must match the name of the template.
    if ai_apps_map.get_entity_by_key(template) is not None:
        cli_print.log_info(
            f"AI app with key '{template}' already exists. Using existing AI app."
        )
    else:
        ai_apps.add(path=target_dir / "ai_app.yaml", should_validate_only=False)

    try:
        ai_app_key = load_ai_app_key(should_log=False)
    except cli_exc.CLIMissingAppContextError:
        ai_app_key = None

    if ai_app_key == template:
        cli_print.log_info(
            f"AI app with key '{template}' is already in context. Skipping AI app context switch."
        )
    else:
        top_level_commands.switch(ai_app_key=template)

    run.run(validated_path=target_dir / "run.yaml", should_validate_only=False)


def _check_required_env_vars(init_folders_path: Path) -> None:
    required_env_vars_file = init_folders_path / "REQUIRED_ENV_VARS.json"
    required_env_vars = {}

    if required_env_vars_file.exists():
        with open(required_env_vars_file) as f:
            required_env_vars = json.load(f)

    for var_name, var_type_hint in required_env_vars.items():
        if not os.getenv(var_name):
            raise cli_exc.CLIConfigurationError(
                f"Required environment variable '{var_name}' of type '{var_type_hint}' is not set."
            )


def _copy_template_files(
    *, template_source_path: Path, target_dir: Path, template: str
) -> None:
    if target_dir.exists():
        cli_print.log_info(
            f"Initialization for '{template}' skipped. Project directory"
            f" '{template}' already exists at '{target_dir}'. Using existing directory."
        )
        return

    shutil.copytree(template_source_path, target_dir)
    cli_print.log_info(
        f"Initializing project for '{template}' into directory '{target_dir}'."
    )
