from __future__ import annotations

import typer

import latticeflow.go.cli.utils.arguments as cli_args
import latticeflow.go.cli.utils.exceptions as cli_exc
import latticeflow.go.cli.utils.printing as cli_print
from latticeflow.go.cli.dataset_generators import list_dataset_generators_command
from latticeflow.go.cli.datasets import list_datasets_command
from latticeflow.go.cli.evaluations import EVALUATION_TABLE_COLUMNS
from latticeflow.go.cli.evaluations import list_evaluations_command
from latticeflow.go.cli.model_adapters import list_model_adapters_command
from latticeflow.go.cli.models import list_models_command
from latticeflow.go.cli.tasks import list_tasks_command
from latticeflow.go.cli.utils.env_vars import get_cli_env_vars
from latticeflow.go.cli.utils.helpers import app_callback
from latticeflow.go.cli.utils.helpers import get_client_from_env
from latticeflow.go.cli.utils.helpers import load_ai_app_key
from latticeflow.go.models import LFBaseModel


class PrintableEntity(LFBaseModel):
    id: str | None = None
    key: str
    name: str
    entity_type: str


list_app = typer.Typer(
    help="List entities as JSON or in a table.",
    # NOTE: We want to allow `lf list` to be invoked, which should list
    # all entities in the AI app that is currently in context.
    invoke_without_command=True,
)


# NOTE: This callback is registered instead of the usual `register_app_callback`,
# because only a single callback can be registered and we want to handle the
# simple `lf list`, but also `lf list <entity>` and the `--help` flag correctly.
@list_app.callback()
def list_callback(
    ctx: typer.Context, is_json_output: bool = cli_args.json_flag_option
) -> None:
    """List entities as JSON or in a table."""
    # Call `app_callback` as we would usually do in `register_app_callback`.
    # It also handles the `--help` flag properly.
    app_callback(get_cli_env_vars)

    # If a subcommand is invoked, let it handle everything
    if ctx.invoked_subcommand is not None:
        return

    # If no subcommand, list all entities
    list_all_entities_in_ai_app(is_json_output=is_json_output)


def list_all_entities_in_ai_app(is_json_output: bool = False) -> None:
    """List all entities for an AI app currently in context."""
    if is_json_output:
        cli_print.suppress_logging()

    ai_app_key = load_ai_app_key()
    client = get_client_from_env()
    ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)

    stored_models = client.models.get_models(ai_app.id).models
    stored_model_adapters = client.model_adapters.get_model_adapters(
        ai_app.id
    ).model_adapters
    stored_datasets = client.datasets.get_datasets(ai_app.id).datasets
    stored_dataset_generators = client.dataset_generators.get_dataset_generators(
        ai_app.id
    ).dataset_generators
    stored_tasks = client.tasks.get_tasks(ai_app.id).tasks
    stored_evaluations = client.evaluations.get_evaluations(
        ai_app_id=ai_app.id
    ).evaluations

    entities: list[PrintableEntity] = []

    for model in stored_models:
        entities.append(
            PrintableEntity(key=model.key, name=model.display_name, entity_type="Model")
        )

    for adapter in stored_model_adapters:
        entities.append(
            PrintableEntity(
                key=adapter.key, name=adapter.display_name, entity_type="Model Adapter"
            )
        )

    for dataset in stored_datasets:
        entities.append(
            PrintableEntity(
                key=dataset.key, name=dataset.display_name, entity_type="Dataset"
            )
        )

    for generator in stored_dataset_generators:
        entities.append(
            PrintableEntity(
                key=generator.key,
                name=generator.display_name,
                entity_type="Dataset Generator",
            )
        )

    for task in stored_tasks:
        entities.append(
            PrintableEntity(key=task.key, name=task.display_name, entity_type="Task")
        )

    if is_json_output:
        for evaluation in stored_evaluations:
            entities.append(
                PrintableEntity(
                    id=evaluation.id,
                    key=evaluation.key,
                    name=evaluation.display_name,
                    entity_type="Evaluation",
                )
            )
        _print_entities_as_json(entities)
    else:
        _print_entities_as_table(entities, ai_app_key)
        cli_print.print_table(
            "Evaluations", stored_evaluations, EVALUATION_TABLE_COLUMNS
        )


def _print_entities_as_table(entities: list[PrintableEntity], ai_app_key: str) -> None:
    entity_type_colors = {
        "Model Adapter": "magenta",
        "Model": "cyan",
        "Dataset Generator": "yellow",
        "Dataset": "green",
        "Task": "blue",
    }

    def get_colored_entity_type(entity: PrintableEntity) -> str:
        color = entity_type_colors.get(entity.entity_type, "white")
        return f"[{color}]{entity.entity_type}[/{color}]"

    cli_print.print_table(
        f"All Entities in AI App with key '{ai_app_key}'",
        entities,
        [
            ("Key", lambda entity: entity.key),
            ("Name", lambda entity: entity.name),
            ("Entity Type", get_colored_entity_type),
        ],
    )


def _print_entities_as_json(entities: list[PrintableEntity]) -> None:
    entities_by_type: dict[str, list[dict[str, str]]] = {
        "model_adapters": [],
        "models": [],
        "dataset_generators": [],
        "datasets": [],
        "tasks": [],
        "evaluations": [],
    }

    type_mapping = {
        "Model Adapter": "model_adapters",
        "Model": "models",
        "Dataset Generator": "dataset_generators",
        "Dataset": "datasets",
        "Task": "tasks",
        "Evaluation": "evaluations",
    }

    for entity in entities:
        json_key = type_mapping.get(entity.entity_type)
        if json_key is None or json_key not in entities_by_type:
            raise cli_exc.CLIError(
                f"Unknown entity type '{entity.entity_type}'"
                f" for entity with key '{entity.key}'."
            )
        entities_by_type[json_key].append(
            {
                **({"id": entity.id} if entity.id is not None else {}),
                "key": entity.key,
                "name": entity.name,
                "entity_type": entity.entity_type,
            }
        )

    cli_print.print_json(entities_by_type)


#######################
# Command registrations
#######################

list_app.command("model")(list_models_command)
list_app.command("model-adapter")(list_model_adapters_command)
list_app.command("dataset")(list_datasets_command)
list_app.command("dataset-generator")(list_dataset_generators_command)
list_app.command("task")(list_tasks_command)
list_app.command("eval")(list_evaluations_command)
