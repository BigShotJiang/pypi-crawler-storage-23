from __future__ import annotations

import typer

from latticeflow.go.cli.dataset_generators import delete_dataset_generator_command
from latticeflow.go.cli.datasets import delete_dataset_command
from latticeflow.go.cli.evaluations import delete_evaluation_command
from latticeflow.go.cli.model_adapters import delete_model_adapter_command
from latticeflow.go.cli.models import delete_model_command
from latticeflow.go.cli.tasks import delete_task_command
from latticeflow.go.cli.utils.helpers import register_app_callback


delete_app = typer.Typer(help="Delete entities by key (or ID for evaluations).")
register_app_callback(delete_app)


#######################
# Command registrations
#######################


delete_app.command("model-adapter")(delete_model_adapter_command)
delete_app.command("model")(delete_model_command)
delete_app.command("dataset-generator")(delete_dataset_generator_command)
delete_app.command("dataset")(delete_dataset_command)
delete_app.command("task")(delete_task_command)
delete_app.command("eval")(delete_evaluation_command)
