from __future__ import annotations

from pathlib import Path

import typer

import latticeflow.go.cli.utils.arguments as cli_args
import latticeflow.go.cli.utils.exceptions as cli_exc
from latticeflow.go.cli.datasets import _get_cli_dataset_from_file
from latticeflow.go.cli.datasets import generate_dataset_preview
from latticeflow.go.cli.models import test_model_command
from latticeflow.go.cli.tasks import test_task_with_entity
from latticeflow.go.cli.utils.helpers import get_client_from_env
from latticeflow.go.cli.utils.helpers import load_ai_app_key
from latticeflow.go.cli.utils.helpers import register_app_callback
from latticeflow.go.cli.utils.run_config_processing import get_cli_run_config_from_file
from latticeflow.go.cli.utils.schema_mappers import EntityByIdentifiersMap
from latticeflow.go.cli.utils.schema_mappers import map_config_keys_to_ids
from latticeflow.go.models import EvaluatedEntityType


test_app = typer.Typer(help="Test models, dataset generation, and task specifications.")
register_app_callback(test_app)


def test_dataset_generation_from_run_or_entity_yaml_command(
    path: Path = typer.Option(
        ...,
        "--file",
        "-f",
        help="Path to a dataset YAML file or a run config YAML file.",
        callback=cli_args.check_path_not_empty,
    ),
    key: str | None = typer.Option(
        None,
        "--key",
        "-k",
        help=(
            "Key of the dataset to extract from run config."
            " Only used when `--file` points to a run config."
        ),
    ),
    num_samples: int = typer.Option(
        3,
        "--num-samples",
        "-n",
        help="The number of samples to generate. Can be at most 10.",
        min=1,
        max=10,
    ),
) -> None:
    """Preview a few samples from a generated dataset defined in a YAML file or a run config."""
    if not path.is_file():
        raise cli_exc.CLIInvalidSingleFilePathError(path)

    ai_app_key = load_ai_app_key()
    client = get_client_from_env(read_timeout=60.0)
    ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)

    # If key is provided, we treat as run config and extract dataset
    if key is not None:
        try:
            run_config, origin_info = get_cli_run_config_from_file(path)
        except Exception as error:
            raise cli_exc.CLITestConfigurationError(
                entity_name="generated dataset",
                identifier_value=key,
                additional_message=f"Failed to load run configuration from file at path '{path}'.",
            ) from error

        cli_dataset = None
        for dataset in run_config.datasets:
            if dataset.key == key:
                cli_dataset = dataset
                break

        if cli_dataset is None:
            generated_dataset_keys = [
                dataset.key
                for dataset in run_config.datasets
                if dataset.generator_specification is not None
            ]
            raise cli_exc.CLITestConfigurationError(
                entity_name="generated dataset",
                identifier_value=key,
                additional_message=(
                    f"Dataset with key '{key}' not found in run config. "
                    f"Available generated datasets: {', '.join(generated_dataset_keys) or 'none'}"
                ),
            )
    # Otherwise, we treat as dataset.yaml
    else:
        try:
            cli_dataset, origin_info = _get_cli_dataset_from_file(path)
        except Exception as error:
            raise cli_exc.CLITestConfigurationError(
                entity_name="generated dataset",
                identifier_value=None,
                additional_message=f"Failed to load generated dataset from file at path '{path}'.",
            ) from error

    generate_dataset_preview(
        cli_dataset=cli_dataset,
        origin_info=origin_info,
        num_samples=num_samples,
        source_path=path,
        ai_app=ai_app,
        client=client,
    )


def test_task_from_run_config_command(
    path: Path = cli_args.single_config_path_option("run"),
    spec_key: str = typer.Option(
        ..., "--spec-key", "-sk", help="Key of the task specification to test."
    ),
    num_samples: int = typer.Option(
        1,
        "--num-samples",
        "-n",
        help="The number of samples to test the task with.",
        min=1,
    ),
) -> None:
    """Test a task based on its specification, extracted from a run YAML file."""
    if not path.is_file():
        raise cli_exc.CLIInvalidSingleFilePathError(path)
    try:
        run_config, _ = get_cli_run_config_from_file(path)
    except Exception as error:
        raise cli_exc.CLITestConfigurationError(
            entity_name="task specification",
            identifier_value=spec_key,
            additional_message=f"Failed to load run configuration from file at path '{path}'.",
        ) from error

    ai_app_key = load_ai_app_key()
    client = get_client_from_env(read_timeout=60.0)
    ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)

    task_specs = (
        run_config.evaluation.task_specifications
        if run_config.evaluation is not None
        else []
    )
    task_spec_to_be_tested = next(
        (task_spec for task_spec in task_specs if task_spec.key == spec_key), None
    )

    if task_spec_to_be_tested is None or task_spec_to_be_tested.key is None:
        raise cli_exc.CLITestConfigurationError(
            entity_name="task specification",
            identifier_value=spec_key,
            additional_message=f"Task specification with key '{spec_key}' not found in run config.",
        )

    try:
        stored_task = client.tasks.get_task_by_key(
            ai_app=ai_app, key=task_spec_to_be_tested.task_key
        )
    except Exception as error:
        raise cli_exc.CLITestConfigurationError(
            "task", task_spec_to_be_tested.task_key
        ) from error

    model_key = None
    dataset_key = None
    if stored_task.evaluated_entity_type == EvaluatedEntityType.DATASET:
        if task_spec_to_be_tested.dataset_key is None:
            raise cli_exc.CLIInvalidArgumentsError(
                "The task is a dataset task but a `dataset_key` was not specified in the task specification."
            )
        dataset_key = task_spec_to_be_tested.dataset_key
    elif stored_task.evaluated_entity_type == EvaluatedEntityType.MODEL:
        if task_spec_to_be_tested.model_key is None:
            raise cli_exc.CLIInvalidArgumentsError(
                "The task is a model task but a `model_key` was not specified in the task specification."
            )
        model_key = task_spec_to_be_tested.model_key

    api_task_test_config = map_config_keys_to_ids(
        config_dict=task_spec_to_be_tested.task_config,
        config_spec=stored_task.config_spec,
        models_map=EntityByIdentifiersMap(client.models.get_models(ai_app.id).models),
        datasets_map=EntityByIdentifiersMap(
            client.datasets.get_datasets(ai_app.id).datasets
        ),
        config_file=path,
    )

    test_task_with_entity(
        client=client,
        ai_app=ai_app,
        stored_task=stored_task,
        task_key=task_spec_to_be_tested.task_key,
        task_config=api_task_test_config,
        model_key=model_key,
        dataset_key=dataset_key,
        num_samples=num_samples,
    )


#######################
# Command registrations
#######################


test_app.command("model")(test_model_command)
test_app.command("dataset")(test_dataset_generation_from_run_or_entity_yaml_command)
test_app.command("task")(test_task_from_run_config_command)
