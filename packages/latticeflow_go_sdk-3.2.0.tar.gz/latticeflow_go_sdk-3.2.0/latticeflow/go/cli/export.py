from __future__ import annotations

import typer

from latticeflow.go.cli.dataset_generators import export_dataset_generator_command
from latticeflow.go.cli.datasets import export_dataset_command
from latticeflow.go.cli.evaluations import download_evaluation_command
from latticeflow.go.cli.model_adapters import export_model_adapter_command
from latticeflow.go.cli.models import export_model_command
from latticeflow.go.cli.policies import export_policy_command
from latticeflow.go.cli.tasks import export_task_command
from latticeflow.go.cli.utils.helpers import register_app_callback


export_app = typer.Typer(help="Export entities or evaluation results.")
register_app_callback(export_app)


#######################
# Command registrations
#######################

export_app.command("model")(export_model_command)
export_app.command("model-adapter")(export_model_adapter_command)
export_app.command("dataset")(export_dataset_command)
export_app.command("dataset-generator")(export_dataset_generator_command)
export_app.command("task")(export_task_command)
export_app.command("eval")(download_evaluation_command)
export_app.command("policies")(export_policy_command)
