from __future__ import annotations

import typer

import latticeflow.go.cli.utils.arguments as cli_args
import latticeflow.go.cli.utils.printing as cli_print
from latticeflow.go.cli.evaluations import show_overview_of_evaluation
from latticeflow.go.cli.policies import overview_policies_command
from latticeflow.go.cli.utils.helpers import get_client_from_env
from latticeflow.go.cli.utils.helpers import load_ai_app_key
from latticeflow.go.cli.utils.helpers import register_app_callback


overview_app = typer.Typer(
    help="Show overview of entities (currently only policies and evaluations are supported)."
)
register_app_callback(overview_app)


# TODO: Simplify in https://app.clickup.com/t/86c8845tn
def overview_evaluation_command(
    evaluation_id: str = typer.Option(
        ..., "--id", help=("ID of the evaluation to show overview for.")
    ),
    is_json_output: bool = cli_args.json_flag_option,
) -> None:
    """Show overview of an evaluation with the given ID as JSON or in a table."""
    if is_json_output:
        cli_print.suppress_logging()

    ai_app_key = load_ai_app_key()
    client = get_client_from_env()
    ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)

    show_overview_of_evaluation(
        client, ai_app, evaluation_id=evaluation_id, is_json_output=is_json_output
    )


#######################
# Command registrations
#######################

overview_app.command("eval")(overview_evaluation_command)
overview_app.command("policies")(overview_policies_command)
