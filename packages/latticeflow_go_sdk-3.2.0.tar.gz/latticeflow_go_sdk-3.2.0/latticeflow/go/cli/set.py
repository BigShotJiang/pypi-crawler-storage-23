from __future__ import annotations

import typer

from latticeflow.go.cli.policies import set_policies_command
from latticeflow.go.cli.utils.helpers import register_app_callback


set_app = typer.Typer(
    help="Set entities from run config (currently only policies are supported)."
)
register_app_callback(set_app)


#######################
# Command registrations
#######################

set_app.command("policies")(set_policies_command)
