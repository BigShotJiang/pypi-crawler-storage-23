from __future__ import annotations

from typing import Any

import click
import typer.core

import latticeflow.go.cli.utils.printing as cli_print


class DeprecatedGroup(typer.core.TyperGroup):
    """A custom TyperGroup that logs a deprecation warning when invoked.
    Circumvents Click's built-in deprecation logging to allow for custom
    formatting.
    """

    def invoke(self, ctx: click.Context) -> Any:
        if self.deprecated:
            cli_print.log_warning(
                f"The '{ctx.command_path}' group of commands is deprecated and will be removed in a future release. See 'lf --help' for new commands.",
                category="deprecation",
            )
            # NOTE: We temporarily remove the `deprecated` flag to avoid Click doing
            # its deprecation logging, because we want to handle the deprecations
            # ourselves.
            self.deprecated = False
            result = super().invoke(ctx)
            self.deprecated = True
        else:
            result = super().invoke(ctx)
        return result
