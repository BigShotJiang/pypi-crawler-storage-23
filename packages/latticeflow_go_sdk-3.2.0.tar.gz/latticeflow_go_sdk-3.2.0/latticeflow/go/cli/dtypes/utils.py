from __future__ import annotations

from typing import Annotated

from pydantic import Field

from latticeflow.go.models import LFBaseModel


user_key_field = Field(
    ...,
    max_length=250,
    min_length=1,
    pattern="^[a-zA-Z0-9_\\-]+$",
    description="Unique identifier assigned to the entity in AI GO!.",
)
referenced_key_field = Field(
    ...,
    max_length=250,
    min_length=1,
    pattern="^[a-zA-Z0-9_\\-\\$]+$",
    description="Reference to an existing entity in AI GO!.",
    json_schema_extra={"lf_docs_type": "user_or_lf_key_field"},
)
optional_user_key_field = Field(
    None,
    max_length=250,
    min_length=1,
    pattern="^[a-zA-Z0-9_\\-]+$",
    description="Unique identifier assigned to the entity in AI GO!.",
)
optional_referenced_key_field = Field(
    None,
    max_length=250,
    min_length=1,
    pattern="^[a-zA-Z0-9_\\-\\$]+$",
    description="Reference to an existing entity in AI GO!.",
)


class UserKey(LFBaseModel):
    key: str = user_key_field


class ReferencedKey(LFBaseModel):
    key: str = referenced_key_field


TemplateValue = Annotated[
    str,
    Field(
        ...,
        description="A string value that can reference configuration values using `<<config.my_param>>`.",
        json_schema_extra={"lf_docs_type": "template_value"},
    ),
]

ReferencedKeyField = Annotated[str, referenced_key_field]
