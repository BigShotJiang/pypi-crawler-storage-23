from __future__ import annotations

from pathlib import Path
from typing import Annotated
from typing import Any
from typing import Dict
from typing import List
from typing import Literal
from typing import Union

from pydantic import Field
from pydantic import field_validator
from pydantic import model_validator
from pydantic import SecretStr
from typing_extensions import Self

from latticeflow.go.cli.dtypes.data_sources import DatasetGeneratorDataSourceTemplate
from latticeflow.go.cli.dtypes.scorers import TaskScorerTemplate
from latticeflow.go.cli.dtypes.solvers import TaskSolverTemplate
from latticeflow.go.cli.dtypes.synthesizers import DatasetGeneratorSynthesizerTemplate
from latticeflow.go.cli.dtypes.utils import optional_referenced_key_field
from latticeflow.go.cli.dtypes.utils import optional_user_key_field
from latticeflow.go.cli.dtypes.utils import ReferencedKey
from latticeflow.go.cli.dtypes.utils import user_key_field
from latticeflow.go.cli.dtypes.utils import UserKey
from latticeflow.go.models import AIAppKeyInformation
from latticeflow.go.models import BooleanParameterSpec
from latticeflow.go.models import CachePolicy
from latticeflow.go.models import CategoricalParameterSpec
from latticeflow.go.models import ConfigurationDatasetGenerationError
from latticeflow.go.models import DatasetColumnParameterSpec
from latticeflow.go.models import DatasetGenerationRequest
from latticeflow.go.models import DatasetParameterSpec
from latticeflow.go.models import DataSourceDatasetGenerationError
from latticeflow.go.models import EvaluatedEntityType
from latticeflow.go.models import ExecutionProgress
from latticeflow.go.models import ExecutionStatus
from latticeflow.go.models import FloatParameterSpec
from latticeflow.go.models import IntParameterSpec
from latticeflow.go.models import LFBaseModel
from latticeflow.go.models import ListParameterSpec
from latticeflow.go.models import MLTask
from latticeflow.go.models import ModelAdapterCodeSnippet
from latticeflow.go.models import ModelAdapterProviderId
from latticeflow.go.models import ModelParameterSpec
from latticeflow.go.models import ModelProviderConnectionConfig
from latticeflow.go.models import Policy
from latticeflow.go.models import ResultStatus
from latticeflow.go.models import StringParameterSpec
from latticeflow.go.models import Subsampling
from latticeflow.go.models import SynthesizerDatasetGenerationError
from latticeflow.go.models import TLSContext


class ResolvedData(LFBaseModel):
    path: Path
    data: Any


class EnvVars(LFBaseModel):
    base_url: str
    api_key: str
    verify_ssl: bool
    timeout: float | None


ParameterSpecType = Union[
    FloatParameterSpec,
    IntParameterSpec,
    BooleanParameterSpec,
    StringParameterSpec,
    ModelParameterSpec,
    DatasetParameterSpec,
    DatasetColumnParameterSpec,
    ListParameterSpec,
    CategoricalParameterSpec,
]
ConfigSpecType = List[ParameterSpecType]


class _BaseCLIModel(LFBaseModel):
    display_name: str = Field(
        ..., description="The model's name displayed to the user.", min_length=1
    )
    description: str | None = Field(None, description="Short description of the model.")
    rate_limit: int | None = Field(
        None, description="The maximum allowed number of requests per minute."
    )
    task: MLTask = Field(
        MLTask.CHAT_COMPLETION, description="The ML task of the model."
    )


class CLIModelCustomConnectionConfig(LFBaseModel):
    connection_type: Literal["custom_connection"] = Field(
        ..., description="The type of connection config."
    )
    adapter: ReferencedKey = Field(
        ReferencedKey(key="latticeflow$identity_chat_completion"),
        description="The model adapter responsible for converting the endpoint "
        "inputs and outputs into a standardized format.",
    )
    url: str = Field(..., description="The model endpoint URL.")
    api_key: SecretStr | None = Field(
        None,
        description="The key to be passed as the authorization header (Authorization: Bearer API_KEY).",
    )
    model_key: str | None = Field(
        None,
        description='This field is used in case the model is not specified in the URL but in the body instead. For the "openai" adapter, this will be passed as the "model" parameter. For custom adapters, this value is available as model_info.model_key.',
    )
    tls_context: TLSContext | None = Field(
        None,
        description="TLS configuration for secure connections to the model endpoint.",
    )
    custom_headers: Dict[str, Any] | None = Field(
        None,
        description="Additional headers to include in requests to the model endpoint.",
    )


class CLICustomInferenceModelConfig(LFBaseModel):
    connection_type: Literal["custom_inference"] = Field(
        ..., description="The type of connection config."
    )
    adapter: ReferencedKey = Field(
        ReferencedKey(key="latticeflow$identity_chat_completion"),
        description="The model adapter responsible for converting the "
        "inputs and outputs into a standardized format.",
    )
    run_inference_snippet: str = Field(
        ...,
        description="The code snippet to make a call to the model.",
        examples=[
            """
            import httpx

            def run_inference(body, environment):
                response = httpx.post(
                    environment["MODEL_ENDPOINT_URL"],
                    headers={"Authorization": f"Bearer {environment['MODEL_ENDPOINT_API_KEY']}"},
                    content=body.encode(),
                    timeout=5.0,
                    verify=False,
                )
                response.raise_for_status()
                return response.text
            """
        ],
    )
    environment: Dict[str, Any] = Field(
        ...,
        description="Environment variables required to run the model client snippet.",
    )
    timeout: float = Field(
        ...,
        gt=0,
        description="Timeout in seconds for the total runtime of the Python snippet.",
    )


class CLICreateModel(_BaseCLIModel, UserKey):
    config: Union[CLIModelCustomConnectionConfig, CLICustomInferenceModelConfig] = (
        Field(
            ...,
            discriminator="connection_type",
            description="Model connection configuration as a custom endpoint.",
        )
    )

    @field_validator("config", mode="before")
    @classmethod
    def _default_discriminator(cls, field_value: Any) -> dict | Any:
        if isinstance(field_value, dict) and "connection_type" not in field_value:
            field_value = {**field_value, "connection_type": "custom_connection"}
        return field_value


class CLIExportModel(_BaseCLIModel, ReferencedKey):
    config: Union[
        CLIModelCustomConnectionConfig,
        CLICustomInferenceModelConfig,
        ModelProviderConnectionConfig,
    ] = Field(
        ...,
        discriminator="connection_type",
        description="Model connection configuration which can be either "
        "a well-known model provider or a custom endpoint.",
    )


class _BaseCLIModelAdapter(LFBaseModel):
    display_name: str = Field(
        ..., description="The model adapter's name displayed to the user.", min_length=1
    )
    description: str | None = Field(
        None, description="Short description of the model adapter."
    )
    long_description: str | None = Field(
        None,
        description="Long description of the model adapter. Supports Markdown "
        "formatting.",
    )
    provider: ModelAdapterProviderId = Field(
        ModelAdapterProviderId.USER, description="Provider of the model adapter."
    )
    task: MLTask = Field(
        MLTask.CHAT_COMPLETION,
        description="The ML task of the model. Default is: `chat_completion`.",
    )
    process_input: ModelAdapterCodeSnippet = Field(
        ...,
        description="The transform of the model inputs in AI GO! format into the body "
        "of the HTTP request.",
    )
    process_output: ModelAdapterCodeSnippet = Field(
        ...,
        description="The transform of the model's HTTP response body into the AI GO! "
        "format.",
    )


class CLICreateModelAdapter(_BaseCLIModelAdapter, UserKey):
    pass


class CLIExportModelAdapter(_BaseCLIModelAdapter, ReferencedKey):
    pass


class _BaseCLITask(LFBaseModel):
    display_name: str = Field(
        ..., min_length=1, description="The task's name displayed to the user."
    )
    description: str = Field(..., description="Short description of the task.")
    long_description: str | None = Field(
        None, description="Long description of the task. Supports Markdown formatting."
    )
    tasks: List[MLTask] = Field([], description="ML tasks supported by the task.")
    evaluated_entity_type: EvaluatedEntityType = Field(
        EvaluatedEntityType.MODEL, description="Type of entity being evaluated."
    )
    config_spec: ConfigSpecType = Field(
        [], description="Configuration specification of the task."
    )
    definition: CLIDeclarativeTaskDefinitionTemplate = Field(
        ..., discriminator="type", description="Definition of the task."
    )

    @field_validator("definition", mode="before")
    @classmethod
    def _default_discriminator(cls, field_value: Any) -> dict | Any:
        if isinstance(field_value, dict) and "type" not in field_value:
            field_value = {**field_value, "type": "declarative_task"}
        return field_value

    @model_validator(mode="after")
    def check_definition_matches_evaluated_entity(self) -> Self:
        if self.evaluated_entity_type == EvaluatedEntityType.DATASET:
            if self.definition.dataset is not None:
                raise ValueError(
                    "The evaluated entity type is `dataset` but the task definition "
                    "does not correspond to a dataset task definition: it should not"
                    " have a (benchmark) dataset but one was provided."
                )
            if self.definition.solver is not None:
                raise ValueError(
                    "The evaluated entity type is `dataset` but the task definition "
                    "does not correspond to a dataset task definition: it must not have"
                    " a solver but one was provided."
                )

        if self.evaluated_entity_type == EvaluatedEntityType.MODEL:
            if self.definition.dataset is None:
                raise ValueError(
                    "The evaluated entity type is `model` but the task definition "
                    "does not correspond to a model task definition: it must have a "
                    " (benchmark) dataset but none was provided."
                )
            if self.definition.solver is None:
                raise ValueError(
                    "The evaluated entity type is `model` but the task definition "
                    "does not correspond to a model task definition: it must have"
                    " a solver but none was provided."
                )

        return self


class CLICreateTask(_BaseCLITask, UserKey):
    tags: list[str] = Field(
        [],
        description=(
            "Tags to be associated with the task. If a tag does not exist,"
            " it will be created with a random color."
        ),
    )


class CLIExportTask(_BaseCLITask, UserKey):
    tags: list[str] = Field(..., description="Tags associated with the task.")


class CLIDeclarativeTaskDefinitionTemplate(LFBaseModel):
    # The default value here is only relevant for the docs generation.
    # `_default_discriminator` makes "declarative_task" the default when not specified.
    # Putting the default value here causes it to be shown as an optional field, which
    # reflects this behavior.
    type: Literal["declarative_task"] = Field(
        "declarative_task",
        description="Type of the task definition which is set to `declarative_task`.",
    )
    dataset: CLITaskDatasetTemplate | None = Field(
        None,
        description="The (benchmark) dataset used by the task. Required for tasks evaluating models. Should not be provided for task evaluating datasets (since the dataset is provided when using the task in an evaluation).",
    )
    solver: TaskSolverTemplate | None = Field(
        None,
        description="Solver used by the task. Required for tasks evaluating models. Should not be provided for task evaluating datasets.",
    )
    scorers: List[Annotated[TaskScorerTemplate, Field(discriminator="type")]] = Field(
        ..., description="List of scorers used by the task."
    )


class CLITaskDatasetTemplate(LFBaseModel):
    key: str = Field(..., description="Key of the dataset to be used for the task.")
    fast_subset_size: Union[int, str] | None = Field(
        None,
        description="Size of the fast subset. This field is deprecated "
        "and will be removed in future versions.",
    )


class _BaseCLIAIApp(UserKey):
    display_name: str = Field(
        ..., description="The AI app's name displayed to the user.", min_length=1
    )
    description: str | None = Field(
        None, description="Short text description of the AI app."
    )
    long_description: str | None = Field(
        None,
        description="Long description of the AI app. Supports Markdown formatting.",
    )
    key_info: AIAppKeyInformation | None = Field(
        None, description="Key information for the AI application."
    )


class CLICreateAIApp(_BaseCLIAIApp):
    tags: list[str] = Field(
        [],
        description=(
            "Tags to be associated with the AI app. If a tag does not exist,"
            " it will be created with a random color."
        ),
    )


class CLIExportAIApp(_BaseCLIAIApp):
    tags: List[str] = Field(..., description="Tags associated with the AI app.")


class _BaseCLIDatasetGenerator(LFBaseModel):
    display_name: str = Field(
        ...,
        min_length=1,
        description="The dataset generator's name displayed to the user.",
    )
    description: str = Field(
        ..., description="Short description of the dataset generator."
    )
    long_description: str | None = Field(
        None,
        description="Long description of the dataset generator. Supports "
        "Markdown formatting.",
    )
    config_spec: ConfigSpecType = Field(
        [], description="Configuration specification for the dataset generator."
    )
    definition: CLIDeclarativeDatasetGeneratorDefinitionTemplate = Field(
        ...,
        description="Declarative dataset generator definition. It must "
        "be of type `CLIDeclarativeDatasetGeneratorDefinitionTemplate`.",
    )

    @field_validator("definition", mode="before")
    @classmethod
    def _default_discriminator(cls, field_value: Any) -> dict | Any:
        if isinstance(field_value, dict) and "type" not in field_value:
            field_value = {**field_value, "type": "declarative_dataset_generator"}
        return field_value


class CLICreateDatasetGenerator(_BaseCLIDatasetGenerator, UserKey):
    pass


class CLIExportDatasetGenerator(_BaseCLIDatasetGenerator, UserKey):
    pass


class CLIDeclarativeDatasetGeneratorDefinitionTemplate(LFBaseModel):
    # The default value here is only relevant for the docs generation.
    # `_default_discriminator` makes "declarative_dataset_generator" the default when
    # not specified. Putting the default value here causes it to be shown as an optional
    # field, which reflects this behavior.
    type: Literal["declarative_dataset_generator"] = Field(
        "declarative_dataset_generator",
        description="Refers to user-defined dataset generators.",
    )
    data_source: DatasetGeneratorDataSourceTemplate = Field(
        ..., description="Data source used by the dataset generator."
    )
    synthesizer: DatasetGeneratorSynthesizerTemplate | None = Field(
        None,
        description=(
            "Data synthesizer configuration used by the dataset generator. This field is"
            " deprecated and will be removed in future versions. Please use `synthesizers` instead."
        ),
    )
    synthesizers: list[DatasetGeneratorSynthesizerTemplate] | None = Field(
        None,
        description=(
            "Data synthesizer configurations used by the dataset generator. Must contain"
            " at least one synthesizer if provided."
        ),
        min_length=1,
    )

    @model_validator(mode="after")
    def check_synthesizers(self) -> Self:
        # NOTE: We handle it here to avoid this validation in `model_construct`.
        if self.synthesizer is None and self.synthesizers is None:
            raise ValueError(
                "At least one of 'synthesizer' or 'synthesizers' must be provided."
                " Note: 'synthesizer' is deprecated and will be removed in future versions."
                " Please use `synthesizers` instead."
            )
        return self

    def model_post_init(self, __context: Any) -> None:
        """Handle backwards compatibility for deprecated 'synthesizer' field."""
        # Import here to avoid circular import
        import latticeflow.go.cli.utils.printing as cli_print

        if self.synthesizer is not None and self.synthesizers is not None:
            cli_print.log_warning(
                "Both 'synthesizer' and 'synthesizers' are specified."
                " The 'synthesizer' field will be ignored, as it is deprecated.",
                category="deprecation",
            )
        elif self.synthesizer is not None and self.synthesizers is None:
            cli_print.log_warning(
                "'synthesizer' is deprecated and will be removed in future"
                " versions. Please use 'synthesizers' instead."
                " The 'synthesizer' value will be automatically migrated to 'synthesizers'.",
                category="deprecation",
            )
            self.synthesizers = [self.synthesizer]


class CLIDatasetGeneratorSpecification(DatasetGenerationRequest):
    dataset_generator_key: str = Field(
        ..., description="Key of the dataset generator to use."
    )


class _BaseCLIDataset(LFBaseModel):
    display_name: str = Field(
        ..., description="The dataset's name displayed to the user.", min_length=1
    )
    description: str | None = Field(
        None, description="Short description of the dataset."
    )
    file_path: Path | None = Field(
        None,
        description="File containing the dataset's data. "
        "Supported formats are CSV and JSONL. Required if dataset generator "
        "is not used.",
    )
    generator_specification: CLIDatasetGeneratorSpecification | None = Field(
        None,
        description="Config for the dataset generator that will be used to generate "
        "the dataset. Required if the data file is not provided.",
    )


class CLICreateDataset(_BaseCLIDataset, UserKey):
    pass


class CLIExportDataset(_BaseCLIDataset, UserKey):
    pass


class _BaseCLIEvaluation(LFBaseModel):
    display_name: str = Field(
        ..., min_length=1, description="The evaluation's name displayed to the user."
    )
    mode: Literal["debug", "full"] | None = Field(
        None,
        description="The mode of evaluation to be performed. Supported modes are "
        "'debug' and `full`. "
        "This field is deprecated and will be removed in future versions."
        " Please use the `num_samples` and `subsampling` fields instead."
        " Setting this field will be translated as follows: 'debug' sets"
        "`num_samples` to 10 while 'full' sets `num_samples` to None (entire dataset).",
    )
    num_samples: int | None = Field(
        None,
        description="Maximum number of samples from each dataset to be used for the "
        "evaluation. This argument only applies to tasks that do not specify "
        "`num_samples` in their task specifications."
        " If not provided, the entire dataset will be used.",
    )
    subsampling: Subsampling | None = Field(
        None,
        description="The method used to subsample the dataset when `num_samples` is"
        " specified. 'head' selects the first N samples, while 'random' selects N "
        "samples randomly from the dataset. If not provided, defaults to 'head'.",
    )
    cache_policy: CachePolicy = Field(
        CachePolicy.REUSE,
        description="The caching policy to use for the task results in the evaluation.",
    )
    task_specifications: List[CLITaskSpecification] = Field(
        ..., description="List of task specifications for the evaluation."
    )


class CLICreateEvaluation(_BaseCLIEvaluation, UserKey):
    tags: list[str] = Field(
        [],
        description=(
            "Tags to be associated with the evaluation. If a tag does not exist,"
            " it will be created with a random color."
        ),
    )


class CLIExportEvaluation(_BaseCLIEvaluation, UserKey):
    tags: list[str] = Field(..., description="Tags associated with the evaluation.")


class CLITaskSpecification(LFBaseModel):
    key: str | None = optional_user_key_field
    task_key: str = user_key_field
    task_config: Dict[str, Any] = Field(
        {},
        description="Configuration for the specified task. Must match the task's config spec.",
    )
    model_key: str | None = optional_referenced_key_field
    dataset_key: str | None = optional_referenced_key_field
    num_samples: int | None = Field(
        None,
        description="Maximum number of samples from the dataset to be used for the task."
        " If not provided, the entire dataset will be used.",
    )
    subsampling: Subsampling | None = Field(
        None,
        description="The method used to subsample the dataset when `num_samples` is"
        " specified. 'head' selects the first N samples, while 'random' selects N "
        "samples randomly from the dataset. If not provided, defaults to 'head'.",
    )
    display_name: str | None = Field(
        None,
        description="The task specification's name displayed to the user.",
        min_length=1,
    )
    task_result_log_path: str | None = Field(
        None, description="Path to the task result log file."
    )


class CLIProviderAndModelKey(LFBaseModel):
    provider_and_model_key: str = Field(
        alias="$provider",
        description=(
            "A string representing a third-party provider and model"
            " key in the format `$provider: <provider>/<model_key>`."
        ),
    )


class CLICreateRunConfig(LFBaseModel):
    model_adapters: list[CLICreateModelAdapter] = Field(
        [],
        description=(
            "List of all model adapters to be created/updated before running the evaluation."
        ),
    )
    models: list[CLICreateModel | CLIProviderAndModelKey] = Field(
        [],
        description=(
            "List of all models to be created/updated before running the evaluation."
            " Can be either a full model definition or a string representing a third-party"
            " provider and model key in the format `$provider: <provider>/<model_key>`."
        ),
    )

    @field_validator("models", mode="before")
    @classmethod
    def reject_plain_strings(cls, value: Any) -> Any:
        if not isinstance(value, list):
            return value

        for i, item in enumerate(value):
            if isinstance(item, str):
                raise ValueError(
                    f"models[{i}]: plain strings are not allowed. "
                    "If you want a provider model, use: $provider: '<provider>/<model_key>'."
                    " Otherwise specify the full model definition either by laying out all fields"
                    " or using a reference file (e.g., `$ref: 'path/to/model.yaml'`)."
                )
        return value

    dataset_generators: list[CLICreateDatasetGenerator] = Field(
        [],
        description=(
            "List of all dataset generators to be created/updated before running the evaluation."
        ),
    )
    datasets: list[CLICreateDataset] = Field(
        [],
        description=(
            "List of all datasets to be created/updated before running the evaluation."
        ),
    )
    tasks: list[CLICreateTask] = Field(
        [],
        description=(
            "List of all tasks to be created/updated before running the evaluation."
        ),
    )
    evaluation: CLICreateEvaluation | None = Field(
        None, description="The evaluation to be run."
    )

    policies: list[Policy] = Field(
        [], description="List of all policies to apply to the AI app."
    )


class CLIExportRunConfig(LFBaseModel):
    model_adapters: list[CLIExportModelAdapter] = Field(
        [],
        description=(
            "List of all model adapters to be created/updated before running the evaluation."
        ),
    )
    models: list[CLIExportModel | CLIProviderAndModelKey] = Field(
        [],
        description=(
            "List of all models to be created/updated before running the evaluation."
            " Can be either a full model definition or a string representing a third-party"
            " provider and model key in the format `$provider: <provider>/<model_key>`."
        ),
    )
    dataset_generators: list[CLIExportDatasetGenerator] = Field(
        [],
        description=(
            "List of all dataset generators to be created/updated before running the evaluation."
        ),
    )
    datasets: list[CLIExportDataset] = Field(
        [],
        description=(
            "List of all datasets to be created/updated before running the evaluation."
        ),
    )
    tasks: list[CLIExportTask] = Field(
        [],
        description=(
            "List of all tasks to be created/updated before running the evaluation."
        ),
    )
    evaluation: CLIExportEvaluation | None = Field(
        None, description=("The evaluation to be run.")
    )


class CLIDatasetGenerationLog(LFBaseModel):
    execution_status: ExecutionStatus
    result_status: ResultStatus | None = None
    progress: ExecutionProgress | None = None
    errors: (
        List[
            ConfigurationDatasetGenerationError
            | SynthesizerDatasetGenerationError
            | DataSourceDatasetGenerationError,
        ]
        | None
    )
