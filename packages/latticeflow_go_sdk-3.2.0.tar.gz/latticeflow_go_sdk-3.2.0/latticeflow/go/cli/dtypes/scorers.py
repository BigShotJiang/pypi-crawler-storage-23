from __future__ import annotations

from typing import Annotated
from typing import Any
from typing import Literal
from typing import Union

from pydantic import Field
from pydantic import model_validator
from typing_extensions import Self

from latticeflow.go.cli.dtypes.metrics import TaskMetricTemplate
from latticeflow.go.cli.dtypes.utils import optional_user_key_field
from latticeflow.go.cli.dtypes.utils import ReferencedKeyField
from latticeflow.go.cli.dtypes.utils import TemplateValue
from latticeflow.go.models import LFBaseModel
from latticeflow.go.models import StringParameterExample


ScoresToCompute = Literal[
    "recall",
    "precision",
    "f1_score",
    "claim_recall",
    "context_precision",
    "context_utilization",
    "noise_sensitivity_in_relevant",
    "noise_sensitivity_in_irrelevant",
    "hallucination",
    "self_knowledge",
    "faithfulness",
]


class _BaseScorerTemplate(LFBaseModel):
    key: str | None = optional_user_key_field
    metrics: list[Annotated[TaskMetricTemplate, Field(discriminator="type")]] | None = (
        Field(
            None,
            description="The metrics associated with this scorer, which will produce per-task metrics.",
        )
    )


class BLEUScorerTemplate(_BaseScorerTemplate):
    type: Literal["bleu"] = Field(..., description="The type of the scorer.")
    ground_truth: str | TemplateValue = Field(
        description="""The ground truth against which the value is compared.

The ground-truth can be:

1. A hard-coded string (ex: `"YES"`)
2. Refer to the sample data (ex: `"{{ sample.country }}"`)
3. Or a mix of (1) and (2) (ex: `"The country is {{ sample.country }}"`).

`sample` represents the current row of the dataset (with a field for every dataset 
column).""",
        title="Ground Truth",
        examples=["{{ sample.country }}", "YES"],
        json_schema_extra={"string_kind": "jinja"},
    )
    value: str | TemplateValue | None = Field(
        default=None,
        description="""The value which will be compared against the ground-truth.

The value can be:

1. A hard-coded string (ex: `"YES"`)
2. Refer to the sample data (ex: `"{{ sample.country }}"`)
3. (For model tasks) Refer to the solver output (ex: `"{{ solver_output.output }}"`)
4. Or a mix of the others (ex: `"The country is {{ sample.country }}"`).

`sample` represents the current row of the dataset (with a field for every dataset 
column).

If `value` is None:

- If the task has a solver and the solver output is a chat completion response, then the
  value is set to the output message content.
- Otherwise, an error is produced.""",
        title="Ground Truth",
        examples=["{{ sample.country }}", "YES"],
        json_schema_extra={"string_kind": "jinja"},
    )


class ModelAsAJudgeClassifierScorerTemplate(_BaseScorerTemplate):
    type: Literal["model_as_a_judge_classifier"] = Field(
        ..., description="The type of the scorer."
    )
    model_key: ReferencedKeyField | TemplateValue = Field(
        description="The model to be used as the judge.",
        title="Model",
        json_schema_extra={"allowed_values_source": "available_models"},
    )
    system_prompt: str | TemplateValue = Field(
        default="You are a helpful assistant and will be used to judge the output of "
        "another model.",
        description="""The system prompt given to the judge model. The prompt can refer
to the following variable dynamically (using ``{{ }}`` syntax):

In all scenarios:

1. `sample`: Sample attributes (ex: `{{ sample.answer }}`)

If the task has a solver:

2. `model_output`: The last model output (ex: `{{ model_output }}`)
3. `messages`: The full list of input/output messages (ex: `{{ messages[0]['content'] }}`)
4. `input_prompt`: The message contents of the last model output (only for chat 
   completion tasks) (ex: `{{ input_prompt }}`)""",
        title="System prompt",
        json_schema_extra={"string_kind": "jinja"},
    )
    user_prompt: str | TemplateValue = Field(
        description="""The user prompt given to the judge model. The prompt can refer
to the following variable dynamically (using ``{{ }}`` syntax):

In all scenarios:

1. `sample`: Sample attributes (ex: `{{ sample.answer }}`)

If the task has a solver:

2. `model_output`: The last model output (ex: `{{ model_output }}`)
3. `messages`: The full list of input/output messages (ex: `{{ messages[0]['content'] }}`)
4. `input_prompt`: The message contents of the last model output (only for chat
   completion tasks) (ex: `{{ input_prompt }}`)
""",
        title="User prompt",
        examples=[
            """Classify whether the capital for a given country matches the correct capital:

Q: What is the capital of {{ sample.country }}?

Generated answer: {{ input_prompt }}

Correct answer: {{ sample.capital }}

Is the generated answer correct? Respond with class labels 'yes' or 'no'."""
        ],
        json_schema_extra={"string_kind": "jinja"},
    )
    correct_labels: list[str | TemplateValue] = Field(
        description="The list of labels predicted by the judge that are considered correct.",
        title="Correct labels",
    )
    incorrect_labels: list[str | TemplateValue] = Field(
        description="The list of labels predicted by the judge that are considered incorrect.",
        title="Incorrect labels",
    )
    use_structured_outputs: bool = Field(
        default=False,
        description="Whether to use structured outputs. It is recommended to enable "
        "this if the model supports it.",
        title="Use structured output",
    )


class ModelAsAJudgeScorerTemplate(_BaseScorerTemplate):
    type: Literal["model_as_a_judge_scorer"] = Field(
        ..., description="The type of the scorer."
    )
    model_key: ReferencedKeyField | TemplateValue = Field(
        description="The model to be used as the judge.",
        title="Model",
        json_schema_extra={"allowed_values_source": "available_models"},
    )
    system_prompt: str | TemplateValue = Field(
        default="You are a helpful assistant and will be used to judge the output of "
        "another model.",
        description="""The system prompt given to the judge model. The prompt can refer
to the following variable dynamically (using ``{{ }}`` syntax):

In all scenarios:

1. `sample`: Sample attributes (ex: `{{ sample.answer }}`)

If the task has a solver:

2. `model_output`: The last model output (ex: `{{ model_output }}`)
3. `messages`: The full list of input/output messages (ex: `{{ messages[0]['content'] }}`)
4. `input_prompt`: The message contents of the last model output (only for chat
   completion tasks) (ex: `{{ input_prompt }}`)
""",
        title="System prompt",
        json_schema_extra={"string_kind": "jinja"},
    )
    user_prompt: str | TemplateValue = Field(
        description="""The user prompt given to the judge model. The prompt can refer
to the following variable dynamically (using ``{{ }}`` syntax):

In all scenarios:

1. `sample`: Sample attributes (ex: `{{ sample.answer }}`)

If the task has a solver:

2. `model_output`: The last model output (ex: `{{ model_output }}`)
3. `messages`: The full list of input/output messages (ex: `{{ messages[0]['content'] }}`)
4. `input_prompt`: The message contents of the last model output (only for chat
   completion tasks) (ex: `{{ input_prompt }}`)
""",
        title="User prompt",
        examples=[
            """Score how 'grounded' the response is given the context.
The score should be between 0.0 (hallucination) to 1.0 (well grounded in the context):

Context: {{ sample.context }}

Generated response: {{ input_prompt }}
"""
        ],
        json_schema_extra={"string_kind": "jinja"},
    )
    score_min: float | TemplateValue = Field(
        default=0.0,
        description="The minimum score that the judge model can predict.",
        title="Minimum score value",
    )
    score_max: float | TemplateValue = Field(
        default=1.0,
        description="The maximum score that the judge model can predict.",
        title="Maximum score value",
    )
    use_structured_outputs: bool = Field(
        default=False,
        description="Whether to use structured outputs. It is recommended to enable "
        "this if the model supports it.",
        title="Use structured output",
    )


class PythonScorerTemplate(_BaseScorerTemplate):
    type: Literal["python"] = Field(..., description="The type of the scorer.")
    compute_scores_snippet: str | TemplateValue = Field(
        description="""The Python code snippet defining how to compute the scores.
It must define a `compute_scores` function with one the following API.

For model tasks:


```python
def compute_scores(sample: dict[str, Any], solver_output: SolverOutput) -> dict[str, Any]:
```


For dataset tasks:


```python
def compute_scores(sample: dict[str, Any]) -> dict[str, Any]:
```


where

- `sample` is a dictionary representing the current sample
- `solver_output` is an object with 2 attributes:

    - `output`: the last model output
    - `messages`: a list of input/output messages representing the interaction history

- the returned dictionary contains the computed scores
""",
        title="The compute_scores snippet",
        examples=[
            """def compute_scores(sample: dict, solver_output: SolverOutput) -> dict[str, Any]:
    # Description: This scorer evaluates if the model correctly predicted the capital
    # of the country, using case-insensitive string equality, producing an
    # 'is_correct' score.

    # `solver_output.output` contains the full model output (in OpenAI-format), from
    # which we can retrieve the output message content.
    model_completion = solver_output.output['choices'][0]['message']['content']

    # Similarly, we retrieve the ground-truth answer (from the `sample` dict)
    gt_answer = sample['capital']

    # A single 'is_correct' score is produced, using case-insensitive string equality.
    is_correct = model_completion.lower().strip() == gt_answer.lower().strip()

    return {'is_correct': is_correct}"""
        ],
        json_schema_extra={"string_kind": "python"},
    )


class AllSamplesPythonScorerTemplate(_BaseScorerTemplate):
    type: Literal["python_all_samples"] = Field(
        ..., description="The type of the scorer."
    )
    compute_scores_snippet: str | TemplateValue = Field(
        description="""The Python code snippet defining how to compute the scores. It
must define a `compute_scores` function with the following API:


```python
def compute_scores(samples: list[dict[str, Any]]) -> list[dict[str, Any]]:
```


where

- `samples` is the list of samples (in the same order as the dataset)
- the returned list contains the computed scores dictionary per sample
""",
        title="The compute_scores snippet",
        examples=[
            """from collections import Counter
from typing import Any

def compute_scores(samples: list[dict[str, Any]]) -> list[dict[str, Any]]:
    ids = [sample['id'] for sample in samples]
    counter = Counter(ids)

    return [
        {'is_id_unique': counter[id] == 1}
        for id in ids
    ]"""
        ],
        json_schema_extra={"string_kind": "python"},
    )


class RAGCheckerScorerTemplate(_BaseScorerTemplate):
    type: Literal["rag_checker"] = Field(..., description="The type of the scorer.")
    query_column: str | TemplateValue = Field(
        default="query",
        description="The name of the sample column containing the query.",
        title="Query Column",
    )
    target_column: str | TemplateValue = Field(
        default="target",
        description="The name of the sample column containing the target.",
        title="Target Column",
    )
    scores_to_compute: list[ScoresToCompute] | None = Field(
        default=None,
        description="The scores to compute. If set to None, all scores are computed.",
        title="Scores to Compute",
    )
    judge_model_key: ReferencedKeyField | TemplateValue | None = Field(
        default=None,
        description="The registered chat completion model to be used as a claim "
        "extractor and checker. If no model is specified, GPT-4 will be used by default.",
        title="Judge Model",
        json_schema_extra={"allowed_values_source": "available_models"},
    )


class StringEqualsScorerTemplate(_BaseScorerTemplate):
    type: Literal["string_equals"] = Field(..., description="The type of the scorer.")
    ground_truth: str | TemplateValue = Field(
        description="""The ground truth against which the solver output is compared.

The ground-truth can be:

1. A hard-coded string (ex: `"YES"`)
2. Refer to the sample data (ex: `"{{ sample.country }}"`)
3. Or a mix of (1) and (2) (ex: `"The country is {{ sample.country }}"`).

`sample` represents the current row of the dataset (with a field for every dataset
column).""",
        title="Ground Truth",
        examples=["{{ sample.country }}", "YES"],
        json_schema_extra={"string_kind": "jinja"},
    )
    value: str | TemplateValue | None = Field(
        default=None,
        description="""The value which will be compared against the ground-truth.

The value can be:

1. A hard-coded string (ex: `"YES"`)
2. Refer to the sample data (ex: `"{{ sample.country }}"`)
3. (For model tasks) Refer to the solver output (ex: `"{{ solver_output.output }}"`)
4. Or a mix of the others (ex: `"The country is {{ sample.country }}"`).

`sample` represents the current row of the dataset (with a field for every dataset
column).

If `value` is None:

- If the task has a solver and the solver output is a chat completion response, then the
  value is set to the output message content.
- Otherwise, an error is produced.""",
        title="Ground Truth",
        examples=["{{ sample.country }}", "YES"],
        json_schema_extra={"string_kind": "jinja"},
    )


class StringEqualsMCQAScorerTemplate(_BaseScorerTemplate):
    type: Literal["string_equals_mcqa"] = Field(
        ..., description="The type of the scorer."
    )
    ground_truth_choice: str | TemplateValue | None = Field(
        default=None,
        description="""Jinja template that produces the ground truth choice.

The ground-truth choice can be:

1. A hard-coded string (e.g. `"A"`)
2. Refer to a sample field (e.g. `"{{ sample.correct_answer }}"`)
3. Derived from sample data (e.g. `"{{ sample.choices[sample.correct_index] }}"`)
4. Or a mix of the above (e.g. `"{{ sample.answer_key | upper }}"`)

`sample` represents the current row of the dataset (with a field for every dataset column).

The template should produce a single character choice (e.g., "B").""",
        title="Ground Truth Choice",
        json_schema_extra={"string_kind": "jinja"},
        examples=[
            StringParameterExample(
                display_name="A field of the sample",
                value="{{ sample.correct_answer }}",
            ),
            StringParameterExample(
                display_name="From index",
                value="{{ sample.choices[sample.correct_index] }}",
            ),
            StringParameterExample(display_name="A constant", value="A"),
        ],
    )
    choices: str | TemplateValue | None = Field(
        default=None,
        description="""Jinja template that produces the list of choices.

The choices can be:

1. A hard-coded list (e.g. `["A", "B", "C", "D"]`)
2. Refer to a sample field (e.g. `"{{ sample.answer_choices }}"`)
3. Derived from sample data (e.g. `"{{ sample.options | map(attribute='key') | list }}"`)

`sample` represents the current row of the dataset (with a field for every dataset column).

The template should produce a list of single character choices (e.g., ["A", "B", "C", "D"]).
The result can be a JSON string or a Python list.""",
        title="Choices",
        json_schema_extra={"string_kind": "jinja"},
        examples=[
            StringParameterExample(
                display_name="A field of the sample",
                value="{{ sample.answer_choices }}",
            ),
            StringParameterExample(
                display_name="A constant list", value='["A", "B", "C", "D"]'
            ),
        ],
    )

    # TODO: https://app.clickup.com/t/86c85xx9h
    # Legacy field-based fields (deprecated but supported for backwards compatibility)
    ground_truth_choice_field: str | TemplateValue | None = Field(
        default=None,
        description="""Column in the dataset that contains the ground truth choice.
The column is expected to contain single character choices (e.g. 'B'). The first
character of the model's output message content is string matched (string equality)
against this value to evaluate a sample.

This field is deprecated and will be removed in future versions. Use 'ground_truth_choice'
with a Jinja template instead (e.g., '{{ sample.field_name }}').""",
        title="Ground-truth choice field (deprecated)",
        json_schema_extra={"allowed_values_source": "dataset_column"},
        exclude=True,
    )
    choices_field: str | TemplateValue | None = Field(
        default=None,
        description="""Column in the dataset that contains the choices e.g.
a column containing `['A', 'B', 'C', 'D']`.

This field is deprecated and will be removed in future versions. Use 'choices' with a
Jinja template instead (e.g., '{{ sample.field_name }}').""",
        title="Choices field (deprecated)",
        json_schema_extra={"allowed_values_source": "dataset_column"},
        exclude=True,
    )

    @model_validator(mode="after")
    def check_fields(self) -> Self:
        """Validate that at least one configuration method is provided."""
        # NOTE: We handle it here to avoid this validation in `model_construct`.
        if self.ground_truth_choice is None and self.ground_truth_choice_field is None:
            raise ValueError(
                "At least one of 'ground_truth_choice' or 'ground_truth_choice_field' must be provided."
                " Note: 'ground_truth_choice_field' is deprecated and will be removed in future versions."
                " Please use 'ground_truth_choice' instead."
            )
        if self.choices is None and self.choices_field is None:
            raise ValueError(
                "At least one of 'choices' or 'choices_field' must be provided."
                " Note: 'choices_field' is deprecated and will be removed in future versions."
                " Please use 'choices' instead."
            )
        return self

    def model_post_init(self, __context: Any) -> None:
        """Handle backwards compatibility for deprecated field-based config."""
        # Import here to avoid circular import
        import latticeflow.go.cli.utils.printing as cli_print

        # Handle ground_truth_choice migration
        if (
            self.ground_truth_choice_field is not None
            and self.ground_truth_choice is not None
        ):
            cli_print.log_warning(
                "Both 'ground_truth_choice' and 'ground_truth_choice_field' are specified."
                " The 'ground_truth_choice_field' field will be ignored, as it is deprecated.",
                category="deprecation",
            )
        elif (
            self.ground_truth_choice_field is not None
            and self.ground_truth_choice is None
        ):
            cli_print.log_warning(
                "'ground_truth_choice_field' is deprecated and will be removed in future"
                " versions. Please use 'ground_truth_choice' instead."
                " The 'ground_truth_choice_field' value will be automatically migrated to 'ground_truth_choice'.",
                category="deprecation",
            )
            self.ground_truth_choice = (
                f"{{{{ sample.{self.ground_truth_choice_field} }}}}"
            )
            self.ground_truth_choice_field = None

        # Handle choices migration
        if self.choices_field is not None and self.choices is not None:
            cli_print.log_warning(
                "Both 'choices' and 'choices_field' are specified."
                " The 'choices_field' field will be ignored, as it is deprecated.",
                category="deprecation",
            )
        elif self.choices_field is not None and self.choices is None:
            cli_print.log_warning(
                "'choices_field' is deprecated and will be removed in future"
                " versions. Please use 'choices' instead."
                " The 'choices_field' value will be automatically migrated to 'choices'.",
                category="deprecation",
            )
            self.choices = f"{{{{ sample.{self.choices_field} }}}}"
            self.choices_field = None


TaskScorerTemplate = Annotated[
    Union[
        BLEUScorerTemplate,
        StringEqualsScorerTemplate,
        StringEqualsMCQAScorerTemplate,
        ModelAsAJudgeClassifierScorerTemplate,
        ModelAsAJudgeScorerTemplate,
        PythonScorerTemplate,
        AllSamplesPythonScorerTemplate,
        RAGCheckerScorerTemplate,
    ],
    Field(discriminator="type"),
]
