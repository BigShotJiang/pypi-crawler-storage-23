from __future__ import annotations

import typer

from latticeflow.go.cli.evaluations import cancel_evaluation_command
from latticeflow.go.cli.utils.helpers import register_app_callback


cancel_app = typer.Typer(help="Cancel running evaluation by ID.")
register_app_callback(cancel_app)


#######################
# Command registrations
#######################

cancel_app.command("eval")(cancel_evaluation_command)
