from __future__ import annotations

from pathlib import Path

import typer

import latticeflow.go.cli.utils.arguments as cli_args
from latticeflow.go.cli.dataset_generators import add_dataset_generators_command
from latticeflow.go.cli.datasets import add_datasets_command
from latticeflow.go.cli.model_adapters import add_model_adapters_command
from latticeflow.go.cli.models import add_models_command
from latticeflow.go.cli.tasks import add_tasks_command
from latticeflow.go.cli.utils import run_config_processing
from latticeflow.go.cli.utils.env_vars import get_cli_env_vars
from latticeflow.go.cli.utils.helpers import app_callback
from latticeflow.go.cli.utils.helpers import get_client_from_env
from latticeflow.go.cli.utils.helpers import is_glob_pattern
from latticeflow.go.cli.utils.helpers import load_ai_app_key
from latticeflow.go.cli.utils.yaml_utils import load_yaml_recursively


add_app = typer.Typer(
    help="Create/update entities from run config or entity YAML files.",
    # NOTE: We want to allow `lf add` to be invoked, which should add
    # all entities from a run config.
    invoke_without_command=True,
)


# NOTE: This callback is registered instead of the usual `register_app_callback`,
# because only a single callback can be registered and we want to handle the
# simple `lf add`, but also `lf add <entity>` and the `--help` flag correctly.
@add_app.callback()
def add_callback(
    ctx: typer.Context,
    path: Path | None = typer.Option(
        None,
        "--file",
        "-f",
        help="Path to run config YAML. Required if no subcommand is used.",
    ),
) -> None:
    """Create/update entities from run config or entity YAML files."""
    # Call `app_callback` as we would usually do in `register_app_callback`.
    # It also handles the `--help` flag properly.
    app_callback(get_cli_env_vars)

    # If a subcommand is invoked, let it handle everything.
    if ctx.invoked_subcommand is not None:
        if path is not None:
            raise typer.BadParameter(
                "Cannot use '--file' / '-f' option on the level of `lf add` with subcommands."
                " Please provide the file path directly to the subcommand"
                " (i.e. `lf add <entity> --file <path>`) or omit"
                " the subcommand (i.e. `lf add --file <path>`) to add from a run config."
            )
        return

    # If there is no subcommand, require a path and process as run config.
    if path is None:
        raise typer.BadParameter(
            "Missing option '--file' / '-f'. Provide a run config YAML file to add entities from."
        )
    add_entities_from_run_config(path)


def _is_file_run_config(path: Path) -> bool:
    """Checks if a file is a run config or not based on a heuristic."""
    if not path.is_file():
        return False

    try:
        data, _ = load_yaml_recursively(path)
    except Exception:
        return False

    return run_config_processing.is_run_config(data)


def _add_dataset_wrapper(
    path: Path = cli_args.run_or_entity_config_path_option("dataset"),
    should_validate_only: bool = cli_args.should_validate_only_option,
) -> None:
    """Create/update dataset(s) based on YAML configuration(s) or run config."""
    if not is_glob_pattern(path) and _is_file_run_config(path):
        if should_validate_only:
            run_config_processing.validate_run_config(path)
            return
        _add_from_run_config_with_filter(path, entity_types={"datasets"})
    else:
        add_datasets_command(path, should_validate_only)


def _add_dataset_generator_wrapper(
    path: Path = cli_args.run_or_entity_config_path_option("dataset generator"),
    should_validate_only: bool = cli_args.should_validate_only_option,
) -> None:
    """Create/update dataset generator(s) based on YAML configuration(s) or run config."""
    if not is_glob_pattern(path) and _is_file_run_config(path):
        if should_validate_only:
            run_config_processing.validate_run_config(path)
            return
        _add_from_run_config_with_filter(path, entity_types={"dataset_generators"})
    else:
        add_dataset_generators_command(path, should_validate_only)


def _add_model_wrapper(
    path: Path | None = cli_args.run_or_entity_config_path_option(
        "model", is_required=False
    ),
    model_provider_and_key: str | None = cli_args.model_provider_and_key_option,
    should_validate_only: bool = cli_args.should_validate_only_option,
) -> None:
    """Create/update model(s) based on YAML configuration(s) or run config."""
    if path is not None and not is_glob_pattern(path) and _is_file_run_config(path):
        if should_validate_only:
            run_config_processing.validate_run_config(path)
            return
        _add_from_run_config_with_filter(path, entity_types={"models"})
    else:
        add_models_command(path, model_provider_and_key, should_validate_only)


def _add_model_adapter_wrapper(
    path: Path | None = cli_args.run_or_entity_config_path_option(
        "model adapter", is_required=False
    ),
    model_adapter_provider_and_key: str
    | None = cli_args.model_adapter_provider_and_key_option,
    should_validate_only: bool = cli_args.should_validate_only_option,
) -> None:
    """Create/update model adapter(s) based on YAML configuration(s) or run config."""
    if path is not None and not is_glob_pattern(path) and _is_file_run_config(path):
        if should_validate_only:
            run_config_processing.validate_run_config(path)
            return
        _add_from_run_config_with_filter(path, entity_types={"model_adapters"})
    else:
        add_model_adapters_command(
            path, model_adapter_provider_and_key, should_validate_only
        )


def _add_task_wrapper(
    path: Path = cli_args.run_or_entity_config_path_option("task"),
    should_validate_only: bool = cli_args.should_validate_only_option,
) -> None:
    """Create/update task(s) based on YAML configuration(s) or run config."""
    if not is_glob_pattern(path) and _is_file_run_config(path):
        if should_validate_only:
            run_config_processing.validate_run_config(path)
            return
        _add_from_run_config_with_filter(path, entity_types={"tasks"})
    else:
        add_tasks_command(path, should_validate_only)


def _add_from_run_config_with_filter(
    path: Path, entity_types: set[run_config_processing.RunConfigEntityType]
) -> None:
    """Create/update entities from a run config file with entity type filtering."""
    ai_app_key = load_ai_app_key()
    client = get_client_from_env()
    stored_ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)
    run_config, origin_info = run_config_processing.get_cli_run_config_from_file(path)

    result = run_config_processing.add_entities_from_run_config(
        run_config=run_config,
        origin_info=origin_info,
        config_file=path,
        client=client,
        stored_ai_app=stored_ai_app,
        entity_types_filter=entity_types,
    )

    if result.total_added < result.total_expected:
        raise typer.Exit(code=1)


def add_entities_from_run_config(path: Path) -> None:
    """Create/update entities from a run config file."""
    ai_app_key = load_ai_app_key()
    client = get_client_from_env()
    stored_ai_app = client.ai_apps.get_ai_app_by_key(ai_app_key)
    run_config, origin_info = run_config_processing.get_cli_run_config_from_file(path)

    result = run_config_processing.add_entities_from_run_config(
        run_config=run_config,
        origin_info=origin_info,
        config_file=path,
        client=client,
        stored_ai_app=stored_ai_app,
        entity_types_filter={
            "model_adapters",
            "models",
            "dataset_generators",
            "datasets",
            "tasks",
        },
    )

    if result.total_added < result.total_expected:
        raise typer.Exit(code=1)


#######################
# Command registrations
#######################

add_app.command("model-adapter")(_add_model_adapter_wrapper)
add_app.command("model")(_add_model_wrapper)
add_app.command("dataset-generator")(_add_dataset_generator_wrapper)
add_app.command("dataset")(_add_dataset_wrapper)
add_app.command("task")(_add_task_wrapper)
