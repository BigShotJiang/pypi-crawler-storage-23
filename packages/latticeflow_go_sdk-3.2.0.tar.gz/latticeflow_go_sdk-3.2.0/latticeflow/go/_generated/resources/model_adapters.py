from __future__ import annotations

from latticeflow.go._generated.api.model_adapters.create_model_adapter import (
    asyncio as create_model_adapter_asyncio,
)
from latticeflow.go._generated.api.model_adapters.create_model_adapter import (
    sync as create_model_adapter_sync,
)
from latticeflow.go._generated.api.model_adapters.delete_model_adapter import (
    asyncio as delete_model_adapter_asyncio,
)
from latticeflow.go._generated.api.model_adapters.delete_model_adapter import (
    sync as delete_model_adapter_sync,
)
from latticeflow.go._generated.api.model_adapters.get_model_adapter import (
    asyncio as get_model_adapter_asyncio,
)
from latticeflow.go._generated.api.model_adapters.get_model_adapter import (
    sync as get_model_adapter_sync,
)
from latticeflow.go._generated.api.model_adapters.get_model_adapter_provider_by_id import (
    asyncio as get_model_adapter_provider_by_id_asyncio,
)
from latticeflow.go._generated.api.model_adapters.get_model_adapter_provider_by_id import (
    sync as get_model_adapter_provider_by_id_sync,
)
from latticeflow.go._generated.api.model_adapters.get_model_adapter_providers import (
    asyncio as get_model_adapter_providers_asyncio,
)
from latticeflow.go._generated.api.model_adapters.get_model_adapter_providers import (
    sync as get_model_adapter_providers_sync,
)
from latticeflow.go._generated.api.model_adapters.get_model_adapters import (
    asyncio as get_model_adapters_asyncio,
)
from latticeflow.go._generated.api.model_adapters.get_model_adapters import (
    sync as get_model_adapters_sync,
)
from latticeflow.go._generated.api.model_adapters.update_model_adapter import (
    asyncio as update_model_adapter_asyncio,
)
from latticeflow.go._generated.api.model_adapters.update_model_adapter import (
    sync as update_model_adapter_sync,
)
from latticeflow.go._generated.models.model import Error
from latticeflow.go._generated.models.model import ModelAdapter
from latticeflow.go._generated.models.model import ModelAdapterProvider
from latticeflow.go._generated.models.model import ModelAdapterProviders
from latticeflow.go._generated.models.model import StoredModelAdapter
from latticeflow.go._generated.models.model import StoredModelAdapters
from latticeflow.go._generated.models.model import Success
from latticeflow.go._generated.types import UNSET
from latticeflow.go._generated.types import Unset
from latticeflow.go.extensions.resources.model_adapters import (
    AsyncModelAdaptersResource as AsyncBaseModule,
)
from latticeflow.go.extensions.resources.model_adapters import (
    ModelAdaptersResource as BaseModule,
)
from latticeflow.go.types import ApiError


class ModelAdaptersResource(BaseModule):
    def get_model_adapter_provider_by_id(
        self, provider_id: str
    ) -> ModelAdapterProvider:
        """Get model adapter provider by ID

        Args:
            provider_id (str):
        """
        with self._base.get_client() as client:
            response = get_model_adapter_provider_by_id_sync(
                provider_id=provider_id, client=client
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    def get_model_adapter(
        self, ai_app_id: str, model_adapter_id: str
    ) -> StoredModelAdapter:
        """Get the model adapter

        Args:
            ai_app_id (str):
            model_adapter_id (str):
        """
        with self._base.get_client() as client:
            response = get_model_adapter_sync(
                ai_app_id=ai_app_id, model_adapter_id=model_adapter_id, client=client
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    def get_model_adapters(
        self, ai_app_id: str, *, key: str | Unset = UNSET
    ) -> StoredModelAdapters:
        """Get all model adapters

        Args:
            ai_app_id (str):
            key (str | Unset):
        """
        with self._base.get_client() as client:
            response = get_model_adapters_sync(
                ai_app_id=ai_app_id, client=client, key=key
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    def delete_model_adapter(self, ai_app_id: str, model_adapter_id: str) -> Success:
        """Delete the model adapter

        Args:
            ai_app_id (str):
            model_adapter_id (str):
        """
        with self._base.get_client() as client:
            response = delete_model_adapter_sync(
                ai_app_id=ai_app_id, model_adapter_id=model_adapter_id, client=client
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    def get_model_adapter_providers(self) -> ModelAdapterProviders:
        """Get all model adapter providers"""
        with self._base.get_client() as client:
            response = get_model_adapter_providers_sync(client=client)
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    def create_model_adapter(
        self, ai_app_id: str, body: ModelAdapter
    ) -> StoredModelAdapter:
        """Create a model adapter

        Args:
            ai_app_id (str):
            body (ModelAdapter):
        """
        with self._base.get_client() as client:
            response = create_model_adapter_sync(
                ai_app_id=ai_app_id, body=body, client=client
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    def update_model_adapter(
        self, ai_app_id: str, model_adapter_id: str, body: ModelAdapter
    ) -> StoredModelAdapter:
        """Update the model adapter

        Args:
            ai_app_id (str):
            model_adapter_id (str):
            body (ModelAdapter):
        """
        with self._base.get_client() as client:
            response = update_model_adapter_sync(
                ai_app_id=ai_app_id,
                model_adapter_id=model_adapter_id,
                body=body,
                client=client,
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response


class AsyncModelAdaptersResource(AsyncBaseModule):
    async def get_model_adapter_provider_by_id(
        self, provider_id: str
    ) -> ModelAdapterProvider:
        """Get model adapter provider by ID

        Args:
            provider_id (str):
        """
        with self._base.get_client() as client:
            response = await get_model_adapter_provider_by_id_asyncio(
                provider_id=provider_id, client=client
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    async def get_model_adapter(
        self, ai_app_id: str, model_adapter_id: str
    ) -> StoredModelAdapter:
        """Get the model adapter

        Args:
            ai_app_id (str):
            model_adapter_id (str):
        """
        with self._base.get_client() as client:
            response = await get_model_adapter_asyncio(
                ai_app_id=ai_app_id, model_adapter_id=model_adapter_id, client=client
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    async def get_model_adapters(
        self, ai_app_id: str, *, key: str | Unset = UNSET
    ) -> StoredModelAdapters:
        """Get all model adapters

        Args:
            ai_app_id (str):
            key (str | Unset):
        """
        with self._base.get_client() as client:
            response = await get_model_adapters_asyncio(
                ai_app_id=ai_app_id, client=client, key=key
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    async def delete_model_adapter(
        self, ai_app_id: str, model_adapter_id: str
    ) -> Success:
        """Delete the model adapter

        Args:
            ai_app_id (str):
            model_adapter_id (str):
        """
        with self._base.get_client() as client:
            response = await delete_model_adapter_asyncio(
                ai_app_id=ai_app_id, model_adapter_id=model_adapter_id, client=client
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    async def get_model_adapter_providers(self) -> ModelAdapterProviders:
        """Get all model adapter providers"""
        with self._base.get_client() as client:
            response = await get_model_adapter_providers_asyncio(client=client)
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    async def create_model_adapter(
        self, ai_app_id: str, body: ModelAdapter
    ) -> StoredModelAdapter:
        """Create a model adapter

        Args:
            ai_app_id (str):
            body (ModelAdapter):
        """
        with self._base.get_client() as client:
            response = await create_model_adapter_asyncio(
                ai_app_id=ai_app_id, body=body, client=client
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    async def update_model_adapter(
        self, ai_app_id: str, model_adapter_id: str, body: ModelAdapter
    ) -> StoredModelAdapter:
        """Update the model adapter

        Args:
            ai_app_id (str):
            model_adapter_id (str):
            body (ModelAdapter):
        """
        with self._base.get_client() as client:
            response = await update_model_adapter_asyncio(
                ai_app_id=ai_app_id,
                model_adapter_id=model_adapter_id,
                body=body,
                client=client,
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response
