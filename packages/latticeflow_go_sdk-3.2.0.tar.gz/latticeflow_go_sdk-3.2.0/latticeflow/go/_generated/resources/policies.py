from __future__ import annotations

from latticeflow.go._generated.api.policies.get_policies import (
    asyncio as get_policies_asyncio,
)
from latticeflow.go._generated.api.policies.get_policies import (
    sync as get_policies_sync,
)
from latticeflow.go._generated.api.policies.get_policies_status import (
    asyncio as get_policies_status_asyncio,
)
from latticeflow.go._generated.api.policies.get_policies_status import (
    sync as get_policies_status_sync,
)
from latticeflow.go._generated.api.policies.update_policies import (
    asyncio as update_policies_asyncio,
)
from latticeflow.go._generated.api.policies.update_policies import (
    sync as update_policies_sync,
)
from latticeflow.go._generated.models.model import Error
from latticeflow.go._generated.models.model import Policies
from latticeflow.go._generated.models.model import PoliciesStatus
from latticeflow.go._generated.models.model import Success
from latticeflow.go.base import BaseClient
from latticeflow.go.types import ApiError


class PoliciesResource:
    def __init__(self, base_client: BaseClient) -> None:
        self._base = base_client

    def update_policies(self, ai_app_id: str, body: Policies) -> Success:
        """Update policies for an AI app. This replaces all existing policies.

        Args:
            ai_app_id (str):
            body (Policies): A collection of policies for an AI app.
        """
        with self._base.get_client() as client:
            response = update_policies_sync(
                ai_app_id=ai_app_id, body=body, client=client
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    def get_policies_status(self, ai_app_id: str) -> PoliciesStatus:
        """Get the status of all policies for an AI app.

        Args:
            ai_app_id (str):
        """
        with self._base.get_client() as client:
            response = get_policies_status_sync(ai_app_id=ai_app_id, client=client)
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    def get_policies(self, ai_app_id: str) -> Policies:
        """Get all policies for an AI app.

        Args:
            ai_app_id (str):
        """
        with self._base.get_client() as client:
            response = get_policies_sync(ai_app_id=ai_app_id, client=client)
            if isinstance(response, Error):
                raise ApiError(response)
            return response


class AsyncPoliciesResource:
    def __init__(self, base_client: BaseClient) -> None:
        self._base = base_client

    async def update_policies(self, ai_app_id: str, body: Policies) -> Success:
        """Update policies for an AI app. This replaces all existing policies.

        Args:
            ai_app_id (str):
            body (Policies): A collection of policies for an AI app.
        """
        with self._base.get_client() as client:
            response = await update_policies_asyncio(
                ai_app_id=ai_app_id, body=body, client=client
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    async def get_policies_status(self, ai_app_id: str) -> PoliciesStatus:
        """Get the status of all policies for an AI app.

        Args:
            ai_app_id (str):
        """
        with self._base.get_client() as client:
            response = await get_policies_status_asyncio(
                ai_app_id=ai_app_id, client=client
            )
            if isinstance(response, Error):
                raise ApiError(response)
            return response

    async def get_policies(self, ai_app_id: str) -> Policies:
        """Get all policies for an AI app.

        Args:
            ai_app_id (str):
        """
        with self._base.get_client() as client:
            response = await get_policies_asyncio(ai_app_id=ai_app_id, client=client)
            if isinstance(response, Error):
                raise ApiError(response)
            return response
