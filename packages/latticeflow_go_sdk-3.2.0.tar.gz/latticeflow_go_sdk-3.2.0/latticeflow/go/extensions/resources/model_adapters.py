from __future__ import annotations

from typing import TYPE_CHECKING

from latticeflow.go.models import Error
from latticeflow.go.models import StoredAIApp
from latticeflow.go.models import StoredModelAdapter
from latticeflow.go.models import Success
from latticeflow.go.types import ApiError


if TYPE_CHECKING:
    from latticeflow.go import AsyncClient
    from latticeflow.go import Client


class ModelAdaptersResource:
    def __init__(self, base_client: Client) -> None:
        self._base = base_client

    def get_model_adapter_by_key(
        self, *, ai_app: StoredAIApp, key: str
    ) -> StoredModelAdapter:
        """Get the Model Adapter with the given key.

        Args:
            key: The key of the Model Adapter.
            ai_app: The AI app the Model Adapter belongs to.

        Raises:
            ApiError: If there is no Model Adapter with the given key for the specified AI app.
        """
        model_adapters = self._base.model_adapters.get_model_adapters(
            ai_app_id=ai_app.id, key=key
        ).model_adapters
        if not model_adapters:
            raise ApiError(
                Error(
                    message=f"Model Adapter with key '{key}' not found for AI app with key '{ai_app.key}'."
                )
            )

        return model_adapters[0]

    def delete_model_adapter_by_key(self, *, ai_app: StoredAIApp, key: str) -> Success:
        """Delete the Model Adapter by the given key.

        Args:
            ai_app: The AI app the Model Adapter belongs to.
            key: The key of the Model Adapter to be deleted.

        Raises:
            ApiError: If there is no Model Adapter with the given key for the specified AI app.
            ApiError: If the deletion of the Model Adapter fails.
        """
        return self._base.model_adapters.delete_model_adapter(
            ai_app_id=ai_app.id,
            model_adapter_id=self._base.model_adapters.get_model_adapter_by_key(
                ai_app=ai_app, key=key
            ).id,
        )


class AsyncModelAdaptersResource:
    def __init__(self, base_client: AsyncClient) -> None:
        self._base = base_client

    async def get_model_adapter_by_key(
        self, *, ai_app: StoredAIApp, key: str
    ) -> StoredModelAdapter:
        """Get the Model Adapter with the given key.

        Args:
            key: The key of the Model Adapter.
            ai_app: The AI app the Model Adapter belongs to.

        Raises:
            ApiError: If there is no Model Adapter with the given key for the specified AI app.
        """
        model_adapters = (
            await self._base.model_adapters.get_model_adapters(
                ai_app_id=ai_app.id, key=key
            )
        ).model_adapters
        if not model_adapters:
            raise ApiError(
                Error(
                    message=f"Model Adapter with key '{key}' not found for AI app with key '{ai_app.key}'."
                )
            )

        return model_adapters[0]

    async def delete_model_adapter_by_key(
        self, *, ai_app: StoredAIApp, key: str
    ) -> Success:
        """Delete the Model Adapter by the given key.

        Args:
            ai_app: The AI app the Model Adapter belongs to.
            key: The key of the Model Adapter to be deleted.

        Raises:
            ApiError: If there is no Model Adapter with the given key for the specified AI app.
            ApiError: If the deletion of the Model Adapter fails.
        """
        return await self._base.model_adapters.delete_model_adapter(
            ai_app_id=ai_app.id,
            model_adapter_id=(
                await self._base.model_adapters.get_model_adapter_by_key(
                    ai_app=ai_app, key=key
                )
            ).id,
        )
