from __future__ import annotations

from typing import TYPE_CHECKING

from latticeflow.go.models import Error
from latticeflow.go.models import StoredAIApp
from latticeflow.go.models import StoredTask
from latticeflow.go.models import Success
from latticeflow.go.types import ApiError


if TYPE_CHECKING:
    from latticeflow.go import AsyncClient
    from latticeflow.go import Client


class TasksResource:
    def __init__(self, base_client: Client) -> None:
        self._base = base_client

    def get_task_by_key(self, *, ai_app: StoredAIApp, key: str) -> StoredTask:
        """Get the Task with the given key.

        Args:
            key: The key of the Task.
            ai_app: The AI app the Task belongs to.

        Raises:
            ApiError: If there is no Task with the given key for the given AI app.
        """
        tasks = self._base.tasks.get_tasks(ai_app_id=ai_app.id, key=key).tasks
        if not tasks:
            raise ApiError(
                Error(
                    message=f"Task with key '{key}' not found for AI app with key '{ai_app.key}'."
                )
            )

        return tasks[0]

    def delete_task_by_key(self, *, ai_app: StoredAIApp, key: str) -> Success:
        """Delete the Task by the given key.

        Args:
            ai_app: The AI app the Task belongs to.
            key: The key of the Task to be deleted.

        Raises:
            ApiError: If there is no Task with the given key for the given AI app.
            ApiError: If the deletion of the Task fails.
        """
        return self._base.tasks.delete_task(
            ai_app_id=ai_app.id,
            task_id=self._base.tasks.get_task_by_key(ai_app=ai_app, key=key).id,
        )


class AsyncTasksResource:
    def __init__(self, base_client: AsyncClient) -> None:
        self._base = base_client

    async def get_task_by_key(self, *, ai_app: StoredAIApp, key: str) -> StoredTask:
        """Get the Task with the given key.

        Args:
            key: The key of the Task.
            ai_app: The AI app the Task belongs to.

        Raises:
            ApiError: If there is no Task with the given key for the given AI app.
        """
        tasks = (await self._base.tasks.get_tasks(ai_app_id=ai_app.id, key=key)).tasks
        if not tasks:
            raise ApiError(
                Error(
                    message=f"Task with key '{key}' not found for AI app with key '{ai_app.key}'."
                )
            )

        return tasks[0]

    async def delete_task_by_key(self, *, ai_app: StoredAIApp, key: str) -> Success:
        """Delete the Task by the given key.

        Args:
            ai_app: The AI app the Task belongs to.
            key: The key of the Task to be deleted.

        Raises:
            ApiError: If there is no Task with the given key for the given AI app.
            ApiError: If the deletion of the Task fails.
        """
        return await self._base.tasks.delete_task(
            ai_app_id=ai_app.id,
            task_id=(await self._base.tasks.get_task_by_key(ai_app=ai_app, key=key)).id,
        )
