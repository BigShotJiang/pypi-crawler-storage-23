# Minimal AI App Template

A minimal working example demonstrating evaluation setup in LatticeFlow AI GO!. Evaluates the word counting ability of a model and checks a dataset property.

## What You Need

- An API key for OpenRouter. Evaluation will run a free model `openai/gpt-oss-120b:free` and will not consume any credits.

  1. Get the API key at [OpenRouter](https://openrouter.ai/settings/keys).
  2. Set it as an environment variable: `export OPENROUTER_API_KEY="your-api-key-here"`.
  3. Enable the user of free models in [OpenRouter](https://openrouter.ai/settings/privacy) by enabling:

     - [x] `Enable free endpoints that may train on inputs`
     - [x] `Enable free endpoints that may publish prompts`

## How to Run

1. Set up environment variable (see above)
2. Configure: `lf configure`
3. Run: `lf init --template minimal`
