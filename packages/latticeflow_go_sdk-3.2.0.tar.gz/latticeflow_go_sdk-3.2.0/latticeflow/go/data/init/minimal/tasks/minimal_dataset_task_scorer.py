from __future__ import annotations

from typing import Any


def compute_scores(samples: list[dict[str, Any]]) -> list[dict[str, Any]]:
    field_name = "<< config.dataset_column >>"
    return [{"has_minimal": "minimal" in sample[field_name]} for sample in samples]
