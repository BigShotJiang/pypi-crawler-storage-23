"""Version information for coverity-metrics package"""

__version__ = "1.0.8"
__author__ = "Jouni Lehto"
__description__ = "Comprehensive metrics and dashboard generator for Coverity static analysis"
