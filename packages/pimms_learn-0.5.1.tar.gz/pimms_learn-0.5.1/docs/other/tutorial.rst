.. include:: ../../project/04_1_train_pimms_models.ipynb
   :parser: myst_nb.docutils_
   :start-line: 0