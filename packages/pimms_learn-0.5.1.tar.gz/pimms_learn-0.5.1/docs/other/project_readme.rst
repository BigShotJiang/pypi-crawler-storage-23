.. include:: ../../project/README.md
   :parser: myst_parser.sphinx_
   :start-line: 0