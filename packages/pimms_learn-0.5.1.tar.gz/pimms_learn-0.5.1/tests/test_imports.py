def test_imports():
    import pimmslearn.analyzers
    import pimmslearn.sklearn

    print(pimmslearn.analyzers.__doc__)
    print(pimmslearn.sklearn.__doc__)
