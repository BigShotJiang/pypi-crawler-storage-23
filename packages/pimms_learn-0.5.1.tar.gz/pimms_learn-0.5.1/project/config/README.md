# Config files for Snakemake workflows

> Avoid white spaces in your config filenames!  
> (e.g. `my study` -> `my_study`)


## `single_dev_dataset`

- HeLa development dataset specifications for a single standalone run
