# KNN comparison

for large protein groups HeLa dataset.

```bash
snakemake -s workflow/Snakefile_v2.smk --configfile config/knn_comparison/hela_pgs_large/config.yaml -p -c1 -n
```