# Alzheimer study configuration

For [`workflow/Snakefile_v2.yaml`](https://github.com/RasmussenLab/pimms/blob/HEAD/project/workflow/Snakefile_v2.smk):

- [`config.yaml`](config.yaml)
- see comments in config for explanations.

For [`workflow/Snakefile_ald_comparison](https://github.com/RasmussenLab/pimms/blob/HEAD/project/workflow/Snakefile_ald_comparison.smk):

- [`comparison.yaml`](comparison.yaml)
