# Example Dataset

- small demo data set
- based on Q-Exactive HF-X Orbitrap machine 6070
- 50 latest runs of quality controll and maintenance samples at NNF CPR
