from __future__ import annotations

import random
import threading
import tkinter as tk
from dataclasses import dataclass, field
from tkinter import messagebox, simpledialog
from typing import Dict, List, Optional, Tuple

import numpy as np

from .solver import solve, auto_schedule_sa, auto_schedule_sqa


@dataclass
class Node:
    idx: int
    x: float
    y: float
    bias: float = 0.0
    items: List[int] = field(default_factory=list)
    label: Optional[int] = None


@dataclass
class Edge:
    i: int
    j: int
    weight: float
    items: List[int] = field(default_factory=list)


class GraphEditor:
    def __init__(self, title: str = "qanneal Graph Editor"):
        self.colors = {
            "bg": "#efe6d6",
            "panel": "#f3ead7",
            "canvas": "#fdf8ef",
            "text": "#2b2b2b",
            "muted": "#6b6b6b",
            "accent": "#c49b63",
            "edge": "#6f6a5d",
            "edge_cut": "#cc3d2b",
            "node": "#ffffff",
            "node_a": "#cfe8ff",
            "node_b": "#d6f2d2",
            "grid": "#e7dcc9",
            "entry_bg": "#fff7ea",
            "entry_fg": "#2b2b2b",
            "button_bg": "#eadfc8",
            "button_fg": "#2b2b2b",
        }

        self.root = tk.Tk()
        self.root.title(title)
        self.root.configure(bg=self.colors["bg"])

        self.canvas = tk.Canvas(self.root, width=900, height=600, bg=self.colors["canvas"], highlightthickness=0)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.sidebar = tk.Frame(self.root, bg=self.colors["panel"])
        self.sidebar.pack(side=tk.RIGHT, fill=tk.Y)

        self.sidebar_canvas = tk.Canvas(self.sidebar, bg=self.colors["panel"], highlightthickness=0, width=320)
        self.sidebar_canvas.pack(side=tk.LEFT, fill=tk.Y, expand=False)
        self.sidebar_scroll = tk.Scrollbar(self.sidebar, orient="vertical", command=self.sidebar_canvas.yview)
        self.sidebar_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.sidebar_canvas.configure(yscrollcommand=self.sidebar_scroll.set)

        self.controls = tk.Frame(self.sidebar_canvas, bg=self.colors["panel"])
        self.sidebar_canvas.create_window((0, 0), window=self.controls, anchor="nw")
        self.controls.bind("<Configure>", self._update_scrollregion)
        self.sidebar_canvas.bind_all("<MouseWheel>", self._on_mousewheel)

        self.info = tk.Text(self.controls, width=38, height=16, bg="#f7f1e3", fg=self.colors["text"],
                            insertbackground=self.colors["text"])
        self.info.pack(padx=8, pady=8)
        self.info.insert(tk.END, "Left-click empty: add node\n")
        self.info.insert(tk.END, "Left-click node: select/unselect\n")
        self.info.insert(tk.END, "Key 'b': set bias on selected node\n")
        self.info.insert(tk.END, "Key 'w': set weight between 2 selected nodes\n")
        self.info.insert(tk.END, "Key 'd' or Delete: delete selected\n")
        self.info.insert(tk.END, "Buttons: preset/export/run/clear\n")
        self.info.insert(tk.END, "Physics: beta=1/T (cooling), gamma=transverse field\n")
        self.info.insert(tk.END, "More sweeps/slices/reads -> better mixing, slower\n")

        btn_frame = tk.Frame(self.controls, bg=self.colors["panel"])
        btn_frame.pack(padx=8, pady=8, fill=tk.X)

        self.preset_var = tk.StringVar(value="MaxCut Ring (6)")
        presets = [
            "MaxCut Ring (6)",
            "MaxCut Complete (6)",
            "MaxCut Bipartite (4,4)",
            "Random QUBO (8)",
            "Spin Glass (8)",
        ]
        tk.Label(btn_frame, text="Preset", bg=self.colors["panel"], fg=self.colors["text"]).pack(anchor="w")
        self.preset_menu = tk.OptionMenu(btn_frame, self.preset_var, *presets)
        self.preset_menu.configure(bg=self.colors["panel"], fg=self.colors["text"], highlightthickness=0)
        self.preset_menu["menu"].config(bg=self.colors["panel"], fg=self.colors["text"])
        self.preset_menu.pack(fill=tk.X)
        self.load_preset_btn = tk.Button(btn_frame, text="Load Preset", command=self.load_preset,
                                         bg=self.colors["accent"], fg="white")
        self.load_preset_btn.pack(fill=tk.X, pady=4)

        self.problem_var = tk.StringVar(value="MaxCut")
        problems = ["QUBO", "MaxCut", "MaxIndependentSet", "MaxClique", "MinVertexCover"]
        tk.Label(btn_frame, text="Problem", bg=self.colors["panel"], fg=self.colors["text"]).pack(anchor="w")
        self.problem_menu = tk.OptionMenu(btn_frame, self.problem_var, *problems)
        self.problem_menu.configure(bg=self.colors["panel"], fg=self.colors["text"], highlightthickness=0)
        self.problem_menu["menu"].config(bg=self.colors["panel"], fg=self.colors["text"])
        self.problem_menu.pack(fill=tk.X)

        self.method_var = tk.StringVar(value="SQA")
        tk.Label(btn_frame, text="Method", bg=self.colors["panel"], fg=self.colors["text"]).pack(anchor="w")
        self.method_menu = tk.OptionMenu(btn_frame, self.method_var, "SQA", "SA")
        self.method_menu.configure(bg=self.colors["panel"], fg=self.colors["text"], highlightthickness=0)
        self.method_menu["menu"].config(bg=self.colors["panel"], fg=self.colors["text"])
        self.method_menu.pack(fill=tk.X)

        self.reads_var = tk.IntVar(value=25)
        tk.Label(btn_frame, text="Reads", bg=self.colors["panel"], fg=self.colors["text"]).pack(anchor="w")
        self.reads_entry = tk.Entry(btn_frame, textvariable=self.reads_var, bg=self.colors["entry_bg"],
                                    fg=self.colors["entry_fg"], insertbackground=self.colors["entry_fg"])
        self.reads_entry.pack(fill=tk.X)

        self.steps_var = tk.IntVar(value=40)
        tk.Label(btn_frame, text="Steps", bg=self.colors["panel"], fg=self.colors["text"]).pack(anchor="w")
        self.steps_entry = tk.Entry(btn_frame, textvariable=self.steps_var, bg=self.colors["entry_bg"],
                                    fg=self.colors["entry_fg"], insertbackground=self.colors["entry_fg"])
        self.steps_entry.pack(fill=tk.X)

        self.beta_start_var = tk.DoubleVar(value=0.1)
        self.beta_end_var = tk.DoubleVar(value=4.0)
        tk.Label(btn_frame, text="Beta start/end", bg=self.colors["panel"], fg=self.colors["text"]).pack(anchor="w")
        beta_row = tk.Frame(btn_frame, bg=self.colors["panel"])
        beta_row.pack(fill=tk.X)
        self.beta_start_entry = tk.Entry(beta_row, textvariable=self.beta_start_var, width=8, bg=self.colors["entry_bg"],
                                         fg=self.colors["entry_fg"], insertbackground=self.colors["entry_fg"])
        self.beta_start_entry.pack(side=tk.LEFT, expand=True, fill=tk.X)
        self.beta_end_entry = tk.Entry(beta_row, textvariable=self.beta_end_var, width=8, bg=self.colors["entry_bg"],
                                       fg=self.colors["entry_fg"], insertbackground=self.colors["entry_fg"])
        self.beta_end_entry.pack(side=tk.LEFT, expand=True, fill=tk.X)

        self.gamma_start_var = tk.DoubleVar(value=5.0)
        self.gamma_end_var = tk.DoubleVar(value=0.01)
        tk.Label(btn_frame, text="Gamma start/end", bg=self.colors["panel"], fg=self.colors["text"]).pack(anchor="w")
        gamma_row = tk.Frame(btn_frame, bg=self.colors["panel"])
        gamma_row.pack(fill=tk.X)
        self.gamma_start_entry = tk.Entry(gamma_row, textvariable=self.gamma_start_var, width=8, bg=self.colors["entry_bg"],
                                          fg=self.colors["entry_fg"], insertbackground=self.colors["entry_fg"])
        self.gamma_start_entry.pack(side=tk.LEFT, expand=True, fill=tk.X)
        self.gamma_end_entry = tk.Entry(gamma_row, textvariable=self.gamma_end_var, width=8, bg=self.colors["entry_bg"],
                                        fg=self.colors["entry_fg"], insertbackground=self.colors["entry_fg"])
        self.gamma_end_entry.pack(side=tk.LEFT, expand=True, fill=tk.X)

        self.sweeps_var = tk.IntVar(value=20)
        tk.Label(btn_frame, text="Sweeps / beta", bg=self.colors["panel"], fg=self.colors["text"]).pack(anchor="w")
        self.sweeps_entry = tk.Entry(btn_frame, textvariable=self.sweeps_var, bg=self.colors["entry_bg"],
                                     fg=self.colors["entry_fg"], insertbackground=self.colors["entry_fg"])
        self.sweeps_entry.pack(fill=tk.X)

        self.worldline_var = tk.IntVar(value=5)
        tk.Label(btn_frame, text="Worldline sweeps", bg=self.colors["panel"], fg=self.colors["text"]).pack(anchor="w")
        self.worldline_entry = tk.Entry(btn_frame, textvariable=self.worldline_var, bg=self.colors["entry_bg"],
                                        fg=self.colors["entry_fg"], insertbackground=self.colors["entry_fg"])
        self.worldline_entry.pack(fill=tk.X)

        self.slices_var = tk.IntVar(value=16)
        tk.Label(btn_frame, text="Trotter slices", bg=self.colors["panel"], fg=self.colors["text"]).pack(anchor="w")
        self.slices_entry = tk.Entry(btn_frame, textvariable=self.slices_var, bg=self.colors["entry_bg"],
                                     fg=self.colors["entry_fg"], insertbackground=self.colors["entry_fg"])
        self.slices_entry.pack(fill=tk.X)

        self.replicas_var = tk.IntVar(value=2)
        tk.Label(btn_frame, text="Replicas", bg=self.colors["panel"], fg=self.colors["text"]).pack(anchor="w")
        self.replicas_entry = tk.Entry(btn_frame, textvariable=self.replicas_var, bg=self.colors["entry_bg"],
                                       fg=self.colors["entry_fg"], insertbackground=self.colors["entry_fg"])
        self.replicas_entry.pack(fill=tk.X)

        self.penalty_var = tk.DoubleVar(value=2.0)
        tk.Label(btn_frame, text="Penalty A (MIS/VC/Clique)", bg=self.colors["panel"],
                 fg=self.colors["text"]).pack(anchor="w")
        tk.Entry(btn_frame, textvariable=self.penalty_var, bg=self.colors["entry_bg"], fg=self.colors["entry_fg"],
                 insertbackground=self.colors["entry_fg"]).pack(fill=tk.X)

        self.show_cut_var = tk.BooleanVar(value=True)
        tk.Checkbutton(btn_frame, text="Show Cut", variable=self.show_cut_var, bg=self.colors["panel"],
                       fg=self.colors["text"], selectcolor=self.colors["panel"]).pack(anchor="w", pady=4)

        self.verify_var = tk.BooleanVar(value=True)
        tk.Checkbutton(btn_frame, text="Verify (brute force <= 18)", variable=self.verify_var, bg=self.colors["panel"],
                       fg=self.colors["text"], selectcolor=self.colors["panel"]).pack(anchor="w", pady=4)

        self.autoprove_var = tk.BooleanVar(value=False)
        tk.Checkbutton(btn_frame, text="Auto-improve (if verifiable)", variable=self.autoprove_var,
                       bg=self.colors["panel"], fg=self.colors["text"], selectcolor=self.colors["panel"]).pack(anchor="w", pady=4)

        self.show_grid_var = tk.BooleanVar(value=True)
        tk.Checkbutton(btn_frame, text="Show grid", variable=self.show_grid_var, command=self.draw_grid,
                       bg=self.colors["panel"], fg=self.colors["text"], selectcolor=self.colors["panel"]).pack(anchor="w", pady=4)

        self.export_btn = tk.Button(btn_frame, text="Export QUBO", command=self.export_qubo,
                                    bg=self.colors["button_bg"], fg=self.colors["button_fg"],
                                    activebackground=self.colors["accent"], activeforeground="white")
        self.export_btn.pack(fill=tk.X)
        self.run_btn = tk.Button(btn_frame, text="Run Solve", command=self.run_solve,
                                 bg=self.colors["accent"], fg="white",
                                 activebackground="#b88445", activeforeground="white")
        self.run_btn.pack(fill=tk.X, pady=4)
        self.clear_btn = tk.Button(btn_frame, text="Clear", command=self.clear,
                                   bg=self.colors["button_bg"], fg=self.colors["button_fg"],
                                   activebackground=self.colors["accent"], activeforeground="white")
        self.clear_btn.pack(fill=tk.X)

        self.nodes: List[Node] = []
        self.edges: Dict[Tuple[int, int], Edge] = {}
        self.selected: List[int] = []
        self.radius = 18

        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<Motion>", self.on_motion)
        self.canvas.bind("<Configure>", self.on_resize)
        self.root.bind("b", self.set_bias)
        self.root.bind("w", self.set_weight)
        self.root.bind("d", self.delete_selected)
        self.root.bind("<Delete>", self.delete_selected)

        self.grid_size = 30
        self.snap_var = tk.BooleanVar(value=True)
        tk.Checkbutton(btn_frame, text="Snap to grid", variable=self.snap_var, bg=self.colors["panel"],
                       fg=self.colors["text"], selectcolor=self.colors["panel"]).pack(anchor="w", pady=4)

        self.hover_item = None
        self.grid_items: List[int] = []

        self.status_var = tk.StringVar(value="Nodes: 0 | Edges: 0")
        tk.Label(self.controls, textvariable=self.status_var, anchor="w", bg=self.colors["panel"],
                 fg=self.colors["muted"]).pack(fill=tk.X, padx=8, pady=(0, 8))

        self.method_var.trace_add("write", self.on_method_change)
        self.on_method_change()
        self.draw_grid()
        self._solver_thread: Optional[threading.Thread] = None

    def _update_scrollregion(self, _event=None) -> None:
        self.sidebar_canvas.configure(scrollregion=self.sidebar_canvas.bbox("all"))

    def _on_mousewheel(self, event) -> None:
        if event.delta == 0:
            return
        self.sidebar_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def log(self, msg: str) -> None:
        self.info.insert(tk.END, msg + "\n")
        self.info.see(tk.END)

    def on_click(self, event) -> None:
        x, y = self.snap_point(event.x, event.y)
        node_idx = self.find_node_at(x, y)
        if node_idx is None:
            self.add_node(x, y)
        else:
            self.toggle_select(node_idx)

    def on_motion(self, event) -> None:
        if not self.snap_var.get():
            return
        x, y = self.snap_point(event.x, event.y)
        if self.hover_item is None:
            self.hover_item = self.canvas.create_oval(x - 3, y - 3, x + 3, y + 3, outline="#cbbfa8")
        else:
            self.canvas.coords(self.hover_item, x - 3, y - 3, x + 3, y + 3)

    def on_resize(self, _event=None) -> None:
        self.draw_grid()

    def draw_grid(self) -> None:
        for item in self.grid_items:
            self.canvas.delete(item)
        self.grid_items = []
        if not self.show_grid_var.get():
            return
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        gs = self.grid_size
        color = self.colors["grid"]
        for x in range(0, w, gs):
            self.grid_items.append(self.canvas.create_line(x, 0, x, h, fill=color))
        for y in range(0, h, gs):
            self.grid_items.append(self.canvas.create_line(0, y, w, y, fill=color))
        for item in self.grid_items:
            self.canvas.tag_lower(item)

    def on_method_change(self, *_args) -> None:
        is_sqa = self.method_var.get().upper() == "SQA"
        state = tk.NORMAL if is_sqa else tk.DISABLED
        self.worldline_entry.config(state=state)
        self.slices_entry.config(state=state)
        self.replicas_entry.config(state=state)
        self.gamma_start_entry.config(state=state)
        self.gamma_end_entry.config(state=state)

    def update_status(self) -> None:
        self.status_var.set(f"Nodes: {len(self.nodes)} | Edges: {len(self.edges)}")

    def snap_point(self, x: float, y: float) -> Tuple[float, float]:
        if not self.snap_var.get():
            return x, y
        gs = self.grid_size
        return round(x / gs) * gs, round(y / gs) * gs

    def find_node_at(self, x: float, y: float) -> Optional[int]:
        for node in self.nodes:
            dx = node.x - x
            dy = node.y - y
            if (dx * dx + dy * dy) <= self.radius * self.radius:
                return node.idx
        return None

    def add_node(self, x: float, y: float) -> None:
        idx = len(self.nodes)
        node = Node(idx=idx, x=x, y=y)
        node.items = self.draw_sketch_circle(x, y, self.radius, self.colors["muted"], self.colors["node"], 2,
                                             seed=idx * 97 + 7)
        node.label = self.canvas.create_text(x, y, text=str(idx), fill=self.colors["text"])
        self.nodes.append(node)
        self.log(f"Added node {idx}")
        self.update_status()

    def add_node_with_bias(self, x: float, y: float, bias: float) -> None:
        self.add_node(x, y)
        self.nodes[-1].bias = bias

    def toggle_select(self, idx: int) -> None:
        if idx in self.selected:
            self.selected.remove(idx)
        else:
            self.selected.append(idx)
        self.refresh_selection()

    def refresh_selection(self) -> None:
        for node in self.nodes:
            if not node.items:
                continue
            color = "#cc3d2b" if node.idx in self.selected else self.colors["muted"]
            for item in node.items:
                self.canvas.itemconfig(item, outline=color)

    def set_bias(self, _event=None) -> None:
        if len(self.selected) != 1:
            messagebox.showinfo("Bias", "Select exactly one node.")
            return
        idx = self.selected[0]
        node = self.nodes[idx]
        value = simpledialog.askfloat("Bias", f"Bias for node {idx}:", initialvalue=node.bias)
        if value is None:
            return
        node.bias = float(value)
        self.log(f"Set bias: node {idx} = {node.bias}")

    def set_weight(self, _event=None) -> None:
        if len(self.selected) != 2:
            messagebox.showinfo("Weight", "Select exactly two nodes.")
            return
        i, j = sorted(self.selected)
        key = (i, j)
        current = self.edges[key].weight if key in self.edges else 0.0
        value = simpledialog.askfloat("Weight", f"Weight for edge ({i},{j}):", initialvalue=current)
        if value is None:
            return
        self.add_edge(i, j, float(value))

    def add_edge(self, i: int, j: int, weight: float) -> None:
        # Normalize to sorted order so that set_weight, export_qubo (MaxClique
        # edge-set check), and delete_selected always use the same canonical key.
        if i > j:
            i, j = j, i
        key = (i, j)
        ni, nj = self.nodes[i], self.nodes[j]
        if key in self.edges:
            edge = self.edges[key]
            edge.weight = weight
            self.log(f"Updated edge ({i},{j}) weight = {weight}")
            return

        items = self.draw_sketch_line(ni.x, ni.y, nj.x, nj.y, self.colors["edge"], 2, seed=i * 173 + j * 37)
        edge = Edge(i=i, j=j, weight=weight, items=items)
        self.edges[key] = edge
        for item in items:
            self.canvas.tag_lower(item)
        self.log(f"Added edge ({i},{j}) weight = {weight}")
        self.update_status()

    def layout_circle(self, n: int, cx: float = 450, cy: float = 300, r: float = 220) -> List[Tuple[float, float]]:
        pts = []
        for k in range(n):
            angle = 2 * np.pi * k / max(n, 1)
            pts.append((cx + r * np.cos(angle), cy + r * np.sin(angle)))
        return pts

    def load_preset(self) -> None:
        name = self.preset_var.get()
        self.clear()

        if name == "MaxCut Ring (6)":
            n = 6
            pts = self.layout_circle(n)
            for x, y in pts:
                self.add_node_with_bias(x, y, 0.0)
            for i in range(n):
                j = (i + 1) % n
                self.add_edge(i, j, 1.0)
            self.problem_var.set("MaxCut")
            self.log("Preset: MaxCut Ring (6)")
            return

        if name == "MaxCut Complete (6)":
            n = 6
            pts = self.layout_circle(n)
            for x, y in pts:
                self.add_node_with_bias(x, y, 0.0)
            for i in range(n):
                for j in range(i + 1, n):
                    self.add_edge(i, j, 1.0)
            self.problem_var.set("MaxCut")
            self.log("Preset: MaxCut Complete (6)")
            return

        if name == "MaxCut Bipartite (4,4)":
            n_left = 4
            n_right = 4
            pts = []
            for i in range(n_left):
                pts.append((250, 120 + i * 110))
            for i in range(n_right):
                pts.append((650, 120 + i * 110))
            for x, y in pts:
                self.add_node_with_bias(x, y, 0.0)
            for i in range(n_left):
                for j in range(n_left, n_left + n_right):
                    self.add_edge(i, j, 1.0)
            self.problem_var.set("MaxCut")
            self.log("Preset: MaxCut Bipartite (4,4)")
            return

        if name == "Random QUBO (8)":
            n = 8
            rng = np.random.default_rng(7)
            pts = self.layout_circle(n)
            for x, y in pts:
                self.add_node_with_bias(x, y, float(rng.normal(scale=0.5)))
            for i in range(n):
                for j in range(i + 1, n):
                    if rng.random() < 0.35:
                        self.add_edge(i, j, float(rng.normal(scale=0.5)))
            self.problem_var.set("QUBO")
            self.log("Preset: Random QUBO (8)")
            return

        if name == "Spin Glass (8)":
            n = 8
            rng = np.random.default_rng(13)
            pts = self.layout_circle(n)
            for x, y in pts:
                self.add_node_with_bias(x, y, float(rng.choice([-1.0, 1.0]) * 0.2))
            for i in range(n):
                for j in range(i + 1, n):
                    if rng.random() < 0.5:
                        self.add_edge(i, j, float(rng.choice([-1.0, 1.0])))
            self.problem_var.set("QUBO")
            self.log("Preset: Spin Glass (8)")
            return

    def delete_selected(self, _event=None) -> None:
        if not self.selected:
            return
        remove = set(self.selected)
        self.selected = []

        for key in list(self.edges.keys()):
            if key[0] in remove or key[1] in remove:
                edge = self.edges.pop(key)
                for item in edge.items:
                    self.canvas.delete(item)

        survivors: List[Node] = []
        old_to_new: Dict[int, int] = {}
        for node in self.nodes:
            if node.idx in remove:
                for item in node.items:
                    self.canvas.delete(item)
                if node.label is not None:
                    self.canvas.delete(node.label)
            else:
                old_to_new[node.idx] = len(survivors)
                survivors.append(node)

        for node in survivors:
            node.idx = old_to_new[node.idx]
            if node.label is not None:
                self.canvas.itemconfig(node.label, text=str(node.idx))
        self.nodes = survivors

        new_edges: Dict[Tuple[int, int], Edge] = {}
        for edge in self.edges.values():
            if edge.i in remove or edge.j in remove:
                continue
            i = old_to_new[edge.i]
            j = old_to_new[edge.j]
            key = tuple(sorted((i, j)))
            edge.i = key[0]
            edge.j = key[1]
            new_edges[key] = edge
        self.edges = new_edges

        self.refresh_selection()
        self.log("Deleted selected nodes.")
        self.update_status()

    def export_qubo(self) -> np.ndarray:
        n = len(self.nodes)
        Q = np.zeros((n, n), dtype=float)
        problem = self.problem_var.get()
        if problem == "MaxCut":
            for node in self.nodes:
                Q[node.idx, node.idx] += node.bias
            for (i, j), edge in self.edges.items():
                w = edge.weight
                Q[i, i] -= w
                Q[j, j] -= w
                Q[i, j] += w
                Q[j, i] += w
            self.log("Exported MaxCut -> QUBO matrix (minimization form).")
        elif problem == "MaxIndependentSet":
            A = max(1.0, float(self.penalty_var.get()))
            for node in self.nodes:
                w_i = node.bias if node.bias != 0.0 else 1.0
                Q[node.idx, node.idx] += -w_i
            for (i, j), edge in self.edges.items():
                Q[i, j] += 0.5 * A
                Q[j, i] += 0.5 * A
            self.log(f"Exported MIS -> QUBO (A={A}).")
        elif problem == "MaxClique":
            A = max(1.0, float(self.penalty_var.get()))
            for node in self.nodes:
                w_i = node.bias if node.bias != 0.0 else 1.0
                Q[node.idx, node.idx] += -w_i
            edge_set = set(self.edges.keys())
            for i in range(n):
                for j in range(i + 1, n):
                    if (i, j) not in edge_set:
                        Q[i, j] += 0.5 * A
                        Q[j, i] += 0.5 * A
            self.log(f"Exported MaxClique -> QUBO (A={A}).")
        elif problem == "MinVertexCover":
            A = max(1.0, float(self.penalty_var.get()))
            for node in self.nodes:
                w_i = node.bias if node.bias != 0.0 else 1.0
                Q[node.idx, node.idx] += w_i
            for (i, j), edge in self.edges.items():
                Q[i, i] += -A
                Q[j, j] += -A
                Q[i, j] += 0.5 * A
                Q[j, i] += 0.5 * A
            self.log(f"Exported MinVertexCover -> QUBO (A={A}).")
        else:
            for node in self.nodes:
                Q[node.idx, node.idx] += node.bias
            for (i, j), edge in self.edges.items():
                Q[i, j] += edge.weight
                Q[j, i] += edge.weight
            self.log("Exported QUBO matrix.")
        self.log(str(Q))
        return Q

    def qubo_energy(self, Q: np.ndarray, x: np.ndarray) -> float:
        return float(x @ Q @ x)

    def brute_force_best(self, Q: np.ndarray) -> Tuple[float, np.ndarray]:
        n = Q.shape[0]
        best_e = float("inf")
        best_x = None
        for mask in range(1 << n):
            x = np.array([(mask >> i) & 1 for i in range(n)], dtype=float)
            e = self.qubo_energy(Q, x)
            if e < best_e:
                best_e = e
                best_x = x
        return best_e, best_x.astype(int)

    def maxcut_value(self, x: np.ndarray) -> float:
        val = 0.0
        for (i, j), edge in self.edges.items():
            w = edge.weight
            val += w * (x[i] + x[j] - 2 * x[i] * x[j])
        return val

    def draw_cut(self, x: np.ndarray) -> None:
        for node in self.nodes:
            if not node.items:
                continue
            color = self.colors["node_a"] if x[node.idx] == 0 else self.colors["node_b"]
            for item in node.items:
                self.canvas.itemconfig(item, fill=color)

        for (i, j), edge in self.edges.items():
            if not edge.items:
                continue
            color = self.colors["edge_cut"] if x[i] != x[j] else self.colors["edge"]
            width = 3 if x[i] != x[j] else 2
            for item in edge.items:
                self.canvas.itemconfig(item, fill=color, width=width)

    def set_controls_state(self, enabled: bool) -> None:
        state = tk.NORMAL if enabled else tk.DISABLED
        self.run_btn.config(state=state)
        self.export_btn.config(state=state)
        self.clear_btn.config(state=state)
        self.load_preset_btn.config(state=state)
        self.preset_menu.config(state=state)
        self.problem_menu.config(state=state)
        self.method_menu.config(state=state)
        self.reads_entry.config(state=state)
        self.steps_entry.config(state=state)
        self.sweeps_entry.config(state=state)
        self.worldline_entry.config(state=state)
        self.slices_entry.config(state=state)
        self.replicas_entry.config(state=state)
        self.beta_start_entry.config(state=state)
        self.beta_end_entry.config(state=state)
        self.gamma_start_entry.config(state=state)
        self.gamma_end_entry.config(state=state)

    def run_solve(self) -> None:
        if len(self.nodes) == 0:
            messagebox.showinfo("Solve", "Add at least one node.")
            return
        Q = self.export_qubo()
        reads = max(1, int(self.reads_var.get() or 1))
        steps = max(2, int(self.steps_var.get() or 40))
        sweeps = max(1, int(self.sweeps_var.get() or 20))
        worldline = max(0, int(self.worldline_var.get() or 5))
        slices = max(1, int(self.slices_var.get() or 16))
        replicas = max(1, int(self.replicas_var.get() or 2))
        method = "sqa" if self.method_var.get().upper() == "SQA" else "sa"
        problem = self.problem_var.get()
        verify = bool(self.verify_var.get())
        autoprove = bool(self.autoprove_var.get())
        show_cut = bool(self.show_cut_var.get())

        beta_start = float(self.beta_start_var.get())
        beta_end = float(self.beta_end_var.get())
        if method == "sqa":
            gamma_start = float(self.gamma_start_var.get())
            gamma_end = float(self.gamma_end_var.get())
            schedule = auto_schedule_sqa(
                steps=steps,
                beta_start=beta_start,
                beta_end=beta_end,
                gamma_start=gamma_start,
                gamma_end=gamma_end,
            )
        else:
            schedule = auto_schedule_sa(
                steps=steps,
                beta_start=beta_start,
                beta_end=beta_end,
            )

        self.log(f"Run: method={method} reads={reads} steps={steps} sweeps={sweeps}")
        if self._solver_thread and self._solver_thread.is_alive():
            self.log("Solve already running.")
            return
        self.set_controls_state(False)
        self._solver_thread = threading.Thread(
            target=self._solve_worker,
            args=(Q, method, reads, sweeps, worldline, slices, replicas, schedule,
                  problem, verify, autoprove, show_cut),
            daemon=True,
        )
        self._solver_thread.start()

    def _solve_worker(self,
                      Q: np.ndarray,
                      method: str,
                      reads: int,
                      sweeps: int,
                      worldline: int,
                      slices: int,
                      replicas: int,
                      schedule,
                      problem: str,
                      verify: bool,
                      autoprove: bool,
                      show_cut: bool) -> None:
        logs: List[str] = []
        try:
            result = solve(
                Q,
                method=method,
                reads=reads,
                sweeps_per_beta=sweeps,
                worldline_sweeps=worldline,
                trotter_slices=slices,
                replicas=replicas,
                schedule=schedule,
                return_bits=True,
                progress=False,
            )
            best_sample = result.best_sample.astype(int)
            best_bits = best_sample.astype(float)
            best_qubo_energy = self.qubo_energy(Q, best_bits)
            best_ising_energy = result.best_energy

            cut_val = None
            if problem == "MaxCut":
                cut_val = self.maxcut_value(best_bits)

            opt_e = None
            opt_x = None
            if verify:
                n = Q.shape[0]
                if n > 18:
                    logs.append("Verify skipped: n > 18")
                else:
                    opt_e, opt_x = self.brute_force_best(Q)
                    logs.append(f"Brute force best QUBO energy: {opt_e}")
                    logs.append(f"Brute force best sample: {opt_x}")
                    if problem == "MaxCut":
                        logs.append(f"Brute force MaxCut value: {self.maxcut_value(opt_x.astype(float))}")
                    if autoprove:
                        target = opt_e
                        best_seen = best_qubo_energy
                        if best_seen > target:
                            logs.append("Auto-improve enabled: searching for optimum...")
                            extra_reads = 0
                            while best_seen > target and extra_reads < 200:
                                extra_reads += 10
                                res2 = solve(
                                    Q,
                                    method=method,
                                    reads=10,
                                    sweeps_per_beta=sweeps,
                                    worldline_sweeps=worldline,
                                    trotter_slices=slices,
                                    replicas=replicas,
                                    schedule=schedule,
                                    return_bits=True,
                                    progress=False,
                                )
                                b2 = res2.best_sample.astype(float)
                                e2 = self.qubo_energy(Q, b2)
                                if e2 < best_seen:
                                    best_seen = e2
                                    best_sample = res2.best_sample.astype(int)
                                    best_qubo_energy = best_seen
                                    best_ising_energy = res2.best_energy
                                    if problem == "MaxCut":
                                        cut_val = self.maxcut_value(best_sample.astype(float))
                                    logs.append(f"Improved: QUBO energy {best_seen}")
                            if best_seen == target:
                                logs.append("Auto-improve reached brute-force optimum.")
                            else:
                                logs.append(f"Auto-improve stopped at {best_seen} (target {target}).")

            logs.append(f"Solve best Ising energy: {best_ising_energy}")
            logs.append(f"Solve best QUBO energy: {best_qubo_energy}")
            logs.append(f"Best sample (bits): {best_sample}")
            if problem == "MaxCut" and cut_val is not None:
                logs.append(f"MaxCut value (best sample): {cut_val}")

            self.root.after(0, lambda: self._solve_done(best_sample, logs, opt_x, problem, show_cut, verify))
        except Exception as exc:
            self.root.after(0, lambda: self._solve_failed(str(exc)))

    def _solve_done(self,
                    best_sample: np.ndarray,
                    logs: List[str],
                    opt_x: Optional[np.ndarray],
                    problem: str,
                    show_cut: bool,
                    verify: bool) -> None:
        for line in logs:
            self.log(line)
        if problem == "MaxCut" and show_cut:
            if opt_x is not None and verify:
                self.draw_cut(opt_x.astype(int))
            else:
                self.draw_cut(best_sample.astype(int))
        self.set_controls_state(True)
        self.update_status()

    def _solve_failed(self, err: str) -> None:
        self.log(f"Error: {err}")
        self.set_controls_state(True)

    def clear(self) -> None:
        self.canvas.delete("all")
        self.grid_items = []  # canvas.delete("all") removed them; reset the list
        self.nodes.clear()
        self.edges.clear()
        self.selected.clear()
        self.hover_item = None
        self.problem_var.set("QUBO")
        self.draw_grid()  # restore grid after wiping the canvas
        self.log("Cleared graph.")
        self.update_status()

    def draw_sketch_line(self, x1: float, y1: float, x2: float, y2: float, color: str, width: int, seed: int) -> List[int]:
        rng = random.Random(seed)
        items: List[int] = []
        for _ in range(3):
            j = 1.8
            ax = x1 + rng.uniform(-j, j)
            ay = y1 + rng.uniform(-j, j)
            bx = x2 + rng.uniform(-j, j)
            by = y2 + rng.uniform(-j, j)
            items.append(self.canvas.create_line(ax, ay, bx, by, fill=color, width=width, capstyle=tk.ROUND))
        return items

    def draw_sketch_circle(self, x: float, y: float, r: float, outline: str, fill: str, width: int, seed: int) -> List[int]:
        rng = random.Random(seed)
        items: List[int] = []
        for k in range(2):
            j = 1.5
            dx = rng.uniform(-j, j)
            dy = rng.uniform(-j, j)
            item = self.canvas.create_oval(
                x - r + dx,
                y - r + dy,
                x + r + dx,
                y + r + dy,
                outline=outline,
                width=width,
                fill=fill if k == 0 else "",
            )
            items.append(item)
        return items

    def run(self) -> None:
        self.root.mainloop()


def launch_graph_editor() -> None:
    GraphEditor().run()
