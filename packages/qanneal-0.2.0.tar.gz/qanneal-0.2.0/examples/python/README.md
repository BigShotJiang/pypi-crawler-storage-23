# Python examples

Run from repo root after installing the Python package:

```bash
python -m pip install -e .
python examples/python/sa_multi.py
python examples/python/sqa_basic.py
python examples/python/metrics_plot.py
python examples/python/parallel_tempering.py
python examples/python/tuned_sqapt_demo.py --mode balanced
python examples/python/number_partition_benchmark.py --with-sqapt --with-ctpimc --schedule-mode balanced --jobs 8
python examples/python/number_partition_compare_all.py --with-sqapt --schedule-mode balanced --instances 16 --jobs 8
```

See the companion `.md` files in this folder for a short explanation of each script.
