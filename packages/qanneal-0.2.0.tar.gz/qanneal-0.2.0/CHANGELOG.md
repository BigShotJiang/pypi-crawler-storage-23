# Changelog

All notable changes to this project will be documented in this file.

## 0.2.0 - 2026-03-05

- Minor release: bumped version to 0.2.0.
- Placeholder for user-visible changes; please update with actual release notes.
