"""
Router state contracts for antaris-router.

Failure behavior:
- RouterState: if the classifier cannot produce a tier, it emits UNKNOWN tier
  with confidence=0.0 and routes to the configured safe-default model.
- RouteDecision: is always produced (never None); on total failure the
  fallback_chain is used in order until one succeeds.
- ClassificationResult: if all classifiers fail, returns tier="simple" with
  confidence=0.0 and reasoning=["fallback: all classifiers failed"].
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

SCHEMA_VERSION = "2.2.0"


@dataclass
class ClassificationResult:
    """
    Output of the task classifier stage.

    Failure semantics:
    - On classifier exception: return tier="simple", confidence=0.0.
    - Confidence < 0.3 triggers the low-confidence escalation path.
    """
    tier: str = "simple"
    confidence: float = 0.0
    reasoning: List[str] = field(default_factory=list)
    signals: List[str] = field(default_factory=list)
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ClassificationResult":
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "ClassificationResult":
        return cls.from_dict(json.loads(s))


@dataclass
class RouteDecision:
    """
    The routing decision produced for a single request.

    Failure semantics:
    - If the primary model is unavailable, iterate fallback_chain.
    - If all fallback_chain models are unavailable, set model="" and
      surface error through the pipeline — never silently drop the request.
    - SLA breaches are logged but do not block routing unless guard policy
      is configured to enforce them.
    """
    model: str = ""
    provider: str = ""
    tier: str = "simple"
    confidence: float = 0.0
    confidence_basis: str = "keyword"
    reasoning: List[str] = field(default_factory=list)
    evidence: List[str] = field(default_factory=list)
    estimated_cost: float = 0.0
    fallback_chain: List[str] = field(default_factory=list)
    classification: Optional[ClassificationResult] = None
    escalated: bool = False
    original_confidence: Optional[float] = None
    escalation_reason: Optional[str] = None
    sla_compliant: bool = True
    sla_breaches: List[str] = field(default_factory=list)
    sla_adjustments: List[str] = field(default_factory=list)
    ab_variant: Optional[str] = None
    explanation: str = ""
    supports_streaming: bool = False
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RouteDecision":
        classification_data = data.pop("classification", None)
        classification = ClassificationResult.from_dict(classification_data) if classification_data else None
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(classification=classification, **filtered)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "RouteDecision":
        return cls.from_dict(json.loads(s))


@dataclass
class RouterState:
    """
    Persisted router state: cost tracking, SLA records, A/B test state.

    Failure semantics:
    - On file corruption: reset to empty state; log warning.
    - On concurrent write conflict: last-writer-wins (acceptable for
      cost tracking approximations).
    - Cost totals may drift slightly under high concurrency — treat as
      estimates, not exact billing.
    """
    session_id: str = ""
    total_requests: int = 0
    total_cost_usd: float = 0.0
    requests_by_tier: Dict[str, int] = field(default_factory=dict)
    cost_by_model: Dict[str, float] = field(default_factory=dict)
    recent_decisions: List[RouteDecision] = field(default_factory=list)
    sla_violations: int = 0
    last_updated: str = ""
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RouterState":
        decisions_raw = data.pop("recent_decisions", [])
        decisions = [RouteDecision.from_dict(d) for d in decisions_raw]
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(recent_decisions=decisions, **filtered)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "RouterState":
        return cls.from_dict(json.loads(s))
