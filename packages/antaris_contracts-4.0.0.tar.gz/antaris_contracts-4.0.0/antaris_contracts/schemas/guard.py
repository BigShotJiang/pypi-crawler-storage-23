"""
Guard state contracts for antaris-guard.

Failure behavior:
- GuardDecision: the guard MUST produce a decision for every input; if all
  pattern matchers crash, the decision defaults to BLOCKED with
  threat_level="critical" and is_safe=False — fail-closed, not fail-open.
- GuardPolicy: if a policy file fails to parse, the active policy is NOT
  replaced; the previous policy remains and a warning is emitted.
- AuditRecord: audit writes are best-effort; a failed audit write is logged
  but does not affect the guard decision itself.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

SCHEMA_VERSION = "2.2.0"


@dataclass
class PatternMatch:
    """A single pattern that fired during guard analysis."""
    pattern_id: str = ""
    pattern_type: str = ""
    matched_text: str = ""
    score: float = 0.0
    severity: str = "low"
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PatternMatch":
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)


@dataclass
class GuardDecision:
    """
    The result of a guard evaluation on a single message or output.

    Threat levels: SAFE, SUSPICIOUS, BLOCKED, CRITICAL.

    Failure semantics:
    - On classifier crash: return threat_level="CRITICAL", is_safe=False (fail-closed).
    - On PII filter crash: log and continue; do NOT expose unredacted text.
    - Pattern version mismatch triggers a warning but does not block.
    """
    threat_level: str = "SAFE"
    is_safe: bool = True
    is_suspicious: bool = False
    is_blocked: bool = False
    matches: List[PatternMatch] = field(default_factory=list)
    score: float = 0.0
    message: str = ""
    pattern_version: str = ""
    pii_found: bool = False
    redaction_count: int = 0
    filtered_text: Optional[str] = None
    audit_id: str = ""
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GuardDecision":
        matches_raw = data.pop("matches", [])
        matches = [PatternMatch.from_dict(m) if isinstance(m, dict) else m for m in matches_raw]
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(matches=matches, **filtered)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "GuardDecision":
        return cls.from_dict(json.loads(s))


@dataclass
class GuardPolicyRule:
    """A single composable rule within a GuardPolicy."""
    rule_id: str = ""
    rule_type: str = ""
    parameters: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GuardPolicyRule":
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)


@dataclass
class GuardPolicy:
    """
    A named, versioned security policy configuration.

    Failure semantics:
    - On parse failure: keep previous policy active, emit warning.
    - On invalid rule_type: skip that rule and log; do not fail entire policy.
    - Policies are reloaded via file-watch (not hot-reload); reload is atomic
      (new policy replaces old only after successful parse).
    """
    policy_id: str = ""
    name: str = "default"
    description: str = ""
    rules: List[GuardPolicyRule] = field(default_factory=list)
    threat_threshold: float = 0.5
    block_threshold: float = 0.8
    enable_pii_filter: bool = True
    enable_behavior_analysis: bool = True
    rate_limit_rpm: Optional[int] = None
    created: str = ""
    last_modified: str = ""
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GuardPolicy":
        rules_raw = data.pop("rules", [])
        rules = [GuardPolicyRule.from_dict(r) for r in rules_raw]
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(rules=rules, **filtered)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "GuardPolicy":
        return cls.from_dict(json.loads(s))


@dataclass
class AuditRecord:
    """
    An append-only audit log entry for guard decisions.

    Failure semantics:
    - Audit writes are best-effort: a failed write is logged, not raised.
    - The audit file is opened in append mode; partial line writes are
      harmless (incomplete JSON lines are skipped on read).
    """
    audit_id: str = ""
    timestamp: str = ""
    source_id: str = ""
    action: str = ""
    risk_level: str = "low"
    decision: Optional[GuardDecision] = None
    details: Dict[str, Any] = field(default_factory=dict)
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AuditRecord":
        decision_data = data.pop("decision", None)
        decision = GuardDecision.from_dict(decision_data) if decision_data else None
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore[attr-defined]
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(decision=decision, **filtered)

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "AuditRecord":
        return cls.from_dict(json.loads(s))
