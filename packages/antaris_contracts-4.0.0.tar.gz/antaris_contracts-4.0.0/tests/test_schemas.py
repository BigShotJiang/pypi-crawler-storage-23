"""
Tests for antaris-contracts: schemas, serialization, and migration.

Run with:
    cd antaris-contracts && python -m pytest tests/ -v
"""

import json
import pytest

from antaris_contracts import (
    SCHEMA_VERSION,
    MemoryEntry,
    SearchResult,
    MemoryShard,
    MemoryIndex,
    ClassificationResult,
    RouteDecision,
    RouterState,
    PatternMatch,
    GuardDecision,
    GuardPolicyRule,
    GuardPolicy,
    AuditRecord,
    ContextItem,
    ContextSection,
    ContextPacket,
    PerformanceMetrics,
    TelemetryEvent,
    SchemaVersion,
    migrate,
)
from antaris_contracts.migration import MigrationError, get_migration_path


# ── Version ──────────────────────────────────────────────────────────────────

class TestVersion:
    def test_schema_version(self):
        assert SCHEMA_VERSION == "2.2.0"

    def test_schema_version_enum_current(self):
        assert SchemaVersion.V2_2_0.value == "2.2.0"

    def test_schema_version_ordering(self):
        order = SchemaVersion.ordered()
        assert order[0] == SchemaVersion.V2_0_0
        assert order[-1] == SchemaVersion.V2_2_0
        assert SchemaVersion.V2_0_0 < SchemaVersion.V2_2_0
        assert SchemaVersion.V2_2_0 <= SchemaVersion.V2_2_0


# ── Memory schemas ────────────────────────────────────────────────────────────

class TestMemoryEntry:
    def test_default_instantiation(self):
        e = MemoryEntry(content="test content")
        assert e.content == "test content"
        assert e.schema_version == "2.2.0"
        assert e.memory_type == "episodic"
        assert e.importance == 1.0

    def test_to_dict(self):
        e = MemoryEntry(content="hello", source="test", importance=0.8)
        d = e.to_dict()
        assert d["content"] == "hello"
        assert d["source"] == "test"
        assert d["importance"] == 0.8
        assert d["schema_version"] == "2.2.0"

    def test_from_dict(self):
        d = {"content": "roundtrip", "source": "pytest", "importance": 0.5,
             "schema_version": "2.2.0"}
        e = MemoryEntry.from_dict(d)
        assert e.content == "roundtrip"
        assert e.source == "pytest"
        assert e.importance == 0.5

    def test_from_dict_ignores_unknown_keys(self):
        d = {"content": "x", "schema_version": "2.2.0", "future_field": "ignored"}
        e = MemoryEntry.from_dict(d)
        assert e.content == "x"

    def test_json_roundtrip(self):
        e = MemoryEntry(content="json test", tags=["a", "b"], memory_type="fact")
        e2 = MemoryEntry.from_json(e.to_json())
        assert e2.content == "json test"
        assert e2.tags == ["a", "b"]
        assert e2.memory_type == "fact"

    def test_to_json_is_valid_json(self):
        e = MemoryEntry(content="check")
        parsed = json.loads(e.to_json())
        assert isinstance(parsed, dict)


class TestMemoryShard:
    def test_default_instantiation(self):
        s = MemoryShard(shard_id="shard_2026-02_test")
        assert s.shard_id == "shard_2026-02_test"
        assert s.entries == []
        assert s.schema_version == "2.2.0"

    def test_with_entries(self):
        e1 = MemoryEntry(content="entry one")
        e2 = MemoryEntry(content="entry two")
        s = MemoryShard(shard_id="test", entries=[e1, e2], entry_count=2)
        d = s.to_dict()
        assert len(d["entries"]) == 2
        assert d["entry_count"] == 2

    def test_from_dict_deserializes_entries(self):
        d = {
            "shard_id": "test",
            "category": "general",
            "period": "2026-02",
            "entries": [{"content": "nested", "schema_version": "2.2.0"}],
            "entry_count": 1,
            "created": "",
            "last_modified": "",
            "schema_version": "2.2.0",
        }
        s = MemoryShard.from_dict(d)
        assert len(s.entries) == 1
        assert isinstance(s.entries[0], MemoryEntry)
        assert s.entries[0].content == "nested"

    def test_json_roundtrip(self):
        entries = [MemoryEntry(content=f"item {i}") for i in range(3)]
        s = MemoryShard(shard_id="s1", entries=entries, entry_count=3)
        s2 = MemoryShard.from_json(s.to_json())
        assert s2.shard_id == "s1"
        assert len(s2.entries) == 3


class TestMemoryIndex:
    def test_default_instantiation(self):
        idx = MemoryIndex()
        assert idx.total_entries == 0
        assert idx.shard_count == 0
        assert idx.schema_version == "2.2.0"

    def test_roundtrip(self):
        idx = MemoryIndex(
            total_entries=100,
            shard_count=5,
            categories=["general", "strategic"],
            shard_manifest={"shard_2026-02_general.json": "abc123"},
        )
        idx2 = MemoryIndex.from_dict(idx.to_dict())
        assert idx2.total_entries == 100
        assert idx2.shard_count == 5
        assert "general" in idx2.categories


# ── Router schemas ────────────────────────────────────────────────────────────

class TestRouteDecision:
    def test_default_instantiation(self):
        d = RouteDecision()
        assert d.tier == "simple"
        assert d.confidence == 0.0
        assert d.schema_version == "2.2.0"

    def test_with_classification(self):
        cls = ClassificationResult(tier="complex", confidence=0.9)
        rd = RouteDecision(
            model="claude-sonnet-4-6",
            tier="complex",
            confidence=0.9,
            classification=cls,
        )
        d = rd.to_dict()
        assert d["classification"]["tier"] == "complex"

    def test_from_dict_with_classification(self):
        d = {
            "model": "claude-haiku-4-5",
            "tier": "simple",
            "confidence": 0.7,
            "classification": {
                "tier": "simple",
                "confidence": 0.7,
                "reasoning": ["keyword match"],
                "signals": [],
                "schema_version": "2.2.0",
            },
            "schema_version": "2.2.0",
        }
        rd = RouteDecision.from_dict(d)
        assert rd.model == "claude-haiku-4-5"
        assert isinstance(rd.classification, ClassificationResult)
        assert rd.classification.tier == "simple"

    def test_json_roundtrip(self):
        rd = RouteDecision(
            model="claude-opus-4-6",
            tier="complex",
            confidence=0.95,
            escalated=True,
            escalation_reason="low confidence",
        )
        rd2 = RouteDecision.from_json(rd.to_json())
        assert rd2.model == "claude-opus-4-6"
        assert rd2.escalated is True
        assert rd2.escalation_reason == "low confidence"


class TestRouterState:
    def test_default_instantiation(self):
        rs = RouterState()
        assert rs.total_requests == 0
        assert rs.schema_version == "2.2.0"

    def test_with_decisions(self):
        decisions = [RouteDecision(model="x", tier="simple")]
        rs = RouterState(total_requests=1, recent_decisions=decisions)
        d = rs.to_dict()
        assert len(d["recent_decisions"]) == 1

    def test_json_roundtrip(self):
        rs = RouterState(session_id="sess-1", total_requests=50, total_cost_usd=0.05)
        rs2 = RouterState.from_json(rs.to_json())
        assert rs2.session_id == "sess-1"
        assert rs2.total_requests == 50


# ── Guard schemas ─────────────────────────────────────────────────────────────

class TestGuardDecision:
    def test_default_safe(self):
        gd = GuardDecision()
        assert gd.is_safe is True
        assert gd.threat_level == "SAFE"
        assert gd.schema_version == "2.2.0"

    def test_blocked_decision(self):
        pm = PatternMatch(pattern_id="inj-01", score=0.95, severity="high")
        gd = GuardDecision(
            threat_level="BLOCKED",
            is_safe=False,
            is_blocked=True,
            matches=[pm],
            score=0.95,
        )
        d = gd.to_dict()
        assert d["threat_level"] == "BLOCKED"
        assert len(d["matches"]) == 1

    def test_from_dict_with_matches(self):
        d = {
            "threat_level": "SUSPICIOUS",
            "is_safe": False,
            "is_suspicious": True,
            "is_blocked": False,
            "matches": [{"pattern_id": "x", "score": 0.5, "severity": "medium",
                         "schema_version": "2.2.0"}],
            "score": 0.5,
            "message": "",
            "schema_version": "2.2.0",
        }
        gd = GuardDecision.from_dict(d)
        assert gd.threat_level == "SUSPICIOUS"
        assert isinstance(gd.matches[0], PatternMatch)

    def test_json_roundtrip(self):
        gd = GuardDecision(threat_level="SAFE", is_safe=True, score=0.0)
        gd2 = GuardDecision.from_json(gd.to_json())
        assert gd2.is_safe is True


class TestGuardPolicy:
    def test_default_instantiation(self):
        gp = GuardPolicy(policy_id="p1", name="strict")
        assert gp.enable_pii_filter is True
        assert gp.schema_version == "2.2.0"

    def test_with_rules(self):
        rule = GuardPolicyRule(rule_id="r1", rule_type="rate_limit",
                               parameters={"rpm": 10})
        gp = GuardPolicy(policy_id="p1", rules=[rule])
        d = gp.to_dict()
        assert len(d["rules"]) == 1
        assert d["rules"][0]["rule_type"] == "rate_limit"

    def test_json_roundtrip(self):
        gp = GuardPolicy(policy_id="p2", name="balanced",
                         threat_threshold=0.6, block_threshold=0.9)
        gp2 = GuardPolicy.from_json(gp.to_json())
        assert gp2.name == "balanced"
        assert gp2.block_threshold == 0.9


class TestAuditRecord:
    def test_with_decision(self):
        gd = GuardDecision(threat_level="SAFE", is_safe=True)
        ar = AuditRecord(
            audit_id="a1",
            timestamp="2026-02-20T00:00:00Z",
            source_id="user-123",
            action="allow",
            decision=gd,
        )
        d = ar.to_dict()
        assert d["decision"]["threat_level"] == "SAFE"

    def test_json_roundtrip(self):
        ar = AuditRecord(audit_id="a2", action="block", risk_level="high")
        ar2 = AuditRecord.from_json(ar.to_json())
        assert ar2.audit_id == "a2"
        assert ar2.risk_level == "high"


# ── Context schemas ───────────────────────────────────────────────────────────

class TestContextPacket:
    def test_default_instantiation(self):
        cp = ContextPacket(task="write a function")
        assert cp.total_budget == 4096
        assert cp.schema_version == "2.2.0"
        assert cp.strategy == "hybrid"

    def test_with_sections(self):
        item = ContextItem(content="mem result", tokens=10, priority=1.0)
        section = ContextSection(
            name="memories", budget=500, used=10, items=[item]
        )
        cp = ContextPacket(task="test", sections=[section], total_used=10)
        d = cp.to_dict()
        assert len(d["sections"]) == 1
        assert d["sections"][0]["name"] == "memories"

    def test_from_dict_nested(self):
        d = {
            "task": "nested test",
            "memories": [],
            "pitfalls": [],
            "environment": {},
            "instructions": [],
            "sections": [
                {
                    "name": "sys",
                    "budget": 100,
                    "used": 5,
                    "compression_level": "none",
                    "items": [{"content": "x", "tokens": 5, "priority": 1.0,
                                "added_at": "", "item_type": "text",
                                "metadata": {}, "schema_version": "2.2.0"}],
                    "overflow_warnings": [],
                    "schema_version": "2.2.0",
                }
            ],
            "total_budget": 4096,
            "total_used": 5,
            "strategy": "hybrid",
            "metadata": {},
            "schema_version": "2.2.0",
        }
        cp = ContextPacket.from_dict(d)
        assert cp.task == "nested test"
        assert isinstance(cp.sections[0], ContextSection)
        assert isinstance(cp.sections[0].items[0], ContextItem)

    def test_json_roundtrip(self):
        cp = ContextPacket(task="roundtrip", total_budget=2048, strategy="memory_first")
        cp2 = ContextPacket.from_json(cp.to_json())
        assert cp2.task == "roundtrip"
        assert cp2.total_budget == 2048
        assert cp2.strategy == "memory_first"


# ── Telemetry schemas ─────────────────────────────────────────────────────────

class TestTelemetryEvent:
    def test_default_instantiation(self):
        ev = TelemetryEvent(
            event_id="e1",
            timestamp="2026-02-20T00:00:00Z",
            module="guard",
            event_type="guard_decision",
        )
        assert ev.schema_version == "2.2.0"
        assert ev.evidence == []

    def test_with_performance(self):
        perf = PerformanceMetrics(latency_ms=45.2, cost_usd=0.000125)
        ev = TelemetryEvent(
            event_id="e2",
            timestamp="2026-02-20T00:00:00Z",
            module="router",
            event_type="route_selected",
            confidence=0.87,
            basis="classifier",
            performance=perf,
        )
        d = ev.to_dict()
        assert d["confidence"] == 0.87
        assert d["performance"]["latency_ms"] == 45.2

    def test_from_dict_with_performance(self):
        d = {
            "event_id": "e3",
            "timestamp": "2026-02-20T00:00:00Z",
            "session_id": "",
            "module": "memory",
            "event_type": "memory_retrieved",
            "confidence": 0.9,
            "basis": "quality_tracker",
            "evidence": ["term_match", "recency"],
            "payload": {"result_count": 4},
            "performance": {"latency_ms": 12.3, "schema_version": "2.2.0"},
            "correlations": [],
            "triggers": [],
            "schema_version": "2.2.0",
        }
        ev = TelemetryEvent.from_dict(d)
        assert ev.module == "memory"
        assert isinstance(ev.performance, PerformanceMetrics)
        assert ev.performance.latency_ms == 12.3

    def test_jsonl_line(self):
        ev = TelemetryEvent(event_id="e4", timestamp="2026-02-20T00:00:00Z",
                            module="pipeline", event_type="request_start")
        line = ev.to_jsonl_line()
        assert line.endswith("\n")
        parsed = json.loads(line.strip())
        assert parsed["event_id"] == "e4"

    def test_json_roundtrip(self):
        perf = PerformanceMetrics(latency_ms=100.0, cost_usd=0.001)
        ev = TelemetryEvent(
            event_id="e5",
            timestamp="2026-02-20T12:00:00Z",
            module="context",
            event_type="context_built",
            confidence=1.0,
            basis="context_budget",
            evidence=["token_count"],
            performance=perf,
            user_id="u-123",
        )
        ev2 = TelemetryEvent.from_json(ev.to_json())
        assert ev2.event_id == "e5"
        assert ev2.user_id == "u-123"
        assert ev2.performance.latency_ms == 100.0


# ── Migration ─────────────────────────────────────────────────────────────────

class TestMigration:
    def test_same_version_noop(self):
        data = {"content": "x", "schema_version": "2.2.0"}
        result = migrate(data)
        assert result == data
        assert result is not data  # deep copy

    def test_200_to_220(self):
        data = {"content": "old entry", "schema_version": "2.0.0"}
        result = migrate(data, to_version="2.2.0")
        assert result["schema_version"] == "2.2.0"
        assert result["memory_type"] == "episodic"
        assert result["type_metadata"] == {}
        assert result["correlations"] == []
        assert result["trace_id"] is None
        assert result["sla_compliant"] is True

    def test_211_to_220(self):
        data = {"model": "x", "tier": "simple", "schema_version": "2.1.1"}
        result = migrate(data, to_version="2.2.0")
        assert result["schema_version"] == "2.2.0"
        assert result["escalated"] is False
        assert result["sla_compliant"] is True
        assert result["supports_streaming"] is False

    def test_unknown_source_raises(self):
        with pytest.raises(MigrationError, match="Unknown source"):
            migrate({"schema_version": "9.9.9"})

    def test_unknown_target_raises(self):
        with pytest.raises(MigrationError, match="Unknown target"):
            migrate({"schema_version": "2.0.0"}, to_version="9.9.9")

    def test_downgrade_raises(self):
        with pytest.raises(MigrationError, match="Downgrade"):
            migrate({"schema_version": "2.2.0"}, to_version="2.0.0")

    def test_missing_schema_version_raises(self):
        with pytest.raises(MigrationError, match="Cannot determine"):
            migrate({"content": "no version"})

    def test_infers_from_version_from_data(self):
        data = {"content": "infer", "schema_version": "2.1.1"}
        result = migrate(data)
        assert result["schema_version"] == "2.2.0"

    def test_get_migration_path_direct(self):
        path = get_migration_path("2.0.0", "2.2.0")
        assert ("2.0.0", "2.2.0") in path or len(path) >= 1

    def test_get_migration_path_same(self):
        path = get_migration_path("2.2.0", "2.2.0")
        assert path == []

    def test_get_migration_path_step(self):
        path = get_migration_path("2.1.1", "2.2.0")
        assert len(path) >= 1

    def test_migration_preserves_existing_fields(self):
        data = {
            "content": "preserve me",
            "source": "manual",
            "importance": 0.75,
            "schema_version": "2.0.0",
        }
        result = migrate(data, to_version="2.2.0")
        assert result["content"] == "preserve me"
        assert result["source"] == "manual"
        assert result["importance"] == 0.75
