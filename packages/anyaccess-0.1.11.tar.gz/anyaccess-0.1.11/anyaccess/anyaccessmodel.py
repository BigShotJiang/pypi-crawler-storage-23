from datetime import datetime
from flask_login import UserMixin
from .anymodel import MiniPresent as MP, db

UserList = ['userid', 'username', 'name', 'usertype', 'email', 'mobilenumber', 'status', 'last_activity', 'date_created']
class User(UserMixin, db.Model):
  __tablename__ = 'access_user'
  id = db.Column(db.Integer, primary_key=True)
  userid = db.Column(db.String(50),unique=True)
  username = db.Column(db.String(50),unique=True)
  password = db.Column(db.String(100))
  name = db.Column(db.String(50))
  usertype = db.Column(db.String(50))
  email = db.Column(db.String(50))
  mobilenumber = db.Column(db.String(50))
  status = db.Column(db.Integer, default=0)
  last_activity = db.Column(db.DateTime) 
  date_created = db.Column(db.DateTime, default=datetime.now)

  @staticmethod
  def date_activity_check(last_activity):
    if not last_activity:
      return "no activity"
    
    diff = datetime.now() - last_activity
    seconds = diff.total_seconds()

    if seconds < 120: return "active now"
    if seconds < 3600: return f"active {int(divmod(seconds, 60)[0])} mins ago"
    if seconds < 86400: return f"active {int(divmod(seconds, 3600)[0])} hours ago"
    if seconds < 604800: return f"active {int(divmod(seconds, 86400)[0])} days ago"
    return str(last_activity)

  @staticmethod
  def jsonify(user):
    last_act = User.date_activity_check(user.last_activity)
    special_formats = {
        "status": MP.status_act(user.status),
        "last_activity": last_act,
        "date_created": str(user.date_created)
    }
    return {k: special_formats.get(k, getattr(user, k)) for k in UserList}

  @staticmethod
  def jsonify_list(user_list):
    jsoned_list = []
    for user in user_list:
      jsoned_list.append(User.jsonify(user))
    return jsoned_list

UserTypeList = ['usertype', 'tags', 'status', 'date_created']
class UserType(db.Model):
  __tablename__ = 'access_usertype'
  id = db.Column(db.Integer, primary_key=True)
  usertype = db.Column(db.String(50))
  tags = db.Column(db.String(500))
  status = db.Column(db.Integer, default=0)
  date_created = db.Column(db.DateTime, default=datetime.now)

  @staticmethod
  def jsonify(user):
    if user.tags is not None: user.tags = user.tags.replace(",",", ")
    special_formats = {
        "status": MP.status_act(user.status),
        "date_created": str(user.date_created)
    }
    return {k: special_formats.get(k, getattr(user, k)) for k in UserTypeList}

  @staticmethod
  def jsonify_list(user_list):
    jsoned_list = []
    for user in user_list:
      jsoned_list.append(UserType.jsonify(user))
    return jsoned_list

LogsList = ['service', 'logtype', 'action_by', 'log', 'date_created']
class Logs(db.Model):
  __tablename__ = 'access_logs'
  id = db.Column(db.Integer, primary_key=True)
  service = db.Column(db.String(50), default="access")
  logtype = db.Column(db.String(50))
  action_by = db.Column(db.String(50))
  log = db.Column(db.String(100))
  date_created = db.Column(db.DateTime, default=datetime.now)

  @staticmethod
  def jsonify(user):
    special_formats = {
        "date_created": str(user.date_created)
    }
    return {k: special_formats.get(k, getattr(user, k)) for k in LogsList}

  @staticmethod
  def jsonify_list(user_list):
    jsoned_list = []
    for user in user_list:
      jsoned_list.append(Logs.jsonify(user))
    return jsoned_list
