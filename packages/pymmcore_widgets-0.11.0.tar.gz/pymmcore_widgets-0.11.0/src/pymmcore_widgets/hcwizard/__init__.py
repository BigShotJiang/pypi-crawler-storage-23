"""Configuration wizard creating/editing a MicroManager configuration file."""

from .config_wizard import ConfigWizard

__all__ = ["ConfigWizard"]
