from pathlib import Path

from scrapling import Selector

from ioi_graph.sources.ioi.parsers import (
    CountriesPageParser,
    OlympiadsPageParser,
    PeoplePageParser,
    ResultsPageParser,
)


def _load_fixture(fixtures_dir: Path, name: str) -> Selector:
    html = (fixtures_dir / name).read_text()
    return Selector(html)


class TestOlympiadsPageParser:
    def test_parse_olympiads(self, fixtures_dir):
        page = _load_fixture(fixtures_dir, "olympiads.html")
        parser = OlympiadsPageParser()
        result = parser.parse(page)

        assert len(result) >= 36  # 1989-2025
        years = {o.year for o in result}
        assert 2024 in years
        assert 1989 in years

        o2024 = next(o for o in result if o.year == 2024)
        assert o2024.host_country_code == "EGY"
        assert o2024.host_city == "Alexandria"
        assert o2024.num_contestants is not None
        assert o2024.num_contestants > 300

    def test_can_parse(self):
        parser = OlympiadsPageParser()
        assert parser.can_parse("/olympiads/")
        assert not parser.can_parse("/results/2024")


class TestResultsPageParser:
    def test_parse_results_2024(self, fixtures_dir):
        page = _load_fixture(fixtures_dir, "results_2024.html")
        parser = ResultsPageParser()
        results = parser.parse(page, year=2024, url="/results/2024")

        assert len(results) > 350
        # Check first place
        first = next(r for r in results if r.rank == 1)
        assert first.contestant_name == "Kangyang Zhou"
        assert first.country_code == "CHN"
        assert first.award == "Gold"
        assert first.score_abs == 600.0
        assert first.score_rel == 100.0
        assert len(first.task_scores) == 6

    def test_task_names_extracted(self, fixtures_dir):
        page = _load_fixture(fixtures_dir, "results_2024.html")
        parser = ResultsPageParser()
        results = parser.parse(page, year=2024, url="/results/2024")

        first = results[0]
        task_names = [ts.name for ts in first.task_scores]
        assert "nile" in task_names
        assert "sphinx" in task_names

    def test_medal_detection(self, fixtures_dir):
        page = _load_fixture(fixtures_dir, "results_2024.html")
        parser = ResultsPageParser()
        results = parser.parse(page, year=2024, url="/results/2024")

        awards = {r.award for r in results if r.award}
        assert "Gold" in awards
        assert "Silver" in awards
        assert "Bronze" in awards


class TestCountriesPageParser:
    def test_parse_countries(self, fixtures_dir):
        page = _load_fixture(fixtures_dir, "countries.html")
        parser = CountriesPageParser()
        countries = parser.parse(page)

        assert len(countries) > 100
        codes = {c.code for c in countries}
        assert "CHN" in codes
        assert "USA" in codes

        china = next(c for c in countries if c.code == "CHN")
        assert china.name == "China"
        assert china.gold_medals > 0


class TestPeoplePageParser:
    def test_parse_person(self, fixtures_dir):
        page = _load_fixture(fixtures_dir, "people_6590.html")
        parser = PeoplePageParser()
        profile = parser.parse(page, person_id=6590, url="/people/6590")

        assert profile.id == 6590
        assert profile.name == "Jia Jun Lee"
        assert profile.country_code == "MYS"
        assert profile.codeforces_handle == "2xJelly"
