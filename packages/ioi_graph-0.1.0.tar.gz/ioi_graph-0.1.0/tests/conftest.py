import sqlite3
from pathlib import Path

import pytest

from ioi_graph.db.engine import ensure_schema

FIXTURES_DIR = Path(__file__).parent / "fixtures"


@pytest.fixture
def fixtures_dir():
    return FIXTURES_DIR


@pytest.fixture
def db_conn(tmp_path):
    db_path = tmp_path / "test.db"
    ensure_schema(db_path)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    yield conn
    conn.close()
