# IOI Contestant Graph

Scrape IOI contestant data, store in SQLite, and analyze contestant relationships as a graph.
