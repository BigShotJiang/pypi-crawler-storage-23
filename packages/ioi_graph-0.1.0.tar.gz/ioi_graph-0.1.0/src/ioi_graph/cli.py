import typer

from ioi_graph.commands import graph_cmd, linkedin, query, scrape

app = typer.Typer(
    name="ioi",
    help="IOI Contestant Graph — scrape, query, and analyze IOI data",
    no_args_is_help=True,
)

app.add_typer(scrape.app, name="scrape")
app.add_typer(query.app, name="query")
app.add_typer(graph_cmd.app, name="graph")
app.add_typer(linkedin.app, name="linkedin")

if __name__ == "__main__":
    app()
