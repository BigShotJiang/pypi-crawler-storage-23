from __future__ import annotations

from pydantic import BaseModel


class WorkExperience(BaseModel):
    company: str
    title: str | None = None
    start_year: int | None = None
    end_year: int | None = None  # None = current


class Education(BaseModel):
    school: str
    degree: str | None = None
    field_of_study: str | None = None
    start_year: int | None = None
    end_year: int | None = None


class LinkedInProfile(BaseModel):
    contestant_id: int
    linkedin_url: str
    headline: str | None = None
    location: str | None = None
    experiences: list[WorkExperience] = []
    education: list[Education] = []
