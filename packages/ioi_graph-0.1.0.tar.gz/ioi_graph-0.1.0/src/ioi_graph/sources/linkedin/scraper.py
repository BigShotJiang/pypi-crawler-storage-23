from __future__ import annotations

import sqlite3
from urllib.parse import quote_plus

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from ioi_graph.config import LINKEDIN_PROFILE_RATE_LIMIT
from ioi_graph.db.repositories import IOIRepository
from ioi_graph.scraping.base import BaseScraper
from ioi_graph.scraping.cache import ScrapeCache
from ioi_graph.scraping.session import LinkedInBrowserSession
from ioi_graph.sources.linkedin.models import LinkedInProfile
from ioi_graph.sources.linkedin.parsers import (
    AuthenticatedLinkedInParser,
    GoogleSearchParser,
)

console = Console()


class LinkedInScraper(BaseScraper):
    SOURCE = "linkedin"

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.repo = IOIRepository(conn)
        self.cache = ScrapeCache(conn)
        self.search_parser = GoogleSearchParser()
        self.profile_parser = AuthenticatedLinkedInParser()

    def get_source_name(self) -> str:
        return self.SOURCE

    def scrape_all(
        self,
        email: str,
        password: str,
        force: bool = False,
        headless: bool = True,
    ) -> None:
        """Scrape LinkedIn profiles for all contestants."""
        rows = self.conn.execute(
            "SELECT id, name FROM contestants ORDER BY id"
        ).fetchall()
        ids = [r["id"] for r in rows]
        self._scrape_ids(ids, email, password, force, headless)

    def scrape_ids(
        self,
        ids: list[int],
        email: str,
        password: str,
        force: bool = False,
        headless: bool = True,
    ) -> None:
        """Scrape LinkedIn profiles for specific contestant IDs."""
        self._scrape_ids(ids, email, password, force, headless)

    def search(self, name: str) -> list[str]:
        """Google search for LinkedIn profile URLs. Returns candidate URLs.

        This is a standalone method for the CLI `search` command — uses a
        one-off StealthyFetcher since no persistent session is running.
        """
        from scrapling import StealthyFetcher

        query = f'site:linkedin.com/in/ "{name}"'
        url = f"https://www.google.com/search?q={quote_plus(query)}"

        console.print(f"[dim]Searching: {query}[/dim]")
        page = StealthyFetcher.fetch(url, headless=True)
        if page.status != 200:
            console.print(f"[red]Google search returned HTTP {page.status}[/red]")
            return []
        return self.search_parser.parse(page)

    def show(self, contestant_id: int) -> LinkedInProfile | None:
        """Show stored LinkedIn data for a contestant."""
        profile = self.repo.get_linkedin_profile(contestant_id)
        if not profile:
            return None

        experiences_rows = self.repo.get_work_experiences(contestant_id)
        education_rows = self.repo.get_education(contestant_id)

        from ioi_graph.sources.linkedin.models import Education, WorkExperience

        return LinkedInProfile(
            contestant_id=contestant_id,
            linkedin_url=profile["linkedin_url"],
            headline=profile["headline"],
            location=profile["location"],
            experiences=[
                WorkExperience(
                    company=r["company"],
                    title=r["title"],
                    start_year=r["start_year"],
                    end_year=r["end_year"],
                )
                for r in experiences_rows
            ],
            education=[
                Education(
                    school=r["school"],
                    degree=r["degree"],
                    field_of_study=r["field_of_study"],
                    start_year=r["start_year"],
                    end_year=r["end_year"],
                )
                for r in education_rows
            ],
        )

    def _scrape_ids(
        self,
        ids: list[int],
        email: str,
        password: str,
        force: bool,
        headless: bool,
    ) -> None:
        skipped = 0
        scraped = 0
        failed = 0

        with LinkedInBrowserSession(
            email=email,
            password=password,
            headless=headless,
            rate_limit=LINKEDIN_PROFILE_RATE_LIMIT,
        ) as li_session:
            # Log in once for the whole batch
            console.print("[dim]Logging in to LinkedIn...[/dim]")
            try:
                li_session.login()
                console.print("[green]LinkedIn login successful[/green]")
            except RuntimeError as e:
                console.print(f"[red]Login failed: {e}[/red]")
                return

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Scraping LinkedIn profiles...", total=len(ids))
                for cid in ids:
                    contestant = self.repo.get_contestant(cid)
                    if not contestant:
                        progress.advance(task)
                        continue

                    name = contestant["name"]
                    progress.update(task, description=f"LinkedIn: {name} ({cid})")

                    key = f"profile/{cid}"
                    if not force and self.cache.is_fresh(self.SOURCE, key):
                        skipped += 1
                        progress.advance(task)
                        continue

                    try:
                        profile = self._scrape_one(cid, name, li_session)
                        if profile:
                            self._store_profile(profile)
                            self.cache.log_scrape(
                                self.SOURCE, key, profile.linkedin_url, "success", 200
                            )
                            scraped += 1
                        else:
                            skipped += 1
                    except Exception as e:
                        self.cache.log_scrape(
                            self.SOURCE, key, "", "error", error_message=str(e)
                        )
                        console.print(f"[red]  Error for {name}: {e}[/red]")
                        failed += 1

                    progress.advance(task)

        console.print(
            f"[bold green]LinkedIn scrape complete: "
            f"{scraped} scraped, {skipped} skipped, {failed} failed[/bold green]"
        )

    def _scrape_one(
        self,
        contestant_id: int,
        name: str,
        li_session: LinkedInBrowserSession,
    ) -> LinkedInProfile | None:
        """Search Google for LinkedIn URL, then scrape the profile via authenticated session."""
        # Step 1: Google search via the same browser session (can't open a
        # second Playwright instance — sync API event loop conflict)
        query = f'site:linkedin.com/in/ "{name}"'
        search_url = f"https://www.google.com/search?q={quote_plus(query)}"

        page = li_session.search_google(search_url)
        if page.status != 200:
            console.print(f"[yellow]  Google search failed (HTTP {page.status}) for {name}[/yellow]")
            return None

        urls = self.search_parser.parse(page)
        if not urls:
            console.print(f"[dim]  No LinkedIn profile found for {name}[/dim]")
            return None

        linkedin_url = urls[0]
        console.print(f"[dim]  Found: {linkedin_url}[/dim]")

        # Step 2: Fetch LinkedIn profile in authenticated session
        page = li_session.fetch_profile(linkedin_url)

        profile = self.profile_parser.parse(
            page,
            contestant_id=contestant_id,
            linkedin_url=linkedin_url,
        )
        exp_count = len(profile.experiences)
        edu_count = len(profile.education)
        console.print(
            f"[green]  {name}: {exp_count} experiences, {edu_count} education entries[/green]"
        )
        return profile

    def _store_profile(self, profile: LinkedInProfile) -> None:
        """Store LinkedIn profile, work experiences, and education in DB."""
        self.repo.upsert_linkedin_profile(
            contestant_id=profile.contestant_id,
            linkedin_url=profile.linkedin_url,
            headline=profile.headline,
            location=profile.location,
        )

        # Replace existing entries for this contestant
        self.repo.delete_work_experiences(profile.contestant_id)
        self.repo.delete_education(profile.contestant_id)

        for exp in profile.experiences:
            self.repo.upsert_work_experience(
                contestant_id=profile.contestant_id,
                company=exp.company,
                title=exp.title,
                start_year=exp.start_year,
                end_year=exp.end_year,
            )

        for edu in profile.education:
            self.repo.upsert_education(
                contestant_id=profile.contestant_id,
                school=edu.school,
                degree=edu.degree,
                field_of_study=edu.field_of_study,
                start_year=edu.start_year,
                end_year=edu.end_year,
            )

        self.conn.commit()
