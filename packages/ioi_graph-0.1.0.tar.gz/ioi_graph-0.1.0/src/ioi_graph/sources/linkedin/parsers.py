from __future__ import annotations

import json
import re
import tempfile
from pathlib import Path
from urllib.parse import urlparse

from ioi_graph.scraping.base import BaseParser
from ioi_graph.sources.linkedin.models import (
    Education,
    LinkedInProfile,
    WorkExperience,
)


def _parse_year_range(text: str) -> tuple[int | None, int | None]:
    """Parse date ranges like 'Jan 2020 - Present', '2018 - 2021', 'Sep 2019 - Jun 2023'.

    Returns (start_year, end_year) where end_year is None for 'Present'.
    """
    if not text:
        return None, None

    text = text.strip()

    # Check for "Present" or "current"
    is_current = bool(re.search(r"(?i)\bpresent\b", text))

    # Find all 4-digit years
    years = [int(y) for y in re.findall(r"\b((?:19|20)\d{2})\b", text)]

    start_year = years[0] if years else None
    if is_current:
        end_year = None
    elif len(years) >= 2:
        end_year = years[1]
    else:
        end_year = None

    return start_year, end_year


class GoogleSearchParser(BaseParser[list[str]]):
    """Parses Google search results to find LinkedIn profile URLs."""

    def can_parse(self, url: str) -> bool:
        return "google.com" in url

    def parse(self, page, **context) -> list[str]:
        urls: list[str] = []
        # Google search result links
        for link in page.css("a"):
            href = link.attrib.get("href", "")
            # Direct LinkedIn profile URLs
            if "linkedin.com/in/" in href:
                # Extract clean URL — Google wraps in redirect URLs sometimes
                clean = self._extract_linkedin_url(href)
                if clean and clean not in urls:
                    urls.append(clean)
        return urls

    @staticmethod
    def _extract_linkedin_url(href: str) -> str | None:
        """Extract a clean linkedin.com/in/ URL from a possibly wrapped href."""
        # If it's a direct LinkedIn URL with linkedin.com in the host
        if href.startswith("https://") and "linkedin.com/in/" in href:
            parsed = urlparse(href)
            if "linkedin.com" in parsed.netloc:
                path = parsed.path.rstrip("/")
                return f"{parsed.scheme}://{parsed.netloc}{path}"

        # Google redirect: /url?q=https://linkedin.com/in/...&sa=...
        match = re.search(r"https?://[a-z]+\.linkedin\.com/in/[^&\s\"']+", href)
        if match:
            url = match.group(0)
            parsed = urlparse(url)
            path = parsed.path.rstrip("/")
            return f"{parsed.scheme}://{parsed.netloc}{path}"

        return None


def _is_censored(text: str | None) -> bool:
    """Check if text is LinkedIn's censored placeholder (all asterisks)."""
    if not text:
        return True
    stripped = text.strip()
    if not stripped:
        return True
    # Censored entries are mostly * characters with spaces
    non_star = stripped.replace("*", "").replace(" ", "")
    return len(non_star) < max(1, len(stripped) // 4)


class LinkedInProfileParser(BaseParser[LinkedInProfile]):
    """Parses a public LinkedIn profile page for work history and education.

    Uses two data sources:
    1. JSON-LD (schema.org structured data) — richest source, has worksFor + alumniOf
    2. HTML "Experience & Education" section — only first item is unblurred

    LinkedIn censors most data on public profiles with asterisks. We filter those out.
    """

    def can_parse(self, url: str) -> bool:
        return "linkedin.com/in/" in url

    def parse(self, page, **context) -> LinkedInProfile:
        contestant_id = context["contestant_id"]
        linkedin_url = context["linkedin_url"]

        # Primary source: JSON-LD structured data
        jsonld = self._extract_jsonld(page)

        headline = self._parse_headline(page)
        location = self._parse_location(page, jsonld)
        experiences = self._parse_experiences_jsonld(jsonld)
        education = self._parse_education_jsonld(jsonld)

        # Supplement with HTML visible items if JSON-LD didn't yield enough
        if not experiences:
            experiences = self._parse_experiences_html(page)
        if not education:
            education = self._parse_education_html(page)

        return LinkedInProfile(
            contestant_id=contestant_id,
            linkedin_url=linkedin_url,
            headline=headline,
            location=location,
            experiences=experiences,
            education=education,
        )

    # ── JSON-LD extraction ──────────────────────────────────────

    def _extract_jsonld(self, page) -> dict | None:
        """Extract the Person object from JSON-LD script tag."""
        import json

        for script in page.css('script[type="application/ld+json"]'):
            try:
                data = json.loads(script.text)
            except (json.JSONDecodeError, TypeError):
                continue

            # JSON-LD can be a dict with @graph array or a direct object
            if isinstance(data, dict) and "@graph" in data:
                for item in data["@graph"]:
                    if item.get("@type") == "Person":
                        return item
            elif isinstance(data, dict) and data.get("@type") == "Person":
                return data
        return None

    def _parse_experiences_jsonld(self, jsonld: dict | None) -> list[WorkExperience]:
        """Extract work experiences from JSON-LD worksFor array."""
        if not jsonld:
            return []

        experiences: list[WorkExperience] = []
        for org in jsonld.get("worksFor", []):
            company = org.get("name", "")
            if _is_censored(company):
                continue

            member = org.get("member", {})
            start_date = member.get("startDate")
            end_date = member.get("endDate")

            # JSON-LD dates are integers (years) or strings
            start_year = int(start_date) if start_date else None
            end_year = int(end_date) if end_date else None

            experiences.append(WorkExperience(
                company=company.strip(),
                title=None,  # Job titles are censored in JSON-LD
                start_year=start_year,
                end_year=end_year,
            ))

        return experiences

    def _parse_education_jsonld(self, jsonld: dict | None) -> list[Education]:
        """Extract education from JSON-LD alumniOf array."""
        if not jsonld:
            return []

        education: list[Education] = []
        for org in jsonld.get("alumniOf", []):
            school = org.get("name", "")
            if _is_censored(school):
                continue

            member = org.get("member", {})
            start_date = member.get("startDate")
            end_date = member.get("endDate")

            start_year = int(start_date) if start_date else None
            end_year = int(end_date) if end_date else None

            education.append(Education(
                school=school.strip(),
                degree=None,
                field_of_study=None,
                start_year=start_year,
                end_year=end_year,
            ))

        return education

    # ── Top card parsing ────────────────────────────────────────

    def _parse_headline(self, page) -> str | None:
        """Parse headline from the meta description or top card."""
        # Meta description often starts with "Experience: Company · Education: School"
        # which isn't a headline. Use the page title instead: "Name - Company | LinkedIn"
        titles = page.css("title")
        if titles:
            title_text = titles[0].text.strip()
            # Format: "Scott Wu - Rakuten | LinkedIn"
            if " | LinkedIn" in title_text:
                headline = title_text.replace(" | LinkedIn", "").strip()
                # Remove the name prefix: "Scott Wu - Rakuten" -> "Rakuten"
                if " - " in headline:
                    return headline.split(" - ", 1)[1].strip()
                return headline
        return None

    def _parse_location(self, page, jsonld: dict | None) -> str | None:
        """Parse location from JSON-LD address or top card."""
        if jsonld:
            address = jsonld.get("address", {})
            locality = address.get("addressLocality")
            if locality and not _is_censored(locality):
                return locality

        # Fallback: top card subline
        el = page.css("h3.top-card-layout__first-subline")
        if el:
            text = el[0].text.strip()
            if text:
                return text
        return None

    # ── HTML fallback parsing ───────────────────────────────────

    def _parse_experiences_html(self, page) -> list[WorkExperience]:
        """Fallback: parse visible experience items from HTML."""
        section = self._find_experience_education_section(page)
        if not section:
            return []

        experiences: list[WorkExperience] = []
        # Only parse items in the visible list (not blurred)
        visible = section.css("ul.visible-list")
        if not visible:
            return []

        for item in visible[0].css("li.profile-section-card"):
            exp = self._parse_card_as_experience(item)
            if exp:
                experiences.append(exp)

        return experiences

    def _parse_education_html(self, page) -> list[Education]:
        """Fallback: parse visible education items from HTML."""
        section = self._find_experience_education_section(page)
        if not section:
            return []

        education: list[Education] = []
        # Look in both visible and blurred lists for education entries
        # (education entries have date-range spans and school-like names)
        for item in section.css("li.profile-section-card"):
            date_spans = item.css("span.date-range")
            if not date_spans:
                continue
            edu = self._parse_card_as_education(item)
            if edu:
                education.append(edu)

        return education

    def _find_experience_education_section(self, page):
        """Find the combined Experience & Education section."""
        sections = page.css("section.experience-education")
        if sections:
            return sections[0]
        # Fallback: find by heading text
        for section in page.css("section"):
            headings = section.css("h2")
            for h in headings:
                text = h.text.strip().lower()
                if "experience" in text and "education" in text:
                    return section
        return None

    def _parse_card_as_experience(self, item) -> WorkExperience | None:
        """Parse a profile-section-card as a work experience entry."""
        h3 = item.css("h3")
        if not h3:
            return None
        company = h3[0].text.strip()
        if _is_censored(company):
            return None

        title = None
        p_tags = item.css("p")
        for p in p_tags:
            if "blur" in (p.attrib.get("class", "")):
                continue
            text = p.text.strip()
            if text and not _is_censored(text):
                title = text
                break

        # Parse date range from <span class="date-range"> > <time> elements
        start_year, end_year = self._parse_date_range_from_card(item)

        return WorkExperience(
            company=company,
            title=title,
            start_year=start_year,
            end_year=end_year,
        )

    def _parse_card_as_education(self, item) -> Education | None:
        """Parse a profile-section-card as an education entry."""
        h3 = item.css("h3")
        if not h3:
            return None
        school = h3[0].text.strip()
        if _is_censored(school):
            return None

        degree = None
        p_tags = item.css("p")
        for p in p_tags:
            if "blur" in (p.attrib.get("class", "")):
                continue
            text = p.text.strip()
            if text and not _is_censored(text) and "undefined" not in text:
                degree = text
                break

        start_year, end_year = self._parse_date_range_from_card(item)

        return Education(
            school=school,
            degree=degree,
            field_of_study=None,
            start_year=start_year,
            end_year=end_year,
        )

    def _parse_date_range_from_card(self, item) -> tuple[int | None, int | None]:
        """Extract years from <span class="date-range"> containing <time> elements."""
        date_spans = item.css("span.date-range")
        if date_spans:
            time_els = date_spans[0].css("time")
            if time_els:
                years = []
                for t in time_els:
                    text = t.text.strip()
                    if text.isdigit():
                        years.append(int(text))
                if len(years) >= 2:
                    return years[0], years[1]
                elif len(years) == 1:
                    return years[0], None
            # Fallback to text parsing
            return _parse_year_range(date_spans[0].text)
        return None, None


class AuthenticatedLinkedInParser(BaseParser[LinkedInProfile]):
    """Parses a logged-in LinkedIn profile page.

    The authenticated DOM structure differs from public profiles.
    Uses a multi-phase approach:
    1. JSON-LD (may still be present on logged-in pages)
    2. Logged-in DOM selectors for experience/education sections
    3. Saves raw HTML to /tmp/ for debugging if parsing yields nothing
    """

    def can_parse(self, url: str) -> bool:
        return "linkedin.com/in/" in url

    def parse(self, page, **context) -> LinkedInProfile:
        contestant_id = context["contestant_id"]
        linkedin_url = context["linkedin_url"]

        # Phase 1: Try JSON-LD (works on both public and authenticated pages)
        jsonld = self._extract_jsonld(page)

        headline = self._parse_headline(page)
        location = self._parse_location(page, jsonld)

        # Phase 2: Parse experiences and education
        experiences = self._parse_experiences_jsonld(jsonld)
        education = self._parse_education_jsonld(jsonld)

        # Phase 3: Try logged-in DOM selectors
        if not experiences:
            experiences = self._parse_experiences_authenticated(page)
        if not education:
            education = self._parse_education_authenticated(page)

        # Phase 4: If we got nothing, dump HTML for debugging
        if not experiences and not education:
            self._dump_debug_html(page, contestant_id)

        return LinkedInProfile(
            contestant_id=contestant_id,
            linkedin_url=linkedin_url,
            headline=headline,
            location=location,
            experiences=experiences,
            education=education,
        )

    # ── JSON-LD extraction (same as public parser) ──────────────

    def _extract_jsonld(self, page) -> dict | None:
        for script in page.css('script[type="application/ld+json"]'):
            try:
                data = json.loads(script.text)
            except (json.JSONDecodeError, TypeError):
                continue
            if isinstance(data, dict) and "@graph" in data:
                for item in data["@graph"]:
                    if item.get("@type") == "Person":
                        return item
            elif isinstance(data, dict) and data.get("@type") == "Person":
                return data
        return None

    def _parse_experiences_jsonld(self, jsonld: dict | None) -> list[WorkExperience]:
        if not jsonld:
            return []
        experiences: list[WorkExperience] = []
        for org in jsonld.get("worksFor", []):
            company = org.get("name", "")
            if _is_censored(company):
                continue
            member = org.get("member", {})
            start_year = int(s) if (s := member.get("startDate")) else None
            end_year = int(e) if (e := member.get("endDate")) else None
            experiences.append(WorkExperience(
                company=company.strip(),
                title=None,
                start_year=start_year,
                end_year=end_year,
            ))
        return experiences

    def _parse_education_jsonld(self, jsonld: dict | None) -> list[Education]:
        if not jsonld:
            return []
        education: list[Education] = []
        for org in jsonld.get("alumniOf", []):
            school = org.get("name", "")
            if _is_censored(school):
                continue
            member = org.get("member", {})
            start_year = int(s) if (s := member.get("startDate")) else None
            end_year = int(e) if (e := member.get("endDate")) else None
            education.append(Education(
                school=school.strip(),
                start_year=start_year,
                end_year=end_year,
            ))
        return education

    # ── Headline / Location ─────────────────────────────────────

    def _parse_headline(self, page) -> str | None:
        # Logged-in profile: headline is in the top card
        for sel in [
            "div.text-body-medium.break-words",
            "div.pv-text-details__left-panel div.text-body-medium",
            "h2.mt1.t-18",
        ]:
            els = page.css(sel)
            if els:
                text = els[0].text.strip()
                if text and not _is_censored(text):
                    return text

        # Fallback: page title
        titles = page.css("title")
        if titles:
            title_text = titles[0].text.strip()
            if " | LinkedIn" in title_text:
                headline = title_text.replace(" | LinkedIn", "").strip()
                if " - " in headline:
                    return headline.split(" - ", 1)[1].strip()
                return headline
        return None

    def _parse_location(self, page, jsonld: dict | None) -> str | None:
        if jsonld:
            address = jsonld.get("address", {})
            locality = address.get("addressLocality")
            if locality and not _is_censored(locality):
                return locality

        # Logged-in profile location selectors
        for sel in [
            "span.text-body-small.inline.t-black--light.break-words",
            "div.pv-text-details__left-panel span.text-body-small",
        ]:
            els = page.css(sel)
            if els:
                text = els[0].text.strip()
                if text and not _is_censored(text):
                    return text
        return None

    # ── Authenticated DOM parsing ───────────────────────────────

    def _parse_experiences_authenticated(self, page) -> list[WorkExperience]:
        """Parse experience entries from logged-in LinkedIn DOM."""
        experiences: list[WorkExperience] = []

        # Find the experience section by its id or heading
        section = self._find_section(page, "experience")
        if not section:
            return []

        for item in section.css("li.artdeco-list__item"):
            exp = self._parse_experience_item(item)
            if exp:
                experiences.append(exp)

        return experiences

    def _parse_education_authenticated(self, page) -> list[Education]:
        """Parse education entries from logged-in LinkedIn DOM."""
        education: list[Education] = []

        section = self._find_section(page, "education")
        if not section:
            return []

        for item in section.css("li.artdeco-list__item"):
            edu = self._parse_education_item(item)
            if edu:
                education.append(edu)

        return education

    def _find_section(self, page, section_name: str):
        """Find a profile section by id anchor or heading text."""
        # Try id-based lookup (e.g., #experience, #education)
        anchors = page.css(f"section#{section_name}")
        if anchors:
            return anchors[0]

        # Try data-section attribute
        for section in page.css("section.artdeco-card"):
            # Check for an anchor with matching id inside the section
            inner_anchors = section.css(f"div#{section_name}")
            if inner_anchors:
                return section
            # Check heading text
            for h2 in section.css("h2 span.visually-hidden, h2 span"):
                if section_name.lower() in h2.text.strip().lower():
                    return section
        return None

    def _parse_experience_item(self, item) -> WorkExperience | None:
        """Parse a single experience list item from authenticated DOM."""
        company = None
        title = None

        # Bold text = title (e.g., "Co-Founder and CEO")
        # Note: t-bold is on a <div>, not <span>, so use element-agnostic selector
        bold_spans = item.css(".t-bold span[aria-hidden='true']")
        if not bold_spans:
            bold_spans = item.css(".t-bold")
        if bold_spans:
            title = bold_spans[0].text.strip()
            if _is_censored(title):
                title = None

        # Normal text = company (e.g., "Cognition · Full-time")
        normal_spans = item.css("span.t-normal span[aria-hidden='true']")
        if not normal_spans:
            normal_spans = item.css("span.t-14.t-normal")
        if normal_spans:
            for span in normal_spans:
                text = span.text.strip().rstrip(" ·").strip()
                if text and not _is_censored(text) and text != title:
                    company = text
                    break

        if not company and not title:
            return None

        # If we only got a title but no company, it might be a single-role entry
        # where the bold text is actually the company
        if not company and title:
            company = title
            title = None

        start_year, end_year = self._parse_date_range_authenticated(item)

        return WorkExperience(
            company=company,
            title=title,
            start_year=start_year,
            end_year=end_year,
        )

    def _parse_education_item(self, item) -> Education | None:
        """Parse a single education list item from authenticated DOM."""
        school = None
        degree = None

        # Bold text = school name (e.g., "Harvard University")
        # Note: t-bold is on a <div>, not <span>, so use element-agnostic selector
        bold_els = item.css(".t-bold span[aria-hidden='true']")
        if not bold_els:
            bold_els = item.css(".t-bold")
        if bold_els:
            school = bold_els[0].text.strip()
            if _is_censored(school):
                return None

        if not school:
            return None

        # Normal text = degree/field (e.g., "Economics")
        normal_spans = item.css("span.t-normal span[aria-hidden='true']")
        if not normal_spans:
            normal_spans = item.css("span.t-14.t-normal")
        if normal_spans:
            for span in normal_spans:
                text = span.text.strip().rstrip(" ·").strip()
                if text and not _is_censored(text) and text != school:
                    degree = text
                    break

        start_year, end_year = self._parse_date_range_authenticated(item)

        return Education(
            school=school,
            degree=degree,
            field_of_study=None,
            start_year=start_year,
            end_year=end_year,
        )

    def _parse_date_range_authenticated(self, item) -> tuple[int | None, int | None]:
        """Extract year range from an authenticated profile list item."""
        # Date ranges appear in lighter/smaller text spans
        for span in item.css("span.t-normal.t-black--light span[aria-hidden='true']"):
            text = span.text.strip()
            years = re.findall(r"\b((?:19|20)\d{2})\b", text)
            if years:
                is_present = bool(re.search(r"(?i)\bpresent\b", text))
                start = int(years[0])
                end = None if is_present else (int(years[1]) if len(years) >= 2 else None)
                return start, end

        # Broader fallback: search all text in the item for year patterns
        full_text = item.text if hasattr(item, "text") else ""
        return _parse_year_range(full_text)

    # ── Debug helper ────────────────────────────────────────────

    @staticmethod
    def _dump_debug_html(page, contestant_id: int) -> None:
        """Save raw HTML to /tmp/ for debugging when parsing yields nothing."""
        html = page.html_content if hasattr(page, "html_content") else str(page)
        path = Path(tempfile.gettempdir()) / f"linkedin_debug_{contestant_id}.html"
        path.write_text(html, encoding="utf-8")
        from rich.console import Console
        Console().print(
            f"[yellow]  No data parsed — raw HTML saved to {path}[/yellow]"
        )
