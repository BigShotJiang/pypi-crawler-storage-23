from __future__ import annotations

from pydantic import BaseModel


class OlympiadSummary(BaseModel):
    year: int
    dates: str | None = None
    host_country_code: str | None = None
    host_city: str | None = None
    num_contestants: int | None = None
    num_countries: int | None = None


class TaskScore(BaseModel):
    position: int
    name: str | None = None
    score: float | None = None
    max_score: float | None = None


class ContestantResult(BaseModel):
    contestant_id: int
    contestant_name: str
    country_code: str
    year: int
    rank: int | None = None
    task_scores: list[TaskScore] = []
    score_abs: float | None = None
    score_rel: float | None = None
    award: str | None = None


class ContestantProfile(BaseModel):
    id: int
    name: str
    country_code: str | None = None
    codeforces_handle: str | None = None
    email: str | None = None


class CountryInfo(BaseModel):
    code: str
    name: str
    gold_medals: int = 0
    silver_medals: int = 0
    bronze_medals: int = 0
    first_participation_year: int | None = None
