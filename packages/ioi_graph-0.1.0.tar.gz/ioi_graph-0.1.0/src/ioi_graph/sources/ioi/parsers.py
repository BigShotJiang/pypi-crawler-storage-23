from __future__ import annotations

import re

from ioi_graph.scraping.base import BaseParser
from ioi_graph.sources.ioi.models import (
    ContestantProfile,
    ContestantResult,
    CountryInfo,
    OlympiadSummary,
    TaskScore,
)


def _parse_float(text: str | None) -> float | None:
    if not text:
        return None
    text = text.strip().rstrip("%")
    try:
        return float(text)
    except ValueError:
        return None


def _parse_int(text: str | None) -> int | None:
    if not text:
        return None
    text = text.strip().rstrip("*")
    try:
        return int(text)
    except ValueError:
        return None


def _extract_id_from_href(href: str, prefix: str) -> int | None:
    """Extract numeric ID from href like 'people/8272' or '/people/8272'."""
    match = re.search(rf"{prefix}/(\d+)", href)
    return int(match.group(1)) if match else None


def _extract_code_from_href(href: str, prefix: str) -> str | None:
    """Extract code from href like 'countries/CHN' or 'delegations/CHN/2024'."""
    match = re.search(rf"{prefix}/([A-Z]{{3}})", href)
    return match.group(1) if match else None


class OlympiadsPageParser(BaseParser[list[OlympiadSummary]]):
    def can_parse(self, url: str) -> bool:
        return "/olympiads" in url

    def parse(self, page, **context) -> list[OlympiadSummary]:
        results = []
        rows = page.css("table tr")
        for row in rows:
            cells = row.css("td")
            if not cells:
                continue

            links = row.css("a")
            year = None
            host_country_code = None
            for link in links:
                href = link.attrib.get("href", "")
                if "olympiads/" in href:
                    year_match = re.search(r"olympiads/(\d+)", href)
                    if year_match:
                        year = int(year_match.group(1))
                elif "countries/" in href:
                    host_country_code = _extract_code_from_href(href, "countries")

            if year is None:
                continue

            # Cells: No, Year(link), Dates, Host(link), City, Contestants, Countries
            # But cell.text may be empty for link cells, so extract from links
            dates = cells[2].text.strip() if len(cells) > 2 else None
            host_city = cells[4].text.strip() if len(cells) > 4 else None
            num_contestants = _parse_int(cells[5].text) if len(cells) > 5 else None
            num_countries = _parse_int(cells[6].text) if len(cells) > 6 else None

            results.append(
                OlympiadSummary(
                    year=year,
                    dates=dates or None,
                    host_country_code=host_country_code,
                    host_city=host_city or None,
                    num_contestants=num_contestants,
                    num_countries=num_countries,
                )
            )
        return results


class ResultsPageParser(BaseParser[list[ContestantResult]]):
    def can_parse(self, url: str) -> bool:
        return "/results/" in url

    def parse(self, page, **context) -> list[ContestantResult]:
        year = context.get("year")
        if year is None:
            match = re.search(r"/results/(\d+)", context.get("url", ""))
            if match:
                year = int(match.group(1))

        results = []
        rows = page.css("table tr")

        # Extract task names from header row
        task_names = []
        if rows:
            header = rows[0]
            for th in header.css("th"):
                cls = th.attrib.get("class", "")
                if "taskscore" in cls:
                    link = th.css("a")
                    if link:
                        href = link[0].attrib.get("href", "")
                        # Extract task name from href like 'tasks/2024/nile'
                        task_match = re.search(r"tasks/\d+/(\w+)", href)
                        task_names.append(task_match.group(1) if task_match else link[0].text.strip())
                    else:
                        task_names.append(th.text.strip())

        for row in rows:
            cells = row.css("td")
            if not cells or len(cells) < 5:
                continue

            # Extract contestant ID and name from cell 1
            name_link = cells[1].css("a")
            if not name_link:
                continue
            href = name_link[0].attrib.get("href", "")
            contestant_id = _extract_id_from_href(href, "people")
            if contestant_id is None:
                continue
            contestant_name = name_link[0].text.strip()

            # Extract country code from cell 2
            country_link = cells[2].css("a")
            country_code = None
            if country_link:
                country_code = _extract_code_from_href(
                    country_link[0].attrib.get("href", ""), "countries"
                )

            # Rank from cell 0
            rank = _parse_int(cells[0].text)

            # Award from cell class (gold, silver, bronze) or last cell text
            award_cell = cells[0]
            award_class = award_cell.attrib.get("class", "")
            if "gold" in award_class:
                award = "Gold"
            elif "silver" in award_class:
                award = "Silver"
            elif "bronze" in award_class:
                award = "Bronze"
            else:
                # Try last cell text
                last_text = cells[-1].text.strip() if cells else ""
                award = last_text if last_text in ("Gold", "Silver", "Bronze", "Honourable Mention") else None

            # Task scores: cells between country and total score
            # Structure: rank, name, country, [task scores...], total, rel%, award
            num_tasks = len(task_names)
            task_score_cells = cells[3 : 3 + num_tasks]
            task_scores = []
            for pos, task_cell in enumerate(task_score_cells):
                score = _parse_float(task_cell.text)
                name = task_names[pos] if pos < len(task_names) else None
                task_scores.append(
                    TaskScore(position=pos, name=name, score=score, max_score=100.0)
                )

            # Total score and relative score
            score_abs_idx = 3 + num_tasks
            score_rel_idx = score_abs_idx + 1
            score_abs = _parse_float(cells[score_abs_idx].text) if len(cells) > score_abs_idx else None
            score_rel = _parse_float(cells[score_rel_idx].text) if len(cells) > score_rel_idx else None

            results.append(
                ContestantResult(
                    contestant_id=contestant_id,
                    contestant_name=contestant_name,
                    country_code=country_code or "UNK",
                    year=year,
                    rank=rank,
                    task_scores=task_scores,
                    score_abs=score_abs,
                    score_rel=score_rel,
                    award=award,
                )
            )
        return results


class PeoplePageParser(BaseParser[ContestantProfile]):
    def can_parse(self, url: str) -> bool:
        return "/people/" in url

    def parse(self, page, **context) -> ContestantProfile:
        person_id = context.get("person_id")
        if person_id is None:
            match = re.search(r"/people/(\d+)", context.get("url", ""))
            if match:
                person_id = int(match.group(1))

        # Get name from page title
        title = page.css("title")
        name = title[0].text.strip() if title else "Unknown"

        # Get country from first participation row
        country_code = None
        table = page.css("table")
        if table:
            for row in table[0].css("tr"):
                cells = row.css("td")
                if len(cells) >= 2:
                    country_link = cells[1].css("a")
                    if country_link:
                        href = country_link[0].attrib.get("href", "")
                        country_code = _extract_code_from_href(href, "delegations")
                        if country_code:
                            break

        # Check for codeforces handle
        codeforces_handle = None
        for link in page.css("a"):
            href = link.attrib.get("href", "")
            if "codeforces.com/profile" in href:
                match = re.search(r"codeforces\.com/profile/([^/\s]+)", href)
                if match:
                    codeforces_handle = match.group(1)
                break

        return ContestantProfile(
            id=person_id,
            name=name,
            country_code=country_code,
            codeforces_handle=codeforces_handle,
        )


class CountriesPageParser(BaseParser[list[CountryInfo]]):
    def can_parse(self, url: str) -> bool:
        return "/countries" in url

    def parse(self, page, **context) -> list[CountryInfo]:
        results = []
        rows = page.css("table tr")
        for row in rows:
            cells = row.css("td")
            if not cells or len(cells) < 6:
                continue

            country_link = cells[1].css("a")
            if not country_link:
                continue
            href = country_link[0].attrib.get("href", "")
            code = _extract_code_from_href(href, "countries")
            if not code:
                continue
            name = country_link[0].text.strip()

            # IOI Host year
            host_text = cells[2].text.strip() if len(cells) > 2 else ""
            first_year = None
            if host_text:
                year_match = re.search(r"\d{4}", host_text)
                if year_match:
                    first_year = int(year_match.group())

            gold = _parse_int(cells[3].text) or 0
            silver = _parse_int(cells[4].text) or 0
            bronze = _parse_int(cells[5].text) or 0

            results.append(
                CountryInfo(
                    code=code,
                    name=name,
                    gold_medals=gold,
                    silver_medals=silver,
                    bronze_medals=bronze,
                    first_participation_year=first_year,
                )
            )
        return results
