from __future__ import annotations

import sqlite3

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from ioi_graph.config import IOI_BASE_URL
from ioi_graph.db.repositories import IOIRepository
from ioi_graph.scraping.base import BaseScraper
from ioi_graph.scraping.cache import ScrapeCache
from ioi_graph.scraping.session import ScrapingSession
from ioi_graph.sources.ioi.parsers import (
    CountriesPageParser,
    OlympiadsPageParser,
    PeoplePageParser,
    ResultsPageParser,
)

console = Console()


class IOIScraper(BaseScraper):
    SOURCE = "ioi"

    def __init__(
        self,
        conn: sqlite3.Connection,
        rate_limit: float = 0.5,
    ):
        self.conn = conn
        self.repo = IOIRepository(conn)
        self.cache = ScrapeCache(conn)
        self.rate_limit = rate_limit

        self.olympiads_parser = OlympiadsPageParser()
        self.results_parser = ResultsPageParser()
        self.people_parser = PeoplePageParser()
        self.countries_parser = CountriesPageParser()

    def get_source_name(self) -> str:
        return self.SOURCE

    def scrape_all(self, force: bool = False) -> None:
        with ScrapingSession(rate_limit=self.rate_limit) as session:
            self._scrape_olympiads(session, force)
            self._scrape_countries(session, force)
            years = self.repo.get_all_years()
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Scraping results...", total=len(years))
                for year in years:
                    progress.update(task, description=f"Scraping results/{year}...")
                    self._scrape_results(session, year, force)
                    progress.advance(task)

    def scrape_year(self, year: int, force: bool = False) -> None:
        with ScrapingSession(rate_limit=self.rate_limit) as session:
            # Ensure countries and olympiad entry exist
            self._scrape_countries(session, force=False)
            if not self.repo.get_olympiad(year):
                self._scrape_olympiads(session, force=True)
            self._scrape_results(session, year, force)

    def scrape_people(
        self, ids: list[int] | None = None, force: bool = False
    ) -> None:
        if ids is None:
            # Get all contestant IDs from DB
            rows = self.conn.execute("SELECT id FROM contestants ORDER BY id").fetchall()
            ids = [r["id"] for r in rows]

        with ScrapingSession(rate_limit=self.rate_limit) as session:
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                console=console,
            ) as progress:
                task = progress.add_task("Scraping profiles...", total=len(ids))
                for person_id in ids:
                    progress.update(
                        task, description=f"Scraping people/{person_id}..."
                    )
                    self._scrape_person(session, person_id, force)
                    progress.advance(task)

    # ── Internal methods ─────────────────────────────────────────

    def _scrape_olympiads(self, session: ScrapingSession, force: bool) -> None:
        key = "olympiads"
        if not force and self.cache.is_fresh(self.SOURCE, key):
            console.print("[dim]Olympiads page is fresh, skipping[/dim]")
            return

        url = f"{IOI_BASE_URL}/olympiads/"
        console.print(f"Fetching {url}")
        try:
            page = session.get(url)
            if page.status != 200:
                self.cache.log_scrape(self.SOURCE, key, url, "error", page.status)
                console.print(f"[red]HTTP {page.status} for {url}[/red]")
                return

            olympiads = self.olympiads_parser.parse(page)
            for o in olympiads:
                self.repo.upsert_olympiad(
                    year=o.year,
                    host_country_code=o.host_country_code,
                    host_city=o.host_city,
                    dates=o.dates,
                    num_contestants=o.num_contestants,
                    num_countries=o.num_countries,
                )
            self.conn.commit()
            self.cache.log_scrape(self.SOURCE, key, url, "success", 200)
            console.print(f"[green]Parsed {len(olympiads)} olympiads[/green]")
        except Exception as e:
            self.cache.log_scrape(self.SOURCE, key, url, "error", error_message=str(e))
            console.print(f"[red]Error scraping olympiads: {e}[/red]")
            raise

    def _scrape_countries(self, session: ScrapingSession, force: bool) -> None:
        key = "countries"
        if not force and self.cache.is_fresh(self.SOURCE, key):
            console.print("[dim]Countries page is fresh, skipping[/dim]")
            return

        url = f"{IOI_BASE_URL}/countries/"
        console.print(f"Fetching {url}")
        try:
            page = session.get(url)
            if page.status != 200:
                self.cache.log_scrape(self.SOURCE, key, url, "error", page.status)
                console.print(f"[red]HTTP {page.status} for {url}[/red]")
                return

            countries = self.countries_parser.parse(page)
            for c in countries:
                self.repo.upsert_country(
                    code=c.code,
                    name=c.name,
                    gold=c.gold_medals,
                    silver=c.silver_medals,
                    bronze=c.bronze_medals,
                    first_year=c.first_participation_year,
                )
            self.conn.commit()
            self.cache.log_scrape(self.SOURCE, key, url, "success", 200)
            console.print(f"[green]Parsed {len(countries)} countries[/green]")
        except Exception as e:
            self.cache.log_scrape(self.SOURCE, key, url, "error", error_message=str(e))
            console.print(f"[red]Error scraping countries: {e}[/red]")
            raise

    def _scrape_results(
        self, session: ScrapingSession, year: int, force: bool
    ) -> None:
        key = f"results/{year}"
        if not force and self.cache.is_fresh(self.SOURCE, key):
            return

        url = f"{IOI_BASE_URL}/results/{year}"
        try:
            page = session.get(url)
            if page.status != 200:
                self.cache.log_scrape(self.SOURCE, key, url, "error", page.status)
                console.print(f"[red]HTTP {page.status} for {url}[/red]")
                return

            contestant_results = self.results_parser.parse(
                page, year=year, url=url
            )

            for cr in contestant_results:
                # Upsert contestant
                self.repo.upsert_contestant(
                    id=cr.contestant_id,
                    name=cr.contestant_name,
                    country_code=cr.country_code,
                    profile_url=f"{IOI_BASE_URL}/people/{cr.contestant_id}",
                )

                # Upsert participation
                participation_id = self.repo.upsert_participation(
                    contestant_id=cr.contestant_id,
                    year=cr.year,
                    country_code=cr.country_code,
                    rank=cr.rank,
                    score_abs=cr.score_abs,
                    score_rel=cr.score_rel,
                    award=cr.award,
                )

                # Upsert task scores
                for ts in cr.task_scores:
                    self.repo.upsert_task_score(
                        participation_id=participation_id,
                        task_position=ts.position,
                        task_name=ts.name,
                        score=ts.score,
                        max_score=ts.max_score,
                    )

            self.conn.commit()
            self.repo.mark_results_scraped(year)
            self.conn.commit()
            self.cache.log_scrape(self.SOURCE, key, url, "success", 200)
            console.print(
                f"[green]  {year}: {len(contestant_results)} contestants[/green]"
            )
        except Exception as e:
            self.cache.log_scrape(
                self.SOURCE, key, url, "error", error_message=str(e)
            )
            console.print(f"[red]Error scraping results/{year}: {e}[/red]")
            raise

    def _scrape_person(
        self, session: ScrapingSession, person_id: int, force: bool
    ) -> None:
        key = f"people/{person_id}"
        if not force and self.cache.is_fresh("profile", key):
            return

        url = f"{IOI_BASE_URL}/people/{person_id}"
        try:
            page = session.get(url)
            if page.status != 200:
                self.cache.log_scrape("profile", key, url, "error", page.status)
                return

            profile = self.people_parser.parse(
                page, person_id=person_id, url=url
            )
            self.repo.update_contestant_profile(
                id=profile.id,
                codeforces_handle=profile.codeforces_handle,
                email=profile.email,
            )
            self.conn.commit()
            self.cache.log_scrape("profile", key, url, "success", 200)
        except Exception as e:
            self.cache.log_scrape(
                "profile", key, url, "error", error_message=str(e)
            )
            console.print(
                f"[red]Error scraping people/{person_id}: {e}[/red]"
            )
