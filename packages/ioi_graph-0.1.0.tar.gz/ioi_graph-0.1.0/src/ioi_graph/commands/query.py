from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ioi_graph.config import DEFAULT_DB_PATH
from ioi_graph.db.engine import ensure_schema, get_connection
from ioi_graph.db.repositories import IOIRepository

app = typer.Typer(help="Query IOI data")
console = Console()


def _get_repo(db: Path) -> IOIRepository:
    ensure_schema(db)
    return IOIRepository(get_connection(db))


@app.command()
def contestant(
    query: str = typer.Argument(..., help="Name search string"),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Search contestants by name and show their history."""
    repo = _get_repo(db)
    matches = repo.search_contestants(query)
    if not matches:
        console.print(f"[yellow]No contestants matching '{query}'[/yellow]")
        return

    for m in matches[:10]:
        console.print(f"\n[bold]{m['name']}[/bold] (ID: {m['id']}, Country: {m['primary_country_code']})")
        participations = repo.get_participations_by_contestant(m["id"])
        if participations:
            table = Table(show_header=True)
            table.add_column("Year", justify="center")
            table.add_column("Country")
            table.add_column("Rank", justify="right")
            table.add_column("Score", justify="right")
            table.add_column("Award")
            for p in participations:
                award_style = {
                    "Gold": "bold yellow",
                    "Silver": "white",
                    "Bronze": "rgb(205,127,50)",
                }.get(p["award"] or "", "dim")
                table.add_row(
                    str(p["year"]),
                    p["country_code"] or "",
                    str(p["rank"]) if p["rank"] else "",
                    f"{p['score_abs']:.2f}" if p["score_abs"] is not None else "",
                    f"[{award_style}]{p['award'] or ''}[/{award_style}]",
                )
            console.print(table)

    if len(matches) > 10:
        console.print(f"[dim]... and {len(matches) - 10} more[/dim]")


@app.command("year")
def year_cmd(
    year: int = typer.Argument(..., help="Year to query"),
    award: Optional[str] = typer.Option(None, "--award", help="Filter by award (gold/silver/bronze)"),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Show results for a specific year."""
    repo = _get_repo(db)
    participations = repo.get_participations_by_year(year, award=award)
    if not participations:
        console.print(f"[yellow]No results for {year}[/yellow]")
        return

    table = Table(title=f"IOI {year} Results{f' ({award})' if award else ''}")
    table.add_column("Rank", justify="right")
    table.add_column("Name")
    table.add_column("Country")
    table.add_column("Score", justify="right")
    table.add_column("Rel%", justify="right")
    table.add_column("Award")

    for p in participations:
        award_style = {
            "Gold": "bold yellow",
            "Silver": "white",
            "Bronze": "rgb(205,127,50)",
        }.get(p["award"] or "", "dim")
        table.add_row(
            str(p["rank"]) if p["rank"] else "",
            p["contestant_name"],
            p["country_code"] or "",
            f"{p['score_abs']:.2f}" if p["score_abs"] is not None else "",
            f"{p['score_rel']:.2f}%" if p["score_rel"] is not None else "",
            f"[{award_style}]{p['award'] or ''}[/{award_style}]",
        )
    console.print(table)
    console.print(f"[dim]Total: {len(participations)} contestants[/dim]")


@app.command()
def teammates(
    contestant_id: int = typer.Argument(..., help="Contestant ID"),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Show teammates of a contestant across all years."""
    repo = _get_repo(db)
    c = repo.get_contestant(contestant_id)
    if not c:
        console.print(f"[red]Contestant {contestant_id} not found[/red]")
        return

    console.print(f"\n[bold]Teammates of {c['name']}[/bold]")
    mates = repo.get_teammates(contestant_id)
    if not mates:
        console.print("[yellow]No teammates found[/yellow]")
        return

    table = Table()
    table.add_column("Year", justify="center")
    table.add_column("Name")
    table.add_column("Country")
    table.add_column("Award")
    for m in mates:
        table.add_row(str(m["year"]), m["name"], m["country_code"] or "", m["award"] or "")
    console.print(table)


@app.command()
def stats(
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Show database summary statistics."""
    repo = _get_repo(db)
    s = repo.db_stats()

    table = Table(title="Database Statistics")
    table.add_column("Table")
    table.add_column("Count", justify="right")
    for name, count in s.items():
        table.add_row(name, str(count))
    console.print(table)
