from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ioi_graph.config import DEFAULT_DB_PATH
from ioi_graph.db.engine import ensure_schema, get_connection

app = typer.Typer(help="LinkedIn profile enrichment")
console = Console()


def _get_scraper(db: Path):
    from ioi_graph.sources.linkedin.scraper import LinkedInScraper

    ensure_schema(db)
    conn = get_connection(db)
    return LinkedInScraper(conn)


@app.command()
def search(
    name: str = typer.Argument(..., help="Contestant name to search for"),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Google search for a contestant's LinkedIn profile."""
    scraper = _get_scraper(db)
    urls = scraper.search(name)
    if not urls:
        console.print("[yellow]No LinkedIn profiles found[/yellow]")
        return

    console.print(f"[bold]Found {len(urls)} candidate URLs:[/bold]")
    for i, url in enumerate(urls, 1):
        marker = "[green]*[/green] " if i == 1 else "  "
        console.print(f"  {marker}{url}")


@app.command()
def scrape(
    ids: str = typer.Option(..., "--ids", help="Comma-separated contestant IDs"),
    email: str = typer.Option(None, "--email", help="LinkedIn email"),
    force: bool = typer.Option(False, "--force", help="Re-scrape even if fresh"),
    headless: bool = typer.Option(True, "--headless/--no-headless", help="Run browser headless (use --no-headless to watch)"),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Scrape LinkedIn profiles for specific contestants (authenticated)."""
    if email is None:
        email = typer.prompt("LinkedIn email")
    password = typer.prompt("LinkedIn password", hide_input=True)

    scraper = _get_scraper(db)
    id_list = [int(x.strip()) for x in ids.split(",")]
    scraper.scrape_ids(id_list, email=email, password=password, force=force, headless=headless)


@app.command(name="scrape-all")
def scrape_all(
    email: str = typer.Option(None, "--email", help="LinkedIn email"),
    force: bool = typer.Option(False, "--force", help="Re-scrape even if fresh"),
    headless: bool = typer.Option(True, "--headless/--no-headless", help="Run browser headless (use --no-headless to watch)"),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Scrape LinkedIn profiles for all contestants (authenticated)."""
    if email is None:
        email = typer.prompt("LinkedIn email")
    password = typer.prompt("LinkedIn password", hide_input=True)

    scraper = _get_scraper(db)
    scraper.scrape_all(email=email, password=password, force=force, headless=headless)


@app.command()
def show(
    contestant_id: int = typer.Argument(..., help="Contestant ID"),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Show stored LinkedIn data for a contestant."""
    scraper = _get_scraper(db)

    # Get contestant name
    contestant = scraper.repo.get_contestant(contestant_id)
    if not contestant:
        console.print(f"[red]Contestant {contestant_id} not found[/red]")
        raise typer.Exit(1)

    profile = scraper.show(contestant_id)
    if not profile:
        console.print(f"[yellow]No LinkedIn data for {contestant['name']} ({contestant_id})[/yellow]")
        return

    console.print(f"\n[bold]{contestant['name']}[/bold]")
    console.print(f"  LinkedIn: {profile.linkedin_url}")
    if profile.headline:
        console.print(f"  Headline: {profile.headline}")
    if profile.location:
        console.print(f"  Location: {profile.location}")

    if profile.experiences:
        console.print(f"\n[bold]Work Experience ({len(profile.experiences)}):[/bold]")
        table = Table()
        table.add_column("Company")
        table.add_column("Title")
        table.add_column("Years")
        for exp in profile.experiences:
            end = str(exp.end_year) if exp.end_year else "Present"
            start = str(exp.start_year) if exp.start_year else "?"
            years = f"{start} - {end}"
            table.add_row(exp.company, exp.title or "", years)
        console.print(table)

    if profile.education:
        console.print(f"\n[bold]Education ({len(profile.education)}):[/bold]")
        table = Table()
        table.add_column("School")
        table.add_column("Degree")
        table.add_column("Field")
        table.add_column("Years")
        for edu in profile.education:
            end = str(edu.end_year) if edu.end_year else "?"
            start = str(edu.start_year) if edu.start_year else "?"
            years = f"{start} - {end}"
            table.add_row(
                edu.school,
                edu.degree or "",
                edu.field_of_study or "",
                years,
            )
        console.print(table)
