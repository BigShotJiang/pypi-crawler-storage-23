from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from ioi_graph.config import DEFAULT_DB_PATH
from ioi_graph.db.engine import ensure_schema, get_connection
from ioi_graph.graph.analyzer import GraphAnalyzer
from ioi_graph.graph.builder import GraphBuilder
from ioi_graph.graph.models import EdgeType

app = typer.Typer(help="Build and analyze the contestant graph")
console = Console()


@app.command()
def build(
    edge_types: Optional[str] = typer.Option(
        None, "--edge-types", help="Comma-separated edge types to build"
    ),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Compute edges from participation data."""
    ensure_schema(db)
    conn = get_connection(db)
    builder = GraphBuilder(conn)

    types = None
    if edge_types:
        types = [EdgeType(t.strip()) for t in edge_types.split(",")]

    console.print("[bold]Building graph edges...[/bold]")
    counts = builder.build_all(edge_types=types)
    for name, count in counts.items():
        console.print(f"  {name}: {count} edges")
    total = sum(counts.values())
    console.print(f"[bold green]Total: {total} edges[/bold green]")


@app.command()
def path(
    source: int = typer.Argument(..., help="Source contestant ID"),
    target: int = typer.Argument(..., help="Target contestant ID"),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Find shortest path between two contestants."""
    ensure_schema(db)
    conn = get_connection(db)
    analyzer = GraphAnalyzer(conn)
    result = analyzer.shortest_path(source, target)
    if not result:
        console.print("[yellow]No path found between these contestants[/yellow]")
        return

    console.print(f"[bold]Path ({len(result)} steps):[/bold]")
    for i, node in enumerate(result):
        arrow = " -> " if i < len(result) - 1 else ""
        console.print(f"  {node['name']} ({node['country']}){arrow}", end="")
    console.print()


@app.command()
def connections(
    person_id: int = typer.Argument(..., help="Contestant ID"),
    top: int = typer.Option(10, "--top", help="Number of connections to show"),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Show strongest connections for a contestant."""
    ensure_schema(db)
    conn = get_connection(db)
    analyzer = GraphAnalyzer(conn)
    result = analyzer.strongest_connections(person_id, top=top)
    if not result:
        console.print("[yellow]No connections found[/yellow]")
        return

    table = Table(title=f"Top {top} Connections")
    table.add_column("Name")
    table.add_column("Country")
    table.add_column("Weight", justify="right")
    for c in result:
        table.add_row(c["name"], c["country"], f"{c['weight']:.1f}")
    console.print(table)


@app.command()
def stats(
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Show graph statistics."""
    ensure_schema(db)
    conn = get_connection(db)
    analyzer = GraphAnalyzer(conn)
    s = analyzer.stats()

    table = Table(title="Graph Statistics")
    table.add_column("Metric")
    table.add_column("Value", justify="right")
    table.add_row("Nodes", str(s["nodes"]))
    table.add_row("Edges", str(s["edges"]))
    table.add_row("Components", str(s["components"]))
    table.add_row("Density", f"{s['density']:.6f}")
    table.add_row("Avg Clustering", f"{s['avg_clustering']:.4f}")
    console.print(table)


@app.command()
def export(
    output: str = typer.Argument(..., help="Output file path (e.g. graph.gexf)"),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Export graph to GEXF format for visualization."""
    ensure_schema(db)
    conn = get_connection(db)
    analyzer = GraphAnalyzer(conn)
    analyzer.export_gexf(output)
    console.print(f"[bold green]Graph exported to {output}[/bold green]")
