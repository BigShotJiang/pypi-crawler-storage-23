from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from ioi_graph.config import DEFAULT_DB_PATH
from ioi_graph.db.engine import ensure_schema, get_connection
from ioi_graph.sources.ioi.scraper import IOIScraper

app = typer.Typer(help="Scrape IOI data from stats.ioinformatics.org")
console = Console()


def _get_scraper(db: Path, rate_limit: float) -> IOIScraper:
    ensure_schema(db)
    conn = get_connection(db)
    return IOIScraper(conn, rate_limit=rate_limit)


@app.command()
def all(
    force: bool = typer.Option(False, "--force", help="Re-scrape even if fresh"),
    rate_limit: float = typer.Option(0.5, "--rate-limit", help="Requests per second"),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Scrape all IOI data: olympiads, countries, and all year results."""
    scraper = _get_scraper(db, rate_limit)
    scraper.scrape_all(force=force)
    console.print("[bold green]Full scrape complete![/bold green]")


@app.command()
def year(
    year: int = typer.Argument(..., help="Year to scrape (e.g. 2024)"),
    force: bool = typer.Option(False, "--force", help="Re-scrape even if fresh"),
    rate_limit: float = typer.Option(0.5, "--rate-limit", help="Requests per second"),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Scrape results for a single year."""
    scraper = _get_scraper(db, rate_limit)
    scraper.scrape_year(year, force=force)
    console.print(f"[bold green]Year {year} scrape complete![/bold green]")


@app.command()
def people(
    ids: Optional[str] = typer.Option(None, "--ids", help="Comma-separated contestant IDs"),
    force: bool = typer.Option(False, "--force", help="Re-scrape even if fresh"),
    rate_limit: float = typer.Option(0.5, "--rate-limit", help="Requests per second"),
    db: Path = typer.Option(DEFAULT_DB_PATH, "--db", help="Database path"),
) -> None:
    """Scrape contestant profiles for enrichment (codeforces handles, etc.)."""
    scraper = _get_scraper(db, rate_limit)
    id_list = [int(x.strip()) for x in ids.split(",")] if ids else None
    scraper.scrape_people(ids=id_list, force=force)
    console.print("[bold green]People scrape complete![/bold green]")
