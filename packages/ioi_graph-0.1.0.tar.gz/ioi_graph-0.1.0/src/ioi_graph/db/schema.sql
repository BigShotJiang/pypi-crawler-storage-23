CREATE TABLE IF NOT EXISTS contestants (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    primary_country_code TEXT,
    profile_url TEXT,
    codeforces_handle TEXT,
    email TEXT,
    scraped_at TEXT
);

CREATE TABLE IF NOT EXISTS countries (
    code TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    gold_medals INTEGER DEFAULT 0,
    silver_medals INTEGER DEFAULT 0,
    bronze_medals INTEGER DEFAULT 0,
    first_participation_year INTEGER
);

CREATE TABLE IF NOT EXISTS olympiads (
    year INTEGER PRIMARY KEY,
    host_country_code TEXT,
    host_city TEXT,
    dates TEXT,
    num_contestants INTEGER,
    num_countries INTEGER,
    results_scraped_at TEXT
);

CREATE TABLE IF NOT EXISTS participations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contestant_id INTEGER NOT NULL,
    year INTEGER NOT NULL,
    country_code TEXT,
    rank INTEGER,
    score_abs REAL,
    score_rel REAL,
    award TEXT,
    UNIQUE(contestant_id, year)
);

CREATE TABLE IF NOT EXISTS task_scores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    participation_id INTEGER NOT NULL,
    task_position INTEGER NOT NULL,
    task_name TEXT,
    score REAL,
    max_score REAL,
    UNIQUE(participation_id, task_position)
);

CREATE TABLE IF NOT EXISTS edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_a_id INTEGER NOT NULL,
    person_b_id INTEGER NOT NULL,
    edge_type TEXT NOT NULL,
    year INTEGER,
    weight REAL NOT NULL DEFAULT 1.0,
    properties TEXT,
    CHECK (person_a_id < person_b_id)
);

CREATE INDEX IF NOT EXISTS idx_edges_a ON edges(person_a_id);
CREATE INDEX IF NOT EXISTS idx_edges_b ON edges(person_b_id);
CREATE INDEX IF NOT EXISTS idx_edges_type ON edges(edge_type);
CREATE INDEX IF NOT EXISTS idx_participations_year ON participations(year);
CREATE INDEX IF NOT EXISTS idx_participations_contestant ON participations(contestant_id);
CREATE INDEX IF NOT EXISTS idx_participations_country_year ON participations(country_code, year);

CREATE TABLE IF NOT EXISTS scrape_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL,
    resource_key TEXT NOT NULL,
    url TEXT,
    status TEXT NOT NULL,
    http_status INTEGER,
    error_message TEXT,
    scraped_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_scrape_log_lookup ON scrape_log(source, resource_key);

-- LinkedIn enrichment tables

CREATE TABLE IF NOT EXISTS linkedin_profiles (
    contestant_id INTEGER PRIMARY KEY,
    linkedin_url TEXT,
    headline TEXT,
    location TEXT,
    scraped_at TEXT
);

CREATE TABLE IF NOT EXISTS work_experiences (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contestant_id INTEGER NOT NULL,
    company TEXT NOT NULL,
    title TEXT,
    start_year INTEGER,
    end_year INTEGER,
    UNIQUE(contestant_id, company, title, start_year)
);

CREATE INDEX IF NOT EXISTS idx_work_exp_company ON work_experiences(company);
CREATE INDEX IF NOT EXISTS idx_work_exp_contestant ON work_experiences(contestant_id);

CREATE TABLE IF NOT EXISTS education (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    contestant_id INTEGER NOT NULL,
    school TEXT NOT NULL,
    degree TEXT,
    field_of_study TEXT,
    start_year INTEGER,
    end_year INTEGER,
    UNIQUE(contestant_id, school, degree, start_year)
);

CREATE INDEX IF NOT EXISTS idx_education_school ON education(school);
CREATE INDEX IF NOT EXISTS idx_education_contestant ON education(contestant_id);
