from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone


class IOIRepository:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    # ── Contestants ──────────────────────────────────────────────

    def upsert_contestant(
        self,
        id: int,
        name: str,
        country_code: str | None = None,
        profile_url: str | None = None,
    ) -> None:
        self.conn.execute(
            """INSERT INTO contestants (id, name, primary_country_code, profile_url, scraped_at)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                 name = excluded.name,
                 primary_country_code = COALESCE(excluded.primary_country_code, primary_country_code),
                 profile_url = COALESCE(excluded.profile_url, profile_url),
                 scraped_at = excluded.scraped_at""",
            (id, name, country_code, profile_url, _now()),
        )

    def update_contestant_profile(
        self,
        id: int,
        codeforces_handle: str | None = None,
        email: str | None = None,
    ) -> None:
        self.conn.execute(
            """UPDATE contestants SET
                 codeforces_handle = COALESCE(?, codeforces_handle),
                 email = COALESCE(?, email),
                 scraped_at = ?
               WHERE id = ?""",
            (codeforces_handle, email, _now(), id),
        )

    def search_contestants(self, query: str) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM contestants WHERE name LIKE ? ORDER BY name",
            (f"%{query}%",),
        ).fetchall()

    def get_contestant(self, id: int) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM contestants WHERE id = ?", (id,)
        ).fetchone()

    # ── Countries ────────────────────────────────────────────────

    def upsert_country(
        self,
        code: str,
        name: str,
        gold: int = 0,
        silver: int = 0,
        bronze: int = 0,
        first_year: int | None = None,
    ) -> None:
        self.conn.execute(
            """INSERT INTO countries (code, name, gold_medals, silver_medals, bronze_medals, first_participation_year)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(code) DO UPDATE SET
                 name = excluded.name,
                 gold_medals = excluded.gold_medals,
                 silver_medals = excluded.silver_medals,
                 bronze_medals = excluded.bronze_medals,
                 first_participation_year = COALESCE(excluded.first_participation_year, first_participation_year)""",
            (code, name, gold, silver, bronze, first_year),
        )

    def get_countries(self) -> list[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM countries ORDER BY name").fetchall()

    # ── Olympiads ────────────────────────────────────────────────

    def upsert_olympiad(
        self,
        year: int,
        host_country_code: str | None = None,
        host_city: str | None = None,
        dates: str | None = None,
        num_contestants: int | None = None,
        num_countries: int | None = None,
    ) -> None:
        self.conn.execute(
            """INSERT INTO olympiads (year, host_country_code, host_city, dates, num_contestants, num_countries)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(year) DO UPDATE SET
                 host_country_code = COALESCE(excluded.host_country_code, host_country_code),
                 host_city = COALESCE(excluded.host_city, host_city),
                 dates = COALESCE(excluded.dates, dates),
                 num_contestants = COALESCE(excluded.num_contestants, num_contestants),
                 num_countries = COALESCE(excluded.num_countries, num_countries)""",
            (year, host_country_code, host_city, dates, num_contestants, num_countries),
        )

    def mark_results_scraped(self, year: int) -> None:
        self.conn.execute(
            "UPDATE olympiads SET results_scraped_at = ? WHERE year = ?",
            (_now(), year),
        )

    def get_olympiad(self, year: int) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM olympiads WHERE year = ?", (year,)
        ).fetchone()

    def get_all_years(self) -> list[int]:
        rows = self.conn.execute(
            "SELECT year FROM olympiads ORDER BY year"
        ).fetchall()
        return [r["year"] for r in rows]

    # ── Participations ───────────────────────────────────────────

    def upsert_participation(
        self,
        contestant_id: int,
        year: int,
        country_code: str | None = None,
        rank: int | None = None,
        score_abs: float | None = None,
        score_rel: float | None = None,
        award: str | None = None,
    ) -> int:
        cur = self.conn.execute(
            """INSERT INTO participations (contestant_id, year, country_code, rank, score_abs, score_rel, award)
               VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(contestant_id, year) DO UPDATE SET
                 country_code = COALESCE(excluded.country_code, country_code),
                 rank = COALESCE(excluded.rank, rank),
                 score_abs = COALESCE(excluded.score_abs, score_abs),
                 score_rel = COALESCE(excluded.score_rel, score_rel),
                 award = COALESCE(excluded.award, award)
               RETURNING id""",
            (contestant_id, year, country_code, rank, score_abs, score_rel, award),
        )
        row = cur.fetchone()
        return row["id"]

    def get_participations_by_year(
        self, year: int, award: str | None = None
    ) -> list[sqlite3.Row]:
        if award:
            return self.conn.execute(
                """SELECT p.*, c.name as contestant_name
                   FROM participations p
                   JOIN contestants c ON c.id = p.contestant_id
                   WHERE p.year = ? AND LOWER(p.award) = LOWER(?)
                   ORDER BY p.rank""",
                (year, award),
            ).fetchall()
        return self.conn.execute(
            """SELECT p.*, c.name as contestant_name
               FROM participations p
               JOIN contestants c ON c.id = p.contestant_id
               WHERE p.year = ?
               ORDER BY p.rank""",
            (year,),
        ).fetchall()

    def get_participations_by_contestant(
        self, contestant_id: int
    ) -> list[sqlite3.Row]:
        return self.conn.execute(
            """SELECT p.*, o.host_city
               FROM participations p
               LEFT JOIN olympiads o ON o.year = p.year
               WHERE p.contestant_id = ?
               ORDER BY p.year""",
            (contestant_id,),
        ).fetchall()

    def get_teammates(self, contestant_id: int) -> list[sqlite3.Row]:
        return self.conn.execute(
            """SELECT DISTINCT c.id, c.name, p2.year, p2.country_code, p2.award
               FROM participations p1
               JOIN participations p2 ON p1.year = p2.year AND p1.country_code = p2.country_code
               JOIN contestants c ON c.id = p2.contestant_id
               WHERE p1.contestant_id = ? AND p2.contestant_id != ?
               ORDER BY p2.year, c.name""",
            (contestant_id, contestant_id),
        ).fetchall()

    # ── Task Scores ──────────────────────────────────────────────

    def upsert_task_score(
        self,
        participation_id: int,
        task_position: int,
        task_name: str | None = None,
        score: float | None = None,
        max_score: float | None = None,
    ) -> None:
        self.conn.execute(
            """INSERT INTO task_scores (participation_id, task_position, task_name, score, max_score)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(participation_id, task_position) DO UPDATE SET
                 task_name = COALESCE(excluded.task_name, task_name),
                 score = COALESCE(excluded.score, score),
                 max_score = COALESCE(excluded.max_score, max_score)""",
            (participation_id, task_position, task_name, score, max_score),
        )

    def get_task_scores(self, participation_id: int) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM task_scores WHERE participation_id = ? ORDER BY task_position",
            (participation_id,),
        ).fetchall()

    # ── Edges ────────────────────────────────────────────────────

    def insert_edge(
        self,
        person_a_id: int,
        person_b_id: int,
        edge_type: str,
        year: int | None = None,
        weight: float = 1.0,
        properties: dict | None = None,
    ) -> None:
        a, b = min(person_a_id, person_b_id), max(person_a_id, person_b_id)
        self.conn.execute(
            """INSERT OR IGNORE INTO edges (person_a_id, person_b_id, edge_type, year, weight, properties)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (a, b, edge_type, year, weight, json.dumps(properties) if properties else None),
        )

    def delete_edges(self, edge_type: str | None = None, year: int | None = None) -> int:
        if edge_type and year:
            cur = self.conn.execute(
                "DELETE FROM edges WHERE edge_type = ? AND year = ?",
                (edge_type, year),
            )
        elif edge_type:
            cur = self.conn.execute(
                "DELETE FROM edges WHERE edge_type = ?", (edge_type,)
            )
        else:
            cur = self.conn.execute("DELETE FROM edges")
        return cur.rowcount

    def get_all_edges(self) -> list[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM edges").fetchall()

    def edge_count(self) -> int:
        return self.conn.execute("SELECT COUNT(*) as cnt FROM edges").fetchone()["cnt"]

    # ── LinkedIn ────────────────────────────────────────────────

    def upsert_linkedin_profile(
        self,
        contestant_id: int,
        linkedin_url: str,
        headline: str | None = None,
        location: str | None = None,
    ) -> None:
        self.conn.execute(
            """INSERT INTO linkedin_profiles (contestant_id, linkedin_url, headline, location, scraped_at)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(contestant_id) DO UPDATE SET
                 linkedin_url = excluded.linkedin_url,
                 headline = COALESCE(excluded.headline, headline),
                 location = COALESCE(excluded.location, location),
                 scraped_at = excluded.scraped_at""",
            (contestant_id, linkedin_url, headline, location, _now()),
        )

    def get_linkedin_profile(self, contestant_id: int) -> sqlite3.Row | None:
        return self.conn.execute(
            "SELECT * FROM linkedin_profiles WHERE contestant_id = ?",
            (contestant_id,),
        ).fetchone()

    def get_all_linkedin_profiles(self) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM linkedin_profiles ORDER BY contestant_id"
        ).fetchall()

    def upsert_work_experience(
        self,
        contestant_id: int,
        company: str,
        title: str | None = None,
        start_year: int | None = None,
        end_year: int | None = None,
    ) -> None:
        self.conn.execute(
            """INSERT INTO work_experiences (contestant_id, company, title, start_year, end_year)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(contestant_id, company, title, start_year) DO UPDATE SET
                 end_year = COALESCE(excluded.end_year, end_year)""",
            (contestant_id, company, title, start_year, end_year),
        )

    def get_work_experiences(self, contestant_id: int) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM work_experiences WHERE contestant_id = ? ORDER BY start_year DESC",
            (contestant_id,),
        ).fetchall()

    def get_all_work_experiences(self) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM work_experiences ORDER BY company, contestant_id"
        ).fetchall()

    def upsert_education(
        self,
        contestant_id: int,
        school: str,
        degree: str | None = None,
        field_of_study: str | None = None,
        start_year: int | None = None,
        end_year: int | None = None,
    ) -> None:
        self.conn.execute(
            """INSERT INTO education (contestant_id, school, degree, field_of_study, start_year, end_year)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(contestant_id, school, degree, start_year) DO UPDATE SET
                 field_of_study = COALESCE(excluded.field_of_study, field_of_study),
                 end_year = COALESCE(excluded.end_year, end_year)""",
            (contestant_id, school, degree, field_of_study, start_year, end_year),
        )

    def get_education(self, contestant_id: int) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM education WHERE contestant_id = ? ORDER BY start_year DESC",
            (contestant_id,),
        ).fetchall()

    def get_all_education(self) -> list[sqlite3.Row]:
        return self.conn.execute(
            "SELECT * FROM education ORDER BY school, contestant_id"
        ).fetchall()

    def delete_work_experiences(self, contestant_id: int) -> int:
        cur = self.conn.execute(
            "DELETE FROM work_experiences WHERE contestant_id = ?",
            (contestant_id,),
        )
        return cur.rowcount

    def delete_education(self, contestant_id: int) -> int:
        cur = self.conn.execute(
            "DELETE FROM education WHERE contestant_id = ?",
            (contestant_id,),
        )
        return cur.rowcount

    # ── Stats ────────────────────────────────────────────────────

    def db_stats(self) -> dict:
        tables = [
            "contestants", "countries", "olympiads", "participations",
            "task_scores", "edges", "linkedin_profiles", "work_experiences", "education",
        ]
        stats = {}
        for t in tables:
            row = self.conn.execute(f"SELECT COUNT(*) as cnt FROM {t}").fetchone()
            stats[t] = row["cnt"]
        return stats

    # ── Scrape log ───────────────────────────────────────────────

    def log_scrape(
        self,
        source: str,
        resource_key: str,
        url: str,
        status: str,
        http_status: int | None = None,
        error_message: str | None = None,
    ) -> None:
        self.conn.execute(
            """INSERT INTO scrape_log (source, resource_key, url, status, http_status, error_message, scraped_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (source, resource_key, url, status, http_status, error_message, _now()),
        )

    def get_last_scrape(self, source: str, resource_key: str) -> sqlite3.Row | None:
        return self.conn.execute(
            """SELECT * FROM scrape_log
               WHERE source = ? AND resource_key = ? AND status = 'success'
               ORDER BY scraped_at DESC LIMIT 1""",
            (source, resource_key),
        ).fetchone()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()
