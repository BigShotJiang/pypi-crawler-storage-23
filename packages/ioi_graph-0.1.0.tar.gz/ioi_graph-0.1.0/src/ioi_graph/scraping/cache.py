from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta, timezone

from ioi_graph.config import (
    RESULTS_FRESHNESS_DAYS,
    PROFILE_FRESHNESS_DAYS,
    LINKEDIN_FRESHNESS_DAYS,
)


class ScrapeCache:
    """Checks scrape_log table for freshness to avoid redundant fetches."""

    FRESHNESS_DAYS = {
        "results": RESULTS_FRESHNESS_DAYS,
        "profile": PROFILE_FRESHNESS_DAYS,
        "olympiads": RESULTS_FRESHNESS_DAYS,
        "countries": RESULTS_FRESHNESS_DAYS,
        "linkedin": LINKEDIN_FRESHNESS_DAYS,
    }

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn

    def is_fresh(self, source: str, resource_key: str) -> bool:
        row = self.conn.execute(
            """SELECT scraped_at FROM scrape_log
               WHERE source = ? AND resource_key = ? AND status = 'success'
               ORDER BY scraped_at DESC LIMIT 1""",
            (source, resource_key),
        ).fetchone()
        if not row:
            return False

        scraped_at = datetime.fromisoformat(row["scraped_at"])
        max_age_days = self.FRESHNESS_DAYS.get(source, RESULTS_FRESHNESS_DAYS)
        return datetime.now(timezone.utc) - scraped_at < timedelta(days=max_age_days)

    def log_scrape(
        self,
        source: str,
        resource_key: str,
        url: str,
        status: str,
        http_status: int | None = None,
        error_message: str | None = None,
    ) -> None:
        self.conn.execute(
            """INSERT INTO scrape_log (source, resource_key, url, status, http_status, error_message, scraped_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                source,
                resource_key,
                url,
                status,
                http_status,
                error_message,
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        self.conn.commit()
