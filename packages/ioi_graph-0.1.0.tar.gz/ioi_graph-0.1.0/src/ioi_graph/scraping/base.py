from __future__ import annotations

import time
import threading
from abc import ABC, abstractmethod
from typing import Generic, TypeVar

T = TypeVar("T")


class RateLimiter:
    """Token-bucket rate limiter with per-domain tracking."""

    def __init__(self, requests_per_second: float = 0.5):
        self._interval = 1.0 / requests_per_second
        self._last_request: dict[str, float] = {}
        self._lock = threading.Lock()

    def wait(self, domain: str = "default") -> None:
        with self._lock:
            now = time.monotonic()
            last = self._last_request.get(domain, 0.0)
            elapsed = now - last
            if elapsed < self._interval:
                time.sleep(self._interval - elapsed)
            self._last_request[domain] = time.monotonic()


class BaseParser(ABC, Generic[T]):
    """Abstract parser that transforms a scraped page into structured data."""

    @abstractmethod
    def parse(self, page, **context) -> T:
        ...

    @abstractmethod
    def can_parse(self, url: str) -> bool:
        ...


class BaseScraper(ABC):
    """Abstract scraper that orchestrates fetching + parsing + storage."""

    @abstractmethod
    def get_source_name(self) -> str:
        ...

    @abstractmethod
    def scrape_all(self, force: bool = False) -> None:
        ...
