from __future__ import annotations

from urllib.parse import urlparse

from scrapling import Fetcher, StealthyFetcher

from ioi_graph.config import (
    USER_AGENT,
    DEFAULT_RATE_LIMIT,
    LINKEDIN_GOOGLE_RATE_LIMIT,
    LINKEDIN_PROFILE_RATE_LIMIT,
)
from ioi_graph.scraping.base import RateLimiter


class ScrapingSession:
    """Wraps Scrapling Fetcher with rate limiting."""

    def __init__(self, rate_limit: float = DEFAULT_RATE_LIMIT):
        self._limiter = RateLimiter(rate_limit)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        pass

    def get(self, url: str):
        domain = urlparse(url).netloc
        self._limiter.wait(domain)
        return Fetcher.get(url, stealthy_headers=True, follow_redirects=True)

    def get_stealth(self, url: str, referer: str | None = None):
        """Fetch via StealthyFetcher (browser-based) for anti-bot bypassing.

        Args:
            url: The URL to fetch.
            referer: Custom referer URL. If provided, disables the default
                     google_search referer so the custom one is used.
        """
        domain = urlparse(url).netloc
        self._limiter.wait(domain)
        kwargs: dict = {"headless": True, "follow_redirects": True}
        if referer:
            kwargs["google_search"] = False
            kwargs["extra_headers"] = {"referer": referer}
        return StealthyFetcher.fetch(url, **kwargs)


class LinkedInBrowserSession:
    """Persistent browser session for authenticated LinkedIn scraping.

    Uses StealthySession to maintain cookies across requests so we can
    log in once and scrape multiple profiles without re-authenticating.
    """

    def __init__(
        self,
        email: str,
        password: str,
        headless: bool = True,
        rate_limit: float = LINKEDIN_PROFILE_RATE_LIMIT,
    ):
        self._email = email
        self._password = password
        self._headless = headless
        self._limiter = RateLimiter(rate_limit)
        self._google_limiter = RateLimiter(LINKEDIN_GOOGLE_RATE_LIMIT)
        self._session = None
        self._logged_in = False

    def __enter__(self):
        from scrapling.engines._browsers._stealth import StealthySession

        self._session = StealthySession(headless=self._headless, network_idle=True)
        self._session.start()
        return self

    def __exit__(self, *exc):
        if self._session:
            self._session.close()
            self._session = None
        self._logged_in = False

    def login(self) -> None:
        """Navigate to linkedin.com/login, fill credentials, and submit.

        Raises:
            RuntimeError: If login fails (wrong credentials or unexpected page).
        """
        def _do_login(page):
            page.fill("input#username", self._email)
            page.fill("input#password", self._password)
            page.click('button[type="submit"]')
            # Don't use "networkidle" — LinkedIn's feed has constant network
            # activity (notifications, etc.) so it never fires.
            page.wait_for_load_state("domcontentloaded")

        resp = self._session.fetch(
            "https://www.linkedin.com/login",
            page_action=_do_login,
        )

        # Verify login succeeded
        url = getattr(resp, "url", "") or ""
        if "feed" in url or "mynetwork" in url:
            self._logged_in = True
            return

        # Check for error messages in the response
        html = resp.html_content if hasattr(resp, "html_content") else str(resp)
        if "Wrong email or password" in html or "challenge" in url:
            raise RuntimeError(
                "LinkedIn login failed — wrong email/password or security challenge."
            )

        # May have landed on an unexpected page but cookies could still be set
        self._logged_in = True

    def fetch_profile(self, url: str):
        """Fetch a LinkedIn profile page (must be logged in).

        Raises:
            RuntimeError: If not logged in.
        """
        if not self._logged_in:
            raise RuntimeError("Must call login() before fetch_profile()")
        self._limiter.wait("linkedin.com")
        return self._session.fetch(url, network_idle=True)

    def search_google(self, url: str):
        """Fetch Google search results via the same browser session.

        We reuse the StealthySession for Google searches because Playwright's
        sync API cannot have multiple instances running concurrently (the
        event loop conflicts). Rate-limited separately from LinkedIn fetches.
        """
        self._google_limiter.wait("google.com")
        return self._session.fetch(url)
