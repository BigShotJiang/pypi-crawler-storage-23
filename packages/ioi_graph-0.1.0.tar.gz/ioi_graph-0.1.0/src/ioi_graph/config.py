from pathlib import Path

DEFAULT_DB_PATH = Path("ioi_graph.db")
IOI_BASE_URL = "https://stats.ioinformatics.org"
USER_AGENT = "IOIGraphBot/0.1 (academic research; github.com/ioi-graph)"
DEFAULT_RATE_LIMIT = 0.5  # requests per second
RESULTS_FRESHNESS_DAYS = 30
PROFILE_FRESHNESS_DAYS = 90

# LinkedIn scraping
LINKEDIN_GOOGLE_RATE_LIMIT = 0.2  # requests per second for Google search
LINKEDIN_PROFILE_RATE_LIMIT = 0.1  # requests per second for LinkedIn profiles
LINKEDIN_FRESHNESS_DAYS = 90
