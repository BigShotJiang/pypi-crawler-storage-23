from __future__ import annotations

import sqlite3
from collections import defaultdict

import networkx as nx

from ioi_graph.db.repositories import IOIRepository


class GraphAnalyzer:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.repo = IOIRepository(conn)
        self.graph: nx.Graph | None = None

    def load(self) -> None:
        """Load edges from DB into a networkx graph."""
        self.graph = nx.Graph()
        edges = self.repo.get_all_edges()
        # Aggregate weights between the same pair
        pair_weights: dict[tuple[int, int], float] = defaultdict(float)
        for e in edges:
            pair = (e["person_a_id"], e["person_b_id"])
            pair_weights[pair] += e["weight"]

        for (a, b), w in pair_weights.items():
            self.graph.add_edge(a, b, weight=w)

        # Add node names
        for node in self.graph.nodes:
            contestant = self.repo.get_contestant(node)
            if contestant:
                self.graph.nodes[node]["name"] = contestant["name"]
                self.graph.nodes[node]["country"] = contestant["primary_country_code"]

    def _ensure_loaded(self) -> nx.Graph:
        if self.graph is None:
            self.load()
        assert self.graph is not None
        return self.graph

    def shortest_path(self, source: int, target: int) -> list[dict]:
        g = self._ensure_loaded()
        if source not in g or target not in g:
            return []
        try:
            path = nx.shortest_path(g, source, target)
        except nx.NetworkXNoPath:
            return []
        result = []
        for node_id in path:
            data = g.nodes[node_id]
            result.append({
                "id": node_id,
                "name": data.get("name", "?"),
                "country": data.get("country", "?"),
            })
        return result

    def strongest_connections(self, person_id: int, top: int = 10) -> list[dict]:
        g = self._ensure_loaded()
        if person_id not in g:
            return []
        neighbors = []
        for neighbor in g.neighbors(person_id):
            weight = g[person_id][neighbor].get("weight", 0)
            data = g.nodes[neighbor]
            neighbors.append({
                "id": neighbor,
                "name": data.get("name", "?"),
                "country": data.get("country", "?"),
                "weight": weight,
            })
        neighbors.sort(key=lambda x: x["weight"], reverse=True)
        return neighbors[:top]

    def stats(self) -> dict:
        g = self._ensure_loaded()
        return {
            "nodes": g.number_of_nodes(),
            "edges": g.number_of_edges(),
            "components": nx.number_connected_components(g),
            "density": nx.density(g),
            "avg_clustering": nx.average_clustering(g) if g.number_of_nodes() > 0 else 0,
        }

    def export_gexf(self, path: str) -> None:
        g = self._ensure_loaded()
        nx.write_gexf(g, path)
