from enum import Enum


class EdgeType(str, Enum):
    SAME_COUNTRY_YEAR = "same_country_year"
    SAME_MEDAL_TIER = "same_medal_tier"
    SAME_COUNTRY = "same_country"
    SAME_COMPANY = "same_company"
    SAME_COMPANY_TIME = "same_company_time"
    SAME_SCHOOL = "same_school"
    SAME_SCHOOL_TIME = "same_school_time"


EDGE_WEIGHTS = {
    EdgeType.SAME_COUNTRY_YEAR: 3.0,
    EdgeType.SAME_MEDAL_TIER: 2.0,
    EdgeType.SAME_COUNTRY: 1.0,
    EdgeType.SAME_COMPANY: 2.5,
    EdgeType.SAME_COMPANY_TIME: 4.0,
    EdgeType.SAME_SCHOOL: 2.0,
    EdgeType.SAME_SCHOOL_TIME: 3.5,
}
