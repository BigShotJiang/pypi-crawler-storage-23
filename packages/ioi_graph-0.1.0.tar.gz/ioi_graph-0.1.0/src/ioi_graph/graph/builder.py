from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from itertools import combinations

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from ioi_graph.db.repositories import IOIRepository
from ioi_graph.graph.models import EdgeType, EDGE_WEIGHTS

console = Console()


def _overlaps(
    a_start: int | None,
    a_end: int | None,
    b_start: int | None,
    b_end: int | None,
) -> bool:
    """Check if two year ranges overlap. None end means current year."""
    if a_start is None or b_start is None:
        return False
    current_year = datetime.now(timezone.utc).year
    a_end = a_end or current_year
    b_end = b_end or current_year
    return a_start <= b_end and b_start <= a_end


class GraphBuilder:
    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        self.repo = IOIRepository(conn)

    def build_all(self, edge_types: list[EdgeType] | None = None) -> dict[str, int]:
        if edge_types is None:
            edge_types = list(EdgeType)

        counts = {}
        for et in edge_types:
            self.repo.delete_edges(edge_type=et.value)
            self.conn.commit()

        if EdgeType.SAME_COUNTRY_YEAR in edge_types:
            counts["same_country_year"] = self._build_same_country_year()
        if EdgeType.SAME_MEDAL_TIER in edge_types:
            counts["same_medal_tier"] = self._build_same_medal_tier()
        if EdgeType.SAME_COUNTRY in edge_types:
            counts["same_country"] = self._build_same_country()
        if EdgeType.SAME_COMPANY in edge_types:
            counts["same_company"] = self._build_same_company()
        if EdgeType.SAME_COMPANY_TIME in edge_types:
            counts["same_company_time"] = self._build_same_company_time()
        if EdgeType.SAME_SCHOOL in edge_types:
            counts["same_school"] = self._build_same_school()
        if EdgeType.SAME_SCHOOL_TIME in edge_types:
            counts["same_school_time"] = self._build_same_school_time()

        return counts

    def build_incremental_year(self, year: int) -> dict[str, int]:
        counts = {}

        # Delete existing edges for this year
        for et in EdgeType:
            self.repo.delete_edges(edge_type=et.value, year=year)
        self.conn.commit()

        counts["same_country_year"] = self._build_same_country_year(year=year)
        counts["same_medal_tier"] = self._build_same_medal_tier(year=year)
        # same_country is cross-year, rebuild fully
        self.repo.delete_edges(edge_type=EdgeType.SAME_COUNTRY.value)
        self.conn.commit()
        counts["same_country"] = self._build_same_country()
        return counts

    def _build_same_country_year(self, year: int | None = None) -> int:
        """Teammates: same country in the same year."""
        weight = EDGE_WEIGHTS[EdgeType.SAME_COUNTRY_YEAR]
        if year:
            rows = self.conn.execute(
                "SELECT contestant_id, country_code FROM participations WHERE year = ?",
                (year,),
            ).fetchall()
            groups = {}
            for r in rows:
                key = (year, r["country_code"])
                groups.setdefault(key, []).append(r["contestant_id"])
            return self._insert_pairs(groups, EdgeType.SAME_COUNTRY_YEAR, weight, with_year=True)

        rows = self.conn.execute(
            "SELECT contestant_id, year, country_code FROM participations ORDER BY year, country_code"
        ).fetchall()
        groups: dict[tuple, list[int]] = {}
        for r in rows:
            key = (r["year"], r["country_code"])
            groups.setdefault(key, []).append(r["contestant_id"])
        return self._insert_pairs(groups, EdgeType.SAME_COUNTRY_YEAR, weight, with_year=True)

    def _build_same_medal_tier(self, year: int | None = None) -> int:
        """Same medal type in the same year."""
        weight = EDGE_WEIGHTS[EdgeType.SAME_MEDAL_TIER]
        query = "SELECT contestant_id, year, award FROM participations WHERE award IS NOT NULL"
        params: tuple = ()
        if year:
            query += " AND year = ?"
            params = (year,)
        rows = self.conn.execute(query, params).fetchall()

        groups: dict[tuple, list[int]] = {}
        for r in rows:
            key = (r["year"], r["award"])
            groups.setdefault(key, []).append(r["contestant_id"])
        return self._insert_pairs(groups, EdgeType.SAME_MEDAL_TIER, weight, with_year=True)

    def _build_same_country(self) -> int:
        """Cross-year: any two contestants who represented the same country."""
        weight = EDGE_WEIGHTS[EdgeType.SAME_COUNTRY]
        rows = self.conn.execute(
            "SELECT DISTINCT contestant_id, country_code FROM participations"
        ).fetchall()

        groups: dict[str, list[int]] = {}
        for r in rows:
            groups.setdefault(r["country_code"], []).append(r["contestant_id"])

        count = 0
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
        ) as progress:
            task = progress.add_task("Building same_country edges...", total=len(groups))
            for country_code, ids in groups.items():
                unique_ids = sorted(set(ids))
                for a, b in combinations(unique_ids, 2):
                    self.repo.insert_edge(a, b, EdgeType.SAME_COUNTRY.value, weight=weight)
                    count += 1
                progress.advance(task)
                # Commit in batches
                if count % 10000 == 0:
                    self.conn.commit()
        self.conn.commit()
        return count

    def _build_same_company(self) -> int:
        """Any two contestants who worked at the same company (any time)."""
        weight = EDGE_WEIGHTS[EdgeType.SAME_COMPANY]
        rows = self.conn.execute(
            "SELECT DISTINCT contestant_id, company FROM work_experiences"
        ).fetchall()

        groups: dict[str, list[int]] = {}
        for r in rows:
            groups.setdefault(r["company"], []).append(r["contestant_id"])

        count = 0
        for company, ids in groups.items():
            unique_ids = sorted(set(ids))
            for a, b in combinations(unique_ids, 2):
                self.repo.insert_edge(
                    a, b, EdgeType.SAME_COMPANY.value, weight=weight,
                    properties={"company": company},
                )
                count += 1
        self.conn.commit()
        return count

    def _build_same_company_time(self) -> int:
        """Same company with overlapping years (strongest professional tie)."""
        weight = EDGE_WEIGHTS[EdgeType.SAME_COMPANY_TIME]
        rows = self.conn.execute(
            "SELECT contestant_id, company, start_year, end_year FROM work_experiences"
        ).fetchall()

        # Group by company
        groups: dict[str, list[dict]] = {}
        for r in rows:
            groups.setdefault(r["company"], []).append({
                "id": r["contestant_id"],
                "start": r["start_year"],
                "end": r["end_year"],
            })

        count = 0
        for company, entries in groups.items():
            for i, a in enumerate(entries):
                for b in entries[i + 1:]:
                    if a["id"] == b["id"]:
                        continue
                    if _overlaps(a["start"], a["end"], b["start"], b["end"]):
                        self.repo.insert_edge(
                            a["id"], b["id"], EdgeType.SAME_COMPANY_TIME.value,
                            weight=weight,
                            properties={"company": company},
                        )
                        count += 1
        self.conn.commit()
        return count

    def _build_same_school(self) -> int:
        """Any two contestants who attended the same school (any time)."""
        weight = EDGE_WEIGHTS[EdgeType.SAME_SCHOOL]
        rows = self.conn.execute(
            "SELECT DISTINCT contestant_id, school FROM education"
        ).fetchall()

        groups: dict[str, list[int]] = {}
        for r in rows:
            groups.setdefault(r["school"], []).append(r["contestant_id"])

        count = 0
        for school, ids in groups.items():
            unique_ids = sorted(set(ids))
            for a, b in combinations(unique_ids, 2):
                self.repo.insert_edge(
                    a, b, EdgeType.SAME_SCHOOL.value, weight=weight,
                    properties={"school": school},
                )
                count += 1
        self.conn.commit()
        return count

    def _build_same_school_time(self) -> int:
        """Same school with overlapping years."""
        weight = EDGE_WEIGHTS[EdgeType.SAME_SCHOOL_TIME]
        rows = self.conn.execute(
            "SELECT contestant_id, school, start_year, end_year FROM education"
        ).fetchall()

        groups: dict[str, list[dict]] = {}
        for r in rows:
            groups.setdefault(r["school"], []).append({
                "id": r["contestant_id"],
                "start": r["start_year"],
                "end": r["end_year"],
            })

        count = 0
        for school, entries in groups.items():
            for i, a in enumerate(entries):
                for b in entries[i + 1:]:
                    if a["id"] == b["id"]:
                        continue
                    if _overlaps(a["start"], a["end"], b["start"], b["end"]):
                        self.repo.insert_edge(
                            a["id"], b["id"], EdgeType.SAME_SCHOOL_TIME.value,
                            weight=weight,
                            properties={"school": school},
                        )
                        count += 1
        self.conn.commit()
        return count

    def _insert_pairs(
        self,
        groups: dict,
        edge_type: EdgeType,
        weight: float,
        with_year: bool = False,
    ) -> int:
        count = 0
        for key, ids in groups.items():
            year_val = key[0] if with_year else None
            unique_ids = sorted(set(ids))
            for a, b in combinations(unique_ids, 2):
                self.repo.insert_edge(
                    a, b, edge_type.value, year=year_val, weight=weight
                )
                count += 1
        self.conn.commit()
        return count
