---
name: Feature Request
about: Suggest a new feature for Qlue-ls
title: "[FEATURE] "
labels: enhancement
assignees:

---

**Describe the feature**
A clear and concise description of what you want.

**Problem it solves**
Why this feature is useful.

**Additional context**
Any extra info, ideas, or examples.
