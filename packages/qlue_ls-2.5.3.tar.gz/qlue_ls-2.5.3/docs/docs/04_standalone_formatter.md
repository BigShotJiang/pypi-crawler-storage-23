# Formatter

Qlue-ls can be used as standalone formatter.
Just run:

```shell
qlue-ls format <path_to_document>
```

You can also format a document in-place using the `writeback` option:

```shell
qlue-ls format --writeback <path_to_document>
```
