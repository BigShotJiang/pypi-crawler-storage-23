# Environment schema

## Environment

::: rbx.box.environment
    options:
      show_root_heading: false
      show_root_toc_entry: false
      heading_level: 3
      show_labels: false

## Extensions

::: rbx.box.extensions
    options:
      show_root_heading: false
      show_root_toc_entry: false
      heading_level: 3
      show_labels: false

### BOCA

::: rbx.box.packaging.boca.extension
    options:
      show_root_heading: false
      show_root_toc_entry: false
      heading_level: 4
      show_labels: false
