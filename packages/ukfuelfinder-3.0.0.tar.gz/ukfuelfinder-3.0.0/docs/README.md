To get the latest openapi spec:

	wget https://www.developer.fuel-finder.service.gov.uk/openapi/info-recipent.en.json


Main changes:

Removal of mft_organisation_name: This field has been removed from all API responses to streamline the data extracts.

Removal of mft.name: Similar to the above, this field was removed from public data extracts, and the Developer Portal documentation was updated to reflect this change.


