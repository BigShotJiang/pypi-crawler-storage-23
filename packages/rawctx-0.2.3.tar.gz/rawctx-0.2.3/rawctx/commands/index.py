from __future__ import annotations

from pathlib import Path

import click

from rawctx.config import ConfigStore, resolve_registry, resolve_token
from rawctx.indexer import IndexRunResult, index_dbt_seed_entry, load_dbt_seed_entries


@click.group()
def index() -> None:
    """Index external package sources into rawctx Hub."""


@index.command("dbt")
@click.option("--seed-file", "seed_file", type=click.Path(path_type=Path, exists=True), required=True)
@click.option("--only", "only_repo", default=None, help="Index only this repo (owner/name)")
@click.option("--limit", type=int, default=0, show_default=True, help="Max entries to process (0 = no limit)")
@click.option("--dry-run", is_flag=True, default=False, help="Run conversion checks without publishing")
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
def index_dbt(
    seed_file: Path,
    only_repo: str | None,
    limit: int,
    dry_run: bool,
    registry_override: str | None,
) -> None:
    if limit < 0:
        raise click.UsageError("--limit must be >= 0")

    entries = load_dbt_seed_entries(seed_file)
    if only_repo:
        entries = [entry for entry in entries if entry.repo == only_repo]

    if limit > 0:
        entries = entries[:limit]

    store = ConfigStore()
    config = store.load()
    registry = resolve_registry(cli_registry=registry_override, config=config)
    token = resolve_token(config)

    if not dry_run and not token:
        raise click.ClickException("Authentication required. Run `rawctx login` first.")

    if not entries:
        click.echo("No matching seed entries.")
        return

    results: list[IndexRunResult] = []
    for entry in entries:
        result = index_dbt_seed_entry(
            entry=entry,
            registry=registry,
            token=token,
            dry_run=dry_run,
        )
        results.append(result)

        package_ref = result.package_ref or "-"
        version = result.version or "-"
        reason = f" ({result.reason})" if result.reason else ""
        click.echo(f"[{result.status}] {entry.repo} -> {package_ref}@{version}{reason}")

    indexed = sum(1 for item in results if item.status == "indexed")
    skipped = sum(1 for item in results if item.status == "skipped")
    failed = sum(1 for item in results if item.status == "failed")
    dry = sum(1 for item in results if item.status == "dry-run")

    click.echo(
        f"summary: total={len(results)} indexed={indexed} skipped={skipped} dry_run={dry} failed={failed}"
    )

    if failed > 0:
        raise click.ClickException("one or more indexing jobs failed")
