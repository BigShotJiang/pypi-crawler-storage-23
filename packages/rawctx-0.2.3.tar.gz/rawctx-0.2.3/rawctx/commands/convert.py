from __future__ import annotations

import re
from pathlib import Path
import shutil

import click
import yaml

from rawctx.commands.validate import validate_target
from rawctx.config import ConfigStore
from rawctx.converter import get_conversion_registry
from rawctx.converter.base import ConversionError, SUPPORTED_SOURCE_FORMATS, SUPPORTED_TARGET_FORMATS
from rawctx.converter.metricflow_to_osi import build_converted_package
from rawctx.packaging.manifest import PACKAGE_NAME_RE, SEMVER_RE, ValidationError


_SAFE_NAME_RE = re.compile(r"[^a-z0-9-]+")


def _slugify(value: str) -> str:
    normalized = value.strip().lower().replace("_", "-").replace(" ", "-")
    normalized = _SAFE_NAME_RE.sub("-", normalized).strip("-")
    return normalized or "semantic-model"


def _default_package_name(project_name: str, username: str | None) -> str:
    scope = _slugify(username or "demo")
    package = f"{_slugify(project_name)}-semantic"
    return f"@{scope}/{package}"


def _resolve_package_name(project_name: str, package_name: str | None, username: str | None) -> str:
    candidate = package_name.strip() if package_name else _default_package_name(project_name, username)
    if not PACKAGE_NAME_RE.fullmatch(candidate):
        raise click.UsageError("package name must match @scope/name with lowercase letters, numbers, and hyphen")
    return candidate


def _resolve_version(project_version: str | None, package_version: str | None) -> str:
    if package_version:
        candidate = package_version.strip()
        if not SEMVER_RE.fullmatch(candidate):
            raise click.UsageError("package version must be strict SemVer X.Y.Z")
        return candidate

    if project_version and SEMVER_RE.fullmatch(project_version.strip()):
        return project_version.strip()

    return "0.1.0"


def _write_yaml(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = yaml.safe_dump(payload, sort_keys=False, allow_unicode=False)
    path.write_text(text, encoding="utf-8")


def _materialize_package(
    output_dir: Path,
    *,
    package_name: str,
    package_version: str,
    source_format: str,
    model_documents: dict[str, dict],
    overwrite: bool,
) -> list[Path]:
    if output_dir.exists():
        if not overwrite:
            raise click.ClickException(f"output already exists: {output_dir} (use --overwrite)")
        shutil.rmtree(output_dir)

    output_dir.mkdir(parents=True, exist_ok=True)
    models_dir = output_dir / "models"
    models_dir.mkdir(parents=True, exist_ok=True)

    model_paths: list[str] = []
    written: list[Path] = []

    for file_name in sorted(model_documents.keys()):
        model_rel_path = Path("models") / file_name
        model_path = output_dir / model_rel_path
        _write_yaml(model_path, model_documents[file_name])
        model_paths.append(model_rel_path.as_posix())
        written.append(model_path)

    manifest = {
        "name": package_name,
        "version": package_version,
        "format": "osi",
        "source_format": source_format,
        "description": f"Converted from {source_format}",
        "source": "dbt",
        "models": model_paths,
    }
    manifest_path = output_dir / "rawctx.yaml"
    _write_yaml(manifest_path, manifest)
    written.append(manifest_path)

    readme_path = output_dir / "README.md"
    readme_path.write_text(
        (
            f"# {package_name}\n\n"
            f"Converted from `{source_format}` using `rawctx convert`.\n"
        ),
        encoding="utf-8",
    )
    written.append(readme_path)

    return written


@click.command()
@click.argument("input_path", type=click.Path(path_type=Path), required=True)
@click.option(
    "--from",
    "from_format",
    type=click.Choice(list(SUPPORTED_SOURCE_FORMATS), case_sensitive=False),
    required=True,
    help="Source format",
)
@click.option(
    "--to",
    "to_format",
    type=click.Choice(list(SUPPORTED_TARGET_FORMATS), case_sensitive=False),
    required=True,
    help="Target format",
)
@click.option("--output", "output_dir", type=click.Path(path_type=Path), required=True, help="Output package directory")
@click.option("--package-name", default=None, help="Override generated package name")
@click.option("--package-version", default=None, help="Override generated package version")
@click.option("--overwrite", is_flag=True, default=False, help="Replace output directory if it exists")
def convert(
    input_path: Path,
    from_format: str,
    to_format: str,
    output_dir: Path,
    package_name: str | None,
    package_version: str | None,
    overwrite: bool,
) -> None:
    from_format = from_format.lower().strip()
    to_format = to_format.lower().strip()

    registry = get_conversion_registry()
    try:
        route = registry.get(from_format, to_format)
    except ConversionError as exc:
        raise click.UsageError(str(exc)) from exc

    try:
        project = route.convert(input_path)
    except ConversionError as exc:
        raise click.ClickException(str(exc)) from exc

    store = ConfigStore()
    config = store.load()

    resolved_package_name = _resolve_package_name(project.project_name, package_name, config.profile.username)
    resolved_version = _resolve_version(project.project_version, package_version)

    converted = build_converted_package(
        project,
        package_name=resolved_package_name,
        version=resolved_version,
        source_format=from_format,
    )

    written = _materialize_package(
        output_dir.expanduser().resolve(),
        package_name=converted.package_name,
        package_version=converted.version,
        source_format=converted.source_format,
        model_documents=converted.model_documents,
        overwrite=overwrite,
    )

    try:
        validate_target(output_dir, "auto")
    except ValidationError as exc:
        raise click.ClickException(str(exc)) from exc

    click.echo(f"Converted {from_format} -> {to_format}")
    click.echo(f"Package: {converted.package_name}@{converted.version}")
    click.echo(f"Wrote {len(written)} file(s) to {output_dir}")


__all__ = ["convert"]
