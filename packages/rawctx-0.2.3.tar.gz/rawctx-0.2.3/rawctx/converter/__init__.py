from __future__ import annotations

from rawctx.converter.base import ConversionRegistry, ConversionRoute
from rawctx.converter.metricflow_to_osi import metricflow_to_project_ir


def get_conversion_registry() -> ConversionRegistry:
    registry = ConversionRegistry()
    registry.register(
        ConversionRoute(
            from_format="metricflow",
            to_format="osi",
            description="Convert MetricFlow semantic models to OSI v1.0",
            convert=metricflow_to_project_ir,
        )
    )
    return registry
