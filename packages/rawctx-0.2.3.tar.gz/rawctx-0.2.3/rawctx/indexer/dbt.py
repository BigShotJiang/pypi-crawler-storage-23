from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
import shutil
import tempfile

import yaml

from rawctx.commands.convert import _materialize_package
from rawctx.commands.validate import validate_target
from rawctx.converter import get_conversion_registry
from rawctx.converter.base import ConversionError
from rawctx.converter.metricflow_to_osi import build_converted_package
from rawctx.indexer.github import GitHubIndexError, download_repo_archive
from rawctx.packaging.builder import build_package_archive
from rawctx.packaging.manifest import SEMVER_RE, ValidationError
from rawctx.registry.client import RegistryClient, RegistryError


@dataclass(frozen=True)
class DbtSeedEntry:
    repo: str
    hub_url: str
    source_ref: str
    package_version: str
    package_name: str | None = None


@dataclass(frozen=True)
class IndexRunResult:
    repo: str
    package_ref: str | None
    version: str | None
    status: str
    reason: str | None = None


def _normalize_name(value: str) -> str:
    lowered = value.strip().lower().replace("_", "-").replace(" ", "-")
    out = []
    for ch in lowered:
        if ch.isalnum() or ch == "-":
            out.append(ch)
        else:
            out.append("-")
    compact = "".join(out).strip("-")
    while "--" in compact:
        compact = compact.replace("--", "-")
    return compact or "package"


def _safe_str(value: object) -> str:
    if isinstance(value, str):
        stripped = value.strip()
        if stripped:
            return stripped
    raise ValueError("expected non-empty string")


def load_dbt_seed_entries(seed_file: Path) -> list[DbtSeedEntry]:
    try:
        raw = yaml.safe_load(seed_file.read_text(encoding="utf-8"))
    except OSError as exc:
        raise RuntimeError(f"failed to read seed file: {seed_file}") from exc

    if not isinstance(raw, list):
        raise RuntimeError("seed file must be a list")

    entries: list[DbtSeedEntry] = []
    for idx, item in enumerate(raw):
        if not isinstance(item, dict):
            raise RuntimeError(f"seed entry[{idx}] must be an object")

        try:
            repo = _safe_str(item.get("repo"))
            hub_url = _safe_str(item.get("hub_url"))
            source_ref = _safe_str(item.get("source_ref"))
            package_version = _safe_str(item.get("package_version"))
            package_name_raw = item.get("package_name")
            package_name = _safe_str(package_name_raw) if package_name_raw is not None else None
        except ValueError as exc:
            raise RuntimeError(f"invalid seed entry[{idx}]: {exc}") from exc

        entries.append(
            DbtSeedEntry(
                repo=repo,
                hub_url=hub_url,
                source_ref=source_ref,
                package_version=package_version,
                package_name=package_name,
            )
        )

    return entries


def _default_package_name(repo: str, explicit: str | None) -> str:
    if explicit:
        return _normalize_name(explicit)
    leaf = repo.split("/", 1)[-1]
    return _normalize_name(leaf.removeprefix("dbt_"))


def index_dbt_seed_entry(
    *,
    entry: DbtSeedEntry,
    registry: str,
    token: str | None,
    dry_run: bool,
) -> IndexRunResult:
    package_name = _default_package_name(entry.repo, entry.package_name)
    package_ref = f"@dbt-hub/{package_name}"

    if SEMVER_RE.fullmatch(entry.package_version) is None:
        return IndexRunResult(
            repo=entry.repo,
            package_ref=package_ref,
            version=entry.package_version,
            status="skipped",
            reason="package_version must be strict SemVer X.Y.Z",
        )

    workspace = Path(tempfile.mkdtemp(prefix="rawctx-index-dbt-"))
    try:
        try:
            project_root = download_repo_archive(repo=entry.repo, ref=entry.source_ref, target_dir=workspace / "repo")
        except GitHubIndexError as exc:
            return IndexRunResult(
                repo=entry.repo,
                package_ref=package_ref,
                version=entry.package_version,
                status="failed",
                reason=str(exc),
            )

        route = get_conversion_registry().get("metricflow", "osi")
        try:
            project = route.convert(project_root)
        except ConversionError as exc:
            reason = str(exc)
            if "no semantic_models found" in reason:
                return IndexRunResult(
                    repo=entry.repo,
                    package_ref=package_ref,
                    version=entry.package_version,
                    status="skipped",
                    reason="semantic_models not found",
                )
            return IndexRunResult(
                repo=entry.repo,
                package_ref=package_ref,
                version=entry.package_version,
                status="failed",
                reason=reason,
            )

        converted = build_converted_package(
            project,
            package_name=package_ref,
            version=entry.package_version,
            source_format="metricflow",
        )

        package_dir = workspace / "package"
        _materialize_package(
            package_dir,
            package_name=converted.package_name,
            package_version=converted.version,
            source_format=converted.source_format,
            model_documents=converted.model_documents,
            overwrite=True,
        )

        try:
            validate_target(package_dir, "auto")
        except ValidationError as exc:
            return IndexRunResult(
                repo=entry.repo,
                package_ref=package_ref,
                version=entry.package_version,
                status="failed",
                reason=str(exc),
            )

        if dry_run:
            return IndexRunResult(
                repo=entry.repo,
                package_ref=package_ref,
                version=entry.package_version,
                status="dry-run",
                reason=f"semantic_models={len(project.semantic_models)}",
            )

        if not token:
            return IndexRunResult(
                repo=entry.repo,
                package_ref=package_ref,
                version=entry.package_version,
                status="failed",
                reason="authentication required for indexing",
            )

        build_dir = workspace / "dist"
        build_dir.mkdir(parents=True, exist_ok=True)
        build = build_package_archive(package_dir, build_dir)
        archive_bytes = build.archive_path.read_bytes()
        checksum = sha256(archive_bytes).hexdigest()

        payload = {
            "scope": "dbt-hub",
            "name": package_name,
            "description": f"Indexed preview from dbt Hub: {entry.repo}",
            "format": "osi",
            "source_format": "metricflow",
            "origin": "indexed",
            "origin_url": entry.hub_url,
            "origin_repo": entry.repo,
            "source": "dbt-hub",
            "repository_url": f"https://github.com/{entry.repo}",
            "tags": ["indexed", "dbt-hub", "metricflow"],
        }

        client = RegistryClient(registry=registry, token=token)
        try:
            try:
                client.create_package(payload=payload)
            except RegistryError as exc:
                if exc.status_code != 409:
                    raise

            try:
                upload = client.request_version_upload(
                    scope="dbt-hub",
                    name=package_name,
                    version=entry.package_version,
                    file_size=len(archive_bytes),
                    checksum_sha256=checksum,
                    origin_ref=entry.source_ref,
                    content_type="application/gzip",
                )
            except RegistryError as exc:
                if exc.status_code == 409:
                    return IndexRunResult(
                        repo=entry.repo,
                        package_ref=package_ref,
                        version=entry.package_version,
                        status="skipped",
                        reason="version already exists",
                    )
                raise

            upload_url = str(upload.get("upload_url") or "")
            if not upload_url:
                return IndexRunResult(
                    repo=entry.repo,
                    package_ref=package_ref,
                    version=entry.package_version,
                    status="failed",
                    reason="registry did not return upload_url",
                )

            client.upload_bytes(upload_url=upload_url, payload=archive_bytes, content_type="application/gzip")
            client.complete_version(
                scope="dbt-hub",
                name=package_name,
                version=entry.package_version,
                checksum_sha256=checksum,
            )
        except RegistryError as exc:
            return IndexRunResult(
                repo=entry.repo,
                package_ref=package_ref,
                version=entry.package_version,
                status="failed",
                reason=str(exc),
            )
        finally:
            client.close()

        return IndexRunResult(
            repo=entry.repo,
            package_ref=package_ref,
            version=entry.package_version,
            status="indexed",
        )
    finally:
        shutil.rmtree(workspace, ignore_errors=True)
