from __future__ import annotations

from io import BytesIO
from pathlib import Path
import tarfile

import httpx


class GitHubIndexError(RuntimeError):
    pass


def _safe_extract_tar(*, payload: bytes, target_dir: Path) -> Path:
    target_dir.mkdir(parents=True, exist_ok=True)
    with tarfile.open(fileobj=BytesIO(payload), mode="r:gz") as tar:
        members = tar.getmembers()
        if not members:
            raise GitHubIndexError("empty repository archive")

        root_names = {Path(member.name).parts[0] for member in members if member.name and Path(member.name).parts}
        if len(root_names) != 1:
            raise GitHubIndexError("unexpected repository archive layout")

        root_name = next(iter(root_names))

        for member in members:
            destination = (target_dir / member.name).resolve()
            if target_dir.resolve() not in destination.parents and destination != target_dir.resolve():
                raise GitHubIndexError(f"unsafe archive entry: {member.name}")

        tar.extractall(path=target_dir)

    return (target_dir / root_name).resolve()


def download_repo_archive(*, repo: str, ref: str, target_dir: Path, timeout: float = 30.0) -> Path:
    repo_name = repo.strip()
    ref_name = ref.strip()
    if not repo_name or "/" not in repo_name:
        raise GitHubIndexError("repo must match owner/name")
    if not ref_name:
        raise GitHubIndexError("ref is required")

    url = f"https://codeload.github.com/{repo_name}/tar.gz/{ref_name}"
    try:
        response = httpx.get(url, timeout=timeout)
        response.raise_for_status()
    except httpx.HTTPError as exc:
        raise GitHubIndexError(f"failed to download {repo_name}@{ref_name}: {exc}") from exc

    return _safe_extract_tar(payload=response.content, target_dir=target_dir)
