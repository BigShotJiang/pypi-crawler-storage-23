"""Dependency resolver placeholder."""
