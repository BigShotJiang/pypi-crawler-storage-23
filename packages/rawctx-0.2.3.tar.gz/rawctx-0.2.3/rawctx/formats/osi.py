from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator
import yaml
from yaml import YAMLError

from rawctx.packaging.manifest import ValidationError


@dataclass(frozen=True)
class OsiSummary:
    datasets: int
    measures: int
    dimensions: int
    relationships: int
    has_ai_context: bool


def _schema_path() -> Path:
    return Path(__file__).resolve().parent.parent / "schemas" / "osi" / "v1.0" / "schema.json"


def _load_schema() -> dict[str, Any]:
    schema_file = _schema_path()
    try:
        with schema_file.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except OSError as exc:
        raise ValidationError("failed to load vendored OSI schema", schema_file) from exc


def _read_yaml(path: Path) -> dict[str, Any]:
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = yaml.safe_load(handle)
    except YAMLError as exc:
        line = getattr(getattr(exc, "problem_mark", None), "line", None)
        col = getattr(getattr(exc, "problem_mark", None), "column", None)
        raise ValidationError(
            "invalid YAML syntax",
            path,
            line=None if line is None else line + 1,
            column=None if col is None else col + 1,
        ) from exc
    except OSError as exc:
        raise ValidationError("failed to read OSI file", path) from exc

    if not isinstance(data, dict):
        raise ValidationError("OSI document root must be a mapping", path)
    return data


def _first_schema_error(path: Path, data: dict[str, Any], schema: dict[str, Any]) -> ValidationError | None:
    validator = Draft202012Validator(schema)
    for error in validator.iter_errors(data):
        field = ".".join(str(part) for part in error.absolute_path)
        return ValidationError(
            message=error.message,
            file_path=path,
            field=field or None,
        )
    return None


def _has_ai_context(obj: Any) -> bool:
    if isinstance(obj, dict):
        if "ai_context" in obj:
            ai_context = obj["ai_context"]
            if ai_context is not None:
                if not (isinstance(ai_context, str) and not ai_context.strip()) and not (isinstance(ai_context, (list, dict)) and len(ai_context) == 0):
                    return True
        for value in obj.values():
            if _has_ai_context(value):
                return True
        return False
    if isinstance(obj, list):
        return any(_has_ai_context(item) for item in obj)
    return False


def _summary(data: dict[str, Any]) -> OsiSummary:
    semantic_models = data.get("semantic_model", [])
    if not isinstance(semantic_models, list):
        semantic_models = []

    datasets = 0
    measures = 0
    dimensions = 0
    relationships = 0

    for semantic_model in semantic_models:
        if not isinstance(semantic_model, dict):
            continue

        model_metrics = semantic_model.get("metrics", [])
        model_relationships = semantic_model.get("relationships", [])
        model_datasets = semantic_model.get("datasets", [])

        if isinstance(model_metrics, list):
            measures += len(model_metrics)
        if isinstance(model_relationships, list):
            relationships += len(model_relationships)

        if isinstance(model_datasets, list):
            datasets += len(model_datasets)
            for dataset in model_datasets:
                if not isinstance(dataset, dict):
                    continue
                fields = dataset.get("fields", [])
                if not isinstance(fields, list):
                    continue
                for field in fields:
                    if not isinstance(field, dict):
                        continue
                    if isinstance(field.get("dimension"), dict):
                        dimensions += 1

    return OsiSummary(
        datasets=datasets,
        measures=measures,
        dimensions=dimensions,
        relationships=relationships,
        has_ai_context=_has_ai_context(data),
    )


def validate_osi(path: Path) -> OsiSummary:
    data = _read_yaml(path)
    schema = _load_schema()
    schema_error = _first_schema_error(path, data, schema)
    if schema_error is not None:
        raise schema_error
    return _summary(data)
