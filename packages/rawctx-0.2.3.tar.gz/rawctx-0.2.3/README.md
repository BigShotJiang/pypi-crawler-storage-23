# rawctx CLI

Python Click-based CLI for rawctx Hub.

## Commands

- `rawctx login [--registry URL] [--id-token JWT] [--token-name NAME] [--expires-in-days N] [--no-browser]`
- `rawctx logout [--local-only]`
- `rawctx publish [TARGET_DIR] [--registry URL]`
- `rawctx publish --from-dbt DBT_PROJECT_DIR [--emit-package DIR] [--package-name @scope/name] [--package-version X.Y.Z] [--registry URL]`
- `rawctx convert --from metricflow --to osi INPUT_PATH --output DIR [--package-name @scope/name] [--package-version X.Y.Z] [--overwrite]`
- `rawctx search [QUERY] [--format F] [--source-format F] [--domain D] [--source S] [--tags CSV] [--page N] [--size N] [--json] [--offline]`
- `rawctx install PACKAGE_REF [--dest PATH] [--offline] [--force] [--registry URL]`
- `rawctx info PACKAGE_REF [--json] [--offline] [--registry URL]`
- `rawctx validate [TARGET] --format auto|manifest|osi`
- `rawctx pack [TARGET_DIR] --output-dir dist`

## Round 6 Convert Workflow

```bash
rawctx convert --from metricflow --to osi ./my-dbt-project --output ./dist/pkg
rawctx validate ./dist/pkg
rawctx pack ./dist/pkg
```

Publish directly from dbt:

```bash
rawctx publish --from-dbt ./my-dbt-project --emit-package ./dist/pkg
```

## Auth Flow (Auto + Fallback)

1. Run `rawctx login`.
2. CLI opens (or prints) the OAuth URL from `POST /api/auth/login/github`.
3. Complete GitHub login in browser.
4. CLI automatically polls OAuth session status and captures `id_token`.
5. CLI calls `POST /api/auth/token` and stores API token in `~/.rawctx/config.yaml`.

Manual fallback:

- `rawctx login --id-token '<JWT>'`

## Config and Environment

Config file (default): `~/.rawctx/config.yaml`

```yaml
registry: "https://api.rawctx.dev"
auth:
  token: "rxctx_..."
  token_id: "uuid"
  token_name: "rawctx-cli"
  issued_at: "2026-02-28T00:00:00+00:00"
profile:
  username: "owner"
```

Environment overrides:

- `RAWCTX_CONFIG` (config path)
- `RAWCTX_REGISTRY` (registry URL)
- `RAWCTX_TOKEN` (auth token)

Priority: CLI option > env var > config > default.

## Offline Mode

`--offline` is supported for:

- `search`
- `info`
- `install`

Cache paths:

- index: `~/.rawctx/cache/packages.json`
- archives: `~/.rawctx/cache/archives/@scope/name/<version>.rawctx.tar.gz`
- installs: `~/.rawctx/packages/@scope/name/<version>/`
