from __future__ import annotations

from io import BytesIO
from pathlib import Path
import tarfile

from click.testing import CliRunner

from rawctx.cli import main
from rawctx.registry.client import RegistryClient, RegistryError
from rawctx.registry.models import PackageDetail, VersionInfo


def _archive_bytes(version: str) -> bytes:
    payload = BytesIO()
    with tarfile.open(fileobj=payload, mode="w:gz") as tar:
        rawctx_yaml = f"name: \"@owner/sample\"\nversion: \"{version}\"\nformat: \"osi\"\nmodels:\n  - models/sample.osi.yaml\n"
        model_yaml = (
            "version: \"1.0\"\n"
            "dialects:\n"
            "  - ANSI_SQL\n"
            "vendors:\n"
            "  - COMMON\n"
            "semantic_model:\n"
            "  - name: sample\n"
            "    datasets:\n"
            "      - name: sample\n"
            "        source: analytics.sample\n"
        )
        for name, content in {
            "package/rawctx.yaml": rawctx_yaml,
            "package/models/sample.osi.yaml": model_yaml,
        }.items():
            content_bytes = content.encode("utf-8")
            info = tarfile.TarInfo(name=name)
            info.size = len(content_bytes)
            info.mtime = 0
            tar.addfile(info, BytesIO(content_bytes))
    return payload.getvalue()


def test_install_online_selects_latest_semver(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: PackageDetail(
            id="pkg",
            scope=scope,
            name=name,
            description="Sample",
            format="osi",
            source_format=None,
            origin="native",
            origin_url=None,
            origin_repo=None,
            source=None,
            domain=None,
            license=None,
            repository_url=None,
            readme=None,
            tags=[],
            is_private=False,
            download_count=0,
            star_count=0,
            owner=None,
        ),
    )

    versions = [
        VersionInfo(
            id="v100",
            version="1.0.0",
            status="published",
            search_index_status="indexed",
            file_size=1,
            checksum_sha256="a" * 64,
            model_summary=None,
            created_at="2026-02-28T00:00:00Z",
            published_at="2026-02-28T00:00:00Z",
        ),
        VersionInfo(
            id="v120",
            version="1.2.0",
            status="published",
            search_index_status="indexed",
            file_size=1,
            checksum_sha256="b" * 64,
            model_summary=None,
            created_at="2026-02-28T00:00:00Z",
            published_at="2026-02-28T00:00:00Z",
        ),
    ]
    monkeypatch.setattr(RegistryClient, "list_versions", lambda self, scope, name, page=1, size=100: (versions, {"page": 1, "size": 100, "total": 2}))

    observed: dict[str, str] = {}

    def fake_request_download(self, *, scope: str, name: str, version: str):
        observed["version"] = version
        return {"download_url": f"https://download.example/{scope}/{name}/{version}", "expires_in": 900}

    monkeypatch.setattr(RegistryClient, "request_download", fake_request_download)
    monkeypatch.setattr(RegistryClient, "download_bytes", lambda self, download_url: _archive_bytes("1.2.0"))

    runner = CliRunner()
    result = runner.invoke(main, ["install", "@owner/sample", "--registry", "https://registry.example"])

    assert result.exit_code == 0
    assert observed["version"] == "1.2.0"
    assert "@owner/sample@1.2.0" in result.output


def test_install_blocks_indexed_package(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: PackageDetail(
            id="pkg",
            scope=scope,
            name=name,
            description="Indexed sample",
            format="osi",
            source_format="metricflow",
            origin="indexed",
            origin_url="https://hub.getdbt.com/fivetran/shopify/latest/",
            origin_repo="fivetran/dbt_shopify",
            source="dbt-hub",
            domain=None,
            license=None,
            repository_url=None,
            readme=None,
            tags=[],
            is_private=False,
            download_count=0,
            star_count=0,
            owner=None,
        ),
    )

    called = {"download": False}

    def fake_request_download(self, *, scope: str, name: str, version: str):
        called["download"] = True
        return {"download_url": "https://download.example/unused", "expires_in": 900}

    monkeypatch.setattr(RegistryClient, "request_download", fake_request_download)

    runner = CliRunner()
    result = runner.invoke(main, ["install", "@owner/sample", "--registry", "https://registry.example"])

    assert result.exit_code != 0
    assert "indexed from dbt Hub" in result.output
    assert called["download"] is False


def test_install_handles_indexed_download_403(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    monkeypatch.setattr(
        RegistryClient,
        "get_package",
        lambda self, scope, name: PackageDetail(
            id="pkg",
            scope=scope,
            name=name,
            description="Sample",
            format="osi",
            source_format=None,
            origin="native",
            origin_url=None,
            origin_repo=None,
            source=None,
            domain=None,
            license=None,
            repository_url=None,
            readme=None,
            tags=[],
            is_private=False,
            download_count=0,
            star_count=0,
            owner=None,
        ),
    )

    versions = [
        VersionInfo(
            id="v100",
            version="0.1.0",
            status="published",
            search_index_status="indexed",
            file_size=1,
            checksum_sha256="a" * 64,
            model_summary=None,
            created_at="2026-03-02T00:00:00Z",
            published_at="2026-03-02T00:00:00Z",
        )
    ]
    monkeypatch.setattr(RegistryClient, "list_versions", lambda self, scope, name, page=1, size=100: (versions, {"page": 1, "size": 100, "total": 1}))

    def fake_request_download(self, *, scope: str, name: str, version: str):
        raise RegistryError(
            "Registry request failed (403)",
            status_code=403,
            payload={
                "error": "indexed_package",
                "message": "This package is indexed from dbt Hub. Install is not supported.",
                "origin_url": "https://hub.getdbt.com/dbt-labs/jaffle-shop/latest/",
                "claim_url": "https://hub.rawctx.dev/packages/@dbt-hub/jaffle-shop/claim",
            },
        )

    monkeypatch.setattr(RegistryClient, "request_download", fake_request_download)

    runner = CliRunner()
    result = runner.invoke(main, ["install", "@owner/sample@0.1.0", "--registry", "https://registry.example"])

    assert result.exit_code != 0
    assert "indexed from dbt Hub" in result.output
    assert "https://hub.getdbt.com/dbt-labs/jaffle-shop/latest/" in result.output
    assert "https://hub.rawctx.dev/packages/@dbt-hub/jaffle-shop/claim" in result.output
