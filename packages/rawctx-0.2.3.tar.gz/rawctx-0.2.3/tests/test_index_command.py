from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from rawctx.cli import main
import rawctx.commands.index as index_module
from rawctx.indexer.dbt import IndexRunResult


def _write_seed(path: Path) -> Path:
    seed = path / "seed.yaml"
    seed.write_text(
        (
            "- repo: fivetran/dbt_shopify\n"
            "  hub_url: https://hub.getdbt.com/fivetran/shopify/latest/\n"
            "  source_ref: v0.12.0\n"
            "  package_version: 0.12.0\n"
            "  package_name: fivetran-shopify\n"
        ),
        encoding="utf-8",
    )
    return seed


def test_index_dbt_dry_run(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    seed = _write_seed(tmp_path)

    observed: dict[str, object] = {}

    def fake_index_dbt_seed_entry(*, entry, registry, token, dry_run):  # type: ignore[no-untyped-def]
        observed["repo"] = entry.repo
        observed["registry"] = registry
        observed["token"] = token
        observed["dry_run"] = dry_run
        return IndexRunResult(
            repo=entry.repo,
            package_ref="@dbt-hub/fivetran-shopify",
            version="0.12.0",
            status="dry-run",
            reason="semantic_models=2",
        )

    monkeypatch.setattr(index_module, "index_dbt_seed_entry", fake_index_dbt_seed_entry)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "index",
            "dbt",
            "--seed-file",
            str(seed),
            "--dry-run",
            "--registry",
            "https://registry.example",
        ],
    )

    assert result.exit_code == 0, result.output
    assert observed["repo"] == "fivetran/dbt_shopify"
    assert observed["registry"] == "https://registry.example"
    assert observed["token"] is None
    assert observed["dry_run"] is True
    assert "[dry-run]" in result.output


def test_index_dbt_requires_auth_when_not_dry_run(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.delenv("RAWCTX_TOKEN", raising=False)
    seed = _write_seed(tmp_path)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "index",
            "dbt",
            "--seed-file",
            str(seed),
            "--registry",
            "https://registry.example",
        ],
    )

    assert result.exit_code != 0
    assert "Authentication required" in result.output
