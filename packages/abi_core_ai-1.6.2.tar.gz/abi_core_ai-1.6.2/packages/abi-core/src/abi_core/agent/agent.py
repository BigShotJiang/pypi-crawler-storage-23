"""
Base ABI Agent Class
Core agent functionality for ABI Framework
"""

import logging
from typing import Dict, Any, AsyncIterable
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)

class AbiAgent(ABC):
    """Base class for all ABI agents"""
    
    def __init__(self, agent_name: str, description: str, content_types: list):
        self.agent_name = agent_name
        self.description = description
        self.content_types = content_types
        logger.info(f"🤖 Initialized {agent_name}: {description}")
    
    @abstractmethod
    async def stream(self, query: str, context_id: str, task_id: str) -> AsyncIterable[Dict[str, Any]]:
        """
        Process query and stream responses
        
        Args:
            query: User query to process
            context_id: Context identifier
            task_id: Task identifier
            
        Yields:
            Dict containing response data with keys:
            - content: Response content
            - response_type: 'text' or 'data'
            - is_task_completed: Boolean
            - require_user_input: Boolean
        """
        pass
    
    def get_info(self) -> Dict[str, Any]:
        """Get agent information"""
        return {
            "name": self.agent_name,
            "description": self.description,
            "content_types": self.content_types
        }