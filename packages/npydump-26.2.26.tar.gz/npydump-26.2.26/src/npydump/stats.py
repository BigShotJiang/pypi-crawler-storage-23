"""Statistics helpers."""

from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

import numpy as np


def compute_stats(arr: np.ndarray) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    if arr.dtype == object:
        return None, "stats not supported for object dtype"
    if np.iscomplexobj(arr):
        return None, "stats not supported for complex dtype"
    if not (np.issubdtype(arr.dtype, np.number) or np.issubdtype(arr.dtype, np.bool_)):
        return None, f"stats not supported for dtype {arr.dtype}"

    flat = arr.ravel()
    count = int(flat.size)
    if count == 0:
        return {
            "count": 0,
            "min": None,
            "max": None,
            "mean": None,
            "std": None,
            "nan_count": 0,
            "inf_count": 0,
        }, None

    if np.issubdtype(arr.dtype, np.floating):
        nan_count = int(np.isnan(flat).sum())
        inf_count = int(np.isinf(flat).sum())
        finite = np.isfinite(flat)
        if not finite.any():
            return {
                "count": count,
                "min": None,
                "max": None,
                "mean": None,
                "std": None,
                "nan_count": nan_count,
                "inf_count": inf_count,
            }, None
        min_val = float(np.nanmin(flat))
        max_val = float(np.nanmax(flat))
        mean_val = float(np.nanmean(flat))
        std_val = float(np.nanstd(flat))
        return {
            "count": count,
            "min": min_val,
            "max": max_val,
            "mean": mean_val,
            "std": std_val,
            "nan_count": nan_count,
            "inf_count": inf_count,
        }, None

    min_val = float(np.min(flat))
    max_val = float(np.max(flat))
    mean_val = float(np.mean(flat))
    std_val = float(np.std(flat))
    return {
        "count": count,
        "min": min_val,
        "max": max_val,
        "mean": mean_val,
        "std": std_val,
        "nan_count": 0,
        "inf_count": 0,
    }, None
