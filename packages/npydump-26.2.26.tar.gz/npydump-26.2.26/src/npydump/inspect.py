"""Metadata extraction utilities."""

from __future__ import annotations

from typing import Any, Dict

import numpy as np


def array_meta(arr: np.ndarray) -> Dict[str, Any]:
    order = "C"
    if arr.flags.f_contiguous and not arr.flags.c_contiguous:
        order = "F"
    return {
        "shape": list(arr.shape),
        "dtype": str(arr.dtype),
        "ndim": int(arr.ndim),
        "size": int(arr.size),
        "itemsize": int(arr.itemsize),
        "order": order,
    }
