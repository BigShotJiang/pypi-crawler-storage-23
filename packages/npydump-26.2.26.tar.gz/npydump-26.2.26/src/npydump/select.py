"""Selection helpers for array display."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

import numpy as np


@dataclass
class Selection:
    mode: str  # meta, head, slice, all
    head: Optional[int] = None
    slice_expr: Optional[str] = None


def parse_slice(expr: str) -> Any:
    parts = [p.strip() for p in expr.split(",")]
    slices = []
    for part in parts:
        if part == ":" or part == "":
            slices.append(slice(None))
            continue
        if ":" in part:
            segs = part.split(":")
            start = int(segs[0]) if segs[0] else None
            stop = int(segs[1]) if len(segs) > 1 and segs[1] else None
            step = int(segs[2]) if len(segs) > 2 and segs[2] else None
            slices.append(slice(start, stop, step))
        else:
            slices.append(int(part))
    return tuple(slices)


def select_data(arr: np.ndarray, sel: Selection) -> Optional[np.ndarray]:
    if sel.mode == "meta":
        return None
    if sel.mode == "all":
        return arr
    if sel.mode == "head":
        head = sel.head or 0
        return arr.ravel()[:head]
    if sel.mode == "slice":
        expr = sel.slice_expr or ":"
        idx = parse_slice(expr)
        if not isinstance(idx, tuple):
            idx = (idx,)
        if len(idx) > arr.ndim:
            idx = idx[: arr.ndim]
        return arr[idx]
    return None
