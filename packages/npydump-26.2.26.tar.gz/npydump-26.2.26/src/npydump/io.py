"""File loading helpers."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, Optional, Tuple

import numpy as np


@dataclass
class LoadedFile:
    path: Path
    kind: str  # "npy" or "npz"
    array: Optional[np.ndarray] = None
    arrays: Optional[Dict[str, np.ndarray]] = None


def load_file(path: Path) -> LoadedFile:
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")
    suffix = path.suffix.lower()
    if suffix == ".npy":
        arr = np.load(path, allow_pickle=True)
        return LoadedFile(path=path, kind="npy", array=arr)
    if suffix == ".npz":
        archive = np.load(path, allow_pickle=True)
        arrays = {k: archive[k] for k in archive.files}
        return LoadedFile(path=path, kind="npz", arrays=arrays)
    raise ValueError("Only .npy and .npz files are supported")


def filter_keys(
    arrays: Dict[str, np.ndarray], keys: Optional[Iterable[str]]
) -> Dict[str, np.ndarray]:
    if not keys:
        return arrays
    selected = {}
    for key in keys:
        if key in arrays:
            selected[key] = arrays[key]
    return selected
