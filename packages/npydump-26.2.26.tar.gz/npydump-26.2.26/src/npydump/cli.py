"""Command line interface for npydump."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, Optional

import numpy as np

from npydump.inspect import array_meta
from npydump.io import filter_keys, load_file
from npydump.select import Selection, select_data
from npydump.stats import compute_stats
from npydump.render import csv as render_csv
from npydump.render import json as render_json
from npydump.render import text as render_text
from npydump.render import yaml as render_yaml


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Inspect .npy and .npz files")
    parser.add_argument("path", help="Path to .npy or .npz file")
    parser.add_argument(
        "--format", choices=["text", "json", "yaml", "csv"], default="text"
    )
    parser.add_argument(
        "--out", help="Output path (file or directory, depends on format)"
    )
    parser.add_argument("--keys", help="Comma-separated keys for .npz")
    parser.add_argument(
        "--stat", action="store_true", help="Include statistics summary"
    )
    parser.add_argument("--precision", type=int, help="Floating point precision")
    parser.add_argument(
        "--max-width", type=int, default=120, help="Max line width for text output"
    )

    group = parser.add_mutually_exclusive_group()
    group.add_argument("--meta", action="store_true", help="Show metadata only")
    group.add_argument("--head", type=int, help="Show first N elements (flattened)")
    group.add_argument(
        "--slice", dest="slice_expr", help="Slice expression, e.g. 0:10, :, -1"
    )
    group.add_argument("--all", action="store_true", help="Show all elements")

    return parser


def _selection_from_args(args: argparse.Namespace) -> Selection:
    if args.meta:
        return Selection(mode="meta")
    if args.head is not None:
        return Selection(mode="head", head=args.head)
    if args.slice_expr:
        return Selection(mode="slice", slice_expr=args.slice_expr)
    if args.all:
        return Selection(mode="all")
    return Selection(mode="head", head=100)


def _object_note(arr: np.ndarray, sel: Selection) -> Optional[str]:
    if arr.dtype == object and sel.mode != "meta":
        return "object dtype not fully supported; metadata only"
    return None


def _render_npy(args: argparse.Namespace, arr: np.ndarray, sel: Selection) -> int:
    meta = array_meta(arr)
    note = _object_note(arr, sel)
    data = None
    if note is None:
        data = select_data(arr, sel)
    stats = None
    stats_note = None
    if args.stat:
        stats, stats_note = compute_stats(arr)

    if args.format == "text":
        output = render_text.render_npy(
            meta, data, note, stats, stats_note, args.max_width, args.precision
        )
        if args.out:
            Path(args.out).write_text(output)
        else:
            print(output)
        return 0

    if args.format == "json":
        output = render_json.render_npy(meta, data, note, stats, stats_note)
        if args.out:
            Path(args.out).write_text(output)
        else:
            print(output)
        return 0

    if args.format == "yaml":
        output = render_yaml.render_npy(meta, data, note, stats, stats_note)
        if args.out:
            Path(args.out).write_text(output)
        else:
            print(output)
        return 0

    if args.format == "csv":
        if not args.out:
            raise ValueError("--out is required for csv format")
        out_path = Path(args.out)
        msg = render_csv.write_npy_csv(out_path, data, note)
        if msg:
            print(msg)
        return 0

    return 1


def _render_npz(
    args: argparse.Namespace, arrays: Dict[str, np.ndarray], sel: Selection
) -> int:
    keys = [k.strip() for k in args.keys.split(",")] if args.keys else None
    arrays = filter_keys(arrays, keys)
    meta = {k: array_meta(v) for k, v in arrays.items()}
    notes: Dict[str, Optional[str]] = {}
    data: Dict[str, Optional[np.ndarray]] = {}
    stats: Dict[str, Optional[Dict[str, float]]] = {}
    stats_notes: Dict[str, Optional[str]] = {}

    for key, arr in arrays.items():
        note = _object_note(arr, sel)
        notes[key] = note
        if note is None:
            data[key] = select_data(arr, sel)
        else:
            data[key] = None
        if args.stat:
            stat_val, stat_note = compute_stats(arr)
            stats[key] = stat_val
            stats_notes[key] = stat_note

    if args.format == "text":
        output = render_text.render_npz(
            meta,
            data,
            notes,
            stats if args.stat else None,
            stats_notes if args.stat else None,
            args.max_width,
            args.precision,
        )
        if args.out:
            Path(args.out).write_text(output)
        else:
            print(output)
        return 0

    if args.format == "json":
        output = render_json.render_npz(
            meta,
            data,
            notes,
            stats if args.stat else None,
            stats_notes if args.stat else None,
        )
        if args.out:
            Path(args.out).write_text(output)
        else:
            print(output)
        return 0

    if args.format == "yaml":
        output = render_yaml.render_npz(
            meta,
            data,
            notes,
            stats if args.stat else None,
            stats_notes if args.stat else None,
        )
        if args.out:
            Path(args.out).write_text(output)
        else:
            print(output)
        return 0

    if args.format == "csv":
        if not args.out:
            raise ValueError("--out is required for csv format")
        out_dir = Path(args.out)
        results = render_csv.write_npz_csv(out_dir, data, notes)
        for key, msg in results.items():
            if msg:
                print(f"{key}: {msg}")
        return 0

    return 1


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()
    sel = _selection_from_args(args)
    try:
        loaded = load_file(Path(args.path))
        if loaded.kind == "npy" and loaded.array is not None:
            return _render_npy(args, loaded.array, sel)
        if loaded.kind == "npz" and loaded.arrays is not None:
            return _render_npz(args, loaded.arrays, sel)
    except Exception as exc:
        print(f"error: {exc}")
        return 1
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
