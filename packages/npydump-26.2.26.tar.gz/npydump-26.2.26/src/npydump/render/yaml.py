"""YAML renderer."""

from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np
import yaml


def _to_list(arr: np.ndarray) -> Any:
    return arr.tolist()


def render_npy(
    meta: Dict[str, Any],
    data: Optional[np.ndarray],
    note: Optional[str],
    stats: Optional[Dict[str, Any]],
    stats_note: Optional[str],
) -> str:
    payload: Dict[str, Any] = {"type": "npy", "meta": meta}
    if note:
        payload["note"] = note
    if data is not None:
        payload["data"] = _to_list(data)
    if stats is not None:
        payload["stats"] = stats
    if stats_note:
        payload["stats_note"] = stats_note
    return yaml.safe_dump(payload, sort_keys=False)


def render_npz(
    meta: Dict[str, Any],
    data: Dict[str, Optional[np.ndarray]],
    notes: Dict[str, Optional[str]],
    stats: Optional[Dict[str, Optional[Dict[str, Any]]]],
    stats_notes: Optional[Dict[str, Optional[str]]],
) -> str:
    payload: Dict[str, Any] = {"type": "npz", "keys": list(meta.keys()), "items": {}}
    for key, info in meta.items():
        item: Dict[str, Any] = {"meta": info}
        note = notes.get(key)
        if note:
            item["note"] = note
        arr = data.get(key)
        if arr is not None:
            item["data"] = _to_list(arr)
        if stats is not None:
            st = stats.get(key)
            if st is not None:
                item["stats"] = st
        if stats_notes is not None:
            st_note = stats_notes.get(key)
            if st_note:
                item["stats_note"] = st_note
        payload["items"][key] = item
    return yaml.safe_dump(payload, sort_keys=False)
