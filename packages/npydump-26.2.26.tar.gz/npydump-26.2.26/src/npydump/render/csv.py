"""CSV renderer."""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Dict, Optional

import numpy as np


def write_npy_csv(
    path: Path, data: Optional[np.ndarray], note: Optional[str]
) -> Optional[str]:
    if data is None:
        return note or "no data to export"
    out_path = path
    out_path.parent.mkdir(parents=True, exist_ok=True)
    flat = data.ravel()
    with out_path.open("w", newline="") as f:
        writer = csv.writer(f)
        for val in flat:
            writer.writerow([val])
    return None


def write_npz_csv(
    out_dir: Path,
    data: Dict[str, Optional[np.ndarray]],
    notes: Dict[str, Optional[str]],
) -> Dict[str, Optional[str]]:
    out_dir.mkdir(parents=True, exist_ok=True)
    results: Dict[str, Optional[str]] = {}
    for key, arr in data.items():
        note = notes.get(key)
        if arr is None:
            results[key] = note or "no data to export"
            continue
        out_path = out_dir / f"{key}.csv"
        flat = arr.ravel()
        with out_path.open("w", newline="") as f:
            writer = csv.writer(f)
            for val in flat:
                writer.writerow([val])
        results[key] = None
    return results
