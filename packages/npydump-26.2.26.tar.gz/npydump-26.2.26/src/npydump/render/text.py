"""Text renderer."""

from __future__ import annotations

from typing import Any, Dict, Optional

import numpy as np


def _array_to_text(arr: np.ndarray, max_width: int, precision: Optional[int]) -> str:
    kwargs = {
        "max_line_width": max_width,
        "threshold": arr.size + 1,
    }
    if precision is not None:
        kwargs["precision"] = precision
    return np.array2string(arr, **kwargs)


def render_npy(
    meta: Dict[str, Any],
    data: Optional[np.ndarray],
    note: Optional[str],
    stats: Optional[Dict[str, Any]],
    stats_note: Optional[str],
    max_width: int,
    precision: Optional[int],
) -> str:
    lines = ["type: npy"]
    for key in ("shape", "dtype", "ndim", "size", "itemsize", "order"):
        lines.append(f"{key}: {meta.get(key)}")
    if note:
        lines.append(f"note: {note}")
    if data is not None:
        lines.append("data:")
        lines.append(_array_to_text(data, max_width, precision))
    if stats is not None or stats_note:
        lines.append("stats:")
        if stats is not None:
            for key in ("count", "min", "max", "mean", "std", "nan_count", "inf_count"):
                lines.append(f"{key}: {stats.get(key)}")
        if stats_note:
            lines.append(f"note: {stats_note}")
    return "\n".join(lines)


def render_npz(
    meta: Dict[str, Any],
    data: Dict[str, Optional[np.ndarray]],
    notes: Dict[str, Optional[str]],
    stats: Optional[Dict[str, Optional[Dict[str, Any]]]],
    stats_notes: Optional[Dict[str, Optional[str]]],
    max_width: int,
    precision: Optional[int],
) -> str:
    lines = ["type: npz", f"keys: {list(meta.keys())}"]
    for key, info in meta.items():
        lines.append("")
        lines.append(f"[{key}]")
        for mkey in ("shape", "dtype", "ndim", "size", "itemsize", "order"):
            lines.append(f"{mkey}: {info.get(mkey)}")
        note = notes.get(key)
        if note:
            lines.append(f"note: {note}")
        arr = data.get(key)
        if arr is not None:
            lines.append("data:")
            lines.append(_array_to_text(arr, max_width, precision))
        if stats is not None or stats_notes is not None:
            st = stats.get(key) if stats else None
            st_note = stats_notes.get(key) if stats_notes else None
            if st is not None or st_note:
                lines.append("stats:")
                if st is not None:
                    for skey in (
                        "count",
                        "min",
                        "max",
                        "mean",
                        "std",
                        "nan_count",
                        "inf_count",
                    ):
                        lines.append(f"{skey}: {st.get(skey)}")
                if st_note:
                    lines.append(f"note: {st_note}")
    return "\n".join(lines)
