# npydump

Inspect NumPy `.npy` and `.npz` files from the command line without opening a Python REPL.

## Install

```bash
pip install .
```

## Usage

```bash
npydump data.npy
npydump data.npy --meta
npydump data.npy --head 10
npydump data.npy --slice "0:5, :, -1"
npydump data.npy --all
npydump data.npy --stat

npydump archive.npz --meta
npydump archive.npz --all
npydump archive.npz --keys a,b --head 5

npydump data.npy --format json
npydump data.npy --format yaml
npydump data.npy --format csv --out data.csv
npydump archive.npz --format csv --out out_csv
```

## Notes

- `object` dtype arrays only show metadata. Data is not expanded by design.
- `--stat` computes common statistics over the flattened array.
- CSV export flattens each array to a single column.
- For `.npz`, CSV output creates one file per key in the output directory.
