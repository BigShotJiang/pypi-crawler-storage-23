import polars as pl

PolarsFrame = pl.DataFrame | pl.LazyFrame
