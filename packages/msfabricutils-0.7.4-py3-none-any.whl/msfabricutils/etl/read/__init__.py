from .delta_table import read_delta
from .parquet import read_parquet

__all__ = (
    "read_delta",
    "read_parquet",
)
