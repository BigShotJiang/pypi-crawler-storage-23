import json
import logging

import typer
from typing_extensions import Annotated

from msfabricutils.rest_api import (
    notebook_create,
    notebook_delete,
    notebook_get,
    notebook_get_definition,
    notebook_list,
    notebook_update,
    notebook_update_definition,
)

app = typer.Typer(
    help="[bold]create, get, list, update, delete, and more ... [/bold]",
    rich_markup_mode="rich",
)

@app.command(help="Create a notebook.", rich_help_panel="Notebook")
def create(
    workspace_id: Annotated[str, typer.Option("--workspace-id", rich_help_panel="Arguments", show_default=False, help="The id of the workspace to create the notebook in.")],
    display_name: Annotated[str, typer.Option("--display-name", rich_help_panel="Arguments", show_default=False, help="The display name of the notebook.")],
    notebook_path: Annotated[str, typer.Option("--notebook-path", rich_help_panel="Arguments", show_default=False, help="The path to the notebook to load content from.")],
    description: Annotated[str, typer.Option("--description", rich_help_panel="Arguments", show_default=False, help="The description of the notebook.")] = None,
    await_lro: Annotated[bool, typer.Option("--await-lro", rich_help_panel="Arguments", show_default=True, help="Whether to await the long running operation.")] = False,
    timeout: Annotated[int, typer.Option("--timeout", show_default=True, help="Timeout for the long running operation (seconds)")] = 60 * 5,
    no_preview: Annotated[bool, typer.Option("--no-preview", "--yes", "-y", rich_help_panel="Arguments", show_default=True, help="Preview the command before executing it. You will be asked to confirm the request before it is executed.")] = False,
    quiet: Annotated[bool, typer.Option("--quiet", show_default=True, help="Whether to run in quiet mode. Sets the logging level to WARNING.")] = False,
):
    logger = logging.getLogger()
    if quiet:
        logger.setLevel(logging.WARNING)
    


    response = notebook_create(
        workspace_id=workspace_id,
        display_name=display_name,
        notebook_path=notebook_path,
        description=description,
        await_lro=await_lro,
        timeout=timeout,        
        preview=not no_preview,
    )

    try:
        content = response.json()
    except json.JSONDecodeError:
        content = response.text

    output = {  
        "url": response.url,
        "method": response.request.method,
        "status_code": response.status_code,
        "reason": response.reason,
        "headers": dict(response.headers),
        "content": content,
    }

    typer.echo(json.dumps(output, indent=2))
    return output

@app.command(help="Get a notebook.", rich_help_panel="Notebook")
def get(
    workspace_id: Annotated[str, typer.Option("--workspace-id", rich_help_panel="Arguments", show_default=False, help="The id of the workspace to get the notebook from.")],
    notebook_id: Annotated[str, typer.Option("--notebook-id", rich_help_panel="Arguments", show_default=False, help="The id of the notebook to get.")],
    no_preview: Annotated[bool, typer.Option("--no-preview", "--yes", "-y", rich_help_panel="Arguments", show_default=True, help="Preview the command before executing it. You will be asked to confirm the request before it is executed.")] = False,
    quiet: Annotated[bool, typer.Option("--quiet", show_default=True, help="Whether to run in quiet mode. Sets the logging level to WARNING.")] = False,
):
    logger = logging.getLogger()
    if quiet:
        logger.setLevel(logging.WARNING)
    


    response = notebook_get(
        workspace_id=workspace_id,
        notebook_id=notebook_id,        
        preview=not no_preview,
    )

    try:
        content = response.json()
    except json.JSONDecodeError:
        content = response.text

    output = {  
        "url": response.url,
        "method": response.request.method,
        "status_code": response.status_code,
        "reason": response.reason,
        "headers": dict(response.headers),
        "content": content,
    }

    typer.echo(json.dumps(output, indent=2))
    return output

@app.command(help="List notebooks for a workspace.", rich_help_panel="Notebook")
def list(
    workspace_id: Annotated[str, typer.Option("--workspace-id", rich_help_panel="Arguments", show_default=False, help="The id of the workspace to list notebooks for.")],
    continuation_token: Annotated[str, typer.Option("--continuation-token", rich_help_panel="Arguments", show_default=False, help="A token for retrieving the next page of results.")] = None,
    no_preview: Annotated[bool, typer.Option("--no-preview", "--yes", "-y", rich_help_panel="Arguments", show_default=True, help="Preview the command before executing it. You will be asked to confirm the request before it is executed.")] = False,
    quiet: Annotated[bool, typer.Option("--quiet", show_default=True, help="Whether to run in quiet mode. Sets the logging level to WARNING.")] = False,
):
    logger = logging.getLogger()
    if quiet:
        logger.setLevel(logging.WARNING)
    


    response = notebook_list(
        workspace_id=workspace_id,
        continuation_token=continuation_token,        
        preview=not no_preview,
    )

    try:
        content = response.json()
    except json.JSONDecodeError:
        content = response.text

    output = {  
        "url": response.url,
        "method": response.request.method,
        "status_code": response.status_code,
        "reason": response.reason,
        "headers": dict(response.headers),
        "content": content,
    }

    typer.echo(json.dumps(output, indent=2))
    return output

@app.command(help="Update a notebook.", rich_help_panel="Notebook")
def update(
    workspace_id: Annotated[str, typer.Option("--workspace-id", rich_help_panel="Arguments", show_default=False, help="The id of the workspace to update.")],
    notebook_id: Annotated[str, typer.Option("--notebook-id", rich_help_panel="Arguments", show_default=False, help="The id of the notebook to update.")],
    display_name: Annotated[str, typer.Option("--display-name", rich_help_panel="Arguments", show_default=False, help="The display name of the notebook.")] = None,
    description: Annotated[str, typer.Option("--description", rich_help_panel="Arguments", show_default=False, help="The description of the notebook.")] = None,
    no_preview: Annotated[bool, typer.Option("--no-preview", "--yes", "-y", rich_help_panel="Arguments", show_default=True, help="Preview the command before executing it. You will be asked to confirm the request before it is executed.")] = False,
    quiet: Annotated[bool, typer.Option("--quiet", show_default=True, help="Whether to run in quiet mode. Sets the logging level to WARNING.")] = False,
):
    logger = logging.getLogger()
    if quiet:
        logger.setLevel(logging.WARNING)

    if not any([display_name, description]):
        raise typer.BadParameter("At least one of the following arguments is required: --display-name, --description")
    


    response = notebook_update(
        workspace_id=workspace_id,
        notebook_id=notebook_id,
        display_name=display_name,
        description=description,        
        preview=not no_preview,
    )

    try:
        content = response.json()
    except json.JSONDecodeError:
        content = response.text

    output = {  
        "url": response.url,
        "method": response.request.method,
        "status_code": response.status_code,
        "reason": response.reason,
        "headers": dict(response.headers),
        "content": content,
    }

    typer.echo(json.dumps(output, indent=2))
    return output

@app.command(help="Delete a notebook.", rich_help_panel="Notebook")
def delete(
    workspace_id: Annotated[str, typer.Option("--workspace-id", rich_help_panel="Arguments", show_default=False, help="The id of the workspace to delete.")],
    notebook_id: Annotated[str, typer.Option("--notebook-id", rich_help_panel="Arguments", show_default=False, help="The id of the notebook to delete.")],
    no_preview: Annotated[bool, typer.Option("--no-preview", "--yes", "-y", rich_help_panel="Arguments", show_default=True, help="Preview the command before executing it. You will be asked to confirm the request before it is executed.")] = False,
    quiet: Annotated[bool, typer.Option("--quiet", show_default=True, help="Whether to run in quiet mode. Sets the logging level to WARNING.")] = False,
):
    logger = logging.getLogger()
    if quiet:
        logger.setLevel(logging.WARNING)
    


    response = notebook_delete(
        workspace_id=workspace_id,
        notebook_id=notebook_id,        
        preview=not no_preview,
    )

    try:
        content = response.json()
    except json.JSONDecodeError:
        content = response.text

    output = {  
        "url": response.url,
        "method": response.request.method,
        "status_code": response.status_code,
        "reason": response.reason,
        "headers": dict(response.headers),
        "content": content,
    }

    typer.echo(json.dumps(output, indent=2))
    return output

@app.command(help="Get the definition of a notebook.", rich_help_panel="NotebookDefinition")
def get_definition(
    workspace_id: Annotated[str, typer.Option("--workspace-id", rich_help_panel="Arguments", show_default=False, help="The id of the workspace to get the notebook definition from.")],
    notebook_id: Annotated[str, typer.Option("--notebook-id", rich_help_panel="Arguments", show_default=False, help="The id of the notebook to get the definition from.")],
    format: Annotated[str, typer.Option("--format", rich_help_panel="Arguments", show_default=False, help="The format of the Notebook definition. Supported format is \"ipynb\" and \"fabricGitSource\".")] = None,
    await_lro: Annotated[bool, typer.Option("--await-lro", rich_help_panel="Arguments", show_default=True, help="Whether to await the long running operation.")] = False,
    timeout: Annotated[int, typer.Option("--timeout", show_default=True, help="Timeout for the long running operation (seconds)")] = 60 * 5,
    no_preview: Annotated[bool, typer.Option("--no-preview", "--yes", "-y", rich_help_panel="Arguments", show_default=True, help="Preview the command before executing it. You will be asked to confirm the request before it is executed.")] = False,
    quiet: Annotated[bool, typer.Option("--quiet", show_default=True, help="Whether to run in quiet mode. Sets the logging level to WARNING.")] = False,
):
    logger = logging.getLogger()
    if quiet:
        logger.setLevel(logging.WARNING)
    


    response = notebook_get_definition(
        workspace_id=workspace_id,
        notebook_id=notebook_id,
        format=format,
        await_lro=await_lro,
        timeout=timeout,        
        preview=not no_preview,
    )

    try:
        content = response.json()
    except json.JSONDecodeError:
        content = response.text

    output = {  
        "url": response.url,
        "method": response.request.method,
        "status_code": response.status_code,
        "reason": response.reason,
        "headers": dict(response.headers),
        "content": content,
    }

    typer.echo(json.dumps(output, indent=2))
    return output

@app.command(help="Update the definition of a notebook.", rich_help_panel="NotebookDefinition")
def update_definition(
    workspace_id: Annotated[str, typer.Option("--workspace-id", rich_help_panel="Arguments", show_default=False, help="The id of the workspace to update.")],
    notebook_id: Annotated[str, typer.Option("--notebook-id", rich_help_panel="Arguments", show_default=False, help="The id of the notebook to update.")],
    notebook_path: Annotated[str, typer.Option("--notebook-path", rich_help_panel="Arguments", show_default=False, help="The path to the notebook to load content from.")],
    update_metadata: Annotated[bool, typer.Option("--update-metadata", rich_help_panel="Arguments", show_default=True, help="When set to true, the item's metadata is updated using the metadata in the .platform file.")] = False,
    await_lro: Annotated[bool, typer.Option("--await-lro", rich_help_panel="Arguments", show_default=True, help="Whether to await the long running operation.")] = False,
    timeout: Annotated[int, typer.Option("--timeout", show_default=True, help="Timeout for the long running operation (seconds)")] = 60 * 5,
    no_preview: Annotated[bool, typer.Option("--no-preview", "--yes", "-y", rich_help_panel="Arguments", show_default=True, help="Preview the command before executing it. You will be asked to confirm the request before it is executed.")] = False,
    quiet: Annotated[bool, typer.Option("--quiet", show_default=True, help="Whether to run in quiet mode. Sets the logging level to WARNING.")] = False,
):
    logger = logging.getLogger()
    if quiet:
        logger.setLevel(logging.WARNING)
    


    response = notebook_update_definition(
        workspace_id=workspace_id,
        notebook_id=notebook_id,
        notebook_path=notebook_path,
        update_metadata=update_metadata,
        await_lro=await_lro,
        timeout=timeout,        
        preview=not no_preview,
    )

    try:
        content = response.json()
    except json.JSONDecodeError:
        content = response.text

    output = {  
        "url": response.url,
        "method": response.request.method,
        "status_code": response.status_code,
        "reason": response.reason,
        "headers": dict(response.headers),
        "content": content,
    }

    typer.echo(json.dumps(output, indent=2))
    return output