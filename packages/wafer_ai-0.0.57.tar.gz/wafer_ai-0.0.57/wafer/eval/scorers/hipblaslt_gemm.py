"""hipBLASLt GEMM scorer.

Benchmark-style: evaluates GEMM kernel TFLOPS improvements.
Scores based on relative TFLOPS improvement over baseline.
"""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

from wafer.core.rollouts.dtypes import Metric, Score
from wafer.eval import extract_eval_result


async def _run_benchmark(work_dir: Path) -> str:
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "wafer.eval.bench.hipblaslt",
        cwd=str(work_dir),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, _ = await proc.communicate()
    return extract_eval_result(stdout.decode())


async def score(
    work_dir: Path,
    *,
    baseline_dir: Path | None = None,
) -> Score:
    """Score a hipBLASLt GEMM solution directory."""
    assert work_dir.is_dir(), f"Not a directory: {work_dir}"
    output = await _run_benchmark(work_dir)
    after = json.loads(output)
    assert "correct" in after, f"Missing 'correct' in output: {after}"
    assert "tflops" in after, f"Missing 'tflops' in output: {after}"

    correct_val = 1.0 if after["correct"] else 0.0
    tflops = float(after["tflops"])

    if baseline_dir is not None:
        assert baseline_dir.is_dir(), f"Baseline not a directory: {baseline_dir}"
        baseline_output = await _run_benchmark(baseline_dir)
        before = json.loads(baseline_output)
        assert "tflops" in before, f"Missing 'tflops' in baseline: {before}"
        before_tflops = float(before["tflops"])
        assert before_tflops > 0, "Baseline tflops must be positive"
        speedup = tflops / before_tflops
        improvement = max(0.0, speedup - 1.0) * 10
    else:
        speedup = tflops
        improvement = tflops

    composite = improvement if after["correct"] else 0.0
    return Score(metrics=(
        Metric("correct", correct_val),
        Metric("tflops", tflops),
        Metric("speedup", speedup),
        Metric("score", composite, weight=1.0),
    ))
