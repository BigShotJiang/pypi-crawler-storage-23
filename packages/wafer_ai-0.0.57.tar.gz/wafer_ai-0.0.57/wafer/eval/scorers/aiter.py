"""Aiter operator scorer.

Evaluates aiter operator optimizations on AMD MI300X.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

from wafer.core.rollouts.dtypes import Metric, Score


async def score(
    work_dir: Path,
    *,
    baseline_dir: Path | None = None,
) -> Score:
    """Score an aiter operator optimization."""
    assert work_dir.is_dir(), f"Not a directory: {work_dir}"

    args_file = work_dir / ".eval_args"
    assert args_file.exists(), (
        "aiter scorer requires .eval_args file with the command to run "
        "(one arg per line, first line after work_dir)"
    )
    cmd_args = args_file.read_text().strip().splitlines()
    assert cmd_args, ".eval_args file is empty"

    proc = await asyncio.create_subprocess_exec(
        *cmd_args,
        cwd=str(work_dir),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, _ = await proc.communicate()
    after = json.loads(stdout.decode())
    assert "correct" in after, f"Missing 'correct' in output: {after}"
    assert "passed_tests" in after, f"Missing 'passed_tests' in output: {after}"
    assert "total_tests" in after, f"Missing 'total_tests' in output: {after}"

    correct_val = 1.0 if after["correct"] else 0.0
    passed = int(after["passed_tests"])
    total = int(after["total_tests"])
    assert total > 0, "total_tests must be positive"
    pass_rate = passed / total

    composite = correct_val + (pass_rate if after["correct"] else 0.0)
    return Score(metrics=(
        Metric("correct", correct_val),
        Metric("passed_tests", float(passed)),
        Metric("total_tests", float(total)),
        Metric("pass_rate", pass_rate),
        Metric("score", composite, weight=1.0),
    ))
