from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

from wafer.core.rollouts.dtypes import Metric, Score
from wafer.eval import extract_eval_result


async def _run_benchmark(work_dir: Path) -> str:
    proc = await asyncio.create_subprocess_exec(
        sys.executable,
        "-m",
        "megakernel_bench.bench",
        "--work-dir",
        str(work_dir),
        cwd=str(work_dir),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, _ = await proc.communicate()
    return extract_eval_result(stdout.decode())


async def score(
    work_dir: Path,
    *,
    baseline_dir: Path | None = None,
) -> Score:
    """Score a megakernel submission via subprocess isolation."""
    assert work_dir.is_dir(), f"Not a directory: {work_dir}"
    output = await _run_benchmark(work_dir)
    after = json.loads(output)

    fused = 1.0 if after.get("fusion") else 0.0
    correct = 1.0 if after.get("correct") else 0.0
    stages_passed = float(after.get("stages_passed", 0))
    speedup = float(after.get("geomean_speedup", 0.0))

    gates_pass = stages_passed >= 2
    composite = (1.0 + speedup) if gates_pass else 0.0

    return Score(
        metrics=(
            Metric("fusion", fused),
            Metric("correct", correct),
            Metric("stages_passed", stages_passed),
            Metric("geomean_speedup", speedup),
            Metric("score", composite, weight=1.0),
        )
    )
