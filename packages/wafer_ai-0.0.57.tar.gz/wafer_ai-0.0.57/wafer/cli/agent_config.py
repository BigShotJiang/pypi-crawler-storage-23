"""Unified agent configuration.

Single frozen dataclass for everything that affects how the agent behaves.
Loaded from TOML, overridden by CLI flags, versioned alongside experiment results.

Usage:
    config = load_agent_config(Path("experiments/kernelbench_v1.toml"))
    config = config.with_overrides({"model": "anthropic/claude-opus-4-6"})
    config = config.interpolate_prompt({"backend": "cuda"})
    prompt = config.build_full_prompt(working_dir=Path.cwd(), targets=[...])
"""
from __future__ import annotations

import string
from dataclasses import dataclass, field, fields as dc_fields, replace
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class ContextConfig:
    """Controls what runtime context is injected into the system prompt."""
    targets: bool = True
    sandboxes: bool = True
    working_dir: bool = True


@dataclass(frozen=True)
class ContextManagementConfig:
    """Controls how the agent manages conversation context (token pruning)."""
    thinking_turns_keep: int = 2
    tool_uses_trigger_tokens: int = 100_000
    tool_uses_keep: int = 5
    tool_uses_clear_at_least_tokens: int = 10_000
    compact_trigger_tokens: int = 150_000
    pause_after_compaction: bool = True


@dataclass(frozen=True)
class AgentConfig:
    """Unified agent configuration -- identity, behavior, and infrastructure.

    All fields have defaults. Override precedence is handled by callers:
        CLI flag > user config TOML > template TOML > defaults
    Each override step uses with_overrides() to layer on top.
    """

    # Identity
    name: str = "default"
    description: str = ""
    # Prompt (supports $variable interpolation)
    system_prompt: str = ""
    user_prompt_template: str = ""
    # Tools
    tools: list[str] = field(default_factory=lambda: ["read", "glob", "grep", "bash"])
    bash_allowlist: list[str] | None = None
    bash_denylist: list[str] | None = None
    confirm_tools: list[str] | None = None
    # Model
    model: str = "anthropic/claude-sonnet-4-5-20250929"
    provider: str | None = None
    temperature: float | None = None
    max_tokens: int = 8192
    max_completion_tokens: int | None = None
    reasoning_effort: str | None = None
    # Thinking
    thinking_enabled: bool = False
    thinking_budget_tokens: int = 10000
    # Execution
    single_turn: bool = False
    max_turns: int | None = None
    timeout_sec: float | None = None
    # Template
    defaults: dict[str, str] = field(default_factory=dict)
    include_skills: bool = False
    cloud_only: bool = False
    # Infrastructure
    agent: str | None = None
    target_name: str | None = None
    workspace: str | None = None
    volumes: dict[str, str] = field(default_factory=dict)
    # Context injection
    context: ContextConfig = field(default_factory=ContextConfig)
    context_management: ContextManagementConfig = field(default_factory=ContextManagementConfig)

    def with_overrides(self, d: dict[str, Any]) -> AgentConfig:
        """Apply overrides from a dict. Keys not present or with None values are skipped."""
        assert isinstance(d, dict), f"Expected dict, got {type(d)}"
        valid_names = {f.name for f in dc_fields(self)}
        filtered = {}
        for k, v in d.items():
            if v is not None and k in valid_names:
                filtered[k] = v
        return replace(self, **filtered) if filtered else self

    def interpolate_prompt(self, args: dict[str, str] | None = None) -> AgentConfig:
        """Return new config with $variables replaced in system_prompt."""
        params = dict(self.defaults)
        if args:
            params.update(args)
        template = string.Template(self.system_prompt)
        required_vars = _extract_template_vars(template)
        missing = [v for v in required_vars if v not in params]
        if missing:
            raise ValueError(
                f"Template '{self.name}' requires variables: {', '.join(missing)}. "
                f"Provide them with --args {missing[0]}=value"
            )
        interpolated = template.safe_substitute(**params)
        return replace(self, system_prompt=interpolated)

    def build_full_prompt(
        self,
        *,
        has_local_gpu: bool = False,
        target_flag: str = "",
        working_dir: Path | None = None,
        targets: list[str] | None = None,
        default_target: str | None = None,
        sandboxes: list[str] | None = None,
        include_skills: bool | None = None,
        project_context: list[tuple[str, str]] | None = None,
    ) -> str:
        """Build the complete system prompt with all runtime context."""
        parts = [self.system_prompt]

        if has_local_gpu:
            parts.append("\n\n## Environment\nYou have direct GPU access in this environment.")
        elif target_flag:
            parts.append(
                f"\n\n## Environment\nUse `{target_flag}` to route commands to GPU hardware."
            )

        if self.user_prompt_template:
            parts.append(f"\n\n{self.user_prompt_template}")

        if working_dir is not None:
            parts.append(
                f"\n\n## Working directory\n"
                f"Your working directory is `{working_dir.resolve()}`. "
                f"Use relative paths (e.g. `./flashinfer`, `flashinfer`) "
                f"for file operations - never assume paths like /home/user."
            )

        if targets:
            parts.append("\n\n## Available targets\n" + "\n".join(targets))
            if default_target:
                parts.append(f"\nDefault target: `{default_target}`")

        if sandboxes:
            parts.append("\n\n## Active sandboxes\n" + "\n".join(sandboxes))

        resolve_skills = include_skills if include_skills is not None else self.include_skills
        if resolve_skills:
            from wafer.core.rollouts.skills import discover_skills, format_skill_metadata_for_prompt
            skill_metadata = [s for s in discover_skills() if not s.disable_model_invocation]
            if skill_metadata:
                parts.append("\n\n" + format_skill_metadata_for_prompt(skill_metadata))

        if project_context:
            for label, content in project_context:
                parts.append(f"\n\n## {label}\n{content}")

        return "\n".join(parts)

    def get_variables(self) -> list[str]:
        """Get list of $variable names used in the system prompt."""
        template = string.Template(self.system_prompt)
        return _extract_template_vars(template)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict for JSON wire format. Skips None/empty values."""
        d: dict[str, Any] = {}
        _SIMPLE_FIELDS = (
            "model", "provider", "temperature", "max_tokens",
            "max_turns", "single_turn",
            "system_prompt", "user_prompt_template",
            "tools", "bash_allowlist", "bash_denylist", "confirm_tools",
            "thinking_enabled", "thinking_budget_tokens",
            "reasoning_effort", "max_completion_tokens",
            "workspace",
            "agent", "target_name", "timeout_sec", "defaults",
            "description", "cloud_only",
        )
        for key in _SIMPLE_FIELDS:
            val = getattr(self, key)
            if val is not None and val != "" and val != {} and val != []:
                d[key] = val
        if self.volumes:
            d["volumes"] = dict(self.volumes)
        ctx = self.context
        if ctx != ContextConfig():
            d["context"] = {
                "targets": ctx.targets,
                "sandboxes": ctx.sandboxes,
                "working_dir": ctx.working_dir,
            }
        cm = self.context_management
        if cm != ContextManagementConfig():
            d["context_management"] = {
                "thinking_turns_keep": cm.thinking_turns_keep,
                "tool_uses_trigger_tokens": cm.tool_uses_trigger_tokens,
                "tool_uses_keep": cm.tool_uses_keep,
                "tool_uses_clear_at_least_tokens": cm.tool_uses_clear_at_least_tokens,
                "compact_trigger_tokens": cm.compact_trigger_tokens,
                "pause_after_compaction": cm.pause_after_compaction,
            }
        return d

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> AgentConfig:
        """Deserialize from dict (JSON wire format)."""
        assert isinstance(d, dict), f"Expected dict, got {type(d)}"
        ctx_raw = d.get("context", {})
        context = ContextConfig(
            targets=ctx_raw.get("targets", True),
            sandboxes=ctx_raw.get("sandboxes", True),
            working_dir=ctx_raw.get("working_dir", True),
        ) if ctx_raw else ContextConfig()
        cm_raw = d.get("context_management", {})
        context_management = ContextManagementConfig(**cm_raw) if cm_raw else ContextManagementConfig()
        base = cls(context=context, context_management=context_management)
        skip = {"context", "context_management"}
        overrides = {k: v for k, v in d.items() if k not in skip}
        return base.with_overrides(overrides)

    def to_toml_string(self) -> str:
        """Serialize to TOML string for writing temp config files."""
        d = self.to_dict()
        context = d.pop("context", None)
        context_management = d.pop("context_management", None)
        volumes = d.pop("volumes", {})
        return _dict_to_toml_string(d, context=context,
                                     context_management=context_management, volumes=volumes)




def _extract_template_vars(template: string.Template) -> list[str]:
    """Extract variable names from a string.Template."""
    return [
        match.group("named") or match.group("braced")
        for match in template.pattern.finditer(template.template)
        if match.group("named") or match.group("braced")
    ]


def _dict_to_toml_string(
    d: dict[str, Any],
    *,
    context: dict[str, Any] | None = None,
    context_management: dict[str, Any] | None = None,
    volumes: dict[str, str] | None = None,
) -> str:
    """Convert a flat config dict to a TOML string."""
    lines: list[str] = []
    nested_sections: dict[str, dict[str, Any]] = {}

    for key, value in d.items():
        if value is None:
            continue
        if key == "thinking_enabled":
            nested_sections.setdefault("thinking", {})["enabled"] = value
        elif key == "thinking_budget_tokens":
            nested_sections.setdefault("thinking", {})["budget_tokens"] = value
        elif key == "bash_allowlist":
            nested_sections.setdefault("bash", {})["allowlist"] = value
        elif key == "bash_denylist":
            nested_sections.setdefault("bash", {})["denylist"] = value
        elif key == "reasoning_effort":
            nested_sections.setdefault("reasoning", {})["effort"] = value
        elif key == "max_completion_tokens":
            nested_sections.setdefault("reasoning", {})["max_tokens"] = value
        elif key == "defaults" and isinstance(value, dict):
            nested_sections["defaults"] = value
        elif isinstance(value, str) and "\n" in value:
            lines.append(f'{key} = """\n{value}"""')
        elif isinstance(value, str):
            lines.append(f'{key} = "{value}"')
        elif isinstance(value, bool):
            lines.append(f"{key} = {'true' if value else 'false'}")
        elif isinstance(value, (int, float)):
            lines.append(f"{key} = {value}")
        elif isinstance(value, list):
            items = ", ".join(f'"{v}"' for v in value)
            lines.append(f"{key} = [{items}]")

    for section_name, section_vals in nested_sections.items():
        lines.append(f"\n[{section_name}]")
        for k, v in section_vals.items():
            if isinstance(v, bool):
                lines.append(f"{k} = {'true' if v else 'false'}")
            elif isinstance(v, (int, float)):
                lines.append(f"{k} = {v}")
            elif isinstance(v, str):
                lines.append(f'{k} = "{v}"')
            elif isinstance(v, list):
                items = ", ".join(f'"{i}"' for i in v)
                lines.append(f"{k} = [{items}]")

    if volumes:
        lines.append("\n[volumes]")
        for k, v in volumes.items():
            lines.append(f'{k} = "{v}"')

    if context:
        lines.append("\n[context]")
        for k, v in context.items():
            if isinstance(v, bool):
                lines.append(f"{k} = {'true' if v else 'false'}")

    if context_management:
        lines.append("\n[context_management]")
        for k, v in context_management.items():
            if isinstance(v, bool):
                lines.append(f"{k} = {'true' if v else 'false'}")
            elif isinstance(v, (int, float)):
                lines.append(f"{k} = {v}")

    return "\n".join(lines) + "\n"


def load_agent_config(path: Path) -> AgentConfig:
    """Load agent config from a TOML file."""
    import tomllib

    assert path.exists(), f"Config file not found: {path}"
    assert path.suffix == ".toml", f"Config file must be .toml, got: {path.suffix}"

    with open(path, "rb") as f:
        raw = tomllib.load(f)

    thinking = raw.pop("thinking", {})
    bash = raw.pop("bash", {})
    reasoning = raw.pop("reasoning", {})
    defaults = raw.pop("defaults", {})
    raw_volumes = raw.pop("volumes", {})
    raw_context = raw.pop("context", {})
    raw_ctx_mgmt = raw.pop("context_management", {})

    _validate_no_unknown_keys(raw, thinking, bash, reasoning, defaults, raw_context, raw_ctx_mgmt)

    agent = raw.get("agent")
    if agent is not None:
        assert agent in _VALID_TOP_LEVEL_AGENTS, (
            f"agent must be one of {_VALID_TOP_LEVEL_AGENTS}. Got: {agent!r}"
        )

    defaults_dict: dict[str, str] = {}
    if defaults:
        defaults_dict = {k: str(v) for k, v in defaults.items()}

    context = ContextConfig(
        targets=raw_context.get("targets", True),
        sandboxes=raw_context.get("sandboxes", True),
        working_dir=raw_context.get("working_dir", True),
    )
    context_management = ContextManagementConfig(
        thinking_turns_keep=raw_ctx_mgmt.get("thinking_turns_keep", 2),
        tool_uses_trigger_tokens=raw_ctx_mgmt.get("tool_uses_trigger_tokens", 100_000),
        tool_uses_keep=raw_ctx_mgmt.get("tool_uses_keep", 5),
        tool_uses_clear_at_least_tokens=raw_ctx_mgmt.get("tool_uses_clear_at_least_tokens", 10_000),
        compact_trigger_tokens=raw_ctx_mgmt.get("compact_trigger_tokens", 150_000),
        pause_after_compaction=raw_ctx_mgmt.get("pause_after_compaction", True),
    )

    display_name = path.stem.replace("_", "-")

    return AgentConfig(
        name=display_name,
        model=raw.get("model", AgentConfig.model),
        provider=raw.get("provider"),
        temperature=raw.get("temperature"),
        max_tokens=raw.get("max_tokens", AgentConfig.max_tokens),
        max_turns=raw.get("max_turns"),
        single_turn=raw.get("single_turn", AgentConfig.single_turn),
        system_prompt=raw.get("system_prompt", ""),
        user_prompt_template=raw.get("user_prompt_template", ""),
        tools=raw.get("tools") or ["read", "glob", "grep", "bash"],
        bash_allowlist=bash.get("allowlist") or raw.get("bash_allowlist"),
        bash_denylist=bash.get("denylist"),
        confirm_tools=raw.get("confirm_tools"),
        thinking_enabled=thinking.get("enabled", raw.get("thinking_enabled", False)),
        thinking_budget_tokens=thinking.get("budget_tokens", AgentConfig.thinking_budget_tokens),
        reasoning_effort=reasoning.get("effort") or raw.get("reasoning_effort"),
        max_completion_tokens=reasoning.get("max_tokens") or raw.get("max_completion_tokens"),
        workspace=raw.get("workspace"),
        agent=agent,
        target_name=raw.get("target_name"),
        timeout_sec=raw.get("timeout_sec"),
        cloud_only=raw.get("cloud_only", False),
        volumes={k: str(v) for k, v in raw_volumes.items()} if raw_volumes else {},
        context=context,
        context_management=context_management,
        defaults=defaults_dict,
        description=raw.get("description", ""),
    )


_KNOWN_TOP_LEVEL_KEYS = frozenset({
    "model", "provider", "temperature", "max_tokens",
    "max_turns", "single_turn",
    "system_prompt", "user_prompt_template",
    "tools", "bash_allowlist", "confirm_tools",
    "thinking_enabled", "thinking_budget_tokens",
    "reasoning_effort", "max_completion_tokens",
    "workspace",
    "agent", "target_name", "timeout_sec", "defaults",
    "description", "cloud_only",
})
_KNOWN_CONTEXT_KEYS = frozenset({"targets", "sandboxes", "working_dir"})

_VALID_TOP_LEVEL_AGENTS = ("wafer", "claude", "codex")

_KNOWN_THINKING_KEYS = frozenset({"enabled", "budget_tokens"})
_KNOWN_BASH_KEYS = frozenset({"allowlist", "denylist"})
_KNOWN_REASONING_KEYS = frozenset({"effort", "max_tokens"})


_BUNDLED_TOML_DIR = Path(__file__).parent / "templates" / "toml"


def get_bundled_template_path(name: str) -> Path | None:
    """Resolve a template name to its bundled TOML path, or None if not found."""
    module_name = name.replace("-", "_")
    toml_path = _BUNDLED_TOML_DIR / f"{module_name}.toml"
    if toml_path.exists():
        return toml_path
    toml_path = _BUNDLED_TOML_DIR / f"{name}.toml"
    if toml_path.exists():
        return toml_path
    return None


def list_bundled_templates() -> list[str]:
    """List available bundled TOML template names."""
    if not _BUNDLED_TOML_DIR.exists():
        return []
    return sorted(
        f.stem.replace("_", "-")
        for f in _BUNDLED_TOML_DIR.glob("*.toml")
    )


_KNOWN_CTX_MGMT_KEYS = frozenset({
    "thinking_turns_keep", "tool_uses_trigger_tokens", "tool_uses_keep",
    "tool_uses_clear_at_least_tokens", "compact_trigger_tokens", "pause_after_compaction",
})


def _validate_no_unknown_keys(
    raw: dict[str, Any],
    thinking: dict[str, Any],
    bash: dict[str, Any],
    reasoning: dict[str, Any],
    defaults: dict[str, Any],
    context: dict[str, Any] | None = None,
    context_management: dict[str, Any] | None = None,
) -> None:
    """Fail fast on unknown keys to catch typos."""
    unknown_top = set(raw.keys()) - _KNOWN_TOP_LEVEL_KEYS
    assert not unknown_top, f"Unknown keys in agent config: {unknown_top}"

    unknown_thinking = set(thinking.keys()) - _KNOWN_THINKING_KEYS
    assert not unknown_thinking, f"Unknown keys in [thinking]: {unknown_thinking}"

    unknown_bash = set(bash.keys()) - _KNOWN_BASH_KEYS
    assert not unknown_bash, f"Unknown keys in [bash]: {unknown_bash}"

    unknown_reasoning = set(reasoning.keys()) - _KNOWN_REASONING_KEYS
    assert not unknown_reasoning, f"Unknown keys in [reasoning]: {unknown_reasoning}"

    if context:
        unknown_context = set(context.keys()) - _KNOWN_CONTEXT_KEYS
        assert not unknown_context, f"Unknown keys in [context]: {unknown_context}"

    if context_management:
        unknown_ctx_mgmt = set(context_management.keys()) - _KNOWN_CTX_MGMT_KEYS
        assert not unknown_ctx_mgmt, f"Unknown keys in [context_management]: {unknown_ctx_mgmt}"
