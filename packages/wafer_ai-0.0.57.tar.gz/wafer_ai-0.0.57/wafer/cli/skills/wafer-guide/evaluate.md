# Kernel Evaluation

Test correctness and measure speedup against a reference using the unified eval primitive:

```bash
# List available evaluation tasks
wafer tool eval --list-tasks

# Run evaluation for a specific task
wafer tool eval --task gpumode
wafer tool eval --task kernelbench

# Push files to sandbox, then run commands (no repeated sync)
wafer sandbox push ./my-kernel
wafer sandbox run --target my-gpu -- wafer tool eval --task kernelbench

# Push single file after editing
wafer sandbox push ./my-kernel/kernel.cu

# Alternative: sync + run in one shot (--sync auto-sets working dir to /tmp/<dirname>/)
wafer sandbox run --target my-gpu --sync ./my-kernel -- wafer tool eval --task kernelbench
```

## SSH Target + Evaluate Integration

Run eval on an SSH target by pushing files then running eval:

```bash
# Step 1: Register SSH target
wafer target init ssh --name my-gpu --host user@host:22

# Step 2: Push files to sandbox
wafer sandbox push ./my-kernel

# Step 3: Run eval on the SSH target
wafer sandbox run --target my-gpu -- wafer tool eval --task gpumode

# After editing a single file, push just that file
wafer sandbox push ./my-kernel/kernel.cu
wafer sandbox run --target my-gpu -- wafer tool eval --task kernelbench
```

**Alternative (one-shot):** Use `--sync` to push + run in one command:

```bash
wafer sandbox run --target my-gpu --sync ./my-kernel -- python run_benchmark.py
```

## GPUMode Function Signatures

The GPUMode format requires these specific function names:
- `custom_kernel()` — your optimized kernel implementation
- `ref_kernel()` — reference implementation (in reference.py)
- `generate_input()` — input generator (in reference.py)

## Target Configuration

Targets define GPU access methods. Initialize with:

```bash
wafer target init ssh                # Your own GPU via SSH
wafer target init workspace          # Cloud GPU workspace
```

Then use: `wafer sandbox run --target <name> -- wafer tool eval --task gpumode` (SSH targets only; workspaces use `wafer target sync` + `wafer target ssh`)
