# Remote Execution (Workspaces)

Run on cloud GPU workspaces:

```bash
# Create a workspace with a specific GPU and environment type
wafer target init workspace my-workspace -g B200 -e baremetal

# List targets (shows SSH connection info: host, port)
wafer target list

# Sync local files to workspace (files land at /workspace/ on remote, NOT /workspace/<name>/)
wafer target sync my-workspace ./local-dir

# SSH into workspace (interactive) — sandbox does NOT support workspaces
wafer target ssh my-workspace
```

**Important: Synced files land at `/workspace/` directly** — not at `/workspace/<workspace-name>/`. For example, if you sync a directory containing `kernel.py`, it will be at `/workspace/kernel.py` on the remote machine.

**Sandbox is SSH-only.** For workspaces, use `wafer target sync` and `wafer target ssh`. For SSH targets (wafer target init ssh), use `wafer sandbox run`.
