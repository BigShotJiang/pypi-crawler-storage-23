"""CLI authentication and credential management.
Handles storing/loading credentials from ~/.wafer/credentials.json
and verifying tokens against the wafer-api.
Supports automatic token refresh using Supabase refresh tokens.
Token validity is checked locally via JWT exp claim — no network
round-trip on the hot path.
"""
from __future__ import annotations

import base64
import json
import logging
import os
import time
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)


def _safe_symbol(unicode_sym: str, ascii_fallback: str) -> str:
    """Return unicode symbol if terminal supports it, otherwise ASCII fallback.
    Respects NO_COLOR (https://no-color.org/) - any value disables symbols.
    """
    import os as _os
    import sys as _sys

    if _os.environ.get("NO_COLOR") is not None:
        return ascii_fallback
    if not _sys.stdout.isatty():
        return ascii_fallback
    try:
        encoding = _sys.stdout.encoding or "ascii"
        unicode_sym.encode(encoding)
        return unicode_sym
    except (UnicodeEncodeError, LookupError):
        return ascii_fallback


# Safe symbols for terminal output
CHECK = "[ok]"
CROSS = "[fail]"
CREDENTIALS_DIR = Path.home() / ".wafer"
CREDENTIALS_FILE = CREDENTIALS_DIR / "credentials.json"


@dataclass
class Credentials:
    """Stored credentials."""
    access_token: str
    refresh_token: str | None = None
    email: str | None = None
    provider_token: str | None = None  # GitHub OAuth token from Supabase


@dataclass
class UserInfo:
    """User info from token verification."""
    user_id: str
    email: str | None


# Tokens within this many seconds of expiry are treated as expired,
# giving enough margin for the real API call to complete.
_EXPIRY_MARGIN_SECONDS = 30


def _token_expired(token: str) -> bool:
    """Check if a token has expired.

    Service tokens (wfr_cloud_*) encode expiry as the second underscore-
    delimited field.  JWTs are decoded via the base64 payload.  Returns
    True if the token is expired or unparseable (fail closed).
    """
    if token.startswith("wfr_cloud_"):
        parts = token.split("_")
        try:
            exp = int(parts[3])
            remaining = exp - time.time()
            if remaining <= _EXPIRY_MARGIN_SECONDS:
                logger.debug("service token expired (%.0fs past expiry)", -remaining)
                return True
            logger.debug("service token valid (%.0fs remaining)", remaining)
            return False
        except (IndexError, ValueError) as exc:
            logger.warning("could not parse service token expiry: %s", exc)
            return True
    try:
        payload_b64 = token.split(".")[1]
        padded = payload_b64 + "=" * (-len(payload_b64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded))
        exp = payload["exp"]
        remaining = exp - time.time()
        if remaining <= _EXPIRY_MARGIN_SECONDS:
            logger.debug("token expired (%.0fs past expiry)", -remaining)
            return True
        logger.debug("token valid (%.0fs remaining)", remaining)
        return False
    except Exception as exc:
        logger.warning("could not decode token exp claim: %s", exc)
        return True


def save_credentials(
    access_token: str,
    refresh_token: str | None = None,
    email: str | None = None,
    provider_token: str | None = None,
) -> None:
    """Save credentials to ~/.wafer/credentials.json.

    Merges with existing credentials so that fields not explicitly passed
    (e.g. provider_token during a token refresh) are preserved.
    """
    CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
    # Load existing data to preserve fields not being updated
    existing: dict = {}
    if CREDENTIALS_FILE.exists():
        try:
            existing = json.loads(CREDENTIALS_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            pass
    existing["access_token"] = access_token
    if refresh_token is not None:
        existing["refresh_token"] = refresh_token
    if email is not None:
        existing["email"] = email
    if provider_token is not None:
        existing["provider_token"] = provider_token
    fd = os.open(str(CREDENTIALS_FILE), os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(existing, f, indent=2)


def load_credentials() -> Credentials | None:
    """Load credentials from ~/.wafer/credentials.json.
    Returns None if file doesn't exist or is invalid.
    """
    if not CREDENTIALS_FILE.exists():
        return None
    try:
        data = json.loads(CREDENTIALS_FILE.read_text())
        return Credentials(
            access_token=data["access_token"],
            refresh_token=data.get("refresh_token"),
            email=data.get("email"),
            provider_token=data.get("provider_token"),
        )
    except (json.JSONDecodeError, KeyError):
        return None


def clear_credentials() -> bool:
    """Remove credentials file.
    Returns True if file was removed, False if it didn't exist.
    """
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()
        return True
    return False


def get_auth_headers() -> dict[str, str]:
    """Get Authorization headers with a valid token.
    Automatically refreshes expired tokens if a refresh token is available.
    Returns empty dict if not logged in or refresh fails.
    """
    token = get_valid_token()
    if token:
        return {"Authorization": f"Bearer {token}"}
    return {}


def verify_token(token: str) -> UserInfo:
    """Verify token with wafer-api and return user info.
    Raises:
        httpx.HTTPStatusError: If token is invalid (401) or other HTTP error
        httpx.RequestError: If API is unreachable
    """
    import httpx

    from .global_config import get_api_url

    api_url = get_api_url()
    with httpx.Client(timeout=10.0) as client:
        response = client.post(
            f"{api_url}/v1/auth/verify",
            json={"token": token},
        )
        if not response.is_success:
            if response.status_code == 401:
                raise RuntimeError("Token is invalid or expired. Run: wafer login")
            raise RuntimeError(f"Token verification failed ({response.status_code})")
        data = response.json()
        return UserInfo(
            user_id=data["user_id"],
            email=data.get("email"),
        )


def refresh_access_token(refresh_token: str) -> tuple[str, str]:
    """Use refresh token to get a new access token from Supabase.
    Args:
        refresh_token: The refresh token from previous auth
    Returns:
        Tuple of (new_access_token, new_refresh_token)
    Raises:
        httpx.HTTPStatusError: If refresh fails (e.g., refresh token expired)
        httpx.RequestError: If Supabase is unreachable
    """
    import httpx

    from .global_config import get_supabase_anon_key, get_supabase_url

    supabase_url = get_supabase_url()
    anon_key = get_supabase_anon_key()
    with httpx.Client(timeout=10.0) as client:
        response = client.post(
            f"{supabase_url}/auth/v1/token?grant_type=refresh_token",
            json={"refresh_token": refresh_token},
            headers={
                "Content-Type": "application/json",
                "apikey": anon_key,
            },
        )
        if not response.is_success:
            raise RuntimeError(
                f"Token refresh failed ({response.status_code}). Run: wafer login"
            )
        data = response.json()
        return data["access_token"], data["refresh_token"]


def get_valid_token() -> str | None:
    """Get a valid access token, refreshing if necessary.
    Checks WAFER_AUTH_TOKEN env var first (used in Modal sandboxes and local
    agent sessions). If the env token is expired, falls through to the
    credentials file path so the refresh token can be used.
    Returns:
        Valid access token, or None if not logged in or refresh failed
    """
    env_token = os.environ.get("WAFER_AUTH_TOKEN")
    if env_token and not _token_expired(env_token):
        return env_token

    creds = load_credentials()
    if not creds:
        logger.debug("no credentials file found")
        return None
    if not _token_expired(creds.access_token):
        return creds.access_token
    if not creds.refresh_token:
        logger.warning("token expired and no refresh token available")
        return None
    try:
        new_access, new_refresh = refresh_access_token(creds.refresh_token)
        save_credentials(new_access, new_refresh, creds.email)
        if env_token:
            os.environ["WAFER_AUTH_TOKEN"] = new_access
        logger.debug("token refreshed successfully")
        return new_access
    except Exception as e:
        logger.warning("token refresh failed: %s", e)
        return None


def _find_free_port() -> int:
    """Find a free port for the callback server."""
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("", 0))
        return s.getsockname()[1]


def _get_oauth_handler_class():
    """Build OAuthCallbackHandler lazily to avoid importing http.server at module level."""
    from http.server import BaseHTTPRequestHandler
    from urllib.parse import parse_qs, urlparse

    class OAuthCallbackHandler(BaseHTTPRequestHandler):
        """HTTP handler that catches the OAuth callback with access token."""
        access_token: str | None = None
        refresh_token: str | None = None
        provider_token: str | None = None
        error: str | None = None

        def log_message(self, format: str, *args: object) -> None:  # noqa: A002
            pass

        def do_GET(self) -> None:
            """Handle GET request - catch the callback or serve the HTML page."""
            parsed = urlparse(self.path)
            if parsed.path == "/callback":
                html = """<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Wafer CLI Login</title></head>
<body>
<h2>Completing login...</h2>
<script>
const hash = window.location.hash.substring(1);
const params = new URLSearchParams(hash);
const accessToken = params.get('access_token');
const refreshToken = params.get('refresh_token');
const providerToken = params.get('provider_token');
const error = params.get('error_description') || params.get('error');
if (accessToken) {
    let url = '/token?access_token=' + encodeURIComponent(accessToken);
    if (refreshToken) url += '&refresh_token=' + encodeURIComponent(refreshToken);
    if (providerToken) url += '&provider_token=' + encodeURIComponent(providerToken);
    fetch(url).then(() => {
        document.body.innerHTML = '<h2>Login successful!</h2><p>You can close this window.</p>';
    });
} else if (error) {
    fetch('/token?error=' + encodeURIComponent(error));
    document.body.innerHTML = '<h2>Login failed</h2><p>' + error + '</p>';
} else {
    document.body.innerHTML = '<h2>No token received</h2>';
}
</script>
</body>
</html>"""
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(html.encode())
            elif parsed.path == "/token":
                params = parse_qs(parsed.query)
                if "access_token" in params:
                    OAuthCallbackHandler.access_token = params["access_token"][0]
                    if "refresh_token" in params:
                        OAuthCallbackHandler.refresh_token = params["refresh_token"][0]
                    if "provider_token" in params:
                        OAuthCallbackHandler.provider_token = params["provider_token"][0]
                elif "error" in params:
                    OAuthCallbackHandler.error = params["error"][0]
                self.send_response(200)
                self.send_header("Content-Type", "text/plain")
                self.end_headers()
                self.wfile.write(b"OK")
            else:
                self.send_response(404)
                self.end_headers()

    return OAuthCallbackHandler


def browser_login(timeout: int = 120, port: int | None = None) -> tuple[str, str | None, str | None]:
    """Open browser for GitHub OAuth and return tokens.
    Starts a local HTTP server, opens browser to Supabase OAuth,
    and waits for the callback with the tokens.
    Args:
        timeout: Seconds to wait for callback (default 120)
        port: Port for callback server. If None, finds a free port (default None)
    Returns:
        Tuple of (access_token, refresh_token, provider_token).
        refresh_token and provider_token may be None.
    Raises:
        TimeoutError: If no callback received within timeout
        RuntimeError: If OAuth flow failed
    """
    import webbrowser
    from http.server import HTTPServer

    from .global_config import get_supabase_url

    if port is None:
        port = _find_free_port()
    redirect_uri = f"http://localhost:{port}/callback"
    supabase_url = get_supabase_url()
    auth_url = f"{supabase_url}/auth/v1/authorize?provider=github&redirect_to={redirect_uri}"
    OAuthCallbackHandler = _get_oauth_handler_class()
    OAuthCallbackHandler.access_token = None
    OAuthCallbackHandler.refresh_token = None
    OAuthCallbackHandler.provider_token = None
    OAuthCallbackHandler.error = None
    server = HTTPServer(("localhost", port), OAuthCallbackHandler)
    server.timeout = 1
    print("Opening browser for GitHub authentication...")
    print(f"If browser doesn't open, visit: {auth_url}")
    webbrowser.open(auth_url)
    start = time.time()
    print("Waiting for authentication...", end="", flush=True)
    while time.time() - start < timeout:
        server.handle_request()
        if OAuthCallbackHandler.access_token:
            print(f" {CHECK}")
            server.server_close()
            return OAuthCallbackHandler.access_token, OAuthCallbackHandler.refresh_token, OAuthCallbackHandler.provider_token
        if OAuthCallbackHandler.error:
            print(f" {CROSS}")
            server.server_close()
            raise RuntimeError(f"OAuth failed: {OAuthCallbackHandler.error}")
    server.server_close()
    raise TimeoutError(f"No response within {timeout} seconds")


def device_code_login(timeout: int = 600) -> tuple[str, str | None, str | None]:
    """Authenticate using state-based flow (no browser/port forwarding needed).
    This is the SSH-friendly auth flow similar to GitHub CLI:
    1. Request a state token from the API
    2. Display the auth URL with state parameter
    3. User visits URL on any device and signs in normally
    4. Poll API until user completes authentication
    Args:
        timeout: Seconds to wait for authentication (default 600 = 10 minutes)
    Returns:
        Tuple of (access_token, refresh_token, provider_token).
        refresh_token and provider_token may be None.
    Raises:
        TimeoutError: If user doesn't authenticate within timeout
        RuntimeError: If auth flow failed
    """
    import webbrowser

    import httpx

    from .global_config import get_api_url

    api_url = get_api_url()
    with httpx.Client(timeout=10.0) as client:
        response = client.post(f"{api_url}/v1/auth/cli-auth/start", json={})
        if not response.is_success:
            raise RuntimeError(
                f"Failed to start auth flow ({response.status_code}). Is the API reachable?"
            )
        data = response.json()
    state = data["state"]
    auth_url = data["auth_url"]
    expires_in = data["expires_in"]
    print("\n" + "=" * 60)
    print("  WAFER CLI - Authentication")
    print("=" * 60)
    print(f"\n  Visit: {auth_url}")
    print("\n  Sign in with GitHub to complete authentication")
    print("\n" + "=" * 60 + "\n")
    webbrowser.open(auth_url)
    start = time.time()
    poll_interval = 5
    last_poll = 0.0
    print("Waiting for authentication", end="", flush=True)
    while time.time() - start < min(timeout, expires_in):
        if time.time() - last_poll >= poll_interval:
            print(".", end="", flush=True)
            with httpx.Client(timeout=10.0) as client:
                try:
                    response = client.post(
                        f"{api_url}/v1/auth/cli-auth/token", json={"state": state}
                    )
                    if response.status_code == 200:
                        data = response.json()
                        print(f" {CHECK}\n")
                        return data["access_token"], data.get("refresh_token"), data.get("provider_token")
                    if response.status_code == 428:
                        last_poll = time.time()
                        time.sleep(1)
                        continue
                    print(f" {CROSS}\n")
                    raise RuntimeError(
                        f"CLI auth flow failed: {response.status_code} {response.text}"
                    )
                except httpx.RequestError:
                    print("!", end="", flush=True)
                    last_poll = time.time()
                    time.sleep(1)
                    continue
        time.sleep(0.5)
    print(f" {CROSS}\n")
    raise TimeoutError(f"Authentication not completed within {expires_in} seconds")
