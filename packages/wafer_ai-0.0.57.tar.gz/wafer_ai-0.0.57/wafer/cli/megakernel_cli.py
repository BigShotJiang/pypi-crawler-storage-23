# TODO: Migrate megakernel benchmark into `wafer tool eval` as a first-class
# evaluation backend. The current standalone `wafer megakernel submit` command
# shells out to `megakernel_bench.bench` which is an external module with no
# integration into the eval harness (scorer.py, eval_task, etc.). Target design:
#
#   wafer tool eval --scorer megakernel --problem problem.json solution.py
#
# This would let megakernel problems participate in the same eval infrastructure
# as CUDA/Triton kernels (scoring, baselines, autotuner sweeps). Until then,
# this command is a minimal passthrough wrapper.
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import typer

megakernel_app = typer.Typer(name="megakernel", help="Megakernel benchmark")


@megakernel_app.command("submit")
def submit(
    solution: Path = typer.Option(..., help="Path to solution.py"),
    problem: Path = typer.Option(..., help="Path to problem.json"),
) -> None:
    """Submit a megakernel for evaluation."""
    assert solution.is_file(), f"Solution not found: {solution}"
    assert problem.is_file(), f"Problem not found: {problem}"

    work_dir = solution.parent
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "megakernel_bench.bench",
            "--work-dir",
            str(work_dir),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    typer.echo(result.stdout)
    if result.returncode != 0:
        typer.echo(result.stderr, err=True)
        raise typer.Exit(code=result.returncode)
