"""Workspaces CLI - Manage remote GPU workspaces.
This module provides the implementation for the `wafer target` subcommand.
"""
import json
import socket
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

import httpx

from .api_client import get_api_url
from .auth import get_auth_headers

VALID_STATUSES = {"creating", "running", "error"}


def _get_client() -> tuple[str, dict[str, str]]:
    """Get API URL and auth headers."""
    api_url = get_api_url()
    headers = get_auth_headers()
    assert api_url, "API URL must be configured"
    assert api_url.startswith("http"), "API URL must be a valid HTTP(S) URL"
    return api_url, headers


def _check_ssh_ready(host: str, port: int, timeout: float = 2.0) -> bool:
    """Check if SSH port is accepting connections.
    Args:
        host: SSH host
        port: SSH port
        timeout: Connection timeout in seconds
    Returns:
        True if SSH is accepting connections, False otherwise
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(timeout)
            result = sock.connect_ex((host, port))
            return result == 0
    except (TimeoutError, socket.gaierror, OSError):
        return False


def _friendly_error(status_code: int, response_text: str, workspace_id: str) -> str:
    """Convert API errors to friendly messages with guidance.
    Args:
        status_code: HTTP status code
        response_text: Response body
        workspace_id: Workspace ID or name for context
    Returns:
        User-friendly error message with suggested next steps
    """
    if status_code == 401:
        return "Not authenticated. Run: wafer login"
    if status_code == 402:
        return (
            "Insufficient credits.\n"
            "  Check usage: wafer billing\n"
            "  Add credits: wafer billing topup"
        )
    if status_code == 404:
        return (
            f"Workspace '{workspace_id}' not found.\n"
            "  List workspaces: wafer target list\n"
            "  Create one: wafer target init workspace <name>"
        )
    if status_code == 503:
        return (
            "No GPU available.\n"
            "  The workspace is queued for GPU access. Try again in a moment.\n"
            "  Check status: wafer target show " + workspace_id
        )
    detail = ""
    if "not running" in response_text.lower() or "not found" in response_text.lower():
        return (
            f"Workspace '{workspace_id}' not found or not running.\n"
            "  Check status: wafer target list\n"
            "  Create new:   wafer target init workspace <name>"
        )
    if "timeout" in response_text.lower():
        return (
            "Command timed out.\n"
            '  Increase timeout: wafer target run --name <workspace> --timeout 600 -- <cmd>\n'
            "  Or set default: wafer config set defaults.exec_timeout 600"
        )
    if "creating" in response_text.lower():
        return (
            f"Workspace '{workspace_id}' is still creating.\n  Check status: wafer target list"
        )
    # Generic error with response detail
    try:
        data = json.loads(response_text)
        detail = data.get("detail", response_text)
    except (json.JSONDecodeError, KeyError):
        detail = response_text
    return f"API error ({status_code}): {detail}"


def _list_workspaces_raw() -> list[dict]:
    """List workspaces and return raw data (for internal use)."""
    api_url, headers = _get_client()
    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.get(f"{api_url}/v1/workspaces")
            response.raise_for_status()
            workspaces = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e
    assert isinstance(workspaces, list), "API must return a list of workspaces"
    for ws in workspaces:
        status = ws.get("status", "unknown")
        assert status in VALID_STATUSES or status == "unknown", (
            f"Workspace {ws.get('id', 'unknown')} has invalid status '{status}'. "
            f"Valid statuses: {VALID_STATUSES}"
        )
    return workspaces


def resolve_workspace(specified: str | None) -> str:
    """Resolve workspace ID from specified name/ID, config default, or single workspace.
    Priority:
    1. If specified, return it (API will resolve name vs ID)
    2. If config has defaults.workspace, return that
    3. If user has exactly one workspace, return its ID
    4. Otherwise, error with guidance
    Args:
        specified: Workspace name or ID, or None to use default
    Returns:
        Workspace name or ID to use
    Raises:
        RuntimeError: If no workspace can be resolved
    """
    from .global_config import get_defaults
    # If specified, use it (API resolves name vs ID)
    if specified:
        return specified
    defaults = get_defaults()
    if defaults.workspace:
        return defaults.workspace
    workspaces = _list_workspaces_raw()
    if len(workspaces) == 0:
        raise RuntimeError("No workspaces found. Create one with: wafer target init workspace <name>")
    if len(workspaces) == 1:
        return workspaces[0]["id"]
    # Multiple workspaces, no default - error with guidance
    names = [ws.get("name", ws["id"]) for ws in workspaces]
    raise RuntimeError(
        f"Multiple workspaces found: {', '.join(names)}\n"
        "Specify one, or set default: wafer config set defaults.workspace <name>"
    )


def list_workspaces(json_output: bool = False, sync_status: bool = False) -> str:
    """List all workspaces for the current user.
    Args:
        json_output: If True, return raw JSON; otherwise return formatted text
        sync_status: If True, live-check container statuses via SSH (slower).
                     If False (default), use cached/DB status for fast listing.
    Returns:
        Workspaces list as string (JSON or formatted text)
    """
    api_url, headers = _get_client()
    try:
        params = {"sync_status": "true"} if sync_status else {}
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.get(f"{api_url}/v1/workspaces", params=params)
            response.raise_for_status()
            workspaces = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e
    assert isinstance(workspaces, list), "API must return a list of workspaces"
    for ws in workspaces:
        status = ws.get("status", "unknown")
        assert status in VALID_STATUSES or status == "unknown", (
            f"Workspace {ws.get('id', 'unknown')} has invalid status '{status}'. "
            f"Valid statuses: {VALID_STATUSES}"
        )
    if json_output:
        from .output import json_response
        return json_response(data={"workspaces": workspaces})
    if not workspaces:
        return "No workspaces found."
    lines = ["Workspaces:", ""]
    for ws in workspaces:
        status = ws.get("status", "unknown")
        status_icon = {"running": "*", "creating": "~", "error": "x"}.get(status, "?")
        lines.append(f"  {status_icon} {ws['name']} ({ws['id']})")
        lines.append(f"    GPU: {ws.get('gpu_type', 'N/A')} | Image: {ws.get('image', 'N/A')}")
        if status == "error":
            lines.append(
                f"    Status: Provisioning failed. Delete and recreate: wafer target remove {ws['name']}"
            )
        elif ws.get("ssh_host") and ws.get("ssh_port") and ws.get("ssh_user"):
            ssh_line = f"    SSH: ssh -p {ws['ssh_port']} {ws['ssh_user']}@{ws['ssh_host']}"
            if status == "creating":
                ssh_line += " (finalizing...)"
            lines.append(ssh_line)
        elif status == "running":
            lines.append(
                f"    Status: Running but SSH not ready. Try: wafer target remove {ws['name']} && wafer target init workspace {ws['name']} --wait"
            )
        else:
            lines.append("    SSH: Not ready (workspace is still creating)")
        lines.append("")
    has_running_with_ssh = any(
        ws.get("status") == "running" and ws.get("ssh_host") for ws in workspaces
    )
    if has_running_with_ssh:
        lines.append("Tip: SSH directly for interactive work. 'exec' is for quick commands only.")
    has_error = any(ws.get("status") == "error" for ws in workspaces)
    if has_error:
        lines.append("Note: Error workspaces are auto-cleaned after 12 hours.")
    return "\n".join(lines)


def _check_duplicate_workspace_name(name: str, api_url: str, headers: dict[str, str]) -> None:
    assert name, "Workspace name must be non-empty"
    assert api_url, "API URL must be non-empty"
    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.get(f"{api_url}/v1/workspaces")
            response.raise_for_status()
            existing = response.json()
            existing_names = [ws.get("name") for ws in existing]
            if name in existing_names:
                raise RuntimeError(
                    f"Workspace '{name}' already exists.\n"
                    f"  Use a different name, or delete the existing one:\n"
                    f"  wafer target remove {name}"
                )
    except httpx.HTTPStatusError:
        pass  # Continue with create, let API handle auth errors
    except httpx.RequestError:
        pass  # Continue with create, let API handle connection errors


def _format_create_result(
    workspace: dict, wait: bool, json_output: bool,
) -> str:
    assert workspace, "Workspace dict must be non-empty"
    assert "id" in workspace, "Workspace must contain 'id'"
    if wait:
        ssh_info = _wait_for_provisioning(workspace["id"])
        if json_output:
            from .output import json_response
            payload = {
                "workspace_id": workspace["id"],
                "ssh_host": ssh_info["ssh_host"],
                "ssh_port": ssh_info["ssh_port"],
                "ssh_user": ssh_info["ssh_user"],
            }
            return json_response(data=payload)
        return (
            f"Workspace ready: {workspace['name']} ({workspace['id']})\n"
            f"SSH: ssh -p {ssh_info['ssh_port']} {ssh_info['ssh_user']}@{ssh_info['ssh_host']}"
        )
    if json_output:
        from .output import json_response
        return json_response(data=workspace)
    return (
        f"Creating workspace: {workspace['name']} ({workspace['id']})\n"
        "Check status with: wafer target list\n"
        "Estimated time: ~30 seconds"
    )


def create_workspace(
    name: str,
    gpu_type: str,
    environment_type: str,
    image: str | None = None,
    wait: bool = False,
    json_output: bool = False,
) -> str:
    """Create a new workspace.
    Per-vendor architecture: each workspace has a single environment type.
    Args:
        name: Workspace name (must be unique)
        gpu_type: GPU type (required: B200, H100, MI300X)
        environment_type: Environment type (required: modal, baremetal)
        image: Docker image (optional, uses default if not specified)
        wait: If True, stream provisioning progress and return SSH credentials
        json_output: If True, return raw JSON; otherwise return formatted text
    Returns:
        Created workspace info as string
    Raises:
        RuntimeError: If name already exists or API error
    """
    # Validate inputs
    assert name, "Workspace name must be non-empty"
    assert gpu_type, "GPU type must be non-empty"
    assert environment_type, "Environment type must be non-empty"
    api_url, headers = _get_client()
    _check_duplicate_workspace_name(name, api_url, headers)
    request_body: dict = {
        "name": name,
        "gpu_type": gpu_type,
        "environment_type": environment_type,
    }
    if image:
        request_body["image"] = image
    try:
        with httpx.Client(timeout=60.0, headers=headers) as client:
            response = client.post(f"{api_url}/v1/workspaces", json=request_body)
            response.raise_for_status()
            workspace = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        if e.response.status_code == 400:
            raise RuntimeError(f"Bad request: {e.response.text}") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e
    # Validate API response has required fields
    assert "id" in workspace, "API response must contain workspace id"
    assert "name" in workspace, "API response must contain workspace name"
    return _format_create_result(workspace, wait, json_output)


def _wait_for_provisioning(workspace_id: str) -> dict[str, str | int]:
    """Wait for workspace provisioning to complete via SSE."""
    import sys
    assert workspace_id, "Workspace ID must be non-empty"
    api_url, headers = _get_client()
    try:
        with httpx.Client(timeout=120, headers=headers) as client:
            with client.stream(
                "POST",
                f"{api_url}/v1/workspaces/{workspace_id}/provision-stream",
            ) as response:
                if response.status_code != 200:
                    error_body = response.read().decode("utf-8", errors="replace")
                    raise RuntimeError(
                        _friendly_error(response.status_code, error_body, workspace_id)
                    )
                ssh_info: dict[str, str | int] | None = None
                for line in response.iter_lines():
                    if not line or not line.startswith("data: "):
                        continue
                    content = line[6:]
                    if content.startswith("[STATUS:"):
                        status = content[8:-1]
                        print(f"[wafer] {status.lower()}...", file=sys.stderr)
                        if status == "ERROR":
                            raise RuntimeError(
                                "Workspace provisioning failed. Check status with: wafer target list"
                            )
                    elif content.startswith("[SSH:"):
                        parts = content[5:-1].split(":")
                        if len(parts) != 3:
                            raise RuntimeError("Malformed SSH info in provisioning stream")
                        ssh_info = {
                            "ssh_host": parts[0],
                            "ssh_port": int(parts[1]),
                            "ssh_user": parts[2],
                        }
                        break
                if ssh_info is None:
                    raise RuntimeError("Provisioning did not return SSH credentials")
                return ssh_info
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e


def delete_workspace(workspace_id: str, json_output: bool = False) -> str:
    """Delete a workspace.
    Args:
        workspace_id: Workspace ID to delete
        json_output: If True, return raw JSON; otherwise return formatted text
    Returns:
        Deletion status as string
    """
    assert workspace_id, "Workspace ID must be non-empty"
    api_url, headers = _get_client()
    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.delete(f"{api_url}/v1/workspaces/{workspace_id}")
            response.raise_for_status()
            result = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        if e.response.status_code == 404:
            raise RuntimeError(f"Workspace not found: {workspace_id}") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e
    if json_output:
        from .output import json_response
        return json_response(data=result)
    return f"Deleted workspace: {workspace_id}"


def _get_running_workspace_ssh(workspace_id: str, action: str) -> dict:
    ws = get_workspace_raw(workspace_id)
    workspace_status = ws.get("status")
    assert workspace_status in VALID_STATUSES, (
        f"Workspace {workspace_id} has invalid status '{workspace_status}'. "
        f"Valid statuses: {VALID_STATUSES}"
    )
    if workspace_status == "error":
        raise RuntimeError(
            f"Workspace provisioning failed. Delete and recreate:\n"
            f"  wafer target remove {workspace_id}\n"
            f"  wafer target init workspace {ws.get('name', workspace_id)} --wait"
        )
    if workspace_status != "running":
        raise RuntimeError(
            f"Workspace is {workspace_status}. Wait for it to be running before {action}."
        )
    ssh_host = ws.get("ssh_host")
    ssh_port = ws.get("ssh_port")
    ssh_user = ws.get("ssh_user")
    if not ssh_host or not ssh_port or not ssh_user:
        raise RuntimeError(
            f"Workspace is running but SSH not ready.\n"
            f"  Delete and recreate: wafer target remove {workspace_id}\n"
            f"  Then: wafer target init workspace {ws.get('name', workspace_id)} --wait"
        )
    assert isinstance(ssh_port, int) and ssh_port > 0, "Workspace missing valid ssh_port"
    return ws


def _wait_for_ssh_ready(
    ssh_host: str, ssh_port: int, workspace_id: str,
    emit: Callable[[str], None],
) -> None:
    assert ssh_host, "SSH host must be non-empty"
    assert ssh_port > 0, "SSH port must be positive"
    max_retries = 3
    retry_delay = 5  # seconds
    for attempt in range(max_retries):
        if _check_ssh_ready(ssh_host, ssh_port):
            return
        if attempt < max_retries - 1:
            emit(f"SSH not ready yet, waiting {retry_delay}s... (attempt {attempt + 1}/{max_retries})")
            time.sleep(retry_delay)
    raise RuntimeError(
        f"Workspace is running but SSH is not accepting connections.\n"
        f"This can happen if the workspace was just created.\n"
        f"Wait a few more seconds and try again, or check status:\n"
        f"  wafer target show {workspace_id}"
    )


def _run_rsync(rsync_cmd: list[str], feature_name: str) -> int:
    assert rsync_cmd, "rsync command must be non-empty"
    assert feature_name, "feature name required for error messages"
    import subprocess
    try:
        result = subprocess.run(rsync_cmd, capture_output=True, text=True)
        if result.returncode != 0:
            return _handle_rsync_error(result.stderr)
        lines = result.stdout.strip().split("\n")
        return sum(
            1
            for line in lines
            if line and not line.startswith((" ", "sent", "total", "receiving", "building", "Transfer"))
        )
    except FileNotFoundError:
        raise RuntimeError(f"rsync not found. Install rsync to use {feature_name} feature.") from None
    except subprocess.SubprocessError as e:
        raise RuntimeError(f"{feature_name.capitalize()} failed: {e}") from e


def _handle_rsync_error(stderr: str) -> int:
    assert isinstance(stderr, str), "stderr must be a string"
    if not stderr:
        raise RuntimeError("rsync failed (no error details available)")
    if "Connection refused" in stderr or "Connection closed" in stderr:
        raise RuntimeError(
            "SSH connection to workspace failed.\n"
            "This could be due to SSH not being fully ready, network issues, or workspace configuration."
        )
    raise RuntimeError(f"rsync failed: {stderr}")


def sync_files(
    workspace_id: str,
    local_path: Path,
    on_progress: Callable[[str], None] | None = None,
    remote_path: str | None = None,
) -> tuple[int, str | None]:
    """Sync local files or directories to workspace via rsync over SSH.
    After rsync completes, calls the API to sync files to Modal volume
    so they're available for exec commands.
    Args:
        workspace_id: Workspace ID or name
        local_path: Local file or directory to sync
        on_progress: Optional callback for progress messages
        remote_path: Remote destination path (default: /workspace/)
    Returns:
        Tuple of (file_count, warning_message). Warning is None on success.
    Raises:
        RuntimeError: If rsync fails
    """
    def emit(msg: str) -> None:
        if on_progress:
            on_progress(msg)
    assert workspace_id, "Workspace ID must be non-empty"
    assert local_path.exists(), f"Path not found: {local_path}"
    ws = _get_running_workspace_ssh(workspace_id, "syncing")
    resolved_id = ws["id"]
    ssh_host, ssh_port, ssh_user = ws["ssh_host"], ws["ssh_port"], ws["ssh_user"]
    _wait_for_ssh_ready(ssh_host, ssh_port, workspace_id, emit)
    source = f"{local_path}/" if local_path.is_dir() else str(local_path)
    from wafer.core.ssh_utils import ssh_mux_opts

    ssh_opts = f"-p {ssh_port} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null {ssh_mux_opts()}"
    dest = remote_path if remote_path else "/workspace/"
    rsync_cmd = [
        "rsync", "-avz", "-e", f"ssh {ssh_opts}",
        source, f"{ssh_user}@{ssh_host}:{dest}",
    ]
    file_count = _run_rsync(rsync_cmd, "sync")
    emit(f"[ok] Synced {file_count} files to {dest}")
    # Notify API to sync files to Modal volume (so exec can see them)
    emit("Syncing to Modal volume...")
    warning = _init_sync_state(resolved_id)
    if warning:
        emit(f"Modal sync warning: {warning}")
    else:
        emit("[ok] Modal sync complete")
    return file_count, warning


def _build_pull_not_found_error(remote_path: str, original_remote_path: str) -> str:
    assert remote_path, "remote_path must be non-empty"
    assert original_remote_path, "original_remote_path must be non-empty"
    error_msg = f"File not found: {remote_path}\n\n"
    error_msg += "Tip: Shell commands (echo, bash) write to /home/wafer by default.\n"
    error_msg += "     Python commands auto-use /workspace as working directory.\n\n"
    if not original_remote_path.startswith("/"):
        suggested_workspace = f"/workspace/{original_remote_path}"
        suggested_home = f"/home/wafer/{original_remote_path}"
        error_msg += "Your file might be at:\n"
        error_msg += f"  - {suggested_workspace} (if created by Python)\n"
        error_msg += f"  - {suggested_home} (if created by shell command)\n\n"
    error_msg += "Use absolute paths to control where files are created:\n"
    error_msg += "  echo \"text\" > /workspace/myfile.txt"
    return error_msg


def _run_pull_rsync(rsync_cmd: list[str], remote_path: str, original_remote_path: str) -> int:
    assert rsync_cmd, "rsync command must be non-empty"
    assert remote_path, "remote_path must be non-empty"
    import subprocess
    try:
        result = subprocess.run(rsync_cmd, capture_output=True, text=True)
        if result.returncode != 0:
            if "No such file or directory" in result.stderr or "link_stat" in result.stderr:
                raise RuntimeError(_build_pull_not_found_error(remote_path, original_remote_path))
            raise RuntimeError(f"rsync failed: {result.stderr}")
        lines = result.stdout.strip().split("\n")
        return sum(
            1
            for line in lines
            if line and not line.startswith((" ", "sent", "total", "receiving", "building", "Transfer"))
        )
    except FileNotFoundError:
        raise RuntimeError("rsync not found. Install rsync to use pull feature.") from None
    except subprocess.SubprocessError as e:
        raise RuntimeError(f"Pull failed: {e}") from e


def pull_files(
    workspace_id: str,
    remote_path: str,
    local_path: Path,
    on_progress: Callable[[str], None] | None = None,
) -> int:
    """Pull files from workspace to local via rsync over SSH.
    Args:
        workspace_id: Workspace ID or name
        remote_path: Remote path in workspace (relative to /workspace or absolute)
        local_path: Local destination path
        on_progress: Optional callback for progress messages
    Returns:
        Number of files transferred
    Raises:
        RuntimeError: If rsync fails or workspace not accessible
    """
    def emit(msg: str) -> None:
        if on_progress:
            on_progress(msg)
    assert workspace_id, "Workspace ID must be non-empty"
    ws = _get_running_workspace_ssh(workspace_id, "pulling files")
    ssh_host, ssh_port, ssh_user = ws["ssh_host"], ws["ssh_port"], ws["ssh_user"]
    original_remote_path = remote_path
    # Normalize remote path - if not absolute, assume relative to /workspace
    if not remote_path.startswith("/"):
        remote_path = f"/workspace/{remote_path}"
    from wafer.core.ssh_utils import ssh_mux_opts

    ssh_opts = f"-p {ssh_port} -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null {ssh_mux_opts()}"
    rsync_cmd = [
        "rsync", "-avz", "-e", f"ssh {ssh_opts}",
        f"{ssh_user}@{ssh_host}:{remote_path}", str(local_path),
    ]
    emit(f"Pulling {remote_path} from workspace...")
    file_count = _run_pull_rsync(rsync_cmd, remote_path, original_remote_path)
    emit(f"Pulled {file_count} files")
    return file_count


def _init_sync_state(workspace_id: str) -> str | None:
    """Tell API to sync files from bare metal to Modal volume.
    This must be called after rsync completes so exec commands
    can access the synced files.
    Returns:
        None on success, warning message on failure (non-fatal)
    """
    api_url, headers = _get_client()
    try:
        with httpx.Client(timeout=120.0, headers=headers) as client:
            response = client.post(f"{api_url}/v1/workspaces/{workspace_id}/init-sync-state")
            response.raise_for_status()
            return None
    except httpx.HTTPStatusError as e:
        # Non-fatal: sync to bare metal succeeded, Modal sync failed
        # User can still SSH in and use files, just not via exec
        if e.response.status_code == 404:
            # Workspace not found or no target - sync still worked for SSH
            return None
        else:
            detail = ""
            try:
                data = e.response.json()
                detail = data.get("detail", "")
            except (json.JSONDecodeError, ValueError):
                detail = e.response.text[:200] if e.response.text else ""
            if detail:
                return f"Files synced to SSH, but Modal sync failed: {detail}"
            return f"Files synced to SSH, but Modal sync failed ({e.response.status_code}). Use SSH or retry sync."
    except httpx.RequestError:
        # Network error - sync to bare metal succeeded
        return None


def get_workspace_raw(workspace_id: str) -> dict:
    """Get workspace details as raw JSON dict."""
    assert workspace_id, "Workspace ID must be non-empty"
    api_url, headers = _get_client()
    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.get(f"{api_url}/v1/workspaces/{workspace_id}")
            response.raise_for_status()
            workspace = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        if e.response.status_code == 404:
            raise RuntimeError(f"Workspace not found: {workspace_id}") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e
    assert "id" in workspace, "API response must contain workspace id"
    assert "name" in workspace, "API response must contain workspace name"
    status = workspace.get("status", "unknown")
    assert status in VALID_STATUSES or status == "unknown", (
        f"Workspace {workspace['id']} has invalid status '{status}'. "
        f"Valid statuses: {VALID_STATUSES}"
    )
    return workspace


def get_workspace(workspace_id: str, json_output: bool = False) -> str:
    """Get details of a specific workspace.
    Args:
        workspace_id: Workspace ID to get
        json_output: If True, return raw JSON; otherwise return formatted text
    Returns:
        Workspace details as string
    """
    workspace = get_workspace_raw(workspace_id)
    if json_output:
        from .output import json_response
        return json_response(data=workspace)
    status = workspace.get("status", "unknown")
    lines = [
        f"Workspace: {workspace['name']} ({workspace['id']})",
        "",
        f"  Status: {status}",
        f"  GPU Type: {workspace.get('gpu_type', 'N/A')}",
        f"  Image: {workspace.get('image', 'N/A')}",
        f"  Created: {workspace.get('created_at', 'N/A')}",
        f"  Last Used: {workspace.get('last_used_at', 'N/A')}",
    ]
    if status == "error":
        lines.extend([
            "",
            "Provisioning failed. Delete and recreate:",
            f"  wafer target remove {workspace['name']}",
            f"  wafer target init workspace {workspace['name']} --wait",
            "",
            "Note: Error workspaces are auto-cleaned after 12 hours.",
        ])
    elif workspace.get("ssh_host"):
        lines.extend([
            "",
            "SSH Info:",
            f"  Host: {workspace['ssh_host']}",
            f"  Port: {workspace.get('ssh_port', 22)}",
            f"  User: {workspace.get('ssh_user', 'root')}",
            "",
            "Tip: SSH directly for interactive work. 'exec' is for quick commands only.",
        ])
    elif status == "creating":
        lines.extend(["", "SSH: available once workspace is running"])
    elif status == "running":
        # Running but no SSH credentials - unusual state
        lines.extend([
            "",
            "Status: Running but SSH not ready.",
            f"  Delete and recreate: wafer target remove {workspace['name']}",
        ])
    return "\n".join(lines)


def _handle_sync_event(sync_type: str) -> None:
    """Handle sync events and print status to stderr.
    Sync events:
    - FORWARD:START - Starting workspace → GPU sync
    - FORWARD:DONE:N - Synced N files to GPU
    - FORWARD:WARN:msg - Warning during forward sync
    - REVERSE:START - Starting GPU → workspace sync
    - REVERSE:DONE:N - Synced N artifacts back
    """
    import sys
    if sync_type == "FORWARD:START":
        print("[sync] Syncing workspace -> GPU...", end="", file=sys.stderr, flush=True)
    elif sync_type.startswith("FORWARD:DONE:"):
        count = sync_type.split(":")[-1]
        print(f" done ({count} files)", file=sys.stderr)
    elif sync_type.startswith("FORWARD:WARN:"):
        msg = sync_type[13:]  # Remove "FORWARD:WARN:"
        print(f" warning: {msg}", file=sys.stderr)
    elif sync_type == "REVERSE:START":
        print("[sync] Syncing artifacts back...", end="", file=sys.stderr, flush=True)
    elif sync_type.startswith("REVERSE:DONE:"):
        count = sync_type.split(":")[-1]
        print(f" done ({count} files)", file=sys.stderr)


@dataclass(frozen=True)
class SSEEvent:
    """Parsed SSE event result."""
    output: str | None  # Content to print (None = no output)
    exit_code: int | None  # Exit code if stream should end (None = continue)
    is_error: bool  # Whether output goes to stderr
    sync_event: str | None = None  # Sync event type (e.g., "FORWARD:START")


def _parse_sse_content(content: str) -> SSEEvent:
    """Parse SSE content into structured event.
    Pure function: content in, event out. No side effects.
    """
    if content == "[DONE]":
        return SSEEvent(output=None, exit_code=0, is_error=False)
    if content.startswith("[EXIT:"):
        try:
            code = int(content[6:-1])
        except ValueError:
            code = 0
        return SSEEvent(output=None, exit_code=code, is_error=False)
    if content.startswith("[ERROR]"):
        return SSEEvent(output=content[8:], exit_code=1, is_error=True)
    # Sync events: [SYNC:FORWARD:START], [SYNC:FORWARD:DONE:5], etc.
    if content.startswith("[SYNC:"):
        sync_type = content[6:-1]  # Remove [SYNC: and ]
        return SSEEvent(output=None, exit_code=None, is_error=False, sync_event=sync_type)
    # Status events we can ignore (already handled elsewhere)
    if content.startswith("[STATUS:") or content.startswith("[CONTEXT:"):
        return SSEEvent(output=None, exit_code=None, is_error=False)
    # Regular output
    return SSEEvent(output=content, exit_code=None, is_error=False)


def _exec_via_ssh(ssh_host: str, ssh_port: int, ssh_user: str, command: str, timeout_seconds: int | None = None) -> int:
    """Execute command via SSH, streaming output to stdout/stderr.
    Used for baremetal workspaces. The workspace's zsh plugin handles GPU routing.
    Args:
        ssh_host: SSH hostname
        ssh_port: SSH port
        ssh_user: SSH username
        command: Command to execute
        timeout_seconds: Optional timeout in seconds
    Returns:
        Exit code from remote command
    Raises:
        RuntimeError: If command exceeds timeout
    """
    import shlex
    import subprocess
    assert ssh_host, "SSH host required"
    assert ssh_port > 0, "SSH port must be positive"
    assert ssh_user, "SSH user required"
    assert command, "Command required"
    from wafer.core.ssh_utils import ssh_mux_args

    ssh_cmd = [
        "ssh",
        "-p", str(ssh_port),
        "-t",
        "-o", "StrictHostKeyChecking=accept-new",
        "-o", "UserKnownHostsFile=~/.ssh/known_hosts",
        "-o", "BatchMode=yes",
        "-o", "LogLevel=ERROR",
        *ssh_mux_args(),
        f"{ssh_user}@{ssh_host}",
        f"zsh -i -l -c {shlex.quote(command)}",
    ]
    # Don't pipe stdout/stderr - let them inherit our file descriptors
    # This preserves terminal formatting (colors, control sequences) and enables streaming
    process = subprocess.Popen(ssh_cmd)
    try:
        returncode = process.wait(timeout=timeout_seconds)
        return returncode
    except subprocess.TimeoutExpired:
        # Kill the process if it times out
        process.kill()
        process.wait()  # Clean up zombie process
        raise RuntimeError(
            f"Command timed out after {timeout_seconds} seconds"
        ) from None


def _exec_via_ssh_capture(
    ssh_host: str, ssh_port: int, ssh_user: str, command: str, timeout_seconds: int | None = None,
) -> tuple[int, str, str]:
    """Execute command via SSH, capturing stdout/stderr.

    Like _exec_via_ssh but returns (exit_code, stdout, stderr) instead of streaming.
    Used by exec_command_capture for baremetal workspaces.
    """
    import shlex
    import subprocess
    from wafer.core.ssh_utils import ssh_mux_args

    assert ssh_host and ssh_port > 0 and ssh_user and command
    ssh_cmd = [
        "ssh",
        "-p", str(ssh_port),
        "-T",
        "-o", "StrictHostKeyChecking=accept-new",
        "-o", "UserKnownHostsFile=~/.ssh/known_hosts",
        "-o", "BatchMode=yes",
        "-o", "LogLevel=ERROR",
        *ssh_mux_args(),
        f"{ssh_user}@{ssh_host}",
        f"zsh -l -c {shlex.quote(command)}",
    ]
    try:
        result = subprocess.run(
            ssh_cmd,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
        )
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        raise RuntimeError(
            f"Command timed out after {timeout_seconds} seconds"
        ) from None


def _build_exec_request(
    command: str, timeout_seconds: int | None, routing: str | None, pull_image: bool,
) -> tuple[dict, float]:
    assert command, "Command must be non-empty"
    assert isinstance(pull_image, bool), "pull_image must be a boolean"
    import base64
    command_b64 = base64.b64encode(command.encode("utf-8")).decode("utf-8")
    request_body: dict = {"command_b64": command_b64, "pull_image": pull_image}
    if timeout_seconds:
        request_body["timeout_seconds"] = timeout_seconds
    if routing:
        request_body["requirements"] = {"routing": routing}
    server_timeout = timeout_seconds or 300
    read_timeout = float(server_timeout + 60)
    return request_body, read_timeout


def _stream_exec_sse(
    workspace_id: str,
    request_body: dict,
    read_timeout: float,
    event_handler: Callable[[SSEEvent], None],
) -> int:
    assert workspace_id, "Workspace ID must be non-empty"
    assert request_body, "Request body must be non-empty"
    api_url, headers = _get_client()
    stream_timeout = httpx.Timeout(connect=30.0, read=read_timeout, write=30.0, pool=30.0)
    try:
        with httpx.Client(timeout=stream_timeout, headers=headers) as client:
            with client.stream(
                "POST",
                f"{api_url}/v1/workspaces/{workspace_id}/exec",
                json=request_body,
            ) as response:
                if response.status_code != 200:
                    error_body = response.read().decode("utf-8", errors="replace")
                    raise RuntimeError(
                        _friendly_error(response.status_code, error_body, workspace_id)
                    )
                exit_code = 0
                for line in response.iter_lines():
                    if not line or not line.startswith("data: "):
                        continue
                    event = _parse_sse_content(line[6:])
                    event_handler(event)
                    if event.exit_code is not None:
                        exit_code = event.exit_code
                        break
                return exit_code
    except httpx.HTTPStatusError as e:
        raise RuntimeError(
            _friendly_error(e.response.status_code, e.response.text, workspace_id)
        ) from e
    except httpx.ReadTimeout as e:
        raise RuntimeError(
            f"Exec stream stalled on workspace '{workspace_id}' "
            f"(no data for {read_timeout:.0f}s). The command may have "
            f"completed but the stream didn't close."
        ) from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e


def exec_command(
    workspace_id: str,
    command: str,
    timeout_seconds: int | None = None,
    routing: str | None = None,
    pull_image: bool = False,
) -> int:
    """Execute a command in workspace, streaming output.
    For baremetal workspaces (with SSH access), commands are executed via SSH.
    The workspace's zsh plugin handles GPU routing automatically, ensuring
    packages installed via pip persist across commands.
    For Modal workspaces (no SSH), commands are executed via the API.
    Args:
        workspace_id: Workspace ID or name
        command: Command to execute
        timeout_seconds: Execution timeout (default: 300, from config)
        routing: Routing hint - "auto", "gpu", "cpu", or "baremetal" (default: auto)
        pull_image: Pull image on target if missing (only for API exec)
    Returns:
        Exit code (0 = success, non-zero = failure)
    """
    import sys
    assert workspace_id, "Workspace ID must be non-empty"
    assert command, "Command must be non-empty"
    workspace = get_workspace_raw(workspace_id)
    ssh_host = workspace.get("ssh_host")
    ssh_port = workspace.get("ssh_port")
    ssh_user = workspace.get("ssh_user", "root")  # Default to root for baremetal
    # Baremetal workspaces have SSH access - use SSH for stateful execution.
    # Exception: when routing is explicitly set (e.g. "gpu", "auto"), use the
    # exec API so the server can route the command to the correct container.
    # On NVIDIA workspaces the main container is CPU-only — GPU access requires
    # the exec API to dispatch to the GPU container.
    if ssh_host and ssh_port and not routing:
        return _exec_via_ssh(ssh_host, ssh_port, ssh_user, command, timeout_seconds)
    # Modal workspaces (no SSH) - use API exec
    # Modal Named Sandboxes persist state within their lifetime
    request_body, read_timeout = _build_exec_request(command, timeout_seconds, routing, pull_image)

    def handle_event(event: SSEEvent) -> None:
        if event.sync_event:
            _handle_sync_event(event.sync_event)
        elif event.output is not None:
            print(event.output, file=sys.stderr if event.is_error else sys.stdout)

    return _stream_exec_sse(workspace_id, request_body, read_timeout, handle_event)


def exec_command_capture(
    workspace_id: str,
    command: str,
    timeout_seconds: int | None = None,
    routing: str | None = None,
    pull_image: bool = False,
) -> tuple[int, str, str]:
    """Execute a command in workspace and capture output.
    Similar to exec_command but returns output as string instead of printing.
    Args:
        workspace_id: Workspace ID or name
        command: Command to execute
        timeout_seconds: Execution timeout (default: 300)
        routing: Routing hint - "auto", "gpu", "cpu", or "baremetal"
    Returns:
        Tuple of (exit_code, stdout, stderr)
    """
    assert workspace_id, "Workspace ID must be non-empty"
    assert command, "Command must be non-empty"

    # Baremetal workspaces have SSH access - prefer SSH for stateful execution.
    # Exception: when routing is explicitly set (e.g. "gpu", "auto"), use the
    # exec API so the server can route the command to the correct container.
    # On NVIDIA workspaces the main container is CPU-only — GPU access requires
    # the exec API to dispatch to the GPU container.
    workspace = get_workspace_raw(workspace_id)
    ssh_host = workspace.get("ssh_host")
    ssh_port = workspace.get("ssh_port")
    ssh_user = workspace.get("ssh_user", "root")  # Default to root for baremetal
    if ssh_host and ssh_port and not routing:
        return _exec_via_ssh_capture(ssh_host, ssh_port, ssh_user, command, timeout_seconds)

    # Modal workspaces (no SSH) or explicit routing requested - use API exec
    request_body, read_timeout = _build_exec_request(command, timeout_seconds, routing, pull_image)
    stdout_lines: list[str] = []
    stderr_lines: list[str] = []

    def handle_event(event: SSEEvent) -> None:
        if event.sync_event:
            return
        if event.output is not None:
            if event.is_error:
                stderr_lines.append(event.output)
            else:
                stdout_lines.append(event.output)

    exit_code = _stream_exec_sse(workspace_id, request_body, read_timeout, handle_event)
    return exit_code, "\n".join(stdout_lines), "\n".join(stderr_lines)
