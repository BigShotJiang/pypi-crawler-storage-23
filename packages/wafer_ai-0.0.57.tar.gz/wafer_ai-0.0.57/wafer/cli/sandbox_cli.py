"""Sandbox CLI: run commands on remote GPUs."""
from __future__ import annotations

import os
import shlex
from pathlib import Path
from typing import TYPE_CHECKING

import typer

if TYPE_CHECKING:
    from wafer.core.sandbox.session import SandboxSession
    from wafer.core.sandbox.types import Sandbox

sandbox_app = typer.Typer(
    name="sandbox",
    help="Run commands on remote GPUs",
    no_args_is_help=True,
)


def _get_ssh_creds(target_name: str) -> tuple[str, str]:
    """Load target and return (ssh_target, ssh_key)."""
    from wafer.cli.targets import load_target

    target = load_target(target_name)
    assert target.ssh_target, f"Target '{target_name}' has no SSH credentials"
    return target.ssh_target, target.ssh_key


def _resolve_ssh_target(target: str | None) -> tuple[str, str, str]:
    """Resolve target to SSH credentials. Errors if workspace (sandbox is SSH-only).
    Returns (target_name, ssh_target, ssh_key).
    """
    from wafer.cli.target_resolve import resolve_target

    target_name, kind = resolve_target(name=target)
    if kind == "workspace":
        typer.echo(
            f"Error: Sandbox only supports SSH targets. '{target_name}' is a workspace.\n"
            "  For workspaces: wafer target sync, wafer target ssh (interactive)\n"
            "  For sandbox:    wafer target init ssh --name <name> --host user@host:22",
            err=True,
        )
        raise typer.Exit(1) from None
    ssh_target, ssh_key = _get_ssh_creds(target_name)
    return target_name, ssh_target, ssh_key


def _run_async(async_fn):
    """Run an async function (not a coroutine) via trio with trio_asyncio bridge."""
    import trio
    import trio_asyncio

    async def _wrapper():
        async with trio_asyncio.open_loop():
            return await async_fn()

    return trio.run(_wrapper)


def _age_str(row: dict | None) -> str:
    """Format sandbox age from DB row or legacy metadata dict."""
    if not row:
        return "-"
    created_at = row.get("created_at")
    if not created_at:
        return "-"
    from datetime import datetime, timezone

    created = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
    delta = datetime.now(timezone.utc) - created
    hours = delta.total_seconds() / 3600
    if hours < 1:
        return f"{int(delta.total_seconds() / 60)}m"
    if hours < 24:
        return f"{hours:.1f}h"
    return f"{hours / 24:.1f}d"


@sandbox_app.command("create")
def sandbox_create(
    target: str | None = typer.Option(None, "--target", "-t", help="Target name (SSH host only)"),
    timeout: int = typer.Option(4, "--timeout-hours", help="Self-destruct timeout in hours"),
) -> None:
    """Create a new sandbox on a target"""
    from wafer.core.sandbox import SandboxSession, create_sandbox

    try:
        target_name, ssh_target, ssh_key = _resolve_ssh_target(target)
    except typer.Exit:
        raise
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None

    from wafer.cli.targets import load_target
    target_info = load_target(target_name)
    gpu_type = (target_info.gpu_type or "").lower() if hasattr(target_info, 'gpu_type') else ""
    gpu_vendor = "amd" if "mi" in gpu_type else "nvidia"
    gpu_count = len(target_info.gpu_ids) if hasattr(target_info, 'gpu_ids') and target_info.gpu_ids else 1
    sandbox = create_sandbox(target_name, ssh_target, ssh_key, timeout, gpu_vendor=gpu_vendor, gpu_count=gpu_count)

    async def _create():
        session = SandboxSession(sandbox)
        await session.start()

    _run_async(_create)
    from wafer.cli.sandboxes_api import db_register_sandbox
    db_register_sandbox(
        sandbox_id=sandbox.id,
        target_name=sandbox.target_name,
        tmux_session=sandbox.tmux_session,
        timeout_hours=sandbox.timeout_hours,
        created_at=sandbox.created_at,
    )
    typer.echo(
        f"Sandbox {sandbox.id} created on {target_name}. "
        f"Attach: wafer sandbox attach {sandbox.id} --target {target_name}"
    )


@sandbox_app.command("list")
def sandbox_list(
    target: str | None = typer.Option(None, "--target", "-t", help="Target name (SSH host only)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show extra details (tmp dir path)"),
) -> None:
    """List active sandboxes"""
    import json as json_mod

    from wafer.cli.sandboxes_api import db_list_active_sandboxes

    rows = db_list_active_sandboxes(target_name=target)

    if json_output:
        items = [
            {"id": r["id"], "target": r["target_name"], "status": "active",
             "age": _age_str(r), "tmp_dir": f"/tmp/.wafer_sandbox/wafer-{r['id']}"}
            if verbose
            else {"id": r["id"], "target": r["target_name"], "status": "active", "age": _age_str(r)}
            for r in rows
        ]
        typer.echo(json_mod.dumps({"sandboxes": items}))
        return

    if not rows:
        typer.echo("No sandboxes found.")
        return

    if verbose:
        typer.echo(f"{'ID':<40} {'TARGET':<22} {'STATUS':<8} {'AGE':<8} TMP_DIR")
        typer.echo(f"{'-'*40} {'-'*22} {'-'*8} {'-'*8} {'-'*40}")
        for r in rows:
            typer.echo(f"{r['id']:<40} {r['target_name']:<22} {'active':<8} {_age_str(r):<8} /tmp/.wafer_sandbox/wafer-{r['id']}")
    else:
        typer.echo(f"{'ID':<40} {'TARGET':<22} {'STATUS':<8} AGE")
        typer.echo(f"{'-'*40} {'-'*22} {'-'*8} {'-'*8}")
        for r in rows:
            typer.echo(f"{r['id']:<40} {r['target_name']:<22} {'active':<8} {_age_str(r)}")



@sandbox_app.command("attach")
def sandbox_attach(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID (e.g. sandbox-abc12345)"),
    target: str | None = typer.Option(None, "--target", "-t", help="Target name (SSH host only)"),
) -> None:
    """Attach to a sandbox session (interactive)"""
    from wafer.core.ssh_utils import parse_ssh_target

    try:
        target_name, ssh_target, ssh_key = _resolve_ssh_target(target)
    except typer.Exit:
        raise
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        typer.echo("Set default: wafer target default <name>", err=True)
        raise typer.Exit(1) from None
    parsed = parse_ssh_target(ssh_target)
    key_path = str(Path(ssh_key).expanduser().resolve())
    tmux_session = sandbox_id if sandbox_id.startswith("wafer-") else f"wafer-{sandbox_id}"
    from wafer.core.ssh_utils import ssh_mux_args

    os.execvp(
        "ssh",
        [
            "ssh",
            "-t",
            "-p", str(parsed.port),
            "-i", key_path,
            "-o", "StrictHostKeyChecking=no",
            "-o", "UserKnownHostsFile=/dev/null",
            *ssh_mux_args(),
            f"{parsed.user}@{parsed.host}",
            f"tmux attach -t {tmux_session}",
        ],
    )


@sandbox_app.command("delete")
def sandbox_delete(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID or 'all'"),
    target: str | None = typer.Option(None, "--target", "-t", help="Target name (SSH host only)"),
) -> None:
    """Delete a sandbox (or all with sandbox_id=all)"""
    from wafer.cli.sandboxes_api import db_destroy_sandbox, db_list_active_sandboxes
    from wafer.core.sandbox import destroy_all_sandboxes, destroy_sandbox

    try:
        target_name, ssh_target, ssh_key = _resolve_ssh_target(target)
    except typer.Exit:
        raise
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        typer.echo("Set default: wafer target default <name>", err=True)
        raise typer.Exit(1) from None
    if sandbox_id.lower() == "all":
        active = db_list_active_sandboxes(target_name=target_name)

        async def _destroy_all():
            return await destroy_all_sandboxes(ssh_target, ssh_key)

        count = _run_async(_destroy_all)
        for row in active:
            db_destroy_sandbox(row["id"])
        typer.echo(f"Destroyed {count} sandbox(es)")
    else:
        canon_id = sandbox_id.removeprefix("wafer-") if sandbox_id.startswith("wafer-") else sandbox_id
        tmux_session = sandbox_id if sandbox_id.startswith("wafer-") else f"wafer-{sandbox_id}"

        async def _destroy():
            await destroy_sandbox(ssh_target, ssh_key, tmux_session)

        _run_async(_destroy)
        db_destroy_sandbox(canon_id)
        typer.echo(f"Destroyed {sandbox_id}")


@sandbox_app.command("gc")
def sandbox_gc(
    target: str | None = typer.Option(None, "--target", "-t", help="Target name (SSH host only)"),
) -> None:
    """Garbage-collect expired sandboxes"""
    from datetime import datetime, timezone

    from wafer.cli.sandboxes_api import db_destroy_sandbox, db_list_active_sandboxes
    from wafer.core.sandbox import destroy_sandbox

    active = db_list_active_sandboxes(target_name=target)
    now = datetime.now(timezone.utc)
    expired = [
        r for r in active
        if datetime.fromisoformat(r["expires_at"].replace("Z", "+00:00")) <= now
    ]

    destroyed = 0
    for row in expired:
        try:
            target_name = row["target_name"]
            _, ssh_target, ssh_key = _resolve_ssh_target(target_name)

            async def _destroy(st=ssh_target, sk=ssh_key, ts=row["tmux_session"]):
                await destroy_sandbox(st, sk, ts)

            _run_async(_destroy)
        except Exception as e:
            typer.echo(f"Warning: failed to destroy {row['id']} on remote: {e}", err=True)
            continue
        db_destroy_sandbox(row["id"])
        destroyed += 1

    typer.echo(f"Destroyed {destroyed} expired sandbox(es)")


@sandbox_app.command("run")
def sandbox_run(
    command: list[str] = typer.Argument(..., help="Command to run"),
    target: str | None = typer.Option(None, "--target", "-t", help="Target name (SSH host only)"),
    sandbox_id: str | None = typer.Option(None, "--sandbox", "-s", help="Sandbox ID to run in (default: first available)"),
    sync_path: Path | None = typer.Option(None, "--sync", help="Path to sync before run"),
    cd_path: str | None = typer.Option(None, "--cd", help="Working directory for command (auto-set to /tmp/<folder> when --sync without --cd)"),
    timeout: int = typer.Option(300, "--timeout-sec", help="Command timeout in seconds (default: 300)"),
    idle_timeout: int = typer.Option(120, "--idle-timeout-sec", help="Kill command after N seconds of no output (default: 120)"),
) -> None:
    """Run a command in a sandbox (creates one if none exists)"""
    from wafer.cli.sandboxes_api import db_list_active_sandboxes, db_register_sandbox, db_touch_sandbox
    from wafer.cli.targets import load_target
    from wafer.cli.targets_ops import get_target_ssh_info, sync_to_target
    from wafer.core.sandbox import SandboxSession, create_sandbox
    from wafer.core.sandbox.manager import DEFAULT_TIMEOUT_HOURS
    from wafer.core.sandbox.types import Sandbox

    try:
        target_name, ssh_target, ssh_key = _resolve_ssh_target(target)
    except typer.Exit:
        raise
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None

    work_dir: str | None = cd_path
    if sync_path and sync_path.exists():
        t = load_target(target_name)

        async def _get_info():
            return await get_target_ssh_info(t)

        ssh_info = _run_async(_get_info)
        if work_dir is None:
            resolved = sync_path.resolve()
            if resolved.is_file():
                work_dir = "/tmp"
            else:
                assert resolved.name, f"Cannot derive remote dir from sync path: {sync_path}"
                work_dir = f"/tmp/{resolved.name}"
        sync_to_target(ssh_info, sync_path.resolve(), remote_path=work_dir)
        typer.echo(f"Synced to {ssh_info.host}:{work_dir}", err=True)

    cmd_str = shlex.join(command) if len(command) > 1 else (command[0] if command else "")
    if work_dir:
        cmd_str = f"cd {shlex.quote(work_dir)} && {cmd_str}"

    active_rows = db_list_active_sandboxes(target_name=target_name)
    created_new = False

    async def _run_in_sandbox():
        nonlocal created_new
        if sandbox_id:
            matching = [r for r in active_rows if r["id"] == sandbox_id or r["tmux_session"] == sandbox_id]
            assert matching, (
                f"Sandbox {sandbox_id} not found on {target_name}. "
                f"List sandboxes: wafer sandbox list --target {target_name}"
            )
            row = matching[0]
            sandbox = Sandbox(
                id=row["id"],
                target_name=target_name,
                tmux_session=row["tmux_session"],
                ssh_target=ssh_target,
                ssh_key=ssh_key,
                created_at=row["created_at"],
                timeout_hours=row["timeout_hours"],
            )
            sb = SandboxSession(sandbox)
            await sb.connect()
        elif active_rows:
            row = active_rows[0]
            sandbox = Sandbox(
                id=row["id"],
                target_name=target_name,
                tmux_session=row["tmux_session"],
                ssh_target=ssh_target,
                ssh_key=ssh_key,
                created_at=row["created_at"],
                timeout_hours=row["timeout_hours"],
            )
            sb = SandboxSession(sandbox)
            await sb.connect()
        else:
            from wafer.cli.targets import load_target as _load_target
            _target_info = _load_target(target_name)
            _gpu_type = (_target_info.gpu_type or "").lower() if hasattr(_target_info, 'gpu_type') else ""
            _gpu_vendor = "amd" if "mi" in _gpu_type else "nvidia"
            _gpu_count = len(_target_info.gpu_ids) if hasattr(_target_info, 'gpu_ids') and _target_info.gpu_ids else 1
            sandbox = create_sandbox(target_name, ssh_target, ssh_key, gpu_vendor=_gpu_vendor, gpu_count=_gpu_count)
            sb = SandboxSession(sandbox)
            await sb.start()
            created_new = True

        try:
            output, exit_code, _metadata = await sb.run_command(cmd_str, timeout, no_change_timeout=idle_timeout)
        finally:
            if sb._client is not None:
                await sb._client.close()

        return sandbox, output, exit_code

    sandbox, output, exit_code = _run_async(_run_in_sandbox)
    if created_new:
        db_register_sandbox(
            sandbox_id=sandbox.id,
            target_name=sandbox.target_name,
            tmux_session=sandbox.tmux_session,
            timeout_hours=sandbox.timeout_hours,
            created_at=sandbox.created_at,
        )
    db_touch_sandbox(sandbox.id, sandbox.timeout_hours)
    typer.echo(output)
    raise typer.Exit(exit_code if exit_code >= 0 else 1)


@sandbox_app.command("_heartbeat", hidden=True)
def sandbox_heartbeat_cmd(
    sandbox_id: str = typer.Option(..., help="Sandbox ID"),
    gpu_vendor: str = typer.Option("nvidia", help="GPU vendor (nvidia, amd, trainium)"),
    gpu_count: int = typer.Option(1, help="Number of GPUs"),
    queue_id: str | None = typer.Option(None, help="Queue entry ID (optional)"),
) -> None:
    """Internal: run heartbeat daemon for a sandbox."""
    from wafer.cli.sandbox_heartbeat import run_heartbeat

    run_heartbeat(sandbox_id, queue_id, gpu_vendor, gpu_count)

