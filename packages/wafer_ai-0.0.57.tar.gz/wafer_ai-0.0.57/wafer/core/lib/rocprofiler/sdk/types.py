"""Type definitions for ROCprofiler-SDK tool.

Follows Wafer-391: ROCprofiler Tools Architecture.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class CheckResult:
    """Result of checking rocprofv3 installation.

    Attributes:
        installed: Whether rocprofv3 is installed
        path: Path to rocprofv3 executable
        version: Version string if available
        install_command: Installation instructions if not installed
    """

    installed: bool
    path: str | None = None
    version: str | None = None
    install_command: str | None = None


@dataclass(frozen=True)
class ProfileResult:
    """Result of running rocprofv3 profiling.

    Attributes:
        success: Whether profiling completed successfully
        output_files: List of generated output file paths
        command: Command that was executed
        stdout: Standard output from rocprofv3
        stderr: Standard error from rocprofv3
        error: Error message if unsuccessful
    """

    success: bool
    output_files: list[str] | None = None
    command: list[str] | None = None
    stdout: str | None = None
    stderr: str | None = None
    error: str | None = None


@dataclass(frozen=True)
class KernelMetrics:
    """Metrics for a single kernel execution.

    Attributes:
        name: Kernel name
        duration_ns: Execution duration in nanoseconds
        grid_size: Grid dimensions (if available)
        block_size: Block dimensions (if available)
        registers_per_thread: Registers used per thread (if available)
        lds_per_workgroup: Local data share per workgroup in bytes (if available)
        vgprs: Number of vector GPRs used (if available)
        sgprs: Number of scalar GPRs used (if available)
    """

    name: str
    duration_ns: float | None = None
    grid_size: str | None = None
    block_size: str | None = None
    registers_per_thread: int | None = None
    lds_per_workgroup: int | None = None
    vgprs: int | None = None
    sgprs: int | None = None


@dataclass(frozen=True)
class AnalysisResult:
    """Result of analyzing rocprofiler output files.

    Attributes:
        success: Whether analysis completed successfully
        file_format: Detected file format ("csv", "json", "rocpd")
        kernels: List of kernel metrics
        summary: Summary statistics dictionary
        error: Error message if unsuccessful
    """

    success: bool
    file_format: str
    kernels: list[KernelMetrics] | None = None
    summary: dict | None = None
    error: str | None = None
