"""Shared SSH utilities. Single source of truth for SSH target parsing and mux options."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

_MUX_DIR = Path("/tmp/ssh-wafer-mux")


@dataclass(frozen=True)
class SSHTarget:
    """Parsed SSH target: user@host:port."""

    user: str
    host: str
    port: int

    def __str__(self) -> str:
        return f"{self.user}@{self.host}:{self.port}"


def parse_ssh_target(target: str) -> SSHTarget:
    """Parse 'user@host:port' -> SSHTarget. Single source of truth.

    Raises:
        ValueError: If format is invalid (missing @, missing :, or invalid port)
    """
    if not target or "@" not in target:
        raise ValueError(
            f"Invalid ssh_target format: {target!r}. Expected: user@host:port"
        )
    parts = target.rsplit(":", 1)
    if len(parts) < 2:
        raise ValueError(
            f"Invalid ssh_target format: {target!r}. Expected: user@host:port"
        )
    user_host, port_str = parts
    user, _, host = user_host.partition("@")
    if not user or not host:
        raise ValueError(
            f"Invalid ssh_target format: {target!r}. Expected: user@host:port"
        )
    if not port_str:
        raise ValueError(
            f"Invalid ssh_target format: {target!r}. Expected: user@host:port"
        )
    try:
        port = int(port_str)
    except ValueError as e:
        raise ValueError(f"Invalid port in ssh_target: {port_str!r}") from e
    return SSHTarget(user=user, host=host, port=port)


def ssh_mux_args() -> list[str]:
    """SSH ControlMaster multiplexing args — reuse one TCP connection across processes.

    Returns -o flags suitable for splicing into an ssh/rsync subprocess call.
    The first process to connect becomes the master; subsequent ones multiplex
    through its Unix socket. ControlPersist keeps it alive for 10 min after
    the last session closes.
    """
    _MUX_DIR.mkdir(mode=0o700, exist_ok=True)
    control_path = str(_MUX_DIR / "%r@%h-%p")
    return [
        "-o", "ControlMaster=auto",
        "-o", f"ControlPath={control_path}",
        "-o", "ControlPersist=600",
        "-o", "ServerAliveInterval=15",
        "-o", "ServerAliveCountMax=3",
    ]


def ssh_mux_opts() -> str:
    """Same as ssh_mux_args() but as a single string for rsync `-e` flags."""
    return " ".join(ssh_mux_args())
