"""Evaluation helpers.

Simple utilities for loading task datasets.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def load_tasks(tasks: list[dict[str, Any]] | Path | str) -> list[dict[str, Any]]:
    """Load tasks from list, Path, or string path.

    Supports:
    - list[dict]: Pass through directly
    - Path or str: Load from JSON file

    Returns the raw task list without normalization. Each task is a dict
    with whatever schema the user defines.
    """
    if isinstance(tasks, list):
        return tasks

    path = Path(tasks)
    with open(path) as f:
        return json.load(f)
