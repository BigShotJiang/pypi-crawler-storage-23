"""Wafer environments for agent execution."""

from wafer.core.environments.wafer_ai import WaferAiEnvironment

__all__ = ["WaferAiEnvironment"]
