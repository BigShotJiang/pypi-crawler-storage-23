from __future__ import annotations

from enum import Enum


class TaskUsage(Enum):
    RestApi = "RestApi"
    Repository = "Repository"
    MetadataApi = "MetadataApi"
    TsmApi = "TsmApi"
    VizPortal = "VizPortal"
