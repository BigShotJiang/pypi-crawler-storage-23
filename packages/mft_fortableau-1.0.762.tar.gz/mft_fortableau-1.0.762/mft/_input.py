from __future__ import annotations

import datetime
import uuid
from collections.abc import Iterator

from mft.parameterfile.parameter_file import ParameterFile
from mft.parameterfile.parameter_info_dto import ParameterInfoDTO
from mft.parameterfile.parameter_object_handler import ParameterObjectHandler


class Input:
    """Read-only wrapper over a binary ParameterFile with typed convenience getters."""

    def __init__(self, file_path: str, parameters: list[ParameterInfoDTO]) -> None:
        self._file_path = file_path
        self._parameters = parameters
        self._file: ParameterFile | None = None
        self._stream = None

    def open(self) -> Input:
        self._stream = open(self._file_path, "r+b")
        self._file = ParameterFile.open_file(self._stream, self._parameters, True)
        return self

    def close(self) -> None:
        if self._file is not None:
            self._file.close()
            self._file = None

    def __enter__(self) -> Input:
        return self.open()

    def __exit__(self, *args: object) -> None:
        self.close()

    @property
    def handler(self) -> ParameterObjectHandler:
        """Access the underlying root handler for advanced operations."""
        if self._file is None or self._file.root_object is None:
            raise RuntimeError("ParameterFile is not open. Call open() or use a context manager first.")
        return self._file.root_object

    # -- String ----------------------------------------------------------------

    def get_string(self, param_id: str) -> str | None:
        return self.handler.get_string(param_id)

    def get_string_list(self, param_id: str) -> list[str]:
        return list(self.handler.get_string_list(param_id))

    # -- Integer ---------------------------------------------------------------

    def get_integer(self, param_id: str) -> int | None:
        return self.handler.get_integer(param_id)

    def get_integer_list(self, param_id: str) -> list[int]:
        return list(self.handler.get_integer_list(param_id))

    # -- Double ----------------------------------------------------------------

    def get_double(self, param_id: str) -> float | None:
        return self.handler.get_double(param_id)

    def get_double_list(self, param_id: str) -> list[float]:
        return list(self.handler.get_double_list(param_id))

    # -- Boolean ---------------------------------------------------------------

    def get_boolean(self, param_id: str) -> bool | None:
        return self.handler.get_boolean(param_id)

    def get_boolean_list(self, param_id: str) -> list[bool]:
        return list(self.handler.get_boolean_list(param_id))

    # -- Date ------------------------------------------------------------------

    def get_date(self, param_id: str) -> datetime.date | None:
        return self.handler.get_date(param_id)

    def get_date_list(self, param_id: str) -> list[datetime.date]:
        return list(self.handler.get_date_list(param_id))

    # -- DateTime --------------------------------------------------------------

    def get_datetime(self, param_id: str) -> datetime.datetime | None:
        return self.handler.get_datetime(param_id)

    def get_datetime_list(self, param_id: str) -> list[datetime.datetime]:
        return list(self.handler.get_datetime_list(param_id))

    # -- TimeSpan --------------------------------------------------------------

    def get_timespan(self, param_id: str) -> datetime.timedelta | None:
        return self.handler.get_timespan(param_id)

    def get_timespan_list(self, param_id: str) -> list[datetime.timedelta]:
        return list(self.handler.get_timespan_list(param_id))

    # -- Guid ------------------------------------------------------------------

    def get_guid(self, param_id: str) -> uuid.UUID | None:
        return self.handler.get_guid(param_id)

    def get_guid_list(self, param_id: str) -> list[uuid.UUID]:
        return list(self.handler.get_guid_list(param_id))

    # -- Enum ------------------------------------------------------------------

    def get_enum(self, param_id: str) -> str | None:
        return self.handler.get_enum(param_id)

    def get_enum_list(self, param_id: str) -> list[str]:
        return list(self.handler.get_enum_list(param_id))

    # -- Binary ----------------------------------------------------------------

    def get_binary(self, param_id: str) -> bytes | None:
        return self.handler.get_binary(param_id)

    def get_binary_list(self, param_id: str) -> list[bytes]:
        return list(self.handler.get_binary_list(param_id))

    # -- Object ----------------------------------------------------------------

    def get_object(self, param_id: str) -> ParameterObjectHandler | None:
        return self.handler.get_object(param_id)

    def get_objects(self, param_id: str) -> Iterator[ParameterObjectHandler]:
        yield from self.handler.get_objects(param_id)
