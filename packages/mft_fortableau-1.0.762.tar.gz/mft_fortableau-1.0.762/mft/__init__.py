# MFT - Manager for Tableau Custom Task Framework
from mft._core import MFT

__version__ = "1.0.762"
__all__ = ["MFT"]
