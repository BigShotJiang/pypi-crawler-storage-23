from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from mft._tm_client import RepositoryCredentials

logger = logging.getLogger(__name__)

try:
    import psycopg2
except ImportError:
    psycopg2 = None  # type: ignore[assignment]

if TYPE_CHECKING:
    from psycopg2.extensions import connection as _PgConnection


class Repository:
    """Read-only client for the Tableau Repository (PostgreSQL).

    Provides two convenience methods for running queries:

    - :meth:`execute` -- returns rows as a list of tuples.
    - :meth:`execute_dict` -- returns rows as a list of dicts keyed by
      column name.

    The connection is opened with ``default_transaction_read_only=on``,
    so all queries are guaranteed read-only at the database level.

    The session is managed by MFT -- :meth:`connect` and :meth:`disconnect`
    are called automatically.  Custom-task code only needs the query methods.

    Example::

        mft = MFT.init()
        rows = mft.repository.execute("SELECT * FROM _workbooks LIMIT 10")
        dicts = mft.repository.execute_dict(
            "SELECT id, name FROM _workbooks WHERE owner_id = %s",
            (owner_id,),
        )

    For advanced use cases (server-side cursors, COPY, etc.) the raw
    ``psycopg2`` connection is available via the :attr:`connection` property.

    Tip: access via ``mft.repository`` -- requires ``"Repository"`` in
    the ``uses`` list of your ``task-meta.json``.
    """

    def __init__(self, credentials: RepositoryCredentials) -> None:
        self._credentials = credentials
        self._connection: _PgConnection | None = None

    # -- lifecycle ------------------------------------------------------------

    def connect(self) -> Repository:
        """Open a read-only connection to the Tableau Repository.

        Returns *self* for chaining.

        Raises
        ------
        ImportError
            If ``psycopg2`` is not installed.
        """
        if psycopg2 is None:
            raise ImportError(
                "psycopg2 is required for Repository. "
                "Install it with: pip install psycopg2-binary"
            )

        self._connection = psycopg2.connect(
            host=self._credentials.host,
            port=self._credentials.port,
            database=self._credentials.database,
            user=self._credentials.username,
            password=self._credentials.password,
            sslmode="prefer",
            options="-c default_transaction_read_only=on",
        )
        logger.debug(
            "Connected to Repository at %s:%s/%s",
            self._credentials.host,
            self._credentials.port,
            self._credentials.database,
        )
        return self

    @property
    def connection(self) -> _PgConnection | None:
        """The underlying ``psycopg2`` connection, or *None* before connect.

        This is intended for advanced use cases such as server-side
        cursors, ``COPY`` operations, or any scenario where the
        convenience methods are not sufficient.  For routine queries,
        prefer :meth:`execute` or :meth:`execute_dict`.
        """
        return self._connection

    def disconnect(self) -> None:
        """Close the database connection."""
        if self._connection is not None:
            self._connection.close()
            self._connection = None
            logger.debug("Disconnected from Repository")

    # -- query helpers --------------------------------------------------------

    def _ensure_connected(self) -> _PgConnection:
        """Return the active connection or raise if not connected."""
        if self._connection is None:
            raise RuntimeError(
                "Repository is not connected. Call connect() first."
            )
        return self._connection

    def execute(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | dict[str, Any] | None = None,
    ) -> list[tuple[Any, ...]]:
        """Execute a read-only SQL query and return all rows as tuples.

        Example::

            rows = mft.repository.execute(
                "SELECT name, owner_id FROM _workbooks WHERE site_id = %s",
                (site_id,),
            )
            for name, owner_id in rows:
                print(name, owner_id)

        Parameters
        ----------
        query:
            SQL query string. Use ``%s`` placeholders for parameters.
        params:
            Optional query parameters (tuple, list, or dict). Always use
            parameterized queries instead of string formatting to prevent
            SQL injection.

        Returns
        -------
        list[tuple[Any, ...]]
            Each row as a tuple of column values.

        Raises
        ------
        RuntimeError
            If the repository is not connected.
        """
        conn = self._ensure_connected()
        cursor = conn.cursor()
        try:
            cursor.execute(query, params)
            return cursor.fetchall()
        finally:
            cursor.close()

    def execute_dict(
        self,
        query: str,
        params: tuple[Any, ...] | list[Any] | dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Execute a read-only SQL query and return all rows as dicts.

        Each dict is keyed by column name from the query result.

        Example::

            users = mft.repository.execute_dict(
                "SELECT id, name, email FROM _users WHERE site_id = %s",
                (site_id,),
            )
            for user in users:
                print(user["name"], user["email"])

        Parameters
        ----------
        query:
            SQL query string. Use ``%s`` placeholders for parameters.
        params:
            Optional query parameters (tuple, list, or dict). Always use
            parameterized queries instead of string formatting to prevent
            SQL injection.

        Returns
        -------
        list[dict[str, Any]]
            Each row as a dict mapping column names to values.

        Raises
        ------
        RuntimeError
            If the repository is not connected.
        """
        conn = self._ensure_connected()
        cursor = conn.cursor()
        try:
            cursor.execute(query, params)
            columns = [desc[0] for desc in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]
        finally:
            cursor.close()
