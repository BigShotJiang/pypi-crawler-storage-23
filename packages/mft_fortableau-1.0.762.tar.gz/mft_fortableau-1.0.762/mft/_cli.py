"""Command-line interface for MFT custom task utilities.

Provides four subcommands for developing and packaging custom tasks:

- ``mft validate-meta`` -- validate ``task-meta.json`` and print a summary.
- ``mft generate-input`` -- generate a sample ``input.json`` from task metadata.
- ``mft validate-input`` -- validate ``input.json`` against task metadata.
- ``mft package`` -- package the task into a ``.mft`` ZIP archive.

The entry point is registered in ``pyproject.toml`` as::

    [project.scripts]
    mft = "mft._cli:main"

Usage examples::

    # Validate (auto-detect task-meta.json in ./src/ or ./)
    mft validate-meta

    # Validate a specific file
    mft validate-meta path/to/task-meta.json

    # Generate a sample input file (default output: ./dev-files/input.json)
    mft generate-input

    # Generate with explicit paths
    mft generate-input path/to/task-meta.json ./my-input.json

    # Validate the input file against metadata
    mft validate-input

    # Validate with explicit paths
    mft validate-input ./dev-files/input.json path/to/task-meta.json

    # Package the current directory into a .mft archive
    mft package

    # Package with a custom output filename
    mft package my_task.mft
"""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys
import zipfile
from pathlib import Path
from typing import Any

from mft._meta import load_task_meta
from mft.models.parameter_info import ParameterInfo
from mft.models.task_meta import TaskMeta
from mft.parameterfile.parameter_info_dto import ParameterType

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Package exclusion rules
# ---------------------------------------------------------------------------

# Any path component matching one of these names causes the file to be
# skipped.  Directories ending with ".egg-info" are also excluded
# (checked separately since the suffix varies by package name).
_PACKAGE_EXCLUDE_DIRS: frozenset[str] = frozenset({
    ".devcontainer", ".git", ".github", ".vscode",
    "dev-files", "docs", "__pycache__",
    ".mypy_cache", ".pytest_cache", ".tox", ".nox",
    "node_modules", ".eggs",
})

_PACKAGE_EXCLUDE_EXTENSIONS: frozenset[str] = frozenset({
    ".mft", ".parameterFile", ".pyc", ".pyo",
})

# Exact filenames excluded to prevent accidental inclusion of secrets.
_PACKAGE_EXCLUDE_FILES: frozenset[str] = frozenset({
    "credentials.json", "secrets.json",
    ".gitignore", ".dockerignore",
    ".mft_token",
})

# Filename prefixes excluded to catch all .env variants
# (.env, .env.local, .env.production, .env.staging, etc.).
_PACKAGE_EXCLUDE_PREFIXES: tuple[str, ...] = (".env",)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Entry point for the ``mft`` CLI.

    Parses command-line arguments and dispatches to the appropriate
    subcommand handler.  When invoked without a subcommand, prints help
    text and exits with code 1.

    Exit codes:

    - **0** -- command completed successfully.
    - **1** -- user error (invalid input, missing file, validation failure).
    - **130** -- interrupted by Ctrl+C (``KeyboardInterrupt``).

    This function is registered as the ``mft`` console script entry point
    in ``pyproject.toml``.  It is called directly by the shell when a user
    runs ``mft <command>``.

    Example::

        # From the command line:
        mft validate-meta
        mft generate-input ./src/task-meta.json ./dev-files/input.json
        mft package my_task.mft
    """
    parser = argparse.ArgumentParser(
        prog="mft",
        description="Manager for Tableau - custom workflow task utilities",
    )
    subparsers = parser.add_subparsers(dest="command", help="available commands")

    # --- validate-meta ---
    p_validate = subparsers.add_parser(
        "validate-meta",
        help="validate a task-meta.json file and print a summary",
    )
    p_validate.add_argument(
        "path",
        nargs="?",
        default=None,
        help="path to task-meta.json (auto-detected if omitted)",
    )
    p_validate.set_defaults(func=_cmd_validate_meta)

    # --- generate-input ---
    p_geninput = subparsers.add_parser(
        "generate-input",
        help="generate a sample input JSON file from task-meta.json",
    )
    p_geninput.add_argument(
        "meta_path",
        nargs="?",
        default=None,
        help="path to task-meta.json (auto-detected if omitted)",
    )
    p_geninput.add_argument(
        "output_path",
        nargs="?",
        default="./dev-files/input.json",
        help="output file path (default: ./dev-files/input.json)",
    )
    p_geninput.set_defaults(func=_cmd_generate_input)

    # --- validate-input ---
    p_valinput = subparsers.add_parser(
        "validate-input",
        help="validate an input JSON file against task-meta.json",
    )
    p_valinput.add_argument(
        "input_path",
        nargs="?",
        default="./dev-files/input.json",
        help="path to input JSON file (default: ./dev-files/input.json)",
    )
    p_valinput.add_argument(
        "meta_path",
        nargs="?",
        default=None,
        help="path to task-meta.json (auto-detected if omitted)",
    )
    p_valinput.set_defaults(func=_cmd_validate_input)

    # --- package ---
    p_package = subparsers.add_parser(
        "package",
        help="package the task into a .mft archive",
    )
    p_package.add_argument(
        "output_name",
        nargs="?",
        default=None,
        help="output filename (default: derived from display_name)",
    )
    p_package.set_defaults(func=_cmd_package)

    try:
        args = parser.parse_args()
        if args.command is None:
            parser.print_help()
            sys.exit(1)
        args.func(args)
    except KeyboardInterrupt:
        sys.exit(130)


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------


def _cmd_validate_meta(args: argparse.Namespace) -> None:
    """Validate ``task-meta.json`` and print a human-readable summary.

    Loads the metadata file (from the explicit *path* argument or by
    auto-detecting ``./src/task-meta.json`` / ``./task-meta.json``),
    validates it, and prints a summary of the task definition including
    display name, description, group, input/output counts, and declared
    service usages.

    Parameters
    ----------
    args:
        Parsed CLI arguments.  Expected attributes:

        - ``path`` (str | None): explicit path to ``task-meta.json``,
          or *None* to auto-detect.

    Raises
    ------
    SystemExit
        Code 0 on success, code 1 if the file is missing or invalid.
    """
    meta = _load_meta_or_exit(args.path)

    uses_str = ", ".join(u.name for u in meta.uses) if meta.uses else "(none)"
    description = meta.description or "(none)"
    group_index_str = str(meta.group_index) if meta.group_index is not None else "(none)"
    version_desc = meta.version_description or "(none)"

    print(f"Task: {meta.display_name}")
    print(f"Description: {description}")
    print(f"Group: {meta.group} (index {group_index_str})")
    print(f"Version: {meta.major_version}")
    print(f"Version description: {version_desc}")
    print(f"Inputs: {len(meta.inputs)}")
    print(f"Outputs: {len(meta.outputs)}")
    print(f"Uses: {uses_str}")
    sys.exit(0)


def _cmd_generate_input(args: argparse.Namespace) -> None:
    """Generate a sample ``input.json`` template from task metadata.

    Reads the ``inputs`` section of ``task-meta.json`` and produces a JSON
    file with placeholder values matching the converter's expected format.
    String-based values use ``TODO:`` markers so the developer knows where
    to fill in real data.  Non-string types use type-appropriate defaults
    (``0``, ``false``, etc.) that are valid but clearly need replacing.

    After writing the file, prints a parameter guide to stdout listing
    every input parameter with its type, whether it is required, and any
    additional context (enum values, nested object structure).

    Parameters
    ----------
    args:
        Parsed CLI arguments.  Expected attributes:

        - ``meta_path`` (str | None): explicit path to ``task-meta.json``,
          or *None* to auto-detect.
        - ``output_path`` (str): path for the generated JSON file.
          Defaults to ``./dev-files/input.json``.

    Raises
    ------
    SystemExit
        Code 0 on success, code 1 if the metadata file is missing/invalid
        or the output file cannot be written.
    """
    meta = _load_meta_or_exit(args.meta_path)

    template: dict[str, Any] = {}
    for param in meta.inputs:
        template[param.id] = _generate_template_value(param)

    output_path = Path(args.output_path)
    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as fh:
            json.dump(template, fh, indent=2)
            fh.write("\n")
    except OSError as exc:
        print(f"Failed to write output file: {exc}", file=sys.stderr)
        sys.exit(1)

    print(f"Generated input template: {output_path}")
    print()
    print("This file contains a JSON template based on your task metadata inputs.")
    print("Replace all TODO and placeholder values with your actual data before")
    print("running the task in dev mode.")
    print()
    print("Parameters to fill in:")
    for param in meta.inputs:
        _print_param_guide(param, indent=2)
    sys.exit(0)


def _cmd_validate_input(args: argparse.Namespace) -> None:
    """Validate an ``input.json`` file against task metadata definitions.

    Loads the metadata and input JSON, runs all type/format/presence
    checks, and prints errors and warnings.  Exits with code 0 when
    valid, code 1 when there are errors.

    Parameters
    ----------
    args:
        Parsed CLI arguments.  Expected attributes:

        - ``input_path`` (str): path to the input JSON file.
          Defaults to ``./dev-files/input.json``.
        - ``meta_path`` (str | None): explicit path to ``task-meta.json``,
          or *None* to auto-detect.

    Raises
    ------
    SystemExit
        Code 0 on success, code 1 if validation fails or files are
        missing/unreadable.
    """
    from mft._validate_input import validate_input

    meta = _load_meta_or_exit(args.meta_path)

    input_path = Path(args.input_path)
    if not input_path.exists():
        print(f"Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    try:
        with open(input_path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except json.JSONDecodeError as exc:
        print(f"Invalid JSON in {input_path}: {exc}", file=sys.stderr)
        sys.exit(1)

    if not isinstance(data, dict):
        print(
            f"Input file must contain a JSON object, got {type(data).__name__}",
            file=sys.stderr,
        )
        sys.exit(1)

    result = validate_input(data, meta.inputs)

    if result.warnings:
        for warning in result.warnings:
            print(f"  WARNING: {warning}")
        print()

    if result.errors:
        print(f"Validation failed with {len(result.errors)} error(s):")
        for error in result.errors:
            print(f"  ERROR: {error}")
        sys.exit(1)

    print("Input validation passed.")
    sys.exit(0)


def _cmd_package(args: argparse.Namespace) -> None:
    """Package the current task directory into a ``.mft`` ZIP archive.

    The archive contains the files the MFT engine needs to build the
    Docker container and run the custom task:

    - ``task-meta.json`` -- task definition (from ``./src/`` or ``./``).
    - ``main.py`` -- task entry point (from project root).
    - ``requirements.txt`` -- pip dependencies (from ``./src/`` or ``./``).
    - Additional ``.py`` files and directories from the project root
      and ``src/`` -- for multi-file tasks with helper modules.

    Excluded directories: ``.devcontainer``, ``.git``, ``dev-files``,
    ``docs``, ``__pycache__``, and other non-runtime directories.

    ``task-meta.json`` and ``requirements.txt`` are always placed at the
    archive root regardless of their source location.  All other files
    preserve their relative paths from the project root.

    The output filename defaults to a snake_case version of the task's
    ``display_name`` with a ``.mft`` extension (e.g. ``"My Task"`` becomes
    ``my_task.mft``).  A custom filename can be provided as a positional
    argument.

    Parameters
    ----------
    args:
        Parsed CLI arguments.  Expected attributes:

        - ``output_name`` (str | None): custom output filename, or *None*
          to derive from the task's ``display_name``.

    Raises
    ------
    SystemExit
        Code 0 on success, code 1 if metadata is invalid, ``task-meta.json``
        cannot be found, or the archive cannot be written.
    """
    # Validate metadata first -- catches schema errors before creating files.
    meta = _load_meta_or_exit(None)

    output_name: str = args.output_name or (
        _display_name_to_snake(meta.display_name) + ".mft"
    )

    # Locate the physical task-meta.json file for inclusion in the archive.
    meta_file = _find_meta_file()
    if meta_file is None:
        print("Cannot find task-meta.json in ./src/ or ./", file=sys.stderr)
        sys.exit(1)

    included: list[str] = []
    added_arcnames: set[str] = set()
    cwd = Path.cwd()
    output_path = (cwd / output_name).resolve()

    try:
        with zipfile.ZipFile(output_name, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            # task-meta.json -- always at archive root regardless of source location
            zf.write(meta_file, "task-meta.json")
            included.append("task-meta.json")
            added_arcnames.add("task-meta.json")

            # main.py -- task entry point
            main_file = cwd / "main.py"
            if main_file.is_file():
                zf.write(main_file, "main.py")
                included.append("main.py")
                added_arcnames.add("main.py")

            # requirements.txt -- check src/ first, then project root
            req_file = cwd / "src" / "requirements.txt"
            if not req_file.is_file():
                req_file = cwd / "requirements.txt"
            if req_file.is_file():
                zf.write(req_file, "requirements.txt")
                included.append("requirements.txt")
                added_arcnames.add("requirements.txt")

            # Additional source files -- .py files at root and all files
            # under src/ (excluding already-added files and ignored dirs)
            for file in sorted(cwd.rglob("*")):
                if not file.is_file():
                    continue

                # Skip symlinks — prevent path traversal outside project
                if file.is_symlink():
                    continue

                rel = file.relative_to(cwd)
                arcname = rel.as_posix()

                # Skip already-added files
                if arcname in added_arcnames:
                    continue

                # Skip files that were promoted to the archive root
                # (task-meta.json, requirements.txt sourced from src/)
                if file == meta_file or file == req_file:
                    continue

                # Skip the output archive itself
                if file.resolve() == output_path:
                    continue

                # Skip excluded directories
                parts = rel.parts
                if any(p in _PACKAGE_EXCLUDE_DIRS for p in parts):
                    continue
                if any(p.endswith(".egg-info") for p in parts):
                    continue

                # Skip excluded extensions, filenames, and prefixes
                if file.suffix in _PACKAGE_EXCLUDE_EXTENSIONS:
                    continue
                if file.name in _PACKAGE_EXCLUDE_FILES:
                    continue
                if any(file.name.startswith(p) for p in _PACKAGE_EXCLUDE_PREFIXES):
                    continue

                # Root-level: only include .py files
                # Subdirectories (src/, etc.): include all files
                if len(parts) == 1 and file.suffix != ".py":
                    continue

                zf.write(file, arcname)
                included.append(arcname)
                added_arcnames.add(arcname)
    except OSError as exc:
        print(f"Failed to create archive: {exc}", file=sys.stderr)
        sys.exit(1)

    print(f"Packaged: {output_name}")
    for name in included:
        print(f"  {name}")
    sys.exit(0)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _load_meta_or_exit(meta_path: str | Path | None) -> TaskMeta:
    """Load and validate ``task-meta.json``, or print an error and exit.

    This is a convenience wrapper around :func:`~mft._meta.load_task_meta`
    that converts its exceptions into user-friendly stderr messages and
    ``sys.exit(1)`` calls.  Used by every subcommand to avoid repeating
    the same try/except boilerplate.

    Parameters
    ----------
    meta_path:
        Explicit path to ``task-meta.json``, or *None* to auto-detect
        from ``./src/task-meta.json`` or ``./task-meta.json``.

    Returns
    -------
    TaskMeta
        The validated task metadata.

    Raises
    ------
    SystemExit
        Code 1 if the file is not found or fails validation.
    """
    try:
        return load_task_meta(meta_path)
    except FileNotFoundError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)


def _find_meta_file() -> Path | None:
    """Locate the physical ``task-meta.json`` file in the current directory.

    Searches ``./src/task-meta.json`` first, then ``./task-meta.json``.
    Returns the first match or *None* if neither exists.

    Returns
    -------
    Path | None
        Path to the found file, or *None*.
    """
    cwd = Path.cwd()
    for candidate in (cwd / "src" / "task-meta.json", cwd / "task-meta.json"):
        if candidate.is_file():
            return candidate
    return None


def _generate_template_value(param: ParameterInfo) -> Any:
    """Build a placeholder value for *param* matching the converter format.

    Produces values that are structurally valid so the generated JSON file
    can be loaded without errors, while making it obvious which values need
    replacing:

    - **String-based types** (String, Date, DateTime, TimeSpan, Guid,
      Binary) get a ``TODO:`` prefixed marker string.
    - **Numeric types** (Integer, Double) get ``0`` / ``0.0``.
    - **Boolean** gets ``false``.
    - **Enum** gets the first declared enum value (or ``""`` if none).
    - **Object** is built recursively from its ``object_properties``.

    When ``param.is_list`` is *True*, the single value is wrapped in a
    one-element list.

    Parameters
    ----------
    param:
        The parameter definition from task metadata.

    Returns
    -------
    Any
        A JSON-serializable placeholder value: ``str``, ``int``, ``float``,
        ``bool``, ``dict``, or ``list`` depending on the parameter type.

    Example::

        param = ParameterInfo(id="url", display_name="URL",
                              type=ParameterType.String, required=True)
        value = _generate_template_value(param)
        # "TODO: Enter URL (String, required)"
    """
    req = ", required" if param.required else ""
    label = param.display_name or param.id

    value: Any

    if param.type == ParameterType.String:
        value = f"TODO: Enter {label} (String{req})"
    elif param.type == ParameterType.Integer:
        value = 0
    elif param.type == ParameterType.Double:
        value = 0.0
    elif param.type == ParameterType.Boolean:
        value = False
    elif param.type == ParameterType.Date:
        value = "TODO: Enter date YYYY-MM-DD"
    elif param.type == ParameterType.DateTime:
        value = "TODO: Enter datetime YYYY-MM-DDTHH:MM:SS"
    elif param.type == ParameterType.TimeSpan:
        value = "TODO: Enter timespan HH:MM:SS"
    elif param.type == ParameterType.Guid:
        value = "TODO: Enter GUID 00000000-0000-0000-0000-000000000000"
    elif param.type == ParameterType.Enum:
        if param.enum_values:
            value = param.enum_values[0]
        else:
            value = ""
    elif param.type == ParameterType.Binary:
        value = "TODO: Enter base64-encoded data"
    elif param.type == ParameterType.Object:
        value = {}
        if param.object_properties:
            for prop in param.object_properties:
                value[prop.id] = _generate_template_value(prop)
    else:
        value = ""

    if param.is_list:
        return [value]
    return value


def _print_param_guide(param: ParameterInfo, *, indent: int = 0) -> None:
    """Print a single-line parameter guide entry to stdout.

    Formats the parameter as a bullet point showing its id, type,
    list/required markers, display name, description, and (for enums)
    the allowed values.  Object parameters recursively print their
    nested properties with increased indentation.

    Parameters
    ----------
    param:
        The parameter definition to describe.
    indent:
        Number of leading spaces for indentation.  Increased by 4 for
        each level of object nesting.
    """
    prefix = " " * indent
    req = " (required)" if param.required else ""
    type_name = param.type.name
    list_suffix = "[]" if param.is_list else ""

    extra = ""
    if param.type == ParameterType.Enum and param.enum_values:
        extra = f" — values: {', '.join(param.enum_values)}"

    desc = f" — {param.description}" if param.description else ""

    print(f"{prefix}- {param.id} ({type_name}{list_suffix}{req}): "
          f"{param.display_name}{desc}{extra}")

    if param.type == ParameterType.Object and param.object_properties:
        for prop in param.object_properties:
            _print_param_guide(prop, indent=indent + 4)


def _display_name_to_snake(name: str) -> str:
    """Convert a display name to a snake_case filename stem.

    Applies the following transformations in order:

    1. Lowercase the entire string.
    2. Replace whitespace and hyphens with underscores.
    3. Strip characters that are not alphanumeric or underscore.
    4. Collapse consecutive underscores.
    5. Strip leading/trailing underscores.

    Parameters
    ----------
    name:
        The human-readable display name (e.g. ``"My Custom Task"``).

    Returns
    -------
    str
        A filesystem-safe snake_case string (e.g. ``"my_custom_task"``).

    Example::

        _display_name_to_snake("My Custom Task")   # "my_custom_task"
        _display_name_to_snake("Hello--World 2.0")  # "hello_world_20"
        _display_name_to_snake("  Trim Me  ")       # "trim_me"
    """
    result = name.lower()
    result = re.sub(r"[\s\-]+", "_", result)
    result = re.sub(r"[^a-z0-9_]", "", result)
    result = re.sub(r"_+", "_", result)
    result = result.strip("_")
    return result
