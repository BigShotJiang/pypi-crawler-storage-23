from __future__ import annotations

import datetime
import uuid
from collections.abc import Callable

from mft.parameterfile.parameter_file import ParameterFile
from mft.parameterfile.parameter_info_dto import ParameterInfoDTO
from mft.parameterfile.parameter_object_handler import ParameterObjectHandler


class Output:
    """Write wrapper over a binary ParameterFile with typed convenience setters."""

    def __init__(self, file_path: str, parameters: list[ParameterInfoDTO]) -> None:
        self._file_path = file_path
        self._parameters = parameters
        self._file: ParameterFile | None = None
        self._stream = None

    def open(self) -> Output:
        self._stream = open(self._file_path, "w+b")
        self._file = ParameterFile.create(self._stream, self._parameters, True)
        return self

    def close(self) -> None:
        if self._file is not None:
            self._file.close()
            self._file = None

    def __enter__(self) -> Output:
        return self.open()

    def __exit__(self, *args: object) -> None:
        self.close()

    @property
    def handler(self) -> ParameterObjectHandler:
        """Access the underlying root handler for advanced operations."""
        if self._file is None or self._file.root_object is None:
            raise RuntimeError("ParameterFile is not open. Call open() or use a context manager first.")
        return self._file.root_object

    # -- String ----------------------------------------------------------------

    def set_string(self, param_id: str, value: str) -> None:
        self.handler.set_string(param_id, value)

    def set_string_list(self, param_id: str, values: list[str]) -> None:
        self.handler.set_string_list(param_id, values)

    # -- Integer ---------------------------------------------------------------

    def set_integer(self, param_id: str, value: int) -> None:
        self.handler.set_integer(param_id, value)

    def set_integer_list(self, param_id: str, values: list[int]) -> None:
        self.handler.set_integer_list(param_id, values)

    # -- Double ----------------------------------------------------------------

    def set_double(self, param_id: str, value: float) -> None:
        self.handler.set_double(param_id, value)

    def set_double_list(self, param_id: str, values: list[float]) -> None:
        self.handler.set_double_list(param_id, values)

    # -- Boolean ---------------------------------------------------------------

    def set_boolean(self, param_id: str, value: bool) -> None:
        self.handler.set_boolean(param_id, value)

    def set_boolean_list(self, param_id: str, values: list[bool]) -> None:
        self.handler.set_boolean_list(param_id, values)

    # -- Date ------------------------------------------------------------------

    def set_date(self, param_id: str, value: datetime.date) -> None:
        self.handler.set_date(param_id, value)

    def set_date_list(self, param_id: str, values: list[datetime.date]) -> None:
        self.handler.set_date_list(param_id, values)

    # -- DateTime --------------------------------------------------------------

    def set_datetime(self, param_id: str, value: datetime.datetime) -> None:
        self.handler.set_datetime(param_id, value)

    def set_datetime_list(self, param_id: str, values: list[datetime.datetime]) -> None:
        self.handler.set_datetime_list(param_id, values)

    # -- TimeSpan --------------------------------------------------------------

    def set_timespan(self, param_id: str, value: datetime.timedelta) -> None:
        self.handler.set_timespan(param_id, value)

    def set_timespan_list(self, param_id: str, values: list[datetime.timedelta]) -> None:
        self.handler.set_timespan_list(param_id, values)

    # -- Guid ------------------------------------------------------------------

    def set_guid(self, param_id: str, value: uuid.UUID) -> None:
        self.handler.set_guid(param_id, value)

    def set_guid_list(self, param_id: str, values: list[uuid.UUID]) -> None:
        self.handler.set_guid_list(param_id, values)

    # -- Enum ------------------------------------------------------------------

    def set_enum(self, param_id: str, value: str) -> None:
        self.handler.set_enum(param_id, value)

    def set_enum_list(self, param_id: str, values: list[str]) -> None:
        self.handler.set_enum_list(param_id, values)

    # -- Binary ----------------------------------------------------------------

    def set_binary(self, param_id: str, value: bytes) -> None:
        self.handler.set_binary(param_id, value)

    def set_binary_list(self, param_id: str, values: list[bytes]) -> None:
        self.handler.set_binary_list(param_id, values)

    # -- Object ----------------------------------------------------------------

    def set_object(self, param_id: str, writer: Callable[[ParameterObjectHandler], None]) -> None:
        self.handler.set_object(param_id, writer)

    def set_object_list(self, param_id: str, writers: list[Callable[[ParameterObjectHandler], None]]) -> None:
        self.handler.set_object_list(param_id, writers)
