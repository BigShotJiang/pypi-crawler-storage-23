from __future__ import annotations

from io import BufferedRandom
import struct
import uuid

from mft.parameterfile.parameter_info_dto import ParameterInfoDTO
from mft.parameterfile.parameter_object_handler import ParameterObjectHandler


class ParameterFile:
    LATEST_VERSION: int = 1
    FILE_HEADER: str = "9C631168-5C75-444F-BEC8-C51442C0C527"

    def __init__(self, parameters: list[ParameterInfoDTO], file_stream: BufferedRandom):
            self.parameters = parameters
            self.stream = file_stream
            self.version = self.LATEST_VERSION
            self.root_object: ParameterObjectHandler | None = None
            self.is_closed: bool = False

    def __enter__(self):
       return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
        return False

    def close(self):
        if not self.is_closed:
            self.is_closed = True
            self.stream.close()

    """
        We store the parameters in a simple binary file format.
        File layout:
        0-16 bytes: File header. Static byte list to identity that file is indeed this format that we are looking for.
        16-20 bytes: File version. This starts from 1, can be used later to identity older file formats (to read them differently). Ignored in the first implementation
        20+ bytes: Binary object stream (Managed by ParameterObjectHandler).
        Every binary object consists of:
        0-1 byte: type of object. This translates to the ParameterType enum
        Depending on the type of object (Object or Value), the structure is different
            - If object type is Value (not an object):
                    1-5 byte: the length of object data
                    5+ byte: the data itself (the length is determined before)
            - If object type is Object (not a value)
                    1-5 byte: parameter count
                    5 - (5+ [ParameterCount * 24]): Parameter metadata. For every parameter, 3x64bit integers are stored: ParameterNameCrc64Hash, ParameterValueStartIndex, ParameterValueEndIndex
                [after metadata]: Parameter data. Each parameter is a binary object again recursively.


        The File starts with a wrapper binary object, starting at byte 20, so byte 21 should always be type Object, etc.
        The layout is like this to easily support nested objects
    """


    @staticmethod
    def create(file_stream: BufferedRandom, parameters: list[ParameterInfoDTO], close_stream_on_error: bool):
        try:
            ret = ParameterFile(parameters, file_stream)

            file_stream.write(uuid.UUID(ParameterFile.FILE_HEADER).bytes_le)
            # write file header (first 16 bytes)
            file_stream.write(struct.pack("I", ret.version))
            # write file version (next 4 bytes)

            # initialize root object
            ret.root_object = ParameterObjectHandler(
                parameters,
                ret.stream,
                20,
                False
            )
            ret.root_object.create()
            return ret
        except Exception:
            if close_stream_on_error:
                file_stream.close()
            raise

    @staticmethod
    def open_file(file_stream: BufferedRandom, parameters: list[ParameterInfoDTO], close_stream_on_error):
        try:
            ret = ParameterFile(parameters, file_stream)

            # Verify file header and read version
            ret.stream.seek(0)
            buffer = file_stream.read(20)
            # File must be at least 20 bytes long
            if len(buffer) < 20:
                raise Exception("Failed to open ParameterFile. Opened file is too small.")

            # Verify file header
            file_header = uuid.UUID(ParameterFile.FILE_HEADER).bytes_le
            if buffer[:16] != file_header:
                raise Exception("Failed to open ParameterFile. Opened file is not a parameter file.")

            # Set version
            ret.version = struct.unpack_from("I", buffer, 16)[0]

            # Initialize root object
            ret.root_object = ParameterObjectHandler(
                parameters,
                ret.stream,
                20,
                True
            )
            ret.root_object.verify()
            return ret
        except Exception:
            if close_stream_on_error:
                file_stream.close()
            raise
