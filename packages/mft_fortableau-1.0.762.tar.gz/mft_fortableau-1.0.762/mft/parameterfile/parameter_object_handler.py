from __future__ import annotations

import ctypes
import datetime
from io import BufferedRandom
import struct
import uuid

from mft.parameterfile.errors import Errors
from mft.parameterfile.parameter_info_dto import ParameterInfoDTO, ParameterType


class ParameterObjectHandler:

    class ParameterMetadata(ctypes.Structure):
        _fields_ = [
            ("parameter_name_hash", ctypes.c_longlong),
            ("start_index", ctypes.c_longlong),
            ("length", ctypes.c_longlong)
        ]

        def __init__(self, parameter_name_hash, start_index, length):
            super().__init__()
            self.parameter_name_hash = parameter_name_hash
            self.start_index = start_index
            self.length = length


    def __init__(self, parameters: list[ParameterInfoDTO], stream: BufferedRandom, start_index: int, is_read_only: bool):
        self.parameters = parameters
        self.stream = stream
        self.start_index = start_index
        self.is_read_only = is_read_only


    def create(self):
        self.set_data_type()
        parameters: list[ParameterObjectHandler.ParameterMetadata] = []
        for e in self.parameters:
            parameters.append(self.ParameterMetadata(parameter_name_hash = self.get_hash(e.id), length=0, start_index=0))
        self.set_metadata(parameters)


    def verify(self):
        self.verify_data_type()
        metadata = self.get_metadata()
        missing_params = [
            param for param in self.parameters if all(self.get_hash(param.id) != e.parameter_name_hash for e in metadata)
        ]
        if missing_params:
            missing_param_ids = [param.id for param in missing_params]
            raise Exception(f"ParameterObjectHandler is unable to parse object because the following parameters are not contained in it: {', '.join(missing_param_ids)}")

    def get_hash(self, parameter_name: str) -> int:
        """CRC-64/ECMA-182 matching .NET ``BitConverter.ToInt64(Crc64.Hash(bytes))``."""
        data = parameter_name.encode('utf-8')
        crc = 0
        for b in data:
            crc ^= b << 56
            for _ in range(8):
                if crc & (1 << 63):
                    crc = ((crc << 1) & 0xFFFFFFFFFFFFFFFF) ^ 0x42F0E1EBA9EA3693
                else:
                    crc = (crc << 1) & 0xFFFFFFFFFFFFFFFF
        # Crc64.Hash() returns big-endian, BitConverter.ToInt64 reads little-endian
        return struct.unpack('<q', crc.to_bytes(8, 'big'))[0]

    # --- DataType (1st byte) ---

    def set_data_type(self):
        self.stream.seek(self.start_index)
        self.stream.write(bytes([ParameterType.Object.value]))

    def verify_data_type(self):
        self.stream.seek(self.start_index)
        b = self.stream.read(1)
        if b[0] != ParameterType.Object.value:
            raise Exception(f"ParameterObjectHandler is unable to parse object because type is: {b[0]}, which is not the expected {ParameterType.Object}")

    # --- End DataType ---


    # --- Parameter Count + Metadata ---

    def check_metadata_size(self) -> int:
        size = ctypes.sizeof(self.ParameterMetadata)
        if size != 24:
            raise Exception("ParameterObjectHandler error. ParameterMetadata struct is not 24 bytes long")
        return size

    def get_total_length(self) -> int:
        metadata = self.get_metadata()
        return 5 + (len(metadata) * 24) + sum(e.length for e in metadata)

    def get_metadata(self) -> list[ParameterMetadata]:
        ret: list[ParameterObjectHandler.ParameterMetadata] = []

        # Get parameter count
        self.stream.seek(self.start_index + 1)
        read = self.stream.read(4)
        if len(read) != 4:
            raise Exception(f"ParameterObjectHandler get_metadata() failed to read parameter count. Expected to read 4 bytes from stream, but read {len(read)}")
        parameter_count: int = struct.unpack("i", read)[0]
        if parameter_count < 0 or parameter_count > 10_000:
            raise ValueError(f"Invalid parameter count: {parameter_count}")
        buf = self.stream.read(parameter_count * 24)

        if len(buf) != parameter_count * 24:
            raise Exception(f"ParameterObjectHandler get_metadata() failed to read parameter metadata binary. Expected to read {parameter_count * 24} bytes, actual read: {len(buf)}")

        for i in range(parameter_count):
            buffer = buf[i * 24:(i + 1) * 24]
            structure = self.ParameterMetadata.from_buffer_copy(buffer)
            ret.append(structure)

        return ret

    def set_metadata(self, parameters: list[ParameterMetadata]):
        struct_size: int = self.check_metadata_size()
        self.stream.seek(self.start_index + 1)
        self.stream.write(struct.pack('i', len(parameters)))
        self.stream.seek(self.start_index + 5)

        # Set metadata
        for parameter in parameters:
            buffer = ctypes.create_string_buffer(struct_size)
            ctypes.memmove(buffer, ctypes.addressof(parameter), ctypes.sizeof(parameter))
            raw_data = bytes(buffer)
            self.stream.write(raw_data)

    # --- End Parameter Count + Metadata ---


    # --- Read common methods ---

    def read_check(self, parameter_id: str, param_type: ParameterType | None = None) -> ParameterInfoDTO:
        param = next((e for e in self.parameters if e.id == parameter_id), None)
        if param is None:
            raise Errors.WorkflowTaskParameterError("ParameterIdNotInDefinition", f"Task attempted to read parameter '{parameter_id}' that does not exist in the task definition")
        if param_type is not None and param.parameter_type != param_type:
            raise Errors.WorkflowTaskParameterError("InvalidParameterType", f"Task attempted to read parameter '{parameter_id}' as type {param_type}, but it is stored as {param.parameter_type.name}")
        return param

    def read_values(self, parameter_id: str, parameter_type: ParameterType, is_required: bool):
        param = self.read_check(parameter_id, parameter_type)
        all_meta = self.get_metadata()
        metadata = next(e for e in all_meta if int(e.parameter_name_hash) == self.get_hash(parameter_id))

        if metadata.start_index == 0 or metadata.length == 0:
            if is_required:
                raise Errors.WorkflowTaskParameterError("RequiredParameterMissing", f"Task attempted to read required parameter '{parameter_id}', but it is missing in the parameter file")
            return

        obj_start_position = metadata.start_index
        end_index = metadata.start_index + metadata.length

        while obj_start_position < end_index:
            self.stream.seek(obj_start_position)
            actual_type = ParameterType(int.from_bytes(self.stream.read(1), byteorder='big'))

            if actual_type != param.parameter_type:
                raise ValueError(f"ParameterFile format error. Parameter is of type {param.parameter_type.name}, but a value in the object stream is {actual_type.name}")

            if param.parameter_type != ParameterType.Object:
                buffer = self.stream.read(4)

                if len(buffer) < 4:
                    raise RuntimeError(f"ParameterFile format error. Expected to read 4 bytes for data length. Actual read: {len(buffer)}")
                data_length = int.from_bytes(buffer, byteorder='little')
                if data_length > 2**31:
                    raise ValueError(f"Data length {data_length} exceeds maximum allowed size")
                buffer = self.stream.read(data_length)
                if len(buffer) < data_length:
                    raise RuntimeError(f"ParameterFile format error. Expected to read {data_length} bytes for data. Actual read: {len(buffer)}")
                ret = (True, bytes(buffer), None)
                obj_start_position += 5 + data_length
            else:
                handler = ParameterObjectHandler(
                    param.object_properties if param.object_properties else [],
                    self.stream,
                    obj_start_position,
                    True,)
                handler.verify()
                ret = (False, None, handler)
                obj_start_position += handler.get_total_length()

            yield ret

    # --- End Read common methods ---


    # --- Read public methods ---

    def value_exists(self, parameter_id: str) -> bool:
        self.read_check(parameter_id, None)
        all_meta: list[ParameterObjectHandler.ParameterMetadata] = self.get_metadata()
        metadata = next((e for e in all_meta if e.parameter_name_hash == self.get_hash(parameter_id)), None)
        return metadata is not None and metadata.start_index > 0

    def get_required_string(self, parameter_id: str):
        for item in self.get_required_string_list(parameter_id):
            return item

    def get_required_string_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.String, True):
            yield item[1].decode('utf-8') if item[0] else None

    def get_string(self, parameter_id: str):
        for item in self.get_string_list(parameter_id):
            return item

    def get_string_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.String, False):
            yield item[1].decode('utf-8') if item[0] else None


    def get_required_integer(self, parameter_id: str):
        for item in self.get_required_integer_list(parameter_id):
            return item

    def get_required_integer_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Integer, True):
            yield struct.unpack('i', item[1])[0] if item[0] else None

    def get_integer(self, parameter_id: str):
        for item in self.get_integer_list(parameter_id):
            return item

    def get_integer_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Integer, False):
            yield struct.unpack('i', item[1])[0] if item[0] else None


    def get_required_double(self, parameter_id: str):
        for item in self.get_required_double_list(parameter_id):
            return item

    def get_required_double_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Double, True):
            yield struct.unpack('d', item[1])[0] if item[0] else None

    def get_double(self, parameter_id: str):
        for item in self.get_double_list(parameter_id):
            return item

    def get_double_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Double, False):
            yield struct.unpack('d', item[1])[0] if item[0] else None


    def get_required_boolean(self, parameter_id: str):
        for item in self.get_required_boolean_list(parameter_id):
            return item

    def get_required_boolean_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Boolean, True):
            yield struct.unpack('?', item[1])[0] if item[0] else None

    def get_boolean(self, parameter_id: str):
        for item in self.get_boolean_list(parameter_id):
            return item

    def get_boolean_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Boolean, False):
            yield struct.unpack('?', item[1])[0] if item[0] else None


    def pack_date(self, date: datetime.date) -> bytes:
        # C# format: BitConverter.GetBytes((short)year) + (byte)month + (byte)day
        # = 2 bytes year (little-endian int16) + 1 byte month + 1 byte day
        return struct.pack('<hBB', date.year, date.month, date.day)

    def unpack_date(self, data: bytes) -> datetime.date:
        if len(data) != 4:
            raise Exception(f"ParameterFile format error. Date parameter is of length {len(data)}, expected 4")
        # C# format: int16 year (LE) + byte month + byte day
        year, month, day = struct.unpack('<hBB', data)
        return datetime.date(year, month, day)

    def get_required_date(self, parameter_id: str):
        for item in self.get_required_date_list(parameter_id):
            return item

    def get_required_date_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Date, True):
            yield self.unpack_date(item[1]) if item[0] else None

    def get_date(self, parameter_id: str):
        for item in self.get_date_list(parameter_id):
            return item

    def get_date_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Date, False):
            yield self.unpack_date(item[1]) if item[0] else None


    # .NET epoch: 0001-01-01 00:00:00
    # .NET Ticks: 100-nanosecond intervals since .NET epoch
    _DOTNET_EPOCH = datetime.datetime(1, 1, 1)
    _TICKS_PER_DAY = 864_000_000_000  # 86400 * 10_000_000

    def datetime_parser(self, data):
        if len(data) != 8:
            raise Exception(f"ParameterFile format error. DateTime parameter is of length {len(data)}, expected 8")
        # C# encodes DateTime.Ticks (100ns intervals since 0001-01-01)
        ticks = struct.unpack('<q', data)[0]
        # Use integer arithmetic to avoid float precision loss for large tick values
        days, remaining = divmod(ticks, self._TICKS_PER_DAY)
        microseconds = remaining // 10
        return self._DOTNET_EPOCH + datetime.timedelta(days=days, microseconds=microseconds)

    def datetime_packer(self, dt: datetime.datetime) -> bytes:
        # Convert Python datetime to .NET Ticks using integer arithmetic
        delta = dt - self._DOTNET_EPOCH
        total_us = delta.days * 86_400_000_000 + delta.seconds * 1_000_000 + delta.microseconds
        ticks = total_us * 10
        return struct.pack('<q', ticks)

    def get_required_datetime(self, parameter_id: str):
        for item in self.get_required_datetime_list(parameter_id):
            return item

    def get_required_datetime_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.DateTime, True):
            yield self.datetime_parser(item[1]) if item[0] else None

    def get_datetime(self, parameter_id: str):
        for item in self.get_datetime_list(parameter_id):
            return item

    def get_datetime_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.DateTime, False):
            yield self.datetime_parser(item[1]) if item[0] else None


    def timespan_parser(self, data):
        if len(data) != 8:
            raise Exception(f"ParameterFile format error. TimeSpan parameter is of length {len(data)}, expected 8")
        # C# encodes TimeSpan.Ticks (100-nanosecond intervals)
        ticks = struct.unpack('<q', data)[0]
        # Convert .NET ticks to microseconds using integer division
        return datetime.timedelta(microseconds=ticks // 10)

    def get_required_timespan(self, parameter_id: str):
        for item in self.get_required_timespan_list(parameter_id):
            return item

    def get_required_timespan_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.TimeSpan, True):
            yield self.timespan_parser(item[1]) if item[0] else None

    def get_timespan(self, parameter_id: str):
        for item in self.get_timespan_list(parameter_id):
            return item

    def get_timespan_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.TimeSpan, False):
            yield self.timespan_parser(item[1]) if item[0] else None


    def guid_parser(self, data):
        if len(data) != 16:
            raise Exception(f"ParameterFile format error. Guid parameter is of length {len(data)}, expected 16")
        return uuid.UUID(bytes_le=data)

    def get_required_guid(self, parameter_id: str):
        for item in self.get_required_guid_list(parameter_id):
            return item

    def get_required_guid_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Guid, True):
            yield self.guid_parser(item[1]) if item[0] else None

    def get_guid(self, parameter_id: str):
        for item in self.get_guid_list(parameter_id):
            return item

    def get_guid_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Guid, False):
            yield self.guid_parser(item[1]) if item[0] else None


    def get_required_enum(self, parameter_id: str):
        for item in self.get_required_enum_list(parameter_id):
            return item

    def get_required_enum_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Enum, True):
            yield item[1].decode('utf-8') if item[0] else None

    def get_enum(self, parameter_id: str):
        for item in self.get_enum_list(parameter_id):
            return item

    def get_enum_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Enum, False):
            yield item[1].decode('utf-8') if item[0] else None

    def get_required_binary(self, parameter_id: str):
        for item in self.get_required_binary_list(parameter_id):
            return item

    def get_required_binary_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Binary, True):
            yield item[1] if item[0] else None

    def get_binary(self, parameter_id: str):
        for item in self.get_binary_list(parameter_id):
            return item

    def get_binary_list(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Binary, False):
            yield item[1] if item[0] else None


    def get_required_object(self, parameter_id: str):
        for item in self.get_required_objects(parameter_id):
            return item

    def get_required_objects(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Object, True):
            yield item[2] if not item[0] else None

    def get_object(self, parameter_id: str):
        for item in self.get_objects(parameter_id):
            return item

    def get_objects(self, parameter_id: str):
        for item in self.read_values(parameter_id, ParameterType.Object, False):
            yield item[2] if not item[0] else None

    # --- End Read public methods ---


    # --- Internal common methods ---

    append_mode: bool = False

    def set_check(self, parameter_id: str, param_type: ParameterType) -> ParameterInfoDTO:
        if self.is_read_only:
            raise Errors.WorkflowTaskParameterError("ObjectHandlerReadOnly", f"Task attempted to set parameter '{parameter_id}' in a read-only Parameter file")

        # check if parameter id exists
        param = next((e for e in self.parameters if e.id == parameter_id), None)
        if param is None:
            raise Errors.WorkflowTaskParameterError("ParameterIdNotInDefinition", f"Task attempted to set parameter '{parameter_id}' that does not exist in the task definition")
        if param_type != param.parameter_type:
            raise Errors.WorkflowTaskParameterError("InvalidParameterType", f"Task attempted to set parameter '{parameter_id}' with an {param_type} value, when it expects {param.parameter_type.name}")
        return param

    def get_stream_length(self, stream):
        # Save the current position
        current_position = stream.tell()
        # Move the cursor to the end of the stream
        stream.seek(0, 2)  # 0 means offset from the end of the file, and 2 means seek from the end
        # Get the length (position of the cursor at the end of the stream)
        length = stream.tell()
        # Move the cursor back to the original position
        stream.seek(current_position, 0)  # 0 means offset from the beginning of the file
        return length

    def set(self, parameter_id: str, param_type: ParameterType, values: list[tuple[bytes | None, callable | None]]):
        param: ParameterInfoDTO = self.set_check(parameter_id, param_type)

        # get highest metadata end index
        obj_end_index = self.start_index + self.get_total_length()
        stream_length_value = self.get_stream_length(self.stream)
        if obj_end_index != stream_length_value:
            raise Errors.WorkflowTaskParameterError("ObjectNotAtEndOfFile", f"Task attempted to set parameter '{parameter_id}', but the current object is not located at the end of the file. Object end index: {obj_end_index}, file length: {stream_length_value}")

        all_meta = self.get_metadata()
        metadata = next((e for e in all_meta if e.parameter_name_hash == self.get_hash(parameter_id)), None)
        meta_index = all_meta.index(metadata)

        if metadata.start_index != 0:
            if not self.append_mode:
                raise Errors.WorkflowTaskParameterError("ParameterAlreadySet", f"Task attempted to set parameter '{parameter_id}', but has already been set. It is only allowed to set each parameter once.")
            if metadata.start_index + metadata.length != stream_length_value:
                raise Errors.WorkflowTaskParameterError("AppendToNonLastParameter", f"Task attempted to append parameter '{parameter_id}', but it was not the parameter that was last set.")
        else:
            # jump to the end of the file to write the data
            metadata.start_index = stream_length_value

        self.stream.seek(0, 2)
        counter = 0
        length = 0
        for value in values:
            value_data = value[0]
            value_obj_writer = value[1]

            if counter >= 1 and not param.is_list:
                raise Errors.WorkflowTaskParameterError("MultipleValuesPassedToNonListParameter", f"Task attempted to set parameter '{parameter_id}' with more than one value, but parameter is not an array")
            if value_data and len(value_data) > 2 ** 31:
                raise Errors.WorkflowTaskParameterError("ParameterValueTooLarge", f"Task attempted to set parameter '{parameter_id}' with larger than the maximum allowed size for single objects (2GB)")

            if param_type == ParameterType.Object:
                if not value_obj_writer:
                    raise Errors.WorkflowTaskParameterError("NoObjectWriter", f"Task attempted to set parameter '{parameter_id}' a NULL function to set nested object")
                else:
                    writer = ParameterObjectHandler(param.object_properties, self.stream, self.get_stream_length(self.stream), False)
                    writer.create()
                    value_obj_writer(writer)
                    length += writer.get_total_length()
            elif value_data is not None:
                self.stream.write(bytes([param_type.value]))
                self.stream.write(len(value_data).to_bytes(4, 'little'))
                self.stream.write(value_data)
                length += 5 + len(value_data)

            counter += 1

        if counter == 0 and not param.is_list and param.required:
            raise Errors.WorkflowTaskParameterError("RequiredParameterCannotBeNullOrEmpty", f"Task attempted to set parameter '{parameter_id}' with NULL/None or empty values")

        metadata.length += length
        if metadata.start_index + metadata.length != self.get_stream_length(self.stream):
            raise Errors.WorkflowTaskParameterError("InvalidObjectLength", f"Task attempted to set parameter '{parameter_id}' but written object length is incorrect. This is an internal file format error.")

        all_meta[meta_index] = metadata
        self.set_metadata(all_meta)

    def set_values(self, parameter_id: str, param_type: ParameterType, data: list[bytes]):
        values = [(e, None) for e in data]
        self.set(parameter_id, param_type, values)

    def set_objects(self, parameter_id: str, data: list[callable]):
        values = [(None, e) for e in data]
        self.set(parameter_id, ParameterType.Object, values)

    # --- End Internal common methods ---


    # --- Write public methods ---

    def set_string(self, parameter_id: str, value: str) -> ParameterObjectHandler:
        self.set_string_list(parameter_id, [value])
        return self

    def set_string_list(self, parameter_id: str, value: list[str]) -> ParameterObjectHandler:
        values = list(value)
        encoded_values = [item.encode('utf-8') for item in values if item is not None]
        self.set_values(parameter_id, ParameterType.String, encoded_values)
        return self

    def set_integer(self, parameter_id: str, value: int) -> ParameterObjectHandler:
        self.set_integer_list(parameter_id, [value])
        return self

    def set_integer_list(self, parameter_id: str, value: list[int]) -> ParameterObjectHandler:
        self.set_values(parameter_id, ParameterType.Integer, [struct.pack('i', item) for item in list(value)])
        return self

    def set_double(self, parameter_id: str, value: float) -> ParameterObjectHandler:
        self.set_double_list(parameter_id, [value])
        return self

    def set_double_list(self, parameter_id: str, value: list[float]) -> ParameterObjectHandler:
        self.set_values(parameter_id, ParameterType.Double, [struct.pack('d', item) for item in list(value)])
        return self

    def set_boolean(self, parameter_id: str, value: bool) -> ParameterObjectHandler:
        self.set_boolean_list(parameter_id, [value])
        return self

    def set_boolean_list(self, parameter_id: str, value: list[bool]) -> ParameterObjectHandler:
        self.set_values(parameter_id, ParameterType.Boolean, [struct.pack('?', item) for item in list(value)])
        return self

    def set_date(self, parameter_id: str, value: datetime.date) -> ParameterObjectHandler:
        self.set_date_list(parameter_id, [value])
        return self

    def set_date_list(self, parameter_id: str, value: list[datetime.date]) -> ParameterObjectHandler:
        self.set_values(parameter_id, ParameterType.Date, [self.pack_date(item) for item in list(value)])
        return self

    def set_datetime(self, parameter_id: str, value: datetime.datetime) -> ParameterObjectHandler:
        self.set_datetime_list(parameter_id, [value])
        return self

    def set_datetime_list(self, parameter_id: str, value: list[datetime.datetime]) -> ParameterObjectHandler:
        self.set_values(parameter_id, ParameterType.DateTime, [self.datetime_packer(item) for item in list(value)])
        return self

    def set_timespan(self, parameter_id: str, value: datetime.timedelta) -> ParameterObjectHandler:
        self.set_timespan_list(parameter_id, [value])
        return self

    def set_timespan_list(self, parameter_id: str, value: list[datetime.timedelta]) -> ParameterObjectHandler:
        # Convert Python timedelta to .NET Ticks (100ns intervals)
        self.set_values(parameter_id, ParameterType.TimeSpan, [struct.pack('<q', int(item.total_seconds() * 10_000_000)) for item in list(value)])
        return self

    def set_guid(self, parameter_id: str, value: uuid.UUID) -> ParameterObjectHandler:
        self.set_guid_list(parameter_id, [value])
        return self

    def set_guid_list(self, parameter_id: str, value: list[uuid.UUID]) -> ParameterObjectHandler:
        self.set_values(parameter_id, ParameterType.Guid, [item.bytes_le for item in list(value)])
        return self

    def set_enum(self, parameter_id: str, value: str) -> ParameterObjectHandler:
        self.set_enum_list(parameter_id, [value])
        return self

    def set_enum_list(self, parameter_id: str, value: list[str]) -> ParameterObjectHandler:
        param = self.set_check(parameter_id, ParameterType.Enum)
        encoded_values = []
        for item in list(value):
            if item is not None:
                if item.lower() not in (enum_value.lower() for enum_value in param.enum_values):
                    raise Errors.WorkflowTaskParameterError("InvalidEnumValue", f"Task attempted to set parameter '{parameter_id}' with an enum value "
                                    f"'{item}', which is not in the list of allowed values")
                encoded_values.append(item.encode('utf-8'))

        self.set_values(parameter_id, ParameterType.Enum, encoded_values)
        return self

    def set_binary(self, parameter_id: str, value: bytes) -> ParameterObjectHandler:
        self.set_binary_list(parameter_id, [value])
        return self

    def set_binary_list(self, parameter_id: str, value: list[bytes]) -> ParameterObjectHandler:
        self.set_values(parameter_id, ParameterType.Binary, list(value))
        return self

    def set_object(self, parameter_id: str, value: callable) -> ParameterObjectHandler:
        self.set_object_list(parameter_id, [value])
        return self

    def set_object_list(self, parameter_id: str, value: list[callable]) -> ParameterObjectHandler:
        self.set_objects(parameter_id, list(value))
        return self
