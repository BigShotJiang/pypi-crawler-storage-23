from __future__ import annotations

import json
from pathlib import Path

from mft.models.parameter_info import ParameterInfo
from mft.models.task_meta import TaskMeta
from mft.models.task_usage import TaskUsage
from mft.parameterfile.parameter_info_dto import ParameterType


def load_task_meta(meta_path: str | Path | None = None) -> TaskMeta:
    path = _resolve_path(meta_path)
    with open(path, "r", encoding="utf-8") as f:
        raw = f.read()

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in {path}: {exc}") from exc

    if not isinstance(data, dict):
        raise ValueError(f"task-meta.json must be a JSON object, got {type(data).__name__}")

    meta = _parse_task_meta(data)

    errors = meta.validate()
    if errors:
        raise ValueError(
            "task-meta.json validation failed:\n" + "\n".join(f"  - {e}" for e in errors)
        )

    return meta


def _resolve_path(meta_path: str | Path | None) -> Path:
    if meta_path is not None:
        p = Path(meta_path)
        if not p.exists():
            raise FileNotFoundError(f"task-meta.json not found: {p}")
        return p

    for candidate in [Path("./src/task-meta.json"), Path("./task-meta.json")]:
        if candidate.exists():
            return candidate

    raise FileNotFoundError(
        "task-meta.json not found. Searched ./src/task-meta.json and ./task-meta.json"
    )


def _parse_task_meta(data: dict) -> TaskMeta:
    uses: list[TaskUsage] = []
    for u in data.get("uses", []):
        try:
            uses.append(TaskUsage(u))
        except ValueError as exc:
            raise ValueError(
                f"Invalid task usage '{u}'. Valid values: {[e.value for e in TaskUsage]}"
            ) from exc

    inputs = [_parse_parameter_info(p) for p in data.get("inputs", [])]
    outputs = [_parse_parameter_info(p) for p in data.get("outputs", [])]

    return TaskMeta(
        display_name=data.get("display_name", ""),
        description=data.get("description"),
        group=data.get("group", "Custom Tasks"),
        group_index=data.get("group_index"),
        major_version=data.get("major_version", 1),
        version_description=data.get("version_description"),
        inputs=inputs,
        outputs=outputs,
        uses=uses,
    )


def _parse_parameter_info(data: dict) -> ParameterInfo:
    type_str = data.get("type", "")
    try:
        param_type = ParameterType[type_str]
    except KeyError as exc:
        raise ValueError(
            f"Invalid parameter type '{type_str}'. "
            f"Valid values: {[e.name for e in ParameterType]}"
        ) from exc

    obj_props: list[ParameterInfo] | None = None
    raw_props = data.get("object_properties")
    if raw_props is not None:
        obj_props = [_parse_parameter_info(p) for p in raw_props]

    return ParameterInfo(
        id=data.get("id", ""),
        display_name=data.get("display_name", ""),
        type=param_type,
        description=data.get("description"),
        required=data.get("required", False),
        is_list=data.get("is_list", False),
        enum_values=data.get("enum_values"),
        object_properties=obj_props,
    )
