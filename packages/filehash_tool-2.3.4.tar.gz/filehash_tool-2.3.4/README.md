This tool only provides Simplified Chinese user interface.

### 简介

本CLI工具用于计算、存储、验证磁盘文件的hash值，可检查文件是否被篡改。

有以下功能：

- 将磁盘文件的**hash值**、**大小**、**路径**、**登记时间**、**数据库ID**保存到数据库的hash链中
- 验证数据库中的记录，检查记录的路径、hash值、大小
- 验证磁盘文件，将hash值、大小、路径与数据库中的记录对比
- 仅打印数据库中的记录
- 仅计算磁盘文件的hash值

建议配置环境变量使用。目前大多数下载网站提供`sha256`值，因此默认使用`sha256`算法。

### CLI命令

路径使用[glob](https://docs.python.org/3/library/glob.html)语法：`*` `?` `[]` `**`

🟢添加文件信息到数据库：
```shell
filehash add 'E:\software\python-3.13.12-amd64.exe'
filehash a 'E:\software\*.exe'
filehash a 'E:\software\**\*.exe' # **遍历子目录
```

🟠验证数据库中的记录：
```shell
# 如果磁盘文件已被删除，会提示文件不存在，但不会中止。
filehash verify_record '*\python*.exe'
filehash vr '*\software\*.exe'
filehash vr '*\software\**\*.exe'
filehash vr '*.exe'
filehash vr '*' # 验证数据库中的所有记录
```

🔵验证磁盘上的文件：
```shell
# 如果数据库中没有该hash值、大小的数据，程序会报错、中止。
# 此功能可Windows/Linux双系统时使用
filehash verify_file 'E:\software\python-3.13.12-amd64.exe'
filehash vf 'E:\software\*.exe'
filehash vf 'E:\software\**\*.exe'
```

🟤在终端运行filehash，打印完整的帮助信息：
```
PS E:\> filehash
usage: filehash [-h] [-m HASH_METH] [-n] [--db-dir DIR] [--backup-dir DIR] [--backup-size SIZE]
                [CMD] [PATH]

文件hash校验。版本: 2.3.4
https://pypi.org/project/filehash-tool

positional arguments:
  CMD                   命令
  PATH                  路径，使用glob语法，*表示所有文件，dir/**/*.exe遍历子目录。

options:
  -h, --help            show this help message and exit
  -m, --hash-meth HASH_METH
                        创建数据库时使用的hash算法，覆盖FILEHASH_HASH_METH环境变量。
  -n, --no-space        打印hash时，不添加空格。
  --db-dir DIR          数据库目录，覆盖FILEHASH_DB_DIR环境变量。
  --backup-dir DIR      备份保存的数据库目录，覆盖FILEHASH_BACKUP_DIR环境变量。
  --backup-size SIZE    备份保存的数据库数量，覆盖FILEHASH_BACKUP_SIZE环境变量。

可用命令:
  add/a                     登记文件到数据库
  verify_record/vr          验证数据库中的记录
  print_record/pr           打印数据库中的记录
  print_existing_record/per 打印数据库中尚存在的记录
  verify_file/vf            验证磁盘文件
  print_file/pf             计算文件hash值 (不加载数据库)

保证存在的hash算法: blake2b, blake2s, md5, sha1, sha224, sha256, sha384,
sha3_224, sha3_256, sha3_384, sha3_512, sha512, shake_128, shake_256
其它可用的hash算法: md5-sha1, ripemd160, sha512_224, sha512_256, sm3
当前创建数据库使用的hash算法: sha256
```

### 更新日志

2.3.0: 对数据库记录的glob语法：支持`**`遍历子目录，运行在Linux/macOS时不再区分大小写、可使用`/`或`\`匹配数据库记录的路径分隔符。

2.2.0: 数据库向前不兼容。改变数据库格式，所有元素加入hash链。