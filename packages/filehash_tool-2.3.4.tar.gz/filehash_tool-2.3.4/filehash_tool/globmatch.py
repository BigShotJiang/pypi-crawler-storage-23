import functools
import re

__all__ = ('globmatch', 'str_globmatch')

def globmatch(path, pat, *,
              case_sensitive: bool = True,
              cross_fs: bool = False) -> bool:
    if isinstance(path, bytes):
        path = str(path, 'ISO-8859-1')
        pat  = str(pat,  'ISO-8859-1')
    return str_globmatch(path, pat,
                         case_sensitive=case_sensitive,
                         cross_fs=cross_fs)

def str_globmatch(path: str, pat: str, *,
                  case_sensitive: bool = True,
                  cross_fs: bool = False) -> bool:
    # detect path separator, use `/` if not found.
    m = re.match(r'(?s)^.*?([/\\])', path)
    path_sep = m.group(1) if m else '/'
    match = _compile_pattern(pat, case_sensitive, cross_fs, path_sep)
    return match(path) is not None

@functools.lru_cache(maxsize=65536)
def _compile_pattern(pat, case_sensitive, cross_fs, path_sep):
    res = translate(pat, cross_fs, path_sep)
    flags = 0 if case_sensitive else re.IGNORECASE
    return re.compile(res, flags).match

def translate(pat, cross_fs, path_sep):
    parts, star_indices = _translate(pat, '*', '.', cross_fs, path_sep)
    return _join_translated_parts(parts, star_indices)

_re_setops_sub = re.compile(r'([&~|])').sub
_re_escape = functools.lru_cache(maxsize=None)(re.escape)

def _translate(pat, star, question_mark, cross_fs, path_sep):
    res = []
    add = res.append
    star_indices = []
    if cross_fs:
        sep_chr = ('/', '\\')
        sep_pat = r'[/\\]' # escaped
    else:
        sep_chr = (path_sep,)
        sep_pat = _re_escape(path_sep)

    i, n = 0, len(pat)
    while i < n:
        c = pat[i]
        i = i+1
        if c == '*':
            # store the position of the wildcard
            star_indices.append(len(res))
            add(star)
            # compress consecutive `*` into one
            while i < n and pat[i] == '*':
                i += 1
        elif c == '?':
            add(question_mark)
        elif c in sep_chr:
            if pat[i:i+2] == '**' and pat[i+2:i+3] in sep_chr:
                j = i+3
                while pat[j:j+2] == '**' and pat[j+2:j+3] in sep_chr:
                    j += 3

                add(sep_pat)
                star_indices.append(len(res))
                add(star)
                add(rf'(?<={sep_pat})')
                i = j
            else:
                add(sep_pat)
        elif c == '[':
            j = i
            if j < n and pat[j] == '!':
                j = j+1
            if j < n and pat[j] == ']':
                j = j+1
            while j < n and pat[j] != ']':
                j = j+1
            if j >= n:
                add('\\[')
            else:
                stuff = pat[i:j]
                if '-' not in stuff:
                    stuff = stuff.replace('\\', r'\\')
                else:
                    chunks = []
                    k = i+2 if pat[i] == '!' else i+1
                    while True:
                        k = pat.find('-', k, j)
                        if k < 0:
                            break
                        chunks.append(pat[i:k])
                        i = k+1
                        k = k+3
                    chunk = pat[i:j]
                    if chunk:
                        chunks.append(chunk)
                    else:
                        chunks[-1] += '-'
                    # Remove empty ranges -- invalid in RE.
                    for k in range(len(chunks)-1, 0, -1):
                        if chunks[k-1][-1] > chunks[k][0]:
                            chunks[k-1] = chunks[k-1][:-1] + chunks[k][1:]
                            del chunks[k]
                    # Escape backslashes and hyphens for set difference (--).
                    # Hyphens that create ranges shouldn't be escaped.
                    stuff = '-'.join(s.replace('\\', r'\\').replace('-', r'\-')
                                     for s in chunks)
                i = j+1
                if not stuff:
                    # Empty range: never match.
                    add('(?!)')
                elif stuff == '!':
                    # Negated empty range: match any character.
                    add('.')
                else:
                    # Escape set operations (&&, ~~ and ||).
                    stuff = _re_setops_sub(r'\\\1', stuff)
                    if stuff[0] == '!':
                        stuff = '^' + stuff[1:]
                    elif stuff[0] in ('^', '['):
                        stuff = '\\' + stuff
                    add(f'[{stuff}]')
        else:
            add(_re_escape(c))
    assert i == n
    return res, star_indices

def _join_translated_parts(parts, star_indices):
    if not star_indices:
        return fr'(?s:{"".join(parts)})\Z'
    iter_star_indices = iter(star_indices)
    j = next(iter_star_indices)
    buffer = parts[:j]  # fixed pieces at the start
    append, extend = buffer.append, buffer.extend
    i = j + 1
    for groupnum, j in enumerate(iter_star_indices, 1):
        # Now deal with STAR fixed STAR fixed ...
        # For an interior `STAR fixed` pairing, we want to do a minimal
        # .*? match followed by `fixed`, with no possibility of backtracking.
        append((f"(?=(?P<g{groupnum}>.*?{''.join(parts[i:j])}))"
                f"(?P=g{groupnum})"))
        i = j + 1
    append('.*')
    extend(parts[i:])
    res = ''.join(buffer)
    return fr'(?s:{res})\Z'
