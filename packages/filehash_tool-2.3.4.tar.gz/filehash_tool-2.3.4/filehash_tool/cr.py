try:
    import colorama
except ImportError:
    colorama = None # type: ignore

__all__ = ('ENABLED',
           'Fore', 'Back',
           'BRIGHT', 'DIM', 'NORMAL', 'RESET_ALL',
           'p', 'cr_block')

ENABLED = (colorama is not None)

if colorama:
    Fore = colorama.Fore
    Back = colorama.Back

    BRIGHT    = colorama.Style.BRIGHT
    DIM       = colorama.Style.DIM
    NORMAL    = colorama.Style.NORMAL
    RESET_ALL = colorama.Style.RESET_ALL
else:
    class Colors:
        def __getattribute__(self, _: str):
            return ''

    Fore = Back = Colors() # type: ignore

    BRIGHT    = ''
    DIM       = ''
    NORMAL    = ''
    RESET_ALL = ''

def colored(obj, *args):
    return ''.join((*args, str(obj), RESET_ALL))

def p(*args):
    s = ''.join(args)
    print(s)

class cr_block:
    def __init__(self, prompt_pip=False):
        if colorama:
            if hasattr(colorama, 'just_fix_windows_console'):
                # just_fix_windows_console() is available in colorama v0.4.6+
                colorama.just_fix_windows_console()
            else:
                colorama.init()
        elif prompt_pip:
            print('安装colorama模块显示颜色文字信息: pip install colorama')

    def close(self):
        if colorama:
            colorama.deinit()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()
