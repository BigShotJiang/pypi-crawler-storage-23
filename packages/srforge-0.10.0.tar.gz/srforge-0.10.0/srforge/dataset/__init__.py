import functools
import logging
import pickle
import shutil
from pathlib import Path
from typing import Callable, Iterable, Optional, Union

import numpy as np
import torch.utils.data

from srforge.data import Entry
from srforge.registry import register_class

logger = logging.getLogger(__name__)

class Dataset(torch.utils.data.Dataset):
    """Base dataset class with built-in disk caching and automatic transform
    application.

    Subclasses implement ``__getitem__`` and ``__len__``.  The framework wraps
    ``__getitem__`` so that:

    1. If caching is enabled and a cached file exists for the requested index,
       the fully-transformed entry is loaded from disk and returned immediately.
    2. On cache miss, the original ``__getitem__`` is called, transforms are
       applied, and the result is stored to disk for future hits.
    3. If caching is disabled, the original ``__getitem__`` is called and
       transforms are applied every time.

    Caching can be enabled in two ways:

    - At construction time via the *cache_dir* parameter (useful in YAML configs).
    - After construction via the :meth:`cache` method (useful in scripts).
    """
    METADATA_FILE = 'meta.json'
    _GETITEM_WRAPPED = "_transforms_wrapped"

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if '__getitem__' not in cls.__dict__:
            return
        original = cls.__dict__['__getitem__']
        if getattr(original, Dataset._GETITEM_WRAPPED, False):
            return

        @functools.wraps(original)
        def __getitem__(self, index, _orig=original):
            if self._cache_enabled:
                cache_file = self._cache_dir / f"{index}.pkl"
                if cache_file.is_file():
                    try:
                        with open(cache_file, "rb") as f:
                            return pickle.load(f)
                    except Exception:
                        logger.warning(f"Corrupted cache file {cache_file}, regenerating.")
                # Cache miss or corrupted — compute, transform, store
                entry = _orig(self, index)
                for transform in self._transforms:
                    entry = transform(entry)
                self._cache_dir.mkdir(parents=True, exist_ok=True)
                with open(cache_file, "wb") as f:
                    pickle.dump(entry, f)
                return entry
            # No cache — original + transforms
            entry = _orig(self, index)
            for transform in self._transforms:
                entry = transform(entry)
            return entry

        setattr(__getitem__, Dataset._GETITEM_WRAPPED, True)
        cls.__getitem__ = __getitem__

    def __init__(self, name: str = None, transforms: list = None,
                 cache_dir: Union[str, Path] = None, recache: bool = False):
        super().__init__()
        self._transforms = transforms or []
        self._name = name
        self._cache_dir: Optional[Path] = None
        self._cache_enabled: bool = False
        if cache_dir is not None:
            if recache:
                cache_path = Path(cache_dir)
                if cache_path.is_dir():
                    shutil.rmtree(cache_path)
                    logger.info(f"Cleared cache directory: {cache_path}")
            self.cache(cache_dir)

    def __getitem__(self, index) -> Entry:
        raise NotImplementedError

    def __len__(self) -> int:
        raise NotImplementedError

    def cache(self, path: Union[str, Path]) -> "Dataset":
        """Enable disk caching of fully-transformed entries.

        Cached entries are stored as pickle files at ``{path}/{index}.pkl``.
        On cache hit, the entry is returned directly — no transforms run again.

        Args:
            path: Directory where cached pickle files are stored.
                Created automatically on first cache write.

        Returns:
            ``self``, for method chaining.
        """
        self._cache_dir = Path(path)
        self._cache_enabled = True
        return self

    @property
    def cache_path(self) -> Optional[Path]:
        """Return the cache directory path, or ``None`` if caching is disabled."""
        return self._cache_dir if self._cache_enabled else None

    @property
    def name(self) -> str:
        return self._name

    def take(self, amount: int, offset: int = 0) -> "SubsetDataset":
        max_amount = len(self)
        if amount + offset > max_amount:
            logger.warning(f"Amount of samples to take ({amount}) is bigger than dataset "
                          f"itself. Using all elements of dataset ({max_amount}).")
            amount = max_amount
        return SubsetDataset(self, list(range(offset, amount + offset)))

    def shuffle(self, seed: int = 0) -> "SubsetDataset":
        indices = list(range(len(self)))
        np.random.seed(seed)
        np.random.shuffle(indices)
        np.random.seed(None)
        return SubsetDataset(self, indices)

    def reverse(self) -> "SubsetDataset":
        indices = list(reversed(range(len(self))))
        return SubsetDataset(self, indices)

    def filter(self, predicate: Callable[[Entry], bool]) -> "SubsetDataset":
        indices = []
        for entry_index, el in enumerate(self):
            if predicate(el):
                indices.append(entry_index)
        return SubsetDataset(self, indices)

    def __iter__(self):
        for i in range(len(self)):
            yield self[i]

    def __add__(self, other: "Dataset") -> "ConcatDataset":
        return ConcatDataset([self, other])

    def __str__(self):
        return self.__repr__()

    def __repr__(self) -> str:
        out_str = f'{self.__class__.__name__}('
        out_str += f'len={len(self)}, '
        out_str += f'transforms={repr(self._transforms)}'
        out_str += ')'
        return out_str

class SubsetDataset(Dataset):
    def __init__(self, dataset: Dataset, indices: Iterable[int]):
        super().__init__()
        self._dataset = dataset
        self._indices = list(indices)
        if len(self._indices) > len(self._dataset):
            raise ValueError(f"Too many indices. Subset cannot be greater than original dataset.")

    @property
    def name(self) -> str:
        return self._dataset.name

    def __len__(self)-> int:
        return len(self._indices)

    def __getitem__(self, item) -> Entry:
        index = self._indices[item]
        return self._dataset[index]

@register_class
class ConcatDataset(Dataset):
    def __init__(self, datasets: Iterable[Dataset], transforms: list = None, **kwargs):
        super().__init__(transforms=transforms, **kwargs)
        self._datasets = list(datasets)
        if not all(ds.name is not None for ds in self._datasets):
            raise ValueError("All datasets must have a name when concatenating.")
        self._lengths = [len(dataset) for dataset in self._datasets]
        self._indices = [0] + [sum(self._lengths[:i+1]) for i in range(len(self._datasets))]


    @property
    def name(self) -> str:
        return '+'.join([dataset.name for dataset in self._datasets])

    def __getitem__(self, index) -> Entry:
        for i, start_index in enumerate(self._indices):
            if index < start_index + self._lengths[i]:
                entry = self._datasets[i][index - start_index]
                entry.name = f'{self._datasets[i].name}_{entry.name}'
                return entry
        raise IndexError(f"Index {index} out of range.")

    def __len__(self) -> int:
        return sum(self._lengths)

    def __repr__(self):
        return f'ConcatDataset({self._datasets}, len={len(self)}, transforms={repr(self._transforms)})'
