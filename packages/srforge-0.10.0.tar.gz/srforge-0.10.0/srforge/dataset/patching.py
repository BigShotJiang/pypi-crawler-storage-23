import logging
import os
from pathlib import Path
from typing import Tuple, Union, Dict, Any, List, Optional
from dataclasses import dataclass
from functools import lru_cache

import torch
from tqdm import tqdm

from srforge.registry import register_class
from srforge.data import GraphEntry, Entry
from srforge.dataset import Dataset
import threading
import time

logger = logging.getLogger(__name__)


# ============================================================
# Cross-platform file lock (Linux/macOS: fcntl, Windows: msvcrt)
# ============================================================




class CrossPlatformFileLock:
    """
    Cross-platform, multi-process lock implemented via atomic directory creation.
    Re-entrant within the same process (prevents Windows 'Resource deadlock avoided' issues).

    Usage:
        lock_path = cache_dir / f"entry_{entry_idx}.lock"
        with CrossPlatformFileLock(lock_path):
            ...
    Internally creates a directory: <lock_path>.lockdir
    """

    # (pid, abs_lockdir) -> recursion count
    _held: Dict[Tuple[int, str], int] = {}
    _held_guard = threading.Lock()

    def __init__(
        self,
        lock_path: Path,
        timeout: float = 120.0,
        poll_interval: float = 0.05,
        stale_seconds: float = 6 * 60 * 60,  # 6 hours
        break_stale: bool = True,
    ):
        self.lock_path = Path(lock_path)
        # Use a directory for atomic creation
        self.lock_dir = self.lock_path.with_suffix(self.lock_path.suffix + ".lockdir")
        self.timeout = float(timeout)
        self.poll_interval = float(poll_interval)
        self.stale_seconds = float(stale_seconds)
        self.break_stale = bool(break_stale)

        self._key = (os.getpid(), str(self.lock_dir.resolve()))
        self._acquired = False

    def _write_meta(self) -> None:
        """Write PID and timestamp metadata into the lock directory."""
        try:
            (self.lock_dir / "pid.txt").write_text(str(os.getpid()), encoding="utf-8")
            (self.lock_dir / "ts.txt").write_text(str(time.time()), encoding="utf-8")
        except Exception:
            # best-effort only
            pass

    def _is_stale(self) -> bool:
        """Check whether the lock directory is older than ``stale_seconds``."""
        try:
            ts_path = self.lock_dir / "ts.txt"
            if not ts_path.exists():
                return False
            ts = float(ts_path.read_text(encoding="utf-8").strip())
            return (time.time() - ts) > self.stale_seconds
        except Exception:
            return False

    def _break_lock(self) -> None:
        """Remove a stale lock directory on a best-effort basis."""
        # best-effort removal of stale lockdir
        try:
            if self.lock_dir.exists():
                for p in self.lock_dir.glob("*"):
                    try:
                        p.unlink()
                    except Exception:
                        pass
                try:
                    self.lock_dir.rmdir()
                except Exception:
                    pass
        except Exception:
            pass

    def __enter__(self):
        # Re-entrant within same process: just bump recursion counter.
        with self._held_guard:
            if self._key in self._held:
                self._held[self._key] += 1
                self._acquired = True
                return self

        start = time.time()
        while True:
            try:
                # Atomic across processes on Windows + POSIX
                self.lock_dir.mkdir(parents=False, exist_ok=False)
                self._write_meta()

                with self._held_guard:
                    self._held[self._key] = 1
                self._acquired = True
                return self

            except FileExistsError:
                if self.break_stale and self._is_stale():
                    self._break_lock()
                    continue

                if (time.time() - start) >= self.timeout:
                    raise TimeoutError(f"Timeout acquiring lock: {self.lock_dir}")

                time.sleep(self.poll_interval)

    def __exit__(self, exc_type, exc, tb):
        if not self._acquired:
            return False

        # Decrement recursion. Only the last exit actually releases the directory.
        with self._held_guard:
            cnt = self._held.get(self._key, 0)
            if cnt > 1:
                self._held[self._key] = cnt - 1
                return False
            if cnt == 1:
                self._held.pop(self._key, None)

        # Best-effort release
        self._break_lock()
        return False


# ============================================================
# Generic (non-multispectral) patching
# ============================================================

@dataclass
class Patch:
    """
    Represents a patch of an entry in the dataset.
    Each patch is defined by its entry index, patch index, and coordinates for each field.
    Variables:
    - entry_index: Index of the original entry in the dataset.
    - patch_index: Index of the patch within the entry.
    - coords: Dictionary mapping field names (e.g. 'lrs', 'hr') to patch coordinates as (y0, x0, h, w).
    """
    entry_index: int
    patch_index: int
    coords: Dict[str, Tuple[int, int, int, int]]  # (y0, x0, h, w) per field


@register_class
class PatchedDataset(Dataset):
    """A dataset wrapper that splits entries into non-overlapping spatial patches.

    Wraps an existing dataset and divides each entry's spatial fields into a
    grid of patches. The patch grid is computed once at init (either from the
    first entry if ``same_shapes`` is ``True``, or per-entry otherwise).

    Args:
        dataset: The underlying dataset returning Entry objects.
        field_sizes: Dictionary mapping field names to patch size. A single
            int is interpreted as ``(int, int)``.
        same_shapes: If ``True``, assumes all entries share the same spatial
            dimensions and computes the grid only once.
        transforms: Optional list of callables applied to each patched Entry.
    """

    def __init__(
        self,
        dataset: Dataset,
        field_sizes: Union[Dict[str, int], Dict[str, Tuple[int, int]]],
        same_shapes: bool = False,
        transforms: list = None,
        **kwargs,
    ):
        super().__init__(dataset.name, transforms=transforms, **kwargs)
        self.field_sizes: Dict[str, Tuple[int, int]] = {}
        for key, value in field_sizes.items():
            self.field_sizes[key] = (value, value) if isinstance(value, int) else value

        self.dataset = dataset
        self.same_shapes = same_shapes
        self.patches = self._create_patches()
        logger.info(f"Created {len(self.patches)} patches.")

    def _extract_tensor(self, value: Any) -> torch.Tensor:
        """
        Given a field value that might be a tensor, list/tuple of tensors, or a dict of tensors,
        extract a representative tensor (e.g. the first element) to use for computing the patch grid.
        """
        if isinstance(value, torch.Tensor):
            return value
        if isinstance(value, (list, tuple)) and len(value) > 0:
            if isinstance(value[0], torch.Tensor):
                for tensor in value:
                    if tensor.shape != value[0].shape:
                        raise ValueError("All tensors in the list/tuple must have the same shape.")
            return self._extract_tensor(value[0])
        if isinstance(value, dict) and len(value) > 0:
            key0 = next(iter(value))
            return self._extract_tensor(value[key0])
        raise ValueError("Field value must be a tensor or container of tensors.")

    def _create_patches(self) -> List[Patch]:
        """
        Compute a sliding window grid for patching.
        Stride == patch size (no overlap) and all fields yield the same number of patches.
        """
        if self.same_shapes is True:
            logger.info("Started creating patches based on first entry")
            sample_entry = self.dataset[0]
            if isinstance(sample_entry, GraphEntry):
                raise NotImplementedError(f"Patching is not implemented for {type(sample_entry)}.")

            grid: Dict[str, List[Tuple[int, int, int, int]]] = {}
            num_patches = None

            for field, patch_size in self.field_sizes.items():
                tensor = self._extract_tensor(sample_entry[field])
                H, W = tensor.shape[-2], tensor.shape[-1]
                patch_h, patch_w = patch_size
                n_y = H // patch_h
                n_x = W // patch_w

                positions = [(i * patch_h, j * patch_w, patch_h, patch_w) for i in range(n_y) for j in range(n_x)]
                grid[field] = positions

                if num_patches is None:
                    num_patches = len(positions)
                elif len(positions) != num_patches:
                    raise ValueError(
                        f"Inconsistent number of patches for field '{field}' (got {len(positions)} vs {num_patches})"
                    )

            patches: List[Patch] = []
            for entry_index in range(len(self.dataset)):
                for patch_idx in range(num_patches or 0):
                    coords = {field: grid[field][patch_idx] for field in self.field_sizes.keys()}
                    patches.append(Patch(entry_index=entry_index, coords=coords, patch_index=patch_idx))
            return patches

        logger.info("Started creating patches for each entry independently")
        patches: List[Patch] = []
        for entry_index in tqdm(range(len(self.dataset)), desc="Creating patches"):
            entry = self.dataset[entry_index]
            if isinstance(entry, GraphEntry):
                raise NotImplementedError(f"Patching is not implemented for {type(entry)}.")

            grid: Dict[str, List[Tuple[int, int, int, int]]] = {}
            num_patches = None

            for field, patch_size in self.field_sizes.items():
                tensor = self._extract_tensor(entry[field])
                H, W = tensor.shape[-2], tensor.shape[-1]
                patch_h, patch_w = patch_size
                n_y = H // patch_h
                n_x = W // patch_w
                positions = [(i * patch_h, j * patch_w, patch_h, patch_w) for i in range(n_y) for j in range(n_x)]
                grid[field] = positions

                if num_patches is None:
                    num_patches = len(positions)
                elif len(positions) != num_patches:
                    raise ValueError(
                        f"Inconsistent number of patches for field '{field}' (got {len(positions)} vs {num_patches})"
                    )

            for patch_idx in range(num_patches or 0):
                coords = {field: grid[field][patch_idx] for field in self.field_sizes.keys()}
                patches.append(Patch(entry_index=entry_index, coords=coords, patch_index=patch_idx))

        return patches

    def _crop_field(self, value: Any, coords: Tuple[int, int, int, int]) -> Any:
        """
        Recursively crop the field value according to coords.
        If value is a Tensor, crop its last two dimensions.
        If it is a list, tuple, or dict, apply cropping elementwise.
        """
        y0, x0, ph, pw = coords
        if isinstance(value, torch.Tensor):
            cropped = value[..., y0:y0 + ph, x0:x0 + pw]
            return cropped.detach().contiguous()
        if isinstance(value, list):
            return [self._crop_field(v, coords) for v in value]
        if isinstance(value, tuple):
            return tuple(self._crop_field(v, coords) for v in value)
        if isinstance(value, dict):
            return {k: self._crop_field(v, coords) for k, v in value.items()}
        return value

    def _crop(self, entry: Any, patch: Patch) -> Any:
        """
        Crop each field in the entry that is specified in patch.coords.
        Other fields remain unchanged.
        """
        result_kwargs = {}
        for key, value in entry.items():
            if key in patch.coords:
                result_kwargs[key] = self._crop_field(value, patch.coords[key])
            else:
                result_kwargs[key] = value

        entry_type = type(entry)
        if 'name' not in result_kwargs:
            raise ValueError(f"Entry type {entry_type} must have a 'name' attribute.")
        result_kwargs['name'] = f"{entry.name}_{str(patch.patch_index).zfill(3)}"
        return entry_type(**result_kwargs)

    def __len__(self):
        """Return the total number of patches across all entries."""
        return len(self.patches)

    def take(self, amount: int, offset: int = 0) -> "PatchedDataset":
        """Subset the dataset to a specific range of patches (not implemented)."""
        raise NotImplementedError #TODO: Implement this similar to MultiSpectralPatchedDataset


    @lru_cache(maxsize=1)
    def __get_full_image(self, entry_index: int) -> Any:
        """Load and cache the full entry at the given index."""
        return self.dataset[entry_index]

    def __getitem__(self, idx) -> Any:
        """Return the cropped Entry for the given patch index."""
        patch = self.patches[idx]
        entry = self.__get_full_image(patch.entry_index)
        return self._crop(entry, patch)


# ============================================================
# MultiSpectral patching (with optional internal cache + locks)
# ============================================================

@dataclass
class MSPatch:
    """Patch spec for a multispectral Entry with dict-of-bands (coords are in REF-band pixels)."""
    entry_index: int
    patch_index: int
    coords_ref: Dict[str, Tuple[int, int, int, int]]  # (y0, x0, h, w) per field


@register_class
class MultiSpectralPatchedDataset(Dataset):
    """A patching dataset for multispectral entries with per-band spatial fields.

    Patches are defined on a reference band and mapped to other bands by spatial
    ratio. Supports optional internal disk caching with cross-platform file
    locking for multi-process data loading.

    Args:
        dataset: Underlying dataset returning multispectral Entry objects.
        field_sizes: Patch sizes per field, in reference-band pixels.
        ref_band: Name of the reference band used to define the patch grid.
        rounding: Rounding mode for coordinate mapping (``"round"``, ``"floor"``,
            or ``"ceil"``).
        use_internal_cache: If ``True``, patches are cached to disk after first
            generation.
        clean_after_transfer: If ``True``, cached patch files are deleted after
            loading.
    """

    def __init__(
        self,
        dataset: Dataset,
        field_sizes: Union[Dict[str, int], Dict[str, Tuple[int, int]]],
        ref_band: str,
        rounding: str = "round",
        use_internal_cache: bool = False,
        clean_after_transfer: bool = True,
        transforms: list = None,
        **kwargs,
    ):
        super().__init__(transforms=transforms, **kwargs)
        self.dataset = dataset
        self.ref_band = ref_band
        self.rounding = rounding

        self.use_internal_cache = use_internal_cache
        self.clean_after_transfer = clean_after_transfer

        self._internal_cache_path: Optional[Path] = None

        # Normalize field sizes
        self.field_sizes: Dict[str, Tuple[int, int]] = {}
        for k, v in field_sizes.items():
            self.field_sizes[k] = (v, v) if isinstance(v, int) else tuple(v)

        self.patches: List[MSPatch] = self._create_patches()
        self.entry_to_patches: Dict[int, List[int]] = {}

        if self.use_internal_cache:
            for idx, patch in enumerate(self.patches):
                self.entry_to_patches.setdefault(patch.entry_index, []).append(idx)

    def __len__(self):
        """Return the total number of patches across all entries."""
        return len(self.patches)

    def _rebuild_entry_to_patches(self) -> None:
        """Rebuild the mapping from entry indices to their patch indices."""
        self.entry_to_patches = {}
        if not self.use_internal_cache:
            return
        for i, p in enumerate(self.patches):
            self.entry_to_patches.setdefault(p.entry_index, []).append(i)

    def take(self, amount: int, offset: int = 0) -> "MultiSpectralPatchedDataset":
        """Subset the dataset to ``amount`` patches starting at ``offset``.

        Args:
            amount: Number of patches to keep.
            offset: Starting patch index.

        Returns:
            This dataset instance, modified in-place.
        """
        max_amount = len(self)
        if amount + offset > max_amount:
            logger.warning(
                f"Amount of samples to take ({amount}) is bigger than dataset itself. "
                f"Using all elements of dataset ({max_amount})."
            )
            amount = max_amount

        indices = list(range(offset, offset + amount))
        self.patches = [self.patches[i] for i in indices]
        self._rebuild_entry_to_patches()
        return self

    def shuffle(self, seed: Optional[int] = None) -> "MultiSpectralPatchedDataset":
        """Randomly shuffle the patch order.

        Args:
            seed: Optional random seed for reproducibility.

        Returns:
            This dataset instance, modified in-place.
        """
        import numpy as np
        indices = list(range(len(self)))
        np.random.seed(seed)
        np.random.shuffle(indices)
        np.random.seed(None)
        self.patches = [self.patches[i] for i in indices]
        self._rebuild_entry_to_patches()
        return self

    @staticmethod
    def _extract_tensor(value: Any) -> torch.Tensor:
        """Extract a representative tensor from a field value.

        Recursively unwraps lists, tuples, and dicts to find the first tensor,
        which is used to determine spatial dimensions for patch grid computation.
        """
        if isinstance(value, torch.Tensor):
            return value
        if isinstance(value, (list, tuple)) and value:
            return MultiSpectralPatchedDataset._extract_tensor(value[0])
        if isinstance(value, dict) and value:
            return MultiSpectralPatchedDataset._extract_tensor(value[list(value.keys())[0]])
        raise ValueError("Field value must be a tensor or container of tensors.")

    def _round_like(self, x: torch.Tensor, mode: str) -> torch.Tensor:
        """Round a tensor using the specified mode (``floor``, ``ceil``, or ``round``)."""
        if mode == "floor":
            return torch.floor(x)
        if mode == "ceil":
            return torch.ceil(x)
        return torch.round(x)

    def _map_coords_by_ratio(self, yxhw_ref, H_ref, W_ref, H_b, W_b):
        """Map reference-band patch coordinates to a target band by spatial ratio.

        Args:
            yxhw_ref: ``(y0, x0, h, w)`` coordinates in reference-band pixels.
            H_ref: Height of the reference band.
            W_ref: Width of the reference band.
            H_b: Height of the target band.
            W_b: Width of the target band.

        Returns:
            ``(y0, x0, h, w)`` coordinates in target-band pixels.
        """
        y0r, x0r, hr, wr = yxhw_ref
        sy = float(H_b) / float(max(H_ref, 1))
        sx = float(W_b) / float(max(W_ref, 1))

        y0b = int(self._round_like(torch.tensor(y0r * sy), self.rounding).item())
        x0b = int(self._round_like(torch.tensor(x0r * sx), self.rounding).item())
        hb = max(1, int(self._round_like(torch.tensor(hr * sy), self.rounding).item()))
        wb = max(1, int(self._round_like(torch.tensor(wr * sx), self.rounding).item()))

        if y0b + hb > H_b:
            y0b = max(0, H_b - hb)
        if x0b + wb > W_b:
            x0b = max(0, W_b - wb)

        return y0b, x0b, hb, wb

    def _crop_field(self, value: Any, coords: Tuple[int, int, int, int]) -> Any:
        """Recursively crop a field value's spatial dimensions to the given coordinates."""
        y0, x0, ph, pw = coords

        if isinstance(value, torch.Tensor):
            return value[..., y0:y0 + ph, x0:x0 + pw].clone().contiguous().detach()

        if isinstance(value, list):
            return [self._crop_field(v, coords) for v in value]
        if isinstance(value, tuple):
            return tuple(self._crop_field(v, coords) for v in value)
        if isinstance(value, dict):
            return {k: self._crop_field(v, coords) for k, v in value.items()}
        if isinstance(value, set):
            return {self._crop_field(v, coords) for v in value}
        return value

    def _create_patches(self) -> List[MSPatch]:
        """
        Build a stride==size (no-overlap) grid on the reference band for each field.
        All fields must produce the same number of patches on the reference band.
        """
        sample_entry = self.dataset[0]
        if not isinstance(sample_entry, Entry):
            raise TypeError(f"This dataset expects Entry items, got {type(sample_entry)}.")
        grid_ref: Dict[str, List[Tuple[int, int, int, int]]] = {}
        num_patches = None

        for field, (ph, pw) in self.field_sizes.items():
            if field not in sample_entry:
                raise KeyError(f"Field '{field}' not found in entry.")
            field_val = sample_entry[field]
            if not isinstance(field_val, dict):
                raise TypeError(f"Field '{field}' must be a dict of band values for multispectral patching.")
            if self.ref_band not in field_val:
                raise KeyError(f"ref_band '{self.ref_band}' not found in field '{field}'.")
            t_ref = self._extract_tensor(field_val[self.ref_band])
            H_ref, W_ref = t_ref.shape[-2], t_ref.shape[-1]
            n_y = H_ref // ph
            n_x = W_ref // pw
            pos = [(iy * ph, ix * pw, ph, pw) for iy in range(n_y) for ix in range(n_x)]
            grid_ref[field] = pos

            if num_patches is None:
                num_patches = len(pos)
            elif len(pos) != num_patches:
                raise ValueError(
                    f"Inconsistent number of patches for field '{field}' on ref band "
                    f"(got {len(pos)} vs {num_patches})."
                )

        patches: List[MSPatch] = []
        logger.info("Started creating patches for each entry independently")
        for entry_index in range(len(self.dataset)):
            for pidx in range(num_patches or 0):
                coords_ref = {f: grid_ref[f][pidx] for f in self.field_sizes.keys()}
                patches.append(MSPatch(entry_index=entry_index, patch_index=pidx, coords_ref=coords_ref))
        return patches

    def _resolve_internal_path(self) -> Path:
        """Resolve or create the internal cache directory for storing patches.

        Uses the ``cache_path`` property to find the dataset's cache directory,
        then creates a sibling ``_internal`` directory next to it.

        Returns:
            Path to the internal cache directory.

        Raises:
            RuntimeError: If no cache directory is found.
        """
        if self._internal_cache_path is not None:
            return self._internal_cache_path

        cache_dir = self.cache_path or getattr(self.dataset, 'cache_path', None)
        if cache_dir is not None:
            internal_path = cache_dir.parent / f"{cache_dir.name}_internal"
            try:
                internal_path.mkdir(parents=True, exist_ok=True)
            except OSError as e:
                raise RuntimeError(
                    f"Found cache location but could not create directory: {internal_path}. Error: {e}"
                )

            logger.info(f"Internal cache initialized at: {internal_path}")
            self._internal_cache_path = internal_path
            return internal_path

        raise RuntimeError(
            "MultiSpectralPatchedDataset configured with use_internal_cache=True, "
            "but no cache directory found. "
            "Please call .cache(path) on the dataset BEFORE starting the dataloader, "
            "or disable internal caching."
        )

    def _get_patch_filename(self, entry_idx: int, patch_idx: int) -> str:
        """Return the cache filename for a given entry and patch index."""
        return f"e{entry_idx}_p{patch_idx}.pt"

    def __getitem__(self, idx: int) -> Entry:
        """Return the patched Entry at the given index.

        Uses internal disk caching (if enabled) with cross-platform file
        locking to avoid redundant loading in multi-process settings.
        """
        mp = self.patches[idx]
        raw_entry: Optional[Entry] = None

        # --- Case 1: no internal cache ---
        if not self.use_internal_cache:
            raw_entry = self._generate_single_patch_on_fly(mp)

        # --- Case 2: using internal cache ---
        else:
            cache_dir = self._resolve_internal_path()
            patch_filename = self._get_patch_filename(mp.entry_index, mp.patch_index)
            patch_path = cache_dir / patch_filename

            # A. FAST PATH
            if patch_path.exists():
                raw_entry = self._load_and_cleanup(patch_path)
                if raw_entry is None:
                    logger.warning(f"Fast path failed for patch {idx}. Falling back to lock.")

            # B. SLOW PATH
            if raw_entry is None:
                lock_path = cache_dir / f"entry_{mp.entry_index}.lock"

                with CrossPlatformFileLock(lock_path):
                    # Double-check inside lock
                    if patch_path.exists():
                        raw_entry = self._load_and_cleanup(patch_path)

                    if raw_entry is None:
                        full_ms_entry = self.dataset[mp.entry_index]
                        patch_indices = self.entry_to_patches[mp.entry_index]

                        for p_idx in patch_indices:
                            patch_info = self.patches[p_idx]
                            ms_patch_entry = self._generate_single_patch_from_full(full_ms_entry, patch_info)

                            curr_filename = self._get_patch_filename(mp.entry_index, patch_info.patch_index)
                            curr_path = cache_dir / curr_filename
                            tmp_path = cache_dir / (curr_filename + ".tmp")

                            torch.save(ms_patch_entry, tmp_path)

                            # Best-effort durability; on some FS this may still be "best effort"
                            try:
                                with open(tmp_path, "rb") as f:
                                    os.fsync(f.fileno())
                            except Exception:
                                pass

                            os.replace(tmp_path, curr_path)  # atomic on Windows + POSIX

                            if p_idx == idx:
                                raw_entry = ms_patch_entry

                        del full_ms_entry

                        if raw_entry is not None and self.clean_after_transfer and patch_path.exists():
                            try:
                                os.remove(patch_path)
                            except OSError:
                                pass

        if raw_entry is None:
            raise RuntimeError(f"Failed to load or generate patch {idx}")

        return raw_entry

    def _load_and_cleanup(self, path: Path):
        """
        Safely loads the patch. Returns None on failure.
        """
        try:
            entry = torch.load(path, weights_only=False)

            if self.clean_after_transfer:
                try:
                    os.remove(path)
                except OSError:
                    pass
            return entry

        except (FileNotFoundError, EOFError, RuntimeError, Exception):
            # If file is corrupted/half-written, delete it so it can be regenerated
            try:
                if path.exists():
                    os.remove(path)
            except OSError:
                pass
            return None

    def _generate_single_patch_on_fly(self, mp: MSPatch):
        """Generate a single patch by loading the full entry and cropping."""
        full_entry = self.dataset[mp.entry_index]
        return self._generate_single_patch_from_full(full_entry, mp)

    def _generate_single_patch_from_full(self, full_entry: Entry, mp: MSPatch) -> Entry:
        """Crop a single patch from an already-loaded full entry.

        Maps reference-band coordinates to each band using spatial ratios
        and crops all fields accordingly.
        """
        new_kwargs = {k: full_entry[k] for k in full_entry.keys()}

        for field, yxhw_ref in mp.coords_ref.items():
            field_val = full_entry[field]
            if not isinstance(field_val, dict):
                continue
            if self.ref_band not in field_val:
                raise KeyError(f"ref_band '{self.ref_band}' not found in field '{field}'.")

            ref_tensor = self._extract_tensor(field_val[self.ref_band])
            H_ref, W_ref = ref_tensor.shape[-2], ref_tensor.shape[-1]

            cropped_field = {}
            for band, band_val in field_val.items():
                t_b = self._extract_tensor(band_val)
                H_b, W_b = t_b.shape[-2], t_b.shape[-1]
                coords_b = self._map_coords_by_ratio(yxhw_ref, H_ref, W_ref, H_b, W_b)
                cropped_field[band] = self._crop_field(band_val, coords_b)

            new_kwargs[field] = cropped_field

        if "name" in new_kwargs:
            new_kwargs["name"] = f"{full_entry.name}_{str(mp.patch_index).zfill(3)}"

        return type(full_entry)(**new_kwargs)
