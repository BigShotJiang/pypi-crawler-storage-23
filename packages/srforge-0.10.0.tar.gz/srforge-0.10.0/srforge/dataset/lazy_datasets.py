from pathlib import Path
from typing import Union, Dict, List, Any
import json

from srforge.dataset import Dataset
from srforge.utils.io import load_file, deep_list_subdirs
from srforge.registry import register_class
from srforge.data import Entry

@register_class
class LazyDataset(Dataset):
    """A dataset that lazily loads data from a directory structure.

    Each example is a subdirectory containing files that match the provided
    mappings. Files are loaded on demand when accessed via ``__getitem__``.

    Args:
        root: Root directory containing the dataset.
        mappings: Dictionary mapping Entry field names to file name patterns
            within each example directory (e.g., ``{"hr": "HR", "lrs": "LR"}``).
        depth: Subdirectory depth for discovering examples. 0 means immediate
            children of root are examples.
        name: Optional dataset name.
        allowed_dirs: Optional list of directory names to include. If empty,
            all directories are included.
        transforms: Optional list of callables applied to each loaded Entry.
    """

    def __init__(self, root: Union[Path, str],
                 mappings: Dict[str, str],
                 depth: int = 0,
                 name: str = None,
                 allowed_dirs: List[str] = None,
                 transforms: list = None,
                 **kwargs):
        super().__init__(name, transforms=transforms, **kwargs)
        if isinstance(root, str):
            root = Path(root)
        self.root = root
        self.depth = depth
        self.allowed_dirs = allowed_dirs or []

        self._examples: List[Path] = sorted(deep_list_subdirs(root, depth=depth, allowed_dirs=self.allowed_dirs))
        self._example_names = self.__get_example_names(depth)
        if not (len(self._examples) == len(self._example_names)):
            raise ValueError(
                "Number of examples and names do not match. Make sure the depth is correct or"
                " there is no duplicates in example names."
            )
        self._mappings = mappings

    @property
    def name(self) -> str:
        """Return the dataset name."""
        return self._name

    @property
    def examples(self) -> List[str]:
        """Return the list of example names."""
        return self._example_names

    def __get_example_names(self, depth: int) -> List[str]:
        """Derive human-readable names from example paths."""
        if depth == 0:
            return [x.stem for x in self._examples]
        return ['_'.join(x.relative_to(self.root).parts) for x in self._examples]


    def __len__(self) -> int:
        """Return the number of examples in the dataset."""
        return len(self._examples)

    def __getitem__(self, idx) -> Entry:
        """Load and return the Entry at the given index."""
        data_dir = self._examples[idx]
        result = {'name': self._example_names[idx]}
        for key, value in self._mappings.items():
            contents = sorted(data_dir.glob(value+'*'))
            if len(contents) == 0:
                result[key] = None
                continue
            # assert len(contents) != 0, f"Mapping '{value}' not found in {data_dir}."
            if len(contents) == 1:
                loaded = load_file(contents[0])
            else:
                loaded = [load_file(x) for x in contents]
            result[key] = loaded
        return Entry(**result)

    @staticmethod
    def __exclude_nones(loaded: Any) -> Any:
        """Remove None values from dicts or lists, returning None if empty."""
        if isinstance(loaded, dict):
            result = {k: v for k, v in loaded.items() if v is not None}
            if len(result) == 0:
                return None
            return result
        if isinstance(loaded, list):
            result = [x for x in loaded if x is not None]
            if len(result) == 0:
                return None
            return result
        return loaded


@register_class
class LazyMultiSpectralDataset(LazyDataset):
    """
    A LazyDataset variant for multispectral data. Each scene folder contains
    one subfolder per spectral band. For each band folder, an Entry is created
    (using the same mapping logic as LazyDataset, but relative to the band folder).
    Finally, a single Entry is created where each field is a dict keyed by band name.
    """

    def __init__(self, root: Union[Path, str],
                 mappings: Dict[str, str],
                 depth: int = 0,
                 name: str = None,
                 allowed_dirs: List[str] = None,
                 transforms: list = None,
                 **kwargs):
        super().__init__(root, mappings, depth, name, allowed_dirs, transforms=transforms, **kwargs)

    def __getitem__(self, idx) -> Entry:
        """Load and return a multispectral Entry at the given index.

        Iterates over band subdirectories within the scene folder, loads each
        band's data using the parent mappings, merges band-level and scene-level
        metadata, and returns a single Entry where each field is a dict keyed
        by band name.

        Args:
            idx (int): Index of the scene to load.

        Returns:
            Entry: An Entry with dict-valued fields keyed by band name.
        """
        # Get the scene folder and its name as in LazyDataset.
        scene_dir = self._examples[idx]
        scene_name = self._example_names[idx]

        field_dict: Dict[str, Dict[str, Any]] = {}
        bands: List[str] = []
        # Assume each band is a subdirectory in the scene folder.
        # Sort to ensure a consistent order.
        for band_dir in sorted(scene_dir.iterdir()):
            if not band_dir.is_dir():
                continue
            # Build an Entry for this band.
            result = {'name': band_dir.name}
            # For each mapping key (e.g. 'hr', 'lrs'), look inside the band folder.
            for key, pattern in self._mappings.items():
                # Note: pattern should be relative to the band folder.
                contents = list(band_dir.glob(pattern + '*'))
                if len(contents) == 0:
                    result[key] = None
                    continue
                if len(contents) == 1:
                    loaded = load_file(contents[0])
                else:
                    loaded = [load_file(x) for x in contents]
                result[key] = loaded
            # load band-specific metadata
            metadata = band_dir / self.METADATA_FILE
            if metadata.exists():
                metadata = load_file(metadata)
            else:
                metadata = {}
            # Make sure that no metadata key is already stored in result.
            if any(k in result for k in metadata):
                raise ValueError(f"Metadata keys {list(metadata.keys())} conflict with existing keys in {result.keys()}. Entry name: {scene_name}, band: {band_dir.name}")
            result.update(metadata)
            bands.append(band_dir.name)

            for key, value in result.items():
                if key == "name":
                    continue
                field_dict.setdefault(key, {})[band_dir.name] = value

        entry = Entry(**field_dict, name=scene_name)
        entry["bands"] = bands

        # load multi-spectral metadata if available
        metadata = scene_dir / self.METADATA_FILE
        if metadata.exists():
            metadata = load_file(metadata)
        else:
            metadata = {}
        # Make sure that no metadata key is already stored in entry.
        if any(k in entry for k in metadata):
            raise ValueError(f"Metadata keys {list(metadata.keys())} conflict with existing keys in {entry.keys()}. Entry name: {scene_name}")
        for k, v in metadata.items():
            if k not in entry:
                entry[k] = v


        return entry



@register_class
class LazyConfigDataset(Dataset):
    """A dataset driven by a JSON or dict config mapping field names to file paths.

    Each key in the config maps to a list of file paths. All lists must have
    the same length. When accessed, the dataset loads files at the given index
    and groups them into an Entry. All files at the same index must share
    the same stem (base filename without extension).

    Args:
        config: A dict mapping field names to lists of file paths, or a path
            to a JSON file containing such a dict.
        name: Optional dataset name.
        transforms: Optional list of callables applied to each loaded Entry.
    """

    def __init__(self,
                 config: Union[str, Path, Dict[str, List[str]]],
                 name: str = None,
                 transforms: list = None,
                 **kwargs):
        super().__init__(name, transforms=transforms, **kwargs)
        self.config: Dict = self.__load_config(config)
        key_lengths = {k: len(v) for k, v in self.config.items()}
        if not (len(set(key_lengths.values())) == 1):
            raise ValueError("All keys in the config must have the same length.")
        self._length = key_lengths.popitem()[1]

    @staticmethod
    def __load_config(config: Any) -> Union[Dict[str, List[str]]]:
        """Load and validate the config from a dict, file path, or JSON string.

        Args:
            config: A dict, ``Path``, or string path to a JSON config file.

        Returns:
            A dictionary mapping field names to lists of file paths.

        Raises:
            ValueError: If config is not a supported type.
        """
        if isinstance(config, dict):
            return config
        elif isinstance(config, (str, Path)):
            with open(config, 'r') as f:
                loaded = json.load(f)
            return loaded
        raise ValueError(f"Invalid config type: {type(config)} for config {config}.")

    @property
    def name(self) -> str:
        """Return the dataset name."""
        return self._name

    @property
    def examples(self) -> List[str]:
        """Return the list of example names (not implemented for config datasets)."""
        raise NotImplementedError

    def __len__(self) -> int:
        """Return the number of examples in the dataset."""
        return self._length

    def __getitem__(self, idx) -> Entry:
        """Load and return the Entry at the given index.

        Args:
            idx (int): Index of the example to load.

        Returns:
            Entry: An Entry with fields populated from the loaded files.

        Raises:
            AssertionError: If files at the same index have different stems.
        """
        result = {}
        name = None
        for key, value in self.config.items():
            filepath = Path(value[idx])
            if name is None:
                name = filepath.stem
            else:
                if not (name == filepath.stem):
                    raise ValueError(f"All entries must have the same name. Got '{name}' and '{filepath.stem}'.")
            result[key] = load_file(filepath)
        return Entry(name=name, **result)


