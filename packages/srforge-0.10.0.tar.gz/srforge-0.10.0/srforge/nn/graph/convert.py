import torch
import torch_geometric as tg
import torch.nn.functional as F


def graph_to_image2d(nodes, num_graphs, lr_shape: tuple = None, num_lr=None):
    num_nodes, features = nodes.shape
    if num_lr is not None:
        if not (len(num_lr.unique()) == 1):
            raise ValueError("All graphs must have the same number of lr images to be converted to a single tensor.")
        num_lr = num_lr[0]
    length = num_nodes // num_graphs
    if lr_shape is None:
        image_size = [int(length ** 0.5)] * 2
    else:
        image_size = lr_shape[-2:]
    if num_lr is None:
        nodes = nodes.reshape(-1, image_size[-2], image_size[-1], features)
    else:
        nodes = nodes.reshape(-1, num_lr, image_size[-2], image_size[-1], features)
    nodes = torch.movedim(nodes, -1, -3)
    return nodes


def graph_to_image2d_uneven(data, field_name="lrs"):
    num_nodes, features = getattr(data, field_name).shape
    max_lrs_in_batch = max([x[-3] for x in data[f"{field_name}_org_shape"]])
    result = list()
    indices = list()
    for i in range(data.num_graphs):
        num_lr, height, width = data[i][f"{field_name}_org_shape"][0, -3:]
        nodes = getattr(data[i], field_name).reshape(-1, num_lr, height, width, features)
        nodes = torch.movedim(nodes, -1, 1)
        nonpadded_indices = torch.ones_like(nodes, dtype=torch.bool)
        nodes = F.pad(input=nodes, pad=(0, 0, 0, 0, 0, max_lrs_in_batch-num_lr, 0, 0, 0, 0), value=0.0)
        nonpadded_indices = F.pad(input=nonpadded_indices,
                                  pad=(0, 0, 0, 0, 0, max_lrs_in_batch-num_lr, 0, 0, 0, 0), value=False)
        result.append(nodes)
        indices.append(nonpadded_indices)
    result = torch.cat(result, dim=0)
    indices = torch.cat(indices, dim=0)
    return result, indices