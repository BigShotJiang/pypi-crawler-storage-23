import torch_geometric as tg
from torch_geometric.utils import grid
from torch_geometric.data import Batch
import torch
class ConvolutionalUpscaling(torch.nn.Module):
    """Graph-based convolutional upscaling using spline convolutions.

    Constructs a high-resolution point cloud from low-resolution graph data
    by placing target positions on a regular grid and performing message
    passing from neighbouring source nodes via radius-based connectivity.

    Args:
        scale (int): Spatial upsampling factor.
        in_channels (int): Number of input feature channels.
        out_channels (int): Number of output feature channels.
        nn (torch.nn.Module, optional): Custom message-passing network.
        transform (optional): Edge-attribute transform (defaults to Cartesian).
        legacy_mode (bool): If ``True``, uses legacy position handling.
        kernel_size (int, optional): Spline kernel size (defaults to ``scale ** 2``).
    """

    def __init__(self, scale: int = None, in_channels: int = None, out_channels: int = None,
                 nn=None, transform=None, legacy_mode=False, kernel_size=None):
        super().__init__()
        self.scale = scale
        self.radius = (2 ** .5)# if legacy_mode else (2**.5)*2./3.
        self.legacy_mode = legacy_mode
        self.transform = transform or tg.transforms.Cartesian(cat=False, max_value=self.radius)
        if kernel_size is None:
            if scale is None:
                raise ValueError('scale or kernel_size must be specified')
            kernel_size = scale*scale
        self.nn = nn or tg.nn.Sequential('x, edge_index, edge_attr', [
            (tg.nn.SplineConv(in_channels, out_channels, dim=2, kernel_size=kernel_size), 'x, edge_index, edge_attr -> x'),
            torch.nn.PReLU()
        ])

    def forward_hr_pos(self, in_data: Batch, x: torch.Tensor, r=3):
        """Upscale using pre-defined high-resolution positions from the input data."""
        from srforge.nn.graph.transforms import cartesian
        device = x.device
        hr_pos = in_data.hr_pos
        pos = in_data.pos
        new_batch = torch.arange(in_data.batch.max() + 1, device=device).repeat_interleave(hr_pos.shape[1])
        hr_pos = hr_pos.view(-1, 2)
        r = r * 2**0.5
        assign_index = tg.nn.radius(hr_pos, pos, r=r, max_num_neighbors=250, batch_x=new_batch, batch_y=in_data.batch)
        edge_attr = cartesian((pos, hr_pos), assign_index, max_value=r)

        empty_x = torch.zeros(hr_pos.shape[0], x.shape[1], device=device)
        lrs = self.nn((x, empty_x), assign_index, edge_attr)
        new_batch = torch.arange(in_data.batch.max() + 1, device=device).repeat_interleave(hr_pos.shape[0])


        # plt.figure()
        # plt.scatter(hr_pos[:, 0].cpu().numpy(), hr_pos[:, 1].cpu().numpy(), c='b', s=1)
        # plt.scatter(pos[:, 0].cpu().numpy(), pos[:, 1].cpu().numpy(), c='r', s=1)
        # plt.scatter(hr_pos[~torch.isin(torch.arange(hr_pos.shape[0], device=device), assign_index[1]), 0].cpu().numpy(),
        #             hr_pos[~torch.isin(torch.arange(hr_pos.shape[0], device=device), assign_index[1]), 1].cpu().numpy(),
        #             c='g', s=1)
        # plt.gca().invert_yaxis()
        # plt.show()

        return tg.data.Data(lrs=lrs, pos=pos, batch=new_batch)

    def forward_org(self, data: Batch, x: torch.Tensor, scale=None, pos_mean=True):
        """Upscale by constructing a regular HR grid from original node shapes."""
        from srforge.nn.graph.transforms import cartesian
        if not (scale is not None or self.scale is not None or 'hr_pos' in data):
            raise ValueError('scale must be specified')
        if 'hr_pos' in data:
            return self.forward_hr_pos(data, x, scale)
        if scale is None:
            scale = self.scale

        device = x.device
        _, template_pos = grid(data.nodes_org_shape[0][-2] * scale,
                               data.nodes_org_shape[0][-1] * scale, device=device)

        template_pos[:, [0, 1]] = template_pos[:, [1, 0]]  # Swap x and y coordinates
        template_pos[:, 0] = template_pos[0, 0] - template_pos[:, 0]

        if pos_mean:
            pos = []
            template_pos = template_pos / scale
            template_mean = template_pos.mean(dim=0)
            for i in range(data.num_graphs):
                pos_median = data[i].pos.mean(dim=0)
                diff = template_mean - pos_median
                pos.append(template_pos - diff)
            pos = torch.cat(pos, dim=0)
        else:
            template_pos = (template_pos - (scale-1)/2)/scale
            pos = template_pos.repeat((data.batch.max() + 1, 1))

        empty_x = torch.zeros(pos.shape[0], x.shape[1], device=device)
        new_batch = torch.arange(data.batch.max() + 1, device=device).repeat_interleave(template_pos.shape[0])
        assign_index = tg.nn.radius(pos, data.pos, r=self.radius, batch_x=new_batch, batch_y=data.batch,
                              max_num_neighbors=250)
        edge_attr = cartesian((data.pos, pos), assign_index, max_value=self.radius)
        lrs = self.nn((x, empty_x), assign_index, edge_attr)

        # torch.save({'upscaled_lrs': lrs, 'upscaled_pos': pos, 'batch': data, 'assign_index': assign_index,
        #             'edge_attr': edge_attr}, 'upscaling_debug.pt')
        # raise Exception('Debugging upscaling')
        return tg.data.Data(lrs=lrs, pos=pos, batch=new_batch)


    def forward(self, data: Batch, x: torch.Tensor, scale=None, pos_mean=True):
        from srforge.nn.graph.transforms import cartesian
        if not (scale is not None or self.scale is not None or 'hr_pos' in data):
            raise ValueError('scale must be specified')
        if 'hr_pos' in data:
            return self.forward_hr_pos(data, x, scale)
        if scale is None:
            scale = self.scale

        device = x.device
        if 'hr' in data and isinstance(data.hr, dict):
            hr_h, hr_w = data.hr['b8'].shape[-2], data.hr['b8'].shape[-1]
        elif 'hr' in data and isinstance(data.hr, torch.Tensor):
            hr_h, hr_w = data.hr.shape[-2], data.hr.shape[-1]
        else:
            hr_h = data.nodes_org_shape[0][-2] * scale
            hr_w = data.nodes_org_shape[0][-1] * scale
        _, template_pos = grid(hr_h, hr_w, device=device)

        template_pos[:, [0, 1]] = template_pos[:, [1, 0]]  # Swap x and y coordinates
        template_pos[:, 0] = template_pos[0, 0] - template_pos[:, 0]

        if pos_mean:
            pos = []
            template_pos = template_pos / scale
            template_mean = template_pos.mean(dim=0)
            for i in range(data.num_graphs):
                pos_median = data[i].pos.mean(dim=0)
                diff = template_mean - pos_median
                pos.append(template_pos - diff)
            pos = torch.cat(pos, dim=0)
        else:
            # template_pos = (template_pos - (scale-1)/2)/scale
            template_pos = (template_pos + 0.5)/scale
            pos = template_pos.repeat((data.batch.max() + 1, 1))

        empty_x = torch.zeros(pos.shape[0], x.shape[1], device=device)
        new_batch = torch.arange(data.batch.max() + 1, device=device).repeat_interleave(template_pos.shape[0])
        assign_index = tg.nn.radius(pos, data.pos, r=self.radius, batch_x=new_batch, batch_y=data.batch,
                              max_num_neighbors=250)
        edge_attr = cartesian((data.pos, pos), assign_index, max_value=self.radius)
        lrs = self.nn((x, empty_x), assign_index, edge_attr)

        return tg.data.Data(lrs=lrs, pos=pos, batch=new_batch)