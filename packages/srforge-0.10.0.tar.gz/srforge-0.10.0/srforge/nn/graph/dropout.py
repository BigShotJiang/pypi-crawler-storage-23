import torch
import torch.nn as nn
from typing import Optional, Tuple


class EdgeDropout(nn.Module):
    def __init__(self, dropout_prob: float = 0.5, mask_self_loops: bool = False):
        """
        Initialize the EdgeDropout module.

        Args:
            dropout_prob (float): The probability of dropping an edge.
                                  Should be in the interval [0, 1].
            mask_self_loops (bool): If False, self-loop edges are preserved and never dropped.
                              If True, all edges are subject to dropout.
        """
        super().__init__()
        if not 0.0 <= dropout_prob <= 1.0:
            raise ValueError("dropout_prob must be between 0 and 1.")
        self.dropout_prob = dropout_prob
        self.mask_self_loops = mask_self_loops

    def forward(self,
                edge_index: torch.Tensor,
                edge_attr: Optional[torch.Tensor] = None
                ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """
        Perform edge dropout on the given edge_index and edge_attr.

        Args:
            edge_index (torch.Tensor): Tensor of shape [2, num_edges] containing edge indices.
            edge_attr (Optional[torch.Tensor]): Tensor of shape [num_edges, D] (optional) containing edge attributes.

        Returns:
            A tuple (edge_index, edge_attr) with the same structure as the input but with some edges dropped.
        """
        # Only apply dropout during training mode and if dropout_prob > 0
        if not self.training or self.dropout_prob == 0.0:
            return edge_index, edge_attr

        num_edges = edge_index.size(1)

        # Create a mask to identify self-loops: edges where source equals target.
        self_loop_mask = (edge_index[0] == edge_index[1])

        # Decide which edges to drop
        dropout_mask = torch.rand(num_edges, device=edge_index.device) >= self.dropout_prob

        # If self-loops are to be preserved, combine masks accordingly.
        if not self.mask_self_loops:
            # Retain self-loops regardless of dropout decision.
            final_mask = dropout_mask | self_loop_mask
        else:
            # If masking self-loops is allowed, use the dropout mask directly.
            final_mask = dropout_mask

        # Apply the mask to edge_index.
        edge_index = edge_index[:, final_mask]

        # Also drop the corresponding edge_attr values if provided.
        if edge_attr is not None:
            edge_attr = edge_attr[final_mask]

        return edge_index, edge_attr