import torch
from torch import Tensor
from torch_geometric.typing import OptPairTensor

def cartesian(pos, edge_index, edge_attr=None, max_value=None, norm=True, cat=True):
    (row, col), pos, pseudo = edge_index, pos, edge_attr
    if isinstance(pos, Tensor):
        pos: OptPairTensor = (pos, pos)

    cart = pos[0][row] - pos[1][col]
    cart = cart.view(-1, 1) if cart.dim() == 1 else cart

    if norm and cart.numel() > 0:
        max_value = cart.abs().max() if max_value is None else max_value
        cart = cart / (2 * max_value) + 0.5

    if pseudo is not None and cat:
        pseudo = pseudo.view(-1, 1) if pseudo.dim() == 1 else pseudo
        edge_attr = torch.cat([pseudo, cart.type_as(pseudo)], dim=-1)
    else:
        edge_attr = cart

    return edge_attr
