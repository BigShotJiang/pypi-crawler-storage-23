# srforge/_paths.py
from __future__ import annotations
from pathlib import Path
import sys, os
from typing import Optional
try:
    import tomllib  # py311+
except ModuleNotFoundError:
    import tomli as tomllib  # py310 fallback
from platformdirs import PlatformDirs

def _project_root_from_main_or_cwd() -> Optional[Path]:
    main_file = getattr(sys.modules.get("__main__"), "__file__", None)
    start = Path(main_file).resolve().parent if main_file else Path.cwd()
    for p in [start] + list(start.parents):
        if (p / "pyproject.toml").exists() or (p / ".git").exists():
            return p
    return None

def _pyproject_config(root: Path) -> dict:
    cfg = {}
    py = root / "pyproject.toml"
    if py.exists():
        with py.open("rb") as f:
            data = tomllib.load(f)
        cfg = data.get("tool", {}).get("srforge", {})
    return cfg

def default_metadata_dir() -> Path:
    # 1) Hydra original CWD (keeps files under the project when Hydra changes cwd)
    try:
        from hydra.utils import get_original_cwd
        pr = Path(get_original_cwd())
        cfg = _pyproject_config(pr)
        rel = cfg.get("metadata_dir", ".srforge/metadata")
        return (pr / rel).resolve()
    except Exception:
        pass

    # 2) Nearest project root (pyproject.toml or .git)
    pr = _project_root_from_main_or_cwd()
    if pr:
        cfg = _pyproject_config(pr)
        rel = cfg.get("metadata_dir", ".srforge/metadata")
        return (pr / rel).resolve()

    # 3) Fallback to user cache like other libs (~/.cache/srforge/metadata on Linux)
    d = PlatformDirs(appname="srforge", appauthor=False)
    return Path(d.user_cache_dir) / "metadata"