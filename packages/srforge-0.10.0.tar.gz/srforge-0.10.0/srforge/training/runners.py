"""
Individual runners i.e. classes that execute epochs in a training process.

"""
import os
from typing import Union, Optional

from typing import List

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
import abc
import logging

import torch
from torch.utils import data
from torch import optim
from torch import nn
try:
    from torch_geometric.data import Batch
except ImportError:
    Batch = None
from torch.amp import GradScaler
from torch.amp import autocast

from srforge.events import runner as runner_events
from srforge import observers
from srforge.loss import Loss
from srforge.loss.schedule import LossScheduler
from srforge.loss.storage import MetricScores

#: Type alias for anything callable as a loss criterion.
Criterion = Union[Loss, LossScheduler]
from srforge.models import Model
from srforge.data.entry import Entry, GraphEntry, _merge_fields
from srforge.registry import register_class
# from torchviz import make_dot

logger = logging.getLogger(__name__)

class EpochRunner(abc.ABC, observers.Observable):
    """
    Base class defining an interface for running a single pass through the whole input dataset
    """
    _scope: str = ""

    @property
    def scope(self) -> str:
        """Scope tag used by :class:`EventBus` for filtering."""
        return self._scope

    def __init__(self, scope: str = None):
        if scope is not None:
            self._scope = scope
        observers.Observable.__init__(self)
        self._criterion: Optional[Criterion] = None

    def get_criterion(self) -> Optional[Criterion]: return self._criterion
    def set_criterion(self, criterion: Criterion):
        if criterion is not self._criterion:
            logger.info(f"{self.__class__.__name__}: Criterion set to {criterion}.")
            self._criterion = criterion

    @abc.abstractmethod
    def run_epoch(self, model: nn.Module, data_loader: data.DataLoader, epoch: int) -> MetricScores:
        """
        :param model: Model to run epoch on.
        :param data_loader: Loader return batches of tuples (input, label)
        :param epoch: Current epoch index.
        :return: Epoch loss
        """


@register_class
class TrainingEpochRunner(EpochRunner):
    """
    Runs training procedure, executing backward propagation with optional
    gradient accumulation. Observers are notified.
    """
    _scope = "train"

    def __init__(self,
                 optimizer: optim.Optimizer,
                 criterion: Optional[Criterion] = None,
                 device: Union[torch.device, str] = 'cpu',
                 postprocessor: List = None,
                 mixed_precision: bool = False,
                 gradient_accumulation_steps: int = 1,
                 scope: str = None,
                 **kwargs):
        super().__init__(scope=scope)
        self.optimizer = optimizer
        self.set_criterion(criterion)
        self._device = device
        self.postprocessor = postprocessor or []

        self.mixed_precision = mixed_precision
        self.scaler = GradScaler(self._device, enabled=mixed_precision)
        self.gradient_accumulation_steps = max(1, gradient_accumulation_steps)
        self._kwargs = kwargs

    def run_epoch(self, model: Model, data_loader: data.DataLoader, epoch: int) -> MetricScores:
        model.train(True)
        score_accumulator = MetricScores.empty()

        self.notify(runner_events.RunnerEpochStarted(
            epoch=epoch,
            dataset_size=len(data_loader.dataset),
            batch_size=data_loader.batch_size,
            num_batches=len(data_loader)
        ))

        # initialize grads to zero *once*
        self.optimizer.zero_grad(set_to_none=True)
        with torch.autograd.set_detect_anomaly(True):
            for batch_idx, entry in enumerate(data_loader):
                torch.cuda.memory.empty_cache()

                with autocast('cuda', enabled=self.mixed_precision):
                    # forward
                    if not isinstance(entry, list):
                        entry = entry.to(self._device)
                    output = model(entry)
                    if isinstance(entry, list):
                        entry = Batch.from_data_list(entry).to(self._device)
                    if isinstance(output, (Entry, GraphEntry)):
                        entry = output
                    elif isinstance(output, dict):
                        if hasattr(entry, "merge_fields"):
                            entry = entry.merge_fields(output, source="model")
                        else:
                            entry = _merge_fields(entry, output, source="model")
                    else:
                        raise TypeError(f"Unsupported model output type: {type(output)}")
                    for t in self.postprocessor:
                        entry = t(entry)

                    # compute losses
                    batch_scores = self._criterion(entry)
                    total_loss = batch_scores.total_weighted()

                # ---- GRADIENT ACCUMULATION LOGIC ----
                # scale down the loss so that over N steps it's equivalent to one big batch
                accum_loss = total_loss / self.gradient_accumulation_steps

                # Debugging: visualize computation graph
                # if batch_idx == 0:
                #     dot = make_dot(accum_loss, params=dict(model.named_parameters()), show_attrs=True, show_saved=True)
                #     from srforge import GlobalSettings
                #     out_dir = GlobalSettings().output_directory
                #     out_path = os.path.join(out_dir, 'debug', f"graph_{epoch}_{batch_idx}.pdf")
                #     dot.render(out_path, format='pdf', cleanup=True)
                #     logger.info(f"Graph saved to {out_path}")
                self.scaler.scale(accum_loss.mean()).backward()

                # Debugging: check for missing gradients
                # for name, p in model.named_parameters():
                #     if p.requires_grad:
                #         if p.grad is None or torch.all(p.grad == 0):
                #             logger.warning(f"No grad in param: {str(name)}")

                # only step & zero every N batches (or on last batch)
                is_last_batch = (batch_idx == len(data_loader) - 1)
                if ((batch_idx + 1) % self.gradient_accumulation_steps == 0) or is_last_batch:
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                    self.optimizer.zero_grad(set_to_none=True)
                    logger.debug(f"Optimizer step at batch {batch_idx}.")
                # prof.step()
                # --------------------------------------

                # log & accumulate
                score_accumulator.add_scores(batch_scores.detached())

                self.notify(runner_events.RunnerBatchFinished(
                    epoch=epoch,
                    batch=batch_idx,
                    entry=entry,
                    batch_scores=batch_scores,
                    criterion=self._criterion,
                    epoch_scores=score_accumulator
                ))

                # free memory
                del output, entry, batch_scores, total_loss, accum_loss

        # finalize: epoch-level means
        self.notify(runner_events.RunnerEpochFinished(
            epoch=epoch,
            epoch_scores=score_accumulator
        ))

        return score_accumulator

@register_class
class ValidationEpochRunner(EpochRunner):
    """
    Passes through validation dataset without backward propagation.
    Observers are notified.
    """
    _scope = "val"

    def __init__(self,
                 loss_fn: Optional[Criterion] = None,
                 criterion: Optional[Criterion] = None,
                 device: Union[str, torch.device] = 'cpu',
                 postprocessor: List = None,
                 mixed_precision: bool = False,
                 scope: str = None):
        super().__init__(scope=scope)
        if loss_fn is not None:
            logger.critical("ValidationEpochRunner: 'loss_fn' argument is deprecated; use 'criterion' instead. This argument will be removed in future versions.")
        self._criterion = loss_fn or criterion
        self._device = device
        self.postprocessor = postprocessor or []
        self.mixed_precision = mixed_precision

    def run_epoch(self, model: nn.Module, data_loader: data.DataLoader, epoch: int) -> MetricScores:
        model.train(False)
        score_accumulator = MetricScores.empty()
        self.notify(runner_events.RunnerEpochStarted(
            epoch=epoch,
            dataset_size=len(data_loader.dataset),
            batch_size=data_loader.batch_size,
            num_batches=len(data_loader)
        ))
        with torch.no_grad():
            with autocast('cuda', enabled=self.mixed_precision):
                for batch_idx, entry in enumerate(data_loader):
                    torch.cuda.memory.empty_cache()
                    if not isinstance(entry, list):
                        entry = entry.to(self._device)
                    output = model(entry)
                    if isinstance(entry, list):
                        entry = Batch.from_data_list(entry).to(self._device)
                    if isinstance(output, (Entry, GraphEntry)):
                        entry = output
                    elif isinstance(output, dict):
                        if hasattr(entry, "merge_fields"):
                            entry = entry.merge_fields(output, source="model")
                        else:
                            entry = _merge_fields(entry, output, source="model")
                    else:
                        raise TypeError(f"Unsupported model output type: {type(output)}")
                    for t in self.postprocessor:
                        entry = t(entry)
                    batch_scores = self._criterion(entry)
                    score_accumulator.add_scores(batch_scores.detached())

                    self.notify(runner_events.RunnerBatchFinished(
                        epoch=epoch,
                        batch=batch_idx,
                        entry=entry,
                        batch_scores=batch_scores,
                        criterion=self._criterion,
                        epoch_scores=score_accumulator
                    ))

                    del output, entry, batch_scores
                self.notify(runner_events.RunnerEpochFinished(
                    epoch=epoch,
                    epoch_scores=score_accumulator
                ))
        return score_accumulator


@register_class
class BenchmarkRunner(EpochRunner):
    """
    Passes through validation dataset without backward propagation.
    Observers are notified.
    """
    _scope = "benchmark"

    def __init__(self,
                 loss_fn: Optional[Criterion] = None,
                 criterion: Optional[Criterion] = None,
                 device: Union[str, torch.device] = 'cpu',
                 postprocessor: List = None,
                 mixed_precision: bool = False,
                 scope: str = None):
        super().__init__(scope=scope)
        if loss_fn is not None:
            logger.critical("BenchmarkRunner: 'loss_fn' argument is deprecated; use 'criterion' instead. This argument will be removed in future versions.")
        self._criterion = loss_fn or criterion
        self._device = device
        self.postprocessor = postprocessor or []
        self.mixed_precision = mixed_precision

    def run_epoch(self, model: nn.Module, data_loader: data.DataLoader, epoch: int) -> MetricScores:
        model.train(False)
        score_accumulator = MetricScores.empty()
        self.notify(runner_events.RunnerEpochStarted(
            epoch=epoch,
            dataset_size=len(data_loader.dataset),
            batch_size=data_loader.batch_size,
            num_batches=len(data_loader)
        ))
        with torch.no_grad():
            with autocast('cuda', enabled=self.mixed_precision):
                for batch_idx, entry in enumerate(data_loader):
                    if not isinstance(entry, list):
                        entry = entry.to(self._device)
                    output = model(entry)
                    if isinstance(entry, list):
                        entry = Batch.from_data_list(entry).to(self._device)
                    if isinstance(output, (Entry, GraphEntry)):
                        entry = output
                    elif isinstance(output, dict):
                        if hasattr(entry, "merge_fields"):
                            entry = entry.merge_fields(output, source="model")
                        else:
                            entry = _merge_fields(entry, output, source="model")
                    else:
                        raise TypeError(f"Unsupported model output type: {type(output)}")
                    for t in self.postprocessor:
                        entry = t(entry)
                    if self._criterion is not None:
                        batch_scores = self._criterion(entry)
                        score_accumulator.add_scores(batch_scores.detached())
                    else:
                        batch_scores = MetricScores.empty()

                    self.notify(runner_events.RunnerBatchFinished(
                        epoch=epoch,
                        batch=batch_idx,
                        entry=entry,
                        batch_scores=batch_scores,
                        criterion=self._criterion,
                        epoch_scores=score_accumulator
                    ))

                    del output
                    del entry
                    del batch_scores
                self.notify(runner_events.RunnerEpochFinished(
                    epoch=epoch,
                    epoch_scores=score_accumulator
                ))
        return score_accumulator
