"""
Module with trainers i.e. classes responsible for training of a model.
Classes defined here are responsible for passing through the dataset
using training and validation runners defined in superdeep.runners package.
Observers are called with various events.
"""
import abc
from typing import Union
import logging

import torch.optim.lr_scheduler
from torch.utils import data
from torch import optim

import srforge.events.trainer
from srforge.training import stop, schedule
from srforge.training import runners
from srforge.events import trainer as trainer_events
from srforge import observers
from srforge.observers.bus import EventBus
from srforge.models import Model
from srforge.loss.schedule import LossScheduler, Loss
from srforge.registry import register_class


logger = logging.getLogger(__name__)

class Trainer(abc.ABC, observers.Observable):
    @abc.abstractmethod
    def train(self, epochs: int, training_loader, validation_loader):
        """
        Performs training of a model.
        """


@register_class
class PyTorchTrainer(Trainer):
    """Generalized approach for training pytorch model."""

    def __init__(self, model: Union[Model, torch.nn.Module],
                 training_epoch_runner: runners.EpochRunner,
                 validation_epoch_runner: runners.EpochRunner,
                 training_criterion: Union[Loss, LossScheduler] = None,
                 validation_criterion: Union[Loss, LossScheduler] = None,
                 lr_scheduler: torch.optim.lr_scheduler.LRScheduler = None,
                 stop_condition: stop.StopCondition = stop.NoCondition()):
        super().__init__()
        self.model = model
        self.training_runner = training_epoch_runner
        self.validation_runner = validation_epoch_runner
        self.stop_condition = stop_condition
        self.initial_epoch = 0
        self.best_losses = None
        self.lr_scheduler = lr_scheduler or schedule.BlankLRScheduler()
        self.training_criterion = self._resolve_criterion(
            training_epoch_runner, training_criterion, "training"
        )
        self.validation_criterion = self._resolve_criterion(
            validation_epoch_runner, validation_criterion, "validation"
        )
    @property
    def event_bus(self) -> EventBus:
        """The shared event bus for this training session."""
        return self._event_bus

    def restore(self, checkpoint: "CheckpointState | None") -> None:
        """Apply a checkpoint to this trainer.

        Sets ``initial_epoch``, ``best_losses``, and restores the GradScaler
        state if present.  Accepts ``None`` (no-op for fresh runs).

        Args:
            checkpoint: A :class:`~srforge.utils.checkpoint.CheckpointState`
                returned by :func:`~srforge.utils.checkpoint.resume_from_checkpoint`,
                or ``None``.
        """
        if checkpoint is None:
            return
        self.initial_epoch = checkpoint.epoch + 1
        self.best_losses = checkpoint.best_losses
        if checkpoint.scaler_state is not None:
            self.training_runner.scaler.load_state_dict(checkpoint.scaler_state)

    def _resolve_criterion(
            self,
            runner: runners.EpochRunner,
            provided_criterion: Union[Loss, LossScheduler, None],
            phase_name: str,
    ) -> Union[Loss, LossScheduler]:
        """Resolve the criterion for *runner* and set it.

        If *provided_criterion* is ``None``, falls back to the runner's
        existing criterion (deprecated).  If it is a
        :class:`LossScheduler`, advances it to ``initial_epoch``.
        The criterion (Loss **or** LossScheduler) is passed directly to
        the runner — no unwrapping.
        """
        criterion = provided_criterion
        if criterion is None:
            logger.warning(
                f"No {phase_name} criterion provided for {self.__class__.__name__}, using the one from {phase_name} runner. "
                f"THIS BEHAVIOR IS DEPRECATED AND WILL BE REMOVED IN FUTURE VERSIONS. "
                f"Please provide the {phase_name} criterion explicitly to the {self.__class__.__name__} constructor."
            )
            if runner.get_criterion() is None:
                raise ValueError(
                    f"No {phase_name} criterion provided for both {self.__class__.__name__} and the {phase_name} runner."
                )
            criterion = runner.get_criterion()

        if isinstance(criterion, LossScheduler):
            criterion.update(self.initial_epoch)

        runner.set_criterion(criterion)
        return criterion

    def train(self, epochs: int,
              training_loader: data.DataLoader,
              validation_loader: data.DataLoader):
        self.notify(trainer_events.TrainingBegan(
            total_epochs=epochs,
            initial_epoch=self.initial_epoch,
            train_batches_per_epoch=len(training_loader),
            val_batches_per_epoch=len(validation_loader),
            best_losses=self.best_losses,
        ))
        for epoch in range(self.initial_epoch, epochs):
            if isinstance(self.training_criterion, LossScheduler):
                self.training_criterion.update(epoch)
            if isinstance(self.validation_criterion, LossScheduler):
                self.validation_criterion.update(epoch)

            loss = self.training_runner.run_epoch(self.model, training_loader, epoch)
            val_loss = self.validation_runner.run_epoch(self.model, validation_loader, epoch)

            self.notify(trainer_events.TrainerEpochFinished(
                optimizer=self.training_runner.optimizer,
                lr_scheduler=self.lr_scheduler,
                model=self.model,
                train_loss=loss,
                val_loss=val_loss,
                epoch=epoch,
                scaler=self.training_runner.scaler
            ))

            val_loss_total_mean = val_loss.total_weighted().mean()
            if isinstance(self.lr_scheduler, optim.lr_scheduler.ReduceLROnPlateau):
                self.lr_scheduler.step(val_loss_total_mean)
            else:
                self.lr_scheduler.step()
            if self.stop_condition.is_condition_satisfied(epoch, loss.total_weighted().mean().item(), val_loss_total_mean.item()):
                break