from torch.optim.lr_scheduler import LRScheduler

class BlankLRScheduler(LRScheduler):
    """A no-op learning rate scheduler that never changes the learning rate."""

    def step(self, *args, **kwargs):
        """Do nothing — the learning rate remains unchanged."""
        pass