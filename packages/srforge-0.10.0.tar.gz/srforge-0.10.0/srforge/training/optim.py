import torch.optim as optim

class Adam(optim.Adam):
    pass
class AdamW(optim.AdamW):
    pass

class SGD(optim.SGD):
    pass

class RMSprop(optim.RMSprop):
    pass

class Adadelta(optim.Adadelta):
    pass

class Adagrad(optim.Adagrad):
    pass

class SparseAdam(optim.SparseAdam):
    pass

class Adamax(optim.Adamax):
    pass

class ASGD(optim.ASGD):
    pass

class LBFGS(optim.LBFGS):
    pass

class Rprop(optim.Rprop):
    pass

class RAdam(optim.RAdam):
    pass

