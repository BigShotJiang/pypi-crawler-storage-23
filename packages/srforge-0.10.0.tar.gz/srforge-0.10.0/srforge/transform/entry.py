"""
Module with transformations over entries aka :class:`Entry`.

"""
import logging
from skimage.registration import phase_cross_correlation
from scipy.ndimage import shift
from typing import Union, Dict, Literal, Iterable, Tuple, Sequence, List, Any, Mapping, Optional
import copy

import numpy as np
import cv2
import torch
import torch.nn.functional as F
from torchvision import transforms
from torchvision.transforms.functional import crop

from srforge.data import Entry, GraphEntry
from srforge.data.multispectral.descriptors import MultiSpectralDescriptor
from srforge.transform import EntryTransform
from srforge.registry import register_class
from srforge.utils.deprecation import deprecated_class
from srforge.utils import IOSpec

logger = logging.getLogger(__name__)


def _filter_bands_in_entry(
    entry: Entry,
    keep: Optional[set[str]] = None,
    remove: Optional[set[str]] = None,
    bands_var: str = "bands",
) -> Entry:
    if keep is not None and remove is not None:
        raise ValueError("Provide either keep or remove, not both.")
    for key in list(entry.keys()):
        value = entry[key]
        if isinstance(value, dict):
            if keep is not None:
                entry[key] = {k: v for k, v in value.items() if k in keep}
            else:
                entry[key] = {k: v for k, v in value.items() if k not in remove}
    if bands_var in entry:
        bands = entry[bands_var]
        if isinstance(bands, list) and bands and isinstance(bands[0], list):
            if keep is not None:
                entry[bands_var] = [[b for b in inner if b in keep] for inner in bands]
            else:
                entry[bands_var] = [[b for b in inner if b not in remove] for inner in bands]
        elif isinstance(bands, list):
            if keep is not None:
                entry[bands_var] = [b for b in bands if b in keep]
            else:
                entry[bands_var] = [b for b in bands if b not in remove]
    return entry

@register_class
class LeaveBands(EntryTransform):
    io_spec = IOSpec(required_inputs=("bands",), required_outputs=("bands",))

    def __init__(self, bands_to_leave: Union[str, List[str]]):
        """
        Leaves only specified bands in a multispectral Entry (dict-of-bands) and removes all other bands.
        :param bands_to_leave: A single band name or a list of band names to be left.
        """
        if isinstance(bands_to_leave, str):
            bands_to_leave = [bands_to_leave]
        self.bands_to_leave = bands_to_leave
        super().__init__()

    def transform(self, entry: Entry):
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry):
        keep = set(self.bands_to_leave)
        return _filter_bands_in_entry(entry, keep=keep, bands_var=self.bands)


@register_class
class RemoveBands(EntryTransform):
    io_spec = IOSpec(required_inputs=("bands",), required_outputs=("bands",))

    def __init__(self, bands_to_remove: Union[str, List[str]]):
        """
        Removes specified bands from a multispectral Entry (dict-of-bands).
        :param bands: A single band name or a list of band names to be removed.
        """
        if isinstance(bands_to_remove, str):
            bands_to_remove = [bands_to_remove]
        self.bands_to_remove = bands_to_remove
        super().__init__()

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        remove = set(self.bands_to_remove)
        return _filter_bands_in_entry(entry, remove=remove, bands_var=self.bands)


@register_class
class SetAttribute(EntryTransform):
    """
    An EntryTransform that sets an attribute in an Entry.
    The attribute is set to the value provided in the constructor.
    """
    io_spec = IOSpec(required_outputs=("attr",))

    def __init__(self, value: Any):
        super().__init__()
        self.value = value

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        entry[self.attr] = self.value
        return entry

@register_class
class StackBands(EntryTransform):
    """
    Stacks multispectral bands into a single entry.
    Every attribute in each band-mapped field of the Entry is going to be concatenated. If all the bands have the same
    values for the attribute, the resulting entry will have the same value for that attribute to avoid duplication.
    """
    io_spec = IOSpec(
        required_inputs=("bands_list", "field"),
        required_outputs=("bands_list",),
        optional_outputs=("output",),
    )

    def __init__(self,
                 bands_descriptor: Optional[MultiSpectralDescriptor] = None):
        self.bands_descriptor = bands_descriptor
        super().__init__()

    def transform(self, entry: Entry):
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry):
        field_value = entry[self.field]
        entry_bands_raw = entry[self.bands_list]

        # Extract canonical band list from batch-wrapped format [["b1", "b2"], ...]
        if isinstance(entry_bands_raw, list) and entry_bands_raw and isinstance(entry_bands_raw[0], list):
            canonical_bands = entry_bands_raw[0]
        elif isinstance(entry_bands_raw, list):
            canonical_bands = entry_bands_raw
        else:
            canonical_bands = entry_bands_raw

        if self.bands_descriptor is None:
            if not isinstance(canonical_bands, list) or not canonical_bands:
                raise ValueError(
                    "No bands descriptor provided and entry has no 'bands' list. "
                    "Please provide a MultiSpectralDescriptor or ensure 'bands' is present."
                )
            bands = canonical_bands
        else:
            descriptor_bands = self.bands_descriptor.bands()
            if isinstance(canonical_bands, list) and canonical_bands:
                bands = [b for b in descriptor_bands if b in canonical_bands]
            else:
                bands = descriptor_bands
        if not bands:
            raise ValueError("No bands available for stacking after applying descriptor ordering.")

        if not isinstance(bands, list):
            raise TypeError(
                f"Expected 'bands' to be a list, got {type(bands)}. Please provide a MultiSpectralDescriptor or "
                "ensure 'bands' is a list of strings."
            )
        if not isinstance(field_value, dict):
            raise TypeError(
                "Expected input field to be a dictionary with band keys, "
                f"but got {type(field_value)}. Please ensure the field contains band-specific data."
            )
        stacked_data = []
        for band in bands:
            if band in field_value:
                stacked_data.append(field_value[band])
            else:
                logger.warning(f"Band '{band}' not found in field. Skipping this band.")
        if not stacked_data:
            raise ValueError(
                f"No data found for bands {bands} in field. "
                "Please ensure the field contains data for the specified bands."
            )
        if isinstance(stacked_data[0], torch.Tensor):
            if stacked_data[0].shape[1] == 1:
                stacked_data = torch.cat(stacked_data, dim=1)
            else:
                stacked_data = torch.stack(stacked_data, dim=1)
        elif isinstance(stacked_data[0], np.ndarray):
            raise NotImplementedError("Not implemented yet.")
        elif isinstance(stacked_data[0], list):
            stacked_data = [x for x in stacked_data if x is not None]
        else:
            raise TypeError(
                f"Unsupported data type {type(stacked_data[0])} for field. "
                "Please ensure the field contains tensors, numpy arrays, or lists."
            )
        target = self.output if self.output is not None else self.field
        entry[target] = stacked_data
        # Preserve batch-wrapped format for bands list
        if isinstance(entry_bands_raw, list) and entry_bands_raw and isinstance(entry_bands_raw[0], list):
            entry[self.bands_list] = [bands for _ in entry_bands_raw]
        else:
            entry[self.bands_list] = bands
        return entry


StackMultispectralToEntry = register_class("StackMultispectralToEntry")(
    deprecated_class("StackMultispectralToEntry", StackBands)
)

from typing import List, Literal, Mapping, Sequence, Any
import torch
import torch.nn.functional as F

@register_class
class ResizeFieldsToReference(EntryTransform):
    io_spec = IOSpec(
        required_inputs=("field", "reference"),
        optional_outputs=("output",),
    )

    def __init__(
            self,
            interpolation_mode: Literal['linear', 'bilinear', 'bicubic', 'trilinear', 'area'] = 'bicubic',
    ):
        super().__init__()
        self.interpolation_mode = interpolation_mode

    # ---- core tensor resize ----
    def _resize_tensor_to(self, x: torch.Tensor, ref: torch.Tensor) -> torch.Tensor:
        target_size = ref.shape[-2:]
        if x.shape[-2:] == target_size:
            return x

        # align_corners is only valid for these modes
        align_corners = False if self.interpolation_mode in {"linear", "bilinear", "bicubic", "trilinear"} else None

        # Make x NCHW for 2D interpolation
        if x.dim() == 2:          # HW
            x_ = x.unsqueeze(0).unsqueeze(0)   # 1x1xHxW
            squeeze_back = "hw"
        elif x.dim() == 3:        # CHW
            x_ = x.unsqueeze(0)                # 1xCxHxW
            squeeze_back = "chw"
        elif x.dim() == 4:        # NCHW
            x_ = x
            squeeze_back = None
        elif x.dim() == 5:        # NCKHW (treat K as sequence, keep it)
            b, c, k, h, w = x.shape
            x_ = x.permute(0, 2, 1, 3, 4).reshape(b * k, c, h, w)  # (B*K, C, H, W)
            squeeze_back = ("nckhw", b, k, c)
        else:
            raise TypeError(f"Unsupported tensor dim={x.dim()} for 2D resize. Tensor shape={tuple(x.shape)}")

        y = F.interpolate(x_, size=target_size, mode=self.interpolation_mode, align_corners=align_corners)

        if squeeze_back == "hw":
            return y.squeeze(0).squeeze(0)
        if squeeze_back == "chw":
            return y.squeeze(0)
        if isinstance(squeeze_back, tuple) and squeeze_back[0] == "nckhw":
            b, k, c = squeeze_back[1:]
            y = y.reshape(b, k, c, *target_size).permute(0, 2, 1, 3, 4)
            return y
        return y

    # ---- recursive container resize ----
    def _resize_like(self, value: Any, reference: Any, *, path: str = "") -> Any:
        # 1) Tensor leaf: ref must be Tensor
        if isinstance(value, torch.Tensor):
            if not isinstance(reference, torch.Tensor):
                raise TypeError(f"{path}: value is Tensor but reference is {type(reference)}")
            return self._resize_tensor_to(value, reference)

        # 2) Mapping (dict-like): reference can be Mapping (key-wise) or Tensor (broadcast)
        if isinstance(value, Mapping):
            if isinstance(reference, Mapping):
                missing = set(value.keys()) - set(reference.keys())
                if missing:
                    raise KeyError(f"{path}: keys {sorted(missing)} not found in reference mapping")
                out_items = {
                    k: self._resize_like(value[k], reference[k], path=f"{path}.{k}" if path else str(k))
                    for k in value.keys()
                }
            elif isinstance(reference, torch.Tensor):
                out_items = {
                    k: self._resize_like(v, reference, path=f"{path}.{k}" if path else str(k))
                    for k, v in value.items()
                }
            else:
                raise TypeError(f"{path}: value is Mapping but reference is {type(reference)} (expected Mapping or Tensor)")

            # preserve mapping type when possible
            try:
                return value.__class__(out_items)
            except Exception:
                return dict(out_items)

        # 3) Sequence (list/tuple-like): reference must also be a Sequence of SAME length (no broadcast)
        # (Avoid treating strings/bytes as sequences here.)
        if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
            if not (isinstance(reference, Sequence) and not isinstance(reference, (str, bytes, bytearray))):
                raise TypeError(f"{path}: value is Sequence but reference is {type(reference)} (expected Sequence)")
            if len(value) != len(reference):
                raise ValueError(f"{path}: sequence length {len(value)} != reference length {len(reference)}")

            resized = [
                self._resize_like(v, r, path=f"{path}[{i}]")
                for i, (v, r) in enumerate(zip(value, reference))
            ]
            return tuple(resized) if isinstance(value, tuple) else resized

        # 4) Unknown container/storage object
        raise TypeError(f"{path}: unsupported type {type(value)} (expected Tensor/Mapping/Sequence)")

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        field_value = entry[self.field]
        reference_obj = entry[self.reference]
        target = self.output if self.output is not None else self.field
        entry[target] = self._resize_like(field_value, reference_obj, path="field")

        return entry


@register_class
class RandomCrop(EntryTransform):
    """
    Randomly crops the images in the entry specified by the keys in the 'apply_to' list. The size of the crop is
    determined by the 'patch_size' parameter. If two specified images have different sizes, the given patch size is applied
    to the first image and the other images are cropped depending on the size ratio between the first image and the
    other images.

    Example: if the first image has size (100, 100) and the second image has size (200, 200), the first
    image will be cropped to (patch_size[0], patch_size[1]) and the second image will be cropped to
    (2 * patch_size[0], 2 * patch_size[1]).
    """

    io_spec = IOSpec(
        required_inputs=("field",),
        optional_outputs=("output",),
    )

    def __init__(self, patch_size: Union[int, List[int]]):
        if isinstance(patch_size, int):
            patch_size = (patch_size, patch_size)
        if not (len(patch_size) == 2):
            raise ValueError(f"Argument 'patch_size' for the RandomCrop transformation must be a list of two"
                             f" integers. Got: {patch_size}")
        super().__init__()
        self.patch_size = patch_size



    def _extract_tensor(self, value: Any) -> torch.Tensor:
        if isinstance(value, torch.Tensor):
            return value
        if isinstance(value, list) and value:
            return self._extract_tensor(value[0])
        if isinstance(value, tuple) and value:
            return self._extract_tensor(value[0])
        if isinstance(value, dict) and value:
            return self._extract_tensor(next(iter(value.values())))
        raise TypeError(f"Unsupported value type for RandomCrop: {type(value)}")

    def transform(self, entry: Entry) -> Entry:
        samples = entry.unbatch()
        results = [self.transform_unbatched(s) for s in samples]
        return Entry.collate(results)

    def transform_unbatched(self, entry: Entry) -> Entry:
        value = entry[self.field]
        tensor = self._extract_tensor(value)
        start_i, start_j, h, w = transforms.RandomCrop.get_params(tensor, output_size=self.patch_size)
        target = self.output if self.output is not None else self.field
        entry[target] = self._crop_image(value, start_i, start_j, h, w)
        return entry

    def _crop_image(self, image: Any, start_i: int, start_j: int, h: int, w: int) -> Any:
        if isinstance(image, torch.Tensor):
            return crop(image, start_i, start_j, h, w)
        if isinstance(image, list):
            return [self._crop_image(x, start_i, start_j, h, w) for x in image]
        if isinstance(image, dict):
            return {key: self._crop_image(value, start_i, start_j, h, w) for key, value in image.items()}


@register_class
class RegisterEntry(EntryTransform): # TODO: Right now it only accepts lists of tensors. It should accept Tensor or list of Tensors. This is because right now multiple images are by default loaded as lists of tensors with no collation even if they are all the same shape.
    io_spec = IOSpec(
        required_inputs=("field", "translations"),
        required_outputs=("field", "translations"),
    )

    def __init__(self,
                 precision: str = 'int', mode: str = 'reflect',
                 adjust_translations_after_registration: bool = False):
        if precision not in ['int', 'float']:
            raise ValueError(f"Wrong registration mode! Selected: {precision}; Available: ['int'. 'float'].")
        super().__init__()
        self.precision = precision
        self.mode = mode
        self.adjust_translations_after_registration = adjust_translations_after_registration

    # def transform(self, entry: Entry) -> Entry:
    #     return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        tr = entry[self.translations]
        if tr is None:
            raise ValueError(f"No translations calculated for LR images in {entry.name}!")
        if self.precision == 'int':
            if isinstance(tr, dict):
                tr = {k: np.round(v) for k, v in tr.items()}
            else:
                tr = np.round(tr)
        if self.adjust_translations_after_registration:
            if isinstance(tr, dict):
                entry[self.translations] = {k: entry[self.translations][k] - v for k, v in tr.items()}
            else:
                entry[self.translations] = entry[self.translations] - tr
        field_value = entry[self.field]
        if field_value is None:
            raise ValueError("Field value is None; cannot register.")
        def _to_numpy_translations(translations: Any, num_images: int) -> np.ndarray:
            if isinstance(translations, torch.Tensor):
                arr = translations.detach().cpu().numpy()
            else:
                arr = np.array(translations)
            if arr.ndim != 2 or arr.shape[0] != num_images or arr.shape[1] != 2:
                raise ValueError(
                    f"Translations must have shape (K, 2); got {arr.shape}."
                )
            return arr

        def _register_tensor(images: torch.Tensor, translations: Any) -> torch.Tensor:
            if images.dim() != 4:
                raise TypeError("Expected unbatched tensor of shape (C, K, H, W).")
            C, K = images.shape[0], images.shape[1]
            tr_np = _to_numpy_translations(translations, K)
            out = images.clone()
            for i in range(K):
                t = tr_np[i]
                for j in range(C):
                    out[j, i] = torch.from_numpy(shift(images[j, i].numpy(), -t, mode=self.mode))
            return out

        if isinstance(field_value, dict):
            for band, images in field_value.items():
                band_tr = tr[band] if isinstance(tr, dict) else tr
                if isinstance(images, torch.Tensor):
                    field_value[band] = _register_tensor(images, band_tr)
                    continue
                if not all(images[0].shape == images[i].shape for i in range(1, len(images))):
                    raise ValueError(f"Different shapes of field.{band} images in {entry.name}!")
                t = band_tr.detach().cpu().numpy() if isinstance(band_tr, torch.Tensor) else np.array(band_tr)
                for i in range(len(images)):
                    for j in range(images[i].shape[0]):
                        x: torch.Tensor = images[i][j]
                        images[i][j] = torch.from_numpy(shift(x.numpy(), -t[i], mode=self.mode))
            return entry

        if isinstance(field_value, torch.Tensor):
            entry[self.field] = _register_tensor(field_value, tr)
            return entry

        if not all(field_value[0].shape == field_value[i].shape for i in range(1, len(field_value))):
            raise ValueError(f"Different shapes of field images in {entry.name}!")
        t = tr.detach().cpu().numpy() if isinstance(tr, torch.Tensor) else np.array(tr)
        for i in range(len(field_value)):
            for j in range(field_value[i].shape[0]):
                x: torch.Tensor = field_value[i][j]
                field_value[i][j] = torch.from_numpy(shift(x.numpy(), -t[i], mode=self.mode))
        return entry


@register_class
class CalculateTranslations(EntryTransform): # TODO: Right now it only accepts lists of tensors. It should accept Tensor or list of Tensors. This is because right now multiple images are by default loaded as lists of tensors with no collation even if they are all the same shape.
    """
    Calculates translations as vectors FROM the reference image TO the target and saves them in a corresponding Entry object.
    Parameters:
    ----------
    upsample_factor : int
        The upsampling factor for subpixel accuracy.
    use_masks : bool
        Whether to use masks for registration. If True, only full-pixel registration can be performed. The default is False.
    ref_index: int
        Reference index for registration. The default is 0.
    key_to_save : str
        A key to save the calculated translations under in the Entry object. The default is "translations".
    """
    io_spec = IOSpec(
        required_inputs=("field",),
        optional_inputs=("masks", "leading"),
        required_outputs=("translations",),
    )

    def __init__(self,
                 upsample_factor: int = 100, use_masks: bool = False, ref_index: int = 0):
        super().__init__()
        self.upsample_factor = upsample_factor
        self.use_masks = use_masks
        self.ref_index = ref_index

    # def transform(self, entry: Entry):
    #     return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry):
        value = entry[self.field]
        masks_value = entry[self.masks] if self.use_masks and self.masks is not None else None
        leading_raw = entry[self.leading] if self.leading is not None else None
        leading_value = leading_raw[0] if isinstance(leading_raw, list) else leading_raw
        ref = 0 if leading_value else self.ref_index

        def _calc_for_list(images, masks):
            translations = []
            if self.use_masks:
                if not (masks is not None and all(x is not None for x in masks)):
                    raise ValueError(f"No masks provided for registration in {entry.name}.")
                if not (len(masks) == len(images)):
                    raise ValueError(f'Different number of images and masks in {entry.name}.')
                for i in range(len(images)):
                    shifts, *_ = phase_cross_correlation(
                        images[ref][0],
                        images[i][0],
                        reference_mask=masks[ref][0],
                        moving_mask=masks[i][0],
                        upsample_factor=self.upsample_factor
                    )
                    translations.append(-shifts)
            else:
                for i in range(len(images)):
                    shifts, *_ = phase_cross_correlation(
                        images[ref][0],
                        images[i][0],
                        upsample_factor=self.upsample_factor
                    )
                    translations.append(-shifts)
            return torch.from_numpy(np.stack(translations))

        def _calc_for_tensor(images: torch.Tensor, masks: Optional[torch.Tensor]) -> torch.Tensor:
            if images.dim() != 4:
                raise TypeError("Expected unbatched tensor of shape (C, K, H, W).")
            imgs_list = [images[:, i, ...] for i in range(images.shape[1])]
            masks_list = [masks[:, i, ...] for i in range(masks.shape[1])] if masks is not None else None
            return _calc_for_list(imgs_list, masks_list)

        if isinstance(value, dict):
            translations_dict = {}
            for band, images in value.items():
                band_masks = None
                if self.use_masks:
                    if isinstance(masks_value, dict):
                        band_masks = masks_value.get(band)
                    else:
                        band_masks = masks_value
                if isinstance(images, torch.Tensor):
                    translations_dict[band] = _calc_for_tensor(images, band_masks)
                else:
                    translations_dict[band] = _calc_for_list(images, band_masks)
            entry[self.translations] = translations_dict
            return entry

        if isinstance(value, torch.Tensor):
            translations = _calc_for_tensor(value, masks_value)
        else:
            translations = _calc_for_list(value, masks_value)
        entry[self.translations] = translations
        return entry


@register_class
class ChooseImages(EntryTransform):
    """
    Chooses the images from the list of low resolution images based on the mean of the clearance masks.
    """
    io_spec = IOSpec(
        required_inputs=("field",),
        optional_outputs=("output",),
    )

    def __init__(self, indices: Union[int, List[int]]):
        self.indices = indices
        super().__init__()


    def transform(self, entry: Entry) -> Entry:
        samples = entry.unbatch()
        results = [self.transform_unbatched(s) for s in samples]
        return Entry.collate(results)

    def transform_unbatched(self, entry: Entry) -> Entry:
        field_value = entry[self.field]
        if field_value is None:
            raise ValueError("Field value is None; cannot select images.")
        target = self.output if self.output is not None else self.field
        def _select_from_value(value: Any) -> Any:
            if isinstance(value, torch.Tensor) and value.dim() >= 5:
                if isinstance(self.indices, int):
                    return value[:, :, self.indices, ...]
                idx = torch.as_tensor(self.indices, device=value.device)
                return value.index_select(2, idx)
            if isinstance(value, list) and not isinstance(self.indices, int):
                return [value[i] for i in self.indices]
            return value[self.indices]

        if isinstance(field_value, dict):
            entry[target] = {k: _select_from_value(v) for k, v in field_value.items()}
        else:
            entry[target] = _select_from_value(field_value)
        return entry


@register_class
class ChooseClearestImages(EntryTransform):
    """
    Chooses the clearest images from the list of low resolution images based on the mean of the clearance masks.
    """

    io_spec = IOSpec(
        required_inputs=("lrs",),
        optional_inputs=("masks", "translations", "leading"),
        required_outputs=("lrs",),
        optional_outputs=("masks", "translations"),
    )

    def __init__(self, num_images: int):
        super().__init__()
        self._num_images = num_images

    def _select_indices(self, lrs: list, lr_masks: Optional[list], leading_lr: bool) -> List[int]:
        if lr_masks is None:
            if not (len(lrs) == self._num_images):
                raise ValueError("No masks provided for registration, but number of images is different than requested.")
            return list(range(len(lrs)))
        clear_percentages = sorted([(mask.mean(), i) for i, mask in enumerate(lr_masks)],
                                   key=lambda x: x[0], reverse=True)
        num_images = min(self._num_images, len(clear_percentages))
        if not (len(clear_percentages) >= num_images):
            raise ValueError("Not enough images to choose from. {} images requested, but only {} available.".format(
                self._num_images, len(clear_percentages)))
        clear_percentages = clear_percentages[:num_images]
        clear_percentages = sorted(clear_percentages, key=lambda x: x[1])
        clear_indices = [x[1] for x in clear_percentages]
        if leading_lr and 0 not in clear_indices:
            clear_indices = [0] + clear_indices[:-1]
        return clear_indices

    def _select_indices_tensor(
        self,
        masks: Optional[torch.Tensor],
        batch_size: int,
        num_images: int,
        leading_lr: bool,
    ) -> List[List[int]]:
        if masks is None:
            if num_images != self._num_images:
                raise AssertionError(
                    "No masks provided for registration, but number of images is different than requested."
                )
            return [list(range(num_images)) for _ in range(batch_size)]

        dims = [i for i in range(masks.dim()) if i not in (0, 2)]
        means = masks.mean(dim=tuple(dims))  # (B, K)
        indices: List[List[int]] = []
        for b in range(means.shape[0]):
            order = sorted(range(means.shape[1]), key=lambda i: means[b, i].item(), reverse=True)
            chosen = sorted(order[:min(self._num_images, len(order))])
            if leading_lr and 0 not in chosen:
                chosen = [0] + chosen[:-1]
            indices.append(chosen)
        return indices

    @staticmethod
    def _gather_tensor_by_indices(values: torch.Tensor, indices: List[List[int]]) -> torch.Tensor:
        out = []
        for b, idx in enumerate(indices):
            idx_tensor = torch.as_tensor(idx, device=values.device)
            out.append(values[b:b + 1].index_select(2, idx_tensor))
        return torch.cat(out, dim=0)

    @staticmethod
    def _gather_translations(values: torch.Tensor, indices: List[List[int]]) -> torch.Tensor:
        out = []
        for b, idx in enumerate(indices):
            idx_tensor = torch.as_tensor(idx, device=values.device)
            out.append(values[b].index_select(0, idx_tensor))
        return torch.stack(out, dim=0)

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        leading_raw = entry[self.leading] if self.leading is not None else None
        if isinstance(leading_raw, list):
            leading = bool(leading_raw[0]) if leading_raw else False
        else:
            leading = bool(leading_raw) if leading_raw is not None else False
        lrs_val = entry[self.lrs]
        masks_val = entry[self.masks] if self.masks is not None else None
        translations_val = entry[self.translations] if self.translations is not None else None

        if isinstance(lrs_val, dict):
            new_lrs = {}
            new_masks = {} if isinstance(masks_val, dict) else None
            new_tr = {} if isinstance(translations_val, dict) else None
            for band, lrs in lrs_val.items():
                band_masks = None
                if isinstance(masks_val, dict):
                    band_masks = masks_val.get(band)
                if isinstance(lrs, torch.Tensor):
                    if band_masks is not None and not isinstance(band_masks, torch.Tensor):
                        raise TypeError("Masks must be a tensor when lrs is a tensor.")
                    indices = self._select_indices_tensor(
                        band_masks, lrs.shape[0], lrs.shape[2], leading
                    )
                    new_lrs[band] = self._gather_tensor_by_indices(lrs, indices)
                    if new_masks is not None and band_masks is not None:
                        new_masks[band] = self._gather_tensor_by_indices(band_masks, indices)
                    if new_tr is not None and translations_val is not None:
                        band_tr = translations_val.get(band)
                        if isinstance(band_tr, torch.Tensor):
                            new_tr[band] = self._gather_translations(band_tr, indices)
                        elif band_tr is not None:
                            new_tr[band] = [band_tr[0:1, i] for i in indices[0]]
                else:
                    band_indices = self._select_indices(lrs, band_masks, leading)
                    new_lrs[band] = [lrs[i] for i in band_indices]
                    if new_masks is not None and band_masks is not None:
                        new_masks[band] = [band_masks[i] for i in band_indices]
                    if new_tr is not None and translations_val is not None:
                        band_tr = translations_val.get(band)
                        if band_tr is not None:
                            new_tr[band] = [band_tr[0:1, i] for i in band_indices]
            entry[self.lrs] = new_lrs
            if self.masks is not None and new_masks is not None:
                entry[self.masks] = new_masks
            if self.translations is not None and new_tr is not None:
                entry[self.translations] = new_tr
            return entry

        if isinstance(lrs_val, torch.Tensor):
            if masks_val is not None and not isinstance(masks_val, torch.Tensor):
                raise TypeError("Masks must be a tensor when lrs is a tensor.")
            indices = self._select_indices_tensor(
                masks_val, lrs_val.shape[0], lrs_val.shape[2], leading
            )
            entry[self.lrs] = self._gather_tensor_by_indices(lrs_val, indices)
            if self.masks is not None and masks_val is not None:
                entry[self.masks] = self._gather_tensor_by_indices(masks_val, indices)
            if self.translations is not None and translations_val is not None and isinstance(translations_val, torch.Tensor):
                entry[self.translations] = self._gather_translations(translations_val, indices)
            return entry

        clear_indices = self._select_indices(lrs_val, masks_val, leading)
        entry[self.lrs] = [lrs_val[i] for i in clear_indices]
        if self.masks is not None and masks_val is not None:
            entry[self.masks] = [masks_val[i] for i in clear_indices]
        if self.translations is not None and translations_val is not None:
            entry[self.translations] = [translations_val[0:1, i] for i in clear_indices]
        return entry


@register_class
class CenterOffset(EntryTransform):
    """
    Centers the lr images translations around origin (0,0) or shifts them by given offset.
    """

    io_spec = IOSpec(
        required_inputs=("translations",),
        required_outputs=("translations",),
    )

    def __init__(self, center_offset: tuple):
        super().__init__()
        self._center_offset = center_offset

    def transform(self, entry: Entry) -> Entry:
        samples = entry.unbatch()
        results = [self.transform_unbatched(s) for s in samples]
        return Entry.collate(results)

    def transform_unbatched(self, entry: Entry) -> Entry:
        if entry[self.translations] is None:
            # print("Cannot center translations, because they are not set.")
            return entry
        translations_val = entry[self.translations]
        if isinstance(translations_val, torch.Tensor):
            if translations_val.dim() == 2:
                translations_val = translations_val.unsqueeze(0)
            if translations_val.dim() != 3:
                raise TypeError("Translations tensor must have shape (B, K, 2) or (K, 2).")
            if self._center_offset is None:
                offset = translations_val.mean(dim=1, keepdim=True)
            else:
                offset = torch.as_tensor(self._center_offset, dtype=translations_val.dtype, device=translations_val.device)
                offset = offset.view(1, 1, 2)
            entry[self.translations] = translations_val - offset
            return entry
        if isinstance(translations_val, dict):
            new_tr = {}
            for band, translations in translations_val.items():
                if isinstance(translations, torch.Tensor):
                    if translations.dim() == 2:
                        translations = translations.unsqueeze(0)
                    if self._center_offset is None:
                        offset = translations.mean(dim=1, keepdim=True)
                    else:
                        offset = torch.as_tensor(self._center_offset, dtype=translations.dtype, device=translations.device)
                        offset = offset.view(1, 1, 2)
                    new_tr[band] = translations - offset
                else:
                    offset = self._center_offset
                    if self._center_offset is None:
                        offset = sum(translations) / len(translations)
                    new_tr[band] = [translation - offset for translation in translations]
            entry[self.translations] = new_tr
            return entry

        offset = self._center_offset
        if self._center_offset is None:
            offset = sum(translations_val) / len(translations_val)
        entry[self.translations] = [translation - offset for translation in translations_val]
        return entry


@register_class
class RenameFields(EntryTransform):
    """
    An EntryTransform that renames fields in an Entry.
    The mapping is provided as a dictionary {source: target} such that
    Entry.source will be renamed to Entry.target.

    This implementation first collects all the source values and then updates
    the entry so that swapping fields is supported.
    """

    io_spec = IOSpec(
        required_inputs=("field",),
        required_outputs=("output",),
    )

    def __init__(self):
        super().__init__()

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        if self.field not in entry:
            return entry
        value = entry[self.field]
        entry[self.output] = value
        if self.output != self.field:
            del entry[self.field]

        return entry

@register_class
class RemoveFields(EntryTransform):
    """
    An EntryTransform that removes fields in an Entry.
    The mapping is provided as a list of strings such that
    Entry.source will be removed from the entry.
    """

    io_spec = IOSpec(
        required_inputs=("field",),
    )

    def __init__(self):
        super().__init__()

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        if self.field not in entry:
            return entry
        del entry[self.field]
        return entry

@register_class
class CopyFields(EntryTransform):
    """
    An EntryTransform that copies fields in an Entry.
    It creates a deep copy of each source field and writes it under the target name.
    The mapping is a dict { source_name: target_name }.
    """

    io_spec = IOSpec(
        required_inputs=("field",),
        required_outputs=("output",),
    )

    def __init__(self):
        super().__init__()

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        value = entry[self.field]
        entry[self.output] = copy.deepcopy(value)
        return entry


def _flatten_dict(d: dict, prefix: str, sep: str) -> dict:
    """Recursively flatten a nested dict, joining keys with *sep*."""
    items = {}
    for key, value in d.items():
        new_key = f"{prefix}{sep}{key}" if prefix else key
        if isinstance(value, dict):
            items.update(_flatten_dict(value, new_key, sep))
        else:
            items[new_key] = value
    return items


@register_class
class FlattenDict(EntryTransform):
    """Recursively unpacks a (nested) dict field into top-level Entry fields.

    Keys at every nesting level are joined with ``sep`` (default ``"_"``)
    to form flat field names. By default the original field name is used as
    the root prefix, so the resulting names read naturally as a path through
    the nested structure.

    Args:
        prefix: If set, replaces the field name as the root prefix.
            Use ``prefix=""`` to omit the root prefix entirely (only inner
            keys are joined).
        sep: Separator between key segments. Default ``"_"``.

    Example — default (field name as prefix)::

        # Entry: {"meta": {"sensor": {"name": "S2", "res": 10}, "date": "2024"}}
        # io: {"field": "meta"}
        # Result: {"meta_sensor_name": "S2", "meta_sensor_res": 10, "meta_date": "2024"}

    Example — custom prefix::

        # FlattenDict(prefix="info"), io: {"field": "meta"}
        # Result: {"info_sensor_name": "S2", "info_sensor_res": 10, "info_date": "2024"}

    Example — no prefix::

        # FlattenDict(prefix=""), io: {"field": "meta"}
        # Result: {"sensor_name": "S2", "sensor_res": 10, "date": "2024"}
    """

    io_spec = IOSpec(
        required_inputs=("field",),
    )

    def __init__(self, prefix: str = None, sep: str = "_"):
        super().__init__()
        self.prefix = prefix
        self.sep = sep

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        if self.field not in entry:
            return entry
        value = entry[self.field]
        if not isinstance(value, dict):
            raise TypeError(
                f"FlattenDict expected a dict for field '{self.field}', "
                f"got {type(value).__name__}"
            )
        root = self.prefix if self.prefix is not None else self.field
        flat = _flatten_dict(value, root, self.sep)
        for key, val in flat.items():
            entry[key] = val
        del entry[self.field]
        return entry


@register_class
class SetLeading(EntryTransform):
    io_spec = IOSpec(
        required_inputs=("lrs", "leading"),
        required_outputs=("leading",),
    )

    def __init__(self, idx: int):
        super().__init__()
        self.idx = idx

    def transform(self, entry: Entry) -> Entry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> Entry:
        leading_val = entry.get(self.leading, [False])
        is_set = leading_val[0] if isinstance(leading_val, list) else leading_val
        if is_set:
            raise ValueError("Leading LR image already set.")
        entry[self.leading] = [True] * len(leading_val) if isinstance(leading_val, list) else [True]
        lrs_val = entry[self.lrs]
        if isinstance(lrs_val, torch.Tensor) and lrs_val.dim() >= 5:
            tmp = lrs_val[:, :, 0].clone()
            lrs_val[:, :, 0] = lrs_val[:, :, self.idx]
            lrs_val[:, :, self.idx] = tmp
            entry[self.lrs] = lrs_val
        else:
            entry[self.lrs][0], entry[self.lrs][self.idx] = entry[self.lrs][self.idx], entry[self.lrs][0]
        return entry



