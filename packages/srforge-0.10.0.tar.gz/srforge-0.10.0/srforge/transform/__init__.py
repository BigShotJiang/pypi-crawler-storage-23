import abc
import inspect
import types
from typing import Any, List, Union, Dict, final, Tuple, Mapping

import torch

from omegaconf import ListConfig

from srforge.data import Entry, GraphEntry
from srforge.registry import register_class
from srforge.utils import obj_to_str, IOSpec, IOModule
from srforge.utils.io_parsing import parse_io_config, build_applications

_APPLICATION = Tuple[Dict[str, str], List[str]]  # (input_map, output_fields)


def _unbatch_value(value, index):
    """Extract sample ``index`` via integer indexing (removes batch dim).

    * ``Tensor [B,C,H,W]`` → ``tensor[index]`` → ``[C,H,W]``
    * ``list`` → ``list[index]``
    * ``dict`` → recurse into values
    * ``None`` → ``None``
    """
    if isinstance(value, torch.Tensor):
        return value[index]
    if isinstance(value, (list, tuple)):
        return value[index]
    if isinstance(value, dict):
        return {k: _unbatch_value(v, index) for k, v in value.items()}
    return value


def _infer_batch_size_from_kwargs(kwargs):
    """Find batch size from the first tensor or list in kwargs."""
    for v in kwargs.values():
        if isinstance(v, torch.Tensor):
            return v.shape[0]
        if isinstance(v, (list, tuple)):
            return len(v)
    raise ValueError("Cannot infer batch size from kwargs — no tensors or lists found.")


def _collate_sample_results(results):
    """Re-batch a list of per-sample results into a single batched value.

    * ``Tensor`` → ``torch.stack(results, dim=0)``
    * ``dict`` → recurse per key
    * ``tuple`` → recurse per position, return as tuple
    * everything else → ``list(results)``
    """
    if not results:
        return results
    first = results[0]
    if isinstance(first, torch.Tensor):
        return torch.stack(results, dim=0)
    if isinstance(first, dict):
        return {k: _collate_sample_results([r[k] for r in results]) for k in first}
    if isinstance(first, tuple):
        return tuple(
            _collate_sample_results([r[i] for r in results])
            for i in range(len(first))
        )
    return list(results)


class Transformation(abc.ABC):

    def __call__(self, data: Any) -> Any:
        return self.transform(data)

    @abc.abstractmethod
    def transform(self, data: Any) -> Any:
        raise NotImplementedError()

    def __repr__(self):
        return obj_to_str(self)

class DataTransform(IOModule, Transformation, abc.ABC):
    """Process the content of Entry fields.

    Subclasses override one of two methods:

    - ``transform(**kwargs)`` — **batched** processing. Receives values with
      a leading batch dimension (tensors are ``[B, C, H, W]``, names are
      lists). This is the default and preferred path for performance.
    - ``transform_unbatched(**kwargs)`` — **unbatched** processing. Receives
      values *without* the batch dimension (tensors are ``[C, H, W]``,
      names are bare strings).

    **Dispatch**: ``transform()`` is always preferred when it exists — for
    both batched and unbatched entries. For unbatched entries, the framework
    auto-wraps via ``collate([entry])`` → ``transform()`` → ``result[0]``.
    The wrapping overhead for a single entry is negligible compared to having
    a single optimized code path. ``transform_unbatched()`` is only used
    when ``transform()`` is not implemented:

    - ``transform()`` exists → always used (wrap/unwrap for unbatched).
    - Only ``transform_unbatched()`` → called directly for unbatched entries,
      looped per sample for batched entries.

    **IO binding** works identically for both paths. The framework
    inspects the overridden method's signature (``transform`` or
    ``transform_unbatched``) for parameter names and type annotations
    (which control annotation-driven recursion into containers).

    **Annotation-driven recursion**: when a field contains a container
    (dict, list, tuple) and the corresponding ``transform``/
    ``transform_unbatched`` parameter is annotated as ``torch.Tensor``
    (or ``Union[..., torch.Tensor]``), the framework recurses into the
    container and calls the method on each leaf value. Annotating as
    ``dict``, ``list``, or omitting the annotation for non-Tensor types
    passes the container as a whole.
    """

    _install_io_ports = False
    _applications: List[_APPLICATION] | None = None
    _recurse_params: set = set()

    def transform(self, *args, **kwargs) -> Any:
        """Batched transform — override for batch-parallel processing.

        Subclasses should override either this method (for batched processing)
        or ``transform_unbatched`` (for unbatched processing). If only
        ``transform_unbatched`` is overridden, the framework automatically
        loops per sample at runtime.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement transform(). "
            f"Override transform() for batched processing or transform_unbatched() "
            f"for unbatched processing."
        )

    def __call__(self, *args, **kwargs) -> Any:
        all_args = args + tuple(kwargs.values())
        if any(isinstance(a, (Entry, GraphEntry)) for a in all_args):
            if len(all_args) != 1:
                raise TypeError(
                    "Cannot mix Entry and non-Entry arguments. "
                    "Pass a single Entry when using IO binding."
                )
            entry = all_args[0]
            if entry.is_batched:
                return self._transform_batched_entry(entry)
            return self._transform_unbatched_entry(entry)
        return self.transform(*args, **kwargs)

    def transform_unbatched(self, **kwargs) -> Any:
        """Unbatched transform — override this for single-sample logic.

        Receives kwargs **without** batch dim: tensors are ``[C,H,W]``,
        strings are bare, scalars are Python types. Return values in the
        same convention.

        When ``transform_unbatched`` is overridden and ``transform`` is not,
        the framework automatically loops over batch samples, calling this
        method once per sample, and re-batches the results.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement transform_unbatched."
        )

    @property
    def _has_transform(self) -> bool:
        return self.__class__.transform is not DataTransform.transform

    @property
    def _has_transform_unbatched(self) -> bool:
        return self.__class__.transform_unbatched is not DataTransform.transform_unbatched

    def _transform_per_sample(self, kwargs: dict) -> Any:
        """Loop over batch, call ``transform_unbatched`` per sample, re-batch.

        For each sample *i* in ``range(B)``, extracts unbatched values
        (tensors indexed with ``[i]`` to remove the batch dim), calls
        ``transform_unbatched(**sample_kwargs)``, and collects results. The
        collected results are re-batched via ``torch.stack`` (tensors),
        per-key recursion (dicts), per-position recursion (tuples), or
        plain list construction (everything else).

        Args:
            kwargs: Batched keyword arguments (same as what ``transform``
                would receive).

        Returns:
            Re-batched result matching the structure returned by
            ``transform_unbatched``.
        """
        B = _infer_batch_size_from_kwargs(kwargs)
        sample_results = []
        for i in range(B):
            sample_kwargs = {p: _unbatch_value(v, i) for p, v in kwargs.items()}
            sample_results.append(self.transform_unbatched(**sample_kwargs))
        return _collate_sample_results(sample_results)

    def set_io(self, io_cfg, *, strict=True, require_all=True):
        """Bind IO mapping using the unified config format.

        Accepts: ``{"inputs": {param: field}, "outputs": <string|list|dict>}``
        """
        inputs_raw, outputs_raw = parse_io_config(io_cfg)
        self._applications = build_applications(inputs_raw, outputs_raw)
        self._io_bound = True
        self._recurse_params = self._build_recurse_set()
        return self

    def _transform_batched_entry(self, entry: Entry) -> Entry:
        """Process a batched Entry (has batch dimension)."""
        if not getattr(self, "_io_bound", False):
            raise ValueError(f"{self.__class__.__name__} requires io mappings before it can run on Entry.")
        if not self._applications:
            raise ValueError(f"{self.__class__.__name__} has no io mappings configured.")
        recurse = self._recurse_params
        for input_map, output_fields in self._applications:
            kwargs = {}
            for param, field in input_map.items():
                if field not in entry:
                    raise KeyError(f"Target '{field}' not found in entry for transformation {self}.")
                kwargs[param] = entry[field]
            result = self._apply_recursive(kwargs, recurse, batched=True)
            if len(output_fields) == 1:
                entry[output_fields[0]] = result
            else:
                for field, val in zip(output_fields, result):
                    entry[field] = val
        return entry

    def _transform_unbatched_entry(self, entry: Entry) -> Entry:
        """Process an unbatched Entry (no batch dimension).

        If ``transform()`` is overridden: wraps via ``Entry.collate([entry])``,
        runs the batched path, then extracts via ``result[0]``. This is
        preferred because the batched code path is the optimized one, and
        the wrapping overhead for a single entry is negligible.

        If only ``transform_unbatched()`` is overridden: calls it directly
        since the data is already single-sample.
        """
        if not getattr(self, "_io_bound", False):
            raise ValueError(f"{self.__class__.__name__} requires io mappings before it can run on Entry.")
        if not self._applications:
            raise ValueError(f"{self.__class__.__name__} has no io mappings configured.")

        if self._has_transform:
            # Wrap → batched transform → unwrap (preferred — optimized path)
            batched = Entry.collate([entry])
            result = self._transform_batched_entry(batched)
            return result[0]

        if self._has_transform_unbatched:
            # Direct unbatched call — data is already single-sample
            recurse = self._recurse_params
            for input_map, output_fields in self._applications:
                kwargs = {}
                for param, field in input_map.items():
                    if field not in entry:
                        raise KeyError(f"Target '{field}' not found in entry for transformation {self}.")
                    kwargs[param] = entry[field]
                result = self._apply_recursive(kwargs, recurse, batched=False)
                if len(output_fields) == 1:
                    entry[output_fields[0]] = result
                else:
                    for field, val in zip(output_fields, result):
                        entry[field] = val
            return entry

        raise NotImplementedError(
            f"{self.__class__.__name__} must implement either transform() or transform_unbatched()."
        )

    @property
    def resolved(self):
        if self._applications is None:
            return {}
        return {
            next(iter(inp.values())): out[0]
            for inp, out in self._applications
            if len(inp) == 1 and len(out) == 1
        }

    # ── Annotation-driven recursion ──────────────────────────────────

    @property
    def _transform_method(self):
        """Return the user-overridden transform method for signature inspection.

        Prefers ``transform`` if overridden, falls back to ``transform_unbatched``.
        """
        if self._has_transform:
            return self.transform
        if self._has_transform_unbatched:
            return self.transform_unbatched
        return self.transform  # fallback (will fail at runtime anyway)

    @staticmethod
    def _should_recurse_param(param: inspect.Parameter) -> bool:
        ann = param.annotation
        if ann is inspect.Parameter.empty:
            return True  # no annotation → recurse (backward compat)
        if ann is torch.Tensor:
            return True
        origin = getattr(ann, '__origin__', None)
        if origin is Union:
            return torch.Tensor in getattr(ann, '__args__', ())
        if hasattr(types, 'UnionType') and isinstance(ann, types.UnionType):
            return torch.Tensor in ann.__args__
        return False

    def _build_recurse_set(self) -> set:
        sig = inspect.signature(self._transform_method)
        return {
            name for name, p in sig.parameters.items()
            if name != 'self'
            and p.kind in (p.POSITIONAL_OR_KEYWORD, p.POSITIONAL_ONLY, p.KEYWORD_ONLY)
            and self._should_recurse_param(p)
        }

    def _apply_recursive(self, kwargs: dict, recurse: set, *, batched: bool = True) -> Any:
        """Apply self.transform with annotation-driven recursion.

        For each kwarg in `recurse`: if it's a container (dict/list/tuple),
        provides iteration structure. Leaf-level recursive params and all
        non-recursive params are broadcast to every position.

        Args:
            kwargs: Keyword arguments to pass to the transform.
            recurse: Set of parameter names that should recurse into containers.
            batched: If True, use batched dispatch (transform → _transform_per_sample).
                If False, call transform_unbatched directly (data is single-sample).
        """
        # Find which recursive params hold containers
        dict_params = {k for k in recurse if k in kwargs and isinstance(kwargs[k], dict)}
        list_params = {k for k in recurse if k in kwargs and isinstance(kwargs[k], (list, tuple))}

        if dict_params:
            if list_params:
                raise TypeError(
                    f"{self.__class__.__name__}: cannot mix dict and list/tuple "
                    f"containers across recursive parameters."
                )
            # Validate matching keys
            keys_iter = iter(dict_params)
            ref_key = next(keys_iter)
            ref_keys = list(kwargs[ref_key].keys())
            for k in keys_iter:
                if list(kwargs[k].keys()) != ref_keys:
                    raise ValueError(
                        f"{self.__class__.__name__}: dict keys mismatch in parallel "
                        f"recursion: '{ref_key}' has {ref_keys}, '{k}' has {list(kwargs[k].keys())}."
                    )
            result = {}
            for key in ref_keys:
                sub_kwargs = {}
                for param, val in kwargs.items():
                    if param in dict_params:
                        sub_kwargs[param] = val[key]
                    else:
                        sub_kwargs[param] = val  # broadcast
                result[key] = self._apply_recursive(sub_kwargs, recurse, batched=batched)
            return result

        if list_params:
            # Validate matching lengths
            lengths = {k: len(kwargs[k]) for k in list_params}
            ref_key = next(iter(list_params))
            ref_len = lengths[ref_key]
            for k, l in lengths.items():
                if l != ref_len:
                    raise ValueError(
                        f"{self.__class__.__name__}: list length mismatch in parallel "
                        f"recursion: '{ref_key}' has {ref_len}, '{k}' has {l}."
                    )
            container_type = type(kwargs[ref_key])
            items = []
            for i in range(ref_len):
                sub_kwargs = {}
                for param, val in kwargs.items():
                    if param in list_params:
                        sub_kwargs[param] = val[i]
                    else:
                        sub_kwargs[param] = val  # broadcast
                items.append(self._apply_recursive(sub_kwargs, recurse, batched=batched))
            return container_type(items)

        # Leaf level — no containers among recursive params
        if batched:
            if self._has_transform:
                return self.transform(**kwargs)
            if self._has_transform_unbatched:
                return self._transform_per_sample(kwargs)
        else:
            # Unbatched — call transform_unbatched directly
            return self.transform_unbatched(**kwargs)
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement either transform() or transform_unbatched()."
        )

class EntryTransform(IOModule, Transformation, abc.ABC):
    """Operate on Entry structure — add, remove, rename fields, change type.

    Subclasses override one of two methods:

    - ``transform(entry)`` — **batched** processing. Receives an Entry with
      ``is_batched=True`` (tensors are ``[B, C, H, W]``, names are lists).
    - ``transform_unbatched(entry)`` — **unbatched** processing. Receives
      an Entry with ``is_batched=False`` (tensors are ``[C, H, W]``,
      names are bare strings).

    **Dispatch** depends on the Entry's ``is_batched`` flag:

    - **Batched entry** + ``transform()`` → call directly (fast path).
    - **Batched entry** + only ``transform_unbatched()`` → unbatch, loop
      per sample, re-collate.
    - **Unbatched entry** + ``transform_unbatched()`` → call directly
      (natural fit).
    - **Unbatched entry** + only ``transform()`` → ``collate([entry])`` →
      batched transform → ``result[0]`` (auto-wrap/unwrap).

    If both are overridden, ``transform()`` wins for batched entries,
    ``transform_unbatched()`` wins for unbatched entries. Unlike
    DataTransform (where the framework mediates field extraction),
    EntryTransform methods receive the Entry directly — so each method
    must match the Entry's batched state.
    """

    def __init__(self):
        super().__init__()

    def set_io(self, io_cfg, *, strict=True, require_all=True):
        """Bind IO mapping using the unified config format.

        Accepts: ``{"inputs": {port: field}, "outputs": {port: field}}``

        For EntryTransform, inputs and outputs map IOSpec port names to
        Entry field names. If outputs is omitted, output ports sharing a
        name with an input port get the same Entry field (in-place).
        """
        inputs_raw, outputs_raw = parse_io_config(io_cfg)
        if not isinstance(inputs_raw, Mapping):
            raise TypeError(
                f"{self.__class__.__name__}: 'inputs' must be a dict for "
                f"port-based binding, got {type(inputs_raw).__name__}."
            )
        flat = dict(inputs_raw)
        if outputs_raw is not None:
            if isinstance(outputs_raw, Mapping):
                flat.update(outputs_raw)
            elif isinstance(outputs_raw, str):
                out_ports = list(
                    (self.io_spec.required_outputs or ())
                    + (self.io_spec.optional_outputs or ())
                )
                if not out_ports:
                    raise ValueError(
                        f"{self.__class__.__name__} has no output ports for "
                        f"positional output '{outputs_raw}'."
                    )
                flat[out_ports[0]] = outputs_raw
            elif isinstance(outputs_raw, (list, tuple)):
                out_ports = list(
                    (self.io_spec.required_outputs or ())
                    + (self.io_spec.optional_outputs or ())
                )
                for port, field in zip(out_ports, outputs_raw):
                    flat[port] = field
            else:
                raise TypeError(
                    f"{self.__class__.__name__}: 'outputs' must be a dict, "
                    f"string, or list, got {type(outputs_raw).__name__}."
                )
        else:
            # In-place: output ports sharing a name with an input port
            # get the same Entry field.
            if self.io_spec:
                for port in (
                    (self.io_spec.required_outputs or ())
                    + (self.io_spec.optional_outputs or ())
                ):
                    if port in inputs_raw:
                        flat[port] = inputs_raw[port]
        self.bind_io(flat, strict=strict, require_all=require_all)
        return self

    def __call__(self, entry) -> Any:
        if not isinstance(entry, (Entry, GraphEntry)):
            raise TypeError(
                f"{self.__class__.__name__} requires an Entry object. "
                f"EntryTransforms operate on Entry structure and cannot be called with raw values."
            )
        if self.io_spec is None:
            raise ValueError(f"{self.__class__.__name__} requires io_spec before it can run.")
        spec = self.io_spec
        has_ports = spec.all_inputs or spec.all_outputs
        if has_ports and not getattr(self, "_io_bound", False):
            raise ValueError(f"{self.__class__.__name__} requires io mappings before it can run.")
        self._validate_required_inputs(entry)
        if entry.is_batched:
            return self._dispatch_batched(entry)
        return self._dispatch_unbatched(entry)

    def transform(self, entry: 'Entry') -> 'Entry':
        """Batched transform — override for batch-parallel processing.

        Receives an Entry with ``is_batched=True``. Tensors have shape
        ``[B, C, H, W]``, names are lists of strings.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement transform(). "
            f"Override transform() for batched processing or transform_unbatched() "
            f"for unbatched processing."
        )

    def transform_unbatched(self, entry: 'Entry') -> 'Entry':
        """Unbatched transform — override this for single-sample logic.

        Receives an Entry with ``is_batched=False``. Tensors have shape
        ``[C, H, W]``, names are bare strings.
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement transform_unbatched."
        )

    @property
    def _has_transform(self) -> bool:
        return self.__class__.transform is not EntryTransform.transform

    @property
    def _has_transform_unbatched(self) -> bool:
        return self.__class__.transform_unbatched is not EntryTransform.transform_unbatched

    def _dispatch_batched(self, entry: 'Entry') -> 'Entry':
        if self._has_transform:
            return self.transform(entry)
        if self._has_transform_unbatched:
            samples = entry.unbatch()
            results = [self.transform_unbatched(s) for s in samples]
            return Entry.collate(results)
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement either transform() or transform_unbatched()."
        )

    def _dispatch_unbatched(self, entry: 'Entry') -> 'Entry':
        if self._has_transform_unbatched:
            return self.transform_unbatched(entry)
        if self._has_transform:
            batched = Entry.collate([entry])
            result = self.transform(batched)
            return result[0]
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement either transform() or transform_unbatched()."
        )

    def _validate_required_inputs(self, entry: 'Entry') -> None:
        required = list(self.io_spec.required_inputs) if isinstance(self.io_spec, IOSpec) else []
        if not required:
            return
        missing: List[str] = []
        for name in required:
            key = getattr(self, name, None)
            if key is None:
                missing.append(f"'{name}' (unbound)")
            elif key not in entry:
                missing.append(f"'{name}' (bound to '{key}', not found in entry)")
        if missing:
            entry_name = getattr(entry, "name", None)
            name_msg = f" (entry='{entry_name}')" if entry_name is not None else ""
            available = sorted(entry.keys()) if hasattr(entry, 'keys') else []
            raise KeyError(
                f"{self.__class__.__name__} missing required input vars{name_msg}: "
                f"{', '.join(missing)}. Available entry fields: {available}"
            )

