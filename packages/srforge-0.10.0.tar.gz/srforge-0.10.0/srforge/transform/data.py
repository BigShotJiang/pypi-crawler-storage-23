import enum
from typing import Literal, Union, Iterable, Tuple
import logging

import numpy as np
import torch
from skimage.exposure import equalize_adapthist

from srforge.utils.convert import to_torch_dtype
from srforge.registry import register_class
from srforge.transform import DataTransform

logger = logging.getLogger(__name__)

@register_class
class MakeShapeDivisibleBy(DataTransform):
    class Axis(enum.IntEnum):
        X = 0
        Y = 1

    def __init__(self, factor: int):
        super().__init__()
        self._factor = factor

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        """
        Crops borders of an image so it is divisible by given factor.

        :param image: Image to be cropped.
        :return: Cropped image.
        """
        remove_rows = image.shape[-2] % self._factor
        remove_cols = image.shape[-1] % self._factor
        if remove_rows != 0:
            image = image[..., :-remove_rows, :]
        if remove_cols != 0:
            image = image[..., :, :-remove_cols]
        return image

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image)


@register_class
class CropBorder(DataTransform):
    """
    Crops the image by the specified border size.
    The border size can be specified as an integer (for all sides),
    a tuple of two integers (for top/bottom and left/right),
    or a tuple of four integers (for left, bottom, right and top).
    The cropping is done by slicing the image tensor.

    """
    def __init__(self, border_size: Union[int, Tuple[int, int], Tuple[int, int, int, int]]):
        super().__init__()
        if isinstance(border_size, int):
            self._top = border_size
            self._bottom = - border_size
            self._left = border_size
            self._right = - border_size
        elif len(border_size) == 2:
            self._top = border_size[1]
            self._bottom = border_size[1]
            self._left = border_size[0]
            self._right = border_size[0]
        elif len(border_size) == 4:
            self._top = border_size[3]
            self._bottom = -border_size[1]
            self._left = border_size[0]
            self._right = -border_size[2]
        else:
            raise ValueError("Border size must be an int, a tuple of two ints or a tuple of four ints.")

        if self._bottom > 0 or self._right > 0:
            raise ValueError("Bottom and right borders must be negative or None to crop the image from the end.")
        if self._top < 0 or self._left < 0:
            raise ValueError("Top and left borders must be non-negative to crop the image from the start.")

        if self._bottom == 0:
            self._bottom = None # None because slices do not support 0 as end index
        if self._right == 0:
            self._right = None # None because slices do not support 0 as end index

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        return image[..., self._top: self._bottom, self._left: self._right]

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image)

@register_class
class MoveAxis(DataTransform):
    def __init__(self, target: Union[int, Iterable[int]], destination: Union[int, Iterable[int]]):
        super().__init__()
        self._target = target
        self._destination = destination

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        """
        Move axes of an array to new positions.
        Other axes remain in their original order.

        :param image: Target image.
        :return: Target image with one axis moved to destined position.
        """
        result = torch.movedim(image, self._target, self._destination)
        return result

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image)

@register_class
class Standardize(DataTransform):
    def __init__(self, mean: float = None, std: float = None):
        super().__init__()
        self._mean = mean
        self._std = std
        if not ((self._std is None) + (self._mean is None) in [0, 2]):
            raise ValueError("Either both mean and std or none of them should be provided.")

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        if self._mean is None or self._std is None:
            if image.dim() <= 1:
                mean = image.mean()
                std = image.std(unbiased=False)
            else:
                dims = tuple(range(1, image.dim()))
                mean = image.mean(dim=dims, keepdim=True)
                std = image.std(dim=dims, unbiased=False, keepdim=True)
        else:
            mean = self._mean
            std = self._std
        if isinstance(std, torch.Tensor):
            std = torch.clamp(std, min=1e-8)
        else:
            if std < 1e-8:
                std = 1e-8
        return (image - mean) / std

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image.unsqueeze(0)).squeeze(0)

@register_class
class Destandardize(DataTransform):
    def __init__(self, mean: float = None, std: float = None):
        super().__init__()
        self._mean = mean
        self._std = std
        if self._mean is None or self._std is None:
            raise ValueError("Destandardize requires both mean and std to be provided.")

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        mean = self._mean
        std = self._std
        return image * std + mean

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image)

@register_class
class AsType(DataTransform):
    def __init__(self, dtype: Union[str, torch.dtype, np.dtype]):
        super().__init__()
        self._dtype = dtype

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        dtype = to_torch_dtype(self._dtype)
        return image.to(dtype)

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image)

@register_class
class ToFloat(DataTransform):
    def __init__(self):
        super().__init__()

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        return image.to(torch.float32)

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image)

@register_class
class ToDouble(DataTransform):
    def __init__(self):
        super().__init__()

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        return image.to(torch.float64)

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image)

@register_class
class Multiply(DataTransform):
    def __init__(self, value: float):
        super().__init__()
        self._value = value

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        return image * self._value

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image)

@register_class
class Divide(DataTransform):
    def __init__(self, value: float):
        super().__init__()
        self._value = value

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        return image / self._value

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image)

@register_class
class Downsample(DataTransform):
    """
    Downsamples the image by the given scale factor using the specified mode.

    :param image: Input image tensor.
    :return: Downsampled image tensor.
    """
    def __init__(self, scale_factor: Union[int, tuple[int, int]], mode: str = 'area'):
        super().__init__()
        self._scale_factor = 1.0 / scale_factor if isinstance(scale_factor, int) else (1.0 / scale_factor[0], 1.0 / scale_factor[1])
        self._mode = mode

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        return torch.nn.functional.interpolate(image, scale_factor=self._scale_factor, mode=self._mode)

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image.unsqueeze(0)).squeeze(0)


@register_class
class Upsample(DataTransform):
    """
    Upsamples the image by the given scale factor using the specified mode.

    :param image: Input image tensor.
    :return: Upsampled image tensor.
    """
    def __init__(self, scale_factor: Union[int, tuple[int, int]], mode: str = 'bicubic'):
        super().__init__()
        self._scale_factor = scale_factor
        self._mode = mode

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        return torch.nn.functional.interpolate(image, scale_factor=self._scale_factor, mode=self._mode)

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image.unsqueeze(0)).squeeze(0)

@register_class
class DisplacementToKernel(DataTransform):
    def __init__(self, max_shift: int = 5):
        super().__init__()
        self.max_shift = max_shift

    def transform(self, displacement: torch.Tensor) -> torch.Tensor:
        """
        Converts a shift vector into a kernel for bilinear interpolation.
        """
        K = self.max_shift * 2 + 1  # kernel size, e.g. 11 for max_shift=5

        if not (max(displacement.min().abs(), displacement.max().abs()) <= self.max_shift + 1e-5):
            raise ValueError(f"Displacement values exceed max_shift={self.max_shift}: min={displacement.min().item()}, max={displacement.max().item()}")
        device = displacement.device


        # 1. prepare a (K,K) grid centered at zero:
        coords = torch.arange(K, device=device) - self.max_shift  # [...,-p,...,0,...,p]
        gy, gx = torch.meshgrid(coords, coords, indexing='ij')  # each [K, K]
        gy = -gy.view(1, 1, K, K)  # broadcast over B,N
        gx = -gx.view(1, 1, K, K)

        # 2. pull out the float offsets:
        dy = displacement[..., 0].unsqueeze(-1).unsqueeze(-1)  # -> [B, N, 1, 1]
        dx = displacement[..., 1].unsqueeze(-1).unsqueeze(-1)

        # 3. compute the bilinear weights:
        wy = torch.relu(1 - torch.abs(gy - dy))  # [B, N, K, K]
        wx = torch.relu(1 - torch.abs(gx - dx))  # [B, N, K, K]
        kernels = wy * wx  # [B, N, K, K]

        # 4. normalize so sum=1 over each (b,n):
        kernels = kernels / kernels.sum(dim=(-2, -1), keepdim=True)
        return kernels

    def transform_unbatched(self, displacement: torch.Tensor) -> torch.Tensor:
        return self.transform(displacement.unsqueeze(0)).squeeze(0)

@register_class
class KernelToDisplacement(DataTransform):
    def __init__(self):
        super().__init__()

    def transform(self, kernels: torch.Tensor) -> torch.Tensor:
        """
        Invert the DisplacementToKernel transform:
          - kernels: Tensor of shape [B, N, K, K], each slice normalized.
        Returns:
          - displacements: Tensor of shape [B, N, 2], where
            displacements[...,0] = dy, displacements[...,1] = dx
        """
        B, N, K, _ = kernels.shape
        device = kernels.device
        if K % 2 == 0:
            raise ValueError("A proper registration kernel size K must be odd, got K={}".format(K))
        max_shift = (K - 1) // 2  # requiring K to be odd, e.g. 11 -> max_shift=5

        # 1) rebuild the same coordinate grids
        coords = torch.arange(K, device=device) - max_shift # shape [K]
        gy, gx = torch.meshgrid(coords, coords, indexing='ij')     # each [K,K]
        # match shapes [1,1,K,K]
        gy = -gy.view(1,1,K,K)
        gx = -gx.view(1,1,K,K)

        # 2) compute expectations
        #    sum across the last two dims
        dy = (gy * kernels).sum(dim=(2, 3))   # shape [B, N]
        dx = (gx * kernels).sum(dim=(2, 3))   # shape [B, N]

        # 3) stack and return
        return torch.stack([dy, dx], dim=-1)  # [B, N, 2]

    def transform_unbatched(self, kernels: torch.Tensor) -> torch.Tensor:
        return self.transform(kernels.unsqueeze(0)).squeeze(0)

@register_class
class ToDb(DataTransform):
    def __init__(self, eps: float = None):
        super().__init__()
        if eps is None:
            self.eps = torch.finfo(torch.float32).eps
        else:
            self.eps = eps
    def transform(self, image: torch.Tensor) -> torch.Tensor:
        x = 10 * torch.log10(image+self.eps)
        return x

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image)

@register_class
class Normalize(DataTransform):
    def __init__(self, range: tuple[float, float]= None):
        super().__init__()
        self.range = range

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        if self.range is not None:
            image = image.clip(self.range[0], self.range[1])
        if image.dim() <= 1:
            min_val = image.min()
            max_val = image.max()
        else:
            dims = tuple(range(1, image.dim()))
            min_val = image.amin(dim=dims, keepdim=True)
            max_val = image.amax(dim=dims, keepdim=True)
        normalized = (image - min_val) / ((max_val - min_val) + torch.finfo(torch.float32).eps)
        return normalized

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image.unsqueeze(0)).squeeze(0)


@register_class
class HistogramEqualize(DataTransform):
    """Per-channel histogram equalization. Output values are in [0, 1]."""

    def __init__(self, bins: int = 256):
        super().__init__()
        self._bins = bins

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        B, C, H, W = image.shape
        out = torch.empty_like(image)
        for b in range(B):
            for c in range(C):
                channel = image[b, c]
                mn, mx = channel.min(), channel.max()
                if mn == mx:
                    out[b, c] = channel
                    continue
                hist = torch.histc(channel, bins=self._bins, min=mn.item(), max=mx.item())
                cdf = hist.cumsum(0)
                cdf = (cdf - cdf[0]) / (cdf[-1] - cdf[0])
                # Map values to bin indices
                normalized = (channel - mn) / (mx - mn)
                bin_indices = (normalized * (self._bins - 1)).long().clamp(0, self._bins - 1)
                out[b, c] = cdf[bin_indices].reshape(H, W)
        return out

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image.unsqueeze(0)).squeeze(0)


@register_class
class CLAHE(DataTransform):
    """Contrast-Limited Adaptive Histogram Equalization. Output values are in [0, 1]."""

    def __init__(self, clip_limit: float = 0.01, kernel_size: tuple[int, int] = (8, 8)):
        super().__init__()
        self._clip_limit = clip_limit
        self._kernel_size = kernel_size

    def transform(self, image: torch.Tensor) -> torch.Tensor:
        B, C, H, W = image.shape
        device = image.device
        out = torch.empty_like(image)
        for b in range(B):
            img_np = image[b].detach().cpu().numpy()  # C×H×W
            # Normalize to [0, 1] for skimage
            mn, mx = img_np.min(), img_np.max()
            if mx - mn > 1e-8:
                img_np = (img_np - mn) / (mx - mn)
            else:
                img_np = np.zeros_like(img_np)
            result = np.empty_like(img_np)
            for c in range(C):
                result[c] = equalize_adapthist(
                    img_np[c],
                    clip_limit=self._clip_limit,
                    kernel_size=self._kernel_size,
                )
            out[b] = torch.from_numpy(np.clip(result, 0, 1)).to(device)
        return out

    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return self.transform(image.unsqueeze(0)).squeeze(0)


@register_class
class ResizeBandsToCommonResolution(DataTransform):
    """Resize all bands in a dict to a common spatial resolution.

    Input is a dict mapping band names to tensors with potentially different
    spatial dimensions.  All tensors are resized to the largest (H, W) found
    across the dict values (``strategy='max'``).

    Supports 4-D (B, C, H, W) and 5-D (B, C, K, H, W) tensors.
    """

    def __init__(
        self,
        strategy: Literal['max', 'min'] = 'max',
        interpolation_mode: Literal['linear', 'bilinear', 'bicubic', 'trilinear', 'area'] = 'bicubic',
    ):
        super().__init__()
        self.strategy = strategy
        self.interpolation_mode = interpolation_mode

    def transform(self, field: dict) -> dict:
        if self.strategy == 'min':
            raise NotImplementedError("'min' strategy is not yet implemented.")
        if not isinstance(field, dict):
            return field

        target_h, target_w = 0, 0
        for tensor in field.values():
            if not isinstance(tensor, torch.Tensor):
                continue
            h, w = tensor.shape[-2:]
            if h > target_h:
                target_h = h
            if w > target_w:
                target_w = w

        target_size = (target_h, target_w)
        result = {}
        for band_name, tensor in field.items():
            if not isinstance(tensor, torch.Tensor):
                result[band_name] = tensor
                continue
            if tensor.shape[-2:] != target_size:
                result[band_name] = self._resize(tensor, target_size)
            else:
                result[band_name] = tensor
        return result

    def transform_unbatched(self, field: dict) -> dict:
        if not isinstance(field, dict):
            return field
        # Unsqueeze each tensor value, run batched transform, squeeze back
        batched = {k: v.unsqueeze(0) if isinstance(v, torch.Tensor) else v for k, v in field.items()}
        result = self.transform(batched)
        return {k: v.squeeze(0) if isinstance(v, torch.Tensor) else v for k, v in result.items()}

    def _resize(self, tensor: torch.Tensor, target_size: tuple[int, int]) -> torch.Tensor:
        align = False if self.interpolation_mode != 'nearest' else None
        if tensor.dim() == 4:
            return torch.nn.functional.interpolate(
                tensor, size=target_size,
                mode=self.interpolation_mode, align_corners=align,
            )
        if tensor.dim() == 5:
            b, c, k, h, w = tensor.shape
            reshaped = tensor.permute(0, 2, 1, 3, 4).reshape(b * k, c, h, w)
            resized = torch.nn.functional.interpolate(
                reshaped, size=target_size,
                mode=self.interpolation_mode, align_corners=align,
            )
            return resized.reshape(b, k, c, *target_size).permute(0, 2, 1, 3, 4)
        raise TypeError(f"Unsupported tensor dim={tensor.dim()} in bands dict.")


@register_class
class MatchReference(DataTransform):
    """Normalize an image to match a reference image's z-score statistics.

    For each channel, the image is standardized (zero mean, unit std) and then
    rescaled to match the reference's mean and standard deviation.
    """

    def transform(self, image: torch.Tensor, reference: torch.Tensor) -> torch.Tensor:
        eps = torch.finfo(image.dtype).eps
        dims = tuple(range(1, image.dim())) if image.dim() > 1 else ()
        img_mean = image.mean(dim=dims, keepdim=True) if dims else image.mean()
        img_std = image.std(dim=dims, keepdim=True) if dims else image.std()
        ref_mean = reference.mean(dim=dims, keepdim=True) if dims else reference.mean()
        ref_std = reference.std(dim=dims, keepdim=True) if dims else reference.std()
        normalized = (image - img_mean) / (img_std + eps)
        return normalized * ref_std + ref_mean

    def transform_unbatched(self, image: torch.Tensor, reference: torch.Tensor) -> torch.Tensor:
        return self.transform(image.unsqueeze(0), reference.unsqueeze(0)).squeeze(0)


@register_class
class StackTensors(DataTransform):
    """Stack a list of tensors into a single tensor along a given dimension.

    Useful for multi-temporal data where a field contains a list of tensors
    (e.g. ``entry.lrs = [t1, t2, t3]``, each ``[1, C, H, W]``) that should
    be combined into a single tensor (e.g. ``[1, 3, C, H, W]`` with ``dim=1``).

    Args:
        dim: The dimension along which to stack.
    """

    def __init__(self, dim: int):
        super().__init__()
        self._dim = dim

    def transform(self, field: list) -> torch.Tensor:
        if field and isinstance(field[0], (list, tuple)):
            # Batched: field is list of per-sample lists
            per_sample = [torch.stack(inner, dim=self._dim) for inner in field]
            return torch.stack(per_sample, dim=0)
        # Flat list of tensors (standalone or single-sample)
        return torch.stack(field, dim=self._dim)

    def transform_unbatched(self, field: list) -> torch.Tensor:
        return torch.stack(field, dim=self._dim)


@register_class
class StackSequence(DataTransform):
    """Stack a collected list of per-sample sequences into a single tensor.

    After collation, multi-temporal data arrives as a list of per-sample
    inner lists:  ``[[t1, t2], [t3, t4]]`` where each tensor has natural
    shape ``[C, H, W]`` (no batch dim).  This transform stacks each inner
    list along the given dimension, then stacks across batch.

    Example (dim=0)::

        Input:  [[t1, t2], [t3, t4]]   # 2 samples, 2 images each (C,H,W)
        Output: tensor [2, 2, C, H, W]  # stacked along dim=0, batch stacked

    Args:
        dim: The dimension along which to stack the inner sequence
            (in the per-sample tensor, without batch dim).
    """

    def __init__(self, dim: int):
        super().__init__()
        self._dim = dim

    def transform(self, field: list) -> torch.Tensor:
        per_sample = [torch.stack(inner, dim=self._dim) for inner in field]
        return torch.stack(per_sample, dim=0)

    def transform_unbatched(self, field: list) -> torch.Tensor:
        return torch.stack(field, dim=self._dim)
