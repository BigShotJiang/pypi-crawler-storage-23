import math
from typing import Dict

import torch
import torch_geometric as tg

from srforge.registry import register_class
from srforge.data import Entry, GraphEntry
from srforge.transform import EntryTransform
from srforge.utils import IOSpec

@register_class
class EntryToGraphEntry(EntryTransform):
    io_spec = IOSpec(
        required_inputs=("nodes",),
        required_outputs=("nodes",),
    )

    def __init__(self, add_pos: bool = True, gsd_mapping: Dict[str, float] = None, **kwargs):
        super().__init__()
        self.gsd_mapping = gsd_mapping or {}
        self.add_pos = add_pos


    def _pos_grid_template(self, org_shape):
        """
        Create a grid template for the position of nodes in the original image.
        The grid is created in the original image coordinates, where (0, 0) is the top-left corner.
        """
        _, pos = tg.utils.grid(org_shape[-2], org_shape[-1], dtype=torch.float32)
        pos[:, [0, 1]] = pos[:, [1, 0]] # Swap x and y coordinates
        # revert order for y-axis (so that y=0 is top and x=0 is left)
        pos[:, 0] = org_shape[-2] - pos[:, 0] - 1.0
        # repeat depending on the number of dimensions preceding width and height
        num_graphs = math.prod(org_shape[:-2])
        pos = pos.repeat(num_graphs, 1)

        return pos

    """
    Transform a list of Entry objects to a single GraphEntry object.
    """
    def transform(self, entry: Entry) -> GraphEntry:
        return self.transform_unbatched(entry)

    def transform_unbatched(self, entry: Entry) -> GraphEntry:
        nodes_key = self.nodes
        nodes_value = entry[nodes_key]
        if isinstance(nodes_value, dict):
            if not all(band in self.gsd_mapping for band in nodes_value):
                raise ValueError("Not all bands in the entry have GSDs defined in gsd_mapping.")

            all_feats = []
            all_pos = []
            band_ids = []
            bands = []

            for b_idx, (band, gsd) in enumerate(self.gsd_mapping.items()):
                if band not in nodes_value:
                    continue
                feats = nodes_value[band]
                if feats.dim() == 3:
                    feats = feats.unsqueeze(0)
                if feats.dim() != 4:
                    raise ValueError(f"Invalid spatial dimensions for band {band}: {tuple(feats.shape)}")
                B, C, H, W = feats.shape
                feats = feats.flatten(2).transpose(1, 2).reshape(-1, C)
                all_feats.append(feats)

                ys = (torch.arange(H, dtype=torch.float32) + 0.5) * gsd
                xs = (torch.arange(W, dtype=torch.float32) + 0.5) * gsd
                grid_y, grid_x = torch.meshgrid(ys, xs, indexing='ij')
                coords = torch.stack([grid_y.flatten(), grid_x.flatten()], dim=1)
                coords = coords.repeat(B, 1)
                all_pos.append(coords)

                band_ids.append(torch.full((B * H * W, 1), b_idx, dtype=torch.int))
                bands.append(band)

            node_feat = torch.cat(all_feats, dim=0)
            pos = torch.cat(all_pos, dim=0)
            band_id = torch.cat(band_ids, dim=0)

            data_kwargs = {
                nodes_key: node_feat,
                "pos": pos,
                "band": band_id,
                "name": entry.name,
                "all_bands": bands,
            }
            if nodes_key != "nodes":
                data_kwargs[f"{nodes_key}_org"] = nodes_value
            for key in entry.keys():
                if key == "name":
                    continue
                if key == nodes_key:
                    continue
                obj = entry[key]
                if key in data_kwargs:
                    key = f"{key}_org"
                data_kwargs[key] = obj
            return GraphEntry(**data_kwargs)

        if isinstance(nodes_value, (list, tuple)):
            # Multi-image: list of K tensors each (C, H, W)
            # → stack to (1, C, K, H, W) so __flatten produces (K*H*W, C) nodes
            nodes_value = torch.stack(nodes_value, dim=1).unsqueeze(0)  # (1, C, K, H, W)
            entry[nodes_key] = nodes_value

        nodes = entry[nodes_key] # (B, C, ..., H, W)
        nodes_org = nodes  # keep original tensor before flattening
        nodes_org_shape = nodes.shape
        nodes = self.__flatten(nodes) # (B*N, C)

        result_kwargs = {}
        for key in entry.keys():
            if key != nodes_key:
                if isinstance(entry[key], torch.Tensor) and entry[key].shape == nodes_org_shape:
                    # Flatten every tensor with the same shape as nodes to make sure they are aligned
                    entry[key] = self.__flatten(entry[key])
                elif isinstance(entry[key], torch.Tensor) and entry[key].dim() >= 3:
                    # Add leading dim for graph-level spatial tensors (e.g. hr)
                    # so PyG batching concatenates along dim 0 → (B, C, H, W)
                    entry[key] = entry[key].unsqueeze(0)
                result_kwargs[key] = entry[key]
        result_kwargs[nodes_key] = nodes
        result_kwargs[f"{nodes_key}_org"] = nodes_org
        result_kwargs[f"{nodes_key}_org_shape"] = torch.tensor(nodes_org_shape[1:]).unsqueeze(0)
        if self.add_pos:
            batch_h_w = (nodes_org_shape[0], *nodes_org_shape[2:])
            result_kwargs["pos"] = self._pos_grid_template(batch_h_w)
        return GraphEntry(**result_kwargs)

    def __flatten(self, nodes):
        nodes = torch.flatten(nodes, 2, -1) # (B, C, N)
        nodes = nodes.permute(0, 2, 1).contiguous() # (B, N, C)
        nodes = nodes.reshape(-1, nodes.shape[-1]) # (B*N, C)
        return nodes

import numpy as np
import matplotlib.pyplot as plt


def plot_graph_entry(graph):
    """
    Scatter-plot a GraphEntry of multispectral data:
      - node positions in meters from graph.pos
      - marker size proportional to the band's GSD (scaled up for visibility)
      - marker color = band ID

    :param graph: GraphEntry with attributes
                   - graph.pos (num_nodes x 2 tensor/array)
                   - graph.band (num_nodes x 1 tensor/array of band indices)
    :param gsd_mapping: Dict[int, float] mapping each band index (0,1,2,...) to its GSD in meters
    """

    # 1) to numpy arrays
    pos = np.array(graph.pos.tolist() if hasattr(graph.pos, "tolist") else graph.pos)
    band_ids = np.array(graph.band.tolist() if hasattr(graph.band, "tolist") else graph.band).flatten()

    # 2) compute sizes
    sizes = graph.band.numpy()

    # 3) choose a categorical colormap
    unique_bands = np.unique(band_ids)
    cmap = plt.cm.get_cmap('tab10', len(unique_bands))

    # 4) plot
    plt.figure(figsize=(8, 8))
    unique = sorted(set(unique_bands))  # [10,20,60]
    cat_map = {g: i for i, g in enumerate(unique)}  # {10:0,20:1,60:2}
    cats = np.array([cat_map[g] for g in sizes[:, 0]])
    sc = plt.scatter(pos[:, 1], pos[:, 0],
                     s=sizes,
                     c=cats,
                     cmap=cmap,
                     marker='s',
                     alpha=0.7)
    cbar = plt.colorbar(sc, ticks=unique_bands)
    cbar.set_label('Band ID')
    plt.gca().invert_yaxis()  # optional: match image coords
    plt.title("Multispectral Graph Nodes")
    plt.xlabel("X position (m)")
    plt.ylabel("Y position (m)")
    plt.show()
