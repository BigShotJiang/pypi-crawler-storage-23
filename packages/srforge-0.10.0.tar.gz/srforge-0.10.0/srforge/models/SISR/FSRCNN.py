import collections
import typing

from torch.nn import Sigmoid
from torch.nn import modules


from srforge.models import Model
from srforge.registry import register_class

# Description of these parameters can be found in the paper.
FSRCNNSensitiveParameters = collections.namedtuple("FSRCNNParameters",
                                                   ["feature_dimensions",
                                                    "feature_shrinking"])


def calculate_padding(kernel_size: int) -> int:
    """Calculates padding for a 'same' convolution.

    Args:
        kernel_size (int): The size of the convolutional kernel.

    Returns:
        int: The padding required to keep the output dimensions the same as the
             input.

    Raises:
        RuntimeError: If the kernel size is even.
    """
    if kernel_size % 2 == 0:
        raise RuntimeError("Padding cannot be calculated for kernel with "
                           "even size.")
    return kernel_size // 2

@register_class
class FSRCNN(Model):
    """Fast Super-Resolution Convolutional Neural Network (FSRCNN).

    An implementation of the model from the paper "Accelerating the
    Super-Resolution Convolutional Neural Network" by Dong et al.

    Reference:
        https://arxiv.org/abs/1608.00367
    """
    EXTRACTION_KERNEL_SIZE = 5
    SHRINKING_KERNEL_SIZE = 1
    MAPPING_KERNEL_SIZE = 3
    EXPANDING_KERNEL_SIZE = 1
    DECONVOLUTION_KERNEL_SIZE = 9
    def __init__(self, channels: int = 1,
                 upscale_factor: int = 3,
                 non_linear_mapping_layers: int = 4,
                 feature_dimensions: int = 56,
                 feature_shrinking: int = 16):
        """Initializes the FSRCNN model.

        Args:
            channels (int, optional): The number of input and output image
                channels (e.g., 1 for grayscale, 3 for RGB). Defaults to 1.
            upscale_factor (int, optional): The target upscaling factor.
                Defaults to 3.
            non_linear_mapping_layers (int, optional): The number of mapping
                layers (m in the paper). Defaults to 4.
            feature_dimensions (int, optional): The number of feature dimensions
                in the extraction layer (d in the paper). Defaults to 56.
            feature_shrinking (int, optional): The number of channels in the
                shrinking layer (s in the paper). Defaults to 16.
        """
        d = feature_dimensions
        s = feature_shrinking
        super().__init__()
        feature_extraction = modules.Sequential(
            modules.Conv2d(in_channels=channels, out_channels=d,
                           kernel_size=FSRCNN.EXTRACTION_KERNEL_SIZE,
                           padding=calculate_padding(
                               self.EXTRACTION_KERNEL_SIZE)),
            modules.PReLU())
        shrinking = modules.Sequential(
            modules.Conv2d(in_channels=d, out_channels=s,
                           kernel_size=self.SHRINKING_KERNEL_SIZE),
            modules.PReLU())
        non_linear_mapping = []
        for _ in range(non_linear_mapping_layers):
            non_linear_mapping.append(
                modules.Conv2d(in_channels=s, out_channels=s,
                               kernel_size=self.MAPPING_KERNEL_SIZE,
                               padding=calculate_padding(
                                   self.MAPPING_KERNEL_SIZE)))
            non_linear_mapping.append(modules.PReLU())

        expanding = modules.Sequential(
            modules.Conv2d(in_channels=s, out_channels=d,
                           kernel_size=self.EXPANDING_KERNEL_SIZE),
            modules.PReLU())

        pad, out_pad = _calculate_deconvolution_padding(upscale_factor)
        deconvolution = modules.ConvTranspose2d(in_channels=d,
                                                out_channels=channels,
                                                kernel_size=self.DECONVOLUTION_KERNEL_SIZE,
                                                stride=upscale_factor,
                                                padding=pad,
                                                output_padding=out_pad
                                                )

        self.full_model = modules.Sequential(feature_extraction,
                                             shrinking,
                                             *non_linear_mapping,
                                             expanding,
                                             deconvolution)

    def _forward(self, x):
        """Defines the forward pass for the FSRCNN model.

        Args:
            x (torch.Tensor): The low-resolution input tensor.

        Returns:
            torch.Tensor: The super-resolved output tensor.
        """
        x = self.full_model(x)
        return Sigmoid()(x)


def _calculate_deconvolution_padding(factor: int) \
        -> typing.Tuple[int, int]:
    """Calculates padding for the deconvolution layer for a given upscale factor.

    For different scale factors, the image must be padded differently so the
    output image shape is scaled correctly without losing pixels at the borders.

    Args:
        factor (int): The upscale factor.

    Returns:
        typing.Tuple[int, int]: A tuple of (padding, output_padding) to be
                                applied at the deconvolution layer.
    """
    paddings = {
        2: (4, 1),
        3: (3, 0),
        4: (3, 1),
        8: (2, 3),
    }
    padding, output_padding = paddings.setdefault(factor, (3, 1))
    return padding, output_padding
