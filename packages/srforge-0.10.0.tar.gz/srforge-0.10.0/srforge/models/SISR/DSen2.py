import torch
import torch.nn as nn
import torch.nn.functional as F

from srforge.registry import register_class
from srforge.models import Model
from srforge.data.multispectral.descriptors import Sentinel2Descriptor as s2

class ResBlock(nn.Module):
    """A standard residual block with two convolutional layers."""
    def __init__(self, channels, kernel_size=3, scale=0.1):
        """Initializes the ResBlock.

        Args:
            channels (int): The number of input and output channels.
            kernel_size (int, optional): The size of the convolutional kernel.
                Defaults to 3.
            scale (float, optional): A scaling factor applied to the residual
                branch before addition. Defaults to 0.1.
        """
        super().__init__()
        self.scale = scale
        self.conv_block = nn.Sequential(
            nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=kernel_size, padding=kernel_size // 2),
            nn.ReLU(),
            nn.Conv2d(in_channels=channels, out_channels=channels, kernel_size=kernel_size, padding=kernel_size // 2)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Defines the forward pass for the residual block.

        Args:
            x (torch.Tensor): The input tensor.

        Returns:
            torch.Tensor: The output tensor after applying the residual connection.
        """
        tmp = self.conv_block(x) * self.scale
        return tmp + x

@register_class
class DSen2(Model):
    """Implementation of the DSen2 model for Sentinel-2 super-resolution.

    This model is designed to super-resolve 20m and 60m Sentinel-2 bands to
    10m resolution, using the 10m bands as a reference.

    Reference:
        Lanaras, C., Bioucas-Dias, J., Baltsavias, E., & Schindler, K. (2018).
        Super-resolution of Sentinel-2 images: Learning a globally applicable
        deep neural network. ISPRS Journal of Photogrammetry and Remote Sensing.
    """
    def __init__(self, num_layers=32, feature_size=256, input_channels=12, return_10m_bands=True):
        """Initializes the DSen2 model.

        Args:
            num_layers (int, optional): The number of residual blocks in the
                main body of the network. Defaults to 32.
            feature_size (int, optional): The number of channels in the
                intermediate feature maps. Defaults to 256.
            input_channels (int, optional): The total number of input channels
                from all concatenated Sentinel-2 bands. Defaults to 12.
            return_10m_bands (bool, optional): If True, the output dictionary will
                also include the original, untouched 10m bands. Defaults to True.
        """
        super().__init__()
        self.return_10m_bands = return_10m_bands
        self.initial_conv = nn.Sequential(
            nn.Conv2d(in_channels=input_channels, out_channels=feature_size, kernel_size=3, padding=1),
            nn.ReLU()
        )
        res_blocks = [ResBlock(feature_size) for _ in range(num_layers)]
        self.res_blocks = nn.Sequential(*res_blocks)
        self.bands_to_upsample = (set(s2.gsd_groups()[20.0]) | set(s2.gsd_groups()[60.0]))
        self.final_conv = nn.ModuleDict(
            {k: nn.Conv2d(in_channels=feature_size, out_channels=1, kernel_size=3, padding=1)
             for k in self.bands_to_upsample}
        )

    def _forward(self, lrs: dict[str, torch.Tensor]) -> dict[str, torch.Tensor]:
        """Defines the forward pass for the DSen2 model.

        Args:
            lrs (dict[str, torch.Tensor]): A dictionary of low-resolution input
                tensors, where keys are Sentinel-2 band names (e.g., 'b1', 'b2').

        Returns:
            dict[str, torch.Tensor]: A dictionary containing the super-resolved
                bands. The keys are the band names.
        """
        available_bands = set(lrs.keys())
        lr_images = lrs
        bands = sorted(list(lr_images.keys())) # TODO: use Sentinel2Descriptor band_indices field for consistency
        max_shape = max([(v.shape[-2], v.shape[-1]) for v in lr_images.values()])
        lr_images = {k: F.interpolate(lr_images[k], max_shape, mode='bicubic') for k in bands}
        x = [lr_images[k] for k in bands]
        x = torch.cat(x, dim=1)
        x = self.initial_conv(x)
        x = self.res_blocks(x)
        result = {}
        for band in available_bands & self.bands_to_upsample:
            result[band] = self.final_conv[band](x) + lr_images[band]
        if self.return_10m_bands:
            for band in available_bands - self.bands_to_upsample:
                result[band] = lr_images[band]
        return result
