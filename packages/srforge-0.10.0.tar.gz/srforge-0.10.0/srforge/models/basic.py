from typing import Optional, Union

from srforge.models import Model
from srforge.registry import register_class

import torch
import torch.nn.functional as F

@register_class
class Bicubic(Model):
    """A model that performs bicubic upsampling.

    This model can upscale an image by a fixed factor or to match the
    dimensions of a provided high-resolution target image. It can operate
    on single tensors or dictionaries of tensors.
    """
    def __init__(self, scale: Union[int, dict[str, int]]):
        """Initializes the Bicubic model.

        Args:
            scale (Union[int, dict[str, int]]): The upsampling factor. Can be
                a single integer for all inputs or a dictionary mapping keys
                to integer scales for dictionary inputs.
        """
        super().__init__()
        self.scale = scale

    def _interpolate(self, x: torch.Tensor, hr: Optional[torch.Tensor] = None, scale: Optional[int] = None) -> torch.Tensor:
        """Helper function to perform the interpolation."""
        if hr is not None:
            scale = round(hr.shape[-1] / x.shape[-1])
        elif scale is None:
            scale = self.scale
        
        # The original implementation seems to have a bug in handling dimensions.
        # This simplified version should be more robust.
        if x.ndim == 3:
            x = x.unsqueeze(0) # Add batch dimension if missing
        
        return F.interpolate(x, scale_factor=scale, mode='bicubic', align_corners=False)

    def _forward(self, image: Union[torch.Tensor, dict[str, torch.Tensor]],
                 hr: Optional[Union[torch.Tensor, dict[str, torch.Tensor]]] = None) -> Union[torch.Tensor, dict[str, torch.Tensor]]:
        """Upsamples the input image(s).

        Args:
            image (Union[torch.Tensor, dict[str, torch.Tensor]]): The low-resolution
                input. Can be a single tensor or a dictionary of tensors.
            hr (Optional[Union[torch.Tensor, dict[str, torch.Tensor]]], optional):
                An optional high-resolution reference tensor or dictionary of
                tensors to infer the output size. Defaults to None.

        Returns:
            Union[torch.Tensor, dict[str, torch.Tensor]]: The upsampled image(s).
        """
        if isinstance(image, dict):
            output = {}
            if isinstance(self.scale, dict):
                for k in image.keys():
                    if k not in self.scale:
                        raise KeyError(f"Scale for key {k} not found in scale dict")
                for k, v in image.items():
                    output[k] = self._interpolate(v, scale=self.scale[k])
            else:
                if not isinstance(hr, dict):
                    raise TypeError("hr must be a dict if lrs is a dict and scale is not a dict")
                for k in image.keys():
                    if k not in hr:
                        raise KeyError(f"Key {k} not found in hr dict")
                for k, v in image.items():
                    output[k] = self._interpolate(v, hr=hr[k])
        else:
            output = self._interpolate(image, hr)
        return output

@register_class
class HR(Model):
    """A model that simply passes the high-resolution image through.

    This is useful in `SequentialModel` flows where a specific stage might
    need to access the original HR image, or for debugging purposes. It acts
    as an identity function for the 'hr' input.
    """
    def __init__(self):
        super().__init__()

    def _forward(self, hr: Union[torch.Tensor, dict[str, torch.Tensor]]) -> Union[torch.Tensor, dict[str, torch.Tensor]]:
        """Returns the input 'hr' tensor or dictionary of tensors.

        Args:
            hr (Union[torch.Tensor, dict[str, torch.Tensor]]): The high-resolution
                input.

        Returns:
            Union[torch.Tensor, dict[str, torch.Tensor]]: The unchanged 'hr' input.
        """
        return hr
