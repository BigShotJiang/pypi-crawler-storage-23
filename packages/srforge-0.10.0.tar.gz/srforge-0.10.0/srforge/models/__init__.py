import abc
import logging
import inspect
import warnings
from typing import Tuple, Union, List, Dict, Any, overload

import torch

from srforge.data import Entry, GraphEntry
from srforge.transform import EntryTransform, DataTransform
from srforge.utils import obj_to_str, IOSpec, IOModule
from srforge.registry import register_class
from srforge.utils.io_parsing import parse_io_config, build_applications, flat_to_applications

try:
    import graphviz
except ImportError:
    graphviz = None

logger = logging.getLogger(__name__)

class Model(IOModule, torch.nn.Module, abc.ABC):
    _install_io_ports = False

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        has_forward = 'forward' in cls.__dict__
        has_private = '_forward' in cls.__dict__
        if has_forward and has_private:
            raise TypeError(
                f"Class {cls.__name__} defines both 'forward' and '_forward'. "
                f"Define only one — 'forward' is recommended."
            )
        if has_forward:
            # Transparently move the user's forward() to _forward() so that
            # Model.forward (the IO routing layer) is inherited unchanged.
            cls._forward = cls.__dict__['forward']
            delattr(cls, 'forward')

    def __init__(
        self,
        name: str = None,
        io_spec: IOSpec | None = None,
    ):
        """Initialize the model and optionally attach its IO contract."""
        super().__init__()
        self._name = name
        # Resolve the IO spec from an explicit instance or a class-level declaration.
        if io_spec is not None:
            if not isinstance(io_spec, IOSpec):
                raise TypeError(f"io_spec must be an IOSpec, got {type(io_spec)}.")
            self.io_spec = io_spec
        elif isinstance(getattr(self.__class__, "io_spec", None), IOSpec):
            self.io_spec = self.__class__.io_spec
        # Safety check: forward() should always resolve to Model.forward (the routing layer).
        # __init_subclass__ handles the rename, so this only triggers on manual monkey-patching.
        if self.__class__.forward is not Model.forward:
            raise RuntimeError(
                f"Class {self.__class__.__name__}: 'forward' was not processed correctly. "
                f"Define forward() in the class body (not assigned after class creation)."
            )
        # Cache the _forward signature for IO binding/inference.
        self._signature = inspect.signature(self._forward)

        # Ensure io_spec is never None — auto-create from signature if needed.
        spec = self.io_spec
        if spec is None:
            _, required, optional = self._infer_input_names()
            spec = IOSpec(required_inputs=tuple(required), optional_inputs=tuple(optional))
        elif isinstance(spec, IOSpec) and not spec.all_inputs:
            _, required, optional = self._infer_input_names()
            spec = spec.replace(required_inputs=tuple(required), optional_inputs=tuple(optional))
        self.io_spec = spec

        # Auto-create applications from IOSpec (backward compat for models with declared IO).
        if self.io_spec.all_inputs and self.io_spec.all_outputs:
            input_map = {name: name for name in self.io_spec.all_inputs}
            output_fields = list(self.io_spec.all_outputs)
            self._applications = [(input_map, output_fields)]
        else:
            self._applications = []

    @property
    def name(self):
        """Human-readable name used in output merges and error messages."""
        if self._name:
            return self._name
        return self.__class__.__name__

    @name.setter
    def name(self, value):
        """Override the display name for this model instance."""
        self._name = value

    def set_io(self, io_cfg, *, strict: bool = True, require_all: bool = True):
        """Bind IO mapping using the unified config format.

        Accepts: ``{"inputs": {param: field}, "outputs": <string|list|dict>}``
        """
        inputs_raw, outputs_raw = parse_io_config(io_cfg)
        self._applications = build_applications(inputs_raw, outputs_raw)
        self._io_bound = True
        return self

    @overload
    def forward(self, data: Entry) -> Entry: ...
    @overload
    def forward(self, data: GraphEntry) -> GraphEntry: ...
    @overload
    def forward(self, *args, **kwargs) -> Any: ...

    def forward(self, *args, **kwargs) -> Any:
        """Route Entry/GraphEntry calls through IO binding; otherwise call _forward directly."""
        all_args = args + tuple(kwargs.values())
        if any(isinstance(arg, (Entry, GraphEntry)) for arg in all_args):
            if len(all_args) != 1:
                raise TypeError("Cannot mix Entry and non-Entry arguments in the forward method.")
            arg = all_args[0]
            if isinstance(arg, Entry):
                return self._forward_entry(arg)
            if isinstance(arg, GraphEntry):
                return self._forward_graph_entry(arg)
        return self._forward(*args, **kwargs)

    def _forward_entry(self, data: Entry) -> Entry:
        """Execute model using applications to map Entry fields to _forward parameters."""
        if not self._applications:
            raise ValueError(
                f"{self.__class__.__name__} has no output ports declared. "
                f"Call set_io() with output mappings or declare io_spec with required_outputs."
            )
        for input_map, output_fields in self._applications:
            kwargs = {}
            for param, field in input_map.items():
                sig_param = self._signature.parameters.get(param)
                if field not in data:
                    if sig_param and sig_param.default != sig_param.empty:
                        continue
                    raise KeyError(f"Required field '{field}' not found in Entry for {self.name}.")
                kwargs[param] = data[field]
            result = self._forward(**kwargs)
            if not isinstance(result, (tuple, list)):
                result = (result,)
            if len(result) != len(output_fields):
                raise ValueError(
                    f"{self.name} returned {len(result)} values but expects {len(output_fields)} outputs."
                )
            data = data.merge_fields(dict(zip(output_fields, result)), source=self.name)
        return data

    def _forward_graph_entry(self, data: GraphEntry) -> GraphEntry:
        """Execute model on a GraphEntry."""
        if not self._applications:
            raise ValueError(
                f"{self.__class__.__name__} has no output ports declared. "
                f"Call set_io() with output mappings or declare io_spec with required_outputs."
            )
        result = self._forward(data)
        if not isinstance(result, (tuple, list)):
            result = (result,)
        _, output_fields = self._applications[0]
        if len(result) != len(output_fields):
            raise ValueError(
                f"Expected {len(output_fields)} outputs, got {len(result)} from {self.__class__.__name__}."
            )
        return data.merge_fields(dict(zip(output_fields, result)), source=self.name)

    @abc.abstractmethod
    def _forward(self, *args, **kwargs) -> Any:
        """Implement the model's computation; do not override forward()."""
        raise NotImplementedError(f"Method '_forward' not implemented for {self.__class__.__name__}.")

    def __repr__(self):
        """Pretty-print instance with init parameters."""
        return obj_to_str(self)

    def _infer_input_names(self) -> Tuple[Tuple[str, ...], Tuple[str, ...], Tuple[str, ...]]:
        """Infer input names from the _forward method signature."""
        required: List[str] = []
        optional: List[str] = []
        for name, param in self._signature.parameters.items():
            # Skip variadic args/kwargs; they don't map to named Entry fields.
            if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                continue
            if param.default is inspect.Parameter.empty:
                required.append(name)
            else:
                optional.append(name)
        inferred = tuple(required + optional)
        return inferred, tuple(required), tuple(optional)

    def trainable_params(self) -> List[torch.nn.Parameter]:
        """Return parameters that require gradients.

        Returns:
            List[torch.nn.Parameter]: Trainable parameters.
        """
        return [p for p in self.parameters() if p.requires_grad]

@register_class
class SequentialModel(Model):
    """Defines a flow of Models and transforms that operate on an Entry.

    All module types (Model, EntryTransform, DataTransform) are configured
    uniformly — the flow DSL is the single source of truth for IO binding.

    Args:
        modules: Dict mapping names to module instances (Model, EntryTransform,
            or DataTransform).
        flow: The flow specification as a multiline string, list of strings,
            or list of ``{"flow": "..."}`` dicts.

    Flow DSL::

        <inputs> -> <module> -> <outputs>

    Module types:
      - **Model**: Named mapping in the module segment or positional on LHS/RHS.
      - **EntryTransform**: IO inferred from flow via IOSpec (positional or named).
      - **DataTransform**: Positional IO from LHS/RHS.

    Examples::

        x -> m1 -> y
        (x, g) -> m1(x=x, guide=g) -> (output=out, aux=meta)
        x, mask -> t1 -> result
        (x, mask) -> t1(image=x, mask=mask) -> (output=result)
        x -> mul -> y
    """

    class Step:
        def __init__(
            self,
            *,
            name: str,
            module: Any,
            kind: str,
            entry_inputs: List[str],
            entry_outputs: List[str],
            input_map: Dict[str, str] | None = None,
            output_map: Dict[str, str] | None = None,
            applications: List[Tuple[Dict[str, str], List[str]]] | None = None,
            recurse_params: set | None = None,
        ):
            self.name = name
            self.module = module
            self.kind = kind
            self.entry_inputs = entry_inputs
            self.entry_outputs = entry_outputs
            self.input_map = input_map or {}
            self.output_map = output_map or {}
            self.applications = applications
            self.recurse_params = recurse_params

    def __init__(
        self,
        modules: dict[str, Any] | None = None,
        flow: str | list | dict[str, Any] | None = None,
        *,
        name: str = None,
        models: dict[str, Any] | None = None,
    ):
        super().__init__(name=name, io_spec=IOSpec())

        # --- backward-compat: accept 'models' kwarg -------------------------
        if models is not None and modules is not None:
            raise ValueError("Cannot specify both 'modules' and 'models'. Use 'modules'.")
        if models is not None:
            warnings.warn(
                "The 'models' parameter is deprecated. Use 'modules' instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            modules = models
        modules = modules or {}

        # --- backward-compat: accept flow as nested dict ---------------------
        if isinstance(flow, dict):
            if "flow" not in flow:
                raise ValueError("SequentialModel flow dict must contain a 'flow' key.")
            warnings.warn(
                "Passing flow as a dict is deprecated. Pass the flow string or list directly.",
                DeprecationWarning,
                stacklevel=2,
            )
            modules = flow.get("blocks", modules) or modules
            flow_spec = flow["flow"]
        elif isinstance(flow, (str, list, tuple)):
            flow_spec = flow
        elif flow is None:
            raise ValueError("SequentialModel requires a flow specification.")
        else:
            raise TypeError(f"Invalid flow type: {type(flow)}. Expected str, list, or dict.")

        if not isinstance(modules, dict) or len(modules) == 0:
            raise ValueError("SequentialModel requires a non-empty modules dict.")

        self.steps, required_inputs = self._build_steps_from_flow(flow_spec, modules)
        self.io_spec = self.io_spec.replace(
            required_inputs=tuple(required_inputs),
            optional_inputs=tuple(),
            required_outputs=tuple(),
            optional_outputs=tuple(),
        )
        self.models = self._register_modules(modules)

    # ------------------------------------------------------------------
    # Parsing helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _strip_segment(segment: str) -> str:
        seg = segment.strip()
        if seg == "()":
            return ""
        if seg.startswith("(") and seg.endswith(")"):
            seg = seg[1:-1].strip()
        return seg

    @staticmethod
    def _parse_segment(segment: str) -> Tuple[List[str], Dict[str, str]]:
        seg = SequentialModel._strip_segment(segment)
        if not seg:
            return [], {}
        parts = [p.strip() for p in seg.split(",") if p.strip()]
        positional: List[str] = []
        mapping: Dict[str, str] = {}
        for item in parts:
            if "=" in item:
                key, val = item.split("=", 1)
                key = key.strip()
                val = val.strip()
                if not key or not val:
                    raise ValueError(f"Invalid mapping '{item}' in segment '{segment}'.")
                if key in mapping:
                    raise ValueError(f"Duplicate mapping key '{key}' in segment '{segment}'.")
                mapping[key] = val
            else:
                positional.append(item)
        if len(positional) != len(set(positional)):
            raise ValueError(f"Duplicate names in segment '{segment}'.")
        return positional, mapping

    @staticmethod
    def _parse_module_segment(segment: str) -> Tuple[str, Dict[str, str]]:
        seg = segment.strip()
        if "(" in seg:
            start = seg.index("(")
            end = seg.rindex(")")
            name = seg[:start].strip()
            inner = seg[start + 1:end].strip()
            positional, mapping = SequentialModel._parse_segment(inner)
            for item in positional:
                if item in mapping:
                    raise ValueError(f"Duplicate mapping key '{item}' in module segment '{segment}'.")
                mapping[item] = item
        else:
            name = seg
            mapping = {}
        if not name:
            raise ValueError(f"Invalid module segment: '{segment}'.")
        return name, mapping

    @staticmethod
    def _is_entry_transform(module: Any) -> bool:
        return isinstance(module, EntryTransform)

    @staticmethod
    def _is_data_transform(module: Any) -> bool:
        return isinstance(module, DataTransform)


    # ------------------------------------------------------------------
    # Flow building
    # ------------------------------------------------------------------

    def _build_steps_from_flow(
        self,
        flow_spec: Union[str, List[Any]],
        modules: Dict[str, Any],
    ) -> Tuple[List["SequentialModel.Step"], List[str]]:
        raw_lines: List[str] = []
        if isinstance(flow_spec, str):
            raw_lines = [l.strip() for l in flow_spec.splitlines()]
        elif isinstance(flow_spec, (list, tuple)):
            for item in flow_spec:
                if isinstance(item, str):
                    raw_lines.append(item.strip())
                elif isinstance(item, dict) and "flow" in item:
                    raw_lines.append(str(item["flow"]).strip())
                else:
                    raise TypeError(f"Flow line must be a string, got {type(item)}.")
        else:
            raise TypeError(f"Invalid flow specification type: {type(flow_spec)}.")

        lines = [l for l in raw_lines if l and not l.lstrip().startswith("#")]
        steps: List[SequentialModel.Step] = []
        produced: set[str] = set()
        required_inputs: set[str] = set()

        for line in lines:
            parts = [p.strip() for p in line.split("->")]
            if len(parts) != 3:
                raise ValueError(f"Invalid flow line: '{line}'. Expected '<inputs> -> <module> -> <outputs>'.")
            lhs, mid, rhs = parts
            pos_inputs, map_inputs = self._parse_segment(lhs)
            pos_outputs, map_outputs = self._parse_segment(rhs)
            module_name, module_map = self._parse_module_segment(mid)

            if module_name not in modules:
                raise KeyError(f"Module '{module_name}' not found in modules.")
            module = modules[module_name]

            if isinstance(module, Model):
                step = self._build_model_step(
                    line, module_name, module, module_map,
                    pos_inputs, map_inputs, pos_outputs, map_outputs,
                )
            elif self._is_entry_transform(module):
                step = self._build_entry_transform_step(
                    line, module_name, module, module_map,
                    pos_inputs, map_inputs, pos_outputs, map_outputs,
                )
            elif self._is_data_transform(module):
                if module_map:
                    raise ValueError(
                        f"DataTransform '{module_name}' does not support named mapping in the module segment."
                    )
                step = self._build_data_transform_step(
                    line, module_name, module,
                    pos_inputs, map_inputs, pos_outputs, map_outputs,
                )
            else:
                raise TypeError(f"Unsupported module type for '{module_name}': {type(module)}.")

            for name in step.entry_inputs:
                if name not in produced:
                    required_inputs.add(name)
            produced.update(step.entry_outputs)
            steps.append(step)

        return steps, sorted(required_inputs)

    # ------------------------------------------------------------------
    # Build helpers shared between Model and EntryTransform
    # ------------------------------------------------------------------

    @staticmethod
    def _build_io_maps(
        module_name: str,
        line: str,
        spec: IOSpec,
        module_map: Dict[str, str],
        pos_inputs: List[str],
        map_inputs: Dict[str, str],
        pos_outputs: List[str],
        map_outputs: Dict[str, str],
    ) -> Tuple[Dict[str, str], Dict[str, str], List[str], List[str]]:
        """Build input_map and output_map from flow DSL and IOSpec.

        Returns (input_map, output_map, entry_inputs, entry_outputs).
        """
        all_inputs = list(spec.all_inputs)
        required_in = list(spec.required_inputs)
        optional_in = list(spec.optional_inputs)

        # --- Input mapping ---------------------------------------------------
        input_map: Dict[str, str] = {}
        if module_map:
            # Named mapping in module segment: t1(image=x, mask=guide)
            unknown = set(module_map.keys()) - set(all_inputs)
            if unknown:
                raise ValueError(
                    f"Module '{module_name}' input mapping has unknown keys: {sorted(unknown)}."
                )
            missing_required = set(required_in) - set(module_map.keys())
            if missing_required:
                raise ValueError(
                    f"Module '{module_name}' is missing required inputs: {sorted(missing_required)}."
                )
            input_map = dict(module_map)
            if pos_inputs:
                if set(pos_inputs) != set(module_map.values()):
                    raise ValueError(
                        f"Module '{module_name}' input mapping values must match LHS entries in '{line}'."
                    )
        elif map_inputs:
            # Named mapping on LHS: (image=x, mask=guide) -> t1
            unknown = set(map_inputs.keys()) - set(all_inputs)
            if unknown:
                raise ValueError(
                    f"Module '{module_name}' has unknown input vars on LHS: {sorted(unknown)}."
                )
            input_map = dict(map_inputs)
            # Fill remaining required inputs positionally
            mapped_ports = set(map_inputs.keys())
            idx = 0
            for port in required_in:
                if port not in mapped_ports:
                    if idx >= len(pos_inputs):
                        raise ValueError(
                            f"Module '{module_name}' is missing required input '{port}'."
                        )
                    input_map[port] = pos_inputs[idx]
                    idx += 1
            for port in optional_in:
                if port not in mapped_ports and idx < len(pos_inputs):
                    input_map[port] = pos_inputs[idx]
                    idx += 1
        else:
            # Pure positional: x, y -> t1
            if len(pos_inputs) < len(required_in) or len(pos_inputs) > len(all_inputs):
                raise ValueError(
                    f"Module '{module_name}' expects {len(required_in)}..{len(all_inputs)} inputs "
                    f"({all_inputs}), got {len(pos_inputs)}."
                )
            input_map = {name: val for name, val in zip(required_in, pos_inputs[:len(required_in)])}
            if len(pos_inputs) > len(required_in):
                extra = pos_inputs[len(required_in):]
                if len(extra) > len(optional_in):
                    raise ValueError(
                        f"Module '{module_name}' has too many inputs; optional inputs are {optional_in}."
                    )
                input_map.update({name: val for name, val in zip(optional_in, extra)})

        # --- Output mapping --------------------------------------------------
        all_outputs = list(spec.all_outputs)
        unknown_out = set(map_outputs.keys()) - set(all_outputs)
        if unknown_out:
            raise ValueError(
                f"Module '{module_name}' output mapping has unknown keys: {sorted(unknown_out)}."
            )

        remaining = [name for name in all_outputs if name not in map_outputs]
        if len(pos_outputs) != len(remaining):
            raise ValueError(
                f"Module '{module_name}' expects {len(remaining)} positional outputs "
                f"({remaining}), got {len(pos_outputs)}."
            )
        output_map = dict(map_outputs)
        output_map.update({name: val for name, val in zip(remaining, pos_outputs)})

        entry_inputs = list(input_map.values())
        entry_outputs = list(output_map.values())
        if len(entry_outputs) != len(set(entry_outputs)):
            raise ValueError(f"Duplicate outputs in flow line '{line}'.")

        return input_map, output_map, entry_inputs, entry_outputs

    # ------------------------------------------------------------------
    # Step builders
    # ------------------------------------------------------------------

    def _build_model_step(
        self,
        line: str,
        module_name: str,
        module: Model,
        module_map: Dict[str, str],
        pos_inputs: List[str],
        map_inputs: Dict[str, str],
        pos_outputs: List[str],
        map_outputs: Dict[str, str],
    ) -> "SequentialModel.Step":
        if map_inputs:
            raise ValueError(f"Model step '{module_name}' does not allow mapping on the LHS: '{line}'.")

        spec = module.io_spec
        has_declared_outputs = bool(spec.all_outputs)

        if not has_declared_outputs:
            # No declared output ports — positional-only outputs from flow RHS.
            if map_outputs:
                raise ValueError(
                    f"Model '{module_name}' has no declared output ports. "
                    f"Named output mapping requires io_spec with outputs. "
                    f"Use positional outputs instead."
                )
            if not pos_outputs:
                raise ValueError(
                    f"Model '{module_name}' has no declared output ports and "
                    f"no outputs in flow line."
                )
            # Create temp spec with synthetic output ports so _build_io_maps
            # can validate the input side normally.
            synthetic = tuple(f"_out{i}" for i in range(len(pos_outputs)))
            spec = spec.replace(required_outputs=synthetic)

        input_map, output_map, entry_inputs, entry_outputs = self._build_io_maps(
            module_name, line, spec, module_map,
            pos_inputs, map_inputs, pos_outputs, map_outputs,
        )

        if not has_declared_outputs:
            output_map = {}  # Signal positional output mode

        return SequentialModel.Step(
            name=module_name,
            module=module,
            kind="model",
            entry_inputs=entry_inputs,
            entry_outputs=entry_outputs,
            input_map=input_map,
            output_map=output_map,
        )

    def _build_entry_transform_step(
        self,
        line: str,
        module_name: str,
        module: Any,
        module_map: Dict[str, str],
        pos_inputs: List[str],
        map_inputs: Dict[str, str],
        pos_outputs: List[str],
        map_outputs: Dict[str, str],
    ) -> "SequentialModel.Step":
        if module.io_spec is None:
            raise ValueError(f"Module '{module_name}' does not define io_spec.")

        # Always derive IO maps from the flow DSL — flow is the source of truth.
        # Pre-binding is ignored inside SequentialModel; rebinding happens per step
        # at runtime for transform_unbatched.
        input_map, output_map, entry_inputs, entry_outputs = self._build_io_maps(
            module_name, line, module.io_spec, module_map,
            pos_inputs, map_inputs, pos_outputs, map_outputs,
        )

        return SequentialModel.Step(
            name=module_name,
            module=module,
            kind="entry_transform",
            entry_inputs=entry_inputs,
            entry_outputs=entry_outputs,
            input_map=input_map,
            output_map=output_map,
        )

    def _build_data_transform_step(
        self,
        line: str,
        module_name: str,
        module: Any,
        pos_inputs: List[str],
        map_inputs: Dict[str, str],
        pos_outputs: List[str],
        map_outputs: Dict[str, str],
    ) -> "SequentialModel.Step":
        if map_inputs or map_outputs:
            raise ValueError(f"DataTransform '{module_name}' does not allow mapping syntax: '{line}'.")

        if pos_outputs and not pos_inputs:
            raise ValueError(f"DataTransform '{module_name}' requires inputs in '{line}'.")

        if not pos_inputs:
            # No flow inputs — fall back to pre-existing binding for backward compat.
            bound = getattr(module, "_io_bound", False)
            if not bound:
                raise ValueError(
                    f"DataTransform '{module_name}' requires flow inputs/outputs or pre-bound io mappings."
                )
            mapping = module.resolved
            pos_inputs = list(mapping.keys())
            pos_outputs = [val for val in mapping.values() if val is not None]

        if not pos_outputs:
            pos_outputs = list(pos_inputs)
        if len(pos_outputs) != len(pos_inputs):
            raise ValueError(
                f"DataTransform '{module_name}' expects {len(pos_inputs)} outputs, got {len(pos_outputs)}."
            )
        if len(pos_outputs) != len(set(pos_outputs)):
            raise ValueError(f"Duplicate outputs in flow line '{line}'.")

        # Compute applications externally — don't mutate module instance state.
        flat_map = {src: dst for src, dst in zip(pos_inputs, pos_outputs)}
        sig = inspect.signature(module._transform_method)
        param_names = [
            name for name, p in sig.parameters.items()
            if name != "self" and p.kind not in (
                inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD
            )
        ]
        applications = flat_to_applications(flat_map, param_names)
        recurse_params = module._build_recurse_set()

        return SequentialModel.Step(
            name=module_name,
            module=module,
            kind="data_transform",
            entry_inputs=pos_inputs,
            entry_outputs=pos_outputs,
            applications=applications,
            recurse_params=recurse_params,
        )

    # ------------------------------------------------------------------
    # Module registration
    # ------------------------------------------------------------------

    def _register_modules(self, modules: dict[str, Any]) -> torch.nn.ModuleDict:
        modules_dict = torch.nn.ModuleDict()
        seen: Dict[int, str] = {}
        self._model_refs: Dict[str, Model] = {}

        for step in self.steps:
            if step.kind != "model":
                continue
            if not isinstance(step.module, Model):
                raise TypeError(f"Module '{step.name}' must be a Model, got {type(step.module)}.")
            self._model_refs[step.name] = step.module
            module_id = id(step.module)
            if module_id not in seen:
                modules_dict[step.name] = step.module
                seen[module_id] = step.name

        for name, mod in modules.items():
            if name not in self._model_refs and isinstance(mod, Model):
                logger.warning(f"Module '{name}' not used in the Sequential flow. Consider removing it.")

        return modules_dict

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def _forward_entry(self, data: Entry) -> Entry:
        for step in self.steps:
            if step.kind == "entry_transform":
                for name in step.entry_inputs:
                    if name not in data:
                        raise KeyError(f"Transform step '{step.name}' missing input '{name}'.")

                # Rebind ports for this step, then execute.
                io_cfg = {}
                io_cfg.update(step.input_map)
                io_cfg.update(step.output_map)
                step.module.bind_io(io_cfg, strict=False, require_all=False)
                data = step.module(data)

                for out_name in step.entry_outputs:
                    if out_name not in data:
                        raise KeyError(f"Transform step '{step.name}' did not produce '{out_name}'.")
                continue

            if step.kind == "data_transform":
                for name in step.entry_inputs:
                    if name not in data:
                        raise KeyError(f"Transform step '{step.name}' missing input '{name}'.")
                # Drive DataTransform externally using per-step applications.
                for input_map, output_fields in step.applications:
                    kwargs = {}
                    for param, field in input_map.items():
                        if field not in data:
                            raise KeyError(f"Target '{field}' not found in entry for transformation {step.name}.")
                        kwargs[param] = data[field]
                    result = step.module._apply_recursive(kwargs, step.recurse_params)
                    if len(output_fields) == 1:
                        data[output_fields[0]] = result
                    else:
                        for field, val in zip(output_fields, result):
                            data[field] = val
                for out_name in step.entry_outputs:
                    if out_name not in data:
                        raise KeyError(f"Transform step '{step.name}' did not produce '{out_name}'.")
                continue

            if step.kind == "model":
                inputs: Dict[str, Any] = {}
                for model_inp, entry_name in step.input_map.items():
                    if entry_name not in data:
                        sig_param = step.module._signature.parameters.get(model_inp)
                        if sig_param and sig_param.default != sig_param.empty:
                            continue
                        raise KeyError(f"SequentialModel missing input '{entry_name}' for module '{step.name}'.")
                    inputs[model_inp] = data[entry_name]
                result = step.module._forward(**inputs)

                if step.output_map:
                    # Named output mode — zip with IOSpec port names, then remap.
                    if not isinstance(result, (tuple, list)):
                        result = (result,)
                    output_ports = step.module.io_spec.all_outputs
                    if len(result) != len(output_ports):
                        raise ValueError(
                            f"Module '{step.name}' returned {len(result)} values "
                            f"but expects {len(output_ports)} outputs: {output_ports}."
                        )
                    port_values = dict(zip(output_ports, result))
                    outputs_dict: Dict[str, Any] = {}
                    for port, entry_name in step.output_map.items():
                        if port not in port_values:
                            raise KeyError(f"Module '{step.name}' did not return output '{port}'.")
                        outputs_dict[entry_name] = port_values[port]
                else:
                    # Positional output mode — zip return values with entry fields.
                    entry_outputs = step.entry_outputs
                    if not isinstance(result, (tuple, list)):
                        result = (result,)
                    if len(result) != len(entry_outputs):
                        raise ValueError(
                            f"Module '{step.name}' returned {len(result)} values "
                            f"but flow expects {len(entry_outputs)} outputs: {entry_outputs}."
                        )
                    outputs_dict = dict(zip(entry_outputs, result))

                data = data.merge_fields(outputs_dict, source=step.name)
                continue

            raise TypeError(f"Unknown step kind '{step.kind}' for '{step.name}'.")

        return data

    def _forward(self, *args, **kwargs) -> Any:
        raise NotImplementedError("SequentialModel expects an Entry input.")
