from .TRMISR import TRMISR
from .RAMS import RAMS
from .MagNAt import MagNAt
