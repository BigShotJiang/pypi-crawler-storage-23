import torch
from torch.nn import modules, ModuleList

import torch_geometric as tg
from torch_geometric.nn import radius_graph

from srforge.models import Model
from srforge.data import GraphEntry
from srforge.registry import register_class


from srforge.models.MISR.TRMISR import Encoder
from srforge.nn.graph.embedding import EdgeAttentionEmbedding
from srforge.nn.graph.convolution import SplineGat
from srforge.nn.graph.convert import graph_to_image2d_uneven, graph_to_image2d
from srforge.nn.graph.aggregation import masked_mean, masked_median
from srforge.nn.graph.interpolation import ConvolutionalUpscaling
from srforge.nn.graph.transforms import cartesian
from srforge.nn.graph.dropout import EdgeDropout

@register_class
class MagNAt_vanilla(Model):
    """A vanilla implementation of the MagNAt model.

    This version appears to be a baseline or earlier version of the MagNAt model
    for multi-image super-resolution, built using PyTorch Geometric. It includes
    a registration network (RegNet) to estimate shifts between input images.
    """

    def __init__(self, in_channels: int = 1, d=56, s=16,  scale: int = 3, processing_layers: int = 4,
                 attention_heads: int = 1, radius: float = 1.0, filter_size: int = 9,
                 regnet_bias: bool = True, remove_masked=False, **kwargs):
        """Initializes the MagNAt_vanilla model.

        Args:
            in_channels (int, optional): Number of input channels for each image.
            d (int, optional): Base feature dimension size.
            s (int, optional): Shrinking layer feature dimension size.
            scale (int, optional): The target upscaling factor.
            processing_layers (int, optional): Number of non-linear mapping layers.
            attention_heads (int, optional): Number of heads in EdgeAttentionEmbedding.
            radius (float, optional): Radius for graph construction.
            filter_size (int, optional): Kernel size for the dynamic filter generation in RegNet.
            regnet_bias (bool, optional): Whether to use a bias in the final RegNet layer.
            remove_masked (bool, optional): If True, removes masked nodes before processing.
            **kwargs (Any): Additional keyword arguments.
        """
        super().__init__()


        self.radius = radius
        self.in_channels = in_channels
        self.remove_masked = remove_masked
        self.dyn_filter_size = filter_size
        self.regnet = torch.nn.Sequential(
            torch.nn.Conv3d(in_channels=in_channels, out_channels=128, kernel_size=(2, 3, 3), stride=(2, 1, 1),
                            padding=(0, 1, 1), padding_mode='reflect'),
            torch.nn.LeakyReLU(0.2),
            torch.nn.Conv3d(in_channels=128, out_channels=64, kernel_size=(1, 3, 3), stride=(1, 1, 1),
                            padding=(0, 1, 1), padding_mode='reflect'),
            torch.nn.LeakyReLU(0.2),
            torch.nn.Conv3d(in_channels=64, out_channels=64, kernel_size=(1, 3, 3), stride=(1, 1, 1),
                            padding=(0, 1, 1), padding_mode='reflect'),
            torch.nn.LeakyReLU(0.2),
            torch.nn.Conv3d(in_channels=64, out_channels=64, kernel_size=(1, 3, 3), stride=(1, 1, 1),
                            padding=(0, 1, 1), padding_mode='reflect'),
            torch.nn.LeakyReLU(0.2),
            torch.nn.Conv3d(in_channels=64, out_channels=self.dyn_filter_size**2, kernel_size=(1, 3, 3), stride=(1, 1, 1),
                            padding=(0, 1, 1), padding_mode='reflect'),
        )

        def regnet_init(m):
            if isinstance(m, torch.nn.Conv3d):
                torch.nn.init.xavier_normal_(m.weight)
                torch.nn.init.constant_(m.bias, 0)
        self.regnet.apply(regnet_init)

        self.shift_lin = torch.nn.Linear(self.dyn_filter_size**2, 2, bias=regnet_bias)
        self.shift_lin.weight.data.zero_()
        if regnet_bias:
            self.shift_lin.bias.data.fill_(0.0)

        interp_nn = tg.nn.Sequential(
            'x, edge_index, edge_attr',[
            (EdgeAttentionEmbedding(d, d, heads=attention_heads, edge_dim=2, add_self_loops=False),
             'x, edge_index, edge_attr -> edge_attention'),
            (SplineGat(d, d, dim=2, kernel_size=9, degree=2),
             'x, edge_index, edge_attr, edge_attention -> x'),
            (modules.PReLU(), 'x -> x'),
             ])
        self.inner_upconv = ConvolutionalUpscaling(scale, legacy_mode=False, nn=interp_nn)
        self.scale = scale
        self.encode = Encoder(channel_size=d, in_channels=2*in_channels)

        self.shrinking = tg.nn.Sequential('x, edge_index, edge_attr', [
            (EdgeAttentionEmbedding(d, d, heads=attention_heads, edge_dim=2), 'x, edge_index, edge_attr -> edge_attention'),
            (SplineGat(d, s, dim=2, kernel_size=6, degree=2),
             'x, edge_index, edge_attr, edge_attention -> x'),
            (modules.PReLU(), 'x -> x'),
        ])
        non_linear_mapping = []
        for _ in range(processing_layers):
            non_linear_mapping.append(tg.nn.Sequential('x, edge_index, edge_attr', [
                (tg.nn.SplineConv(s, s, dim=2, kernel_size=6, degree=2), 'x, edge_index, edge_attr -> x'),
                (modules.PReLU(), 'x -> x'),
            ]))
        self.non_linear_mapping = tg.nn.Sequential('x, edge_index, edge_attr', [
            (layer, 'x, edge_index, edge_attr -> x')
            for layer in non_linear_mapping])

        self.expanding = tg.nn.Sequential('x, edge_index, edge_attr', [
            (tg.nn.SplineConv(s, d, dim=2, kernel_size=6, degree=2), 'x, edge_index, edge_attr -> x'),
            (modules.PReLU(), 'x -> x'),
            ])
        kernel_size = 3
        padding = kernel_size // 2
        self.conv1 = torch.nn.Sequential(
            torch.nn.Conv2d(d, out_channels=d, kernel_size=kernel_size, padding=padding),
            torch.nn.PReLU()
        )
        self.convs = ModuleList([torch.nn.Sequential(
            torch.nn.Conv2d(d, d, 3, padding=1),
            torch.nn.PReLU()) for _ in range(4)])
        self.final = torch.nn.Sequential(
            torch.nn.Conv2d(d, out_channels=1, kernel_size=kernel_size, padding=padding),
            torch.nn.PReLU()
        )

    def _forward(self, batch: GraphEntry):
        """Defines the forward pass for the MagNAt_vanilla model.

        The process involves:
        1. Estimating inter-frame shifts using a registration network (RegNet).
        2. Applying these shifts to node positions in the graph.
        3. Encoding image features and processing them through a graph network.
        4. Upscaling the graph features and converting back to an image.
        5. Final convolutional refinement.

        Args:
            batch (GraphEntry): A batch of graph entries, where each graph
                represents a scene with multiple low-resolution views.

        Returns:
            torch.Tensor: The super-resolved output image tensor.
        """
        num_graphs = batch.num_graphs
        batch_id = batch.batch
        leading_lr = any(batch.leading) if "leading" in batch else False
        tensor_x, nonpadded_pixels = graph_to_image2d_uneven(batch) # (B, C_in, N, H, W)

        nonpadded_images = nonpadded_pixels.sum(dim=(-1, -2, -4)).unsqueeze(-1).to(bool) # (B, N, 1)
        flattened_indices = nonpadded_pixels.sum(dim=(-4)).to(bool).contiguous().view(-1) # (B, N*H*W)

        regnet_input = torch.tile(tensor_x[:, :, 0:1, :, :], (1, 1, tensor_x.shape[2], 1, 1)) # (B, C_in, N, H, W)
        regnet_input = torch.stack([regnet_input, tensor_x], dim=2) # (B, C_in, 2, N, H, W)
        regnet_input = regnet_input.swapaxes(2, 3).contiguous() # (B, C_in, N, 2, H, W)
        regnet_input = regnet_input.view(regnet_input.shape[0], regnet_input.shape[1],
                                         regnet_input.shape[2]*regnet_input.shape[3],
                                         regnet_input.shape[4], regnet_input.shape[5]) # (B, C_in, 2*N, H, W)
        regnet_input = regnet_input[:, :, 2:] # (B, C_in, 2*N-2, H, W)
        shifts = 0
        if regnet_input.shape[2] > 0:
            shifts = self.regnet(regnet_input) # (B, K*K, N-1, H, W)
            shifts = shifts.mean(dim=(3, 4)) # (B, K*K, N-1)
            shifts = torch.softmax(shifts, dim=2) # (B, K*K, N-1)
            shifts = torch.movedim(shifts, 2, 1).contiguous().view(-1, self.dyn_filter_size**2) # (B*(N-1), K*K)
            shifts = self.shift_lin(shifts).view(-1, tensor_x.shape[2]-1, 2) # (B, (N-1), 2)
            shifts = torch.cat([torch.zeros_like(shifts[:, 0:1]), shifts], dim=1) # (B, N, 2)
            if not leading_lr:
                shifts = shifts - masked_mean(shifts, nonpadded_images, dim=1, keepdim=True)
            shifts = torch.repeat_interleave(shifts, tensor_x.shape[-2] * tensor_x.shape[-1], 1) # (B, N*H*W, 2)
            shifts = shifts.view(-1, 2) # (B*N*H*W, 2)

            shifts = shifts[flattened_indices]
        pos = batch.pos + shifts
        batch.pos = pos

        batch_size, features, N, height, width = tensor_x.shape
        if leading_lr:
            refs = tensor_x[:, :, 0:1, :, :] # (B, C_in, 1, H, W)
        else:
            refs = masked_median(tensor_x, nonpadded_pixels, dim=2, keepdim=True)  # (B, C_in, 1, H, W)
        refs = refs.repeat(1, 1, tensor_x.shape[2], 1, 1) # (B, C_in, N, H, W)
        stacked_input = torch.cat([tensor_x, refs], 1)  # tensor (B, 2*C_in, N, H, W)
        stacked_input = torch.movedim(stacked_input, 2, 1).contiguous() # (B, N, 2*C_in, H, W)
        stacked_input = stacked_input.view(
            batch_size * N, 2*self.in_channels, height, width)[nonpadded_images.view(-1)] # (B*N, 2*C_in, H, W)

        x = self.encode(stacked_input)  # (B*N, d, H, W)
        x = x.movedim(1, -1).contiguous().view(-1, x.shape[1]) # (B*N, d)

        if self.remove_masked:
            x = x[batch.lr_masks[:, 0]]
            pos = pos[batch.lr_masks[:, 0]]
            batch.pos = pos
            batch_id = batch_id[batch.lr_masks[:, 0]]
            batch.batch = batch_id
        edge_index = radius_graph(pos, r=self.radius, batch=batch_id, loop=True, max_num_neighbors=500)
        edge_attr = cartesian(pos, edge_index, max_value=self.radius)
        batch.edge_index = edge_index
        batch.edge_attr = edge_attr
        
        x = self.shrinking(x, edge_index, edge_attr)
        x_res = x
        x = self.non_linear_mapping(x, edge_index, edge_attr)
        x = x + x_res
        x = self.expanding(x, edge_index, edge_attr)

        data = self.inner_upconv(batch, x, pos_mean=False)
        x = graph_to_image2d(data.lrs, num_graphs,
                                   lr_shape=(batch.nodes_org_shape[0][-2] * self.scale,
                                             batch.nodes_org_shape[0][-1] * self.scale)) # (B, C_out, scale*H, scale*W)

        x = self.conv1(x)
        x_res = x
        for conv in self.convs:
            x = conv(x)
        x = x + x_res
        x = self.final(x)
        return x


@register_class
class MagNAt(Model):
    """The MagNAt model for Multi-Image Super-Resolution using Graph Attention.

    This model registers a set of low-resolution images by treating them as nodes
    in a graph, estimates their alignment, and fuses their features using a graph
    neural network to produce a super-resolved image. This version includes
    edge dropout for regularization.
    """

    def __init__(self, in_channels: int = 1, d=56, s=16,  scale: int = 3, processing_layers: int = 4,
                 attention_heads: int = 1, radius: float = 1.0, filter_size: int = 9,
                 regnet_bias: bool = True, remove_masked=False,
                 edge_dropout: float = 0.3, **kwargs):
        """Initializes the MagNAt model.

        Args:
            in_channels (int, optional): Number of input channels for each image.
            d (int, optional): Base feature dimension size.
            s (int, optional): Shrinking layer feature dimension size.
            scale (int, optional): The target upscaling factor.
            processing_layers (int, optional): Number of non-linear mapping layers.
            attention_heads (int, optional): Number of heads in EdgeAttentionEmbedding.
            radius (float, optional): Radius for graph construction.
            filter_size (int, optional): Kernel size for the dynamic filter generation in RegNet.
            regnet_bias (bool, optional): Whether to use a bias in the final RegNet layer.
            remove_masked (bool, optional): If True, removes masked nodes before processing.
            edge_dropout (float, optional): Dropout probability for graph edges.
            **kwargs (Any): Additional keyword arguments.
        """
        super().__init__()


        self.radius = radius
        self.in_channels = in_channels
        self.remove_masked = remove_masked
        self.dyn_filter_size = filter_size
        self.regnet = torch.nn.Sequential(
            torch.nn.Conv3d(in_channels=in_channels, out_channels=128, kernel_size=(2, 3, 3), stride=(2, 1, 1),
                            padding=(0, 1, 1), padding_mode='reflect'),
            torch.nn.LeakyReLU(0.2),
            torch.nn.Conv3d(in_channels=128, out_channels=64, kernel_size=(1, 3, 3), stride=(1, 1, 1),
                            padding=(0, 1, 1), padding_mode='reflect'),
            torch.nn.LeakyReLU(0.2),
            torch.nn.Conv3d(in_channels=64, out_channels=64, kernel_size=(1, 3, 3), stride=(1, 1, 1),
                            padding=(0, 1, 1), padding_mode='reflect'),
            torch.nn.LeakyReLU(0.2),
            torch.nn.Conv3d(in_channels=64, out_channels=64, kernel_size=(1, 3, 3), stride=(1, 1, 1),
                            padding=(0, 1, 1), padding_mode='reflect'),
            torch.nn.LeakyReLU(0.2),
            torch.nn.Conv3d(in_channels=64, out_channels=self.dyn_filter_size**2, kernel_size=(1, 3, 3), stride=(1, 1, 1),
                            padding=(0, 1, 1), padding_mode='reflect'),
        )

        def regnet_init(m):
            if isinstance(m, torch.nn.Conv3d):
                torch.nn.init.xavier_normal_(m.weight)
                torch.nn.init.constant_(m.bias, 0)
        self.regnet.apply(regnet_init)

        self.shift_lin = torch.nn.Linear(self.dyn_filter_size**2, 2, bias=regnet_bias)
        self.shift_lin.weight.data.zero_()
        if regnet_bias:
            self.shift_lin.bias.data.fill_(0.0)

        self.edge_dropout = EdgeDropout(dropout_prob=edge_dropout)
        interp_nn = tg.nn.Sequential('x, edge_index, edge_attr',[
            (EdgeDropout(dropout_prob=edge_dropout), 'edge_index, edge_attr -> edge_index, edge_attr'),
            (EdgeAttentionEmbedding(d, d, heads=attention_heads, edge_dim=2, add_self_loops=False),
             'x, edge_index, edge_attr -> edge_attention'),
            (SplineGat(d, d, dim=2, kernel_size=9, degree=2),
             'x, edge_index, edge_attr, edge_attention -> x'),
            (modules.PReLU(), 'x -> x'),
             ])
        self.inner_upconv = ConvolutionalUpscaling(scale, legacy_mode=False, nn=interp_nn)
        self.scale = scale
        self.encode = Encoder(channel_size=d, in_channels=2*in_channels)
        
        self.shrinking = tg.nn.Sequential('x, edge_index, edge_attr', [
            (EdgeAttentionEmbedding(d, d, heads=attention_heads, edge_dim=2), 'x, edge_index, edge_attr -> edge_attention'),
            (SplineGat(d, s, dim=2, kernel_size=6, degree=2),
             'x, edge_index, edge_attr, edge_attention -> x'),
            (modules.PReLU(), 'x -> x'),
        ])
        non_linear_mapping = []
        for _ in range(processing_layers):
            non_linear_mapping.append(tg.nn.Sequential('x, edge_index, edge_attr', [
                (tg.nn.SplineConv(s, s, dim=2, kernel_size=6, degree=2), 'x, edge_index, edge_attr -> x'),
                (modules.PReLU(), 'x -> x'),
            ]))
        self.non_linear_mapping = tg.nn.Sequential('x, edge_index, edge_attr', [
            (layer, 'x, edge_index, edge_attr -> x')
            for layer in non_linear_mapping])

        self.expanding = tg.nn.Sequential('x, edge_index, edge_attr', [
            (tg.nn.SplineConv(s, d, dim=2, kernel_size=6, degree=2), 'x, edge_index, edge_attr -> x'),
            (modules.PReLU(), 'x -> x'),
            ])
        kernel_size = 3
        padding = kernel_size // 2
        self.conv1 = torch.nn.Sequential(
            torch.nn.Conv2d(d, out_channels=d, kernel_size=kernel_size, padding=padding),
            torch.nn.PReLU()
        )
        self.convs = ModuleList([torch.nn.Sequential(
            torch.nn.Conv2d(d, d, 3, padding=1),
            torch.nn.PReLU()) for _ in range(4)])
        self.final = torch.nn.Sequential(
            torch.nn.Conv2d(d, out_channels=1, kernel_size=kernel_size, padding=padding),
            torch.nn.PReLU()
        )

    def _forward(self, batch: GraphEntry):
        """Defines the forward pass for the MagNAt model.

        The process involves:
        1. Estimating inter-frame shifts using a registration network (RegNet).
        2. Applying these shifts to node positions in the graph.
        3. Applying edge dropout for regularization.
        4. Encoding image features and processing them through a graph network.
        5. Upscaling the graph features and converting back to an image.
        6. Final convolutional refinement.

        Args:
            batch (GraphEntry): A batch of graph entries, where each graph
                represents a scene with multiple low-resolution views.

        Returns:
            torch.Tensor: The super-resolved output image tensor.
        """
        num_graphs = batch.num_graphs
        batch_id = batch.batch
        leading_lr = any(batch.leading) if "leading" in batch else False
        tensor_x, nonpadded_pixels = graph_to_image2d_uneven(batch) # (B, C_in, N, H, W)

        nonpadded_images = nonpadded_pixels.sum(dim=(-1, -2, -4)).unsqueeze(-1).to(bool) # (B, N, 1)
        flattened_indices = nonpadded_pixels.sum(dim=(-4)).to(bool).contiguous().view(-1) # (B, N*H*W)

        regnet_input = torch.tile(tensor_x[:, :, 0:1, :, :], (1, 1, tensor_x.shape[2], 1, 1)) # (B, C_in, N, H, W)
        regnet_input = torch.stack([regnet_input, tensor_x], dim=2) # (B, C_in, 2, N, H, W)
        regnet_input = regnet_input.swapaxes(2, 3).contiguous() # (B, C_in, N, 2, H, W)
        regnet_input = regnet_input.view(regnet_input.shape[0], regnet_input.shape[1],
                                         regnet_input.shape[2]*regnet_input.shape[3],
                                         regnet_input.shape[4], regnet_input.shape[5]) # (B, C_in, 2*N, H, W)
        regnet_input = regnet_input[:, :, 2:] # (B, C_in, 2*N-2, H, W)
        shifts = 0
        if regnet_input.shape[2] > 0:
            shifts = self.regnet(regnet_input) # (B, K*K, N-1, H, W)
            shifts = shifts.mean(dim=(3, 4)) # (B, K*K, N-1)
            shifts = torch.softmax(shifts, dim=1) # (B, K*K, N-1)
            shifts = torch.movedim(shifts, 2, 1).contiguous().view(-1, self.dyn_filter_size**2) # (B*(N-1), K*K)
            shifts = self.shift_lin(shifts).view(-1, tensor_x.shape[2]-1, 2) # (B, (N-1), 2)
            shifts = torch.cat([torch.zeros_like(shifts[:, 0:1]), shifts], dim=1) # (B, N, 2)
            if not leading_lr:
                shifts = shifts - masked_mean(shifts, nonpadded_images, dim=1, keepdim=True)
            shifts = torch.repeat_interleave(shifts, tensor_x.shape[-2] * tensor_x.shape[-1], 1) # (B, N*H*W, 2)
            shifts = shifts.view(-1, 2) # (B*N*H*W, 2)

            shifts = shifts[flattened_indices]
        pos = batch.pos + shifts
        batch.pos = pos

        batch_size, features, N, height, width = tensor_x.shape
        if leading_lr:
            refs = tensor_x[:, :, 0:1, :, :] # (B, C_in, 1, H, W)
        else:
            refs = masked_median(tensor_x, nonpadded_pixels, dim=2, keepdim=True)  # (B, C_in, 1, H, W)
        refs = refs.repeat(1, 1, tensor_x.shape[2], 1, 1) # (B, C_in, N, H, W)
        stacked_input = torch.cat([tensor_x, refs], 1)  # tensor (B, 2*C_in, N, H, W)
        stacked_input = torch.movedim(stacked_input, 2, 1).contiguous() # (B, N, 2*C_in, H, W)
        stacked_input = stacked_input.view(
            batch_size * N, 2*self.in_channels, height, width)[nonpadded_images.view(-1)] # (B*N, 2*C_in, H, W)

        x = self.encode(stacked_input)  # (B*N, d, H, W)
        x = x.movedim(1, -1).contiguous().view(-1, x.shape[1]) # (B*N, d)

        if self.remove_masked:
            x = x[batch.lr_masks[:, 0]]
            pos = pos[batch.lr_masks[:, 0]]
            batch.pos = pos
            batch_id = batch_id[batch.lr_masks[:, 0]]
            batch.batch = batch_id
        edge_index = radius_graph(pos, r=self.radius, batch=batch_id, loop=True, max_num_neighbors=500)
        edge_attr = cartesian(pos, edge_index, max_value=self.radius)
        edge_index, edge_attr = self.edge_dropout(edge_index, edge_attr)
        batch.edge_index = edge_index
        batch.edge_attr = edge_attr
        
        x = self.shrinking(x, edge_index, edge_attr)
        x_res = x
        x = self.non_linear_mapping(x, edge_index, edge_attr)
        x = x + x_res
        x = self.expanding(x, edge_index, edge_attr)

        data = self.inner_upconv(batch, x, pos_mean=False)
        x = graph_to_image2d(data.lrs, num_graphs,
                                   lr_shape=(batch.nodes_org_shape[0][-2] * self.scale, batch.nodes_org_shape[0][-1] * self.scale))

        x = self.conv1(x)
        x_res = x
        for conv in self.convs:
            x = conv(x)
        x = x + x_res
        x = self.final(x)
        return x
