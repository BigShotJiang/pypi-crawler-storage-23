import torch
from torch import nn
from torch.nn import functional as F

from srforge.models import Model
from srforge.registry import register_class


class RFAB(nn.Module):
    """Residual Feature Attention Block (RFAB)."""
    def __init__(self, filters, kernel_size, r):
        """Initializes the RFAB module.

        Args:
            filters (int): Number of input and output channels.
            kernel_size (int): Size of the convolutional kernel.
            r (int): The reduction ratio for the feature attention mechanism.
        """
        super().__init__()
        self.pre_attention = nn.Sequential(
            nn.utils.parametrizations.weight_norm(nn.Conv3d(in_channels=filters, out_channels=filters,
                                           kernel_size=kernel_size, padding=kernel_size // 2)),
            nn.ReLU(),
            nn.utils.parametrizations.weight_norm(nn.Conv3d(in_channels=filters, out_channels=filters,
                                           kernel_size=kernel_size, padding=kernel_size // 2))
        )

        self.feature_attention = nn.Sequential(
            nn.AdaptiveAvgPool3d(1),
            nn.utils.parametrizations.weight_norm(nn.Conv3d(in_channels=filters, out_channels=filters // r,
                                           kernel_size=kernel_size, padding=kernel_size // 2)),
            nn.ReLU(),
            nn.utils.parametrizations.weight_norm(nn.Conv3d(in_channels=filters // r, out_channels=filters,
                                           kernel_size=kernel_size, padding=kernel_size // 2)),
        )

    def forward(self, x):
        """Defines the forward pass for the RFAB.

        Args:
            x (torch.Tensor): The input tensor.

        Returns:
            torch.Tensor: The output tensor.
        """
        x_rfab_res = x
        x = self.pre_attention(x)
        x_fa_res = x
        x = self.feature_attention(x)
        x = x * x_fa_res
        return x + x_rfab_res


class TemporalReductionBlock(nn.Module):
    """A block for temporal reduction, combining an RFAB with a 3D convolution."""
    def __init__(self, filters, kernel_size, r):
        """Initializes the TemporalReductionBlock.

        Args:
            filters (int): Number of input and output channels.
            kernel_size (int): Size of the convolutional kernel.
            r (int): The reduction ratio for the feature attention mechanism.
        """
        super().__init__()
        self.rfab = RFAB(filters, kernel_size, r)
        self.conv = nn.Sequential(
            nn.utils.parametrizations.weight_norm(nn.Conv3d(in_channels=filters, out_channels=filters,
                                           kernel_size=kernel_size)),
            nn.ReLU()
        )

    def forward(self, x):
        """Defines the forward pass for the TRB.

        Args:
            x (torch.Tensor): The input tensor.

        Returns:
            torch.Tensor: The output tensor with reduced temporal dimension.
        """
        x = F.pad(x, [1, 1, 1, 1, 0, 0], mode='replicate')
        x = self.rfab(x)
        x = self.conv(x)
        return x


class RTAB(nn.Module):
    """Residual Temporal Attention Block (RTAB) for 2D feature maps."""
    def __init__(self, filters, kernel_size, r):
        """Initializes the RTAB module.

        Args:
            filters (int): Number of input and output channels.
            kernel_size (int): Size of the convolutional kernel.
            r (int): The reduction ratio for the temporal attention mechanism.
        """
        super().__init__()
        self.attention = nn.Sequential(
            nn.utils.parametrizations.weight_norm(nn.Conv2d(in_channels=filters, out_channels=filters,
                                           kernel_size=kernel_size, padding=kernel_size // 2)),
            nn.ReLU(),
            nn.utils.parametrizations.weight_norm(nn.Conv2d(in_channels=filters, out_channels=filters,
                                           kernel_size=kernel_size, padding=kernel_size // 2))
        )
        self.temporal = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.utils.parametrizations.weight_norm(nn.Conv2d(in_channels=filters, out_channels=filters // r,
                                           kernel_size=kernel_size, padding=kernel_size // 2)),
            nn.ReLU(),
            nn.utils.parametrizations.weight_norm(nn.Conv2d(in_channels=filters // r, out_channels=filters,
                                           kernel_size=kernel_size, padding=kernel_size // 2)),
        )

    def forward(self, x):
        """Defines the forward pass for the RTAB.

        Args:
            x (torch.Tensor): The input tensor.

        Returns:
            torch.Tensor: The output tensor.
        """
        x_res = x
        x = self.attention(x)
        x_temp_res = x
        x = self.temporal(x)
        x = x_temp_res * x
        x = x + x_res
        return x

@register_class
class RAMS(Model):
    """Implementation of the RAMS model for Multi-Image Super-Resolution.

    This model uses a series of residual feature attention blocks (RFAB) and
    temporal reduction blocks (TRB) to fuse information from a sequence of
    low-resolution images.

    Reference:
        Wang, W., Chen, J., & Wang, L. (2020). Residual-attentional-modules-based
        network for multi-image super-resolution. Signal, Image and Video
        Processing.
    """
    def __init__(self, scale: int = 3, filters: int = 32,
                 kernel_size: int = 3, in_channels: int = 1, n_views: int = 9, r: int = 8,
                 N: int = 12, mean: float = 0.0, std: float = 1.0):
        """Initializes the RAMS model.

        Args:
            scale (int, optional): The target upscaling factor. Defaults to 3.
            filters (int, optional): The number of base filters in the model.
                Defaults to 32.
            kernel_size (int, optional): The default convolutional kernel size.
                Defaults to 3.
            in_channels (int, optional): The number of input channels. Defaults to 1.
            n_views (int, optional): The number of input low-resolution views.
                Defaults to 9.
            r (int, optional): The reduction ratio for attention mechanisms.
                Defaults to 8.
            N (int, optional): The number of RFAB blocks. Defaults to 12.
            mean (float, optional): Mean value for input normalization. Defaults to 0.0.
            std (float, optional): Standard deviation for input normalization.
                Defaults to 1.0.
        """
        super().__init__()
        self.mean = mean
        self.std = std
        self.scale = scale
        self.n_views = n_views
        self.in_channels = in_channels
        self.conv1 = nn.utils.parametrizations.weight_norm(nn.Conv3d(in_channels=in_channels, out_channels=filters,
                                                    kernel_size=kernel_size, padding=1))
        self.rfabs = [RFAB(filters, kernel_size, r) for i in range(N)]
        self.rfabs = nn.Sequential(*self.rfabs)
        self.conv2 = nn.utils.parametrizations.weight_norm(nn.Conv3d(in_channels=filters, out_channels=filters,
                                                    kernel_size=kernel_size, padding=1))
        self.trbs = [TemporalReductionBlock(filters, kernel_size, r) for _ in range(n_views // 3)]
        self.trbs = nn.Sequential(*self.trbs)
        self.conv3 = nn.utils.parametrizations.weight_norm(nn.Conv3d(in_channels=filters, out_channels=scale ** 2,
                                                    kernel_size=kernel_size, padding=0))
        self.rtab = RTAB(n_views, kernel_size, r)
        self.global_conv = nn.Conv2d(n_views, scale ** 2, kernel_size=kernel_size)

    def _forward(self, lrs: torch.Tensor):
        """Defines the forward pass for the RAMS model.

        Args:
            lrs (torch.Tensor): A tensor of low-resolution input images with shape
                (B, C, N, H, W) where N is the number of views.

        Returns:
            torch.Tensor: The super-resolved output image tensor.
        """
        x = lrs
        if not (x.shape[1] == 1):
            raise ValueError(f'Expected 1 channel, got {x.shape[1]}')
        x = x.squeeze(1)
        x = (x - self.mean) / self.std
        x_global_res = x


        x = torch.unsqueeze(x, 1)
        x = F.pad(x, [1, 1, 1, 1, 0, 0], mode='replicate')

        # Low level features extraction
        x = self.conv1(x)

        # LSC
        x_res = x
        x = self.rfabs(x)
        x = self.conv2(x)
        x = x + x_res

        # Temporal Reduction, out: CxHxW
        x = self.trbs(x)

        # Upscaling
        x = self.conv3(x)
        x = x[..., 0, :, :]
        x = F.pixel_shuffle(x, self.scale)

        # Global path
        x_global_res = F.pad(x_global_res, [1, 1, 1, 1], mode='reflect')
        x_global_res = self.rtab(x_global_res)
        x_global_res = self.global_conv(x_global_res)
        x_global_res = F.pixel_shuffle(x_global_res, self.scale)
        x = x + x_global_res
        x = x * self.std + self.mean
        return x
