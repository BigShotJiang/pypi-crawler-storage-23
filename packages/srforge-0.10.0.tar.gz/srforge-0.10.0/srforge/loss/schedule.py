import logging
from bisect import bisect_right
from typing import Mapping
from srforge.loss import Loss
from srforge.loss.storage import MetricScores
from srforge.registry import register_class


logger = logging.getLogger(__name__)

@register_class
class LossScheduler:
    """Epoch-aware loss wrapper that swaps the active Loss at configured milestones.

    Args:
        schedule: Mapping of ``{epoch_milestone: Loss}``. Must contain key ``0``.
        start_epoch: Current/resume epoch (defaults to 0).
    """
    def __init__(self, schedule: Mapping[int, Loss], start_epoch: int = 0):
        if 0 not in schedule:
            raise ValueError("Loss schedule must contain key 0 to set an initial loss.")
        self.loss_schedule = dict(schedule)
        self.milestones = sorted(self.loss_schedule.keys())
        self.current_loss: Loss = self._loss_for_epoch(start_epoch)

    def __call__(self, *args, **kwargs) -> MetricScores:
        """Delegate to the currently active loss function."""
        return self.current_loss(*args, **kwargs)

    def update(self, epoch: int) -> 'LossScheduler':
        """Advance the scheduler to *epoch*, updating the active loss."""
        self.current_loss = self._loss_for_epoch(epoch)
        return self

    def get_loss_fn(self) -> Loss:
        """Return the currently active Loss instance."""
        return self.current_loss

    def _loss_for_epoch(self, epoch: int) -> Loss:
        """Return the Loss function active at the given epoch."""
        i = bisect_right(self.milestones, epoch) - 1
        key = self.milestones[max(i, 0)]
        return self.loss_schedule[key]
