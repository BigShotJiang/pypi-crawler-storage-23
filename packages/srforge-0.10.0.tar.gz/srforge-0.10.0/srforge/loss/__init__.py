import torch
from torch import nn
from typing import Mapping, Union, List, Any, get_origin, get_args, Dict, Optional, overload
from itertools import product
from abc import ABC, abstractmethod
from inspect import signature

from srforge.data import Entry, GraphEntry
from srforge.registry import register_class
from srforge.utils import obj_to_str
from srforge.utils.iomodule import IOModule
from srforge.loss.storage import MetricScores

def _is_dict_annotation(ann) -> bool:
    origin = get_origin(ann)
    if origin is dict or origin is Dict:
        return True
    # handle Union[...] / | where one of the args is a dict
    if origin is Union:
        return any((get_origin(a) is dict or get_origin(a) is Dict) for a in get_args(ann))
    return False

class Loss(nn.Module, IOModule, ABC):
    _install_io_ports = False
    def __init__(self, weight=1.0, name: str = None, **kwargs):
        super().__init__()
        self._name = name or self.__class__.__name__
        self._weight = weight
        self.sig = signature(self.calculate_score)
        self.__check_annotated_signatures()
        # Identity default: param_name → param_name
        self._input_map = {name: name for name in self.sig.parameters}

    def set_io(self, io_cfg, *, strict=True, require_all=True):
        """Set IO binding using the unified format: ``{"inputs": {param: field}}``.

        Losses only read from Entry (no outputs). If ``outputs`` is provided,
        a :class:`TypeError` is raised.
        """
        from srforge.utils.io_parsing import parse_io_config
        inputs_raw, outputs_raw = parse_io_config(io_cfg)
        if outputs_raw is not None:
            raise TypeError(
                "Loss components don't produce outputs. Remove 'outputs' from io config."
            )
        if not isinstance(inputs_raw, Mapping):
            raise TypeError(
                "Loss 'inputs' must be a dict (not list). "
                "Losses don't support multiple applications."
            )
        input_map = dict(inputs_raw)
        for key in input_map:
            if key not in self.sig.parameters:
                raise ValueError(
                    f"Parameter '{key}' not found in calculate_score signature "
                    f"of {self.__class__.__name__}."
                )
        self._input_map.update(input_map)
        return self

    @property
    def weight(self) -> float:
        return self._weight

    @weight.setter
    def weight(self, new_weight: float):
        self._weight = new_weight

    @property
    @abstractmethod
    def best_min(self) -> bool:
        raise NotImplementedError

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, new_name: str):
        if new_name is None:
            new_name = self.__class__.__name__
        self._name = new_name

    @overload
    def __call__ (self, entry: Entry | GraphEntry) -> MetricScores: ...

    @overload
    def __call__ (self, *args: Any) -> MetricScores: ...

    @overload
    def __call__ (self, **kwargs: Any) -> MetricScores: ...

    def __call__(self, *args, **kwargs) -> MetricScores:
        if "entry" in kwargs:
            if args:
                raise TypeError(
                    f"{self.__class__.__name__} expects either positional args, keyword args, or a single Entry, not a mix."
                )
            if len(kwargs) != 1:
                raise TypeError(
                    f"{self.__class__.__name__} expects only 'entry' when provided as a keyword."
                )
            entry = kwargs["entry"]
            if not isinstance(entry, (Entry, GraphEntry)):
                raise TypeError(
                    f"{self.__class__.__name__} expects 'entry' to be Entry or GraphEntry, got {type(entry)}."
                )
            return super().__call__(entry)
        if args and kwargs:
            raise TypeError(
                f"{self.__class__.__name__} expects either positional args, keyword args, or a single Entry, not a mix."
            )
        if len(args) == 1 and isinstance(args[0], (Entry, GraphEntry)):
            return super().__call__(args[0])
        if args:
            if len(args) != len(self.sig.parameters):
                raise TypeError(
                    f"{self.__class__.__name__} expects {len(self.sig.parameters)} positional arguments "
                    f"({list(self.sig.parameters.keys())}), got {len(args)}."
                )
            loss_kwargs = dict(zip(self.sig.parameters.keys(), args))
            return self._compute_scores(loss_kwargs)
        if kwargs:
            loss_kwargs = self.__get_loss_kwargs(kwargs)
            return self._compute_scores(loss_kwargs)
        raise TypeError(f"{self.__class__.__name__} expects arguments but none were provided.")

    def __get_loss_kwargs(self, entry: Entry | Dict[str, Any]) -> Dict[str, Any]:
        loss_kwargs = {}
        for name, param in self.sig.parameters.items():
            mapped = self._input_map[name]
            if param.default == param.empty:
                if mapped not in entry:
                    raise KeyError(
                        f"Error when calculating loss '{self.name}': "
                        f"Parameter '{mapped}' not found!"
                    )
            loss_kwargs[name] = (
                entry[mapped] if mapped in entry else None
            )
        return loss_kwargs

    def forward(self, entry: Entry) -> MetricScores:
        loss_kwargs = self.__get_loss_kwargs(entry)
        return self._compute_scores(loss_kwargs)

    def _compute_scores(self, loss_kwargs: Dict[str, Any]) -> MetricScores:
        # inspect annotations:
        annotated_as_dict = {
            name
            for name, param in self.sig.parameters.items()
            if _is_dict_annotation(param.annotation)
        }

        # check for runtime dict values:
        actual_dict_params = {
            name for name, val in loss_kwargs.items() if isinstance(val, dict)
        }

        # if any annotation/dict‐value mismatches → error:
        for name in annotated_as_dict:
            if name not in actual_dict_params:
                raise TypeError(
                    f"Loss '{self.name}' expects parameter '{name}' to be a dict, "
                    f"but got {type(loss_kwargs[name]).__name__}"
                )

        # if any params annotated as dict → single-call path
        if annotated_as_dict:
            for name in actual_dict_params:
                if annotated_as_dict and name not in annotated_as_dict:
                    # we only allow dict‐values *if* their param is annotated as dict
                    raise TypeError(
                        f"Loss '{self.name}' got dict for '{name}', but its annotation "
                        f"is {self.sig.parameters[name].annotation}"
                )
            raw_score = self.calculate_score(**loss_kwargs)
            return MetricScores.single(
                name=self.name,
                raw=raw_score,
                best_min=self.best_min,
                weight=self.weight
            )

        # otherwise, fallback to per‐key splitting if runtime values are dicts
        if actual_dict_params:
            # collect keysets of all dict-valued inputs
            keysets = [set(loss_kwargs[n].keys()) for n in actual_dict_params]

            # use only keys present in *all* dict inputs
            common_keys = set.intersection(*keysets) if keysets else set()

            if not common_keys:
                raise ValueError(
                    f"Dict-valued loss inputs share no common keys; got {keysets}"
                )

            raw_per_band = {}
            for band in sorted(common_keys):
                sub_kwargs = {
                    name: (val[band] if name in actual_dict_params else val)
                    for name, val in loss_kwargs.items()
                }
                Lb = self.calculate_score(**sub_kwargs)
                raw_per_band[band] = Lb

            return MetricScores.single(
                name=self.name,
                raw=raw_per_band,
                best_min=self.best_min,
                weight=self.weight,
            )
        # pure-scalar path
        raw_score = self.calculate_score(**loss_kwargs)
        return MetricScores.single(
            name=self.name,
            raw=raw_score,
            best_min=self.best_min,
            weight=self.weight,
        )

    @abstractmethod
    def calculate_score(self, *args, **kwargs):
        """
        Calculate the loss score based on the provided entry data parameters.
        To make this work properly an annotation of each parameter data type is required.
        """
        raise NotImplementedError

    def __check_annotated_signatures(self):
        """
        Ensures that the calculate_score method has annotated signatures for all parameters.
        """
        for name, param in self.sig.parameters.items():
            if param.annotation == param.empty:
                raise ValueError(f"Parameter '{name}' in calculate_score method for loss '{self._name}' must have an annotated type!")

    @staticmethod
    def mask_pixels(sr: torch.Tensor, hr: torch.Tensor, hr_mask=None):
        if hr_mask is None:
            hr_mask = torch.ones_like(hr)
        dims = tuple(range(1, sr.dim()))
        total_unmasked = torch.sum(hr_mask, dim=dims)
        return sr*hr_mask, hr*hr_mask, total_unmasked

    def __str__(self):
        return obj_to_str(self)


@register_class
class LossCombiner(Loss):
    def __init__(self, losses: Union[Loss, List[Loss]], **kwargs):
        super().__init__(**kwargs)
        if isinstance(losses, Loss):
            losses = [losses]
        if not (len(set([loss.name for loss in losses])) == len(losses)):
            raise ValueError("Losses must have unique names!")
        self.losses: List[Loss] = losses

    @property
    def best_min(self):
        return True

    @property
    def weight(self):
        return 1.0

    @property
    def name(self) -> str:
        return f"LossCombiner({[loss.name for loss in self.losses]})"

    def __iter__(self):
        return iter(self.losses)

    def forward(self, entry: Entry):
        combined = MetricScores.empty()
        for loss in self:
            scores = loss(entry)
            combined = combined.merge(scores)
        return combined

    def calculate_score(self, entry: Entry):
        raise RuntimeError("LossCombiner.calculate_score is not used directly.")

    def _rename_losses(self):
        raise NotImplementedError(f"Not implemented for base class {self.__class__.__name__}.")


@register_class
class cLossCombiner(LossCombiner):
    """
    Corrected-loss combiner:
    - For each underlying loss, evaluates it on a grid of shifted HR patches.
    - For each pixel, picks min or max over shifts (depending on best_min).
    - Returns MetricScores with one MetricEntry per underlying loss,
      preserving each loss's weight and best_min.
    """

    def __init__(
        self,
        losses: Union[Loss, List[Loss]],
        border: int = 3,
        do_correction: bool = True,
        **kwargs
    ):
        super().__init__(losses, **kwargs)
        self.border = border
        self.do_correction = do_correction
        # choose min for "minimize" losses, max for "maximize" metrics (e.g. PSNR)
        self.loss_choice_functions = {
            loss: (torch.min if loss.best_min else torch.max)
            for loss in self.losses
        }
        # Loss.__init__ already set self.sig = signature(self.calculate_score)
        # and checked annotations
        self._rename_losses()

    # ---- naming tweaks -------------------------------------------------

    def _rename_losses(self):
        # prefix underlying loss names with 'c'
        for loss in self.losses:
            loss.name = f"c{loss.name}"

    @property
    def name(self) -> str:
        return f"cLossCombiner({[loss.name for loss in self.losses]})"

    # ---- main forward --------------------------------------------------

    def forward(self, entry: Entry) -> MetricScores:
        """
        Build kwargs for our own calculate_score (sr, hr, hr_mask),
        handle multi-band dict inputs, and wrap results into MetricScores.
        """
        # Build loss_kwargs using the same logic as Loss.forward
        loss_kwargs: Dict[str, Any] = {}
        for param_name, param in self.sig.parameters.items():
            mapped = self._input_map[param_name]
            if param.default == param.empty:
                if mapped not in entry:
                    raise KeyError(
                        f"Error when calculating loss '{self.name}': "
                        f"Parameter '{mapped}' not found!"
                    )
            loss_kwargs[param_name] = (
                entry[mapped] if mapped in entry else None
            )

        # Detect dict-valued arguments (multi-band case)
        dict_params = {
            name: val
            for name, val in loss_kwargs.items()
            if isinstance(val, dict)
        }

        # ---- multi-band: per-band evaluation, then pack dict[band]->Tensor ----
        if dict_params:
            keysets = [set(d.keys()) for d in dict_params.values()]
            bands = set.intersection(*keysets)
            # per-loss, per-band raw results
            per_loss_per_band: Dict[str, Dict[str, torch.Tensor]] = {
                loss.name: {} for loss in self.losses
            }

            for band in bands:
                sub_kwargs = {
                    name: (val[band] if isinstance(val, dict) else val)
                    for name, val in loss_kwargs.items()
                }
                band_results = self.calculate_score(**sub_kwargs)  # dict[loss_name]->Tensor
                for loss_name, loss_val in band_results.items():
                    per_loss_per_band[loss_name][band] = loss_val

            metrics = MetricScores.empty()
            for loss in self.losses:
                scores = MetricScores.single(
                    name=loss.name,
                    raw=per_loss_per_band[loss.name],
                    best_min=loss.best_min,
                    weight=loss.weight,
                )
                metrics = metrics.merge(scores)
            return metrics

        # ---- single (non-dict) path ------------------------------------
        raw_results = self.calculate_score(**loss_kwargs)  # dict[loss_name]->Tensor
        metrics = MetricScores.empty()
        for loss in self.losses:
            score = MetricScores.single(
                name=loss.name,
                raw=raw_results[loss.name],
                best_min=loss.best_min,
                weight=loss.weight,
            )
            metrics = metrics.merge(score)
        return metrics

    # ---- corrected, raw-only score computation ------------------------

    def calculate_score(
        self,
        x: torch.Tensor,
        y: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        """
        Compute raw per-loss scores after spatial correction.

        IMPORTANT:
        - Returns *raw* scores (no sign flip, no weighting).
        - Weight and best_min are handled by MetricEntry / MetricScores.
        """
        sr = x
        hr = y
        hr_mask = mask
        if hr_mask is None:
            hr_mask = torch.ones_like(hr)

        height, width = hr.shape[-2:]
        max_pixel_shifts = 2 * self.border
        cropped_height = height - max_pixel_shifts
        cropped_width = width - max_pixel_shifts

        # central SR patch
        sr_patch = sr[:, :, self.border:height - self.border,
                         self.border:width - self.border]

        # apply mask to HR
        hr = hr * hr_mask

        hr_patches = []
        mask_patches = []
        for i, j in product(range(max_pixel_shifts + 1), range(max_pixel_shifts + 1)):
            hr_patches.append(
                hr[:, :, i:i + cropped_height, j:j + cropped_width]
            )
            mask_patches.append(
                hr_mask[:, :, i:i + cropped_height, j:j + cropped_width]
            )

        hr_patches = torch.stack(hr_patches, dim=1)     # [B, P, C, Hc, Wc]
        mask_patches = torch.stack(mask_patches, dim=1) # [B, P, C, Hc, Wc]
        sr_patch = torch.repeat_interleave(
            sr_patch.unsqueeze(1),
            hr_patches.shape[1],
            dim=1
        )  # [B, P, C, Hc, Wc]

        if self.do_correction:
            # correction term b for each patch
            total_unmasked = torch.sum(mask_patches, dim=[-3, -2, -1], keepdim=True)
            # avoid div-by-zero if needed (up to you)
            b = torch.pow(total_unmasked, -1) * torch.sum(
                hr_patches - sr_patch,
                dim=[-3, -2, -1],
            ).view(total_unmasked.shape)
            sr_patch = sr_patch + b

        # apply mask
        sr_patch = sr_patch * mask_patches

        # flatten patches for loss evaluation
        patches_shape = sr_patch.shape  # [B, P, C, Hc, Wc]
        sr_patch_flat = sr_patch.view(-1, *patches_shape[-3:])   # [B*P, C, Hc, Wc]
        hr_patches_flat = hr_patches.view(-1, *patches_shape[-3:])

        results: Dict[str, torch.Tensor] = {}

        for loss, choice_function in self.loss_choice_functions.items():
            # call underlying loss in "raw" space
            # NOTE: calculate_score is raw, no weight or sign flip
            loss_values = loss.calculate_score(
                x=sr_patch_flat,
                y=hr_patches_flat,
                y_mask=None,
            )  # expected shape [B*P, ...]
            loss_values = loss_values.view(*patches_shape[:-3])  # [B, P, ...]

            # pick best over shifts: min if best_min, max otherwise
            best_vals, _ = choice_function(loss_values, dim=1)   # [B, ...]
            results[loss.name] = best_vals

        return results


# Import submodules so their @register_class decorators run, making
# short names (L1, SSIM, LossScheduler, …) available to ConfigParser.
from srforge.loss import metrics as _metrics  # noqa: F401
from srforge.loss import schedule as _schedule  # noqa: F401

