from typing import Optional, Dict, Union, Literal

from srforge.loss import Loss
from srforge.registry import register_class
import lpips

import torch
from torch import nn
import torch.nn.functional as F
from torchmetrics import SpectralAngleMapper

from skimage import measure

DictOrTensor = Union[Dict[str, torch.Tensor], torch.Tensor]

@register_class
class MSE(Loss):
    @property
    def best_min(self) -> bool:
        return True

    def __init__(self, eps: float = 1e-12, **kwargs):
        super().__init__(**kwargs)
        self.eps = eps

    def calculate_score(self, x: torch.Tensor, y: torch.Tensor, y_mask: torch.Tensor = None):
        x, y, total_unmasked = self.mask_pixels(x, y, y_mask)
        dims = tuple(range(1, x.dim()))

        sq = torch.square(y - x)
        num = torch.sum(sq, dim=dims)

        # zabezpieczenie przed /0
        invalid = total_unmasked <= 0
        denom = torch.clamp_min(total_unmasked, 1)

        mse = num / denom
        mse = torch.where(invalid, torch.full_like(mse, float("nan")), mse)
        return mse


@register_class
class PSNR(MSE):
    @property
    def best_min(self) -> bool:
        return False

    def __init__(self, data_range: float = 1.0, eps: float = 1e-12, **kwargs):
        super().__init__(eps=eps, **kwargs)
        self.data_range = data_range

    def calculate_score(self, x: torch.Tensor, y: torch.Tensor, y_mask: torch.Tensor = None):
        mse = super().calculate_score(x, y, y_mask)
        mse = torch.clamp_min(mse, self.eps)  # MSE==0 -> bardzo duży PSNR, ale nie inf

        # PSNR = 10 log10( (MAX^2) / MSE )
        psnr = 10.0 * torch.log10((self.data_range ** 2) / mse)
        return psnr

def _charbonnier(x: torch.Tensor, eps: float = 1e-3) -> torch.Tensor:
    return torch.sqrt(x * x + eps * eps)

@register_class
class Charbonnier(Loss):
    """Masked Charbonnier loss (smooth L1). Lower is better."""
    @property
    def best_min(self) -> bool:
        return True


    def __init__(self, epsilon: float = 1e-3, **kwargs):
        super().__init__(**kwargs)
        self.epsilon = float(epsilon)


    def calculate_score(self, x: torch.Tensor, y: torch.Tensor, y_mask: torch.Tensor | None = None):
        x, y, total = self.mask_pixels(x, y, y_mask)
        err = _charbonnier(y - x, eps=self.epsilon)
        # Sum over C,H,W; normalize by unmasked pixel count per batch, then mean over batch
        per_sample = err.sum(dim=(-3, -2, -1)) / total
        return per_sample

@register_class
class L1(Loss):
    @property
    def best_min(self) -> bool:
        return True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def calculate_score(self, x: torch.Tensor, y: torch.Tensor, y_mask: torch.Tensor = None):
        """
        Masked version of MAE (L1) loss.
        """
        x, y, total_unmasked = self.mask_pixels(x, y, y_mask)
        l1_loss = torch.sum(torch.abs(y - x), dim=(-3, -2, -1)) / total_unmasked
        return l1_loss

@register_class
class TotalVariation(Loss):
    """
    Total Variation (TV) metric/penalty for images or feature maps.

    TV encourages spatial smoothness by penalizing differences between neighboring
    pixels. With `anisotropic=True`, it sums absolute horizontal and vertical
    gradients (|dx| + |dy|). With `anisotropic=False`, it uses the isotropic form
    sqrt(dx^2 + dy^2), which is rotation-invariant. Lower values indicate smoother
    results. Supports optional spatial masks and returns a per-sample scalar
    normalized by the number of valid pixels.

    Parameters
    ----------
    anisotropic : bool, optional (default: False)
        If True, use anisotropic TV; if False, use isotropic TV.
    **kwargs : Any
        Forwarded to the base `Loss` class.

    Inputs
    ------
    x : torch.Tensor
        Tensor of shape [B, C, H, W] to regularize (e.g., an image or residual).
    y : torch.Tensor or None
        Unused placeholder for API compatibility.
    mask : torch.Tensor or None
        Optional binary/soft mask of shape [B, 1, H, W] (or [B, H, W]) defining
        valid pixels used for normalization.

    Returns
    -------
    torch.Tensor
        Tensor of shape [B] with the TV value per sample; lower is better.
    """
    @property
    def best_min(self) -> bool:
        return True


    def __init__(self, anisotropic: bool = False, eps: float = 1e-6, **kwargs):
        super().__init__(**kwargs)
        self.anisotropic = bool(anisotropic)
        self.eps = float(eps)

    def calculate_score(self, x: torch.Tensor, y: Optional[torch.Tensor] = None, mask: Optional[torch.Tensor] = None):
        """
        x: [B, C, H, W]
        mask (optional): [B, 1, H, W] or [B, H, W]; 1 = valid
        Returns per-sample TV normalized by the number of valid gradient locations.
        """
        B, C, H, W = x.shape

        # Forward differences
        dx = x[:, :, :, 1:] - x[:, :, :, :-1]   # [B, C, H,   W-1]
        dy = x[:, :, 1:, :] - x[:, :, :-1, :]   # [B, C, H-1, W  ]

        if self.anisotropic:
            if mask is not None:
                m = mask.unsqueeze(1) if mask.dim() == 3 else mask  # [B,1,H,W]
                m = m.to(torch.float32)
                mx = m[:, :, :, 1:] * m[:, :, :, :-1]               # for dx
                my = m[:, :, 1:, :] * m[:, :, :-1, :]               # for dy
                num = (dx.abs().to(torch.float32) * mx).sum((-3, -2, -1)) \
                    + (dy.abs().to(torch.float32) * my).sum((-3, -2, -1))
                denom = (mx.sum((-3, -2, -1)) + my.sum((-3, -2, -1))).clamp_min(1.0)
                return num / denom  # float32
            else:
                num = dx.abs().to(torch.float32).sum((-3, -2, -1)) \
                    + dy.abs().to(torch.float32).sum((-3, -2, -1))
                denom_scalar = float(H * (W - 1) + (H - 1) * W)
                return num / denom_scalar  # float32

        # ---- isotropic TV: sqrt(dx^2 + dy^2) on common grid [H-1, W-1] ----
        dx_c = dx[:, :, :-1, :]                    # [B, C, H-1, W-1]
        dy_c = dy[:, :, :, :-1]                    # [B, C, H-1, W-1]

        # Compute in float32 for AMP stability; use hypot for robust magnitude
        mag = torch.hypot(dx_c.to(torch.float32), dy_c.to(torch.float32)) + self.eps  # [B,C,H-1,W-1]

        if mask is not None:
            m = mask.unsqueeze(1) if mask.dim() == 3 else mask
            m = m.to(torch.float32)
            mx = m[:, :, :, 1:] * m[:, :, :, :-1]
            my = m[:, :, 1:, :] * m[:, :, :-1, :]
            m_iso = mx[:, :, :-1, :] * my[:, :, :, :-1]       # where both grads exist
            num = (mag * m_iso).sum((-3, -2, -1))
            denom = m_iso.sum((-3, -2, -1)).clamp_min(1.0)
            return num / denom  # float32
        else:
            num = mag.sum((-3, -2, -1))
            denom_scalar = float((H - 1) * (W - 1))
            return num / denom_scalar  # float32

@register_class
class SSIM(Loss):
    @property
    def best_min(self) -> bool:
        return False

    def __init__(self, window_size=11, size_average=True, **kwargs):
        super().__init__(**kwargs)
        self.window_size = window_size
        self.size_average = size_average
        self.channel = 1
        self.window = self.create_window(window_size, self.channel)

    @staticmethod
    def gaussian(window_size, sigma):
        from math import exp
        gauss = torch.Tensor([exp(-(x - window_size // 2) ** 2 / float(2 * sigma ** 2)) for x in range(window_size)])
        return gauss / gauss.sum()

    @staticmethod
    def create_window(window_size, channel):
        from torch.autograd import Variable
        _1D_window = SSIM.gaussian(window_size, 1.5).unsqueeze(1)
        _2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)
        window = Variable(_2D_window.expand(channel, 1, window_size, window_size).contiguous())
        return window

    @staticmethod
    def _ssim(img1, img2, window, window_size, channel, size_average=True):
        mu1 = F.conv2d(img1, window, padding=window_size // 2, groups=channel)
        mu2 = F.conv2d(img2, window, padding=window_size // 2, groups=channel)

        mu1_sq = mu1.pow(2)
        mu2_sq = mu2.pow(2)
        mu1_mu2 = mu1 * mu2

        sigma1_sq = F.conv2d(img1 * img1, window, padding=window_size // 2, groups=channel) - mu1_sq
        sigma2_sq = F.conv2d(img2 * img2, window, padding=window_size // 2, groups=channel) - mu2_sq
        sigma12 = F.conv2d(img1 * img2, window, padding=window_size // 2, groups=channel) - mu1_mu2

        C1 = 0.01 ** 2
        C2 = 0.03 ** 2

        ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))

        return ssim_map

    def calculate_score(self, x: torch.Tensor, y:torch.Tensor, y_mask: torch.Tensor = None):
        input_shape = x.shape
        x, y, _ = self.mask_pixels(x, y, y_mask)
        x = x.view(-1, *input_shape[-3:])
        y = y.view(-1, *input_shape[-3:])
        (_, channel, _, _) = x.size()

        if channel == self.channel and self.window.data.type() == x.data.type():
            window = self.window
        else:
            window = self.create_window(self.window_size, channel)

            if x.is_cuda:
                window = window.cuda(x.get_device())
            window = window.type_as(x)

            self.window = window
            self.channel = channel
        result = self._ssim(x, y, window, self.window_size, channel, self.size_average).mean((-3, -2, -1))
        result = result.view(input_shape[:-3])
        return result

@register_class
class TBE(Loss):
    'The Blur Effect non-reference metric to measure how blurry is the image.'

    def __init__(self, h_size=11, weight=1.0, name: str = None, **kwargs):
        super().__init__(weight=weight, name=name, **kwargs)
        self.h_size = h_size

    @property
    def best_min(self) -> bool:
        # As per the documentation, a higher blur score is indicative of a more blurry image,
        # so we'll want to minimize this score.
        return True

    def calculate_score(self, sr: torch.Tensor, entry):
        # Get the super-resolved images
        if not (sr.shape[1] == 1):
            raise ValueError('The Blur Effect metric only supports grayscale images.')
        # Initialize a tensor to store the blur scores
        blur_scores = []

        # Iterate over each image in the batch
        for i in range(sr.shape[0]):
            # Select the image
            img = sr[i, 0]

            # Convert the image to numpy array and grayscale
            img = img.detach().cpu().numpy()  # transpose to (height, width, channels)

            # Calculate the blur metric
            blur_score = measure.blur_effect(img, h_size=self.h_size)

            # Store the blur score
            blur_scores.append(blur_score)

        # Calculate the mean blur score for the batch
        # mean_blur_score = torch.mean(blur_scores)
        blur_scores = torch.tensor(blur_scores)
        return blur_scores

class ShiftNetRegisLoss(Loss):
    @property
    def best_min(self) -> bool:
        return True

    def __init__(self, weight=1.0, **kwargs):
        super().__init__(weight=weight, **kwargs)


    def calculate_score(self, shifts: torch.Tensor):
        loss = torch.mean(shifts, dim=(-2, -1)) ** 2
        return loss

@register_class
class L1RegisteredUncertaintyLoss(Loss):
    @property
    def best_min(self) -> bool:
        return True

    def __init__(self, weight=1.0, **kwargs):
        super().__init__(weight=weight, **kwargs)

    def calculate_score(self, x: torch.Tensor, y: torch.Tensor,
                        sigma_sr: torch.Tensor, y_mask: torch.Tensor = None):  # y_true, mu_pred, sigma_pred, y_mask, HR_SIZE):
        """
        Modified l1 loss to take into account pixel shifts
        """
        y_true = y
        HR_SIZE = y_true.shape[-1]
        mu_pred = x
        sigma_pred = sigma_sr
        if y_mask is None:
            y_mask = torch.ones_like(y_true)
        y_true = y_true[:, 0, :, :]
        mu_pred = mu_pred[:, 0, :, :]
        sigma_pred = sigma_pred[:, 0, :, :]
        y_mask = y_mask[:, 0, :, :]

        y_shape = y_true.size()
        border = 3
        max_pixels_shifts = 2 * border
        size_image = HR_SIZE
        cropped_predictions_mu = mu_pred[:, border:size_image - border, border:size_image - border]
        cropped_predictions_sigma = sigma_pred[:, border:size_image - border, border:size_image - border]

        X = []
        for i in range(max_pixels_shifts + 1):  # range(7)
            for j in range(max_pixels_shifts + 1):  # range(7)
                cropped_labels = y_true[:, i:i + (size_image - max_pixels_shifts),
                                 j:j + (size_image - max_pixels_shifts)]
                cropped_y_mask = y_mask[:, i:i + (size_image - max_pixels_shifts),
                                 j:j + (size_image - max_pixels_shifts)]

                cropped_predictions_mu_masked = cropped_predictions_mu * cropped_y_mask
                cropped_predictions_sigma_masked = cropped_predictions_sigma * cropped_y_mask
                cropped_labels_masked = cropped_labels * cropped_y_mask

                total_pixels_masked = torch.sum(cropped_y_mask, dim=(1, 2))

                # bias brightness
                b = (1.0 / total_pixels_masked) * torch.sum(cropped_labels_masked - cropped_predictions_mu_masked,
                                                            dim=(1, 2))
                # print(b.shape)
                b = torch.reshape(b, (y_shape[0], 1, 1))

                corrected_cropped_predictions_mu = cropped_predictions_mu_masked + b
                corrected_cropped_predictions_mu = corrected_cropped_predictions_mu * cropped_y_mask
                corrected_cropped_predictions_sigma = cropped_predictions_sigma_masked + b
                corrected_cropped_predictions_sigma = corrected_cropped_predictions_sigma * cropped_y_mask

                # l1_loss = torch.sum(torch.abs(cropped_labels_masked-corrected_cropped_predictions), dim=(1,2))/total_pixels_masked

                y = cropped_labels_masked
                m = corrected_cropped_predictions_mu
                s = corrected_cropped_predictions_sigma
                # l1_loss = torch.sum( torch.log(2*s) + torch.abs(y-m)/s, dim=(1,2))/total_pixels_masked
                l1_loss = torch.sum(s + torch.abs(y - m) * torch.exp(-s), dim=(1, 2)) / total_pixels_masked

                X.append(l1_loss)
        X = torch.stack(X)
        min_l1 = torch.min(X, dim=0).values

        return min_l1


@register_class
class CrossEntropy(Loss):
    @property
    def best_min(self) -> bool:
        # lower cross‐entropy is better
        return True

    def __init__(self, eps: float = 1e-12, **kwargs):
        """
        eps: small constant to avoid log(0)
        """
        super().__init__(**kwargs)
        self.eps = eps

    def calculate_score(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        """
        Computes per‑sample mean cross‑entropy:
            CE(x, y) = - 1/N * sum_i y_i * log(x_i)
        where N is the number of elements per sample (across all dims except batch).

        Args:
          x: predictions, shape [B, D1, D2, …], values in (0,1]
          y: target distributions, same shape as x
        Returns:
          Tensor of shape [B], the average CE per sample.
        """
        # clamp for numerical stability
        x = x.clamp(min=self.eps)

        # sum over all dims except batch (dim=0)
        dims = tuple(range(1, x.dim()))
        # total negative log‑likelihood per sample
        ce_sum = -(y * torch.log(x)).sum(dim=dims)

        # normalize by number of elements per sample
        numel = x[0].numel()
        return ce_sum / numel


@register_class
class MGE(Loss):
    """
    Mean Gradient Error (Sobel magnitude) with channel control.

    Args:
        per_channel (bool): If True, compare gradients per-channel.
                            If False, first sum channels -> 1 channel, then compare.
        square_diff (bool): If True, use squared difference; else absolute difference.
        eps (float): Small constant in gradient magnitude.

    Inputs to `calculate_score`:
        x: Tensor (B,C,H,W)  - prediction
        y: Tensor (B,C,H,W)  - reference/target
        y_mask (optional): (B,C,H,W) or (B,1,H,W) mask in {0,1} (or float in [0,1]).
                            If per_channel=False and mask has C>1, it will be merged to (B,1,H,W).
    """

    @property
    def best_min(self) -> bool:
        return True

    def __init__(self, per_channel: bool = True, square_diff: bool = True, eps: float = 1e-6, **kwargs):
        super().__init__(**kwargs)
        self.per_channel = bool(per_channel)
        self.square_diff = bool(square_diff)
        self.eps = float(eps)

        k_h = torch.tensor([[-1, 0, 1],
                            [-2, 0, 2],
                            [-1, 0, 1]], dtype=torch.float32).view(1, 1, 3, 3)
        k_v = torch.tensor([[-1, -2, -1],
                            [0, 0, 0],
                            [1, 2, 1]], dtype=torch.float32).view(1, 1, 3, 3)
        self.register_buffer("weight_h", k_h, persistent=False)
        self.register_buffer("weight_v", k_v, persistent=False)

    def _grad_mag(self, x: torch.Tensor) -> torch.Tensor:
        # x: BxCxHxW
        B, C, H, W = x.shape
        wh = self.weight_h.to(device=x.device, dtype=x.dtype).expand(C, 1, 3, 3).contiguous()
        wv = self.weight_v.to(device=x.device, dtype=x.dtype).expand(C, 1, 3, 3).contiguous()
        xp = F.pad(x, (1, 1, 1, 1), mode="reflect")
        gx = F.conv2d(xp, wh, groups=C)
        gy = F.conv2d(xp, wv, groups=C)
        return torch.sqrt(gx * gx + gy * gy + self.eps)

    def _merge_channels(self, t: torch.Tensor) -> torch.Tensor:
        # Sum channels -> single channel (B,1,H,W)
        return t.sum(dim=1, keepdim=True)

    def _merge_mask_like(self, m: torch.Tensor, target_channels: int) -> torch.Tensor:
        # Ensure mask has the same channel count as gradient tensor
        if m is None:
            return None
        if m.shape[1] == target_channels:
            return m
        # If we need 1 channel, merge any multi-channel mask conservatively (any-on)
        if target_channels == 1:
            return (m.sum(dim=1, keepdim=True) > 0).to(m.dtype)
        # If we need C channels but mask is single-channel, repeat
        if target_channels > 1 and m.shape[1] == 1:
            return m.repeat(1, target_channels, 1, 1)
        # Fallback: clamp and reshape
        return m[:, :target_channels]

    def _denominator(self, mask: torch.Tensor | None, B: int, C_eff: int, H: int, W: int, device, dtype):
        if mask is None:
            return torch.full((B,), C_eff * H * W, device=device, dtype=dtype)
        return mask.view(B, -1).sum(dim=1).clamp_min(1.0)

    def calculate_score(self, x: torch.Tensor, y: torch.Tensor, y_mask: torch.Tensor | None = None):
        # Use framework's masking to keep behaviour consistent; we will recompute denom for C_eff
        x, y, _ = self.mask_pixels(x, y, y_mask)

        # Channel handling
        if self.per_channel:
            x_use, y_use = x, y
        else:
            x_use, y_use = self._merge_channels(x) / x.shape[1], self._merge_channels(y) / y.shape[1]

        B, C_eff, H, W = x_use.shape

        # Gradients
        gx = self._grad_mag(x_use)
        gy = self._grad_mag(y_use)

        # Diff
        diff = gx - gy
        per_pix = diff.pow(2) if self.square_diff else diff.abs()

        # Mask align + denom
        mask_eff = None if y_mask is None else self._merge_mask_like(y_mask.to(device=x.device, dtype=x.dtype), C_eff)
        if mask_eff is not None:
            per_pix = per_pix * mask_eff
        denom = self._denominator(mask_eff, B, C_eff, H, W, x.device, x.dtype)

        # Reduce per sample
        return per_pix.sum(dim=(-3, -2, -1)) / denom

@register_class
class SAM(Loss):
    @property
    def best_min(self) -> bool:
        return True

    def __init__(
            self,
            eps: float = 1e-8,
            clamp: float = 1.0 - 1e-7,
            unit: Literal['radians', 'degrees'] = 'radians',
            **kwargs):
        """
        Spectral Angle Mapper (SAM) loss.

        SAM measures the spectral similarity between two multispectral images by computing, per pixel,
        the angle between the spectral vectors (across bands) and then averaging over spatial dimensions.

        Supports two input formats:
          1) Dict-of-bands: Dict[str, Tensor] where each value is [B,H,W] or [B,1,H,W]
             (bands are aligned by key; only common keys are used).
          2) Stacked tensor: Tensor of shape [B,C,H,W] where C is the number of bands.

        Parameters
        ----------
        eps : float
            Small constant to avoid division by zero in the cosine computation.
        clamp : float
            Clamp value applied to cosine similarity before acos to avoid numerical issues.
            Cosine is clamped to [-clamp, clamp].
        unit : Literal['radians', 'degrees']
            Output angle units. 'radians' returns angles in radians, 'degrees' converts to degrees.

        Notes
        -----
        - Output is one value per sample: Tensor[B].
        - Smaller values indicate better spectral alignment (best_min = True).
        """
        super().__init__(**kwargs)
        self.eps = eps
        self.clamp = clamp
        self.unit = unit

    def _to_bchw(self, d: Dict[str, torch.Tensor], keys) -> torch.Tensor:
        # each value may be [B,1,H,W] or [B,H,W]
        bands = []
        for k in keys:
            t = d[k]
            if t.dim() == 3:          # [B,H,W]
                t = t.unsqueeze(1)    # -> [B,1,H,W]
            elif t.dim() == 4:
                pass                  # [B,1,H,W] or [B,C?,H,W] (we assume 1)
            else:
                raise ValueError(f"SAM: band '{k}' tensor must be [B,H,W] or [B,1,H,W], got {tuple(t.shape)}")
            bands.append(t)
        return torch.cat(bands, dim=1)  # [B,C,H,W]

    def _is_bchw(self, t: torch.Tensor) -> bool:
        return t.dim() == 4

    def calculate_score(self, x: DictOrTensor, y: DictOrTensor) -> torch.Tensor:
        """
        Compute per-sample SAM score.

        Parameters
        ----------
        x : DictOrTensor
            Predicted image, either:
              - Dict[str, Tensor] with per-band tensors [B,H,W] or [B,1,H,W], or
              - Tensor[B,C,H,W]
        y : DictOrTensor
            Target image in the same format as x.

        Returns
        -------
        Tensor
            Per-sample mean SAM angle, Tensor[B], in units specified by `unit`.

        Raises
        ------
        ValueError
            If x and y have different types, unsupported shapes, or share no common band keys (dict input).
        """
        if type(x) != type(y):
            raise ValueError(f"SAM: x and y must be of the same type, got {type(x)} vs {type(y)}")

        if isinstance(x, dict):
            # use only common bands
            common = set(x.keys()) & set(y.keys())
            if not common:
                raise ValueError(f"SAM: x and y share no common band keys (x={list(x)}, y={list(y)})")

            keys = sorted(common)

            xb = self._to_bchw(x, keys)
            yb = self._to_bchw(y, keys)
        elif self._is_bchw(x) and self._is_bchw(y):
            xb = x
            yb = y
        else:
            raise ValueError(f"SAM: unsupported input types/shapes: {type(x)} {tuple(x.shape)} vs {type(y)} {tuple(y.shape)}")

        # SAM core: angle per pixel
        xb32 = xb.float()
        yb32 = yb.float()

        dot = (xb32 * yb32).sum(dim=1)                  # [B,H,W]
        nx = torch.linalg.vector_norm(xb32, dim=1)       # [B,H,W]
        ny = torch.linalg.vector_norm(yb32, dim=1)       # [B,H,W]
        cos = dot / (nx * ny + self.eps)
        cos = cos.clamp(-self.clamp, self.clamp)
        ang = torch.acos(cos)                            # radians

        out = ang.mean(dim=(-2, -1))                     # [B]
        if self.unit == "degrees":
            out = out * (180.0 / torch.pi)
        return out

@register_class
class LPIPS(Loss):
    @property
    def best_min(self) -> bool:
        return True

    def __init__(self, net='alex', device='cuda', **kwargs):
        super().__init__(**kwargs)
        self.net = net
        self.device = device
        self.loss = lpips.LPIPS(net=net).to(device)

    def _prepare_input_tensor(self, img):
        img_interp = img * 2.0 - 1.0
        return img_interp.to(self.device).float()

    def calculate_score(self, x: torch.Tensor, y: torch.Tensor, y_mask: torch.Tensor | None = None):
        x_tensor = self._prepare_input_tensor(x)
        y_tensor = self._prepare_input_tensor(y)
        result = self.loss(x_tensor, y_tensor)
        return result
