from abc import ABC, abstractmethod

from torchmetrics import Metric

class TorchMetricDummyLoss(Metric, ABC):
    """
    Base class for all loss functions. For now it is exactly the same as torchmetrics.Metric, but it can be extended in
    the future. The reasoning behind this class is to create an adapter between our codebase and torchmetrics, so that
    we can easily switch to another library in the future if needed or event mix them. For now, if you need to use a
    torchmetrics metric as a loss function, you can simply inherit from this class and use srforge.loss.Loss API.
    WORK IN PROGRESS - this module is not yet used in the codebase and is under development.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    @abstractmethod
    def update(self, *args, **kwargs):
        raise NotImplementedError("Update method must be implemented in the subclass.")

    @abstractmethod
    def compute(self):
        raise NotImplementedError("Compute method must be implemented in the subclass.")

