from dataclasses import dataclass
from typing import Any, Dict, Iterable, Union, List, Callable, Optional

import torch

TensorOrDict = Union[torch.Tensor, Dict[str, "TensorOrDict"]]

def _map_tree(x: TensorOrDict, fn):
    """Apply ``fn`` to every leaf tensor in a nested dict-or-tensor tree."""
    if isinstance(x, dict):
        return {k: _map_tree(v, fn) for k, v in x.items()}
    return fn(x)

def _concat_tree(values: list[TensorOrDict]) -> TensorOrDict:
    """
    Concatenate a list of TensorOrDict along batch dimension.
    """
    first = values[0]
    if isinstance(first, dict):
        keys = set(first.keys())
        if not all(isinstance(v, dict) and set(v.keys()) == keys for v in values):
            raise ValueError("All dict-valued entries must share the same keys.")
        return {k: _concat_tree([v[k] for v in values]) for k in keys}
    else:
        return torch.cat(values, dim=0)

def _to_batch_tensor(x: TensorOrDict) -> torch.Tensor:
    """
    Collapse TensorOrDict into a tensor of shape [B].

    - If x is a tensor: assumed to have batch dimension as first dim (usually [B]).
      We return x.view(x.shape[0], -1).mean(dim=1) to get [B].
    - If x is a dict: we
        1) recursively convert each value to [B] via _to_batch_tensor,
        2) stack them and sum (or mean) over bands, yielding [B].
    """
    if isinstance(x, dict):
        # all band tensors must agree in batch size
        tensors = [_to_batch_tensor(v) for v in x.values()]  # each [B]
        stacked = torch.stack(tensors, dim=0)                  # [num_bands, B]
        return stacked.mean(dim=0)
    else:
        # x is tensor, treat all non-batch dims as "features" and average them
        if x.ndim == 1:
            return x  # already [B]
        else:
            B = x.shape[0]
            return x.view(B, -1).mean(dim=1)   # [B]

def _detach_tree(x: TensorOrDict, cpu: bool) -> TensorOrDict:
    """Detach every tensor in the tree from the computation graph, optionally moving to CPU."""
    if isinstance(x, dict):
        return {k: _detach_tree(v, cpu) for k, v in x.items()}
    return x.detach() if not cpu else x.detach().cpu()

def _sum_tree(values: Iterable[TensorOrDict]) -> TensorOrDict:
    """Element-wise sum over a sequence of ``TensorOrDict`` values."""
    values = list(values)
    if not values:
        raise ValueError("Cannot sum empty MetricScores")

    first = values[0]

    if isinstance(first, dict):
        keys = set(first.keys())
        if not all(isinstance(v, dict) and set(v.keys()) == keys for v in values):
            raise ValueError(f"All dict-valued metrics must share the same keys; got {[v.keys() for v in values]}")
        return {k: _sum_tree([v[k] for v in values]) for k in keys}

    # assume tensors / scalars
    total = first
    for v in values[1:]:
        total = total + v
    return total


@dataclass
class MetricEntry:
    """
    Holds all variants of a single metric:
      - raw: output of calculate_score (no sign, no weight)
      - best_min: True if smaller is better; False if larger is better
      - weight: optimization weight (can be 0)
    """
    raw: TensorOrDict
    best_min: bool
    weight: float

    # structured views
    def as_raw(self) -> TensorOrDict:
        return self.raw

    def as_opt(self) -> TensorOrDict:
        return _map_tree(self.raw, lambda x: x if self.best_min else -x)

    def as_weighted(self) -> TensorOrDict:
        return _map_tree(self.as_opt(), lambda x: x * self.weight)

    # batch views: always [B]
    def raw_batch(self) -> torch.Tensor:
        return _to_batch_tensor(self.as_raw())

    def opt_batch(self) -> torch.Tensor:
        return _to_batch_tensor(self.as_opt())

    def weighted_batch(self) -> torch.Tensor:
        return _to_batch_tensor(self.as_weighted())

    # concat with another entry along batch dim
    def concat(self, other: "MetricEntry") -> "MetricEntry":
        if not (self.best_min == other.best_min):
            raise ValueError("best_min mismatch in concat")
        if not (self.weight == other.weight):
            raise ValueError("weight mismatch in concat")
        return MetricEntry(
            raw=_concat_tree([self.raw, other.raw]),
            best_min=self.best_min,
            weight=self.weight,
            )


@dataclass
class MetricScores:
    metrics: Dict[str, MetricEntry]

    @classmethod
    def single(cls, name: str, raw: TensorOrDict, *, best_min: bool, weight: float) -> "MetricScores":
        return cls({name: MetricEntry(raw=raw, best_min=best_min, weight=weight)})

    @classmethod
    def empty(cls) -> "MetricScores":
        return cls({})

    def __iter__(self):
        return iter(self.metrics.items())

    def __getitem__(self, name: str) -> MetricEntry:
        return self.metrics[name]

    # For one batch: merge non-overlapping metric sets
    def merge(self, other: "MetricScores") -> "MetricScores":
        shared = set(self.metrics.keys()) & set(other.metrics.keys())
        if shared:
            raise ValueError(f"Duplicate metric names in merge: {shared}")
        new = dict(self.metrics)
        new.update(other.metrics)
        return MetricScores(new)

    # For accumulation across batches: concat along batch dim
    def add_scores(self, other: "MetricScores") -> None:
        """
        In-place accumulation: concatenates batch dimension when names match.
        """
        for name, entry in other.metrics.items():
            if name in self.metrics:
                self.metrics[name] = self.metrics[name].concat(entry)
            else:
                self.metrics[name] = entry

    # detached copy (for logging / accumulation, no graph)
    def detached(self, cpu=True) -> "MetricScores":
        return MetricScores({
            name: MetricEntry(
                raw=_detach_tree(entry.raw, cpu),
                best_min=entry.best_min,
                weight=entry.weight,
            )
            for name, entry in self.metrics.items()
        })

    # dict views (structured)
    def as_raw_dict(self) -> Dict[str, TensorOrDict]:
        return {name: entry.as_raw() for name, entry in self.metrics.items()}

    def as_weighted_dict(self) -> Dict[str, TensorOrDict]:
        return {name: entry.as_weighted() for name, entry in self.metrics.items()}

    def _as_flat_dict(
            self,
            value_getter: Callable[[MetricEntry], TensorOrDict],
            total_getter: Callable[["MetricScores"], torch.Tensor],
            reduce_batch: bool = True,
            include_metric_totals: bool = True,
            include_global_total: bool = True,
            global_total_key: str = "total",
    ) -> dict[str, TensorOrDict]:
        """
        Generic flattener:

        name           -> metric-level total (if include_metric_totals)
        name.band      -> per-band
        ...
        global_total_key -> global total over all metrics
        """
        out: dict[str, TensorOrDict] = {}

        for name, entry in self.metrics.items():
            v = value_getter(entry)  # tensor[B] or dict[band -> tensor[B]]

            if isinstance(v, dict):
                # per-band values
                for band_name, band_tensor in v.items():
                    key = f"{name}.{band_name}"
                    out[key] = band_tensor.mean() if reduce_batch else band_tensor  # scalar or [B]

                if include_metric_totals:
                    # collapse bands → [B]
                    total_per_sample = _to_batch_tensor(v)
                    out[name] = total_per_sample.mean() if reduce_batch else total_per_sample
            else:
                # flat metric
                out[name] = v.mean() if reduce_batch else v

        if include_global_total:
            total = total_getter(self)  # [B]
            out[global_total_key] = total.mean() if reduce_batch else total

        return out

    def as_weighted_flat_dict(
            self,
            reduce_batch: bool = True,
            include_metric_totals: bool = True,
            include_global_total: bool = True,
            global_total_key: str = "total",
    ) -> dict[str, TensorOrDict]:
        return self._as_flat_dict(
            value_getter=lambda e: e.as_weighted(),
            total_getter=lambda s: s.total_weighted(),
            reduce_batch=reduce_batch,
            include_metric_totals=include_metric_totals,
            include_global_total=include_global_total,
            global_total_key=global_total_key,
        )

    def as_raw_flat_dict(
            self,
            reduce_batch: bool = True,
            include_metric_totals: bool = True,
    ) -> dict[str, TensorOrDict]:
        return self._as_flat_dict(
            value_getter=lambda e: e.as_raw(),
            total_getter=lambda s: s.total_raw(),
            reduce_batch=reduce_batch,
            include_metric_totals=include_metric_totals,
            include_global_total=False,
        )

    def as_summary_dict(self) -> dict[str, TensorOrDict]:
        results_dict = self.as_weighted_flat_dict(reduce_batch=True, include_global_total=True,
                                                         include_metric_totals=True, global_total_key="total")
        results_dict['raw'] = self.as_raw_flat_dict(reduce_batch=True, include_metric_totals=True)
        return results_dict

    # totals over current (possibly accumulated) batch: always [B]
    def total_raw(self) -> torch.Tensor:
        vals = [e.raw_batch() for e in self.metrics.values()]
        if len(vals) == 0:
            return torch.Tensor()
        total = vals[0]
        for v in vals[1:]:
            total = total + v
        return total  # [B]

    def total_weighted(self) -> torch.Tensor:
        vals = [e.weighted_batch() for e in self.metrics.values()]
        if len(vals) == 0:
            return torch.Tensor()
        total = vals[0]
        for v in vals[1:]:
            total = total + v
        return total  # [B]

    # per-metric means over all accumulated examples
    def mean_raw(self) -> Dict[str, torch.Tensor]:
        return {name: e.raw_batch().mean() for name, e in self.metrics.items()}

    def mean_weighted(self) -> Dict[str, torch.Tensor]:
        return {name: e.weighted_batch().mean() for name, e in self.metrics.items()}
