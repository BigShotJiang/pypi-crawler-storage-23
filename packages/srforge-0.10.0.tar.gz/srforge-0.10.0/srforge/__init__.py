from srforge.registry import ClassRegistry
import logging
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("srforge")
except PackageNotFoundError:
    __version__ = "0+local"

logger = logging.getLogger(__name__)

class Singleton(type):
    """Metaclass implementing the Singleton pattern.

    Ensures only one instance of a class exists throughout the application.

    Attributes:
        _instances: Dictionary mapping classes to their singleton instances.
    """
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super().__call__(*args, **kwargs)
        return cls._instances[cls]

class GlobalSettings(metaclass=Singleton):
    """Application-wide settings manager.

    Provides centralized access to global configuration using the Singleton pattern.

    Attributes:
        debug_mode: Enable verbose debugging output.
        output_directory: Root directory for outputs (models, logs, visualizations).
        config: Reference to the main configuration object.
    """
    def __init__(self):
        """Initialize default settings."""
        self.debug_mode = False
        self.output_directory = 'output'
        self.config = None
        from srforge.observers.bus import EventBus
        self.event_bus = EventBus()

    def __setattr__(self, key, value):
        """Set an attribute value.

        Args:
            key: Attribute name.
            value: Value to assign.
        """
        # logger.info(f"GlobalSettings: setting {key} to {value}")
        super().__setattr__(key, value)

ClassRegistry().discover(__name__)


def init(cfg) -> "ConfigResolver":
    """One-call framework setup for Hydra-based scripts.

    Performs the boilerplate that every script needs:

    1. Strips internal config keys (``clear_defaults``).
    2. Wires :class:`GlobalSettings` (config, output directory).
    3. Creates and returns a :class:`ConfigResolver`.

    Everything config-structure-dependent (tracker, observers, device,
    debug level) is left to the caller.

    Args:
        cfg: An OmegaConf ``DictConfig`` from ``@hydra.main``.

    Returns:
        A :class:`~srforge.config.ConfigResolver` bound to *cfg*.
    """
    from hydra.core.hydra_config import HydraConfig

    from srforge.config import ConfigResolver
    from srforge.config.utils import clear_defaults

    clear_defaults(cfg)
    settings = GlobalSettings()
    settings.config = cfg
    settings.output_directory = HydraConfig.get().runtime.output_dir
    return ConfigResolver(cfg)