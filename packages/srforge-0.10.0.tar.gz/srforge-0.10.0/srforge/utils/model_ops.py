import logging
from typing import Union

import torch

logger = logging.getLogger(__name__)

def get_submodule(source_module: torch.nn.Module, submodule_name: str) -> torch.nn.Module:
    """
    Get a submodule from a module by name.
    :param source_module: The model instance.
    :param submodule_name: The name of the module to get.
    :return: The module instance (torch.nn.Module).
    """
    if not hasattr(source_module, submodule_name):
        raise ValueError(f"Module '{submodule_name}' not found in model '{source_module.__class__.__name__}'.")
    module = getattr(source_module, submodule_name)
    logger.info(f"Extracted module '{submodule_name}' from model '{source_module.__class__.__name__}'.")
    return module


def replace_with_modules_from_another_model(target_model: torch.nn.Module,
                                      target_module_name: Union[str, list[str]],
                                      source_model: torch.nn.Module,
                                      source_module_name: Union[str, list[str]] = None) -> torch.nn.Module:
    """
    Replace a single or multiple modules in a target model with modules from a source model.
    :param target_model: The model instance to modify.
    :param target_module_name: The name(s) of the module(s) in the target model to replace.
    :param source_model: The model instance to copy modules from.
    :param source_module_name: The name(s) of the module(s) in the source model to copy.
                               If None, the same names as target_module_name are used.

    :return: The modified target model instance.
    """
    if source_module_name is None:
        source_module_name = target_module_name
    if isinstance(target_module_name, str):
        target_module_name = [target_module_name]
    if isinstance(source_module_name, str):
        source_module_name = [source_module_name]
    if len(target_module_name) != len(source_module_name):
        raise ValueError("'target_module_name' and 'source_module_name' parameters must have the same length if provided as lists.")

    for t_name, s_name in zip(target_module_name, source_module_name):
        if not hasattr(target_model, t_name):
            raise ValueError(f"Module '{t_name}' not found in target model '{target_model.__class__.__name__}'.")
        if not hasattr(source_model, s_name):
            raise ValueError(f"Module '{s_name}' not found in source model '{source_model.__class__.__name__}'.")
        setattr(target_model, t_name, get_submodule(source_model, s_name))
        logger.info(f"Replaced module '{t_name}' in target model with module '{s_name}' from source model.")

    return target_model

def replace_module(target_model: torch.nn.Module,
                   target_module_name: str,
                   new_module: torch.nn.Module) -> torch.nn.Module:
    """
    Replace a module in a target model with a new module.
    :param target_model: The model instance to modify.
    :param target_module_name: The name of the module in the target model to replace.
    :param new_module: The new module instance to insert.

    :return: The modified target model instance.
    """
    if not hasattr(target_model, target_module_name):
        raise ValueError(f"Module '{target_module_name}' not found in target model '{target_model.__class__.__name__}'.")
    setattr(target_model, target_module_name, new_module)
    logger.info(f"Replaced module '{target_module_name}' in target model with new module '{new_module.__class__.__name__}'.")

    return target_model