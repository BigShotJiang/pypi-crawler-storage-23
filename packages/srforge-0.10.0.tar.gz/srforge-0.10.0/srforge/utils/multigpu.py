"""Multi-GPU device setup and DataParallel wrapping utilities."""

from __future__ import annotations

import logging
from typing import Any

import torch

logger = logging.getLogger(__name__)


def setup_device(
    model: torch.nn.Module,
    device_config: Any,
    dataset: Any = None,
) -> tuple[torch.nn.Module, torch.device]:
    """Resolve device config, move model to device, and wrap DataParallel if needed.

    Args:
        model: The model to place on device.
        device_config: Single device (int/str) or list for multi-GPU.
        dataset: Required for multi-GPU — probes element type to choose
            between ``torch.nn.DataParallel`` and
            ``torch_geometric.nn.DataParallel``.  Ignored for single-GPU.

    Returns:
        ``(model, device)`` tuple.  *model* may be wrapped in DataParallel.

    Raises:
        ValueError: If multi-GPU is requested but *dataset* is ``None``.
    """
    try:
        from omegaconf import ListConfig
    except ImportError:  # pragma: no cover
        ListConfig = None

    list_types = (list, tuple) + ((ListConfig,) if ListConfig else ())

    if isinstance(device_config, list_types) and len(device_config) > 1:
        device = torch.device(device_config[0])
        model.to(device)
        if dataset is None:
            raise ValueError(
                "dataset is required for multi-GPU setup "
                "(needed to detect Entry vs GraphEntry)."
            )
        model = wrap_data_parallel(model, device_config, dataset)
        logger.info("Using devices: %s", [torch.device(d) for d in device_config])
    else:
        if isinstance(device_config, list_types):
            device_config = device_config[0]
        device = torch.device(device_config)
        model.to(device)
        logger.info("Using device: %s", device)

    return model, device


def wrap_data_parallel(
    model: torch.nn.Module,
    device_ids: list,
    dataset,
) -> torch.nn.Module:
    """Wrap *model* in DataParallel based on dataset element type.

    Probes the first element of *dataset* to decide between standard
    ``torch.nn.DataParallel`` (for :class:`Entry`) and
    ``torch_geometric.nn.DataParallel`` (for :class:`GraphEntry`).

    Args:
        model: The model to wrap.
        device_ids: List of device IDs (ints, strings, or ``torch.device``).
        dataset: Dataset to probe for Entry vs GraphEntry.

    Returns:
        DataParallel-wrapped model.
    """
    from srforge.data import Entry, GraphEntry

    device_ids = [torch.device(d).index for d in device_ids]
    first_element = dataset[0]

    if isinstance(first_element, Entry):
        return torch.nn.DataParallel(model, device_ids=device_ids)
    elif isinstance(first_element, GraphEntry):
        import torch_geometric as tg

        return tg.nn.DataParallel(model, device_ids=device_ids)
    else:
        raise TypeError(
            f"Unsupported dataset element type: {type(first_element)}"
        )
