import logging
import torch

from srforge.models import Model
from srforge.utils.deprecation import _deprecated
from srforge.utils.checkpoint import (
    load_weights_from_wandb,
    load_weights_from_tracker,
    get_model_from_wandb as _original_get_model_from_wandb,
)
from srforge.utils.model_ops import get_submodule


logger = logging.getLogger(__name__)


@_deprecated(
    old_name='load_from_wandb',
    new_name='load_weights_from_tracker',
    new_func=load_weights_from_wandb,
    name_map={'model': 'module'}
)
def load_from_wandb(model: Model, project: str, entity: str, run_id: str, model_name: str = None, load_best_model: bool = True):
    """
    Deprecated function. Use `load_weights_from_tracker` instead.
    """
    raise RuntimeError("This function is a forwarder; it should have been wrapped by the _deprecated decorator.")

@_deprecated(
    old_name='get_module_from_model',
    new_name='get_submodule',
    new_func=get_submodule,
    name_map={'model': 'source_module', 'module_name': 'submodule_name'}
)
def get_module_from_model(model: torch.nn.Module, module_name: str):
    """
    Deprecated function. Use `get_submodule` instead.
    """
    raise RuntimeError("This function is a forwarder; it should have been wrapped by the _deprecated decorator.")

@_deprecated(
    old_name='srforge.utils.model.get_model_from_wandb',
    new_name='srforge.utils.checkpoint.get_model_from_wandb',
    new_func=_original_get_model_from_wandb,
    name_map={}
)
def get_model_from_wandb(model_name: str, run_id: str, project: str, entity: str, load_best_model: bool) -> torch.nn.Module:
    """
    Deprecated function. Use `get_model_from_wandb` from `srforge.utils.checkpoint` instead.
    """
    raise RuntimeError("This function is a forwarder; it should have been wrapped by the _deprecated decorator.")
