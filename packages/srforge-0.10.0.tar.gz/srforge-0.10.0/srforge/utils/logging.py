import logging
import sys
from typing import Union

import colorlog


# Global Logger Configuration
def configure_logger(level: Union[str, int] = logging.INFO):
    """
    Configures the global logger with the given logging level, with colored output.
    """
    # Define the logger
    logger = logging.getLogger()
    logger.setLevel(level)  # Set global logging level

    # Clear existing handlers to prevent duplicates
    if logger.hasHandlers():
        logger.handlers.clear()

    # Create console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)

    # Define colored formatter
    formatter = colorlog.ColoredFormatter(
        '%(log_color)s%(asctime)s - %(name)s - %(funcName)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
        log_colors={
            'DEBUG': 'cyan',
            'INFO': 'green',
            'WARNING': 'yellow',
            'ERROR': 'red',
            'CRITICAL': 'bold_red',
        },
        secondary_log_colors={},
        style='%'
    )
    console_handler.setFormatter(formatter)

    # Add handler to logger
    logger.addHandler(console_handler)