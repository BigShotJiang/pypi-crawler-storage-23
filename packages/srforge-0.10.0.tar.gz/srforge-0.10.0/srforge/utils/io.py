import logging
import pickle
import json
from pathlib import Path
from typing import Union, List, Any

import cv2
import torch

logger = logging.getLogger(__name__)

IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.tif', '.dib', '.jp2']
PICKLE_EXTENSIONS = ['.pkl', '.pickle']
JSON_EXTENSIONS = ['.json']

def load_image(filepath: Union[str, Path]) -> torch.Tensor:
    """
    Load image from the given path to format [C, H, W].

    :param filepath: Path to the image
    :return: Loaded image
    """
    image = cv2.imread(str(filepath), cv2.IMREAD_UNCHANGED)
    if image.ndim == 2:
        image = image[:, :, None]
    image = torch.from_numpy(image).permute(2, 0, 1).float()
    return image

def standardize_values(values: Any) -> Any:
    if isinstance(values, (list, tuple)):
        return torch.tensor(values).float()
    elif isinstance(values, dict):
        standardized = {}
        for key, value in values.items():
            standardized[key] = standardize_values(value)
        return standardized
    return values

def load_file(filepath: Union[str, Path]) -> Union[Any, List[Any]]:
    """
    Load file from the given path.

    :param filepath: Path of the file or directory to load
    :return: Loaded file
    """
    filepath = Path(filepath)
    if not filepath.exists():
        raise FileNotFoundError(f"File {filepath} does not exist.")
    if filepath.is_dir():
        result = []
        for file in filepath.iterdir():
            loaded_file = load_file(file)
            if loaded_file is not None:
                result.append(loaded_file)
        return result

    extension = filepath.suffix.lower()
    if extension in IMAGE_EXTENSIONS:
        return load_image(filepath)
    if extension in PICKLE_EXTENSIONS:
        with open(filepath, 'rb') as f:
            return pickle.load(f)
    if extension in JSON_EXTENSIONS:
        with open(filepath, 'r') as f:
            attributes = json.load(f)
        for key, value in attributes.items():
            attributes[key] = standardize_values(value)
        return attributes
    return None


def list_subdirs(directory: Union[str, Path],
                 allowed_dirs: Union[str, List[str], None] = None
                 ) -> List[Path]:
    """
    Returns a list of subdirectories (as `pathlib.Path` objects) in a folder ``directory``.
    ``allowed_dirs`` specifies which folders should be included. If ``allowed_dirs`` is
    empty or None, all subdirectories will be included.

    :param directory: A Path object pointing to the directory to scan.
    :param allowed_dirs: A string or list of strings specifying folder names to include.
    :return: A list of Path objects corresponding to subdirectories.
    """
    if allowed_dirs is None:
        allowed_dirs = []
    elif isinstance(allowed_dirs, str):
        allowed_dirs = [allowed_dirs]

    return [
        entry
        for entry in directory.iterdir()
        if entry.is_dir() and (not allowed_dirs or entry.name in allowed_dirs)
    ]


def deep_list_subdirs(
        directory: Path,
        depth: int = 0,
        allowed_dirs: Union[str, List[str], None] = None
) -> List[Path]:
    """
    Returns a list of subdirectories (as `Path` objects) for all folders
    located `depth` levels deeper. If `depth` is 0, it behaves just
    like `list_subdirs`.

    :param directory: Path to the root directory.
    :param depth: How many levels deeper to recurse.
    :param allowed_dirs: If provided, only these subdirectory names are returned or scanned further.
    :return: A list of Path objects corresponding to discovered subdirectories.
    """
    if not (depth >= 0):
        raise ValueError(f"Depth must be >= 0 (got {depth})")

    final_list: List[Path] = []

    if depth == 0:
        # At the final level, respect `allowed_dirs`.
        final_list.extend(
            list_subdirs(directory, allowed_dirs=allowed_dirs)
        )
    else:
        # Go one level down, then recurse deeper.
        for subdir in list_subdirs(directory, allowed_dirs=allowed_dirs):
            final_list.extend(
                deep_list_subdirs(
                    subdir, depth=depth - 1, allowed_dirs=allowed_dirs
                )
            )

    return final_list