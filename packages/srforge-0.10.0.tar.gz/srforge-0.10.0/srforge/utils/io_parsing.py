"""Unified IO config parsing for set_io() — single format for all IOModule subclasses.

The ONE format::

    {"inputs": {param_or_port: entry_field}, "outputs": <string|list|dict>}

- ``inputs``: dict (single application) or list of dicts (multiple applications).
- ``outputs``: string, list, dict, or omitted (in-place default).
"""

from typing import Any, Dict, List, Mapping, Tuple

from omegaconf import ListConfig

_APPLICATION = Tuple[Dict[str, str], List[str]]


def parse_io_config(io_cfg: Any) -> Tuple[Any, Any]:
    """Validate and extract ``(inputs_raw, outputs_raw)`` from the IO config.

    Raises :class:`TypeError` if *io_cfg* is not the expected format.
    """
    if io_cfg is None:
        raise TypeError(
            "IO config must be a dict with an 'inputs' key, got None."
        )
    if not isinstance(io_cfg, Mapping) or "inputs" not in io_cfg:
        raise TypeError(
            f"IO config must be a dict with an 'inputs' key. "
            f"Expected {{'inputs': {{param: field}}, 'outputs': ...}}, "
            f"got {type(io_cfg).__name__}."
        )
    inputs_raw = io_cfg["inputs"]
    outputs_raw = io_cfg.get("outputs")

    # Validate inputs type
    if isinstance(inputs_raw, Mapping):
        pass  # single application
    elif isinstance(inputs_raw, (list, tuple, ListConfig)):
        for i, item in enumerate(inputs_raw):
            if not isinstance(item, Mapping):
                raise TypeError(
                    f"Multiple applications: 'inputs[{i}]' must be a dict, "
                    f"got {type(item).__name__}."
                )
    else:
        raise TypeError(
            f"'inputs' must be a dict or list of dicts, "
            f"got {type(inputs_raw).__name__}."
        )
    return inputs_raw, outputs_raw


def build_applications(inputs_raw: Any, outputs_raw: Any) -> List[_APPLICATION]:
    """Convert parsed ``(inputs, outputs)`` into a list of applications."""
    if isinstance(inputs_raw, Mapping):
        # Single application
        input_map = dict(inputs_raw)
        output_fields = _resolve_single_outputs(input_map, outputs_raw)
        return [(input_map, output_fields)]

    # Multiple applications (list of dicts)
    inputs_list = list(inputs_raw)
    if outputs_raw is None:
        # In-place: each application's output = its input field values
        return [(dict(item), list(dict(item).values())) for item in inputs_list]

    # Coerce outputs to a list
    if isinstance(outputs_raw, str):
        outputs_list: Any = [outputs_raw]
    elif isinstance(outputs_raw, (list, tuple, ListConfig)):
        outputs_list = list(outputs_raw)
    else:
        raise TypeError(
            f"For multiple applications, 'outputs' must be a list, "
            f"got {type(outputs_raw).__name__}."
        )

    if len(outputs_list) != len(inputs_list):
        raise ValueError(
            f"'inputs' and 'outputs' lengths must match: "
            f"{len(inputs_list)} inputs vs {len(outputs_list)} outputs."
        )

    apps: List[_APPLICATION] = []
    for item, out in zip(inputs_list, outputs_list):
        input_map = dict(item)
        if isinstance(out, (list, tuple, ListConfig)):
            apps.append((input_map, list(out)))
        else:
            apps.append((input_map, [str(out)]))
    return apps


def _resolve_single_outputs(input_map: dict, outputs_raw: Any) -> List[str]:
    """Resolve outputs for a single application."""
    if outputs_raw is None:
        if len(input_map) > 1:
            raise ValueError(
                f"'outputs' is required when 'inputs' has multiple parameters "
                f"({list(input_map.keys())}). In-place default only works with "
                f"a single input."
            )
        return list(input_map.values())
    if isinstance(outputs_raw, str):
        return [outputs_raw]
    if isinstance(outputs_raw, Mapping):
        return list(outputs_raw.values())
    if isinstance(outputs_raw, (list, tuple, ListConfig)):
        return list(outputs_raw)
    raise TypeError(
        f"'outputs' must be a string, list, dict, or None, "
        f"got {type(outputs_raw).__name__}."
    )


def flat_to_applications(
    flat_map: Dict[str, str],
    param_names: List[str],
) -> List[_APPLICATION]:
    """Convert a flat ``{src_field: dst_field}`` map into applications.

    Used by :class:`SequentialModel` when building DataTransform steps
    from the flow DSL.  Requires the transform to have exactly one parameter.

    Args:
        flat_map: ``{entry_field_in: entry_field_out}`` pairs.
        param_names: Parameter names from the transform method signature.
    """
    if len(param_names) != 1:
        raise ValueError(
            f"flat_to_applications requires a single-parameter transform, "
            f"got {len(param_names)} parameters: {param_names}."
        )
    param = param_names[0]
    return [
        ({param: src}, [dst if dst is not None else src])
        for src, dst in flat_map.items()
    ]
