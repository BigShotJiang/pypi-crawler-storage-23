"""Base class for components with configurable input/output bindings."""

from typing import Any, Dict, Mapping, Self

from srforge.utils.iospec import IOSpec
from srforge.utils.io_parsing import parse_io_config


class _IOPort:
    """Data descriptor reserving an attribute name for IO port binding.

    Installed on IOModule subclasses via __init_subclass__ for each
    port declared in io_spec. Prevents accidental overwrites and
    enforces immutability after binding.
    """

    def __init__(self, name: str):
        self.name = name
        self.storage_key = f"_ioport_{name}"

    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        try:
            return obj.__dict__[self.storage_key]
        except KeyError:
            raise AttributeError(
                f"'{type(obj).__name__}' IO port '{self.name}' is not bound yet. "
                f"Call set_io() first."
            )

    def __set__(self, obj, value):
        if getattr(obj, '_io_binding_in_progress', False):
            obj.__dict__[self.storage_key] = value
            return
        raise AttributeError(
            f"'{type(obj).__name__}': cannot assign to IO port '{self.name}'. "
            f"IO port attributes are managed by set_io/bind_io."
        )

    def __delete__(self, obj):
        raise AttributeError(
            f"'{type(obj).__name__}': cannot delete IO port '{self.name}'."
        )


class IOModule:
    """Base class providing IO port binding functionality.

    Enables models and transforms to declare their inputs/outputs via IOSpec
    and bind them to concrete Entry field names at configuration time.

    Attributes:
        io_spec: Declares required/optional input and output ports.
    """
    io_spec: IOSpec | None = None

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        # Only install _IOPort descriptors if the class opts in.
        if not getattr(cls, '_install_io_ports', True):
            return
        spec = cls.__dict__.get('io_spec')
        if spec is not None and isinstance(spec, IOSpec):
            for port_name in spec.all_inputs + spec.all_outputs:
                setattr(cls, port_name, _IOPort(port_name))

    def __init__(self, *args, **kwargs):
        """Initialize IO binding state."""
        self._io_map: Dict[str, Any] = {}
        self._resolved_vars: Dict[str, Any] = {}
        self._io_bound = False
        super().__init__(*args, **kwargs)

    def set_io(self, io_cfg: Any, *, strict: bool = True, require_all: bool = True) -> Self:
        """Bind IO mapping using the unified config format.

        Accepts the standard structured format::

            {"inputs": {port: field, ...}, "outputs": {port: field, ...}}

        Merges inputs and outputs into a flat ``{port: field}`` dict
        and delegates to :meth:`bind_io`.

        Args:
            io_cfg: Structured IO config dict with ``inputs`` and
                optionally ``outputs`` keys.
            strict: Reject unknown port names if True.
            require_all: Require all mandatory ports to be mapped if True.

        Returns:
            Self for method chaining.
        """
        inputs_raw, outputs_raw = parse_io_config(io_cfg)
        # Merge into flat {port: field} dict for bind_io
        if not isinstance(inputs_raw, Mapping):
            raise TypeError(
                f"{self.__class__.__name__}: 'inputs' must be a dict for "
                f"port-based binding, got {type(inputs_raw).__name__}."
            )
        flat: dict[str, Any] = dict(inputs_raw)
        if outputs_raw is not None:
            if isinstance(outputs_raw, Mapping):
                # Check for conflicting bindings
                conflicts = {
                    k: (flat[k], outputs_raw[k])
                    for k in set(flat) & set(outputs_raw)
                    if flat[k] != outputs_raw[k]
                }
                if conflicts:
                    detail = ", ".join(
                        f"'{k}' maps to '{v_in}' in inputs but '{v_out}' in outputs"
                        for k, (v_in, v_out) in conflicts.items()
                    )
                    raise ValueError(
                        f"{self.__class__.__name__} structured io has conflicting bindings: {detail}. "
                        f"A port name can only map to one Entry field. "
                        f"Use distinct port names if you need different fields for input and output."
                    )
                flat.update(outputs_raw)
            else:
                raise TypeError(
                    f"{self.__class__.__name__}: 'outputs' must be a dict "
                    f"for port-based binding, got {type(outputs_raw).__name__}."
                )
        self.bind_io(flat, strict=strict, require_all=require_all)
        return self

    def bind_io(self, io_map: Mapping[str, Any], *, strict: bool = True, require_all: bool = True) -> None:
        """Validate and store IO port-to-field mappings.

        Args:
            io_map: Mapping from port names to Entry field names.
            strict: Reject unknown port names if True.
            require_all: Require all mandatory ports to be mapped if True.

        Raises:
            ValueError: If validation fails (unknown ports, missing required ports).
        """
        if io_map is None:
            raise ValueError(f"{self.__class__.__name__} requires io_map.")
        mapping = dict(io_map)
        spec = self.io_spec if isinstance(self.io_spec, IOSpec) else IOSpec()
        # Enforce that only declared ports are mapped (when strict).
        if strict and (spec.all_inputs or spec.all_outputs):
            allowed = set(spec.all_inputs) | set(spec.all_outputs)
            unknown = [name for name in mapping.keys() if name not in allowed]
            if unknown:
                raise ValueError(
                    f"{self.__class__.__name__} io_map contains unknown variables: {sorted(unknown)}."
                )
        if require_all:
            required = set(spec.required_inputs) | set(spec.required_outputs)
            missing = [name for name in required if mapping.get(name) is None]
            if missing:
                raise ValueError(
                    f"{self.__class__.__name__} io_map is missing required variable(s): {sorted(missing)}."
                )
        # Resolve port names into concrete entry keys.
        resolved = self._resolve_vars(mapping, spec, require_all=require_all)
        # Guard: non-IOSpec ports must not shadow existing instance attributes.
        # (IOSpec ports are protected by _IOPort descriptors installed at class definition.)
        spec_ports = set(spec.all_inputs) | set(spec.all_outputs) if (spec.all_inputs or spec.all_outputs) else set()
        previous_ports = set(self._resolved_vars) if self._resolved_vars else set()
        for name in resolved:
            if name not in spec_ports and name not in previous_ports and hasattr(self, name):
                raise ValueError(
                    f"{self.__class__.__name__}: IO port '{name}' would overwrite "
                    f"existing attribute (current value: {getattr(self, name)!r}). "
                    f"Rename the port or the attribute to avoid collision."
                )
        self._io_map = mapping
        self._resolved_vars = resolved
        self._io_bound = True
        # Expose resolved keys as instance attributes for convenience.
        self._io_binding_in_progress = True
        try:
            for name, value in resolved.items():
                setattr(self, name, value)
        finally:
            self._io_binding_in_progress = False

    @property
    def io_map(self) -> Dict[str, Any]:
        """Return a copy of the raw io_map."""
        return dict(getattr(self, "_io_map", {}))

    @property
    def resolved(self) -> Dict[str, Any]:
        """Return a copy of the resolved port keys."""
        return dict(getattr(self, "_resolved_vars", {}))

    def has_mapping(self, name: str) -> bool:
        """True if a port is mapped to a concrete key."""
        if not getattr(self, "_io_bound", False):
            return False
        return self._resolved_vars.get(name) is not None

    def _resolve_vars(
        self,
        mapping: Dict[str, Any],
        spec: IOSpec,
        *,
        require_all: bool,
    ) -> Dict[str, Any]:
        resolved: Dict[str, Any] = {}
        # If the spec declares ports, enforce required/optional rules.
        if spec.all_inputs or spec.all_outputs:
            for name in list(spec.required_inputs) + list(spec.required_outputs):
                if name in resolved:
                    continue
                if name not in mapping or mapping[name] is None:
                    if require_all:
                        raise ValueError(
                            f"{self.__class__.__name__} io_map is missing required variable: '{name}'."
                        )
                    resolved[name] = None
                    continue
                value = mapping[name]
                if isinstance(value, (list, tuple)):
                    raise TypeError(
                        f"{self.__class__.__name__} io_map expects '{name}' to be a single key, got {value}."
                    )
                resolved[name] = value
            for name in list(spec.optional_inputs) + list(spec.optional_outputs):
                if name in resolved:
                    continue
                value = mapping.get(name)
                if value is None:
                    resolved[name] = None
                else:
                    if isinstance(value, (list, tuple)):
                        raise TypeError(
                            f"{self.__class__.__name__} io_map expects '{name}' to be a single key, got {value}."
                        )
                    resolved[name] = value
        else:
            # No declared ports: accept raw mapping as-is.
            for name, value in mapping.items():
                if isinstance(value, (list, tuple)):
                    raise TypeError(
                        f"{self.__class__.__name__} io_map expects '{name}' to be a single key, got {value}."
                    )
                resolved[name] = value
        return resolved

    def _port_key(self, name: str) -> Any:
        """Return the resolved entry key for a port name (or the name itself if unbound)."""
        if getattr(self, "_io_bound", False):
            return self._resolved_vars.get(name)
        return name
