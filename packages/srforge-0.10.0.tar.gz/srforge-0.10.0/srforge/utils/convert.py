from typing import Union, Any
import torch
import numpy as np

def to_torch_dtype(data_type: Union[str, np.dtype, torch.dtype]) -> torch.dtype:
    result = None
    if isinstance(data_type, torch.dtype):
        return data_type
    if isinstance(data_type, np.dtype):
        # Map NumPy dtypes to Torch dtypes
        result =  {
            np.float32: torch.float32,
            np.float64: torch.float64,
            np.float16: torch.float16,
            np.int32: torch.int32,
            np.int64: torch.int64,
            np.int16: torch.int16,
            np.uint16: torch.uint16,
            np.int8: torch.int8,
            np.uint8: torch.uint8,
            np.bool_: torch.bool,
            np.bool: torch.bool
        }.get(data_type, None)
    elif isinstance(data_type, str):
        # Map string representations of dtypes to Torch dtypes
        result = {
            "float32": torch.float32,
            "float64": torch.float64,
            "float16": torch.float16,
            "float": torch.float,
            'double': torch.double,
            "int32": torch.int32,
            "int64": torch.int64,
            "int16": torch.int16,
            "uint16": torch.uint16,
            "int8": torch.int8,
            "uint8": torch.uint8,
            "int": torch.int,
            "bool": torch.bool,
        }.get(data_type.lower(), None)

    if result is not None:
        return result
    else:
        raise ValueError(f"Unsupported data type: {data_type}")

def to_numpy(data: Any) -> Any:
    if isinstance(data, torch.Tensor):
        return data.detach().cpu().numpy()
    elif isinstance(data, dict):
        return {k: to_numpy(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [to_numpy(v) for v in data]
    return data