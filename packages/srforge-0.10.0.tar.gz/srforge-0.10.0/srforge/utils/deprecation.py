"""Tools for handling deprecated functions and classes."""
import sys
import logging
import inspect
import warnings
from functools import wraps

logger = logging.getLogger(__name__)

YELLOW = "\x1b[33m"
RESET = "\x1b[0m"

def _deprecated(old_name: str, new_name: str, new_func, name_map: dict[str, str]):
    """Factory for creating a deprecated function wrapper.

    This is a higher-order function that generates a decorator. The resulting
    decorator wraps a dummy function (with the old signature) and forwards calls
    to a new function, translating argument names along the way.

    Args:
        old_name (str): The name of the deprecated function (for warnings).
        new_name (str): The name of the new function (for warnings).
        new_func (callable): The new function to forward calls to.
        name_map (dict[str, str]): A mapping from old argument names to new
            argument names.

    Returns:
        callable: A decorator that can be applied to a function with the old
                  signature.
    """
    new_sig = inspect.signature(new_func)

    def decorator(old_like_func_with_signature):
        old_sig = inspect.signature(old_like_func_with_signature)

        @wraps(old_like_func_with_signature)
        def wrapper(*args, **kwargs):
            warnings.warn(
                f"{old_name} is deprecated; use {new_name} instead.",
                DeprecationWarning,
                stacklevel=2,
            )

            # Bind to the *old* signature so positionals map to old names.
            bound = old_sig.bind_partial(*args, **kwargs)
            bound.apply_defaults()

            # Translate old -> new names
            fwd_kwargs = {}
            for old_param, val in bound.arguments.items():
                mapped = name_map.get(old_param, old_param)  # default: same name
                if mapped in fwd_kwargs:
                    raise TypeError(
                        f"Conflicting arguments for {mapped!r} "
                        f"(did you pass both {old_param!r} and {mapped!r}?)"
                    )
                fwd_kwargs[mapped] = val

            # Filter out extraneous args not accepted by the new function
            accepted = set(new_sig.parameters)
            fwd_kwargs = {k: v for k, v in fwd_kwargs.items() if k in accepted}

            return new_func(**fwd_kwargs)

            # Note: we intentionally don’t pass args positionally to new_func,
            # to avoid mismatches if parameter order changed.

        # Expose the *old* signature to IDEs & help()
        wrapper.__signature__ = old_sig
        return wrapper

    return decorator

def deprecated_class(old_name: str, new_cls: type) -> type:
    """Create a deprecated class alias that warns on instantiation.

    This function creates a new class that inherits from `new_cls` but issues a
    `DeprecationWarning` when it's initialized. The alias will have the `old_name`
    and can be used with `isinstance` checks as if it were the new class.

    Args:
        old_name (str): The name for the new deprecated class alias.
        new_cls (type): The new, non-deprecated class to wrap.

    Returns:
        type: A new class type that serves as a deprecated alias for `new_cls`.
    """

    try:
        from srforge.transform import EntryTransform
    except Exception:
        EntryTransform = None

    if EntryTransform is not None and issubclass(new_cls, EntryTransform):
        class _Deprecated(new_cls):
            def __init__(self, *args, **kwargs):
                base_msg = f"{old_name} is deprecated; use {new_cls.__name__} instead."
                if sys.stderr.isatty():  # real terminal / emulated
                    msg = f"{YELLOW}[DEPRECATED] {base_msg}{RESET}"
                else:
                    msg = f"[DEPRECATED] {base_msg}"

                warnings.warn(msg, DeprecationWarning, stacklevel=2)
                super().__init__(*args, **kwargs)
    else:
        class _Deprecated(new_cls):
            def __init__(self, *args, **kwargs):
                base_msg = f"{old_name} is deprecated; use {new_cls.__name__} instead."
                if sys.stderr.isatty():  # real terminal / emulated
                    msg = f"{YELLOW}[DEPRECATED] {base_msg}{RESET}"
                else:
                    msg = f"[DEPRECATED] {base_msg}"

                warnings.warn(msg, DeprecationWarning, stacklevel=2)
                super().__init__(*args, **kwargs)
    _Deprecated.__name__ = old_name
    _Deprecated.__qualname__ = old_name
    _Deprecated.__doc__ = f"DEPRECATED: use {new_cls.__name__} instead."

    return _Deprecated
