"""Input/Output specification for models and transforms."""

from typing import Iterable, Tuple


class IOSpec:
    """Declares input and output ports for models and transforms.

    Defines which named fields a component requires or optionally accepts,
    and which fields it produces. Used for validation and automatic binding.

    Attributes:
        required_inputs: Input ports that must be provided.
        optional_inputs: Input ports that may be provided.
        required_outputs: Output ports that will be produced.
        optional_outputs: Output ports that may be produced.
    """
    def __init__(
        self,
        required_inputs: Iterable[str] = (),
        optional_inputs: Iterable[str] = (),
        required_outputs: Iterable[str] = (),
        optional_outputs: Iterable[str] = (),
    ) -> None:
        """Initialize IO specification.

        Args:
            required_inputs: Names of required input ports.
            optional_inputs: Names of optional input ports.
            required_outputs: Names of required output ports.
            optional_outputs: Names of optional output ports.

        Raises:
            TypeError: If port names are not strings.
            ValueError: If port names are invalid or duplicated.
        """
        self.required_inputs = tuple(required_inputs)
        self.optional_inputs = tuple(optional_inputs)
        self.required_outputs = tuple(required_outputs)
        self.optional_outputs = tuple(optional_outputs)
        self._validate()

    def _validate(self) -> None:
        for name in (
            self.required_inputs
            + self.optional_inputs
            + self.required_outputs
            + self.optional_outputs
        ):
            if not isinstance(name, str):
                raise TypeError(f"IOSpec names must be strings, got {type(name)}.")
            if not name:
                raise ValueError("IOSpec names must be non-empty.")

        if set(self.required_inputs) & set(self.optional_inputs):
            raise ValueError("IOSpec inputs cannot be both required and optional.")
        if set(self.required_outputs) & set(self.optional_outputs):
            raise ValueError("IOSpec outputs cannot be both required and optional.")

        if len(self.required_inputs) != len(set(self.required_inputs)):
            raise ValueError("IOSpec required_inputs must be unique.")
        if len(self.optional_inputs) != len(set(self.optional_inputs)):
            raise ValueError("IOSpec optional_inputs must be unique.")
        if len(self.required_outputs) != len(set(self.required_outputs)):
            raise ValueError("IOSpec required_outputs must be unique.")
        if len(self.optional_outputs) != len(set(self.optional_outputs)):
            raise ValueError("IOSpec optional_outputs must be unique.")

    @property
    def all_inputs(self) -> Tuple[str, ...]:
        """Get all input ports (required + optional).

        Returns:
            Tuple of all input port names.
        """
        return self.required_inputs + self.optional_inputs

    @property
    def all_outputs(self) -> Tuple[str, ...]:
        """Get all output ports (required + optional).

        Returns:
            Tuple of all output port names.
        """
        return self.required_outputs + self.optional_outputs

    def replace(
        self,
        *,
        required_inputs: Iterable[str] | None = None,
        optional_inputs: Iterable[str] | None = None,
        required_outputs: Iterable[str] | None = None,
        optional_outputs: Iterable[str] | None = None,
    ) -> "IOSpec":
        """Create a new IOSpec with modified ports.

        Args:
            required_inputs: New required inputs, or None to keep current.
            optional_inputs: New optional inputs, or None to keep current.
            required_outputs: New required outputs, or None to keep current.
            optional_outputs: New optional outputs, or None to keep current.

        Returns:
            New IOSpec instance with updated ports.
        """
        return IOSpec(
            required_inputs=required_inputs if required_inputs is not None else self.required_inputs,
            optional_inputs=optional_inputs if optional_inputs is not None else self.optional_inputs,
            required_outputs=required_outputs if required_outputs is not None else self.required_outputs,
            optional_outputs=optional_outputs if optional_outputs is not None else self.optional_outputs,
        )
