import inspect
from typing import Any
import torch

from srforge.utils.iospec import IOSpec
from srforge.utils.iomodule import IOModule


def is_image(obj: Any) -> bool:
    """
    Check if obj is an image tensor based on shape and type.
    """
    if not isinstance(obj, torch.Tensor):
        return False
    return len(obj.shape) == 3 and obj.shape[0] in [1, 3] and obj.shape[1] > 0 and obj.shape[2] > 0

def obj_to_str(obj: Any):
    """
    Dynamically generate class string representation based on __init__ arguments.
    """
    params = inspect.signature(obj.__init__).parameters
    param_strings = []

    for name, param in params.items():
        if name == 'self':
            continue  # Skip 'self'
        if hasattr(obj, name):
            value = getattr(obj, name)
        elif hasattr(obj, f'_{name}'):
            value = getattr(obj, f'_{name}')
        elif param.default is not inspect.Parameter.empty:
            value = param.default
        else:
            value = None  # Fallback if no value is found
        param_strings.append(f"{name}={repr(value)}")

    param_str = ", ".join(param_strings)
    return f"{obj.__class__.__name__}({param_str})"
