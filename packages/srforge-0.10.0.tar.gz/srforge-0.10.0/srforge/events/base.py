class Event:
    """Marker base class for all events."""
    pass
