from dataclasses import dataclass
from typing import Any

from .base import Event
from srforge.loss.storage import MetricScores


@dataclass(frozen=True)
class RunnerEpochStarted(Event):
    epoch: int
    dataset_size: int
    batch_size: int
    num_batches: int


@dataclass(frozen=True)
class RunnerBatchFinished(Event):
    epoch: int
    batch: int
    entry: Any
    batch_scores: MetricScores
    criterion: Any
    epoch_scores: MetricScores


@dataclass(frozen=True)
class RunnerEpochFinished(Event):
    epoch: int
    epoch_scores: MetricScores
