from dataclasses import dataclass
from typing import Any

from .base import Event
from srforge.loss import MetricScores
from srforge.models import Model


@dataclass(frozen=True)
class TrainingBegan(Event):
    total_epochs: int
    initial_epoch: int
    train_batches_per_epoch: int
    val_batches_per_epoch: int
    best_losses: dict | None = None


@dataclass(frozen=True)
class TrainerEpochFinished(Event):
    optimizer: Any
    lr_scheduler: Any
    model: Model
    train_loss: MetricScores
    val_loss: MetricScores
    epoch: int
    scaler: Any
