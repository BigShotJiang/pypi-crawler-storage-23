"""SR-Forge command-line interface."""

import argparse
import sys


def main():
    """Entry point for the ``srforge`` command."""
    parser = argparse.ArgumentParser(prog="srforge", description="SR-Forge CLI")
    sub = parser.add_subparsers(dest="command")

    init_parser = sub.add_parser("init", help="Scaffold a new training project")
    init_parser.add_argument(
        "--force", action="store_true", help="Overwrite existing files"
    )

    args = parser.parse_args()
    if args.command == "init":
        _init(args)
    else:
        parser.print_help()
        sys.exit(1)


def _init(args):
    """Generate train.py and configs/train-cfg.yaml in the current directory."""
    from importlib.resources import files
    from pathlib import Path

    scaffold = files("srforge.scaffold")

    file_map = {
        Path("train.py"): scaffold.joinpath("train.py").read_text(encoding="utf-8"),
        Path("configs") / "train-cfg.yaml": scaffold.joinpath("train-cfg.yaml").read_text(encoding="utf-8"),
    }

    for name, content in file_map.items():
        if name.exists() and not args.force:
            print(f"  skip  {name} (already exists, use --force to overwrite)")
            continue
        name.parent.mkdir(parents=True, exist_ok=True)
        name.write_text(content, encoding="utf-8")
        print(f"  create  {name}")

    print("\nDone. Edit configs/train-cfg.yaml, then run: python train.py")


if __name__ == "__main__":
    main()
