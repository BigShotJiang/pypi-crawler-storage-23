"""No-op experiment tracker for offline runs and testing."""

from __future__ import annotations

from typing import Any

import numpy as np

from srforge.registry import register_class
from .base import ExperimentTracker


@register_class
class NullTracker(ExperimentTracker):
    """No-op tracker. All methods silently do nothing."""

    @property
    def run_id(self) -> str | None:
        return None

    @property
    def run_name(self) -> str | None:
        return None

    @property
    def run_path(self) -> str | None:
        return None

    @property
    def is_resumed(self) -> bool:
        return False

    def log_metrics(self, metrics: dict, *, step: int) -> None:
        pass

    def log_image(self, key: str, image: np.ndarray, *, step: int) -> None:
        pass

    def set_summary(self, key: str, value: Any) -> None:
        pass

    def commit(self, *, step: int) -> None:
        pass

    def log_config(self, config: dict) -> None:
        pass

    def watch_model(self, model: Any, **kwargs) -> None:
        pass

    def save_file(self, path: str, *, base_path: str | None = None) -> None:
        pass

    def restore_file(self, filename: str) -> str:
        raise FileNotFoundError(
            f"NullTracker cannot restore files (requested: {filename})"
        )

    def restore_from_run(self, run_id: str, filename: str) -> str:
        raise FileNotFoundError(
            f"NullTracker cannot restore files from other runs "
            f"(requested: {filename} from run {run_id})"
        )

    def finish(self, exit_code: int = 0) -> None:
        pass
