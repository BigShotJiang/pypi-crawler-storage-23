"""Weights & Biases experiment tracker."""

from __future__ import annotations

from typing import Any

import numpy as np

from srforge.registry import register_class
from .base import ExperimentTracker


@register_class
class WandbTracker(ExperimentTracker):
    """Experiment tracker backed by Weights & Biases.

    Constructor parameters mirror ``wandb.init()`` arguments.
    """

    def __init__(
        self,
        *,
        project: str,
        entity: str | None = None,
        name: str | None = None,
        run_id: str | None = None,
        group: str | None = None,
        notes: str | None = None,
        tags: list[str] | None = None,
        job_type: str = "training",
        resume: str = "allow",
        mode: str = "online",
        dir: str | None = None,
        settings: Any = None,
    ):
        import wandb

        self._wandb = wandb
        self._wandb.init(
            project=project,
            entity=entity,
            name=name,
            id=run_id,
            group=group,
            notes=notes,
            tags=tags,
            job_type=job_type,
            resume=resume,
            mode=mode,
            dir=dir,
            settings=settings,
        )

    # --- Run info ---
    @property
    def run_id(self) -> str | None:
        run = self._wandb.run
        return run.id if run else None

    @property
    def run_name(self) -> str | None:
        run = self._wandb.run
        return run.name if run else None

    @property
    def run_path(self) -> str | None:
        run = self._wandb.run
        return run.path if run else None

    @property
    def is_resumed(self) -> bool:
        run = self._wandb.run
        return run.resumed if run else False

    # --- Logging ---
    def log_metrics(self, metrics: dict, *, step: int) -> None:
        self._wandb.log(metrics, step=step)

    def log_image(self, key: str, image: np.ndarray, *, step: int) -> None:
        self._wandb.log({key: self._wandb.Image(image)}, step=step)

    def set_summary(self, key: str, value: Any) -> None:
        self._wandb.run.summary[key] = value

    def commit(self, *, step: int) -> None:
        self._wandb.log({}, step=step, commit=True)

    # --- Config ---
    def log_config(self, config: dict) -> None:
        self._wandb.config.update(config)

    # --- Model monitoring ---
    def watch_model(self, model: Any, **kwargs) -> None:
        self._wandb.watch(model, **kwargs)

    # --- File management ---
    def save_file(self, path: str, *, base_path: str | None = None) -> None:
        self._wandb.save(path, base_path=base_path)

    def restore_file(self, filename: str) -> str:
        restored = self._wandb.run.restore(filename)
        if restored is None:
            raise FileNotFoundError(
                f"Could not restore '{filename}' from run {self.run_id}"
            )
        return restored.name

    def restore_from_run(self, run_id: str, filename: str) -> str:
        run = self._wandb.Api().run(
            f"{self._wandb.run.entity}/{self._wandb.run.project}/{run_id}"
        )
        downloaded = run.file(filename).download(replace=True)
        return downloaded.name

    # --- Lifecycle ---
    def finish(self, exit_code: int = 0) -> None:
        self._wandb.finish(exit_code)
