"""Abstract experiment tracking interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import numpy as np


class ExperimentTracker(ABC):
    """Abstract experiment tracking interface.

    Provides a backend-agnostic API for logging metrics, images,
    config, and managing run lifecycle.
    """

    # --- Run info ---
    @property
    @abstractmethod
    def run_id(self) -> str | None:
        """Unique identifier for the current run."""

    @property
    @abstractmethod
    def run_name(self) -> str | None:
        """Human-readable name for the current run."""

    @property
    @abstractmethod
    def run_path(self) -> str | None:
        """Full path/URL for the current run."""

    @property
    @abstractmethod
    def is_resumed(self) -> bool:
        """Whether the current run was resumed from a previous run."""

    # --- Logging ---
    @abstractmethod
    def log_metrics(self, metrics: dict, *, step: int) -> None:
        """Log a dictionary of scalar metrics at the given step."""

    @abstractmethod
    def log_image(self, key: str, image: np.ndarray, *, step: int) -> None:
        """Log a single image under *key* at the given step."""

    @abstractmethod
    def set_summary(self, key: str, value: Any) -> None:
        """Set a summary value (e.g. best loss, best epoch)."""

    @abstractmethod
    def commit(self, *, step: int) -> None:
        """Flush / commit all pending logs for the given step."""

    # --- Config ---
    @abstractmethod
    def log_config(self, config: dict) -> None:
        """Log the full experiment configuration."""

    # --- Model monitoring ---
    @abstractmethod
    def watch_model(self, model: Any, **kwargs) -> None:
        """Attach gradient / parameter tracking to a model."""

    # --- File management ---
    @abstractmethod
    def save_file(self, path: str, *, base_path: str | None = None) -> None:
        """Upload / persist a file artifact."""

    @abstractmethod
    def restore_file(self, filename: str) -> str:
        """Fetch a file from a previous run (resume scenario).

        Args:
            filename: Name of the file to restore.

        Returns:
            Local filesystem path to the restored file.

        Raises:
            FileNotFoundError: If the file cannot be restored.
        """

    @abstractmethod
    def restore_from_run(self, run_id: str, filename: str) -> str:
        """Fetch a file from a *different* run.

        Args:
            run_id: Identifier of the source run.
            filename: Name of the file to restore.

        Returns:
            Local filesystem path to the restored file.

        Raises:
            FileNotFoundError: If the file cannot be found.
        """

    # --- Lifecycle ---
    @abstractmethod
    def finish(self, exit_code: int = 0) -> None:
        """Finalize the run."""
