"""Configuration utilities."""

from srforge.config.resolver import ConfigResolver
from srforge.config.legacy import ConfigParser

__all__ = ["ConfigResolver", "ConfigParser"]
