"""Generic configuration resolution and object instantiation from OmegaConf."""

import importlib
import logging
import re
from typing import Any, Mapping, Union

from omegaconf import DictConfig, ListConfig, OmegaConf

from srforge.registry import ClassRegistry
from srforge.utils import IOModule

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# OmegaConf custom resolver: ${ref:path}
# ---------------------------------------------------------------------------
# YAML chokes on unquoted %{path} because '%' is a directive character.
# Registering a ``ref`` resolver lets users write ``${ref:path}`` (no quotes)
# — OmegaConf resolves it to the internal ``%{path}`` marker that
# ``_resolve_reference_string`` already handles.
#
# Usage in YAML::
#
#   optimizer: ${ref:optimizer}                      # simple reference
#   params: ${ref:model}.trainable_params()          # with method chain
#
try:
    OmegaConf.register_new_resolver("ref", lambda path: f"%{{{path}}}")
except ValueError:
    pass  # already registered (e.g. module reload)


class _Args(list):
    """List wrapper marking positional parameters during config resolution."""


class _Kwargs(dict):
    """Dict wrapper marking keyword parameters during config resolution."""


def _sanitize_params(value: Any) -> Any:
    """Convert internal _Args/_Kwargs to plain list/dict."""
    if isinstance(value, _Args):
        return [_sanitize_params(v) for v in value]
    if isinstance(value, _Kwargs):
        return {k: _sanitize_params(v) for k, v in value.items()}
    return value


class ConfigResolver:
    """Resolve OmegaConf configs into live Python objects.

    Config syntax::

        _target: module.ClassName   # or a ClassRegistry short name
        params:
            param1: value1
            param2: value2
        io:                         # optional, only for IOModule subclasses
            inputs: {port: field}
            outputs: field

    Reference syntax (preferred — no quoting needed in YAML)::

        ${ref:path.to.object}                # resolve a previously instantiated object
        ${ref:model}.method()                # resolve + call a no-arg method
        ${ref:model}.foo().bar()             # chained method calls

    Legacy syntax (requires YAML quoting)::

        "%{path.to.object}"                  # resolve a previously instantiated object
        "%{path.to.object}.method()"         # resolve + call a no-arg method
    """

    def __init__(self, config: Any) -> None:
        self.config = config
        self._instances: dict[str, Any] = {}
        self._resolving: set[str] = set()

    # ------------------------------------------------------------------
    # Config tree navigation
    # ------------------------------------------------------------------

    def _select_config_node(self, path: str) -> Any:
        """Select a config node by dotted path.

        Args:
            path: Dotted path (e.g., ``"model"`` or ``"optimizer.params"``).

        Returns:
            Config node at the given path.

        Raises:
            KeyError: If the path cannot be resolved.
        """
        if not path:
            raise KeyError("Empty config reference path.")
        path = self._normalize_path(path)
        current: Any = self.config
        for part in path.split("."):
            if isinstance(current, (DictConfig, Mapping)):
                if part not in current:
                    raise KeyError(f"Config path '{path}' not found.")
                current = current[part]
            elif isinstance(current, (list, tuple, ListConfig, _Args)):
                try:
                    idx = int(part)
                except ValueError as exc:
                    raise KeyError(f"Config path '{path}' not found.") from exc
                if idx < 0 or idx >= len(current):
                    raise KeyError(f"Config path '{path}' not found.")
                current = current[idx]
            else:
                raise KeyError(f"Config path '{path}' not found.")
        return current

    # ------------------------------------------------------------------
    # Reference resolution
    # ------------------------------------------------------------------

    @staticmethod
    def _normalize_path(path: str) -> str:
        """Normalize bracket notation to dot notation.

        ``items[0].name`` becomes ``items.0.name``, matching OmegaConf
        path conventions.
        """
        return re.sub(r'\[(\d+)\]', r'.\1', path).lstrip('.')

    def _resolve_path(self, path: str) -> Any:
        """Resolve a config path into an instantiated object.

        Args:
            path: Dotted path in the config (bracket notation accepted).

        Returns:
            Resolved object.

        Raises:
            ValueError: If a circular reference is detected.
        """
        path = self._normalize_path(path)
        if path in self._instances:
            return self._instances[path]
        if path in self._resolving:
            raise ValueError(f"Circular reference detected while resolving '{path}'.")
        self._resolving.add(path)
        node = self._select_config_node(path)
        value = self._load_class_from_config(node, path=path)
        self._instances[path] = value
        self._resolving.remove(path)
        return value

    _PRIMITIVE_TYPES = (str, int, float, bool, type(None))

    def _resolve_reference_string(self, value: str) -> Any:
        """Resolve an instance reference with optional method chains.

        Preferred syntax (via OmegaConf ``ref`` resolver — no YAML quoting)::

            ${ref:model}                         -> resolve "model"
            ${ref:model}.trainable_params()      -> resolve, then call method

        Legacy syntax (requires YAML quoting)::

            %{model}                             -> resolve "model"
            %{model}.trainable_params()          -> resolve, then call method

        Both forms produce the same internal ``%{path}`` string.

        Args:
            value: String to resolve.

        Returns:
            Resolved object if the string is a reference, otherwise the
            original string.

        Raises:
            TypeError: If the resolved value is a primitive.  Use ``${...}``
                (OmegaConf interpolation) for value references.
        """
        if not isinstance(value, str):
            return value
        match = re.fullmatch(
            r"%\{([^}]+)\}((?:\.\w+\(\))*)", value.strip(),
        )
        if not match:
            return value
        path = match.group(1).strip()
        method_chain = match.group(2)
        if not path:
            raise ValueError("Reference path cannot be empty.")
        result = self._resolve_path(path)
        if method_chain:
            for method_name in re.findall(r'\.(\w+)\(\)', method_chain):
                result = getattr(result, method_name)()
        if isinstance(result, self._PRIMITIVE_TYPES):
            ref_str = f"%{{{path}}}{method_chain}"
            raise TypeError(
                f"'{ref_str}' resolved to a {type(result).__name__} value. "
                f"Use ${{{path}}} for value interpolation."
            )
        return result

    # ------------------------------------------------------------------
    # Recursive instantiation
    # ------------------------------------------------------------------

    def _load_class_from_config(
        self,
        config: Any,
        *args: Any,
        path: str | None = None,
        **kwargs: Any,
    ) -> Any:
        """Recursively instantiate objects from config.

        Args:
            config: Config node to parse.
            *args: Positional args to pass through.
            path: Optional dotted path for instance caching.
            **kwargs: Keyword args to pass through.

        Returns:
            Instantiated object or parsed value.

        Raises:
            ModuleNotFoundError: If the target module cannot be imported.
            AttributeError: If the target class is missing.
            TypeError: If io bindings are provided for a non-IOModule target.
        """
        if path is not None and path in self._instances:
            return self._instances[path]

        if isinstance(config, str):
            return self._resolve_reference_string(config)

        if isinstance(config, (DictConfig, _Kwargs)):
            if '_target' in config:
                return self._instantiate_target(config, *args, path=path, **kwargs)

            params = _Kwargs()
            for key, subconfig in config.items():
                params[key] = self._load_class_from_config(
                    subconfig,
                    path=f"{path}.{key}" if path else None,
                )
            return params

        if isinstance(config, (ListConfig, _Args)):
            params = _Args()
            for idx, subconfig in enumerate(config):
                params.append(
                    self._load_class_from_config(
                        subconfig,
                        path=f"{path}.{idx}" if path else None,
                    )
                )
            return params

        return config

    def _instantiate_target(
        self,
        config: Any,
        *args: Any,
        path: str | None = None,
        **kwargs: Any,
    ) -> Any:
        """Instantiate a single ``_target`` config node.

        Separated from :meth:`_load_class_from_config` for readability.
        """
        _target = config['_target']
        if _target in ClassRegistry():
            module, class_name = ClassRegistry().get(_target)
        else:
            module = '.'.join(_target.split('.')[:-1])
            class_name = _target.split('.')[-1]

        if module in (None, '') or class_name in (None, ''):
            raise ValueError(
                f"Module and class name must be provided in the configuration "
                f"file for the key '_target' or the class must be registered "
                f"in the ClassRegistry. Got {_target}"
            )

        kwargs_params = _Kwargs()
        args_params = _Args()
        io_cfg = config.get("io") if isinstance(config, Mapping) else None

        if 'params' in config and config['params'] is not None:
            params = self._load_class_from_config(
                config['params'],
                path=f"{path}.params" if path else None,
            )
            if isinstance(params, _Args):
                args_params.append(_Args(list(params)))
            elif isinstance(params, _Kwargs):
                kwargs_params = params

        try:
            imported_module = importlib.import_module(module)
        except ModuleNotFoundError:
            logger.critical(
                f"Trying to import module '{module}' for class '{class_name}' failed."
            )
            raise

        try:
            cls = getattr(imported_module, class_name)
        except AttributeError:
            logger.critical(
                f"Module '{module}' does not have a class '{class_name}'."
            )
            raise

        clean_args = [_sanitize_params(a) for a in args_params]
        clean_kwargs = {k: _sanitize_params(v) for k, v in kwargs_params.items()}

        try:
            instance = cls(*args, *clean_args, **kwargs, **clean_kwargs)
        except Exception:
            logger.critical(
                f"Could not instantiate class '{class_name}' from module "
                f"'{module}' with parameters:\n"
                f"args: {args}\nkwargs: {kwargs}\n"
                f"args_params: {args_params}\nkwargs_params: {kwargs_params}."
            )
            raise

        if io_cfg is not None:
            if isinstance(instance, IOModule):
                instance.set_io(io_cfg)
            else:
                raise TypeError(
                    f"{cls.__name__} does not support io bindings "
                    f"but config provided 'io'."
                )

        if path is not None:
            self._instances[path] = instance
        return instance

    # ------------------------------------------------------------------
    # OmegaConf path detection
    # ------------------------------------------------------------------

    def _find_config_path(self, node: Any) -> str | None:
        """Determine the dotted config path of *node* within this resolver's config.

        Walks the OmegaConf parent chain from *node* up to ``self.config``.
        Returns ``None`` when *node* is not part of the config tree.
        """
        if not isinstance(node, (DictConfig, ListConfig)):
            return None
        parts: list[str] = []
        current = node
        while current is not self.config:
            key = current._key()
            if key is None:
                return None
            parts.append(str(key))
            parent = current._get_parent()
            if parent is None:
                return None
            current = parent
        parts.reverse()
        return ".".join(parts) if parts else None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def resolve_all(self) -> dict[str, Any]:
        """Resolve all top-level config fields.

        Returns:
            Mapping of top-level keys to resolved objects.
        """
        resolved: dict[str, Any] = {}
        if isinstance(self.config, (DictConfig, Mapping)):
            for key in list(self.config.keys()):
                resolved[key] = self._resolve_path(key)
        return resolved

    def __call__(self, config: Any, *args: Any, **kwargs: Any) -> Any:
        """Parse and instantiate a config node.

        Automatically registers the result in ``_instances`` when *config*
        is a node from this resolver's config tree, so ``${ref:path}``
        references resolve without manual bookkeeping.

        Args:
            config: Config node to parse.
            *args: Positional args to forward to the constructor.
            **kwargs: Keyword args to forward to the constructor.

        Returns:
            Parsed object.
        """
        path = self._find_config_path(config)
        return self._load_class_from_config(config, *args, path=path, **kwargs)
