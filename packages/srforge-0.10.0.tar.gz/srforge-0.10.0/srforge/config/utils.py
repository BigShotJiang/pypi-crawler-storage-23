import omegaconf

def clear_defaults(cfg: omegaconf.DictConfig) -> omegaconf.DictConfig:
    """Remove config keys that start with an underscore.

    Args:
        cfg (omegaconf.DictConfig): Config to clean in-place.

    Returns:
        omegaconf.DictConfig: The same config with underscore keys removed.
    """
    with omegaconf.open_dict(cfg):
        for k in list(cfg.keys()):
            if k.startswith('_'):
                del cfg[k]
    return cfg
