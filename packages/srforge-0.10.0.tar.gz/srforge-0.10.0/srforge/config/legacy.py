"""Training-specific configuration parsing with W&B resume support.

.. deprecated::
    Use :class:`~srforge.config.resolver.ConfigResolver` instead.
    ``ConfigParser`` will be removed in a future release.
"""

import logging
import os
import warnings
from typing import Any, Union

from omegaconf import DictConfig, ListConfig

from srforge.config.resolver import ConfigResolver
from srforge.training.schedule import BlankLRScheduler

import torch
from srforge.models import SequentialModel, Model

logger = logging.getLogger(__name__)
CONFIG_TYPE = DictConfig


class ConfigParser(ConfigResolver):
    """Config resolver with training-specific lifecycle methods.

    .. deprecated::
        Use :class:`~srforge.config.resolver.ConfigResolver` for generic
        config resolution. ``ConfigParser`` will be removed in a future release.

    Extends :class:`ConfigResolver` with model/optimizer/scheduler
    instantiation, W&B checkpoint loading, and training resume support.

    Args:
        config: Root configuration object.
        run: W&B run handle.
    """

    def __init__(self, config: CONFIG_TYPE, run: 'wandb_sdk.wandb_run.Run') -> None:
        warnings.warn(
            "ConfigParser is deprecated. Use ConfigResolver for generic config "
            "resolution.",
            DeprecationWarning,
            stacklevel=2,
        )
        super().__init__(config)
        self.__model = None
        self.__optimizer = None
        self.__lr_scheduler = None
        self.__checkpoint: Any = None
        self._run = run

    # ------------------------------------------------------------------
    # Lazy properties
    # ------------------------------------------------------------------

    @property
    def _model(self) -> 'torch.nn.Module':
        """Return the instantiated model (lazy)."""
        if self.__model is None:
            self.get_model()
        return self.__model

    @property
    def _optimizer(self) -> 'torch.optim.Optimizer':
        """Return the instantiated optimizer (lazy)."""
        if self.__optimizer is None:
            self.get_optimizer()
        return self.__optimizer

    @property
    def _lr_scheduler(self) -> 'torch.optim.lr_scheduler.LRScheduler':
        """Return the instantiated scheduler (lazy)."""
        if self.__lr_scheduler is None:
            self.get_lr_scheduler()
        return self.__lr_scheduler

    # ------------------------------------------------------------------
    # Checkpoint / W&B resume
    # ------------------------------------------------------------------

    def __get_stored_file(self, file: str) -> Any:
        """Restore a file from W&B and load it with torch.

        Args:
            file: File name to restore.

        Returns:
            Loaded object from the restored file.
        """
        import wandb
        file = wandb.run.restore(file).name
        loaded_file = torch.load(file, map_location='cpu')
        os.remove(file)
        return loaded_file

    @property
    def _checkpoint(self):
        """Return cached checkpoint contents if available."""
        if self.__checkpoint is None:
            checkpoint_files = ['checkpoint_last.pth', 'model_last.pth', 'model.pth']

            for checkpoint in checkpoint_files:
                try:
                    self.__checkpoint = self.__get_stored_file(checkpoint)
                    logger.info(f"Loaded checkpoint '{checkpoint}' for run {self._run.id}.")
                    return self.__checkpoint
                except Exception:
                    logger.warning(f"Could not load checkpoint '{checkpoint}' for run {self._run.id}.")
            logger.critical(f"Could not load any checkpoint for run {self._run.id}.")
        return self.__checkpoint

    # ------------------------------------------------------------------
    # Training lifecycle
    # ------------------------------------------------------------------

    @staticmethod
    def __dict_to_params_list(config: Union[ListConfig[CONFIG_TYPE], CONFIG_TYPE]) -> Union[ListConfig, CONFIG_TYPE]:
        """Normalize a config object into a list wrapper.

        Args:
            config: Config to normalize.

        Returns:
            The normalized config.
        """
        if isinstance(config, DictConfig):
            return ListConfig([config])
        return config

    def get_model(self) -> 'torch.nn.Module':
        """Instantiate the model defined in the config.

        Returns:
            Instantiated model.

        Raises:
            FileNotFoundError: If requested resume weights are missing.
        """
        config = self.config.model
        self.__dict_to_params_list(config)
        self.__model = self._load_class_from_config(config)
        self._instances.setdefault("model", self.__model)
        logger.info(f'Model initialized: {self.__model}')
        if hasattr(self._run, 'resumed') and self._run.resumed:
            if isinstance(self.__model, SequentialModel):
                raise NotImplementedError("Resuming training for Sequential models is not supported yet.")
            else:
                model_weights = self.__get_stored_file(f'{self._model.name}_last.pth')
                if model_weights is not None:
                    self._model.load_state_dict(model_weights)
                else:
                    raise FileNotFoundError(f"Could not find model weights for {self._model.name}.")
            logger.info("Loaded model weights from the last checkpoint.")
        return self._model

    def get_optimizer(self) -> 'torch.optim.Optimizer':
        """Instantiate the optimizer defined in the config.

        The optimizer's ``params`` (model parameters) should be declared
        in the config via ``%{model}.trainable_params()`` or
        ``%{model}.parameters()``.

        Returns:
            Instantiated optimizer.
        """
        config = self.config.optimizer
        self.__optimizer = self._load_class_from_config(config, path="optimizer")
        logger.info(f'Optimizer initialized: {self.__optimizer}')
        if self._run.resumed:
            self.__optimizer.load_state_dict(self._checkpoint['optimizer'])
            logger.info("Loaded optimizer state from checkpoint.")
        return self._optimizer

    def get_lr_scheduler(self) -> 'torch.optim.lr_scheduler.LRScheduler':
        """Instantiate the learning rate scheduler defined in the config.

        The scheduler's ``optimizer`` should be declared in the config
        via ``%{optimizer}``.  When no scheduler config is provided,
        a :class:`BlankLRScheduler` is used.

        Returns:
            Instantiated scheduler.
        """
        config = self.config.lr_scheduler
        if config is None:
            self.__lr_scheduler = BlankLRScheduler(self._optimizer)
            self._instances.setdefault("lr_scheduler", self.__lr_scheduler)
            return self._lr_scheduler

        self.__lr_scheduler = self._load_class_from_config(config, path="lr_scheduler")
        logger.debug(f'LR Scheduler initialized: {self.__lr_scheduler}')
        if self._run.resumed:
            if 'lr_scheduler' in self._checkpoint:
                self.__lr_scheduler.load_state_dict(self._checkpoint['lr_scheduler'])
                logger.debug("Loaded lr scheduler state from checkpoint.")
            else:
                logger.warning("Could not find lr scheduler state in checkpoint.")
        return self._lr_scheduler

    def get_training_data(self) -> tuple:
        """Return resume-related training metadata.

        Returns:
            tuple[int, Any]: Initial epoch and best losses (if resuming).
        """
        initial_epoch = 0
        best_losses = None
        if self._run.resumed:
            initial_epoch = self._run.summary.get('epoch') + 1
            best_losses = self._run.summary.get('best_losses')
        return initial_epoch, best_losses
