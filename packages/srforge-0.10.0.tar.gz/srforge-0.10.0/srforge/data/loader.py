from typing import Union
from omegaconf import ListConfig
import logging
from torch.utils.data import DataLoader
try:
    import torch_geometric as tg
except ImportError:
    tg = None

from srforge.data.collation import GeneralCollation
from srforge.data import Entry, GraphEntry
from srforge.dataset import Dataset

logger = logging.getLogger(__name__)

class DataLoaderFactory:
    """A factory for creating PyTorch DataLoader instances.

    This factory inspects the dataset type (`Entry` or `GraphEntry`) and the
    training environment (single-GPU or multi-GPU) to select the most
    appropriate DataLoader from PyTorch or PyTorch Geometric.
    """
    def __init__(self, dataset: Dataset, batch_size: int = 32, shuffle: bool = True,
                 device:Union[str, list] ='cuda:0', **kwargs):
        """Initializes the DataLoaderFactory.

        Args:
            dataset (Dataset): The dataset to be loaded.
            batch_size (int, optional): The number of samples per batch.
                Defaults to 32.
            shuffle (bool, optional): Whether to shuffle the data at every epoch.
                Defaults to True.
            device (Union[str, list], optional): The device(s) for training.
                If a list of device IDs is provided, multi-GPU loaders are
                configured. Defaults to 'cuda:0'.
            **kwargs (Any): Additional keyword arguments to be passed to the underlying
                DataLoader constructor.
        """
        self.dataset: Dataset = dataset
        self.batch_size: int = batch_size
        self.shuffle: bool = shuffle
        self.kwargs = kwargs
        self.device: Union[str, list] = device
        self.multi_gpu = isinstance(device, (list, tuple, ListConfig)) and len(device) > 1

    def get_loader(self) -> DataLoader:
        """Builds and returns the appropriate DataLoader.

        Selects a loader based on the dataset's item type and device settings:
        - `torch.utils.data.DataLoader`: For `Entry` types on single/multi-GPU.
        - `torch_geometric.loader.DataLoader`: For `GraphEntry` on single-GPU.
        - `torch_geometric.loader.DataListLoader`: For `GraphEntry` on multi-GPU.

        Returns:
            DataLoader: The configured DataLoader instance.

        Raises:
            TypeError: If the dataset's item type is not supported.
        """
        first_item = self.dataset[0]
        if not self.multi_gpu:  # Single-GPU training
            if isinstance(first_item, Entry):
                # Traditional DataLoader for tensor-based entries.
                loader = DataLoader(
                    self.dataset,
                    batch_size=self.batch_size,
                    shuffle=self.shuffle,
                    collate_fn=GeneralCollation(),
                    **self.kwargs
                )
                logger.info(f"Using PyTorch DataLoader for single-GPU training with batch size {self.batch_size}.")
            elif isinstance(first_item, GraphEntry):
                # Use torch_geometric's DataLoader for graph data.
                loader = tg.loader.DataLoader(
                    self.dataset,
                    batch_size=self.batch_size,
                    shuffle=self.shuffle,
                    **self.kwargs
                )
                logger.info(f"Using torch_geometric DataLoader for single-GPU training with batch size {self.batch_size}.")
            else:
                raise TypeError(f"Dataset type {type(first_item)} not supported.")
        else:  # Multi-GPU training
            if isinstance(first_item, Entry):
                # Use DataListLoader for multi-GPU training with tensor-based entries.
                loader = DataLoader(
                    self.dataset,
                    batch_size=self.batch_size,
                    shuffle=self.shuffle,
                    collate_fn=GeneralCollation(),
                    **self.kwargs
                )
                logger.info(f"Using PyTorch DataLoader for multi-GPU training with batch size {self.batch_size}.")
            elif isinstance(first_item, GraphEntry):
                # Use torch_geometric's DataListLoader for multi-GPU training with graph data.
                loader = tg.loader.DataListLoader(
                    dataset=self.dataset,
                    batch_size=self.batch_size,
                    shuffle=self.shuffle,
                    **self.kwargs
                )
                logger.info(f"Using torch_geometric DataListLoader for multi-GPU training with batch size {self.batch_size}.")
            else:
                raise TypeError(f"Dataset type {type(first_item)} not supported.")

        return loader