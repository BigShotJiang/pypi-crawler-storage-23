"""Tools and descriptors for handling multispectral satellite imagery."""
