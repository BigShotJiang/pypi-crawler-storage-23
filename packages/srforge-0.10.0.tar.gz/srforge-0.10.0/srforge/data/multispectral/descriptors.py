import abc
from typing import List, Dict, Tuple

from srforge.registry import register_class


class MultiSpectralDescriptor(abc.ABC):
    """
    Base class for *static* descriptors for multispectral imagery data. Subclasses MUST override
    all of these class getters to provide the necessary metadata for the specific sensor or dataset.
    """

    @classmethod
    @abc.abstractmethod
    def bands(cls) -> List[str]:
        """Returns a list of all band names for the sensor.

        Returns:
            List[str]: A list of band names, e.g., `['b1', 'b2', 'b3']`.
        """
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def band_indices(cls) -> Dict[str,int]:
        """Gets a dictionary mapping band names to their integer indices.

        This is useful for selecting specific bands from a tensor by name.

        Returns:
            Dict[str, int]: A dictionary where keys are band names and values
                are their corresponding zero-based indices.
        """
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def gsd(cls) -> Dict[str,float]:
        """Gets the Ground Sample Distance (GSD) for each band.

        Returns:
            Dict[str, float]: A dictionary mapping band names to their GSD in
                meters.
        """
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def wavelengths(cls) -> Dict[str,Tuple[float,float]]:
        """Gets the wavelength range for each band.

        Returns:
            Dict[str, Tuple[float, float]]: A dictionary mapping band names
                to a (min, max) tuple of their wavelength range in nanometers.
        """
        raise NotImplementedError

    @classmethod
    @abc.abstractmethod
    def bit_depth(cls) -> int:
        """Gets the radiometric resolution (bit depth) of the sensor.

        Returns:
            int: The bit depth of the sensor data (e.g., 12 for 12-bit data).
        """
        raise NotImplementedError

    @classmethod
    def gsd_groups(cls) -> Dict[float, List[str]]:
        """Groups bands by their Ground Sample Distance (GSD).

        This is a convenience method that inverts the `gsd` mapping.

        Returns:
            Dict[float, List[str]]: A dictionary where keys are GSD values (in
                meters) and values are lists of band names sharing that GSD.
        """
        groups = {}
        for band, gsd in cls.gsd().items():
            if gsd not in groups:
                groups[gsd] = []
            groups[gsd].append(band)
        return groups

    def __repr__(self):
        """Return a concise string representation including name and band count."""
        return (
            f"<{self.__class__.__name__}"
            f" name={self.name!r}"
            f" bands={len(self.bands())}>"
        )

@register_class
class Sentinel2Descriptor(MultiSpectralDescriptor):
    """Descriptor for the Sentinel-2 MSI sensor."""
    # metadata
    @classmethod
    def name(cls) -> str:
        """Returns the official name of the sensor."""
        return "Sentinel-2 MSI"

    @classmethod
    def description(cls) -> str:
        """Returns a brief description of the sensor."""
        return "Sentinel-2 MultiSpectral Instrument (MSI) L1C/L2A: 13 bands"

    @classmethod
    def bands(cls) -> List[str]:
        """Returns the list of all band names for Sentinel-2."""
        return ["b1","b2","b3","b4","b5","b6","b7","b8","b8a","b9","b10","b11","b12"]

    @classmethod
    def band_indices(cls) -> Dict[str,int]:
        """Returns a mapping of band names to their integer indices."""
        bands = cls.bands()
        return {b: i for i, b in enumerate(bands)}


    @classmethod
    def gsd(cls) -> Dict[str,float]:
        """Returns the Ground Sample Distance (GSD) in meters for each band."""
        gsd = {
        **{b: 10.0 for b in ["b2","b3","b4","b8"]},
        **{b: 20.0 for b in ["b5","b6","b7","b8a","b11","b12"]},
        **{b: 60.0 for b in ["b1","b9","b10"]},
        }
        return gsd
    @classmethod
    def wavelengths(cls) -> Dict[str,Tuple[float,float]]:
        """Returns the wavelength range in nanometers for each band."""
        return {
        "b1":  (433.0, 453.0),
        "b2":  (457.5, 522.5),
        "b3":  (542.5, 577.5),
        "b4":  (650.0, 680.0),
        "b5":  (697.5, 712.5),
        "b6":  (732.5, 747.5),
        "b7":  (773.0, 793.0),
        "b8":  (784.5, 899.5),
        "b8a": (855.0, 875.0),
        "b9":  (935.0, 955.0),
        "b10": (1360.0, 1390.0),
        "b11": (1515.0, 1650.0),
        "b12": (2100.0, 2280.0),
    }

    @classmethod
    def bit_depth(cls) -> int:
        """Returns the radiometric resolution (bit depth) for the sensor."""
        # Sentinel-2 L1C products are 12-bit, L2A products can be 14-bit.
        # Here we assume the maximum bit depth for L2A.
        return 2**14 - 1


@register_class
class Sentinel1SARDescriptor(MultiSpectralDescriptor):
    """Descriptor for the Sentinel-1 C-band SAR sensor."""
    @classmethod
    def name(cls) -> str:
        """Returns the official name of the sensor."""
        return "Sentinel‑1 C‑band SAR"
    @classmethod
    def description(cls) -> str:
        """Returns a brief description of the sensor."""
        return ("Sentinel‑1 C‑band Synthetic Aperture Radar (SAR), "
                "typical spatial resolution ~5m")
    @classmethod
    def bands(cls) -> List[str]:
        """Returns the list of available polarimetric channels."""
        # Polarimetric channels available
        return ["VV", "VH", "HH", "HV"]
    @classmethod
    def band_indices(cls) -> Dict[str,int]:
        """Returns a mapping of band names to their integer indices."""
        return {b: i for i, b in enumerate(cls.bands())}
    @classmethod
    def gsd(cls) -> Dict[str,float]:
        """Returns the typical Ground Sample Distance (GSD) in meters."""
        # C‑band SAR typical ground sampling distance in meters
        return {b: 5.0 for b in cls.bands()}
    @classmethod
    def wavelengths(cls) -> Dict[str, Tuple[float, float]]:
        """Returns the wavelength for the C-band sensor."""
        # Sentinel‑1 is a single C‑band sensor at ≈5.5cm wavelength
        wl = 0.055  # in meters
        return {b: (wl, wl) for b in cls.bands()}
    @classmethod
    def bit_depth(cls) -> int:
        """Returns the typical bit depth for the stored data."""
        # Typically stored in a 32‑bit floating point format
        return 16