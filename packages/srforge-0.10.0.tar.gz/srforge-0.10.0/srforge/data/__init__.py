"""
Core data structures for the sr-forge framework.

This package defines the fundamental data containers, `Entry` and `GraphEntry`,
which are used throughout the data processing and model pipelines.
"""
from .entry import (
    Entry,
    GraphEntry,
    _DynamicStorage,
    _HAS_PYG,
    send
)

__all__ = [
    "Entry",
    "GraphEntry",
    "_DynamicStorage",
    "_HAS_PYG",
    "send"
]
