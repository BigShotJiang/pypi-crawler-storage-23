import logging
from abc import ABC
from typing import Any, Union, Dict, List, Tuple, Set, Mapping, Optional

import torch
from torch import Tensor
try:
    from torch_geometric.data import Data as _PyGData
    _HAS_PYG = True
except ImportError:
    _PyGData = None
    _HAS_PYG = False
from .collation import GeneralCollation

logger = logging.getLogger(__name__)

def send(data: Any, device: torch.device) -> Any:
    """Recursively moves data to a specified PyTorch device.

    This function traverses nested data structures (lists, tuples, dicts, sets)
    and moves any found `torch.Tensor` to the target device. It also supports
    objects with a custom `.to()` method, like `torch_geometric.data.Data`
    or the `Entry` class itself.

    Args:
        data (Any): The data to move. Can be a tensor or a nested structure
            containing tensors.
        device (torch.device): The target device.

    Returns:
        Any: A copy of the data structure with all tensors moved to the
             specified device.
    """
    # 1. Base case: It's a Tensor -> move it
    if isinstance(data, torch.Tensor):
        return data.to(device)

    # 2. Dictionary: Recursively apply to values
    elif isinstance(data, dict):
        return {k: send(v, device) for k, v in data.items()}

    # 3. List: Recursively apply to elements
    elif isinstance(data, list):
        return [send(v, device) for v in data]

    # 4. Tuple: Recursively apply and reconstruct tuple (tuples are immutable)
    elif isinstance(data, tuple):
        return tuple(send(v, device) for v in data)

    # 5. Set: Recursively apply (rare for tensors due to hashing, but supported)
    elif isinstance(data, set):
        return {send(v, device) for v in data}

    # 6. Advanced: If object has a custom .to() method (e.g. PyG Data object or SR-Forge Entry)
    elif hasattr(data, 'to') and callable(data.to):
        return data.to(device)

    # 7. Fallback: Return None, int, float, str, etc. as is
    return data

def to_numpy(data: Any) -> Any:
    """Recursively converts tensors to numpy arrays.

    This function traverses nested data structures (lists, tuples, dicts, sets)
    and converts any found ``torch.Tensor`` to a numpy array via
    ``.detach().cpu().numpy()``.

    Args:
        data (Any): The data to convert. Can be a tensor or a nested structure
            containing tensors.

    Returns:
        Any: A copy of the data structure with all tensors converted to numpy
             arrays. Non-tensor values are returned as-is.
    """
    if isinstance(data, torch.Tensor):
        return data.detach().cpu().numpy()

    elif isinstance(data, dict):
        return {k: to_numpy(v) for k, v in data.items()}

    elif isinstance(data, list):
        return [to_numpy(v) for v in data]

    elif isinstance(data, tuple):
        return tuple(to_numpy(v) for v in data)

    elif isinstance(data, set):
        return {to_numpy(v) for v in data}

    return data

def _entry_keys(entry: Any) -> set:
    """Safely get the keys from an entry-like object.

    Tries to get keys using `entry.keys()` (for dicts or Entry), falls
    back to `entry.__dict__.keys()` for general objects.

    Args:
        entry (Any): The object from which to get keys.

    Returns:
        set: A set of keys found on the object. Returns an empty set if
             no keys can be found.
    """
    if isinstance(entry, Entry):
        return set(entry.keys())
    if hasattr(entry, "keys"):
        try:
            return set(entry.keys())
        except Exception:
            pass
    if hasattr(entry, "__dict__"):
        return set(entry.__dict__.keys())
    return set()

def _merge_fields(entry: Any, fields: Mapping[str, Any], *, source: Optional[str] = None, allow_overwrite: bool = False) -> Any:
    """Safely merges a dictionary of fields into an entry-like object.

    This function modifies the entry object in-place. It can handle `Entry`
    objects, dictionaries, or general objects, setting attributes on them.
    It includes a check to prevent accidentally overwriting existing fields.

    Args:
        entry (Any): The entry object to modify.
        fields (Mapping[str, Any]): A dictionary of fields to merge into the entry.
        source (Optional[str], optional): The name of the calling function, used
            for clearer error messages. Defaults to None.
        allow_overwrite (bool, optional): If False, raises a `KeyError` if `fields`
            contains keys that already exist in `entry`. Defaults to False.

    Returns:
        Any: The modified entry object.

    Raises:
        TypeError: If `fields` is not a dictionary or mapping.
        KeyError: If `allow_overwrite` is False and a field conflict occurs.
    """
    if fields is None:
        return entry
    if not isinstance(fields, Mapping):
        origin = source or "_merge_fields"
        raise TypeError(f"{origin} fields must be a mapping, got {type(fields)}.")
    if not allow_overwrite:
        overlap = _entry_keys(entry) & set(fields.keys())
        if overlap:
            name = getattr(entry, "name", None)
            name_msg = f" (entry='{name}')" if name is not None else ""
            origin = source or "_merge_fields"
            raise KeyError(
                f"{origin} attempted to overwrite existing entry fields{name_msg}: {sorted(overlap)}"
            )
    if isinstance(entry, Entry):
        for k, v in fields.items():
            entry[k] = v
        return entry
    if isinstance(entry, dict):
        for k, v in fields.items():
            entry[k] = v
        return entry
    for k, v in fields.items():
        setattr(entry, k, v)
    return entry

class _DynamicStorage(ABC, dict):
    """A dictionary-like storage class with attribute-style access.

    This class acts as a base for `Entry`. It inherits from `dict` but
    overrides attribute access methods (`__getattr__`, `__setattr__`) to allow
    accessing dictionary keys as if they were object attributes.

    Internal attributes (those starting with '_') are handled by the standard
    `object` methods and are not stored in the dictionary.
    """
    def __init__(self, *args, **kwargs):
        """Initializes the storage.

        Accepts arguments in the same way as `dict()`.

        Args:
            *args: Variable length argument list, passed to `dict`.
            **kwargs: Arbitrary keyword arguments, passed to `dict`.
        """
        # Instead of calling dict.__init__ (which bypasses __setitem__),
        # we update self by iterating through args and kwargs.
        super().__init__()
        for arg in args:
            # If arg is a dict or has an items() method,
            # iterate over its items.
            if hasattr(arg, 'items'):
                for key, value in arg.items():
                    self[key] = value
            else:
                # Otherwise, assume it's an iterable of (key, value) pairs.
                for key, value in arg:
                    self[key] = value
        for key, value in kwargs.items():
            self[key] = value

    def __getattr__(self, key: Any) -> Any:
        try:
            return self[key]
        except KeyError:
            raise AttributeError(
                f"Trying to access non-existing attribute '{key}' in {self.__class__.__name__} object."
            )

    def __setattr__(self, key: Any, value: Any):
        # Store public fields in the underlying mapping; keep internal attrs on __dict__.
        if str(key).startswith("_"):
            object.__setattr__(self, key, value)
            return
        self.__setitem__(key, value)

    def __delattr__(self, key: Any):
        if str(key).startswith("_"):
            try:
                object.__delattr__(self, key)
            except AttributeError:
                raise AttributeError(
                    f"Trying to delete non-existing attribute '{key}' in {self.__class__.__name__} object."
                )
            return
        try:
            self.__delitem__(key)
        except KeyError:
            raise AttributeError(
                f"Trying to delete non-existing attribute '{key}' in {self.__class__.__name__} object."
            )

    def __getitem__(self, item: Any) -> Any:
        return dict.__getitem__(self, item)

    def __setitem__(self, key: Any, value: Any):
        dict.__setitem__(self, key, value)

    def __delitem__(self, key: Any):
        dict.__delitem__(self, key)

    def keys(self) -> List[str]:
        """Returns a list of all keys in the storage."""
        return list(dict.keys(self))

    def values(self) -> List[Any]:
        """Returns a list of all values in the storage."""
        return list(dict.values(self))

    def items(self) -> List[tuple]:
        """Returns a list of all (key, value) pairs."""
        return list(dict.items(self))

    def __repr__(self) -> str:
        out_str = f'{self.__class__.__name__}('
        for key, val in self.items():
            if val is None:
                continue
            if isinstance(val, torch.Tensor):
                out_str += f"{key}={val.shape}, "
            elif isinstance(val, list) and val:
                out_str += f"{key}=List[{len(val)}, {type(val[0])}], "
            elif isinstance(val, str):
                out_str += f"{key}='{val}', "
            else:
                out_str += f"{key}={val}, "
        out_str = out_str.rstrip(', ') + ')'
        return out_str

    def to(self, device: Any) -> '_DynamicStorage':
        """Returns a new instance with all tensors moved to the specified device.

        Uses the ``send()`` function to recursively move tensors within nested
        structures (dicts, lists, tuples). Non-tensor values are copied as-is.
        The original instance is not modified.

        Args:
            device (Any): The target PyTorch device.

        Returns:
            _DynamicStorage: A new instance with tensors on the target device.
        """
        return self.__class__(**{k: send(v, device) for k, v in self.items()})

    def numpy(self) -> '_DynamicStorage':
        """Returns a new instance with all tensors converted to numpy arrays.

        Uses the ``to_numpy()`` function to recursively convert tensors via
        ``.detach().cpu().numpy()``. Non-tensor values are copied as-is.
        The original instance is not modified.

        Returns:
            _DynamicStorage: A new instance with numpy arrays instead of tensors.
        """
        return self.__class__(**{k: to_numpy(v) for k, v in self.items()})

def _infer_batch_size_value(value):
    """Infer batch size from a single field value.

    Used as a fallback when ``_batch_size`` is not stored (i.e. for
    manually-constructed Entries that did not go through :meth:`collate`
    or :meth:`_slice_batch`).

    Args:
        value: A field value — Tensor, list, dict, or other.

    Returns:
        int or None: The batch size, or ``None`` if not inferrable
        from this value.
    """
    if isinstance(value, torch.Tensor):
        return value.shape[0]
    if isinstance(value, (list, tuple)):
        return len(value)
    if isinstance(value, dict):
        for v in value.values():
            result = _infer_batch_size_value(v)
            if result is not None:
                return result
    return None


def _slice_value(value, slc):
    """Extract a sub-batch via slicing, preserving the batch dimension.

    * ``Tensor`` → ``tensor[slc]``
    * ``list`` → ``list[slc]``
    * ``tuple`` → ``list(tuple[slc])`` (converted to list for consistency)
    * ``dict`` → recurse into values
    * ``None`` → ``None``
    """
    if isinstance(value, torch.Tensor):
        return value[slc]
    if isinstance(value, (list, tuple)):
        return list(value[slc]) if isinstance(value, tuple) else value[slc]
    if isinstance(value, dict):
        return {k: _slice_value(v, slc) for k, v in value.items()}
    return value


def _index_value(value, index):
    """Extract a single sample via integer indexing (removes batch dim).

    * ``Tensor [B,C,H,W]`` → ``tensor[index]`` → ``[C,H,W]``
    * ``list`` → ``list[index]`` (e.g. ``["s1","s2"]`` → ``"s1"``)
    * ``tuple`` → ``tuple[index]``
    * ``dict`` → recurse into values
    * ``None`` → ``None``
    """
    if isinstance(value, torch.Tensor):
        return value[index]
    if isinstance(value, (list, tuple)):
        return value[index]
    if isinstance(value, dict):
        return {k: _index_value(v, index) for k, v in value.items()}
    return value


class Entry(_DynamicStorage):
    """The core data container in SR-Forge.

    Entry is a dictionary-like container with attribute-style access
    (``entry.lr`` is equivalent to ``entry['lr']``). It holds all data for
    a sample as it flows through the pipeline — tensors, metadata, and
    intermediate results.

    **Stack-based convention**: ``Dataset.__getitem__`` returns fields in
    their natural form — tensors are ``[C, H, W]``, names are bare strings,
    scalars are Python types. Collation (via DataLoader) stacks samples to
    add a batch dimension: tensors become ``[B, C, H, W]``, names become
    lists, scalars become 1-D tensors.

    **Batched flag**: ``entry.is_batched`` indicates whether the entry has
    a batch dimension. Set to ``True`` by :meth:`collate` and
    :meth:`_slice_batch`, defaults to ``False`` for entries from datasets
    or manual construction. Integer indexing (``entry[i]``) removes the
    flag; slicing (``entry[0:1]``) preserves it.

    **Batch operations** (only meaningful when ``is_batched`` is ``True``):

    - ``entry.batch_size`` — number of samples in the batch.
    - ``entry[i]`` — extract sample *i*, removing batch dim (PyTorch semantics).
    - ``entry[start:stop]`` — extract a sub-batch (batch dim preserved).
    - ``entry.unbatch()`` — split into a list of unbatched Entries.

    **Collation**: ``Entry.collate([e1, e2, ...])`` stacks entries to add
    a batch dimension. Sets ``_is_batched = True`` and stores
    ``_batch_size`` for O(1) lookup.

    **Round-trip invariant**: ``Entry.collate([e1, e2])[i]`` recovers the
    original unbatched entry ``ei``.
    """
    def __init__(self, name: Union[str, list[str]] = None, *args, **kwargs):
        """Initializes the Entry.

        Args:
            name (str, optional): An identifier for the entry, such as an
                image filename. Defaults to None.
            *args (Any): Variable length argument list, passed to the `dict` constructor.
            **kwargs (Any): Arbitrary keyword arguments, which become items in the entry.
        """
        super().__init__(*args, **kwargs)
        self.name = name

    def __getitem__(self, item: Any) -> Any:
        """Dispatch on index type: int → sample, slice → sub-batch, str → field.

        Integer indexing extracts a single sample, removing the batch
        dimension (PyTorch semantics: ``tensor[i]`` drops dim 0).
        Slice indexing extracts a sub-batch with batch dim preserved.
        String keys access fields as usual (dict behavior).
        """
        if isinstance(item, int):
            return self._index_sample(item)
        if isinstance(item, slice):
            return self._slice_batch(item)
        return dict.__getitem__(self, item)

    def __delitem__(self, key: Any):
        if key == "name":
            raise KeyError(
                "Cannot delete 'name' from Entry — it is a required field."
            )
        dict.__delitem__(self, key)

    @property
    def is_batched(self) -> bool:
        """Whether this Entry carries a batch dimension.

        Set to ``True`` by :meth:`collate` and :meth:`_slice_batch`.
        Defaults to ``False`` for entries from datasets or manual
        construction. Integer indexing (``entry[i]``) clears the flag;
        slicing (``entry[0:1]``) preserves it.
        """
        return getattr(self, '_is_batched', False)

    @property
    def batch_size(self) -> int:
        """Return the batch size.

        Uses the stored ``_batch_size`` (set by :meth:`collate` and
        :meth:`_slice_batch`) when available, falling back to inference
        from the first tensor or list field.

        Returns:
            int: The batch size.

        Raises:
            ValueError: If batch size cannot be inferred (no tensors or lists).
        """
        if hasattr(self, '_batch_size'):
            return self._batch_size
        for value in self.values():
            result = _infer_batch_size_value(value)
            if result is not None:
                return result
        raise ValueError("Cannot infer batch size — no tensor or list fields found.")

    def __len__(self):
        """Return batch size if batched.

        Raises:
            TypeError: If the Entry is unbatched.

        Use ``entry.is_batched`` to check before calling ``len()``, or
        wrap in a try/except to handle both cases in one call.
        """
        if not self.is_batched:
            raise TypeError(
                "len() of unbatched Entry is not defined. "
                "Use entry.is_batched to check, or entry.batch_size for batched entries."
            )
        return self.batch_size

    def _index_sample(self, index: int) -> "Entry":
        """Extract a single sample via integer indexing, removing batch dim.

        Uses true integer indexing (PyTorch semantics): tensors go from
        ``[B,C,H,W]`` to ``[C,H,W]``, lists return the element at
        ``index``. The returned Entry does **not** have ``_is_batched``
        set (defaults to ``False``).

        Args:
            index: Sample index (supports negative indexing).

        Returns:
            Entry: An unbatched Entry (no batch dimension).

        Raises:
            IndexError: If ``index`` is out of range.
        """
        bs = self.batch_size
        if index < 0:
            index += bs
        if index < 0 or index >= bs:
            raise IndexError(
                f"Batch index {index} out of range for batch size {bs}."
            )
        return Entry(**{k: _index_value(v, index) for k, v in self.items()})

    def _slice_batch(self, slc: slice) -> "Entry":
        """Extract a sub-batch via slicing, preserving batch dim.

        The returned Entry has ``_batch_size`` and ``_is_batched`` set.

        Args:
            slc: A Python slice object.

        Returns:
            Entry: A sub-batch Entry with batch dim preserved.
        """
        result = Entry(**{k: _slice_value(v, slc) for k, v in self.items()})
        result._batch_size = len(range(*slc.indices(self.batch_size)))
        result._is_batched = True
        return result

    def unbatch(self) -> List["Entry"]:
        """Split this batched Entry into a list of unbatched Entries.

        Each element is obtained via integer indexing, so the batch
        dimension is removed (PyTorch semantics).

        Returns:
            List[Entry]: One unbatched Entry per sample.
        """
        return [self[i] for i in range(self.batch_size)]

    @classmethod
    def collate(cls, batch: List["Entry"]) -> "Entry":
        """Collate a list of Entries into a single batched Entry.

        Stacks each field to add a batch dimension: tensors are stacked
        via ``torch.stack``, lists are collected into a list-of-lists,
        strings are collected into a list, scalars become 1-D tensors.
        All entries must have the same keys.

        The returned Entry has ``_is_batched = True`` and
        ``_batch_size = len(batch)`` for O(1) :attr:`batch_size` access.

        Args:
            batch: A list of Entry objects to collate.

        Returns:
            Entry: A single batched Entry.

        Raises:
            ValueError: If entries have different keys.
        """
        if not all(set(entry.keys()) == set(batch[0].keys()) for entry in batch):
            raise ValueError("All entries must have the same keys.")
        result_dict = {}
        for key in batch[0].keys():
            result_dict[key] = GeneralCollation().collate([entry[key] for entry in batch], key=key)
        result = cls(**result_dict)
        result._batch_size = len(batch)
        result._is_batched = True
        return result

    def merge_fields(self, fields: Mapping[str, Any], *, source: Optional[str] = None, allow_overwrite: bool = False) -> "Entry":
        """Merges a dictionary of fields into this entry.

        A convenience wrapper around the `_merge_fields` utility function.

        Args:
            fields (Mapping[str, Any]): A dictionary of fields to merge.
            source (Optional[str], optional): Name of the calling function for
                clearer error messages. Defaults to None.
            allow_overwrite (bool, optional): If False, raises an error on
                field conflicts. Defaults to False.

        Returns:
            Entry: The modified entry object.
        """
        return _merge_fields(self, fields, source=source, allow_overwrite=allow_overwrite)



if _HAS_PYG:
    class GraphEntry(_PyGData):
        """An ``Entry`` subclass for graph-based data, compatible with PyTorch Geometric.

        This class inherits from ``torch_geometric.data.Data``, making it directly
        usable with PyG's loaders and models. It's intended for samples that are
        represented as graphs (e.g., scenes with nodes and edges).

        Requires ``pip install srforge[graph]``.
        """
        def __init__(self,
                     name: str = None,
                     edge_index: Tensor = None,
                     edge_attr: Tensor = None,
                     pos: Tensor = None,
                     **kwargs):
            """Initializes the GraphEntry.

            Args:
                name (str, optional): An identifier for the entry. Defaults to None.
                edge_index (Tensor, optional): Graph connectivity in COO format with
                    shape ``[2, num_edges]``. Defaults to None.
                edge_attr (Tensor, optional): Features for each edge, with shape
                    ``[num_edges, num_edge_features]``. Defaults to None.
                pos (Tensor, optional): Node position matrix with shape
                    ``[num_nodes, num_dimensions]``. Defaults to None.
                **kwargs (Any): Additional attributes to be stored in the graph data object.
            """
            super().__init__(name=name, edge_index=edge_index, edge_attr=edge_attr,
                             pos=pos, **kwargs)

        def merge_fields(self, fields: Mapping[str, Any], *, source: Optional[str] = None, allow_overwrite: bool = False) -> "GraphEntry":
            """Merges a dictionary of fields into this graph entry."""
            return _merge_fields(self, fields, source=source, allow_overwrite=allow_overwrite)

        def numpy(self) -> 'GraphEntry':
            """Returns a new GraphEntry with all tensors converted to numpy arrays."""
            return self.__class__(**{k: to_numpy(self[k]) for k in self.keys()})
else:
    class GraphEntry:
        """Stub for GraphEntry when torch-geometric is not installed.

        This class exists so that ``isinstance(x, GraphEntry)`` checks work
        (always returning ``False``) without requiring torch-geometric.
        Attempting to instantiate raises ``ImportError``.
        """
        def __init__(self, *args, **kwargs):
            raise ImportError(
                "GraphEntry requires torch-geometric. "
                "Install it with: pip install srforge[graph]"
            )
