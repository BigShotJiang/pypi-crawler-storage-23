from typing import List, Any, TYPE_CHECKING

import torch

if TYPE_CHECKING:
    from data import Entry


class GeneralCollation:
    """A general-purpose collator for batches of ``Entry`` objects.

    Collation **stacks** to add a batch dimension:

    * **Tensor** (same shape) — ``torch.stack(batch, dim=0)``
    * **Tensor** (different shapes) — kept as a list (not stackable)
    * **list / tuple** — collected into a list (``[list1, list2]``)
    * **dict** — recursively collate each key
    * **None** (all) — stays ``None``
    * **None** (mixed with other types) — kept as a list
    * **str** — collected into a list (``["s1", "s2"]``)
    * **int / float** — ``torch.tensor([v1, v2])``
    * **bool** — ``torch.tensor([v1, v2], dtype=torch.bool)``
    """

    def __call__(self, batch: List['Entry']) -> 'Entry':
        """Collate a batch of entries.

        Ensures all entries in the batch are of the same type and then calls
        the ``collate`` class method on that type.

        Args:
            batch (List['Entry']): A list of ``Entry`` objects to collate.

        Returns:
            Entry: A single ``Entry`` object containing the collated batch.
        """
        if not all(type(x) == type(batch[0]) for x in batch):
            raise TypeError(f"Collation error: Found different types in batch: {[type(x) for x in batch]}")
        return type(batch[0]).collate(batch)

    def collate(self, batch: List[Any], key: str = None) -> Any:
        """Recursively collate a list of items by stacking.

        Adds a batch dimension to each field. Tensors are stacked
        (``torch.stack``), lists/tuples are collected into a list,
        strings are collected, and scalars become 1-D tensors.

        Args:
            batch (List[Any]): The list of items to collate.
            key (str, optional): The key corresponding to the batch, used for
                error messages. Defaults to None.

        Returns:
            Any: The collated batch.

        Raises:
            TypeError: If the batch contains mixed types for the same key,
                or an unsupported type is encountered.
        """
        elem = batch[0]
        has_none = any(x is None for x in batch)
        has_non_none = any(x is not None for x in batch)
        if has_none and has_non_none:
            return list(batch)
        if not all(isinstance(x, type(elem)) for x in batch):
            raise TypeError(f"Collation error: Found different types in batch for key '{key}': {[type(x) for x in batch]}")

        if isinstance(elem, torch.Tensor):
            if all(entry.shape == elem.shape for entry in batch):
                return torch.stack(batch, dim=0)
            return list(batch)
        if isinstance(elem, (list, tuple)):
            return list(batch)
        if isinstance(elem, dict):
            return {k: self.collate([d[k] for d in batch], key=f"{key}_{k}") for k in elem}
        if elem is None:
            return None
        if isinstance(elem, str):
            return list(batch)
        if isinstance(elem, bool):
            return torch.tensor(batch, dtype=torch.bool)
        if isinstance(elem, (int, float)):
            return torch.tensor(batch)
        raise TypeError(
            f"Collation error for key '{key}': unsupported type {type(elem).__name__}."
        )
