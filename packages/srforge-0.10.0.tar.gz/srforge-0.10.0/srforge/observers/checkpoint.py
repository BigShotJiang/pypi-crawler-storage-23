import logging
import os

import srforge.events.trainer
from srforge import GlobalSettings
from srforge.registry import register_class
from srforge.utils.checkpoint import save_checkpoint, save_model_weights
from .base import Observer

logger = logging.getLogger(__name__)


@register_class
class PyTorchModelSaver(Observer):
    """Observer that saves model checkpoints to disk after each epoch.

    Tracks the best validation loss and saves both ``_best`` and ``_last``
    checkpoints (training state + model weights per sub-model).

    Args:
        tracker: Experiment tracker for uploading files and setting summaries.
            Defaults to :class:`~srforge.tracking.NullTracker` if not provided.
        best_loss: Initial best loss value (used when resuming).
    """

    EVENTS = [srforge.events.trainer.TrainingBegan, srforge.events.trainer.TrainerEpochFinished]

    def __init__(self, best_loss: float = None, tracker: "ExperimentTracker | None" = None, **kwargs):
        super().__init__(**kwargs)
        self.best_loss = best_loss
        if tracker is None:
            from srforge.tracking import NullTracker
            tracker = NullTracker()
        self.tracker = tracker

    def on_training_began(self, event: srforge.events.trainer.TrainingBegan) -> None:
        if event.best_losses is not None and self.best_loss is None:
            self.best_loss = event.best_losses.get("total")

    def on_epoch_finished(self, event: srforge.events.trainer.TrainerEpochFinished):
        val_loss_mean = event.val_loss.total_weighted().mean()
        if self.best_loss is None or self.best_loss > val_loss_mean:
            if self.best_loss is not None:
                logger.info(f"New best loss: {self.best_loss} -> {val_loss_mean}")
            self.tracker.set_summary("best_losses", event.val_loss.as_summary_dict())
            self.tracker.set_summary("best_epoch", event.epoch)
            self.best_loss = val_loss_mean
            self._save_states(event, "_best")
        self.tracker.set_summary("epoch", event.epoch)
        self._save_states(event, "_last")

    def _save_states(self, data: srforge.events.trainer.TrainerEpochFinished, suffix: str = ""):
        out_dir = GlobalSettings().output_directory

        ckpt_path = os.path.join(out_dir, f"checkpoint{suffix}.pth")
        save_checkpoint(
            ckpt_path,
            epoch=data.epoch,
            optimizer=data.optimizer,
            lr_scheduler=data.lr_scheduler,
            scaler=data.scaler,
            best_loss=self.best_loss,
        )
        self.tracker.save_file(ckpt_path, base_path=out_dir)

        for path in save_model_weights(data.model, out_dir, suffix):
            self.tracker.save_file(path, base_path=out_dir)
