from __future__ import annotations

import abc
import inspect
import logging

import re
from collections import defaultdict
from typing import Dict, Type, Callable, Any, List, DefaultDict

from srforge.events.base import Event

logger = logging.getLogger(__name__)

def camel_to_snake(name: str) -> str:
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def snake_to_camel(name: str) -> str:
    return "".join(part.capitalize() for part in name.split("_"))


def all_event_subclasses() -> Dict[str, Type[Event]]:
    """Recursively collect all Event subclasses keyed by their class __name__."""
    result: Dict[str, Type[Event]] = {}

    def _walk(cls: Type[Event]):
        for sub in cls.__subclasses__():
            if sub.__name__ not in result:
                result[sub.__name__] = sub
                _walk(sub)

    _walk(Event)
    return result


class ObserverMeta(abc.ABCMeta):
    """
    Metaclass that:
      - uses `EVENTS` (optional) + `on_*` methods
      - auto-infers handlers from names & optional type hints
      - warns (via logger.warning) when there’s a mismatch,
        but tries hard to still do the right thing.
    """

    def __init__(cls, name, bases, ns, **kwargs):
        super().__init__(name, bases, ns, **kwargs)

        handlers: Dict[Type[Event], Callable[[Any], None]] = {}
        for base in bases:
            if hasattr(base, "__event_handlers__"):
                handlers.update(base.__event_handlers__)  # type: ignore

        has_own_events = "EVENTS" in ns
        events_declared: List[Type[Event]] = list(getattr(cls, "EVENTS", []))

        on_methods: Dict[str, Callable[..., Any]] = {}
        for attr_name, obj in ns.items():
            if callable(obj) and attr_name.startswith("on_"):
                on_methods[attr_name] = obj

        known_events = all_event_subclasses()

        # 1) For each on_* method, try to infer the event type
        for method_name, func in on_methods.items():
            snake = method_name[len("on_"):]
            camel = snake_to_camel(snake)

            inferred_by_name: Type[Event] | None = known_events.get(camel)

            sig = inspect.signature(func)
            params = list(sig.parameters.values())
            ev_type_from_hint: Type[Event] | None = None

            if len(params) >= 2:
                ann = params[1].annotation
                if isinstance(ann, type) and issubclass(ann, Event):
                    ev_type_from_hint = ann

            # Decide event type, preferring explicit annotation
            ev_type: Type[Event] | None = ev_type_from_hint or inferred_by_name

            if ev_type is None:
                logger.warning(
                    f"{cls.__name__}.{method_name}: cannot infer event type "
                    f"(no matching Event subclass for '{camel}' and no Event annotation). "
                    f"This handler will be ignored."
                )
                continue

            # If both name and annotation disagree, warn but trust annotation
            if inferred_by_name and ev_type_from_hint and inferred_by_name is not ev_type_from_hint:
                logger.warning(
                    f"{cls.__name__}.{method_name}: annotation ({ev_type_from_hint.__name__}) "
                    f"disagrees with name-derived event ({inferred_by_name.__name__}); "
                    f"using annotated type."
                )

            handlers[ev_type] = func

            # If not declared in EVENTS, warn but still wire it:
            if events_declared and ev_type not in events_declared:
                logger.warning(
                    f"{cls.__name__}.{method_name} handles {ev_type.__name__} "
                    f"but {ev_type.__name__} is not listed in {cls.__name__}.EVENTS. "
                    f"Consider adding it for stricter checks."
                )

        # 2) Check events in EVENTS that have no handler
        #    Only if this class declared a NON-EMPTY EVENTS list.
        if has_own_events and events_declared:
            for ev_type in events_declared:
                if ev_type not in handlers:
                    expected_name = f"on_{camel_to_snake(ev_type.__name__)}"
                    logger.warning(
                        f"{cls.__name__}.EVENTS contains {ev_type.__name__} "
                        f"but no handler {expected_name}(...) was found. "
                        f"This event will currently be ignored by {cls.__name__}."
                    )


        # 3) Symmetric warnings for global situation
        #    Again, only if this class declared EVENTS itself.
        if has_own_events and events_declared and not on_methods:
            logger.warning(
                f"{cls.__name__} declares EVENTS={events_declared} but has no on_* "
                f"methods. Did you forget to implement the handlers?"
            )

        if not events_declared and on_methods:
            logger.warning(
                f"{cls.__name__} defines on_* methods ({', '.join(on_methods.keys())}) "
                f"but EVENTS is empty. Everything will still work, but you may want "
                f"to declare EVENTS=[...] for better static checking."
            )

        cls.__event_handlers__ = handlers  # type: ignore[attr-defined]


class Observer(metaclass=ObserverMeta):
    """
    Subclasses may define:
        EVENTS = [EventType1, EventType2, ...]

    and must provide an implementation of 'on_*' methods in snake_case, e.g.:
        def on_<event_type_1>(self, event): ...

    if they list that event type in EVENTS.

    Accepts an optional ``scope`` keyword argument that controls which
    runner-level events this observer receives.  After creation, the observer
    must be explicitly subscribed to an :class:`~srforge.observers.bus.EventBus`::

        bus.subscribe(observer)   # reads scope from observer._bus_scope
    """
    EVENTS: List[Type[Event]] = []

    def __init__(self, scope=None):
        self._bus_scope = scope


class Observable:
    """
    Observable that dispatches **event objects**.
    Observers are auto-wired by inspecting methods named `on_*`
    whose first non-self parameter has a concrete type annotation.

    Optionally forwards events to an attached :class:`EventBus` with a scope tag.
    """

    def __init__(self) -> None:
        # map: event_type -> list[callable(event)]
        self._observers: DefaultDict[type, list[Callable[[Any], None]]] = defaultdict(list)
        self._event_bus: Any | None = None
        self._bus_scope: str | None = None
        # Auto-attach to global EventBus if available
        try:
            from srforge import GlobalSettings
            bus = GlobalSettings().event_bus
            if bus is not None:
                scope = getattr(self, '_scope', None) or None
                self.attach_bus(bus, scope=scope)
        except Exception:
            pass

    def attach_bus(self, bus: Any, scope: str | None = None) -> None:
        """Attach an :class:`EventBus`.  Events will be forwarded with *scope*."""
        self._event_bus = bus
        self._bus_scope = scope

    # low-level API if you ever need it
    def _subscribe(self, event_type: type, callback: Callable[[Any], None]) -> None:
        self._observers[event_type].append(callback)

    def add_observer(self, observer: Any) -> None:
        """
        Auto-discover event handlers on `observer`.

        Any method on the *class*:
          - whose name starts with `on_`
          - whose first non-`self` parameter has a type annotation
        is treated as a handler for that event type.
        """
        handlers: Dict[Type[Event], Callable[[Any], None]] = getattr(
            observer, "__event_handlers__", {}
        )
        if not handlers:
            raise TypeError(
                f"{observer.__class__.__name__} does not declare any EVENTS/handlers; "
                f"did you forget to set EVENTS?"
            )

        cls = type(observer)
        for ev_type, func in handlers.items():
            # bind function to instance
            bound = func.__get__(observer, cls)
            self._observers[ev_type].append(bound)

    def notify(self, event: Any) -> None:
        """
        Publish a concrete event object to all observers registered
        for its exact type, then forward to the attached bus (if any).
        """
        for callback in self._observers.get(type(event), []):
            callback(event)
        if self._event_bus is not None:
            self._event_bus.publish(event, scope=self._bus_scope)


