"""Standalone event bus with scope-based filtering."""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Type

from srforge.events.base import Event

if TYPE_CHECKING:
    from srforge.observers.base import Observer

logger = logging.getLogger(__name__)

_UNSET = object()


class _Subscription:
    """Internal record: one observer bound to optional scope(s)."""

    __slots__ = ("observer", "scopes", "handlers")

    def __init__(
        self,
        observer: Any,
        scopes: frozenset[str] | None,
        handlers: Dict[Type[Event], Callable],
    ):
        self.observer = observer
        self.scopes = scopes  # None = wildcard (all scopes)
        self.handlers = handlers


class EventBus:
    """Standalone event dispatcher with scope-based filtering.

    Observers register with an optional ``scope`` parameter.  Events are
    published with an optional ``scope``.  Rules:

    - Observer registered **without** scope receives events from ALL scopes
      (and scopeless events).
    - Observer registered **with** scope(s) receives only events whose
      publish-scope matches, **plus** all scopeless events (trainer-level).
    """

    def __init__(self) -> None:
        self._subscriptions: defaultdict[
            Type[Event], List[_Subscription]
        ] = defaultdict(list)

    def subscribe(
        self,
        observer: Any,
        scope: str | list[str] | None = _UNSET,
    ) -> None:
        """Register *observer* (or a list of observers) for their declared event types.

        Args:
            observer: An ``Observer`` instance with ``__event_handlers__``,
                or an iterable of such instances.
            scope: Optional scope filter.  When omitted, reads
                ``observer._bus_scope`` (set by the observer's constructor).
                ``None`` means receive all events.
                A string or list restricts runner events to matching scopes.
        """
        if isinstance(observer, (list, tuple)):
            for obs in observer:
                self.subscribe(obs, scope=scope)
            return

        handlers: dict = getattr(observer, "__event_handlers__", {})
        if not handlers:
            raise TypeError(
                f"{type(observer).__name__} has no __event_handlers__; "
                f"did you forget to set EVENTS?"
            )

        if scope is _UNSET:
            scope = getattr(observer, "_bus_scope", None)

        if isinstance(scope, str):
            scopes = frozenset([scope])
        elif isinstance(scope, (list, tuple)):
            scopes = frozenset(scope)
        else:
            scopes = None  # wildcard

        cls = type(observer)
        bound_handlers: Dict[Type[Event], Callable] = {
            ev_type: func.__get__(observer, cls)
            for ev_type, func in handlers.items()
        }

        sub = _Subscription(observer, scopes, bound_handlers)
        for ev_type in bound_handlers:
            self._subscriptions[ev_type].append(sub)

    def publish(self, event: Event, scope: str | None = None) -> None:
        """Dispatch *event* to matching subscribers.

        Args:
            event: The event instance.
            scope: The scope tag (set by the emitting Observable).
                ``None`` means the event is scopeless (e.g. trainer-level)
                and always passes through to all subscribers.
        """
        for sub in self._subscriptions.get(type(event), []):
            if scope is None:
                # Scopeless event — always deliver
                handler = sub.handlers.get(type(event))
                if handler:
                    handler(event)
            elif sub.scopes is None or scope in sub.scopes:
                # Scoped event — deliver if subscriber is wildcard or matches
                handler = sub.handlers.get(type(event))
                if handler:
                    handler(event)
