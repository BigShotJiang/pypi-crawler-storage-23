import logging
logger = logging.getLogger(__name__)
import threading
from typing import Type, Union
import pkgutil
import importlib
from pathlib import Path
import json
import inspect
import ast
from ._paths import default_metadata_dir



class ClassRegistry:
    """Singleton registry for automatic class discovery and lookup.

    Automatically discovers classes decorated with @register_class and enables
    configuration-based instantiation without full module paths.

    Attributes:
        classes: Dictionary mapping public names to (module, class_name) tuples.
        _discovered: Set of root packages already scanned.
        _metadata_dir: Directory for saving registry metadata.
    """
    _instance = None
    _lock = threading.Lock()
    CLASS_REGISTRY_FILENAME = "class_registry.json"

    # ────────────────────────────────────────────────────────── singleton ──
    def __new__(cls, *args, **kwargs):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance.classes = {}
                cls._instance._discovered = set()
                cls._instance._metadata_dir = None
        return cls._instance

    # ──────────────────────────────────────────────── public API ──────────
    def set_metadata_dir(self, path: Union[str, Path]):
        """Set the directory for saving registry metadata.

        Args:
            path: Directory path for metadata files.
        """
        self._metadata_dir = Path(path)

    def discover(self, root: Union[str, Path]):
        """Discover and register classes in the specified package or directory.

        Scans all Python files and registers classes decorated with @register_class.

        Args:
            root: Package name (e.g., "srforge") or Path object to source directory.
        """
        root_path, root_pkg = self._to_path_and_package(root)
        if root_pkg in self._discovered:
            return                      # already done

        self._walk_source_tree(root_path, root_pkg)
        self._discovered.add(root_pkg)
        # self._save_metadata(self._metadata_dir or default_metadata_dir())

    def register(self, name: str, cls: Type):
        """Register a class with a public lookup name.

        Args:
            name: Public name for configuration-based lookup.
            cls: Class type to register.
        """
        if any((m == cls.__module__ and n == cls.__name__)
               for m, n in self.classes.values()):
            return                      # identical class already known
        self.classes[name] = (cls.__module__, cls.__name__)

    # ──────────────────────────────────────────── internals ───────────────
    @staticmethod
    def _to_path_and_package(root: Union[str, Path]):
        """Return (Path_to_folder, canonical_package_name)."""
        if isinstance(root, Path):
            # Convert src/srforge/... → srforge...
            # The package name is the last folder that *contains* __init__.py
            for parent in reversed(root.resolve().parents):
                if (parent / "__init__.py").exists():
                    pkg = ".".join(root.resolve().relative_to(parent).parts)
                    full_pkg = f"{parent.name}.{pkg}" if pkg else parent.name
                    return root.resolve(), full_pkg
            raise RuntimeError(f"Cannot derive package name from {root}")

        # dotted import name: find its spec
        spec = importlib.util.find_spec(root)
        if spec is None or spec.origin is None:
            raise ImportError(f"Cannot import '{root}'")
        if spec.submodule_search_locations:          # it’s a package
            folder = Path(next(iter(spec.submodule_search_locations))).resolve()
        else:                                        # it’s a single module file
            folder = Path(spec.origin).resolve().parent
        return folder, spec.name                     # spec.name is the canonical pkg

    # --------------------------------------------------------------------
    def _walk_source_tree(self, folder: Path, package_root: str):
        """
        Parse every .py file underneath *folder* and register classes that have
        a @register_class decorator.
        """
        for py_file in folder.rglob("*.py"):
            try:
                tree = ast.parse(py_file.read_text("utf‑8"), filename=str(py_file))
            except SyntaxError:
                continue

            rel_mod = ".".join(py_file.relative_to(folder).with_suffix("").parts)
            module_name = f"{package_root}.{rel_mod}" if rel_mod else package_root

            for node in tree.body:
                if not isinstance(node, ast.ClassDef):
                    continue
                for deco in node.decorator_list:
                    # @register_class           → ast.Name
                    # @register_class("foo")    → ast.Call(func=ast.Name)
                    if (isinstance(deco, ast.Name) and deco.id == "register_class") \
                       or (isinstance(deco, ast.Call) and
                           isinstance(deco.func, ast.Name) and deco.func.id == "register_class"):
                        public = (node.name if isinstance(deco, ast.Name)
                                  else (deco.args[0].value if deco.args else node.name))
                        self.classes.setdefault(public, (module_name, node.name))
                        break                                            # stop scanning decorators

    # --------------------------------------------------------------------
    def _save_metadata(self, path: Path):
        path.mkdir(parents=True, exist_ok=True)
        result = dict()

        classes = list(self.classes.keys())
        classes = sorted(classes, key=lambda x: x.lower())
        result['by_class'] = {k: self.classes[k][0] for k in classes}

        modules = sorted([self.classes[k][0] for k in self.classes])
        x = {module: [] for module in modules}
        for k, v in self.classes.items():
            x[v[0]].append(k)
        keys = sorted(x.keys())
        result['by_module'] = {k: x[k] for k in keys},

        with (path / self.CLASS_REGISTRY_FILENAME).open("w", encoding="utf-8") as f:
            json.dump(result, f, indent=4)
        print(f"Class registry saved to {path / self.CLASS_REGISTRY_FILENAME}")

    def __contains__(self, name):
        return self.has(name)

    def get(self, name):
        return self.classes.get(name)

    def has(self, name):
        return name in self.classes

    def __repr__(self):
        # pretty print
        return f'ClassRegistry({self.classes})'

def register_class(cls_or_name: Union[type, str] = None) -> Union[type, callable]:
    """Decorator to register a class for configuration-based instantiation.

    Enables using short names in YAML configs instead of full module paths.

    Args:
        cls_or_name: Class to register, or custom name string.

    Returns:
        Decorated class (unchanged).

    Example:
        >>> @register_class
        ... class MyModel(Model):
        ...     pass
        >>>
        >>> @register_class("custom_name")
        ... class AnotherModel(Model):
        ...     pass
    """
    def wrapper(cls):
        # Get the full module path
        class_name = cls.__name__ if isinstance(cls_or_name, type) or cls_or_name is None else cls_or_name
        ClassRegistry().register(class_name, cls)
        return cls

    if isinstance(cls_or_name, type):
        return wrapper(cls_or_name)
    return wrapper
