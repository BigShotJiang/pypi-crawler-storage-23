import os
import shutil
from pathlib import Path

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

import logging
from srforge.utils.logging import configure_logger
configure_logger(logging.INFO)

import hydra
import omegaconf
import torch

from srforge import GlobalSettings, init
from srforge.data.loader import DataLoaderFactory
from srforge.training.runners import BenchmarkRunner
from srforge.utils.multigpu import setup_device


@hydra.main(config_path="configs", config_name="test-cfg", version_base=None)
def main(cfg) -> None:
    resolve = init(cfg)
    settings = GlobalSettings()
    configure_logger(cfg.system.debug_level)

    # ── Tracking ──────────────────────────────────────────────────
    tracker = resolve(cfg.tracker)
    tracker.log_config(omegaconf.OmegaConf.to_container(cfg, resolve=False))

    print('Configuring benchmark...')
    print(f'Run ID: {tracker.run_id}')
    print(f'Run Name: {tracker.run_name}')
    print(f'Run path: {tracker.run_path}')

    # ── Model & metrics ───────────────────────────────────────────
    model         = resolve(cfg.model)
    metrics       = resolve(cfg.test_metrics)
    postprocessor = resolve(cfg.postprocessing)
    test_dataset  = resolve(cfg.dataset)

    model, device = setup_device(model, cfg.system.device)

    # ── Optional dataset caching ──────────────────────────────────
    if cfg.system.cache_dir is not None:
        cache_path = Path(cfg.system.cache_dir) / 'cache' / f"{device.type}_{device.index}"
        print(cache_path, cache_path.absolute())
        os.makedirs(cache_path, exist_ok=True)
        if os.path.isdir(cache_path) and cfg.system.recache:
            shutil.rmtree(cache_path)
        test_dataset = test_dataset.cache(cache_path / 'test')

    # ── Data loader ───────────────────────────────────────────────
    test_loader = DataLoaderFactory(
        test_dataset, batch_size=1, shuffle=False,
        num_workers=0, device=cfg.system.device,
    ).get_loader()

    out_dir = Path(cfg.system.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # ── Observers ────────────────────────────────────────────────
    observers = resolve(cfg.observers)
    settings.event_bus.subscribe(observers)

    # ── Benchmark ─────────────────────────────────────────────────
    runner = BenchmarkRunner(metrics, device, postprocessor=postprocessor)
    runner.run_epoch(model=model, data_loader=test_loader, epoch=0)

    tracker.finish(0)


if __name__ == "__main__":
    main()
