# Experiment Tracking

SR-Forge provides an `ExperimentTracker` abstraction so your scripts and observers are tracking-backend-agnostic. The backend (Weights & Biases, MLflow, or nothing) is selected via config.

---

## The Interface

Every tracker implements `ExperimentTracker`:

| Method | Description |
|--------|-------------|
| `log_metrics(metrics, step=)` | Log scalar metrics |
| `log_image(key, image, step=)` | Log an image |
| `set_summary(key, value)` | Set a run-level summary value |
| `commit(step=)` | Flush pending logs |
| `log_config(config)` | Log the experiment config |
| `watch_model(model, **kwargs)` | Attach gradient/parameter tracking |
| `save_file(path, base_path=)` | Upload a file artifact |
| `restore_file(filename)` | Download a file from the current (resumed) run |
| `restore_from_run(run_id, filename)` | Download a file from a different run |
| `finish(exit_code)` | Finalize the run |

Properties:

| Property | Type | Description |
|----------|------|-------------|
| `run_id` | `str \| None` | Unique run identifier |
| `run_name` | `str \| None` | Human-readable run name |
| `run_path` | `str \| None` | Full path/URL to the run |
| `is_resumed` | `bool` | Whether this run was resumed |

---

## Built-in Trackers

### WandbTracker

Backed by [Weights & Biases](https://wandb.ai). Constructor params mirror `wandb.init()`:

```yaml
tracker:
  _target: WandbTracker
  params:
    project: my-project
    entity: my-team
    mode: online          # online, offline, or disabled
    name:                 # auto-generated if null
    run_id:               # set to resume a previous run
    group:                # group related runs
    tags:                 # list of tags
    notes:                # description
    job_type: training
    resume: allow
```

When `run_id` is set and the run already exists, W&B resumes it. The `is_resumed` property returns `True`, which triggers checkpoint restoration in the training script.

### NullTracker

A no-op tracker where every method silently does nothing. Properties return `None`/`False`. Use it for offline development, debugging, or testing:

```yaml
tracker:
  _target: NullTracker
```

`restore_file()` and `restore_from_run()` raise `FileNotFoundError` — there are no files to restore when there's no tracking backend.

`NullTracker` is also the default for observers when no tracker is explicitly provided.

---

## Usage in Scripts

The standard pattern:

```python
from srforge import init
import omegaconf

resolve = init(cfg)

tracker = resolve(cfg.tracker)
tracker.log_config(omegaconf.OmegaConf.to_container(cfg, resolve=False))

# ... training ...

tracker.finish(0)
```

Observers receive the tracker as a constructor parameter — they don't need to know which backend is active. In YAML, use `${ref:tracker}` to inject the already-resolved tracker:

```yaml
observers:
  - _target: LossLogger
    params:
      tracker: ${ref:tracker}   # injects the resolved tracker instance
  - _target: PyTorchModelSaver
    params:
      tracker: ${ref:tracker}
  - _target: ProgressBar        # no tracker needed
    params:
      name: "T"
      scope: train
```

Inside an observer, access is via `self.tracker`:

```python
# Inside an observer — works with any tracker
self.tracker.log_metrics({"train/loss": loss_value}, step=epoch)
self.tracker.save_file(checkpoint_path, base_path=output_dir)
```

---

## Resuming Training

Resume is driven by the tracker. When `tracker.is_resumed` is `True`, the `resume_from_checkpoint()` utility:

1. Downloads the last checkpoint via `tracker.restore_file("checkpoint_last.pth")`
2. Restores optimizer, scheduler, and model weights
3. Restores RNG states for exact reproducibility

```python
from srforge.utils.checkpoint import resume_from_checkpoint

ckpt = resume_from_checkpoint(model, optimizer, scheduler, tracker=tracker)
trainer = resolve(cfg.trainer)
trainer.restore(ckpt)  # None-safe: no-op for fresh runs
```

For W&B, set `run_id` in the config to the run you want to resume:

```yaml
tracker:
  _target: WandbTracker
  params:
    project: my-project
    run_id: abc123xyz      # this triggers resume
    resume: allow
```

---

## Loading from a Different Run

To load model weights from a run that is *not* the current one (e.g., for transfer learning or inference), use `restore_from_run`:

```python
from srforge.utils.checkpoint import load_weights_from_tracker

model = load_weights_from_tracker(
    module=model,
    tracker=tracker,
    run_id="other-run-id",
    best=True,
)
```

This downloads the weight file via `tracker.restore_from_run()`, loads it, and cleans up the temporary file.

---

## Writing a Custom Tracker

Subclass `ExperimentTracker` and implement all abstract methods:

```python
from srforge.tracking.base import ExperimentTracker
from srforge.registry import register_class

@register_class
class MLflowTracker(ExperimentTracker):
    def __init__(self, experiment_name, tracking_uri=None):
        import mlflow
        mlflow.set_tracking_uri(tracking_uri)
        mlflow.set_experiment(experiment_name)
        self._run = mlflow.start_run()

    @property
    def run_id(self):
        return self._run.info.run_id

    # ... implement all other methods ...
```

Then use it in config:

```yaml
tracker:
  _target: MLflowTracker
  params:
    experiment_name: my-experiment
    tracking_uri: http://localhost:5000
```

No script changes needed — the tracker is resolved from config like any other component.
