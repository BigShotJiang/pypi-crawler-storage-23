# IO Binding

IO binding connects your components to Entry fields. A model with a `forward(image)` parameter can read from `entry["satellite_rgb"]` in one experiment and `entry["camera_input"]` in another — same model, different data.

This page is the comprehensive reference for all binding syntax. For concept guides, see: [Model](models/model.md) | [DataTransform](transforms/data-transform.md) | [EntryTransform](transforms/entry-transform.md) | [SequentialModel](models/sequential-model.md)

---

## All Binding Methods

| Method | Where | When to Use |
|--------|-------|-------------|
| `set_io(...)` | Python code | Programmatic setup, tests |
| `io:` key in YAML | Config files | Config-driven instantiation |
| Flow DSL: `x -> module -> y` | SequentialModel | Multi-stage pipelines |

---

## The One Format

All four component types (Model, DataTransform, EntryTransform, Loss) use the same `set_io()` format:

```python
component.set_io({
    "inputs": {param_or_port: entry_field, ...},
    "outputs": <string | list | dict>,
})
```

- **`inputs`**: A dict mapping parameter/port names to Entry field names, or a list of such dicts for multiple applications.
- **`outputs`**: A string, list, dict, or omitted. Determines where results are written.

!!! warning "When can you omit `outputs`?"
    Only when the component has a **single input** and returns a **single value**. The result is written back to the input field (in-place). If there are multiple inputs or multiple return values, `outputs` is **required**.

---

## Model

Model inputs are inferred from `forward()` parameter names — no IOSpec needed. Output field names come from the `outputs` key.

### `set_io()` in Python

**Single output:**

```python
class Upscaler(Model):
    def forward(self, image):
        return self.net(image)

model = Upscaler()
model.set_io({"inputs": {"image": "image_rgb"}, "outputs": "prediction"})
# "image" matches forward() param → reads entry["image_rgb"]
# "prediction" → writes entry["prediction"]
```

**Dict outputs** — when you want named output ports (e.g., for models with IOSpec):

```python
model.set_io({
    "inputs": {"image": "image_rgb"},
    "outputs": {"output": "prediction"},
})
```

### YAML `io:` Config

```yaml
model:
  _target: Upscaler
  params:
    channels: 128
  io:
    inputs:
      image: image_rgb
    outputs: prediction
```

### Multiple Inputs

Models with multiple `forward()` parameters:

```python
class FusionModel(Model):
    def forward(self, image, guide):
        return self.net(image, guide)

model.set_io({
    "inputs": {"image": "x", "guide": "edges"},
    "outputs": "result",
})
```

```yaml
  io:
    inputs:
      image: x
      guide: edges
    outputs: result
```

### Multiple Outputs

When `forward()` returns multiple values, you need output port names. Two approaches:

**With IOSpec** — declare named output ports:

```python
from srforge.utils import IOSpec

class FusionModel(Model):
    io_spec = IOSpec(required_outputs=("output", "attention_map"))

    def forward(self, image, guide):
        result, attn = self.net(image, guide)
        return result, attn  # Maps to ("output", "attention_map")
```

```python
model.set_io({
    "inputs": {"image": "x", "guide": "edges"},
    "outputs": {"output": "result", "attention_map": "attn"},
})
```

**Without IOSpec** — positional mapping in SequentialModel flow DSL:

```python
flow = ["(x, edges) -> fuse -> (result, attn)"]
# 1st return value → entry["result"]
# 2nd return value → entry["attn"]
```

### Optional Inputs

Parameters with defaults in `forward()` are automatically optional — they are skipped if the bound Entry field is absent:

```python
class MyModel(Model):
    def forward(self, image, guide=None):
        if guide is not None:
            return self.guided_net(image, guide)
        return self.net(image)

model.set_io({
    "inputs": {"image": "x", "guide": "edges"},
    "outputs": "y",
})
entry = Entry(x=tensor)  # No "edges" field
result = model(entry)    # OK: guide=None, model handles it
```

### SequentialModel Flow DSL

| Syntax | Example | Notes |
|---|---|---|
| Single input/output | `x -> m1 -> y` | Inputs by signature order |
| Multi-input | `(x, edges) -> m1 -> y` | Positional by signature order |
| Multi-output | `(x, g) -> m1 -> (result, conf)` | Positional return values |
| Named inputs | ` -> m1(image=x, guide=edges) -> y` | Explicit parameter mapping |
| Named outputs | `x -> m1 -> (output=y)` | Requires IOSpec |
| Reuse | `x -> enc -> h1` then `h1 -> enc -> h2` | Shared weights, different fields |

Models are **fully reusable** — the same instance can appear in multiple flow lines with shared weights. Each flow line provides its own IO mapping.

---

## DataTransform

DataTransform inputs are inferred from `transform()` or `transform_unbatched()` parameter names. No IOSpec needed. Type annotations control [recursion into containers](transforms/data-transform.md#how-type-annotations-control-container-handling).

### Single-Parameter Transforms

For transforms with one parameter (e.g., `transform(self, image: Tensor)`):

**In-place** — transform and write back to the same field:

```python
t.set_io({"inputs": {"image": "x"}})
# Reads entry["x"], writes result back to entry["x"]
```

**With new output name:**

```python
t.set_io({"inputs": {"image": "x"}, "outputs": "x_scaled"})
# Reads entry["x"], writes to entry["x_scaled"]
```

**Multiple fields** — apply the same transform to each field independently:

```python
t.set_io({"inputs": [{"image": "x"}, {"image": "y"}]})
# In-place on both: entry["x"] and entry["y"]

t.set_io({
    "inputs": [{"image": "x"}, {"image": "y"}],
    "outputs": ["x_scaled", "y_scaled"],
})
# Reads entry["x"] → writes entry["x_scaled"]
# Reads entry["y"] → writes entry["y_scaled"]
```

YAML equivalents:

```yaml
# In-place on single field
io:
  inputs:
    image: x

# With new output name
io:
  inputs:
    image: x
  outputs: x_scaled

# Multiple fields, in-place
io:
  inputs:
    - {image: x}
    - {image: y}

# Multiple fields with different output names
io:
  inputs: [{image: x}, {image: y}]
  outputs: [x_scaled, y_scaled]
```

### Multi-Parameter Transforms

When `transform()` takes multiple parameters, map each to an Entry field:

```python
# MatchReference: transform(self, image: Tensor, reference: Tensor)
t.set_io({
    "inputs": {"image": "lrs", "reference": "hr"},
    "outputs": "matched",
})
```

```yaml
io:
  inputs:
    image: lrs
    reference: hr
  outputs: matched
```

### Multiple Outputs

When `transform()` returns a tuple, map each value to a field using a list of output names:

```python
class SplitChannels(DataTransform):
    def transform(self, image: torch.Tensor):
        return image[:, :3], image[:, 3:]

t = SplitChannels()
t.set_io({"inputs": {"image": "x"}, "outputs": ["rgb", "extra"]})
```

```yaml
io:
  inputs:
    image: x
  outputs: [rgb, extra]   # Unpacked from the returned tuple
```

### Multiple Applications

Apply the same transform to different fields independently:

```python
# Single-parameter, multiple fields
t.set_io({"inputs": [{"image": "x"}, {"image": "y"}]})  # In-place on both

# Multi-parameter, multiple applications
t.set_io({
    "inputs": [
        {"image": "a1", "reference": "b1"},
        {"image": "a2", "reference": "b2"},
    ],
    "outputs": ["o1", "o2"],
})
# Application 1: transform(image=entry["a1"], reference=entry["b1"]) → entry["o1"]
# Application 2: transform(image=entry["a2"], reference=entry["b2"]) → entry["o2"]
```

**Multiple applications with multiple outputs per application:**

```python
t.set_io({
    "inputs": [
        {"image": "a1", "reference": "b1"},
        {"image": "a2", "reference": "b2"},
    ],
    "outputs": [["o1a", "o1b"], ["o2a", "o2b"]],
})
```

### In-Place Transforms

DataTransforms can overwrite the source field — unlike Models, which cannot overwrite existing Entry fields:

```python
t.set_io({"inputs": {"image": "x"}})  # entry["x"] replaced with transformed result
```

In SequentialModel:

```
x -> mul -> x           # entry["x"] overwritten
```

### Optional Parameters

Optional parameters (with default values) work in direct calls but are **not supported in IO binding** — all parameters must be bound:

```python
class AddNoise(DataTransform):
    def transform(self, image: Tensor, mask: Tensor = None):
        ...

noise = AddNoise()
noise(some_tensor)                 # OK: mask defaults to None

# Must bind ALL parameters:
noise.set_io({
    "inputs": {"image": "x", "mask": "m"},
    "outputs": "noisy",
})
```

### SequentialModel Flow DSL

| Syntax | Example | Effect |
|---|---|---|
| Single field | `x -> mul -> y` | One application |
| Multi-field | `x, y -> mul -> x2, y2` | Positional pairing (one application per pair) |
| In-place | `x -> mul -> x` | Overwrites `entry["x"]` |

DataTransforms are **fully reusable** — the same instance can appear in multiple flow lines. No instance state is mutated; applications are computed externally per step.

| State | Behavior |
|---|---|
| Not bound | Flow DSL computes applications externally. |
| Already bound | Flow DSL takes precedence. Pre-binding ignored. |

---

## EntryTransform

EntryTransform requires IOSpec — port names become instance attributes that your transform code accesses (e.g., `entry[self.field]`). This is fundamentally different from Model and DataTransform, which receive values as method parameters.

### Declaring Ports (IOSpec)

Every EntryTransform must declare an `io_spec` as a class attribute:

```python
from srforge.utils import IOSpec

class SelectBands(EntryTransform):
    io_spec = IOSpec(
        required_inputs=("multispectral",),
        optional_inputs=("reference",),
        required_outputs=("selected",),
        optional_outputs=("confidence",),
    )

    def transform_unbatched(self, entry):
        ms = entry[self.multispectral]   # self.multispectral → bound field name
        entry[self.selected] = ms[0:3]
        return entry
```

The four port categories:

| Category | Meaning | `self.<port>` if unbound |
|----------|---------|--------------------------|
| **Required inputs** | Must be bound and present in Entry | `AttributeError` |
| **Optional inputs** | May be absent — check `if self.port is not None` | `None` |
| **Required outputs** | Must always be produced | `AttributeError` |
| **Optional outputs** | May or may not be produced | `None` |

After IO binding, port names become instance attributes — `self.multispectral` resolves to the bound Entry field name (a string like `"raw_ms"`).

!!! warning "Port names are reserved"
    Port names are protected by the framework. Assigning to a port name in `__init__()` raises `AttributeError`. Rename either the port or the attribute to avoid collisions.

**Empty IOSpec** — transforms that operate on Entry structure without specific ports:

```python
class RemoveByPrefix(EntryTransform):
    io_spec = IOSpec()   # No ports — no set_io() needed
```

### `set_io()` in Python

**With dict outputs** — port name → field name:

```python
t.set_io({
    "inputs": {"multispectral": "raw_ms"},
    "outputs": {"selected": "rgb_only"},
})
# self.multispectral → "raw_ms", self.selected → "rgb_only"
```

**With positional outputs** — mapped to output ports in IOSpec order:

```python
t.set_io({
    "inputs": {"multispectral": "raw_ms"},
    "outputs": "rgb_only",
})
# "rgb_only" maps to the first output port ("selected")
```

**In-place** — outputs omitted, output ports sharing a name with an input port auto-map:

```python
t.set_io({"inputs": {"bands": "spectral"}})
# If "bands" is both an input and output port, writes back to "spectral"
```

**No inputs** — transforms with only outputs:

```python
t.set_io({"inputs": {}, "outputs": {"attr": "flag"}})
```

### YAML `io:` Config

```yaml
select:
  _target: SelectBands
  params:
    bands: [0, 1, 2]
  io:
    inputs:
      multispectral: raw_ms
    outputs:
      selected: rgb_only
```

### In-Place Port Rules

Port names live in a flat namespace. When the same name appears in both inputs and outputs, it maps to a single Entry field:

| Binding | Behavior |
|---|---|
| Same field in inputs and outputs | Allowed — reads and writes `entry["spectral"]` |
| Different fields for same port | Raises `ValueError` — conflicting bindings |

### SequentialModel Flow DSL

| Syntax | Example | Notes |
|---|---|---|
| Positional | `x -> t1 -> y` | Ports in IOSpec order |
| Named (module) | `(x, m) -> t1(image=x, mask=m) -> result` | Explicit port assignment |
| Named (LHS) | `(image=x, mask=m) -> t1 -> result` | Named mapping on input side |

### Reuse and Pre-Binding

EntryTransforms are **reusable** — the same instance can appear in multiple flow lines. Ports are rebound per step at runtime via `bind_io()`.

If a transform is pre-bound via `set_io()`, the **flow DSL takes precedence** inside SequentialModel — the pre-binding is overridden.

---

## Loss

Losses use `set_io()` with **inputs only** — they read from Entry fields and return `MetricScores`, never writing back. See the [Losses guide](losses.md) for full details.

```python
from srforge.loss.metrics import L1

loss = L1(weight=1.0)
loss.set_io({"inputs": {"x": "sr", "y": "hr"}})

scores = loss(entry)  # reads entry["sr"] → x, entry["hr"] → y
```

**Identity default** — when `set_io()` is not called, parameter names map to same-named Entry fields:

```python
loss = L1()
scores = loss(Entry(x=pred, y=target))  # x → x, y → y
```

**No outputs** — passing `outputs` raises `TypeError`. Losses don't write to Entry.

**No multiple applications** — `inputs` must be a single dict, not a list.

### YAML

```yaml
- _target: L1
  params:
    weight: 1.0
  io:
    inputs: {x: sr, y: hr}
```

---

## SequentialModel: All Module Types

Inside a SequentialModel, all module types get their IO from the flow DSL — no `io:` key needed:

```yaml
model:
  _target: srforge.models.SequentialModel
  params:
    modules:
      m1:
        _target: MyModel
        params: {}
      t1:
        _target: srforge.transform.entry.CopyFields
        params: {}
      mul:
        _target: srforge.transform.data.Multiply
        params:
          value: 2.0
    flow:
      - "x -> m1 -> y"           # Model: positional
      - "y -> t1 -> z"           # EntryTransform: positional
      - "z -> mul -> out"        # DataTransform: positional
```

!!! note "Key differences between module types in flow"
    - **Model**: Supports named input mapping (`m1(image=x)`) and named output mapping (`(output=y)` with IOSpec).
    - **EntryTransform**: Same named syntax as Model. Ports rebound per step.
    - **DataTransform**: Positional only — no named mapping. Input/output fields paired 1:1.

---

## Standalone Use (No Entry)

Model and DataTransform can be called directly with raw values, bypassing IO binding:

```python
# Model — no set_io() needed
output = model(some_tensor)               # calls forward() directly

# DataTransform (batched)
downsampled = Downsample()(some_tensor)    # calls transform() directly

# DataTransform (per-sample)
result = MyPerSampleTransform()(some_tensor)  # calls transform() which dispatches
```

EntryTransform always requires an Entry — it operates on Entry structure.

---

## Validation and Errors

### Missing Required Port

```python
# EntryTransform missing required output port
SelectBands().set_io({"inputs": {"multispectral": "x"}})
# ValueError: SelectBands io_map is missing required variable(s): ['selected']
```

### Unbound Component

```python
transform = StackBands()
transform(entry)  # No set_io called
# ValueError: StackBands requires io mappings before it can run.
```

### Conflicting Structured Bindings

```python
module.set_io({
    "inputs": {"image": "image_rgb"},
    "outputs": {"image": "prediction"},  # Same port, different field!
})
# ValueError: conflicting bindings
```

### Wrong Format

```python
# OLD (removed): t.set_io("x")
# OLD (removed): t.set_io(["x", "y"])
# OLD (removed): t.set_io({"x": "y"})
# These all raise TypeError — use the structured format instead.

t.set_io({"inputs": {"image": "x"}})          # Correct
t.set_io({"inputs": {"image": "x"}, "outputs": "y"})  # Correct
```

---

## Summary

| Scenario | What to Do |
|----------|------------|
| Writing a test or script | `component.set_io({"inputs": {...}, "outputs": ...})` |
| Defining an experiment config | Add `io:` with `inputs`/`outputs` keys in YAML |
| Building a SequentialModel | Let the flow DSL handle mapping |
| Prototyping in a notebook | Call the component directly with raw values |

---

**Next:** [Models](models/index.md) — Neural network components that use IO binding
