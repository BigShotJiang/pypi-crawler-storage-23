# SequentialModel

Most real-world deep learning pipelines are not a single model. You might encode first, then transform, then decode. Or split data into branches, process them separately, and merge. **SequentialModel** lets you compose these multi-stage pipelines declaratively using a simple flow DSL — no glue code needed.

You've already learned about the building blocks — [Models](model.md), [DataTransforms](../transforms/data-transform.md), and [EntryTransforms](../transforms/entry-transform.md). SequentialModel is how you wire them together into a pipeline, using [IO binding](../io-binding.md) to route data between stages automatically.

---

## Quick Reference

Every flow line follows the same pattern:

```
<inputs> -> <module> -> <outputs>
```

- **Inputs**: Entry field names that the module reads
- **Module**: A named Model, EntryTransform, or DataTransform
- **Outputs**: Entry field names that the module writes

### Minimal Example

```python
from srforge.models import SequentialModel, Model
from srforge.data import Entry

class Encoder(Model):
    def forward(self, image):
        return self.net(image)

class Decoder(Model):
    def forward(self, features):
        return self.net(features)

seq = SequentialModel(
    modules={"encode": Encoder(), "decode": Decoder()},
    flow="""
        x -> encode -> features
        features -> decode -> y
    """,
)

entry = Entry(x=some_tensor)
result = seq(entry)
# result.features — intermediate result preserved
# result.y — final output
```

### Module Types in Flow

All module types are configured uniformly — the flow DSL is the single source of truth for IO binding:

| Module Type | IO Source | Named Mapping | Auto-recurse into dicts/lists |
|-------------|-----------|---------------|-------------------------------|
| **Model** | Flow DSL | Yes | No |
| **EntryTransform** | Flow DSL | Yes | No |
| **DataTransform** | Flow DSL | No (positional only) | Yes (annotation-driven) |

---

## How It Works

A `SequentialModel` is itself a `Model`. It takes an Entry, runs it through a sequence of steps, and returns the modified Entry. Fields accumulate as the pipeline runs — step 2 can read fields produced by step 1.

```
Entry -> [step 1] -> Entry' -> [step 2] -> Entry'' -> ... -> Final Entry
```

### Defining a SequentialModel

```python
seq = SequentialModel(
    modules={"module_name": module_instance, ...},
    flow="...flow lines...",
)
```

The `flow` parameter can be a multiline string or a list of strings. The `modules` dict provides the named modules referenced in the flow.

---

## Flow DSL Syntax

### Basic Syntax

Each line has exactly three segments separated by `->`:

```
<LHS> -> <module> -> <RHS>
```

1. **LHS** — Entry fields to read
2. **Module segment** — which module to execute (with optional port mapping)
3. **RHS** — Entry fields to write

### Writing Flow Lines

**Multiline string** (most readable):

```python
flow = """
    # This is a comment
    x -> encoder -> features
    features -> decoder -> output
"""
```

**List of strings:**

```python
flow = [
    "x -> encoder -> features",
    "features -> decoder -> output",
]
```

### Multiple Inputs and Outputs

```
x, y -> module -> a, b
(x, y) -> module -> (a, b)
```

Both forms are equivalent. Parentheses are optional.

### Empty Inputs or Outputs

```
 -> set_attr -> y          # no inputs (writes only)
x -> remove -> ()          # no outputs (reads and deletes)
```

---

## Models in Flow

Models are the most flexible module type. The flow line controls which Entry fields map to which ports.

### Positional Mapping

Fields map to `forward()` parameters by signature order. Outputs are assigned positionally to return values:

```python
class TwoInputModel(Model):
    def forward(self, image, guide):
        output, conf = self.net(image, guide)
        return output, conf

flow = ["(x, edges) -> enhance -> (result, conf)"]
# "image" <- entry["x"]       (1st forward() param)
# "guide" <- entry["edges"]   (2nd forward() param)
# 1st return value -> entry["result"]
# 2nd return value -> entry["conf"]
```

### Named Mapping

For clarity or different ordering, use named mapping in the module's parentheses. **Named input mapping** works with any model (port names = `forward()` parameter names). **Named output mapping** (e.g., `output=result`) requires IOSpec with declared output ports:

```python
from srforge.utils import IOSpec

class TwoInputModel(Model):
    io_spec = IOSpec(required_outputs=("output", "confidence"))

    def forward(self, image, guide):
        ...

flow = ["(x, edges) -> enhance(image=x, guide=edges) -> (output=result, confidence=conf)"]
```

Or omit the LHS if the module segment names everything:

```python
flow = [" -> enhance(image=x, guide=edges) -> (output=result, confidence=conf)"]
```

### Reusing the Same Model

A model can appear in multiple flow lines with shared weights:

```python
encoder = Encoder()
seq = SequentialModel(
    modules={"encoder": encoder},
    flow="""
        x -> encoder -> h1
        h1 -> encoder -> h2
    """,
)
# encoder applied twice with different IO mappings, shared parameters
```

---

## EntryTransforms in Flow

EntryTransforms work the same way as Models in the flow DSL — the flow line defines the IO mapping. No manual `set_io()` needed.

### Basic Usage

```python
from srforge.transform.entry import CopyFields

seq = SequentialModel(
    modules={"copy": CopyFields()},
    flow=["y -> copy -> z"],
)
```

### Positional and Named Mapping

```python
# Positional
flow = ["(image, msk) -> t -> result"]

# Named
flow = ["(a, b) -> t(x=a, mask=b) -> result"]
```

### Transforms with No Inputs or Outputs

```python
# Write-only (e.g., SetAttribute)
flow = [" -> set_val -> flag"]

# Read-only (e.g., RemoveFields)
flow = ["temp -> rm -> ()"]
```

### Optional Ports

The framework knows which ports are optional from the module's IOSpec. Optional inputs can be omitted from the LHS, and optional outputs can be included or omitted from the RHS:

```python
# Without optional output:
flow = ["x -> t -> y"]

# With optional output:
flow = ["x -> t -> (y, msk)"]
```

### Reuse with Different Mappings

The same EntryTransform instance can appear in multiple flow lines — ports are rebound per step at runtime:

```python
t = AddOneEntry()
flow = ["a -> t -> b", "b -> t -> c"]
```

### Pre-Bound Transforms

If a transform already has `set_io()` called, the **flow DSL takes precedence** — the pre-binding is overridden at runtime:

```python
copy = CopyFields().set_io({"inputs": {"field": "y"}, "outputs": {"output": "z"}})
flow = ["a -> copy -> b"]   # Rebinds to field=a, output=b
```

---

## DataTransforms in Flow

DataTransforms are the simplest to use in a flow. They don't need pre-binding — the flow line becomes the binding.

### Auto-Binding from Flow

```python
from srforge.transform.data import Multiply

mul = Multiply(2.0)
seq = SequentialModel(
    modules={"mul": mul},
    flow=["x -> mul -> y"],
)
```

### In-Place Transform

```python
flow = ["x -> mul -> x"]   # entry["x"] overwritten with transformed result
```

### Multiple Fields

DataTransforms pair inputs and outputs positionally:

```python
flow = ["x, y -> mul -> x2, y2"]
# entry["x2"] = mul(entry["x"])
# entry["y2"] = mul(entry["y"])
```

### Per-Sample DataTransforms

DataTransforms that implement `transform_unbatched()` instead of `transform()` work transparently in flows — no special syntax needed. The transform handles its own dispatch (batched vs per-sample) internally:

```python
class PerSampleDouble(DataTransform):
    def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
        return image * 2  # receives [C,H,W], no batch dim

seq = SequentialModel(
    modules={"double": PerSampleDouble()},
    flow="image -> double -> image",
)
# Each sample is doubled independently, then re-batched
```

### Recursive on Nested Structures

If a field contains a nested dict or list, the DataTransform is applied recursively to every leaf tensor (when the transform parameter is `Tensor`-annotated):

```python
entry = Entry(x={"a": tensor_a, "b": tensor_b})
flow = ["x -> mul -> y"]
# entry["y"] = {"a": mul(tensor_a), "b": mul(tensor_b)}
```

### No Named Mapping

DataTransforms do not support named mapping syntax:

```python
flow = ["(x=a) -> mul -> y"]   # ERROR
```

### Reusability

DataTransforms are **fully reusable** — the same instance can appear in multiple flow lines with different fields. Instance state is never mutated; applications are computed externally:

```python
mul = Multiply(2.0)
flow = [
    "x -> mul -> x_scaled",
    "y -> mul -> y_scaled",   # Same instance, different fields
]
```

See [DataTransform: In SequentialModel](../transforms/data-transform.md#in-sequentialmodel) for details on recursion and multi-input behavior.

---

## Building Pipelines

### Two-Stage Pipeline

```python
seq = SequentialModel(
    modules={"stage1": FirstStage(), "stage2": SecondStage()},
    flow="""
        x -> stage1 -> intermediate
        intermediate -> stage2 -> y
    """,
)
```

### Model + Transform Pipeline

```python
from srforge.transform.data import Multiply
from srforge.transform.entry import CopyFields

seq = SequentialModel(
    modules={
        "m1": HRPassthrough(),
        "copy": CopyFields(),
        "scale": Multiply(2.0),
    },
    flow="""
        x -> m1 -> y
        y -> copy -> z
        z -> scale -> out
    """,
)
```

### Multi-Input Model with Auxiliary Output

Without IOSpec — positional output mapping:

```python
class FusionModel(Model):
    def forward(self, image, guide):
        output, attn = self.fusion_net(image, guide)
        return output, attn

seq = SequentialModel(
    modules={"fuse": FusionModel()},
    flow=["(x, edges) -> fuse -> (result, attn)"],
)
```

With IOSpec — named output mapping:

```python
class FusionModel(Model):
    io_spec = IOSpec(required_outputs=("output", "attention_map"))

    def forward(self, image, guide):
        output, attn = self.fusion_net(image, guide)
        return output, attn

seq = SequentialModel(
    modules={"fuse": FusionModel()},
    flow=["(x, edges) -> fuse -> (output=result, attention_map=attn)"],
)
```

---

## Required Input Inference

SequentialModel automatically determines which Entry fields must be present before the pipeline runs:

```python
flow = """
    x -> encoder -> features       # consumes "x" (not produced by any prior step)
    features -> decoder -> out     # consumes "features" (produced by step 1)
"""
# Required inputs: ["x"]
```

---

## Field Overwrite Protection

Model steps **cannot overwrite** existing Entry fields:

```python
entry = Entry(x=tensor_a, y=tensor_b)
seq(entry)  # KeyError: attempted to overwrite existing entry fields: ['y']
```

DataTransforms are an exception — they can overwrite in-place when input and output are the same field.

---

## YAML Configuration

SequentialModel is fully configurable from YAML:

```yaml
model:
  _target: srforge.models.SequentialModel
  params:
    modules:
      encoder:
        _target: MyModel
        params:
          hidden_dim: 128
      copy:
        _target: srforge.transform.entry.CopyFields
        params: {}
      scale:
        _target: srforge.transform.data.Multiply
        params:
          value: 1.5
    flow:
      - "x -> encoder -> features"
      - "features -> copy -> features_backup"
      - "features -> scale -> output"
```

All module types are configured the same way — no `io:` key needed. The flow DSL handles IO binding for all of them.

---

## Common Errors

### "Module 'xxx' not found in modules"

The module name in the flow must match a key in the `modules` dict.

### "Module 'xxx' expects N inputs, got M"

Provide all required inputs in the LHS:

```python
# Model needs 2 inputs
flow = ["x -> m1 -> y"]  # ERROR: only 1 input
flow = ["(x, g) -> m1 -> y"]  # OK
```

### "DataTransform step 'xxx' requires flow inputs/outputs"

DataTransforms need at least an input field in the flow.

### "Duplicate outputs in flow line"

Each output field name must be unique within a flow line.

---

## Summary

| | Model | EntryTransform | DataTransform |
|-|-------|---------------|---------------|
| **IO binding** | Flow DSL | Flow DSL | Flow DSL |
| **Input mapping** | Positional or named | Positional or named | Positional only |
| **Output mapping** | Positional or named | Positional or named | Positional only |
| **Named syntax in module** | Yes: `m1(x=input)` | Yes: `t1(x=input)` | No |
| **Auto-recurse into dicts/lists** | No | No | Yes (annotation-driven) |
| **Reusable (different mapping)** | Yes | Yes | Yes |

### When to Use SequentialModel

- Multi-stage pipelines (encode -> transform -> decode)
- Mixing models and transforms in one forward pass
- Pipelines where intermediate results need to be preserved
- Declarative experiment configuration in YAML

### When NOT to Use SequentialModel

- Single model, no transforms — just use the model directly
- Pure preprocessing — apply transforms directly in the dataset's `transforms` list
- Dynamic branching (if/else logic) — SequentialModel is strictly sequential

---

**Next:** [Configuration](../configuration.md) — Define entire experiments in YAML, including SequentialModel pipelines
