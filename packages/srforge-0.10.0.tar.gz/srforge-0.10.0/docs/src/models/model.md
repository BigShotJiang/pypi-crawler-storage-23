# Model

A Model is a PyTorch neural network that participates in SR-Forge's pipeline. You write `forward()` with your computation — the framework handles extracting inputs from Entry fields and storing outputs back. It works exactly like a regular `nn.Module`, with IO binding on top.

---

## Your First Model

```python
from srforge.models import Model
import torch

class Upscaler(Model):
    def __init__(self, channels: int = 64):
        super().__init__()
        self.net = torch.nn.Sequential(
            torch.nn.Conv2d(3, channels, 3, padding=1),
            torch.nn.ReLU(),
            torch.nn.Conv2d(channels, 3, 3, padding=1),
        )

    def forward(self, image):
        return self.net(image)
```

Three things to notice:

1. **No IOSpec needed** — inputs are inferred from `forward()` parameter names (here: `image`). Outputs are determined when you bind the model (via `set_io()` or the flow DSL).
2. **`forward()`** — your computation, just like any PyTorch module. Parameter names become input port names automatically.
3. **It's a regular `nn.Module`** — you can call it standalone with plain tensors: `model(some_tensor)`

---

## The `forward()` Convention

In standard PyTorch, you override `forward()` in your subclass. SR-Forge follows the same convention:

```python
class MyModel(Model):
    def forward(self, x):
        return self.net(x)
```

Behind the scenes, `Model.__init_subclass__` transparently renames your `forward()` to `_forward()` so that the base class `Model.forward` (which handles Entry routing) can intercept calls and do IO binding before calling your code. This follows PyTorch's convention where `forward()` is the public interface — you define it naturally, and the framework adds Entry routing on top. This is invisible to you — just define `forward()` as you would in any PyTorch module.

!!! note "Legacy `_forward()` convention"
    The older `_forward()` convention still works for backward compatibility:

    ```python
    class MyModel(Model):
        def _forward(self, x):
            return self.net(x)
    ```

    Both produce identical behavior. Defining both `forward` and `_forward` raises `TypeError`.

---

## Input and Output Ports

Model input ports are **always inferred** from the `forward()` signature — no declaration needed:

- Parameters without defaults become **required inputs** (must be present in Entry)
- Parameters with defaults become **optional inputs** (skipped if absent)

```python
class MyModel(Model):
    def forward(self, image, guide=None):  # image: required, guide: optional
        ...
```

Output ports come from one of three sources:

1. **`set_io()`** — the `outputs` key specifies where results are written
2. **Flow DSL** — positional mapping assigns output fields directly
3. **IOSpec** (optional) — explicit declaration for named output mapping

### IOSpec: Declaring Output Ports (Optional)

For most models, `set_io()` or flow DSL mapping is all you need. But if you want to use **named output mapping** in the flow DSL (e.g., `-> model -> (output=y, aux=z)`), you need to declare output port names explicitly with IOSpec:

```python
from srforge.utils import IOSpec

class FusionModel(Model):
    io_spec = IOSpec(
        required_outputs=("output", "attention_map"),
    )

    def forward(self, image, guide):
        output, attn = self.fusion_net(image, guide)
        return output, attn  # Maps to ("output", "attention_map") by name
```

You never need to declare inputs in IOSpec — they are always inferred from `forward()`.

See the [IO Binding Reference](../io-binding.md#multiple-outputs) for all multiple-output syntax options.

---

## How Entry Routing Works

When you call `set_io()`, the `inputs` dict maps `forward()` parameter names to Entry fields, and `outputs` specifies where results are written. When you call `model(entry)`, the base class routes data through the binding:

1. Detects that the argument is an Entry
2. Looks up the IO binding: `image -> "image_rgb"`
3. Extracts `entry["image_rgb"]` and passes it as `image=entry["image_rgb"]`
4. Your `forward()` runs and returns a tensor
5. Maps the return value to the output field: `"prediction"`
6. Writes `entry["prediction"] = result`
7. Returns the updated Entry

```python
model = Upscaler()
model.set_io({"inputs": {"image": "image_rgb"}, "outputs": "prediction"})
# "image" → forward() param, reads entry["image_rgb"]
# "prediction" → output, writes entry["prediction"]

entry = Entry(image_rgb=some_tensor)
result = model(entry)
# result.prediction contains the model output
# result.image_rgb is preserved
```

### Multiple Outputs

If your model returns multiple values, they map to output ports:

**With IOSpec** (named mapping — ports have explicit names):

```python
class FusionModel(Model):
    io_spec = IOSpec(
        required_outputs=("output", "attention_map"),
    )

    def forward(self, image, guide):
        output, attn = self.fusion_net(image, guide)
        return output, attn  # Maps to ("output", "attention_map")
```

**Without IOSpec** (positional mapping in flow DSL):

```python
class FusionModel(Model):
    def forward(self, image, guide):
        output, attn = self.fusion_net(image, guide)
        return output, attn

# In SequentialModel, outputs are assigned positionally:
flow = ["(x, edges) -> fuse -> (result, conf)"]
# 1st return value -> entry["result"]
# 2nd return value -> entry["conf"]
```

### Field Overwrite Protection

Model outputs cannot overwrite existing Entry fields — this prevents accidentally losing data (e.g., a model silently replacing the ground truth). If `entry["prediction"]` already exists, a `KeyError` is raised:

```python
entry = Entry(image_rgb=tensor, prediction=existing_tensor)
model(entry)  # KeyError: attempted to overwrite existing entry fields: ['prediction']
```

---

## Standalone Use

Models can be called directly with raw tensors, bypassing IO binding entirely:

```python
# Pipeline mode (with Entry)
model.set_io({"inputs": {"image": "image_rgb"}, "outputs": "prediction"})
result_entry = model(entry)

# Standalone mode (plain PyTorch)
output = model(image=some_tensor)  # Returns raw forward() output
```

In standalone mode, the return value is whatever `forward()` returns — no Entry wrapping, no output mapping. No `set_io()` needed.

---

## IO Binding

Model IO is configured through `set_io()`, YAML `io:` keys, or the SequentialModel flow DSL.

### In Python

```python
model.set_io({"inputs": {"image": "image_rgb"}, "outputs": "prediction"})
```

### In YAML Config

```yaml
model:
  _target: Upscaler
  params:
    channels: 128
  io:
    inputs:
      image: image_rgb
    outputs: prediction
```

### In SequentialModel

```python
seq = SequentialModel(
    modules={"sr": Upscaler()},
    flow=["x -> sr -> y"],
)
# Parameter "image" reads entry["x"], output writes entry["y"]
```

For the full catalog of binding syntax, see the [IO Binding Reference: Model](../io-binding.md#model).

---

## In SequentialModel

Models are the most flexible module type inside a [SequentialModel](sequential-model.md). The flow DSL controls which Entry fields map to which ports:

```python
flow = ["(x, edges) -> enhance -> (result, conf)"]
```

For named output mapping (using port names like `output=result`), declare output ports with IOSpec:

```python
flow = ["(x, edges) -> enhance(image=x, guide=edges) -> (output=result, confidence=conf)"]
```

Models are **fully reusable** — the same instance can appear in multiple flow lines with shared weights:

```python
encoder = Encoder()
seq = SequentialModel(
    modules={"encoder": encoder},
    flow="""
        x -> encoder -> h1
        h1 -> encoder -> h2
    """,
)
# encoder is applied twice: x -> h1 -> h2 (shared weights)
```

See [SequentialModel: Models in Flow](sequential-model.md#models-in-flow) for details.

---

**Next:** [SequentialModel](sequential-model.md) — Compose models and transforms into multi-stage pipelines
