# Models

In SR-Forge, a **Model** is a neural network component that participates in the data pipeline. Unlike a plain PyTorch `nn.Module`, an SR-Forge Model knows how to read inputs from Entry fields and write outputs back — thanks to IO binding.

## Which One Do I Need?

```
I want to build a model...
            |
   Is it a single neural network?
            |
     +------+------+
     |             |
    YES           NO — it's a multi-stage pipeline
     |             |
     v             v
   Model      SequentialModel
```

**[Model](model.md)** — for individual neural network components. You define `forward()` with your computation, and the framework handles Entry routing. This is what you use for a single encoder, decoder, super-resolver, etc.

**[SequentialModel](sequential-model.md)** — for multi-stage pipelines that chain multiple models and transforms. You describe the data flow with a simple arrow syntax (`image -> encoder -> features -> decoder -> output`), and the framework wires everything together. No glue code needed.

Read them in order — Model first, then SequentialModel (which builds on everything you've learned so far).
