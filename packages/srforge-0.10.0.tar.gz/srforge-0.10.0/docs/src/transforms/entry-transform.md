# EntryTransform

Where a DataTransform changes the **content** of fields, an EntryTransform changes the **structure** of the Entry itself. It can add new fields, remove fields, read metadata, make decisions based on multiple values, and even change the Entry type entirely — for example, converting a plain Entry into a GraphEntry or any other custom Entry subclass.

```
Entry --> [your transform] --> Entry (modified, possibly different type)
```

Use EntryTransform when you need to reshape the data container, not just process the data inside it.

---

## Your First EntryTransform

Here's an EntryTransform that unpacks a nested dict field into top-level Entry fields — something that requires creating new fields dynamically and removing the original:

```python
from srforge.transform import EntryTransform
from srforge.utils import IOSpec

class FlattenField(EntryTransform):
    io_spec = IOSpec(required_inputs=("nested",))

    def transform_unbatched(self, entry):
        data = entry[self.nested]
        for key, value in data.items():
            entry[key] = value
        del entry[self.nested]
        return entry
```

Two things are new here compared to DataTransform:

1. **`io_spec`** — a declaration of what the transform needs. It lists **ports**: named placeholders for inputs and outputs. A port like `nested` doesn't correspond to any Entry field by itself — it gets connected to an actual field name through IO binding (`set_io()`). This means the same transform works with `"metadata"`, `"properties"`, or any other dict field.
2. **`transform_unbatched(entry)`** — you receive the full Entry and can create new fields (`entry[key] = value`), remove fields (`del entry[...]`), and inspect structure. A DataTransform cannot do any of this — it only receives values, never the Entry itself.

Use it with an Entry:

```python
from srforge.data import Entry
import torch

t = FlattenField()
t.set_io({"inputs": {"nested": "metadata"}})

entry = Entry(
    image=torch.randn(3, 64, 64),
    metadata={"width": 256, "height": 256, "source": "camera_1"},
)
entry = t(entry)
# entry has: image, width, height, source — metadata dict was unpacked and removed
```

The port name `nested` is abstract — `set_io()` maps it to the actual Entry field `"metadata"`. The same transform class can be reused with different field names in different contexts.

This couldn't be a DataTransform. Here's what each type can and can't do for this operation:

| Operation | DataTransform | EntryTransform |
|-----------|---------------|----------------|
| Read a dict field from Entry | Yes | Yes |
| Iterate over dict keys | Yes | Yes |
| Create new Entry fields dynamically | No | Yes |
| Remove the original dict field | No | Yes |

A DataTransform can write to new fields, but the number of outputs is fixed by what `transform()` returns and must be mapped to field names upfront. An EntryTransform can create fields dynamically at runtime — `FlattenField` produces as many new fields as there are keys in the dict, whether that's 0 or 100.

---

## Declaring Ports with IOSpec

Every EntryTransform must declare an `io_spec` as a class attribute. This is the component's **contract** — what it needs and what it produces:

```python
io_spec = IOSpec(
    required_inputs=("image",),        # Must be bound and present in Entry
    optional_inputs=("reference",),    # May be omitted — skipped if absent
    required_outputs=("output",),      # Always produced
    optional_outputs=("confidence",),  # Produced only in some configurations
)
```

Port names like `"image"` and `"output"` above are abstract — they don't correspond to any Entry field until connected through IO binding (covered [below](#io-binding-options)).

The four port categories:

| Category | Meaning | `self.<port>` if not bound |
|----------|---------|---------------------------|
| **Required inputs** | Must be bound to Entry fields and present at runtime | `AttributeError` — binding is mandatory |
| **Optional inputs** | Can be left unbound or absent from Entry — your `transform_unbatched()` should handle the missing case | `None` |
| **Required outputs** | Must always be produced by the transform | `AttributeError` — binding is mandatory |
| **Optional outputs** | May or may not be produced, depending on configuration | `None` |

After IO binding, port names become instance attributes — `self.image` resolves to the bound Entry field name (a string). Unbound optional ports resolve to `None`, so you can check `if self.mask is not None` to decide whether to use them. Before any `set_io()` call, accessing any port raises `AttributeError`.

!!! warning "Port names are reserved"
    Port names declared in IOSpec are protected — the framework uses them to store the bound field name (e.g., `self.image` resolves to `"input_rgb"`). If you try to assign to one in `__init__()`, you'll get an `AttributeError`:

    ```python
    class BadTransform(EntryTransform):
        io_spec = IOSpec(required_inputs=("image",), required_outputs=("output",))

        def __init__(self):
            super().__init__()
            self.image = "oops"  # AttributeError: cannot assign to IO port 'image'
    ```

    Rename either the port or the attribute to avoid the collision.

**Empty IOSpec** — some transforms operate on Entry structure without reading or writing specific fields. These declare an empty `IOSpec()` and don't need `set_io()`. The `super().__init__()` call is required because EntryTransform extends `torch.nn.Module`:

```python
class RemoveByPrefix(EntryTransform):
    io_spec = IOSpec()  # No ports — operates on Entry structure directly

    def __init__(self, prefix: str):
        super().__init__()
        self.prefix = prefix

    def transform_unbatched(self, entry):
        keys_to_remove = [k for k in entry.keys() if k.startswith(self.prefix)]
        for key in keys_to_remove:
            del entry[key]
        return entry

t = RemoveByPrefix(prefix="debug_")
entry = t(entry)  # No set_io() needed — nothing to bind
```

---

## IO Binding Options

The sections below show all binding methods — some reference [YAML configuration](../configuration.md) and [SequentialModel](../models/sequential-model.md). Feel free to skim and return later.

Like DataTransform, there are three ways to connect ports to Entry fields:

**In Python:**

```python
transform.set_io({
    "inputs": {"multispectral": "raw_ms"},
    "outputs": {"selected": "rgb_only"},
})
```

**In YAML config:**

```yaml
select:
  _target: SelectBands
  params:
    bands: [0, 1, 2]
  io:
    inputs:
      multispectral: raw_ms
    outputs:
      selected: rgb_only
```

**In SequentialModel flow DSL:**

```
raw_ms -> select -> rgb_only
```

All three produce the same result — the transform reads from `entry["raw_ms"]` and writes to `entry["rgb_only"]`.

All three are interchangeable. For the complete syntax reference with all variants, see [IO Binding Reference: EntryTransform](../io-binding.md#entrytransform).

---

## In SequentialModel

Inside a [SequentialModel](../models/sequential-model.md), EntryTransforms get their IO from the flow DSL:

```python
seq = SequentialModel(
    modules={"copy": CopyFields()},
    flow=["y -> copy -> z"],
)
```

EntryTransforms are **fully reusable** — the same instance can appear in multiple flow lines with different field mappings. The ports are rebound per step at runtime:

```python
copy = CopyFields()
flow = [
    "x -> copy -> y",
    "y -> copy -> z",
]
```

If a transform was pre-bound via `set_io()`, the **flow DSL takes precedence** inside SequentialModel.

See [SequentialModel: EntryTransforms in Flow](../models/sequential-model.md#entrytransforms-in-flow) for details.

---

## Batched vs Unbatched: Pick One

Like DataTransform, EntryTransform lets you pick one method and the framework handles the other case (see the [overview](index.md#batched-vs-unbatched-pick-one)). The choice works the same way: `transform(entry)` for batched logic, `transform_unbatched(entry)` for per-sample logic. If both are implemented, `transform()` always wins.

One thing to keep in mind: EntryTransform methods receive the **Entry itself**, which has a concrete batched state (`is_batched`, tensor shapes, list-vs-bare-string fields). If your code **depends on shapes** (e.g., indexing into tensors, using `.shape`), make sure it matches the Entry's batched state. Shape-agnostic code (e.g., renaming or deleting fields) works regardless.

---

## Using DataTransforms Inside EntryTransform

Since DataTransforms operate on raw values, you can call them inside `transform_unbatched()`. This lets you combine Entry-level logic with reusable value-processing components:

```python
class NormalizeAllTensorFields(EntryTransform):
    io_spec = IOSpec()  # No ports — operates on all fields

    def __init__(self):
        super().__init__()
        self.normalize = Normalize(mean=0.5, std=0.5)  # A DataTransform

    def transform_unbatched(self, entry):
        for key in entry.keys():
            if isinstance(entry[key], torch.Tensor):
                entry[key] = self.normalize(entry[key])
        return entry
```

The EntryTransform iterates over the Entry structure (inspecting field names and types), while the DataTransform handles the actual computation on each value. However, you cannot call an EntryTransform inside a DataTransform — a DataTransform only receives values, so it has no Entry to pass.

---

## Examples

### Band Splitting (One to Many Fields)

```python
class SplitMultispectralBands(EntryTransform):
    io_spec = IOSpec(
        required_inputs=("multispectral",),
        required_outputs=("rgb", "nir", "swir")
    )

    def transform_unbatched(self, entry: Entry) -> Entry:
        ms = entry[self.multispectral]  # [C, H, W] — no batch dim
        entry[self.rgb] = ms[0:3]
        entry[self.nir] = ms[3:5]
        entry[self.swir] = ms[5:7]
        return entry
```

### Conditional Processing

```python
class ConditionalNormalize(EntryTransform):
    io_spec = IOSpec(
        required_inputs=("image",),
        optional_inputs=("reference",),
        required_outputs=("normalized",)
    )

    def transform_unbatched(self, entry: Entry) -> Entry:
        image = entry[self.image]

        if self.reference in entry and entry[self.reference] is not None:
            ref = entry[self.reference]
            mean, std = ref.mean(), ref.std()
        else:
            mean, std = image.mean(), image.std()

        entry[self.normalized] = (image - mean) / std
        return entry
```

### Field Merging (Many to One)

```python
class MergeBands(EntryTransform):
    io_spec = IOSpec(
        required_inputs=("rgb", "nir"),
        required_outputs=("multispectral",)
    )

    def transform_unbatched(self, entry: Entry) -> Entry:
        rgb = entry[self.rgb]
        nir = entry[self.nir]
        entry[self.multispectral] = torch.cat([rgb, nir], dim=0)  # channel dim in [C, H, W]
        return entry
```

---

## Common Mistakes

### Forgetting IOSpec

```python
# BAD: Missing io_spec
class SelectBands(EntryTransform):
    def transform_unbatched(self, entry):
        return entry  # Runtime error: no io_spec defined

# GOOD: Always declare IOSpec
class SelectBands(EntryTransform):
    io_spec = IOSpec(
        required_inputs=("multispectral",),
        required_outputs=("selected",)
    )
    def transform_unbatched(self, entry):
        return entry
```

### Using EntryTransform for Simple Value Operations

```python
# BAD: Overkill for a pure function on values
class Normalize(EntryTransform):
    io_spec = IOSpec(required_inputs=("image",), required_outputs=("normalized",))
    def transform_unbatched(self, entry):
        entry[self.normalized] = (entry[self.image] - 0.5) / 0.5
        return entry

# GOOD: Simple and reusable
class Normalize(DataTransform):
    def transform(self, image: torch.Tensor) -> torch.Tensor:
        return (image - 0.5) / 0.5
```

DataTransform is simpler, more reusable, and doesn't require IOSpec. It also supports `transform_unbatched()` for per-sample logic without the batch dimension (see [Per-Sample Processing](data-transform.md#per-sample-processing-transform_unbatched)). Use EntryTransform only when you need access to Entry structure — removing fields, inspecting field names, or changing the Entry type.

---

**Next:** [IO Binding](../io-binding.md) — The complete reference for connecting ports to Entry fields
