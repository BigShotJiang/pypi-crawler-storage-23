# Losses

A **Loss** evaluates how well your model's predictions match the target. In SR-Forge, losses are components that read from Entry fields (like `sr` and `hr`) and return `MetricScores` — they never write back to the Entry. This makes them read-only observers of the pipeline output.

```
Dataset --> Transforms --> Model --> [Entry with sr, hr, ...] --> Loss --> MetricScores
```

---

## Your First Loss

```python
from srforge.loss import Loss
import torch

class MyL1(Loss):
    @property
    def best_min(self) -> bool:
        return True  # lower is better

    def calculate_score(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        return (x - y).abs().mean(dim=(-3, -2, -1))  # per-sample scalar [B]
```

Three things to notice:

1. **`best_min`** — tells the framework whether to minimize (True) or maximize (False) this metric during optimization.
2. **`calculate_score()`** — your computation. Parameter names become port names for IO binding (here: `x` and `y`).
3. **Type annotations are required** — every parameter in `calculate_score()` must be annotated. This drives the automatic multi-band splitting behavior.

---

## IO Binding

Losses use the same `set_io()` format as every other SR-Forge component, but with **inputs only** — losses don't produce outputs.

```python
from srforge.loss.metrics import L1
from srforge.data import Entry

loss = L1()
loss.set_io({"inputs": {"x": "sr", "y": "hr"}})

entry = Entry(sr=torch.randn(1, 3, 64, 64), hr=torch.randn(1, 3, 64, 64))
scores = loss(entry)  # reads entry["sr"] → x, entry["hr"] → y
```

**Identity default** — when `set_io()` is not called, the loss maps parameter names to same-named Entry fields. If your Entry has fields `x` and `y`, you don't need `set_io()` at all:

```python
loss = L1()
entry = Entry(x=torch.randn(1, 3, 64, 64), y=torch.randn(1, 3, 64, 64))
scores = loss(entry)  # x → x, y → y — just works
```

!!! warning "No `outputs` for losses"
    Losses return `MetricScores`, not Entry fields. Passing `outputs` to `set_io()` raises `TypeError`.

---

## Calling Modes

Losses support three calling modes:

### 1. Entry-based (primary)

```python
loss = L1()
loss.set_io({"inputs": {"x": "prediction", "y": "ground_truth"}})
scores = loss(entry)
```

### 2. Positional tensors

```python
loss = L1()
scores = loss(pred_tensor, target_tensor)  # maps to (x, y) in signature order
```

### 3. Keyword tensors

```python
loss = L1()
scores = loss(x=pred_tensor, y=target_tensor)
```

!!! note
    When using keyword mode, keys must match the **Entry field names** (after mapping), not the parameter names. If you set `set_io({"inputs": {"x": "sr", "y": "hr"}})`, use `loss(sr=..., hr=...)`.

---

## Masking

Most built-in losses accept an optional `y_mask` parameter for spatial masking — useful when parts of the target image are invalid (e.g., borders, clouds, no-data regions).

```python
loss = L1()
loss.set_io({"inputs": {"x": "sr", "y": "hr", "y_mask": "mask"}})

entry = Entry(
    sr=torch.randn(1, 3, 64, 64),
    hr=torch.randn(1, 3, 64, 64),
    mask=torch.ones(1, 3, 64, 64),  # 1 = valid, 0 = ignore
)
scores = loss(entry)
```

The `mask_pixels()` static helper is available for custom losses:

```python
class MaskedLoss(Loss):
    @property
    def best_min(self):
        return True

    def calculate_score(self, x: torch.Tensor, y: torch.Tensor, y_mask: torch.Tensor = None):
        x, y, total_unmasked = self.mask_pixels(x, y, y_mask)
        return (x - y).abs().sum(dim=(-3, -2, -1)) / total_unmasked
```

---

## Multi-Band (Dict) Inputs

Loss inputs can be tensors or dicts of tensors (one per spectral band). The behavior depends on type annotations:

### Tensor-annotated parameters (default) — automatic per-band splitting

When `calculate_score` parameters are annotated as `torch.Tensor`, dict inputs are automatically split per band. The loss runs once per band, and results are collected into a `{band: score}` dict:

```python
class BandL1(Loss):
    @property
    def best_min(self):
        return True

    def calculate_score(self, x: torch.Tensor, y: torch.Tensor):
        return (x - y).abs().mean(dim=(-3, -2, -1))

loss = BandL1()
entry = Entry(
    x={"b1": torch.randn(1, 1, 64, 64), "b2": torch.randn(1, 1, 64, 64)},
    y={"b1": torch.randn(1, 1, 64, 64), "b2": torch.randn(1, 1, 64, 64)},
)
scores = loss(entry)
# scores.as_raw_dict() → {"BandL1": {"b1": tensor([...]), "b2": tensor([...])}}
```

### Dict-annotated parameters — single call, full dict passed

When parameters are annotated as `dict`, the entire dict is passed as-is. No splitting occurs — your code handles the dict structure:

```python
class DictSAM(Loss):
    @property
    def best_min(self):
        return True

    def calculate_score(
        self,
        x: dict[str, torch.Tensor],
        y: dict[str, torch.Tensor],
    ):
        # Full dict available — compute spectral angle across bands
        ...
```

---

## MetricScores

`Loss.__call__` always returns `MetricScores`, never raw tensors. Key methods:

| Method | Returns | Description |
|--------|---------|-------------|
| `as_raw_dict()` | `{name: tensor_or_dict}` | Raw scores, no sign flip or weighting |
| `as_weighted_dict()` | `{name: tensor}` | With optimization sign + weight applied |
| `total_raw()` | `Tensor[B]` | Sum of all raw scores |
| `total_weighted()` | `Tensor[B]` | Sum with sign + weight (used for backprop) |

---

## Built-In Losses

| Loss | Parameters | `best_min` | Description |
|------|------------|:----------:|-------------|
| **L1** | `x, y, y_mask=None` | min | Mean absolute error (MAE) |
| **MSE** | `x, y, y_mask=None` | min | Mean squared error |
| **PSNR** | `x, y, y_mask=None` | max | Peak signal-to-noise ratio |
| **Charbonnier** | `x, y, y_mask=None` | min | Smooth L1 (epsilon-controlled) |
| **SSIM** | `x, y, y_mask=None` | max | Structural similarity index |
| **TotalVariation** | `x, y=None, mask=None` | min | Spatial smoothness penalty |
| **MGE** | `x, y, y_mask=None` | min | Mean Gradient Error (Sobel-based) |
| **SAM** | `x, y` | min | Spectral Angle Mapper |
| **LPIPS** | `x, y` | min | Learned Perceptual Image Patch Similarity |
| **CrossEntropy** | `x, y` | min | Per-sample mean cross-entropy |
| **TBE** | `sr, entry` | min | The Blur Effect (non-reference) |
| **L1RegisteredUncertaintyLoss** | `x, y, sigma_sr, y_mask=None` | min | L1 with shift registration uncertainty |

All losses accept `weight` and `name` constructor parameters. All are registered and usable by short name in YAML configs.

---

## LossCombiner

Combine multiple losses, each with its own weight:

```python
from srforge.loss import L1, SSIM, LossCombiner

combiner = LossCombiner([
    L1(weight=1.0, name="L1").set_io({"inputs": {"x": "sr", "y": "hr"}}),
    SSIM(weight=0.01, name="SSIM").set_io({"inputs": {"x": "sr", "y": "hr"}}),
])

scores = combiner(entry)
# scores.metrics has both "L1" and "SSIM" entries
total = scores.total_weighted()  # weighted sum for backprop
```

Each loss evaluates independently on the same Entry. The combiner merges all `MetricScores` — names must be unique across losses.

---

## cLossCombiner

A variant that adds **spatial correction** — it evaluates each loss over a grid of pixel shifts and picks the best alignment per sample. Useful for super-resolution where sub-pixel misalignment between prediction and target is common:

```python
from srforge.loss import L1, cLossCombiner

combiner = cLossCombiner(
    losses=[L1(weight=1.0)],
    border=3,           # search ±3 pixels
    do_correction=True, # apply brightness correction
)
combiner.set_io({"inputs": {"x": "sr", "y": "hr"}})
```

Loss names are prefixed with `c` (e.g., `L1` becomes `cL1`).

---

## LossScheduler

Switch between loss functions at epoch milestones:

```python
from srforge.loss import L1, SSIM, LossCombiner
from srforge.loss.schedule import LossScheduler

scheduler = LossScheduler(schedule={
    0: LossCombiner([
        L1(weight=1.0).set_io({"inputs": {"x": "sr", "y": "hr"}}),
        SSIM(weight=0.01).set_io({"inputs": {"x": "sr", "y": "hr"}}),
    ]),
    50: LossCombiner([
        L1(weight=1.0).set_io({"inputs": {"x": "sr", "y": "hr"}}),
        SSIM(weight=0.05).set_io({"inputs": {"x": "sr", "y": "hr"}}),
    ]),
})

# During training:
scheduler.update(epoch)
scores = scheduler(entry)
```

The schedule must contain key `0`. Call `update(epoch)` each epoch to switch the active loss.

---

## YAML Configuration

In config files, use `io:` (same as transforms and models):

```yaml
loss:
  _target: LossScheduler
  params:
    schedule:
      0:
        _target: LossCombiner
        params:
          losses:
            - _target: L1
              params:
                weight: 1.0
              io:
                inputs: {x: sr, y: hr}
            - _target: SSIM
              params:
                weight: 0.01
              io:
                inputs: {x: sr, y: hr}
      50:
        _target: LossCombiner
        params:
          losses:
            - _target: L1
              params:
                weight: 1.0
              io:
                inputs: {x: sr, y: hr}
            - _target: SSIM
              params:
                weight: 0.05
              io:
                inputs: {x: sr, y: hr}
```
