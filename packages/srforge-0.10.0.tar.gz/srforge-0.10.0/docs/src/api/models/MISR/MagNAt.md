# MagNAt Model

::: srforge.models.MISR.MagNAt
