# Core Data Structures

::: srforge.data.entry
