# Graph Neural Networks

::: srforge.nn.graph
