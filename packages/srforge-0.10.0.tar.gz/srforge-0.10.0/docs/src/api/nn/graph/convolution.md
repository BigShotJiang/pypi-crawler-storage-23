# Graph Convolution

::: srforge.nn.graph.convolution
