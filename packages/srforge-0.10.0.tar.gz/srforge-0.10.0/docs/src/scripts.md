# Writing Scripts

SR-Forge ships with ready-to-use `train` and `test` scripts that work entirely from YAML config. Most users will never need to modify them. But if you need custom logic — a different training loop, a GAN setup, transfer learning — you can write your own script.

This page shows how to write a script from scratch and explains each building block.

---

## Minimal Training Script

Here is the shortest working training script:

```python
import hydra
import omegaconf

from srforge import GlobalSettings, init
from srforge.data.loader import DataLoaderFactory
from srforge.utils.checkpoint import resume_from_checkpoint


@hydra.main(config_path="configs", config_name="train-cfg", version_base=None)
def main(cfg):
    resolve = init(cfg)                              # (1)

    tracker = resolve(cfg.tracker)                   # (2)
    tracker.log_config(omegaconf.OmegaConf.to_container(cfg, resolve=False))

    model     = resolve(cfg.model)                   # (3)
    optimizer = resolve(cfg.optimizer)
    scheduler = resolve(cfg.lr_scheduler)
    loss      = resolve(cfg.loss)

    ckpt = resume_from_checkpoint(model, optimizer, scheduler, tracker=tracker)  # (4)

    model.to("cuda")

    train_loader = DataLoaderFactory(
        resolve(cfg.dataset.training),
        batch_size=cfg.training.batch_size, shuffle=True,
    ).get_loader()
    val_loader = DataLoaderFactory(
        resolve(cfg.dataset.validation),
        batch_size=1, shuffle=False,
    ).get_loader()

    observers = resolve(cfg.observers)               # (5)
    GlobalSettings().event_bus.subscribe(observers)

    trainer = resolve(cfg.trainer)                    # (6)
    trainer.restore(ckpt)
    trainer.train(cfg.training.epochs, train_loader, val_loader)

    tracker.finish(0)                                # (7)


if __name__ == "__main__":
    main()
```

Let's walk through each numbered step.

---

## Step by Step

### 1. `init(cfg)` — Framework Setup

```python
resolve = init(cfg)
```

`srforge.init()` does three things and returns a `ConfigResolver`:

1. Cleans internal config keys (`clear_defaults`)
2. Wires `GlobalSettings` — stores the config and sets the output directory from Hydra
3. Creates a `ConfigResolver` bound to the config

The returned `resolve` callable is your main tool: pass any config subtree to it and it recursively instantiates the Python objects it describes.

`init()` has **no config key assumptions** — it doesn't care whether your config has `model`, `tracker`, or any other specific key. That's your script's job.

### 2. Tracker Setup

```python
tracker = resolve(cfg.tracker)
tracker.log_config(omegaconf.OmegaConf.to_container(cfg, resolve=False))
```

The tracker provides experiment logging (metrics, images, checkpoints). Resolve it from config and log the full config as metadata.

Observers that need the tracker (e.g., `LossLogger`, `PyTorchModelSaver`, `BatchImageLogger`) receive it as a constructor parameter via `tracker: ${ref:tracker}` in the YAML config. No need to store it on `GlobalSettings`.

See [Experiment Tracking](tracking.md) for details on the tracker abstraction.

### 3. Resolve Training Objects

```python
model     = resolve(cfg.model)
optimizer = resolve(cfg.optimizer)
scheduler = resolve(cfg.lr_scheduler)
loss      = resolve(cfg.loss)
```

Each `resolve()` call instantiates the class specified by `_target` with the `params` from YAML. Results are **cached** — calling `resolve(cfg.model)` twice returns the same Python object. This is how `${ref:model}` references work: when the optimizer config says `params: ${ref:model}.trainable_params()`, the resolver returns the already-created model instance.

Order doesn't matter. The resolver handles forward references lazily.

### 4. Resume from Checkpoint

```python
ckpt = resume_from_checkpoint(model, optimizer, scheduler, tracker=tracker)
```

One call that handles the entire resume flow:

- If the tracker says the run was resumed (`tracker.is_resumed`), it loads the last checkpoint, restores optimizer/scheduler state, loads model weights, and restores RNG states for exact reproducibility.
- If not resumed, it returns `None`.

You pass the result to `trainer.restore()` later — it accepts `None` as a no-op.

### 5. Observers

```python
observers = resolve(cfg.observers)
GlobalSettings().event_bus.subscribe(observers)
```

Observers react to training events (epoch finished, batch finished, etc.). Resolve them from config, then explicitly subscribe them to the global event bus. The `subscribe()` method accepts a list.

See [Observers & Events](observers.md) for how to write custom observers.

### 6. Trainer

```python
trainer = resolve(cfg.trainer)
trainer.restore(ckpt)
trainer.train(cfg.training.epochs, train_loader, val_loader)
```

The trainer orchestrates the epoch loop. `restore(ckpt)` sets the initial epoch, best losses, and restores the GradScaler state from the checkpoint. It accepts `None` (fresh run) as a no-op.

### 7. Cleanup

```python
tracker.finish(0)
```

Finalizes the tracker (flushes logs, uploads remaining files). Always call this at the end.

---

## GlobalSettings

`GlobalSettings` is a singleton that stores application-wide state. The framework uses it to find the event bus and output directory.

| Attribute | Type | Description |
|-----------|------|-------------|
| `config` | `DictConfig` | The full experiment config |
| `output_directory` | `str` | Hydra's output directory for the current run |
| `event_bus` | `EventBus` | Global event bus for observer dispatch |

`init(cfg)` sets `config` and `output_directory` automatically. The tracker is **not** stored on `GlobalSettings` — instead, observers receive it as an explicit constructor parameter via `tracker: ${ref:tracker}` in the config.

---

## ConfigResolver

`ConfigResolver` is the engine that turns YAML into Python objects. Key behaviors:

- **`_target` + `params`** — instantiate any class
- **Recursive** — nested `_target` blocks are resolved bottom-up
- **Cached** — each config path is resolved once and reused
- **`${ref:path}`** — references to already-instantiated objects
- **`io:` key** — automatically calls `set_io()` on IOModule subclasses
- **Runtime kwargs** — `resolve(cfg.section, key=value)` injects extra constructor arguments

See [Configuration](configuration.md) for the full reference.

---

## Writing a Test Script

A test/benchmark script is simpler — no optimizer, scheduler, or resume:

```python
import hydra
import omegaconf
import torch

from srforge import GlobalSettings, init
from srforge.data.loader import DataLoaderFactory
from srforge.training.runners import BenchmarkRunner


@hydra.main(config_path="configs", config_name="test-cfg", version_base=None)
def main(cfg):
    resolve = init(cfg)

    tracker = resolve(cfg.tracker)
    tracker.log_config(omegaconf.OmegaConf.to_container(cfg, resolve=False))

    model         = resolve(cfg.model)
    metrics       = resolve(cfg.test_metrics)
    postprocessor = resolve(cfg.postprocessing)
    test_dataset  = resolve(cfg.dataset)

    device = torch.device(cfg.system.device)
    model.to(device)

    test_loader = DataLoaderFactory(
        test_dataset, batch_size=1, shuffle=False,
    ).get_loader()

    observers = resolve(cfg.observers)
    GlobalSettings().event_bus.subscribe(observers)

    runner = BenchmarkRunner(metrics, device, postprocessor=postprocessor)
    runner.run_epoch(model=model, data_loader=test_loader, epoch=0)

    tracker.finish(0)


if __name__ == "__main__":
    main()
```

The pattern is the same: `init` -> resolve objects -> set up data -> run.

---

## Custom Training Loops

If `PyTorchTrainer` doesn't fit your needs (e.g., GAN training with alternating updates), you have two options:

### Option A: Write a Custom Trainer Class

Create a new trainer class, register it, and reference it in config:

```python
from srforge.registry import register_class
from srforge.observers.base import Observable

@register_class
class GANTrainer(Observable):
    def __init__(self, generator, discriminator, g_optimizer, d_optimizer, **kwargs):
        super().__init__(**kwargs)
        self.generator = generator
        self.discriminator = discriminator
        self.g_optimizer = g_optimizer
        self.d_optimizer = d_optimizer

    def train(self, epochs, train_loader, val_loader):
        for epoch in range(epochs):
            for batch in train_loader:
                # Your custom alternating update logic
                ...
```

Then in YAML:

```yaml
trainer:
  _target: GANTrainer
  params:
    generator: ${ref:generator}
    discriminator: ${ref:discriminator}
    g_optimizer: ${ref:g_optimizer}
    d_optimizer: ${ref:d_optimizer}
```

The script stays the same — `resolve(cfg.trainer)` creates your custom trainer.

### Option B: Inline the Loop in the Script

For one-off experiments, you can skip the trainer entirely and write the loop directly:

```python
for epoch in range(resume.initial_epoch, cfg.training.epochs):
    model.train()
    for batch in train_loader:
        batch = batch.to(device)
        output = model(batch)
        loss_scores = loss(output)
        loss_scores.total_weighted().mean().backward()
        optimizer.step()
        optimizer.zero_grad()

    scheduler.step()
```

This gives you full control but loses the observer/event infrastructure.

---

## Multi-GPU

For multi-GPU DataParallel training, the device config is a list:

```yaml
system:
  device: [0, 1]
```

The script uses `setup_device()` which handles everything — device detection, `model.to()`, and DataParallel wrapping:

```python
from srforge.utils.multigpu import setup_device

model, device = setup_device(model, cfg.system.device, train_dataset)
```

For single-GPU or CPU, it simply moves the model. For multi-GPU, it auto-detects whether to use `torch.nn.DataParallel` or `torch_geometric.nn.DataParallel` based on the dataset's element type.

---

## Summary

| Building Block | What It Does |
|---------------|-------------|
| `init(cfg)` | Framework setup, returns `ConfigResolver` |
| `resolve(cfg.section)` | Instantiate any config section |
| `resolve(cfg.section, key=val)` | Inject runtime values |
| `GlobalSettings().event_bus` | Global event bus for observers |
| `resume_from_checkpoint(model, opt, sched, tracker=)` | One-call checkpoint resume |
| `setup_device(model, device_config, dataset)` | Device placement + DataParallel |
| `DataLoaderFactory(...).get_loader()` | Create data loaders |
| `trainer.train(epochs, train_loader, val_loader)` | Run the training loop |
| `tracker.finish(0)` | Finalize the run |
