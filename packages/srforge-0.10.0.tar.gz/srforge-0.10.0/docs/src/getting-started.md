# Getting Started

## Installation

### Prerequisites

Install PyTorch **before** installing SR-Forge. Follow the official instructions at [pytorch.org](https://pytorch.org/get-started/locally/) to pick the right build for your OS, package manager, and GPU.

```bash
# Example: CUDA 12.8
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128

# Example: CPU only
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu
```

### Install SR-Forge

```bash
pip install srforge
```

This installs the core framework with everything you need for tensor-based super-resolution: models, transforms, datasets, losses, training loops, and configuration.

### Graph neural network support

If you work with graph-based models (e.g., MagNAt), you need PyTorch Geometric and its compiled extensions. Just like PyTorch itself, these must be installed with the correct CUDA version **before** installing SR-Forge's graph extra.

Follow the [PyG installation guide](https://pytorch-geometric.readthedocs.io/en/latest/install/installation.html) to pick the right wheels for your PyTorch version, then install the graph extra:

```bash
# Example: PyG packages for PyTorch 2.7 + CUDA 12.8
pip install torch-geometric
pip install pyg-lib torch-scatter torch-sparse torch-cluster torch-spline-conv \
    -f https://data.pyg.org/whl/torch-2.7.0+cu128.html

# Then install the graph extra
pip install srforge[graph]
```

## Scaffold a new project

After installing SR-Forge, create a ready-to-run training project:

```bash
mkdir my-experiment && cd my-experiment
srforge init
```

This generates:

```
my-experiment/
├── train.py              # Complete training script
└── configs/
    └── train-cfg.yaml    # Sample config with all settings
```

Edit `configs/train-cfg.yaml` to point at your data and adjust training settings, then run:

```bash
python train.py
```

The generated files are a **starting point**, not a rigid template. They include common features out of the box (multi-GPU, mixed precision, dataset caching, W&B tracking, loss scheduling, checkpointing), but you're expected to modify both files to fit your workflow.

The config file is especially flexible — add any fields you need. The YAML config is a plain Hydra/OmegaConf file, so you can add custom sections for your own training script logic, experiment metadata, or grouping in W&B, MLflow, or any other tracking tool. For example:

```yaml
# Custom fields — use them however you like in train.py
experiment:
  description: "Ablation study on loss weights"
  tags: [ablation, l1-ssim]

my_custom_setting: 42
```

See the [Configuration](configuration.md) guide for details on built-in settings.

## What's next

Read the guide in order — each page builds on the previous one:

1. **[Core Concepts](concepts.md)** — Quick glossary of every SR-Forge term
2. **[Entry](entry.md)** — The data container that flows through the pipeline
3. **[Datasets](datasets.md)** — Loading data and caching
4. **[Transforms](transforms/index.md)** — Preprocessing and augmentation
5. **[IO Binding](io-binding.md)** — How components connect to Entry fields
6. **[Models](models/index.md)** — Neural networks and pipeline composition
7. **[Losses](losses.md)** — Evaluation metrics and loss functions
8. **[Configuration](configuration.md)** — Wire everything together in YAML

## For developers

Install PyTorch and PyG with CUDA wheels first (see [Prerequisites](#prerequisites) and [Graph support](#graph-neural-network-support) above), then clone and install in editable mode:

```bash
git clone https://gitlab.com/tarasiewicztomasz/sr-forge.git
cd sr-forge
pip install -e ".[dev,graph]"
```

This gives you:

- **Editable install** — code changes take effect immediately, no reinstall needed
- **Dev tools** — pytest, mkdocs, mkdocstrings
- **Graph support** — full access to all components including graph models

Run the test suite:

```bash
pytest tests/ -v
```

Build and serve the docs locally:

```bash
mkdocs serve
```

Then open the local URL shown in the terminal.
