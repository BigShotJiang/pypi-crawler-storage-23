"""Tests for Dataset built-in disk caching."""

import pickle
from pathlib import Path
from unittest.mock import MagicMock

import pytest
import torch

from srforge.data import Entry
from srforge.dataset import Dataset, SubsetDataset, ConcatDataset


# ── Helpers ──────────────────────────────────────────────────────────────

class _CountingDataset(Dataset):
    """Dataset that counts how many times __getitem__ is called."""

    def __init__(self, n: int = 5, **kwargs):
        super().__init__(name="counting", **kwargs)
        self._n = n
        self.getitem_count = 0

    def __len__(self):
        return self._n

    def __getitem__(self, idx) -> Entry:
        self.getitem_count += 1
        return Entry(name=f"entry_{idx}", x=torch.tensor([float(idx)]))


def _add_one(entry: Entry) -> Entry:
    entry["x"] = entry["x"] + 1
    return entry


# ── Basic caching ────────────────────────────────────────────────────────

class TestBasicCaching:
    def test_cache_creates_pickle_file(self, tmp_path):
        ds = _CountingDataset()
        ds.cache(tmp_path / "cache")

        ds[0]
        assert (tmp_path / "cache" / "0.pkl").is_file()

    def test_cache_hit_skips_original_getitem(self, tmp_path):
        ds = _CountingDataset()
        ds.cache(tmp_path / "cache")

        ds[0]  # miss — calls original
        ds[0]  # hit — loads from cache
        assert ds.getitem_count == 1

    def test_cache_stores_correct_data(self, tmp_path):
        ds = _CountingDataset()
        ds.cache(tmp_path / "cache")

        result = ds[2]
        assert torch.equal(result["x"], torch.tensor([2.0]))

        # Verify the pickle file content matches
        with open(tmp_path / "cache" / "2.pkl", "rb") as f:
            cached = pickle.load(f)
        assert torch.equal(cached["x"], torch.tensor([2.0]))
        assert cached.name == "entry_2"

    def test_cache_returns_self(self, tmp_path):
        ds = _CountingDataset()
        result = ds.cache(tmp_path / "cache")
        assert result is ds

    def test_no_cache_by_default(self, tmp_path):
        ds = _CountingDataset()
        assert not ds._cache_enabled
        assert ds.cache_path is None

        ds[0]  # should work fine, no files created
        assert not any(tmp_path.iterdir()) if tmp_path.exists() else True

    def test_multiple_indices_cached(self, tmp_path):
        ds = _CountingDataset(n=3)
        ds.cache(tmp_path / "cache")

        for i in range(3):
            ds[i]

        assert ds.getitem_count == 3
        for i in range(3):
            assert (tmp_path / "cache" / f"{i}.pkl").is_file()

        # Second pass — all hits
        for i in range(3):
            ds[i]
        assert ds.getitem_count == 3  # unchanged


# ── Cache + transforms ordering ──────────────────────────────────────────

class TestCacheTransformOrdering:
    def test_cache_stores_transformed_data(self, tmp_path):
        ds = _CountingDataset(transforms=[_add_one])
        ds.cache(tmp_path / "cache")

        result = ds[0]
        # Original value is 0.0, transform adds 1
        assert torch.equal(result["x"], torch.tensor([1.0]))

        # Cached file should have the TRANSFORMED value
        with open(tmp_path / "cache" / "0.pkl", "rb") as f:
            cached = pickle.load(f)
        assert torch.equal(cached["x"], torch.tensor([1.0]))

    def test_cache_hit_skips_transforms(self, tmp_path):
        ds = _CountingDataset(transforms=[_add_one])
        ds.cache(tmp_path / "cache")

        ds[0]   # miss — load, transform, cache
        result = ds[0]  # hit — return cached (already transformed)

        assert torch.equal(result["x"], torch.tensor([1.0]))
        assert ds.getitem_count == 1  # original only called once

    def test_corrupted_cache_regenerates(self, tmp_path):
        ds = _CountingDataset()
        ds.cache(tmp_path / "cache")

        # Write garbage to cache file
        cache_dir = tmp_path / "cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        (cache_dir / "0.pkl").write_bytes(b"not a pickle")

        # Should regenerate cleanly
        result = ds[0]
        assert result.name == "entry_0"
        assert ds.getitem_count == 1


# ── cache_dir init param ─────────────────────────────────────────────────

class TestCacheDirParam:
    def test_cache_dir_in_constructor(self, tmp_path):
        ds = _CountingDataset(cache_dir=tmp_path / "cache")

        assert ds._cache_enabled
        assert ds.cache_path == tmp_path / "cache"

        ds[0]
        assert (tmp_path / "cache" / "0.pkl").is_file()

    def test_cache_dir_as_string(self, tmp_path):
        ds = _CountingDataset(cache_dir=str(tmp_path / "cache"))
        assert isinstance(ds.cache_path, Path)
        ds[0]
        assert (tmp_path / "cache" / "0.pkl").is_file()


# ── cache_path property ──────────────────────────────────────────────────

class TestCachePathProperty:
    def test_none_when_disabled(self):
        ds = _CountingDataset()
        assert ds.cache_path is None

    def test_returns_path_when_enabled(self, tmp_path):
        ds = _CountingDataset()
        ds.cache(tmp_path / "cache")
        assert ds.cache_path == tmp_path / "cache"


# ── SubsetDataset delegation ─────────────────────────────────────────────

class TestSubsetDelegation:
    def test_subset_delegates_to_cached_parent(self, tmp_path):
        ds = _CountingDataset(n=5)
        ds.cache(tmp_path / "cache")

        subset = SubsetDataset(ds, [1, 3])
        result = subset[0]  # maps to parent index 1
        assert result.name == "entry_1"
        assert (tmp_path / "cache" / "1.pkl").is_file()

        # Hit on parent cache
        subset[0]
        assert ds.getitem_count == 1


# ── ConcatDataset delegation ─────────────────────────────────────────────

class TestConcatDelegation:
    def test_concat_delegates_to_cached_children(self, tmp_path):
        ds1 = _CountingDataset(n=2)
        ds1._name = "ds1"
        ds1.cache(tmp_path / "cache1")

        ds2 = _CountingDataset(n=2)
        ds2._name = "ds2"
        ds2.cache(tmp_path / "cache2")

        concat = ds1 + ds2  # ConcatDataset
        concat[0]  # from ds1
        concat[2]  # from ds2

        assert (tmp_path / "cache1" / "0.pkl").is_file()
        assert (tmp_path / "cache2" / "0.pkl").is_file()

        # Hits
        concat[0]
        concat[2]
        assert ds1.getitem_count == 1
        assert ds2.getitem_count == 1


# ── recache parameter ──────────────────────────────────────────────────

class TestRecache:
    def test_recache_deletes_existing_cache(self, tmp_path):
        cache_dir = tmp_path / "cache"

        # Build initial cache
        ds1 = _CountingDataset(cache_dir=cache_dir)
        ds1[0]
        ds1[1]
        assert (cache_dir / "0.pkl").is_file()
        assert (cache_dir / "1.pkl").is_file()

        # Re-create with recache=True — old files should be gone
        ds2 = _CountingDataset(cache_dir=cache_dir, recache=True)
        assert not (cache_dir / "0.pkl").exists()
        assert not (cache_dir / "1.pkl").exists()

        # New data is cached on access
        ds2[0]
        assert (cache_dir / "0.pkl").is_file()

    def test_recache_false_preserves_cache(self, tmp_path):
        cache_dir = tmp_path / "cache"

        ds1 = _CountingDataset(cache_dir=cache_dir)
        ds1[0]
        assert (cache_dir / "0.pkl").is_file()

        # Re-create with recache=False — old cache preserved, no re-computation
        ds2 = _CountingDataset(cache_dir=cache_dir, recache=False)
        ds2[0]
        assert ds2.getitem_count == 0  # served from cache, original never called

    def test_recache_without_cache_dir_is_noop(self):
        # Should not raise
        ds = _CountingDataset(recache=True)
        assert not ds._cache_enabled
        ds[0]  # works fine without caching
