import torch

from srforge.data import Entry
from srforge.dataset import Dataset
from srforge.dataset.patching import MultiSpectralPatchedDataset


class _SingleEntryDataset(Dataset):
    def __init__(self, entry: Entry):
        super().__init__(name="dummy")
        self._entry = entry

    def __len__(self) -> int:
        return 1

    def __getitem__(self, idx) -> Entry:
        return self._entry

    @property
    def examples(self):
        return ["dummy"]


class TestMultiSpectralPatchedDataset:
    def test_crops_dict_of_bands(self):
        entry = Entry(
            name="scene",
            lrs={
                "b2": torch.arange(16, dtype=torch.float32).reshape(1, 4, 4),
                "b8": torch.arange(4, dtype=torch.float32).reshape(1, 2, 2),
            },
        )
        ds = _SingleEntryDataset(entry)
        patched = MultiSpectralPatchedDataset(
            ds,
            field_sizes={"lrs": 2},
            ref_band="b2",
            use_internal_cache=False,
        )

        assert len(patched) == 4
        patch0 = patched[0]
        assert patch0.name == "scene_000"
        assert patch0.lrs["b2"].shape[-2:] == (2, 2)
        assert patch0.lrs["b8"].shape[-2:] == (1, 1)
        assert torch.allclose(
            patch0.lrs["b2"],
            torch.tensor([[[0.0, 1.0], [4.0, 5.0]]])
        )
        assert torch.allclose(
            patch0.lrs["b8"],
            torch.tensor([[[0.0]]])
        )
