"""Tests for Dataset.__init_subclass__ automatic transform application."""

import pytest
import torch

from srforge.data import Entry
from srforge.dataset import Dataset


# ── Helpers ──────────────────────────────────────────────────────────────

class _FixedDataset(Dataset):
    """Minimal concrete Dataset that returns a fixed Entry."""

    def __init__(self, entry: Entry, **kwargs):
        super().__init__(name="fixed", **kwargs)
        self._entry = entry

    def __len__(self):
        return 1

    def __getitem__(self, idx) -> Entry:
        return self._entry

    @property
    def examples(self):
        return ["fixed"]


def _add_one(entry: Entry) -> Entry:
    """Transform that increments field 'x' by 1."""
    entry["x"] = entry["x"] + 1
    return entry


def _double(entry: Entry) -> Entry:
    """Transform that doubles field 'x'."""
    entry["x"] = entry["x"] * 2
    return entry


# ── Auto-application ─────────────────────────────────────────────────────

class TestAutoApplication:
    def test_single_transform_applied(self):
        entry = Entry(name="e", x=torch.tensor([0.0]))
        ds = _FixedDataset(entry, transforms=[_add_one])

        result = ds[0]
        assert torch.equal(result["x"], torch.tensor([1.0]))

    def test_multiple_transforms_applied_in_order(self):
        entry = Entry(name="e", x=torch.tensor([1.0]))
        ds = _FixedDataset(entry, transforms=[_add_one, _double])

        result = ds[0]
        # (1 + 1) * 2 = 4
        assert torch.equal(result["x"], torch.tensor([4.0]))

    def test_empty_transforms_no_error(self):
        entry = Entry(name="e", x=torch.tensor([5.0]))
        ds = _FixedDataset(entry, transforms=[])

        result = ds[0]
        assert torch.equal(result["x"], torch.tensor([5.0]))

    def test_no_transforms_arg_defaults_to_empty(self):
        entry = Entry(name="e", x=torch.tensor([5.0]))
        ds = _FixedDataset(entry)

        result = ds[0]
        assert torch.equal(result["x"], torch.tensor([5.0]))


# ── No double-application in inheritance ─────────────────────────────────

class _ChildDataset(_FixedDataset):
    """Child that overrides __getitem__ — gets its own wrapper."""

    def __getitem__(self, idx) -> Entry:
        entry = self._entry
        entry["tag"] = "child"
        return entry


class _GrandchildNoOverride(_ChildDataset):
    """Grandchild that does NOT override __getitem__ — inherits ChildDataset's wrapper."""
    pass


class TestNoDoubleApplication:
    def test_child_with_own_getitem_wraps_independently(self):
        entry = Entry(name="e", x=torch.tensor([0.0]))
        ds = _ChildDataset(entry, transforms=[_add_one])

        result = ds[0]
        assert result["tag"] == "child"  # bare string, no pre-collation
        assert torch.equal(result["x"], torch.tensor([1.0]))

    def test_grandchild_without_getitem_uses_parent_wrapper(self):
        entry = Entry(name="e", x=torch.tensor([0.0]))
        ds = _GrandchildNoOverride(entry, transforms=[_add_one])

        result = ds[0]
        assert result["tag"] == "child"  # bare string, no pre-collation
        # Transform applied exactly once
        assert torch.equal(result["x"], torch.tensor([1.0]))


# ── No pre-collation ─────────────────────────────────────────────────────

class TestNoPrecollation:
    def test_bare_string_stays_bare(self):
        """No pre-collation — bare name string stays as-is."""
        entry = Entry(name="scene", x=torch.tensor([1.0]))
        ds = _FixedDataset(entry)

        result = ds[0]
        assert result.name == "scene"

    def test_bare_int_stays_int(self):
        entry = Entry(name="e", scale=4)
        ds = _FixedDataset(entry)

        result = ds[0]
        assert result["scale"] == 4
        assert isinstance(result["scale"], int)

    def test_nested_dict_scalars_unchanged(self):
        entry = Entry(name="e", meta={"a": 1, "b": "x"})
        ds = _FixedDataset(entry)

        result = ds[0]
        assert result.meta["a"] == 1
        assert result.meta["b"] == "x"

    def test_transforms_see_natural_values(self):
        """Transforms see natural values (e.g. name is a bare string)."""
        def _check_name_is_string(entry):
            assert isinstance(entry.name, str), "Transform should see name as string"
            return entry

        entry = Entry(name="scene", x=torch.tensor([1.0]))
        ds = _FixedDataset(entry, transforms=[_check_name_is_string])

        ds[0]  # Should not raise


# ── repr ─────────────────────────────────────────────────────────────────

class TestRepr:
    def test_repr_shows_transforms(self):
        entry = Entry(name="e", x=torch.tensor([0.0]))
        ds = _FixedDataset(entry, transforms=[_add_one])

        r = repr(ds)
        assert "transforms=" in r
        assert "preprocessor" not in r
