import json
from pathlib import Path

from srforge.data import Entry
from srforge.dataset.lazy_datasets import LazyMultiSpectralDataset


def _write_json(path: Path, payload) -> None:
    path.write_text(json.dumps(payload), encoding="utf-8")


class TestLazyMultiSpectralDataset:
    def test_returns_entry_with_band_dicts(self, tmp_path: Path):
        root = tmp_path / "root"
        scene = root / "scene1"
        for band in ["b2", "b8"]:
            band_dir = scene / band
            band_dir.mkdir(parents=True, exist_ok=True)
            _write_json(band_dir / "lrs.json", {"values": [1, 2]})
            _write_json(band_dir / "hr.json", {"values": [3, 4]})

        ds = LazyMultiSpectralDataset(root, mappings={"lrs": "lrs", "hr": "hr"})
        entry = ds[0]

        assert isinstance(entry, Entry)
        assert entry.name == "scene1"
        assert set(entry.keys()) == {"lrs", "hr", "bands", "name"}
        assert set(entry.lrs.keys()) == {"b2", "b8"}
        assert set(entry.hr.keys()) == {"b2", "b8"}
        assert entry.bands == ["b2", "b8"]
        assert entry.lrs["b2"]["values"].shape == (2,)
        assert entry.hr["b8"]["values"].shape == (2,)
