import pytest
import torch
from omegaconf import OmegaConf

from srforge.config.resolver import ConfigResolver, _Args, _Kwargs, _sanitize_params
from srforge.data import Entry


def _resolver(cfg_dict=None):
    cfg = OmegaConf.create(cfg_dict or {})
    return ConfigResolver(cfg)


# ------------------------------------------------------------------
# _Args / _Kwargs / _sanitize_params
# ------------------------------------------------------------------

def test_sanitize_params_converts_nested_wrappers():
    nested = _Kwargs({"a": _Args([1, _Kwargs({"b": 2})])})
    result = _sanitize_params(nested)
    assert type(result) is dict
    assert type(result["a"]) is list
    assert type(result["a"][1]) is dict


def test_sanitize_params_passes_through_plain_values():
    assert _sanitize_params(42) == 42
    assert _sanitize_params("hello") == "hello"
    assert _sanitize_params(None) is None


# ------------------------------------------------------------------
# Basic instantiation
# ------------------------------------------------------------------

def test_instantiate_class_from_target():
    resolver = _resolver({
        "entry": {"_target": "srforge.data.Entry", "params": {"name": "test"}},
    })
    result = resolver.resolve_all()
    assert isinstance(result["entry"], Entry)
    assert result["entry"].name == "test"


def test_instantiate_with_no_params():
    resolver = _resolver({
        "entry": {"_target": "srforge.data.Entry"},
    })
    result = resolver.resolve_all()
    assert isinstance(result["entry"], Entry)


def test_instantiate_via_call():
    cfg = OmegaConf.create({
        "entry": {"_target": "srforge.data.Entry", "params": {"name": "via_call"}},
    })
    resolver = ConfigResolver(cfg)
    entry = resolver(cfg.entry)
    assert isinstance(entry, Entry)
    assert entry.name == "via_call"


# ------------------------------------------------------------------
# Reference resolution
# ------------------------------------------------------------------

def test_resolve_reference_string():
    resolver = _resolver({
        "shared": {"_target": "srforge.data.Entry", "params": {"name": "shared"}},
        "alias": "%{shared}",
    })
    result = resolver.resolve_all()
    assert result["alias"] is result["shared"]


def test_resolve_nested_reference():
    resolver = _resolver({
        "group": {
            "inner": {"_target": "srforge.data.Entry", "params": {"name": "inner"}},
        },
        "alias": "%{group.inner}",
    })
    result = resolver.resolve_all()
    assert result["alias"] is result["group"]["inner"]


def test_primitive_reference_raises():
    """Referencing a primitive via %{} should raise TypeError."""
    resolver = _resolver({
        "values": {"num": 7},
        "ref": "%{values.num}",
    })
    with pytest.raises(TypeError, match=r"resolved to a int value.*\$\{"):
        resolver.resolve_all()


def test_primitive_string_reference_raises():
    resolver = _resolver({
        "values": {"text": "hello"},
        "ref": "%{values.text}",
    })
    with pytest.raises(TypeError, match=r"resolved to a str value"):
        resolver.resolve_all()


def test_primitive_bool_reference_raises():
    resolver = _resolver({
        "values": {"flag": True},
        "ref": "%{values.flag}",
    })
    with pytest.raises(TypeError, match=r"resolved to a bool value"):
        resolver.resolve_all()


def test_reference_inside_params():
    resolver = _resolver({
        "shared": {"_target": "srforge.data.Entry", "params": {"name": "shared"}},
        "holder": {
            "_target": "srforge.data.Entry",
            "params": {"name": "holder", "ref": "%{shared}"},
        },
    })
    result = resolver.resolve_all()
    assert result["holder"].ref is result["shared"]


def test_non_reference_string_unchanged():
    resolver = _resolver({
        "plain": "just a string",
        "partial": "prefix %{not_a_ref}",
    })
    result = resolver.resolve_all()
    assert result["plain"] == "just a string"
    assert result["partial"] == "prefix %{not_a_ref}"


# ------------------------------------------------------------------
# Method call references
# ------------------------------------------------------------------

def test_method_call_reference():
    resolver = _resolver({
        "model": {"_target": "torch.nn.Linear", "params": {"in_features": 4, "out_features": 2}},
        "optimizer": {
            "_target": "torch.optim.SGD",
            "params": {"params": "%{model}.parameters()", "lr": 0.01},
        },
    })
    result = resolver.resolve_all()
    assert isinstance(result["optimizer"], torch.optim.SGD)
    assert len(result["optimizer"].param_groups[0]["params"]) == 2


# ------------------------------------------------------------------
# IO binding
# ------------------------------------------------------------------

def test_io_binding_on_model():
    resolver = _resolver({
        "model": {
            "_target": "srforge.models.basic.HR",
            "params": {},
            "io": {"inputs": {"hr": "x"}, "outputs": {"sr": "y"}},
        },
    })
    result = resolver.resolve_all()
    entry = Entry(x=torch.tensor([1.0]))
    out = result["model"](entry)
    assert torch.allclose(out.y, entry.x)


def test_io_binding_on_data_transform():
    resolver = _resolver({
        "transform": {
            "_target": "srforge.transform.data.Multiply",
            "params": {"value": 2.0},
            "io": {"inputs": {"image": "x"}, "outputs": "y"},
        },
    })
    result = resolver.resolve_all()
    assert result["transform"].resolved == {"x": "y"}
    entry = Entry(x=torch.tensor([1.0]))
    out = result["transform"](entry)
    assert torch.allclose(out.y, torch.tensor([2.0]))


def test_io_binding_on_entry_transform():
    resolver = _resolver({
        "transform": {
            "_target": "srforge.transform.entry.SetAttribute",
            "params": {"value": 5},
            "io": {"inputs": {}, "outputs": {"attr": "flag"}},
        },
    })
    result = resolver.resolve_all()
    entry = Entry()
    out = result["transform"](entry)
    assert out.flag == 5


def test_io_on_non_iomodule_raises():
    resolver = _resolver({
        "bad": {
            "_target": "torch.nn.Linear",
            "params": {"in_features": 2, "out_features": 1},
            "io": {"inputs": {"x": "y"}},
        },
    })
    with pytest.raises(TypeError, match="does not support io bindings"):
        resolver.resolve_all()


# ------------------------------------------------------------------
# Auto-path detection via __call__
# ------------------------------------------------------------------

def test_call_auto_registers_instance():
    cfg = OmegaConf.create({
        "shared": {"_target": "srforge.data.Entry", "params": {"name": "shared"}},
        "consumer": {
            "_target": "srforge.data.Entry",
            "params": {"name": "consumer", "ref": "%{shared}"},
        },
    })
    resolver = ConfigResolver(cfg)

    shared = resolver(cfg.shared)
    assert "shared" in resolver._instances
    assert resolver._instances["shared"] is shared

    consumer = resolver(cfg.consumer)
    assert consumer.ref is shared


# ------------------------------------------------------------------
# Error handling
# ------------------------------------------------------------------

def test_circular_reference_raises():
    resolver = _resolver({
        "a": "%{b}",
        "b": "%{a}",
    })
    with pytest.raises(ValueError, match="Circular reference"):
        resolver.resolve_all()


def test_invalid_path_raises():
    resolver = _resolver({
        "bad": "%{missing.path}",
    })
    with pytest.raises(KeyError):
        resolver.resolve_all()


def test_empty_reference_not_resolved():
    """Empty %{} is not a valid reference — treated as a plain string."""
    resolver = _resolver({
        "val": "%{}",
    })
    result = resolver.resolve_all()
    assert result["val"] == "%{}"


def test_invalid_target_raises():
    resolver = _resolver({
        "bad": {"_target": "nonexistent.module.ClassName", "params": {}},
    })
    with pytest.raises(ModuleNotFoundError):
        resolver.resolve_all()


# ------------------------------------------------------------------
# List and dict traversal
# ------------------------------------------------------------------

def test_list_config_resolved():
    resolver = _resolver({
        "items": [
            {"_target": "srforge.data.Entry", "params": {"name": "a"}},
            {"_target": "srforge.data.Entry", "params": {"name": "b"}},
        ],
    })
    result = resolver.resolve_all()
    assert len(result["items"]) == 2
    assert result["items"][0].name == "a"
    assert result["items"][1].name == "b"


def test_bracket_notation_reference():
    """Both %{items[0]} and %{items.0} resolve the same list element."""
    resolver = _resolver({
        "items": [
            {"_target": "srforge.data.Entry", "params": {"name": "first"}},
            {"_target": "srforge.data.Entry", "params": {"name": "second"}},
        ],
        "ref_bracket": "%{items[0]}",
        "ref_dot": "%{items.0}",
        "ref_nested": "%{items[1]}",
    })
    result = resolver.resolve_all()
    assert result["ref_bracket"] is result["items"][0]
    assert result["ref_dot"] is result["items"][0]
    assert result["ref_nested"] is result["items"][1]
    assert result["ref_bracket"].name == "first"


def test_nested_dict_config_resolved():
    resolver = _resolver({
        "group": {
            "x": {"_target": "srforge.data.Entry", "params": {"name": "x"}},
            "y": {"_target": "srforge.data.Entry", "params": {"name": "y"}},
        },
    })
    result = resolver.resolve_all()
    assert result["group"]["x"].name == "x"
    assert result["group"]["y"].name == "y"


# ------------------------------------------------------------------
# resolve_all with mixed content
# ------------------------------------------------------------------

def test_resolve_all_mixed():
    resolver = _resolver({
        "num": 42,
        "text": "hello",
        "entry": {"_target": "srforge.data.Entry", "params": {"name": "e"}},
    })
    result = resolver.resolve_all()
    assert result["num"] == 42
    assert result["text"] == "hello"
    assert isinstance(result["entry"], Entry)


# ------------------------------------------------------------------
# ClassRegistry short names
# ------------------------------------------------------------------

def test_registry_short_name():
    resolver = _resolver({
        "entry": {"_target": "LazyDataset", "params": {"root": "/tmp", "mappings": {}}},
    })
    from srforge.dataset.lazy_datasets import LazyDataset
    result = resolver.resolve_all()
    assert isinstance(result["entry"], LazyDataset)


# ------------------------------------------------------------------
# ${ref:...} OmegaConf resolver syntax
# ------------------------------------------------------------------

def _resolver_from_yaml(yaml_str):
    """Create a ConfigResolver from a YAML string (tests OmegaConf interpolation)."""
    cfg = OmegaConf.create(yaml_str)
    return ConfigResolver(cfg)


def test_ref_resolver_simple():
    """${ref:path} resolves to the same object as %{path}."""
    resolver = _resolver_from_yaml("""\
shared:
  _target: srforge.data.Entry
  params:
    name: shared
alias: ${ref:shared}
""")
    result = resolver.resolve_all()
    assert result["alias"] is result["shared"]


def test_ref_resolver_nested_path():
    """${ref:dotted.path} resolves nested config paths."""
    resolver = _resolver_from_yaml("""\
group:
  inner:
    _target: srforge.data.Entry
    params:
      name: inner
alias: ${ref:group.inner}
""")
    result = resolver.resolve_all()
    assert result["alias"] is result["group"]["inner"]


def test_ref_resolver_method_chain():
    """${ref:model}.method() calls the method on the resolved object."""
    resolver = _resolver_from_yaml("""\
model:
  _target: torch.nn.Linear
  params:
    in_features: 4
    out_features: 2
optimizer:
  _target: torch.optim.SGD
  params:
    params: ${ref:model}.parameters()
    lr: 0.01
""")
    result = resolver.resolve_all()
    assert isinstance(result["optimizer"], torch.optim.SGD)
    assert len(result["optimizer"].param_groups[0]["params"]) == 2


def test_ref_resolver_inside_params():
    """${ref:path} works inside a params block."""
    resolver = _resolver_from_yaml("""\
shared:
  _target: srforge.data.Entry
  params:
    name: shared
holder:
  _target: srforge.data.Entry
  params:
    name: holder
    ref: ${ref:shared}
""")
    result = resolver.resolve_all()
    assert result["holder"].ref is result["shared"]


def test_ref_resolver_primitive_guard():
    """${ref:path} to a primitive still raises TypeError."""
    resolver = _resolver_from_yaml("""\
values:
  num: 7
bad: ${ref:values.num}
""")
    with pytest.raises(TypeError, match=r"resolved to a int value"):
        resolver.resolve_all()
