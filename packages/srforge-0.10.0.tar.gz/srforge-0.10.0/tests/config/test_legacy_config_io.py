import warnings
from types import SimpleNamespace

import pytest
import torch
from omegaconf import OmegaConf

from srforge.config.legacy import ConfigParser
from srforge.data import Entry
from srforge.models import SequentialModel


def _make_parser(config=None):
    run = SimpleNamespace(resumed=False, id="dummy", summary={})
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", DeprecationWarning)
        return ConfigParser(config=config or {}, run=run)


def test_config_parser_binds_entry_transform_io():
    parser = _make_parser()
    cfg = OmegaConf.create(
        {
            "_target": "srforge.transform.entry.SetAttribute",
            "params": {"value": 5},
            "io": {"inputs": {}, "outputs": {"attr": "flag"}},
        }
    )

    transform = parser._load_class_from_config(cfg)

    entry = Entry()
    out = transform(entry)

    assert transform.attr == "flag"
    assert out.flag == 5


def test_config_parser_binds_model_io():
    parser = _make_parser()
    cfg = OmegaConf.create(
        {
            "_target": "srforge.models.basic.HR",
            "params": {},
            "io": {"inputs": {"hr": "x"}, "outputs": {"sr": "y"}},
        }
    )

    model = parser._load_class_from_config(cfg)

    entry = Entry(x=torch.tensor([1.0]))
    out = model(entry)

    assert torch.allclose(out.y, entry.x)
    assert "x" in out


def test_config_parser_binds_data_transform_io():
    parser = _make_parser()
    cfg = OmegaConf.create(
        {
            "_target": "srforge.transform.data.Multiply",
            "params": {"value": 2.0},
            "io": {"inputs": {"image": "x"}, "outputs": "y"},
        }
    )

    transform = parser._load_class_from_config(cfg)

    assert transform.resolved == {"x": "y"}
    entry = Entry(x=torch.tensor([1.0]))
    out = transform(entry)
    assert torch.allclose(out.y, torch.tensor([2.0]))
    assert torch.allclose(transform.transform(torch.tensor([1.0])), torch.tensor([2.0]))


def test_config_parser_builds_sequential_model_from_config():
    parser = _make_parser()
    cfg = OmegaConf.create(
        {
            "_target": "srforge.models.SequentialModel",
            "params": {
                "models": {
                    "m1": {"_target": "srforge.models.basic.HR", "params": {}},
                    "t1": {
                        "_target": "srforge.transform.entry.CopyFields",
                        "params": {},
                        "io": {"inputs": {"field": "y"}, "outputs": {"output": "z"}},
                    },
                    "mul": {"_target": "srforge.transform.data.Multiply", "params": {"value": 2.0}},
                },
                "flow": {
                    "flow": [
                        "x -> m1 -> y",
                        "y -> t1 -> z",
                        "z -> mul -> out",
                    ]
                },
            },
        }
    )

    model = parser._load_class_from_config(cfg)

    assert isinstance(model, SequentialModel)
    entry = Entry(x=torch.tensor([1.0]))
    out = model(entry)

    assert torch.allclose(out.x, torch.tensor([1.0]))
    assert torch.allclose(out.y, torch.tensor([1.0]))
    assert torch.allclose(out.z, torch.tensor([1.0]))
    assert torch.allclose(out.out, torch.tensor([2.0]))


def test_config_parser_sequential_entry_transform_io_inferred_from_flow():
    """EntryTransform IO is inferred from the flow DSL — no 'io:' key needed."""
    parser = _make_parser()
    cfg = OmegaConf.create(
        {
            "_target": "srforge.models.SequentialModel",
            "params": {
                "models": {
                    "m1": {"_target": "srforge.models.basic.HR", "params": {}},
                    "t1": {"_target": "srforge.transform.entry.CopyFields", "params": {}},
                },
                "flow": {"flow": ["x -> m1 -> y", "y -> t1 -> z"]},
            },
        }
    )

    model = parser._load_class_from_config(cfg)

    assert isinstance(model, SequentialModel)
    entry = Entry(x=torch.tensor([1.0]))
    out = model(entry)

    assert torch.allclose(out.x, torch.tensor([1.0]))
    assert torch.allclose(out.y, torch.tensor([1.0]))
    assert torch.allclose(out.z, torch.tensor([1.0]))


def test_config_parser_resolves_reference_string():
    cfg = OmegaConf.create(
        {
            "model": {"_target": "srforge.models.basic.HR", "params": {}},
            "alias": "%{model}",
        }
    )
    parser = _make_parser(config=cfg)

    resolved = parser.resolve_all()

    assert "model" in resolved
    assert resolved["alias"] is resolved["model"]
    from srforge.models import Model
    assert isinstance(resolved["alias"], Model)
    assert isinstance(resolved["model"], Model)


def test_config_parser_resolves_nested_references_to_same_instance():
    cfg = OmegaConf.create(
        {
            "shared": {"_target": "srforge.data.Entry", "params": {"name": "shared"}},
            "holder": {
                "_target": "srforge.data.Entry",
                "params": {"name": "holder", "ref": "%{shared}"},
            },
            "alias": "%{group.inner}",
            "list_ref": ["%{shared}", "%{group.inner}"],
            "dict_ref": {"a": "%{shared}", "b": "%{group.inner}"},
            "group": {
                "inner": {"_target": "srforge.data.Entry", "params": {"name": "inner"}},
            },
        }
    )
    parser = _make_parser(config=cfg)

    resolved = parser.resolve_all()

    assert resolved["holder"].ref is resolved["shared"]
    assert resolved["alias"] is resolved["group"]["inner"]
    assert resolved["list_ref"][0] is resolved["shared"]
    assert resolved["list_ref"][1] is resolved["group"]["inner"]
    assert resolved["dict_ref"]["a"] is resolved["shared"]
    assert resolved["dict_ref"]["b"] is resolved["group"]["inner"]


def test_config_parser_primitive_reference_raises():
    cfg = OmegaConf.create(
        {
            "values": {"num": 7},
            "ref": "%{values.num}",
        }
    )
    parser = _make_parser(config=cfg)
    with pytest.raises(TypeError, match=r"resolved to a int value"):
        parser.resolve_all()


def test_config_parser_container_references_and_keeps_literals():
    cfg = OmegaConf.create(
        {
            "values_list": [1, 2, 3],
            "values_dict": {"a": 1, "b": 2},
            "list_alias": "%{values_list}",
            "dict_alias": "%{values_dict}",
            "literal": "prefix %{values.text}",
        }
    )
    parser = _make_parser(config=cfg)

    resolved = parser.resolve_all()

    assert resolved["list_alias"] is resolved["values_list"]
    assert resolved["dict_alias"] is resolved["values_dict"]
    assert resolved["literal"] == "prefix %{values.text}"


def test_config_parser_call_auto_registers_instances():
    """parser(cfg.X) auto-registers the result so %{X} resolves without manual bookkeeping."""
    cfg = OmegaConf.create(
        {
            "shared": {"_target": "srforge.data.Entry", "params": {"name": "shared"}},
            "consumer": {
                "_target": "srforge.data.Entry",
                "params": {"name": "consumer", "ref": "%{shared}"},
            },
        }
    )
    parser = _make_parser(config=cfg)

    # Call parser(cfg.shared) — should auto-register as "shared"
    shared = parser(cfg.shared)
    assert "shared" in parser._instances
    assert parser._instances["shared"] is shared

    # Now parse consumer which uses %{shared} — should resolve to same instance
    consumer = parser(cfg.consumer)
    assert consumer.ref is shared


def test_config_parser_method_call_reference():
    """References with () call the method on the resolved object."""
    cfg = OmegaConf.create(
        {
            "model": {"_target": "torch.nn.Linear", "params": {"in_features": 4, "out_features": 2}},
            "optimizer": {
                "_target": "torch.optim.SGD",
                "params": {"params": "%{model}.parameters()", "lr": 0.01},
            },
        }
    )
    parser = _make_parser(config=cfg)

    resolved = parser.resolve_all()

    assert isinstance(resolved["optimizer"], torch.optim.SGD)
    assert len(resolved["optimizer"].param_groups[0]["params"]) == 2  # weight + bias


def test_config_parser_invalid_reference_raises():
    cfg = OmegaConf.create(
        {
            "bad": "%{missing.path}",
        }
    )
    parser = _make_parser(config=cfg)

    with pytest.raises(KeyError):
        parser.resolve_all()
