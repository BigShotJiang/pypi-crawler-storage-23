"""Tests for LossScheduler — callable delegation and epoch-based switching."""

import pytest
import torch

from srforge.data import Entry
from srforge.loss import Loss, LossCombiner
from srforge.loss.schedule import LossScheduler
from srforge.loss.storage import MetricScores


# ── Minimal concrete Loss for testing ────────────────────────────────────

class _ConstLoss(Loss):
    """Loss that always returns a fixed value (useful for asserting which loss is active)."""

    def __init__(self, value: float, **kwargs):
        super().__init__(**kwargs)
        self._value = value

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        return torch.tensor(self._value).expand_as(x)


def _make_entry():
    return Entry(x=torch.ones(1, 1, 4, 4), y=torch.zeros(1, 1, 4, 4))


# ── Tests ────────────────────────────────────────────────────────────────

class TestLossSchedulerCallable:
    def test_call_delegates_to_current_loss(self):
        loss_a = _ConstLoss(1.0, name="A")
        scheduler = LossScheduler({0: loss_a})

        scores = scheduler(_make_entry())

        assert isinstance(scores, MetricScores)
        assert "A" in scores.metrics

    def test_call_with_positional_args(self):
        loss_a = _ConstLoss(1.0, name="A")
        scheduler = LossScheduler({0: loss_a})

        x = torch.ones(1, 1, 4, 4)
        y = torch.zeros(1, 1, 4, 4)
        scores = scheduler(x, y)

        assert isinstance(scores, MetricScores)

    def test_call_with_keyword_args(self):
        loss_a = _ConstLoss(1.0, name="A")
        scheduler = LossScheduler({0: loss_a})

        scores = scheduler(x=torch.ones(1, 1, 4, 4), y=torch.zeros(1, 1, 4, 4))

        assert isinstance(scores, MetricScores)


class TestLossSchedulerUpdate:
    def test_update_switches_active_loss(self):
        loss_a = _ConstLoss(1.0, name="A")
        loss_b = _ConstLoss(2.0, name="B")
        scheduler = LossScheduler({0: loss_a, 10: loss_b})

        # Before milestone 10 → loss_a
        scores_before = scheduler(_make_entry())
        assert "A" in scores_before.metrics

        # After milestone 10 → loss_b
        scheduler.update(10)
        scores_after = scheduler(_make_entry())
        assert "B" in scores_after.metrics

    def test_update_returns_self_for_chaining(self):
        loss_a = _ConstLoss(1.0, name="A")
        scheduler = LossScheduler({0: loss_a})

        result = scheduler.update(5)

        assert result is scheduler

    def test_update_with_epoch_between_milestones(self):
        loss_a = _ConstLoss(1.0, name="A")
        loss_b = _ConstLoss(2.0, name="B")
        scheduler = LossScheduler({0: loss_a, 50: loss_b})

        scheduler.update(25)
        assert scheduler.get_loss_fn() is loss_a

        scheduler.update(75)
        assert scheduler.get_loss_fn() is loss_b

    def test_start_epoch_sets_correct_initial_loss(self):
        loss_a = _ConstLoss(1.0, name="A")
        loss_b = _ConstLoss(2.0, name="B")
        scheduler = LossScheduler({0: loss_a, 10: loss_b}, start_epoch=15)

        assert scheduler.get_loss_fn() is loss_b


class TestLossSchedulerGetLossFn:
    def test_get_loss_fn_returns_current_loss(self):
        loss_a = _ConstLoss(1.0, name="A")
        scheduler = LossScheduler({0: loss_a})

        assert scheduler.get_loss_fn() is loss_a

    def test_get_loss_fn_reflects_update(self):
        loss_a = _ConstLoss(1.0, name="A")
        loss_b = _ConstLoss(2.0, name="B")
        scheduler = LossScheduler({0: loss_a, 10: loss_b})

        scheduler.update(10)
        assert scheduler.get_loss_fn() is loss_b


class TestLossSchedulerValidation:
    def test_missing_epoch_zero_raises(self):
        loss_a = _ConstLoss(1.0, name="A")

        with pytest.raises(ValueError, match="key 0"):
            LossScheduler({5: loss_a})


class TestLossSchedulerWithCombiner:
    def test_scheduler_wrapping_combiner(self):
        """LossScheduler wrapping a LossCombiner — the real-world config pattern."""
        combiner = LossCombiner([
            _ConstLoss(1.0, name="L1"),
            _ConstLoss(0.5, name="SSIM"),
        ])
        scheduler = LossScheduler({0: combiner})

        scores = scheduler(_make_entry())

        assert isinstance(scores, MetricScores)
        assert "L1" in scores.metrics
        assert "SSIM" in scores.metrics


class TestLossSchedulerAsRunnerCriterion:
    def test_runner_calling_scheduler_directly(self):
        """Simulate what a runner does: call self._criterion(entry)."""
        loss_a = _ConstLoss(1.0, name="A")
        loss_b = _ConstLoss(2.0, name="B")
        scheduler = LossScheduler({0: loss_a, 10: loss_b})

        # Epoch 0: runner sees loss_a's output
        entry = _make_entry()
        scores_0 = scheduler(entry)
        raw_0 = scores_0.as_raw_dict()["A"]

        # Epoch 10: update, then runner sees loss_b's output
        scheduler.update(10)
        scores_10 = scheduler(entry)
        raw_10 = scores_10.as_raw_dict()["B"]

        assert torch.allclose(raw_0, torch.tensor(1.0))
        assert torch.allclose(raw_10, torch.tensor(2.0))
