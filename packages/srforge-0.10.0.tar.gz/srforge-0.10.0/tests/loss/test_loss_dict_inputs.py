import pytest
import torch

from srforge.data import Entry
from srforge.loss import Loss


class _ScalarL1(Loss):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_io({"inputs": {"pred": "y", "target": "t"}})

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return (pred - target).abs()


class _DictL1(Loss):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_io({"inputs": {"pred": "y", "target": "t"}})

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(
        self,
        pred: dict[str, torch.Tensor],
        target: dict[str, torch.Tensor],
    ) -> dict[str, torch.Tensor]:
        return {k: (pred[k] - target[k]).abs() for k in pred.keys()}


class TestLossDictInputs:
    def test_dict_inputs_split_per_band_when_unannotated(self):
        entry = Entry(
            y={"b1": torch.tensor([1.0]), "b2": torch.tensor([2.0])},
            t={"b1": torch.tensor([0.0]), "b2": torch.tensor([4.0])},
        )
        loss = _ScalarL1()

        scores = loss(entry)
        raw = scores.as_raw_dict()["_ScalarL1"]

        assert "_ScalarL1" in scores.as_raw_dict()
        assert set(raw.keys()) == {"b1", "b2"}
        assert torch.allclose(raw["b1"], torch.tensor([1.0]))
        assert torch.allclose(raw["b2"], torch.tensor([2.0]))
        assert set(entry.keys()) == {"name", "y", "t"}

    def test_dict_inputs_require_common_keys(self):
        entry = Entry(
            y={"b1": torch.tensor([1.0])},
            t={"b2": torch.tensor([1.0])},
        )
        loss = _ScalarL1()

        with pytest.raises(ValueError) as exc:
            loss(entry)
        assert "keys" in str(exc.value).lower()

    def test_dict_annotations_disable_band_splitting(self):
        entry = Entry(
            y={"b1": torch.tensor([1.0]), "b2": torch.tensor([2.0])},
            t={"b1": torch.tensor([0.0]), "b2": torch.tensor([4.0])},
        )
        loss = _DictL1()

        scores = loss(entry)
        raw = scores.as_raw_dict()["_DictL1"]

        assert "_DictL1" in scores.as_raw_dict()
        assert set(raw.keys()) == {"b1", "b2"}
        assert torch.allclose(raw["b1"], torch.tensor([1.0]))
        assert torch.allclose(raw["b2"], torch.tensor([2.0]))

    def test_dict_annotations_reject_tensor_inputs(self):
        entry = Entry(y=torch.tensor([1.0]), t=torch.tensor([3.0]))
        loss = _DictL1()

        with pytest.raises(TypeError) as exc:
            loss(entry)
        assert "dict" in str(exc.value).lower()
