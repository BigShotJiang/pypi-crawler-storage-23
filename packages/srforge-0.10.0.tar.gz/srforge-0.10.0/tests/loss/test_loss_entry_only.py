import pytest
import torch

from srforge.data import Entry, GraphEntry, _HAS_PYG
from srforge.loss import Loss, LossCombiner

needs_pyg = pytest.mark.skipif(not _HAS_PYG, reason="torch-geometric not installed")


class _AbsDiff(Loss):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_io({"inputs": {"pred": "y", "target": "t"}})

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return (pred - target).abs()


class _SignedDiff(Loss):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_io({"inputs": {"pred": "y", "target": "t"}})

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return pred - target


def test_loss_reads_from_entry():
    entry = Entry(y=torch.tensor([1.0]), t=torch.tensor([3.0]))
    loss = _AbsDiff()

    scores = loss(entry)

    assert "_AbsDiff" in scores.metrics
    assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([2.0]))
    assert set(entry.keys()) == {"name", "y", "t"}


@needs_pyg
def test_loss_reads_from_graph_entry():
    entry = GraphEntry(name="graph", y=torch.tensor([1.0]), t=torch.tensor([3.0]))
    loss = _AbsDiff()

    scores = loss(entry)

    assert "_AbsDiff" in scores.metrics
    assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([2.0]))


def test_loss_accepts_entry_keyword():
    entry = Entry(y=torch.tensor([1.0]), t=torch.tensor([3.0]))
    loss = _AbsDiff()

    scores = loss(entry=entry)

    assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([2.0]))
    assert "y" in entry and "t" in entry


@needs_pyg
def test_loss_accepts_graph_entry_keyword():
    entry = GraphEntry(name="graph", y=torch.tensor([1.0]), t=torch.tensor([3.0]))
    loss = _AbsDiff()

    scores = loss(entry=entry)

    assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([2.0]))


def test_loss_rejects_entry_keyword_with_other_kwargs():
    entry = Entry(y=torch.tensor([1.0]), t=torch.tensor([3.0]))
    loss = _AbsDiff()

    with pytest.raises(TypeError) as exc:
        loss(entry=entry, y=torch.tensor([1.0]))
    assert "entry" in str(exc.value).lower()


def test_loss_rejects_entry_keyword_with_positional_args():
    entry = Entry(y=torch.tensor([1.0]), t=torch.tensor([3.0]))
    loss = _AbsDiff()

    with pytest.raises(TypeError) as exc:
        loss(torch.tensor([1.0]), entry=entry)
    assert "entry" in str(exc.value).lower()


def test_loss_missing_key_raises():
    entry = Entry(y=torch.tensor([1.0]))
    loss = _AbsDiff()

    with pytest.raises(KeyError) as exc:
        loss(entry)
    assert "t" in str(exc.value)


def test_loss_accepts_positional_args_in_signature_order():
    loss = _AbsDiff()
    pred = torch.tensor([1.0])
    target = torch.tensor([3.0])

    scores = loss(pred, target)

    assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([2.0]))


def test_loss_accepts_kwargs_in_entry_namespace():
    loss = _AbsDiff()
    scores = loss(y=torch.tensor([1.0]), t=torch.tensor([3.0]))

    assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([2.0]))


def test_loss_rejects_kwargs_in_param_namespace_when_mapped():
    loss = _AbsDiff()
    with pytest.raises(KeyError) as exc:
        loss(pred=torch.tensor([1.0]), target=torch.tensor([3.0]))
    assert "parameter" in str(exc.value).lower() or "y" in str(exc.value).lower()


def test_loss_rejects_mixed_args_and_kwargs():
    loss = _AbsDiff()
    with pytest.raises(TypeError) as exc:
        loss(torch.tensor([1.0]), target=torch.tensor([3.0]))
    assert "args" in str(exc.value).lower() or "positional" in str(exc.value).lower()


def test_loss_rejects_incorrect_arg_length():
    loss = _AbsDiff()
    with pytest.raises(TypeError) as exc:
        loss(torch.tensor([1.0]))
    assert "expected" in str(exc.value).lower() or "arguments" in str(exc.value).lower()


def test_loss_positional_order_is_respected():
    loss = _SignedDiff()
    scores = loss(torch.tensor([1.0]), torch.tensor([3.0]))
    swapped = loss(torch.tensor([3.0]), torch.tensor([1.0]))

    assert torch.allclose(scores.as_raw_dict()["_SignedDiff"], torch.tensor([-2.0]))
    assert torch.allclose(swapped.as_raw_dict()["_SignedDiff"], torch.tensor([2.0]))


def test_loss_combiner_uses_entry_only():
    entry = Entry(y=torch.tensor([1.0]), t=torch.tensor([3.0]))
    loss1 = _AbsDiff(name="L1")
    loss2 = _AbsDiff(name="L2")
    combiner = LossCombiner([loss1, loss2])

    scores = combiner(entry)

    assert set(scores.metrics.keys()) == {"L1", "L2"}
    raw = scores.as_raw_dict()
    assert torch.allclose(raw["L1"], torch.tensor([2.0]))
    assert torch.allclose(raw["L2"], torch.tensor([2.0]))
