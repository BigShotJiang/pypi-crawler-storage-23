import pytest
import torch

from srforge.data import Entry
from srforge.loss import Loss, cLossCombiner


class _TinyLoss(Loss):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(
        self,
        x: torch.Tensor,
        y: torch.Tensor,
        y_mask: torch.Tensor | None = None,
    ) -> torch.Tensor:
        dims = tuple(range(1, x.dim()))
        return (x - y).abs().mean(dim=dims)


class TestCLossCombiner:
    def test_renames_losses_with_c_prefix(self):
        base = _TinyLoss(name="L1")
        combiner = cLossCombiner([base], border=0, do_correction=False)

        assert base.name == "cL1"
        assert "cL1" in combiner.name
        assert combiner.losses[0].name == "cL1"

    def test_forward_returns_metric_scores(self):
        base = _TinyLoss(name="L1")
        combiner = cLossCombiner([base], border=0, do_correction=False)
        entry = Entry(
            x=torch.zeros((1, 1, 2, 2), dtype=torch.float32),
            y=torch.zeros((1, 1, 2, 2), dtype=torch.float32),
        )

        scores = combiner(entry)
        raw = scores.as_raw_dict()["cL1"]

        assert "cL1" in scores.as_raw_dict()
        assert raw.shape == (1,)
        assert torch.allclose(raw, torch.zeros_like(raw))

    def test_missing_required_keys_raises(self):
        base = _TinyLoss(name="L1")
        combiner = cLossCombiner([base], border=0, do_correction=False)
        entry = Entry(y=torch.zeros((1, 1, 2, 2), dtype=torch.float32))

        with pytest.raises(KeyError) as exc:
            combiner(entry)
        assert "x" in str(exc.value) or "missing" in str(exc.value).lower()
