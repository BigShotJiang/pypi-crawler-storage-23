"""Tests for Loss.set_io() — unified IO binding on Loss."""

import pytest
import torch

from srforge.data import Entry
from srforge.loss import Loss
from srforge.utils.iomodule import IOModule


class _L1(Loss):
    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        return (x - y).abs().mean(dim=(-3, -2, -1))


class _WithMask(Loss):
    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(
        self, x: torch.Tensor, y: torch.Tensor, y_mask: torch.Tensor = None
    ) -> torch.Tensor:
        if y_mask is not None:
            x = x * y_mask
            y = y * y_mask
        return (x - y).abs().mean(dim=(-3, -2, -1))


# -- IOModule inheritance ---------------------------------------------------

class TestLossIsIOModule:
    def test_isinstance(self):
        assert isinstance(_L1(), IOModule)

    def test_no_io_port_descriptors(self):
        """Loss sets _install_io_ports = False — no _IOPort descriptors."""
        loss = _L1()
        # Should be able to set arbitrary attributes without _IOPort blocking
        loss.x = 42
        assert loss.x == 42


# -- set_io() ---------------------------------------------------------------

class TestSetIo:
    def test_basic(self):
        loss = _L1()
        loss.set_io({"inputs": {"x": "sr", "y": "hr"}})
        assert loss._input_map == {"x": "sr", "y": "hr"}

    def test_returns_self(self):
        loss = _L1()
        result = loss.set_io({"inputs": {"x": "sr", "y": "hr"}})
        assert result is loss

    def test_chainable(self):
        loss = _L1().set_io({"inputs": {"x": "sr", "y": "hr"}})
        assert loss._input_map == {"x": "sr", "y": "hr"}

    def test_partial_mapping(self):
        """Mapping only some params — unmapped keep identity default."""
        loss = _WithMask()
        loss.set_io({"inputs": {"x": "sr", "y": "hr"}})
        # x and y are remapped; y_mask keeps its identity default
        assert loss._input_map == {"x": "sr", "y": "hr", "y_mask": "y_mask"}

    def test_rejects_outputs(self):
        loss = _L1()
        with pytest.raises(TypeError, match="don't produce outputs"):
            loss.set_io({"inputs": {"x": "sr", "y": "hr"}, "outputs": "result"})

    def test_rejects_list_inputs(self):
        loss = _L1()
        with pytest.raises(TypeError, match="must be a dict"):
            loss.set_io({"inputs": [{"x": "a"}, {"x": "b"}]})

    def test_rejects_unknown_param(self):
        loss = _L1()
        with pytest.raises(ValueError, match="not found in calculate_score"):
            loss.set_io({"inputs": {"x": "sr", "y": "hr", "z": "extra"}})

    def test_rejects_non_dict_config(self):
        loss = _L1()
        with pytest.raises(TypeError, match="must be a dict with an 'inputs' key"):
            loss.set_io("x")

    def test_rejects_missing_inputs_key(self):
        loss = _L1()
        with pytest.raises(TypeError, match="must be a dict with an 'inputs' key"):
            loss.set_io({"outputs": "sr"})


# -- Identity default -------------------------------------------------------

class TestIdentityDefault:
    def test_identity_default_works(self):
        """No set_io() — params map to same-named Entry fields."""
        loss = _L1()
        entry = Entry(x=torch.tensor([[[[1.0]]]]), y=torch.tensor([[[[3.0]]]]))

        scores = loss(entry)

        assert torch.allclose(scores.as_raw_dict()["_L1"], torch.tensor([2.0]))

    def test_set_io_overrides_identity(self):
        """set_io() remaps params to different Entry fields."""
        loss = _L1()
        loss.set_io({"inputs": {"x": "prediction", "y": "target"}})

        entry = Entry(prediction=torch.tensor([[[[1.0]]]]), target=torch.tensor([[[[3.0]]]]))
        scores = loss(entry)

        assert torch.allclose(scores.as_raw_dict()["_L1"], torch.tensor([2.0]))

    def test_identity_default_missing_field_raises(self):
        """Identity maps x→x, but Entry has no 'x' field."""
        loss = _L1()
        entry = Entry(sr=torch.tensor([1.0]), hr=torch.tensor([3.0]))

        with pytest.raises(KeyError, match="x"):
            loss(entry)
