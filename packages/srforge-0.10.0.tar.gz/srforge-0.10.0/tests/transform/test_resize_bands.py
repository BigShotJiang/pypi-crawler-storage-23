"""Tests for ResizeBandsToCommonResolution (DataTransform version)."""

import pytest
import torch

from srforge.data import Entry
from srforge.transform.data import ResizeBandsToCommonResolution


def _tensor(shape, value=1.0):
    return torch.full(shape, value, dtype=torch.float32)


# ── Standalone transform (no Entry, no IO) ────────────────────────────

class TestStandaloneTransform:

    def test_upsample_smaller_band(self):
        bands = {
            "b1": _tensor((1, 1, 2, 2), 1.0),
            "b2": _tensor((1, 1, 4, 4), 2.0),
        }
        result = ResizeBandsToCommonResolution().transform(bands)

        assert result["b1"].shape[-2:] == (4, 4)
        assert result["b2"].shape[-2:] == (4, 4)
        # b2 unchanged (already at target size)
        assert torch.equal(result["b2"], bands["b2"])

    def test_all_same_size_is_noop(self):
        bands = {
            "b1": _tensor((1, 1, 4, 4), 1.0),
            "b2": _tensor((1, 1, 4, 4), 2.0),
        }
        result = ResizeBandsToCommonResolution().transform(bands)

        assert torch.equal(result["b1"], bands["b1"])
        assert torch.equal(result["b2"], bands["b2"])

    def test_three_bands_different_sizes(self):
        bands = {
            "b1": _tensor((1, 1, 2, 2)),
            "b2": _tensor((1, 1, 4, 4)),
            "b3": _tensor((1, 1, 8, 8)),
        }
        result = ResizeBandsToCommonResolution().transform(bands)

        assert result["b1"].shape[-2:] == (8, 8)
        assert result["b2"].shape[-2:] == (8, 8)
        assert result["b3"].shape[-2:] == (8, 8)

    def test_single_sample_4d_tensor(self):
        bands = {
            "b1": _tensor((1, 1, 2, 2)),
            "b2": _tensor((1, 1, 4, 4)),
        }
        result = ResizeBandsToCommonResolution().transform(bands)

        assert result["b1"].shape == (1, 1, 4, 4)
        assert result["b2"].shape == (1, 1, 4, 4)

    def test_5d_tensor(self):
        bands = {
            "b1": _tensor((2, 1, 3, 2, 2)),
            "b2": _tensor((2, 1, 3, 4, 4)),
        }
        result = ResizeBandsToCommonResolution().transform(bands)

        assert result["b1"].shape == (2, 1, 3, 4, 4)
        assert result["b2"].shape == (2, 1, 3, 4, 4)

    def test_non_tensor_values_preserved(self):
        bands = {
            "b1": _tensor((1, 1, 2, 2)),
            "b2": _tensor((1, 1, 4, 4)),
            "meta": "some_string",
        }
        result = ResizeBandsToCommonResolution().transform(bands)

        assert result["meta"] == "some_string"
        assert result["b1"].shape[-2:] == (4, 4)

    def test_non_dict_input_passthrough(self):
        tensor = _tensor((1, 1, 4, 4))
        result = ResizeBandsToCommonResolution().transform(tensor)
        assert torch.equal(result, tensor)

    def test_interpolation_mode_bilinear(self):
        bands = {
            "b1": _tensor((1, 1, 2, 2), 1.0),
            "b2": _tensor((1, 1, 4, 4), 2.0),
        }
        result = ResizeBandsToCommonResolution(
            interpolation_mode="bilinear"
        ).transform(bands)

        assert result["b1"].shape[-2:] == (4, 4)

    def test_min_strategy_raises(self):
        bands = {"b1": _tensor((1, 1, 2, 2))}
        with pytest.raises(NotImplementedError, match="min"):
            ResizeBandsToCommonResolution(strategy="min").transform(bands)

    def test_unsupported_dim_raises(self):
        bands = {"b1": _tensor((2, 2)), "b2": _tensor((4, 4))}
        with pytest.raises(TypeError, match="Unsupported tensor dim=2"):
            ResizeBandsToCommonResolution().transform(bands)


# ── With Entry via set_io ─────────────────────────────────────────────

class TestWithEntry:

    def test_simple_string_in_place(self):
        """In-place set_io works — field: dict annotation skips recursion."""
        entry = Entry(
            lrs={
                "b1": _tensor((1, 1, 2, 2), 1.0),
                "b2": _tensor((1, 1, 4, 4), 2.0),
            }
        )
        t = ResizeBandsToCommonResolution().set_io({"inputs": {"field": "lrs"}})
        result = t(entry)

        assert result["lrs"]["b1"].shape[-2:] == (4, 4)
        assert result["lrs"]["b2"].shape[-2:] == (4, 4)

    def test_flat_dict_rename(self):
        """Structured inputs/outputs works for renaming output."""
        entry = Entry(
            lrs={
                "b1": _tensor((1, 1, 2, 2), 1.0),
                "b2": _tensor((1, 1, 4, 4), 2.0),
            }
        )
        t = ResizeBandsToCommonResolution().set_io({"inputs": {"field": "lrs"}, "outputs": "resized"})
        result = t(entry)

        assert result["resized"]["b1"].shape[-2:] == (4, 4)
        # Original unchanged
        assert result["lrs"]["b1"].shape[-2:] == (2, 2)

    def test_dict_inputs_syntax(self):
        """Dict-inputs syntax still works."""
        entry = Entry(
            lrs={
                "b1": _tensor((1, 1, 2, 2), 1.0),
                "b2": _tensor((1, 1, 4, 4), 2.0),
            }
        )
        t = ResizeBandsToCommonResolution().set_io({
            "inputs": {"field": "lrs"}, "outputs": "lrs",
        })
        result = t(entry)

        assert result["lrs"]["b1"].shape[-2:] == (4, 4)
        assert result["lrs"]["b2"].shape[-2:] == (4, 4)

    def test_list_multiple_fields(self):
        """List config processes multiple fields independently."""
        entry = Entry(
            lrs={
                "b1": _tensor((1, 1, 2, 2)),
                "b2": _tensor((1, 1, 4, 4)),
            },
            hr={
                "b1": _tensor((1, 1, 4, 4)),
                "b2": _tensor((1, 1, 8, 8)),
            },
        )
        t = ResizeBandsToCommonResolution().set_io({"inputs": [{"field": "lrs"}, {"field": "hr"}]})
        result = t(entry)

        assert result["lrs"]["b1"].shape[-2:] == (4, 4)
        assert result["hr"]["b1"].shape[-2:] == (8, 8)

    def test_structured_string_sections(self):
        """{"inputs": {"field": "lrs"}, "outputs": "resized"} works."""
        entry = Entry(
            lrs={
                "b1": _tensor((1, 1, 2, 2), 1.0),
                "b2": _tensor((1, 1, 4, 4), 2.0),
            }
        )
        t = ResizeBandsToCommonResolution().set_io({
            "inputs": {"field": "lrs"}, "outputs": "resized",
        })
        result = t(entry)

        assert result["resized"]["b1"].shape[-2:] == (4, 4)
        assert result["resized"]["b2"].shape[-2:] == (4, 4)


# ── Registry ──────────────────────────────────────────────────────────

class TestRegistry:

    def test_registered(self):
        from srforge.registry import ClassRegistry
        assert "ResizeBandsToCommonResolution" in ClassRegistry()
