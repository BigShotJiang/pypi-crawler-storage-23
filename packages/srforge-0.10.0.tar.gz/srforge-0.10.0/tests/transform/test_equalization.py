"""Tests for HistogramEqualize, CLAHE DataTransforms and MatchReference DataTransform."""

import torch
import pytest

from srforge.data import Entry
from srforge.transform.data import HistogramEqualize, CLAHE, MatchReference


# ── HistogramEqualize ────────────────────────────────────────────────────

class TestHistogramEqualize:
    def test_output_in_zero_one(self):
        img = torch.rand(1, 3, 16, 16)
        t = HistogramEqualize()
        out = t.transform(img)
        assert out.min() >= 0.0
        assert out.max() <= 1.0 + 1e-6

    def test_batched_input(self):
        """Works on multi-sample batches."""
        img = torch.rand(4, 3, 16, 16)
        t = HistogramEqualize()
        out = t.transform(img)
        assert out.shape == (4, 3, 16, 16)

    def test_constant_channel_unchanged(self):
        """A constant channel should stay constant."""
        img = torch.full((1, 1, 8, 8), 0.5)
        t = HistogramEqualize()
        out = t.transform(img)
        assert torch.allclose(out, img)

    def test_custom_bins(self):
        img = torch.rand(1, 1, 16, 16)
        t = HistogramEqualize(bins=64)
        out = t.transform(img)
        assert out.shape == img.shape


# ── CLAHE ────────────────────────────────────────────────────────────────

class TestCLAHE:
    def test_output_in_zero_one(self):
        img = torch.rand(1, 3, 32, 32)
        t = CLAHE()
        out = t.transform(img)
        assert out.min() >= 0.0 - 1e-6
        assert out.max() <= 1.0 + 1e-6

    def test_batched_input(self):
        img = torch.rand(4, 3, 32, 32)
        t = CLAHE()
        out = t.transform(img)
        assert out.shape == (4, 3, 32, 32)

    def test_preserves_device_and_dtype(self):
        img = torch.rand(1, 1, 32, 32, dtype=torch.float32)
        t = CLAHE()
        out = t.transform(img)
        assert out.dtype == torch.float32

    def test_custom_params(self):
        img = torch.rand(1, 1, 32, 32)
        t = CLAHE(clip_limit=0.05, kernel_size=(4, 4))
        out = t.transform(img)
        assert out.shape == img.shape


# ── MatchReference ───────────────────────────────────────────────────────

class TestMatchReference:
    def test_standalone_transform(self):
        """MatchReference.transform works directly without Entry or IO."""
        torch.manual_seed(42)
        image = torch.randn(1, 3, 16, 16) * 2 + 5
        reference = torch.randn(1, 3, 16, 16) * 0.5 + 1

        t = MatchReference()
        out = t.transform(image, reference)

        assert out.shape == image.shape
        assert abs(out.mean().item() - reference.mean().item()) < 0.5
        assert abs(out.std().item() - reference.std().item()) < 0.5

    def test_dict_io_single_application(self):
        """Dict inputs → single application with explicit param names."""
        torch.manual_seed(42)
        image = torch.randn(1, 3, 16, 16) * 2 + 5
        reference = torch.randn(1, 3, 16, 16) * 0.5 + 1

        t = MatchReference()
        t.set_io({"inputs": {"image": "sr", "reference": "hr"}, "outputs": "sr_match"})

        entry = Entry(name="test", sr=image, hr=reference)
        result = t(entry)

        out = result["sr_match"]
        assert out.shape == image.shape
        assert abs(out.mean().item() - reference.mean().item()) < 0.5
        assert abs(out.std().item() - reference.std().item()) < 0.5

    def test_paired_io_multiple_applications(self):
        """List of dicts inputs → multiple applications, each with different field mappings."""
        torch.manual_seed(42)
        lrs = torch.randn(1, 3, 16, 16) * 2 + 5
        rgb = torch.randn(1, 3, 16, 16) * 3 + 10
        hr = torch.randn(1, 3, 16, 16) * 0.5 + 1

        t = MatchReference()
        t.set_io({
            "inputs": [{"image": "lrs", "reference": "hr"}, {"image": "rgb", "reference": "hr"}],
            "outputs": ["lrs_match", "rgb_match"],
        })

        entry = Entry(name="test", lrs=lrs, rgb=rgb, hr=hr)
        result = t(entry)

        lrs_out = result["lrs_match"]
        rgb_out = result["rgb_match"]
        ref_mean = hr.mean().item()
        ref_std = hr.std().item()
        assert abs(lrs_out.mean().item() - ref_mean) < 0.5
        assert abs(lrs_out.std().item() - ref_std) < 0.5
        assert abs(rgb_out.mean().item() - ref_mean) < 0.5
        assert abs(rgb_out.std().item() - ref_std) < 0.5

    def test_keyword_tuple_multiple_applications(self):
        """Dict syntax allows explicit param=field and arbitrary order."""
        torch.manual_seed(42)
        lrs = torch.randn(1, 3, 16, 16) * 2 + 5
        sr = torch.randn(1, 3, 16, 16) * 3 + 10
        hr = torch.randn(1, 3, 16, 16) * 0.5 + 1

        t = MatchReference()
        t.set_io({
            "inputs": [{"image": "lrs", "reference": "hr"}, {"image": "sr", "reference": "hr"}],
            "outputs": ["lrs_match", "sr_match"],
        })

        entry = Entry(name="test", lrs=lrs, sr=sr, hr=hr)
        result = t(entry)

        ref_mean = hr.mean().item()
        ref_std = hr.std().item()
        assert abs(result["lrs_match"].mean().item() - ref_mean) < 0.5
        assert abs(result["lrs_match"].std().item() - ref_std) < 0.5
        assert abs(result["sr_match"].mean().item() - ref_mean) < 0.5
        assert abs(result["sr_match"].std().item() - ref_std) < 0.5

    def test_1d_tensor(self):
        """Works on 1D tensors (no channel dim)."""
        image = torch.tensor([1.0, 2.0, 3.0, 4.0])
        reference = torch.tensor([10.0, 20.0, 30.0, 40.0])

        t = MatchReference()
        out = t.transform(image, reference)
        assert abs(out.mean().item() - reference.mean().item()) < 1.0

    def test_is_registered(self):
        from srforge.registry import ClassRegistry
        assert "MatchReference" in ClassRegistry()

    def test_missing_entry_field_raises(self):
        """KeyError when an input field is missing from the entry."""
        t = MatchReference()
        t.set_io({"inputs": {"image": "sr", "reference": "hr"}, "outputs": "sr_match"})

        entry = Entry(name="test", sr=torch.randn(1, 3, 8, 8))
        with pytest.raises(KeyError):
            t(entry)
