"""Tests that batched (transform) and unbatched (transform_unbatched) paths
produce identical results for every implemented transform.

For each transform, two code paths are exercised:

- **Path A (batched)**: ``t(Entry.collate([e1, e2]))`` dispatches to ``transform()``
- **Path B (unbatched)**: ``t(e1)``, ``t(e2)`` dispatches to ``transform_unbatched()``,
  then results are collated

The outputs are compared field-by-field.
"""
import copy
from unittest.mock import patch

import pytest
import torch

from srforge.data import Entry


# ── Helpers ──────────────────────────────────────────────────────────


def _assert_tensor_equal(a, b, *, atol=0, path=""):
    """Assert two tensors are equal (or close if atol > 0)."""
    assert a.shape == b.shape, f"{path}: shape mismatch {a.shape} vs {b.shape}"
    if atol > 0:
        assert torch.allclose(a, b, atol=atol), (
            f"{path}: max diff {(a - b).abs().max().item():.2e} > atol={atol}"
        )
    else:
        assert torch.equal(a, b), f"{path}: tensors not equal"


def _assert_value_equal(a, b, *, atol=0, path=""):
    """Recursively compare two values."""
    if isinstance(a, torch.Tensor) and isinstance(b, torch.Tensor):
        _assert_tensor_equal(a, b, atol=atol, path=path)
    elif isinstance(a, dict) and isinstance(b, dict):
        assert set(a.keys()) == set(b.keys()), f"{path}: dict keys differ"
        for k in a:
            _assert_value_equal(a[k], b[k], atol=atol, path=f"{path}.{k}")
    elif isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        assert len(a) == len(b), f"{path}: list length {len(a)} vs {len(b)}"
        for i, (va, vb) in enumerate(zip(a, b)):
            _assert_value_equal(va, vb, atol=atol, path=f"{path}[{i}]")
    else:
        assert a == b, f"{path}: {a!r} != {b!r}"


def _assert_equivalence(result_a: Entry, result_b: Entry, fields, *, atol=0):
    """Compare two entries field-by-field."""
    for field in fields:
        va = result_a[field]
        vb = result_b[field]
        _assert_value_equal(va, vb, atol=atol, path=field)


def _run_equivalence(t, e1, e2, compare_fields, *, atol=0):
    """Run both paths and compare.

    Path A: batched entry → transform()
    Path B: each unbatched entry → transform_unbatched(), then collate
    """
    # Path A: batched
    result_a = t(Entry.collate([copy.deepcopy(e1), copy.deepcopy(e2)]))

    # Path B: unbatched → collate
    r1 = t(copy.deepcopy(e1))
    r2 = t(copy.deepcopy(e2))
    result_b = Entry.collate([r1, r2])

    _assert_equivalence(result_a, result_b, compare_fields, atol=atol)


# ── DataTransform Tests ──────────────────────────────────────────────


class TestDataTransformEquivalence:
    """Each test creates two unbatched entries, runs both paths, compares."""

    def _make_image_entries(self, field="image", C=3, H=32, W=32):
        e1 = Entry(name="s1", **{field: torch.randn(C, H, W)})
        e2 = Entry(name="s2", **{field: torch.randn(C, H, W)})
        return e1, e2

    def test_make_shape_divisible_by(self):
        from srforge.transform.data import MakeShapeDivisibleBy
        t = MakeShapeDivisibleBy(factor=8)
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries(H=35, W=37)
        _run_equivalence(t, e1, e2, ["image"])

    def test_crop_border(self):
        from srforge.transform.data import CropBorder
        t = CropBorder(border_size=4)
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries()
        _run_equivalence(t, e1, e2, ["image"])

    def test_move_axis(self):
        from srforge.transform.data import MoveAxis
        t = MoveAxis(target=-2, destination=-1)
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries()
        _run_equivalence(t, e1, e2, ["image"])

    def test_standardize(self):
        from srforge.transform.data import Standardize
        t = Standardize()
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries()
        _run_equivalence(t, e1, e2, ["image"], atol=1e-5)

    def test_standardize_with_params(self):
        from srforge.transform.data import Standardize
        t = Standardize(mean=0.5, std=0.2)
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries()
        _run_equivalence(t, e1, e2, ["image"])

    def test_destandardize(self):
        from srforge.transform.data import Destandardize
        t = Destandardize(mean=0.5, std=0.2)
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries()
        _run_equivalence(t, e1, e2, ["image"])

    def test_as_type(self):
        from srforge.transform.data import AsType
        t = AsType(dtype="float64")
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries()
        _run_equivalence(t, e1, e2, ["image"])

    def test_to_float(self):
        from srforge.transform.data import ToFloat
        t = ToFloat()
        t.set_io({"inputs": {"image": "image"}})
        e1 = Entry(name="s1", image=torch.randn(3, 16, 16).double())
        e2 = Entry(name="s2", image=torch.randn(3, 16, 16).double())
        _run_equivalence(t, e1, e2, ["image"])

    def test_to_double(self):
        from srforge.transform.data import ToDouble
        t = ToDouble()
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries()
        _run_equivalence(t, e1, e2, ["image"])

    def test_multiply(self):
        from srforge.transform.data import Multiply
        t = Multiply(value=2.5)
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries()
        _run_equivalence(t, e1, e2, ["image"])

    def test_divide(self):
        from srforge.transform.data import Divide
        t = Divide(value=3.0)
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries()
        _run_equivalence(t, e1, e2, ["image"])

    def test_downsample(self):
        from srforge.transform.data import Downsample
        t = Downsample(scale_factor=2)
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries()
        _run_equivalence(t, e1, e2, ["image"], atol=1e-5)

    def test_upsample(self):
        from srforge.transform.data import Upsample
        t = Upsample(scale_factor=2)
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries(H=16, W=16)
        _run_equivalence(t, e1, e2, ["image"], atol=1e-5)

    def test_to_db(self):
        from srforge.transform.data import ToDb
        t = ToDb()
        t.set_io({"inputs": {"image": "image"}})
        e1 = Entry(name="s1", image=torch.rand(3, 16, 16) + 0.01)
        e2 = Entry(name="s2", image=torch.rand(3, 16, 16) + 0.01)
        _run_equivalence(t, e1, e2, ["image"], atol=1e-5)

    def test_normalize(self):
        from srforge.transform.data import Normalize
        t = Normalize()
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries()
        _run_equivalence(t, e1, e2, ["image"], atol=1e-5)

    def test_normalize_with_range(self):
        from srforge.transform.data import Normalize
        t = Normalize(range=(-1.0, 1.0))
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries()
        _run_equivalence(t, e1, e2, ["image"], atol=1e-5)

    def test_histogram_equalize(self):
        from srforge.transform.data import HistogramEqualize
        t = HistogramEqualize(bins=64)
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries(H=16, W=16)
        _run_equivalence(t, e1, e2, ["image"], atol=1e-5)

    def test_clahe(self):
        from srforge.transform.data import CLAHE
        t = CLAHE(clip_limit=0.01, kernel_size=(4, 4))
        t.set_io({"inputs": {"image": "image"}})
        e1, e2 = self._make_image_entries(H=16, W=16)
        _run_equivalence(t, e1, e2, ["image"], atol=1e-5)

    def test_displacement_to_kernel(self):
        from srforge.transform.data import DisplacementToKernel
        t = DisplacementToKernel(max_shift=3)
        t.set_io({"inputs": {"displacement": "disp"}})
        e1 = Entry(name="s1", disp=torch.randn(4, 2).clamp(-3, 3))
        e2 = Entry(name="s2", disp=torch.randn(4, 2).clamp(-3, 3))
        _run_equivalence(t, e1, e2, ["disp"], atol=1e-6)

    def test_kernel_to_displacement(self):
        from srforge.transform.data import KernelToDisplacement
        t = KernelToDisplacement()
        t.set_io({"inputs": {"kernels": "kernels"}})
        K = 7
        k1 = torch.rand(4, K, K)
        k1 = k1 / k1.sum(dim=(-2, -1), keepdim=True)
        k2 = torch.rand(4, K, K)
        k2 = k2 / k2.sum(dim=(-2, -1), keepdim=True)
        e1 = Entry(name="s1", kernels=k1)
        e2 = Entry(name="s2", kernels=k2)
        _run_equivalence(t, e1, e2, ["kernels"], atol=1e-5)

    def test_match_reference(self):
        from srforge.transform.data import MatchReference
        t = MatchReference()
        t.set_io({"inputs": {"image": "lr", "reference": "hr"}, "outputs": "matched"})
        e1 = Entry(name="s1", lr=torch.randn(3, 16, 16), hr=torch.randn(3, 16, 16))
        e2 = Entry(name="s2", lr=torch.randn(3, 16, 16), hr=torch.randn(3, 16, 16))
        _run_equivalence(t, e1, e2, ["matched"], atol=1e-5)

    def test_resize_bands_to_common_resolution(self):
        from srforge.transform.data import ResizeBandsToCommonResolution
        t = ResizeBandsToCommonResolution()
        t.set_io({"inputs": {"field": "bands"}})
        e1 = Entry(name="s1", bands={
            "b1": torch.randn(3, 16, 16),
            "b2": torch.randn(3, 8, 8),
        })
        e2 = Entry(name="s2", bands={
            "b1": torch.randn(3, 16, 16),
            "b2": torch.randn(3, 8, 8),
        })
        _run_equivalence(t, e1, e2, ["bands"], atol=1e-5)

    def test_stack_tensors(self):
        from srforge.transform.data import StackTensors
        t = StackTensors(dim=0)
        t.set_io({"inputs": {"field": "lrs"}})
        e1 = Entry(name="s1", lrs=[torch.randn(1, 3, 16, 16), torch.randn(1, 3, 16, 16)])
        e2 = Entry(name="s2", lrs=[torch.randn(1, 3, 16, 16), torch.randn(1, 3, 16, 16)])
        _run_equivalence(t, e1, e2, ["lrs"])

    def test_stack_sequence(self):
        from srforge.transform.data import StackSequence
        t = StackSequence(dim=0)
        t.set_io({"inputs": {"field": "lrs"}})
        e1 = Entry(name="s1", lrs=[torch.randn(3, 16, 16), torch.randn(3, 16, 16)])
        e2 = Entry(name="s2", lrs=[torch.randn(3, 16, 16), torch.randn(3, 16, 16)])
        _run_equivalence(t, e1, e2, ["lrs"])


# ── EntryTransform Tests ─────────────────────────────────────────────


class TestEntryTransformEquivalence:
    """Each test creates two unbatched entries, runs both paths, compares."""

    def test_set_attribute(self):
        from srforge.transform.entry import SetAttribute
        t = SetAttribute(value=42)
        t.set_io({"inputs": {}, "outputs": {"attr": "scale"}})
        e1 = Entry(name="s1", image=torch.randn(3, 16, 16))
        e2 = Entry(name="s2", image=torch.randn(3, 16, 16))
        # Path A: batched entry → sets scale=42 (literal int)
        result_a = t(Entry.collate([copy.deepcopy(e1), copy.deepcopy(e2)]))
        # Path B: unbatched → each gets scale=42, collation makes tensor([42, 42])
        r1 = t(copy.deepcopy(e1))
        r2 = t(copy.deepcopy(e2))
        result_b = Entry.collate([r1, r2])
        assert result_a["scale"] == 42
        assert torch.equal(result_b["scale"], torch.tensor([42, 42]))
        # Both paths set the attribute — representations differ due to collation
        _assert_equivalence(result_a, result_b, ["image"])

    def test_rename_fields(self):
        from srforge.transform.entry import RenameFields
        t = RenameFields()
        t.set_io({"inputs": {"field": "lr"}, "outputs": {"output": "input"}})
        e1 = Entry(name="s1", lr=torch.randn(3, 16, 16))
        e2 = Entry(name="s2", lr=torch.randn(3, 16, 16))
        _run_equivalence(t, e1, e2, ["input"])

    def test_remove_fields(self):
        from srforge.transform.entry import RemoveFields
        t = RemoveFields()
        t.set_io({"inputs": {"field": "extra"}})
        e1 = Entry(name="s1", image=torch.randn(3, 16, 16), extra=torch.randn(1))
        e2 = Entry(name="s2", image=torch.randn(3, 16, 16), extra=torch.randn(1))
        # After removal, compare remaining fields
        result_a = t(Entry.collate([copy.deepcopy(e1), copy.deepcopy(e2)]))
        r1 = t(copy.deepcopy(e1))
        r2 = t(copy.deepcopy(e2))
        result_b = Entry.collate([r1, r2])
        assert "extra" not in result_a
        assert "extra" not in result_b
        _assert_equivalence(result_a, result_b, ["image"], atol=0)

    def test_copy_fields(self):
        from srforge.transform.entry import CopyFields
        t = CopyFields()
        t.set_io({"inputs": {"field": "image"}, "outputs": {"output": "image_copy"}})
        e1 = Entry(name="s1", image=torch.randn(3, 16, 16))
        e2 = Entry(name="s2", image=torch.randn(3, 16, 16))
        _run_equivalence(t, e1, e2, ["image", "image_copy"])

    def test_flatten_dict(self):
        from srforge.transform.entry import FlattenDict
        t = FlattenDict(sep="_")
        t.set_io({"inputs": {"field": "meta"}})
        e1 = Entry(name="s1", meta={"sensor": "S2", "res": 10})
        e2 = Entry(name="s2", meta={"sensor": "L8", "res": 30})
        _run_equivalence(t, e1, e2, ["meta_sensor", "meta_res"])

    def test_leave_bands(self):
        from srforge.transform.entry import LeaveBands
        t = LeaveBands(bands_to_leave=["b2"])
        t.set_io({"inputs": {"bands": "bands"}})
        e1 = Entry(name="s1", bands=["b2", "b8"],
                    lrs={"b2": torch.randn(3, 8, 8), "b8": torch.randn(3, 8, 8)})
        e2 = Entry(name="s2", bands=["b2", "b8"],
                    lrs={"b2": torch.randn(3, 8, 8), "b8": torch.randn(3, 8, 8)})
        _run_equivalence(t, e1, e2, ["bands", "lrs"])

    def test_remove_bands(self):
        from srforge.transform.entry import RemoveBands
        t = RemoveBands(bands_to_remove=["b8"])
        t.set_io({"inputs": {"bands": "bands"}})
        e1 = Entry(name="s1", bands=["b2", "b8"],
                    lrs={"b2": torch.randn(3, 8, 8), "b8": torch.randn(3, 8, 8)})
        e2 = Entry(name="s2", bands=["b2", "b8"],
                    lrs={"b2": torch.randn(3, 8, 8), "b8": torch.randn(3, 8, 8)})
        _run_equivalence(t, e1, e2, ["bands", "lrs"])

    def test_choose_images(self):
        from srforge.transform.entry import ChooseImages
        t = ChooseImages(indices=0)
        t.set_io({"inputs": {"field": "lrs"}})
        e1 = Entry(name="s1", lrs=[torch.randn(1, 3, 8, 8) for _ in range(4)])
        e2 = Entry(name="s2", lrs=[torch.randn(1, 3, 8, 8) for _ in range(4)])
        _run_equivalence(t, e1, e2, ["lrs"])

    def test_center_offset(self):
        from srforge.transform.entry import CenterOffset
        t = CenterOffset(center_offset=None)
        t.set_io({"inputs": {"translations": "translations"}})
        e1 = Entry(name="s1", translations=torch.randn(4, 2))
        e2 = Entry(name="s2", translations=torch.randn(4, 2))
        _run_equivalence(t, e1, e2, ["translations"], atol=1e-6)

    def test_center_offset_with_value(self):
        from srforge.transform.entry import CenterOffset
        t = CenterOffset(center_offset=(1.0, 2.0))
        t.set_io({"inputs": {"translations": "translations"}})
        e1 = Entry(name="s1", translations=torch.randn(4, 2))
        e2 = Entry(name="s2", translations=torch.randn(4, 2))
        _run_equivalence(t, e1, e2, ["translations"], atol=1e-6)

    def test_random_crop(self):
        from srforge.transform.entry import RandomCrop
        t = RandomCrop(patch_size=8)
        t.set_io({"inputs": {"field": "image"}})
        e1 = Entry(name="s1", image=torch.randn(3, 32, 32))
        e2 = Entry(name="s2", image=torch.randn(3, 32, 32))
        # Monkeypatch get_params for determinism
        fixed_params = (4, 4, 8, 8)
        with patch("srforge.transform.entry.transforms.RandomCrop.get_params", return_value=fixed_params):
            _run_equivalence(t, e1, e2, ["image"])

    def test_resize_fields_to_reference(self):
        from srforge.transform.entry import ResizeFieldsToReference
        t = ResizeFieldsToReference(interpolation_mode="bilinear")
        t.set_io({"inputs": {"field": "lr", "reference": "hr"}})
        e1 = Entry(name="s1", lr=torch.randn(3, 8, 8), hr=torch.randn(3, 32, 32))
        e2 = Entry(name="s2", lr=torch.randn(3, 8, 8), hr=torch.randn(3, 32, 32))
        _run_equivalence(t, e1, e2, ["lr"], atol=1e-5)
