import itertools

import pytest
import torch
from torchvision.transforms import RandomCrop
from torchvision.transforms.functional import crop
from scipy.ndimage import shift as scipy_shift

from srforge.data import Entry
from srforge.data.multispectral.descriptors import MultiSpectralDescriptor
from srforge.transform.data import ResizeBandsToCommonResolution
from srforge.transform.entry import (
    LeaveBands,
    RemoveBands,
    SetAttribute,
    StackBands,
    ResizeFieldsToReference,
    RandomCrop as RandomCropTransform,
    RegisterEntry,
    CalculateTranslations,
    ChooseImages,
    ChooseClearestImages,
    CenterOffset,
    RenameFields,
    RemoveFields,
    CopyFields,
    FlattenDict,
    SetLeading,
)
from srforge.data import _HAS_PYG
try:
    from srforge.transform.graph import EntryToGraphEntry
except ImportError:
    EntryToGraphEntry = None

needs_pyg = pytest.mark.skipif(not _HAS_PYG, reason="torch-geometric not installed")


def _tensor(shape, value):
    return torch.full(shape, float(value), dtype=torch.float32)


def _apply_shift(images, translations, mode="reflect"):
    out = []
    for i, img in enumerate(images):
        img_out = img.clone()
        for j in range(img.shape[0]):
            shift_vec = translations[i]
            shifted = scipy_shift(img[j].numpy(), -shift_vec, mode=mode)
            img_out[j] = torch.from_numpy(shifted).to(img.dtype)
        out.append(img_out)
    return out


def _apply_shift_batched(images, translations, mode="reflect"):
    out = images.clone()
    b, c, k, _, _ = images.shape
    tr_np = translations.detach().cpu().numpy()
    for b_idx in range(b):
        for k_idx in range(k):
            shift_vec = tr_np[b_idx, k_idx]
            for ch in range(c):
                shifted = scipy_shift(images[b_idx, ch, k_idx].numpy(), -shift_vec, mode=mode)
                out[b_idx, ch, k_idx] = torch.from_numpy(shifted).to(images.dtype)
    return out


def _clone_images(images):
    return [img.clone() for img in images]


class _TestDescriptor(MultiSpectralDescriptor):
    @classmethod
    def bands(cls):
        return ["b1", "b2", "b3"]

    @classmethod
    def band_indices(cls):
        return {b: i for i, b in enumerate(cls.bands())}

    @classmethod
    def gsd(cls):
        return {b: 10.0 for b in cls.bands()}

    @classmethod
    def wavelengths(cls):
        return {b: (1.0, 2.0) for b in cls.bands()}

    @classmethod
    def bit_depth(cls):
        return 16


# --- LeaveBands ---


class TestLeaveBands:
    def test_leave_bands_filters_dict_and_list(self):
        entry = Entry(
            bands=[["b1", "b2", "b3"]],
            lrs={"b1": 1, "b2": 2, "b3": 3},
            target={"b1": 10, "b2": 20, "b3": 30},
        )
        out = LeaveBands(["b1", "b3"]).set_io({"inputs": {"bands": "bands"}})(entry)

        assert out is entry
        assert out.bands == [["b1", "b3"]]
        assert set(out.lrs.keys()) == {"b1", "b3"}
        assert set(out.target.keys()) == {"b1", "b3"}
        assert set(out.keys()) == {"bands", "lrs", "target", "name"}

    def test_leave_bands_without_bands_list(self):
        entry = Entry(
            lrs={"b1": 1, "b2": 2},
            misc="keep",
        )
        with pytest.raises(KeyError):
            LeaveBands("b1").set_io({"inputs": {"bands": "bands"}})(entry)

    def test_leave_bands_batched_dict(self):
        entry = Entry(
            bands=[["b1", "b2"]],
            lrs={"b1": _tensor((2, 1, 2, 2), 1.0), "b2": _tensor((2, 1, 2, 2), 2.0)},
            target={"b1": _tensor((2, 1, 2, 2), 3.0), "b2": _tensor((2, 1, 2, 2), 4.0)},
        )
        out = LeaveBands("b2").set_io({"inputs": {"bands": "bands"}})(entry)

        assert set(out.lrs.keys()) == {"b2"}
        assert set(out.target.keys()) == {"b2"}
        assert out.lrs["b2"].shape[0] == 2
        assert out.bands == [["b2"]]


# --- RemoveBands ---


class TestRemoveBands:
    def test_remove_bands_filters_dict_and_list(self):
        entry = Entry(
            bands=[["b1", "b2", "b3"]],
            lrs={"b1": 1, "b2": 2, "b3": 3},
            target={"b1": 10, "b2": 20, "b3": 30},
        )
        out = RemoveBands(["b2"]).set_io({"inputs": {"bands": "bands"}})(entry)

        assert out is entry
        assert out.bands == [["b1", "b3"]]
        assert set(out.lrs.keys()) == {"b1", "b3"}
        assert set(out.target.keys()) == {"b1", "b3"}
        assert set(out.keys()) == {"bands", "lrs", "target", "name"}

    def test_remove_bands_without_bands_list(self):
        entry = Entry(
            lrs={"b1": 1, "b2": 2},
            misc="keep",
        )
        with pytest.raises(KeyError):
            RemoveBands("b2").set_io({"inputs": {"bands": "bands"}})(entry)

    def test_remove_bands_batched_dict(self):
        entry = Entry(
            bands=[["b1", "b2"]],
            lrs={"b1": _tensor((2, 1, 2, 2), 1.0), "b2": _tensor((2, 1, 2, 2), 2.0)},
        )
        out = RemoveBands("b1").set_io({"inputs": {"bands": "bands"}})(entry)

        assert set(out.lrs.keys()) == {"b2"}
        assert out.bands == [["b2"]]


# --- SetAttribute ---


class TestSetAttribute:
    def test_set_attribute_sets_value(self):
        entry = Entry()
        out = SetAttribute(5).set_io({"inputs": {"attr": "foo"}})(entry)

        assert out.foo == 5
        assert "foo" in out

    def test_set_attribute_overwrites_value(self):
        entry = Entry(foo=1)
        out = SetAttribute(7).set_io({"inputs": {"attr": "foo"}})(entry)

        assert out.foo == 7
        assert set(out.keys()) == {"foo", "name"}

    def test_set_attribute_with_batched_tensor(self):
        value = _tensor((2, 1, 3, 3), 5.0)
        entry = Entry()
        out = SetAttribute(value).set_io({"inputs": {"attr": "batched"}})(entry)

        assert torch.allclose(out.batched, value)
        assert out.batched.shape[0] == 2


# --- StackBands ---


class TestStackBands:
    def test_stack_bands_uses_entry_order_without_output(self):
        entry = Entry(
            bands=[["b2", "b1"]],
            lrs={
                "b1": _tensor((1, 1, 2, 2), 1.0),
                "b2": _tensor((1, 1, 2, 2), 2.0),
            },
        )
        out = StackBands().set_io({"inputs": {"bands_list": "bands", "field": "lrs"}})(entry)

        assert out is entry
        assert out.lrs.shape == (1, 2, 2, 2)
        assert torch.allclose(out.lrs[:, 0], _tensor((1, 2, 2), 2.0))
        assert torch.allclose(out.lrs[:, 1], _tensor((1, 2, 2), 1.0))
        assert out.bands == [["b2", "b1"]]
        assert set(out.keys()) == {"bands", "lrs", "name"}

    def test_stack_bands_descriptor_subset_with_output(self):
        entry = Entry(
            bands=[["b2", "b1"]],
            lrs={
                "b1": _tensor((1, 1, 2, 2), 1.0),
                "b2": _tensor((1, 1, 2, 2), 2.0),
            },
        )
        out = StackBands(
            bands_descriptor=_TestDescriptor,
        ).set_io({"inputs": {"bands_list": "bands", "field": "lrs"}, "outputs": {"output": "stacked"}})(entry)

        assert "stacked" in out
        assert out.stacked.shape == (1, 2, 2, 2)
        assert torch.allclose(out.stacked[:, 0], _tensor((1, 2, 2), 1.0))
        assert torch.allclose(out.stacked[:, 1], _tensor((1, 2, 2), 2.0))
        assert out.bands == [["b1", "b2"]]
        assert isinstance(out.lrs, dict)
        assert set(out.keys()) == {"bands", "lrs", "stacked", "name"}

    def test_stack_bands_batched_tensors(self):
        entry = Entry(
            bands=[["b2", "b1"]],
            lrs={
                "b1": _tensor((2, 1, 2, 2), 1.0),
                "b2": _tensor((2, 1, 2, 2), 2.0),
            },
        )
        out = StackBands().set_io({"inputs": {"bands_list": "bands", "field": "lrs"}})(entry)

        assert out.lrs.shape == (2, 2, 2, 2)
        assert torch.allclose(out.lrs[:, 0], _tensor((2, 2, 2), 2.0))
        assert torch.allclose(out.lrs[:, 1], _tensor((2, 2, 2), 1.0))
        assert out.bands == [["b2", "b1"]]


# --- ResizeFieldsToReference ---


class TestResizeFieldsToReference:
    def test_resize_field_in_place(self):
        entry = Entry(
            lrs=_tensor((1, 1, 2, 2), 1.0),
            ref=_tensor((1, 1, 4, 4), 2.0),
        )
        out = ResizeFieldsToReference().set_io({"inputs": {"field": "lrs", "reference": "ref"}})(entry)

        assert out.lrs.shape[-2:] == (4, 4)
        assert out.ref.shape[-2:] == (4, 4)

    def test_resize_field_with_output_mapping(self):
        entry = Entry(
            lrs={"b1": _tensor((1, 1, 2, 2), 1.0), "b2": _tensor((1, 1, 2, 2), 2.0)},
            ref={"b1": _tensor((1, 1, 4, 4), 0.0), "b2": _tensor((1, 1, 4, 4), 0.0)},
        )
        out = ResizeFieldsToReference().set_io(
            {"inputs": {"field": "lrs", "reference": "ref"}, "outputs": {"output": "resized"}}
        )(entry)

        assert "resized" in out
        assert out.resized["b1"].shape[-2:] == (4, 4)
        assert out.resized["b2"].shape[-2:] == (4, 4)
        assert isinstance(out.lrs, dict)
        assert set(out.keys()) == {"lrs", "ref", "resized", "name"}

    def test_resize_field_batched_tensor(self):
        entry = Entry(
            lrs=_tensor((2, 1, 2, 2), 1.0),
            ref=_tensor((2, 1, 4, 4), 2.0),
        )
        out = ResizeFieldsToReference().set_io({"inputs": {"field": "lrs", "reference": "ref"}})(entry)

        assert out.lrs.shape == (2, 1, 4, 4)
        assert out.ref.shape == (2, 1, 4, 4)

    def test_resize_field_batched_sequence_tensor(self):
        field = torch.zeros((2, 1, 3, 2, 2), dtype=torch.float32)
        ref = torch.zeros((2, 1, 3, 4, 4), dtype=torch.float32)
        entry = Entry(lrs=field, ref=ref)
        out = ResizeFieldsToReference().set_io({"inputs": {"field": "lrs", "reference": "ref"}})(entry)

        assert out.lrs.shape == (2, 1, 3, 4, 4)


# --- ResizeBandsToCommonResolution ---


class TestResizeBandsToCommonResolution:
    def test_resize_bands_in_place(self):
        entry = Entry(
            lrs={
                "b1": _tensor((1, 1, 2, 2), 1.0),
                "b2": _tensor((1, 1, 4, 4), 2.0),
            }
        )
        out = ResizeBandsToCommonResolution().set_io({"inputs": {"field": "lrs"}})(entry)

        assert out.lrs["b1"].shape[-2:] == (4, 4)
        assert out.lrs["b2"].shape[-2:] == (4, 4)
        assert set(out.keys()) == {"lrs", "name"}

    def test_resize_bands_with_output_mapping(self):
        entry = Entry(
            lrs={
                "b1": _tensor((1, 1, 2, 2), 1.0),
                "b2": _tensor((1, 1, 4, 4), 2.0),
            }
        )
        out = ResizeBandsToCommonResolution().set_io({"inputs": {"field": "lrs"}, "outputs": "resized"})(entry)

        assert out.resized["b1"].shape[-2:] == (4, 4)
        assert out.lrs["b1"].shape[-2:] == (2, 2)
        assert set(out.keys()) == {"lrs", "resized", "name"}

    def test_resize_bands_batched_tensor_dict(self):
        entry = Entry(
            lrs={
                "b1": _tensor((2, 1, 2, 2), 1.0),
                "b2": _tensor((2, 1, 4, 4), 2.0),
            }
        )
        entry._is_batched = True
        out = ResizeBandsToCommonResolution().set_io({"inputs": {"field": "lrs"}})(entry)

        assert out.lrs["b1"].shape == (2, 1, 4, 4)
        assert out.lrs["b2"].shape == (2, 1, 4, 4)

    def test_resize_bands_batched_sequence_dict(self):
        entry = Entry(
            lrs={
                "b1": torch.zeros((2, 1, 2, 2, 2), dtype=torch.float32),
                "b2": torch.zeros((2, 1, 2, 4, 4), dtype=torch.float32),
            }
        )
        entry._is_batched = True
        out = ResizeBandsToCommonResolution().set_io({"inputs": {"field": "lrs"}})(entry)

        assert out.lrs["b1"].shape == (2, 1, 2, 4, 4)
        assert out.lrs["b2"].shape == (2, 1, 2, 4, 4)


# --- RandomCrop ---


class TestRandomCrop:
    def test_random_crop_in_place(self, monkeypatch):
        entry = Entry(lrs=_tensor((1, 1, 4, 4), 1.0))
        original = entry.lrs.clone()
        monkeypatch.setattr(RandomCrop, "get_params", staticmethod(lambda *args, **kwargs: (1, 1, 2, 2)))

        out = RandomCropTransform(patch_size=2).set_io({"inputs": {"field": "lrs"}})(entry)

        expected = crop(original, 1, 1, 2, 2)
        assert torch.allclose(out.lrs, expected)
        assert set(out.keys()) == {"lrs", "name"}

    def test_random_crop_with_output_mapping(self, monkeypatch):
        entry = Entry(
            lrs={
                "b1": _tensor((1, 1, 4, 4), 1.0),
                "b2": _tensor((1, 1, 4, 4), 2.0),
            }
        )
        original_b1 = entry.lrs["b1"].clone()
        monkeypatch.setattr(RandomCrop, "get_params", staticmethod(lambda *args, **kwargs: (0, 0, 2, 2)))

        out = RandomCropTransform(patch_size=2).set_io({"inputs": {"field": "lrs"}, "outputs": {"output": "cropped"}})(entry)

        assert "cropped" in out
        assert out.cropped["b1"].shape[-2:] == (2, 2)
        assert torch.allclose(out.lrs["b1"], original_b1)
        assert set(out.keys()) == {"lrs", "cropped", "name"}

    def test_random_crop_batched_tensor(self, monkeypatch):
        entry = Entry(lrs=torch.arange(2 * 1 * 2 * 4 * 4, dtype=torch.float32).reshape(2, 1, 2, 4, 4))
        original = entry.lrs.clone()
        monkeypatch.setattr(RandomCrop, "get_params", staticmethod(lambda *args, **kwargs: (1, 1, 2, 2)))

        out = RandomCropTransform(patch_size=2).set_io({"inputs": {"field": "lrs"}})(entry)

        expected = original[..., 1:3, 1:3]
        assert torch.allclose(out.lrs, expected)


# --- RegisterEntry ---


class TestRegisterEntry:
    def test_register_entry_list(self):
        base = torch.arange(16 * 16, dtype=torch.float32).reshape(1, 16, 16)
        img1 = torch.cat([base, base + 100.0], dim=0)
        img2 = torch.cat([base + 200.0, base + 300.0], dim=0)
        lrs = [img1, img2]
        original = _clone_images(lrs)
        translations = torch.tensor([[0.0, 0.0], [1.0, -1.0]], dtype=torch.float32)
        entry = Entry(lrs=lrs, translations=translations)

        out = RegisterEntry().set_io({"inputs": {"field": "lrs", "translations": "translations"}})(entry)

        expected = _apply_shift(original, translations)
        assert torch.allclose(out.lrs[0], expected[0], atol=1e-4)
        assert torch.allclose(out.lrs[1], expected[1], atol=1e-4)
        assert "translations" in out

    def test_register_entry_dict(self):
        base = torch.arange(16 * 16, dtype=torch.float32).reshape(1, 16, 16)
        lrs = {
            "b1": [torch.cat([base, base + 10.0], dim=0), torch.cat([base + 20.0, base + 30.0], dim=0)],
            "b2": [torch.cat([base + 40.0, base + 50.0], dim=0), torch.cat([base + 60.0, base + 70.0], dim=0)],
        }
        originals = {band: _clone_images(images) for band, images in lrs.items()}
        translations = {
            "b1": torch.tensor([[0.0, 0.0], [1.0, -1.0]], dtype=torch.float32),
            "b2": torch.tensor([[0.0, 0.0], [1.0, -1.0]], dtype=torch.float32),
        }
        entry = Entry(lrs=lrs, translations=translations)

        out = RegisterEntry().set_io({"inputs": {"field": "lrs", "translations": "translations"}})(entry)

        expected_b1 = _apply_shift(originals["b1"], translations["b1"])
        expected_b2 = _apply_shift(originals["b2"], translations["b2"])
        assert torch.allclose(out.lrs["b1"][0], expected_b1[0], atol=1e-4)
        assert torch.allclose(out.lrs["b1"][1], expected_b1[1], atol=1e-4)
        assert torch.allclose(out.lrs["b2"][0], expected_b2[0], atol=1e-4)
        assert torch.allclose(out.lrs["b2"][1], expected_b2[1], atol=1e-4)
        assert set(out.lrs.keys()) == {"b1", "b2"}

    def test_register_entry_batched_tensor(self):
        c, k, h, w = 1, 2, 6, 6
        grid = torch.arange(h * w, dtype=torch.float32).reshape(1, 1, h, w)  # (C, K=1, H, W)
        sample_translations = [
            torch.tensor([[0.0, 0.0], [1.0, -1.0]], dtype=torch.float32),
            torch.tensor([[-1.0, 0.0], [0.0, 1.0]], dtype=torch.float32),
        ]
        samples = []
        for b_idx in range(2):
            images = grid + b_idx * 100.0
            images = images + torch.arange(k, dtype=torch.float32).view(1, k, 1, 1) * 10
            samples.append(Entry(lrs=images.clone(), translations=sample_translations[b_idx]))
        entry = Entry.collate(samples)

        out = RegisterEntry().set_io({"inputs": {"field": "lrs", "translations": "translations"}})(entry)

        expected = _apply_shift_batched(entry.lrs, entry.translations)
        assert torch.allclose(out.lrs, expected, atol=1e-4)


# --- CalculateTranslations ---


class TestCalculateTranslations:
    @pytest.mark.parametrize("use_masks,use_leading", list(itertools.product([False, True], repeat=2)))
    def test_calculate_translations_optional_inputs(self, use_masks, use_leading):
        images = [_tensor((1, 4, 4), 1.0), _tensor((1, 4, 4), 1.0)]
        entry_kwargs = {"lrs": images}
        inputs = {"field": "lrs"}
        outputs = {"translations": "translations"}

        if use_masks:
            entry_kwargs["masks"] = [_tensor((1, 4, 4), 1.0), _tensor((1, 4, 4), 1.0)]
            inputs["masks"] = "masks"

        if use_leading:
            entry_kwargs["leading"] = [True]
            inputs["leading"] = "leading"

        entry = Entry(**entry_kwargs)
        out = CalculateTranslations(use_masks=use_masks, ref_index=1).set_io({"inputs": inputs, "outputs": outputs})(entry)

        assert isinstance(out.translations, torch.Tensor)
        assert out.translations.shape[0] == len(images)
        assert "lrs" in out

    def test_calculate_translations_dict(self):
        images = {
            "b1": [_tensor((1, 4, 4), 1.0), _tensor((1, 4, 4), 1.0)],
            "b2": [_tensor((1, 4, 4), 2.0), _tensor((1, 4, 4), 2.0)],
        }
        entry = Entry(lrs=images)
        out = CalculateTranslations().set_io({"inputs": {"field": "lrs"}, "outputs": {"translations": "translations"}})(entry)

        assert set(out.translations.keys()) == {"b1", "b2"}
        assert out.translations["b1"].shape[0] == 2
        assert "lrs" in out

    def test_calculate_translations_batched_tensor(self):
        single = torch.arange(4 * 4, dtype=torch.float32).reshape(1, 1, 4, 4)  # (C=1, K=1, H, W)
        base = single.repeat(1, 2, 1, 1)  # (C=1, K=2, H, W)
        samples = [Entry(lrs=base.clone()) for _ in range(2)]
        entry = Entry.collate(samples)

        out = CalculateTranslations(upsample_factor=1).set_io({"inputs": {"field": "lrs"}, "outputs": {"translations": "translations"}})(entry)

        assert out.translations.shape == (2, 2, 2)
        assert torch.allclose(out.translations, torch.zeros_like(out.translations), atol=1e-4)


# --- ChooseImages ---


class TestChooseImages:
    @pytest.mark.parametrize("use_output", [False, True])
    def test_choose_images_list_optional_output(self, use_output):
        entry = Entry(lrs=[_tensor((1, 1, 2, 2), 1.0), _tensor((1, 1, 2, 2), 2.0)])
        io_map = {"inputs": {"field": "lrs"}}
        if use_output:
            io_map["outputs"] = {"output": "selected"}
        out = ChooseImages(indices=1).set_io(io_map)(entry)

        if use_output:
            assert out.selected.shape == (1, 1, 2, 2)
            assert len(out.lrs) == 2
            assert set(out.keys()) == {"lrs", "selected", "name"}
        else:
            assert out.lrs.shape == (1, 1, 2, 2)
            assert set(out.keys()) == {"lrs", "name"}

    def test_choose_images_dict(self):
        entry = Entry(
            lrs={
                "b1": [_tensor((1, 1, 2, 2), 1.0), _tensor((1, 1, 2, 2), 2.0)],
                "b2": [_tensor((1, 1, 2, 2), 3.0), _tensor((1, 1, 2, 2), 4.0)],
            }
        )
        out = ChooseImages(indices=0).set_io({"inputs": {"field": "lrs"}, "outputs": {"output": "selected"}})(entry)

        assert out.selected["b1"].shape == (1, 1, 2, 2)
        assert out.selected["b2"].shape == (1, 1, 2, 2)
        assert set(out.keys()) == {"lrs", "selected", "name"}

    def test_choose_images_batched_tensor(self):
        entry = Entry(lrs=torch.arange(2 * 1 * 3 * 2 * 2, dtype=torch.float32).reshape(2, 1, 3, 2, 2))
        original = entry.lrs.clone()
        out = ChooseImages(indices=[0, 2]).set_io({"inputs": {"field": "lrs"}})(entry)

        assert out.lrs.shape == (2, 1, 2, 2, 2)
        assert torch.allclose(out.lrs[:, :, 0], original[:, :, 0])
        assert torch.allclose(out.lrs[:, :, 1], original[:, :, 2])


# --- ChooseClearestImages ---


class TestChooseClearestImages:
    @pytest.mark.parametrize(
        "use_masks,use_translations,use_leading",
        list(itertools.product([False, True], repeat=3)),
    )
    def test_choose_clearest_images_optional_inputs(self, use_masks, use_translations, use_leading):
        num_images = 2
        inputs = {"lrs": "lrs"}
        outputs = {}
        entry_kwargs = {}

        if use_masks:
            lrs = [
                _tensor((1, 1, 2, 2), 0.0),
                _tensor((1, 1, 2, 2), 1.0),
                _tensor((1, 1, 2, 2), 2.0),
            ]
            masks = [
                _tensor((1, 1, 2, 2), 0.1),
                _tensor((1, 1, 2, 2), 0.9),
                _tensor((1, 1, 2, 2), 0.5),
            ]
            entry_kwargs["masks"] = masks
            inputs["masks"] = "masks"
            outputs["masks"] = "masks"
        else:
            lrs = [
                _tensor((1, 1, 2, 2), 0.0),
                _tensor((1, 1, 2, 2), 1.0),
            ]

        entry_kwargs["lrs"] = lrs

        if use_translations:
            translations = torch.zeros((1, len(lrs), 2), dtype=torch.float32)
            entry_kwargs["translations"] = translations
            inputs["translations"] = "translations"
            outputs["translations"] = "translations"

        if use_leading:
            entry_kwargs["leading"] = [True]
            inputs["leading"] = "leading"

        io_map = {"inputs": inputs}
        if outputs:
            io_map["outputs"] = outputs

        entry = Entry(**entry_kwargs)
        out = ChooseClearestImages(num_images=num_images).set_io(io_map)(entry)

        assert len(out.lrs) == num_images
        if use_masks:
            expected = [0, 1] if use_leading else [1, 2]
            assert torch.allclose(out.lrs[0], lrs[expected[0]])
            assert torch.allclose(out.lrs[1], lrs[expected[1]])

        if use_translations:
            assert "translations" in out
            assert len(out.translations) == num_images
        else:
            assert "translations" not in out

        if use_masks:
            assert "masks" in out
            assert len(out.masks) == num_images
        else:
            assert "masks" not in out
        assert "lrs" in out

    def test_choose_clearest_images_dict(self):
        entry = Entry(
            lrs={
                "b1": [
                    _tensor((1, 1, 2, 2), 1.0),
                    _tensor((1, 1, 2, 2), 2.0),
                ]
            },
            masks={"b1": [_tensor((1, 1, 2, 2), 1.0), _tensor((1, 1, 2, 2), 0.5)]},
        )
        out = ChooseClearestImages(
            num_images=1,
        ).set_io({"inputs": {"lrs": "lrs", "masks": "masks"}, "outputs": {"masks": "masks"}})(entry)

        assert len(out.lrs["b1"]) == 1
        assert len(out.masks["b1"]) == 1
        assert set(out.keys()) == {"lrs", "masks", "name"}

    def test_choose_clearest_images_batched_tensor(self):
        lrs = torch.zeros((2, 1, 3, 2, 2), dtype=torch.float32)
        masks = torch.tensor(
            [
                [[[0.1]], [[0.9]], [[0.2]]],
                [[[0.8]], [[0.1]], [[0.7]]],
            ],
            dtype=torch.float32,
        ).unsqueeze(1).repeat(1, 1, 1, 2, 2)
        translations = torch.arange(2 * 3 * 2, dtype=torch.float32).reshape(2, 3, 2)
        entry = Entry(lrs=lrs, masks=masks, translations=translations)

        out = ChooseClearestImages(num_images=2).set_io(
            {"inputs": {"lrs": "lrs", "masks": "masks", "translations": "translations"}, "outputs": {"masks": "masks", "translations": "translations"}}
        )(entry)

        assert out.lrs.shape == (2, 1, 2, 2, 2)
        assert out.translations.shape == (2, 2, 2)
        assert torch.allclose(out.translations[0, 0], translations[0, 1])
        assert torch.allclose(out.translations[0, 1], translations[0, 2])
        assert torch.allclose(out.translations[1, 0], translations[1, 0])
        assert torch.allclose(out.translations[1, 1], translations[1, 2])


# --- CenterOffset ---


class TestCenterOffset:
    def test_center_offset_list(self):
        entry = Entry(translations=[torch.tensor([1.0, 1.0]), torch.tensor([3.0, 3.0])])
        out = CenterOffset(center_offset=None).set_io({"inputs": {"translations": "translations"}})(entry)

        assert torch.allclose(out.translations[0], torch.tensor([-1.0, -1.0]))
        assert torch.allclose(out.translations[1], torch.tensor([1.0, 1.0]))
        assert "translations" in out

    def test_center_offset_dict(self):
        entry = Entry(translations={"b1": [torch.tensor([2.0, 2.0])], "b2": [torch.tensor([3.0, 3.0])]})
        out = CenterOffset(center_offset=torch.tensor([1.0, 1.0])).set_io({"inputs": {"translations": "translations"}})(entry)

        assert torch.allclose(out.translations["b1"][0], torch.tensor([1.0, 1.0]))
        assert torch.allclose(out.translations["b2"][0], torch.tensor([2.0, 2.0]))
        assert set(out.keys()) == {"translations", "name"}

    def test_center_offset_batched_tensor(self):
        translations = torch.tensor(
            [
                [[0.0, 0.0], [2.0, 2.0]],
                [[1.0, 1.0], [3.0, 3.0]],
            ],
            dtype=torch.float32,
        )
        entry = Entry(translations=translations)
        out = CenterOffset(center_offset=None).set_io({"inputs": {"translations": "translations"}})(entry)

        assert torch.allclose(out.translations[0], torch.tensor([[-1.0, -1.0], [1.0, 1.0]]))
        assert torch.allclose(out.translations[1], torch.tensor([[-1.0, -1.0], [1.0, 1.0]]))


# --- RenameFields ---


class TestRenameFields:
    def test_rename_fields_moves_value(self):
        entry = Entry(x=1)
        out = RenameFields().set_io({"inputs": {"field": "x"}, "outputs": {"output": "y"}})(entry)

        assert "x" not in out
        assert out.y == 1
        assert not hasattr(out, "x")
        assert set(out.keys()) == {"y", "name"}

    def test_rename_fields_same_mapping_keeps_value(self):
        entry = Entry(x=1)
        out = RenameFields().set_io({"inputs": {"field": "x"}, "outputs": {"output": "x"}})(entry)

        assert "x" in out
        assert out.x == 1
        assert set(out.keys()) == {"x", "name"}

    def test_rename_fields_batched_tensor(self):
        entry = Entry(x=_tensor((2, 1, 2, 2), 1.0))
        out = RenameFields().set_io({"inputs": {"field": "x"}, "outputs": {"output": "y"}})(entry)

        assert "x" not in out
        assert out.y.shape == (2, 1, 2, 2)


# --- RemoveFields ---


class TestRemoveFields:
    def test_remove_fields_deletes_key(self):
        entry = Entry(x=1, y=2)
        out = RemoveFields().set_io({"inputs": {"field": "x"}})(entry)

        assert "x" not in out
        assert not hasattr(out, "x")
        assert out.y == 2
        assert set(out.keys()) == {"y", "name"}

    def test_remove_fields_missing_key(self):
        entry = Entry(y=2)
        with pytest.raises(KeyError):
            RemoveFields().set_io({"inputs": {"field": "x"}})(entry)

    def test_remove_fields_batched_tensor(self):
        entry = Entry(x=_tensor((2, 1, 2, 2), 1.0), y=_tensor((2, 1, 2, 2), 2.0))
        out = RemoveFields().set_io({"inputs": {"field": "x"}})(entry)

        assert "x" not in out
        assert out.y.shape == (2, 1, 2, 2)


# --- CopyFields ---


class TestCopyFields:
    def test_copy_fields_creates_deep_copy(self):
        entry = Entry(x=[1, 2])
        out = CopyFields().set_io({"inputs": {"field": "x"}, "outputs": {"output": "y"}})(entry)

        out.y.append(3)
        assert out.x == [1, 2]
        assert out.y == [1, 2, 3]
        assert set(out.keys()) == {"x", "y", "name"}

    def test_copy_fields_nested(self):
        entry = Entry(x={"a": [1, 2]})
        out = CopyFields().set_io({"inputs": {"field": "x"}, "outputs": {"output": "y"}})(entry)

        out.y["a"].append(3)
        assert out.x["a"] == [1, 2]
        assert set(out.keys()) == {"x", "y", "name"}

    def test_copy_fields_batched_tensor(self):
        entry = Entry(x=_tensor((2, 1, 2, 2), 1.0))
        out = CopyFields().set_io({"inputs": {"field": "x"}, "outputs": {"output": "y"}})(entry)

        out.y += 1.0
        assert torch.allclose(out.x, _tensor((2, 1, 2, 2), 1.0))
        assert torch.allclose(out.y, _tensor((2, 1, 2, 2), 2.0))


# --- FlattenDict ---


class TestFlattenDict:
    def test_default_uses_field_name_as_prefix(self):
        """Default: field name becomes the root prefix."""
        entry = Entry(bands={"b2": _tensor((1, 1, 4, 4), 1.0), "b8": _tensor((1, 1, 4, 4), 2.0)})
        out = FlattenDict().set_io({"inputs": {"field": "bands"}})(entry)

        assert "bands" not in out
        assert torch.allclose(out.bands_b2, _tensor((1, 1, 4, 4), 1.0))
        assert torch.allclose(out.bands_b8, _tensor((1, 1, 4, 4), 2.0))

    def test_no_prefix(self):
        """prefix='' omits root prefix -- inner keys only."""
        entry = Entry(bands={"b2": _tensor((1, 1, 4, 4), 1.0)})
        out = FlattenDict(prefix="").set_io({"inputs": {"field": "bands"}})(entry)

        assert "bands" not in out
        assert torch.allclose(out.b2, _tensor((1, 1, 4, 4), 1.0))

    def test_custom_prefix(self):
        entry = Entry(bands={"b2": _tensor((1, 1, 4, 4), 1.0)})
        out = FlattenDict(prefix="lr").set_io({"inputs": {"field": "bands"}})(entry)

        assert "bands" not in out
        assert torch.allclose(out.lr_b2, _tensor((1, 1, 4, 4), 1.0))

    def test_deeply_nested(self):
        """Recursively flattens nested dicts, joining all keys."""
        entry = Entry(meta={"sensor": {"name": ["S2"], "res": torch.tensor([10])}, "date": ["2024"]})
        out = FlattenDict().set_io({"inputs": {"field": "meta"}})(entry)

        assert "meta" not in out
        assert out.meta_sensor_name == ["S2"]
        assert torch.equal(out.meta_sensor_res, torch.tensor([10]))
        assert out.meta_date == ["2024"]

    def test_custom_separator(self):
        entry = Entry(meta={"sensor": {"name": ["S2"]}})
        out = FlattenDict(sep=".").set_io({"inputs": {"field": "meta"}})(entry)

        assert out["meta.sensor.name"] == ["S2"]

    def test_preserves_other_fields(self):
        entry = Entry(
            image=_tensor((1, 1, 4, 4), 3.0),
            bands={"b2": _tensor((1, 1, 4, 4), 1.0)},
        )
        out = FlattenDict().set_io({"inputs": {"field": "bands"}})(entry)

        assert torch.allclose(out.image, _tensor((1, 1, 4, 4), 3.0))
        assert "bands" not in out

    def test_non_dict_raises(self):
        entry = Entry(bands=_tensor((1, 1, 4, 4), 1.0))
        with pytest.raises(TypeError, match="expected a dict"):
            FlattenDict().set_io({"inputs": {"field": "bands"}})(entry)


# --- SetLeading ---


class TestSetLeading:
    def test_set_leading_swaps_images(self):
        lrs = [_tensor((1, 1, 2, 2), 1.0), _tensor((1, 1, 2, 2), 2.0)]
        entry = Entry(lrs=lrs, leading=[False])
        out = SetLeading(idx=1).set_io({"inputs": {"lrs": "lrs"}, "outputs": {"leading": "leading"}})(entry)

        assert out.leading == [True]
        assert torch.allclose(out.lrs[0], _tensor((1, 1, 2, 2), 2.0))
        assert len(out.lrs) == 2
        assert set(out.keys()) == {"lrs", "leading", "name"}

    def test_set_leading_raises_if_already_set(self):
        entry = Entry(lrs=[_tensor((1, 1, 2, 2), 1.0)], leading=[True])
        with pytest.raises(ValueError):
            SetLeading(idx=0).set_io({"inputs": {"lrs": "lrs"}, "outputs": {"leading": "leading"}})(entry)

    def test_set_leading_batched_tensor(self):
        lrs = torch.stack([_tensor((2, 1, 2, 2), 1.0), _tensor((2, 1, 2, 2), 2.0)], dim=2)
        entry = Entry(lrs=lrs, leading=[False])
        out = SetLeading(idx=1).set_io({"inputs": {"lrs": "lrs"}, "outputs": {"leading": "leading"}})(entry)

        assert out.leading == [True]
        assert torch.allclose(out.lrs[:, :, 0], _tensor((2, 1, 2, 2), 2.0))
        assert torch.allclose(out.lrs[:, :, 1], _tensor((2, 1, 2, 2), 1.0))


# --- EntryToGraphEntry ---


@needs_pyg
class TestEntryToGraphEntry:
    def test_entry_to_graph_entry_tensor(self):
        entry = Entry(nodes=_tensor((1, 1, 2, 2), 1.0), mask=_tensor((1, 1, 2, 2), 0.0))
        out = EntryToGraphEntry().set_io({"inputs": {"nodes": "nodes"}})(entry)

        assert out.nodes.shape == (4, 1)
        assert out.mask.shape == (4, 1)
        assert out.pos.shape[0] == 4
        assert "nodes_org" in out
        assert "nodes_org_shape" in out
        assert out.nodes_org.shape == (1, 1, 2, 2)
        assert out.nodes_org_shape.tolist() == [[1, 2, 2]]

    def test_entry_to_graph_entry_dict(self):
        entry = Entry(
            nodes={
                "b1": _tensor((1, 1, 2, 2), 1.0),
                "b2": _tensor((1, 1, 2, 2), 2.0),
            }
        )
        out = EntryToGraphEntry(
            gsd_mapping={"b1": 10.0, "b2": 20.0},
        ).set_io({"inputs": {"nodes": "nodes"}})(entry)

        assert out.nodes.shape[0] == 8
        assert out.band.shape[0] == 8
        assert len(out.all_bands) == 2
        assert out.nodes.shape[1] == 1

    def test_entry_to_graph_entry_list(self):
        """List of K tensors each (C, H, W) → nodes_org stores stacked (1, C, K, H, W)."""
        imgs = [torch.full((1, 3, 3), float(i)) for i in range(4)]  # 4 images, 1ch, 3x3
        entry = Entry(nodes=imgs, hr=_tensor((1, 1, 9, 9), 0.0))
        out = EntryToGraphEntry().set_io({"inputs": {"nodes": "nodes"}})(entry)

        assert out.nodes.shape == (4 * 3 * 3, 1)  # K*H*W nodes, C features
        assert "nodes_org" in out
        assert out.nodes_org.shape == (1, 1, 4, 3, 3)  # (1, C, K, H, W)
        assert out.nodes_org_shape.tolist() == [[1, 4, 3, 3]]

    def test_entry_to_graph_entry_batched_tensor(self):
        nodes = torch.arange(2 * 1 * 2 * 2, dtype=torch.float32).reshape(2, 1, 2, 2)
        entry = Entry(nodes=nodes, mask=torch.zeros_like(nodes))
        out = EntryToGraphEntry().set_io({"inputs": {"nodes": "nodes"}})(entry)

        assert out.nodes.shape == (8, 1)
        assert out.pos.shape == (8, 2)
        assert out.mask.shape == (8, 1)
        assert out.nodes_org.shape == (2, 1, 2, 2)
