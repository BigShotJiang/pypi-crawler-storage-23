import pytest

torch = pytest.importorskip("torch")

from srforge.transform.data import (
    MakeShapeDivisibleBy,
    CropBorder,
    MoveAxis,
    Standardize,
    Destandardize,
    AsType,
    ToFloat,
    ToDouble,
    Multiply,
    Divide,
    Downsample,
    Upsample,
    DisplacementToKernel,
    KernelToDisplacement,
    ToDb,
    Normalize,
    StackTensors,
    StackSequence,
)


# --- MakeShapeDivisibleBy ---


@pytest.mark.parametrize("B", [1, 2])
def test_make_shape_divisible_by_crops_end(B):
    image = torch.arange(B * 5 * 7, dtype=torch.float32).reshape(B, 1, 5, 7)
    original = image.clone()
    out = MakeShapeDivisibleBy(4).transform(image)

    assert out.shape == (B, 1, 4, 4)
    assert torch.equal(out, image[..., :-1, :-3])
    assert torch.equal(image, original)


# --- CropBorder ---


@pytest.mark.parametrize("B", [1, 2])
def test_crop_border_int(B):
    image = torch.arange(B * 10 * 12, dtype=torch.float32).reshape(B, 1, 10, 12)
    out = CropBorder(1).transform(image)

    assert out.shape == (B, 1, 8, 10)
    assert torch.equal(out, image[..., 1:-1, 1:-1])


def test_crop_border_tuple4():
    image = torch.arange(10 * 12, dtype=torch.float32).reshape(1, 1, 10, 12)
    original = image.clone()
    out = CropBorder((1, 2, 3, 4)).transform(image)

    assert out.shape == (1, 1, 4, 8)
    assert torch.equal(out, image[..., 4:-2, 1:-3])
    assert torch.equal(image, original)


def test_crop_border_tuple2_rejects_positive_values():
    with pytest.raises(ValueError):
        CropBorder((1, 1))


# --- MoveAxis ---


def test_move_axis():
    image = torch.zeros((1, 2, 3, 4), dtype=torch.float32)
    out = MoveAxis(1, 3).transform(image)

    assert out.shape == (1, 3, 4, 2)
    assert torch.equal(out, torch.movedim(image, 1, 3))
    assert out.dtype == image.dtype


def test_move_axis_batch_dim():
    image = torch.zeros((2, 3, 4, 5), dtype=torch.float32)
    out = MoveAxis(0, 2).transform(image)

    assert out.shape == (3, 4, 2, 5)
    assert torch.equal(out, torch.movedim(image, 0, 2))


# --- Standardize ---


def test_standardize_with_explicit_mean_std():
    image = torch.tensor([1.0, 2.0, 3.0], dtype=torch.float32).reshape(1, 1, 1, 3)
    out = Standardize(mean=2.0, std=0.5).transform(image)

    expected = torch.tensor([-2.0, 0.0, 2.0], dtype=torch.float32).reshape(1, 1, 1, 3)
    assert torch.allclose(out, expected)
    assert out.dtype == image.dtype


def test_standardize_handles_zero_std():
    image = torch.full((1, 1, 2, 2), 5.0, dtype=torch.float32)
    out = Standardize().transform(image)

    assert torch.allclose(out, torch.zeros_like(image))
    assert out.shape == image.shape


def test_standardize_per_sample_stats():
    image = torch.arange(40, dtype=torch.float32).reshape(2, 1, 1, 20)
    out = Standardize().transform(image)

    assert out.shape == image.shape
    assert torch.allclose(out.mean(dim=(1, 2, 3)), torch.tensor([0.0, 0.0]), atol=1e-6)
    assert torch.allclose(out.std(dim=(1, 2, 3)), torch.tensor([1.0, 1.0]), atol=1e-1)


# --- Destandardize ---


def test_destandardize_inverts_standardize():
    image = torch.tensor([1.0, 2.0, 3.0, 4.0], dtype=torch.float32).reshape(1, 1, 2, 2)
    mean, std = 2.5, 0.5
    standardized = Standardize(mean=mean, std=std).transform(image)
    out = Destandardize(mean=mean, std=std).transform(standardized)

    assert torch.allclose(out, image)
    assert out.dtype == image.dtype


def test_destandardize_inverts_standardize_multi_sample():
    image = torch.tensor([1.0, 2.0, 3.0, 4.0], dtype=torch.float32).reshape(2, 1, 1, 2)
    mean, std = 2.0, 0.5
    standardized = Standardize(mean=mean, std=std).transform(image)
    out = Destandardize(mean=mean, std=std).transform(standardized)

    assert torch.allclose(out, image)


def test_destandardize_requires_mean_std():
    with pytest.raises(ValueError):
        Destandardize()


# --- AsType, ToFloat, ToDouble ---


@pytest.mark.parametrize("B", [1, 2])
def test_as_type_to_float_and_double(B):
    image = torch.arange(B * 4, dtype=torch.int32).reshape(B, 1, 2, 2)

    out_as = AsType("float16").transform(image)
    assert out_as.dtype == torch.float16

    out_float = ToFloat().transform(image)
    assert out_float.dtype == torch.float32

    out_double = ToDouble().transform(image)
    assert out_double.dtype == torch.float64


# --- Multiply, Divide ---


@pytest.mark.parametrize("B", [1, 2])
def test_multiply_and_divide(B):
    image = torch.arange(1, B * 4 + 1, dtype=torch.float32).reshape(B, 1, 2, 2)
    original = image.clone()

    out_mul = Multiply(2.0).transform(image)
    assert torch.allclose(out_mul, image * 2.0)

    out_div = Divide(2.0).transform(image)
    assert torch.allclose(out_div, image / 2.0)
    assert torch.equal(image, original)


# --- Downsample, Upsample ---


@pytest.mark.parametrize("B", [1, 2])
def test_downsample_and_upsample(B):
    image = torch.zeros((B, 1, 8, 8), dtype=torch.float32)

    down = Downsample(scale_factor=2).transform(image)
    assert down.shape == (B, 1, 4, 4)

    up = Upsample(scale_factor=2, mode="nearest").transform(image)
    assert up.shape == (B, 1, 16, 16)
    assert down.dtype == image.dtype
    assert up.dtype == image.dtype


# --- DisplacementToKernel ---


def test_displacement_to_kernel_center_and_sum():
    displacement = torch.zeros((1, 1, 2), dtype=torch.float32)
    kernels = DisplacementToKernel(max_shift=2).transform(displacement)

    assert kernels.shape == (1, 1, 5, 5)
    assert torch.allclose(kernels.sum(dim=(-2, -1)), torch.ones((1, 1)))
    assert torch.allclose(kernels[0, 0, 2, 2], torch.tensor(1.0))
    assert kernels.dtype == displacement.dtype


def test_displacement_to_kernel_multi_channel():
    displacement = torch.zeros((2, 3, 2), dtype=torch.float32)
    kernels = DisplacementToKernel(max_shift=2).transform(displacement)

    assert kernels.shape == (2, 3, 5, 5)
    assert torch.allclose(kernels.sum(dim=(-2, -1)), torch.ones((2, 3)))


def test_displacement_to_kernel_rejects_out_of_range():
    displacement = torch.tensor([[[3.0, 0.0]]], dtype=torch.float32)

    with pytest.raises(ValueError):
        DisplacementToKernel(max_shift=2).transform(displacement)


# --- KernelToDisplacement ---


def test_kernel_to_displacement_round_trip():
    displacement = torch.tensor([[[0.4, -0.3]]], dtype=torch.float32)
    kernels = DisplacementToKernel(max_shift=2).transform(displacement)
    recovered = KernelToDisplacement().transform(kernels)

    assert torch.allclose(recovered, displacement, atol=1e-4)
    assert recovered.shape == displacement.shape


def test_kernel_to_displacement_round_trip_multi_channel():
    displacement = torch.tensor(
        [[[0.4, -0.3], [0.0, 0.0]], [[0.1, 0.2], [-0.2, 0.1]]], dtype=torch.float32
    )
    kernels = DisplacementToKernel(max_shift=2).transform(displacement)
    recovered = KernelToDisplacement().transform(kernels)

    assert recovered.shape == displacement.shape
    assert torch.allclose(recovered, displacement, atol=1e-4)


def test_kernel_to_displacement_rejects_even_kernel():
    kernels = torch.full((1, 1, 4, 4), 1.0 / 16, dtype=torch.float32)

    with pytest.raises(ValueError):
        KernelToDisplacement().transform(kernels)


# --- ToDb ---


def test_to_db():
    image = torch.tensor([1.0, 10.0, 100.0, 1000.0], dtype=torch.float32).reshape(1, 1, 2, 2)
    out = ToDb(eps=0.0).transform(image)

    expected = torch.tensor([0.0, 10.0, 20.0, 30.0], dtype=torch.float32).reshape(1, 1, 2, 2)
    assert torch.allclose(out, expected)
    assert out.dtype == image.dtype


def test_to_db_multi_sample():
    image = torch.tensor([1.0, 10.0, 100.0, 1000.0], dtype=torch.float32).reshape(2, 1, 1, 2)
    out = ToDb(eps=0.0).transform(image)

    expected = torch.tensor([0.0, 10.0, 20.0, 30.0], dtype=torch.float32).reshape(2, 1, 1, 2)
    assert torch.allclose(out, expected)


# --- Normalize ---


def test_normalize_with_range():
    image = torch.tensor([0.0, 1.0, 2.0, 3.0], dtype=torch.float32).reshape(1, 1, 1, 4)
    out = Normalize(range=(1.0, 2.0)).transform(image)

    expected = torch.tensor([0.0, 0.0, 1.0, 1.0], dtype=torch.float32).reshape(1, 1, 1, 4)
    assert torch.allclose(out, expected)


def test_normalize_default():
    image = torch.tensor([0.0, 1.0, 2.0, 3.0], dtype=torch.float32).reshape(1, 1, 1, 4)
    out = Normalize().transform(image)

    assert out.amin().item() == 0.0
    assert out.amax().item() == 1.0
    assert out.shape == image.shape


def test_normalize_per_sample():
    image = torch.tensor([0.0, 1.0, 2.0, 3.0], dtype=torch.float32).reshape(2, 1, 1, 2)
    out = Normalize().transform(image)

    assert torch.allclose(out.amin(dim=(1, 2, 3)), torch.tensor([0.0, 0.0]))
    assert torch.allclose(out.amax(dim=(1, 2, 3)), torch.tensor([1.0, 1.0]))


# --- StackTensors ---


def test_stack_tensors_dim1():
    tensors = [torch.randn(1, 3, 8, 8) for _ in range(4)]
    out = StackTensors(dim=1).transform(tensors)

    assert out.shape == (1, 4, 3, 8, 8)
    for i, t in enumerate(tensors):
        assert torch.equal(out[:, i], t)


def test_stack_tensors_dim0():
    tensors = [torch.randn(1, 3, 8, 8) for _ in range(3)]
    out = StackTensors(dim=0).transform(tensors)

    assert out.shape == (3, 1, 3, 8, 8)
    for i, t in enumerate(tensors):
        assert torch.equal(out[i], t)


def test_stack_tensors_standalone():
    """StackTensors works on a flat list of tensors (no collation)."""
    tensors = [torch.randn(1, 3, 4, 4) for _ in range(5)]
    out = StackTensors(dim=1).transform(tensors)
    assert out.shape == (1, 5, 3, 4, 4)


# --- StackSequence ---


def test_stack_sequence_dim1():
    """StackSequence stacks inner lists along dim=1 and stacks across batch."""
    inner1 = [torch.randn(3, 4, 4) for _ in range(3)]
    inner2 = [torch.randn(3, 4, 4) for _ in range(3)]
    field = [inner1, inner2]

    out = StackSequence(dim=1).transform(field)

    assert out.shape == (2, 3, 3, 4, 4)
    for i, t in enumerate(inner1):
        assert torch.equal(out[0, :, i], t)
    for i, t in enumerate(inner2):
        assert torch.equal(out[1, :, i], t)


def test_stack_sequence_dim2():
    inner1 = [torch.randn(3, 4, 4) for _ in range(4)]
    inner2 = [torch.randn(3, 4, 4) for _ in range(4)]
    field = [inner1, inner2]

    out = StackSequence(dim=2).transform(field)

    assert out.shape == (2, 3, 4, 4, 4)


def test_stack_sequence_with_io_binding():
    """StackSequence works end-to-end with Entry.collate and IO binding."""
    from srforge.data import Entry

    t = StackSequence(dim=0)
    t.set_io({"inputs": {"field": "lrs"}})

    raw1 = Entry(name="test_1", lrs=[torch.randn(3, 4, 4) for _ in range(5)])
    raw2 = Entry(name="test_2", lrs=[torch.randn(3, 4, 4) for _ in range(5)])
    entry = Entry.collate([raw1, raw2])

    result = t(entry)

    assert result["lrs"].shape == (2, 5, 3, 4, 4)
