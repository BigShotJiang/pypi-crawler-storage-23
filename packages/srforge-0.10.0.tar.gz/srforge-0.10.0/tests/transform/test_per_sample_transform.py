import torch
import pytest

from srforge.data import Entry
from srforge.transform import DataTransform
from srforge.models import SequentialModel


class TestDetection:
    def test_base_has_no_transform_unbatched(self):
        class Plain(DataTransform):
            def transform(self, image: torch.Tensor) -> torch.Tensor:
                return image

        t = Plain()
        assert t._has_transform is True
        assert t._has_transform_unbatched is False

    def test_sample_only_detected(self):
        class SampleOnly(DataTransform):
            def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
                return image * 2

        t = SampleOnly()
        assert t._has_transform is False
        assert t._has_transform_unbatched is True

    def test_both_overridden(self):
        class Both(DataTransform):
            def transform(self, image: torch.Tensor) -> torch.Tensor:
                return image

            def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
                return image * 2

        t = Both()
        assert t._has_transform is True
        assert t._has_transform_unbatched is True


class TestSimplePerSample:
    def test_doubles_input(self):
        class DoublePerSample(DataTransform):
            def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
                assert image.dim() == 3  # no batch dim: [C, H, W]
                return image * 2

        t = DoublePerSample()
        t.set_io({"inputs": {"image": "image"}})
        e1 = Entry(name="s1", image=torch.ones(3, 4, 4))
        e2 = Entry(name="s2", image=torch.ones(3, 4, 4))
        batch = Entry.collate([e1, e2])
        result = t(batch)
        assert result.image.shape == (2, 3, 4, 4)
        assert torch.allclose(result.image, torch.full((2, 3, 4, 4), 2.0))

    def test_single_sample_batch(self):
        class DoublePerSample(DataTransform):
            def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
                return image * 3

        t = DoublePerSample()
        t.set_io({"inputs": {"image": "image"}})
        batch = Entry.collate([Entry(name="s1", image=torch.ones(3, 4, 4))])
        result = t(batch)
        assert result.image.shape == (1, 3, 4, 4)
        assert torch.allclose(result.image, torch.full((1, 3, 4, 4), 3.0))


class TestIOBinding:
    def test_set_io_with_mapping(self):
        class DoublePerSample(DataTransform):
            def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
                return image * 2

        t = DoublePerSample()
        t.set_io({"inputs": {"image": "lr"}, "outputs": "sr"})
        batch = Entry.collate([Entry(name="s1", lr=torch.ones(3, 4, 4))])
        result = t(batch)
        assert result.sr.shape == (1, 3, 4, 4)
        assert torch.allclose(result.sr, torch.full((1, 3, 4, 4), 2.0))

    def test_structured_io(self):
        class AddPerSample(DataTransform):
            def transform_unbatched(self, image: torch.Tensor, offset: torch.Tensor) -> torch.Tensor:
                return image + offset

        t = AddPerSample()
        t.set_io({"inputs": {"image": "lr", "offset": "bias"}, "outputs": "sr"})
        e1 = Entry(name="s1", lr=torch.ones(1, 2, 2), bias=torch.full((1, 2, 2), 10.0))
        e2 = Entry(name="s2", lr=torch.ones(1, 2, 2), bias=torch.full((1, 2, 2), 10.0))
        batch = Entry.collate([e1, e2])
        result = t(batch)
        assert result.sr.shape == (2, 1, 2, 2)
        assert torch.allclose(result.sr, torch.full((2, 1, 2, 2), 11.0))


class TestMultiInput:
    def test_two_inputs_both_unbatched(self):
        class Combine(DataTransform):
            def transform_unbatched(self, image: torch.Tensor, reference: torch.Tensor) -> torch.Tensor:
                assert image.dim() == 3
                assert reference.dim() == 3
                return image + reference

        t = Combine()
        t.set_io({"inputs": {"image": "lr", "reference": "hr"}, "outputs": "result"})
        e1 = Entry(name="s1", lr=torch.ones(1, 4, 4), hr=torch.full((1, 4, 4), 5.0))
        e2 = Entry(name="s2", lr=torch.ones(1, 4, 4), hr=torch.full((1, 4, 4), 5.0))
        batch = Entry.collate([e1, e2])
        result = t(batch)
        assert result.result.shape == (2, 1, 4, 4)
        assert torch.allclose(result.result, torch.full((2, 1, 4, 4), 6.0))


class TestMultiOutput:
    def test_tuple_return_rebatched(self):
        class SplitPerSample(DataTransform):
            def transform_unbatched(self, image: torch.Tensor):
                return image[:1], image[1:]

        t = SplitPerSample()
        t.set_io({"inputs": {"image": "image"}, "outputs": ["first_channel", "rest"]})
        e1 = Entry(name="s1", image=torch.randn(3, 4, 4))
        e2 = Entry(name="s2", image=torch.randn(3, 4, 4))
        batch = Entry.collate([e1, e2])
        result = t(batch)
        assert result.first_channel.shape == (2, 1, 4, 4)
        assert result.rest.shape == (2, 2, 4, 4)


class TestTransformPriority:
    def test_transform_wins_over_transform_unbatched(self):
        """When both are overridden, batched transform() is used."""

        class Both(DataTransform):
            def transform(self, image: torch.Tensor) -> torch.Tensor:
                return image * 10  # batched

            def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
                return image * 2  # per-sample

        t = Both()
        t.set_io({"inputs": {"image": "image"}})
        batch = Entry.collate([Entry(name="s1", image=torch.ones(3, 4, 4))])
        result = t(batch)
        # transform() should win — multiply by 10, not 2
        assert torch.allclose(result.image, torch.full((1, 3, 4, 4), 10.0))


class TestSequentialModel:
    def test_per_sample_in_flow(self):
        class DoublePerSample(DataTransform):
            def transform_unbatched(self, image: torch.Tensor) -> torch.Tensor:
                return image * 2

        model = SequentialModel(
            modules={"double": DoublePerSample()},
            flow="image -> double -> image",
        )
        e1 = Entry(name="s1", image=torch.ones(3, 4, 4))
        e2 = Entry(name="s2", image=torch.ones(3, 4, 4))
        batch = Entry.collate([e1, e2])
        result = model(batch)
        assert result.image.shape == (2, 3, 4, 4)
        assert torch.allclose(result.image, torch.full((2, 3, 4, 4), 2.0))
