"""Tests for ``srforge init`` CLI scaffolding."""

import subprocess
import sys
from importlib.resources import files
from pathlib import Path

import pytest


@pytest.fixture()
def tmp_project(tmp_path, monkeypatch):
    """Change to a fresh temporary directory for each test."""
    monkeypatch.chdir(tmp_path)
    return tmp_path


class TestInit:
    def test_creates_files(self, tmp_project):
        """srforge init creates train.py and configs/train-cfg.yaml."""
        result = subprocess.run(
            [sys.executable, "-m", "srforge.cli", "init"],
            capture_output=True, text=True,
        )
        assert result.returncode == 0
        assert (tmp_project / "train.py").is_file()
        assert (tmp_project / "configs" / "train-cfg.yaml").is_file()
        assert "create" in result.stdout

    def test_skip_existing(self, tmp_project):
        """Refuses to overwrite without --force."""
        (tmp_project / "train.py").write_text("existing")
        result = subprocess.run(
            [sys.executable, "-m", "srforge.cli", "init"],
            capture_output=True, text=True,
        )
        assert result.returncode == 0
        assert "skip" in result.stdout
        # Original content preserved
        assert (tmp_project / "train.py").read_text() == "existing"
        # Config still created (it didn't exist)
        assert (tmp_project / "configs" / "train-cfg.yaml").is_file()

    def test_force_overwrites(self, tmp_project):
        """--force overwrites existing files."""
        (tmp_project / "train.py").write_text("old content")
        result = subprocess.run(
            [sys.executable, "-m", "srforge.cli", "init", "--force"],
            capture_output=True, text=True,
        )
        assert result.returncode == 0
        assert "create" in result.stdout
        assert (tmp_project / "train.py").read_text() != "old content"

    def test_no_command_shows_help(self):
        """No subcommand prints help and exits with code 1."""
        result = subprocess.run(
            [sys.executable, "-m", "srforge.cli"],
            capture_output=True, text=True,
        )
        assert result.returncode == 1
        assert "usage" in result.stdout.lower() or "usage" in result.stderr.lower()

    def test_content_matches_scaffold(self, tmp_project):
        """Generated files match the scaffold templates exactly."""
        scaffold = files("srforge.scaffold")

        subprocess.run(
            [sys.executable, "-m", "srforge.cli", "init"],
            capture_output=True, text=True,
        )
        assert (tmp_project / "train.py").read_text(encoding="utf-8") == \
            scaffold.joinpath("train.py").read_text(encoding="utf-8")
        assert (tmp_project / "configs" / "train-cfg.yaml").read_text(encoding="utf-8") == \
            scaffold.joinpath("train-cfg.yaml").read_text(encoding="utf-8")
