"""Exhaustive reference tests for all io_map formats accepted by set_io.

Each test documents one specific io_map input format, verifies the exact
internal state produced (_applications, _io_bound), and checks the runtime
behavior (what is read/written in the Entry).

Uses the unified IO config format exclusively::

    {"inputs": {param_or_port: entry_field}, "outputs": <string|list|dict>}

Organized by consumer class:
  - IOModule (base): used by EntryTransform, Model
  - DataTransform configs: dict inputs → _applications
  - Annotation-driven recursion: recurse Tensor, pass dict raw, broadcast
  - EntryTransform: all accepted formats
  - Error cases: formats that must be rejected
"""

import pytest
import torch

from srforge.data import Entry
from srforge.transform import EntryTransform, DataTransform
from srforge.utils import IOSpec, IOModule


# -- Test fixtures ------------------------------------------------------------

def _t(*values):
    return torch.tensor(list(values), dtype=torch.float32)


class _IOModuleWithSpec(IOModule):
    """IOModule with required + optional ports."""
    io_spec = IOSpec(
        required_inputs=("field", "reference"),
        optional_outputs=("output",),
    )


class _IOModuleNoSpec(IOModule):
    """IOModule with no IOSpec (empty)."""
    pass


class _SingleInputTransform(DataTransform):
    """transform(image) -> image * 2"""
    def transform(self, image):
        return image * 2


class _TensorAnnotatedTransform(DataTransform):
    """transform(image: Tensor) -> image * 2  -- annotation triggers recursion."""
    def transform(self, image: torch.Tensor) -> torch.Tensor:
        return image * 2


class _DictAnnotatedTransform(DataTransform):
    """transform(field: dict) -> dict  -- annotation suppresses recursion."""
    def transform(self, field: dict) -> dict:
        return {k: v * 10 for k, v in field.items()}


class _MultiInputTransform(DataTransform):
    """transform(image, reference) -> image + reference"""
    def transform(self, image, reference):
        return image + reference


class _MultiInputTensorAnnotated(DataTransform):
    """transform(image: Tensor, reference: Tensor) -> image + reference"""
    def transform(self, image: torch.Tensor, reference: torch.Tensor) -> torch.Tensor:
        return image + reference


class _MultiOutputTransform(DataTransform):
    """transform(image) -> (image * 2, image * 3)"""
    def transform(self, image):
        return image * 2, image * 3


class _MultiInputMultiOutputTransform(DataTransform):
    """transform(image, reference) -> (image + reference, image - reference)"""
    def transform(self, image, reference):
        return image + reference, image - reference


class _TestEntryTransform(EntryTransform):
    """EntryTransform with required + optional ports."""
    io_spec = IOSpec(
        required_inputs=("field", "reference"),
        optional_outputs=("output",),
    )

    def transform_unbatched(self, entry):
        val = entry[self.field] + entry[self.reference]
        target = self.output if self.output is not None else self.field
        entry[target] = val
        return entry


class _CollidingAttrModule(IOModule):
    """IOModule where __init__ sets self.name, which collides with port 'name'."""
    io_spec = IOSpec(required_inputs=("name",), required_outputs=("name_upper",))

    def __init__(self):
        super().__init__()
        self.name = "MyModule"  # after super().__init__ so it's a real instance attr


class _CollidingAttrTransform(EntryTransform):
    """EntryTransform where __init__ sets self.mode, which collides with port 'mode'."""
    io_spec = IOSpec(required_inputs=("mode", "field"), required_outputs=("output",))

    def __init__(self, mode: str = "fast"):
        self._saved_mode = mode
        super().__init__()
        self.mode = mode  # after super().__init__ so it's a real instance attr

    def transform_unbatched(self, entry):
        entry[self.output] = entry[self.field]
        return entry


# =============================================================================
# IOModule base (used by EntryTransform, Model)
# =============================================================================

class TestIOModuleWithSpec:
    """IOModule with IOSpec: required_inputs=(field, reference), optional_outputs=(output,)."""

    def test_structured_dict_all_ports(self):
        """set_io({"inputs": {"field": "lrs", "reference": "hr"}, "outputs": {"output": "sr"}})

        _resolved_vars = {"field": "lrs", "reference": "hr", "output": "sr"}
        self.field = "lrs", self.reference = "hr", self.output = "sr"
        """
        m = _IOModuleWithSpec()
        m.set_io({"inputs": {"field": "lrs", "reference": "hr"}, "outputs": {"output": "sr"}})

        assert m._resolved_vars == {"field": "lrs", "reference": "hr", "output": "sr"}
        assert m.field == "lrs"
        assert m.reference == "hr"
        assert m.output == "sr"
        assert m._io_bound is True

    def test_structured_dict_optional_omitted(self):
        """set_io({"inputs": {"field": "lrs", "reference": "hr"}})

        _resolved_vars = {"field": "lrs", "reference": "hr", "output": None}
        self.output = None
        """
        m = _IOModuleWithSpec()
        m.set_io({"inputs": {"field": "lrs", "reference": "hr"}})

        assert m._resolved_vars == {"field": "lrs", "reference": "hr", "output": None}
        assert m.field == "lrs"
        assert m.reference == "hr"
        assert m.output is None

    def test_same_field_for_multiple_ports(self):
        """set_io({"inputs": {"field": "x", "reference": "x"}, "outputs": {"output": "x"}})

        Same field name for different ports -- allowed.
        _resolved_vars = {"field": "x", "reference": "x", "output": "x"}
        """
        m = _IOModuleWithSpec()
        m.set_io({"inputs": {"field": "x", "reference": "x"}, "outputs": {"output": "x"}})

        assert m._resolved_vars == {"field": "x", "reference": "x", "output": "x"}
        assert m.field == "x"
        assert m.reference == "x"
        assert m.output == "x"

    def test_structured_outputs_omitted_optional_is_none(self):
        """set_io({"inputs": {"field": "lrs", "reference": "hr"}})

        No outputs section -- optional output gets None.
        _resolved_vars = {"field": "lrs", "reference": "hr", "output": None}
        """
        m = _IOModuleWithSpec()
        m.set_io({"inputs": {"field": "lrs", "reference": "hr"}})

        assert m._resolved_vars == {"field": "lrs", "reference": "hr", "output": None}
        assert m.output is None


class TestIOModuleNoSpec:
    """IOModule with no IOSpec -- raw passthrough, no validation."""

    def test_structured_dict_merged(self):
        """set_io({"inputs": {"a": "x"}, "outputs": {"b": "y"}})

        Sections merged -> {"a": "x", "b": "y"}.
        """
        m = _IOModuleNoSpec()
        m.set_io({"inputs": {"a": "x"}, "outputs": {"b": "y"}})

        assert m._resolved_vars == {"a": "x", "b": "y"}

    def test_structured_inputs_only(self):
        """set_io({"inputs": {"a": "x", "b": "y"}})

        No outputs -- just inputs.
        """
        m = _IOModuleNoSpec()
        m.set_io({"inputs": {"a": "x", "b": "y"}})

        assert m._resolved_vars == {"a": "x", "b": "y"}
        assert m.a == "x"
        assert m.b == "y"


# =============================================================================
# DataTransform configs -- all normalize to _applications
# =============================================================================

class TestDataTransformConfigs:
    """DataTransform unified config: dict inputs -> _applications.

    All formats normalize to _applications via build_applications.
    Runtime uses _apply_recursive with annotation-driven recursion.
    """

    # -- Single application (inputs as dict) -----------------------------------

    def test_single_input_identity(self):
        """set_io({"inputs": {"image": "image"}})

        _applications = [({"image": "image"}, ["image"])]
        Runtime: entry["image"] = transform(entry["image"])
        """
        t = _SingleInputTransform()
        t.set_io({"inputs": {"image": "image"}})

        assert t._applications == [({"image": "image"}, ["image"])]
        assert t._io_bound is True

        result = t(Entry(name="test", image=_t(1, 2, 3)))
        assert torch.equal(result["image"], _t(2, 4, 6))

    def test_single_input_rename(self):
        """set_io({"inputs": {"image": "lrs"}, "outputs": "sr"})

        _applications = [({"image": "lrs"}, ["sr"])]
        Runtime: reads entry["lrs"] -> writes entry["sr"].
        """
        t = _SingleInputTransform()
        t.set_io({"inputs": {"image": "lrs"}, "outputs": "sr"})

        assert t._applications == [({"image": "lrs"}, ["sr"])]

        result = t(Entry(name="test", lrs=_t(5)))
        assert torch.equal(result["sr"], _t(10))

    def test_single_input_list_output(self):
        """set_io({"inputs": {"image": "lrs"}, "outputs": ["sr"]})

        _applications = [({"image": "lrs"}, ["sr"])]
        """
        t = _SingleInputTransform()
        t.set_io({"inputs": {"image": "lrs"}, "outputs": ["sr"]})

        assert t._applications == [({"image": "lrs"}, ["sr"])]

        result = t(Entry(name="test", lrs=_t(5)))
        assert torch.equal(result["sr"], _t(10))

    def test_single_input_no_outputs_defaults_to_inplace(self):
        """set_io({"inputs": {"image": "lrs"}})

        No outputs -> defaults to input field values = in-place.
        _applications = [({"image": "lrs"}, ["lrs"])]
        """
        t = _SingleInputTransform()
        t.set_io({"inputs": {"image": "lrs"}})

        assert t._applications == [({"image": "lrs"}, ["lrs"])]

        result = t(Entry(name="test", lrs=_t(4)))
        assert torch.equal(result["lrs"], _t(8))

    # -- Multiple applications (inputs as list of dicts) -----------------------

    def test_multi_app_identity(self):
        """set_io({"inputs": [{"image": "lrs"}, {"image": "hr"}]})

        No outputs -> in-place for each application.
        _applications = [({"image": "lrs"}, ["lrs"]), ({"image": "hr"}, ["hr"])]
        """
        t = _SingleInputTransform()
        t.set_io({"inputs": [{"image": "lrs"}, {"image": "hr"}]})

        assert t._applications == [
            ({"image": "lrs"}, ["lrs"]),
            ({"image": "hr"}, ["hr"]),
        ]
        assert t._io_bound is True

        result = t(Entry(name="test", lrs=_t(1), hr=_t(10)))
        assert torch.equal(result["lrs"], _t(2))
        assert torch.equal(result["hr"], _t(20))

    def test_multi_app_with_rename(self):
        """set_io({"inputs": [{"image": "lrs"}, {"image": "hr"}], "outputs": ["sr", "hr"]})

        _applications = [({"image": "lrs"}, ["sr"]), ({"image": "hr"}, ["hr"])]
        Runtime: reads entry["lrs"] -> writes entry["sr"],
                 reads entry["hr"] -> writes entry["hr"].
        """
        t = _SingleInputTransform()
        t.set_io({"inputs": [{"image": "lrs"}, {"image": "hr"}], "outputs": ["sr", "hr"]})

        assert t._applications == [
            ({"image": "lrs"}, ["sr"]),
            ({"image": "hr"}, ["hr"]),
        ]

        result = t(Entry(name="test", lrs=_t(1), hr=_t(10)))
        assert torch.equal(result["sr"], _t(2))
        assert torch.equal(result["hr"], _t(20))

    # -- Multi-input single application ----------------------------------------

    def test_multi_input_single_output(self):
        """set_io({"inputs": {"image": "lrs", "reference": "hr"}, "outputs": "sr"})

        _applications = [({"image": "lrs", "reference": "hr"}, ["sr"])]
        Runtime: entry["sr"] = transform(image=entry["lrs"], reference=entry["hr"])
        """
        t = _MultiInputTransform()
        t.set_io({"inputs": {"image": "lrs", "reference": "hr"}, "outputs": "sr"})

        assert t._applications == [({"image": "lrs", "reference": "hr"}, ["sr"])]
        assert t._io_bound is True

        result = t(Entry(name="test", lrs=_t(1, 2), hr=_t(10, 20)))
        assert torch.equal(result["sr"], _t(11, 22))

    def test_multi_input_multi_output(self):
        """set_io({"inputs": {"image": "lrs", "reference": "hr"}, "outputs": ["sum", "diff"]})

        _applications = [({"image": "lrs", "reference": "hr"}, ["sum", "diff"])]
        Runtime: a, b = transform(...); entry["sum"] = a, entry["diff"] = b
        """
        t = _MultiInputMultiOutputTransform()
        t.set_io({"inputs": {"image": "lrs", "reference": "hr"}, "outputs": ["sum", "diff"]})

        assert t._applications == [({"image": "lrs", "reference": "hr"}, ["sum", "diff"])]

        result = t(Entry(name="test", lrs=_t(10, 20), hr=_t(3, 5)))
        assert torch.equal(result["sum"], _t(13, 25))
        assert torch.equal(result["diff"], _t(7, 15))

    def test_multi_input_no_outputs_raises(self):
        """Omitting outputs with multiple inputs is an error."""
        t = _MultiInputTransform()
        with pytest.raises(ValueError, match="'outputs' is required when 'inputs' has multiple parameters"):
            t.set_io({"inputs": {"image": "lrs", "reference": "hr"}})

    # -- Multiple multi-input applications ------------------------------------

    def test_multi_input_multiple_applications(self):
        """set_io({"inputs": [{"image": "lrs", "reference": "hr"}, {"image": "rgb", "reference": "hr"}],
                   "outputs": ["lrs_out", "rgb_out"]})

        _applications = [
            ({"image": "lrs", "reference": "hr"}, ["lrs_out"]),
            ({"image": "rgb", "reference": "hr"}, ["rgb_out"]),
        ]
        """
        t = _MultiInputTransform()
        t.set_io({
            "inputs": [{"image": "lrs", "reference": "hr"}, {"image": "rgb", "reference": "hr"}],
            "outputs": ["lrs_out", "rgb_out"],
        })

        assert t._applications == [
            ({"image": "lrs", "reference": "hr"}, ["lrs_out"]),
            ({"image": "rgb", "reference": "hr"}, ["rgb_out"]),
        ]

        result = t(Entry(name="test", lrs=_t(1), rgb=_t(100), hr=_t(10)))
        assert torch.equal(result["lrs_out"], _t(11))
        assert torch.equal(result["rgb_out"], _t(110))

    # -- Multi-input with multi-output lists -----------------------------------

    def test_multi_input_multiple_apps_with_multi_output(self):
        """set_io({"inputs": [{"image": "lrs", "reference": "hr"}],
                   "outputs": [["sum", "diff"]]})

        _applications = [({"image": "lrs", "reference": "hr"}, ["sum", "diff"])]
        Runtime: a, b = transform(...); entry["sum"] = a, entry["diff"] = b
        """
        t = _MultiInputMultiOutputTransform()
        t.set_io({
            "inputs": [{"image": "lrs", "reference": "hr"}],
            "outputs": [["sum", "diff"]],
        })

        assert t._applications == [
            ({"image": "lrs", "reference": "hr"}, ["sum", "diff"]),
        ]

        result = t(Entry(name="test", lrs=_t(10), hr=_t(3)))
        assert torch.equal(result["sum"], _t(13))
        assert torch.equal(result["diff"], _t(7))

    # -- Single-input multi-output with multiple apps --------------------------

    def test_single_input_multi_output_multiple_apps(self):
        """set_io({"inputs": [{"image": "lrs"}, {"image": "rgb"}],
                   "outputs": [["a", "b"], ["c", "d"]]})

        _applications = [
            ({"image": "lrs"}, ["a", "b"]),
            ({"image": "rgb"}, ["c", "d"]),
        ]
        """
        t = _MultiOutputTransform()
        t.set_io({
            "inputs": [{"image": "lrs"}, {"image": "rgb"}],
            "outputs": [["a", "b"], ["c", "d"]],
        })

        assert t._applications == [
            ({"image": "lrs"}, ["a", "b"]),
            ({"image": "rgb"}, ["c", "d"]),
        ]

        result = t(Entry(name="test", lrs=_t(5), rgb=_t(10)))
        assert torch.equal(result["a"], _t(10))  # 5 * 2
        assert torch.equal(result["b"], _t(15))  # 5 * 3
        assert torch.equal(result["c"], _t(20))  # 10 * 2
        assert torch.equal(result["d"], _t(30))  # 10 * 3

    # -- Resolved property -----------------------------------------------------

    def test_resolved_property_reconstructs_flat_mapping(self):
        """resolved property reconstructs {src: dst} from single-input applications."""
        t = _SingleInputTransform()
        t.set_io({"inputs": [{"image": "lrs"}, {"image": "hr"}], "outputs": ["sr", "hr"]})

        assert t.resolved == {"lrs": "sr", "hr": "hr"}


# =============================================================================
# Config normalization -- verify all formats produce _applications
# =============================================================================

class TestConfigNormalization:
    """Verify that all io_map formats produce _applications for DataTransform."""

    def test_dict_inputs_produces_applications(self):
        t = _SingleInputTransform()
        t.set_io({"inputs": {"image": "image"}})
        assert t._applications == [({"image": "image"}, ["image"])]

    def test_dict_inputs_with_string_output_produces_applications(self):
        t = _SingleInputTransform()
        t.set_io({"inputs": {"image": "lrs"}, "outputs": "sr"})
        assert t._applications == [({"image": "lrs"}, ["sr"])]

    def test_list_of_dicts_produces_applications(self):
        t = _SingleInputTransform()
        t.set_io({"inputs": [{"image": "lrs"}, {"image": "hr"}]})
        assert t._applications == [
            ({"image": "lrs"}, ["lrs"]),
            ({"image": "hr"}, ["hr"]),
        ]

    def test_list_of_dicts_with_outputs_produces_applications(self):
        t = _SingleInputTransform()
        t.set_io({"inputs": [{"image": "lrs"}], "outputs": ["sr"]})
        assert t._applications == [({"image": "lrs"}, ["sr"])]

    def test_dict_inputs_multi_param_produces_applications(self):
        """{"inputs": {dict}, ...} -> structured path."""
        t = _MultiInputTransform()
        t.set_io({"inputs": {"image": "lrs", "reference": "hr"}, "outputs": "out"})
        assert t._applications == [({"image": "lrs", "reference": "hr"}, ["out"])]

    def test_list_of_dicts_multi_param_produces_applications(self):
        """{"inputs": [{dict}, ...], ...} -> multiple applications."""
        t = _MultiInputTransform()
        t.set_io({"inputs": [{"image": "lrs", "reference": "hr"}], "outputs": ["out"]})
        assert t._applications == [({"image": "lrs", "reference": "hr"}, ["out"])]

    def test_multi_output_list_in_outputs_produces_applications(self):
        """{"inputs": [{"image": "x"}], "outputs": [["a", "b"]]} -> multi-output app."""
        t = _MultiOutputTransform()
        t.set_io({"inputs": [{"image": "x"}], "outputs": [["a", "b"]]})
        assert t._applications == [({"image": "x"}, ["a", "b"])]


# =============================================================================
# Annotation-driven recursion
# =============================================================================

class TestAnnotationDrivenRecursion:
    """Verify that type annotations control recursion behavior."""

    def test_no_annotation_recurses_into_dict(self):
        """transform(image) with no annotation -> recurses into dict values."""
        t = _SingleInputTransform()
        t.set_io({"inputs": {"image": "field"}})

        entry = Entry(field={"a": _t(1, 2), "b": _t(3, 4)})
        result = t(entry)

        assert torch.equal(result["field"]["a"], _t(2, 4))
        assert torch.equal(result["field"]["b"], _t(6, 8))

    def test_tensor_annotated_recurses_into_dict(self):
        """transform(image: Tensor) -> recurses into dict values."""
        t = _TensorAnnotatedTransform()
        t.set_io({"inputs": {"image": "field"}})

        entry = Entry(field={"a": _t(1, 2), "b": _t(3, 4)})
        result = t(entry)

        assert torch.equal(result["field"]["a"], _t(2, 4))
        assert torch.equal(result["field"]["b"], _t(6, 8))

    def test_dict_annotated_skips_recursion(self):
        """transform(field: dict) -> dict passed whole, no recursion."""
        t = _DictAnnotatedTransform()
        t.set_io({"inputs": {"field": "data"}})

        entry = Entry(data={"a": _t(1), "b": _t(2)})
        result = t(entry)

        # dict was passed whole to transform, which does v * 10
        assert torch.equal(result["data"]["a"], _t(10))
        assert torch.equal(result["data"]["b"], _t(20))

    def test_no_annotation_recurses_into_list(self):
        """transform(image) with no annotation -> recurses into list elements."""
        t = _SingleInputTransform()
        t.set_io({"inputs": {"image": "field"}})

        entry = Entry(field=[_t(1, 2), _t(3, 4)])
        result = t(entry)

        assert isinstance(result["field"], list)
        assert torch.equal(result["field"][0], _t(2, 4))
        assert torch.equal(result["field"][1], _t(6, 8))

    def test_tensor_annotated_recurses_into_tuple(self):
        """transform(image: Tensor) -> recurses into tuple elements."""
        t = _TensorAnnotatedTransform()
        t.set_io({"inputs": {"image": "field"}})

        entry = Entry(field=(_t(1), _t(2)))
        result = t(entry)

        assert isinstance(result["field"], tuple)
        assert torch.equal(result["field"][0], _t(2))
        assert torch.equal(result["field"][1], _t(4))

    def test_dict_annotated_with_structured_config(self):
        """transform(field: dict) via dict-inputs syntax also skips recursion."""
        t = _DictAnnotatedTransform()
        t.set_io({"inputs": {"field": "data"}, "outputs": "out"})

        entry = Entry(data={"a": _t(1), "b": _t(2)})
        result = t(entry)

        assert torch.equal(result["out"]["a"], _t(10))
        assert torch.equal(result["out"]["b"], _t(20))

    def test_multi_input_parallel_dict_recursion(self):
        """transform(image: Tensor, reference: Tensor) with both dicts -> parallel recursion."""
        t = _MultiInputTensorAnnotated()
        t.set_io({"inputs": {"image": "lrs", "reference": "hr"}, "outputs": "out"})

        entry = Entry(
            lrs={"b1": _t(1), "b2": _t(2)},
            hr={"b1": _t(10), "b2": _t(20)},
        )
        result = t(entry)

        assert torch.equal(result["out"]["b1"], _t(11))
        assert torch.equal(result["out"]["b2"], _t(22))

    def test_multi_input_broadcast_tensor(self):
        """transform(image: Tensor, reference: Tensor) where image=dict, reference=Tensor.

        reference is broadcast to each dict key.
        """
        t = _MultiInputTensorAnnotated()
        t.set_io({"inputs": {"image": "lrs", "reference": "hr"}, "outputs": "out"})

        entry = Entry(
            lrs={"b1": _t(1), "b2": _t(2)},
            hr=_t(100),  # scalar tensor, broadcast to each key
        )
        result = t(entry)

        assert torch.equal(result["out"]["b1"], _t(101))
        assert torch.equal(result["out"]["b2"], _t(102))

    def test_multi_input_parallel_list_recursion(self):
        """transform(image: Tensor, reference: Tensor) with both lists -> parallel recursion."""
        t = _MultiInputTensorAnnotated()
        t.set_io({"inputs": {"image": "lrs", "reference": "hr"}, "outputs": "out"})

        entry = Entry(
            lrs=[_t(1), _t(2)],
            hr=[_t(10), _t(20)],
        )
        result = t(entry)

        assert isinstance(result["out"], list)
        assert torch.equal(result["out"][0], _t(11))
        assert torch.equal(result["out"][1], _t(22))

    def test_multi_input_dict_key_mismatch_raises(self):
        """Different dict keys across recursive params -> ValueError."""
        t = _MultiInputTensorAnnotated()
        t.set_io({"inputs": {"image": "lrs", "reference": "hr"}, "outputs": "out"})

        entry = Entry(
            lrs={"b1": _t(1), "b2": _t(2)},
            hr={"b1": _t(10), "b3": _t(30)},  # b3 instead of b2
        )
        with pytest.raises(ValueError, match="dict keys mismatch"):
            t(entry)

    def test_multi_input_mixed_dict_list_raises(self):
        """One dict, one list across recursive params -> TypeError."""
        t = _MultiInputTensorAnnotated()
        t.set_io({"inputs": {"image": "lrs", "reference": "hr"}, "outputs": "out"})

        entry = Entry(
            lrs={"b1": _t(1)},
            hr=[_t(10)],
        )
        with pytest.raises(TypeError, match="cannot mix dict and list"):
            t(entry)

    def test_nested_dict_recursion(self):
        """Nested dicts: recursion proceeds level by level."""
        t = _TensorAnnotatedTransform()
        t.set_io({"inputs": {"image": "field"}})

        entry = Entry(field={"a": {"x": _t(1), "y": _t(2)}, "b": _t(3)})
        result = t(entry)

        assert torch.equal(result["field"]["a"]["x"], _t(2))
        assert torch.equal(result["field"]["a"]["y"], _t(4))
        assert torch.equal(result["field"]["b"], _t(6))


# =============================================================================
# EntryTransform -- all accepted formats
# =============================================================================

class TestEntryTransformFormats:
    """EntryTransform uses port-based binding via IOModule.

    IOSpec: required_inputs=(field, reference), optional_outputs=(output,).
    """

    def test_structured_dict_all_ports(self):
        """set_io({"inputs": {"field": "lrs", "reference": "hr"}, "outputs": {"output": "sr"}})

        _resolved_vars = {"field": "lrs", "reference": "hr", "output": "sr"}
        """
        t = _TestEntryTransform()
        t.set_io({"inputs": {"field": "lrs", "reference": "hr"}, "outputs": {"output": "sr"}})

        assert t._resolved_vars == {"field": "lrs", "reference": "hr", "output": "sr"}
        assert t.field == "lrs"
        assert t.reference == "hr"
        assert t.output == "sr"

        result = t(Entry(lrs=_t(1, 2), hr=_t(10, 20)))
        assert torch.equal(result["sr"], _t(11, 22))

    def test_structured_dict_optional_omitted(self):
        """set_io({"inputs": {"field": "lrs", "reference": "hr"}})

        Optional output gets None (no shared port name with inputs).
        _resolved_vars = {"field": "lrs", "reference": "hr", "output": None}
        """
        t = _TestEntryTransform()
        t.set_io({"inputs": {"field": "lrs", "reference": "hr"}})

        assert t._resolved_vars == {"field": "lrs", "reference": "hr", "output": None}
        assert t.output is None

        result = t(Entry(lrs=_t(1, 2), hr=_t(10, 20)))
        assert torch.equal(result["lrs"], _t(11, 22))  # writes back to field

    def test_structured_dict_sections(self):
        """set_io({"inputs": {"field": "lrs", "reference": "hr"}, "outputs": {"output": "sr"}})

        Sections merged -> {"field": "lrs", "reference": "hr", "output": "sr"}.
        """
        t = _TestEntryTransform()
        t.set_io({"inputs": {"field": "lrs", "reference": "hr"}, "outputs": {"output": "sr"}})

        assert t._resolved_vars == {"field": "lrs", "reference": "hr", "output": "sr"}

        result = t(Entry(lrs=_t(1), hr=_t(10)))
        assert torch.equal(result["sr"], _t(11))

    def test_string_output_maps_to_first_output_port(self):
        """set_io({"inputs": {"field": "lrs", "reference": "hr"}, "outputs": "sr"})

        String output -> mapped to the first output port ("output").
        """
        t = _TestEntryTransform()
        t.set_io({"inputs": {"field": "lrs", "reference": "hr"}, "outputs": "sr"})

        assert t._resolved_vars == {"field": "lrs", "reference": "hr", "output": "sr"}
        assert t.output == "sr"

        result = t(Entry(lrs=_t(1), hr=_t(10)))
        assert torch.equal(result["sr"], _t(11))

    def test_list_output_maps_to_output_ports(self):
        """set_io({"inputs": {"field": "lrs", "reference": "hr"}, "outputs": ["sr"]})

        List output -> mapped positionally to output ports.
        """
        t = _TestEntryTransform()
        t.set_io({"inputs": {"field": "lrs", "reference": "hr"}, "outputs": ["sr"]})

        assert t._resolved_vars == {"field": "lrs", "reference": "hr", "output": "sr"}
        assert t.output == "sr"


# =============================================================================
# Error cases -- formats that must be rejected
# =============================================================================

class TestErrorCases:

    # -- IOModule errors -------------------------------------------------------

    def test_iomodule_none_raises(self):
        m = _IOModuleWithSpec()
        with pytest.raises(TypeError, match="IO config must be a dict"):
            m.set_io(None)

    def test_iomodule_string_raises(self):
        """IOModule does not accept string format."""
        m = _IOModuleWithSpec()
        with pytest.raises(TypeError, match="IO config must be a dict"):
            m.set_io("field")

    def test_iomodule_list_raises(self):
        """IOModule does not accept list format."""
        m = _IOModuleWithSpec()
        with pytest.raises(TypeError, match="IO config must be a dict"):
            m.set_io(["field", "reference"])

    def test_iomodule_flat_dict_without_inputs_key_raises(self):
        """Flat dict without 'inputs' key is rejected."""
        m = _IOModuleWithSpec()
        with pytest.raises(TypeError, match="IO config must be a dict"):
            m.set_io({"field": "lrs", "reference": "hr"})

    def test_iomodule_unknown_port_strict_raises(self):
        m = _IOModuleWithSpec()
        with pytest.raises(ValueError, match="unknown variables"):
            m.set_io({"inputs": {"field": "lrs", "reference": "hr", "bogus": "x"}})

    def test_iomodule_missing_required_raises(self):
        m = _IOModuleWithSpec()
        with pytest.raises(ValueError, match="missing required"):
            m.set_io({"inputs": {"field": "lrs"}})  # 'reference' missing

    def test_iomodule_structured_conflicting_port_raises(self):
        """Same port in inputs and outputs mapped to different fields."""
        m = _IOModuleNoSpec()
        with pytest.raises(ValueError, match="conflicting bindings"):
            m.set_io({"inputs": {"a": "x"}, "outputs": {"a": "y"}})

    def test_iomodule_inputs_not_dict_raises(self):
        """IOModule requires inputs to be a dict (not list of dicts)."""
        m = _IOModuleWithSpec()
        with pytest.raises(TypeError, match="'inputs' must be a dict for port-based"):
            m.set_io({"inputs": [{"field": "lrs"}]})

    def test_iomodule_outputs_not_dict_raises(self):
        """IOModule requires outputs to be a dict (not string or list)."""
        m = _IOModuleWithSpec()
        with pytest.raises(TypeError, match="'outputs' must be a dict"):
            m.set_io({"inputs": {"field": "lrs", "reference": "hr"}, "outputs": "sr"})

    # -- Port/attribute collision guard ----------------------------------------

    def test_port_shadows_instance_attribute_raises(self):
        """self.name = ... in __init__ is caught by descriptor at construction time."""
        with pytest.raises(AttributeError, match="cannot assign to IO port"):
            _CollidingAttrModule()

    def test_port_shadows_init_attribute_on_transform_raises(self):
        """self.mode = ... in __init__ is caught by descriptor at construction time."""
        with pytest.raises(AttributeError, match="cannot assign to IO port"):
            _CollidingAttrTransform(mode="fast")

    def test_rebinding_same_ports_allowed(self):
        """Re-calling set_io with the same port names must not raise."""
        m = _IOModuleWithSpec()
        m.set_io({"inputs": {"field": "lrs", "reference": "hr"}})
        assert m.field == "lrs"
        # Rebind -- same ports, different fields:
        m.set_io({"inputs": {"field": "rgb", "reference": "nir"}})
        assert m.field == "rgb"
        assert m.reference == "nir"

    def test_no_collision_when_port_matches_spec_only(self):
        """Ports that only exist in IOSpec (never set as instance attrs) are fine."""
        m = _IOModuleWithSpec()
        m.set_io({"inputs": {"field": "x", "reference": "y"}, "outputs": {"output": "z"}})
        assert m.field == "x"
        assert m.reference == "y"
        assert m.output == "z"

    # -- Descriptor immutability -----------------------------------------------

    def test_bound_port_is_read_only(self):
        """After set_io, direct assignment to a port attribute raises."""
        m = _IOModuleWithSpec()
        m.set_io({"inputs": {"field": "lrs", "reference": "hr"}})
        with pytest.raises(AttributeError, match="cannot assign to IO port"):
            m.field = "something_else"

    def test_bound_port_cannot_be_deleted(self):
        """After set_io, deleting a port attribute raises."""
        m = _IOModuleWithSpec()
        m.set_io({"inputs": {"field": "lrs", "reference": "hr"}})
        with pytest.raises(AttributeError, match="cannot delete IO port"):
            del m.field

    def test_unbound_port_access_raises(self):
        """Before set_io, accessing a port attribute raises."""
        m = _IOModuleWithSpec()
        with pytest.raises(AttributeError, match="not bound yet"):
            _ = m.field

    def test_unbound_port_assignment_raises(self):
        """Before set_io, assigning to a port attribute raises."""
        m = _IOModuleWithSpec()
        with pytest.raises(AttributeError, match="cannot assign to IO port"):
            m.field = "x"

    # -- DataTransform config errors -------------------------------------------

    def test_datatransform_none_raises(self):
        t = _SingleInputTransform()
        with pytest.raises(TypeError, match="IO config must be a dict"):
            t.set_io(None)

    def test_datatransform_string_raises(self):
        """String format is no longer accepted."""
        t = _SingleInputTransform()
        with pytest.raises(TypeError, match="IO config must be a dict"):
            t.set_io("image")

    def test_datatransform_list_raises(self):
        """List format is no longer accepted."""
        t = _SingleInputTransform()
        with pytest.raises(TypeError, match="IO config must be a dict"):
            t.set_io(["lrs", "hr"])

    def test_datatransform_flat_dict_raises(self):
        """Flat dict (without 'inputs' key) is no longer accepted."""
        t = _SingleInputTransform()
        with pytest.raises(TypeError, match="IO config must be a dict"):
            t.set_io({"lrs": "sr"})

    def test_datatransform_inputs_string_raises(self):
        """String inputs are no longer accepted."""
        t = _SingleInputTransform()
        with pytest.raises(TypeError, match="'inputs' must be a dict or list of dicts"):
            t.set_io({"inputs": "lrs", "outputs": "sr"})

    def test_datatransform_inputs_none_raises(self):
        t = _SingleInputTransform()
        with pytest.raises(TypeError, match="'inputs' must be a dict or list of dicts"):
            t.set_io({"inputs": None, "outputs": ["x"]})

    def test_datatransform_inputs_list_of_strings_raises(self):
        """List of strings (not dicts) in inputs is no longer accepted."""
        t = _SingleInputTransform()
        with pytest.raises(TypeError, match="inputs\\[0\\].*must be a dict"):
            t.set_io({"inputs": ["lrs", "hr"], "outputs": ["sr", "hr"]})

    def test_datatransform_inputs_list_of_tuples_raises(self):
        """Tuple inputs are no longer accepted."""
        t = _MultiInputTransform()
        with pytest.raises(TypeError, match="inputs\\[0\\].*must be a dict"):
            t.set_io({"inputs": [("lrs", "hr")], "outputs": ["out"]})

    def test_datatransform_inputs_outputs_length_mismatch_raises(self):
        t = _MultiInputTransform()
        with pytest.raises(ValueError, match="lengths must match"):
            t.set_io({
                "inputs": [{"image": "lrs", "reference": "hr"}, {"image": "rgb", "reference": "hr"}],
                "outputs": ["out"],
            })

    def test_datatransform_multi_app_outputs_wrong_type_raises(self):
        """Multiple applications with dict outputs is not accepted."""
        t = _SingleInputTransform()
        with pytest.raises(TypeError, match="'outputs' must be a list"):
            t.set_io({
                "inputs": [{"image": "lrs"}, {"image": "hr"}],
                "outputs": {"a": "b"},
            })

    # -- EntryTransform config errors ------------------------------------------

    def test_entrytransform_none_raises(self):
        t = _TestEntryTransform()
        with pytest.raises(TypeError, match="IO config must be a dict"):
            t.set_io(None)

    def test_entrytransform_string_raises(self):
        t = _TestEntryTransform()
        with pytest.raises(TypeError, match="IO config must be a dict"):
            t.set_io("field")

    def test_entrytransform_list_raises(self):
        t = _TestEntryTransform()
        with pytest.raises(TypeError, match="IO config must be a dict"):
            t.set_io(["field", "reference"])

    def test_entrytransform_flat_dict_raises(self):
        """Flat dict (without 'inputs' key) is no longer accepted."""
        t = _TestEntryTransform()
        with pytest.raises(TypeError, match="IO config must be a dict"):
            t.set_io({"field": "lrs", "reference": "hr"})

    def test_entrytransform_inputs_not_dict_raises(self):
        """EntryTransform requires inputs to be a dict (not list of dicts)."""
        t = _TestEntryTransform()
        with pytest.raises(TypeError, match="'inputs' must be a dict for port-based"):
            t.set_io({"inputs": [{"field": "lrs"}]})

    # -- Runtime errors --------------------------------------------------------

    def test_unbound_datatransform_entry_raises(self):
        """Calling DataTransform on Entry without set_io raises."""
        t = _SingleInputTransform()
        with pytest.raises(ValueError, match="requires io mappings"):
            t(Entry(name="test", image=_t(1)))

    def test_missing_entry_field_raises(self):
        t = _SingleInputTransform()
        t.set_io({"inputs": {"image": "missing_field"}})
        with pytest.raises(KeyError, match="not found in entry"):
            t(Entry(name="test", image=_t(1)))

    def test_missing_entry_field_structured_raises(self):
        t = _MultiInputTransform()
        t.set_io({"inputs": {"image": "lrs", "reference": "hr"}, "outputs": "out"})
        with pytest.raises(KeyError):
            t(Entry(name="test", lrs=_t(1)))  # hr missing
