"""Verify SR-Forge collation behavior alongside PyTorch Geometric.

SR-Forge uses stack-based collation (adds batch dim), while PyG concatenates
along dim 0. For tensors without a leading batch dim in Entry (natural shapes),
stack produces the same result as PyG's cat on tensors with a leading dim=1.
These tests document parity where it exists and known differences where it
does not.
"""

import pytest
import torch

pyg = pytest.importorskip("torch_geometric")
from torch_geometric.data import Data, Batch

from srforge.data import Entry


# --- Parity tests: exact match between SR-Forge and PyG ---
# SR-Forge stores tensors without batch dim (natural shapes).
# PyG stores tensors with a leading dim (e.g. [1,C,H,W]).
# After collation both produce [B,C,H,W].


class TestCollationPyGParity:
    def test_tensor_2d(self):
        # PyG: [1,2] cat → [2,2]; SF: [2] stack → [2,2]
        d1, d2 = Data(x=torch.tensor([[1.0, 2.0]])), Data(x=torch.tensor([[3.0, 4.0]]))
        e1, e2 = Entry(x=torch.tensor([1.0, 2.0])), Entry(x=torch.tensor([3.0, 4.0]))

        pyg_batch = Batch.from_data_list([d1, d2])
        sf_batch = Entry.collate([e1, e2])

        assert torch.equal(pyg_batch.x, sf_batch.x)

    def test_tensor_4d_image(self):
        # PyG: [1,3,8,8] cat → [2,3,8,8]; SF: [3,8,8] stack → [2,3,8,8]
        t1_pyg, t2_pyg = torch.randn(1, 3, 8, 8), torch.randn(1, 3, 8, 8)
        t1_sf, t2_sf = t1_pyg.squeeze(0), t2_pyg.squeeze(0)

        pyg_batch = Batch.from_data_list([Data(img=t1_pyg), Data(img=t2_pyg)])
        sf_batch = Entry.collate([Entry(img=t1_sf), Entry(img=t2_sf)])

        assert torch.equal(pyg_batch.img, sf_batch.img)
        assert sf_batch.img.shape == (2, 3, 8, 8)

    def test_tensor_5d(self):
        # PyG: [1,1,3,4,4] cat → [2,1,3,4,4]; SF: [1,3,4,4] stack → [2,1,3,4,4]
        t1_pyg, t2_pyg = torch.randn(1, 1, 3, 4, 4), torch.randn(1, 1, 3, 4, 4)
        t1_sf, t2_sf = t1_pyg.squeeze(0), t2_pyg.squeeze(0)

        pyg_batch = Batch.from_data_list([Data(x=t1_pyg), Data(x=t2_pyg)])
        sf_batch = Entry.collate([Entry(x=t1_sf), Entry(x=t2_sf)])

        assert torch.equal(pyg_batch.x, sf_batch.x)
        assert sf_batch.x.shape == (2, 1, 3, 4, 4)

    def test_multiple_tensor_fields(self):
        img1_pyg, tgt1_pyg = torch.randn(1, 3, 4, 4), torch.randn(1, 3, 8, 8)
        img2_pyg, tgt2_pyg = torch.randn(1, 3, 4, 4), torch.randn(1, 3, 8, 8)

        pyg_batch = Batch.from_data_list([
            Data(img=img1_pyg, target=tgt1_pyg),
            Data(img=img2_pyg, target=tgt2_pyg),
        ])
        sf_batch = Entry.collate([
            Entry(img=img1_pyg.squeeze(0), target=tgt1_pyg.squeeze(0)),
            Entry(img=img2_pyg.squeeze(0), target=tgt2_pyg.squeeze(0)),
        ])

        assert torch.equal(pyg_batch.img, sf_batch.img)
        assert torch.equal(pyg_batch.target, sf_batch.target)
        assert sf_batch.img.shape == (2, 3, 4, 4)
        assert sf_batch.target.shape == (2, 3, 8, 8)

    def test_dict_of_tensors(self):
        # PyG cat on inner tensors; SF stack on inner tensors
        bands1_pyg = {"rgb": torch.ones(1, 3, 4, 4), "nir": torch.ones(1, 2, 4, 4) * 2}
        bands2_pyg = {"rgb": torch.ones(1, 3, 4, 4) * 3, "nir": torch.ones(1, 2, 4, 4) * 4}
        bands1_sf = {k: v.squeeze(0) for k, v in bands1_pyg.items()}
        bands2_sf = {k: v.squeeze(0) for k, v in bands2_pyg.items()}

        pyg_batch = Batch.from_data_list([Data(bands=bands1_pyg), Data(bands=bands2_pyg)])
        sf_batch = Entry.collate([Entry(bands=bands1_sf), Entry(bands=bands2_sf)])

        assert torch.equal(pyg_batch.bands["rgb"], sf_batch.bands["rgb"])
        assert torch.equal(pyg_batch.bands["nir"], sf_batch.bands["nir"])
        assert sf_batch.bands["rgb"].shape == (2, 3, 4, 4)
        assert sf_batch.bands["nir"].shape == (2, 2, 4, 4)

    def test_dict_with_different_value_shapes(self):
        """Dict where each key has tensors of different spatial size."""
        bands1_pyg = {"10m": torch.randn(1, 4, 8, 8), "20m": torch.randn(1, 6, 4, 4)}
        bands2_pyg = {"10m": torch.randn(1, 4, 8, 8), "20m": torch.randn(1, 6, 4, 4)}
        bands1_sf = {k: v.squeeze(0) for k, v in bands1_pyg.items()}
        bands2_sf = {k: v.squeeze(0) for k, v in bands2_pyg.items()}

        pyg_batch = Batch.from_data_list([Data(bands=bands1_pyg), Data(bands=bands2_pyg)])
        sf_batch = Entry.collate([Entry(bands=bands1_sf), Entry(bands=bands2_sf)])

        assert torch.equal(pyg_batch.bands["10m"], sf_batch.bands["10m"])
        assert torch.equal(pyg_batch.bands["20m"], sf_batch.bands["20m"])
        assert sf_batch.bands["10m"].shape == (2, 4, 8, 8)
        assert sf_batch.bands["20m"].shape == (2, 6, 4, 4)

    def test_large_batch(self):
        n = 16
        tensors_pyg = [torch.randn(1, 3, 4, 4) for _ in range(n)]
        tensors_sf = [t.squeeze(0) for t in tensors_pyg]

        pyg_batch = Batch.from_data_list([Data(x=t) for t in tensors_pyg])
        sf_batch = Entry.collate([Entry(x=t) for t in tensors_sf])

        assert torch.equal(pyg_batch.x, sf_batch.x)
        assert sf_batch.x.shape == (n, 3, 4, 4)

    def test_batch_of_one(self):
        t_pyg = torch.randn(1, 3, 4, 4)
        t_sf = t_pyg.squeeze(0)

        pyg_batch = Batch.from_data_list([Data(x=t_pyg)])
        sf_batch = Entry.collate([Entry(x=t_sf)])

        assert torch.equal(pyg_batch.x, sf_batch.x)
        assert sf_batch.x.shape == (1, 3, 4, 4)

    def test_bare_string(self):
        """Both collect bare strings into a list."""
        pyg_batch = Batch.from_data_list([Data(tag="hello"), Data(tag="world")])
        sf_batch = Entry.collate([Entry(tag="hello"), Entry(tag="world")])

        assert pyg_batch.tag == sf_batch.tag == ["hello", "world"]

    def test_bare_int(self):
        """Both create a tensor from bare ints."""
        pyg_batch = Batch.from_data_list([Data(scale=2), Data(scale=4)])
        sf_batch = Entry.collate([Entry(scale=2), Entry(scale=4)])

        assert torch.equal(pyg_batch.scale, sf_batch.scale)
        assert torch.equal(sf_batch.scale, torch.tensor([2, 4]))

    def test_bare_float(self):
        """Both create a tensor from bare floats."""
        pyg_batch = Batch.from_data_list([Data(weight=1.5), Data(weight=2.5)])
        sf_batch = Entry.collate([Entry(weight=1.5), Entry(weight=2.5)])

        assert torch.equal(pyg_batch.weight, sf_batch.weight)

    def test_bare_bool(self):
        """Both create a bool tensor from bare bools."""
        pyg_batch = Batch.from_data_list([Data(flag=True), Data(flag=False)])
        sf_batch = Entry.collate([Entry(flag=True), Entry(flag=False)])

        assert torch.equal(pyg_batch.flag, sf_batch.flag)
        assert sf_batch.flag.dtype == torch.bool


# --- Known differences ---


class TestCollationKnownDifferences:
    def test_none_field(self):
        """PyG does not store None attributes; SR-Forge collapses to None."""
        sf_batch = Entry.collate([Entry(mask=None), Entry(mask=None)])
        assert sf_batch.mask is None

        # PyG doesn't store None at all
        pyg_batch = Batch.from_data_list([Data(), Data()])
        with pytest.raises(AttributeError):
            _ = pyg_batch.mask

    def test_different_shape_tensors(self):
        """PyG raises RuntimeError; SR-Forge falls back to a list."""
        t1, t2 = torch.randn(3, 4, 4), torch.randn(3, 8, 8)

        sf_batch = Entry.collate([Entry(x=t1), Entry(x=t2)])
        assert isinstance(sf_batch.x, list)
        assert len(sf_batch.x) == 2
        assert torch.equal(sf_batch.x[0], t1)
        assert torch.equal(sf_batch.x[1], t2)

        with pytest.raises(RuntimeError):
            Batch.from_data_list([Data(x=t1.unsqueeze(0)), Data(x=t2.unsqueeze(0))])

    def test_1d_tensor_sf_stacks_pyg_cats(self):
        """PyG concatenates 1D tensors; SR-Forge stacks them."""
        t1, t2 = torch.tensor([1.0, 2.0, 3.0]), torch.tensor([4.0, 5.0, 6.0])

        pyg_batch = Batch.from_data_list([Data(x=t1), Data(x=t2)])
        sf_batch = Entry.collate([Entry(x=t1), Entry(x=t2)])

        # PyG: cat → [6,]; SR-Forge: stack → [2,3]
        assert pyg_batch.x.shape == (6,)
        assert sf_batch.x.shape == (2, 3)

    def test_list_of_tensors_sf_collects_pyg_elementwise(self):
        """PyG collates lists element-wise; SR-Forge collects them."""
        lrs1 = [torch.tensor([[1.0, 2.0]]), torch.tensor([[3.0, 4.0]])]
        lrs2 = [torch.tensor([[5.0, 6.0]]), torch.tensor([[7.0, 8.0]])]

        pyg_batch = Batch.from_data_list([Data(lrs=lrs1), Data(lrs=lrs2)])
        sf_batch = Entry.collate([Entry(lrs=lrs1), Entry(lrs=lrs2)])

        # PyG: element-wise (2 elements, each catted)
        assert len(pyg_batch.lrs) == 2
        assert pyg_batch.lrs[0].shape == (2, 2)

        # SR-Forge: collected (2 elements, each is the original list)
        assert len(sf_batch.lrs) == 2
        assert len(sf_batch.lrs[0]) == 2  # first sample's list
        assert len(sf_batch.lrs[1]) == 2  # second sample's list
