import pytest
import torch

from srforge.data.entry import Entry, GraphEntry, _merge_fields
from srforge.data import _HAS_PYG

needs_pyg = pytest.mark.skipif(not _HAS_PYG, reason="torch-geometric not installed")


def test_merge_fields_entry_adds_fields_and_returns_same():
    entry = Entry(name="scene", x=torch.tensor([1.0]))
    out = entry.merge_fields({"y": torch.tensor([2.0])})

    assert out is entry
    assert "y" in entry
    assert "x" in entry
    assert torch.allclose(entry.x, torch.tensor([1.0]))
    assert torch.allclose(entry.y, torch.tensor([2.0]))
    assert set(entry.keys()) == {"name", "x", "y"}


def test_merge_fields_entry_rejects_overlap_with_source_and_name():
    entry = Entry(name="scene", x=torch.tensor([1.0]))

    with pytest.raises(KeyError) as exc:
        entry.merge_fields({"x": torch.tensor([2.0])}, source="model")

    msg = str(exc.value)
    assert "model" in msg
    assert "scene" in msg
    assert "x" in msg
    assert torch.allclose(entry.x, torch.tensor([1.0]))


def test_merge_fields_entry_allow_overwrite():
    entry = Entry(x=torch.tensor([1.0]))
    entry.merge_fields({"x": torch.tensor([3.0])}, allow_overwrite=True)

    assert torch.allclose(entry.x, torch.tensor([3.0]))
    assert set(entry.keys()) == {"name", "x"}


def test_merge_fields_none_returns_entry():
    entry = Entry(x=torch.tensor([1.0]))
    out = entry.merge_fields(None)

    assert out is entry
    assert set(entry.keys()) == {"name", "x"}


def test_merge_fields_non_mapping_raises_type_error():
    entry = Entry(x=torch.tensor([1.0]))

    with pytest.raises(TypeError) as exc:
        _merge_fields(entry, [("y", torch.tensor([2.0]))])
    assert "mapping" in str(exc.value)


def test_merge_fields_dict_and_object_targets():
    data = {"x": 1}
    out = _merge_fields(data, {"y": 2})

    assert out is data
    assert data["x"] == 1
    assert data["y"] == 2

    class Obj:
        pass

    obj = Obj()
    _merge_fields(obj, {"y": 3})

    assert not hasattr(obj, "x")
    assert obj.y == 3


@needs_pyg
def test_merge_fields_graph_entry():
    entry = GraphEntry(name="graph", x=torch.tensor([1.0]))
    out = entry.merge_fields({"y": torch.tensor([2.0])})

    assert out is entry
    assert "x" in entry and "y" in entry
    assert torch.allclose(entry.x, torch.tensor([1.0]))
    assert torch.allclose(entry.y, torch.tensor([2.0]))
