import numpy as np
import pytest
import torch

from srforge.data import Entry, _HAS_PYG
from srforge.data.entry import GraphEntry

needs_pyg = pytest.mark.skipif(not _HAS_PYG, reason="torch-geometric not installed")


def _tensor(value: float, shape=(2, 3)):
    return torch.full(shape, float(value), dtype=torch.float32)


class TestEntryTo:
    def test_returns_new_instance(self):
        entry = Entry(x=_tensor(1.0))
        result = entry.to("cpu")
        assert result is not entry

    def test_original_unchanged(self):
        original_tensor = _tensor(1.0)
        entry = Entry(x=original_tensor)
        entry.to("cpu")
        assert entry.x is original_tensor

    def test_preserves_name(self):
        entry = Entry(name="test", x=_tensor(1.0))
        result = entry.to("cpu")
        assert result.name == "test"

    def test_preserves_non_tensor_fields(self):
        entry = Entry(x=_tensor(1.0), label="hello", count=42)
        result = entry.to("cpu")
        assert result.label == "hello"
        assert result.count == 42

    def test_nested_dict(self):
        entry = Entry(nested={"a": _tensor(1.0), "b": _tensor(2.0)})
        result = entry.to("cpu")
        assert isinstance(result.nested["a"], torch.Tensor)
        assert isinstance(result.nested["b"], torch.Tensor)

    def test_nested_list(self):
        entry = Entry(tensors=[_tensor(1.0), _tensor(2.0)])
        result = entry.to("cpu")
        assert isinstance(result.tensors[0], torch.Tensor)
        assert isinstance(result.tensors[1], torch.Tensor)

    def test_all_fields_copied(self):
        entry = Entry(a=_tensor(1.0), b=_tensor(2.0), c="meta")
        result = entry.to("cpu")
        assert set(result.keys()) == {"a", "b", "c", "name"}


class TestEntryNameGuard:
    def test_del_item_raises_key_error(self):
        entry = Entry(name="test", x=_tensor(1.0))
        with pytest.raises(KeyError, match="Cannot delete 'name'"):
            del entry["name"]

    def test_del_attr_raises_attribute_error(self):
        entry = Entry(name="test", x=_tensor(1.0))
        with pytest.raises(AttributeError):
            del entry.name

    def test_name_preserved_after_failed_deletion(self):
        entry = Entry(name="test", x=_tensor(1.0))
        with pytest.raises(KeyError):
            del entry["name"]
        assert entry.name == "test"

    def test_other_fields_still_deletable(self):
        entry = Entry(name="test", x=_tensor(1.0), extra="data")
        del entry["extra"]
        assert "extra" not in entry
        assert entry.name == "test"


class TestEntryNumpy:
    def test_returns_new_instance(self):
        entry = Entry(x=_tensor(1.0))
        result = entry.numpy()
        assert result is not entry

    def test_original_unchanged(self):
        entry = Entry(x=_tensor(1.0))
        entry.numpy()
        assert isinstance(entry.x, torch.Tensor)

    def test_converts_tensors(self):
        entry = Entry(x=_tensor(1.0), y=_tensor(2.0))
        result = entry.numpy()
        assert isinstance(result.x, np.ndarray)
        assert isinstance(result.y, np.ndarray)

    def test_values_preserved(self):
        entry = Entry(x=_tensor(3.0, shape=(2,)))
        result = entry.numpy()
        np.testing.assert_array_equal(result.x, [3.0, 3.0])

    def test_preserves_name(self):
        entry = Entry(name="test", x=_tensor(1.0))
        result = entry.numpy()
        assert result.name == "test"

    def test_preserves_non_tensor_fields(self):
        entry = Entry(x=_tensor(1.0), label="hello", count=42)
        result = entry.numpy()
        assert result.label == "hello"
        assert result.count == 42

    def test_nested_dict(self):
        entry = Entry(nested={"a": _tensor(1.0), "b": "keep"})
        result = entry.numpy()
        assert isinstance(result.nested["a"], np.ndarray)
        assert result.nested["b"] == "keep"

    def test_nested_list(self):
        entry = Entry(tensors=[_tensor(1.0), _tensor(2.0)])
        result = entry.numpy()
        assert isinstance(result.tensors[0], np.ndarray)
        assert isinstance(result.tensors[1], np.ndarray)

    def test_detaches_grad_tensors(self):
        t = torch.randn(3, requires_grad=True)
        entry = Entry(x=t)
        result = entry.numpy()
        assert isinstance(result.x, np.ndarray)


@needs_pyg
class TestGraphEntryNumpy:
    def test_returns_new_instance(self):
        ge = GraphEntry(x=_tensor(1.0), edge_index=torch.tensor([[0, 1], [1, 0]]))
        result = ge.numpy()
        assert result is not ge

    def test_original_unchanged(self):
        ge = GraphEntry(x=_tensor(1.0), edge_index=torch.tensor([[0, 1], [1, 0]]))
        ge.numpy()
        assert isinstance(ge.x, torch.Tensor)

    def test_converts_tensors(self):
        ge = GraphEntry(x=_tensor(1.0), edge_index=torch.tensor([[0, 1], [1, 0]]))
        result = ge.numpy()
        assert isinstance(result.x, np.ndarray)
        assert isinstance(result.edge_index, np.ndarray)

    def test_preserves_name(self):
        ge = GraphEntry(name="graph1", x=_tensor(1.0))
        result = ge.numpy()
        assert result.name == "graph1"
