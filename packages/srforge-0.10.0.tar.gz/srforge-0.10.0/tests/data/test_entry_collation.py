import torch

from srforge.data import Entry


def _tensor(value: float, shape=(1, 2, 2)):
    """Create a tensor with the given shape (no batch dim by default)."""
    return torch.full(shape, float(value), dtype=torch.float32)


class TestEntryCollation:
    def test_collate_tensors_batch_dim(self):
        """Stack adds a batch dim: [C,H,W] + [C,H,W] -> [2,C,H,W]."""
        e1 = Entry(x=_tensor(1.0))
        e2 = Entry(x=_tensor(2.0))
        batch = Entry.collate([e1, e2])
        assert batch.x.shape == (2, 1, 2, 2)
        assert torch.allclose(batch.x[0], e1.x)
        assert torch.allclose(batch.x[1], e2.x)

    def test_collate_dict_of_tensors(self):
        e1 = Entry(lrs={"b1": _tensor(1.0), "b2": _tensor(2.0)})
        e2 = Entry(lrs={"b1": _tensor(3.0), "b2": _tensor(4.0)})
        batch = Entry.collate([e1, e2])
        assert batch.lrs["b1"].shape == (2, 1, 2, 2)
        assert batch.lrs["b2"].shape == (2, 1, 2, 2)
        assert torch.allclose(batch.lrs["b1"][0], e1.lrs["b1"])
        assert torch.allclose(batch.lrs["b1"][1], e2.lrs["b1"])

    def test_collate_list_collects(self):
        """Lists are collected: [t1,t2] + [t3,t4] -> [[t1,t2], [t3,t4]]."""
        e1 = Entry(lrs=[_tensor(1.0), _tensor(2.0)])
        e2 = Entry(lrs=[_tensor(3.0), _tensor(4.0)])
        batch = Entry.collate([e1, e2])
        assert isinstance(batch.lrs, list)
        assert len(batch.lrs) == 2  # collected, not concatenated
        assert len(batch.lrs[0]) == 2
        assert len(batch.lrs[1]) == 2
        assert torch.allclose(batch.lrs[0][0], _tensor(1.0))
        assert torch.allclose(batch.lrs[1][0], _tensor(3.0))

    def test_collate_tuple_collects(self):
        """Tuples are collected, same as lists."""
        e1 = Entry(lrs=(_tensor(1.0), _tensor(2.0)))
        e2 = Entry(lrs=(_tensor(3.0), _tensor(4.0)))
        batch = Entry.collate([e1, e2])
        assert isinstance(batch.lrs, list)
        assert len(batch.lrs) == 2  # collected

    def test_collate_list_of_lists(self):
        """List of lists collects: [["b1","b2"]] + [["b3","b4"]] -> [[["b1","b2"]], [["b3","b4"]]]."""
        e1 = Entry(lrs=[["b1", "b2"]])
        e2 = Entry(lrs=[["b3", "b4"]])
        batch = Entry.collate([e1, e2])
        assert isinstance(batch.lrs, list)
        assert len(batch.lrs) == 2
        assert batch.lrs[0] == [["b1", "b2"]]
        assert batch.lrs[1] == [["b3", "b4"]]

    def test_collate_name_bare_string(self):
        """Bare strings collected: "s1" + "s2" -> ["s1", "s2"]."""
        e1 = Entry(name="scene1")
        e2 = Entry(name="scene2")
        batch = Entry.collate([e1, e2])
        assert batch.name == ["scene1", "scene2"]

    def test_collate_bands_as_list(self):
        """Band lists: ["b1","b2"] + ["b1","b2"] -> [["b1","b2"], ["b1","b2"]]."""
        e1 = Entry(bands=["b1", "b2"])
        e2 = Entry(bands=["b1", "b2"])
        batch = Entry.collate([e1, e2])
        assert batch.bands == [["b1", "b2"], ["b1", "b2"]]

    def test_collate_dict_of_list_tensors(self):
        """Dicts recurse, then inner lists are collected."""
        e1 = Entry(lrs={"b1": [_tensor(1.0), _tensor(2.0)]})
        e2 = Entry(lrs={"b1": [_tensor(3.0), _tensor(4.0)]})
        batch = Entry.collate([e1, e2])
        assert isinstance(batch.lrs["b1"], list)
        assert len(batch.lrs["b1"]) == 2  # collected

    def test_collate_none_returns_none(self):
        e1 = Entry(mask=None)
        e2 = Entry(mask=None)
        batch = Entry.collate([e1, e2])
        assert batch.mask is None

    def test_collate_mixed_none_and_tensor(self):
        """None mixed with tensors returns a list of raw values."""
        t = _tensor(1.0)
        e1 = Entry(mask=None)
        e2 = Entry(mask=t)
        batch = Entry.collate([e1, e2])
        assert isinstance(batch.mask, list)
        assert len(batch.mask) == 2
        assert batch.mask[0] is None
        assert torch.equal(batch.mask[1], t)

    def test_collate_mixed_none_and_string(self):
        """None mixed with strings returns a list."""
        e1 = Entry(tag="hello")
        e2 = Entry(tag=None)
        batch = Entry.collate([e1, e2])
        assert isinstance(batch.tag, list)
        assert batch.tag == ["hello", None]

    def test_collate_bare_string(self):
        """Bare strings are collected into a list."""
        e1 = Entry(tag="hello")
        e2 = Entry(tag="world")
        batch = Entry.collate([e1, e2])
        assert batch.tag == ["hello", "world"]

    def test_collate_bare_int(self):
        """Bare ints become a tensor."""
        e1 = Entry(scale=2)
        e2 = Entry(scale=4)
        batch = Entry.collate([e1, e2])
        assert torch.equal(batch.scale, torch.tensor([2, 4]))

    def test_collate_bare_float(self):
        """Bare floats become a tensor."""
        e1 = Entry(weight=1.5)
        e2 = Entry(weight=2.5)
        batch = Entry.collate([e1, e2])
        assert torch.equal(batch.weight, torch.tensor([1.5, 2.5]))

    def test_collate_bare_bool(self):
        """Bare bools become a bool tensor."""
        e1 = Entry(flag=True)
        e2 = Entry(flag=False)
        batch = Entry.collate([e1, e2])
        assert torch.equal(batch.flag, torch.tensor([True, False]))
        assert batch.flag.dtype == torch.bool

    def test_collate_lists_different_lengths_collected(self):
        """Different-length lists are collected (not concatenated)."""
        e1 = Entry(lrs=[_tensor(1.0), _tensor(2.0)])
        e2 = Entry(lrs=[_tensor(3.0), _tensor(4.0), _tensor(5.0)])
        batch = Entry.collate([e1, e2])
        assert len(batch.lrs) == 2
        assert len(batch.lrs[0]) == 2
        assert len(batch.lrs[1]) == 3

    def test_collate_different_shape_tensors_fallback_list(self):
        t1, t2 = _tensor(1.0, (1, 2, 2)), _tensor(2.0, (1, 4, 4))
        e1 = Entry(x=t1)
        e2 = Entry(x=t2)
        batch = Entry.collate([e1, e2])
        assert isinstance(batch.x, list)
        assert len(batch.x) == 2
        assert torch.equal(batch.x[0], t1)
        assert torch.equal(batch.x[1], t2)

    def test_collate_sets_is_batched(self):
        """collate() sets _is_batched on the result."""
        e1 = Entry(name="s1", x=_tensor(1.0))
        e2 = Entry(name="s2", x=_tensor(2.0))
        assert not e1.is_batched
        batch = Entry.collate([e1, e2])
        assert batch.is_batched
        assert batch.batch_size == 2

    def test_collate_round_trip(self):
        """collate -> entry[i] recovers the original unbatched entry."""
        e1 = Entry(name="s1", x=_tensor(1.0), scale=4)
        e2 = Entry(name="s2", x=_tensor(2.0), scale=8)
        batch = Entry.collate([e1, e2])
        r1 = batch[0]
        r2 = batch[1]
        assert r1.name == "s1"
        assert r2.name == "s2"
        assert torch.equal(r1.x, e1.x)
        assert torch.equal(r2.x, e2.x)
        assert r1.scale == 4
        assert r2.scale == 8
        assert not r1.is_batched
        assert not r2.is_batched
