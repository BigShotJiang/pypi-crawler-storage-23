import torch
import pytest

from srforge.data import Entry


def _tensor(value: float, shape=(1, 2, 2)):
    """Create a tensor without batch dim (C,H,W)."""
    return torch.full(shape, float(value), dtype=torch.float32)


def _batched_tensor(value: float, batch=2, shape=(3, 4, 4)):
    """Create a batched tensor (B,C,H,W)."""
    return torch.full((batch, *shape), float(value), dtype=torch.float32)


class TestBatchSize:
    def test_from_tensor(self):
        entry = Entry(name=["s1", "s2"], image=torch.randn(2, 3, 4, 4))
        assert entry.batch_size == 2

    def test_from_list(self):
        entry = Entry(name=["s1", "s2", "s3"])
        assert entry.batch_size == 3

    def test_from_nested_dict(self):
        entry = Entry(
            name=["s1"],
            bands={"rgb": torch.randn(1, 3, 4, 4), "nir": torch.randn(1, 1, 4, 4)},
        )
        assert entry.batch_size == 1

    def test_empty_raises(self):
        entry = Entry(name=None)
        with pytest.raises(ValueError, match="Cannot infer batch size"):
            _ = entry.batch_size

    def test_single_sample(self):
        entry = Entry(name=["s1"], image=torch.randn(1, 3, 4, 4))
        assert entry.batch_size == 1


class TestIsBatched:
    def test_manual_entry_not_batched(self):
        entry = Entry(name="s1", image=torch.randn(3, 4, 4))
        assert not entry.is_batched

    def test_collated_entry_is_batched(self):
        e1 = Entry(name="s1", image=torch.randn(3, 4, 4))
        e2 = Entry(name="s2", image=torch.randn(3, 4, 4))
        batch = Entry.collate([e1, e2])
        assert batch.is_batched

    def test_integer_index_clears_batched(self):
        e1 = Entry(name="s1", image=torch.randn(3, 4, 4))
        e2 = Entry(name="s2", image=torch.randn(3, 4, 4))
        batch = Entry.collate([e1, e2])
        sample = batch[0]
        assert not sample.is_batched

    def test_slice_preserves_batched(self):
        e1 = Entry(name="s1", image=torch.randn(3, 4, 4))
        e2 = Entry(name="s2", image=torch.randn(3, 4, 4))
        batch = Entry.collate([e1, e2])
        sub = batch[0:1]
        assert sub.is_batched


class TestIntegerIndexing:
    def test_tensor_removes_batch_dim(self):
        """Integer indexing removes batch dim: [B,C,H,W] → [C,H,W]."""
        entry = Entry(name=["s1", "s2"], image=torch.randn(2, 3, 4, 4))
        sample = entry[0]
        assert sample.image.shape == (3, 4, 4)

    def test_string_list_returns_element(self):
        """list[i] returns element: ["s1","s2"] → "s1"."""
        entry = Entry(name=["s1", "s2"])
        sample = entry[0]
        assert sample.name == "s1"

    def test_nested_list_returns_element(self):
        """Nested list returns element: [["b2","b8"], ["b2","b8"]] → ["b2","b8"]."""
        entry = Entry(name=["s1", "s2"], bands=[["b2", "b8"], ["b2", "b8"]])
        sample = entry[0]
        assert sample.bands == ["b2", "b8"]

    def test_none_list_returns_element(self):
        """List of None returns element: [None, None] → None."""
        entry = Entry(name=["s1", "s2"], mask=[None, None])
        sample = entry[0]
        assert sample.mask is None

    def test_dict_field_recursed(self):
        entry = Entry(
            name=["s1", "s2"],
            lrs={"b1": torch.randn(2, 1, 4, 4), "b2": torch.randn(2, 1, 4, 4)},
        )
        sample = entry[0]
        assert sample.lrs["b1"].shape == (1, 4, 4)
        assert sample.lrs["b2"].shape == (1, 4, 4)

    def test_negative_index(self):
        entry = Entry(name=["s1", "s2", "s3"], image=torch.randn(3, 3, 4, 4))
        sample = entry[-1]
        assert sample.name == "s3"
        assert sample.image.shape == (3, 4, 4)

    def test_out_of_range_raises(self):
        entry = Entry(name=["s1", "s2"])
        with pytest.raises(IndexError, match="out of range"):
            _ = entry[5]

    def test_negative_out_of_range_raises(self):
        entry = Entry(name=["s1", "s2"])
        with pytest.raises(IndexError, match="out of range"):
            _ = entry[-3]

    def test_returns_entry_type(self):
        entry = Entry(name=["s1", "s2"])
        sample = entry[0]
        assert isinstance(sample, Entry)

    def test_string_field_access_still_works(self):
        """String keys still access fields normally."""
        entry = Entry(name=["s1"], image=torch.randn(1, 3, 4, 4))
        assert entry["name"] == ["s1"]
        assert entry["image"].shape == (1, 3, 4, 4)

    def test_1d_tensor_integer_index(self):
        """1D tensor[i] returns a scalar tensor (shape ())."""
        entry = Entry(name=["s1", "s2"], scale=torch.tensor([4, 8]))
        sample = entry[0]
        assert sample.scale.shape == ()
        assert sample.scale.item() == 4

    def test_none_field_unchanged(self):
        """Bare None (not in a list) stays None after indexing."""
        entry = Entry(name=["s1", "s2"], mask=None)
        sample = entry[0]
        assert sample.mask is None


class TestSliceIndexing:
    def test_tensor_sub_batch(self):
        entry = Entry(name=["s1", "s2", "s3"], image=torch.randn(3, 3, 4, 4))
        sub = entry[0:2]
        assert sub.image.shape == (2, 3, 4, 4)

    def test_list_sub_batch(self):
        entry = Entry(name=["s1", "s2", "s3"])
        sub = entry[1:3]
        assert sub.name == ["s2", "s3"]

    def test_preserves_batch_dim(self):
        entry = Entry(name=["s1", "s2", "s3"], image=torch.randn(3, 3, 4, 4))
        sub = entry[0:1]
        assert sub.image.shape == (1, 3, 4, 4)
        assert sub.name == ["s1"]

    def test_dict_field(self):
        entry = Entry(
            name=["s1", "s2", "s3"],
            lrs={"b1": torch.randn(3, 1, 4, 4)},
        )
        sub = entry[0:2]
        assert sub.lrs["b1"].shape == (2, 1, 4, 4)

    def test_step_slice(self):
        entry = Entry(name=["s1", "s2", "s3", "s4"])
        sub = entry[::2]
        assert sub.name == ["s1", "s3"]

    def test_returns_entry_type(self):
        entry = Entry(name=["s1", "s2"])
        sub = entry[0:1]
        assert isinstance(sub, Entry)


class TestUnbatch:
    def test_length_matches_batch_size(self):
        entry = Entry(name=["s1", "s2", "s3"], image=torch.randn(3, 3, 4, 4))
        samples = entry.unbatch()
        assert len(samples) == 3

    def test_values_match_indexing(self):
        entry = Entry(name=["s1", "s2"], image=torch.randn(2, 3, 4, 4))
        samples = entry.unbatch()
        for i, sample in enumerate(samples):
            assert sample.name == entry[i].name
            assert torch.equal(sample.image, entry[i].image)

    def test_single_sample(self):
        """Single-sample unbatch returns one entry without batch dim."""
        entry = Entry(name=["s1"], image=torch.randn(1, 3, 4, 4))
        samples = entry.unbatch()
        assert len(samples) == 1
        assert samples[0].name == "s1"
        assert samples[0].image.shape == (3, 4, 4)


class TestRoundTrip:
    def test_collate_index_round_trip(self):
        """collate([e1, e2])[i] recovers the original unbatched entry."""
        e1 = Entry(name="s1", image=_tensor(1.0), scale=4)
        e2 = Entry(name="s2", image=_tensor(2.0), scale=8)

        batch = Entry.collate([e1, e2])
        r1 = batch[0]
        r2 = batch[1]

        assert r1.name == "s1"
        assert torch.equal(r1.image, e1.image)
        assert r1.scale == 4
        assert r2.name == "s2"
        assert torch.equal(r2.image, e2.image)
        assert r2.scale == 8

    def test_collate_unbatch_recollate(self):
        """collate(unbatch(collate(entries))) == collate(entries)."""
        e1 = Entry(name="s1", image=_tensor(1.0))
        e2 = Entry(name="s2", image=_tensor(2.0))

        batch = Entry.collate([e1, e2])
        samples = batch.unbatch()
        rebatch = Entry.collate(samples)

        assert rebatch.name == batch.name
        assert torch.equal(rebatch.image, batch.image)

    def test_round_trip_with_dict_fields(self):
        """Round-trip with dict fields."""
        e1 = Entry(name="s1", meta={"a": 1, "b": "x"})
        e1.image = torch.randn(3, 4, 4)

        e2 = Entry(name="s2", meta={"a": 2, "b": "y"})
        e2.image = torch.randn(3, 4, 4)

        batch = Entry.collate([e1, e2])
        r1 = batch[0]

        assert r1.name == "s1"
        assert r1.meta["a"] == 1  # scalar tensor compares equal to int
        assert r1.meta["b"] == "x"
        assert torch.equal(r1.image, e1.image)

    def test_round_trip_with_mixed_none(self):
        """Collation of mixed None values round-trips via unbatch."""
        e1 = Entry(name="s1", mask=None)
        e2 = Entry(name="s2", mask=_tensor(1.0))

        batch = Entry.collate([e1, e2])
        assert isinstance(batch.mask, list)

        s1 = batch[0]
        s2 = batch[1]
        assert s1.mask is None
        assert torch.equal(s2.mask, _tensor(1.0))

    def test_round_trip_with_bands(self):
        """Band lists round-trip correctly."""
        e1 = Entry(name="s1", bands=["b2", "b8"])
        e2 = Entry(name="s2", bands=["b2", "b8"])

        batch = Entry.collate([e1, e2])
        assert batch.bands == [["b2", "b8"], ["b2", "b8"]]

        r1 = batch[0]
        assert r1.bands == ["b2", "b8"]
        assert r1.name == "s1"

    def test_round_trip_preserves_none(self):
        """None values round-trip correctly."""
        e1 = Entry(name="s1", mask=None)
        e2 = Entry(name="s2", mask=None)

        batch = Entry.collate([e1, e2])
        assert batch.mask is None

        r1 = batch[0]
        assert r1.mask is None


class TestLen:
    def test_unbatched_raises_type_error(self):
        entry = Entry(name="s1", image=torch.randn(3, 4, 4))
        with pytest.raises(TypeError, match="unbatched Entry"):
            len(entry)

    def test_batched_returns_batch_size(self):
        e1 = Entry(name="s1", image=torch.randn(3, 4, 4))
        e2 = Entry(name="s2", image=torch.randn(3, 4, 4))
        batch = Entry.collate([e1, e2])
        assert len(batch) == 2

    def test_single_collated_returns_one(self):
        e1 = Entry(name="s1", image=torch.randn(3, 4, 4))
        batch = Entry.collate([e1])
        assert len(batch) == 1

    def test_after_integer_index_raises(self):
        e1 = Entry(name="s1", image=torch.randn(3, 4, 4))
        e2 = Entry(name="s2", image=torch.randn(3, 4, 4))
        batch = Entry.collate([e1, e2])
        sample = batch[0]
        with pytest.raises(TypeError, match="unbatched Entry"):
            len(sample)

    def test_after_slice_preserves_size(self):
        e1 = Entry(name="s1", image=torch.randn(3, 4, 4))
        e2 = Entry(name="s2", image=torch.randn(3, 4, 4))
        e3 = Entry(name="s3", image=torch.randn(3, 4, 4))
        batch = Entry.collate([e1, e2, e3])
        sub = batch[0:2]
        assert len(sub) == 2
