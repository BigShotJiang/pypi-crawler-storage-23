"""Tests for IOModule.set_io structured format validation."""

import pytest

from srforge.utils import IOSpec, IOModule


class _DummyModule(IOModule):
    io_spec = IOSpec(
        required_inputs=("image",),
        required_outputs=("output",),
    )


class _InPlaceModule(IOModule):
    io_spec = IOSpec(
        required_inputs=("bands",),
        required_outputs=("bands",),
    )


class TestStructuredSetIoConflictDetection:

    def test_conflicting_port_raises(self):
        """Same port mapped to different fields in inputs vs outputs."""
        module = _DummyModule()
        with pytest.raises(ValueError, match="conflicting bindings"):
            module.set_io({
                "inputs": {"image": "image_rgb"},
                "outputs": {"image": "prediction"},
            })

    def test_in_place_same_value_allowed(self):
        """Same port mapped to same field in both sections is fine (in-place)."""
        module = _InPlaceModule()
        module.set_io({
            "inputs": {"bands": "spectral"},
            "outputs": {"bands": "spectral"},
        })
        assert module.bands == "spectral"

    def test_disjoint_ports_structured(self):
        """Different ports in inputs vs outputs — normal case."""
        module = _DummyModule()
        module.set_io({
            "inputs": {"image": "x"},
            "outputs": {"output": "y"},
        })
        assert module.image == "x"
        assert module.output == "y"

    def test_flat_dict_unaffected(self):
        """Flat dict format still works normally."""
        module = _DummyModule()
        module.set_io({"inputs": {"image": "x"}, "outputs": {"output": "y"}})
        assert module.image == "x"
        assert module.output == "y"
