import pytest

from srforge.data import Entry


class TestDynamicStorageBasics:
    def test_attribute_set_updates_mapping(self):
        entry = Entry()
        entry.x = 10

        assert entry["x"] == 10
        assert entry.x == 10
        assert "x" in entry
        assert "x" in entry.keys()
        assert "x" not in entry.__dict__

    def test_item_set_updates_attribute(self):
        entry = Entry()
        entry["y"] = 5

        assert entry.y == 5
        assert entry["y"] == 5
        assert "y" in entry
        assert "y" in entry.keys()
        assert "y" not in entry.__dict__

    def test_attribute_delete_removes_mapping(self):
        entry = Entry()
        entry.z = 3

        del entry.z

        assert "z" not in entry
        assert "z" not in entry.keys()
        with pytest.raises(AttributeError):
            _ = entry.z

    def test_item_delete_removes_attribute(self):
        entry = Entry()
        entry["w"] = 7

        del entry["w"]

        assert "w" not in entry
        assert "w" not in entry.keys()
        with pytest.raises(AttributeError):
            _ = entry.w

    def test_missing_attribute_raises_attribute_error(self):
        entry = Entry()
        with pytest.raises(AttributeError):
            _ = entry.missing


class TestDynamicStoragePrivateAttrs:
    def test_private_attr_stays_in_dict(self):
        entry = Entry()
        entry._private = 123

        assert "_private" not in entry
        assert "_private" not in entry.keys()
        assert entry._private == 123
        assert entry.__dict__["_private"] == 123

    def test_private_attr_delete(self):
        entry = Entry()
        entry._private = 123

        del entry._private

        assert "_private" not in entry.__dict__
        assert "_private" not in entry.keys()
        with pytest.raises(AttributeError):
            _ = entry._private

    def test_private_key_and_private_attr_are_distinct(self):
        entry = Entry()
        entry["_hidden"] = "dict"
        entry._hidden = "attr"

        assert "_hidden" in entry.keys()
        assert entry["_hidden"] == "dict"
        assert entry._hidden == "attr"


class TestDynamicStorageKeys:
    def test_keys_values_items_reflect_mapping(self):
        entry = Entry()
        entry.a = 1
        entry["b"] = 2

        assert set(entry.keys()) == {"a", "b", "name"}
        assert set(entry.values()) == {None, 1, 2}
        assert dict(entry.items()) == {"a": 1, "b": 2, "name": None}
        assert "a" in entry and "b" in entry
        assert entry.name is None


class TestDynamicStorageMethodNameConflict:
    def test_mapping_key_with_method_name(self):
        entry = Entry()
        entry["items"] = 42

        # Dict access returns the stored value.
        assert entry["items"] == 42
        assert "items" in entry

        # Attribute access returns the method from dict subclass, not the stored value.
        assert callable(entry.items)


class TestEntryNameField:
    def test_name_is_stored_in_mapping(self):
        entry = Entry(name="scene")

        assert entry.name == "scene"
        assert entry["name"] == "scene"
        assert "name" in entry
        assert "name" in entry.keys()
        assert "name" not in entry.__dict__
