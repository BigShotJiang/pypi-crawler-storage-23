import torch

from torch.utils.data import DataLoader, Dataset

from srforge.data import Entry
from srforge.loss import Loss
from srforge.training.runners import TrainingEpochRunner, ValidationEpochRunner, BenchmarkRunner


class _DummyDataset(Dataset):
    def __len__(self):
        return 1

    def __getitem__(self, idx):
        return Entry(x=torch.tensor([1.0]), t=torch.tensor([2.0]))


class _DictModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = torch.nn.Linear(1, 1, bias=False)
        torch.nn.init.constant_(self.linear.weight, 1.0)

    def forward(self, entry: Entry):
        x = entry["x"].view(-1, 1)
        y = self.linear(x).view(-1)
        return {"y": y}


class _AbsDiff(Loss):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_io({"inputs": {"pred": "y", "target": "t"}})

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return (pred - target).abs()


def _make_loader():
    return DataLoader(_DummyDataset(), batch_size=1, shuffle=False, collate_fn=lambda batch: batch[0])


def test_training_runner_merges_dict_output_before_postprocessor():
    model = _DictModel()
    loss = _AbsDiff()
    seen = {}

    def postproc(entry: Entry):
        assert "y" in entry
        seen["y"] = entry["y"].detach().clone()
        return entry

    runner = TrainingEpochRunner(
        optimizer=torch.optim.SGD(model.parameters(), lr=0.1),
        criterion=loss,
        device="cpu",
        postprocessor=[postproc],
    )

    scores = runner.run_epoch(model, _make_loader(), epoch=0)

    assert "_AbsDiff" in scores.metrics
    assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([1.0]))
    assert "y" in seen
    assert torch.allclose(seen["y"], torch.tensor([1.0]))


def test_validation_runner_merges_dict_output():
    model = _DictModel()
    loss = _AbsDiff()

    runner = ValidationEpochRunner(
        criterion=loss,
        device="cpu",
        postprocessor=[],
    )

    scores = runner.run_epoch(model, _make_loader(), epoch=0)

    assert "_AbsDiff" in scores.metrics
    assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([1.0]))


def test_benchmark_runner_merges_dict_output():
    model = _DictModel()
    loss = _AbsDiff()

    runner = BenchmarkRunner(
        criterion=loss,
        device="cpu",
        postprocessor=[],
    )

    scores = runner.run_epoch(model, _make_loader(), epoch=0)

    assert "_AbsDiff" in scores.metrics
    assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([1.0]))
