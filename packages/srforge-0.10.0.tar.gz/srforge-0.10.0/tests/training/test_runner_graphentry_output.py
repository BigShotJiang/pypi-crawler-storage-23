import pytest
import torch

pytest.importorskip("torch_geometric")
from torch.utils.data import DataLoader, Dataset

from srforge.data import GraphEntry
from srforge.loss import Loss
from srforge.training.runners import TrainingEpochRunner, ValidationEpochRunner, BenchmarkRunner


class _GraphDataset(Dataset):
    def __len__(self):
        return 1

    def __getitem__(self, idx):
        return GraphEntry(x=torch.tensor([1.0]), t=torch.tensor([2.0]))


class _GraphModel(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.tensor(1.0))

    def forward(self, entry: GraphEntry) -> GraphEntry:
        y = entry.x * self.weight
        return GraphEntry(x=entry.x, t=entry.t, y=y)


class _AbsDiff(Loss):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_io({"inputs": {"pred": "y", "target": "t"}})

    @property
    def best_min(self) -> bool:
        return True

    def calculate_score(self, pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return (pred - target).abs()


def _make_loader():
    return DataLoader(_GraphDataset(), batch_size=1, shuffle=False, collate_fn=lambda batch: batch[0])


class TestRunnerGraphEntryOutput:
    def test_training_runner_accepts_graph_entry_output(self):
        model = _GraphModel()
        loss = _AbsDiff()

        def postproc(entry: GraphEntry):
            assert isinstance(entry, GraphEntry)
            assert "y" in entry
            return entry

        runner = TrainingEpochRunner(
            optimizer=torch.optim.SGD(model.parameters(), lr=0.1),
            criterion=loss,
            device="cpu",
            postprocessor=[postproc],
        )

        scores = runner.run_epoch(model, _make_loader(), epoch=0)

        assert "_AbsDiff" in scores.metrics
        assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([1.0]))

    def test_validation_runner_accepts_graph_entry_output(self):
        model = _GraphModel()
        loss = _AbsDiff()

        runner = ValidationEpochRunner(
            criterion=loss,
            device="cpu",
            postprocessor=[],
        )

        scores = runner.run_epoch(model, _make_loader(), epoch=0)

        assert "_AbsDiff" in scores.metrics
        assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([1.0]))

    def test_benchmark_runner_accepts_graph_entry_output(self):
        model = _GraphModel()
        loss = _AbsDiff()

        runner = BenchmarkRunner(
            criterion=loss,
            device="cpu",
            postprocessor=[],
        )

        scores = runner.run_epoch(model, _make_loader(), epoch=0)

        assert "_AbsDiff" in scores.metrics
        assert torch.allclose(scores.as_raw_dict()["_AbsDiff"], torch.tensor([1.0]))
