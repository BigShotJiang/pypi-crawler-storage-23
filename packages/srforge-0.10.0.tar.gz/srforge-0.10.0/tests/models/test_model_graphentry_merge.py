import pytest
import torch

pytest.importorskip("torch_geometric")
from srforge.data import GraphEntry
from srforge.models import Model
from srforge.utils import IOSpec


class _GraphAddOne(Model):
    io_spec = IOSpec(required_outputs=("y",))
    def __init__(self):
        super().__init__()

    def _forward(self, data: GraphEntry):
        return data.x + 1


def test_model_merges_into_graph_entry():
    entry = GraphEntry(name="graph", x=torch.tensor([1.0]))
    model = _GraphAddOne()

    out = model(entry)

    assert out is entry
    assert torch.allclose(out.x, torch.tensor([1.0]))
    assert torch.allclose(out.y, torch.tensor([2.0]))


def test_model_raises_on_graph_entry_collision():
    entry = GraphEntry(name="graph", x=torch.tensor([1.0]), y=torch.tensor([0.0]))
    model = _GraphAddOne()

    with pytest.raises(KeyError) as exc:
        model(entry)
    assert "y" in str(exc.value)
