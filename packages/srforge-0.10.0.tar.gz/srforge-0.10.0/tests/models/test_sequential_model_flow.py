import warnings

import pytest
import torch

from srforge.data import Entry
from srforge.models import Model, SequentialModel
from srforge.transform import EntryTransform
from srforge.transform.data import Multiply
from srforge.transform.entry import RemoveFields, SetAttribute
from srforge.utils import IOSpec


class _AddOne(Model):
    def __init__(self):
        super().__init__()

    def _forward(self, x):
        return x + 1


class _TwoOut(Model):
    io_spec = IOSpec(required_inputs=("x", "g"), required_outputs=("sr", "aux"))

    def __init__(self):
        super().__init__()

    def _forward(self, x, g):
        return x + 1, g + 2


class _AddOneEntry(EntryTransform):
    io_spec = IOSpec(required_inputs=("x",), required_outputs=("y",))

    def __init__(self):
        super().__init__()

    def transform_unbatched(self, entry: Entry) -> Entry:
        entry[self.y] = entry[self.x] + 1
        return entry


class _MaskOptional(EntryTransform):
    io_spec = IOSpec(
        required_inputs=("x",),
        optional_inputs=("mask",),
        required_outputs=("y",),
    )

    def __init__(self):
        super().__init__()

    def transform_unbatched(self, entry: Entry) -> Entry:
        value = entry[self.x]
        mask = entry[self.mask] if self.mask is not None else None
        entry[self.y] = value if mask is None else value * mask
        return entry


class _OptionalOutput(EntryTransform):
    io_spec = IOSpec(
        required_inputs=("x",),
        required_outputs=("y",),
        optional_outputs=("mask",),
    )

    def __init__(self):
        super().__init__()

    def transform_unbatched(self, entry: Entry) -> Entry:
        entry[self.y] = entry[self.x] + 1
        if self.mask is not None:
            entry[self.mask] = entry[self.x] * 0
        return entry


class _NoWriteOutput(EntryTransform):
    io_spec = IOSpec(required_inputs=("x",), required_outputs=("y",))

    def __init__(self):
        super().__init__()

    def transform_unbatched(self, entry: Entry) -> Entry:
        return entry


class TestSequentialModelModelSteps:
    def test_model_step_positional_mapping(self):
        seq = SequentialModel(modules={"m1": _AddOne()}, flow=["x -> m1 -> y"])
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))
        assert torch.allclose(out.x, torch.tensor(1.0))

    def test_model_step_module_mapping_without_lhs(self):
        seq = SequentialModel(modules={"m1": _AddOne()}, flow=[" -> m1(x=x) -> y"])
        entry = Entry(x=torch.tensor(3.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(4.0))

    def test_model_step_partial_output_mapping(self):
        seq = SequentialModel(modules={"m2": _TwoOut()}, flow=["(x, g) -> m2 -> (sr=out, z)"])
        entry = Entry(x=torch.tensor(1.0), g=torch.tensor(2.0))

        out = seq(entry)

        assert torch.allclose(out.out, torch.tensor(2.0))
        assert torch.allclose(out.z, torch.tensor(4.0))

    def test_model_step_unknown_input_key_raises(self):
        with pytest.raises(ValueError):
            SequentialModel(modules={"m1": _AddOne()}, flow=["x -> m1(z=x) -> y"])

    def test_model_step_unknown_output_key_raises(self):
        with pytest.raises(ValueError):
            SequentialModel(modules={"m1": _AddOne()}, flow=["x -> m1 -> (q=y)"])

    def test_model_step_lhs_mismatch_with_mapping_raises(self):
        with pytest.raises(ValueError):
            SequentialModel(modules={"m1": _AddOne()}, flow=["x -> m1(x=z) -> y"])

    def test_model_reuse_same_instance(self):
        model = _AddOne()
        seq = SequentialModel(modules={"m1": model}, flow=["x -> m1 -> y", "y -> m1 -> z"])
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.x, torch.tensor(1.0))
        assert torch.allclose(out.y, torch.tensor(2.0))
        assert torch.allclose(out.z, torch.tensor(3.0))
        assert len(seq.models) == 1


class TestSequentialModelEntryTransforms:
    """Flow DSL infers IO for EntryTransforms — no manual set_io() needed."""

    def test_entry_transform_positional_required(self):
        seq = SequentialModel(modules={"t1": _AddOneEntry()}, flow=["x -> t1 -> y"])
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))

    def test_entry_transform_optional_input_positional(self):
        seq = SequentialModel(modules={"t1": _MaskOptional()}, flow=["(x, mask) -> t1 -> y"])
        entry = Entry(x=torch.tensor(2.0), mask=torch.tensor(0.5))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(1.0))

    def test_entry_transform_optional_input_remapped(self):
        seq = SequentialModel(modules={"t1": _MaskOptional()}, flow=["(x, msk) -> t1 -> y"])
        entry = Entry(x=torch.tensor(2.0), msk=torch.tensor(0.5))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(1.0))

    def test_entry_transform_optional_output_positional(self):
        seq = SequentialModel(modules={"t1": _OptionalOutput()}, flow=["x -> t1 -> (y, mask)"])
        entry = Entry(x=torch.tensor(2.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(3.0))
        assert torch.allclose(out.mask, torch.tensor(0.0))

    def test_entry_transform_optional_output_remapped(self):
        seq = SequentialModel(
            modules={"t1": _OptionalOutput()}, flow=["x -> t1 -> (y, msk)"]
        )
        entry = Entry(x=torch.tensor(2.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(3.0))
        assert torch.allclose(out.msk, torch.tensor(0.0))

    def test_entry_transform_no_output(self):
        seq = SequentialModel(modules={"rm": RemoveFields()}, flow=["x -> rm -> ()"])
        entry = Entry(x=torch.tensor(1.0), y=torch.tensor(2.0))

        out = seq(entry)

        assert "x" not in out
        assert torch.allclose(out.y, torch.tensor(2.0))

    def test_entry_transform_output_only(self):
        seq = SequentialModel(modules={"set": SetAttribute(5)}, flow=[" -> set -> y"])
        entry = Entry()

        out = seq(entry)

        assert out.y == 5

    def test_entry_transform_missing_output_raises(self):
        seq = SequentialModel(modules={"t1": _NoWriteOutput()}, flow=["x -> t1 -> y"])
        entry = Entry(x=torch.tensor(1.0))

        with pytest.raises(KeyError):
            seq(entry)

    def test_entry_transform_named_mapping_in_module_segment(self):
        seq = SequentialModel(
            modules={"t1": _MaskOptional()},
            flow=["(a, b) -> t1(x=a, mask=b) -> result"],
        )
        entry = Entry(a=torch.tensor(4.0), b=torch.tensor(0.5))

        out = seq(entry)

        assert torch.allclose(out.result, torch.tensor(2.0))


class TestSequentialModelEntryTransformPreBound:
    """Pre-bound transforms work — the flow DSL takes precedence over pre-binding."""

    def test_pre_bound_positional(self):
        t = _AddOneEntry()
        t.set_io({"inputs": {"x": "x"}, "outputs": {"y": "y"}})
        seq = SequentialModel(modules={"t1": t}, flow=["x -> t1 -> y"])
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))

    def test_pre_bound_flow_overrides_binding(self):
        """Flow DSL takes precedence over pre-existing set_io() binding."""
        t = _AddOneEntry()
        t.set_io({"inputs": {"x": "x"}, "outputs": {"y": "y"}})
        seq = SequentialModel(modules={"t1": t}, flow=["a -> t1 -> b"])
        entry = Entry(a=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.b, torch.tensor(2.0))

    def test_pre_bound_optional_flow_adds_optional(self):
        """Flow DSL can provide optional ports even when pre-binding did not include them."""
        t = _MaskOptional()
        t.set_io({"inputs": {"x": "x"}, "outputs": {"y": "y"}})
        seq = SequentialModel(modules={"t1": t}, flow=["(x, mask) -> t1 -> y"])
        entry = Entry(x=torch.tensor(2.0), mask=torch.tensor(0.5))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(1.0))

    def test_pre_bound_optional_full(self):
        t = _MaskOptional()
        t.set_io({"inputs": {"x": "x", "mask": "msk"}, "outputs": {"y": "y"}})
        seq = SequentialModel(modules={"t1": t}, flow=["(x, msk) -> t1 -> y"])
        entry = Entry(x=torch.tensor(2.0), msk=torch.tensor(0.5))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(1.0))


class TestSequentialModelDataTransforms:
    def test_data_transform_basic(self):
        seq = SequentialModel(modules={"mul": Multiply(3.0)}, flow=["x -> mul -> y"])
        entry = Entry(x=torch.tensor(2.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(6.0))
        assert torch.allclose(out.x, torch.tensor(2.0))

    def test_data_transform_default_output(self):
        seq = SequentialModel(modules={"mul": Multiply(3.0)}, flow=["x -> mul -> "])
        entry = Entry(x=torch.tensor(2.0))

        out = seq(entry)

        assert torch.allclose(out.x, torch.tensor(6.0))

    def test_data_transform_multiple_inputs(self):
        seq = SequentialModel(modules={"mul": Multiply(2.0)}, flow=["x, y -> mul -> x2, y2"])
        entry = Entry(x=torch.tensor(2.0), y=torch.tensor(3.0))

        out = seq(entry)

        assert torch.allclose(out.x2, torch.tensor(4.0))
        assert torch.allclose(out.y2, torch.tensor(6.0))

    def test_data_transform_recursive(self):
        seq = SequentialModel(modules={"mul": Multiply(2.0)}, flow=["x -> mul -> y"])
        entry = Entry(x={"a": torch.tensor(1.0), "b": torch.tensor(2.0)})

        out = seq(entry)

        assert torch.allclose(out.y["a"], torch.tensor(2.0))
        assert torch.allclose(out.y["b"], torch.tensor(4.0))

    def test_data_transform_mapping_forbidden(self):
        with pytest.raises(ValueError):
            SequentialModel(modules={"mul": Multiply(2.0)}, flow=["(x=a) -> mul -> y"])

        with pytest.raises(ValueError):
            SequentialModel(modules={"mul": Multiply(2.0)}, flow=["x -> mul -> (y=z)"])

    def test_data_transform_output_mismatch_raises(self):
        with pytest.raises(ValueError):
            SequentialModel(modules={"mul": Multiply(2.0)}, flow=["x, y -> mul -> z"])


class TestSequentialModelErrors:
    def test_unknown_module_raises(self):
        with pytest.raises(KeyError):
            SequentialModel(modules={"t1": _AddOneEntry()}, flow=["x -> missing -> y"])

    def test_duplicate_outputs_raise(self):
        with pytest.raises(ValueError):
            SequentialModel(modules={"m2": _TwoOut()}, flow=["x -> m2 -> (sr=out, aux=out)"])

    def test_missing_input_runtime_raises(self):
        seq = SequentialModel(modules={"m1": _AddOne()}, flow=["x -> m1 -> y"])
        entry = Entry()

        with pytest.raises(KeyError):
            seq(entry)

    def test_output_collision_runtime_raises(self):
        seq = SequentialModel(modules={"m1": _AddOne()}, flow=["x -> m1 -> y"])
        entry = Entry(x=torch.tensor(1.0), y=torch.tensor(0.0))

        with pytest.raises(KeyError):
            seq(entry)



class TestSequentialModelModuleReuse:
    """All module types can be reused with different mappings in the same flow."""

    def test_transform_unbatched_reuse_different_mappings(self):
        t = _AddOneEntry()
        seq = SequentialModel(
            modules={"t1": t}, flow=["a -> t1 -> b", "b -> t1 -> c"]
        )
        entry = Entry(a=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.b, torch.tensor(2.0))
        assert torch.allclose(out.c, torch.tensor(3.0))

    def test_transform_unbatched_reuse_with_optional_ports(self):
        t = _MaskOptional()
        seq = SequentialModel(
            modules={"t1": t},
            flow=[
                "(a, m) -> t1 -> b",
                "b -> t1 -> c",
            ],
        )
        entry = Entry(a=torch.tensor(4.0), m=torch.tensor(0.5))

        out = seq(entry)

        assert torch.allclose(out.b, torch.tensor(2.0))   # 4.0 * 0.5
        assert torch.allclose(out.c, torch.tensor(2.0))   # no mask, pass through

    def test_data_transform_reuse_different_fields(self):
        mul = Multiply(2.0)
        seq = SequentialModel(
            modules={"mul": mul},
            flow=["x -> mul -> x2", "y -> mul -> y2"],
        )
        entry = Entry(x=torch.tensor(3.0), y=torch.tensor(5.0))

        out = seq(entry)

        assert torch.allclose(out.x2, torch.tensor(6.0))
        assert torch.allclose(out.y2, torch.tensor(10.0))

    def test_data_transform_reuse_chained(self):
        mul = Multiply(2.0)
        seq = SequentialModel(
            modules={"mul": mul},
            flow=["x -> mul -> y", "y -> mul -> z"],
        )
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))
        assert torch.allclose(out.z, torch.tensor(4.0))

    def test_data_transform_reuse_multi_field(self):
        mul = Multiply(3.0)
        seq = SequentialModel(
            modules={"mul": mul},
            flow=["a, b -> mul -> a2, b2", "c -> mul -> c2"],
        )
        entry = Entry(a=torch.tensor(1.0), b=torch.tensor(2.0), c=torch.tensor(3.0))

        out = seq(entry)

        assert torch.allclose(out.a2, torch.tensor(3.0))
        assert torch.allclose(out.b2, torch.tensor(6.0))
        assert torch.allclose(out.c2, torch.tensor(9.0))

    def test_model_reuse_different_mappings(self):
        m = _AddOne()
        seq = SequentialModel(
            modules={"m1": m},
            flow=["a -> m1 -> b", "b -> m1 -> c"],
        )
        entry = Entry(a=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.b, torch.tensor(2.0))
        assert torch.allclose(out.c, torch.tensor(3.0))


class TestSequentialModelFlowSpecVariants:
    def test_flow_spec_list_of_dicts(self):
        seq = SequentialModel(
            modules={"m1": _AddOne(), "t1": _AddOneEntry()},
            flow=[{"flow": "x -> m1 -> y"}, {"flow": "y -> t1 -> z"}],
        )
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))
        assert torch.allclose(out.z, torch.tensor(3.0))

    def test_flow_comments_and_whitespace(self):
        seq = SequentialModel(
            modules={"m1": _AddOne(), "t1": _AddOneEntry()},
            flow="""
                # comment
                x -> m1 -> y

                y -> t1 -> z
            """,
        )
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.z, torch.tensor(3.0))

    def test_flow_as_single_string(self):
        seq = SequentialModel(modules={"m1": _AddOne()}, flow="x -> m1 -> y")
        entry = Entry(x=torch.tensor(1.0))

        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))


class TestSequentialModelBackwardCompat:
    """Old API (models= and flow-as-dict) still works with deprecation warnings."""

    def test_models_kwarg_deprecated(self):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            seq = SequentialModel(models={"m1": _AddOne()}, flow=["x -> m1 -> y"])
            deprecations = [x for x in w if issubclass(x.category, DeprecationWarning)]
            assert any("models" in str(d.message) for d in deprecations)

        entry = Entry(x=torch.tensor(1.0))
        out = seq(entry)
        assert torch.allclose(out.y, torch.tensor(2.0))

    def test_flow_as_dict_deprecated(self):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            seq = SequentialModel(modules={"m1": _AddOne()}, flow={"flow": ["x -> m1 -> y"]})
            deprecations = [x for x in w if issubclass(x.category, DeprecationWarning)]
            assert any("dict" in str(d.message).lower() for d in deprecations)

        entry = Entry(x=torch.tensor(1.0))
        out = seq(entry)
        assert torch.allclose(out.y, torch.tensor(2.0))

    def test_old_api_models_and_nested_flow(self):
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            seq = SequentialModel(
                models={"m1": _AddOne(), "t1": _AddOneEntry()},
                flow={"flow": ["x -> m1 -> y", "y -> t1 -> z"]},
            )

        entry = Entry(x=torch.tensor(1.0))
        out = seq(entry)

        assert torch.allclose(out.y, torch.tensor(2.0))
        assert torch.allclose(out.z, torch.tensor(3.0))

    def test_both_modules_and_models_raises(self):
        with pytest.raises(ValueError, match="Cannot specify both"):
            SequentialModel(
                modules={"m1": _AddOne()},
                models={"m1": _AddOne()},
                flow=["x -> m1 -> y"],
            )
