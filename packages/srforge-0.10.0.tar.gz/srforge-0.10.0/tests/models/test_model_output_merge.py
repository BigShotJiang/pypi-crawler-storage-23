import pytest
import torch

from srforge.data import Entry
from srforge.models import Model, SequentialModel
from srforge.utils import IOSpec


class _AddOne(Model):
    def __init__(self):
        super().__init__()

    def _forward(self, x):
        return x + 1


class _AddTwo(Model):
    def __init__(self):
        super().__init__()

    def _forward(self, y):
        return y + 2


def test_model_merges_outputs_into_entry():
    entry = Entry(name="scene", x=torch.tensor(1.0))
    model = _AddOne()
    model.set_io({"inputs": {"x": "x"}, "outputs": "sr"})

    out = model(entry)

    assert out is entry
    assert torch.allclose(out.x, torch.tensor(1.0))
    assert torch.allclose(out.sr, torch.tensor(2.0))
    assert set(out.keys()) == {"name", "x", "sr"}


def test_model_raises_on_output_collision():
    entry = Entry(name="scene", x=torch.tensor(1.0), sr=torch.tensor(0.0))
    model = _AddOne()
    model.set_io({"inputs": {"x": "x"}, "outputs": "sr"})

    with pytest.raises(KeyError) as exc:
        model(entry)
    assert "sr" in str(exc.value)


def test_sequential_model_merges_outputs_into_entry():
    seq = SequentialModel(
        modules={"m1": _AddOne(), "m2": _AddTwo()},
        flow=[
            "x -> m1 -> y",
            "y -> m2 -> z",
        ],
    )

    entry = Entry(name="scene", x=torch.tensor(1.0))
    out = seq(entry)

    assert out is entry
    assert torch.allclose(out.x, torch.tensor(1.0))
    assert torch.allclose(out.y, torch.tensor(2.0))
    assert torch.allclose(out.z, torch.tensor(4.0))
    assert set(out.keys()) == {"name", "x", "y", "z"}


def test_sequential_model_raises_on_output_collision():
    seq = SequentialModel(
        modules={"m1": _AddOne()},
        flow=["x -> m1 -> y"],
    )

    entry = Entry(name="scene", x=torch.tensor(1.0), y=torch.tensor(0.0))
    with pytest.raises(KeyError) as exc:
        seq(entry)
    assert "y" in str(exc.value)


class TestModelForwardRename:
    """Users can define forward() instead of _forward() — __init_subclass__ renames it."""

    def test_forward_defined_works_with_entry(self):
        class AddOneForward(Model):
            def forward(self, x):
                return x + 1

        model = AddOneForward()
        model.set_io({"inputs": {"x": "x"}, "outputs": "y"})
        entry = Entry(x=torch.tensor(1.0))
        out = model(entry)
        assert torch.allclose(out.y, torch.tensor(2.0))

    def test_forward_defined_works_standalone(self):
        class AddOneForward(Model):
            def forward(self, x):
                return x + 1

        model = AddOneForward()
        result = model(torch.tensor(3.0))
        assert torch.allclose(result, torch.tensor(4.0))

    def test_private_forward_still_works(self):
        """Backward compat: _forward() still works."""
        model = _AddOne()
        model.set_io({"inputs": {"x": "x"}, "outputs": "sr"})
        entry = Entry(x=torch.tensor(1.0))
        out = model(entry)
        assert torch.allclose(out.sr, torch.tensor(2.0))

    def test_both_forward_and_private_raises(self):
        with pytest.raises(TypeError, match="both 'forward' and '_forward'"):
            class Bad(Model):
                def forward(self, x):
                    return x + 1
                def _forward(self, x):
                    return x + 2

    def test_forward_in_sequential_model(self):
        class MulTwo(Model):
            def forward(self, x):
                return x * 2

        seq = SequentialModel(
            modules={"m": MulTwo()},
            flow=["a -> m -> b"],
        )
        out = seq(Entry(a=torch.tensor(3.0)))
        assert torch.allclose(out.b, torch.tensor(6.0))

    def test_no_iospec_raw_args_works(self):
        """Model without IOSpec can be called with raw args (prototyping mode)."""
        class PlainModel(Model):
            def _forward(self, x):
                return x * 2

        model = PlainModel()
        result = model(torch.tensor(3.0))
        assert torch.allclose(result, torch.tensor(6.0))

    def test_no_iospec_entry_raises(self):
        """Model without output binding raises when called with Entry."""
        class PlainModel(Model):
            def _forward(self, x):
                return x * 2

        model = PlainModel()
        with pytest.raises(ValueError, match="no output ports"):
            model(Entry(x=torch.tensor(1.0)))
