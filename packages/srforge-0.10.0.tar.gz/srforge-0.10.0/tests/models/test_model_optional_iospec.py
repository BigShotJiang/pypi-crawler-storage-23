"""Tests for optional IOSpec on Model.

Inputs are always inferred from _forward() signature.
Outputs come from set_io(), flow DSL, or explicit IOSpec.
"""

import pytest
import torch

from srforge.data import Entry
from srforge.models import Model, SequentialModel
from srforge.utils import IOSpec


class _PlainModel(Model):
    """Model without IOSpec — inputs inferred from _forward()."""

    def __init__(self):
        super().__init__()

    def _forward(self, x):
        return x + 1


class _TwoOutputModel(Model):
    """Model without IOSpec that returns two values."""

    def __init__(self):
        super().__init__()

    def _forward(self, x, g):
        return x + 1, g + 2


class _OptionalInputModel(Model):
    """Model without IOSpec with an optional input."""

    def __init__(self):
        super().__init__()

    def _forward(self, x, bias=None):
        return x + bias if bias is not None else x + 1


class _ModelWithIOSpec(Model):
    """Model WITH IOSpec — backward compatibility."""

    io_spec = IOSpec(required_inputs=("x",), required_outputs=("y",))

    def __init__(self):
        super().__init__()

    def _forward(self, x):
        return x + 1


# ---------------------------------------------------------------------------
# Auto-created IOSpec
# ---------------------------------------------------------------------------


class TestModelAutoCreatedIOSpec:
    def test_io_spec_never_none(self):
        model = _PlainModel()
        assert model.io_spec is not None

    def test_inputs_auto_inferred(self):
        model = _PlainModel()
        assert "x" in model.io_spec.all_inputs

    def test_optional_inputs_auto_inferred(self):
        model = _OptionalInputModel()
        assert "x" in model.io_spec.required_inputs
        assert "bias" in model.io_spec.optional_inputs

    def test_no_outputs_initially(self):
        model = _PlainModel()
        assert not model.io_spec.all_outputs


# ---------------------------------------------------------------------------
# Model.set_io() output inference
# ---------------------------------------------------------------------------


class TestModelSetIO:
    def test_set_io_creates_applications(self):
        model = _PlainModel()
        model.set_io({"inputs": {"x": "a"}, "outputs": "b"})
        assert model._applications == [({"x": "a"}, ["b"])]

    def test_set_io_dict_outputs(self):
        model = _PlainModel()
        model.set_io({"inputs": {"x": "a"}, "outputs": {"sr": "b"}})
        assert model._applications == [({"x": "a"}, ["b"])]

    def test_entry_after_set_io_works(self):
        model = _PlainModel()
        model.set_io({"inputs": {"x": "a"}, "outputs": "b"})
        entry = Entry(a=torch.tensor(1.0))
        out = model(entry)
        assert torch.allclose(out.b, torch.tensor(2.0))

    def test_entry_without_set_io_raises(self):
        model = _PlainModel()
        with pytest.raises(ValueError, match="no output ports"):
            model(Entry(x=torch.tensor(1.0)))

    def test_raw_tensor_without_set_io_works(self):
        model = _PlainModel()
        result = model(torch.tensor(3.0))
        assert torch.allclose(result, torch.tensor(4.0))

    def test_set_io_returns_self(self):
        model = _PlainModel()
        result = model.set_io({"inputs": {"x": "a"}, "outputs": "b"})
        assert result is model


# ---------------------------------------------------------------------------
# SequentialModel positional outputs
# ---------------------------------------------------------------------------


class TestSequentialModelPositionalOutputs:
    def test_single_output(self):
        seq = SequentialModel(modules={"m": _PlainModel()}, flow=["x -> m -> y"])
        entry = Entry(x=torch.tensor(1.0))
        out = seq(entry)
        assert torch.allclose(out.y, torch.tensor(2.0))

    def test_multi_output(self):
        seq = SequentialModel(
            modules={"m": _TwoOutputModel()},
            flow=["(x, g) -> m -> (y, z)"],
        )
        entry = Entry(x=torch.tensor(1.0), g=torch.tensor(2.0))
        out = seq(entry)
        assert torch.allclose(out.y, torch.tensor(2.0))
        assert torch.allclose(out.z, torch.tensor(4.0))

    def test_reuse_different_mappings(self):
        seq = SequentialModel(
            modules={"m": _PlainModel()},
            flow=["a -> m -> b", "b -> m -> c"],
        )
        entry = Entry(a=torch.tensor(1.0))
        out = seq(entry)
        assert torch.allclose(out.b, torch.tensor(2.0))
        assert torch.allclose(out.c, torch.tensor(3.0))

    def test_named_input_mapping_positional_output(self):
        seq = SequentialModel(
            modules={"m": _PlainModel()},
            flow=[" -> m(x=a) -> b"],
        )
        entry = Entry(a=torch.tensor(5.0))
        out = seq(entry)
        assert torch.allclose(out.b, torch.tensor(6.0))

    def test_named_output_without_iospec_raises(self):
        with pytest.raises(ValueError, match="no declared output ports"):
            SequentialModel(
                modules={"m": _PlainModel()},
                flow=["x -> m -> (output=y)"],
            )

    def test_return_count_mismatch_raises(self):
        seq = SequentialModel(
            modules={"m": _PlainModel()},
            flow=["x -> m -> (y, z)"],
        )
        entry = Entry(x=torch.tensor(1.0))
        with pytest.raises(ValueError, match="returned 1 values.*expects 2"):
            seq(entry)

    def test_optional_input_in_flow(self):
        seq = SequentialModel(
            modules={"m": _OptionalInputModel()},
            flow=["(x, bias) -> m -> y"],
        )
        entry = Entry(x=torch.tensor(5.0), bias=torch.tensor(10.0))
        out = seq(entry)
        assert torch.allclose(out.y, torch.tensor(15.0))


# ---------------------------------------------------------------------------
# Backward compatibility: models WITH IOSpec
# ---------------------------------------------------------------------------


class TestBackwardCompatWithIOSpec:
    def test_model_with_iospec_standalone(self):
        model = _ModelWithIOSpec()
        entry = Entry(x=torch.tensor(1.0))
        out = model(entry)
        assert torch.allclose(out.y, torch.tensor(2.0))

    def test_model_with_iospec_in_flow(self):
        seq = SequentialModel(
            modules={"m": _ModelWithIOSpec()},
            flow=["a -> m -> b"],
        )
        entry = Entry(a=torch.tensor(1.0))
        out = seq(entry)
        assert torch.allclose(out.b, torch.tensor(2.0))

    def test_model_with_iospec_named_output_in_flow(self):
        seq = SequentialModel(
            modules={"m": _ModelWithIOSpec()},
            flow=["a -> m -> (y=b)"],
        )
        entry = Entry(a=torch.tensor(1.0))
        out = seq(entry)
        assert torch.allclose(out.b, torch.tensor(2.0))
