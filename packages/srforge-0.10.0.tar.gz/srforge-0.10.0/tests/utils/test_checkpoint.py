"""Tests for standardized checkpoint save/load utilities."""

import random

import numpy as np
import pytest
import torch

from srforge.models import Model, SequentialModel
from srforge.utils.checkpoint import (
    CHECKPOINT_VERSION,
    CheckpointState,
    _capture_rng_states,
    _restore_rng_states,
    load_checkpoint,
    load_model_weights,
    save_checkpoint,
    save_model_weights,
)


# ── Test helpers ─────────────────────────────────────────────────────


class _DummyModel(Model):
    def __init__(self, name="dummy"):
        super().__init__()
        self.linear = torch.nn.Linear(4, 4)
        self._name = name

    @property
    def name(self):
        return self._name

    def _forward(self, x):
        return self.linear(x)


def _make_optimizer(model):
    return torch.optim.SGD(model.parameters(), lr=0.01)


def _make_scheduler(optimizer):
    return torch.optim.lr_scheduler.StepLR(optimizer, step_size=10)


# ── save_checkpoint / load_checkpoint ────────────────────────────────


class TestSaveCheckpoint:
    def test_structure(self, tmp_path):
        model = _DummyModel()
        opt = _make_optimizer(model)
        sched = _make_scheduler(opt)
        scaler = torch.amp.GradScaler("cpu", enabled=True)

        path = str(tmp_path / "ckpt.pth")
        save_checkpoint(
            path, epoch=5, optimizer=opt, lr_scheduler=sched,
            scaler=scaler, best_loss=0.42,
        )

        data = torch.load(path, map_location="cpu", weights_only=False)
        assert data["checkpoint_version"] == CHECKPOINT_VERSION
        assert data["epoch"] == 5
        assert data["best_losses"] == {"total": 0.42}
        assert "optimizer" in data
        assert "lr_scheduler" in data
        assert "rng_states" in data
        assert set(data["rng_states"]) == {"python", "numpy", "torch_cpu", "torch_cuda"}

    def test_scaler_none_when_disabled(self, tmp_path):
        model = _DummyModel()
        opt = _make_optimizer(model)
        sched = _make_scheduler(opt)
        scaler = torch.amp.GradScaler("cpu", enabled=False)

        path = str(tmp_path / "ckpt.pth")
        save_checkpoint(
            path, epoch=0, optimizer=opt, lr_scheduler=sched,
            scaler=scaler, best_loss=None,
        )

        data = torch.load(path, map_location="cpu", weights_only=False)
        assert data["scaler"] is None

    def test_scaler_state_when_enabled(self, tmp_path):
        model = _DummyModel()
        opt = _make_optimizer(model)
        sched = _make_scheduler(opt)
        scaler = torch.amp.GradScaler("cpu", enabled=True)

        path = str(tmp_path / "ckpt.pth")
        save_checkpoint(
            path, epoch=0, optimizer=opt, lr_scheduler=sched,
            scaler=scaler, best_loss=None,
        )

        data = torch.load(path, map_location="cpu", weights_only=False)
        assert isinstance(data["scaler"], dict)

    def test_scaler_none_when_none_passed(self, tmp_path):
        model = _DummyModel()
        opt = _make_optimizer(model)
        sched = _make_scheduler(opt)

        path = str(tmp_path / "ckpt.pth")
        save_checkpoint(
            path, epoch=0, optimizer=opt, lr_scheduler=sched,
            scaler=None, best_loss=None,
        )

        data = torch.load(path, map_location="cpu", weights_only=False)
        assert data["scaler"] is None
        assert data["best_losses"] is None


class TestLoadCheckpoint:
    def test_roundtrip(self, tmp_path):
        model = _DummyModel()
        opt = _make_optimizer(model)
        sched = _make_scheduler(opt)

        path = str(tmp_path / "ckpt.pth")
        save_checkpoint(
            path, epoch=10, optimizer=opt, lr_scheduler=sched,
            scaler=None, best_loss=1.23,
        )

        ckpt = load_checkpoint(path)
        assert isinstance(ckpt, CheckpointState)
        assert ckpt.checkpoint_version == CHECKPOINT_VERSION
        assert ckpt.epoch == 10
        assert ckpt.best_losses == {"total": 1.23}
        assert ckpt.scaler_state is None
        assert ckpt.rng_states is not None

    def test_legacy_format(self, tmp_path):
        """Old checkpoints without checkpoint_version and rng_states."""
        legacy = {
            "epoch": 7,
            "optimizer": {"state": {}},
            "lr_scheduler": {"step_size": 10},
            "scaler": {"scale": 1.0},
            "best_losses": {"total": 0.5},
        }
        path = str(tmp_path / "legacy.pth")
        torch.save(legacy, path)

        ckpt = load_checkpoint(path)
        assert ckpt.checkpoint_version == 0
        assert ckpt.epoch == 7
        assert ckpt.rng_states is None
        assert ckpt.scaler_state == {"scale": 1.0}
        assert ckpt.best_losses == {"total": 0.5}


# ── RNG states ───────────────────────────────────────────────────────


class TestRngStates:
    def test_roundtrip(self):
        """Capture, advance, restore — should produce same random output."""
        torch.manual_seed(42)
        np.random.seed(42)
        random.seed(42)

        states = _capture_rng_states()

        # Advance RNG
        expected_torch = torch.randn(5)
        expected_numpy = np.random.randn(5)
        expected_python = random.random()

        # Restore and regenerate
        _restore_rng_states(states)
        actual_torch = torch.randn(5)
        actual_numpy = np.random.randn(5)
        actual_python = random.random()

        assert torch.equal(expected_torch, actual_torch)
        np.testing.assert_array_equal(expected_numpy, actual_numpy)
        assert expected_python == actual_python

    def test_no_cuda_safe(self):
        """torch_cuda should be empty list on CPU-only, restore should not error."""
        states = _capture_rng_states()
        if not torch.cuda.is_available():
            assert states["torch_cuda"] == []
        # Should not raise regardless
        _restore_rng_states(states)


# ── Model weights ────────────────────────────────────────────────────


class TestSaveModelWeights:
    def test_single_model(self, tmp_path):
        model = _DummyModel(name="mymodel")
        paths = save_model_weights(model, str(tmp_path), "_last")
        assert len(paths) == 1
        assert paths[0].endswith("mymodel_last.pth")
        assert (tmp_path / "mymodel_last.pth").exists()

    def test_sequential_model(self, tmp_path):
        m1 = _DummyModel(name="enc")
        m2 = _DummyModel(name="dec")
        seq = SequentialModel(
            modules={"enc": m1, "dec": m2},
            flow="x -> enc -> mid\nmid -> dec -> y",
        )
        paths = save_model_weights(seq, str(tmp_path), "_best")
        assert len(paths) == 2
        names = {p.split("/")[-1].split("\\")[-1] for p in paths}
        assert names == {"enc_best.pth", "dec_best.pth"}

    def test_returns_paths(self, tmp_path):
        model = _DummyModel(name="test")
        paths = save_model_weights(model, str(tmp_path), "_last")
        assert isinstance(paths, list)
        for p in paths:
            assert isinstance(p, str)


class TestLoadModelWeights:
    def test_roundtrip(self, tmp_path):
        model = _DummyModel(name="net")
        original_state = {k: v.clone() for k, v in model.state_dict().items()}

        save_model_weights(model, str(tmp_path), "_last")

        # Reinitialize with different weights
        model2 = _DummyModel(name="net")
        model2.linear.weight.data.fill_(999.0)

        load_model_weights(
            model2,
            lambda fn: str(tmp_path / fn),
            suffix="_last",
        )

        for key in original_state:
            assert torch.equal(model2.state_dict()[key], original_state[key])

    def test_sequential_roundtrip(self, tmp_path):
        m1 = _DummyModel(name="a")
        m2 = _DummyModel(name="b")
        seq = SequentialModel(
            modules={"a": m1, "b": m2},
            flow="x -> a -> mid\nmid -> b -> y",
        )

        orig_a = {k: v.clone() for k, v in m1.state_dict().items()}
        orig_b = {k: v.clone() for k, v in m2.state_dict().items()}

        save_model_weights(seq, str(tmp_path), "_last")

        # New models with different weights
        m1_new = _DummyModel(name="a")
        m2_new = _DummyModel(name="b")
        m1_new.linear.weight.data.fill_(0.0)
        m2_new.linear.weight.data.fill_(0.0)
        seq_new = SequentialModel(
            modules={"a": m1_new, "b": m2_new},
            flow="x -> a -> mid\nmid -> b -> y",
        )

        load_model_weights(seq_new, lambda fn: str(tmp_path / fn), suffix="_last")

        for key in orig_a:
            assert torch.equal(m1_new.state_dict()[key], orig_a[key])
        for key in orig_b:
            assert torch.equal(m2_new.state_dict()[key], orig_b[key])
