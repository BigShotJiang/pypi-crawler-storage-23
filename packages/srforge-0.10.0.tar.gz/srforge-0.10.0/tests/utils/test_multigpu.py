"""Tests for the multigpu utility."""

from unittest.mock import MagicMock, patch

import pytest
import torch

from srforge.data import Entry
from srforge.utils.multigpu import wrap_data_parallel


class _FakeOther:
    """Neither Entry nor GraphEntry."""
    pass


@pytest.fixture
def model():
    return torch.nn.Linear(4, 4)


class TestWrapDataParallel:
    def test_entry_uses_torch_dp(self, model):
        dataset = MagicMock()
        dataset.__getitem__ = MagicMock(return_value=Entry())
        with patch("torch.nn.DataParallel") as mock_dp:
            mock_dp.return_value = MagicMock()
            wrap_data_parallel(model, ["cuda:0"], dataset)
            mock_dp.assert_called_once_with(model, device_ids=[0])

    def test_unsupported_type_raises(self, model):
        dataset = MagicMock()
        dataset.__getitem__ = MagicMock(return_value=_FakeOther())
        with pytest.raises(TypeError, match="Unsupported dataset element type"):
            wrap_data_parallel(model, ["cuda:0"], dataset)

    def test_device_ids_extracted(self, model):
        """Device strings are converted to integer indices."""
        dataset = MagicMock()
        dataset.__getitem__ = MagicMock(return_value=Entry())
        with patch("torch.nn.DataParallel") as mock_dp:
            mock_dp.return_value = MagicMock()
            wrap_data_parallel(model, ["cuda:0", "cuda:1"], dataset)
            mock_dp.assert_called_once_with(model, device_ids=[0, 1])
