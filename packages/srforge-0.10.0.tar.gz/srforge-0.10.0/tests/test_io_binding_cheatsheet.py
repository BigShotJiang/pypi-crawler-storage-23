"""Tests verifying IO binding methods from the cheatsheet produce identical results.

Each test class corresponds to a section in docs/src/io-binding.md cheatsheet.
All set_io calls use the unified format:

    {"inputs": {param_or_port: entry_field}, "outputs": <string|list|dict>}

Flow DSL tests are unchanged (flow syntax is separate from set_io format).
"""

import pytest
import torch

from srforge.data import Entry
from srforge.models import Model, SequentialModel
from srforge.transform import EntryTransform, DataTransform
from srforge.utils import IOSpec


# ---------------------------------------------------------------------------
# Test modules
# ---------------------------------------------------------------------------


class _AddOne(Model):
    """output = image + 1."""

    io_spec = IOSpec(required_inputs=("image",), required_outputs=("output",))

    def __init__(self):
        super().__init__()

    def _forward(self, image):
        return image + 1


class _AddGuide(Model):
    """output = image + guide (or image + 1 without guide)."""

    io_spec = IOSpec(
        required_inputs=("image",),
        optional_inputs=("guide",),
        required_outputs=("output",),
    )

    def __init__(self):
        super().__init__()

    def _forward(self, image, guide=None):
        return image + guide if guide is not None else image + 1


class _DoubleInPlace(EntryTransform):
    """transform_unbatched style, in-place: field *= 2."""

    io_spec = IOSpec(required_inputs=("field",), required_outputs=("field",))

    def transform_unbatched(self, entry):
        entry[self.field] = entry[self.field] * 2
        return entry


class _CopySrcDst(EntryTransform):
    """transform_unbatched style, separate ports: dst = clone(src)."""

    io_spec = IOSpec(required_inputs=("src",), required_outputs=("dst",))

    def transform_unbatched(self, entry):
        entry[self.dst] = entry[self.src].clone()
        return entry


class _Times3(DataTransform):
    """DataTransform: data * 3."""

    def __init__(self):
        super().__init__()

    def transform(self, data):
        return data * 3


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _t(*values):
    """Shorthand for creating a float tensor."""
    return torch.tensor(list(values), dtype=torch.float32)


# ===========================================================================
# Model cheatsheet
# ===========================================================================


class TestModelBindingMethods:
    """Binding methods for Model produce identical output.

    Cheatsheet rows: set_io (unified), flow positional,
    flow named (module), flow named (output).
    """

    def test_set_io(self):
        model = _AddOne().set_io({
            "inputs": {"image": "x"},
            "outputs": {"output": "y"},
        })
        result = model(Entry(x=_t(1, 2, 3)))
        assert torch.equal(result["y"], _t(2, 3, 4))

    def test_flow_dsl_positional(self):
        seq = SequentialModel(modules={"m": _AddOne()}, flow=["x -> m -> y"])
        result = seq(Entry(x=_t(1, 2, 3)))
        assert torch.equal(result["y"], _t(2, 3, 4))

    def test_flow_dsl_named_module(self):
        seq = SequentialModel(
            modules={"m": _AddOne()},
            flow=["x -> m(image=x) -> y"],
        )
        result = seq(Entry(x=_t(1, 2, 3)))
        assert torch.equal(result["y"], _t(2, 3, 4))

    def test_flow_dsl_named_output(self):
        seq = SequentialModel(
            modules={"m": _AddOne()},
            flow=["x -> m -> (output=y)"],
        )
        result = seq(Entry(x=_t(1, 2, 3)))
        assert torch.equal(result["y"], _t(2, 3, 4))


class TestModelOptionalInputs:
    """Optional inputs work consistently across binding methods.

    Cheatsheet: IOSpec optional_inputs -- may be omitted from binding.
    """

    def test_set_io_without_optional(self):
        model = _AddGuide().set_io({
            "inputs": {"image": "x"},
            "outputs": {"output": "y"},
        })
        result = model(Entry(x=_t(1, 2, 3)))
        assert torch.equal(result["y"], _t(2, 3, 4))

    def test_set_io_with_optional(self):
        model = _AddGuide().set_io({
            "inputs": {"image": "x", "guide": "g"},
            "outputs": {"output": "y"},
        })
        result = model(Entry(x=_t(1, 2, 3), g=_t(10, 20, 30)))
        assert torch.equal(result["y"], _t(11, 22, 33))

    def test_flow_positional_without_optional(self):
        seq = SequentialModel(modules={"m": _AddGuide()}, flow=["x -> m -> y"])
        result = seq(Entry(x=_t(1, 2, 3)))
        assert torch.equal(result["y"], _t(2, 3, 4))

    def test_flow_positional_with_optional(self):
        seq = SequentialModel(
            modules={"m": _AddGuide()},
            flow=["(x, g) -> m -> y"],
        )
        result = seq(Entry(x=_t(1, 2, 3), g=_t(10, 20, 30)))
        assert torch.equal(result["y"], _t(11, 22, 33))

    def test_flow_named_with_optional(self):
        seq = SequentialModel(
            modules={"m": _AddGuide()},
            flow=["(x, g) -> m(image=x, guide=g) -> y"],
        )
        result = seq(Entry(x=_t(1, 2, 3), g=_t(10, 20, 30)))
        assert torch.equal(result["y"], _t(11, 22, 33))


class TestModelWithoutIOSpec:
    """Models without IOSpec -- inputs inferred from _forward, outputs from set_io/flow.

    Cheatsheet: no IOSpec required.
    """

    def test_set_io_infers_outputs(self):
        """set_io with outputs string -- output name comes from the string."""

        class _Plain(Model):
            def _forward(self, image):
                return image + 1

        model = _Plain().set_io({"inputs": {"image": "x"}, "outputs": "y"})
        result = model(Entry(x=_t(1, 2, 3)))
        assert torch.equal(result["y"], _t(2, 3, 4))

    def test_flow_positional(self):
        """Flow DSL positional mapping works without IOSpec."""

        class _Plain(Model):
            def _forward(self, image):
                return image + 1

        seq = SequentialModel(modules={"m": _Plain()}, flow=["x -> m -> y"])
        result = seq(Entry(x=_t(1, 2, 3)))
        assert torch.equal(result["y"], _t(2, 3, 4))

    def test_raw_args_no_binding(self):
        """Raw tensor call works without any IO binding."""

        class _Plain(Model):
            def _forward(self, image):
                return image + 1

        model = _Plain()
        result = model(_t(1, 2, 3))
        assert torch.equal(result, _t(2, 3, 4))

    def test_entry_without_binding_raises(self):
        """Calling with Entry before set_io raises clear error."""

        class _Plain(Model):
            def _forward(self, image):
                return image + 1

        model = _Plain()
        with pytest.raises(ValueError, match="no output ports"):
            model(Entry(image=_t(1, 2, 3)))


# ===========================================================================
# EntryTransform cheatsheet
# ===========================================================================


class TestEntryTransformEntryBindingMethods:
    """transform_unbatched style: binding methods produce identical output.

    Cheatsheet rows: set_io (unified), flow positional,
    flow named (module), flow named (LHS).
    """

    def test_set_io(self):
        t = _CopySrcDst()
        t.set_io({"inputs": {"src": "a"}, "outputs": {"dst": "b"}})
        result = t(Entry(a=_t(1, 2, 3)))
        assert torch.equal(result["b"], _t(1, 2, 3))

    def test_flow_dsl_positional(self):
        seq = SequentialModel(
            modules={"t": _CopySrcDst()},
            flow=["a -> t -> b"],
        )
        result = seq(Entry(a=_t(1, 2, 3)))
        assert torch.equal(result["b"], _t(1, 2, 3))

    def test_flow_dsl_named_module(self):
        seq = SequentialModel(
            modules={"t": _CopySrcDst()},
            flow=["a -> t(src=a) -> b"],
        )
        result = seq(Entry(a=_t(1, 2, 3)))
        assert torch.equal(result["b"], _t(1, 2, 3))

    def test_flow_dsl_named_lhs(self):
        seq = SequentialModel(
            modules={"t": _CopySrcDst()},
            flow=["(src=a) -> t -> b"],
        )
        result = seq(Entry(a=_t(1, 2, 3)))
        assert torch.equal(result["b"], _t(1, 2, 3))


# ===========================================================================
# EntryTransform -- in-place ports
# ===========================================================================


class TestEntryTransformInPlace:
    """In-place ports (same name in inputs and outputs).

    Cheatsheet: EntryTransform in-place ports table.
    """

    def test_inputs_only_implies_in_place(self):
        """Omitting outputs for in-place port auto-maps output to same field."""
        t = _DoubleInPlace()
        t.set_io({"inputs": {"field": "data"}})
        result = t(Entry(data=_t(1, 2, 3)))
        assert torch.equal(result["data"], _t(2, 4, 6))

    def test_explicit_same_field_allowed(self):
        t = _DoubleInPlace()
        t.set_io({"inputs": {"field": "data"}, "outputs": {"field": "data"}})
        result = t(Entry(data=_t(1, 2, 3)))
        assert torch.equal(result["data"], _t(2, 4, 6))

    def test_outputs_override_inputs_for_same_port(self):
        """When outputs maps the same port to a different field, outputs wins."""
        t = _DoubleInPlace()
        t.set_io({"inputs": {"field": "raw"}, "outputs": {"field": "processed"}})
        # outputs overwrites inputs for the shared port name: field -> "processed"
        result = t(Entry(processed=torch.tensor([1.0, 2.0, 3.0])))
        assert torch.equal(result["processed"], torch.tensor([2.0, 4.0, 6.0]))

    def test_flow_dsl_in_place(self):
        seq = SequentialModel(
            modules={"t": _DoubleInPlace()},
            flow=["data -> t -> data"],
        )
        result = seq(Entry(data=_t(1, 2, 3)))
        assert torch.equal(result["data"], _t(2, 4, 6))


# ===========================================================================
# EntryTransform -- pre-bound behavior in SequentialModel
# ===========================================================================


class TestEntryTransformPreBound:
    """Pre-bound transforms in SequentialModel.

    Cheatsheet: Pre-bound transforms table.
    """

    def test_not_bound_transform_unbatched_rebound_at_runtime(self):
        """transform_unbatched: flow infers mapping, ports are rebound per step at runtime."""
        t = _CopySrcDst()
        seq = SequentialModel(modules={"t": t}, flow=["a -> t -> b"])
        result = seq(Entry(a=_t(5)))
        assert torch.equal(result["b"], _t(5))

    def test_pre_bound_matching_flow_ok(self):
        """Already bound, flow matches -- no error."""
        t = _CopySrcDst()
        t.set_io({"inputs": {"src": "a"}, "outputs": {"dst": "b"}})
        seq = SequentialModel(modules={"t": t}, flow=["a -> t -> b"])
        result = seq(Entry(a=_t(7)))
        assert torch.equal(result["b"], _t(7))

    def test_pre_bound_mismatching_flow_overrides(self):
        """Already bound, flow differs -- flow DSL takes precedence."""
        t = _CopySrcDst()
        t.set_io({"inputs": {"src": "a"}, "outputs": {"dst": "b"}})
        seq = SequentialModel(modules={"t": t}, flow=["x -> t -> y"])
        result = seq(Entry(x=_t(7)))
        assert torch.equal(result["y"], _t(7))


# ===========================================================================
# EntryTransform -- reuse rules
# ===========================================================================


class TestEntryTransformReuse:
    """Reusability rules for EntryTransform."""

    def test_transform_unbatched_reusable_different_mappings(self):
        """Same transform_unbatched instance can be reused with different mappings."""
        t = _CopySrcDst()
        seq = SequentialModel(
            modules={"t": t},
            flow=[
                "a -> t -> b",
                "b -> t -> c",
            ],
        )
        result = seq(Entry(a=_t(5)))
        assert torch.equal(result["b"], _t(5))
        assert torch.equal(result["c"], _t(5))


# ===========================================================================
# DataTransform cheatsheet -- single field
# ===========================================================================


class TestDataTransformBindingMethods:
    """DataTransform binding methods produce identical output (single field).

    Cheatsheet rows: set_io in-place, set_io with rename, flow DSL rename,
    flow DSL in-place.
    """

    def test_set_io_in_place(self):
        """Omitting outputs defaults to in-place."""
        t = _Times3()
        t.set_io({"inputs": {"data": "x"}})
        result = t(Entry(x=_t(1, 2)))
        assert torch.equal(result["x"], _t(3, 6))

    def test_set_io_rename(self):
        t = _Times3()
        t.set_io({"inputs": {"data": "x"}, "outputs": "y"})
        result = t(Entry(x=_t(1, 2)))
        assert torch.equal(result["y"], _t(3, 6))

    def test_flow_dsl_rename(self):
        seq = SequentialModel(modules={"t": _Times3()}, flow=["x -> t -> y"])
        result = seq(Entry(x=_t(1, 2)))
        assert torch.equal(result["y"], _t(3, 6))

    def test_flow_dsl_in_place(self):
        seq = SequentialModel(modules={"t": _Times3()}, flow=["x -> t -> x"])
        result = seq(Entry(x=_t(1, 2)))
        assert torch.equal(result["x"], _t(3, 6))


# ===========================================================================
# DataTransform cheatsheet -- multi-field
# ===========================================================================


class TestDataTransformMultiField:
    """Multi-field DataTransform across binding methods.

    All methods produce the same paired output.
    """

    def test_set_io_in_place(self):
        t = _Times3()
        t.set_io({"inputs": [{"data": "x"}, {"data": "y"}]})
        result = t(Entry(x=_t(1), y=_t(2)))
        assert torch.equal(result["x"], _t(3))
        assert torch.equal(result["y"], _t(6))

    def test_set_io_rename(self):
        t = _Times3()
        t.set_io({
            "inputs": [{"data": "x"}, {"data": "y"}],
            "outputs": ["x3", "y3"],
        })
        result = t(Entry(x=_t(1), y=_t(2)))
        assert torch.equal(result["x3"], _t(3))
        assert torch.equal(result["y3"], _t(6))

    def test_flow_dsl_multi_field(self):
        seq = SequentialModel(
            modules={"t": _Times3()},
            flow=["x, y -> t -> x3, y3"],
        )
        result = seq(Entry(x=_t(1), y=_t(2)))
        assert torch.equal(result["x3"], _t(3))
        assert torch.equal(result["y3"], _t(6))


# ===========================================================================
# DataTransform -- SequentialModel auto-binding and validation
# ===========================================================================


class TestDataTransformInSequentialModel:
    """DataTransform auto-binding and validation in SequentialModel.

    Cheatsheet: DataTransform in SequentialModel table.
    """

    def test_not_bound_external_driving(self):
        """Flow DSL computes applications externally -- module state is not mutated."""
        t = _Times3()
        assert not getattr(t, "_io_bound", False)
        seq = SequentialModel(modules={"t": t}, flow=["x -> t -> y"])
        assert not getattr(t, "_io_bound", False)  # instance state not mutated
        result = seq(Entry(x=_t(2)))
        assert torch.equal(result["y"], _t(6))

    def test_already_bound_validates_ok(self):
        """Pre-bound DataTransform, flow matches -- no error."""
        t = _Times3()
        t.set_io({"inputs": {"data": "x"}, "outputs": "y"})
        seq = SequentialModel(modules={"t": t}, flow=["x -> t -> y"])
        result = seq(Entry(x=_t(2)))
        assert torch.equal(result["y"], _t(6))

    def test_already_bound_mismatch_overrides(self):
        """Pre-bound DataTransform, flow differs -- flow DSL takes precedence."""
        t = _Times3()
        t.set_io({"inputs": {"data": "x"}, "outputs": "y"})
        seq = SequentialModel(modules={"t": t}, flow=["a -> t -> b"])
        result = seq(Entry(a=_t(2)))
        assert torch.equal(result["b"], _t(6))

    def test_not_bound_no_flow_fields_raises(self):
        """Unbound DataTransform with empty flow fields -- ValueError."""
        t = _Times3()
        with pytest.raises(ValueError, match="requires flow inputs"):
            SequentialModel(modules={"t": t}, flow=["() -> t -> ()"])
