"""Tests for config-driven observer wiring to runners/trainer."""

import pytest
from dataclasses import dataclass
from omegaconf import OmegaConf

from srforge.events.base import Event
from srforge.observers.base import Observer, Observable
from srforge.config.legacy import ConfigParser


# ── Test events & observers ──────────────────────────────────────────────

@dataclass(frozen=True)
class DummyEvent(Event):
    value: int


class DummyObserver(Observer):
    EVENTS = [DummyEvent]

    def __init__(self, name: str = "default", **kwargs):
        super().__init__(**kwargs)
        self.name = name
        self.received = []

    def on_dummy_event(self, event: DummyEvent):
        self.received.append(event.value)


# Register for ConfigParser resolution
from srforge.registry import register_class
register_class(DummyObserver)


# ── Helpers ──────────────────────────────────────────────────────────────

def make_parser():
    """Create a minimal ConfigParser (cfg/wandb_run unused for direct parsing)."""
    cfg = OmegaConf.create({})
    return ConfigParser(cfg, None)


# ── Tests ────────────────────────────────────────────────────────────────

class TestObserverFromConfig:
    def test_parse_single_observer(self):
        parser = make_parser()
        obs_cfg = OmegaConf.create({
            "_target": "DummyObserver",
            "params": {"name": "test_obs"}
        })
        obs = parser(obs_cfg)
        assert isinstance(obs, DummyObserver)
        assert obs.name == "test_obs"

    def test_attach_parsed_observer_to_bus(self, fresh_event_bus):
        """Observer explicitly subscribed to bus receives events from Observable."""
        parser = make_parser()
        obs_cfg = OmegaConf.create({
            "_target": "DummyObserver",
            "params": {"name": "attached"}
        })
        obs = parser(obs_cfg)
        fresh_event_bus.subscribe(obs)

        # Observable auto-attaches to global bus, so notify goes through the bus.
        target = Observable()
        target.notify(DummyEvent(value=42))

        assert obs.received == [42]

    def test_multiple_observers_from_config_list(self):
        parser = make_parser()
        observers_cfg = OmegaConf.create([
            {"_target": "DummyObserver", "params": {"name": "A"}},
            {"_target": "DummyObserver", "params": {"name": "B"}},
        ])

        target = Observable()
        for obs_cfg in observers_cfg:
            obs = parser(obs_cfg)
            target.add_observer(obs)

        target.notify(DummyEvent(value=99))

        # Both observers should have received the event
        assert len(target._observers[DummyEvent]) == 2

    def test_observer_config_with_extra_keys_ignored(self):
        """ConfigParser ignores keys it doesn't know about (like 'observers')."""
        parser = make_parser()
        cfg = OmegaConf.create({
            "_target": "DummyObserver",
            "params": {"name": "x"},
            "observers": [{"_target": "DummyObserver"}],  # unknown key
        })
        obs = parser(cfg)
        assert isinstance(obs, DummyObserver)
        assert obs.name == "x"


class TestRuntimeKwargsInjection:
    def test_config_params_merged_with_runtime_kwargs(self):
        """ConfigParser merges config params with extra **kwargs passed to __call__."""
        parser = make_parser()
        cfg = OmegaConf.create({
            "_target": "DummyObserver",
        })
        # name provided as runtime kwarg instead of in config params
        obs = parser(cfg, name="injected")
        assert isinstance(obs, DummyObserver)
        assert obs.name == "injected"

    def test_runtime_kwargs_override_config_params(self):
        """Runtime kwargs take precedence when both config and kwargs specify same key."""
        parser = make_parser()
        cfg = OmegaConf.create({
            "_target": "DummyObserver",
            "params": {"name": "from_config"},
        })
        # This will cause a conflict — Python kwargs merge means runtime wins
        # Actually, ConfigParser does: cls(**kwargs, **kwargs_params) where kwargs = runtime, kwargs_params = config
        # If both have "name", Python raises TypeError for duplicate kwarg.
        # So config params and runtime kwargs should NOT overlap.
        # This test documents the expected behavior.
        with pytest.raises(TypeError):
            parser(cfg, name="from_runtime")


class TestObserverWiringPattern:
    def test_explicit_registration_from_config(self, fresh_event_bus):
        """Parse observers from config, then explicitly subscribe to bus."""
        parser = make_parser()

        observers_cfg = OmegaConf.create([
            {"_target": "DummyObserver", "params": {"name": "child_A", "scope": "train"}},
            {"_target": "DummyObserver", "params": {"name": "child_B"}},
        ])

        wired = []
        for obs_cfg in observers_cfg:
            obs = parser(obs_cfg)
            fresh_event_bus.subscribe(obs)
            wired.append(obs)

        assert len(wired) == 2
        assert wired[0].name == "child_A"
        assert wired[1].name == "child_B"

        # Emit scoped event via global bus
        fresh_event_bus.publish(DummyEvent(value=7), scope="train")
        assert wired[0].received == [7]   # scoped to train — matches
        assert wired[1].received == [7]   # wildcard — receives all

    def test_scoped_filtering_via_explicit_registration(self, fresh_event_bus):
        """Scoped observer explicitly registered skips non-matching scope."""
        parser = make_parser()

        observers_cfg = OmegaConf.create([
            {"_target": "DummyObserver", "params": {"name": "train_only", "scope": "train"}},
            {"_target": "DummyObserver", "params": {"name": "val_only", "scope": "val"}},
        ])

        wired = []
        for obs_cfg in observers_cfg:
            obs = parser(obs_cfg)
            fresh_event_bus.subscribe(obs)
            wired.append(obs)

        fresh_event_bus.publish(DummyEvent(value=1), scope="train")
        assert wired[0].received == [1]   # train_only — matches
        assert wired[1].received == []    # val_only — skipped

    def test_empty_observers_list_is_fine(self):
        """No observers configured — should work without errors."""
        target_cfg = OmegaConf.create({
            "_target": "DummyObserver",
            "params": {"name": "lonely"},
        })

        target = Observable()
        for obs_cfg in target_cfg.get("observers", []):
            pass  # no iterations

        # No observers, notify should be a no-op
        target.notify(DummyEvent(value=1))


class TestSelfInitViaEvent:
    def test_best_loss_set_via_training_began(self, fresh_event_bus):
        """PyTorchModelSaver receives TrainingBegan event after explicit subscribe."""
        from srforge.observers.checkpoint import PyTorchModelSaver
        from srforge.events.trainer import TrainingBegan

        parser = make_parser()
        cfg = OmegaConf.create({
            "_target": "PyTorchModelSaver",
        })
        saver = parser(cfg)
        fresh_event_bus.subscribe(saver)
        assert saver.best_loss is None

        fresh_event_bus.publish(TrainingBegan(
            total_epochs=100, initial_epoch=0,
            train_batches_per_epoch=10, val_batches_per_epoch=5,
            best_losses={"total": 0.123},
        ))
        assert saver.best_loss == 0.123


class TestRegisteredRunnerClasses:
    def test_training_epoch_runner_registered(self):
        from srforge.registry import ClassRegistry
        assert "TrainingEpochRunner" in ClassRegistry()

    def test_validation_epoch_runner_registered(self):
        from srforge.registry import ClassRegistry
        assert "ValidationEpochRunner" in ClassRegistry()

    def test_benchmark_runner_registered(self):
        from srforge.registry import ClassRegistry
        assert "BenchmarkRunner" in ClassRegistry()

    def test_pytorch_trainer_registered(self):
        from srforge.registry import ClassRegistry
        assert "PyTorchTrainer" in ClassRegistry()


class TestRegisteredObserverClasses:
    def test_progress_bar_registered(self):
        from srforge.registry import ClassRegistry
        assert "ProgressBar" in ClassRegistry()

    def test_loss_logger_registered(self):
        from srforge.registry import ClassRegistry
        assert "LossLogger" in ClassRegistry()

    def test_pytorch_model_saver_registered(self):
        from srforge.registry import ClassRegistry
        assert "PyTorchModelSaver" in ClassRegistry()

    def test_batch_image_logger_registered(self):
        from srforge.registry import ClassRegistry
        assert "BatchImageLogger" in ClassRegistry()

    def test_batch_image_saver_registered(self):
        from srforge.registry import ClassRegistry
        assert "BatchImageSaver" in ClassRegistry()

    def test_logits_logger_registered(self):
        from srforge.registry import ClassRegistry
        assert "LogitsLogger" in ClassRegistry()


class TestRegisteredTransformClasses:
    def test_histogram_equalize_registered(self):
        from srforge.registry import ClassRegistry
        assert "HistogramEqualize" in ClassRegistry()

    def test_clahe_registered(self):
        from srforge.registry import ClassRegistry
        assert "CLAHE" in ClassRegistry()

    def test_match_reference_registered(self):
        from srforge.registry import ClassRegistry
        assert "MatchReference" in ClassRegistry()
