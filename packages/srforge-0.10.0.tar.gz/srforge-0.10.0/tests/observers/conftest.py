import pytest


@pytest.fixture(autouse=True)
def fresh_event_bus():
    """Reset the global EventBus before each test to prevent cross-test interference."""
    from srforge import GlobalSettings, Singleton
    from srforge.observers.bus import EventBus

    gs = GlobalSettings()
    gs.event_bus = EventBus()
    yield gs.event_bus
    gs.event_bus = EventBus()
