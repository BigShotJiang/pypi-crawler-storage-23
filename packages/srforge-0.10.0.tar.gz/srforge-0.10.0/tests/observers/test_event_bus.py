"""Tests for EventBus with scope-based filtering."""

import pytest
from dataclasses import dataclass

from srforge.events.base import Event
from srforge.observers.base import Observer, Observable
from srforge.observers.bus import EventBus


# ── Test events ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class AlphaEvent(Event):
    value: int


@dataclass(frozen=True)
class BetaEvent(Event):
    value: int


# ── Test observers ───────────────────────────────────────────────────────

class AlphaObserver(Observer):
    EVENTS = [AlphaEvent]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.received = []

    def on_alpha_event(self, event: AlphaEvent):
        self.received.append(("alpha", event.value))


class BetaObserver(Observer):
    EVENTS = [BetaEvent]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.received = []

    def on_beta_event(self, event: BetaEvent):
        self.received.append(("beta", event.value))


class MultiObserver(Observer):
    """Observer that handles both event types."""
    EVENTS = [AlphaEvent, BetaEvent]

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.received = []

    def on_alpha_event(self, event: AlphaEvent):
        self.received.append(("alpha", event.value))

    def on_beta_event(self, event: BetaEvent):
        self.received.append(("beta", event.value))


# ── EventBus tests ───────────────────────────────────────────────────────

class TestEventBusBasics:
    def test_subscribe_and_publish(self):
        bus = EventBus()
        obs = AlphaObserver()
        bus.subscribe(obs)
        bus.publish(AlphaEvent(value=1))
        assert obs.received == [("alpha", 1)]

    def test_unmatched_event_type_not_delivered(self):
        bus = EventBus()
        obs = AlphaObserver()
        bus.subscribe(obs)
        bus.publish(BetaEvent(value=2))
        assert obs.received == []

    def test_multiple_observers_receive_same_event(self):
        bus = EventBus()
        obs1 = AlphaObserver()
        obs2 = AlphaObserver()
        bus.subscribe(obs1)
        bus.subscribe(obs2)
        bus.publish(AlphaEvent(value=3))
        assert obs1.received == [("alpha", 3)]
        assert obs2.received == [("alpha", 3)]

    def test_multi_event_observer(self):
        bus = EventBus()
        obs = MultiObserver()
        bus.subscribe(obs)
        bus.publish(AlphaEvent(value=1))
        bus.publish(BetaEvent(value=2))
        assert obs.received == [("alpha", 1), ("beta", 2)]


class TestEventBusScopeFiltering:
    def test_wildcard_subscriber_receives_all_scoped_events(self):
        """Observer registered without scope receives events from ANY scope."""
        bus = EventBus()
        obs = AlphaObserver()
        bus.subscribe(obs)  # no scope = wildcard
        bus.publish(AlphaEvent(value=1), scope="train")
        bus.publish(AlphaEvent(value=2), scope="val")
        assert obs.received == [("alpha", 1), ("alpha", 2)]

    def test_wildcard_subscriber_receives_scopeless_events(self):
        """Wildcard subscriber also receives scopeless (trainer-level) events."""
        bus = EventBus()
        obs = AlphaObserver()
        bus.subscribe(obs)
        bus.publish(AlphaEvent(value=1), scope=None)
        assert obs.received == [("alpha", 1)]

    def test_scoped_subscriber_receives_matching_scope(self):
        bus = EventBus()
        obs = AlphaObserver()
        bus.subscribe(obs, scope="train")
        bus.publish(AlphaEvent(value=1), scope="train")
        assert obs.received == [("alpha", 1)]

    def test_scoped_subscriber_skips_nonmatching_scope(self):
        bus = EventBus()
        obs = AlphaObserver()
        bus.subscribe(obs, scope="train")
        bus.publish(AlphaEvent(value=1), scope="val")
        assert obs.received == []

    def test_scoped_subscriber_receives_scopeless_events(self):
        """Scoped subscribers always receive scopeless (trainer-level) events."""
        bus = EventBus()
        obs = AlphaObserver()
        bus.subscribe(obs, scope="train")
        bus.publish(AlphaEvent(value=1), scope=None)
        assert obs.received == [("alpha", 1)]

    def test_multiple_scopes_as_list(self):
        bus = EventBus()
        obs = AlphaObserver()
        bus.subscribe(obs, scope=["train", "val"])
        bus.publish(AlphaEvent(value=1), scope="train")
        bus.publish(AlphaEvent(value=2), scope="val")
        bus.publish(AlphaEvent(value=3), scope="benchmark")
        assert obs.received == [("alpha", 1), ("alpha", 2)]

    def test_scoped_and_wildcard_coexist(self):
        """Scoped and wildcard subscribers on the same bus."""
        bus = EventBus()
        train_obs = AlphaObserver()
        wild_obs = AlphaObserver()
        bus.subscribe(train_obs, scope="train")
        bus.subscribe(wild_obs)  # wildcard

        bus.publish(AlphaEvent(value=1), scope="train")
        bus.publish(AlphaEvent(value=2), scope="val")

        assert train_obs.received == [("alpha", 1)]
        assert wild_obs.received == [("alpha", 1), ("alpha", 2)]


class TestEventBusErrors:
    def test_subscribe_non_observer_raises(self):
        bus = EventBus()
        with pytest.raises(TypeError, match="no __event_handlers__"):
            bus.subscribe("not an observer")

    def test_subscribe_observer_with_no_events_raises(self):
        bus = EventBus()

        class EmptyObs(Observer):
            EVENTS = []

        with pytest.raises(TypeError, match="no __event_handlers__"):
            bus.subscribe(EmptyObs())


class TestObservableBusForwarding:
    def test_observable_forwards_to_bus(self):
        """Observable.notify() forwards events to attached bus."""
        bus = EventBus()
        obs = AlphaObserver()
        bus.subscribe(obs)

        emitter = Observable()
        emitter.attach_bus(bus, scope="train")
        emitter.notify(AlphaEvent(value=42))

        assert obs.received == [("alpha", 42)]

    def test_observable_forwards_with_scope(self):
        """Bus receives events with the emitter's scope tag."""
        bus = EventBus()
        train_obs = AlphaObserver()
        val_obs = AlphaObserver()
        bus.subscribe(train_obs, scope="train")
        bus.subscribe(val_obs, scope="val")

        emitter = Observable()
        emitter.attach_bus(bus, scope="train")
        emitter.notify(AlphaEvent(value=1))

        assert train_obs.received == [("alpha", 1)]
        assert val_obs.received == []

    def test_observable_without_bus_works_normally(self):
        """Observable auto-attaches to global bus; direct add_observer adds a second path.
        Observer does NOT auto-subscribe, so only direct path fires."""
        emitter = Observable()
        obs = AlphaObserver()
        emitter.add_observer(obs)
        emitter.notify(AlphaEvent(value=5))
        # Observer only receives via direct add_observer (no auto-subscribe)
        assert obs.received == [("alpha", 5)]

    def test_direct_and_bus_observers_coexist(self):
        """Direct add_observer and bus subscription on the same Observable."""
        bus = EventBus()
        bus_obs = AlphaObserver()
        direct_obs = AlphaObserver()
        bus.subscribe(bus_obs)

        emitter = Observable()
        emitter.attach_bus(bus, scope="train")
        emitter.add_observer(direct_obs)

        emitter.notify(AlphaEvent(value=7))

        assert direct_obs.received == [("alpha", 7)]
        assert bus_obs.received == [("alpha", 7)]

    def test_scopeless_emitter_publishes_scopeless(self):
        """Observable attached with scope=None publishes scopeless events."""
        bus = EventBus()
        scoped_obs = AlphaObserver()
        bus.subscribe(scoped_obs, scope="train")

        emitter = Observable()
        emitter.attach_bus(bus, scope=None)
        emitter.notify(AlphaEvent(value=9))

        # Scopeless events always pass through to all subscribers
        assert scoped_obs.received == [("alpha", 9)]


class TestModelSaverSelfInit:
    def test_on_training_began_sets_best_loss(self):
        """PyTorchModelSaver initializes best_loss from TrainingBegan event."""
        from srforge.observers.checkpoint import PyTorchModelSaver
        from srforge.events.trainer import TrainingBegan

        saver = PyTorchModelSaver()
        assert saver.best_loss is None

        event = TrainingBegan(
            total_epochs=100,
            initial_epoch=5,
            train_batches_per_epoch=10,
            val_batches_per_epoch=5,
            best_losses={"total": 0.123, "L1": 0.1},
        )
        saver.on_training_began(event)
        assert saver.best_loss == 0.123

    def test_on_training_began_no_overwrite(self):
        """If best_loss already set, TrainingBegan does not overwrite it."""
        from srforge.observers.checkpoint import PyTorchModelSaver
        from srforge.events.trainer import TrainingBegan

        saver = PyTorchModelSaver(best_loss=0.05)
        event = TrainingBegan(
            total_epochs=100,
            initial_epoch=0,
            train_batches_per_epoch=10,
            val_batches_per_epoch=5,
            best_losses={"total": 0.999},
        )
        saver.on_training_began(event)
        assert saver.best_loss == 0.05  # unchanged

    def test_on_training_began_none_best_losses(self):
        """TrainingBegan with best_losses=None leaves best_loss as None."""
        from srforge.observers.checkpoint import PyTorchModelSaver
        from srforge.events.trainer import TrainingBegan

        saver = PyTorchModelSaver()
        event = TrainingBegan(
            total_epochs=100,
            initial_epoch=0,
            train_batches_per_epoch=10,
            val_batches_per_epoch=5,
            best_losses=None,
        )
        saver.on_training_began(event)
        assert saver.best_loss is None

    def test_saver_via_event_bus(self):
        """Full integration: PyTorchModelSaver receives TrainingBegan via EventBus."""
        from srforge.observers.checkpoint import PyTorchModelSaver
        from srforge.events.trainer import TrainingBegan

        bus = EventBus()
        saver = PyTorchModelSaver()
        bus.subscribe(saver)

        bus.publish(TrainingBegan(
            total_epochs=100,
            initial_epoch=5,
            train_batches_per_epoch=10,
            val_batches_per_epoch=5,
            best_losses={"total": 0.42},
        ))
        assert saver.best_loss == 0.42


class TestRunnerScope:
    def test_training_runner_scope(self):
        from srforge.training.runners import TrainingEpochRunner
        assert TrainingEpochRunner._scope == "train"

    def test_validation_runner_scope(self):
        from srforge.training.runners import ValidationEpochRunner
        assert ValidationEpochRunner._scope == "val"

    def test_benchmark_runner_scope(self):
        from srforge.training.runners import BenchmarkRunner
        assert BenchmarkRunner._scope == "benchmark"

    def test_scope_property(self):
        from srforge.training.runners import TrainingEpochRunner
        import torch
        runner = TrainingEpochRunner(
            optimizer=torch.optim.SGD([torch.zeros(1)], lr=0.01)
        )
        assert runner.scope == "train"


class TestExplicitRegistration:
    """Observer must be explicitly subscribed to EventBus."""

    def test_observer_not_auto_subscribed(self, fresh_event_bus):
        """Creating an observer does NOT auto-subscribe it to the global bus."""
        obs = AlphaObserver()
        fresh_event_bus.publish(AlphaEvent(value=42))
        assert obs.received == []

    def test_explicit_subscribe(self, fresh_event_bus):
        """After explicit subscribe, observer receives events."""
        obs = AlphaObserver()
        fresh_event_bus.subscribe(obs)
        fresh_event_bus.publish(AlphaEvent(value=42))
        assert obs.received == [("alpha", 42)]

    def test_subscribe_reads_scope_from_observer(self, fresh_event_bus):
        """subscribe() without explicit scope reads observer._bus_scope."""
        obs = AlphaObserver(scope="train")
        fresh_event_bus.subscribe(obs)  # no explicit scope — reads _bus_scope
        fresh_event_bus.publish(AlphaEvent(value=1), scope="train")
        fresh_event_bus.publish(AlphaEvent(value=2), scope="val")
        assert obs.received == [("alpha", 1)]

    def test_subscribe_explicit_scope_overrides(self, fresh_event_bus):
        """Explicit scope in subscribe() overrides observer._bus_scope."""
        obs = AlphaObserver(scope="train")
        fresh_event_bus.subscribe(obs, scope="val")  # override
        fresh_event_bus.publish(AlphaEvent(value=1), scope="train")
        fresh_event_bus.publish(AlphaEvent(value=2), scope="val")
        assert obs.received == [("alpha", 2)]

    def test_observer_without_scope_receives_all(self, fresh_event_bus):
        """Observer without scope receives events from any scope."""
        obs = AlphaObserver()
        fresh_event_bus.subscribe(obs)
        fresh_event_bus.publish(AlphaEvent(value=1), scope="train")
        fresh_event_bus.publish(AlphaEvent(value=2), scope="val")
        fresh_event_bus.publish(AlphaEvent(value=3))
        assert obs.received == [("alpha", 1), ("alpha", 2), ("alpha", 3)]

    def test_observable_auto_attaches(self, fresh_event_bus):
        """Observable auto-attaches to global bus on creation."""
        obs = AlphaObserver()
        fresh_event_bus.subscribe(obs)
        emitter = Observable()
        emitter.notify(AlphaEvent(value=99))
        assert obs.received == [("alpha", 99)]

    def test_observable_uses_class_scope(self, fresh_event_bus):
        """Observable uses _scope class attribute for bus scope."""

        class ScopedEmitter(Observable):
            _scope = "train"

        train_obs = AlphaObserver(scope="train")
        val_obs = AlphaObserver(scope="val")
        fresh_event_bus.subscribe(train_obs)
        fresh_event_bus.subscribe(val_obs)

        emitter = ScopedEmitter()
        emitter.notify(AlphaEvent(value=1))

        assert train_obs.received == [("alpha", 1)]
        assert val_obs.received == []

    def test_multiple_observers_explicit_subscribe(self, fresh_event_bus):
        """Multiple observers explicitly subscribed to the same bus."""
        obs1 = AlphaObserver()
        obs2 = AlphaObserver()
        obs3 = BetaObserver()
        for obs in [obs1, obs2, obs3]:
            fresh_event_bus.subscribe(obs)

        fresh_event_bus.publish(AlphaEvent(value=10))
        fresh_event_bus.publish(BetaEvent(value=20))

        assert obs1.received == [("alpha", 10)]
        assert obs2.received == [("alpha", 10)]
        assert obs3.received == [("beta", 20)]
