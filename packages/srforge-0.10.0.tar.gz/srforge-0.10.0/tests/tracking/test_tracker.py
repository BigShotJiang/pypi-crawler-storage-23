"""Tests for the experiment tracking abstraction."""

from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from srforge.tracking import ExperimentTracker, NullTracker, WandbTracker


# ── NullTracker ──────────────────────────────────────────────────────

class TestNullTracker:
    def test_is_experiment_tracker(self):
        assert isinstance(NullTracker(), ExperimentTracker)

    def test_run_properties_are_none_or_false(self):
        t = NullTracker()
        assert t.run_id is None
        assert t.run_name is None
        assert t.run_path is None
        assert t.is_resumed is False

    def test_log_metrics_noop(self):
        NullTracker().log_metrics({"loss": 0.5}, step=0)

    def test_log_image_noop(self):
        img = np.zeros((10, 10, 3), dtype=np.uint8)
        NullTracker().log_image("test", img, step=0)

    def test_set_summary_noop(self):
        NullTracker().set_summary("best", 0.1)

    def test_commit_noop(self):
        NullTracker().commit(step=0)

    def test_log_config_noop(self):
        NullTracker().log_config({"lr": 0.001})

    def test_watch_model_noop(self):
        NullTracker().watch_model(MagicMock())

    def test_save_file_noop(self):
        NullTracker().save_file("/tmp/model.pth", base_path="/tmp")

    def test_finish_noop(self):
        NullTracker().finish(0)

    def test_restore_file_raises(self):
        with pytest.raises(FileNotFoundError, match="NullTracker cannot restore"):
            NullTracker().restore_file("checkpoint_last.pth")

    def test_restore_from_run_raises(self):
        with pytest.raises(FileNotFoundError, match="from other runs"):
            NullTracker().restore_from_run("run123", "model_best.pth")


# ── WandbTracker ─────────────────────────────────────────────────────

class TestWandbTracker:
    @pytest.fixture
    def mock_wandb(self):
        with patch.dict("sys.modules", {"wandb": MagicMock()}) as mods:
            wandb = mods["wandb"]
            run = MagicMock()
            run.id = "abc123"
            run.name = "test-run"
            run.path = "entity/project/abc123"
            run.resumed = False
            run.summary = {}
            wandb.run = run
            wandb.init = MagicMock()
            wandb.log = MagicMock()
            wandb.Image = MagicMock()
            wandb.watch = MagicMock()
            wandb.save = MagicMock()
            wandb.finish = MagicMock()
            wandb.config = MagicMock()
            yield wandb

    def _make_tracker(self, mock_wandb):
        tracker = WandbTracker(project="test-project")
        mock_wandb.init.assert_called_once()
        return tracker

    def test_is_experiment_tracker(self, mock_wandb):
        tracker = self._make_tracker(mock_wandb)
        assert isinstance(tracker, ExperimentTracker)

    def test_run_properties(self, mock_wandb):
        tracker = self._make_tracker(mock_wandb)
        assert tracker.run_id == "abc123"
        assert tracker.run_name == "test-run"
        assert tracker.run_path == "entity/project/abc123"
        assert tracker.is_resumed is False

    def test_log_metrics(self, mock_wandb):
        tracker = self._make_tracker(mock_wandb)
        tracker.log_metrics({"loss": 0.5}, step=1)
        mock_wandb.log.assert_called_with({"loss": 0.5}, step=1)

    def test_log_image(self, mock_wandb):
        tracker = self._make_tracker(mock_wandb)
        img = np.zeros((10, 10, 3), dtype=np.uint8)
        tracker.log_image("pred", img, step=1)
        mock_wandb.Image.assert_called_once_with(img)
        mock_wandb.log.assert_called()

    def test_set_summary(self, mock_wandb):
        tracker = self._make_tracker(mock_wandb)
        tracker.set_summary("best_loss", 0.1)
        assert mock_wandb.run.summary["best_loss"] == 0.1

    def test_commit(self, mock_wandb):
        tracker = self._make_tracker(mock_wandb)
        tracker.commit(step=5)
        mock_wandb.log.assert_called_with({}, step=5, commit=True)

    def test_log_config(self, mock_wandb):
        tracker = self._make_tracker(mock_wandb)
        tracker.log_config({"lr": 0.001})
        mock_wandb.config.update.assert_called_once_with({"lr": 0.001})

    def test_watch_model(self, mock_wandb):
        tracker = self._make_tracker(mock_wandb)
        model = MagicMock()
        tracker.watch_model(model, log="all")
        mock_wandb.watch.assert_called_once_with(model, log="all")

    def test_save_file(self, mock_wandb):
        tracker = self._make_tracker(mock_wandb)
        tracker.save_file("/tmp/model.pth", base_path="/tmp")
        mock_wandb.save.assert_called_once_with("/tmp/model.pth", base_path="/tmp")

    def test_finish(self, mock_wandb):
        tracker = self._make_tracker(mock_wandb)
        tracker.finish(0)
        mock_wandb.finish.assert_called_once_with(0)

    def test_restore_file(self, mock_wandb):
        tracker = self._make_tracker(mock_wandb)
        restored = MagicMock()
        restored.name = "/tmp/restored/checkpoint_last.pth"
        mock_wandb.run.restore.return_value = restored
        path = tracker.restore_file("checkpoint_last.pth")
        mock_wandb.run.restore.assert_called_once_with("checkpoint_last.pth")
        assert path == "/tmp/restored/checkpoint_last.pth"

    def test_restore_file_not_found(self, mock_wandb):
        tracker = self._make_tracker(mock_wandb)
        mock_wandb.run.restore.return_value = None
        with pytest.raises(FileNotFoundError):
            tracker.restore_file("nonexistent.pth")

    def test_restore_from_run(self, mock_wandb):
        tracker = self._make_tracker(mock_wandb)
        mock_wandb.run.entity = "test-entity"
        mock_wandb.run.project = "test-project"
        mock_run = MagicMock()
        downloaded = MagicMock()
        downloaded.name = "/tmp/model_best.pth"
        mock_run.file.return_value.download.return_value = downloaded
        mock_wandb.Api.return_value.run.return_value = mock_run

        path = tracker.restore_from_run("other-run-id", "model_best.pth")

        mock_wandb.Api.return_value.run.assert_called_once_with(
            "test-entity/test-project/other-run-id"
        )
        mock_run.file.assert_called_once_with("model_best.pth")
        assert path == "/tmp/model_best.pth"


# ── Registry ─────────────────────────────────────────────────────────

class TestTrackerRegistry:
    def test_wandb_tracker_registered(self):
        from srforge.registry import ClassRegistry
        assert ClassRegistry().has("WandbTracker")

    def test_null_tracker_registered(self):
        from srforge.registry import ClassRegistry
        assert ClassRegistry().has("NullTracker")
