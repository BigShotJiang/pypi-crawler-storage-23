from __future__ import annotations


def concatBytes(a: bytes, b: bytes) -> bytes:
    return a + b
