from . import linear

from ...resources.resolve_path import resolve_path

template =  resolve_path('kenney_pirate/template.tmx')