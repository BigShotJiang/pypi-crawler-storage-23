<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="tiles_sheet" tilewidth="64" tileheight="64" tilecount="102" columns="17">
 <image source="tiles_sheet.png" width="1088" height="384"/>
 <tile id="84" type="Win"/>
 <tile id="101" type="Spawn"/>
</tileset>
