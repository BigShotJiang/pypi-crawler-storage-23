"""import_cmd command entrypoint."""

from specfact_cli.modules.import_cmd.src.commands import app


__all__ = ["app"]
