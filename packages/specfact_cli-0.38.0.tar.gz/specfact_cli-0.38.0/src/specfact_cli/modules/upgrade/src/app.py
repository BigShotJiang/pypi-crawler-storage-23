"""upgrade command entrypoint."""

from specfact_cli.modules.upgrade.src.commands import app


__all__ = ["app"]
