"""Module packages root. Packages here are discovered via metadata.yaml and registered with CommandRegistry."""
