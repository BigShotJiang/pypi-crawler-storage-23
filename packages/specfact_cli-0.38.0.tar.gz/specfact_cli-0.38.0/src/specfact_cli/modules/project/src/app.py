"""project command entrypoint."""

from specfact_cli.modules.project.src.commands import app


__all__ = ["app"]
