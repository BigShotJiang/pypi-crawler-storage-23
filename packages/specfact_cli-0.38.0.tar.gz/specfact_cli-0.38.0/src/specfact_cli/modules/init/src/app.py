"""init command entrypoint."""

from specfact_cli.modules.init.src.commands import app


__all__ = ["app"]
