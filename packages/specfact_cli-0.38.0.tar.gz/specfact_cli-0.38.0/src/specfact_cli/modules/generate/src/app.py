"""generate command entrypoint."""

from specfact_cli.modules.generate.src.commands import app


__all__ = ["app"]
