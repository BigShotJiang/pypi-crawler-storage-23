"""sdd command entrypoint."""

from specfact_cli.modules.sdd.src.commands import app


__all__ = ["app"]
