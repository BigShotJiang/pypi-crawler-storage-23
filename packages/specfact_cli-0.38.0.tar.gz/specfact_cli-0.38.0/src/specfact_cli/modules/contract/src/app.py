"""contract command entrypoint."""

from specfact_cli.modules.contract.src.commands import app


__all__ = ["app"]
