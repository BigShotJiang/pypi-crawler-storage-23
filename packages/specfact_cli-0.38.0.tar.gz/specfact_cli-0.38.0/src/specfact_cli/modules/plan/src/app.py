"""plan command entrypoint."""

from specfact_cli.modules.plan.src.commands import app


__all__ = ["app"]
