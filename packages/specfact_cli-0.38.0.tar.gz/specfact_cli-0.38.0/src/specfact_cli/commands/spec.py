"""Backward-compatible app shim. Implementation moved to modules/spec/."""

from specfact_cli.modules.spec.src.commands import app


__all__ = ["app"]
