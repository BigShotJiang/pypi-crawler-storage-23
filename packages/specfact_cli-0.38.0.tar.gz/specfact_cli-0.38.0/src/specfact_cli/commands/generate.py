"""Backward-compatible app shim. Implementation moved to modules/generate/."""

from specfact_cli.modules.generate.src.commands import app


__all__ = ["app"]
