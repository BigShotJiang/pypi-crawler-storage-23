"""Backward-compatible app shim. Implementation moved to modules/init/."""

from specfact_cli.modules.init.src.commands import app


__all__ = ["app"]
