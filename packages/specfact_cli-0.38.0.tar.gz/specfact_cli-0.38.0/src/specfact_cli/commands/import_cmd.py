"""Backward-compatible app shim. Implementation moved to modules/import_cmd/."""

from specfact_cli.modules.import_cmd.src.commands import app


__all__ = ["app"]
