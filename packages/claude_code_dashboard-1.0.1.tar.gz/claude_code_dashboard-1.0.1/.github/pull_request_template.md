## Summary

<!-- 簡述這個 PR 做了什麼 -->

## Why

<!-- 動機、對應的 Issue（例如 Closes #123） -->

## Test Plan

<!-- 如何驗證這個變更 -->

- [ ] `uv run claude-dash --plan max5` 正常運作
- [ ] 相關功能手動測試通過
