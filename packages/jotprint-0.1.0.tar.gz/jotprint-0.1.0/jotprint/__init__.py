from .core import write
