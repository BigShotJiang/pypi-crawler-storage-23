def write(*args, sep="\n"):
    print(*args, sep=sep)
