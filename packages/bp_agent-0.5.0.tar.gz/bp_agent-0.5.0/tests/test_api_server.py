import pytest

pytest.skip("api.server module removed", allow_module_level=True)
