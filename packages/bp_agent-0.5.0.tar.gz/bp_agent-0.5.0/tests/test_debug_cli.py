import pytest

pytest.skip("debug_cli module removed", allow_module_level=True)
