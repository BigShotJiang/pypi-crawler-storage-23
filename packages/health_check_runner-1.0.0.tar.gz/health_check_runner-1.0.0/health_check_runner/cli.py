"""
cli.py — Command-line entry point for health_check_runner.

Usage
-----
    healthcheck-run --template templates/mydevice.json \\
                    --sessions config/sessions.json \\
                    --env      config/envs/lab.json \\
                    [--shared  config/shared_rules.json] \\
                    [--tc TC1 --tc TC2] \\
                    [--output  table|json|junit] \\
                    [--out-file results.xml] \\
                    [--timeout 60] \\
                    [--loglevel DEBUG]

Exit code
---------
    0  all TCs passed
    1  one or more TCs failed
    2  configuration / connection error
"""

import argparse
import json
import logging
import os
import sys

from .runner import Runner


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        prog="healthcheck-run",
        description="Run JSON-driven CLI health checks.",
    )
    parser.add_argument("--template", required=True,
                        help="Path to templates/<nf>.json")
    parser.add_argument("--sessions", required=True,
                        help="Path to config/sessions.json")
    parser.add_argument("--env", required=True,
                        help="Path to config/envs/<site>.json")
    parser.add_argument("--shared", default=None,
                        help="Path to config/shared_rules.json")
    parser.add_argument("--tc", action="append", dest="tc_ids", metavar="TC_ID",
                        help="Run only these TC IDs (repeatable)")
    parser.add_argument("--output", choices=["table", "json", "junit"],
                        default="table",
                        help="Output format (default: table)")
    parser.add_argument("--out-file", dest="out_file", default=None,
                        help="Write output to this file instead of stdout")
    parser.add_argument("--timeout", type=int, default=60,
                        help="Default SSH command timeout in seconds (default: 60)")
    parser.add_argument("--loglevel",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                        default="INFO",
                        help="Log level (default: INFO)")

    args = parser.parse_args(argv)

    logging.basicConfig(
        level=getattr(logging, args.loglevel),
        format="%(asctime)s [%(levelname)s] %(message)s",
        stream=sys.stderr,
    )

    try:
        runner = Runner(
            template     = args.template,
            sessions     = args.sessions,
            env          = args.env,
            shared_rules = args.shared,
            timeout      = args.timeout,
        )
    except (FileNotFoundError, Exception) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    try:
        runner.open()
    except Exception as exc:
        print(f"ERROR opening sessions: {exc}", file=sys.stderr)
        return 2

    # For table mode: print header now, stream each TC as it finishes,
    # then print the footer.  For json/junit we must buffer the whole
    # suite before rendering, so on_tc_done is not used.
    live_table = (args.output == "table" and not args.out_file)

    if live_table:
        col_tc, col_name = 20, 50
        header = (
            f"\n  Suite: {runner.get_suite_key()}\n"
            f"  {'TC ID':<{col_tc}} {'Name':<{col_name}} {'Result':<6} {'Time':>6}\n"
            f"  {'-' * (col_tc + col_name + 14)}"
        )
        print(header, flush=True)

        def _on_tc_done(tc):
            print(tc.to_line(tc_col=col_tc, name_col=col_name), flush=True)
    else:
        _on_tc_done = None

    try:
        result = runner.run(tc_ids=args.tc_ids, on_tc_done=_on_tc_done)
    except Exception as exc:
        print(f"ERROR during run: {exc}", file=sys.stderr)
        return 2
    finally:
        runner.close()

    if live_table:
        col_tc, col_name = 20, 50
        footer = (
            f"  {'-' * (col_tc + col_name + 14)}\n"
            f"  {result.passed_count}/{result.total} passed, "
            f"{result.failed_count} failed  ({result.duration_s:.1f}s)\n"
        )
        print(footer, flush=True)
    else:
        # Buffered render for json / junit, or table written to a file
        if args.output == "table":
            output_str = result.to_table()
        elif args.output == "json":
            output_str = result.to_json()
        else:  # junit
            output_str = result.to_junit_xml()

        if args.out_file:
            with open(args.out_file, "w", encoding="utf-8") as fh:
                fh.write(output_str)
            print(f"Results written to {args.out_file}", file=sys.stderr)
        else:
            print(output_str)

    return 0 if result.failed_count == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
