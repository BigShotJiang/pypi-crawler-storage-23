"""
SshApi.py  —  Platform-independent SSH library using Paramiko.

Replaces DutApi.py (pexpect-based, Linux-only).

Key improvements over DutApi / pexpect:
  - Works on Windows and Linux  (paramiko uses pure-Python crypto + sockets)
  - Each SSH hop owns its own Paramiko SSHClient — no shared byte stream
  - Interactive shell uses idle-timeout reads, NOT prompt-regex matching
    → no buffer corruption, no leftover data bleeding into the next read
  - Multi-hop via Paramiko direct-tcpip channel (true SSH tunneling)
  - sudo / password prompts handled naturally by idle-timeout

Execution modes
---------------
  exec mode  (use_shell=False, e.g. the jump relay server)
      Execute_Command() opens a fresh exec channel each call.
      Output = pure stdout + stderr, no prompt text, no echo.

  shell mode (use_shell=True, default for all target sessions)
      Open_SSH() opens an interactive PTY shell immediately after connecting.
      Execute_Command() sends the command to the shell and reads until
      the remote side goes quiet for idle_sec seconds.
      This correctly handles sudo password prompts, sub-context CLIs,
      and long-running commands — no prompt configuration needed.

Robot Framework keyword compatibility
--------------------------------------
  Open_SSH        ip  user  password  [prompt]  [port]  [timeout]
  Execute_Command command  [timeout]
  Update_Prompt   prompt       ← no-op (idle-timeout replaces prompt matching)
  Send_Control    character    ← sends Ctrl+<char> to shell
  Close_Session   [cmd]
"""

import logging
import socket
import time
from typing import Optional

import paramiko

# Module-level stdlib fallback — replaced per-instance when a logger is injected.
_default_log = logging.getLogger("health_check_runner.ssh_api")
logging.basicConfig(level=logging.DEBUG)


def _log(msg: str, console: bool = False) -> None:   # noqa: ARG001
    _default_log.info(f"[SshApi] {msg}")


def _warn(msg: str) -> None:
    _default_log.warning(f"[SshApi] {msg}")


class SshApi:
    """
    One Paramiko SSH session.

    Instantiate with ``use_shell=True`` (default) to open an interactive PTY
    shell immediately after connecting.  All Execute_Command() calls go
    through the shell with idle-timeout reads.

    Instantiate with ``use_shell=False`` for relay/jump servers where you only
    need the transport to tunnel child connections through.
    """

    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    # ------------------------------------------------------------------ #
    #  Construction                                                        #
    # ------------------------------------------------------------------ #

    def __init__(self, timeout: int = 60, use_shell: bool = True):
        self.timeout   = int(timeout)
        self.use_shell = use_shell

        self._client:    Optional[paramiko.SSHClient]  = None
        self._transport: Optional[paramiko.Transport]  = None
        self._shell:     Optional[paramiko.Channel]    = None
        self._logger     = None   # injected MaskingLogger (optional)

    def attach_logger(self, logger) -> None:
        """Inject a logger (e.g. MaskingLogger) for this session's output."""
        self._logger = logger

    def _li(self, msg: str, console: bool = False) -> None:
        if self._logger:
            self._logger.info(f"[SshApi] {msg}", also_console=console)
        else:
            _log(msg, console)

    def _lw(self, msg: str) -> None:
        if self._logger:
            self._logger.warn(f"[SshApi] {msg}")
        else:
            _warn(msg)

    # ------------------------------------------------------------------ #
    #  Connection                                                          #
    # ------------------------------------------------------------------ #

    def Open_SSH(self,
                 ip:       str,
                 user:     str,
                 password: str,
                 prompt    = None,       # accepted for API compat, not used
                 port:     int = 22,
                 timeout:  int = None,
                 sock      = None) -> bool:
        """
        Open an SSH connection.

        Pass *sock* (a Paramiko Channel) to tunnel through a parent hop.
        *prompt* is ignored — we use idle-timeout reads instead.
        """
        t = int(timeout or self.timeout)
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            kw = dict(
                hostname=ip, username=user, password=password,
                port=int(port), timeout=t,
                allow_agent=False, look_for_keys=False,
            )
            if sock is not None:
                kw["sock"] = sock
            client.connect(**kw)
            self._client    = client
            self._transport = client.get_transport()
            self._li(f"Connected to {user}@{ip}:{port}")

            if self.use_shell:
                self._open_shell()

            return True
        except Exception as exc:
            self._lw(f"Open_SSH failed for {user}@{ip}: {exc}")
            return False

    def open_channel_to(self, dest_ip: str, dest_port: int = 22) -> paramiko.Channel:
        """
        Open a direct-tcpip tunnel channel through this session's transport.
        Pass the returned channel as *sock* to a child SshApi.Open_SSH().
        """
        if self._transport is None:
            raise RuntimeError("[SshApi] open_channel_to: no active transport")
        return self._transport.open_channel(
            "direct-tcpip",
            (dest_ip, int(dest_port)),
            ("127.0.0.1", 0),
        )

    # ------------------------------------------------------------------ #
    #  Command execution                                                   #
    # ------------------------------------------------------------------ #

    def Execute_Command(self, command: str, timeout: int = None,
                        output=None, **_kwargs) -> str:
        """
        Execute *command* and return its output.

        Shell mode  : sends to PTY, reads until idle.
        Exec mode   : opens a fresh exec channel (clean stdout+stderr).
        The *output* parameter is accepted for backward-compatibility and
        is ignored — we always read the full output.
        """
        t = int(timeout or self.timeout)
        if self._shell is not None:
            return self._shell_execute(command, t)
        return self._exec_execute(command, t)

    def _exec_execute(self, command: str, timeout: int) -> str:
        if self._client is None:
            raise RuntimeError("[SshApi] not connected")
        try:
            _, stdout, stderr = self._client.exec_command(command, timeout=timeout)
            stdout.channel.settimeout(timeout)
            out = stdout.read().decode("utf-8", errors="replace")
            err = stderr.read().decode("utf-8", errors="replace")
            return (out + err).rstrip("\r\n")
        except Exception as exc:
            raise RuntimeError(f"[SshApi] exec_command failed: {exc}") from exc

    def _shell_execute(self, command: str, timeout: int) -> str:
        if self._shell is None:
            raise RuntimeError("[SshApi] shell not open")
        self._shell.send(command + "\n")
        # Brief sleep lets the remote start producing output before the
        # idle timer begins — prevents a false-idle on slow CLIs (e.g. AMOS).
        time.sleep(0.5)
        # idle_sec: wait this long after last byte before declaring done.
        # Higher for long-running commands (AMOS cvcu, lt all, etc.).
        idle_sec = 3 if timeout <= 30 else (5 if timeout <= 90 else 8)
        return self._read_until_idle(idle_sec=idle_sec, max_sec=timeout)

    # ------------------------------------------------------------------ #
    #  Interactive shell helpers                                           #
    # ------------------------------------------------------------------ #

    def _open_shell(self, width: int = 2000, height: int = 80):
        chan = self._client.invoke_shell(width=width, height=height)
        chan.settimeout(0.2)
        self._shell = chan
        # Drain login banner / MOTD
        self._read_until_idle(idle_sec=1.5, max_sec=8)
        self._li("Interactive shell opened")

    @property
    def is_shell(self) -> bool:
        return self._shell is not None

    def _read_until_idle(self, idle_sec: float, max_sec: float) -> str:
        """
        Read from the interactive shell until no new bytes arrive for
        *idle_sec* seconds, or *max_sec* total has elapsed.

        This completely replaces prompt-regex matching:
          - Works regardless of prompt format
          - Cannot leave partial data in a buffer (drains everything available)
          - Handles sudo password prompts and long-running commands automatically
        """
        buf       = b""
        deadline  = time.time() + max_sec
        last_recv = time.time()

        while time.time() < deadline:
            try:
                chunk = self._shell.recv(8192)
                if chunk:
                    buf += chunk
                    last_recv = time.time()
                else:
                    break   # channel closed
            except socket.timeout:
                pass
            if buf and (time.time() - last_recv) >= idle_sec:
                break

        return buf.decode("utf-8", errors="replace")

    # ------------------------------------------------------------------ #
    #  Control characters                                                  #
    # ------------------------------------------------------------------ #

    def Update_Prompt(self, prompt):
        """No-op — kept for API compatibility.  Idle-timeout is used."""
        pass

    def Send_Control(self, character: str = "c") -> str:
        """Send Ctrl+<character> to the interactive shell."""
        if self._shell is None:
            self._lw("Send_Control: no interactive shell open")
            return ""
        ctrl = chr(ord(character.lower()) - ord("a") + 1)
        self._shell.send(ctrl)
        time.sleep(0.3)
        return self._read_until_idle(idle_sec=1.0, max_sec=5)

    # ------------------------------------------------------------------ #
    #  Teardown                                                            #
    # ------------------------------------------------------------------ #

    def Close_Shell(self):
        """Close only the interactive shell; keep the transport alive."""
        if self._shell:
            try:
                self._shell.send("exit\n")
                time.sleep(0.2)
                self._shell.close()
            except Exception:
                pass
            self._shell = None
            self._li("Shell closed")

    def Close_Session(self, cmd: str = "exit") -> bool:
        """Close shell (if any) then the SSH connection."""
        self.Close_Shell()
        if self._client:
            try:
                self._client.close()
            except Exception:
                pass
            self._client    = None
            self._transport = None
        self._li("Session closed")
        return True
