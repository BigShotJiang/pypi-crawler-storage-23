"""
pytest_plugin.py — pytest fixture helpers for health_check_runner.

Usage
-----
    # conftest.py
    from health_check_runner.integrations.pytest_plugin import make_suite_fixture

    bbu = make_suite_fixture(
        template="templates/mydevice.json",
        sessions="config/sessions.json",
        env="config/envs/lab.json",
    )

    # test_bbu.py
    import pytest

    @pytest.mark.parametrize("tc_id", [
        "TC1", "TC1-CLI-ALT", "TC2-CLI", "TC3-CLI"
    ])
    def test_bbu(bbu, tc_id):
        result = bbu.run_tc(tc_id)
        assert result.passed, result.failure_summary()

    # Or run the whole suite and inspect:
    def test_bbu_full(bbu):
        suite = bbu.run()
        failed = suite.failed_tcs()
        assert not failed, "\\n".join(
            f"{tc.tc_id}: {tc.failure_summary()}" for tc in failed
        )
"""

from typing import List, Optional
from ..runner import Runner


def make_suite_fixture(
    template:     str,
    sessions:     str,
    env:          str,
    shared_rules: Optional[str] = None,
    timeout:      int           = 60,
    secrets:      Optional[List[str]] = None,
    scope:        str           = "session",
):
    """
    Factory that returns a pytest fixture with the requested scope.

    The returned fixture opens SSH sessions once (per scope) and yields
    a live Runner.  Sessions are closed automatically after all tests
    in the scope have finished.

    Parameters
    ----------
    template        Path to templates/<nf>.json
    sessions        Path to config/sessions.json
    env             Path to config/envs/<site>.json
    shared_rules    Path to config/shared_rules.json (optional)
    timeout         Default SSH command timeout in seconds
    secrets         Extra strings to redact from logs
    scope           pytest fixture scope: "session", "module", or "function"
    """

    import pytest  # noqa: PLC0415 — lazy import, pytest is an optional dependency

    @pytest.fixture(scope=scope)
    def _runner_fixture():
        runner = Runner(
            template     = template,
            sessions     = sessions,
            env          = env,
            shared_rules = shared_rules,
            timeout      = timeout,
            secrets      = secrets or [],
        )
        runner.open()
        yield runner
        runner.close()

    return _runner_fixture


def parametrize_tcs(template: str):
    """
    Decorator that parametrizes a test function with all TC IDs from
    the given template file.

    Usage:
        @parametrize_tcs("templates/mydevice.json")
        def test_bbu(bbu, tc_id):
            result = bbu.run_tc(tc_id)
            assert result.passed, result.failure_summary()
    """
    import json, os, pytest  # noqa: PLC0415

    def decorator(fn):
        with open(os.path.abspath(template), encoding="utf-8") as fh:
            tpl = json.load(fh)
        tc_ids = [tc["id"] for tc in tpl.get("test_cases", [])]
        return pytest.mark.parametrize("tc_id", tc_ids)(fn)

    return decorator
