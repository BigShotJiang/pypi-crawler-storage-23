"""
robot_keywords.py — Thin Robot Framework keyword wrapper.

Imports robot.api lazily so the package does not depend on robotframework
at import time.  Only loaded when used inside a Robot Framework run.

Usage in a .robot file:

    Library    health_check_runner.integrations.robot_keywords
    ...        template_path=${CURDIR}/../templates/mydevice.json
    ...        sessions_path=${CURDIR}/../config/sessions.json
    ...        env_path=${CURDIR}/../config/envs/lab.json
    ...        shared_rules_path=${CURDIR}/../config/shared_rules.json
    ...        timeout=600

    Suite Setup      Open Suite Sessions    mydevice_suite
    Suite Teardown   Close Suite Sessions   mydevice_suite

Keyword API (drop-in replacement for HealthCheckJsonParser.py)
--------------------------------------------------------------
    Open Suite Sessions    suite_key
    Close Suite Sessions   suite_key
    Run JSON Test Case     suite_key   tc_id
    Get JSON Variable      dot.path
"""

from typing import Optional
from .._logger import RobotLogger, MaskingLogger
from ..runner import Runner


class RobotKeywords:
    """
    Robot Framework library class.
    All RF coupling is contained here; the core engine has no RF imports.
    """

    ROBOT_LIBRARY_SCOPE      = "SUITE"
    ROBOT_LIBRARY_DOC_FORMAT = "reST"

    def __init__(
        self,
        template_path:     str = "templates/mme.json",
        sessions_path:     str = "config/sessions.json",
        env_path:          str = "config/envs/lab.json",
        shared_rules_path: Optional[str] = "config/shared_rules.json",
        timeout:           int = 600,
    ):
        # Build a MaskingLogger that wraps the RF logger
        rf_log          = RobotLogger()
        self._masking   = MaskingLogger(rf_log)
        self._runner    = Runner(
            template     = template_path,
            sessions     = sessions_path,
            env          = env_path,
            shared_rules = shared_rules_path,
            timeout      = int(timeout),
            logger       = self._masking,
        )
        # Register env passwords as secrets
        for sess_data in self._runner._env_doc.get("sessions", {}).values():
            pwd = sess_data.get("password", "")
            if pwd:
                self._masking.register_secret(pwd)

    # ------------------------------------------------------------------ #
    #  Keywords                                                            #
    # ------------------------------------------------------------------ #

    def open_suite_sessions(self, suite_key: str) -> None:
        """Connect all sessions in the suite's default_chain."""
        self._runner.open()

    def close_suite_sessions(self, suite_key: str) -> None:
        """Disconnect all sessions in reverse order."""
        self._runner.close()

    def run_json_test_case(self, suite_key: str, tc_id: str) -> None:
        """
        Execute one TC.  Failures are raised as Robot Framework failures.
        Soft failures (continue_on_failure=true) trigger
        run_keyword_and_continue_on_failure so the TC is marked FAIL but
        execution continues.
        """
        from robot.libraries.BuiltIn import BuiltIn  # noqa: PLC0415

        result = self._runner.run_tc(tc_id)

        if not result.passed:
            n = len(result.failures)
            BuiltIn().run_keyword_and_continue_on_failure(
                "Fail",
                f"{n} validation(s) failed:\n" + "\n".join(result.failures),
            )

    def get_json_variable(self, dot_path: str) -> str:
        """Return a template value by dot-notation path."""
        return self._runner._resolve(f"${{{dot_path}}}")

    # Backward-compatible snake_case aliases used by older suite files
    Open_Suite_Sessions  = open_suite_sessions
    Close_Suite_Sessions = close_suite_sessions
    Run_JSON_Test_Case   = run_json_test_case
    Get_JSON_Variable    = get_json_variable
