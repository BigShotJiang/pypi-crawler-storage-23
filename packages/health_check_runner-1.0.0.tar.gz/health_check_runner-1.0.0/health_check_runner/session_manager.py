"""
session_manager.py — Multi-hop SSH session lifecycle manager.

Completely decoupled from Robot Framework.
Accepts any logger that implements .info() / .debug() / .warn().

Connection types
----------------
  direct         SSH directly to the target (e.g. jump server)
  ssh_from       SSH through a parent session's transport channel
  amos_from      New SSH to parent's server + AMOS CLI init sequence
  command_from   Enter a sub-context on parent's shell (no new SSH)
  su_from        Escalate to root on parent's shell (no new SSH)
"""

import re
import socket as _socket
from typing import Callable, Dict, List, Optional

import paramiko

from .ssh_api import SshApi
from ._logger import StdlibLogger, MaskingLogger


class SessionManager:
    """
    Manages named SSH sessions.

    Each direct / ssh_from / amos_from session owns its own SshApi instance.
    su_from and command_from sessions delegate execution to a parent's SshApi.
    """

    def __init__(
        self,
        sessions_def: dict,
        resolve_fn: Callable[[str], str],
        default_timeout: int = 60,
        logger=None,
    ):
        self._defs      = sessions_def
        self._resolve   = resolve_fn
        self._default_t = int(default_timeout)
        self._log       = logger or StdlibLogger()
        self._active:   Dict[str, bool]   = {}
        self._apis:     Dict[str, SshApi] = {}
        self._delegs:   Dict[str, str]    = {}

    # ------------------------------------------------------------------ #
    #  Public                                                              #
    # ------------------------------------------------------------------ #

    def connect(self, session_id: str) -> None:
        if self._active.get(session_id):
            self._log.debug(f"[SM] connect({session_id}) — already active")
            return

        defn      = self._get_def(session_id)
        conn_type = defn.get("connection", "ssh_from")
        label     = defn.get("label", "")
        tag       = f"[{session_id}]" + (f" ({label})" if label else "")
        self._log.info(f"[SM] Connecting {tag}  type={conn_type}")

        parent_id = defn.get("parent")
        if parent_id and not self._active.get(parent_id):
            self._log.debug(f"[SM]   auto-connecting parent '{parent_id}'")
            self.connect(parent_id)

        {
            "direct":       self._connect_direct,
            "ssh_from":     self._connect_ssh_from,
            "amos_from":    self._connect_amos_from,
            "command_from": self._connect_command_from,
            "su_from":      self._connect_su_from,
        }.get(conn_type, self._unknown_type)(session_id, defn)

        self._active[session_id] = True
        self._log.info(f"[SM] Connected   {tag}")

    def disconnect(self, session_id: str) -> None:
        if not self._active.get(session_id):
            self._log.warn(f"[SM] disconnect({session_id}) — not active")
            return

        defn      = self._get_def(session_id)
        conn_type = defn.get("connection", "ssh_from")

        if conn_type == "direct":
            api = self._apis.pop(session_id, None)
            if api:
                api.Close_Session()

        elif conn_type == "ssh_from":
            api = self._apis.pop(session_id, None)
            if api:
                try:
                    api.Execute_Command("exit", timeout=5)
                except Exception:
                    pass
                api.Close_Session()

        elif conn_type == "amos_from":
            api = self._apis.pop(session_id, None)
            if api:
                exit_cmd = self._resolve(defn.get("amos_exit", {}).get("command", "exit"))
                try:
                    api.Execute_Command(exit_cmd, timeout=10)
                except Exception:
                    pass
                api.Close_Session()

        elif conn_type in ("command_from", "su_from"):
            parent_id = self._delegs.pop(session_id, None)
            if parent_id:
                parent_api = self._apis.get(parent_id)
                if parent_api:
                    exit_cmd = self._resolve(defn.get("exit_command", "exit"))
                    try:
                        parent_api.Execute_Command(exit_cmd, timeout=10)
                    except Exception:
                        pass

        self._active[session_id] = False
        self._log.info(f"[SM] Disconnected [{session_id}]")

    def execute(self, session_id: str, command: str, **kwargs) -> str:
        if not self._active.get(session_id):
            raise RuntimeError(
                f"Session '{session_id}' is not active — "
                f"add it to default_chain or use an ssh_connect step."
            )
        timeout   = kwargs.get("timeout")
        target_id = self._delegs.get(session_id, session_id)
        api       = self._apis.get(target_id)
        if api is None:
            raise RuntimeError(f"[SM] No SshApi for session '{target_id}'")

        self._log.debug(f"[SM]   exec [{session_id}] $ {command[:120]}")
        try:
            return api.Execute_Command(command, timeout=timeout)
        except Exception as exc:
            if not self._is_connection_error(exc):
                raise
            self._log.warn(f"[SM] [{session_id}] connection error: {exc} — reconnecting")
            self._reconnect(session_id)
            target_id = self._delegs.get(session_id, session_id)
            api = self._apis[target_id]
            self._log.info(f"[SM] [{session_id}] reconnected — replaying: {command[:80]}")
            return api.Execute_Command(command, timeout=timeout)

    def send_control(self, session_id: str, key: str = "c") -> str:
        target_id = self._delegs.get(session_id, session_id)
        api = self._apis.get(target_id)
        return api.Send_Control(key) if api else ""

    def connect_chain(self, chain: List[str]) -> None:
        self._log.info(f"[SM] Connecting chain: {chain}")
        for sid in chain:
            if not self._active.get(sid):
                self.connect(sid)

    def disconnect_chain(self, chain: List[str]) -> None:
        self._log.info(f"[SM] Disconnecting chain (reversed): {list(reversed(chain))}")
        for sid in reversed(chain):
            if self._active.get(sid):
                self.disconnect(sid)

    # ------------------------------------------------------------------ #
    #  Connection type implementations                                     #
    # ------------------------------------------------------------------ #

    def _connect_direct(self, session_id: str, defn: dict) -> None:
        ip      = self._resolve(defn["ip"])
        user    = self._resolve(defn["username"])
        timeout = int(defn.get("timeout", self._default_t))
        self._log.info(f"[SM]   direct SSH → {user}@{ip}  timeout={timeout}s")
        api = self._make_api(timeout=timeout, use_shell=False)
        if not api.Open_SSH(ip, user, self._resolve(defn["password"]),
                            port=int(defn.get("port", 22))):
            raise RuntimeError(f"Direct SSH failed for '{session_id}' → {ip}")
        self._apis[session_id] = api

    def _connect_ssh_from(self, session_id: str, defn: dict) -> None:
        ip         = self._resolve(defn.get("ip") or defn.get("ip_alias", ""))
        user       = self._resolve(defn["username"])
        port       = int(defn.get("port", 22))
        timeout    = int(defn.get("timeout", self._default_t))
        parent_id  = defn.get("parent")
        parent_api = self._apis.get(parent_id)
        sock       = parent_api.open_channel_to(ip, port) if parent_api else None
        self._log.info(f"[SM]   ssh {user}@{ip} via '{parent_id}'  timeout={timeout}s")
        api = self._make_api(timeout=timeout, use_shell=True)
        if not api.Open_SSH(ip, user, self._resolve(defn["password"]),
                            port=port, sock=sock):
            raise RuntimeError(f"SSH failed for '{session_id}' → {ip}")
        verify = defn.get("verify_after_login")
        if verify:
            vout = api.Execute_Command(self._resolve(verify["command"]), timeout=15)
            vexp = self._resolve(verify["expect_contains"])
            if vexp in vout:
                self._log.info(f"[SM]   post-login check PASSED: '{vexp}'")
            else:
                self._log.warn(f"[SM]   post-login check FAILED: '{vexp}' not in output")
        self._apis[session_id] = api

    def _connect_amos_from(self, session_id: str, defn: dict) -> None:
        parent_id      = defn["parent"]
        parent_defn    = self._defs[parent_id]
        gp_id          = parent_defn.get("parent")
        gp_api         = self._apis.get(gp_id)
        ip             = self._resolve(parent_defn.get("ip") or parent_defn.get("ip_alias", ""))
        user           = self._resolve(parent_defn["username"])
        port           = int(parent_defn.get("port", 22))
        timeout        = int(defn.get("timeout", self._default_t))
        sock           = gp_api.open_channel_to(ip, port) if gp_api else None
        self._log.info(f"[SM]   AMOS: new SSH → {user}@{ip} via '{gp_id}'  timeout={timeout}s")
        api = self._make_api(timeout=timeout, use_shell=True)
        if not api.Open_SSH(ip, user, self._resolve(parent_defn["password"]),
                            port=port, sock=sock):
            raise RuntimeError(f"AMOS SSH failed for '{session_id}' → {ip}")
        for i, step in enumerate(defn.get("amos_init", []), 1):
            cmd       = self._resolve(step["command"])
            t         = int(step.get("timeout", timeout))
            forbidden = step.get("should_not_contain")
            self._log.debug(f"[SM]   AMOS init step {i}: '{cmd}'  timeout={t}s")
            out = api.Execute_Command(cmd, timeout=t)
            if forbidden and forbidden in out:
                raise RuntimeError(
                    f"AMOS init '{cmd}' returned forbidden string: '{forbidden}'"
                )
        self._log.info("[SM]   AMOS session ready")
        self._apis[session_id] = api

    def _connect_command_from(self, session_id: str, defn: dict) -> None:
        parent_id  = defn["parent"]
        parent_api = self._apis.get(parent_id)
        if parent_api is None:
            raise RuntimeError(f"Parent '{parent_id}' not connected for '{session_id}'")
        enter_cmd = self._resolve(defn["enter_command"])
        self._log.info(f"[SM]   entering sub-context '{session_id}' via '{enter_cmd}'")
        parent_api.Execute_Command(enter_cmd, timeout=int(defn.get("timeout", 15)))
        self._delegs[session_id] = parent_id

    def _connect_su_from(self, session_id: str, defn: dict) -> None:
        parent_id  = defn["parent"]
        parent_api = self._apis.get(parent_id)
        if parent_api is None:
            raise RuntimeError(f"Parent '{parent_id}' not connected for '{session_id}'")
        su_cmd = self._resolve(defn.get("su_command", "su - root"))
        self._log.info(f"[SM]   su escalation via '{su_cmd}'")
        parent_api.Execute_Command(su_cmd, timeout=10)
        parent_api.Execute_Command(self._resolve(defn.get("password", "")),
                                   timeout=int(defn.get("timeout", 30)))
        self._delegs[session_id] = parent_id

    def _unknown_type(self, session_id: str, defn: dict) -> None:
        raise ValueError(
            f"Unknown connection type '{defn.get('connection')}' for '{session_id}'"
        )

    # ------------------------------------------------------------------ #
    #  Reconnect-on-failure                                                #
    # ------------------------------------------------------------------ #

    def _is_connection_error(self, exc: Exception) -> bool:
        if isinstance(exc, (paramiko.SSHException, _socket.error, EOFError, OSError)):
            return True
        if isinstance(exc, RuntimeError):
            msg = str(exc).lower()
            return any(kw in msg for kw in
                       ("not connected", "channel", "transport", "eof", "socket", "ssh"))
        return False

    def _reconnect(self, session_id: str) -> None:
        owner_id   = self._delegs.get(session_id, session_id)
        dependents = [s for s, p in self._delegs.items() if p == owner_id]
        self._log.warn(f"[SM] Reconnecting '{owner_id}'")
        api = self._apis.pop(owner_id, None)
        if api:
            try:
                api.Close_Session()
            except Exception:
                pass
        self._active[owner_id] = False
        for dep in dependents:
            self._active[dep] = False
            self._delegs.pop(dep, None)
        self.connect(owner_id)
        for dep in dependents:
            self.connect(dep)
        self._log.info(f"[SM] '{owner_id}' reconnected successfully")

    # ------------------------------------------------------------------ #
    #  Helpers                                                             #
    # ------------------------------------------------------------------ #

    def _make_api(self, timeout: int, use_shell: bool) -> SshApi:
        api = SshApi(timeout=timeout, use_shell=use_shell)
        api.attach_logger(self._log)
        return api

    def _get_def(self, session_id: str) -> dict:
        defn = self._defs.get(session_id)
        if defn is None:
            available = [k for k in self._defs if not k.startswith("_")]
            raise KeyError(
                f"Unknown session '{session_id}'. Available: {available}"
            )
        return defn
