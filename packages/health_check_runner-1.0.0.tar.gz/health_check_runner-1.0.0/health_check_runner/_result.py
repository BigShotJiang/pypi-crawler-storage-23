"""
_result.py — Structured result objects returned by Runner.

  StepResult    Output from a single execute step.
  TCResult      Outcome of one test case (steps + validations).
  SuiteResult   Aggregated outcome of a full suite run.

SuiteResult.to_dict()       → JSON-serialisable dict
SuiteResult.to_junit_xml()  → JUnit XML string (Jenkins / GitLab CI / GitHub Actions)
"""

import json
import textwrap
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional


def _format_tc_row(tc: "TCResult", tc_col: int = 20, name_col: int = 50) -> str:
    """
    Render one TCResult as one or more aligned terminal lines.

    Rules
    -----
    * TC name is hard-wrapped at name_col characters.  The first segment
      shares the line with tc_id / status / time; overflow segments appear
      on continuation lines indented to the name column.
    * Failure messages strip the leading "[Engine] " tag and are wrapped
      to fit within the total table width (tc_col + name_col + 14 chars),
      each prefixed with "    ! " and continuation lines indented to match.
    """
    status    = "PASS" if tc.passed else "FAIL"
    time_str  = f"{tc.duration_s:>5.1f}s"
    total_w   = tc_col + name_col + 14          # matches separator width
    name_indent = " " * (2 + tc_col + 1)        # align under the Name column

    # Split the TC name into name_col-wide chunks
    name_chunks = textwrap.wrap(tc.name, width=name_col) or [""]

    # First line: tc_id | first name chunk | status | time
    lines = [
        f"  {tc.tc_id:<{tc_col}} {name_chunks[0]:<{name_col}} {status:<6} {time_str}"
    ]
    # Continuation lines for a long name (no status/time — they already appeared)
    for chunk in name_chunks[1:]:
        lines.append(f"{name_indent}{chunk}")

    # Failure messages
    fail_prefix    = "    ! "
    fail_cont      = "      "   # same width as "    ! "
    for msg in tc.failures:
        clean = msg.removeprefix("[Engine] ")
        wrapped = textwrap.fill(
            clean,
            width            = total_w,
            initial_indent   = fail_prefix,
            subsequent_indent= fail_cont,
            break_long_words = True,
            break_on_hyphens = False,
        )
        lines.append(wrapped)

    return "\n".join(lines)


@dataclass
class StepResult:
    index:      int
    action:     str
    session_id: str
    command:    str
    output:     str
    duration_s: float
    error:      Optional[str] = None


@dataclass
class TCResult:
    tc_id:      str
    name:       str
    passed:     bool
    duration_s: float
    failures:   List[str]            = field(default_factory=list)
    captured:   Dict[str, str]       = field(default_factory=dict)
    steps:      List[StepResult]     = field(default_factory=list)

    def failure_summary(self) -> str:
        return "\n".join(self.failures) if self.failures else ""

    def to_line(self, tc_col: int = 20, name_col: int = 50) -> str:
        """
        One or more terminal lines printed as soon as the TC finishes.
        Long TC names wrap onto continuation lines; failure messages are
        wrapped to fit within the table's total width.

          TC1-CLI-ALT          Check Alarms (alt)                        FAIL   5.6s
            ! Number of alarms greater than 0
        """
        return _format_tc_row(self, tc_col=tc_col, name_col=name_col)


@dataclass
class SuiteResult:
    suite_key:  str
    started_at: datetime
    duration_s: float
    tcs:        List[TCResult] = field(default_factory=list)

    # ------------------------------------------------------------------ #
    #  Convenience properties                                              #
    # ------------------------------------------------------------------ #

    @property
    def passed_count(self) -> int:
        return sum(1 for tc in self.tcs if tc.passed)

    @property
    def failed_count(self) -> int:
        return sum(1 for tc in self.tcs if not tc.passed)

    @property
    def total(self) -> int:
        return len(self.tcs)

    def passed_tcs(self) -> List[TCResult]:
        return [tc for tc in self.tcs if tc.passed]

    def failed_tcs(self) -> List[TCResult]:
        return [tc for tc in self.tcs if not tc.passed]

    def summary(self) -> str:
        return (
            f"Suite '{self.suite_key}': "
            f"{self.passed_count}/{self.total} passed, "
            f"{self.failed_count} failed  ({self.duration_s:.1f}s)"
        )

    # ------------------------------------------------------------------ #
    #  Serialisation                                                       #
    # ------------------------------------------------------------------ #

    def to_dict(self) -> dict:
        return {
            "suite_key":  self.suite_key,
            "started_at": self.started_at.isoformat(),
            "duration_s": round(self.duration_s, 3),
            "passed":     self.passed_count,
            "failed":     self.failed_count,
            "total":      self.total,
            "test_cases": [
                {
                    "id":         tc.tc_id,
                    "name":       tc.name,
                    "passed":     tc.passed,
                    "duration_s": round(tc.duration_s, 3),
                    "failures":   tc.failures,
                    "captured":   tc.captured,
                    "steps": [
                        {
                            "index":      s.index,
                            "action":     s.action,
                            "session_id": s.session_id,
                            "command":    s.command,
                            "duration_s": round(s.duration_s, 3),
                            "error":      s.error,
                        }
                        for s in tc.steps
                    ],
                }
                for tc in self.tcs
            ],
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    def to_junit_xml(self) -> str:
        """
        JUnit XML — consumed by Jenkins, GitLab CI, GitHub Actions, etc.

        Each TCResult becomes a <testcase>.  Failures appear as <failure>
        children.  The suite appears as a <testsuite> root element.
        """
        root = ET.Element(
            "testsuite",
            name=self.suite_key,
            tests=str(self.total),
            failures=str(self.failed_count),
            time=f"{self.duration_s:.3f}",
            timestamp=self.started_at.isoformat(),
        )

        for tc in self.tcs:
            tc_el = ET.SubElement(
                root, "testcase",
                name=tc.name,
                classname=self.suite_key,
                time=f"{tc.duration_s:.3f}",
            )
            if not tc.passed:
                fail_el = ET.SubElement(
                    tc_el, "failure",
                    message=tc.failures[0] if tc.failures else "FAILED",
                )
                fail_el.text = "\n".join(tc.failures)

        ET.indent(root, space="  ")
        return ET.tostring(root, encoding="unicode", xml_declaration=True)

    def to_table(self, tc_col: int = 20, name_col: int = 50) -> str:
        """Plain-text result table for terminal output."""
        sep = "  " + "-" * (tc_col + name_col + 14)
        lines = [
            "",
            f"  Suite: {self.suite_key}",
            f"  {'TC ID':<{tc_col}} {'Name':<{name_col}} {'Result':<6} {'Time':>6}",
            sep,
        ]
        for tc in self.tcs:
            lines.append(_format_tc_row(tc, tc_col=tc_col, name_col=name_col))
        lines += [
            sep,
            f"  {self.passed_count}/{self.total} passed, "
            f"{self.failed_count} failed  ({self.duration_s:.1f}s)",
            "",
        ]
        return "\n".join(lines)
