"""
_logger.py — Pluggable logger abstraction.

Three concrete implementations:

  StdlibLogger   Default. Uses Python stdlib logging.
  RobotLogger    Wraps robot.api.logger — used by the RF keyword layer.
  MaskingLogger  Wraps any Logger and redacts registered secret strings.
                 Credentials in commands / output never appear in logs.
"""

import logging
from typing import List, Optional


class StdlibLogger:
    """Default logger — Python stdlib logging."""

    def __init__(self, name: str = "health_check_runner", level: int = logging.DEBUG):
        logging.basicConfig(
            level=level,
            format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        )
        self._log = logging.getLogger(name)

    def info(self, msg: str, also_console: bool = False) -> None:
        self._log.info(msg)

    def debug(self, msg: str) -> None:
        self._log.debug(msg)

    def warn(self, msg: str) -> None:
        self._log.warning(msg)


class RobotLogger:
    """
    Thin wrapper around robot.api.logger.
    Imported lazily so the package does not depend on robotframework
    at import time — only when used inside a Robot Framework run.
    """

    def __init__(self):
        from robot.api import logger as _rf  # noqa: PLC0415
        self._rf = _rf

    def info(self, msg: str, also_console: bool = False) -> None:
        self._rf.info(msg, also_console=also_console)

    def debug(self, msg: str) -> None:
        self._rf.debug(msg)

    def warn(self, msg: str) -> None:
        self._rf.warn(msg)


class MaskingLogger:
    """
    Wraps any Logger and replaces every registered secret string with '***'
    before the message reaches the underlying logger.

    Usage:
        logger = MaskingLogger(StdlibLogger())
        logger.register_secret(password)
        # password will never appear in any log line
    """

    def __init__(self, base, secrets: Optional[List[str]] = None):
        self._base = base
        self._secrets: List[str] = [s for s in (secrets or []) if s]

    def register_secret(self, secret: str) -> None:
        """Add a string that will be redacted in all future log messages."""
        if secret and secret not in self._secrets:
            self._secrets.append(secret)

    def _mask(self, text: str) -> str:
        for s in self._secrets:
            text = text.replace(s, "***")
        return text

    def info(self, msg: str, also_console: bool = False) -> None:
        self._base.info(self._mask(msg), also_console=also_console)

    def debug(self, msg: str) -> None:
        self._base.debug(self._mask(msg))

    def warn(self, msg: str) -> None:
        self._base.warn(self._mask(msg))
