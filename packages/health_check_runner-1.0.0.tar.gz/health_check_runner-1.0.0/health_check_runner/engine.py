"""
engine.py — Core TC execution and validation engine.

No Robot Framework dependency.  All RF coupling lives in
integrations/robot_keywords.py.

Validation types supported
--------------------------
String / structural
  assert_contains          assert_not_contains        assert_equal
  assert_contains_any      assert_line_count_equal    assert_line_count_gte
  for_each_line            lines_containing           all_lines_match_any
  section_lines_contain_any

Extraction
  regex_extract            regex_line_match            regex_findall
  string_extract           string_extract_between      extract_between
  extract_between_parens   split_extract               fetch_between
  split_field_assert       split_fields_numeric_gt

Numeric
  assert_numeric_lt        assert_numeric_gt           assert_greater_than
  strip_percent_and_assert_lte

Network-specific
  unlocked_must_be_enabled  verify_ping_ipv4  verify_ping_ipv6
  version_in_active_partition

Date
  date_diff_assert_lte      last_line_date_diff

XML
  xml_xpath

JSON
  json_extract

Informational
  log_output                store_nf_version
"""

import json as _json
import re
import time
import xml.etree.ElementTree as ET
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from ._logger import StdlibLogger
from ._result import StepResult, TCResult
from .session_manager import SessionManager


class Engine:
    """
    Executes test cases defined in the JSON template format.

    Instantiate with a SessionManager that already has open sessions,
    plus the merged template / sessions / env data and shared rules.
    """

    def __init__(
        self,
        sm: SessionManager,
        template: dict,
        vars_store: Dict[str, str],
        shared_rules: dict,
        logger=None,
    ):
        self._sm      = sm
        self._tpl     = template
        self._vars    = vars_store
        self._shared  = shared_rules
        self._log     = logger or StdlibLogger()

    # ------------------------------------------------------------------ #
    #  Public                                                              #
    # ------------------------------------------------------------------ #

    def run_tc(self, suite_key: str, tc_id: str) -> TCResult:
        suite = self._get_suite(suite_key)
        tc    = self._find_tc(suite, tc_id)
        if tc is None:
            raise KeyError(f"TC '{tc_id}' not found in suite '{suite_key}'")

        tc_name  = tc.get("name", tc_id)
        t_start  = time.monotonic()
        captured: Dict[str, Any] = {}
        step_results: List[StepResult] = []
        failures:     List[str]        = []

        self._log.info(f"[Engine] >> {tc_id} — {tc_name}")

        # ---- steps --------------------------------------------------------
        steps = tc.get("steps", [])
        for i, step in enumerate(steps, 1):
            action     = step.get("action", "")
            session_id = step.get("on", "—")
            self._log.info(
                f"[Engine]   Step {i}/{len(steps)}: action={action}  on={session_id}"
            )
            step_result = self._execute_step(step, captured)
            if step_result:
                step_results.append(step_result)

        # ---- validations --------------------------------------------------
        validations = tc.get("validations", [])
        passed_v = 0
        for i, rule in enumerate(validations, 1):
            vtype = rule.get("type", "?")
            self._log.debug(
                f"[Engine]   Validation {i}/{len(validations)}: type={vtype}"
            )
            try:
                self._validate(rule, captured)
                passed_v += 1
            except AssertionError as exc:
                if rule.get("continue_on_failure", False):
                    self._log.warn(f"[Engine]   SOFT FAIL ({vtype}): {exc}")
                    failures.append(str(exc))
                else:
                    self._log.warn(f"[Engine]   HARD FAIL ({vtype}): {exc}")
                    failures.append(str(exc))
                    duration = time.monotonic() - t_start
                    return TCResult(
                        tc_id=tc_id, name=tc_name, passed=False,
                        duration_s=duration, failures=failures,
                        captured={k: str(v) for k, v in captured.items()
                                  if isinstance(v, (str, int, float))},
                        steps=step_results,
                    )

        duration = time.monotonic() - t_start
        passed   = len(failures) == 0

        self._log.info(
            f"[Engine]   Validations: {passed_v} passed, {len(failures)} soft-failed"
        )
        self._log.info(f"[Engine] {'OK' if passed else 'FAIL'}  {tc_id} — {tc_name}")

        return TCResult(
            tc_id=tc_id, name=tc_name, passed=passed,
            duration_s=duration, failures=failures,
            captured={k: str(v) for k, v in captured.items()
                      if isinstance(v, (str, int, float))},
            steps=step_results,
        )

    # ------------------------------------------------------------------ #
    #  Step dispatcher                                                     #
    # ------------------------------------------------------------------ #

    def _execute_step(
        self, step: dict, captured: Dict[str, Any]
    ) -> Optional[StepResult]:
        action     = step.get("action", "")
        session_id = step.get("on")

        if not session_id and action not in ("sleep",):
            raise ValueError(f"[Engine] Step missing 'on' field: {step}")

        if action == "ssh_connect":
            self._sm.connect(session_id)
            return None

        if action == "ssh_disconnect":
            self._sm.disconnect(session_id)
            return None

        if action == "execute":
            cmd    = self._resolve(step.get("command", ""))
            kwargs: Dict[str, Any] = {}
            if step.get("timeout"):
                kwargs["timeout"] = int(step["timeout"])

            t0  = time.monotonic()
            out = self._sm.execute(session_id, cmd, **kwargs)
            dur = time.monotonic() - t0

            self._log.debug(f"[Engine]     output preview: {out[:200].strip()!r}")
            self._log.info(f"[Engine] [{session_id}] $ {cmd}\n{out}")

            # Inline checks
            for field, should_fail in (
                ("should_not_contain", lambda p, o: p in o),
                ("expect_contains",   lambda p, o: p not in o),
            ):
                phrase = step.get(field)
                if phrase:
                    phrase = self._resolve(phrase)
                    if should_fail(phrase, out):
                        msg = (f"Command '{cmd}' on [{session_id}]: "
                               f"{field} check failed for '{phrase}'")
                        if step.get("continue_on_failure", False):
                            self._log.warn(f"[Engine] {msg}")
                        else:
                            raise AssertionError(f"[Engine] {msg}")

            cap = step.get("capture_as")
            if cap:
                captured[cap] = out
                self._log.debug(f"[Engine]     captured as '{cap}'  ({len(out)} chars)")

            return StepResult(
                index=0, action=action, session_id=session_id,
                command=cmd, output=out, duration_s=dur,
            )

        if action == "send_control":
            result = self._sm.send_control(session_id, step.get("key", "c"))
            cap = step.get("capture_as")
            if cap:
                captured[cap] = result
            return None

        if action == "sleep":
            time.sleep(float(step.get("seconds", 1)))
            return None

        if action in ("update_prompt", "set_context"):
            return None   # no-op in idle-timeout mode

        self._log.warn(f"[Engine] Unknown step action '{action}' — skipped")
        return None

    # ------------------------------------------------------------------ #
    #  Validation dispatcher                                               #
    # ------------------------------------------------------------------ #

    def _validate(self, rule: dict, captured: Dict[str, Any]) -> None:
        vtype  = rule.get("type", "")
        source = rule.get("source", "output")
        text   = str(captured.get(source, ""))
        cont   = rule.get("continue_on_failure", False)

        dispatch = {
            "assert_contains":               self._v_assert_contains,
            "assert_not_contains":           self._v_assert_not_contains,
            "assert_equal":                  self._v_assert_equal,
            "assert_greater_than":           self._v_assert_greater_than,
            "assert_contains_any":           self._v_assert_contains_any,
            "assert_line_count_equal":       self._v_line_count_equal,
            "assert_line_count_gte":         self._v_line_count_gte,
            "regex_extract":                 self._v_regex_extract,
            "regex_line_match":              self._v_regex_extract,
            "regex_findall":                 self._v_regex_findall,
            "string_extract":                self._v_string_extract,
            "string_extract_between":        self._v_string_extract_between,
            "for_each_line":                 self._v_for_each_line,
            "extract_between_parens":        self._v_extract_between_parens,
            "extract_between":               self._v_extract_between,
            "date_diff_assert_lte":          self._v_date_diff,
            "verify_ping_ipv4":              lambda r, c, t, k: self._v_ping(t, False, k),
            "verify_ping_ipv6":              lambda r, c, t, k: self._v_ping(t, True, k),
            "strip_percent_and_assert_lte":  self._v_strip_percent,
            "unlocked_must_be_enabled":      self._v_unlocked_port,
            "split_extract":                 self._v_split_extract,
            "assert_numeric_lt":             self._v_assert_numeric_lt,
            "assert_numeric_gt":             self._v_assert_numeric_gt,
            "split_field_assert":            self._v_split_field_assert,
            "split_fields_numeric_gt":       self._v_split_fields_numeric_gt,
            "lines_containing":              self._v_lines_containing,
            "last_line_date_diff":           self._v_last_line_date_diff,
            "fetch_between":                 self._v_fetch_between,
            "section_lines_contain_any":     self._v_section_lines_contain_any,
            "all_lines_match_any":           self._v_all_lines_match_any,
            "version_in_active_partition":   self._v_version_in_active_partition,
            "xml_xpath":                     self._v_xml_xpath,
            "json_extract":                  self._v_json_extract,
            "store_nf_version":              lambda r, c, t, k: self._store_nf_version(r, c),
            "log_output":                    lambda r, c, t, k: self._log.info(
                                                 f"[Engine] OUTPUT ({source}):\n{t}"),
        }
        fn = dispatch.get(vtype)
        if fn:
            fn(rule, captured, text, cont)
        else:
            self._log.warn(f"[Engine] Unknown validation type '{vtype}' — skipped")

    # ------------------------------------------------------------------ #
    #  String / structural validators                                      #
    # ------------------------------------------------------------------ #

    def _v_assert_contains(self, r, c, text, cont):
        self._assert_contains(
            self._resolve(r.get("value", text)),
            self._resolve(r["expected"]),
            r.get("message"), cont,
        )

    def _v_assert_not_contains(self, r, c, text, cont):
        val = self._resolve(r.get("value", text))
        exp = self._resolve(r["expected"])
        if exp in val:
            self._fail(r.get("message", f"Output should NOT contain '{exp}'"), cont)

    def _v_assert_equal(self, r, c, text, cont):
        exp = self._resolve(str(r["expected"]))
        val = self._resolve(str(r.get("value", text))).strip()
        if val != exp:
            self._fail(r.get("message", f"Expected '{exp}' but got '{val}'"), cont)

    def _v_assert_greater_than(self, r, c, text, cont):
        threshold = float(r["threshold"])
        val = float(self._resolve(str(r.get("value", text))).strip())
        if not val > threshold:
            self._fail(f"{val} is not > {threshold}", cont)

    def _v_assert_contains_any(self, r, c, text, cont):
        candidates = r.get("expected", [])
        if not any(self._resolve(c_) in text for c_ in candidates):
            self._fail(r.get("message", f"None of {candidates} found"), cont)

    def _v_line_count_equal(self, r, c, text, cont):
        count = len([l for l in text.splitlines() if l.strip()])
        exp   = int(r["expected"])
        if count != exp:
            self._fail(r.get("message", f"Expected {exp} lines, got {count}"), cont)

    def _v_line_count_gte(self, r, c, text, cont):
        count = len([l for l in text.splitlines() if l.strip()])
        exp   = int(r["expected"])
        if count < exp:
            self._fail(r.get("message", f"Expected >= {exp} lines, got {count}"), cont)

    # ------------------------------------------------------------------ #
    #  Extraction validators                                               #
    # ------------------------------------------------------------------ #

    def _v_regex_extract(self, rule, captured, text, cont):
        pattern = rule["pattern"]
        matches = re.findall(pattern, text)
        cap     = rule.get("capture_as")
        if not matches:
            self._fail(f"Pattern '{pattern}' matched nothing", cont)
            return
        value = matches[0]
        for split_key in ("split_on", "extract_on"):
            split_on = rule.get(split_key)
            if split_on:
                idx   = int(rule.get("split_index", rule.get("index", 1)))
                parts = value.split(split_on)
                value = parts[idx].strip() if idx < len(parts) else value
        if rule.get("strip_prefix"):
            value = value.replace(rule["strip_prefix"], "").strip()
        if rule.get("extract_after") and rule["extract_after"] in value:
            value = value.split(rule["extract_after"], 1)[1].strip()
        if cap:
            captured[cap] = value
        if "assert_equal" in rule:
            exp = self._resolve(str(rule["assert_equal"]))
            if value.strip() != exp:
                self._fail(rule.get("message", f"Expected '{exp}' got '{value}'"), cont)
        if "assert_contains" in rule:
            self._assert_contains(value, self._resolve(rule["assert_contains"]),
                                  rule.get("message"), cont)
        if "for_each_line" in rule:
            for line in value.splitlines():
                self._validate({**rule["for_each_line"],
                                "value": line, "source": "__line__"}, captured)

    def _v_regex_findall(self, rule, captured, text, cont):
        matches = re.findall(rule["pattern"], text, re.DOTALL)
        cap = rule.get("capture_as")
        if cap:
            captured[cap] = matches
        for_each     = rule.get("for_each", [])
        at_least_one = rule.get("at_least_one")
        found_one    = False
        for item in matches:
            for sub in (for_each if isinstance(for_each, list) else []):
                self._validate({**sub, "value": item, "source": "__item__"}, captured)
            if at_least_one:
                try:
                    self._validate(
                        {**at_least_one, "value": item, "source": "__item__"}, captured)
                    found_one = True
                except AssertionError:
                    pass
        if at_least_one and not found_one and matches:
            self._fail(at_least_one.get("message", "at_least_one condition not met"), cont)

    def _v_string_extract(self, rule, captured, text, cont):
        value = text
        if rule.get("split_on") and rule["split_on"] in value:
            value = value.split(rule["split_on"])[int(rule.get("split_index", 1))]
        if rule.get("split_on_2") and rule["split_on_2"] in value:
            value = value.split(rule["split_on_2"])[int(rule.get("split_index_2", 0))]
        value = value.strip()
        if rule.get("capture_as"):
            captured[rule["capture_as"]] = value
        if "assert_equal" in rule:
            exp = self._resolve(str(rule["assert_equal"]))
            if value != exp:
                self._fail(rule.get("message", f"Expected '{exp}' got '{value}'"), cont)

    def _v_string_extract_between(self, rule, captured, text, cont):
        start, end = rule["start_marker"], rule["end_marker"]
        if start in text and end in text:
            extracted = text.split(start)[1].split(end)[0]
        else:
            extracted = ""
            self._fail(f"Markers not found: '{start}'/'{end}'", cont)
        if rule.get("capture_as"):
            captured[rule["capture_as"]] = extracted

    def _v_for_each_line(self, rule, captured, text, cont):
        lines    = [l for l in text.splitlines() if l.strip()][int(rule.get("skip_lines", 0)):]
        expected = rule.get("assert_contains")
        inner    = cont or rule.get("continue_on_failure", False)
        for line in lines:
            if expected:
                try:
                    self._assert_contains(line, self._resolve(expected),
                                          rule.get("message"), inner)
                except AssertionError as exc:
                    self._log.warn(f"[Engine] for_each_line: {exc}")
            else:
                sub = rule.get("sub_rule", rule)
                try:
                    self._validate({**sub, "value": line, "source": "__line__"}, captured)
                except AssertionError as exc:
                    if inner:
                        self._log.warn(f"[Engine] for_each_line: {exc}")
                    else:
                        raise

    def _v_extract_between_parens(self, rule, captured, text, cont):
        field = rule.get("field_match") or rule.get("field")
        m     = re.search(rf"{re.escape(field)}.*?\(([^)]+)\)", text)
        if not m:
            self._fail(f"Field '{field}' not found", cont)
            return
        value = m.group(1).strip()
        if rule.get("capture_as"):
            captured[rule["capture_as"]] = value
        if "assert_equal" in rule:
            exp = self._resolve(str(rule["assert_equal"]))
            if value != exp:
                self._fail(rule.get("message",
                           f"{field}: expected '{exp}' got '{value}'"), cont)

    def _v_extract_between(self, rule, captured, text, cont):
        start = rule.get("start", rule.get("start_marker", ""))
        end   = rule.get("end",   rule.get("end_marker",   ""))
        if start in text and end in text:
            extracted = text.split(start)[1].split(end)[0]
        else:
            extracted = ""
            self._fail(f"Markers not found: '{start}'/'{end}'", cont)
        if rule.get("capture_as"):
            captured[rule["capture_as"]] = extracted

    def _v_split_extract(self, rule, captured, text, cont):
        value = text
        for token, idx in rule.get("split", []):
            if token in value:
                parts = value.split(token)
                value = parts[idx] if idx < len(parts) else value
        value = value.strip()
        if rule.get("capture_as"):
            captured[rule["capture_as"]] = value
        if "assert_equal" in rule:
            exp = self._resolve(str(rule["assert_equal"]))
            if value != exp:
                self._fail(rule.get("message", f"Expected '{exp}' got '{value}'"), cont)

    def _v_fetch_between(self, rule, captured, text, cont):
        after = rule.get("after", "")
        if after not in text:
            self._fail(f"'after' marker not found: '{after}'", cont)
            return
        segment = text.split(after, 1)[1]
        before  = rule.get("before", "")
        if before and before in segment:
            segment = segment.split(before, 1)[0]
        if rule.get("capture_as"):
            captured[rule["capture_as"]] = segment.strip()

    def _v_split_field_assert(self, rule, captured, text, cont):
        parts = text.split(rule.get("split_by", " "))
        idx   = int(rule.get("field_index", 0))
        value = parts[idx].strip() if idx < len(parts) else ""
        if "assert_contains" in rule:
            self._assert_contains(value, self._resolve(rule["assert_contains"]),
                                  rule.get("message"), cont)
        if "assert_contains_any" in rule:
            if not any(c in value for c in rule["assert_contains_any"]):
                self._fail(rule.get("message",
                    f"'{value}' not in {rule['assert_contains_any']}"), cont)

    def _v_split_fields_numeric_gt(self, rule, captured, text, cont):
        parts     = text.split(rule.get("split_by", " "))
        fr_s, fr_e = rule.get("field_range", [0, 0])
        threshold = float(rule.get("threshold", 0))
        for i in range(fr_s, min(fr_e + 1, len(parts))):
            try:
                val = float(parts[i].strip())
            except (ValueError, IndexError):
                continue
            if val <= threshold:
                self._fail(rule.get("message",
                    f"Field[{i}]={val} not > {threshold}"), cont)

    def _v_lines_containing(self, rule, captured, text, cont):
        contains = rule["contains"]
        matched  = [l for l in text.splitlines() if contains in l]
        if rule.get("capture_as"):
            captured[rule["capture_as"]] = "\n".join(matched)
        n = len(matched)
        if "assert_line_count_gte" in rule and n < int(rule["assert_line_count_gte"]):
            self._fail(rule.get("message",
                f"Expected >= {rule['assert_line_count_gte']} lines "
                f"containing '{contains}', got {n}"), cont)
        if "assert_line_count_equal" in rule and n != int(rule["assert_line_count_equal"]):
            self._fail(rule.get("message",
                f"Expected {rule['assert_line_count_equal']} lines "
                f"containing '{contains}', got {n}"), cont)
        if "assert_line_count_gt" in rule and n <= int(rule["assert_line_count_gt"]):
            self._fail(rule.get("message",
                f"Expected > {rule['assert_line_count_gt']} lines "
                f"containing '{contains}', got {n}"), cont)

    def _v_section_lines_contain_any(self, rule, captured, text, cont):
        after, before = rule.get("after", ""), rule.get("before", "")
        segment = text.split(after, 1)[1] if after in text else text
        if before and before in segment:
            segment = segment.split(before, 1)[0]
        lines = [l for l in segment.splitlines() if l.strip()]
        if rule.get("pattern"):
            lines = [l for l in lines if re.search(rule["pattern"], l)]
        expected_any = rule.get("assert_contains_any", [])
        if any(any(c in l for c in expected_any) for l in lines):
            return
        self._fail(rule.get("message",
            f"No line in section '{after}'…'{before}' "
            f"contains any of {expected_any}"), cont)

    def _v_all_lines_match_any(self, rule, captured, text, cont):
        patterns = rule.get("patterns", [])
        for line in [l for l in text.splitlines() if l.strip()]:
            if not any(p in line for p in patterns):
                self._fail(rule.get("message",
                    f"Line does not match any of {patterns}: '{line}'"), cont)

    # ------------------------------------------------------------------ #
    #  Numeric validators                                                  #
    # ------------------------------------------------------------------ #

    def _v_assert_numeric_lt(self, rule, captured, text, cont):
        try:
            val = float(text.strip())
        except ValueError:
            self._fail(f"Cannot convert '{text}' to float", cont)
            return
        if val >= float(rule["threshold"]):
            self._fail(rule.get("message", f"{val} is not < {rule['threshold']}"), cont)

    def _v_assert_numeric_gt(self, rule, captured, text, cont):
        try:
            val = float(text.strip())
        except ValueError:
            self._fail(f"Cannot convert '{text}' to float", cont)
            return
        if val <= float(rule["threshold"]):
            self._fail(rule.get("message", f"{val} is not > {rule['threshold']}"), cont)

    def _v_strip_percent(self, rule, captured, text, cont):
        val = float(text.replace("%", "").strip())
        if val > float(rule["threshold"]):
            self._fail(f"Usage {val}% exceeds threshold {rule['threshold']}%", cont)

    # ------------------------------------------------------------------ #
    #  Network-specific validators                                         #
    # ------------------------------------------------------------------ #

    def _v_unlocked_port(self, rule, captured, text, cont):
        for line in text.splitlines():
            if "(UNLOCKED)" in line and "(ENABLED)" not in line:
                chunk = line.split("(UNLOCKED)")[1].split("Transport")[0].strip()
                if chunk:
                    self._fail(
                        f"Unlocked port not enabled "
                        f"[{rule.get('context','')}]: {line}", cont)

    def _v_ping(self, text: str, ipv6: bool, cont: bool) -> None:
        key   = "verify_ping_ipv6" if ipv6 else "verify_ping_ipv4"
        rules = self._shared.get(key, {}).get("assert_all", [])
        for sub in rules:
            try:
                self._validate({**sub, "value": text, "source": "__ping__"}, {})
            except AssertionError as exc:
                if cont or sub.get("continue_on_failure", False):
                    self._log.warn(f"[Engine] ping: {exc}")
                else:
                    raise

    def _v_version_in_active_partition(self, rule, captured, text, cont):
        expected = self._resolve(rule.get("expected", ""))
        for line in text.splitlines():
            if "active" in line.lower() and expected in line:
                return
        self._fail(rule.get("message",
            f"Version '{expected}' not found in active partition"), cont)

    # ------------------------------------------------------------------ #
    #  Date validators                                                     #
    # ------------------------------------------------------------------ #

    def _v_date_diff(self, rule, captured, text, cont):
        threshold = int(rule.get("threshold_days", 31))
        sep       = rule.get("date_separator", "T")
        fi        = int(rule.get("field_index", 3))
        now       = datetime.now()
        for line in text.splitlines():
            if "BACKUP" not in line:
                continue
            parts = line.split("|")
            if fi >= len(parts):
                continue
            raw = parts[fi].replace(sep, " ").strip()
            try:
                ts = datetime.strptime(raw[:19], "%Y-%m-%d %H:%M:%S")
            except ValueError:
                continue
            days = abs((now - ts).days)
            if days > threshold:
                self._fail(rule.get("message",
                    f"Backup '{raw}' is {days} days old "
                    f"(threshold {threshold})"), cont)

    def _v_last_line_date_diff(self, rule, captured, text, cont):
        lines = [l for l in text.splitlines() if l.strip()]
        if not lines:
            self._fail("No lines for date diff", cont)
            return
        sep       = rule.get("separator", "|")
        date_fmt  = rule.get("date_format", "%Y-%m-%dT%H:%M:%SZ")
        fi        = rule.get("date_field", "last")
        threshold = int(rule.get("assert_days_lte", 31))
        parts     = lines[-1].split(sep)
        raw       = (parts[-1] if fi == "last" else parts[int(fi)]).strip()
        try:
            ts = datetime.strptime(raw, date_fmt)
        except ValueError:
            self._fail(f"Cannot parse date '{raw}'", cont)
            return
        days = abs((datetime.now() - ts).days)
        if days > threshold:
            self._fail(rule.get("message",
                f"Date '{raw}' is {days} days old (threshold {threshold})"), cont)

    # ------------------------------------------------------------------ #
    #  XML validator                                                       #
    # ------------------------------------------------------------------ #

    def _v_xml_xpath(self, rule: dict, captured: dict, text: str, cont: bool) -> None:
        xpath = rule.get("xpath", "")
        if not xpath:
            self._fail("xml_xpath: 'xpath' field is required", cont)
            return
        xml_text = self._extract_xml_body(text)
        if not xml_text:
            self._fail(f"xml_xpath: no XML found in source '{rule.get('source')}'", cont)
            return
        xml_clean = self._strip_xml_namespaces(xml_text)
        try:
            root = ET.fromstring(xml_clean)
        except ET.ParseError as exc:
            self._fail(f"xml_xpath: XML parse error: {exc}", cont)
            return
        try:
            matches = root.findall(xpath)
        except Exception as exc:
            self._fail(f"xml_xpath: invalid XPath '{xpath}': {exc}", cont)
            return
        count = len(matches)
        self._log.debug(f"[Engine]   xml_xpath '{xpath}' → {count} match(es)")
        if "assert_count_equal" in rule:
            n = int(rule["assert_count_equal"])
            if count != n:
                self._fail(rule.get("message",
                    f"xml_xpath '{xpath}': expected {n} match(es), got {count}"), cont)
        if "assert_count_gte" in rule:
            n = int(rule["assert_count_gte"])
            if count < n:
                self._fail(rule.get("message",
                    f"xml_xpath '{xpath}': expected >= {n} match(es), got {count}"), cont)
        needs_value = any(k in rule for k in (
            "capture_as", "assert_equal", "assert_contains",
            "assert_not_contains", "assert_numeric_lt", "assert_numeric_gt"))
        if count == 0:
            if needs_value:
                self._fail(rule.get("message",
                    f"xml_xpath '{xpath}': no match — cannot extract value"), cont)
            return
        idx  = int(rule.get("index", 0))
        if idx >= count:
            self._fail(f"xml_xpath '{xpath}': index {idx} out of range "
                       f"({count} match(es))", cont)
            return
        elem = matches[idx]
        attr = rule.get("attribute")
        if attr:
            value = elem.get(attr)
            if value is None:
                self._fail(rule.get("message",
                    f"xml_xpath '{xpath}': attribute '{attr}' not found"), cont)
                return
        else:
            value = "".join(elem.itertext()).strip()
        self._log.debug(f"[Engine]   xml_xpath value = {value!r}")
        if rule.get("capture_as"):
            captured[rule["capture_as"]] = value
        if "assert_equal" in rule:
            exp = self._resolve(str(rule["assert_equal"]))
            if value != exp:
                self._fail(rule.get("message",
                    f"xml_xpath '{xpath}': expected '{exp}', got '{value}'"), cont)
        if "assert_contains" in rule:
            exp = self._resolve(str(rule["assert_contains"]))
            if exp not in value:
                self._fail(rule.get("message",
                    f"xml_xpath '{xpath}': '{exp}' not in '{value}'"), cont)
        if "assert_not_contains" in rule:
            exp = self._resolve(str(rule["assert_not_contains"]))
            if exp in value:
                self._fail(rule.get("message",
                    f"xml_xpath '{xpath}': should not contain '{exp}'"), cont)
        if "assert_numeric_lt" in rule:
            try:
                fval = float(value)
            except ValueError:
                self._fail(f"xml_xpath '{xpath}': cannot convert '{value}' to float", cont)
                return
            if fval >= float(rule["assert_numeric_lt"]):
                self._fail(rule.get("message",
                    f"xml_xpath '{xpath}': {fval} is not < {rule['assert_numeric_lt']}"), cont)
        if "assert_numeric_gt" in rule:
            try:
                fval = float(value)
            except ValueError:
                self._fail(f"xml_xpath '{xpath}': cannot convert '{value}' to float", cont)
                return
            if fval <= float(rule["assert_numeric_gt"]):
                self._fail(rule.get("message",
                    f"xml_xpath '{xpath}': {fval} is not > {rule['assert_numeric_gt']}"), cont)

    # ------------------------------------------------------------------ #
    #  JSON validator                                                      #
    # ------------------------------------------------------------------ #

    def _v_json_extract(self, rule: dict, captured: dict, text: str, cont: bool) -> None:
        """
        Parse JSON from source, navigate a dot-notation path, assert / capture.

        Path syntax
        -----------
        "status"             → data["status"]
        "result.code"        → data["result"]["code"]
        "items.0.name"       → data["items"][0]["name"]
        "items.*.status"     → [item["status"] for item in data["items"]]
                               (captures list; use assert_each_contains to check)

        Rule fields
        -----------
        path                 Dot-notation path (required)
        capture_as           Store extracted value in captured dict
        assert_equal         Exact string/number match
        assert_contains      Substring in string value
        assert_not_contains  Substring absent
        assert_numeric_lt    Float < threshold
        assert_numeric_gt    Float > threshold
        assert_count_gte     List length >= n  (for wildcard paths)
        assert_each_contains Each item in list contains string
        """
        path = rule.get("path", "")
        if not path:
            self._fail("json_extract: 'path' field is required", cont)
            return

        json_text = self._extract_json_body(text)
        if not json_text:
            self._fail(f"json_extract: no JSON found in source '{rule.get('source')}'", cont)
            return

        try:
            data = _json.loads(json_text)
        except _json.JSONDecodeError as exc:
            self._fail(f"json_extract: JSON parse error: {exc}", cont)
            return

        try:
            value = self._json_path_get(data, path)
        except (KeyError, IndexError, TypeError) as exc:
            self._fail(rule.get("message",
                f"json_extract: path '{path}' not found: {exc}"), cont)
            return

        self._log.debug(f"[Engine]   json_extract '{path}' → {str(value)[:80]!r}")

        if rule.get("capture_as"):
            captured[rule["capture_as"]] = (
                _json.dumps(value) if isinstance(value, (dict, list)) else str(value)
            )

        # List-specific assertions (wildcard path returns list)
        if isinstance(value, list):
            if "assert_count_gte" in rule:
                n = int(rule["assert_count_gte"])
                if len(value) < n:
                    self._fail(rule.get("message",
                        f"json_extract '{path}': expected >= {n} items, "
                        f"got {len(value)}"), cont)
            if "assert_each_contains" in rule:
                exp = self._resolve(str(rule["assert_each_contains"]))
                for item in value:
                    if exp not in str(item):
                        self._fail(rule.get("message",
                            f"json_extract '{path}': item {item!r} "
                            f"does not contain '{exp}'"), cont)
            return

        # Scalar assertions
        str_val = str(value)
        if "assert_equal" in rule:
            exp = self._resolve(str(rule["assert_equal"]))
            if str_val != exp:
                self._fail(rule.get("message",
                    f"json_extract '{path}': expected '{exp}', got '{str_val}'"), cont)
        if "assert_contains" in rule:
            exp = self._resolve(str(rule["assert_contains"]))
            if exp not in str_val:
                self._fail(rule.get("message",
                    f"json_extract '{path}': '{exp}' not in '{str_val}'"), cont)
        if "assert_not_contains" in rule:
            exp = self._resolve(str(rule["assert_not_contains"]))
            if exp in str_val:
                self._fail(rule.get("message",
                    f"json_extract '{path}': should not contain '{exp}'"), cont)
        if "assert_numeric_lt" in rule:
            try:
                fval = float(value)
            except (ValueError, TypeError):
                self._fail(f"json_extract '{path}': cannot convert '{value}' to float",
                           cont)
                return
            if fval >= float(rule["assert_numeric_lt"]):
                self._fail(rule.get("message",
                    f"json_extract '{path}': {fval} is not < "
                    f"{rule['assert_numeric_lt']}"), cont)
        if "assert_numeric_gt" in rule:
            try:
                fval = float(value)
            except (ValueError, TypeError):
                self._fail(f"json_extract '{path}': cannot convert '{value}' to float",
                           cont)
                return
            if fval <= float(rule["assert_numeric_gt"]):
                self._fail(rule.get("message",
                    f"json_extract '{path}': {fval} is not > "
                    f"{rule['assert_numeric_gt']}"), cont)

    # ------------------------------------------------------------------ #
    #  Misc                                                                #
    # ------------------------------------------------------------------ #

    def _store_nf_version(self, rule: dict, captured: dict) -> None:
        """
        In standalone mode, emits an INFO log instead of calling the
        RF 'insert nf version' keyword.
        Override this method in the RF keyword wrapper to call BuiltIn().
        """
        value = captured.get(rule.get("value_from", ""), rule.get("value", ""))
        self._log.info(
            f"[Engine] store_nf_version: core={rule.get('core')} "
            f"app={rule.get('application')} fqdn={rule.get('fqdn')} "
            f"value={value}"
        )

    # ------------------------------------------------------------------ #
    #  XML helpers                                                         #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _extract_xml_body(text: str) -> str:
        idx = text.rfind("<?xml")
        if idx != -1:
            return text[idx:].strip()
        m = re.search(r"<[A-Za-z]", text)
        return text[m.start():].strip() if m else ""

    @staticmethod
    def _strip_xml_namespaces(xml_text: str) -> str:
        s = re.sub(r'\s+xmlns(?::\w+)?="[^"]*"', "", xml_text)
        s = re.sub(r"(</?)\w+:", r"\1", s)
        s = re.sub(r"(?<=[\s])\w+:(\w+=)", r"\1", s)
        return s

    # ------------------------------------------------------------------ #
    #  JSON helpers                                                        #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _extract_json_body(text: str) -> str:
        """
        Extract the first complete JSON object or array from raw text.
        Handles curl -v output, HTTP headers, shell prompts.

        Strategy: find whichever of '{' or '[' appears first in the text,
        then walk forward counting open/close brackets to find the matching
        end character, returning only the balanced JSON document.  This
        avoids rfind cutting into the middle of nested objects.
        """
        pairs = (("{", "}"), ("[", "]"))
        candidates = [(text.find(sc), sc, ec) for sc, ec in pairs if text.find(sc) != -1]
        if not candidates:
            return ""
        # Use the start character that appears earliest in the text
        _, start_char, end_char = min(candidates, key=lambda t: t[0])
        idx = text.find(start_char)
        depth    = 0
        in_str   = False
        escape   = False
        for i, ch in enumerate(text[idx:], idx):
            if escape:
                escape = False
                continue
            if ch == "\\" and in_str:
                escape = True
                continue
            if ch == '"':
                in_str = not in_str
                continue
            if in_str:
                continue
            if ch == start_char:
                depth += 1
            elif ch == end_char:
                depth -= 1
                if depth == 0:
                    return text[idx: i + 1]
        return ""

    @staticmethod
    def _json_path_get(data: Any, path: str) -> Any:
        """
        Navigate a dot-notation path through a JSON structure.

          "a.b.c"   → data["a"]["b"]["c"]
          "items.0" → data["items"][0]
          "items.*" → [item for item in data["items"]]   (wildcard)
        """
        parts   = path.split(".")
        current = data
        for i, part in enumerate(parts):
            if part == "*":
                if not isinstance(current, list):
                    raise TypeError(f"Wildcard '*' requires a list at '{'.'.join(parts[:i])}'")
                remaining = ".".join(parts[i + 1:])
                if remaining:
                    return [Engine._json_path_get(item, remaining) for item in current]
                return current
            elif isinstance(current, list):
                try:
                    current = current[int(part)]
                except (ValueError, IndexError) as exc:
                    raise IndexError(
                        f"Cannot access index '{part}' on list at "
                        f"'{'.'.join(parts[:i])}'"
                    ) from exc
            elif isinstance(current, dict):
                if part not in current:
                    raise KeyError(
                        f"Key '{part}' not found at '{'.'.join(parts[:i])}'. "
                        f"Available: {list(current.keys())}"
                    )
                current = current[part]
            else:
                raise TypeError(
                    f"Cannot navigate '{part}' on {type(current).__name__} "
                    f"at '{'.'.join(parts[:i])}'"
                )
        return current

    # ------------------------------------------------------------------ #
    #  Variable resolution                                                 #
    # ------------------------------------------------------------------ #

    def _resolve(self, value) -> str:
        if not isinstance(value, str):
            return str(value) if value is not None else ""

        def replace(m):
            key = m.group(1)
            if key in self._vars:
                return self._vars[key]
            for prefix in ("sessions.", "test_suites.", "shared_validation_rules."):
                if (prefix + key) in self._vars:
                    return self._vars[prefix + key]
            import os
            if key in os.environ:
                return os.environ[key]
            return m.group(0)

        return re.sub(r"\$\{([^}]+)\}", replace, value)

    # ------------------------------------------------------------------ #
    #  Assertion helpers                                                   #
    # ------------------------------------------------------------------ #

    def _assert_contains(self, text: str, expected: str,
                         message=None, cont: bool = False) -> None:
        if expected not in text:
            self._fail(message or f"Expected to contain '{expected}'", cont)

    def _fail(self, message: str, cont: bool) -> None:
        raise AssertionError(f"[Engine] {message}")

    # ------------------------------------------------------------------ #
    #  Suite / TC lookup                                                   #
    # ------------------------------------------------------------------ #

    def _get_suite(self, suite_key: str) -> dict:
        suite = self._tpl.get("test_suites", {}).get(suite_key)
        if suite is None:
            raise KeyError(
                f"Suite '{suite_key}' not found. "
                f"Available: {list(self._tpl.get('test_suites', {}).keys())}"
            )
        return suite

    @staticmethod
    def _find_tc(suite: dict, tc_id: str) -> Optional[dict]:
        for tc in suite.get("test_cases", []):
            if tc.get("id") == tc_id:
                return tc
        return None
