"""
runner.py — Public API for health_check_runner.

Usage
-----
    from health_check_runner import Runner

    with Runner(
        template="templates/mydevice.json",
        sessions="config/sessions.json",
        env="config/envs/lab.json",
    ) as r:
        result = r.run()
        print(result.summary())

    # or run a single TC
    with Runner(...) as r:
        tc = r.run_tc("TC1")
        assert tc.passed, tc.failure_summary()
"""

import copy
import json
import os
import re
import time
from datetime import datetime
from typing import Callable, Dict, List, Optional

from ._logger import StdlibLogger, MaskingLogger
from ._result import SuiteResult, TCResult
from .engine import Engine
from .session_manager import SessionManager


class Runner:
    """
    High-level entry point for running JSON-driven health checks
    from plain Python, pytest, or CLI — no Robot Framework required.

    Parameters
    ----------
    template        Path to templates/<nf>.json
    sessions        Path to config/sessions.json
    env             Path to config/envs/<site>.json
    shared_rules    Path to config/shared_rules.json (optional)
    timeout         Default SSH command timeout in seconds
    secrets         List of strings to redact from all log output
                    (e.g. passwords).  The passwords from the env file
                    are added automatically.
    log_level       Python logging level for the stdlib logger
                    (ignored if a custom logger is passed)
    logger          Custom logger implementing .info()/.debug()/.warn().
                    If None, StdlibLogger wrapped in MaskingLogger is used.
    """

    def __init__(
        self,
        template:     str,
        sessions:     str,
        env:          str,
        shared_rules: Optional[str] = None,
        timeout:      int           = 60,
        secrets:      Optional[List[str]] = None,
        log_level:    int           = 20,   # logging.INFO
        logger                      = None,
    ):
        self._template_path = template
        self._sessions_path = sessions
        self._env_path      = env
        self._shared_path   = shared_rules
        self._timeout       = int(timeout)

        # Logging
        if logger is not None:
            self._log = logger
        else:
            base           = StdlibLogger(level=log_level)
            self._masking  = MaskingLogger(base, secrets or [])
            self._log      = self._masking

        # Load and merge config
        self._tpl_doc   = self._load_json(template)
        self._sess_doc  = self._load_json(sessions)
        self._env_doc   = self._load_json(env)
        self._shared    = (
            self._load_json(shared_rules).get("shared_validation_rules", {})
            if shared_rules and os.path.isfile(shared_rules)
            else {}
        )

        self._sessions_merged = self._merge_sessions()
        self._suite_key       = self._tpl_doc.get("suite_key", "unknown")
        self._vars: Dict[str, str] = {}
        self._build_flat_vars(self._build_tpl_tree())

        # Auto-register env passwords as secrets
        if hasattr(self, "_masking"):
            for sess_data in self._env_doc.get("sessions", {}).values():
                pwd = sess_data.get("password", "")
                if pwd:
                    self._masking.register_secret(pwd)

        self._sm: Optional[SessionManager] = None
        self._engine: Optional[Engine]     = None

        self._log.info(
            f"[Runner] Loaded: suite='{self._suite_key}'  "
            f"TCs={len(self._tpl_doc.get('test_cases', []))}  "
            f"chain={self._tpl_doc.get('default_chain', [])}"
        )

    # ------------------------------------------------------------------ #
    #  Context manager                                                     #
    # ------------------------------------------------------------------ #

    def __enter__(self) -> "Runner":
        self.open()
        return self

    def __exit__(self, *_) -> None:
        self.close()

    # ------------------------------------------------------------------ #
    #  Session lifecycle                                                   #
    # ------------------------------------------------------------------ #

    def open(self) -> None:
        """Open all sessions in default_chain (equiv to Suite Setup)."""
        self._sm = SessionManager(
            sessions_def    = self._sessions_merged,
            resolve_fn      = self._resolve,
            default_timeout = self._timeout,
            logger          = self._log,
        )
        self._engine = Engine(
            sm           = self._sm,
            template     = self._build_tpl_tree(),
            vars_store   = self._vars,
            shared_rules = self._shared,
            logger       = self._log,
        )
        chain = self._tpl_doc.get("default_chain", [])
        self._sm.connect_chain(chain)
        self._log.info(f"[Runner] Sessions open: {chain}")

    def close(self) -> None:
        """Close all sessions (equiv to Suite Teardown)."""
        if self._sm:
            chain = self._tpl_doc.get("default_chain", [])
            self._sm.disconnect_chain(chain)
            self._sm = None
        self._log.info("[Runner] Sessions closed")

    # ------------------------------------------------------------------ #
    #  Test execution                                                      #
    # ------------------------------------------------------------------ #

    def run(
        self,
        tc_ids:     Optional[List[str]]              = None,
        on_tc_done: Optional[Callable[[TCResult], None]] = None,
    ) -> SuiteResult:
        """
        Run all (or a subset of) test cases and return a SuiteResult.

        Parameters
        ----------
        tc_ids      If given, only these TC IDs are executed (in order).
                    If None, all TCs defined in the template are run.
        on_tc_done  Optional callback called immediately after each TC
                    completes.  Receives the TCResult so callers can
                    print live progress without waiting for the whole
                    suite to finish.

                    Example::

                        def print_live(tc: TCResult) -> None:
                            print(tc.to_line(), flush=True)

                        result = runner.run(on_tc_done=print_live)
        """
        if self._engine is None:
            raise RuntimeError("Call open() or use Runner as a context manager first.")

        all_tcs   = self._tpl_doc.get("test_cases", [])
        to_run    = (
            [tc for tc in all_tcs if tc["id"] in tc_ids]
            if tc_ids
            else all_tcs
        )
        started   = datetime.now()
        t0        = time.monotonic()
        tc_results: List[TCResult] = []

        for tc in to_run:
            result = self._engine.run_tc(self._suite_key, tc["id"])
            tc_results.append(result)
            if on_tc_done is not None:
                on_tc_done(result)

        duration = time.monotonic() - t0
        suite_result = SuiteResult(
            suite_key  = self._suite_key,
            started_at = started,
            duration_s = duration,
            tcs        = tc_results,
        )
        self._log.info(f"[Runner] {suite_result.summary()}")
        return suite_result

    def run_tc(self, tc_id: str) -> TCResult:
        """Run a single TC by ID and return a TCResult."""
        if self._engine is None:
            raise RuntimeError("Call open() or use Runner as a context manager first.")
        return self._engine.run_tc(self._suite_key, tc_id)

    def get_suite_key(self) -> str:
        return self._suite_key

    # ------------------------------------------------------------------ #
    #  Config loading + merge                                              #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _load_json(path: str) -> dict:
        abs_path = os.path.abspath(path)
        if not os.path.isfile(abs_path):
            raise FileNotFoundError(f"[Runner] File not found: {abs_path}")
        with open(abs_path, encoding="utf-8") as fh:
            return json.load(fh)

    def _merge_sessions(self) -> dict:
        base     = copy.deepcopy(self._sess_doc.get("sessions", {}))
        env_sess = self._env_doc.get("sessions", {})
        for sid, overrides in env_sess.items():
            if sid not in base:
                base[sid] = {}
            base[sid].update(overrides)
        return base

    def _build_tpl_tree(self) -> dict:
        suite_key = self._suite_key
        return {
            "sessions": self._sessions_merged,
            "test_suites": {
                suite_key: {
                    "description":   self._tpl_doc.get("description", ""),
                    "default_chain": self._tpl_doc.get("default_chain", []),
                    "test_cases":    self._tpl_doc.get("test_cases", []),
                }
            },
            "shared_validation_rules": self._shared,
        }

    def _build_flat_vars(self, node, prefix=""):
        if isinstance(node, dict):
            for k, v in node.items():
                full = f"{prefix}.{k}" if prefix else k
                if isinstance(v, (dict, list)):
                    self._build_flat_vars(v, full)
                else:
                    self._vars[full] = str(v) if v is not None else ""
        elif isinstance(node, list):
            for i, v in enumerate(node):
                self._build_flat_vars(v, f"{prefix}.{i}")

    def _resolve(self, value) -> str:
        if not isinstance(value, str):
            return str(value) if value is not None else ""

        def replace(m):
            key = m.group(1)
            if key in self._vars:
                return self._vars[key]
            for prefix in ("sessions.", "test_suites.", "shared_validation_rules."):
                if (prefix + key) in self._vars:
                    return self._vars[prefix + key]
            if key in os.environ:
                return os.environ[key]
            return m.group(0)

        return re.sub(r"\$\{([^}]+)\}", replace, value)
