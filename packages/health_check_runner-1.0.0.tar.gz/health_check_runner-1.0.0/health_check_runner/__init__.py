"""
health_check_runner
===================
Universal JSON-driven CLI health check library.

Supports Robot Framework, pytest, plain Python, and CLI execution
from the same template JSON files.

Quick start
-----------
    from health_check_runner import Runner

    with Runner(
        template="templates/mydevice.json",
        sessions="config/sessions.json",
        env="config/envs/lab.json",
    ) as r:
        result = r.run()
        print(result.summary())
        print(result.to_table())
"""

from .runner import Runner
from ._result import SuiteResult, TCResult, StepResult
from ._logger import StdlibLogger, MaskingLogger

__all__ = [
    "Runner",
    "SuiteResult",
    "TCResult",
    "StepResult",
    "StdlibLogger",
    "MaskingLogger",
]

__version__ = "1.0.0"
