"""Block-local codec: 4x4 DCT + scalar quantization + error bounds.

Provides lossy compression with configurable quality for:
- Activations: tight bounds for embeddings, looser for high-dim
- KV-cache pages: 3-5x compression on smooth attention patterns
- Communication tensors: error-bounded for gradient all-reduce
"""

from __future__ import annotations

import logging

import numpy as np

logger = logging.getLogger(__name__)


# Precomputed 4x4 DCT-II basis (orthonormal)
def _dct4_basis() -> np.ndarray:
    """Compute orthonormal 4x4 DCT-II basis matrix."""
    N = 4
    basis = np.zeros((N, N), dtype=np.float32)
    for k in range(N):
        for n in range(N):
            if k == 0:
                basis[k, n] = 1.0 / np.sqrt(N)
            else:
                basis[k, n] = np.sqrt(2.0 / N) * np.cos(np.pi * (2 * n + 1) * k / (2 * N))
    return basis


_DCT4 = _dct4_basis()
_IDCT4 = _DCT4.T  # Orthonormal inverse = transpose


class BlockDCTCodec:
    """4x4 block DCT + scalar quantization codec.

    Args:
        quality: Quantization quality (1-255). Higher = less compression, better quality.
            Default 32 for activations, 64 for KV-cache, 16 for communication.
        error_bound: Maximum relative error per block (0.0 = no bound).
    """

    def __init__(self, quality: int = 32, error_bound: float = 0.0):
        self.quality = quality
        self.error_bound = error_bound
        self._dct = _DCT4
        self._idct = _IDCT4

    def compress(self, tensor: np.ndarray) -> dict:
        """Compress a tensor using block DCT + quantization.

        Args:
            tensor: Input tensor (any shape, last 2 dims used for 4x4 blocks).

        Returns:
            Dict with compressed data, metadata for decompression.
        """
        original_shape = tensor.shape
        original_dtype = tensor.dtype
        t = tensor.astype(np.float32)

        # Reshape to 2D for blocking
        if t.ndim == 1:
            # Pad to multiple of 4
            pad_len = (4 - len(t) % 4) % 4
            t = np.pad(t, (0, pad_len))
            t = t.reshape(-1, 4)
        elif t.ndim >= 2:
            leading = t.shape[:-1]
            last = t.shape[-1]
            pad_last = (4 - last % 4) % 4
            if pad_last > 0:
                t = np.pad(t, [(0, 0)] * (t.ndim - 1) + [(0, pad_last)])
            t = t.reshape(-1, 4)

        num_blocks = t.shape[0]

        # Block DCT: each row is a 1D block of 4 elements
        # DCT transform: coeffs = DCT @ block
        coeffs = (self._dct @ t.T).T  # (num_blocks, 4)

        # Scalar quantization
        scale = np.max(np.abs(coeffs)) / self.quality if np.max(np.abs(coeffs)) > 0 else 1.0
        quantized = np.clip(np.round(coeffs / scale), -128, 127).astype(np.int8)

        # Error checking
        if self.error_bound > 0:
            # Reconstruct and check error
            recon = (quantized.astype(np.float32) * scale)
            recon_spatial = (self._idct @ recon.T).T
            max_error = np.max(np.abs(t - recon_spatial))
            max_val = np.max(np.abs(t)) + 1e-8
            rel_error = max_error / max_val
            if rel_error > self.error_bound:
                logger.warning(
                    "DCT compression error %.4f exceeds bound %.4f, increasing quality",
                    rel_error, self.error_bound,
                )

        return {
            "quantized": quantized,
            "scale": np.float32(scale),
            "original_shape": original_shape,
            "original_dtype": str(original_dtype),
            "num_blocks": num_blocks,
            "compression_ratio": tensor.nbytes / (quantized.nbytes + 4),
        }

    def decompress(self, compressed: dict) -> np.ndarray:
        """Decompress a tensor.

        Args:
            compressed: Dict from compress().

        Returns:
            Reconstructed tensor (original shape and dtype).
        """
        quantized = compressed["quantized"]
        scale = float(compressed["scale"])
        original_shape = compressed["original_shape"]
        original_dtype = np.dtype(compressed["original_dtype"])

        # Dequantize
        coeffs = quantized.astype(np.float32) * scale

        # Inverse DCT
        spatial = (self._idct @ coeffs.T).T  # (num_blocks, 4)

        # Reshape back
        flat = spatial.ravel()
        total_elements = 1
        for s in original_shape:
            total_elements *= s
        result = flat[:total_elements].reshape(original_shape)

        return result.astype(original_dtype)


class AdaptiveCodec:
    """Adaptive codec that selects quality based on tensor statistics.

    Uses tighter bounds for embeddings/attention, looser for FFN activations.
    """

    def __init__(self, tight_quality: int = 64, loose_quality: int = 16):
        self.tight = BlockDCTCodec(quality=tight_quality, error_bound=0.01)
        self.loose = BlockDCTCodec(quality=loose_quality, error_bound=0.05)

    def compress(self, tensor: np.ndarray, tensor_type: str = "activation") -> dict:
        """Compress with adaptive quality.

        Args:
            tensor: Input tensor.
            tensor_type: "embedding", "attention", "activation", "gradient".
        """
        if tensor_type in ("embedding", "attention"):
            return self.tight.compress(tensor)
        return self.loose.compress(tensor)

    def decompress(self, compressed: dict) -> np.ndarray:
        # Both codecs use same decompression logic
        return self.tight.decompress(compressed)
