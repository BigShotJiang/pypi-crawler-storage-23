"""GrillyCompression — activation, KV-cache, and communication compression.

Optional grilly extension providing:
- BlockDCTCodec: 4x4 block DCT + scalar quantization with error bounds
- ActivationCompressor: Compress intermediate tensors between layers (30-60% VRAM savings)
- KVCacheCompressor: Compress cached K/V pages (3-5x compression)
- CommunicationCompressor: Gradient/tensor compression for multi-GPU (19-37% improvement)
"""

from .codec import BlockDCTCodec
from .activation import ActivationCompressor
from .kv_cache import KVCacheCompressor
from .communication import CommunicationCompressor

__version__ = "0.1.0"

__all__ = [
    "BlockDCTCodec",
    "ActivationCompressor",
    "KVCacheCompressor",
    "CommunicationCompressor",
]
