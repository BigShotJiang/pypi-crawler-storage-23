"""GPU integration tests for GrillyCompression package.

Tests exercise the compression algorithms with data that flows through the
grilly Vulkan backend (VulkanTensor -> numpy -> compress -> decompress -> numpy).
All tests are skipped when the Vulkan backend is not available.

Tests cover:
- BlockDCTCodec: round-trip on GPU-sourced data, block sizes, quality, error bounds
- ActivationCompressor: activation pipeline with typical transformer shapes
- KVCacheCompressor: KV-cache page compression with attention-score validation
- CommunicationCompressor: gradient compression with error feedback
- Integration: end-to-end multi-layer pipeline, chained error accumulation
"""

import pytest
import numpy as np

try:
    import grilly
    from grilly import VULKAN_AVAILABLE as _vulkan_ok
    from grilly.utils.tensor_conversion import VulkanTensor
    VULKAN_AVAILABLE = _vulkan_ok
except Exception:
    VULKAN_AVAILABLE = False

from grillycompression.codec import BlockDCTCodec, AdaptiveCodec
from grillycompression.activation import ActivationCompressor
from grillycompression.kv_cache import KVCacheCompressor
from grillycompression.communication import CommunicationCompressor

pytestmark = [
    pytest.mark.gpu,
    pytest.mark.skipif(not VULKAN_AVAILABLE, reason="Vulkan not available"),
]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _gpu_roundtrip(data: np.ndarray) -> np.ndarray:
    """Send data through VulkanTensor and back to numpy (GPU round-trip)."""
    vt = VulkanTensor(data.astype(np.float32), lazy=True)
    return vt.numpy()


def _relative_error(original: np.ndarray, reconstructed: np.ndarray) -> float:
    """Compute maximum relative error between original and reconstructed."""
    max_val = np.max(np.abs(original)) + 1e-8
    return float(np.max(np.abs(original - reconstructed)) / max_val)


def _correlation(a: np.ndarray, b: np.ndarray) -> float:
    """Pearson correlation between flattened arrays."""
    a_flat = a.ravel().astype(np.float64)
    b_flat = b.ravel().astype(np.float64)
    if np.std(a_flat) < 1e-12 or np.std(b_flat) < 1e-12:
        return 1.0 if np.allclose(a_flat, b_flat, atol=1e-6) else 0.0
    return float(np.corrcoef(a_flat, b_flat)[0, 1])


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def rng():
    """Seeded random generator for reproducibility."""
    return np.random.RandomState(42)


@pytest.fixture
def activation_tensor(rng):
    """Activation tensor (batch=2, seq=32, hidden=64) via GPU round-trip."""
    data = rng.randn(2, 32, 64).astype(np.float32)
    return _gpu_roundtrip(data)


@pytest.fixture
def embedding_tensor(rng):
    """Embedding tensor (batch=2, seq=32, hidden=128) via GPU round-trip."""
    data = rng.randn(2, 32, 128).astype(np.float32)
    return _gpu_roundtrip(data)


@pytest.fixture
def kv_tensors(rng):
    """KV-cache tensors (batch=1, heads=8, seq=64, head_dim=128) via GPU round-trip."""
    k = _gpu_roundtrip(rng.randn(1, 8, 64, 128).astype(np.float32))
    v = _gpu_roundtrip(rng.randn(1, 8, 64, 128).astype(np.float32))
    return k, v


@pytest.fixture
def kv_small(rng):
    """Small KV-cache tensors (1, 8, 64, 128) -- Llama-like shape."""
    k = _gpu_roundtrip(rng.randn(1, 8, 64, 128).astype(np.float32))
    v = _gpu_roundtrip(rng.randn(1, 8, 64, 128).astype(np.float32))
    return k, v


@pytest.fixture
def gradient_tensor(rng):
    """Gradient tensor via GPU round-trip."""
    data = rng.randn(64, 128).astype(np.float32) * 0.01
    return _gpu_roundtrip(data)


# ===========================================================================
# 1. TestBlockDCTCodecGPU
# ===========================================================================

class TestBlockDCTCodecGPU:
    """Test DCT codec with GPU-sourced data."""

    def test_roundtrip_preserves_data(self, activation_tensor):
        """Compress/decompress round-trip preserves data within error bounds."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(activation_tensor)
        result = codec.decompress(compressed)
        assert result.shape == activation_tensor.shape
        rel_err = _relative_error(activation_tensor, result)
        assert rel_err < 0.15, f"Relative error {rel_err:.4f} exceeds 15%"

    def test_activation_shaped_tensor(self, activation_tensor):
        """Works with activation-shaped tensors (batch, seq, hidden)."""
        codec = BlockDCTCodec(quality=48)
        compressed = codec.compress(activation_tensor)
        result = codec.decompress(compressed)
        assert result.shape == (2, 32, 64)
        assert _correlation(activation_tensor, result) > 0.90

    def test_embedding_shaped_tensor(self, embedding_tensor):
        """Works with embedding-shaped tensors (batch, seq, hidden=128)."""
        codec = BlockDCTCodec(quality=64)
        compressed = codec.compress(embedding_tensor)
        result = codec.decompress(compressed)
        assert result.shape == (2, 32, 128)
        assert _correlation(embedding_tensor, result) > 0.90

    @pytest.mark.parametrize("shape", [
        (4, 32, 64),
        (1, 16, 256),
        (2, 64, 128),
        (8, 8, 32),
    ])
    def test_various_shapes(self, rng, shape):
        """Various tensor shapes are handled correctly."""
        data = _gpu_roundtrip(rng.randn(*shape).astype(np.float32))
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(data)
        result = codec.decompress(compressed)
        assert result.shape == shape

    def test_block_size_4x4_implicit(self, activation_tensor):
        """Codec uses 4x4 blocks (last dim padded to multiple of 4)."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(activation_tensor)
        # The number of blocks should reflect the 4-element blocking
        total_elements = np.prod(activation_tensor.shape[:-1])
        last_dim_padded = activation_tensor.shape[-1] + (4 - activation_tensor.shape[-1] % 4) % 4
        expected_blocks = int(total_elements * (last_dim_padded // 4))
        assert compressed["num_blocks"] == expected_blocks

    def test_quality_low_vs_high(self, activation_tensor):
        """Higher quality produces lower reconstruction error."""
        codec_low = BlockDCTCodec(quality=8)
        codec_high = BlockDCTCodec(quality=64)

        result_low = codec_low.decompress(codec_low.compress(activation_tensor))
        result_high = codec_high.decompress(codec_high.compress(activation_tensor))

        err_low = _relative_error(activation_tensor, result_low)
        err_high = _relative_error(activation_tensor, result_high)
        assert err_high <= err_low, (
            f"High quality error ({err_high:.4f}) should be <= low quality error ({err_low:.4f})"
        )

    @pytest.mark.parametrize("quality", [8, 16, 32, 48, 64, 128])
    def test_quality_levels(self, rng, quality):
        """Various quality levels produce valid results."""
        data = _gpu_roundtrip(rng.randn(2, 16, 64).astype(np.float32))
        codec = BlockDCTCodec(quality=quality)
        compressed = codec.compress(data)
        result = codec.decompress(compressed)
        assert result.shape == data.shape
        # All quality levels should produce finite results
        assert np.all(np.isfinite(result))

    def test_compressed_smaller_than_original(self, activation_tensor):
        """Compressed size is smaller than original float32 data."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(activation_tensor)
        compressed_bytes = compressed["quantized"].nbytes + 4  # +4 for scale
        original_bytes = activation_tensor.nbytes
        assert compressed_bytes < original_bytes, (
            f"Compressed ({compressed_bytes}) not smaller than original ({original_bytes})"
        )

    def test_compression_ratio_positive(self, activation_tensor):
        """Compression ratio is greater than 1."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(activation_tensor)
        assert compressed["compression_ratio"] > 1.0

    def test_error_bound_respected(self, rng):
        """Error bound with high quality keeps reconstruction error controlled."""
        data = _gpu_roundtrip(rng.randn(2, 16, 64).astype(np.float32))
        codec = BlockDCTCodec(quality=64, error_bound=0.05)
        compressed = codec.compress(data)
        result = codec.decompress(compressed)
        rel_err = _relative_error(data, result)
        # High quality + error bound should keep error reasonable
        assert rel_err < 0.10, f"Error {rel_err:.4f} too high with error_bound=0.05"

    def test_error_bound_zero_still_compresses(self, activation_tensor):
        """error_bound=0.0 (no bound) still compresses correctly."""
        codec = BlockDCTCodec(quality=32, error_bound=0.0)
        compressed = codec.compress(activation_tensor)
        result = codec.decompress(compressed)
        assert result.shape == activation_tensor.shape

    def test_quantized_dtype_int8(self, activation_tensor):
        """Quantized coefficients are stored as int8."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(activation_tensor)
        assert compressed["quantized"].dtype == np.int8


# ===========================================================================
# 2. TestActivationCompressorGPU
# ===========================================================================

class TestActivationCompressorGPU:
    """Test activation compression pipeline with GPU-sourced data."""

    def test_roundtrip_activation(self, activation_tensor):
        """Compress/decompress activation tensor preserves shape and quality."""
        compressor = ActivationCompressor(quality=32, adaptive=False)
        compressed = compressor.compress(activation_tensor)
        result = compressor.decompress(compressed)
        assert result.shape == activation_tensor.shape
        assert _correlation(activation_tensor, result) > 0.90

    @pytest.mark.parametrize("hidden_dim", [64, 128, 256])
    def test_typical_hidden_dims(self, rng, hidden_dim):
        """Works with typical transformer hidden dimensions."""
        data = _gpu_roundtrip(rng.randn(2, 32, hidden_dim).astype(np.float32))
        compressor = ActivationCompressor(quality=32, adaptive=False)
        compressed = compressor.compress(data)
        result = compressor.decompress(compressed)
        assert result.shape == data.shape
        assert _correlation(data, result) > 0.95

    def test_compression_saves_bytes(self, activation_tensor):
        """Compression achieves 30-60% byte savings (float32 -> int8)."""
        compressor = ActivationCompressor(quality=32, adaptive=False)
        compressed = compressor.compress(activation_tensor)
        stats = compressor.get_stats()
        original_bytes = activation_tensor.nbytes
        saved_bytes = stats["bytes_saved"]
        savings_pct = saved_bytes / original_bytes * 100
        # int8 quantization of float32 should save at least 30%
        assert savings_pct > 30, f"Savings {savings_pct:.1f}% below 30% target"

    def test_correlation_above_threshold(self, activation_tensor):
        """Decompressed activations correlate > 0.95 with originals."""
        compressor = ActivationCompressor(quality=48, adaptive=False)
        compressed = compressor.compress(activation_tensor)
        result = compressor.decompress(compressed)
        corr = _correlation(activation_tensor, result)
        assert corr > 0.95, f"Correlation {corr:.4f} below 0.95 threshold"

    def test_fp32_input(self, rng):
        """fp32 input tensors compress and decompress correctly."""
        data = _gpu_roundtrip(rng.randn(2, 16, 64).astype(np.float32))
        assert data.dtype == np.float32
        compressor = ActivationCompressor(quality=32, adaptive=False)
        compressed = compressor.compress(data)
        result = compressor.decompress(compressed)
        assert result.dtype == np.float32

    def test_fp16_input(self, rng):
        """fp16 input tensors are handled (codec casts to float32 internally)."""
        data = rng.randn(2, 16, 64).astype(np.float16)
        # VulkanTensor casts to float32, so GPU roundtrip changes dtype
        # but we test that the compressor handles fp16 numpy input
        compressor = ActivationCompressor(quality=32, adaptive=False)
        compressed = compressor.compress(data)
        result = compressor.decompress(compressed)
        assert result.shape == data.shape
        assert result.dtype == np.float16

    def test_adaptive_mode(self, activation_tensor):
        """Adaptive mode selects quality based on layer type."""
        compressor = ActivationCompressor(quality=32, adaptive=True)
        # Attention should use tight quality (lower error)
        comp_attn = compressor.compress(activation_tensor, layer_type="attention")
        res_attn = compressor.decompress(comp_attn)

        compressor2 = ActivationCompressor(quality=32, adaptive=True)
        comp_act = compressor2.compress(activation_tensor, layer_type="activation")
        res_act = compressor2.decompress(comp_act)

        err_attn = _relative_error(activation_tensor, res_attn)
        err_act = _relative_error(activation_tensor, res_act)
        assert err_attn <= err_act, (
            f"Attention error ({err_attn:.4f}) should be <= activation error ({err_act:.4f})"
        )

    def test_checkpoint_compress_decompress(self, rng):
        """compress_checkpoint / decompress_checkpoint round-trip."""
        compressor = ActivationCompressor(quality=32, adaptive=True)
        activations = {
            "layer0.attn": _gpu_roundtrip(rng.randn(2, 32, 64).astype(np.float32)),
            "layer0.ffn": _gpu_roundtrip(rng.randn(2, 32, 128).astype(np.float32)),
            "layer1.attn": _gpu_roundtrip(rng.randn(2, 32, 64).astype(np.float32)),
        }
        compressed = compressor.compress_checkpoint(activations)
        decompressed = compressor.decompress_checkpoint(compressed)
        for name in activations:
            assert decompressed[name].shape == activations[name].shape
            assert _correlation(activations[name], decompressed[name]) > 0.90

    def test_stats_accumulate(self, activation_tensor):
        """Stats correctly accumulate across multiple compressions."""
        compressor = ActivationCompressor(quality=32, adaptive=False)
        for _ in range(3):
            compressor.compress(activation_tensor)
        stats = compressor.get_stats()
        assert stats["tensors_compressed"] == 3
        assert stats["bytes_saved"] > 0
        assert stats["avg_compression_ratio"] > 1.0


# ===========================================================================
# 3. TestKVCacheCompressorGPU
# ===========================================================================

class TestKVCacheCompressorGPU:
    """Test KV-cache page compression with GPU-sourced data."""

    def test_page_roundtrip(self, kv_tensors):
        """Compress/decompress KV page preserves shape and quality."""
        k, v = kv_tensors
        compressor = KVCacheCompressor(quality=48, error_bound=0.01)
        compressed = compressor.compress_page(k, v)
        k_out, v_out = compressor.decompress_page(compressed)
        assert k_out.shape == k.shape
        assert v_out.shape == v.shape

    def test_llama_like_shapes(self, kv_small):
        """Works with small Llama-like KV shapes (1, 8, 64, 128)."""
        k, v = kv_small
        compressor = KVCacheCompressor(quality=48, error_bound=0.01)
        compressed = compressor.compress_page(k, v)
        k_out, v_out = compressor.decompress_page(compressed)
        assert k_out.shape == (1, 8, 64, 128)
        assert v_out.shape == (1, 8, 64, 128)
        assert _correlation(k, k_out) > 0.90
        assert _correlation(v, v_out) > 0.90

    def test_compression_ratio(self, kv_tensors):
        """Compression ratio is in a reasonable range."""
        k, v = kv_tensors
        compressor = KVCacheCompressor(quality=48, error_bound=0.01)
        compressed = compressor.compress_page(k, v)
        # Both K and V should have compression ratio > 1
        assert compressed["k"]["compression_ratio"] > 1.0
        assert compressed["v"]["compression_ratio"] > 1.0

    def test_attention_score_preservation(self, rng):
        """Attention scores computed with decompressed KV are close to original.

        Simulates: scores = softmax(Q @ K^T / sqrt(d)) @ V
        """
        batch, heads, seq_q, seq_kv, head_dim = 1, 4, 16, 32, 64

        q = _gpu_roundtrip(rng.randn(batch, heads, seq_q, head_dim).astype(np.float32))
        k = _gpu_roundtrip(rng.randn(batch, heads, seq_kv, head_dim).astype(np.float32))
        v = _gpu_roundtrip(rng.randn(batch, heads, seq_kv, head_dim).astype(np.float32))

        # Original attention
        scale = 1.0 / np.sqrt(head_dim)
        scores_orig = q @ k.transpose(0, 1, 3, 2) * scale
        # Stable softmax
        scores_orig = scores_orig - np.max(scores_orig, axis=-1, keepdims=True)
        exp_scores = np.exp(scores_orig)
        attn_orig = exp_scores / (np.sum(exp_scores, axis=-1, keepdims=True) + 1e-8)
        out_orig = attn_orig @ v

        # Compressed KV attention
        compressor = KVCacheCompressor(quality=48, error_bound=0.01)
        compressed = compressor.compress_page(k, v)
        k_dec, v_dec = compressor.decompress_page(compressed)

        scores_dec = q @ k_dec.transpose(0, 1, 3, 2) * scale
        scores_dec = scores_dec - np.max(scores_dec, axis=-1, keepdims=True)
        exp_scores_dec = np.exp(scores_dec)
        attn_dec = exp_scores_dec / (np.sum(exp_scores_dec, axis=-1, keepdims=True) + 1e-8)
        out_dec = attn_dec @ v_dec

        # Output should be correlated
        corr = _correlation(out_orig, out_dec)
        assert corr > 0.85, f"Attention output correlation {corr:.4f} below 0.85"

    def test_incremental_page_compression(self, rng):
        """Compress pages incrementally (page by page)."""
        compressor = KVCacheCompressor(quality=48, error_bound=0.01)
        num_pages = 4
        pages = []

        for i in range(num_pages):
            k = _gpu_roundtrip(rng.randn(1, 4, 16, 64).astype(np.float32))
            v = _gpu_roundtrip(rng.randn(1, 4, 16, 64).astype(np.float32))
            compressed = compressor.compress_page(k, v)
            pages.append(compressed)

        # All pages should decompress correctly
        for i, page in enumerate(pages):
            k_out, v_out = compressor.decompress_page(page)
            assert k_out.shape == (1, 4, 16, 64), f"Page {i} K shape mismatch"
            assert v_out.shape == (1, 4, 16, 64), f"Page {i} V shape mismatch"

        # Stats should reflect all pages
        stats = compressor.get_stats()
        assert stats["pages_compressed"] == num_pages

    def test_estimate_savings(self, kv_tensors):
        """estimate_savings returns reasonable values after compression."""
        k, v = kv_tensors
        compressor = KVCacheCompressor(quality=48)
        compressor.compress_page(k, v)
        savings = compressor.estimate_savings(
            num_layers=32, num_kv_heads=8, page_size=64,
            head_dim=128, num_pages=100,
        )
        assert savings["uncompressed_mb"] > 0
        assert savings["compressed_mb"] < savings["uncompressed_mb"]
        assert 0 < savings["savings_pct"] < 100

    @pytest.mark.parametrize("shape", [
        (1, 4, 16, 32),
        (1, 8, 32, 64),
        (2, 4, 8, 128),
    ])
    def test_various_kv_shapes(self, rng, shape):
        """Various KV shapes are handled correctly."""
        k = _gpu_roundtrip(rng.randn(*shape).astype(np.float32))
        v = _gpu_roundtrip(rng.randn(*shape).astype(np.float32))
        compressor = KVCacheCompressor(quality=48)
        compressed = compressor.compress_page(k, v)
        k_out, v_out = compressor.decompress_page(compressed)
        assert k_out.shape == shape
        assert v_out.shape == shape


# ===========================================================================
# 4. TestCommunicationCompressorGPU
# ===========================================================================

class TestCommunicationCompressorGPU:
    """Test gradient compression with GPU-sourced data."""

    def test_gradient_roundtrip(self, gradient_tensor):
        """Compress/decompress gradient preserves shape and quality."""
        compressor = CommunicationCompressor(quality=24, error_feedback=False)
        compressed = compressor.compress_gradient(gradient_tensor, name="fc.weight")
        result = compressor.decompress_gradient(compressed)
        assert result.shape == gradient_tensor.shape
        rel_err = _relative_error(gradient_tensor, result)
        assert rel_err < 0.20, f"Gradient error {rel_err:.4f} exceeds 20%"

    def test_error_bounded_compression(self, gradient_tensor):
        """Error-bounded compression keeps error controlled."""
        compressor = CommunicationCompressor(quality=48, error_feedback=False)
        compressed = compressor.compress_gradient(gradient_tensor, name="w")
        result = compressor.decompress_gradient(compressed)
        rel_err = _relative_error(gradient_tensor, result)
        # Higher quality should give lower error
        assert rel_err < 0.10, f"Error {rel_err:.4f} too high for quality=48"

    @pytest.mark.parametrize("shape", [
        (128,),
        (64, 128),
        (32, 64),
        (16, 16, 16),
    ])
    def test_various_gradient_shapes(self, rng, shape):
        """Various gradient tensor shapes are handled correctly."""
        data = _gpu_roundtrip(rng.randn(*shape).astype(np.float32) * 0.01)
        compressor = CommunicationCompressor(quality=24, error_feedback=False)
        compressed = compressor.compress_gradient(data, name="param")
        result = compressor.decompress_gradient(compressed)
        assert result.shape == shape

    def test_compression_ratio(self, gradient_tensor):
        """Compression ratio is greater than 1."""
        compressor = CommunicationCompressor(quality=24, error_feedback=False)
        compressor.compress_gradient(gradient_tensor, name="w")
        stats = compressor.get_stats()
        assert stats["compression_ratio"] > 1.0
        assert stats["communication_saved_pct"] > 0

    def test_error_feedback_reduces_cumulative_error(self, rng):
        """Error feedback reduces cumulative error over multiple rounds."""
        g = _gpu_roundtrip(rng.randn(256).astype(np.float32) * 0.01)

        compressor_ef = CommunicationCompressor(quality=16, error_feedback=True)
        compressor_no = CommunicationCompressor(quality=16, error_feedback=False)

        cumulative_ef = np.zeros_like(g)
        cumulative_no = np.zeros_like(g)

        for _ in range(5):
            comp_ef = compressor_ef.compress_gradient(g, name="p")
            cumulative_ef += compressor_ef.decompress_gradient(comp_ef).astype(np.float32)

            comp_no = compressor_no.compress_gradient(g, name="p")
            cumulative_no += compressor_no.decompress_gradient(comp_no).astype(np.float32)

        target = g * 5
        error_ef = np.mean(np.abs(target - cumulative_ef))
        error_no = np.mean(np.abs(target - cumulative_no))
        # Error feedback should give at least as good cumulative accuracy
        assert error_ef <= error_no * 1.1, (
            f"Error feedback ({error_ef:.6f}) should be <= no-feedback ({error_no:.6f})"
        )

    def test_compress_tensor_generic(self, rng):
        """compress_tensor / decompress_tensor for generic GPU-sourced tensors."""
        data = _gpu_roundtrip(rng.randn(32, 64).astype(np.float32))
        compressor = CommunicationCompressor(quality=24)
        compressed = compressor.compress_tensor(data)
        result = compressor.decompress_tensor(compressed)
        assert result.shape == data.shape

    def test_clear_residuals_after_step(self, gradient_tensor):
        """Residuals are cleared after optimizer step simulation."""
        compressor = CommunicationCompressor(quality=24, error_feedback=True)
        compressor.compress_gradient(gradient_tensor, name="p0")
        compressor.compress_gradient(gradient_tensor, name="p1")
        assert len(compressor._residuals) == 2
        compressor.clear_residuals()
        assert len(compressor._residuals) == 0


# ===========================================================================
# 5. TestCompressionIntegration
# ===========================================================================

class TestCompressionIntegration:
    """End-to-end GPU integration tests simulating real inference/training pipelines."""

    def test_mini_inference_pipeline(self, rng):
        """Simulate compress between layers, decompress for next layer.

        Pipeline: input -> [compress] -> [decompress] -> linear -> [compress] ->
                  [decompress] -> output
        """
        batch, seq, hidden = 2, 32, 64
        compressor = ActivationCompressor(quality=32, adaptive=False)

        # Layer 0 output (from GPU)
        act0 = _gpu_roundtrip(rng.randn(batch, seq, hidden).astype(np.float32))

        # Compress between layers
        comp0 = compressor.compress(act0)
        act0_dec = compressor.decompress(comp0)

        # Simulate layer 1 (simple linear transform)
        w1 = rng.randn(hidden, hidden).astype(np.float32) * 0.02
        act1 = act0_dec @ w1

        # Compress again between layers
        comp1 = compressor.compress(act1)
        act1_dec = compressor.decompress(comp1)

        # Simulate layer 2
        w2 = rng.randn(hidden, hidden).astype(np.float32) * 0.02
        act2 = act1_dec @ w2

        # Final output should be finite and shaped correctly
        assert act2.shape == (batch, seq, hidden)
        assert np.all(np.isfinite(act2))

    def test_chained_error_accumulation(self, rng):
        """Chained compress/decompress does not accumulate too much error."""
        batch, seq, hidden = 2, 16, 64
        compressor = ActivationCompressor(quality=48, adaptive=False)

        original = _gpu_roundtrip(rng.randn(batch, seq, hidden).astype(np.float32))
        current = original.copy()

        # Chain 5 compress/decompress cycles
        for _ in range(5):
            compressed = compressor.compress(current)
            current = compressor.decompress(compressed)

        # After 5 rounds, correlation should still be reasonable
        corr = _correlation(original, current)
        assert corr > 0.80, f"Correlation {corr:.4f} too low after 5 chained rounds"

        # Relative error should not be catastrophic
        rel_err = _relative_error(original, current)
        assert rel_err < 0.50, f"Relative error {rel_err:.4f} too high after chaining"

    def test_memory_savings_measurement(self, rng):
        """Measure memory savings across a simulated multi-layer checkpoint."""
        compressor = ActivationCompressor(quality=32, adaptive=True)

        # Simulate 4 layers of activations
        activations = {}
        for i in range(4):
            activations[f"layer{i}.attn"] = _gpu_roundtrip(
                rng.randn(2, 32, 64).astype(np.float32)
            )
            activations[f"layer{i}.ffn"] = _gpu_roundtrip(
                rng.randn(2, 32, 128).astype(np.float32)
            )

        # Compress all
        compressed = compressor.compress_checkpoint(activations)

        # Verify all compressed
        assert len(compressed) == len(activations)

        # Check stats
        stats = compressor.get_stats()
        assert stats["tensors_compressed"] == 8
        assert stats["bytes_saved"] > 0
        assert stats["avg_compression_ratio"] > 1.0

        # Total bytes saved
        total_original = sum(a.nbytes for a in activations.values())
        total_compressed = sum(c["quantized"].nbytes + 4 for c in compressed.values())
        savings_pct = (1 - total_compressed / total_original) * 100
        assert savings_pct > 30, f"Only {savings_pct:.1f}% savings, expected > 30%"

    def test_kv_cache_across_layers(self, rng):
        """Simulate KV cache compression across multiple transformer layers."""
        compressor = KVCacheCompressor(quality=48, error_bound=0.01)
        num_layers = 4

        cache = {}
        for layer_idx in range(num_layers):
            k = _gpu_roundtrip(rng.randn(1, 4, 32, 64).astype(np.float32))
            v = _gpu_roundtrip(rng.randn(1, 4, 32, 64).astype(np.float32))
            cache[f"layer{layer_idx}"] = compressor.compress_page(k, v)

        # Decompress all and verify
        for layer_idx in range(num_layers):
            k_out, v_out = compressor.decompress_page(cache[f"layer{layer_idx}"])
            assert k_out.shape == (1, 4, 32, 64)
            assert v_out.shape == (1, 4, 32, 64)

        stats = compressor.get_stats()
        assert stats["pages_compressed"] == num_layers
        assert stats["avg_compression_ratio"] > 1.0

    def test_gradient_allreduce_simulation(self, rng):
        """Simulate gradient all-reduce: compress, 'transfer', decompress, average."""
        compressor_gpu0 = CommunicationCompressor(quality=24, error_feedback=True)
        compressor_gpu1 = CommunicationCompressor(quality=24, error_feedback=True)

        # Two GPUs compute different gradients
        g0 = _gpu_roundtrip(rng.randn(64, 128).astype(np.float32) * 0.01)
        g1 = _gpu_roundtrip(rng.randn(64, 128).astype(np.float32) * 0.01)

        # Compress for communication
        comp0 = compressor_gpu0.compress_gradient(g0, name="fc.weight")
        comp1 = compressor_gpu1.compress_gradient(g1, name="fc.weight")

        # Decompress on receiving side
        g0_received = compressor_gpu1.decompress_gradient(comp0)
        g1_received = compressor_gpu0.decompress_gradient(comp1)

        # Average (all-reduce)
        avg_on_gpu0 = (g0 + g1_received.astype(np.float32)) / 2
        avg_on_gpu1 = (g0_received.astype(np.float32) + g1) / 2

        # Both GPUs should have similar averaged gradients
        true_avg = (g0 + g1) / 2
        corr0 = _correlation(true_avg, avg_on_gpu0)
        corr1 = _correlation(true_avg, avg_on_gpu1)
        assert corr0 > 0.90, f"GPU0 average correlation {corr0:.4f} too low"
        assert corr1 > 0.90, f"GPU1 average correlation {corr1:.4f} too low"

    def test_vulkan_tensor_to_compression_roundtrip(self, rng):
        """Full VulkanTensor -> numpy -> compress -> decompress -> VulkanTensor cycle."""
        data_np = rng.randn(2, 32, 64).astype(np.float32)

        # Create VulkanTensor
        vt_in = VulkanTensor(data_np, lazy=True)

        # Extract numpy for compression
        np_in = vt_in.numpy()
        assert np_in.shape == (2, 32, 64)

        # Compress
        compressor = ActivationCompressor(quality=32, adaptive=False)
        compressed = compressor.compress(np_in)

        # Decompress
        np_out = compressor.decompress(compressed)

        # Wrap back in VulkanTensor
        vt_out = VulkanTensor(np_out, lazy=True)
        final = vt_out.numpy()

        assert final.shape == data_np.shape
        assert _correlation(data_np, final) > 0.90
