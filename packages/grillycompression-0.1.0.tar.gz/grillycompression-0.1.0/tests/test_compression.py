"""Tests for GrillyCompression package.

Tests cover:
- BlockDCTCodec: round-trip, quality levels, compression ratio, shapes, error bounds
- AdaptiveCodec: tensor-type selection, round-trip
- ActivationCompressor: round-trip, statistics tracking, tensor shapes
- KVCacheCompressor: page compression, memory estimation, statistics
- CommunicationCompressor: gradient compression, error feedback, statistics, ratio
"""

import pytest
import numpy as np

from grillycompression.codec import BlockDCTCodec, AdaptiveCodec
from grillycompression.activation import ActivationCompressor
from grillycompression.kv_cache import KVCacheCompressor
from grillycompression.communication import CommunicationCompressor

np.random.seed(42)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tensor_1d():
    """A 1D float32 tensor of length 20."""
    return np.random.randn(20).astype(np.float32)


@pytest.fixture
def tensor_2d():
    """A 2D float32 tensor (8, 16)."""
    return np.random.randn(8, 16).astype(np.float32)


@pytest.fixture
def tensor_3d():
    """A 3D float32 tensor (2, 8, 16) simulating (batch, seq, hidden)."""
    return np.random.randn(2, 8, 16).astype(np.float32)


@pytest.fixture
def kv_page():
    """A pair of K/V tensors shaped (1, 4, 8, 16): (batch, heads, page_len, head_dim)."""
    k = np.random.randn(1, 4, 8, 16).astype(np.float32)
    v = np.random.randn(1, 4, 8, 16).astype(np.float32)
    return k, v


@pytest.fixture
def gradient():
    """A gradient tensor shaped (128,)."""
    return np.random.randn(128).astype(np.float32)


# ===========================================================================
# 1. TestBlockDCTCodec
# ===========================================================================

class TestBlockDCTCodec:

    def test_roundtrip_preserves_shape(self, tensor_2d):
        """Compress/decompress round-trip preserves original tensor shape."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(tensor_2d)
        result = codec.decompress(compressed)
        assert result.shape == tensor_2d.shape

    def test_roundtrip_preserves_dtype(self, tensor_2d):
        """Round-trip preserves original dtype."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(tensor_2d)
        result = codec.decompress(compressed)
        assert result.dtype == tensor_2d.dtype

    def test_roundtrip_within_error_bounds(self, tensor_2d):
        """Reconstructed tensor is close to original (relative error < 10% at q=32)."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(tensor_2d)
        result = codec.decompress(compressed)
        max_val = np.max(np.abs(tensor_2d)) + 1e-8
        rel_error = np.max(np.abs(tensor_2d - result)) / max_val
        assert rel_error < 0.10, f"Relative error {rel_error:.4f} exceeds 10%"

    def test_quality_low(self, tensor_2d):
        """Low quality (8) produces larger error but still reconstructs shape."""
        codec = BlockDCTCodec(quality=8)
        compressed = codec.compress(tensor_2d)
        result = codec.decompress(compressed)
        assert result.shape == tensor_2d.shape
        # Low quality -> larger error is acceptable
        max_val = np.max(np.abs(tensor_2d)) + 1e-8
        rel_error = np.max(np.abs(tensor_2d - result)) / max_val
        assert rel_error < 0.50, f"Even low quality should not exceed 50% error, got {rel_error:.4f}"

    def test_quality_medium(self, tensor_2d):
        """Medium quality (32) should have moderate error."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(tensor_2d)
        result = codec.decompress(compressed)
        max_val = np.max(np.abs(tensor_2d)) + 1e-8
        rel_error = np.max(np.abs(tensor_2d - result)) / max_val
        assert rel_error < 0.15, f"Medium quality error {rel_error:.4f} too high"

    def test_quality_high(self, tensor_2d):
        """High quality (64) should have smaller error than low quality."""
        codec_high = BlockDCTCodec(quality=64)
        codec_low = BlockDCTCodec(quality=8)

        compressed_high = codec_high.compress(tensor_2d)
        compressed_low = codec_low.compress(tensor_2d)

        result_high = codec_high.decompress(compressed_high)
        result_low = codec_low.decompress(compressed_low)

        error_high = np.max(np.abs(tensor_2d - result_high))
        error_low = np.max(np.abs(tensor_2d - result_low))

        assert error_high <= error_low, (
            f"High quality error ({error_high:.4f}) should be <= low quality error ({error_low:.4f})"
        )

    def test_compression_reduces_size(self, tensor_2d):
        """Compressed representation should be smaller than original."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(tensor_2d)
        compressed_bytes = compressed["quantized"].nbytes + 4  # +4 for scale
        original_bytes = tensor_2d.nbytes
        assert compressed_bytes < original_bytes, (
            f"Compressed ({compressed_bytes}) should be smaller than original ({original_bytes})"
        )

    def test_compression_ratio_reported(self, tensor_2d):
        """Compression ratio is included in the compressed dict and is > 1."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(tensor_2d)
        assert "compression_ratio" in compressed
        assert compressed["compression_ratio"] > 1.0

    def test_1d_input(self, tensor_1d):
        """1D tensors are handled correctly through round-trip."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(tensor_1d)
        result = codec.decompress(compressed)
        assert result.shape == tensor_1d.shape
        max_val = np.max(np.abs(tensor_1d)) + 1e-8
        rel_error = np.max(np.abs(tensor_1d - result)) / max_val
        assert rel_error < 0.15

    def test_2d_input(self, tensor_2d):
        """2D tensors are handled correctly through round-trip."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(tensor_2d)
        result = codec.decompress(compressed)
        assert result.shape == tensor_2d.shape

    def test_1d_non_multiple_of_4(self):
        """1D tensor whose length is not a multiple of 4 works correctly."""
        t = np.random.randn(13).astype(np.float32)
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(t)
        result = codec.decompress(compressed)
        assert result.shape == t.shape

    def test_2d_non_multiple_of_4_last_dim(self):
        """2D tensor with last dim not multiple of 4 works correctly."""
        t = np.random.randn(5, 7).astype(np.float32)
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(t)
        result = codec.decompress(compressed)
        assert result.shape == t.shape

    def test_error_bound_respected(self, tensor_2d):
        """When error_bound is set, the reconstruction respects it or warns."""
        codec = BlockDCTCodec(quality=64, error_bound=0.05)
        compressed = codec.compress(tensor_2d)
        result = codec.decompress(compressed)
        # With quality=64 and error_bound=0.05, error should be controlled
        max_val = np.max(np.abs(tensor_2d)) + 1e-8
        rel_error = np.max(np.abs(tensor_2d - result)) / max_val
        # The codec logs a warning but does not refuse; we check that high quality
        # keeps the error reasonable
        assert rel_error < 0.10, f"Error {rel_error:.4f} too high with error_bound enabled"

    def test_error_bound_zero_no_check(self, tensor_2d):
        """With error_bound=0.0, no error checking occurs (still compresses fine)."""
        codec = BlockDCTCodec(quality=32, error_bound=0.0)
        compressed = codec.compress(tensor_2d)
        result = codec.decompress(compressed)
        assert result.shape == tensor_2d.shape

    def test_compressed_dict_keys(self, tensor_2d):
        """Compressed dict contains all expected keys."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(tensor_2d)
        expected_keys = {"quantized", "scale", "original_shape", "original_dtype",
                         "num_blocks", "compression_ratio"}
        assert set(compressed.keys()) == expected_keys

    def test_quantized_dtype_is_int8(self, tensor_2d):
        """Quantized coefficients are stored as int8."""
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(tensor_2d)
        assert compressed["quantized"].dtype == np.int8

    def test_zero_tensor(self):
        """Compressing a zero tensor does not crash."""
        t = np.zeros((4, 8), dtype=np.float32)
        codec = BlockDCTCodec(quality=32)
        compressed = codec.compress(t)
        result = codec.decompress(compressed)
        assert result.shape == t.shape
        np.testing.assert_allclose(result, t, atol=1e-6)


# ===========================================================================
# 2. TestAdaptiveCodec
# ===========================================================================

class TestAdaptiveCodec:

    def test_embedding_uses_tight_quality(self, tensor_2d):
        """Embedding type should use tight codec (higher quality, lower error)."""
        codec = AdaptiveCodec(tight_quality=64, loose_quality=16)
        compressed = codec.compress(tensor_2d, tensor_type="embedding")
        result = codec.decompress(compressed)
        max_val = np.max(np.abs(tensor_2d)) + 1e-8
        rel_error_tight = np.max(np.abs(tensor_2d - result)) / max_val

        compressed_loose = codec.compress(tensor_2d, tensor_type="activation")
        result_loose = codec.decompress(compressed_loose)
        rel_error_loose = np.max(np.abs(tensor_2d - result_loose)) / max_val

        assert rel_error_tight <= rel_error_loose, (
            f"Tight ({rel_error_tight:.4f}) should have <= error than loose ({rel_error_loose:.4f})"
        )

    def test_attention_uses_tight_quality(self, tensor_2d):
        """Attention type should also use tight codec."""
        codec = AdaptiveCodec(tight_quality=64, loose_quality=16)
        compressed = codec.compress(tensor_2d, tensor_type="attention")
        result = codec.decompress(compressed)
        max_val = np.max(np.abs(tensor_2d)) + 1e-8
        rel_error = np.max(np.abs(tensor_2d - result)) / max_val
        assert rel_error < 0.10, f"Attention (tight) error {rel_error:.4f} too high"

    def test_activation_uses_loose_quality(self, tensor_2d):
        """Generic activation uses loose codec (more aggressive compression)."""
        codec = AdaptiveCodec(tight_quality=64, loose_quality=16)
        compressed = codec.compress(tensor_2d, tensor_type="activation")
        result = codec.decompress(compressed)
        assert result.shape == tensor_2d.shape

    def test_gradient_uses_loose_quality(self, tensor_2d):
        """Gradient type uses loose codec."""
        codec = AdaptiveCodec(tight_quality=64, loose_quality=16)
        compressed = codec.compress(tensor_2d, tensor_type="gradient")
        result = codec.decompress(compressed)
        assert result.shape == tensor_2d.shape

    def test_roundtrip_preserves_shape(self, tensor_2d):
        """Adaptive codec preserves tensor shape through round-trip."""
        codec = AdaptiveCodec()
        for ttype in ("embedding", "attention", "activation", "gradient"):
            compressed = codec.compress(tensor_2d, tensor_type=ttype)
            result = codec.decompress(compressed)
            assert result.shape == tensor_2d.shape, f"Shape mismatch for type={ttype}"

    def test_default_quality_values(self):
        """Default tight=64, loose=16 matches docstring defaults."""
        codec = AdaptiveCodec()
        assert codec.tight.quality == 64
        assert codec.loose.quality == 16


# ===========================================================================
# 3. TestActivationCompressor
# ===========================================================================

class TestActivationCompressor:

    def test_roundtrip_preserves_shape(self, tensor_3d):
        """Compress/decompress round-trip preserves shape."""
        compressor = ActivationCompressor(quality=32, adaptive=False)
        compressed = compressor.compress(tensor_3d)
        result = compressor.decompress(compressed)
        assert result.shape == tensor_3d.shape

    def test_roundtrip_preserves_data(self, tensor_3d):
        """Reconstructed activation is close to original."""
        compressor = ActivationCompressor(quality=32, adaptive=False)
        compressed = compressor.compress(tensor_3d)
        result = compressor.decompress(compressed)
        max_val = np.max(np.abs(tensor_3d)) + 1e-8
        rel_error = np.max(np.abs(tensor_3d - result)) / max_val
        assert rel_error < 0.15

    def test_adaptive_roundtrip(self, tensor_3d):
        """Adaptive compressor round-trips correctly."""
        compressor = ActivationCompressor(quality=32, adaptive=True)
        compressed = compressor.compress(tensor_3d, layer_type="activation")
        result = compressor.decompress(compressed)
        assert result.shape == tensor_3d.shape

    def test_adaptive_embedding_type(self, tensor_2d):
        """Adaptive compressor handles embedding type."""
        compressor = ActivationCompressor(quality=32, adaptive=True)
        compressed = compressor.compress(tensor_2d, layer_type="embedding")
        result = compressor.decompress(compressed)
        assert result.shape == tensor_2d.shape

    def test_stats_tracking_calls(self, tensor_3d):
        """Statistics track number of compressed tensors."""
        compressor = ActivationCompressor(quality=32, adaptive=False)
        for _ in range(5):
            compressor.compress(tensor_3d)
        stats = compressor.get_stats()
        assert stats["tensors_compressed"] == 5

    def test_stats_tracking_bytes_saved(self, tensor_3d):
        """Statistics track bytes saved (should be positive for float32 -> int8)."""
        compressor = ActivationCompressor(quality=32, adaptive=False)
        compressor.compress(tensor_3d)
        stats = compressor.get_stats()
        assert stats["bytes_saved"] > 0, "Compression should save bytes"

    def test_stats_avg_ratio(self, tensor_3d):
        """Average compression ratio should be > 1."""
        compressor = ActivationCompressor(quality=32, adaptive=False)
        compressor.compress(tensor_3d)
        compressor.compress(tensor_3d)
        stats = compressor.get_stats()
        assert stats["avg_compression_ratio"] > 1.0

    def test_different_tensor_shapes(self):
        """Various tensor shapes are handled."""
        compressor = ActivationCompressor(quality=32, adaptive=False)
        shapes = [(16,), (4, 8), (2, 4, 8), (1, 2, 4, 16)]
        for shape in shapes:
            t = np.random.randn(*shape).astype(np.float32)
            compressed = compressor.compress(t)
            result = compressor.decompress(compressed)
            assert result.shape == shape, f"Shape mismatch for input shape {shape}"

    def test_compress_checkpoint(self):
        """compress_checkpoint handles a dict of named activations."""
        compressor = ActivationCompressor(quality=32, adaptive=True)
        activations = {
            "layer0.attn": np.random.randn(2, 8, 16).astype(np.float32),
            "layer0.ffn": np.random.randn(2, 8, 32).astype(np.float32),
            "layer1.attn": np.random.randn(2, 8, 16).astype(np.float32),
        }
        compressed = compressor.compress_checkpoint(activations)
        assert set(compressed.keys()) == set(activations.keys())

    def test_decompress_checkpoint(self):
        """decompress_checkpoint reconstructs all activations."""
        compressor = ActivationCompressor(quality=32, adaptive=True)
        activations = {
            "layer0.attn": np.random.randn(2, 8, 16).astype(np.float32),
            "layer0.ffn": np.random.randn(2, 8, 32).astype(np.float32),
        }
        compressed = compressor.compress_checkpoint(activations)
        decompressed = compressor.decompress_checkpoint(compressed)
        for name in activations:
            assert decompressed[name].shape == activations[name].shape

    def test_checkpoint_attn_vs_ffn_quality(self):
        """compress_checkpoint uses 'attention' type for layers with 'attn' in name."""
        compressor = ActivationCompressor(quality=16, adaptive=True)
        t = np.random.randn(2, 8, 16).astype(np.float32)
        activations = {
            "layer0.attn": t.copy(),
            "layer0.ffn": t.copy(),
        }
        compressed = compressor.compress_checkpoint(activations)
        # Both should compress without error; attn should use tight codec
        result_attn = compressor.decompress(compressed["layer0.attn"])
        result_ffn = compressor.decompress(compressed["layer0.ffn"])
        error_attn = np.max(np.abs(t - result_attn))
        error_ffn = np.max(np.abs(t - result_ffn))
        assert error_attn <= error_ffn, (
            f"attn error ({error_attn:.4f}) should be <= ffn error ({error_ffn:.4f})"
        )


# ===========================================================================
# 4. TestKVCacheCompressor
# ===========================================================================

class TestKVCacheCompressor:

    def test_page_roundtrip_shape(self, kv_page):
        """Compressed/decompressed KV page preserves shape."""
        k, v = kv_page
        compressor = KVCacheCompressor(quality=48, error_bound=0.01)
        compressed = compressor.compress_page(k, v)
        k_out, v_out = compressor.decompress_page(compressed)
        assert k_out.shape == k.shape
        assert v_out.shape == v.shape

    def test_page_roundtrip_data(self, kv_page):
        """Decompressed KV data is close to original."""
        k, v = kv_page
        compressor = KVCacheCompressor(quality=48, error_bound=0.01)
        compressed = compressor.compress_page(k, v)
        k_out, v_out = compressor.decompress_page(compressed)

        max_k = np.max(np.abs(k)) + 1e-8
        max_v = np.max(np.abs(v)) + 1e-8
        assert np.max(np.abs(k - k_out)) / max_k < 0.15
        assert np.max(np.abs(v - v_out)) / max_v < 0.15

    def test_compressed_page_has_keys(self, kv_page):
        """Compressed page dict has 'k', 'v', 'page_shape' keys."""
        k, v = kv_page
        compressor = KVCacheCompressor()
        compressed = compressor.compress_page(k, v)
        assert "k" in compressed
        assert "v" in compressed
        assert "page_shape" in compressed
        assert compressed["page_shape"] == k.shape

    def test_memory_savings_estimation_defaults(self):
        """estimate_savings returns sensible values with default ratio."""
        compressor = KVCacheCompressor()
        savings = compressor.estimate_savings(
            num_layers=32, num_kv_heads=8, page_size=128,
            head_dim=64, num_pages=100,
        )
        assert savings["uncompressed_mb"] > 0
        assert savings["compressed_mb"] > 0
        assert savings["compressed_mb"] < savings["uncompressed_mb"]
        assert 0 < savings["savings_pct"] < 100

    def test_memory_savings_with_compression_history(self, kv_page):
        """estimate_savings uses actual compression ratio after pages are compressed."""
        k, v = kv_page
        compressor = KVCacheCompressor(quality=48)
        compressor.compress_page(k, v)
        compressor.compress_page(k, v)

        savings = compressor.estimate_savings(
            num_layers=16, num_kv_heads=4, page_size=8,
            head_dim=16, num_pages=50,
        )
        assert savings["avg_compression_ratio"] > 0
        assert savings["savings_pct"] > 0

    def test_stats_pages_compressed(self, kv_page):
        """Statistics track number of pages compressed."""
        k, v = kv_page
        compressor = KVCacheCompressor()
        compressor.compress_page(k, v)
        compressor.compress_page(k, v)
        compressor.compress_page(k, v)
        stats = compressor.get_stats()
        assert stats["pages_compressed"] == 3

    def test_stats_avg_compression_ratio(self, kv_page):
        """Average compression ratio is > 1 after compressing pages."""
        k, v = kv_page
        compressor = KVCacheCompressor()
        compressor.compress_page(k, v)
        stats = compressor.get_stats()
        assert stats["avg_compression_ratio"] > 1.0

    def test_different_page_shapes(self):
        """Various KV page shapes are handled."""
        compressor = KVCacheCompressor(quality=48)
        shapes = [
            (1, 2, 4, 8),
            (2, 8, 16, 32),
            (1, 1, 4, 4),
        ]
        for shape in shapes:
            k = np.random.randn(*shape).astype(np.float32)
            v = np.random.randn(*shape).astype(np.float32)
            compressed = compressor.compress_page(k, v)
            k_out, v_out = compressor.decompress_page(compressed)
            assert k_out.shape == shape, f"K shape mismatch for {shape}"
            assert v_out.shape == shape, f"V shape mismatch for {shape}"


# ===========================================================================
# 5. TestCommunicationCompressor
# ===========================================================================

class TestCommunicationCompressor:

    def test_gradient_roundtrip_shape(self, gradient):
        """Compressed/decompressed gradient preserves shape."""
        compressor = CommunicationCompressor(quality=24, error_feedback=False)
        compressed = compressor.compress_gradient(gradient, name="layer0.weight")
        result = compressor.decompress_gradient(compressed)
        assert result.shape == gradient.shape

    def test_gradient_roundtrip_data(self, gradient):
        """Decompressed gradient is close to original."""
        compressor = CommunicationCompressor(quality=24, error_feedback=False)
        compressed = compressor.compress_gradient(gradient, name="layer0.weight")
        result = compressor.decompress_gradient(compressed)
        max_val = np.max(np.abs(gradient)) + 1e-8
        rel_error = np.max(np.abs(gradient - result)) / max_val
        assert rel_error < 0.20, f"Gradient error {rel_error:.4f} too high"

    def test_error_feedback_stores_residual(self, gradient):
        """With error_feedback=True, residuals are stored after compression."""
        compressor = CommunicationCompressor(quality=24, error_feedback=True)
        compressor.compress_gradient(gradient, name="param0")
        assert "param0" in compressor._residuals
        assert compressor._residuals["param0"].shape == gradient.shape

    def test_error_feedback_improves_over_rounds(self):
        """Error feedback should reduce cumulative error over multiple rounds."""
        compressor_ef = CommunicationCompressor(quality=16, error_feedback=True)
        compressor_no = CommunicationCompressor(quality=16, error_feedback=False)

        # Simulate multiple rounds of compressing the same gradient
        g = np.random.randn(64).astype(np.float32)
        cumulative_ef = np.zeros_like(g)
        cumulative_no = np.zeros_like(g)

        for _ in range(5):
            compressed_ef = compressor_ef.compress_gradient(g, name="p")
            result_ef = compressor_ef.decompress_gradient(compressed_ef)
            cumulative_ef += result_ef.astype(np.float32)

            compressed_no = compressor_no.compress_gradient(g, name="p")
            result_no = compressor_no.decompress_gradient(compressed_no)
            cumulative_no += result_no.astype(np.float32)

        target = g * 5
        error_ef = np.mean(np.abs(target - cumulative_ef))
        error_no = np.mean(np.abs(target - cumulative_no))

        # Error feedback should give at least as good cumulative accuracy
        assert error_ef <= error_no * 1.1, (
            f"Error feedback ({error_ef:.4f}) should be <= no-feedback ({error_no:.4f})"
        )

    def test_clear_residuals(self, gradient):
        """clear_residuals empties the residual store."""
        compressor = CommunicationCompressor(quality=24, error_feedback=True)
        compressor.compress_gradient(gradient, name="p0")
        compressor.compress_gradient(gradient, name="p1")
        assert len(compressor._residuals) == 2
        compressor.clear_residuals()
        assert len(compressor._residuals) == 0

    def test_compress_tensor_generic(self, tensor_2d):
        """compress_tensor / decompress_tensor for generic tensors."""
        compressor = CommunicationCompressor(quality=24)
        compressed = compressor.compress_tensor(tensor_2d)
        result = compressor.decompress_tensor(compressed)
        assert result.shape == tensor_2d.shape

    def test_stats_tensors_compressed(self, gradient):
        """Statistics track number of compressed gradients."""
        compressor = CommunicationCompressor(quality=24, error_feedback=False)
        for _ in range(4):
            compressor.compress_gradient(gradient, name="w")
        stats = compressor.get_stats()
        assert stats["tensors_compressed"] == 4

    def test_stats_compression_ratio(self, gradient):
        """Compression ratio should be > 1."""
        compressor = CommunicationCompressor(quality=24, error_feedback=False)
        compressor.compress_gradient(gradient, name="w")
        stats = compressor.get_stats()
        assert stats["compression_ratio"] > 1.0

    def test_stats_communication_saved(self, gradient):
        """communication_saved_pct should be positive."""
        compressor = CommunicationCompressor(quality=24, error_feedback=False)
        compressor.compress_gradient(gradient, name="w")
        stats = compressor.get_stats()
        assert stats["communication_saved_pct"] > 0

    def test_gradient_2d_shape(self):
        """2D gradient tensors compress/decompress correctly."""
        compressor = CommunicationCompressor(quality=24, error_feedback=False)
        g = np.random.randn(32, 64).astype(np.float32)
        compressed = compressor.compress_gradient(g, name="fc.weight")
        result = compressor.decompress_gradient(compressed)
        assert result.shape == g.shape

    def test_no_name_gradient(self, gradient):
        """Gradient compression works without a parameter name."""
        compressor = CommunicationCompressor(quality=24, error_feedback=True)
        compressed = compressor.compress_gradient(gradient)
        result = compressor.decompress_gradient(compressed)
        assert result.shape == gradient.shape

    def test_error_feedback_residual_applied(self):
        """Error feedback residual from round 1 is applied in round 2."""
        compressor = CommunicationCompressor(quality=16, error_feedback=True)
        g = np.ones(16, dtype=np.float32) * 0.5

        # Round 1: compress and record residual
        compressed1 = compressor.compress_gradient(g, name="p")
        result1 = compressor.decompress_gradient(compressed1)
        residual = compressor._residuals["p"].copy()

        # Round 2: residual should be added to the input before compression
        compressed2 = compressor.compress_gradient(g, name="p")
        # The effective input to round 2 was g + residual
        # Verify a new residual was computed (it changed from round 1)
        residual2 = compressor._residuals["p"]
        # Residuals should generally differ between rounds
        assert not np.allclose(residual, residual2, atol=1e-10) or np.allclose(residual, 0, atol=1e-10)
