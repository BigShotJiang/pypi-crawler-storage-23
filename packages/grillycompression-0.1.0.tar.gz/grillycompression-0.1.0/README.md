# GrillyCompression

Activation, KV-cache, and communication compression pipelines — optional [grilly](https://github.com/grillcheese/grilly) extension.

## Features

- **Block DCT Codec** — 4x4 DCT + scalar quantization with configurable error bounds
- **Activation Compression** — 30-60% VRAM savings on intermediate tensors
- **KV-Cache Compression** — 3-5x compression on cached K/V pages
- **Communication Compression** — 19-37% gradient volume reduction for multi-GPU
- **Adaptive Quality** — tight bounds for embeddings, looser for FFN activations
- **Error Feedback** — residual compression for gradient communication

## Quick Start

```bash
pip install grillycompression
```

```python
from grillycompression import BlockDCTCodec, ActivationCompressor, KVCacheCompressor

# Compress activations
compressor = ActivationCompressor(quality=32, adaptive=True)
compressed = compressor.compress(activation_tensor, layer_type="activation")
restored = compressor.decompress(compressed)

# Compress KV-cache pages
kv_comp = KVCacheCompressor(quality=48)
compressed_page = kv_comp.compress_page(k_data, v_data)
k_restored, v_restored = kv_comp.decompress_page(compressed_page)
```

## Requirements

- Python 3.12+
- grilly >= 0.4.0
- numpy

## License

MIT
