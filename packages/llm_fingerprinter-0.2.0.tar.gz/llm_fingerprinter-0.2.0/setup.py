#!/usr/bin/env python3
"""Backward-compatible setup.py - uses pyproject.toml for configuration."""
from setuptools import setup

setup()
