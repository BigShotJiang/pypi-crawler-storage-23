"""LLM Fingerprinter - Black-box LLM model identification system.

Fingerprints LLM responses using 75 discriminative prompts across three layers
(stylistic, behavioral, discriminative) to identify the underlying model family.
"""

__version__ = "0.2.0"
__author__ = "litemars"

from llm_fingerprinter.fingerprinter import LLMFingerprinter
from llm_fingerprinter.classifier import EnsembleClassifier, create_classifier
from llm_fingerprinter.feature_extractor import FeatureExtractor
from llm_fingerprinter.prompt_suite import PromptSuite
from llm_fingerprinter.fingerprint_store import FingerprintStore
from llm_fingerprinter.base_client import BaseClient, ClientError

__all__ = [
    "LLMFingerprinter",
    "EnsembleClassifier",
    "create_classifier",
    "FeatureExtractor",
    "PromptSuite",
    "FingerprintStore",
    "BaseClient",
    "ClientError",
    "__version__",
]
