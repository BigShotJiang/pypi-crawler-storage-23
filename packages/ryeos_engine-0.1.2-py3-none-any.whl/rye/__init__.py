"""RYE OS - AI operating system on Lillux microkernel."""

__version__ = "0.1.0"
