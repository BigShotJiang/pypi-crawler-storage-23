"""Directive handler module."""

from rye.handlers.directive.handler import DirectiveHandler

__all__ = ["DirectiveHandler"]
