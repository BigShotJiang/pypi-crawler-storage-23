The images here are actually embedded in various .ipynb files so that they render
correctly in various Notebook environments. (Referring to image files from Notebooks
is unreliable.)

You embed images using the "Edit > Insert Image" command in classic Jupyter. The option
does not appear to be available in JupyterLab.
