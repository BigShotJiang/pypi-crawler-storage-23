from seeq.spy.notifications._emails import send_email, EmailRecipient, EmailAttachment

__all__ = ['send_email', 'EmailRecipient', 'EmailAttachment']
