# 17.03.25

from .command.global_search import global_search as call_global_search

__all__ = [
    "call_global_search",
]