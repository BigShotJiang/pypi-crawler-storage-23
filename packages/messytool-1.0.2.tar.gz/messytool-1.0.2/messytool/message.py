from win10toast import ToastNotifier
def send(title,msg):
    toaster=ToastNotifier()
    toaster.show_toast(title,msg)
def send_warning(msg):
    toaster=ToastNotifier()
    toaster.show_toast('Warning',msg)
def send_error(msg):
    toaster=ToastNotifier()
    toaster.show_toast('Error',msg)
