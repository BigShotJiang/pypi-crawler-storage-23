from tkinter import *
root=Tk()
needcalc=StringVar()
needcalc.set('')
def press_normal_keys(key):
    needcalc.set(needcalc.get()+key)
def press_equal():
    try:
        needcalc.set(eval(needcalc.get()))
    except Exception:
        needcalc.set('CauculatorError')
    if len(str(eval(needcalc.get())))>=20:
        needcalc.set('LenOutOfDisplay')

def press_ce():
    needcalc.set('')
def press_bs():
    new_str=needcalc.get()[:-1]
    needcalc.set(new_str)
e1=Entry(root,textvariable=needcalc).grid(row=0,column=0,columnspan=4)
b1=Button(root,text='1',command=lambda:press_normal_keys('1'),bg='orange',width=5).grid(row=1,column=0)
b2=Button(root,text='2',command=lambda:press_normal_keys('2'),bg='orange',width=5).grid(row=1,column=1)
b3=Button(root,text='3',command=lambda:press_normal_keys('3'),bg='orange',width=5).grid(row=1,column=2)
bp=Button(root,text='+',command=lambda:press_normal_keys('+'),bg='blue',width=5).grid(row=1,column=3)
b4=Button(root,text='4',command=lambda:press_normal_keys('4'),bg='orange',width=5).grid(row=2,column=0)
b5=Button(root,text='5',command=lambda:press_normal_keys('5'),bg='orange',width=5).grid(row=2,column=1)
b6=Button(root,text='6',command=lambda:press_normal_keys('6'),bg='orange',width=5).grid(row=2,column=2)
bm=Button(root,text='-',command=lambda:press_normal_keys('-'),bg='blue',width=5).grid(row=2,column=3)
b7=Button(root,text='7',command=lambda:press_normal_keys('7'),bg='orange',width=5).grid(row=3,column=0)
b8=Button(root,text='8',command=lambda:press_normal_keys('8'),bg='orange',width=5).grid(row=3,column=1)
b9=Button(root,text='9',command=lambda:press_normal_keys('9'),bg='orange',width=5).grid(row=3,column=2)
bmu=Button(root,text='×',command=lambda:press_normal_keys('*'),bg='blue',width=5).grid(row=3,column=3)
b0=Button(root,text='0',command=lambda:press_normal_keys('0'),bg='orange',width=10).grid(row=4,column=0,columnspan=2)
bd=Button(root,text='÷',command=lambda:press_normal_keys('/'),bg='blue',width=10).grid(row=4,column=2,columnspan=2)
bdot=Button(root,text='.',command=lambda:press_normal_keys('.'),bg='orange',width=5).grid(row=5,column=0)
bcf=Button(root,text='**',command=lambda:press_normal_keys('**'),bg='blue',width=5).grid(row=5,column=1)
bqy=Button(root,text='%',command=lambda:press_normal_keys('%'),bg='blue',width=5).grid(row=5,column=2)
bzc=Button(root,text='//',command=lambda:press_normal_keys('//'),bg='blue',width=5).grid(row=5,column=3)
be=Button(root,text='=',command=press_equal,bg='cyan',width=20).grid(row=6,column=0,columnspan=4)
bce=Button(root,text='CE',command=press_ce,bg='purple',width=10).grid(row=7,column=0,columnspan=2)
bb=Button(root,text='<<',command=press_bs,bg='purple',width=10).grid(row=7,column=2,columnspan=2)
root.mainloop()
