from setuptools import setup,find_packages
setup(
    name='messytool',
    version='1.0.2',
    author='Ruize,Dai',
    author_email='a_cloudclear@163.com',
    description='Some useful tools...',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    packages=find_packages(),
    python_requires='>=3.5',
    install_requires=[],
)
    
