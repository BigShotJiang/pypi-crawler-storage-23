# SendCraft Python SDK

Official Python SDK for [SendCraft](https://sendcraft.online) — send transactional emails and campaigns via the SendCraft API.

## Installation

```bash
pip install sendcraft-sdk
```

## Quick Start

```python
import os
from sendcraft import SendCraft

client = SendCraft(api_key=os.environ["SENDCRAFT_API_KEY"])

result = client.send_email(
    to_email="user@example.com",
    subject="Hello from SendCraft",
    html_content="<h1>Hello!</h1><p>Welcome!</p>",
    from_email="noreply@yourdomain.com"
)

print(result)
```

## Environment Variables

```env
SENDCRAFT_API_KEY=sk_live_your_key_here
```

## Usage Examples

### Send Bulk Emails

```python
client.send_bulk_emails(
    emails=[
        {"toEmail": "user1@example.com", "toName": "John"},
        {"toEmail": "user2@example.com", "toName": "Jane"},
    ],
    subject="Weekly Newsletter",
    html_content="<h1>This week...</h1>",
    from_email="newsletter@yourdomain.com"
)
```

### Create Campaign

```python
client.create_campaign(
    name="Product Launch",
    subject="Big News!",
    html_content="<h1>Check it out!</h1>",
    from_email="marketing@yourdomain.com",
    recipients=["user1@example.com", "user2@example.com"]
)
```

### Error Handling

```python
from sendcraft import SendCraft, SendCraftError, UnauthorizedError, RateLimitError

try:
    client.send_email(...)
except UnauthorizedError:
    print("Invalid API key")
except RateLimitError:
    print("Too many requests")
except SendCraftError as e:
    print("Error:", e)
```

## API Reference

| Method | Description |
|--------|-------------|
| `send_email(...)` | Send a single email |
| `send_bulk_emails(...)` | Send to multiple recipients |
| `schedule_email(...)` | Schedule email for later |
| `get_email_stats()` | Get email statistics |
| `create_campaign(...)` | Create campaign |
| `get_campaigns(limit)` | List campaigns |
| `send_campaign(id)` | Send campaign |
| `create_template(...)` | Create template |
| `get_templates()` | List templates |
| `create_webhook(...)` | Create webhook |
| `get_analytics(id)` | Campaign analytics |
| `get_account()` | Account info |

## Support

- Website: https://sendcraft.online
- Email: support@sendcraft.online

## License

MIT
