"""
SendCraft SDK - Official Python Client
"""

from .client import SendCraft
from .exceptions import (
    SendCraftError,
    UnauthorizedError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    ServerError
)

__version__ = "1.0.0"
__author__ = "SendCraft Team"
__all__ = [
    "SendCraft",
    "SendCraftError",
    "UnauthorizedError",
    "ForbiddenError",
    "NotFoundError",
    "RateLimitError",
    "ServerError"
]
