"""
SendCraft SDK Exceptions
"""


class SendCraftError(Exception):
    """Base exception for SendCraft SDK errors"""
    pass


class UnauthorizedError(SendCraftError):
    """Raised when API key is invalid or missing"""
    pass


class ForbiddenError(SendCraftError):
    """Raised when user doesn't have permission"""
    pass


class NotFoundError(SendCraftError):
    """Raised when requested resource is not found"""
    pass


class RateLimitError(SendCraftError):
    """Raised when rate limit is exceeded"""
    pass


class ServerError(SendCraftError):
    """Raised when server returns 5xx error"""
    pass
