# ONQL Python Client

This is the ONQL Python client package.

## Installation

```bash
pip install onql-client
```

## Usage

```python
from onqlclient import ... # your usage here
```
