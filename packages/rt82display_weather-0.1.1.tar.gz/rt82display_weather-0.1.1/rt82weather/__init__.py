"""RT82 Weather - Weather display for Epomaker RT82 keyboard LCD screen."""

try:
    from ._version import __version__
except ModuleNotFoundError:
    __version__ = "dev"
