ERROR_BADGE = "[bold red]ERROR[/bold red]"
SUCCESS_BADGE = "[green]SUCCESS[/green]"
FAILED_BADGE = "[bold red]FAILED[/bold red]"
