# CHOMPACK — library for chordal matrix computations

[![License](https://img.shields.io/badge/license-GPL3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.en.html)
[![GitHub release](https://img.shields.io/github/release/cvxopt/chompack.svg)](https://github.com/cvxopt/chompack/releases/latest)
[![PyPI](https://img.shields.io/pypi/v/chompack.svg)](https://pypi.python.org/pypi/chompack)
[![Documentation Status](https://readthedocs.org/projects/chompack/badge/?version=latest)](http://chompack.readthedocs.io/en/latest/?badge=latest)

## Documentation

Documentation available at http://chompack.readthedocs.io


## Quick Install

```
pip install chompack
```

## License
CHOMPACK is licensed under the GNU General Public License version 3 (GPL-3.0-or-later). See [LICENSE](LICENSE) for details.