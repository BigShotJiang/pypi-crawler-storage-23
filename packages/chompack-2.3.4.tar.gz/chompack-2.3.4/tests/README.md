Chompack test cases
=====================

Run all tests with the following command:
```bash
cd tests/
python -m unittest discover . -v
```
