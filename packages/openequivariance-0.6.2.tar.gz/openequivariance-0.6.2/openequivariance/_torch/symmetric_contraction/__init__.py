from openequivariance._torch.symmetric_contraction.symmetric_contraction import (
    SymmetricContraction,
)

__all__ = ["SymmetricContraction"]
