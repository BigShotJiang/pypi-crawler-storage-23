#
# This is an auto-generated file.  DO NOT EDIT!
#

from ansys.systemcoupling.core.adaptor.impl.types import *


class solve_with_plot(InjectedCommand):
    """
    Solves, showing a live plot of transfer values and convergence for data transfers
    of a coupling interface.

    .. note::
        This functionality is experimental and is still being developed. The API
        and behavior are subject to change.

    Note that although the optional arguments are somewhat complex to describe, the
    common use cases are relatively straightforward to use. The complexity exists
    to provide flexibility for more complex use cases.

    If there is a single interface, and charts are needed on all transfers,
    then no arguments are needed. The transfer list can be filtered by optionally
    providing `transfer_names`, to specify a list of transfers to be included.

    If there are multiple interfaces, then `interface_name` can be provided
    to select a single interface, and again `transfer_names` may be provided as
    a filter.

    There are no other situations where it is valid to provide `interface_name`
    and/or `transfer_names`.

    If there are multiple interfaces, and no filtering is required, no arguments
    are needed.

    If there are multiple interfaces, and all transfers are needed on some
    interfaces, then `interface_names` may be provided to select those interfaces.
    In this case there is no filtering of transfers.

    For full control, `interface_and_transfer_names` may be provided to specify
    exactly which interfaces and which transfers on those interfaces are needed.
    This takes the form of a dictionary, mapping an interface name either to a list of
    transfer names or to `None`. `None` here is a concise way to indicate that all
    transfers on that interface are needed.

    Parameters
    ----------
    interface_name : str, optional
        Specification of which interface to plot. Defaults to ``None``.

        Cannot be used if `interface_names` or `interface_and_transfer_names`
        is provided.
    interface_names : List, optional
        Specification of which interfaces to plot. Defaults to ``None``.

        Cannot be used if `interface_name` or `interface_and_transfer_names`
        is provided.
    transfer_names : List, optional
        Specification of which data transfers to plot. Defaults
        to ``None``, which means plot all data transfers.

        Can only be used if there is a single interface in the analysis, or
        if a single interface is selected via `interface_name` or `interface_names`.
    interface_and_transfer_names : Dict, optional
        Specification of which interfaces and data transfers to plot. Defaults
        to ``None``.

        Can only be used if `interface_name`, `interface_names`, and
        `transfer_names` are not provided and allows for full specification
        of which interfaces and which transfers to plot in the form of a dictionary
        mapping interface names to lists of transfer names. Additionally, the list
        of transfer names may be None to indicate that all transfers on that interface
        are to be plotted.
    working_dir : str, optional
        Working directory (defaults = ".").
    show_convergence : bool, optional
        Whether to show convergence plots (defaults to ``True``).
    show_transfer_values : bool, optional
        Whether to show transfer value plots (defaults to ``True``).

    """

    syc_name = "solve_with_plot"

    cmd_name = "solve_with_plot"

    argument_names = [
        "interface_name",
        "interface_names",
        "transfer_names",
        "interface_and_transfer_names",
        "working_dir",
        "show_convergence",
        "show_transfer_values",
    ]

    class interface_name(String):
        """
        Specification of which interface to plot. Defaults to ``None``.

        Cannot be used if `interface_names` or `interface_and_transfer_names`
        is provided.
        """

        syc_name = "interface_name"

    class interface_names(StringList):
        """
        Specification of which interfaces to plot. Defaults to ``None``.

        Cannot be used if `interface_name` or `interface_and_transfer_names`
        is provided.
        """

        syc_name = "interface_names"

    class transfer_names(StringList):
        """
        Specification of which data transfers to plot. Defaults
        to ``None``, which means plot all data transfers.

        Can only be used if there is a single interface in the analysis, or
        if a single interface is selected via `interface_name` or `interface_names`.
        """

        syc_name = "transfer_names"

    class interface_and_transfer_names(StringListOrNoneDict):
        """
        Specification of which interfaces and data transfers to plot. Defaults
        to ``None``.

        Can only be used if `interface_name`, `interface_names`, and
        `transfer_names` are not provided and allows for full specification
        of which interfaces and which transfers to plot in the form of a dictionary
        mapping interface names to lists of transfer names. Additionally, the list
        of transfer names may be None to indicate that all transfers on that interface
        are to be plotted.
        """

        syc_name = "interface_and_transfer_names"

    class working_dir(String):
        """
        Working directory (defaults = ".").
        """

        syc_name = "working_dir"

    class show_convergence(Boolean):
        """
        Whether to show convergence plots (defaults to ``True``).
        """

        syc_name = "show_convergence"

    class show_transfer_values(Boolean):
        """
        Whether to show transfer value plots (defaults to ``True``).
        """

        syc_name = "show_transfer_values"
