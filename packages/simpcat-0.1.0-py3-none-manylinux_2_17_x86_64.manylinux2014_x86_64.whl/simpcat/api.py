"""Thin Python wrapper for the Simpcat public REST API.

Provides typed access to metrics, assets, and metadata endpoints.
No external dependencies — uses only stdlib (urllib, json, tomllib).

Example::

    from simpcat import Api

    api = Api()  # reads creds from SIMPCAT_API_KEY / ~/.simpcat/config.toml
    runs = api.runs(project="default")
    for run in runs:
        print(run["name"])
"""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Iterator
from urllib.error import HTTPError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

_DEFAULT_HOST = "simpcat.ai"
_CHUNK_SIZE = 65_536  # 64 KiB


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class ApiError(Exception):
    """Structured error from the Simpcat API.

    Attributes:
        code: Machine-readable error code (e.g. ``"not_found"``).
        message: Human-readable description.
        status: HTTP status code.
    """

    def __init__(self, code: str, message: str, status: int) -> None:
        self.code = code
        self.message = message
        self.status = status
        super().__init__(f"[{status}] {code}: {message}")


# ---------------------------------------------------------------------------
# Config resolution helpers (ports Rust config.rs logic)
# ---------------------------------------------------------------------------

def _strip_scheme(url: str) -> str:
    """Strip ``https://`` or ``http://`` and trailing ``/``."""
    for prefix in ("https://", "http://"):
        if url.startswith(prefix):
            url = url[len(prefix):]
            break
    return url.rstrip("/")


def _find_config_file() -> Path | None:
    """Walk up from CWD for ``simpcat.toml``, then check ``~/.simpcat/config.toml``."""
    # 1. SIMPCAT_CONFIG env var
    env_path = os.environ.get("SIMPCAT_CONFIG")
    if env_path:
        p = Path(env_path)
        if p.exists():
            return p

    # 2. Walk up from CWD
    try:
        cwd = Path.cwd()
    except OSError:
        cwd = None
    if cwd is not None:
        d: Path | None = cwd
        while d is not None:
            candidate = d / "simpcat.toml"
            if candidate.exists():
                return candidate
            parent = d.parent
            d = parent if parent != d else None

    # 3. ~/.simpcat/config.toml
    home = Path.home()
    user_config = home / ".simpcat" / "config.toml"
    if user_config.exists():
        return user_config

    return None


def _parse_config_toml(text: str) -> dict[str, str]:
    """Extract ``[hosts."<bare_host>"]`` → ``api_key`` mappings from TOML.

    Uses ``tomllib`` on 3.11+. Falls back to a minimal regex parser on 3.10
    (only handles the ``[hosts."..."] / api_key = "..."`` pattern we need).
    """
    if sys.version_info >= (3, 11):
        import tomllib
        data = tomllib.loads(text)
        hosts = data.get("hosts", {})
        return {k: v["api_key"] for k, v in hosts.items() if "api_key" in v}

    # Minimal fallback for 3.10
    result: dict[str, str] = {}
    current_host: str | None = None
    for line in text.splitlines():
        line = line.strip()
        # Match [hosts."hostname"]
        m = re.match(r'^\[hosts\."([^"]+)"\]$', line)
        if m:
            current_host = m.group(1)
            continue
        # Match api_key = "value" under a [hosts."..."] section
        if current_host is not None:
            m = re.match(r'^api_key\s*=\s*"([^"]*)"$', line)
            if m:
                result[current_host] = m.group(1)
                current_host = None
                continue
            # New section header → reset
            if line.startswith("["):
                current_host = None
    return result


def _resolve_api_key(host: str) -> str:
    """Resolve API key: env var → config file → error."""
    env_key = os.environ.get("SIMPCAT_API_KEY")
    if env_key:
        return env_key

    config_path = _find_config_file()
    if config_path is not None:
        try:
            text = config_path.read_text()
        except OSError:
            text = ""
        hosts = _parse_config_toml(text)
        bare_host = _strip_scheme(host)
        if bare_host in hosts:
            return hosts[bare_host]

    bare_host = _strip_scheme(host)
    raise ApiError(
        code="auth_missing",
        message=(
            f"No API key found for host '{bare_host}'. "
            "Set SIMPCAT_API_KEY or run `simpcat login`."
        ),
        status=0,
    )


# ---------------------------------------------------------------------------
# URL derivation (ports Rust ApiEndpoints logic)
# ---------------------------------------------------------------------------

def _derive_urls(host: str) -> tuple[str, str, str]:
    """Derive (metrics_url, assets_url, metadata_url) from host.

    - localhost → all same URL
    - ``app.simpcat.ai`` → ``https://metrics.simpcat.ai``, etc.
    - ``app-pr5.sampcat.dev`` → ``https://metrics-pr5.sampcat.dev``, etc.

    Env var overrides: ``SIMPCAT_METRICS_URL``, ``SIMPCAT_ASSETS_URL``,
    ``SIMPCAT_METADATA_URL``.
    """
    # Ensure host has a scheme
    if host.startswith("http://") or host.startswith("https://"):
        base_url = host.rstrip("/")
    else:
        base_url = f"https://{host}".rstrip("/")

    bare = _strip_scheme(host)

    if bare.startswith("localhost") or bare.startswith("127.0.0.1"):
        metrics_url = base_url
        assets_url = base_url
        metadata_url = base_url
    else:
        # Strip "app" prefix: "app.simpcat.ai" → ".simpcat.ai"
        #                      "app-pr5.sampcat.dev" → "-pr5.sampcat.dev"
        scheme = "https"
        if host.startswith("http://"):
            scheme = "http"

        suffix = bare
        if suffix.startswith("app.") or suffix.startswith("app-"):
            suffix = suffix[3:]  # "app.simpcat.ai" → ".simpcat.ai"
        else:
            suffix = "." + suffix  # "simpcat.ai" → ".simpcat.ai"

        metrics_url = f"{scheme}://metrics{suffix}"
        assets_url = f"{scheme}://assets{suffix}"
        metadata_url = f"{scheme}://metadata{suffix}"

    # Env var overrides (ignore empty values, strip trailing slashes)
    env_metrics = os.environ.get("SIMPCAT_METRICS_URL")
    if env_metrics:
        metrics_url = env_metrics.rstrip("/")
    env_assets = os.environ.get("SIMPCAT_ASSETS_URL")
    if env_assets:
        assets_url = env_assets.rstrip("/")
    env_metadata = os.environ.get("SIMPCAT_METADATA_URL")
    if env_metadata:
        metadata_url = env_metadata.rstrip("/")

    return metrics_url, assets_url, metadata_url


# ---------------------------------------------------------------------------
# RunPage — lightweight pagination wrapper
# ---------------------------------------------------------------------------

class RunPage:
    """A page of runs from the ``/v1/metadata/runs`` endpoint.

    Attributes:
        data: List of run dicts.
        has_more: Whether another page exists.
        cursor: Opaque cursor for fetching the next page (``None`` if last page).
    """

    def __init__(self, data: list[dict], has_more: bool, cursor: str | None,
                 _fetch_next: Any = None) -> None:
        self.data = data
        self.has_more = has_more
        self.cursor = cursor
        self._fetch_next = _fetch_next

    def next_page(self) -> RunPage:
        """Fetch the next page. Raises ``StopIteration`` if no more pages."""
        if not self.has_more or self._fetch_next is None:
            raise StopIteration("No more pages")
        return self._fetch_next(self.cursor)

    def __iter__(self) -> Iterator[dict]:
        return iter(self.data)

    def __len__(self) -> int:
        return len(self.data)

    def __repr__(self) -> str:
        return f"RunPage(len={len(self.data)}, has_more={self.has_more})"


# ---------------------------------------------------------------------------
# Api — main client class
# ---------------------------------------------------------------------------

class Api:
    """Python client for the Simpcat public REST API.

    Args:
        api_key: API key. Falls back to ``SIMPCAT_API_KEY`` env var, then
            ``~/.simpcat/config.toml``.
        host: Server host (e.g. ``app.simpcat.ai``). Falls back to
            ``SIMPCAT_HOST`` env var, then the default production host.
        timeout: HTTP request timeout in seconds.
    """

    def __init__(
        self,
        api_key: str | None = None,
        host: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self._host = host or os.environ.get("SIMPCAT_HOST", _DEFAULT_HOST)
        self._host = self._host.rstrip("/")
        self._api_key = api_key or _resolve_api_key(self._host)
        self._timeout = timeout

        metrics_url, assets_url, metadata_url = _derive_urls(self._host)
        self._metrics_url = metrics_url
        self._assets_url = assets_url
        self._metadata_url = metadata_url

    # -- Internal HTTP helpers ------------------------------------------------

    def _request(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        body: dict | list | None = None,
        accept: str | None = None,
        output: str | Path | None = None,
    ) -> dict | str | bytes | Path:
        if params:
            # Filter out None values
            filtered = {k: v for k, v in params.items() if v is not None}
            if filtered:
                url = f"{url}?{urlencode(filtered, doseq=True)}"

        headers: dict[str, str] = {
            "Authorization": f"Bearer {self._api_key}",
        }
        if accept:
            headers["Accept"] = accept

        data: bytes | None = None
        if body is not None:
            data = json.dumps(body).encode()
            headers["Content-Type"] = "application/json"

        req = Request(url, data=data, headers=headers, method=method)

        try:
            resp = urlopen(req, timeout=self._timeout)
        except HTTPError as exc:
            _raise_api_error(exc)

        try:
            # Stream to file if output is provided
            if output is not None:
                out_path = Path(output)
                out_path.parent.mkdir(parents=True, exist_ok=True)
                with open(out_path, "wb") as f:
                    while True:
                        chunk = resp.read(_CHUNK_SIZE)
                        if not chunk:
                            break
                        f.write(chunk)
                return out_path

            raw = resp.read()
            content_type = resp.headers.get("Content-Type", "")
        finally:
            resp.close()

        # Parse based on content type
        if "application/json" in content_type:
            return json.loads(raw)
        if "text/csv" in content_type or "text/plain" in content_type:
            return raw.decode("utf-8")
        # Binary formats: parquet, arrow, octet-stream
        return raw

    def _get(self, url: str, **kwargs: Any) -> dict | str | bytes | Path:
        return self._request("GET", url, **kwargs)

    def _post(self, url: str, **kwargs: Any) -> dict | str | bytes | Path:
        return self._request("POST", url, **kwargs)

    # -- Metrics endpoints (/v1/metrics/) ------------------------------------

    def metric_names(self, run_id: str) -> dict:
        """List metric names for a run.

        Returns:
            Dict with ``"metric_names"`` key containing a list of strings.
        """
        url = f"{self._metrics_url}/v1/metrics/runs/{quote(run_id, safe='')}"
        return self._get(url)  # type: ignore[return-value]

    def metric(
        self,
        run_id: str,
        name: str,
        *,
        format: str = "json",
        resolution: int | None = None,
        after_step: int | None = None,
        limit: int | None = None,
        output: str | Path | None = None,
    ) -> dict | str | bytes | Path:
        """Fetch a single metric's data.

        Args:
            run_id: Run identifier.
            name: Metric name.
            format: Response format — ``"json"``, ``"csv"``, ``"parquet"``,
                ``"arrow"``, or ``"arrow_stream"``.
            resolution: Max number of data points to return.
            after_step: Only return steps after this value.
            limit: Max rows.
            output: Path to stream response to disk (returns ``Path``).

        Returns:
            ``dict`` for json, ``str`` for csv, ``bytes`` for binary formats,
            or ``Path`` when ``output`` is provided.
        """
        url = (
            f"{self._metrics_url}/v1/metrics/runs/"
            f"{quote(run_id, safe='')}/{quote(name, safe='')}"
        )
        accept = _format_to_accept(format)
        return self._get(
            url,
            params={"resolution": resolution, "after_step": after_step, "limit": limit},
            accept=accept,
            output=output,
        )

    def metrics(
        self,
        runs: list[str],
        *,
        metrics: list[str] | None = None,
        format: str = "json",
        resolution: int | None = None,
        step_range: tuple[int, int] | None = None,
        limit: int | None = None,
        output: str | Path | None = None,
    ) -> dict | str | bytes | Path:
        """Query metrics across multiple runs.

        Args:
            runs: List of run IDs.
            metrics: Metric names to include (all if ``None``).
            format: Response format.
            resolution: Max data points per metric.
            step_range: ``(min_step, max_step)`` filter.
            limit: Max rows.
            output: Path to stream response to disk.
        """
        url = f"{self._metrics_url}/v1/metrics/query"
        body: dict[str, Any] = {"run_ids": runs, "format": format}
        if metrics is not None:
            body["metrics"] = metrics
        if resolution is not None:
            body["resolution"] = resolution
        if step_range is not None:
            body["step_range"] = {"min": step_range[0], "max": step_range[1]}
        if limit is not None:
            body["limit"] = limit
        accept = _format_to_accept(format)
        return self._post(url, body=body, accept=accept, output=output)

    # -- Assets endpoints (/v1/assets/) --------------------------------------

    def media(self, run_id: str) -> list[dict]:
        """List media assets for a run."""
        url = f"{self._assets_url}/v1/assets/runs/{quote(run_id, safe='')}/media"
        return self._get(url)  # type: ignore[return-value]

    def files(self, run_id: str) -> list[dict]:
        """List file assets for a run."""
        url = f"{self._assets_url}/v1/assets/runs/{quote(run_id, safe='')}/files"
        return self._get(url)  # type: ignore[return-value]

    def assets(
        self,
        runs: list[str],
        *,
        types: list[str] | None = None,
        step_range: tuple[int, int] | None = None,
    ) -> dict:
        """Query assets across multiple runs."""
        url = f"{self._assets_url}/v1/assets/query"
        body: dict[str, Any] = {"run_ids": runs}
        if types is not None:
            body["types"] = types
        if step_range is not None:
            body["step_range"] = {"min": step_range[0], "max": step_range[1]}
        return self._post(url, body=body)  # type: ignore[return-value]

    # -- Metadata endpoints (/v1/metadata/) ----------------------------------

    def projects(self) -> list[dict]:
        """List all projects."""
        url = f"{self._metadata_url}/v1/metadata/projects"
        return self._get(url)  # type: ignore[return-value]

    def runs(
        self,
        *,
        project: str | None = None,
        status: str | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> RunPage:
        """List runs with pagination.

        Args:
            project: Filter by project name.
            status: Filter by status (e.g. ``"running"``, ``"finished"``).
            limit: Page size.
            cursor: Pagination cursor from a previous ``RunPage``.
        """
        url = f"{self._metadata_url}/v1/metadata/runs"
        params: dict[str, Any] = {
            "project": project,
            "status": status,
            "limit": limit,
            "cursor": cursor,
        }
        result = self._get(url, params=params)
        if not isinstance(result, dict):
            raise ApiError(
                code="invalid_response",
                message="Expected JSON object from /v1/metadata/runs",
                status=0,
            )
        return RunPage(
            data=result.get("data", result.get("runs", [])),
            has_more=result.get("has_more", False),
            cursor=result.get("cursor"),
            _fetch_next=lambda c: self.runs(
                project=project, status=status, limit=limit, cursor=c
            ),
        )

    def run(self, run_id: str) -> dict:
        """Get a single run's metadata."""
        url = f"{self._metadata_url}/v1/metadata/runs/{quote(run_id, safe='')}"
        return self._get(url)  # type: ignore[return-value]

    # -- Convenience -----------------------------------------------------------

    def all_runs(
        self,
        *,
        project: str | None = None,
        status: str | None = None,
    ) -> list[dict]:
        """Fetch all runs, exhausting pagination."""
        result: list[dict] = []
        page = self.runs(project=project, status=status)
        result.extend(page.data)
        while page.has_more:
            page = page.next_page()
            result.extend(page.data)
        return result


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _format_to_accept(fmt: str) -> str:
    """Map format string to HTTP Accept header value."""
    mapping = {
        "json": "application/json",
        "csv": "text/csv",
        "parquet": "application/vnd.apache.parquet",
        "arrow": "application/vnd.apache.arrow.file",
        "arrow_stream": "application/vnd.apache.arrow.stream",
    }
    return mapping.get(fmt, "application/json")


def _raise_api_error(exc: HTTPError) -> None:
    """Convert an HTTPError into an ApiError."""
    try:
        raw = exc.read()
        data = json.loads(raw)
        err = data.get("error", data)
        code = err.get("code", "unknown")
        message = err.get("message", str(data))
    except (json.JSONDecodeError, AttributeError):
        code = "http_error"
        message = raw.decode("utf-8", errors="replace") if raw else str(exc)
    raise ApiError(code=code, message=message, status=exc.code) from exc
