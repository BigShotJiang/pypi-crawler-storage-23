"""Histogram — wraps histogram data for logging."""

from __future__ import annotations

from typing import Any


class Histogram:
    """Wraps histogram data for logging. Compatible with wandb.Histogram."""

    MAX_BINS = 512

    def __init__(
        self,
        sequence: Any = None,
        np_histogram: tuple | None = None,
        num_bins: int = 64,
    ) -> None:
        if np_histogram is not None:
            counts, bin_edges = np_histogram
            self.counts = list(counts)
            self.bin_edges = list(bin_edges)
        elif sequence is not None:
            import numpy as np
            data = np.asarray(sequence, dtype=np.float64).ravel()
            num_bins = min(num_bins, self.MAX_BINS)
            counts, bin_edges = np.histogram(data, bins=num_bins)
            self.counts = counts.tolist()
            self.bin_edges = bin_edges.tolist()
        else:
            raise ValueError("Either sequence or np_histogram required")

        if len(self.bin_edges) != len(self.counts) + 1:
            raise ValueError(
                f"bin_edges length ({len(self.bin_edges)}) must be "
                f"counts length + 1 ({len(self.counts) + 1})"
            )
