"""Capture git provenance info at run init time."""

from __future__ import annotations

import subprocess
from typing import Any


def get_git_info() -> dict[str, Any] | None:
    """Capture git commit hash, branch, remote, and dirty status.

    Returns None if not in a git repo or git is not available.
    """
    try:
        subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            capture_output=True,
            check=True,
        )
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None

    info: dict[str, Any] = {}

    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True, text=True, check=True,
        )
        info["commit"] = result.stdout.strip()
    except subprocess.CalledProcessError:
        pass

    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, check=True,
        )
        info["branch"] = result.stdout.strip()
    except subprocess.CalledProcessError:
        pass

    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True, text=True, check=True,
        )
        info["remote"] = result.stdout.strip()
    except subprocess.CalledProcessError:
        pass

    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, check=True,
        )
        info["dirty"] = len(result.stdout.strip()) > 0
    except subprocess.CalledProcessError:
        pass

    try:
        result = subprocess.run(
            ["git", "diff", "HEAD", "--stat"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0 and result.stdout.strip():
            info["diff_stat"] = result.stdout.strip()
    except (subprocess.SubprocessError, FileNotFoundError):
        pass

    return info if info else None
