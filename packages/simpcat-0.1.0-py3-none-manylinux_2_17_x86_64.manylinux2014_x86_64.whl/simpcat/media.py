"""Audio and Image media classes for simpcat."""

from __future__ import annotations

from typing import Any

import numpy as np


class Audio:
    """Wraps audio data for logging. Compatible with wandb.Audio interface."""

    def __init__(
        self,
        data_or_path: np.ndarray | str,
        caption: str = "",
        sample_rate: int = 22050,
    ) -> None:
        if isinstance(data_or_path, str):
            self._path = data_or_path
            self._data = None
        else:
            self._path = None
            self._data = np.asarray(data_or_path, dtype=np.float32)
        self.caption = caption
        self.sample_rate = sample_rate

    def save(self, path: str) -> None:
        """Write audio data to a WAV file."""
        import soundfile as sf

        if self._data is not None:
            sf.write(path, self._data, self.sample_rate)
        elif self._path is not None:
            import shutil
            shutil.copy2(self._path, path)


class Image:
    """Wraps image data for logging. Compatible with wandb.Image interface."""

    def __init__(
        self,
        data_or_path: np.ndarray | Any | str,
        caption: str = "",
    ) -> None:
        if isinstance(data_or_path, str):
            self._path = data_or_path
            self._data = None
        elif isinstance(data_or_path, np.ndarray):
            self._data = data_or_path
            self._path = None
        else:
            # Assume PIL Image
            self._data = data_or_path
            self._path = None
        self.caption = caption

    def save(self, path: str) -> None:
        """Write image data to a PNG file."""
        if self._path is not None:
            import shutil
            shutil.copy2(self._path, path)
        elif isinstance(self._data, np.ndarray):
            from PIL import Image as PILImage
            arr = self._data
            if arr.dtype.kind == 'f' and arr.min() >= 0.0 and arr.max() <= 1.0:
                arr = (arr * 255).clip(0, 255).astype(np.uint8)
            img = PILImage.fromarray(arr)
            img.save(path)
        else:
            # Assume PIL Image object
            self._data.save(path)
