"""Spawn a per-run simpcat daemon."""

from __future__ import annotations

import os
import shutil
import subprocess
import time
import warnings
from pathlib import Path

DEFAULT_HOST = "simpcat.ai"


def _find_daemon_binary() -> str | None:
    """Locate the simpcat binary."""
    explicit = os.environ.get("SIMPCAT_CLI_PATH")
    if explicit and os.path.isfile(explicit):
        return explicit

    on_path = shutil.which("simpcat")
    if on_path:
        return on_path

    return None


def spawn_run_daemon(run_dir: Path, run_id: str) -> tuple[subprocess.Popen, str]:
    """Spawn a per-run daemon process.

    Returns (process, socket_path).
    Raises RuntimeError on failure.
    """
    binary = _find_daemon_binary()
    if binary is None:
        raise RuntimeError(
            "simpcat: 'simpcat' binary not found. "
            "Install it or set SIMPCAT_CLI_PATH=/path/to/simpcat."
        )

    cmd = [binary, "daemon", "--run-dir", str(run_dir), "--run-id", run_id]

    env = os.environ.copy()

    stderr_path = run_dir / "logs" / "daemon_stderr.log"
    stderr_path.parent.mkdir(parents=True, exist_ok=True)
    stderr_file = open(stderr_path, "w")

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=stderr_file,
            stdin=subprocess.PIPE,
            start_new_session=True,
            env=env,
        )
    except OSError as e:
        stderr_file.close()
        raise RuntimeError(f"simpcat: failed to start daemon: {e}") from e

    # Determine socket path: daemon.sock in run_dir, or read socket.path for fallback
    socket_path = str(run_dir / "daemon.sock")
    socket_path_file = run_dir / "socket.path"

    # Wait for socket to appear (3s)
    deadline = time.monotonic() + 3.0
    while time.monotonic() < deadline:
        # Check if daemon wrote a fallback socket.path file
        if socket_path_file.exists():
            socket_path = socket_path_file.read_text().strip()

        if os.path.exists(socket_path):
            stderr_file.close()
            return (proc, socket_path)

        if proc.poll() is not None:
            stderr_file.close()
            stderr_output = stderr_path.read_text().strip()
            msg = f"simpcat: daemon exited immediately (code {proc.returncode})."
            if stderr_output:
                msg += f"\n{stderr_output}"
            else:
                msg += f"\nCheck {run_dir / 'logs' / 'debug.log'} for errors."
            raise RuntimeError(msg)

        time.sleep(0.05)

    # Kill the unresponsive process
    proc.kill()
    proc.wait()
    stderr_file.close()
    stderr_output = stderr_path.read_text().strip()
    msg = "simpcat: daemon started but socket not available after 3s."
    if stderr_output:
        msg += f"\n{stderr_output}"
    else:
        msg += f"\nCheck {run_dir / 'logs' / 'debug.log'} for errors."
    raise RuntimeError(msg)
