"""Console output capture — TeeStream for stdout/stderr."""

from __future__ import annotations

import io
import sys
import threading
from pathlib import Path
from typing import Any


class TeeStream(io.TextIOBase):
    """Wraps a stream to tee output to both the original and a buffer."""

    def __init__(self, original: Any, buffer: OutputBuffer, stream_name: str) -> None:
        self._original = original
        self._buffer = buffer
        self._stream_name = stream_name

    def write(self, text: str) -> int:
        result = self._original.write(text)
        if text:
            self._buffer.append(text, self._stream_name)
        return result if result is not None else len(text)

    def flush(self) -> None:
        self._original.flush()

    def fileno(self) -> int:
        return self._original.fileno()

    def isatty(self) -> bool:
        return self._original.isatty()

    @property
    def encoding(self) -> str:
        return getattr(self._original, "encoding", "utf-8")


class OutputBuffer:
    """Thread-safe buffer that accumulates output and flushes periodically."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._chunks: list[tuple[str, str]] = []  # (text, stream_name)

    def append(self, text: str, stream_name: str) -> None:
        with self._lock:
            self._chunks.append((text, stream_name))

    def drain(self) -> list[tuple[str, str]]:
        with self._lock:
            chunks = self._chunks
            self._chunks = []
            return chunks


class OutputCapture:
    """Captures stdout/stderr and writes to a log file.

    The daemon watches this file via file watcher for real-time upload.
    """

    def __init__(self, log_path: Path, flush_interval: float = 2.0) -> None:
        self._log_path = log_path
        self._flush_interval = flush_interval
        self._buffer = OutputBuffer()
        self._original_stdout = sys.stdout
        self._original_stderr = sys.stderr
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._started = False

    def start(self) -> None:
        if self._started:
            return
        self._started = True
        sys.stdout = TeeStream(self._original_stdout, self._buffer, "stdout")  # type: ignore[assignment]
        sys.stderr = TeeStream(self._original_stderr, self._buffer, "stderr")  # type: ignore[assignment]
        self._thread = threading.Thread(target=self._flush_loop, daemon=True, name="simpcat-capture")
        self._thread.start()

    def _flush_loop(self) -> None:
        while not self._stop_event.wait(timeout=self._flush_interval):
            self._flush()

    def _flush(self) -> None:
        chunks = self._buffer.drain()
        if not chunks:
            return
        combined = "".join(text for text, _stream in chunks)
        if combined:
            try:
                with open(self._log_path, "a") as f:
                    f.write(combined)
            except OSError:
                pass

    def stop(self) -> None:
        if not self._started:
            return
        self._started = False
        sys.stdout = self._original_stdout
        sys.stderr = self._original_stderr
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        # Final flush
        self._flush()
