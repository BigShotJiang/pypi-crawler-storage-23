"""simpcat CLI stub — the CLI has moved to the simpcat Rust binary.

Install the simpcat binary and use:
  simpcat login
  simpcat logout
  simpcat verify
"""

from __future__ import annotations

import sys


def main() -> None:
    print(
        "The simpcat CLI has moved to the native `simpcat` binary.\n"
        "\n"
        "Install it from: https://simpcat.ai\n"
        "\n"
        "Then use:\n"
        "  simpcat login\n"
        "  simpcat logout\n"
        "  simpcat verify\n",
        file=sys.stderr,
    )
    sys.exit(1)


if __name__ == "__main__":
    main()
