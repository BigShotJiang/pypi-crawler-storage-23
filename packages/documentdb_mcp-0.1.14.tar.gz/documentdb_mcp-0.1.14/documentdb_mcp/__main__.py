#!/usr/bin/python
# coding: utf-8
from documentdb_mcp.documentdb_mcp import documentdb_mcp

if __name__ == "__main__":
    documentdb_mcp()
