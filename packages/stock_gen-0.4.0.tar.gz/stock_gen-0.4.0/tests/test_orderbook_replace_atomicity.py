import pytest

from stock_gen.orderbook import OrderBook
from stock_gen.types import Side


def test_replace_rolls_back_when_new_order_is_invalid() -> None:
    ob = OrderBook()
    order_id = ob.add_limit_resting(side=Side.BID, price_ticks=100, qty=5)
    before = list(ob.iter_orders_priority(Side.BID))

    with pytest.raises(ValueError, match="qty must be positive"):
        ob.replace(order_id, new_price_ticks=101, new_qty=0)

    assert list(ob.iter_orders_priority(Side.BID)) == before
    assert ob.best_price_ticks(Side.BID) == 100
    assert ob.total_qty(Side.BID) == 5
