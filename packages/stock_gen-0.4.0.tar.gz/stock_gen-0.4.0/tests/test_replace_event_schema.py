import numpy as np

from stock_gen import EventCapPolicy, StockGenerator, StockGeneratorConfig
from stock_gen.config import ExpLinearIntensityConfig
from stock_gen.types import EventType, PlacementMode


def test_replace_event_populates_v2_fields() -> None:
    theta = {
        EventType.R_B: np.asarray([10.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=np.float64),
    }
    cfg = StockGeneratorConfig(
        dt=0.1,
        seed=101,
        max_events_per_step=1,
        event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG,
        intensity=ExpLinearIntensityConfig(theta=theta),
    )
    sg = StockGenerator(cfg)

    sg.step()
    replace_events = [event for event in sg.get_events() if event.event_type is EventType.R_B]

    assert replace_events
    ev = replace_events[0]
    assert ev.replaced_order_id is not None
    assert ev.order_id is not None
    assert ev.order_id != ev.replaced_order_id
    assert ev.placement_mode in (PlacementMode.IMPROVE, PlacementMode.JOIN, PlacementMode.DEEP)
