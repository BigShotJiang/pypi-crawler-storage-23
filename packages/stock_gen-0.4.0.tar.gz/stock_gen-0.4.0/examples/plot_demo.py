from __future__ import annotations

import matplotlib

matplotlib.use("Agg")

import pathlib

from stock_gen import StockGenerator, StockGeneratorConfig
from stock_gen import viz


def main() -> None:
    out_dir = pathlib.Path("examples_out")
    out_dir.mkdir(exist_ok=True)

    cfg = StockGeneratorConfig(
        tick_size=0.01,
        dt=1.0,
        end_time=120.0,
        depth_levels=10,
        seed=123,
    )
    sg = StockGenerator(cfg)
    sim = sg.gen()
    hist = sim.history

    ax = viz.plot_mid(hist)
    ax.figure.tight_layout()
    ax.figure.savefig(out_dir / "mid.png", dpi=150)

    ax = viz.plot_spread(hist, in_ticks=True)
    ax.figure.tight_layout()
    ax.figure.savefig(out_dir / "spread_ticks.png", dpi=150)

    axes = viz.plot_l2_heatmap(hist, side="both")
    # axes can be a single ax or a list/ndarray of axes; handle the common "both" case.
    fig = axes[0].figure if hasattr(axes, "__getitem__") else axes.figure
    fig.tight_layout()
    fig.savefig(out_dir / "l2_heatmap.png", dpi=150)

    print(f"wrote plots to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()
