# stock-gen

언어: [English (canonical)](README.md) | 한국어

`stock-gen`은 이벤트 기반 지정가 주문서(limit order book) 시뮬레이터입니다. 호가/체결/취소 이벤트로 가격과 스프레드가 변하며, 경계 상황은 정책으로 제어할 수 있습니다.

> 참고: 기준 문서는 영문 [README.md](README.md)이며, 이 문서는 번역본입니다.

## 요구 사항

- Python >= 3.11

## 설치

```bash
python -m pip install stock-gen
```

로컬 개발 환경:

```bash
python -m pip install -e '.[dev]'
```

## 빠른 시작

전체 타입 기준 사용 예시(`StepResult`, `SimulationResult`, `step()`/`gen()` 차이, 오류 동작)는 [docs/api.md](docs/api.md)를 참고하세요.

```python
from stock_gen import StockGenerator, StockGeneratorConfig

sim = StockGenerator(StockGeneratorConfig(seed=123, end_time=10.0)).gen()
print("frames=", len(sim.frames), "events=", len(sim.events), "trades=", len(sim.trades))
```

## 정책 동작

- `LiquidityPolicy.REPAIR` (기본값): 한쪽 호가가 비면 합성 유동성을 자동 보강합니다.
- `LiquidityPolicy.ALLOW_EMPTY`: 한쪽 호가 비어 있는 상태를 허용하며, 최우선 호가/스프레드 필드가 비어 있을 수 있습니다.
- `LiquidityPolicy.HALT_ON_EMPTY`: 한쪽 호가 상태에서 `RuntimeError`를 발생시킵니다.
- `EventCapPolicy.RAISE` (기본값): `max_events_per_step`에 도달하면 `EventCapExceededError`를 발생시킵니다.
- `EventCapPolicy.TRUNCATE_AND_FLAG`: 해당 스텝을 조기 종료하고 `StepResult.truncated=True`를 설정합니다.

## 문서 맵

### 사용자 문서

- [docs/api.md](docs/api.md)
- [docs/config-reference.md](docs/config-reference.md)
- [docs/data-contract.md](docs/data-contract.md)
- [docs/architecture.md](docs/architecture.md)
- [docs/reproducibility.md](docs/reproducibility.md)

### 유지보수자 문서

- [docs/release.md](docs/release.md)
- [docs/archive/migration-v0.3.md](docs/archive/migration-v0.3.md)
- `docs/plans/`
