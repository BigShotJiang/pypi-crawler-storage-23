from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from numpy.typing import NDArray

from .types import EventCapPolicy, EventType, LiquidityPolicy

PHI_DIM: int = 6


@dataclass(frozen=True, slots=True)
class ExpLinearIntensityConfig:
    theta: dict[EventType, NDArray[np.float64]] = field(default_factory=dict)
    min_lambda: float = 1e-12
    exp_clip: float = 50.0

    def __post_init__(self) -> None:
        if self.min_lambda <= 0.0:
            raise ValueError("min_lambda must be > 0")
        if self.exp_clip <= 0.0:
            raise ValueError("exp_clip must be > 0")
        for event_type, theta in self.theta.items():
            if not isinstance(event_type, EventType):
                raise TypeError(f"theta key must be EventType, got {type(event_type)!r}")
            if theta.shape != (PHI_DIM,):
                raise ValueError(
                    f"theta[{event_type.value}] must be shape ({PHI_DIM},), got {theta.shape}"
                )

    @staticmethod
    def default() -> "ExpLinearIntensityConfig":
        # phi = [1, log1p(spread_ticks), log1p(best_bid_qty), log1p(best_ask_qty), imbalance, recent_flow]
        t: dict[EventType, NDArray[np.float64]] = {}

        def v(*xs: float) -> NDArray[np.float64]:
            arr = np.asarray(xs, dtype=np.float64)
            if arr.shape != (PHI_DIM,):
                raise ValueError(f"theta must be shape ({PHI_DIM},), got {arr.shape}")
            return arr

        t[EventType.L_B] = v(+0.1, +0.5, -0.15, +0.0, -0.25, +0.0)
        t[EventType.L_A] = v(+0.1, +0.5, +0.0, -0.15, +0.25, +0.0)

        t[EventType.M_B] = v(-1.4, -0.7, +0.0, +0.05, -0.20, -0.25)
        t[EventType.M_A] = v(-1.4, -0.7, +0.05, +0.0, +0.20, +0.25)

        t[EventType.C_B] = v(-0.7, +0.0, +0.25, +0.0, +0.08, +0.0)
        t[EventType.C_A] = v(-0.7, +0.0, +0.0, +0.25, -0.08, +0.0)

        # Replace is supported by the engine, but disabled in the default v1 generator
        # by omitting it from theta.

        return ExpLinearIntensityConfig(theta=t)


@dataclass(frozen=True, slots=True)
class PlacementConfig:
    # logits = W @ [1, log1p(spread_ticks), side_imbalance]
    # where side_imbalance = imbalance (bid) or -imbalance (ask)
    W: NDArray[np.float64] = field(
        default_factory=lambda: np.asarray(
            [
                [-0.6, +1.3, +0.9],  # improve
                [+0.4, -0.3, +0.0],  # join
                [+0.0, -0.2, -0.2],  # deep
            ],
            dtype=np.float64,
        )
    )
    p_deep: float = 0.35
    deep_max_ticks: int = 200

    def __post_init__(self) -> None:
        if self.W.shape != (3, 3):
            raise ValueError(f"W must be shape (3, 3), got {self.W.shape}")
        if self.p_deep <= 0.0 or self.p_deep > 1.0:
            raise ValueError("p_deep must be in (0, 1]")
        if self.deep_max_ticks <= 0:
            raise ValueError("deep_max_ticks must be positive")


@dataclass(frozen=True, slots=True)
class SizeConfig:
    market_mu: float = 1.0
    market_sigma: float = 0.9

    improve_mu: float = 1.4
    improve_sigma: float = 0.8

    join_mu: float = 1.2
    join_sigma: float = 0.85

    deep_mu: float = 1.1
    deep_sigma: float = 0.9

    max_order_qty: int = 1_000

    def __post_init__(self) -> None:
        if self.market_sigma < 0.0 or self.improve_sigma < 0.0 or self.join_sigma < 0.0 or self.deep_sigma < 0.0:
            raise ValueError("all sigma values must be >= 0")
        if self.max_order_qty <= 0:
            raise ValueError("max_order_qty must be positive")


@dataclass(frozen=True, slots=True)
class CancelConfig:
    beta_a: float = 5.0
    beta_b: float = 2.0

    def __post_init__(self) -> None:
        if self.beta_a <= 0.0 or self.beta_b <= 0.0:
            raise ValueError("beta_a and beta_b must be > 0")


@dataclass(frozen=True, slots=True)
class StockGeneratorConfig:
    """Top-level immutable configuration for StockGenerator."""

    tick_size: float = 0.01
    dt: float = 1.0
    end_time: float = 600.0
    depth_levels: int = 10

    seed: int | None = 123

    initial_mid_price: float | None = None
    initial_spread_ticks: int = 2
    init_levels_per_side: int = 50
    init_orders_per_level: int = 3

    max_events_per_step: int = 50_000

    # EWMA half-life for recent aggressive flow (in simulation time units).
    flow_half_life: float = 10.0
    liquidity_policy: LiquidityPolicy = LiquidityPolicy.REPAIR
    event_cap_policy: EventCapPolicy = EventCapPolicy.RAISE

    intensity: ExpLinearIntensityConfig = field(default_factory=ExpLinearIntensityConfig.default)
    placement: PlacementConfig = field(default_factory=PlacementConfig)
    size: SizeConfig = field(default_factory=SizeConfig)
    cancel: CancelConfig = field(default_factory=CancelConfig)

    def __post_init__(self) -> None:
        if self.tick_size <= 0.0:
            raise ValueError("tick_size must be positive")
        if self.dt <= 0.0:
            raise ValueError("dt must be positive")
        if self.end_time < 0.0:
            raise ValueError("end_time must be >= 0")
        if self.depth_levels <= 0:
            raise ValueError("depth_levels must be positive")
        if self.initial_mid_price is not None and self.initial_mid_price <= 0.0:
            raise ValueError("initial_mid_price must be positive when provided")
        if self.initial_spread_ticks <= 0:
            raise ValueError("initial_spread_ticks must be positive")
        if self.init_levels_per_side <= 0 or self.init_orders_per_level <= 0:
            raise ValueError("init_levels_per_side and init_orders_per_level must be positive")
        if self.max_events_per_step <= 0:
            raise ValueError("max_events_per_step must be positive")
        if self.flow_half_life < 0.0:
            raise ValueError("flow_half_life must be >= 0")
