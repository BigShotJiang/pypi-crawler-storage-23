from __future__ import annotations

from bisect import bisect_left
from collections import OrderedDict
from dataclasses import dataclass

from .types import Side, Trade


@dataclass(slots=True)
class PriceLevel:
    price_ticks: int
    orders: "OrderedDict[int, int]"
    total_qty: int

    @staticmethod
    def empty(price_ticks: int) -> "PriceLevel":
        return PriceLevel(price_ticks=price_ticks, orders=OrderedDict(), total_qty=0)


class OrderBook:
    """
    Order-level CLOB with price-time priority.

    Internal prices are integer ticks.
    """

    def __init__(self) -> None:
        self._bid_levels: dict[int, PriceLevel] = {}
        self._ask_levels: dict[int, PriceLevel] = {}

        # Sorted keys (ascending). For bids: key = price_ticks. For asks: key = -price_ticks.
        self._bid_keys: list[int] = []
        self._ask_keys: list[int] = []

        self._order_index: dict[int, tuple[Side, int]] = {}
        self._next_order_id: int = 1

        self._total_bid_qty: int = 0
        self._total_ask_qty: int = 0

    def total_qty(self, side: Side) -> int:
        return self._total_bid_qty if side is Side.BID else self._total_ask_qty

    def best_price_ticks(self, side: Side) -> int | None:
        if side is Side.BID:
            return None if not self._bid_keys else int(self._bid_keys[-1])
        return None if not self._ask_keys else int(-self._ask_keys[-1])

    def best_qty(self, side: Side) -> int:
        p = self.best_price_ticks(side)
        if p is None:
            return 0
        lvl = self._bid_levels[p] if side is Side.BID else self._ask_levels[p]
        return int(lvl.total_qty)

    def spread_ticks(self) -> int | None:
        bb = self.best_price_ticks(Side.BID)
        ba = self.best_price_ticks(Side.ASK)
        if bb is None or ba is None:
            return None
        return int(ba - bb)

    def add_limit_resting(self, side: Side, price_ticks: int, qty: int) -> int:
        if qty <= 0:
            raise ValueError("qty must be positive")
        order_id = self._next_order_id
        self._next_order_id += 1
        self._add_order_with_id(order_id=order_id, side=side, price_ticks=price_ticks, qty=qty)
        return order_id

    def cancel(self, order_id: int) -> tuple[Side, int, int] | None:
        info = self._order_index.get(order_id)
        if info is None:
            return None
        side, price_ticks = info
        if side is Side.BID:
            lvl = self._bid_levels[price_ticks]
        else:
            lvl = self._ask_levels[price_ticks]

        qty = lvl.orders.pop(order_id)
        lvl.total_qty -= qty
        del self._order_index[order_id]

        if side is Side.BID:
            self._total_bid_qty -= qty
        else:
            self._total_ask_qty -= qty

        if not lvl.orders:
            self._remove_level(side=side, price_ticks=price_ticks)

        return side, price_ticks, qty

    def replace(self, order_id: int, *, new_price_ticks: int, new_qty: int) -> int:
        if new_qty <= 0:
            raise ValueError("qty must be positive")

        canceled = self.cancel(order_id)
        if canceled is None:
            raise KeyError(f"unknown order_id={order_id}")
        side, old_price_ticks, old_qty = canceled
        try:
            return self.add_limit_resting(side=side, price_ticks=new_price_ticks, qty=new_qty)
        except Exception:
            # Preserve original order when replacement insert fails.
            self._add_order_with_id(
                order_id=order_id,
                side=side,
                price_ticks=old_price_ticks,
                qty=old_qty,
            )
            raise

    def iter_orders_priority(self, side: Side):
        if side is Side.BID:
            for price in reversed(self._bid_keys):
                price_ticks = int(price)
                lvl = self._bid_levels[price_ticks]
                for order_id, qty in lvl.orders.items():
                    yield int(order_id), price_ticks, int(qty)
        else:
            for key in reversed(self._ask_keys):
                price_ticks = int(-key)
                lvl = self._ask_levels[price_ticks]
                for order_id, qty in lvl.orders.items():
                    yield int(order_id), price_ticks, int(qty)

    def get_l2_ticks(self, levels: int) -> tuple[list[int], list[int], list[int], list[int]]:
        # Returns lists: bid_px_ticks, bid_qty, ask_px_ticks, ask_qty
        bid_px: list[int] = []
        bid_q: list[int] = []
        ask_px: list[int] = []
        ask_q: list[int] = []

        for key in reversed(self._bid_keys[-levels:]):
            price_ticks = int(key)
            bid_px.append(price_ticks)
            bid_q.append(int(self._bid_levels[price_ticks].total_qty))

        for key in reversed(self._ask_keys[-levels:]):
            price_ticks = int(-key)
            ask_px.append(price_ticks)
            ask_q.append(int(self._ask_levels[price_ticks].total_qty))

        return bid_px, bid_q, ask_px, ask_q

    def process_market(self, *, side: Side, qty: int, t: float) -> list[Trade]:
        if qty <= 0:
            raise ValueError("qty must be positive")
        return self._consume_opposite(side=side, qty=qty, t=t, limit_price_ticks=None)[0]

    def process_limit(
        self, *, side: Side, price_ticks: int, qty: int, t: float
    ) -> tuple[int | None, list[Trade]]:
        if qty <= 0:
            raise ValueError("qty must be positive")
        trades, remaining = self._consume_opposite(
            side=side, qty=qty, t=t, limit_price_ticks=price_ticks
        )
        if remaining <= 0:
            return None, trades
        order_id = self.add_limit_resting(side=side, price_ticks=price_ticks, qty=remaining)
        return order_id, trades

    def _consume_opposite(
        self, *, side: Side, qty: int, t: float, limit_price_ticks: int | None
    ) -> tuple[list[Trade], int]:
        trades: list[Trade] = []
        remaining = int(qty)

        if side is Side.BID:
            # consume asks
            while remaining > 0:
                best_ask = self.best_price_ticks(Side.ASK)
                if best_ask is None:
                    break
                if limit_price_ticks is not None and best_ask > limit_price_ticks:
                    break

                lvl = self._ask_levels[best_ask]
                while remaining > 0 and lvl.orders:
                    maker_id, maker_qty = next(iter(lvl.orders.items()))
                    fill = maker_qty if maker_qty < remaining else remaining
                    trades.append(Trade(t=t, price_ticks=best_ask, qty=fill, aggressor=Side.BID))

                    maker_qty -= fill
                    remaining -= fill
                    lvl.total_qty -= fill
                    self._total_ask_qty -= fill

                    if maker_qty == 0:
                        lvl.orders.popitem(last=False)
                        del self._order_index[maker_id]
                    else:
                        lvl.orders[maker_id] = maker_qty

                if not lvl.orders:
                    self._remove_level(side=Side.ASK, price_ticks=best_ask)
        else:
            # consume bids
            while remaining > 0:
                best_bid = self.best_price_ticks(Side.BID)
                if best_bid is None:
                    break
                if limit_price_ticks is not None and best_bid < limit_price_ticks:
                    break

                lvl = self._bid_levels[best_bid]
                while remaining > 0 and lvl.orders:
                    maker_id, maker_qty = next(iter(lvl.orders.items()))
                    fill = maker_qty if maker_qty < remaining else remaining
                    trades.append(Trade(t=t, price_ticks=best_bid, qty=fill, aggressor=Side.ASK))

                    maker_qty -= fill
                    remaining -= fill
                    lvl.total_qty -= fill
                    self._total_bid_qty -= fill

                    if maker_qty == 0:
                        lvl.orders.popitem(last=False)
                        del self._order_index[maker_id]
                    else:
                        lvl.orders[maker_id] = maker_qty

                if not lvl.orders:
                    self._remove_level(side=Side.BID, price_ticks=best_bid)

        return trades, remaining

    def _add_order_with_id(self, *, order_id: int, side: Side, price_ticks: int, qty: int) -> None:
        if side is Side.BID:
            lvl = self._bid_levels.get(price_ticks)
            if lvl is None:
                lvl = PriceLevel.empty(price_ticks)
                self._bid_levels[price_ticks] = lvl
                self._insert_key(self._bid_keys, price_ticks)
            lvl.orders[order_id] = qty
            lvl.total_qty += qty
            self._total_bid_qty += qty
        else:
            lvl = self._ask_levels.get(price_ticks)
            if lvl is None:
                lvl = PriceLevel.empty(price_ticks)
                self._ask_levels[price_ticks] = lvl
                self._insert_key(self._ask_keys, -price_ticks)
            lvl.orders[order_id] = qty
            lvl.total_qty += qty
            self._total_ask_qty += qty

        self._order_index[order_id] = (side, price_ticks)

    def _remove_level(self, *, side: Side, price_ticks: int) -> None:
        if side is Side.BID:
            del self._bid_levels[price_ticks]
            self._remove_key(self._bid_keys, price_ticks)
        else:
            del self._ask_levels[price_ticks]
            self._remove_key(self._ask_keys, -price_ticks)

    @staticmethod
    def _insert_key(keys: list[int], key: int) -> None:
        i = bisect_left(keys, key)
        keys.insert(i, key)

    @staticmethod
    def _remove_key(keys: list[int], key: int) -> None:
        i = bisect_left(keys, key)
        if i >= len(keys) or keys[i] != key:
            raise KeyError(f"missing price key={key}")
        keys.pop(i)
