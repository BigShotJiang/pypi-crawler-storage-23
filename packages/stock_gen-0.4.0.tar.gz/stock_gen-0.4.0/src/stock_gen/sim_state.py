from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class SimulationState:
    t: float = 0.0
    recent_flow: float = 0.0
    last_mid_ticks: int | None = None
    frame_index: int = 0
    _next_event_seq: int = 1

    def reset(self) -> None:
        self.t = 0.0
        self.recent_flow = 0.0
        self.last_mid_ticks = None
        self.frame_index = 0
        self._next_event_seq = 1

    def next_event_seq(self) -> int:
        seq = self._next_event_seq
        self._next_event_seq += 1
        return seq
