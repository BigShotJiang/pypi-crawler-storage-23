from __future__ import annotations

import math

import numpy as np
from numpy.random import Generator
from numpy.typing import NDArray

from .config import PlacementConfig
from .types import PlacementMode, Side


def _softmax(logits: NDArray[np.float64]) -> NDArray[np.float64]:
    m = float(np.max(logits))
    x = np.exp(logits - m)
    s = float(np.sum(x))
    if s == 0.0:
        # Should only happen if all logits were -inf.
        return np.asarray([1.0 / len(logits)] * len(logits), dtype=np.float64)
    return x / s


def sample_placement(
    *,
    cfg: PlacementConfig,
    rng: Generator,
    side: Side,
    best_bid_ticks: int | None,
    best_ask_ticks: int | None,
    spread_ticks: int | None,
    imbalance: float,
) -> tuple[PlacementMode, int, int | None]:
    """
    Returns (mode, price_ticks, deep_distance_d).
    """
    spread = 0.0 if spread_ticks is None or spread_ticks < 0 else float(spread_ticks)
    side_imb = float(imbalance if side is Side.BID else -imbalance)
    feats = np.asarray([1.0, math.log1p(spread), side_imb], dtype=np.float64)

    logits = cfg.W @ feats
    if logits.shape != (3,):
        raise ValueError(f"placement logits must be shape (3,), got {logits.shape}")

    improve_ok = spread_ticks is not None and spread_ticks > 1 and best_bid_ticks is not None and best_ask_ticks is not None
    if not improve_ok:
        logits = logits.copy()
        logits[0] = -np.inf  # improve

    probs = _softmax(logits.astype(np.float64))
    mode_idx = int(rng.choice(3, p=probs))
    mode = (PlacementMode.IMPROVE, PlacementMode.JOIN, PlacementMode.DEEP)[mode_idx]

    if side is Side.BID:
        if best_bid_ticks is None:
            raise ValueError("cannot place bid when best_bid is None")
        if mode is PlacementMode.IMPROVE:
            return mode, int(best_bid_ticks + 1), None
        if mode is PlacementMode.JOIN:
            return mode, int(best_bid_ticks), None
        d = int(min(int(rng.geometric(cfg.p_deep)), cfg.deep_max_ticks))
        return mode, int(best_bid_ticks - d), d

    # ASK
    if best_ask_ticks is None:
        raise ValueError("cannot place ask when best_ask is None")
    if mode is PlacementMode.IMPROVE:
        return mode, int(best_ask_ticks - 1), None
    if mode is PlacementMode.JOIN:
        return mode, int(best_ask_ticks), None
    d = int(min(int(rng.geometric(cfg.p_deep)), cfg.deep_max_ticks))
    return mode, int(best_ask_ticks + d), d

