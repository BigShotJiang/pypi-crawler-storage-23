from __future__ import annotations

from typing import Literal

import numpy as np

from .types import MarketHistory


def _as_history(obj: MarketHistory | object) -> MarketHistory:
    if isinstance(obj, MarketHistory):
        return obj
    get_history = getattr(obj, "get_history", None)
    if callable(get_history):
        hist = get_history()
        if isinstance(hist, MarketHistory):
            return hist
    raise TypeError("expected MarketHistory or an object with get_history() -> MarketHistory")


def plot_mid(obj: MarketHistory | object, *, ax=None):
    import matplotlib.pyplot as plt

    hist = _as_history(obj)
    data = hist.to_numpy(as_ticks=False)
    if ax is None:
        _, ax = plt.subplots(1, 1, figsize=(9, 3))
    ax.plot(data["t"], data["mid"], lw=1.2)
    ax.set_title("Mid Price")
    ax.set_xlabel("t")
    ax.set_ylabel("price")
    ax.grid(True, alpha=0.2)
    return ax


def plot_spread(obj: MarketHistory | object, *, ax=None, in_ticks: bool = True):
    import matplotlib.pyplot as plt

    hist = _as_history(obj)
    data = hist.to_numpy(as_ticks=True)
    if ax is None:
        _, ax = plt.subplots(1, 1, figsize=(9, 3))
    y = data["spread_ticks"].astype(np.float64)
    if not in_ticks:
        y = y * float(hist.tick_size)
    ax.plot(data["t"], y, lw=1.2)
    ax.set_title("Spread" + (" (ticks)" if in_ticks else ""))
    ax.set_xlabel("t")
    ax.set_ylabel("spread")
    ax.grid(True, alpha=0.2)
    return ax


def plot_l2_heatmap(
    obj: MarketHistory | object,
    *,
    side: Literal["bid", "ask", "both"] = "both",
    cmap: str = "viridis",
):
    import matplotlib.pyplot as plt

    hist = _as_history(obj)
    data = hist.to_numpy(as_ticks=True)
    t = data["t"]

    def _plot_one(ax, qty: np.ndarray, title: str):
        # qty: (N, K) where K is level index (0=best)
        im = ax.imshow(qty.T, aspect="auto", origin="upper", cmap=cmap)
        ax.set_title(title)
        ax.set_xlabel("frame")
        ax.set_ylabel("level (0=best)")
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    if side == "both":
        fig, axes = plt.subplots(2, 1, figsize=(10, 6), sharex=True)
        _plot_one(axes[0], data["bid_qty"], "Bid L2 Qty Heatmap")
        _plot_one(axes[1], data["ask_qty"], "Ask L2 Qty Heatmap")
        fig.suptitle("L2 Depth (Top-K)")
        return axes

    fig, ax = plt.subplots(1, 1, figsize=(10, 3))
    if side == "bid":
        _plot_one(ax, data["bid_qty"], "Bid L2 Qty Heatmap")
    elif side == "ask":
        _plot_one(ax, data["ask_qty"], "Ask L2 Qty Heatmap")
    else:
        raise ValueError("side must be one of: 'bid', 'ask', 'both'")
    _ = t  # keep for future axis formatting
    return ax
