# Reproducibility Guide

This project is designed to be deterministic when seed and config are fixed.

## Deterministic Recipe

1. Pin package version (`stock-gen==X.Y.Z`).
   Example: `stock-gen==0.3.0`.
2. Fix `StockGeneratorConfig(seed=...)` to a concrete integer.
3. Keep full config identical, including `dt`, policies, and nested model configs.
4. Start from a fresh `StockGenerator(cfg)` or call `reset(seed=...)`.

## Recommended Equality Check

Use tick-space arrays for comparisons:

```python
import numpy as np
from stock_gen import StockGenerator, StockGeneratorConfig

cfg = StockGeneratorConfig(seed=2026, dt=0.5, end_time=5.0)
run1 = StockGenerator(cfg).gen(until_time=5.0).history.to_numpy(as_ticks=True)
run2 = StockGenerator(cfg).gen(until_time=5.0).history.to_numpy(as_ticks=True)

for key in ["t", "spread_ticks", "best_bid_ticks", "best_ask_ticks", "bid_px_ticks", "ask_px_ticks"]:
    np.testing.assert_array_equal(run1[key], run2[key])
```

## Common Pitfalls

- `seed=None` means non-deterministic behavior.
- `gen()` is stateful; calling it again continues from current time.
- `SimulationResult.steps` is cumulative for the instance.
- Comparing price-space arrays (`as_ticks=False`) can include tiny float representation differences.
- Changing NumPy/Python versions can change floating-point edge behavior in long runs.

## Reset Behavior

`reset(seed=s)` reinitializes:
- RNG state
- order book state
- simulation state (`t`, frame index, flow)
- collected frames/events/trades/steps

Use `reset(seed=original_seed)` to replay the same path on the same version/environment.

## What to Log for Reproducible Experiments

- `stock-gen` version
- Python version
- NumPy version
- full `StockGeneratorConfig` (including nested configs)
- random seed
- simulation horizon (`until_time` or `end_time`)
