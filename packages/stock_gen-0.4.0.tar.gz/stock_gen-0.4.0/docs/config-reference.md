# Config Reference

`StockGeneratorConfig` is the single entry point for simulator configuration.

## Top-Level Fields

| Field | Default | Meaning | Validation |
| --- | --- | --- | --- |
| `tick_size` | `0.01` | Price increment in quote currency units. | Must be `> 0`. |
| `dt` | `1.0` | Frame duration used by `step()` and `gen()`. | Must be `> 0`. |
| `end_time` | `600.0` | Default horizon when `gen(until_time=None)` is used. | Must be `>= 0`. |
| `depth_levels` | `10` | L2 depth stored in each frame snapshot. | Must be `> 0`. |
| `seed` | `123` | RNG seed. Use `None` for non-deterministic runs. | No additional runtime validation. |
| `initial_mid_price` | `None` | If `None`, sampled from uniform `[100, 200]`. | `None` or `> 0`. |
| `initial_spread_ticks` | `2` | Initial spread at bootstrapping time. | Must be `> 0`. |
| `init_levels_per_side` | `50` | Number of initial price levels on each side. | Must be `> 0`. |
| `init_orders_per_level` | `3` | Initial resting orders per seeded level. | Must be `> 0`. |
| `max_events_per_step` | `50000` | Per-frame hard cap on processed events. | Must be `> 0`. |
| `flow_half_life` | `10.0` | EWMA half-life for recent aggressive flow feature. | Must be `>= 0`. |
| `liquidity_policy` | `LiquidityPolicy.REPAIR` | One-sided book handling behavior. | No direct `__post_init__` check; pass `LiquidityPolicy` values. |
| `event_cap_policy` | `EventCapPolicy.RAISE` | Behavior at `max_events_per_step` cap. | No direct `__post_init__` check; pass `EventCapPolicy` values. |
| `intensity` | `ExpLinearIntensityConfig.default()` | Event intensity model parameters. | No direct type check in `StockGeneratorConfig`; nested config validates itself. |
| `placement` | `PlacementConfig()` | Limit-order placement mode sampling config. | No direct type check in `StockGeneratorConfig`; nested config validates itself. |
| `size` | `SizeConfig()` | Lognormal-style size model parameters. | No direct type check in `StockGeneratorConfig`; nested config validates itself. |
| `cancel` | `CancelConfig()` | Cancellation priority distribution parameters. | No direct type check in `StockGeneratorConfig`; nested config validates itself. |

## Policy Fields

### `LiquidityPolicy`

- `REPAIR`: inserts synthetic liquidity when one side is empty.
- `ALLOW_EMPTY`: keeps one-sided books; missing best/spread fields appear in outputs.
- `HALT_ON_EMPTY`: raises `RuntimeError` immediately.

### `EventCapPolicy`

- `RAISE`: raises `EventCapExceededError` at cap.
- `TRUNCATE_AND_FLAG`: truncates frame and sets `StepResult.truncated=True`.

## Nested Configs

### `ExpLinearIntensityConfig`

| Field | Default | Meaning | Validation |
| --- | --- | --- | --- |
| `theta` | `{...}` | Per-event coefficient vectors. Missing event type means that event type is disabled. | Each key must be `EventType`; each vector must be shape `(6,)` (`PHI_DIM=6`). |
| `min_lambda` | `1e-12` | Minimum intensity floor. | Must be `> 0`. |
| `exp_clip` | `50.0` | Exponential clipping for numerical stability. | Must be `> 0`. |

Feature vector order (`phi`):
`[1, log1p(spread_ticks), log1p(best_bid_qty), log1p(best_ask_qty), imbalance, recent_flow]`

### `PlacementConfig`

| Field | Default | Meaning | Validation |
| --- | --- | --- | --- |
| `W` | `3x3` matrix | Logit weights for `IMPROVE/JOIN/DEEP` placement modes. | Must be shape `(3, 3)`. |
| `p_deep` | `0.35` | Probability parameter for deep placement distance path. | Must be in `(0, 1]`. |
| `deep_max_ticks` | `200` | Maximum deep placement distance in ticks. | Must be `> 0`. |

### `SizeConfig`

| Field | Default | Validation |
| --- | --- | --- |
| `market_mu` | `1.0` | No additional runtime validation. |
| `market_sigma` | `0.9` | Must be `>= 0`. |
| `improve_mu` | `1.4` | No additional runtime validation. |
| `improve_sigma` | `0.8` | Must be `>= 0`. |
| `join_mu` | `1.2` | No additional runtime validation. |
| `join_sigma` | `0.85` | Must be `>= 0`. |
| `deep_mu` | `1.1` | No additional runtime validation. |
| `deep_sigma` | `0.9` | Must be `>= 0`. |
| `max_order_qty` | `1000` | Must be `> 0`. |

### `CancelConfig`

| Field | Default | Meaning | Validation |
| --- | --- | --- | --- |
| `beta_a` | `5.0` | Beta distribution shape parameter for cancellation priority sampling. | Must be `> 0`. |
| `beta_b` | `2.0` | Beta distribution shape parameter for cancellation priority sampling. | Must be `> 0`. |

## Validation Error Types

- Most invalid numeric ranges raise `ValueError`.
- `ExpLinearIntensityConfig(theta=...)` raises `TypeError` if a `theta` key is not `EventType`.

## Practical Presets

- Strict safety: `liquidity_policy=LiquidityPolicy.HALT_ON_EMPTY`, `event_cap_policy=EventCapPolicy.RAISE`
- Robust batch generation: `liquidity_policy=LiquidityPolicy.REPAIR`, `event_cap_policy=EventCapPolicy.TRUNCATE_AND_FLAG`
- Stress one-sided markets: `liquidity_policy=LiquidityPolicy.ALLOW_EMPTY`
