# Migration Guide: v0.2 -> v0.3

This guide summarizes what changed in `0.3.0` and how to upgrade safely.

## What Changed

### Runtime/API Surface

- Existing imports and top-level usage patterns remain valid, but container mutability contracts changed:
  - `get_events()`, `get_trades()`, `get_step_results()` now return tuples.
  - `MarketHistory.frames/events/trades` and `SimulationResult.steps` are now tuples.
  - L2/frame arrays in snapshots are exported read-only.
- `get_l2(levels=...)` now validates input and raises `ValueError` for non-positive levels.

### Documentation Structure

- Version labels in docs were generalized (for example, titles no longer include `v0.2`).
- README Quickstart is intentionally minimal; the full typed walkthrough now lives in `docs/api.md`.
- New docs (at `0.3.0` rollout time):
  - `docs/architecture.md`
  - `docs/archive/migration-v0.3.md` (this document, now archived path)

### Release Process (Maintainers)

- Official publish flow is now GitHub Actions + OIDC Trusted Publishing.
- `twine upload dist/*` is removed from the standard release checklist.

## Breaking Changes

1. Public container mutability changed from list-style to tuple-style snapshots.
   If you mutate returned collections (`append`, `clear`, item assignment), update code to copy first.
2. Snapshot array mutability is now restricted.
   If you mutated frame/L2 arrays in-place, copy arrays before editing.
3. `get_l2(levels<=0)` now raises `ValueError` instead of leaking lower-level array errors.
4. Maintainer release procedure changed.
   You should release by pushing `vX.Y.Z` tags and letting GitHub Actions publish to PyPI via OIDC.
5. Version-specific doc heading text changed.
   If you linked to old heading text that included `v0.2`, update those references.

## Upgrade Checklist

1. Update dependency pin to `stock-gen==0.3.0`.
2. Replace any mutation of returned history/event/trade/step collections with explicit copies.
3. If you are a maintainer, follow `docs/release.md` tag-driven OIDC workflow.
4. Refresh internal links/bookmarks that depended on old version-tagged headings.
5. Use `docs/architecture.md` as the current system-level reference for onboarding.

## Verification After Upgrade

Run your smoke script and compare key shapes:

```python
from stock_gen import StockGenerator, StockGeneratorConfig

sim = StockGenerator(StockGeneratorConfig(seed=42, end_time=5.0)).gen()
print(len(sim.frames), len(sim.events), len(sim.trades))
```

For deterministic checks, follow `docs/reproducibility.md` and pin exact package/environment versions.
