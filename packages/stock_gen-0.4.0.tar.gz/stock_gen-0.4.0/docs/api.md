# API Reference

## Public Imports

```python
from stock_gen import (
    EventCapPolicy,
    LiquidityPolicy,
    SimulationResult,
    StepResult,
    StockGenerator,
    StockGeneratorConfig,
)
```

## Quickstart

```python
from stock_gen import (
    EventCapPolicy,
    LiquidityPolicy,
    SimulationResult,
    StepResult,
    StockGenerator,
    StockGeneratorConfig,
)

cfg = StockGeneratorConfig(
    tick_size=0.01,
    dt=1.0,
    end_time=60.0,
    depth_levels=10,
    seed=123,
    liquidity_policy=LiquidityPolicy.REPAIR,
    event_cap_policy=EventCapPolicy.RAISE,
)

sg = StockGenerator(cfg)

step: StepResult = sg.step()
print(
    "t=", step.frame.t,
    "mid=", step.frame.mid_price,
    "events=", step.events_processed,
    "truncated=", step.truncated,
)

sim: SimulationResult = sg.gen()
print(
    "frames=", len(sim.frames),
    "steps=", len(sim.steps),
    "events=", len(sim.events),
    "trades=", len(sim.trades),
)
```

## Main Objects

- `StockGeneratorConfig`: immutable dataclass for simulator parameters.
- `StockGenerator`: stateful simulator instance.
- `StepResult`: per-frame execution result from `step()`.
- `SimulationResult`: cumulative result from `gen()`.

## `StockGenerator`

- `StockGenerator(config: StockGeneratorConfig | None = None)`
- `step(dt: float | None = None) -> StepResult`
- `gen(until_time: float | None = None) -> SimulationResult`
- `reset(seed: int | None = None) -> None`
- `get_history() -> MarketHistory`
- `get_step_results() -> tuple[StepResult, ...]`
- `get_events() -> tuple[Event, ...]`
- `get_trades() -> tuple[Trade, ...]`
- `get_l2(levels: int | None = None, *, as_ticks: bool = False) -> L2Snapshot`
- `get_time() -> float`
- `get_price() -> float`
- `get_best_bid_ask() -> tuple[tuple[float, int], tuple[float, int]]`

Notes:
- `gen()` continues from current simulator time; it does not reset state.
- `SimulationResult.steps` includes all prior `step()` calls on the same instance.
- History/event/trade/step containers are immutable snapshots (`tuple`).
- `get_l2(levels=...)` requires `levels > 0`.

## `StepResult`

- `frame: FrameSnapshot`: end-of-step snapshot at step end time.
- `truncated: bool`: `True` if step stopped early by `EventCapPolicy.TRUNCATE_AND_FLAG`.
- `events_processed: int`: number of events applied in that frame.
- `t_last_event: float | None`: timestamp of the last in-frame event, or `None` if no events.

## `SimulationResult`

- `history: MarketHistory`
- `steps: tuple[StepResult, ...]`
- `frames`: property alias for `history.frames`
- `events`: property alias for `history.events`
- `trades`: property alias for `history.trades`

## Policies

### `LiquidityPolicy`

- `REPAIR` (default): if one side is empty, synthetic limit liquidity is inserted.
- `ALLOW_EMPTY`: one-sided states are allowed; quote/spread fields may be missing.
- `HALT_ON_EMPTY`: raises `RuntimeError` on one-sided state.

### `EventCapPolicy`

- `RAISE` (default): raises `EventCapExceededError` when `max_events_per_step` is reached, and rolls back that step atomically.
- `TRUNCATE_AND_FLAG`: ends step immediately and returns `StepResult.truncated=True`.

## Error Behavior

Common exceptions from public calls:

- `StockGeneratorConfig(...)`: `ValueError` for invalid numeric ranges; `TypeError` when `ExpLinearIntensityConfig.theta` keys are not `EventType`.
- `step(dt=...)`: `ValueError` if `dt <= 0`.
- `gen(until_time=...)`: `ValueError` if `until_time < current simulator time`.
- `get_l2(levels=...)`: `ValueError` if `levels <= 0`.
- `LiquidityPolicy.HALT_ON_EMPTY`: `RuntimeError` when a one-sided book is detected.
- `EventCapPolicy.RAISE`: raises `EventCapExceededError` (a `RuntimeError` subtype in `stock_gen.sim_policies`) at `max_events_per_step`; step state is restored to pre-call state.
