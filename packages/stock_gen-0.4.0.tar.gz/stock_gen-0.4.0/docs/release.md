# Release Guide

This is a practical checklist for shipping a new `stock-gen` version.

## 1. Update Package + Docs

1. Update `README.md` for public API/current behavior.
2. Sync `README.ko.md` with `README.md` and keep language-switch links reciprocal. (`README.md` is canonical.)
3. Update `docs/api.md`, `docs/data-contract.md`, and `docs/config-reference.md` if interfaces changed.
4. Add release notes to `CHANGELOG.md`.
5. Set `[project].version` in `pyproject.toml`.

## 2. Run Verification (Local)

```bash
pytest -q
ruff check .
mypy src
python -m build
```

Expected:
- tests pass
- lint/type checks pass
- wheel and sdist generated under `dist/`

## 3. Smoke-Test Built Artifact (Local)

```bash
python -m pip install --force-reinstall dist/*.whl
python - <<'PY'
from stock_gen import StockGenerator, StockGeneratorConfig
sim = StockGenerator(StockGeneratorConfig(seed=1, end_time=1.0)).gen()
print(len(sim.frames), len(sim.events), len(sim.trades))
PY
```

## 4. Publish via GitHub Actions (Trusted Publishing)

This repository publishes via `.github/workflows/workflow.yml`:
- Trigger: push a tag matching `v*` (recommended release path)
- Build job: validates tag/version match, runs tests, builds artifacts
- Publish job: uploads to PyPI using OIDC (`pypa/gh-action-pypi-publish`)

Release commands:

```bash
git tag vX.Y.Z
git push origin vX.Y.Z
```

Notes:
- `twine upload` is not required in the standard release flow.
- `workflow_dispatch` exists for manual runs, but tag-driven release is preferred for version safety checks.
- PyPI Trusted Publisher must be configured for this GitHub repository/workflow.

## 5. Post-Release Check

1. Install from index: `python -m pip install -U stock-gen==X.Y.Z`
2. Run a 30-second smoke simulation.
3. Confirm changelog and docs match published behavior.
4. Confirm `README.md` and `README.ko.md` are both updated for the released behavior.
