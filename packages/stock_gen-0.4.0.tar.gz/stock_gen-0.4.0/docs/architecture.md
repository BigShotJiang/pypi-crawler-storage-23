# Architecture Overview

`stock-gen` is an event-driven CLOB simulator with a policy layer for edge-case handling and deterministic replay.

## Design Goals

- Deterministic generation when config + seed are fixed
- Stable output contracts for downstream modeling pipelines
- Explicit policy control for empty-book and event-cap scenarios
- Fast batch generation for experimentation and backtesting-style workloads

## Core Components

### Configuration Layer

- `StockGeneratorConfig` defines top-level simulation parameters (`dt`, `end_time`, `tick_size`, depth, seed).
- Nested config objects (`intensity`, `placement`, `size`, `cancel`) parameterize event intensity and microstructure behavior.
- Policy enums (`LiquidityPolicy`, `EventCapPolicy`) control failure vs repair/truncation semantics.

### Simulation Engine

- `StockGenerator` owns mutable simulation state and orchestrates per-frame execution.
- `step(dt=None)` advances one frame and returns `StepResult`.
- `gen(until_time=None)` repeatedly calls frame logic and returns cumulative `SimulationResult`.
- `reset(seed=None)` reinitializes RNG + state for replay.

### Market State + Events

- Internal order-book state tracks resting liquidity and best quotes.
- Event stream applies order placements, cancellations, replacements, and matches.
- Trades are emitted from matched liquidity events and stored in history.

### Output Layer

- `StepResult` captures frame-end snapshot + truncation metadata.
- `SimulationResult` exposes cumulative `history`, `steps`, and aliases (`frames`, `events`, `trades`).
- `MarketHistory.to_numpy()` exports vectorized arrays with explicit validity masks and sentinels.

## Execution Flow (One Frame)

1. Determine target frame boundary (`current_time + dt`).
2. Sample and apply events until the boundary (or policy cap stop).
3. Enforce configured policies for one-sided/empty-book conditions.
4. Materialize frame snapshot features.
5. Return `StepResult` and append to cumulative history.

## Determinism Boundaries

- Deterministic: same package version, Python/NumPy environment, config, and seed.
- Non-deterministic: `seed=None`, environment/version drift, or changed defaults/configs.
- `gen()` is stateful by design; repeated calls continue from current time unless `reset()` is used.

## Extension Points

- Add new event types by extending intensity + application pipeline.
- Tune placement/size/cancel behavior through nested config parameters.
- Add downstream features by extending snapshot/export contract (with matching docs updates).
