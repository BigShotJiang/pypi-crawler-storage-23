# Data Contract

This document defines stable output shapes and sentinel semantics for downstream consumers.

## `StepResult` Contract

- Returned by every `step()`.
- `frame.t` equals the generator time after the step.
- `events_processed` is `0..max_events_per_step`.
- `truncated=True` only when `EventCapPolicy.TRUNCATE_AND_FLAG` is active and cap is reached.
- `t_last_event` is `None` if `events_processed == 0`.

## `SimulationResult` Contract

- Returned by `gen()`.
- `history.frames`, `history.events`, `history.trades` are cumulative immutable tuples for the generator instance.
- `steps` is a cumulative immutable tuple and includes earlier explicit `step()` calls.

## `FrameSnapshot` Contract

- Scalar fields:
  - `t: float`
  - `best_bid_ticks: int | None`
  - `best_ask_ticks: int | None`
  - `mid_price: float | None`
  - `spread_ticks: int | None`
  - `imbalance: float | None`
  - `recent_flow: float`
- L2 arrays:
  - `bid_px_ticks`, `bid_qty`, `ask_px_ticks`, `ask_qty`
  - shape: `(depth_levels,)`
  - dtype: `int64`
  - arrays are exported as read-only views
  - missing price level sentinel: `-1`
  - missing quantity sentinel: `0`

## `Event` Contract

Stable fields:
- `seq`, `frame_index`, `t`
- `event_type`, `side`
- `price_ticks`, `qty`, `order_id`
- `synthetic`, `reason`
- `placement_mode`, `deep_distance`
- `replaced_order_id`

Notes:
- `synthetic=True` identifies policy-driven repair events.
- Replace events (`R_b`, `R_a`) populate `replaced_order_id`.

## `MarketHistory.to_numpy()` Contract

### Base Arrays

`to_numpy(as_ticks=True)` returns scalar series, tick-space quote arrays, and validity masks:

- `t`
- `mid`, `mid_valid`
- `spread_ticks`, `spread_valid`
- `best_bid_ticks`, `best_ask_ticks`, `best_bid_valid`, `best_ask_valid`
- `imbalance`, `imbalance_valid`
- `recent_flow`
- `bid_px_ticks`, `bid_qty`
- `ask_px_ticks`, `ask_qty`
- `bid_px_valid`, `ask_px_valid` (level-price validity masks)

### Missing-Value Encoding (`as_ticks=True`)

- `mid`: `nan` when invalid (`mid_valid=False`)
- `imbalance`: `nan` when invalid (`imbalance_valid=False`)
- `spread_ticks`: `-1` when invalid (`spread_valid=False`)
- `best_bid_ticks`: `-1` when invalid (`best_bid_valid=False`)
- `best_ask_ticks`: `-1` when invalid (`best_ask_valid=False`)
- `bid_px_ticks` / `ask_px_ticks`: `-1` at missing levels

### Price-Unit Export (`as_ticks=False`)

`to_numpy(as_ticks=False)` additionally includes:

- `best_bid`, `best_ask`
- `bid_px`, `ask_px`

Missing prices in these price-unit arrays are `NaN`:

- if best quote is missing (`best_bid_valid=False` or `best_ask_valid=False`), corresponding `best_bid`/`best_ask` entry is `NaN`
- if a level price is missing (`bid_px_valid=False` or `ask_px_valid=False`), corresponding `bid_px`/`ask_px` entry is `NaN`

### Empty History

When history is empty, arrays are returned with size `0`. Price-unit arrays (`best_bid`, `best_ask`, `bid_px`, `ask_px`) are omitted until at least one frame exists.
