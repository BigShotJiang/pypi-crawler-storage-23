# stock-gen

Language: English (canonical) | [한국어](README.ko.md)

`stock-gen` is an event-driven limit order book simulator. Price and spread evolve through order-book events (placements, cancellations, and matches), with configurable policies for edge conditions.

## Requirements

- Python >= 3.11

## Install

```bash
python -m pip install stock-gen
```

For local development:

```bash
python -m pip install -e '.[dev]'
```

## Quickstart

For the full typed walkthrough (`StepResult`, `SimulationResult`, `step()` vs `gen()`, and error behavior), see [docs/api.md](docs/api.md).

```python
from stock_gen import StockGenerator, StockGeneratorConfig

sim = StockGenerator(StockGeneratorConfig(seed=123, end_time=10.0)).gen()
print("frames=", len(sim.frames), "events=", len(sim.events), "trades=", len(sim.trades))
```

## Policy Behavior

- `LiquidityPolicy.REPAIR` (default): auto-inserts synthetic liquidity if a side is empty.
- `LiquidityPolicy.ALLOW_EMPTY`: allows one-sided books; quote/spread fields can be missing.
- `LiquidityPolicy.HALT_ON_EMPTY`: raises `RuntimeError` on one-sided states.
- `EventCapPolicy.RAISE` (default): raises `EventCapExceededError` at `max_events_per_step`.
- `EventCapPolicy.TRUNCATE_AND_FLAG`: ends the step early and sets `StepResult.truncated=True`.

## Documentation Map

### User Docs

- [docs/api.md](docs/api.md)
- [docs/config-reference.md](docs/config-reference.md)
- [docs/data-contract.md](docs/data-contract.md)
- [docs/architecture.md](docs/architecture.md)
- [docs/reproducibility.md](docs/reproducibility.md)

### Maintainer Docs

- [docs/release.md](docs/release.md)
- [docs/archive/migration-v0.3.md](docs/archive/migration-v0.3.md)
- `docs/plans/`
