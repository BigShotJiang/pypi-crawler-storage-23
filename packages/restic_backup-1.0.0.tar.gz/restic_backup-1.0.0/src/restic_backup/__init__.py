"""restic-backup - A simple, configuration-driven backup tool powered by Restic."""

__version__ = "1.0.0"
