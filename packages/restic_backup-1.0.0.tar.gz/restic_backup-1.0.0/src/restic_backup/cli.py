#!/usr/bin/env python3
"""
restic-backup - A simple, configuration-driven backup tool powered by Restic.

This is the main command-line interface for the restic-backup tool.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

import yaml

if TYPE_CHECKING:
    from collections.abc import Sequence


DEFAULT_CONFIG = "/etc/restic-backup/config.yaml"
ENV_FILE = "/etc/restic-backup/restic.env"
VERSION = "1.0.0"


@dataclass
class Project:
    """Represents a backup project configuration."""

    name: str
    source: str
    exclude: list[str]


@dataclass
class Config:
    """Represents the complete backup configuration."""

    repository: str
    retention: dict
    projects: list[Project]

    @classmethod
    def load(cls, config_path: str) -> Config:
        """Load configuration from YAML file."""
        with open(config_path) as f:
            data = yaml.safe_load(f)

        projects = [
            Project(
                name=name,
                source=cfg["source"],
                exclude=cfg.get("exclude", []),
            )
            for name, cfg in data["projects"].items()
        ]

        return cls(
            repository=data["repository"],
            retention=data["retention"],
            projects=projects,
        )


class ResticRepo:
    """Wrapper for Restic repository operations."""

    def __init__(self, repo_path: str) -> None:
        self.repo_path = repo_path
        os.environ["RESTIC_REPOSITORY"] = repo_path

    def init(self) -> bool:
        """Initialize repository if it doesn't exist."""
        if self._exists():
            return True
        print(f"Initializing repository: {self.repo_path}")
        return self._run(["restic", "init"])

    def backup(self, source: str, excludes: list[str], tag: str) -> bool:
        """Perform backup."""
        cmd = ["restic", "backup", source, "--tag", tag, "--compression=off"]

        for pattern in excludes:
            cmd.extend(["--exclude", pattern])

        return self._run(cmd)

    def forget(self, retention: dict) -> bool:
        """Clean up old backups according to retention policy."""
        print("Cleaning old backups...")
        cmd = [
            "restic",
            "forget",
            "--keep-daily",
            str(retention["daily"]),
            "--keep-weekly",
            str(retention["weekly"]),
            "--keep-monthly",
            str(retention["monthly"]),
            "--prune",
        ]
        return self._run(cmd)

    def snapshots(self) -> bool:
        """List snapshots."""
        return self._run(["restic", "snapshots", "--compact"])

    def restore(self, snapshot: str, target: str) -> bool:
        """Restore from snapshot."""
        print(f"Restoring snapshot {snapshot} to {target}")
        os.makedirs(target, exist_ok=True)
        return self._run(["restic", "restore", snapshot, "--target", target])

    def _exists(self) -> bool:
        """Check if repository is initialized."""
        result = subprocess.run(
            ["restic", "snapshots"],
            capture_output=True,
            env=os.environ.copy(),
        )
        return result.returncode == 0

    def _run(self, cmd: list[str]) -> bool:
        """Execute a restic command."""
        result = subprocess.run(cmd, env=os.environ.copy())
        return result.returncode == 0


class BackupManager:
    """Manages backup operations for all configured projects."""

    def __init__(self, config_path: str) -> None:
        self.config = Config.load(config_path)

    def backup(self, project_name: str | None = None) -> None:
        """Execute backup for all or specified project(s)."""
        projects = self._get_projects(project_name)

        for project in projects:
            self._backup_one(project)

        print("\n✓ All projects backed up successfully!")

    def _backup_one(self, project: Project) -> None:
        """Backup a single project."""
        print(f"\n{'=' * 50}")
        print(f"📦 Backing up: {project.name}")
        print(f"{'=' * 50}")

        if not os.path.isdir(project.source):
            print(f"⚠️  Skipping: Source path does not exist: {project.source}")
            return

        repo = ResticRepo(f"{self.config.repository}/{project.name}")
        if not repo.init():
            print("❌ Error: Failed to initialize repository")
            return

        print(f"📂 Source: {project.source}")
        print(f"💾 Repository: {repo.repo_path}")

        if project.exclude:
            print("🚫 Exclusions:")
            for pattern in project.exclude:
                print(f"   - {pattern}")

        print("⏳ Starting backup...")
        if not repo.backup(project.source, project.exclude, project.name):
            print(f"❌ Error: Backup failed for {project.name}")
            return

        repo.forget(self.config.retention)
        print(f"✅ {project.name} backup completed")

    def status(self) -> None:
        """Display backup status for all projects."""
        print(f"\n{'=' * 50}")
        print("📊 Backup Status")
        print(f"{'=' * 50}")

        for project in self.config.projects:
            repo = ResticRepo(f"{self.config.repository}/{project.name}")

            print(f"\n📁 {project.name}")
            print(f"   Source: {project.source}")
            print(f"   Repository: {repo.repo_path}")

            if repo._exists():
                repo.snapshots()
            else:
                print("   Status: Not initialized")

    def restore(self, project_name: str, target: str, snapshot: str = "latest") -> None:
        """Restore a project from backup."""
        project = self._find_project(project_name)
        if not project:
            print(f"❌ Error: Unknown project '{project_name}'")
            sys.exit(1)

        repo = ResticRepo(f"{self.config.repository}/{project_name}")
        repo.restore(snapshot, target)
        print(f"✅ Restore completed: {target}")

    def list_projects(self) -> None:
        """List all configured projects."""
        print(f"\nConfigured projects ({len(self.config.projects)}):")
        print(f"{'=' * 50}")
        for project in self.config.projects:
            print(f"\n📁 {project.name}")
            print(f"   Source: {project.source}")
            if project.exclude:
                print(f"   Exclusions: {', '.join(project.exclude)}")

    def _get_projects(self, name: str | None) -> list[Project]:
        """Get list of projects to process."""
        if name is None:
            return self.config.projects

        project = self._find_project(name)
        if project:
            return [project]

        print(f"❌ Error: Unknown project '{name}'")
        available = ", ".join(p.name for p in self.config.projects)
        print(f"Available projects: {available}")
        sys.exit(1)

    def _find_project(self, name: str) -> Project | None:
        """Find a project by name."""
        for project in self.config.projects:
            if project.name == name:
                return project
        return None


def load_env() -> None:
    """Load environment variables from file."""
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    key = key.replace("export ", "").strip()
                    value = value.strip().strip('"').strip("'")
                    os.environ[key] = value


def create_parser() -> argparse.ArgumentParser:
    """Create argument parser."""
    parser = argparse.ArgumentParser(
        prog="restic-backup",
        description="A simple, configuration-driven backup tool powered by Restic.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  restic-backup list                    # List all projects
  restic-backup backup                  # Backup all projects
  restic-backup backup immich           # Backup specific project
  restic-backup status                  # Show backup status
  restic-backup restore immich /tmp/restore   # Restore latest
  restic-backup restore immich /tmp/restore abc123  # Restore specific snapshot
        """,
    )

    parser.add_argument(
        "--version",
        "-v",
        action="version",
        version=f"%(prog)s {VERSION}",
    )

    parser.add_argument(
        "--config",
        "-c",
        default=DEFAULT_CONFIG,
        help=f"Configuration file path (default: {DEFAULT_CONFIG})",
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # backup command
    p_backup = subparsers.add_parser("backup", help="Execute backup")
    p_backup.add_argument("project", nargs="?", help="Project name (optional, default: all)")

    # status command
    subparsers.add_parser("status", help="Show backup status")

    # list command
    subparsers.add_parser("list", help="List configured projects")

    # restore command
    p_restore = subparsers.add_parser("restore", help="Restore from backup")
    p_restore.add_argument("project", help="Project name")
    p_restore.add_argument("target", help="Target path for restore")
    p_restore.add_argument(
        "snapshot",
        nargs="?",
        default="latest",
        help="Snapshot ID (default: latest)",
    )

    return parser


def main(args: Sequence[str] | None = None) -> int:
    """Main entry point."""
    parser = create_parser()
    parsed = parser.parse_args(args)

    if not parsed.command:
        parser.print_help()
        return 1

    # Load environment variables
    load_env()

    # Check configuration file
    if not os.path.exists(parsed.config):
        print(f"❌ Error: Configuration file not found: {parsed.config}")
        return 1

    # Execute command
    manager = BackupManager(parsed.config)

    if parsed.command == "backup":
        manager.backup(parsed.project)
    elif parsed.command == "status":
        manager.status()
    elif parsed.command == "list":
        manager.list_projects()
    elif parsed.command == "restore":
        manager.restore(parsed.project, parsed.target, parsed.snapshot)

    return 0


if __name__ == "__main__":
    sys.exit(main())
