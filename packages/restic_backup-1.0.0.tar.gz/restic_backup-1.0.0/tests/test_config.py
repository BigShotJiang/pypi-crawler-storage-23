"""Tests for configuration loading."""

import tempfile
from pathlib import Path

import pytest

from restic_backup.cli import Config, Project


@pytest.fixture
def sample_config():
    """Create a sample configuration file."""
    config_content = """
repository: /tmp/test-repo

retention:
  daily: 7
  weekly: 4
  monthly: 3

projects:
  test-project:
    source: /data/test
    exclude:
      - cache
      - "*.log"
      
  another-project:
    source: /data/another
    exclude: []
"""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write(config_content)
        return f.name


class TestConfig:
    """Test configuration loading."""

    def test_load_config(self, sample_config):
        """Test loading configuration from YAML."""
        config = Config.load(sample_config)
        
        assert config.repository == "/tmp/test-repo"
        assert config.retention["daily"] == 7
        assert config.retention["weekly"] == 4
        assert config.retention["monthly"] == 3
        
    def test_load_projects(self, sample_config):
        """Test loading projects."""
        config = Config.load(sample_config)
        
        assert len(config.projects) == 2
        
        # Check first project
        p1 = config.projects[0]
        assert p1.name == "test-project"
        assert p1.source == "/data/test"
        assert p1.exclude == ["cache", "*.log"]
        
        # Check second project
        p2 = config.projects[1]
        assert p2.name == "another-project"
        assert p2.source == "/data/another"
        assert p2.exclude == []


class TestProject:
    """Test Project dataclass."""

    def test_project_creation(self):
        """Test creating a Project instance."""
        project = Project(
            name="my-project",
            source="/data/my",
            exclude=["cache", "tmp"]
        )
        
        assert project.name == "my-project"
        assert project.source == "/data/my"
        assert project.exclude == ["cache", "tmp"]
