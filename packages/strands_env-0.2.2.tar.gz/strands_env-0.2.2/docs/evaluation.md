# Evaluation Guide

This guide covers running benchmark evaluations with `strands-env`.

## CLI Reference

The `strands-env` CLI provides commands for running benchmark evaluations.

### List Benchmarks

```bash
strands-env eval list
```

### Run Evaluation

```bash
# Using a registered benchmark
strands-env eval run <benchmark> --env <hook_file> [options]

# Using a custom evaluator hook
strands-env eval run --evaluator <evaluator_file> --env <hook_file> [options]
```

**Required arguments:**
- `<benchmark>` - Benchmark name (e.g., `aime-2024`, `aime-2025`), OR
- `--evaluator` - Path to evaluator hook file (mutually exclusive with benchmark)
- `--env`, `-e` - Path to environment hook file

**Model options:**
- `--backend`, `-b` - Model backend: `sglang` (default) or `bedrock`
- `--base-url` - SGLang server URL (default: `http://localhost:30000`)
- `--model-id` - Model ID (auto-detected for SGLang, required for Bedrock)
- `--tokenizer-path` - Tokenizer path (defaults to model_id)
- `--tool-parser` - Tool parser name (e.g., `hermes`, `qwen_xml`) or path to hook file
- `--region` - AWS region for Bedrock
- `--profile-name` - AWS profile name for Bedrock
- `--role-arn` - AWS role ARN to assume for Bedrock

**Sampling options:**
- `--temperature` - Sampling temperature (default: 0.7)
- `--max-tokens` - Maximum new tokens (default: 16384)
- `--top-p` - Top-p sampling (default: 0.95)
- `--top-k` - Top-k sampling

**Evaluation options:**
- `--n-samples-per-prompt` - Samples per prompt for pass@k (default: 1)
- `--max-concurrency` - Maximum concurrent evaluations (default: 10)
- `--output`, `-o` - Output directory (default: `{benchmark}_eval/`)
- `--save-interval` - Save results every N samples (default: 10)
- `--keep-tokens` - Keep token-level observations in results

**Other options:**
- `--system-prompt` - Path to system prompt file
- `--max-tool-iters` - Maximum tool iterations per step (default: None)
- `--max-tool-calls` - Maximum tool calls per step (default: None)
- `--debug` - Enable debug logging

### Examples

```bash
# Using registered benchmark with code sandbox env
strands-env eval run aime-2024 \
    --env examples/eval/aime_code/code_sandbox_env.py \
    --base-url http://localhost:30000

# Using custom evaluator hook (custom benchmark)
strands-env eval run \
    --evaluator examples/eval/simple_math/simple_math_evaluator.py \
    --env examples/eval/simple_math/calculator_env.py \
    --base-url http://localhost:30000

# Pass@8 evaluation with high concurrency
strands-env eval run aime-2024 \
    --env examples/eval/simple_math/calculator_env.py \
    --base-url http://localhost:30000 \
    --n-samples-per-prompt 8 \
    --max-concurrency 30

# With custom tool parser
strands-env eval run aime-2024 \
    --env examples/eval/simple_math/calculator_env.py \
    --base-url http://localhost:30000 \
    --tool-parser qwen_xml
```

## Hook Files

Environment hook files define how environments are created for each evaluation sample. They must export a `create_env_factory` function.

### Structure

```python
from strands_env.cli.config import EnvConfig
from strands_env.core.models import ModelFactory

def create_env_factory(model_factory: ModelFactory, env_config: EnvConfig):
    """Create an async environment factory.

    Args:
        model_factory: Factory for creating model instances.
        env_config: Environment configuration from CLI.

    Returns:
        Async function that creates an Environment for each action.
    """
    async def env_factory(action):
        return YourEnvironment(
            model_factory=model_factory,
            system_prompt=env_config.system_prompt,
            max_tool_iters=env_config.max_tool_iters,
        )

    return env_factory
```

### Example: Calculator Environment

```python
# examples/eval/simple_math/calculator_env.py
from strands_env.cli.config import EnvConfig
from strands_env.core.models import ModelFactory
from strands_env.environments.calculator import CalculatorEnv
from strands_env.rewards import MathRewardFunction

def create_env_factory(model_factory: ModelFactory, env_config: EnvConfig):
    reward_fn = MathRewardFunction()

    async def env_factory(_action):
        return CalculatorEnv(
            model_factory=model_factory,
            reward_fn=reward_fn,
            system_prompt=env_config.system_prompt,
            max_tool_iters=env_config.max_tool_iters,
        )

    return env_factory
```

### Example: Code Sandbox Environment

```python
# examples/eval/aime_code/code_sandbox_env.py
from strands_env.cli.config import EnvConfig
from strands_env.core.models import ModelFactory
from strands_env.environments.code_sandbox import CodeMode, CodeSandboxEnv
from strands_env.rewards import MathRewardFunction

def create_env_factory(model_factory: ModelFactory, env_config: EnvConfig):
    reward_fn = MathRewardFunction()

    async def env_factory(_action):
        return CodeSandboxEnv(
            model_factory=model_factory,
            reward_fn=reward_fn,
            system_prompt=env_config.system_prompt,
            max_tool_iters=env_config.max_tool_iters,
            mode=CodeMode.CODE,
        )

    return env_factory
```

## Custom Evaluators

For custom benchmarks, subclass `Evaluator`. You can either register it with `@register_eval` or use an evaluator hook file.

### Evaluator Hook File

Create a Python file that exports `EvaluatorClass`:

```python
# my_evaluator.py
from collections.abc import Iterable

from strands_env.core import Action, TaskContext
from strands_env.eval import Evaluator

class MyEvaluator(Evaluator):
    benchmark_name = "my-benchmark"

    def load_dataset(self) -> Iterable[Action]:
        for item in load_my_data():
            yield Action(
                message=item["prompt"],
                task_context=TaskContext(
                    id=item["id"],
                    ground_truth=item["answer"],
                ),
            )

EvaluatorClass = MyEvaluator
```

Then run:
```bash
strands-env eval run --evaluator my_evaluator.py --env my_env.py --base-url http://localhost:30000
```

### Registered Evaluator

To add a built-in benchmark, create a module in `src/strands_env/eval/benchmarks/` and use `@register_eval`:

```python
# src/strands_env/eval/benchmarks/my_benchmark.py
from collections.abc import Iterable

from strands_env.core import Action, TaskContext

from ..evaluator import Evaluator
from ..registry import register_eval

@register_eval("my-benchmark")
class MyEvaluator(Evaluator):
    benchmark_name = "my-benchmark"

    def load_dataset(self) -> Iterable[Action]:
        """Load dataset and return Actions for evaluation."""
        for item in load_my_data():
            yield Action(
                message=item["prompt"],
                task_context=TaskContext(
                    id=item["id"],
                    ground_truth=item["answer"],
                ),
            )
```

Benchmarks are auto-discovered from the `benchmarks/` subdirectory. If a benchmark has missing dependencies, it will be listed as unavailable in `strands-env eval list` with the import error message.

### Programmatic Usage

```python
async def run_evaluation():
    evaluator = MyEvaluator(
        env_factory=env_factory,
        n_samples_per_prompt=8,
        max_concurrency=30,
        output_path="results.jsonl",
        keep_tokens=False,
    )

    actions = evaluator.load_dataset()
    results = await evaluator.run(actions)
    metrics = evaluator.compute_metrics(results)
    # {"pass@1": 0.75, "pass@8": 0.95, ...}
```

### Custom Metrics

Override `get_metric_fns()` to customize metrics:

```python
from functools import partial

from strands_env.eval import Evaluator
from strands_env.eval.metrics import compute_pass_at_k

class MyEvaluator(Evaluator):
    benchmark_name = "my-benchmark"

    def load_dataset(self):
        ...

    def get_metric_fns(self):
        # Include default pass@k plus custom metrics
        return [
            partial(compute_pass_at_k, k_values=[1, 5, 10], reward_threshold=1.0),
            self.my_custom_metric,
        ]

    def my_custom_metric(self, results: dict) -> dict:
        return {"my_metric": compute_something(results)}
```

## Tool Parser Hook

For models that use non-standard tool calling formats, you can specify a custom tool parser via `--tool-parser`. This accepts either:

1. A predefined parser name from `strands-sglang` (e.g., `hermes`, `qwen_xml`)
2. A path to a Python hook file

### Hook File Format

The hook file must export either `tool_parser` (instance) or `ToolParserClass` (subclass):

```python
# my_tool_parser.py
from strands_sglang.tool_parsers import ToolParser, ToolParseResult

class MyToolParser(ToolParser):
    def parse(self, text: str) -> list[ToolParseResult]:
        # Custom parsing logic
        ...

# Export as instance
tool_parser = MyToolParser()

# OR export as class (will be instantiated)
ToolParserClass = MyToolParser
```

Then use:
```bash
strands-env eval run aime-2024 \
    --env my_env.py \
    --base-url http://localhost:30000 \
    --tool-parser my_tool_parser.py
```

## Output Files

Evaluation results are saved to the output directory:

```
{benchmark}_eval/
├── config.json      # CLI configuration for reproducibility
├── results.jsonl    # Per-sample results (action, step_result, reward)
└── metrics.json     # Aggregated metrics (pass@k, etc.)
```

The evaluator supports checkpointing and resume - if interrupted, it will skip already-completed samples on restart.
