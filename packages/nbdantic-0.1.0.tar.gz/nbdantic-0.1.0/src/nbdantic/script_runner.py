from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from types import TracebackType
from typing import Any, Literal, Self

import tomlkit

from nbdantic.nbrs import VersionT, package_spec_from_string


def python_version_cast(pv: str) -> tuple[str, str, str]:
    parts = pv.split(".")
    if len(parts) not in [1, 2, 3]:
        raise ValueError("incorrect version specification")
    macro, minor, micro = (parts + ["*", "*"])[:3]
    return (macro, minor, micro)


@dataclass
class OpVer:
    operator: Literal["==", "~=", ">=", ">", "<=", "<", "!="]
    version: str

    @property
    def uv_spec(self):
        return f"{self.operator}{self.version}"

    @classmethod
    def from_version_spec(cls, pkg_spec) -> list[Self]:
        return [cls(operator=p.operator, version=p.version) for p in pkg_spec]


type VersionUrl = str


@dataclass
class PackageSpec:
    name: str
    version: list[OpVer] | VersionUrl | None = field(default_factory=lambda: None)

    def __post_init__(self):
        # NOTE: check that OpVer is valid, so we can test that building the packagespec
        # directly is broken or not. Check that VersionUrl is actually an url with
        # the proper bindings
        match self.version:
            case None:
                return
            case str() | list():
                package_spec_from_string(self.uv_spec)

    @property
    def uv_spec(self) -> str:
        # TODO: uv spec because heavy usage by uv, but it should be
        # spec string or similar.
        match self.version:
            case list():
                ops = ",".join(op.uv_spec for op in self.version)
                return f"{self.name}{ops}"
            case str():
                return f"{self.name} @ {self.version}"
            case _:
                if self.version is None:
                    return f"{self.name}"
                else:
                    raise ValueError("should not occur, invalid type on version")

    @classmethod
    def parse(cls, spec: str) -> PackageSpec:
        pkg_spec = package_spec_from_string(spec)
        match pkg_spec.version_type:
            case VersionT.Url:
                return cls(name=pkg_spec.package_name, version=pkg_spec.version_str)
            case VersionT.VerSpec:
                return cls(
                    name=pkg_spec.package_name,
                    version=OpVer.from_version_spec(pkg_spec.pkg_spec),
                )
            case None:
                return cls(name=pkg_spec.package_name)

    @classmethod
    def from_any(cls, pkg: str | PackageSpec) -> PackageSpec:
        match pkg:
            case PackageSpec():
                return pkg
            case str():
                return cls.parse(pkg)
            case _:
                raise ValueError(f"expected str | PackageSpec, got {type(pkg)}")


def _merge_toml(target: dict[str, Any], source: dict[str, Any]) -> None:
    for key, value in source.items():
        if key in target and isinstance(target[key], dict) and isinstance(value, dict):
            _merge_toml(target[key], value)
        else:
            target[key] = value


def _python_version_spec(python_version: str | OpVer | list[OpVer]) -> str:
    match python_version:
        case list() as ovs:
            return ",".join(ov.uv_spec for ov in ovs)
        case OpVer():
            return python_version.uv_spec
        case str():
            return f"=={python_version}"


def _inline_script_header(
    packages: list[str | PackageSpec],
    python_version: str | OpVer = "3.13",
) -> str:
    """minimal non exhaustive way of running the inline script header for our use case, for a
    full scoping of the differences check https://docs.astral.sh/uv/guides/scripts/#creating-a-python-script"""
    lines = []
    w = lines.append

    w("# /// script")
    deps = []

    for pkg in packages:
        spec = PackageSpec.from_any(pkg)
        deps.append(spec.uv_spec)

    if deps:
        w(f"# dependencies = {deps!r}")

    pv_spec = _python_version_spec(python_version)
    w(f'# requires-python = "{pv_spec}"')
    w("# ///")
    return "\n".join(lines)


class UVScriptRunner:
    def __init__(
        self,
        packages: list[str | PackageSpec] | None = None,
        python_version: str | None = None,
        pyproject_entries: list[tuple[str, str]] | None = None,
        work_dir: Path | str | None = None,
    ) -> None:
        """if using work_dir for the creation of temporary files during execution
        the folder needs to be isolated"""
        self.packages = packages or []
        self.python_version = python_version_cast(python_version or "3.13")
        self.pyproject_entries = pyproject_entries or []
        self.work_dir = self._resolve_work_dir(work_dir)
        self._validate_uv_installed()

    @staticmethod
    def _resolve_work_dir(work_dir: Path | str | None) -> Path:
        if work_dir is None:
            return Path(tempfile.gettempdir()) / "nbdanticrunner" / str(uuid.uuid4())
        path = Path(work_dir)
        if path.exists() and not path.is_dir():
            raise ValueError(f"work_dir must be a directory, got: {path}")
        return path

    @staticmethod
    def _validate_uv_installed() -> None:
        if not shutil.which("uv"):
            raise RuntimeError("uv not found")

    def __enter__(self) -> Self:
        if self.work_dir.exists():
            shutil.rmtree(self.work_dir)
        self.generate_pyproject()
        if not self.packages:
            return self
        result = self.add_packages(self.packages)
        if result.returncode != 0:
            raise RuntimeError(f"failed to install packages: \n{result.stderr}\n{result.stdout}")
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> bool:
        if self.work_dir.exists():
            shutil.rmtree(self.work_dir)
        return False

    def pyproject_content(
        self,
        *,
        name: str = "test",
        version: str = "0.1.0",
        description: str = "",
        author: str = "nbdantic",
    ) -> str:
        doc = tomlkit.document()

        project = tomlkit.table()
        project["name"] = name
        project["version"] = version
        project["description"] = description
        project["requires-python"] = f"=={'.'.join(self.python_version)}"
        project["dependencies"] = tomlkit.array()

        authors = tomlkit.array()
        author_tbl = tomlkit.inline_table()
        author_tbl["name"] = author
        authors.append(author_tbl)
        project["authors"] = authors

        doc["project"] = project

        sections: dict[str, list[str]] = defaultdict(list)
        for section, line in self.pyproject_entries:
            sections[section].append(line)

        for section, lines in sections.items():
            raw = f"[{section}]\n" + "\n".join(lines) + "\n"
            parsed = tomlkit.parse(raw)
            _merge_toml(doc, parsed)

        return tomlkit.dumps(doc)

    def add_packages(
        self,
        packages: list[str | PackageSpec],
        flags: list[str] | None = None,
    ) -> subprocess.CompletedProcess[str]:
        builtin_modules = sys.stdlib_module_names
        final_packages: list[str] = []
        for pkg in packages:
            spec = PackageSpec.from_any(pkg)
            if spec.name not in builtin_modules:
                final_packages.append(spec.uv_spec)

        if not final_packages:
            return subprocess.CompletedProcess(args=[], returncode=0, stdout="", stderr="")

        return subprocess.run(
            [
                "uv",
                "add",
                *(flags or []),
                *final_packages,
            ],
            cwd=self.work_dir,
            capture_output=True,
            text=True,
        )

    def write_tmp_file(
        self,
        content: str | bytes,
        extension: str,
        private: bool = True,
    ) -> Path:
        self.work_dir.mkdir(parents=True, exist_ok=True)
        tmp_file = self.work_dir / f"{'_' if private else ''}{uuid.uuid4()}.{extension}"
        if isinstance(content, str):
            tmp_file.write_text(content)
        elif isinstance(content, bytes):
            tmp_file.write_bytes(content)
        return tmp_file

    def generate_pyproject(self, **kwargs: Any) -> str:
        self.work_dir.mkdir(parents=True, exist_ok=True)
        content = self.pyproject_content(**kwargs)
        pyproject_path = self.work_dir / "pyproject.toml"
        pyproject_path.write_text(content)
        return content

    def run(
        self,
        command_args: list[str | Path],
        **subprocess_kwargs: Any,
    ) -> subprocess.CompletedProcess[str]:
        env = os.environ.copy()
        venv_path = str(self.work_dir.absolute()) + "/.venv"
        env["UV_PROJECT_ENVIRONMENT"] = venv_path
        env["VIRTUAL_ENV"] = venv_path
        return subprocess.run(
            command_args,
            env=env,
            **subprocess_kwargs,
        )

    def oneshot_cmd(
        self,
        command: list[str | Path],
        flags: list[str] | None = None,
        timeout: float | None = None,
    ) -> subprocess.CompletedProcess[str]:
        return self.run(
            ["uv", "run", *(flags or []), *command],
            cwd=self.work_dir,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

    def oneshot_python(
        self,
        code_content: str,
        flags: list[str] | None = None,
        timeout: float | None = None,
    ) -> subprocess.CompletedProcess[str]:
        return self.run(
            [
                "uv",
                "run",
                *(flags or []),
                "python",
                "-c",
                code_content,
            ],
            cwd=self.work_dir,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

    def run_inline_script(
        self,
        code: str,
        packages: list[str | PackageSpec] | None = None,
        python_version: str | OpVer | None = None,
        timeout: float | None = None,
    ) -> subprocess.CompletedProcess[str]:
        pv = python_version or ".".join(self.python_version[:2])
        header = _inline_script_header(packages or self.packages, pv)
        script = f"{header}\n\n{code}"
        script_path = self.write_tmp_file(script, "py", private=True)
        return self.run(
            ["uv", "run", str(script_path)],
            cwd=self.work_dir,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
