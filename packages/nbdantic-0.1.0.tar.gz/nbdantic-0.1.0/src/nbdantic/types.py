from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, TypedDict

import nbformat as nbf

type CellContent = str
type Label = str
type SequenceContent = list[dict[Label, Any]]

type CellValidator = Callable[[CellContent], None]
type SequenceValidator = Callable[[SequenceContent], None]
type TerminalCellCheck = Callable[[nbf.NotebookNode], bool]
type InitialCellCheck = Callable[[nbf.NotebookNode], bool]


class ErrorDict(TypedDict):
    ValidationError: Exception | None


@dataclass
class CellNode:
    cell_type: str
    source: str
    metadata: dict[str, Any] = field(default_factory=dict)
    outputs: list[Any] = field(default_factory=list)
    execution_count: int | None = None

    @classmethod
    def from_nbnode(cls, node: nbf.NotebookNode) -> CellNode:
        return cls(
            cell_type=node["cell_type"],
            source=node["source"],
            metadata=dict(node.get("metadata", {})),
            outputs=list(node.get("outputs", [])),
            execution_count=node.get("execution_count"),
        )


@dataclass
class ChoiceResult:
    matched_option: Label
    matched_type: str
    cells: CellsMap


type CellsMapValue = CellNode | ChoiceResult | list[CellsMap] | CellsMap | None
type CellsMap = dict[Label, CellsMapValue]
