import importlib
import importlib.util
import logging
import re
import sys
from enum import Enum

try:

    def _find_module(module: str) -> list[str]:
        spec = importlib.util.find_spec(module)
        return [spec.name] if spec else []

    def _load_module(_: str, module: str) -> object:
        return importlib.import_module(module)

    setattr(importlib, "find_module", _find_module)
    setattr(importlib, "load_module", _load_module)
    sys.modules["imp"] = importlib

    from ansiwrap import wrap as _wrap
except ImportError:
    from textwrap import wrap as _wrap

STATUS_LEN = 88

_ANSI: dict[str, str] = {
    "red": "31",
    "green": "32",
    "yellow": "33",
    "blue": "34",
    "magenta": "35",
    "cyan": "36",
    "white": "37",
    "black": "30",
    "orange": "38;5;208",
    "purple": "38;5;141",
    "pink": "38;5;217",
}

_STATUS_COLORS: dict[str, str] = {
    "STARTED": "yellow",
    "PASSED": "green",
    "FAILED": "red",
    "WARNING": "orange",
    "INFO": "purple",
}

_nocolor: bool = False


def set_nocolor(enabled: bool = True) -> None:
    global _nocolor
    _nocolor = enabled
    _handler.setFormatter(PlainFormatter() if enabled else StatusFormatter())


class LogStatus(Enum):
    STARTED = "STARTED"
    PASSED = "PASSED"
    FAILED = "FAILED"
    WARNING = "WARNING"
    INFO = "INFO"


# NOTE: inspired always by geohotz tinygrad/helpers.py `colored()``
def cstr(color: str | None, text: object, bold: bool = False) -> str:
    if _nocolor or color is None or color not in _ANSI:
        return str(text)
    b = "1;" if bold else ""
    return f"\033[{b}{_ANSI[color]}m{text}\033[0m"


def ansistrip(s: str) -> str:
    return re.sub(r"\x1b\[(K|.*?m)", "", s)


def ansilen(s: str) -> int:
    return len(ansistrip(s))


def word_wrap(s: str, width: int = 80) -> str:
    if ansilen(s) <= width:
        return s
    lines = s.splitlines()
    if len(lines) > 1:
        return "\n".join(word_wrap(line, width) for line in lines)
    i = 0
    while ansilen(s[:i]) < width and i < len(s):
        i += 1
    return s[:i] + "\n" + word_wrap(s[i:], width)


class PlainFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        status: LogStatus | None = getattr(record, "status", None)
        if status is None:
            return super().format(record)

        msg = record.getMessage()
        lines = msg.split("\n")
        all_chunks: list[str] = []
        for line in lines:
            chunks = _wrap(line, width=STATUS_LEN - 1, break_long_words=False) if line.strip() else [""]
            all_chunks.extend(chunks)

        parts: list[str] = []
        if status == LogStatus.WARNING:
            parts.append(f"{'-' * (STATUS_LEN - 1)} [{status.value}]")

        first_line = f"{all_chunks[0]:<{STATUS_LEN - 1}}"
        if status == LogStatus.WARNING:
            parts.append(first_line)
        else:
            parts.append(f"{first_line} [{status.value}]")

        for chunk in all_chunks[1:]:
            parts.append(chunk)

        if status == LogStatus.WARNING:
            parts.append("-" * (STATUS_LEN - 1))

        return "\n".join(parts)


class StatusFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        status: LogStatus | None = getattr(record, "status", None)
        nocolor: bool = getattr(record, "nocolor", False)

        if status is None:
            return super().format(record)

        msg = record.getMessage()
        color = _STATUS_COLORS.get(status.value)
        status_tag = cstr(color, f" [{status.value}]", bold=True)

        lines = msg.split("\n")
        all_chunks: list[str] = []
        for line in lines:
            chunks = _wrap(line, width=STATUS_LEN - 1, break_long_words=False) if line.strip() else [""]
            all_chunks.extend(chunks)

        text_color = "orange" if status == LogStatus.WARNING and not nocolor else None
        parts: list[str] = []

        if status == LogStatus.WARNING:
            parts.append(f"{'-' * (STATUS_LEN - 1)}{status_tag}")

        visible_len = ansilen(all_chunks[0])
        pad = max(STATUS_LEN - 1 - visible_len, 0)
        first_line = all_chunks[0] + " " * pad
        if status == LogStatus.WARNING:
            parts.append(cstr(text_color, first_line))
        else:
            parts.append(cstr(text_color, first_line) + status_tag)

        for chunk in all_chunks[1:]:
            parts.append(cstr(text_color, chunk))

        if status == LogStatus.WARNING:
            parts.append("-" * (STATUS_LEN - 1))

        return "\n".join(parts)


class NbdanticLogger(logging.Logger):
    def status_log(self, msg: str, status: LogStatus, nocolor: bool = False) -> None:
        level = logging.WARNING if status == LogStatus.WARNING else logging.INFO
        self.log(level, msg, extra={"status": status, "nocolor": nocolor})


logging.setLoggerClass(NbdanticLogger)

logger: NbdanticLogger = logging.getLogger("nbdantic")  # type: ignore

_handler = logging.StreamHandler()
_handler.setFormatter(StatusFormatter())
logger.addHandler(_handler)
logger.setLevel(logging.INFO)
logger.propagate = False
