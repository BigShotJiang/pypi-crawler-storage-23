from __future__ import annotations

import inspect
from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, ClassVar, Final, Self, cast

import nbformat as nbf

from .grammar import (
    Cell,
    CellValidationError,
    Choice,
    Code,
    Markdown,
    Maybe,
    ParseElement,
    Sequence,
    SequenceError,
    _validator_name,
)
from .logger import LogStatus, cstr, logger
from .types import CellNode, CellsMap, ChoiceResult, ErrorDict, InitialCellCheck, Label, TerminalCellCheck

CELL_PREVIEW_LEN: Final[int] = 200


@dataclass
class ValidationFailure:
    cell_index: int
    label: Label
    element_type: str
    message: str
    cell_preview: str = ""
    validator_name: str | None = None

    def __str__(self) -> str:
        header = f"cell #{self.cell_index} — {self.element_type}({self.label})"
        parts = [cstr("red", header, True)]
        if self.validator_name:
            parts.append(f"  validator: {cstr('magenta', self.validator_name, True)}")
        parts.append(f"  {self.message}")
        if self.cell_preview:
            preview = self.cell_preview[:CELL_PREVIEW_LEN]
            if len(self.cell_preview) > CELL_PREVIEW_LEN:
                preview += "..."
            parts.append(f"  content: {cstr('cyan', preview)}")
        return "\n".join(parts)


@dataclass
class ValidationResult:
    success: bool
    cells_map: CellsMap | None = None
    failures: list[ValidationFailure] = field(default_factory=list)

    def __bool__(self) -> bool:
        return self.success

    def raise_if_failed(self) -> None:
        if not self.success:
            msg = "\n\n".join(str(f) for f in self.failures)
            raise ValueError(f"validation failed:\n\n{msg}")


def _nice(element: ParseElement) -> str:
    match element:
        case Code() | Markdown():
            return f"{element.cell_type} - {element.label}"
        case Maybe():
            return f"maybe({element.label})"
        case Choice():
            return f"choice({' | '.join(s.label for s in element.options)}) - {element.label}"
        case list():
            return "\n".join(_nice(s) for s in element)
        case _:
            return str(element)


def _cell_preview(cells: list[nbf.NotebookNode], idx: int) -> str:
    if 0 <= idx < len(cells):
        return str(cells[idx].get("source", ""))[:CELL_PREVIEW_LEN]
    return ""


def _error_dict_factory() -> ErrorDict:
    return ErrorDict(ValidationError=None)


def _raise_if_nbf_validation_error(error_dict: ErrorDict) -> None:
    if isinstance(validation_error := error_dict["ValidationError"], Exception):
        raise validation_error


def _default_is_terminal_cell(cell: nbf.NotebookNode) -> bool:
    return str(cell.get("source", "")).startswith("# END")


def _default_is_initial_cell(_cell: nbf.NotebookNode) -> bool:
    return True


class _NotebookMeta(type):
    def __new__(
        mcs,
        cls_name: str,
        bases: tuple[type[Any], ...],
        namespace: dict[str, Any],
        **kwargs: Any,
    ) -> type:
        cls = super().__new__(mcs, cls_name, bases, namespace, **kwargs)

        if not bases:
            return cls

        if "structure" in namespace:
            structure = namespace["structure"]
            if not isinstance(structure, Sequence):
                raise TypeError(f"{cls_name}.structure must be a Sequence, got {type(structure).__name__}")

        for attr in ("is_terminal_cell", "is_initial_cell"):
            if attr in namespace:
                fn = namespace[attr]
                if not callable(fn):
                    raise TypeError(f"{cls_name}.{attr} must be callable")
                sig = inspect.signature(fn)
                params = [
                    p
                    for p in sig.parameters.values()
                    if p.default is inspect.Parameter.empty
                    and p.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)
                ]
                if len(params) != 1:
                    raise TypeError(
                        f"{cls_name}.{attr} must accept exactly 1 parameter (NotebookNode), got {len(params)}"
                    )

        return cls


class JupyterNotebook(metaclass=_NotebookMeta):
    structure: ClassVar[Sequence]
    is_terminal_cell: ClassVar[TerminalCellCheck] = _default_is_terminal_cell
    is_initial_cell: ClassVar[InitialCellCheck] = _default_is_initial_cell

    def __init__(self) -> None:
        self.cells: list[nbf.NotebookNode] = []
        self._cells_map: CellsMap | None = None

    @classmethod
    def from_str(
        cls,
        notebook_str: str,
        as_version: int | None = None,
        *,
        validate: bool = True,
    ) -> Self:
        error_dict = _error_dict_factory()
        notebook = nbf.reads(
            notebook_str,
            as_version=as_version or nbf.NO_CONVERT,
            capture_validation_error=error_dict,
        )
        _raise_if_nbf_validation_error(error_dict)
        return cls._load(notebook, validate=validate)

    @classmethod
    def from_file(
        cls,
        path: str | Path,
        as_version: int | None = None,
        *,
        validate: bool = True,
    ) -> Self:
        error_dict = _error_dict_factory()
        notebook = nbf.read(
            path,
            as_version=as_version or nbf.NO_CONVERT,
            capture_validation_error=error_dict,
        )
        _raise_if_nbf_validation_error(error_dict)
        return cls._load(notebook, validate=validate)

    @classmethod
    def from_node(cls, notebook: nbf.NotebookNode, *, validate: bool = True) -> Self:
        return cls._load(notebook, validate=validate)

    @classmethod
    def _load(cls, notebook: nbf.NotebookNode, *, validate: bool = True) -> Self:
        instance = cls()
        all_cells = list(notebook.cells)

        start = 0
        for i, cell in enumerate(all_cells):
            if cls.is_initial_cell(cell):
                start = i
                break

        end = len(all_cells)
        for i in range(start, len(all_cells)):
            if cls.is_terminal_cell(all_cells[i]):
                end = i
                break

        instance.cells = all_cells[start:end]

        if validate:
            instance.validate().raise_if_failed()

        return instance

    @property
    def cells_map(self) -> CellsMap:
        if self._cells_map is None:
            raise ValueError("no cells map — call validate() first")
        return self._cells_map

    def validate(self, *, fail_fast: bool = True) -> ValidationResult:
        return self._validate_structure(self.structure, fail_fast=fail_fast)

    def _validate_structure(
        self,
        expected_structure: Sequence,
        *,
        fail_fast: bool = True,
    ) -> ValidationResult:
        pending_validations: list[tuple[Callable[..., Any], Any, Label, int, str]] = []
        failures: list[ValidationFailure] = []

        def derive(
            cells: list[nbf.NotebookNode],
            production: Cell | Sequence | Choice | Maybe,
            possible_next: list[str],
            cells_map: CellsMap,
            start_idx: int = 0,
        ) -> int:
            current_idx = start_idx

            if len(cells) <= current_idx:
                match production:
                    case Maybe():
                        cells_map[production.label] = None
                        return current_idx
                    case Sequence() if production.empty:
                        cells_map[production.label] = []
                        return current_idx
                    case _:
                        possible_next.append(f"{production.__class__.__name__}({production.label})")
                        raise IndexError(
                            f"\nran out of cells at position "
                            f"{cstr('yellow', current_idx, True)}. "
                            f"expected {production.__class__.__name__}({production.label})"
                        )

            match production:
                case Markdown() | Code():
                    cell_type = cells[current_idx]["cell_type"]
                    if cell_type != production.cell_type:
                        failures.append(
                            ValidationFailure(
                                cell_index=current_idx,
                                label=production.label,
                                element_type=production.__class__.__name__,
                                message=f"expected {production.cell_type}, got {cell_type}",
                                cell_preview=_cell_preview(cells, current_idx),
                            )
                        )
                        raise ValueError(
                            f"\nexpected {production.__class__.__name__}({production.label}) "
                            f"at position {cstr('yellow', current_idx, True)}, got {cell_type}"
                        )

                    if production.validators:
                        pending_validations.append(
                            (
                                production.validate,
                                cells[current_idx]["source"],
                                production.label,
                                current_idx,
                                production.__class__.__name__,
                            )
                        )

                    logger.status_log(f"[{current_idx:03}] {_nice(production)}", LogStatus.PASSED)
                    cells_map[production.label] = CellNode.from_nbnode(cells[current_idx])
                    return current_idx + 1

                case Maybe():
                    try:
                        temp_cells_map: CellsMap = {}
                        saved_pending = len(pending_validations)
                        saved_failures = len(failures)
                        new_idx = derive(cells, production.element, [], temp_cells_map, current_idx)
                        cells_map[production.label] = temp_cells_map
                        logger.status_log(
                            f"[{new_idx - 1:03}] {_nice(production)} -> matched",
                            LogStatus.PASSED,
                        )
                        return new_idx
                    except (ValueError, IndexError):
                        # unmatched validations and failures must be delted
                        del pending_validations[saved_pending:]
                        del failures[saved_failures:]
                        cells_map[production.label] = None
                        return current_idx

                case Choice():
                    for option in production.options:
                        try:
                            temp: CellsMap = {}
                            saved_pending = len(pending_validations)
                            saved_failures = len(failures)
                            new_idx = derive(cells, option, [], temp, current_idx)
                            cells_map[production.label] = ChoiceResult(
                                matched_option=option.label,
                                matched_type=option.__class__.__name__,
                                cells=temp,
                            )
                            logger.status_log(
                                f"[{new_idx - 1:03}] {_nice(production)} -> matched {option.label}",
                                LogStatus.PASSED,
                            )
                            return new_idx
                        except (ValueError, IndexError):
                            # unmatched validations and failures must be delted
                            del pending_validations[saved_pending:]
                            del failures[saved_failures:]

                    option_labels = " | ".join(o.label for o in production.options)
                    failures.append(
                        ValidationFailure(
                            cell_index=current_idx,
                            label=production.label,
                            element_type="Choice",
                            message=f"no option matched ({option_labels})",
                            cell_preview=_cell_preview(cells, current_idx),
                        )
                    )
                    raise ValueError(
                        f"\nno option in Choice({production.label}) matched at position "
                        f"{cstr('yellow', current_idx, True)}"
                    )

                case Sequence():
                    pattern_ended, match_count = False, 0
                    cells_map[production.label] = []
                    while not pattern_ended:
                        _cm: CellsMap = {}
                        saved_idx = current_idx
                        saved_pending_seq = len(pending_validations)
                        saved_failures_seq = len(failures)
                        for i, sub_expected in enumerate(production):
                            try:
                                current_idx = derive(cells, sub_expected, possible_next, _cm, current_idx)
                            except (ValueError, IndexError) as e:
                                if (match_count > 0 and i == 0) or (i == 0 and production.empty):
                                    # unmatched or empty is valid validations and failures must be deleted
                                    current_idx = saved_idx
                                    del pending_validations[saved_pending_seq:]
                                    del failures[saved_failures_seq:]
                                    pattern_ended = True
                                    break
                                raise e
                        if not pattern_ended:
                            cast(list, cells_map[production.label]).append(_cm)
                            match_count += 1

                    for v in production.validators:
                        pending_validations.append(
                            (
                                v,
                                cells_map[production.label],
                                production.label,
                                current_idx,
                                "Sequence",
                            )
                        )
                    return current_idx

                case _:
                    raise ValueError(
                        "ill-formatted production: only Code, Markdown, Choice, Maybe, and Sequence objects are accepted"
                    )

        try:
            idx = 0
            possible_next: list[str] = []
            cells_map: CellsMap = {}
            for struct in expected_structure:
                try:
                    idx = derive(self.cells, struct, possible_next, cells_map, idx)
                except IndexError:
                    failures.append(
                        ValidationFailure(
                            cell_index=idx,
                            label="<root>",
                            element_type="Sequence",
                            message="ran out of cells, expected: " + ", ".join(possible_next),
                        )
                    )
                    logger.status_log(
                        f"ran out of cells at position {idx}, expected one of:\n" + "\n".join(possible_next),
                        LogStatus.FAILED,
                    )
                    return ValidationResult(success=False, failures=failures)

            if idx < len(self.cells):
                failures.append(
                    ValidationFailure(
                        cell_index=idx,
                        label="<root>",
                        element_type="Sequence",
                        message="found extra cells, remove them!",
                    )
                )
                raise ValueError("found extra cells, remove them!")

        except (ValueError, SequenceError) as e:
            logger.status_log(str(e), LogStatus.FAILED)
            return ValidationResult(success=False, failures=failures)
        except Exception as e:
            failures.append(
                ValidationFailure(
                    cell_index=-1,
                    label="<root>",
                    element_type="<unknown>",
                    message=f"unexpected error: {e!s}",
                )
            )
            logger.status_log(f"validation failed: {e}", LogStatus.FAILED)
            return ValidationResult(success=False, failures=failures)

        for v in expected_structure.validators:
            pending_validations.append((v, [cells_map], expected_structure.label, -1, "Sequence"))

        for validator, content, label, cell_idx, elem_type in pending_validations:
            try:
                validator(deepcopy(content))
            except CellValidationError as e:
                failure = ValidationFailure(
                    cell_index=cell_idx,
                    label=label,
                    element_type=elem_type,
                    message=str(e),
                    cell_preview=str(content)[:CELL_PREVIEW_LEN] if isinstance(content, str) else "",
                    validator_name=e.validator_name,
                )
                failures.append(failure)
                logger.status_log(str(failure), LogStatus.FAILED)
                if fail_fast:
                    return ValidationResult(success=False, cells_map=cells_map, failures=failures)
            except Exception as e:
                failure = ValidationFailure(
                    cell_index=cell_idx,
                    label=label,
                    element_type=elem_type,
                    message=str(e),
                    cell_preview=str(content)[:CELL_PREVIEW_LEN] if isinstance(content, str) else "",
                    validator_name=_validator_name(validator),
                )
                failures.append(failure)
                logger.status_log(str(failure), LogStatus.FAILED)
                if fail_fast:
                    return ValidationResult(success=False, cells_map=cells_map, failures=failures)

        if failures:
            return ValidationResult(success=False, cells_map=cells_map, failures=failures)

        self._cells_map = cells_map
        return ValidationResult(success=True, cells_map=cells_map)
