from __future__ import annotations

import inspect
from copy import deepcopy
from textwrap import dedent
from typing import Any, Callable, ClassVar, Final, Iterator, cast

from .logger import cstr
from .types import CellContent, CellValidator, Label, SequenceValidator


def _validator_name(v: Callable[..., Any]) -> str:
    return getattr(v, "__name__", type(v).__name__)


def _check_cell_validator(v: CellValidator) -> None:
    try:
        sig = inspect.signature(v)
    except (ValueError, TypeError):
        return
    params = [
        p
        for p in sig.parameters.values()
        if p.default is inspect.Parameter.empty
        and p.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)
    ]
    if len(params) != 1:
        raise TypeError(
            f"CellValidator '{_validator_name(v)}' must accept exactly 1 positional "
            f"parameter (CellContent), got {len(params)}"
        )


def _check_sequence_validator(v: SequenceValidator) -> None:
    try:
        sig = inspect.signature(v)
    except (ValueError, TypeError):
        return
    params = [
        p
        for p in sig.parameters.values()
        if p.default is inspect.Parameter.empty
        and p.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)
    ]
    if len(params) != 1:
        raise TypeError(
            f"SequenceValidator '{_validator_name(v)}' must accept exactly 1 positional "
            f"parameter (SequenceContent), got {len(params)}"
        )


class CellValidationError(Exception):
    def __init__(self, message: str, validator_name: str | None = None) -> None:
        super().__init__(message)
        self.validator_name = validator_name


class SequenceError(Exception):
    pass


class Cell:
    cell_type: ClassVar[str]

    def __init__(
        self,
        label: Label,
        validators: list[CellValidator] | None = None,
        source: CellContent = "",
    ) -> None:
        self.label: Final[Label] = label
        self._source = source
        self.validators: list[CellValidator] = []
        for v in validators or []:
            _check_cell_validator(v)
            self.validators.append(v)

    @property
    def content(self) -> CellContent:
        return self._source

    def validate(self, x: CellContent) -> None:
        for v in self.validators:
            try:
                v(deepcopy(x))
            except Exception as e:
                doc = f"({v.__doc__})" if v.__doc__ else ""
                raise CellValidationError(
                    dedent(f"""
                    validation failed for cell '{cstr("yellow", self.label, True)}':\n
                    {cstr("magenta", _validator_name(v), True)} {doc} - {e!s}
                    """),
                    validator_name=_validator_name(v),
                )

    def __or__(self, other: Choice | Sequence | Cell | Maybe) -> Choice:
        if isinstance(other, Choice):
            return Choice(
                label=f"{self.label}_or_{'_or_'.join(o.label for o in other.options)}",
                options=cast(list, [self] + other.options),
            )
        return Choice(
            label=f"{self.label}_or_{other.label}",
            options=cast(list, [self, other]),
        )


class Markdown(Cell):
    cell_type = "markdown"


class Code(Cell):
    cell_type = "code"


class Choice:
    def __init__(
        self,
        label: Label,
        options: list[Markdown | Code | Sequence | Choice | Maybe],
    ) -> None:
        self.label: Final[Label] = label
        self.options: list[Markdown | Code | Sequence | Choice | Maybe] = []
        for opt in options:
            if isinstance(opt, Choice):
                self.options.extend(opt.options)
            else:
                self.options.append(opt)

    def __or__(self, other: Choice | Sequence | Cell | Maybe) -> Choice:
        if isinstance(other, Choice):
            return Choice(
                label=f"{self.label}_or_{other.label}",
                options=self.options + other.options,
            )
        return Choice(
            label=f"{self.label}_or_{other.label}",
            options=cast(list, self.options + [other]),
        )


class Maybe:
    def __init__(
        self,
        label: Label,
        element: Markdown | Code | Sequence | Choice,
    ) -> None:
        self.label: Final[Label] = label
        self.element: Final[Markdown | Code | Sequence | Choice] = element

    def __or__(self, other: Choice | Sequence | Cell | Maybe) -> Choice:
        if isinstance(other, Choice):
            return Choice(
                label=f"{self.label}_or_{'_or_'.join(o.label for o in other.options)}",
                options=cast(list, [self] + other.options),
            )
        return Choice(
            label=f"{self.label}_or_{other.label}",
            options=cast(list, [self, other]),
        )


class Sequence:
    def __init__(
        self,
        label: Label,
        structure: list[Markdown | Code | Sequence | Choice | Maybe],
        validators: list[SequenceValidator] | None = None,
        empty: bool = False,
    ) -> None:
        self.label: Final[Label] = label
        self.empty: Final[bool] = empty
        self.structure: Final[list[Markdown | Code | Sequence | Choice | Maybe]] = structure
        self.validators: list[SequenceValidator] = []
        for v in validators or []:
            _check_sequence_validator(v)
            self.validators.append(v)

    def __iter__(self) -> Iterator[Markdown | Code | Sequence | Choice | Maybe]:
        yield from self.structure

    def __or__(self, other: Choice | Sequence | Cell | Maybe) -> Choice:
        if isinstance(other, Choice):
            return Choice(
                label=f"{self.label}_or_{'_or_'.join(o.label for o in other.options)}",
                options=cast(list, [self] + other.options),
            )
        return Choice(
            label=f"{self.label}_or_{other.label}",
            options=cast(list, [self, other]),
        )


type ParseElement = Markdown | Code | Sequence | Choice | Maybe
