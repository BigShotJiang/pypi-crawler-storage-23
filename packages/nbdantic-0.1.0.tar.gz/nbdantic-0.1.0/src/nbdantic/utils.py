import ast
from typing import Any, Callable

from .types import CellNode, CellsMapValue


def packages_from_code(code: str) -> list[str]:
    packages: list[str] = []
    tree = ast.parse(code)
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            packages.extend([alias.name for alias in node.names])
        if isinstance(node, ast.ImportFrom) and node.module:
            packages.append(node.module.split(".")[0])
    return list(set(packages))


def is_cell(a: Any) -> bool:
    return isinstance(a, CellNode)


def all_nested_cells(
    cells: CellsMapValue,
    f: Callable[[CellNode], bool] = lambda _: True,
) -> list[CellNode]:
    def _collect(c: Any, acc: list[CellNode]) -> None:
        if isinstance(c, CellNode):
            if f(c):
                acc.append(c)
        elif isinstance(c, dict):
            for v in c.values():
                _collect(v, acc)
        elif isinstance(c, list):
            for item in c:
                _collect(item, acc)
        elif hasattr(c, "cells"):
            _collect(c.cells, acc)

    acc: list[CellNode] = []
    _collect(cells, acc)
    return acc


def src_only_cell(content: str) -> CellNode:
    return CellNode(cell_type="code", source=content)
