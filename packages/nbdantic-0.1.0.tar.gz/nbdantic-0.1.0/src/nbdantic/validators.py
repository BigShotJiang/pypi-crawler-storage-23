import ast
import json
import sys
from functools import wraps
from typing import Any

from .logger import LogStatus, logger
from .script_runner import UVScriptRunner
from .types import CellValidator, SequenceValidator


def valid_python(code_content: str) -> None:
    compile(code_content, "<string>", "exec")


def not_empty(content: str) -> None:
    if not content:
        raise ValueError("Cannot be empty!")


def contains_only_imports(content: str) -> None:
    tree = ast.parse(content)
    if not all(isinstance(n, (ast.Import, ast.ImportFrom, ast.alias, ast.Module)) for n in ast.walk(tree)):
        raise ValueError("Code should only contain import statements")


def starts_with(starter: str) -> CellValidator:
    @wraps(starts_with)
    def _starts_with(content: str) -> None:
        if not content.startswith(starter):
            raise ValueError(f"This cell should start with {starter} - found {content}")

    _starts_with.__name__ = f"starts_with({starter!r})"
    return _starts_with


def at_least(times: int) -> SequenceValidator:
    @wraps(at_least)
    def _at_least(content: list[dict[str, Any]]) -> None:
        if len(content) < times:
            raise ValueError(f"This section expected {times} cells, got {len(content)}")

    _at_least.__name__ = f"at_least({times})"
    return _at_least


def json_loadable(content: str) -> None:
    try:
        json.loads(content)
    except Exception as e:
        raise ValueError(f"Cell does not contain valid JSON: {e}")


def only_one_top_level_function(content: str) -> None:
    tree = ast.parse(content)
    func_defs = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    if len(func_defs) != 1:
        raise ValueError(f"Found {len(func_defs)} function definitions, expecting one and only one.")


def functions_must_be_typed(content: str) -> None:
    tree = ast.parse(content)
    func_defs = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    if not func_defs:
        return
    for func_def in func_defs:
        args = func_def.args
        func_arguments = (
            (args.args or [])
            + (args.posonlyargs or [])
            + (args.kwonlyargs or [])
            + ([args.vararg] if args.vararg else [])
            + ([args.kwarg] if args.kwarg else [])
        )

        not_typed_args = [arg.arg for arg in func_arguments if arg.annotation is None]
        if len(not_typed_args) > 0:
            raise ValueError(
                f"Function {func_def.name} arguments are not fully typed. Missing types on {not_typed_args}"
            )


def funcdef_does_not_contain_docstring(content: str) -> None:
    tree = ast.parse(content)
    funcdefs = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
    errors = []
    for f in funcdefs:
        if ast.get_docstring(f):
            errors.append(f"Function {f.name} should not have docstrings when mocked, keep it minimal")
    if errors:
        raise ValueError("\n".join(errors))


def does_not_exceed(max_chars: int) -> CellValidator:
    @wraps(does_not_exceed)
    def _does_not_exceed(content: str) -> None:
        n_chars = len(content)
        if n_chars > max_chars:
            logger.status_log(
                f"Content is too big. It exceeded the limit by "
                f"{(n_chars - max_chars) / max_chars * 100:.1f}%, please reduce it if possible.",
                LogStatus.WARNING,
            )

    _does_not_exceed.__name__ = f"does_not_exceed({max_chars})"
    return _does_not_exceed


def line_warning(quantity: int) -> CellValidator:
    @wraps(line_warning)
    def _warn(content: str) -> None:
        tree = ast.parse(content)
        func = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        if len(func) != 1:
            raise ValueError(f"Expecting one function definition, found {len(func)}")
        funcdef = func[0]
        docstring = ast.get_docstring(funcdef, False)
        docstring_lines = len(docstring.split("\n")) if docstring else 0

        if not funcdef.end_lineno:
            raise ValueError(f"Python Compatibility issue! version should be higher than {sys.version_info}")

        if (line_count := funcdef.end_lineno - funcdef.lineno + 1 - docstring_lines) > quantity:
            logger.status_log(
                f"Try reducing the size of function '{funcdef.name}', if not possible split it in "
                f"more subproblems. Function body should be <{quantity}, found {line_count}",
                LogStatus.WARNING,
            )

    _warn.__name__ = f"line_warning({quantity})"
    return _warn


def ruff_check(
    select: list[str] | None = None,
    ignore: list[str] | None = None,
) -> CellValidator:
    _select = select or ["E", "F", "A"]
    _ignore = ignore or ["E501", "E741"]

    @wraps(ruff_check)
    def _ruff_check(content: str) -> None:
        runner = UVScriptRunner(
            packages=["ruff"],
            pyproject_entries=[
                ("tool.ruff.lint", f"select = {_select}"),
                ("tool.ruff.lint", f"ignore = {_ignore}"),
            ],
        )
        with runner:
            tmp_file = runner.write_tmp_file(content, "py")
            result_fix = runner.oneshot_cmd(["ruff", "check", "--fix-only", "--quiet", str(tmp_file.absolute())])
            if result_fix.returncode != 0:
                raise ValueError(f"ruff fix failed unexpectedly:\n{result_fix.stderr}")

            result = runner.oneshot_cmd(["ruff", "check", "--quiet", str(tmp_file.absolute())])
            if result.returncode != 0:
                numbered = "\n".join(f"{i + 1:>3} | {line}" for i, line in enumerate(content.splitlines()))
                raise ValueError(f"Lint failed:\n{result.stdout}\n{result.stderr}\n{numbered}")

    _ruff_check.__name__ = f"ruff_check(select={_select!r}, ignore={_ignore!r})"
    return _ruff_check


def ty_check(content: str) -> None:
    runner = UVScriptRunner(packages=["ty"])
    with runner:
        tmp_file = runner.write_tmp_file(content, "py")
        result = runner.oneshot_cmd(["ty", "check", str(tmp_file.absolute())])
        if result.returncode != 0:
            raise ValueError(f"Type check failed:\n{result.stdout}\n{result.stderr}")
