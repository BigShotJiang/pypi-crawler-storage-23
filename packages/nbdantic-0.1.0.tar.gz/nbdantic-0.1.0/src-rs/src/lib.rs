use pyo3::{exceptions::PyTypeError, prelude::*};

use uv_pep440::{VersionSpecifier, VersionSpecifiers};
use uv_pep508::{Requirement, VersionOrUrl};

#[pyclass(name = "VersionSpecifier")]
#[derive(Clone)]
pub struct PyVersionSpecifier {
    inner: VersionSpecifier,
}

#[pymethods]
impl PyVersionSpecifier {
    #[getter]
    fn operator(&self) -> String {
        self.inner.operator().to_string()
    }

    #[getter]
    fn version(&self) -> String {
        self.inner.version().to_string()
    }

    fn __repr__(&self) -> String {
        format!("VersionSpecifier('{}')", self.inner)
    }

    fn __str__(&self) -> String {
        self.inner.to_string()
    }
}

impl From<VersionSpecifier> for PyVersionSpecifier {
    fn from(spec: VersionSpecifier) -> Self {
        Self { inner: spec }
    }
}

#[pyclass(eq, eq_int, name = "VersionT")]
#[derive(PartialEq, Clone)]
pub enum VersionT {
    Url,
    VerSpec,
}

#[pyclass(name = "UVRequirement")]
#[derive(Clone)]
pub struct PyRequirement {
    inner: Requirement,
}

#[pymethods]
impl PyRequirement {
    #[getter]
    fn package_name(&self) -> String {
        self.inner.name.to_string()
    }

    #[getter]
    fn version_type(&self) -> PyResult<Option<VersionT>> {
        if let Some(voru) = &self.inner.version_or_url {
            match voru {
                VersionOrUrl::VersionSpecifier(_) => return Ok(Some(VersionT::VerSpec)),
                VersionOrUrl::Url(_) => return Ok(Some(VersionT::Url)),
            }
        }
        Ok(None)
    }

    #[getter]
    fn pkg_spec(&self) -> PyResult<Option<Vec<PyVersionSpecifier>>> {
        if let Some(voru) = &self.inner.version_or_url {
            match voru {
                VersionOrUrl::VersionSpecifier(vs) => {
                    return Ok(Some(vs.iter().map(|s| s.clone().into()).collect()));
                }
                VersionOrUrl::Url(_) => {
                    return Err(PyTypeError::new_err(
                        "Url version has no pkg_spec translation".to_string(),
                    ));
                }
            }
        }
        Ok(None)
    }

    #[getter]
    fn version_str(&self) -> Option<String> {
        if let Some(voru) = &self.inner.version_or_url {
            match voru {
                VersionOrUrl::VersionSpecifier(vs) => return Some(vs.to_string()),
                VersionOrUrl::Url(url) => return Some(url.to_string()),
            }
        }
        None
    }

    fn __repr__(&self) -> String {
        format!("UVRequirement('{}')", self.inner)
    }
}

impl From<Requirement> for PyRequirement {
    fn from(req: Requirement) -> Self {
        Self { inner: req }
    }
}

#[pymodule]
mod nbrs {
    use crate::{PyRequirement, PyVersionSpecifier, Requirement, VersionSpecifiers, VersionT};
    use std::str::FromStr;

    use pyo3::{exceptions::PyValueError, prelude::*};

    #[pymodule_init]
    fn init(m: &Bound<'_, PyModule>) -> PyResult<()> {
        m.add_class::<PyVersionSpecifier>()?;
        m.add_class::<PyRequirement>()?;
        m.add_class::<VersionT>()?;
        Ok(())
    }

    #[pyfunction]
    fn version_specs_from_string(spec_str: String) -> PyResult<Vec<PyVersionSpecifier>> {
        let specs = VersionSpecifiers::from_str(&spec_str)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(specs.iter().map(|s| s.clone().into()).collect())
    }

    #[pyfunction]
    fn package_spec_from_string(spec_str: String) -> PyResult<PyRequirement> {
        let req =
            Requirement::from_str(&spec_str).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(req.into())
    }
}
