from pathlib import Path

import markdown_it as mdit
import yaml
from iker.common.utils.funcutils import singleton
from iker.common.utils.jsonutils import JsonObject

__all__ = [
    "predefined_tagset_specs",
]


@singleton
def predefined_tagset_specs() -> list[tuple[Path, JsonObject]]:
    # Register simple constructors for !markdown tags yaml.load can parse them.
    def markdown_constructor(loader: yaml.Loader, node: yaml.ScalarNode | yaml.MappingNode):
        text = loader.construct_scalar(node)
        tokens = mdit.MarkdownIt().parse(text)
        for token in tokens:
            if token.type.startswith("heading"):
                raise ValueError("markdown content in tagset specifications cannot contain headings.")
        return {
            "type": "markdown",
            "text": text,
        }

    yaml.SafeLoader.add_constructor("!markdown", markdown_constructor)

    def load():
        root = Path(__file__).parent
        for path in root.glob("**/*.tagset.yaml"):
            text = path.read_text(encoding="utf-8")
            yield path, yaml.load(text, yaml.SafeLoader)

    return list(load())
