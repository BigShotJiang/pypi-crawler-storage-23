import dataclasses
import datetime
import os
import pathlib
import textwrap
import typing
from collections.abc import Generator, Mapping, Sequence
from typing import Self

import jinja2
import pydantic as pdt
import sqlalchemy as sa
import sqlalchemy.dialects.sqlite as sa_sqlite
import sqlalchemy.orm as sa_orm
from iker.common.utils.dbutils import ConnectionMaker
from iker.common.utils.funcutils import singleton
from iker.common.utils.iterutils import dicttree
from iker.common.utils.iterutils import dicttree_add, dicttree_remove
from iker.common.utils.iterutils import dicttree_children, dicttree_lineage, dicttree_subtree
from iker.common.utils.iterutils import head_or_none
from iker.common.utils.jsonutils import JsonObject, JsonType
from iker.common.utils.randutils import randomizer
from iker.common.utils.strutils import is_blank
from sqlmodel import Field, SQLModel

from plexus.common.resources.tags import predefined_tagset_specs
from plexus.common.utils.datautils import validate_colon_tag, validate_snake_case, validate_vehicle_name
from plexus.common.utils.datautils import validate_dt_timezone
from plexus.common.utils.ormutils import SequenceModelMixinProtocol
from plexus.common.utils.ormutils import clone_sequence_model_instance, make_base_model, make_sequence_model_mixin
from plexus.common.utils.sqlutils import escape_sql_like

__all__ = [
    "TagRecord",
    "TagRecordTable",
    "RichDesc",
    "Tag",
    "Tagset",
    "populate_tagset",
    "predefined_tagsets",
    "render_tagset_markdown_readme",
    "tag_cache_file_path",
    "TagCache",
]

BaseModel = make_base_model()


class TagRecord(BaseModel):
    vehicle_name: str = Field(
        sa_column=sa.Column(sa_sqlite.TEXT, nullable=False),
        description="Vehicle name associated with the tag record",
    )
    begin_dt: datetime.datetime = Field(
        sa_column=sa.Column(sa_sqlite.TIMESTAMP, nullable=False),
        description="Begin datetime of the tag record",
    )
    end_dt: datetime.datetime = Field(
        sa_column=sa.Column(sa_sqlite.TIMESTAMP, nullable=False),
        description="End datetime of the tag record",
    )
    tag: str = Field(
        sa_column=sa.Column(sa_sqlite.TEXT, nullable=False),
        description="Tag name",
    )
    props: JsonType | None = Field(
        sa_column=sa.Column(sa_sqlite.TEXT, nullable=True),
        default=None,
        description="Additional properties of the tag record in JSON format",
    )

    @pdt.field_validator("vehicle_name", mode="after")
    @classmethod
    def validate_vehicle_name(cls, v: str) -> str:
        validate_vehicle_name(v)
        return v

    @pdt.field_validator("begin_dt", mode="after")
    @classmethod
    def validate_begin_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v)
        return v

    @pdt.field_validator("end_dt", mode="after")
    @classmethod
    def validate_end_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v)
        return v

    @pdt.model_validator(mode="after")
    def validate_begin_dt_end_dt(self) -> Self:
        if self.begin_dt > self.end_dt:
            raise ValueError(f"begin dt '{self.begin_dt}' is greater than end dt '{self.end_dt}'")
        return self

    @pdt.field_validator("tag", mode="after")
    @classmethod
    def validate_tag(cls, v: str) -> str:
        validate_colon_tag(v)
        return v


class TagRecordTable(TagRecord, make_sequence_model_mixin("sqlite"), table=True):
    __tablename__ = "tag_record"


if typing.TYPE_CHECKING:
    class TagRecordTable(SQLModel, SequenceModelMixinProtocol):
        vehicle_name: sa_orm.Mapped[str] = ...
        begin_dt: sa_orm.Mapped[datetime.datetime] = ...
        end_dt: sa_orm.Mapped[datetime.datetime] = ...
        tag: sa_orm.Mapped[str] = ...
        props: sa_orm.Mapped[JsonType | None] = ...


@dataclasses.dataclass(frozen=True, eq=True, order=True)
class RichDesc(object):
    type: str
    text: str


@dataclasses.dataclass(frozen=True, eq=True, order=True)
class Tag(object):
    name: str
    desc: str | RichDesc | None

    @property
    def tag_parts(self) -> list[str]:
        return self.name.rsplit(":")

    @property
    def parent_tag_name(self) -> str | None:
        return head_or_none(self.name.rsplit(":", 1))

    def populate(self, vehicle_name: str, begin_dt: datetime.datetime, end_dt: datetime.datetime,
                 props: JsonType) -> TagRecord:
        return TagRecord(
            vehicle_name=vehicle_name,
            begin_dt=begin_dt,
            end_dt=end_dt,
            tag=self.name,
            props=props,
        )


class Tagset(Sequence[Tag], Mapping[str, Tag]):
    def __init__(self, namespace: str, desc: str | RichDesc) -> None:
        super().__init__()
        self.namespace = namespace
        self.desc = desc
        self.tags: list[Tag] = []
        self.tags_dict: dict[str, Tag] = {}
        self.tags_tree: dicttree[str, Tag] = {}

    def __contains__(self, item: str | Tag) -> bool:
        tag_name = item.name if isinstance(item, Tag) else item
        return tag_name in self.tags_dict

    def __len__(self) -> int:
        return len(self.tags)

    def __getitem__(self, index: int) -> Tag:
        return self.tags[index]

    def keys(self):
        return self.tags_dict.keys()

    def values(self):
        return self.tags_dict.values()

    def items(self):
        return self.tags_dict.items()

    def get(self, item: str | Tag) -> Tag | None:
        tag_name = item.name if isinstance(item, Tag) else item
        return self.tags_dict.get(tag_name)

    @property
    def tag_names(self) -> list[str]:
        return list(self.tags_dict.keys())

    def add(self, tag: Tag) -> None:
        if tag.name in self.tags_dict:
            raise ValueError(f"duplicate tag name '{tag.name}'")

        self.tags.append(tag)
        self.tags_dict[tag.name] = tag

        dicttree_add(self.tags_tree, tag.tag_parts, tag, create_prefix=True)

    def remove(self, tag_name: str) -> None:
        tag = self.get(tag_name)
        if tag is None:
            raise ValueError(f"tag '{tag_name}' not found")

        self.tags.remove(tag)
        del self.tags_dict[tag_name]

        dicttree_remove(self.tags_tree, tag.tag_parts, recursive=True)

    def child_tags(self, parent: str | Tag) -> list[Tag]:
        if parent is None:
            return []
        if isinstance(parent, str):
            return self.child_tags(self.get(parent))

        subtree = dicttree_subtree(self.tags_tree, parent.tag_parts)
        return list(dicttree_children(subtree)) if subtree else []

    def parent_tags(self, child: str | Tag) -> list[Tag]:
        if child is None:
            return []
        if isinstance(child, str):
            return self.parent_tags(self.get(child))

        return list(dicttree_lineage(self.tags_tree, child.tag_parts[:-1]))


def populate_tagset(tagset_spec: JsonObject) -> Tagset:
    """
    Collect tags from tagset spec JSON object, validate the format along the way.

    :param tagset_spec: JSON object of tagset spec
    :return: Populated Tagset instance
    """

    def validate_and_collect(name: str, tag_def: JsonObject) -> Generator[Tag, None, None]:
        if not isinstance(tag_def, dict):
            raise ValueError(f"tag '{name}' definition is not a dict")

        if not is_blank(name):
            desc = tag_def.get("$desc")
            if isinstance(desc, dict):
                desc = RichDesc(**desc)

            yield Tag(name=name, desc=desc)

        for child_name, child_tag_def in tag_def.items():
            if child_name == "$desc":
                continue

            if not isinstance(child_name, str):
                raise ValueError(f"child '{child_name}' of tag '{name}' is not a string")
            try:
                validate_snake_case(child_name)
            except ValueError as e:
                raise ValueError(f"child '{child_name}' of tag '{name}' is not in snake case") from e

            child_name = name + ":" + child_name if name else child_name

            yield from validate_and_collect(child_name, child_tag_def)

    namespace = tagset_spec.get("$namespace")
    if namespace is None:
        raise ValueError("missing '$namespace' in tagset spec")
    try:
        validate_snake_case(namespace)
    except ValueError as e:
        raise ValueError(f"tagset namespace '{namespace}' is not in snake case") from e

    desc = tagset_spec.get("$desc")
    if desc is None:
        raise ValueError("missing '$desc' in tagset spec")
    if isinstance(desc, dict):
        desc = RichDesc(**desc)

    tags = tagset_spec.get("$tags")
    if tags is None:
        raise ValueError("missing '$tags' in tagset spec")

    tagset = Tagset(namespace=namespace, desc=desc)

    for tag in validate_and_collect("", tags):
        tagset.add(tag)

    return tagset


@singleton
def predefined_tagsets() -> dict[str, Tagset]:
    tagsets: dict[str, Tagset] = {}
    for _, tagset_spec in predefined_tagset_specs():
        tagset = populate_tagset(tagset_spec)
        tagsets[tagset.namespace] = tagset
    return tagsets


def render_tagset_markdown_readme(tagset: Tagset) -> str:
    def render_desc(desc: str | RichDesc | None) -> str:
        if desc is None:
            return ""
        if isinstance(desc, str):
            return desc
        if isinstance(desc, RichDesc):
            return desc.text
        raise ValueError(f"unsupported desc type '{type(desc)}'")

    template_str = textwrap.dedent(
        """
        # Tagset {{ tagset.namespace }}

        {{ tagset.desc | render_desc }}

        ## Contents

        {% for tag in tagset.tags %}
        - {{ tag.name }}
        {% endfor %}

        ## Tags

        {% for tag in tagset.tags %}
        ### {{ tag.name }}

        {{ tag.desc | render_desc }}

        {% endfor %}
        """
    )

    env = jinja2.Environment(trim_blocks=True, lstrip_blocks=True)
    env.filters["render_desc"] = render_desc

    return env.from_string(template_str).render(tagset=tagset)


@singleton
def tag_cache_file_path() -> pathlib.Path:
    return pathlib.Path.home() / ".local" / "plus" / "datahub" / "tag_cache" / f"{randomizer().random_alphanumeric(7)}.db"


class TagCache(object):
    def __init__(self, *, file_path: str | os.PathLike[str] | None = None, fail_if_exists: bool = False):
        self.file_path = pathlib.Path(file_path or tag_cache_file_path())
        if fail_if_exists and self.file_path.exists():
            raise FileExistsError(f"tag cache file '{str(self.file_path)}' already exists")
        self.file_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn_maker = ConnectionMaker.from_url(f"sqlite:///{str(self.file_path.absolute())}",
                                                   engine_opts=dict(connect_args={"check_same_thread": False}))
        BaseModel.metadata.create_all(self.conn_maker.engine)

    def query(
        self,
        vehicle_name: str,
        begin_time: datetime.datetime | None = None,
        end_time: datetime.datetime | None = None,
        tag_pattern: str | None = None,
    ) -> list[TagRecordTable]:
        with self.conn_maker.make_session() as session:
            query = session.query(TagRecordTable).where(TagRecordTable.vehicle_name == vehicle_name)

            if begin_time:
                query = query.filter(TagRecordTable.end_dt >= begin_time)
            if end_time:
                query = query.filter(TagRecordTable.begin_dt <= end_time)
            if tag_pattern:
                query = query.filter(TagRecordTable.tag.like(f"{escape_sql_like(tag_pattern)}%", escape="\\"))

            return query.all()

    def add(
        self,
        vehicle_name: str,
        begin_time: datetime.datetime,
        end_time: datetime.datetime,
        tag: str | Tag,
        props: JsonType | None = None,
    ):
        with self.conn_maker.make_session() as session:
            tag_record = TagRecord(
                vehicle_name=vehicle_name,
                begin_dt=begin_time,
                end_dt=end_time,
                tag=tag.name if isinstance(tag, Tag) else tag,
                props=props,
            )
            session.add(clone_sequence_model_instance(TagRecordTable, tag_record))
            session.commit()

    def remove(self, vehicle_name: str, begin_time: datetime.datetime, end_time: datetime.datetime):
        with self.conn_maker.make_session() as session:
            session.execute(
                sa
                .delete(TagRecordTable)
                .where(
                    TagRecordTable.vehicle_name == vehicle_name,
                    TagRecordTable.end_dt >= begin_time,
                    TagRecordTable.begin_dt <= end_time,
                )
            )
            session.commit()

    def clear(self):
        with self.conn_maker.make_session() as session:
            session.execute(sa.delete(TagRecordTable))
            session.commit()

    def append_to(self, target_file_path: str, *, overwrite: bool = False):
        target_tag_cache = TagCache(file_path=target_file_path)
        if overwrite:
            target_tag_cache.clear()
        TagCache.clone_to(self, target_tag_cache)

    def merge_from(self, source_file_path: str, *, overwrite: bool = False):
        source_tag_cache = TagCache(file_path=source_file_path)
        if overwrite:
            self.clear()
        TagCache.clone_to(source_tag_cache, self)

    @staticmethod
    def clone_to(source: "TagCache", target: "TagCache"):
        target.clear()
        with source.conn_maker.make_session() as source_session, target.conn_maker.make_session() as target_session:
            target_session.add_all([clone_sequence_model_instance(TagRecordTable, db_tag_record, clear_meta_fields=True)
                                    for db_tag_record in source_session.query(TagRecordTable).all()])
            target_session.commit()
