import datetime
import unittest

import ddt
from iker.common.utils.dtutils import dt_parse_iso

from plexus.common.utils.tagutils import TagCache, Tagset
from plexus.common.utils.tagutils import predefined_tagsets, render_tagset_markdown_readme
from plexus.common.utils.tagutils import tag_cache_file_path


@ddt.ddt
class TagUtilsTest(unittest.TestCase):

    def test_predefined_tagsets(self):
        tagsets = predefined_tagsets()
        for _, tagset in tagsets.items():
            self.assertIsInstance(tagset, Tagset)

            for tag in tagset:
                self.assertIn(tag, tagset)
                self.assertIn(tag.name, tagset)
                self.assertEqual(tag, tagset.get(tag))
                self.assertEqual(tag, tagset.get(tag.name))

            markdown = render_tagset_markdown_readme(tagset)
            self.assertIsInstance(markdown, str)

            print(markdown)

    def test_tag_cache(self):
        tag_cache = TagCache()

        self.assertEqual(tag_cache.file_path, tag_cache_file_path())
        self.assertTrue(tag_cache.file_path.exists())

        self.assertEqual(len(tag_cache.query("dummy_vehicle")), 0)

        tags = [
            "dummy:foo",
            "dummy:bar",
            "dummy:baz",
            "dummy:qux",
        ]
        for i in range(1000):
            tag_cache.add(
                "dummy_vehicle",
                dt_parse_iso("2020-01-01T00:00:00.000000+00:00") + datetime.timedelta(seconds=i),
                dt_parse_iso("2021-01-01T00:00:00.000000+00:00") + datetime.timedelta(seconds=i + 1),
                tags[i % len(tags)],
            )

        self.assertEqual(len(tag_cache.query("dummy_vehicle")), 1000)
        self.assertEqual(
            len(tag_cache.query("dummy_vehicle",
                                dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                                dt_parse_iso("2020-01-01T00:01:00.000000+00:00"))),
            61,
        )
        self.assertEqual(
            len(tag_cache.query("dummy_vehicle",
                                dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                                dt_parse_iso("2020-01-01T00:01:00.000000+00:00"),
                                tag_pattern="dummy:foo")),
            16,
        )
        self.assertEqual(
            len(tag_cache.query("dummy_vehicle",
                                dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                                dt_parse_iso("2020-01-01T00:01:00.000000+00:00"),
                                tag_pattern="dummy:bar")),
            15,
        )
        self.assertEqual(
            len(tag_cache.query("dummy_vehicle",
                                dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                                dt_parse_iso("2020-01-01T00:01:00.000000+00:00"),
                                tag_pattern="dummy")),
            61,
        )
        self.assertEqual(len(tag_cache.query("dummy_vehicle", tag_pattern="dummy:foo")), 250)
        self.assertEqual(len(tag_cache.query("dummy_vehicle", tag_pattern="dummy:bar")), 250)
        self.assertEqual(len(tag_cache.query("dummy_vehicle", tag_pattern="dummy")), 1000)
        self.assertEqual(len(tag_cache.query("another_dummy_vehicle")), 0)

        tag_cache.remove("dummy_vehicle",
                         dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                         dt_parse_iso("2020-01-01T00:01:00.000000+00:00"))

        self.assertEqual(len(tag_cache.query("dummy_vehicle")), 939)

        tag_cache.clear()

        self.assertEqual(len(tag_cache.query("dummy_vehicle")), 0)
