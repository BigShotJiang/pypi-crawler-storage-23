# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from dataclasses import dataclass
from typing import Dict, Optional, Tuple, List, Any

import torch

from litgpt.config import Config

from keys_values.attention import (
    DefaultKeysAndValues,
    KeysAndValues,
    MultiHeadSelfAttention,
)
from keys_values.use_eager_kernel import transform_mha_kwargs


@dataclass(frozen=True)
class KVCacheParams:
    """
    If a KV cache is assigned to a model, it can support different batch sizes.
    Batch size may change between inference runs, but not within an inference
    run (i.e., different chunks). However, the batch size must never exceed
    `max_batch_size`.

    If `dtype` is not specified, it is chosen with the first :meth:`forward`
    call, based on the input arguments.

    """

    max_batch_size: int
    n_query_groups: int
    cache_length: int
    head_size: int
    n_head: int
    dtype: Optional[torch.dtype]

    @staticmethod
    def from_config(
        config: Config,
        max_batch_size: int,
        cache_length: int,
        dtype: Optional[torch.dtype] = None,
        head_size: Optional[int] = None,
    ) -> "KVCacheParams":
        if head_size is None:
            head_size = config.n_embd // config.n_head
        return KVCacheParams(
            max_batch_size=max_batch_size,
            n_query_groups=config.n_query_groups,
            cache_length=cache_length,
            head_size=head_size,
            n_head=config.n_head,
            dtype=dtype,
        )


class KVCache(torch.nn.Module):
    """
    Base class for key-value (KV) caches.

    A cache is used to support inference for batches of size
    `<= max_batch_size`. This effective batch size is determined at the
    initial :meth:`forward` call for an inference (`input_pos == 0`), and
    remains the same for subsequent calls (`input_pos > 0`).

    KV cache buffers have shapes
    `(batch_size, config.n_query_groups, cache_length, head_size)`, where
    `head_size` is a parameter (defaults to `config.head_size`). Depending on
    the implementation, these buffers are allocated up front with first
    dimension `max_batch_size`, or they are re-allocated for every inference
    with the effective batch size.

    `input_pos` counts the number of tokens for which KV information has
    been cached, since the last recent :meth:`reset` call. The first call
    of :meth:`forward` after a reset (when `input_pos == 0`) is called the
    prefill call.

    When implementing a new KV cache, consider these base classes:

    * :class:`AttnWeightsKVCache`: Eviction decisions based on scores which
        require attention weights to be computed. Based on buffers.
    * :class:`KVCacheWithBuffers`: Based on buffers which can be deallocated
        and reallocated.
    * :class:`DefaultKVCache`: Maintains multi-head self attention object and
        a reference implementation of :meth:`forward` based on this.

    """

    def __init__(
        self,
        config: Config,
        max_batch_size: int,
        cache_length: int,
        block_idx: int,
        dtype: Optional[torch.dtype] = None,
        head_size: Optional[int] = None,
    ):
        """
        Note that `max_batch_size` is the maximum batch size the cache can be
        used with. The effective batch size is determined when calling
        :meth:`forward` when `input_pos == 0`, and can change with any such
        prefill call. If this is smaller than `max_batch_size`, then in
        general only parts of the buffers are used.

        Args:
            config: Model config
            max_batch_size: Inference batch size (maximum)
            cache_length: Number of slots in cache
            block_idx: Index of model block (or layer). Multi-head attention
                needs to know this.
            dtype: Data type for buffers. If not given, it is set with the
                first :meth:`forward` call, based on the input arguments.
            head_size: Size of final dimension of buffers. Defaults to
                `config.head_size`.

        """
        super().__init__()
        if cache_length <= 0:
            raise ValueError("cache_length must be positive")
        self.config = config  # Needed for :meth:`clone`
        self.max_batch_size = max_batch_size
        self._n_query_groups = config.n_query_groups
        self._cache_length = cache_length
        if head_size is None:
            head_size = config.head_size
        self.head_size = head_size
        self.n_head = config.n_head
        self._dtype = dtype
        self.block_idx = block_idx

    @property
    def device(self) -> Optional[torch.device]:
        """
        A KV cache is created without association to a device. Its device
        is set based on the arguments of the first :meth:`forward` call. It
        cannot be changed afterwards (use :meth:`clone` to transport a
        cache to a different device).

        Returns:
            Device the KV cache buffers are kept on, and which arguments
            to :meth:`forward` need to be on. Returns `None` as long as the
            device is not fixed (upon first :meth:`forward` call).

        """
        raise NotImplementedError

    @property
    def dtype(self) -> Optional[torch.dtype]:
        """
        Returns:
            Data type of the KV cache buffers. This can be set at construction
            or is otherwise set with the first :meth:`forward` call. Cannot
            be changed afterwards.

        """
        return self._dtype

    @property
    def cache_length(self) -> int:
        """
        Returns:
            Number of slots in cache. The cache is full once the sum of
            `query.shape[2]` of :meth:`forward` calls reaches this length.

        """
        return self._cache_length

    @property
    def n_query_groups(self) -> int:
        return self._n_query_groups

    @property
    def input_pos(self) -> int:
        """
        Returns:
            Number of tokens for which KV information has been cached,
            since the last recent :meth:`reset` call. Each time :meth:`forward`
            is called, this counter increases by `query.shape[2]`.

        """
        raise NotImplementedError()

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        token_idx: torch.Tensor,
    ) -> torch.Tensor:
        """
        Given query, key, value tensors, this method extends the KV cache with
        `key`, `value`, then computes multi-head self attention. There are two
        cases:

        * Prefill (`input_pos == 0`): Starts a generation loop by passing key
          and value tensors. The KV cache is reset. The length must be
          `num <= max_prefill_length`. The effective batch size must be
          `batch_size <= max_batch_size`. This batch size is then fixed for
          subsequent calls of :meth:`forward`.
          Different to update (`input_pos > 0`), additional information (such
          as attention weights) are not obtained here. This is because the
          typical prefill size is much larger than `num` in update, and device
          memory is much more of a concern.
        * Update (`input_pos > 0`): Continues a generation loop (or processing
          of large prompt). The length must be `num <= max_forward_length()`.

        If the cache makes eviction decisions based on scores which require
        attention weights, scores for the next :meth:`forward` call need to
        be computed here.

        If a sequence is generated token by token, updates always use `num=1`.
        The case `num > 1` arises if large prompts are to be ingested with more
        than `max_prefill_length` tokens. Note that if the cache makes eviction
        decisions by scoring in :meth:`update`, then large `num` may lead to
        worse decisions. On the other hand, ingesting prompts with larger `num`
        is faster.

        Args:
            query: New queries,
                `(batch_size, n_query_groups, num, head_size)`. Here,
                `num <= max_forward_length()` if `input_pos > 0`, and
                `num <= max_prefill_length` if `input_pos == 0`. Must be
                position encoded.
            key: New keys, `(batch_size, n_query_groups, num, head_size)`.
                Must be position encoded.
            value: New values, `(batch_size, n_query_groups, num, head_size)`
            token_idx: Token indices of input sequence, `(batch_size, num)`.
                Some KV caches make use of this information.

        Returns:
            Multi-head self-attention outputs before final linear map,
            `(batch_size, num, n_head * head_size)`

        """
        raise NotImplementedError()

    def get_keys_values(self) -> Optional[KeysAndValues]:
        """
        Returns:
            :class:`KeysAndValues` object, providing access to currently stored
            keys and values tensors. If the cache is empty or has not been
            initialized, `None` is returned.

        """
        raise NotImplementedError()

    def max_forward_length(self) -> int:
        """
        Note that this limit may change during the course of the generation
        for certain caches. Also, `max_forward_length() <= max_prefill_length`.

        Returns:
            Maximum sequence length for `key`, `value` tensors passed to
            :meth:`forward` with `input_pos > 0`. Depends on cache, but is
            `<= cache_length`. May not be static.

        """
        raise NotImplementedError()

    @property
    def max_prefill_length(self) -> int:
        """
        Returns:
            Maximum sequence length for `key`, `value` tensors passed to
            :meth:`forward` if `input_pos == 0`. Depends on cache, but is
            `<= cache_length`.

        """
        raise NotImplementedError()

    def get_params(self) -> KVCacheParams:
        return KVCacheParams(
            max_batch_size=self.max_batch_size,
            n_query_groups=self.n_query_groups,
            cache_length=self.cache_length,
            head_size=self.head_size,
            n_head=self.n_head,
            dtype=self.dtype,
        )

    def token_positions(self) -> torch.Tensor:
        """
        Returns:
            Token positions in slots of the cache, shape
            `(batch_size, n_query_groups, current_length)`, where
            `current_length <= cache_length` is the current cache length.
        """
        raise NotImplementedError()

    def size_estimate(self) -> Tuple[int, Dict[str, int]]:
        """
        This is an estimate of the main buffers (which should all be allocated
        up front), it does not cover temporary storage used in the methods
        (make sure these are small compared to the main buffers). Also, real
        memory usage may be larger due to alignment issues.

        Returns:
            num_bits_total, bits_by_part (unit is bits)

        """
        raise NotImplementedError()

    @classmethod
    def size_estimate_apriori(
        cls, params: KVCacheParams, **kwargs
    ) -> Tuple[int, Dict[str, int]]:
        """
        Same semantics as :meth:`size_estimate`, but can be called without a
        cache being created. Results may not be exactly the same, but should
        be very close.

        Args:
            params: KV cache parameters
            **kwargs: Extra arguments (optional)

        Returns:
            num_bits_total, bits_by_part (unit is bits)

        """
        raise NotImplementedError()

    def reset(self) -> None:
        """
        Resets the cache so that `input_pos == 0` afterwards. Needs to be
        called before the cache can be used for a new sequence. The next
        recent :meth:`forward` call after :meth:`reset` is the prefill call.

        """
        raise NotImplementedError()

    def set_seq_length(self, seq_length: int) -> None:
        """
        Elements of a KV cache may depend on the current sequence length, or
        the maximum sequence length (for example, the position encoding).
        This method is called once a new sequence (batch) is processed.

        Args:
            seq_length: New sequence length

        """
        raise NotImplementedError()

    def clone(self) -> "KVCache":
        """
        Creates and returns a shallow copy of this object. If the cache has
        buffers (see :class:`KVCacheBuffers`), these are not copied. In general,
        cloning works only once such buffers have been deallocated.

        Use this method to transport a cache to a different device (do not
        use :meth:`to`).

        Returns:
            Shallow copy of this object

        """
        raise NotImplementedError()

    def _base_kwargs_for_clone(self) -> Dict[str, Any]:
        """
        Supports :meth:`clone` implementations in subclasses.

        Returns:
            Keyword arguments for calling the constructor in :meth:`clone`

        """
        return dict(
            config=self.config,
            max_batch_size=self.max_batch_size,
            cache_length=self.cache_length,
            block_idx=self.block_idx,
            dtype=self.dtype,
            head_size=self.head_size,
        )

    def to(self, *args, **kwargs):
        raise NotImplementedError(
            "Use `clone` to transport a cache to a different device. It is "
            "not possible to change `dtype`"
        )


class DefaultKVCache(KVCache):
    """
    Default implementation of :class:`KVCache`, which implements
    :meth:`forward` using scaled dot product attention. Most KV caches will
    inherit from this class. If a cache uses buffers, use the base class
    :class:`KVCacheWithBuffers`.

    """

    def __init__(
        self,
        config: Config,
        max_batch_size: int,
        cache_length: int,
        block_idx: int,
        dtype: Optional[torch.dtype] = None,
        head_size: Optional[int] = None,
        mha: Optional[MultiHeadSelfAttention] = None,
        **mha_kwargs,
    ):
        """
        Additional args:
            mha: :class:`MultiHeadSelfAttention` object to be used for SDPA.
                Optional.
            mha_kwargs: If `mha` is not given, a new SDPA object is created
                here using these keyword arguments.

        """
        super().__init__(
            config=config,
            max_batch_size=max_batch_size,
            cache_length=cache_length,
            block_idx=block_idx,
            dtype=dtype,
            head_size=head_size,
        )
        if mha is None:
            self.mha = MultiHeadSelfAttention(
                config,
                **transform_mha_kwargs(mha_kwargs, config),
            )
        else:
            self.mha = mha
        self._device = None  # Unassigned so far
        self._input_pos = 0

    @property
    def input_pos(self) -> int:
        return self._input_pos

    @property
    def device(self) -> Optional[torch.device]:
        return self._device

    @property
    def batch_size(self) -> Optional[int]:
        raise NotImplementedError()

    def _forward_check_args(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        token_idx: torch.Tensor,
    ):
        """
        Apart from checking shapes of arguments, we also deal with `device`.
        If `_device is None`, it is set to `query.device`, and existing
        parameters are moved (if any). Otherwise, `query.device` must be
        equal to `_device`. Arguments are not moved if on the wrong device.

        Parameters are moved only if they have been created without a `device`
        specified.

        """
        for_prefill = self.input_pos == 0
        if query.ndim != 4:
            raise ValueError("query, key, value must be 4D tensors")
        batch_size, _, num, _ = query.shape
        if for_prefill:
            if not (1 <= batch_size <= self.max_batch_size):
                raise ValueError(
                    f"query.shape[0] = {batch_size}, must be in [1, {self.max_batch_size}]"
                )
            if not (1 <= num <= self.max_prefill_length):
                raise ValueError(
                    f"query.shape[2] = {num}, must be in [1, {self.max_prefill_length}]"
                )
        else:
            if batch_size != self.batch_size:
                raise ValueError(
                    f"query.shape[0] = {batch_size} != batch_size = {self.batch_size}"
                )
            if not (1 <= num <= self.max_forward_length()):
                raise ValueError(
                    f"query.shape[2] = {num}, must be in [1, {self.max_forward_length()}]"
                )
        q_shape = (batch_size, self.n_head, num, self.head_size)
        if query.shape != q_shape:
            raise ValueError(f"query.shape = {query.shape}, must be {q_shape}")
        k_shape = (batch_size, self.n_query_groups, num, self.head_size)
        if key.shape != k_shape:
            raise ValueError(f"key.shape = {key.shape}, must be {k_shape}")
        if value.shape != k_shape:
            raise ValueError(f"value.shape = {value.shape}, must be {k_shape}")
        t_shape = (batch_size, num)
        if token_idx.shape != t_shape:
            raise ValueError(f"token_idx.shape = {token_idx.shape}, must be {t_shape}")
        # Deal with device
        # If `_device is None`, we set it here to `query.device`. Parameters
        # which have already been created, are moved to the new device if needed.
        new_device = query.device
        for x in (key, value, token_idx):
            if x.device != new_device:
                raise ValueError("query, key, value, token_idx must be on same device")
        self._convert_or_check_device(new_device)
        if self._device is None:
            # Fix device of cache
            self._device = new_device
        if self._dtype is None:
            self._dtype = query.dtype

    def _convert_or_check_device(
        self,
        new_device: torch.device,
    ):
        if self._device is None:
            for name in self._parameter_names():
                x = getattr(self, name, None)
                if x is not None:
                    if not isinstance(x, torch.Tensor):
                        raise AssertionError(
                            f"Internal error in _convert_or_check_device: {name} must be of type torch.Tensor"
                        )
                    if x.device != new_device:
                        setattr(self, name, x.to(new_device))
        elif new_device != self._device:
            raise ValueError(
                f"Arguments on device {new_device}, must be on {self._device}"
            )

    @classmethod
    def _parameter_names(cls) -> List[str]:
        """
        Returns:
            Names of `torch.Tensor` parameters which need to be checked for
            device or converted.

        """
        return []

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        token_idx: torch.Tensor,
    ) -> torch.Tensor:
        self._forward_check_args(query, key, value, token_idx)
        input_pos = self.input_pos  # Value before increase
        for_prefill = input_pos == 0
        num = query.shape[2]

        # Call :meth:`_forward` or :meth:`_prefill`, depending on `for_prefill`
        if for_prefill:
            self._prefill(key, value, token_idx)
            # In this case, `k_and_v` can vend both keys and values at the same
            # time.
            k_and_v = DefaultKeysAndValues(key, value)
        else:
            # Extend KV cache and retrieve key, value tensors to be used.
            # Instead of asking for the key and value tensors as such,
            # `k_and_v` allows access to them.
            k_and_v = self._forward(key, value, token_idx)
        # Important to increase this here, since cache has been extended
        self._input_pos += num

        # Multi-head self-attention main computation
        return_attn_weights = (not for_prefill) and self.update_requires_attn_weights()
        attn_outputs, attn_weights = self.mha(
            query=query,
            k_and_v=k_and_v,
            block_idx=self.block_idx,
            input_pos=input_pos,
            return_attn_weights=return_attn_weights,
            token_positions=None if for_prefill else self.token_positions(),
        )
        if attn_weights is not None and return_attn_weights:
            # Pass attention weights and query length to KV cache
            self._update(attn_weights=attn_weights, query_length=num)

        return attn_outputs

    def _prefill(
        self,
        key: torch.Tensor,
        value: torch.Tensor,
        token_idx: torch.Tensor,
    ):
        """
        Implements :meth:`forward` when `input_pos == 0`. Starts a
        generation loop by passing key and value tensors coming from a prefill
        with embeddings coming from the prompts. The length must be
        `num <= max_prefill_length`. The effective batch size must be
        `batch_size <= max_batch_size`. This batch size is then fixed for
        subsequent calls of :meth:`forward` and :meth:`_update`.
        `input_pos` need not be increased here.

        Args:
            key: Prefill keys, `(batch_size, n_query_groups, num, head_size)`
            value: Prefill values, `(batch_size, n_query_groups, num, head_size)`
            token_idx: Token indices of input sequence, `(batch_size, num)`.

        """
        raise NotImplementedError()

    def _forward(
        self,
        key: torch.Tensor,
        value: torch.Tensor,
        token_idx: torch.Tensor,
    ) -> KeysAndValues:
        """
        Implements part of :meth:`forward` if `input_pos > 0`. Namely, `key`
        and `value` are written into the cache, possibly evicting slots. Then,
        an object is returned which provides read access to the full keys and
        values buffers.
        `input_pos` need not be increased here.

        Args:
            key: New keys, `(batch_size, n_query_groups, num, head_size)`,
                where `1 <= num <= max_forward_length()`
            value: New values, `(batch_size, n_query_groups, num, head_size)`
            token_idx: Token indices of input sequence, `(batch_size, num)`.

        Returns:
            key_cached, value_cached, `(batch_size, n_query_groups, T,
                head_size)`, where `T <= cache_length` is the current cache
                length

        """
        raise NotImplementedError()

    def _update(self, *args, **kwargs):
        """
        Method called in :meth:`forward` if `input_pos > 0`, passing extra
        information depending on the subclass. In general, this method updates
        internal scores and takes a decision which slot is evicted upon the
        next :meth:`forward` call, if the cache is full.

        One important example are KV caches based on the Heavy Hitter Oracle
        (H2O) proposal. These require the attention weights from the current
        MLA computation (summed over query axis) to be passed, and
        :meth:`update_requires_attn_weights` has to return `True`.

        Note: The extra information typically scales with `num`, the number of
        tokens :meth:`forward` was called for.

        Args:
            *args: Depends on subclass
            **kwargs: Depends on subclass

        """
        pass

    def update_requires_attn_weights(self) -> bool:
        """
        Attention weights are required for KV caches following the Heavy
        Hitter Oracle (H2O) proposal.

        Returns:
            If `True`, :meth:`update` requires argument `attn_weights`, which
            passes current attention weights, summed over the query axis, as
            `(batch_size, n_query_groups, current_length)` tensor, where
            `current_length <= cache_length` is the current cache length.
            Independent of `dtype` of other tensors, this tensor has
            `dtype = float32`. The query axis size is the number of tokens in
            the last recent :meth:`forward` call.

        """
        return False

    def _base_kwargs_for_clone(self) -> Dict[str, Any]:
        """
        Supports :meth:`clone` implementations in subclasses.
        Note that the copy created by :meth:`clone` uses the same `self.mha`
        object (shallow copy).

        Returns:
            Keyword arguments for calling the constructor in :meth:`clone`

        """
        result = super()._base_kwargs_for_clone()
        result["mha"] = self.mha  # Use the same `mha`
        return result

    def reset(self) -> None:
        self._reset()
        self._input_pos = 0

    def _reset(self):
        raise NotImplementedError()

    @property
    def max_prefill_length(self) -> int:
        return self.cache_length  # Default

    def set_seq_length(self, seq_length: int) -> None:
        self.mha.set_seq_length(seq_length)


class KVCacheReplayLog:
    """
    A KV cache replay log stores the information required to replay all
    KV cache decisions done for an inference pass. It is required for
    gradient computations, but also to recreate cache content from inputs.

    Log information is stored on the same device as the cache supplying it.

    """

    @property
    def token_chunks(self) -> List[torch.Tensor]:
        """
        Returns:
            List of token chunks processed or generated during inference pass

        """
        raise NotImplementedError

    def __len__(self) -> int:
        """
        Returns:
            Length of token sequence

        """
        return sum(chunk.shape[-1] for chunk in self.token_chunks)

    @property
    def cache_length(self) -> int:
        """
        Returns:
            Cache length (number of slots)

        """
        raise NotImplementedError

    @property
    def max_prefill_length(self) -> int:
        """
        Returns:
            Maximum length for prefill

        """
        raise NotImplementedError

    @property
    def grace_period(self) -> int:
        """
        Returns:
            Grace period if there is one; 0 otherwise

        """
        raise NotImplementedError

    @property
    def device(self) -> Optional[torch.device]:
        """
        Returns:
            Device of token chunks and slot positions maintained, or `None`
            as long as the log is empty

        """
        if self.token_chunks:
            return self.token_chunks[0].device
        else:
            return None

    def extract_index(
        self,
        token_pos: int,
        num: int,
        **kwargs,
    ) -> torch.Tensor:
        """
                Returns slice of the slot position index, of shape
                `(batch_size, n_query_groups, num)` and values in
                `[0, cache_length)`. The slot position index contains the slot
                insert position for every token, which also depends on position in
                batch and query group.

                Args:
                    token_pos: Token position where slice starts. Must be
        -               `>= cache_length`.
                    num: Length of slice
                    **kwargs: Dtype and device for the returned tensor. The default
                        device is the one of the token chunks.

                Returns:
                    See above.

        """
        raise NotImplementedError


class DefaultKVCacheReplayLog(KVCacheReplayLog):
    def __init__(
        self,
        token_chunks: List[torch.Tensor],
        cache_length: int,
        max_prefill_length: int,
        grace_period: int = 0,
    ):
        if token_chunks:
            device = token_chunks[0].device
            if any(c.device != device for c in token_chunks):
                raise ValueError("All token_chunks entries must be on same device")
        self._token_chunks = token_chunks
        self._cache_length = cache_length
        self._grace_period = grace_period
        self._max_prefill_length = max_prefill_length

    @property
    def token_chunks(self) -> List[torch.Tensor]:
        return self._token_chunks

    @property
    def cache_length(self) -> int:
        return self._cache_length

    @property
    def max_prefill_length(self) -> int:
        return self._max_prefill_length

    @property
    def grace_period(self) -> int:
        return self._grace_period

    def append_token_chunk(self, chunk: torch.Tensor):
        if self.token_chunks:
            other = self.token_chunks[-1]
            if other.ndim != chunk.ndim or other.shape[:-1] != chunk.shape[:-1]:
                raise ValueError(
                    f"chunk has wrong shape: chunk.shape={chunk.shape}, other.shape={other.shape}"
                )
            if other.device != chunk.device:
                raise ValueError(
                    f"chunk has wrong device: chunk.device={chunk.device}, other.device={other.device}"
                )
        self.token_chunks.append(chunk.detach().clone())
