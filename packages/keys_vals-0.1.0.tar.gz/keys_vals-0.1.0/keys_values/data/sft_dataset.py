# Original: Copyright Lightning AI. Licensed under the Apache License 2.0, see LICENSE file.
# Modification: Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License").
# You may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
from functools import partial
from typing import List, Dict, Optional, Callable, Union, Any

import torch

from litgpt.prompts import PromptStyle, Default
from litgpt.tokenizer import Tokenizer

from keys_values.data.base import (
    INPUT_IDS_NAME,
    LABELS_NAME,
    POSITION_NAME,
    LongContextDataset,
    common_collate_fn,
    is_pad_datacase,
)


class SFTDataset(LongContextDataset):
    """
    Improved variant of :class:`litgpt.data.base.SFTDataset`.

    In particular, elem["token_counts"]["raw"] is not computed here, and
    included only if it is given or available from what is done anyway.
    Avoids extra costs due to tokenization.

    """

    def __init__(
        self,
        data: List[Dict[str, str]],
        tokenizer: Tokenizer,
        prompt_style: Union[str, PromptStyle],
        max_seq_length: int = -1,
        mask_prompt: bool = True,
        ignore_index: int = -100,
        transform: Optional[Callable[[Dict[str, str]], Dict[str, str]]] = None,
    ) -> None:
        super().__init__(
            data,
            tokenizer,
            prompt_style,
            max_seq_length,
            transform,
        )
        self.mask_prompt = mask_prompt
        self.ignore_index = ignore_index

    def __getitem__(self, idx: int) -> Dict[str, Any]:
        example = self.data[idx]
        if is_pad_datacase(example):
            return example
        if self.transform is not None:
            example = self.transform(example)
        prompt = self.prompt_style.apply(prompt=example["instruction"], **example)
        encoded_prompt = self.tokenizer.encode(
            prompt,
            max_length=self.max_seq_length,
        )
        encoded_response = self.tokenizer.encode(
            example["output"],
            bos=False,
            eos=True,
            max_length=self.max_seq_length,
        )
        encoded_prompt_and_response = torch.cat(
            (encoded_prompt, encoded_response)
        ).type(torch.int64)
        if 0 < self.max_seq_length < len(encoded_prompt_and_response):
            msl = self.max_seq_length
            encoded_prompt_and_response = encoded_prompt_and_response[:msl]
            encoded_prompt_and_response[msl - 1] = self.tokenizer.eos_id

        # The labels are the full prompt with response, but with the prompt masked out
        labels = encoded_prompt_and_response.clone()
        if self.mask_prompt:
            labels[: len(encoded_prompt)] = self.ignore_index

        token_counts = {"raw_plus_prompt_template": len(encoded_prompt_and_response)}
        raw_count = example.get("num_tokens_instruction")
        if (
            raw_count is None
            and self.transform is None
            and isinstance(self.prompt_style, Default)
        ):
            raw_count = len(encoded_prompt)
        if raw_count is not None:
            token_counts["raw"] = raw_count + len(encoded_response)

        result = {
            INPUT_IDS_NAME: encoded_prompt_and_response,
            LABELS_NAME: labels,
            "token_counts": token_counts,
        }
        if POSITION_NAME in example:
            result[POSITION_NAME] = example[POSITION_NAME]
        return result


def get_sft_collate_fn(pad_id: int = 0, ignore_index: int = -100):
    """Returns the collate function for supervised finetuning (needed in the DataLoader).

    The collate function gets a list of dicts with keys `input_ids` and `labels`.
    It returns a dict with batched `input_ids` and `labels`. Also pads short sequences to the longest element in
    the batch. Optionally truncates all sequences to the specified maximum length.
    """
    return partial(_sft_collate_fn, pad_id=pad_id, ignore_index=ignore_index)


def _sft_collate_fn(
    samples: List[Dict[str, Any]],
    pad_id: int = 0,
    ignore_index: int = -100,
) -> Dict[str, Union[torch.Tensor, Dict[str, Any]]]:
    batched, samples = common_collate_fn(samples, pad_id=pad_id)
    batched[LABELS_NAME] = torch.nn.utils.rnn.pad_sequence(
        [sample[LABELS_NAME] for sample in samples],
        batch_first=True,
        padding_value=ignore_index,
    )
    return batched
