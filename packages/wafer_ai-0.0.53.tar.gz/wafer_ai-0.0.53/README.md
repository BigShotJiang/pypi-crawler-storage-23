# wafer-ai

Unified Wafer package containing:

- `wafer.cli` – CLI commands and templates
- `wafer.core` – SDK, tools, environments, and rollouts
- `wafer.lsp` – language server implementation

**Install from PyPI** (creates `wafer` executable):

```bash
uv tool install wafer-ai
wafer --help
```

If you get 0.0.1 or "No executables", force latest: `uv tool install "wafer-ai>=0.0.20"`

**Install locally** from the monorepo:

```bash
uv pip install -e packages/wafer-ai
```
