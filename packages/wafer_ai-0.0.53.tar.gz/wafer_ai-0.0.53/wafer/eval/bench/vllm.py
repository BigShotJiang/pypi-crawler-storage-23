"""vLLM bench script.

Runs pytest for correctness and an inline kernel microbenchmark for performance.
Outputs JSON to stdout.

Usage: python -m wafer.eval.bench.vllm <op_name> <test_cmd> [bench_cmd] [--json] [--bench-only]

If bench_cmd is "auto" or omitted, runs a built-in microbenchmark for the op.
If bench_cmd is provided, shells out to it and parses the output.
If --bench-only is passed, skips the pytest correctness tests (useful for baselines).
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
import time


def _parse_pytest_output(output: str) -> dict:
    """Parse pytest output for pass/fail counts."""
    passed = 0
    failed = 0
    passed_match = re.search(r"(\d+) passed", output)
    if passed_match:
        passed = int(passed_match.group(1))
    failed_match = re.search(r"(\d+) failed", output)
    if failed_match:
        failed = int(failed_match.group(1))
    return {"passed": passed, "failed": failed, "total": passed + failed}


def _parse_bench_output(output: str) -> dict:
    """Parse benchmark output for throughput/latency metrics.

    Supports multiple vLLM kernel benchmark output formats:
    - "Kernel running time: 123.456 us" (paged_attention, layernorm, quant)
    - "throughput: 123.4" (serving benchmarks)
    - "123.4 TFLOPS" (gemm benchmarks)
    - "123.4 GB/s" (memory bandwidth benchmarks)
    - "latency: 123.4 ms" (general latency)
    """
    metrics: dict = {}

    # vLLM kernel microbenchmarks: "Kernel running time: 123.456 us"
    kernel_time = re.search(
        r"Kernel running time:\s*([\d.]+)\s*us", output, re.IGNORECASE
    )
    if kernel_time:
        metrics["time_us"] = float(kernel_time.group(1))

    throughput_match = re.search(r"throughput[:\s]+([\d.]+)", output, re.IGNORECASE)
    if throughput_match:
        metrics["throughput"] = float(throughput_match.group(1))
    tflops_match = re.search(r"([\d.]+)\s*TFLOPS", output, re.IGNORECASE)
    if tflops_match:
        metrics["tflops"] = float(tflops_match.group(1))
    bandwidth_match = re.search(r"([\d.]+)\s*GB/s", output, re.IGNORECASE)
    if bandwidth_match:
        metrics["bandwidth_gbps"] = float(bandwidth_match.group(1))
    latency_match = re.search(r"latency[:\s]+([\d.]+)\s*ms", output, re.IGNORECASE)
    if latency_match:
        metrics["latency_ms"] = float(latency_match.group(1))
    return metrics


# ── Inline kernel microbenchmarks ────────────────────────────────────────────
# Each returns time_us (microseconds per invocation).
# These run inside a set_current_vllm_config() context so custom ops work.


def _bench_layernorm(dtype_str: str = "half", hidden_size: int = 8192,
                     num_tokens: int = 4096, num_iters: int = 100) -> float:
    """Benchmark RMSNorm / LayerNorm kernel."""
    import torch
    from vllm.model_executor.layers.layernorm import RMSNorm
    from vllm.utils.torch_utils import STR_DTYPE_TO_TORCH_DTYPE
    dtype = STR_DTYPE_TO_TORCH_DTYPE.get(dtype_str, torch.float16)

    layer = RMSNorm(hidden_size).to(dtype=dtype, device="cuda")
    layer.weight.data.normal_(mean=1.0, std=0.1)
    x = torch.randn(num_tokens, hidden_size, dtype=dtype, device="cuda") * (1 / (2 * hidden_size))

    # warmup
    for _ in range(5):
        layer(x)
    torch.cuda.synchronize()

    t0 = time.perf_counter()
    for _ in range(num_iters):
        layer(x)
    torch.cuda.synchronize()
    return (time.perf_counter() - t0) / num_iters * 1e6


def _bench_activation(num_tokens: int = 4096, intermediate_size: int = 14336,
                      num_iters: int = 100) -> float:
    """Benchmark SiLU-and-mul activation kernel."""
    import torch
    from vllm.model_executor.layers.activation import SiluAndMul
    dtype = torch.bfloat16
    x = torch.randn(num_tokens, 2 * intermediate_size, dtype=dtype, device="cuda")
    layer = SiluAndMul()

    for _ in range(5):
        layer(x)
    torch.cuda.synchronize()

    t0 = time.perf_counter()
    for _ in range(num_iters):
        layer(x)
    torch.cuda.synchronize()
    return (time.perf_counter() - t0) / num_iters * 1e6


def _bench_rotary_embedding(num_tokens: int = 4096, num_heads: int = 32,
                            head_size: int = 128, num_iters: int = 100) -> float:
    """Benchmark rotary embedding kernel."""
    import torch
    from vllm.model_executor.layers.rotary_embedding import get_rope
    dtype = torch.bfloat16
    max_position = 8192
    rope_params = {"partial_rotary_factor": 1.0}
    rope = get_rope(head_size, max_position, True, rope_params)
    rope = rope.to(dtype=dtype, device="cuda")

    positions = torch.randint(0, max_position, (1, num_tokens), device="cuda")
    query = torch.randn(1, num_tokens, num_heads * head_size, dtype=dtype, device="cuda")
    key = torch.randn_like(query)

    for _ in range(5):
        rope.forward_cuda(positions, query.clone(), key.clone())
    torch.cuda.synchronize()

    t0 = time.perf_counter()
    for _ in range(num_iters):
        rope.forward_cuda(positions, query.clone(), key.clone())
    torch.cuda.synchronize()
    return (time.perf_counter() - t0) / num_iters * 1e6


def _bench_quant(quant_dtype: str = "fp8", num_tokens: int = 4096,
                 hidden_size: int = 8192, num_iters: int = 100) -> float:
    """Benchmark FP8 or INT8 quantization kernel."""
    import torch
    from vllm import _custom_ops as ops
    x = torch.randn(num_tokens, hidden_size, dtype=torch.float16, device="cuda")

    if quant_dtype == "fp8":
        fn = lambda: ops.scaled_fp8_quant(x)
    else:
        fn = lambda: ops.scaled_int8_quant(x)

    for _ in range(5):
        fn()
    torch.cuda.synchronize()

    t0 = time.perf_counter()
    for _ in range(num_iters):
        fn()
    torch.cuda.synchronize()
    return (time.perf_counter() - t0) / num_iters * 1e6


def _bench_paged_attention(num_seqs: int = 8, seq_len: int = 4096,
                           num_query_heads: int = 32, num_kv_heads: int = 8,
                           head_size: int = 128, block_size: int = 16,
                           num_iters: int = 100) -> float:
    """Benchmark paged attention v2 kernel."""
    import random
    import torch
    from vllm import _custom_ops as ops
    from vllm.utils.torch_utils import create_kv_caches_with_random

    NUM_BLOCKS = 128 * 1024
    dtype = torch.float16
    scale = float(1.0 / (head_size ** 0.5))

    query = torch.empty(num_seqs, num_query_heads, head_size, dtype=dtype, device="cuda")
    query.uniform_(-scale, scale)

    seq_lens = [seq_len] * num_seqs
    seq_lens_t = torch.tensor(seq_lens, dtype=torch.int, device="cuda")

    max_num_blocks_per_seq = (seq_len + block_size - 1) // block_size
    block_tables = torch.tensor(
        [[random.randint(0, NUM_BLOCKS - 1) for _ in range(max_num_blocks_per_seq)]
         for _ in range(num_seqs)],
        dtype=torch.int, device="cuda",
    )

    key_caches, value_caches = create_kv_caches_with_random(
        NUM_BLOCKS, block_size, 1, num_kv_heads, head_size, "auto", dtype, device="cuda",
    )
    key_cache, value_cache = key_caches[0], value_caches[0]

    output = torch.empty(num_seqs, num_query_heads, head_size, dtype=dtype, device="cuda")
    # paged_attention_v2 requires extra workspace buffers
    exp_sum = torch.empty(num_seqs, num_query_heads, dtype=torch.float32, device="cuda")
    max_logits = torch.empty(num_seqs, num_query_heads, dtype=torch.float32, device="cuda")
    # tmp_out shape: (num_seqs, num_query_heads, max_num_partitions, head_size)
    max_num_partitions = (seq_len + 512 - 1) // 512
    tmp_out = torch.empty(num_seqs, num_query_heads, max_num_partitions, head_size,
                          dtype=dtype, device="cuda")
    k_scale = torch.tensor(1.0, dtype=torch.float32, device="cuda")
    v_scale = torch.tensor(1.0, dtype=torch.float32, device="cuda")

    def run():
        ops.paged_attention_v2(
            output, exp_sum, max_logits, tmp_out, query,
            key_cache, value_cache, num_kv_heads, scale,
            block_tables, seq_lens_t, block_size, seq_len,
            None,  # alibi_slopes
            "auto",  # kv_cache_dtype
            k_scale, v_scale,
        )

    for _ in range(5):
        run()
    torch.cuda.synchronize()

    t0 = time.perf_counter()
    for _ in range(num_iters):
        run()
    torch.cuda.synchronize()
    return (time.perf_counter() - t0) / num_iters * 1e6


def _bench_fused_topk(num_tokens: int = 4096, hidden_size: int = 4096,
                      num_experts: int = 8, topk: int = 2,
                      num_iters: int = 100) -> float:
    """Benchmark fused_topk kernel."""
    import torch
    from vllm.model_executor.layers.fused_moe import fused_topk

    hidden_states = torch.randn(num_tokens, hidden_size, dtype=torch.bfloat16, device="cuda")
    gating_output = torch.randn(num_tokens, num_experts, dtype=torch.float32, device="cuda")

    for _ in range(5):
        fused_topk(hidden_states, gating_output, topk, renormalize=True)
    torch.cuda.synchronize()

    t0 = time.perf_counter()
    for _ in range(num_iters):
        fused_topk(hidden_states, gating_output, topk, renormalize=True)
    torch.cuda.synchronize()
    return (time.perf_counter() - t0) / num_iters * 1e6


def _bench_cache_kernels(num_tokens: int = 4096, num_heads: int = 32,
                         head_size: int = 128, block_size: int = 16,
                         num_iters: int = 100) -> float:
    """Benchmark reshape_and_cache kernel."""
    import torch
    from vllm import _custom_ops as ops
    dtype = torch.bfloat16
    num_blocks = 1024

    key = torch.randn(num_tokens, num_heads, head_size, dtype=dtype, device="cuda")
    value = torch.randn_like(key)
    key_cache = torch.randn(num_blocks, num_heads, head_size // 8, block_size, 8,
                            dtype=dtype, device="cuda")
    value_cache = torch.randn(num_blocks, num_heads, head_size, block_size,
                              dtype=dtype, device="cuda")
    slot_mapping = torch.randint(0, num_blocks * block_size, (num_tokens,),
                                 dtype=torch.long, device="cuda")
    k_scale = torch.tensor(1.0, dtype=torch.float32, device="cuda")
    v_scale = torch.tensor(1.0, dtype=torch.float32, device="cuda")

    def run():
        ops.reshape_and_cache(key, value, key_cache, value_cache, slot_mapping,
                              "auto", k_scale, v_scale)

    for _ in range(5):
        run()
    torch.cuda.synchronize()

    t0 = time.perf_counter()
    for _ in range(num_iters):
        run()
    torch.cuda.synchronize()
    return (time.perf_counter() - t0) / num_iters * 1e6


def _bench_fused_moe(num_tokens: int = 256, hidden_size: int = 4096,
                     intermediate_size: int = 8192, num_experts: int = 8,
                     topk: int = 2, num_iters: int = 50) -> float:
    """Benchmark fused MoE (experts GEMM) kernel."""
    import torch
    from vllm.model_executor.layers.fused_moe import fused_experts
    dtype = torch.bfloat16

    hidden_states = torch.randn(num_tokens, hidden_size, dtype=dtype, device="cuda")
    w1 = torch.randn(num_experts, 2 * intermediate_size, hidden_size, dtype=dtype, device="cuda")
    w2 = torch.randn(num_experts, hidden_size, intermediate_size, dtype=dtype, device="cuda")
    topk_weights = torch.softmax(
        torch.randn(num_tokens, topk, device="cuda"), dim=-1
    ).to(torch.float32)
    topk_ids = torch.randint(0, num_experts, (num_tokens, topk),
                             dtype=torch.int32, device="cuda")

    for _ in range(3):
        fused_experts(hidden_states, w1, w2, topk_weights, topk_ids)
    torch.cuda.synchronize()

    t0 = time.perf_counter()
    for _ in range(num_iters):
        fused_experts(hidden_states, w1, w2, topk_weights, topk_ids)
    torch.cuda.synchronize()
    return (time.perf_counter() - t0) / num_iters * 1e6


def _bench_cutlass_scaled_mm(M: int = 4096, N: int = 4096, K: int = 4096,
                              num_iters: int = 100) -> float:
    """Benchmark CUTLASS FP8 scaled matmul kernel."""
    import torch
    from vllm import _custom_ops as ops

    a = torch.randn(M, K, dtype=torch.float16, device="cuda").to(torch.float8_e4m3fn)
    # b must be column-major (stride(0)==1) for CUTLASS kernel
    b_raw = torch.randn(N, K, dtype=torch.float16, device="cuda").to(torch.float8_e4m3fn)
    b = b_raw.t().contiguous().t()
    scale_a = torch.tensor(1.0, dtype=torch.float32, device="cuda")
    scale_b = torch.tensor(1.0, dtype=torch.float32, device="cuda")

    for _ in range(5):
        ops.cutlass_scaled_mm(a, b, scale_a, scale_b, out_dtype=torch.bfloat16)
    torch.cuda.synchronize()

    t0 = time.perf_counter()
    for _ in range(num_iters):
        ops.cutlass_scaled_mm(a, b, scale_a, scale_b, out_dtype=torch.bfloat16)
    torch.cuda.synchronize()
    return (time.perf_counter() - t0) / num_iters * 1e6


# Registry: op_name -> (bench_fn, kwargs)
# Only 1:1 mappings — each task has a dedicated benchmark.
_BUILTIN_BENCHMARKS: dict[str, tuple] = {
    "rms_norm": (_bench_layernorm, {}),
    "layernorm": (_bench_layernorm, {}),
    "activation": (_bench_activation, {}),
    "rotary_embedding": (_bench_rotary_embedding, {}),
    "fp8_quant": (_bench_quant, {"quant_dtype": "fp8"}),
    "int8_quant": (_bench_quant, {"quant_dtype": "int8"}),
    "paged_attention": (_bench_paged_attention, {}),
    "fused_topk": (_bench_fused_topk, {}),
    "fused_moe": (_bench_fused_moe, {}),
    "cutlass_scaled_mm": (_bench_cutlass_scaled_mm, {}),
    "cache_kernels": (_bench_cache_kernels, {}),
}


def _run_builtin_benchmark(op_name: str) -> dict:
    """Run the built-in microbenchmark for an op, with VllmConfig context."""
    entry = _BUILTIN_BENCHMARKS.get(op_name)
    if entry is None:
        print(f"[vllm-eval] No built-in benchmark for op '{op_name}', skipping")
        return {}

    bench_fn, kwargs = entry
    # Show all parameters (defaults + overrides) so the agent knows exactly what's benchmarked
    import inspect
    sig = inspect.signature(bench_fn)
    full_params = {k: v.default for k, v in sig.parameters.items() if v.default is not inspect.Parameter.empty}
    full_params.update(kwargs)
    print(f"[vllm-eval] Running built-in microbenchmark: {bench_fn.__name__}")
    print(f"[vllm-eval] Benchmark parameters: {full_params}")

    try:
        # Set up VllmConfig context required by vLLM 0.15+ custom ops
        from vllm.config import set_current_vllm_config, VllmConfig
        import torch

        # Need to set device type explicitly for VllmConfig
        import os
        os.environ.setdefault("VLLM_TARGET_DEVICE", "cuda")

        with set_current_vllm_config(VllmConfig()):
            time_us = bench_fn(**kwargs)

        print(f"Kernel running time: {time_us:.3f} us")
        return {"time_us": time_us}

    except Exception as e:
        print(f"[vllm-eval] Built-in benchmark failed: {type(e).__name__}: {e}")
        # Try without VllmConfig context (older vLLM or ops that don't need it)
        try:
            time_us = bench_fn(**kwargs)
            print(f"Kernel running time: {time_us:.3f} us")
            return {"time_us": time_us}
        except Exception as e2:
            print(f"[vllm-eval] Benchmark also failed without config: {e2}")
            return {}


def main() -> None:
    # Parse args: <op_name> <test_cmd> [bench_cmd] [--json] [--bench-only]
    # Filter out flags from positional args so --json doesn't get eaten as bench_cmd.
    positional = []
    bench_only = False
    for arg in sys.argv[1:]:
        if arg == "--json":
            continue  # consumed by wafer tool eval, not us
        elif arg == "--bench-only":
            bench_only = True
        else:
            positional.append(arg)

    if len(positional) < 2:
        print(
            f"Usage: python -m wafer.eval.bench.vllm <op_name> <test_cmd> [bench_cmd] [--json] [--bench-only]\n"
            f"Got positional args: {positional}",
            file=sys.stderr,
        )
        sys.exit(1)

    op_name = positional[0]
    test_cmd = positional[1]
    bench_cmd = positional[2] if len(positional) > 2 else "auto"

    result: dict = {
        "success": False,
        "correctness_passed": False,
        "metrics": {},
        "error": None,
    }

    print(f"[vllm-eval] Op: {op_name}")
    print(f"[vllm-eval] Test: {test_cmd}")
    print(f"[vllm-eval] Bench: {bench_cmd}")
    if bench_only:
        print("[vllm-eval] Mode: bench-only (skipping correctness tests)")

    try:
        correctness_passed = True  # assume pass unless we run tests

        if not bench_only:
            print("[vllm-eval] Running correctness tests...")
            test_proc = subprocess.run(
                test_cmd, shell=True, capture_output=True, text=True, timeout=600,
            )
            print(test_proc.stdout)
            if test_proc.stderr:
                print(test_proc.stderr, file=sys.stderr)

            test_results = _parse_pytest_output(test_proc.stdout + "\n" + test_proc.stderr)
            correctness_passed = test_proc.returncode == 0 and test_results["failed"] == 0
            result["correctness_passed"] = correctness_passed
            result["test_results"] = test_results

        if correctness_passed:
            if bench_cmd in ("auto", ""):
                # Use built-in microbenchmark
                print("[vllm-eval] Running built-in benchmark...")
                metrics = _run_builtin_benchmark(op_name)
            else:
                # Shell out to external bench command
                print(f"[vllm-eval] Running external benchmark: {bench_cmd}")
                bench_proc = subprocess.run(
                    bench_cmd, shell=True, capture_output=True, text=True, timeout=600,
                )
                print(bench_proc.stdout)
                if bench_proc.stderr:
                    print(bench_proc.stderr, file=sys.stderr)
                metrics = _parse_bench_output(bench_proc.stdout + "\n" + bench_proc.stderr)

            result["metrics"] = metrics
            result["success"] = bool(metrics)
            if bench_only:
                result["correctness_passed"] = True  # not tested, assume pass
        else:
            result["error"] = f"Correctness tests failed: {test_results['failed']} failures"

    except subprocess.TimeoutExpired:
        result["error"] = "Evaluation timed out"
    except Exception as e:
        result["error"] = str(e)

    print(f"EVAL_RESULT_JSON:{json.dumps(result)}")


if __name__ == "__main__":
    main()
