"""Allow running bench scripts via python -m wafer.eval.bench."""
from __future__ import annotations

import sys

print("Usage: python -m wafer.eval.bench.<name>", file=sys.stderr)
print("Available: kernelbench, gpumode, vllm, hipblaslt", file=sys.stderr)
sys.exit(1)
