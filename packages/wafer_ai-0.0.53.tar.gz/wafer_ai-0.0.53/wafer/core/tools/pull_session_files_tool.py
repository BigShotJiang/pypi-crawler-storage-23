"""Pull files from a subagent session into the orchestrator workspace."""
from __future__ import annotations

from pathlib import Path

from wafer.core.rollouts.dtypes import (
    Tool,
    ToolCall,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
)

PULL_SESSION_FILES_TOOL = Tool(
    type="function",
    function=ToolFunction(
        name="pull_session_files",
        description=(
            "Pull files from a completed subagent session into your local workspace. "
            "Use the session_id from the [subagent_session:...] tag in subagent results. "
            "Files are written to subagents/<session_id>/ by default."
        ),
        parameters=ToolFunctionParameter(
            type="object",
            properties={
                "session_id": {
                    "type": "string",
                    "description": "Subagent session ID (from [subagent_session:...] in tool result)",
                },
                "paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Specific file paths to pull. Omit to pull all files.",
                },
                "dest_dir": {
                    "type": "string",
                    "description": "Destination directory within workspace. Defaults to subagents/<session_id>.",
                },
            },
        ),
        required=["session_id"],
    ),
)

MAX_PULL_FILE_SIZE = 1_000_000  # 1MB per file
MAX_TOTAL_PULL_SIZE = 10_000_000  # 10MB total


async def exec_pull_session_files(
    tool_call: ToolCall,
    working_dir: Path,
    *,
    api_url: str | None = None,
    auth_token: str | None = None,
) -> ToolResult:
    """Pull files from a subagent session workspace into the orchestrator's local workspace."""
    session_id = tool_call.args.get("session_id", "")
    requested_paths: list[str] | None = tool_call.args.get("paths")
    dest_dir_arg: str | None = tool_call.args.get("dest_dir")

    assert session_id, "session_id is required"
    assert api_url, "WAFER_API_URL not configured"
    assert auth_token, "WAFER_AUTH_TOKEN not configured"

    dest_dir = working_dir / (dest_dir_arg or f"subagents/{session_id}")
    dest_dir = dest_dir.resolve()
    assert dest_dir == working_dir.resolve() or str(dest_dir).startswith(
        str(working_dir.resolve()) + "/"
    ), f"dest_dir must be within working_dir, got {dest_dir}"

    file_list, err = await _list_session_files(api_url, auth_token, session_id)
    if err:
        return ToolResult(tool_call_id=tool_call.id, is_error=True, content="", error=err)
    assert file_list is not None

    pullable = [
        f for f in file_list
        if not f["is_dir"] and f["size"] <= MAX_PULL_FILE_SIZE
    ]

    if requested_paths:
        requested_set = set(requested_paths)
        pullable = [f for f in pullable if f["path"] in requested_set]
        missing = requested_set - {f["path"] for f in pullable}
        if missing:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Files not found or too large (>{MAX_PULL_FILE_SIZE}B): {', '.join(sorted(missing))}",
            )

    if not pullable:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=False,
            content="No files to pull (session workspace is empty or all files exceed size limit).",
        )

    total_size = sum(f["size"] for f in pullable)
    if total_size > MAX_TOTAL_PULL_SIZE:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=f"Total size {total_size}B exceeds {MAX_TOTAL_PULL_SIZE}B limit. Use 'paths' to select specific files.",
        )

    pulled: list[str] = []
    errors: list[str] = []
    for f in pullable:
        file_data, fetch_err = await _fetch_file(api_url, auth_token, session_id, f["path"])
        if fetch_err:
            errors.append(f"{f['path']}: {fetch_err}")
            continue

        assert file_data is not None
        file_dest = dest_dir / f["path"]
        file_dest.parent.mkdir(parents=True, exist_ok=True)
        if file_data["encoding"] == "base64":
            import base64

            file_dest.write_bytes(base64.b64decode(file_data["content"]))
        else:
            file_dest.write_text(file_data["content"], encoding="utf-8")
        pulled.append(f["path"])

    lines = [f"Pulled {len(pulled)} file(s) to {dest_dir.relative_to(working_dir)}/"]
    for p in pulled:
        size = next((f["size"] for f in pullable if f["path"] == p), 0)
        lines.append(f"  {p} ({size}B)")
    if errors:
        lines.append(f"\nFailed to fetch {len(errors)} file(s):")
        for e in errors:
            lines.append(f"  {e}")

    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=bool(errors and not pulled),
        content="\n".join(lines),
        error="\n".join(errors) if errors and not pulled else None,
    )


async def _list_session_files(
    api_url: str, auth_token: str, session_id: str,
) -> tuple[list[dict] | None, str | None]:
    """List files in a session. Returns (files, error)."""
    from wafer.core.api_client import WaferApiError, fetch_wafer_api

    try:
        data = await fetch_wafer_api(
            api_url=api_url,
            auth_token=auth_token,
            endpoint=f"/v1/cloud-agent/sessions/{session_id}/files",
        )
        return data.get("files", []), None
    except WaferApiError as e:
        return None, f"Failed to list files: {e.detail}"


async def _fetch_file(
    api_url: str, auth_token: str, session_id: str, path: str,
) -> tuple[dict[str, str] | None, str | None]:
    """Fetch a single file's content. Returns ({"content": ..., "encoding": ...}, error)."""
    import urllib.parse

    from wafer.core.api_client import WaferApiError, fetch_wafer_api

    encoded_path = "/".join(urllib.parse.quote(seg, safe="") for seg in path.split("/"))
    try:
        data = await fetch_wafer_api(
            api_url=api_url,
            auth_token=auth_token,
            endpoint=f"/v1/cloud-agent/sessions/{session_id}/files/{encoded_path}",
        )
        return {"content": data.get("content", ""), "encoding": data.get("encoding", "utf-8")}, None
    except WaferApiError as e:
        return None, f"{e.status_code}: {e.detail[:200]}"
