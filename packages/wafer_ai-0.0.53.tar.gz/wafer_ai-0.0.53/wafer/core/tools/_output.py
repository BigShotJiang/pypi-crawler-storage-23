"""Shared output truncation for bash_tool."""
from __future__ import annotations

MAX_OUTPUT_SIZE = 32_000


def truncate_output(output: str, max_size: int = MAX_OUTPUT_SIZE) -> str:
    """Head+tail truncation. Used by bash_tool."""
    if len(output) <= max_size:
        return output
    head = max_size // 2
    tail = max_size // 2
    truncated = len(output) - max_size
    return (
        output[:head]
        + f"\n\n... ({truncated} chars truncated, showing first and last {max_size // 2} chars) ...\n\n"
        + output[-tail:]
    )
