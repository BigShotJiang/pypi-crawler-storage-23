"""Unified Sandbox abstraction.

A sandbox is an environment where an agent runs. From the agent's perspective,
it's always a local machine. The distinction is in the *target* — where that
local environment lives.

Three target types:
- "local": user's terminal, no tmux, no GPU management
- "modal": Modal container, CPU only
- GPU target (e.g. "my-b200"): SSH + tmux + heartbeat + driver enforcement
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class Sandbox:
    """A sandbox occupies all GPUs on the target machine.

    One active sandbox per target at a time. Agents join sandboxes
    via ``wafer agent -s <sandbox_id>``.
    """

    id: str
    target: str  # "local", "modal", or a registered target name
    gpu_count: int = 0
    gpu_type: str | None = None
    gpu_vendor: Literal["nvidia", "amd", "trainium"] | None = None
    ssh_target: str | None = None
    ssh_key: str | None = None
    tmux_session: str | None = None


def load_sandbox(sandbox_id: str) -> Sandbox:
    """Load a sandbox from the DB, resolving target details from the target registry."""
    from wafer.cli.sandboxes_api import db_get_sandbox

    row = db_get_sandbox(sandbox_id)
    assert row is not None, f"Sandbox '{sandbox_id}' not found"

    target_name = row["target_name"]
    ssh_target = row.get("ssh_target")
    ssh_key = row.get("ssh_key")
    gpu_count = row.get("gpu_count", 0)
    gpu_type = row.get("gpu_type")
    gpu_vendor = row.get("gpu_vendor")

    if not ssh_target:
        try:
            from wafer.cli.user_targets_api import get_target_by_name, user_target_to_baremetal_target
            t = get_target_by_name(target_name)
            if t:
                bt = user_target_to_baremetal_target(t)
                ssh_target = bt.ssh_target
                ssh_key = bt.ssh_key
                gpu_count = len(bt.gpu_ids)
                gpu_type = bt.gpu_type
                gpu_vendor = bt.vendor
        except (KeyError, AttributeError, TypeError):
            pass

    return Sandbox(
        id=row["id"],
        target=target_name,
        ssh_target=ssh_target,
        ssh_key=ssh_key,
        gpu_count=gpu_count,
        gpu_type=gpu_type,
        gpu_vendor=gpu_vendor,
        tmux_session=row.get("tmux_session"),
    )


def should_install_path_wrappers(sandbox: Sandbox) -> bool:
    """PATH wrappers only needed for NVIDIA (converts EXCLUSIVE_PROCESS errors to waits)."""
    return sandbox.gpu_vendor == "nvidia"


def generate_wrapper_script(binary_name: str, real_path: str) -> str:
    """Generate a flock-based wrapper script for an NVIDIA GPU binary."""
    assert binary_name, "binary_name required"
    assert real_path, "real_path required"
    return (
        "#!/bin/bash\n"
        f'GPU_ID=${{CUDA_VISIBLE_DEVICES:-0}}\n'
        f'exec flock /var/lock/wafer-gpu-${{GPU_ID}} {real_path} "$@"\n'
    )
