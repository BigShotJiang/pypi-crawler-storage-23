"""
Status line component - displays session info, model, tokens below input.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

from ..tui import Component
from ..utils import visible_width

if TYPE_CHECKING:
    from ..theme import Theme


class StatusLine(Component):
    """Single-line status bar showing session info, model, and token counts."""
    def __init__(
        self,
        theme: Theme | None = None,
        app_base_url: str | None = None,
    ) -> None:
        """Initialize status line.
        Args:
            theme: Theme for styling
            app_base_url: Base URL for the wafer app (e.g. http://localhost:3001 or https://app.wafer.ai)
        """
        from ..theme import DARK_THEME
        self._theme = theme or DARK_THEME
        self._app_base_url = app_base_url
        # Status fields
        self._session_id: str | None = None
        self._model: str | None = None
        self._input_tokens: int = 0
        self._output_tokens: int = 0
        self._cost: float = 0.0
        self._context_window: int | None = None  # Model's max context window
        self._env_info: dict[str, str] | None = None
        self._mode: str | None = None

    def set_session_id(self, session_id: str | None) -> None:
        """Set the session ID to display."""
        self._session_id = session_id

    def set_model(self, model: str | None, context_window: int | None = None) -> None:
        """Set the model name and context window to display."""
        self._model = model
        self._context_window = context_window

    def set_tokens(self, input_tokens: int, output_tokens: int, cost: float = 0.0) -> None:
        """Set token counts and cost."""
        self._input_tokens = input_tokens
        self._output_tokens = output_tokens
        self._cost = cost

    def add_tokens(self, input_tokens: int, output_tokens: int, cost: float = 0.0) -> None:
        """Add to token counts and cost."""
        self._input_tokens += input_tokens
        self._output_tokens += output_tokens
        self._cost += cost

    def set_env_info(self, env_info: dict[str, str] | None) -> None:
        """Set environment info to display."""
        self._env_info = env_info

    def set_mode(self, mode: str | None) -> None:
        """Set current mode indicator (e.g. 'plan'). None clears it."""
        self._mode = mode

    def _wrap_parts(
        self, parts: list[str], available_width: int, separator: str = "  │  "
    ) -> list[str]:
        """Wrap parts across multiple lines at part boundaries.
        Args:
            parts: List of content parts to join
            available_width: Max width per line
            separator: String to join parts with
        Returns:
            List of wrapped lines (without styling/padding)
        """
        if not parts:
            return []
        lines: list[str] = []
        current_line = ""
        sep_width = visible_width(separator)
        for part in parts:
            part_width = visible_width(part)
            if not current_line:
                # First part on this line
                if part_width <= available_width:
                    current_line = part
                else:
                    # Single part too wide - truncate it
                    current_line = part[: available_width - 1] + "…"
            else:

                new_width = visible_width(current_line) + sep_width + part_width
                if new_width <= available_width:
                    current_line = current_line + separator + part
                else:
                    # Wrap to new line
                    lines.append(current_line)
                    if part_width <= available_width:
                        current_line = part
                    else:
                        current_line = part[: available_width - 1] + "…"
        if current_line:
            lines.append(current_line)
        return lines

    @staticmethod
    def _format_tokens(n: int) -> str:
        """Format token count with K suffix for readability."""
        if n >= 1000:
            return f"{n / 1000:.1f}K"
        return str(n)

    def render(self, width: int) -> list[str]:
        """Render the status line as a single clean line with · separators."""
        from ..theme import hex_to_fg
        dim = hex_to_fg(self._theme.dim)
        muted = hex_to_fg(self._theme.muted)
        fg_reset = "\x1b[39m"

        parts: list[str] = []

        # Mode indicator
        if self._mode:
            accent = hex_to_fg(self._theme.accent)
            parts.append(f"{accent}{self._mode.upper()}{fg_reset}")

        # Session (show short suffix only, with clickable link if app URL is set)
        if self._session_id:
            short_id = self._session_id.rsplit("_", 1)[-1] if "_" in self._session_id else self._session_id
            if self._app_base_url:
                url = f"{self._app_base_url}/agent?session={self._session_id}"
                osc_link = f"\x1b]8;;{url}\x1b\\{short_id}\x1b]8;;\x1b\\"
                parts.append(f"{dim}session{fg_reset} {muted}{osc_link}{fg_reset}")
            else:
                parts.append(f"{dim}session{fg_reset} {muted}{short_id}{fg_reset}")

        # Tokens
        if self._input_tokens > 0 or self._output_tokens > 0:
            inp = self._format_tokens(self._input_tokens)
            out = self._format_tokens(self._output_tokens)
            token_str = f"{dim}tokens{fg_reset} {muted}{inp} in · {out} out{fg_reset}"
            if self._context_window and self._context_window > 0:
                total = self._input_tokens + self._output_tokens
                pct = (total / self._context_window) * 100
                token_str += f" {dim}({pct:.0f}% context){fg_reset}"
            parts.append(token_str)

        # Env info
        if self._env_info:
            for key, value in self._env_info.items():
                parts.append(f"{dim}{key}{fg_reset} {muted}{value}{fg_reset}")

        if not parts:
            return [" " * width]

        separator = f"  {dim}·{fg_reset}  "
        line_content = separator.join(parts)
        content_width = visible_width(line_content)
        padding = " " * max(0, width - 2 - content_width)
        return [f"  {line_content}{padding}"]
