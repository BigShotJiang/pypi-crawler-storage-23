"""Template loader utilities.

TOML-only: loads templates from bundled TOML files in wafer/cli/templates/toml/.
"""
from __future__ import annotations

from wafer.cli.agent_config import AgentConfig


def load_template(template_name: str) -> AgentConfig:
    """Load a template by name from bundled TOML."""
    from wafer.cli.agent_config import get_bundled_template_path, load_agent_config

    path = get_bundled_template_path(template_name)
    if path is None:
        available = list_templates()
        raise FileNotFoundError(
            f"Template '{template_name}' not found. "
            f"Available: {', '.join(available) if available else '(none)'}"
        )
    return load_agent_config(path)


def list_templates() -> list[str]:
    """List available bundled TOML template names."""
    from wafer.cli.agent_config import list_bundled_templates
    return list_bundled_templates()


def load_all_templates() -> list[tuple[str, AgentConfig | None, str | None]]:
    """Load all available templates with error handling."""
    names = list_templates()
    results: list[tuple[str, AgentConfig | None, str | None]] = []
    for name in names:
        try:
            config = load_template(name)
            results.append((name, config, None))
        except (FileNotFoundError, ValueError, KeyError, TypeError) as e:
            results.append((name, None, str(e)))
    return results
