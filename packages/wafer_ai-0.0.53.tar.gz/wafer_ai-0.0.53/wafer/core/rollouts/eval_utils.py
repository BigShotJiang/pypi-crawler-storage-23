"""Shared evaluation utilities used by the CLI-agent-based eval runner.

Pure functions for: summary metrics, resume, sample persistence, dataset loading.
Extracted from evaluation.py to decouple from the in-process evaluate() pipeline.
"""
from __future__ import annotations

import json
import logging
import re
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from .dtypes import Sample, Score, Trajectory

logger = logging.getLogger(__name__)

# JSON-like recursive type for sanitize_api_keys
JsonValue = dict[str, "JsonValue"] | list["JsonValue"] | str | int | float | bool | None


# ── Git Info ──────────────────────────────────────────────────────────────────
def get_git_info() -> dict[str, Any]:
    """Get git repository info for reproducibility."""
    info: dict[str, Any] = {
        "commit": None,
        "branch": None,
        "dirty": None,
        "commit_full": None,
    }
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            info["commit_full"] = result.stdout.strip()
            info["commit"] = info["commit_full"][:8]
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            info["branch"] = result.stdout.strip()
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            info["dirty"] = len(result.stdout.strip()) > 0
    except (subprocess.SubprocessError, FileNotFoundError, OSError):
        pass
    return info


# ── Sanitize ──────────────────────────────────────────────────────────────────
def sanitize_api_keys(data: JsonValue) -> JsonValue:
    """Recursively sanitize API keys from nested data structures."""
    if isinstance(data, dict):
        sanitized = {}
        for key, value in data.items():
            if key == "api_key" and isinstance(value, str) and value.startswith("sk-"):
                sanitized[key] = "***REDACTED***"
            else:
                sanitized[key] = sanitize_api_keys(value)
        return sanitized
    elif isinstance(data, list):
        return [sanitize_api_keys(item) for item in data]
    else:
        return data


# ── Summary Metrics ───────────────────────────────────────────────────────────
def compute_summary_metrics(results: list[Sample]) -> dict[str, Any]:
    """Compute summary statistics from results using Score."""
    if not results:
        return {}
    summary: dict[str, Any] = {}
    all_metric_names: set[str] = set()
    for r in results:
        if r.score:
            for m in r.score.metrics:
                all_metric_names.add(m.name)
    for metric_name in all_metric_names:
        values = []
        for r in results:
            if r.score:
                for m in r.score.metrics:
                    if m.name == metric_name:
                        values.append(m.value)
                        break
        if values:
            mean_val = sum(values) / len(values)
            sorted_values = sorted(values)
            n = len(sorted_values)
            if n % 2 == 0:
                median_val = (sorted_values[n // 2 - 1] + sorted_values[n // 2]) / 2
            else:
                median_val = sorted_values[n // 2]
            summary[f"mean_{metric_name}"] = mean_val
            summary[f"median_{metric_name}"] = median_val
            summary[f"min_{metric_name}"] = min(values)
            summary[f"max_{metric_name}"] = max(values)
            summary[f"std_{metric_name}"] = (
                sum((v - mean_val) ** 2 for v in values) / len(values)
            ) ** 0.5
    rewards = [r.score.reward if r.score else 0.0 for r in results]
    if rewards:
        mean_reward = sum(rewards) / len(rewards)
        summary["mean_reward"] = mean_reward
        summary["min_reward"] = min(rewards)
        summary["max_reward"] = max(rewards)
        summary["std_reward"] = (sum((r - mean_reward) ** 2 for r in rewards) / len(rewards)) ** 0.5
    summary["total_samples"] = len(results)
    summary["avg_turns"] = sum(r.metadata.get("turns_used", 0) for r in results) / len(results)
    summary["avg_tokens"] = sum(r.metadata.get("total_tokens", 0) for r in results) / len(results)

    provider_errors = [r for r in results if r.metadata.get("status") == "provider_error"]
    failed_samples = [r for r in results if r.metadata.get("status") == "failed"]
    completed_samples = [r for r in results if r.metadata.get("status") == "success"]
    summary["provider_errors"] = len(provider_errors)
    summary["failed_samples"] = len(failed_samples)
    summary["completed_samples"] = len(completed_samples)
    summary["run_completion_rate"] = len(completed_samples) / len(results) if results else 0.0
    error_types: dict[str, int] = {}
    for r in failed_samples:
        error = r.metadata.get("error", "Unknown error")
        error_type = error.split(":")[0] if ":" in error else error
        error_types[error_type] = error_types.get(error_type, 0) + 1
    if error_types:
        summary["error_breakdown"] = error_types
    provider_breakdown: dict[str, int] = {}
    for r in provider_errors:
        error = r.metadata.get("error", "")
        if "ProviderError[" in error:
            provider = error.split("[")[1].split("]")[0]
        else:
            provider = "unknown"
        provider_breakdown[provider] = provider_breakdown.get(provider, 0) + 1
    if provider_breakdown:
        summary["provider_error_breakdown"] = provider_breakdown

    # pass@k: group by task index, check if any sample passed (reward > 0)
    task_groups: dict[str, list[Sample]] = {}
    for r in results:
        parts = r.id.rsplit("_k", 1)
        task_key = parts[0]
        task_groups.setdefault(task_key, []).append(r)
    if task_groups:
        n_tasks = len(task_groups)
        max_k = max(len(v) for v in task_groups.values())
        if max_k > 1:
            passed_tasks = sum(
                1 for samples in task_groups.values()
                if any((s.score.reward if s.score else 0.0) > 0 for s in samples)
            )
            summary[f"pass_at_{max_k}"] = passed_tasks / n_tasks if n_tasks else 0.0
            best_rewards = [
                max((s.score.reward if s.score else 0.0) for s in samples)
                for samples in task_groups.values()
            ]
            summary[f"mean_best_reward_at_{max_k}"] = (
                sum(best_rewards) / len(best_rewards) if best_rewards else 0.0
            )

    return summary


# ── Resume Support ────────────────────────────────────────────────────────────
def load_completed_sample_ids(resume_dir: Path) -> set[str]:
    """Load IDs of completed samples from a previous run for resume."""
    completed_ids: set[str] = set()
    samples_dir = resume_dir / "samples"
    if not samples_dir.exists():
        logger.warning(f"No samples directory found in {resume_dir}")
        return completed_ids
    for sample_file in samples_dir.glob("*.json"):
        try:
            sample_data = json.loads(sample_file.read_text())
            status = sample_data.get("metadata", {}).get("status")
            if status == "success":
                completed_ids.add(sample_data.get("id", sample_file.stem))
        except Exception as e:
            logger.warning(f"Failed to load sample {sample_file}: {e}")
    return completed_ids


def load_streamed_samples(output_dir: Path) -> list[Sample]:
    """Load any samples already streamed to disk (for interrupt recovery)."""
    samples: list[Sample] = []
    samples_dir = output_dir / "samples"
    if not samples_dir.exists():
        return samples
    for sample_file in sorted(samples_dir.glob("*.json")):
        try:
            sample_data = json.loads(sample_file.read_text())
            samples.append(Sample.from_dict(sample_data))
        except Exception as e:
            logger.warning(f"Failed to load streamed sample {sample_file}: {e}")
    return samples


# ── Sample Persistence ────────────────────────────────────────────────────────
def write_sample_started(
    sample_id: str,
    sample_data: dict[str, Any],
    output_dir: Path,
) -> None:
    """Write a placeholder sample file when a sample starts. Enables UI to show samples as they appear."""
    try:
        output_dir = Path(output_dir)
        samples_dir = output_dir / "samples"
        samples_dir.mkdir(parents=True, exist_ok=True)
        placeholder = {
            "id": sample_id,
            "input": sample_data,
            "trajectory": None,
            "score": None,
            "reward": 0.0,
            "metadata": {"status": "running"},
        }
        placeholder = sanitize_api_keys(placeholder)
        sample_file = samples_dir / f"{sample_id}.json"
        sample_file.write_text(json.dumps(placeholder, indent=2, default=str))
        logger.debug(f"Wrote sample started placeholder {sample_id}")
    except Exception as e:
        logger.warning(f"Failed to write sample started {sample_id}: {e}")


def stream_sample_to_file(sample: Sample, output_dir: Path) -> None:
    """Stream a completed sample to file immediately for live observability."""
    try:
        output_dir = Path(output_dir)
        samples_dir = output_dir / "samples"
        samples_dir.mkdir(parents=True, exist_ok=True)
        sample_dict = sample.to_dict()
        sample_dict = sanitize_api_keys(sample_dict)
        sample_file = samples_dir / f"{sample.id}.json"
        sample_file.write_text(json.dumps(sample_dict, indent=2, default=str))
        if sample.trajectory:
            trajectories_dir = output_dir / "trajectories"
            trajectories_dir.mkdir(parents=True, exist_ok=True)
            traj_file = trajectories_dir / f"{sample.id}.jsonl"
            Trajectory.save_jsonl([sample.trajectory], str(traj_file))
        logger.debug(f"Streamed sample {sample.id} to {output_dir}")
    except Exception as e:
        logger.warning(f"Failed to stream sample {sample.id}: {e}")


def write_partial_report(
    output_dir: Path,
    completed_samples: list[Sample],
    eval_name: str,
    interrupted: bool = False,
    resume_from: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Write partial report for observability and interrupt recovery."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    summary_metrics = compute_summary_metrics(completed_samples) if completed_samples else {}
    report: dict[str, Any] = {
        "eval_name": eval_name,
        "completed_samples": len(completed_samples),
        "partial": True,
        "interrupted": interrupted,
        "summary_metrics": summary_metrics,
        "sample_ids": [s.id for s in completed_samples],
        "timestamp": datetime.now().isoformat(),
        "git_info": get_git_info(),
    }
    if metadata:
        report["metadata"] = metadata
    if resume_from:
        report["resume_from"] = resume_from
    if interrupted:
        report["interrupted_at"] = datetime.now().isoformat()
    report = sanitize_api_keys(report)
    report_file = output_dir / "report.json"
    report_file.write_text(json.dumps(report, indent=2))
    logger.debug(f"Wrote partial report: {len(completed_samples)} samples")


# ── EvalReport ────────────────────────────────────────────────────────────────
@dataclass
class EvalReport:
    """Summary report for an evaluation run."""
    eval_name: str
    total_samples: int
    summary_metrics: dict[str, Any]
    sample_results: list[Sample]
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    git_info: dict[str, Any] = field(default_factory=get_git_info)
    metadata: dict[str, Any] | None = None

    async def save(self, output_dir: Path) -> None:
        """Save evaluation results to directory."""
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        samples_dir = output_dir / "samples"
        samples_dir.mkdir(exist_ok=True)
        for sample in self.sample_results:
            sample_dict = sample.to_dict()
            sample_dict = sanitize_api_keys(sample_dict)
            sample_file = samples_dir / f"{sample.id}.json"
            sample_file.write_text(json.dumps(sample_dict, indent=2, default=str))
        summary: dict[str, Any] = {
            "eval_name": self.eval_name,
            "total_samples": self.total_samples,
            "summary_metrics": self.summary_metrics,
            "timestamp": self.timestamp,
            "git_info": self.git_info,
            "sample_ids": [s.id for s in self.sample_results],
        }
        if self.metadata:
            summary["metadata"] = self.metadata
        summary = sanitize_api_keys(summary)
        report_file = output_dir / "report.json"
        report_file.write_text(json.dumps(summary, indent=2))
        trajectories_dir = output_dir / "trajectories"
        trajectories_dir.mkdir(exist_ok=True)
        for sample in self.sample_results:
            if sample.trajectory:
                traj_file = trajectories_dir / f"{sample.id}.jsonl"
                Trajectory.save_jsonl([sample.trajectory], str(traj_file))
        logger.info(f"Saved -> {output_dir}")


# ── Dataset Loaders ───────────────────────────────────────────────────────────
def load_jsonl(path: Path) -> list[dict[str, Any]]:
    """Load JSONL dataset."""
    items = []
    with open(path) as f:
        for line in f:
            if line.strip():
                items.append(json.loads(line))
    return items


def load_csv(path: Path) -> list[dict[str, Any]]:
    """Load CSV dataset."""
    import csv
    items = []
    with open(path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            items.append(dict(row))
    return items


# ── Analysis Helpers ──────────────────────────────────────────────────────────
def group_by(
    results: list[Sample],
    key: Any,
) -> dict[str, list[Sample]]:
    """Group evaluation results by a key function."""
    groups: dict[str, list[Sample]] = {}
    for result in results:
        k = key(result)
        if k not in groups:
            groups[k] = []
        groups[k].append(result)
    return groups


def summarize(results: list[Sample]) -> dict[str, float]:
    """Compute summary statistics for a list of evaluation results."""
    if not results:
        return {"mean": 0.0, "std": 0.0, "min": 0.0, "max": 0.0, "n": 0}
    rewards = []
    for r in results:
        if r.score is not None:
            rewards.append(r.score.reward)
        else:
            rewards.append(0.0)
    n = len(rewards)
    mean = sum(rewards) / n
    variance = sum((r - mean) ** 2 for r in rewards) / n
    std = variance ** 0.5
    return {
        "mean": mean,
        "std": std,
        "min": min(rewards),
        "max": max(rewards),
        "n": n,
    }
