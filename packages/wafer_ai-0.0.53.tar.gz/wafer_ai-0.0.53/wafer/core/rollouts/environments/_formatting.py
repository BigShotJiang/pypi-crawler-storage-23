"""Shared formatting utilities for environment tool output.
Provides consistent formatting across all environments for:
- Extracting text from tool results
- Formatting tool output with truncation and theming
- Default tool rendering (works for any tool with zero config)
- GPU event line formatting (wafer target run lock acquire/release)
"""
from __future__ import annotations

import json
import re
from typing import TYPE_CHECKING, Any

_GPU_EVENT_PREFIX = "[GPU_EVENT] "


def format_gpu_event_line(line: str) -> str | None:
    """Format [GPU_EVENT] JSON line for human display. Returns None if not a GPU event."""
    if not line.strip().startswith(_GPU_EVENT_PREFIX):
        return None
    try:
        json_str = line.strip()[len(_GPU_EVENT_PREFIX) :]
        event = json.loads(json_str)
    except (json.JSONDecodeError, KeyError):
        return None
    etype = event.get("type", "")
    target = event.get("target", "?")
    if etype == "gpu_acquire":
        gpu_ids = event.get("gpu_ids", [])
        if gpu_ids:
            ids_str = ",".join(map(str, gpu_ids))
            return f"[GPU] Acquired {target} (GPU {ids_str})"
        return f"[GPU] Acquired {target}"
    if etype == "gpu_release":
        hold_ms = event.get("hold_duration_ms")
        suffix = f" ({hold_ms}ms)" if hold_ms is not None else ""
        return f"[GPU] Released {target}{suffix}"
    return f"[GPU] {etype}: {target}"

if TYPE_CHECKING:
    from ..dtypes import DetailLevel, ToolRenderConfig
    from ..frontends.tui.theme import Theme


def get_text_output(result: dict[str, Any] | None) -> str:
    """Extract text output from tool result.
    Handles result formats:
    - {"content": "string"} - direct string content
    - {"content": [{"type": "text", "text": "..."}]} - content blocks
    Returns:
        Extracted text with ANSI codes and carriage returns stripped.
    """
    if not result:
        return ""
    content = result.get("content", {})
    # Direct string content
    if isinstance(content, str):
        return content
    # Content block list
    if isinstance(content, list):
        text_blocks = [c for c in content if isinstance(c, dict) and c.get("type") == "text"]
        text_output = "\n".join(c.get("text", "") for c in text_blocks if c.get("text"))
        return _strip_ansi(text_output)
    return ""


def _strip_ansi(text: str) -> str:
    """Strip ANSI escape codes and carriage returns."""
    text = re.sub(r"\x1b\[[0-9;]*[a-zA-Z]", "", text)
    return text.replace("\r", "")


_BODY_CONTENT_ARGS = frozenset({
    "content", "code", "body", "new_string", "old_string", "source", "script",
})

_STREAMING_CONTENT_ARGS = _BODY_CONTENT_ARGS | frozenset({
    "command", "text", "query", "sql", "prompt",
})


def _default_header(tool_name: str, args: dict[str, Any], theme: Any = None) -> str:
    """Generate default header for a tool call.
    Format: tool_name(arg1=..., arg2=...)
    Content args (body/code/content) are excluded from the header since they're
    shown in the result body or streaming display. Remaining args are truncated
    at 50 chars. When a theme is provided, tool name gets accent color and args
    get muted color for visual hierarchy.
    """
    display_args = {k: v for k, v in args.items() if k not in _BODY_CONTENT_ARGS}
    name_str = theme.accent_fg(tool_name) if theme else tool_name
    if not display_args:
        return f"{name_str}()"
    parts = []
    for key, value in list(display_args.items())[:3]:
        if isinstance(value, str):
            display = repr(value[:50] + "..." if len(value) > 50 else value)
        else:
            display = repr(value)
            if len(display) > 50:
                display = display[:50] + "..."
        part_str = f"{key}={display}"
        if theme:
            part_str = theme.muted_fg(part_str)
        parts.append(part_str)
    if len(display_args) > 3:
        parts.append("...")
    return f"{name_str}({', '.join(parts)})"


def _get_streaming_content_arg(args: dict[str, Any]) -> str | None:
    """Find the primary streaming content arg from tool call args."""
    for name in _STREAMING_CONTENT_ARGS:
        val = args.get(name)
        if isinstance(val, str) and val:
            return val
    best: str | None = None
    best_len = 50
    for val in args.values():
        if isinstance(val, str) and len(val) > best_len:
            best = val
            best_len = len(val)
    return best


def format_tool_output(
    header: str,
    result: dict[str, Any] | None,
    detail_level: DetailLevel,
    theme: Theme | None = None,
    config: ToolRenderConfig | None = None,
) -> str:
    """Format tool output with consistent styling."""
    from ..dtypes import DetailLevel, ToolRenderConfig
    if config is None:
        config = ToolRenderConfig()
    text = header
    if not result:
        return text
    output = get_text_output(result).strip()
    if not output:
        return text
    is_error = result.get("isError", False)
    lines = output.split("\n")

    max_lines = config.get_max_lines(detail_level)
    if max_lines < 0:  # -1 = unlimited
        display_count = len(lines)
    else:
        display_count = min(len(lines), max_lines)
    display_lines = lines[:display_count]
    remaining = len(lines) - display_count

    summary = config.error_summary if is_error else config.success_summary
    if summary:
        text += f"\n⎿ {summary}"
    style_method = None
    if theme and config.style_fn:
        style_method = getattr(theme, config.style_fn, None)
    for line in display_lines:
        gpu_formatted = format_gpu_event_line(line)
        display_line = gpu_formatted if gpu_formatted is not None else line
        if display_line.startswith("[GPU]") and theme and hasattr(theme, "accent_fg"):
            styled_line = theme.accent_fg(display_line)
        elif style_method:
            styled_line = style_method(display_line)
        else:
            styled_line = display_line
        text += f"\n  {styled_line}"
    if remaining > 0:
        hint = f"... ({remaining} more lines)"
        styled_hint = theme.muted_fg(hint) if theme else hint
        text += f"\n  {styled_hint}"
    return text


def format_tool(
    tool_name: str,
    args: dict[str, Any],
    result: dict[str, Any] | None,
    detail_level: DetailLevel,
    theme: Theme | None = None,
    config: ToolRenderConfig | None = None,
) -> str:
    """Format any tool output using config or sensible defaults."""
    from ..dtypes import DetailLevel, ToolRenderConfig
    if config is None:
        config = ToolRenderConfig()

    if config.custom_formatter:
        return config.custom_formatter(tool_name, args, result, detail_level, theme)

    if config.header_fn:
        header = config.header_fn(tool_name, args)
    else:
        header = _default_header(tool_name, args, theme)
    return format_tool_output(header, result, detail_level, theme, config)


def format_streaming_tool(
    tool_name: str,
    args: dict[str, Any],
    detail_level: DetailLevel,
    theme: Theme | None = None,
    config: ToolRenderConfig | None = None,
) -> str:
    """Format a tool call during streaming (before result is received)."""
    from ..dtypes import DetailLevel, ToolRenderConfig

    if config is None:
        config = ToolRenderConfig()

    if config.custom_formatter:
        return config.custom_formatter(tool_name, args, None, detail_level, theme)

    if config.header_fn:
        header = config.header_fn(tool_name, args)
    else:
        header = _default_header(tool_name, args, theme)

    content = _get_streaming_content_arg(args)
    is_multiline = content is not None and "\n" in content
    if not content or not is_multiline:
        return header

    lines = content.split("\n")
    max_lines = max(config.streaming_max_lines, 1)
    display_lines = lines[:max_lines]
    remaining = len(lines) - max_lines

    parts: list[str] = [header]
    for line in display_lines:
        parts.append(f"  {line}")
    if remaining > 0:
        parts.append(f"  ... ({remaining} more lines)")

    return "\n".join(parts)


def shorten_path(path: str) -> str:
    """Convert absolute path to tilde notation if in home directory."""
    import os
    home = os.path.expanduser("~")
    if path.startswith(home):
        return "~" + path[len(home) :]
    return path


def replace_tabs(text: str) -> str:
    """Replace tabs with spaces for consistent rendering."""
    return text.replace("\t", "   ")


def _parse_eval_result(result: dict[str, Any] | None) -> dict[str, Any] | None:
    """Parse eval_task result JSON. Returns dict with metrics, per_config, worst_config or None."""
    if not result:
        return None
    output = get_text_output(result).strip()
    if not output:
        return None
    try:
        return json.loads(output)
    except json.JSONDecodeError:
        return None


def format_eval_tool(
    tool_name: str,
    args: dict[str, Any],
    result: dict[str, Any] | None,
    detail_level: Any,
    theme: Any = None,
) -> str:
    """Custom formatter for eval_task: score badge, metrics, per-config breakdown."""
    task_arg = args.get("task", "")
    task_str = f"task={repr(task_arg)}" if task_arg else ""
    name_str = theme.accent_fg(f"{tool_name}({task_str})") if theme else f"{tool_name}({task_str})"

    if result and result.get("isError"):
        err = get_text_output(result).strip() or "(no details)"
        err_line = theme.error_fg(err) if theme else err
        return f"{name_str}\n  {err_line}"

    data = _parse_eval_result(result)
    if not data or "metrics" not in data:
        return format_tool(tool_name, args, result, detail_level, theme, config=None)

    metrics_arr = data.get("metrics", [])
    metrics_dict: dict[str, float] = {}
    per_config_breakdown: str | None = None
    per_config_list: list[dict[str, Any]] | None = None

    for m in metrics_arr:
        if isinstance(m, dict):
            metrics_dict[m.get("name", "")] = float(m.get("value", 0))
            if m.get("name") == "per_config" and m.get("metadata"):
                meta = m["metadata"]
                per_config_breakdown = meta.get("breakdown")
                per_config_list = meta.get("configs")

    if data.get("per_config"):
        per_config_list = data["per_config"]
    if data.get("worst_config") and not per_config_breakdown:
        w = data["worst_config"]
        per_config_breakdown = f"WORST: M={w.get('M')} N={w.get('N')} ratio={w.get('ratio', 0):.4f}x"

    score_val = metrics_dict.get("score") or metrics_dict.get("worst_ratio") or 0.0
    if theme:
        score_str = (
            theme.accent_fg(f"{score_val:.4f}")
            if score_val >= 1.0
            else theme.warning_fg(f"{score_val:.4f}")
            if score_val >= 0.5
            else theme.error_fg(f"{score_val:.4f}")
        )
    else:
        score_str = f"{score_val:.4f}"

    lines = [f"{name_str}", f"  Score: {score_str}"]
    metric_keys = [k for k in ("correct", "avg_ratio", "worst_ratio", "score") if metrics_dict.get(k) is not None]
    for i, key in enumerate(metric_keys):
        v = metrics_dict[key]
        weight_note = " (weight=1.0)" if key == "score" else ""
        prefix = "└─" if i == len(metric_keys) - 1 else "├─"
        lines.append(f"  {prefix} {key:<12} {v:.4f}{weight_note}")

    if per_config_breakdown or per_config_list:
        lines.append("  Per-config:")
        if per_config_list:
            for cfg in per_config_list:
                ratio = cfg.get("ratio", 0)
                tag = "[OK]  " if ratio >= 1.0 else "[SLOW]"
                if theme:
                    tag = theme.accent_fg(tag) if ratio >= 1.0 else theme.error_fg(tag)
                m_val = cfg.get("M", 0)
                n_val = cfg.get("N", 0)
                custom_ms = cfg.get("custom_ms")
                pytorch_ms = cfg.get("pytorch_ms")
                timing = ""
                if custom_ms is not None and pytorch_ms is not None:
                    timing = f"  custom={custom_ms:.4f}ms pytorch={pytorch_ms:.4f}ms"
                lines.append(f"    {tag} M={m_val:>6} N={n_val:>6}  {ratio:.4f}x{timing}")
        elif per_config_breakdown:
            for bline in per_config_breakdown.split("\n"):
                lines.append(f"    {bline}")

    return "\n".join(lines)
