"""Modal image builders and secret helpers for CLI agent sandbox execution.

Shared between the wafer-api (cloud agent endpoint) and the eval harness
(run_cli_agent with use_modal=True). Kept in wafer-ai so the eval harness
can use it without depending on wafer-api.
"""

from __future__ import annotations

import os
import sys
import logging
from pathlib import Path
from typing import Literal

import modal

logger = logging.getLogger(__name__)

AgentName = Literal["wafer"]

_MODAL_SUPPORTED_PYTHON = {"3.9", "3.10", "3.11", "3.12", "3.13"}


def _get_local_python_version() -> str:
    major, minor = sys.version_info[:2]
    version = f"{major}.{minor}"
    assert version in _MODAL_SUPPORTED_PYTHON, f"Python {version} not supported by Modal. Supported: {_MODAL_SUPPORTED_PYTHON}"
    return version


def _build_wafer_image() -> modal.Image:
    image = (
        modal.Image
        .debian_slim(python_version=_get_local_python_version())
        .apt_install("git", "bash", "curl", "build-essential")
    )
    current = Path(__file__).resolve()
    pkg_root = current.parent.parent.parent.parent
    assert (pkg_root / "pyproject.toml").exists(), f"Expected wafer-ai root at {pkg_root}"
    remote_path = "/root/wafer"
    image = image.add_local_dir(local_path=pkg_root, remote_path=remote_path, copy=True)
    return image.uv_pip_install(remote_path)


_IMAGE_BUILDERS: dict[AgentName, callable] = {
    "wafer": _build_wafer_image,
}


def build_agent_image(agent: AgentName) -> modal.Image:
    builder = _IMAGE_BUILDERS.get(agent)
    assert builder is not None, f"Unknown agent: {agent}"
    return builder()


def get_agent_secrets(
    agent: AgentName,
    *,
    user_token: str | None = None,
    api_url: str | None = None,
) -> modal.Secret:
    assert agent == "wafer", f"Only agent='wafer' is supported. Got: {agent!r}"
    token = user_token or os.environ.get("WAFER_AUTH_TOKEN")
    url = api_url or os.environ.get("WAFER_API_URL", "https://www.api.wafer.ai")
    assert token, "WAFER_AUTH_TOKEN or user_token required for wafer agent"
    secrets: dict[str, str] = {
        "WAFER_API_URL": url,
        "WAFER_AUTH_TOKEN": token,
    }
    for key in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY"):
        val = os.environ.get(key)
        if val:
            secrets[key] = val
    return modal.Secret.from_dict(secrets)
