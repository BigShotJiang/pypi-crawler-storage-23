"""Wafer AI environment with minimal toolset for code editing tasks.
Tools: read, write, edit, glob, grep, bash, skill, eval_task, subagent, pull_session_files
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import trio

from wafer.core.rollouts.dtypes import (
    AgentState,
    Message,
    RunConfig,
    Tool,
    ToolCall,
    ToolRenderConfig,
    ToolResult,
)
from wafer.core.rollouts.environments._formatting import format_eval_tool
from wafer.core.tools import (
    BASH_TOOL,
    EDIT_TOOL,
    EVAL_TOOL,
    GLOB_TOOL,
    GREP_TOOL,
    PULL_SESSION_FILES_TOOL,
    READ_TOOL,
    SKILL_TOOL,
    SUBAGENT_TOOL,
    WRITE_TOOL,
    ApprovalCallback,
    exec_bash,
    exec_edit,
    exec_eval,
    exec_glob,
    exec_grep,
    exec_pull_session_files,
    exec_read,
    exec_skill,
    exec_subagent,
    exec_write,
)


def _shorten_path(path: str) -> str:
    """Convert absolute path to tilde notation if in home directory."""
    home = os.path.expanduser("~")
    if path.startswith(home):
        return "~" + path[len(home) :]
    return path


ALL_TOOLS = {
    "read": READ_TOOL,
    "write": WRITE_TOOL,
    "edit": EDIT_TOOL,
    "glob": GLOB_TOOL,
    "grep": GREP_TOOL,
    "bash": BASH_TOOL,
    "skill": SKILL_TOOL,
    "eval_task": EVAL_TOOL,
    "subagent": SUBAGENT_TOOL,
    "pull_session_files": PULL_SESSION_FILES_TOOL,
}


@dataclass
class CodingEnvironment:
    """Local filesystem environment with read, write, edit, glob, grep, bash tools."""

    working_dir: Path = field(default_factory=Path.cwd)
    allowed_paths: list[Path] | None = None
    enabled_tools: list[str] | None = None
    bash_allowlist: list[str] | None = None
    bash_denylist: list[str] | None = None
    bash_approval_callback: ApprovalCallback | None = None
    bash_default_timeout: int = 180
    target_name: str | None = None
    gpu_type: str | None = None
    confirm_tools: list[str] | None = None

    def __post_init__(self) -> None:
        if self.enabled_tools is not None:
            valid_tools = set(ALL_TOOLS.keys())
            unknown = set(self.enabled_tools) - valid_tools
            if unknown:
                raise ValueError(
                    f"Unknown tools: {sorted(unknown)}. Available: {sorted(valid_tools)}"
                )

    def get_name(self) -> str:
        return "coding"

    def get_status_info(self) -> dict[str, str] | None:
        info: dict[str, str] = {}
        if self.target_name:
            info["target"] = self.target_name
        if self.gpu_type:
            info["accelerator"] = self.gpu_type
        return info or None

    async def serialize(self) -> dict:
        d: dict = {
            "working_dir": str(self.working_dir),
            "allowed_paths": [str(p) for p in self.allowed_paths] if self.allowed_paths else None,
            "enabled_tools": self.enabled_tools,
            "bash_allowlist": self.bash_allowlist,
            "bash_denylist": self.bash_denylist,
            "target_name": self.target_name,
            "gpu_type": self.gpu_type,
        }
        if self.confirm_tools is not None:
            d["confirm_tools"] = self.confirm_tools
        return d

    @staticmethod
    async def deserialize(data: dict) -> CodingEnvironment:
        allowed = data.get("allowed_paths")
        return CodingEnvironment(
            working_dir=Path(data["working_dir"]),
            allowed_paths=[Path(p) for p in allowed] if allowed else None,
            enabled_tools=data.get("enabled_tools"),
            bash_allowlist=data.get("bash_allowlist"),
            bash_denylist=data.get("bash_denylist"),
            target_name=data.get("target_name"),
            gpu_type=data.get("gpu_type"),
            confirm_tools=data.get("confirm_tools"),
        )

    async def close(self) -> None:
        """No-op — sandbox lifecycle is managed by wafer sandbox create/destroy."""

    def requires_confirmation(self, tool_call: ToolCall) -> bool:
        if self.confirm_tools is not None:
            return tool_call.name in self.confirm_tools
        return tool_call.name == "bash"

    def get_tools(self) -> list[Tool]:
        if self.enabled_tools is None:
            return list(ALL_TOOLS.values())
        return [ALL_TOOLS[name] for name in self.enabled_tools if name in ALL_TOOLS]

    def get_tool_render_config(self, tool_name: str) -> ToolRenderConfig | None:
        if tool_name == "eval_task":
            return ToolRenderConfig(custom_formatter=format_eval_tool)
        if tool_name == "subagent":
            def _subagent_header(name: str, args: dict[str, Any]) -> str:
                config = args.get("config", "?")
                label = config if isinstance(config, str) else "inline"
                return f"{name}(config={label!r})"
            return ToolRenderConfig(header_fn=_subagent_header)
        return None

    async def on_assistant_message(self, message: Message, state: AgentState) -> AgentState:
        return state

    async def exec_tool(
        self,
        tool_call: ToolCall,
        current_state: AgentState,
        run_config: RunConfig,
        cancel_scope: trio.CancelScope | None = None,
    ) -> ToolResult:
        if self.enabled_tools is not None and tool_call.name not in self.enabled_tools:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Tool '{tool_call.name}' is not enabled. Enabled tools: {', '.join(self.enabled_tools)}",
            )
        handlers = {
            "read": lambda tc: exec_read(tc, self.working_dir),
            "write": lambda tc: exec_write(tc, self.working_dir),
            "edit": lambda tc: exec_edit(tc, self.working_dir),
            "glob": lambda tc: exec_glob(tc, self.working_dir),
            "grep": lambda tc: exec_grep(tc, self.working_dir),
            "bash": lambda tc: exec_bash(
                tc,
                self.working_dir,
                cancel_scope,
                self.bash_allowlist,
                self.bash_denylist,
                self.bash_approval_callback,
                self.bash_default_timeout,
            ),
            "skill": lambda tc: exec_skill(tc),
            "eval_task": lambda tc: exec_eval(tc, self.working_dir),
            "subagent": lambda tc: exec_subagent(
                tc,
                on_output=lambda delta: run_config.on_chunk(delta),
                api_url=os.environ.get("WAFER_API_URL"),
                auth_token=os.environ.get("WAFER_AUTH_TOKEN"),
            ),
            "pull_session_files": lambda tc: exec_pull_session_files(
                tc,
                self.working_dir,
                api_url=os.environ.get("WAFER_API_URL"),
                auth_token=os.environ.get("WAFER_AUTH_TOKEN"),
            ),
        }
        handler = handlers.get(tool_call.name)
        if handler is None:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Unknown tool: {tool_call.name}",
            )
        try:
            return await handler(tool_call)
        except Exception as e:
            return ToolResult(tool_call_id=tool_call.id, is_error=True, content="", error=str(e))


WaferAiEnvironment = CodingEnvironment
