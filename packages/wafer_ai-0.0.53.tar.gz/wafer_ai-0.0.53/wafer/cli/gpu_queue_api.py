"""GPU queue API client — machine-level lock via Supabase RPCs.

A sandbox occupies all GPUs on a target. Only one active sandbox per target.
The queue serializes sandbox creation: if the machine is busy, new requests
are queued and promoted when the current sandbox releases.

RPCs (to be created in Supabase):
- acquire_or_enqueue: lock the machine or queue if busy
- poll_queue_entry: extend TTL, check if promoted
- release_and_promote: release machine, promote next in queue
"""
from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)


async def acquire_or_enqueue(
    *, target_id: str, session_id: str, ttl_seconds: int = 180,
) -> dict[str, Any]:
    """Attempt to acquire machine-level lock. Returns status and queue_id.

    Returns:
        {"status": "active", "queue_id": "..."} if lock acquired
        {"status": "queued", "queue_id": "...", "position": N} if queued
    """
    from wafer.cli.sandboxes_api import _get_sb_headers

    import httpx

    sb_url, headers = _get_sb_headers()
    resp = httpx.post(
        f"{sb_url}/rest/v1/rpc/acquire_or_enqueue",
        headers=headers,
        json={
            "p_target_id": target_id,
            "p_session_id": session_id,
            "p_ttl_seconds": ttl_seconds,
        },
        timeout=10,
    )
    if resp.status_code != 200:
        logger.warning("acquire_or_enqueue failed: %s %s", resp.status_code, resp.text)
        return {"status": "active", "queue_id": session_id}
    return resp.json()


async def poll_queue_entry(queue_id: str) -> dict[str, Any]:
    """Extend TTL and check if promoted from queued to active."""
    from wafer.cli.sandboxes_api import _get_sb_headers

    import httpx

    sb_url, headers = _get_sb_headers()
    resp = httpx.post(
        f"{sb_url}/rest/v1/rpc/poll_queue_entry",
        headers=headers,
        json={"p_queue_id": queue_id},
        timeout=10,
    )
    if resp.status_code != 200:
        logger.warning("poll_queue_entry failed: %s %s", resp.status_code, resp.text)
        return {"status": "active", "queue_id": queue_id}
    return resp.json()


async def release_and_promote(queue_id: str) -> bool:
    """Release machine lock and promote next queued entry."""
    from wafer.cli.sandboxes_api import _get_sb_headers

    import httpx

    sb_url, headers = _get_sb_headers()
    resp = httpx.post(
        f"{sb_url}/rest/v1/rpc/release_and_promote",
        headers=headers,
        json={"p_queue_id": queue_id},
        timeout=10,
    )
    if resp.status_code != 200:
        logger.warning("release_and_promote failed: %s %s", resp.status_code, resp.text)
        return False
    return True
