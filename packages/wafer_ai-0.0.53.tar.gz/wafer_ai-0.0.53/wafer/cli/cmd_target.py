# ruff: noqa: PLR0913, E402
"""Target management commands: create, manage, and sync code on GPU targets.

Subgroups:
  wafer target init   Initialize new targets (SSH, workspace)
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING, Any

import typer

if TYPE_CHECKING:
    from .targets_ops import TargetSSHInfo

from .target_resolve import resolve_target_type


def complete_target_name(incomplete: str) -> list[str]:
    """Autocomplete target names from API."""
    try:
        from .targets import list_targets
        return [n for n in list_targets() if n.startswith(incomplete)]
    except (ImportError, RuntimeError, OSError):
        return []


target_app = typer.Typer(
    name="target",
    help="Set up and manage connections to GPU machines",
    no_args_is_help=True,
)
init_app = typer.Typer(
    help="Initialize a new accelerator target"
)

target_app.add_typer(init_app, name="init")


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_KNOWN_GPU_TYPES = [
    "B200", "B100", "H200", "H100", "A100", "A10", "V100",
    "RTX 5090", "RTX 5080", "RTX 4090", "RTX 4080", "RTX 3090", "RTX 3080",
    "MI300X", "MI250X", "MI100",
    "Trainium3", "Trainium2", "Trainium", "Trn3", "Trn2", "Trn1",
    "TPUv5", "TPUv4", "TPU",
]

_GFX_TO_GPU_TYPE: dict[str, str] = {
    "gfx942": "MI300X",
    "gfx941": "MI300X",
    "gfx940": "MI300X",
    "gfx950": "MI350X",
    "gfx90a": "MI250X",
    "gfx908": "MI100",
}

_KNOWN_ACCELERATOR_TYPES = ("nvidia", "amd", "trainium", "tpu", "other")

_AMD_GPU_TYPES = frozenset({"MI300X", "MI250X", "MI100", "MI350X"})
_TRAINIUM_GPU_TYPES = frozenset({"TRAINIUM", "TRAINIUM2", "TRAINIUM3", "TRN1", "TRN2", "TRN3"})
_NVIDIA_GPU_TYPES = frozenset({
    "B200", "B100", "H200", "H100", "A100", "A10", "V100",
    "RTX 5090", "RTX 5080", "RTX 4090", "RTX 4080", "RTX 3090", "RTX 3080",
})
_SUPPORTED_GPU_TYPES_FOR_LOCK = _NVIDIA_GPU_TYPES | _AMD_GPU_TYPES | _TRAINIUM_GPU_TYPES

_SSH_KEY_CANDIDATES = ("id_ed25519", "id_ecdsa", "id_rsa")


# ---------------------------------------------------------------------------
# Shared tiny helpers (defined locally to avoid coupling back to app.py)
# ---------------------------------------------------------------------------

def _exit_with_error(msg: str) -> None:
    """Print error to stderr and exit with code 1."""
    typer.echo(f"Error: {msg}", err=True)
    raise typer.Exit(1) from None


def _resolve_show_status(quiet: bool, verbose: bool) -> bool:
    """Resolve show_status from quiet/verbose flags and user preferences."""
    if quiet:
        return False
    if verbose:
        return True
    from .global_config import get_preferences
    return get_preferences().mode == "explicit"


def _make_progress_callback(show_status: bool):  # noqa: ANN201
    """Create a progress callback that prints to stderr when show_status is True."""
    from collections.abc import Callable
    def on_progress(msg: str) -> None:
        if show_status:
            typer.echo(f"[wafer] {msg}", err=True)
    return on_progress


# ---------------------------------------------------------------------------
# SSH / GPU detection helpers
# ---------------------------------------------------------------------------

def _ssh_detect_gpu(host: str, ssh_key: str) -> tuple[Any, str | None, str | None]:
    assert isinstance(host, str) and host, "host must be a non-empty string"
    assert isinstance(ssh_key, str) and ssh_key, "ssh_key must be a non-empty string"

    typer.echo(f"Connecting to {host}...")
    detected_gpu, torch_package, torch_index_url = None, None, None
    try:
        import trio
        import trio_asyncio

        from wafer.core.async_ssh import AsyncSSHClient
        from wafer.core.gpu_detect import detect_remote_gpu, get_torch_requirements

        expanded_key = str(Path(ssh_key).expanduser())

        async def _detect() -> None:
            nonlocal detected_gpu, torch_package, torch_index_url
            async with trio_asyncio.open_loop():
                async with AsyncSSHClient(host, expanded_key) as client:
                    detected_gpu = await detect_remote_gpu(client)

        trio.run(_detect)
        if detected_gpu:
            typer.echo(f"  Found: {detected_gpu.gpu_name}")
            if detected_gpu.vendor == "nvidia":
                typer.echo(f"  CUDA: {detected_gpu.driver_version}")
            else:
                typer.echo(f"  ROCm: {detected_gpu.driver_version}")
            torch_reqs = get_torch_requirements(detected_gpu)
            torch_package = torch_reqs.packages[0]
            torch_index_url = torch_reqs.index_url
            typer.echo(f"  PyTorch: {torch_package}")
        else:
            typer.echo("  No GPU detected (nvidia-smi/rocm-smi not found)")
    except Exception as e:
        typer.echo(f"  Detection failed: {e}", err=True)
    return detected_gpu, torch_package, torch_index_url


def _ssh_compute_capability(detected_gpu: Any, gpu_type: str) -> str:
    assert isinstance(gpu_type, str) and gpu_type, "gpu_type must be a non-empty string"
    assert detected_gpu is None or hasattr(detected_gpu, "vendor"), "detected_gpu must have vendor attribute or be None"

    if detected_gpu:
        from wafer.core.gpu_detect import get_compute_capability
        return get_compute_capability(detected_gpu)
    gpu_upper = gpu_type.upper()
    if "TRAINIUM" in gpu_upper or "TRN1" in gpu_upper or "TRN2" in gpu_upper:
        return "0.0"
    if "TPU" in gpu_upper:
        return "0.0"
    compute_caps = {
        "B200": "10.0", "H100": "9.0", "A100": "8.0", "A10": "8.6",
        "V100": "7.0", "MI300X": "9.4", "MI250X": "9.0",
        "RTX 5090": "10.0", "RTX 4090": "8.9", "RTX 3090": "8.6",
    }
    return compute_caps.get(gpu_type, "8.0")


def _print_ssh_target_summary(
    target: Any, host: str, gpu_ids: list[int], gpu_type: str,
    compute_capability: str, ncu: bool, docker_image: str | None,
    torch_package: str | None, name: str,
) -> None:
    assert isinstance(name, str) and name, "name must be a non-empty string"
    assert isinstance(host, str) and host, "host must be a non-empty string"

    typer.echo(f"\u2713 Created target: {target.name}")
    typer.echo("  Type: Baremetal (SSH)")
    typer.echo(f"  Host: {host}")
    typer.echo(f"  GPU IDs: {gpu_ids}")
    typer.echo(f"  GPU Type: {gpu_type}")
    typer.echo(f"  Compute: {compute_capability}")
    typer.echo(f"  NCU: {'Yes' if ncu else 'No'}")
    if docker_image:
        typer.echo(f"  Docker: {docker_image}")
    if torch_package:
        typer.echo(f"  Torch: {torch_package}")
    typer.echo("")
    typer.echo(
        f"Usage: wafer sandbox run --target {name} -- wafer tool eval --task kernelbench"
    )


def _detect_ssh_key() -> str:
    """Auto-detect an SSH private key from ~/.ssh/."""
    ssh_dir = Path.home() / ".ssh"
    for candidate in _SSH_KEY_CANDIDATES:
        path = ssh_dir / candidate
        if path.exists():
            return str(path)
    typer.echo("Error: No SSH key found in ~/.ssh/. Provide --ssh-key explicitly.", err=True)
    raise typer.Exit(1)


# ---------------------------------------------------------------------------
# GPU type / device helpers
# ---------------------------------------------------------------------------

def _gpu_visible_devices_var(gpu_type: str | None) -> str:
    """Return the env var that controls GPU/accelerator visibility for the given type."""
    if gpu_type and gpu_type.upper() in _AMD_GPU_TYPES:
        return "HIP_VISIBLE_DEVICES"
    if gpu_type and gpu_type.upper() in _TRAINIUM_GPU_TYPES:
        return "NEURON_RT_VISIBLE_CORES"
    return "CUDA_VISIBLE_DEVICES"


def _format_device_ids(gpu_type: str | None, gpu_ids: list[int]) -> str:
    """Format device IDs for the visibility env var.

    Trainium (NEURON_RT_VISIBLE_CORES) requires range notation like '0-3'.
    NVIDIA/AMD use comma-separated like '0,1,2,3'.
    """
    assert gpu_ids, "gpu_ids must be non-empty"
    if gpu_type and gpu_type.upper() in _TRAINIUM_GPU_TYPES:
        sorted_ids = sorted(gpu_ids)
        if len(sorted_ids) == 1:
            return str(sorted_ids[0])
        assert sorted_ids == list(range(sorted_ids[0], sorted_ids[-1] + 1)), \
            f"Trainium requires contiguous core range, got {sorted_ids}"
        return f"{sorted_ids[0]}-{sorted_ids[-1]}"
    return ",".join(str(g) for g in gpu_ids)


def _extract_gpu_type(gpu_name: str) -> str:
    """Extract GPU type from full GPU name.
    Examples:
        "NVIDIA H100 80GB HBM3" -> "H100"
        "NVIDIA GeForce RTX 4090" -> "RTX 4090"
        "AMD Instinct MI300X OAM" -> "MI300X"
        "GFX Version: \t\tgfx942" -> "MI300X"
    """
    assert gpu_name, "GPU name must be non-empty"
    match = re.search(r"gfx\d{2,3}[a-z]?", gpu_name.lower())
    if match:
        gfx_id = match.group(0)
        resolved = _GFX_TO_GPU_TYPE.get(gfx_id)
        if resolved:
            return resolved
    gpu_name_upper = gpu_name.upper()
    for gpu_type in _KNOWN_GPU_TYPES:
        if gpu_type in gpu_name_upper:
            return gpu_type
    return gpu_name.replace("NVIDIA ", "").replace("AMD ", "").strip()


# ---------------------------------------------------------------------------
# SSH credential helpers
# ---------------------------------------------------------------------------

def _get_workspace_ssh_creds(ws_data: dict) -> tuple[str, int, str]:
    """Extract and validate SSH credentials from workspace data.

    Returns (host, port, user). Exits if workspace not ready.
    """
    ssh_host = ws_data.get("ssh_host")
    ssh_port = ws_data.get("ssh_port")
    ssh_user = ws_data.get("ssh_user")
    if not ssh_host:
        _exit_with_error("Workspace SSH host not available yet. Wait a few seconds and retry.")
    if not ssh_port:
        _exit_with_error("Workspace SSH port not available yet. Wait a few seconds and retry.")
    if not ssh_user:
        _exit_with_error("Workspace SSH user not available yet. Wait a few seconds and retry.")
    assert ssh_host and ssh_port and ssh_user
    return ssh_host, int(ssh_port), ssh_user


def _build_workspace_ssh_args(host: str, port: int, user: str) -> list[str]:
    """Build SSH command args for a workspace connection."""
    return [
        "ssh",
        "-p", str(port),
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        f"{user}@{host}",
    ]


def _build_host_ssh_args(ssh_info: "TargetSSHInfo") -> list[str]:
    """Build SSH command args for a host target connection."""
    return [
        "ssh",
        "-i", str(ssh_info.key_path),
        "-p", str(ssh_info.port),
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        f"{ssh_info.user}@{ssh_info.host}",
    ]


# ---------------------------------------------------------------------------
# List formatting helpers
# ---------------------------------------------------------------------------

def _format_workspace_list_item(ws: dict) -> tuple[str, dict]:
    """Format a workspace for list display. Returns (line, json_item)."""
    from .targets import get_default_target
    default = get_default_target()
    status = ws.get("status", "unknown")
    status_icon = {"running": "\u25cf", "creating": "\u25d0", "error": "\u2717"}.get(status, "?")
    gpu = ws.get("gpu_type", "N/A")
    marker = " *" if ws["name"] == default else ""
    line = f"  {status_icon} {(ws['name'] + marker):<22} {gpu:<10} workspace   {status}"
    json_item = {
        "name": ws["name"],
        "type": "workspace",
        "gpu_type": gpu,
        "status": status,
        "id": ws.get("id"),
        "default": ws["name"] == default,
    }
    return line, json_item


def _list_workspace_items(sync: bool) -> tuple[list[str], list[dict]]:
    """Fetch workspaces and format for display. Returns (lines, json_items)."""
    lines: list[str] = []
    json_items: list[dict] = []
    try:
        import httpx
    except ImportError:
        return lines, json_items
    try:
        from .workspaces import _get_client
        api_url, headers = _get_client()
        params = {"sync_status": "true"} if sync else {}
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.get(f"{api_url}/v1/workspaces", params=params)
            response.raise_for_status()
            workspaces = response.json()
        assert isinstance(workspaces, list), "API must return a list"
        for ws in workspaces:
            line, item = _format_workspace_list_item(ws)
            lines.append(line)
            json_items.append(item)
    except (RuntimeError, Exception):
        pass
    return lines, json_items


def _list_host_items() -> tuple[list[str], list[dict]]:
    """Load local host targets and format for display. Returns (lines, json_items)."""
    from .targets import get_default_target, list_targets, load_target
    lines: list[str] = []
    json_items: list[dict] = []
    default = get_default_target()
    for name in list_targets():
        try:
            t = load_target(name)
            ttype = type(t).__name__.replace("Target", "").lower()
            gpu = t.gpu_type
            marker = " *" if name == default else ""
            lines.append(f"    {(name + marker):<22} {gpu:<10} {ttype}")
            json_items.append({
                "name": name, "type": ttype, "gpu_type": gpu, "default": name == default,
            })
        except (FileNotFoundError, ValueError, TypeError):
            lines.append(f"    {name:<20} {'?':<10} error")
    return lines, json_items


# ---------------------------------------------------------------------------
# Show helpers
# ---------------------------------------------------------------------------

def _show_workspace(name: str, json_output: bool) -> None:
    from .workspaces import get_workspace
    try:
        result = get_workspace(name, json_output=json_output)
        typer.echo(result)
    except RuntimeError as e:
        _exit_with_error(str(e))


def _show_host(name: str, json_output: bool) -> None:
    from .targets import get_target_info, load_target
    try:
        target = load_target(name)
    except FileNotFoundError as e:
        _exit_with_error(str(e))

    info = get_target_info(target)
    if json_output:
        from .output import json_response
        typer.echo(json_response(data={"name": name, **info}))
    else:
        typer.echo(f"Target: {name}")
        for key, value in info.items():
            typer.echo(f"  {key}: {value}")


# ===========================================================================
# init_app commands – helpers
# ===========================================================================


def _bootstrap_wafer_key(
    *,
    user_ssh_key: str,
    ssh_user: str,
    ssh_host: str,
    ssh_port: int,
    wafer_public_key: str,
) -> bool:
    """Install wafer public key on target via user's existing SSH key. Returns True on success."""
    import subprocess

    escaped_key = wafer_public_key.replace("'", "'\\''")
    install_cmd = (
        f"mkdir -p ~/.ssh && chmod 700 ~/.ssh && "
        f"(grep -qF '{escaped_key}' ~/.ssh/authorized_keys 2>/dev/null || "
        f"echo '{escaped_key}' >> ~/.ssh/authorized_keys) && "
        f"chmod 600 ~/.ssh/authorized_keys"
    )
    try:
        result = subprocess.run(
            [
                "ssh",
                "-o", "StrictHostKeyChecking=no",
                "-o", "UserKnownHostsFile=/dev/null",
                "-o", "ConnectTimeout=10",
                "-i", user_ssh_key,
                "-p", str(ssh_port),
                f"{ssh_user}@{ssh_host}",
                install_cmd,
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            typer.echo("  Wafer key installed on target.", err=True)
            return True
        typer.echo(f"  Failed to install key (exit {result.returncode}): {result.stderr.strip()}", err=True)
        typer.echo("  You can install manually with the setup command above.", err=True)
        return False
    except subprocess.TimeoutExpired:
        typer.echo("  SSH timed out. Check connectivity and try: wafer target verify", err=True)
        return False


def _verify_wafer_key(
    *,
    wafer_key_path: str,
    ssh_user: str,
    ssh_host: str,
    ssh_port: int,
    target_name: str,
) -> bool:
    """Verify SSH connectivity using the wafer key. Returns True on success."""
    import subprocess

    typer.echo("  Verifying wafer key connectivity...", err=True)
    try:
        result = subprocess.run(
            [
                "ssh",
                "-o", "StrictHostKeyChecking=no",
                "-o", "UserKnownHostsFile=/dev/null",
                "-o", "ConnectTimeout=10",
                "-i", wafer_key_path,
                "-p", str(ssh_port),
                f"{ssh_user}@{ssh_host}",
                "echo OK",
            ],
            capture_output=True,
            text=True,
            timeout=15,
        )
        if result.returncode == 0 and "OK" in result.stdout:
            typer.echo("  Wafer key verified. Target is active.", err=True)
            return True
        typer.echo(f"  Verification failed (exit {result.returncode}).", err=True)
        typer.echo(f"  Run: wafer target verify {target_name}", err=True)
        return False
    except subprocess.TimeoutExpired:
        typer.echo("  Verification timed out.", err=True)
        typer.echo(f"  Run: wafer target verify {target_name}", err=True)
        return False


def _get_wafer_ai_source_dir() -> Path | None:
    """Locate the wafer-ai package directory if running from a source checkout."""
    pkg_dir = Path(__file__).resolve().parent.parent.parent
    if (pkg_dir / "pyproject.toml").exists() and (pkg_dir / "wafer").is_dir():
        return pkg_dir
    return None


def _is_dev_mode() -> bool:
    """True when running from a git source checkout (not a pip-installed release)."""
    return _get_wafer_ai_source_dir() is not None


def _ssh_cmd_base(wafer_key_path: str, ssh_port: int) -> list[str]:
    return [
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "ConnectTimeout=15",
        "-i", wafer_key_path,
        "-p", str(ssh_port),
    ]


def _bootstrap_wafer_cli(
    *,
    wafer_key_path: str,
    ssh_user: str,
    ssh_host: str,
    ssh_port: int,
    dev: bool | None = None,
) -> bool:
    """Install wafer-ai on a target via SSH.

    dev=None: auto-detect (source checkout -> dev, else prod).
    dev=True: upload local source and uv tool install.
    dev=False: uv tool install wafer-ai from PyPI.
    """
    if dev is None:
        dev = _is_dev_mode()

    if dev:
        return _bootstrap_dev(
            wafer_key_path=wafer_key_path,
            ssh_user=ssh_user, ssh_host=ssh_host, ssh_port=ssh_port,
        )
    return _bootstrap_prod(
        wafer_key_path=wafer_key_path,
        ssh_user=ssh_user, ssh_host=ssh_host, ssh_port=ssh_port,
    )


def _bootstrap_prod(
    *,
    wafer_key_path: str,
    ssh_user: str,
    ssh_host: str,
    ssh_port: int,
) -> bool:
    """Prod bootstrap: install wafer-ai from PyPI via uv tool install."""
    import subprocess

    typer.echo("  Installing wafer-ai from PyPI (prod)...", err=True)
    remote_target = f"{ssh_user}@{ssh_host}"
    ssh_base = _ssh_cmd_base(wafer_key_path, ssh_port)

    install_cmd = (
        'export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH" && '
        "command -v uv >/dev/null 2>&1 || (curl -LsSf https://astral.sh/uv/install.sh | sh) && "
        "uv tool install --force wafer-ai && "
        "wafer --version"
    )
    try:
        result = subprocess.run(
            ["ssh"] + ssh_base + [remote_target, install_cmd],
            capture_output=True, text=True, timeout=300,
        )
        if result.returncode != 0:
            typer.echo(f"  Install failed: {result.stderr.strip()}", err=True)
            return False
        version = result.stdout.strip().split("\n")[-1]
        typer.echo(f"  wafer-ai installed: {version}", err=True)
        return True
    except subprocess.TimeoutExpired:
        typer.echo("  Bootstrap timed out.", err=True)
        return False


def _bootstrap_dev(
    *,
    wafer_key_path: str,
    ssh_user: str,
    ssh_host: str,
    ssh_port: int,
) -> bool:
    """Dev bootstrap: upload local source and uv tool install."""
    import subprocess
    import tarfile
    import tempfile

    src_dir = _get_wafer_ai_source_dir()
    assert src_dir is not None, "Cannot find wafer-ai source directory for dev bootstrap"

    typer.echo("  Packaging wafer-ai from local source (dev)...", err=True)

    with tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False) as tmp:
        tmp_path = Path(tmp.name)

    _EXCLUDE = {
        "__pycache__", ".venv", ".git", ".ruff_cache", ".mypy_cache",
        "*.pyc", "*.egg-info", "dist", ".eggs", "tests", "uv.lock",
    }

    def _filter(info: tarfile.TarInfo) -> tarfile.TarInfo | None:
        name = info.name
        for pat in _EXCLUDE:
            if pat.startswith("*"):
                if name.endswith(pat[1:]):
                    return None
            elif f"/{pat}/" in f"/{name}/" or name == pat or name.endswith(f"/{pat}"):
                return None
        return info

    remote_target = f"{ssh_user}@{ssh_host}"
    ssh_base = _ssh_cmd_base(wafer_key_path, ssh_port)

    try:
        with tarfile.open(tmp_path, "w:gz") as tar:
            tar.add(str(src_dir), arcname="wafer-ai", filter=_filter)

        size_mb = tmp_path.stat().st_size / (1024 * 1024)
        typer.echo(f"  Uploading wafer-ai ({size_mb:.1f}MB)...", err=True)

        scp_result = subprocess.run(
            ["scp", "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=/dev/null",
             "-o", "ConnectTimeout=15", "-i", wafer_key_path,
             "-P", str(ssh_port),
             str(tmp_path), f"{remote_target}:/tmp/wafer-ai-bootstrap.tar.gz"],
            capture_output=True, text=True, timeout=120,
        )
        if scp_result.returncode != 0:
            typer.echo(f"  SCP failed: {scp_result.stderr.strip()}", err=True)
            return False

        typer.echo("  Installing wafer-ai on target...", err=True)
        install_cmd = (
            'export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH" && '
            "command -v uv >/dev/null 2>&1 || (curl -LsSf https://astral.sh/uv/install.sh | sh) && "
            "rm -rf /tmp/wafer-ai-bootstrap && "
            "mkdir -p /tmp/wafer-ai-bootstrap && "
            "tar xzf /tmp/wafer-ai-bootstrap.tar.gz -C /tmp/wafer-ai-bootstrap && "
            "uv tool install --force /tmp/wafer-ai-bootstrap/wafer-ai && "
            "wafer --version"
        )
        install_result = subprocess.run(
            ["ssh"] + ssh_base + [remote_target, install_cmd],
            capture_output=True, text=True, timeout=300,
        )
        if install_result.returncode != 0:
            typer.echo(f"  Install failed: {install_result.stderr.strip()}", err=True)
            return False

        version = install_result.stdout.strip().split("\n")[-1]
        typer.echo(f"  wafer-ai installed: {version}", err=True)
        return True

    except subprocess.TimeoutExpired:
        typer.echo("  Bootstrap timed out.", err=True)
        return False
    finally:
        tmp_path.unlink(missing_ok=True)


# ===========================================================================
# init_app commands
# ===========================================================================

@init_app.command("ssh")
def init_ssh(
    name: str = typer.Option(..., "--name", "-n", help="Target name"),
    host: str = typer.Option(..., "--host", "-H", help="SSH host (user@hostname:port)"),
    ssh_key: str | None = typer.Option(None, "--ssh-key", "-k", help="Path to SSH key (auto-detected if omitted)"),
    gpu_ids: str | None = typer.Option(None, "--gpu-ids", "-g", help="Comma-separated device IDs (auto-detected if omitted)"),
    gpu_type: str | None = typer.Option(
        None, "--gpu-type", help="Accelerator type: B200, MI300X, Trainium, TPU, other (auto-detected if not specified)"
    ),
    vendor: str | None = typer.Option(
        None, "--vendor", "-v", help="Accelerator vendor: nvidia, amd, trainium, tpu, other"
    ),
    docker_image: str | None = typer.Option(
        None, "--docker-image", "-d", help="Docker image (optional)"
    ),
    ncu: bool = typer.Option(False, "--ncu/--no-ncu", help="NCU profiling available"),
    no_detect: bool = typer.Option(False, "--no-detect", help="Skip GPU auto-detection"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Auto-confirm key installation (non-interactive)"),
) -> None:
    """Initialize an SSH target for your own GPU hardware

    Examples:
        wafer target init ssh --name my-gpu --host user@192.168.1.100:22
    """
    from pathlib import Path

    from wafer.core.ssh_utils import parse_ssh_target

    from .user_targets_api import create_target as api_create_target, user_target_to_baremetal_target

    user_provided_gpu_ids: list[int] | None = None
    if gpu_ids is not None:
        try:
            user_provided_gpu_ids = [int(g.strip()) for g in gpu_ids.split(",")]
        except ValueError:
            typer.echo(f"Error: Invalid GPU IDs '{gpu_ids}'. Use comma-separated integers.", err=True)
            raise typer.Exit(1) from None
    try:
        parsed = parse_ssh_target(host)
        ssh_user, ssh_host, ssh_port = parsed.user, parsed.host, parsed.port
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        typer.echo("Example: user@192.168.1.100:22", err=True)
        raise typer.Exit(1) from None
    if ssh_key is None:
        ssh_key = _detect_ssh_key()
        typer.echo(f"  Using SSH key: {ssh_key}")
    ssh_key_path = str(Path(ssh_key).expanduser().resolve())
    detected_gpu, torch_package, torch_index_url = None, None, None
    if not no_detect:
        detected_gpu, torch_package, torch_index_url = _ssh_detect_gpu(host, ssh_key)
        if detected_gpu and not gpu_type:
            gpu_type = _extract_gpu_type(detected_gpu.gpu_name)
        elif not gpu_type:
            gpu_type = "B200"
            typer.echo(f"  Using default: {gpu_type}")
    parsed_gpu_ids = user_provided_gpu_ids
    if parsed_gpu_ids is None:
        if detected_gpu and detected_gpu.gpu_count > 0:
            parsed_gpu_ids = list(range(detected_gpu.gpu_count))
            typer.echo(f"  Detected {detected_gpu.gpu_count} device(s): {parsed_gpu_ids}")
        else:
            parsed_gpu_ids = [0]
    if not gpu_type:
        gpu_type = "B200"
    compute_capability = _ssh_compute_capability(detected_gpu, gpu_type)
    if vendor is not None and vendor not in _KNOWN_ACCELERATOR_TYPES:
        typer.echo(f"Error: vendor must be one of {_KNOWN_ACCELERATOR_TYPES}", err=True)
        raise typer.Exit(1)
    try:
        resp = api_create_target(
            name=name,
            ssh_host=ssh_host,
            ssh_user=ssh_user,
            ssh_port=ssh_port,
            gpu_type=gpu_type,
            gpu_ids=parsed_gpu_ids,
        )
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        typer.echo("Run: wafer login", err=True)
        raise typer.Exit(1) from None
    except (ValueError, AssertionError) as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    keys_dir = Path.home() / ".wafer" / "keys"
    if resp.get("private_key"):
        keys_dir.mkdir(parents=True, exist_ok=True)
        key_path = keys_dir / name
        key_path.write_text(resp["private_key"])
        key_path.chmod(0o600)
    target = user_target_to_baremetal_target(resp["target"])
    public_key = resp.get("public_key")
    if public_key:
        typer.echo(f"\n  Wafer public key: {resp.get('fingerprint', '')}", err=True)
        if yes or typer.confirm("  Install wafer key on target now?", default=True):
            _bootstrap_wafer_key(
                user_ssh_key=ssh_key_path,
                ssh_user=ssh_user,
                ssh_host=ssh_host,
                ssh_port=ssh_port,
                wafer_public_key=public_key,
            )
            _verify_wafer_key(
                wafer_key_path=str(keys_dir / name),
                ssh_user=ssh_user,
                ssh_host=ssh_host,
                ssh_port=ssh_port,
                target_name=name,
            )
            typer.echo("\n  Bootstrapping wafer-ai on target...", err=True)
            _bootstrap_wafer_cli(
                wafer_key_path=str(keys_dir / name),
                ssh_user=ssh_user,
                ssh_host=ssh_host,
                ssh_port=ssh_port,
            )
        else:
            typer.echo(f"\n  Run manually:\n  {resp.get('setup_command', '')}", err=True)
    _print_ssh_target_summary(
        target, host, parsed_gpu_ids, gpu_type, compute_capability, ncu,
        docker_image, torch_package, name,
    )


@init_app.command("workspace")
def init_workspace(
    name: str = typer.Argument(..., help="Workspace name"),
    gpu_type: str = typer.Option(
        "B200", "--gpu", "-g",
        help="Accelerator type: B200, MI300X, Trainium, TPU (default: B200). Backend may not support all.",
    ),
    environment_type: str = typer.Option("baremetal", "--env", "-e", help="Environment type"),
    image: str | None = typer.Option(None, "--image", "-i", help="Docker image"),
    wait: bool = typer.Option(False, "--wait", "-w", help="Wait for provisioning"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Create a cloud GPU workspace

    Examples:
        wafer target init workspace dev
        wafer target init workspace dev --gpu MI300X
    """
    from .workspaces import create_workspace
    assert name, "Workspace name must be non-empty"
    try:
        result = create_workspace(
            name,
            gpu_type=gpu_type,
            environment_type=environment_type,
            image=image,
            wait=wait,
            json_output=json_output,
        )
        typer.echo(result)
    except RuntimeError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


# ===========================================================================
# target_app commands
# ===========================================================================

@target_app.command("bootstrap")
def target_bootstrap(
    name: str = typer.Argument(..., help="Target name"),
    dev: bool = typer.Option(False, "--dev", help="Force dev mode: upload local source"),
    prod: bool = typer.Option(False, "--prod", help="Force prod mode: install from PyPI via uv"),
) -> None:
    """Install/update wafer-ai on a target.

    Auto-detects dev vs prod mode. Dev mode uploads local source.
    Prod mode installs from PyPI via uv tool install.

    Examples:
        wafer target bootstrap b200-node          # auto-detect
        wafer target bootstrap b200-node --dev     # force local source
        wafer target bootstrap b200-node --prod    # force PyPI
    """
    from .user_targets_api import get_target_by_name

    assert not (dev and prod), "--dev and --prod are mutually exclusive"

    target = get_target_by_name(name)
    assert target is not None, f"Target '{name}' not found. Run: wafer target list"
    key_path = Path.home() / ".wafer" / "keys" / name
    assert key_path.exists(), (
        f"Wafer key not found at {key_path}. Run: wafer target init ssh --name {name} ..."
    )

    mode: bool | None = None
    if dev:
        mode = True
    elif prod:
        mode = False

    ok = _bootstrap_wafer_cli(
        wafer_key_path=str(key_path),
        ssh_user=target["ssh_user"],
        ssh_host=target["ssh_host"],
        ssh_port=target["ssh_port"],
        dev=mode,
    )
    if not ok:
        raise typer.Exit(1)


@target_app.command("verify")
def target_verify(
    name: str = typer.Argument(..., help="Target name"),
    cloud: bool = typer.Option(False, "--cloud", help="Verify from cloud (Modal)"),
) -> None:
    """Verify target connectivity"""
    if cloud:
        from .user_targets_api import verify_target
        result = verify_target(name, from_cloud=True)
        ok = result.get("ok", False)
        res = result.get("result", {})
        if ok:
            typer.echo("  SSH: OK")
            for k, v in res.items():
                if k != "ok" and v is not None:
                    typer.echo(f"  {k}: {v}")
            typer.echo(f"  Target '{name}' is active.")
        else:
            typer.echo("  SSH: FAILED")
            typer.echo(f"  Error: {res.get('error', 'unknown')}")
            raise typer.Exit(1)
        return

    from .targets import load_target
    from .targets_ops import TargetExecError, exec_on_target_sync, get_target_ssh_info

    import trio

    try:
        target = load_target(name)
        ssh_info = trio.run(get_target_ssh_info, target)
        vendor = getattr(target, "vendor", None) or ""
        if vendor == "amd":
            probe_cmd = "rocm-smi --showproductname 2>/dev/null && uname -r"
        elif vendor in ("trainium", "tpu", "other"):
            probe_cmd = "uname -r"
        else:
            probe_cmd = (
                "(nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader 2>/dev/null "
                "|| rocm-smi --showproductname 2>/dev/null) && uname -r"
            )
        exit_code = exec_on_target_sync(ssh_info, probe_cmd)
        if exit_code != 0:
            _exit_with_error("SSH probe failed")
        typer.echo("  SSH: OK")
        typer.echo(f"  Target '{name}' is active.")
    except (FileNotFoundError, TargetExecError, ValueError) as e:
        _exit_with_error(str(e))


def _fetch_statuses_with_fallback(
    fetch_accelerator_status: Any,
    list_targets: Any,
) -> list[dict[str, Any]]:
    """Fetch accelerator statuses; fall back to plain target list if endpoint unavailable."""
    import httpx as _httpx

    try:
        return fetch_accelerator_status()
    except RuntimeError as e:
        _exit_with_error(str(e))
    except _httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            _exit_with_error("Not authenticated. Run: wafer login")
        if e.response.status_code == 403:
            _exit_with_error("Access denied (403). Run: wafer login")
        if e.response.status_code in (404, 500):
            try:
                targets = list_targets()
            except (ImportError, RuntimeError, OSError):
                _exit_with_error("API unavailable. Check your connection or run: wafer login")
            return [
                {
                    "target_name": t.get("name", "?"),
                    "gpu_type": t.get("gpu_type"),
                    "gpu_ids": t.get("gpu_ids") or [0],
                    "status": "?",
                    "active_sandboxes": [],
                }
                for t in targets
            ]
        _exit_with_error(
            f"API error ({e.response.status_code}). Run: wafer login"
        )
    except (_httpx.ConnectError, _httpx.TimeoutException):
        _exit_with_error("Cannot reach API. Check your network connection.")


@target_app.command("list")
def unified_list(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    watch: bool = typer.Option(False, "--watch", "-w", help="Live-refresh every 5 seconds"),
) -> None:
    """List all targets with accelerator status"""
    import time

    def _fetch_and_render() -> None:
        from .user_targets_api import fetch_accelerator_status, list_targets

        statuses = _fetch_statuses_with_fallback(fetch_accelerator_status, list_targets)

        if json_output:
            from .output import json_response
            typer.echo(json_response(data={"targets": statuses}))
            return

        if not statuses:
            typer.echo("No targets found.")
            typer.echo("  SSH target:  wafer target init ssh --name X --host user@host:22")
            typer.echo("  Workspace:   wafer target init workspace <name> --gpu B200")
            typer.echo("  (Requires: wafer login)")
            return

        from rich.console import Console
        from rich.table import Table

        _STATUS_STYLE: dict[str, str] = {
            "idle": "green",
            "occupied": "yellow",
            "?": "dim",
        }

        table = Table(show_header=True, header_style="bold", box=None, pad_edge=False, padding=(0, 2))
        table.add_column("Target", style="bold cyan", no_wrap=True)
        table.add_column("Accelerator", no_wrap=True)
        table.add_column("Devices", no_wrap=True)
        table.add_column("Status", no_wrap=True)
        table.add_column("Sandboxes")

        for t in statuses:
            name = t.get("target_name") or t.get("name", "?")
            gpu = t.get("gpu_type") or "?"
            gpu_ids = t.get("gpu_ids") or []
            devices = ",".join(str(g) for g in gpu_ids) if gpu_ids else "—"
            status = t.get("status", "?")
            style = _STATUS_STYLE.get(status, "")
            status_cell = f"[{style}]●[/{style}] {status}" if style else status

            sandboxes = t.get("active_sandboxes") or []
            if sandboxes:
                sb = sandboxes[0]
                expires = sb.get("expires_at", "")
                sandbox_text = f"[yellow]{len(sandboxes)} active[/yellow]"
                if expires:
                    from datetime import datetime, timezone
                    exp_dt = datetime.fromisoformat(expires.replace("Z", "+00:00"))
                    remaining = exp_dt - datetime.now(timezone.utc)
                    hours = remaining.total_seconds() / 3600
                    if hours > 0:
                        sandbox_text += f" [dim](expires {hours:.1f}h)[/dim]"
            else:
                sandbox_text = "[dim]—[/dim]"

            table.add_row(name, gpu, devices, status_cell, sandbox_text)

        Console().print(table)

    if watch:
        import os
        from datetime import datetime, timezone
        try:
            while True:
                os.system("clear" if os.name != "nt" else "cls")
                now_str = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
                typer.echo(f"\033[1mwafer target list\033[0m  \033[2m--watch  {now_str}  Ctrl+C to stop\033[0m\n")
                try:
                    _fetch_and_render()
                except (typer.Exit, SystemExit):
                    typer.echo("\033[31mFetch failed — retrying in 5s…\033[0m", err=True)
                time.sleep(5)
        except KeyboardInterrupt:
            typer.echo("\nStopped.")
    else:
        _fetch_and_render()


@target_app.command("show")
def unified_show(
    name: str = typer.Argument(..., help="Target name"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show details for a target (workspace or host)

    Examples:
        wafer target show dev
        wafer target show my-gpu --json
    """
    try:
        kind, ws = resolve_target_type(name)
    except RuntimeError as e:
        _exit_with_error(str(e))
    assert kind in ("workspace", "host")

    if kind == "workspace":
        _show_workspace(name, json_output)
    else:
        _show_host(name, json_output)


@target_app.command("remove")
def unified_remove(
    name: str = typer.Argument(..., help="Target name"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Remove a target (workspace or host)"""
    try:
        kind, ws = resolve_target_type(name)
    except RuntimeError as e:
        _exit_with_error(str(e))
    assert kind in ("workspace", "host")

    if not yes:
        confirm = typer.confirm(f"Remove target '{name}'?")
        if not confirm:
            typer.echo("Cancelled.")
            raise typer.Exit(0)

    if kind == "workspace":
        from .workspaces import delete_workspace
        try:
            typer.echo(delete_workspace(name))
        except RuntimeError as e:
            _exit_with_error(str(e))
    else:
        try:
            from .user_targets_api import delete_target, get_target_by_name
            if get_target_by_name(name) is not None:
                delete_target(name)
                typer.echo(f"Removed target: {name}")
            else:
                from .targets import remove_target
                remove_target(name)
                typer.echo(f"Removed target: {name}")
        except FileNotFoundError as e:
            _exit_with_error(str(e))
        except ValueError as e:
            _exit_with_error(str(e))


@target_app.command("default")
def unified_default(
    name: str | None = typer.Argument(None, help="Target name to set as default (omit to show current)"),
) -> None:
    """Set the default target, or show the current default"""
    from .targets import get_default_target, set_default_target
    if name is None:
        current = get_default_target()
        if current:
            typer.echo(current)
        else:
            typer.echo("No default target set.")
            typer.echo("  Set one with: wafer target default <name>")
            typer.echo("  See targets:  wafer target list")
        return
    try:
        set_default_target(name)
        typer.echo(f"Default target set to: {name}")
    except FileNotFoundError as e:
        _exit_with_error(str(e))


@target_app.command("ssh")
def unified_ssh(
    name: str = typer.Argument(..., help="Target name"),
) -> None:
    """SSH into a target (workspace or host)"""
    import os as _os
    import trio
    try:
        kind, ws = resolve_target_type(name)
    except RuntimeError as e:
        _exit_with_error(str(e))
    assert kind in ("workspace", "host")

    if kind == "workspace":
        from .workspaces import get_workspace_raw
        try:
            ws_data = get_workspace_raw(name)
        except RuntimeError as e:
            _exit_with_error(str(e))
        host, port, user = _get_workspace_ssh_creds(ws_data)
        _os.execvp("ssh", _build_workspace_ssh_args(host, port, user))
    else:
        from .targets import load_target
        from .targets_ops import TargetExecError, get_target_ssh_info
        try:
            target = load_target(name)
            ssh_info = trio.run(get_target_ssh_info, target)
        except FileNotFoundError as e:
            _exit_with_error(str(e))
        except TargetExecError as e:
            _exit_with_error(str(e))
        _os.execvp("ssh", _build_host_ssh_args(ssh_info))


@target_app.command("sync")
def unified_sync(
    name: str = typer.Argument(..., help="Target name"),
    path: Path = typer.Argument(..., help="Local file or directory to sync"),
    remote_path: str | None = typer.Option(None, "--remote-path", "-r", help="Remote destination path"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show status messages"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress status messages"),
) -> None:
    """Sync local files to a target

    Examples:
        wafer target sync dev ./my-project
        wafer target sync my-gpu ./kernel.py --remote-path /tmp/kernel.py
    """
    import trio

    show_status = _resolve_show_status(quiet, verbose)
    if not path.exists():
        _exit_with_error(f"Path not found: {path}")
    try:
        kind, ws = resolve_target_type(name)
    except RuntimeError as e:
        _exit_with_error(str(e))
    assert kind in ("workspace", "host")

    on_progress = _make_progress_callback(show_status)
    if show_status:
        typer.echo(f"[wafer] Syncing {path} to {kind} {name}...", err=True)

    if kind == "workspace":
        from .workspaces import sync_files
        try:
            sync_files(name, path.resolve(), on_progress=on_progress, remote_path=remote_path)
        except RuntimeError as e:
            _exit_with_error(str(e))
    else:
        from .targets import load_target
        from .targets_ops import TargetExecError, get_target_ssh_info, sync_to_target
        try:
            target = load_target(name)
            ssh_info = trio.run(get_target_ssh_info, target)
            sync_to_target(ssh_info, path.resolve(), remote_path=remote_path, on_progress=on_progress)
        except (FileNotFoundError, TargetExecError) as e:
            _exit_with_error(str(e))


@target_app.command("pull")
def unified_pull(
    name: str = typer.Argument(..., help="Target name"),
    remote_path: str = typer.Argument(..., help="Remote path to pull"),
    local_path: Path = typer.Argument(Path("."), help="Local destination (default: current directory)"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show status messages"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress status messages"),
) -> None:
    """Pull files from a target to local machine"""
    import trio

    show_status = _resolve_show_status(quiet, verbose)
    try:
        kind, ws = resolve_target_type(name)
    except RuntimeError as e:
        _exit_with_error(str(e))
    assert kind in ("workspace", "host")

    on_progress = _make_progress_callback(show_status)
    if kind == "workspace":
        from .workspaces import pull_files
        try:
            file_count = pull_files(name, remote_path, local_path.resolve(), on_progress=on_progress)
            if show_status:
                typer.echo(f"[wafer] Pulled {file_count} files to {local_path}", err=True)
        except RuntimeError as e:
            _exit_with_error(str(e))
    else:
        from .targets import load_target
        from .targets_ops import TargetExecError, get_target_ssh_info, pull_from_target
        try:
            target = load_target(name)
            ssh_info = trio.run(get_target_ssh_info, target)
            pull_from_target(ssh_info, remote_path, local_path.resolve(), on_progress=on_progress)
        except (FileNotFoundError, TargetExecError) as e:
            _exit_with_error(str(e))



