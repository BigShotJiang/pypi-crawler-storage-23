"""API client for user targets and wafer keys."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import httpx

from .api_client import get_api_url
from .auth import get_auth_headers


def _handle_response(resp: httpx.Response) -> None:
    """Check response status; raise RuntimeError with a clean message on failure."""
    if resp.is_success:
        return
    detail = ""
    try:
        detail = resp.json().get("detail", resp.text)
    except (httpx.HTTPError, httpx.RequestError, OSError):
        detail = resp.text
    if resp.status_code == 401:
        raise RuntimeError("Not authenticated. Run: wafer login")
    if resp.status_code == 404:
        raise RuntimeError(f"Not found: {detail}")
    raise RuntimeError(f"API error ({resp.status_code}): {detail}")


def _get_client() -> tuple[str, dict[str, str]]:
    api_url = get_api_url()
    headers = get_auth_headers()
    if not api_url or not api_url.startswith("http"):
        raise RuntimeError("API URL must be configured. Run: wafer login")
    if not headers:
        raise RuntimeError("Not authenticated. Run: wafer login")
    return api_url, headers


def _supabase_fallback_list(auth_token: str) -> list[dict[str, Any]]:
    """Direct Supabase REST fallback when the API server is stale/broken."""
    import base64
    import json as _json
    from .global_config import get_supabase_url, get_supabase_anon_key

    sb_url = get_supabase_url()
    anon_key = get_supabase_anon_key()
    payload = auth_token.split(".")[1]
    payload += "=" * (4 - len(payload) % 4)
    uid = _json.loads(base64.urlsafe_b64decode(payload))["sub"]
    headers = {
        "Authorization": f"Bearer {auth_token}",
        "apikey": anon_key,
    }
    resp = httpx.get(
        f"{sb_url}/rest/v1/user_targets?user_id=eq.{uid}&order=created_at.desc",
        headers=headers,
        timeout=30,
    )
    _handle_response(resp)
    return resp.json()


_cache_list_targets: list[dict[str, Any]] | None = None


def invalidate_targets_api_cache() -> None:
    """Reset the list_targets cache."""
    global _cache_list_targets  # noqa: PLW0603
    _cache_list_targets = None


def list_targets() -> list[dict[str, Any]]:
    """List user targets from API, with direct Supabase fallback.
    Cached for the process lifetime — call invalidate_targets_api_cache() after mutations.
    """
    global _cache_list_targets  # noqa: PLW0603
    if _cache_list_targets is not None:
        return _cache_list_targets
    api_url, headers = _get_client()
    resp = httpx.get(
        f"{api_url}/v1/user-targets",
        headers=headers,
        timeout=30,
    )
    if resp.status_code >= 500:
        token = headers.get("Authorization", "").removeprefix("Bearer ")
        result = _supabase_fallback_list(token)
        _cache_list_targets = result
        return result
    _handle_response(resp)
    result = resp.json()
    _cache_list_targets = result
    return result


def fetch_accelerator_status() -> list[dict[str, Any]]:
    """Fetch per-target accelerator status (sandbox occupancy)."""
    api_url, headers = _get_client()
    resp = httpx.get(
        f"{api_url}/v1/user-targets/accelerator-status",
        headers=headers,
        timeout=30,
    )
    _handle_response(resp)
    return resp.json()


def get_target_by_name(name: str) -> dict[str, Any] | None:
    """Get target by name. Returns None if not found."""
    targets = list_targets()
    for t in targets:
        if t.get("name") == name:
            return t
    return None


def get_target_by_id(target_id: str) -> dict[str, Any]:
    """Get target by ID."""
    api_url, headers = _get_client()
    resp = httpx.get(
        f"{api_url}/v1/user-targets/{target_id}",
        headers=headers,
        timeout=30,
    )
    _handle_response(resp)
    return resp.json()


_SENTINEL_DEFAULT = object()
_cache_default_target_api: object = _SENTINEL_DEFAULT


def get_default_target_api() -> dict[str, Any] | None:
    """Get user's default target from API. Returns None if no default set (404).
    Cached for the process lifetime.
    """
    global _cache_default_target_api  # noqa: PLW0603
    if _cache_default_target_api is not _SENTINEL_DEFAULT:
        return _cache_default_target_api  # type: ignore[return-value]
    api_url, headers = _get_client()
    resp = httpx.get(
        f"{api_url}/v1/user-targets/default",
        headers=headers,
        timeout=30,
    )
    if resp.status_code == 404:
        _cache_default_target_api = None
        return None
    _handle_response(resp)
    result = resp.json()
    _cache_default_target_api = result
    return result


def set_default_target_api(target_id: str) -> None:
    """Set target as default via API."""
    api_url, headers = _get_client()
    resp = httpx.post(
        f"{api_url}/v1/user-targets/{target_id}/set-default",
        headers=headers,
        timeout=30,
    )
    _handle_response(resp)
    invalidate_targets_api_cache()
    global _cache_default_target_api  # noqa: PLW0603
    _cache_default_target_api = _SENTINEL_DEFAULT


def create_target(
    name: str,
    ssh_host: str,
    ssh_user: str,
    ssh_port: int = 22,
    gpu_type: str | None = None,
    gpu_ids: list[int] | None = None,
) -> dict[str, Any]:
    """Create target. Returns CreateTargetResponse with target and key info."""
    api_url, headers = _get_client()
    body: dict[str, Any] = {
        "name": name,
        "ssh_host": ssh_host,
        "ssh_port": ssh_port,
        "ssh_user": ssh_user,
    }
    if gpu_type:
        body["gpu_type"] = gpu_type
    if gpu_ids is not None:
        body["gpu_ids"] = gpu_ids

    resp = httpx.post(
        f"{api_url}/v1/user-targets",
        headers=headers,
        json=body,
        timeout=30,
    )
    _handle_response(resp)
    return resp.json()


def delete_target(name: str) -> None:
    """Delete target by name."""
    target = get_target_by_name(name)
    if not target:
        raise ValueError(f"Target '{name}' not found")
    api_url, headers = _get_client()
    resp = httpx.delete(
        f"{api_url}/v1/user-targets/{target['id']}",
        headers=headers,
        timeout=30,
    )
    _handle_response(resp)
    invalidate_targets_api_cache()


def verify_target(name: str, from_cloud: bool = False) -> dict[str, Any]:
    """Verify target connectivity."""
    target = get_target_by_name(name)
    if not target:
        raise ValueError(f"Target '{name}' not found")
    api_url, headers = _get_client()
    params = {"from-cloud": str(from_cloud).lower()}
    resp = httpx.post(
        f"{api_url}/v1/user-targets/{target['id']}/verify",
        headers=headers,
        params=params,
        timeout=120 if from_cloud else 30,
    )
    _handle_response(resp)
    return resp.json()


def fetch_target_key(target_id: str) -> str:
    """Fetch decrypted private key from API. Used when local key file is missing (multi-device)."""
    api_url, headers = _get_client()
    resp = httpx.get(
        f"{api_url}/v1/user-targets/{target_id}/key",
        headers=headers,
        timeout=30,
    )
    _handle_response(resp)
    return resp.json()["private_key"]


def list_wafer_keys() -> list[dict[str, Any]]:
    """List Wafer-managed SSH keys."""
    api_url, headers = _get_client()
    resp = httpx.get(
        f"{api_url}/v1/wafer-keys",
        headers=headers,
        timeout=30,
    )
    _handle_response(resp)
    return resp.json()


def generate_wafer_key(name: str) -> dict[str, Any]:
    """Generate a Wafer SSH keypair. Returns key with private_key (one-time)."""
    api_url, headers = _get_client()
    resp = httpx.post(
        f"{api_url}/v1/wafer-keys/generate",
        headers=headers,
        json={"name": name},
        timeout=30,
    )
    _handle_response(resp)
    return resp.json()


def delete_wafer_key(key_id: str) -> None:
    """Delete a Wafer key by ID."""
    api_url, headers = _get_client()
    resp = httpx.delete(
        f"{api_url}/v1/wafer-keys/{key_id}",
        headers=headers,
        timeout=30,
    )
    _handle_response(resp)


_COMPUTE_CAPS: dict[str, str] = {
    "B200": "10.0", "H100": "9.0", "A100": "8.0", "A10": "8.6",
    "V100": "7.0", "MI300X": "9.4", "MI250X": "9.0", "MI100": "8.0",
    "MI350X": "9.4",
    "RTX 5090": "10.0", "RTX 4090": "8.9", "RTX 3090": "8.6",
    "AMD Instinct MI300X": "9.4", "AMD Instinct MI250X": "9.0",
    "AMD Instinct MI100": "8.0", "AMD Instinct MI350X": "9.4",
}


def user_target_to_baremetal_target(t: dict[str, Any]) -> "BaremetalTarget":
    """Convert user target API response to BaremetalTarget for SSH operations."""
    from wafer.core.utils.kernel_utils.targets.config import BaremetalTarget

    name = t["name"]
    key_path = Path.home() / ".wafer" / "keys" / name

    if not key_path.exists():
        target_id = t.get("id")
        if not target_id:
            raise ValueError(
                f"Target '{name}' has no local key file at {key_path}. "
                "Re-register with: wafer target init ssh"
            )
        try:
            private_key = fetch_target_key(target_id)
            key_path.parent.mkdir(parents=True, exist_ok=True)
            key_path.write_text(private_key)
            key_path.chmod(0o600)
        except Exception as e:
            raise ValueError(
                f"Target '{name}' has no local key file and could not fetch from API: {e}\n"
                "Re-register with: wafer target init ssh"
            ) from e

    ssh_target = f"{t['ssh_user']}@{t['ssh_host']}:{t['ssh_port']}"
    gpu_ids = t.get("gpu_ids") or [0]
    if isinstance(gpu_ids, list) and len(gpu_ids) == 0:
        gpu_ids = [0]
    gpu_type = t.get("gpu_type") or "B200"
    gpu_upper = gpu_type.upper()
    if "TRAINIUM" in gpu_upper or "TRN1" in gpu_upper or "TRN2" in gpu_upper or "TRN3" in gpu_upper:
        compute_capability = "0.0"
        vendor = "trainium"
    elif "TPU" in gpu_upper:
        compute_capability = "0.0"
        vendor = "tpu"
    else:
        compute_capability = _COMPUTE_CAPS.get(gpu_type, "8.0")
        vendor = (
            "amd"
            if (gpu_upper.startswith("MI") or "INSTINCT" in gpu_upper)
            else "nvidia"
        )
    ncu_available = vendor == "nvidia"
    return BaremetalTarget(
        name=name,
        ssh_target=ssh_target,
        ssh_key=str(key_path),
        gpu_ids=gpu_ids,
        gpu_type=gpu_type,
        compute_capability=compute_capability,
        vendor=vendor,
        ncu_available=ncu_available,
    )
