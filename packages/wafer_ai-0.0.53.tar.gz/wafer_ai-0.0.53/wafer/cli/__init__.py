"""Wafer CLI package."""


def __getattr__(name: str):
    if name in ("app", "main"):
        from wafer.cli.app import app, main

        globals()["app"] = app
        globals()["main"] = main
        return globals()[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ["app", "main"]
