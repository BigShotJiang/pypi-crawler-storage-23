"""Shared target resolution. Extract from app.py for use by sandbox CLI and others."""
from __future__ import annotations

from collections.abc import Callable


def _gather_workspace_targets(
    gpu_filter: str | None = None,
    running_only: bool = False,
) -> list[tuple[str, str, dict]]:
    """Gather workspace targets, optionally filtered by GPU type.

    Returns list of (name, "workspace", ws_dict) tuples.
    """
    results: list[tuple[str, str, dict]] = []
    try:
        from wafer.cli.workspaces import _list_workspaces_raw

        for ws in _list_workspaces_raw():
            if running_only and ws.get("status") != "running":
                continue
            if gpu_filter and ws.get("gpu_type", "").upper() != gpu_filter.upper():
                continue
            results.append((ws["name"], "workspace", ws))
    except RuntimeError:
        pass  # API unreachable
    return results


def _gather_host_targets(
    gpu_filter: str | None = None,
) -> list[tuple[str, str]]:
    """Gather host targets (local TOML + user targets from API), optionally filtered by GPU type.

    Returns list of (name, "host") tuples.
    """
    from wafer.cli.targets import list_targets, load_target

    results: list[tuple[str, str]] = []
    seen: set[str] = set()
    for tname in list_targets():
        try:
            t = load_target(tname)
            if gpu_filter:
                t_gpu = t.gpu_type
                if t_gpu.upper() != gpu_filter.upper():
                    continue
            results.append((tname, "host"))
            seen.add(tname)
        except (FileNotFoundError, ValueError, TypeError):
            pass
    try:
        from wafer.cli.user_targets_api import list_targets as list_user_targets

        for t in list_user_targets():
            tname = t.get("name")
            if not tname or tname in seen:
                continue
            if gpu_filter:
                t_gpu = t.get("gpu_type", "") or ""
                if t_gpu.upper() != gpu_filter.upper():
                    continue
            results.append((tname, "host"))
            seen.add(tname)
    except (RuntimeError, Exception):
        pass
    return results


def resolve_target_type(name: str) -> tuple[str, dict | None]:
    """Determine if target is 'workspace' or 'host'. Returns (kind, info).

    kind is "workspace" or "host". info is ws_dict for workspace, None for host.
    Raises RuntimeError if name is not found or ambiguous.
    """
    if not name:
        raise RuntimeError("Target name must be non-empty")
    ws_match: dict | None = None
    try:
        from wafer.cli.workspaces import _list_workspaces_raw

        for ws in _list_workspaces_raw():
            if ws.get("name") == name or ws.get("id") == name:
                ws_match = ws
                break
    except RuntimeError:
        pass
    from wafer.cli.targets import list_targets

    is_local_host = name in list_targets()
    try:
        from wafer.cli.user_targets_api import get_target_by_name

        is_user_target = get_target_by_name(name) is not None
    except (RuntimeError, Exception):
        is_user_target = False
    is_host = is_local_host or is_user_target
    if ws_match and is_host:
        raise RuntimeError(
            f"Target '{name}' exists as both a workspace and a host.\n"
            "  Remove one to resolve the ambiguity, or rename the host:\n"
            f"    wafer target remove {name}   (removes workspace)\n"
            f"    wafer target show {name}     (currently picks workspace)"
        )
    if ws_match:
        return ("workspace", ws_match)
    if is_host:
        return ("host", None)
    raise RuntimeError(
        f"Target '{name}' not found as workspace or host.\n"
        "  List targets: wafer target list\n"
        "  Create one:   wafer target init --help"
    )


def resolve_target(
    name: str | None = None,
    gpu: str | None = None,
    on_pick: Callable[[list[tuple[str, str]], str], tuple[str, str]] | None = None,
) -> tuple[str, str]:
    """Resolve target by name, GPU type, or auto-select. Returns (target_name, kind).

    Resolution order:
    1. name given: use that target directly
    2. gpu given: find matching target(s), pick if multiple
    3. No args: use default, or auto-select if only one exists

    When multiple candidates exist, calls on_pick(candidates, label) if provided;
    otherwise raises RuntimeError.
    """
    if name:
        kind, _ = resolve_target_type(name)
        return name, kind

    if gpu:
        ws_targets = _gather_workspace_targets(gpu_filter=gpu, running_only=True)
        host_targets = _gather_host_targets(gpu_filter=gpu)
        candidates = [(n, k) for n, k, *_ in ws_targets] + list(host_targets)

        if not candidates:
            raise RuntimeError(
                f"No target found with GPU type '{gpu}'.\n"
                "  List targets: wafer target list"
            )
        if len(candidates) == 1:
            return candidates[0]
        if on_pick:
            return on_pick(candidates, f"Multiple targets with GPU '{gpu}'")
        names = ", ".join(c[0] for c in candidates)
        raise RuntimeError(
            f"Multiple targets with GPU '{gpu}': {names}. Use --target to specify."
        )

    # Auto-select
    from wafer.cli.targets import get_default_target

    default = get_default_target()
    if default:
        try:
            kind, _ = resolve_target_type(default)
            return default, kind
        except RuntimeError:
            pass

    ws_targets = _gather_workspace_targets(running_only=True)
    host_targets = _gather_host_targets()
    candidates = [(n, k) for n, k, *_ in ws_targets] + list(host_targets)

    if not candidates:
        raise RuntimeError(
            "No targets available.\n"
            "  Get started: wafer target init --help"
        )
    if len(candidates) == 1:
        return candidates[0]
    if on_pick:
        return on_pick(candidates, "Multiple targets available")
    names = ", ".join(c[0] for c in candidates)
    raise RuntimeError(f"Multiple targets available: {names}. Use --target to specify.")
