from langchain.chat_models import init_chat_model
import os

os.environ["GOOGLE_API_KEY"] = "KEY"

model = init_chat_model("google_genai:gemini-2.5-flash-lite")

while True:
    query = input("Enter Query (type exit to stop): ")

    if query.lower() == "exit":
        print("Chat Ended.")
        break

    response = model.invoke(query)

    print(f"\nQuery: {query}")
    print("Answer:")
    print(response.content)
    print("-" * 50)
