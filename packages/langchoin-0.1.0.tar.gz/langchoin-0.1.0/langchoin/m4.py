# app.py

import os
from langchain_google_genai import ChatGoogleGenerativeAI

os.environ["GOOGLE_API_KEY"] = "KEY"

try:
    model = ChatGoogleGenerativeAI(
        model="gemini-1.5-flash",  
        temperature=0.7
    )

    prompt_A = "Suggest a unique name for a white cat."
    prompt_B = "Give one creative cat name for a white colored kitten."

    response_A = model.invoke(prompt_A)
    response_B = model.invoke(prompt_B)

    print("Response A:", response_A.content)
    print("\n")
    print("Response B:", response_B.content)

except Exception as e:
    print("Error:", e)