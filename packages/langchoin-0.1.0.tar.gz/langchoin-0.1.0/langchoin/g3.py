import os
from langchain.chat_models import init_chat_model

os.environ["GOOGLE_API_KEY"] = "KEY"

model = init_chat_model("google_genai:gemini-2.5-flash-lite")

prompt = """Write Python code for bubble sort algorithm
without preamble and postamble."""

response = model.invoke(prompt)

print(f"User Query: {prompt}")
print("Answer:")
print(response.content)
