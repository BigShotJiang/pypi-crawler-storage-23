"""RYE OS Web Bundle — browser automation, fetch, and search tools."""
