# PyAxencoAPI

Client Python asynchrone pour interagir avec les dispositifs connectés MyNeomitis via API REST/Websocket.

## Installation

```bash
pip install pyaxencoapi
