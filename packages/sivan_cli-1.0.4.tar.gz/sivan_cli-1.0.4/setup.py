from setuptools import setup

setup(
    name="sivan-cli",
    version="1.0.4",
    py_modules=["sivan"],
    install_requires=[
        "requests",
    ],
    entry_points={
        "console_scripts": [
            "sivan=sivan:main",
        ],
    },
)
