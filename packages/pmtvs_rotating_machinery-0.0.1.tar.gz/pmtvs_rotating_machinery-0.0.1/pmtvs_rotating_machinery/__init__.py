"""pmtvs-rotating-machinery — signal analysis primitives. Coming soon."""
__version__ = "0.0.1"
