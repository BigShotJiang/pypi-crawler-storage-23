---
name: Pull request
about: Make a pull request

---

Related to #<ID>

Acceptance criteria 
=================== 
- [ ] Functionality implemented in agreement with description of the ticket
- [ ] Tests are updated
- [ ] Documentation updated
