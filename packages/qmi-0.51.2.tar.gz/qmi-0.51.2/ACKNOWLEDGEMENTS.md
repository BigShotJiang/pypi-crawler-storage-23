We would like to acknowledge the Technische Universiteit Delft for the funding of and making possible the QMI project. 
We would also like to acknowledge the Jigsaw B.V. for the development of the core of QMI.
