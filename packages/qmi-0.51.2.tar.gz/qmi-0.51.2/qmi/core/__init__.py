""" Core functionality of the QMI framework.
"""
