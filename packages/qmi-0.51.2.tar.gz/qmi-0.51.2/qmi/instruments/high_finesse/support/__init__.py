from qmi.instruments.high_finesse.support._library_wrapper import (
    WlmGetErr,
    WlmGainErr,
    WlmTempErr,
    WlmMmiErr,
    WlmDistanceErr
)