"""
Parallax Inc., USB multicore microcontroller.

The qmi.instruments.parallax package provides support for:
- USB Propeller project board
"""

from qmi.instruments.parallax.usb_propeller import Parallax_UsbPropeller
