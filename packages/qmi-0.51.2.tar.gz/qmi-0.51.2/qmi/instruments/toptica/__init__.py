"""
TOPTICA Photonics, digital laser controller.

The qmi.instruments.toptica package provides support for:
- DLC pro.
"""
# Alternative, QMI naming convention approved names
from qmi.instruments.toptica.dlc import Toptica_DLC as Toptica_DlcPro
