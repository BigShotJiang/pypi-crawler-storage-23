"""
Dummy QMI instrument class for demoing and tutorial examples.
"""
# Alternative, QMI naming convention approved name
from qmi.instruments.dummy.noisy_sine_generator import NoisySineGenerator as Dummy_NoisySineGenerator
