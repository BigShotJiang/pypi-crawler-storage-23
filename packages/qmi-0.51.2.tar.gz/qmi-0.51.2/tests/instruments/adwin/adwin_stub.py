class ADwin:
    pass  # empty class, only for avoiding error in unit-tests/coverage