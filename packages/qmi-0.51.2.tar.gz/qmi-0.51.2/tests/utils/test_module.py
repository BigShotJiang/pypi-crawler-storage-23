"""Test module."""


def start(foo: str, bar: int) -> None:
    pass


def stop() -> None:
    pass