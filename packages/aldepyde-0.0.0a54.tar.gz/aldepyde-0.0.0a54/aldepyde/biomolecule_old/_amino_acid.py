from aldepyde.biomolecule_old.Residue import Residue

__all__ = ['amino_acid']

class amino_acid(Residue):
    pass