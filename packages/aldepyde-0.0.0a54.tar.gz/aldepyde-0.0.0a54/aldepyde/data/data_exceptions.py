
class DataAccessException(Exception):
    def __init__(self, message):
        super().__init__(message)

# Unable to resolve to one output when necessary
class AmbiguousTokenException(Exception):
    def __init__(self, message):
        super().__init__(message)

# Invalid res_type
class BadCategoryException(Exception):
    def __init__(self, message):
        super().__init__(message)

class EntryRetrievalException(Exception):
    def __init__(self, message):
        super().__init__(message)