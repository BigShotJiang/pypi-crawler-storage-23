from .polymer_constraints import PolymerConstraints, ConstraintSpecs
from .defaults.protein_defaults import ProteinDefaults

class ProteinConstraints(PolymerConstraints):
    def __init__(self, specs:ConstraintSpecs=None):
        if specs is None:
            default_categories = ProteinDefaults().get_classes()
            cs = ConstraintSpecs(categories=default_categories)
        else:
            cs = specs
        # cs = self.get_default_classes() if classes is None else classes
        super().__init__(specs=cs)


    def get_default_classes(self):
        return ProteinDefaults().get_classes()