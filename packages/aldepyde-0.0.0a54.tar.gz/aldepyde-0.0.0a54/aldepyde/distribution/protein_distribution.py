from importlib.resources import files
import json

def load_swiss():
    pass

def load_chg():
    pass