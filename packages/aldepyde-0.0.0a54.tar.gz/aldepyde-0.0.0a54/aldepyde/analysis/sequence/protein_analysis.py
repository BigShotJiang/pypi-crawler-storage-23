from typing import Literal
from aldepyde.data import get_store


def hydropathy(sequence: str, scale: Literal['kd'] = 'kd', window: int = 0, window_average: bool = False) -> list:
    hydropathies = []
    den = len(sequence) if window_average\
    else 1
    if window < 0:
        return [sum([get_store().hydropathy(aa, scale=scale) for aa in sequence])/den]
    for i in range(window, len(sequence) - window, 1):
        residue_window = sequence[i - window:i + window + 1]
        hydropathies.append(sum([get_store().hydropathy(aa, scale=scale) for aa in residue_window])/(len(residue_window) if window_average
                                                                                                    else 1))
    if len(hydropathies) == 0:
        return [sum([get_store().hydropathy(aa, scale=scale) for aa in sequence])/den]
    return hydropathies

def helical_prop(sequence: str, window: int = 0, window_average: bool = False) -> list:
    propensities = []
    den = len(sequence) if window_average\
    else 1
    if window < 0:
        return [sum([get_store().helical_prop(aa) for aa in sequence])/den]
    for i in range(window, len(sequence) - window, 1):
        residue_window = sequence[i - window:i + window + 1]
        propensities.append(sum([get_store().helical_prop(aa) for aa in residue_window])/(len(residue_window) if window_average
                                                                                        else 1))
    if len(propensities) == 0:
        return [sum([get_store().helical_prop(aa) for aa in sequence])/den]
    return propensities

# TODO Implement this algorithm
# https://bio.libretexts.org/Courses/Ouachita_Baptist_University/Reyna_Cell_Biology/02%3A_2-(T2-first_lecture)_Protein_Structure/2.05%3A_G._Predicting_Protein_Properties_From_Sequences/2.5.02%3A_G2._Prediction_of_Secondary_Structure

def chou_fasman():
    pass