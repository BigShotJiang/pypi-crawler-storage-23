"""Shared Pydantic models for type validation."""

from pydantic import BaseModel

__all__ = ["BaseModel"]

