from typing import Literal

EncodingErrorHandler = Literal["strict", "ignore", "replace"]
