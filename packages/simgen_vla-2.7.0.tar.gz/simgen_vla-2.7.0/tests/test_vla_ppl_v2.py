"""
VLA vs Standard Training - PPL Comparison (Triton Version)
==========================================================
Uses vla.py Triton kernels directly (not cubin).
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import time
import math
import sys

# Add simgen to path
sys.path.insert(0, 'C:/SimGen')

# Check CUDA
assert torch.cuda.is_available(), "CUDA required"
device = torch.device('cuda')

# Import VLA from vla.py (Triton version)
from simgen.vla import (
    matmul, linear, softmax, cross_entropy, sum as vla_sum,
    VLAMatmulFunction, VLALinearFunction, VLACrossEntropyFunction,
    __version__
)

print(f"VLA version: {__version__}")
print(f"Device: {torch.cuda.get_device_name()}")
print()

# =============================================================================
# SIMPLE GPT MODEL
# =============================================================================

class SimpleGPT(nn.Module):
    """Minimal GPT for testing."""

    def __init__(self, vocab_size=1000, dim=256, n_heads=4, n_layers=2, seq_len=64):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, dim)
        self.pos_embed = nn.Embedding(seq_len, dim)

        self.layers = nn.ModuleList([
            nn.TransformerEncoderLayer(
                d_model=dim, nhead=n_heads, dim_feedforward=dim*4,
                dropout=0.0, batch_first=True
            ) for _ in range(n_layers)
        ])

        self.ln = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, vocab_size, bias=False)
        self.seq_len = seq_len

    def forward(self, x):
        B, T = x.shape
        pos = torch.arange(T, device=x.device)
        x = self.embed(x) + self.pos_embed(pos)

        for layer in self.layers:
            x = layer(x)

        x = self.ln(x)
        return self.head(x)


def train_standard(model, n_steps=200, batch_size=4, seq_len=64, vocab_size=1000, lr=1e-3):
    """Train with standard PyTorch."""
    model = model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr)

    losses = []
    start = time.time()

    for step in range(n_steps):
        x = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)
        targets = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)

        optimizer.zero_grad()
        logits = model(x)
        loss = F.cross_entropy(logits.view(-1, vocab_size), targets.view(-1))
        loss.backward()
        optimizer.step()

        losses.append(loss.item())

        if (step + 1) % 50 == 0:
            avg = sum(losses[-50:]) / 50
            print(f"  [Standard] Step {step+1}: Loss={avg:.4f}, PPL={math.exp(avg):.2f}")

    elapsed = time.time() - start
    final_loss = sum(losses[-20:]) / 20
    return final_loss, math.exp(final_loss), elapsed, losses


def train_vla_cross_entropy(model, n_steps=200, batch_size=4, seq_len=64, vocab_size=1000, lr=1e-3):
    """Train with VLA cross-entropy (exact loss computation)."""
    model = model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr)

    losses = []
    start = time.time()

    for step in range(n_steps):
        x = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)
        targets = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)

        optimizer.zero_grad()
        logits = model(x)

        # VLA cross entropy with autograd
        loss = VLACrossEntropyFunction.apply(
            logits.view(-1, vocab_size),
            targets.view(-1),
            'mean'
        )

        loss.backward()
        optimizer.step()

        losses.append(loss.item())

        if (step + 1) % 50 == 0:
            avg = sum(losses[-50:]) / 50
            print(f"  [VLA CE] Step {step+1}: Loss={avg:.4f}, PPL={math.exp(avg):.2f}")

    elapsed = time.time() - start
    final_loss = sum(losses[-20:]) / 20
    return final_loss, math.exp(final_loss), elapsed, losses


def train_vla_linear_output(model, n_steps=200, batch_size=4, seq_len=64, vocab_size=1000, lr=1e-3):
    """Train with VLA linear for output projection + VLA cross-entropy."""
    model = model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr)

    losses = []
    start = time.time()

    for step in range(n_steps):
        x = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)
        targets = torch.randint(0, vocab_size, (batch_size, seq_len), device=device)

        optimizer.zero_grad()

        # Standard forward until output layer
        B, T = x.shape
        pos = torch.arange(T, device=x.device)
        h = model.embed(x) + model.pos_embed(pos)

        for layer in model.layers:
            h = layer(h)
        h = model.ln(h)

        # VLA linear for final projection (exact)
        logits = VLALinearFunction.apply(h, model.head.weight, None)
        logits = logits.float()

        # VLA cross entropy (exact)
        loss = VLACrossEntropyFunction.apply(
            logits.view(-1, vocab_size),
            targets.view(-1),
            'mean'
        )

        loss.backward()
        optimizer.step()

        losses.append(loss.item())

        if (step + 1) % 50 == 0:
            avg = sum(losses[-50:]) / 50
            print(f"  [VLA Lin+CE] Step {step+1}: Loss={avg:.4f}, PPL={math.exp(avg):.2f}")

    elapsed = time.time() - start
    final_loss = sum(losses[-20:]) / 20
    return final_loss, math.exp(final_loss), elapsed, losses


# =============================================================================
# RUN TESTS
# =============================================================================

print("="*70)
print("VLA TRAINING COMPARISON (200 steps)")
print("="*70)

# Test 1: Standard
print("\n[1/3] Training with Standard PyTorch...")
torch.manual_seed(42)
torch.cuda.manual_seed(42)
model1 = SimpleGPT()
loss1, ppl1, time1, losses1 = train_standard(model1, n_steps=200)

# Test 2: VLA Cross-Entropy only
print("\n[2/3] Training with VLA Cross-Entropy...")
torch.manual_seed(42)
torch.cuda.manual_seed(42)
model2 = SimpleGPT()
model2.load_state_dict(torch.load('temp_weights.pt') if False else model1.state_dict())
# Reset to same init
torch.manual_seed(42)
torch.cuda.manual_seed(42)
model2 = SimpleGPT()
loss2, ppl2, time2, losses2 = train_vla_cross_entropy(model2, n_steps=200)

# Test 3: VLA Linear + Cross-Entropy
print("\n[3/3] Training with VLA Linear + Cross-Entropy...")
torch.manual_seed(42)
torch.cuda.manual_seed(42)
model3 = SimpleGPT()
loss3, ppl3, time3, losses3 = train_vla_linear_output(model3, n_steps=200)

# =============================================================================
# RESULTS
# =============================================================================

print()
print("="*70)
print("RESULTS")
print("="*70)
print(f"{'Method':<25} {'Loss':>10} {'PPL':>10} {'Time':>10} {'PPL Δ':>12}")
print("-"*70)
print(f"{'Standard PyTorch':<25} {loss1:>10.4f} {ppl1:>10.2f} {time1:>9.1f}s {'baseline':>12}")
print(f"{'VLA Cross-Entropy':<25} {loss2:>10.4f} {ppl2:>10.2f} {time2:>9.1f}s {(ppl1-ppl2)/ppl1*100:>+11.1f}%")
print(f"{'VLA Linear + CE':<25} {loss3:>10.4f} {ppl3:>10.2f} {time3:>9.1f}s {(ppl1-ppl3)/ppl1*100:>+11.1f}%")
print()

# Check convergence over time
print("Loss at step 50/100/150/200:")
print(f"  Standard:    {losses1[49]:.4f} / {losses1[99]:.4f} / {losses1[149]:.4f} / {losses1[199]:.4f}")
print(f"  VLA CE:      {losses2[49]:.4f} / {losses2[99]:.4f} / {losses2[149]:.4f} / {losses2[199]:.4f}")
print(f"  VLA Lin+CE:  {losses3[49]:.4f} / {losses3[99]:.4f} / {losses3[149]:.4f} / {losses3[199]:.4f}")
