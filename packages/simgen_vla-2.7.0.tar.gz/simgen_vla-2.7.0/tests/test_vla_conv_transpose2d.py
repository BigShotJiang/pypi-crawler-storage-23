"""
VLA Conv Transpose 2D Test - TRUE ZERO ERROR
"""
import sys
sys.path.insert(0, '/mnt/c/SimGen/simgen')
import torch
import torch.nn.functional as F
from decimal import Decimal, getcontext
import struct
getcontext().prec = 200

import vla_triton as vla

print("="*60)
print("VLA CONV_TRANSPOSE2D TEST")
print("="*60)

def fp64_to_decimal(f):
    bits = struct.unpack("Q", struct.pack("d", f))[0]
    if bits == 0:
        return Decimal(0)
    sign = -1 if (bits >> 63) else 1
    exp = ((bits >> 52) & 0x7FF) - 1023 - 52
    mantissa = (bits & 0xFFFFFFFFFFFFF) | 0x10000000000000
    return Decimal(sign * mantissa) * (Decimal(2) ** exp)

torch.manual_seed(42)
device = "cuda"

# Test 1: Basic conv_transpose2d
print("\n--- Test 1: Basic conv_transpose2d ---")
N, C_in, H, W = 2, 3, 4, 4
C_out, kH, kW = 4, 3, 3
stride, padding = 2, 1

x = torch.randn(N, C_in, H, W, device=device, dtype=torch.float32)
# Note: conv_transpose2d weight is [C_in, C_out, kH, kW]
w = torch.randn(C_in, C_out, kH, kW, device=device, dtype=torch.float32)

print(f"Input:  [{N}, {C_in}, {H}, {W}]")
print(f"Weight: [{C_in}, {C_out}, {kH}, {kW}]")
print(f"Stride: {stride}, Padding: {padding}")

result = vla.vla_conv_transpose2d(x, w, stride=stride, padding=padding)
print(f"Output shape: {result.shape}")
print(f"Output dtype: {result.dtype}")

# Compare to FP64 PyTorch
gt = F.conv_transpose2d(x.double(), w.double(), stride=stride, padding=padding)
print(f"Expected shape: {gt.shape}")
error = (result - gt).abs().max().item()
print(f"Max error vs FP64: {error:.2e}")

# Test 2: return_vla=True
print("\n--- Test 2: conv_transpose2d(return_vla=True) ---")
result_vla = vla.vla_conv_transpose2d(x, w, stride=stride, padding=padding, return_vla=True)
print(f"VLAResult: {result_vla.n_limbs} limbs")

# Check one element manually
# For transposed conv, element [0,0,0,0] gets contributions from specific input/kernel combinations
collapsed = result_vla.collapse()
gt_elem = gt[0, 0, 0, 0].item()
vla_elem = collapsed[0, 0, 0, 0].item()
error = abs(vla_elem - gt_elem)
print(f"Element [0,0,0,0] error vs FP64: {error:.2e}")

# Test 3: UNet-like upsampling shape
print("\n--- Test 3: UNet-like Upsampling ---")
N, C_in, H, W = 1, 256, 8, 8
C_out, kH, kW = 128, 4, 4
stride, padding = 2, 1

x = torch.randn(N, C_in, H, W, device=device, dtype=torch.float32)
w = torch.randn(C_in, C_out, kH, kW, device=device, dtype=torch.float32)

result = vla.vla_conv_transpose2d(x, w, stride=stride, padding=padding)
gt = F.conv_transpose2d(x.double(), w.double(), stride=stride, padding=padding)

print(f"Input: [{N},{C_in},{H},{W}] -> Output: {result.shape}")
error = (result - gt).abs().max().item()
print(f"Max error vs FP64: {error:.2e}")

# Test 4: Diffusion model typical shape
print("\n--- Test 4: Diffusion Model Shape ---")
N, C_in, H, W = 1, 512, 16, 16
C_out, kH, kW = 256, 3, 3
stride, padding = 2, 1
output_padding = 1

x = torch.randn(N, C_in, H, W, device=device, dtype=torch.float32)
w = torch.randn(C_in, C_out, kH, kW, device=device, dtype=torch.float32)

result = vla.vla_conv_transpose2d(x, w, stride=stride, padding=padding, output_padding=output_padding)
gt = F.conv_transpose2d(x.double(), w.double(), stride=stride, padding=padding, output_padding=output_padding)

print(f"Input: [{N},{C_in},{H},{W}] -> Output: {result.shape}")
error = (result - gt).abs().max().item()
print(f"Max error vs FP64: {error:.2e}")

print("\n" + "="*60)
print("CONV_TRANSPOSE2D TEST COMPLETE")
print("="*60)
