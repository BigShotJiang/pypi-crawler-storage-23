"""
Test Universal VLA Mode - Vision Models
========================================
Tests CNN, UNet-style, and ResNet-like architectures.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import sys

sys.path.insert(0, '/mnt/c/SimGen')

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"Device: {device}")

from simgen import vla

print("\n" + "="*70)
print("UNIVERSAL VLA VISION TEST")
print("="*70)

# Enable VLA
vla.enable_vla()

errors = []

def test_model(name, model, input_shape, check_backward=True):
    try:
        x = torch.randn(*input_shape, device=device, requires_grad=True)
        out = model(x)

        # Check for NaN
        if torch.isnan(out).any():
            errors.append((name, "NaN in output"))
            print(f"  ✗ {name}: NaN in output")
            return

        # Test backward if requested
        if check_backward:
            loss = out.mean()
            loss.backward()
            if x.grad is None or torch.isnan(x.grad).any():
                errors.append((name, "NaN or None gradient"))
                print(f"  ✗ {name}: NaN or None gradient")
                return

        print(f"  ✓ {name} - output: {out.shape}")
        return True
    except Exception as e:
        errors.append((name, str(e)))
        print(f"  ✗ {name}: {e}")
        return False

# =============================================================================
# TEST 1: Basic CNN
# =============================================================================
print("\n--- Basic CNN ---")

class SimpleCNN(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 32, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(32)
        self.conv2 = nn.Conv2d(32, 64, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(64)
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(64, 10)

    def forward(self, x):
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.max_pool2d(x, 2)
        x = F.relu(self.bn2(self.conv2(x)))
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        return self.fc(x)

model = SimpleCNN().to(device)
test_model("SimpleCNN", model, (4, 3, 32, 32))

# =============================================================================
# TEST 2: ResNet-style Block
# =============================================================================
print("\n--- ResNet-style ---")

class ResBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(channels)
        self.conv2 = nn.Conv2d(channels, channels, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(channels)

    def forward(self, x):
        residual = x
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out = out + residual
        return F.relu(out)

class MiniResNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 64, 7, stride=2, padding=3)
        self.bn1 = nn.BatchNorm2d(64)
        self.pool = nn.MaxPool2d(3, stride=2, padding=1)
        self.block1 = ResBlock(64)
        self.block2 = ResBlock(64)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(64, 10)

    def forward(self, x):
        x = F.relu(self.bn1(self.conv1(x)))
        x = self.pool(x)
        x = self.block1(x)
        x = self.block2(x)
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        return self.fc(x)

model = MiniResNet().to(device)
test_model("MiniResNet", model, (4, 3, 64, 64))

# =============================================================================
# TEST 3: UNet-style Encoder-Decoder
# =============================================================================
print("\n--- UNet-style ---")

class DoubleConv(nn.Module):
    def __init__(self, in_ch, out_ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=False),
            nn.Conv2d(out_ch, out_ch, 3, padding=1),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=False)
        )

    def forward(self, x):
        return self.conv(x)

class MiniUNet(nn.Module):
    def __init__(self, in_ch=3, out_ch=1):
        super().__init__()
        self.enc1 = DoubleConv(in_ch, 64)
        self.enc2 = DoubleConv(64, 128)
        self.pool = nn.MaxPool2d(2)

        self.bottleneck = DoubleConv(128, 256)

        self.up2 = nn.ConvTranspose2d(256, 128, 2, stride=2)
        self.dec2 = DoubleConv(256, 128)
        self.up1 = nn.ConvTranspose2d(128, 64, 2, stride=2)
        self.dec1 = DoubleConv(128, 64)

        self.out = nn.Conv2d(64, out_ch, 1)

    def forward(self, x):
        # Encoder
        e1 = self.enc1(x)
        e2 = self.enc2(self.pool(e1))

        # Bottleneck
        b = self.bottleneck(self.pool(e2))

        # Decoder
        d2 = self.up2(b)
        d2 = self.dec2(torch.cat([d2, e2], dim=1))
        d1 = self.up1(d2)
        d1 = self.dec1(torch.cat([d1, e1], dim=1))

        return self.out(d1)

model = MiniUNet().to(device)
test_model("MiniUNet", model, (2, 3, 64, 64))

# =============================================================================
# TEST 4: Diffusion-style (GroupNorm + SiLU)
# =============================================================================
print("\n--- Diffusion-style ---")

class DiffusionBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.norm1 = nn.GroupNorm(8, channels)
        self.conv1 = nn.Conv2d(channels, channels, 3, padding=1)
        self.norm2 = nn.GroupNorm(8, channels)
        self.conv2 = nn.Conv2d(channels, channels, 3, padding=1)

    def forward(self, x):
        h = F.silu(self.norm1(x))
        h = self.conv1(h)
        h = F.silu(self.norm2(h))
        h = self.conv2(h)
        return h + x

class MiniDiffusion(nn.Module):
    def __init__(self, in_ch=3, out_ch=3, channels=64):
        super().__init__()
        self.conv_in = nn.Conv2d(in_ch, channels, 3, padding=1)
        self.block1 = DiffusionBlock(channels)
        self.block2 = DiffusionBlock(channels)
        self.norm_out = nn.GroupNorm(8, channels)
        self.conv_out = nn.Conv2d(channels, out_ch, 3, padding=1)

    def forward(self, x):
        x = self.conv_in(x)
        x = self.block1(x)
        x = self.block2(x)
        x = F.silu(self.norm_out(x))
        return self.conv_out(x)

model = MiniDiffusion().to(device)
test_model("MiniDiffusion", model, (2, 3, 32, 32))

# =============================================================================
# TEST 5: Full Training Step
# =============================================================================
print("\n--- Full Training Step ---")

model = SimpleCNN().to(device)
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)

x = torch.randn(8, 3, 32, 32, device=device)
y = torch.randint(0, 10, (8,), device=device)

try:
    # Forward
    logits = model(x)
    loss = F.cross_entropy(logits, y)

    # Backward
    optimizer.zero_grad()
    loss.backward()

    # Check gradients
    has_grads = all(p.grad is not None for p in model.parameters() if p.requires_grad)
    nan_grads = any(torch.isnan(p.grad).any() for p in model.parameters() if p.grad is not None)

    # Step
    optimizer.step()

    if has_grads and not nan_grads:
        print(f"  ✓ Full training step - loss: {loss.item():.4f}")
    else:
        errors.append(("Training step", f"has_grads={has_grads}, nan_grads={nan_grads}"))
        print(f"  ✗ Training step: has_grads={has_grads}, nan_grads={nan_grads}")
except Exception as e:
    errors.append(("Training step", str(e)))
    print(f"  ✗ Training step: {e}")

# Disable and summary
vla.disable_vla()

print("\n" + "="*70)
print("SUMMARY")
print("="*70)

if errors:
    print(f"\n❌ {len(errors)} errors:")
    for name, err in errors:
        print(f"   - {name}: {err}")
else:
    print("\n✓ All vision tests passed!")
    print("\nVLA now supports:")
    print("  - CNNs (ResNet, VGG, etc.)")
    print("  - UNets (segmentation)")
    print("  - Diffusion models (Stable Diffusion-style)")
    print("  - Any model using conv/pool/interpolate")
