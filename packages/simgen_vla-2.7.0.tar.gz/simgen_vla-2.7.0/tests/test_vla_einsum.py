"""
VLA Einsum Test - TRUE ZERO ERROR
"""
import sys
sys.path.insert(0, '/mnt/c/SimGen/simgen')
import torch
from decimal import Decimal, getcontext
import struct
getcontext().prec = 200

import vla_triton as vla

print("="*60)
print("VLA EINSUM TEST")
print("="*60)

def fp64_to_decimal(f):
    bits = struct.unpack("Q", struct.pack("d", f))[0]
    if bits == 0:
        return Decimal(0)
    sign = -1 if (bits >> 63) else 1
    exp = ((bits >> 52) & 0x7FF) - 1023 - 52
    mantissa = (bits & 0xFFFFFFFFFFFFF) | 0x10000000000000
    return Decimal(sign * mantissa) * (Decimal(2) ** exp)

def decimal_dot(x, y):
    result = Decimal(0)
    for a, b in zip(x.flatten().cpu().tolist(), y.flatten().cpu().tolist()):
        result += fp64_to_decimal(float(a)) * fp64_to_decimal(float(b))
    return result

torch.manual_seed(42)
device = "cuda"

# Test 1: Dot product 'i,i->'
print("\n--- Test 1: einsum('i,i->') dot product ---")
a = torch.randn(500, device=device, dtype=torch.float32)
b = torch.randn(500, device=device, dtype=torch.float32)
gt = decimal_dot(a.double(), b.double())
result = vla.vla_einsum("i,i->", a, b, return_vla=True)
vla_dec = result.to_decimal()
error = abs(vla_dec - gt)
print(f"Error: {error}")
print("TRUE ZERO!" if error == 0 else "Has error")

# Test 2: Outer product 'i,j->ij'
print("\n--- Test 2: einsum('i,j->ij') outer product ---")
a = torch.randn(50, device=device, dtype=torch.float32)
b = torch.randn(50, device=device, dtype=torch.float32)
result = vla.vla_einsum("i,j->ij", a, b, return_vla=True)
gt_elem = fp64_to_decimal(a[0].item()) * fp64_to_decimal(b[0].item())
vla_elem = result.to_decimal((0, 0))
error = abs(vla_elem - gt_elem)
print(f"Element [0,0] error: {error}")
print("TRUE ZERO!" if error == 0 else "Has error")

# Test 3: Matrix multiply 'ij,jk->ik'
print("\n--- Test 3: einsum('ij,jk->ik') matmul ---")
a = torch.randn(16, 32, device=device, dtype=torch.float32)
b = torch.randn(32, 16, device=device, dtype=torch.float32)
gt = decimal_dot(a[0,:].double(), b[:,0].double())
result = vla.vla_einsum("ij,jk->ik", a, b, return_vla=True)
vla_elem = result.to_decimal((0, 0))
error = abs(vla_elem - gt)
print(f"Element [0,0] error: {error}")
print("TRUE ZERO!" if error == 0 else "Has error")

# Test 4: Batch matmul 'bij,bjk->bik'
print("\n--- Test 4: einsum('bij,bjk->bik') batch matmul ---")
a = torch.randn(4, 8, 16, device=device, dtype=torch.float32)
b = torch.randn(4, 16, 8, device=device, dtype=torch.float32)
gt = decimal_dot(a[0, 0, :].double(), b[0, :, 0].double())
result = vla.vla_einsum("bij,bjk->bik", a, b, return_vla=True)
vla_elem = result.to_decimal((0, 0, 0))
error = abs(vla_elem - gt)
print(f"Element [0,0,0] error: {error}")
print("TRUE ZERO!" if error == 0 else "Has error")

# Test 5: Transpose 'ij->ji'
print("\n--- Test 5: einsum('ij->ji') transpose ---")
a = torch.randn(8, 16, device=device, dtype=torch.float32)
result = vla.vla_einsum("ij->ji", a)
expected = a.t().double()
error = (result - expected).abs().max().item()
print(f"Max error: {error}")
print("EXACT!" if error == 0 else "Has error")

# Test 6: Trace 'ii->'
print("\n--- Test 6: einsum('ii->') trace ---")
a = torch.randn(32, 32, device=device, dtype=torch.float32)
result = vla.vla_einsum("ii->", a, return_vla=True)
diag = a.diagonal()
gt = Decimal(0)
for v in diag.cpu().tolist():
    gt += fp64_to_decimal(float(v))
vla_dec = result.to_decimal()
error = abs(vla_dec - gt)
print(f"Error: {error}")
print("TRUE ZERO!" if error == 0 else "Has error")

# Test 7: Sum over axis 'ijk->ij'
print("\n--- Test 7: einsum('ijk->ij') sum axis ---")
a = torch.randn(4, 8, 16, device=device, dtype=torch.float32)
result = vla.vla_einsum("ijk->ij", a, return_vla=True)
gt = Decimal(0)
for k in range(16):
    gt += fp64_to_decimal(a[0, 0, k].item())
vla_elem = result.to_decimal((0, 0))
error = abs(vla_elem - gt)
print(f"Element [0,0] error: {error}")
print("TRUE ZERO!" if error == 0 else "Has error")

# Test 8: Unsupported pattern should FAIL
print("\n--- Test 8: Unsupported pattern should FAIL ---")
try:
    c = torch.randn(4, 16, 8, device=device, dtype=torch.float32)
    result = vla.vla_einsum("ijk,jkl->il", a, c)
    print("ERROR: Should have raised NotImplementedError!")
except NotImplementedError as e:
    print("Correctly raised NotImplementedError")

print("\n" + "="*60)
print("EINSUM TEST COMPLETE")
print("="*60)
