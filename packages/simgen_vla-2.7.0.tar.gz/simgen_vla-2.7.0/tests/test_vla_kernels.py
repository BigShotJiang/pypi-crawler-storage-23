"""
VLA Kernel-by-Kernel Test
==========================
Test each VLA kernel to verify exact precision with no errors.
Run in WSL: python test_vla_kernels.py
"""

import torch
import sys
import math

sys.path.insert(0, 'C:/SimGen')

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"Device: {torch.cuda.get_device_name() if device == 'cuda' else 'CPU'}")

from simgen import vla

def test_kernel(name, vla_fn, torch_fn, gen_input, tolerance=1e-10):
    """Test a single kernel against FP64 ground truth."""
    print(f"\n{'='*60}")
    print(f"Testing: {name}")
    print(f"{'='*60}")

    # Generate input
    inputs = gen_input()
    if isinstance(inputs, torch.Tensor):
        inputs = (inputs,)

    # Ground truth: FP64 computation
    inputs_fp64 = tuple(x.double() for x in inputs)
    gt = torch_fn(*inputs_fp64).item() if torch_fn(*inputs_fp64).numel() == 1 else torch_fn(*inputs_fp64)

    # Standard PyTorch FP32
    inputs_fp32 = tuple(x.float() for x in inputs)
    std_result = torch_fn(*inputs_fp32)

    # VLA result
    vla_result = vla_fn(*inputs_fp32)

    # Compare errors
    if isinstance(gt, torch.Tensor):
        gt_val = gt.double()
        std_err = (std_result.double() - gt_val).abs().max().item()
        vla_err = (vla_result.double() - gt_val).abs().max().item()
    else:
        gt_val = gt
        std_result_val = std_result.item() if isinstance(std_result, torch.Tensor) else std_result
        vla_result_val = vla_result.item() if isinstance(vla_result, torch.Tensor) else vla_result
        std_err = abs(std_result_val - gt_val)
        vla_err = abs(vla_result_val - gt_val)

    # Report
    print(f"  Ground truth (FP64): {gt_val if not isinstance(gt_val, torch.Tensor) else 'tensor'}")
    print(f"  Standard FP32 error: {std_err:.2e}")
    print(f"  VLA error:           {vla_err:.2e}")

    if std_err > 0:
        improvement = std_err / max(vla_err, 1e-20)
        print(f"  VLA improvement:     {improvement:.0f}x more accurate")

    # Check if VLA is better or equal
    if vla_err <= std_err:
        print(f"  Result: PASS")
        return True
    else:
        print(f"  Result: FAIL (VLA worse than standard)")
        return False


# =============================================================================
# KERNEL 1: SUM
# =============================================================================
def test_sum():
    return test_kernel(
        name="vla.sum",
        vla_fn=vla.sum,
        torch_fn=torch.sum,
        gen_input=lambda: torch.randn(10_000_000, device=device)
    )


# =============================================================================
# KERNEL 2: DOT
# =============================================================================
def test_dot():
    def gen():
        return torch.randn(10_000_000, device=device), torch.randn(10_000_000, device=device)

    return test_kernel(
        name="vla.dot",
        vla_fn=vla.dot,
        torch_fn=torch.dot,
        gen_input=gen
    )


# =============================================================================
# KERNEL 3: MEAN
# =============================================================================
def test_mean():
    return test_kernel(
        name="vla.mean",
        vla_fn=vla.mean,
        torch_fn=torch.mean,
        gen_input=lambda: torch.randn(10_000_000, device=device)
    )


# =============================================================================
# KERNEL 4: NORM
# =============================================================================
def test_norm():
    return test_kernel(
        name="vla.norm",
        vla_fn=vla.norm,
        torch_fn=torch.norm,
        gen_input=lambda: torch.randn(10_000_000, device=device)
    )


# =============================================================================
# KERNEL 5: VAR
# =============================================================================
def test_var():
    return test_kernel(
        name="vla.var",
        vla_fn=vla.var,
        torch_fn=torch.var,
        gen_input=lambda: torch.randn(10_000_000, device=device)
    )


# =============================================================================
# KERNEL 6: STD
# =============================================================================
def test_std():
    return test_kernel(
        name="vla.std",
        vla_fn=vla.std,
        torch_fn=torch.std,
        gen_input=lambda: torch.randn(10_000_000, device=device)
    )


# =============================================================================
# KERNEL 7: MATMUL
# =============================================================================
def test_matmul():
    def gen():
        return torch.randn(512, 512, device=device), torch.randn(512, 512, device=device)

    def vla_mm(a, b):
        return vla.matmul(a, b)

    def torch_mm(a, b):
        return torch.matmul(a, b)

    print(f"\n{'='*60}")
    print(f"Testing: vla.matmul")
    print(f"{'='*60}")

    a, b = gen()

    # Ground truth
    gt = torch.matmul(a.double(), b.double())

    # Standard
    std_result = torch.matmul(a.float(), b.float())
    std_err = (std_result.double() - gt).abs().max().item()

    # VLA
    vla_result = vla.matmul(a.float(), b.float())
    vla_err = (vla_result - gt).abs().max().item()

    print(f"  Standard FP32 max error: {std_err:.2e}")
    print(f"  VLA max error:           {vla_err:.2e}")

    if std_err > 0:
        improvement = std_err / max(vla_err, 1e-20)
        print(f"  VLA improvement:         {improvement:.0f}x more accurate")

    if vla_err <= std_err:
        print(f"  Result: PASS")
        return True
    else:
        print(f"  Result: FAIL")
        return False


# =============================================================================
# KERNEL 8: SOFTMAX
# =============================================================================
def test_softmax():
    print(f"\n{'='*60}")
    print(f"Testing: vla.softmax")
    print(f"{'='*60}")

    x = torch.randn(1024, 1024, device=device)

    # Ground truth
    gt = torch.softmax(x.double(), dim=-1)

    # Standard
    std_result = torch.softmax(x.float(), dim=-1)
    std_err = (std_result.double() - gt).abs().max().item()

    # VLA
    vla_result = vla.softmax(x.float(), dim=-1)
    vla_err = (vla_result.double() - gt).abs().max().item()

    print(f"  Standard FP32 max error: {std_err:.2e}")
    print(f"  VLA max error:           {vla_err:.2e}")

    if std_err > 0:
        improvement = std_err / max(vla_err, 1e-20)
        print(f"  VLA improvement:         {improvement:.0f}x more accurate")

    if vla_err <= std_err:
        print(f"  Result: PASS")
        return True
    else:
        print(f"  Result: FAIL")
        return False


# =============================================================================
# KERNEL 9: LAYER NORM
# =============================================================================
def test_layer_norm():
    print(f"\n{'='*60}")
    print(f"Testing: vla.layer_norm")
    print(f"{'='*60}")

    x = torch.randn(1024, 768, device=device)

    # Ground truth
    gt = torch.nn.functional.layer_norm(x.double(), (768,))

    # Standard
    std_result = torch.nn.functional.layer_norm(x.float(), (768,))
    std_err = (std_result.double() - gt).abs().max().item()

    # VLA
    vla_result = vla.layer_norm(x.float(), (768,))
    vla_err = (vla_result.double() - gt).abs().max().item()

    print(f"  Standard FP32 max error: {std_err:.2e}")
    print(f"  VLA max error:           {vla_err:.2e}")

    if std_err > 0:
        improvement = std_err / max(vla_err, 1e-20)
        print(f"  VLA improvement:         {improvement:.0f}x more accurate")

    if vla_err <= std_err:
        print(f"  Result: PASS")
        return True
    else:
        print(f"  Result: FAIL")
        return False


# =============================================================================
# MAIN
# =============================================================================
if __name__ == "__main__":
    print("="*60)
    print("VLA KERNEL-BY-KERNEL TEST")
    print("="*60)
    print("Testing each kernel for exact precision vs FP64 ground truth")

    results = {}

    # Test each kernel
    results['sum'] = test_sum()
    results['dot'] = test_dot()
    results['mean'] = test_mean()
    results['norm'] = test_norm()
    results['var'] = test_var()
    results['std'] = test_std()
    results['matmul'] = test_matmul()
    results['softmax'] = test_softmax()
    results['layer_norm'] = test_layer_norm()

    # Summary
    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")

    passed = sum(1 for v in results.values() if v)
    total = len(results)

    for name, result in results.items():
        status = "PASS" if result else "FAIL"
        print(f"  {name}: {status}")

    print(f"\n  Total: {passed}/{total} passed")

    if passed == total:
        print("\n  ALL KERNELS WORKING!")
    else:
        print(f"\n  {total - passed} kernel(s) need fixing")
