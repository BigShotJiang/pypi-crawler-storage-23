"""
GPT-2 Training: VLAAdamW vs Standard AdamW
==========================================
Compare convergence, validation loss, and speed.
"""
import sys
sys.path.insert(0, '/mnt/c/SimGen/simgen')

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
import time
import math

# Check CUDA
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"Device: {torch.cuda.get_device_name() if device == 'cuda' else 'CPU'}")

# Import VLA
import vla_triton as vla

# =============================================================================
# GPT-2 Model (Small)
# =============================================================================

class GPT2Config:
    vocab_size = 50257
    n_embd = 256      # Small for testing
    n_head = 4
    n_layer = 4
    block_size = 128
    dropout = 0.1

class CausalSelfAttention(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.n_head = config.n_head
        self.n_embd = config.n_embd
        self.head_dim = config.n_embd // config.n_head

        self.c_attn = nn.Linear(config.n_embd, 3 * config.n_embd)
        self.c_proj = nn.Linear(config.n_embd, config.n_embd)
        self.dropout = nn.Dropout(config.dropout)

        # Causal mask
        self.register_buffer("mask", torch.tril(torch.ones(config.block_size, config.block_size))
                             .view(1, 1, config.block_size, config.block_size))

    def forward(self, x):
        B, T, C = x.shape

        qkv = self.c_attn(x)
        q, k, v = qkv.split(self.n_embd, dim=2)

        q = q.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        k = k.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        v = v.view(B, T, self.n_head, self.head_dim).transpose(1, 2)

        # Attention
        att = (q @ k.transpose(-2, -1)) * (1.0 / math.sqrt(self.head_dim))
        att = att.masked_fill(self.mask[:, :, :T, :T] == 0, float('-inf'))
        att = F.softmax(att, dim=-1)
        att = self.dropout(att)

        y = att @ v
        y = y.transpose(1, 2).contiguous().view(B, T, C)

        return self.dropout(self.c_proj(y))

class MLP(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.c_fc = nn.Linear(config.n_embd, 4 * config.n_embd)
        self.c_proj = nn.Linear(4 * config.n_embd, config.n_embd)
        self.dropout = nn.Dropout(config.dropout)

    def forward(self, x):
        x = F.gelu(self.c_fc(x))
        return self.dropout(self.c_proj(x))

class Block(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.ln_1 = nn.LayerNorm(config.n_embd)
        self.attn = CausalSelfAttention(config)
        self.ln_2 = nn.LayerNorm(config.n_embd)
        self.mlp = MLP(config)

    def forward(self, x):
        x = x + self.attn(self.ln_1(x))
        x = x + self.mlp(self.ln_2(x))
        return x

class GPT2(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config

        self.wte = nn.Embedding(config.vocab_size, config.n_embd)
        self.wpe = nn.Embedding(config.block_size, config.n_embd)
        self.drop = nn.Dropout(config.dropout)
        self.blocks = nn.ModuleList([Block(config) for _ in range(config.n_layer)])
        self.ln_f = nn.LayerNorm(config.n_embd)
        self.lm_head = nn.Linear(config.n_embd, config.vocab_size, bias=False)

        # Weight tying
        self.wte.weight = self.lm_head.weight

        self.apply(self._init_weights)
        print(f"GPT-2 params: {sum(p.numel() for p in self.parameters()):,}")

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, idx, targets=None):
        B, T = idx.shape

        pos = torch.arange(0, T, dtype=torch.long, device=idx.device)
        tok_emb = self.wte(idx)
        pos_emb = self.wpe(pos)
        x = self.drop(tok_emb + pos_emb)

        for block in self.blocks:
            x = block(x)

        x = self.ln_f(x)
        logits = self.lm_head(x)

        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)), targets.view(-1))

        return logits, loss

# =============================================================================
# Dataset
# =============================================================================

class TextDataset(Dataset):
    def __init__(self, data, block_size):
        self.data = data
        self.block_size = block_size

    def __len__(self):
        return len(self.data) - self.block_size

    def __getitem__(self, idx):
        x = self.data[idx:idx + self.block_size]
        y = self.data[idx + 1:idx + self.block_size + 1]
        return x, y

def load_wikitext():
    """Load WikiText-2 or generate synthetic data if not available."""
    try:
        from datasets import load_dataset
        dataset = load_dataset('wikitext', 'wikitext-2-raw-v1')

        # Simple tokenization (character-level for simplicity)
        text = '\n'.join(dataset['train']['text'])
        # Use simple char-to-int mapping (for testing)
        chars = sorted(list(set(text)))
        char_to_idx = {c: i for i, c in enumerate(chars)}

        train_data = torch.tensor([char_to_idx.get(c, 0) for c in text[:100000]], dtype=torch.long)
        val_data = torch.tensor([char_to_idx.get(c, 0) for c in text[100000:110000]], dtype=torch.long)

        return train_data, val_data, len(chars)
    except:
        print("WikiText not available, using synthetic data...")
        # Synthetic data for testing
        vocab_size = 1000
        train_data = torch.randint(0, vocab_size, (50000,))
        val_data = torch.randint(0, vocab_size, (5000,))
        return train_data, val_data, vocab_size

# =============================================================================
# Training Functions
# =============================================================================

def train_epoch(model, dataloader, optimizer, device):
    model.train()
    total_loss = 0
    n_batches = 0

    for x, y in dataloader:
        x, y = x.to(device), y.to(device)

        optimizer.zero_grad()
        _, loss = model(x, y)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        total_loss += loss.item()
        n_batches += 1

    return total_loss / n_batches

@torch.no_grad()
def evaluate(model, dataloader, device):
    model.eval()
    total_loss = 0
    n_batches = 0

    for x, y in dataloader:
        x, y = x.to(device), y.to(device)
        _, loss = model(x, y)
        total_loss += loss.item()
        n_batches += 1

    return total_loss / n_batches

# =============================================================================
# Main Comparison
# =============================================================================

def run_experiment(optimizer_type, model, train_loader, val_loader, config, n_epochs=10, lr=1e-3):
    """Run training with given optimizer."""

    if optimizer_type == 'adamw':
        optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
        name = "Standard AdamW"
    elif optimizer_type == 'vla':
        optimizer = vla.VLAAdamW(model.parameters(), lr=lr, weight_decay=0.01)
        name = "VLA AdamW"
    else:
        raise ValueError(f"Unknown optimizer: {optimizer_type}")

    print(f"\n{'='*60}")
    print(f"Training with {name}")
    print(f"{'='*60}")

    train_losses = []
    val_losses = []
    epoch_times = []

    for epoch in range(n_epochs):
        start_time = time.time()

        train_loss = train_epoch(model, train_loader, optimizer, device)
        val_loss = evaluate(model, val_loader, device)

        epoch_time = time.time() - start_time

        train_losses.append(train_loss)
        val_losses.append(val_loss)
        epoch_times.append(epoch_time)

        ppl = math.exp(val_loss) if val_loss < 10 else float('inf')
        print(f"Epoch {epoch+1:2d} | Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f} | PPL: {ppl:.2f} | Time: {epoch_time:.2f}s")

    return {
        'train_losses': train_losses,
        'val_losses': val_losses,
        'epoch_times': epoch_times,
        'final_val_loss': val_losses[-1],
        'total_time': sum(epoch_times),
        'avg_epoch_time': sum(epoch_times) / len(epoch_times),
    }

def main():
    print("="*60)
    print("GPT-2 Training: VLAAdamW vs Standard AdamW")
    print("="*60)

    # Config
    config = GPT2Config()
    config.vocab_size = 1000  # Will be updated
    batch_size = 32
    n_epochs = 10
    lr = 3e-4

    # Load data
    print("\nLoading data...")
    train_data, val_data, vocab_size = load_wikitext()
    config.vocab_size = vocab_size
    print(f"Vocab size: {vocab_size}")
    print(f"Train tokens: {len(train_data):,}")
    print(f"Val tokens: {len(val_data):,}")

    train_dataset = TextDataset(train_data, config.block_size)
    val_dataset = TextDataset(val_data, config.block_size)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, drop_last=True)

    print(f"Train batches: {len(train_loader)}")
    print(f"Val batches: {len(val_loader)}")

    # Train with Standard AdamW
    torch.manual_seed(42)
    model_std = GPT2(config).to(device)
    results_std = run_experiment('adamw', model_std, train_loader, val_loader, config, n_epochs, lr)

    # Train with VLA AdamW (same init)
    torch.manual_seed(42)
    model_vla = GPT2(config).to(device)
    results_vla = run_experiment('vla', model_vla, train_loader, val_loader, config, n_epochs, lr)

    # =============================================================================
    # Results Comparison
    # =============================================================================
    print("\n" + "="*60)
    print("RESULTS COMPARISON")
    print("="*60)

    print(f"\n{'Metric':<25} {'Standard AdamW':<20} {'VLA AdamW':<20} {'Difference':<15}")
    print("-"*80)

    # Final validation loss
    std_val = results_std['final_val_loss']
    vla_val = results_vla['final_val_loss']
    diff_val = vla_val - std_val
    better_val = "VLA" if vla_val < std_val else "Standard"
    print(f"{'Final Val Loss':<25} {std_val:<20.4f} {vla_val:<20.4f} {diff_val:+.4f} ({better_val})")

    # Perplexity
    std_ppl = math.exp(std_val) if std_val < 10 else float('inf')
    vla_ppl = math.exp(vla_val) if vla_val < 10 else float('inf')
    diff_ppl = vla_ppl - std_ppl
    print(f"{'Final Perplexity':<25} {std_ppl:<20.2f} {vla_ppl:<20.2f} {diff_ppl:+.2f}")

    # Training time
    std_time = results_std['total_time']
    vla_time = results_vla['total_time']
    speedup = std_time / vla_time
    print(f"{'Total Time (s)':<25} {std_time:<20.2f} {vla_time:<20.2f} {speedup:.2f}x")

    # Average epoch time
    std_epoch = results_std['avg_epoch_time']
    vla_epoch = results_vla['avg_epoch_time']
    print(f"{'Avg Epoch Time (s)':<25} {std_epoch:<20.2f} {vla_epoch:<20.2f}")

    # Convergence analysis
    print("\n" + "-"*60)
    print("CONVERGENCE ANALYSIS")
    print("-"*60)

    print(f"\n{'Epoch':<10} {'Std Val Loss':<15} {'VLA Val Loss':<15} {'Difference':<15}")
    for i in range(n_epochs):
        std_l = results_std['val_losses'][i]
        vla_l = results_vla['val_losses'][i]
        diff = vla_l - std_l
        print(f"{i+1:<10} {std_l:<15.4f} {vla_l:<15.4f} {diff:+.4f}")

    # Final verdict
    print("\n" + "="*60)
    print("VERDICT")
    print("="*60)

    if vla_val < std_val:
        improvement = (std_val - vla_val) / std_val * 100
        print(f"\nVLA AdamW achieved {improvement:.2f}% LOWER validation loss!")
    elif vla_val > std_val:
        regression = (vla_val - std_val) / std_val * 100
        print(f"\nStandard AdamW achieved {regression:.2f}% lower validation loss.")
    else:
        print("\nBoth optimizers achieved identical validation loss.")

    if vla_time < std_time:
        print(f"VLA AdamW was {speedup:.2f}x FASTER!")
    else:
        print(f"Standard AdamW was {1/speedup:.2f}x faster.")

    print("\nNote: FP64 optimizer state prevents drift over long training runs.")
    print("Benefits become more apparent with longer training (1000+ epochs).")

if __name__ == "__main__":
    main()
