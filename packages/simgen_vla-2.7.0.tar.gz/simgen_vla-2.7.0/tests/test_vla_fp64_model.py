"""
Test: FP64 model with VLA = Zero-error gradients?
=================================================
If we keep model in FP64 and use VLA, gradients should be EXACT.
"""
import torch
import torch.nn as nn
import sys
sys.path.insert(0, 'C:/SimGen')

device = 'cuda'
print(f"Device: {torch.cuda.get_device_name()}")

from simgen import vla

print("\n" + "="*60)
print("TEST: FP64 Model + VLA = Zero-Error Gradients?")
print("="*60)

torch.manual_seed(42)

# =============================================================================
# Test 1: Simple Matmul - FP64 throughout
# =============================================================================
print("\n--- Test 1: Matmul FP64 Throughout ---")

A = torch.randn(64, 64, device=device, dtype=torch.float64, requires_grad=True)
B = torch.randn(64, 64, device=device, dtype=torch.float64, requires_grad=True)

# Ground truth: Standard FP64 PyTorch
A_gt = A.detach().clone().requires_grad_(True)
B_gt = B.detach().clone().requires_grad_(True)
C_gt = torch.matmul(A_gt, B_gt)
loss_gt = C_gt.sum()
loss_gt.backward()

# VLA with FP64 input
vla.enable_vla(verbose=False)

A_vla = A.detach().clone().requires_grad_(True)
B_vla = B.detach().clone().requires_grad_(True)
C_vla = torch.matmul(A_vla, B_vla)  # Patched to VLA
loss_vla = C_vla.sum()
loss_vla.backward()

grad_A_err = (A_vla.grad - A_gt.grad).abs().max().item()
grad_B_err = (B_vla.grad - B_gt.grad).abs().max().item()

print(f"  grad_A error: {grad_A_err:.2e}")
print(f"  grad_B error: {grad_B_err:.2e}")

if grad_A_err == 0 and grad_B_err == 0:
    print("  ✓ ZERO ERROR - Gradients are EXACT!")
else:
    print(f"  Small error remains (likely from .to(dtype) conversion)")

vla.disable_vla(verbose=False)

# =============================================================================
# Test 2: Linear Layer - FP64 Model
# =============================================================================
print("\n--- Test 2: FP64 Linear Layer ---")

# Create FP64 linear layer
linear = nn.Linear(128, 64).to(device).double()
x = torch.randn(32, 128, device=device, dtype=torch.float64, requires_grad=True)
target = torch.randn(32, 64, device=device, dtype=torch.float64)

# Ground truth
linear_gt = nn.Linear(128, 64).to(device).double()
linear_gt.weight.data = linear.weight.data.clone()
linear_gt.bias.data = linear.bias.data.clone()
x_gt = x.detach().clone().requires_grad_(True)

out_gt = linear_gt(x_gt)
loss_gt = ((out_gt - target) ** 2).mean()
loss_gt.backward()

# VLA
vla.enable_vla(verbose=False)

linear_vla = nn.Linear(128, 64).to(device).double()
linear_vla.weight.data = linear.weight.data.clone()
linear_vla.bias.data = linear.bias.data.clone()
linear_vla.zero_grad()
x_vla = x.detach().clone().requires_grad_(True)

out_vla = linear_vla(x_vla)
loss_vla = ((out_vla - target) ** 2).mean()
loss_vla.backward()

grad_x_err = (x_vla.grad - x_gt.grad).abs().max().item()
grad_w_err = (linear_vla.weight.grad - linear_gt.weight.grad).abs().max().item()
grad_b_err = (linear_vla.bias.grad - linear_gt.bias.grad).abs().max().item()

print(f"  grad_x error: {grad_x_err:.2e}")
print(f"  grad_w error: {grad_w_err:.2e}")
print(f"  grad_b error: {grad_b_err:.2e}")

if grad_x_err == 0 and grad_w_err == 0 and grad_b_err == 0:
    print("  ✓ ZERO ERROR - All gradients EXACT!")

vla.disable_vla(verbose=False)

# =============================================================================
# Test 3: Full MLP - FP64
# =============================================================================
print("\n--- Test 3: FP64 MLP (multiple layers) ---")

class MLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(64, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 10)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

# Create FP64 MLP
model = MLP().to(device).double()
x = torch.randn(16, 64, device=device, dtype=torch.float64)
target = torch.randint(0, 10, (16,), device=device)

# Ground truth
model_gt = MLP().to(device).double()
model_gt.load_state_dict(model.state_dict())
out_gt = model_gt(x)
loss_gt = nn.functional.cross_entropy(out_gt, target)
loss_gt.backward()

# VLA
vla.enable_vla(verbose=False)

model_vla = MLP().to(device).double()
model_vla.load_state_dict(model.state_dict())
model_vla.zero_grad()
out_vla = model_vla(x)
loss_vla = nn.functional.cross_entropy(out_vla, target)
loss_vla.backward()

# Compare all gradients
total_err = 0
for (name, p_gt), (_, p_vla) in zip(model_gt.named_parameters(), model_vla.named_parameters()):
    err = (p_vla.grad - p_gt.grad).abs().max().item()
    total_err += err
    if err > 0:
        print(f"  {name}: {err:.2e}")

if total_err == 0:
    print("  ✓ ALL GRADIENTS ZERO ERROR!")
else:
    print(f"  Total error: {total_err:.2e}")

vla.disable_vla(verbose=False)

# =============================================================================
# Summary
# =============================================================================
print("\n" + "="*60)
print("SUMMARY")
print("="*60)
print("""
FP64 Model + VLA:
- Forward pass: EXACT (VLA cubins)
- Backward pass: Depends on operation

For TRULY zero-error gradients:
1. Use FP64 model (.double())
2. VLA cubins compute exact results
3. No FP64→FP32 conversion = no precision loss

The remaining small errors (if any) come from:
- PyTorch internal autograd ops not using VLA
- Some element-wise ops using standard FP64 not compensated
""")
