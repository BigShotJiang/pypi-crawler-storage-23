"""
Test Universal VLA Mode - All ops patched
=========================================
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import sys

sys.path.insert(0, '/mnt/c/SimGen')

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"Device: {device}")

from simgen import vla

print("\n" + "="*70)
print("UNIVERSAL VLA MODE TEST")
print("="*70)

# Enable VLA
vla.enable_vla()

# Test all patched operations
print("\nTesting all patched operations...")
errors = []

def test_op(name, fn, *args, **kwargs):
    try:
        result = fn(*args, **kwargs)
        print(f"  ✓ {name}")
        return True
    except Exception as e:
        print(f"  ✗ {name}: {e}")
        errors.append((name, str(e)))
        return False

# Create test tensors
x = torch.randn(4, 8, device=device)
y = torch.randn(8, 16, device=device)
v = torch.randn(8, device=device)
w = torch.randn(16, 8, device=device)

print("\n--- Matrix Operations ---")
test_op("torch.matmul", torch.matmul, x, y)
test_op("torch.mm", torch.mm, x, y)
test_op("torch.bmm", torch.bmm, x.unsqueeze(0), y.unsqueeze(0))
test_op("torch.addmm", torch.addmm, torch.randn(4, 16, device=device), x, y)
test_op("torch.mv", torch.mv, x, v)
test_op("torch.dot", torch.dot, v, v)

print("\n--- Reductions ---")
test_op("torch.sum", torch.sum, x)
test_op("torch.sum(dim)", torch.sum, x, dim=1)
test_op("torch.mean", torch.mean, x)
test_op("torch.var", torch.var, x)
test_op("torch.std", torch.std, x)
test_op("torch.norm", torch.norm, x)
test_op("torch.prod", torch.prod, torch.abs(x) + 0.1)  # Avoid negative products

print("\n--- Element-wise ---")
test_op("torch.exp", torch.exp, x)
test_op("torch.log", torch.log, torch.abs(x) + 0.1)
test_op("torch.sqrt", torch.sqrt, torch.abs(x))
test_op("torch.rsqrt", torch.rsqrt, torch.abs(x) + 0.1)

print("\n--- Linear & Loss ---")
test_op("F.linear", F.linear, x, w)
test_op("F.linear(bias)", F.linear, x, w, torch.randn(16, device=device))
logits = torch.randn(4, 10, device=device)
targets = torch.randint(0, 10, (4,), device=device)
test_op("F.cross_entropy", F.cross_entropy, logits, targets)
test_op("F.mse_loss", F.mse_loss, x, torch.randn_like(x))

print("\n--- Softmax & Normalization ---")
test_op("F.softmax", F.softmax, logits, dim=-1)
test_op("F.log_softmax", F.log_softmax, logits, dim=-1)
test_op("F.layer_norm", F.layer_norm, x, (8,))
ln_weight = torch.randn(8, device=device)
ln_bias = torch.randn(8, device=device)
test_op("F.layer_norm(affine)", F.layer_norm, x, (8,), ln_weight, ln_bias)

# Batch norm needs running stats
bn_mean = torch.zeros(8, device=device)
bn_var = torch.ones(8, device=device)
test_op("F.batch_norm", F.batch_norm, x.unsqueeze(0).permute(0, 2, 1), bn_mean, bn_var)

print("\n--- Activations ---")
test_op("F.gelu", F.gelu, x)
test_op("F.silu", F.silu, x)
test_op("F.relu", F.relu, x)
test_op("F.leaky_relu", F.leaky_relu, x)
test_op("torch.tanh", torch.tanh, x)
test_op("torch.sigmoid", torch.sigmoid, x)

print("\n--- Attention ---")
q = torch.randn(2, 4, 8, device=device)
k = torch.randn(2, 4, 8, device=device)
v_attn = torch.randn(2, 4, 8, device=device)
if hasattr(F, 'scaled_dot_product_attention'):
    test_op("F.scaled_dot_product_attention", F.scaled_dot_product_attention, q, k, v_attn)
else:
    print("  - F.scaled_dot_product_attention not available (PyTorch < 2.0)")

print("\n--- Embedding ---")
indices = torch.randint(0, 100, (4, 8), device=device)
emb_weight = torch.randn(100, 16, device=device)
test_op("F.embedding", F.embedding, indices, emb_weight)

# Test full model forward + backward
print("\n" + "="*70)
print("Testing Full Model (MiniGPT)")
print("="*70)

class MiniGPT(nn.Module):
    def __init__(self, vocab=100, dim=64, heads=4, layers=2):
        super().__init__()
        self.embed = nn.Embedding(vocab, dim)
        self.layers = nn.ModuleList([
            nn.TransformerEncoderLayer(dim, heads, dim*4, dropout=0, batch_first=True)
            for _ in range(layers)
        ])
        self.ln = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, vocab)

    def forward(self, x):
        x = self.embed(x)
        for layer in self.layers:
            x = layer(x)
        x = self.ln(x)
        return self.head(x)

model = MiniGPT().to(device)
x_input = torch.randint(0, 100, (2, 16), device=device)
targets = torch.randint(0, 100, (2, 16), device=device)

try:
    logits = model(x_input)
    loss = F.cross_entropy(logits.view(-1, 100), targets.view(-1))
    print(f"  Forward: ✓ (loss = {loss.item():.4f})")

    loss.backward()
    print(f"  Backward: ✓")

    # Check gradients exist
    has_grads = all(p.grad is not None for p in model.parameters() if p.requires_grad)
    print(f"  Gradients: {'✓' if has_grads else '✗'}")
except Exception as e:
    print(f"  ✗ Error: {e}")
    errors.append(("Full Model", str(e)))

# Disable and verify
vla.disable_vla()

print("\n" + "="*70)
print("SUMMARY")
print("="*70)

if errors:
    print(f"\n❌ {len(errors)} errors:")
    for name, err in errors:
        print(f"   - {name}: {err}")
else:
    print("\n✓ All tests passed!")
    print("\nUniversal VLA mode is ready!")
    print("Usage:")
    print("  from simgen import vla")
    print("  vla.enable_vla()  # All GPU ops now use exact arithmetic")
