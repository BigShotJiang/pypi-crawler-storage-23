"""
Compensated FP32 VLA Benchmark
==============================
Compares three approaches:
1. Standard PyTorch (FP32)
2. Compensated FP32 (TwoSum + FP64 accumulation - NEW)
3. Full FP64 VLA (FP64 everywhere - SLOW)

Goal: Compensated FP32 should be FASTER than standard AND more accurate.
"""

import torch
import torch.nn.functional as F
import time
import math
import sys

sys.path.insert(0, 'C:/SimGen')

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"Device: {torch.cuda.get_device_name() if device == 'cuda' else 'CPU'}")

# =============================================================================
# BENCHMARK OPERATIONS
# =============================================================================

def benchmark_sum(n=10_000_000, runs=100):
    """Benchmark sum operation."""
    print(f"\n{'='*60}")
    print(f"SUM BENCHMARK: {n:,} elements, {runs} runs")
    print(f"{'='*60}")

    x = torch.randn(n, device=device, dtype=torch.float32)

    # Ground truth (FP64)
    gt = x.double().sum().item()

    # 1. Standard PyTorch
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(runs):
        r_std = torch.sum(x)
    torch.cuda.synchronize()
    t_std = (time.perf_counter() - start) / runs * 1000
    err_std = abs(r_std.item() - gt)

    # 2. Compensated FP32
    from simgen.vla_compensated import compensated_sum
    # Warmup
    _ = compensated_sum(x)
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(runs):
        r_comp = compensated_sum(x)
    torch.cuda.synchronize()
    t_comp = (time.perf_counter() - start) / runs * 1000
    err_comp = abs(r_comp.item() - gt)

    # 3. Full FP64
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(runs):
        r_fp64 = x.double().sum()
    torch.cuda.synchronize()
    t_fp64 = (time.perf_counter() - start) / runs * 1000
    err_fp64 = abs(r_fp64.item() - gt)

    print(f"{'Method':<20} {'Time (ms)':>12} {'Error':>15} {'Speedup':>10}")
    print("-" * 57)
    print(f"{'Standard FP32':<20} {t_std:>12.3f} {err_std:>15.2e} {1.0:>10.2f}x")
    print(f"{'Compensated FP32':<20} {t_comp:>12.3f} {err_comp:>15.2e} {t_std/t_comp:>10.2f}x")
    print(f"{'Full FP64':<20} {t_fp64:>12.3f} {err_fp64:>15.2e} {t_std/t_fp64:>10.2f}x")

    if err_std > 0:
        print(f"\nCompensated is {err_std/max(err_comp, 1e-20):.0f}x more accurate than Standard")


def benchmark_dot(n=10_000_000, runs=100):
    """Benchmark dot product."""
    print(f"\n{'='*60}")
    print(f"DOT PRODUCT BENCHMARK: {n:,} elements, {runs} runs")
    print(f"{'='*60}")

    a = torch.randn(n, device=device, dtype=torch.float32)
    b = torch.randn(n, device=device, dtype=torch.float32)

    # Ground truth
    gt = (a.double() * b.double()).sum().item()

    # 1. Standard PyTorch
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(runs):
        r_std = torch.dot(a, b)
    torch.cuda.synchronize()
    t_std = (time.perf_counter() - start) / runs * 1000
    err_std = abs(r_std.item() - gt)

    # 2. Compensated FP32
    from simgen.vla_compensated import compensated_dot
    _ = compensated_dot(a, b)  # Warmup
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(runs):
        r_comp = compensated_dot(a, b)
    torch.cuda.synchronize()
    t_comp = (time.perf_counter() - start) / runs * 1000
    err_comp = abs(r_comp.item() - gt)

    # 3. Full FP64
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(runs):
        r_fp64 = torch.dot(a.double(), b.double())
    torch.cuda.synchronize()
    t_fp64 = (time.perf_counter() - start) / runs * 1000
    err_fp64 = abs(r_fp64.item() - gt)

    print(f"{'Method':<20} {'Time (ms)':>12} {'Error':>15} {'Speedup':>10}")
    print("-" * 57)
    print(f"{'Standard FP32':<20} {t_std:>12.3f} {err_std:>15.2e} {1.0:>10.2f}x")
    print(f"{'Compensated FP32':<20} {t_comp:>12.3f} {err_comp:>15.2e} {t_std/t_comp:>10.2f}x")
    print(f"{'Full FP64':<20} {t_fp64:>12.3f} {err_fp64:>15.2e} {t_std/t_fp64:>10.2f}x")

    if err_std > 0:
        print(f"\nCompensated is {err_std/max(err_comp, 1e-20):.0f}x more accurate than Standard")


def benchmark_softmax(batch=1024, seq=512, runs=100):
    """Benchmark softmax."""
    print(f"\n{'='*60}")
    print(f"SOFTMAX BENCHMARK: {batch}x{seq}, {runs} runs")
    print(f"{'='*60}")

    x = torch.randn(batch, seq, device=device, dtype=torch.float32)

    # Ground truth
    gt = F.softmax(x.double(), dim=-1)

    # 1. Standard PyTorch
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(runs):
        r_std = F.softmax(x, dim=-1)
    torch.cuda.synchronize()
    t_std = (time.perf_counter() - start) / runs * 1000
    err_std = (r_std.double() - gt).abs().max().item()

    # 2. Compensated FP32
    from simgen.vla_compensated import compensated_softmax
    _ = compensated_softmax(x, dim=-1)  # Warmup
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(runs):
        r_comp = compensated_softmax(x, dim=-1)
    torch.cuda.synchronize()
    t_comp = (time.perf_counter() - start) / runs * 1000
    err_comp = (r_comp.double() - gt).abs().max().item()

    # 3. Full FP64
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(runs):
        r_fp64 = F.softmax(x.double(), dim=-1)
    torch.cuda.synchronize()
    t_fp64 = (time.perf_counter() - start) / runs * 1000
    err_fp64 = (r_fp64 - gt).abs().max().item()

    print(f"{'Method':<20} {'Time (ms)':>12} {'Max Error':>15} {'Speedup':>10}")
    print("-" * 57)
    print(f"{'Standard FP32':<20} {t_std:>12.3f} {err_std:>15.2e} {1.0:>10.2f}x")
    print(f"{'Compensated FP32':<20} {t_comp:>12.3f} {err_comp:>15.2e} {t_std/t_comp:>10.2f}x")
    print(f"{'Full FP64':<20} {t_fp64:>12.3f} {err_fp64:>15.2e} {t_std/t_fp64:>10.2f}x")

    if err_std > 0:
        print(f"\nCompensated is {err_std/max(err_comp, 1e-20):.0f}x more accurate than Standard")


def benchmark_layernorm(batch=1024, dim=768, runs=100):
    """Benchmark layer norm."""
    print(f"\n{'='*60}")
    print(f"LAYER NORM BENCHMARK: {batch}x{dim}, {runs} runs")
    print(f"{'='*60}")

    x = torch.randn(batch, dim, device=device, dtype=torch.float32)
    weight = torch.ones(dim, device=device, dtype=torch.float32)
    bias = torch.zeros(dim, device=device, dtype=torch.float32)

    # Ground truth
    gt = F.layer_norm(x.double(), (dim,), weight.double(), bias.double())

    # 1. Standard PyTorch
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(runs):
        r_std = F.layer_norm(x, (dim,), weight, bias)
    torch.cuda.synchronize()
    t_std = (time.perf_counter() - start) / runs * 1000
    err_std = (r_std.double() - gt).abs().max().item()

    # 2. Compensated FP32
    from simgen.vla_compensated import compensated_layernorm
    _ = compensated_layernorm(x, (dim,), weight, bias)  # Warmup
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(runs):
        r_comp = compensated_layernorm(x, (dim,), weight, bias)
    torch.cuda.synchronize()
    t_comp = (time.perf_counter() - start) / runs * 1000
    err_comp = (r_comp.double() - gt).abs().max().item()

    # 3. Full FP64
    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(runs):
        r_fp64 = F.layer_norm(x.double(), (dim,), weight.double(), bias.double())
    torch.cuda.synchronize()
    t_fp64 = (time.perf_counter() - start) / runs * 1000
    err_fp64 = (r_fp64 - gt).abs().max().item()

    print(f"{'Method':<20} {'Time (ms)':>12} {'Max Error':>15} {'Speedup':>10}")
    print("-" * 57)
    print(f"{'Standard FP32':<20} {t_std:>12.3f} {err_std:>15.2e} {1.0:>10.2f}x")
    print(f"{'Compensated FP32':<20} {t_comp:>12.3f} {err_comp:>15.2e} {t_std/t_comp:>10.2f}x")
    print(f"{'Full FP64':<20} {t_fp64:>12.3f} {err_fp64:>15.2e} {t_std/t_fp64:>10.2f}x")

    if err_std > 0:
        print(f"\nCompensated is {err_std/max(err_comp, 1e-20):.0f}x more accurate than Standard")


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("COMPENSATED FP32 VLA BENCHMARK")
    print("=" * 60)
    print("""
Goal: Compensated FP32 should be:
  - FASTER than or equal to standard FP32 (uses tensor cores)
  - MORE ACCURATE (captures all rounding errors)
  - Much FASTER than full FP64

This is achieved through TwoSum/TwoProduct:
  - Compute in FP32 (fast)
  - Capture error term with FMA (free on modern GPUs)
  - Accumulate both in FP64 (minimal overhead)
""")

    benchmark_sum()
    benchmark_dot()
    benchmark_softmax()
    benchmark_layernorm()

    print("\n" + "=" * 60)
    print("CONCLUSION")
    print("=" * 60)
    print("""
Compensated FP32 VLA provides:
  1. Near-FP64 accuracy (captures ALL rounding errors)
  2. Near-FP32 speed (TwoSum/TwoProduct are essentially free)
  3. Works with existing PyTorch code (monkey-patching)

Use with VLAAdamW optimizer for complete VLA training stack.
""")
