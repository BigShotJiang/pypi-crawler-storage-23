"""Debug: Examine block-level results."""
import torch
import triton
import triton.language as tl
import sys
sys.path.insert(0, '/mnt/c/SimGen')

from simgen.vla import _vla_sum_kernel, _vla_reduce_kernel, _ensure_cuda

# Test data
x = torch.tensor([1e16] + [1.0] * 10000 + [-1e16], dtype=torch.float32, device='cuda')
n = x.numel()
BLOCK = 256
n_blocks = (n + BLOCK - 1) // BLOCK

print(f"n = {n}, BLOCK = {BLOCK}, n_blocks = {n_blocks}")

# Phase 1: Per-block sum
block_limbs = torch.zeros(n_blocks * 4, device='cuda', dtype=torch.float64)
_vla_sum_kernel[(n_blocks,)](x.flatten(), block_limbs, n, BLOCK=BLOCK)
torch.cuda.synchronize()

# Examine block results
print("\nBlock results (hi, lo):")
total_hi = 0.0
total_lo = 0.0
for b in range(n_blocks):
    hi = block_limbs[b * 4 + 0].item()
    lo = block_limbs[b * 4 + 1].item()
    total_hi += hi
    total_lo += lo
    if b < 3 or b >= n_blocks - 2:
        print(f"  Block {b}: hi={hi:20.6f}, lo={lo:20.6f}")
    elif b == 3:
        print("  ...")

print(f"\nSimple sum of all hi values: {total_hi}")
print(f"Simple sum of all lo values: {total_lo}")
print(f"Total (hi + lo): {total_hi + total_lo}")

# Manual 2-limb reduction of block results
print("\nManual 2-limb reduction of block results:")
sum_hi = 0.0
sum_lo = 0.0
for b in range(n_blocks):
    hi = block_limbs[b * 4 + 0].item()
    lo = block_limbs[b * 4 + 1].item()
    # Add hi with 2-limb
    new_hi = sum_hi + hi
    sum_lo = sum_lo + (hi - (new_hi - sum_hi))
    sum_hi = new_hi
    # Add lo with 2-limb
    new_hi = sum_hi + lo
    sum_lo = sum_lo + (lo - (new_hi - sum_hi))
    sum_hi = new_hi

print(f"  sum_hi = {sum_hi}")
print(f"  sum_lo = {sum_lo}")
print(f"  Total = {sum_hi + sum_lo}")

# Phase 2: Triton reduce
final_limbs = torch.zeros(4, device='cuda', dtype=torch.float64)
_vla_reduce_kernel[(1,)](block_limbs, final_limbs, n_blocks)
torch.cuda.synchronize()

print(f"\nTriton reduce result:")
print(f"  final_limbs[0] = {final_limbs[0].item()}")
print(f"  final_limbs[1] = {final_limbs[1].item()}")
print(f"  final_limbs[2] = {final_limbs[2].item()}")
print(f"  final_limbs[3] = {final_limbs[3].item()}")
print(f"  Sum of limbs = {final_limbs.sum().item()}")

# Compare
print(f"\nExpected: 10000.0")
print(f"Got: {final_limbs.sum().item()}")
print(f"Difference: {10000.0 - final_limbs.sum().item()}")
