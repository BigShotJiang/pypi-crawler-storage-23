"""
VLA Optimizer vs Full VLA Mode - GPT-2 on WikiText-2
=====================================================
Compares three approaches:
1. Standard PyTorch (baseline)
2. VLA Optimizer only (FP64 state, standard forward/backward)
3. Full VLA mode (all ops in FP64 - current approach)

Hypothesis: VLA Optimizer alone gives most benefit with minimal overhead.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import time
import sys

sys.path.insert(0, '/mnt/c/SimGen')

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"Device: {torch.cuda.get_device_name() if device == 'cuda' else 'CPU'}")

# =============================================================================
# SIMPLE GPT-2 MODEL
# =============================================================================

class GPT2Block(nn.Module):
    def __init__(self, dim, heads, dropout=0.1):
        super().__init__()
        self.ln1 = nn.LayerNorm(dim)
        self.attn = nn.MultiheadAttention(dim, heads, dropout=dropout, batch_first=True)
        self.ln2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(
            nn.Linear(dim, dim * 4),
            nn.GELU(),
            nn.Linear(dim * 4, dim),
            nn.Dropout(dropout)
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, mask=None):
        # Self-attention with residual
        x_ln = self.ln1(x)
        attn_out, _ = self.attn(x_ln, x_ln, x_ln, attn_mask=mask, need_weights=False)
        x = x + self.dropout(attn_out)
        # MLP with residual
        x = x + self.mlp(self.ln2(x))
        return x


class GPT2(nn.Module):
    def __init__(self, vocab_size, dim=256, heads=4, layers=4, max_seq=128, dropout=0.1):
        super().__init__()
        self.tok_emb = nn.Embedding(vocab_size, dim)
        self.pos_emb = nn.Embedding(max_seq, dim)
        self.blocks = nn.ModuleList([
            GPT2Block(dim, heads, dropout) for _ in range(layers)
        ])
        self.ln_f = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, vocab_size, bias=False)
        self.head.weight = self.tok_emb.weight  # Weight tying
        self.max_seq = max_seq
        self.dim = dim

        # Causal mask
        self.register_buffer('causal_mask', torch.triu(
            torch.ones(max_seq, max_seq, dtype=torch.bool), diagonal=1
        ))

    def forward(self, x):
        B, T = x.shape
        tok = self.tok_emb(x)
        pos = self.pos_emb(torch.arange(T, device=x.device))
        x = tok + pos

        mask = self.causal_mask[:T, :T]
        for block in self.blocks:
            x = block(x, mask)

        x = self.ln_f(x)
        logits = self.head(x)
        return logits


# =============================================================================
# DATA LOADING
# =============================================================================

def load_wikitext2(seq_len=64, batch_size=32):
    """Load WikiText-2 dataset."""
    from datasets import load_dataset

    print("Loading WikiText-2...")
    dataset = load_dataset("wikitext", "wikitext-2-raw-v1")

    # Build vocabulary from training data
    train_text = " ".join([t for t in dataset['train']['text'] if t.strip()])
    words = train_text.split()

    # Build vocab (top N words)
    from collections import Counter
    word_counts = Counter(words)
    vocab = ['<pad>', '<unk>'] + [w for w, c in word_counts.most_common(10000) if c >= 3]
    word2idx = {w: i for i, w in enumerate(vocab)}

    print(f"Vocab size: {len(vocab)}")

    def tokenize(text):
        return [word2idx.get(w, 1) for w in text.split()]  # 1 = <unk>

    # Tokenize datasets
    train_tokens = tokenize(" ".join([t for t in dataset['train']['text'] if t.strip()]))
    val_tokens = tokenize(" ".join([t for t in dataset['validation']['text'] if t.strip()]))

    def create_batches(tokens, seq_len, batch_size):
        # Create sequences
        n_seqs = len(tokens) // (seq_len + 1)
        tokens = tokens[:n_seqs * (seq_len + 1)]
        data = torch.tensor(tokens, dtype=torch.long).view(n_seqs, seq_len + 1)

        # Shuffle and batch
        indices = torch.randperm(n_seqs)
        batches = []
        for i in range(0, n_seqs - batch_size, batch_size):
            batch_idx = indices[i:i + batch_size]
            batch = data[batch_idx]
            x = batch[:, :-1]
            y = batch[:, 1:]
            batches.append((x, y))
        return batches

    train_batches = create_batches(train_tokens, seq_len, batch_size)
    val_batches = create_batches(val_tokens, seq_len, batch_size)

    print(f"Train batches: {len(train_batches)}, Val batches: {len(val_batches)}")

    return train_batches, val_batches, len(vocab)


def evaluate(model, batches, device):
    """Evaluate model and return perplexity."""
    model.eval()
    total_loss = 0
    total_tokens = 0

    with torch.no_grad():
        for x, y in batches[:50]:  # Limit for speed
            x, y = x.to(device), y.to(device)
            logits = model(x)
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)), y.view(-1))
            total_loss += loss.item() * y.numel()
            total_tokens += y.numel()

    avg_loss = total_loss / total_tokens
    ppl = math.exp(avg_loss)
    return ppl


def train_epoch(model, optimizer, batches, device, max_batches=None):
    """Train for one epoch."""
    model.train()
    total_loss = 0
    n_batches = 0

    for i, (x, y) in enumerate(batches):
        if max_batches and i >= max_batches:
            break

        x, y = x.to(device), y.to(device)

        optimizer.zero_grad()
        logits = model(x)
        loss = F.cross_entropy(logits.view(-1, logits.size(-1)), y.view(-1))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        total_loss += loss.item()
        n_batches += 1

    return total_loss / n_batches


# =============================================================================
# MAIN COMPARISON
# =============================================================================

def main():
    print("=" * 70)
    print("VLA Optimizer vs Full VLA Mode - GPT-2 on WikiText-2")
    print("=" * 70)

    # Hyperparameters
    SEQ_LEN = 64
    BATCH_SIZE = 32
    EPOCHS = 3
    MAX_BATCHES = 100  # Limit for quick testing
    LR = 1e-3

    # Load data
    train_batches, val_batches, vocab_size = load_wikitext2(SEQ_LEN, BATCH_SIZE)

    results = {}

    # =========================================================================
    # TEST 1: Standard PyTorch (baseline)
    # =========================================================================
    print("\n" + "=" * 70)
    print("TEST 1: Standard PyTorch Training")
    print("=" * 70)

    torch.manual_seed(42)
    model = GPT2(vocab_size, dim=256, heads=4, layers=4, max_seq=SEQ_LEN).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR)

    print(f"Model params: {sum(p.numel() for p in model.parameters()):,}")

    start = time.perf_counter()
    std_ppls = []
    for epoch in range(EPOCHS):
        train_loss = train_epoch(model, optimizer, train_batches, device, MAX_BATCHES)
        val_ppl = evaluate(model, val_batches, device)
        std_ppls.append(val_ppl)
        print(f"  Epoch {epoch+1}: Train Loss={train_loss:.4f}, Val PPL={val_ppl:.2f}")
    std_time = time.perf_counter() - start
    results['standard'] = {'ppl': std_ppls[-1], 'time': std_time, 'ppls': std_ppls}

    # =========================================================================
    # TEST 2: VLA Optimizer Only (FP64 state, standard forward/backward)
    # =========================================================================
    print("\n" + "=" * 70)
    print("TEST 2: VLA Optimizer Only (FP64 state)")
    print("=" * 70)

    from simgen.vla_optimizer import VLAAdamW

    torch.manual_seed(42)
    model = GPT2(vocab_size, dim=256, heads=4, layers=4, max_seq=SEQ_LEN).to(device)
    optimizer = VLAAdamW(model.parameters(), lr=LR)

    start = time.perf_counter()
    vla_opt_ppls = []
    for epoch in range(EPOCHS):
        train_loss = train_epoch(model, optimizer, train_batches, device, MAX_BATCHES)
        val_ppl = evaluate(model, val_batches, device)
        vla_opt_ppls.append(val_ppl)
        print(f"  Epoch {epoch+1}: Train Loss={train_loss:.4f}, Val PPL={val_ppl:.2f}")
    vla_opt_time = time.perf_counter() - start
    results['vla_optimizer'] = {'ppl': vla_opt_ppls[-1], 'time': vla_opt_time, 'ppls': vla_opt_ppls}

    # =========================================================================
    # TEST 3: Full VLA Mode (all ops in FP64)
    # =========================================================================
    print("\n" + "=" * 70)
    print("TEST 3: Full VLA Mode (all ops)")
    print("=" * 70)

    from simgen import vla
    vla.enable_vla()

    torch.manual_seed(42)
    model = GPT2(vocab_size, dim=256, heads=4, layers=4, max_seq=SEQ_LEN).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=LR)

    start = time.perf_counter()
    full_vla_ppls = []
    for epoch in range(EPOCHS):
        train_loss = train_epoch(model, optimizer, train_batches, device, MAX_BATCHES)
        val_ppl = evaluate(model, val_batches, device)
        full_vla_ppls.append(val_ppl)
        print(f"  Epoch {epoch+1}: Train Loss={train_loss:.4f}, Val PPL={val_ppl:.2f}")
    full_vla_time = time.perf_counter() - start
    results['full_vla'] = {'ppl': full_vla_ppls[-1], 'time': full_vla_time, 'ppls': full_vla_ppls}

    vla.disable_vla()

    # =========================================================================
    # TEST 4: VLA Optimizer + Full VLA Mode (best of both)
    # =========================================================================
    print("\n" + "=" * 70)
    print("TEST 4: VLA Optimizer + Full VLA Mode")
    print("=" * 70)

    vla.enable_vla()

    torch.manual_seed(42)
    model = GPT2(vocab_size, dim=256, heads=4, layers=4, max_seq=SEQ_LEN).to(device)
    optimizer = VLAAdamW(model.parameters(), lr=LR)

    start = time.perf_counter()
    combined_ppls = []
    for epoch in range(EPOCHS):
        train_loss = train_epoch(model, optimizer, train_batches, device, MAX_BATCHES)
        val_ppl = evaluate(model, val_batches, device)
        combined_ppls.append(val_ppl)
        print(f"  Epoch {epoch+1}: Train Loss={train_loss:.4f}, Val PPL={val_ppl:.2f}")
    combined_time = time.perf_counter() - start
    results['combined'] = {'ppl': combined_ppls[-1], 'time': combined_time, 'ppls': combined_ppls}

    vla.disable_vla()

    # =========================================================================
    # RESULTS
    # =========================================================================
    print("\n" + "=" * 70)
    print("RESULTS")
    print("=" * 70)

    baseline_ppl = results['standard']['ppl']
    baseline_time = results['standard']['time']

    print(f"\n{'Method':<30} {'Final PPL':>12} {'Time':>10} {'PPL Change':>12} {'Slowdown':>10}")
    print("-" * 74)

    for name, data in results.items():
        ppl_change = (baseline_ppl - data['ppl']) / baseline_ppl * 100
        slowdown = data['time'] / baseline_time
        print(f"{name:<30} {data['ppl']:>12.2f} {data['time']:>9.1f}s {ppl_change:>+11.1f}% {slowdown:>9.1f}x")

    print("\nPer-epoch PPL:")
    for name, data in results.items():
        ppls_str = " -> ".join([f"{p:.2f}" for p in data['ppls']])
        print(f"  {name}: {ppls_str}")

    # Analysis
    print("\n" + "=" * 70)
    print("ANALYSIS")
    print("=" * 70)

    # Find best approach
    best_name = min(results, key=lambda k: results[k]['ppl'])
    print(f"\nBest PPL: {best_name} ({results[best_name]['ppl']:.2f})")

    # Find best efficiency (PPL improvement per time)
    efficiencies = {}
    for name, data in results.items():
        ppl_improvement = baseline_ppl - data['ppl']
        time_cost = data['time'] - baseline_time
        if time_cost > 0:
            efficiency = ppl_improvement / time_cost
        else:
            efficiency = float('inf') if ppl_improvement > 0 else 0
        efficiencies[name] = efficiency

    best_efficiency = max(efficiencies, key=lambda k: efficiencies[k])
    print(f"Best efficiency: {best_efficiency} ({efficiencies[best_efficiency]:.4f} PPL/second)")

    print("\nConclusion:")
    if results['vla_optimizer']['ppl'] < results['standard']['ppl']:
        opt_improvement = (results['standard']['ppl'] - results['vla_optimizer']['ppl']) / results['standard']['ppl'] * 100
        opt_slowdown = results['vla_optimizer']['time'] / results['standard']['time']
        print(f"  VLA Optimizer alone gives {opt_improvement:.1f}% PPL improvement with {opt_slowdown:.2f}x slowdown")
        print(f"  This is the recommended approach for most use cases.")
    else:
        print(f"  VLA Optimizer did not improve PPL in this test.")
        print(f"  Consider running for more epochs to see long-term benefits.")

    if results['full_vla']['ppl'] < results['standard']['ppl']:
        full_improvement = (results['standard']['ppl'] - results['full_vla']['ppl']) / results['standard']['ppl'] * 100
        full_slowdown = results['full_vla']['time'] / results['standard']['time']
        print(f"\n  Full VLA mode gives {full_improvement:.1f}% PPL improvement with {full_slowdown:.1f}x slowdown")
    else:
        print(f"\n  Full VLA mode did not improve PPL. The overhead may outweigh benefits for short training.")


if __name__ == "__main__":
    main()
