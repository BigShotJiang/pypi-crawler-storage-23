"""
SimGen VLA - Zero-Error GPU Arithmetic for PyTorch
===================================================
Precompiled CUDA kernels for exact computation.
"""

from setuptools import setup, find_packages

NAME = "simgen-vla"
VERSION = "2.6.0"
DESCRIPTION = "VLA: Zero-Error GPU Arithmetic for PyTorch. Exact results, every calculation."

setup(
    name=NAME,
    version=VERSION,
    description=DESCRIPTION,
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Clouthier Simulation Labs",
    author_email="kyle@simgen.dev",
    url="https://simgen.dev",
    packages=["simgen", "simgen.vla", "simgen.cubin_native"],
    package_data={
        "simgen": [
            "__init__.py",
            "vla_runtime.py",
            "vla_runtime.*.pyd",  # Compiled extension (IP protected)
            "vla_optimizer.py",
            "cubin_loader_native.py",
        ],
        "simgen.vla": [
            "__init__.py",
            "auto.py",
            "autograd.py",
            "autograd.*.pyd",  # Compiled extension (IP protected)
        ],
        "simgen.cubin_native": ["*.cubin", "manifest.json"],
    },
    exclude_package_data={
        "simgen": ["cuda/*", "archive/*", "*.cu", "*.cuh", "vla_triton.py"],
    },
    install_requires=[
        "torch>=2.0",
        "cupy-cuda12x>=12.0",
    ],
    extras_require={
        "dev": ["pytest", "mpmath"],
    },
    python_requires=">=3.10",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Intended Audience :: Developers",
        "Intended Audience :: Financial and Insurance Industry",
        "Operating System :: POSIX :: Linux",
        "Operating System :: Microsoft :: Windows",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Mathematics",
    ],
)
