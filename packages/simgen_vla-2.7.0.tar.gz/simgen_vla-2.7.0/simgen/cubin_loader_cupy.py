"""
SimGen VLA Cubin Loader - CuPy Backend
======================================
Loads and launches precompiled CUDA kernels using CuPy.
Works on Kaggle and anywhere CuPy is available.
No cuda-python dependency required.
"""

import os
import json
import ctypes
import torch
from pathlib import Path
from typing import Dict, Optional, Tuple, Any

try:
    import cupy as cp
    CUPY_AVAILABLE = True
except ImportError:
    CUPY_AVAILABLE = False

__all__ = ["CubinLoaderCuPy", "get_gpu_arch", "SUPPORTED_ARCHS"]

SUPPORTED_ARCHS = [75, 80, 86, 89, 90]


def get_gpu_arch() -> int:
    """Get the compute capability of the current GPU."""
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA not available")
    props = torch.cuda.get_device_properties(0)
    return props.major * 10 + props.minor


def _find_best_arch(target_arch: int) -> int:
    """Find the best compatible architecture for the target GPU."""
    compatible = [a for a in SUPPORTED_ARCHS if a <= target_arch]
    if not compatible:
        raise RuntimeError(
            f"GPU architecture sm_{target_arch} is not supported. "
            f"Minimum required: sm_{min(SUPPORTED_ARCHS)}"
        )
    return max(compatible)


class CubinLoaderCuPy:
    """
    Loads and manages precompiled CUDA kernels using CuPy.

    This loader uses CuPy's RawModule to load cubins, avoiding
    the need for cuda-python which isn't available on all platforms.
    """

    def __init__(self, cubin_dir: Optional[str] = None):
        if not CUPY_AVAILABLE:
            raise ImportError("CuPy is required but not installed. pip install cupy-cuda12x")

        if cubin_dir is None:
            module_dir = os.path.dirname(os.path.abspath(__file__))
            cubin_dir = os.path.join(module_dir, "cubin")

        self.cubin_dir = Path(cubin_dir)
        self._modules: Dict[str, cp.RawModule] = {}
        self._kernels: Dict[str, "CubinKernelCuPy"] = {}
        self._metadata: Dict[str, dict] = {}

        # Load manifest
        manifest_path = self.cubin_dir / "manifest.json"
        if manifest_path.exists():
            with open(manifest_path) as f:
                self.manifest = json.load(f)
        else:
            self.manifest = {}

        # Detect GPU architecture
        self.gpu_arch = get_gpu_arch()
        self.cubin_arch = _find_best_arch(self.gpu_arch)
        self.sm_name = f"sm_{self.cubin_arch}"

    def _load_kernel(self, kernel_name: str) -> "CubinKernelCuPy":
        """Load a kernel and its metadata."""
        if kernel_name in self._kernels:
            return self._kernels[kernel_name]

        # Find cubin and metadata files
        cubin_file = f"{kernel_name}_{self.sm_name}.cubin"
        meta_file = f"{kernel_name}_{self.sm_name}.json"

        cubin_path = self.cubin_dir / cubin_file
        meta_path = self.cubin_dir / meta_file

        if not cubin_path.exists():
            raise FileNotFoundError(f"Cubin not found: {cubin_path}")
        if not meta_path.exists():
            raise FileNotFoundError(f"Metadata not found: {meta_path}")

        # Load metadata
        with open(meta_path) as f:
            metadata = json.load(f)

        # Load cubin as CuPy RawModule
        module = cp.RawModule(path=str(cubin_path))

        # Get kernel function
        function = module.get_function(kernel_name)

        self._modules[kernel_name] = module
        self._metadata[kernel_name] = metadata

        kernel = CubinKernelCuPy(function, kernel_name, metadata)
        self._kernels[kernel_name] = kernel
        return kernel

    def get_kernel(self, kernel_name: str) -> "CubinKernelCuPy":
        """Get a kernel by name."""
        return self._load_kernel(kernel_name)

    def list_kernels(self) -> list:
        """List all available kernel names."""
        return list(self.manifest.keys())

    def get_info(self) -> dict:
        """Get loader information."""
        return {
            "backend": "cupy",
            "gpu_arch": self.gpu_arch,
            "cubin_arch": self.cubin_arch,
            "sm_name": self.sm_name,
            "cubin_dir": str(self.cubin_dir),
            "kernels_available": len(self.manifest),
            "kernels_loaded": len(self._kernels),
        }


class CubinKernelCuPy:
    """Wrapper for a loaded CUDA kernel function using CuPy."""

    def __init__(self, function: cp.RawKernel, name: str, metadata: dict):
        self.function = function
        self.name = name
        self.metadata = metadata
        self.num_warps = metadata.get("num_warps", 4)
        self.shared_mem = metadata.get("shared", 0)
        self.constexprs = metadata.get("constexprs", {})
        self.signature = metadata.get("signature", {})

    def __call__(self, grid: Tuple[int, ...], *args, stream=None):
        """Launch the kernel with the given grid and arguments.

        Args:
            grid: Tuple of (gridX,) or (gridX, gridY) or (gridX, gridY, gridZ)
            *args: Kernel arguments (tensors and scalars) - DO NOT include constexprs
            stream: CUDA stream (None for default)
        """
        # Normalize grid to tuple
        if isinstance(grid, int):
            grid = (grid,)

        # Block size from num_warps (32 threads per warp)
        block_size = self.num_warps * 32
        block = (block_size,)

        # Convert arguments to CuPy format
        cupy_args = []
        for arg in args:
            if isinstance(arg, torch.Tensor):
                # Convert PyTorch tensor to CuPy array (zero-copy via DLPack)
                cupy_args.append(cp.asarray(arg))
            elif isinstance(arg, cp.ndarray):
                cupy_args.append(arg)
            elif isinstance(arg, int):
                cupy_args.append(cp.int32(arg))
            elif isinstance(arg, float):
                cupy_args.append(cp.float64(arg))
            else:
                cupy_args.append(arg)

        # IMPORTANT: Triton kernels expect 2 scratch pointers at the end
        # These are for intermediate storage and can be null (0)
        scratch1 = cp.uint64(0)
        scratch2 = cp.uint64(0)
        cupy_args.extend([scratch1, scratch2])

        # Launch kernel
        self.function(grid, block, tuple(cupy_args), shared_mem=self.shared_mem)


def torch_to_cupy(tensor: torch.Tensor) -> cp.ndarray:
    """Zero-copy conversion from PyTorch tensor to CuPy array."""
    return cp.asarray(tensor)


def cupy_to_torch(array: cp.ndarray) -> torch.Tensor:
    """Zero-copy conversion from CuPy array to PyTorch tensor."""
    return torch.as_tensor(array, device='cuda')


# Test function
def test_cupy_loader():
    """Test the CuPy-based cubin loader."""
    print("Testing CuPy Cubin Loader...")

    loader = CubinLoaderCuPy()
    print(f"Loader info: {loader.get_info()}")

    # Test with a simple kernel
    kernel = loader.get_kernel("_vla_neg_kernel")
    print(f"Loaded kernel: {kernel.name}")
    print(f"  num_warps: {kernel.num_warps}")
    print(f"  signature: {kernel.signature}")

    # Create test data
    n = 100
    x = torch.randn(n, device='cuda', dtype=torch.float64)
    out = torch.zeros(n, device='cuda', dtype=torch.float64)

    # Run kernel
    grid = ((n + 1023) // 1024,)
    kernel(grid, x, out, n)
    torch.cuda.synchronize()

    # Verify
    expected = -x
    max_diff = (out - expected).abs().max().item()
    print(f"Max difference: {max_diff:.2e}")

    if max_diff < 1e-10:
        print("SUCCESS!")
        return True
    else:
        print("FAILED!")
        return False


if __name__ == "__main__":
    test_cupy_loader()
