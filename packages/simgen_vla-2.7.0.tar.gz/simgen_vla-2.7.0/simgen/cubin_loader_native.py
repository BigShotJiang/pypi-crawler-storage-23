"""
SimGen VLA - Native CUDA Cubin Loader
======================================
Loads precompiled native CUDA kernels via CuPy.
No Triton dependency, no cuda-python dependency.

Works on: Kaggle, Colab, any system with CuPy installed.
"""

import json
from pathlib import Path
from typing import Dict, Optional, Tuple

import torch

try:
    import cupy as cp
    HAS_CUPY = True
except ImportError:
    HAS_CUPY = False

__all__ = ['NativeCubinLoader', 'HAS_CUPY']

# Block size used in kernels
BLOCK_SIZE = 256


class NativeKernel:
    """Wrapper for a native CUDA kernel loaded via CuPy."""

    def __init__(self, function, name: str, block_size: int = BLOCK_SIZE):
        self.function = function
        self.name = name
        self.block_size = block_size

    def __call__(self, grid: Tuple[int, ...], block: Tuple[int, ...], args: tuple, shared_mem: int = 0):
        """Launch kernel with grid, block, and args."""
        # Convert torch tensors to CuPy arrays (zero-copy via DLPack)
        cupy_args = []
        for arg in args:
            if isinstance(arg, torch.Tensor):
                cupy_args.append(cp.from_dlpack(arg))
            elif isinstance(arg, (int, float)):
                cupy_args.append(arg)
            else:
                cupy_args.append(arg)

        # Launch kernel
        self.function(grid, block, tuple(cupy_args), shared_mem=shared_mem)

    def launch(self, *args, grid: Tuple[int, ...], stream=None):
        """Convenience launch with automatic block size."""
        block = (self.block_size, 1, 1)
        self(grid, block, args, shared_mem=0)


class NativeCubinLoader:
    """
    Loader for native CUDA cubins.

    Usage:
        loader = NativeCubinLoader()
        sum_kernel = loader.get_kernel('vla_sum_kernel')
        sum_kernel.launch(input_ptr, output_ptr, output_err_ptr, n, grid=(num_blocks, 1, 1))
    """

    def __init__(self, cubin_dir: Optional[Path] = None):
        if not HAS_CUPY:
            raise RuntimeError("CuPy not available. Install with: pip install cupy-cuda12x")

        # Find cubin directory
        if cubin_dir is None:
            cubin_dir = Path(__file__).parent / "cubin_native"
        self.cubin_dir = Path(cubin_dir)

        # Load manifest
        manifest_path = self.cubin_dir / "manifest.json"
        if not manifest_path.exists():
            raise FileNotFoundError(f"Manifest not found: {manifest_path}")

        with open(manifest_path) as f:
            self.manifest = json.load(f)

        # Detect GPU architecture
        self.arch = self._detect_arch()
        self.cubin_path = self._get_cubin_path()

        # Load module
        self._module = None
        self._kernels: Dict[str, NativeKernel] = {}

    def _detect_arch(self) -> str:
        """Detect GPU compute capability."""
        device = cp.cuda.Device()
        cc = device.compute_capability
        arch = f"sm_{cc}"

        # Map to supported architecture
        supported = list(self.manifest["architectures"].keys())
        if arch in supported:
            return arch

        # Find closest lower arch
        cc_num = int(cc)
        for candidate in sorted(supported, reverse=True):
            if int(candidate[3:]) <= cc_num:
                return candidate

        return supported[0]  # Fallback to lowest

    def _get_cubin_path(self) -> Path:
        """Get cubin path for current architecture."""
        arch_info = self.manifest["architectures"].get(self.arch)
        if not arch_info:
            raise RuntimeError(f"No cubin for architecture {self.arch}")

        cubin_name = arch_info["cubin"]
        cubin_path = self.cubin_dir / cubin_name

        if not cubin_path.exists():
            raise FileNotFoundError(f"Cubin not found: {cubin_path}")

        return cubin_path

    @property
    def module(self):
        """Lazy load CuPy RawModule."""
        if self._module is None:
            self._module = cp.RawModule(path=str(self.cubin_path))
        return self._module

    def get_kernel(self, name: str) -> NativeKernel:
        """Get a kernel by name."""
        if name not in self._kernels:
            try:
                func = self.module.get_function(name)
                self._kernels[name] = NativeKernel(func, name, BLOCK_SIZE)
            except Exception as e:
                raise RuntimeError(f"Failed to load kernel '{name}': {e}")
        return self._kernels[name]

    def list_kernels(self) -> list:
        """List available kernels."""
        return self.manifest.get("kernels", [])

    @property
    def info(self) -> dict:
        """Get loader info."""
        return {
            "arch": self.arch,
            "cubin": str(self.cubin_path),
            "kernels": self.list_kernels(),
            "version": self.manifest.get("version", "unknown"),
        }


# Convenience functions
def vla_sum(x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Exact sum using VLA.
    Returns (sum, error) where true_sum = sum + error.
    """
    loader = NativeCubinLoader()
    kernel = loader.get_kernel("vla_sum_kernel")

    n = x.numel()
    num_blocks = (n + BLOCK_SIZE - 1) // BLOCK_SIZE

    # Allocate output
    output = torch.zeros(1, dtype=torch.float64, device=x.device)
    output_err = torch.zeros(1, dtype=torch.float64, device=x.device)

    # Flatten input
    x_flat = x.contiguous().view(-1).float()

    # Launch kernel
    kernel.launch(
        x_flat.data_ptr(), output.data_ptr(), output_err.data_ptr(), n,
        grid=(num_blocks, 1, 1)
    )

    cp.cuda.Stream.null.synchronize()
    return output, output_err


def vla_dot(x: torch.Tensor, y: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    Exact dot product using VLA.
    Returns (result, error1, error2) where true_dot = result + error1 + error2.
    """
    loader = NativeCubinLoader()
    kernel = loader.get_kernel("vla_dot_kernel")

    n = x.numel()
    num_blocks = (n + BLOCK_SIZE - 1) // BLOCK_SIZE

    # Allocate output
    output = torch.zeros(1, dtype=torch.float64, device=x.device)
    output_err = torch.zeros(1, dtype=torch.float64, device=x.device)
    output_err2 = torch.zeros(1, dtype=torch.float64, device=x.device)

    # Flatten inputs
    x_flat = x.contiguous().view(-1).float()
    y_flat = y.contiguous().view(-1).float()

    # Launch kernel
    kernel.launch(
        x_flat.data_ptr(), y_flat.data_ptr(),
        output.data_ptr(), output_err.data_ptr(), output_err2.data_ptr(), n,
        grid=(num_blocks, 1, 1)
    )

    cp.cuda.Stream.null.synchronize()
    return output, output_err, output_err2
