"""MimirClient — async HTTP client for the Mímir Knowledge Graph API.

This is a placeholder. Implementation follows after design approval.
See docs/design.md for the API coverage matrix and architectural constraints.
"""

# TODO: Implement after design document approval (RULES.md Implementation Gate)
# Reference implementations to study:
#   - semantic/src/mimir_semantic/client.py (existing HTTP wrapper)
#   - Agent team's internal client (request from team)