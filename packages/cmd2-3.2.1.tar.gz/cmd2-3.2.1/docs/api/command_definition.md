# cmd2.command_definition

::: cmd2.command_definition
