# AIMemory Project

## Overview
This project uses Claude Code with team agents for collaborative AI-powered tasks.

## Conventions
- Use the `.claude/agents/` directory for custom agent definitions
- Agents are defined as markdown files describing their role, tools, and instructions
