"""Hive.CEO -- Embedded Self-Aware Agent System for LLMHosts.com.

Provides self-awareness, self-improvement, self-healing, and admin panel
capabilities. Progressive enhancement: LLMHosts works without Hive.
"""

__version__ = "1.0.0"
