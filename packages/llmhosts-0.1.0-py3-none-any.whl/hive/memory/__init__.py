"""Hive institutional memory -- persistent knowledge across sessions."""
