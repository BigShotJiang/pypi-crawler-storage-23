"""Hive sandbox -- Docker-based isolated test execution."""
