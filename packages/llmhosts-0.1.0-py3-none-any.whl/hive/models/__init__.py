"""Hive model provider abstraction layer."""
