"""Hive admin panel -- FastAPI routes for /admin/hive/."""
