"""Hive agent definitions -- 5-agent embedded system."""

from hive.agents.base import AgentMessage, BaseAgent

__all__ = ["AgentMessage", "BaseAgent"]
