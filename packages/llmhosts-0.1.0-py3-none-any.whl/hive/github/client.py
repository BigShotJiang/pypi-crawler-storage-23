"""GitHub API client for Hive Builder agent.

Handles: branch creation, commit, PR creation, CI status checks.
All code changes go through GitHub PRs -- never direct to main.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

logger = logging.getLogger("hive.github")


@dataclass
class PRInfo:
    """Information about a Pull Request."""

    number: int
    title: str
    url: str
    branch: str
    status: str  # "open" | "merged" | "closed"
    ci_status: str  # "pending" | "passing" | "failing" | "unknown"


class GitHubClient:
    """GitHub API wrapper for Hive operations.

    Uses GitHub CLI (gh) or GitHub API via httpx.
    Credentials provided by God-Mode (GH_TOKEN env var).
    """

    def __init__(self, repo: str, branch_prefix: str = "hive/") -> None:
        self.repo = repo
        self.branch_prefix = branch_prefix

    async def create_branch(self, branch_name: str, base: str = "main") -> bool:
        """Create a new branch from base.

        Uses: git checkout -b {branch_name} {base}
        """
        logger.info("Creating branch: %s from %s", branch_name, base)
        # Placeholder: full implementation uses subprocess to run git commands
        return True

    async def commit_changes(self, branch: str, message: str, files: list[str]) -> bool:
        """Stage and commit changes on a branch.

        Follows Hive commit convention: hive(HIVE-NNN): description
        """
        logger.info("Committing to %s: %s (%d files)", branch, message, len(files))
        return True

    async def create_pr(self, title: str, body: str, branch: str, base: str = "main") -> PRInfo | None:
        """Create a Pull Request.

        Uses GitHub CLI: gh pr create --title ... --body ... --head ... --base ...
        """
        logger.info("Creating PR: %s (branch: %s)", title, branch)
        # Placeholder: full implementation uses gh CLI or GitHub API
        return PRInfo(
            number=0,
            title=title,
            url=f"https://github.com/{self.repo}/pull/0",
            branch=branch,
            status="open",
            ci_status="unknown",
        )

    async def get_ci_status(self, pr_number: int) -> str:
        """Check CI status for a PR.

        Returns: "pending" | "passing" | "failing" | "unknown"
        """
        # Placeholder: full implementation queries GitHub checks API
        return "unknown"

    async def list_recent_prs(self, limit: int = 10) -> list[PRInfo]:
        """List recent PRs created by Hive."""
        # Placeholder: full implementation filters PRs by hive/ branch prefix
        return []
