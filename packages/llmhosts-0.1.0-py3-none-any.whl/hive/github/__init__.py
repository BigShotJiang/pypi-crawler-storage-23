"""Hive GitHub integration -- PR creation and CI interaction."""
