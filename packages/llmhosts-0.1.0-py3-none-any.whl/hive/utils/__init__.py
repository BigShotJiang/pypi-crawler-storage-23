"""Hive utilities -- sandbox execution, codebase indexing."""
