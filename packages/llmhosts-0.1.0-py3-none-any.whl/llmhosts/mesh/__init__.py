"""LLMHosts mesh -- multi-device mesh networking for distributed inference.

Register devices, route requests to the best available GPU, and monitor
mesh health across your personal infrastructure.

Usage::

    from llmhosts.mesh import DeviceManager, MeshRouter, Device

    manager = DeviceManager(data_dir)
    await manager.initialize()
    router = MeshRouter(manager)
    route = await router.route("llama3.2")
"""

from __future__ import annotations

from llmhosts.mesh.manager import DeviceManager
from llmhosts.mesh.models import Device, DeviceRegistration, DeviceRole, MeshStatus
from llmhosts.mesh.router import MeshRoute, MeshRouter

__all__ = [
    "Device",
    "DeviceManager",
    "DeviceRegistration",
    "DeviceRole",
    "MeshRoute",
    "MeshRouter",
    "MeshStatus",
]
