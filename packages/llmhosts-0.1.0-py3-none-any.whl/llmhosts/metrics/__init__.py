"""LLMHosts metrics -- in-memory + SQLite request metrics for dashboards."""

from __future__ import annotations

from llmhosts.metrics.collector import MetricsCollector, MetricsSnapshot, TimeseriesPoint
from llmhosts.metrics.export import MetricsExporter

try:
    from llmhosts.metrics.prometheus import (
        PrometheusMetricsExporter,
        create_metrics_app,
        record_http_request,
        record_llm_request,
    )

    _prometheus_available = True
except ImportError:
    _prometheus_available = False
    PrometheusMetricsExporter = None  # type: ignore[misc, assignment]
    create_metrics_app = None  # type: ignore[misc, assignment]
    record_http_request = None  # type: ignore[misc, assignment]
    record_llm_request = None  # type: ignore[misc, assignment]

__all__ = [
    "MetricsCollector",
    "MetricsExporter",
    "MetricsSnapshot",
    "PrometheusMetricsExporter",
    "TimeseriesPoint",
    "create_metrics_app",
    "record_http_request",
    "record_llm_request",
]
