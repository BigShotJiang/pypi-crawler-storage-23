"""Honest savings calculation and validation.

Provides :class:`HonestSavings` -- a conservative, transparent savings
calculator that never overstates how much a user saves by running local AI.
"""

from __future__ import annotations

from llmhosts.savings.calculator import (
    HonestSavings,
    MonthlyProjection,
    RequestSavings,
    SavingsReport,
    ValidationResult,
)

__all__ = [
    "HonestSavings",
    "MonthlyProjection",
    "RequestSavings",
    "SavingsReport",
    "ValidationResult",
]
