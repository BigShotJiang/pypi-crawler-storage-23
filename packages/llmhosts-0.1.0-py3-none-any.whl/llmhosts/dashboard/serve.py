"""Serve the static web dashboard from FastAPI.

Mounts the self-contained HTML dashboard at ``/dashboard``.
The dashboard fetches data from the ``/api/*`` endpoints defined in
:mod:`llmhost.proxy.dashboard_routes`.
"""

from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

router = APIRouter(tags=["web-dashboard"])

_STATIC_DIR = Path(__file__).parent / "static"


@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard() -> HTMLResponse:
    """Serve the web dashboard."""
    html_path = _STATIC_DIR / "index.html"
    return HTMLResponse(content=html_path.read_text())
