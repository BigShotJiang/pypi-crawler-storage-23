"""LLMHosts backend dispatcher -- routes unified requests to inference backends.

Currently supports:

* **Ollama** (local, auto-discovered on ``http://127.0.0.1:11434``)
* **Cloud APIs** via BYOK keys forwarded through LiteLLM (when available)

The dispatcher converts :class:`UnifiedRequest` into the appropriate
backend format, calls the backend, and returns a :class:`UnifiedResponse`.
Streaming is handled via :meth:`dispatch_stream`, which yields raw text tokens.

When a :class:`BackendManager` is attached, cloud requests are routed
through LiteLLM automatically.  The dispatcher falls back to raw httpx
for Ollama regardless.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any

import httpx

from llmhosts.config import ConnectionPoolConfig
from llmhosts.constants import OLLAMA_DEFAULT_HOST
from llmhosts.proxy.errors import BackendTimeoutError, BackendUnavailableError, KarmaTooLowError
from llmhosts.proxy.models import UnifiedRequest, UnifiedResponse

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from llmhosts.audit.logger import AuditLogger
    from llmhosts.backends.manager import BackendManager
    from llmhosts.hive.karma import KarmaEngine
    from llmhosts.hive.manager import HiveManager
    from llmhosts.router.engine import Router

# Karma: block requests when below this; deprioritize when below 1.0
KARMA_THRESHOLD_BLOCK = 0.5
COMPUTE_HOURS_PER_REQUEST = 0.001

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Backend registry entries
# ---------------------------------------------------------------------------

BACKEND_TIMEOUT = 120.0  # generous default for large-model generation


@dataclass
class BackendEntry:
    """Metadata for a single inference backend."""

    name: str
    base_url: str
    backend_type: str  # "ollama" | "openai" | "anthropic" | "litellm"
    models: list[str] = field(default_factory=list)
    priority: int = 0  # lower = preferred
    healthy: bool = True
    member_id: str | None = None  # Hive member ID when backend is a Hive peer (for karma routing)


# ---------------------------------------------------------------------------
# Cloud provider detection -- heuristics for model → provider mapping
# ---------------------------------------------------------------------------

_CLOUD_MODEL_PREFIXES: dict[str, list[str]] = {
    "openai": ["gpt-", "o1-", "o3-", "chatgpt-", "ft:gpt-", "dall-e", "tts-", "whisper"],
    "anthropic": ["claude-"],
    "google": ["gemini-", "gemini/"],
    "mistral": ["mistral-", "mixtral-", "codestral-", "open-mistral-", "open-mixtral-"],
    "groq": ["groq/"],
    "together": ["together_ai/", "together/"],
    "deepseek": ["deepseek-", "deepseek/"],
    "openrouter": ["openrouter/"],
}


def _detect_cloud_model(model: str) -> bool:
    """Return *True* if *model* looks like a cloud model rather than a local Ollama model.

    Uses prefix heuristics -- any model matching a known cloud provider
    prefix is treated as a cloud request.  Models containing ``/`` that
    match a known LiteLLM provider prefix are also considered cloud.
    """
    model_lower = model.lower()
    for prefixes in _CLOUD_MODEL_PREFIXES.values():
        for prefix in prefixes:
            if model_lower.startswith(prefix):
                return True
    return False


# ---------------------------------------------------------------------------
# Ollama helpers
# ---------------------------------------------------------------------------


def _unified_to_ollama_payload(req: UnifiedRequest) -> dict[str, Any]:
    """Convert a :class:`UnifiedRequest` to the Ollama ``/api/chat`` body."""
    messages: list[dict[str, Any]] = []
    for m in req.messages:
        msg: dict[str, Any] = {"role": m.role}
        if isinstance(m.content, list):
            # Flatten multimodal content blocks to a single string for Ollama
            parts = [block.get("text", "") for block in m.content if isinstance(block, dict)]
            msg["content"] = "\n".join(parts)
        else:
            msg["content"] = m.content or ""
        messages.append(msg)

    payload: dict[str, Any] = {
        "model": req.model,
        "messages": messages,
        "stream": req.stream,
    }
    options: dict[str, Any] = {}
    if req.temperature is not None:
        options["temperature"] = req.temperature
    if req.top_p is not None:
        options["top_p"] = req.top_p
    if req.max_tokens is not None:
        options["num_predict"] = req.max_tokens
    if req.stop:
        options["stop"] = req.stop
    if options:
        payload["options"] = options
    return payload


def _ollama_response_to_unified(data: dict[str, Any], model: str) -> UnifiedResponse:
    """Parse an Ollama ``/api/chat`` non-streaming JSON response."""
    message = data.get("message", {})
    content = message.get("content", "")
    done_reason = data.get("done_reason", "stop")

    prompt_tokens = data.get("prompt_eval_count", 0) or 0
    completion_tokens = data.get("eval_count", 0) or 0

    return UnifiedResponse(
        content=content,
        finish_reason=done_reason,
        model=model,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        total_tokens=prompt_tokens + completion_tokens,
    )


def _litellm_dict_to_unified(data: dict[str, Any], model: str) -> UnifiedResponse:
    """Convert a normalized LiteLLM response dict to :class:`UnifiedResponse`."""
    return UnifiedResponse(
        content=data.get("content", ""),
        finish_reason=data.get("finish_reason", "stop") or "stop",
        model=data.get("model", model),
        prompt_tokens=data.get("prompt_tokens", 0),
        completion_tokens=data.get("completion_tokens", 0),
        total_tokens=data.get("total_tokens", 0),
        tool_calls=data.get("tool_calls"),
    )


# ---------------------------------------------------------------------------
# BackendDispatcher
# ---------------------------------------------------------------------------


class BackendDispatcher:
    """Discover backends, dispatch requests, and manage health state.

    Supports two modes of operation:

    1. **Standalone** (default): Uses raw httpx to talk to Ollama directly.
       Cloud models are not available.
    2. **With BackendManager**: When :meth:`attach_backend_manager` is called
       with an initialised :class:`BackendManager`, cloud models are routed
       through LiteLLM while Ollama requests continue via raw httpx.

    Typical lifecycle::

        dispatcher = BackendDispatcher()
        await dispatcher.startup()

        # Optionally attach cloud backends
        dispatcher.attach_backend_manager(backend_manager)

        response = await dispatcher.dispatch(unified_request)
        await dispatcher.shutdown()
    """

    def __init__(self, pool_config: ConnectionPoolConfig | None = None) -> None:
        self._backends: list[BackendEntry] = []
        self._pool_config = pool_config or ConnectionPoolConfig()
        self._pool_registry: dict[str, httpx.AsyncClient] = {}
        self._backend_manager: BackendManager | None = None
        self._router: Router | None = None
        self._hive_manager: HiveManager | None = None
        self._karma_engine: KarmaEngine | None = None
        self._audit_logger: AuditLogger | None = None

    # -- lifecycle -----------------------------------------------------------

    async def startup(self) -> None:
        """Discover local backends. Connection pools are created lazily on first use."""
        await self._discover_ollama()
        await self._discover_lan_nodes()
        logger.info(
            "BackendDispatcher ready - %d backend(s), %d model(s)",
            len(self._backends),
            sum(len(b.models) for b in self._backends),
        )

    async def shutdown(self) -> None:
        """Close all per-backend connection pools."""
        for url, client in self._pool_registry.items():
            await client.aclose()
            logger.debug("Closed connection pool for %s", url)
        self._pool_registry.clear()
        logger.info("BackendDispatcher shut down")

    # -- connection pooling --------------------------------------------------

    def _get_or_create_pool(self, backend: BackendEntry) -> httpx.AsyncClient:
        """Return the connection pool for *backend*, creating one if needed.

        Each unique ``base_url`` gets its own :class:`httpx.AsyncClient` with
        HTTP/2 enabled (when the ``h2`` package is available) and configurable
        pool limits from :class:`ConnectionPoolConfig`.
        """
        key = backend.base_url
        if key in self._pool_registry:
            return self._pool_registry[key]

        cfg = self._pool_config
        use_http2 = cfg.http2
        try:
            client = httpx.AsyncClient(
                http2=use_http2,
                limits=httpx.Limits(
                    max_connections=cfg.max_connections,
                    max_keepalive_connections=cfg.max_keepalive,
                    keepalive_expiry=cfg.idle_timeout,
                ),
                timeout=httpx.Timeout(BACKEND_TIMEOUT, connect=10.0),
            )
        except ImportError:
            # h2 package not installed -- fall back to HTTP/1.1
            use_http2 = False
            logger.info("h2 package not installed; falling back to HTTP/1.1 for %s", key)
            client = httpx.AsyncClient(
                http2=False,
                limits=httpx.Limits(
                    max_connections=cfg.max_connections,
                    max_keepalive_connections=cfg.max_keepalive,
                    keepalive_expiry=cfg.idle_timeout,
                ),
                timeout=httpx.Timeout(BACKEND_TIMEOUT, connect=10.0),
            )
        self._pool_registry[key] = client
        logger.info(
            "Created connection pool for %s (max_conn=%d, keepalive=%d, http2=%s)",
            key,
            cfg.max_connections,
            cfg.max_keepalive,
            use_http2,
        )
        return client

    # -- BackendManager integration ------------------------------------------

    def attach_backend_manager(self, manager: BackendManager) -> None:
        """Attach a :class:`BackendManager` for cloud backend routing.

        Once attached, the dispatcher will route cloud model requests
        through LiteLLM via the manager, while local Ollama requests
        continue through raw httpx.

        Parameters
        ----------
        manager:
            An initialised :class:`BackendManager`.
        """
        self._backend_manager = manager
        # Register a synthetic BackendEntry so cloud models show up
        # in model listing and backend selection
        if manager.has_cloud:
            cloud_entry = BackendEntry(
                name="litellm-cloud",
                base_url="",  # no direct URL -- routed via LiteLLM
                backend_type="litellm",
                models=[],  # cloud models are resolved dynamically
                priority=10,  # prefer local over cloud
                healthy=True,
            )
            self._backends.append(cloud_entry)
            logger.info("Attached BackendManager with cloud backend support")
        else:
            logger.info("Attached BackendManager (no cloud providers configured)")

    @property
    def backend_manager(self) -> BackendManager | None:
        """The attached :class:`BackendManager`, or *None*."""
        return self._backend_manager

    # -- Router integration --------------------------------------------------

    def attach_router(self, router: Router) -> None:
        """Attach a :class:`Router` for intelligent routing and privacy enforcement.

        When attached, :meth:`dispatch` and :meth:`dispatch_stream` call
        ``router.route()`` before backend selection to apply PII detection and
        privacy constraints.  SENSITIVE-tier PII is enforced to local backends only.
        """
        self._router = router
        logger.info("Router attached to BackendDispatcher (privacy enforcement active)")

    # -- Hive karma integration --------------------------------------------------

    def attach_hive_karma(self, hive_manager: HiveManager, karma_engine: KarmaEngine) -> None:
        """Attach Hive karma for contribution/consumption tracking and karma-weighted routing.

        When attached, local backend (ollama-local) is tagged with current member ID,
        and after each successful dispatch karma is updated (contribution if local,
        consumption if forwarded to a Hive peer). Backends are sorted by karma when
        multiple candidates exist.
        """
        self._hive_manager = hive_manager
        self._karma_engine = karma_engine
        current_member_id = hive_manager.get_current_member_id()
        if current_member_id:
            for b in self._backends:
                if b.name == "ollama-local" or b.base_url == OLLAMA_DEFAULT_HOST:
                    b.member_id = current_member_id
                    break
        logger.info("Hive karma attached to BackendDispatcher")

    # -- Audit logger integration -----------------------------------------------

    def attach_audit_logger(self, audit_logger: AuditLogger) -> None:
        """Attach an :class:`AuditLogger` for request audit trail.

        When attached, every :meth:`dispatch` call writes an :class:`AuditEntry`
        to the audit log after the backend response completes.
        """
        self._audit_logger = audit_logger
        logger.info("AuditLogger attached to BackendDispatcher")

    @property
    def audit_logger(self) -> AuditLogger | None:
        """The attached :class:`AuditLogger`, or *None*."""
        return self._audit_logger

    def _is_local_backend(self, backend: BackendEntry) -> bool:
        """Return True if this backend is the local node (we contribute when we serve)."""
        return backend.backend_type == "ollama" and (
            backend.name == "ollama-local" or backend.base_url == OLLAMA_DEFAULT_HOST
        )

    @staticmethod
    def _compute_hours_from_response(response: UnifiedResponse) -> float:
        """Compute hours for karma from response (simple heuristic)."""
        if response.total_tokens and response.total_tokens > 0:
            return max(COMPUTE_HOURS_PER_REQUEST, response.total_tokens / 1_000_000.0)
        return COMPUTE_HOURS_PER_REQUEST

    async def _record_karma_after_dispatch(
        self,
        backend: BackendEntry,
        current_member_id: str | None,
        compute_hours: float,
    ) -> None:
        """Record contribution (local) or consumption (remote) after successful dispatch."""
        if not self._karma_engine or not current_member_id:
            return
        try:
            if self._is_local_backend(backend):
                await self._karma_engine.record_contribution(current_member_id, compute_hours)
            else:
                await self._karma_engine.record_consumption(current_member_id, compute_hours)
        except Exception:
            logger.warning("Karma update failed", exc_info=True)

    async def _record_audit(
        self,
        *,
        request: UnifiedRequest,
        response: UnifiedResponse | None,
        backend: BackendEntry,
        start_time: float,
        status_code: int = 200,
        error: str | None = None,
        source_ip: str = "",
        request_id: str = "",
        api_key_id: str = "",
        user_id: str = "",
        dialect: str = "openai",
        path: str = "/v1/chat/completions",
    ) -> None:
        """Record an audit entry after a dispatch completes (or fails).

        This is a best-effort operation -- failures are logged but never
        propagated to the caller.
        """
        if self._audit_logger is None:
            return

        from llmhosts.audit.models import AuditEntry

        latency_ms = (time.monotonic() - start_time) * 1000.0
        prompt_tokens = response.prompt_tokens if response else 0
        completion_tokens = response.completion_tokens if response else 0
        model_used = response.model if response else request.model

        entry = AuditEntry(
            request_id=request_id,
            timestamp=datetime.now(timezone.utc),
            source_ip=source_ip,
            method="POST",
            path=path,
            dialect=dialect,
            model_requested=request.model,
            model_used=model_used,
            backend_type=backend.backend_type,
            routing_tier="rule",
            routing_reasoning="",
            routing_confidence=0.0,
            input_tokens=prompt_tokens,
            output_tokens=completion_tokens,
            actual_cost=0.0,
            cloud_equivalent_cost=0.0,
            cached=False,
            latency_ms=round(latency_ms, 2),
            status_code=status_code,
            error=error,
            api_key_id=api_key_id,
            user_id=user_id,
        )
        try:
            await self._audit_logger.log(entry)
        except Exception:
            logger.warning("Failed to write audit entry for request_id=%s", request_id, exc_info=True)

    async def _select_backend_with_privacy(self, request: UnifiedRequest) -> BackendEntry:
        """Select a backend, applying privacy enforcement when a Router is attached.

        If the Router classifies the request as SENSITIVE (e.g. SSN, credit card),
        only local (Ollama) backends are eligible.  Falls back to normal
        :meth:`_select_backend` when no router is attached or routing fails.
        When Hive karma is attached, sorts candidates by karma (higher first).

        Raises :class:`BackendUnavailableError` if a SENSITIVE request cannot be
        satisfied by any available local backend.
        """
        priority_order: list[tuple[str, float]] | None = None
        karma_engine = getattr(self, "_karma_engine", None)
        if karma_engine:
            try:
                priority_order = await karma_engine.get_priority_order()
            except Exception:
                logger.debug("Karma get_priority_order failed, skipping karma sort", exc_info=True)

        if self._router is None:
            return self._select_backend(request.model, priority_order=priority_order)

        try:
            decision = await self._router.route(request)
        except Exception:
            logger.warning("Router.route() failed, falling back to rule-based selection", exc_info=True)
            return self._select_backend(request.model, priority_order=priority_order)

        privacy_tier = getattr(decision, "privacy_tier", "public")
        forced_local = getattr(decision, "forced_local", False)

        if forced_local or privacy_tier == "sensitive":
            local_candidates = [
                b
                for b in self._backends
                if b.healthy and b.backend_type == "ollama" and (request.model in b.models or not b.models)
            ]
            if local_candidates:
                local_candidates.sort(key=lambda b: b.priority)
                logger.info(
                    "Privacy enforcement: routing '%s' to local backend (tier=%s)",
                    request.model,
                    privacy_tier,
                )
                return local_candidates[0]
            raise BackendUnavailableError(
                f"No local backend available for model '{request.model}'. "
                f"Request contains {privacy_tier}-tier PII and cannot be routed to cloud."
            )

        return self._select_backend(request.model, priority_order=priority_order)

    # -- discovery -----------------------------------------------------------

    async def _discover_ollama(self) -> None:
        """Probe the local Ollama instance and populate model list."""
        # Use a temporary backend entry to get/create a pool for discovery
        discovery_backend = BackendEntry(name="_discovery", base_url=OLLAMA_DEFAULT_HOST, backend_type="ollama")
        client = self._get_or_create_pool(discovery_backend)
        try:
            resp = await client.get(f"{OLLAMA_DEFAULT_HOST}/api/tags", timeout=5.0)
            resp.raise_for_status()
            data = resp.json()
            model_names = [m["name"] for m in data.get("models", [])]
            if model_names:
                entry = BackendEntry(
                    name="ollama-local",
                    base_url=OLLAMA_DEFAULT_HOST,
                    backend_type="ollama",
                    models=model_names,
                    priority=0,
                    healthy=True,
                )
                self._backends.append(entry)
                logger.info("Discovered Ollama at %s with models: %s", OLLAMA_DEFAULT_HOST, model_names)
            else:
                logger.warning("Ollama found at %s but no models loaded", OLLAMA_DEFAULT_HOST)
        except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError):
            logger.info("Ollama not reachable at %s - skipping", OLLAMA_DEFAULT_HOST)

    async def _discover_lan_nodes(self) -> None:
        """Discover LAN nodes via mDNS and add as Ollama-type backends with lower priority than local."""
        try:
            from llmhosts.discovery.mdns import get_discovered_nodes
        except ImportError:
            return

        nodes = get_discovered_nodes()
        for node in nodes:
            if not node.models:
                continue
            # Avoid duplicating the local Ollama backend
            existing_urls = {b.base_url for b in self._backends}
            if node.base_url in existing_urls:
                continue

            entry = BackendEntry(
                name=f"lan-{node.hostname}",
                base_url=node.base_url,
                backend_type="ollama",  # LAN nodes expose Ollama-compatible API
                models=node.models,
                priority=5,  # between local (0) and cloud (10)
                healthy=True,
            )
            self._backends.append(entry)
            logger.info(
                "Added LAN node %s at %s with %d model(s)",
                node.hostname,
                node.base_url,
                len(node.models),
            )

    async def refresh_lan_nodes(self) -> int:
        """Re-scan LAN nodes and update backend list. Returns count of LAN backends."""
        # Remove existing LAN entries
        self._backends = [b for b in self._backends if not b.name.startswith("lan-")]
        await self._discover_lan_nodes()
        return sum(1 for b in self._backends if b.name.startswith("lan-"))

    # -- model listing -------------------------------------------------------

    def list_backends_info(self) -> list[Any]:
        """Return backend info in Router-compatible :class:`~llmhost.router.models.BackendInfo` format."""
        from llmhosts.router.models import BackendInfo as RouterBackendInfo

        result = []
        for b in self._backends:
            if b.backend_type == "litellm":
                continue  # LiteLLM is a cloud aggregator, not a direct backend
            result.append(
                RouterBackendInfo(
                    backend_type=b.backend_type,
                    url=b.base_url,
                    models=list(b.models),
                    is_local=b.backend_type == "ollama",
                    is_healthy=b.healthy,
                )
            )
        return result

    def list_models(self) -> list[dict[str, str]]:
        """Return a flat list of ``{"id": ..., "owned_by": ...}`` for all backends."""
        result: list[dict[str, str]] = []
        for backend in self._backends:
            if backend.backend_type == "litellm":
                # Cloud models aren't pre-enumerated; skip static listing
                # They're accessible but listed via /v1/models with provider filter
                continue
            for model in backend.models:
                result.append({"id": model, "owned_by": backend.name})
        return result

    # -- backend selection ---------------------------------------------------

    def _select_backend(
        self,
        model: str,
        *,
        priority_order: list[tuple[str, float]] | None = None,
    ) -> BackendEntry:
        """Choose the best healthy backend that serves *model*.

        For cloud models (detected via prefix heuristics), routes to the
        LiteLLM backend entry if available.  Otherwise falls back to Ollama.
        When *priority_order* is provided (from KarmaEngine.get_priority_order),
        candidates are sorted so higher-karma members are preferred.

        Raises :class:`BackendUnavailableError` if none is found.
        """
        # Check if this looks like a cloud model and we have a cloud backend
        if _detect_cloud_model(model) and self._backend_manager is not None and self._backend_manager.has_cloud:
            cloud_entries = [b for b in self._backends if b.backend_type == "litellm" and b.healthy]
            if cloud_entries:
                return cloud_entries[0]

        # Try exact model match on local backends
        candidates = [b for b in self._backends if b.healthy and model in b.models]
        if not candidates:
            # Fallback: if we have a cloud backend and the model wasn't found locally,
            # route to cloud as a last resort
            if self._backend_manager is not None and self._backend_manager.has_cloud:
                cloud_entries = [b for b in self._backends if b.backend_type == "litellm" and b.healthy]
                if cloud_entries:
                    return cloud_entries[0]
            # Final fallback: any healthy local backend
            candidates = [b for b in self._backends if b.healthy and b.backend_type != "litellm"]
        if not candidates:
            raise BackendUnavailableError(f"No healthy backend available for model '{model}'")
        candidates.sort(key=lambda b: b.priority)
        # Karma-weighted order: prefer backends whose member_id appears first in priority_order
        if priority_order:
            rank_by_member: dict[str, int] = {mid: i for i, (mid, _) in enumerate(priority_order)}
            candidates.sort(
                key=lambda b: rank_by_member.get(b.member_id or "", 9999),
            )
        return candidates[0]

    # -- non-streaming dispatch ----------------------------------------------

    async def dispatch(
        self,
        request: UnifiedRequest,
        *,
        source_ip: str = "",
        request_id: str = "",
        api_key_id: str = "",
        user_id: str = "",
        dialect: str = "openai",
        path: str = "/v1/chat/completions",
    ) -> UnifiedResponse:
        """Send *request* to the best backend and return the result."""
        # Anti-abuse: block when karma below threshold
        hive_manager = getattr(self, "_hive_manager", None)
        karma_engine = getattr(self, "_karma_engine", None)
        if hive_manager and karma_engine:
            current_member_id = hive_manager.get_current_member_id()
            if current_member_id:
                karma = await karma_engine.get_karma(current_member_id)
                if karma < KARMA_THRESHOLD_BLOCK:
                    raise KarmaTooLowError(
                        "Karma too low; contribute more before requesting from Hive.",
                        retry_after_seconds=60,
                    )

        start_time = time.monotonic()
        backend = await self._select_backend_with_privacy(request)
        error_msg: str | None = None
        status_code = 200
        response: UnifiedResponse | None = None

        try:
            if backend.backend_type == "ollama":
                response = await self._dispatch_ollama(backend, request)
            elif backend.backend_type == "litellm":
                response = await self._dispatch_litellm(request)
            else:
                raise BackendUnavailableError(f"Unsupported backend type '{backend.backend_type}'")
        except Exception as exc:
            error_msg = str(exc)[:500]
            status_code = 502
            await self._record_audit(
                request=request,
                response=None,
                backend=backend,
                start_time=start_time,
                status_code=status_code,
                error=error_msg,
                source_ip=source_ip,
                request_id=request_id,
                api_key_id=api_key_id,
                user_id=user_id,
                dialect=dialect,
                path=path,
            )
            raise

        # Record karma after successful dispatch
        if hive_manager and karma_engine:
            current_member_id = hive_manager.get_current_member_id()
            compute_hours = self._compute_hours_from_response(response)
            await self._record_karma_after_dispatch(backend, current_member_id, compute_hours)

        await self._record_audit(
            request=request,
            response=response,
            backend=backend,
            start_time=start_time,
            status_code=200,
            source_ip=source_ip,
            request_id=request_id,
            api_key_id=api_key_id,
            user_id=user_id,
            dialect=dialect,
            path=path,
        )
        return response

    async def _dispatch_ollama(self, backend: BackendEntry, request: UnifiedRequest) -> UnifiedResponse:
        """Forward a non-streaming request to Ollama ``/api/chat``."""
        client = self._get_or_create_pool(backend)
        payload = _unified_to_ollama_payload(request)
        payload["stream"] = False  # force non-streaming here

        url = f"{backend.base_url}/api/chat"
        try:
            resp = await client.post(url, json=payload)
            resp.raise_for_status()
            data = resp.json()
            return _ollama_response_to_unified(data, request.model)
        except httpx.TimeoutException as exc:
            backend.healthy = False
            raise BackendTimeoutError(f"Ollama at {backend.base_url} timed out") from exc
        except httpx.HTTPStatusError as exc:
            error_text = exc.response.text[:500]
            logger.error("Ollama returned %s: %s", exc.response.status_code, error_text)
            raise BackendUnavailableError(f"Ollama error: {error_text}") from exc
        except httpx.ConnectError as exc:
            backend.healthy = False
            raise BackendUnavailableError(f"Cannot reach Ollama at {backend.base_url}") from exc

    async def _dispatch_litellm(self, request: UnifiedRequest) -> UnifiedResponse:
        """Forward a non-streaming request through LiteLLM via BackendManager."""
        assert self._backend_manager is not None

        # Convert UnifiedRequest messages to plain dicts for LiteLLM
        messages = [
            {"role": m.role, "content": m.content if isinstance(m.content, str) else (m.content or "")}
            for m in request.messages
        ]

        kwargs: dict[str, Any] = {}
        if request.temperature is not None:
            kwargs["temperature"] = request.temperature
        if request.max_tokens is not None:
            kwargs["max_tokens"] = request.max_tokens
        if request.top_p is not None:
            kwargs["top_p"] = request.top_p
        if request.stop:
            kwargs["stop"] = request.stop
        if request.tools:
            kwargs["tools"] = request.tools

        try:
            result = await self._backend_manager.completion(
                backend_type="litellm",
                model=request.model,
                messages=messages,
                stream=False,
                **kwargs,
            )
            # result is a dict from LiteLLMBackend._normalize_response
            return _litellm_dict_to_unified(result, request.model)  # type: ignore[arg-type]
        except ValueError as exc:
            raise BackendUnavailableError(str(exc)) from exc

    # -- streaming dispatch --------------------------------------------------

    async def dispatch_stream(
        self,
        request: UnifiedRequest,
        *,
        source_ip: str = "",
        request_id: str = "",
        api_key_id: str = "",
        user_id: str = "",
        dialect: str = "openai",
        path: str = "/v1/chat/completions",
    ) -> AsyncIterator[str]:
        """Send *request* to the best backend and yield text tokens."""
        # Anti-abuse: block when karma below threshold
        hive_manager = getattr(self, "_hive_manager", None)
        karma_engine = getattr(self, "_karma_engine", None)
        if hive_manager and karma_engine:
            current_member_id = hive_manager.get_current_member_id()
            if current_member_id:
                karma = await karma_engine.get_karma(current_member_id)
                if karma < KARMA_THRESHOLD_BLOCK:
                    raise KarmaTooLowError(
                        "Karma too low; contribute more before requesting from Hive.",
                        retry_after_seconds=60,
                    )

        start_time = time.monotonic()
        backend = await self._select_backend_with_privacy(request)

        if backend.backend_type == "ollama":
            async for token in self._stream_ollama(backend, request):
                yield token
            if hive_manager and karma_engine:
                current_member_id = hive_manager.get_current_member_id()
                await self._record_karma_after_dispatch(backend, current_member_id, COMPUTE_HOURS_PER_REQUEST)
            await self._record_audit(
                request=request,
                response=None,
                backend=backend,
                start_time=start_time,
                source_ip=source_ip,
                request_id=request_id,
                api_key_id=api_key_id,
                user_id=user_id,
                dialect=dialect,
                path=path,
            )
            return
        if backend.backend_type == "litellm":
            async for token in self._stream_litellm(request):
                yield token
            if hive_manager and karma_engine:
                current_member_id = hive_manager.get_current_member_id()
                await self._record_karma_after_dispatch(backend, current_member_id, COMPUTE_HOURS_PER_REQUEST)
            await self._record_audit(
                request=request,
                response=None,
                backend=backend,
                start_time=start_time,
                source_ip=source_ip,
                request_id=request_id,
                api_key_id=api_key_id,
                user_id=user_id,
                dialect=dialect,
                path=path,
            )
            return

        raise BackendUnavailableError(f"Unsupported backend type '{backend.backend_type}'")

    async def _stream_ollama(self, backend: BackendEntry, request: UnifiedRequest) -> AsyncIterator[str]:
        """Stream tokens from Ollama ``/api/chat``."""
        client = self._get_or_create_pool(backend)
        payload = _unified_to_ollama_payload(request)
        payload["stream"] = True

        url = f"{backend.base_url}/api/chat"
        try:
            async with client.stream("POST", url, json=payload) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.strip():
                        continue
                    try:
                        chunk = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    message = chunk.get("message", {})
                    token = message.get("content", "")
                    if token:
                        yield token
                    if chunk.get("done", False):
                        return
        except httpx.TimeoutException as exc:
            backend.healthy = False
            raise BackendTimeoutError(f"Ollama stream timed out at {backend.base_url}") from exc
        except httpx.ConnectError as exc:
            backend.healthy = False
            raise BackendUnavailableError(f"Cannot reach Ollama at {backend.base_url}") from exc

    async def _stream_litellm(self, request: UnifiedRequest) -> AsyncIterator[str]:
        """Stream tokens through LiteLLM via BackendManager."""
        assert self._backend_manager is not None

        messages = [
            {"role": m.role, "content": m.content if isinstance(m.content, str) else (m.content or "")}
            for m in request.messages
        ]

        kwargs: dict[str, Any] = {}
        if request.temperature is not None:
            kwargs["temperature"] = request.temperature
        if request.max_tokens is not None:
            kwargs["max_tokens"] = request.max_tokens
        if request.top_p is not None:
            kwargs["top_p"] = request.top_p
        if request.stop:
            kwargs["stop"] = request.stop
        if request.tools:
            kwargs["tools"] = request.tools

        try:
            stream = await self._backend_manager.completion(
                backend_type="litellm",
                model=request.model,
                messages=messages,
                stream=True,
                **kwargs,
            )
            # stream is an AsyncIterator[dict] from LiteLLMBackend
            async for chunk in stream:  # type: ignore[union-attr]
                token = chunk.get("content", "")
                if token:
                    yield token
                if chunk.get("finish_reason") is not None:
                    return
        except ValueError as exc:
            raise BackendUnavailableError(str(exc)) from exc
