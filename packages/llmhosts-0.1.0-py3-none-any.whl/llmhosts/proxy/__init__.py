"""LLMHosts proxy package -- OpenAI + Anthropic compatible LLM proxy."""

from __future__ import annotations

from llmhosts.proxy.app import create_app

__all__ = ["create_app"]
