"""Version utilities for LLMHosts.

Provides structured version information and tier detection based on
which optional dependencies are installed.
"""

from __future__ import annotations

import platform
import sys

from llmhosts import __version__


def get_version_info() -> dict[str, str]:
    """Get version info including the installed tier.

    Returns
    -------
    dict[str, str]
        Keys: ``version``, ``python``, ``tier``, ``platform``.
    """
    return {
        "version": __version__,
        "python": sys.version,
        "tier": detect_tier(),
        "platform": platform.platform(),
    }


def detect_tier() -> str:
    """Detect which pip extras are installed.

    Returns
    -------
    str
        One of ``"core"``, ``"smart"``, or ``"full"``.

    Tier definitions:
        - **core**: base install (~50 MB) -- FastAPI proxy, rule-based routing
        - **smart**: + ONNX + FAISS (~150 MB) -- kNN and ModernBERT tiers
        - **full**: + PyTorch + transformers (~2 GB) -- Qwen reasoning tier
    """
    try:
        import faiss  # noqa: F401
        import onnxruntime  # noqa: F401

        try:
            import torch  # noqa: F401

            return "full"
        except ImportError:
            return "smart"
    except ImportError:
        return "core"
