"""LLMHosts constants -- ports, paths, version references."""

from __future__ import annotations

from llmhosts import __version__

# ---- Version ----
VERSION: str = __version__

# ---- Network ----
DEFAULT_HOST: str = "127.0.0.1"
DEFAULT_PORT: int = 4000
OLLAMA_DEFAULT_PORT: int = 11434
OLLAMA_DEFAULT_HOST: str = "http://127.0.0.1:11434"
VLLM_DEFAULT_HOST: str = "http://localhost:8000"

# ---- Filesystem ----
DATA_DIR_NAME: str = ".llmhosts"
DB_FILENAME: str = "llmhosts.db"
CONFIG_FILENAME: str = "config.toml"
FAISS_INDEX_FILENAME: str = "router.faiss"

# ---- API ----
API_V1_PREFIX: str = "/v1"
OPENAI_CHAT_PATH: str = "/v1/chat/completions"
ANTHROPIC_MESSAGES_PATH: str = "/v1/messages"
DASHBOARD_PATH: str = "/dashboard"
