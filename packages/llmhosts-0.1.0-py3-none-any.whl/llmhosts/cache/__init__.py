"""LLMHosts cache -- tiered caching system.

Tier 0 (exact hash) is always available.  Higher tiers require optional
dependencies installed via ``pip install llmhosts[smart]``.

Tiers:
  0 -- :class:`ExactHashCache` -- SHA-256 exact match (zero false positives)
  1 -- :class:`NamespaceFilter` -- entity-aware namespace bucketing
  2 -- :class:`VCache` -- vCache verified semantic cache (ICLR 2026)

:class:`CacheManager` orchestrates all tiers as a unified cascade.
"""

from __future__ import annotations

from llmhosts.cache.exact import ExactHashCache
from llmhosts.cache.manager import CacheLookup, CacheManager, CacheManagerStats
from llmhosts.cache.models import CacheEntry, CacheStats
from llmhosts.cache.namespace import NAMESPACE_AVAILABLE, NamespaceFilter, NamespaceKey, NamespaceStats
from llmhosts.cache.vcache import VCACHE_AVAILABLE, AdaptiveThreshold, VCache, VCacheResult, VCacheStats

__all__ = [
    # Tier 1
    "NAMESPACE_AVAILABLE",
    # Tier 2
    "VCACHE_AVAILABLE",
    "AdaptiveThreshold",
    # Tier 0
    "CacheEntry",
    # Manager
    "CacheLookup",
    "CacheManager",
    "CacheManagerStats",
    "CacheStats",
    "ExactHashCache",
    "NamespaceFilter",
    "NamespaceKey",
    "NamespaceStats",
    "VCache",
    "VCacheResult",
    "VCacheStats",
]
