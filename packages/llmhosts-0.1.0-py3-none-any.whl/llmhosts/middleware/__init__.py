"""LLMHosts middleware -- request processing and observability."""

from __future__ import annotations

from llmhosts.middleware.correlation import CorrelationIdMiddleware, get_correlation_id, set_correlation_id
from llmhosts.middleware.rate_limit import IPRateLimitMiddleware
from llmhosts.middleware.redact import redact_email, redact_text, safe_log_api_key, safe_log_email
from llmhosts.middleware.sanitize import (
    InputSanitizer,
    sanitize_email,
    sanitize_slug,
    sanitize_string,
    sanitize_uuid,
)

__all__ = [
    "CorrelationIdMiddleware",
    "IPRateLimitMiddleware",
    "InputSanitizer",
    "get_correlation_id",
    "redact_email",
    "redact_text",
    "safe_log_api_key",
    "safe_log_email",
    "sanitize_email",
    "sanitize_slug",
    "sanitize_string",
    "sanitize_uuid",
    "set_correlation_id",
]
