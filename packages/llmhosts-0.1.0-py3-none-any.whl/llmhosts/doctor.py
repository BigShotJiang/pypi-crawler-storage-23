"""Comprehensive system health verification for ``llmhost doctor``.

The :class:`Doctor` class runs a suite of diagnostic checks concurrently and
returns structured :class:`DoctorCheck` results.  This module centralises
all doctor logic that previously lived in ``cli.py``.
"""

from __future__ import annotations

import asyncio
import importlib
import logging
import platform
import shutil
import socket
import sys
from pathlib import Path
from typing import Any

from llmhosts.banner import DoctorCheck

logger = logging.getLogger(__name__)


class Doctor:
    """Comprehensive system health verification.

    Checks: Python, config, Ollama, keys, port, tier, disk, hardware,
    proxy responsiveness, cache, database integrity.

    Usage::

        doctor = Doctor()
        results = await doctor.run_all()
        print_doctor_report(results)
    """

    def __init__(self, config: Any | None = None, data_dir: Path | None = None) -> None:
        """Initialise the doctor.

        Args:
            config: An :class:`~llmhost.config.LLMHostsConfig` instance.
                    If ``None``, one is loaded from default location.
            data_dir: Override for ``~/.llmhosts``.  Used mainly in tests.
        """
        if config is None:
            from llmhosts.config import load_config

            config = load_config()
        self._config = config
        self._data_dir = data_dir or self._default_data_dir()

    @staticmethod
    def _default_data_dir() -> Path:
        from llmhosts.constants import DATA_DIR_NAME

        return Path.home() / DATA_DIR_NAME

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    async def run_all(self) -> list[DoctorCheck]:
        """Run all checks concurrently where possible.

        Returns:
            A list of :class:`DoctorCheck` results ordered by category.
        """
        # Group into concurrent and sequential checks
        tasks = [
            self.check_python(),
            self.check_config(),
            self.check_ollama(),
            self.check_keys(),
            self.check_port(),
            self.check_tier(),
            self.check_disk(),
            self.check_hardware(),
            self.check_database(),
            self.check_cache(),
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        checks: list[DoctorCheck] = []
        for result in results:
            if isinstance(result, DoctorCheck):
                checks.append(result)
            elif isinstance(result, BaseException):
                checks.append(
                    DoctorCheck(
                        name="Unknown",
                        status="fail",
                        message=f"Check raised exception: {result}",
                    )
                )
        return checks

    # ------------------------------------------------------------------
    # Individual checks
    # ------------------------------------------------------------------

    async def check_python(self) -> DoctorCheck:
        """Verify Python version >= 3.10."""
        py_ver = platform.python_version()
        py_ok = sys.version_info >= (3, 10)
        return DoctorCheck(
            name="Python version",
            status="ok" if py_ok else "fail",
            message=f"Python {py_ver}",
            suggestion="LLMHosts requires Python 3.10+. Upgrade your Python installation." if not py_ok else None,
        )

    async def check_config(self) -> DoctorCheck:
        """Verify config file exists and is valid TOML."""
        from llmhosts.config import llmhosts_dir

        cfg_path = llmhosts_dir() / "config.toml"
        if not cfg_path.is_file():
            return DoctorCheck(
                name="Config file",
                status="warn",
                message="Not found (using defaults)",
                suggestion="Run: mkdir -p ~/.llmhosts && llmhost config init",
            )

        # Validate TOML syntax
        try:
            import toml  # type: ignore[import-untyped]

            toml.load(cfg_path)
            return DoctorCheck(
                name="Config file",
                status="ok",
                message=str(cfg_path),
            )
        except Exception as exc:
            return DoctorCheck(
                name="Config file",
                status="fail",
                message=f"Invalid TOML: {exc}",
                suggestion="Fix syntax errors in your config.toml or delete it to use defaults.",
            )

    async def check_ollama(self) -> DoctorCheck:
        """Ping Ollama, list models."""
        try:
            from llmhosts.discovery.ollama import OllamaDiscovery

            ollama_host = self._config.ollama.host
            async with OllamaDiscovery(host=ollama_host, timeout=5.0) as ollama:
                if await ollama.is_available():
                    models = await ollama.list_models()
                    model_names = ", ".join(m.name for m in models[:5])
                    suffix = f" (+{len(models) - 5} more)" if len(models) > 5 else ""
                    if models:
                        return DoctorCheck(
                            name="Ollama",
                            status="ok",
                            message=f"Running at {ollama_host}, {len(models)} model(s): {model_names}{suffix}",
                        )
                    return DoctorCheck(
                        name="Ollama",
                        status="warn",
                        message=f"Running at {ollama_host} but no models installed",
                        suggestion="Pull a model: ollama pull llama3.2",
                    )
                return DoctorCheck(
                    name="Ollama",
                    status="warn",
                    message=f"Not reachable at {ollama_host}",
                    suggestion="Install Ollama from https://ollama.com or check the host config.",
                )
        except Exception as exc:
            return DoctorCheck(name="Ollama", status="fail", message=str(exc))

    async def check_keys(self) -> DoctorCheck:
        """Verify stored keys are decryptable and optionally valid."""
        try:
            from llmhosts.keys.manager import KeyManager

            mgr = KeyManager(data_dir=self._data_dir)
            providers = mgr.list_providers()
            if providers:
                names = ", ".join(p.provider for p in providers)
                # Check if any have decrypt errors
                decrypt_errors = [p for p in providers if p.masked_key == "***decrypt-error***"]
                if decrypt_errors:
                    bad = ", ".join(p.provider for p in decrypt_errors)
                    return DoctorCheck(
                        name="BYOK API keys",
                        status="warn",
                        message=f"{len(providers)} key(s): {names} ({len(decrypt_errors)} decrypt error(s): {bad})",
                        suggestion="Some keys cannot be decrypted. Re-add them with: llmhost keys add <provider> <key>",
                    )
                return DoctorCheck(
                    name="BYOK API keys",
                    status="ok",
                    message=f"{len(providers)} key(s): {names}",
                )
            return DoctorCheck(
                name="BYOK API keys",
                status="warn",
                message="No keys configured",
                suggestion="Add cloud keys with: llmhost keys add <provider> <key>",
            )
        except Exception as exc:
            return DoctorCheck(name="BYOK API keys", status="fail", message=str(exc))

    async def check_port(self) -> DoctorCheck:
        """Verify default port is available."""
        port = self._config.server.port
        host = self._config.server.host
        port_free = self._is_port_free(host, port)
        return DoctorCheck(
            name="Proxy port",
            status="ok" if port_free else "warn",
            message=f"{host}:{port} {'available' if port_free else 'in use'}",
            suggestion=f"Port {port} is occupied. Use --port to pick another." if not port_free else None,
        )

    async def check_tier(self) -> DoctorCheck:
        """Detect installed pip tier (core/smart/full)."""
        tiers_found: list[str] = ["core"]

        # Smart tier markers
        smart_modules = ["onnxruntime", "faiss", "tokenizers"]
        smart_available = all(self._can_import(m) for m in smart_modules)
        if smart_available:
            tiers_found.append("smart")

        # Full tier markers
        full_modules = ["torch", "transformers", "sentence_transformers"]
        full_available = all(self._can_import(m) for m in full_modules)
        if full_available:
            tiers_found.append("full")

        tier_str = " + ".join(tiers_found)
        if full_available:
            msg = f"Installed: [{tier_str}] — all router tiers available"
        elif smart_available:
            msg = f"Installed: [{tier_str}] — kNN + ModernBERT router available"
        else:
            msg = f"Installed: [{tier_str}] — rule-based router only"

        return DoctorCheck(
            name="Installed tier",
            status="ok",
            message=msg,
            suggestion="Upgrade with: pip install llmhosts[smart] or llmhost[full]" if not smart_available else None,
        )

    async def check_disk(self) -> DoctorCheck:
        """Verify sufficient disk space (>1GB free)."""
        disk_total, disk_free = self._get_disk_space()
        disk_ok = disk_free > 1.0
        return DoctorCheck(
            name="Disk space",
            status="ok" if disk_ok else "warn",
            message=f"{disk_free:.1f} GB free / {disk_total:.1f} GB total",
            suggestion="Low disk space may prevent model downloads." if not disk_ok else None,
        )

    async def check_hardware(self) -> DoctorCheck:
        """Detect GPU, RAM, CPU."""
        try:
            from llmhosts.discovery.hardware import HardwareDetector

            hw = await HardwareDetector.detect()
            parts: list[str] = []
            if hw.gpus:
                for gpu in hw.gpus:
                    vram_gb = round(gpu.vram_total_mb / 1024, 1)
                    parts.append(f"{gpu.name} ({vram_gb}GB VRAM)")
                gpu_str = ", ".join(parts)
            else:
                gpu_str = "No GPU detected"
            msg = f"{gpu_str}, {hw.ram_total_gb:.0f}GB RAM, {hw.cpu_cores} CPU cores"
            return DoctorCheck(
                name="Hardware",
                status="ok" if hw.gpus else "warn",
                message=msg,
                suggestion="A GPU is recommended for local inference performance." if not hw.gpus else None,
            )
        except Exception as exc:
            return DoctorCheck(name="Hardware", status="fail", message=f"Detection failed: {exc}")

    async def check_database(self) -> DoctorCheck:
        """Verify SQLite database is accessible and tables exist."""
        from llmhosts.constants import DB_FILENAME

        db_path = self._data_dir / DB_FILENAME
        if not db_path.exists():
            return DoctorCheck(
                name="Database",
                status="warn",
                message=f"Database not found at {db_path}",
                suggestion="Database will be created on first server start.",
            )

        try:
            import aiosqlite

            async with aiosqlite.connect(str(db_path)) as db:
                # Check for expected tables
                cursor = await db.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = [row[0] for row in await cursor.fetchall()]

                if not tables:
                    return DoctorCheck(
                        name="Database",
                        status="warn",
                        message=f"Database exists but has no tables ({db_path})",
                        suggestion="Tables will be created on first server start.",
                    )

                # Quick integrity check
                cursor = await db.execute("PRAGMA integrity_check")
                row = await cursor.fetchone()
                integrity = row[0] if row else "unknown"
                if integrity != "ok":
                    return DoctorCheck(
                        name="Database",
                        status="fail",
                        message=f"Database integrity check failed: {integrity}",
                        suggestion="Delete the database file and restart. Data will be re-created.",
                    )

                return DoctorCheck(
                    name="Database",
                    status="ok",
                    message=f"{len(tables)} table(s): {', '.join(sorted(tables)[:5])}",
                )
        except Exception as exc:
            return DoctorCheck(name="Database", status="fail", message=f"Database error: {exc}")

    async def check_cache(self) -> DoctorCheck:
        """Verify cache is functional (write + read test)."""
        if not self._config.cache.enabled:
            return DoctorCheck(
                name="Cache",
                status="ok",
                message="Cache is disabled in config",
            )

        try:
            import hashlib
            import time

            # Simple write/read test using a temp file in data dir
            test_dir = self._data_dir / "cache"
            test_dir.mkdir(parents=True, exist_ok=True)

            test_key = f"doctor-test-{time.time_ns()}"
            test_value = b"llmhost-cache-test-payload"
            test_hash = hashlib.sha256(test_key.encode()).hexdigest()[:16]
            test_file = test_dir / f".doctor-{test_hash}"

            # Write
            start = asyncio.get_event_loop().time()
            test_file.write_bytes(test_value)

            # Read back
            read_back = test_file.read_bytes()
            elapsed_ms = (asyncio.get_event_loop().time() - start) * 1000

            # Cleanup
            test_file.unlink(missing_ok=True)

            if read_back == test_value:
                # Check cache directory size
                cache_size_mb = sum(f.stat().st_size for f in test_dir.rglob("*") if f.is_file()) / (1024 * 1024)
                return DoctorCheck(
                    name="Cache",
                    status="ok",
                    message=f"Write/read OK ({elapsed_ms:.1f}ms), cache dir: {cache_size_mb:.1f}MB",
                )
            return DoctorCheck(
                name="Cache",
                status="fail",
                message="Cache read-back mismatch",
                suggestion="Check filesystem permissions on ~/.llmhosts/cache/",
            )
        except Exception as exc:
            return DoctorCheck(name="Cache", status="fail", message=f"Cache test failed: {exc}")

    # ------------------------------------------------------------------
    # Static helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _is_port_free(host: str, port: int) -> bool:
        """Check if a TCP port is available."""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(1)
                s.bind((host, port))
            return True
        except OSError:
            return False

    @staticmethod
    def _can_import(module: str) -> bool:
        """Check if a module can be imported without triggering side effects."""
        try:
            importlib.import_module(module)
            return True
        except ImportError:
            return False

    @staticmethod
    def _get_disk_space() -> tuple[float, float]:
        """Return (total_gb, free_gb) for the home directory filesystem."""
        try:
            usage = shutil.disk_usage(str(Path.home()))
            return (round(usage.total / (1024**3), 1), round(usage.free / (1024**3), 1))
        except OSError:
            return (0.0, 0.0)
