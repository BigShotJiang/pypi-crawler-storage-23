"""LLMHosts tunnel -- make your local proxy accessible from anywhere.

Supports Tailscale (preferred, zero-config mesh) and Cloudflare
(fallback, free quick tunnels).

Usage::

    from llmhosts.tunnel import TunnelManager, TunnelConfig

    mgr = TunnelManager()
    status = await mgr.start()
    print(status.url)
"""

from __future__ import annotations

from llmhosts.tunnel.manager import TunnelManager
from llmhosts.tunnel.models import TunnelConfig, TunnelProvider, TunnelStatus

__all__ = [
    "TunnelConfig",
    "TunnelManager",
    "TunnelProvider",
    "TunnelStatus",
]
