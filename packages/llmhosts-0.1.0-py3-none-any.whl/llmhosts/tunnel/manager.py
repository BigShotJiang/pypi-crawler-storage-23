"""Tunnel lifecycle orchestrator with auto-detection.

``TunnelManager`` is the main entry point for the tunnel subsystem.
It detects available providers, picks the best one (or uses an explicit
choice), starts/stops the tunnel, and manages authentication.

Usage::

    mgr = TunnelManager()
    status = await mgr.start()
    print(f"Your LLMHosts is accessible at: {status.url}")
    # ... later ...
    await mgr.stop()
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from llmhosts.tunnel.auth import TunnelAuth
from llmhosts.tunnel.cloudflare import CloudflareTunnel
from llmhosts.tunnel.detector import TunnelDetector
from llmhosts.tunnel.models import TunnelConfig, TunnelProvider, TunnelStatus
from llmhosts.tunnel.tailscale import TailscaleTunnel

if TYPE_CHECKING:
    from pathlib import Path

logger = logging.getLogger(__name__)


class TunnelManager:
    """Orchestrate tunnel lifecycle with auto-detection.

    Supports Tailscale (preferred) and Cloudflare (fallback).
    Handles auth key generation and graceful shutdown.
    """

    def __init__(self, config_dir: Path | None = None) -> None:
        self._config_dir = config_dir
        self._tailscale: TailscaleTunnel | None = None
        self._cloudflare: CloudflareTunnel | None = None
        self._active_provider: TunnelProvider = TunnelProvider.NONE
        self._auth: TunnelAuth | None = None
        self._status: TunnelStatus = TunnelStatus()

    @property
    def auth(self) -> TunnelAuth | None:
        """The auth handler, available after :meth:`start`."""
        return self._auth

    @property
    def active_provider(self) -> TunnelProvider:
        """The currently active provider."""
        return self._active_provider

    async def start(self, config: TunnelConfig | None = None) -> TunnelStatus:
        """Auto-detect and start the best available tunnel.

        1. Detect available providers (or use explicit ``config.provider``).
        2. Pick the best one.
        3. Start the tunnel.
        4. Load/generate auth key.
        5. Return status with URL.
        """
        cfg = config or TunnelConfig()

        # -- Determine provider --------------------------------------------------

        chosen: TunnelProvider
        if cfg.provider and cfg.provider != TunnelProvider.NONE:
            chosen = cfg.provider
            logger.info("Using explicitly configured provider: %s", chosen.value)
        else:
            available = await TunnelDetector.detect()
            if not available:
                return TunnelStatus(
                    provider=TunnelProvider.NONE,
                    active=False,
                    local_port=cfg.port,
                    error=(
                        "No tunnel providers found. Install one of:\n"
                        "  - Tailscale: https://tailscale.com/download\n"
                        "  - Cloudflare: https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/"
                    ),
                )
            chosen = available[0]
            logger.info(
                "Auto-detected providers: %s -- using %s",
                [p.value for p in available],
                chosen.value,
            )

        # -- Start the tunnel ----------------------------------------------------

        if chosen == TunnelProvider.TAILSCALE:
            self._tailscale = TailscaleTunnel()
            status = await self._tailscale.start(port=cfg.port, funnel=cfg.funnel)
        elif chosen == TunnelProvider.CLOUDFLARE:
            self._cloudflare = CloudflareTunnel()
            status = await self._cloudflare.start(port=cfg.port, hostname=cfg.hostname)
        else:
            status = TunnelStatus(
                provider=TunnelProvider.NONE,
                active=False,
                local_port=cfg.port,
                error="Unknown provider",
            )

        self._active_provider = chosen
        self._status = status

        # -- Auth ----------------------------------------------------------------

        if status.active and cfg.auth_required:
            self._auth = await TunnelAuth.load(self._config_dir)
            logger.info("Tunnel auth enabled (key loaded)")

        return status

    async def stop(self) -> None:
        """Stop any active tunnel and clean up resources."""
        if self._tailscale:
            await self._tailscale.stop()
            self._tailscale = None
        if self._cloudflare:
            await self._cloudflare.stop()
            self._cloudflare = None

        self._active_provider = TunnelProvider.NONE
        self._status = TunnelStatus()
        logger.info("Tunnel stopped")

    async def status(self) -> TunnelStatus:
        """Get current tunnel status by querying the active provider."""
        if self._active_provider == TunnelProvider.TAILSCALE and self._tailscale:
            self._status = await self._tailscale.status()
        elif self._active_provider == TunnelProvider.CLOUDFLARE and self._cloudflare:
            self._status = await self._cloudflare.status()
        else:
            self._status = TunnelStatus(provider=TunnelProvider.NONE, active=False)
        return self._status

    async def restart(self, config: TunnelConfig | None = None) -> TunnelStatus:
        """Stop and restart the tunnel."""
        await self.stop()
        return await self.start(config)
