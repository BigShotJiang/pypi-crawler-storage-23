"""Pydantic v2 models for tunnel configuration, status, and provider info."""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from datetime import datetime


class TunnelProvider(str, Enum):
    """Supported tunnel providers."""

    TAILSCALE = "tailscale"
    CLOUDFLARE = "cloudflare"
    NONE = "none"


class TunnelStatus(BaseModel):
    """Current status of a tunnel connection."""

    provider: TunnelProvider = TunnelProvider.NONE
    active: bool = False
    url: str | None = None
    local_port: int = 4000
    started_at: datetime | None = None
    error: str | None = None
    pid: int | None = None

    @property
    def display_url(self) -> str:
        """URL suitable for display, or a placeholder."""
        return self.url or "(not connected)"


class TunnelConfig(BaseModel):
    """User-facing tunnel configuration."""

    provider: TunnelProvider | None = None  # None = auto-detect
    port: int = Field(default=4000, ge=1, le=65535)
    hostname: str | None = None  # Custom hostname for Cloudflare named tunnel
    funnel: bool = False  # Tailscale Funnel (public) vs Serve (mesh only)
    auth_required: bool = True  # Require API key for tunnel access


class TailscaleInfo(BaseModel):
    """Information gathered from ``tailscale status --json``."""

    installed: bool = False
    connected: bool = False
    hostname: str | None = None  # e.g. "devbox"
    tailnet_ip: str | None = None  # e.g. "100.x.y.z"
    dns_name: str | None = None  # e.g. "devbox.tail12345.ts.net"
    version: str | None = None


class CloudflareInfo(BaseModel):
    """Information gathered from ``cloudflared --version``."""

    installed: bool = False
    version: str | None = None
    has_credentials: bool = False
