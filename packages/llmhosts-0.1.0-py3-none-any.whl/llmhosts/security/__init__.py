"""LLMHosts TrustShield security platform.

Pillars:
1. PromptGuard -- prompt injection defense (prompt_guard.py, patterns.py)
2. TrustLedger -- tamper-evident audit (audit/hmac_chain.py, audit/exporter.py)
3. AdaptiveShield -- model-weighted sliding window rate limiting (adaptive_rate_limit.py)
4. SecureMesh -- mTLS for backend connections (future: tls_manager.py, mtls.py)
5. TransparencyDashboard -- privacy manifest, resource monitoring (transparency.py, privacy_manifest.py, resource_monitor.py)
"""

from __future__ import annotations
