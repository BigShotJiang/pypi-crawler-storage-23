"""Pydantic v2 models for RBAC and Team Management (F-024).

Roles: admin, developer, viewer. Per-member model allowlists, budgets,
spending alerts, and access decisions.
"""

from __future__ import annotations

from datetime import datetime  # noqa: TC003 -- Pydantic needs this at runtime
from enum import Enum

from pydantic import BaseModel, Field


class Role(str, Enum):
    """Role a team member can have."""

    ADMIN = "admin"  # Full control: manage team, set budgets, all models
    DEVELOPER = "developer"  # Use models, see own stats, no team management
    VIEWER = "viewer"  # Read-only: see dashboard, no model access


class TeamMember(BaseModel):
    """A member of a team with role, allowlist, and spending tracking."""

    id: str
    email: str
    name: str
    role: Role
    model_allowlist: list[str] = Field(default_factory=list)  # Empty = all models
    monthly_budget: float | None = None  # Spending cap in USD
    current_spend: float = 0.0
    joined_at: datetime
    last_active: datetime | None = None
    active: bool = True
    api_key_hash: str | None = None  # SHA-256 hash for API key -> member lookup


class Team(BaseModel):
    """A team with members, plan, and seat limits."""

    id: str
    name: str
    owner_id: str
    plan: str = "team"
    max_seats: int = 15
    members: list[TeamMember] = Field(default_factory=list)
    created_at: datetime


class SpendingAlert(BaseModel):
    """A spending threshold alert for a member or team-wide."""

    id: str
    team_id: str
    member_id: str | None = None  # None = team-wide
    threshold: float  # USD amount
    period: str = "month"  # "day", "week", "month"
    triggered: bool = False
    triggered_at: datetime | None = None


class ModelAllowlist(BaseModel):
    """Role-based model allowlist (for future use)."""

    role: Role
    models: list[str]  # Model patterns: "llama*", "gpt-4*", etc.


class AccessDecision(BaseModel):
    """Result of an access check for a member requesting a model."""

    allowed: bool
    reason: str
    role: Role
    model_requested: str
    budget_remaining: float | None = None
