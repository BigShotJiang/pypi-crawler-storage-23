"""``llmhost up`` -- unified command that turns a home GPU into a cloud API.

Orchestrates:
1. Start Ollama if not running
2. Start local proxy (FastAPI)
3. Open tunnel (auto-detect Cloudflare Quick Tunnel or Tailscale Funnel)
4. Authenticate with LLMHosts.com (Device Code Flow, RFC 8628)
5. Register this device with the server
6. Start heartbeat loop
7. Print API endpoint and key

This is the zero-friction experience: ``pip install llmhosts && llmhosts up``
"""

from __future__ import annotations

import asyncio
import logging
import platform
import signal
from typing import TYPE_CHECKING

import httpx

from llmhosts.auth.device_flow import AuthenticationError, Credentials, DeviceCodeFlow
from llmhosts.tunnel.manager import TunnelManager
from llmhosts.tunnel.models import TunnelConfig

if TYPE_CHECKING:
    from rich.console import Console

logger = logging.getLogger(__name__)

# Heartbeat interval in seconds
_HEARTBEAT_INTERVAL = 30

# Server URL (production)
_DEFAULT_SERVER_URL = "https://llmhosts.com"


class LLMHostUp:
    """Orchestrates the ``llmhost up`` flow."""

    def __init__(
        self,
        console: Console,
        *,
        server_url: str = _DEFAULT_SERVER_URL,
        port: int = 4000,
        no_tui: bool = True,
    ) -> None:
        self._console = console
        self._server_url = server_url
        self._port = port
        self._no_tui = no_tui
        self._tunnel_mgr = TunnelManager()
        self._auth_flow = DeviceCodeFlow(server_url=server_url)
        self._credentials: Credentials | None = None
        self._tunnel_url: str | None = None
        self._device_name: str = platform.node() or "my-device"
        self._shutdown_event = asyncio.Event()
        self._heartbeat_task: asyncio.Task[None] | None = None

    async def run(self) -> None:
        """Execute the full ``llmhost up`` flow."""
        self._console.print()
        self._console.print("[bold cyan]LLMHosts[/bold cyan] [dim]— Your GPU, Everywhere[/dim]")
        self._console.print()

        # Step 1: Check/start Ollama
        await self._ensure_ollama()

        # Step 2: Start tunnel
        await self._start_tunnel()

        if not self._tunnel_url:
            self._console.print("[red]Failed to establish tunnel. Cannot continue.[/red]")
            return

        # Step 3: Authenticate
        await self._authenticate()

        if not self._credentials:
            self._console.print("[red]Authentication failed. Cannot continue.[/red]")
            return

        # Step 4: Register device
        await self._register_device()

        # Step 5: Print success banner
        self._print_success()

        # Step 6: Start heartbeat + local proxy, wait for shutdown
        await self._run_with_heartbeat()

    # ------------------------------------------------------------------
    # Step 1: Ollama
    # ------------------------------------------------------------------

    async def _ensure_ollama(self) -> None:
        """Check if Ollama is running. If not, try to start it."""
        self._console.print("[dim]Checking Ollama...[/dim]")
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.get("http://localhost:11434/api/tags")
                if resp.status_code == 200:
                    models = resp.json().get("models", [])
                    model_names = [m.get("name", "unknown") for m in models]
                    self._console.print(
                        f"  [green]Ollama running[/green] — {len(model_names)} model(s): "
                        + ", ".join(model_names[:5])
                        + ("..." if len(model_names) > 5 else "")
                    )
                    return
        except Exception:
            pass

        self._console.print("  [yellow]Ollama not detected.[/yellow] Please start Ollama first:")
        self._console.print("  [dim]  ollama serve[/dim]")
        self._console.print()

    # ------------------------------------------------------------------
    # Step 2: Tunnel
    # ------------------------------------------------------------------

    async def _start_tunnel(self) -> None:
        """Start a tunnel with auto-detection."""
        self._console.print("[dim]Starting tunnel...[/dim]")

        config = TunnelConfig(
            port=self._port,
            funnel=True,  # Public access for Tailscale
            auth_required=False,  # Auth handled by server-side relay
        )

        status = await self._tunnel_mgr.start(config)

        if status.active and status.url:
            self._tunnel_url = status.url
            provider_label = status.provider.value.title()
            self._console.print(f"  [green]Tunnel active[/green] via {provider_label}: {status.url}")
        else:
            error = status.error or "Unknown tunnel error"
            self._console.print(f"  [red]Tunnel failed:[/red] {error}")

    # ------------------------------------------------------------------
    # Step 3: Authentication
    # ------------------------------------------------------------------

    async def _authenticate(self) -> None:
        """Authenticate with LLMHosts.com via Device Code Flow."""
        # Try loading existing credentials first
        existing = await self._auth_flow.load_credentials()
        if existing:
            # Verify credentials are still valid
            try:
                async with httpx.AsyncClient(timeout=10.0) as client:
                    resp = await client.get(
                        f"{self._server_url}/api/devices",
                        headers={"Authorization": f"Bearer {existing.api_key}"},
                    )
                    if resp.status_code == 200:
                        self._credentials = existing
                        self._console.print(
                            f"  [green]Authenticated[/green] as {existing.email} ({existing.plan} plan)"
                        )
                        return
            except Exception:
                pass

        # Need fresh authentication
        self._console.print()
        self._console.print("[bold]Authenticate with LLMHosts.com[/bold]")

        try:
            creds = await self._auth_flow.authenticate(
                auto_open_browser=True,
                on_user_code=self._display_auth_code,
            )
            self._credentials = creds
            self._console.print()
            self._console.print(f"  [green]Authenticated[/green] as {creds.email} ({creds.plan} plan)")
        except AuthenticationError as exc:
            self._console.print(f"  [red]Auth failed:[/red] {exc}")

    def _display_auth_code(self, user_code: str, verification_uri: str) -> None:
        """Display the device code for the user."""
        from rich.panel import Panel

        self._console.print()
        self._console.print(
            Panel(
                f"[bold]Open[/bold] [cyan]{verification_uri}[/cyan]\n"
                f"[bold]Enter code:[/bold] [bold yellow]{user_code}[/bold yellow]",
                title="[bold]Authorize This Device[/bold]",
                border_style="blue",
                padding=(1, 2),
            )
        )
        self._console.print("[dim]Waiting for authorization...[/dim]")

    # ------------------------------------------------------------------
    # Step 4: Device registration
    # ------------------------------------------------------------------

    async def _register_device(self) -> None:
        """Register this device with the LLMHosts.com server."""
        if not self._credentials or not self._tunnel_url:
            return

        self._console.print("[dim]Registering device...[/dim]")

        # Detect hardware and models
        hardware = await self._detect_hardware()
        models = await self._discover_models()

        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.post(
                    f"{self._server_url}/api/devices",
                    headers={"Authorization": f"Bearer {self._credentials.api_key}"},
                    json={
                        "name": self._device_name,
                        "tunnel_url": self._tunnel_url,
                        "models": models,
                        "hardware": hardware,
                    },
                )
                if resp.status_code in (200, 201):
                    self._console.print(f'  [green]Device registered[/green] as "{self._device_name}"')
                else:
                    self._console.print(f"  [yellow]Registration warning:[/yellow] {resp.text}")
        except Exception as exc:
            self._console.print(f"  [yellow]Registration failed:[/yellow] {exc}")

    async def _detect_hardware(self) -> str:
        """Best-effort hardware summary."""
        try:
            from llmhosts.discovery.hardware import HardwareDetector

            hw = await HardwareDetector.detect()
            parts: list[str] = []
            if hw.gpus:
                for gpu in hw.gpus:
                    vram_gb = round(gpu.vram_total_mb / 1024, 1)
                    parts.append(f"{gpu.name} ({vram_gb}GB)")
            parts.append(f"{hw.ram_total_gb:.0f}GB RAM")
            return ", ".join(parts)
        except Exception:
            return platform.machine()

    async def _discover_models(self) -> list[str]:
        """Discover locally-available models from Ollama."""
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.get("http://localhost:11434/api/tags")
                if resp.status_code == 200:
                    models = resp.json().get("models", [])
                    return [m.get("name", "unknown") for m in models]
        except Exception:
            pass
        return []

    # ------------------------------------------------------------------
    # Step 5: Success banner
    # ------------------------------------------------------------------

    def _print_success(self) -> None:
        """Print the success banner with API details."""
        from rich.panel import Panel

        if not self._credentials:
            return

        relay_base = f"{self._server_url}/api/relay/v1"

        self._console.print()
        self._console.print(
            Panel(
                f"[bold green]Your GPU is live![/bold green]\n"
                f"\n"
                f"[bold]API Endpoint:[/bold]  [cyan]{relay_base}[/cyan]\n"
                f"[bold]API Key:[/bold]       [dim]{self._credentials.api_key[:20]}...[/dim]\n"
                f"[bold]Device:[/bold]        {self._device_name}\n"
                f"[bold]Tunnel:[/bold]        {self._tunnel_url}\n"
                f"\n"
                f"[bold]Try it:[/bold]\n"
                f"  curl {relay_base}/chat/completions \\\n"
                f'    -H "Authorization: Bearer {self._credentials.api_key[:20]}..." \\\n'
                f'    -H "Content-Type: application/json" \\\n'
                f'    -d \'{{"model": "llama3.1", "messages": [{{"role": "user", "content": "Hello"}}]}}\'\n'
                f"\n"
                f"[bold]Or set environment variables:[/bold]\n"
                f"  export OPENAI_BASE_URL={relay_base}\n"
                f"  export OPENAI_API_KEY={self._credentials.api_key}",
                title="[bold]LLMHosts — GPU-as-API[/bold]",
                border_style="green",
                padding=(1, 2),
            )
        )
        self._console.print()
        self._console.print("[dim]Press Ctrl+C to disconnect.[/dim]")
        self._console.print()

    # ------------------------------------------------------------------
    # Step 6: Heartbeat + wait
    # ------------------------------------------------------------------

    async def _run_with_heartbeat(self) -> None:
        """Run heartbeat loop and local proxy until shutdown."""
        # Set up signal handlers
        loop = asyncio.get_event_loop()

        def _on_signal() -> None:
            self._shutdown_event.set()

        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, _on_signal)

        # Start heartbeat task
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

        # Start the local proxy server
        proxy_task = asyncio.create_task(self._run_proxy())

        # Wait for shutdown signal
        await self._shutdown_event.wait()

        # Cleanup
        self._console.print("\n[dim]Shutting down...[/dim]")

        if self._heartbeat_task:
            self._heartbeat_task.cancel()

        proxy_task.cancel()

        # Mark device offline
        await self._mark_device_offline()

        # Stop tunnel
        await self._tunnel_mgr.stop()

        self._console.print("[dim]Disconnected. Your GPU is no longer accessible remotely.[/dim]")

    async def _heartbeat_loop(self) -> None:
        """Send heartbeat to server every 30 seconds."""
        while not self._shutdown_event.is_set():
            try:
                await asyncio.sleep(_HEARTBEAT_INTERVAL)
                if self._shutdown_event.is_set():
                    break

                if not self._credentials:
                    continue

                models = await self._discover_models()

                async with httpx.AsyncClient(timeout=10.0) as client:
                    await client.post(
                        f"{self._server_url}/api/devices/heartbeat",
                        headers={"Authorization": f"Bearer {self._credentials.api_key}"},
                        json={
                            "name": self._device_name,
                            "tunnel_url": self._tunnel_url,
                            "models": models,
                            "status": "online",
                        },
                    )
                    logger.debug("Heartbeat sent")
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.debug("Heartbeat failed: %s", exc)

    async def _run_proxy(self) -> None:
        """Run the local FastAPI proxy server."""
        try:
            from llmhosts.config import load_config
            from llmhosts.server import LLMHostsServer

            config = load_config()
            config.server.port = self._port
            config.server.host = "0.0.0.0"  # nosec B104 — must bind all interfaces for tunnel
            config.dashboard.tui = False

            server = LLMHostsServer(config)
            await server.startup()

            if server._app is None:
                logger.error("Server app failed to initialize")
                return

            # Run uvicorn
            import uvicorn

            uvi_config = uvicorn.Config(
                server._app,
                host=config.server.host,
                port=config.server.port,
                log_level="warning",
            )
            uvi_server = uvicorn.Server(uvi_config)
            await uvi_server.serve()
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            logger.error("Proxy server error: %s", exc)

    async def _mark_device_offline(self) -> None:
        """Mark device as offline on the server."""
        if not self._credentials:
            return
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                await client.post(
                    f"{self._server_url}/api/devices/heartbeat",
                    headers={"Authorization": f"Bearer {self._credentials.api_key}"},
                    json={
                        "name": self._device_name,
                        "status": "offline",
                    },
                )
        except Exception:
            pass  # Best-effort
