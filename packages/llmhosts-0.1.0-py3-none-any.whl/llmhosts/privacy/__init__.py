"""LLMHosts privacy module -- PII detection and privacy-aware routing classification.

Classifies request content into privacy tiers:
    - PUBLIC: No PII detected, safe for cloud routing
    - PRIVATE: Contains PII (emails, phone numbers), local-only routing
    - SENSITIVE: High-risk PII (SSNs, credit cards), encrypted local-only routing
"""

from __future__ import annotations

from llmhosts.privacy.detector import PIIDetector, PIIMatch, PIIType
from llmhosts.privacy.models import PrivacyClassification, PrivacySettings, PrivacyTier

__all__ = [
    "PIIDetector",
    "PIIMatch",
    "PIIType",
    "PrivacyClassification",
    "PrivacySettings",
    "PrivacyTier",
]
