"""Ollama auto-discovery, hardware detection, tunnel tool probing, model suggestions, vLLM, and mDNS LAN discovery."""

from __future__ import annotations

from llmhosts.discovery.engine import EngineManager, EngineType, InferenceEngine
from llmhosts.discovery.hardware import HardwareDetector
from llmhosts.discovery.mdns import LANNode, MDNSDiscovery, get_discovered_nodes, scan_lan
from llmhosts.discovery.models import (
    GPUInfo,
    HardwareProfile,
    ModelDetails,
    ModelInfo,
    OllamaHealth,
    OllamaModel,
    RunningModel,
)
from llmhosts.discovery.ollama import OllamaDiscovery
from llmhosts.discovery.suggest import ModelSuggester, ModelSuggestion
from llmhosts.discovery.vllm import VLLMDiscovery, VLLMHealth, VLLMMetrics, VLLMModel

__all__ = [
    "EngineManager",
    "EngineType",
    "GPUInfo",
    "HardwareDetector",
    "HardwareProfile",
    "InferenceEngine",
    "LANNode",
    "MDNSDiscovery",
    "ModelDetails",
    "ModelInfo",
    "ModelSuggester",
    "ModelSuggestion",
    "OllamaDiscovery",
    "OllamaHealth",
    "OllamaModel",
    "RunningModel",
    "VLLMDiscovery",
    "VLLMHealth",
    "VLLMMetrics",
    "VLLMModel",
    "get_discovered_nodes",
    "scan_lan",
]
