"""LLMHosts -- Your Personal AI Cloud."""

__version__ = "0.1.0"
