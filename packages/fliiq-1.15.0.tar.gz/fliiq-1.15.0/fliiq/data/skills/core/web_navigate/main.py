"""Web navigation skill — browse websites, extract info, fill forms."""

import os


async def handler(params: dict) -> dict:
    """Navigate a website and execute a task using a browser agent."""
    try:
        from fliiq.runtime.browser.engine import run_browser_task
    except ImportError:
        raise ValueError(
            "browser-use is not installed. Run:\n"
            "  pip install fliiq[browser]\n"
            "  playwright install chromium"
        )

    # CLI --show-browser flag sets env var; LLM param overrides if explicitly passed
    browser_visible = params.get("browser_visible") or os.environ.get("FLIIQ_SHOW_BROWSER") == "1"

    return await run_browser_task(
        task=params["task"],
        url=params.get("url"),
        browser_visible=browser_visible,
        max_steps=params.get("max_steps", 50),
    )
