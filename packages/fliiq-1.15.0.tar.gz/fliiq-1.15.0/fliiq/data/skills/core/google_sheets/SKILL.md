---
name: google_sheets
description: "Manage Google Sheets: create spreadsheets, read/write cell ranges, append rows. Supports multiple Google accounts. Requires OAuth via `fliiq google auth`."
---

Use this tool to create and manage Google Sheets spreadsheets. Supports reading cell ranges, writing data, and appending rows.

## Setup Required
1. Create a Google Cloud project at https://console.cloud.google.com/
2. Enable the Google Sheets API
3. Create OAuth 2.0 credentials (Desktop app type), set redirect URI to http://localhost:8080/callback
4. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in your .env file
5. Run `fliiq google auth` to authorize each Google account

If you authorized before Sheets support was added, run `fliiq google auth` again to grant Sheets permissions.

## Available Actions
- create: Create a new spreadsheet
- get_metadata: Get spreadsheet metadata (title, sheets list, etc.)
- read_range: Read cell values from a range (A1 notation)
- write_range: Write values to a range
- append_rows: Append rows after existing data

## Range Notation (A1)
- `Sheet1!A1:D10` — specific range on Sheet1
- `A1:D10` — range on the first sheet
- `Sheet1` — entire sheet
- `Sheet1!A:A` — entire column A

## Multi-Account
Use the `account_email` parameter to specify which Google account to use. Defaults to the first authorized account.
