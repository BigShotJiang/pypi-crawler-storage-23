---
name: send_telegram_audio
description: "Send an audio file via Telegram Bot API. Accepts MP3, M4A, OGG files. Use after text_to_speech to deliver pronunciation audio."
---

Send an audio file to a Telegram chat. The file is uploaded via multipart/form-data using Telegram's sendAudio API.

After successful upload, the local audio file is deleted to clean up temp files.
