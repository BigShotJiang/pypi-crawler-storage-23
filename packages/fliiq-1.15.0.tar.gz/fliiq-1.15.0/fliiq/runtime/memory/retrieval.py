"""Memory retrieval — keyword search and daily log loading."""

import re
from dataclasses import dataclass
from datetime import date, timedelta

from fliiq.runtime.memory.manager import MemoryManager


@dataclass
class SearchResult:
    file_name: str
    line_number: int
    line: str
    context: str  # 1 line above/below


def search_memories(
    manager: MemoryManager,
    query: str,
    ignore_case: bool = True,
    max_results: int = 50,
) -> list[SearchResult]:
    """Regex search across all .md files in the memory directory."""
    flags = re.IGNORECASE if ignore_case else 0
    try:
        regex = re.compile(query, flags)
    except re.error as e:
        raise ValueError(f"Invalid search pattern: {e}")

    results = []
    memory_dir = manager.memory_dir
    if not memory_dir.is_dir():
        return results

    for md_file in sorted(memory_dir.rglob("*.md")):
        if len(results) >= max_results:
            break
        try:
            lines = md_file.read_text(encoding="utf-8").splitlines()
        except (OSError, UnicodeDecodeError):
            continue

        rel_name = str(md_file.relative_to(memory_dir))
        for i, line in enumerate(lines):
            if len(results) >= max_results:
                break
            if regex.search(line):
                # Build context: 1 line above/below
                ctx_lines = []
                if i > 0:
                    ctx_lines.append(lines[i - 1])
                ctx_lines.append(line)
                if i < len(lines) - 1:
                    ctx_lines.append(lines[i + 1])
                context = "\n".join(ctx_lines)

                results.append(SearchResult(
                    file_name=rel_name,
                    line_number=i + 1,
                    line=line,
                    context=context,
                ))

    return results


def load_recent_daily(manager: MemoryManager, days: int = 3) -> str:
    """Concatenate the last N days of daily logs."""
    today = date.today()
    parts = []
    for offset in range(days):
        d = today - timedelta(days=offset)
        date_str = d.isoformat()
        content = manager.load_memory(date_str)
        if content:
            parts.append(f"### {date_str}\n{content}")

    return "\n\n".join(parts)
