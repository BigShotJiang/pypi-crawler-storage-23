"""Textual TUI for Fliiq — Claude Code-style interface."""

from fliiq.cli.tui.app import FliiqApp

__all__ = ["FliiqApp"]
