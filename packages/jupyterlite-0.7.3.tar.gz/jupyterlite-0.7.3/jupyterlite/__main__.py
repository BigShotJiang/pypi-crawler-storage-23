if __name__ == "__main__":
    from jupyterlite_core.app import main

    main()
