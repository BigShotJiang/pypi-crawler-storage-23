---
title: Lint changelog
---

### Description

Fixes changelog release dates and updates availability admonitions.
