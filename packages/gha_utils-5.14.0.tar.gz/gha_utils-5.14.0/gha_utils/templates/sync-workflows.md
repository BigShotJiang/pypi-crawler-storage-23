---
title: Sync workflow files
---

### Description

Syncs [thin-caller workflow files](https://github.com/kdeldycke/workflows?tab=readme-ov-file#example-usage) from the upstream [`kdeldycke/workflows`](https://github.com/kdeldycke/workflows) repository. See the [`sync-workflows` job documentation](https://github.com/kdeldycke/workflows?tab=readme-ov-file#githubworkflowsautofixyaml-jobs) for details.
