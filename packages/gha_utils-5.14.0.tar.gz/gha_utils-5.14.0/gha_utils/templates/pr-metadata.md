---
args: [table]
---

<details><summary><code>Workflow metadata</code></summary>

\$table

</details>
