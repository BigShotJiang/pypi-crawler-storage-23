from pathlib import Path
import duckdb
import logging
import hashlib
import json
import re
from datetime import datetime, timedelta, timezone
from typing import Dict, List

# Note: We avoid importing adbc_driver_duckdb/adbc_driver_manager here to
# keep runtime dependencies light. Use stdlib timezone instead.

from agentfoundry.kgraph.base import KGraphBase
from agentfoundry.vectorstores.factory import VectorStoreFactory

logger = logging.getLogger(__name__)


class DuckSqliteGraph(KGraphBase):
    """Knowledge‑graph implementation backed by DuckDB.

    *Facts* are stored relationally while the accompanying text triple is sent
    to the configured `vector_store` for similarity search.  A light JSON column
    keeps arbitrary metadata keyed by the caller (e.g. `user_id`, `org_id`, etc.).
    """

    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, persist_path: str):
        if getattr(self, "_initialized", False):
            return
        from agentfoundry.utils.exceptions import InitializationError

        path = Path(persist_path)
        path.mkdir(parents=True, exist_ok=True)
        self.db_path = str(path / "kgraph.duckdb")
        try:
            self.conn = duckdb.connect(self.db_path)
            self._ensure_schema()
        except Exception as exc:
            raise InitializationError(
                component="DuckSqliteGraph",
                message=f"Failed to initialize DuckDB at {self.db_path}: {exc}",
                cause=exc,
            ) from exc
        self.vector_store = VectorStoreFactory.get_store()
        logger.info(f"DuckSqliteGraph initialized at {self.db_path}")
        self._initialized = True

    # ---------------------------------------------------------------------
    # Schema & helpers
    # ---------------------------------------------------------------------
    def _ensure_schema(self) -> None:
        """Create tables / indexes if they do not already exist."""
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS facts (
                id TEXT PRIMARY KEY,
                subject TEXT,
                predicate TEXT,
                obj TEXT,
                user_id TEXT,
                org_id TEXT,
                created_at TIMESTAMP DEFAULT current_timestamp,
                metadata JSON
            )
            """
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_user ON facts(user_id, org_id)"
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_org_created ON facts(org_id, created_at)"
        )

    # Milvus JSON metadata field limit (bytes).  We target a safe ceiling
    # leaving headroom for JSON envelope overhead.
    _VS_META_MAX = 60_000

    @staticmethod
    def _clamp_metadata_for_vs(metadata: Dict, max_bytes: int) -> Dict:
        """Return a copy of *metadata* whose JSON serialisation fits in *max_bytes*.

        Strategy: iteratively find the largest string value and halve it until
        the total fits.  This preserves all keys and as much data as possible.
        """
        compact = dict(metadata)
        while True:
            blob = json.dumps(compact, separators=(",", ":"))
            if len(blob.encode("utf-8")) <= max_bytes:
                return compact
            # Find the largest string value and truncate it
            biggest_key, biggest_len = None, 0
            for k, v in compact.items():
                if isinstance(v, str) and len(v) > biggest_len:
                    biggest_key, biggest_len = k, len(v)
            if biggest_key is None or biggest_len <= 64:
                # Nothing left to shrink – drop non-essential keys
                for drop_key in ("code_content", "docstring"):
                    compact.pop(drop_key, None)
                break
            compact[biggest_key] = compact[biggest_key][: biggest_len // 2] + "…"
        return compact

    @staticmethod
    def _det_id(triple: str, user_id: str, org_id: str) -> str:
        """Deterministically derive the SHA‑256 id from the triple+actor."""
        h = hashlib.sha256()
        h.update(triple.encode())
        h.update(user_id.encode())
        h.update(org_id.encode())
        return h.hexdigest()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def upsert_fact(
        self,
        subject: str,
        predicate: str,
        obj: str,
        metadata: Dict,
    ) -> str:
        """Insert or update a fact and mirror it into the vector store."""
        user_id = metadata.get("user_id", "")
        org_id = metadata.get("org_id", "")
        triple = f"{subject}|{predicate}|{obj}"
        fact_id = self._det_id(triple, user_id, org_id)

        logger.debug(
            "upsert_fact: id=%s user=%s org=%s subj=%s pred=%s obj_len=%d",
            fact_id[:12], user_id, org_id, subject[:40], predicate[:30], len(obj),
        )

        metadata_json = json.dumps(metadata, separators=(",", ":"))
        self.conn.execute(
            "INSERT OR REPLACE INTO facts VALUES (?, ?, ?, ?, ?, ?, current_timestamp, ?)",
            [fact_id, subject, predicate, obj, user_id, org_id, metadata_json],
        )

        # Vector store may throw if the id is already present – swallow and carry on
        vs_meta = self._clamp_metadata_for_vs(metadata, self._VS_META_MAX)
        try:
            self.vector_store.add_texts([triple], metadatas=[vs_meta], ids=[fact_id])
        except ValueError as exc:
            msg = str(exc).lower()
            if "duplicate" in msg or "already" in msg or "exist" in msg:
                logger.debug("upsert_fact: duplicate id %s in vector store (expected): %s", fact_id, exc)
            else:
                logger.warning("upsert_fact: unexpected ValueError adding to vector store: %s", exc, exc_info=True)
        except Exception as exc:
            logger.error("upsert_fact: failed to add fact %s to vector store: %s", fact_id, exc, exc_info=True)

        return fact_id

    def search(
        self,
        query: str,
        *,
        user_id: str,
        org_id: str,
        k: int = 5,
    ) -> List[Dict]:
        logger.debug(
            "KG search: query=%s user=%s org=%s k=%d",
            query[:60], user_id, org_id, k,
        )
        docs = self.vector_store.similarity_search_with_score(
            query, k=k, filter={"user_id": user_id, "org_id": org_id}
        )

        results = []
        for doc, score in docs:
            subj, pred, obj = doc.page_content.split("|", 2)
            results.append(
                {"subject": subj, "predicate": pred, "object": obj, "score": score}
            )
        logger.debug("KG search returned %d results for query=%s", len(results), query[:40])
        return results

    def get_neighbours(self, entity: str, depth: int = 2) -> List[Dict]:
        """Breadth‑first traversal up to *depth* hops from *entity*."""
        q = """
        WITH RECURSIVE hop(n, s, p, o) AS (
            SELECT 1, subject, predicate, obj FROM facts
            WHERE subject = ? OR obj = ?
            UNION ALL
            SELECT n + 1, f.subject, f.predicate, f.obj
            FROM facts f
            JOIN hop h ON f.subject = h.o
            WHERE n < ?
        )
        SELECT s, p, o FROM hop;
        """
        logger.debug("get_neighbours: entity=%s depth=%d", entity[:60], depth)
        rows = self.conn.execute(q, [entity, entity, depth]).fetchall()
        logger.debug("get_neighbours: entity=%s returned %d triples", entity[:40], len(rows))
        return [
            {"subject": s, "predicate": p, "object": o} for s, p, o in rows
        ]

    def purge_expired(self, days: int = 90) -> None:
        """Remove facts whose *created_at* is older than *days*."""
        logger.info("Purging facts older than %d days", days)
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        self.conn.execute("DELETE FROM facts WHERE created_at < ?", [cutoff])

    def delete_context(self, *, org_id: str, graph_slice_id: str) -> int:
        """Delete all triples linked to a particular graph slice id."""
        logger.info("delete_context: org=%s graph_slice_id=%s", org_id, graph_slice_id)
        result = self.conn.execute(
            """
            DELETE FROM facts
            WHERE org_id = ?
              AND json_extract(metadata, '$.graph_slice_id') = ?
            """,
            [org_id, graph_slice_id],
        )
        deleted = result.rowcount if hasattr(result, "rowcount") else 0
        logger.info("delete_context: org=%s graph_slice_id=%s deleted=%d", org_id, graph_slice_id, deleted)
        return deleted

    # Only allow simple alphanumeric/underscore keys in metadata filters
    _SAFE_KEY_RE = re.compile(r"^[A-Za-z0-9_]+$")

    def fetch_by_metadata(self, *, org_id: str, filters: Dict[str, str]) -> List[Dict]:
        """Fetch triples whose metadata JSON includes the supplied key/value filters."""
        logger.debug("fetch_by_metadata: org=%s filters=%s", org_id, list(filters.keys()))
        params = [org_id]
        conditions = ["org_id = ?"]
        for key, value in filters.items():
            if not self._SAFE_KEY_RE.match(key):
                logger.warning("fetch_by_metadata: rejecting unsafe filter key: %r", key)
                continue
            conditions.append("json_extract(metadata, ?) = ?")
            params.append(f"$.{key}")
            params.append(value)

        where_clause = " AND ".join(conditions)
        query = f"SELECT subject, predicate, obj, metadata FROM facts WHERE {where_clause}"
        rows = self.conn.execute(query, params).fetchall()
        results: List[Dict] = []
        for subject, predicate, obj, metadata in rows:
            try:
                meta = json.loads(metadata) if isinstance(metadata, str) else metadata
            except Exception:
                meta = {}
            results.append(
                {
                    "subject": subject,
                    "predicate": predicate,
                    "object": obj,
                    "metadata": meta,
                }
            )
        logger.debug("fetch_by_metadata: org=%s returned %d triples", org_id, len(results))
        return results
