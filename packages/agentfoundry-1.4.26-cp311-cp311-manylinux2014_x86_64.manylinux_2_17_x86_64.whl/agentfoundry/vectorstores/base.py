"""Abstract base-class for vector-store providers.

Moved out of *providers/__init__.py* to follow the guideline that classes
belong in their own dedicated modules.
"""

from __future__ import annotations

import hashlib
import logging
from abc import ABC, abstractmethod
from typing import Any

from langchain_core.documents import Document

logger = logging.getLogger(__name__)


class VectorStore(ABC):  # noqa: D101  (minimal doc)
    """Base class for concrete vector-store provider wrappers."""

    def __init__(self, **kwargs: Any):
        self.kwargs = kwargs
        logger.info(f"Initialized {type(self).__name__} with kwargs={kwargs}")

    # ------------------------------------------------------------------
    # Basic operations expected by *memory_tools* and other call-sites.
    # ------------------------------------------------------------------
    @abstractmethod
    def get_store(self, org_id: str = None):  # pragma: no cover
        """Abstract method implemented by derived classes"""
        raise NotImplementedError

    def add_documents(self, documents, **kwargs):  # type: ignore[no-self-use]
        """Robustly add documents across heterogeneous vector stores.

        - Prefer store.add_documents if available, filtering kwargs to the method's accepted parameters to avoid TypeError on unknown args (e.g., allow_update).
        - Fallback to store.add_texts if present by converting Documents to (texts, metadatas, ids).
        """
        logger.info(f"add_documents called for {len(documents)} docs")
        org_id = kwargs.pop("org_id", None)
        store = self.get_store(org_id=org_id) if org_id is not None else self.get_store()
        add_docs = getattr(store, "add_documents", None)
        if callable(add_docs):
            try:
                # Filter kwargs to those accepted by the store's signature
                import inspect

                sig = inspect.signature(add_docs)
                allowed = set(sig.parameters.keys())
                filt_kwargs = {k: v for k, v in kwargs.items() if k in allowed}
                return add_docs(documents, **filt_kwargs)
            except TypeError:
                logger.debug("add_documents: retrying without extra kwargs", exc_info=True)
                return add_docs(documents)

        add_texts = getattr(store, "add_texts", None)
        if callable(add_texts):

            texts = []
            metadatas = []
            ids = []
            for d in documents:
                if isinstance(d, Document):
                    texts.append(d.page_content)
                    metadatas.append(getattr(d, "metadata", None) or {})
                    ids.append(getattr(d, "id", None))
                else:
                    texts.append(str(d))
                    metadatas.append({})
                    ids.append(None)
            try:
                return add_texts(texts, metadatas=metadatas, ids=ids)
            except TypeError:
                logger.warning("add_texts() does not support metadatas/ids; falling back to texts-only", exc_info=True)
                return add_texts(texts)

        logger.error(f"add_documents() not implemented for {type(self).__name__}")
        raise NotImplementedError("Underlying vector store does not support add_documents/add_texts")

    @staticmethod
    def _normalize_filter(kwargs: dict) -> dict | None:
        """Build a filter dict from explicit 'filter' key + remaining kwargs.

        Handles:
        - Merging extra kwargs into the filter dict
        - Stripping internal ``caller_role_level`` key
        - Wrapping multiple peer predicates in ``$and`` for Chroma 1.x compat
        - Returning ``None`` instead of empty dict (Chroma prefers None)
        """
        raw = kwargs.pop("filter", None)
        flt = raw if raw is not None else {}
        flt.update(kwargs)

        if isinstance(flt, dict) and "caller_role_level" in flt:
            flt.pop("caller_role_level", None)

        if isinstance(flt, dict):
            top_ops = {"$and", "$or", "$not"}
            has_op = any(op in flt for op in top_ops)
            if not has_op and len(flt) > 1:
                flt = {"$and": [{k: v} for k, v in flt.items()]}
            if len(flt) == 0:
                flt = None

        return flt

    def similarity_search(self, query: str, k: int = 4, **kwargs):  # type: ignore[no-self-use]
        """Proxy to underlying store ensuring non-standard kwargs become filters.

        LangChain-compatible vector stores typically expose the signature

            similarity_search(query, k=4, filter=None, **kwargs)

        Internal AgentFoundry callers historically passed arbitrary metadata
        keywords (``org_id``, ``user_id`` …) directly – expecting the provider
        to interpret them as filter constraints.  Newer upstream versions,
        however, raise ``TypeError`` for unexpected parameters.  To stay
        backward-compatible, we convert *unknown* kwargs into the ``filter``
        dict accepted by modern stores before delegating.
        """
        logger.info(f"similarity_search called for query={query} k={k}")
        org_id = kwargs.pop("org_id", None)
        logger.info(f"similarity_search called for org_id={org_id}")
        store = self.get_store(org_id=org_id) if org_id is not None else self.get_store()

        flt = self._normalize_filter(kwargs)

        logger.debug(f"VectorStore.similarity_search: provider={type(self).__name__} k={k} filter={flt}")

        res = store.similarity_search(query, k=k, filter=flt)
        logger.debug(f"VectorStore.similarity_search: provider={type(self).__name__} returned {len(res) if hasattr(res, '__len__') else -1} docs")

        return res

    def similarity_search_with_score(self, query: str, k: int = 4, **kwargs):  # type: ignore[no-self-use]
        """Proxy to underlying store's similarity_search_with_score.

        Returns a list of (Document, score) tuples.  Falls back to
        similarity_search (with score=0.0) if the underlying store does
        not implement the scored variant.
        """
        org_id = kwargs.pop("org_id", None)
        store = self.get_store(org_id=org_id) if org_id is not None else self.get_store()

        scored_fn = getattr(store, "similarity_search_with_score", None)
        if callable(scored_fn):
            flt = self._normalize_filter(kwargs)

            logger.debug(
                "VectorStore.similarity_search_with_score: provider=%s k=%d filter=%s",
                type(self).__name__, k, flt,
            )
            return scored_fn(query, k=k, filter=flt)

        # Fallback: return documents with a default score of 0.0
        logger.warning(
            "%s: underlying store has no similarity_search_with_score; falling back to similarity_search",
            type(self).__name__,
        )
        docs = self.similarity_search(query, k=k, org_id=org_id, **kwargs)
        return [(doc, 0.0) for doc in docs]

    def delete(self, *args, **kwargs):  # type: ignore[no-self-use]
        org_id = kwargs.pop("org_id", None)
        ids = args[0] if args and isinstance(args[0], list) else kwargs.get("ids", [])
        logger.debug("VectorStore.delete: org_id=%s ids_count=%d", org_id, len(ids) if ids else 0)
        store = self.get_store(org_id=org_id) if org_id is not None else self.get_store()
        return store.delete(*args, **kwargs)

    # ------------------------------------------------------------------
    # Helper utilities that concrete providers often expose.
    # ------------------------------------------------------------------

    @staticmethod
    def deterministic_id(text: str, user_id: str | None, org_id: str | None) -> str:  # noqa: D401
        """SHA-256 hash of (text, user_id, org_id) for stable document IDs."""
        digest = hashlib.sha256()
        digest.update((text or "").encode("utf-8"))
        digest.update((user_id or "").encode("utf-8"))
        digest.update((org_id or "").encode("utf-8"))
        return digest.hexdigest()

    def verify_connectivity(self, org_id: str = "global") -> None:
        """Verify backend reachability.  Raises InitializationError on failure."""
        from agentfoundry.utils.exceptions import InitializationError

        logger.info("%s: verifying connectivity (org_id=%s)", type(self).__name__, org_id)
        try:
            store = self.get_store(org_id=org_id)
            if store is None:
                raise InitializationError(
                    component=type(self).__name__,
                    message=f"get_store(org_id={org_id!r}) returned None",
                )
        except InitializationError:
            raise
        except Exception as exc:
            raise InitializationError(
                component=type(self).__name__,
                message=f"connectivity check failed: {exc}",
                cause=exc,
            ) from exc
        logger.info("%s: connectivity verified (org_id=%s)", type(self).__name__, org_id)

    def purge_expired(self, retention_days: int = 0) -> None:  # noqa: D401
        # Optional – providers may override.
        return None
