"""Providers sub-package (kept minimal – all heavy lifting in individual modules)."""

# Provider modules self-register with VectorStoreFactory when imported.
# The factory's auto-import block (at the bottom of factory.py) handles
# importing individual provider modules and catches errors per-provider so
# that a missing optional dependency (e.g. pymilvus) does not prevent other
# providers from loading.
#
# Do NOT eagerly import concrete provider classes here – doing so creates a
# hard coupling between all providers and causes the entire package import to
# fail if any single provider's dependencies are missing.

from agentfoundry.vectorstores.factory import VectorStoreFactory

register_provider = VectorStoreFactory.register_provider  # type: ignore
get_provider_cls = VectorStoreFactory.get_provider_cls  # type: ignore
available_providers = VectorStoreFactory.available_providers  # type: ignore
