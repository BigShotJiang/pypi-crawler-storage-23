"""Cooperative request cancellation for AgentFoundry.

A :class:`CancellationToken` is created per incoming request and registered in
the global :class:`RequestTracker`.  A separate HTTP request calls the cancel
endpoint which sets the event on the token.  The processing thread checks the
token at strategic checkpoints and raises :class:`RequestCancelled` to unwind.
"""

from __future__ import annotations

import logging
import threading
from typing import Optional

logger = logging.getLogger(__name__)


class RequestCancelled(Exception):
    """Raised when a request has been cancelled by the user."""

    def __init__(self, user_id: str = "", thread_id: str = ""):
        self.user_id = user_id
        self.thread_id = thread_id
        super().__init__(
            f"Request cancelled for user_id={user_id}, thread_id={thread_id}"
        )


class CancellationToken:
    """Thread-safe cancellation token backed by :class:`threading.Event`."""

    def __init__(self, user_id: str = "", thread_id: str = ""):
        self._event = threading.Event()
        self.user_id = user_id
        self.thread_id = thread_id

    def cancel(self) -> None:
        """Signal cancellation.  Thread-safe and idempotent."""
        logger.info(
            "Cancellation signalled for user_id=%s thread_id=%s",
            self.user_id,
            self.thread_id,
        )
        self._event.set()

    @property
    def is_cancelled(self) -> bool:
        """Check cancellation status without raising."""
        return self._event.is_set()

    def check(self) -> None:
        """Raise :class:`RequestCancelled` if cancellation has been signalled."""
        if self._event.is_set():
            raise RequestCancelled(self.user_id, self.thread_id)


class RequestTracker:
    """Global registry mapping ``(user_id, thread_id)`` to active tokens.

    Thread-safe singleton.  Instantiate freely — all instances share state.
    """

    _instance: Optional[RequestTracker] = None
    _init_lock = threading.Lock()

    def __new__(cls) -> RequestTracker:
        with cls._init_lock:
            if cls._instance is None:
                inst = super().__new__(cls)
                inst._tokens: dict[tuple[str, str], CancellationToken] = {}
                inst._lock = threading.Lock()
                cls._instance = inst
            return cls._instance

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def register(self, user_id: str, thread_id: str) -> CancellationToken:
        """Create and register a new :class:`CancellationToken`.

        If a token already exists for this key the old one is cancelled and
        replaced so that overlapping requests for the same user/thread do not
        conflict.
        """
        token = CancellationToken(user_id, thread_id)
        key = (str(user_id), str(thread_id))
        with self._lock:
            old = self._tokens.get(key)
            if old is not None:
                old.cancel()
                logger.info(
                    "Replaced existing token for %s (old request will be cancelled)",
                    key,
                )
            self._tokens[key] = token
        logger.info(
            "Registered cancellation token for user_id=%s thread_id=%s",
            user_id,
            thread_id,
        )
        return token

    def cancel(self, user_id: str, thread_id: str) -> bool:
        """Signal cancellation for the active request.

        Returns ``True`` if a token was found and cancelled, ``False`` if no
        active request exists (already completed or never started).
        """
        key = (str(user_id), str(thread_id))
        with self._lock:
            token = self._tokens.get(key)
        if token is None:
            logger.info("No active token found for %s; cancel is a no-op", key)
            return False
        token.cancel()
        return True

    def unregister(self, user_id: str, thread_id: str) -> None:
        """Remove the token.  Called in a ``finally`` block after processing."""
        key = (str(user_id), str(thread_id))
        with self._lock:
            self._tokens.pop(key, None)
        logger.debug("Unregistered token for %s", key)

    def is_active(self, user_id: str, thread_id: str) -> bool:
        """Return whether there is an active (non-cancelled) request."""
        key = (str(user_id), str(thread_id))
        with self._lock:
            token = self._tokens.get(key)
        return token is not None and not token.is_cancelled
