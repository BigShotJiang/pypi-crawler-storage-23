"""Health check protocol for AgentFoundry components."""

from __future__ import annotations

from abc import ABC, abstractmethod

from agentfoundry.health.models import ComponentHealth


class HealthCheckable(ABC):
    """Protocol for components that support health checking.

    Components implement :meth:`check_health` to return a
    :class:`ComponentHealth` snapshot.  The method should be lightweight
    and safe to call from any thread.
    """

    @abstractmethod
    def check_health(self, *, timeout: float = 5.0) -> ComponentHealth:
        """Perform a health check and return a ComponentHealth report.

        Args:
            timeout: Maximum seconds the check may take before being
                     considered timed out (provider-specific).

        Returns:
            ComponentHealth with status, latency, error details, and metadata.
        """
        ...

    @property
    def health_component_name(self) -> str:
        """Return the canonical name used to identify this component in the registry.

        Default implementation returns the class name.  Override for
        provider-specific naming (e.g. ``'vectorstore.milvus'``).
        """
        return type(self).__name__
