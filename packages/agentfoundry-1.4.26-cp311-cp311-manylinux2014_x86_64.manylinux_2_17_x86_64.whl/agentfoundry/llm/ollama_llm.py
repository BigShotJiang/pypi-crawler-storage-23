# agentfoundry/llm/ollama/ollama_llm.py
import logging
import sys
import time
from typing import Any, Mapping, Sequence, ClassVar, Callable

from langchain_core.tools import BaseTool
from langchain_ollama import ChatOllama
from .llm_interface import LLMInterface

logger = logging.getLogger(__name__)


class OllamaLLM(ChatOllama, LLMInterface):
    """ChatOllama that satisfies the LLMInterface and langgraph_supervisor's bind_tools requirement."""

    bind_tools: ClassVar[Callable]
    chat: ClassVar[Callable]
    invoke: ClassVar[Callable]

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        logger.info(
            "OllamaLLM initialized: model=%s base_url=%s",
            getattr(self, "model", None),
            getattr(self, "base_url", None),
        )

    def bind_tools(           # minimal helper
        self,
        tools: Sequence[BaseTool],
        *args,
        **kwargs,
    ) -> "OllamaLLM":
        new = self            # simply reuse the same instance
        new._tool_map: Mapping[str, BaseTool] = {t.name: t for t in tools}
        logger.debug("OllamaLLM.bind_tools: bound %d tools", len(tools))
        return new

    def invoke(self, input: Any, config: Any = None, **kwargs: Any):
        logger.debug(
            "OllamaLLM.invoke: model=%s input_type=%s",
            getattr(self, "model", None), type(input).__name__,
        )
        t0 = time.perf_counter()
        result = super().invoke(input, config=config, **kwargs)
        dt = int((time.perf_counter() - t0) * 1000)
        resp_chars = len(getattr(result, "content", "") or "")
        logger.debug("OllamaLLM.invoke: time_ms=%d resp_chars=%d", dt, resp_chars)
        return result

    def chat(self, messages: list, **kwargs) -> str:
        """Engage in a chat-like conversation with the LLM."""
        logger.debug("OllamaLLM.chat: messages=%d", len(messages))
        result = super().invoke(messages, **kwargs)
        return getattr(result, "content", str(result))


# Quick test when running this module directly
if __name__ == "__main__":
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)  # Set to DEBUG to capture all log levels
    # Create handler that outputs to stdout
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setLevel(logging.DEBUG)
    # Create a formatter and set it on the handler
    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    stdout_handler.setFormatter(formatter)
    # Add the handler to the logger
    logger.addHandler(stdout_handler)

    llm = OllamaLLM(model="gemma3:27b")
    messages = [{"role": "user", "content": "Write a short poem about the stars."}]
    output = llm.invoke(messages).content
    print("Output:\n", output)
