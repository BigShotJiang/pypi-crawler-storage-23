SELECT COUNT(*) AS cnt FROM users;
