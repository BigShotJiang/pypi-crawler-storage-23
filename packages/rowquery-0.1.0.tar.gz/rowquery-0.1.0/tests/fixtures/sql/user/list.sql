SELECT id, name, email
FROM users
ORDER BY name;
