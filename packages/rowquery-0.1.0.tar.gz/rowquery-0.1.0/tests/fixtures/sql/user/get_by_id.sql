SELECT id, name, email
FROM users
WHERE id = :user_id;
