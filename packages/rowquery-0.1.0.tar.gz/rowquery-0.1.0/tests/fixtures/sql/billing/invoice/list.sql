SELECT id, user_id, amount, status
FROM invoices
ORDER BY id;
