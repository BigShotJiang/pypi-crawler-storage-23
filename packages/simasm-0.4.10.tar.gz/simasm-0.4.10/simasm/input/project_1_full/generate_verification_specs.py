#!/usr/bin/env python3
"""
generate_verification_specs.py

Generate verification specification files for all topologies.
Creates .simasm verification files that test stutter equivalence
between Event Graph (EG) and Activity Cycle Diagram (ACD) models.

Topologies:
  - Feedback n-queue (9 specs)
  - Fork-join n-queue (9 specs)
  - Hybrid n x m (20 specs)
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).parent
NUM_SERVERS = 5


def generate_feedback_verification(n: int) -> str:
    """Generate verification spec for feedback n-queue."""
    lines = []
    lines.append(f"// =============================================================================")
    lines.append(f"// Verification: Feedback {n}-Queue Stutter Equivalence")
    lines.append(f"// =============================================================================")
    lines.append(f"// Verifies stutter equivalence between Event Graph and ACD models")
    lines.append(f"// of a {n}-station feedback queue with 50% feedback probability.")
    lines.append(f"//")
    lines.append(f"// Observable alignment:")
    lines.append(f"//   EG uses queue_count_i and server_count_i state variables (i=1..{n})")
    lines.append(f"//   ACD uses marking(Q_i) and marking(S_i) where S_i holds IDLE servers")
    lines.append(f"// =============================================================================")
    lines.append(f"")
    lines.append(f"verification feedback_{n}_stutter_equivalence:")
    lines.append(f"")
    lines.append(f"    models:")
    lines.append(f'        import EG from "../generated/eg/feedback_{n}_eg.simasm"')
    lines.append(f'        import ACD from "../generated/acd/feedback_{n}_acd.simasm"')
    lines.append(f"    endmodels")
    lines.append(f"")
    lines.append(f"    seeds: [42, 123, 456]")
    lines.append(f"")
    lines.append(f"    labels:")

    for i in range(1, n + 1):
        lines.append(f"        // Station {i} labels")
        lines.append(f'        label queue_{i}_empty for EG: "queue_count_{i} == 0"')
        lines.append(f'        label queue_{i}_empty for ACD: "marking(Q_{i}) == 0"')
        lines.append(f'        label queue_{i}_nonempty for EG: "queue_count_{i} > 0"')
        lines.append(f'        label queue_{i}_nonempty for ACD: "marking(Q_{i}) > 0"')
        lines.append(f'        label server_{i}_idle for EG: "server_count_{i} == 0"')
        lines.append(f'        label server_{i}_idle for ACD: "marking(S_{i}) == {NUM_SERVERS}"')
        lines.append(f'        label server_{i}_busy for EG: "server_count_{i} > 0"')
        lines.append(f'        label server_{i}_busy for ACD: "marking(S_{i}) < {NUM_SERVERS}"')
        if i < n:
            lines.append(f"")

    lines.append(f"")
    lines.append(f"    endlabels")
    lines.append(f"")
    lines.append(f"    observables:")

    for i in range(1, n + 1):
        lines.append(f"        // Station {i}")
        lines.append(f"        observable queue_{i}_empty:")
        lines.append(f"            EG -> queue_{i}_empty")
        lines.append(f"            ACD -> queue_{i}_empty")
        lines.append(f"        endobservable")
        lines.append(f"        observable queue_{i}_nonempty:")
        lines.append(f"            EG -> queue_{i}_nonempty")
        lines.append(f"            ACD -> queue_{i}_nonempty")
        lines.append(f"        endobservable")
        lines.append(f"        observable server_{i}_idle:")
        lines.append(f"            EG -> server_{i}_idle")
        lines.append(f"            ACD -> server_{i}_idle")
        lines.append(f"        endobservable")
        lines.append(f"        observable server_{i}_busy:")
        lines.append(f"            EG -> server_{i}_busy")
        lines.append(f"            ACD -> server_{i}_busy")
        lines.append(f"        endobservable")
        if i < n:
            lines.append(f"")

    lines.append(f"")
    lines.append(f"    endobservables")
    lines.append(f"")
    lines.append(f"    check:")
    lines.append(f"        type: stutter_equivalence")
    lines.append(f"        run_length: 10000.0")
    lines.append(f"        timeout: 600")
    lines.append(f"    endcheck")
    lines.append(f"")
    lines.append(f"    output:")
    lines.append(f'        format: "json"')
    lines.append(f'        file_path: "../../output/feedback_n_queue/feedback_{n}_results.json"')
    lines.append(f"        include_counterexample: true")
    lines.append(f"    endoutput")
    lines.append(f"")
    lines.append(f"endverification")
    lines.append(f"")

    return "\n".join(lines)


def generate_fork_join_verification(n: int) -> str:
    """Generate verification spec for fork-join n-queue."""
    lines = []
    lines.append(f"// =============================================================================")
    lines.append(f"// Verification: Fork-Join {n}-Queue Stutter Equivalence")
    lines.append(f"// =============================================================================")
    lines.append(f"// Verifies stutter equivalence between Event Graph and ACD models")
    lines.append(f"// of a fork-join queue with {n} parallel branch{'es' if n > 1 else ''}.")
    lines.append(f"//")
    lines.append(f"// Observable alignment:")
    lines.append(f"//   EG: queue_count_i, server_count_i, part_i_num (state variables)")
    lines.append(f"//   ACD: marking(Q_i), marking(S_i), marking(P_i) (queue markings)")
    lines.append(f"// =============================================================================")
    lines.append(f"")
    lines.append(f"verification fork_join_{n}_stutter_equivalence:")
    lines.append(f"")
    lines.append(f"    models:")
    lines.append(f'        import EG from "../generated/eg/fork_join_{n}_eg.simasm"')
    lines.append(f'        import ACD from "../generated/acd/fork_join_{n}_acd.simasm"')
    lines.append(f"    endmodels")
    lines.append(f"")
    lines.append(f"    seeds: [42, 123, 456]")
    lines.append(f"")
    lines.append(f"    labels:")

    for i in range(1, n + 1):
        lines.append(f"        // Branch {i} labels")
        lines.append(f'        label queue_{i}_empty for EG: "queue_count_{i} == 0"')
        lines.append(f'        label queue_{i}_empty for ACD: "marking(Q_{i}) == 0"')
        lines.append(f'        label queue_{i}_nonempty for EG: "queue_count_{i} > 0"')
        lines.append(f'        label queue_{i}_nonempty for ACD: "marking(Q_{i}) > 0"')
        lines.append(f'        label server_{i}_idle for EG: "server_count_{i} == 0"')
        lines.append(f'        label server_{i}_idle for ACD: "marking(S_{i}) == {NUM_SERVERS}"')
        lines.append(f'        label server_{i}_busy for EG: "server_count_{i} > 0"')
        lines.append(f'        label server_{i}_busy for ACD: "marking(S_{i}) < {NUM_SERVERS}"')
        lines.append(f'        label part_{i}_empty for EG: "part_{i}_num == 0"')
        lines.append(f'        label part_{i}_empty for ACD: "marking(P_{i}) == 0"')
        lines.append(f'        label part_{i}_nonempty for EG: "part_{i}_num > 0"')
        lines.append(f'        label part_{i}_nonempty for ACD: "marking(P_{i}) > 0"')
        if i < n:
            lines.append(f"")

    lines.append(f"")
    lines.append(f"    endlabels")
    lines.append(f"")
    lines.append(f"    observables:")

    for i in range(1, n + 1):
        lines.append(f"        // Branch {i}")
        lines.append(f"        observable queue_{i}_empty:")
        lines.append(f"            EG -> queue_{i}_empty")
        lines.append(f"            ACD -> queue_{i}_empty")
        lines.append(f"        endobservable")
        lines.append(f"        observable queue_{i}_nonempty:")
        lines.append(f"            EG -> queue_{i}_nonempty")
        lines.append(f"            ACD -> queue_{i}_nonempty")
        lines.append(f"        endobservable")
        lines.append(f"        observable server_{i}_idle:")
        lines.append(f"            EG -> server_{i}_idle")
        lines.append(f"            ACD -> server_{i}_idle")
        lines.append(f"        endobservable")
        lines.append(f"        observable server_{i}_busy:")
        lines.append(f"            EG -> server_{i}_busy")
        lines.append(f"            ACD -> server_{i}_busy")
        lines.append(f"        endobservable")
        lines.append(f"        observable part_{i}_empty:")
        lines.append(f"            EG -> part_{i}_empty")
        lines.append(f"            ACD -> part_{i}_empty")
        lines.append(f"        endobservable")
        lines.append(f"        observable part_{i}_nonempty:")
        lines.append(f"            EG -> part_{i}_nonempty")
        lines.append(f"            ACD -> part_{i}_nonempty")
        lines.append(f"        endobservable")
        if i < n:
            lines.append(f"")

    lines.append(f"")
    lines.append(f"    endobservables")
    lines.append(f"")
    lines.append(f"    check:")
    lines.append(f"        type: stutter_equivalence")
    lines.append(f"        run_length: 10000.0")
    lines.append(f"        timeout: 600")
    lines.append(f"    endcheck")
    lines.append(f"")
    lines.append(f"    output:")
    lines.append(f'        format: "json"')
    lines.append(f'        file_path: "../../output/fork_join_n_queue/fork_join_{n}_results.json"')
    lines.append(f"        include_counterexample: true")
    lines.append(f"    endoutput")
    lines.append(f"")
    lines.append(f"endverification")
    lines.append(f"")

    return "\n".join(lines)


def generate_hybrid_verification(n: int, m: int) -> str:
    """Generate verification spec for hybrid n x m queue."""
    lines = []
    lines.append(f"// =============================================================================")
    lines.append(f"// Verification: Hybrid {n}x{m}-Queue Stutter Equivalence")
    lines.append(f"// =============================================================================")
    lines.append(f"// Verifies stutter equivalence between Event Graph and ACD models")
    lines.append(f"// of a hybrid queue: {n} tandem stations, {m} fork-join branches, feedback p=0.5.")
    lines.append(f"//")
    lines.append(f"// Observable alignment:")
    lines.append(f"//   EG: queue_count_i, server_count_i, branch_queue_j, branch_server_j")
    lines.append(f"//   ACD: marking(Q_i), marking(S_i), marking(BQ_j), marking(BS_j)")
    lines.append(f"// =============================================================================")
    lines.append(f"")
    lines.append(f"verification hybrid_{n}_{m}_stutter_equivalence:")
    lines.append(f"")
    lines.append(f"    models:")
    lines.append(f'        import EG from "../generated/eg/hybrid_{n}_{m}_eg.simasm"')
    lines.append(f'        import ACD from "../generated/acd/hybrid_{n}_{m}_acd.simasm"')
    lines.append(f"    endmodels")
    lines.append(f"")
    lines.append(f"    seeds: [42, 123, 456]")
    lines.append(f"")
    lines.append(f"    labels:")

    # Tandem station labels
    for i in range(1, n + 1):
        lines.append(f"        // Tandem station {i} labels")
        lines.append(f'        label queue_{i}_empty for EG: "queue_count_{i} == 0"')
        lines.append(f'        label queue_{i}_empty for ACD: "marking(Q_{i}) == 0"')
        lines.append(f'        label queue_{i}_nonempty for EG: "queue_count_{i} > 0"')
        lines.append(f'        label queue_{i}_nonempty for ACD: "marking(Q_{i}) > 0"')
        lines.append(f'        label server_{i}_idle for EG: "server_count_{i} == 0"')
        lines.append(f'        label server_{i}_idle for ACD: "marking(S_{i}) == {NUM_SERVERS}"')
        lines.append(f'        label server_{i}_busy for EG: "server_count_{i} > 0"')
        lines.append(f'        label server_{i}_busy for ACD: "marking(S_{i}) < {NUM_SERVERS}"')
        lines.append(f"")

    # Branch labels
    for j in range(1, m + 1):
        lines.append(f"        // Branch {j} labels")
        lines.append(f'        label branch_queue_{j}_empty for EG: "branch_queue_{j} == 0"')
        lines.append(f'        label branch_queue_{j}_empty for ACD: "marking(BQ_{j}) == 0"')
        lines.append(f'        label branch_queue_{j}_nonempty for EG: "branch_queue_{j} > 0"')
        lines.append(f'        label branch_queue_{j}_nonempty for ACD: "marking(BQ_{j}) > 0"')
        lines.append(f'        label branch_server_{j}_idle for EG: "branch_server_{j} == 0"')
        lines.append(f'        label branch_server_{j}_idle for ACD: "marking(BS_{j}) == {NUM_SERVERS}"')
        lines.append(f'        label branch_server_{j}_busy for EG: "branch_server_{j} > 0"')
        lines.append(f'        label branch_server_{j}_busy for ACD: "marking(BS_{j}) < {NUM_SERVERS}"')
        if j < m:
            lines.append(f"")

    lines.append(f"")
    lines.append(f"    endlabels")
    lines.append(f"")
    lines.append(f"    observables:")

    # Tandem observables
    for i in range(1, n + 1):
        lines.append(f"        // Tandem station {i}")
        lines.append(f"        observable queue_{i}_empty:")
        lines.append(f"            EG -> queue_{i}_empty")
        lines.append(f"            ACD -> queue_{i}_empty")
        lines.append(f"        endobservable")
        lines.append(f"        observable queue_{i}_nonempty:")
        lines.append(f"            EG -> queue_{i}_nonempty")
        lines.append(f"            ACD -> queue_{i}_nonempty")
        lines.append(f"        endobservable")
        lines.append(f"        observable server_{i}_idle:")
        lines.append(f"            EG -> server_{i}_idle")
        lines.append(f"            ACD -> server_{i}_idle")
        lines.append(f"        endobservable")
        lines.append(f"        observable server_{i}_busy:")
        lines.append(f"            EG -> server_{i}_busy")
        lines.append(f"            ACD -> server_{i}_busy")
        lines.append(f"        endobservable")
        lines.append(f"")

    # Branch observables
    for j in range(1, m + 1):
        lines.append(f"        // Branch {j}")
        lines.append(f"        observable branch_queue_{j}_empty:")
        lines.append(f"            EG -> branch_queue_{j}_empty")
        lines.append(f"            ACD -> branch_queue_{j}_empty")
        lines.append(f"        endobservable")
        lines.append(f"        observable branch_queue_{j}_nonempty:")
        lines.append(f"            EG -> branch_queue_{j}_nonempty")
        lines.append(f"            ACD -> branch_queue_{j}_nonempty")
        lines.append(f"        endobservable")
        lines.append(f"        observable branch_server_{j}_idle:")
        lines.append(f"            EG -> branch_server_{j}_idle")
        lines.append(f"            ACD -> branch_server_{j}_idle")
        lines.append(f"        endobservable")
        lines.append(f"        observable branch_server_{j}_busy:")
        lines.append(f"            EG -> branch_server_{j}_busy")
        lines.append(f"            ACD -> branch_server_{j}_busy")
        lines.append(f"        endobservable")
        if j < m:
            lines.append(f"")

    lines.append(f"")
    lines.append(f"    endobservables")
    lines.append(f"")
    lines.append(f"    check:")
    lines.append(f"        type: stutter_equivalence")
    lines.append(f"        run_length: 10000.0")
    lines.append(f"        timeout: 600")
    lines.append(f"    endcheck")
    lines.append(f"")
    lines.append(f"    output:")
    lines.append(f'        format: "json"')
    lines.append(f'        file_path: "../../../output/hybrid/hybrid_{n}_{m}_results.json"')
    lines.append(f"        include_counterexample: true")
    lines.append(f"    endoutput")
    lines.append(f"")
    lines.append(f"endverification")
    lines.append(f"")

    return "\n".join(lines)


def main():
    print("=" * 70)
    print("  VERIFICATION SPECIFICATION GENERATION")
    print("=" * 70)

    total = 0

    # --- Feedback ---
    feedback_n_values = [1, 2, 3, 4, 5, 7, 10, 15, 20]
    feedback_dir = BASE_DIR / "feedback_n_queue" / "verification"
    feedback_dir.mkdir(parents=True, exist_ok=True)

    print(f"\nFeedback verification specs:")
    for n in feedback_n_values:
        spec = generate_feedback_verification(n)
        filepath = feedback_dir / f"feedback_{n}_verification.simasm"
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(spec)
        print(f"  feedback_{n}_verification.simasm")
        total += 1

    # --- Fork-Join ---
    fork_join_n_values = [1, 2, 3, 4, 5, 7, 10, 15, 20]
    fork_join_dir = BASE_DIR / "fork_join_n_queue" / "verification"
    fork_join_dir.mkdir(parents=True, exist_ok=True)

    print(f"\nFork-Join verification specs:")
    for n in fork_join_n_values:
        spec = generate_fork_join_verification(n)
        filepath = fork_join_dir / f"fork_join_{n}_verification.simasm"
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(spec)
        print(f"  fork_join_{n}_verification.simasm")
        total += 1

    # --- Hybrid ---
    hybrid_configs = [
        (1, 2), (1, 3), (2, 2), (2, 3), (2, 4),
        (3, 2), (3, 3), (3, 4), (4, 2), (4, 3),
        (4, 4), (5, 2), (5, 3), (5, 4), (5, 5),
        (7, 2), (7, 3), (7, 4), (10, 2), (10, 3),
    ]
    hybrid_dir = BASE_DIR / "held_out" / "hybrid" / "verification"
    hybrid_dir.mkdir(parents=True, exist_ok=True)

    print(f"\nHybrid verification specs:")
    for n, m in hybrid_configs:
        spec = generate_hybrid_verification(n, m)
        filepath = hybrid_dir / f"hybrid_{n}_{m}_verification.simasm"
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(spec)
        print(f"  hybrid_{n}_{m}_verification.simasm")
        total += 1

    print(f"\n{'=' * 70}")
    print(f"  Generated {total} verification specs")
    print(f"{'=' * 70}")


if __name__ == "__main__":
    main()
