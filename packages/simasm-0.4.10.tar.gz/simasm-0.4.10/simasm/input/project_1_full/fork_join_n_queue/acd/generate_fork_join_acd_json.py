#!/usr/bin/env python3
"""
generate_fork_join_acd_json.py

Generate ACD JSON files for fork-join n-queue models.
Fork-Join = arrivals forked to n parallel branches, joined after all complete.
Separate Fork activity, zero-duration Join.

Configurations: n = {1, 2, 3, 4, 5, 7, 10, 15, 20}
"""

import json
import os


def generate_fork_join_acd_json(n):
    """Generate ACD JSON for fork_join_n model."""
    model_name = f"fork_join_{n}_acd"

    # --- Parameters ---
    parameters = {
        "num_servers": {
            "type": "Nat",
            "value": 5,
            "description": "Number of servers per branch"
        },
        "iat_mean": {
            "type": "Real",
            "value": 1.25,
            "description": "Inter-arrival time mean"
        },
        "ist_mean": {
            "type": "Real",
            "value": 1.0,
            "description": "Service time mean per branch"
        },
        "sim_end_time": {
            "type": "Real",
            "value": 10000.0,
            "description": "Simulation end time"
        }
    }

    # --- Token Types ---
    job_attributes = {
        "arrival_time": {
            "type": "Real",
            "description": "Time job arrived"
        }
    }
    for i in range(1, n + 1):
        job_attributes[f"service_start_time_{i}"] = {
            "type": "Real",
            "description": f"Time job started service at branch {i}"
        }

    token_types = {
        "Job": {
            "name": "Job",
            "parent": "Token",
            "attributes": job_attributes,
            "description": "Customer job token"
        },
        "Resource": {
            "name": "Resource",
            "parent": "Token",
            "attributes": {},
            "description": "Reusable resource token"
        }
    }

    # --- Queues ---
    queues = {
        "C": {
            "initial_tokens": 1,
            "token_type": "Resource",
            "is_resource": True,
            "description": "Creator resource queue"
        },
        "Q_fork": {
            "initial_tokens": 0,
            "token_type": "Job",
            "is_resource": False,
            "description": "Pre-fork queue"
        }
    }
    for i in range(1, n + 1):
        queues[f"Q_{i}"] = {
            "initial_tokens": 0,
            "token_type": "Job",
            "is_resource": False,
            "description": f"Job waiting queue at branch {i}"
        }
        queues[f"S_{i}"] = {
            "initial_tokens": 5,
            "token_type": "Resource",
            "is_resource": True,
            "description": f"Server resource queue at branch {i}"
        }
        queues[f"P_{i}"] = {
            "initial_tokens": 0,
            "token_type": "Job",
            "is_resource": False,
            "description": f"Part completion queue at branch {i}"
        }
    queues["Jobs"] = {
        "initial_tokens": 0,
        "token_type": "Job",
        "is_resource": False,
        "description": "Completed jobs (sink)"
    }

    # --- Activities ---
    activities = []

    # Create activity
    activities.append({
        "name": "Create",
        "priority": 3,
        "at_begin": {
            "condition": "true",
            "consume": [
                {"queue": "C", "count": 1, "bind_as": "creator_token"}
            ],
            "actions": []
        },
        "at_end": [
            {
                "condition": "true",
                "produce": [
                    {"queue": "C", "count": 1, "token_source": "creator_token"},
                    {"queue": "Q_fork", "count": 1, "token_source": "new"}
                ],
                "actions": ["job_id_counter := job_id_counter + 1"]
            }
        ],
        "description": "Job creation activity",
        "duration": "duration_create"
    })

    # Fork activity (zero duration, consumes from Q_fork, produces to all Q_i)
    fork_produce = [{"queue": f"Q_{i}", "count": 1, "token_source": "new"} for i in range(1, n + 1)]
    activities.append({
        "name": "Fork",
        "priority": 2,
        "at_begin": {
            "condition": "true",
            "consume": [
                {"queue": "Q_fork", "count": 1, "bind_as": "fork_token"}
            ],
            "actions": []
        },
        "at_end": [
            {
                "condition": "true",
                "produce": fork_produce,
                "actions": []
            }
        ],
        "description": "Fork: distribute job to all branches",
        "duration": "duration_fork"
    })

    # Serve activities for each branch
    for i in range(1, n + 1):
        activities.append({
            "name": f"Serve_{i}",
            "priority": 1,
            "at_begin": {
                "condition": "true",
                "consume": [
                    {"queue": f"S_{i}", "count": 1, "bind_as": "server_token"},
                    {"queue": f"Q_{i}", "count": 1, "bind_as": "job_token"}
                ],
                "actions": [f"service_start_time_{i}(job_token) := sim_clocktime"]
            },
            "at_end": [
                {
                    "condition": "true",
                    "produce": [
                        {"queue": f"S_{i}", "count": 1, "token_source": "server_token"},
                        {"queue": f"P_{i}", "count": 1, "token_source": "job_token"}
                    ],
                    "actions": []
                }
            ],
            "description": f"Service activity at branch {i}",
            "duration": f"duration_serve_{i}"
        })

    # Join activity (zero duration, consumes from all P_i)
    join_consume = [{"queue": f"P_{i}", "count": 1, "bind_as": f"part_token_{i}"} for i in range(1, n + 1)]
    activities.append({
        "name": "Join",
        "priority": 0,
        "at_begin": {
            "condition": "true",
            "consume": join_consume,
            "actions": []
        },
        "at_end": [
            {
                "condition": "true",
                "produce": [
                    {"queue": "Jobs", "count": 1, "token_source": "new"}
                ],
                "actions": ["departure_count := departure_count + 1"]
            }
        ],
        "description": "Join: synchronize all branches",
        "duration": "duration_join"
    })

    # --- Random Streams ---
    random_streams = {
        "duration_create": {
            "distribution": "exponential",
            "params": {"mean": "iat_mean"},
            "stream_name": "arrivals"
        },
        "duration_fork": {
            "distribution": "constant",
            "params": {"value": 0},
            "stream_name": "fork"
        },
        "duration_join": {
            "distribution": "constant",
            "params": {"value": 0},
            "stream_name": "join"
        }
    }
    for i in range(1, n + 1):
        random_streams[f"duration_serve_{i}"] = {
            "distribution": "exponential",
            "params": {"mean": "ist_mean"},
            "stream_name": f"service_{i}"
        }

    # --- State Variables ---
    state_variables = {
        "job_id_counter": {"type": "Nat", "initial": 0},
        "departure_count": {"type": "Nat", "initial": 0}
    }

    # --- Observables ---
    observables = {}
    for i in range(1, n + 1):
        observables[f"queue_count_{i}"] = {
            "name": f"queue_count_{i}",
            "expression": f"marking(Q_{i})",
            "description": f"Number in queue at branch {i}"
        }
        observables[f"server_count_{i}"] = {
            "name": f"server_count_{i}",
            "expression": f"num_servers - marking(S_{i})",
            "description": f"Number of busy servers at branch {i}"
        }

    # Part completion observables
    for i in range(1, n + 1):
        observables[f"part_{i}_num"] = {
            "name": f"part_{i}_num",
            "expression": f"marking(P_{i})",
            "description": f"Completed but not yet joined at branch {i}"
        }

    # In-system expression
    parts = []
    for i in range(1, n + 1):
        parts.append(f"marking(Q_{i}) + (num_servers - marking(S_{i})) + marking(P_{i})")
    in_system_expr = " + ".join(parts)
    observables["in_system"] = {
        "name": "in_system",
        "expression": in_system_expr,
        "description": "Total in system"
    }

    # --- Statistics ---
    queue_sum_parts = [f"marking(Q_{i})" for i in range(1, n + 1)]
    statistics = [
        {
            "name": "L_q_total",
            "type": "time_average",
            "expression": " + ".join(queue_sum_parts),
            "description": "Average total queue length"
        },
        {
            "name": "L",
            "type": "time_average",
            "expression": in_system_expr,
            "description": "Average number in system"
        },
        {
            "name": "throughput",
            "type": "count",
            "expression": "departure_count",
            "description": "Total departures"
        }
    ]

    # --- Assemble ---
    spec = {
        "model_name": model_name,
        "description": f"Fork-Join {n}-Queue using Activity Cycle Diagram - {n} parallel branch{'es' if n > 1 else ''}",
        "parameters": parameters,
        "token_types": token_types,
        "queues": queues,
        "activities": activities,
        "random_streams": random_streams,
        "state_variables": state_variables,
        "stopping_condition": "sim_clocktime >= sim_end_time",
        "observables": observables,
        "statistics": statistics
    }

    return spec


def main():
    n_values = [1, 2, 3, 4, 5, 7, 10, 15, 20]
    output_dir = os.path.dirname(os.path.abspath(__file__))

    print("Generating fork-join ACD JSON files...")
    for n in n_values:
        spec = generate_fork_join_acd_json(n)
        filename = f"fork_join_{n}_acd.json"
        filepath = os.path.join(output_dir, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(spec, f, indent=2)

        num_activities = len(spec["activities"])
        num_queues = len(spec["queues"])
        print(f"  {filename}: {num_activities} activities, {num_queues} queues")

    print(f"\nGenerated {len(n_values)} files in {output_dir}")


if __name__ == "__main__":
    main()
