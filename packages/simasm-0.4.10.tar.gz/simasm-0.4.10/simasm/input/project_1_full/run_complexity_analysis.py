#!/usr/bin/env python3
"""
run_complexity_analysis.py

Compute complexity metrics (HET/SMC, CC, LOC, KC) for all EG and ACD models.
Outputs JSON, CSV, and a console summary table.

Usage:
    python -m simasm.input.project_1_full.run_complexity_analysis
"""

import json
import csv
import math
import zlib
import sys
import os
from datetime import datetime
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from simasm.complexity.api import analyze_complexity


# ---------------------------------------------------------------------------
# Metric helpers (LOC, KC) - independent of simasm complexity API
# ---------------------------------------------------------------------------

def compute_loc(filepath, comment_prefix="//"):
    """Non-blank, non-comment lines."""
    count = 0
    with open(filepath, encoding="utf-8") as f:
        for line in f:
            stripped = line.strip()
            if stripped and not stripped.startswith(comment_prefix):
                count += 1
    return count


def compute_kc(filepath):
    """Approximate Kolmogorov complexity: log2(zlib compressed size)."""
    with open(filepath, "rb") as f:
        data = f.read()
    compressed = zlib.compress(data, 9)
    return math.log2(len(compressed))


def compute_cyclomatic_number(json_path):
    """Cyclomatic number M = E - V + 2P from event graph JSON."""
    with open(json_path, encoding="utf-8") as f:
        spec = json.load(f)
    v = len(spec.get("vertices", []))
    e = len(spec.get("scheduling_edges", [])) + len(spec.get("cancelling_edges", []))
    p = 1
    return e - v + 2 * p


# ---------------------------------------------------------------------------
# Model discovery
# ---------------------------------------------------------------------------

BASE = Path(__file__).parent

TOPOLOGIES = {
    "tandem": {
        "eg_simasm": BASE / "tandem_n_queue" / "generated" / "eg",
        "acd_simasm": BASE / "tandem_n_queue" / "generated" / "acd",
        "eg_json": BASE / "tandem_n_queue" / "eg",
        "sizes": [1, 2, 3, 4, 5, 7, 10, 15, 20],
        "name_fn": lambda n: f"tandem_{n}",
        "is_held_out": False,
    },
    "feedback": {
        "eg_simasm": BASE / "feedback_n_queue" / "generated" / "eg",
        "acd_simasm": BASE / "feedback_n_queue" / "generated" / "acd",
        "eg_json": BASE / "feedback_n_queue" / "eg",
        "sizes": [1, 2, 3, 4, 5, 7, 10, 15, 20],
        "name_fn": lambda n: f"feedback_{n}",
        "is_held_out": False,
    },
    "fork_join": {
        "eg_simasm": BASE / "fork_join_n_queue" / "generated" / "eg",
        "acd_simasm": BASE / "fork_join_n_queue" / "generated" / "acd",
        "eg_json": BASE / "fork_join_n_queue" / "eg",
        "sizes": [1, 2, 3, 4, 5, 7, 10, 15, 20],
        "name_fn": lambda n: f"fork_join_{n}",
        "is_held_out": False,
    },
    "hybrid": {
        "eg_simasm": BASE / "held_out" / "hybrid" / "generated" / "eg",
        "acd_simasm": BASE / "held_out" / "hybrid" / "generated" / "acd",
        "eg_json": BASE / "held_out" / "hybrid" / "eg",
        "sizes": [
            (1, 2), (1, 3), (2, 2), (2, 3), (2, 4),
            (3, 2), (3, 3), (3, 4), (4, 2), (4, 3),
            (4, 4), (5, 2), (5, 3), (5, 4), (5, 5),
            (7, 2), (7, 3), (7, 4), (10, 2), (10, 3),
        ],
        "name_fn": lambda t: f"hybrid_{t[0]}_{t[1]}",
        "is_held_out": True,
    },
}


def discover_models():
    """Discover all EG and ACD model files and their JSON specs."""
    models = []

    for topo_name, topo in TOPOLOGIES.items():
        for size in topo["sizes"]:
            name = topo["name_fn"](size)

            # EG model
            eg_simasm = topo["eg_simasm"] / f"{name}_eg.simasm"
            eg_json = topo["eg_json"] / f"{name}_eg.json"
            if eg_simasm.exists():
                models.append({
                    "model_name": f"{name}_eg",
                    "topology": topo_name,
                    "formalism": "EG",
                    "size": size if not isinstance(size, tuple) else sum(size),
                    "size_param": str(size),
                    "is_held_out": topo["is_held_out"],
                    "simasm_path": str(eg_simasm),
                    "json_path": str(eg_json) if eg_json.exists() else None,
                })

            # ACD model
            acd_simasm = topo["acd_simasm"] / f"{name}_acd.simasm"
            if acd_simasm.exists():
                models.append({
                    "model_name": f"{name}_acd",
                    "topology": topo_name,
                    "formalism": "ACD",
                    "size": size if not isinstance(size, tuple) else sum(size),
                    "size_param": str(size),
                    "is_held_out": topo["is_held_out"],
                    "simasm_path": str(acd_simasm),
                    "json_path": None,  # ACD has no event graph JSON
                })

    return models


# ---------------------------------------------------------------------------
# Metric computation
# ---------------------------------------------------------------------------

def compute_metrics(model_info):
    """Compute all complexity metrics for a single model."""
    simasm_path = model_info["simasm_path"]
    json_path = model_info["json_path"]

    # HET analysis via simasm complexity API
    try:
        result = analyze_complexity(
            simasm_path,
            json_spec_path=json_path,
            model_name=model_info["model_name"]
        )
        het_static = result.het_static
        het_event = result.het_event
        het_control = result.het_control
        smc = result.smc if json_path else het_static  # Use het_static as SMC for ACD
        het_path_avg = result.het_path_avg
        num_paths = result.num_paths
        total_rules = result.total_rules
        total_updates = result.total_updates
        total_conditionals = result.total_conditionals
        total_let_bindings = result.total_let_bindings
        total_function_calls = result.total_function_calls
        total_new_entities = result.total_new_entities
        total_list_operations = result.total_list_operations
        vertex_count = result.vertex_count
        edge_count = result.edge_count
        edge_density = result.edge_density
        has_cycles = result.has_cycles

        rules_breakdown = [
            {
                "name": r.name,
                "het": r.het,
                "updates": r.updates,
                "conditionals": r.conditionals,
                "let_bindings": r.let_bindings,
                "function_calls": r.function_calls,
                "new_entities": r.new_entities,
                "list_operations": r.list_operations,
            }
            for r in result.rules
        ]
    except Exception as ex:
        print(f"    WARNING: HET analysis failed for {model_info['model_name']}: {ex}")
        het_static = 0
        het_event = 0
        het_control = 0
        smc = 0
        het_path_avg = 0.0
        num_paths = 0
        total_rules = 0
        total_updates = 0
        total_conditionals = 0
        total_let_bindings = 0
        total_function_calls = 0
        total_new_entities = 0
        total_list_operations = 0
        vertex_count = 0
        edge_count = 0
        edge_density = 0.0
        has_cycles = False
        rules_breakdown = []

    # CC from EG JSON (only for EG models)
    cc = None
    if json_path and os.path.exists(json_path):
        try:
            cc = compute_cyclomatic_number(json_path)
        except Exception as ex:
            print(f"    WARNING: CC computation failed: {ex}")

    # LOC
    loc = compute_loc(simasm_path)

    # KC
    kc = compute_kc(simasm_path)

    return {
        **model_info,
        "smc": smc,
        "het_static": het_static,
        "het_event": het_event,
        "het_control": het_control,
        "het_path_avg": het_path_avg,
        "num_paths": num_paths,
        "cyclomatic_number": cc,
        "loc": loc,
        "kc": kc,
        "vertex_count": vertex_count,
        "edge_count": edge_count,
        "edge_density": edge_density,
        "has_cycles": has_cycles,
        "total_rules": total_rules,
        "total_updates": total_updates,
        "total_conditionals": total_conditionals,
        "total_let_bindings": total_let_bindings,
        "total_function_calls": total_function_calls,
        "total_new_entities": total_new_entities,
        "total_list_operations": total_list_operations,
        "rules": rules_breakdown,
    }


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------

def write_json(metrics, output_path):
    """Write full metrics to JSON."""
    output = {
        "name": "EG_vs_ACD_Complexity",
        "timestamp": datetime.now().isoformat(),
        "total_models": len(metrics),
        "models": metrics,
    }
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)
    print(f"\n  JSON output: {output_path}")


def write_csv(metrics, output_path):
    """Write summary metrics to CSV."""
    fields = [
        "model_name", "topology", "formalism", "size_param", "is_held_out",
        "smc", "het_static", "cyclomatic_number", "loc", "kc",
        "total_rules", "total_updates", "total_conditionals",
        "vertex_count", "edge_count",
    ]
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for m in metrics:
            writer.writerow(m)
    print(f"  CSV output:  {output_path}")


def print_comparison_table(metrics):
    """Print EG vs ACD comparison table."""
    # Group by topology and size
    pairs = {}
    for m in metrics:
        key = (m["topology"], m["size_param"])
        if key not in pairs:
            pairs[key] = {}
        pairs[key][m["formalism"]] = m

    print("\n" + "=" * 120)
    print("  EG vs ACD COMPLEXITY COMPARISON")
    print("=" * 120)

    header = f"  {'Model':<20} {'SMC_EG':>8} {'SMC_ACD':>8} {'Ratio':>7} {'CC':>5} {'LOC_EG':>7} {'LOC_ACD':>8} {'KC_EG':>7} {'KC_ACD':>8}"
    print(header)
    print("  " + "-" * 116)

    for topo in ["tandem", "feedback", "fork_join", "hybrid"]:
        topo_pairs = {k: v for k, v in pairs.items() if k[0] == topo}
        if not topo_pairs:
            continue

        print(f"\n  [{topo.upper()}]")
        for key in sorted(topo_pairs.keys(), key=lambda k: eval(k[1]) if '(' in k[1] else int(k[1])):
            pair = topo_pairs[key]
            eg = pair.get("EG", {})
            acd = pair.get("ACD", {})

            name = f"{topo}_{key[1]}"
            smc_eg = eg.get("smc", "-")
            smc_acd = acd.get("smc", "-")
            cc = eg.get("cyclomatic_number", "-")
            loc_eg = eg.get("loc", "-")
            loc_acd = acd.get("loc", "-")
            kc_eg = eg.get("kc", "-")
            kc_acd = acd.get("kc", "-")

            # Compute ratio
            if isinstance(smc_eg, (int, float)) and isinstance(smc_acd, (int, float)) and smc_acd > 0:
                ratio = f"{smc_eg / smc_acd:.2f}"
            else:
                ratio = "-"

            kc_eg_s = f"{kc_eg:.2f}" if isinstance(kc_eg, float) else str(kc_eg)
            kc_acd_s = f"{kc_acd:.2f}" if isinstance(kc_acd, float) else str(kc_acd)

            print(f"  {name:<20} {str(smc_eg):>8} {str(smc_acd):>8} {ratio:>7} {str(cc):>5} {str(loc_eg):>7} {str(loc_acd):>8} {kc_eg_s:>7} {kc_acd_s:>8}")

    # Summary statistics
    eg_models = [m for m in metrics if m["formalism"] == "EG"]
    acd_models = [m for m in metrics if m["formalism"] == "ACD"]

    print(f"\n  {'SUMMARY':}")
    print(f"  " + "-" * 60)
    print(f"  Total EG models:  {len(eg_models)}")
    print(f"  Total ACD models: {len(acd_models)}")

    if eg_models:
        smc_vals = [m["smc"] for m in eg_models if m["smc"]]
        if smc_vals:
            print(f"  EG  SMC range: {min(smc_vals)} - {max(smc_vals)}")
    if acd_models:
        smc_vals = [m["smc"] for m in acd_models if m["smc"]]
        if smc_vals:
            print(f"  ACD SMC range: {min(smc_vals)} - {max(smc_vals)}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    print("=" * 70)
    print("  COMPLEXITY ANALYSIS: EG vs ACD")
    print("=" * 70)

    # Discover models
    models = discover_models()
    print(f"\n  Discovered {len(models)} models")

    eg_count = sum(1 for m in models if m["formalism"] == "EG")
    acd_count = sum(1 for m in models if m["formalism"] == "ACD")
    print(f"  EG: {eg_count}, ACD: {acd_count}")

    # Compute metrics
    print(f"\n  Computing metrics...")
    all_metrics = []
    for i, model in enumerate(models):
        print(f"  [{i+1}/{len(models)}] {model['model_name']}...", end="", flush=True)
        result = compute_metrics(model)
        all_metrics.append(result)
        print(f" SMC={result['smc']}, LOC={result['loc']}, KC={result['kc']:.2f}"
              + (f", CC={result['cyclomatic_number']}" if result['cyclomatic_number'] is not None else ""))

    # Output
    output_dir = BASE.parent.parent / "output" / "complexity"
    output_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    json_path = output_dir / f"eg_vs_acd_metrics_{timestamp}.json"
    csv_path = output_dir / f"eg_vs_acd_metrics_{timestamp}.csv"
    latest_json = output_dir / "eg_vs_acd_metrics_latest.json"
    latest_csv = output_dir / "eg_vs_acd_metrics_latest.csv"

    write_json(all_metrics, json_path)
    write_csv(all_metrics, csv_path)
    write_json(all_metrics, latest_json)
    write_csv(all_metrics, latest_csv)

    # Print comparison
    print_comparison_table(all_metrics)

    print(f"\n  Analysis complete!")
    return all_metrics


if __name__ == "__main__":
    main()
