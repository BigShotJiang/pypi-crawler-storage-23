#!/usr/bin/env python3
"""
generate_feedback_acd_json.py

Generate ACD JSON files for feedback n-queue models.
Feedback = tandem n stations with probabilistic routing (p=0.5) after last station.

Configurations: n = {1, 2, 3, 4, 5, 7, 10, 15, 20}
"""

import json
import os


def generate_feedback_acd_json(n):
    """Generate ACD JSON for feedback_n model."""
    model_name = f"feedback_{n}_acd"

    # --- Parameters ---
    parameters = {
        "num_servers": {
            "type": "Nat",
            "value": 5,
            "description": "Number of servers per station"
        },
        "iat_mean": {
            "type": "Real",
            "value": 1.25,
            "description": "Inter-arrival time mean"
        },
        "ist_mean": {
            "type": "Real",
            "value": 1.0,
            "description": "Service time mean per station"
        },
        "feedback_prob": {
            "type": "Real",
            "value": 0.5,
            "description": "Probability of feedback to station 1"
        },
        "sim_end_time": {
            "type": "Real",
            "value": 10000.0,
            "description": "Simulation end time"
        }
    }

    # --- Token Types ---
    job_attributes = {
        "arrival_time": {
            "type": "Real",
            "description": "Time job arrived"
        }
    }
    for i in range(1, n + 1):
        job_attributes[f"service_start_time_{i}"] = {
            "type": "Real",
            "description": f"Time job started service at station {i}"
        }

    token_types = {
        "Job": {
            "name": "Job",
            "parent": "Token",
            "attributes": job_attributes,
            "description": "Customer job token"
        },
        "Resource": {
            "name": "Resource",
            "parent": "Token",
            "attributes": {},
            "description": "Reusable resource token"
        }
    }

    # --- Queues ---
    queues = {
        "C": {
            "initial_tokens": 1,
            "token_type": "Resource",
            "is_resource": True,
            "description": "Creator resource queue"
        }
    }
    for i in range(1, n + 1):
        queues[f"Q_{i}"] = {
            "initial_tokens": 0,
            "token_type": "Job",
            "is_resource": False,
            "description": f"Job waiting queue at station {i}"
        }
        queues[f"S_{i}"] = {
            "initial_tokens": 5,
            "token_type": "Resource",
            "is_resource": True,
            "description": f"Server resource queue at station {i}"
        }
    queues["Jobs"] = {
        "initial_tokens": 0,
        "token_type": "Job",
        "is_resource": False,
        "description": "Completed jobs (sink)"
    }

    # --- Activities ---
    activities = []

    # Create activity
    activities.append({
        "name": "Create",
        "priority": 2,
        "at_begin": {
            "condition": "true",
            "consume": [
                {"queue": "C", "count": 1, "bind_as": "creator_token"}
            ],
            "actions": []
        },
        "at_end": [
            {
                "condition": "true",
                "produce": [
                    {"queue": "C", "count": 1, "token_source": "creator_token"},
                    {"queue": "Q_1", "count": 1, "token_source": "new"}
                ],
                "actions": ["job_id_counter := job_id_counter + 1"]
            }
        ],
        "description": "Job creation activity",
        "duration": "duration_create"
    })

    # Serve activities for stations 1..n-1 (intermediate)
    for i in range(1, n):
        activities.append({
            "name": f"Serve_{i}",
            "priority": 1,
            "at_begin": {
                "condition": "true",
                "consume": [
                    {"queue": f"S_{i}", "count": 1, "bind_as": "server_token"},
                    {"queue": f"Q_{i}", "count": 1, "bind_as": "job_token"}
                ],
                "actions": [f"service_start_time_{i}(job_token) := sim_clocktime"]
            },
            "at_end": [
                {
                    "condition": "true",
                    "produce": [
                        {"queue": f"S_{i}", "count": 1, "token_source": "server_token"},
                        {"queue": f"Q_{i+1}", "count": 1, "token_source": "job_token"}
                    ],
                    "actions": []
                }
            ],
            "description": f"Service activity at station {i}",
            "duration": f"duration_serve_{i}"
        })

    # Serve_n (last station with probabilistic feedback)
    activities.append({
        "name": f"Serve_{n}",
        "priority": 1,
        "at_begin": {
            "condition": "true",
            "consume": [
                {"queue": f"S_{n}", "count": 1, "bind_as": "server_token"},
                {"queue": f"Q_{n}", "count": 1, "bind_as": "job_token"}
            ],
            "actions": [f"service_start_time_{n}(job_token) := sim_clocktime"]
        },
        "at_end": [
            {
                "condition": "feedback",
                "produce": [
                    {"queue": f"S_{n}", "count": 1, "token_source": "server_token"},
                    {"queue": "Q_1", "count": 1, "token_source": "job_token"}
                ],
                "actions": []
            },
            {
                "condition": "not_feedback",
                "produce": [
                    {"queue": f"S_{n}", "count": 1, "token_source": "server_token"},
                    {"queue": "Jobs", "count": 1, "token_source": "job_token"}
                ],
                "actions": ["departure_count := departure_count + 1"]
            }
        ],
        "description": f"Service activity at station {n} (with feedback)",
        "duration": f"duration_serve_{n}"
    })

    # --- Random Streams ---
    random_streams = {
        "duration_create": {
            "distribution": "exponential",
            "params": {"mean": "iat_mean"},
            "stream_name": "arrivals"
        }
    }
    for i in range(1, n + 1):
        random_streams[f"duration_serve_{i}"] = {
            "distribution": "exponential",
            "params": {"mean": "ist_mean"},
            "stream_name": f"service_{i}"
        }

    # --- State Variables ---
    state_variables = {
        "job_id_counter": {"type": "Nat", "initial": 0},
        "departure_count": {"type": "Nat", "initial": 0}
    }

    # --- Observables ---
    observables = {}
    for i in range(1, n + 1):
        observables[f"queue_count_{i}"] = {
            "name": f"queue_count_{i}",
            "expression": f"marking(Q_{i})",
            "description": f"Number in queue at station {i}"
        }
        observables[f"server_count_{i}"] = {
            "name": f"server_count_{i}",
            "expression": f"num_servers - marking(S_{i})",
            "description": f"Number of busy servers at station {i}"
        }

    # In-system expression
    parts = []
    for i in range(1, n + 1):
        parts.append(f"marking(Q_{i}) + (num_servers - marking(S_{i}))")
    in_system_expr = " + ".join(parts)
    observables["in_system"] = {
        "name": "in_system",
        "expression": in_system_expr,
        "description": "Total in system"
    }

    # --- Statistics ---
    queue_sum_parts = [f"marking(Q_{i})" for i in range(1, n + 1)]
    statistics = [
        {
            "name": "L_q_total",
            "type": "time_average",
            "expression": " + ".join(queue_sum_parts),
            "description": "Average total queue length"
        },
        {
            "name": "L",
            "type": "time_average",
            "expression": in_system_expr,
            "description": "Average number in system"
        },
        {
            "name": "throughput",
            "type": "count",
            "expression": "departure_count",
            "description": "Total departures"
        }
    ]

    # --- Assemble ---
    spec = {
        "model_name": model_name,
        "description": f"Feedback {n}-Queue using Activity Cycle Diagram - {n} station{'s' if n > 1 else ''} in tandem with 50% feedback",
        "parameters": parameters,
        "token_types": token_types,
        "queues": queues,
        "activities": activities,
        "random_streams": random_streams,
        "state_variables": state_variables,
        "stopping_condition": "sim_clocktime >= sim_end_time",
        "observables": observables,
        "statistics": statistics
    }

    return spec


def main():
    n_values = [1, 2, 3, 4, 5, 7, 10, 15, 20]
    output_dir = os.path.dirname(os.path.abspath(__file__))

    print("Generating feedback ACD JSON files...")
    for n in n_values:
        spec = generate_feedback_acd_json(n)
        filename = f"feedback_{n}_acd.json"
        filepath = os.path.join(output_dir, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(spec, f, indent=2)

        num_activities = len(spec["activities"])
        num_queues = len(spec["queues"])
        print(f"  {filename}: {num_activities} activities, {num_queues} queues")

    print(f"\nGenerated {len(n_values)} files in {output_dir}")


if __name__ == "__main__":
    main()
