#!/usr/bin/env python3
"""
generate_feedback_asm.py

Generate SimASM models from feedback n-queue JSON specifications.

Usage:
    python generate_feedback_asm.py --all
    python generate_feedback_asm.py --n 1 3 5
"""

import sys
import argparse
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from simasm.converter import convert_eg_from_json
from simasm.converter.acd.schema_x import load_acd_from_json as load_acd_spec


def convert_acd_from_json_extended(json_path: str) -> str:
    """Load ACD JSON with extended format and convert to SimASM code."""
    import sys as _sys
    from simasm.converter.acd import schema_x
    _sys.modules['simasm.converter.acd.schema'] = schema_x
    try:
        from importlib import reload
        import simasm.converter.acd.converter_x as converter_x
        reload(converter_x)
        spec = load_acd_spec(json_path)
        return converter_x.convert_acd(spec)
    finally:
        from simasm.converter.acd import schema
        _sys.modules['simasm.converter.acd.schema'] = schema


BASE_DIR = Path(__file__).parent
SUPPORTED_N_VALUES = [1, 2, 3, 4, 5, 7, 10, 15, 20]


def generate_eg_model(n: int, verbose: bool = True) -> Path:
    """Generate Event Graph ASM model for feedback n-queue."""
    json_path = BASE_DIR / "eg" / f"feedback_{n}_eg.json"
    output_path = BASE_DIR / "generated" / "eg" / f"feedback_{n}_eg.simasm"

    if not json_path.exists():
        raise FileNotFoundError(f"EG JSON not found: {json_path}")

    if verbose:
        print(f"  Converting EG: {json_path.name} -> {output_path.name}")

    simasm_code = convert_eg_from_json(str(json_path))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(simasm_code)

    if verbose:
        lines = simasm_code.count('\n')
        print(f"    Generated {lines} lines")

    return output_path


def generate_acd_model(n: int, verbose: bool = True) -> Path:
    """Generate Activity Cycle Diagram ASM model for feedback n-queue."""
    json_path = BASE_DIR / "acd" / f"feedback_{n}_acd.json"
    output_path = BASE_DIR / "generated" / "acd" / f"feedback_{n}_acd.simasm"

    if not json_path.exists():
        raise FileNotFoundError(f"ACD JSON not found: {json_path}")

    if verbose:
        print(f"  Converting ACD: {json_path.name} -> {output_path.name}")

    simasm_code = convert_acd_from_json_extended(str(json_path))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(simasm_code)

    if verbose:
        lines = simasm_code.count('\n')
        print(f"    Generated {lines} lines")

    return output_path


def generate_all_models(n_values: list = None, verbose: bool = True) -> dict:
    """Generate all EG and ACD models for specified n values."""
    if n_values is None:
        n_values = SUPPORTED_N_VALUES

    results = {"generated": [], "failed": [], "eg_files": [], "acd_files": []}

    print("=" * 70)
    print("  FEEDBACK N-QUEUE ASM MODEL GENERATION")
    print("=" * 70)
    print(f"\nGenerating models for n = {n_values}")
    print(f"Output directory: {BASE_DIR / 'generated'}\n")

    for n in n_values:
        print(f"\n[n={n}] Generating feedback {n}-queue models...")
        try:
            eg_path = generate_eg_model(n, verbose)
            results["eg_files"].append(str(eg_path))
            acd_path = generate_acd_model(n, verbose)
            results["acd_files"].append(str(acd_path))
            results["generated"].append(n)
            print(f"    SUCCESS")
        except Exception as e:
            results["failed"].append({"n": n, "error": str(e)})
            print(f"    FAILED: {e}")

    print("\n" + "=" * 70)
    print(f"  GENERATION COMPLETE")
    print("=" * 70)
    print(f"  Generated: {len(results['generated'])} model pairs")
    print(f"  Failed: {len(results['failed'])}")

    if results["failed"]:
        print(f"\n  Failed models:")
        for fail in results["failed"]:
            print(f"    n={fail['n']}: {fail['error']}")

    return results


def main():
    parser = argparse.ArgumentParser(
        description="Generate SimASM models from feedback n-queue JSON specifications"
    )
    parser.add_argument("--all", action="store_true", help="Generate all models")
    parser.add_argument("--n", type=int, nargs="+", help="Specific n values to generate")
    parser.add_argument("--quiet", action="store_true", help="Suppress verbose output")

    args = parser.parse_args()

    if not args.all and not args.n:
        parser.print_help()
        print("\nError: Specify --all or --n <values>")
        sys.exit(1)

    n_values = SUPPORTED_N_VALUES if args.all else args.n
    results = generate_all_models(n_values, verbose=not args.quiet)
    sys.exit(1 if results["failed"] else 0)


if __name__ == "__main__":
    main()
