#!/usr/bin/env python3
"""
generate_hybrid_json.py

Generate Event Graph JSON files for hybrid topology models.
Hybrid = N tandem stations + M fork-join branches + feedback (p=0.5).

Configurations: 20 (N, M) pairs ranging from (1,2) to (10,3)
"""

import json
import os


def generate_hybrid_json(n, m):
    """Generate Event Graph JSON for hybrid_(n)_(m) model."""
    model_name = f"hybrid_{n}_{m}_eg"

    # --- Entities ---
    attributes = {"arrival_time": "Real"}
    for i in range(1, n + 1):
        attributes[f"service_start_time_{i}"] = "Real"
    attributes["fork_time"] = "Real"
    for j in range(1, m + 1):
        attributes[f"branch_start_time_{j}"] = "Real"
    attributes["departure_time"] = "Real"

    entities = {
        "Load": {
            "name": "Load",
            "parent": "Object",
            "attributes": attributes
        }
    }

    # --- Parameters ---
    parameters = {
        "service_capacity": {
            "type": "Nat",
            "value": 5,
            "description": "Number of servers per station"
        },
        "iat_mean": {
            "type": "Real",
            "value": 1.25,
            "description": "Inter-arrival time mean"
        },
        "ist_mean": {
            "type": "Real",
            "value": 1.0,
            "description": "Service time mean per station"
        },
        "feedback_prob": {
            "type": "Real",
            "value": 0.5,
            "description": "Probability of feedback to station 1"
        },
        "sim_end_time": {
            "type": "Real",
            "value": 10000.0,
            "description": "Simulation end time"
        }
    }

    # --- State Variables ---
    state_variables = {}
    # Tandem stations
    for i in range(1, n + 1):
        state_variables[f"queue_count_{i}"] = {
            "type": "Nat", "initial": 0,
            "description": f"Number in queue at tandem station {i}"
        }
        state_variables[f"server_count_{i}"] = {
            "type": "Nat", "initial": 0,
            "description": f"Number being served at tandem station {i}"
        }
    # Fork-join branches
    for j in range(1, m + 1):
        state_variables[f"branch_queue_{j}"] = {
            "type": "Nat", "initial": 0,
            "description": f"Number in queue at branch {j}"
        }
        state_variables[f"branch_server_{j}"] = {
            "type": "Nat", "initial": 0,
            "description": f"Number being served at branch {j}"
        }
        state_variables[f"part_{j}_num"] = {
            "type": "Nat", "initial": 0,
            "description": f"Completed but not yet joined at branch {j}"
        }
    state_variables["load_id_counter"] = {"type": "Nat", "initial": 0}
    state_variables["departure_count"] = {"type": "Nat", "initial": 0}

    # --- Random Streams ---
    random_streams = {
        "interarrival_time": {
            "distribution": "exponential",
            "params": {"mean": "iat_mean"},
            "stream_name": "arrivals"
        }
    }
    for i in range(1, n + 1):
        random_streams[f"service_time_{i}"] = {
            "distribution": "exponential",
            "params": {"mean": "ist_mean"},
            "stream_name": f"service_{i}"
        }
    for j in range(1, m + 1):
        random_streams[f"branch_service_time_{j}"] = {
            "distribution": "exponential",
            "params": {"mean": "ist_mean"},
            "stream_name": f"branch_service_{j}"
        }

    # --- Vertices ---
    vertices = []

    # Arrive
    vertices.append({
        "name": "Arrive",
        "description": "Customer arrival event",
        "state_change": "load_id_counter := load_id_counter + 1; queue_count_1 := queue_count_1 + 1"
    })

    # Tandem stations Start_i / Finish_i
    for i in range(1, n + 1):
        vertices.append({
            "name": f"Start_{i}",
            "parameters": [{"load": "Load"}],
            "description": f"Service start at tandem station {i}",
            "state_change": f"queue_count_{i} := queue_count_{i} - 1; server_count_{i} := server_count_{i} + 1"
        })
        if i < n:
            # Intermediate station: route to next queue
            finish_state = f"server_count_{i} := server_count_{i} - 1; queue_count_{i+1} := queue_count_{i+1} + 1"
        else:
            # Last tandem station: just decrement server (Fork handles routing)
            finish_state = f"server_count_{i} := server_count_{i} - 1"
        vertices.append({
            "name": f"Finish_{i}",
            "parameters": [{"load": "Load"}],
            "description": f"Service completion at tandem station {i}",
            "state_change": finish_state
        })

    # Fork
    fork_state_parts = [f"branch_queue_{j} := branch_queue_{j} + 1" for j in range(1, m + 1)]
    vertices.append({
        "name": "Fork",
        "description": "Fork: distribute load to all branches",
        "state_change": "; ".join(fork_state_parts)
    })

    # Branch stations Branch_Start_j / Branch_Finish_j
    for j in range(1, m + 1):
        vertices.append({
            "name": f"Branch_Start_{j}",
            "parameters": [{"load": "Load"}],
            "description": f"Service start at branch {j}",
            "state_change": f"branch_queue_{j} := branch_queue_{j} - 1; branch_server_{j} := branch_server_{j} + 1"
        })
        vertices.append({
            "name": f"Branch_Finish_{j}",
            "parameters": [{"load": "Load"}],
            "description": f"Service completion at branch {j}",
            "state_change": f"branch_server_{j} := branch_server_{j} - 1; part_{j}_num := part_{j}_num + 1"
        })

    # Join
    join_state_parts = [f"part_{j}_num := part_{j}_num - 1" for j in range(1, m + 1)]
    vertices.append({
        "name": "Join",
        "description": "Join: synchronize all branches",
        "state_change": "; ".join(join_state_parts)
    })

    # Attempt_To_Depart
    vertices.append({
        "name": "Attempt_To_Depart",
        "description": "Probabilistic departure/feedback decision",
        "state_change": ""
    })

    # Depart
    vertices.append({
        "name": "Depart",
        "description": "Customer departs the system",
        "state_change": "departure_count := departure_count + 1"
    })

    # --- Scheduling Edges ---
    edges = []

    # Arrive -> Arrive (self-scheduling)
    edges.append({
        "from": "Arrive", "to": "Arrive",
        "delay": "interarrival_time", "condition": "true", "priority": 0
    })

    # Arrive -> Start_1
    edges.append({
        "from": "Arrive", "to": "Start_1",
        "delay": 0, "condition": "server_count_1 < service_capacity",
        "priority": 0, "parameters": ["load"]
    })

    # Tandem section edges
    for i in range(1, n + 1):
        # Start_i -> Finish_i
        edges.append({
            "from": f"Start_{i}", "to": f"Finish_{i}",
            "delay": f"service_time_{i}", "condition": "true",
            "priority": 0, "parameters": ["load"]
        })
        # Finish_i -> Start_i (self-loop for queue)
        edges.append({
            "from": f"Finish_{i}", "to": f"Start_{i}",
            "delay": 0,
            "condition": f"queue_count_{i} > 0 and server_count_{i} < service_capacity",
            "priority": 0, "parameters": ["next_load"]
        })
        if i < n:
            # Finish_i -> Start_{i+1}
            edges.append({
                "from": f"Finish_{i}", "to": f"Start_{i+1}",
                "delay": 0,
                "condition": f"server_count_{i+1} < service_capacity",
                "priority": 0, "parameters": ["load"]
            })

    # Finish_N -> Fork
    edges.append({
        "from": f"Finish_{n}", "to": "Fork",
        "delay": 0, "condition": "true", "priority": 0
    })

    # Fork -> Branch_Start_j
    for j in range(1, m + 1):
        edges.append({
            "from": "Fork", "to": f"Branch_Start_{j}",
            "delay": 0,
            "condition": f"branch_queue_{j} > 0 and branch_server_{j} < service_capacity",
            "priority": 0, "parameters": ["load"]
        })

    # Branch section edges
    for j in range(1, m + 1):
        # Branch_Start_j -> Branch_Finish_j
        edges.append({
            "from": f"Branch_Start_{j}", "to": f"Branch_Finish_{j}",
            "delay": f"branch_service_time_{j}", "condition": "true",
            "priority": 0, "parameters": ["load"]
        })
        # Branch_Finish_j -> Branch_Start_j (self-loop)
        edges.append({
            "from": f"Branch_Finish_{j}", "to": f"Branch_Start_{j}",
            "delay": 0,
            "condition": f"branch_queue_{j} > 0 and branch_server_{j} < service_capacity",
            "priority": 0, "parameters": ["next_load"]
        })
        # Branch_Finish_j -> Join
        edges.append({
            "from": f"Branch_Finish_{j}", "to": "Join",
            "delay": 0, "condition": "true", "priority": 0
        })

    # Join -> Attempt_To_Depart (conditional on all parts complete)
    join_condition = " and ".join(f"part_{j}_num > 0" for j in range(1, m + 1))
    edges.append({
        "from": "Join", "to": "Attempt_To_Depart",
        "delay": 0, "condition": join_condition, "priority": 0
    })

    # Attempt_To_Depart -> Start_1 (feedback)
    edges.append({
        "from": "Attempt_To_Depart", "to": "Start_1",
        "delay": 0, "condition": "feedback", "priority": 0,
        "feedback_action": "queue_count_1 := queue_count_1 + 1"
    })

    # Attempt_To_Depart -> Depart (not feedback)
    edges.append({
        "from": "Attempt_To_Depart", "to": "Depart",
        "delay": 0, "condition": "not_feedback", "priority": 0,
        "depart_action": "departure_count := departure_count + 1"
    })

    # --- Observables ---
    observables = {}
    # Tandem queues and servers
    for i in range(1, n + 1):
        observables[f"queue_count_{i}"] = {
            "name": f"queue_count_{i}",
            "expression": f"queue_count_{i}",
            "description": f"Number in queue at tandem station {i}"
        }
        observables[f"server_count_{i}"] = {
            "name": f"server_count_{i}",
            "expression": f"server_count_{i}",
            "description": f"Number of busy servers at tandem station {i}"
        }
    # Branch queues and servers
    for j in range(1, m + 1):
        observables[f"branch_queue_{j}"] = {
            "name": f"branch_queue_{j}",
            "expression": f"branch_queue_{j}",
            "description": f"Number in queue at branch {j}"
        }
        observables[f"branch_server_{j}"] = {
            "name": f"branch_server_{j}",
            "expression": f"branch_server_{j}",
            "description": f"Number of busy servers at branch {j}"
        }

    # In-system expression
    tandem_parts = [f"queue_count_{i} + server_count_{i}" for i in range(1, n + 1)]
    branch_parts = [f"branch_queue_{j} + branch_server_{j} + part_{j}_num" for j in range(1, m + 1)]
    in_system_expr = " + ".join(tandem_parts + branch_parts)
    observables["in_system"] = {
        "name": "in_system",
        "expression": in_system_expr,
        "description": "Total in system"
    }

    # Total queue length
    queue_parts = [f"queue_count_{i}" for i in range(1, n + 1)] + \
                  [f"branch_queue_{j}" for j in range(1, m + 1)]
    observables["L_q_total"] = {
        "name": "L_q_total",
        "expression": " + ".join(queue_parts),
        "description": "Total queue length"
    }

    observables["departure_count"] = {
        "name": "departure_count",
        "expression": "departure_count",
        "description": "Total departures"
    }

    # --- Statistics ---
    statistics = [
        {
            "name": "L_q_total",
            "type": "time_average",
            "observable": "L_q_total",
            "description": "Average total queue length"
        },
        {
            "name": "L",
            "type": "time_average",
            "observable": "in_system",
            "description": "Average number in system"
        },
        {
            "name": "throughput",
            "type": "count",
            "observable": "departure_count",
            "description": "Total departures"
        }
    ]

    # --- Assemble ---
    spec = {
        "model_name": model_name,
        "description": f"Hybrid {n}x{m}-Queue: {n} tandem stations, {m} fork-join branches, feedback p=0.5",
        "entities": entities,
        "parameters": parameters,
        "state_variables": state_variables,
        "random_streams": random_streams,
        "vertices": vertices,
        "scheduling_edges": edges,
        "cancelling_edges": [],
        "initial_events": [
            {"event": "Arrive", "time": "interarrival_time"}
        ],
        "stopping_condition": "sim_clocktime >= sim_end_time",
        "observables": observables,
        "statistics": statistics
    }

    return spec


def main():
    configurations = [
        (1, 2), (1, 3), (2, 2), (2, 3), (2, 4),
        (3, 2), (3, 3), (3, 4), (4, 2), (4, 3),
        (4, 4), (5, 2), (5, 3), (5, 4), (5, 5),
        (7, 2), (7, 3), (7, 4), (10, 2), (10, 3),
    ]
    output_dir = os.path.dirname(os.path.abspath(__file__))

    print("Generating hybrid Event Graph JSON files...")
    for n, m in configurations:
        spec = generate_hybrid_json(n, m)
        filename = f"hybrid_{n}_{m}_eg.json"
        filepath = os.path.join(output_dir, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(spec, f, indent=2)

        num_vertices = len(spec["vertices"])
        num_edges = len(spec["scheduling_edges"])
        num_state_vars = len(spec["state_variables"])
        print(f"  {filename}: {num_vertices} vertices, {num_edges} edges, {num_state_vars} state vars")

    print(f"\nGenerated {len(configurations)} files in {output_dir}")


if __name__ == "__main__":
    main()
