#!/usr/bin/env python3
"""
generate_hybrid_asm.py

Generate SimASM models from hybrid topology JSON specifications.

Usage:
    python generate_hybrid_asm.py --all
"""

import sys
import argparse
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from simasm.converter import convert_eg_from_json
from simasm.converter.acd.schema_x import load_acd_from_json as load_acd_spec


def convert_acd_from_json_extended(json_path: str) -> str:
    """Load ACD JSON with extended format and convert to SimASM code."""
    import sys as _sys
    from simasm.converter.acd import schema_x
    _sys.modules['simasm.converter.acd.schema'] = schema_x
    try:
        from importlib import reload
        import simasm.converter.acd.converter_x as converter_x
        reload(converter_x)
        spec = load_acd_spec(json_path)
        return converter_x.convert_acd(spec)
    finally:
        from simasm.converter.acd import schema
        _sys.modules['simasm.converter.acd.schema'] = schema


BASE_DIR = Path(__file__).parent
CONFIGURATIONS = [
    (1, 2), (1, 3), (2, 2), (2, 3), (2, 4),
    (3, 2), (3, 3), (3, 4), (4, 2), (4, 3),
    (4, 4), (5, 2), (5, 3), (5, 4), (5, 5),
    (7, 2), (7, 3), (7, 4), (10, 2), (10, 3),
]


def generate_eg_model(n: int, m: int, verbose: bool = True) -> Path:
    """Generate Event Graph ASM model for hybrid n x m queue."""
    json_path = BASE_DIR / "eg" / f"hybrid_{n}_{m}_eg.json"
    output_path = BASE_DIR / "generated" / "eg" / f"hybrid_{n}_{m}_eg.simasm"

    if not json_path.exists():
        raise FileNotFoundError(f"EG JSON not found: {json_path}")

    if verbose:
        print(f"  Converting EG: {json_path.name} -> {output_path.name}")

    simasm_code = convert_eg_from_json(str(json_path))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(simasm_code)

    if verbose:
        lines = simasm_code.count('\n')
        print(f"    Generated {lines} lines")

    return output_path


def generate_acd_model(n: int, m: int, verbose: bool = True) -> Path:
    """Generate Activity Cycle Diagram ASM model for hybrid n x m queue."""
    json_path = BASE_DIR / "acd" / f"hybrid_{n}_{m}_acd.json"
    output_path = BASE_DIR / "generated" / "acd" / f"hybrid_{n}_{m}_acd.simasm"

    if not json_path.exists():
        raise FileNotFoundError(f"ACD JSON not found: {json_path}")

    if verbose:
        print(f"  Converting ACD: {json_path.name} -> {output_path.name}")

    simasm_code = convert_acd_from_json_extended(str(json_path))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(simasm_code)

    if verbose:
        lines = simasm_code.count('\n')
        print(f"    Generated {lines} lines")

    return output_path


def generate_all_models(configs: list = None, verbose: bool = True) -> dict:
    """Generate all EG and ACD models for specified configurations."""
    if configs is None:
        configs = CONFIGURATIONS

    results = {"generated": [], "failed": [], "eg_files": [], "acd_files": []}

    print("=" * 70)
    print("  HYBRID TOPOLOGY ASM MODEL GENERATION")
    print("=" * 70)
    print(f"\nGenerating {len(configs)} model pairs")
    print(f"Output directory: {BASE_DIR / 'generated'}\n")

    for n, m in configs:
        print(f"\n[{n}x{m}] Generating hybrid {n}_{m} models...")
        try:
            eg_path = generate_eg_model(n, m, verbose)
            results["eg_files"].append(str(eg_path))
            acd_path = generate_acd_model(n, m, verbose)
            results["acd_files"].append(str(acd_path))
            results["generated"].append((n, m))
            print(f"    SUCCESS")
        except Exception as e:
            results["failed"].append({"config": (n, m), "error": str(e)})
            print(f"    FAILED: {e}")

    print("\n" + "=" * 70)
    print(f"  GENERATION COMPLETE")
    print("=" * 70)
    print(f"  Generated: {len(results['generated'])} model pairs")
    print(f"  Failed: {len(results['failed'])}")

    if results["failed"]:
        print(f"\n  Failed models:")
        for fail in results["failed"]:
            print(f"    {fail['config']}: {fail['error']}")

    return results


def main():
    parser = argparse.ArgumentParser(
        description="Generate SimASM models from hybrid topology JSON specifications"
    )
    parser.add_argument("--all", action="store_true", help="Generate all models")
    parser.add_argument("--quiet", action="store_true", help="Suppress verbose output")

    args = parser.parse_args()

    if not args.all:
        parser.print_help()
        print("\nError: Specify --all")
        sys.exit(1)

    results = generate_all_models(verbose=not args.quiet)
    sys.exit(1 if results["failed"] else 0)


if __name__ == "__main__":
    main()
