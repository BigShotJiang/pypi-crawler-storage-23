#!/usr/bin/env python3
"""
generate_hybrid_acd_json.py

Generate ACD JSON files for hybrid topology models.
Hybrid = N tandem stations + M fork-join branches + feedback (p=0.5).

Configurations: 20 (N, M) pairs matching existing EG models.
"""

import json
import os


def generate_hybrid_acd_json(n, m):
    """Generate ACD JSON for hybrid_(n)_(m) model."""
    model_name = f"hybrid_{n}_{m}_acd"

    # --- Parameters ---
    parameters = {
        "num_servers": {
            "type": "Nat",
            "value": 5,
            "description": "Number of servers per station"
        },
        "iat_mean": {
            "type": "Real",
            "value": 1.25,
            "description": "Inter-arrival time mean"
        },
        "ist_mean": {
            "type": "Real",
            "value": 1.0,
            "description": "Service time mean per station"
        },
        "feedback_prob": {
            "type": "Real",
            "value": 0.5,
            "description": "Probability of feedback to station 1"
        },
        "sim_end_time": {
            "type": "Real",
            "value": 10000.0,
            "description": "Simulation end time"
        }
    }

    # --- Token Types ---
    job_attributes = {
        "arrival_time": {
            "type": "Real",
            "description": "Time job arrived"
        }
    }
    for i in range(1, n + 1):
        job_attributes[f"service_start_time_{i}"] = {
            "type": "Real",
            "description": f"Time job started service at tandem station {i}"
        }
    job_attributes["fork_time"] = {
        "type": "Real",
        "description": "Time job was forked"
    }
    for j in range(1, m + 1):
        job_attributes[f"branch_start_time_{j}"] = {
            "type": "Real",
            "description": f"Time job started service at branch {j}"
        }

    token_types = {
        "Job": {
            "name": "Job",
            "parent": "Token",
            "attributes": job_attributes,
            "description": "Customer job token"
        },
        "Resource": {
            "name": "Resource",
            "parent": "Token",
            "attributes": {},
            "description": "Reusable resource token"
        }
    }

    # --- Queues ---
    queues = {
        "C": {
            "initial_tokens": 1,
            "token_type": "Resource",
            "is_resource": True,
            "description": "Creator resource queue"
        }
    }

    # Tandem station queues
    for i in range(1, n + 1):
        queues[f"Q_{i}"] = {
            "initial_tokens": 0,
            "token_type": "Job",
            "is_resource": False,
            "description": f"Job waiting queue at tandem station {i}"
        }
        queues[f"S_{i}"] = {
            "initial_tokens": 5,
            "token_type": "Resource",
            "is_resource": True,
            "description": f"Server resource queue at tandem station {i}"
        }

    # Fork queue
    queues["Q_fork"] = {
        "initial_tokens": 0,
        "token_type": "Job",
        "is_resource": False,
        "description": "Pre-fork queue"
    }

    # Branch queues
    for j in range(1, m + 1):
        queues[f"BQ_{j}"] = {
            "initial_tokens": 0,
            "token_type": "Job",
            "is_resource": False,
            "description": f"Job waiting queue at branch {j}"
        }
        queues[f"BS_{j}"] = {
            "initial_tokens": 5,
            "token_type": "Resource",
            "is_resource": True,
            "description": f"Server resource queue at branch {j}"
        }
        queues[f"P_{j}"] = {
            "initial_tokens": 0,
            "token_type": "Job",
            "is_resource": False,
            "description": f"Part completion queue at branch {j}"
        }

    queues["Jobs"] = {
        "initial_tokens": 0,
        "token_type": "Job",
        "is_resource": False,
        "description": "Completed jobs (sink)"
    }

    # --- Activities ---
    activities = []

    # Create activity (highest priority)
    activities.append({
        "name": "Create",
        "priority": 4,
        "at_begin": {
            "condition": "true",
            "consume": [
                {"queue": "C", "count": 1, "bind_as": "creator_token"}
            ],
            "actions": []
        },
        "at_end": [
            {
                "condition": "true",
                "produce": [
                    {"queue": "C", "count": 1, "token_source": "creator_token"},
                    {"queue": "Q_1", "count": 1, "token_source": "new"}
                ],
                "actions": ["job_id_counter := job_id_counter + 1"]
            }
        ],
        "description": "Job creation activity",
        "duration": "duration_create"
    })

    # Tandem Serve activities (Serve_1..Serve_n)
    for i in range(1, n + 1):
        if i < n:
            # Intermediate station: route to next tandem queue
            at_end = [
                {
                    "condition": "true",
                    "produce": [
                        {"queue": f"S_{i}", "count": 1, "token_source": "server_token"},
                        {"queue": f"Q_{i+1}", "count": 1, "token_source": "job_token"}
                    ],
                    "actions": []
                }
            ]
        else:
            # Last tandem station: route to fork queue
            at_end = [
                {
                    "condition": "true",
                    "produce": [
                        {"queue": f"S_{i}", "count": 1, "token_source": "server_token"},
                        {"queue": "Q_fork", "count": 1, "token_source": "job_token"}
                    ],
                    "actions": []
                }
            ]

        activities.append({
            "name": f"Serve_{i}",
            "priority": 3,
            "at_begin": {
                "condition": "true",
                "consume": [
                    {"queue": f"S_{i}", "count": 1, "bind_as": "server_token"},
                    {"queue": f"Q_{i}", "count": 1, "bind_as": "job_token"}
                ],
                "actions": [f"service_start_time_{i}(job_token) := sim_clocktime"]
            },
            "at_end": at_end,
            "description": f"Service activity at tandem station {i}",
            "duration": f"duration_serve_{i}"
        })

    # Fork activity (zero duration)
    fork_produce = [{"queue": f"BQ_{j}", "count": 1, "token_source": "new"} for j in range(1, m + 1)]
    activities.append({
        "name": "Fork",
        "priority": 2,
        "at_begin": {
            "condition": "true",
            "consume": [
                {"queue": "Q_fork", "count": 1, "bind_as": "fork_token"}
            ],
            "actions": []
        },
        "at_end": [
            {
                "condition": "true",
                "produce": fork_produce,
                "actions": []
            }
        ],
        "description": "Fork: distribute job to all branches",
        "duration": "duration_fork"
    })

    # Branch Serve activities
    for j in range(1, m + 1):
        activities.append({
            "name": f"Branch_Serve_{j}",
            "priority": 1,
            "at_begin": {
                "condition": "true",
                "consume": [
                    {"queue": f"BS_{j}", "count": 1, "bind_as": "server_token"},
                    {"queue": f"BQ_{j}", "count": 1, "bind_as": "job_token"}
                ],
                "actions": [f"branch_start_time_{j}(job_token) := sim_clocktime"]
            },
            "at_end": [
                {
                    "condition": "true",
                    "produce": [
                        {"queue": f"BS_{j}", "count": 1, "token_source": "server_token"},
                        {"queue": f"P_{j}", "count": 1, "token_source": "job_token"}
                    ],
                    "actions": []
                }
            ],
            "description": f"Service activity at branch {j}",
            "duration": f"duration_branch_serve_{j}"
        })

    # Join activity (zero duration, with feedback)
    join_consume = [{"queue": f"P_{j}", "count": 1, "bind_as": f"part_token_{j}"} for j in range(1, m + 1)]
    activities.append({
        "name": "Join",
        "priority": 0,
        "at_begin": {
            "condition": "true",
            "consume": join_consume,
            "actions": []
        },
        "at_end": [
            {
                "condition": "feedback",
                "produce": [
                    {"queue": "Q_1", "count": 1, "token_source": "new"}
                ],
                "actions": []
            },
            {
                "condition": "not_feedback",
                "produce": [
                    {"queue": "Jobs", "count": 1, "token_source": "new"}
                ],
                "actions": ["departure_count := departure_count + 1"]
            }
        ],
        "description": "Join: synchronize all branches (with feedback)",
        "duration": "duration_join"
    })

    # --- Random Streams ---
    random_streams = {
        "duration_create": {
            "distribution": "exponential",
            "params": {"mean": "iat_mean"},
            "stream_name": "arrivals"
        },
        "duration_fork": {
            "distribution": "constant",
            "params": {"value": 0},
            "stream_name": "fork"
        },
        "duration_join": {
            "distribution": "constant",
            "params": {"value": 0},
            "stream_name": "join"
        }
    }
    for i in range(1, n + 1):
        random_streams[f"duration_serve_{i}"] = {
            "distribution": "exponential",
            "params": {"mean": "ist_mean"},
            "stream_name": f"service_{i}"
        }
    for j in range(1, m + 1):
        random_streams[f"duration_branch_serve_{j}"] = {
            "distribution": "exponential",
            "params": {"mean": "ist_mean"},
            "stream_name": f"branch_service_{j}"
        }

    # --- State Variables ---
    state_variables = {
        "job_id_counter": {"type": "Nat", "initial": 0},
        "departure_count": {"type": "Nat", "initial": 0}
    }

    # --- Observables ---
    # Match EG observables exactly
    observables = {}

    # Tandem station observables
    for i in range(1, n + 1):
        observables[f"queue_count_{i}"] = {
            "name": f"queue_count_{i}",
            "expression": f"marking(Q_{i})",
            "description": f"Number in queue at tandem station {i}"
        }
        observables[f"server_count_{i}"] = {
            "name": f"server_count_{i}",
            "expression": f"num_servers - marking(S_{i})",
            "description": f"Number of busy servers at tandem station {i}"
        }

    # Branch observables
    for j in range(1, m + 1):
        observables[f"branch_queue_{j}"] = {
            "name": f"branch_queue_{j}",
            "expression": f"marking(BQ_{j})",
            "description": f"Number in queue at branch {j}"
        }
        observables[f"branch_server_{j}"] = {
            "name": f"branch_server_{j}",
            "expression": f"num_servers - marking(BS_{j})",
            "description": f"Number of busy servers at branch {j}"
        }

    # In-system expression
    tandem_parts = [f"marking(Q_{i}) + (num_servers - marking(S_{i}))" for i in range(1, n + 1)]
    branch_parts = [f"marking(BQ_{j}) + (num_servers - marking(BS_{j})) + marking(P_{j})" for j in range(1, m + 1)]
    in_system_expr = " + ".join(tandem_parts + branch_parts)
    observables["in_system"] = {
        "name": "in_system",
        "expression": in_system_expr,
        "description": "Total in system"
    }

    # Total queue length
    queue_parts = [f"marking(Q_{i})" for i in range(1, n + 1)] + \
                  [f"marking(BQ_{j})" for j in range(1, m + 1)]
    observables["L_q_total"] = {
        "name": "L_q_total",
        "expression": " + ".join(queue_parts),
        "description": "Total queue length"
    }

    observables["departure_count"] = {
        "name": "departure_count",
        "expression": "departure_count",
        "description": "Total departures"
    }

    # --- Statistics ---
    statistics = [
        {
            "name": "L_q_total",
            "type": "time_average",
            "expression": " + ".join(queue_parts),
            "description": "Average total queue length"
        },
        {
            "name": "L",
            "type": "time_average",
            "expression": in_system_expr,
            "description": "Average number in system"
        },
        {
            "name": "throughput",
            "type": "count",
            "expression": "departure_count",
            "description": "Total departures"
        }
    ]

    # --- Assemble ---
    spec = {
        "model_name": model_name,
        "description": f"Hybrid {n}x{m}-Queue using Activity Cycle Diagram - {n} tandem stations, {m} fork-join branches, feedback p=0.5",
        "parameters": parameters,
        "token_types": token_types,
        "queues": queues,
        "activities": activities,
        "random_streams": random_streams,
        "state_variables": state_variables,
        "stopping_condition": "sim_clocktime >= sim_end_time",
        "observables": observables,
        "statistics": statistics
    }

    return spec


def main():
    configurations = [
        (1, 2), (1, 3), (2, 2), (2, 3), (2, 4),
        (3, 2), (3, 3), (3, 4), (4, 2), (4, 3),
        (4, 4), (5, 2), (5, 3), (5, 4), (5, 5),
        (7, 2), (7, 3), (7, 4), (10, 2), (10, 3),
    ]
    output_dir = os.path.dirname(os.path.abspath(__file__))
    os.makedirs(output_dir, exist_ok=True)

    print("Generating hybrid ACD JSON files...")
    for n, m in configurations:
        spec = generate_hybrid_acd_json(n, m)
        filename = f"hybrid_{n}_{m}_acd.json"
        filepath = os.path.join(output_dir, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(spec, f, indent=2)

        num_activities = len(spec["activities"])
        num_queues = len(spec["queues"])
        print(f"  {filename}: {num_activities} activities, {num_queues} queues")

    print(f"\nGenerated {len(configurations)} files in {output_dir}")


if __name__ == "__main__":
    main()
