#!/usr/bin/env python3
"""
generate_held_out_models.py

Generate SimASM models from held-out topology JSON specifications.
These models are used for external validation of HET complexity metric.

Usage:
    python generate_held_out_models.py --all
    python generate_held_out_models.py --topology hybrid
"""

import sys
import argparse
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from simasm.converter import convert_eg_from_json

# Base directory
BASE_DIR = Path(__file__).parent

# Topology configurations
TOPOLOGIES = {
    "hybrid": {
        "models": [
            "hybrid_1_2", "hybrid_1_3",
            "hybrid_2_2", "hybrid_2_3", "hybrid_2_4",
            "hybrid_3_2", "hybrid_3_3", "hybrid_3_4",
            "hybrid_4_2", "hybrid_4_3", "hybrid_4_4",
            "hybrid_5_2", "hybrid_5_3", "hybrid_5_4", "hybrid_5_5",
            "hybrid_7_2", "hybrid_7_3", "hybrid_7_4",
            "hybrid_10_2", "hybrid_10_3",
        ],
        "description": "Hybrid: tandem + fork-join + feedback (20 configs)"
    },
    "assembly_rework": {
        "models": [
            "assembly_rework_2", "assembly_rework_3",
            "assembly_rework_5", "assembly_rework_7"
        ],
        "description": "Assembly line with per-stage quality inspection and rework (p=0.2)"
    },
    "emergency_dept": {
        "models": [
            "ed_2", "ed_3",
            "ed_5", "ed_7"
        ],
        "description": "Emergency department with triage, N treatment areas, and readmission (p=0.15)"
    },
    "warehouse": {
        "models": [
            "warehouse"
        ],
        "description": "Warehouse outbound process with 4 arrival streams, 6 stations (real-world model)"
    }
}


def generate_model(topology: str, model_name: str, verbose: bool = True) -> Path:
    """
    Generate SimASM model from Event Graph JSON.

    Args:
        topology: Topology family name (e.g., "split_merge")
        model_name: Model name without _eg suffix (e.g., "split_merge_2")
        verbose: Print progress messages

    Returns:
        Path to generated .simasm file
    """
    json_path = BASE_DIR / topology / "eg" / f"{model_name}_eg.json"
    output_path = BASE_DIR / topology / "generated" / "eg" / f"{model_name}_eg.simasm"

    if not json_path.exists():
        raise FileNotFoundError(f"EG JSON not found: {json_path}")

    if verbose:
        print(f"  Converting: {json_path.name} -> {output_path.name}")

    # Convert JSON to SimASM code
    simasm_code = convert_eg_from_json(str(json_path))

    # Write output file
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(simasm_code)

    if verbose:
        lines = simasm_code.count('\n')
        print(f"    Generated {lines} lines")

    return output_path


def generate_topology_models(topology: str, verbose: bool = True) -> dict:
    """
    Generate all models for a topology.

    Args:
        topology: Topology family name
        verbose: Print progress messages

    Returns:
        dict with generation results
    """
    if topology not in TOPOLOGIES:
        raise ValueError(f"Unknown topology: {topology}. Valid: {list(TOPOLOGIES.keys())}")

    config = TOPOLOGIES[topology]
    results = {"generated": [], "failed": [], "files": []}

    print(f"\n[{topology}] {config['description']}")

    for model_name in config["models"]:
        try:
            output_path = generate_model(topology, model_name, verbose)
            results["generated"].append(model_name)
            results["files"].append(str(output_path))
        except Exception as e:
            results["failed"].append({"model": model_name, "error": str(e)})
            if verbose:
                print(f"    FAILED: {e}")

    return results


def generate_all_models(topologies: list = None, verbose: bool = True) -> dict:
    """
    Generate all held-out models.

    Args:
        topologies: List of topology names (default: all)
        verbose: Print progress messages

    Returns:
        dict with generation results
    """
    if topologies is None:
        topologies = list(TOPOLOGIES.keys())

    all_results = {
        "total_generated": 0,
        "total_failed": 0,
        "by_topology": {}
    }

    print("=" * 70)
    print("  HELD-OUT MODEL GENERATION (HET Validation)")
    print("=" * 70)
    print(f"\nGenerating models for topologies: {topologies}")
    print(f"Output directory: {BASE_DIR}\n")

    for topology in topologies:
        results = generate_topology_models(topology, verbose)
        all_results["by_topology"][topology] = results
        all_results["total_generated"] += len(results["generated"])
        all_results["total_failed"] += len(results["failed"])

    # Summary
    print("\n" + "=" * 70)
    print("  GENERATION COMPLETE")
    print("=" * 70)
    print(f"  Generated: {all_results['total_generated']} models")
    print(f"  Failed: {all_results['total_failed']}")

    for topology, results in all_results["by_topology"].items():
        status = "OK" if not results["failed"] else "PARTIAL"
        print(f"    {topology}: {len(results['generated'])} models [{status}]")

    return all_results


def main():
    """Command-line entry point."""
    parser = argparse.ArgumentParser(
        description="Generate SimASM models from held-out topology JSON specifications"
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Generate all models"
    )
    parser.add_argument(
        "--topology",
        nargs="+",
        choices=list(TOPOLOGIES.keys()),
        help="Specific topologies to generate"
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress verbose output"
    )

    args = parser.parse_args()

    if not args.all and not args.topology:
        parser.print_help()
        print("\nError: Specify --all or --topology <names>")
        sys.exit(1)

    topologies = None if args.all else args.topology
    results = generate_all_models(topologies, verbose=not args.quiet)

    # Exit with error code if any failures
    sys.exit(1 if results["total_failed"] else 0)


if __name__ == "__main__":
    main()
