#!/usr/bin/env python3
"""
run_all_verification.py

Run trace equivalence verification for all topologies:
  - Feedback n-queue (9 models)
  - Fork-join n-queue (9 models)
  - Hybrid n x m (20 models)

Usage:
    python run_all_verification.py --all --end-time 1000.0
    python run_all_verification.py --topology feedback --end-time 100.0
    python run_all_verification.py --topology hybrid --end-time 100.0 --seeds 42,123
"""

import sys
import json
import time
import argparse
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Callable

# Add project root to path
project_root = Path(__file__).parent.parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from simasm.parser.loader import load_file
from simasm.runtime.stepper import ASMStepper, StepperConfig
from simasm.verification.trace import (
    Trace, no_stutter_trace, traces_stutter_equivalent,
    count_stutter_steps
)
from simasm.verification.label import Label, LabelSet, LabelingFunction
from simasm.core.state import Undefined

BASE_DIR = Path(__file__).parent
OUTPUT_BASE = BASE_DIR.parent.parent / "output"

DEFAULT_SEEDS = [42, 123, 456]
NUM_SERVERS = 5


# =============================================================================
# LABELING FUNCTIONS
# =============================================================================

def get_marking(state, queue_obj):
    """Get marking of a queue from state._functions['marking']."""
    marking_func = state._functions.get('marking', {})
    return marking_func.get((queue_obj,), 0)


def make_eg_var_predicate(var_name, op, value):
    """Create a predicate for an EG state variable."""
    def predicate(state) -> bool:
        val = state.get_var(var_name)
        if isinstance(val, Undefined):
            return False
        if op == "==":
            return val == value
        elif op == ">":
            return val > value
        elif op == "<":
            return val < value
        return False
    return predicate


def make_acd_marking_predicate(queue_obj, op, value):
    """Create a predicate for an ACD marking check."""
    def predicate(state) -> bool:
        marking = get_marking(state, queue_obj)
        if op == "==":
            return marking == value
        elif op == ">":
            return marking > value
        elif op == "<":
            return marking < value
        return False
    return predicate


# =============================================================================
# FEEDBACK LABELING
# =============================================================================

def create_feedback_eg_labeling(loaded_model, n: int) -> LabelingFunction:
    labeling = LabelingFunction()
    for i in range(1, n + 1):
        labeling.define(f"queue_{i}_empty", make_eg_var_predicate(f"queue_count_{i}", "==", 0))
        labeling.define(f"queue_{i}_nonempty", make_eg_var_predicate(f"queue_count_{i}", ">", 0))
        labeling.define(f"server_{i}_idle", make_eg_var_predicate(f"server_count_{i}", "==", 0))
        labeling.define(f"server_{i}_busy", make_eg_var_predicate(f"server_count_{i}", ">", 0))
    return labeling


def create_feedback_acd_labeling(loaded_model, n: int) -> LabelingFunction:
    labeling = LabelingFunction()
    state = loaded_model.state
    for i in range(1, n + 1):
        q_obj = state.get_var(f"Q_{i}")
        s_obj = state.get_var(f"S_{i}")
        labeling.define(f"queue_{i}_empty", make_acd_marking_predicate(q_obj, "==", 0))
        labeling.define(f"queue_{i}_nonempty", make_acd_marking_predicate(q_obj, ">", 0))
        labeling.define(f"server_{i}_idle", make_acd_marking_predicate(s_obj, "==", NUM_SERVERS))
        labeling.define(f"server_{i}_busy", make_acd_marking_predicate(s_obj, "<", NUM_SERVERS))
    return labeling


# =============================================================================
# FORK-JOIN LABELING
# =============================================================================

def create_fork_join_eg_labeling(loaded_model, n: int) -> LabelingFunction:
    labeling = LabelingFunction()
    for i in range(1, n + 1):
        labeling.define(f"queue_{i}_empty", make_eg_var_predicate(f"queue_count_{i}", "==", 0))
        labeling.define(f"queue_{i}_nonempty", make_eg_var_predicate(f"queue_count_{i}", ">", 0))
        labeling.define(f"server_{i}_idle", make_eg_var_predicate(f"server_count_{i}", "==", 0))
        labeling.define(f"server_{i}_busy", make_eg_var_predicate(f"server_count_{i}", ">", 0))
        labeling.define(f"part_{i}_empty", make_eg_var_predicate(f"part_{i}_num", "==", 0))
        labeling.define(f"part_{i}_nonempty", make_eg_var_predicate(f"part_{i}_num", ">", 0))
    return labeling


def create_fork_join_acd_labeling(loaded_model, n: int) -> LabelingFunction:
    labeling = LabelingFunction()
    state = loaded_model.state
    for i in range(1, n + 1):
        q_obj = state.get_var(f"Q_{i}")
        s_obj = state.get_var(f"S_{i}")
        p_obj = state.get_var(f"P_{i}")
        labeling.define(f"queue_{i}_empty", make_acd_marking_predicate(q_obj, "==", 0))
        labeling.define(f"queue_{i}_nonempty", make_acd_marking_predicate(q_obj, ">", 0))
        labeling.define(f"server_{i}_idle", make_acd_marking_predicate(s_obj, "==", NUM_SERVERS))
        labeling.define(f"server_{i}_busy", make_acd_marking_predicate(s_obj, "<", NUM_SERVERS))
        labeling.define(f"part_{i}_empty", make_acd_marking_predicate(p_obj, "==", 0))
        labeling.define(f"part_{i}_nonempty", make_acd_marking_predicate(p_obj, ">", 0))
    return labeling


# =============================================================================
# HYBRID LABELING
# =============================================================================

def create_hybrid_eg_labeling(loaded_model, n: int, m: int) -> LabelingFunction:
    labeling = LabelingFunction()
    for i in range(1, n + 1):
        labeling.define(f"queue_{i}_empty", make_eg_var_predicate(f"queue_count_{i}", "==", 0))
        labeling.define(f"queue_{i}_nonempty", make_eg_var_predicate(f"queue_count_{i}", ">", 0))
        labeling.define(f"server_{i}_idle", make_eg_var_predicate(f"server_count_{i}", "==", 0))
        labeling.define(f"server_{i}_busy", make_eg_var_predicate(f"server_count_{i}", ">", 0))
    for j in range(1, m + 1):
        labeling.define(f"branch_queue_{j}_empty", make_eg_var_predicate(f"branch_queue_{j}", "==", 0))
        labeling.define(f"branch_queue_{j}_nonempty", make_eg_var_predicate(f"branch_queue_{j}", ">", 0))
        labeling.define(f"branch_server_{j}_idle", make_eg_var_predicate(f"branch_server_{j}", "==", 0))
        labeling.define(f"branch_server_{j}_busy", make_eg_var_predicate(f"branch_server_{j}", ">", 0))
    return labeling


def create_hybrid_acd_labeling(loaded_model, n: int, m: int) -> LabelingFunction:
    labeling = LabelingFunction()
    state = loaded_model.state
    for i in range(1, n + 1):
        q_obj = state.get_var(f"Q_{i}")
        s_obj = state.get_var(f"S_{i}")
        labeling.define(f"queue_{i}_empty", make_acd_marking_predicate(q_obj, "==", 0))
        labeling.define(f"queue_{i}_nonempty", make_acd_marking_predicate(q_obj, ">", 0))
        labeling.define(f"server_{i}_idle", make_acd_marking_predicate(s_obj, "==", NUM_SERVERS))
        labeling.define(f"server_{i}_busy", make_acd_marking_predicate(s_obj, "<", NUM_SERVERS))
    for j in range(1, m + 1):
        bq_obj = state.get_var(f"BQ_{j}")
        bs_obj = state.get_var(f"BS_{j}")
        labeling.define(f"branch_queue_{j}_empty", make_acd_marking_predicate(bq_obj, "==", 0))
        labeling.define(f"branch_queue_{j}_nonempty", make_acd_marking_predicate(bq_obj, ">", 0))
        labeling.define(f"branch_server_{j}_idle", make_acd_marking_predicate(bs_obj, "==", NUM_SERVERS))
        labeling.define(f"branch_server_{j}_busy", make_acd_marking_predicate(bs_obj, "<", NUM_SERVERS))
    return labeling


# =============================================================================
# TRACE COLLECTION
# =============================================================================

def run_model_trace(model_path, model_name, labeling_factory, seed, end_time, **factory_kwargs):
    """Run a model and collect its trace.

    Uses end-of-tick labeling: labels are captured for the LAST state at each
    clock time (just before the clock advances to the next time). This ensures
    both EG and ACD models report the same observable state after all processing
    at a given simulation time is complete, abstracting over formalism-specific
    sub-step ordering within the same clock tick.
    """
    load_start = time.time()
    loaded = load_file(model_path, seed=seed)
    labeling = labeling_factory(loaded, **factory_kwargs)
    main_rule = loaded.rules.get(loaded.main_rule_name)
    config = StepperConfig(time_var="sim_clocktime", end_time=end_time)
    stepper = ASMStepper(
        state=loaded.state,
        main_rule=main_rule,
        rule_evaluator=loaded.rule_evaluator,
        config=config,
    )
    load_time = time.time() - load_start

    trace = Trace()
    exec_start = time.time()
    initial_labels = labeling.evaluate(loaded.state)
    trace.append(initial_labels)

    step = 0
    prev_time = loaded.state.get_var("sim_clocktime") or 0.0
    last_labels = initial_labels
    while stepper.can_step():
        stepper.step()
        step += 1
        curr_time = loaded.state.get_var("sim_clocktime") or 0.0
        if curr_time != prev_time:
            # Clock advanced: capture the LAST state of the previous tick
            trace.append(last_labels)
            prev_time = curr_time
        last_labels = labeling.evaluate(loaded.state)

    # Do NOT append final labels: the final tick may be incompletely processed
    # (EG and ACD stop at different sub-steps within the tick that crosses
    # sim_end_time). The trace already contains end-of-tick labels for all
    # complete ticks via the clock-change detection above.

    exec_time = time.time() - exec_start
    final_time = loaded.state.get_var("sim_clocktime") or 0.0

    return trace, step, final_time, load_time, exec_time


def verify_pair(eg_path, acd_path, eg_labeling_factory, acd_labeling_factory,
                seed, end_time, **factory_kwargs):
    """Verify stutter equivalence for a single model pair."""
    pair_start = time.time()

    trace_eg, steps_eg, time_eg, lt_eg, et_eg = run_model_trace(
        str(eg_path), "EG", eg_labeling_factory, seed, end_time, **factory_kwargs)
    trace_acd, steps_acd, time_acd, lt_acd, et_acd = run_model_trace(
        str(acd_path), "ACD", acd_labeling_factory, seed, end_time, **factory_kwargs)

    ns_eg = no_stutter_trace(trace_eg)
    ns_acd = no_stutter_trace(trace_acd)
    is_equivalent = traces_stutter_equivalent(trace_eg, trace_acd)

    pair_total = time.time() - pair_start

    return {
        "seed": seed,
        "is_equivalent": is_equivalent,
        "timing": {
            "eg_load_sec": lt_eg, "eg_exec_sec": et_eg,
            "acd_load_sec": lt_acd, "acd_exec_sec": et_acd,
            "pair_total_sec": pair_total
        },
        "eg": {
            "raw_trace_length": len(trace_eg),
            "no_stutter_length": len(ns_eg),
            "stutter_steps": count_stutter_steps(trace_eg),
            "simulation_steps": steps_eg,
            "final_time": time_eg
        },
        "acd": {
            "raw_trace_length": len(trace_acd),
            "no_stutter_length": len(ns_acd),
            "stutter_steps": count_stutter_steps(trace_acd),
            "simulation_steps": steps_acd,
            "final_time": time_acd
        }
    }


# =============================================================================
# VERIFICATION RUNNERS
# =============================================================================

def run_feedback_verification(seeds, end_time, output_dir):
    """Run verification for all feedback models."""
    n_values = [1, 2, 3, 4, 5, 7, 10, 15, 20]
    fb_dir = BASE_DIR / "feedback_n_queue"
    results = {}
    total, equiv, failed = 0, 0, 0

    for n in n_values:
        eg_path = fb_dir / "generated" / "eg" / f"feedback_{n}_eg.simasm"
        acd_path = fb_dir / "generated" / "acd" / f"feedback_{n}_acd.simasm"

        if not eg_path.exists() or not acd_path.exists():
            print(f"  SKIP feedback_{n} (files missing)")
            continue

        model_key = f"feedback_{n}"
        model_result = {"is_equivalent": True, "seed_results": [], "failed_seeds": []}

        for i, seed in enumerate(seeds):
            print(f"  [{model_key}] seed={seed}...", end="", flush=True)
            try:
                result = verify_pair(
                    eg_path, acd_path,
                    create_feedback_eg_labeling, create_feedback_acd_labeling,
                    seed, end_time, n=n)
                model_result["seed_results"].append(result)
                total += 1
                if result["is_equivalent"]:
                    equiv += 1
                    print(f" EQUIVALENT (EG:{result['eg']['no_stutter_length']} ACD:{result['acd']['no_stutter_length']}) [{result['timing']['pair_total_sec']:.1f}s]")
                else:
                    failed += 1
                    model_result["is_equivalent"] = False
                    model_result["failed_seeds"].append(seed)
                    print(f" NOT EQUIVALENT [{result['timing']['pair_total_sec']:.1f}s]")
            except Exception as e:
                print(f" ERROR: {e}")
                model_result["seed_results"].append({"seed": seed, "error": str(e), "is_equivalent": False})
                model_result["is_equivalent"] = False
                model_result["failed_seeds"].append(seed)
                total += 1
                failed += 1

        results[model_key] = model_result

    return results, total, equiv, failed


def run_fork_join_verification(seeds, end_time, output_dir):
    """Run verification for all fork-join models."""
    n_values = [1, 2, 3, 4, 5, 7, 10, 15, 20]
    fj_dir = BASE_DIR / "fork_join_n_queue"
    results = {}
    total, equiv, failed = 0, 0, 0

    for n in n_values:
        eg_path = fj_dir / "generated" / "eg" / f"fork_join_{n}_eg.simasm"
        acd_path = fj_dir / "generated" / "acd" / f"fork_join_{n}_acd.simasm"

        if not eg_path.exists() or not acd_path.exists():
            print(f"  SKIP fork_join_{n} (files missing)")
            continue

        model_key = f"fork_join_{n}"
        model_result = {"is_equivalent": True, "seed_results": [], "failed_seeds": []}

        for i, seed in enumerate(seeds):
            print(f"  [{model_key}] seed={seed}...", end="", flush=True)
            try:
                result = verify_pair(
                    eg_path, acd_path,
                    create_fork_join_eg_labeling, create_fork_join_acd_labeling,
                    seed, end_time, n=n)
                model_result["seed_results"].append(result)
                total += 1
                if result["is_equivalent"]:
                    equiv += 1
                    print(f" EQUIVALENT (EG:{result['eg']['no_stutter_length']} ACD:{result['acd']['no_stutter_length']}) [{result['timing']['pair_total_sec']:.1f}s]")
                else:
                    failed += 1
                    model_result["is_equivalent"] = False
                    model_result["failed_seeds"].append(seed)
                    print(f" NOT EQUIVALENT [{result['timing']['pair_total_sec']:.1f}s]")
            except Exception as e:
                print(f" ERROR: {e}")
                model_result["seed_results"].append({"seed": seed, "error": str(e), "is_equivalent": False})
                model_result["is_equivalent"] = False
                model_result["failed_seeds"].append(seed)
                total += 1
                failed += 1

        results[model_key] = model_result

    return results, total, equiv, failed


def run_hybrid_verification(seeds, end_time, output_dir):
    """Run verification for all hybrid models."""
    configs = [
        (1, 2), (1, 3), (2, 2), (2, 3), (2, 4),
        (3, 2), (3, 3), (3, 4), (4, 2), (4, 3),
        (4, 4), (5, 2), (5, 3), (5, 4), (5, 5),
        (7, 2), (7, 3), (7, 4), (10, 2), (10, 3),
    ]
    hy_dir = BASE_DIR / "held_out" / "hybrid"
    results = {}
    total, equiv, failed = 0, 0, 0

    for n, m in configs:
        eg_path = hy_dir / "generated" / "eg" / f"hybrid_{n}_{m}_eg.simasm"
        acd_path = hy_dir / "generated" / "acd" / f"hybrid_{n}_{m}_acd.simasm"

        if not eg_path.exists() or not acd_path.exists():
            print(f"  SKIP hybrid_{n}_{m} (files missing)")
            continue

        model_key = f"hybrid_{n}_{m}"
        model_result = {"is_equivalent": True, "seed_results": [], "failed_seeds": []}

        for i, seed in enumerate(seeds):
            print(f"  [{model_key}] seed={seed}...", end="", flush=True)
            try:
                result = verify_pair(
                    eg_path, acd_path,
                    lambda loaded, n=n, m=m: create_hybrid_eg_labeling(loaded, n, m),
                    lambda loaded, n=n, m=m: create_hybrid_acd_labeling(loaded, n, m),
                    seed, end_time)
                model_result["seed_results"].append(result)
                total += 1
                if result["is_equivalent"]:
                    equiv += 1
                    print(f" EQUIVALENT (EG:{result['eg']['no_stutter_length']} ACD:{result['acd']['no_stutter_length']}) [{result['timing']['pair_total_sec']:.1f}s]")
                else:
                    failed += 1
                    model_result["is_equivalent"] = False
                    model_result["failed_seeds"].append(seed)
                    print(f" NOT EQUIVALENT [{result['timing']['pair_total_sec']:.1f}s]")
            except Exception as e:
                print(f" ERROR: {e}")
                model_result["seed_results"].append({"seed": seed, "error": str(e), "is_equivalent": False})
                model_result["is_equivalent"] = False
                model_result["failed_seeds"].append(seed)
                total += 1
                failed += 1

        results[model_key] = model_result

    return results, total, equiv, failed


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser(description="Run trace equivalence verification for all topologies")
    parser.add_argument("--all", action="store_true", help="Run all topologies")
    parser.add_argument("--topology", choices=["feedback", "fork_join", "hybrid"], help="Run specific topology")
    parser.add_argument("--end-time", type=float, default=1000.0, help="Simulation end time")
    parser.add_argument("--seeds", type=str, default="42,123,456", help="Comma-separated seeds")

    args = parser.parse_args()

    if not args.all and not args.topology:
        parser.print_help()
        print("\nError: Specify --all or --topology")
        sys.exit(1)

    seeds = [int(s) for s in args.seeds.split(",")]
    end_time = args.end_time
    topologies = ["feedback", "fork_join", "hybrid"] if args.all else [args.topology]

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = OUTPUT_BASE / "verification" / timestamp
    output_dir.mkdir(parents=True, exist_ok=True)

    suite_start = time.time()

    print("=" * 70)
    print("  ALL-TOPOLOGY STUTTER EQUIVALENCE VERIFICATION")
    print("=" * 70)
    print(f"  Topologies: {topologies}")
    print(f"  Seeds: {seeds}")
    print(f"  End time: {end_time}")
    print(f"  Output: {output_dir}")

    all_results = {"timestamp": timestamp, "seeds": seeds, "end_time": end_time, "topologies": {}}
    grand_total, grand_equiv, grand_failed = 0, 0, 0

    if "feedback" in topologies:
        print(f"\n{'='*70}")
        print("  FEEDBACK VERIFICATION")
        print(f"{'='*70}")
        fb_results, t, e, f_ = run_feedback_verification(seeds, end_time, output_dir)
        all_results["topologies"]["feedback"] = fb_results
        grand_total += t; grand_equiv += e; grand_failed += f_

    if "fork_join" in topologies:
        print(f"\n{'='*70}")
        print("  FORK-JOIN VERIFICATION")
        print(f"{'='*70}")
        fj_results, t, e, f_ = run_fork_join_verification(seeds, end_time, output_dir)
        all_results["topologies"]["fork_join"] = fj_results
        grand_total += t; grand_equiv += e; grand_failed += f_

    if "hybrid" in topologies:
        print(f"\n{'='*70}")
        print("  HYBRID VERIFICATION")
        print(f"{'='*70}")
        hy_results, t, e, f_ = run_hybrid_verification(seeds, end_time, output_dir)
        all_results["topologies"]["hybrid"] = hy_results
        grand_total += t; grand_equiv += e; grand_failed += f_

    total_wall = time.time() - suite_start

    all_results["summary"] = {
        "total_pairs": grand_total,
        "equivalent": grand_equiv,
        "failed": grand_failed,
        "all_equivalent": grand_failed == 0,
        "total_wall_time_sec": total_wall
    }

    summary_path = output_dir / "all_results.json"
    with open(summary_path, "w") as f_:
        json.dump(all_results, f_, indent=2, default=str)

    print(f"\n{'='*70}")
    print("  GRAND SUMMARY")
    print(f"{'='*70}")
    print(f"  Total pairs: {grand_total}")
    print(f"  Equivalent:  {grand_equiv}")
    print(f"  Failed:      {grand_failed}")
    print(f"  Wall time:   {total_wall:.1f}s")
    print(f"  Results:     {summary_path}")

    if grand_failed == 0:
        print("\n  ALL MODELS STUTTER EQUIVALENT!")
    else:
        print(f"\n  {grand_failed} verification(s) FAILED")

    sys.exit(1 if grand_failed > 0 else 0)


if __name__ == "__main__":
    main()
