#!/usr/bin/env python3
"""
generate_tandem_asm.py

Generate SimASM models from tandem n-queue JSON specifications.

Usage:
    python generate_tandem_asm.py --all              # Generate all models (n=1,3,5,10,20)
    python generate_tandem_asm.py --n 1              # Generate only n=1 models
    python generate_tandem_asm.py --n 1 3 5          # Generate specific models
"""

import sys
import argparse
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from simasm.converter import convert_eg_from_json

# Import ACD schema_x for extended format support (duration, produce, actions)
from simasm.converter.acd.schema_x import load_acd_from_json as load_acd_spec


def convert_acd_from_json_extended(json_path: str) -> str:
    """
    Load ACD JSON with extended format and convert to SimASM code.

    Uses schema_x which supports the format with:
    - duration field (instead of bto_event)
    - produce/actions in at_end (instead of action string)
    """
    # Import here to avoid circular dependency issues
    import sys

    # Temporarily patch schema import for converter_x
    from simasm.converter.acd import schema_x
    sys.modules['simasm.converter.acd.schema'] = schema_x

    try:
        # Now import converter_x which will use schema_x
        from importlib import reload
        import simasm.converter.acd.converter_x as converter_x
        reload(converter_x)

        spec = load_acd_spec(json_path)
        return converter_x.convert_acd(spec)
    finally:
        # Restore original schema
        from simasm.converter.acd import schema
        sys.modules['simasm.converter.acd.schema'] = schema


# Base directory
BASE_DIR = Path(__file__).parent

# Supported n values
SUPPORTED_N_VALUES = [1, 3, 5, 10, 20]


def generate_eg_model(n: int, verbose: bool = True) -> Path:
    """
    Generate Event Graph ASM model for tandem n-queue.

    Args:
        n: Number of stations in tandem queue
        verbose: Print progress messages

    Returns:
        Path to generated .simasm file
    """
    json_path = BASE_DIR / "eg" / f"tandem_{n}_eg.json"
    output_path = BASE_DIR / "generated" / "eg" / f"tandem_{n}_eg.simasm"

    if not json_path.exists():
        raise FileNotFoundError(f"EG JSON not found: {json_path}")

    if verbose:
        print(f"  Converting EG: {json_path.name} -> {output_path.name}")

    # Convert JSON to SimASM code
    simasm_code = convert_eg_from_json(str(json_path))

    # Write output file
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(simasm_code)

    if verbose:
        lines = simasm_code.count('\n')
        print(f"    Generated {lines} lines")

    return output_path


def generate_acd_model(n: int, verbose: bool = True) -> Path:
    """
    Generate Activity Cycle Diagram ASM model for tandem n-queue.

    Args:
        n: Number of stations in tandem queue
        verbose: Print progress messages

    Returns:
        Path to generated .simasm file
    """
    json_path = BASE_DIR / "acd" / f"tandem_{n}_acd.json"
    output_path = BASE_DIR / "generated" / "acd" / f"tandem_{n}_acd.simasm"

    if not json_path.exists():
        raise FileNotFoundError(f"ACD JSON not found: {json_path}")

    if verbose:
        print(f"  Converting ACD: {json_path.name} -> {output_path.name}")

    # Convert JSON to SimASM code using extended format support
    simasm_code = convert_acd_from_json_extended(str(json_path))

    # Write output file
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(simasm_code)

    if verbose:
        lines = simasm_code.count('\n')
        print(f"    Generated {lines} lines")

    return output_path


def generate_all_models(n_values: list = None, verbose: bool = True) -> dict:
    """
    Generate all EG and ACD models for specified n values.

    Args:
        n_values: List of n values to generate (default: all supported)
        verbose: Print progress messages

    Returns:
        dict with generation results
    """
    if n_values is None:
        n_values = SUPPORTED_N_VALUES

    results = {
        "generated": [],
        "failed": [],
        "eg_files": [],
        "acd_files": []
    }

    print("=" * 70)
    print("  TANDEM N-QUEUE ASM MODEL GENERATION")
    print("=" * 70)
    print(f"\nGenerating models for n = {n_values}")
    print(f"Output directory: {BASE_DIR / 'generated'}\n")

    for n in n_values:
        print(f"\n[n={n}] Generating tandem {n}-queue models...")

        try:
            # Generate EG model
            eg_path = generate_eg_model(n, verbose)
            results["eg_files"].append(str(eg_path))

            # Generate ACD model
            acd_path = generate_acd_model(n, verbose)
            results["acd_files"].append(str(acd_path))

            results["generated"].append(n)
            print(f"    SUCCESS")

        except Exception as e:
            results["failed"].append({"n": n, "error": str(e)})
            print(f"    FAILED: {e}")

    # Summary
    print("\n" + "=" * 70)
    print(f"  GENERATION COMPLETE")
    print("=" * 70)
    print(f"  Generated: {len(results['generated'])} model pairs")
    print(f"  Failed: {len(results['failed'])}")

    if results["generated"]:
        print(f"\n  EG models: {BASE_DIR / 'generated' / 'eg'}")
        print(f"  ACD models: {BASE_DIR / 'generated' / 'acd'}")

    if results["failed"]:
        print(f"\n  Failed models:")
        for fail in results["failed"]:
            print(f"    n={fail['n']}: {fail['error']}")

    return results


def main():
    """Command-line entry point."""
    parser = argparse.ArgumentParser(
        description="Generate SimASM models from tandem n-queue JSON specifications"
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Generate all models (n=1,3,5,10,20)"
    )
    parser.add_argument(
        "--n",
        type=int,
        nargs="+",
        help="Specific n values to generate"
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress verbose output"
    )

    args = parser.parse_args()

    if not args.all and not args.n:
        parser.print_help()
        print("\nError: Specify --all or --n <values>")
        sys.exit(1)

    if args.all:
        n_values = SUPPORTED_N_VALUES
    else:
        # Validate n values
        invalid = [n for n in args.n if n not in SUPPORTED_N_VALUES]
        if invalid:
            print(f"Error: Invalid n values: {invalid}")
            print(f"Supported values: {SUPPORTED_N_VALUES}")
            sys.exit(1)
        n_values = args.n

    results = generate_all_models(n_values, verbose=not args.quiet)

    # Exit with error code if any failures
    sys.exit(1 if results["failed"] else 0)


if __name__ == "__main__":
    main()
