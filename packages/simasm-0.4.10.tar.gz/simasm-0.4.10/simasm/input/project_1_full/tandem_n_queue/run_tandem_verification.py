#!/usr/bin/env python3
"""
run_tandem_verification.py

Run trace equivalence verification for tandem n-queue EG vs ACD models.

This script:
1. Loads generated .simasm models for both EG and ACD
2. Runs them with the same random seed
3. Collects traces using labeling functions
4. Verifies stutter equivalence between traces
5. Reports results

Usage:
    python run_tandem_verification.py --n 1 --end-time 100.0 --seed 42
    python run_tandem_verification.py --all --end-time 1000.0 --seeds 42,123,456
"""

import sys
import json
import time
import argparse
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Callable

# Add project root to path
project_root = Path(__file__).parent.parent.parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from simasm.parser.loader import load_file
from simasm.runtime.stepper import ASMStepper, StepperConfig
from simasm.verification.trace import (
    Trace, no_stutter_trace, traces_stutter_equivalent,
    count_stutter_steps
)
from simasm.verification.label import Label, LabelSet, LabelingFunction
from simasm.core.state import Undefined


# Base directory
BASE_DIR = Path(__file__).parent
OUTPUT_BASE = BASE_DIR.parent.parent.parent / "output" / "tandem_n_queue"

# Supported n values
SUPPORTED_N_VALUES = [1, 3, 5, 10, 20]

# Default seeds for verification
DEFAULT_SEEDS = [42, 123, 456]


def create_eg_labeling_function(loaded_model, n: int) -> LabelingFunction:
    """
    Create labeling function for Event Graph model.

    Labels are defined based on queue_count_i and server_count_i state variables.

    Args:
        loaded_model: Loaded EG model
        n: Number of stations

    Returns:
        LabelingFunction for the EG model
    """
    labeling = LabelingFunction()

    for i in range(1, n + 1):
        queue_var = f"queue_count_{i}"
        server_var = f"server_count_{i}"

        # Queue empty/nonempty labels
        def make_queue_empty(var_name):
            def predicate(state) -> bool:
                val = state.get_var(var_name)
                if isinstance(val, Undefined):
                    return False
                return val == 0
            return predicate

        def make_queue_nonempty(var_name):
            def predicate(state) -> bool:
                val = state.get_var(var_name)
                if isinstance(val, Undefined):
                    return False
                return val > 0
            return predicate

        def make_server_idle(var_name):
            def predicate(state) -> bool:
                val = state.get_var(var_name)
                if isinstance(val, Undefined):
                    return False
                return val == 0
            return predicate

        def make_server_busy(var_name):
            def predicate(state) -> bool:
                val = state.get_var(var_name)
                if isinstance(val, Undefined):
                    return False
                return val > 0
            return predicate

        labeling.define(f"queue_{i}_empty", make_queue_empty(queue_var))
        labeling.define(f"queue_{i}_nonempty", make_queue_nonempty(queue_var))
        labeling.define(f"server_{i}_idle", make_server_idle(server_var))
        labeling.define(f"server_{i}_busy", make_server_busy(server_var))

    return labeling


def create_acd_labeling_function(loaded_model, n: int, num_servers: int = 5) -> LabelingFunction:
    """
    Create labeling function for ACD model.

    Labels are defined based on marking(Q_i) and marking(S_i).
    Note: In ACD, marking(S_i) is the number of IDLE servers,
    so busy servers = num_servers - marking(S_i).

    Args:
        loaded_model: Loaded ACD model
        n: Number of stations
        num_servers: Number of servers per station

    Returns:
        LabelingFunction for the ACD model
    """
    labeling = LabelingFunction()
    initial_state = loaded_model.state

    # Pre-fetch the queue objects from the initial state
    # These objects are constants and won't change
    queue_objects = {}
    server_queue_objects = {}

    for i in range(1, n + 1):
        queue_objects[i] = initial_state.get_var(f"Q_{i}")
        server_queue_objects[i] = initial_state.get_var(f"S_{i}")

    def get_marking(state, queue_obj):
        """Get marking of a queue from state._functions['marking']."""
        marking_func = state._functions.get('marking', {})
        return marking_func.get((queue_obj,), 0)

    for i in range(1, n + 1):
        q_obj = queue_objects[i]
        s_obj = server_queue_objects[i]

        def make_queue_empty(queue_obj):
            def predicate(state) -> bool:
                marking = get_marking(state, queue_obj)
                return marking == 0
            return predicate

        def make_queue_nonempty(queue_obj):
            def predicate(state) -> bool:
                marking = get_marking(state, queue_obj)
                return marking > 0
            return predicate

        def make_server_idle(server_queue_obj, num_srv):
            def predicate(state) -> bool:
                # Server idle means all servers are available in S_i
                # All servers idle means marking(S_i) == num_servers
                marking = get_marking(state, server_queue_obj)
                return marking == num_srv
            return predicate

        def make_server_busy(server_queue_obj, num_srv):
            def predicate(state) -> bool:
                # Servers busy when marking(S_i) < num_servers
                marking = get_marking(state, server_queue_obj)
                return marking < num_srv
            return predicate

        labeling.define(f"queue_{i}_empty", make_queue_empty(q_obj))
        labeling.define(f"queue_{i}_nonempty", make_queue_nonempty(q_obj))
        labeling.define(f"server_{i}_idle", make_server_idle(s_obj, num_servers))
        labeling.define(f"server_{i}_busy", make_server_busy(s_obj, num_servers))

    return labeling


def run_model_trace(
    model_path: str,
    model_name: str,
    labeling_factory: Callable,
    n: int,
    seed: int,
    end_time: float,
    verbose: bool = False
) -> Tuple[Trace, int, float, float, float]:
    """
    Run a model and collect its trace.

    Args:
        model_path: Path to the .simasm model file
        model_name: Name of the model for logging
        labeling_factory: Factory function to create labeling function
        n: Number of stations
        seed: Random seed
        end_time: Simulation end time
        verbose: Print detailed output

    Returns:
        tuple: (Trace, step_count, final_time, load_time_sec, exec_time_sec)
    """
    if verbose:
        print(f"    Loading {model_name}...")

    # Measure load time
    load_start = time.time()

    # Load the model
    loaded = load_file(model_path, seed=seed)

    # Create labeling function
    labeling = labeling_factory(loaded, n)

    # Get main rule
    main_rule = loaded.rules.get(loaded.main_rule_name)

    # Create stepper
    config = StepperConfig(
        time_var="sim_clocktime",
        end_time=end_time,
    )
    stepper = ASMStepper(
        state=loaded.state,
        main_rule=main_rule,
        rule_evaluator=loaded.rule_evaluator,
        config=config,
    )

    load_time = time.time() - load_start

    # Collect trace
    trace = Trace()

    # Measure execution time
    exec_start = time.time()

    # Record initial state for both models.
    # Both EG and ACD now start with empty Q_1 (initial_tokens=0).
    initial_labels = labeling.evaluate(loaded.state)
    trace.append(initial_labels)

    # Run and collect
    step = 0
    while stepper.can_step():
        stepper.step()
        step += 1

        labels = labeling.evaluate(loaded.state)
        trace.append(labels)

    exec_time = time.time() - exec_start

    final_time = loaded.state.get_var("sim_clocktime") or 0.0

    if verbose:
        print(f"      Completed: {step} steps, time {final_time:.4f}, load={load_time:.3f}s, exec={exec_time:.3f}s")

    return trace, step, final_time, load_time, exec_time


def verify_single_model(
    n: int,
    seed: int,
    end_time: float,
    verbose: bool = False
) -> dict:
    """
    Verify stutter equivalence for a single tandem n-queue model pair.

    Args:
        n: Number of stations
        seed: Random seed
        end_time: Simulation end time
        verbose: Print detailed output

    Returns:
        dict with verification result
    """
    pair_start = time.time()

    eg_path = BASE_DIR / "generated" / "eg" / f"tandem_{n}_eg.simasm"
    acd_path = BASE_DIR / "generated" / "acd" / f"tandem_{n}_acd.simasm"

    if not eg_path.exists():
        raise FileNotFoundError(f"EG model not found: {eg_path}")
    if not acd_path.exists():
        raise FileNotFoundError(f"ACD model not found: {acd_path}")

    # Run EG model
    trace_eg, steps_eg, time_eg, load_time_eg, exec_time_eg = run_model_trace(
        str(eg_path), "EG", create_eg_labeling_function, n, seed, end_time, verbose
    )

    # Run ACD model
    trace_acd, steps_acd, time_acd, load_time_acd, exec_time_acd = run_model_trace(
        str(acd_path), "ACD", create_acd_labeling_function, n, seed, end_time, verbose
    )

    # Compute no-stutter traces
    ns_eg = no_stutter_trace(trace_eg)
    ns_acd = no_stutter_trace(trace_acd)

    # Check equivalence
    is_equivalent = traces_stutter_equivalent(trace_eg, trace_acd)

    pair_total = time.time() - pair_start

    return {
        "n": n,
        "seed": seed,
        "end_time": end_time,
        "is_equivalent": is_equivalent,
        "timing": {
            "eg_load_sec": load_time_eg,
            "eg_exec_sec": exec_time_eg,
            "acd_load_sec": load_time_acd,
            "acd_exec_sec": exec_time_acd,
            "pair_total_sec": pair_total
        },
        "eg": {
            "raw_trace_length": len(trace_eg),
            "no_stutter_length": len(ns_eg),
            "stutter_steps": count_stutter_steps(trace_eg),
            "simulation_steps": steps_eg,
            "final_time": time_eg,
            "load_time_sec": load_time_eg,
            "execution_time_sec": exec_time_eg
        },
        "acd": {
            "raw_trace_length": len(trace_acd),
            "no_stutter_length": len(ns_acd),
            "stutter_steps": count_stutter_steps(trace_acd),
            "simulation_steps": steps_acd,
            "final_time": time_acd,
            "load_time_sec": load_time_acd,
            "execution_time_sec": exec_time_acd
        },
        "ns_trace_eg": ns_eg,
        "ns_trace_acd": ns_acd
    }


def verify_model_multi_seed(
    n: int,
    seeds: List[int],
    end_time: float,
    verbose: bool = False
) -> dict:
    """
    Verify stutter equivalence for a model with multiple seeds.

    Args:
        n: Number of stations
        seeds: List of random seeds
        end_time: Simulation end time
        verbose: Print detailed output

    Returns:
        dict with verification results for all seeds
    """
    results = {
        "n": n,
        "seeds": seeds,
        "end_time": end_time,
        "seed_results": [],
        "all_equivalent": True,
        "failed_seeds": []
    }

    for seed in seeds:
        try:
            result = verify_single_model(n, seed, end_time, verbose)
            results["seed_results"].append(result)

            if not result["is_equivalent"]:
                results["all_equivalent"] = False
                results["failed_seeds"].append(seed)

        except Exception as e:
            results["seed_results"].append({
                "n": n,
                "seed": seed,
                "error": str(e),
                "is_equivalent": False
            })
            results["all_equivalent"] = False
            results["failed_seeds"].append(seed)

    return results


def run_verification(
    n_values: List[int],
    seeds: List[int],
    end_time: float,
    verbose: bool = True
) -> dict:
    """
    Run full verification suite for specified models.

    Args:
        n_values: List of n values to verify
        seeds: List of random seeds
        end_time: Simulation end time
        verbose: Print progress

    Returns:
        dict with full verification results
    """
    suite_start = time.time()

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = OUTPUT_BASE / timestamp
    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("  TANDEM N-QUEUE STUTTER EQUIVALENCE VERIFICATION")
    print("=" * 70)
    print(f"\nModels: n = {n_values}")
    print(f"Seeds: {seeds}")
    print(f"End time: {end_time}")
    print(f"Output: {output_dir}")

    all_results = {
        "verification": "tandem_n_queue",
        "timestamp": timestamp,
        "n_values": n_values,
        "seeds": seeds,
        "end_time": end_time,
        "models": {}
    }

    total_pairs = 0
    equivalent_pairs = 0
    failed_pairs = 0

    for n in n_values:
        print(f"\n{'='*70}")
        print(f"  Verifying tandem_{n} (n={n})")
        print(f"{'='*70}")

        model_result = {
            "is_equivalent": True,
            "seed_results": [],
            "failed_seeds": []
        }

        for i, seed in enumerate(seeds):
            print(f"\n  [{i+1}/{len(seeds)}] Seed {seed}...", end="", flush=True)

            try:
                result = verify_single_model(n, seed, end_time, verbose=False)

                # Print summary with timing
                timing = result["timing"]
                if result["is_equivalent"]:
                    print(f" EQUIVALENT (EG: {result['eg']['no_stutter_length']} ns-steps, ACD: {result['acd']['no_stutter_length']} ns-steps) [{timing['pair_total_sec']:.3f}s]")
                else:
                    print(f" NOT EQUIVALENT [{timing['pair_total_sec']:.3f}s]")
                    model_result["is_equivalent"] = False
                    model_result["failed_seeds"].append(seed)
                    failed_pairs += 1

                # Store result (without large trace objects for JSON)
                seed_result = {
                    "seed": seed,
                    "is_equivalent": result["is_equivalent"],
                    "timing": result["timing"],
                    "eg": result["eg"],
                    "acd": result["acd"]
                }
                model_result["seed_results"].append(seed_result)
                total_pairs += 1

                if result["is_equivalent"]:
                    equivalent_pairs += 1

            except Exception as e:
                print(f" ERROR: {e}")
                model_result["seed_results"].append({
                    "seed": seed,
                    "error": str(e),
                    "is_equivalent": False
                })
                model_result["is_equivalent"] = False
                model_result["failed_seeds"].append(seed)
                total_pairs += 1
                failed_pairs += 1

        # Summary for this model
        if model_result["is_equivalent"]:
            print(f"\n  RESULT: tandem_{n} is STUTTER EQUIVALENT across all seeds")
        else:
            print(f"\n  RESULT: tandem_{n} is NOT EQUIVALENT (failed seeds: {model_result['failed_seeds']})")

        all_results["models"][f"tandem_{n}"] = model_result

        # Write individual model results
        model_output = output_dir / f"tandem_{n}_results.json"
        with open(model_output, "w") as f:
            json.dump(model_result, f, indent=2)

    total_wall_time = time.time() - suite_start

    # Summary
    all_results["summary"] = {
        "total": total_pairs,
        "equivalent": equivalent_pairs,
        "failed": failed_pairs,
        "all_models_equivalent": failed_pairs == 0,
        "total_wall_time_sec": total_wall_time
    }

    # Write summary
    summary_path = output_dir / "summary.json"
    with open(summary_path, "w") as f:
        json.dump(all_results, f, indent=2)

    print("\n" + "=" * 70)
    print("  VERIFICATION SUMMARY")
    print("=" * 70)
    print(f"  Total model-seed pairs: {total_pairs}")
    print(f"  Equivalent: {equivalent_pairs}")
    print(f"  Failed: {failed_pairs}")
    print(f"  Total wall time: {total_wall_time:.3f}s")
    print(f"\n  Results written to: {output_dir}")

    if failed_pairs == 0:
        print("\n  ALL MODELS STUTTER EQUIVALENT!")
    else:
        print(f"\n  {failed_pairs} verification(s) FAILED")
        for model_name, model_result in all_results["models"].items():
            if model_result["failed_seeds"]:
                print(f"    {model_name}: failed seeds {model_result['failed_seeds']}")

    return all_results


def main():
    """Command-line entry point."""
    parser = argparse.ArgumentParser(
        description="Run trace equivalence verification for tandem n-queue models"
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Verify all models (n=1,3,5,10,20)"
    )
    parser.add_argument(
        "--n",
        type=int,
        nargs="+",
        help="Specific n values to verify"
    )
    parser.add_argument(
        "--end-time",
        type=float,
        default=1000.0,
        help="Simulation end time (default: 1000.0)"
    )
    parser.add_argument(
        "--seed",
        type=int,
        help="Single random seed to use"
    )
    parser.add_argument(
        "--seeds",
        type=str,
        help="Comma-separated list of seeds (e.g., 42,123,456)"
    )
    parser.add_argument(
        "--seed-range",
        nargs=2,
        type=int,
        metavar=("START", "END"),
        help="Range of seeds (inclusive), e.g., --seed-range 1 50"
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Print detailed output"
    )

    args = parser.parse_args()

    # Determine n values
    if args.all:
        n_values = SUPPORTED_N_VALUES
    elif args.n:
        invalid = [n for n in args.n if n not in SUPPORTED_N_VALUES]
        if invalid:
            print(f"Error: Invalid n values: {invalid}")
            print(f"Supported values: {SUPPORTED_N_VALUES}")
            sys.exit(1)
        n_values = args.n
    else:
        parser.print_help()
        print("\nError: Specify --all or --n <values>")
        sys.exit(1)

    # Determine seeds
    if args.seed:
        seeds = [args.seed]
    elif args.seed_range:
        seeds = list(range(args.seed_range[0], args.seed_range[1] + 1))
    elif args.seeds:
        seeds = [int(s.strip()) for s in args.seeds.split(",")]
    else:
        seeds = DEFAULT_SEEDS

    # Run verification
    results = run_verification(n_values, seeds, args.end_time, verbose=args.verbose)

    # Exit code
    sys.exit(0 if results["summary"]["failed"] == 0 else 1)


if __name__ == "__main__":
    main()
