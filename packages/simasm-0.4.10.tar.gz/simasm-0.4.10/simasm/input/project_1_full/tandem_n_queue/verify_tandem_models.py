"""
Verification script for tandem n-queue JSON configuration files.

Validates:
1. JSON syntax and schema compliance
2. Structural consistency between EG and ACD models
3. Flow correctness (stations 1→2→...→n)
4. Queue/server naming consistency
5. Parameter value matching
6. Observable alignment for trace equivalence
"""

import json
import sys
from pathlib import Path
from typing import Dict, List, Tuple, Any

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from simasm.converter.acd.schema_x import parse_pure_acd_json, ACDSpec
from simasm.converter.event_graph.schema import parse_eg_json, EventGraphSpec


def load_json(filepath: Path) -> Dict[str, Any]:
    """Load JSON file and return dict."""
    with open(filepath) as f:
        return json.load(f)


def verify_eg_structure(data: Dict, n: int) -> List[str]:
    """Verify Event Graph structure for n-station tandem queue."""
    errors = []

    # Expected vertices: Arrive, Start_1..Start_n, Finish_1..Finish_n
    expected_vertices = {"Arrive"}
    for i in range(1, n + 1):
        expected_vertices.add(f"Start_{i}")
        expected_vertices.add(f"Finish_{i}")

    actual_vertices = {v["name"] for v in data.get("vertices", [])}

    missing = expected_vertices - actual_vertices
    extra = actual_vertices - expected_vertices

    if missing:
        errors.append(f"Missing vertices: {missing}")
    if extra:
        errors.append(f"Extra vertices: {extra}")

    # Verify state variables
    expected_state_vars = {"load_id_counter", "departure_count"}
    for i in range(1, n + 1):
        expected_state_vars.add(f"queue_count_{i}")
        expected_state_vars.add(f"server_count_{i}")

    actual_state_vars = set(data.get("state_variables", {}).keys())

    missing_sv = expected_state_vars - actual_state_vars
    if missing_sv:
        errors.append(f"Missing state variables: {missing_sv}")

    # Verify scheduling edge flow
    edges = data.get("scheduling_edges", [])

    # Check Arrive → Arrive self-loop exists
    has_arrive_loop = any(
        e.get("from") == "Arrive" and e.get("to") == "Arrive"
        for e in edges
    )
    if not has_arrive_loop:
        errors.append("Missing Arrive self-loop edge")

    # Check Arrive → Start_1 edge
    has_arrive_start1 = any(
        e.get("from") == "Arrive" and e.get("to") == "Start_1"
        for e in edges
    )
    if not has_arrive_start1:
        errors.append("Missing Arrive → Start_1 edge")

    # Check Start_i → Finish_i edges for all stations
    for i in range(1, n + 1):
        has_start_finish = any(
            e.get("from") == f"Start_{i}" and e.get("to") == f"Finish_{i}"
            for e in edges
        )
        if not has_start_finish:
            errors.append(f"Missing Start_{i} → Finish_{i} edge")

    # Check Finish_i → Start_{i+1} edges for tandem flow
    for i in range(1, n):
        has_finish_start_next = any(
            e.get("from") == f"Finish_{i}" and e.get("to") == f"Start_{i+1}"
            for e in edges
        )
        if not has_finish_start_next:
            errors.append(f"Missing Finish_{i} → Start_{i+1} edge (tandem flow)")

    # Check recirculation edges Finish_i → Start_i
    for i in range(1, n + 1):
        has_recirc = any(
            e.get("from") == f"Finish_{i}" and e.get("to") == f"Start_{i}"
            for e in edges
        )
        if not has_recirc:
            errors.append(f"Missing Finish_{i} → Start_{i} recirculation edge")

    # Verify random streams
    expected_streams = {"interarrival_time"}
    for i in range(1, n + 1):
        expected_streams.add(f"service_time_{i}")

    actual_streams = set(data.get("random_streams", {}).keys())
    missing_streams = expected_streams - actual_streams
    if missing_streams:
        errors.append(f"Missing random streams: {missing_streams}")

    # Verify observables include all queue_count and server_count
    observables = data.get("observables", {})
    for i in range(1, n + 1):
        if f"queue_count_{i}" not in observables:
            errors.append(f"Missing observable: queue_count_{i}")

    return errors


def verify_acd_structure(data: Dict, n: int) -> List[str]:
    """Verify ACD structure for n-station tandem queue."""
    errors = []

    # Expected queues: C, Q_1..Q_n, S_1..S_n, Jobs
    expected_queues = {"C", "Jobs"}
    for i in range(1, n + 1):
        expected_queues.add(f"Q_{i}")
        expected_queues.add(f"S_{i}")

    actual_queues = set(data.get("queues", {}).keys())

    missing = expected_queues - actual_queues
    extra = actual_queues - expected_queues

    if missing:
        errors.append(f"Missing queues: {missing}")
    if extra:
        errors.append(f"Extra queues: {extra}")

    # Expected activities: Create, Serve_1..Serve_n
    expected_activities = {"Create"}
    for i in range(1, n + 1):
        expected_activities.add(f"Serve_{i}")

    actual_activities = {a["name"] for a in data.get("activities", [])}

    missing_act = expected_activities - actual_activities
    extra_act = actual_activities - expected_activities

    if missing_act:
        errors.append(f"Missing activities: {missing_act}")
    if extra_act:
        errors.append(f"Extra activities: {extra_act}")

    # Verify activity flow
    activities = {a["name"]: a for a in data.get("activities", [])}

    # Create should consume from C and produce to C and Q_1
    create = activities.get("Create")
    if create:
        consumes = [c["queue"] for c in create.get("at_begin", {}).get("consume", [])]
        if "C" not in consumes:
            errors.append("Create activity should consume from C")

        produces = []
        for arc in create.get("at_end", []):
            produces.extend([p["queue"] for p in arc.get("produce", [])])
        if "C" not in produces:
            errors.append("Create activity should produce to C")
        if "Q_1" not in produces:
            errors.append("Create activity should produce to Q_1")

    # Verify Serve_i activities
    for i in range(1, n + 1):
        serve = activities.get(f"Serve_{i}")
        if serve:
            consumes = [c["queue"] for c in serve.get("at_begin", {}).get("consume", [])]
            if f"S_{i}" not in consumes:
                errors.append(f"Serve_{i} should consume from S_{i}")
            if f"Q_{i}" not in consumes:
                errors.append(f"Serve_{i} should consume from Q_{i}")

            produces = []
            for arc in serve.get("at_end", []):
                produces.extend([p["queue"] for p in arc.get("produce", [])])
            if f"S_{i}" not in produces:
                errors.append(f"Serve_{i} should produce to S_{i}")

            # Check output queue
            if i < n:
                if f"Q_{i+1}" not in produces:
                    errors.append(f"Serve_{i} should produce to Q_{i+1} (tandem flow)")
            else:
                if "Jobs" not in produces:
                    errors.append(f"Serve_{n} should produce to Jobs (departure)")

    # Verify random streams
    expected_streams = {"duration_create"}
    for i in range(1, n + 1):
        expected_streams.add(f"duration_serve_{i}")

    actual_streams = set(data.get("random_streams", {}).keys())
    missing_streams = expected_streams - actual_streams
    if missing_streams:
        errors.append(f"Missing random streams: {missing_streams}")

    # Verify observables include all queue_count and server_count
    observables = data.get("observables", {})
    for i in range(1, n + 1):
        if f"queue_count_{i}" not in observables:
            errors.append(f"Missing observable: queue_count_{i}")
        if f"server_count_{i}" not in observables:
            errors.append(f"Missing observable: server_count_{i}")

    return errors


def verify_eg_acd_alignment(eg_data: Dict, acd_data: Dict, n: int) -> List[str]:
    """Verify EG and ACD models are aligned for trace equivalence."""
    errors = []

    # Parameters should match
    eg_params = eg_data.get("parameters", {})
    acd_params = acd_data.get("parameters", {})

    for param in ["iat_mean", "ist_mean", "sim_end_time"]:
        eg_val = eg_params.get(param, {}).get("value")
        acd_val = acd_params.get(param, {}).get("value")
        if eg_val != acd_val:
            errors.append(f"Parameter mismatch for {param}: EG={eg_val}, ACD={acd_val}")

    # Server capacity should match
    eg_capacity = eg_params.get("service_capacity", {}).get("value")
    acd_servers = acd_params.get("num_servers", {}).get("value")
    if eg_capacity != acd_servers:
        errors.append(f"Server count mismatch: EG service_capacity={eg_capacity}, ACD num_servers={acd_servers}")

    # Check server queue initial tokens match capacity
    acd_queues = acd_data.get("queues", {})
    for i in range(1, n + 1):
        s_queue = acd_queues.get(f"S_{i}", {})
        initial = s_queue.get("initial_tokens", 0)
        if initial != acd_servers:
            errors.append(f"S_{i} initial_tokens={initial} should match num_servers={acd_servers}")

    # Observable names should align
    eg_obs = set(eg_data.get("observables", {}).keys())
    acd_obs = set(acd_data.get("observables", {}).keys())

    # Check critical observables present in both
    for i in range(1, n + 1):
        if f"queue_count_{i}" not in eg_obs:
            errors.append(f"EG missing observable: queue_count_{i}")
        if f"queue_count_{i}" not in acd_obs:
            errors.append(f"ACD missing observable: queue_count_{i}")

    return errors


def verify_tandem_model(n: int, base_path: Path) -> Tuple[bool, Dict[str, List[str]]]:
    """Verify a single tandem-n model pair (EG and ACD)."""
    results = {
        "eg_errors": [],
        "acd_errors": [],
        "alignment_errors": [],
        "load_errors": []
    }

    eg_path = base_path / "eg" / f"tandem_{n}_eg.json"
    acd_path = base_path / "acd" / f"tandem_{n}_acd.json"

    # Load files
    try:
        eg_data = load_json(eg_path)
    except Exception as e:
        results["load_errors"].append(f"Failed to load EG: {e}")
        eg_data = None

    try:
        acd_data = load_json(acd_path)
    except Exception as e:
        results["load_errors"].append(f"Failed to load ACD: {e}")
        acd_data = None

    if eg_data:
        results["eg_errors"] = verify_eg_structure(eg_data, n)

    if acd_data:
        results["acd_errors"] = verify_acd_structure(acd_data, n)

    if eg_data and acd_data:
        results["alignment_errors"] = verify_eg_acd_alignment(eg_data, acd_data, n)

    # Determine pass/fail
    all_errors = (
        results["load_errors"] +
        results["eg_errors"] +
        results["acd_errors"] +
        results["alignment_errors"]
    )

    return len(all_errors) == 0, results


def main():
    """Run verification on all tandem models."""
    base_path = Path(__file__).parent
    n_values = [1, 3, 5, 10, 20]

    print("=" * 70)
    print("TANDEM N-QUEUE MODEL VERIFICATION")
    print("=" * 70)

    all_passed = True

    for n in n_values:
        print(f"\n--- Tandem {n}-Queue ---")
        passed, results = verify_tandem_model(n, base_path)

        if passed:
            print(f"  PASS: All checks passed")
        else:
            all_passed = False
            print(f"  FAIL:")

            if results["load_errors"]:
                print(f"    Load errors:")
                for e in results["load_errors"]:
                    print(f"      - {e}")

            if results["eg_errors"]:
                print(f"    Event Graph errors:")
                for e in results["eg_errors"]:
                    print(f"      - {e}")

            if results["acd_errors"]:
                print(f"    ACD errors:")
                for e in results["acd_errors"]:
                    print(f"      - {e}")

            if results["alignment_errors"]:
                print(f"    Alignment errors:")
                for e in results["alignment_errors"]:
                    print(f"      - {e}")

    print("\n" + "=" * 70)
    if all_passed:
        print("OVERALL: ALL MODELS PASSED VERIFICATION")
    else:
        print("OVERALL: SOME MODELS FAILED VERIFICATION")
    print("=" * 70)

    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
