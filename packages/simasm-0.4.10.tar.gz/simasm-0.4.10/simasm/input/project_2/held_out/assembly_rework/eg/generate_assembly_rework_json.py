#!/usr/bin/env python3
"""
generate_assembly_rework_json.py

Generate Event Graph JSON files for assembly line with quality inspection topology.
Each stage has: Start -> Finish -> Inspect -> {Rework(p=0.2) | Pass}

Configurations: N = {2, 3, 5, 7} stages
"""

import json
import os


def generate_assembly_rework_json(n):
    """Generate Event Graph JSON for assembly_rework_N model."""
    model_name = f"assembly_rework_{n}_eg"

    # --- Entities ---
    entities = {
        "Part": {
            "name": "Part",
            "parent": "Object",
            "attributes": {"arrival_time": "Real"}
        }
    }

    # --- Parameters ---
    parameters = {
        "service_capacity": {
            "type": "Nat",
            "value": 5,
            "description": "Number of servers per station"
        },
        "iat_mean": {
            "type": "Real",
            "value": 1.25,
            "description": "Inter-arrival time mean"
        },
        "ist_mean": {
            "type": "Real",
            "value": 1.0,
            "description": "Service time mean per station"
        },
        "rework_prob": {
            "type": "Real",
            "value": 0.2,
            "description": "Probability of rework at each stage"
        },
        "sim_end_time": {
            "type": "Real",
            "value": 10000.0,
            "description": "Simulation end time"
        }
    }

    # --- State Variables ---
    state_variables = {}
    for i in range(1, n + 1):
        state_variables[f"queue_{i}"] = {"type": "Nat", "initial": 0}
        state_variables[f"server_{i}"] = {"type": "Nat", "initial": 0}
    state_variables["part_id_counter"] = {"type": "Nat", "initial": 0}
    state_variables["departure_count"] = {"type": "Nat", "initial": 0}
    state_variables["rework_count_total"] = {"type": "Nat", "initial": 0}

    # --- Random Streams ---
    random_streams = {
        "interarrival_time": {
            "distribution": "exponential",
            "params": {"mean": "iat_mean"},
            "stream_name": "arrivals"
        }
    }
    for i in range(1, n + 1):
        random_streams[f"service_time_{i}"] = {
            "distribution": "exponential",
            "params": {"mean": "ist_mean"},
            "stream_name": f"service_{i}"
        }
        random_streams[f"rework_decision_{i}"] = {
            "distribution": "uniform",
            "params": {"min": 0, "max": 1},
            "stream_name": f"rework_{i}"
        }

    # --- Vertices ---
    vertices = []

    # Arrive
    vertices.append({
        "name": "Arrive",
        "state_change": "part_id_counter := part_id_counter + 1; queue_1 := queue_1 + 1"
    })

    # Per-stage: Start_i, Finish_i, Inspect_i, Rework_i, Pass_i (except last stage has no Pass)
    for i in range(1, n + 1):
        vertices.append({
            "name": f"Start_{i}",
            "parameters": [{"part": "Part"}],
            "state_change": f"queue_{i} := queue_{i} - 1; server_{i} := server_{i} + 1"
        })
        vertices.append({
            "name": f"Finish_{i}",
            "parameters": [{"part": "Part"}],
            "state_change": f"server_{i} := server_{i} - 1"
        })
        vertices.append({
            "name": f"Inspect_{i}",
            "parameters": [{"part": "Part"}],
            "description": f"Quality check after stage {i}",
            "state_change": ""
        })
        vertices.append({
            "name": f"Rework_{i}",
            "parameters": [{"part": "Part"}],
            "description": f"Send back for rework at stage {i}",
            "state_change": f"queue_{i} := queue_{i} + 1; rework_count_total := rework_count_total + 1"
        })
        if i < n:
            vertices.append({
                "name": f"Pass_{i}",
                "parameters": [{"part": "Part"}],
                "description": f"Pass inspection, move to stage {i+1}",
                "state_change": f"queue_{i+1} := queue_{i+1} + 1"
            })

    # Depart
    vertices.append({
        "name": "Depart",
        "state_change": "departure_count := departure_count + 1"
    })

    # --- Scheduling Edges ---
    edges = []

    # Arrive -> Arrive (self-scheduling)
    edges.append({
        "from": "Arrive", "to": "Arrive",
        "delay": "interarrival_time", "condition": "true", "priority": 0
    })

    # Arrive -> Start_1
    edges.append({
        "from": "Arrive", "to": "Start_1",
        "delay": 0, "condition": "queue_1 > 0 and server_1 < service_capacity",
        "priority": 0, "parameters": ["part"]
    })

    for i in range(1, n + 1):
        # Start_i -> Finish_i
        edges.append({
            "from": f"Start_{i}", "to": f"Finish_{i}",
            "delay": f"service_time_{i}", "condition": "true",
            "priority": 0, "parameters": ["part"]
        })

        # Finish_i -> Inspect_i
        edges.append({
            "from": f"Finish_{i}", "to": f"Inspect_{i}",
            "delay": 0, "condition": "true",
            "priority": 0, "parameters": ["part"]
        })

        # Finish_i -> Start_i (serve next in queue)
        edges.append({
            "from": f"Finish_{i}", "to": f"Start_{i}",
            "delay": 0, "condition": f"queue_{i} > 0 and server_{i} < service_capacity",
            "priority": 0, "parameters": ["next_part"]
        })

        # Inspect_i -> Rework_i (failed inspection)
        edges.append({
            "from": f"Inspect_{i}", "to": f"Rework_{i}",
            "delay": 0, "condition": f"rework_decision_{i} < rework_prob",
            "priority": 0, "parameters": ["part"]
        })

        if i < n:
            # Inspect_i -> Pass_i (passed inspection, not last stage)
            edges.append({
                "from": f"Inspect_{i}", "to": f"Pass_{i}",
                "delay": 0, "condition": f"rework_decision_{i} >= rework_prob",
                "priority": 0, "parameters": ["part"]
            })

            # Rework_i -> Start_i (reworked part re-enters service)
            edges.append({
                "from": f"Rework_{i}", "to": f"Start_{i}",
                "delay": 0, "condition": f"queue_{i} > 0 and server_{i} < service_capacity",
                "priority": 0, "parameters": ["part"]
            })

            # Pass_i -> Start_{i+1} (move to next stage)
            edges.append({
                "from": f"Pass_{i}", "to": f"Start_{i+1}",
                "delay": 0, "condition": f"queue_{i+1} > 0 and server_{i+1} < service_capacity",
                "priority": 0, "parameters": ["part"]
            })
        else:
            # Last stage: Inspect_N -> Depart (passed)
            edges.append({
                "from": f"Inspect_{i}", "to": "Depart",
                "delay": 0, "condition": f"rework_decision_{i} >= rework_prob",
                "priority": 0
            })

            # Rework_N -> Start_N
            edges.append({
                "from": f"Rework_{i}", "to": f"Start_{i}",
                "delay": 0, "condition": f"queue_{i} > 0 and server_{i} < service_capacity",
                "priority": 0, "parameters": ["part"]
            })

    # --- Observables ---
    queue_expr = " + ".join(f"queue_{i}" for i in range(1, n + 1))
    observables = {
        "total_queue": {
            "name": "total_queue",
            "expression": queue_expr
        },
        "departure_count": {
            "name": "departure_count",
            "expression": "departure_count"
        },
        "rework_count": {
            "name": "rework_count",
            "expression": "rework_count_total"
        }
    }

    # --- Statistics ---
    statistics = [
        {"name": "L_q_total", "type": "time_average", "observable": "total_queue"},
        {"name": "throughput", "type": "count", "observable": "departure_count"},
        {"name": "rework_total", "type": "count", "observable": "rework_count"}
    ]

    # --- Assemble ---
    spec = {
        "model_name": model_name,
        "description": f"Assembly line with {n} stages, probabilistic rework at each stage",
        "entities": entities,
        "parameters": parameters,
        "state_variables": state_variables,
        "random_streams": random_streams,
        "vertices": vertices,
        "scheduling_edges": edges,
        "cancelling_edges": [],
        "initial_events": [
            {"event": "Arrive", "time": "interarrival_time"}
        ],
        "stopping_condition": "sim_clocktime >= sim_end_time",
        "observables": observables,
        "statistics": statistics
    }

    return spec


def main():
    configurations = [2, 3, 5, 7]
    output_dir = os.path.dirname(os.path.abspath(__file__))

    print("Generating assembly_rework Event Graph JSON files...")
    for n in configurations:
        spec = generate_assembly_rework_json(n)
        filename = f"assembly_rework_{n}_eg.json"
        filepath = os.path.join(output_dir, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(spec, f, indent=2)

        num_vertices = len(spec["vertices"])
        num_edges = len(spec["scheduling_edges"])
        num_state_vars = len(spec["state_variables"])
        print(f"  {filename}: {num_vertices} vertices, {num_edges} edges, {num_state_vars} state vars")

    print(f"\nGenerated {len(configurations)} files in {output_dir}")


if __name__ == "__main__":
    main()
