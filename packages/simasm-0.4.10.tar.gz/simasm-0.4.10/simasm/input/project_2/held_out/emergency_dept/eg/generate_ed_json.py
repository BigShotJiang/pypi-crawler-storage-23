#!/usr/bin/env python3
"""
generate_ed_json.py

Generate Event Graph JSON files for Emergency Department topology.
Structure: Arrive -> Triage -> Route(1/N) -> Treatment_i -> Assess -> {Readmit(p=0.15) | Discharge}

Configurations: N = {2, 3, 5, 7} treatment areas
"""

import json
import os


def generate_ed_json(n):
    """Generate Event Graph JSON for ed_N model (N treatment areas)."""
    model_name = f"ed_{n}_eg"

    # --- Entities ---
    entities = {
        "Patient": {
            "name": "Patient",
            "parent": "Object",
            "attributes": {"arrival_time": "Real"}
        }
    }

    # --- Parameters ---
    parameters = {
        "service_capacity": {
            "type": "Nat",
            "value": 5,
            "description": "Number of servers per station"
        },
        "iat_mean": {
            "type": "Real",
            "value": 1.25,
            "description": "Inter-arrival time mean"
        },
        "ist_mean": {
            "type": "Real",
            "value": 1.0,
            "description": "Service time mean per station"
        },
        "readmit_prob": {
            "type": "Real",
            "value": 0.15,
            "description": "Probability of readmission after treatment"
        },
        "sim_end_time": {
            "type": "Real",
            "value": 10000.0,
            "description": "Simulation end time"
        }
    }

    # --- State Variables ---
    state_variables = {
        "triage_queue": {"type": "Nat", "initial": 0},
        "triage_server": {"type": "Nat", "initial": 0},
    }
    for i in range(1, n + 1):
        state_variables[f"treatment_queue_{i}"] = {"type": "Nat", "initial": 0}
        state_variables[f"treatment_server_{i}"] = {"type": "Nat", "initial": 0}
    state_variables["patient_id_counter"] = {"type": "Nat", "initial": 0}
    state_variables["discharge_count"] = {"type": "Nat", "initial": 0}
    state_variables["readmit_count"] = {"type": "Nat", "initial": 0}

    # --- Random Streams ---
    random_streams = {
        "interarrival_time": {
            "distribution": "exponential",
            "params": {"mean": "iat_mean"},
            "stream_name": "arrivals"
        },
        "triage_service_time": {
            "distribution": "exponential",
            "params": {"mean": "ist_mean"},
            "stream_name": "triage_service"
        },
        "routing_decision": {
            "distribution": "uniform",
            "params": {"min": 0, "max": 1},
            "stream_name": "routing"
        },
        "readmit_decision": {
            "distribution": "uniform",
            "params": {"min": 0, "max": 1},
            "stream_name": "readmit"
        }
    }
    for i in range(1, n + 1):
        random_streams[f"treatment_service_time_{i}"] = {
            "distribution": "exponential",
            "params": {"mean": "ist_mean"},
            "stream_name": f"treatment_service_{i}"
        }

    # --- Vertices ---
    vertices = []

    # Arrive
    vertices.append({
        "name": "Arrive",
        "state_change": "patient_id_counter := patient_id_counter + 1; triage_queue := triage_queue + 1"
    })

    # Triage
    vertices.append({
        "name": "Start_Triage",
        "parameters": [{"patient": "Patient"}],
        "state_change": "triage_queue := triage_queue - 1; triage_server := triage_server + 1"
    })
    vertices.append({
        "name": "Finish_Triage",
        "parameters": [{"patient": "Patient"}],
        "state_change": "triage_server := triage_server - 1"
    })

    # Route - probabilistic routing to treatment areas
    vertices.append({
        "name": "Route",
        "parameters": [{"patient": "Patient"}],
        "description": "Route patient to treatment area (uniform 1/N)",
        "state_change": ""
    })

    # Treatment areas
    for i in range(1, n + 1):
        vertices.append({
            "name": f"Enter_Treatment_{i}",
            "parameters": [{"patient": "Patient"}],
            "description": f"Patient enters treatment area {i} queue",
            "state_change": f"treatment_queue_{i} := treatment_queue_{i} + 1"
        })
        vertices.append({
            "name": f"Start_Treatment_{i}",
            "parameters": [{"patient": "Patient"}],
            "state_change": f"treatment_queue_{i} := treatment_queue_{i} - 1; treatment_server_{i} := treatment_server_{i} + 1"
        })
        vertices.append({
            "name": f"Finish_Treatment_{i}",
            "parameters": [{"patient": "Patient"}],
            "state_change": f"treatment_server_{i} := treatment_server_{i} - 1"
        })

    # Assess - readmission decision
    vertices.append({
        "name": "Assess",
        "parameters": [{"patient": "Patient"}],
        "description": "Assess patient for discharge or readmission",
        "state_change": ""
    })

    # Readmit
    vertices.append({
        "name": "Readmit",
        "parameters": [{"patient": "Patient"}],
        "description": "Patient readmitted back to triage",
        "state_change": "triage_queue := triage_queue + 1; readmit_count := readmit_count + 1"
    })

    # Discharge
    vertices.append({
        "name": "Discharge",
        "state_change": "discharge_count := discharge_count + 1"
    })

    # --- Scheduling Edges ---
    edges = []

    # Arrive -> Arrive (self-scheduling)
    edges.append({
        "from": "Arrive", "to": "Arrive",
        "delay": "interarrival_time", "condition": "true", "priority": 0
    })

    # Arrive -> Start_Triage
    edges.append({
        "from": "Arrive", "to": "Start_Triage",
        "delay": 0, "condition": "triage_queue > 0 and triage_server < service_capacity",
        "priority": 0, "parameters": ["patient"]
    })

    # Start_Triage -> Finish_Triage
    edges.append({
        "from": "Start_Triage", "to": "Finish_Triage",
        "delay": "triage_service_time", "condition": "true",
        "priority": 0, "parameters": ["patient"]
    })

    # Finish_Triage -> Route
    edges.append({
        "from": "Finish_Triage", "to": "Route",
        "delay": 0, "condition": "true",
        "priority": 0, "parameters": ["patient"]
    })

    # Finish_Triage -> Start_Triage (serve next in triage queue)
    edges.append({
        "from": "Finish_Triage", "to": "Start_Triage",
        "delay": 0, "condition": "triage_queue > 0 and triage_server < service_capacity",
        "priority": 0, "parameters": ["next_patient"]
    })

    # Route -> Enter_Treatment_i (probabilistic routing: uniform 1/N)
    for i in range(1, n + 1):
        lower = (i - 1) / n
        upper = i / n
        if i < n:
            condition = f"routing_decision >= {lower} and routing_decision < {upper}"
        else:
            # Last bucket: >= to handle rounding
            condition = f"routing_decision >= {lower}"
        edges.append({
            "from": "Route", "to": f"Enter_Treatment_{i}",
            "delay": 0, "condition": condition,
            "priority": 0, "parameters": ["patient"]
        })

    # Treatment area edges
    for i in range(1, n + 1):
        # Enter_Treatment_i -> Start_Treatment_i
        edges.append({
            "from": f"Enter_Treatment_{i}", "to": f"Start_Treatment_{i}",
            "delay": 0, "condition": f"treatment_queue_{i} > 0 and treatment_server_{i} < service_capacity",
            "priority": 0, "parameters": ["patient"]
        })

        # Start_Treatment_i -> Finish_Treatment_i
        edges.append({
            "from": f"Start_Treatment_{i}", "to": f"Finish_Treatment_{i}",
            "delay": f"treatment_service_time_{i}", "condition": "true",
            "priority": 0, "parameters": ["patient"]
        })

        # Finish_Treatment_i -> Assess
        edges.append({
            "from": f"Finish_Treatment_{i}", "to": "Assess",
            "delay": 0, "condition": "true",
            "priority": 0, "parameters": ["patient"]
        })

        # Finish_Treatment_i -> Start_Treatment_i (serve next in treatment queue)
        edges.append({
            "from": f"Finish_Treatment_{i}", "to": f"Start_Treatment_{i}",
            "delay": 0, "condition": f"treatment_queue_{i} > 0 and treatment_server_{i} < service_capacity",
            "priority": 0, "parameters": ["next_patient"]
        })

    # Assess -> Readmit (readmission)
    edges.append({
        "from": "Assess", "to": "Readmit",
        "delay": 0, "condition": "readmit_decision < readmit_prob",
        "priority": 0, "parameters": ["patient"]
    })

    # Assess -> Discharge (discharge)
    edges.append({
        "from": "Assess", "to": "Discharge",
        "delay": 0, "condition": "readmit_decision >= readmit_prob",
        "priority": 0
    })

    # Readmit -> Start_Triage (readmitted patient goes back to triage)
    edges.append({
        "from": "Readmit", "to": "Start_Triage",
        "delay": 0, "condition": "triage_queue > 0 and triage_server < service_capacity",
        "priority": 0, "parameters": ["patient"]
    })

    # --- Observables ---
    queue_parts = ["triage_queue"] + [f"treatment_queue_{i}" for i in range(1, n + 1)]
    queue_expr = " + ".join(queue_parts)
    observables = {
        "total_queue": {
            "name": "total_queue",
            "expression": queue_expr
        },
        "discharge_count": {
            "name": "discharge_count",
            "expression": "discharge_count"
        },
        "readmit_count": {
            "name": "readmit_count",
            "expression": "readmit_count"
        }
    }

    # --- Statistics ---
    statistics = [
        {"name": "L_q_total", "type": "time_average", "observable": "total_queue"},
        {"name": "throughput", "type": "count", "observable": "discharge_count"},
        {"name": "readmit_total", "type": "count", "observable": "readmit_count"}
    ]

    # --- Assemble ---
    spec = {
        "model_name": model_name,
        "description": f"Emergency department with triage, {n} treatment areas, and probabilistic readmission (p=0.15)",
        "entities": entities,
        "parameters": parameters,
        "state_variables": state_variables,
        "random_streams": random_streams,
        "vertices": vertices,
        "scheduling_edges": edges,
        "cancelling_edges": [],
        "initial_events": [
            {"event": "Arrive", "time": "interarrival_time"}
        ],
        "stopping_condition": "sim_clocktime >= sim_end_time",
        "observables": observables,
        "statistics": statistics
    }

    return spec


def main():
    configurations = [2, 3, 5, 7]
    output_dir = os.path.dirname(os.path.abspath(__file__))

    print("Generating emergency_dept Event Graph JSON files...")
    for n in configurations:
        spec = generate_ed_json(n)
        filename = f"ed_{n}_eg.json"
        filepath = os.path.join(output_dir, filename)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(spec, f, indent=2)

        num_vertices = len(spec["vertices"])
        num_edges = len(spec["scheduling_edges"])
        num_state_vars = len(spec["state_variables"])
        print(f"  {filename}: {num_vertices} vertices, {num_edges} edges, {num_state_vars} state vars")

    print(f"\nGenerated {len(configurations)} files in {output_dir}")


if __name__ == "__main__":
    main()
