"""
SimASM configuration module.
"""

from .file_config import FileConfig

__all__ = ['FileConfig']
