"""
Example JSON specifications for Event Graph and ACD models.
"""
