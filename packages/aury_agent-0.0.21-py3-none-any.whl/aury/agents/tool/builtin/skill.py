"""Skill tool - load skill content on demand.

Implements Progressive Disclosure for skills:
- Tool description lists available skill names + descriptions
- LLM calls this tool to load full skill content when needed

Works with SkillContextProvider (Provider gives overview in system prompt,
this tool gives full content on demand).
"""
from __future__ import annotations

from typing import Any, TYPE_CHECKING

from ...core.logging import tool_logger as logger
from ...core.types.tool import BaseTool, ToolContext, ToolResult

if TYPE_CHECKING:
    from ...skill import SkillLoader


class SkillTool(BaseTool):
    """Load skill content on demand.
    
    Progressive Disclosure pattern:
    - Description dynamically lists available skills (name + short description)
    - LLM calls skill(name=...) to load full instructions when needed
    - Content is lazily loaded from SKILL.md body
    """
    
    _name = "skill"
    
    def __init__(self, loader: "SkillLoader"):
        """Initialize with SkillLoader.
        
        Args:
            loader: SkillLoader instance with skills already loaded
        """
        self._loader = loader
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def description(self) -> str:
        """Build description with available skills list."""
        skills = self._loader.list_all()
        if not skills:
            return (
                "Load a skill to get detailed instructions for a specific task. "
                "No skills are currently available."
            )
        
        skill_lines = []
        for skill in sorted(skills, key=lambda s: s.name):
            desc_first_line = skill.description.split("\n")[0].strip()
            skill_lines.append(f"  - {skill.name}: {desc_first_line}")
        
        skill_list = "\n".join(skill_lines)
        return (
            "Load a skill to get detailed instructions for a specific task.\n"
            "Skills provide specialized knowledge and step-by-step guidance.\n"
            "Use this when a task matches an available skill's description.\n\n"
            f"Available skills:\n{skill_list}"
        )
    
    @property
    def parameters(self) -> dict[str, Any]:
        """Build parameters with skill name enum."""
        skills = self._loader.list_all()
        skill_names = [s.name for s in skills]
        
        name_schema: dict[str, Any] = {
            "type": "string",
            "description": "The skill name to load",
        }
        if skill_names:
            name_schema["enum"] = sorted(skill_names)
        
        return {
            "type": "object",
            "properties": {
                "name": name_schema,
            },
            "required": ["name"],
        }
    
    async def execute(
        self,
        params: dict[str, Any],
        ctx: ToolContext,
    ) -> ToolResult:
        """Load and return skill content."""
        skill_name = params.get("name", "")
        
        if not skill_name:
            return ToolResult.error("Missing 'name' parameter")
        
        skill = self._loader.get(skill_name)
        if skill is None:
            available = ", ".join(s.name for s in self._loader.list_all())
            return ToolResult.error(
                f"Skill '{skill_name}' not found. "
                f"Available skills: {available or 'none'}"
            )
        
        logger.info(
            "Loading skill",
            extra={
                "skill": skill_name,
                "source": skill.source,
                "invocation_id": ctx.invocation_id,
            },
        )
        
        # Load full content (lazy)
        content = await skill.load_content()
        
        # Build output
        base_dir = str(skill.path.parent)
        parts = [
            f"## Skill: {skill.name}",
            "",
            f"**Base directory**: {base_dir}",
        ]
        
        if skill.allowed_tools:
            parts.append(f"**Allowed tools**: {', '.join(skill.allowed_tools)}")
        
        parts.extend(["", content.strip()])
        
        output = "\n".join(parts)
        
        logger.debug(
            "Skill loaded",
            extra={
                "skill": skill_name,
                "content_len": len(content),
                "invocation_id": ctx.invocation_id,
            },
        )
        
        return ToolResult.success(output)


__all__ = ["SkillTool"]
