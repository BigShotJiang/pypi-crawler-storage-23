"""Output rendering for Gremlin."""
