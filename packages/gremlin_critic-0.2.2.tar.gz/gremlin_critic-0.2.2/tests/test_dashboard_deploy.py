"""Test deployed dashboard is accessible (requires internet)."""

import json

import pytest
import requests


@pytest.mark.skipif(
    True,  # Skip by default, run manually with: pytest -k deploy --run-deploy-tests
    reason="Requires internet and deployed dashboard",
)
class TestDashboardDeploy:
    """Tests for deployed dashboard on GitHub Pages."""

    BASE_URL = "https://abhi10.github.io/gremlin"

    def test_dashboard_html_accessible(self):
        """Test that main dashboard HTML loads."""
        resp = requests.get(self.BASE_URL, timeout=10)
        assert resp.status_code == 200
        assert "Gremlin Risk Dashboard" in resp.text

    def test_catalog_accessible(self):
        """Test that catalog.json is accessible."""
        resp = requests.get(f"{self.BASE_URL}/data/catalog.json", timeout=10)
        assert resp.status_code == 200
        catalog = resp.json()
        assert "projects" in catalog
        assert len(catalog["projects"]) > 0

    def test_all_data_files_accessible(self):
        """Test that all data files listed in catalog are accessible."""
        catalog_resp = requests.get(f"{self.BASE_URL}/data/catalog.json", timeout=10)
        catalog = catalog_resp.json()

        for project in catalog["projects"]:
            url = f"{self.BASE_URL}/data/{project['file']}"
            resp = requests.get(url, timeout=10)
            assert resp.status_code == 200, f"Failed to load {url}"

            # Verify JSON is valid
            data = resp.json()
            assert "areas" in data
            assert "target" in data

    def test_chartjs_cdn_accessible(self):
        """Test that Chart.js CDN loads."""
        resp = requests.get(
            "https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js",
            timeout=10,
        )
        assert resp.status_code == 200
