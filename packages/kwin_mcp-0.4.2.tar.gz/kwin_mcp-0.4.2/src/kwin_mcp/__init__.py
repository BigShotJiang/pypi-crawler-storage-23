"""kwin-mcp: MCP server for GUI automation on KDE Plasma 6 Wayland."""
