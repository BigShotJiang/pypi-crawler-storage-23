"""Allow running kwin-mcp via `python -m kwin_mcp`."""

from kwin_mcp.server import main

main()
