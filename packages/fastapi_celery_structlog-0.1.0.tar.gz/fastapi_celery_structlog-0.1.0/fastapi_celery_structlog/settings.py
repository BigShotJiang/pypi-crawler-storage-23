"""Package-level logging configuration for FastAPI and Celery integration."""

import logging
import logging.config
from pathlib import Path
from typing import Any

import structlog

from .runtime import resolve_runtime_options
from .utils import (
    add_logger_name,
    remove_response_field_for_none_system_loggers,
)


def configure_logging(
    base_dir: str | Path | None = None,
    env_value: Any = None,
) -> None:
    """Configure standard logging and structlog processors.

    The configuration keeps console logging enabled for all loggers while
    routing file output selectively:
    - HTTP request structured logs -> ``logs/app.json.log``
    - Celery structured task logs -> ``logs/celery.json.log``

    Args:
        base_dir: Optional root path used to create the ``logs/`` directory.
        env_value: Optional environment value used to switch dev/prod renderer.
    """
    resolved_base_dir, resolved_env_value = resolve_runtime_options(
        base_dir=base_dir,
        env_value=env_value,
    )
    logs_dir = resolved_base_dir / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    env_name = str(getattr(resolved_env_value, "value", resolved_env_value)).lower()
    is_dev = env_name in {"dev", "local", "development"}

    logging_config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "json_formatter": {
                "()": structlog.stdlib.ProcessorFormatter,
                "processor": structlog.processors.JSONRenderer(),
            },
            "plain_console": {
                "()": structlog.stdlib.ProcessorFormatter,
                "processor": structlog.dev.ConsoleRenderer(colors=True),
            },
        },
        "handlers": {
            "console": {
                "class": "logging.StreamHandler",
                "formatter": "plain_console" if is_dev else "json_formatter",
            },
            "request_json_file": {
                "class": "logging.handlers.TimedRotatingFileHandler",
                "filename": str(logs_dir / "app.json.log"),
                "when": "midnight",
                "interval": 1,
                "backupCount": 15,
                "formatter": "json_formatter",
                "encoding": "utf-8",
            },
            "celery_json_file": {
                "class": "logging.handlers.TimedRotatingFileHandler",
                "filename": str(logs_dir / "celery.json.log"),
                "when": "midnight",
                "interval": 1,
                "backupCount": 15,
                "formatter": "json_formatter",
                "encoding": "utf-8",
            },
        },
        "loggers": {
            "app": {
                "handlers": ["console"],
                "level": "INFO",
                "propagate": False,
            },
            "celery": {
                "handlers": ["console"],
                "level": "INFO",
                "propagate": False,
            },
            "celery.app.trace": {
                "handlers": ["console"],
                "level": "INFO",
                "propagate": False,
            },
            "fastapi_celery_structlog.middlewares.request_response": {
                "handlers": ["console", "request_json_file"],
                "level": "INFO",
                "propagate": False,
            },
            "fastapi_celery_structlog.celery.logger": {
                "handlers": ["console", "celery_json_file"],
                "level": "INFO",
                "propagate": False,
            },
            "uvicorn": {
                "handlers": ["console"],
                "level": "WARNING",
                "propagate": False,
            },
            "uvicorn.error": {
                "handlers": ["console"],
                "level": "WARNING",
                "propagate": False,
            },
            "uvicorn.access": {
                "handlers": ["console"],
                "level": "WARNING",
                "propagate": False,
            },
            "watchfiles.main": {
                "handlers": ["console"],
                "level": "WARNING",
                "propagate": False,
            },
            "watchfiles.watcher": {
                "handlers": ["console"],
                "level": "WARNING",
                "propagate": False,
            },
        },
        "root": {
            "handlers": ["console"],
            "level": "INFO",
        },
    }

    logging.config.dictConfig(logging_config)

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.stdlib.filter_by_level,
            structlog.processors.TimeStamper(fmt="iso"),
            add_logger_name,
            structlog.stdlib.add_log_level,
            remove_response_field_for_none_system_loggers,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )
