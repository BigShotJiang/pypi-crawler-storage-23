"""Celery logging integration built on top of the package logging setup."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import structlog
from celery import signals

from ..settings import configure_logging

_SIGNALS_CONFIGURED = False
logger = structlog.get_logger(__name__)


def _bind_task_context(
    task_id: str | None = None,
    task: Any = None,
    args: tuple[Any, ...] | None = None,
    kwargs: dict[str, Any] | None = None,
) -> None:
    """Bind common Celery task metadata to structlog contextvars."""
    structlog.contextvars.bind_contextvars(
        task_id=task_id,
        task=getattr(task, "name", None),
        task_args=list(args or ()),
        task_kwargs=kwargs or {},
    )


def _connect_celery_signals() -> None:
    """Connect Celery signals once and emit structured task lifecycle logs."""
    global _SIGNALS_CONFIGURED
    if _SIGNALS_CONFIGURED:
        return

    def _task_prerun_handler(
        sender: Any = None,
        task_id: str | None = None,
        task: Any = None,
        args: tuple[Any, ...] | None = None,
        kwargs: dict[str, Any] | None = None,
        **_: Any,
    ) -> None:
        _bind_task_context(
            task_id=task_id, task=task or sender, args=args, kwargs=kwargs
        )
        logger.info(
            "celery task started",
            task_id=task_id,
            task=getattr(task or sender, "name", None),
            task_args=list(args or ()),
            task_kwargs=kwargs or {},
        )

    def _task_postrun_handler(
        sender: Any = None,
        task_id: str | None = None,
        task: Any = None,
        retval: Any = None,
        state: str | None = None,
        **_: Any,
    ) -> None:
        logger.info(
            "celery task finished",
            task_id=task_id,
            task=getattr(task or sender, "name", None),
            state=state,
            result=retval,
        )
        structlog.contextvars.clear_contextvars()

    def _task_failure_handler(
        sender: Any = None,
        task_id: str | None = None,
        exception: BaseException | None = None,
        traceback: Any = None,
        einfo: Any = None,
        **_: Any,
    ) -> None:
        logger.error(
            "celery task failed",
            task_id=task_id,
            task=getattr(sender, "name", None),
            error=str(exception) if exception else None,
            traceback=str(traceback) if traceback else None,
            einfo=str(einfo) if einfo else None,
        )

    signals.task_prerun.connect(_task_prerun_handler, weak=False)
    signals.task_postrun.connect(_task_postrun_handler, weak=False)
    signals.task_failure.connect(_task_failure_handler, weak=False)

    _SIGNALS_CONFIGURED = True


def configure_celery_logging(
    *,
    celery_app: Any | None = None,
    base_dir: str | Path | None = None,
    env_value: Any = None,
    worker_hijack_root_logger: bool = False,
) -> None:
    """Configure logging for Celery workers and attach task signal handlers.

    Args:
        celery_app: Optional Celery app instance to mutate worker logger flags.
        base_dir: Optional base path used for log file directory creation.
        env_value: Optional environment name used for renderer mode.
        worker_hijack_root_logger: Forwarded to ``celery_app.conf`` when app is
            provided.
    """
    configure_logging(base_dir=base_dir, env_value=env_value)
    _connect_celery_signals()

    if celery_app is not None:
        celery_app.conf.worker_hijack_root_logger = worker_hijack_root_logger
