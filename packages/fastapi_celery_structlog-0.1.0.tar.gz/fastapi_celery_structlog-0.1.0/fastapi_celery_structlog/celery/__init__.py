"""Celery integration entrypoints for fastapi-celery-structlog."""

from .logger import configure_celery_logging

__all__ = ["configure_celery_logging"]
