"""Reusable structlog processors for HTTP and Celery log shaping."""

import logging

from celery._state import get_current_task, current_task
from structlog.typing import EventDict

celery_required_log_output_fields = [
    # celery struct log default keys
    "child_task_id",
    "child_task_name",
    "duration_ms",
    "event",
    "error",
    "exception",
    "level",
    "logger",
    "priority",
    "parent_task_id",
    "reason",
    "routing_key",
    "task_id",
    "task",
    "timestamp",
    # request fields
    "correlation_id",
    "request_id",
    "environment",
    "tenant_domain",
    "tenant_name",
    "tenant_schema_name",
    # extra fields
    "retry_count",
    "result",
    "task_args",
    "task_kwargs",
]


def add_logger_name(
    logger: logging.Logger, method_name: str, event_dict: EventDict
) -> EventDict:
    """
    Add the logger name to system.logger instead of top-level 'logger'.
    """
    # Ensure 'system' dict exists
    system_dict = event_dict.setdefault("system", {})

    record = event_dict.get("_record")
    if record is None:
        system_dict["logger"] = logger.name
    else:
        system_dict["logger"] = record.name

    return event_dict


def remove_response_field_for_none_system_loggers(
    logger: logging.Logger, method_name: str, event_dict: EventDict
) -> EventDict:
    """
    Remove certain fields from the log output if the logger is NOT one of:
    - django_structlog
    - django_custom
    """
    logger_name = (
        event_dict.get("logger")
        or event_dict.get("system", {}).get("logger")
        or getattr(logger, "name", None)
    )
    request_payload = event_dict.get("request")
    is_http_request_log = (
        isinstance(request_payload, dict) and request_payload.get("type") == "HTTP"
    )

    # Keep request middleware fields for HTTP logs.
    if is_http_request_log:
        return event_dict

    # Only keep fields if logger is one of the system loggers
    if logger_name not in {"django_structlog", "django_custom"}:
        for field in [
            "duration_ms",
            "exception",
            "system",
            "response",
            "service",
            "event_name",
        ]:
            event_dict.pop(field, None)

    return event_dict


def cleanup_unwanted_celery_output_fields(
    logger: logging.Logger, method_name: str, event_dict: EventDict
) -> EventDict:
    """Keep only whitelisted Celery fields in output event dict."""
    return {k: event_dict.get(k) for k in celery_required_log_output_fields}


def reformat_request_to_celery_log_fields(
    logger: logging.Logger, method_name: str, event_dict: EventDict
) -> EventDict:
    """Map nested request/tenant fields to flat Celery-friendly keys."""
    request = event_dict.get("request", {})
    if isinstance(request, dict):
        event_dict.setdefault("correlation_id", request.get("correlation_id"))
        event_dict.setdefault("request_id", request.get("id"))

    tenant = event_dict.get("tenant", {})
    if isinstance(tenant, dict):
        event_dict.setdefault("tenant_domain", tenant.get("domain"))
        event_dict.setdefault("tenant_name", tenant.get("name"))
        event_dict.setdefault("tenant_schema_name", tenant.get("schema_name"))

    return event_dict


def ensure_celery_task_name_processor(
    logger: logging.Logger, method_name: str, event_dict: EventDict
) -> EventDict:
    """
    Ensures that task name is bound to structlog context var
    But is better to use struct log celery signals instead of using this processor
    """
    try:
        task = get_current_task()
        if task and hasattr(task, "name"):
            event_dict["task"] = task.name
            return event_dict
    except Exception:
        pass

    # Try using current_task (alternative approach)
    try:
        if current_task and hasattr(current_task, "name"):
            event_dict["task"] = current_task.name
            return event_dict
    except Exception:
        pass

    return event_dict
