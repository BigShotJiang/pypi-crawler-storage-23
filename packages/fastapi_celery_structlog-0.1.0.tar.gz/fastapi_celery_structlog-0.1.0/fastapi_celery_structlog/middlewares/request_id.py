"""ASGI middleware that manages request and correlation identifiers."""

import uuid
from typing import Optional

from starlette.types import ASGIApp, Message, Receive, Scope, Send


class RequestIDMiddleware:
    """Populate ``request_id`` and ``correlation_id`` in ASGI scope state.

    Reads incoming headers, generates missing identifiers, and mirrors them back
    to response headers so upstream/downstream systems can correlate requests.
    """

    def __init__(
        self,
        app: ASGIApp,
        request_id_header: str = "x-request-id",
        correlation_id_header: str = "x-correlation-id",
    ) -> None:
        self.app = app
        self.request_id_header = request_id_header.lower()
        self.correlation_id_header = correlation_id_header.lower()

    @staticmethod
    def _get_header(
        headers: list[tuple[bytes, bytes]], name_lower: str
    ) -> Optional[str]:
        """Return a header value from raw ASGI headers by lowercase key."""
        name_b = name_lower.encode("latin-1")
        for k, v in headers:
            if k.lower() == name_b:
                return v.decode("latin-1")
        return None

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Run middleware for HTTP requests and pass-through non-HTTP scopes."""
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        headers = scope.get("headers") or []
        request_id = (
            self._get_header(headers, "x-request-id")
            or self._get_header(headers, "request-id")
            or str(uuid.uuid4())
        )
        correlation_id = (
            self._get_header(headers, "x-correlation-id")
            or self._get_header(headers, "correlation-id")
            or request_id
        )

        # روی scope ذخیره کن تا همه جا قابل دسترسی باشه
        scope.setdefault("state", {})
        scope["state"]["request_id"] = request_id
        scope["state"]["correlation_id"] = correlation_id

        async def send_wrapper(message: Message) -> None:
            if message["type"] == "http.response.start":
                hdrs = list(message.get("headers", []))
                hdrs.append((b"x-request-id", request_id.encode("latin-1")))
                hdrs.append((b"x-correlation-id", correlation_id.encode("latin-1")))
                message["headers"] = hdrs
            await send(message)

        await self.app(scope, receive, send_wrapper)
