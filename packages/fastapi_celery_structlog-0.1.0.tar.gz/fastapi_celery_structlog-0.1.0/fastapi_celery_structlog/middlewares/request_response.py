"""Structured request/response ASGI middleware for FastAPI/Starlette."""

import asyncio
import json
import logging
import socket
from datetime import datetime, timezone
from http import HTTPStatus
from inspect import getsourcefile, getsourcelines
from time import perf_counter
from typing import Any, Callable

import structlog
from starlette.datastructures import Headers
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from ..runtime import resolve_env_value

logger = structlog.get_logger()


def default_environment() -> str:
    """Default environment resolver used by middleware instances."""
    return str(resolve_env_value())


class StructlogRequestMiddleware:
    """
    Request/response logging middleware for FastAPI/Starlette using structlog contextvars.

    Fixes applied vs original:
    - Build request dict once and reuse (avoid drift/overhead).
    - UTC, timezone-aware timestamp.
    - Safer JSON media-type detection (handles application/problem+json).
    - Hard cap on captured body bytes (truncate chunk).
    - Optional endpoint source introspection (can be disabled/cached).
    - 499 cancellation treated as non-5xx "cancelled" and not counted as error by default.
    - Sanitize captured JSON body (denylist keys, depth/size bounded).
    - Avoid reverse DNS / blocking host resolution; best-effort only.
    """

    DEFAULT_SENSITIVE_KEYS = {
        "password",
        "pass",
        "passwd",
        "secret",
        "token",
        "access_token",
        "refresh_token",
        "id_token",
        "authorization",
        "api_key",
        "apikey",
        "client_secret",
        "session",
        "cookie",
        "set-cookie",
    }

    def __init__(
        self,
        app: ASGIApp,
        *,
        project_name: str = "location-backend",
        ip_logging_enabled: bool = True,
        log_4xx_level: int = logging.WARNING,
        max_body_bytes: int = 32_000,
        # Only capture response bodies for these status codes (avoid 401/403 payload leaks by default)
        capture_body_statuses: frozenset[int] = frozenset({400, 404, 409, 422}),
        # Capture only when content-type is JSON-ish
        capture_only_json: bool = True,
        # Sanitization
        sensitive_keys: frozenset[str] = frozenset(DEFAULT_SENSITIVE_KEYS),
        sanitize_max_depth: int = 6,
        sanitize_max_list: int = 50,
        sanitize_max_str: int = 2_000,
        # Introspection / performance knobs
        include_endpoint_source: bool = False,
        cache_endpoint_source: bool = True,
        # Cancellation semantics
        cancelled_status_code: int = 499,
        cancelled_is_error: bool = False,
        environment_resolver: Callable[[], str] | None = default_environment,
    ) -> None:
        self.app = app
        self.project_name = project_name
        self.ip_logging_enabled = ip_logging_enabled
        self.log_4xx_level = log_4xx_level
        self.max_body_bytes = max_body_bytes

        self.capture_body_statuses = capture_body_statuses
        self.capture_only_json = capture_only_json

        self.sensitive_keys = {k.lower() for k in sensitive_keys}
        self.sanitize_max_depth = sanitize_max_depth
        self.sanitize_max_list = sanitize_max_list
        self.sanitize_max_str = sanitize_max_str

        self.include_endpoint_source = include_endpoint_source
        self.cache_endpoint_source = cache_endpoint_source
        self._endpoint_source_cache: dict[int, tuple[str | None, int | None]] = {}

        self.cancelled_status_code = cancelled_status_code
        self.cancelled_is_error = cancelled_is_error
        self.environment_resolver = environment_resolver

        # Best-effort host/IP; never crash.
        self._service_host = socket.gethostname() or None
        self._service_ip = None
        if self._service_host:
            try:
                # In containerized envs this may be meaningless; it's OK if it fails.
                self._service_ip = socket.gethostbyname(self._service_host)
            except OSError:
                self._service_ip = None

    @staticmethod
    def _state_get(scope: Scope, key: str) -> Any:
        """Read a key from ASGI ``state`` supporting dict and object forms."""
        state = scope.get("state")
        if state is None:
            return None
        if isinstance(state, dict):
            return state.get(key)
        return getattr(state, key, None)

    @staticmethod
    def _build_message(status_code: int) -> str:
        """Return standard reason phrase for a status code."""
        try:
            return HTTPStatus(status_code).phrase
        except ValueError:
            return f"HTTP {status_code}"

    @staticmethod
    def _get_path_with_query(scope: Scope) -> str:
        """Build request path including query string when available."""
        path = str(scope.get("path", ""))
        query = scope.get("query_string", b"")
        if not query:
            return path
        try:
            return f"{path}?{query.decode('latin-1')}"
        except UnicodeDecodeError:
            return path

    @staticmethod
    def _client_ip(scope: Scope) -> str | None:
        """Extract client IP from ASGI ``scope['client']``."""
        client = scope.get("client")
        if isinstance(client, tuple) and client:
            return str(client[0])
        return None

    def _format_request(self, scope: Scope) -> dict[str, Any]:
        """Build the normalized request payload written into logs."""
        headers = Headers(raw=list(scope.get("headers", [])))
        return {
            "id": self._state_get(scope, "request_id"),
            "correlation_id": self._state_get(scope, "correlation_id"),
            "type": "HTTP",
            "method": str(scope.get("method", "")),
            "path": self._get_path_with_query(scope),
            "ip": self._client_ip(scope) if self.ip_logging_enabled else None,
            "user_agent": headers.get("user-agent"),
        }

    @staticmethod
    def _parse_json_body(body_chunks: list[bytes]) -> Any:
        """Parse captured response body chunks as JSON when possible."""
        if not body_chunks:
            return None
        try:
            return json.loads(b"".join(body_chunks).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return None

    @staticmethod
    def _is_json_content_type(content_type: str) -> bool:
        """
        Accept application/json, application/*+json, and tolerate parameters.
        """
        if not content_type:
            return False
        media = content_type.split(";", 1)[0].strip().lower()
        return media == "application/json" or media.endswith("+json")

    def _sanitize(self, obj: Any, *, _depth: int = 0) -> Any:
        """
        Best-effort sanitization:
        - Redact sensitive keys (case-insensitive).
        - Bound recursion depth.
        - Bound list size.
        - Bound string size.
        """
        if _depth > self.sanitize_max_depth:
            return "<truncated:depth>"

        if obj is None or isinstance(obj, (bool, int, float)):
            return obj

        if isinstance(obj, str):
            if len(obj) > self.sanitize_max_str:
                return obj[: self.sanitize_max_str] + "<truncated>"
            return obj

        if isinstance(obj, bytes):
            # Don't log bytes blobs.
            return "<bytes>"

        if isinstance(obj, list):
            if len(obj) > self.sanitize_max_list:
                return [
                    self._sanitize(x, _depth=_depth + 1)
                    for x in obj[: self.sanitize_max_list]
                ] + ["<truncated:list>"]
            return [self._sanitize(x, _depth=_depth + 1) for x in obj]

        if isinstance(obj, dict):
            out: dict[str, Any] = {}
            for k, v in obj.items():
                key_str = str(k)
                if key_str.lower() in self.sensitive_keys:
                    out[key_str] = "<redacted>"
                else:
                    out[key_str] = self._sanitize(v, _depth=_depth + 1)
            return out

        # Fallback: avoid huge reprs
        s = str(obj)
        if len(s) > self.sanitize_max_str:
            return s[: self.sanitize_max_str] + "<truncated>"
        return s

    def _environment(self) -> str:
        """Resolve environment name safely using injected resolver fallback."""
        if callable(self.environment_resolver):
            try:
                return str(self.environment_resolver())
            except Exception:
                return str(resolve_env_value())
        return str(resolve_env_value())

    def _bind_initial(self, request_dict: dict[str, Any]) -> None:
        """Bind baseline structlog context for the current request."""
        structlog.contextvars.bind_contextvars(
            timestamp=datetime.now(timezone.utc).isoformat(),
            level=None,
            environment=self._environment(),
            event_name=None,
            service={"host": self._service_host, "ip": self._service_ip},
            user={
                "id": None,
                "email": None,
                "username": None,
                "first_name": None,
                "last_name": None,
            },
            request=request_dict,
            response={
                "error": None,
                "status_code": None,
                "message": None,
                "body": None,
            },
            system={"logger": None, "filename": None, "lineno": None},
            exception=None,
            event=None,
            duration_ms=None,
        )

    def _bind_system_and_event(self, scope: Scope) -> None:
        """Bind endpoint-derived ``event_name`` and optional source location."""
        endpoint = scope.get("endpoint")
        route = scope.get("route")

        module_name = getattr(endpoint, "__module__", None) if endpoint else None
        view_name = getattr(endpoint, "__name__", None) if endpoint else None
        route_name = getattr(route, "name", None)

        event_name = (
            f"{self.project_name}/"
            f"{module_name or 'null'}/"
            f"{route_name or view_name or 'null'}"
        )

        filename: str | None = None
        line_number: int | None = None

        if self.include_endpoint_source and endpoint:
            cache_key = id(endpoint)
            if self.cache_endpoint_source and cache_key in self._endpoint_source_cache:
                filename, line_number = self._endpoint_source_cache[cache_key]
            else:
                try:
                    filename = getsourcefile(endpoint)
                    line_number = getsourcelines(endpoint)[1]
                except (OSError, TypeError):
                    filename = None
                    line_number = None
                if self.cache_endpoint_source:
                    self._endpoint_source_cache[cache_key] = (filename, line_number)

        structlog.contextvars.bind_contextvars(
            event_name=event_name,
            system={"logger": None, "filename": filename, "lineno": line_number},
        )

    @staticmethod
    def bind_user(scope: Scope) -> None:
        """Bind authenticated user information from ASGI state when present."""
        user_data: dict[str, str | None] = {
            "id": None,
            "email": None,
            "username": None,
            "first_name": None,
            "last_name": None,
        }
        state = scope.get("state")

        user = None
        auth = None
        if isinstance(state, dict):
            user = state.get("user")
            auth = state.get("auth")
        elif state is not None:
            user = getattr(state, "user", None)
            auth = getattr(state, "auth", None)

        if user and getattr(user, "is_authenticated", False):
            user_data["id"] = str(getattr(user, "pk", None) or getattr(user, "id", ""))
            user_data["email"] = getattr(user, "email", None)
            user_data["username"] = getattr(user, "username", None)
            user_data["first_name"] = getattr(user, "first_name", None)
            user_data["last_name"] = getattr(user, "last_name", None)
        elif isinstance(auth, dict):
            user_data["id"] = str(auth.get("sub", None))
            user_data["email"] = auth.get("email", None)
            user_data["username"] = auth.get("username", None)
            user_data["first_name"] = auth.get("firstName", None)
            user_data["last_name"] = auth.get("lastName", None)

        structlog.contextvars.bind_contextvars(user=user_data)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Handle request lifecycle and emit a single structured completion log."""
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return

        started_at = perf_counter()
        status_code = 500
        response_headers: list[tuple[bytes, bytes]] = []

        # capture buffers
        body_chunks: list[bytes] = []
        captured_bytes = 0
        should_capture_body = False

        logged = False

        # Build request dict once, bind once
        request_dict = self._format_request(scope)
        self._bind_initial(request_dict)
        self.bind_user(scope)

        def finalize(
            *,
            status: int,
            is_error: bool,
            message: str,
            body: Any = None,
            cancelled: bool = False,
            log_exception: bool = False,
        ) -> None:
            nonlocal logged
            if logged:
                return

            self._bind_system_and_event(scope)

            duration_ms = round((perf_counter() - started_at) * 1000, 2)

            response_obj = {
                "error": is_error,
                "status_code": status,
                "message": message,
                "body": body,
            }

            log_kwargs = {
                "request": request_dict,
                "response": response_obj,
                "duration_ms": duration_ms,
                "cancelled": cancelled,
            }

            if status >= 500:
                level = logging.ERROR
            elif status >= 400:
                level = self.log_4xx_level
            else:
                level = logging.INFO

            if log_exception:
                logger.exception("request completed with error", **log_kwargs)
            else:
                logger.log(level, "request completed", **log_kwargs)

            logged = True

        async def send_wrapper(message: Message) -> None:
            nonlocal status_code, response_headers, should_capture_body, captured_bytes

            if message["type"] == "http.response.start":
                status_code = int(message.get("status", 500))
                response_headers = list(message.get("headers", []))

                if status_code in self.capture_body_statuses:
                    if not self.capture_only_json:
                        should_capture_body = True
                    else:
                        content_type = (
                            Headers(raw=response_headers).get("content-type") or ""
                        ).lower()
                        should_capture_body = self._is_json_content_type(content_type)
                else:
                    should_capture_body = False

            if message["type"] == "http.response.body":
                if should_capture_body and message.get("body"):
                    body = message.get("body", b"") or b""
                    if captured_bytes < self.max_body_bytes and body:
                        remaining = self.max_body_bytes - captured_bytes
                        if remaining > 0:
                            chunk = body[:remaining]
                            body_chunks.append(chunk)
                            captured_bytes += len(chunk)

            await send(message)

            if (
                message["type"] == "http.response.body"
                and message.get("more_body", False) is False
            ):
                response_body = None
                if should_capture_body:
                    parsed = self._parse_json_body(body_chunks)
                    response_body = (
                        self._sanitize(parsed) if parsed is not None else None
                    )

                finalize(
                    status=status_code,
                    is_error=status_code >= 500,
                    message=self._build_message(status_code),
                    body=response_body,
                )

        try:
            await self.app(scope, receive, send_wrapper)
        except asyncio.CancelledError:
            finalize(
                status=self.cancelled_status_code,
                is_error=self.cancelled_is_error,
                message="Request cancelled",
                body=None,
                cancelled=True,
                log_exception=False,
            )
            raise
        except Exception:
            # finalize inside except so logger.exception captures sys.exc_info()
            finalize(
                status=500,
                is_error=True,
                message="Internal Server Error",
                body=None,
                cancelled=False,
                log_exception=True,
            )
            raise
        finally:
            if not logged:
                if response_headers:
                    finalize(
                        status=status_code,
                        is_error=status_code >= 500,
                        message=self._build_message(status_code),
                        body=None,
                    )
                else:
                    finalize(
                        status=500,
                        is_error=True,
                        message="No response generated",
                        body=None,
                    )
            structlog.contextvars.clear_contextvars()
