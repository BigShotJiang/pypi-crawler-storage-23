"""Runtime option resolution helpers.

This module centralizes how the package resolves environment-related values so
FastAPI and Celery paths behave consistently.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

DEFAULT_ENV_VALUE = "development"
DEFAULT_ENV_VARIABLES = ("ENV", "APP_ENV", "FASTAPI_ENV", "ENVIRONMENT")
BASE_DIR_ENV_VARIABLES = (
    "FASTAPI_CELERY_STRUCTLOG_BASE_DIR",
    "BASE_DIR",
    "APP_BASE_DIR",
)
ROOT_MARKERS = ("pyproject.toml", ".git")


def _coerce_env_value(value: Any) -> str:
    """Normalize an environment-like value to a stripped string.

    Supports plain strings and enum-like objects exposing a ``.value``
    attribute.
    """
    if value is None:
        return ""
    if hasattr(value, "value"):
        value = value.value
    return str(value).strip()


def resolve_env_value(
    env_value: Any = None,
    *,
    env_vars: tuple[str, ...] = DEFAULT_ENV_VARIABLES,
    default: str = DEFAULT_ENV_VALUE,
) -> str:
    """Resolve environment name used in log context and renderer selection.

    Resolution order:
    1. Explicit ``env_value`` argument.
    2. First non-empty value from ``env_vars``.
    3. ``default``.
    """
    explicit = _coerce_env_value(env_value)
    if explicit:
        return explicit

    for name in env_vars:
        candidate = _coerce_env_value(os.getenv(name))
        if candidate:
            return candidate

    return default


def _find_project_root(start_path: Path) -> Path:
    """Walk up from ``start_path`` and return the first directory with markers."""
    start = start_path.resolve()
    candidates = [start, *start.parents]
    for candidate in candidates:
        for marker in ROOT_MARKERS:
            if (candidate / marker).exists():
                return candidate
    return start


def resolve_base_dir(
    base_dir: str | Path | None = None,
    *,
    base_dir_env_vars: tuple[str, ...] = BASE_DIR_ENV_VARIABLES,
    start_path: str | Path | None = None,
) -> Path:
    """Resolve the base directory used for log file output.

    Resolution order:
    1. Explicit ``base_dir`` argument.
    2. First non-empty value from ``base_dir_env_vars``.
    3. Auto-discovered project root from ``start_path``/``cwd``.
    """
    if base_dir is not None:
        return Path(base_dir).expanduser().resolve()

    for var_name in base_dir_env_vars:
        value = os.getenv(var_name)
        if value:
            return Path(value).expanduser().resolve()

    initial = Path(start_path).expanduser() if start_path is not None else Path.cwd()
    if initial.is_file():
        initial = initial.parent
    return _find_project_root(initial)


def resolve_runtime_options(
    *,
    base_dir: str | Path | None = None,
    env_value: Any = None,
    start_path: str | Path | None = None,
) -> tuple[Path, str]:
    """Resolve both ``base_dir`` and ``env_value`` in one call."""
    return (
        resolve_base_dir(base_dir=base_dir, start_path=start_path),
        resolve_env_value(env_value=env_value),
    )
