"""Public package API for fastapi-celery-structlog."""

from pathlib import Path
from typing import Any

__version__ = "0.1.0"

__all__ = ["configure_logging", "__version__"]


def configure_logging(
    base_dir: str | Path | None = None,
    env_value: Any = None,
) -> None:
    """Lazily import and call :func:`fastapi_celery_structlog.settings.configure_logging`."""
    from .settings import configure_logging as _configure_logging

    return _configure_logging(base_dir=base_dir, env_value=env_value)
