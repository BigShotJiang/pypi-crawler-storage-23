import uvicorn
from fastapi import FastAPI

if __package__ is None or __package__ == "":
    from _bootstrap import ensure_project_root_on_path

    ensure_project_root_on_path()

from fastapi_celery_structlog import configure_logging
from fastapi_celery_structlog.middlewares import (
    RequestIDMiddleware,
    StructlogRequestMiddleware,
)

if __package__ is None or __package__ == "":
    from tasks import add_task
else:
    from .tasks import add_task

configure_logging()

app = FastAPI(title="fastapi-celery-structlog demo")
app.add_middleware(StructlogRequestMiddleware, project_name="demo-service")
app.add_middleware(RequestIDMiddleware)


def health() -> dict[str, str]:
    return {"status": "ok"}


def queue_add_task(a: int, b: int) -> dict[str, str]:
    result = add_task.delay(a, b)
    return {"task_id": result.id}


app.add_api_route("/health", health, methods=["GET"])
app.add_api_route("/tasks/add", queue_add_task, methods=["POST"])


if __name__ == "__main__":
    uvicorn.run(
        "__main__:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="debug",
        access_log=True,
        log_config=None,
    )
