from celery import Celery

if __package__ is None or __package__ == "":
    from _bootstrap import ensure_project_root_on_path

    ensure_project_root_on_path()

from fastapi_celery_structlog.celery import configure_celery_logging

celery_app = Celery(
    "fastapi_celery_demo",
    broker="redis://localhost:6379/0",
    backend="redis://localhost:6379/1",
    include=["examples.fastapi_celery_demo.tasks"],
)

configure_celery_logging(celery_app=celery_app)
