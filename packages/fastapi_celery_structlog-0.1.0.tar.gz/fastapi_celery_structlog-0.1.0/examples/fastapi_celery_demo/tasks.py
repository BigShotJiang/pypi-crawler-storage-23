if __package__ is None or __package__ == "":
    from _bootstrap import ensure_project_root_on_path

    ensure_project_root_on_path()
    from celery_app import celery_app as demo_celery_app
else:
    from .celery_app import celery_app as demo_celery_app


def add(a: int, b: int) -> int:
    return a + b


add_task = demo_celery_app.task(name="examples.add")(add)
