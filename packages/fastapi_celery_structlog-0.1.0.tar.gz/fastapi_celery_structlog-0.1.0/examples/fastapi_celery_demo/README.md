# FastAPI + Celery Demo

This example shows how to use `fastapi-celery-structlog` in both web app and worker.

## Prerequisites

- Redis running on `localhost:6379`
- Project dependencies installed

## Run FastAPI API

From project root (recommended):

```bash
uv run uvicorn examples.fastapi_celery_demo.api:app --reload
```

Or from this directory:

```bash
python api.py
```

## Run Celery Worker

From project root (recommended):

```bash
uv run celery -A examples.fastapi_celery_demo.celery_app:celery_app worker -l INFO
```

Or from this directory:

```bash
celery -A celery_app:celery_app worker -l INFO
```

## Trigger a Task

```bash
curl -X POST "http://127.0.0.1:8000/tasks/add?a=10&b=32"
```

You should see a task id in the API response and structured logs in console and `logs/app.json.log`.
