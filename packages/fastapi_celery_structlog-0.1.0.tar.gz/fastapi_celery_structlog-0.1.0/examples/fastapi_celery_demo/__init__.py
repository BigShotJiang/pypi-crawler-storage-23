"""Runnable FastAPI + Celery demo for fastapi-celery-structlog."""
