import os
import tempfile
import unittest
from pathlib import Path

from fastapi_celery_structlog.runtime import resolve_base_dir, resolve_env_value


class DummyEnv:
    def __init__(self, value: str) -> None:
        self.value = value


class RuntimeTests(unittest.TestCase):
    def test_env_value_prefers_explicit_value(self) -> None:
        self.assertEqual(resolve_env_value(env_value="staging"), "staging")
        self.assertEqual(resolve_env_value(env_value=DummyEnv("prod")), "prod")

    def test_env_value_reads_environment_variable(self) -> None:
        old = os.environ.get("ENV")
        try:
            os.environ["ENV"] = "qa"
            self.assertEqual(resolve_env_value(), "qa")
        finally:
            if old is None:
                os.environ.pop("ENV", None)
            else:
                os.environ["ENV"] = old

    def test_resolve_base_dir_prefers_explicit_path(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            path = resolve_base_dir(base_dir=tmp)
            self.assertEqual(path, Path(tmp).resolve())

    def test_resolve_base_dir_from_env(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            old = os.environ.get("FASTAPI_CELERY_STRUCTLOG_BASE_DIR")
            try:
                os.environ["FASTAPI_CELERY_STRUCTLOG_BASE_DIR"] = tmp
                path = resolve_base_dir()
                self.assertEqual(path, Path(tmp).resolve())
            finally:
                if old is None:
                    os.environ.pop("FASTAPI_CELERY_STRUCTLOG_BASE_DIR", None)
                else:
                    os.environ["FASTAPI_CELERY_STRUCTLOG_BASE_DIR"] = old


if __name__ == "__main__":
    unittest.main()
