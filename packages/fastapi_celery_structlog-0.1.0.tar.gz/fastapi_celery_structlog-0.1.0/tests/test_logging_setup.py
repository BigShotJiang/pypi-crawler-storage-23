import tempfile
import unittest
from pathlib import Path

try:
    from fastapi_celery_structlog.celery.logger import configure_celery_logging
    from fastapi_celery_structlog.settings import configure_logging
except ModuleNotFoundError as exc:
    if exc.name == "structlog":
        raise unittest.SkipTest("structlog is not installed in this environment")
    raise


class DummyConf:
    worker_hijack_root_logger = True


class DummyCeleryApp:
    conf = DummyConf()


class LoggingSetupTests(unittest.TestCase):
    def test_configure_logging_creates_logs_dir(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            configure_logging(base_dir=tmp, env_value="development")
            logs_dir = Path(tmp) / "logs"
            self.assertTrue(logs_dir.exists())
            self.assertTrue(logs_dir.is_dir())

    def test_configure_celery_logging_sets_worker_hijack_flag(self) -> None:
        app = DummyCeleryApp()
        with tempfile.TemporaryDirectory() as tmp:
            configure_celery_logging(
                celery_app=app,
                base_dir=tmp,
                env_value="production",
                worker_hijack_root_logger=False,
            )
        self.assertFalse(app.conf.worker_hijack_root_logger)


if __name__ == "__main__":
    unittest.main()
