# Release Guide

Use this checklist to publish `fastapi-celery-structlog`.

## 1) Bump Version

Update version in:

- `pyproject.toml` (`[project].version`)
- `fastapi_celery_structlog/__init__.py` (`__version__`)

## 2) Run Quality Checks

```bash
uv sync --dev
uv run pre-commit run --all-files
uv run python -m unittest discover -s tests -v
```

## 3) Build Distribution

```bash
uv run python -m build
```

Artifacts are created in `dist/` (`.whl` and `.tar.gz`).

## 4) Validate Metadata

```bash
uv run twine check dist/*
```

## 5) Publish

TestPyPI (recommended first):

```bash
uv run twine upload --repository testpypi dist/*
```

PyPI:

```bash
uv run twine upload dist/*
```

## 6) Verify Install

```bash
python -m venv /tmp/fcs-verify
source /tmp/fcs-verify/bin/activate
pip install fastapi-celery-structlog
python -c "import fastapi_celery_structlog as p; print(p.__version__)"
```
