def hello_world():
    """Prints hello."""
    print("Hello World")

class Test:
    def run(self):
        pass

def new_feature():
    return "new"
