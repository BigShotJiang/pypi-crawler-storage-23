import os
import subprocess

os.system("ls")
subprocess.run("ls", shell=True)
eval("2 + 2")