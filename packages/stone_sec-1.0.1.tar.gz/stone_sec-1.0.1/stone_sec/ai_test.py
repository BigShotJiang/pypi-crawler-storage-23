import os

user_input = input("cmd: ")
os.system(user_input)