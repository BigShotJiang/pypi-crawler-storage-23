from polymarklib.markets import fetch_market_by_slug

def test_get_tokens():
    btc_up_down = fetch_market_by_slug("btc-updown-5m-1772135400")
    print(btc_up_down.clob_token_ids)
    return btc_up_down.clob_token_ids