"""MCP server implementation."""

from enyal.mcp.server import mcp

__all__ = ["mcp"]
