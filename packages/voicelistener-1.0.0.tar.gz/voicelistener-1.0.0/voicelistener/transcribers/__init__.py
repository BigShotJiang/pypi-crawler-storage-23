from voicelistener.transcribers.whispertranscriber import WhisperTranscriber

__all__ = ["WhisperTranscriber"]
