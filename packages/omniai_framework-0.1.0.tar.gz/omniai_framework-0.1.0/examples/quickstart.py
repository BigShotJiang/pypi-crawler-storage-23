"""OmniAI Quickstart Example.

Demonstrates the core API: config, registry, model build, train, predict.
"""

from __future__ import annotations

from typing import Any

import numpy as np

import omniai
from omniai import (
    BaseModel,
    BaseTrainer,
    Callback,
    Config,
    EarlyStopping,
    ModelConfig,
    ProgressCallback,
    TrainerConfig,
    detect_hardware,
    get_backend,
    register,
    registry,
    set_seed,
)
from omniai.utils.types import MetricsDict


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Step 1: Check the environment
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

print(f"OmniAI v{omniai.__version__}")
print(f"Available backends: {omniai.list_available_backends()}")
print()

hw = detect_hardware()
print(hw.summary())
print()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Step 2: Define a custom model using the OmniAI API
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@register("example.linear_net", description="Simple linear network", tags=["example", "linear"])
class LinearNet(BaseModel):
    """A simple 2-layer linear network for demonstration."""

    def _build(self) -> None:
        hidden = self.config.get("hidden_size", 64)
        in_dim = self.config.get("input_dim", 10)
        out_dim = self.config.get("output_dim", 1)

        # Simple numpy weights (no framework dependency!)
        self.w1 = np.random.randn(in_dim, hidden).astype(np.float32) * 0.01
        self.b1 = np.zeros(hidden, dtype=np.float32)
        self.w2 = np.random.randn(hidden, out_dim).astype(np.float32) * 0.01
        self.b2 = np.zeros(out_dim, dtype=np.float32)

    def forward(self, x: Any, **kwargs: Any) -> Any:
        # Layer 1 + ReLU
        h = x @ self.w1 + self.b1
        h = np.maximum(h, 0)  # ReLU
        # Layer 2
        return h @ self.w2 + self.b2

    def predict(self, inputs: Any, **kwargs: Any) -> Any:
        return self.forward(inputs)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Step 3: Define a trainer
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

class SimpleTrainer(BaseTrainer):
    """Simple gradient-free trainer using random perturbation (for demo)."""

    def __init__(self, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.lr = self.config.learning_rate
        self.best_loss = float("inf")

    def train_step(self, batch: Any) -> MetricsDict:
        x, y = batch
        # Forward
        pred = self.model(x)
        loss = float(np.mean((pred - y) ** 2))

        # Simple gradient approximation (for demo — no autograd needed)
        if loss < self.best_loss:
            self.best_loss = loss
            # Save current weights
            self._best_w1 = self.model.w1.copy()  # type: ignore[attr-defined]
            self._best_w2 = self.model.w2.copy()  # type: ignore[attr-defined]

        # Random perturbation
        self.model.w1 += np.random.randn(*self.model.w1.shape).astype(np.float32) * self.lr  # type: ignore[attr-defined]
        self.model.w2 += np.random.randn(*self.model.w2.shape).astype(np.float32) * self.lr  # type: ignore[attr-defined]

        return {"loss": loss}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Step 4: Use the config + registry system
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def main() -> None:
    set_seed(42)

    # ── Registry ──────────────────────────────────────────────────────────
    print("Registered models:")
    print(registry.summary())

    # ── Config-driven model creation ──────────────────────────────────────
    config = ModelConfig.from_dict({
        "arch": "example.linear_net",
        "hidden_size": 32,
        "input_dim": 8,
        "output_dim": 1,
    })

    # Build from registry
    model_cls = registry.get("example.linear_net")
    model = model_cls(config=config).build()

    print(model.summary())

    # ── Generate fake data ────────────────────────────────────────────────
    n_samples = 200
    X = np.random.randn(n_samples, 8).astype(np.float32)
    y = (X[:, 0] * 2.0 + X[:, 1] * -1.5 + 0.5).reshape(-1, 1).astype(np.float32)

    # Create batches
    batch_size = 32
    train_data = [
        (X[i : i + batch_size], y[i : i + batch_size])
        for i in range(0, n_samples, batch_size)
    ]

    # ── Train ─────────────────────────────────────────────────────────────
    trainer = SimpleTrainer(
        model=model,
        train_data=train_data,
        config=TrainerConfig(
            epochs=5,
            learning_rate=0.001,
            logging_steps=100,
        ),
        callbacks=[ProgressCallback()],
    )

    history = trainer.fit()

    # ── Results ───────────────────────────────────────────────────────────
    print("\nTraining History:")
    for i, epoch_metrics in enumerate(history):
        print(f"  Epoch {i + 1}: {epoch_metrics}")

    # ── Predict ───────────────────────────────────────────────────────────
    test_input = np.random.randn(3, 8).astype(np.float32)
    predictions = model.predict(test_input)
    print(f"\nPredictions shape: {predictions.shape}")
    print(f"Predictions: {predictions.flatten()}")

    # ── Backend info ──────────────────────────────────────────────────────
    backend = get_backend()
    print(f"\nActive backend: {backend.name}")
    print(f"Backend tensor test: {backend.shape(backend.randn((3, 4)))}")

    print("\n✅ OmniAI quickstart complete!")


if __name__ == "__main__":
    main()
