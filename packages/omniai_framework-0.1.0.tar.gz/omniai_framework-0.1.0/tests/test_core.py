"""Tests for OmniAI core module — BaseModel, BaseTrainer, Config, Registry."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Any

import numpy as np
import pytest

from omniai.core.base import BaseModel, BaseTrainer
from omniai.core.callbacks import (
    Callback,
    EarlyStopping,
    MetricsLogger,
    ModelCheckpoint,
    ProgressCallback,
)
from omniai.core.config import Config, ModelConfig, TrainerConfig
from omniai.core.hardware import detect_hardware, get_available_devices, get_optimal_device
from omniai.core.registry import ModelRegistry, register, registry
from omniai.utils.exceptions import (
    ConfigFileError,
    DuplicateRegistrationError,
    ModelNotFoundError,
)
from omniai.utils.types import MetricsDict, ModelPhase


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Config Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestConfig:
    """Tests for the Config system."""

    def test_basic_creation(self) -> None:
        config = Config(arch="test.model", name="my_model")
        assert config.arch == "test.model"
        assert config.name == "my_model"

    def test_model_config_defaults(self) -> None:
        config = ModelConfig()
        assert config.hidden_size == 768
        assert config.num_layers == 12
        assert config.num_heads == 12
        assert config.vocab_size == 32000

    def test_from_dict(self) -> None:
        data = {"arch": "transformer.bert", "hidden_size": 1024, "custom_field": "hello"}
        config = ModelConfig.from_dict(data)
        assert config.arch == "transformer.bert"
        assert config.hidden_size == 1024
        assert config.get("custom_field") == "hello"

    def test_to_dict(self) -> None:
        config = ModelConfig(arch="test", hidden_size=512)
        d = config.to_dict()
        assert d["arch"] == "test"
        assert d["hidden_size"] == 512

    def test_yaml_roundtrip(self) -> None:
        config = ModelConfig(arch="test.model", hidden_size=2048, num_layers=24)
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "config.yaml"
            config.to_yaml(path)
            loaded = ModelConfig.from_yaml(path)
            assert loaded.arch == "test.model"
            assert loaded.hidden_size == 2048
            assert loaded.num_layers == 24

    def test_json_roundtrip(self) -> None:
        config = ModelConfig(arch="test.model", hidden_size=4096)
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "config.json"
            config.to_json(path)
            loaded = ModelConfig.from_json(path)
            assert loaded.arch == "test.model"
            assert loaded.hidden_size == 4096

    def test_merge(self) -> None:
        base = ModelConfig(arch="base", hidden_size=512)
        overlay = {"hidden_size": 1024, "num_layers": 6}
        merged = base.merge(overlay)
        assert merged.arch == "base"  # Kept from base
        assert merged.get("hidden_size") == 1024  # Overridden
        assert merged.get("num_layers") == 6

    def test_dict_access(self) -> None:
        config = Config(arch="test")
        assert config["arch"] == "test"
        assert "arch" in config
        with pytest.raises(KeyError):
            _ = config["nonexistent"]

    def test_copy(self) -> None:
        config = ModelConfig(arch="test", hidden_size=512)
        copied = config.copy()
        copied.hidden_size = 1024  # type: ignore[attr-defined]
        assert config.hidden_size == 512  # Original unchanged

    def test_yaml_file_not_found(self) -> None:
        with pytest.raises(ConfigFileError):
            Config.from_yaml("/nonexistent/path.yaml")

    def test_json_file_not_found(self) -> None:
        with pytest.raises(ConfigFileError):
            Config.from_json("/nonexistent/path.json")

    def test_extra_params(self) -> None:
        data = {"arch": "test", "custom_param": 42, "nested": {"a": 1}}
        config = Config.from_dict(data)
        assert config.get("custom_param") == 42
        assert config.get("nested") == {"a": 1}
        assert config.get("missing", "default") == "default"

    def test_trainer_config(self) -> None:
        config = TrainerConfig(
            optimizer="adam",
            learning_rate=3e-4,
            epochs=10,
            batch_size=64,
        )
        assert config.optimizer == "adam"
        assert config.learning_rate == 3e-4
        assert config.epochs == 10

    def test_str_repr(self) -> None:
        config = Config(arch="test")
        assert "test" in str(config)
        assert "Config" in repr(config)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Registry Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestRegistry:
    """Tests for the ModelRegistry."""

    def setup_method(self) -> None:
        """Create a fresh registry for each test."""
        self.reg = ModelRegistry()

    def test_register_and_get(self) -> None:
        @self.reg.register("test.model_a")
        class ModelA(BaseModel):
            def _build(self) -> None:
                pass
            def forward(self, *args: Any, **kwargs: Any) -> Any:
                return None
        
        retrieved = self.reg.get("test.model_a")
        assert retrieved is ModelA

    def test_register_direct(self) -> None:
        class ModelB(BaseModel):
            def _build(self) -> None:
                pass
            def forward(self, *args: Any, **kwargs: Any) -> Any:
                return None

        self.reg.register("test.model_b", ModelB)
        assert self.reg.get("test.model_b") is ModelB

    def test_duplicate_registration(self) -> None:
        class ModelC(BaseModel):
            def _build(self) -> None:
                pass
            def forward(self, *args: Any, **kwargs: Any) -> Any:
                return None

        self.reg.register("test.dup", ModelC)
        with pytest.raises(DuplicateRegistrationError):
            self.reg.register("test.dup", ModelC)

    def test_force_registration(self) -> None:
        class ModelD(BaseModel):
            def _build(self) -> None:
                pass
            def forward(self, *args: Any, **kwargs: Any) -> Any:
                return None

        class ModelD2(BaseModel):
            def _build(self) -> None:
                pass
            def forward(self, *args: Any, **kwargs: Any) -> Any:
                return None

        self.reg.register("test.force", ModelD)
        self.reg.register("test.force", ModelD2, force=True)
        assert self.reg.get("test.force") is ModelD2

    def test_model_not_found(self) -> None:
        with pytest.raises(ModelNotFoundError):
            self.reg.get("nonexistent.model")

    def test_list_models(self) -> None:
        class M1(BaseModel):
            def _build(self) -> None: pass
            def forward(self, *a: Any, **kw: Any) -> Any: return None

        class M2(BaseModel):
            def _build(self) -> None: pass
            def forward(self, *a: Any, **kw: Any) -> Any: return None

        self.reg.register("alpha.m1", M1)
        self.reg.register("beta.m2", M2)

        all_models = self.reg.list_models()
        assert "alpha.m1" in all_models
        assert "beta.m2" in all_models

        alpha_only = self.reg.list_models(category="alpha")
        assert "alpha.m1" in alpha_only
        assert "beta.m2" not in alpha_only

    def test_list_categories(self) -> None:
        class M(BaseModel):
            def _build(self) -> None: pass
            def forward(self, *a: Any, **kw: Any) -> Any: return None

        self.reg.register("cat_a.model", M)
        self.reg.register("cat_b.model", M, force=True)
        categories = self.reg.list_categories()
        assert "cat_a" in categories
        assert "cat_b" in categories

    def test_search(self) -> None:
        class M(BaseModel):
            def _build(self) -> None: pass
            def forward(self, *a: Any, **kw: Any) -> Any: return None

        self.reg.register("transformer.bert", M, tags=["nlp", "encoder"])
        self.reg.register("transformer.gpt2", M, tags=["nlp", "decoder"], force=True)
        self.reg.register("classical.svm", M, tags=["classification"], force=True)

        results = self.reg.search("transformer.*")
        assert "transformer.bert" in results
        assert "transformer.gpt2" in results
        assert "classical.svm" not in results

        tag_results = self.reg.search("nlp")
        assert len(tag_results) == 2

    def test_info(self) -> None:
        class M(BaseModel):
            """A test model."""
            def _build(self) -> None: pass
            def forward(self, *a: Any, **kw: Any) -> Any: return None

        self.reg.register("test.info_model", M, description="Test model", tags=["test"])
        info = self.reg.info("test.info_model")
        assert "test.info_model" in info
        assert "Test model" in info

    def test_contains(self) -> None:
        class M(BaseModel):
            def _build(self) -> None: pass
            def forward(self, *a: Any, **kw: Any) -> Any: return None

        self.reg.register("test.exists", M)
        assert "test.exists" in self.reg
        assert "test.nope" not in self.reg

    def test_len(self) -> None:
        assert len(self.reg) == 0
        class M(BaseModel):
            def _build(self) -> None: pass
            def forward(self, *a: Any, **kw: Any) -> Any: return None
        self.reg.register("test.len", M)
        assert len(self.reg) == 1

    def test_summary(self) -> None:
        summary = self.reg.summary()
        assert "No models registered" in summary

    def test_case_insensitive(self) -> None:
        class M(BaseModel):
            def _build(self) -> None: pass
            def forward(self, *a: Any, **kw: Any) -> Any: return None
        self.reg.register("Test.CaseModel", M)
        assert self.reg.get("test.casemodel") is M


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# BaseModel Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class SimpleModel(BaseModel):
    """A minimal concrete model for testing."""

    def _build(self) -> None:
        self._weight = np.random.randn(10, 5).astype(np.float32)

    def forward(self, x: Any, **kwargs: Any) -> Any:
        return x @ self._weight

    def predict(self, inputs: Any, **kwargs: Any) -> Any:
        return self.forward(inputs)


class TestBaseModel:
    """Tests for BaseModel."""

    def test_creation(self) -> None:
        model = SimpleModel(config=ModelConfig(arch="test.simple"))
        assert model.phase == ModelPhase.INITIALIZED
        assert not model.is_built

    def test_build(self) -> None:
        model = SimpleModel(config=ModelConfig(arch="test.simple"))
        result = model.build()
        assert result is model  # Returns self for chaining
        assert model.is_built
        assert model.phase == ModelPhase.BUILT

    def test_forward(self) -> None:
        model = SimpleModel(config=ModelConfig(arch="test.simple"))
        model.build()
        x = np.random.randn(3, 10).astype(np.float32)
        output = model(x)
        assert output.shape == (3, 5)

    def test_predict(self) -> None:
        model = SimpleModel(config=ModelConfig(arch="test.simple"))
        model.build()
        x = np.random.randn(3, 10).astype(np.float32)
        output = model.predict(x)
        assert output.shape == (3, 5)

    def test_from_config_dict(self) -> None:
        model = SimpleModel(config={"arch": "test.simple", "hidden_size": 256})
        assert model.config.get("arch") == "test.simple"

    def test_from_config_kwargs(self) -> None:
        model = SimpleModel(arch="test.simple", hidden_size=256)
        assert model.config.get("arch") == "test.simple"

    def test_save_load(self) -> None:
        model = SimpleModel(config=ModelConfig(arch="test.simple"))
        model.build()
        with tempfile.TemporaryDirectory() as tmpdir:
            model.save(tmpdir)
            assert (Path(tmpdir) / "config.json").exists()
            assert (Path(tmpdir) / "metadata.json").exists()

    def test_summary(self) -> None:
        model = SimpleModel(config=ModelConfig(arch="test.simple"))
        model.build()
        summary = model.summary()
        assert "SimpleModel" in summary
        assert "test.simple" in summary

    def test_repr(self) -> None:
        model = SimpleModel(config=ModelConfig(arch="test.simple"))
        r = repr(model)
        assert "SimpleModel" in r


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# BaseTrainer Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class SimpleTrainer(BaseTrainer):
    """A minimal concrete trainer for testing."""

    def train_step(self, batch: Any) -> MetricsDict:
        x, y = batch
        pred = self.model(x)
        loss = float(np.mean((pred - y) ** 2))
        return {"loss": loss}


class TestBaseTrainer:
    """Tests for BaseTrainer."""

    def _make_data(self, n_batches: int = 5) -> list[tuple[Any, Any]]:
        """Create simple fake data."""
        return [
            (
                np.random.randn(4, 10).astype(np.float32),
                np.random.randn(4, 5).astype(np.float32),
            )
            for _ in range(n_batches)
        ]

    def test_creation(self) -> None:
        model = SimpleModel().build()
        trainer = SimpleTrainer(model=model)
        assert trainer.global_step == 0
        assert trainer.current_epoch == 0

    def test_fit(self) -> None:
        model = SimpleModel().build()
        data = self._make_data()
        trainer = SimpleTrainer(
            model=model,
            train_data=data,
            config=TrainerConfig(epochs=2, logging_steps=100),
        )
        history = trainer.fit()
        assert len(history) == 2
        assert "loss" in history[0]
        assert trainer.global_step == 10  # 2 epochs * 5 batches

    def test_evaluate(self) -> None:
        model = SimpleModel().build()
        data = self._make_data()
        trainer = SimpleTrainer(model=model)
        metrics = trainer.evaluate(data)
        assert "loss" in metrics

    def test_callbacks(self) -> None:
        model = SimpleModel().build()
        data = self._make_data()

        class TrackingCallback(Callback):
            def __init__(self) -> None:
                self.events: list[str] = []
            def on_train_begin(self, trainer: Any) -> None:
                self.events.append("train_begin")
            def on_epoch_begin(self, trainer: Any, epoch: int) -> None:
                self.events.append(f"epoch_begin_{epoch}")
            def on_epoch_end(self, trainer: Any, epoch: int, metrics: Any) -> None:
                self.events.append(f"epoch_end_{epoch}")
            def on_train_end(self, trainer: Any) -> None:
                self.events.append("train_end")

        tracker = TrackingCallback()
        trainer = SimpleTrainer(
            model=model,
            train_data=data,
            callbacks=[tracker],
            config=TrainerConfig(epochs=2, logging_steps=100),
        )
        trainer.fit()

        assert "train_begin" in tracker.events
        assert "epoch_begin_0" in tracker.events
        assert "epoch_end_0" in tracker.events
        assert "epoch_end_1" in tracker.events
        assert "train_end" in tracker.events

    def test_model_phase_tracking(self) -> None:
        model = SimpleModel().build()
        data = self._make_data(2)
        trainer = SimpleTrainer(
            model=model,
            train_data=data,
            config=TrainerConfig(epochs=1, logging_steps=100),
        )
        assert model.phase == ModelPhase.BUILT
        trainer.fit()
        assert model.phase == ModelPhase.TRAINED

    def test_history(self) -> None:
        model = SimpleModel().build()
        data = self._make_data()
        trainer = SimpleTrainer(
            model=model,
            train_data=data,
            config=TrainerConfig(epochs=3, logging_steps=100),
        )
        trainer.fit()
        assert len(trainer.history) == 3


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Hardware Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestHardware:
    """Tests for hardware detection."""

    def test_detect_hardware(self) -> None:
        info = detect_hardware()
        assert info.cpu_count >= 1
        assert info.os_name != ""
        assert info.python_version != ""

    def test_get_optimal_device(self) -> None:
        device = get_optimal_device()
        assert device in ("cpu", "cuda", "mps", "xla")

    def test_get_available_devices(self) -> None:
        devices = get_available_devices()
        assert "cpu" in devices

    def test_hardware_summary(self) -> None:
        info = detect_hardware()
        summary = info.summary()
        assert "OmniAI Hardware Report" in summary
        assert "CPU" in summary


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Backend Tests
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestBackends:
    """Tests for the backend abstraction."""

    def test_numpy_backend_available(self) -> None:
        from omniai.backends import get_backend
        backend = get_backend("numpy")
        assert backend.is_available
        assert backend.name == "numpy"

    def test_numpy_tensor_ops(self) -> None:
        from omniai.backends import get_backend
        backend = get_backend("numpy")

        # Creation
        z = backend.zeros((3, 4))
        assert backend.shape(z) == (3, 4)

        o = backend.ones((2, 3))
        assert np.allclose(backend.to_numpy(o), 1.0)

        r = backend.randn((5, 5))
        assert backend.shape(r) == (5, 5)

    def test_numpy_math_ops(self) -> None:
        from omniai.backends import get_backend
        backend = get_backend("numpy")

        a = backend.tensor([[1.0, 2.0], [3.0, 4.0]])
        b = backend.tensor([[5.0, 6.0], [7.0, 8.0]])

        # Matmul
        c = backend.matmul(a, b)
        expected = np.array([[19.0, 22.0], [43.0, 50.0]])
        assert np.allclose(backend.to_numpy(c), expected)

        # Add
        s = backend.add(a, b)
        assert np.allclose(backend.to_numpy(s), [[6.0, 8.0], [10.0, 12.0]])

        # Softmax
        sm = backend.softmax(backend.tensor([1.0, 2.0, 3.0]))
        assert abs(float(backend.sum(sm)) - 1.0) < 1e-5

    def test_numpy_activations(self) -> None:
        from omniai.backends import get_backend
        backend = get_backend("numpy")

        x = backend.tensor([-1.0, 0.0, 1.0])
        relu = backend.relu(x)
        assert np.allclose(backend.to_numpy(relu), [0.0, 0.0, 1.0])

        sig = backend.sigmoid(backend.tensor([0.0]))
        assert abs(float(backend.to_numpy(sig)[0]) - 0.5) < 1e-5

    def test_numpy_shape_ops(self) -> None:
        from omniai.backends import get_backend
        backend = get_backend("numpy")

        x = backend.randn((2, 3, 4))
        reshaped = backend.reshape(x, (6, 4))
        assert backend.shape(reshaped) == (6, 4)

        transposed = backend.transpose(x, 0, 2)
        assert backend.shape(transposed) == (4, 3, 2)

    def test_auto_detect(self) -> None:
        from omniai.backends import get_backend, list_available_backends
        backend = get_backend()  # auto-detect
        assert backend.is_available
        assert backend.name in list_available_backends()

    def test_list_available(self) -> None:
        from omniai.backends import list_available_backends
        available = list_available_backends()
        assert "numpy" in available  # Always available


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Import Validation
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class TestImports:
    """Test that all modules import cleanly."""

    def test_top_level_import(self) -> None:
        import omniai
        assert omniai.__version__ == "0.1.0"

    def test_core_imports(self) -> None:
        from omniai import Model, Config, Trainer, registry
        assert Model is not None
        assert Config is not None
        assert Trainer is not None
        assert registry is not None

    def test_module_stubs_import(self) -> None:
        """All module stubs should import without error."""
        import omniai.classical
        import omniai.deep
        import omniai.transformers
        import omniai.llm
        import omniai.diffusion
        import omniai.gan
        import omniai.rl
        import omniai.graph
        import omniai.thermodynamic
        import omniai.quantum
        import omniai.neuromorphic
        import omniai.evolutionary
        import omniai.memory
        import omniai.energy
        import omniai.neurosymbolic
        import omniai.metalearning
        import omniai.continual
        import omniai.selfsupervised
        import omniai.multimodal
        import omniai.agents
        import omniai.optimization
        import omniai.distributed
        import omniai.compression
        import omniai.data
        import omniai.evaluation
        import omniai.serving
        import omniai.safety
