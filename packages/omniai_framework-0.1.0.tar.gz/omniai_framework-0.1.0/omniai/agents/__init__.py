"""OmniAI AI Agent Architectures module.

Agent frameworks:
- ReAct (Reasoning + Acting)
- Chain-of-Thought / Tree-of-Thought / Graph-of-Thought
- Tool-using agents (function calling)
- Planning agents (STRIPS-style + neural)
- Multi-agent communication
- Autonomous agent loops (AutoGPT-style)
- Cognitive architectures (ACT-R, SOAR inspired)
"""
