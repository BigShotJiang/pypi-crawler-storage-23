"""
╔═══════════════════════════════════════════════════════════════════════╗
║                            OmniAI                                    ║
║   A unified framework for ALL AI/ML/LLM architectures               ║
╚═══════════════════════════════════════════════════════════════════════╝

OmniAI provides a modular, production-grade Python library for building,
training, fine-tuning, and deploying AI models — from classical ML to
cutting-edge LLMs, diffusion models, and beyond.

Quick Start::

    from omniai import Model, Config, Trainer, registry

    # Build a model from config
    config = Config(arch="transformer.llama", hidden_size=4096, num_layers=32)
    model = Model.build(config)

    # Or use the registry
    model_cls = registry.get("transformer.llama")

    # Train with unified API
    trainer = Trainer(model=model, train_data=loader)
    trainer.fit(epochs=3)

    # Export
    model.export("onnx", path="model.onnx")

Modules:
    - ``omniai.core``          — Base classes, config, registry, callbacks
    - ``omniai.backends``      — Framework abstraction (PyTorch, JAX, TF, NumPy)
    - ``omniai.classical``     — Classical ML (SVM, trees, clustering, etc.)
    - ``omniai.deep``          — MLP, CNN, RNN, autoencoders
    - ``omniai.transformers``  — All transformer architectures
    - ``omniai.llm``           — LLM utilities (tokenizers, generation)
    - ``omniai.diffusion``     — Diffusion models
    - ``omniai.gan``           — Generative adversarial networks
    - ``omniai.rl``            — Reinforcement learning
    - ``omniai.graph``         — Graph neural networks
    - ``omniai.thermodynamic`` — Thermodynamic computing
    - ``omniai.quantum``       — Quantum ML
    - ``omniai.neuromorphic``  — Spiking neural networks
    - ``omniai.evolutionary``  — NAS, genetic algorithms
    - ``omniai.memory``        — Memory-augmented networks
    - ``omniai.energy``        — Energy-based models
    - ``omniai.neurosymbolic`` — Neuro-symbolic AI
    - ``omniai.metalearning``  — Meta/few-shot learning
    - ``omniai.continual``     — Continual learning
    - ``omniai.selfsupervised``— Self-supervised learning
    - ``omniai.multimodal``    — Cross-modal architectures
    - ``omniai.agents``        — AI agent frameworks
    - ``omniai.optimization``  — Optimizers, schedulers
    - ``omniai.distributed``   — Distributed training
    - ``omniai.compression``   — Pruning, quantization, LoRA
    - ``omniai.data``          — Data pipelines
    - ``omniai.evaluation``    — Metrics and benchmarks
    - ``omniai.serving``       — Model serving
    - ``omniai.safety``        — Alignment and guardrails
"""

__version__ = "0.1.0"
__author__ = "OmniAI Contributors"

# ── Core Public API ────────────────────────────────────────────────────────────

from omniai.core.base import BaseModel as Model
from omniai.core.base import BaseModel, BaseTrainer
from omniai.core.base import BaseTrainer as Trainer
from omniai.core.callbacks import (
    Callback,
    EarlyStopping,
    LearningRateMonitor,
    MetricsLogger,
    ModelCheckpoint,
    ProgressCallback,
)
from omniai.core.config import Config, DataConfig, ModelConfig, TrainerConfig
from omniai.core.hardware import detect_hardware, get_device, get_optimal_device
from omniai.core.registry import register, registry

# ── Backend API ────────────────────────────────────────────────────────────────

from omniai.backends import (
    current_backend,
    get_backend,
    list_available_backends,
    set_backend,
)

# ── Utilities ──────────────────────────────────────────────────────────────────

from omniai.utils.common import count_parameters, format_param_count, set_seed
from omniai.utils.logging import get_logger, set_verbosity, setup_logging

__all__ = [
    # Version
    "__version__",
    # Core
    "Model",
    "BaseModel",
    "Trainer",
    "BaseTrainer",
    "Config",
    "ModelConfig",
    "TrainerConfig",
    "DataConfig",
    # Registry
    "registry",
    "register",
    # Callbacks
    "Callback",
    "EarlyStopping",
    "ModelCheckpoint",
    "LearningRateMonitor",
    "ProgressCallback",
    "MetricsLogger",
    # Hardware
    "detect_hardware",
    "get_optimal_device",
    "get_device",
    # Backend
    "get_backend",
    "set_backend",
    "current_backend",
    "list_available_backends",
    # Utilities
    "set_seed",
    "setup_logging",
    "set_verbosity",
    "get_logger",
    "count_parameters",
    "format_param_count",
]
