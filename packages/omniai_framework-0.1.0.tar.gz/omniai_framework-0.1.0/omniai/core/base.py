"""OmniAI Base Classes.

Provides the foundational abstract classes that all OmniAI models
and trainers inherit from, ensuring a unified API across all architectures.
"""

from __future__ import annotations

import abc
import copy
import json
import time
from pathlib import Path
from typing import Any, ClassVar, Dict, Iterator, List, Optional, Type, TypeVar

import numpy as np

from omniai.core.config import Config, ModelConfig, TrainerConfig
from omniai.utils.common import count_parameters, format_param_count
from omniai.utils.exceptions import (
    CheckpointError,
    ExportError,
    ModelBuildError,
    ModelLoadError,
)
from omniai.utils.logging import get_logger
from omniai.utils.types import (
    Device,
    MetricsDict,
    ModelPhase,
    PathLike,
    Tensor,
)

logger = get_logger(__name__)

T = TypeVar("T", bound="BaseModel")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# BaseModel
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class BaseModel(abc.ABC):
    """Abstract base class for all OmniAI models.

    Provides a unified interface for model construction, training,
    inference, serialization, and export across all architectures.

    Subclasses must implement:
        - `_build()`: Construct the model architecture
        - `forward()`: The forward pass
        - `predict()`: High-level inference method

    Example:
        >>> class MyModel(BaseModel):
        ...     def _build(self):
        ...         self.linear = torch.nn.Linear(10, 1)
        ...     def forward(self, x):
        ...         return self.linear(x)
        ...     def predict(self, inputs, **kwargs):
        ...         return self.forward(inputs)
    """

    # Class-level defaults
    _default_config_cls: ClassVar[Type[Config]] = ModelConfig

    def __init__(self, config: Config | dict[str, Any] | None = None, **kwargs: Any) -> None:
        """Initialize the model.

        Args:
            config: Model configuration (Config, dict, or None for defaults).
            **kwargs: Override config values.
        """
        # Resolve config
        if config is None:
            config = self._default_config_cls(**kwargs)
        elif isinstance(config, dict):
            merged = {**config, **kwargs}
            config = self._default_config_cls.from_dict(merged)
        elif kwargs:
            config = config.merge(kwargs)

        self.config = config
        self._phase = ModelPhase.INITIALIZED
        self._device: str = "cpu"
        self._built = False

        # Metadata
        self._creation_time = time.time()
        self._training_history: list[MetricsDict] = []

    # ── Build ──────────────────────────────────────────────────────────────

    def build(self: T) -> T:
        """Build the model architecture.

        Returns:
            Self, for method chaining.

        Raises:
            ModelBuildError: If construction fails.
        """
        try:
            self._build()
            self._built = True
            self._phase = ModelPhase.BUILT
            logger.info(
                "Built %s (%s parameters)",
                self.__class__.__name__,
                format_param_count(self.num_parameters),
            )
        except Exception as e:
            raise ModelBuildError(
                f"Failed to build {self.__class__.__name__}: {e}",
                hint="Check your config values and ensure all dependencies are installed.",
            ) from e
        return self

    @abc.abstractmethod
    def _build(self) -> None:
        """Internal build method. Subclasses must implement this."""
        ...

    @classmethod
    def from_config(cls: Type[T], config: Config | dict[str, Any] | PathLike) -> T:
        """Create and build a model from config.

        Args:
            config: Config object, dict, or path to config file.

        Returns:
            Built model instance.
        """
        if isinstance(config, (str, Path)):
            path = Path(config)
            if path.suffix in (".yaml", ".yml"):
                config = cls._default_config_cls.from_yaml(path)
            elif path.suffix == ".json":
                config = cls._default_config_cls.from_json(path)
            else:
                raise ModelBuildError(f"Unsupported config format: {path.suffix}")

        model = cls(config=config)
        model.build()
        return model

    # ── Forward / Predict ──────────────────────────────────────────────────

    @abc.abstractmethod
    def forward(self, *args: Any, **kwargs: Any) -> Any:
        """Forward pass through the model.

        Args:
            *args: Model inputs.
            **kwargs: Additional arguments.

        Returns:
            Model output.
        """
        ...

    def predict(self, inputs: Any, **kwargs: Any) -> Any:
        """High-level inference method.

        Default implementation calls forward(). Override for custom logic.

        Args:
            inputs: Input data.
            **kwargs: Additional arguments.

        Returns:
            Model predictions.
        """
        return self.forward(inputs, **kwargs)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """Make the model callable."""
        return self.forward(*args, **kwargs)

    # ── Serialization ──────────────────────────────────────────────────────

    def save(self, path: PathLike) -> None:
        """Save model weights and config to disk.

        Args:
            path: Directory to save to.
        """
        save_dir = Path(path)
        save_dir.mkdir(parents=True, exist_ok=True)

        # Save config
        self.config.to_json(save_dir / "config.json")

        # Save weights (framework-specific)
        self._save_weights(save_dir / "model_weights")

        # Save metadata
        metadata = {
            "class": f"{self.__class__.__module__}.{self.__class__.__qualname__}",
            "phase": self._phase.value,
            "device": self._device,
            "num_parameters": self.num_parameters,
            "creation_time": self._creation_time,
        }
        with open(save_dir / "metadata.json", "w") as f:
            json.dump(metadata, f, indent=2)

        logger.info("Saved model to %s", save_dir)

    @classmethod
    def load(cls: Type[T], path: PathLike) -> T:
        """Load a model from disk.

        Args:
            path: Directory to load from.

        Returns:
            Loaded model instance.

        Raises:
            ModelLoadError: If loading fails.
        """
        load_dir = Path(path)
        if not load_dir.exists():
            raise ModelLoadError(f"Model directory not found: {load_dir}")

        config_path = load_dir / "config.json"
        if not config_path.exists():
            raise ModelLoadError(f"Config not found: {config_path}")

        try:
            config = cls._default_config_cls.from_json(config_path)
            model = cls(config=config)
            model.build()
            model._load_weights(load_dir / "model_weights")
            logger.info("Loaded model from %s", load_dir)
            return model
        except Exception as e:
            raise ModelLoadError(f"Failed to load model: {e}") from e

    def _save_weights(self, path: Path) -> None:
        """Save model weights. Override in subclasses for framework-specific saving."""
        logger.debug("Base _save_weights called — no weights to save for %s", self.__class__.__name__)

    def _load_weights(self, path: Path) -> None:
        """Load model weights. Override in subclasses for framework-specific loading."""
        logger.debug("Base _load_weights called — no weights to load for %s", self.__class__.__name__)

    # ── Export ─────────────────────────────────────────────────────────────

    def export(self, fmt: str, path: PathLike, **kwargs: Any) -> None:
        """Export model to a specific format.

        Args:
            fmt: Export format ('onnx', 'torchscript', 'tflite', 'safetensors').
            path: Output path.
            **kwargs: Format-specific options.

        Raises:
            ExportError: If export fails or format is unsupported.
        """
        fmt = fmt.lower().strip()

        exporters = {
            "onnx": self._export_onnx,
            "torchscript": self._export_torchscript,
            "safetensors": self._export_safetensors,
        }

        exporter = exporters.get(fmt)
        if exporter is None:
            raise ExportError(
                f"Unsupported export format: '{fmt}'",
                hint=f"Supported formats: {', '.join(exporters.keys())}",
            )

        try:
            exporter(Path(path), **kwargs)
            logger.info("Exported model to %s format: %s", fmt.upper(), path)
        except ExportError:
            raise
        except Exception as e:
            raise ExportError(f"Export to {fmt} failed: {e}") from e

    def _export_onnx(self, path: Path, **kwargs: Any) -> None:
        raise ExportError("ONNX export not implemented for this model type.")

    def _export_torchscript(self, path: Path, **kwargs: Any) -> None:
        raise ExportError("TorchScript export not implemented for this model type.")

    def _export_safetensors(self, path: Path, **kwargs: Any) -> None:
        raise ExportError("Safetensors export not implemented for this model type.")

    # ── Properties ─────────────────────────────────────────────────────────

    @property
    def num_parameters(self) -> int:
        """Total number of parameters."""
        try:
            return count_parameters(self, trainable_only=False)
        except TypeError:
            return 0

    @property
    def num_trainable_parameters(self) -> int:
        """Number of trainable parameters."""
        try:
            return count_parameters(self, trainable_only=True)
        except TypeError:
            return 0

    @property
    def phase(self) -> ModelPhase:
        """Current lifecycle phase."""
        return self._phase

    @property
    def is_built(self) -> bool:
        """Whether the model has been built."""
        return self._built

    @property
    def device(self) -> str:
        """Current device."""
        return self._device

    # ── Display ────────────────────────────────────────────────────────────

    def summary(self) -> str:
        """Get a human-readable model summary.

        Returns:
            Formatted summary string.
        """
        lines = [
            f"╭─── {self.__class__.__name__} ───╮",
            f"  Architecture:  {self.config.get('arch', 'N/A')}",
            f"  Parameters:    {format_param_count(self.num_parameters)} total",
            f"                 {format_param_count(self.num_trainable_parameters)} trainable",
            f"  Phase:         {self._phase.value}",
            f"  Device:        {self._device}",
            "╰───────────────────────────────╯",
        ]
        return "\n".join(lines)

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"arch={self.config.get('arch', '')!r}, "
            f"params={format_param_count(self.num_parameters)}, "
            f"phase={self._phase.value})"
        )


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# BaseTrainer
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━


class BaseTrainer(abc.ABC):
    """Abstract base class for all OmniAI trainers.

    Provides a unified training interface with callbacks, logging,
    checkpointing, and metrics tracking.

    Subclasses must implement:
        - `train_step()`: Single training step logic
        - `eval_step()`: Single evaluation step logic

    Example:
        >>> trainer = Trainer(model=model, train_data=loader, optimizer="adamw")
        >>> trainer.fit(epochs=3)
        >>> metrics = trainer.evaluate(test_data)
    """

    def __init__(
        self,
        model: BaseModel,
        config: TrainerConfig | dict[str, Any] | None = None,
        train_data: Any = None,
        eval_data: Any = None,
        callbacks: list[Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Initialize the trainer.

        Args:
            model: The model to train.
            config: Trainer configuration.
            train_data: Training data loader.
            eval_data: Evaluation data loader.
            callbacks: List of callback instances.
            **kwargs: Override config values.
        """
        # Config
        if config is None:
            config = TrainerConfig(**kwargs)
        elif isinstance(config, dict):
            config = TrainerConfig.from_dict({**config, **kwargs})
        elif kwargs:
            config = config.merge(kwargs)

        self.model = model
        self.config: TrainerConfig = config  # type: ignore[assignment]
        self.train_data = train_data
        self.eval_data = eval_data
        self.callbacks = callbacks or []

        # State
        self.global_step = 0
        self.current_epoch = 0
        self.best_metric: float | None = None
        self._history: list[MetricsDict] = []

    # ── Training Loop ──────────────────────────────────────────────────────

    def fit(
        self,
        epochs: int | None = None,
        max_steps: int | None = None,
    ) -> list[MetricsDict]:
        """Run the full training loop.

        Args:
            epochs: Number of epochs (overrides config).
            max_steps: Maximum training steps (overrides config).

        Returns:
            List of per-epoch metrics dictionaries.
        """
        epochs = epochs or self.config.epochs
        max_steps = max_steps or (self.config.max_steps if self.config.max_steps > 0 else None)

        self.model._phase = ModelPhase.TRAINING
        self._on_train_begin()

        try:
            for epoch in range(epochs):
                self.current_epoch = epoch
                self._on_epoch_begin(epoch)

                epoch_metrics = self._run_epoch(epoch, max_steps)
                self._history.append(epoch_metrics)

                # Evaluation
                if self.eval_data is not None:
                    eval_metrics = self.evaluate(self.eval_data)
                    epoch_metrics.update({f"eval_{k}": v for k, v in eval_metrics.items()})

                self._on_epoch_end(epoch, epoch_metrics)

                logger.info(
                    "Epoch %d/%d — %s",
                    epoch + 1,
                    epochs,
                    " | ".join(f"{k}: {v:.4f}" if isinstance(v, float) else f"{k}: {v}"
                               for k, v in epoch_metrics.items()),
                )

                if max_steps and self.global_step >= max_steps:
                    logger.info("Reached max_steps=%d, stopping training.", max_steps)
                    break

        finally:
            self.model._phase = ModelPhase.TRAINED
            self._on_train_end()

        return self._history

    def _run_epoch(self, epoch: int, max_steps: int | None) -> MetricsDict:
        """Run a single training epoch.

        Args:
            epoch: Current epoch number.
            max_steps: Maximum training steps.

        Returns:
            Aggregated epoch metrics.
        """
        epoch_metrics: dict[str, list[float]] = {}

        if self.train_data is None:
            logger.warning("No training data provided, skipping epoch.")
            return {}

        for batch_idx, batch in enumerate(self.train_data):
            step_metrics = self.train_step(batch)
            self.global_step += 1

            # Accumulate metrics
            for k, v in step_metrics.items():
                epoch_metrics.setdefault(k, []).append(float(v))

            # Logging
            if self.global_step % self.config.logging_steps == 0:
                avg = {k: np.mean(v[-self.config.logging_steps:]) for k, v in epoch_metrics.items()}
                self._on_log(avg)

            # Checkpointing
            if self.config.save_steps > 0 and self.global_step % self.config.save_steps == 0:
                self._save_checkpoint()

            if max_steps and self.global_step >= max_steps:
                break

        # Average metrics over epoch
        return {k: float(np.mean(v)) for k, v in epoch_metrics.items()}

    @abc.abstractmethod
    def train_step(self, batch: Any) -> MetricsDict:
        """Execute a single training step.

        Args:
            batch: A single batch of training data.

        Returns:
            Dictionary of metrics for this step.
        """
        ...

    # ── Evaluation ─────────────────────────────────────────────────────────

    def evaluate(self, data: Any | None = None) -> MetricsDict:
        """Run evaluation on the given data.

        Args:
            data: Data loader for evaluation. Uses self.eval_data if None.

        Returns:
            Aggregated evaluation metrics.
        """
        data = data or self.eval_data
        if data is None:
            return {}

        all_metrics: dict[str, list[float]] = {}
        for batch in data:
            step_metrics = self.eval_step(batch)
            for k, v in step_metrics.items():
                all_metrics.setdefault(k, []).append(float(v))

        return {k: float(np.mean(v)) for k, v in all_metrics.items()}

    def eval_step(self, batch: Any) -> MetricsDict:
        """Execute a single evaluation step.

        Default implementation calls train_step in eval mode.
        Override for custom evaluation logic.
        """
        return self.train_step(batch)

    # ── Checkpointing ──────────────────────────────────────────────────────

    def _save_checkpoint(self) -> None:
        """Save a training checkpoint."""
        ckpt_dir = Path(self.config.checkpoint_dir) / f"step_{self.global_step}"
        try:
            self.model.save(ckpt_dir)
            # Save trainer state
            state = {
                "global_step": self.global_step,
                "current_epoch": self.current_epoch,
                "best_metric": self.best_metric,
                "config": self.config.to_dict(),
            }
            with open(ckpt_dir / "trainer_state.json", "w") as f:
                json.dump(state, f, indent=2)
            logger.info("Saved checkpoint at step %d to %s", self.global_step, ckpt_dir)
        except Exception as e:
            raise CheckpointError(f"Failed to save checkpoint: {e}") from e

    # ── Callback Hooks ─────────────────────────────────────────────────────

    def _on_train_begin(self) -> None:
        for cb in self.callbacks:
            if hasattr(cb, "on_train_begin"):
                cb.on_train_begin(self)

    def _on_train_end(self) -> None:
        for cb in self.callbacks:
            if hasattr(cb, "on_train_end"):
                cb.on_train_end(self)

    def _on_epoch_begin(self, epoch: int) -> None:
        for cb in self.callbacks:
            if hasattr(cb, "on_epoch_begin"):
                cb.on_epoch_begin(self, epoch)

    def _on_epoch_end(self, epoch: int, metrics: MetricsDict) -> None:
        for cb in self.callbacks:
            if hasattr(cb, "on_epoch_end"):
                cb.on_epoch_end(self, epoch, metrics)

    def _on_log(self, metrics: MetricsDict) -> None:
        for cb in self.callbacks:
            if hasattr(cb, "on_log"):
                cb.on_log(self, metrics)

    # ── Properties ─────────────────────────────────────────────────────────

    @property
    def history(self) -> list[MetricsDict]:
        """Training history — list of per-epoch metric dicts."""
        return self._history

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"model={self.model.__class__.__name__}, "
            f"step={self.global_step}, "
            f"epoch={self.current_epoch})"
        )
