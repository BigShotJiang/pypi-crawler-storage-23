"""OmniAI Callback System.

Provides base callbacks and built-in callbacks for training:
- EarlyStopping
- ModelCheckpoint
- LearningRateMonitor
- ProgressBar
- MetricsLogger
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

from omniai.utils.logging import get_logger
from omniai.utils.types import MetricsDict, PathLike

if TYPE_CHECKING:
    from omniai.core.base import BaseTrainer

logger = get_logger(__name__)


class Callback:
    """Base class for training callbacks.

    Override any of the hook methods to add custom behavior.
    """

    def on_train_begin(self, trainer: "BaseTrainer") -> None:
        """Called at the start of training."""

    def on_train_end(self, trainer: "BaseTrainer") -> None:
        """Called at the end of training."""

    def on_epoch_begin(self, trainer: "BaseTrainer", epoch: int) -> None:
        """Called at the start of each epoch."""

    def on_epoch_end(
        self, trainer: "BaseTrainer", epoch: int, metrics: MetricsDict
    ) -> None:
        """Called at the end of each epoch."""

    def on_step_begin(self, trainer: "BaseTrainer", step: int) -> None:
        """Called before each training step."""

    def on_step_end(
        self, trainer: "BaseTrainer", step: int, metrics: MetricsDict
    ) -> None:
        """Called after each training step."""

    def on_log(self, trainer: "BaseTrainer", metrics: MetricsDict) -> None:
        """Called when metrics are logged."""


class EarlyStopping(Callback):
    """Stop training when a monitored metric stops improving.

    Args:
        monitor: Metric name to monitor (e.g., 'eval_loss').
        patience: Number of epochs with no improvement before stopping.
        min_delta: Minimum change to qualify as an improvement.
        mode: 'min' for metrics that should decrease, 'max' for increase.
        verbose: Whether to log stopping decisions.
    """

    def __init__(
        self,
        monitor: str = "eval_loss",
        patience: int = 5,
        min_delta: float = 0.0,
        mode: str = "min",
        verbose: bool = True,
    ) -> None:
        self.monitor = monitor
        self.patience = patience
        self.min_delta = min_delta
        self.mode = mode
        self.verbose = verbose
        self.best_value: float | None = None
        self.wait = 0
        self.stopped_epoch = 0

    def on_epoch_end(
        self, trainer: "BaseTrainer", epoch: int, metrics: MetricsDict
    ) -> None:
        current = metrics.get(self.monitor)
        if current is None:
            return

        current = float(current)

        if self.best_value is None:
            self.best_value = current
            return

        if self.mode == "min":
            improved = current < self.best_value - self.min_delta
        else:
            improved = current > self.best_value + self.min_delta

        if improved:
            self.best_value = current
            self.wait = 0
        else:
            self.wait += 1
            if self.wait >= self.patience:
                self.stopped_epoch = epoch
                if self.verbose:
                    logger.info(
                        "EarlyStopping: %s did not improve for %d epochs. "
                        "Best: %.4f. Stopping.",
                        self.monitor, self.patience, self.best_value,
                    )
                # Signal the trainer to stop
                if hasattr(trainer, "_stop_training"):
                    trainer._stop_training = True  # type: ignore[attr-defined]


class ModelCheckpoint(Callback):
    """Save model checkpoints during training.

    Args:
        dirpath: Directory to save checkpoints.
        monitor: Metric to monitor for 'best' saving.
        mode: 'min' or 'max' for the monitored metric.
        save_top_k: Number of best checkpoints to keep.
        save_every_n_epochs: Save every N epochs regardless of metric.
        verbose: Whether to log checkpoint saves.
    """

    def __init__(
        self,
        dirpath: PathLike = "checkpoints",
        monitor: str = "eval_loss",
        mode: str = "min",
        save_top_k: int = 3,
        save_every_n_epochs: int = 0,
        verbose: bool = True,
    ) -> None:
        self.dirpath = Path(dirpath)
        self.monitor = monitor
        self.mode = mode
        self.save_top_k = save_top_k
        self.save_every_n_epochs = save_every_n_epochs
        self.verbose = verbose
        self.best_value: float | None = None
        self._saved: list[tuple[float, Path]] = []

    def on_epoch_end(
        self, trainer: "BaseTrainer", epoch: int, metrics: MetricsDict
    ) -> None:
        # Save every N epochs
        if self.save_every_n_epochs > 0 and (epoch + 1) % self.save_every_n_epochs == 0:
            path = self.dirpath / f"epoch_{epoch + 1}"
            trainer.model.save(path)
            if self.verbose:
                logger.info("ModelCheckpoint: Saved epoch %d to %s", epoch + 1, path)

        # Save best
        current = metrics.get(self.monitor)
        if current is None:
            return

        current = float(current)
        is_best = False

        if self.best_value is None:
            is_best = True
        elif self.mode == "min":
            is_best = current < self.best_value
        else:
            is_best = current > self.best_value

        if is_best:
            self.best_value = current
            path = self.dirpath / f"best_epoch_{epoch + 1}"
            trainer.model.save(path)
            self._saved.append((current, path))

            # Remove old checkpoints
            if len(self._saved) > self.save_top_k:
                if self.mode == "min":
                    self._saved.sort(key=lambda x: x[0])
                else:
                    self._saved.sort(key=lambda x: -x[0])
                self._saved = self._saved[: self.save_top_k]

            if self.verbose:
                logger.info(
                    "ModelCheckpoint: %s improved to %.4f. Saved to %s",
                    self.monitor, current, path,
                )


class LearningRateMonitor(Callback):
    """Log learning rate at each epoch.

    Extracts the current learning rate from the optimizer and logs it.
    """

    def on_epoch_end(
        self, trainer: "BaseTrainer", epoch: int, metrics: MetricsDict
    ) -> None:
        try:
            optimizer = getattr(trainer, "optimizer", None)
            if optimizer is not None and hasattr(optimizer, "param_groups"):
                for i, pg in enumerate(optimizer.param_groups):
                    lr = pg.get("lr", 0.0)
                    metrics[f"lr_group_{i}"] = lr
                    if i == 0:
                        metrics["lr"] = lr
        except Exception:
            pass


class ProgressCallback(Callback):
    """Display a progress bar during training using tqdm."""

    def __init__(self) -> None:
        self._epoch_start_time: float = 0.0

    def on_train_begin(self, trainer: "BaseTrainer") -> None:
        logger.info("Training started")

    def on_epoch_begin(self, trainer: "BaseTrainer", epoch: int) -> None:
        self._epoch_start_time = time.time()

    def on_epoch_end(
        self, trainer: "BaseTrainer", epoch: int, metrics: MetricsDict
    ) -> None:
        elapsed = time.time() - self._epoch_start_time
        metrics_str = " | ".join(
            f"{k}: {v:.4f}" if isinstance(v, float) else f"{k}: {v}"
            for k, v in metrics.items()
        )
        logger.info("Epoch %d completed in %.1fs — %s", epoch + 1, elapsed, metrics_str)

    def on_train_end(self, trainer: "BaseTrainer") -> None:
        logger.info("Training complete. Total steps: %d", trainer.global_step)


class MetricsLogger(Callback):
    """Log metrics to a JSON file for experiment tracking.

    Args:
        log_dir: Directory to write log files.
        filename: Name of the metrics log file.
    """

    def __init__(
        self,
        log_dir: PathLike = "logs",
        filename: str = "metrics.jsonl",
    ) -> None:
        self.log_dir = Path(log_dir)
        self.filename = filename
        self._log_path: Path | None = None

    def on_train_begin(self, trainer: "BaseTrainer") -> None:
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self._log_path = self.log_dir / self.filename

    def on_epoch_end(
        self, trainer: "BaseTrainer", epoch: int, metrics: MetricsDict
    ) -> None:
        if self._log_path is None:
            return

        record = {
            "epoch": epoch + 1,
            "global_step": trainer.global_step,
            "timestamp": time.time(),
            **{k: float(v) if isinstance(v, (int, float)) else v for k, v in metrics.items()},
        }
        with open(self._log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")
