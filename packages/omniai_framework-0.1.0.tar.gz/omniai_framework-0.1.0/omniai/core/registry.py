"""OmniAI Model Registry.

A global, category-aware registry for all model architectures.
Models are registered via the `@register` decorator or `registry.register()`.

Example:
    >>> from omniai.core.registry import registry, register
    >>>
    >>> @register("classical.linear_regression")
    ... class LinearRegressionModel(BaseModel):
    ...     pass
    >>>
    >>> model_cls = registry.get("classical.linear_regression")
    >>> print(registry.list_models(category="classical"))
"""

from __future__ import annotations

import fnmatch
import re
from typing import Any, Callable, Dict, List, Optional, Type, TypeVar

from omniai.utils.exceptions import DuplicateRegistrationError, ModelNotFoundError
from omniai.utils.logging import get_logger

logger = get_logger(__name__)

T = TypeVar("T")


class ModelRegistry:
    """Global registry for model architectures.

    Supports hierarchical naming (e.g., 'transformers.llama', 'classical.svm'),
    category-based listing, pattern search, and metadata.
    """

    def __init__(self) -> None:
        self._registry: Dict[str, _RegistryEntry] = {}

    def register(
        self,
        name: str,
        cls: Type[Any] | None = None,
        *,
        description: str = "",
        tags: list[str] | None = None,
        force: bool = False,
    ) -> Type[Any] | Callable[[Type[T]], Type[T]]:
        """Register a model class.

        Can be used as a decorator or called directly.

        Args:
            name: Unique model identifier (e.g., 'transformers.llama').
            cls: The model class to register (if not used as decorator).
            description: Human-readable description of the model.
            tags: Optional tags for search/filtering.
            force: If True, overwrite existing registration.

        Returns:
            The registered class, or a decorator if cls is None.

        Raises:
            DuplicateRegistrationError: If name already registered and force=False.
        """

        def _register(model_cls: Type[T]) -> Type[T]:
            normalized = name.lower().strip()

            if normalized in self._registry and not force:
                raise DuplicateRegistrationError(normalized)

            entry = _RegistryEntry(
                name=normalized,
                cls=model_cls,
                description=description or model_cls.__doc__ or "",
                tags=tags or [],
                category=normalized.split(".")[0] if "." in normalized else "uncategorized",
            )
            self._registry[normalized] = entry
            logger.debug("Registered model: %s -> %s", normalized, model_cls.__name__)
            return model_cls

        if cls is not None:
            return _register(cls)
        return _register

    def get(self, name: str) -> Type[Any]:
        """Get a registered model class by name.

        Args:
            name: Model identifier.

        Returns:
            The model class.

        Raises:
            ModelNotFoundError: If the model is not registered.
        """
        normalized = name.lower().strip()
        entry = self._registry.get(normalized)
        if entry is None:
            raise ModelNotFoundError(normalized, list(self._registry.keys()))
        return entry.cls

    def get_entry(self, name: str) -> "_RegistryEntry":
        """Get the full registry entry for a model.

        Args:
            name: Model identifier.

        Returns:
            Registry entry with metadata.
        """
        normalized = name.lower().strip()
        entry = self._registry.get(normalized)
        if entry is None:
            raise ModelNotFoundError(normalized, list(self._registry.keys()))
        return entry

    def list_models(self, category: str | None = None) -> list[str]:
        """List all registered model names.

        Args:
            category: Optional category filter (e.g., 'transformers', 'classical').

        Returns:
            Sorted list of model names.
        """
        if category:
            category = category.lower().strip()
            return sorted(
                name for name, entry in self._registry.items()
                if entry.category == category
            )
        return sorted(self._registry.keys())

    def list_categories(self) -> list[str]:
        """List all registered categories.

        Returns:
            Sorted list of category names.
        """
        return sorted({entry.category for entry in self._registry.values()})

    def search(self, pattern: str) -> list[str]:
        """Search for models matching a glob or substring pattern.

        Args:
            pattern: Glob pattern (e.g., 'transformer.*') or substring.

        Returns:
            List of matching model names.
        """
        pattern_lower = pattern.lower().strip()
        matches = []

        # Try glob pattern first
        for name in self._registry:
            if fnmatch.fnmatch(name, pattern_lower):
                matches.append(name)

        # If no glob matches, try substring
        if not matches:
            for name in self._registry:
                if pattern_lower in name:
                    matches.append(name)

        # Also search tags
        for name, entry in self._registry.items():
            if any(pattern_lower in tag.lower() for tag in entry.tags):
                if name not in matches:
                    matches.append(name)

        return sorted(matches)

    def info(self, name: str) -> str:
        """Get human-readable info about a registered model.

        Args:
            name: Model identifier.

        Returns:
            Formatted info string.
        """
        entry = self.get_entry(name)
        lines = [
            f"Model: {entry.name}",
            f"Class: {entry.cls.__module__}.{entry.cls.__qualname__}",
            f"Category: {entry.category}",
        ]
        if entry.description:
            lines.append(f"Description: {entry.description}")
        if entry.tags:
            lines.append(f"Tags: {', '.join(entry.tags)}")
        return "\n".join(lines)

    def summary(self) -> str:
        """Get a summary of all registered models by category.

        Returns:
            Formatted summary string.
        """
        if not self._registry:
            return "No models registered."

        lines = [f"OmniAI Model Registry ({len(self._registry)} models)\n"]
        for category in self.list_categories():
            models = self.list_models(category=category)
            lines.append(f"  {category}/ ({len(models)} models)")
            for model in models:
                entry = self._registry[model]
                desc = entry.description[:60] + "..." if len(entry.description) > 60 else entry.description
                lines.append(f"    ├─ {model}" + (f"  — {desc}" if desc else ""))
            lines.append("")
        return "\n".join(lines)

    def __contains__(self, name: str) -> bool:
        return name.lower().strip() in self._registry

    def __len__(self) -> int:
        return len(self._registry)

    def __repr__(self) -> str:
        return f"ModelRegistry({len(self._registry)} models)"


class _RegistryEntry:
    """Internal registry entry storing a model class and its metadata."""

    __slots__ = ("name", "cls", "description", "tags", "category")

    def __init__(
        self,
        name: str,
        cls: Type[Any],
        description: str,
        tags: list[str],
        category: str,
    ) -> None:
        self.name = name
        self.cls = cls
        self.description = description
        self.tags = tags
        self.category = category


# ── Global Registry Instance ──────────────────────────────────────────────────

registry = ModelRegistry()
"""The global OmniAI model registry. Use `@register(name)` to add models."""


def register(
    name: str,
    *,
    description: str = "",
    tags: list[str] | None = None,
    force: bool = False,
) -> Callable[[Type[T]], Type[T]]:
    """Convenience decorator for registering models in the global registry.

    Args:
        name: Unique model identifier.
        description: Human-readable description.
        tags: Optional tags for search/filtering.
        force: If True, overwrite existing registration.

    Example:
        >>> @register("classical.linear_regression", tags=["regression", "linear"])
        ... class LinearRegression(BaseModel):
        ...     pass
    """
    return registry.register(name, description=description, tags=tags, force=force)  # type: ignore[return-value]
