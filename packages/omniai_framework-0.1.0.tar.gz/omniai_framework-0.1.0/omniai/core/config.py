"""OmniAI Configuration System.

Provides a unified, hierarchical configuration system supporting:
- YAML / JSON / dict / dataclass-based creation
- Config inheritance and merging
- Validation with informative error messages
- Serialization to/from files
"""

from __future__ import annotations

import copy
import json
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any, ClassVar, Type, TypeVar

import yaml

from omniai.utils.exceptions import ConfigError, ConfigFileError, ConfigValidationError
from omniai.utils.logging import get_logger
from omniai.utils.types import ConfigDict, PathLike

logger = get_logger(__name__)

T = TypeVar("T", bound="Config")


@dataclass
class Config:
    """Base configuration class for all OmniAI models and components.

    Supports creation from YAML, JSON, dictionaries, and other Config objects.
    Provides validation, merging, and serialization capabilities.

    Example:
        >>> config = Config.from_yaml("configs/model.yaml")
        >>> config = Config(arch="transformer.llama", hidden_size=4096)
        >>> config.to_yaml("output_config.yaml")
    """

    # ── Core Fields ────────────────────────────────────────────────────────

    arch: str = ""
    """Architecture identifier (e.g., 'transformer.llama', 'classical.linear_regression')."""

    name: str = ""
    """Optional human-readable name for the model/component."""

    # ── Metadata ───────────────────────────────────────────────────────────

    _extra: dict[str, Any] = field(default_factory=dict, repr=False)
    """Extra parameters not in the dataclass schema, stored as a dict."""

    # ── Class Variables ────────────────────────────────────────────────────

    _validators: ClassVar[dict[str, Any]] = {}

    # ── Constructors ───────────────────────────────────────────────────────

    @classmethod
    def from_yaml(cls: Type[T], path: PathLike) -> T:
        """Load config from a YAML file.

        Args:
            path: Path to the YAML file.

        Returns:
            Config instance.

        Raises:
            ConfigFileError: If the file cannot be read or parsed.
        """
        path = Path(path)
        if not path.exists():
            raise ConfigFileError(f"Config file not found: {path}")

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            raise ConfigFileError(f"Failed to parse YAML config: {path}\n{e}") from e

        if not isinstance(data, dict):
            raise ConfigFileError(
                f"Expected YAML mapping at top level, got {type(data).__name__}",
                hint="Ensure your YAML config file contains key-value pairs at the top level.",
            )

        logger.debug("Loaded config from %s", path)
        return cls.from_dict(data)

    @classmethod
    def from_json(cls: Type[T], path: PathLike) -> T:
        """Load config from a JSON file.

        Args:
            path: Path to the JSON file.

        Returns:
            Config instance.

        Raises:
            ConfigFileError: If the file cannot be read or parsed.
        """
        path = Path(path)
        if not path.exists():
            raise ConfigFileError(f"Config file not found: {path}")

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            raise ConfigFileError(f"Failed to parse JSON config: {path}\n{e}") from e

        if not isinstance(data, dict):
            raise ConfigFileError(
                f"Expected JSON object at top level, got {type(data).__name__}"
            )

        logger.debug("Loaded config from %s", path)
        return cls.from_dict(data)

    @classmethod
    def from_dict(cls: Type[T], data: ConfigDict) -> T:
        """Create config from a dictionary.

        Known fields are set as attributes; unknown fields are stored in `_extra`.

        Args:
            data: Configuration dictionary.

        Returns:
            Config instance.
        """
        known_fields = {f.name for f in fields(cls) if not f.name.startswith("_")}
        known = {k: v for k, v in data.items() if k in known_fields}
        extra = {k: v for k, v in data.items() if k not in known_fields}

        instance = cls(**known)
        instance._extra = extra
        return instance

    # ── Serialization ──────────────────────────────────────────────────────

    def to_dict(self) -> ConfigDict:
        """Convert config to a dictionary.

        Returns:
            Configuration as a flat dictionary including extra params.
        """
        data = {}
        for f in fields(self):
            if f.name.startswith("_"):
                continue
            data[f.name] = getattr(self, f.name)
        data.update(self._extra)
        return data

    def to_yaml(self, path: PathLike | None = None) -> str:
        """Serialize config to YAML.

        Args:
            path: Optional path to write the YAML file.

        Returns:
            YAML string representation.
        """
        data = self.to_dict()
        yaml_str = yaml.dump(data, default_flow_style=False, sort_keys=False)

        if path is not None:
            path = Path(path)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(yaml_str)
            logger.debug("Saved config to %s", path)

        return yaml_str

    def to_json(self, path: PathLike | None = None, indent: int = 2) -> str:
        """Serialize config to JSON.

        Args:
            path: Optional path to write the JSON file.
            indent: JSON indentation level.

        Returns:
            JSON string representation.
        """
        data = self.to_dict()
        json_str = json.dumps(data, indent=indent, default=str)

        if path is not None:
            path = Path(path)
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(json_str)
            logger.debug("Saved config to %s", path)

        return json_str

    # ── Merging ────────────────────────────────────────────────────────────

    def merge(self, other: Config | ConfigDict) -> Config:
        """Merge another config or dict into this one (non-destructive).

        Values from `other` take precedence. Returns a new Config.

        Args:
            other: Config or dict to merge from.

        Returns:
            New merged Config instance.
        """
        base = self.to_dict()

        if isinstance(other, Config):
            overlay = other.to_dict()
        else:
            overlay = other

        merged = _deep_merge(base, overlay)
        return self.__class__.from_dict(merged)

    # ── Access ─────────────────────────────────────────────────────────────

    def get(self, key: str, default: Any = None) -> Any:
        """Get a config value by key, checking both fields and extras.

        Args:
            key: Configuration key.
            default: Default value if key not found.

        Returns:
            The configuration value.
        """
        if hasattr(self, key) and not key.startswith("_"):
            return getattr(self, key)
        return self._extra.get(key, default)

    def __getitem__(self, key: str) -> Any:
        """Dict-style access to config values."""
        val = self.get(key, _SENTINEL)
        if val is _SENTINEL:
            raise KeyError(f"Config key '{key}' not found")
        return val

    def __contains__(self, key: str) -> bool:
        """Check if a config key exists."""
        return self.get(key, _SENTINEL) is not _SENTINEL

    # ── Validation ─────────────────────────────────────────────────────────

    def validate(self) -> None:
        """Validate the configuration.

        Raises:
            ConfigValidationError: If any validation check fails.
        """
        for field_name, validator in self._validators.items():
            if hasattr(self, field_name):
                value = getattr(self, field_name)
                try:
                    validator(value)
                except (ValueError, TypeError) as e:
                    raise ConfigValidationError(field_name, value, str(e)) from e

    # ── Display ────────────────────────────────────────────────────────────

    def __str__(self) -> str:
        return self.to_yaml()

    def __repr__(self) -> str:
        cls_name = self.__class__.__name__
        items = ", ".join(f"{k}={v!r}" for k, v in self.to_dict().items())
        return f"{cls_name}({items})"

    def copy(self: T) -> T:
        """Create a deep copy of this config."""
        return self.__class__.from_dict(copy.deepcopy(self.to_dict()))


# ── Specialized Config Classes ─────────────────────────────────────────────────

@dataclass
class ModelConfig(Config):
    """Configuration for model architectures."""

    hidden_size: int = 768
    num_layers: int = 12
    num_heads: int = 12
    intermediate_size: int = 3072
    vocab_size: int = 32000
    max_seq_length: int = 2048
    dropout: float = 0.1
    activation: str = "gelu"
    norm_type: str = "layernorm"
    dtype: str = "float32"


@dataclass
class TrainerConfig(Config):
    """Configuration for training."""

    # Optimization
    optimizer: str = "adamw"
    learning_rate: float = 1e-4
    weight_decay: float = 0.01
    max_grad_norm: float = 1.0

    # Schedule
    scheduler: str = "cosine"
    warmup_steps: int = 0
    warmup_ratio: float = 0.0

    # Training
    epochs: int = 1
    max_steps: int = -1
    batch_size: int = 32
    gradient_accumulation_steps: int = 1

    # Precision
    precision: str = "fp32"

    # Distributed
    distributed_strategy: str = "none"

    # Logging
    logging_steps: int = 100
    eval_steps: int = 500
    save_steps: int = 1000

    # Paths
    output_dir: str = "outputs"
    checkpoint_dir: str = "checkpoints"

    # Reproducibility
    seed: int = 42


@dataclass
class DataConfig(Config):
    """Configuration for data loading."""

    dataset_name: str = ""
    dataset_path: str = ""
    train_split: str = "train"
    eval_split: str = "validation"
    test_split: str = "test"
    max_length: int = 512
    num_workers: int = 4
    pin_memory: bool = True
    shuffle: bool = True


# ── Helpers ────────────────────────────────────────────────────────────────────

_SENTINEL = object()


def _deep_merge(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    """Deep merge two dictionaries. Overlay values take precedence."""
    result = copy.deepcopy(base)
    for key, value in overlay.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result
