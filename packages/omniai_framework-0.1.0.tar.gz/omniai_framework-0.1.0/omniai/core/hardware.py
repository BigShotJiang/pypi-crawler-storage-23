"""Hardware detection and device management for OmniAI.

Auto-detects available compute hardware (CPU, CUDA, ROCm, MPS, TPU)
and provides utilities for optimal device selection and memory info.
"""

from __future__ import annotations

import os
import platform
from dataclasses import dataclass, field
from typing import Any

from omniai.utils.exceptions import DeviceNotAvailableError
from omniai.utils.logging import get_logger
from omniai.utils.types import DeviceType

logger = get_logger(__name__)


@dataclass
class GPUInfo:
    """Information about a GPU device."""

    index: int
    name: str
    total_memory_gb: float
    compute_capability: tuple[int, int] | None = None
    driver_version: str | None = None


@dataclass
class HardwareInfo:
    """Complete hardware capability report."""

    # CPU
    cpu_count: int = 0
    cpu_name: str = ""
    system_memory_gb: float = 0.0

    # GPU
    cuda_available: bool = False
    cuda_version: str | None = None
    cudnn_version: str | None = None
    gpu_count: int = 0
    gpus: list[GPUInfo] = field(default_factory=list)

    # Other accelerators
    rocm_available: bool = False
    mps_available: bool = False
    tpu_available: bool = False

    # Platform
    os_name: str = ""
    python_version: str = ""

    def summary(self) -> str:
        """Return a human-readable hardware summary."""
        lines = [
            "╭─── OmniAI Hardware Report ───╮",
            f"  OS:       {self.os_name}",
            f"  Python:   {self.python_version}",
            f"  CPU:      {self.cpu_name} ({self.cpu_count} cores)",
            f"  RAM:      {self.system_memory_gb:.1f} GB",
        ]
        if self.cuda_available:
            lines.append(f"  CUDA:     {self.cuda_version} ({self.gpu_count} GPU(s))")
            if self.cudnn_version:
                lines.append(f"  cuDNN:    {self.cudnn_version}")
            for gpu in self.gpus:
                lines.append(f"    GPU {gpu.index}: {gpu.name} ({gpu.total_memory_gb:.1f} GB)")
        elif self.mps_available:
            lines.append("  Apple MPS: available")
        elif self.rocm_available:
            lines.append("  ROCm:     available")
        elif self.tpu_available:
            lines.append("  TPU:      available")
        else:
            lines.append("  GPU:      none detected")
        lines.append("╰─────────────────────────────╯")
        return "\n".join(lines)


def detect_hardware() -> HardwareInfo:
    """Detect all available hardware and return a comprehensive report.

    Returns:
        HardwareInfo with all detected capabilities.
    """
    info = HardwareInfo(
        cpu_count=os.cpu_count() or 1,
        cpu_name=platform.processor() or "Unknown",
        os_name=f"{platform.system()} {platform.release()}",
        python_version=platform.python_version(),
    )

    # System memory
    try:
        import psutil

        mem = psutil.virtual_memory()
        info.system_memory_gb = round(mem.total / (1024**3), 1)
    except ImportError:
        pass

    # CUDA detection
    try:
        import torch

        info.cuda_available = torch.cuda.is_available()
        if info.cuda_available:
            info.cuda_version = torch.version.cuda
            info.cudnn_version = str(torch.backends.cudnn.version()) if torch.backends.cudnn.is_available() else None  # type: ignore[attr-defined]
            info.gpu_count = torch.cuda.device_count()
            for i in range(info.gpu_count):
                props = torch.cuda.get_device_properties(i)
                info.gpus.append(
                    GPUInfo(
                        index=i,
                        name=props.name,
                        total_memory_gb=round(props.total_mem / (1024**3), 1),
                        compute_capability=(props.major, props.minor),
                    )
                )

        # MPS detection (Apple Silicon)
        info.mps_available = (
            hasattr(torch.backends, "mps")
            and torch.backends.mps.is_available()  # type: ignore[attr-defined]
        )
    except ImportError:
        pass

    # ROCm detection
    if not info.cuda_available:
        try:
            import torch

            if hasattr(torch.version, "hip") and torch.version.hip is not None:
                info.rocm_available = True
        except ImportError:
            pass

    # TPU detection
    try:
        import torch_xla  # type: ignore[import-untyped]

        info.tpu_available = True
    except ImportError:
        pass

    return info


def get_optimal_device() -> str:
    """Auto-detect and return the optimal device string.

    Returns:
        Device string: 'cuda', 'mps', 'tpu', or 'cpu'.
    """
    try:
        import torch

        if torch.cuda.is_available():
            return "cuda"
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():  # type: ignore[attr-defined]
            return "mps"
    except ImportError:
        pass

    try:
        import torch_xla  # type: ignore[import-untyped]

        return "xla"
    except ImportError:
        pass

    return "cpu"


def get_device(device: str | None = None) -> str:
    """Resolve a device string, handling 'auto' and None.

    Args:
        device: Device string or None/'auto' for auto-detection.

    Returns:
        Resolved device string.

    Raises:
        DeviceNotAvailableError: If the requested device is not available.
    """
    if device is None or device == "auto":
        return get_optimal_device()

    # Validate the device exists
    device_lower = device.lower().split(":")[0]  # Handle "cuda:0"

    if device_lower == "cpu":
        return device

    if device_lower == "cuda":
        try:
            import torch

            if torch.cuda.is_available():
                return device
        except ImportError:
            pass
        raise DeviceNotAvailableError(device)

    if device_lower == "mps":
        try:
            import torch

            if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():  # type: ignore[attr-defined]
                return device
        except ImportError:
            pass
        raise DeviceNotAvailableError(device)

    raise DeviceNotAvailableError(device)


def get_available_devices() -> list[str]:
    """List all available compute devices.

    Returns:
        List of device strings (e.g., ['cpu', 'cuda:0', 'cuda:1']).
    """
    devices = ["cpu"]

    try:
        import torch

        if torch.cuda.is_available():
            for i in range(torch.cuda.device_count()):
                devices.append(f"cuda:{i}")

        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():  # type: ignore[attr-defined]
            devices.append("mps")
    except ImportError:
        pass

    return devices
