"""OmniAI Core — base classes, config, registry, callbacks, and hardware."""

from omniai.core.base import BaseModel, BaseTrainer
from omniai.core.callbacks import (
    Callback,
    EarlyStopping,
    LearningRateMonitor,
    MetricsLogger,
    ModelCheckpoint,
    ProgressCallback,
)
from omniai.core.config import Config, DataConfig, ModelConfig, TrainerConfig
from omniai.core.hardware import (
    HardwareInfo,
    detect_hardware,
    get_available_devices,
    get_device,
    get_optimal_device,
)
from omniai.core.registry import ModelRegistry, register, registry

__all__ = [
    # Base
    "BaseModel",
    "BaseTrainer",
    # Config
    "Config",
    "ModelConfig",
    "TrainerConfig",
    "DataConfig",
    # Registry
    "ModelRegistry",
    "registry",
    "register",
    # Callbacks
    "Callback",
    "EarlyStopping",
    "ModelCheckpoint",
    "LearningRateMonitor",
    "ProgressCallback",
    "MetricsLogger",
    # Hardware
    "HardwareInfo",
    "detect_hardware",
    "get_optimal_device",
    "get_device",
    "get_available_devices",
]
