"""OmniAI Self-Supervised Learning module.

SSL methods:
- Masked Language Modeling (MLM)
- Causal Language Modeling (CLM)
- Masked Image Modeling (MIM / MAE / BEiT)
- Contrastive Predictive Coding (CPC)
- JEPA (Joint Embedding Predictive Architecture)
- I-JEPA, V-JEPA
- BYOL, Self-Distillation frameworks
"""
