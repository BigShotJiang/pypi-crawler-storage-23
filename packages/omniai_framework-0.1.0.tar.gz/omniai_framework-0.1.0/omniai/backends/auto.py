"""Backend auto-detection and management for OmniAI.

Automatically selects the best available backend and provides
a global interface for switching backends.
"""

from __future__ import annotations

from typing import Any

from omniai.backends.base import Backend
from omniai.backends.numpy_backend import NumpyBackend
from omniai.utils.exceptions import BackendNotAvailableError
from omniai.utils.logging import get_logger
from omniai.utils.types import BackendType

logger = get_logger(__name__)

# Global backend instance
_current_backend: Backend | None = None


def get_backend(name: str | BackendType | None = None) -> Backend:
    """Get a backend instance by name, or auto-detect the best available.

    Args:
        name: Backend name ('pytorch', 'jax', 'tensorflow', 'numpy', 'auto', or None).
              If None or 'auto', automatically selects the best available.

    Returns:
        Backend instance.

    Raises:
        BackendNotAvailableError: If the requested backend is not installed.
    """
    if name is None or name == BackendType.AUTO or name == "auto":
        return _auto_detect()

    if isinstance(name, BackendType):
        name = name.value

    name = name.lower().strip()

    if name in ("pytorch", "torch"):
        from omniai.backends.pytorch_backend import PyTorchBackend

        backend = PyTorchBackend()
        if not backend.is_available:
            raise BackendNotAvailableError("pytorch")
        return backend

    if name == "numpy":
        return NumpyBackend()

    if name in ("jax",):
        # Stub for future JAX backend
        raise BackendNotAvailableError("jax")

    if name in ("tensorflow", "tf"):
        # Stub for future TF backend
        raise BackendNotAvailableError("tensorflow")

    raise BackendNotAvailableError(name)


def _auto_detect() -> Backend:
    """Auto-detect the best available backend.

    Priority: PyTorch > JAX > TensorFlow > NumPy
    """
    # Try PyTorch first
    try:
        from omniai.backends.pytorch_backend import PyTorchBackend

        backend = PyTorchBackend()
        if backend.is_available:
            logger.debug("Auto-detected backend: PyTorch")
            return backend
    except ImportError:
        pass

    # Fall back to NumPy
    logger.debug("Auto-detected backend: NumPy (no deep learning framework found)")
    return NumpyBackend()


def set_backend(name: str | BackendType) -> None:
    """Set the global default backend.

    Args:
        name: Backend name to use globally.
    """
    global _current_backend
    _current_backend = get_backend(name)
    logger.info("Set global backend to: %s", _current_backend.name)


def current_backend() -> Backend:
    """Get the current global backend, auto-detecting if needed.

    Returns:
        The current Backend instance.
    """
    global _current_backend
    if _current_backend is None:
        _current_backend = _auto_detect()
    return _current_backend


def list_available_backends() -> list[str]:
    """List all available backends.

    Returns:
        List of available backend names.
    """
    available = ["numpy"]  # Always available

    try:
        import torch
        available.append("pytorch")
    except ImportError:
        pass

    try:
        import jax
        available.append("jax")
    except ImportError:
        pass

    try:
        import tensorflow
        available.append("tensorflow")
    except ImportError:
        pass

    return available
