"""OmniAI Backends — framework-agnostic compute abstraction."""

from omniai.backends.auto import (
    current_backend,
    get_backend,
    list_available_backends,
    set_backend,
)
from omniai.backends.base import Backend

__all__ = [
    "Backend",
    "get_backend",
    "set_backend",
    "current_backend",
    "list_available_backends",
]
