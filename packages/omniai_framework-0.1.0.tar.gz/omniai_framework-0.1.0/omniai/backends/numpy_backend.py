"""NumPy fallback backend for OmniAI.

Provides CPU-only tensor operations using NumPy. Used as a fallback
when no deep learning framework is installed, primarily for classical ML.
"""

from __future__ import annotations

import math
from typing import Any, Sequence

import numpy as np

from omniai.backends.base import Backend
from omniai.utils.types import DType, Device, Shape, Tensor


class NumpyBackend(Backend):
    """NumPy-based compute backend.

    CPU-only fallback for classical ML and environments without
    PyTorch/JAX/TensorFlow.
    """

    @property
    def name(self) -> str:
        return "numpy"

    @property
    def is_available(self) -> bool:
        return True  # NumPy is always available (it's a core dependency)

    # ── Tensor Creation ────────────────────────────────────────────────────

    def tensor(self, data: Any, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        return np.asarray(data, dtype=dtype)

    def zeros(self, shape: Shape, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        return np.zeros(shape, dtype=dtype or np.float32)

    def ones(self, shape: Shape, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        return np.ones(shape, dtype=dtype or np.float32)

    def randn(self, shape: Shape, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        return np.random.randn(*shape).astype(dtype or np.float32)

    def arange(self, start: int, end: int, step: int = 1, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        return np.arange(start, end, step, dtype=dtype)

    # ── Tensor Properties ─────────────────────────────────────────────────

    def shape(self, tensor: Tensor) -> Shape:
        return tuple(tensor.shape)

    def dtype(self, tensor: Tensor) -> DType:
        return tensor.dtype

    def to_numpy(self, tensor: Tensor) -> Any:
        return np.asarray(tensor)

    def to_device(self, tensor: Tensor, device: Device) -> Tensor:
        return tensor  # NumPy is CPU-only

    # ── Math Operations ────────────────────────────────────────────────────

    def matmul(self, a: Tensor, b: Tensor) -> Tensor:
        return np.matmul(a, b)

    def add(self, a: Tensor, b: Tensor) -> Tensor:
        return np.add(a, b)

    def mul(self, a: Tensor, b: Tensor) -> Tensor:
        return np.multiply(a, b)

    def sum(self, tensor: Tensor, dim: int | None = None, keepdim: bool = False) -> Tensor:
        result = np.sum(tensor, axis=dim, keepdims=keepdim)
        return result

    def mean(self, tensor: Tensor, dim: int | None = None, keepdim: bool = False) -> Tensor:
        result = np.mean(tensor.astype(np.float64), axis=dim, keepdims=keepdim)
        return result.astype(np.float32)

    def softmax(self, tensor: Tensor, dim: int = -1) -> Tensor:
        exp_x = np.exp(tensor - np.max(tensor, axis=dim, keepdims=True))
        return exp_x / np.sum(exp_x, axis=dim, keepdims=True)

    def relu(self, tensor: Tensor) -> Tensor:
        return np.maximum(tensor, 0)

    def gelu(self, tensor: Tensor) -> Tensor:
        return 0.5 * tensor * (1 + np.tanh(math.sqrt(2 / math.pi) * (tensor + 0.044715 * tensor**3)))

    def sigmoid(self, tensor: Tensor) -> Tensor:
        return 1 / (1 + np.exp(-tensor))

    def tanh(self, tensor: Tensor) -> Tensor:
        return np.tanh(tensor)

    def exp(self, tensor: Tensor) -> Tensor:
        return np.exp(tensor)

    def log(self, tensor: Tensor) -> Tensor:
        return np.log(tensor)

    def sqrt(self, tensor: Tensor) -> Tensor:
        return np.sqrt(tensor)

    # ── Shape Operations ───────────────────────────────────────────────────

    def reshape(self, tensor: Tensor, shape: Shape) -> Tensor:
        return np.reshape(tensor, shape)

    def transpose(self, tensor: Tensor, dim0: int, dim1: int) -> Tensor:
        axes = list(range(tensor.ndim))
        axes[dim0], axes[dim1] = axes[dim1], axes[dim0]
        return np.transpose(tensor, axes)

    def cat(self, tensors: Sequence[Tensor], dim: int = 0) -> Tensor:
        return np.concatenate(list(tensors), axis=dim)

    def stack(self, tensors: Sequence[Tensor], dim: int = 0) -> Tensor:
        return np.stack(list(tensors), axis=dim)

    def unsqueeze(self, tensor: Tensor, dim: int) -> Tensor:
        return np.expand_dims(tensor, axis=dim)

    def squeeze(self, tensor: Tensor, dim: int | None = None) -> Tensor:
        if dim is None:
            return np.squeeze(tensor)
        return np.squeeze(tensor, axis=dim)

    # ── Comparison ─────────────────────────────────────────────────────────

    def argmax(self, tensor: Tensor, dim: int | None = None) -> Tensor:
        return np.argmax(tensor, axis=dim)

    def max(self, tensor: Tensor, dim: int | None = None) -> Tensor:
        return np.max(tensor, axis=dim)

    def min(self, tensor: Tensor, dim: int | None = None) -> Tensor:
        return np.min(tensor, axis=dim)
