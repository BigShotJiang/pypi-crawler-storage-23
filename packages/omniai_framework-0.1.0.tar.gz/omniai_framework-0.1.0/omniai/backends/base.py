"""Abstract backend interface for OmniAI.

Defines the tensor operations contract that all backends must implement,
enabling framework-agnostic model code.
"""

from __future__ import annotations

import abc
from typing import Any, Sequence

from omniai.utils.types import DType, Device, Shape, Tensor


class Backend(abc.ABC):
    """Abstract base class for compute backends.

    Each backend (PyTorch, JAX, TensorFlow, NumPy) implements this interface,
    allowing model code to be written once and run on any framework.
    """

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Backend name identifier."""
        ...

    @property
    @abc.abstractmethod
    def is_available(self) -> bool:
        """Whether this backend's dependencies are installed."""
        ...

    # ── Tensor Creation ────────────────────────────────────────────────────

    @abc.abstractmethod
    def tensor(self, data: Any, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        """Create a tensor from data."""
        ...

    @abc.abstractmethod
    def zeros(self, shape: Shape, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        """Create a tensor of zeros."""
        ...

    @abc.abstractmethod
    def ones(self, shape: Shape, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        """Create a tensor of ones."""
        ...

    @abc.abstractmethod
    def randn(self, shape: Shape, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        """Create a tensor of random normal values."""
        ...

    @abc.abstractmethod
    def arange(self, start: int, end: int, step: int = 1, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        """Create a range tensor."""
        ...

    # ── Tensor Properties ─────────────────────────────────────────────────

    @abc.abstractmethod
    def shape(self, tensor: Tensor) -> Shape:
        """Get tensor shape."""
        ...

    @abc.abstractmethod
    def dtype(self, tensor: Tensor) -> DType:
        """Get tensor dtype."""
        ...

    @abc.abstractmethod
    def to_numpy(self, tensor: Tensor) -> Any:
        """Convert tensor to numpy array."""
        ...

    @abc.abstractmethod
    def to_device(self, tensor: Tensor, device: Device) -> Tensor:
        """Move tensor to a device."""
        ...

    # ── Math Operations ────────────────────────────────────────────────────

    @abc.abstractmethod
    def matmul(self, a: Tensor, b: Tensor) -> Tensor:
        """Matrix multiplication."""
        ...

    @abc.abstractmethod
    def add(self, a: Tensor, b: Tensor) -> Tensor:
        """Element-wise addition."""
        ...

    @abc.abstractmethod
    def mul(self, a: Tensor, b: Tensor) -> Tensor:
        """Element-wise multiplication."""
        ...

    @abc.abstractmethod
    def sum(self, tensor: Tensor, dim: int | None = None, keepdim: bool = False) -> Tensor:
        """Sum reduction."""
        ...

    @abc.abstractmethod
    def mean(self, tensor: Tensor, dim: int | None = None, keepdim: bool = False) -> Tensor:
        """Mean reduction."""
        ...

    @abc.abstractmethod
    def softmax(self, tensor: Tensor, dim: int = -1) -> Tensor:
        """Softmax activation."""
        ...

    @abc.abstractmethod
    def relu(self, tensor: Tensor) -> Tensor:
        """ReLU activation."""
        ...

    @abc.abstractmethod
    def gelu(self, tensor: Tensor) -> Tensor:
        """GELU activation."""
        ...

    @abc.abstractmethod
    def sigmoid(self, tensor: Tensor) -> Tensor:
        """Sigmoid activation."""
        ...

    @abc.abstractmethod
    def tanh(self, tensor: Tensor) -> Tensor:
        """Tanh activation."""
        ...

    @abc.abstractmethod
    def exp(self, tensor: Tensor) -> Tensor:
        """Element-wise exponential."""
        ...

    @abc.abstractmethod
    def log(self, tensor: Tensor) -> Tensor:
        """Element-wise natural logarithm."""
        ...

    @abc.abstractmethod
    def sqrt(self, tensor: Tensor) -> Tensor:
        """Element-wise square root."""
        ...

    # ── Shape Operations ───────────────────────────────────────────────────

    @abc.abstractmethod
    def reshape(self, tensor: Tensor, shape: Shape) -> Tensor:
        """Reshape tensor."""
        ...

    @abc.abstractmethod
    def transpose(self, tensor: Tensor, dim0: int, dim1: int) -> Tensor:
        """Transpose two dimensions."""
        ...

    @abc.abstractmethod
    def cat(self, tensors: Sequence[Tensor], dim: int = 0) -> Tensor:
        """Concatenate tensors along a dimension."""
        ...

    @abc.abstractmethod
    def stack(self, tensors: Sequence[Tensor], dim: int = 0) -> Tensor:
        """Stack tensors along a new dimension."""
        ...

    @abc.abstractmethod
    def unsqueeze(self, tensor: Tensor, dim: int) -> Tensor:
        """Add a dimension."""
        ...

    @abc.abstractmethod
    def squeeze(self, tensor: Tensor, dim: int | None = None) -> Tensor:
        """Remove a dimension."""
        ...

    # ── Comparison ─────────────────────────────────────────────────────────

    @abc.abstractmethod
    def argmax(self, tensor: Tensor, dim: int | None = None) -> Tensor:
        """Argmax."""
        ...

    @abc.abstractmethod
    def max(self, tensor: Tensor, dim: int | None = None) -> Tensor:
        """Max value."""
        ...

    @abc.abstractmethod
    def min(self, tensor: Tensor, dim: int | None = None) -> Tensor:
        """Min value."""
        ...

    # ── Display ────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(available={self.is_available})"
