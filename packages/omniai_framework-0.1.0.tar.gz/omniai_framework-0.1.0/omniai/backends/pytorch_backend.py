"""PyTorch backend implementation for OmniAI.

Primary backend providing full tensor operations via PyTorch.
"""

from __future__ import annotations

from typing import Any, Sequence

import numpy as np

from omniai.backends.base import Backend
from omniai.utils.types import DType, Device, Shape, Tensor


class PyTorchBackend(Backend):
    """PyTorch-based compute backend.

    This is the primary backend for OmniAI, providing full GPU acceleration
    and deep learning primitives.
    """

    def __init__(self) -> None:
        self._torch: Any = None

    @property
    def name(self) -> str:
        return "pytorch"

    @property
    def is_available(self) -> bool:
        try:
            import torch
            return True
        except ImportError:
            return False

    @property
    def torch(self) -> Any:
        """Lazy import of torch."""
        if self._torch is None:
            try:
                import torch
                self._torch = torch
            except ImportError:
                raise ImportError(
                    "PyTorch is required but not installed. "
                    "Install with: pip install omniai[torch]"
                )
        return self._torch

    # ── Tensor Creation ────────────────────────────────────────────────────

    def tensor(self, data: Any, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        kwargs: dict[str, Any] = {}
        if dtype is not None:
            kwargs["dtype"] = dtype
        if device is not None:
            kwargs["device"] = device
        if isinstance(data, np.ndarray):
            return self.torch.from_numpy(data).to(**kwargs) if kwargs else self.torch.from_numpy(data)
        return self.torch.tensor(data, **kwargs)

    def zeros(self, shape: Shape, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        kwargs: dict[str, Any] = {}
        if dtype is not None:
            kwargs["dtype"] = dtype
        if device is not None:
            kwargs["device"] = device
        return self.torch.zeros(*shape, **kwargs)

    def ones(self, shape: Shape, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        kwargs: dict[str, Any] = {}
        if dtype is not None:
            kwargs["dtype"] = dtype
        if device is not None:
            kwargs["device"] = device
        return self.torch.ones(*shape, **kwargs)

    def randn(self, shape: Shape, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        kwargs: dict[str, Any] = {}
        if dtype is not None:
            kwargs["dtype"] = dtype
        if device is not None:
            kwargs["device"] = device
        return self.torch.randn(*shape, **kwargs)

    def arange(self, start: int, end: int, step: int = 1, dtype: DType | None = None, device: Device | None = None) -> Tensor:
        kwargs: dict[str, Any] = {}
        if dtype is not None:
            kwargs["dtype"] = dtype
        if device is not None:
            kwargs["device"] = device
        return self.torch.arange(start, end, step, **kwargs)

    # ── Tensor Properties ─────────────────────────────────────────────────

    def shape(self, tensor: Tensor) -> Shape:
        return tuple(tensor.shape)

    def dtype(self, tensor: Tensor) -> DType:
        return tensor.dtype

    def to_numpy(self, tensor: Tensor) -> Any:
        return tensor.detach().cpu().numpy()

    def to_device(self, tensor: Tensor, device: Device) -> Tensor:
        return tensor.to(device)

    # ── Math Operations ────────────────────────────────────────────────────

    def matmul(self, a: Tensor, b: Tensor) -> Tensor:
        return self.torch.matmul(a, b)

    def add(self, a: Tensor, b: Tensor) -> Tensor:
        return a + b

    def mul(self, a: Tensor, b: Tensor) -> Tensor:
        return a * b

    def sum(self, tensor: Tensor, dim: int | None = None, keepdim: bool = False) -> Tensor:
        if dim is None:
            return tensor.sum()
        return tensor.sum(dim=dim, keepdim=keepdim)

    def mean(self, tensor: Tensor, dim: int | None = None, keepdim: bool = False) -> Tensor:
        if dim is None:
            return tensor.float().mean()
        return tensor.float().mean(dim=dim, keepdim=keepdim)

    def softmax(self, tensor: Tensor, dim: int = -1) -> Tensor:
        return self.torch.nn.functional.softmax(tensor, dim=dim)

    def relu(self, tensor: Tensor) -> Tensor:
        return self.torch.nn.functional.relu(tensor)

    def gelu(self, tensor: Tensor) -> Tensor:
        return self.torch.nn.functional.gelu(tensor)

    def sigmoid(self, tensor: Tensor) -> Tensor:
        return self.torch.sigmoid(tensor)

    def tanh(self, tensor: Tensor) -> Tensor:
        return self.torch.tanh(tensor)

    def exp(self, tensor: Tensor) -> Tensor:
        return self.torch.exp(tensor)

    def log(self, tensor: Tensor) -> Tensor:
        return self.torch.log(tensor)

    def sqrt(self, tensor: Tensor) -> Tensor:
        return self.torch.sqrt(tensor)

    # ── Shape Operations ───────────────────────────────────────────────────

    def reshape(self, tensor: Tensor, shape: Shape) -> Tensor:
        return tensor.reshape(shape)

    def transpose(self, tensor: Tensor, dim0: int, dim1: int) -> Tensor:
        return tensor.transpose(dim0, dim1)

    def cat(self, tensors: Sequence[Tensor], dim: int = 0) -> Tensor:
        return self.torch.cat(list(tensors), dim=dim)

    def stack(self, tensors: Sequence[Tensor], dim: int = 0) -> Tensor:
        return self.torch.stack(list(tensors), dim=dim)

    def unsqueeze(self, tensor: Tensor, dim: int) -> Tensor:
        return tensor.unsqueeze(dim)

    def squeeze(self, tensor: Tensor, dim: int | None = None) -> Tensor:
        if dim is None:
            return tensor.squeeze()
        return tensor.squeeze(dim)

    # ── Comparison ─────────────────────────────────────────────────────────

    def argmax(self, tensor: Tensor, dim: int | None = None) -> Tensor:
        if dim is None:
            return tensor.argmax()
        return tensor.argmax(dim=dim)

    def max(self, tensor: Tensor, dim: int | None = None) -> Tensor:
        if dim is None:
            return tensor.max()
        return tensor.max(dim=dim).values

    def min(self, tensor: Tensor, dim: int | None = None) -> Tensor:
        if dim is None:
            return tensor.min()
        return tensor.min(dim=dim).values
