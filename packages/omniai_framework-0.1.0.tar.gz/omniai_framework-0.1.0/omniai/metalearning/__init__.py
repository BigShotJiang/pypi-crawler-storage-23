"""OmniAI Meta-Learning & Few-Shot module.

Meta-learning architectures:
- MAML, Reptile, ProtoNet, Matching Networks
- Meta-SGD
- Learning to Learn architectures
- In-context Learning frameworks
- Task-Agnostic Meta-Learning
- Hypernetworks
"""
