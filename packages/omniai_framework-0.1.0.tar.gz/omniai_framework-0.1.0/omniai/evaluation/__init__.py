"""OmniAI Evaluation Suite module.

Built-in metrics and benchmarks:
- NLP: BLEU, ROUGE, perplexity, BERTScore
- CV: mAP, FID, IS, SSIM, PSNR
- RL: reward curves, episode returns
- Classification: accuracy, precision, recall, F1, AUC-ROC
- Regression: MSE, MAE, R²
- Benchmark suites and leaderboard integration
"""
