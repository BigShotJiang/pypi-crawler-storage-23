"""OmniAI Safety & Alignment module.

AI safety and alignment tools:
- Guardrails and content filtering
- Bias detection and mitigation
- RLHF / DPO / KTO tooling
- Red-teaming utilities
- Toxicity detection
- Fairness metrics
- Interpretability: attention viz, SHAP, GradCAM, probing
"""
