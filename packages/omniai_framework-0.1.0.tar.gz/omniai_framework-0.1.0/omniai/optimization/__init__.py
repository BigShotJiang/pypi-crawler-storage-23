"""OmniAI Optimization module.

Optimizers, schedulers, and training utilities:
- Optimizers: SGD, Adam, AdamW, LAMB, LARS, Lion, Sophia, Shampoo, Prodigy, Schedule-Free
- LR Schedulers: Cosine, Warmup, OneCycle, Cyclic, REX
- Mixed-Precision Training (FP16, BF16, FP8)
- Gradient Accumulation, Gradient Checkpointing
- Curriculum Learning
"""
