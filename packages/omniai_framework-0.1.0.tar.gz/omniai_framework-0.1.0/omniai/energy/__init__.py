"""OmniAI Energy-Based Models module.

Energy-based architectures and contrastive learning:
- Restricted Boltzmann Machines (RBM)
- Deep Boltzmann Machines (DBM)
- Deep Belief Networks (DBN)
- Generic EBM framework
- Contrastive Learning: SimCLR, MoCo, BYOL, Barlow Twins, VICReg, DINO
"""
