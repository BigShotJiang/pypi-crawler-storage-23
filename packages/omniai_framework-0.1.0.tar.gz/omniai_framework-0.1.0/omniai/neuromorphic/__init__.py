"""OmniAI Neuromorphic / Spiking Neural Networks module.

Spiking and neuromorphic architectures:
- Leaky Integrate-and-Fire (LIF) neurons
- Spiking Neural Networks (SNNs)
- STDP (Spike-Timing-Dependent Plasticity)
- Surrogate gradient methods for SNN training
- Integration with Intel Loihi / IBM TrueNorth / BrainChip Akida
- Liquid State Machines
- Echo State Networks / Reservoir Computing
"""
