"""OmniAI structured logging with configurable verbosity.

Provides a unified logging interface for all OmniAI modules,
with support for structured output and experiment tracking integration.
"""

from __future__ import annotations

import logging
import sys
import time
from contextlib import contextmanager
from typing import Any, Generator

# ── Module-level Logger Setup ──────────────────────────────────────────────────

_LOG_FORMAT = "%(asctime)s │ %(levelname)-8s │ %(name)s │ %(message)s"
_LOG_DATE_FORMAT = "%H:%M:%S"

_root_logger = logging.getLogger("omniai")
_initialized = False


def setup_logging(
    level: int | str = logging.INFO,
    log_file: str | None = None,
    rich: bool = False,
) -> None:
    """Configure OmniAI logging.

    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL).
        log_file: Optional path to write logs to file.
        rich: If True and 'rich' is installed, use rich formatting.
    """
    global _initialized
    if _initialized:
        return

    if isinstance(level, str):
        level = getattr(logging, level.upper(), logging.INFO)

    _root_logger.setLevel(level)

    # Console handler
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(level)

    if rich:
        try:
            from rich.logging import RichHandler

            console = RichHandler(
                level=level,
                show_time=True,
                show_path=False,
                markup=True,
            )
        except ImportError:
            pass

    if not isinstance(console, logging.StreamHandler) or not rich:
        formatter = logging.Formatter(_LOG_FORMAT, datefmt=_LOG_DATE_FORMAT)
        console.setFormatter(formatter)

    _root_logger.addHandler(console)

    # File handler
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        file_formatter = logging.Formatter(
            "%(asctime)s │ %(levelname)-8s │ %(name)s │ %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        file_handler.setFormatter(file_formatter)
        _root_logger.addHandler(file_handler)

    _initialized = True


def get_logger(name: str) -> logging.Logger:
    """Get a logger instance for a module.

    Args:
        name: Module name (e.g., 'omniai.core.registry').

    Returns:
        Configured logger instance.
    """
    if not _initialized:
        setup_logging()
    return logging.getLogger(name)


def set_verbosity(level: int | str) -> None:
    """Set the global OmniAI logging verbosity.

    Args:
        level: Logging level.
    """
    if isinstance(level, str):
        level = getattr(logging, level.upper(), logging.INFO)
    _root_logger.setLevel(level)
    for handler in _root_logger.handlers:
        handler.setLevel(level)


# ── Convenience Functions ──────────────────────────────────────────────────────

def debug(msg: str, *args: Any, **kwargs: Any) -> None:
    """Log a debug message."""
    get_logger("omniai").debug(msg, *args, **kwargs)


def info(msg: str, *args: Any, **kwargs: Any) -> None:
    """Log an info message."""
    get_logger("omniai").info(msg, *args, **kwargs)


def warning(msg: str, *args: Any, **kwargs: Any) -> None:
    """Log a warning message."""
    get_logger("omniai").warning(msg, *args, **kwargs)


def error(msg: str, *args: Any, **kwargs: Any) -> None:
    """Log an error message."""
    get_logger("omniai").error(msg, *args, **kwargs)


# ── Timing Context Manager ────────────────────────────────────────────────────

@contextmanager
def log_duration(operation: str, logger: logging.Logger | None = None) -> Generator[None, None, None]:
    """Context manager that logs the duration of an operation.

    Args:
        operation: Description of the operation being timed.
        logger: Logger to use; defaults to omniai root logger.

    Example:
        >>> with log_duration("Model training"):
        ...     train_model()
    """
    _logger = logger or get_logger("omniai")
    _logger.info("Starting: %s", operation)
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        if elapsed < 1:
            _logger.info("Completed: %s in %.1fms", operation, elapsed * 1000)
        elif elapsed < 60:
            _logger.info("Completed: %s in %.2fs", operation, elapsed)
        else:
            minutes = int(elapsed // 60)
            seconds = elapsed % 60
            _logger.info("Completed: %s in %dm %.1fs", operation, minutes, seconds)
