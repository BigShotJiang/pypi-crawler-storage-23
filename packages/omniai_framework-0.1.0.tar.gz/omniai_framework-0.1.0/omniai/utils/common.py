"""Common utility functions used across OmniAI.

Includes seed management, parameter counting, memory tracking, timing,
and other frequently needed helpers.
"""

from __future__ import annotations

import os
import random
import time
from contextlib import contextmanager
from functools import wraps
from pathlib import Path
from typing import Any, Callable, Generator, TypeVar

import numpy as np

from omniai.utils.logging import get_logger
from omniai.utils.types import PathLike

logger = get_logger(__name__)

F = TypeVar("F", bound=Callable[..., Any])


# ── Reproducibility ───────────────────────────────────────────────────────────

def set_seed(seed: int, deterministic: bool = False) -> None:
    """Set random seeds for reproducibility across all frameworks.

    Args:
        seed: Random seed value.
        deterministic: If True, enable deterministic mode (may reduce performance).
    """
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)

    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        if deterministic:
            torch.backends.cudnn.deterministic = True  # type: ignore[attr-defined]
            torch.backends.cudnn.benchmark = False  # type: ignore[attr-defined]
            torch.use_deterministic_algorithms(True)
    except ImportError:
        pass

    try:
        import tensorflow as tf

        tf.random.set_seed(seed)
    except ImportError:
        pass

    logger.debug("Set random seed to %d (deterministic=%s)", seed, deterministic)


# ── Parameter Counting ────────────────────────────────────────────────────────

def count_parameters(model: Any, trainable_only: bool = True) -> int:
    """Count the number of parameters in a model.

    Args:
        model: A model object (PyTorch nn.Module or similar).
        trainable_only: If True, count only trainable parameters.

    Returns:
        Total parameter count.
    """
    try:
        # PyTorch
        if trainable_only:
            return sum(p.numel() for p in model.parameters() if p.requires_grad)
        return sum(p.numel() for p in model.parameters())
    except AttributeError:
        pass

    try:
        # TensorFlow/Keras
        if trainable_only:
            return int(sum(np.prod(w.shape) for w in model.trainable_weights))
        return int(sum(np.prod(w.shape) for w in model.weights))
    except AttributeError:
        pass

    raise TypeError(f"Cannot count parameters for model of type {type(model).__name__}")


def format_param_count(count: int) -> str:
    """Format parameter count in human-readable form.

    Args:
        count: Number of parameters.

    Returns:
        Formatted string (e.g., '7.0B', '350M', '1.2K').
    """
    if count >= 1e9:
        return f"{count / 1e9:.1f}B"
    elif count >= 1e6:
        return f"{count / 1e6:.1f}M"
    elif count >= 1e3:
        return f"{count / 1e3:.1f}K"
    return str(count)


# ── Memory Tracking ───────────────────────────────────────────────────────────

def get_gpu_memory_info() -> dict[str, float]:
    """Get GPU memory usage in GB.

    Returns:
        Dictionary with 'allocated', 'reserved', 'total' memory in GB.
    """
    try:
        import torch

        if torch.cuda.is_available():
            allocated = torch.cuda.memory_allocated() / (1024**3)
            reserved = torch.cuda.memory_reserved() / (1024**3)
            total = torch.cuda.get_device_properties(0).total_mem / (1024**3)
            return {
                "allocated_gb": round(allocated, 2),
                "reserved_gb": round(reserved, 2),
                "total_gb": round(total, 2),
                "free_gb": round(total - allocated, 2),
            }
    except (ImportError, RuntimeError):
        pass

    return {"allocated_gb": 0.0, "reserved_gb": 0.0, "total_gb": 0.0, "free_gb": 0.0}


def get_system_memory_info() -> dict[str, float]:
    """Get system RAM usage in GB.

    Returns:
        Dictionary with 'total', 'available', 'used' memory in GB.
    """
    try:
        import psutil

        mem = psutil.virtual_memory()
        return {
            "total_gb": round(mem.total / (1024**3), 2),
            "available_gb": round(mem.available / (1024**3), 2),
            "used_gb": round(mem.used / (1024**3), 2),
            "percent": mem.percent,
        }
    except ImportError:
        return {"total_gb": 0.0, "available_gb": 0.0, "used_gb": 0.0, "percent": 0.0}


# ── Timing Utilities ──────────────────────────────────────────────────────────

def timer(func: F) -> F:
    """Decorator that logs execution time of a function.

    Example:
        >>> @timer
        ... def slow_function():
        ...     time.sleep(1)
    """

    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start = time.perf_counter()
        result = func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        logger.debug("%s completed in %.3fs", func.__qualname__, elapsed)
        return result

    return wrapper  # type: ignore[return-value]


# ── File Utilities ────────────────────────────────────────────────────────────

def ensure_dir(path: PathLike) -> Path:
    """Create directory if it doesn't exist.

    Args:
        path: Directory path to create.

    Returns:
        The Path object.
    """
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def file_size_str(path: PathLike) -> str:
    """Get human-readable file size.

    Args:
        path: Path to file.

    Returns:
        Formatted size string (e.g., '1.5 GB').
    """
    size = Path(path).stat().st_size
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"


# ── Lazy Import ───────────────────────────────────────────────────────────────

def lazy_import(module_name: str, package: str | None = None) -> Any:
    """Lazily import a module, raising a helpful error if not available.

    Args:
        module_name: Module to import.
        package: Optional package for relative imports.

    Returns:
        The imported module.

    Raises:
        ImportError: With a helpful installation hint.
    """
    import importlib

    try:
        return importlib.import_module(module_name, package)
    except ImportError as e:
        raise ImportError(
            f"Module '{module_name}' is required but not installed. "
            f"Install it with: pip install {module_name.split('.')[0]}"
        ) from e
