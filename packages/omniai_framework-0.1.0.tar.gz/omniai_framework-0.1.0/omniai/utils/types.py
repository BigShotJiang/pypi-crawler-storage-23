"""Common type aliases used across OmniAI.

Provides unified type definitions for tensors, devices, data types,
and other common constructs to ensure consistency across modules.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Literal, Optional, Protocol, Sequence, Tuple, Union

import numpy as np
import numpy.typing as npt

# ── Tensor Types ───────────────────────────────────────────────────────────────

# Generic numpy array type
NumpyArray = npt.NDArray[Any]

# We define a union type that works whether or not torch/jax/tf are installed
Tensor = Any  # Union of torch.Tensor, jax.Array, tf.Tensor, np.ndarray at runtime

# ── Device & Dtype ─────────────────────────────────────────────────────────────

Device = Union[str, Any]  # "cpu", "cuda", "cuda:0", "mps", torch.device, etc.
DType = Any  # torch.dtype, np.dtype, jax dtype, etc.


class DeviceType(str, enum.Enum):
    """Canonical device type identifiers."""
    CPU = "cpu"
    CUDA = "cuda"
    ROCM = "rocm"
    MPS = "mps"
    TPU = "tpu"
    XLA = "xla"
    AUTO = "auto"


class Precision(str, enum.Enum):
    """Supported training precision modes."""
    FP32 = "fp32"
    FP16 = "fp16"
    BF16 = "bf16"
    FP8 = "fp8"
    INT8 = "int8"
    INT4 = "int4"
    MIXED_FP16 = "mixed_fp16"
    MIXED_BF16 = "mixed_bf16"


class BackendType(str, enum.Enum):
    """Supported compute backends."""
    PYTORCH = "pytorch"
    JAX = "jax"
    TENSORFLOW = "tensorflow"
    NUMPY = "numpy"
    AUTO = "auto"


# ── Shape Types ────────────────────────────────────────────────────────────────

Shape = Tuple[int, ...]
BatchSize = int

# ── Path Types ─────────────────────────────────────────────────────────────────

PathLike = Union[str, Path]

# ── Callback Types ─────────────────────────────────────────────────────────────

MetricValue = Union[int, float]
MetricsDict = Dict[str, MetricValue]
LossValue = float

# ── Config Types ───────────────────────────────────────────────────────────────

ConfigDict = Dict[str, Any]
ConfigValue = Union[str, int, float, bool, None, List[Any], Dict[str, Any]]

# ── Data Types ─────────────────────────────────────────────────────────────────

BatchType = Any  # A single batch from a data loader — structure varies
DataLoaderType = Any  # torch.utils.data.DataLoader or similar iterable

# ── Function Types ─────────────────────────────────────────────────────────────

LossFunction = Callable[..., Any]
MetricFunction = Callable[..., MetricValue]
ActivationFunction = Callable[[Tensor], Tensor]
InitializerFunction = Callable[[Tensor], None]


# ── Protocols ──────────────────────────────────────────────────────────────────

class Predictable(Protocol):
    """Protocol for objects that can make predictions."""

    def predict(self, inputs: Any, **kwargs: Any) -> Any:
        ...


class Trainable(Protocol):
    """Protocol for objects that can be trained."""

    def train_step(self, batch: Any) -> MetricsDict:
        ...


class Exportable(Protocol):
    """Protocol for objects that can be exported."""

    def export(self, fmt: str, path: PathLike, **kwargs: Any) -> None:
        ...


class Serializable(Protocol):
    """Protocol for objects that can be saved and loaded."""

    def save(self, path: PathLike) -> None:
        ...

    @classmethod
    def load(cls, path: PathLike) -> "Serializable":
        ...


# ── Distributed Types ─────────────────────────────────────────────────────────

class DistributedStrategy(str, enum.Enum):
    """Distributed training strategies."""
    NONE = "none"
    DDP = "ddp"
    FSDP = "fsdp"
    DEEPSPEED_ZERO1 = "deepspeed_zero1"
    DEEPSPEED_ZERO2 = "deepspeed_zero2"
    DEEPSPEED_ZERO3 = "deepspeed_zero3"
    PIPELINE = "pipeline"
    TENSOR = "tensor"


# ── Model State ────────────────────────────────────────────────────────────────

class ModelPhase(str, enum.Enum):
    """Model lifecycle phases."""
    INITIALIZED = "initialized"
    BUILT = "built"
    TRAINING = "training"
    TRAINED = "trained"
    EXPORTED = "exported"
