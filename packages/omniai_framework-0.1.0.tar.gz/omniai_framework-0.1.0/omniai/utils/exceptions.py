"""OmniAI custom exception hierarchy.

Provides informative, categorized exceptions for all library components.
"""

from __future__ import annotations


class OmniAIError(Exception):
    """Base exception for all OmniAI errors."""

    def __init__(self, message: str, *, hint: str | None = None) -> None:
        self.hint = hint
        full_message = message
        if hint:
            full_message += f"\n  Hint: {hint}"
        super().__init__(full_message)


# ── Config Errors ──────────────────────────────────────────────────────────────

class ConfigError(OmniAIError):
    """Raised when configuration is invalid or missing."""


class ConfigValidationError(ConfigError):
    """Raised when config values fail validation."""

    def __init__(self, field: str, value: object, reason: str) -> None:
        super().__init__(
            f"Invalid config value for '{field}': {value!r}. {reason}",
            hint=f"Check the documentation for valid values of '{field}'.",
        )
        self.field = field
        self.value = value
        self.reason = reason


class ConfigFileError(ConfigError):
    """Raised when a config file cannot be read or parsed."""


# ── Backend Errors ─────────────────────────────────────────────────────────────

class BackendError(OmniAIError):
    """Raised for backend-related issues."""


class BackendNotAvailableError(BackendError):
    """Raised when a requested backend is not installed."""

    def __init__(self, backend: str) -> None:
        super().__init__(
            f"Backend '{backend}' is not available.",
            hint=f"Install it with: pip install omniai[{backend}]",
        )
        self.backend = backend


# ── Registry Errors ────────────────────────────────────────────────────────────

class RegistryError(OmniAIError):
    """Raised for model registry issues."""


class ModelNotFoundError(RegistryError):
    """Raised when a model is not found in the registry."""

    def __init__(self, name: str, available: list[str] | None = None) -> None:
        msg = f"Model '{name}' not found in the registry."
        hint = None
        if available:
            # Find closest matches
            close = [a for a in available if name.lower() in a.lower()][:5]
            if close:
                hint = f"Did you mean one of: {', '.join(close)}?"
            else:
                hint = f"Available models: {', '.join(available[:10])}..."
        super().__init__(msg, hint=hint)
        self.name = name


class DuplicateRegistrationError(RegistryError):
    """Raised when attempting to register a model with an existing name."""

    def __init__(self, name: str) -> None:
        super().__init__(
            f"Model '{name}' is already registered.",
            hint="Use force=True to override, or choose a different name.",
        )
        self.name = name


# ── Model Errors ───────────────────────────────────────────────────────────────

class ModelError(OmniAIError):
    """Raised for model-related issues."""


class ModelBuildError(ModelError):
    """Raised when model construction fails."""


class ModelLoadError(ModelError):
    """Raised when model loading fails."""


# ── Training Errors ────────────────────────────────────────────────────────────

class TrainingError(OmniAIError):
    """Raised for training-related issues."""


class CheckpointError(TrainingError):
    """Raised for checkpoint save/load issues."""


# ── Hardware Errors ────────────────────────────────────────────────────────────

class HardwareError(OmniAIError):
    """Raised for hardware detection/usage issues."""


class DeviceNotAvailableError(HardwareError):
    """Raised when requested hardware device is unavailable."""

    def __init__(self, device: str) -> None:
        super().__init__(
            f"Device '{device}' is not available on this system.",
            hint="Use omniai.core.hardware.get_available_devices() to see what's available.",
        )
        self.device = device


# ── Data Errors ────────────────────────────────────────────────────────────────

class DataError(OmniAIError):
    """Raised for data loading/processing issues."""


class DataFormatError(DataError):
    """Raised when data format is unsupported or malformed."""


# ── Export / Serving Errors ────────────────────────────────────────────────────

class ExportError(OmniAIError):
    """Raised when model export fails."""


class ServingError(OmniAIError):
    """Raised for model serving issues."""
