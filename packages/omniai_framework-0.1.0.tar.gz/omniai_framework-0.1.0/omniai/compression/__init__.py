"""OmniAI Model Compression module.

Pruning, quantization, distillation, and PEFT:
- Pruning: Unstructured, Structured, Movement, SparseGPT, Wanda
- Quantization: PTQ, QAT, GPTQ, AWQ, GGUF/GGML, SqueezeLLM, QuIP#, HQQ
- Knowledge Distillation
- LoRA, QLoRA, DoRA, AdaLoRA, LoRA+, LoHa, LoKr, GaLore
- Full PEFT suite
"""
