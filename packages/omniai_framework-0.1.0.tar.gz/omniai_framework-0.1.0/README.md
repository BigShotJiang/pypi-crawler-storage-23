# 🧠 OmniAI

**A unified, modular framework for building, training, and deploying ALL AI/ML/LLM architectures.**

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://python.org)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache%202.0-green.svg)](https://opensource.org/licenses/Apache-2.0)

---

## ⚡ Quick Start

```python
from omniai import Model, Config, Trainer, registry

# Config-driven model creation
config = Config.from_yaml("configs/llama_7b.yaml")
model = Model.build(config)

# Or programmatic
model = Model.build(
    arch="transformer.llama",
    hidden_size=4096,
    num_layers=32,
)

# Unified training
trainer = Trainer(model=model, train_data=loader, optimizer="adamw")
trainer.fit(epochs=3)

# Inference & export
output = model.predict(input_data)
model.export("onnx", path="model.onnx")
```

## 📦 Installation

```bash
# Core (NumPy only, classical ML)
pip install omniai

# With PyTorch (deep learning, transformers, LLMs)
pip install omniai[torch]

# Specific domains
pip install omniai[llm]          # LLM tools + transformers + tokenizers
pip install omniai[diffusion]    # Diffusion models
pip install omniai[rl]           # Reinforcement learning
pip install omniai[quantum]      # Quantum ML
pip install omniai[classical]    # scikit-learn, XGBoost, LightGBM

# Everything
pip install omniai[all]
```

## 🏗️ Architecture

```
omniai/
├── core/              # Base classes, config, registry, callbacks
├── backends/          # PyTorch, JAX, TF, NumPy abstraction
├── classical/         # SVM, trees, clustering, Bayesian
├── deep/              # MLP, CNN, RNN, autoencoders
├── transformers/      # BERT, GPT, LLaMA, Mamba, ViT, ...
├── llm/               # Tokenizers, generation, serving
├── diffusion/         # DDPM, Stable Diffusion, DiT, ...
├── gan/               # StyleGAN, CycleGAN, normalizing flows
├── rl/                # DQN, PPO, SAC, RLHF, DPO
├── graph/             # GCN, GAT, GraphSAGE, equivariant GNNs
├── thermodynamic/     # Thermodynamic computing, equilibrium prop
├── quantum/           # VQE, QAOA, tensor networks
├── neuromorphic/      # Spiking NNs, reservoir computing
├── evolutionary/      # NAS, genetic algorithms, CMA-ES
├── memory/            # NTM, DNC, Hopfield networks
├── energy/            # RBM, DBN, contrastive learning
├── neurosymbolic/     # Neural theorem provers, concept bottleneck
├── metalearning/      # MAML, ProtoNet, hypernetworks
├── continual/         # EWC, progressive networks
├── selfsupervised/    # MLM, MAE, JEPA, BYOL
├── multimodal/        # CLIP, text-to-image/video/audio
├── agents/            # ReAct, CoT, tool-using agents
├── optimization/      # AdamW, Lion, Sophia, schedulers
├── distributed/       # DDP, FSDP, DeepSpeed
├── compression/       # Pruning, quantization, LoRA/PEFT
├── data/              # Multi-modal data pipelines
├── evaluation/        # BLEU, FID, mAP, perplexity
├── serving/           # REST API, ONNX, vLLM-style inference
└── safety/            # Guardrails, RLHF, bias detection
```

## 🔑 Key Features

| Feature | Description |
|---------|-------------|
| **Unified API** | Consistent `.build()`, `.train()`, `.predict()`, `.export()` across all architectures |
| **Backend-agnostic** | Write once, run on PyTorch, JAX, TensorFlow, or NumPy |
| **Hardware-aware** | Auto-detects CPU, CUDA, ROCm, Apple MPS, TPU |
| **Config-driven** | YAML/JSON/dataclass configs with inheritance and validation |
| **Model Registry** | Global registry with `@register` decorator, search, categories |
| **Callbacks** | EarlyStopping, ModelCheckpoint, LR monitoring, custom hooks |
| **Production-ready** | Type hints, comprehensive error messages, logging, checkpointing |

## 🧪 Running Tests

```bash
pip install omniai[dev]
pytest tests/ -v
```

## 📖 Examples

```bash
python examples/quickstart.py
```

## 📄 License

Apache 2.0 — see [LICENSE](LICENSE) for details.
