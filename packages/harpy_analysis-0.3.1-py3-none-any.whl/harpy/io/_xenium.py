from __future__ import annotations

import json
import os
from collections.abc import Iterable, Mapping
from pathlib import Path
from types import MappingProxyType
from typing import Any

import dask.dataframe as dd
import numpy as np
import pandas as pd
from loguru import logger as log
from spatialdata import SpatialData, read_zarr
from spatialdata._logging import logger
from spatialdata.models import TableModel
from spatialdata.transformations import Scale, Sequence, get_transformation, set_transformation
from spatialdata_io import xenium as sdata_xenium
from spatialdata_io._constants._constants import XeniumKeys

from harpy.io._transcripts import read_transcripts
from harpy.utils._keys import _INSTANCE_KEY, _REGION_KEY, _SPATIAL


def xenium(
    path: str | Path | list[str] | list[Path],
    to_coordinate_system: str | list[str] = "global",
    aligned_images: bool = True,
    cells_labels: bool = True,
    nucleus_labels: bool = True,
    morphology_mip: bool = False,
    morpholohy_focus: bool = True,
    cells_table: bool = True,
    filter_gene_names: str | list[str] = None,
    imread_kwargs: Mapping[str, Any] = MappingProxyType({}),
    image_models_kwargs: Mapping[str, Any] = MappingProxyType({}),
    labels_models_kwargs: Mapping[str, Any] = MappingProxyType({}),
    instance_key: str = _INSTANCE_KEY,
    region_key: str = _REGION_KEY,
    spatial_key: str = _SPATIAL,
    output: str | Path | None = None,
) -> SpatialData:
    """
    Read a *10X Genomics Xenium* dataset into a :class:`~spatialdata.SpatialData` object.

    Wrapper around :func:`spatialdata_io.xenium` that adds some additional capabilities:
    (i) adding a micron-based coordinate system, and
    (ii) loading multiple samples into a single SpatialData object.

    This function reads images, transcripts, masks (cell and nuclei) and tables, so it can be used for analysis.
    The resulting :class:`~anndata.AnnData` table will be annotated by a labels layer.

    The micron coordinate system is added as '{to_coordinate_system}_micron' and is available to all spatial elements within the resulting SpatialData object.

    Cell and nuclear boundaries provided by Xenium will not be loaded, as these polygonal versions of the cell and nucleus labels are approximations.
    They can however be generated from the cell and nuclear labels using :func:`harpy.sh.vectorize`.

    This function reads the following files:

        - ``{xx.XENIUM_SPECS!r}``: File containing specifications.
        - ``{xx.TRANSCRIPTS_FILE!r}``: File containing transcripts.
        - ``{xx.CELL_FEATURE_MATRIX_FILE!r}``: File containing cell feature matrix.
        - ``{xx.CELL_METADATA_FILE!r}``: File containing cell metadata.
        - ``{xx.MORPHOLOGY_MIP_FILE!r}``: File containing morphology mip.
        - ``{xx.MORPHOLOGY_FOCUS_FILE!r}``: File containing morphology focus.

    .. seealso::

        - `10X Genomics Xenium file format  <https://cf.10xgenomics.com/supp/xenium/xenium_documentation.html>`_.

    Parameters
    ----------
    path
        Specifies the location of the dataset. This can either be a single path or a list of paths, where each path corresponds to a different experiment/roi.
    to_coordinate_system
        The coordinate system to which the images, segmentation masks and transcripts will be added for each item in path.
        If provided as a list, its length should be equal to the number of paths specified in `path`.
    aligned_images
        Whether to also parse, when available, additional H&E or IF aligned images. For more control over the aligned
        images being read, in particular, to specify the axes of the aligned images, please set this parameter to
        `False` and use the `xenium_aligned_image` function directly.
    cells_labels
        Whether to read cell labels (raster) provided by Xenium. The polygonal version of the cell labels are simplified
        for visualization purposes, and using the raster version is recommended for analysis.
    nucleus_labels
        Whether to read nucleus labels (raster) provided by Xenium. The polygonal version of the nucleus labels are simplified
        for visualization purposes, and using the raster version is recommended for analysis.
    morphology_mip
        Whether to read the morphology mip image (available in versions < 2.0.0).
    morphology_focus
        Whether to read the morphology focus image.
    cells_table
        Whether to read the cell annotations in the `AnnData` table.
        Will be added to the `f"table_{to_coordinate_system}"` slot in `sdata.tables`, or  f"table_{to_coordinate_system[i]}" if `to_coordinate_system` is a list.
        If `True`, labels layer annotating the table will also be added to `sdata`.
    filter_gene_names
        Gene names that need to be filtered out (via `str.contains`), mostly control genes that were added, and which you don't want to use.
        Filtering is case insensitive. Also see :func:`harpy.read_transcripts`.
    imread_kwargs
        Keyword arguments to pass to the image reader.
    image_models_kwargs
        Keyword arguments to pass to the image models.
    labels_models_kwargs
        Keyword arguments to pass to the labels models.
    instance_key
        Instance key. The name of the column in :class:`~anndata.AnnData` table `.obs` that will hold the instance ids.
        Ignored if `table` is `False`.
    region_key
        Region key. The name of the column in  :class:`~anndata.AnnData` table `.obs` that will hold the name of the elements that annotate the table.
        Ignored if `table` is `False`.
    spatial_key
        The key in the :class:`~anndata.AnnData` table `.obsm` that will hold the `x` and `y` center of the instances.
        Ignored if `table` is `False`.
    output
        The path where the resulting :class:`~spatialdata.SpatialData` object object will be backed. If `None`, it will not be backed to a Zarr store.

    Raises
    ------
    AssertionError
        Raised when the number of elements in `path` and `to_coordinate_system` are not the same.
    AssertionError
        If elements in `to_coordinate_system` are not unique.
    AssertionError
        If `cells_table` is `True`, but the labels layer annotating the table is not found.

    Returns
    -------
    A :class:`~spatialdata.SpatialData` object object.
    """

    def _fix_name(item: str | Iterable[str]):
        return list(item) if isinstance(item, Iterable) and not isinstance(item, str) else [item]

    path = _fix_name(path)
    to_coordinate_system = _fix_name(to_coordinate_system)
    assert len(path) == len(to_coordinate_system), (
        "If parameters 'path' and/or 'to_coordinate_system' are specified as a list, their length should be equal."
    )
    assert len(to_coordinate_system) == len(set(to_coordinate_system)), (
        "All elements specified via 'to_coordinate_system' should be unique."
    )
    if cells_table and not cells_labels:
        log.info("Setting 'cell_labels' to 'True' to allow annotation of the table with the associated labels layer.")
        cells_labels = True

    sdata = SpatialData()
    # back the images to the zarr store, so we avoid having to persist the transcripts in memory in the read_transcripts step.
    if output is not None:
        sdata.write(output)
        sdata = read_zarr(output)

    for _path, _to_coordinate_system in zip(path, to_coordinate_system, strict=True):
        _sdata = sdata_xenium(
            path=_path,
            cells_boundaries=False,  # use harpy.sh.vectorize on the cell labels
            nucleus_boundaries=False,  # use harpy.sh.vectorize on the nucleus labels
            cells_labels=cells_labels,
            nucleus_labels=nucleus_labels,
            morphology_mip=morphology_mip,
            morphology_focus=morpholohy_focus,
            cells_as_circles=False,
            transcripts=False,  # we have our own reader for transcripts
            cells_table=cells_table,
            aligned_images=aligned_images,
            imread_kwargs=imread_kwargs,
            image_models_kwargs=image_models_kwargs,
            labels_models_kwargs=labels_models_kwargs,
        )

        layers = [*_sdata.images] + [*_sdata.labels]

        with open(os.path.join(_path, XeniumKeys.XENIUM_SPECS)) as f:
            specs = json.load(f)
            pixel_size = specs["pixel_size"]

        scale_pixels_to_micron = Scale(axes=("x", "y"), scale=[pixel_size, pixel_size])

        for _layer in layers:
            # rename coordinate system "global" to _to_coordinate_system, and add micron coordinate system
            transformation = get_transformation(_sdata[_layer], to_coordinate_system="global")
            transformations = {
                _to_coordinate_system: transformation,
                f"{_to_coordinate_system}_micron": Sequence([transformation, scale_pixels_to_micron]),
            }
            set_transformation(_sdata[_layer], transformation=transformations, set_all=True)
            _sdata[f"{_layer}_{_to_coordinate_system}"] = _sdata[_layer]
            del _sdata[_layer]

        if cells_table:
            adata = _sdata["table"]
            assert f"cell_labels_{_to_coordinate_system}" in [*_sdata.labels], (
                "labels layer annotating the table is not found in SpatialData object."
            )
            # set "cell_id" column in table as index, because anndata does not allow both "cell_id" and "cell_ID" (=_INSTANCE_KEY) as columns in obs.
            if XeniumKeys.CELL_ID in adata.obs.columns:
                logger.info(f"Setting '{XeniumKeys.CELL_ID}' as table index.")
                adata.obs.set_index(XeniumKeys.CELL_ID, inplace=True)
            adata.obs.rename(columns={"region": region_key, "cell_labels": instance_key}, inplace=True)
            adata.obs[region_key] = pd.Categorical(adata.obs[region_key].astype(str) + f"_{_to_coordinate_system}")
            adata.uns.pop(TableModel.ATTRS_KEY)
            adata.obsm[spatial_key] = adata.obsm[spatial_key] * (1 / pixel_size)
            adata = TableModel.parse(
                adata,
                region_key=region_key,
                region=adata.obs[region_key].cat.categories.to_list(),
                instance_key=instance_key,
            )

            del _sdata["table"]

            _sdata[f"table_{_to_coordinate_system}"] = adata

        layers = [*_sdata.images] + [*_sdata.labels] + [*_sdata.tables]

        for _layer in layers:
            sdata[_layer] = _sdata[_layer]
            if sdata.is_backed():
                sdata.write_element(_layer)

        if sdata.is_backed():
            sdata = read_zarr(sdata.path)

    # now read the transcripts
    for _path, _to_coordinate_system in zip(path, to_coordinate_system, strict=True):
        table = dd.read_parquet(os.path.join(_path, XeniumKeys.TRANSCRIPTS_FILE))

        with open(os.path.join(_path, XeniumKeys.XENIUM_SPECS)) as f:
            specs = json.load(f)

        # Create a 3x3 identity matrix
        affine_matrix = np.eye(3)

        affine_matrix[0, 0] = 1 / pixel_size  # Scaling in x
        affine_matrix[1, 1] = 1 / pixel_size  # Scaling in y

        column_x_name = XeniumKeys.TRANSCRIPTS_X
        column_y_name = XeniumKeys.TRANSCRIPTS_Y
        column_gene_name = XeniumKeys.FEATURE_NAME

        column_x = table.columns.get_loc(column_x_name)
        column_y = table.columns.get_loc(column_y_name)
        column_gene = table.columns.get_loc(column_gene_name)

        sdata = read_transcripts(
            sdata,
            path_count_matrix=os.path.join(_path, XeniumKeys.TRANSCRIPTS_FILE),
            transform_matrix=affine_matrix,
            output_layer=f"transcripts_{_to_coordinate_system}",
            column_x=column_x,
            column_y=column_y,
            column_z=None,
            column_gene=column_gene,
            to_coordinate_system=_to_coordinate_system,
            to_micron_coordinate_system=f"{_to_coordinate_system}_micron",
            filter_gene_names=filter_gene_names,
            overwrite=False,
        )

    return sdata
