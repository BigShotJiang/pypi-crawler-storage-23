from __future__ import annotations

from collections.abc import Iterable, Mapping
from types import MappingProxyType
from typing import Any

import numpy as np
import pandas as pd
import scanpy as sc
from loguru import logger as log
from scipy.sparse import issparse
from spatialdata import SpatialData

from harpy.image._image import get_dataarray
from harpy.shape._shape import filter_shapes_layer
from harpy.table._table import ProcessTable, add_table_layer
from harpy.utils._aggregate import _get_mask_area
from harpy.utils._keys import _CELLSIZE_KEY, _RAW_COUNTS_KEY


def preprocess_transcriptomics(
    sdata: SpatialData,
    labels_layer: str | Iterable[str],
    table_layer: str,
    output_layer: str,
    percent_top: tuple[int, ...] = (2, 5),
    min_counts: int = 10,
    min_cells: int = 5,
    size_norm: bool = True,
    library_norm: bool = False,
    highly_variable_genes: bool = False,
    highly_variable_genes_kwargs: Mapping[str, Any] = MappingProxyType({}),
    max_value_scale: float | None = 10,
    n_comps: int = 50,
    update_shapes_layers: bool = True,
    instance_size_key: str = _CELLSIZE_KEY,
    raw_counts_key: str = _RAW_COUNTS_KEY,
    overwrite: bool = False,
) -> SpatialData:
    """
    Preprocess a table (AnnData) attribute of a SpatialData object for transcriptomics data.

    Performs filtering (via :func:`~scanpy.pp.filter_cells` and :func:`~scanpy.pp.filter_genes` ) and optional normalization (on size or via :func:`~scanpy.sc.pp.normalize_total`),
    log transformation (:func:`~scanpy.pp.log1p`), highly variable genes selection (:func:`~scanpy.pp.highly_variable_genes`),
    scaling (:func:`~scanpy.pp.scale`), and PCA calculation (:func:`~scanpy.pp.pca`) for transcriptomics data
    contained in the `sdata.tables[table_layer]`. QC metrics are added to `sdata.tables[output_layer].obs` using :func:`~scanpy.pp.calculate_qc_metrics`.

    Parameters
    ----------
    sdata
        The input SpatialData object.
    labels_layer
        The labels layer(s) of `sdata` used to select the cells via the region key in `sdata.tables[table_layer].obs`.
        Note that if `output_layer` is equal to `table_layer` and overwrite is `True`,
        cells in `sdata.tables[table_layer]` linked to other `labels_layer` (via the region key), will be removed from `sdata.tables[table_layer]`
        (also from the backing zarr store if it is backed).
    table_layer
        The table layer in `sdata` on which to perform preprocessing on.
    output_layer
        The output table layer in `sdata` to which preprocessed table layer will be written.
    percent_top
        List of ranks (where genes are ranked by expression) at which the cumulative proportion of expression will be reported as a percentage.
        Passed to :func:`~scanpy.pp.calculate_qc_metrics`.
    min_counts
        Minimum number of genes a cell should contain to be kept (passed to :func:`~scanpy.pp.filter_cells`).
    min_cells
        Minimum number of cells a gene should be in to be kept (passed to :func:`~scanpy.pp.filter_genes`).
    size_norm
        If `True`, normalization is based on the size of the nucleus/cell. Resulting values are multiplied by 100 after normalization.
    library_norm
        If `True`, :func:`~scanpy.sc.pp.normalize_total` is used for normalization.
    highly_variable_genes
        If `True`, will only retain highly variable genes, as calculated by :func:`~scanpy.pp.highly_variable_genes`.
    highly_variable_genes_kwargs
        Keyword arguments passed to :func:`~scanpy.pp.highly_variable_genes`. Ignored if `highly_variable_genes` is `False`.
    max_value_scale
        The maximum value to which data will be scaled, when scaling the data to have zero mean and a variance of one, using :func:`~scanpy.pp.scale`.
    n_comps
        Number of principal components to calculate.
    update_shapes_layers
        Whether to filter the shapes layers associated with `labels_layer`.
        If set to `True`, cells that do not appear in resulting `output_layer` (with the region key equal to `labels_layer`) will be removed from the shapes layers (via region key) in the `sdata` object.
        Filtered shapes will be added to `sdata` with prefix 'filtered_low_counts'.
        This parameter is deprecated, and will be removed in a future version.
    instance_size_key
        The key in the :class:`~anndata.AnnData` table `.obs` that holds the size of the instances. If `instance_size_key` is not found in `.obs` it will be calculated from the `labels_layer`.
        Ignored if `size_norm` is `False`.
    raw_counts_key
        Name of the :class:`~anndata.AnnData` layer where the non-preprocessed counts will be stored.
    overwrite
        If True, overwrites the `output_layer` if it already exists in `sdata`.

    Returns
    -------
    The `sdata` containing the preprocessed AnnData object as an attribute (`sdata.tables[output_layer]`).

    Raises
    ------
    ValueError
        If `sdata` does not have labels attribute.
    ValueError
        If `sdata` does not have tables attribute.
    ValueError
        If `labels_layer`, or one of the element of `labels_layer` is not a labels layer in `sdata`.
    ValueError
        If `table_layer` is not a table layer in `sdata`.


    Warnings
    --------
    - If `max_value_scale` is set too low, it may overly constrain the variability of the data,
      potentially impacting downstream analyses.
    - If the dimensionality of `sdata.tables[table_layer]` is smaller than the desired number of principal components, `n_comps` is set to the minimum dimensionality, and a message is printed.

    See Also
    --------
    harpy.tb.allocate : create an AnnData table in `sdata` using a `points_layer` and a `labels_layer`.
    """
    preprocess_instance = Preprocess(sdata, labels_layer=labels_layer, table_layer=table_layer)
    sdata = preprocess_instance.preprocess(
        output_layer=output_layer,
        calculate_qc_metrics=True,
        filter_cells=True,
        filter_genes=True,
        calculate_cell_size=True,
        size_norm=size_norm,
        library_norm=library_norm,
        log1p=True,
        highly_variable_genes=highly_variable_genes,
        highly_variable_genes_kwargs=highly_variable_genes_kwargs,
        scale=True,
        max_value_scale=max_value_scale,
        calculate_pca=True,
        update_shapes_layers=update_shapes_layers,
        qc_kwargs={"percent_top": percent_top},
        filter_cells_kwargs={"min_counts": min_counts},
        filter_genes_kwargs={"min_cells": min_cells},
        pca_kwargs={"n_comps": n_comps},
        instance_size_key=instance_size_key,
        raw_counts_key=raw_counts_key,
        overwrite=overwrite,
    )
    return sdata


def preprocess_proteomics(
    sdata: SpatialData,
    labels_layer: str | Iterable[str],
    table_layer: str,
    output_layer: str,
    size_norm: bool = True,
    library_norm: bool = False,
    log1p: bool = True,
    scale: bool = False,
    max_value_scale: float | None = 10,
    q: float | None = None,
    max_value_q: float | None = 1,
    calculate_pca: bool = False,
    n_comps: int = 50,
    instance_size_key: str = _CELLSIZE_KEY,
    raw_counts_key: str = _RAW_COUNTS_KEY,
    overwrite: bool = False,
) -> SpatialData:
    """
    Preprocess a table (AnnData) attribute of a SpatialData object for proteomics data.

    Performs optional normalization (on size or via :func:`~scanpy.pp.normalize_total`), log transformation
    (:func:`~scanpy.pp.log1p`), scaling (:func:`~scanpy.pp.scale`)/ quantile normalization and PCA calculation (:func:`~scanpy.pp.pca`)
    for proteomics data contained in `sdata`.

    Parameters
    ----------
    sdata
        The input SpatialData object.
    labels_layer
        The labels layer(s) of `sdata` used to select the cells via the region key in `sdata.tables[table_layer].obs`.
        Note that if `output_layer` is equal to `table_layer` and overwrite is True,
        cells in `sdata.tables[table_layer]` linked to other `labels_layer` (via the region key), will be removed from `sdata.tables[table_layer]`.
        If a list of labels layers is provided, they will therefore be preprocessed together (e.g. multiple samples).
    table_layer
        The table layer in sdata to apply preprocessing to.
        It is an AnnData object containing total intensities per cell in `.obs` (rows) and per channel in `.var` (columns).
    output_layer
        The output table layer in `sdata` to which preprocessed table layer will be written.
    size_norm
        If `True`, normalization is based on the size of the nucleus/cell. Resulting values are multiplied by 100 after normalization.
    library_norm
        If `True`, :func:`~scanpy.pp.normalize_total` is used for normalization.
    log1p
        If `True`, applies log1p transformation to the data (via :func:`~scanpy.pp.log1p`), after optional normalization.
    scale
        If `True`, scales the data to have zero mean and a variance of one. The scaling is capped at `max_value_scale`.
    max_value_scale
        The maximum value to which data will be scaled. Ignored if `scale` is `False`.
    q
        Quantile used for normalization. If specified, values are normalized by this quantile calculated for each `adata.var`. Typical value used is 0.999.
        Resulting values are multiplied by 100 after normalization.
    max_value_q
        The maximum value to which data will be scaled when performing quantile normalization. Ignored if `q` is `None`. Typical value is 1.
        Resulting values are multiplied by 100 after normalization.
    calculate_pca
        If `True`, calculates principal component analysis (PCA) on the data.
    n_comps
        Number of principal components to calculate. Ignored if `calculate_pca` is False.
    instance_size_key
        The key in the :class:`~anndata.AnnData` table `.obs` that holds the size of the instances. If `instance_size_key` is not found in `.obs` it will be calculated from the `labels_layer`.
        Ignored if `size_norm` is `False`.
    raw_counts_key
        Name of the :class:`~anndata.AnnData` layer where the non-preprocessed intensities will be stored.
        This parameter is ignored if no preprocessing is applied (i.e. `size_norm`, `library_norm`, `log1p`, `scale` are all `False` and q is `None`).
    overwrite
        If `True`, overwrites the `output_layer` if it already exists in `sdata`.

    Returns
    -------
    The `sdata` containing the preprocessed AnnData object as an attribute (`sdata.tables[output_layer]`).

    Raises
    ------
    ValueError
        - If `sdata` does not contains any labels layers.
        - If `sdata` does not contain any table layers.
        - If `labels_layer`, or one of the element of `labels_layer` is not a labels layer in `sdata`.
        - If `table_layer` is not a table layer in `sdata`.
        - If both `scale` is set to True and `q` is not None.

    Warnings
    --------
    - If `scale` is True and `max_value_scale` is set too low, it may overly constrain the variability of the data,
      potentially impacting downstream analyses.
    - If the dimensionality of `sdata.tables[table_layer]` is smaller than the desired number of principal components
      when `calculate_pca` is True, `n_comps` is set to the minimum dimensionality, and a message is printed.

    See Also
    --------
    harpy.tb.allocate_intensity : create an AnnData table in `sdata` using an `image_layer` and a `labels_layer`.
    """
    preprocess_instance = Preprocess(sdata, labels_layer=labels_layer, table_layer=table_layer)
    sdata = preprocess_instance.preprocess(
        output_layer=output_layer,
        calculate_qc_metrics=False,
        filter_cells=False,
        filter_genes=False,
        calculate_cell_size=True,
        size_norm=size_norm,
        library_norm=library_norm,
        log1p=log1p,
        scale=scale,
        max_value_scale=max_value_scale,
        q=q,
        max_value_q=max_value_q,
        highly_variable_genes=False,
        calculate_pca=calculate_pca,
        update_shapes_layers=False,
        pca_kwargs={"n_comps": n_comps},
        instance_size_key=instance_size_key,
        raw_counts_key=raw_counts_key,
        overwrite=overwrite,
    )
    return sdata


class Preprocess(ProcessTable):
    def preprocess(
        self,
        output_layer: str,
        calculate_qc_metrics: bool = True,
        filter_cells: bool = True,
        filter_genes: bool = True,
        calculate_cell_size: bool = True,
        size_norm: bool = True,
        library_norm: bool = False,
        log1p: bool = True,
        scale: bool = True,
        max_value_scale: float | None = 10,  # ignored if scale is False,
        q: float | None = None,  # quantile for normalization, typically 0.999
        max_value_q: float | None = 1,  # ignored if q is None
        highly_variable_genes: bool = False,
        calculate_pca: bool = True,
        update_shapes_layers: bool = True,  # whether to update the shapes layer based on the items filtered out in sdata.tables[self.table_layer].
        qc_kwargs: Mapping[str, Any] = MappingProxyType({}),  # keyword arguments passed to sc.pp.calculate_qc_metrics
        filter_cells_kwargs: Mapping[str, Any] = MappingProxyType({}),  # keyword arguments passed to sc.pp.filter_cells
        filter_genes_kwargs: Mapping[str, Any] = MappingProxyType({}),  # keyword arguments passed to sc.pp.filter_genes
        norm_kwargs: Mapping[str, Any] = MappingProxyType({}),  # keyword arguments passed to sc.pp.normalize_total.
        highly_variable_genes_kwargs: Mapping[str, Any] = MappingProxyType(
            {}
        ),  # keyword arguments passed to sc.pp.highly_variable_genes
        pca_kwargs: Mapping[str, Any] = MappingProxyType({}),  # keyword arguments passed to sc.pp.pca
        instance_size_key: str = _CELLSIZE_KEY,
        raw_counts_key: str = _RAW_COUNTS_KEY,
        overwrite: bool = False,
    ) -> SpatialData:
        adata = self._get_adata()
        # Calculate QC Metrics
        if calculate_qc_metrics:
            sc.pp.calculate_qc_metrics(adata, layer=None, inplace=True, **qc_kwargs)

            # Filter cells and genes
            if filter_cells:
                sc.pp.filter_cells(adata, inplace=True, copy=False, **filter_cells_kwargs)
            if filter_genes:
                sc.pp.filter_genes(adata, inplace=True, copy=False, **filter_genes_kwargs)

        if calculate_cell_size:
            # we do not want to loose the index (_CELL_INDEX)
            old_index = adata.obs.index
            index_name = adata.obs.index.name or "index"
            if instance_size_key in adata.obs.columns:
                log.warning(
                    f"Column with name '{instance_size_key}' already exists. Removing column '{instance_size_key}'."
                )
                adata.obs = adata.obs.drop(columns=instance_size_key)
            for i, _labels_layer in enumerate(self.labels_layer):
                log.info(f"Calculating cell size from provided labels_layer '{_labels_layer}'")
                se = get_dataarray(self.sdata, layer=_labels_layer)
                _shapesize = _get_mask_area(
                    se.data if se.data.ndim == 3 else se.data[None, ...],
                    instance_key=self.instance_key,
                    instance_size_key=instance_size_key,
                )
                _shapesize[self.region_key] = _labels_layer
                if i == 0:
                    shapesize = _shapesize
                else:
                    shapesize = pd.concat([shapesize, _shapesize], ignore_index=True)
            # note that we checked that adata.obs[ self.instance_key ] is unique for given region (see self._get_adata())
            adata.obs = pd.merge(
                adata.obs.reset_index(), shapesize, on=[self.instance_key, self.region_key], how="left"
            )
            adata.obs.index = old_index
            adata.obs = adata.obs.drop(columns=[index_name])

        if any([size_norm, library_norm, log1p, scale]) or q is not None:
            log.info(f"Saving non preprocessed data matrix to the AnnData '.layers[{raw_counts_key}]'.")
            if raw_counts_key in adata.layers:
                log.warning(
                    f"Key '{raw_counts_key}' already exists in '.layers'. "
                    "You are probably preprocessing an already preprocessed table."
                )
            adata.layers[raw_counts_key] = adata.X.copy()

        if size_norm and library_norm:
            raise ValueError(
                "Both 'size_norm' and 'library_norm' were set to True. Please set only one of them to True."
            )

        if size_norm:
            X_size_norm = (
                adata.X.T * 100 / adata.obs[instance_size_key].values
            ).T  # *100 for numerical stability. Otherwise sc.pp.highly_variable_genes could filter too many values.
            if issparse(adata.X):
                adata.X = X_size_norm.tocsr()
            else:
                adata.X = X_size_norm
        if library_norm:
            sc.pp.normalize_total(adata, layer=None, copy=False, inplace=True, **norm_kwargs)

        if log1p:
            sc.pp.log1p(adata, base=None, copy=False, layer=None, obsm=None)

        if highly_variable_genes:
            sc.pp.highly_variable_genes(adata, layer=None, inplace=True, subset=False, **highly_variable_genes_kwargs)
            if adata.raw is None:
                adata.raw = adata.copy()
            adata = adata[:, adata.var.highly_variable]

        if scale and q is not None:
            raise ValueError(
                "Please choose between scaling via 'scanpy.pp.scale' or normalization by q quantile, not both."
            )

        if scale:
            if adata.raw is None:
                adata.raw = adata.copy()
            sc.pp.scale(adata, copy=False, layer=None, obsm=None, zero_center=True, max_value=max_value_scale)

        if q is not None:
            if adata.raw is None:
                adata.raw = adata.copy()
            arr = adata.X.toarray() if issparse(adata.X) else adata.X  # np.where not defined on sparse matrix
            arr = np.where(arr == 0, np.nan, arr)
            arr_quantile = np.nanquantile(arr, q, axis=0)
            adata.X = (adata.X.T * 100 / arr_quantile.reshape(-1, 1)).T
            if max_value_q is not None:
                adata.X = np.where(adata.X > max_value_q * 100, max_value_q * 100, adata.X)
            if issparse(adata.X):
                adata.X = adata.X.tocsr()

        if calculate_pca:
            # calculate the max amount of pc's possible
            n_comps = pca_kwargs.pop("n_comps", None)
            if n_comps is not None:
                if min(adata.shape) < n_comps:
                    n_comps = min(adata.shape) - 1
                    log.warning(
                        f"amount of pc's was set to {min(adata.shape) - 1} because of the dimensionality of 'sdata.tables[table_layer]'."
                    )
            if not scale and (q is None):
                log.warning(
                    "Please consider scaling the data by passing 'scale=True' or setting 'q', when passing 'calculate_pca=True'."
                )
            self._type_check_before_pca(adata)
            sc.pp.pca(adata, copy=False, n_comps=n_comps, **pca_kwargs)

        self.sdata = add_table_layer(
            self.sdata,
            adata=adata,
            output_layer=output_layer,
            region=self.labels_layer,
            instance_key=self.instance_key,
            region_key=self.region_key,
            overwrite=overwrite,
        )

        if update_shapes_layers:
            for _labels_layer in self.labels_layer:
                self.sdata = filter_shapes_layer(
                    self.sdata,
                    table_layer=output_layer,
                    labels_layer=_labels_layer,
                    prefix_filtered_shapes_layer="filtered_low_counts",
                )

        return self.sdata
