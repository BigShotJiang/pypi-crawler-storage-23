# TODO Template

## In Progress

- [ ] (Active task description)

## Next

- [ ] Fill `docs/PROJECT.md` with real stack and command details.
- [ ] Fill `docs/CONVENTIONS.md` with concrete team standards.

## Blocked

- [ ] (Reason for blockage)

## Done

- [x] Scaffolded agent router and docs templates.
