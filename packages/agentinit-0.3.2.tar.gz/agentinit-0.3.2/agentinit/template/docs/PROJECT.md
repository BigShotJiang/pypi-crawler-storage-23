# Project Context

**Purpose:** Describe what this project is for and expected outcomes.

## Stack

- **Runtime:** (not configured)
- **Language(s):** (not configured)
- **Framework(s):** (not configured)
- **Storage/Infra:** (not configured)

## Commands

<!-- agentinit:commands:start -->
- Setup: (not configured)
- Build: (not configured)
- Test: (not configured)
- Lint/Format: (not configured)
- Run: (not configured)
<!-- agentinit:commands:end -->

## Layout

- `AGENTS.md`: Primary router.
- `docs/`: Source-of-truth context and memory files.
- `src/`: (describe your source layout)
- `tests/`: (describe your test layout)

## Constraints

- **Security:** (document security constraints)
- **Performance:** (document performance constraints)
- **Deadlines/Limits:** (document deadline constraints)
