# Conventions

## Style

- **Formatting standard:** (not configured)
- **Documentation tone/language:** English
- **Commenting expectations:** (not configured)

## Naming

- **Files/directories:** (not configured)
- **Variables/functions/types:** (not configured)
- **Branch naming:** (not configured)

## Testing

- **Required test types:** (not configured)
- **Minimum coverage/gates:** (not configured)
- **Test data/fixtures:** (not configured)

## Git Workflow

- **Commit message format:** (not configured)
- **PR requirements/reviews:** (not configured)
- **Merge strategy:** (not configured)
