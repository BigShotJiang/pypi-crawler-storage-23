# Project State

<!-- Persistent snapshot — any agent updates this at session end. -->

## Current Focus

- (What is being worked on right now)

## Next

1. (Priority item)
2. (Priority item)
3. (Priority item)

## Blockers

- None

## Recent Decisions

- (Link to `DECISIONS.md` entry or one-line summary)

## Lessons Learned

- (Add any gotchas, workarounds, or implicit knowledge discovered during the last session)

## Last Updated

<!-- Agents: Update this using `date +"%Y-%m-%d %H:%M:%S"` -->
YYYY-MM-DD
