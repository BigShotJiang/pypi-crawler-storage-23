"""Allow running as `python -m agentinit._contextlint`."""

from agentinit._contextlint.cli import main

raise SystemExit(main())
