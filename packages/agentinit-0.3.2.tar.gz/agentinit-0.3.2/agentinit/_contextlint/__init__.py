"""contextlint — a tiny linter for AI agent context files (vendored copy)."""

__version__ = "0.1.0"
