from d_pygen.ai_engine import generate_project_plan

plan = generate_project_plan("FastAPI backend with JWT auth")

print(plan)
