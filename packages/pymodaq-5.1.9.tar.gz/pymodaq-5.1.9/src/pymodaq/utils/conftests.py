import pytest

qtbotskip = True

main_modules_skip = True
