"""endnote-mcp: MCP server for searching and citing an EndNote reference library."""
