#!/usr/bin/env python3

import tsrkit_rs
import random


def erasure_coding_example():
    n = 32

    segment = bytes([random.randint(0, 255) for _ in range(n)])

    print("Segment", segment.hex())

    encoded_chunks = tsrkit_rs.encode_py(segment, 2, 4)

    print("Encoded chunks")
    for i in encoded_chunks:
        print(i.hex())

    c = [(bytes(encoded_chunks[i]), i) for i in range(len(encoded_chunks))]

    del(c[0])
    del(c[1])

    decoded_data = tsrkit_rs.decode_py(c, 2, 4)

    print("Original segment", decoded_data.hex())

    assert segment.hex() == decoded_data.hex()

def multi_segment_encoding():
    n = 32
    t = 200

    segments = [bytes([random.randint(0, 255) for _ in range(n)]) for _ in range(t)]
    encoded_segments = tsrkit_rs.multi_encode_py(segments, 2, 4)

if __name__ == "__main__":
    erasure_coding_example()
    multi_segment_encoding()

