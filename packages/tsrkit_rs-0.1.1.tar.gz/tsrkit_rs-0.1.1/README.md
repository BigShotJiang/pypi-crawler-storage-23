tsrkit-rs
====

Python Bindings for Erasure coding using [reed-solomon-simd](https://crates.io/crates/reed-solomon-simd), matching the JAM graypaper for python.

Credits
----
[Leopard-RS](https://github.com/catid/leopard)
[reed-solomon-simd](https://crates.io/crates/reed-solomon-simd)
