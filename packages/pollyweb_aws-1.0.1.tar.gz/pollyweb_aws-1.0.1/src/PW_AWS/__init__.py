"""Public package exports and compatibility path setup."""

from __future__ import annotations

from pathlib import Path
import sys


_current_dir = Path(__file__).resolve().parent
if str(_current_dir) not in sys.path:
    sys.path.append(str(_current_dir))

# Allow top-level imports of PW_UTILS modules (e.g., `from PW_UTILS.LOG import LOG`).
try:
    import PW_UTILS  # type: ignore

    _pw_utils_dir = Path(PW_UTILS.__file__).resolve().parent
    if str(_pw_utils_dir) not in sys.path:
        sys.path.append(str(_pw_utils_dir))
except Exception:
    pass

from .AWS import AWS
from .AWS_RETRY import RetryWithBackoff

__all__ = [
    "AWS",
    "RetryWithBackoff",
]
