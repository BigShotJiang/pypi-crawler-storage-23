"""Version information for pulse-bybit."""

__version__ = "0.1.1"
__version_info__ = (0, 1, 1)
