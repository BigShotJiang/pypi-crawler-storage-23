# rcgram/__init__.py
from .core import TelegramPrinter, bot_instance

__all__ = ['TelegramPrinter', 'bot_instance']