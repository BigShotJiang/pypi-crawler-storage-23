"""Graph-to-instruction preview: generate skeleton instruction.json and data_row.json."""

from typing import Any

from .models import (
    CheckboxValueRange,
    ClickSelectValueRange,
    ComboboxValueRange,
    DateValueRange,
    DropdownValueRange,
    FieldNode,
    FormGraph,
    NumericValueRange,
    RadioValueRange,
    SliderValueRange,
    TextValueRange,
)


def preview_instruction_skeleton(graph: FormGraph) -> dict[str, Any]:
    """
    Generate a skeleton instruction.json structure from the graph.

    This is a read-only preview showing how the graph maps to the
    existing Instructions/StepDefinition/FieldDefinition structure.
    """
    steps: list[dict[str, Any]] = []

    for page in graph.pages:
        fields: list[dict[str, Any]] = []
        for field in page.fields:
            field_dict: dict[str, Any] = {
                "type": field.field_type.value,
                "selector": field.selector,
                "data_key": field.data_key,
            }
            if field.iframe_selector is not None:
                field_dict["iframe_selector"] = field.iframe_selector

            fields.append(field_dict)

        next_action: dict[str, Any]
        if page.next_action_selector is not None:
            next_action = {
                "type": "click",
                "selector": page.next_action_selector,
            }
        else:
            next_action = {
                "type": "delay",
                "delay_ms": 1000,
            }

        step: dict[str, Any] = {
            "name": page.page_id,
            "wait_for": page.wait_for_selector,
            "timeout_ms": 30000,
            "fields": fields,
            "next_action": next_action,
        }
        steps.append(step)

    skeleton: dict[str, Any] = {
        "url": graph.url,
        "browser_config": {
            "browser_type": "chromium",
            "viewport_width": 1920,
            "viewport_height": 1080,
        },
        "steps": steps,
        "final_page": {
            "wait_for": "TODO",
            "timeout_ms": 30000,
            "post_wait_delay_ms": 0,
        },
    }

    return skeleton


def preview_data_row_template(graph: FormGraph) -> dict[str, Any]:
    """Generate a template data_row.json with placeholder values based on value ranges."""
    template: dict[str, Any] = {}

    for page in graph.pages:
        for field in page.fields:
            template[field.data_key] = _generate_placeholder_value(field=field)

    return template


def _generate_placeholder_value(field: FieldNode) -> Any:
    """Generate a placeholder value for a field based on its value_range."""
    if field.value_range is None:
        return "TODO"

    value_range = field.value_range

    if isinstance(value_range, TextValueRange):
        if value_range.example_values:
            return value_range.example_values[0]
        return "TODO_TEXT"

    if isinstance(value_range, NumericValueRange):
        return str(int(value_range.min_value))

    if isinstance(value_range, DropdownValueRange):
        if value_range.options:
            return value_range.options[0].value
        return "TODO_DROPDOWN"

    if isinstance(value_range, RadioValueRange):
        if value_range.options:
            return value_range.options[0].value
        return "TODO_RADIO"

    if isinstance(value_range, CheckboxValueRange):
        return True

    if isinstance(value_range, DateValueRange):
        return value_range.min_date

    if isinstance(value_range, SliderValueRange):
        return str(int(value_range.min_value))

    if isinstance(value_range, ComboboxValueRange):
        if value_range.options:
            return value_range.options[0].value
        return "TODO_COMBOBOX"

    if isinstance(value_range, ClickSelectValueRange):
        if value_range.options:
            return value_range.options[0].value
        return "TODO_CLICK_SELECT"

    return "TODO"
