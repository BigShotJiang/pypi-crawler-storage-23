"""
Centralized configuration constants and resilience utilities for the crawler framework.

Provides timeout constants, delay values, WaitConfig/WaitExecutor for timing,
retry_async for exponential backoff retry, and click_with_fallback for
escalating click strategies (normal -> force -> JS dispatch -> JS direct).
"""

import asyncio
import logging
import random
from collections.abc import Awaitable, Callable
from typing import Literal, TypeVar

from playwright.async_api import Locator, Page
from pydantic import BaseModel, ConfigDict

from .models import RetryConfig

# stdlib logger to avoid circular import with utils.py
logger = logging.getLogger(__name__)


class WaitConfig(BaseModel):
    """
    Configuration for a single wait operation.

    All wait times use milliseconds as the canonical unit.
    Randomization applies a multiplier between 1x and 2x to simulate human behavior.
    """

    model_config = ConfigDict(frozen=True)

    min_ms: int
    randomize: bool = True

    @classmethod
    def create(
        cls,
        value: int | None = None,
        *,
        default: int,
        randomize: bool = True,
    ) -> "WaitConfig":
        """
        Create WaitConfig from optional value with fallback to default.

        Args:
            value: Optional configured timeout from field/action definition
            default: Default minimum timeout constant to use if value is None
            randomize: Whether to apply randomization (default True)

        """
        return cls(
            min_ms=value if value is not None else default,
            randomize=randomize,
        )

    def resolve_ms(self) -> int:
        if self.randomize:
            sampled = random.randint(self.min_ms, self.min_ms * 2)
            logger.debug(f"Wait resolved: {sampled}ms (range: {self.min_ms}-{self.min_ms * 2}ms)")
            return sampled
        logger.debug(f"Wait resolved: {self.min_ms}ms (no randomization)")
        return self.min_ms

    def resolve_seconds(self) -> float:
        return self.resolve_ms() / 1000.0


class WaitExecutor:
    """
    Unified executor for all wait operations.

    Provides consistent interface for delays, element visibility waits,
    and element state waits. All methods accept WaitConfig for timing.
    """

    def __init__(self, page: Page) -> None:
        self._page = page

    async def delay(self, config: WaitConfig) -> None:
        await asyncio.sleep(config.resolve_seconds())

    async def page_timeout(self, config: WaitConfig) -> None:
        await self._page.wait_for_timeout(config.resolve_ms())

    async def wait_visible(self, locator: Locator, config: WaitConfig) -> None:
        await locator.wait_for(state="visible", timeout=config.resolve_ms())

    async def wait_attached(self, locator: Locator, config: WaitConfig) -> None:
        await locator.wait_for(state="attached", timeout=config.resolve_ms())

    async def wait_selector(
        self,
        selector: str,
        config: WaitConfig,
        state: Literal["attached", "detached", "visible", "hidden"] = "visible",
    ) -> None:
        await self._page.wait_for_selector(selector=selector, state=state, timeout=config.resolve_ms())


T = TypeVar("T")


async def retry_async(
    operation: Callable[[], Awaitable[T]],
    config: RetryConfig,
    retryable_exceptions: tuple[type[Exception], ...],
    context: str,
) -> T:
    """
    Execute an async operation with exponential backoff retry.

    Args:
        operation: Async callable to execute (no arguments, use closure for state)
        config: Retry configuration (max_attempts, base_delay_ms, backoff_multiplier)
        retryable_exceptions: Tuple of exception types that trigger a retry
        context: Human-readable context string for log messages

    Raises:
        The last exception if all attempts are exhausted.

    """
    last_exception: Exception | None = None
    for attempt in range(1, config.max_attempts + 1):
        try:
            return await operation()
        except retryable_exceptions as e:
            last_exception = e
            if attempt < config.max_attempts:
                delay_ms = int(config.base_delay_ms * (config.backoff_multiplier ** (attempt - 1)))
                logger.warning(f"Retry {attempt}/{config.max_attempts}: {context} -- {e} -- waiting {delay_ms}ms")
                await asyncio.sleep(delay_ms / 1000.0)
            else:
                logger.warning(f"All {config.max_attempts} attempts exhausted: {context} -- {e}")
    raise last_exception  # type: ignore[misc]


CLICK_FALLBACK_DEFAULT_TEXTS = ["klar", "akzept", "accept", "agree", "ok", "verstanden", "zustimm"]


async def click_with_fallback(
    page: Page,
    locator: Locator,
    selector: str,
    context: str,
    force_first: bool = False,
) -> None:
    """
    Click an element with escalating fallback strategies.

    Tries up to 4 strategies in order:
    1. Normal click (or force click if force_first=True)
    2. Force click (or normal click if force_first=True)
    3. JavaScript dispatchEvent click
    4. JavaScript element.click()

    Args:
        page: Playwright Page instance
        locator: Playwright Locator for the target element
        selector: CSS selector string (used for JS fallback)
        context: Human-readable context for log messages
        force_first: If True, try force click before normal click

    Raises:
        The last exception if all strategies fail.

    """
    from playwright.async_api import Error as PlaywrightError
    from playwright.async_api import TimeoutError as PlaywrightTimeoutError

    strategies: list[tuple[str, Callable[[], Awaitable[None]]]] = []

    if force_first:
        strategies.append(("force_click", lambda: locator.click(force=True)))
        strategies.append(("normal_click", lambda: locator.click()))
    else:
        strategies.append(("normal_click", lambda: locator.click()))
        strategies.append(("force_click", lambda: locator.click(force=True)))

    async def _js_dispatch_click() -> None:
        handle = await locator.element_handle()
        if handle is None:
            msg = "Element handle is None"
            raise PlaywrightError(msg)
        await handle.evaluate("el => el.dispatchEvent(new MouseEvent('click', {bubbles: true, cancelable: true}))")

    async def _js_direct_click() -> None:
        escaped_selector = selector.replace("'", "\\'")
        result = await page.evaluate(f"document.querySelector('{escaped_selector}')?.click() ?? 'not_found'")
        if result == "not_found":
            msg = f"JS click: element not found for selector '{selector}'"
            raise PlaywrightError(msg)

    strategies.append(("js_dispatch_click", _js_dispatch_click))
    strategies.append(("js_direct_click", _js_direct_click))

    last_error: Exception | None = None
    for strategy_name, strategy_fn in strategies:
        try:
            await strategy_fn()
            logger.info(f"Click succeeded via {strategy_name}: {context}")
            return
        except (PlaywrightTimeoutError, PlaywrightError) as e:
            last_error = e
            logger.warning(f"Click failed via {strategy_name}: {context} -- {e}")

    raise last_error  # type: ignore[misc]


def random_wait_ms(min_ms: int) -> int:
    """Generate a random wait time in milliseconds between min_ms and min_ms * 2."""
    return WaitConfig(min_ms=min_ms, randomize=True).resolve_ms()


DEFAULT_VIEWPORT_WIDTH = 1920
DEFAULT_VIEWPORT_HEIGHT = 1080

# Cookie Consent Timeouts (milliseconds) - minimum values, actual wait is random [min, min*2]
COOKIE_BANNER_SETTLE_DELAY_MIN_MS = 1000
COOKIE_BANNER_VISIBLE_TIMEOUT_MIN_MS = 1500
COOKIE_ACCEPT_BUTTON_TIMEOUT_MIN_MS = 2500
COOKIE_POST_CONSENT_DELAY_MIN_MS = 500

# Action Timeouts (milliseconds) - minimum values, actual wait is random [min, min*2]
ACTION_PRE_DELAY_MIN_MS = 1000
ACTION_POST_DELAY_MIN_MS = 2500
ACTION_ELEMENT_ATTACHED_TIMEOUT_MIN_MS = 15000
ACTION_WAIT_TIMEOUT_MIN_MS = 15000

# Field Handler Timeouts (milliseconds) - minimum values, actual wait is random [min, min*2]
FIELD_VISIBLE_TIMEOUT_MIN_MS = 5000
FIELD_POST_CLICK_DELAY_MIN_MS = 500
FIELD_TYPE_DELAY_MIN_MS = 25
FIELD_WAIT_AFTER_TYPE_MIN_MS = 500
FIELD_OPTION_VISIBLE_TIMEOUT_MIN_MS = 5000
FIELD_WAIT_AFTER_CLICK_MIN_MS = 250

# Combobox Delays (milliseconds) - minimum values, actual wait is random [min, min*2]
COMBOBOX_PRE_TYPE_DELAY_MIN_MS = 150
COMBOBOX_POST_CLEAR_DELAY_MIN_MS = 100
COMBOBOX_POST_ENTER_DELAY_MIN_MS = 150

# Discovery Timeouts (milliseconds) - minimum values
DISCOVERY_PAGE_LOAD_TIMEOUT_MIN_MS = 15000

# CAPTCHA Timeouts (milliseconds) - minimum values for hardcoded operations
CAPTCHA_CONTAINER_VISIBLE_TIMEOUT_MIN_MS = 5000
CAPTCHA_POST_SCROLL_DELAY_MIN_MS = 500
CAPTCHA_MOUSE_MOVE_DELAY_MIN_MS = 100
CAPTCHA_MOUSE_SETTLE_DELAY_MIN_MS = 200
CAPTCHA_POST_SUBMIT_DELAY_MIN_MS = 1000
CAPTCHA_POST_MODAL_DISMISS_DELAY_MIN_MS = 2000
CAPTCHA_RETRY_DELAY_MIN_MS = 2000
CAPTCHA_POLL_INTERVAL_MS = 500

# CSS Selector Special Characters that need escaping
CSS_SELECTOR_ESCAPE_CHARS = ":[]().#>+~="

# Characters that need escaping in CSS attribute values
CSS_ATTRIBUTE_VALUE_ESCAPE_CHARS = "\"'\\[]"
