"""
Browser profile builder that visits random sites to accumulate cookies and storage.

Supports two modes:
- Disk mode (storage_path set): persists profile to disk (directory for Camoufox, JSON for Chromium)
- In-memory mode (storage_path=None): Chromium returns storage state as dict, Camoufox uses temp dir
"""

import logging
import random
import shutil
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from browserforge.fingerprints import Screen
from camoufox.async_api import AsyncCamoufox
from playwright.async_api import Page, async_playwright

from .browser_utils import handle_cookie_consent
from .config import WaitConfig, WaitExecutor
from .models import (
    BrowserConfig,
    BrowserType,
    CrawlerBrowserConfig,
    ProfilerConfig,
    ProfilerSiteConfig,
)


@dataclass(frozen=True)
class ProfilerResult:
    visited_urls: list[str] = field(default_factory=list)
    storage_state_path: Path | None = None
    storage_state: dict[str, Any] | None = None


def resolve_storage_path(base_path: str, browser_type: BrowserType) -> Path:
    """Resolve the storage path based on browser type."""
    if browser_type == BrowserType.CAMOUFOX:
        return Path(f"{base_path}.camoufox")
    return Path(f"{base_path}.chromium.json")


async def run_profiler(
    config: ProfilerConfig,
    browser_type: BrowserType,
    browser_config: BrowserConfig,
    crawler_browser_config: CrawlerBrowserConfig | None,
    headless: bool | str,
    logger: logging.Logger,
) -> ProfilerResult:
    """Build a browser profile by visiting random sites and accepting cookies."""
    selected_sites = random.sample(config.sites, k=config.visit_count)
    selected_urls = [site.url for site in selected_sites]
    in_memory = config.storage_path is None

    logger.info(
        f"Profiler starting: visit_count={config.visit_count} "
        f"total_sites={len(config.sites)} in_memory={in_memory} selected_urls={selected_urls}"
    )

    if in_memory:
        return await _run_profiler_in_memory(
            selected_sites=selected_sites,
            selected_urls=selected_urls,
            config=config,
            browser_type=browser_type,
            browser_config=browser_config,
            crawler_browser_config=crawler_browser_config,
            headless=headless,
            logger=logger,
        )

    storage_path = resolve_storage_path(
        base_path=config.storage_path,  # type: ignore[arg-type]  # validated not None above
        browser_type=browser_type,
    )

    if browser_type == BrowserType.CAMOUFOX:
        await _run_profiler_camoufox(
            selected_sites=selected_sites,
            config=config,
            browser_config=browser_config,
            crawler_browser_config=crawler_browser_config,
            headless=headless,
            storage_path=storage_path,
            logger=logger,
        )
    else:
        await _run_profiler_chromium(
            selected_sites=selected_sites,
            config=config,
            browser_config=browser_config,
            crawler_browser_config=crawler_browser_config,
            headless=headless,
            storage_path=storage_path,
            logger=logger,
        )

    logger.info(f"Profiler completed: storage_path='{storage_path}' visited={len(selected_urls)} urls")
    return ProfilerResult(storage_state_path=storage_path, visited_urls=selected_urls)


async def _run_profiler_in_memory(
    selected_sites: list[ProfilerSiteConfig],
    selected_urls: list[str],
    config: ProfilerConfig,
    browser_type: BrowserType,
    browser_config: BrowserConfig,
    crawler_browser_config: CrawlerBrowserConfig | None,
    headless: bool | str,
    logger: logging.Logger,
) -> ProfilerResult:
    """Run profiler in-memory mode. Chromium returns dict, Camoufox uses temp dir."""
    if browser_type == BrowserType.CAMOUFOX:
        temp_dir = Path(tempfile.mkdtemp(prefix="azcrawlerpy_profiler_"))
        try:
            await _run_profiler_camoufox(
                selected_sites=selected_sites,
                config=config,
                browser_config=browser_config,
                crawler_browser_config=crawler_browser_config,
                headless=headless,
                storage_path=temp_dir,
                logger=logger,
            )
            logger.info(
                f"Profiler completed in-memory (camoufox temp dir): path='{temp_dir}' visited={len(selected_urls)} urls"
            )
            # Camoufox persists to user_data_dir; return temp path for the crawl session
            return ProfilerResult(
                storage_state_path=temp_dir,
                visited_urls=selected_urls,
            )
        except Exception:
            shutil.rmtree(temp_dir, ignore_errors=True)
            raise
    else:
        storage_state = await _run_profiler_chromium_in_memory(
            selected_sites=selected_sites,
            config=config,
            browser_config=browser_config,
            crawler_browser_config=crawler_browser_config,
            headless=headless,
            logger=logger,
        )
        logger.info(f"Profiler completed in-memory (chromium): visited={len(selected_urls)} urls")
        return ProfilerResult(
            storage_state=storage_state,
            visited_urls=selected_urls,
        )


async def _run_profiler_camoufox(
    selected_sites: list[ProfilerSiteConfig],
    config: ProfilerConfig,
    browser_config: BrowserConfig,
    crawler_browser_config: CrawlerBrowserConfig | None,
    headless: bool | str,
    storage_path: Path,
    logger: logging.Logger,
) -> None:
    """Run profiler using Camoufox with persistent context."""
    storage_path.mkdir(parents=True, exist_ok=True)

    screen_constraints = Screen(
        max_width=browser_config.viewport_width,
        max_height=browser_config.viewport_height,
    )

    camoufox_kwargs: dict[str, Any] = {
        "headless": headless,
        "screen": screen_constraints,
        "persistent_context": True,
        "user_data_dir": str(storage_path),
    }

    if crawler_browser_config is not None:
        if crawler_browser_config.proxy is not None:
            proxy_dict: dict[str, str] = {"server": crawler_browser_config.proxy.server}
            if crawler_browser_config.proxy.username is not None:
                proxy_dict["username"] = crawler_browser_config.proxy.username
            if crawler_browser_config.proxy.password is not None:
                proxy_dict["password"] = crawler_browser_config.proxy.password
            camoufox_kwargs["proxy"] = proxy_dict

        if crawler_browser_config.humanize is not None and crawler_browser_config.humanize.enabled:
            if crawler_browser_config.humanize.max_time_seconds is not None:
                camoufox_kwargs["humanize"] = crawler_browser_config.humanize.max_time_seconds
            else:
                camoufox_kwargs["humanize"] = True

        if crawler_browser_config.geoip is not None:
            camoufox_kwargs["geoip"] = crawler_browser_config.geoip

        if crawler_browser_config.os is not None:
            camoufox_kwargs["os"] = crawler_browser_config.os

    # persistent_context=True makes AsyncCamoufox return a context, not a browser
    async with AsyncCamoufox(**camoufox_kwargs) as context:
        page = await context.new_page()

        await _visit_sites(
            page=page,
            selected_sites=selected_sites,
            config=config,
            logger=logger,
        )

        await page.close()
    # Camoufox persistent context auto-saves to user_data_dir on close


async def _run_profiler_chromium(
    selected_sites: list[ProfilerSiteConfig],
    config: ProfilerConfig,
    browser_config: BrowserConfig,
    crawler_browser_config: CrawlerBrowserConfig | None,
    headless: bool | str,
    storage_path: Path,
    logger: logging.Logger,
) -> None:
    """Run profiler using Chromium and save storage state to JSON."""
    launch_kwargs, context_kwargs = _build_chromium_kwargs(
        browser_config=browser_config,
        crawler_browser_config=crawler_browser_config,
    )
    chromium_headless = True if headless == "virtual" else headless

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=chromium_headless, **launch_kwargs)
        context = await browser.new_context(**context_kwargs)
        page = await context.new_page()

        await _visit_sites(
            page=page,
            selected_sites=selected_sites,
            config=config,
            logger=logger,
        )

        storage_path.parent.mkdir(parents=True, exist_ok=True)
        await context.storage_state(path=str(storage_path))
        logger.info(f"Chromium storage state saved: path='{storage_path}'")

        await page.close()
        await context.close()
        await browser.close()


async def _run_profiler_chromium_in_memory(
    selected_sites: list[ProfilerSiteConfig],
    config: ProfilerConfig,
    browser_config: BrowserConfig,
    crawler_browser_config: CrawlerBrowserConfig | None,
    headless: bool | str,
    logger: logging.Logger,
) -> dict[str, Any]:
    """Run profiler using Chromium and return storage state as dict (no file written)."""
    launch_kwargs, context_kwargs = _build_chromium_kwargs(
        browser_config=browser_config,
        crawler_browser_config=crawler_browser_config,
    )
    chromium_headless = True if headless == "virtual" else headless

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=chromium_headless, **launch_kwargs)
        context = await browser.new_context(**context_kwargs)
        page = await context.new_page()

        await _visit_sites(
            page=page,
            selected_sites=selected_sites,
            config=config,
            logger=logger,
        )

        storage_state: dict[str, Any] = dict(await context.storage_state())
        logger.info("Chromium storage state captured in-memory")

        await page.close()
        await context.close()
        await browser.close()

    return storage_state


def _build_chromium_kwargs(
    browser_config: BrowserConfig,
    crawler_browser_config: CrawlerBrowserConfig | None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Build launch and context kwargs for Chromium profiler."""
    launch_kwargs: dict[str, Any] = {}
    context_kwargs: dict[str, Any] = {
        "viewport": {
            "width": browser_config.viewport_width,
            "height": browser_config.viewport_height,
        },
    }

    if crawler_browser_config is not None:
        if crawler_browser_config.proxy is not None:
            proxy_dict: dict[str, str] = {"server": crawler_browser_config.proxy.server}
            if crawler_browser_config.proxy.username is not None:
                proxy_dict["username"] = crawler_browser_config.proxy.username
            if crawler_browser_config.proxy.password is not None:
                proxy_dict["password"] = crawler_browser_config.proxy.password
            launch_kwargs["proxy"] = proxy_dict

        if crawler_browser_config.ignore_https_errors is not None:
            context_kwargs["ignore_https_errors"] = crawler_browser_config.ignore_https_errors

        if crawler_browser_config.context_options is not None:
            opts = crawler_browser_config.context_options
            if opts.user_agent is not None:
                context_kwargs["user_agent"] = opts.user_agent
            if opts.locale is not None:
                context_kwargs["locale"] = opts.locale
            if opts.timezone_id is not None:
                context_kwargs["timezone_id"] = opts.timezone_id

    return launch_kwargs, context_kwargs


async def _visit_sites(
    page: Page,
    selected_sites: list[ProfilerSiteConfig],
    config: ProfilerConfig,
    logger: logging.Logger,
) -> None:
    """Visit each selected site, handle cookies, and linger."""
    waiter = WaitExecutor(page=page)

    for i, site in enumerate(selected_sites):
        try:
            logger.info(f"Profiler visiting site {i + 1}/{len(selected_sites)}: url='{site.url}'")
            await page.goto(url=site.url, wait_until="domcontentloaded")

            if site.cookie_consent is not None:
                await handle_cookie_consent(
                    page=page,
                    config=site.cookie_consent,
                    strict=False,
                )

            if site.browse_delay_ms is not None:
                browse_delay = WaitConfig(min_ms=site.browse_delay_ms, randomize=True)
                await waiter.delay(config=browse_delay)

            logger.info(f"Profiler finished site {i + 1}/{len(selected_sites)}: url='{site.url}'")

        except Exception:
            if not config.ignore_errors:
                raise
            logger.warning(
                f"Profiler site failed (ignored): url='{site.url}'",
                exc_info=True,
            )

        if config.inter_site_delay_ms is not None and i < len(selected_sites) - 1:
            inter_delay = WaitConfig(min_ms=config.inter_site_delay_ms, randomize=True)
            await waiter.delay(config=inter_delay)
