"""CLI entry point for sidecar hooks.

Usage from Claude Code hooks:
    python -m cmdop_claude.sidecar.hook scan
    python -m cmdop_claude.sidecar.hook status
    python -m cmdop_claude.sidecar.hook acknowledge <item_id> [days]
    python -m cmdop_claude.sidecar.hook map-update
    python -m cmdop_claude.sidecar.hook inject-tasks
    python -m cmdop_claude.sidecar.hook fix <task_id> [--apply]
    python -m cmdop_claude.sidecar.hook init
    python -m cmdop_claude.sidecar.hook register
    python -m cmdop_claude.sidecar.hook unregister
"""
import json
import sys
import time
from pathlib import Path

from .._config import Config, get_config
from ..services.sidecar_service import SidecarService

# Debounce interval for map-update (seconds)
_MAP_UPDATE_DEBOUNCE = 60


def main() -> None:
    if len(sys.argv) < 2:
        print(
            "Usage: python -m cmdop_claude.sidecar.hook "
            "<scan|status|acknowledge|map-update|inject-tasks|fix|init|register|unregister>"
        )
        sys.exit(1)

    command = sys.argv[1]
    config = get_config()
    sidecar = SidecarService(config)

    if command == "scan":
        try:
            result = sidecar.generate_review()
            print(f"Review generated: {len(result.items)} items found")
            print(f"Tokens used: {result.tokens_used} ({result.model_used})")
        except RuntimeError as e:
            print(f"Skipped: {e}")

    elif command == "status":
        status = sidecar.get_status()
        print(json.dumps(status.model_dump(), indent=2, default=str))

    elif command == "acknowledge":
        if len(sys.argv) < 3:
            print("Usage: acknowledge <item_id> [days]")
            sys.exit(1)
        item_id = sys.argv[2]
        days = int(sys.argv[3]) if len(sys.argv) > 3 else 30
        sidecar.acknowledge(item_id, days)
        print(f"Suppressed {item_id} for {days} days")

    elif command == "map-update":
        _handle_map_update(sidecar, config)

    elif command == "inject-tasks":
        _handle_inject_tasks(sidecar)

    elif command == "fix":
        _handle_fix(sidecar)

    elif command == "init":
        _handle_init(sidecar)

    elif command == "register":
        if sidecar.register_mcp():
            print("Registered sidecar MCP server in ~/.claude.json")
        else:
            print("Already registered.")

    elif command == "unregister":
        if sidecar.unregister_mcp():
            print("Unregistered sidecar MCP server from ~/.claude.json")
        else:
            print("Not registered.")

    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


def _handle_map_update(sidecar: SidecarService, config: "Config") -> None:
    """Incremental map update with debounce — skip if last run < 60s ago."""
    map_path = Path(config.claude_dir_path) / "project-map.md"
    if map_path.exists():
        age = time.time() - map_path.stat().st_mtime
        if age < _MAP_UPDATE_DEBOUNCE:
            print(f"Skipped: map updated {age:.0f}s ago (debounce {_MAP_UPDATE_DEBOUNCE}s)")
            return

    try:
        result = sidecar.generate_map()
        print(
            f"Map updated: {len(result.directories)} dirs, "
            f"{len(result.entry_points)} entry points, "
            f"{result.tokens_used} tokens ({result.model_used})"
        )
    except Exception as e:
        print(f"Error: {e}")


def _handle_inject_tasks(sidecar: SidecarService) -> None:
    """Print top pending tasks to stdout for UserPromptSubmit hook injection."""
    summary = sidecar.get_pending_summary(max_items=3)
    if summary:
        print(summary)


def _handle_fix(sidecar: SidecarService) -> None:
    """Generate a fix for a task. Usage: fix <task_id> [--apply]"""
    if len(sys.argv) < 3:
        print("Usage: fix <task_id> [--apply]")
        sys.exit(1)
    task_id = sys.argv[2]
    apply = "--apply" in sys.argv[3:]
    try:
        result = sidecar.fix_task(task_id, apply=apply)
        if result.diff == "Task not found.":
            print(f"Task {task_id} not found.")
            sys.exit(1)
        print(result.diff)
        if result.applied:
            print(f"\nApplied to {result.file_path}. Task marked completed.")
        print(f"Tokens: {result.tokens_used}")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


def _handle_init(sidecar: SidecarService) -> None:
    """Initialize .claude/ for a bare project."""
    try:
        result = sidecar.init_project()
        if not result.files_created:
            print(f"Skipped: {result.model_used}")
            return
        print(f"Initialized {len(result.files_created)} files:")
        for f in result.files_created:
            print(f"  - {f}")
        print(f"Model: {result.model_used} | Tokens: {result.tokens_used}")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
