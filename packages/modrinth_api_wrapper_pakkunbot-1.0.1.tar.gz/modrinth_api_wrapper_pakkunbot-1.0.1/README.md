A fork of [modrinth-api-wrapper](https://pypi.org/project/modrinth-api-wrapper/) package, published to pypi as modrinth-api-wrapper-pakkunbot.

Contains the following fix:
- Fix support for Python 3.8