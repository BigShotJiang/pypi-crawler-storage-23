"""Alfred TUI widgets."""
