"""Alfred TUI screens."""
