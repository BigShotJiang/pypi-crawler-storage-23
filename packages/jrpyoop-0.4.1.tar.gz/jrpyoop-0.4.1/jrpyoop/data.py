from importlib import resources
import pandas as pd

PACKAGE = "jrpyoop"


def load(filename):                                                                                                                             
    # Ensure file has .zip extension
    if not filename.endswith(".zip"):
        zipped_filename = filename + ".zip"
    else:
        zipped_filename = filename

    available_data = list_pkg_data()
    assert zipped_filename in available_data, (
        f"Could not find '{filename}' dataset. "
        + f"Available datasets are: {[data.strip('.zip') for data in available_data]}."
    )

    # Absolute path to data                                                                                                                 
    abs_path = resources.files(PACKAGE) / "data" / zipped_filename
    return pd.read_csv(abs_path)


def list_pkg_data():
    """
    Return the names of all datasets present in the package.
    These datasets can be loaded using data.load("dataset.zip") or data.load("dataset").
    The dataset names returned here all include the .zip suffix of the filename.
    """
    # Get path to files relative to package
    # and extract the "dataset_name.zip" from "path/to/datadir/dataset_name.zip"
    data_path = resources.files(PACKAGE) / "data"
    datasets = [
        file.name
        for file in data_path.iterdir()
        if str(file).endswith("zip")
    ]
    return datasets
