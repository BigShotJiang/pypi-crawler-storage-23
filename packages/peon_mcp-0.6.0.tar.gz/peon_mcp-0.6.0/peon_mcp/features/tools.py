"""MCP tool registrations for features."""

from mcp.server.fastmcp import Context


def register_tools(mcp, api_fn):
    @mcp.tool()
    async def create_feature(
        project_id: str,
        name: str,
        description: str = "",
        status: str = "planned",
        branch: str = "",
        ctx: Context = None,
    ) -> dict | str:
        """Create a high-level feature for a project.

        The project must already exist. If it does not, call create_project first.

        Args:
            project_id: The project this feature belongs to (repo name).
            name: Short name for the feature (e.g. 'User authentication').
            description: Longer description of the feature's scope and goals.
            status: One of 'planned', 'in_progress', 'done', or 'cancelled'.
            branch: Git branch name for this feature. If empty, auto-generated from name.
        """
        return await api_fn(ctx).create_feature(project_id, name, description, status, branch)

    @mcp.tool()
    async def list_features(
        project_id: str,
        status: str | None = None,
        ctx: Context = None,
    ) -> list[dict] | str:
        """List features for a project, optionally filtered by status.

        Args:
            project_id: The project to list features for (repo name).
            status: Filter by status ('planned', 'in_progress', 'done', 'cancelled'). Omit to show all.
        """
        return await api_fn(ctx).list_features(project_id, status)

    @mcp.tool()
    async def get_feature(feature_id: int, ctx: Context = None) -> dict | str:
        """Get a single feature by its ID.

        Args:
            feature_id: The numeric ID of the feature.
        """
        return await api_fn(ctx).get_feature(feature_id)

    @mcp.tool()
    async def update_feature(
        feature_id: int,
        name: str | None = None,
        description: str | None = None,
        status: str | None = None,
        branch: str | None = None,
        pr_url: str | None = None,
        ctx: Context = None,
    ) -> dict | str:
        """Update fields on an existing feature.

        Args:
            feature_id: The numeric ID of the feature to update.
            name: New name (optional).
            description: New description (optional).
            status: New status — 'planned', 'in_progress', 'done', or 'cancelled' (optional).
            branch: Git branch name for this feature (optional).
            pr_url: URL of the PR merging this feature to main (optional).
        """
        return await api_fn(ctx).update_feature(feature_id, name, description, status, branch, pr_url)

    @mcp.tool()
    async def delete_feature(feature_id: int, ctx: Context = None) -> str:
        """Delete a feature by its ID.

        Args:
            feature_id: The numeric ID of the feature to delete.
        """
        return await api_fn(ctx).delete_feature(feature_id)

    @mcp.tool()
    async def complete_feature(feature_id: int, pr_url: str = "", ctx: Context = None) -> dict | str:
        """Mark a feature as done after all its tasks are complete.

        Validates that all tasks within the feature are done or cancelled before
        marking the feature as complete. If pr_url is not provided, automatically
        creates a PR via GitHub CLI and stores the URL.

        Args:
            feature_id: The numeric ID of the feature to complete.
            pr_url: URL of the PR merging the feature branch to main (optional).
                    If not provided, will auto-create via gh CLI.
        """
        return await api_fn(ctx).complete_feature(feature_id, pr_url)

    @mcp.tool()
    async def resolve_feature_conflicts(feature_id: int, ctx: Context = None) -> dict | str:
        """Merge origin/main into the feature branch to resolve PR conflicts.

        Use this when a feature branch PR into main has merge conflicts.
        Creates a temporary worktree, merges origin/main into the feature branch,
        and pushes the result. If the merge has conflicts that cannot be resolved
        automatically, returns a list of conflicting files so you can fix them manually.

        Args:
            feature_id: The numeric ID of the feature whose branch has conflicts.
        """
        return await api_fn(ctx).resolve_feature_conflicts(feature_id)
