"""Pydantic models for feature endpoints."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

from peon_mcp.tasks.schemas import TaskResponse


class FeatureResponse(BaseModel):
    id: int
    project_id: str
    name: str
    description: str
    status: Literal["planned", "in_progress", "done", "cancelled"]
    branch: str
    pr_url: str | None = None
    task_counts: dict[str, int] | None = None
    created_at: str
    updated_at: str


class CreateFeatureRequest(BaseModel):
    name: str
    description: str = ""
    status: str = "planned"
    branch: str = ""


class UpdateFeatureRequest(BaseModel):
    name: str | None = None
    description: str | None = None
    status: str | None = None
    branch: str | None = None
    pr_url: str | None = None


class CompleteFeatureRequest(BaseModel):
    pr_url: str = ""


class FeatureTasksResponse(BaseModel):
    items: list[TaskResponse]
    total: int


class ResolveConflictsResponse(BaseModel):
    success: bool
    conflicts: list[str]
    message: str
    commit_sha: str | None = None
