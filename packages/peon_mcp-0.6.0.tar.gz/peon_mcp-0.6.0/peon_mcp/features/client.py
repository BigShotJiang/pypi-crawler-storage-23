"""API client methods for features."""

from __future__ import annotations

from typing import Any

from peon_mcp.common.base_client import BaseAPIClient


class FeatureClient(BaseAPIClient):
    """Feature API client methods."""

    async def create_feature(
        self,
        project_id: str,
        name: str,
        description: str = "",
        status: str = "planned",
        branch: str = "",
    ) -> dict | str:
        return await self._request(
            "POST", f"/api/projects/{project_id}/features",
            json={
                "name": name,
                "description": description,
                "status": status,
                "branch": branch,
            },
        )

    async def list_features(
        self, project_id: str, status: str | None = None
    ) -> list[dict] | str:
        params: dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        return await self._paginate_all(
            f"/api/projects/{project_id}/features", params=params
        )

    async def get_feature(self, feature_id: int) -> dict | str:
        return await self._request("GET", f"/api/features/{feature_id}")

    async def update_feature(
        self,
        feature_id: int,
        name: str | None = None,
        description: str | None = None,
        status: str | None = None,
        branch: str | None = None,
        pr_url: str | None = None,
    ) -> dict | str:
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if status is not None:
            body["status"] = status
        if branch is not None:
            body["branch"] = branch
        if pr_url is not None:
            body["pr_url"] = pr_url
        return await self._request("PUT", f"/api/features/{feature_id}", json=body)

    async def delete_feature(self, feature_id: int) -> str:
        result = await self._request("DELETE", f"/api/features/{feature_id}")
        if isinstance(result, dict) and result.get("ok"):
            return f"Feature {feature_id} deleted"
        if isinstance(result, str):
            return result
        return f"Feature {feature_id} deleted"

    async def complete_feature(
        self, feature_id: int, pr_url: str = ""
    ) -> dict | str:
        body: dict[str, Any] = {}
        if pr_url:
            body["pr_url"] = pr_url
        return await self._request(
            "POST", f"/api/features/{feature_id}/complete", json=body or None
        )

    async def resolve_feature_conflicts(self, feature_id: int) -> dict | str:
        return await self._request(
            "POST", f"/api/features/{feature_id}/resolve-conflicts"
        )
