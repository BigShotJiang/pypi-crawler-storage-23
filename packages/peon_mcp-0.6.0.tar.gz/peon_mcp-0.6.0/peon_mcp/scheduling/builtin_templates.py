"""Built-in schedule templates available for all projects.

These are pre-defined recurring task templates that users can enable
with one click from the Schedules UI or via the seed API endpoint.
"""

from __future__ import annotations

from typing import TypedDict


class BuiltinTemplate(TypedDict):
    key: str
    title: str
    description: str
    cron_expression: str
    priority: str
    timezone: str


BUILTIN_TEMPLATES: list[BuiltinTemplate] = [
    {
        "key": "nightly-tests",
        "title": "Nightly Test Suite",
        "description": "Run full test suite and report results",
        "cron_expression": "0 2 * * *",
        "priority": "high",
        "timezone": "UTC",
    },
    {
        "key": "weekly-dependency-audit",
        "title": "Weekly Dependency Audit",
        "description": "Check for outdated/vulnerable dependencies",
        "cron_expression": "0 9 * * 1",
        "priority": "medium",
        "timezone": "UTC",
    },
    {
        "key": "weekly-dead-code-detection",
        "title": "Weekly Dead Code Detection",
        "description": "Scan for unused imports, functions, and variables",
        "cron_expression": "0 10 * * 3",
        "priority": "low",
        "timezone": "UTC",
    },
    {
        "key": "monthly-docs-review",
        "title": "Monthly Documentation Review",
        "description": "Review and update project documentation",
        "cron_expression": "0 9 1 * *",
        "priority": "low",
        "timezone": "UTC",
    },
]

_BY_KEY: dict[str, BuiltinTemplate] = {t["key"]: t for t in BUILTIN_TEMPLATES}


def get_builtin_template(key: str) -> BuiltinTemplate | None:
    """Return a built-in template by key, or None if not found."""
    return _BY_KEY.get(key)
