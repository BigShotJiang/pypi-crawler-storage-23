"""MCP tool registrations for scheduling."""


def register_tools(mcp, api_fn):
    @mcp.tool()
    async def create_schedule(
        project_id: str,
        title: str,
        cron_expression: str,
        description: str = "",
        priority: str = "medium",
        feature_id: int | None = None,
        timezone: str = "UTC",
        enabled: bool = True,
        ctx=None,
    ) -> dict | str:
        """Create a new scheduled task template.

        The template will automatically create tasks according to the cron schedule.
        Use trigger_schedule to create a task immediately from the template.

        Args:
            project_id: The project this template belongs to (repo name).
            title: Title for tasks created from this template.
            cron_expression: Standard 5-field cron expression (e.g., '0 9 * * 1' for Mondays at 9am).
            description: Description for tasks created from this template.
            priority: Task priority — 'low', 'medium', 'high', or 'critical'.
            feature_id: Feature ID to assign created tasks to (optional).
            timezone: Timezone name for cron evaluation (default: 'UTC').
            enabled: Whether the schedule is active (default: True).
        """
        return await api_fn(ctx).create_schedule(
            project_id, title, cron_expression, description,
            priority, feature_id, timezone, enabled,
        )

    @mcp.tool()
    async def list_schedules(project_id: str, ctx=None) -> list[dict] | str:
        """List all task templates (scheduled tasks) for a project.

        Args:
            project_id: The project to list schedules for (repo name).
        """
        return await api_fn(ctx).list_schedules(project_id)

    @mcp.tool()
    async def get_schedule(template_id: int, ctx=None) -> dict | str:
        """Get a single task template by ID.

        Args:
            template_id: The numeric ID of the task template.
        """
        return await api_fn(ctx).get_schedule(template_id)

    @mcp.tool()
    async def update_schedule(
        template_id: int,
        title: str | None = None,
        description: str | None = None,
        priority: str | None = None,
        feature_id: int | None = None,
        cron_expression: str | None = None,
        timezone: str | None = None,
        enabled: bool | None = None,
        ctx=None,
    ) -> dict | str:
        """Update fields on an existing task template.

        Args:
            template_id: The numeric ID of the task template to update.
            title: New title (optional).
            description: New description (optional).
            priority: New priority — 'low', 'medium', 'high', or 'critical' (optional).
            feature_id: New feature ID (optional).
            cron_expression: New cron expression (optional).
            timezone: New timezone (optional).
            enabled: Enable or disable the schedule (optional).
        """
        return await api_fn(ctx).update_schedule(
            template_id, title, description, priority,
            feature_id, cron_expression, timezone, enabled,
        )

    @mcp.tool()
    async def delete_schedule(template_id: int, ctx=None) -> str:
        """Delete a task template by ID.

        Args:
            template_id: The numeric ID of the task template to delete.
        """
        return await api_fn(ctx).delete_schedule(template_id)

    @mcp.tool()
    async def trigger_schedule(template_id: int, ctx=None) -> dict | str:
        """Manually trigger a task template to create a task immediately.

        Creates a new task with the template's title, description, and priority,
        then records the trigger time on the template.

        Args:
            template_id: The numeric ID of the task template to trigger.
        """
        return await api_fn(ctx).trigger_schedule(template_id)

    @mcp.tool()
    async def list_upcoming_schedules(
        project_id: str,
        hours: int = 24,
        ctx=None,
    ) -> list[dict] | str:
        """Preview tasks that will be created by schedules in the next N hours.

        Args:
            project_id: The project to preview upcoming tasks for.
            hours: How many hours ahead to look (default: 24, max: 720).
        """
        return await api_fn(ctx).list_upcoming_schedules(project_id, hours)
