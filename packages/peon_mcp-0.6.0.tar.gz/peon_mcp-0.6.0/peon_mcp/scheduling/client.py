"""API client methods for scheduling."""

from __future__ import annotations

from typing import Any

from peon_mcp.common.base_client import BaseAPIClient


class SchedulingClient(BaseAPIClient):
    """Scheduling API client methods."""

    async def create_schedule(
        self,
        project_id: str,
        title: str,
        cron_expression: str,
        description: str = "",
        priority: str = "medium",
        feature_id: int | None = None,
        timezone: str = "UTC",
        enabled: bool = True,
    ) -> dict | str:
        body: dict[str, Any] = {
            "project_id": project_id,
            "title": title,
            "cron_expression": cron_expression,
            "description": description,
            "priority": priority,
            "timezone": timezone,
            "enabled": enabled,
        }
        if feature_id is not None:
            body["feature_id"] = feature_id
        return await self._request("POST", "/api/schedules", json=body)

    async def list_schedules(self, project_id: str) -> list[dict] | str:
        return await self._request(
            "GET", "/api/schedules", params={"project_id": project_id}
        )

    async def get_schedule(self, template_id: int) -> dict | str:
        return await self._request("GET", f"/api/schedules/{template_id}")

    async def update_schedule(
        self,
        template_id: int,
        title: str | None = None,
        description: str | None = None,
        priority: str | None = None,
        feature_id: int | None = None,
        cron_expression: str | None = None,
        timezone: str | None = None,
        enabled: bool | None = None,
    ) -> dict | str:
        body: dict[str, Any] = {}
        if title is not None:
            body["title"] = title
        if description is not None:
            body["description"] = description
        if priority is not None:
            body["priority"] = priority
        if feature_id is not None:
            body["feature_id"] = feature_id
        if cron_expression is not None:
            body["cron_expression"] = cron_expression
        if timezone is not None:
            body["timezone"] = timezone
        if enabled is not None:
            body["enabled"] = enabled
        return await self._request("PUT", f"/api/schedules/{template_id}", json=body)

    async def delete_schedule(self, template_id: int) -> str:
        result = await self._request("DELETE", f"/api/schedules/{template_id}")
        if isinstance(result, dict) and result.get("ok"):
            return f"Schedule {template_id} deleted"
        if isinstance(result, str):
            return result
        return f"Schedule {template_id} deleted"

    async def trigger_schedule(self, template_id: int) -> dict | str:
        return await self._request(
            "POST", f"/api/schedules/{template_id}/trigger"
        )

    async def list_upcoming_schedules(
        self, project_id: str, hours: int = 24
    ) -> list[dict] | str:
        return await self._request(
            "GET", "/api/schedules/upcoming",
            params={"project_id": project_id, "hours": hours},
        )
