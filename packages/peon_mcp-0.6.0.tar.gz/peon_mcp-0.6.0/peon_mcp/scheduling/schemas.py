"""Pydantic models for scheduling endpoints."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class TaskTemplateCreate(BaseModel):
    project_id: str
    title: str
    description: str = ""
    priority: Literal["low", "medium", "high", "critical"] = "medium"
    feature_id: int | None = None
    cron_expression: str
    timezone: str = "UTC"
    enabled: bool = True


class TaskTemplateUpdate(BaseModel):
    title: str | None = None
    description: str | None = None
    priority: str | None = None
    feature_id: int | None = None
    cron_expression: str | None = None
    timezone: str | None = None
    enabled: bool | None = None


class TaskTemplateResponse(BaseModel):
    id: int
    project_id: str
    feature_id: int | None = None
    title: str
    description: str
    priority: str
    cron_expression: str
    timezone: str
    enabled: bool
    last_run_at: str | None = None
    next_run_at: str | None = None
    created_at: str
    updated_at: str


class TriggerResponse(BaseModel):
    task_id: int
    template_id: int
    message: str


class UpcomingTask(BaseModel):
    template_id: int
    template_title: str
    scheduled_at: str
    priority: str


class BuiltinTemplateResponse(BaseModel):
    key: str
    title: str
    description: str
    cron_expression: str
    priority: str
    timezone: str


class SeedAllResponse(BaseModel):
    created: list[TaskTemplateResponse]
