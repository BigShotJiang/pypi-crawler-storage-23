"""Pydantic models for tool policy endpoints."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class ToolPolicyCreate(BaseModel):
    project_id: str
    name: str
    profile: Literal["minimal", "coding", "full"] = "coding"
    allow: str = ""
    also_allow: str = ""
    deny: str = ""
    fs_workspace_only: bool = True
    exec_security: Literal["deny", "allowlist", "full"] = "allowlist"
    exec_timeout_seconds: int = 300
    is_default: bool = False


class ToolPolicyUpdate(BaseModel):
    name: str | None = None
    profile: Literal["minimal", "coding", "full"] | None = None
    allow: str | None = None
    also_allow: str | None = None
    deny: str | None = None
    fs_workspace_only: bool | None = None
    exec_security: Literal["deny", "allowlist", "full"] | None = None
    exec_timeout_seconds: int | None = None
    is_default: bool | None = None


class ToolPolicyResponse(BaseModel):
    id: int
    project_id: str
    name: str
    profile: Literal["minimal", "coding", "full"]
    allow: str
    also_allow: str
    deny: str
    fs_workspace_only: bool
    exec_security: Literal["deny", "allowlist", "full"]
    exec_timeout_seconds: int
    is_default: bool
    created_at: str
    updated_at: str


class ResolvedPolicy(BaseModel):
    """The flattened/merged result of profile + allow + also_allow - deny."""

    policy_id: int
    policy_name: str
    profile: Literal["minimal", "coding", "full"]
    allowed_tools: list[str]
    denied_tools: list[str]
    fs_workspace_only: bool
    exec_security: Literal["deny", "allowlist", "full"]
    exec_timeout_seconds: int
    is_unrestricted: bool
