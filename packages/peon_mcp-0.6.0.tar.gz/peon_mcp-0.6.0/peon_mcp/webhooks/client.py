"""API client methods for webhooks."""

from __future__ import annotations

from peon_mcp.common.base_client import BaseAPIClient


class WebhookClient(BaseAPIClient):
    """Webhook API client methods."""

    async def create_webhook(
        self,
        project_id: str,
        name: str,
        url: str,
        secret: str = "",
        events: list[str] | None = None,
        enabled: bool = True,
    ) -> dict | str:
        return await self._request(
            "POST",
            "/api/webhooks",
            json={
                "project_id": project_id,
                "name": name,
                "url": url,
                "secret": secret,
                "events": events or [],
                "enabled": enabled,
            },
        )

    async def list_webhooks(self, project_id: str) -> list[dict] | str:
        return await self._paginate_all("/api/webhooks", params={"project_id": project_id})

    async def get_webhook(self, webhook_id: int) -> dict | str:
        return await self._request("GET", f"/api/webhooks/{webhook_id}")

    async def update_webhook(
        self,
        webhook_id: int,
        name: str | None = None,
        url: str | None = None,
        secret: str | None = None,
        events: list[str] | None = None,
        enabled: bool | None = None,
    ) -> dict | str:
        payload = {}
        if name is not None:
            payload["name"] = name
        if url is not None:
            payload["url"] = url
        if secret is not None:
            payload["secret"] = secret
        if events is not None:
            payload["events"] = events
        if enabled is not None:
            payload["enabled"] = enabled
        return await self._request("PUT", f"/api/webhooks/{webhook_id}", json=payload)

    async def delete_webhook(self, webhook_id: int) -> dict | str:
        return await self._request("DELETE", f"/api/webhooks/{webhook_id}")

    async def list_webhook_events(self, webhook_id: int) -> list[dict] | str:
        return await self._paginate_all(f"/api/webhooks/{webhook_id}/events")

    async def test_webhook(self, webhook_id: int) -> dict | str:
        return await self._request("POST", f"/api/webhooks/{webhook_id}/test")
