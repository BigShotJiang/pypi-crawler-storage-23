"""MCP tool registrations for webhooks."""


def register_tools(mcp, api_fn):
    @mcp.tool()
    async def create_webhook(
        project_id: str,
        name: str,
        url: str,
        secret: str = "",
        events: list[str] | None = None,
        enabled: bool = True,
        ctx=None,
    ) -> dict | str:
        """Create a webhook configuration for a project.

        Args:
            project_id: The project identifier (repo name).
            name: Human-readable name for this webhook.
            url: The URL to POST events to.
            secret: Optional secret for HMAC signing (omitted from response).
            events: List of event types to subscribe to (empty = all events).
            enabled: Whether this webhook is active (default True).
        """
        return await api_fn(ctx).create_webhook(
            project_id, name, url, secret, events or [], enabled
        )

    @mcp.tool()
    async def list_webhooks(project_id: str, ctx=None) -> list[dict] | str:
        """List webhook configurations for a project.

        Args:
            project_id: The project identifier (repo name).
        """
        return await api_fn(ctx).list_webhooks(project_id)

    @mcp.tool()
    async def update_webhook(
        webhook_id: int,
        name: str | None = None,
        url: str | None = None,
        secret: str | None = None,
        events: list[str] | None = None,
        enabled: bool | None = None,
        ctx=None,
    ) -> dict | str:
        """Update fields on an existing webhook configuration.

        Args:
            webhook_id: The numeric ID of the webhook to update.
            name: New name (optional).
            url: New URL (optional).
            secret: New secret (optional).
            events: New list of event types (optional).
            enabled: Enable or disable the webhook (optional).
        """
        return await api_fn(ctx).update_webhook(
            webhook_id, name, url, secret, events, enabled
        )

    @mcp.tool()
    async def delete_webhook(webhook_id: int, ctx=None) -> dict | str:
        """Delete a webhook configuration by its ID.

        Args:
            webhook_id: The numeric ID of the webhook to delete.
        """
        return await api_fn(ctx).delete_webhook(webhook_id)

    @mcp.tool()
    async def test_webhook(webhook_id: int, ctx=None) -> dict | str:
        """Send a test event to verify the webhook configuration works.

        Args:
            webhook_id: The numeric ID of the webhook to test.
        """
        return await api_fn(ctx).test_webhook(webhook_id)
