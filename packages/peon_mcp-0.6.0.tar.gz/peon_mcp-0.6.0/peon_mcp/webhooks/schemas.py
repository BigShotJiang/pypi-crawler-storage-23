"""Pydantic models for webhook endpoints."""

from __future__ import annotations

from pydantic import BaseModel


class WebhookConfigCreate(BaseModel):
    project_id: str
    name: str
    url: str
    secret: str = ""
    events: list[str] = []
    enabled: bool = True


class WebhookConfigUpdate(BaseModel):
    name: str | None = None
    url: str | None = None
    secret: str | None = None
    events: list[str] | None = None
    enabled: bool | None = None


class WebhookConfigResponse(BaseModel):
    id: int
    project_id: str
    name: str
    url: str
    events: list[str]
    enabled: bool
    created_at: str
    updated_at: str


class EventLogResponse(BaseModel):
    id: int
    project_id: str
    webhook_config_id: int | None
    event_type: str
    payload: str
    status: str
    response_code: int | None
    error: str
    created_at: str
