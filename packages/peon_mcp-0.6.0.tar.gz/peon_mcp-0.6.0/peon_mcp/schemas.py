"""Pydantic models for request validation and response serialization.

This module re-exports all schema classes from feature packages for
backward compatibility.  Code that does ``from peon_mcp.schemas import
TaskResponse`` will continue to work.
"""

# Common / generic
from peon_mcp.common.schemas import (  # noqa: F401
    BulkUpdateResponse,
    OkResponse,
    PaginatedResponse,
    SuccessResponse,
)

# System
from peon_mcp.system.schemas import (  # noqa: F401
    LoopsResponse,
    SystemInfoResponse,
)

# Projects (includes stats models)
from peon_mcp.projects.schemas import (  # noqa: F401
    ActivityDataPoint,
    ContextPruningConfig,
    CreateProjectRequest,
    DurationStatsResponse,
    PerformanceStatsResponse,
    ProjectActivityResponse,
    ProjectResponse,
    ProjectStatsResponse,
    TestRunStatsResponse,
    TestRunStatusDetail,
    UpdateProjectRequest,
)

# Work logs
from peon_mcp.work_logs.schemas import (  # noqa: F401
    CreateWorkLogRequest,
    WorkLogResponse,
)

# Tasks
from peon_mcp.tasks.schemas import (  # noqa: F401
    BulkUpdateTasksRequest,
    ConflictResolutionResponse,
    CreateTaskRequest,
    GlobalNextTaskRequest,
    NextTaskRequest,
    NextTaskResponse,
    RecoverableTaskResponse,
    RecoveryResponse,
    TaskDetailResponse,
    TaskResponse,
    UpdateTaskProgressRequest,
    UpdateTaskRequest,
)

# Features
from peon_mcp.features.schemas import (  # noqa: F401
    CompleteFeatureRequest,
    CreateFeatureRequest,
    FeatureResponse,
    FeatureTasksResponse,
    ResolveConflictsResponse,
    UpdateFeatureRequest,
)

# Testing
from peon_mcp.testing.schemas import (  # noqa: F401
    CreateTestCommandRequest,
    TestCaseResponse,
    TestCommandResponse,
    TestRunResponse,
    TestRunResultResponse,
    UpdateTestCommandRequest,
)

# Memories
from peon_mcp.memories.schemas import (  # noqa: F401
    CreateMemoryRequest,
    MemoryResponse,
    RecallMemoriesRequest,
)

# Reviews
from peon_mcp.reviews.schemas import (  # noqa: F401
    CancelReviewResponse,
    CompleteReviewPerspectiveRequest,
    CompleteReviewPerspectiveResponse,
    CreateReviewRequest,
    CreateReviewResponse,
    CreateTaskFromReviewRequest,
    PerspectiveFindings,
    ReviewConvergenceResponse,
    ReviewFindingResponse,
    ReviewSessionDetailResponse,
    ReviewSessionResponse,
    ReviewSummary,
    SimpleCreateReviewSessionRequest,
    SubmitReviewFindingRequest,
)

# Webhooks
from peon_mcp.webhooks.schemas import (  # noqa: F401
    EventLogResponse,
    WebhookConfigCreate,
    WebhookConfigResponse,
    WebhookConfigUpdate,
)

# Sessions
from peon_mcp.sessions.schemas import (  # noqa: F401
    SessionCreate,
    SessionDetailResponse,
    SessionEventCreate,
    SessionEventResponse,
    SessionResponse,
    SessionStatsResponse,
    SessionUpdate,
)

# Discord
from peon_mcp.discord.schemas import (  # noqa: F401
    ActivityLogCreate,
    ActivityLogResponse,
    BotStatusResponse,
    ChannelMappingCreate,
    ChannelMappingResponse,
    ChannelMappingUpdate,
    DiscordConfigCreate,
    DiscordConfigResponse,
    DiscordConfigUpdate,
    DiscordEmbedField,
    DiscordInboundMessageResponse,
    DiscordMessagePayload,
    SendMessageRequest,
    SendMessageResponse,
)

# Forward reference updates (needed due to cross-references)
FeatureTasksResponse.model_rebuild()
TaskDetailResponse.model_rebuild()
