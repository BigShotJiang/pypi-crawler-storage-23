"""Task management domain."""
