"""Pydantic models for task endpoints."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

from peon_mcp.work_logs.schemas import WorkLogResponse


class TaskResponse(BaseModel):
    id: int
    project_id: str
    feature_id: int | None = None
    title: str
    description: str
    priority: Literal["low", "medium", "high", "critical"]
    status: Literal["grooming", "todo", "in_progress", "done", "cancelled", "timeout"]
    commit_base: str
    commit_head: str
    branch: str
    worktree_path: str
    pr_url: str
    progress: float
    lines_added: int
    lines_deleted: int
    tokens_used: int
    scheduled_at: str | None = None
    started_at: str | None = None
    completed_at: str | None = None
    created_at: str
    updated_at: str
    all_feature_tasks_complete: bool | None = None
    feature_branch: str | None = None
    feature_name: str | None = None
    tool_policy_id: int | None = None
    depends_on: list[int] = []
    blocked_by: list[int] = []


class TaskDetailResponse(TaskResponse):
    work_logs: list[WorkLogResponse] = []


class RecoverableTaskResponse(TaskResponse):
    recovery_hints: list[str] = []


class CreateTaskRequest(BaseModel):
    title: str
    description: str = ""
    priority: str = "medium"
    status: str = "todo"
    commit_base: str = ""
    commit_head: str = ""
    branch: str = ""
    worktree_path: str = ""
    pr_url: str = ""
    feature_id: int | None = None
    depends_on: list[int] = []
    scheduled_at: str | None = None


class UpdateTaskRequest(BaseModel):
    title: str | None = None
    description: str | None = None
    priority: str | None = None
    status: str | None = None
    commit_base: str | None = None
    commit_head: str | None = None
    branch: str | None = None
    worktree_path: str | None = None
    pr_url: str | None = None
    feature_id: int | None = None
    lines_added: int | None = None
    lines_deleted: int | None = None
    tokens_used: int | None = None
    test_override: str | None = None
    tool_policy_id: int | None = None


class UpdateTaskProgressRequest(BaseModel):
    progress: float


class BulkUpdateTasksRequest(BaseModel):
    task_ids: list[int]
    status: str


class NextTaskRequest(BaseModel):
    commit_base: str = ""
    feature_id: int | None = None


class GlobalNextTaskRequest(BaseModel):
    project_id: str = ""
    commit_base: str = ""
    feature_id: int | None = None


class NextTaskResponse(TaskResponse):
    feature_branch: str | None = None


class RecoveryResponse(BaseModel):
    status: str
    recovery_task_id: int
    original_task_id: int
    message: str


class ConflictResolutionResponse(BaseModel):
    status: str
    conflict_resolution_task_id: int
    original_task_id: int
    message: str


class AddDependencyRequest(BaseModel):
    depends_on_task_id: int


class TaskDependencyResponse(BaseModel):
    id: int
    task_id: int
    depends_on_task_id: int
    created_at: str
