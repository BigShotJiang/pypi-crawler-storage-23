"""Pydantic models for sub-agent endpoints."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class SubAgentSpawn(BaseModel):
    project_id: str
    label: str
    parent_task_id: int | None = None
    model: str = ""
    timeout_seconds: int = 600
    idempotency_key: str = ""


class SubAgentUpdate(BaseModel):
    status: Literal["pending", "running", "completed", "failed", "timeout", "cancelled"] | None = None
    result_summary: str | None = None
    tokens_used: int | None = None
    ended_at: str | None = None
    pid: int | None = None


class SubAgentResponse(BaseModel):
    id: int
    parent_session_id: int | None = None
    parent_task_id: int | None = None
    project_id: str
    label: str
    idempotency_key: str
    model: str
    status: Literal["pending", "running", "completed", "failed", "timeout", "cancelled"]
    depth: int
    pid: int | None = None
    result_summary: str
    tokens_used: int
    timeout_seconds: int
    started_at: str
    ended_at: str | None = None
    created_at: str
    duration_seconds: float | None = None


class SubAgentLimitsResponse(BaseModel):
    project_id: str
    max_subagent_depth: int
    max_subagents_per_task: int
    max_concurrent_subagents: int
    current_running: int
    current_pending: int
    can_spawn: bool
    reason: str
