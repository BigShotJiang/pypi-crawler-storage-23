"""MCP tool registrations for testing."""

from mcp.server.fastmcp import Context


def register_tools(mcp, api_fn):
    @mcp.tool()
    async def add_test_command(
        project_id: str,
        name: str,
        command: str,
        timeout_seconds: int = 300,
        sort_order: int = 0,
        report_path: str = "",
        max_retries: int = 3,
        ctx: Context = None,
    ) -> dict | str:
        """Add a test command configuration for a project.

        Args:
            project_id: The project this test command belongs to (repo name).
            name: Short name for the test command (e.g. 'Unit Tests', 'Linting').
            command: The shell command to execute (e.g. 'pytest', 'npm test').
            timeout_seconds: Maximum execution time in seconds (default: 300).
            sort_order: Execution order (lower values run first, default: 0).
            report_path: Path to JUnit XML report file for parsing test results (optional).
            max_retries: Maximum number of retry attempts before escalation (default: 3).
        """
        return await api_fn(ctx).add_test_command(
            project_id, name, command, timeout_seconds, sort_order, report_path, max_retries,
        )

    @mcp.tool()
    async def list_test_commands(
        project_id: str,
        ctx: Context = None,
    ) -> list[dict]:
        """List all test commands for a project.

        Returns all test commands ordered by sort_order (execution order).
        Includes both enabled and disabled commands.

        Args:
            project_id: The project to list test commands for (repo name).
        """
        return await api_fn(ctx).list_test_commands(project_id)

    @mcp.tool()
    async def update_test_command(
        test_command_id: int,
        name: str | None = None,
        command: str | None = None,
        timeout_seconds: int | None = None,
        sort_order: int | None = None,
        enabled: bool | None = None,
        report_path: str | None = None,
        max_retries: int | None = None,
        ctx: Context = None,
    ) -> dict | str:
        """Update fields on an existing test command.

        Args:
            test_command_id: The numeric ID of the test command to update.
            name: New name (optional).
            command: New command (optional).
            timeout_seconds: New timeout in seconds (optional).
            sort_order: New sort order (optional).
            enabled: Enable or disable the test command (optional).
            report_path: New report path (optional).
            max_retries: New max retries (optional).
        """
        return await api_fn(ctx).update_test_command(
            test_command_id, name, command, timeout_seconds,
            sort_order, enabled, report_path, max_retries,
        )

    @mcp.tool()
    async def delete_test_command(test_command_id: int, ctx: Context = None) -> str:
        """Delete a test command by its ID.

        Args:
            test_command_id: The numeric ID of the test command to delete.
        """
        return await api_fn(ctx).delete_test_command(test_command_id)

    @mcp.tool()
    async def run_tests(
        task_id: int,
        project_id: str,
        ctx: Context = None,
    ) -> dict:
        """Execute test commands for a task and record results.

        Runs all enabled test commands for the project in sort order. Records
        test results to test_runs and test_cases tables. Respects max_retries
        to prevent infinite test loops.

        Args:
            task_id: The task ID to run tests for.
            project_id: The project this task belongs to.

        Returns:
            Dictionary with overall_status, results array, summary string, and needs_human_review flag.
        """
        return await api_fn(ctx).run_tests(task_id, project_id)

    @mcp.tool()
    async def list_test_runs(
        task_id: int | None = None,
        project_id: str | None = None,
        include_cases: bool = False,
        ctx: Context = None,
    ) -> list[dict]:
        """List test runs, optionally filtered by task or project.

        Args:
            task_id: Filter to runs for a specific task (optional).
            project_id: Filter to runs for a specific project (optional).
            include_cases: Include nested test_cases for each run (optional).

        Returns:
            List of test run dictionaries, ordered by created_at DESC.
        """
        return await api_fn(ctx).list_test_runs(task_id, project_id, include_cases)
