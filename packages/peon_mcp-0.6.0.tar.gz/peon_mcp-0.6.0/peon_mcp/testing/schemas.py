"""Pydantic models for test command and test run endpoints."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, field_validator


class TestCommandResponse(BaseModel):
    id: int
    project_id: str
    name: str
    command: str
    timeout_seconds: int
    sort_order: int
    enabled: bool
    report_path: str
    max_retries: int
    created_at: str
    updated_at: str

    @field_validator("enabled", mode="before")
    @classmethod
    def coerce_enabled(_cls, v: Any) -> bool:
        return bool(v)


class CreateTestCommandRequest(BaseModel):
    name: str
    command: str
    timeout_seconds: int = 300
    sort_order: int = 0
    enabled: bool = True
    report_path: str = ""
    max_retries: int = 3


class UpdateTestCommandRequest(BaseModel):
    name: str | None = None
    command: str | None = None
    timeout_seconds: int | None = None
    sort_order: int | None = None
    enabled: bool | None = None
    report_path: str | None = None
    max_retries: int | None = None


class TestCaseResponse(BaseModel):
    id: int
    test_run_id: int
    name: str
    classname: str
    status: Literal["pass", "fail", "error", "skip"]
    duration_seconds: float
    message: str
    created_at: str


class TestRunResponse(BaseModel):
    id: int
    task_id: int
    project_id: str
    test_command_id: int
    command_name: str
    command: str
    status: Literal["pending", "running", "pass", "fail", "error", "timeout"]
    exit_code: int | None = None
    duration_seconds: float | None = None
    output: str
    tests_passed: int
    tests_failed: int
    tests_skipped: int
    created_at: str
    test_cases: list[TestCaseResponse] | None = None


class TestRunResultResponse(BaseModel):
    overall_status: str
    results: list[dict[str, Any]]
    summary: str
    needs_human_review: bool
