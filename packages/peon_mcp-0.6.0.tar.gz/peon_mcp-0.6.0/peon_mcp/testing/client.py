"""API client methods for testing."""

from __future__ import annotations

from typing import Any

from peon_mcp.common.base_client import BaseAPIClient


class TestingClient(BaseAPIClient):
    """Testing API client methods."""

    async def add_test_command(
        self,
        project_id: str,
        name: str,
        command: str,
        timeout_seconds: int = 300,
        sort_order: int = 0,
        report_path: str = "",
        max_retries: int = 3,
    ) -> dict | str:
        return await self._request(
            "POST", f"/api/projects/{project_id}/test-commands",
            json={
                "name": name,
                "command": command,
                "timeout_seconds": timeout_seconds,
                "sort_order": sort_order,
                "report_path": report_path,
                "max_retries": max_retries,
            },
        )

    async def list_test_commands(self, project_id: str) -> list[dict] | str:
        return await self._request(
            "GET", f"/api/projects/{project_id}/test-commands"
        )

    async def update_test_command(
        self,
        test_command_id: int,
        name: str | None = None,
        command: str | None = None,
        timeout_seconds: int | None = None,
        sort_order: int | None = None,
        enabled: bool | None = None,
        report_path: str | None = None,
        max_retries: int | None = None,
    ) -> dict | str:
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if command is not None:
            body["command"] = command
        if timeout_seconds is not None:
            body["timeout_seconds"] = timeout_seconds
        if sort_order is not None:
            body["sort_order"] = sort_order
        if enabled is not None:
            body["enabled"] = enabled
        if report_path is not None:
            body["report_path"] = report_path
        if max_retries is not None:
            body["max_retries"] = max_retries
        return await self._request(
            "PUT", f"/api/test-commands/{test_command_id}", json=body
        )

    async def delete_test_command(self, test_command_id: int) -> str:
        result = await self._request(
            "DELETE", f"/api/test-commands/{test_command_id}"
        )
        if isinstance(result, dict) and result.get("success"):
            return f"Test command {test_command_id} deleted"
        if isinstance(result, str):
            return result
        return f"Test command {test_command_id} deleted"

    async def run_tests(self, task_id: int, project_id: str) -> dict | str:
        return await self._request(
            "POST", f"/api/tasks/{task_id}/run-tests",
            timeout=600.0,
        )

    async def list_test_runs(
        self,
        task_id: int | None = None,
        project_id: str | None = None,
        include_cases: bool = False,
    ) -> list[dict] | str:
        if task_id is not None:
            # Task-scoped endpoint always includes cases
            return await self._request("GET", f"/api/tasks/{task_id}/test-runs")
        if project_id is not None:
            return await self._paginate_all(
                f"/api/projects/{project_id}/test-runs"
            )
        return []
