"""MCP tool registrations for projects."""

from mcp.server.fastmcp import Context


def register_tools(mcp, api_fn):
    @mcp.tool()
    async def create_project(
        project_id: str,
        path: str,
        github_url: str = "",
        ctx: Context = None,
    ) -> dict:
        """Register a project so tasks can be scoped to it.

        Args:
            project_id: Unique identifier for the project (typically the repo name, e.g. 'peon-mcp').
            path: Absolute path to the project on disk (e.g. '/Users/me/projects/peon-mcp').
            github_url: GitHub repository URL (e.g. 'https://github.com/org/repo'). Used by peon-loop to clone the repo if it doesn't exist locally.
        """
        return await api_fn(ctx).create_project(project_id, path, github_url)

    @mcp.tool()
    async def list_projects(ctx: Context = None) -> list[dict]:
        """List all registered projects."""
        return await api_fn(ctx).list_projects()

    @mcp.tool()
    async def get_project(project_id: str, ctx: Context = None) -> dict | str:
        """Get a project by its ID.

        Args:
            project_id: The project identifier (repo name).
        """
        return await api_fn(ctx).get_project(project_id)

    @mcp.tool()
    async def update_project(
        project_id: str,
        path: str | None = None,
        github_url: str | None = None,
        ctx: Context = None,
    ) -> dict | str:
        """Update fields on an existing project.

        Args:
            project_id: The project identifier to update.
            path: New filesystem path for the project (optional).
            github_url: GitHub repository URL (optional).
        """
        return await api_fn(ctx).update_project(project_id, path, github_url)
