"""API client methods for projects."""

from __future__ import annotations

from typing import Any

from peon_mcp.common.base_client import BaseAPIClient


class ProjectClient(BaseAPIClient):
    """Project API client methods."""

    async def create_project(
        self, project_id: str, path: str, github_url: str = ""
    ) -> dict | str:
        result = await self._request(
            "POST", "/api/projects",
            json={"id": project_id, "path": path, "github_url": github_url},
        )
        # MCP uses INSERT OR IGNORE; REST returns 409 on duplicate.
        # On 409, fall back to GET to match MCP idempotent behavior.
        if isinstance(result, str) and "already exists" in result:
            return await self._request("GET", f"/api/projects/{project_id}")
        return result

    async def list_projects(self) -> list[dict] | str:
        return await self._request("GET", "/api/projects")

    async def get_project(self, project_id: str) -> dict | str:
        return await self._request("GET", f"/api/projects/{project_id}")

    async def update_project(
        self, project_id: str, path: str | None = None, github_url: str | None = None
    ) -> dict | str:
        body: dict[str, Any] = {}
        if path is not None:
            body["path"] = path
        if github_url is not None:
            body["github_url"] = github_url
        return await self._request("PUT", f"/api/projects/{project_id}", json=body)
