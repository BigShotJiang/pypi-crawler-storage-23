"""Pydantic models for project endpoints."""

from __future__ import annotations

from pydantic import BaseModel, Field

from peon_mcp.work_logs.schemas import WorkLogResponse


class ContextPruningConfig(BaseModel):
    enabled: bool = True
    default_max_chars: int = 10000
    ttl_minutes: int = 30
    head_tail_ratio: list[float] = Field(default_factory=lambda: [0.7, 0.2])
    per_tool_limits: dict[str, int] = Field(
        default_factory=lambda: {
            "bash": 5000,
            "read": 8000,
            "grep": 3000,
            "glob": 2000,
            "git_log": 3000,
            "git_diff": 8000,
            "run_tests": 5000,
        }
    )
    always_preserve: list[str] = Field(
        default_factory=lambda: ["error", "commit_sha", "pr_url"]
    )
    never_prune_tools: list[str] = Field(
        default_factory=lambda: ["create_task", "update_task"]
    )


class ProjectResponse(BaseModel):
    id: str
    path: str
    github_url: str = ""
    created_at: str


class CreateProjectRequest(BaseModel):
    id: str
    path: str
    github_url: str = ""


class UpdateProjectRequest(BaseModel):
    path: str | None = None
    github_url: str | None = None


class DurationStatsResponse(BaseModel):
    avg_duration: float | None = None
    min_duration: float | None = None
    max_duration: float | None = None
    completed_count: int


class PerformanceStatsResponse(BaseModel):
    total_lines_added: int
    total_lines_deleted: int
    total_tokens_used: int


class TestRunStatusDetail(BaseModel):
    count: int
    avg_duration: float


class TestRunStatsResponse(BaseModel):
    by_status: dict[str, TestRunStatusDetail]
    configured_commands: int
    total_runs: int
    pass_rate: float
    total_test_cases: int
    total_case_failures: int


class ProjectStatsResponse(BaseModel):
    feature_counts: dict[str, int]
    task_counts: dict[str, int]
    task_priority_counts: dict[str, int]
    total_logs: int
    test_counts: dict[str, int]
    recent_logs: list[WorkLogResponse]
    duration_stats: DurationStatsResponse
    performance_stats: PerformanceStatsResponse
    test_run_stats: TestRunStatsResponse | None = None


class ActivityDataPoint(BaseModel):
    hour: str
    count: int


class ProjectActivityResponse(BaseModel):
    activity: list[ActivityDataPoint]
