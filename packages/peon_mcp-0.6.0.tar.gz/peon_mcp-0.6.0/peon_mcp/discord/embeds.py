"""Discord embed formatters for peon-mcp webhook events.

Each builder returns a plain dict matching Discord's embed object schema.
No discord.py import is required — the dict is sent directly via the REST API.
"""

from __future__ import annotations

from datetime import datetime, timezone

# Discord embed colors
COLOR_GREEN = 0x57F287   # task.created, test.passed
COLOR_GOLD = 0xFEE75C    # task.completed, feature.completed
COLOR_RED = 0xED4245     # task.failed, test.failed, test.max_retries_exhausted
COLOR_ORANGE = 0xE67E22  # task.timeout
COLOR_BLUE = 0x5865F2    # review.session_completed
COLOR_PURPLE = 0x9B59B6  # review.convergence_found

# Priority badge emoji
_PRIORITY_BADGE = {
    "critical": "🔴 Critical",
    "high": "🟠 High",
    "medium": "🟡 Medium",
    "low": "🟢 Low",
}


def _embed(
    title: str,
    description: str,
    color: int,
    project_id: str,
    fields: list[dict] | None = None,
) -> dict:
    """Build a base Discord embed dict with standard footer and timestamp."""
    embed: dict = {
        "title": title,
        "description": description,
        "color": color,
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z"),
        "footer": {"text": f"Project: {project_id}"},
    }
    if fields:
        embed["fields"] = fields
    return embed


def _field(name: str, value: str, inline: bool = False) -> dict:
    return {"name": name, "value": value or "\u200b", "inline": inline}


# ---------------------------------------------------------------------------
# Task event formatters
# ---------------------------------------------------------------------------


def _task_created(project_id: str, data: dict) -> dict:
    title = data.get("title", "Untitled Task")
    priority = data.get("priority", "medium")
    task_id = data.get("task_id", "?")
    task_url = data.get("task_url", "")

    fields = [
        _field("Priority", _PRIORITY_BADGE.get(priority, priority), inline=True),
        _field("Task ID", f"#{task_id}", inline=True),
    ]
    assignee = data.get("assignee", "")
    if assignee:
        fields.append(_field("Assignee", assignee, inline=True))

    description = f"**[{title}]({task_url})**" if task_url else f"**{title}**"
    return _embed(
        title="Task Created",
        description=description,
        color=COLOR_GREEN,
        project_id=project_id,
        fields=fields,
    )


def _task_completed(project_id: str, data: dict) -> dict:
    title = data.get("title", "Untitled Task")
    task_id = data.get("task_id", "?")
    lines_added = data.get("lines_added", 0)
    lines_deleted = data.get("lines_deleted", 0)
    duration = data.get("duration_seconds")

    fields = [
        _field("Task ID", f"#{task_id}", inline=True),
        _field("Lines", f"+{lines_added} / -{lines_deleted}", inline=True),
    ]
    if duration is not None:
        minutes, secs = divmod(int(duration), 60)
        fields.append(_field("Duration", f"{minutes}m {secs}s", inline=True))

    return _embed(
        title="Task Completed",
        description=f"**{title}**",
        color=COLOR_GOLD,
        project_id=project_id,
        fields=fields,
    )


def _task_failed(project_id: str, data: dict) -> dict:
    title = data.get("title", "Untitled Task")
    task_id = data.get("task_id", "?")
    error = data.get("error", "No error details provided.")

    fields = [
        _field("Task ID", f"#{task_id}", inline=True),
        _field("Error", f"```{error[:1000]}```", inline=False),
    ]
    return _embed(
        title="Task Failed",
        description=f"**{title}**",
        color=COLOR_RED,
        project_id=project_id,
        fields=fields,
    )


def _task_timeout(project_id: str, data: dict) -> dict:
    title = data.get("title", "Untitled Task")
    task_id = data.get("task_id", "?")
    timeout_secs = data.get("timeout_seconds")

    fields = [_field("Task ID", f"#{task_id}", inline=True)]
    if timeout_secs is not None:
        minutes, secs = divmod(int(timeout_secs), 60)
        fields.append(_field("Timeout After", f"{minutes}m {secs}s", inline=True))

    return _embed(
        title="Task Timed Out",
        description=f"**{title}**",
        color=COLOR_ORANGE,
        project_id=project_id,
        fields=fields,
    )


# ---------------------------------------------------------------------------
# Test event formatters
# ---------------------------------------------------------------------------


def _test_passed(project_id: str, data: dict) -> dict:
    command = data.get("test_command", "tests")
    pass_count = data.get("pass_count", 0)
    duration = data.get("duration_seconds")

    fields = [
        _field("Command", f"`{command}`", inline=False),
        _field("Passed", str(pass_count), inline=True),
    ]
    if duration is not None:
        fields.append(_field("Duration", f"{duration:.1f}s", inline=True))

    return _embed(
        title="Tests Passed",
        description="All tests passed successfully.",
        color=COLOR_GREEN,
        project_id=project_id,
        fields=fields,
    )


def _test_failed(project_id: str, data: dict) -> dict:
    command = data.get("test_command", "tests")
    fail_count = data.get("fail_count", 0)
    failures: list = data.get("failures", [])

    fields = [
        _field("Command", f"`{command}`", inline=False),
        _field("Failed", str(fail_count), inline=True),
    ]
    if failures:
        summary_lines = []
        for f in failures[:5]:
            name = f.get("name", "unknown") if isinstance(f, dict) else str(f)
            summary_lines.append(f"• {name}")
        if len(failures) > 5:
            summary_lines.append(f"…and {len(failures) - 5} more")
        fields.append(_field("Failures", "\n".join(summary_lines), inline=False))

    return _embed(
        title="Tests Failed",
        description=f"{fail_count} test(s) failed.",
        color=COLOR_RED,
        project_id=project_id,
        fields=fields,
    )


def _test_max_retries_exhausted(project_id: str, data: dict) -> dict:
    command = data.get("test_command", "tests")
    retry_count = data.get("retry_count", 0)
    needs_human = data.get("needs_human_review", False)

    fields = [
        _field("Command", f"`{command}`", inline=False),
        _field("Retries Attempted", str(retry_count), inline=True),
        _field(
            "Human Review",
            "⚠️ Required" if needs_human else "Not flagged",
            inline=True,
        ),
    ]
    return _embed(
        title="Tests: Max Retries Exhausted",
        description="All retry attempts have been used.",
        color=COLOR_RED,
        project_id=project_id,
        fields=fields,
    )


# ---------------------------------------------------------------------------
# Review event formatters
# ---------------------------------------------------------------------------


def _review_session_completed(project_id: str, data: dict) -> dict:
    session_id = data.get("session_id", "?")
    summary = data.get("summary", "Review session completed.")
    finding_counts: dict = data.get("finding_counts", {})

    fields = [_field("Session ID", f"#{session_id}", inline=True)]
    if finding_counts:
        count_parts = [f"{sev}: {cnt}" for sev, cnt in finding_counts.items()]
        fields.append(_field("Findings", " | ".join(count_parts), inline=False))

    return _embed(
        title="Review Session Completed",
        description=summary[:2000] if summary else "Review complete.",
        color=COLOR_BLUE,
        project_id=project_id,
        fields=fields,
    )


def _review_convergence_found(project_id: str, data: dict) -> dict:
    session_id = data.get("session_id", "?")
    findings: list = data.get("findings", [])

    fields = [_field("Session ID", f"#{session_id}", inline=True)]
    if findings:
        lines = []
        for f in findings[:5]:
            if isinstance(f, dict):
                sev = f.get("severity", "?")
                msg = f.get("message", f.get("summary", ""))[:120]
                lines.append(f"• [{sev}] {msg}")
            else:
                lines.append(f"• {str(f)[:120]}")
        if len(findings) > 5:
            lines.append(f"…and {len(findings) - 5} more")
        fields.append(_field("Converged Findings", "\n".join(lines), inline=False))

    return _embed(
        title="Review Convergence Found",
        description=f"{len(findings)} finding(s) converged across perspectives.",
        color=COLOR_PURPLE,
        project_id=project_id,
        fields=fields,
    )


# ---------------------------------------------------------------------------
# Feature event formatters
# ---------------------------------------------------------------------------


def _feature_completed(project_id: str, data: dict) -> dict:
    name = data.get("name", "Untitled Feature")
    feature_id = data.get("feature_id", "?")
    task_count = data.get("task_count", 0)
    pr_url = data.get("pr_url", "")

    description = f"**{name}**"
    if pr_url:
        description += f"\n[View Pull Request]({pr_url})"

    fields = [
        _field("Feature ID", f"#{feature_id}", inline=True),
        _field("Tasks Completed", str(task_count), inline=True),
    ]
    return _embed(
        title="Feature Completed",
        description=description,
        color=COLOR_GOLD,
        project_id=project_id,
        fields=fields,
    )


# ---------------------------------------------------------------------------
# Public dispatch
# ---------------------------------------------------------------------------

_BUILDERS = {
    "task.created": _task_created,
    "task.completed": _task_completed,
    "task.failed": _task_failed,
    "task.timeout": _task_timeout,
    "test.passed": _test_passed,
    "test.failed": _test_failed,
    "test.max_retries_exhausted": _test_max_retries_exhausted,
    "review.session_completed": _review_session_completed,
    "review.convergence_found": _review_convergence_found,
    "feature.completed": _feature_completed,
}


def build_embed(event_type: str, project_id: str, data: dict) -> dict:
    """Return a Discord embed dict for the given event type and payload data.

    Args:
        event_type: The event type string (e.g. 'task.completed').
        project_id: The project that emitted the event — shown in the embed footer.
        data: Event-specific payload fields (varies by event type).

    Returns:
        A plain dict conforming to Discord's embed object schema.
        Suitable for use in the ``embeds`` array of a Discord message payload.
    """
    builder = _BUILDERS.get(event_type)
    if builder:
        return builder(project_id, data)
    return _embed(
        title=f"Event: {event_type}",
        description=str(data)[:2000],
        color=COLOR_BLUE,
        project_id=project_id,
    )
