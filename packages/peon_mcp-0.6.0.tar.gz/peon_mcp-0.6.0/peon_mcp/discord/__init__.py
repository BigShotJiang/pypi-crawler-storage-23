"""Discord bot integration feature package."""
