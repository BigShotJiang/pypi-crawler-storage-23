"""Pydantic models for review endpoints."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

from peon_mcp.tasks.schemas import TaskResponse


class ReviewSessionResponse(BaseModel):
    id: int
    project_id: str
    task_id: int
    pr_url: str
    pr_title: str
    status: Literal["pending", "in_progress", "completed", "failed", "cancelled"]
    pipeline_stage: Literal["reviewing", "fixing", "verifying", "complete", "failed"] = "reviewing"
    fix_policy: Literal["auto", "manual", "skip"] = "auto"
    perspectives: list[str]
    pipeline_stage: str = "reviewing"
    fix_policy: str = "auto"
    created_at: str
    completed_at: str | None = None
    updated_at: str


class ReviewFindingResponse(BaseModel):
    id: int
    session_id: int
    perspective: str
    agent_status: Literal["pending", "in_progress", "completed", "failed"]
    severity: Literal["info", "low", "medium", "high", "critical"]
    category: str
    file_path: str
    line_start: int | None = None
    line_end: int | None = None
    title: str
    description: str
    suggestion: str
    confidence: float
    created_task_id: int | None = None
    created_at: str


class ReviewConvergenceResponse(BaseModel):
    id: int
    session_id: int
    category: str
    file_path: str
    finding_ids: list[int]
    perspectives: list[str]
    convergence_count: int
    max_severity: Literal["info", "low", "medium", "high", "critical"]
    summary: str
    created_task_id: int | None = None
    created_at: str


class PerspectiveFindings(BaseModel):
    agent_status: Literal["pending", "in_progress", "completed", "failed"]
    findings: list[ReviewFindingResponse]
    finding_count: int


class ReviewSummary(BaseModel):
    total_findings: int
    by_severity: dict[str, int]
    convergence_count: int


class ReviewSessionDetailResponse(ReviewSessionResponse):
    findings_by_perspective: dict[str, PerspectiveFindings]
    convergences: list[ReviewConvergenceResponse]
    summary: ReviewSummary
    fix_tasks: list[TaskResponse] = []
    verify_task: TaskResponse | None = None


class CreateReviewRequest(BaseModel):
    perspectives: list[str] = ["security", "maintainability", "architecture"]


class CreateReviewResponse(BaseModel):
    session_id: int
    status: str
    tasks_created: int
    task_ids: list[int]
    message: str


class CancelReviewResponse(BaseModel):
    status: str
    message: str


class SubmitReviewFindingRequest(BaseModel):
    perspective: str
    severity: str
    category: str
    file_path: str
    title: str
    description: str
    suggestion: str
    line_start: int | None = None
    line_end: int | None = None
    confidence: float | None = None


class CompleteReviewPerspectiveRequest(BaseModel):
    tokens_used: int | None = None


class CompleteReviewPerspectiveResponse(BaseModel):
    session_id: int
    perspective: str
    findings_updated: int
    tokens_used: int
    status: str
    pipeline_advanced: dict | None = None


class SimpleCreateReviewSessionRequest(BaseModel):
    project_id: str
    task_id: int
    perspectives: list[str] | None = None
    fix_policy: Literal["auto", "manual", "skip"] = "auto"


class CreateTaskFromReviewRequest(BaseModel):
    convergence_id: int | None = None
    finding_id: int | None = None


class AdvancePipelineResponse(BaseModel):
    advanced: bool
    from_stage: str | None = None
    to_stage: str | None = None
    reason: str | None = None
    tasks_created: int | None = None


class RetryPipelineResponse(BaseModel):
    retried: bool
    stage: str
    reset_tasks: list[int] = []
    verify_task_id: int | None = None


class PipelineStatusResponse(BaseModel):
    session_id: int
    pipeline_stage: str
    fix_policy: str
    stages: dict
