"""API client methods for reviews."""

from __future__ import annotations

from typing import Any

from peon_mcp.common.base_client import BaseAPIClient


class ReviewClient(BaseAPIClient):
    """Review API client methods."""

    async def submit_review_finding(
        self,
        session_id: int,
        perspective: str,
        severity: str,
        category: str,
        file_path: str,
        title: str,
        description: str,
        suggestion: str,
        line_start: int | None = None,
        line_end: int | None = None,
        confidence: float | None = None,
    ) -> dict | str:
        body: dict[str, Any] = {
            "perspective": perspective,
            "severity": severity,
            "category": category,
            "file_path": file_path,
            "title": title,
            "description": description,
            "suggestion": suggestion,
        }
        if line_start is not None:
            body["line_start"] = line_start
        if line_end is not None:
            body["line_end"] = line_end
        if confidence is not None:
            body["confidence"] = confidence
        return await self._request(
            "POST", f"/api/reviews/{session_id}/findings", json=body
        )

    async def complete_review_perspective(
        self,
        session_id: int,
        perspective: str,
        tokens_used: int | None = None,
    ) -> dict | str:
        body: dict[str, Any] = {}
        if tokens_used is not None:
            body["tokens_used"] = tokens_used
        return await self._request(
            "POST",
            f"/api/reviews/{session_id}/perspectives/{perspective}/complete",
            json=body or None,
        )

    async def create_review_session(
        self,
        project_id: str,
        task_id: int,
        perspectives: list[str] | None = None,
    ) -> dict | str:
        body: dict[str, Any] = {
            "project_id": project_id,
            "task_id": task_id,
        }
        if perspectives is not None:
            body["perspectives"] = perspectives
        return await self._request("POST", "/api/reviews", json=body)

    async def get_review_session(self, session_id: int) -> dict | str:
        return await self._request("GET", f"/api/reviews/{session_id}")

    async def list_review_sessions(
        self, project_id: str, status: str | None = None
    ) -> list[dict] | str:
        params: dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        return await self._paginate_all(
            f"/api/projects/{project_id}/reviews", params=params
        )

    async def cancel_review_session(self, session_id: int) -> dict | str:
        return await self._request(
            "POST", f"/api/reviews/{session_id}/cancel"
        )

    async def advance_pipeline(self, session_id: int) -> dict | str:
        return await self._request("POST", f"/api/reviews/{session_id}/advance")

    async def get_pipeline_status(self, session_id: int) -> dict | str:
        return await self._request("GET", f"/api/reviews/{session_id}/pipeline")

    async def retry_pipeline(self, session_id: int) -> dict | str:
        return await self._request("POST", f"/api/reviews/{session_id}/retry")
