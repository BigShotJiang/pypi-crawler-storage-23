"""Code review management domain."""
