"""API client methods for memories."""

from __future__ import annotations

from typing import Any

from peon_mcp.common.base_client import BaseAPIClient


class MemoryClient(BaseAPIClient):
    """Memory API client methods."""

    async def save_memory(
        self,
        project_id: str,
        category: str = "general",
        content: str = "",
        source_task_id: int | None = None,
    ) -> dict | str:
        json_body: dict[str, Any] = {
            "category": category,
            "content": content,
        }
        if source_task_id is not None:
            json_body["source_task_id"] = source_task_id
        return await self._request(
            "POST", f"/api/projects/{project_id}/memories",
            json=json_body,
        )

    async def recall_memories(
        self,
        project_id: str,
        category: str | None = None,
        limit: int = 10,
    ) -> list[dict] | str:
        json_body: dict[str, Any] = {"limit": limit}
        if category is not None:
            json_body["category"] = category
        return await self._request(
            "POST", f"/api/projects/{project_id}/memories/recall",
            json=json_body,
        )

    async def forget_memory(self, memory_id: int) -> dict | str:
        return await self._request("DELETE", f"/api/memories/{memory_id}")

    async def list_memories(
        self,
        project_id: str,
        category: str | None = None,
    ) -> list[dict] | str:
        params: dict[str, Any] = {}
        if category is not None:
            params["category"] = category
        return await self._paginate_all(
            f"/api/projects/{project_id}/memories", params=params,
        )
