"""MCP tool registrations for memories."""

from mcp.server.fastmcp import Context


def register_tools(mcp, api_fn):
    @mcp.tool()
    async def save_memory(
        project_id: str,
        category: str,
        content: str,
        source_task_id: int | None = None,
        ctx: Context = None,
    ) -> dict | str:
        """Save a compact memory for future agents working on this project.

        Memories persist across task sessions and are designed for context injection.
        Use this to record learnings, gotchas, environment quirks, patterns, and
        test insights that future agents should know about.

        Each project is capped at 50 memories. When full, the least-accessed
        oldest memory is automatically evicted.

        Args:
            project_id: The project identifier (repo name).
            category: Memory category — 'env', 'pattern', 'gotcha', 'test', 'dependency', or 'general'.
            content: The memory content (max 500 characters). Keep it concise and actionable.
            source_task_id: The task ID that produced this learning (optional).
        """
        return await api_fn(ctx).save_memory(project_id, category, content, source_task_id)

    @mcp.tool()
    async def recall_memories(
        project_id: str,
        category: str | None = None,
        limit: int = 10,
        ctx: Context = None,
    ) -> list[dict] | str:
        """Recall memories for a project, returning the most useful ones first.

        This increments each memory's access count, making frequently-recalled
        memories more resistant to eviction. Use this at the start of a task
        to load project context.

        Args:
            project_id: The project identifier (repo name).
            category: Filter by category (optional). One of 'env', 'pattern', 'gotcha', 'test', 'dependency', 'general'.
            limit: Maximum number of memories to return (default 10, max 50).
        """
        return await api_fn(ctx).recall_memories(project_id, category, limit)

    @mcp.tool()
    async def forget_memory(
        memory_id: int,
        ctx: Context = None,
    ) -> dict | str:
        """Delete a specific memory by ID.

        Use this to remove outdated, incorrect, or superseded memories.

        Args:
            memory_id: The numeric ID of the memory to delete.
        """
        return await api_fn(ctx).forget_memory(memory_id)

    @mcp.tool()
    async def list_memories(
        project_id: str,
        category: str | None = None,
        ctx: Context = None,
    ) -> list[dict] | str:
        """List all memories for a project (read-only, no access count increment).

        Unlike recall_memories, this does not increment access counts. Use this
        for browsing/auditing memories without affecting their eviction priority.

        Args:
            project_id: The project identifier (repo name).
            category: Filter by category (optional). One of 'env', 'pattern', 'gotcha', 'test', 'dependency', 'general'.
        """
        return await api_fn(ctx).list_memories(project_id, category)
