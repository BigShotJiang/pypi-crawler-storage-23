"""Agent memory management domain."""
