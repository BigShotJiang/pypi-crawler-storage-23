"""Pydantic models for memory endpoints."""

from __future__ import annotations

from pydantic import BaseModel, Field


class MemoryResponse(BaseModel):
    id: int
    project_id: str
    category: str
    content: str
    source_task_id: int | None = None
    access_count: int
    created_at: str
    updated_at: str


class CreateMemoryRequest(BaseModel):
    category: str = "general"
    content: str = Field(..., max_length=500)
    source_task_id: int | None = None


class RecallMemoriesRequest(BaseModel):
    category: str | None = None
    limit: int = Field(default=10, ge=1, le=50)
