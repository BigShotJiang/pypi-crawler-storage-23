"""API client methods for work logs."""

from __future__ import annotations

from peon_mcp.common.base_client import BaseAPIClient


class WorkLogClient(BaseAPIClient):
    """Work log API client methods."""

    async def log_work(
        self,
        task_id: int,
        project_id: str,
        summary: str,
        files_changed: str = "",
        test_result: str = "",
    ) -> dict | str:
        return await self._request(
            "POST", f"/api/projects/{project_id}/logs",
            json={
                "task_id": task_id,
                "summary": summary,
                "files_changed": files_changed,
                "test_result": test_result,
            },
        )

    async def list_work_logs(
        self,
        task_id: int | None = None,
        project_id: str | None = None,
    ) -> list[dict] | str:
        # Route to the most specific endpoint available
        if task_id is not None:
            return await self._request("GET", f"/api/tasks/{task_id}/logs")
        if project_id is not None:
            return await self._paginate_all(f"/api/projects/{project_id}/logs")
        # Neither filter: not supported by REST, return empty
        return []
