"""MCP tool registrations for work logs."""

from mcp.server.fastmcp import Context


def register_tools(mcp, api_fn):
    @mcp.tool()
    async def log_work(
        task_id: int,
        project_id: str,
        summary: str,
        files_changed: str = "",
        test_result: str = "",
        ctx: Context = None,
    ) -> dict | str:
        """Log the results of work done on a task.

        Call this after completing (or attempting) a task to create an auditable
        record of what was done.

        Args:
            task_id: The numeric ID of the task this work relates to.
            project_id: The project identifier (repo name).
            summary: A concise description of what was done, what changed, and the outcome.
            files_changed: Comma-separated list of files that were added, modified, or deleted.
            test_result: Overall test suite result — 'pass', 'fail', or 'skip'. Leave empty if tests were not run.
        """
        return await api_fn(ctx).log_work(task_id, project_id, summary, files_changed, test_result)

    @mcp.tool()
    async def list_work_logs(
        task_id: int | None = None,
        project_id: str | None = None,
        ctx: Context = None,
    ) -> list[dict]:
        """List work logs, optionally filtered by task or project.

        Args:
            task_id: Filter to logs for a specific task (optional).
            project_id: Filter to logs for a specific project (optional).
        """
        return await api_fn(ctx).list_work_logs(task_id, project_id)
