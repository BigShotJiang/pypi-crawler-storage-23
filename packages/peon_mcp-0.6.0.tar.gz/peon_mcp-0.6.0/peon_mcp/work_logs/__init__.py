"""Work log management domain."""
