"""Pydantic models for work log endpoints."""

from __future__ import annotations

from pydantic import BaseModel


class WorkLogResponse(BaseModel):
    id: int
    task_id: int
    project_id: str
    summary: str
    files_changed: str
    test_result: str
    created_at: str


class CreateWorkLogRequest(BaseModel):
    task_id: int
    summary: str
    files_changed: str = ""
    test_result: str = ""
