"""Work log REST API routes."""

from fastapi import APIRouter, Depends, HTTPException, Query

from peon_mcp.common.dependencies import get_db
from peon_mcp.common.schemas import PaginatedResponse
from peon_mcp.db import row_to_dict
from peon_mcp.work_logs.schemas import CreateWorkLogRequest, WorkLogResponse

router = APIRouter(tags=["Work Logs"])


@router.get("/api/projects/{project_id}/logs", response_model=PaginatedResponse[WorkLogResponse])
async def list_work_logs(
    project_id: str,
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    db=Depends(get_db),
):
    # Get total count for pagination metadata
    count_rows = await db.execute_fetchall(
        "SELECT COUNT(*) FROM work_logs WHERE project_id = ?",
        (project_id,),
    )
    total = count_rows[0][0] if count_rows else 0

    rows = await db.execute_fetchall(
        "SELECT * FROM work_logs WHERE project_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?",
        (project_id, limit, offset),
    )
    items = [row_to_dict(r) for r in rows]

    return {
        "items": items,
        "total": total,
        "limit": limit,
        "offset": offset,
        "has_next": (offset + len(items)) < total,
    }


@router.get("/api/tasks/{task_id}/logs", response_model=list[WorkLogResponse])
async def list_task_work_logs(task_id: int, db=Depends(get_db)):
    """List work logs for a specific task."""
    rows = await db.execute_fetchall(
        "SELECT * FROM work_logs WHERE task_id = ? ORDER BY created_at DESC",
        (task_id,),
    )
    return [row_to_dict(r) for r in rows]


@router.post("/api/projects/{project_id}/logs", response_model=WorkLogResponse, status_code=201)
async def create_work_log(project_id: str, body: CreateWorkLogRequest, db=Depends(get_db)):
    task_id = body.task_id
    summary = body.summary.strip()
    if not summary:
        raise HTTPException(400, detail="task_id and summary are required")
    cursor = await db.execute(
        "INSERT INTO work_logs (task_id, project_id, summary, files_changed, test_result) VALUES (?, ?, ?, ?, ?)",
        (task_id, project_id, summary, body.files_changed, body.test_result),
    )
    await db.commit()
    rows = await db.execute_fetchall(
        "SELECT * FROM work_logs WHERE id = ?", (cursor.lastrowid,)
    )
    return row_to_dict(rows[0])
