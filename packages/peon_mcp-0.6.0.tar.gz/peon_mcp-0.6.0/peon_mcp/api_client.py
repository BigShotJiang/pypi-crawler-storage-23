"""HTTP client that delegates MCP tool calls to the peon-ui REST API.

This module provides PeonAPIClient, a thin async HTTP client that maps
all MCP server tools to their corresponding REST API endpoints.

Convention: methods return ``dict`` on success and ``str`` on error,
matching the MCP tool return convention.

The aggregated client is built dynamically from auto-discovered feature
clients so that new feature domains register automatically.
"""

from __future__ import annotations

from peon_mcp.common.base_client import BaseAPIClient, _get_base_url, _get_api_key  # noqa: F401
from peon_mcp.discovery import discover_client_classes

_client_classes = discover_client_classes()

PeonAPIClient = type(
    "PeonAPIClient",
    tuple(_client_classes) or (BaseAPIClient,),
    {
        "__doc__": (
            "Async HTTP client for the peon-ui REST API.\n\n"
            "Aggregates all feature-specific client classes via multiple inheritance.\n"
            "All methods share a single httpx connection from BaseAPIClient."
        ),
    },
)
