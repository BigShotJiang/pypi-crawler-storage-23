"""Generic response models shared across feature domains."""

from __future__ import annotations

from typing import Generic, TypeVar

from pydantic import BaseModel


T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    items: list[T]
    total: int
    limit: int
    offset: int
    has_next: bool


class OkResponse(BaseModel):
    ok: bool


class SuccessResponse(BaseModel):
    success: bool


class BulkUpdateResponse(BaseModel):
    updated: int
