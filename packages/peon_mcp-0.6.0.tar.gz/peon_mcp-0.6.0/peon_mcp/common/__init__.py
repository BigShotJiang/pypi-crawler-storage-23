"""Shared utilities, constants, and base classes."""
