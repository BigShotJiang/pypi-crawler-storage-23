"""FastAPI dependency functions."""

from fastapi import Request


async def get_db(request: Request):
    """Dependency to get the shared DB connection."""
    return request.app.state.db
