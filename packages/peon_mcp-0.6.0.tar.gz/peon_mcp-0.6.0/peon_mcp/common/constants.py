"""Validation constant sets shared across the application."""

import os

# Valid status values for features
VALID_FEATURE_STATUSES = {'planned', 'in_progress', 'done', 'cancelled'}

# Valid status values for tasks
VALID_TASK_STATUSES = {'grooming', 'todo', 'in_progress', 'done', 'cancelled', 'timeout'}

# Valid priority values for tasks
VALID_PRIORITIES = {'low', 'medium', 'high', 'critical'}

# Valid severity values for review findings
VALID_SEVERITIES = {'critical', 'high', 'medium', 'low', 'info'}

# Valid perspective values for reviews
VALID_PERSPECTIVES = {'security', 'maintainability', 'performance', 'architecture', 'testing', 'reliability'}

# Valid category values for peon memories
VALID_MEMORY_CATEGORIES = {'env', 'pattern', 'gotcha', 'test', 'dependency', 'general'}

# Maximum number of memories per project (eviction threshold)
MAX_MEMORIES_PER_PROJECT = 50

# Discord bot token — read from environment, used as fallback when not stored in DB
DISCORD_BOT_TOKEN: str = os.environ.get("DISCORD_BOT_TOKEN", "")
