"""Pydantic models for system endpoints."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class SystemInfoResponse(BaseModel):
    db_path: str
    version: str


class LoopsResponse(BaseModel):
    active_count: int
    loops: list[dict[str, Any]]
