"""System endpoints (health, system-info, loops)."""
