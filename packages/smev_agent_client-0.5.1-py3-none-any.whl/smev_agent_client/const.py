# coding: utf-8


DEFAULT_REQUEST_TIMEOUT = 300  # Таймаут запроса, секунд
DEFAULT_REQUEST_RETRIES = 5  # Количество повторных попыток
DEFAULT_RETRY_FACTOR = 1  # Шаг увеличения задержки м.д. запросами
