"""Allow running the MCP server as a module: python -m aimemory.mcp"""

from aimemory.mcp.server import main

main()
