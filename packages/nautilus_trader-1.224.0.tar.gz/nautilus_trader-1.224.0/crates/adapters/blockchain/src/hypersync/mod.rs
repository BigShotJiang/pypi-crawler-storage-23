// -------------------------------------------------------------------------------------------------
//  Copyright (C) 2015-2026 Nautech Systems Pty Ltd. All rights reserved.
//  https://nautechsystems.io
//
//  Licensed under the GNU Lesser General Public License Version 3.0 (the "License");
//  You may not use this file except in compliance with the License.
//  You may obtain a copy of the License at https://www.gnu.org/licenses/lgpl-3.0.en.html
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
// -------------------------------------------------------------------------------------------------

//! HyperSync client integration for efficient blockchain data indexing.
//!
//! This module provides a client interface for [HyperSync](https://envio.dev/#hypersync),
//! a high-performance blockchain data indexing service that enables efficient querying
//! of historical blockchain data across multiple networks.

pub mod client;
pub mod helpers;
pub mod transform;

/// Type alias for HyperSync log entries.
pub type HypersyncLog = hypersync_client::simple_types::Log;
