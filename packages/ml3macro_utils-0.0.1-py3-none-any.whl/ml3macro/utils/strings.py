from functools import reduce
from typing import Tuple


def strip_margin(s: str, /) -> str:
    if not isinstance(s, str):
        raise TypeError("Input must be a string")

    lines: Tuple[str, ...] = tuple(s.splitlines())

    # Remove empty leading lines (immutable approach)
    first_non_empty_idx = next(
        (i for i, line in enumerate(lines) if line.strip()), len(lines)
    )
    trimmed_lines: Tuple[str, ...] = lines[first_non_empty_idx:]

    # Remove empty trailing lines (immutable approach)
    last_non_empty_idx = next(
        (i for i, line in enumerate(reversed(trimmed_lines)) if line.strip()),
        len(trimmed_lines),
    )
    trimmed_lines = trimmed_lines[: len(trimmed_lines) - last_non_empty_idx]

    if not trimmed_lines:
        return ""

    # Calculate margin length from first line
    first_line: str = trimmed_lines[0]
    margin_length: int = len(first_line) - len(first_line.lstrip())

    # Verify all lines have consistent margin
    for line in trimmed_lines:
        if not line:
            continue  # Skip empty lines
        if len(line) < margin_length:
            raise ValueError(
                f"Line '{line}' is shorter than margin length {margin_length}"
            )
        if line[:margin_length].strip():
            raise ValueError(f"Line '{line}' has non-whitespace in margin area")

    # Process all lines using reduce
    def process_line(acc: Tuple[str, ...], line: str) -> Tuple[str, ...]:
        return (*acc, line[margin_length:]) if line else (*acc, line)

    result_lines: Tuple[str, ...] = reduce(
        process_line, trimmed_lines[1:], (trimmed_lines[0][margin_length:],)
    )

    return "\n".join(result_lines)
