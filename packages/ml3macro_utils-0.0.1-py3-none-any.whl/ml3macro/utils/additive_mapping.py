"""This is like a frozen (immutable) dict, except that you can add new keys to it.
Not allowed: updating/deleting existing keys or their values."""

from typing import (
    Any,
    Generic,
    Hashable,
    ItemsView,
    Iterator,
    KeysView,
    Mapping,
    Self,
    TypeVar,
    ValuesView,
    overload,
)

KeyType = TypeVar("KeyType", bound=Hashable)  # Allow any hashable type as key
ValueType = TypeVar("ValueType")
_T = TypeVar("_T")


class AdditiveMapping(Generic[KeyType, ValueType], Mapping[KeyType, ValueType]):
    """An immutable mapping that allows adding new keys but not modifying existing ones.

    Once created, existing keys cannot be updated or deleted, but new keys can be
    added using the `add()` method.
    """

    __map: dict[KeyType, ValueType]

    def __init__(self, **kwargs: ValueType) -> None:
        self.__map = dict(kwargs)  # type: ignore[assignment]

    def __getitem__(self, key: KeyType, /) -> ValueType:
        return self.__map[key]

    def __len__(self) -> int:
        return len(self.__map)

    def __iter__(self) -> Iterator[KeyType]:
        return iter(self.__map)

    @overload
    def get(self, __key: KeyType) -> ValueType | None: ...

    @overload
    def get(self, __key: KeyType, __default: ValueType) -> ValueType: ...

    @overload
    def get(self, __key: KeyType, __default: _T) -> ValueType | _T: ...

    def get(self, __key: KeyType, __default: Any = None) -> ValueType | Any:
        """Return the value for key if key is in the mapping, else default."""
        return self.__map.get(__key, __default)

    def add(self, remove_none_values: bool = True, **kwargs: ValueType) -> Self:
        """Add new key-value pairs to the mapping.

        Args:
            remove_none_values: If True, skip any keys with None values
            **kwargs: Key-value pairs to add

        Returns:
            Self for method chaining

        Raises:
            KeyError: If any key already exists
        """
        self.append(kwargs, remove_none_values=remove_none_values)
        return self

    def append(
        self,
        additional_mappings: Mapping[KeyType, ValueType] | dict[Any, ValueType],
        /,
        *,
        remove_none_values: bool = True,
    ) -> None:
        """Append new key-value pairs from another mapping.

        Args:
            additional_mappings: Mapping containing key-value pairs to add
            remove_none_values: If True, skip any keys with None values

        Raises:
            KeyError: If any key already exists
        """
        kvs_to_add = (
            additional_mappings
            if not remove_none_values
            else {k: v for k, v in additional_mappings.items() if v is not None}
        )
        keys_to_add = kvs_to_add.keys()
        conflicting_keys = [k for k in keys_to_add if k in self.__map]
        if conflicting_keys:
            raise KeyError(
                f"{type(self).__qualname__} cannot update existing keys (but new keys can be added). "
                f"Conflicting keys: {', '.join(str(k) for k in conflicting_keys)}"
            )
        self.__map.update(kvs_to_add)

    def __setitem__(self, key: KeyType, value: ValueType) -> None:
        """Prevent direct item assignment."""
        raise TypeError(
            f"'{type(self).__name__}' object does not support item assignment"
        )

    def __delitem__(self, key: KeyType) -> None:
        """Prevent item deletion."""
        raise TypeError(
            f"'{type(self).__name__}' object does not support item deletion"
        )

    def keys(self) -> KeysView[KeyType]:
        """Return a list of keys in the mapping."""
        return KeysView(self.__map)

    def values(self) -> ValuesView[ValueType]:
        """Return a list of values in the mapping."""
        return ValuesView(self.__map)

    def items(self) -> ItemsView[KeyType, ValueType]:
        """Return a list of (key, value) pairs in the mapping."""
        return ItemsView(self.__map)
