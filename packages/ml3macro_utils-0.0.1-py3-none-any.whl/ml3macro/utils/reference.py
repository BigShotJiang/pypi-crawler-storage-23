"""Utility functions for working with Python object references"""

from functools import partial
from typing import Any


def fully_qualified_name(obj: Any) -> str:
    """Get the fully qualified name of a Python object (module.class)."""

    # ------------------------------------------------------------------
    # Partial functions (explicitly not supported)
    # ------------------------------------------------------------------
    if isinstance(obj, partial):
        raise ValueError("Partial functions are not supported")

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------
    if isinstance(obj, property):
        # The getter (`fget`) carries the real qualified name.
        fget = getattr(obj, "fget", None)
        if (
            fget is not None
            and hasattr(fget, "__module__")
            and hasattr(fget, "__qualname__")
        ):
            return f"{fget.__module__}.{fget.__qualname__}"
        raise ValueError(f"Cannot determine FQN for property {obj}")

    # ------------------------------------------------------------------
    # Modules
    # ------------------------------------------------------------------
    if hasattr(obj, "__name__") and not hasattr(obj, "__qualname__"):
        # Built‑in modules (e.g. sys, os, math) – just the name
        if getattr(obj, "__name__", "").startswith(("builtins", "sys", "os", "math")):
            return str(obj.__name__)
        return str(obj.__name__)

    # ------------------------------------------------------------------
    # Primitive values – not supported
    # ------------------------------------------------------------------
    if obj is None or isinstance(obj, (int, float, str, bool, list, dict, tuple, set)):
        raise ValueError(
            f"Cannot get FQN for primitive value: {obj}. "
            f"Pass the class attribute descriptor instead, e.g., Parent.attr1"
        )

    # ------------------------------------------------------------------
    # Lambda functions
    # ------------------------------------------------------------------
    if getattr(obj, "__name__", None) == "<lambda>":
        raise ValueError("Cannot get FQN for lambda function")

    # ------------------------------------------------------------------
    # Bound methods – reject instance methods, allow class/static methods
    # ------------------------------------------------------------------
    if hasattr(obj, "__self__"):
        if getattr(obj, "__module__", None) == "builtins":
            # built‑in function – keep going
            pass
        elif obj.__self__ is not None and not isinstance(obj.__self__, type):
            raise ValueError("Cannot get FQN for bound method")
        # staticmethod / classmethod – continue

    # ------------------------------------------------------------------
    # Objects without __module__ / __qualname__
    # ------------------------------------------------------------------
    if not hasattr(obj, "__module__") or not hasattr(obj, "__qualname__"):
        raise ValueError(
            f"Object {obj} does not have __module__ and __qualname__ attributes"
        )

    module = obj.__module__
    qualname = obj.__qualname__
    if not module or not qualname:
        raise ValueError(f"Object {obj} has empty __module__ or __qualname__")
    return f"{module}.{qualname}"
