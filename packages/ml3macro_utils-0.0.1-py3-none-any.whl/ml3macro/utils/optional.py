"""Optional value handling utilities with clear callable behavior documentation.

Callable Handling Guidelines:
1. PREFER returning values from getters when possible
2. ONLY return callables when you specifically want deferred execution
3. ALWAYS document when getters return callables
4. CONSIDER using type hints to clarify callable intent
"""

from typing import Callable, Optional, TypeVar

ValueType = TypeVar("ValueType")
Object = TypeVar("Object")


def _get_default(
    default: ValueType | Callable[[], ValueType],
) -> ValueType:
    """Get the default value, calling callable defaults if needed."""
    if callable(default):
        return default()
    return default


def get_or_else(
    value: Optional[ValueType],
    default: ValueType | Callable[[], ValueType],
) -> ValueType:
    """Return the value if not None, otherwise return the default.

    Args:
        value: The value to check (returns this if not None)
        default: Value or callable to return if value is None

    Returns:
        The value if not None, otherwise the default (calling callable defaults)

    Example:
        >>> get_or_else("value", "default")
        "value"
        >>> get_or_else(None, lambda: "computed")
        "computed"
    """
    if value is None:
        return _get_default(default)
    return value


def obj_get_or_else(
    obj: Optional[Object],
    get_value: Callable[[Object], Optional[ValueType]],
    default: ValueType | Callable[[], ValueType],
) -> ValueType:
    """Retrieve a value from an object or return a default.

    Important Behavior Notes:
    1. Callable Defaults: If default is callable, it's called when needed
    2. Getter Results: The getter's return value is returned AS-IS
       - If getter returns a callable, YOU must decide whether to call it
       - This function does NOT automatically call callables returned by getters
    3. None Handling: Returns default if obj is None OR getter returns None

    Example Patterns:
    Pattern A - Getter returns values (most common):
        >>> result = obj_get_or_else(person, lambda p: p.name, "Unknown")
        >>> # result is a string, no calling needed

    Pattern B - Getter returns callables (advanced):
        >>> result = obj_get_or_else(config, lambda c: c.loader, default_loader)
        >>> # result might be callable - check before using!
        >>> final_value = result() if callable(result) else result

    Args:
        obj: The object to extract value from (None returns default)
        get_value: Function that extracts value from obj (returns None uses default)
        default: Value or callable to return when obj/value is None

    Returns:
        The extracted value, or default value/callable result

    Example:
        >>> class Person:
        ...     def __init__(self, name):
        ...         self.name = name
        >>> person = Person("Alice")
        >>> obj_get_or_else(person, lambda p: p.name, "Unknown")
        "Alice"
        >>> obj_get_or_else(None, lambda p: p.name, "Unknown")
        "Unknown"
    """
    if obj is None:
        return _get_default(default)
    value = get_value(obj)
    if value is None:
        return _get_default(default)
    return value
