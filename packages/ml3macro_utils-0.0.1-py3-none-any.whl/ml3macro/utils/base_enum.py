from enum import StrEnum


class BaseML3MacroStrEnum(StrEnum): ...
