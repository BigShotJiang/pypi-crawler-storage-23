class Agent:
    def __init__(self, name:str, pomp):
        self.name = name
        self.pomp = pomp