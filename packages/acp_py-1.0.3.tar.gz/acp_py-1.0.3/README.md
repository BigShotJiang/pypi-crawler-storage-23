# acp-py

Python Agent SDK - 基于 WebSocket 的智能体通信库

## 安装

```bash
pip install acp-py
```

## 快速开始

### 启动 Agent

```bash
# 直接启动（使用默认配置）
acp-py

# 指定 Agent 名称
acp-py -n my_agent

# 启用调试模式
acp-py --debug

# 指定目标 Agent（可直接发送消息）
acp-py -t target_agent.aid.pub
```

### 交互命令

启动后可以使用以下命令：

| 命令 | 说明 |
|------|------|
| `/target <aid>` | 设置目标 Agent |
| `/session` | 显示当前会话信息 |
| `/aid` | 显示本机 AID |
| `/help` | 显示帮助 |
| `/quit` | 退出 |
| 其他输入 | 发送消息给目标 |

## CLI 参数

```bash
acp-py [选项]

选项:
  -d, --data <path>    数据目录 (默认: ./acp-data)
  -p, --password <pwd> 种子密码
  -n, --name <name>    Agent 名称
  -t, --target <aid>   目标 Agent AID
  --ap <address>       AP 地址 (默认: aid.pub)
  --debug              启用调试模式
```

## 自定义 Agent 开发

```python
from agentcp import AgentCP

# 创建 AgentCP 实例
acp = AgentCP("./data", seed_password="your_password", debug=True)

# 创建 Agent
aid = acp.create_aid(ap="aid.pub", agent_name="my_agent")
print(f"Agent AID: {aid.id}")

# 注册消息处理器
async def handle_message(data):
    print(f"收到消息: {data}")

aid.add_message_handler(handle_message)

# 上线
aid.online()

# 发送消息
session_id = aid.create_session("my_session", "测试会话")
aid.invite_member(session_id, "target_agent.aid.pub")
aid.send_message(session_id, ["target_agent.aid.pub"], "Hello!")

# 保持运行
acp.serve_forever()
```

## 系统要求

- Python >= 3.8

## 平台支持

- macOS
- Linux
- Windows

## License

MIT
