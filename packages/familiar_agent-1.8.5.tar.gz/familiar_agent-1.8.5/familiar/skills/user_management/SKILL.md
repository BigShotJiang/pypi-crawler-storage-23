# User Management Skill

Create, update, list, and deactivate user accounts.
Foundation for multi-user nonprofit teams.

## Roles (from core)

- **admin**: Full access, manage users, configure system
- **staff**: Normal access, own data, assigned skills
- **readonly**: View only, no write actions

## Extended Roles (added by RBAC skill)

- **editor**: Write access to assigned skills, no user management
- **auditor**: Read-only + audit trail + compliance reports
- **volunteer**: Limited access to specific tasks/contacts

## HIPAA Relevance

- §164.312(a)(1): Unique user identification
- §164.312(d): Person or entity authentication
- §164.308(a)(3): Workforce security
