# Google Drive Skill - Clio, Muse of History

*Clio was the Muse who recorded and preserved the great deeds of history. She keeps your archives organized and accessible.*

Search, read, and manage files in Google Drive.

## Setup

Uses same Google OAuth credentials as Calendar skill.
Enable the Google Drive API in your Google Cloud Console.

## Usage

- "Find the Q4 budget spreadsheet"
- "What's in the Board Meeting folder?"
- "Download the grant report PDF"
- "Search Drive for volunteer forms"
- "Upload this file to the Grants folder"

## Capabilities

- Search files by name or content
- List folder contents
- Read Google Docs content
- Download files
- Upload files
- Create folders

## Notes

- First run will prompt for additional permissions
- Can read Google Docs/Sheets directly without downloading
- PDFs and other files are downloaded for reading
