# Audit Trail Skill

Log and query every data access, tool invocation, and configuration change.
Required for HIPAA §164.312(b) audit controls.

## Usage

- Log events: tool executions, data access, config changes, auth events
- Search audit log by date, user, action, severity
- Generate compliance reports for auditors
- Track data access per record (who viewed what, when)
- Export tamper-evident audit trail (hash-chained)

## Architecture

Wraps core/audit.py AuditStore (SQLite-backed, hash-chained).
Every entry includes timestamp, user, action, resource, severity,
IP address, and a SHA-256 chain hash for tamper detection.

## HIPAA Requirements Met

- §164.312(b): Audit controls on information systems
- §164.308(a)(1)(ii)(D): Information system activity review
- §164.312(c)(2): Mechanism to authenticate electronic PHI
