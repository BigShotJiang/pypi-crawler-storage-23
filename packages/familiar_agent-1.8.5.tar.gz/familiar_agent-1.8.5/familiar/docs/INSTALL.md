# Install Familiar

## Pi / Linux / Mac

```bash
# 1. Extract
unzip familiar-v1_0_3.zip
cd familiar

# 2. Run installer
chmod +x install.sh
FAMILIAR_ZIP=../familiar-v1_0_3.zip ./install.sh

# 3. Set API key (pick one)
export ANTHROPIC_API_KEY="sk-ant-..."   # Claude
export OPENAI_API_KEY="sk-..."          # GPT-4
# Or use Ollama (free, local): ollama pull llama3.2

# 4. Start
~/.familiar/bin/familiar
```

## Run as Service

```bash
# Linux (systemd)
sudo systemctl start familiar
sudo systemctl status familiar

# View logs
journalctl -u familiar -f
```

## Commands

```bash
familiar                # Interactive CLI
familiar --telegram     # Telegram bot
familiar --dashboard    # Web UI at localhost:5000
```

## Files

```
~/.familiar/
├── config.yaml        # Configuration
├── .env               # API keys (chmod 600)
├── data/              # Memory, history
├── secure/            # Encryption keys
└── app/               # Familiar code
```

## Telegram Setup

1. Message @BotFather on Telegram
2. Create bot, get token
3. Add to config:

```yaml
# ~/.familiar/config.yaml
channels:
  telegram_enabled: true
  telegram_token: "123456:ABC..."
  telegram_allowed_users: [your_telegram_id]
```

## Mesh Networking (Multi-Pi)

```yaml
# Gateway node (central Pi)
mesh:
  enabled: true
  role: gateway
  gateway_port: 18789

# Client nodes (other Pis)
mesh:
  enabled: true
  role: node
  gateway_url: ws://gateway-pi:18789
```

All traffic is Signal-grade encrypted (X3DH + Double Ratchet).

## Support

- Config: `~/.familiar/config.yaml`
- Logs: `journalctl -u familiar -f`
- Issues: github.com/familiar-ai/familiar/issues
