"""Entry point: python -m familiar.onboard"""

from familiar.onboard.google_setup import main

main()
