import sys
import click

from tai_sql import pm
from ..utils import verify_server_connection, createdb, createschema
from ...services import DriftManager
from ...services.feed import FeedRunner


@click.command()
@click.option('--schema', '-s', help='Nombre del esquema')
@click.option('--table', '-t', help='Nombre de la tabla específica a alimentar')
@click.option('--clean', is_flag=True, help='Limpiar (TRUNCATE CASCADE) las tablas antes de alimentar')
@click.option('--dry-run', '-d', is_flag=True, help='Mostrar qué se insertaría sin ejecutar')
@click.option('--force', '-f', is_flag=True, help='Ejecutar feed incluso si hay cambios pendientes')
@click.option('--verbose', '-v', is_flag=True, help='Mostrar información detallada durante la ejecución')
def feed(schema: str = None, table: str = None, clean: bool = False, dry_run: bool = False, force: bool = False, verbose: bool = False):
    """Alimenta las tablas del esquema con datos iniciales"""

    if schema:
        pm.set_current_schema(schema)

    if not schema and not pm.db:
        click.echo(f"❌ No existe ningún esquema por defecto", err=True)
        click.echo(f"   Puedes definir uno con: tai-sql set-default-schema <nombre>", err=True)
        click.echo(f"   O usar la opción: --schema <nombre_esquema>", err=True)
        sys.exit(1)

    try:
        click.echo()
        click.echo(f"🌱 Feed schema: {pm.db.schema_name}")
        click.echo()

        if not verify_server_connection(pm.db.provider.host, pm.db.provider.port):
            sys.exit(1)

        createdb(pm.db.provider.database)
        createschema(pm.db.schema_name)

        click.echo()

        # ── Drift check ──────────────────────────────
        drift = DriftManager()
        drift.run()

        click.echo()

        if drift.has_changes:
            drift.show()
            click.echo("⚠️  Hay cambios pendientes de sincronizar con la base de datos.", err=True)
            click.echo("   Ejecuta 'tai-sql push' antes de alimentar la base de datos.", err=True)

            if not force:
                click.echo("   Usa --force para ejecutar el feed de todas formas.", err=True)
                sys.exit(1)
            else:
                click.echo("   Continuando con --force...")

            click.echo()
        
        else:
            click.echo("✅ No se detectaron cambios pendientes. Continuando con el feed...")
            click.echo()

        # ── Feed ─────────────────────────────────────
        runner = FeedRunner(
            engine=pm.db.engine,
            schema_name=pm.db.schema_name,
            driver=pm.db.driver,
            tables=pm.db.tables,
        )

        runner.discover(table_filter=table)

        if not runner.feeds:
            click.echo("📭 No se encontraron métodos feed() en ningún modelo")
            return

        runner.show(verbose)

        if dry_run:
            click.echo()
            click.echo("🔍 Modo dry-run: no se ejecutaron cambios")
            return

        click.echo()

        if clean:
            runner.clean()
            click.echo()

        click.echo("🚀 Ejecutando feeds...")
        click.echo()
        runner.execute()

        click.echo()
        click.echo("✅ Feed completado exitosamente")

    except Exception as e:
        click.echo(f"❌ Error durante feed: {e}", err=True)
        sys.exit(1)
