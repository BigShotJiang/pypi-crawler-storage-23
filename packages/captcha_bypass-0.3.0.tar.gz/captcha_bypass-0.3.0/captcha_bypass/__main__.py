"""Entry point for `python -m captcha_bypass`."""

from captcha_bypass.cli import main

if __name__ == "__main__":
    main()
