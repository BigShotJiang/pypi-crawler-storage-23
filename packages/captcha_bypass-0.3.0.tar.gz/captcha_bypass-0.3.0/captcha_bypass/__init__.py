"""Captcha bypass service with HTTP API."""

from importlib.metadata import version

__version__ = version("captcha-bypass")
