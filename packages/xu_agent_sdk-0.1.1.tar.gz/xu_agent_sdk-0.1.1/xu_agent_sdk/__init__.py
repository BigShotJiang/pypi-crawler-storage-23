"""
xu-agent-sdk: Python SDK for 1xu Trading Signals
=================================================
Connect your autonomous agent to 1xu's whale intelligence signals.

Installation:
    pip install xu-agent-sdk

Quick Start:
    from xu_agent_sdk import XuAgent

    agent = XuAgent(api_key="1xu_your_key_here")
    
    # Get signals
    signals = await agent.get_signals(limit=10)
    
    # Report trade
    await agent.report_trade(
        signal_id=signals[0]['id'],
        market_id=signals[0]['market_id'],
        direction='yes',
        size_usd=100,
        entry_price=0.65
    )

Documentation: https://1xu.app/docs/sdk
"""

__version__ = "0.1.0"
__author__ = "1xu Team"

from .client import XuAgent, XuSignal
from .exceptions import (
    XuError,
    XuAuthError,
    XuRateLimitError,
    XuPaymentRequiredError,
)

__all__ = [
    "XuAgent",
    "XuSignal",
    "XuError",
    "XuAuthError", 
    "XuRateLimitError",
    "XuPaymentRequiredError",
]
