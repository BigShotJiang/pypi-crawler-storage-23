"""
xu-agent-sdk Exceptions
"""


class XuError(Exception):
    """Base exception for xu-agent-sdk"""
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response or {}


class XuAuthError(XuError):
    """Authentication failed - invalid or missing API key"""
    pass


class XuRateLimitError(XuError):
    """Rate limit exceeded - too many requests"""
    def __init__(self, message: str, retry_after: int = 60, **kwargs):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class XuPaymentRequiredError(XuError):
    """Payment required - need to upgrade tier or add funds"""
    def __init__(self, message: str, pricing: dict = None, **kwargs):
        super().__init__(message, **kwargs)
        self.pricing = pricing or {}


class XuSignalLimitError(XuError):
    """Daily signal limit exceeded"""
    def __init__(self, message: str, resets_in_seconds: int = 0, **kwargs):
        super().__init__(message, **kwargs)
        self.resets_in_seconds = resets_in_seconds


class XuConnectionError(XuError):
    """Network connection error"""
    pass


class XuValidationError(XuError):
    """Invalid input parameters"""
    pass
