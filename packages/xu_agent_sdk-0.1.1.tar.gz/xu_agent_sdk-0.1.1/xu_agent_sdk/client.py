"""
xu-agent-sdk Client
===================
Main client for interacting with 1xu Trading Signals API.
"""

import asyncio
import aiohttp
import logging
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List, Callable, Awaitable
from dataclasses import dataclass
from enum import Enum

from .exceptions import (
    XuError,
    XuAuthError,
    XuRateLimitError,
    XuPaymentRequiredError,
    XuSignalLimitError,
    XuConnectionError,
    XuValidationError,
)

logger = logging.getLogger(__name__)


# =============================================================================
# Data Models
# =============================================================================

@dataclass
class XuSignal:
    """Represents a trading signal from 1xu"""
    id: str
    market_id: str
    market: str  # Human readable market name
    direction: str  # 'yes' or 'no'
    confidence: float  # 0-1 (computed from whale quality + market factors)
    entry_price: float  # Actual market price at entry
    suggested_size: str  # e.g., "$50-100"
    whale_score: float
    timestamp: datetime
    expires_at: Optional[datetime] = None
    category: Optional[str] = None  # e.g., 'crypto', 'politics', 'sports'
    quality_grade: Optional[str] = None  # A/B/C/D/F
    
    # Additional context
    whale_activity: Optional[Dict] = None
    market_stats: Optional[Dict] = None  # current_price, volume, price_drift, etc.
    raw: Optional[Dict] = None  # Full raw signal data (for accessing conflict, etc.)
    
    @property
    def has_conflict(self) -> bool:
        """Check if opposing signals exist on the same market (GAP 9)."""
        if self.raw and 'conflict' in self.raw:
            return bool(self.raw['conflict'].get('has_conflict', False))
        return False
    
    @property
    def conflict_info(self) -> Optional[Dict]:
        """Get conflict details if available (GAP 9)."""
        if self.raw and 'conflict' in self.raw:
            return self.raw['conflict']
        return None
    
    @property
    def side(self) -> str:
        """Alias for direction (convenience for trading logic)."""
        return self.direction
    
    @property
    def price(self) -> float:
        """Alias for entry_price (convenience for trading logic)."""
        return self.entry_price
    
    @property
    def market_title(self) -> str:
        """Alias for market (convenience for display)."""
        return self.market
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'XuSignal':
        # Extract nested signal/quality/context if present (A2A format)
        signal_block = data.get('signal', {})
        quality_block = data.get('quality', {})
        market_block = data.get('market', {})
        context_block = data.get('context', {})
        
        # Confidence: prefer signal.confidence > quality.confidence > whale_score
        confidence = float(
            signal_block.get('confidence',
            quality_block.get('confidence',
            data.get('confidence',
            data.get('whale_score', 0.5))))
        )
        
        # Entry price: prefer signal.entry_price > price
        entry_price = float(
            signal_block.get('entry_price',
            data.get('entry_price',
            data.get('price', 0)))
        )
        
        # Build market_stats from context block
        market_stats = data.get('market_stats')
        if context_block and not market_stats:
            market_stats = {
                'current_price': context_block.get('current_price'),
                'signal_age_seconds': context_block.get('signal_age_seconds', 0),
                'price_drift_pct': context_block.get('price_drift_pct', 0),
                'market_volume_24h': context_block.get('market_volume_24h'),
                'estimated_resolution': context_block.get('estimated_resolution', ''),
                'agents_received': context_block.get('agents_received', 0),
            }
        
        return cls(
            id=data.get('id', data.get('_id', data.get('signal_id', ''))),
            market_id=data.get('market_id', market_block.get('condition_id', data.get('condition_id', ''))),
            market=market_block.get('title', data.get('market', data.get('question', ''))),
            direction=signal_block.get('direction', data.get('direction', data.get('action', 'yes'))).lower(),
            confidence=confidence,
            entry_price=entry_price,
            suggested_size=signal_block.get('suggested_size_usd', data.get('suggested_size', '$50-100')),
            whale_score=float(quality_block.get('whale_score', data.get('whale_score', 0.5))),
            timestamp=datetime.fromisoformat(data['timestamp'].replace('Z', '+00:00')) if data.get('timestamp') else datetime.now(timezone.utc),
            expires_at=datetime.fromisoformat(data['expires_at'].replace('Z', '+00:00')) if data.get('expires_at') else None,
            category=market_block.get('category', data.get('category')),
            quality_grade=quality_block.get('grade', data.get('quality_grade')),
            whale_activity=data.get('whale_activity') or data.get('whale'),
            market_stats=market_stats,
            raw=data,  # Preserve full signal for conflict/context access
        )
    
    def to_dict(self) -> Dict:
        result = {
            'id': self.id,
            'market_id': self.market_id,
            'market': self.market,
            'direction': self.direction,
            'confidence': self.confidence,
            'entry_price': self.entry_price,
            'suggested_size': self.suggested_size,
            'whale_score': self.whale_score,
            'timestamp': self.timestamp.isoformat(),
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'category': self.category,
            'quality_grade': self.quality_grade,
        }
        if self.market_stats:
            result['market_stats'] = self.market_stats
        return result


class TradeStatus(Enum):
    SKIPPED = 'skipped'
    EXECUTED = 'executed'
    FAILED = 'failed'
    CLOSED = 'closed'


# =============================================================================
# Main Client
# =============================================================================

class XuAgent:
    """
    Client for 1xu Trading Signals API.
    
    Example:
        agent = XuAgent(api_key="1xu_your_key")
        
        # Get latest signals
        signals = await agent.get_signals(limit=10)
        
        # Stream signals in real-time
        async for signal in agent.stream_signals():
            print(f"New signal: {signal.market} -> {signal.direction}")
    """
    
    BASE_URL = "https://1xu.app"
    
    def __init__(
        self,
        api_key: str,
        base_url: str = None,
        timeout: int = 30,
        auto_ack: bool = True,
    ):
        """
        Initialize the 1xu Agent client.
        
        Args:
            api_key: Your 1xu API key (get one at https://1xu.app/agent-dashboard)
            base_url: Override the base URL (for testing)
            timeout: Request timeout in seconds
            auto_ack: Automatically acknowledge signals when received
        """
        if not api_key or not api_key.startswith('1xu_'):
            raise XuValidationError("Invalid API key format. Expected '1xu_...'")
        
        self.api_key = api_key
        self.base_url = (base_url or self.BASE_URL).rstrip('/')
        self.timeout = timeout
        self.auto_ack = auto_ack
        
        self._session: Optional[aiohttp.ClientSession] = None
        self._agent_id: Optional[str] = None
        self._tier: Optional[str] = None
        
        # Callbacks
        self._on_signal: Optional[Callable[[XuSignal], Awaitable[None]]] = None
        self._on_error: Optional[Callable[[Exception], Awaitable[None]]] = None
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create HTTP session"""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self.timeout),
                headers={
                    'X-API-Key': self.api_key,
                    'User-Agent': f'xu-agent-sdk/0.1.0',
                    'Content-Type': 'application/json'
                }
            )
        return self._session
    
    async def close(self):
        """Close the client session"""
        if self._session and not self._session.closed:
            await self._session.close()
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
    
    # ============ CORE API METHODS ============
    
    async def _request(self, method: str, endpoint: str, 
                       data: Dict = None, params: Dict = None) -> Dict:
        """Make an API request"""
        session = await self._get_session()
        url = f"{self.base_url}{endpoint}"
        
        try:
            async with session.request(method, url, json=data, params=params) as resp:
                result = await resp.json()
                
                # Handle errors
                if resp.status == 401:
                    raise XuAuthError(
                        result.get('error', 'Authentication failed'),
                        status_code=401,
                        response=result
                    )
                elif resp.status == 402:
                    raise XuPaymentRequiredError(
                        result.get('error', 'Payment required'),
                        pricing=result.get('pricing'),
                        status_code=402,
                        response=result
                    )
                elif resp.status == 429:
                    raise XuRateLimitError(
                        result.get('error', 'Rate limit exceeded'),
                        retry_after=int(result.get('retry_after', 60)),
                        status_code=429,
                        response=result
                    )
                elif resp.status >= 400:
                    # Check if it's a daily limit error
                    if 'limit' in result.get('error', '').lower():
                        raise XuSignalLimitError(
                            result.get('error'),
                            resets_in_seconds=result.get('resets_in_seconds', 0),
                            status_code=resp.status,
                            response=result
                        )
                    raise XuError(
                        result.get('error', f'Request failed with status {resp.status}'),
                        status_code=resp.status,
                        response=result
                    )
                
                return result
                
        except aiohttp.ClientError as e:
            raise XuConnectionError(f"Connection error: {e}")
    
    # ============ AUTHENTICATION ============
    
    async def verify_connection(self) -> Dict:
        """
        Verify API key and get account information.
        
        Returns:
            Dict with wallet, tier, features, and limits
        """
        result = await self._request('GET', '/api/a2a/access', params={'api_key': self.api_key})
        
        self._agent_id = result.get('wallet')
        self._tier = result.get('tier')
        
        return result
    
    async def refresh_balance(self) -> Dict:
        """
        Refresh token balance and update tier if changed.
        
        Returns:
            Dict with updated tier information
        """
        return await self._request('POST', '/api/a2a/refresh-balance', params={'api_key': self.api_key})
    
    @property
    def agent_id(self) -> Optional[str]:
        """Get the agent ID (wallet address)"""
        return self._agent_id
    
    @property
    def tier(self) -> Optional[str]:
        """Get the current tier"""
        return self._tier
    
    # ============ SIGNALS ============
    
    async def get_signals(
        self,
        limit: int = 10,
        min_confidence: float = 0.5,
        direction: str = None,
    ) -> List[XuSignal]:
        """
        Get latest trading signals.
        
        Args:
            limit: Maximum number of signals to return
            min_confidence: Minimum confidence score (0-1)
            direction: Filter by direction ('yes' or 'no')
        
        Returns:
            List of XuSignal objects
        """
        params = {
            'api_key': self.api_key,
            'limit': limit,
            'min_confidence': min_confidence,
        }
        if direction:
            params['direction'] = direction
        
        result = await self._request('GET', '/api/v1/signals', params=params)
        
        signals = []
        for s in result.get('signals', []):
            signal = XuSignal.from_dict(s)
            signals.append(signal)
            
            # Auto acknowledge
            if self.auto_ack and self._agent_id:
                try:
                    await self.acknowledge_signal(signal.id, s.get('broadcast_time'))
                except Exception as e:
                    logger.warning(f"Failed to ack signal {signal.id}: {e}")
        
        return signals
    
    async def get_trial_signals(self) -> List[XuSignal]:
        """
        Get free trial signals (limited, delayed).
        
        Returns:
            List of XuSignal objects
        """
        result = await self._request('GET', '/api/v1/signals/trial')
        return [XuSignal.from_dict(s) for s in result.get('signals', [])]
    
    async def stream_signals(
        self,
        callback: Callable[[XuSignal], Awaitable[None]] = None,
        min_confidence: float = 0.5,
    ):
        """
        Stream signals in real-time (for Pro+ tiers with webhooks).
        
        This is a long-polling implementation. For true real-time,
        register a webhook endpoint.
        
        Args:
            callback: Async function to call for each signal
            min_confidence: Minimum confidence filter
        
        Yields:
            XuSignal objects as they arrive
        """
        last_signal_id = None
        
        while True:
            try:
                signals = await self.get_signals(limit=5, min_confidence=min_confidence)
                
                for signal in signals:
                    if last_signal_id and signal.id == last_signal_id:
                        break
                    
                    if callback:
                        await callback(signal)
                    else:
                        yield signal
                
                if signals:
                    last_signal_id = signals[0].id
                
                await asyncio.sleep(10)  # Poll every 10 seconds
                
            except XuRateLimitError as e:
                await asyncio.sleep(e.retry_after)
            except Exception as e:
                if self._on_error:
                    await self._on_error(e)
                else:
                    logger.error(f"Stream error: {e}")
                await asyncio.sleep(30)
    
    # ============ TRADE REPORTING ============
    
    async def acknowledge_signal(
        self,
        signal_id: str,
        broadcast_time: str = None
    ) -> Dict:
        """
        Acknowledge receipt of a signal.
        
        Args:
            signal_id: The signal ID
            broadcast_time: When the signal was broadcast (ISO format)
        
        Returns:
            Dict with latency information
        """
        return await self._request('POST', '/api/a2a/report/ack', data={
            'agent_id': self._agent_id or self.api_key,
            'signal_id': signal_id,
            'broadcast_time': broadcast_time
        })
    
    async def report_skip(
        self,
        signal_id: str,
        reason: str,
        market_id: str = None
    ) -> Dict:
        """
        Report that a signal was intentionally skipped.
        
        Args:
            signal_id: The signal ID
            reason: Why you skipped (e.g., "below_threshold", "no_liquidity")
            market_id: The market ID (optional)
        
        Returns:
            Dict with success status
        """
        return await self._request('POST', '/api/a2a/report/skip', data={
            'agent_id': self._agent_id or self.api_key,
            'signal_id': signal_id,
            'reason': reason,
            'market_id': market_id
        })
    
    async def report_failure(
        self,
        signal_id: str,
        reason: str,
        market_id: str = None
    ) -> Dict:
        """
        Report that trade execution failed.
        
        Args:
            signal_id: The signal ID
            reason: Failure reason (e.g., "insufficient_funds", "slippage")
            market_id: The market ID (optional)
        
        Returns:
            Dict with success status
        """
        return await self._request('POST', '/api/a2a/report/failure', data={
            'agent_id': self._agent_id or self.api_key,
            'signal_id': signal_id,
            'reason': reason,
            'market_id': market_id
        })
    
    async def report_trade(
        self,
        signal_id: str,
        market_id: str,
        direction: str,
        size_usd: float,
        entry_price: float,
        tx_hash: str = None,
        executed_at: datetime = None
    ) -> Dict:
        """
        Report a successful trade execution.
        
        Args:
            signal_id: The signal ID that triggered this trade
            market_id: The Polymarket condition ID
            direction: 'yes' or 'no'
            size_usd: Position size in USD
            entry_price: Entry price (0-1)
            tx_hash: Transaction hash for on-chain verification (optional)
            executed_at: Execution timestamp (optional)
        
        Returns:
            Dict with trade_id and verification status
        """
        data = {
            'agent_id': self._agent_id or self.api_key,
            'signal_id': signal_id,
            'market_id': market_id,
            'direction': direction,
            'size_usd': size_usd,
            'entry_price': entry_price,
        }
        
        if tx_hash:
            data['tx_hash'] = tx_hash
        if executed_at:
            data['executed_at'] = executed_at.isoformat()
        
        return await self._request('POST', '/api/a2a/report/trade', data=data)
    
    async def report_close(
        self,
        trade_id: str,
        exit_price: float,
        pnl_usd: float,
        tx_hash: str = None
    ) -> Dict:
        """
        Report closing a position.
        
        Args:
            trade_id: The trade ID from report_trade response
            exit_price: Exit price (0-1)
            pnl_usd: Realized profit/loss in USD
            tx_hash: Close transaction hash (optional)
        
        Returns:
            Dict with success status and is_winner flag
        """
        return await self._request('POST', '/api/a2a/report/close', data={
            'agent_id': self._agent_id or self.api_key,
            'trade_id': trade_id,
            'exit_price': exit_price,
            'pnl_usd': pnl_usd,
            'tx_hash': tx_hash
        })
    
    # ============ STATS ============
    
    async def get_my_stats(self) -> Dict:
        """
        Get your agent's performance statistics.
        
        Returns:
            Dict with win_rate, total_pnl, trade counts, etc.
        """
        agent_id = self._agent_id or self.api_key
        return await self._request('GET', f'/api/a2a/stats/{agent_id}')
    
    async def get_my_trades(self, limit: int = 50, status: str = None) -> List[Dict]:
        """
        Get your trade history.
        
        Args:
            limit: Maximum number of trades
            status: Filter by status ('executed', 'closed', 'skipped', 'failed')
        
        Returns:
            List of trade records
        """
        agent_id = self._agent_id or self.api_key
        params = {'limit': limit}
        if status:
            params['status'] = status
        
        result = await self._request('GET', f'/api/a2a/trades/{agent_id}', params=params)
        return result.get('trades', [])
    
    async def get_leaderboard(self, metric: str = 'total_pnl_usd', limit: int = 20) -> List[Dict]:
        """
        Get the agent leaderboard.
        
        Args:
            metric: Ranking metric ('total_pnl_usd', 'win_rate', 'verification_rate')
            limit: Number of entries
        
        Returns:
            List of leaderboard entries with rank
        """
        result = await self._request('GET', '/api/a2a/leaderboard', params={
            'metric': metric,
            'limit': limit
        })
        return result.get('leaderboard', [])
    
    # ============ USAGE ============
    
    async def get_usage(self) -> Dict:
        """
        Get current API usage and limits.
        
        Returns:
            Dict with signals_used, remaining, rate_limits, etc.
        """
        return await self._request('GET', '/api/v1/usage', params={'api_key': self.api_key})
    
    async def get_pricing(self) -> Dict:
        """
        Get current pricing tiers and token requirements.
        
        Returns:
            Dict with tiers, thresholds, and beta information
        """
        return await self._request('GET', '/api/a2a/tiers')
    
    # ============ WEBHOOKS ============
    
    async def register_webhook(self, url: str) -> Dict:
        """
        Register a webhook URL for real-time signal delivery.
        
        Args:
            url: Your webhook endpoint URL
        
        Returns:
            Dict with success status
        """
        return await self._request('POST', '/api/v1/webhook', data={
            'api_key': self.api_key,
            'url': url
        })


# =============================================================================
# Convenience Functions
# =============================================================================

async def quick_start(api_key: str) -> XuAgent:
    """
    Quick start helper - creates and verifies an agent.
    
    Example:
        agent = await quick_start("1xu_your_key")
        signals = await agent.get_signals()
    """
    agent = XuAgent(api_key)
    await agent.verify_connection()
    return agent
