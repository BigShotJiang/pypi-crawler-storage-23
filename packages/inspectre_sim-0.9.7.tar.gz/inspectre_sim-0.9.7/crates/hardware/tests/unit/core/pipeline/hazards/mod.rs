pub mod control_hazards;
pub mod data_forwarding;
pub mod load_use;
