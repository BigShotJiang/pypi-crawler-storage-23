pub mod decode;
pub mod execute;
pub mod fetch;
pub mod memory;
pub mod writeback;
