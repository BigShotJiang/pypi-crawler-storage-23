"""
Parameter types and validation for simulation configuration.

Reserved for shared parameter classes (e.g., size, latency) used across components.
"""
