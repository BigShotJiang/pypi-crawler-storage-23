"""Disk or block device model; reserved for Python-side disk configuration or metrics."""
