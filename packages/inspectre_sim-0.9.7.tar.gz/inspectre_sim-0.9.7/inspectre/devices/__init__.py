"""
Device models (disk, UART, etc.).

Reserved for Python-side device abstractions or configuration that map to the SoC devices.
"""
