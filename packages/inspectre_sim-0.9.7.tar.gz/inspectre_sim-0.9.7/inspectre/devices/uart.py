"""UART device model; reserved for Python-side UART configuration or introspection."""
