"""
Memory hierarchy models (bus, cache, DRAM, prefetcher, replacement policy).

Reserved for Python-side memory subsystem abstractions or configuration.
"""
