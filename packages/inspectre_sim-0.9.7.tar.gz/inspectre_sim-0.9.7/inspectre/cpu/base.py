"""Base CPU model or configuration; reserved for shared CPU abstractions."""
