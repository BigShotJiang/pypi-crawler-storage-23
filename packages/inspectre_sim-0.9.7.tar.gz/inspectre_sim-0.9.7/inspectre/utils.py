"""
Shared utilities for the RISC-V simulator Python API.

Reserved for helper functions (e.g., formatting, path handling) used across the package.
"""
