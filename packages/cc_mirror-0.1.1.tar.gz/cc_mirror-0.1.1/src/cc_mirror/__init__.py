"""CC Mirror — 从你的 Claude Code 历史中提取可自动化的模式。"""

__version__ = "0.1.1"
__author__ = "Nature"
