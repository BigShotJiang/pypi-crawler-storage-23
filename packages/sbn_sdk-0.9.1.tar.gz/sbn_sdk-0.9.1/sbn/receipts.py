"""Receipts sub-client — convenience wrapper for receipt queries."""

from __future__ import annotations

from typing import Any

from sbn._http import HttpTransport


class ReceiptsClient:
    """Convenience client for receipt queries.

    Provides a simpler interface for common receipt operations that are
    also available through ``GatewayClient.fetch_receipt()`` and
    ``SnapChoreClient.receipts_discover()``.
    """

    def __init__(self, transport: HttpTransport) -> None:
        self._t = transport

    def get(self, receipt_id: str) -> dict[str, Any]:
        """Fetch a receipt by ID.

        Endpoint: ``GET /receipts/{receipt_id}``
        """
        return self._t.get(f"/receipts/{receipt_id}").json()

    def list(
        self,
        *,
        project_id: str | None = None,
        hash: str | None = None,
        domain: str | None = None,
        limit: int = 20,
        offset: int = 0,
        since: str | None = None,
    ) -> dict[str, Any]:
        """List receipts with optional filters.

        Endpoint: ``GET /internal/snapchore/receipts/discover``

        Args:
            project_id: Scope to a specific project.
            hash: Exact receipt hash lookup.
            domain: Filter by domain (wildcard suffix OK, e.g. ``"numa.*"``).
            limit: Max entries per page (default 20, max 200).
            offset: Pagination offset.
            since: ISO-8601 cursor — only receipts created after this time.

        Returns:
            ``{"receipts": [...], "count": N, "offset": M, ...}``
        """
        params: dict[str, str] = {"limit": str(limit)}
        if offset:
            params["offset"] = str(offset)
        if since:
            params["since"] = since
        if project_id:
            params["project_id"] = project_id
        if hash:
            params["hash"] = hash
        if domain:
            params["domain"] = domain
        return self._t.get("/internal/snapchore/receipts/discover", params=params).json()
