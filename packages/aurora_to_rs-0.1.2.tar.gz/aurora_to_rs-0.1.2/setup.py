from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="aurora_to_rs",
    version="0.1.2",
    author="Ankit Goel",
    author_email="ankitgoel888@gmail.com",
    description="Lean Aurora PostgreSQL to Redshift loader via copy_expert + S3 COPY",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/ankitgoel888/aurora_to_rs",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    install_requires=[
        "boto3",
        "psycopg2",
    ],
    python_requires='>=3.8',
)
