# Episode 07-worldview: Way up here.

**This episode shows how you can use a notebook to setup a simple dashboard to
monitor all of your Metaflow flows.**

#### Showcasing:
- The Metaflow client API.

#### Before playing this episode:
1. ```python -m pip install notebook``` (only locally, if you don't have it already)

#### To play this episode:
1. Open ```07-worldview/worldview.ipynb```
