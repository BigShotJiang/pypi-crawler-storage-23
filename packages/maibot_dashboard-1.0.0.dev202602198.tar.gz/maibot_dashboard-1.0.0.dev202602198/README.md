# MaiBot WebUI Dist

该包仅包含 MaiBot WebUI 的前端构建产物（dist）。
