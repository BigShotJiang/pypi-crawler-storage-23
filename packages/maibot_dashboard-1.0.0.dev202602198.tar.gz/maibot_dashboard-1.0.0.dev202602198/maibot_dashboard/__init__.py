from .resources import get_dist_path

__all__ = ["get_dist_path"]
