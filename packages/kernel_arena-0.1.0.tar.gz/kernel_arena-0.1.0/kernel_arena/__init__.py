"""Placeholder package - name claimed on PyPI."""

__version__ = "0.1.0"
