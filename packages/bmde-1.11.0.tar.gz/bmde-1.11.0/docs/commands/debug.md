
## bmde debug 
WIP

Debugs a `.nds` file using GDB from terminal or from Insight, possibly using the run backend. 
