"""Semantic fact and schema definitions for neocortical store."""

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any


class FactCategory(StrEnum):
    """Category of semantic fact."""

    IDENTITY = "identity"
    LOCATION = "location"
    PREFERENCE = "preference"
    RELATIONSHIP = "relationship"
    OCCUPATION = "occupation"
    TEMPORAL = "temporal"
    ATTRIBUTE = "attribute"
    CUSTOM = "custom"
    # Cognitive constraint categories (LoCoMo-Plus)
    GOAL = "goal"
    STATE = "state"
    VALUE = "value"
    CAUSAL = "causal"
    POLICY = "policy"


@dataclass
class FactSchema:
    """
    Schema definition for a type of fact.
    Defines validation rules and display properties.
    """

    category: FactCategory
    key_pattern: str
    value_type: str  # "string", "number", "date", "list", "object"
    required: bool = False
    multi_valued: bool = False
    temporal: bool = False
    validators: list[str] = field(default_factory=list)
    display_name: str = ""
    description: str = ""
    examples: list[str] = field(default_factory=list)


@dataclass
class SemanticFact:
    """A structured semantic fact in the neocortical store."""

    id: str
    tenant_id: str
    category: FactCategory
    key: str
    subject: str
    predicate: str
    value: Any
    value_type: str
    context_tags: list[str] = field(default_factory=list)
    confidence: float = 0.8
    evidence_count: int = 1
    evidence_ids: list[str] = field(default_factory=list)
    valid_from: datetime | None = None
    valid_to: datetime | None = None
    is_current: bool = True
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    version: int = 1
    supersedes_id: str | None = None


DEFAULT_FACT_SCHEMAS: dict[str, FactSchema] = {
    "user:identity:name": FactSchema(
        category=FactCategory.IDENTITY,
        key_pattern="user:identity:name",
        value_type="string",
        display_name="User's Name",
        description="The user's preferred name",
        examples=["John", "Dr. Smith"],
    ),
    "user:location:current_city": FactSchema(
        category=FactCategory.LOCATION,
        key_pattern="user:location:current_city",
        value_type="string",
        temporal=True,
        display_name="Current City",
        description="Where the user currently lives",
        examples=["Paris", "New York"],
    ),
    "user:preference:cuisine": FactSchema(
        category=FactCategory.PREFERENCE,
        key_pattern="user:preference:cuisine",
        value_type="list",
        multi_valued=True,
        display_name="Food Preferences",
        description="Types of cuisine the user likes/dislikes",
        examples=["vegetarian", "Italian", "no seafood"],
    ),
    "user:relationship:*": FactSchema(
        category=FactCategory.RELATIONSHIP,
        key_pattern="user:relationship:{person}",
        value_type="object",
        display_name="Relationship",
        description="User's relationship with someone",
        examples=["spouse: Jane", "colleague: Bob"],
    ),
    # Cognitive constraint schemas (LoCoMo-Plus)
    "user:goal:*": FactSchema(
        category=FactCategory.GOAL,
        key_pattern="user:goal:{scope}",
        value_type="string",
        temporal=True,
        display_name="User Goal",
        description="A goal the user is pursuing",
        examples=["preparing for exam", "saving money for a house"],
    ),
    "user:value:*": FactSchema(
        category=FactCategory.VALUE,
        key_pattern="user:value:{scope}",
        value_type="string",
        display_name="User Value",
        description="Something the user values or considers important",
        examples=["family time", "healthy eating", "environmental sustainability"],
    ),
    "user:state:*": FactSchema(
        category=FactCategory.STATE,
        key_pattern="user:state:{scope}",
        value_type="string",
        temporal=True,
        display_name="User State",
        description="A current state or condition the user is experiencing",
        examples=["stressed about work", "recovering from surgery"],
    ),
    "user:causal:*": FactSchema(
        category=FactCategory.CAUSAL,
        key_pattern="user:causal:{scope}",
        value_type="string",
        display_name="Causal Reasoning",
        description="A causal explanation or reasoning provided by the user",
        examples=["avoiding sugar because of diabetes", "studying hard to get scholarship"],
    ),
    "user:policy:*": FactSchema(
        category=FactCategory.POLICY,
        key_pattern="user:policy:{scope}",
        value_type="string",
        display_name="Personal Policy",
        description="A personal rule or policy the user follows",
        examples=["never eats after 8pm", "always exercises in the morning"],
    ),
}
