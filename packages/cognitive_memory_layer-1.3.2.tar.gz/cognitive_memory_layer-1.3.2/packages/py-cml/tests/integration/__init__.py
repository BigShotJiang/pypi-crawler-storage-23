"""Integration tests (require running CML server)."""
