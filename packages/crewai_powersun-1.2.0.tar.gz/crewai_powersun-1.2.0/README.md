# crewai-powersun

CrewAI integration for [PowerSun.vip](https://powersun.vip) — the TRON Energy & Bandwidth marketplace and DEX swap aggregator for AI agents.

## Install

```bash
pip install crewai-powersun
```

## Quick Start

```python
from crewai import Agent, Task, Crew
from crewai_powersun import PowerSunEstimateCostTool, PowerSunBuyEnergyTool

# Create an agent with PowerSun tools
energy_manager = Agent(
    role="TRON Energy Manager",
    goal="Minimize transaction costs by renting energy instead of burning TRX",
    backstory="Expert in TRON network resource management",
    tools=[
        PowerSunEstimateCostTool(),
        PowerSunBuyEnergyTool(api_key="ps_your_key"),
    ],
)

# Create a task
task = Task(
    description="Estimate cost and buy 65000 energy for address TYourAddress for 1 hour",
    agent=energy_manager,
)

crew = Crew(agents=[energy_manager], tasks=[task])
result = crew.kickoff()
```

## Environment Variable

Set `POWERSUN_API_KEY` to avoid passing the key to each tool:

```bash
export POWERSUN_API_KEY=ps_your_key
```

## Available Tools (9)

| Tool | Auth | Description |
|------|------|-------------|
| `PowerSunRegisterTool` | No | Start registration — get challenge to sign |
| `PowerSunVerifyRegistrationTool` | No | Submit signature → get API key |
| `PowerSunMarketOverviewTool` | No | Market snapshot: prices, availability, stats |
| `PowerSunEstimateCostTool` | No | Calculate energy rental cost |
| `PowerSunBuyEnergyTool` | Yes | Purchase energy delegation |
| `PowerSunGetBalanceTool` | Yes | Account balance and deposit info |
| `PowerSunGetOrderStatusTool` | Yes | Order status with delegation progress |
| `PowerSunGetSwapQuoteTool` | Yes | Get swap quote for SunSwap DEX (TRX, USDT, USDC, SUN, BTT, WIN, JST) |
| `PowerSunExecuteSwapTool` | Yes | Execute signed swap TX with automatic energy delegation |

## Links

- **Platform:** [powersun.vip](https://powersun.vip)
- **MCP Server:** [powersun.vip/mcp](https://powersun.vip/mcp)
- **API Docs:** [powersun.vip/api-docs](https://powersun.vip/api-docs)

## License

MIT
