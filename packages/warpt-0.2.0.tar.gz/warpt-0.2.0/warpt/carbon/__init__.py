"""Carbon tracking package for energy, CO2, and cost estimation."""
