"""Warpt command handlers - orchestration layer for CLI commands."""
