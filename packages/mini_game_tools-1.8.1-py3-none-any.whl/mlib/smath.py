# 常数
pi = 3.141592653589793
e = 2.718281828459045
i = 1j

# ========== 基础函数 ==========

def _exp(z, terms=20):
    """e^z 泰勒展开，支持复数"""
    result = 1.0
    term = 1.0
    for n in range(1, terms):
        term *= z / n
        result += term
    return result

def _ln(x):
    
    if x <= 0:
        return float('-inf')
    y = x - 1
    if abs(y) < 0.1:
        return y - y**2/2 + y**3/3 - y**4/4 + y**5/5 - y**6/6 + y**7/7 - y**8/8 + y**9/9 - y**10/10 + y**11/11 - y**12/12 + y**13/13 - y**14/14 + y**15/15 - y**16/16 + y**17/17 - y**18/18 + y**19/19
    exponent = 0
    while x > 2:
        x /= 2
        exponent += 1
    while x < 1:
        x *= 2
        exponent -= 1
    y = x - 1
    log_x = y - y**2/2 + y**3/3 - y**4/4 + y**5/5 - y**6/6 + y**7/7 - y**8/8 + y**9/9 - y**10/10 + y**11/11 - y**12/12 + y**13/13 - y**14/14 + y**15/15 - y**16/16 + y**17/17 - y**18/18 + y**19/19
    return log_x + exponent * 0.6931471805599453  # ln(2)

def _log(z):
    """复数自然对数 ln(z)"""
    if not isinstance(z, complex):
        z = complex(z, 0)
    
    # 模长
    r = (z.real**2 + z.imag**2) ** 0.5
    if r == 0:
        return float("-inf")
    
    # 辐角 atan2(y, x)
    theta = _atan2(z.imag, z.real)
    result = complex(_ln(r), theta)
    if abs(result.imag) < 1e-15:  # 浮点数精度阈值
        return result.real
    return result

def _atan2(y, x):
    """手写辐角函数"""
    if x > 0:
        return _atan(y / x)
    if x < 0:
        if y >= 0:
            return _atan(y / x) + pi
        else:
            return _atan(y / x) - pi
    if x == 0:
        if y > 0:
            return pi / 2
        if y < 0:
            return -pi / 2
        return 0  # (0,0) 未定义，这里返回 0

def _atan(x, terms=20):
    """反正切泰勒展开 arctan(x)"""
    if abs(x) > 1:
        return pi/2 - _atan(1/x) if x > 0 else -pi/2 - _atan(1/x)
    
    result = 0
    for n in range(terms):
        result += ((-1)**n) * (x**(2*n+1)) / (2*n + 1)
    if abs(result.imag) < 1e-15:  # 浮点数精度阈值
        return result.real
    return result

# ========== 对数系列 ==========

def log(z, base=10):
    """任意底数的对数，支持复数"""
    ln_z = _log(z)
    if base is None:
        return ln_z
    return ln_z / _log(base)

def log10(z):
    return log(z, 10)

def log2(z):
    return log(z, 2)

def ln(z):

    if not isinstance(z, complex):
        # 提取 e 的幂次
        n = 0
        x = z
        while x > e:  # 分解出 e 的因子
            x /= e
            n += 1
        while 0 < x < 1/e:
            x *= e
            n -= 1
        
        if n != 0:
            # ln(z) = n * ln(e) + ln(x)
            # ln(e) 可以预定义为精确值 1.0
            return n * 1.0 + _ln(x)
        
    # 复数走原来的逻辑
    return _log(z)
# ========== 三角函数 ==========

def cos(z):
    """余弦，支持复数"""
    if not isinstance(z, complex):
        z = z % (2*pi)
        z = complex(z, 0)
    iz = complex(-(z.imag % (2*pi)), z.real % (2*pi))  # i * z
    result = (_exp(iz) + _exp(-iz)) / 2
    if abs(result.imag) < 1e-15:  # 浮点数精度阈值
        return result.real
    return result

def sin(z):
    """正弦，支持复数"""
    if not isinstance(z, complex):
        z = complex(z, 0)
    iz = complex(-z.imag, z.real)  # i * z
    result = (_exp(iz) - _exp(-iz)) / (2j)
    if abs(result.imag) < 1e-15:  # 浮点数精度阈值
        return result.real
    return result

def tan(z):
    return sin(z) / cos(z)

def cot(z):
    return cos(z) / sin(z)

def sec(z):
    return 1 / cos(z)

def csc(z):
    return 1 / sin(z)

# ========== 反三角函数 ==========

def asin(z):
    """反正弦 arcsin(z) = -i * ln(i*z + sqrt(1-z²))"""
    if not isinstance(z, complex):
        z = complex(z, 0)
    return -1j * _log(1j * z + (1 - z*z) ** 0.5)

def acos(z):
    """反余弦 arccos(z) = -i * ln(z + i*sqrt(1-z²))"""
    if not isinstance(z, complex):
        z = complex(z, 0)
    return -1j * _log(z + 1j * (1 - z*z) ** 0.5)

def atan(z):
    """反正切 arctan(z) = i/2 * ln((i+z)/(i-z))"""
    if not isinstance(z, complex):
        z = complex(z, 0)
    return (1j/2) * _log((1j + z) / (1j - z))

def atan2(y, x):
    if isinstance(y, complex):
        raise ValueError("输入复数, 你用atan去, 别找我")
    if isinstance(x, complex):
        raise ValueError("输入复数, 你用atan去, 别找我")
    return _atan2(y, x)
# ========== 双曲函数 ==========

def cosh(z):
    """双曲余弦 cosh(z) = (e^z + e^-z)/2"""
    return (_exp(z) + _exp(-z)) / 2

def sinh(z):
    """双曲正弦 sinh(z) = (e^z - e^-z)/2"""
    return (_exp(z) - _exp(-z)) / 2

def tanh(z):
    return sinh(z) / cosh(z)

# ========== 取整函数 ==========
def round(x):
    if x >= 0:
        return int(x + 0.5)
    else:
        return int(x - 0.5)
    
def floor(x):
    return round(x - 0.5)

def ceil(x):
    return (floor(x) + 1) if x != int(x) else x

# ========== 代数函数 ==========

def root(x, n=2):
    """n 次方根"""
    return x ** (1/n)

sqrt = root  # 平方根别名
cbrt = lambda x: root(x, 3)  # 立方根

# ========== 转换函数 ==========
sign = lambda x: (x > 0) - (x < 0)
rad = lambda x: x * pi / 180
deg = lambda x: x * 180 / pi
fract = lambda x: x - floor(x) if x >= 0 else x - ceil(x)
wrap = lambda x, a, b: a + (x - a) % (b - a)
def map(x, in_min, in_max, out_min, out_max, clamp=False):
    value = (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min
    if clamp:
        if out_min <= out_max:
            return max(min(value, out_max), out_min)
        else:
            return max(min(value, out_min), out_max)
    return value


# ========== 统计函数 ==========

def mean(arr):
    return sum(arr) / len(arr)

def variance(arr):
    m = mean(arr)
    return sum((x - m) ** 2 for x in arr) / len(arr)

def mad(arr):
    m = mean(arr)
    return sum(abs(x - m) for x in arr) / len(arr)

def median(arr):
    """中位数"""
    if not arr:
        return None
    sorted_arr = sorted(arr)
    n = len(sorted_arr)
    mid = n // 2
    if n % 2 == 1:
        return sorted_arr[mid]
    return (sorted_arr[mid - 1] + sorted_arr[mid]) / 2


def mode(arr):
    """众数（可能有多个）"""
    if not arr:
        return None
    
    # 统计频次
    freq = {}
    for x in arr:
        freq[x] = freq.get(x, 0) + 1
    
    # 找最大频次
    max_freq = max(freq.values())
    
    # 收集所有出现次数 = max_freq 的数
    modes = [x for x, count in freq.items() if count == max_freq]
    
    return modes if len(modes) > 1 else modes[0]


def std(arr, ddof=0):
    """标准差
    ddof=0: 总体标准差（除以 n）
    ddof=1: 样本标准差（除以 n-1）
    """
    if len(arr) < 2:
        return 0
    
    m = mean(arr)
    variance = sum((x - m) ** 2 for x in arr) / (len(arr) - ddof)
    return variance ** 0.5

def probability_distribution(arr):
    """把数组转换成概率分布"""
    total = len(arr)
    freq = {}
    for x in arr:
        freq[x] = freq.get(x, 0) + 1
    # 数值 → 出现概率
    return {val: count/total for val, count in freq.items()}

def distribution_to_arr(prob_dict, n):
    """把概率分布转换成数组
       prob_dict: {值: 概率} 的字典，概率和应为1
       n: 要生成的样本数量
       返回: 按概率分布生成的数组
    """
    total = n
    # 数值 → 出现概率
    return _flatten([[val]*(round(count*total)) for val, count in prob_dict.items()])

def _flatten(lst):
    """递归展平嵌套列表"""
    result = []
    for item in lst:
        if isinstance(item, list):
            result.extend(_flatten(item))  # 递归
        else:
            result.append(item)
    return result
# 或者按概率排序
def prob_dist_sorted(arr):
    prob_dist = probability_distribution(arr)
    return dict(sorted(prob_dist.items(), key=lambda x: x[1], reverse=True))

