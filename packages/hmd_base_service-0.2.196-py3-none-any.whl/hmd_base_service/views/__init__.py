from inspect import Parameter, signature
import os
from typing import Any, Callable, Dict


from hmd_lib_auth.open_policy_agent import validate_authorization
from hmd_lib_auth.lambda_helper import service_name, opa_input, opa_bearer_token

from ..types import OperationEvent, OperationContext
from ..operation import Operation, annotation_map
from .components import NeuronSphereUI
from fastui import AnyComponent


class View:
    def __init__(
        self,
        fn: Callable,
        rest_path: str,
        name: str = None,
        operation_type: str = None,
        pre_op: Operation = None,
        pre_op_args: Callable = None,
        args: Dict = {},
    ) -> None:
        self.fn = fn
        self.rest_path = rest_path
        self.fn_signature = signature(fn)
        self.args = args

        view_params = []
        for k, v in self.args.items():
            if isinstance(v, str):
                annotation = annotation_map.get(v, Parameter.empty)
            else:
                annotation = v
            param = Parameter(k, Parameter.POSITIONAL_OR_KEYWORD, annotation=annotation)
            view_params.append(param)

        self.op_signature = self.fn_signature.replace(parameters=view_params)
        self.name = fn.__name__ if name is None else name
        self.operation_type = operation_type
        self.pre_op = pre_op
        self.pre_op_args = pre_op_args

    def __call__(self, evt: OperationEvent, ctx: OperationContext) -> Any:
        with ctx.tracer.start_span(self.name):
            fn_params = self.fn_signature.parameters
            evt_args = evt.args
            args = []
            kwargs = {}

            if os.environ.get("AUTHORIZATION", "NONE") != "NONE":
                is_authorized, policy = validate_authorization(
                    service_name(
                        os.environ.get("HMD_INSTANCE_NAME"),
                        os.environ.get("HMD_REPO_NAME"),
                        os.environ.get("HMD_DID"),
                        os.environ.get("HMD_ENVIRONMENT"),
                        os.environ.get("HMD_REGION"),
                        os.environ.get("HMD_CUSTOMER_CODE"),
                    ),
                    self.auth_rules,
                    opa_input(evt),
                    token=opa_bearer_token(),
                )

                if not is_authorized:
                    violated_rules = [
                        rule for rule in self.auth_rules if not policy.get(rule, False)
                    ]
                    raise Exception(f"Request does not satisfy rules: {violated_rules}")

            if self.pre_op_args is not None and isinstance(self.pre_op_args, callable):
                evt_args = self.pre_op_args(evt.args)

            if self.pre_op is not None:
                evt_payload = self.pre_op(
                    OperationEvent(
                        evt.orig_evt,
                        evt.path,
                        evt_args,
                        evt.payload,
                        class_name=evt.class_name,
                    ),
                    ctx,
                )
                evt.payload = evt_payload

            for k, param in fn_params.items():
                if k == "evt":
                    args.append(evt)
                    continue
                if k == "ctx":
                    args.append(ctx)
                    continue
                arg_value = evt_args.get(k)
                if arg_value is None:
                    arg_value = evt_payload.get(k)

                if param.kind == param.POSITIONAL_OR_KEYWORD:
                    if arg_value is None:
                        raise Exception(f"Missing {k} in event")
                    args.append(arg_value)
                    continue

                if param.kind == param.KEYWORD_ONLY:
                    if arg_value is None:
                        raise Exception(f"Missing {k} in event")
                    kwargs[k] = arg_value
                    continue

                if param.kind == param.VAR_POSITIONAL:
                    args = [evt, ctx]
                    break

            with ctx.metrics.timer(
                f"{self.name}.fn_call",
                description=f"{self.name} wrapped view function timer",
            ):
                result = self.fn(*args, **kwargs)
                print(result)
                return result

    def __getitem__(self, key: str) -> Any:
        return self.__dict__[key]


ViewMap = Dict[str, View]
