from typing import Any, Dict, List, Type, TypeVar
from hmd_schema_loader import DefaultLoader

from hmd_entity_storage import BaseEngine
from hmd_lib_telemetry.hmd_lib_telemetry import HmdTracer, HmdMetric
from pydantic import BaseModel, Field, create_model
from hmd_meta_types.entity import Entity

ClassName = TypeVar("ClassName")
ClassNameList = List[ClassName]


annotation_map = {
    "string": str,
    "integer": int,
    "float": float,
    "mapping": str,
    "collection": str,
    "blob": str,
    "timestamp": str,
    "json": dict,
    "enum": str,
    "class_name": ClassName,
}

# Module-level cache for Pydantic models to avoid duplicate generation
_pydantic_model_cache: Dict[str, Any] = {}


class OperationEvent:
    def __init__(
        self,
        evt: Dict,
        request: Any,
        path: str,
        args: Dict = {},
        payload: Dict = {},
        class_name: str = None,
        access_token: str = None,
    ):
        self.orig_evt = evt
        self.path = path
        self.args = args
        self.payload = payload
        self.class_name = class_name
        self.access_token = access_token
        self.request = request

    def __getitem__(self, key: str) -> Any:
        if key == "args":
            return self.args

        if key == "payload":
            return self.payload

        if key == "path":
            return self.path

        if key == "class_name":
            return self.class_name

        return self.orig_evt.get(key)

    def get(self, key, default: Any = None):
        if key == "args":
            value = self.args
        elif key == "payload":
            value = self.payload
        elif key == "path":
            value = self.path
        elif key == "class_name":
            value = self.class_name
        else:
            value = self.orig_evt.get(key)

        if value is None:
            return default

        return value


def get_field_type(attr: dict):
    base_type = annotation_map[attr["type"]]
    default = None
    if attr.get("required", False):
        default = ...

    return (base_type, default)


class EntityModel(BaseModel):
    identifier: str = None
    ns_internal_created: str = Field(None, alias="_created")
    ns_internal_updated: str = Field(None, alias="_updated")


def get_model(klass: Entity):
    namespace_name = klass.get_namespace_name()

    # Return cached model if exists
    if namespace_name in _pydantic_model_cache:
        return _pydantic_model_cache[namespace_name]

    # Generate and cache
    fields = klass.entity_definition()["attributes"]
    fields = {k: get_field_type(v) for k, v in fields.items()}
    if klass.entity_definition()["metatype"].lower() == "relationship":
        fields["ref_from"] = (str, ...)
        fields["ref_to"] = (str, ...)

    payload_model = create_model(
        namespace_name,
        __base__=EntityModel,
        **fields,
    )
    _pydantic_model_cache[namespace_name] = payload_model
    return payload_model


class OperationContext:
    def __init__(self, svc_name: str, ctx: Dict) -> None:
        self.ctx = ctx
        self.service_config = ctx.get("service_config", {})
        self.entity_configs = ctx.get("entity_configs", {})
        self.storage = ctx.get("storage")
        self.db_config = ctx.get("db_config")
        self.loaders: Dict[str, DefaultLoader] = ctx.get("loaders", {})
        self.loader: DefaultLoader = ctx.get("loader")
        self.tracer = HmdTracer(svc_name)
        self.metrics = HmdMetric(svc_name)
        self.models: Dict[str, Any] = {}
        self.user_email: str = None  # This will be set by UserMiddleware
        self.sender_host: str = None  # This will be set by OperationContextMiddleware
        if self.loader is not None:
            with self.metrics.timer("operation_context.model_generation"):
                for schema_name in self.loader:
                    klass = self.loader.get_class(schema_name)
                    self.models[klass.get_namespace_name()] = get_model(klass)

    def __getitem__(self, key: str) -> Any:
        if key in self.__dict__:
            return self.__dict__[key]

        return self.ctx[key]

    def get(self, key: str, default: Any = None):
        value = self[key]

        if value is None:
            return default

        return value

    def has_db_engines(self):
        return (
            self.storage
            and isinstance(self.storage, dict)
            and len(self.storage) > 0
            and all(isinstance(value, BaseEngine) for _, value in self.storage.items())
        )
