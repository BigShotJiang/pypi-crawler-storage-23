import os
from typing import Any, Callable, Dict, List
from inspect import signature, Parameter, Signature, iscoroutinefunction

from hmd_lib_auth.open_policy_agent import validate_authorization
from hmd_lib_auth.lambda_helper import (
    service_name,
    opa_input,
    opa_bearer_token,
    cert_info,
)

from .types import OperationEvent, OperationContext, annotation_map


class Operation:
    def __init__(
        self,
        fn: Callable,
        name: str = None,
        operation_type: str = None,
        rest_path: str = None,
        rest_methods: List[str] = [],
        graphql_query: str = None,
        graphql_return_list: bool = False,
        graphql_mutation: str = None,
        graphql_entity_type=None,
        graphql_input_type=None,
        args: Dict = {},
        auth_rules: List = [],
    ) -> None:
        self.fn = fn
        self.operation_type = operation_type
        self._fn_signature = None  # Lazy - only computed when operation is invoked
        self.args = args

        # Build op_signature directly from args (no reflection needed!)
        op_params = []
        for k, v in self.args.items():
            if isinstance(v, str):
                annotation = annotation_map.get(v, Parameter.empty)
            else:
                annotation = v
            param = Parameter(k, Parameter.POSITIONAL_OR_KEYWORD, annotation=annotation)
            op_params.append(param)
        self.op_signature = Signature(parameters=op_params)
        self.name = fn.__name__ if name is None else name
        self.rest_path = rest_path
        self.rest_methods = rest_methods
        self.graphql_query = graphql_query
        self.graphql_mutation = graphql_mutation
        self.graphql_return_list = graphql_return_list
        self.graphql_entity_type = graphql_entity_type
        self.graphql_input_type = graphql_input_type
        self.auth_rules = auth_rules

    @property
    def fn_signature(self):
        """Lazy signature - only computed when operation is invoked."""
        if self._fn_signature is None:
            self._fn_signature = signature(self.fn)
        return self._fn_signature

    def _prepare_call(self, evt: OperationEvent, ctx: OperationContext):
        """Prepare arguments for function call and perform authorization."""
        fn_params = self.fn_signature.parameters
        evt_args = evt.args
        evt_payload = evt.payload
        args = []
        kwargs = {}

        if os.environ.get("AUTHORIZATION", "NONE") != "NONE":
            is_authorized, policy = validate_authorization(
                service_name(
                    os.environ.get("HMD_INSTANCE_NAME"),
                    os.environ.get("HMD_REPO_NAME"),
                    os.environ.get("HMD_DID"),
                    os.environ.get("HMD_ENVIRONMENT"),
                    os.environ.get("HMD_REGION"),
                    os.environ.get("HMD_CUSTOMER_CODE"),
                ),
                self.auth_rules,
                opa_input(evt, cert_info(evt)),
                token=opa_bearer_token(),
            )

            if not is_authorized:
                violated_rules = [
                    rule for rule in self.auth_rules if not policy.get(rule, False)
                ]
                raise Exception(f"Request does not satisfy rules: {violated_rules}")

        for k, param in fn_params.items():
            if k == "evt":
                args.append(evt)
                continue
            if k == "ctx":
                args.append(ctx)
                continue
            arg_value = evt_args.get(k)
            if arg_value is None:
                arg_value = evt_payload.get(k)

            if param.kind == param.POSITIONAL_OR_KEYWORD:
                if arg_value is None:
                    raise Exception(f"Missing {k} in event")
                args.append(arg_value)
                continue

            if param.kind == param.KEYWORD_ONLY:
                if arg_value is None:
                    raise Exception(f"Missing {k} in event")
                kwargs[k] = arg_value
                continue

            if param.kind == param.VAR_POSITIONAL:
                args = [evt, ctx]
                break

        return args, kwargs

    def __call__(self, evt: OperationEvent, ctx: OperationContext) -> Any:
        # For async functions, return the coroutine directly to be awaited by caller
        if iscoroutinefunction(self.fn):
            return self._async_call(evt, ctx)
        return self._sync_call(evt, ctx)

    def _sync_call(self, evt: OperationEvent, ctx: OperationContext) -> Any:
        """Synchronous call handler."""
        with ctx.tracer.start_span(self.name):
            args, kwargs = self._prepare_call(evt, ctx)

            if ctx.has_db_engines():
                with ctx.metrics.timer(
                    f"{self.name}.db_transaction_wrapper",
                    description=f"{self.name} call including db engine transaction calls",
                ):
                    for db_engine in ctx.storage.values():
                        db_engine.begin_transaction()
                    try:
                        with ctx.metrics.timer(
                            f"{self.name}.fn_call",
                            description=f"{self.name} wrapped function timer",
                        ):
                            result = self.fn(*args, **kwargs)
                        for db_engine in ctx.storage.values():
                            db_engine.commit_transaction()
                        return result
                    except Exception as e:
                        ctx.tracer.error(f"{self.name} failed", {"exception": str(e)})
                        for db_engine in ctx.storage.values():
                            db_engine.rollback_transaction()
                        raise e
            else:
                with ctx.metrics.timer(
                    f"{self.name}.fn_call",
                    description=f"{self.name} wrapped function timer",
                ):
                    return self.fn(*args, **kwargs)

    async def _async_call(self, evt: OperationEvent, ctx: OperationContext) -> Any:
        """Asynchronous call handler."""
        with ctx.tracer.start_span(self.name):
            args, kwargs = self._prepare_call(evt, ctx)

            if ctx.has_db_engines():
                with ctx.metrics.timer(
                    f"{self.name}.db_transaction_wrapper",
                    description=f"{self.name} call including db engine transaction calls",
                ):
                    for db_engine in ctx.storage.values():
                        db_engine.begin_transaction()
                    try:
                        with ctx.metrics.timer(
                            f"{self.name}.fn_call",
                            description=f"{self.name} wrapped function timer",
                        ):
                            result = await self.fn(*args, **kwargs)
                        for db_engine in ctx.storage.values():
                            db_engine.commit_transaction()
                        return result
                    except Exception as e:
                        ctx.tracer.error(f"{self.name} failed", {"exception": str(e)})
                        for db_engine in ctx.storage.values():
                            db_engine.rollback_transaction()
                        raise e
            else:
                with ctx.metrics.timer(
                    f"{self.name}.fn_call",
                    description=f"{self.name} wrapped function timer",
                ):
                    return await self.fn(*args, **kwargs)

    def __getitem__(self, key: str) -> Any:
        return self.__dict__[key]


OperationMap = Dict[str, Operation]
