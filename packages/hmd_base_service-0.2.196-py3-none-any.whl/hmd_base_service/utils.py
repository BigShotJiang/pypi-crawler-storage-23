from typing import Dict
from hmd_entity_storage import BaseEngine


STORAGE = "storage"

__default_operation_config__ = {"expose": True, "pre": [], "post": []}
__default_entity_config__ = {
    "create": __default_operation_config__,
    "read": __default_operation_config__,
    "update": __default_operation_config__,
    "delete": __default_operation_config__,
    "search": __default_operation_config__,
}


def _has_db_engines(context):
    return (
        STORAGE in context
        and isinstance(context[STORAGE], dict)
        and len(context[STORAGE]) > 0
        and all(isinstance(value, BaseEngine) for _, value in context[STORAGE].items())
    )


def get_entity_config(class_name: str, entity_configs: Dict):
    class_name_config = entity_configs.get(class_name, {})
    defined_default = entity_configs.get("__default__", {})

    return {**__default_entity_config__, **defined_default, **class_name_config}


def init_instrumentation(config: Dict = {}):
    """
    Initialize the auto-instrumentation for the service.
    """
    from opentelemetry.instrumentation.requests import RequestsInstrumentor
    from opentelemetry.instrumentation.botocore import BotocoreInstrumentor
    from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
    from opentelemetry.instrumentation.psycopg2 import Psycopg2Instrumentor

    default_config = {
        "requests": {"instrumentation_enabled": True},
        "botocore": {"instrumentation_enabled": True},
        "boto3sqs": {"instrumentation_enabled": True},
        "fastapi": {"instrumentation_enabled": True},
        "psycopg2": {"instrumentation_enabled": True},
    }
    config = {**default_config, **config}
    if config["requests"]["instrumentation_enabled"]:
        RequestsInstrumentor().instrument()
    if config["botocore"]["instrumentation_enabled"]:
        BotocoreInstrumentor().instrument()
    if config["fastapi"]["instrumentation_enabled"]:
        FastAPIInstrumentor().instrument()
    if config["psycopg2"]["instrumentation_enabled"]:
        Psycopg2Instrumentor().instrument()


def init_lambda_instrumentation(config: Dict = {}):
    """
    Initialize the auto-instrumentation for AWS Lambda functions.
    """
    from opentelemetry.instrumentation.aws_lambda import AwsLambdaInstrumentor

    default_config = {
        "aws_lambda": {"instrumentation_enabled": True},
    }
    config = {**default_config, **config}
    if config["aws_lambda"]["instrumentation_enabled"]:
        AwsLambdaInstrumentor().instrument()
