from functools import partial
import logging
import os
from abc import ABC, abstractmethod
from json import loads, JSONDecodeError
from typing import Any, Callable, Dict, List, Type

from hmd_lib_auth.open_policy_agent import validate_authorization
from hmd_lib_auth.lambda_helper import service_name, opa_input, opa_bearer_token
from hmd_entity_storage import BaseEngine
from hmd_meta_types import Entity

logger = logging.getLogger(f"HMD.{__name__}")

STORAGE = "storage"

__default_operation_config__ = {"expose": True, "pre": [], "post": []}
__default_entity_config__ = {
    "create": __default_operation_config__,
    "read": __default_operation_config__,
    "update": __default_operation_config__,
    "delete": __default_operation_config__,
    "search": __default_operation_config__,
}


def _has_db_engines(context):
    return (
        STORAGE in context
        and isinstance(context[STORAGE], dict)
        and len(context[STORAGE]) > 0
        and all(isinstance(value, BaseEngine) for _, value in context[STORAGE].items())
    )


class BaseService:
    def __init__(self, context=None) -> None:
        if context is None:
            context = {}
        self.context = context
        self.handlers = {}
        self.operations = {}
        self.searches = {}
        self.has_db_engines = _has_db_engines(context)
        self.__middleware: List[
            Callable[[Callable[[Dict, Dict], Any], Dict, Dict], Any]
        ] = []

    def __run_middleware(self, execute):
        next = execute
        exec_fn = execute
        for fn in reversed(self.__middleware):
            next = partial(fn, next)
            exec_fn = next

        return exec_fn

    def execute(self, evt, ctx):
        evt_path = evt["path"]
        body = evt.get("body", "{}")
        if not body:
            body = "{}"

        # TODO: is there a better way to handle this?
        # for *some* integrations, we don't have control over the structure of
        # the request body. It may be sent as a query string as opposed to json
        # for now, we log that event and expect the client to parse the body
        # in code
        try:
            evt["payload"] = loads(body)
        except JSONDecodeError:
            logger.warning("unable to decode request body")
            body = "{}"
            evt["payload"] = loads(body)
        ctx = {**self.context, **ctx.__dict__}

        for h_path, handler in self.handlers.items():
            if h_path in evt_path:
                execute = self.__run_middleware(handler.execute)
                result = execute(evt, ctx)
                return result

    def run(self):
        for _, handler in self.handlers.items():
            logger.info(f"Calling setup for {handler.__class__}")
            handler.setup(self.operations, self.context)
            logger.info(f"Setup complete for {handler.__class__}")

    def register_handler(self, handler, base_path):
        if base_path in self.handlers:
            raise Exception(f"Mutiple handlers specified for base_path: {base_path}")

        self.handlers[base_path] = handler

    def register_saved_search(
        self, name: str, entities: List[Type[Entity]], search: Dict[str, Any]
    ):
        self.searches[name] = {"entities": entities, "filter": search}

    def operation(self, **kwds):
        def decorator(fn):
            def transaction_wrapper(*args, **kwargs):
                evt = args[0]
                # TODO once all services are using identity, we could probably
                # clean this up
                if os.environ.get("AUTHORIZATION", "NONE") != "NONE":
                    rules = kwds.get("auth_rules", [])

                    is_authorized, policy = validate_authorization(
                        service_name(
                            os.environ.get("HMD_INSTANCE_NAME"),
                            os.environ.get("HMD_REPO_NAME"),
                            os.environ.get("HMD_DID"),
                            os.environ.get("HMD_ENVIRONMENT"),
                            os.environ.get("HMD_REGION"),
                            os.environ.get("HMD_CUSTOMER_CODE"),
                        ),
                        rules,
                        opa_input(evt),
                        token=opa_bearer_token(),
                    )
                    if not is_authorized:
                        violated_rules = [
                            rule for rule in rules if not policy.get(rule, False)
                        ]
                        raise Exception(
                            f"Request does not satisfy rules: {violated_rules}"
                        )

                if self.has_db_engines:
                    for db_engine in self.context[
                        "storage"
                    ].values():  # type: BaseEngine
                        db_engine.begin_transaction()
                    try:
                        result = fn(*args, **kwargs)
                        for db_engine in self.context[
                            "storage"
                        ].values():  # type: BaseEngine
                            db_engine.commit_transaction()
                        return result
                    except Exception as e:
                        for db_engine in self.context[
                            "storage"
                        ].values():  # type: BaseEngine
                            db_engine.rollback_transaction()
                        raise e
                else:
                    return fn(*args, **kwargs)

            self.operations[fn.__name__] = {"fn": transaction_wrapper, **kwds}

            return transaction_wrapper

        return decorator

    def middleware(self, fn: Callable[[Callable[[Dict, Dict], Any], Dict, Dict], Any]):
        self.__middleware.append(fn)


class BaseHandler(ABC):
    @abstractmethod
    def setup(self, operations, context: Dict):
        raise NotImplementedError

    @abstractmethod
    def execute(self, evt, ctx):
        raise NotImplementedError
