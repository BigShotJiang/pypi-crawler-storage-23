from typing import Callable
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from ...operation import OperationContext


class SenderHostMiddleware(BaseHTTPMiddleware):
    def __init__(
        self, app, dispatch=None, get_hostname: Callable = lambda evt: None
    ) -> None:
        super().__init__(app)
        self.get_hostname = get_hostname

    async def dispatch(self, request: Request, call_next):
        request.state.sender_host = self.get_hostname(
            request.scope.get("aws.event", {})
        )
        if request.state.context:
            request.state.context.sender_host = request.state.sender_host

        response = await call_next(request)
        return response
