from typing import Callable, List
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from hmd_lang_audit.audit_record import AuditRecord
from hmd_lang_audit.audit_record_audits_entity import AuditRecordAuditsEntity
from ...operation import OperationContext

from hmd_entity_storage.engines import BaseEngine
from hmd_entity_storage.auditor.engine_auditor import EngineAuditor


class UserMiddleware(BaseHTTPMiddleware):
    def __init__(
        self,
        app,
        dispatch=None,
        engine: BaseEngine = None,
        exclude=List[str],
    ) -> None:
        super().__init__(app)

        self.audit_engine = engine
        self.exclude = exclude

    async def dispatch(self, request: Request, call_next):
        context: OperationContext = request.state.context

        if context.db_config is not None and context.storage is not None:

            def prepare_audit_record(
                event_type: str,
                event_subtype: str,
                action: str,
                started_at,
                ended_at,
                outcome: str,
                outcome_description: str,
            ):
                return {
                    "user_email": request.state.user_email,
                    "correlation_id": request.scope.get("aws.event", {}).get(
                        "requestId"
                    ),
                    "event_type": event_type,
                    "event_subtype": event_subtype,
                    "action": action,
                    "started_at": started_at,
                    "ended_at": ended_at,
                    "outcome": outcome,
                    "outcome_description": outcome_description,
                }

            auditor = EngineAuditor(
                audit_engine=self.audit_engine,
                audit_record_class=AuditRecord,
                audit_relationship_class=AuditRecordAuditsEntity,
                prepare_audit_data=prepare_audit_record,
            )

            for key, db_engine in context.storage.items():
                if context.db_config[key].get("audit", True):
                    context.storage[key] = auditor.audit(
                        db_engine,
                        context.db_config[key]["engine_type"],
                        exclude=self.exclude,
                    )

            request.state.context = context
        response = await call_next(request)
        return response
