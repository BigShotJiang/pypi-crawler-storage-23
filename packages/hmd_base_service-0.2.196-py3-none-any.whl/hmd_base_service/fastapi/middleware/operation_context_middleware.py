from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from ...operation import OperationContext


class OperationContextMiddleware(BaseHTTPMiddleware):
    def __init__(
        self, app, dispatch=None, context: OperationContext = OperationContext("", {})
    ) -> None:
        super().__init__(app)
        self.context = context

    async def dispatch(self, request: Request, call_next):
        request.state.context = self.context
        response = await call_next(request)
        return response
