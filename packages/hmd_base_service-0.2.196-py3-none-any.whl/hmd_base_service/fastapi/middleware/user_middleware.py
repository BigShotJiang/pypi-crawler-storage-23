from typing import Callable
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from ...operation import OperationContext


class UserMiddleware(BaseHTTPMiddleware):
    def __init__(
        self,
        app,
        dispatch=None,
        get_user_email: Callable = lambda evt: None,
        get_user_scope: Callable = lambda evt: None,
    ) -> None:
        super().__init__(app)
        self.get_user_email = get_user_email
        self.get_user_scope = get_user_scope

    async def dispatch(self, request: Request, call_next):
        request.state.user_email = self.get_user_email(
            request.scope.get("aws.event", {})
        )
        request.state.user_scope = self.get_user_scope(
            request.scope.get("aws.event", {})
        )
 
        if request.state.context:
            request.state.context.user_email = request.state.user_email
            request.state.context.user_scope = request.state.user_scope

        response = await call_next(request)
        return response
