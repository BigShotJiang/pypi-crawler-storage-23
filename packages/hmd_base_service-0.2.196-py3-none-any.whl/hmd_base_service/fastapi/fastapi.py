import os
from typing import Callable, Dict, List
import logging

from fastapi import FastAPI
from hmd_lib_auth.lambda_helper import get_claims, auth_token

from .middleware.user_middleware import UserMiddleware
from .middleware.sender_host_middleware import SenderHostMiddleware

from ..types import OperationContext
from ..utils import _has_db_engines
from ..operation import Operation, OperationMap
from ..views import View, ViewMap
from .handlers.base import OperationRouteHandler
from .middleware.operation_context_middleware import OperationContextMiddleware


logger = logging.getLogger(f"HMD.{__name__}")


def get_user_email(event: Dict) -> str:
    token = auth_token(event)
    auth_ctx = event.get("requestContext", {}).get("authorizer", {})
    claims = {}
    if "cert_info_serial_number" in auth_ctx:
        email = auth_ctx["cert_info_serial_number"]
        return email
    if token is not None and not token == "":
        claims = get_claims(token)
    email = claims.get("sub", "")
    scope = claims.get("scp", "")

    if not scope:
        scope = claims.get("scope", "")

    if (
        "email" not in scope
        and "headers" in event
        and "X-NeuronSphere-User-Email" in event["headers"]
    ):
        email = event["headers"]["X-NeuronSphere-User-Email"]

    return email


def get_user_scope(event: Dict) -> str:
    token = auth_token(event)
    auth_ctx = event.get("requestContext", {}).get("authorizer", {})
    claims = {}
    if "cert_info_serial_number" in auth_ctx:
        return ["service"]
    if token is not None and not token == "":
        claims = get_claims(token)
    scope = claims.get("scp", "")

    if not scope:
        return claims.get("scope", "")

    return scope


def get_hostname(event: Dict) -> str:
    if "headers" in event and "X-NeuronSphere-Host" in event["headers"]:
        return event["headers"]["X-NeuronSphere-Host"]
    return None


class FastAPIService(FastAPI):
    def __init__(self, context: Dict = {}):
        root_path = None
        if os.environ.get("HMD_ENVIRONMENT", "local") == "local":
            root_path = f"/{os.environ.get('HMD_INSTANCE_NAME', '')}"
        super().__init__(
            title=os.environ.get("HMD_INSTANCE_NAME", "HMD Base Service"),
            version=os.environ.get("HMD_REPO_VERSION", "0.1"),
            root_path=root_path,
        )
        self.context = OperationContext(
            f"{os.environ.get('HMD_INSTANCE_NAME')}_{os.environ.get('HMD_REPO_NAME')}_{os.environ.get('HMD_REPO_VERSION')}",
            context,
        )
        self.handlers: Dict[str, OperationRouteHandler] = {}
        self.operations: OperationMap = {}
        self.views: ViewMap = {}
        self.searches = {}
        self.has_db_engines = _has_db_engines(context)
        self.tracer = self.context.tracer
        self.metrics = self.context.metrics
        self.add_middleware(
            UserMiddleware, get_user_email=get_user_email, get_user_scope=get_user_scope
        )
        self.add_middleware(SenderHostMiddleware, get_hostname=get_hostname)
        self.add_middleware(OperationContextMiddleware, context=self.context)

    def register_handler(self, handler: OperationRouteHandler, base_path: str):
        if base_path in self.handlers:
            raise Exception(f"Mutiple handlers specified for base_path: {base_path}")

        if not isinstance(handler, OperationRouteHandler):
            raise Exception(
                f"Invalid handler class, must inherit from OperationRouteHandler"
            )

        self.handlers[base_path] = handler

    def run(self):
        with self.tracer.start_span("fastapi.setup"):
            if len(self.handlers) == 0:
                self.tracer.error("No operation handlers registered")
                raise Exception("No operation handlers registered")
            for base_path, handler in self.handlers.items():
                self.include_router(handler)
                logger.info(f"Setup complete for {base_path}")

    def operation(
        self,
        operation_type: str = None,
        rest_path: str = None,
        rest_methods: List[str] = [],
        graphql_query: str = None,
        graphql_return_list: bool = False,
        graphql_mutation: str = None,
        graphql_entity_type=None,
        graphql_input_type=None,
        args: Dict = {},
        name: str = None,
    ):
        def decorator(fn: Callable):
            with self.metrics.timer("operation.create"):
                op = Operation(
                    fn,
                    operation_type=operation_type,
                    rest_path=rest_path,
                    rest_methods=rest_methods,
                    graphql_query=graphql_query,
                    graphql_mutation=graphql_mutation,
                    graphql_input_type=graphql_input_type,
                    graphql_entity_type=graphql_entity_type,
                    graphql_return_list=graphql_return_list,
                    args=args,
                    name=name,
                )

            self.operations[op.name] = op
            with self.metrics.timer(f"operation.{op.name}.route_registration"):
                for handler in self.handlers.values():
                    handler.add_operation(op, self.context)
            return op

        return decorator

    def view(
        self,
        rest_path: str,
        name: str = None,
        operation_type: str = None,
        pre_op: Operation = None,
        pre_op_args: Callable = None,
        args: Dict = {},
    ):
        def decorator(fn: Callable):
            view = View(
                fn,
                rest_path,
                name=name,
                operation_type=operation_type,
                pre_op=pre_op,
                pre_op_args=pre_op_args,
                args=args,
            )
            self.views[view.name] = view
            return view

        return decorator
