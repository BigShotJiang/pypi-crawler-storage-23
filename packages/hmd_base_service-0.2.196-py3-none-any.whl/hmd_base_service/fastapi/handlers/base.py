from typing import Dict
from fastapi import APIRouter

from hmd_base_service.operation import OperationMap, Operation
from hmd_base_service.types import OperationContext


class OperationRouteHandler(APIRouter):
    def setup(self, operations: OperationMap, context: Dict):
        pass

    def add_operation(self, operation: Operation, context: OperationContext):
        pass
