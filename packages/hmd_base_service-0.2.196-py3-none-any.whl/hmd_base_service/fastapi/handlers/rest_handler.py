import logging
import re
from inspect import Parameter, Signature, iscoroutinefunction

from re import Match
from typing import Union
from pydantic import BaseModel
from fastapi import Header, Request, HTTPException

from hmd_cli_tools import ServiceException
from .base import OperationRouteHandler, OperationMap
from ...operation import Operation
from ...views import View, ViewMap, NeuronSphereUI
from ...utils import get_entity_config
from ...types import (
    ClassName,
    ClassNameList,
    OperationEvent,
    OperationContext,
    EntityModel,
)


logger = logging.getLogger(f"HMD.{__name__}")


def get_fastapi_signature(
    sig: Signature,
    payload_model: BaseModel = None,
) -> Signature:
    """Convert Operation signature into FastAPI compatible signature.


    Args:
        sig (Signature): Operation signature to convert
        payload_model (BaseModel): Pydantic model representing request body payload

    Returns:
        Signature: _description_
    """

    route_params = sig.parameters
    r_params = [
        Parameter("request", Parameter.POSITIONAL_OR_KEYWORD, annotation=Request)
    ]
    for k, p in route_params.items():
        if k == "payload" and payload_model is not None:
            r_params.append(
                Parameter(
                    k,
                    Parameter.POSITIONAL_OR_KEYWORD,
                    annotation=payload_model,
                )
            )
            continue
        if p.annotation == ClassName:
            r_params.append(
                Parameter(k, Parameter.POSITIONAL_OR_KEYWORD, annotation=payload_model)
            )
            continue
        r_params.append(p)
    return_annotation = sig.return_annotation

    if return_annotation == ClassName:
        return_annotation = payload_model

    if return_annotation == ClassNameList:
        return_annotation = list[payload_model]

    r_params.append(
        Parameter(
            "authorization",
            Parameter.KEYWORD_ONLY,
            default=Header(None),
            annotation=Union[str, None],
        )
    )
    sig = sig.replace(parameters=r_params, return_annotation=return_annotation)

    return sig


def route_factory(
    route_path: str,
    op: Union[Operation, View],
    context: OperationContext,
    class_name: str = None,
    op_name: str = None,
    class_model: EntityModel = None,
):
    """Factory function to create FastAPI routes.

    Args:
        route_path (str): path for route
        op (Operation): NeuronSphere MicroService Operation used to handle the route
        context (OperationContext): service operation context
        class_name (str, optional): NeuronSphere Entity class name, used to create multiple routes per class in language pack using same operation. Defaults to None.
    """

    def _build_event(request: Request, *args, **kwargs):
        """Build OperationEvent from request arguments."""
        access_token = None
        if "authorization" in kwargs:
            access_token = kwargs.get("authorization", None)
            del kwargs["authorization"]
        bound_args = op.op_signature.bind(*args, **kwargs)
        evt_args = {}

        for k, v in bound_args.arguments.items():
            if isinstance(v, BaseModel):
                evt_args[k] = v.model_dump(exclude_unset=True, by_alias=True)
                continue
            if isinstance(v, list):
                evt_args[k] = [
                    (
                        a.model_dump(exclude_unset=True, by_alias=True)
                        if isinstance(a, BaseModel)
                        else a
                    )
                    for a in v
                ]
                continue
            evt_args[k] = v

        payload = evt_args.get("payload", {})

        # Convert payload to dictionary if it is a Pydantic BaseModel
        if isinstance(payload, BaseModel):
            payload = payload.model_dump(exclude_unset=True, by_alias=True)

        return OperationEvent(
            request.scope.get("aws.event", {}),
            request=request,
            path=route_path,
            args=evt_args,
            payload=payload,
            class_name=class_name,
            access_token=access_token,
        )

    # Check if the operation function is async
    is_async = iscoroutinefunction(op.fn)

    if is_async:

        async def async_op_route(request: Request, *args, **kwargs):
            evt = _build_event(request, *args, **kwargs)
            try:
                result = await op(evt, context)
                return result
            except Exception as e:
                logger.exception(f"Error processing request: {e}")
                if isinstance(e, ServiceException):
                    raise HTTPException(status_code=e.status, detail=e.message) from e
                raise e from e

        async_op_route.__name__ = op.name if op_name is None else op_name
        async_op_route.__signature__ = get_fastapi_signature(
            op.op_signature, class_model
        )
        return async_op_route
    else:

        def op_route(request: Request, *args, **kwargs):
            evt = _build_event(request, *args, **kwargs)
            try:
                result = op(evt, context)
                return result
            except Exception as e:
                logger.exception(f"Error processing request: {e}")
                if isinstance(e, ServiceException):
                    raise HTTPException(status_code=e.status, detail=e.message) from e
                raise e from e

        op_route.__name__ = op.name if op_name is None else op_name
        op_route.__signature__ = get_fastapi_signature(op.op_signature, class_model)
        return op_route


def is_schema_exposed(schema_name: str, context: OperationContext, op: Operation):
    entity_config = get_entity_config(schema_name, context.entity_configs)
    return entity_config.get(op.operation_type, {})["expose"]


def add_class_name_route(
    handler: OperationRouteHandler,
    r_path: str,
    op: Union[Operation, View],
    context: OperationContext,
    class_name: str = None,
    class_model: EntityModel = None,
):
    r_path = r_path.replace("<class_name>", class_name)
    op_name = f"{class_name.split('.')[-1]}_{op.name}"
    op_route = route_factory(
        r_path,
        op,
        context,
        class_name=class_name,
        op_name=op_name,
        class_model=class_model,
    )
    handler.add_api_route(
        r_path,
        op_route,
        methods=op.rest_methods,
        operation_id=f'{op.name}_{r_path.replace("/", "_").replace("{","").replace("}", "")}',
        response_model_exclude_unset=True,
    )


class RestOperationHandler(OperationRouteHandler):
    def get_route_path(self, path: str):
        def repl(matchobj: Match):
            return (
                matchobj.group(0)
                .replace("args_", "")
                .replace("<", "{")
                .replace(">", "}")
            )

        return re.sub(r"\<args_[\w]+\>", repl, path)

    def setup(
        self, operations: OperationMap, views: ViewMap, context: OperationContext
    ):
        ops = operations.values()
        handler = self
        # Models are already cached by OperationContext.__init__ in types.py
        with context.tracer.start_span("rest_handler_add_ops"):
            for op in ops:
                if op.rest_path is None:
                    continue
                route_path = self.get_route_path(op.rest_path)

                # If <class_name> present in path, we create a separate route for each class in loader
                # This ensures each class shows up in the OpenAPI schema
                if "<class_name>" in route_path:
                    with context.metrics.timer(f"{op.name}_class_name_setup"):
                        exposed_schemas = list(
                            filter(
                                lambda k: is_schema_exposed(k, context, op),
                                context.models.keys(),
                            )
                        )
                        with context.metrics.timer(
                            f"{op.name}_class_name_route_factory"
                        ):
                            # Use map() to try and speed up performance
                            # Need to wrap in list to call generator
                            list(
                                map(
                                    lambda schema_name: add_class_name_route(
                                        handler,
                                        route_path,
                                        op,
                                        context,
                                        class_name=schema_name,
                                        class_model=context.models[schema_name],
                                    ),
                                    exposed_schemas,
                                )
                            )
                else:
                    # Create route for operation
                    op_route = route_factory(route_path, op, context)

                    self.add_api_route(
                        route_path,
                        op_route,
                        methods=op.rest_methods,
                        operation_id=f'{op.name}_{route_path.replace("/", "_").replace("{","").replace("}", "")}',
                    )

    def add_operation(self, operation: Operation, context: OperationContext):
        if operation.rest_path is None:
            return

        route_path = self.get_route_path(operation.rest_path)
        handler = self
        if "<class_name>" in route_path:
            with context.metrics.timer(f"{operation.name}_class_name_setup"):
                exposed_schemas = list(
                    filter(
                        lambda k: is_schema_exposed(k, context, operation),
                        context.models.keys(),
                    )
                )
                with context.metrics.timer(
                    f"{operation.name}_class_name_route_factory"
                ):
                    # Use map() to try and speed up performance
                    # Need to wrap in list to call generator
                    list(
                        map(
                            lambda schema_name: add_class_name_route(
                                handler,
                                route_path,
                                operation,
                                context,
                                class_name=schema_name,
                                class_model=context.models[schema_name],
                            ),
                            exposed_schemas,
                        )
                    )
        else:
            op_route = route_factory(route_path, operation, context)
            self.add_api_route(
                route_path,
                op_route,
                methods=operation.rest_methods,
                operation_id=f'{operation.name}_{route_path.replace("/", "_").replace("{","").replace("}", "")}',
            )
