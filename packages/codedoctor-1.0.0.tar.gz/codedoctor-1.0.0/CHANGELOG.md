# Changelog

## [1.0.0](https://github.com/BigPattyOG/CodeDoctor/compare/v0.2.0...v1.0.0) (2026-02-23)


### ⚠ BREAKING CHANGES

* Update to CodeDoctor and how it functions ([#16](https://github.com/BigPattyOG/CodeDoctor/issues/16))

### Features

* Update to CodeDoctor and how it functions ([#16](https://github.com/BigPattyOG/CodeDoctor/issues/16)) ([e41c3e8](https://github.com/BigPattyOG/CodeDoctor/commit/e41c3e894984b671508411d608bfdedfbf628acd))
