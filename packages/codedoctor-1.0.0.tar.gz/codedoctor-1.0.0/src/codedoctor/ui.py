from __future__ import annotations

from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.theme import Theme


def make_console() -> Console:
    """Create a Rich console themed to BareCoding."""
    theme = Theme(
        {
            "brand": "#22c55e",
            "muted": "#a1a1aa",
            "fg": "#fafafa",
            "border": "#1a1a1a",
            "ok": "#22c55e",
            "warn": "yellow",
            "fail": "red",
        }
    )
    return Console(theme=theme)


class BareUI:
    """BareCoding-style terminal UX helpers."""

    def __init__(self, console: Optional[Console] = None) -> None:
        self.console = console or make_console()

    def spinner(self, label: str):
        """Return a spinner context manager that updates in-place."""
        return self.console.status(
            f"[muted]⚠️ {label}[/muted]",
            spinner="line",
            spinner_style="brand",
        )

    def ok(self, msg: str) -> None:
        self.console.print(f"[ok]✅ {msg}[/ok]")

    def fail(self, msg: str) -> None:
        self.console.print(f"[fail]❎ {msg}[/fail]")

    def warn(self, msg: str) -> None:
        self.console.print(f"[warn]⚠️ {msg}[/warn]")

    def block(self, title: str, body: str, kind: str) -> None:
        """Print a framed output block."""
        if not body.strip():
            body = "(no output)"
        self.console.print(
            Panel(
                Text(body.rstrip(), style="fg"),
                title=f"[{kind}]{title}[/{kind}]",
                border_style=kind,
                padding=(1, 2),
            )
        )
