from __future__ import annotations

import argparse
import time
from dataclasses import replace
from pathlib import Path

from rich.panel import Panel
from rich.prompt import Confirm, Prompt

from codedoctor.config import (
    CodeDoctorConfig,
    default_config_path,
    load_config,
    save_config,
)
from codedoctor.report import CheckResult, CheckStatus, ScanReport
from codedoctor.runner import build_checks, run_command
from codedoctor.storage import get_report_paths, rotate_latest_to_previous
from codedoctor.test_template import has_any_pytest_tests, write_test_template
from codedoctor.ui import BareUI
from codedoctor.updater import check_for_update, run_self_update

UPDATE_CHECK_INTERVAL_S = 24 * 60 * 60


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="codedoctor",
        description="Beginner-friendly checks for Python repositories.",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=(
            "Examples:\n"
            "  codedoctor setup\n"
            "  codedoctor scan .\n"
            "  codedoctor scan . --fix\n"
            "  codedoctor scan . --report\n"
            "  codedoctor update\n"
        ),
    )
    parser.add_argument(
        "--config",
        type=str,
        default=str(default_config_path()),
        help="Path to codedoctor config JSON (default: %(default)s).",
    )

    subs = parser.add_subparsers(dest="command", required=True)

    setup = subs.add_parser("setup", help="Initialize codedoctor.")
    setup.add_argument("--force", action="store_true", help="Overwrite config file.")

    update = subs.add_parser("update", help="Update codedoctor from PyPI.")
    update.add_argument("--yes", action="store_true", help="Update without prompting.")

    scan = subs.add_parser("scan", help="Scan a repository.")
    scan.add_argument("path", nargs="?", default=".", help="Repo path (default: .)")
    scan.add_argument("--fix", action="store_true", help="Apply safe auto-fixes.")
    scan.add_argument("--skip-tests", action="store_true", help="Skip running pytest.")
    scan.add_argument(
        "--no-gitignore",
        action="store_true",
        help="Disable best-effort gitignore excludes for mypy/bandit.",
    )
    scan.add_argument(
        "--assume-defaults",
        action="store_true",
        help="Allow scan without running setup (use built-in defaults).",
    )
    scan.add_argument(
        "--no-update-check",
        action="store_true",
        help="Do not check PyPI for updates during scan.",
    )

    # Reports optional
    scan.add_argument(
        "--report",
        action="store_true",
        help="Write a report file (overrides config).",
    )
    scan.add_argument(
        "--report-path",
        default=None,
        help="Write report to a specific path (implies --report).",
    )
    scan.add_argument(
        "--report-dir",
        default=None,
        help="Directory (relative to repo) to store reports (overrides config).",
    )

    # Test template overrides
    scan.add_argument(
        "--offer-test-template",
        action="store_true",
        help="Offer to create a starter test file if no tests are detected.",
    )
    scan.add_argument(
        "--no-offer-test-template",
        action="store_true",
        help="Do not offer test template creation.",
    )

    return parser


def cmd_setup(config_path: Path, force: bool) -> int:
    ui = BareUI()

    if config_path.exists() and not force:
        ui.warn(f"Config already exists: {config_path}")
        ui.console.print("[muted]Run: codedoctor setup --force[/muted]")
        return 0

    ui.console.print("[brand]CodeDoctor[/brand] setup")
    ui.console.print(
        "[muted]Hey There! Before you can use CodeDoctor, we just have a few questions for you...[/muted]"
    )
    ui.console.print()

    respect_gitignore = Confirm.ask(
        "Respect .gitignore for scans? (Ignore what it ignores)", default=True
    )
    apply_fixes = Confirm.ask(
        "Enable safe auto-fixes by default? (Runs fixes everytime, else use --fix)",
        default=False,
    )
    skip_tests = Confirm.ask("Skip running tests (pytest) by default?", default=False)

    reports_enabled = Confirm.ask("Write report files by default?", default=False)
    report_dir = Prompt.ask(
        "Report directory (relative to repo)", default=".codedoctor"
    )

    offer_test_template = Confirm.ask(
        "Offer to create a starter test file when no tests are detected?",
        default=True,
    )
    test_template_output = Prompt.ask(
        "Default starter test output path (relative to repo)",
        default="tests/test_smoke.py",
    )
    test_template_source = Prompt.ask(
        "Optional custom template file path (leave blank for built-in)",
        default="",
        show_default=False,
    )

    cfg = CodeDoctorConfig(
        respect_gitignore=respect_gitignore,
        apply_fixes=apply_fixes,
        skip_tests=skip_tests,
        report_dir=report_dir,
        reports_enabled=reports_enabled,
        offer_test_template=offer_test_template,
        test_template_output=test_template_output,
        test_template_source=test_template_source,
        setup_completed=True,
        last_update_check_unix=0,
    )
    save_config(cfg, path=config_path)
    ui.ok(f"Saved config: {config_path}")
    return 0


def cmd_update(yes: bool) -> int:
    ui = BareUI()
    with ui.spinner("Checking for updates"):
        res = check_for_update()

    if res.error:
        ui.warn("Update check failed.")
        ui.block("Update check details", res.error, "warn")
        return 1

    if not res.is_update_available:
        ui.ok(f"CodeDoctor is up to date ({res.installed}).")
        return 0

    ui.warn(f"Update available: {res.installed} -> {res.latest}")
    if not yes:
        if not Confirm.ask("Update now?", default=False):
            ui.ok("Canceled.")
            return 0

    with ui.spinner("Updating CodeDoctor"):
        rc = run_self_update()

    if rc == 0:
        ui.ok("Update completed.")
    else:
        ui.fail(f"Update failed (exit code {rc}).")
    return rc


def maybe_print_update_notice(cfg: CodeDoctorConfig) -> CodeDoctorConfig:
    now = int(time.time())
    if now - int(cfg.last_update_check_unix) < UPDATE_CHECK_INTERVAL_S:
        return cfg

    res = check_for_update()
    cfg2 = replace(cfg, last_update_check_unix=now)

    if res.error:
        return cfg2

    if res.is_update_available:
        # Keep notice short and clean
        print(
            f"Notice: update available ({res.installed} -> {res.latest}). "
            "Run: codedoctor update"
        )

    return cfg2


def maybe_offer_test_template(
    ui: BareUI, repo_path: Path, cfg: CodeDoctorConfig
) -> None:
    if not cfg.offer_test_template:
        return

    if has_any_pytest_tests(repo_path):
        return

    ui.warn("No tests detected in ./tests.")
    if Confirm.ask(
        f"Create a starter test file at {cfg.test_template_output}?",
        default=False,
    ):
        path = write_test_template(
            repo_path=repo_path,
            output_relpath=cfg.test_template_output,
            template_source_path=cfg.test_template_source,
        )
        ui.ok(f"Created: {path}")


def scan_repo_interactive(
    repo_path: Path,
    apply_fixes: bool,
    skip_tests: bool,
    respect_gitignore: bool,
) -> ScanReport:
    ui = BareUI()
    results: list[CheckResult] = []

    checks = build_checks(
        repo_path=repo_path,
        apply_fixes=apply_fixes,
        skip_tests=skip_tests,
        respect_gitignore=respect_gitignore,
    )

    for name, cmd in checks:
        if not cmd:
            tool = name.split(" ", 1)[0]
            r = CheckResult(
                name=name,
                command=[],
                returncode=127,
                output=(
                    f"{tool} is not installed or not on PATH.\n"
                    f"Install it with: python -m pip install {tool}"
                ),
                status=CheckStatus.FAIL,
            )
            results.append(r)
            ui.fail(f"{name}: Missing dependency.")
            ui.block(f"{name} details", r.output, "fail")
            continue

        with ui.spinner(f"Running {name}"):
            r = run_command(display_name=name, cmd=cmd, cwd=repo_path)

        if r.status == CheckStatus.PASS:
            ui.ok(f"{name} finished with no issues.")
        elif r.status == CheckStatus.FAIL:
            ui.fail(f"{name} found items that need attention.")
            ui.block(f"{name} output", r.output, "fail")
        else:
            ui.warn(f"{name} had an internal CodeDoctor warning.")
            ui.block(f"{name} details", r.output, "warn")

        results.append(r)

    passed = sum(1 for r in results if r.status == CheckStatus.PASS)
    failed = sum(1 for r in results if r.status == CheckStatus.FAIL)
    warned = sum(1 for r in results if r.status == CheckStatus.WARN)

    ui.console.print()
    ui.console.print(
        Panel(
            f"[ok]{passed} clear[/ok]  [fail]{failed} blocked[/fail]  "
            f"[warn]{warned} internal warnings[/warn]",
            title="[brand]CodeDoctor[/brand]",
            border_style="border",
            padding=(1, 2),
        )
    )

    return ScanReport(repo=str(repo_path), results=results)


def write_reports_if_enabled(
    ui: BareUI,
    repo_path: Path,
    report: ScanReport,
    report_dir: str,
    report_path: str | None,
    enable_reports: bool,
) -> None:
    if not enable_reports:
        return

    text = report.to_full_text()

    if report_path:
        out = Path(report_path).expanduser().resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
        ui.ok(f"Wrote report: {out}")
        return

    report_root = repo_path / report_dir
    paths = get_report_paths(repo_path=repo_path)
    paths = paths.__class__(
        directory=report_root,
        latest=report_root / "report-latest.txt",
        previous=report_root / "report-prev.txt",
        timestamped=report_root / paths.timestamped.name,
    )

    report_root.mkdir(parents=True, exist_ok=True)
    rotate_latest_to_previous(latest=paths.latest, previous=paths.previous)

    paths.latest.write_text(text, encoding="utf-8")
    paths.timestamped.write_text(text, encoding="utf-8")

    ui.ok(f"Wrote report: {paths.latest}")
    ui.ok(f"Wrote report: {paths.timestamped}")


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    ui = BareUI()

    config_path = Path(args.config).expanduser().resolve()
    cfg = load_config(path=config_path)

    if args.command == "setup":
        return cmd_setup(config_path=config_path, force=bool(args.force))

    if args.command == "update":
        return cmd_update(yes=bool(args.yes))

    if args.command == "scan":
        if not cfg.setup_completed and not bool(args.assume_defaults):
            ui.warn("CodeDoctor is not set up yet.")
            ui.console.print("[muted]Run: codedoctor setup[/muted]")
            ui.console.print("[muted]Or:  codedoctor scan --assume-defaults[/muted]")
            return 2

        if not bool(args.no_update_check):
            cfg2 = maybe_print_update_notice(cfg)
            if cfg2 != cfg and cfg.setup_completed:
                save_config(cfg2, path=config_path)
                cfg = cfg2

        repo_path = Path(args.path).expanduser().resolve()

        apply_fixes = bool(args.fix) or cfg.apply_fixes
        skip_tests = bool(args.skip_tests) or cfg.skip_tests
        respect_gitignore = (not bool(args.no_gitignore)) and cfg.respect_gitignore

        # Offer test template (config + flags)
        offer_override = bool(args.offer_test_template)
        offer_disable = bool(args.no_offer_test_template)
        cfg_offer = (
            cfg if not offer_override else replace(cfg, offer_test_template=True)
        )
        if offer_disable:
            cfg_offer = replace(cfg_offer, offer_test_template=False)

        maybe_offer_test_template(ui, repo_path=repo_path, cfg=cfg_offer)

        report = scan_repo_interactive(
            repo_path=repo_path,
            apply_fixes=apply_fixes,
            skip_tests=skip_tests,
            respect_gitignore=respect_gitignore,
        )

        report_dir = args.report_dir if args.report_dir is not None else cfg.report_dir
        enable_reports = (
            bool(args.report) or bool(args.report_path) or cfg.reports_enabled
        )
        write_reports_if_enabled(
            ui=ui,
            repo_path=repo_path,
            report=report,
            report_dir=report_dir,
            report_path=args.report_path,
            enable_reports=enable_reports,
        )

        return report.exit_code

    return 1
