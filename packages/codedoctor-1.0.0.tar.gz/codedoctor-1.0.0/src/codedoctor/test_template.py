from __future__ import annotations

from pathlib import Path

DEFAULT_TEMPLATE = '''\
"""
CodeDetector test templates

This file is meant to be a safe starting point, not a full test suite.
"""


def test_smoke():
    assert True
'''


def has_any_pytest_tests(repo_path: Path) -> bool:
    tests_dir = repo_path / "tests"
    if not tests_dir.is_dir():
        return False
    return any(tests_dir.rglob("test_*.py"))


def _load_template_text(source_path: str) -> str:
    if not source_path.strip():
        return DEFAULT_TEMPLATE

    p = Path(source_path).expanduser()
    if not p.exists() or not p.is_file():
        return DEFAULT_TEMPLATE

    try:
        return p.read_text(encoding="utf-8")
    except OSError:
        return DEFAULT_TEMPLATE


def write_test_template(
    repo_path: Path,
    output_relpath: str,
    template_source_path: str,
) -> Path:
    target = (repo_path / output_relpath).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)

    if target.exists():
        return target

    text = _load_template_text(template_source_path)
    target.write_text(text, encoding="utf-8")
    return target
