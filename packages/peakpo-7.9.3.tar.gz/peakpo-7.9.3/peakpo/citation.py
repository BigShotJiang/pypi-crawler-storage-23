"""
peakpo version

Todo: better system should be implemented, such as pbr.
"""

__citation__ = "S.-H. Shim (2017) PeakPo - A python software for X-ray diffraction analysis at high pressure and high temperature. Zenodo. http://doi.org/10.5281/zenodo.810199"
