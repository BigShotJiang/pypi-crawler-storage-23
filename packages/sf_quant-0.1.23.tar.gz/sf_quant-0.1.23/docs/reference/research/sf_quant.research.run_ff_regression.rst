﻿sf\_quant.research.run\_ff\_regression
======================================

.. currentmodule:: sf_quant.research

.. autofunction:: run_ff_regression