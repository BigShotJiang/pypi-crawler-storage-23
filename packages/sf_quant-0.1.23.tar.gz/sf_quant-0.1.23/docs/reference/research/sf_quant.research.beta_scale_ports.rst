﻿sf\_quant.research.beta\_scale\_ports
=====================================

.. currentmodule:: sf_quant.research

.. autofunction:: beta_scale_ports