﻿sf\_quant.research.generate\_quantile\_ports
============================================

.. currentmodule:: sf_quant.research

.. autofunction:: generate_quantile_ports