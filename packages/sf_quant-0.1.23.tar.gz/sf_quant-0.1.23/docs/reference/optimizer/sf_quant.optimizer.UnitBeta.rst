﻿sf\_quant.optimizer.UnitBeta
============================

.. currentmodule:: sf_quant.optimizer

.. autoclass:: UnitBeta

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~UnitBeta.__init__
   
   

   
   
   