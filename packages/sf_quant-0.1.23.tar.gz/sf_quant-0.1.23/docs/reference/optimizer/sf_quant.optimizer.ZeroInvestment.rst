﻿sf\_quant.optimizer.ZeroInvestment
==================================

.. currentmodule:: sf_quant.optimizer

.. autoclass:: ZeroInvestment

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ZeroInvestment.__init__
   
   

   
   
   