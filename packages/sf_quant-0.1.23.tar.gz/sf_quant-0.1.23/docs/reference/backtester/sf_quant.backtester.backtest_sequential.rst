﻿sf\_quant.backtester.backtest\_sequential
=========================================

.. currentmodule:: sf_quant.backtester

.. autofunction:: backtest_sequential