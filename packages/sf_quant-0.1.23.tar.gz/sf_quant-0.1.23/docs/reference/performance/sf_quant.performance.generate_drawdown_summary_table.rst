﻿sf\_quant.performance.generate\_drawdown\_summary\_table
========================================================

.. currentmodule:: sf_quant.performance

.. autofunction:: generate_drawdown_summary_table