﻿sf\_quant.performance.generate\_drawdown\_from\_returns
=======================================================

.. currentmodule:: sf_quant.performance

.. autofunction:: generate_drawdown_from_returns