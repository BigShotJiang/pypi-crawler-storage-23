﻿sf\_quant.performance.generate\_multi\_returns\_chart
=====================================================

.. currentmodule:: sf_quant.performance

.. autofunction:: generate_multi_returns_chart