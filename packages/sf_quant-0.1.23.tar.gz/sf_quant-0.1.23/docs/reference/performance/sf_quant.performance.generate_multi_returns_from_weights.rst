﻿sf\_quant.performance.generate\_multi\_returns\_from\_weights
=============================================================

.. currentmodule:: sf_quant.performance

.. autofunction:: generate_multi_returns_from_weights