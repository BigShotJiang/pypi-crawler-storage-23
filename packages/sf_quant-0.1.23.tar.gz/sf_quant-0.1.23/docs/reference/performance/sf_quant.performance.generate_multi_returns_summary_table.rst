﻿sf\_quant.performance.generate\_multi\_returns\_summary\_table
==============================================================

.. currentmodule:: sf_quant.performance

.. autofunction:: generate_multi_returns_summary_table