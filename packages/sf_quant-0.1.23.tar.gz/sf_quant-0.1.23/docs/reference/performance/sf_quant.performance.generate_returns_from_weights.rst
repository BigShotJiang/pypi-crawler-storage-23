﻿sf\_quant.performance.generate\_returns\_from\_weights
======================================================

.. currentmodule:: sf_quant.performance

.. autofunction:: generate_returns_from_weights