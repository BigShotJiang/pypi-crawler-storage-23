﻿sf\_quant.performance.generate\_leverage\_summary\_table
========================================================

.. currentmodule:: sf_quant.performance

.. autofunction:: generate_leverage_summary_table