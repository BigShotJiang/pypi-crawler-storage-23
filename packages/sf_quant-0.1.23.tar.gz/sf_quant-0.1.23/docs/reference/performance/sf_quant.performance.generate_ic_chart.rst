﻿sf\_quant.performance.generate\_ic\_chart
=========================================

.. currentmodule:: sf_quant.performance

.. autofunction:: generate_ic_chart