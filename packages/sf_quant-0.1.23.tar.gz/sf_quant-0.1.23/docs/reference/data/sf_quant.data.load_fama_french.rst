﻿sf\_quant.data.load\_fama\_french
=================================

.. currentmodule:: sf_quant.data

.. autofunction:: load_fama_french