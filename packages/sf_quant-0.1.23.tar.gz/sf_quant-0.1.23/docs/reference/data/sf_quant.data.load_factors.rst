﻿sf\_quant.data.load\_factors
============================

.. currentmodule:: sf_quant.data

.. autofunction:: load_factors