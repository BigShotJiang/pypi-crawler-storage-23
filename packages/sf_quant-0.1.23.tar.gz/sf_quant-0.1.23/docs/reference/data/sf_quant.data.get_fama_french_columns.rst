﻿sf\_quant.data.get\_fama\_french\_columns
=========================================

.. currentmodule:: sf_quant.data

.. autofunction:: get_fama_french_columns