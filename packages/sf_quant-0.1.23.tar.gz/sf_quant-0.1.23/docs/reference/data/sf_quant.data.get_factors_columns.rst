﻿sf\_quant.data.get\_factors\_columns
====================================

.. currentmodule:: sf_quant.data

.. autofunction:: get_factors_columns