﻿sf\_quant.data.get\_crsp\_v2\_daily\_columns
============================================

.. currentmodule:: sf_quant.data

.. autofunction:: get_crsp_v2_daily_columns