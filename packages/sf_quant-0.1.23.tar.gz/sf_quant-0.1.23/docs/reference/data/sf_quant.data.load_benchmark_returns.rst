﻿sf\_quant.data.load\_benchmark\_returns
=======================================

.. currentmodule:: sf_quant.data

.. autofunction:: load_benchmark_returns