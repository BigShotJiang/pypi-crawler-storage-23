﻿sf\_quant.data.get\_assets\_columns
===================================

.. currentmodule:: sf_quant.data

.. autofunction:: get_assets_columns