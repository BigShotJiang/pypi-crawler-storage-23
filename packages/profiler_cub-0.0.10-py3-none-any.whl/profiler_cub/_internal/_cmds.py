from argparse import ArgumentParser, Namespace
from typing import TYPE_CHECKING, NamedTuple

from profiler_cub._internal.debug import _print_debug_info

if TYPE_CHECKING:
    from profiler_cub._internal.info import ExitCode, _BumpType, _Version


class _ReturnedArgs(NamedTuple):
    cmd: str
    bump_type: _BumpType
    no_color: bool


def get_args(args: list[str]) -> _ReturnedArgs:
    """Parse command-line arguments."""
    from profiler_cub._internal.info import _VALIDS

    parser = ArgumentParser(description="Pack Int CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("version", help="Get the version of the package.")
    bump_parser: ArgumentParser = subparsers.add_parser("bump", help="Bump the version of the package.")
    bump_parser.add_argument(
        "bump_type",
        type=str,
        choices=_VALIDS,
        help="Type of version bump (major, minor, patch).",
    )
    debug_parser: ArgumentParser = subparsers.add_parser("debug", help="Print debug information.")
    debug_parser.add_argument(
        "--no-color",
        "-n",
        action="store_true",
        help="Disable colored output.",
    )
    parsed: Namespace = parser.parse_args(args)
    return _ReturnedArgs(
        cmd=parsed.command,
        bump_type=getattr(parsed, "bump_type", "patch"),
        no_color=getattr(parsed, "no_color", False),
    )


def get_version() -> ExitCode:
    """CLI command to get the version of the package."""
    from profiler_cub._internal.info import METADATA, ExitCode

    print(METADATA.version)
    return ExitCode.SUCCESS


def bump_version(b: _BumpType) -> ExitCode:
    """Bump the version of the current package.

    Args:
        b: The type of bump ("major", "minor", or "patch").
        v: A Version instance representing the current version.

    Returns:
        An ExitCode indicating success or failure.
    """
    from profiler_cub._internal.info import _VALIDS, METADATA, ExitCode

    v: _Version = METADATA.version_tuple
    if b not in _VALIDS:
        print(f"Invalid argument '{b}'. Use one of: {', '.join(_VALIDS)}.")
        return ExitCode.FAILURE

    if v == (0, 0, 0):
        print("Current version is 0.0.0, cannot bump version.")
        return ExitCode.FAILURE
    try:
        new_version: _Version = v.new_version(b)
        print(str(new_version))
        return ExitCode.SUCCESS
    except ValueError:
        print(f"Invalid version tuple: {v}")
        return ExitCode.FAILURE


def debug_info(no_color: bool = False) -> ExitCode:
    """CLI command to print debug information."""
    from profiler_cub._internal.info import ExitCode

    _print_debug_info(no_color=no_color)  # pyright: ignore[reportCallIssue]
    return ExitCode.SUCCESS


# ruff: noqa: PLC0415
