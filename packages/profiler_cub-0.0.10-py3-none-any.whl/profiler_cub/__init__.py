"""Profiler Cub package.

A beautiful profiler for Python projects with various options
"""

from profiler_cub._internal.cli import main
from profiler_cub._internal.info import METADATA

__version__: str = METADATA.version

__all__: list[str] = ["METADATA", "__version__", "main"]
