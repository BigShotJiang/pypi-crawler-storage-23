"""
Celery tasks for privacy app.

Background tasks for:
- Processing scheduled account deletions (GDPR Article 17)
- Cleaning up expired data export requests
"""

import logging

from celery import shared_task
from django.db.utils import DatabaseError
from django.utils import timezone

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3)
def process_scheduled_deletions(self):
    """
    Process accounts scheduled for GDPR deletion.

    Runs daily via Celery Beat.
    Finds PrivacyProfiles where deletion_scheduled_for has passed
    and executes the erasure using GDPRDataEraser.

    Returns:
        dict: Summary of processed deletions
    """
    try:
        from nimoh_base.privacy.models import PrivacyProfile
        from nimoh_base.privacy.utils.gdpr import GDPRDataEraser

        overdue = PrivacyProfile.objects.filter(
            deletion_requested=True,
            deletion_scheduled_for__lte=timezone.now(),
        ).select_related("user")

        processed = 0
        failed = 0
        results = []

        for privacy_profile in overdue:
            user = privacy_profile.user
            try:
                # anonymize_recovery_data field was removed (domain-specific).
                # Default to always retaining audit logs during GDPR deletion — the safe choice.
                retain_audit = True
                eraser = GDPRDataEraser(user=user)
                summary = eraser.initiate_erasure(
                    reason="Scheduled GDPR deletion (grace period expired)",
                    retain_audit=retain_audit,
                )
                processed += 1
                results.append(
                    {
                        "anonymized_id": summary.get("anonymized_id"),
                        "status": "erased",
                    }
                )
                logger.info(
                    "GDPR deletion completed for user %s",
                    summary.get("anonymized_id"),
                )
            except (DatabaseError, ValueError, OSError):
                failed += 1
                logger.exception("GDPR deletion failed for user_id=%s", user.id)

        result = {
            "status": "success",
            "processed": processed,
            "failed": failed,
            "total_found": processed + failed,
        }

        logger.info(
            "Scheduled deletions processed: %d succeeded, %d failed",
            processed,
            failed,
        )
        return result

    except Exception as exc:
        logger.error("process_scheduled_deletions failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=300)


@shared_task(bind=True, max_retries=3)
def cleanup_stale_export_requests(self):
    """
    Reset data export requests older than 7 days that were never fulfilled.

    Runs daily via Celery Beat.

    Returns:
        dict: Summary of cleaned-up requests
    """
    try:
        from datetime import timedelta

        from nimoh_base.privacy.models import PrivacyProfile

        cutoff = timezone.now() - timedelta(days=7)
        stale = PrivacyProfile.objects.filter(
            data_export_requested=True,
            data_export_requested_at__lt=cutoff,
        )
        count = stale.update(
            data_export_requested=False,
            data_export_requested_at=None,
        )

        logger.info("Cleaned up %d stale data-export requests", count)
        return {"status": "success", "cleaned": count}

    except Exception as exc:
        logger.error("cleanup_stale_export_requests failed: %s", exc, exc_info=True)
        raise self.retry(exc=exc, countdown=300)
