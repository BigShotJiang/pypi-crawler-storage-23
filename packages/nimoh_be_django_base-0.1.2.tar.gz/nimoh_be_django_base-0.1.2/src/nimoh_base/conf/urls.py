"""
nimoh_base.conf.urls
====================
Default URL pattern helpers.

Add the package's built-in URL groups to a consumer project's ``urls.py``::

    from nimoh_base.conf.urls import nimoh_base_urlpatterns
    from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

    urlpatterns = [
        path('admin/', admin.site.urls),
        *nimoh_base_urlpatterns(
            api_prefix='api/v1/',
            include_schema=True,
        ),
        # consumer-project-specific routes…
    ]
"""

from django.urls import include, path


def nimoh_base_urlpatterns(
    api_prefix: str = "api/v1/",
    *,
    include_auth: bool = True,
    include_monitoring: bool = True,
    include_privacy: bool = True,
    include_schema: bool = True,
    include_health: bool = True,
) -> list:
    """
    Return a list of ``path()`` entries for all nimoh_base URL modules.

    Args:
        api_prefix:         URL prefix for all API routes (default: ``'api/v1/'``).
        include_auth:       Include authentication routes.
        include_monitoring: Include monitoring/metrics routes.
        include_privacy:    Include privacy/GDPR routes.
        include_schema:     Include OpenAPI schema endpoints (SpectacularAPIView).
        include_health:     Include the health-check endpoint.

    Returns:
        A list of ``path()`` objects ready to be spread into ``urlpatterns``.
    """
    patterns = []

    if include_auth:
        patterns.append(path(f"{api_prefix}auth/", include("nimoh_base.auth.urls")))

    if include_monitoring:
        patterns.append(path(f"{api_prefix}monitoring/", include("nimoh_base.monitoring.urls")))

    if include_privacy:
        patterns.append(path(f"{api_prefix}privacy/", include("nimoh_base.privacy.urls")))

    if include_health:
        from nimoh_base.core.health import health_check_view

        patterns.append(path(f"{api_prefix}health/", health_check_view, name="health-check"))

    if include_schema:
        try:
            from drf_spectacular.views import (
                SpectacularAPIView,
                SpectacularRedocView,
                SpectacularSwaggerView,
            )

            patterns += [
                path(f"{api_prefix}schema/", SpectacularAPIView.as_view(), name="schema"),
                path(
                    f"{api_prefix}schema/swagger-ui/",
                    SpectacularSwaggerView.as_view(url_name="schema"),
                    name="swagger-ui",
                ),
                path(
                    f"{api_prefix}schema/redoc/",
                    SpectacularRedocView.as_view(url_name="schema"),
                    name="redoc",
                ),
            ]
        except ImportError:
            pass  # drf-spectacular not installed — skip schema endpoints

    return patterns
