#!/bin/bash
exec cloak hook audit-log
