#!/bin/bash
exec cloak hook guard-read
