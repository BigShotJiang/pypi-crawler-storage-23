# omu_chat

OMUAPPSでチャットの機能を使うために使われます

OMUAPPSプロジェクトについてはこちらをご覧ください：<https://omuapps.com/>

このパッケージの使い方は
