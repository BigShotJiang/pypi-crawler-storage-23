# Temperature Logger & PID Controller — Complete Documentation

Welcome to the NEnG TMP117 instrument control suite!

## Quick Navigation

### First-time users

Start here → **[GUI_QUICKSTART.md](GUI_QUICKSTART.md)**

### Setup & installation

All tools at a glance → **[GUI_SETUP_GUIDE.md](GUI_SETUP_GUIDE.md)**

### Detailed references

| Tool | Documentation |
| --- | --- |
| `temp-logger-gui` | [GUI_README.md](GUI_README.md) |
| `temp-logger` (CLI) | [REALTIME_LOGGER_README.md](REALTIME_LOGGER_README.md) |
| `pid-controller-gui` | [GUI_SETUP_GUIDE.md](GUI_SETUP_GUIDE.md#pid-controller-gui--pid-controller-gui) |
| `scpi-client` | [GUI_SETUP_GUIDE.md](GUI_SETUP_GUIDE.md#scpi-client--interactive-scpi-terminal) |

### WiFi connectivity

- Quick WiFi setup → **[WIFI_QUICKSTART.md](WIFI_QUICKSTART.md)**
- Full WiFi guide → **[WIFI_SUPPORT.md](WIFI_SUPPORT.md)**

### macOS Tkinter installation

**[TKINTER_INSTALLATION.md](TKINTER_INSTALLATION.md)**

---

## 30-second quick start

```bash
# 1. Install
cd temp-logger
python3 -m venv .venv && source .venv/bin/activate
pip install -e .

# 2. Run any tool
temp-logger-gui          # logger GUI
pid-controller-gui       # PID controller GUI
scpi-client              # interactive SCPI terminal
temp-logger              # CLI logger with live plot
```

---

## Source files

| Module | Purpose |
| --- | --- |
| `src/temp_logger/gui_realtime_logger.py` | `temp-logger-gui` — Tkinter GUI logger |
| `src/temp_logger/pid_controller_gui.py` | `pid-controller-gui` — PID controller GUI |
| `src/temp_logger/scpi_client.py` | `scpi-client` — interactive SCPI terminal |
| `src/temp_logger/pc_realtime_logger.py` | `temp-logger` — CLI logger engine |
| `src/temp_logger/logger.py` | Shared logging / CSV backend |
| `src/temp_logger/tools/myserial/scpi_universal.py` | USB + WiFi SCPI interface |
| `src/temp_logger/tools/myserial/scpi_serial.py` | USB serial SCPI interface |

---

## Common tasks

### Log temperature data

```bash
temp-logger-gui              # GUI with live plots
temp-logger --output exp.csv # CLI with CSV export
```

### Control PID temperature

```bash
pid-controller-gui           # full GUI
scpi-client ":PID:RAMP 35,2" # single SCPI command
```

### Calibrate sensors

```bash
scpi-client
# then interactively:
#   :CONF1:OFFS -0.05
#   :CONF2:OFFS +0.02
#   :SYST:CAL:SAVE
```

### Simultaneous logging + control

```bash
# Terminal 1 — USB logging
temp-logger --output data.csv

# Terminal 2 — WiFi control
pid-controller-gui
```

---

## System requirements

- Python 3.9+
- Dependencies: `pyserial`, `numpy`, `matplotlib`, `pandas`, `psutil`
- `tkinter` (for GUIs — see [TKINTER_INSTALLATION.md](TKINTER_INSTALLATION.md) on macOS)

(c) 2024-26 Prof. Flavio ABREU ARAUJO. All rights reserved.
