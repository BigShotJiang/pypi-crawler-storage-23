#!/usr/bin/env python3
"""
SCPI Serial Interface - Easy-to-use serial connection for NEnG instruments

Provides a simple, reusable interface for communicating with SCPI instruments
via USB CDC serial connection with automatic port detection, error handling,
and convenient command/query methods.

Usage:
    from scpi_serial import SCPISerial

    # Auto-detect port
    with SCPISerial() as instr:
        print(instr.query("*IDN?"))
        instr.write("WIFI:ENABLE 1")

    # Or specify port
    with SCPISerial(port="/dev/cu.usbmodem2101") as instr:
        status = instr.query("WIFI:STATUS?")
        print(status)

(c) 2024-25 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

import platform
import time

# Ensure we load the real PySerial package (and not the similarly named 'serial' stub)
try:
    import serial as pyserial

    # PySerial exposes Serial and SerialException; if they're missing we likely imported
    # the wrong package (e.g., the 'serial' stub from PyPI).
    if not hasattr(pyserial, "Serial") or not hasattr(pyserial, "SerialException"):
        raise ImportError(
            f"Imported 'serial' from {getattr(pyserial, '__file__', 'unknown')} but it lacks Serial/SerialException"
        )

    serial = pyserial  # Alias to keep the rest of the module unchanged
    import serial.tools.list_ports  # type: ignore  # noqa: F811
except ImportError as exc:  # pragma: no cover - defensive guard
    raise ImportError(
        "PySerial is missing or shadowed by another 'serial' package. "
        "Uninstall any 'serial' package and install the correct one with 'pip install pyserial'."
    ) from exc


class SCPISerial:
    """
    Easy-to-use serial interface for SCPI instruments.

    Features:
    - Automatic port detection
    - Context manager support (with statement)
    - Simple write/query methods
    - OPC synchronization for reliable command completion
    - Built-in error handling
    - Connection verification
    - Cross-platform support (macOS, Linux, Windows)
    """

    def __init__(self, port=None, baudrate=115200, timeout=1, auto_connect=True, sync_mode=True):
        """
        Initialize SCPI serial interface.

        Args:
            port: Serial port path (e.g., "/dev/cu.usbmodem2101", "COM3")
                  If None, will attempt auto-detection
            baudrate: Serial baudrate (default: 115200)
            timeout: Read timeout in seconds (default: 1)
            auto_connect: Automatically connect on initialization (default: True)
            sync_mode: Use OPC synchronization for write commands (default: True)
        """
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self.sync_mode = sync_mode
        self.serial = None
        self._connected = False
        self._rx_partial = ""  # buffer for incomplete lines (non-blocking reads)

        if auto_connect:
            self.connect()

    def __enter__(self):
        """Context manager entry - returns connected instance"""
        if not self._connected:
            self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - closes connection"""
        self.close()
        return False

    @staticmethod
    def list_ports():
        """
        List all available serial ports with descriptions.

        Returns:
            List of tuples: [(port, description, hwid), ...]
        """
        ports = []
        for port in serial.tools.list_ports.comports():
            ports.append((port.device, port.description, port.hwid))
        return ports

    @staticmethod
    def find_neng_port():
        """
        Attempt to auto-detect NEnG instrument port.

        Looks for common USB CDC patterns:
        - macOS: /dev/cu.usbmodem*
        - Linux: /dev/ttyACM*, /dev/ttyUSB*
        - Windows: COM*

        Returns:
            Port path string or None if not found
        """
        system = platform.system()

        for port in serial.tools.list_ports.comports():
            device = port.device
            port.description.lower()

            # Check for common CircuitPython/USB CDC patterns
            if system == "Darwin":  # macOS
                if device.startswith("/dev/cu.usbmodem"):
                    return device
            elif system == "Linux":
                # Check for USB CDC and USB serial devices
                if device.startswith("/dev/ttyACM") or device.startswith("/dev/ttyUSB"):
                    return device
            elif system == "Windows" and device.startswith("COM"):
                return device

        return None

    @staticmethod
    def get_useful_ports():
        """
        Get list of potentially useful serial ports (USB, not system ports).

        Filters out system tty ports (/dev/ttyS*) which are usually not USB devices.

        Returns:
            List of tuples: [(device, description), ...]
        """
        system = platform.system()
        useful_ports = []

        for port in serial.tools.list_ports.comports():
            device = port.device
            desc = port.description

            # Filter based on platform
            if system == "Darwin":  # macOS
                # Include USB modem and serial ports
                if device.startswith("/dev/cu.usbmodem") or device.startswith("/dev/cu.usbserial"):
                    useful_ports.append((device, desc))
            elif system == "Linux":
                # Include USB CDC and USB serial, exclude system ttyS ports
                if device.startswith("/dev/ttyACM") or device.startswith("/dev/ttyUSB"):
                    useful_ports.append((device, desc))
            elif system == "Windows" and device.startswith("COM"):
                # Include COM ports (usually USB on Windows)
                useful_ports.append((device, desc))

        return useful_ports

    def connect(self):
        """
        Connect to serial port.

        If port was not specified during initialization, attempts auto-detection.

        Raises:
            serial.SerialException: If connection fails
            ValueError: If no port specified and auto-detection fails
        """
        if self._connected:
            return

        # Auto-detect port if not specified
        if self.port is None:
            self.port = self.find_neng_port()
            if self.port is None:
                available = self.get_useful_ports()
                error_msg = (
                    "❌ No compatible device found!\n"
                    "Possible causes:\n"
                    "  • Device is disconnected\n"
                    "  • Device is powered off\n"
                    "  • USB cable is loose or damaged\n"
                    "  • Device is in use by another application\n\n"
                    "Solution:\n"
                    "  1. Check the USB connection\n"
                    "  2. Check the device is powered on\n"
                    "  3. Try specifying the port explicitly\n"
                )
                if available:
                    error_msg += "\nAvailable USB ports:\n"
                    for port_name, port_desc in available:
                        error_msg += f"  • {port_name}: {port_desc}\n"
                else:
                    error_msg += "\nNo USB serial ports found on this system.\n"

                raise ValueError(error_msg)

        # Connect
        try:
            self.serial = serial.Serial(self.port, baudrate=self.baudrate, timeout=self.timeout)
            time.sleep(0.1)  # Allow connection to stabilize
            self._connected = True
        except serial.SerialException as e:
            raise serial.SerialException(f"❌ Failed to connect to {self.port}: {e}") from e

    def close(self):
        """Close serial connection"""
        if self.serial:
            self.serial.close()
        self.serial = None
        self._connected = False

    def write(self, cmd, sync=None):
        """
        Send a command to the instrument.

        Args:
            cmd: Command string (e.g., "WIFI:ENABLE 1")
            sync: Override sync_mode for this command. If None, uses self.sync_mode
                  If True, appends *OPC? and waits for completion
        """
        if not self._connected:
            raise serial.SerialException("Serial port not connected")

        # Determine if we should sync this command
        use_sync = self.sync_mode if sync is None else sync

        cmd_stripped = cmd.strip()
        is_query = cmd_stripped.endswith("?")
        is_ieee_cmd = cmd_stripped.startswith("*")

        # For non-query, non-IEEE commands with sync enabled, use OPC synchronization
        if use_sync and not is_query and not is_ieee_cmd:
            # Send command with *OPC? appended for completion detection
            cmd_to_send = f"{cmd_stripped};*OPC?\n"
            self.serial.write(cmd_to_send.encode("utf-8"))
            self.serial.flush()

            # Wait for "1" response indicating completion
            start_time = time.time()
            while (time.time() - start_time) < self.timeout:
                if self.serial.in_waiting > 0:
                    response = self.serial.readline().decode("utf-8").strip()
                    # Skip echo of the command
                    if response == cmd_stripped or response == cmd_to_send.strip():
                        continue
                    # "1" indicates OPC completion
                    if response == "1":
                        return
                    # Error response
                    if response.startswith("-") or "error" in response.lower():
                        return
                time.sleep(0.01)
        else:
            # Standard write without sync
            if not cmd_stripped.endswith("\n"):
                cmd_stripped += "\n"
            self.serial.write(cmd_stripped.encode("utf-8"))

    def write_nosync(self, cmd):
        """
        Send a command without OPC synchronization.

        Useful when you want fast execution without waiting for completion.

        Args:
            cmd: Command string
        """
        self.write(cmd, sync=False)

    def readline(self):
        """
        Read a response line from the instrument.

        Returns:
            Response string (stripped of whitespace)
        """
        if not self._connected:
            raise serial.SerialException("Serial port not connected")

        response = self.serial.readline().decode("utf-8").strip()
        return response

    def query(self, cmd, filter_echo=True):
        """
        Send a query command and read response.

        Args:
            cmd: Command string (e.g., "*IDN?")
            filter_echo: Skip lines that match the command (for DEBUG mode)

        Returns:
            Response string
        """
        if not self._connected:
            raise serial.SerialException("Serial port not connected")

        cmd_stripped = cmd.strip()

        # Flush input buffer to discard any background data/telemetry
        self.serial.reset_input_buffer()

        # Ensure newline and send
        cmd_to_send = cmd_stripped + "\n" if not cmd_stripped.endswith("\n") else cmd_stripped
        self.serial.write(cmd_to_send.encode("utf-8"))
        self.serial.flush()

        time.sleep(0.05)  # Small delay to ensure device responds

        # Read response, filtering echo if needed
        start_time = time.time()
        while (time.time() - start_time) < self.timeout:
            if self.serial.in_waiting > 0:
                response = self.serial.readline().decode("utf-8").strip()
                # Skip echo of the command in DEBUG mode
                if filter_echo and (response == cmd_stripped or response == cmd_to_send.strip()):
                    continue
                # Skip empty responses
                if not response:
                    continue
                return response
            time.sleep(0.01)

        return ""  # Timeout - no response

    def flush(self):
        """Flush serial input/output buffers"""
        if self.serial:
            self.serial.reset_input_buffer()
            self.serial.reset_output_buffer()

    def ensure_connected(self):
        """
        Ensure serial is connected. Reconnect if needed.

        Returns:
            True if connected, False otherwise
        """
        if not self._connected:
            try:
                self.connect()
            except Exception:
                return False
        return True

    @property
    def connected(self):
        """Check if connected to instrument."""
        return self._connected

    @property
    def port_name(self):
        """Get connected port name (or a friendly fallback)."""
        return self.port if self.port else "Not connected"

    def read_all(self):
        """
        Read all available data from serial buffer.

        Returns:
            String with all available data
        """
        if not self._connected:
            return ""

        data = ""
        try:
            while self.serial.in_waiting:
                data += self.serial.read(self.serial.in_waiting).decode("utf-8")
        except Exception:
            pass
        return data

    def read_until(self, terminator="\n", timeout=2.0):
        """
        Read until a terminator is found or timeout.

        Args:
            terminator: String to stop reading (default: "\n")
            timeout: Maximum time to wait in seconds

        Returns:
            String read (including terminator if found)
        """
        start_time = time.time()
        buffer = ""

        while True:
            if time.time() - start_time > timeout:
                return buffer

            if self.serial.in_waiting:
                buffer += self.serial.read(self.serial.in_waiting).decode("utf-8")
                if terminator in buffer:
                    return buffer

            time.sleep(0.01)

    def __repr__(self):
        return f"SCPISerial(port={self.port}, connected={self._connected})"


# Compatibility alias
SCPI_Serial = SCPISerial


if __name__ == "__main__":
    """Quick test when run directly"""
    try:
        with SCPISerial() as instr:
            print(f"Connected to {instr.port}")
            print(instr.query("*IDN?"))
    except Exception as e:
        print(f"Error: {e}")
