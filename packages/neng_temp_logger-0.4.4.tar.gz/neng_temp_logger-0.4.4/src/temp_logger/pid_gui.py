"""Entry point for the ``pid-controller-gui`` command.

(c) 2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

from __future__ import annotations

import sys
import tkinter as tk

from . import __version__
from .pid_controller_gui import PIDControllerGUI


def main() -> None:
    """Launch the PID Controller GUI."""
    if len(sys.argv) > 1 and sys.argv[1] in ("--version", "-V"):
        print(f"pid-controller-gui {__version__}")
        return
    root = tk.Tk()
    _app = PIDControllerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
