"""Entry point for the ``tmp117-scan`` command.

(c) 2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

from __future__ import annotations

import sys

from . import __version__
from .device_scanner import main as scanner_main


def main() -> int:
    """Launch the TMP117 device scanner."""
    if len(sys.argv) > 1 and sys.argv[1] in ("--version", "-V"):
        print(f"tmp117-scan {__version__}")
        return 0
    return scanner_main()


if __name__ == "__main__":
    sys.exit(main())
