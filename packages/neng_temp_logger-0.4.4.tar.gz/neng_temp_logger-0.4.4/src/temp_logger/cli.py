"""Console entrypoint for Temp Logger.

Launches the CLI real-time logger (matplotlib plots + CSV).

(c) 2025-26 Prof. Flavio ABREU ARAUJO. All rights reserved.
"""

from __future__ import annotations

import sys

from . import __version__
from .pc_realtime_logger import main as pc_main


def main() -> int:
    """Entry point for ``temp-logger`` command with full WiFi support."""
    if len(sys.argv) > 1 and sys.argv[1] in ("--version", "-V"):
        print(f"temp-logger {__version__}")
        return 0
    return pc_main()
