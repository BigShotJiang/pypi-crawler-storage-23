# TMP117 Device Scanner

Fast network scanner for discovering TMP117 temperature instruments on port 5025.

## Overview

The `tmp117-scan` tool scans **all your network interfaces** (WiFi, Ethernet, VLANs, bridges) to find TMP117 devices. It uses concurrent TCP port scanning for speed (~3-5 seconds for a /24 network) and verifies devices by querying the SCPI `*IDN?` command.

**NEW**: Multi-network auto-detection now scans all active network interfaces simultaneously, finding devices even when they're on a different subnet than your primary network connection.

## Installation

The scanner is installed automatically with the `neng-temp-logger` package:

```bash
pip install neng-temp-logger
```

Or for development:

```bash
cd TMP117/Python/temp-logger
pip install -e .
```

## Quick Start

### Scan All Network Interfaces (Recommended)

```bash
tmp117-scan
```

This will:

1. Auto-detect **all network interfaces** (WiFi, Ethernet, VLANs, bridges)
2. Scan all networks concurrently for devices on port 5025
3. Verify each device with `*IDN?` query
4. Display results in a formatted table

Example output when multiple networks are detected:

```txt
Scanning 3 network(s) for TMP117 devices...
  • 192.168.1.0/24
  • 10.104.32.0/24
  • 130.104.134.0/24

======================================================================
Found 1 TMP117 device(s):
======================================================================
  • 10.104.32.54    - NEnG,TMP117-PID,SN001,v1.0
======================================================================
Scan completed in 5.12s
```

### Scan Specific Network

```bash
tmp117-scan -n 192.168.1.0/24
```

### Verbose Mode

See detailed scanning progress:

```bash
tmp117-scan -v
```

Output:

```txt
Auto-detected network: 192.168.1.0/24
Scanning 192.168.1.0/24 (254 hosts) for port 5025...
  Port 5025 open: 192.168.1.100
  ✓ TMP117 found: 192.168.1.100 → NEnG,TMP117-PID,SN001,v1.0
Verifying 1 device(s)...

======================================================================
Found 1 TMP117 device(s):
======================================================================
  • 192.168.1.100   - NEnG,TMP117-PID,SN001,v1.0
======================================================================
Scan completed in 4.23s
```

## Output Formats

### Table (Default)

Human-friendly formatted table:

```bash
tmp117-scan
```

### JSON

Machine-readable JSON output:

```bash
tmp117-scan --json
```

Output:

```json
{
  "devices": [
    {
      "ip": "192.168.1.100",
      "id": "NEnG,TMP117-PID,SN001,v1.0"
    }
  ],
  "count": 1
}
```

### Simple

IP addresses only (one per line):

```bash
tmp117-scan --simple
```

Output:

```txt
192.168.1.100
```

## Saving Results

Save scan results to a file:

```bash
tmp117-scan -o devices.txt
tmp117-scan --json -o devices.json
```

## Advanced Usage

### Scan Large Networks

For larger networks, increase the number of concurrent workers:

```bash
tmp117-scan -n 10.0.0.0/16 -w 200
```

Default is 100 workers, which is optimal for most /24 networks.

### Custom Port

If your devices use a non-standard port:

```bash
tmp117-scan -p 5555
```

### Multiple Networks

**Automatic**: The scanner now automatically detects and scans all network interfaces concurrently without any configuration.

If you want to scan **specific** multiple networks only:

```bash
tmp117-scan -n 192.168.1.0/24 -o net1.txt
tmp117-scan -n 192.168.2.0/24 -o net2.txt
cat net1.txt net2.txt
```

But in most cases, simply running `tmp117-scan` will find all devices across all your networks.

## Performance

Scan times for typical networks (on modern hardware):

| Network Size | Hosts | Time (approx) |
|--------------|-------|---------------|
| /24          | 254   | 3-5 seconds   |
| /23          | 510   | 6-8 seconds   |
| /22          | 1022  | 12-15 seconds |
| /16          | 65534 | 10-15 minutes |

Performance tips:

- **Timeout tuning**: Default is 0.5s for port check, 1.5s for SCPI
- **Worker count**: 100-200 threads is optimal for local networks
- **Network targeting**: Scan only your subnet, not entire address spaces

## Troubleshooting

### No Devices Found

1. **Verify device is on network**:

   ```bash
   scpi-client ":WIFI:IP?"  # Check device IP via USB
   ```

2. **Verify device is reachable**:

   ```bash
   ping 192.168.1.100
   ```

3. **Test port manually**:

   ```bash
   nc -zv 192.168.1.100 5025
   ```

4. **Check firewall**: Ensure port 5025 is not blocked

### Device Not Found with Auto-Detection

The scanner auto-detects **all network interfaces**, so this should be rare. If a device is still not found:

1. **Verify device is connected to a network you have access to**
2. **Manually specify the network** if you know which one the device is on:

   ```bash
   tmp117-scan -n 192.168.1.0/24
   ```

3. **Use verbose mode** to see all networks being scanned:

   ```bash
   tmp117-scan -v
   ```

### Slow Scanning

Increase worker count for faster scanning:

```bash
tmp117-scan -w 200
```

Or reduce network size:

```bash
tmp117-scan -n 192.168.1.100/29  # Only scan 192.168.1.97-102
```

## Integration Examples

### Use with Other Tools

```bash
# Find devices and connect with scpi-client
IP=$(tmp117-scan --simple | head -1)
scpi-client -w $IP "*IDN?"

# Start logger on first found device
tmp117-scan --simple | head -1 | xargs -I {} temp-logger --wifi {}
```

### Scripting

```python
#!/usr/bin/env python3
import subprocess
import json

# Run scanner and get JSON output
result = subprocess.run(
    ["tmp117-scan", "--json"],
    capture_output=True,
    text=True
)

devices = json.loads(result.stdout)
print(f"Found {devices['count']} device(s)")

for device in devices['devices']:
    print(f"  {device['ip']}: {device['id']}")
```

## Command Reference

```txt
usage: tmp117-scan [-h] [-n NETWORK] [-p PORT] [-w WORKERS] [-o OUTPUT] [-v]
                   [--json | --simple]

optional arguments:
  -h, --help            Show help message
  -n, --network NETWORK Network in CIDR notation (e.g., 192.168.1.0/24)
  -p, --port PORT       SCPI port to scan (default: 5025)
  -w, --workers WORKERS Number of parallel threads (default: 100)
  -o, --output OUTPUT   Save results to file
  -v, --verbose         Show detailed progress
  --json                Output as JSON
  --simple              Output only IP addresses
  --version, -V         Show version number
```

## See Also

- [WiFi Quick Start](WIFI_QUICKSTART.md) - Configure WiFi on devices
- [WiFi Support](WIFI_SUPPORT.md) - Full WiFi documentation
- [SCPI Client](README.md) - Send SCPI commands to devices

---

(c) 2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
