# Temp Logger

Real-time temperature logger and instrument control suite for NEnG TMP117 PID instruments.

## Tools included

| Command | Description |
| --- | --- |
| `temp-logger` | CLI real-time logger with live matplotlib plots and CSV export |
| `temp-logger-gui` | Tkinter GUI logger with embedded plots, dark theme, WiFi/USB support |
| `pid-controller-gui` | PID temperature controller GUI — ramp control, tuning, TEC, live graphs |
| `wifi-config-gui` | WiFi configuration GUI — network management, status monitoring, SCPI console |
| `scpi-client` | Interactive SCPI terminal with tab-completion, history, pretty-printed output |
| `tmp117-scan` | Fast network scanner to discover TMP117 devices on port 5025 |
| `update-firmware` | OTA firmware updater — single/batch file upload, git-aware deployment |

All connection-based tools support **USB serial** and **WiFi/TCP** connections.
WiFi lets you log data and control the instrument simultaneously from two terminals.
See [WIFI_SUPPORT.md](https://gitlab.flavio.be/flavio/temp-logger/-/blob/main/WIFI_SUPPORT.md) for details.

This directory is a **standalone, pip-installable** Python package.

## Install

### Recommended: Install from PyPI

```bash
pip install neng-temp-logger
```

### Development install from source (editable mode)

Clone the repository and install in editable mode:

```bash
git clone git@gitlab.flavio.be:flavio/temp-logger.git
cd temp-logger
python3 -m venv .venv
source .venv/bin/activate        # macOS / Linux
python -m pip install -U pip
python -m pip install -e .
```

### Tkinter on macOS

The GUI tools require Tkinter. On macOS it may be missing depending on how
Python was installed. See [TKINTER_INSTALLATION.md](https://gitlab.flavio.be/flavio/temp-logger/-/blob/main/TKINTER_INSTALLATION.md).

```bash
brew install tcl-tk
brew install python-tk@3.xx      # replace xx with your Python minor version
```

## Run

### Temperature logger (GUI)

```bash
temp-logger-gui
```

### Temperature logger (CLI)

```bash
temp-logger                      # auto-detect port, live plot
temp-logger --no-plot            # headless (data-only)
temp-logger --output exp1.csv    # custom output file
temp-logger --wifi 192.168.1.100 # force WiFi connection
```

### PID controller GUI

```bash
pid-controller-gui               # auto-connects USB or WiFi
```

### WiFi configuration GUI

```bash
wifi-config-gui                  # manage WiFi networks and settings
```

**IMPORTANT:** CIRCUITPY must be unmounted for WiFi configuration changes to persist!

```bash
diskutil unmount /Volumes/CIRCUITPY   # macOS
umount /media/$USER/CIRCUITPY         # Linux
```

### Interactive SCPI terminal

```bash
scpi-client                     # USB auto-detect, interactive
scpi-client -w                  # WiFi auto-detect (scans all networks)
scpi-client -w 192.168.1.100    # WiFi with explicit IP
scpi-client "*IDN?"             # single command, then exit
```

**NEW**: `scpi-client -w` (without IP) auto-detects devices across **all network interfaces**.

### Network device scanner

```bash
tmp117-scan                     # scan ALL network interfaces (WiFi, Ethernet, VLANs)
tmp117-scan -n 192.168.1.0/24   # scan specific network
tmp117-scan -v                  # verbose mode
tmp117-scan --json              # JSON output
```

**NEW**: Auto-detection now scans **all network interfaces** — finds devices even on different subnets.

### OTA firmware update

```bash
# Auto-detect device on ALL networks (WiFi, Ethernet, VLANs)
update-firmware --git-deploy --yes --reboot                         # easiest method!

# Explicit IP for specific device
update-firmware 192.168.1.100 code.py --password 'pass' --reboot   # single file
update-firmware 192.168.1.100 code.py boot.py --password 'pass'    # batch upload
update-firmware 192.168.1.100 --git-deploy --password 'pass'       # git-aware deploy
update-firmware 192.168.1.100 --git-deploy --dry-run               # preview changes
update-firmware 192.168.1.100 --git-deploy --force-full --reboot   # full redeploy

# Scan specific network if auto-detect fails
update-firmware --scan-network 10.104.32.0/24 --git-deploy --yes --reboot
```

**NEW**:

- **Auto-detection** now scans **all network interfaces** — no IP needed!
- **Git-aware deployment** uploads only changed files (97% bandwidth savings)
- **10-12x faster** upload speeds (~50-100 KB/s with optimized TCP buffers)
- **File deletion** support for removed files from git repo

See [OTA_QUICK_START.md](https://gitlab.flavio.be/flavio/temp-logger/-/blob/main/OTA_QUICK_START.md) for complete guide.

## Documentation index

| File | Description |
| --- | --- |
| [GUI_QUICKSTART.md](https://gitlab.flavio.be/flavio/temp-logger/-/blob/main/GUI_QUICKSTART.md) | 60-second getting started for `temp-logger-gui` |
| [GUI_README.md](https://gitlab.flavio.be/flavio/temp-logger/-/blob/main/GUI_README.md) | Detailed `temp-logger-gui` reference |
| [REALTIME_LOGGER_README.md](https://gitlab.flavio.be/flavio/temp-logger/-/blob/main/REALTIME_LOGGER_README.md) | CLI `temp-logger` documentation |
| [DEVICE_SCANNER.md](https://gitlab.flavio.be/flavio/temp-logger/-/blob/main/DEVICE_SCANNER.md) | Network scanner for discovering TMP117 devices |
| [WIFI_SUPPORT.md](https://gitlab.flavio.be/flavio/temp-logger/-/blob/main/WIFI_SUPPORT.md) | WiFi/TCP connection guide |
| [WIFI_QUICKSTART.md](https://gitlab.flavio.be/flavio/temp-logger/-/blob/main/WIFI_QUICKSTART.md) | Quick WiFi setup |
| [TKINTER_INSTALLATION.md](https://gitlab.flavio.be/flavio/temp-logger/-/blob/main/TKINTER_INSTALLATION.md) | Tkinter setup for macOS |
| [RELEASE_CHECKLIST.md](https://gitlab.flavio.be/flavio/temp-logger/-/blob/main/RELEASE_CHECKLIST.md) | Release process and checklist |

## Notes

- USB serial communicates via CDC at 115 200 baud.
- WiFi/TCP uses port 5025 (standard SCPI-over-TCP).
- Only **one** application can use USB serial at a time; WiFi allows a second simultaneous connection.

(c) 2024-26 Prof. Flavio ABREU ARAUJO. All rights reserved.
