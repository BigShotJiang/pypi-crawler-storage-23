# Quick Start: WiFi Logging

## The Problem

When using the temperature logger via USB, the serial port is occupied and
you cannot send SCPI commands from a second application simultaneously.

## The Solution

Use WiFi for one tool and USB for the other!

## Setup WiFi (one-time, on the device)

### Option 1: Use the WiFi Config GUI (Recommended)

**IMPORTANT:** Unmount CIRCUITPY first for changes to persist!

```bash
diskutil unmount /Volumes/CIRCUITPY   # macOS
umount /media/$USER/CIRCUITPY         # Linux
```

Then launch the GUI:

```bash
wifi-config-gui
```

The GUI provides:

- Network scanning and selection
- Password entry dialogs
- Add/remove fallback networks
- Connection status monitoring
- Live SCPI console

### Option 2: Manual Configuration

Create a file `wifi_config.txt` on the CIRCUITPY USB drive:

```txt
ssid=YourLabWiFiName
password=YourWiFiPassword
```

Reboot the board. The firmware reads this file at startup and connects
automatically. The assigned IP is printed on the serial console.

### Verify Connection

```bash
scpi-client ":WIFI:CONNECTED?"   # → 1
scpi-client ":WIFI:IP?"          # → 192.168.x.x
```

## Start Logging (auto-detect mode)

```bash
# Logger will auto-discover WiFi IP and connect
temp-logger
```

The logger will:

1. Connect via USB briefly.
2. Query `:WIFI:IP?` to get the IP address.
3. Disconnect USB.
4. Connect via WiFi (TCP port 5025).
5. Start logging.

## Send Commands via USB (while logging runs on WiFi)

```bash
# In another terminal
scpi-client ":PID:ENAB ON"
scpi-client ":PID:SETP 25"
scpi-client ":PID:STAT?"
```

Or use the PID controller GUI:

```bash
pid-controller-gui
```

## GUI Quick Start

1. Launch: `temp-logger-gui`
2. Connection dropdown: select **"Auto (WiFi → USB)"** (default).
3. Click **START**.
4. USB is now free for `scpi-client` or `pid-controller-gui`!

## Troubleshooting

### Can't auto-discover WiFi IP?

Manually specify it:

```bash
temp-logger --wifi 192.168.1.100
```

Or in the GUI: select "Force WiFi", enter the IP, click START.

### WiFi not configured?

Create `wifi_config.txt` on the CIRCUITPY drive (see above) and reboot.

### Force USB mode

```bash
temp-logger --prefer-usb
```

Or in the GUI: select "Force USB".

## More Information

- Full WiFi documentation: [WIFI_SUPPORT.md](WIFI_SUPPORT.md)
- Implementation details: [WIFI_IMPLEMENTATION.md](WIFI_IMPLEMENTATION.md)

(c) 2024-26 Prof. Flavio ABREU ARAUJO. All rights reserved.
