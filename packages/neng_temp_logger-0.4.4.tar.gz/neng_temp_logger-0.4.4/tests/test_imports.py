"""Smoke tests — verify the package is importable and version is sane."""

from __future__ import annotations

import os
import re


def test_package_imports():
    import temp_logger  # noqa: F401
    from temp_logger.tools.myserial import SCPISerial  # noqa: F401


def test_version_format():
    from temp_logger import __version__

    assert re.match(r"^\d+\.\d+\.\d+", __version__), (
        f"Version string {__version__!r} does not look like semver"
    )


def test_entry_points_importable():
    """All entry point modules must be importable without side-effects.

    Skip GUI imports in headless environments (CI/CD runners).
    """
    # CLI entry point is always importable
    from temp_logger import cli  # noqa: F401

    # GUI imports require Tkinter and display — skip in CI
    if os.environ.get("DISPLAY") or os.environ.get("CI") is None:
        from temp_logger import gui, pid_gui  # noqa: F401
