#!/bin/bash

# brew install tcl-tk

#? For Python 3.9
# brew install python@3.9 python-tk@3.9
python3.9 -m tkinter
python3.9 -m temp_logger.gui
python3.9 -m pip list | grep temp-logger
python3.9 -m pytest

#? For Python 3.10
# brew install python@3.10 python-tk@3.10
python3.10 -m tkinter
python3.10 -m temp_logger.gui
python3.10 -m pip list | grep temp-logger
python3.10 -m pytest

#? For Python 3.11
# brew install python@3.11 python-tk@3.11
python3.11 -m tkinter
python3.11 -m temp_logger.gui
python3.11 -m pip list | grep temp-logger
python3.11 -m pytest

#? For Python 3.12
# brew install python@3.12 python-tk@3.12
python3.12 -m tkinter
python3.12 -m temp_logger.gui
python3.12 -m pip list | grep temp-logger
python3.12 -m pytest

#? For Python 3.13
# brew install python@3.13 python-tk@3.13
python3.13 -m tkinter
python3.13 -m temp_logger.gui
python3.13 -m pip list | grep temp-logger
python3.13 -m pytest

#? For Python 3.14
# brew install python@3.14 python-tk@3.14
python3.14 -m tkinter
python3.14 -m temp_logger.gui
python3.14 -m pip list | grep temp-logger
python3.14 -m pytest
