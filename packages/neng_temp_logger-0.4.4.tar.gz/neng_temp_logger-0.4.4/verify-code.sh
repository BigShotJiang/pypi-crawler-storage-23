#!/bin/bash
# ============================================================================
# Verification Script for temp-logger
#
# Runs linting (ruff) and tests to ensure code quality.
# Usage: ./verify-code.sh [--fix] [--no-tests]
#
# Options:
#   --fix         Apply automatic fixes with ruff
#   --no-tests    Skip running tests
# ============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FIX=false
RUN_TESTS=true

# Parse arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --fix)
            FIX=true
            shift
            ;;
        --no-tests)
            RUN_TESTS=false
            shift
            ;;
        *)
            echo "Unknown option: $1"
            echo "Usage: $0 [--fix] [--no-tests]"
            exit 1
            ;;
    esac
done

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
RESET='\033[0m'

echo -e "${BLUE}${BOLD}════════════════════════════════════════════════${RESET}"
echo -e "${BLUE}${BOLD}  Code Verification: temp-logger${RESET}"
echo -e "${BLUE}${BOLD}════════════════════════════════════════════════${RESET}\n"

# Check if ruff is installed (use python3 -m for CI compatibility)
if ! python3 -m ruff --version &> /dev/null; then
    echo -e "${RED}✗ ruff not found!${RESET}"
    echo "Install with: pip install ruff"
    exit 1
fi

# ============================================================================
# 1. RUFF LINTING
# ============================================================================
echo -e "${BLUE}${BOLD}1. Ruff Linting${RESET}"
echo "───────────────────────────────────────────────────"

if [ "$FIX" = true ]; then
    echo -e "${YELLOW}Applying automatic fixes...${RESET}\n"
    python3 -m ruff check src/ tests/ --fix || true
    python3 -m ruff format src/ tests/ 2>/dev/null || true
else
    echo -e "${YELLOW}Checking code style...${RESET}\n"
    RUFF_EXIT=0
    python3 -m ruff check src/ tests/ || RUFF_EXIT=$?

    if [ $RUFF_EXIT -eq 0 ]; then
        echo -e "\n${GREEN}✓ All checks passed!${RESET}"
    else
        echo -e "\n${RED}✗ Linting issues found. Fix with: ./verify-code.sh --fix${RESET}"
        exit 1
    fi
fi

echo ""

# ============================================================================
# 2. TYPE CHECKING (optional - requires mypy/pyright)
# ============================================================================
if command -v mypy &> /dev/null; then
    echo -e "${BLUE}${BOLD}2. Type Checking (mypy)${RESET}"
    echo "───────────────────────────────────────────────────"
    mypy src/ --ignore-missing-imports 2>/dev/null || {
        echo -e "${YELLOW}⚠ Type check warnings (non-critical)${RESET}"
    }
    echo ""
fi

# ============================================================================
# 3. PYTEST
# ============================================================================
if [ "$RUN_TESTS" = true ]; then
    echo -e "${BLUE}${BOLD}3. Unit Tests (pytest)${RESET}"
    echo "───────────────────────────────────────────────────\n"

    # Check if pytest is installed (use python3 -m for CI compatibility)
    if ! python3 -m pytest --version &> /dev/null; then
        echo -e "${RED}✗ pytest not found!${RESET}"
        echo "Install with: pip install pytest"
        exit 1
    fi

    if python3 -m pytest tests/ -v --tb=short; then
        echo -e "\n${GREEN}✓ All tests passed!${RESET}"
    else
        echo -e "\n${RED}✗ Tests failed!${RESET}"
        exit 1
    fi
    echo ""
fi

# ============================================================================
# SUMMARY
# ============================================================================
echo -e "${BLUE}${BOLD}════════════════════════════════════════════════${RESET}"
echo -e "${GREEN}${BOLD}  ✓ Code Verification Complete!${RESET}"
echo -e "${BLUE}${BOLD}════════════════════════════════════════════════${RESET}"
echo ""
echo -e "Versions:"
echo -e "  ruff:  $(python3 -m ruff --version)"
echo -e "  pytest: $(python3 -m pytest --version 2>/dev/null || echo 'not installed')"
echo ""
