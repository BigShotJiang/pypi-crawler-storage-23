#!/usr/bin/env python

# PYTHON_ARGCOMPLETE_OK
import argparse
import os
import re
import time
import pywikibot
from pywikibot import config as pwb_config
from pywikibot.specialbots import UploadRobot

try:
    import argcomplete
except ImportError:
    argcomplete = None

pwb_config.put_throttle = 0

site = pywikibot.Site()

ALLOWED_EXTENSIONS = ('.bmp', '.gif', '.png', '.jpg', '.jpeg', '.webp', '.webm', '.mkv', '.mp3', '.opus', '.ogg', '.pdf', '.djvu')
ILLEGAL_COMMONS_TITLE_CHARS_RE = re.compile(r'[\x00-\x1f\x7f#<>\[\]|{}]')


def collect_files(recursive: bool) -> list[str]:
    if recursive:
        files: list[str] = []
        for root, dirs, filenames in os.walk('.', topdown=True):
            dirs[:] = [d for d in dirs if not d.startswith('.')]
            for filename in filenames:
                if filename.startswith('.'):
                    continue
                if filename.lower().endswith(ALLOWED_EXTENSIONS):
                    files.append(os.path.relpath(os.path.join(root, filename), '.'))
        return sorted(files)

    return sorted([
        f
        for f in os.listdir('.')
        if not f.startswith('.')
        and os.path.isfile(f)
        and f.lower().endswith(ALLOWED_EXTENSIONS)
    ])


def enable_autocomplete(parser: argparse.ArgumentParser) -> None:
    if argcomplete is not None:
        argcomplete.autocomplete(parser)


def sanitize_commons_filename(filename: str) -> str:
    sanitized = ILLEGAL_COMMONS_TITLE_CHARS_RE.sub('_', filename)
    # MediaWiki treats "_" as a space in titles, so remove both before "." or ","
    sanitized = re.sub(r'[_\s]+([.,])', r'\1', sanitized)
    sanitized = re.sub(r'\s+', ' ', sanitized).strip()
    return sanitized


def build_description(description: str, source: str, _author: str, date: str, license: str, categories: list[str]) -> str:

    site.login()
    author = f'[[User:{site.user()}|{site.user()}]]' if _author == 'me' else _author
    categories_block = '\n'.join(f'[[Category:{category}]]' for category in categories)
    if categories_block:
        categories_block += '\n'

    return f'''=={{{{int:filedesc}}}}==
{{{{Information
|description={{{{en|1={description}}}}}
|source={source}
|author={author}
|date={date}
}}}}

=={{{{int:license-header}}}}==
{{{{{license}}}}}

{categories_block}

[[Category:Uploaded with pwb wrapper script by Vitaly Zdanevich]]
'''

def upload_to_commons(file_path: str, description: str, _target: str | None = None, prefix: str | None = None) -> None:
    target = sanitize_commons_filename(_target or os.path.basename(file_path))
    if prefix:
        target = f'{prefix}{target}'

    file_page = pywikibot.FilePage(site, f'File:{target}')
    if file_page.exists():
        print(f'Skipping existing file on Commons: {target}')
        return

    bot = UploadRobot(
        file_path,
        description=description,
        use_filename=target,
        keep_filename=True,
        verify_description=False,
        # Uncomment only for unattended batch uploads where duplicate-content
        # warnings should be auto-skipped (`duplicate` is based on SHA-1
        # content hash, not the filename).
        # ignore_warning=['duplicate'],
    )
    bot.run()

def main() -> None:
    print(f'Pywikibot version: {pywikibot.__version__}')

    parser = argparse.ArgumentParser(description='Upload a file to Wikimedia Commons using Pywikibot as a library. Its simpler to use than the official pwb.')
    parser.add_argument('--file', required=False, help='OPTIONAL Path to the local file to upload')
    parser.add_argument('file_posit', nargs='?', help='OPTIONAL Path to the local file to upload')
    parser.add_argument('--source', required=False, help='OPTIONAL For example https://example.com/image', default='{{own}}')
    parser.add_argument('--author', required=False, help='OPTIONAL for the current user use "me"', default = '')
    parser.add_argument('--license', required=False, help='OPTIONAL for example PD-old, default is cc-by-4.0', default='cc-by-4.0')
    parser.add_argument('--category', required=False, action='append', default=[], help='OPTIONAL without brackets. Repeat for multiple categories')
    parser.add_argument('--date', required=False, help='OPTIONAL YYYY-MM-DD, for example 2025-12-27')
    parser.add_argument('--desc', required=False, help='OPTIONAL Short description of the file')
    target_group = parser.add_mutually_exclusive_group()
    target_group.add_argument('--target', required=False, help='OPTIONAL target filename on Commons. Ignored if no file specified (if uploading all here)')
    target_group.add_argument('--prefix', required=False, help='OPTIONAL prefix filename on Commons')
    parser.add_argument('--i', required=False, default = 0, help='OPTIONAL start from the specified index', type=int)
    parser.add_argument('--recursive', action='store_true', help='OPTIONAL upload files from subfolders too (only when no file specified)')

    enable_autocomplete(parser)
    args = parser.parse_args()
    categories: list[str] = []
    for category in args.category:
        normalized_category = category.strip()
        if normalized_category and normalized_category not in categories:
            categories.append(normalized_category)

    if args.file_posit and os.path.isfile(args.file_posit):
        description = build_description(args.desc, args.source, args.author, args.date, args.license, categories)
        upload_to_commons(args.file_posit, description, args.target, args.prefix)
    elif args.file and os.path.isfile(args.file):
        description = build_description(args.desc, args.source, args.author, args.date, args.license, categories)
        upload_to_commons(args.file, description, args.target, args.prefix)
    elif args.file:
        print(f'Error: file not found: {args.file}')
        raise SystemExit(1)
    else:
        files = collect_files(args.recursive)
        for i, f in enumerate(files[args.i:], start = args.i):
            print(f'{i+1}/{len(files)}: {f} {os.path.getsize(f) / 1024 / 1024:.2f} MB')
            description = build_description(args.desc, args.source, args.author, args.date, args.license, categories)
            upload_to_commons(f, description, prefix=args.prefix)

def run_with_timer() -> None:
    start_time = time.perf_counter()
    try:
        main()
    finally:
        elapsed_seconds = int(time.perf_counter() - start_time)
        minutes, seconds = divmod(elapsed_seconds, 60)
        print(f'Total time: {minutes:02d}:{seconds:02d}')


if __name__ == '__main__':
    run_with_timer()
