"""Keywords resource for Agent Berlin SDK."""

from typing import Optional

from .._http import HTTPClient
from ..models.search import (
    ClusterKeywordsResponse,
    ClusterListResponse,
    KeywordSearchResponse,
)
from ..utils import get_project_domain


class KeywordsResource:
    """Resource for keyword operations.

    Example:
        results = client.keywords.search(query="digital marketing", limit=20)
        for kw in results.keywords:
            print(f"{kw.keyword}: volume={kw.volume}, difficulty={kw.difficulty}")
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def search(
        self,
        query: str,
        *,
        limit: Optional[int] = None,
    ) -> KeywordSearchResponse:
        """Search for keywords by semantic query.

        Returns relevant keywords with metadata including search volume,
        difficulty, CPC, and intent classification. The project domain is automatically populated.

        Args:
            query: Search query for semantic matching.
            limit: Maximum results (default: 10, max: 50).

        Returns:
            KeywordSearchResponse with matching keywords and metadata.
        """
        payload: dict[str, object] = {
            "project_domain": get_project_domain(),
            "query": query,
        }
        if limit is not None:
            payload["limit"] = limit

        data = self._http.post("/keywords/search", json=payload)
        return KeywordSearchResponse.model_validate(data)

    def list_clusters(
        self,
        *,
        representative_count: Optional[int] = None,
    ) -> ClusterListResponse:
        """List all keyword clusters with representative keywords.

        Returns a summary of all HDBSCAN clusters including their sizes and
        representative keywords (highest volume keywords in each cluster).
        The project domain is automatically populated.

        Args:
            representative_count: Number of representative keywords per cluster
                (default: 3, max: 10).

        Returns:
            ClusterListResponse with list of clusters and metadata.

        Example:
            clusters = client.keywords.list_clusters()
            for cluster in clusters.clusters:
                print(f"Cluster {cluster.cluster_id}: {cluster.size} keywords")
                print(f"  Representatives: {', '.join(cluster.representative_keywords)}")
        """
        payload: dict[str, object] = {
            "project_domain": get_project_domain(),
        }
        if representative_count is not None:
            payload["representative_count"] = representative_count

        data = self._http.post("/keywords/clusters", json=payload)
        return ClusterListResponse.model_validate(data)

    def get_cluster_keywords(
        self,
        cluster_id: int,
        *,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> ClusterKeywordsResponse:
        """Get keywords belonging to a specific cluster.

        Returns keywords from a specific cluster with pagination support.
        Use cluster_id=-1 to get noise keywords (unclustered).
        The project domain is automatically populated.

        Args:
            cluster_id: The cluster ID to fetch keywords for (-1 for noise).
            limit: Maximum keywords to return (default: 50, max: 1000).
            offset: Number of keywords to skip for pagination (default: 0).

        Returns:
            ClusterKeywordsResponse with list of keywords and pagination info.

        Example:
            # Get keywords from cluster 0
            result = client.keywords.get_cluster_keywords(0, limit=20)
            for kw in result.keywords:
                print(f"{kw.keyword}: volume={kw.volume}")

            # Get noise keywords (unclustered)
            noise = client.keywords.get_cluster_keywords(-1)
        """
        payload: dict[str, object] = {
            "project_domain": get_project_domain(),
            "cluster_id": cluster_id,
        }
        if limit is not None:
            payload["limit"] = limit
        if offset is not None:
            payload["offset"] = offset

        data = self._http.post("/keywords/clusters/keywords", json=payload)
        return ClusterKeywordsResponse.model_validate(data)
