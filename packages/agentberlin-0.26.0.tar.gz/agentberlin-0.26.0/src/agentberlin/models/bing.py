"""Pydantic models for Bing Webmaster Tools API responses."""

from typing import List, Optional

from pydantic import BaseModel, Field


class QueryStatsRow(BaseModel):
    """A single row of query statistics data."""

    query: str
    impressions: int
    clicks: int
    avg_position: float = Field(alias="avgPosition")
    avg_ctr: float = Field(alias="avgCtr")
    date: Optional[str] = None

    model_config = {"populate_by_name": True}


class QueryStatsResponse(BaseModel):
    """Response from query stats request."""

    rows: List[QueryStatsRow] = Field(default_factory=list)


class PageStatsRow(BaseModel):
    """A single row of page statistics data."""

    url: str
    impressions: int
    clicks: int
    avg_position: float = Field(alias="avgPosition")
    avg_ctr: float = Field(alias="avgCtr")

    model_config = {"populate_by_name": True}


class PageStatsResponse(BaseModel):
    """Response from page stats request."""

    rows: List[PageStatsRow] = Field(default_factory=list)


class TrafficStats(BaseModel):
    """Traffic statistics for a site."""

    date: Optional[str] = None
    impressions: int = 0
    clicks: int = 0
    avg_ctr: float = Field(default=0.0, alias="avgCtr")
    avg_imp_rank: float = Field(default=0.0, alias="avgImpRank")
    avg_click_position: float = Field(default=0.0, alias="avgClickPosition")

    model_config = {"populate_by_name": True}


class CrawlStats(BaseModel):
    """Crawl statistics for a site."""

    date: Optional[str] = None
    crawled_pages: int = Field(default=0, alias="crawledPages")
    crawl_errors: int = Field(default=0, alias="crawlErrors")
    in_index: int = Field(default=0, alias="inIndex")
    in_links: int = Field(default=0, alias="inLinks")
    blocked_by_robots_txt: int = Field(default=0, alias="blockedByRobotsTxt")
    contains_malware: int = Field(default=0, alias="containsMalware")
    http_code_error: int = Field(default=0, alias="httpCodeError")

    model_config = {"populate_by_name": True}


class SiteInfo(BaseModel):
    """Information about a site in Bing Webmaster Tools."""

    site_url: str
    is_verified: bool = True
    is_in_index: bool = True
