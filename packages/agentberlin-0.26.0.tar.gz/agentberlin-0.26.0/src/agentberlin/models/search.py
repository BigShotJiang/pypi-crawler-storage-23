"""Pydantic models for search API responses (pages, keywords)."""

from typing import List, Optional

from pydantic import BaseModel, Field


# Evidence model for page search results
class Evidence(BaseModel):
    """Evidence chunk with h_path and text."""

    h_path: Optional[str] = None
    text: str


# Topic info model
class TopicInfo(BaseModel):
    """Topic classification for a page."""

    topics: List[str] = Field(default_factory=list)
    topic_scores: List[float] = Field(default_factory=list)
    page_type: Optional[str] = None  # "pillar" or "landing"
    assigned_topic: Optional[str] = None


# Advanced page search models


class SimilarPage(BaseModel):
    """Single similar page in advanced search results."""

    target_page_url: str
    similarity_score: float
    match_type: str  # "page_to_page" or "chunk_to_page"
    chunk_text: Optional[str] = None
    page_type: Optional[str] = None  # "pillar", "landing", or None
    assigned_topic: Optional[str] = None
    # Rich fields from full search pipeline
    title: Optional[str] = None
    h1: Optional[str] = None
    meta_description: Optional[str] = None
    evidence: Optional[List[Evidence]] = None  # Top chunks with h_path + text
    domain: Optional[str] = None
    status_code: Optional[str] = None
    topic_info: Optional[TopicInfo] = None  # Full topic info


class SimilarChunkSet(BaseModel):
    """Similar pages for a specific chunk (used with deep_search)."""

    chunk_id: int
    chunk_text: str
    similar_pages: List[SimilarPage] = Field(default_factory=list)


class AdvancedPageSearchResponse(BaseModel):
    """Response for advanced page search."""

    source_page_url: Optional[str] = None
    source_page_type: Optional[str] = None  # "pillar", "landing", or None
    source_assigned_topic: Optional[str] = None
    similar_pages: List[SimilarPage] = Field(default_factory=list)
    similar_chunks: List[SimilarChunkSet] = Field(default_factory=list)


# Keyword search models


class KeywordResult(BaseModel):
    """Single keyword with metadata."""

    keyword: str
    volume: Optional[int] = None
    difficulty: Optional[int] = None  # 0-100
    cpc: Optional[float] = None
    intent: Optional[str] = None  # informational, commercial, transactional, navigational


class KeywordSearchResponse(BaseModel):
    """Response for keyword search."""

    keywords: List[KeywordResult] = Field(default_factory=list)
    total: int


# Cluster listing models


class ClusterSummary(BaseModel):
    """Single cluster summary."""

    cluster_id: int
    size: int
    representative_keywords: List[str] = Field(default_factory=list)


class ClusterListResponse(BaseModel):
    """Response for listing all clusters."""

    clusters: List[ClusterSummary] = Field(default_factory=list)
    noise_count: int
    total_keywords: int
    cluster_count: int


class ClusterKeywordResult(BaseModel):
    """Single keyword in a cluster."""

    keyword: str
    cluster_id: Optional[int] = None
    volume: Optional[int] = None
    difficulty: Optional[int] = None  # 0-100
    cpc: Optional[float] = None
    intent: Optional[str] = None


class ClusterKeywordsResponse(BaseModel):
    """Response for getting keywords in a cluster."""

    keywords: List[ClusterKeywordResult] = Field(default_factory=list)
    total: int
    cluster_id: int
    limit: int
    offset: int


# Get page models


class PageLink(BaseModel):
    """Link in page details."""

    source_url: str
    target_url: str
    anchor_text: Optional[str] = None
    domain_type: str  # "internal" or "external"
    source_title: Optional[str] = None
    target_title: Optional[str] = None


class PageLinksDetail(BaseModel):
    """Links for a page."""

    inlinks: List[PageLink] = Field(default_factory=list)
    outlinks: List[PageLink] = Field(default_factory=list)


class PageTopicInfo(BaseModel):
    """Topic classification for a page."""

    topics: List[str] = Field(default_factory=list)
    topic_scores: List[float] = Field(default_factory=list)
    page_type: Optional[str] = None  # "pillar" or "landing"
    assigned_topic: Optional[str] = None


class PageDetailResponse(BaseModel):
    """Detailed page information."""

    url: str
    title: Optional[str] = None
    meta_description: Optional[str] = None
    h1: Optional[str] = None
    domain: Optional[str] = None
    links: Optional[PageLinksDetail] = None
    topic_info: Optional[PageTopicInfo] = None
    content_preview: Optional[str] = None
    content_length: int = 0


# Simple response models for basic page search


class PageResult(BaseModel):
    """Simple page result with URL and title."""

    url: str
    title: str


class PageSearchResponse(BaseModel):
    """Response for simple page search."""

    pages: List[PageResult] = Field(default_factory=list)
    total: int


# SERP models for compatibility


class SERPResult(BaseModel):
    """Single SERP result."""

    title: str
    url: str
    snippet: Optional[str] = None


class SERPResponse(BaseModel):
    """Response for SERP queries."""

    query: str
    results: List[SERPResult] = Field(default_factory=list)
    total: int
