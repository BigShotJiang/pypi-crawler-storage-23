__version__ = "0.1.18"
__app_name__ = "devmemory"
