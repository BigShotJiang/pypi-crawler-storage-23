# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2025-2026 Maurice Garcia

"""Type aliases for PyPNM-CMTS."""
from __future__ import annotations

from typing import NewType

from pypnm.lib.types import (
    HostNameStr,
    InetAddressStr,
    InterfaceIndex,
    IPv4Str,
    IPv6Str,
    MacAddressStr,
    PathLike,
    SnmpIndex,
)

IntList                = list[int]
OptionalIntList        = IntList | None
IPv6LinkLocalStr        = NewType("IPv6LinkLocalStr", IPv6Str)
CableModemIndex         = NewType("CableModemIndex", SnmpIndex)
CmRegSgId               = NewType("CmRegSgId", int)
RegisterCmMacInetAddress = tuple[CableModemIndex, MacAddressStr, IPv4Str, IPv6Str, IPv6LinkLocalStr]
RegisterCmInetAddress   = tuple[IPv4Str, IPv6Str, IPv6LinkLocalStr]

MacAddressExist = NewType("MacAddressExist", bool)

CoordinationElectionName = NewType("CoordinationElectionName", str)
LeaderId                 = NewType("LeaderId", str)
OwnerId                  = NewType("OwnerId", str)
ServiceGroupId           = NewType("ServiceGroupId", int)
TickIndex                = NewType("TickIndex", int)
OrchestratorRunId        = NewType("OrchestratorRunId", str)
CoordinationPath         = PathLike
PnmCaptureOperationId    = NewType("PnmCaptureOperationId", str)
# Orchestrator PNM operation key, for example ds_ofdm_rxmer.
PnmTestName              = NewType("PnmTestName", str)

NodeName        = NewType("NodeName", str)
MdCmSgId        = NewType("MdCmSgId", int)
MdDsSgId        = NewType("MdDsSgId", int)
MdUsSgId        = NewType("MdUsSgId", int)
MdNodeStatus    = tuple[InterfaceIndex, NodeName, MdCmSgId]

UriStr                  = NewType("UriStr", str)

CmtsCmRegStatusId       = NewType("CmtsCmRegStatusId", int)
CmtsCmRegStatusMacAddr  = tuple[CmtsCmRegStatusId, MacAddressStr]
CmtsCmRegState          = NewType("CmtsCmRegState", int)
InterfaceIndexOrZero    = NewType("InterfaceIndexOrZero", InterfaceIndex)
MdIfIndex               = InterfaceIndexOrZero
RcpId                   = NewType("RcpId", str)
ChSetId                 = NewType("ChSetId", int)
DocsisQosVersion        = NewType("DocsisQosVersion", int)
DateAndTime             = NewType("DateAndTime", str)
Iso8601TimestampStr     = NewType("Iso8601TimestampStr", str)
EnergyMgtBits           = NewType("EnergyMgtBits", int)
InetAddressIPv4         = IPv4Str
InetAddressIPv6         = IPv6Str
PnmDestinationIndex     = NewType("PnmDestinationIndex", int)
PnmDestinationPort      = NewType("PnmDestinationPort", int)
PnmTransferProtocol     = NewType("PnmTransferProtocol", int)
PnmRowStatus            = NewType("PnmRowStatus", int)
PnmBaseUriStr           = NewType("PnmBaseUriStr", UriStr)
PnmUsOfdmaRxMerNumAvgs  = NewType("PnmUsOfdmaRxMerNumAvgs", int)
PnmUsOfdmaRxMerMeasStatus = NewType("PnmUsOfdmaRxMerMeasStatus", int)


__all__ = [
    "IntList",
    "OptionalIntList",
    "MacAddressExist",
    "IPv6LinkLocalStr",
    "CableModemIndex",
    "CmRegSgId",
    "CoordinationElectionName",
    "LeaderId",
    "OwnerId",
    "ServiceGroupId",
    "TickIndex",
    "OrchestratorRunId",
    "CoordinationPath",
    "PnmCaptureOperationId",
    "PnmTestName",
    "NodeName",
    "MdCmSgId",
    "MdDsSgId",
    "MdUsSgId",
    "MdNodeStatus",
    "CmtsCmRegStatusId",
    "CmtsCmRegStatusMacAddr",
    "CmtsCmRegState",
    "InterfaceIndexOrZero",
    "MdIfIndex",
    "RcpId",
    "ChSetId",
    "DocsisQosVersion",
    "DateAndTime",
    "Iso8601TimestampStr",
    "EnergyMgtBits",
    "InetAddressIPv4",
    "InetAddressIPv6",
    "PnmDestinationIndex",
    "PnmDestinationPort",
    "PnmTransferProtocol",
    "PnmRowStatus",
    "PnmBaseUriStr",
    "PnmUsOfdmaRxMerNumAvgs",
    "PnmUsOfdmaRxMerMeasStatus",
    "UriStr",
    "HostNameStr",
    "InetAddressStr",
    "RegisterCmMacInetAddress",
    "RegisterCmInetAddress",
]
