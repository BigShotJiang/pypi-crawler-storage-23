# SPDX-License-Identifier: Apache-2.0
# Copyright (c) 2026 Maurice Garcia

"""RxMER PNM orchestration routes."""
from __future__ import annotations

from pypnm_cmts.api.routes.pnm.sg.ds.ofdm.rxmer.router import router

__all__ = [
    "router",
]
