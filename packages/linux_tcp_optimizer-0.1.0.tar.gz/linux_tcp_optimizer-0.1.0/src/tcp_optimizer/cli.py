"""Main CLI entrypoint and subcommands."""

import json
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from . import __version__
from ._linux import require_linux, require_root
from .bdp import parse_bandwidth, parse_rtt_ms, recommend_buffers
from .detect import detect
from .info import gather_info
from .presets import TUNE_KEYS, get_preset, get_preset_names
from .report import gather_report_data, write_html, write_json
from .sysctl import backup_current, exists, write
from .viz import run_viz

console = Console()


def _linux_check():
    require_linux()


@click.group()
@click.version_option(version=__version__, prog_name="tcp-optimizer")
def main() -> None:
    """Linux TCP Optimizer — tune sysctl, detect bottlenecks, adjust buffers, visualize TCP."""
    _linux_check()


@main.command()
@click.option(
    "--preset",
    "-p",
    type=click.Choice(get_preset_names()),
    required=True,
    help="Preset to apply",
)
@click.option("--dry-run", is_flag=True, help="Only print what would be set")
@click.option(
    "--backup",
    "backup_path",
    type=click.Path(path_type=Path),
    default=None,
    help="Save current values to file before applying",
)
def tune(preset: str, dry_run: bool, backup_path: Path | None) -> None:
    """Apply a named sysctl preset (throughput, low-latency, wan, conservative)."""
    if not dry_run:
        require_root()
    preset_data = get_preset(preset)
    keys_to_apply = [k for k in preset_data if exists(k)]
    if backup_path and not dry_run:
        backup = backup_current(TUNE_KEYS)
        data = {k: (v if isinstance(v, str) else " ".join(map(str, v))) for k, v in backup.items()}
        backup_path.write_text(json.dumps(data, indent=2))
        console.print(f"[green]Backed up current values to {backup_path}[/green]")
    if dry_run:
        table = Table(title=f"Would apply preset: {preset}")
        table.add_column("Key", style="cyan")
        table.add_column("Value", style="green")
        for k in keys_to_apply:
            v = preset_data[k]
            table.add_row(k, str(v) if not isinstance(v, list) else " ".join(map(str, v)))
        console.print(table)
        return
    for k in keys_to_apply:
        v = preset_data[k]
        try:
            write(k, v)
            console.print(f"  [green]Set {k}[/green]")
        except Exception as e:
            console.print(f"  [red]Failed {k}: {e}[/red]")
    console.print(f"[green]Preset [bold]{preset}[/bold] applied.[/green]")


@main.command()
@click.option("--json-output", "json_out", is_flag=True, help="Output as JSON")
def detect_cmd(json_out: bool) -> None:
    """Detect bottlenecks (retransmissions, interface drops)."""
    _linux_check()
    result = detect()
    if json_out:
        out = {
            "retrans_rate": result.retrans_rate,
            "out_segs": result.out_segs,
            "retrans_segs": result.retrans_segs,
            "curr_estab": result.curr_estab,
            "findings": [
                {"severity": f.severity, "message": f.message, "recommendation": f.recommendation}
                for f in result.findings
            ],
        }
        console.print(json.dumps(out, indent=2))
        return
    if result.retrans_rate is not None:
        console.print(f"Retransmission rate: [bold]{result.retrans_rate:.2%}[/bold]")
        console.print(f"Connections (CurrEstab): {result.curr_estab}")
    if not result.findings:
        console.print("[green]No issues detected.[/green]")
        return
    for f in result.findings:
        style = (
            "red" if f.severity == "critical" else "yellow" if f.severity == "warning" else "blue"
        )
        console.print(f"[{style}]{f.severity.upper()}:[/{style}] {f.message}")
        console.print(f"  [dim]→ {f.recommendation}[/dim]")


@main.command()
@click.option("--bandwidth", "-b", required=True, help="e.g. 1Gbps, 100Mbps")
@click.option("--rtt", "-r", required=True, help="RTT in ms, e.g. 2 or 2ms")
@click.option("--apply", "do_apply", is_flag=True, help="Apply recommended values (requires root)")
@click.option("--dry-run", is_flag=True, help="Show what would be set")
def buffers(bandwidth: str, rtt: str, do_apply: bool, dry_run: bool) -> None:
    """Compute BDP and recommend buffer sizes; optionally apply them."""
    _linux_check()
    try:
        bps = parse_bandwidth(bandwidth)
        rtt_ms = parse_rtt_ms(rtt)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)
    rec = recommend_buffers(bps, rtt_ms)
    console.print(f"BDP: [bold]{rec.bdp_bytes / 1024:.1f} KiB[/bold]")
    console.print(
        f"Recommended tcp_rmem: {rec.tcp_rmem_min} {rec.tcp_rmem_default} {rec.tcp_rmem_max}"
    )
    console.print(
        f"Recommended tcp_wmem: {rec.tcp_wmem_min} {rec.tcp_wmem_default} {rec.tcp_wmem_max}"
    )
    console.print(f"Recommended net.core.rmem_max: {rec.core_rmem_max}")
    console.print(f"Recommended net.core.wmem_max: {rec.core_wmem_max}")
    if do_apply or dry_run:
        if do_apply:
            require_root()
        sysctl_ops = [
            ("net.core.rmem_max", rec.core_rmem_max),
            ("net.core.wmem_max", rec.core_wmem_max),
            ("net.ipv4.tcp_rmem", [rec.tcp_rmem_min, rec.tcp_rmem_default, rec.tcp_rmem_max]),
            ("net.ipv4.tcp_wmem", [rec.tcp_wmem_min, rec.tcp_wmem_default, rec.tcp_wmem_max]),
        ]
        for key, val in sysctl_ops:
            if dry_run:
                console.print(f"  [dim]Would set {key} = {val}[/dim]")
            else:
                if exists(key):
                    try:
                        write(key, val)
                        console.print(f"  [green]Set {key}[/green]")
                    except Exception as e:
                        console.print(f"  [red]Failed {key}: {e}[/red]")


@main.command()
def info() -> None:
    """Show current key sysctl and kernel version."""
    _linux_check()
    data = gather_info()
    console.print(f"Kernel: [bold]{data['kernel']}[/bold]")
    table = Table(title="Sysctl")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="green")
    for k, v in sorted(data["sysctl"].items()):
        table.add_row(k, str(v) if not isinstance(v, list) else " ".join(map(str, v)))
    console.print(table)


@main.command()
@click.option("--duration", "-d", type=int, default=30, help="Seconds to run")
@click.option("--refresh", "-r", type=float, default=1.0, help="Refresh interval in seconds")
def viz(duration: int, refresh: float) -> None:
    """Live view of retransmission rate and connection count."""
    _linux_check()
    run_viz(duration_sec=duration, refresh_sec=refresh)


@main.command()
@click.option(
    "--json",
    "out_json",
    type=click.Path(path_type=Path),
    default=None,
    help="Write JSON report here",
)
@click.option(
    "--html",
    "out_html",
    type=click.Path(path_type=Path),
    default=None,
    help="Write HTML report here",
)
def report(out_json: Path | None, out_html: Path | None) -> None:
    """Export snapshot of sysctl and TCP stats (JSON and/or HTML)."""
    _linux_check()
    data = gather_report_data()
    if out_json:
        write_json(data, out_json)
        console.print(f"[green]Wrote JSON report to {out_json}[/green]")
    if out_html:
        write_html(data, out_html)
        console.print(f"[green]Wrote HTML report to {out_html}[/green]")
    if not out_json and not out_html:
        console.print(json.dumps({k: v for k, v in data.items() if k == "sysctl"}, indent=2))


if __name__ == "__main__":
    main()
