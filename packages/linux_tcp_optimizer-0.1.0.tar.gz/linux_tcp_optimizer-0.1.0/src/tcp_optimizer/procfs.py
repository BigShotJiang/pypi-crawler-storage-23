"""Parse /proc/net/snmp and /proc/net/netstat for TCP and network stats."""

from pathlib import Path

PROC_NET = Path("/proc/net")


def _parse_key_value_proc(filepath: Path) -> dict[str, dict[str, int]]:
    """
    Parse files like /proc/net/snmp: first line headers, second line values.
    Sections are separated by blank lines; each section has a name (e.g. Tcp:) then keys.
    """
    text = filepath.read_text()
    result: dict[str, dict[str, int]] = {}
    current_name: str | None = None
    current_keys: list[str] = []
    for line in text.splitlines():
        if not line.strip():
            continue
        parts = line.split()
        if not parts:
            continue
        name = parts[0].rstrip(":")
        if name and name[0].isupper() and current_name != name:
            # New section: e.g. "Tcp:" or "Ip:"
            if current_name and current_keys:
                # Commit previous section when we see next (we need two lines per section)
                pass
            current_name = name
            current_keys = parts[1:]
            continue
        # Value line: first token is same section name, rest are values
        if current_keys and len(parts) >= len(current_keys) + 1:
            values = parts[1 : 1 + len(current_keys)]
            section: dict[str, int] = {}
            for k, v in zip(current_keys, values):
                try:
                    section[k] = int(v)
                except ValueError:
                    section[k] = 0
            result[current_name] = section
            current_name = None
            current_keys = []
    return result


def read_snmp() -> dict[str, dict[str, int]]:
    """Read and parse /proc/net/snmp. Returns e.g. {'Tcp': {'RetransSegs': 5, ...}, 'Ip': {...}}."""
    return _parse_key_value_proc(PROC_NET / "snmp")


def read_netstat() -> dict[str, dict[str, int]]:
    """Read and parse /proc/net/netstat. Returns sections like TcpExt, IpExt."""
    return _parse_key_value_proc(PROC_NET / "netstat")


def get_tcp_stats() -> dict[str, int]:
    """Get TCP section from snmp. Returns empty dict if not available."""
    data = read_snmp()
    return data.get("Tcp", {})


def get_tcp_ext_stats() -> dict[str, int]:
    """Get TcpExt section from netstat if present."""
    data = read_netstat()
    return data.get("TcpExt", {})
