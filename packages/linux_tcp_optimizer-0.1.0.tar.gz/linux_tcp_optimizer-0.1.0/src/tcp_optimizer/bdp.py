"""BDP (Bandwidth-Delay Product) calculator and buffer size recommendations."""

import re
from dataclasses import dataclass


@dataclass
class BufferRecommendation:
    """Recommended buffer sizes in bytes."""

    tcp_rmem_min: int
    tcp_rmem_default: int
    tcp_rmem_max: int
    tcp_wmem_min: int
    tcp_wmem_default: int
    tcp_wmem_max: int
    core_rmem_max: int
    core_wmem_max: int
    bdp_bytes: int


def parse_bandwidth(s: str) -> int:
    """
    Parse bandwidth string to bytes per second.
    Examples: 1Gbps, 1G, 100Mbps, 100M, 1gbit, 500mbps.
    """
    s = s.strip().upper().replace(" ", "")
    match = re.match(r"^(\d+(?:\.\d+)?)\s*(G?M?K?)(?:BPS|BIT/S?)?$", s, re.IGNORECASE)
    if not match:
        raise ValueError(f"Invalid bandwidth: {s!r}. Use e.g. 1Gbps, 100Mbps, 500M.")
    num = float(match.group(1))
    unit = (match.group(2) or "M").upper()
    if unit == "G":
        bits_per_sec = num * 1_000_000_000
    elif unit == "M":
        bits_per_sec = num * 1_000_000
    elif unit == "K":
        bits_per_sec = num * 1_000
    else:
        bits_per_sec = num
    return int(bits_per_sec / 8)


def parse_rtt_ms(s: str) -> float:
    """Parse RTT string to milliseconds. E.g. 2, 2ms, 0.5."""
    s = s.strip().lower().replace(" ", "")
    s = re.sub(r"ms$", "", s)
    try:
        return float(s)
    except ValueError:
        raise ValueError(f"Invalid RTT: {s!r}. Use e.g. 2 or 2ms.")


def bdp_bytes(bandwidth_bps: int, rtt_seconds: float) -> int:
    """Compute BDP in bytes: bandwidth (bytes/s) * RTT (s)."""
    return int(bandwidth_bps * rtt_seconds)


def recommend_buffers(
    bandwidth_bps: int,
    rtt_ms: float,
    *,
    min_default_bytes: int = 65536,
    max_cap_bytes: int = 16 * 1024 * 1024,
) -> BufferRecommendation:
    """
    Recommend tcp_rmem, tcp_wmem, and core *_{r,w}mem_max from BDP.
    rtt_ms is in milliseconds; bandwidth_bps is in bytes per second.
    """
    rtt_sec = rtt_ms / 1000.0
    bdp = bdp_bytes(bandwidth_bps, rtt_sec)
    # Cap max to avoid excessive memory; at least 2x BDP for headroom
    recv_max = min(max(bdp * 2, 262144), max_cap_bytes)
    send_max = min(max(bdp * 2, 262144), max_cap_bytes)
    default = max(min_default_bytes, bdp // 2)
    default = min(default, recv_max // 2)
    return BufferRecommendation(
        tcp_rmem_min=4096,
        tcp_rmem_default=default,
        tcp_rmem_max=recv_max,
        tcp_wmem_min=4096,
        tcp_wmem_default=default,
        tcp_wmem_max=send_max,
        core_rmem_max=recv_max,
        core_wmem_max=send_max,
        bdp_bytes=bdp,
    )
