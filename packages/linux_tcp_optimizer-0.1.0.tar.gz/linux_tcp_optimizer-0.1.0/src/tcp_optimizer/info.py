"""Print current networking/sysctl settings (info subcommand)."""

from pathlib import Path

from .sysctl import exists, get

INFO_KEYS = [
    "net.core.rmem_max",
    "net.core.wmem_max",
    "net.core.netdev_max_backlog",
    "net.ipv4.tcp_congestion_control",
    "net.ipv4.tcp_rmem",
    "net.ipv4.tcp_wmem",
    "net.ipv4.tcp_moderate_rcvbuf",
    "net.core.default_qdisc",
]


def get_kernel_version() -> str:
    try:
        return Path("/proc/version").read_text().strip().split(" ")[2]
    except Exception:
        return "unknown"


def gather_info() -> dict:
    """Gather current sysctl values and kernel version."""
    out: dict = {"kernel": get_kernel_version(), "sysctl": {}}
    for key in INFO_KEYS:
        if exists(key):
            out["sysctl"][key] = get(key)
    return out
