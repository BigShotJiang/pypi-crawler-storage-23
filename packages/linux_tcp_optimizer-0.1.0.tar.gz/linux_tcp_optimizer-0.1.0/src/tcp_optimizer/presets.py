"""Named presets for sysctl tuning. Values are applied to /proc/sys."""

from typing import Any

# Keys we touch across presets (for backup/restore)
TUNE_KEYS = [
    "net.core.rmem_max",
    "net.core.wmem_max",
    "net.core.rmem_default",
    "net.core.wmem_default",
    "net.core.netdev_max_backlog",
    "net.core.optmem_max",
    "net.ipv4.tcp_rmem",
    "net.ipv4.tcp_wmem",
    "net.ipv4.tcp_mem",
    "net.ipv4.tcp_congestion_control",
    "net.ipv4.tcp_moderate_rcvbuf",
    "net.ipv4.tcp_slow_start_after_idle",
    "net.ipv4.tcp_max_syn_backlog",
]

# Preset: key -> value. List of ints for tcp_rmem/tcp_wmem/tcp_mem.
PRESETS: dict[str, dict[str, Any]] = {
    "conservative": {
        "net.core.rmem_max": 262144,
        "net.core.wmem_max": 262144,
        "net.core.rmem_default": 65536,
        "net.core.wmem_default": 65536,
        "net.core.netdev_max_backlog": 2000,
        "net.core.optmem_max": 65536,
        "net.ipv4.tcp_rmem": [4096, 65536, 262144],
        "net.ipv4.tcp_wmem": [4096, 65536, 262144],
        "net.ipv4.tcp_mem": [786432, 1048576, 26777216],
        "net.ipv4.tcp_congestion_control": "cubic",
        "net.ipv4.tcp_moderate_rcvbuf": 1,
        "net.ipv4.tcp_slow_start_after_idle": 1,
        "net.ipv4.tcp_max_syn_backlog": 4096,
    },
    "throughput": {
        "net.core.rmem_max": 16777216,
        "net.core.wmem_max": 16777216,
        "net.core.rmem_default": 262144,
        "net.core.wmem_default": 262144,
        "net.core.netdev_max_backlog": 16384,
        "net.core.optmem_max": 65536,
        "net.ipv4.tcp_rmem": [4096, 87380, 16777216],
        "net.ipv4.tcp_wmem": [4096, 65536, 16777216],
        "net.ipv4.tcp_mem": [786432, 1048576, 26777216],
        "net.ipv4.tcp_congestion_control": "bbr",
        "net.ipv4.tcp_moderate_rcvbuf": 1,
        "net.ipv4.tcp_slow_start_after_idle": 0,
        "net.ipv4.tcp_max_syn_backlog": 8192,
    },
    "low-latency": {
        "net.core.rmem_max": 262144,
        "net.core.wmem_max": 262144,
        "net.core.rmem_default": 65536,
        "net.core.wmem_default": 65536,
        "net.core.netdev_max_backlog": 4096,
        "net.core.optmem_max": 65536,
        "net.ipv4.tcp_rmem": [4096, 65536, 262144],
        "net.ipv4.tcp_wmem": [4096, 65536, 262144],
        "net.ipv4.tcp_mem": [786432, 1048576, 26777216],
        "net.ipv4.tcp_congestion_control": "bbr",
        "net.ipv4.tcp_moderate_rcvbuf": 1,
        "net.ipv4.tcp_slow_start_after_idle": 0,
        "net.ipv4.tcp_max_syn_backlog": 8192,
    },
    "wan": {
        "net.core.rmem_max": 4194304,
        "net.core.wmem_max": 4194304,
        "net.core.rmem_default": 262144,
        "net.core.wmem_default": 262144,
        "net.core.netdev_max_backlog": 8192,
        "net.core.optmem_max": 65536,
        "net.ipv4.tcp_rmem": [4096, 131072, 4194304],
        "net.ipv4.tcp_wmem": [4096, 65536, 4194304],
        "net.ipv4.tcp_mem": [786432, 1048576, 26777216],
        "net.ipv4.tcp_congestion_control": "bbr",
        "net.ipv4.tcp_moderate_rcvbuf": 1,
        "net.ipv4.tcp_slow_start_after_idle": 0,
        "net.ipv4.tcp_max_syn_backlog": 8192,
    },
}


def get_preset_names() -> list[str]:
    return list(PRESETS.keys())


def get_preset(name: str) -> dict[str, Any]:
    if name not in PRESETS:
        raise KeyError(f"Unknown preset: {name}. Available: {', '.join(get_preset_names())}")
    return PRESETS[name].copy()
