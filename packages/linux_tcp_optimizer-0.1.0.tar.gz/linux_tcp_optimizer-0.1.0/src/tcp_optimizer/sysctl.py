"""Read and write Linux sysctl via /proc/sys."""

from pathlib import Path

PROC_SYS = Path("/proc/sys")


def _sysctl_path(key: str) -> Path:
    """Convert key like net.core.rmem_max to /proc/sys/net/core/rmem_max."""
    return PROC_SYS / key.replace(".", "/")


def read(key: str) -> str:
    """Read a sysctl value. Raises FileNotFoundError if key does not exist."""
    path = _sysctl_path(key)
    return path.read_text().strip()


def read_multi(key: str) -> list[str]:
    """Read a multi-value sysctl (e.g. tcp_rmem) as a list of strings."""
    raw = read(key)
    return raw.split()


def write(key: str, value: str | int | list[int]) -> None:
    """Write a sysctl value. Requires root. Value can be string, int, or list of ints."""
    path = _sysctl_path(key)
    if isinstance(value, list):
        value_str = "\t".join(str(v) for v in value)
    else:
        value_str = str(value)
    path.write_text(value_str + "\n")


def get(key: str) -> str | list[str]:
    """Read sysctl; multi-value keys return list, others return single string."""
    raw = read(key).strip()
    if "\t" in raw or (raw and raw.split()[0].isdigit() and len(raw.split()) > 1):
        return raw.split()
    return raw


def exists(key: str) -> bool:
    """Return True if the sysctl key exists."""
    return _sysctl_path(key).exists()


def backup_current(keys: list[str]) -> dict[str, str | list[str]]:
    """Read current values for given keys. Returns dict key -> value (str or list)."""
    result: dict[str, str | list[str]] = {}
    for k in keys:
        if exists(k):
            result[k] = get(k)
    return result
