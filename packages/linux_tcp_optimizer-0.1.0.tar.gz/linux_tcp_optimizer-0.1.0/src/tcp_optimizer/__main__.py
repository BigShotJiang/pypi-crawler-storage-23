"""Allow running as python -m tcp_optimizer."""

from .cli import main

if __name__ == "__main__":
    main()
