"""Export report: sysctl snapshot + procfs stats (JSON/HTML)."""

import json
from pathlib import Path

from . import presets
from .procfs import read_netstat, read_snmp
from .sysctl import exists, get


def gather_report_data() -> dict:
    """Collect all data for a report."""
    keys = presets.TUNE_KEYS
    sysctl: dict = {}
    for k in keys:
        if exists(k):
            v = get(k)
            sysctl[k] = v
    snmp = {}
    netstat = {}
    try:
        snmp = read_snmp()
    except Exception:
        pass
    try:
        netstat = read_netstat()
    except Exception:
        pass
    return {
        "sysctl": sysctl,
        "snmp": snmp,
        "netstat": netstat,
    }


def write_json(data: dict, path: Path) -> None:
    """Write report as JSON. Convert non-JSON-serializable values."""

    def _serialize(obj):
        if isinstance(obj, dict):
            return {k: _serialize(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [_serialize(x) for x in obj]
        if isinstance(obj, (str, int, float, bool, type(None))):
            return obj
        return str(obj)

    path.write_text(json.dumps(_serialize(data), indent=2))


def write_html(data: dict, path: Path) -> None:
    """Write a simple HTML report."""
    sysctl = data.get("sysctl", {})
    snmp = data.get("snmp", {})
    tcp = snmp.get("Tcp", {})
    rows = []
    for k, v in sorted(sysctl.items()):
        if isinstance(v, list):
            v = " ".join(str(x) for x in v)
        rows.append(f"<tr><td>{k}</td><td>{v}</td></tr>")
    sysctl_table = "\n".join(rows)
    tcp_rows = "".join(f"<tr><td>{k}</td><td>{v}</td></tr>" for k, v in sorted(tcp.items()))
    html = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>TCP Optimizer Report</title></head>
<body>
<h1>TCP Optimizer Report</h1>
<h2>Sysctl</h2>
<table border="1"><tr><th>Key</th><th>Value</th></tr>
{sysctl_table}
</table>
<h2>TCP (snmp)</h2>
<table border="1"><tr><th>Metric</th><th>Value</th></tr>
{tcp_rows}
</table>
</body>
</html>
"""
    path.write_text(html, encoding="utf-8")
