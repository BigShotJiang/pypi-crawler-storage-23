"""Live terminal visualization of TCP stats (retrans rate, connections)."""

import time
from collections import deque

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table

from .procfs import get_tcp_stats

console = Console()


def run_viz(duration_sec: int = 30, refresh_sec: float = 1.0) -> None:
    """Run live viz for duration_sec (or until Ctrl+C). Poll every refresh_sec."""
    history_retrans: deque[float] = deque(maxlen=60)
    history_estab: deque[int] = deque(maxlen=60)
    start = time.monotonic()
    last_out = 0
    last_retrans = 0

    def make_table() -> Table:
        nonlocal last_out, last_retrans
        tcp = get_tcp_stats()
        out_segs = tcp.get("OutSegs", 0)
        retrans = tcp.get("RetransSegs", 0)
        curr_estab = tcp.get("CurrEstab", 0)
        delta_out = out_segs - last_out
        delta_retrans = retrans - last_retrans
        last_out = out_segs
        last_retrans = retrans
        rate = (delta_retrans / delta_out * 100) if delta_out > 0 else 0.0
        history_retrans.append(rate)
        history_estab.append(curr_estab)
        spark_retrans = _sparkline(history_retrans, 0, 10)
        spark_estab = _sparkline(history_estab, 0, max(history_estab) or 1)
        table = Table(title="TCP congestion view")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        table.add_column("History", style="dim")
        table.add_row("Retrans rate (instant %)", f"{rate:.2f}%", spark_retrans)
        table.add_row("Connections (CurrEstab)", str(curr_estab), spark_estab)
        table.add_row("OutSegs (total)", str(out_segs), "")
        table.add_row("RetransSegs (total)", str(retrans), "")
        return table

    def gen():
        while (time.monotonic() - start) < duration_sec:
            yield make_table()
            time.sleep(refresh_sec)
        return

    it = iter(gen())
    try:
        with Live(console=console, refresh_per_second=1 / refresh_sec) as live:
            while (time.monotonic() - start) < duration_sec:
                try:
                    table = next(it)
                except StopIteration:
                    break
                live.update(Panel(table, title="tcp-optimizer viz"))
                time.sleep(refresh_sec)
    except KeyboardInterrupt:
        pass

    console.print("[dim]Viz ended.[/dim]")


def _sparkline(values: deque, lo: float, hi: float) -> str:
    if not values or hi <= lo:
        return ""
    blocks = "▁▂▃▄▅▆▇█"
    out = []
    for v in values:
        idx = int((v - lo) / (hi - lo) * (len(blocks) - 1))
        idx = max(0, min(idx, len(blocks) - 1))
        out.append(blocks[idx])
    return "".join(out)
