"""Linux platform checks and privilege detection."""

import os
import sys


def is_linux() -> bool:
    """Return True if running on Linux."""
    return sys.platform == "linux"


def require_linux() -> None:
    """Exit with a clear message if not on Linux."""
    if not is_linux():
        print("This tool is for Linux only. Exiting.", file=sys.stderr)
        sys.exit(1)


def is_root() -> bool:
    """Return True if running as root (uid 0)."""
    return os.geteuid() == 0


def require_root(message: str = "This operation requires root. Run with sudo.") -> None:
    """Exit with a clear message if not root."""
    if not is_root():
        print(message, file=sys.stderr)
        sys.exit(1)
