"""Linux TCP Optimizer Toolkit — tune sysctl, detect bottlenecks, adjust buffers, visualize TCP."""

__version__ = "0.1.0"
