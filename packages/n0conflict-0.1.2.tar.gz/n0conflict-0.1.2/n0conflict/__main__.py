from n0conflict.main import main

main()
