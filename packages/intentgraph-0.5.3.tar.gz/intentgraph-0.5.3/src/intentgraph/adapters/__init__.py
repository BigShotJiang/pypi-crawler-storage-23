"""Infrastructure adapters for IntentGraph."""
