"""Tests for RepoSnapshot v1 functionality."""
