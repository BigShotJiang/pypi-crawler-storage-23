# Test fixtures should be initialized as git repos in conftest.py setup
