# CCCC MCP Server
# Exposes cccc control-plane tools for agents
