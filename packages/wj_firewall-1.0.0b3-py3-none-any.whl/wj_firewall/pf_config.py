# ────────────────────────────────────────────────────────────────────────────────────────
#   pf_config.py
#   ────────────
#
#   Manage the wj-firewall PF anchor file and ensure pf.conf references it.
#
#   (c) 2026 WaterJuice — Released under the Unlicense; see LICENSE.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import logging
import re
from datetime import UTC
from datetime import datetime
from pathlib import Path
from .rules import BlockedInterfaces

# ────────────────────────────────────────────────────────────────────────────────────────
#   Constants
# ────────────────────────────────────────────────────────────────────────────────────────

ANCHOR_NAME = "wj-firewall"
ANCHOR_PATH = Path("/etc/pf.anchors/wj-firewall")
PF_CONF_PATH = Path("/etc/pf.conf")

# Lines that must appear in pf.conf for the anchor to be evaluated.
ANCHOR_RULE = f'anchor "{ANCHOR_NAME}"'
ANCHOR_LOAD = f'load anchor "{ANCHOR_NAME}" from "{ANCHOR_PATH}"'

# Old managed block markers (for migration from v0.1).
_OLD_BLOCK_START = "# >>> wj-firewall managed rules - DO NOT EDIT MANUALLY >>>"
_OLD_BLOCK_END = "# <<< wj-firewall managed rules <<<"

# Regex matching a "block ... in on <iface>" line in the anchor file.
_BLOCK_IN_PATTERN = re.compile(
    r"^block\s+(?:(?:return|drop)\s+)?in\s+(?:quick\s+)?on\s+(\w+)\s+all"
)

# Regex matching a "pass in ... proto tcp/udp ... port <N>" line (allowed port).
_PASS_IN_PORT_PATTERN = re.compile(
    r"^pass\s+in\s+(?:quick\s+)?on\s+(\w+)\s+proto\s+(?:tcp|udp)\s+"
    r"from\s+any\s+to\s+any\s+port\s+(\d+)\s+keep\s+state"
)

# Regex matching a "pass in ... proto icmp ... all" line (ICMP allowed).
_PASS_IN_ICMP_PATTERN = re.compile(
    r"^pass\s+in\s+(?:quick\s+)?on\s+(\w+)\s+proto\s+icmp\s+all\s+keep\s+state"
)

log = logging.getLogger(__name__)

# ────────────────────────────────────────────────────────────────────────────────────────
#   Anchor File Functions
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def generate_anchor_content(blocked: BlockedInterfaces) -> str:
    """
    Generate the full text content of the PF anchor file.

    For each blocked interface, emits rules (all using ``quick``
    for immediate decision — first match wins):

      1. ``pass out quick on <iface> all keep state``          — outgoing + return traffic
      2. ``pass in quick on <iface> proto udp ... port 67→68`` — DHCP
      3. ``pass in quick on <iface> proto icmp all keep state`` — ICMP (unless blocked)
      4. Per-port pass rules (TCP + UDP) for each allowed port
      5. ``block drop in quick on <iface> all``                — drop everything else

    ICMP (ping, traceroute, PMTU discovery) is allowed through by
    default. When ICMP is blocked on an interface, the ICMP pass
    rule is omitted.

    The ``quick`` keyword makes each rule an immediate final decision,
    preventing any later rules from overriding our block.

    We use ``block drop`` (silent discard) rather than ``block return``
    to avoid RST/ICMP unreachable responses that can trigger macOS
    Private Relay to disable itself.
    """
    now = datetime.now(tz=UTC).strftime("%Y-%m-%d %H:%M:%S UTC")
    lines: list[str] = [
        (
            "# ──────────────────────────────────────────────────────────"
            "──────────────────────────────────"
        ),
        "#   wj-firewall anchor — auto-generated, do not edit manually",
        f"#   Generated: {now}",
        (
            "# ──────────────────────────────────────────────────────────"
            "──────────────────────────────────"
        ),
    ]

    for iface in sorted(blocked.interfaces):
        ports = sorted(blocked.get_allowed_ports(iface))
        icmp_blocked = blocked.is_icmp_blocked(iface)
        lines.append("")

        # Comment describing the rule set for this interface.
        modifiers: list[str] = []
        if icmp_blocked:
            modifiers.append("no ICMP")
        modifiers.extend(str(p) for p in ports)
        if modifiers:
            lines.append(f"# {iface} \u2014 block incoming ({', '.join(modifiers)})")
        else:
            lines.append(f"# {iface} \u2014 block incoming")

        lines.append(f"pass out quick on {iface} all keep state")
        lines.append(
            f"pass in quick on {iface} proto udp from any port 67 to any port 68 keep"
            " state"
        )
        if not icmp_blocked:
            lines.append(f"pass in quick on {iface} proto icmp all keep state")
        for port in ports:
            lines.append(
                f"pass in quick on {iface} proto tcp from any to any port {port} keep"
                " state"
            )
            lines.append(
                f"pass in quick on {iface} proto udp from any to any port {port} keep"
                " state"
            )
        lines.append(f"block drop in quick on {iface} all")

    lines.append("")
    return "\n".join(lines)


# ────────────────────────────────────────────────────────────────────────────────────────
def read_blocked_interfaces(path: Path = ANCHOR_PATH) -> BlockedInterfaces:
    """
    Parse the anchor file and return which interfaces have incoming blocked,
    along with any per-port exceptions and ICMP blocking state.

    Looks for ``block ... in on <iface> all`` lines to identify blocked
    interfaces, ``pass in ... proto tcp/udp ... port <N>`` lines to
    identify allowed ports, and ``pass in ... proto icmp all`` lines to
    identify interfaces with ICMP allowed. An interface with a block
    rule but no ICMP pass rule has ICMP blocked.

    If the file does not exist or cannot be read, returns an empty state
    (no interfaces blocked).
    """
    try:
        content = path.read_text()
    except OSError:
        return BlockedInterfaces()

    blocked = BlockedInterfaces()
    icmp_allowed: set[str] = set()

    for line in content.splitlines():
        stripped = line.strip()

        match = _BLOCK_IN_PATTERN.match(stripped)
        if match:
            blocked.interfaces.add(match.group(1))
            continue

        port_match = _PASS_IN_PORT_PATTERN.match(stripped)
        if port_match:
            iface = port_match.group(1)
            port = int(port_match.group(2))
            blocked.add_allowed_port(iface, port)
            continue

        icmp_match = _PASS_IN_ICMP_PATTERN.match(stripped)
        if icmp_match:
            icmp_allowed.add(icmp_match.group(1))

    # Interfaces that are blocked but have no ICMP pass rule have ICMP blocked.
    blocked.block_icmp = blocked.interfaces - icmp_allowed

    return blocked


# ────────────────────────────────────────────────────────────────────────────────────────
#   pf.conf Anchor Management
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def check_pf_conf_anchor(path: Path = PF_CONF_PATH) -> bool:
    """
    Check whether pf.conf contains the anchor declaration and load rule,
    and that they appear **before** the first com.apple *filter* anchor.

    PF requires scrub/nat/rdr rules before filter rules, so our filter
    anchor must come after those but before any other filter anchor.

    pf.conf is world-readable, so no elevated privileges are needed.
    """
    try:
        content = path.read_text()
    except OSError:
        return False

    if ANCHOR_RULE not in content or ANCHOR_LOAD not in content:
        return False

    # Verify ordering: wj-firewall must appear AFTER all scrub/nat/rdr/
    # dummynet anchors (normalization/translation) and BEFORE any other
    # filter-type anchor. PF rejects the config otherwise.
    _NON_FILTER_PREFIXES = (
        "scrub-anchor",
        "nat-anchor",
        "rdr-anchor",
        "dummynet-anchor",
    )
    wj_idx: int | None = None
    last_non_filter_idx: int | None = None
    first_other_filter_idx: int | None = None
    for i, line in enumerate(content.splitlines()):
        stripped = line.strip()
        if stripped == ANCHOR_RULE and wj_idx is None:
            wj_idx = i
        elif stripped.startswith(_NON_FILTER_PREFIXES):
            last_non_filter_idx = i
        elif (
            stripped.startswith("anchor")
            and ANCHOR_NAME not in stripped
            and first_other_filter_idx is None
        ):
            first_other_filter_idx = i

    if wj_idx is None:
        return False

    # Must come after all normalization/translation rules.
    if last_non_filter_idx is not None and wj_idx < last_non_filter_idx:
        return False

    # Must come before any other filter anchor.
    if first_other_filter_idx is not None and wj_idx > first_other_filter_idx:
        return False

    return True


# ────────────────────────────────────────────────────────────────────────────────────────
def generate_pf_conf_with_anchor(path: Path = PF_CONF_PATH) -> str:
    """
    Read the current pf.conf, remove any old managed block, and insert the
    anchor declaration and load rule if they are not already present.

    PF enforces strict rule ordering: scrub → nat → rdr → filter. Our
    ``anchor`` is a filter-type rule, so it **must** appear after all
    scrub-anchor / nat-anchor / rdr-anchor / dummynet-anchor lines.
    We insert it just before ``anchor "com.apple/*"`` (the first
    filter-type anchor) so our rules are evaluated first.

    Returns the new pf.conf content as a string. The caller is responsible
    for writing it to disk (which requires elevated privileges).
    """
    try:
        content = path.read_text()
    except OSError:
        content = ""

    # Remove old managed block from v0.1 (if present).
    lines = content.splitlines()
    new_lines: list[str] = []
    in_old_block = False
    for line in lines:
        if line.strip() == _OLD_BLOCK_START:
            in_old_block = True
            continue
        if line.strip() == _OLD_BLOCK_END:
            in_old_block = False
            continue
        if not in_old_block:
            new_lines.append(line)

    # Remove any existing wj-firewall lines (we'll re-insert in the right place).
    new_lines = [line for line in new_lines if ANCHOR_NAME not in line]

    # Find the first filter-type anchor line (i.e. `anchor "..."` that is
    # NOT a scrub-anchor / nat-anchor / rdr-anchor / dummynet-anchor).
    # We must insert BEFORE this line but AFTER all the non-filter anchors,
    # because PF requires scrub/nat/rdr rules to precede filter rules.
    _NON_FILTER_PREFIXES = (
        "scrub-anchor",
        "nat-anchor",
        "rdr-anchor",
        "dummynet-anchor",
    )
    insert_idx: int | None = None
    for i, line in enumerate(new_lines):
        stripped = line.strip()
        if stripped.startswith("anchor") and not stripped.startswith(
            _NON_FILTER_PREFIXES
        ):
            insert_idx = i
            break

    anchor_lines = [ANCHOR_RULE, ANCHOR_LOAD]

    if insert_idx is not None:
        for j, anchor_line in enumerate(anchor_lines):
            new_lines.insert(insert_idx + j, anchor_line)
    else:
        # No filter anchor found — append at the end.
        new_lines.extend(["", *anchor_lines])

    content = "\n".join(new_lines)
    if not content.endswith("\n"):
        content += "\n"

    return content


# ────────────────────────────────────────────────────────────────────────────────────────
def generate_pf_conf_without_anchor(path: Path = PF_CONF_PATH) -> str | None:
    """
    Read the current pf.conf and remove all wj-firewall anchor references
    (including any old v0.1 managed blocks).

    Returns the cleaned pf.conf content as a string, or ``None`` if
    no wj-firewall references were found (nothing to remove).
    """
    try:
        content = path.read_text()
    except OSError:
        return None

    # Remove old managed block from v0.1 (if present).
    lines = content.splitlines()
    new_lines: list[str] = []
    in_old_block = False
    had_old_block = False
    for line in lines:
        if line.strip() == _OLD_BLOCK_START:
            in_old_block = True
            had_old_block = True
            continue
        if line.strip() == _OLD_BLOCK_END:
            in_old_block = False
            continue
        if not in_old_block:
            new_lines.append(line)

    # Remove any wj-firewall anchor lines.
    before_count = len(new_lines)
    new_lines = [line for line in new_lines if ANCHOR_NAME not in line]
    had_anchor_lines = len(new_lines) < before_count

    if not had_anchor_lines and not had_old_block:
        return None

    result = "\n".join(new_lines)
    if not result.endswith("\n"):
        result += "\n"

    return result
