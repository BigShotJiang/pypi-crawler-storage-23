# ────────────────────────────────────────────────────────────────────────────────────────
#   apply.py
#   ────────
#
#   Shared apply logic — writes the PF anchor file, reloads PF, and
#   ensures the firewall is active. Used by both the interactive TUI
#   and the CLI.
#
#   (c) 2026 WaterJuice — Released under the Unlicense; see LICENSE.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import logging
from .pf_config import ANCHOR_PATH
from .pf_config import PF_CONF_PATH
from .pf_config import check_pf_conf_anchor
from .pf_config import generate_anchor_content
from .pf_config import generate_pf_conf_with_anchor
from .pf_control import enable_pf
from .pf_control import flush_states_on_interface
from .pf_control import install_launch_daemon
from .pf_control import is_launch_daemon_installed
from .pf_control import is_pf_enabled
from .pf_control import reload_anchor
from .pf_control import reload_pf_conf
from .pf_control import write_file_privileged
from .rules import BlockedInterfaces

log = logging.getLogger(__name__)

# ────────────────────────────────────────────────────────────────────────────────────────
#   Functions
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def apply_rules(blocked: BlockedInterfaces) -> tuple[bool, str]:
    """
    Write the anchor file and reload PF.

    Ensures pf.conf has the anchor reference, writes the anchor file,
    reloads the anchor, enables PF if needed, and flushes states on
    blocked interfaces.

    Returns (success, message). On failure the message describes what
    went wrong.
    """
    # Write the anchor file first — pf.conf references it, so it must
    # exist before we reload pf.conf (otherwise pfctl fails with
    # "No such file or directory").
    content = generate_anchor_content(blocked)
    ok, msg = write_file_privileged(content, ANCHOR_PATH)
    if not ok:
        return False, f"Error writing anchor: {msg}"

    # Ensure pf.conf has the anchor reference.
    if not check_pf_conf_anchor():
        new_conf = generate_pf_conf_with_anchor()
        ok, msg = write_file_privileged(new_conf, PF_CONF_PATH)
        if not ok:
            return False, f"Error writing pf.conf: {msg}"
        ok, msg = reload_pf_conf()
        if not ok:
            return False, f"Error reloading pf.conf: {msg}"

    # Reload just the anchor.
    ok, msg = reload_anchor()
    if not ok:
        return False, f"Error reloading anchor: {msg}"

    # Ensure PF is enabled.
    if not is_pf_enabled():
        ok, msg = enable_pf()
        if not ok:
            return False, f"Error enabling PF: {msg}"

    # Install launch daemon so PF is re-enabled at boot.
    if not is_launch_daemon_installed():
        ok, msg = install_launch_daemon()
        if not ok:
            log.warning("Could not install launch daemon: %s", msg)

    # Flush state entries on blocked interfaces — existing states bypass
    # rule evaluation, so old connections would continue to pass.
    for iface_name in sorted(blocked.interfaces):
        flush_states_on_interface(iface_name)

    return True, "Rules applied successfully."
