# ────────────────────────────────────────────────────────────────────────────────────────
#   cli.py
#   ──────
#
#   CLI argument parsing and subcommand handlers. Provides non-interactive
#   access to view firewall state and modify blocked interfaces.
#
#   Running ``wj-firewall`` with no arguments launches the interactive TUI.
#   Subcommands (status, block, unblock, set, allow, deny, icmp, remove)
#   provide scriptable access.
#
#   (c) 2026 WaterJuice — Released under the Unlicense; see LICENSE.
#
#   Authors
#   ───────
#   bena (via Claude)
#
#   Version History
#   ───────────────
#   Feb 2026 - Created
# ────────────────────────────────────────────────────────────────────────────────────────

# ────────────────────────────────────────────────────────────────────────────────────────
#   Imports
# ────────────────────────────────────────────────────────────────────────────────────────

import os
import subprocess
import sys
import traceback
from collections.abc import Callable
from typing import NoReturn
from .argbuilder import ArgsParser
from .argbuilder import Namespace
from .rules import BlockedInterfaces
from .version import VERSION_STR

# ────────────────────────────────────────────────────────────────────────────────────────
#   Constants
# ────────────────────────────────────────────────────────────────────────────────────────

# Column widths for the status table.
_COL_IFACE = 30
_COL_IP = 22
_COL_INCOMING = 12
_COL_ICMP = 10

# Type alias for subcommand handler functions.
type _CommandHandler = Callable[[Namespace], int]

# ────────────────────────────────────────────────────────────────────────────────────────
#   Argument Parser
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _create_parser() -> ArgsParser:
    """Build the argument parser with subcommands."""
    parser = ArgsParser(
        prog="wj-firewall",
        description="macOS PF firewall configuration tool.",
        version=f"wj-firewall {VERSION_STR}",
        epilog="Run without arguments to launch the interactive TUI.",
    )

    # Common options ──────────────────────────────────────────────────────────
    common = parser.create_common_collection()
    common.add_argument(
        "--no-colour",
        "--no-color",
        action="store_true",
        dest="no_colour",
        help="Disable coloured output",
    )

    # status ──────────────────────────────────────────────────────────────────
    parser.add_command(
        "status",
        help="Show firewall status and interface block state",
    )

    # block ───────────────────────────────────────────────────────────────────
    block_cmd = parser.add_command(
        "block",
        help="Block incoming traffic on interfaces",
    )
    block_cmd.add_argument(
        "interfaces",
        nargs="+",
        metavar="IFACE",
        help="Interface names to block (e.g. en0 en1)",
    )

    # unblock ─────────────────────────────────────────────────────────────────
    unblock_cmd = parser.add_command(
        "unblock",
        help="Unblock incoming traffic on interfaces",
    )
    unblock_cmd.add_argument(
        "interfaces",
        nargs="+",
        metavar="IFACE",
        help="Interface names to unblock",
    )

    # set ─────────────────────────────────────────────────────────────────────
    set_cmd = parser.add_command(
        "set",
        help="Set exactly these interfaces as blocked (empty = unblock all)",
    )
    set_cmd.add_argument(
        "interfaces",
        nargs="*",
        metavar="IFACE",
        help="Interface names to block (omit all to unblock everything)",
    )

    # allow ──────────────────────────────────────────────────────────────────
    allow_cmd = parser.add_command(
        "allow",
        help="Open specific ports on a blocked interface",
    )
    allow_cmd.add_argument(
        "interface",
        metavar="IFACE",
        help="Interface name (e.g. en0)",
    )
    allow_cmd.add_argument(
        "ports",
        nargs="+",
        type=int,
        metavar="PORT",
        help="Port numbers to open (1\u201365535)",
    )

    # deny ───────────────────────────────────────────────────────────────────
    deny_cmd = parser.add_command(
        "deny",
        help="Close ports on a blocked interface",
    )
    deny_cmd.add_argument(
        "interface",
        metavar="IFACE",
        help="Interface name (e.g. en0)",
    )
    deny_cmd.add_argument(
        "ports",
        nargs="+",
        type=int,
        metavar="PORT",
        help="Port numbers to close",
    )

    # icmp ───────────────────────────────────────────────────────────────────
    icmp_cmd = parser.add_command(
        "icmp",
        help="Block or allow ICMP (ping/traceroute) on a blocked interface",
    )
    icmp_cmd.add_argument(
        "interface",
        metavar="IFACE",
        help="Interface name (e.g. en0)",
    )
    icmp_cmd.add_argument(
        "action",
        choices=["block", "allow"],
        help="'block' to block ICMP, 'allow' to allow it",
    )

    # remove ───────────────────────────────────────────────────────────────────
    parser.add_command(
        "remove",
        help=(
            "Remove all wj-firewall PF modifications (anchor file and pf.conf"
            " references)"
        ),
    )

    return parser


# ────────────────────────────────────────────────────────────────────────────────────────
#   Helpers
# ────────────────────────────────────────────────────────────────────────────────────────


# Commands that require root privileges (all subcommands).
_SUDO_COMMANDS = {
    "status",
    "block",
    "unblock",
    "set",
    "allow",
    "deny",
    "icmp",
    "remove",
}


# ────────────────────────────────────────────────────────────────────────────────────────
def _sudo_cached() -> bool:
    """Check whether sudo credentials are cached (no password prompt needed)."""
    try:
        result = subprocess.run(
            ["sudo", "-n", "true"],  # noqa: S603, S607
            capture_output=True,
            timeout=5,
        )
        return result.returncode == 0
    except (subprocess.SubprocessError, OSError):
        return False


# ────────────────────────────────────────────────────────────────────────────────────────
def _print_sudo_notice() -> None:
    """Print a notice that sudo is required and a password prompt will appear."""
    if _sudo_cached():
        return
    args = " ".join(sys.argv[1:])
    cmd = f"sudo wj-firewall {args}" if args else "sudo wj-firewall"
    print("wj-firewall requires administrator privileges.")
    print("You will be prompted for your password by sudo.")
    print(f"If you prefer, you can run: {cmd}")
    print()


# ────────────────────────────────────────────────────────────────────────────────────────
def _relaunch_as_root() -> NoReturn:
    """Re-execute the current command under ``sudo``.

    Replaces the current process via ``execvp`` so there is no extra
    parent process left behind.
    """
    os.execvp("sudo", ["sudo", sys.executable, "-m", "wj_firewall"] + sys.argv[1:])


# ────────────────────────────────────────────────────────────────────────────────────────
def _warn_unknown(requested: list[str], known_names: set[str]) -> None:
    """Print warnings for interface names not currently visible."""
    from .colour import yellow

    for name in requested:
        if name not in known_names:
            print(
                yellow(f"Warning: unknown interface '{name}' (not currently visible)"),
                file=sys.stderr,
            )


# ────────────────────────────────────────────────────────────────────────────────────────
def _validate_ports(ports: list[int]) -> int | None:
    """
    Validate that all port numbers are in range 1\u201365535.

    Returns the first invalid port, or ``None`` if all are valid.
    """
    for port in ports:
        if port < 1 or port > 65535:
            return port
    return None


# ────────────────────────────────────────────────────────────────────────────────────────
def _apply_and_report(blocked: BlockedInterfaces) -> int:
    """Apply rules and print the result. Returns exit code."""
    from .apply import apply_rules
    from .colour import green
    from .colour import red

    ok, msg = apply_rules(blocked)
    if ok:
        print(green(msg))
        return 0
    print(red(msg), file=sys.stderr)
    return 1


# ────────────────────────────────────────────────────────────────────────────────────────
#   Subcommand Handlers
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def _cmd_status(_args: Namespace) -> int:
    """Show PF status, anchor status, and per-interface block state."""
    from .colour import bold
    from .colour import cyan
    from .colour import dim
    from .colour import green
    from .colour import red
    from .colour import yellow
    from .interfaces import get_interfaces
    from .pf_config import check_pf_conf_anchor
    from .pf_config import read_blocked_interfaces
    from .pf_control import is_launch_daemon_installed
    from .pf_control import is_pf_enabled

    anchor_ok = check_pf_conf_anchor()
    blocked = read_blocked_interfaces()
    interfaces = get_interfaces(keep_interfaces=blocked.interfaces)

    pf_on = is_pf_enabled()
    pf_str = green("Enabled") if pf_on else red("Disabled")
    anchor_str = green("OK") if anchor_ok else red("Missing from pf.conf")
    boot_ok = is_launch_daemon_installed()
    boot_str = green("Enabled") if boot_ok else dim("Not configured")
    print(f"PF:      {pf_str}")
    print(f"Anchor:  {anchor_str}")
    print(f"Boot:    {boot_str}")
    print()

    if not interfaces:
        print("No network interfaces detected.")
        return 0

    # Table header — pad plain text before wrapping in colour so ANSI
    # escape codes don't throw off column alignment.
    hdr = (
        f"{'Interface':<{_COL_IFACE}}"
        f"{'IP Address':<{_COL_IP}}"
        f"{'Incoming':<{_COL_INCOMING}}"
        f"{'ICMP':<{_COL_ICMP}}"
        f"{'Open Ports'}"
    )
    print(bold(hdr))
    print(dim("─" * (_COL_IFACE + _COL_IP + _COL_INCOMING + _COL_ICMP + 20)))

    # Interface rows.
    for iface in interfaces:
        label = iface.name
        if iface.description:
            label = f"{iface.name} ({iface.description})"
        # Truncate long names so columns stay aligned.
        max_label = _COL_IFACE - 1
        if len(label) > max_label:
            label = label[: max_label - 1] + "\u2026"

        ipv4 = [a for a in iface.addresses if "." in a]
        if ipv4:
            ip_text = ipv4[0]
        elif iface.addresses:
            ip_text = "[IPv6]"
        else:
            ip_text = "—"

        if blocked.is_blocked(iface.name):
            incoming_plain = "BLOCKED"
            incoming = red(bold(incoming_plain))
        else:
            incoming_plain = "allowed"
            incoming = dim(incoming_plain)

        # ICMP column.
        if blocked.is_icmp_blocked(iface.name):
            icmp_plain = "blocked"
            icmp_col = red(bold(icmp_plain))
        else:
            icmp_plain = ""
            icmp_col = ""

        # Exceptions column (ports only).
        except_parts = [str(p) for p in sorted(blocked.get_allowed_ports(iface.name))]
        except_text = ", ".join(except_parts)

        # Pad plain text to column width, then colourise — ANSI codes
        # are invisible but count toward str length, breaking ljust.
        col_iface = green(label.ljust(_COL_IFACE))
        col_ip = cyan(ip_text.ljust(_COL_IP))
        col_incoming = incoming + " " * max(0, _COL_INCOMING - len(incoming_plain))
        col_icmp = icmp_col + " " * max(0, _COL_ICMP - len(icmp_plain))
        col_except = yellow(except_text) if except_text else ""
        print(f"{col_iface}{col_ip}{col_incoming}{col_icmp}{col_except}")

    return 0


# ────────────────────────────────────────────────────────────────────────────────────────
def _cmd_block(args: Namespace) -> int:
    """Block incoming traffic on the specified interfaces."""
    from .interfaces import get_interfaces
    from .pf_config import read_blocked_interfaces

    blocked = read_blocked_interfaces()
    interfaces = get_interfaces(keep_interfaces=blocked.interfaces)
    known_names = {iface.name for iface in interfaces}

    requested: list[str] = args.interfaces
    _warn_unknown(requested, known_names)

    for name in requested:
        blocked.set_blocked(name, blocked=True)

    return _apply_and_report(blocked)


# ────────────────────────────────────────────────────────────────────────────────────────
def _cmd_unblock(args: Namespace) -> int:
    """Unblock incoming traffic on the specified interfaces."""
    from .interfaces import get_interfaces
    from .pf_config import read_blocked_interfaces

    blocked = read_blocked_interfaces()
    interfaces = get_interfaces(keep_interfaces=blocked.interfaces)
    known_names = {iface.name for iface in interfaces}

    requested: list[str] = args.interfaces
    _warn_unknown(requested, known_names)

    for name in requested:
        blocked.set_blocked(name, blocked=False)

    return _apply_and_report(blocked)


# ────────────────────────────────────────────────────────────────────────────────────────
def _cmd_set(args: Namespace) -> int:
    """Set exactly these interfaces as blocked."""
    from .interfaces import get_interfaces
    from .pf_config import read_blocked_interfaces
    from .rules import BlockedInterfaces

    old_blocked = read_blocked_interfaces()
    interfaces = get_interfaces()
    known_names = {iface.name for iface in interfaces}

    requested: list[str] = args.interfaces
    _warn_unknown(requested, known_names)

    # Preserve exceptions for interfaces that remain blocked.
    new_set = set(requested)
    new_ports = {
        k: set(v) for k, v in old_blocked.allowed_ports.items() if k in new_set
    }
    new_block_icmp = old_blocked.block_icmp & new_set
    blocked = BlockedInterfaces(
        interfaces=new_set, allowed_ports=new_ports, block_icmp=new_block_icmp
    )
    return _apply_and_report(blocked)


# ────────────────────────────────────────────────────────────────────────────────────────
def _cmd_allow(args: Namespace) -> int:
    """Open specific ports on a blocked interface."""
    from .colour import red
    from .interfaces import get_interfaces
    from .pf_config import read_blocked_interfaces

    blocked = read_blocked_interfaces()
    interfaces = get_interfaces(keep_interfaces=blocked.interfaces)
    known_names = {iface.name for iface in interfaces}

    iface: str = args.interface
    _warn_unknown([iface], known_names)

    ports: list[int] = args.ports
    bad = _validate_ports(ports)
    if bad is not None:
        print(red(f"Invalid port: {bad} (must be 1\u201365535)"), file=sys.stderr)
        return 1

    # Block the interface if not already blocked.
    if not blocked.is_blocked(iface):
        blocked.set_blocked(iface, blocked=True)

    for port in ports:
        blocked.add_allowed_port(iface, port)

    return _apply_and_report(blocked)


# ────────────────────────────────────────────────────────────────────────────────────────
def _cmd_deny(args: Namespace) -> int:
    """Close ports on a blocked interface."""
    from .colour import red
    from .colour import yellow
    from .pf_config import read_blocked_interfaces

    blocked = read_blocked_interfaces()
    iface: str = args.interface

    if not blocked.is_blocked(iface):
        print(
            yellow(f"Interface '{iface}' is not blocked; nothing to deny."),
            file=sys.stderr,
        )
        return 0

    ports: list[int] = args.ports
    bad = _validate_ports(ports)
    if bad is not None:
        print(red(f"Invalid port: {bad} (must be 1\u201365535)"), file=sys.stderr)
        return 1

    for port in ports:
        blocked.remove_allowed_port(iface, port)

    return _apply_and_report(blocked)


# ────────────────────────────────────────────────────────────────────────────────────────
def _cmd_icmp(args: Namespace) -> int:
    """Block or allow ICMP on a blocked interface."""
    from .colour import yellow
    from .interfaces import get_interfaces
    from .pf_config import read_blocked_interfaces

    blocked = read_blocked_interfaces()
    interfaces = get_interfaces(keep_interfaces=blocked.interfaces)
    known_names = {iface.name for iface in interfaces}

    iface: str = args.interface
    _warn_unknown([iface], known_names)

    block = args.action == "block"

    # Block the interface if not already blocked.
    if not blocked.is_blocked(iface):
        if block:
            blocked.set_blocked(iface, blocked=True)
        else:
            print(
                yellow(f"Interface '{iface}' is not blocked; ICMP is already allowed."),
                file=sys.stderr,
            )
            return 0

    blocked.set_icmp_blocked(iface, blocked=block)

    return _apply_and_report(blocked)


# ────────────────────────────────────────────────────────────────────────────────────────
def _cmd_remove(_args: Namespace) -> int:
    """Remove all wj-firewall PF modifications."""
    from .colour import green
    from .colour import red
    from .colour import yellow
    from .pf_config import ANCHOR_PATH
    from .pf_config import PF_CONF_PATH
    from .pf_config import generate_pf_conf_without_anchor
    from .pf_config import read_blocked_interfaces
    from .pf_control import delete_file_privileged
    from .pf_control import flush_states_on_interface
    from .pf_control import reload_pf_conf
    from .pf_control import remove_launch_daemon
    from .pf_control import write_file_privileged

    errors: list[str] = []

    # Read current blocked interfaces before we delete anything — we need
    # to know which interfaces to flush states on.
    blocked = read_blocked_interfaces()

    # Remove the launch daemon that enables PF at boot.
    ok, msg = remove_launch_daemon()
    if ok:
        if "not installed" in msg:
            print(yellow(f"Launch daemon: {msg}"))
        else:
            print(green(msg))
    else:
        errors.append(msg)
        print(red(msg), file=sys.stderr)

    # Remove anchor references from pf.conf.
    new_pf_conf = generate_pf_conf_without_anchor()
    if new_pf_conf is not None:
        ok, msg = write_file_privileged(new_pf_conf, PF_CONF_PATH)
        if ok:
            print(green("Removed anchor references from pf.conf."))
        else:
            errors.append(f"Failed to update pf.conf: {msg}")
            print(red(errors[-1]), file=sys.stderr)
    else:
        print(yellow("No anchor references found in pf.conf (already clean)."))

    # Delete the anchor file.
    if ANCHOR_PATH.exists():
        ok, msg = delete_file_privileged(ANCHOR_PATH)
        if ok:
            print(green(f"Deleted anchor file {ANCHOR_PATH}."))
        else:
            errors.append(f"Failed to delete {ANCHOR_PATH}: {msg}")
            print(red(errors[-1]), file=sys.stderr)
    else:
        print(yellow(f"Anchor file {ANCHOR_PATH} does not exist (already clean)."))

    # Reload pf.conf so PF drops the anchor rules.
    ok, msg = reload_pf_conf()
    if ok:
        print(green("Reloaded PF configuration."))
    else:
        errors.append(f"Failed to reload PF: {msg}")
        print(red(errors[-1]), file=sys.stderr)

    # Flush states on previously blocked interfaces.
    for iface in sorted(blocked.interfaces):
        ok, msg = flush_states_on_interface(iface)
        if not ok:
            errors.append(f"Failed to flush states on {iface}: {msg}")
            print(red(errors[-1]), file=sys.stderr)

    if errors:
        print()
        print(red("Remove completed with errors."))
        return 1

    print()
    print(green("All wj-firewall PF modifications have been removed."))
    return 0


# ────────────────────────────────────────────────────────────────────────────────────────
#   Main Entry Point
# ────────────────────────────────────────────────────────────────────────────────────────


# ────────────────────────────────────────────────────────────────────────────────────────
def main() -> int:
    """Entry point: parse arguments and dispatch to TUI or CLI subcommand."""
    if sys.platform != "darwin":
        print("wj-firewall requires macOS.", file=sys.stderr)
        return 1

    try:
        return _main_inner()
    except KeyboardInterrupt:
        return 0
    except SystemExit:
        raise
    except BaseException as e:
        t = "-------------------------------------------------------------------\n"
        t += "UNHANDLED EXCEPTION OCCURRED!!\n"
        t += "\n"
        t += traceback.format_exc()
        t += "\n"
        t += f"EXCEPTION: {type(e)} {e}\n"
        t += "-------------------------------------------------------------------\n"
        print(t, file=sys.stderr)
        return 1


# ────────────────────────────────────────────────────────────────────────────────────────
def _main_inner() -> int:
    """Inner main function that does the actual work."""
    from .colour import set_colours_enabled

    # If no arguments at all, launch the TUI directly — don't let
    # argbuilder show help (its default when no command is given).
    if len(sys.argv) <= 1:
        if os.geteuid() != 0:
            _print_sudo_notice()
            _relaunch_as_root()
        from .app import launch_tui

        return launch_tui()

    parser = _create_parser()
    args: Namespace = parser.parse()

    # Relaunch as root if the command requires it.
    if args.command in _SUDO_COMMANDS and os.geteuid() != 0:
        _print_sudo_notice()
        _relaunch_as_root()

    # Handle colour settings.
    if args.no_colour:
        set_colours_enabled(False)

    commands: dict[str, _CommandHandler] = {
        "status": _cmd_status,
        "block": _cmd_block,
        "unblock": _cmd_unblock,
        "set": _cmd_set,
        "allow": _cmd_allow,
        "deny": _cmd_deny,
        "icmp": _cmd_icmp,
        "remove": _cmd_remove,
    }

    return commands[args.command](args)
