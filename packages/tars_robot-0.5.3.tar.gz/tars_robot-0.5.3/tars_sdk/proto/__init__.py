"""Generated proto files for TARS gRPC service."""
