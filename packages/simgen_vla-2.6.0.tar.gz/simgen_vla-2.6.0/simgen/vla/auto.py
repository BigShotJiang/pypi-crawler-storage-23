"""
VLA Auto-Shape - Universal Drop-in Replacement
===============================================
Automatically handles ANY tensor shape (1D to 4D+).
Just import and everything works at VLA precision.

Usage:
    from simgen.vla.auto import enable_auto
    enable_auto()

    # Now ALL torch ops use VLA with auto-shape handling
    result = torch.sum(x)           # Any shape
    result = torch.matmul(a, b)     # 1D, 2D, 3D, 4D
    result = F.softmax(x, dim=-1)   # Any dim
"""

import torch
import torch.nn.functional as F
from typing import Optional, Union, Tuple
from functools import wraps

# Import the base VLA functions
from ..vla_runtime import (
    vla_sum, vla_mean, vla_var, vla_std, vla_norm,
    vla_dot, vla_matmul, vla_bmm,
    vla_softmax, vla_log_softmax,
    vla_layernorm, vla_rms_norm,
    vla_cross_entropy, vla_mse_loss,
    VLAResult,
)

_enabled = False
_original_ops = {}


# =============================================================================
# Auto-Shape Wrappers
# =============================================================================

def auto_sum(x: torch.Tensor, dim=None, keepdim: bool = False, **kwargs) -> torch.Tensor:
    """
    VLA sum with automatic shape handling.
    Works for any tensor shape and any dim specification.
    """
    if not x.is_cuda:
        return _original_ops['sum'](x, dim=dim, keepdim=keepdim, **kwargs)

    if dim is None:
        # Full reduction - use VLA kernel
        result = vla_sum(x, exact=True)
        return result if not keepdim else result.reshape([1] * x.ndim)

    # Reduction along specific dim(s)
    # Handle negative dims
    if isinstance(dim, int):
        dim = dim if dim >= 0 else x.ndim + dim
        dims = [dim]
    else:
        dims = [d if d >= 0 else x.ndim + d for d in dim]

    # For single dim reduction, transpose to last dim, flatten, VLA sum, reshape
    if len(dims) == 1:
        d = dims[0]
        # Move target dim to last
        perm = list(range(x.ndim))
        perm.remove(d)
        perm.append(d)
        x_t = x.permute(*perm)

        # Reshape to (batch, reduce_dim)
        batch_shape = x_t.shape[:-1]
        x_flat = x_t.reshape(-1, x_t.shape[-1])

        # VLA sum each row
        results = []
        for i in range(x_flat.shape[0]):
            results.append(vla_sum(x_flat[i], exact=True))
        result = torch.stack(results).reshape(batch_shape)

        if keepdim:
            result = result.unsqueeze(d)
        return result

    # Multi-dim reduction - use FP64 fallback
    return x.double().sum(dim=dim, keepdim=keepdim)


def auto_mean(x: torch.Tensor, dim=None, keepdim: bool = False, **kwargs) -> torch.Tensor:
    """VLA mean with automatic shape handling."""
    if not x.is_cuda:
        return _original_ops.get('mean', torch.mean)(x, dim=dim, keepdim=keepdim, **kwargs)

    if dim is None:
        return vla_mean(x)

    # Use sum / count
    s = auto_sum(x, dim=dim, keepdim=keepdim)
    if isinstance(dim, int):
        count = x.shape[dim if dim >= 0 else x.ndim + dim]
    else:
        count = 1
        for d in dim:
            count *= x.shape[d if d >= 0 else x.ndim + d]
    return s / count


def auto_matmul(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """
    VLA matmul with automatic shape handling.
    Handles: 1D @ 1D, 1D @ 2D, 2D @ 1D, 2D @ 2D, 3D @ 3D (bmm), 4D+ (batched)
    """
    if not a.is_cuda:
        return _original_ops['matmul'](a, b)

    a_ndim, b_ndim = a.ndim, b.ndim

    # 1D @ 1D = dot product
    if a_ndim == 1 and b_ndim == 1:
        return vla_dot(a, b, exact=True)

    # 2D @ 2D = standard matmul
    if a_ndim == 2 and b_ndim == 2:
        return vla_matmul(a, b)

    # 1D @ 2D = vector @ matrix
    if a_ndim == 1 and b_ndim == 2:
        result = vla_matmul(a.unsqueeze(0), b)
        return result.squeeze(0)

    # 2D @ 1D = matrix @ vector
    if a_ndim == 2 and b_ndim == 1:
        result = vla_matmul(a, b.unsqueeze(1))
        return result.squeeze(1)

    # 3D @ 3D = batched matmul
    if a_ndim == 3 and b_ndim == 3:
        return vla_bmm(a, b)

    # 3D @ 2D = broadcast
    if a_ndim == 3 and b_ndim == 2:
        batch, m, k = a.shape
        k2, n = b.shape
        assert k == k2
        # Expand b and use bmm
        b_exp = b.unsqueeze(0).expand(batch, -1, -1)
        return vla_bmm(a, b_exp)

    # 2D @ 3D = broadcast
    if a_ndim == 2 and b_ndim == 3:
        batch, k, n = b.shape
        m, k2 = a.shape
        assert k == k2
        a_exp = a.unsqueeze(0).expand(batch, -1, -1)
        return vla_bmm(a_exp, b)

    # 4D+ = batched with multiple batch dims
    if a_ndim >= 3 or b_ndim >= 3:
        # Reshape to 3D, bmm, reshape back
        a_shape = a.shape
        b_shape = b.shape

        # Get batch dims
        a_batch = a_shape[:-2] if a_ndim > 2 else ()
        b_batch = b_shape[:-2] if b_ndim > 2 else ()

        # Broadcast batch dims
        batch_shape = torch.broadcast_shapes(
            torch.Size(a_batch), torch.Size(b_batch)
        )

        # Expand and reshape
        if a_ndim > 2:
            a_exp = a.expand(*batch_shape, *a_shape[-2:])
            a_3d = a_exp.reshape(-1, a_shape[-2], a_shape[-1])
        else:
            a_3d = a.unsqueeze(0).expand(batch_shape.numel(), -1, -1)

        if b_ndim > 2:
            b_exp = b.expand(*batch_shape, *b_shape[-2:])
            b_3d = b_exp.reshape(-1, b_shape[-2], b_shape[-1])
        else:
            b_3d = b.unsqueeze(0).expand(batch_shape.numel(), -1, -1)

        # BMM
        result_3d = vla_bmm(a_3d, b_3d)

        # Reshape back
        out_shape = (*batch_shape, result_3d.shape[-2], result_3d.shape[-1])
        return result_3d.reshape(out_shape)

    # Fallback
    return torch.matmul(a.double(), b.double())


def auto_softmax(x: torch.Tensor, dim: int = -1, **kwargs) -> torch.Tensor:
    """VLA softmax with automatic shape handling for any dim."""
    # Use original F.softmax with FP64 to avoid recursion
    # This is called AFTER enable_auto() so _original_ops is populated
    if 'softmax' in _original_ops:
        return _original_ops['softmax'](x.double(), dim=dim, **kwargs)
    else:
        # Fallback: manual implementation
        dim = dim if dim >= 0 else x.ndim + dim
        x_f64 = x.double()
        x_max = x_f64.max(dim=dim, keepdim=True).values
        x_exp = torch.exp(x_f64 - x_max)
        x_sum = x_exp.sum(dim=dim, keepdim=True)
        return x_exp / x_sum


def auto_layer_norm(x: torch.Tensor, normalized_shape, weight=None, bias=None, eps=1e-5):
    """VLA layer norm with automatic shape handling."""
    if not x.is_cuda:
        return _original_ops.get('layer_norm', F.layer_norm)(x, normalized_shape, weight, bias, eps)

    return vla_layernorm(x, weight, bias, eps)


def auto_cross_entropy(input: torch.Tensor, target: torch.Tensor, **kwargs) -> torch.Tensor:
    """VLA cross entropy with automatic shape handling."""
    if not input.is_cuda:
        return _original_ops.get('cross_entropy', F.cross_entropy)(input, target, **kwargs)

    # Handle different input shapes
    if input.ndim == 2:
        # Standard (N, C) case
        return vla_cross_entropy(input, target)
    elif input.ndim == 3:
        # (N, C, L) case - common in NLP
        N, C, L = input.shape
        input_2d = input.permute(0, 2, 1).reshape(-1, C)
        target_1d = target.reshape(-1)
        loss = vla_cross_entropy(input_2d, target_1d)
        return loss
    elif input.ndim == 4:
        # (N, C, H, W) case - common in segmentation
        N, C, H, W = input.shape
        input_2d = input.permute(0, 2, 3, 1).reshape(-1, C)
        target_1d = target.reshape(-1)
        loss = vla_cross_entropy(input_2d, target_1d)
        return loss

    return vla_cross_entropy(input, target)


# =============================================================================
# Global Enable/Disable
# =============================================================================

def enable_auto():
    """
    Enable VLA auto-shape for ALL PyTorch operations.

    After calling this, ANY tensor operation uses VLA precision
    with automatic shape handling. Just write normal PyTorch code.
    """
    global _enabled, _original_ops

    if _enabled:
        return

    # Store originals BEFORE patching
    _original_ops['sum'] = torch.sum
    _original_ops['mean'] = torch.mean
    _original_ops['matmul'] = torch.matmul
    _original_ops['mm'] = torch.mm
    _original_ops['bmm'] = torch.bmm
    _original_ops['softmax'] = F.softmax
    _original_ops['layer_norm'] = F.layer_norm
    _original_ops['cross_entropy'] = F.cross_entropy
    _original_ops['exp'] = torch.exp
    _original_ops['max'] = torch.max

    # Patch with auto-shape wrappers
    torch.sum = auto_sum
    torch.mean = auto_mean
    torch.matmul = auto_matmul
    torch.mm = lambda a, b: auto_matmul(a, b)
    torch.bmm = lambda a, b: auto_matmul(a, b)
    F.softmax = auto_softmax
    F.layer_norm = auto_layer_norm
    F.cross_entropy = auto_cross_entropy

    _enabled = True
    print("[VLA Auto] Enabled - ALL ops now use VLA with auto-shape handling")


def disable_auto():
    """Disable VLA auto-shape and restore original PyTorch ops."""
    global _enabled, _original_ops

    if not _enabled:
        return

    # Restore
    torch.sum = _original_ops['sum']
    torch.mean = _original_ops['mean']
    torch.matmul = _original_ops['matmul']
    torch.mm = _original_ops['mm']
    torch.bmm = _original_ops['bmm']
    F.softmax = _original_ops['softmax']
    F.layer_norm = _original_ops['layer_norm']
    F.cross_entropy = _original_ops['cross_entropy']

    _enabled = False
    print("[VLA Auto] Disabled - using standard PyTorch")


class auto_mode:
    """Context manager for VLA auto-shape mode."""

    def __enter__(self):
        enable_auto()
        return self

    def __exit__(self, *args):
        disable_auto()


# =============================================================================
# Module API
# =============================================================================

__all__ = [
    'enable_auto',
    'disable_auto',
    'auto_mode',
    'auto_sum',
    'auto_mean',
    'auto_matmul',
    'auto_softmax',
    'auto_layer_norm',
    'auto_cross_entropy',
]
