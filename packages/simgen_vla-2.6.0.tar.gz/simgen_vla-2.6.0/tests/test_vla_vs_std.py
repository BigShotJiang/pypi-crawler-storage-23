"""VLA vs Standard PyTorch Training Comparison"""
import sys
sys.path.insert(0, '/mnt/c/SimGen')

import torch
import torch.nn as nn
import torch.nn.functional as F
from simgen import vla
import math
import time

print('='*70)
print('VLA vs Standard PyTorch Training Comparison')
print('='*70)

torch.manual_seed(42)
torch.cuda.manual_seed(42)

# Config
VOCAB_SIZE = 256  # char-level
N_EMBD = 128
N_HEAD = 4
N_LAYER = 2
BLOCK_SIZE = 64
BATCH_SIZE = 16
TRAIN_STEPS = 100
VAL_STEPS = 10

# Generate synthetic text data (char-level)
print('\nGenerating training data...')
data_size = 50000
data = torch.randint(0, VOCAB_SIZE, (data_size,), device='cuda')
train_data = data[:int(0.9*data_size)]
val_data = data[int(0.9*data_size):]

def get_batch(split, batch_size=BATCH_SIZE):
    d = train_data if split == 'train' else val_data
    ix = torch.randint(len(d) - BLOCK_SIZE, (batch_size,))
    x = torch.stack([d[i:i+BLOCK_SIZE] for i in ix])
    y = torch.stack([d[i+1:i+BLOCK_SIZE+1] for i in ix])
    return x, y

# ============ STANDARD PYTORCH MODEL ============
class StandardGPT(nn.Module):
    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VOCAB_SIZE, N_EMBD)
        self.wpe = nn.Embedding(BLOCK_SIZE, N_EMBD)
        self.blocks = nn.ModuleList([
            nn.TransformerEncoderLayer(N_EMBD, N_HEAD, N_EMBD*4, dropout=0.1, batch_first=True)
            for _ in range(N_LAYER)
        ])
        self.ln_f = nn.LayerNorm(N_EMBD)
        self.lm_head = nn.Linear(N_EMBD, VOCAB_SIZE, bias=False)

    def forward(self, idx):
        B, T = idx.shape
        pos = torch.arange(0, T, device=idx.device)
        x = self.wte(idx) + self.wpe(pos)

        # Causal mask
        mask = torch.triu(torch.ones(T, T, device=idx.device), diagonal=1).bool()

        for block in self.blocks:
            x = block(x, src_mask=mask, is_causal=True)

        x = self.ln_f(x)
        return self.lm_head(x)

# ============ VLA MODEL ============
class VLAGPT(nn.Module):
    def __init__(self):
        super().__init__()
        self.wte = nn.Embedding(VOCAB_SIZE, N_EMBD)
        self.wpe = nn.Embedding(BLOCK_SIZE, N_EMBD)
        self.blocks = nn.ModuleList([
            vla.VLATransformerBlock(N_EMBD, N_HEAD, dropout=0.1)
            for _ in range(N_LAYER)
        ])
        self.ln_f = vla.VLALayerNorm(N_EMBD)
        self.lm_head = vla.VLALinear(N_EMBD, VOCAB_SIZE, bias=False)

    def forward(self, idx):
        B, T = idx.shape
        pos = torch.arange(0, T, device=idx.device)
        x = self.wte(idx) + self.wpe(pos)

        for block in self.blocks:
            x = block(x.float())

        x = self.ln_f(x.float())
        return self.lm_head(x.float())

@torch.no_grad()
def evaluate(model, use_vla=False):
    model.eval()
    losses = []
    for _ in range(VAL_STEPS):
        x, y = get_batch('val')
        logits = model(x)
        if use_vla:
            loss = vla.cross_entropy(logits.view(-1, VOCAB_SIZE), y.view(-1))
        else:
            loss = F.cross_entropy(logits.view(-1, VOCAB_SIZE), y.view(-1))
        losses.append(loss.item())
    model.train()
    avg_loss = sum(losses) / len(losses)
    ppl = math.exp(avg_loss)
    return avg_loss, ppl

def train_model(model, name, use_vla=False):
    print(f'\n{"="*70}')
    print(f'Training: {name}')
    print('='*70)

    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3)
    model.train()

    train_losses = []
    val_losses = []
    val_ppls = []

    # Initial eval
    val_loss, val_ppl = evaluate(model, use_vla)
    val_losses.append(val_loss)
    val_ppls.append(val_ppl)
    print(f'Initial: val_loss={val_loss:.4f}, val_ppl={val_ppl:.2f}')

    start = time.time()

    for step in range(TRAIN_STEPS):
        x, y = get_batch('train')

        logits = model(x)

        if use_vla:
            loss = vla.cross_entropy(logits.view(-1, VOCAB_SIZE), y.view(-1))
        else:
            loss = F.cross_entropy(logits.view(-1, VOCAB_SIZE), y.view(-1))

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        train_losses.append(loss.item())

        if (step + 1) % 25 == 0:
            val_loss, val_ppl = evaluate(model, use_vla)
            val_losses.append(val_loss)
            val_ppls.append(val_ppl)
            print(f'Step {step+1:3d}: train_loss={loss.item():.4f}, val_loss={val_loss:.4f}, val_ppl={val_ppl:.2f}')

    elapsed = time.time() - start

    return {
        'train_losses': train_losses,
        'val_losses': val_losses,
        'val_ppls': val_ppls,
        'time': elapsed,
        'final_train_loss': train_losses[-1],
        'final_val_loss': val_losses[-1],
        'final_val_ppl': val_ppls[-1],
    }

# ============ RUN COMPARISON ============
print(f'\nGPU: {torch.cuda.get_device_name(0)}')

# Standard PyTorch
torch.manual_seed(42)
torch.cuda.manual_seed(42)
std_model = StandardGPT().cuda()
std_results = train_model(std_model, 'Standard PyTorch', use_vla=False)

# VLA
torch.manual_seed(42)
torch.cuda.manual_seed(42)
vla_model = VLAGPT().cuda()
vla_results = train_model(vla_model, 'VLA Exact Arithmetic', use_vla=True)

# ============ COMPARISON ============
print('\n' + '='*70)
print('COMPARISON RESULTS')
print('='*70)

print(f'\n{"Metric":<25} {"Standard":<15} {"VLA":<15} {"Diff":<15}')
print('-'*70)

# Final train loss
diff = (std_results["final_train_loss"] - vla_results["final_train_loss"]) / std_results["final_train_loss"] * 100
print(f'{"Final Train Loss":<25} {std_results["final_train_loss"]:<15.4f} {vla_results["final_train_loss"]:<15.4f} {diff:+.2f}%')

# Final val loss
diff = (std_results["final_val_loss"] - vla_results["final_val_loss"]) / std_results["final_val_loss"] * 100
print(f'{"Final Val Loss":<25} {std_results["final_val_loss"]:<15.4f} {vla_results["final_val_loss"]:<15.4f} {diff:+.2f}%')

# Final val ppl
diff = (std_results["final_val_ppl"] - vla_results["final_val_ppl"]) / std_results["final_val_ppl"] * 100
print(f'{"Final Val PPL":<25} {std_results["final_val_ppl"]:<15.2f} {vla_results["final_val_ppl"]:<15.2f} {diff:+.2f}%')

# Time
print(f'{"Training Time (s)":<25} {std_results["time"]:<15.2f} {vla_results["time"]:<15.2f}')

# Improvement summary
ppl_improvement = (std_results["final_val_ppl"] - vla_results["final_val_ppl"]) / std_results["final_val_ppl"] * 100
print('\n' + '='*70)
if ppl_improvement > 0:
    print(f'VLA BETTER by {ppl_improvement:.2f}% perplexity')
else:
    print(f'Standard BETTER by {-ppl_improvement:.2f}% perplexity')
print('='*70)
