"""Debug 2-limb algorithm"""
import torch
import numpy as np

# Test data
x = [1e16] + [1.0] * 10000 + [-1e16]

# Python 2-limb (exact same as CUDA)
sum_hi = 0.0
sum_lo = 0.0
for v in x:
    new_hi = sum_hi + float(v)
    sum_lo = sum_lo + (float(v) - (new_hi - sum_hi))
    sum_hi = new_hi
print(f'Python 2-limb: {sum_hi + sum_lo}')

# Python 4-limb for comparison
def two_sum(a, b):
    s = a + b
    a_prime = s - b
    b_prime = s - a_prime
    e = (a - a_prime) + (b - b_prime)
    return s, e

limb0 = limb1 = limb2 = limb3 = 0.0
for v in x:
    s0, e0 = two_sum(limb0, float(v))
    s1, e1 = two_sum(limb1, e0)
    s2, e2 = two_sum(limb2, e1)
    limb0, limb1, limb2, limb3 = s0, s1, s2, limb3 + e2

print(f'Python 4-limb: {limb3 + limb2 + limb1 + limb0}')

# Naive FP64
print(f'Naive FP64: {sum(x)}')

# NumPy
print(f'NumPy FP64: {np.sum(np.array(x, dtype=np.float64))}')
