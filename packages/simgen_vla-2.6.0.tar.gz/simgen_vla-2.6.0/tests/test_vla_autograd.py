"""Debug VLA autograd."""
import torch
import torch.nn.functional as F
import sys
sys.path.insert(0, '/mnt/c/SimGen')

from simgen import vla

# Simple test: does VLACrossEntropyFunction work with autograd?
print("Testing VLACrossEntropyFunction directly...")

logits = torch.randn(4, 10, device='cuda', requires_grad=True)
targets = torch.randint(0, 10, (4,), device='cuda')

print(f"logits.requires_grad = {logits.requires_grad}")
print(f"logits.is_leaf = {logits.is_leaf}")

# Direct call to VLACrossEntropyFunction
loss = vla.VLACrossEntropyFunction.apply(logits, targets, 'mean')
print(f"loss = {loss.item():.4f}")
print(f"loss.requires_grad = {loss.requires_grad}")
print(f"loss.grad_fn = {loss.grad_fn}")

if loss.requires_grad:
    loss.backward()
    print(f"logits.grad = {logits.grad}")
    print("Backward PASSED!")
else:
    print("ERROR: loss doesn't require grad")

# Now test through the monkeypatch
print("\n" + "="*60)
print("Testing through F.cross_entropy with VLA enabled...")

vla.enable_vla()

logits2 = torch.randn(4, 10, device='cuda', requires_grad=True)
targets2 = torch.randint(0, 10, (4,), device='cuda')

loss2 = F.cross_entropy(logits2, targets2)
print(f"loss2 = {loss2.item():.4f}")
print(f"loss2.requires_grad = {loss2.requires_grad}")
print(f"loss2.grad_fn = {loss2.grad_fn}")

if loss2.requires_grad:
    loss2.backward()
    print(f"logits2.grad = {logits2.grad}")
    print("Backward PASSED!")
else:
    print("ERROR: loss2 doesn't require grad")

vla.disable_vla()
