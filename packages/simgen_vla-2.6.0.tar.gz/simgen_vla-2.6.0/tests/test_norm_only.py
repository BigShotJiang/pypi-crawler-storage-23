"""
Test ONLY the norm kernel
"""
import torch
import sys
sys.path.insert(0, 'C:/SimGen')

device = 'cuda'
print(f"Device: {torch.cuda.get_device_name()}")

from simgen import vla

print("\n" + "="*60)
print("NORM KERNEL TEST")
print("="*60)

# Test data
x = torch.randn(10_000_000, device=device, dtype=torch.float32)

# Ground truth (FP64)
gt = torch.norm(x.double()).item()
print(f"Ground truth (FP64):     {gt}")

# Standard PyTorch FP32
std_result = torch.norm(x).item()
std_error = abs(std_result - gt)
print(f"Standard FP32 result:    {std_result}")
print(f"Standard FP32 error:     {std_error:.2e}")

# VLA result
vla_result = vla.norm(x).item()
vla_error = abs(vla_result - gt)
print(f"VLA result:              {vla_result}")
print(f"VLA error:               {vla_error:.2e}")

# Comparison
if std_error > 0:
    improvement = std_error / max(vla_error, 1e-20)
    print(f"\nVLA is {improvement:.0f}x more accurate")

print("\n" + "="*60)
print("WHAT THIS KERNEL DOES:")
print("="*60)
print("""
1. L2 norm = sqrt(sum of x^2)

2. The _vla_norm_kernel computes sum(x^2) using:
   - TwoProduct: x * x = (product, error) - captures ALL rounding error
   - TwoSum accumulation: adds products + errors exactly

3. Python wrapper takes sqrt() of the exact sum of squares

4. Use cases:
   - Gradient clipping: clip_grad_norm_()
   - Weight decay: ||w||^2
   - Regularization: L2 penalty
   - Normalization: x / ||x||
   - Convergence checks: ||residual||

5. Monkey-patch target:
   - torch.norm()
   - torch.linalg.norm()
   - F.normalize() (uses norm internally)
""")
