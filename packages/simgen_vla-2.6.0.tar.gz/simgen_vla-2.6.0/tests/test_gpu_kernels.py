"""
VLA GPU Kernels Test - General Compute (not training-specific)
==============================================================
Test kernels used in simulations, scientific computing, data processing
"""
import torch
import sys
sys.path.insert(0, 'C:/SimGen')

device = 'cuda'
print(f"Device: {torch.cuda.get_device_name()}")

from simgen import vla

def test_kernel(name, vla_fn, torch_fn, inputs, description):
    """Test a kernel and report accuracy."""
    print(f"\n{'='*60}")
    print(f"KERNEL: {name}")
    print(f"USE: {description}")
    print(f"{'='*60}")

    # Ground truth (FP64)
    inputs_fp64 = tuple(x.double() if isinstance(x, torch.Tensor) else x for x in inputs)
    gt = torch_fn(*inputs_fp64)

    # Standard FP32
    inputs_fp32 = tuple(x.float() if isinstance(x, torch.Tensor) else x for x in inputs)
    std_result = torch_fn(*inputs_fp32)

    # VLA
    vla_result = vla_fn(*inputs_fp32)

    # Compute errors
    if gt.numel() == 1:
        gt_val = gt.item()
        std_err = abs(std_result.item() - gt_val)
        vla_err = abs(vla_result.item() - gt_val)
    else:
        std_err = (std_result.double() - gt).abs().max().item()
        vla_err = (vla_result.double() - gt).abs().max().item()

    print(f"  Standard FP32 error: {std_err:.2e}")
    print(f"  VLA error:           {vla_err:.2e}")

    if std_err > 0 and vla_err > 0:
        print(f"  VLA improvement:     {std_err/vla_err:.0f}x more accurate")
    elif vla_err == 0:
        print(f"  VLA improvement:     EXACT (zero error)")

    status = "PASS" if vla_err <= std_err else "FAIL"
    print(f"  Result: {status}")
    return status == "PASS"

results = {}

# =============================================================================
# REDUCTIONS - Used in statistics, signal processing, simulations
# =============================================================================

print("\n" + "#"*60)
print("# REDUCTION KERNELS")
print("#"*60)

# SUM - accumulating values
x = torch.randn(1_000_000, device=device)
results['sum'] = test_kernel(
    "vla.sum", vla.sum, torch.sum, (x,),
    "Accumulating values (physics sims, statistics)"
)

# MEAN - averaging
results['mean'] = test_kernel(
    "vla.mean", vla.mean, torch.mean, (x,),
    "Computing averages (signal processing, statistics)"
)

# VAR - variance
results['var'] = test_kernel(
    "vla.var", vla.var, torch.var, (x,),
    "Variance calculation (uncertainty quantification)"
)

# STD - standard deviation
results['std'] = test_kernel(
    "vla.std", vla.std, torch.std, (x,),
    "Standard deviation (quality control, statistics)"
)

# NORM - vector magnitude
results['norm'] = test_kernel(
    "vla.norm", vla.norm, torch.norm, (x,),
    "Vector magnitude (physics, convergence checks)"
)

# =============================================================================
# DOT PRODUCT - Used in physics, graphics, ML
# =============================================================================

print("\n" + "#"*60)
print("# DOT PRODUCT / INNER PRODUCT")
print("#"*60)

a = torch.randn(1_000_000, device=device)
b = torch.randn(1_000_000, device=device)
results['dot'] = test_kernel(
    "vla.dot", vla.dot, torch.dot, (a, b),
    "Inner product (projections, correlations, similarity)"
)

# =============================================================================
# MATRIX OPERATIONS - Used everywhere
# =============================================================================

print("\n" + "#"*60)
print("# MATRIX OPERATIONS")
print("#"*60)

A = torch.randn(256, 256, device=device)
B = torch.randn(256, 256, device=device)
results['matmul'] = test_kernel(
    "vla.matmul", vla.matmul, torch.matmul, (A, B),
    "Matrix multiply (linear systems, transformations, ML)"
)

# Linear (y = xW + b)
x_lin = torch.randn(128, 512, device=device)
W = torch.randn(256, 512, device=device)
b_lin = torch.randn(256, device=device)

def torch_linear(x, w, b):
    return torch.nn.functional.linear(x, w, b)

def vla_linear(x, w, b):
    return vla.linear(x, w, b)

results['linear'] = test_kernel(
    "vla.linear", vla_linear, torch_linear, (x_lin, W, b_lin),
    "Linear transform y=xW+b (neural nets, projections)"
)

# =============================================================================
# TRANSCENDENTAL FUNCTIONS - Used in physics, signal processing
# =============================================================================

print("\n" + "#"*60)
print("# TRANSCENDENTAL FUNCTIONS")
print("#"*60)

x_pos = torch.rand(100_000, device=device) + 0.1  # Positive for log/sqrt
x_any = torch.randn(100_000, device=device)

results['exp'] = test_kernel(
    "vla.exp", vla.exp, torch.exp, (x_any,),
    "Exponential (decay, growth, probability)"
)

results['log'] = test_kernel(
    "vla.log", vla.log, torch.log, (x_pos,),
    "Logarithm (entropy, information, compression)"
)

results['sqrt'] = test_kernel(
    "vla.sqrt", vla.sqrt, torch.sqrt, (x_pos,),
    "Square root (distances, RMS, std dev)"
)

results['sin'] = test_kernel(
    "vla.sin", vla.sin, torch.sin, (x_any,),
    "Sine (waves, oscillations, rotations)"
)

results['cos'] = test_kernel(
    "vla.cos", vla.cos, torch.cos, (x_any,),
    "Cosine (waves, oscillations, rotations)"
)

results['tanh'] = test_kernel(
    "vla.tanh", vla.tanh, torch.tanh, (x_any,),
    "Hyperbolic tangent (normalization, activations)"
)

# =============================================================================
# SUMMARY
# =============================================================================

print("\n" + "="*60)
print("SUMMARY - GPU COMPUTE KERNELS")
print("="*60)

passed = sum(1 for v in results.values() if v)
total = len(results)

for name, result in results.items():
    status = "PASS" if result else "FAIL"
    print(f"  {name}: {status}")

print(f"\n  Total: {passed}/{total} passed")

if passed == total:
    print("\n  ALL GPU COMPUTE KERNELS WORKING!")
else:
    print(f"\n  {total - passed} kernel(s) need fixing")
