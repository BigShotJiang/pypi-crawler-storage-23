"""
FINAL VLA TEST - Verify ALL operations use TRUE VLA (no PyTorch wrappers)
"""
import torch
import sys
sys.path.insert(0, '/mnt/c/SimGen')

# Import vla.py directly (not vla_runtime.so)
import importlib.util
spec = importlib.util.spec_from_file_location("vla", "/mnt/c/SimGen/simgen/vla.py")
vla = importlib.util.module_from_spec(spec)
spec.loader.exec_module(vla)

def test_all():
    print("=" * 60)
    print("TRUE VLA FINAL TEST - All Operations")
    print("=" * 60)

    all_passed = True

    # Test 1: Catastrophic cancellation (the gold standard)
    print("\n[1] SUM - Catastrophic Cancellation")
    x = torch.tensor([1e16, 1.0, -1e16], device='cuda', dtype=torch.float32)
    result = vla.sum(x).item()
    expected = 1.0
    passed = result == expected
    print(f"    1e16 + 1 - 1e16 = {result} (expected {expected})")
    print(f"    {'✓ PASS' if passed else '✗ FAIL'}")
    all_passed &= passed

    # Test 2: Unique with inverse and counts
    print("\n[2] UNIQUE with return_inverse and return_counts")
    x = torch.tensor([3, 1, 2, 1, 3, 3, 2], device='cuda', dtype=torch.float32)
    unique_vals, inverse, counts = vla.unique(x, return_inverse=True, return_counts=True)
    print(f"    Input: {x.tolist()}")
    print(f"    Unique: {unique_vals.tolist()}")
    print(f"    Inverse: {inverse.tolist()}")
    print(f"    Counts: {counts.tolist()}")
    # Verify: unique should be [1, 2, 3], counts should be [2, 2, 3]
    expected_unique = [1.0, 2.0, 3.0]
    expected_counts = [2, 2, 3]
    passed = (unique_vals.tolist() == expected_unique and counts.tolist() == expected_counts)
    print(f"    {'✓ PASS' if passed else '✗ FAIL'}")
    all_passed &= passed

    # Test 3: logsumexp full reduction
    print("\n[3] LOGSUMEXP - Full Reduction")
    x = torch.tensor([1.0, 2.0, 3.0], device='cuda', dtype=torch.float32)
    result = vla.logsumexp(x, dim=None).item()
    expected = torch.logsumexp(x.double(), dim=0).item()
    error = abs(result - expected)
    passed = error < 1e-10
    print(f"    VLA: {result}")
    print(f"    Expected: {expected}")
    print(f"    Error: {error}")
    print(f"    {'✓ PASS' if passed else '✗ FAIL'}")
    all_passed &= passed

    # Test 4: topk
    print("\n[4] TOPK")
    x = torch.randn(10, device='cuda', dtype=torch.float32)
    values, indices = vla.topk(x, k=3, largest=True)
    torch_values, torch_indices = torch.topk(x.double(), k=3, largest=True)
    passed = torch.allclose(values.double(), torch_values, atol=1e-10)
    print(f"    VLA topk values: {values.tolist()[:3]}")
    print(f"    Torch topk values: {torch_values.tolist()[:3]}")
    print(f"    {'✓ PASS' if passed else '✗ FAIL'}")
    all_passed &= passed

    # Test 5: dot product
    print("\n[5] DOT PRODUCT")
    x = torch.randn(1000, device='cuda', dtype=torch.float32)
    y = torch.randn(1000, device='cuda', dtype=torch.float32)
    vla_dot = vla.dot(x, y).item()
    torch_dot = torch.dot(x.double(), y.double()).item()
    error = abs(vla_dot - torch_dot)
    passed = error < 1e-10
    print(f"    VLA: {vla_dot}")
    print(f"    Torch FP64: {torch_dot}")
    print(f"    Error: {error}")
    print(f"    {'✓ PASS' if passed else '✗ FAIL'}")
    all_passed &= passed

    # Test 6: matmul
    print("\n[6] MATMUL")
    A = torch.randn(32, 64, device='cuda', dtype=torch.float32)
    B = torch.randn(64, 32, device='cuda', dtype=torch.float32)
    vla_result = vla.matmul(A, B)
    torch_result = torch.matmul(A.double(), B.double())
    max_error = (vla_result - torch_result).abs().max().item()
    passed = max_error < 1e-8
    print(f"    Max error: {max_error}")
    print(f"    {'✓ PASS' if passed else '✗ FAIL'}")
    all_passed &= passed

    # Test 7: norm
    print("\n[7] NORM")
    x = torch.randn(1000, device='cuda', dtype=torch.float32)
    vla_norm = vla.norm(x).item()
    torch_norm = torch.norm(x.double()).item()
    error = abs(vla_norm - torch_norm)
    passed = error < 1e-10
    print(f"    VLA: {vla_norm}")
    print(f"    Torch FP64: {torch_norm}")
    print(f"    Error: {error}")
    print(f"    {'✓ PASS' if passed else '✗ FAIL'}")
    all_passed &= passed

    # Test 8: sort
    print("\n[8] SORT")
    x = torch.randn(100, device='cuda', dtype=torch.float32)
    vla_sorted, vla_idx = vla.sort(x, dim=0)
    torch_sorted, torch_idx = torch.sort(x.double(), dim=0)
    passed = torch.allclose(vla_sorted, torch_sorted, atol=1e-10)
    print(f"    Values match: {passed}")
    print(f"    {'✓ PASS' if passed else '✗ FAIL'}")
    all_passed &= passed

    # Test 9: softmax
    print("\n[9] SOFTMAX")
    x = torch.randn(10, device='cuda', dtype=torch.float32)
    vla_sm = vla.softmax(x, dim=-1)
    torch_sm = torch.softmax(x.double(), dim=-1)
    max_error = (vla_sm - torch_sm).abs().max().item()
    passed = max_error < 1e-10
    print(f"    Max error: {max_error}")
    print(f"    {'✓ PASS' if passed else '✗ FAIL'}")
    all_passed &= passed

    # Test 10: det
    print("\n[10] DETERMINANT")
    A = torch.randn(4, 4, device='cuda', dtype=torch.float32)
    vla_det = vla.det(A).item()
    torch_det = torch.linalg.det(A.double()).item()
    error = abs(vla_det - torch_det)
    rel_error = error / (abs(torch_det) + 1e-10)
    passed = rel_error < 1e-6
    print(f"    VLA: {vla_det}")
    print(f"    Torch FP64: {torch_det}")
    print(f"    Relative error: {rel_error}")
    print(f"    {'✓ PASS' if passed else '✗ FAIL'}")
    all_passed &= passed

    # Test 11: FFT
    print("\n[11] FFT")
    x = torch.randn(64, device='cuda', dtype=torch.float32)
    vla_fft = vla.fft(x)
    torch_fft = torch.fft.fft(x.double())
    max_error = (vla_fft - torch_fft).abs().max().item()
    passed = max_error < 1e-6
    print(f"    Max error: {max_error}")
    print(f"    {'✓ PASS' if passed else '✗ FAIL'}")
    all_passed &= passed

    # Test 12: arcsin/arccos/arctan (Triton, not PyTorch)
    print("\n[12] ARCSIN/ARCCOS/ARCTAN (Triton)")
    x = torch.tensor([0.5], device='cuda', dtype=torch.float32)
    vla_asin = vla.arcsin(x).item()
    vla_acos = vla.arccos(x).item()
    vla_atan = vla.arctan(x).item()
    torch_asin = torch.asin(x.double()).item()
    torch_acos = torch.acos(x.double()).item()
    torch_atan = torch.atan(x.double()).item()
    passed = (abs(vla_asin - torch_asin) < 1e-10 and
              abs(vla_acos - torch_acos) < 1e-10 and
              abs(vla_atan - torch_atan) < 1e-10)
    print(f"    arcsin: VLA={vla_asin}, torch={torch_asin}")
    print(f"    arccos: VLA={vla_acos}, torch={torch_acos}")
    print(f"    arctan: VLA={vla_atan}, torch={torch_atan}")
    print(f"    {'✓ PASS' if passed else '✗ FAIL'}")
    all_passed &= passed

    # Summary
    print("\n" + "=" * 60)
    if all_passed:
        print("ALL TRUE VLA OPERATIONS PASSED!")
        print("NO PYTORCH WRAPPERS IN FORWARD PATH!")
    else:
        print("SOME TESTS FAILED")
    print("=" * 60)

    return all_passed

if __name__ == "__main__":
    test_all()
