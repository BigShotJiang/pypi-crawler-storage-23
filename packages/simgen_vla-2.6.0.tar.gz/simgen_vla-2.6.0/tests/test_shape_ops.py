"""
Test VLA Shape Operations
"""
import torch
import sys
sys.path.insert(0, '/mnt/c/SimGen')

import importlib.util
spec = importlib.util.spec_from_file_location("vla", "/mnt/c/SimGen/simgen/vla.py")
vla = importlib.util.module_from_spec(spec)
spec.loader.exec_module(vla)

print("=" * 60)
print("VLA SHAPE OPERATIONS TEST")
print("=" * 60)

all_passed = True

# Test 1: reshape
print("\n[1] RESHAPE")
x = torch.randn(2, 3, 4, device='cuda')
y = vla.reshape(x, (6, 4))
passed = y.shape == torch.Size([6, 4])
print(f"    {x.shape} -> {y.shape}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 2: transpose
print("\n[2] TRANSPOSE")
x = torch.randn(2, 3, device='cuda')
y = vla.transpose(x, 0, 1)
passed = y.shape == torch.Size([3, 2])
print(f"    {x.shape} transpose(0,1) -> {y.shape}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 3: permute
print("\n[3] PERMUTE")
x = torch.randn(2, 3, 4, device='cuda')
y = vla.permute(x, (2, 0, 1))
passed = y.shape == torch.Size([4, 2, 3])
print(f"    {x.shape} permute(2,0,1) -> {y.shape}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 4: squeeze/unsqueeze
print("\n[4] SQUEEZE/UNSQUEEZE")
x = torch.randn(1, 3, 1, 4, device='cuda')
y = vla.squeeze(x)
passed = y.shape == torch.Size([3, 4])
print(f"    squeeze {x.shape} -> {y.shape}: {'✓' if passed else '✗'}")
all_passed &= passed

x = torch.randn(3, 4, device='cuda')
y = vla.unsqueeze(x, 0)
passed = y.shape == torch.Size([1, 3, 4])
print(f"    unsqueeze {x.shape} dim=0 -> {y.shape}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 5: cat
print("\n[5] CAT")
a = torch.randn(2, 3, device='cuda')
b = torch.randn(2, 3, device='cuda')
c = vla.cat([a, b], dim=0)
passed = c.shape == torch.Size([4, 3])
print(f"    cat([2,3], [2,3]) dim=0 -> {c.shape}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 6: stack
print("\n[6] STACK")
a = torch.randn(2, 3, device='cuda')
b = torch.randn(2, 3, device='cuda')
c = vla.stack([a, b], dim=0)
passed = c.shape == torch.Size([2, 2, 3])
print(f"    stack([2,3], [2,3]) dim=0 -> {c.shape}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 7: split/chunk
print("\n[7] SPLIT/CHUNK")
x = torch.randn(6, 4, device='cuda')
parts = vla.split(x, 2, dim=0)
passed = len(parts) == 3 and parts[0].shape == torch.Size([2, 4])
print(f"    split [6,4] into 2s -> {len(parts)} parts: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 8: flatten
print("\n[8] FLATTEN")
x = torch.randn(2, 3, 4, device='cuda')
y = vla.flatten(x)
passed = y.shape == torch.Size([24])
print(f"    flatten {x.shape} -> {y.shape}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 9: gather
print("\n[9] GATHER")
x = torch.tensor([[1, 2], [3, 4]], device='cuda', dtype=torch.float32)
idx = torch.tensor([[0, 1], [1, 0]], device='cuda')
y = vla.gather(x, 1, idx)
expected = torch.tensor([[1, 2], [4, 3]], device='cuda', dtype=torch.float32)
passed = torch.allclose(y, expected)
print(f"    gather: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 10: index_select
print("\n[10] INDEX_SELECT")
x = torch.randn(3, 4, device='cuda')
idx = torch.tensor([0, 2], device='cuda')
y = vla.index_select(x, 0, idx)
passed = y.shape == torch.Size([2, 4])
print(f"    index_select {x.shape} idx=[0,2] -> {y.shape}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 11: flip
print("\n[11] FLIP")
x = torch.tensor([1, 2, 3, 4], device='cuda', dtype=torch.float32)
y = vla.flip(x, [0])
expected = torch.tensor([4, 3, 2, 1], device='cuda', dtype=torch.float32)
passed = torch.allclose(y, expected)
print(f"    flip [1,2,3,4] -> {y.tolist()}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 12: roll
print("\n[12] ROLL")
x = torch.tensor([1, 2, 3, 4], device='cuda', dtype=torch.float32)
y = vla.roll(x, 2)
expected = torch.tensor([3, 4, 1, 2], device='cuda', dtype=torch.float32)
passed = torch.allclose(y, expected)
print(f"    roll [1,2,3,4] by 2 -> {y.tolist()}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 13: pad
print("\n[13] PAD")
x = torch.randn(2, 3, device='cuda')
y = vla.pad(x, (1, 1, 2, 2))
passed = y.shape == torch.Size([6, 5])
print(f"    pad {x.shape} (1,1,2,2) -> {y.shape}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 14: meshgrid
print("\n[14] MESHGRID")
x = torch.tensor([1, 2, 3], device='cuda')
y = torch.tensor([4, 5], device='cuda')
xx, yy = vla.meshgrid(x, y)
passed = xx.shape == torch.Size([3, 2]) and yy.shape == torch.Size([3, 2])
print(f"    meshgrid [3] x [2] -> {xx.shape}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 15: comparison ops
print("\n[15] COMPARISON OPS")
x = torch.tensor([1, 2, 3], device='cuda', dtype=torch.float32)
y = torch.tensor([2, 2, 2], device='cuda', dtype=torch.float32)
lt = vla.lt(x, y)
eq = vla.eq(x, y)
gt = vla.gt(x, y)
passed = lt.tolist() == [True, False, False] and eq.tolist() == [False, True, False]
print(f"    lt: {lt.tolist()}, eq: {eq.tolist()}, gt: {gt.tolist()}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 16: floor/ceil/trunc
print("\n[16] FLOOR/CEIL/TRUNC")
x = torch.tensor([1.5, -1.5, 2.7], device='cuda', dtype=torch.float32)
f = vla.floor(x)
c = vla.ceil(x)
t = vla.trunc(x)
passed = f.tolist() == [1.0, -2.0, 2.0] and c.tolist() == [2.0, -1.0, 3.0]
print(f"    floor: {f.tolist()}, ceil: {c.tolist()}, trunc: {t.tolist()}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 17: log2/log10/exp2
print("\n[17] LOG2/LOG10/EXP2")
x = torch.tensor([2.0, 10.0, 100.0], device='cuda', dtype=torch.float32)
l2 = vla.log2(x)
l10 = vla.log10(x)
passed = abs(l2[0].item() - 1.0) < 1e-10 and abs(l10[1].item() - 1.0) < 1e-10
print(f"    log2(2)={l2[0].item():.4f}, log10(10)={l10[1].item():.4f}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 18: sinh/cosh/asinh
print("\n[18] SINH/COSH/ASINH")
x = torch.tensor([0.0, 1.0], device='cuda', dtype=torch.float32)
sh = vla.sinh(x)
ch = vla.cosh(x)
passed = abs(sh[0].item()) < 1e-10 and abs(ch[0].item() - 1.0) < 1e-10
print(f"    sinh(0)={sh[0].item():.4f}, cosh(0)={ch[0].item():.4f}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 19: erf
print("\n[19] ERF")
x = torch.tensor([0.0, 1.0], device='cuda', dtype=torch.float32)
e = vla.erf(x)
passed = abs(e[0].item()) < 1e-10  # erf(0) = 0
print(f"    erf(0)={e[0].item():.6f}: {'✓' if passed else '✗'}")
all_passed &= passed

# Test 20: random
print("\n[20] RANDOM")
r = vla.rand(100, device='cuda')
rn = vla.randn(100, device='cuda')
ri = vla.randint(0, 10, (100,), device='cuda')
passed = r.shape == torch.Size([100]) and rn.shape == torch.Size([100])
print(f"    rand/randn/randint shapes OK: {'✓' if passed else '✗'}")
all_passed &= passed

# Summary
print("\n" + "=" * 60)
if all_passed:
    print("ALL SHAPE OPERATIONS PASSED!")
else:
    print("SOME TESTS FAILED")
print("=" * 60)
