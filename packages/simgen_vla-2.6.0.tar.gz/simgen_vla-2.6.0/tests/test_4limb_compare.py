"""Compare 2-limb vs 4-limb for the failing case."""
import torch
import sys
sys.path.insert(0, '/mnt/c/SimGen')

# Clear cache
import shutil, os
cache_dir = os.path.expanduser("~/.triton/cache")
if os.path.exists(cache_dir):
    shutil.rmtree(cache_dir)

# The failing block: 17 ones followed by -1e16
values = [1.0] * 17 + [-1e16]

# Python 2-limb simulation
sum_hi = 0.0
sum_lo = 0.0
for v in values:
    new_hi = sum_hi + v
    diff = new_hi - sum_hi
    error = v - diff
    sum_lo = sum_lo + error
    sum_hi = new_hi
print(f"Python 2-limb for block 39 data:")
print(f"  sum_hi = {sum_hi}")
print(f"  sum_lo = {sum_lo}")
print(f"  total = {sum_hi + sum_lo}")

# Python 4-limb simulation (TwoSum cascade)
def two_sum(a, b):
    s = a + b
    a_prime = s - b
    b_prime = s - a_prime
    e = (a - a_prime) + (b - b_prime)
    return s, e

limb0 = limb1 = limb2 = limb3 = 0.0
for v in values:
    s0, e0 = two_sum(limb0, float(v))
    s1, e1 = two_sum(limb1, e0)
    s2, e2 = two_sum(limb2, e1)
    limb0, limb1, limb2, limb3 = s0, s1, s2, limb3 + e2

print(f"\nPython 4-limb for block 39 data:")
print(f"  limb0 = {limb0}")
print(f"  limb1 = {limb1}")
print(f"  limb2 = {limb2}")
print(f"  limb3 = {limb3}")
print(f"  total = {limb3 + limb2 + limb1 + limb0}")

# Now check what happens with the CORRECT order (1e16 first, then ones, then -1e16)
print("\n" + "="*60)
print("With CORRECT order (1e16, then 10000 ones, then -1e16):")
values_ordered = [1e16] + [1.0] * 10000 + [-1e16]

# Python 2-limb
sum_hi = 0.0
sum_lo = 0.0
for v in values_ordered:
    new_hi = sum_hi + v
    diff = new_hi - sum_hi
    error = v - diff
    sum_lo = sum_lo + error
    sum_hi = new_hi
print(f"Python 2-limb: {sum_hi + sum_lo}")

# Python 4-limb
limb0 = limb1 = limb2 = limb3 = 0.0
for v in values_ordered:
    s0, e0 = two_sum(limb0, float(v))
    s1, e1 = two_sum(limb1, e0)
    s2, e2 = two_sum(limb2, e1)
    limb0, limb1, limb2, limb3 = s0, s1, s2, limb3 + e2
print(f"Python 4-limb: {limb3 + limb2 + limb1 + limb0}")

# Block-parallel simulation: values distributed across blocks
print("\n" + "="*60)
print("Block-parallel simulation (BLOCK=256):")
BLOCK = 256
n = len(values_ordered)
n_blocks = (n + BLOCK - 1) // BLOCK

block_results_2limb = []
block_results_4limb = []

for b in range(n_blocks):
    start = b * BLOCK
    end = min(start + BLOCK, n)
    block_vals = values_ordered[start:end]

    # 2-limb
    hi, lo = 0.0, 0.0
    for v in block_vals:
        new_hi = hi + v
        diff = new_hi - hi
        error = v - diff
        lo = lo + error
        hi = new_hi
    block_results_2limb.append((hi, lo))

    # 4-limb
    l0 = l1 = l2 = l3 = 0.0
    for v in block_vals:
        s0, e0 = two_sum(l0, float(v))
        s1, e1 = two_sum(l1, e0)
        s2, e2 = two_sum(l2, e1)
        l0, l1, l2, l3 = s0, s1, s2, l3 + e2
    block_results_4limb.append((l0, l1, l2, l3))

# Reduce 2-limb results
print("\n2-limb block reduction:")
sum_hi, sum_lo = 0.0, 0.0
for hi, lo in block_results_2limb:
    # Add hi
    new_hi = sum_hi + hi
    diff = new_hi - sum_hi
    error = hi - diff
    sum_lo = sum_lo + error
    sum_hi = new_hi
    # Add lo
    new_hi = sum_hi + lo
    diff = new_hi - sum_hi
    error = lo - diff
    sum_lo = sum_lo + error
    sum_hi = new_hi
print(f"  Final: sum_hi={sum_hi}, sum_lo={sum_lo}, total={sum_hi + sum_lo}")

# Reduce 4-limb results
print("\n4-limb block reduction:")
r0 = r1 = r2 = r3 = 0.0
for l0, l1, l2, l3 in block_results_4limb:
    for v in [l0, l1, l2, l3]:
        s0, e0 = two_sum(r0, v)
        s1, e1 = two_sum(r1, e0)
        s2, e2 = two_sum(r2, e1)
        r0, r1, r2, r3 = s0, s1, s2, r3 + e2
print(f"  Final: total={r3 + r2 + r1 + r0}")
