from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from comate_cli.terminal_agent.preflight import (
    PROVIDER_PRESETS,
    LevelConfigDraft,
    PreflightCheckResult,
    _PreflightWizard,
    _PreflightWizardFlowResult,
    _build_preflight_entry_options,
    _format_level_summary,
    _format_missing_reasons,
    _print_preflight_block_message,
    build_preview_payload,
    evaluate_preflight_state,
    merge_user_settings,
    run_preflight_if_needed,
)


class TestPreflightState(unittest.TestCase):
    def test_missing_config_requires_preflight(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            result = evaluate_preflight_state(
                project_root=root,
                env={},
                user_settings_path=root / "user-settings.json",
            )
        self.assertTrue(result.needs_preflight)
        self.assertEqual(result.mode, "env")
        self.assertEqual(result.missing_levels, ("LOW", "MID", "HIGH"))
        self.assertTrue(any("Model levels not fully configured" in reason for reason in result.reasons))

    def test_complete_env_config_skips_preflight(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            env = {
                "COMATE_AGENT_SDK_LLM_LOW": "anthropic:claude-haiku-4-5",
                "COMATE_AGENT_SDK_LLM_MID": "anthropic:claude-sonnet-4-5",
                "COMATE_AGENT_SDK_LLM_HIGH": "anthropic:claude-opus-4-5",
                "ANTHROPIC_API_KEY": "test-key",
            }
            result = evaluate_preflight_state(
                project_root=root,
                env=env,
                user_settings_path=root / "user-settings.json",
            )
        self.assertFalse(result.needs_preflight)
        self.assertEqual(result.missing_levels, ())
        self.assertEqual(result.missing_key_levels, ())

    def test_partial_settings_requires_preflight(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            user_settings = root / "user-settings.json"
            user_settings.write_text(
                json.dumps(
                    {
                        "llm_levels": {"LOW": "deepseek:deepseek-chat"},
                        "llm_levels_api_key": {"LOW": "k-low"},
                    }
                ),
                encoding="utf-8",
            )
            result = evaluate_preflight_state(
                project_root=root,
                env={},
                user_settings_path=user_settings,
            )
        self.assertTrue(result.needs_preflight)
        self.assertEqual(result.mode, "settings")
        self.assertEqual(result.llm_levels_source, "user")
        self.assertEqual(result.missing_levels, ("MID", "HIGH"))

    def test_env_mode_ignores_settings_api_keys(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            user_settings = root / "user-settings.json"
            user_settings.write_text(
                json.dumps({"llm_levels_api_key": {"LOW": "x", "MID": "y", "HIGH": "z"}}),
                encoding="utf-8",
            )
            env = {
                "COMATE_AGENT_SDK_LLM_LOW": "openai:gpt-5-mini",
                "COMATE_AGENT_SDK_LLM_MID": "openai:gpt-5",
                "COMATE_AGENT_SDK_LLM_HIGH": "openai:gpt-5",
            }
            result = evaluate_preflight_state(
                project_root=root,
                env=env,
                user_settings_path=user_settings,
            )
        self.assertTrue(result.needs_preflight)
        self.assertEqual(result.mode, "env")
        self.assertEqual(result.missing_key_levels, ("LOW", "MID", "HIGH"))

    def test_empty_settings_levels_falls_back_to_env_mode(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            user_settings = root / "user-settings.json"
            user_settings.write_text(
                json.dumps({"llm_levels": {}}),
                encoding="utf-8",
            )
            env = {
                "COMATE_AGENT_SDK_LLM_LOW": "anthropic:claude-haiku-4-5",
                "COMATE_AGENT_SDK_LLM_MID": "anthropic:claude-sonnet-4-5",
                "COMATE_AGENT_SDK_LLM_HIGH": "anthropic:claude-opus-4-5",
                "ANTHROPIC_API_KEY": "test-key",
            }
            result = evaluate_preflight_state(
                project_root=root,
                env=env,
                user_settings_path=user_settings,
            )
        self.assertFalse(result.needs_preflight)
        self.assertEqual(result.mode, "env")


class TestPreflightMerge(unittest.TestCase):
    def test_merge_preserves_unrelated_fields(self) -> None:
        merged = merge_user_settings(
            existing={
                "permissions": {"allow": ["psql"], "deny": []},
                "llm_levels": {"LOW": "openai:gpt-4o"},
            },
            levels={
                "LOW": LevelConfigDraft(
                    provider="deepseek",
                    model="deepseek-chat",
                    base_url="https://api.deepseek.com",
                    api_key="low-key",
                ),
                "MID": LevelConfigDraft(
                    provider="deepseek",
                    model="deepseek-chat",
                    base_url="https://api.deepseek.com",
                    api_key="mid-key",
                ),
                "HIGH": LevelConfigDraft(
                    provider="deepseek",
                    model="deepseek-reasoner",
                    base_url="https://api.deepseek.com",
                    api_key="high-key",
                ),
            },
        )
        self.assertIn("permissions", merged)
        self.assertEqual(merged["permissions"]["allow"], ["psql"])
        self.assertEqual(
            merged["llm_levels"]["HIGH"],
            "deepseek:deepseek-reasoner",
        )
        self.assertEqual(
            merged["llm_levels_base_url"]["LOW"],
            "https://api.deepseek.com",
        )
        self.assertEqual(merged["llm_levels_api_key"]["MID"], "mid-key")

    def test_preview_masks_api_keys(self) -> None:
        preview = build_preview_payload(
            {
                "LOW": LevelConfigDraft(
                    provider="anthropic",
                    model="kimi-for-coding",
                    base_url="https://api.kimi.com/coding",
                    api_key="secret",
                ),
                "MID": LevelConfigDraft(
                    provider="anthropic",
                    model="kimi-for-coding",
                    base_url="https://api.kimi.com/coding",
                    api_key="secret",
                ),
                "HIGH": LevelConfigDraft(
                    provider="anthropic",
                    model="kimi-for-coding",
                    base_url="https://api.kimi.com/coding",
                    api_key="secret",
                ),
            }
        )
        self.assertEqual(preview["llm_levels_api_key"]["LOW"], "***")

    def test_presets_include_zai_cn_and_global(self) -> None:
        preset_map = {preset.preset_id: preset for preset in PROVIDER_PRESETS}
        self.assertIn("zai_cn", preset_map)
        self.assertIn("zai_global", preset_map)
        self.assertEqual(
            preset_map["zai_cn"].base_url,
            "https://open.bigmodel.cn/api/anthropic",
        )
        self.assertEqual(
            preset_map["zai_global"].base_url,
            "https://api.z.ai/api/anthropic",
        )

    def test_provider_presets_are_brand_only(self) -> None:
        labels = [preset.label for preset in PROVIDER_PRESETS]
        self.assertEqual(
            labels,
            [
                "DeepSeek",
                "MiniMax",
                "Kimi",
                "z.ai (CN)",
                "z.ai (Global)",
                "OpenAI",
                "Anthropic",
            ],
        )
        for preset in PROVIDER_PRESETS:
            text = f"{preset.label} {preset.description}".lower()
            self.assertNotIn("native", text)
            self.assertNotIn("compatible", text)
            self.assertNotIn("generic", text)
            self.assertNotIn("base_url", text)

    def test_presets_include_openai_and_anthropic_defaults(self) -> None:
        preset_map = {preset.preset_id: preset for preset in PROVIDER_PRESETS}
        self.assertEqual(preset_map["openai"].base_url, "https://api.openai.com/v1")
        self.assertEqual(preset_map["openai"].models["LOW"], "gpt-5-mini")
        self.assertEqual(preset_map["anthropic"].base_url, "https://api.anthropic.com")
        self.assertEqual(preset_map["anthropic"].models["MID"], "claude-sonnet-4-5")

    def test_level_summary_is_two_row_aligned_layout(self) -> None:
        summary = _format_level_summary(
            level="LOW",
            entry=LevelConfigDraft(
                provider="minimax",
                model="MiniMax-M2.5",
                base_url="https://api.minimaxi.com/anthropic",
            ),
        )
        lines = summary.splitlines()
        self.assertEqual(len(lines), 2)
        self.assertTrue(lines[0].startswith("LOW   "))
        self.assertIn("Model", lines[0])
        self.assertIn("minimax:MiniMax-M2.5", lines[0])
        self.assertTrue(lines[1].startswith("      "))
        self.assertIn("Endpoint", lines[1])
        self.assertIn("https://api.minimaxi.com/anthropic", lines[1])


class TestPreflightCopy(unittest.TestCase):
    def test_missing_reasons_are_indented(self) -> None:
        text = _format_missing_reasons(
            ("Model levels not fully configured: LOW, MID, HIGH",)
        )
        self.assertIn("What's missing:", text)
        self.assertIn("  - Model levels not fully configured: LOW, MID, HIGH", text)

    def test_block_message_uses_provider_setup_wording(self) -> None:
        class _FakeConsole:
            def __init__(self) -> None:
                self.lines: list[str] = []

            def print(self, text: str) -> None:
                self.lines.append(text)

        console = _FakeConsole()
        _print_preflight_block_message(
            console=console,
            check=PreflightCheckResult(
                needs_preflight=True,
                reasons=("Model levels not fully configured: LOW, MID, HIGH",),
                mode="env",
                llm_levels_source=None,
                llm_levels={},
                missing_levels=("LOW", "MID", "HIGH"),
                missing_key_levels=(),
            ),
        )
        full = "\n".join(console.lines)
        self.assertIn("Provider setup required", full)
        self.assertIn("configure an API provider before you can continue", full)

    def test_entry_options_do_not_show_missing_reasons(self) -> None:
        options = _build_preflight_entry_options()
        self.assertEqual(len(options), 2)
        start = next(item for item in options if item["value"] == "continue")
        self.assertEqual(start["description"], "")


class TestPreflightWizard(unittest.TestCase):
    def _build_wizard(self) -> _PreflightWizard:
        return _PreflightWizard(
            check=PreflightCheckResult(
                needs_preflight=True,
                reasons=("Model levels not fully configured: LOW, MID, HIGH",),
                mode="env",
                llm_levels_source=None,
                llm_levels={},
                missing_levels=("LOW", "MID", "HIGH"),
                missing_key_levels=(),
            ),
            project_root=Path("/tmp/project"),
        )

    def test_wizard_reuses_single_application_instance(self) -> None:
        with patch("comate_cli.terminal_agent.preflight.Application") as app_cls:
            wizard = self._build_wizard()
            wizard._open_provider_menu()
            wizard._selected_preset = PROVIDER_PRESETS[0]
            wizard._draft = wizard._selected_preset.build_draft()
            wizard._open_edit_menu()

        self.assertEqual(app_cls.call_count, 1)

    def test_provider_menu_descriptions_are_empty(self) -> None:
        wizard = self._build_wizard()
        wizard._open_provider_menu()
        descriptions = [opt.description for opt in wizard._selection_ui._state.options]
        self.assertTrue(descriptions)
        self.assertTrue(all(desc == "" for desc in descriptions))
        self.assertEqual(wizard._selection_ui._state.item_gap_lines, 1)

    def test_provider_menu_prioritizes_openai_anthropic_first(self) -> None:
        wizard = self._build_wizard()
        wizard._open_provider_menu()
        labels = [opt.label for opt in wizard._selection_ui._state.options]
        self.assertGreaterEqual(len(labels), 2)
        self.assertEqual(labels[0], "OpenAI")
        self.assertEqual(labels[1], "Anthropic")

    def test_shared_endpoint_menu_has_single_endpoint_action(self) -> None:
        wizard = self._build_wizard()
        wizard._selected_preset = next(p for p in PROVIDER_PRESETS if p.preset_id == "deepseek")
        wizard._draft = wizard._selected_preset.build_draft()
        wizard._open_edit_menu()
        values = [opt.value for opt in wizard._selection_ui._state.options]
        self.assertIn("edit:endpoint", values)
        options_by_value = {opt.value: opt for opt in wizard._selection_ui._state.options}
        self.assertEqual(options_by_value["edit:LOW"].description, "deepseek-chat")
        self.assertEqual(options_by_value["edit:endpoint"].description, "https://api.deepseek.com")

    def test_openai_menu_does_not_have_shared_endpoint_action(self) -> None:
        wizard = self._build_wizard()
        wizard._selected_preset = next(p for p in PROVIDER_PRESETS if p.preset_id == "openai")
        wizard._draft = wizard._selected_preset.build_draft()
        wizard._open_edit_menu()
        values = [opt.value for opt in wizard._selection_ui._state.options]
        self.assertNotIn("edit:endpoint", values)

    def test_shared_endpoint_updates_all_levels(self) -> None:
        wizard = self._build_wizard()
        wizard._selected_preset = next(p for p in PROVIDER_PRESETS if p.preset_id == "zai_global")
        wizard._draft = wizard._selected_preset.build_draft()
        wizard._on_shared_endpoint_submitted("https://example.com/anthropic")
        for level in ("LOW", "MID", "HIGH"):
            self.assertEqual(wizard._draft[level].base_url, "https://example.com/anthropic")

    def test_collect_api_key_once_per_provider(self) -> None:
        wizard = self._build_wizard()
        wizard._selected_preset = next(p for p in PROVIDER_PRESETS if p.preset_id == "kimi_code")
        wizard._draft = wizard._selected_preset.build_draft()
        with patch.dict("os.environ", {}, clear=True):
            wizard._prepare_key_collection()
        self.assertEqual(wizard._providers_need_key, ["anthropic"])


class TestPreflightRunFlow(unittest.IsolatedAsyncioTestCase):
    async def test_run_preflight_propagates_wizard_cancel_detail(self) -> None:
        class _FakeConsole:
            def __init__(self) -> None:
                self.lines: list[str] = []

            def print(self, text: str) -> None:
                self.lines.append(text)

        check = PreflightCheckResult(
            needs_preflight=True,
            reasons=("Model levels not fully configured: LOW, MID, HIGH",),
            mode="env",
            llm_levels_source=None,
            llm_levels={},
            missing_levels=("LOW", "MID", "HIGH"),
            missing_key_levels=(),
        )
        with (
            patch(
                "comate_cli.terminal_agent.preflight.evaluate_preflight_state",
                return_value=check,
            ),
            patch(
                "comate_cli.terminal_agent.preflight._run_preflight_wizard",
                AsyncMock(
                    return_value=_PreflightWizardFlowResult(
                        levels=None,
                        cancel_detail="provider_cancelled",
                    )
                ),
            ),
        ):
            result = await run_preflight_if_needed(
                console=_FakeConsole(),
                project_root=Path("/tmp/project"),
                interactive=True,
            )

        self.assertEqual(result.status, "cancelled")
        self.assertEqual(result.detail, "provider_cancelled")


if __name__ == "__main__":
    unittest.main(verbosity=2)
