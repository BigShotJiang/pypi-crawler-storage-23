from __future__ import annotations

import unittest
from types import SimpleNamespace

from prompt_toolkit.completion import Completion

from comate_cli.terminal_agent.tui_parts.render_panels import RenderPanelsMixin


class _FakeCompleteState:
    def __init__(
        self,
        completions: list[Completion],
        selected_index: int | None,
    ) -> None:
        self.completions = completions
        self.complete_index = selected_index
        if selected_index is None:
            self.current_completion = None
        elif 0 <= selected_index < len(completions):
            self.current_completion = completions[selected_index]
        else:
            self.current_completion = None


class _FakeStatusBar:
    def get_mode(self) -> str:
        return "act"

    def info_status_text(self) -> str:
        return "model | ~main / 100% context left"

    def git_diff_fragments(self) -> list[tuple[str, str]]:
        return []


class _FakeLoadingState:
    def __init__(self, text: str = "") -> None:
        self.text = text


class _FakeRenderer:
    def __init__(self) -> None:
        self.active_todos = False
        self.running_subagents = False
        self.todo_lines: list[str] = []

    def has_active_todos(self) -> bool:
        return self.active_todos

    def has_running_subagents(self) -> bool:
        return self.running_subagents

    def has_running_tools(self) -> bool:
        return False

    def loading_state(self) -> _FakeLoadingState:
        return _FakeLoadingState("")

    def todo_panel_lines(self, *, max_lines: int) -> list[str]:
        return self.todo_lines[:max_lines]


class _FakeTUI(RenderPanelsMixin):
    def __init__(
        self,
        complete_state: _FakeCompleteState | None,
        *,
        width: int = 80,
    ) -> None:
        self._input_area = SimpleNamespace(
            buffer=SimpleNamespace(complete_state=complete_state)
        )
        self._status_bar = _FakeStatusBar()
        self._app = None
        self._width = width
        self._renderer = _FakeRenderer()
        self._todo_panel_max_lines = 6
        self._loading_frame = 0

    def _terminal_width(self) -> int:
        return self._width


def _join_fragments(fragments: list[tuple[str, str]]) -> str:
    return "".join(text for _, text in fragments)


class TestCompletionStatusPanel(unittest.TestCase):
    def test_slash_completion_renders_name_and_meta(self) -> None:
        completion = Completion(
            text="/help",
            start_position=0,
            display="/help (h)",
            display_meta="Show available slash commands",
        )
        tui = _FakeTUI(_FakeCompleteState([completion], selected_index=0))

        text = _join_fragments(tui._completion_panel_text())

        self.assertIn("/help (h)", text)
        self.assertIn("Show available slash commands", text)

    def test_mention_completion_renders_path_without_meta_separator(self) -> None:
        completion = Completion(
            text="src/main.py ",
            start_position=0,
            display="src/main.py",
        )
        tui = _FakeTUI(_FakeCompleteState([completion], selected_index=0))

        text = _join_fragments(tui._completion_panel_text())

        self.assertIn("src/main.py", text)
        self.assertNotIn("—", text)

    def test_selected_completion_uses_current_style(self) -> None:
        completions = [
            Completion(text="/help", start_position=0, display="/help"),
            Completion(text="/model", start_position=0, display="/model"),
        ]
        tui = _FakeTUI(_FakeCompleteState(completions, selected_index=1))

        fragments = tui._completion_panel_text()

        selected_rows = [
            text
            for style, text in fragments
            if style == "class:completion.status.current"
        ]
        self.assertTrue(any("/model" in row for row in selected_rows))

    def test_overflow_shows_more_indicator_and_caps_height(self) -> None:
        completions = [
            Completion(text=f"/cmd{i}", start_position=0, display=f"/cmd{i}")
            for i in range(12)
        ]
        tui = _FakeTUI(_FakeCompleteState(completions, selected_index=4))

        text = _join_fragments(tui._completion_panel_text())

        self.assertEqual(tui._completion_panel_height(), 8)
        self.assertIn("/cmd4", text)
        self.assertIn("… and 4 more", text)

    def test_overflow_at_bottom_hides_more_indicator(self) -> None:
        completions = [
            Completion(text=f"/cmd{i}", start_position=0, display=f"/cmd{i}")
            for i in range(12)
        ]
        tui = _FakeTUI(_FakeCompleteState(completions, selected_index=11))

        text = _join_fragments(tui._completion_panel_text())

        self.assertNotIn("… and", text)

    def test_long_row_is_truncated(self) -> None:
        completion = Completion(
            text="/very-long-command-name",
            start_position=0,
            display="/very-long-command-name",
            display_meta="meta information is also very long",
        )
        tui = _FakeTUI(
            _FakeCompleteState([completion], selected_index=0),
            width=16,
        )

        text = _join_fragments(tui._completion_panel_text())

        self.assertIn("…", text)

    def test_loading_hide_gate_only_depends_on_todo_panel(self) -> None:
        tui = _FakeTUI(None)
        self.assertFalse(tui._should_hide_loading_panel())

        tui._renderer.active_todos = True
        self.assertTrue(tui._should_hide_loading_panel())
        self.assertEqual(tui._loading_text(), [("", " ")])

        tui._renderer.active_todos = False
        tui._renderer.running_subagents = True
        self.assertFalse(tui._should_hide_loading_panel())

    def test_todo_title_uses_shimmer_fragments(self) -> None:
        tui = _FakeTUI(None, width=80)
        tui._renderer.todo_lines = [
            "📋 Todo (1/3 completed · 1 in_progress · 1 pending)",
            "  ◉ 撰写方案 ⏳",
        ]
        tui._loading_frame = 7

        fragments = tui._todo_text()
        header_styles: set[str] = set()
        header_text_parts: list[str] = []
        for style, text in fragments:
            if text == "\n":
                break
            header_styles.add(style)
            header_text_parts.append(text)

        header_text = "".join(header_text_parts)
        self.assertIn("📋", header_text)
        self.assertGreater(len(header_styles), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
