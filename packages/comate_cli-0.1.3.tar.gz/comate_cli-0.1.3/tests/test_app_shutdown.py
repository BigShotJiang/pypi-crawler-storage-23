from __future__ import annotations

import unittest
from contextlib import contextmanager
from unittest.mock import MagicMock, call, patch

from comate_cli.terminal_agent import app as app_module


class _FakeSession:
    def __init__(self, session_id: str, *, fail: bool = False) -> None:
        self.session_id = session_id
        self._fail = fail
        self.shutdown_calls = 0

    async def shutdown(self) -> None:
        self.shutdown_calls += 1
        if self._fail:
            raise RuntimeError(f"boom-{self.session_id}")


class TestAppShutdown(unittest.IsolatedAsyncioTestCase):
    async def test_graceful_shutdown_deduplicates_sessions_and_flushes(self) -> None:
        events: list[str] = []

        @contextmanager
        def _fake_guard():
            events.append("guard_enter")
            try:
                yield
            finally:
                events.append("guard_exit")

        s1 = _FakeSession("s1")
        s2 = _FakeSession("s2")

        with (
            patch.object(app_module, "_sigint_guard", _fake_guard),
            patch.object(app_module, "_flush_langfuse_if_configured", side_effect=lambda: events.append("flush")),
        ):
            await app_module._graceful_shutdown(s1, s1, s2)  # type: ignore[arg-type]

        self.assertEqual(s1.shutdown_calls, 1)
        self.assertEqual(s2.shutdown_calls, 1)
        self.assertEqual(events, ["guard_enter", "flush", "guard_exit"])

    async def test_graceful_shutdown_continues_after_session_failure(self) -> None:
        s_ok = _FakeSession("ok")
        s_fail = _FakeSession("fail", fail=True)

        flush_mock = MagicMock()
        with patch.object(app_module, "_flush_langfuse_if_configured", flush_mock):
            await app_module._graceful_shutdown(s_fail, s_ok)  # type: ignore[arg-type]

        self.assertEqual(s_fail.shutdown_calls, 1)
        self.assertEqual(s_ok.shutdown_calls, 1)
        flush_mock.assert_called_once()

    def test_sigint_guard_restores_handler(self) -> None:
        current_thread = object()
        previous_handler = object()
        signal_mock = MagicMock()
        signal_mock.SIGINT = 2
        signal_mock.SIG_IGN = 1
        signal_mock.getsignal.return_value = previous_handler

        with (
            patch.object(app_module.os, "name", "posix"),
            patch.object(app_module.threading, "current_thread", return_value=current_thread),
            patch.object(app_module.threading, "main_thread", return_value=current_thread),
            patch.object(app_module, "signal", signal_mock),
        ):
            with app_module._sigint_guard():
                pass

        self.assertEqual(
            signal_mock.signal.call_args_list,
            [
                call(signal_mock.SIGINT, signal_mock.SIG_IGN),
                call(signal_mock.SIGINT, previous_handler),
            ],
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
