from __future__ import annotations

import json
import unittest
from pathlib import Path
from types import SimpleNamespace

from comate_agent_sdk.context.items import ContextItem, ItemType
from comate_agent_sdk.llm.messages import (
    AssistantMessage,
    Function,
    ToolCall,
    ToolMessage,
    UserMessage,
)

from comate_cli.terminal_agent.event_renderer import EventRenderer
from comate_cli.terminal_agent.tui_parts.history_sync import HistorySyncMixin


class _DummyHistorySync(HistorySyncMixin):
    def __init__(self, items: list[ContextItem]) -> None:
        self._session = SimpleNamespace(
            _agent=SimpleNamespace(
                _context=SimpleNamespace(
                    get_conversation_items_snapshot=lambda: list(items)
                )
            )
        )
        self._renderer = EventRenderer(project_root=Path.cwd())
        self._printed_history_index = 0
        self._show_thinking = True

    def _drain_history_sync(self) -> None:
        return


def _task_tool_call(*, tool_call_id: str, description: str, prompt: str) -> ToolCall:
    return ToolCall(
        id=tool_call_id,
        type="function",
        function=Function(
            name="Task",
            arguments=json.dumps(
                {
                    "subagent_type": "Plan",
                    "description": description,
                    "prompt": prompt,
                },
                ensure_ascii=False,
            ),
        ),
    )


class TestHistorySync(unittest.TestCase):
    def test_resume_history_skips_meta_user_messages(self) -> None:
        items = [
            ContextItem(
                item_type=ItemType.USER_MESSAGE,
                message=UserMessage(content="<session-state>hidden</session-state>", is_meta=True),
                content_text="<session-state>hidden</session-state>",
            ),
            ContextItem(
                item_type=ItemType.USER_MESSAGE,
                message=UserMessage(content="visible user input"),
                content_text="visible user input",
            ),
        ]
        sync = _DummyHistorySync(items)

        sync.add_resume_history("resume")

        user_entries = [entry for entry in sync._renderer.history_entries() if entry.entry_type == "user"]
        self.assertEqual(len(user_entries), 1)
        self.assertEqual(user_entries[0].text, "visible user input")

        system_entries = [entry for entry in sync._renderer.history_entries() if entry.entry_type == "system"]
        self.assertTrue(system_entries)
        self.assertIn("history loaded: 1 messages", str(system_entries[-1].text))

    def test_resume_history_task_signature_uses_subagent_and_description(self) -> None:
        task_call = _task_tool_call(
            tool_call_id="tc_plan_ok",
            description="设计 Queue Panel 实现方案",
            prompt="MODE: create\nPLAN_FILE: ~/.agent/plans/terminal-agent-queue-panel.md",
        )
        items = [
            ContextItem(
                item_type=ItemType.ASSISTANT_MESSAGE,
                message=AssistantMessage(content="", tool_calls=[task_call]),
                content_text="",
            ),
            ContextItem(
                item_type=ItemType.TOOL_RESULT,
                message=ToolMessage(
                    tool_call_id="tc_plan_ok",
                    tool_name="Task",
                    content="done",
                    is_error=False,
                ),
                content_text="done",
                tool_name="Task",
            ),
        ]
        sync = _DummyHistorySync(items)

        sync.add_resume_history("resume")

        tool_results = [
            entry for entry in sync._renderer.history_entries() if entry.entry_type == "tool_result"
        ]
        self.assertEqual(len(tool_results), 1)
        text = str(tool_results[0].text)
        self.assertIn("Plan(设计 Queue Panel 实现方案)", text)
        self.assertNotIn("MODE: create", text)
        self.assertNotIn("Task({", text)

    def test_resume_history_task_error_keeps_error_severity(self) -> None:
        task_call = _task_tool_call(
            tool_call_id="tc_plan_err",
            description="设计 Queue Panel 实现方案",
            prompt="MODE: create\nPLAN_FILE: ~/.agent/plans/terminal-agent-queue-panel.md",
        )
        items = [
            ContextItem(
                item_type=ItemType.ASSISTANT_MESSAGE,
                message=AssistantMessage(content="", tool_calls=[task_call]),
                content_text="",
            ),
            ContextItem(
                item_type=ItemType.TOOL_RESULT,
                message=ToolMessage(
                    tool_call_id="tc_plan_err",
                    tool_name="Task",
                    content="Error: something failed",
                    is_error=True,
                ),
                content_text="Error: something failed",
                tool_name="Task",
            ),
        ]
        sync = _DummyHistorySync(items)

        sync.add_resume_history("resume")

        tool_results = [
            entry for entry in sync._renderer.history_entries() if entry.entry_type == "tool_result"
        ]
        self.assertEqual(len(tool_results), 1)
        self.assertEqual(tool_results[0].severity, "error")
        self.assertIn("Plan(设计 Queue Panel 实现方案)", str(tool_results[0].text))


if __name__ == "__main__":
    unittest.main(verbosity=2)
