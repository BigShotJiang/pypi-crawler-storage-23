from __future__ import annotations

import unittest

from comate_cli.terminal_agent.selection_menu import SelectionMenuUI


def _build_options(count: int) -> list[dict[str, str]]:
    return [
        {
            "value": f"v-{idx:02d}",
            "label": f"label-{idx:02d}",
            "description": "",
        }
        for idx in range(count)
    ]


class TestSelectionMenu(unittest.TestCase):
    def test_options_window_hides_cursor(self) -> None:
        ui = SelectionMenuUI()
        self.assertTrue(ui._options_window.always_hide_cursor())

    def test_move_selection_wraps_by_default(self) -> None:
        ui = SelectionMenuUI()
        ok = ui.set_options(title="menu", options=_build_options(3))
        self.assertTrue(ok)

        ui.move_selection(-1)
        self.assertEqual(ui._state.selected_index, 2)

    def test_windowed_selection_keeps_viewport_in_sync(self) -> None:
        ui = SelectionMenuUI()
        ok = ui.set_options(
            title="menu",
            options=_build_options(20),
            page_size=15,
            wrap_navigation=False,
        )
        self.assertTrue(ok)

        ui.move_selection(15)
        self.assertEqual(ui._state.selected_index, 15)
        self.assertEqual(ui._state.viewport_start, 1)

        fragments_text = "".join(text for _style, text in ui._options_fragments())
        self.assertNotIn("label-00", fragments_text)
        self.assertIn("label-01", fragments_text)
        self.assertIn("label-15", fragments_text)
        self.assertIn("Showing 2-16/20", fragments_text)

    def test_non_wrap_mode_clamps_at_bottom(self) -> None:
        ui = SelectionMenuUI()
        ok = ui.set_options(
            title="menu",
            options=_build_options(4),
            wrap_navigation=False,
        )
        self.assertTrue(ok)

        ui.move_selection(10)
        self.assertEqual(ui._state.selected_index, 3)
        ui.move_selection(1)
        self.assertEqual(ui._state.selected_index, 3)

    def test_description_selected_only_renders_only_active_row_description(self) -> None:
        ui = SelectionMenuUI()
        options = _build_options(3)
        options[0]["description"] = "desc-0"
        options[1]["description"] = "desc-1"
        options[2]["description"] = "desc-2"
        ok = ui.set_options(
            title="menu",
            options=options,
            description_selected_only=True,
        )
        self.assertTrue(ok)

        fragments_text = "".join(text for _style, text in ui._options_fragments())
        self.assertIn("desc-0", fragments_text)
        self.assertNotIn("desc-1", fragments_text)
        self.assertNotIn("desc-2", fragments_text)

        ui.move_selection(1)
        fragments_text = "".join(text for _style, text in ui._options_fragments())
        self.assertNotIn("desc-0", fragments_text)
        self.assertIn("desc-1", fragments_text)

    def test_item_gap_lines_adds_blank_line_between_items(self) -> None:
        ui = SelectionMenuUI()
        ok = ui.set_options(
            title="menu",
            options=_build_options(3),
            item_gap_lines=1,
        )
        self.assertTrue(ok)
        fragments_text = "".join(text for _style, text in ui._options_fragments())
        self.assertIn("label-00\n\n", fragments_text)
        self.assertIn("label-01\n\n", fragments_text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
