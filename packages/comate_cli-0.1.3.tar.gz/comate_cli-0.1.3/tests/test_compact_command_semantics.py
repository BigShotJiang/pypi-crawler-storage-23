from __future__ import annotations

import asyncio
import unittest

from comate_agent_sdk.agent.compaction.models import ManualCompactionResult
from comate_cli.terminal_agent.tui_parts.commands import CommandsMixin


class _DummyRenderer:
    def __init__(self) -> None:
        self.messages: list[tuple[str, str]] = []

    def append_system_message(self, content: str, *, severity: str = "info") -> None:
        self.messages.append((content, severity))


class _DummyStatusBar:
    def __init__(self) -> None:
        self.refresh_calls = 0

    async def refresh(self) -> None:
        self.refresh_calls += 1


class _DummySession:
    def __init__(self, result: ManualCompactionResult) -> None:
        self._result = result

    async def compact_context_manual(self) -> ManualCompactionResult:
        return self._result


class _DummyCommands(CommandsMixin):
    def __init__(self, result: ManualCompactionResult) -> None:
        self._renderer = _DummyRenderer()
        self._status_bar = _DummyStatusBar()
        self._session = _DummySession(result)
        self._busy = False
        self._is_compacting = False
        self._compact_task = None
        self._compact_cancel_requested = False
        self._pending_exit_after_compact_cancel = False
        self._exit_calls = 0
        self._refresh_calls = 0

    def _set_busy(self, value: bool) -> None:
        self._busy = value

    def _refresh_layers(self) -> None:
        self._refresh_calls += 1

    def _exit_app(self) -> None:
        self._exit_calls += 1


class TestCompactCommandSemantics(unittest.TestCase):
    def test_compact_refreshes_status_bar_after_success(self) -> None:
        commands = _DummyCommands(
            ManualCompactionResult(
                attempted=True,
                compacted=True,
                tokens_before=1000,
                tokens_after=120,
                reason="success",
            )
        )

        asyncio.run(commands._slash_compact(""))

        self.assertEqual(commands._status_bar.refresh_calls, 1)
        self.assertTrue(any("/compact 完成:" in msg for msg, _ in commands._renderer.messages))
        self.assertEqual(commands._exit_calls, 0)

    def test_compact_rejects_args(self) -> None:
        commands = _DummyCommands(
            ManualCompactionResult(
                attempted=False,
                compacted=False,
                reason="unused",
            )
        )

        asyncio.run(commands._slash_compact("--bad"))

        self.assertEqual(commands._status_bar.refresh_calls, 0)
        self.assertEqual(commands._renderer.messages[-1][0], "Usage: /compact")
        self.assertEqual(commands._renderer.messages[-1][1], "error")


if __name__ == "__main__":
    unittest.main()
