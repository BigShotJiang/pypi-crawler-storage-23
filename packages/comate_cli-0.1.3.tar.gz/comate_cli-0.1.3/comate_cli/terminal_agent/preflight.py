from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal, Mapping

from prompt_toolkit.application import Application
from prompt_toolkit.filters import Condition
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import HSplit, Layout, Window
from prompt_toolkit.layout.containers import ConditionalContainer, DynamicContainer
from prompt_toolkit.layout.controls import FormattedTextControl
from prompt_toolkit.patch_stdout import patch_stdout
from prompt_toolkit.styles import Style as PTStyle
from prompt_toolkit.widgets import Frame, TextArea
from rich.console import Console

from comate_agent_sdk.agent.llm_levels import ALL_LEVELS
from comate_agent_sdk.agent.settings import (
    LOCAL_SETTINGS_FILENAME,
    USER_SETTINGS_PATH,
    load_settings_file,
    read_settings_json_object,
    write_settings_json_atomic,
)

from comate_cli.terminal_agent.selection_menu import SelectionMenuUI

logger = logging.getLogger(__name__)

_PROVIDER_ENV_VARS: dict[str, str] = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "google": "GOOGLE_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "minimax": "MINIMAX_API_KEY",
}

_LEVEL_LABEL_WIDTH = 6
_FIELD_LABEL_WIDTH = 9
_VALUE_MAX_WIDTH = 96
_SHARED_ENDPOINT_PRESET_IDS: set[str] = {
    "deepseek",
    "minimax",
    "kimi_code",
    "zai_cn",
    "zai_global",
    "openai",
    "anthropic",
}
_PROVIDER_MENU_PRIORITY: dict[str, int] = {
    "openai": 1,
    "anthropic": 0,
}

_LEVEL_DESCRIPTIONS: dict[str, str] = {
    "HIGH": "Most capable for complex work",
    "MID": "Best for everyday tasks (default)",
    "LOW": "Fastest for quick answers",
}

_WIZARD_STYLE = PTStyle.from_dict({
    # Base
    "": "bg:#1f232a #dde3ed",
    # Selection menu（与 tui.py 保持一致的 class 名称）
    "selection.title":                "#bfdbfe bold",
    "selection.divider":              "fg:#334155",
    "selection.body":                 "bg:#1a1e28 #d8dee9",
    "selection.option":               "fg:#cbd5e1",
    "selection.option.selected":      "#f0f9ff bold",
    "selection.description":          "fg:#6b7280",
    "selection.description.selected": "fg:#7dd3fc",
    "selection.hint":                 "fg:#475569",
    # Frame widget（输入框卡片边框）
    "frame.border":                   "#334155",
    "frame.label":                    "#bfdbfe bold",
    # 输入框底部提示
    "preflight.hint":                 "bg:#1a1e28 #475569",
})


@dataclass(frozen=True, slots=True)
class LevelConfigDraft:
    provider: str
    model: str
    base_url: str | None = None
    api_key: str | None = None


@dataclass(frozen=True, slots=True)
class ProviderPreset:
    preset_id: str
    label: str
    description: str
    provider: str
    base_url: str | None
    models: Mapping[str, str]

    def build_draft(self) -> dict[str, LevelConfigDraft]:
        return {
            level: LevelConfigDraft(
                provider=self.provider,
                model=str(self.models[level]).strip(),
                base_url=self.base_url,
            )
            for level in ALL_LEVELS
        }


@dataclass(frozen=True, slots=True)
class PreflightCheckResult:
    needs_preflight: bool
    reasons: tuple[str, ...]
    mode: Literal["settings", "env"]
    llm_levels_source: str | None
    llm_levels: Mapping[str, str]
    missing_levels: tuple[str, ...]
    missing_key_levels: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class PreflightResult:
    status: Literal[
        "skipped",
        "configured",
        "cancelled",
        "blocked_non_interactive",
        "failed",
    ]
    detail: str | None = None

    @property
    def should_abort_launch(self) -> bool:
        return self.status in {"cancelled", "blocked_non_interactive", "failed"}


PROVIDER_PRESETS: tuple[ProviderPreset, ...] = (
    ProviderPreset(
        preset_id="deepseek",
        label="DeepSeek",
        description="Balanced defaults for cost and reasoning.",
        provider="deepseek",
        base_url="https://api.deepseek.com",
        models={
            "LOW": "deepseek-chat",
            "MID": "deepseek-chat",
            "HIGH": "deepseek-reasoner",
        },
    ),
    ProviderPreset(
        preset_id="minimax",
        label="MiniMax Coding Plan",
        description="One model across all levels for quick setup.",
        provider="minimax",
        base_url="https://api.minimaxi.com/anthropic",
        models={
            "LOW": "MiniMax-M2.5",
            "MID": "MiniMax-M2.5",
            "HIGH": "MiniMax-M2.5",
        },
    ),
    ProviderPreset(
        preset_id="kimi_code",
        label="Kimi Code Plan",
        description="Coding-focused preset with Kimi defaults.",
        provider="anthropic",
        base_url="https://api.kimi.com/coding",
        models={
            "LOW": "kimi-for-coding",
            "MID": "kimi-for-coding",
            "HIGH": "kimi-for-coding",
        },
    ),
    ProviderPreset(
        preset_id="zai_cn",
        label="Glm-coding Plan",
        description="z.ai China mainland endpoint preset.",
        provider="anthropic",
        base_url="https://open.bigmodel.cn/api/anthropic",
        models={
            "LOW": "glm-4.7",
            "MID": "glm-4.7",
            "HIGH": "glm-5",
        },
    ),
    ProviderPreset(
        preset_id="zai_global",
        label="Z.ai (Global)",
        description="Global endpoint preset.",
        provider="anthropic",
        base_url="https://api.z.ai/api/anthropic",
        models={
            "LOW": "glm-4.7",
            "MID": "glm-4.7",
            "HIGH": "glm-5",
        },
    ),
    ProviderPreset(
        preset_id="openai",
        label="OpenAI and compatible",
        description="Official OpenAI endpoint with editable model and endpoint.",
        provider="openai",
        base_url="https://api.openai.com/v1",
        models={
            "LOW": "gpt-5-mini",
            "MID": "gpt-5.2",
            "HIGH": "gpt-5.2",
        },
    ),
    ProviderPreset(
        preset_id="anthropic",
        label="Anthropic and compatible",
        description="Official Anthropic endpoint with editable model and endpoint.",
        provider="anthropic",
        base_url="https://api.anthropic.com",
        models={
            "LOW": "claude-haiku-4-5",
            "MID": "claude-sonnet-4-6",
            "HIGH": "claude-opus-4-6",
        },
    ),
)


def evaluate_preflight_state(
    *,
    project_root: Path,
    env: Mapping[str, str] | None = None,
    user_settings_path: Path | None = None,
) -> PreflightCheckResult:
    env_map: Mapping[str, str] = env if env is not None else os.environ
    user_path = user_settings_path or USER_SETTINGS_PATH
    project_path = project_root / ".agent" / "settings.json"
    local_path = project_root / ".agent" / LOCAL_SETTINGS_FILENAME

    user_cfg = load_settings_file(user_path)
    project_cfg = load_settings_file(project_path)
    local_cfg = load_settings_file(local_path)

    llm_levels_raw, llm_levels_source = _resolve_effective_field(
        ("user", user_cfg),
        ("project", project_cfg),
        ("local", local_cfg),
        field_name="llm_levels",
    )
    llm_level_keys, _ = _resolve_effective_field(
        ("user", user_cfg),
        ("project", project_cfg),
        ("local", local_cfg),
        field_name="llm_levels_api_key",
    )

    normalized_levels: dict[str, str] = {}
    missing_levels: list[str] = []
    invalid_levels: list[str] = []
    parsed_provider_by_level: dict[str, str] = {}

    llm_levels = llm_levels_raw if llm_levels_raw else None
    if llm_levels is not None:
        mode: Literal["settings", "env"] = "settings"
        for level in ALL_LEVELS:
            raw = str(llm_levels.get(level, "")).strip()
            if not raw:
                missing_levels.append(level)
                continue
            normalized_levels[level] = raw
            provider = _try_parse_provider(raw)
            if provider is None:
                invalid_levels.append(level)
            else:
                parsed_provider_by_level[level] = provider
    else:
        mode = "env"
        for level in ALL_LEVELS:
            env_key = f"COMATE_AGENT_SDK_LLM_{level}"
            raw = str(env_map.get(env_key, "")).strip()
            if not raw:
                missing_levels.append(level)
                continue
            normalized_levels[level] = raw
            provider = _try_parse_provider(raw)
            if provider is None:
                invalid_levels.append(level)
            else:
                parsed_provider_by_level[level] = provider

    missing_key_levels: list[str] = []
    key_levels = llm_level_keys or {}
    for level in ALL_LEVELS:
        provider = parsed_provider_by_level.get(level)
        if provider is None:
            continue
        env_name = _PROVIDER_ENV_VARS.get(provider, "")
        has_env_key = bool(env_name and str(env_map.get(env_name, "")).strip())
        has_settings_key = bool(mode == "settings" and str(key_levels.get(level, "")).strip())
        if not has_env_key and not has_settings_key:
            missing_key_levels.append(level)

    reasons: list[str] = []
    if missing_levels:
        reasons.append(f"Model levels not fully configured: {', '.join(missing_levels)}")
    if invalid_levels:
        reasons.append(f"Invalid model format in levels: {', '.join(invalid_levels)} (expected provider:model)")
    if missing_key_levels:
        reasons.append(f"API key missing for: {', '.join(missing_key_levels)}")

    return PreflightCheckResult(
        needs_preflight=bool(reasons),
        reasons=tuple(reasons),
        mode=mode,
        llm_levels_source=llm_levels_source,
        llm_levels=normalized_levels,
        missing_levels=tuple(missing_levels),
        missing_key_levels=tuple(missing_key_levels),
    )


async def run_preflight_if_needed(
    *,
    console: Console,
    project_root: Path,
    interactive: bool,
) -> PreflightResult:
    check = evaluate_preflight_state(project_root=project_root)
    if not check.needs_preflight:
        return PreflightResult(status="skipped")

    if not interactive:
        _print_preflight_block_message(console=console, check=check)
        return PreflightResult(status="blocked_non_interactive", detail="missing_llm_config")

    flow = await _run_preflight_wizard(check=check, project_root=project_root)
    if flow.cancel_detail is not None:
        console.print("[yellow]Setup cancelled. Session was not started.[/]")
        return PreflightResult(status="cancelled", detail=flow.cancel_detail)
    draft_with_keys = flow.levels
    if draft_with_keys is None:
        console.print("[yellow]Setup cancelled. Session was not started.[/]")
        return PreflightResult(status="cancelled", detail="unknown_cancelled")

    settings_path = USER_SETTINGS_PATH.expanduser()
    try:
        merged = merge_user_settings(
            existing=_load_user_settings_json(settings_path),
            levels=draft_with_keys,
        )
        write_user_settings_atomic(path=settings_path, data=merged)
    except Exception as exc:
        logger.exception("Failed to save pre-flight settings")
        console.print(f"[red]Failed to save provider settings: {exc}[/]")
        return PreflightResult(status="failed", detail="write_failed")

    recheck = evaluate_preflight_state(project_root=project_root)
    if recheck.needs_preflight:
        console.print(
            "[red]Settings were saved to user scope, but effective configuration is still incomplete. "
            "Please check project/local overrides.[/]"
        )
        return PreflightResult(status="failed", detail="still_missing_after_write")

    console.print(f"[green]Provider settings saved: {settings_path}[/]")
    return PreflightResult(status="configured")


def merge_user_settings(
    *,
    existing: Mapping[str, Any],
    levels: Mapping[str, LevelConfigDraft],
) -> dict[str, Any]:
    merged: dict[str, Any] = dict(existing)

    llm_levels = dict(merged.get("llm_levels") if isinstance(merged.get("llm_levels"), dict) else {})
    llm_levels_base_url = dict(
        merged.get("llm_levels_base_url") if isinstance(merged.get("llm_levels_base_url"), dict) else {}
    )
    llm_levels_api_key = dict(
        merged.get("llm_levels_api_key") if isinstance(merged.get("llm_levels_api_key"), dict) else {}
    )

    for level in ALL_LEVELS:
        draft = levels[level]
        llm_levels[level] = f"{draft.provider}:{draft.model}"
        if draft.base_url:
            llm_levels_base_url[level] = draft.base_url
        else:
            llm_levels_base_url.pop(level, None)
        if draft.api_key:
            llm_levels_api_key[level] = draft.api_key
        else:
            llm_levels_api_key.pop(level, None)

    merged["llm_levels"] = llm_levels
    if llm_levels_base_url:
        merged["llm_levels_base_url"] = llm_levels_base_url
    else:
        merged.pop("llm_levels_base_url", None)

    if llm_levels_api_key:
        merged["llm_levels_api_key"] = llm_levels_api_key
    else:
        merged.pop("llm_levels_api_key", None)

    return merged


def write_user_settings_atomic(*, path: Path, data: Mapping[str, Any]) -> None:
    write_settings_json_atomic(path=path, data=data)


def _load_user_settings_json(path: Path) -> dict[str, Any]:
    return read_settings_json_object(path)


def _resolve_effective_field(
    user_pair: tuple[str, Any],
    project_pair: tuple[str, Any],
    local_pair: tuple[str, Any],
    *,
    field_name: str,
) -> tuple[dict[str, Any] | None, str | None]:
    for source, cfg in (local_pair, project_pair, user_pair):
        if cfg is None:
            continue
        value = getattr(cfg, field_name, None)
        if isinstance(value, dict):
            return value, source
    return None, None


def _try_parse_provider(raw: str) -> str | None:
    value = raw.strip()
    if ":" not in value:
        return None
    provider, model = value.split(":", 1)
    provider = provider.strip().lower()
    model = model.strip()
    if not provider or not model:
        return None
    return provider


def _truncate_value(value: str, max_width: int = _VALUE_MAX_WIDTH) -> str:
    text = value.strip()
    if len(text) <= max_width:
        return text
    if max_width <= 3:
        return text[:max_width]
    return f"{text[:max_width - 3]}..."


def _format_level_summary(*, level: str, entry: LevelConfigDraft) -> str:
    model_value = _truncate_value(f"{entry.provider}:{entry.model}")
    endpoint_value = _truncate_value(entry.base_url or "(default)")
    level_cell = f"{level:<{_LEVEL_LABEL_WIDTH}}"
    model_label = f"{'Model':<{_FIELD_LABEL_WIDTH}}"
    endpoint_label = f"{'Endpoint':<{_FIELD_LABEL_WIDTH}}"
    return (
        f"{level_cell}{model_label}{model_value}\n"
        f"{'':<{_LEVEL_LABEL_WIDTH}}{endpoint_label}{endpoint_value}"
    )


def _format_missing_reasons(reasons: tuple[str, ...], *, bullet_indent: str = "  ") -> str:
    if not reasons:
        return "What's missing:\n  - Unknown issue"
    lines = ["What's missing:"]
    lines.extend(f"{bullet_indent}- {reason}" for reason in reasons)
    return "\n".join(lines)


def _print_preflight_block_message(*, console: Console, check: PreflightCheckResult) -> None:
    reason_lines = _format_missing_reasons(check.reasons)
    console.print("[red]Provider setup required[/]")
    console.print("[dim]You need to configure an API provider before you can continue.[/]")
    console.print(f"[dim]{reason_lines}[/]")
    console.print("[dim]Run `comate` in interactive mode to complete provider setup.[/]")


def _build_preflight_entry_options() -> list[dict[str, str]]:
    return [
        {
            "value": "continue",
            "label": "Start setup now",
            "description": "",
        },
        {
            "value": "cancel",
            "label": "Exit",
            "description": "",
        },
    ]


@dataclass(frozen=True, slots=True)
class _PreflightWizardFlowResult:
    levels: dict[str, LevelConfigDraft] | None
    cancel_detail: str | None


class _PreflightWizard:
    def __init__(self, *, check: PreflightCheckResult, project_root: Path) -> None:
        self._check = check
        self._project_root = project_root
        self._app: Application | None = None

        self._mode: Literal["selection", "input"] = "selection"
        self._selection_ui = SelectionMenuUI()
        self._selection_submit_handler: Callable[[str], None] | None = None
        self._selection_cancel_detail: str | None = None
        self._active_input_area: TextArea | None = None
        self._active_input_allow_empty = False
        self._input_submit_handler: Callable[[str], None] | None = None
        self._input_cancel_detail: str | None = None
        self._input_container_current = Window(height=1, char=" ")

        self._selected_preset: ProviderPreset | None = None
        self._draft: dict[str, LevelConfigDraft] = {}
        self._editing_level: str | None = None
        self._editing_model: str | None = None
        self._provider_to_key: dict[str, str | None] = {}
        self._providers_need_key: list[str] = []
        self._next_key_index = 0

        self._back_fn: Callable[[], None] | None = None

        self._resolved_levels: dict[str, LevelConfigDraft] | None = None
        self._cancel_detail: str | None = None
        self._build_application()

    def _build_application(self) -> None:
        selection_panel = ConditionalContainer(
            content=self._selection_ui.container,
            filter=Condition(lambda: self._mode == "selection"),
        )
        input_panel = ConditionalContainer(
            content=DynamicContainer(lambda: self._input_container_current),
            filter=Condition(lambda: self._mode == "input"),
        )
        root = HSplit([selection_panel, input_panel])
        kb = self._build_key_bindings()
        self._app = Application(
            layout=Layout(container=root, focused_element=self._selection_ui.focus_target()),
            key_bindings=kb,
            style=_WIZARD_STYLE,
            full_screen=True,
            erase_when_done=True,
            mouse_support=False,
        )

    def _build_key_bindings(self) -> KeyBindings:
        kb = KeyBindings()

        @kb.add("up")
        @kb.add("k")
        def _on_up(event) -> None:
            del event
            if self._mode != "selection":
                return
            self._selection_ui.move_selection(-1)
            self._selection_ui.refresh()
            self._invalidate()

        @kb.add("down")
        @kb.add("j")
        def _on_down(event) -> None:
            del event
            if self._mode != "selection":
                return
            self._selection_ui.move_selection(1)
            self._selection_ui.refresh()
            self._invalidate()

        @kb.add("enter")
        def _on_enter(event) -> None:
            del event
            if self._mode == "selection":
                selected = self._selection_ui.get_selected()
                if selected is None:
                    return
                if self._selection_submit_handler is None:
                    return
                self._selection_submit_handler(selected.value)
                return
            if self._active_input_area is None:
                return
            text = self._active_input_area.text
            if not self._active_input_allow_empty and not text.strip():
                return
            if self._input_submit_handler is None:
                return
            self._input_submit_handler(text)

        @kb.add("escape")
        def _on_escape(event) -> None:
            del event
            if self._back_fn is not None:
                self._back_fn()
                return
            if self._mode == "selection":
                self._cancel_with_detail(self._selection_cancel_detail)
                return
            self._cancel_with_detail(self._input_cancel_detail)

        @kb.add("c-c")
        def _on_ctrl_c(event) -> None:
            del event
            if self._mode == "selection":
                self._cancel_with_detail(self._selection_cancel_detail)
                return
            self._cancel_with_detail(self._input_cancel_detail)

        return kb

    async def run(self) -> _PreflightWizardFlowResult:
        self._open_entry_menu()
        if self._app is None:
            return _PreflightWizardFlowResult(levels=None, cancel_detail="entry_cancelled")
        with patch_stdout(raw=True):
            await self._app.run_async()
        return _PreflightWizardFlowResult(levels=self._resolved_levels, cancel_detail=self._cancel_detail)

    def _invalidate(self) -> None:
        if self._app is None:
            return
        self._app.invalidate()

    def _focus_selection(self) -> None:
        if self._app is None:
            return
        self._app.layout.focus(self._selection_ui.focus_target())

    def _focus_input(self) -> None:
        if self._app is None or self._active_input_area is None:
            return
        self._app.layout.focus(self._active_input_area.window)

    def _show_selection(
        self,
        *,
        title: str,
        options: list[dict[str, str]],
        page_size: int,
        item_gap_lines: int,
        description_selected_only: bool,
        line_wrap: bool,
        on_submit: Callable[[str], None],
        cancel_detail: str,
        initial_value: str | None = None,
    ) -> None:
        ok = self._selection_ui.set_options(
            title=title,
            options=options,
            page_size=page_size,
            item_gap_lines=item_gap_lines,
            wrap_navigation=False,
            description_selected_only=description_selected_only,
            line_wrap=line_wrap,
        )
        if not ok:
            self._cancel_with_detail(cancel_detail)
            return
        if initial_value is not None:
            for idx, item in enumerate(options):
                if str(item.get("value")) != initial_value:
                    continue
                for _ in range(idx):
                    self._selection_ui.move_selection(1)
                break
        self._selection_ui.refresh()
        self._selection_submit_handler = on_submit
        self._selection_cancel_detail = cancel_detail
        self._mode = "selection"
        self._focus_selection()
        self._invalidate()

    def _show_input(
        self,
        *,
        title: str,
        label: str,
        initial_value: str,
        secret: bool,
        allow_empty: bool,
        on_submit: Callable[[str], None],
        cancel_detail: str,
    ) -> None:
        input_area = TextArea(
            text=initial_value,
            multiline=False,
            password=secret,
            prompt=f"  {label} › ",
            wrap_lines=False,
        )
        hint = Window(
            content=FormattedTextControl(
                text=[("class:preflight.hint", "  Enter  Confirm    Esc / Ctrl-C  Cancel")]
            ),
            height=1,
            dont_extend_height=True,
            style="class:preflight.hint",
        )
        self._input_container_current = HSplit([
            Frame(body=input_area, title=title),
            hint,
        ])
        self._active_input_area = input_area
        self._active_input_allow_empty = allow_empty
        self._input_submit_handler = on_submit
        self._input_cancel_detail = cancel_detail
        self._mode = "input"
        self._focus_input()
        self._invalidate()

    def _open_entry_menu(self) -> None:
        self._back_fn = None
        self._show_selection(
            title=f"Provider setup required ({self._project_root})",
            options=_build_preflight_entry_options(),
            page_size=5,
            item_gap_lines=0,
            description_selected_only=False,
            line_wrap=True,
            on_submit=self._on_entry_selected,
            cancel_detail="entry_cancelled",
        )

    def _on_entry_selected(self, value: str) -> None:
        if value == "continue":
            self._open_provider_menu()
            return
        self._cancel_with_detail("entry_cancelled")

    def _open_provider_menu(self) -> None:
        self._back_fn = self._open_entry_menu
        ranked_presets = sorted(
            enumerate(PROVIDER_PRESETS),
            key=lambda pair: (_PROVIDER_MENU_PRIORITY.get(pair[1].preset_id, 100), pair[0]),
        )
        options = [
            {
                "value": preset.preset_id,
                "label": preset.label,
                "description": "",
            }
            for _, preset in ranked_presets
        ]
        self._show_selection(
            title="Choose your API provider",
            options=options,
            page_size=10,
            item_gap_lines=1,
            description_selected_only=False,
            line_wrap=True,
            on_submit=self._on_provider_selected,
            cancel_detail="provider_cancelled",
        )

    def _on_provider_selected(self, value: str) -> None:
        selected = next((preset for preset in PROVIDER_PRESETS if preset.preset_id == value), None)
        if selected is None:
            self._cancel_with_detail("provider_cancelled")
            return
        self._selected_preset = selected
        self._draft = selected.build_draft()
        self._open_edit_menu()

    def _uses_shared_endpoint(self) -> bool:
        if self._selected_preset is None:
            return False
        return self._selected_preset.preset_id in _SHARED_ENDPOINT_PRESET_IDS

    def _shared_endpoint_value(self) -> str:
        for level in ALL_LEVELS:
            entry = self._draft.get(level)
            if entry is None:
                continue
            return entry.base_url or ""
        return ""

    def _apply_shared_endpoint(self, endpoint: str | None) -> None:
        normalized = endpoint.strip() if endpoint is not None else ""
        resolved = normalized or None
        for level in ALL_LEVELS:
            current = self._draft[level]
            self._draft[level] = LevelConfigDraft(
                provider=current.provider,
                model=current.model,
                base_url=resolved,
                api_key=current.api_key,
            )

    def _open_edit_menu(self) -> None:
        if self._selected_preset is None:
            self._cancel_with_detail("level_cancelled")
            return
        self._back_fn = self._open_provider_menu
        options: list[dict[str, str]] = [
            {"value": "done", "label": "Continue", "description": "Proceed to API key setup"},
        ]
        use_shared_endpoint = self._uses_shared_endpoint()
        for level in ALL_LEVELS:
            entry = self._draft[level]
            model_value = _truncate_value(entry.model)
            level_desc = _LEVEL_DESCRIPTIONS.get(level, "")
            description = f"{level_desc} · {model_value}" if level_desc else model_value
            options.append(
                {
                    "value": f"edit:{level}",
                    "label": f"Edit {level}",
                    "description": description,
                }
            )
        if use_shared_endpoint:
            endpoint_value = _truncate_value(self._shared_endpoint_value())
            options.append(
                {
                    "value": "edit:endpoint",
                    "label": "Edit endpoint (all levels)",
                    "description": endpoint_value,
                }
            )
        options.append(
            {
                "value": "cancel",
                "label": "Cancel setup",
                "description": "",
            }
        )
        self._show_selection(
            title=f"Review model levels (Provider: {self._selected_preset.label})",
            options=options,
            page_size=8,
            item_gap_lines=0,
            description_selected_only=False,
            line_wrap=True,
            on_submit=self._on_edit_action_selected,
            cancel_detail="level_cancelled",
        )

    def _on_edit_action_selected(self, value: str) -> None:
        if value == "done":
            self._prepare_key_collection()
            return
        if value == "cancel":
            self._cancel_with_detail("level_cancelled")
            return
        if value == "edit:endpoint":
            self._back_fn = self._open_edit_menu
            self._show_input(
                title="API endpoint (all levels, optional)",
                label="endpoint",
                initial_value=self._shared_endpoint_value(),
                secret=False,
                allow_empty=True,
                on_submit=self._on_shared_endpoint_submitted,
                cancel_detail="level_cancelled",
            )
            return
        if not value.startswith("edit:"):
            self._cancel_with_detail("level_cancelled")
            return
        _, level = value.split(":", 1)
        current = self._draft.get(level)
        if current is None:
            self._cancel_with_detail("level_cancelled")
            return
        self._editing_level = level
        self._back_fn = self._open_edit_menu
        self._show_input(
            title=f"{level}: Model name",
            label="model",
            initial_value=current.model,
            secret=False,
            allow_empty=False,
            on_submit=lambda text, _level=level: self._on_edit_model_submitted(_level, text),
            cancel_detail="level_cancelled",
        )

    def _on_edit_model_submitted(self, level: str, model: str) -> None:
        self._editing_level = level
        self._editing_model = model.strip()
        if self._uses_shared_endpoint():
            current = self._draft[level]
            self._draft[level] = LevelConfigDraft(
                provider=current.provider,
                model=self._editing_model,
                base_url=current.base_url,
                api_key=current.api_key,
            )
            self._editing_level = None
            self._editing_model = None
            self._open_edit_menu()
            return
        current = self._draft[level]
        self._back_fn = self._open_edit_menu
        self._show_input(
            title=f"{level}: API endpoint (optional)",
            label="endpoint",
            initial_value=current.base_url or "",
            secret=False,
            allow_empty=True,
            on_submit=lambda text, _level=level: self._on_edit_endpoint_submitted(_level, text),
            cancel_detail="level_cancelled",
        )

    def _on_edit_endpoint_submitted(self, level: str, endpoint: str) -> None:
        current = self._draft[level]
        model = current.model
        if self._editing_level == level and self._editing_model is not None:
            model = self._editing_model
        self._draft[level] = LevelConfigDraft(
            provider=current.provider,
            model=model.strip(),
            base_url=endpoint.strip() or None,
            api_key=current.api_key,
        )
        self._editing_level = None
        self._editing_model = None
        self._open_edit_menu()

    def _on_shared_endpoint_submitted(self, endpoint: str) -> None:
        self._apply_shared_endpoint(endpoint)
        self._open_edit_menu()

    def _prepare_key_collection(self) -> None:
        self._provider_to_key = {}
        self._providers_need_key = []
        self._next_key_index = 0
        seen_providers: set[str] = set()
        for level in ALL_LEVELS:
            entry = self._draft[level]
            provider = entry.provider
            if provider in seen_providers:
                continue
            seen_providers.add(provider)
            env_name = _PROVIDER_ENV_VARS.get(provider)
            if env_name and str(os.environ.get(env_name, "")).strip():
                self._provider_to_key[provider] = None
                continue
            self._providers_need_key.append(provider)
        self._open_next_key_input()

    def _open_next_key_input(self) -> None:
        if self._next_key_index >= len(self._providers_need_key):
            self._resolved_levels = self._build_levels_with_keys()
            self._open_confirm_menu()
            return
        provider = self._providers_need_key[self._next_key_index]
        self._back_fn = self._open_edit_menu
        self._show_input(
            title=f"Enter API key for {provider.title()}",
            label="api_key",
            initial_value="",
            secret=True,
            allow_empty=False,
            on_submit=lambda text, _provider=provider: self._on_api_key_submitted(_provider, text),
            cancel_detail="key_cancelled",
        )

    def _on_api_key_submitted(self, provider: str, key: str) -> None:
        self._provider_to_key[provider] = key.strip()
        self._next_key_index += 1
        self._open_next_key_input()

    def _build_levels_with_keys(self) -> dict[str, LevelConfigDraft]:
        resolved: dict[str, LevelConfigDraft] = {}
        for level in ALL_LEVELS:
            entry = self._draft[level]
            resolved[level] = LevelConfigDraft(
                provider=entry.provider,
                model=entry.model,
                base_url=entry.base_url,
                api_key=self._provider_to_key.get(entry.provider),
            )
        return resolved

    def _open_confirm_menu(self) -> None:
        self._back_fn = self._open_edit_menu
        if self._resolved_levels is None:
            self._resolved_levels = self._build_levels_with_keys()
        preview = build_preview_payload(self._resolved_levels)
        masked_preview = json.dumps(preview, ensure_ascii=False, indent=2, sort_keys=True)
        options = [
            {
                "value": "save",
                "label": "Save and continue",
                "description": masked_preview,
            },
            {
                "value": "cancel",
                "label": "Cancel",
                "description": "",
            },
        ]
        self._show_selection(
            title="Confirm settings update (~/.agent/settings.json)",
            options=options,
            page_size=6,
            item_gap_lines=0,
            description_selected_only=False,
            line_wrap=True,
            on_submit=self._on_confirm_selected,
            cancel_detail="confirm_cancelled",
        )

    def _on_confirm_selected(self, value: str) -> None:
        if value == "save":
            self._finish_success()
            return
        self._cancel_with_detail("confirm_cancelled")

    def _finish_success(self) -> None:
        if self._resolved_levels is None:
            self._resolved_levels = self._build_levels_with_keys()
        self._cancel_detail = None
        if self._app is not None:
            self._app.exit(result="save")

    def _cancel_with_detail(self, detail: str | None) -> None:
        self._cancel_detail = detail or "unknown_cancelled"
        if self._app is not None:
            self._app.exit(result=None)


async def _run_preflight_wizard(
    *,
    check: PreflightCheckResult,
    project_root: Path,
) -> _PreflightWizardFlowResult:
    wizard = _PreflightWizard(check=check, project_root=project_root)
    return await wizard.run()


def build_preview_payload(levels: Mapping[str, LevelConfigDraft]) -> dict[str, dict[str, str]]:
    llm_levels: dict[str, str] = {}
    llm_levels_base_url: dict[str, str] = {}
    llm_levels_api_key: dict[str, str] = {}
    for level in ALL_LEVELS:
        entry = levels[level]
        llm_levels[level] = f"{entry.provider}:{entry.model}"
        if entry.base_url:
            llm_levels_base_url[level] = entry.base_url
        if entry.api_key:
            llm_levels_api_key[level] = "***"

    payload: dict[str, dict[str, str]] = {"llm_levels": llm_levels}
    if llm_levels_base_url:
        payload["llm_levels_base_url"] = llm_levels_base_url
    if llm_levels_api_key:
        payload["llm_levels_api_key"] = llm_levels_api_key
    return payload
