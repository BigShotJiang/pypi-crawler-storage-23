from __future__ import annotations

import asyncio
import logging
import sys
from typing import Any

from comate_agent_sdk.agent import ChatSession
from comate_agent_sdk.agent.events import SessionInitEvent, StopEvent

from comate_cli.terminal_agent.rpc_protocol import (
    ErrorCodes,
    JSONRPCProtocolError,
    build_error_response,
    build_event_notification,
    build_success_response,
    parse_jsonrpc_message,
)

logger = logging.getLogger(__name__)


class StdioRPCBridge:
    """JSON-RPC 2.0 bridge over stdin/stdout (NDJSON)."""

    def __init__(self, session: ChatSession) -> None:
        self._session = session
        self._write_lock = asyncio.Lock()
        self._closing = False
        self._event_pump_task: asyncio.Task[None] | None = None
        self._init_event = asyncio.Event()
        self._init_session_id: str | None = None
        self._init_error: Exception | None = None
        self._active_prompt_request_id: str | int | None = None
        self._active_prompt_result: asyncio.Future[dict[str, Any]] | None = None

    async def run(self) -> None:
        self._event_pump_task = asyncio.create_task(
            self._run_event_pump(),
            name="rpc-event-pump",
        )
        try:
            while not self._closing:
                pump_task = self._event_pump_task
                if pump_task is not None and pump_task.done():
                    await pump_task

                raw_line = await asyncio.to_thread(sys.stdin.readline)
                if raw_line == "":
                    break

                line = raw_line.strip()
                if not line:
                    continue

                await self._handle_incoming_line(line)
        finally:
            self._closing = True
            await self._cancel_active_prompt()
            active_future = self._active_prompt_result
            if active_future is not None and not active_future.done():
                active_future.set_result(
                    {"status": "cancelled", "stop_reason": "cancelled"}
                )
            pump_task = self._event_pump_task
            if pump_task is not None:
                pump_task.cancel()
                try:
                    await pump_task
                except asyncio.CancelledError:
                    pass
                self._event_pump_task = None

    async def _handle_incoming_line(self, line: str) -> None:
        try:
            message = parse_jsonrpc_message(line)
        except JSONRPCProtocolError as exc:
            await self._send(
                build_error_response(
                    request_id=exc.request_id,
                    code=exc.code,
                    message=exc.message,
                    data=exc.data,
                )
            )
            return

        method = message.get("method")
        request_id = message.get("id")
        params = message.get("params") or {}

        if method is None:
            await self._send(
                build_error_response(
                    request_id=request_id if isinstance(request_id, str | int) else None,
                    code=ErrorCodes.INVALID_REQUEST,
                    message="response payload is not supported on this endpoint",
                )
            )
            return

        if method == "initialize":
            await self._handle_initialize(request_id)
            return
        if method == "prompt":
            await self._handle_prompt(request_id, params)
            return
        if method == "cancel":
            await self._handle_cancel(request_id)
            return
        if method == "replay":
            await self._handle_replay(request_id)
            return

        await self._send(
            build_error_response(
                request_id=request_id if isinstance(request_id, str | int) else None,
                code=ErrorCodes.METHOD_NOT_FOUND,
                message=f"method not found: {method}",
            )
        )

    async def _handle_initialize(self, request_id: Any) -> None:
        if not isinstance(request_id, str | int):
            await self._send(
                build_error_response(
                    request_id=None,
                    code=ErrorCodes.INVALID_REQUEST,
                    message="initialize requires request id",
                )
            )
            return

        try:
            session_id = await self._wait_for_init_session_id()
        except Exception as exc:
            await self._send(
                build_error_response(
                    request_id=request_id,
                    code=ErrorCodes.INTERNAL_ERROR,
                    message=f"initialize failed: {exc}",
                )
            )
            return

        await self._send(
            build_success_response(
                request_id,
                {
                    "status": "ok",
                    "protocol_version": "1.0",
                    "session_id": session_id,
                },
            )
        )

    async def _handle_prompt(self, request_id: Any, params: Any) -> None:
        if not isinstance(request_id, str | int):
            await self._send(
                build_error_response(
                    request_id=None,
                    code=ErrorCodes.INVALID_REQUEST,
                    message="prompt requires request id",
                )
            )
            return

        if self._has_active_prompt():
            await self._send(
                build_error_response(
                    request_id=request_id,
                    code=ErrorCodes.INVALID_STATE,
                    message="prompt already running",
                )
            )
            return

        if not isinstance(params, dict):
            await self._send(
                build_error_response(
                    request_id=request_id,
                    code=ErrorCodes.INVALID_PARAMS,
                    message="params must be an object",
                )
            )
            return

        user_input = params.get("user_input")
        if not isinstance(user_input, str) or not user_input.strip():
            await self._send(
                build_error_response(
                    request_id=request_id,
                    code=ErrorCodes.INVALID_PARAMS,
                    message="params.user_input must be a non-empty string",
                )
            )
            return

        result_future = asyncio.get_running_loop().create_future()
        self._active_prompt_request_id = request_id
        self._active_prompt_result = result_future

        try:
            await self._session.send(user_input)
        except Exception as exc:
            self._clear_active_prompt(result_future)
            await self._send(
                build_error_response(
                    request_id=request_id,
                    code=ErrorCodes.INTERNAL_ERROR,
                    message=f"failed to send prompt: {exc}",
                )
            )
            return

        asyncio.create_task(
            self._finalize_prompt_result(result_future=result_future, request_id=request_id),
            name=f"rpc-prompt-finalize-{request_id}",
        )

    async def _handle_cancel(self, request_id: Any) -> None:
        if not isinstance(request_id, str | int):
            await self._send(
                build_error_response(
                    request_id=None,
                    code=ErrorCodes.INVALID_REQUEST,
                    message="cancel requires request id",
                )
            )
            return

        cancelled = await self._cancel_active_prompt()
        await self._send(build_success_response(request_id, {"cancelled": cancelled}))

    async def _handle_replay(self, request_id: Any) -> None:
        if not isinstance(request_id, str | int):
            await self._send(
                build_error_response(
                    request_id=None,
                    code=ErrorCodes.INVALID_REQUEST,
                    message="replay requires request id",
                )
            )
            return

        await self._send(
            build_success_response(
                request_id,
                {
                    "supported": False,
                    "reason": "replay is not implemented for stdio bridge",
                },
            )
        )

    async def _run_event_pump(self) -> None:
        try:
            async for event in self._session.events():
                if isinstance(event, SessionInitEvent):
                    self._init_session_id = str(event.session_id)
                    self._init_event.set()

                await self._send(build_event_notification(event))

                if isinstance(event, StopEvent):
                    self._resolve_prompt_from_stop(event)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.exception("rpc event pump failed")
            self._init_error = RuntimeError(f"event pump failed: {exc}")
            self._init_event.set()
            active_future = self._active_prompt_result
            if active_future is not None and not active_future.done():
                active_future.set_exception(self._init_error)
            raise

    def _resolve_prompt_from_stop(self, stop_event: StopEvent) -> None:
        active_future = self._active_prompt_result
        if active_future is None or active_future.done():
            return

        stop_reason = str(stop_event.reason or "completed")
        if stop_reason == "waiting_for_plan_approval":
            result = {
                "status": "waiting_for_plan_approval",
                "stop_reason": stop_reason,
            }
        elif stop_reason == "waiting_for_input":
            result = {"status": "waiting_for_input", "stop_reason": stop_reason}
        elif stop_reason == "interrupted":
            result = {"status": "cancelled", "stop_reason": stop_reason}
        else:
            result = {"status": "completed", "stop_reason": stop_reason}
        active_future.set_result(result)

    async def _finalize_prompt_result(
        self,
        *,
        result_future: asyncio.Future[dict[str, Any]],
        request_id: str | int,
    ) -> None:
        try:
            result = await result_future
            await self._send(build_success_response(request_id, result))
        except Exception as exc:
            await self._send(
                build_error_response(
                    request_id=request_id,
                    code=ErrorCodes.INTERNAL_ERROR,
                    message=str(exc),
                )
            )
        finally:
            self._clear_active_prompt(result_future)

    async def _cancel_active_prompt(self) -> bool:
        if not self._has_active_prompt():
            return False
        try:
            self._session.run_controller.interrupt("rpc_cancel")
        except Exception as exc:
            logger.warning(f"failed to interrupt active prompt: {exc}", exc_info=True)
        return True

    async def _wait_for_init_session_id(self) -> str:
        if self._init_session_id is not None:
            return self._init_session_id
        if self._init_error is not None:
            raise self._init_error

        await self._init_event.wait()

        if self._init_error is not None:
            raise self._init_error
        if self._init_session_id is None:
            raise RuntimeError("session init event missing")
        return self._init_session_id

    def _has_active_prompt(self) -> bool:
        active_future = self._active_prompt_result
        return active_future is not None and not active_future.done()

    def _clear_active_prompt(self, result_future: asyncio.Future[dict[str, Any]]) -> None:
        if self._active_prompt_result is not result_future:
            return
        self._active_prompt_result = None
        self._active_prompt_request_id = None

    async def _send(self, payload: dict[str, Any]) -> None:
        encoded = f"{self._dump_json(payload)}\n"
        async with self._write_lock:
            await asyncio.to_thread(sys.stdout.write, encoded)
            await asyncio.to_thread(sys.stdout.flush)

    @staticmethod
    def _dump_json(payload: dict[str, Any]) -> str:
        import json

        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
