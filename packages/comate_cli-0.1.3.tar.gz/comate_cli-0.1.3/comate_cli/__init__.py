"""Comate CLI package."""

from comate_cli.main import main

__all__ = ["main"]
