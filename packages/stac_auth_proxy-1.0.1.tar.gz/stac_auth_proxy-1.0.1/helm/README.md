# STAC Auth Proxy Helm Chart

For documentation, see [Kubernetes Deployment](https://developmentseed.org/stac-auth-proxy/user-guide/kubernetes).

## Local Installation

```bash
helm install stac-auth-proxy ./helm
```
