"""AutoTimm callbacks for training integration."""

from __future__ import annotations

from autotimm.callbacks.json_progress import JsonProgressCallback

__all__ = ["JsonProgressCallback"]
