"""
Utilities to generate and optimize parameters of interest from data (e.g.
calibration routines)
"""
