# gxl-papers

Mount 450,000+ bioRxiv/medRxiv papers as a local filesystem.

Papers appear as directories you can browse with standard Unix commands
(`ls`, `cat`, `grep`, `head`, `tail`). Content is served live from a
remote API — nothing is downloaded up front.

## Quick start

```bash
# With uv (recommended)
uv tool install gxl-papers

# Or with pip
pip install gxl-papers
```

```bash
gxl-papers login          # enter your API key
gxl-papers mount ~/papers
```

Then:

```bash
ls ~/papers/papers/
cat ~/papers/papers/<uuid>/meta.json
cat ~/papers/papers/<uuid>/content.lines
grep -i "CRISPR" ~/papers/papers/<uuid>/content.lines
ls ~/papers/papers/<uuid>/sections/
ls ~/papers/papers/<uuid>/supplements/
```

## One-liner install

```bash
curl -sSL https://papers-api.gxl.dev/install | bash
```

## Requirements

- Python 3.10+
- Linux: FUSE (`sudo apt install fuse` / `sudo yum install fuse`)
- macOS: [macFUSE](https://osxfuse.github.io)

## Commands

```
gxl-papers login               Save API key
gxl-papers mount [PATH]        Mount filesystem (default: ~/papers)
gxl-papers mount -f [PATH]     Mount in foreground (for debugging)
gxl-papers unmount [PATH]      Unmount
gxl-papers status              Check mount and API health
```

## Environment variables

| Variable | Description |
|---|---|
| `GXL_PAPERS_API_KEY` | API key (alternative to `login`) |
| `GXL_PAPERS_API_URL` | API base URL (default: Cloud Run endpoint) |

## Directory structure

```
~/papers/
  papers/
    {uuid}/
      meta.json           Title, DOI, authors, abstract
      content.lines       Full text (line-numbered)
      sections/
        Abstract.lines
        Introduction.lines
        Methods.lines
        Results.lines
        Discussion.lines
      supplements/
        file01.docx.md.lines
        data.csv
      figures/
        fig1
        fig2
```
