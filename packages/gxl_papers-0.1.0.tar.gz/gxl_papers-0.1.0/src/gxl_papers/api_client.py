"""HTTP client for the Papers API with caching and retries."""

import json
import logging
import time

import requests
from cachetools import TTLCache

logger = logging.getLogger(__name__)


class PapersAPIClient:
    """Thin HTTP client that wraps the papers-api REST endpoints.

    Adds:
    - TTL caching for getattr/readdir (critical for FUSE performance)
    - Retry on transient failures
    - Bearer token auth
    """

    def __init__(self, base_url: str, api_key: str | None = None):
        self.base_url = base_url.rstrip("/")
        self._session = requests.Session()
        if api_key:
            self._session.headers["Authorization"] = f"Bearer {api_key}"
        self._session.headers["Accept"] = "application/json"

        self._attr_cache: TTLCache = TTLCache(maxsize=5000, ttl=60)
        self._dir_cache: TTLCache = TTLCache(maxsize=1000, ttl=60)
        self._content_cache: TTLCache = TTLCache(maxsize=300, ttl=300)

    def _get(self, endpoint: str, params: dict | None = None, timeout: int = 30) -> dict:
        url = f"{self.base_url}{endpoint}"
        for attempt in range(3):
            try:
                resp = self._session.get(url, params=params, timeout=timeout)
                if resp.status_code == 404:
                    return {"_error": "not_found"}
                resp.raise_for_status()
                return resp.json()
            except requests.exceptions.ConnectionError:
                if attempt < 2:
                    time.sleep(0.5 * (attempt + 1))
                    continue
                raise
            except requests.exceptions.HTTPError:
                raise
        return {"_error": "max_retries"}

    def getattr(self, path: str) -> dict | None:
        if path in self._attr_cache:
            return self._attr_cache[path]
        result = self._get("/v1/getattr", {"path": path})
        if "_error" in result:
            return None
        self._attr_cache[path] = result
        if "entries" in result:
            self._dir_cache[path] = result["entries"]
        return result

    def readdir(self, path: str, limit: int = 200) -> list[dict] | None:
        if path in self._dir_cache:
            return self._dir_cache[path]
        result = self._get("/v1/readdir", {"path": path, "limit": limit})
        if "_error" in result:
            return None
        entries = result.get("entries", [])
        self._dir_cache[path] = entries
        return entries

    def read(self, path: str) -> str | None:
        """Read file content as plain text (cached)."""
        if path in self._content_cache:
            return self._content_cache[path]
        result = self._get("/v1/read", {"path": path})
        if "_error" in result:
            return None

        content_type = result.get("type", "")
        if content_type == "json":
            text = json.dumps(result["content"], indent=2)
        elif content_type == "lines":
            lines = result.get("lines", [])
            text = "\n".join(
                f"L{ln['line_number']} : {ln['content']}" for ln in lines
            )
        else:
            text = json.dumps(result, indent=2)

        self._content_cache[path] = text
        return text

    def search(self, query: str, n: int = 25) -> list[dict]:
        result = self._get("/v1/search", {"q": query, "n": n})
        return result.get("results", [])

    def health(self) -> dict:
        return self._get("/health")
