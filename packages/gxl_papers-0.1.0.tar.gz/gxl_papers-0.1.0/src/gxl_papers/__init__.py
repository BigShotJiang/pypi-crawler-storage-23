"""gxl-papers — Mount bioRxiv/medRxiv papers as a local filesystem."""

__version__ = "0.1.0"
