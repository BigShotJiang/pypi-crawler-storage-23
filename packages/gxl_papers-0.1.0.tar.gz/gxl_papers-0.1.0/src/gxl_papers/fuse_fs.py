"""FUSE filesystem that proxies all operations to the remote Papers API.

Uses fusepy (works on macOS + Linux, no async, simple). Read-only.

Mount hierarchy:
    {mount_point}/
        papers/
            {uuid}/
                meta.json
                content.lines
                sections/
                    Abstract.lines
                    Methods.lines
                    ...
                supplements/
                    ...
                figures/
                    ...
"""

import errno
import json
import logging
import os
import stat
import time

try:
    from fuse import FUSE, FuseOSError, Operations
except ImportError:
    raise ImportError(
        "fusepy is required. Install it with:  pip install fusepy\n"
        "On macOS you also need macFUSE: https://osxfuse.github.io"
    )

from .api_client import PapersAPIClient

logger = logging.getLogger(__name__)


class PapersFS(Operations):
    """Read-only FUSE filesystem backed by the Papers API."""

    def __init__(self, client: PapersAPIClient):
        self.client = client
        self.fd = 0
        self._open_files: dict[int, str] = {}
        self._mount_time = time.time()

    def _now(self) -> float:
        return self._mount_time

    def _vpath(self, path: str) -> str:
        """Convert local FUSE path to virtual API path.

        FUSE gives us paths like /papers/uuid/content.lines.
        The API expects the same format, so we just pass through.
        """
        return path

    # ------------------------------------------------------------------
    # Attribute operations
    # ------------------------------------------------------------------

    def getattr(self, path, fh=None):
        vpath = self._vpath(path)
        attrs = self.client.getattr(vpath)

        if attrs is None:
            raise FuseOSError(errno.ENOENT)

        now = self._now()
        is_dir = attrs.get("type") == "dir"

        if is_dir:
            return {
                "st_mode": stat.S_IFDIR | 0o555,
                "st_nlink": 2,
                "st_size": 4096,
                "st_ctime": now,
                "st_mtime": now,
                "st_atime": now,
                "st_uid": os.getuid(),
                "st_gid": os.getgid(),
            }

        size = attrs.get("size", 0)
        if size == 0:
            content = self.client.read(vpath)
            size = len(content.encode("utf-8")) if content else 0

        return {
            "st_mode": stat.S_IFREG | 0o444,
            "st_nlink": 1,
            "st_size": size,
            "st_ctime": now,
            "st_mtime": now,
            "st_atime": now,
            "st_uid": os.getuid(),
            "st_gid": os.getgid(),
        }

    def readdir(self, path, fh):
        vpath = self._vpath(path)
        entries = self.client.readdir(vpath)

        yield "."
        yield ".."

        if entries:
            for entry in entries:
                name = entry["name"] if isinstance(entry, dict) else entry
                yield name

    def open(self, path, flags):
        if flags & (os.O_WRONLY | os.O_RDWR):
            raise FuseOSError(errno.EROFS)
        self.fd += 1
        self._open_files[self.fd] = path
        return self.fd

    def read(self, path, size, offset, fh):
        vpath = self._vpath(path)
        content = self.client.read(vpath)
        if content is None:
            raise FuseOSError(errno.ENOENT)
        data = content.encode("utf-8", errors="replace")
        return data[offset:offset + size]

    def release(self, path, fh):
        self._open_files.pop(fh, None)
        return 0

    def statfs(self, path):
        return {
            "f_bsize": 4096,
            "f_frsize": 4096,
            "f_blocks": 1_000_000,
            "f_bfree": 0,
            "f_bavail": 0,
            "f_files": 500_000,
            "f_ffree": 0,
            "f_namemax": 255,
        }

    # Write operations — all return EROFS
    def chmod(self, path, mode):
        raise FuseOSError(errno.EROFS)

    def chown(self, path, uid, gid):
        raise FuseOSError(errno.EROFS)

    def create(self, path, mode, fi=None):
        raise FuseOSError(errno.EROFS)

    def mkdir(self, path, mode):
        raise FuseOSError(errno.EROFS)

    def rename(self, old, new):
        raise FuseOSError(errno.EROFS)

    def rmdir(self, path):
        raise FuseOSError(errno.EROFS)

    def symlink(self, name, target):
        raise FuseOSError(errno.EROFS)

    def truncate(self, path, length, fh=None):
        raise FuseOSError(errno.EROFS)

    def unlink(self, path):
        raise FuseOSError(errno.EROFS)

    def utimens(self, path, times=None):
        raise FuseOSError(errno.EROFS)

    def write(self, path, data, offset, fh):
        raise FuseOSError(errno.EROFS)


def mount(mount_point: str, api_url: str, api_key: str | None = None,
          foreground: bool = True, debug: bool = False):
    """Mount the papers filesystem at the given path."""
    os.makedirs(mount_point, exist_ok=True)

    client = PapersAPIClient(api_url, api_key)

    # Verify connectivity
    try:
        health = client.health()
        if health.get("status") != "ok":
            logger.warning("API health check returned: %s", health)
    except Exception as e:
        logger.error("Cannot reach API at %s: %s", api_url, e)
        raise SystemExit(f"Cannot reach Papers API at {api_url}: {e}")

    print(f"📁 Mounting papers filesystem at {mount_point}")
    print(f"   API: {api_url}")
    print(f"   Auth: {'enabled' if api_key else 'none (open mode)'}")
    print()
    print(f"   ls {mount_point}/papers/")
    print(f"   cat {mount_point}/papers/{{uuid}}/meta.json")
    print(f"   cat {mount_point}/papers/{{uuid}}/content.lines")
    print()

    fs = PapersFS(client)

    FUSE(
        fs,
        mount_point,
        foreground=foreground,
        ro=True,
        nothreads=False,
        allow_other=False,
        **({"debug": True} if debug else {}),
    )
