"""CLI for gxl-papers: mount, unmount, status, login."""

import json
import logging
import os
import signal
import subprocess
import sys
from pathlib import Path

import click

CONFIG_DIR = Path.home() / ".config" / "gxl-papers"
CONFIG_FILE = CONFIG_DIR / "config.json"
PID_FILE = CONFIG_DIR / "mount.pid"
DEFAULT_MOUNT = str(Path.home() / "papers")
DEFAULT_API_URL = "https://papers-api-gxl-prod.run.app"


def _load_config() -> dict:
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def _save_config(cfg: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


@click.group()
@click.option("--debug", is_flag=True, help="Enable debug logging")
def main(debug: bool):
    """gxl-papers — Mount 450K+ bioRxiv/medRxiv papers as a local filesystem."""
    level = logging.DEBUG if debug else logging.WARNING
    logging.basicConfig(level=level, format="%(levelname)s: %(message)s")


@main.command()
@click.option("--api-key", envvar="GXL_PAPERS_API_KEY", help="API key")
@click.option("--api-url", envvar="GXL_PAPERS_API_URL", help="API base URL")
def login(api_key: str | None, api_url: str | None):
    """Save API credentials for future use."""
    cfg = _load_config()
    if api_key:
        cfg["api_key"] = api_key
    else:
        api_key = click.prompt("API key", hide_input=True)
        cfg["api_key"] = api_key
    if api_url:
        cfg["api_url"] = api_url
    _save_config(cfg)
    click.echo("Credentials saved to ~/.config/gxl-papers/config.json")


@main.command()
@click.argument("mount_point", default=DEFAULT_MOUNT)
@click.option("--api-key", envvar="GXL_PAPERS_API_KEY", help="API key (or use `login`)")
@click.option("--api-url", envvar="GXL_PAPERS_API_URL", help="API base URL")
@click.option("--foreground", "-f", is_flag=True, help="Run in foreground (default: daemon)")
@click.option("--debug", is_flag=True, help="Enable FUSE debug output")
def mount(mount_point: str, api_key: str | None, api_url: str | None,
          foreground: bool, debug: bool):
    """Mount the papers filesystem."""
    cfg = _load_config()
    api_key = api_key or cfg.get("api_key")
    api_url = api_url or cfg.get("api_url", DEFAULT_API_URL)

    if not api_key:
        click.echo("No API key found. Use --api-key or run `gxl-papers login` first.", err=True)
        sys.exit(1)

    mount_point = os.path.expanduser(mount_point)

    if foreground:
        from .fuse_fs import mount as do_mount
        do_mount(mount_point, api_url, api_key, foreground=True, debug=debug)
    else:
        # Daemon mode: fork into background
        proc = subprocess.Popen(
            [sys.executable, "-m", "gxl_papers.cli", "mount", mount_point,
             "--api-key", api_key, "--api-url", api_url, "-f"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        PID_FILE.parent.mkdir(parents=True, exist_ok=True)
        PID_FILE.write_text(str(proc.pid))
        click.echo(f"Mounted at {mount_point} (pid {proc.pid})")
        click.echo(f"  ls {mount_point}/papers/")
        click.echo(f"  gxl-papers unmount {mount_point}")


@main.command()
@click.argument("mount_point", default=DEFAULT_MOUNT)
def unmount(mount_point: str):
    """Unmount the papers filesystem."""
    mount_point = os.path.expanduser(mount_point)

    # Try fusermount first (Linux)
    ret = subprocess.run(["fusermount", "-u", mount_point], capture_output=True)
    if ret.returncode != 0:
        # Try umount (macOS)
        ret = subprocess.run(["umount", mount_point], capture_output=True)

    if ret.returncode == 0:
        click.echo(f"Unmounted {mount_point}")
    else:
        click.echo(f"Failed to unmount: {ret.stderr.decode()}", err=True)
        sys.exit(1)

    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
            os.kill(pid, signal.SIGTERM)
        except (ProcessLookupError, ValueError):
            pass
        PID_FILE.unlink(missing_ok=True)


@main.command()
@click.argument("mount_point", default=DEFAULT_MOUNT)
def status(mount_point: str):
    """Check if the filesystem is mounted and API is reachable."""
    mount_point = os.path.expanduser(mount_point)
    cfg = _load_config()
    api_url = cfg.get("api_url", DEFAULT_API_URL)
    api_key = cfg.get("api_key")

    # Check mount
    if os.path.ismount(mount_point):
        click.echo(f"Mount: {mount_point} (active)")
    else:
        click.echo(f"Mount: {mount_point} (not mounted)")

    # Check PID
    if PID_FILE.exists():
        pid = PID_FILE.read_text().strip()
        click.echo(f"PID: {pid}")
    else:
        click.echo("PID: none")

    # Check API
    click.echo(f"API: {api_url}")
    click.echo(f"Auth: {'configured' if api_key else 'not configured'}")

    if api_key:
        try:
            from .api_client import PapersAPIClient
            client = PapersAPIClient(api_url, api_key)
            health = client.health()
            click.echo(f"Health: {health.get('status', 'unknown')}")
        except Exception as e:
            click.echo(f"Health: error ({e})")


if __name__ == "__main__":
    main()
