#!/usr/bin/env bash
set -euo pipefail
#
# gxl-papers installer
# Usage: curl -sSL https://papers-api.gxl.dev/install | bash
#

echo "==> Installing gxl-papers..."

# Check FUSE
if [ "$(uname)" = "Linux" ]; then
    if ! command -v fusermount &>/dev/null; then
        echo "Warning: FUSE not found. Install with:  sudo apt install fuse"
    fi
elif [ "$(uname)" = "Darwin" ]; then
    if ! test -d /Library/Filesystems/macfuse.fs; then
        echo "Warning: macFUSE not found. Install from: https://osxfuse.github.io"
    fi
fi

# Prefer uv if available, fall back to pip
if command -v uv &>/dev/null; then
    uv tool install gxl-papers
    echo "==> Installed via uv"
elif command -v pip3 &>/dev/null || command -v pip &>/dev/null; then
    PIP="$(command -v pip3 || command -v pip)"
    "${PIP}" install gxl-papers
    echo "==> Installed via pip"
else
    # Bootstrap uv (fastest path if nothing is installed)
    echo "==> No uv or pip found — installing uv first..."
    curl -LsSf https://astral.sh/uv/install.sh | sh
    export PATH="${HOME}/.local/bin:${PATH}"
    uv tool install gxl-papers
    echo "==> Installed via uv"
fi

echo ""
echo "==> Setup:"
echo "    gxl-papers login"
echo "    gxl-papers mount ~/papers"
echo ""
echo "==> Then use standard commands:"
echo "    ls ~/papers/papers/"
echo "    cat ~/papers/papers/{uuid}/meta.json"
echo "    cat ~/papers/papers/{uuid}/content.lines"
