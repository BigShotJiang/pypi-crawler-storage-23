from azure.identity.aio import DefaultAzureCredential
from Osdental.Auth import ITokenProvider


class LocalAzureCredentialProvider(ITokenProvider):

    def __init__(self):
        self._credential = DefaultAzureCredential()

    async def get_token(self, scope: str) -> str:
        token = await self._credential.get_token(scope)
        return token.token