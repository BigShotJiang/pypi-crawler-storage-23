from azure.identity.aio import ManagedIdentityCredential
from Osdental.Auth.ITokenProvider import ITokenProvider


class AzureManagedIdentityTokenProvider(ITokenProvider):

    def __init__(self):
        self._credential = ManagedIdentityCredential()

    async def get_token(self, scope: str) -> str:
        token = await self._credential.get_token(scope)
        return token.token