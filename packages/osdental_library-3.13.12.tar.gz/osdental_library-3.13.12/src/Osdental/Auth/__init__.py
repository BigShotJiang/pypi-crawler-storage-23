from abc import ABC, abstractmethod

class ITokenProvider(ABC):

    @abstractmethod
    async def get_token(self, scope: str) -> str:
        pass