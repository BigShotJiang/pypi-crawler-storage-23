import asyncio
import time
from typing import Dict
from abc import ABC, abstractmethod
from azure.identity.aio import DefaultAzureCredential
from azure.keyvault.secrets.aio import SecretClient


class ISecretProvider(ABC):

    @abstractmethod
    async def get(self, name: str) -> str:
        pass

class AzureKeyVaultSecretProvider(ISecretProvider):

    def __init__(
        self, 
        vault_url: str,
        ttl_seconds: int = 300,
        is_local: bool = False
    ):
        self._vault_url = vault_url
        self._ttl = ttl_seconds

        self._credential = None
        self._client = None

        self._cache: Dict[str, tuple[str, float]] = {}
        self._lock = asyncio.Lock()
        self._initialized = False
        self._is_local = is_local

    async def _initialize(self):

        if self._initialized:
            return

        async with self._lock:
            if self._initialized:
                return

            self._credential = DefaultAzureCredential()

            self._client = SecretClient(
                vault_url=self._vault_url,
                credential=self._credential
            )

            self._initialized = True

    async def get(self, name: str) -> str:

        await self._initialize()

        now = time.time()

        # Cache hit válido
        if name in self._cache:
            value, expires_at = self._cache[name]
            if now < expires_at:
                return value

        # Evita múltiples llamadas concurrentes
        async with self._lock:

            # Double check pattern
            if name in self._cache:
                value, expires_at = self._cache[name]
                if now < expires_at:
                    return value

            secret = await self._client.get_secret(name)

            value = secret.value
            expires_at = now + self._ttl

            self._cache[name] = (value, expires_at)

            return value

    async def close(self):

        if self._client:
            await self._client.close()

        if self._credential:
            await self._credential.close()