from setdoc.core import *
from setdoc.tests import *
