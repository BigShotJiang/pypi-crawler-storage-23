from setdoc.core.basic import basic
from setdoc.core.getbasicdoc import getbasicdoc
from setdoc.core.SetDoc import SetDoc

__all__ = ["SetDoc", "basic", "getbasicdoc", "setdoc"]

setdoc = SetDoc  # legacy
