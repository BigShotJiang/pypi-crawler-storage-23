# TODO: This is an example file which you should delete/edit after implementing
import os
from database_mysql_local.generic_crud import GenericCRUD
from logger_local.MetaLogger import MetaLogger
from translate import Translator
from api_management_local.api_limit import APILimitsLocal

#from language_remote import LangCode
# from python_sdk_remote.utilities import our_get_env

# The old way without class
# from .constants_src_examples_local import (<THE_ENTITIES>_CODE_LOGGER_OBJECT,
#                                <THE_ENTITY>_SCHEMA_NAME, <THE_ENTITY>_TABLE_NAME,
#                                <THE_ENTITY>_VIEW_NAME, <THE_ENTITY>_COLUMN_NAME)
# from .constants_src_<the_entities> import ConstantsSrc<TheEntities>

# logger = Logger.create_logger(object=ConstantsSrc<TheEntities>Local.<THE_ENTITIES>_CODE_LOGGER_OBJECT)


class Translate(GenericCRUD, metaclass=MetaLogger):
    def __init__(self, is_test_data: bool = False) -> None:
        #GenericCRUD.__init__(self, default_schema_name="translate")
        #self.logger.info("whatever you want to log "+ PACKAGE_VERSION)
        # TODO is this okay? considered magic variable or no?
        self.default_language = "en"
        self.api_type_id = None  # TODO where we get this from?
        # TODO check if this is good
        self.user_external_id = os.getenv("USER_EXTERNAL_ID", "")
        self.endpoint_url = ""  # TODO where we get this from?

    # If this is CRUD method please make sure we don't have this method
    #  functionality already in GenericCRUD and if needed wrap the GenericCRUD
    #  method
    # TODO implement functionality for document or non string translation?
    def translate_text(self, source_language: str, output_language: str, text: str) -> str:

        if Translator is None:
            raise ImportError("translate package is not installed. Install it to use translate_text.")

        if not output_language:
            output_language = self.default_language

        #detect how long string
        text_length = len(text)

        #logic to determine if simple translate or google cloud translate
        #get number of remaining google_cloud translates (total 500,000 per month I think)
        #if remaining > 450,000 or something,
            #use simple translate
        #else use cloud translate

        #if error with cloud translate
            #use simple translate
        
        
       
        #sfgfgs
        return #final_translation

    def translate_with_package(self, source_language: str, output_language: str, text: str,) -> str:
        # TODO implement
        if source_language:
            translator = Translator(from_lang=source_language, to_lang=output_language)
        else:
            translator = Translator(to_lang=output_language)
        final_translation = translator.translate(text)
        return final_translation

    def translate_with_google_cloud(self, input_text: str) -> str:
        #  TODO Implement
        return
# TODO: once done, run some auto lint formatter such as autopep8, autoflake or
#  whatever your IDE provide.
