# Copyright 2026 UsamaAliceWhite All Rights Reserved


# 標準モジュール
import datetime
import inspect
import logging
import pathlib

# 自作モジュール
from .Handler import HandlerManager, HandlerParameter
from .Logger import LoggerManager, LoggerParameter


# 公開API
__all__ = ["Declaration", "Output"]


# --- ロギング機能の設定 ---
class Declaration:
    def __new__(cls,
                log_file_path: pathlib.Path = pathlib.Path.home() / "Anonymous.log",
                *,
                log_message_format: str = "%(asctime)s [%(levelname)-8s] %(name)-20s %(funcName)-20s:%(lineno)-4d - %(message)s",
                log_datetime_format: str = "%Y-%m-%d %H:%M:%S",
                handler_when: str = "midnight",
                handler_interval: int = 1,
                handler_backupcount: int = 30,
                handler_encoding: str | None = "utf-8",
                handler_delay: bool = False,
                handler_utc: bool = False,
                handler_attime: datetime.time | None = None,
                handler_errors: str | None = None,
                handler_level: int = logging.DEBUG
                ) -> None:
        HandlerManager(HandlerParameter(
            file_path= pathlib.Path(log_file_path),
            when= handler_when,
            interval= handler_interval,
            backupcount= handler_backupcount,
            encoding= handler_encoding,
            delay= handler_delay,
            utc= handler_utc,
            attime= handler_attime,
            errors= handler_errors,
            level= handler_level,
            message_format= log_message_format,
            datetime_format= log_datetime_format
        ))


# --- ログの出力 ---
class Output:
    def __new__(cls,
                message: str,
                *,
                logger_name: str | None = None,
                logger_level: int = logging.DEBUG
                ) -> None:
        logger_name = logger_name or pathlib.Path(inspect.stack()[1].filename).stem
        handler_manager: HandlerManager = HandlerManager()
        logger_manager: LoggerManager = LoggerManager(LoggerParameter(
            handler= handler_manager.create_handler(),
            name= logger_name,
            level= logger_level
        ))
        logger: logging.Logger = logger_manager.create_logger()
        if logger_level == logging.CRITICAL:
            logger.critical(message, stacklevel= 2)
        elif logger_level == logging.ERROR:
            logger.error(message, stacklevel= 2)
        elif logger_level == logging.WARNING:
            logger.warning(message, stacklevel= 2)
        elif logger_level == logging.INFO:
            logger.info(message, stacklevel= 2)
        else:
            logger.debug(message, stacklevel= 2)