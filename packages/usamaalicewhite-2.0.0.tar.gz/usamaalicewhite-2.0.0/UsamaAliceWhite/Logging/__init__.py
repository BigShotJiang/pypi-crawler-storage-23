# Copyright 2026 UsamaAliceWhite All Rights Reserved


# 自作モジュール
from .Core import Declaration, Output


# 公開API
__all__ = ["Declaration", "Output"]