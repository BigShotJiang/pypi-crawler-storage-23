from pathlib import Path
from typing import List, Dict, Union, Optional
import torch
from torch.utils.data import Dataset
import cv2
import numpy as np


class SegmentationDataset(Dataset):
    """
    PyTorch Dataset for loading image and mask pairs for segmentation tasks.

    Expects a folder structure:
        images_dir/
            image1.png
            image2.jpg
            ...
        masks_dir/
            image1_mask.png
            image2_mask.png
            ...

    The correspondence is based on the filename stem (name without extension).
    A mask suffix can be provided to handle cases where mask filenames differ
    from image filenames (e.g., image '001.jpg' → mask '001_mask.png').

    Args:
        images_dir (str or Path): Directory containing input images.
        masks_dir (str or Path): Directory containing ground truth masks.
        image_size (int, optional): Target size (height and width) for resizing.
            Defaults to 512.
        mask_suffix (str, optional): Suffix appended to the image stem to form
            the mask filename. For example, if an image is 'frame_001.jpg' and
            its mask is 'frame_001_gt.png', set mask_suffix='_gt'. Defaults to ''.

    Attributes:
        ids (List[str]): List of image stems (without extension) found in images_dir.
    """

    def __init__(
        self,
        images_dir: Union[str, Path],
        masks_dir: Union[str, Path],
        image_size: int = 512,
        mask_suffix: str = '',
    ) -> None:
        self.images_dir = Path(images_dir)
        self.masks_dir = Path(masks_dir)
        self.image_size = image_size
        self.mask_suffix = mask_suffix

        self.ids: List[str] = [
            f.stem for f in self.images_dir.glob('*')
            if f.suffix.lower() in ('.png', '.jpg', '.jpeg', '.tif')
        ]

    def __len__(self) -> int:
        return len(self.ids)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """
        Load and return a single sample (image and mask) at the given index.

        Args:
            idx (int): Index of the sample to retrieve.

        Returns:
            Dict[str, torch.Tensor]: A dictionary with keys:
                - 'image': torch.Tensor of shape (3, H, W) normalized to [0, 1].
                - 'mask': torch.Tensor of shape (H, W) with class indices (long).

        Raises:
            FileNotFoundError: If the image or mask file cannot be read.
        """
        name = self.ids[idx]

        img_path = self.images_dir / f"{name}.png"
        if not img_path.exists():
            img_path = self.images_dir / f"{name}.jpg"

        image = cv2.imread(str(img_path))
        if image is None:
            raise FileNotFoundError(f"Image not found or unable to read: {img_path}")

        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        mask_path = self.masks_dir / f"{name}{self.mask_suffix}.png"
        mask = cv2.imread(str(mask_path), cv2.IMREAD_GRAYSCALE)
        if mask is None:
            raise FileNotFoundError(f"Mask not found or unable to read: {mask_path}")

        image = cv2.resize(image, (self.image_size, self.image_size))
        mask = cv2.resize(
            mask,
            (self.image_size, self.image_size),
            interpolation=cv2.INTER_NEAREST  # keep discrete labels
        )

        image = torch.from_numpy(image).permute(2, 0, 1).float() / 255.0
        mask = torch.from_numpy(mask).long()

        return {'image': image, 'mask': mask}