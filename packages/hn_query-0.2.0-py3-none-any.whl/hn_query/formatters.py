"""Output formatters for Hacker News stories."""

from __future__ import annotations

import csv
import json
from datetime import UTC, datetime
from io import StringIO
from typing import Any

from rich.console import Console, Group, RenderableType
from rich.panel import Panel
from rich.text import Text

from hn_query.models import HNStory


def _story_to_dict(story: HNStory, rank: int) -> dict[str, Any]:
    return {
        "rank": rank,
        "id": story.id,
        "title": story.title,
        "score": story.score,
        "comments": story.descendants,
        "author": story.by,
        "url": story.url,
        "time": story.time,
    }


def to_json(stories: list[HNStory]) -> str:
    """Convert stories to pretty JSON."""
    payload = [
        _story_to_dict(story, rank) for rank, story in enumerate(stories, start=1)
    ]
    return json.dumps(payload, ensure_ascii=False, indent=2)


def to_csv(stories: list[HNStory]) -> str:
    """Convert stories to CSV text."""
    buffer = StringIO()
    writer = csv.DictWriter(
        buffer,
        fieldnames=[
            "rank",
            "id",
            "title",
            "score",
            "comments",
            "author",
            "url",
            "time",
        ],
    )
    writer.writeheader()
    for rank, story in enumerate(stories, start=1):
        writer.writerow(_story_to_dict(story, rank))
    return buffer.getvalue()


def render_human(stories: list[HNStory]) -> RenderableType:
    """Build Rich cards for terminal output."""
    if not stories:
        return Panel(Text("No stories found."), title="Top Stories")

    cards: list[Panel] = []
    for rank, story in enumerate(stories, start=1):
        timestamp = datetime.fromtimestamp(story.time, tz=UTC).strftime(
            "%Y-%m-%d %H:%M:%SZ"
        )
        body = Text()
        body.append(f"Score: {story.score}\n")
        body.append(f"Comments: {story.descendants}\n")
        body.append(f"Author: {story.by}\n")
        body.append(f"Time: {timestamp}\n")
        body.append(f"URL: {story.url or '(none)'}")
        cards.append(Panel(body, title=f"#{rank} {story.title}", expand=True))

    return Group(*cards)


def to_human_text(stories: list[HNStory]) -> str:
    """Render human output to plain text for file writes."""
    console = Console(record=True, color_system=None, force_terminal=False)
    console.print(render_human(stories))
    return console.export_text()


def item_to_json(item: dict[str, Any]) -> str:
    """Convert a single item to pretty JSON."""
    return json.dumps(item, ensure_ascii=False, indent=2)


def item_to_csv(item: dict[str, Any]) -> str:
    """Convert a single item to one-row CSV."""
    fields = [
        "id",
        "type",
        "title",
        "text",
        "url",
        "score",
        "by",
        "time",
        "comments",
        "parent",
        "dead",
        "deleted",
    ]
    buffer = StringIO()
    writer = csv.DictWriter(buffer, fieldnames=fields)
    writer.writeheader()
    writer.writerow({key: item.get(key, "") for key in fields})
    return buffer.getvalue()


def render_item_human(item: dict[str, Any]) -> RenderableType:
    """Build a Rich card for one item."""
    body = Text()
    body.append(f"Type: {item.get('type', '')}\n")
    body.append(f"Author: {item.get('by', '')}\n")
    body.append(f"Score: {item.get('score', 0)}\n")
    body.append(f"Comments: {item.get('comments', 0)}\n")
    body.append(f"URL: {item.get('url', '') or '(none)'}\n")
    body.append(f"Parent: {item.get('parent', 0)}\n")
    body.append(f"Dead: {item.get('dead', False)}\n")
    body.append(f"Deleted: {item.get('deleted', False)}")

    title = str(item.get("title", "")) or f"Item {item.get('id', '')}"
    return Panel(body, title=title, expand=True)


def item_to_human_text(item: dict[str, Any]) -> str:
    """Render a single item to plain text."""
    console = Console(record=True, color_system=None, force_terminal=False)
    console.print(render_item_human(item))
    return console.export_text()

