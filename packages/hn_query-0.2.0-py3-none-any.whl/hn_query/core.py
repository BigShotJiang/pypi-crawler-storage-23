"""Core business logic — keep this free of CLI concerns (no typer imports)."""


def greet(name: str, *, shout: bool = False) -> str:
    """Build a greeting message.

    Args:
        name: The name to greet.
        shout: If True, return the greeting in uppercase.

    Returns:
        The formatted greeting string.
    """
    message = f"Hello, {name}!"
    if shout:
        message = message.upper()
    return message
