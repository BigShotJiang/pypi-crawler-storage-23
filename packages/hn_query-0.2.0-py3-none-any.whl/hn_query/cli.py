"""CLI entry point — all commands are defined here."""

from __future__ import annotations

from enum import StrEnum
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from hn_query import __version__
from hn_query.api import HNApiError, get_best, get_item, get_new, get_top
from hn_query.formatters import (
    item_to_csv,
    item_to_human_text,
    item_to_json,
    render_human,
    render_item_human,
    to_csv,
    to_human_text,
    to_json,
)
from hn_query.models import HNStory

app = typer.Typer(
    name="hn-query",
    help="HN CLI utility.",
    no_args_is_help=True,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"hn-query v{__version__}")
        raise typer.Exit


@app.callback()
def main(
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            "-V",
            help="Show version and exit.",
            callback=_version_callback,
            is_eager=True,
        ),
    ] = None,
) -> None:
    """HN CLI utility."""


class OutputFormat(StrEnum):
    """Supported output formats for story commands."""

    HUMAN = "human"
    JSON = "json"
    CSV = "csv"


def _resolve_format(
    *,
    output_format: OutputFormat,
    json_output: bool,
    csv_output: bool,
) -> OutputFormat:
    if json_output and csv_output:
        typer.echo("Error: choose only one of --json or --csv.", err=True)
        raise typer.Exit(code=2)

    resolved = output_format
    if json_output:
        if output_format is OutputFormat.CSV:
            typer.echo("Error: --format csv conflicts with --json.", err=True)
            raise typer.Exit(code=2)
        resolved = OutputFormat.JSON

    if csv_output:
        if output_format is OutputFormat.JSON:
            typer.echo("Error: --format json conflicts with --csv.", err=True)
            raise typer.Exit(code=2)
        resolved = OutputFormat.CSV

    return resolved


def _write_output(path: Path, content: str) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
    except OSError as exc:
        typer.echo(f"Error writing output file: {exc}", err=True)
        raise typer.Exit(code=1) from exc


def _render_story_output(
    *,
    stories: list[HNStory],
    selected_format: OutputFormat,
    output: Path | None,
) -> None:
    if selected_format is OutputFormat.HUMAN and output is None:
        Console().print(render_human(stories))
        return

    content = ""
    if selected_format is OutputFormat.HUMAN:
        content = to_human_text(stories)
    elif selected_format is OutputFormat.JSON:
        content = to_json(stories)
    elif selected_format is OutputFormat.CSV:
        content = to_csv(stories)

    if output is not None:
        _write_output(output, content)
        typer.echo(f"Wrote {selected_format.value} output to {output}")
        return

    typer.echo(content)


def _render_item_output(
    *,
    item: dict[str, object],
    selected_format: OutputFormat,
    output: Path | None,
) -> None:
    if selected_format is OutputFormat.HUMAN and output is None:
        Console().print(render_item_human(item))
        return

    content = ""
    if selected_format is OutputFormat.HUMAN:
        content = item_to_human_text(item)
    elif selected_format is OutputFormat.JSON:
        content = item_to_json(item)
    elif selected_format is OutputFormat.CSV:
        content = item_to_csv(item)

    if output is not None:
        _write_output(output, content)
        typer.echo(f"Wrote {selected_format.value} output to {output}")
        return

    typer.echo(content)


@app.command()
def top(
    limit: Annotated[
        int,
        typer.Option(
            "--limit",
            "-n",
            min=1,
            max=100,
            help="Number of top stories to fetch.",
        ),
    ] = 10,
    output_format: Annotated[
        OutputFormat,
        typer.Option(
            "--format",
            help="Output format: human, json, or csv.",
            case_sensitive=False,
        ),
    ] = OutputFormat.HUMAN,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Shortcut for --format json."),
    ] = False,
    csv_output: Annotated[
        bool,
        typer.Option("--csv", help="Shortcut for --format csv."),
    ] = False,
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Write output to this file."),
    ] = None,
    timeout: Annotated[
        float,
        typer.Option("--timeout", min=0.1, help="HTTP timeout in seconds."),
    ] = 10.0,
) -> None:
    """Fetch top Hacker News stories."""
    selected_format = _resolve_format(
        output_format=output_format,
        json_output=json_output,
        csv_output=csv_output,
    )

    try:
        stories = get_top(limit=limit, timeout=timeout)
    except HNApiError as exc:
        typer.echo(f"Error fetching top stories: {exc}", err=True)
        raise typer.Exit(code=1) from exc

    _render_story_output(
        stories=stories,
        selected_format=selected_format,
        output=output,
    )


@app.command()
def new(
    limit: Annotated[
        int,
        typer.Option(
            "--limit",
            "-n",
            min=1,
            max=100,
            help="Number of new stories to fetch.",
        ),
    ] = 10,
    output_format: Annotated[
        OutputFormat,
        typer.Option(
            "--format",
            help="Output format: human, json, or csv.",
            case_sensitive=False,
        ),
    ] = OutputFormat.HUMAN,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Shortcut for --format json."),
    ] = False,
    csv_output: Annotated[
        bool,
        typer.Option("--csv", help="Shortcut for --format csv."),
    ] = False,
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Write output to this file."),
    ] = None,
    timeout: Annotated[
        float,
        typer.Option("--timeout", min=0.1, help="HTTP timeout in seconds."),
    ] = 10.0,
) -> None:
    """Fetch new Hacker News stories."""
    selected_format = _resolve_format(
        output_format=output_format,
        json_output=json_output,
        csv_output=csv_output,
    )

    try:
        stories = get_new(limit=limit, timeout=timeout)
    except HNApiError as exc:
        typer.echo(f"Error fetching new stories: {exc}", err=True)
        raise typer.Exit(code=1) from exc

    _render_story_output(
        stories=stories,
        selected_format=selected_format,
        output=output,
    )


@app.command()
def best(
    limit: Annotated[
        int,
        typer.Option(
            "--limit",
            "-n",
            min=1,
            max=100,
            help="Number of best stories to fetch.",
        ),
    ] = 10,
    output_format: Annotated[
        OutputFormat,
        typer.Option(
            "--format",
            help="Output format: human, json, or csv.",
            case_sensitive=False,
        ),
    ] = OutputFormat.HUMAN,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Shortcut for --format json."),
    ] = False,
    csv_output: Annotated[
        bool,
        typer.Option("--csv", help="Shortcut for --format csv."),
    ] = False,
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Write output to this file."),
    ] = None,
    timeout: Annotated[
        float,
        typer.Option("--timeout", min=0.1, help="HTTP timeout in seconds."),
    ] = 10.0,
) -> None:
    """Fetch best Hacker News stories."""
    selected_format = _resolve_format(
        output_format=output_format,
        json_output=json_output,
        csv_output=csv_output,
    )

    try:
        stories = get_best(limit=limit, timeout=timeout)
    except HNApiError as exc:
        typer.echo(f"Error fetching best stories: {exc}", err=True)
        raise typer.Exit(code=1) from exc

    _render_story_output(
        stories=stories,
        selected_format=selected_format,
        output=output,
    )


@app.command()
def item(
    item_id: Annotated[int, typer.Argument(help="Hacker News item ID.")],
    output_format: Annotated[
        OutputFormat,
        typer.Option(
            "--format",
            help="Output format: human, json, or csv.",
            case_sensitive=False,
        ),
    ] = OutputFormat.HUMAN,
    json_output: Annotated[
        bool,
        typer.Option("--json", help="Shortcut for --format json."),
    ] = False,
    csv_output: Annotated[
        bool,
        typer.Option("--csv", help="Shortcut for --format csv."),
    ] = False,
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Write output to this file."),
    ] = None,
    timeout: Annotated[
        float,
        typer.Option("--timeout", min=0.1, help="HTTP timeout in seconds."),
    ] = 10.0,
) -> None:
    """Fetch one Hacker News item by ID."""
    selected_format = _resolve_format(
        output_format=output_format,
        json_output=json_output,
        csv_output=csv_output,
    )

    try:
        item_data = get_item(item_id=item_id, timeout=timeout)
    except HNApiError as exc:
        typer.echo(f"Error fetching item {item_id}: {exc}", err=True)
        raise typer.Exit(code=1) from exc

    _render_item_output(
        item=item_data,
        selected_format=selected_format,
        output=output,
    )

