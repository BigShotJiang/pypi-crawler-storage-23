"""Stable public Python API for scripts and notebooks."""

from __future__ import annotations

from typing import Any

from hn_query.formatters import (
    item_to_csv as _item_to_csv,
)
from hn_query.formatters import (
    item_to_json as _item_to_json,
)
from hn_query.formatters import (
    to_csv as _stories_to_csv,
)
from hn_query.formatters import (
    to_json as _stories_to_json,
)
from hn_query.models import HNStory
from hn_query.services.hn_api import (
    HNApiError,
    fetch_best_stories,
    fetch_item_details,
    fetch_new_stories,
    fetch_top_stories,
)


def _validate_limit(limit: int) -> None:
    if limit < 1 or limit > 100:
        raise ValueError("limit must be between 1 and 100")


def _validate_timeout(timeout: float) -> None:
    if timeout <= 0:
        raise ValueError("timeout must be greater than 0")


def _validate_item_id(item_id: int) -> None:
    if item_id <= 0:
        raise ValueError("item_id must be greater than 0")


def get_top(limit: int = 10, timeout: float = 10.0) -> list[HNStory]:
    """Return top Hacker News stories."""
    _validate_limit(limit)
    _validate_timeout(timeout)
    return fetch_top_stories(limit=limit, timeout=timeout)


def get_new(limit: int = 10, timeout: float = 10.0) -> list[HNStory]:
    """Return new Hacker News stories."""
    _validate_limit(limit)
    _validate_timeout(timeout)
    return fetch_new_stories(limit=limit, timeout=timeout)


def get_best(limit: int = 10, timeout: float = 10.0) -> list[HNStory]:
    """Return best Hacker News stories."""
    _validate_limit(limit)
    _validate_timeout(timeout)
    return fetch_best_stories(limit=limit, timeout=timeout)


def get_item(item_id: int, timeout: float = 10.0) -> dict[str, Any]:
    """Return one Hacker News item."""
    _validate_item_id(item_id)
    _validate_timeout(timeout)
    return fetch_item_details(item_id=item_id, timeout=timeout)


def stories_to_json(stories: list[HNStory]) -> str:
    """Serialize stories to JSON."""
    return _stories_to_json(stories)


def stories_to_csv(stories: list[HNStory]) -> str:
    """Serialize stories to CSV."""
    return _stories_to_csv(stories)


def item_to_json(item: dict[str, Any]) -> str:
    """Serialize one item to JSON."""
    return _item_to_json(item)


def item_to_csv(item: dict[str, Any]) -> str:
    """Serialize one item to CSV."""
    return _item_to_csv(item)


__all__ = [
    "HNApiError",
    "get_best",
    "get_item",
    "get_new",
    "get_top",
    "item_to_csv",
    "item_to_json",
    "stories_to_csv",
    "stories_to_json",
]

