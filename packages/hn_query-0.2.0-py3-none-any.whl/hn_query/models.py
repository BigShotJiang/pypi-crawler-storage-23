"""Domain models for Hacker News data."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class HNStory:
    """A normalized Hacker News story item."""

    id: int
    title: str
    url: str
    score: int
    by: str
    time: int
    descendants: int
