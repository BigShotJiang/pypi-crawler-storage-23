"""External service clients used by the CLI."""

