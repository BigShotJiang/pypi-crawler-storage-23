"""Hacker News API client helpers."""

from __future__ import annotations

from typing import Any

import httpx

from hn_query.models import HNStory

API_BASE_URL = "https://hacker-news.firebaseio.com"


class HNApiError(Exception):
    """Raised when the Hacker News API cannot be read successfully."""


def _get_json(client: httpx.Client, path: str, timeout: float) -> Any:
    try:
        response = client.get(path, timeout=timeout)
        response.raise_for_status()
        return response.json()
    except (httpx.HTTPError, ValueError) as exc:
        raise HNApiError(f"Failed to fetch Hacker News API path: {path}") from exc


def _coerce_story(item: dict[str, Any]) -> HNStory:
    return HNStory(
        id=int(item.get("id", 0)),
        title=str(item.get("title", "(untitled story)")),
        url=str(item.get("url", "")),
        score=int(item.get("score", 0)),
        by=str(item.get("by", "(unknown)")),
        time=int(item.get("time", 0)),
        descendants=int(item.get("descendants", 0)),
    )


def _coerce_item(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": int(item.get("id", 0)),
        "type": str(item.get("type", "")),
        "title": str(item.get("title", "")),
        "text": str(item.get("text", "")),
        "url": str(item.get("url", "")),
        "score": int(item.get("score", 0)),
        "by": str(item.get("by", "")),
        "time": int(item.get("time", 0)),
        "comments": int(item.get("descendants", 0)),
        "parent": int(item.get("parent", 0)),
        "dead": bool(item.get("dead", False)),
        "deleted": bool(item.get("deleted", False)),
    }


def _fetch_top_story_ids(client: httpx.Client, timeout: float) -> list[int]:
    payload = _get_json(client, "/v0/topstories.json", timeout)
    if not isinstance(payload, list):
        raise HNApiError("Unexpected response for top stories.")

    story_ids: list[int] = []
    for item in payload:
        try:
            story_ids.append(int(item))
        except (TypeError, ValueError):
            continue
    return story_ids


def _fetch_new_story_ids(client: httpx.Client, timeout: float) -> list[int]:
    payload = _get_json(client, "/v0/newstories.json", timeout)
    if not isinstance(payload, list):
        raise HNApiError("Unexpected response for new stories.")

    story_ids: list[int] = []
    for item in payload:
        try:
            story_ids.append(int(item))
        except (TypeError, ValueError):
            continue
    return story_ids


def _fetch_best_story_ids(client: httpx.Client, timeout: float) -> list[int]:
    payload = _get_json(client, "/v0/beststories.json", timeout)
    if not isinstance(payload, list):
        raise HNApiError("Unexpected response for best stories.")

    story_ids: list[int] = []
    for item in payload:
        try:
            story_ids.append(int(item))
        except (TypeError, ValueError):
            continue
    return story_ids


def _fetch_item(client: httpx.Client, item_id: int, timeout: float) -> dict[str, Any]:
    payload = _get_json(client, f"/v0/item/{item_id}.json", timeout)
    if not isinstance(payload, dict):
        raise HNApiError(f"Unexpected response for item: {item_id}")
    return payload


def fetch_top_story_ids(timeout: float = 10.0) -> list[int]:
    """Return top story IDs from Hacker News."""
    with httpx.Client(base_url=API_BASE_URL) as client:
        return _fetch_top_story_ids(client, timeout)


def fetch_new_story_ids(timeout: float = 10.0) -> list[int]:
    """Return new story IDs from Hacker News."""
    with httpx.Client(base_url=API_BASE_URL) as client:
        return _fetch_new_story_ids(client, timeout)


def fetch_best_story_ids(timeout: float = 10.0) -> list[int]:
    """Return best story IDs from Hacker News."""
    with httpx.Client(base_url=API_BASE_URL) as client:
        return _fetch_best_story_ids(client, timeout)


def fetch_item(item_id: int, timeout: float = 10.0) -> dict[str, Any]:
    """Return one item payload from Hacker News."""
    with httpx.Client(base_url=API_BASE_URL) as client:
        return _fetch_item(client, item_id, timeout)


def fetch_item_details(item_id: int, timeout: float = 10.0) -> dict[str, Any]:
    """Return one normalized item payload from Hacker News."""
    with httpx.Client(base_url=API_BASE_URL) as client:
        item = _fetch_item(client, item_id, timeout)
    return _coerce_item(item)


def fetch_top_stories(limit: int = 10, timeout: float = 10.0) -> list[HNStory]:
    """Fetch and normalize top Hacker News stories."""
    with httpx.Client(base_url=API_BASE_URL) as client:
        ids = _fetch_top_story_ids(client, timeout)
        stories: list[HNStory] = []
        for story_id in ids[:limit]:
            item = _fetch_item(client, story_id, timeout)
            stories.append(_coerce_story(item))
        return stories


def fetch_new_stories(limit: int = 10, timeout: float = 10.0) -> list[HNStory]:
    """Fetch and normalize new Hacker News stories."""
    with httpx.Client(base_url=API_BASE_URL) as client:
        ids = _fetch_new_story_ids(client, timeout)
        stories: list[HNStory] = []
        for story_id in ids[:limit]:
            item = _fetch_item(client, story_id, timeout)
            stories.append(_coerce_story(item))
        return stories


def fetch_best_stories(limit: int = 10, timeout: float = 10.0) -> list[HNStory]:
    """Fetch and normalize best Hacker News stories."""
    with httpx.Client(base_url=API_BASE_URL) as client:
        ids = _fetch_best_story_ids(client, timeout)
        stories: list[HNStory] = []
        for story_id in ids[:limit]:
            item = _fetch_item(client, story_id, timeout)
            stories.append(_coerce_story(item))
        return stories

