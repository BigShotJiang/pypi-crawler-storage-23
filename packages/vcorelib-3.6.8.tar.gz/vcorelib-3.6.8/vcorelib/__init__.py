# =====================================
# generator=datazen
# version=3.2.3
# hash=7593af82eeac476529579fe64e6b247e
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "A collection of core Python utilities."
PKG_NAME = "vcorelib"
VERSION = "3.6.8"

# vcorelib-specific content.
DEFAULT_INDENT = 2
DEFAULT_ENCODING = "utf-8"
