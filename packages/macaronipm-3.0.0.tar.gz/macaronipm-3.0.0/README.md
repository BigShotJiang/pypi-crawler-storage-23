# MacaroniPM | A PenguinMod API wrapper

## Instalation

You can download the latest version of macaronipm via `pip install macaronipm`

## New functions

`macaronipm.user.UserExist()`

`macaronipm.user.IsBanned()`

`macaronipm.user.logout()`

`macaronipm.user.GetMessages()`

`macaronipm.user.getUnreadMessages()`

`macaronipm.IsOnline()`

`macaronipm.project.hasLovedVoted()`
