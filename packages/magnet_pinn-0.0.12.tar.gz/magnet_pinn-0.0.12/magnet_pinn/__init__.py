"""
    A deep learning package for predicting EM fields in a MRI scanner. Contains models, preprocessing, and evaluation tools.
"""