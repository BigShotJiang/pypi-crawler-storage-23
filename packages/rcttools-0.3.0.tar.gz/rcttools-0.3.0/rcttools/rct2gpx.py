import logging
import os.path
import subprocess
import sys
from datetime import datetime, timezone
from decimal import Decimal
from typing import Dict, List, Tuple

import exif  # type: ignore[import-untyped]
import ffmpeg  # type: ignore[import-untyped]
import numpy as np
import pandas as pd
from gpxpy.gpx import GPX, GPXTrack, GPXTrackPoint, GPXTrackSegment
from PIL import Image

from .alphabet import NUMBERS, NUMBERS_SHAPE
from .common import (
    CHAR_WIDTHS,
    FLOAT_FRAME_TYPE,
    FLOAT_VIDEO_TYPE,
    VIDEO_TYPE,
    calc_bearing,
    dec_to_dms,
)
from .errors import UnsupportedVideoResolutionError
from .text_format import EmbeddedData, StateMachine


class EmbeddedAndDerivedData(EmbeddedData):
    heading: Decimal | None


class OutputType:
    GPX = "gpx"
    CSV = "csv"
    DATA_STACKED_FRAMES = "data_stacked_frames"
    FULL_FRAMES = "full_frames"


def get_ffmpeg_version() -> List[int]:
    try:
        out = subprocess.check_output(["ffmpeg", "-version"], stderr=subprocess.STDOUT)
        version_line = (
            out.decode().splitlines()[0].replace("ffmpeg version ", "").split()[0]
        )
        version_parts = version_line.split(".")
        return [int(part) for part in version_parts]
    except Exception as e:
        logging.error(f"Error getting FFmpeg version: {e}")
        return [0, 0, 0]  # Default to a very old version if we can't determine it


def transcode(mp4_path: str) -> VIDEO_TYPE:
    """
    Transcode an MP4 video file to extract the region with data.

    Currently assumes 1080p video.
    """
    height = 40
    width = 1450
    rate = "29.97"
    mp4 = ffmpeg.input(mp4_path, r=rate)
    trimmed = mp4.filter("crop", w=width, h=height, x=0, y=1035)
    white = ffmpeg.input(f"color=white:s={width}x{height}:r={rate}", f="lavfi")
    black = ffmpeg.input(f"color=black:s={width}x{height}:r={rate}", f="lavfi")
    try:
        out, _ = (
            ffmpeg.filter([trimmed, white, white, black], "threshold")
            .output("pipe:", format="rawvideo", pix_fmt="rgb24")
            .run(capture_stdout=True, quiet=True)
        )
    except ffmpeg.Error:
        r = ffmpeg.probe(
            mp4_path,
            v="error",
            select_streams="v:0",
            show_entries="stream=width,height",
            of="json",
        )
        stream_data = r["streams"][0]
        if stream_data["width"] != 1920 or stream_data["height"] != 1080:
            raise UnsupportedVideoResolutionError(
                f"Unexpected video resolution {stream_data['width']}x{stream_data['height']}. "
                "This tool currently only supports 1080p video."
            )
        raise
    return np.frombuffer(out, np.uint8).reshape([-1, height, width, 3])


def extract_full_frames(
    mp4_path: str, results: Dict[int, EmbeddedAndDerivedData], output_dir: str
) -> None:
    basename = os.path.basename(mp4_path).rsplit(".", 1)[0]
    output_dir = os.path.join(output_dir, basename)
    frame_nums = sorted(results.keys())
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)
    out, err = (
        ffmpeg.input(mp4_path)
        .filter("select", "+".join(f"eq(n,{x})" for x in frame_nums))
        .output(
            os.path.join(output_dir, "frames%02d.jpg"),
            vframes=len(frame_nums),
            format="image2",
            vcodec="mjpeg",
            vsync=0,
        )
        .run(capture_stdout=True, quiet=True)
    )
    for i, frame in enumerate(frame_nums):
        data = results[frame]

        input_path = os.path.join(output_dir, f"frames{str(i + 1).zfill(2)}.jpg")
        output_path = os.path.join(
            output_dir, data["datetime"].strftime("%Y%m%d_%H%M%S.jpg")
        )
        with open(input_path, "rb") as f:
            img = exif.Image(f.read())

        img.datetime_original = data["datetime"].strftime(exif.DATETIME_STR_FORMAT)

        lat = data["latitude"]
        if lat:
            lat_dms = dec_to_dms(lat)
            img.gps_latitude = lat_dms
            img.gps_latitude_ref = "N" if lat >= 0 else "S"

        lon = data["longitude"]
        if lon:
            lon_dms = dec_to_dms(lon)
            img.gps_longitude = lon_dms
            img.gps_longitude_ref = "E" if lon >= 0 else "W"

        heading = data["heading"]
        if heading is not None:
            img.gps_img_direction = float(heading)
            img.gps_img_direction_ref = "T"

        with open(output_path, "wb") as f:
            f.write(img.get_file())
        os.remove(input_path)


def fast_parse(
    mp4_path: str, write_stacked_frames: bool = False, output_directory: str = ""
) -> Tuple[dict[int, EmbeddedData], "pd.Series[float]"]:
    alphabet = NUMBERS

    if not os.path.exists(mp4_path):
        raise FileNotFoundError(f"Input file not found: {mp4_path}")

    video = transcode(mp4_path)

    start_time = datetime.now(timezone.utc)

    y_offsets = {0: StateMachine(), -1: StateMachine(True)}
    seconds_digit_video: Dict[int, FLOAT_VIDEO_TYPE] = {
        y_offset: 1
        - (
            video[:, (5 + y_offset) : (35 + y_offset), 561 : 561 + NUMBERS_SHAPE[1]]
            / 255.0
        )
        for y_offset in y_offsets
    }

    change_scores: Dict[
        int, Dict[str, np.ndarray[Tuple[int], np.dtype[np.float32]]]
    ] = {}
    best_average = 0.0
    change_df = pd.DataFrame()
    selected_y = 0
    for y in y_offsets:
        change_scores[y] = {}
        for letter in alphabet:
            change_scores[y][letter] = alphabet[letter].score_video(
                seconds_digit_video[y]
            )

        current_df = pd.DataFrame(change_scores[y])
        current_average = current_df.max(axis=1).mean()
        if current_average > best_average:
            change_df = current_df
            best_average = current_average
            selected_y = y

    best_fit = change_df.idxmax(axis=1)

    changes = best_fit[best_fit != best_fit.shift(1)].index
    change_max = change_df.max(axis=1)

    ranges: List[Tuple[int, int]] = []
    for i in range(len(changes) - 1):
        if change_max[i] > 0.4:
            ranges.append((changes[i], changes[i + 1]))
    ranges.append((changes[-1], len(video)))

    stacked_frames: Dict[int, FLOAT_FRAME_TYPE] = {}
    for r in ranges:
        stacked_frames[r[0]] = video[r[0] : r[1]].mean(axis=0)
        if write_stacked_frames:
            path = os.path.join(output_directory, f"data_{r[0]}.png")
            Image.fromarray(stacked_frames[r[0]].astype(np.uint8)).save(path)

    result, summary_stats = parsed_stacked_frames(
        y_offsets[selected_y], selected_y, stacked_frames
    )

    end_time = datetime.now(timezone.utc)
    duration = (end_time - start_time).total_seconds()
    logging.info(f"Parsed {len(video)} frames in {duration:.2f} seconds")

    return result, summary_stats


def parsed_stacked_frames(
    state_machine: StateMachine,
    selected_y: int,
    stacked_frames: Dict[int, FLOAT_FRAME_TYPE],
) -> Tuple[Dict[int, EmbeddedData], "pd.Series[float]"]:

    result: Dict[int, EmbeddedData] = {}
    summary_stats: Dict[int, float] = {}
    for frame_index, stacked_frame in stacked_frames.items():
        chars: List[str] = []
        best_scores: List[float] = []

        frame_failed = False

        while not state_machine.is_complete():
            alphabet = state_machine.get_alphabet()
            if alphabet == {}:
                continue
            offset = state_machine.get_next_offset()
            offset_frame = {
                width: (
                    1
                    - (
                        stacked_frame[
                            (5 + selected_y) : (35 + selected_y),
                            offset : offset + width,
                        ]
                        / 255.0
                    )
                )
                for width in set(CHAR_WIDTHS[x] for x in alphabet.keys())
            }
            scores = {
                letter: alphabet[letter].score_frame(offset_frame[CHAR_WIDTHS[letter]])
                for letter in alphabet
            }
            max_score = 0.0
            max_letter = ""
            for letter, score in scores.items():
                if score > max_score:
                    max_score = score
                    max_letter = letter

            if max_score >= 0.5:
                state_machine.append(max_letter)
                chars.append(max_letter)
                best_scores.append(max_score)
            else:
                frame_failed = True
                break

        if not frame_failed:
            result[int(frame_index)] = state_machine.result()
            summary_stats[int(frame_index)] = pd.Series(best_scores).mean()
        state_machine.reset()

    return result, pd.Series(summary_stats)


def add_heading(
    embedded_data: Dict[int, EmbeddedData],
) -> Dict[int, EmbeddedAndDerivedData]:
    result: Dict[int, EmbeddedAndDerivedData] = {}
    keys = sorted(embedded_data.keys())
    if len(keys) == 0:
        return result
    heading: Decimal | None = None
    for i in range(len(keys) - 1):
        data1 = embedded_data[keys[i]]
        data2 = embedded_data[keys[i + 1]]
        lat1 = data1["latitude"]
        lon1 = data1["longitude"]
        lat2 = data2["latitude"]
        lon2 = data2["longitude"]

        value = EmbeddedAndDerivedData(heading=None, **data1)
        if (
            lat1 is not None
            and lon1 is not None
            and lat2 is not None
            and lon2 is not None
        ):
            # Heading will be None if points are identical
            heading = calc_bearing(lat1, lon1, lat2, lon2)
            value["heading"] = heading

        result[keys[i]] = value

    result[keys[-1]] = EmbeddedAndDerivedData(
        heading=heading, **embedded_data[keys[-1]]
    )

    heading = None
    for i in range(len(keys)):
        # Propagate last known, non-null heading forward
        heading_temp = result[keys[i]]["heading"]
        if heading_temp is not None:
            # Assume RCT715 is mounted backwards
            heading = (heading_temp + Decimal(180)) % 360
        result[keys[i]]["heading"] = heading

    return result


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(
        description="Extract GPX data embedded in MP4 video files from Garmin Varia RCT715 devices",
    )
    parser.add_argument("mp4_path", type=str)
    parser.add_argument(
        "--types",
        action="append",
        help=(
            "Types of output to generate - gpx: GPX file, csv: CSV file, "
            "data_stacked_frames: Stacked frames of data region, full_frames: "
            "Full frames corresponding to data updates with EXIF data tags. "
            "If not specified, defaults to gpx"
        ),
        type=str,
        choices=[
            OutputType.GPX,
            OutputType.CSV,
            OutputType.DATA_STACKED_FRAMES,
            OutputType.FULL_FRAMES,
        ],
    )
    parser.add_argument(
        "--output-directory",
        type=str,
        default="",
        help="Directory to save output files",
    )
    parser.add_argument(
        "--show-stats",
        action="store_true",
        help="Show summary statistics for alphabet fit debugging",
    )
    parser.add_argument("--verbose", action="store_true", help="Enable verbose logging")

    ffmpeg_version = get_ffmpeg_version()
    if ffmpeg_version[0] < 7:
        print(
            f"FFmpeg version 7 or higher is required, but version {'.'.join(map(str, ffmpeg_version))} was found",
            file=sys.stderr,
        )
        sys.exit(1)
        return

    args = parser.parse_args()
    types = args.types or [OutputType.GPX]

    mp4_path = args.mp4_path
    prefix = os.path.dirname(mp4_path)
    if args.output_directory:
        prefix = args.output_directory
    basename = os.path.basename(mp4_path).rsplit(".", 1)[0]
    csv = OutputType.CSV in types
    gpx = OutputType.GPX in types
    full_frames = OutputType.FULL_FRAMES in types
    show_stats = args.show_stats
    if args.verbose:
        logging.basicConfig(level=logging.INFO)
    else:
        logging.basicConfig(level=logging.WARNING)
    try:
        embedded_data, summary_stats = fast_parse(
            mp4_path,
            write_stacked_frames=OutputType.DATA_STACKED_FRAMES in types,
            output_directory=prefix,
        )
    except FileNotFoundError as e:
        print(e, file=sys.stderr)
        sys.exit(2)
        return
    except UnsupportedVideoResolutionError as e:
        print(e, file=sys.stderr)
        sys.exit(3)
        return
    result = add_heading(embedded_data)

    if show_stats or args.verbose:
        output_func = print if not args.verbose else logging.info
        output_func(f"Summary statistics for {mp4_path}:")
        stats = summary_stats.to_frame(name="goodness_of_fit")
        stats.index.name = "frame_index"
        output_func(stats)

    if csv:
        df = pd.DataFrame.from_dict(result, orient="index")
        df.index.name = "frame_index"
        csv_path = os.path.join(prefix, f"{basename}.csv")
        df.to_csv(csv_path)

    if gpx:
        gpx_obj = GPX()
        track = GPXTrack()
        gpx_obj.tracks.append(track)
        segment = GPXTrackSegment()
        track.segments.append(segment)

        for frame_index in sorted(result.keys()):
            data = result[frame_index]
            if data["latitude"] is not None and data["longitude"] is not None:
                segment.points.append(
                    GPXTrackPoint(
                        latitude=float(data["latitude"]),
                        longitude=float(data["longitude"]),
                        time=data["datetime"],
                    )
                )
        gpx_path = os.path.join(prefix, f"{basename}.gpx")
        with open(gpx_path, "w") as f:
            f.write(gpx_obj.to_xml(version="1.1"))

    if full_frames:
        extract_full_frames(mp4_path, result, prefix)


if __name__ == "__main__":
    main()
