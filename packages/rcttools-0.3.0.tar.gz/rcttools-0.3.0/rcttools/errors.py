class UnsupportedVideoResolutionError(Exception):
    """Raised when the video resolution is not supported."""

    pass
