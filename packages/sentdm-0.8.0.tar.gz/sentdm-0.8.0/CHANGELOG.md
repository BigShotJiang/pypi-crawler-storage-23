# Changelog

## 0.8.0 (2026-02-18)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/sentdm/sent-dm-python/compare/v0.7.0...v0.8.0)

### Features

* **api:** manual updates ([360738f](https://github.com/sentdm/sent-dm-python/commit/360738fed511bd249fb75d9c1c263c28964a0e15))
* **api:** manual updates ([3635da5](https://github.com/sentdm/sent-dm-python/commit/3635da501ca023b5fe35f55946189a84933a9c54))
* **api:** manual updates ([c839787](https://github.com/sentdm/sent-dm-python/commit/c839787873794ed14357133cdc4eea6b97bbe422))

## 0.7.0 (2026-02-16)

Full Changelog: [v0.6.2...v0.7.0](https://github.com/sentdm/sent-dm-python/compare/v0.6.2...v0.7.0)

### Features

* **api:** manual updates ([cfc1149](https://github.com/sentdm/sent-dm-python/commit/cfc1149490464e063d4b8e5240615b265ee1e1f3))

## 0.6.2 (2026-02-16)

Full Changelog: [v0.6.1...v0.6.2](https://github.com/sentdm/sent-dm-python/compare/v0.6.1...v0.6.2)

### Chores

* format all `api.md` files ([0487ff9](https://github.com/sentdm/sent-dm-python/commit/0487ff9ccc71444812022cfc0ab63bc7359d85d2))

## 0.6.1 (2026-02-12)

Full Changelog: [v0.6.0...v0.6.1](https://github.com/sentdm/sent-dm-python/compare/v0.6.0...v0.6.1)

### Chores

* **internal:** fix lint error on Python 3.14 ([ad77df0](https://github.com/sentdm/sent-dm-python/commit/ad77df0f31ffcb2a91ec062c64f06d9c3b784050))

## 0.6.0 (2026-02-12)

Full Changelog: [v0.5.1...v0.6.0](https://github.com/sentdm/sent-dm-python/compare/v0.5.1...v0.6.0)

### Features

* **api:** api update ([2fca748](https://github.com/sentdm/sent-dm-python/commit/2fca74838491701a13972a88ea35b15fa993c78c))

## 0.5.1 (2026-02-10)

Full Changelog: [v0.5.0...v0.5.1](https://github.com/sentdm/sent-dm-python/compare/v0.5.0...v0.5.1)

### Chores

* **internal:** bump dependencies ([2ad24e0](https://github.com/sentdm/sent-dm-python/commit/2ad24e0e1c74d4706996b0fa5ae648e236c5c5b7))

## 0.5.0 (2026-01-30)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/sentdm/sent-dm-python/compare/v0.4.0...v0.5.0)

### Features

* **client:** add custom JSON encoder for extended type support ([f307d02](https://github.com/sentdm/sent-dm-python/commit/f307d02dc15c86ea022ff03b2e3d7583a9a0a56a))

## 0.4.0 (2026-01-28)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/sentdm/sent-dm-python/compare/v0.3.0...v0.4.0)

### Features

* **api:** manual updates ([d514396](https://github.com/sentdm/sent-dm-python/commit/d514396d49b8b0988207dbb2135fb9fbc52407fd))

## 0.3.0 (2026-01-28)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/sentdm/sent-dm-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** manual updates ([e02db1d](https://github.com/sentdm/sent-dm-python/commit/e02db1d8c3d8a1626bb6b34330e6c5a182b2bd4a))

## 0.2.0 (2026-01-27)

Full Changelog: [v0.1.1...v0.2.0](https://github.com/sentdm/sent-dm-python/compare/v0.1.1...v0.2.0)

### Features

* **api:** manual updates ([b88b8e4](https://github.com/sentdm/sent-dm-python/commit/b88b8e4f6d42e4699c8a4f3e7f4065e742353820))

## 0.1.1 (2026-01-27)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/sentdm/sent-dm-python/compare/v0.1.0...v0.1.1)

### Chores

* update SDK settings ([a712995](https://github.com/sentdm/sent-dm-python/commit/a712995ce16452fd8e30e519a766796c486370fa))

## 0.1.0 (2026-01-27)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/sentdm/sent-dm-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([5c655ad](https://github.com/sentdm/sent-dm-python/commit/5c655ad2d463283deb5857982bd52dc302f390aa))


### Chores

* update SDK settings ([ece63ca](https://github.com/sentdm/sent-dm-python/commit/ece63ca4e3e9228669d69b891b275da09e6e88d4))
