# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..types import message_send_params
from .._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from .._utils import maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.message_send_response import MessageSendResponse
from ..types.message_retrieve_status_response import MessageRetrieveStatusResponse
from ..types.message_retrieve_activities_response import MessageRetrieveActivitiesResponse

__all__ = ["MessagesResource", "AsyncMessagesResource"]


class MessagesResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> MessagesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/sentdm/sent-dm-python#accessing-raw-response-data-eg-headers
        """
        return MessagesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> MessagesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/sentdm/sent-dm-python#with_streaming_response
        """
        return MessagesResourceWithStreamingResponse(self)

    def retrieve_activities(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MessageRetrieveActivitiesResponse:
        """Retrieves the activity log for a specific message.

        Activities track the message
        lifecycle including acceptance, processing, sending, delivery, and any errors.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/v3/messages/{id}/activities",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MessageRetrieveActivitiesResponse,
        )

    def retrieve_status(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MessageRetrieveStatusResponse:
        """Retrieves the current status and details of a message by ID.

        Includes delivery
        status, timestamps, and error information if applicable.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/v3/messages/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MessageRetrieveStatusResponse,
        )

    def send(
        self,
        *,
        channel: Optional[SequenceNotStr[str]] | Omit = omit,
        template: message_send_params.Template | Omit = omit,
        test_mode: bool | Omit = omit,
        to: SequenceNotStr[str] | Omit = omit,
        idempotency_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MessageSendResponse:
        """Sends a message to one or more recipients using a template.

        Supports
        multi-channel broadcast — when multiple channels are specified (e.g. ["sms",
        "whatsapp"]), a separate message is created for each (recipient, channel) pair.
        Returns immediately with per-recipient message IDs for async tracking via
        webhooks or the GET /messages/{id} endpoint.

        Args:
          channel: Channels to broadcast on, e.g. ["whatsapp", "sms"]. Each channel produces a
              separate message per recipient. "sent" = auto-detect, "rcs" = reserved
              (skipped). Defaults to ["sent"] (auto-detect) if omitted.

          template: Template reference (by id or name, with optional parameters)

          test_mode: Test mode flag - when true, the operation is simulated without side effects
              Useful for testing integrations without actual execution

          to: List of recipient phone numbers in E.164 format (multi-recipient fan-out)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Idempotency-Key": idempotency_key}), **(extra_headers or {})}
        return self._post(
            "/v3/messages",
            body=maybe_transform(
                {
                    "channel": channel,
                    "template": template,
                    "test_mode": test_mode,
                    "to": to,
                },
                message_send_params.MessageSendParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MessageSendResponse,
        )


class AsyncMessagesResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncMessagesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/sentdm/sent-dm-python#accessing-raw-response-data-eg-headers
        """
        return AsyncMessagesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncMessagesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/sentdm/sent-dm-python#with_streaming_response
        """
        return AsyncMessagesResourceWithStreamingResponse(self)

    async def retrieve_activities(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MessageRetrieveActivitiesResponse:
        """Retrieves the activity log for a specific message.

        Activities track the message
        lifecycle including acceptance, processing, sending, delivery, and any errors.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/v3/messages/{id}/activities",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MessageRetrieveActivitiesResponse,
        )

    async def retrieve_status(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MessageRetrieveStatusResponse:
        """Retrieves the current status and details of a message by ID.

        Includes delivery
        status, timestamps, and error information if applicable.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/v3/messages/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MessageRetrieveStatusResponse,
        )

    async def send(
        self,
        *,
        channel: Optional[SequenceNotStr[str]] | Omit = omit,
        template: message_send_params.Template | Omit = omit,
        test_mode: bool | Omit = omit,
        to: SequenceNotStr[str] | Omit = omit,
        idempotency_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MessageSendResponse:
        """Sends a message to one or more recipients using a template.

        Supports
        multi-channel broadcast — when multiple channels are specified (e.g. ["sms",
        "whatsapp"]), a separate message is created for each (recipient, channel) pair.
        Returns immediately with per-recipient message IDs for async tracking via
        webhooks or the GET /messages/{id} endpoint.

        Args:
          channel: Channels to broadcast on, e.g. ["whatsapp", "sms"]. Each channel produces a
              separate message per recipient. "sent" = auto-detect, "rcs" = reserved
              (skipped). Defaults to ["sent"] (auto-detect) if omitted.

          template: Template reference (by id or name, with optional parameters)

          test_mode: Test mode flag - when true, the operation is simulated without side effects
              Useful for testing integrations without actual execution

          to: List of recipient phone numbers in E.164 format (multi-recipient fan-out)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Idempotency-Key": idempotency_key}), **(extra_headers or {})}
        return await self._post(
            "/v3/messages",
            body=await async_maybe_transform(
                {
                    "channel": channel,
                    "template": template,
                    "test_mode": test_mode,
                    "to": to,
                },
                message_send_params.MessageSendParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MessageSendResponse,
        )


class MessagesResourceWithRawResponse:
    def __init__(self, messages: MessagesResource) -> None:
        self._messages = messages

        self.retrieve_activities = to_raw_response_wrapper(
            messages.retrieve_activities,
        )
        self.retrieve_status = to_raw_response_wrapper(
            messages.retrieve_status,
        )
        self.send = to_raw_response_wrapper(
            messages.send,
        )


class AsyncMessagesResourceWithRawResponse:
    def __init__(self, messages: AsyncMessagesResource) -> None:
        self._messages = messages

        self.retrieve_activities = async_to_raw_response_wrapper(
            messages.retrieve_activities,
        )
        self.retrieve_status = async_to_raw_response_wrapper(
            messages.retrieve_status,
        )
        self.send = async_to_raw_response_wrapper(
            messages.send,
        )


class MessagesResourceWithStreamingResponse:
    def __init__(self, messages: MessagesResource) -> None:
        self._messages = messages

        self.retrieve_activities = to_streamed_response_wrapper(
            messages.retrieve_activities,
        )
        self.retrieve_status = to_streamed_response_wrapper(
            messages.retrieve_status,
        )
        self.send = to_streamed_response_wrapper(
            messages.send,
        )


class AsyncMessagesResourceWithStreamingResponse:
    def __init__(self, messages: AsyncMessagesResource) -> None:
        self._messages = messages

        self.retrieve_activities = async_to_streamed_response_wrapper(
            messages.retrieve_activities,
        )
        self.retrieve_status = async_to_streamed_response_wrapper(
            messages.retrieve_status,
        )
        self.send = async_to_streamed_response_wrapper(
            messages.send,
        )
