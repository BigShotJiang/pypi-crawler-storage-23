# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["UserInviteParams"]


class UserInviteParams(TypedDict, total=False):
    email: str
    """User email address (required)"""

    name: str
    """User full name (required)"""

    role: str
    """User role: admin, billing, or developer (required)"""

    test_mode: bool
    """
    Test mode flag - when true, the operation is simulated without side effects
    Useful for testing integrations without actual execution
    """

    idempotency_key: Annotated[str, PropertyInfo(alias="Idempotency-Key")]
