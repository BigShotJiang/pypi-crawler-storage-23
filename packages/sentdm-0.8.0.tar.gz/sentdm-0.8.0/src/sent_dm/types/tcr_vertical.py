# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["TcrVertical"]

TcrVertical: TypeAlias = Literal[
    "PROFESSIONAL",
    "REAL_ESTATE",
    "HEALTHCARE",
    "HUMAN_RESOURCES",
    "ENERGY",
    "ENTERTAINMENT",
    "RETAIL",
    "TRANSPORTATION",
    "AGRICULTURE",
    "INSURANCE",
    "POSTAL",
    "EDUCATION",
    "HOSPITALITY",
    "FINANCIAL",
    "POLITICAL",
    "GAMBLING",
    "LEGAL",
    "CONSTRUCTION",
    "NGO",
    "MANUFACTURING",
    "GOVERNMENT",
    "TECHNOLOGY",
    "COMMUNICATION",
]
