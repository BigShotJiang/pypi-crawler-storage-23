"""Config checker package - make CLI runnable with python -m."""

from unique_toolkit._common.config_checker.cli import cli

if __name__ == "__main__":
    cli()
