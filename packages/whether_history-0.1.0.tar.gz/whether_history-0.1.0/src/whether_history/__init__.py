from .data_aggregator import OpenMeteoWhetherDataAggregator
from .whether import Whether

__all__ = [
    "Whether",
]
