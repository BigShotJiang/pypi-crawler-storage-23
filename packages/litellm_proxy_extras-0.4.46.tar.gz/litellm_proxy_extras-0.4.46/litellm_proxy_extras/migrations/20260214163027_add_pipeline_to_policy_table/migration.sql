-- AlterTable
ALTER TABLE "LiteLLM_PolicyTable" ADD COLUMN     "pipeline" JSONB;

