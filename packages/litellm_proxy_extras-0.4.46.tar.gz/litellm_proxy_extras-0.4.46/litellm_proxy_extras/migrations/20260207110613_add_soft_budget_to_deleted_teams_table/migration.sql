-- AlterTable
ALTER TABLE "LiteLLM_DeletedTeamTable" ADD COLUMN     "soft_budget" DOUBLE PRECISION;

