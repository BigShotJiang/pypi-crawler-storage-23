"""Shared LLM error types."""

from __future__ import annotations


class ClaudePipeError(Exception):
    """Generic LLM execution error (backward-compatible name)."""

    pass


class BackendNotAvailable(ClaudePipeError):
    """Raised when the requested backend cannot be used."""

    pass


class CapabilityError(ClaudePipeError):
    """Raised when the selected backend lacks required capabilities."""

    pass


class BackendTimeoutError(ClaudePipeError):
    """Raised when a backend times out. Not retriable — a different backend
    would silently change model behavior for the same prompt."""

    pass


class LLMPausedError(ClaudePipeError):
    """Raised when LLM calls are paused via `hive privacy on`."""

    pass
