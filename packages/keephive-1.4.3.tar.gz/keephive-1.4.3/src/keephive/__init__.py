"""keephive: a knowledge sidecar for Claude Code."""

__version__ = "1.4.3"
