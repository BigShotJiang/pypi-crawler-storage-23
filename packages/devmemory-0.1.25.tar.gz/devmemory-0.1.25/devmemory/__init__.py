__version__ = "0.1.25"
__app_name__ = "devmemory"
