"""Tests for the preduce API client."""

import pytest
from unittest.mock import patch, MagicMock
from preduce import compress, CompressResult


class TestCompress:
    def test_empty_text_raises(self):
        with pytest.raises(ValueError, match="empty"):
            compress("", api_key="test-key")

    def test_whitespace_text_raises(self):
        with pytest.raises(ValueError, match="empty"):
            compress("   ", api_key="test-key")

    def test_invalid_category_raises(self):
        with pytest.raises(ValueError, match="Invalid category"):
            compress("hello", api_key="test-key", category="INVALID")

    def test_valid_categories_accepted(self):
        for cat in ["GENERAL", "FINANCIAL", "MEDICAL", "CODE",
                     "general", "financial", "medical", "code"]:
            # Should not raise ValueError for category
            # (will fail on network, but that's fine — we're testing validation)
            with pytest.raises((ConnectionError, RuntimeError, OSError)):
                compress("hello", api_key="test-key", category=cat,
                         api_url="http://localhost:99999/compress", timeout=1)

    @patch("preduce.client.requests.post")
    def test_successful_compress(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "compressed_text": "compressed output",
            "category": "GENERAL",
            "original_tokens": 100,
            "compressed_tokens": 50,
            "stats": {
                "char_reduction_pct": 45.2,
                "token_reduction_pct": 50.0,
            },
        }
        mock_post.return_value = mock_resp

        result = compress("some text here", api_key="test-key")

        assert isinstance(result, CompressResult)
        assert result.compressed_text == "compressed output"
        assert result.category == "GENERAL"
        assert result.original_tokens == 100
        assert result.compressed_tokens == 50
        assert result.token_reduction_pct == 50.0
        assert result.char_reduction_pct == 45.2

    @patch("preduce.client.requests.post")
    def test_sends_category(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "compressed_text": "out",
            "category": "FINANCIAL",
            "original_tokens": 10,
            "compressed_tokens": 5,
            "stats": {},
        }
        mock_post.return_value = mock_resp

        compress("text", api_key="key", category="FINANCIAL")

        call_kwargs = mock_post.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert payload["category"] == "FINANCIAL"

    @patch("preduce.client.requests.post")
    def test_sends_api_key_in_payload(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "compressed_text": "out",
            "category": "GENERAL",
            "original_tokens": 10,
            "compressed_tokens": 5,
            "stats": {},
        }
        mock_post.return_value = mock_resp

        compress("text", api_key="my-secret-key")

        call_kwargs = mock_post.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert payload["api_key"] == "my-secret-key"

    @patch("preduce.client.requests.post")
    def test_403_raises_permission_error(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.status_code = 403
        mock_post.return_value = mock_resp

        with pytest.raises(PermissionError, match="Invalid API key"):
            compress("text", api_key="bad-key")

    @patch("preduce.client.requests.post")
    def test_402_raises_permission_error(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.status_code = 402
        mock_post.return_value = mock_resp

        with pytest.raises(PermissionError, match="quota exceeded"):
            compress("text", api_key="key")

    @patch("preduce.client.requests.post")
    def test_500_raises_runtime_error(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.status_code = 500
        mock_resp.text = "Internal Server Error"
        mock_post.return_value = mock_resp

        with pytest.raises(RuntimeError, match="500"):
            compress("text", api_key="key")

    @patch("preduce.client.requests.post")
    def test_to_dict(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "compressed_text": "out",
            "category": "GENERAL",
            "original_tokens": 10,
            "compressed_tokens": 5,
            "stats": {"token_reduction_pct": 50.0},
        }
        mock_post.return_value = mock_resp

        result = compress("text", api_key="key")
        d = result.to_dict()

        assert isinstance(d, dict)
        assert d["compressed_text"] == "out"
        assert d["category"] == "GENERAL"
        assert d["stats"]["token_reduction_pct"] == 50.0
