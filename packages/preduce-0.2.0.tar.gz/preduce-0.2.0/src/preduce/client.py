"""
preduce.client — Lightweight API client for the Preduce compression service.

No heavy dependencies. Just sends text to the API and returns structured results.
"""

import requests
from dataclasses import dataclass, asdict
from typing import Optional, Dict, Any

DEFAULT_API_URL = "https://preduce.dev/compress"

VALID_CATEGORIES = {"GENERAL", "FINANCIAL", "MEDICAL", "CODE", "ACADEMIC", "SUPPORT", "MARKETING"}


@dataclass
class CompressResult:
    """Result of a compression operation.

    Attributes:
        compressed_text: The compressed output text.
        category: Detected or overridden category (GENERAL, FINANCIAL, MEDICAL, CODE, ACADEMIC, SUPPORT, MARKETING).
        original_tokens: Estimated token count of the original text.
        compressed_tokens: Estimated token count of the compressed text.
        stats: Dictionary with detailed reduction metrics.
    """
    compressed_text: str
    category: str
    original_tokens: int
    compressed_tokens: int
    stats: Dict[str, Any]

    @property
    def token_reduction_pct(self) -> float:
        """Percentage of tokens reduced."""
        return self.stats.get("token_reduction_pct", 0.0)

    @property
    def char_reduction_pct(self) -> float:
        """Percentage of characters reduced."""
        return self.stats.get("char_reduction_pct", 0.0)

    def to_dict(self) -> dict:
        """Convert to a plain dictionary."""
        return asdict(self)


def compress(
    text: str,
    api_key: str,
    *,
    category: Optional[str] = None,
    api_url: str = DEFAULT_API_URL,
    timeout: int = 30,
) -> CompressResult:
    """
    Compress text via the Preduce API.

    Sends text to the Preduce compression service and returns the compressed
    result. The API auto-classifies text into the optimal category (GENERAL,
    FINANCIAL, MEDICAL, CODE) unless you override it.

    Args:
        text: The text to compress.
        api_key: Your Preduce API key.
        category: Optional category override. One of: GENERAL, FINANCIAL,
            MEDICAL, CODE, ACADEMIC, SUPPORT, MARKETING. If omitted, the API auto-detects.
        api_url: Custom API endpoint (default: Preduce cloud).
        timeout: Request timeout in seconds (default: 30).

    Returns:
        CompressResult with compressed text, category, and stats.

    Raises:
        ValueError: If text is empty or category is invalid.
        PermissionError: If API key is invalid or quota exceeded.
        RuntimeError: If the API returns an error.
        requests.ConnectionError: If the API is unreachable.

    Examples:
        >>> from preduce import compress
        >>> result = compress("Your verbose text here...", api_key="sk-...")
        >>> print(result.compressed_text)
        >>> print(result.token_reduction_pct)

        >>> # Force financial compression
        >>> result = compress(
        ...     "Total revenue for FY2025 was $847.3 million...",
        ...     api_key="sk-...",
        ...     category="FINANCIAL",
        ... )
    """
    if not text or not text.strip():
        raise ValueError("Text must not be empty.")

    if category is not None:
        category = category.upper()
        if category not in VALID_CATEGORIES:
            raise ValueError(
                f"Invalid category '{category}'. "
                f"Must be one of: {', '.join(sorted(VALID_CATEGORIES))}"
            )

    payload: Dict[str, Any] = {"text": text}
    if category:
        payload["category"] = category
    if api_key:
        payload["api_key"] = api_key

    headers = {
        "Content-Type": "application/json",
    }

    try:
        resp = requests.post(api_url, json=payload, headers=headers, timeout=timeout)
    except requests.ConnectionError:
        raise ConnectionError(
            "Could not connect to the Preduce API. "
            "Check your internet connection or try again later."
        )
    except requests.Timeout:
        raise TimeoutError(
            f"Preduce API request timed out after {timeout}s. "
            "Try a shorter text or increase the timeout."
        )

    if resp.status_code == 403:
        raise PermissionError("Invalid API key. Get one at https://preduce.dev")
    if resp.status_code == 402:
        raise PermissionError("API quota exceeded. Upgrade at https://preduce.dev")
    if resp.status_code == 422:
        detail = resp.json().get("detail", resp.text)
        raise ValueError(f"Invalid request: {detail}")
    if resp.status_code != 200:
        raise RuntimeError(f"Preduce API error ({resp.status_code}): {resp.text}")

    data = resp.json()

    return CompressResult(
        compressed_text=data["compressed_text"],
        category=data.get("category", category or "GENERAL"),
        original_tokens=data.get("original_tokens", 0),
        compressed_tokens=data.get("compressed_tokens", 0),
        stats=data.get("stats", {}),
    )
