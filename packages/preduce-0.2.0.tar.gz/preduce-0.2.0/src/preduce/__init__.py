"""
preduce — Compress LLM prompts 50%+ while preserving meaning.

Usage:
    from preduce import compress

    result = compress("Your verbose text here...", api_key="your-key")
    print(result.compressed_text)   # compressed output
    print(result.category)          # auto-detected: GENERAL, FINANCIAL, MEDICAL, CODE
    print(result.stats)             # reduction percentages and token counts
"""

from preduce.client import compress, CompressResult

__all__ = ["compress", "CompressResult"]
__version__ = "0.1.0"
