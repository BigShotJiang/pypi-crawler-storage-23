# preduce

Compress LLM prompts 50%+ while preserving meaning. Cut your API costs in half with one line of code.

## Install

```bash
pip install preduce
```

## Quick Start

```python
from preduce import compress

result = compress("Your verbose text here...", api_key="your-key")

print(result.compressed_text)      # compressed output
print(result.category)             # GENERAL, FINANCIAL, MEDICAL, CODE, ACADEMIC, SUPPORT, or MARKETING
print(result.token_reduction_pct)  # e.g. 52.3
print(result.stats)                # full reduction metrics
```

## Category Override

```python
result = compress(
    "Total revenue for fiscal year 2025 was $847,300,000, "
    "representing an increase of 22.4% year-over-year.",
    api_key="your-key",
    category="FINANCIAL",
)
# → "Total rev FY2025 $847.3M, +22.4% YoY."
```

## Categories

| Category | What it compresses | Example |
|---|---|---|
| **GENERAL** | Business docs, emails, reports | "we are pleased to announce" → removed |
| **FINANCIAL** | Earnings, metrics, filings | "$847,300,000" → "$847.3M" |
| **MEDICAL** | Clinical notes, discharge summaries | "type 2 diabetes mellitus" → "T2DM" |
| **CODE** | Preserves code, compresses prose | Code untouched, comments compressed |
| **ACADEMIC** | Research papers, dissertations | "statistically significant" → "sig." |
| **SUPPORT** | Support tickets, help desk | "thank you for contacting" → "thanks for contacting" |
| **MARKETING** | Marketing copy, promotions | "limited time offer" → "limited time" |

## Response

```python
result.compressed_text   # str — the compressed text
result.category          # str — detected or overridden category
result.original_tokens   # int — estimated original token count
result.compressed_tokens # int — estimated compressed token count
result.token_reduction_pct  # float — percentage reduction
result.char_reduction_pct   # float — percentage reduction
result.stats             # dict — full metrics
result.to_dict()         # dict — serialize everything
```

## Error Handling

```python
from preduce import compress

try:
    result = compress("text", api_key="invalid-key")
except PermissionError:
    print("Bad API key or quota exceeded")
except ValueError:
    print("Invalid input (empty text or bad category)")
except RuntimeError:
    print("API error")
```

## Get an API Key

Visit [preduce.dev](https://preduce.dev) to get your API key.

## License

MIT
