"""Vizro Dash Components are used by the Vizro framework but can be used in a pure Dash app."""
