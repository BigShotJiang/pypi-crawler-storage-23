from __future__ import annotations

import os
from typing import Optional

from easyrunner.source.resources.ssh_key_manager import SshKeyManager
from easyrunner.source.ssh_key import SshKey
from easyrunner_cli.source.ssh_config import (
    build_private_key_filename,
    ssh_config,
)


class FilesystemSshKeyManager(SshKeyManager):
    """Filesystem-backed SshKeyManager for CLI (persistent keys).

    Stores EasyRunner-managed server keys under `~/.ssh/easyrunner_keys/` (by default).
    """

    def __init__(self, key_dir: Optional[str] = None) -> None:
        self.key_dir = key_dir or ssh_config.key_dir
        os.makedirs(self.key_dir, exist_ok=True)

    def generate_and_store_key(self, identifier: str, passphrase: Optional[str] = None) -> str:
        name = build_private_key_filename(identifier)
        # create SshKey with the CLI key dir
        ssh_key = SshKey(email=f"easyrunner@{identifier}", name=name, ssh_key_dir=self.key_dir, regenerate_if_exists=True, passphrase=passphrase)
        ssh_key.generate_ed25519_keypair()
        ssh_key.save_private_key()
        ssh_key.save_public_key()
        # Return the actual path used by this manager (key_dir may be different from global ssh_config)
        return os.path.join(self.key_dir, name)

    def retrieve_private_key(self, identifier: str) -> Optional[str]:
        path = os.path.join(self.key_dir, build_private_key_filename(identifier))
        if not os.path.exists(path):
            return None
        with open(path, "r") as f:
            return f.read()

    def delete_key(self, identifier: str) -> bool:
        priv = os.path.join(self.key_dir, build_private_key_filename(identifier))
        pub = f"{priv}.pub"
        ok = True
        for p in (priv, pub):
            try:
                if os.path.exists(p):
                    os.remove(p)
            except Exception:
                ok = False
        return ok
