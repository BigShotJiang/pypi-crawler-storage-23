"""Keyring-based implementation of the SecretStore interface."""

import logging
import platform
from typing import Optional

import keyring
from easyrunner.source.store import SecretStore

logger = logging.getLogger(__name__)


class KeyringSecretStore(SecretStore):
    """Secure secret storage using the system keyring.

    Maps hierarchical path-based keys to keyring's service/account model:
    - Key path: "easyrunner/github/oauth_token"
    - Keyring service: "easyrunner.github"
    - Keyring account: "oauth_token"

    Multi-part accounts use dot separators for backward compatibility:
    - Key path: "easyrunner/hetzner/api_key/default"
    - Keyring service: "easyrunner.hetzner"
    - Keyring account: "api_key.default"

    See docs/secret-storage-design.md for design rationale.

    Uses the system keyring for secure credential storage. On macOS, this automatically
    configures keychain items to require password authentication on every access using
    the Security Framework. On other platforms, uses standard keyring storage.
    """

    def __init__(self) -> None:
        """Initialize the keyring secret store."""
        self.is_macos: bool = platform.system() == "Darwin"

    def store_secret(self, key: str, value: str) -> bool:
        """Store a secret in the system keyring."""
        service, account = self._parse_key(key)
        if self.is_macos:
            return self._store_secret_macos_secure(service, account, value)
        else:
            return self._store_secret_standard(service, account, value)

    def get_secret(self, key: str) -> Optional[str]:
        """Retrieve a secret from the system keyring."""
        service, account = self._parse_key(key)
        if self.is_macos:
            return self._get_secret_macos_secure(service, account)
        else:
            return self._get_secret_standard(service, account)

    def delete_secret(self, key: str) -> bool:
        """Delete a secret from the system keyring."""
        service, account = self._parse_key(key)
        if self.is_macos:
            return self._delete_secret_macos_secure(service, account)
        else:
            return self._delete_secret_standard(service, account)

    def discover_linked_accounts(self, service_name: str) -> list[str]:
        """Discover all linked accounts/projects for a service.

        On macOS, uses Security Framework to enumerate all stored accounts.
        Not supported on other platforms.

        Args:
            service_name: Service name (e.g., 'hetzner', 'cloudflare')

        Returns:
            List of account/project names that have stored credentials
        """
        if self.is_macos:
            return self._discover_accounts_macos_enumerate(service_name)
        else:
            logger.warning(f"Account discovery not supported on {platform.system()}")
            return []

    def _discover_accounts_macos_enumerate(self, service_name: str) -> list[str]:
        """Discover all accounts on macOS by querying the Security Framework.

        Uses SecItemCopyMatching to enumerate all keychain items for a service.

        Args:
            service_name: Service name (e.g., 'hetzner', 'cloudflare')

        Returns:
            List of account/project names that have stored credentials
        """
        try:
            from Security import (  # type: ignore
                SecItemCopyMatching,  # type: ignore
                errSecSuccess,  # type: ignore
                kSecAttrAccount,  # type: ignore
                kSecAttrService,  # type: ignore
                kSecClass,  # type: ignore
                kSecClassGenericPassword,  # type: ignore
                kSecMatchLimit,  # type: ignore
                kSecMatchLimitAll,  # type: ignore
                kSecReturnAttributes,  # type: ignore
            )
        except ImportError:
            logger.error("PyObjC Security Framework not available")
            return []

        try:
            service = f"easyrunner.{service_name}"

            # Query for all accounts in this service
            query = {
                kSecClass: kSecClassGenericPassword,
                kSecAttrService: service,
                kSecMatchLimit: kSecMatchLimitAll,
                kSecReturnAttributes: True,
            }

            # PyObjC pattern: SecItemCopyMatching returns (status, results) tuple
            status, results = SecItemCopyMatching(query, None)

            if status != errSecSuccess:
                logger.debug(f"No accounts found for service: {service} (status: {status})")
                return []

            if not results:
                return []

            # Extract account names from results
            accounts = []
            logger.debug(f"Results type: {type(results)}, Results: {results}")
            for item in results:
                logger.debug(f"Item type: {type(item)}, Item: {item}")
                # PyObjC returns NSDictionary objects, not Python dicts
                # Access via dictionary-style indexing which works with both
                try:
                    account = item[kSecAttrAccount]
                    logger.debug(f"Account from kSecAttrAccount: {account} (type: {type(account)})")
                    if account:
                        # Convert dot-separated account to name
                        # e.g., "api_key.default" -> "default", "api_token.janaka-personal" -> "janaka-personal"
                        account_str = str(account)
                        logger.debug(f"Account string: {account_str}")

                        # Handle both old slash format and new dot format
                        # Old: "api_token/test-account", New: "api_token.janaka-personal"
                        if "." in account_str:
                            account_parts = account_str.split(".", 1)  # Split only on first dot
                            logger.debug(f"Account parts after split (dot): {account_parts}")
                            if len(account_parts) > 1:
                                # Get the part after the first dot as the account name
                                name = account_parts[1]
                                logger.debug(f"Extracted name: {name}")
                                if name and name not in accounts:
                                    accounts.append(name)
                        elif "/" in account_str:
                            # Old format with slash - skip it
                            logger.debug(f"Skipping old slash format: {account_str}")
                            continue
                except (KeyError, TypeError) as e:
                    logger.debug(f"Failed to extract account from item: {e}")
                    continue

            return sorted(accounts)

        except Exception as e:
            logger.error(f"Error enumerating accounts for {service_name}: {e}")
            return []

    def _check_account_exists(self, service: str, account: str) -> bool:
        """Check if a keychain account exists without retrieving its value (no password prompt).

        Args:
            service: Keyring service name
            account: Keyring account name

        Returns:
            True if the account exists, False otherwise
        """
        if not self.is_macos:
            # Can't check without triggering a read on standard keyring
            return False

        try:
            from Security import (  # type: ignore
                SecItemCopyMatching,  # type: ignore
                errSecSuccess,  # type: ignore
                kSecAttrAccount,  # type: ignore
                kSecAttrService,  # type: ignore
                kSecClass,  # type: ignore
                kSecClassGenericPassword,  # type: ignore
            )

            # Query just for the existence of this specific account
            query = {
                kSecClass: kSecClassGenericPassword,
                kSecAttrService: service,
                kSecAttrAccount: account,
            }

            # Check if the item exists (pass None for result since we just want to check existence)
            result = SecItemCopyMatching(query, None)

            # SecItemCopyMatching returns a tuple (status, result_ref) on macOS
            # Status 0 (errSecSuccess) means the item exists
            if isinstance(result, tuple):
                status = result[0]
            else:
                status = result

            return status == errSecSuccess

        except Exception as e:
            logger.debug(f"Error checking account existence: {e}")
            return False

    @staticmethod
    def _parse_key(key: str) -> tuple[str, str]:
        """Parse path-based key into keyring service and account.

        Args:
            key: Path-based key (e.g., "easyrunner/github/oauth_token")

        Returns:
            Tuple of (service, account) for keyring
        """
        parts = key.split("/")

        if len(parts) < 2:
            raise ValueError(f"Invalid key format: {key}. Expected format: easyrunner/service/...")

        # Convert "easyrunner/github/oauth_token" to service="easyrunner.github", account="oauth_token"
        # Convert "easyrunner/hetzner/api_key/default" to service="easyrunner.hetzner", account="api_key.default"
        service = f"{parts[0]}.{parts[1]}"
        account = ".".join(parts[2:]) if len(parts) > 2 else ""

        return service, account

    def _store_secret_standard(self, service: str, account: str, value: str) -> bool:
        """Store secret using standard keyring (non-macOS platforms)."""
        try:
            keyring.set_password(service, account, value)
            logger.debug(f"Secret stored in keyring: {service}/{account}")
            return True
        except Exception as e:
            logger.error(f"Failed to store secret in keyring: {e}")
            return False

    def _get_secret_standard(self, service: str, account: str) -> Optional[str]:
        """Retrieve secret using standard keyring (non-macOS platforms)."""
        try:
            secret = keyring.get_password(service, account)
            if secret:
                logger.debug(f"Secret retrieved from keyring: {service}/{account}")
            return secret
        except Exception as e:
            logger.error(f"Failed to retrieve secret from keyring: {e}")
            return None

    def _delete_secret_standard(self, service: str, account: str) -> bool:
        """Delete secret using standard keyring (non-macOS platforms)."""
        try:
            keyring.delete_password(service, account)
            logger.debug(f"Secret deleted from keyring: {service}/{account}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete secret from keyring: {e}")
            return False

    def _store_secret_macos_secure(
        self, service: str, account: str, value: str
    ) -> bool:
        """Store secret with password challenge requirement on macOS."""
        try:
            from Foundation import NSData  # type: ignore
            from Security import (  # type: ignore
                SecAccessControlCreateWithFlags,  # type: ignore
                SecItemAdd,  # type: ignore
                SecItemDelete,  # type: ignore
                errSecSuccess,  # type: ignore
                kSecAttrAccessControl,  # type: ignore
                kSecAttrAccessibleWhenUnlockedThisDeviceOnly,  # type: ignore
                kSecAttrAccount,  # type: ignore
                kSecAttrService,  # type: ignore
                kSecClass,  # type: ignore
                kSecClassGenericPassword,  # type: ignore
                kSecValueData,  # type: ignore
            )
        except ImportError as import_error:
            logger.info(
                f"PyObjC frameworks not available ({import_error}), using standard keyring"
            )
            return self._store_secret_standard(service, account, value)

        try:
            # Delete any existing item first
            query = {
                kSecClass: kSecClassGenericPassword,
                kSecAttrService: service,
                kSecAttrAccount: account,
            }
            SecItemDelete(query)

            # Create access control requiring user interaction (password/TouchID)
            # Using kSecAccessControlUserPresence which requires authentication
            error = None
            access_control = SecAccessControlCreateWithFlags(
                None,  # allocator
                kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
                0x40000000,  # kSecAccessControlUserPresence
                error,
            )

            if not access_control:
                logger.warning(
                    "Failed to create access control, falling back to standard keyring"
                )
                return self._store_secret_standard(service, account, value)

            # Configure keychain item with password requirement
            value_bytes = value.encode("utf-8")
            query = {
                kSecClass: kSecClassGenericPassword,
                kSecAttrService: service,
                kSecAttrAccount: account,
                kSecValueData: NSData.dataWithBytes_length_(value_bytes, len(value_bytes)),
                kSecAttrAccessControl: access_control,
            }

            status = SecItemAdd(query, None)
            if status == errSecSuccess:
                logger.debug(
                    f"Secret stored with password challenge requirement: {service}/{account}"
                )
                return True
            else:
                logger.debug(
                    f"Failed to store secret (status: {status}), falling back to standard keyring"
                )
                return self._store_secret_standard(service, account, value)

        except Exception as e:
            logger.debug(
                f"Failed to store secret securely: {e}, falling back to standard keyring"
            )
            return self._store_secret_standard(service, account, value)

    def _get_secret_macos_secure(self, service: str, account: str) -> Optional[str]:
        """Retrieve secret with password challenge on macOS."""
        try:
            from Security import (  # type: ignore
                SecItemCopyMatching,  # type: ignore
                errSecAuthFailed,  # type: ignore
                errSecItemNotFound,  # type: ignore
                errSecSuccess,  # type: ignore
                kSecAttrAccount,  # type: ignore
                kSecAttrService,  # type: ignore
                kSecClass,  # type: ignore
                kSecClassGenericPassword,  # type: ignore
                kSecReturnData,  # type: ignore
            )
        except ImportError as import_error:
            logger.info(
                f"PyObjC frameworks not available ({import_error}), using standard keyring"
            )
            return self._get_secret_standard(service, account)

        try:
            query = {
                kSecClass: kSecClassGenericPassword,
                kSecAttrService: service,
                kSecAttrAccount: account,
                kSecReturnData: True,
            }

            # PyObjC pattern: SecItemCopyMatching returns (status, result) tuple
            status, result = SecItemCopyMatching(query, None)

            if status == errSecSuccess and result:
                value = result.bytes().tobytes().decode("utf-8")
                logger.debug(f"Secret retrieved from keyring: {service}/{account}")
                return value
            elif status == errSecItemNotFound:
                logger.debug(f"Secret not found in keyring: {service}/{account}")
                return None
            elif status == errSecAuthFailed:
                logger.error("Authentication failed when retrieving secret")
                return None
            else:
                logger.debug(
                    f"Failed to retrieve secret (status: {status}), falling back to standard keyring"
                )
                return self._get_secret_standard(service, account)

        except Exception as e:
            logger.debug(
                f"Failed to retrieve secret securely: {e}, falling back to standard keyring"
            )
            return self._get_secret_standard(service, account)

    def _delete_secret_macos_secure(self, service: str, account: str) -> bool:
        """Delete secret on macOS."""
        try:
            from Security import (  # type: ignore
                SecItemDelete,  # type: ignore
                errSecSuccess,  # type: ignore
                kSecAttrAccount,  # type: ignore
                kSecAttrService,  # type: ignore
                kSecClass,  # type: ignore
                kSecClassGenericPassword,  # type: ignore
            )
        except ImportError as import_error:
            logger.info(
                f"PyObjC frameworks not available ({import_error}), using standard keyring"
            )
            return self._delete_secret_standard(service, account)

        try:
            query = {
                kSecClass: kSecClassGenericPassword,
                kSecAttrService: service,
                kSecAttrAccount: account,
            }

            status = SecItemDelete(query)
            if status == errSecSuccess:
                logger.debug(f"Secret deleted from keyring: {service}/{account}")
                return True
            else:
                logger.debug(
                    f"Failed to delete secret (status: {status}), falling back to standard keyring"
                )
                return self._delete_secret_standard(service, account)

        except Exception as e:
            logger.debug(
                f"Failed to delete secret securely: {e}, falling back to standard keyring"
            )
            return self._delete_secret_standard(service, account)
