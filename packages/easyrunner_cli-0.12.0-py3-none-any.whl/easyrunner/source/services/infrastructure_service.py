from __future__ import annotations

from typing import Optional

from ..cloud_providers.cloud_provider_base import CloudProviderBase
from .service_result import ServiceResult


class InfrastructureService:
    """High-level service orchestration for infrastructure provisioning.

    This service consumes a CloudProvider and uses the provider's executor
    (if available) to run Pulumi programs. It provides a small, testable
    orchestration API for higher-level flows.
    """

    def __init__(self, provider: CloudProviderBase):
        self.provider = provider

    def provision_server(self, stack_name: str = "create-vm", backend_url: Optional[str] = None) -> ServiceResult[dict]:
        executor = self.provider.get_executor()
        if not executor:
            return ServiceResult.error("Provider does not expose an executor", error_code="NO_EXECUTOR")

        try:
            outputs = executor.create_vm(stack_name=stack_name, backend_url=backend_url)
            return ServiceResult.ok(message="Server provisioned", data=outputs)
        except Exception as e:
            return ServiceResult.error(message=f"Provisioning failed: {e}", error_code="PROVISION_FAILED")
