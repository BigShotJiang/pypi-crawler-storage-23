"""DNSService: Business logic for DNS setup and management.

Handles:
- DNS zone validation (checking if domain exists in Cloudflare)
- DNS record checking and creation
- DNS record description and formatting
"""

import logging
from typing import Optional

from ..integrations.cloudflare import CloudflareApiClient, CloudflareApiTokenManager
from ..store import EasyRunnerStore, SecretStore
from .service_result import ServiceResult

logger = logging.getLogger(__name__)


class DNSService:
    """Service for DNS management operations."""

    def __init__(self, store: EasyRunnerStore, secret_store: SecretStore):
        """Initialize service with store and secret store dependencies.

        Args:
            store: EasyRunnerStore instance for persistence
            secret_store: SecretStore instance for secure token storage
        """
        self.store = store
        self.secret_store = secret_store

    def validate_and_setup_dns(
        self,
        domain: str,
        server_ip: str,
        server_name: str,
        account_name: str = "default",
    ) -> ServiceResult[dict]:
        """Validate domain exists in Cloudflare and check/create DNS record.

        This method:
        1. Iterates through all linked Cloudflare accounts to find a matching zone
        2. Validates the domain is available in Cloudflare
        3. Checks if A record already exists for the IP
        4. Creates DNS record if needed
        5. Returns record information

        Args:
            domain: Full domain name (e.g., "app.example.com")
            server_ip: Server IP address for DNS record
            server_name: Name of the server (for description)
            account_name: Cloudflare account name (default: "default", ignored when iterating)

        Returns:
            ServiceResult with DNS record information and actions taken
        """
        try:
            # Step 1: Get all linked Cloudflare accounts
            linked_accounts = []
            
            # Check if secret_store has discover_linked_accounts method (CLI implementation)
            if hasattr(self.secret_store, 'discover_linked_accounts'):
                # Type ignore: discover_linked_accounts is not in the SecretStore interface
                # but is available in KeyringSecretStore (CLI implementation)
                linked_accounts = self.secret_store.discover_linked_accounts("cloudflare")  # type: ignore
                logger.debug(f"Discovered {len(linked_accounts)} linked Cloudflare account(s): {linked_accounts}")
            
            # If no accounts discovered, fall back to checking the default account
            if not linked_accounts:
                linked_accounts = ["default"]
                logger.debug("No accounts discovered, using default account")

            # Step 2: Iterate through each account to find matching zone
            zone_info = None
            matched_account = None
            client = None
            found_any_token = False
            
            for account in linked_accounts:
                logger.debug(f"Checking Cloudflare account '{account}' for domain '{domain}'")
                
                token_manager = CloudflareApiTokenManager(
                    account_name=account, secret_store=self.secret_store
                )
                api_token = token_manager.get_api_token()

                if not api_token:
                    logger.debug(f"No API token found for account '{account}', skipping")
                    continue
                
                found_any_token = True

                client = CloudflareApiClient(api_token=api_token)

                # Try to find the zone for this domain in this account
                zone_info = self._find_zone_for_domain(client=client, domain=domain)
                if zone_info:
                    matched_account = account
                    logger.info(f"Found matching zone in Cloudflare account '{account}': {zone_info.get('name')}")
                    break
            
            # Step 3: Check if we found a matching zone in any account
            if not zone_info or not client:
                logger.warning(f"Domain '{domain}' not found in any linked Cloudflare account")
                
                if not found_any_token:
                    # No tokens found at all - not linked
                    return ServiceResult.error(
                        message="Cloudflare not linked. Run 'er link cloudflare <account_name>' first.",
                        error_code="CLOUDFLARE_NOT_LINKED",
                        details={"domain": domain},
                    )
                
                return ServiceResult.error(
                    message=f"Domain '{domain}' not found in any of {len(linked_accounts)} linked Cloudflare account(s). Add it to one of your Cloudflare accounts first.",
                    error_code="DOMAIN_NOT_FOUND_IN_CLOUDFLARE",
                    details={"domain": domain, "checked_accounts": linked_accounts},
                )

            zone_id = zone_info["id"]
            zone_name = zone_info["name"]
            logger.debug(f"Found zone: {zone_name} (ID: {zone_id}) in account '{matched_account}'")

            # Step 4: Extract the record name (subdomain within the zone)
            record_name = self._extract_record_name(domain=domain, zone_name=zone_name)

            # Step 5: List existing records for this domain
            existing_records = client.list_dns_records(zone_id=zone_id)
            if existing_records is None:
                logger.error(f"Failed to list DNS records for zone {zone_id}")
                return ServiceResult.error(
                    message="Failed to query DNS records from Cloudflare",
                    error_code="DNS_LIST_FAILED",
                )

            # Filter records matching the domain
            matching_records = [
                r
                for r in existing_records
                if r.get("name") == domain or r.get("name") == record_name
            ]

            logger.debug(
                f"Found {len(matching_records)} existing record(s) for {domain}"
            )

            # Step 6: Check if record already exists for this IP
            existing_a_record = None
            for record in matching_records:
                if record.get("type") == "A" and record.get("content") == server_ip:
                    existing_a_record = record
                    logger.info(
                        f"A record already exists for {domain} → {server_ip} (ID: {record.get('id')})"
                    )
                    break

            if existing_a_record:
                # Record already exists, no need to create
                return ServiceResult.ok(
                    message=f"DNS A record already exists for {domain}",
                    data={
                        "action": "exists",
                        "zone_id": zone_id,
                        "zone_name": zone_name,
                        "domain": domain,
                        "record_id": existing_a_record.get("id"),
                        "ip": server_ip,
                        "records": matching_records,
                        "account": matched_account,
                    },
                )

            # Step 7: Create new DNS record
            # Note: DNS comment/description is not yet supported in the Cloudflare API client,
            # but the record will be created with the intended purpose: auto setup for EasyRunner
            new_record = client.create_dns_record(
                zone_id=zone_id,
                record_type="A",
                name=record_name,
                content=server_ip,
                ttl=300,  # 5 minutes
                proxied=False,
            )

            if not new_record:
                logger.error(f"Failed to create DNS record for {domain}")
                return ServiceResult.error(
                    message=f"Failed to create DNS A record for {domain}",
                    error_code="DNS_CREATE_FAILED",
                )

            logger.info(
                f"Successfully created DNS A record: {domain} → {server_ip} (ID: {new_record.get('id')}) in account '{matched_account}'"
            )

            # Include both new record and existing matching records in response
            matching_records.append(new_record)

            return ServiceResult.ok(
                message=f"DNS A record created: {domain} → {server_ip}",
                data={
                    "action": "created",
                    "zone_id": zone_id,
                    "zone_name": zone_name,
                    "domain": domain,
                    "record_id": new_record.get("id"),
                    "ip": server_ip,
                    "ttl": new_record.get("ttl"),
                    "proxied": new_record.get("proxied"),
                    "records": matching_records,
                    "account": matched_account,
                },
            )

        except Exception as e:
            error_msg = f"DNS setup failed: {str(e)}"
            logger.error(error_msg, exc_info=True)
            return ServiceResult.error(
                message=error_msg,
                error_code="DNS_SETUP_FAILED",
                details={"exception_type": type(e).__name__},
            )

    def _find_zone_for_domain(
        self, client: CloudflareApiClient, domain: str
    ) -> Optional[dict]:
        """Find the Cloudflare zone that contains this domain.

        Args:
            client: CloudflareApiClient instance
            domain: Full domain name to find zone for

        Returns:
            Zone info dict with id and name, or None if not found
        """
        try:
            zones = client.list_zones()
            if not zones:
                logger.warning("No Cloudflare zones found")
                return None

            # Sort by zone name length (longest first) to match most specific zone
            # E.g., "api.prod.example.com" should match "prod.example.com" before "example.com"
            sorted_zones = sorted(zones, key=lambda z: len(z.get("name", "")), reverse=True)

            for zone in sorted_zones:
                zone_name = zone.get("name", "").lower()
                domain_lower = domain.lower()

                # Check if domain matches or is a subdomain of this zone
                if domain_lower == zone_name or domain_lower.endswith("." + zone_name):
                    return zone

            logger.warning(
                f"No matching Cloudflare zone found for domain '{domain}'"
            )
            return None

        except Exception as e:
            logger.error(f"Error finding zone for domain '{domain}': {str(e)}")
            return None

    def _get_token_display(self, token: str) -> str:
        """Format token for display to user (first 8 chars + last 4 chars).

        Args:
            token: The full API token string

        Returns:
            Formatted token display string (e.g., "default_t...defg")
        """
        if not token or len(token) <= 12:
            return "***" if token else "(none)"
        return f"{token[:8]}...{token[-4:]}"

    def _extract_record_name(self, domain: str, zone_name: str) -> str:
        """Extract the record name (subdomain) from full domain and zone name.

        Args:
            domain: Full domain name (e.g., "api.prod.example.com")
            zone_name: Zone name (e.g., "example.com")

        Returns:
            Record name to use in Cloudflare API (e.g., "api.prod" or "@" for apex)
        """
        domain_lower = domain.lower()
        zone_name_lower = zone_name.lower()

        if domain_lower == zone_name_lower:
            # Apex domain
            return "@"

        if domain_lower.endswith("." + zone_name_lower):
            # Extract subdomain
            subdomain = domain_lower[: -(len(zone_name_lower) + 1)]
            return subdomain

        # Fallback to full domain (Cloudflare will handle it)
        return domain_lower
