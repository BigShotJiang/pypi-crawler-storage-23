from enum import Enum


class OS(Enum):
    UBUNTU = "ubuntu"
    MACOS = "macos"
    NONE = "none"
    WINDOWS = "windows"
