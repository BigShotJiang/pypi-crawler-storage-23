from abc import ABC


class ResourceBase(ABC):
    pass
