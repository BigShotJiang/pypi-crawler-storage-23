from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional


class SshKeyManager(ABC):
    """Abstract interface for persistent server-to-server SSH key management.

    This resource-level abstraction is used by services (e.g. DeploymentService)
    to retrieve or generate SSH keys for authenticating from EasyRunner to a
    managed server. Implementations can store keys on the filesystem (CLI)
    or in a secrets manager (Web API).
    """

    @abstractmethod
    def generate_and_store_key(self, identifier: str, passphrase: Optional[str] = None) -> str:
        """Generate a new key pair and store it.

        Args:
            identifier: A stable identifier for this key (e.g. hostname or server id)
            passphrase: Optional passphrase for the private key

        Returns:
            The path or locator of the stored private key (string) — implementation-defined.
        """

    @abstractmethod
    def retrieve_private_key(self, identifier: str) -> Optional[str]:
        """Retrieve private key content or a locator for the given identifier.

        Returns raw private key content (PEM/OpenSSH string) or None if not found.
        """

    @abstractmethod
    def delete_key(self, identifier: str) -> bool:
        """Delete a stored key by identifier. Returns True if deleted."""
