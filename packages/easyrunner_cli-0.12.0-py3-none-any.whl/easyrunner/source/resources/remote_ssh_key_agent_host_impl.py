from __future__ import annotations

from typing import List, Optional

from .os_resources.ssh_agent import SshAgent
from .remote_ssh_key_agent import RemoteSshKeyAgent


class HostBasedRemoteSshKeyAgent(RemoteSshKeyAgent):
    """Concrete RemoteSshKeyAgent implementation backed by HostServer's SshAgent resource.

    This adapter simply delegates to the existing SshAgent resource methods which
    operate by executing ssh-agent commands on the remote host via CommandExecutor.
    """

    def __init__(self, ssh_agent: SshAgent) -> None:
        self._ssh_agent = ssh_agent

    def add_key_from_content(self, private_key_content: str, comment: Optional[str] = None) -> bool:
        result = self._ssh_agent.add_key_from_content(private_key_content, comment)
        return result.success

    def list_keys(self) -> List[str]:
        result = self._ssh_agent.list_keys()
        return result.result or []

    def get_public_key(self, private_key_content: str) -> Optional[str]:
        # In-host agent implementation does not derive public key — expect higher layer
        return None
