from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional


class RemoteSshKeyAgent(ABC):
    """Abstract interface to manage ephemeral SSH keys on a remote host via its SSH agent.

    Implementations will typically use the HostServer resource (SshAgent) to load keys
    into memory on the server and optionally return metadata or public-key material.
    """

    @abstractmethod
    def add_key_from_content(self, private_key_content: str, comment: Optional[str] = None) -> bool:
        """Add a private key to the remote host ssh-agent from content.

        Returns True on success.
        """

    @abstractmethod
    def list_keys(self) -> list[str]:
        """List loaded key fingerprints or identifiers."""

    @abstractmethod
    def get_public_key(self, private_key_content: str) -> Optional[str]:
        """Return the public key corresponding to a private key content string.

        Implementations may derive the public key or return None if unsupported.
        """
