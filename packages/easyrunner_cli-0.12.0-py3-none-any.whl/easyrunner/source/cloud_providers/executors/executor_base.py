from __future__ import annotations

from typing import Any, Callable, Optional

from ..cloud_provider_base import CloudProviderBase


class ExecutorBase:
    """Base helper for Pulumi automation executors.

    Executors coordinate Pulumi stack selection and program execution.
    Concrete executors implement provider-specific program invocation.
    """

    def __init__(self, provider: CloudProviderBase) -> None:
        self.provider = provider

    def execute_program(self, stack_name: str, program: Callable[[], None], backend_url: Optional[str] = None) -> dict[str, Any] | None:
        """Execute a Pulumi program using the provider's workspace options.

        This method wraps common automation API usage; concrete executors
        may provide higher-level convenience methods.
        """
        import pulumi.automation as auto

        opts = self.provider._create_workspace_options(backend_url=backend_url)
        stack = auto.create_or_select_stack(stack_name=stack_name, project_name=self.provider.project_name, program=program, opts=opts)
        stack.up()
        outputs = stack.outputs()
        # Convert OutputMap to simple dict
        return self.provider._convert_pulumi_outputs_to_dict(outputs)
