from __future__ import annotations

from typing import Any, Optional

# CloudProviderBase intentionally not referenced directly here; we accept generic provider via ExecutorBase
from .executor_base import ExecutorBase


class HetznerVMExecutor(ExecutorBase):
    """Executor that runs the Hetzner VM creation program.

    This class coordinates Pulumi automation (stack selection + up).
    It deliberately avoids changing the provider's logic; it only wraps
    the execution pattern in a testable class that calls a module-level
    program function.
    """

    def create_vm(self, stack_name: str = "create-vm", backend_url: Optional[str] = None) -> dict[str, Any] | None:
        from ..programs.hetzner_vm import create_vm_program

        return self.execute_program(stack_name=stack_name, program=create_vm_program, backend_url=backend_url)
