"""Pulumi program definitions for Hetzner (module-level functions).

Pulumi automation requires program functions to be module-level (picklable).
This module contains pure program functions that define resources when executed
by Pulumi's automation API. These functions are intentionally lightweight so
they can be imported safely without side-effects.
"""

def create_vm_program():
    """Module-level Pulumi program that creates a VM.

    NOTE: This function is executed by Pulumi automation when the stack is run.
    It is intentionally minimal here; actual resource definitions should be
    implemented by the provider-specific program if needed.
    """
    # Import inside function to avoid import-time side-effects
    import pulumi  # type: ignore

    # Example placeholder export — real program should declare resources
    pulumi.export("vm_placeholder", "noop")

