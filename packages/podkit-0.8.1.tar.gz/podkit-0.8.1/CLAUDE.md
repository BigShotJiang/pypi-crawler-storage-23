# Podkit

Container management library for spawning and managing Docker containers (for now). Created as a response to Navari's needs to have container management in multiple places. Navari is a LLM-based agent solution with multiple MCP servers, skills, A2A servers and stuff like that.

The project has 3 core parts/concepts - a session (3) which depends on a container manager (2) which in turn depends on a specific backend (1). Corresponding locations:
1. `podkit/backends/docker.py` for the currently used backend
2. `podkit/core/manager.py` for the container manager
3. `podkit/core/session.py` for the session

In theory the backend can be swapped with no other code changes (at least that was the intention at design time). Session is the highest level layer out of these three and is designed around the concept of user ID and session ID, which are mandatory and used across all Navari stack. User ID and session ID are also included in the spawned container names.

There is also `podkit/utils/lifecycle.py` which provides a convenient `get_docker_session` function. This way the consumer does not need to instantiate a backend, container manager and session manually - `get_docker_session` does this under the hood and returns a session proxy. It can take an optional `ContainerConfig` parameter with various options including an array of `Mount` objects for precise configuration.

Main functionality that a session provides (or its proxy) are `execute_command` and `write_file` functions that do their job in a spawned container.

There are no unit tests in this repo (by design), only integration tests that run in a Docker container (see `Dockerfile.test` and `docker-compose.yml`). The integration tests are at the moment in two files: `tests/integration/test_integration_happy_path.py` and `tests/integration/test_integration_negative_flows.py`. The files are massive and contain many possible scenarios. The reasoning for having just 2 huge files was to cover real world scenarios with as little test code as possible, thus some tests depend on each other and run sequentially. This is by design and should stay this way. However in future it is reasonable not to extend these files but create new ones.

The `README.md` file focuses on examples and usage patterns, and it should stay this way.

To run the linter: `./scripts/lint.sh --fix`
To run the tests: `./scripts/test.sh`
