"""Base container manager for managing container lifecycle."""

import base64
import logging
import re
import uuid
from abc import ABC, abstractmethod
from pathlib import Path
from threading import Lock
from typing import TYPE_CHECKING, Any

from podkit.backends.base import BackendInterface
from podkit.core.models import ContainerConfig, ContainerStatus, ProcessResult
from podkit.utils.mounts import config_volumes_to_mounts
from podkit.utils.paths import normalize_container_path

if TYPE_CHECKING:
    from podkit.core.events import PodkitEventHandler


class BaseContainerManager(ABC):
    """
    Base container manager that works with any backend.

    Projects extend this class and inject their chosen backend.
    """

    def __init__(
        self,
        backend: BackendInterface,
        container_prefix: str,
        event_handler: "PodkitEventHandler | None" = None,
        logger: logging.Logger | None = None,
    ):
        """
        Initialize container manager.

        Args:
            backend: Backend implementation (Docker, K8s, etc.).
            container_prefix: Prefix for container names (e.g., "sandbox", "biomni").
            event_handler: Optional event handler for lifecycle events.
            logger: Optional logger instance. If None, creates a default logger.
                   Accepts any Python logger for flexible integration with external logging systems.
        """
        self.backend = backend
        self.container_prefix = container_prefix
        self.event_handler = event_handler
        self.logger = logger or logging.getLogger(f"podkit.{container_prefix}")
        self.lock = Lock()
        self.containers: dict[str, str] = {}  # {workload_id: workload_name}

        self.backend.connect()

    def _track_container(self, container_id: str, container_name: str) -> None:
        """Thread-safe method to add container to tracking dictionary.

        Args:
            container_id: Container ID to track.
            container_name: Container name.
        """
        with self.lock:
            self.containers[container_id] = container_name

    def _untrack_container(self, container_id: str) -> bool:
        """Thread-safe method to remove container from tracking dictionary.

        Args:
            container_id: Container ID to untrack.

        Returns:
            True if container was tracked (and removed), False otherwise.
        """
        with self.lock:
            if container_id in self.containers:
                del self.containers[container_id]
                return True
            return False

    def _is_tracked(self, container_id: str) -> bool:
        """Thread-safe method to check if container is tracked.

        Args:
            container_id: Container ID to check.

        Returns:
            True if container is tracked, False otherwise.
        """
        with self.lock:
            return container_id in self.containers

    def get_tracked_containers(self) -> list[str]:
        """Get list of tracked container IDs.

        Returns:
            List of container IDs currently tracked.
        """
        with self.lock:
            return list(self.containers.keys())

    def create_container(
        self,
        user_id: str,
        session_id: str,
        config: ContainerConfig,
        *,
        container_name: str | None = None,
    ) -> tuple[str, str]:
        """
        Create a new container.

        Args:
            user_id: User identifier.
            session_id: Session identifier.
            config: Container configuration.
            container_name: Optional container name. If None, generates automatically.

        Returns:
            Tuple of (container_id, container_name).

        Raises:
            RuntimeError: If container creation fails.
        """
        # Allow event handler to modify config before creation
        if self.event_handler:
            config = self.event_handler.on_container_creating(user_id, session_id, config)

        if container_name is None:
            user_session_slug = "-".join(re.sub(r"[^a-z0-9]", "", _id.lower()) for _id in (session_id, user_id))
            container_name = f"{self.container_prefix}-{user_session_slug}-{uuid.uuid4().hex[:4]}"

        mounts = self.get_mounts(user_id, session_id, config)

        # Add labels for session recovery and container grouping
        labels = {
            "podkit.user_id": user_id,
            "podkit.session_id": session_id,
            "podkit.manager": self.container_prefix,
            "podkit.image": config.image,
            "com.docker.compose.project": self.container_prefix,
        }

        try:
            # Create via backend with labels (outside lock - this may be slow)
            container_id = self.backend.create_workload(
                name=container_name,
                config=config,
                mounts=mounts,
                labels=labels,
            )

            # Add to tracking (minimize lock time)
            self._track_container(container_id, container_name)

            # Notify event handler of successful creation
            if self.event_handler:
                self.event_handler.on_container_created(container_id, container_name, user_id, session_id, config)

            return container_id, container_name

        except Exception as e:
            # Notify event handler of failure
            if self.event_handler:
                self.event_handler.on_container_creation_failed(user_id, session_id, config, e)
            raise

    @abstractmethod
    def get_mounts(
        self,
        user_id: str,
        session_id: str,
        config: ContainerConfig,
    ) -> list[dict[str, Any]]:
        """
        Get volume mounts for container.

        Project-specific implementation (sandbox vs biomni have different needs).

        Args:
            user_id: User identifier.
            session_id: Session identifier.
            config: Container configuration.

        Returns:
            List of mount specifications in Docker format.
        """
        ...

    def start_container(self, container_id: str, config: ContainerConfig | None = None) -> None:
        """
        Start a container with optional startup verification.

        Backend automatically handles paused vs stopped states.

        Args:
            container_id: ID of the container to start.
            config: Optional config for verification settings.
                   If None or no startup_verification, verification is skipped.

        Raises:
            RuntimeError: If container start fails or verification fails.
        """
        # Delegate to backend - it handles start/unpause + verification
        verification_config = config.startup_verification if config else None

        try:
            self.backend.start_workload(container_id, verification_config)
        except Exception:
            # Notify event handler of startup failure
            if self.event_handler:
                with self.lock:
                    container_name = self.containers.get(container_id, "unknown")

                # Get additional info for the callback
                labels = self.backend.get_workload_labels(container_id)
                user_id = labels.get("podkit.user_id", "unknown")
                session_id = labels.get("podkit.session_id", "unknown")
                exit_code = self.backend.get_workload_exit_code(container_id)
                logs = self.backend.get_workload_logs(container_id, tail=100)

                self.event_handler.on_container_startup_failed(
                    container_id=container_id,
                    container_name=container_name,
                    user_id=user_id,
                    session_id=session_id,
                    exit_code=exit_code,
                    logs=logs,
                )

            # Re-raise the exception
            raise

    def stop_container(self, container_id: str, timeout: int = 10) -> None:
        """
        Stop a container without removing it.

        Idempotent - no error if container is already stopped.

        Args:
            container_id: ID of the container to stop.
            timeout: Timeout in seconds for graceful stop (default: 10).

        Raises:
            RuntimeError: If container stop fails.
        """
        with self.lock:
            container_name = self.containers.get(container_id, "unknown")

        try:
            self.backend.stop_workload(container_id, timeout=timeout)

            if self.event_handler:
                self.event_handler.on_container_stopped(container_id, container_name)

        except Exception as e:
            if self.event_handler:
                self.event_handler.on_container_stop_failed(container_id, e)
            raise

    def remove_container(self, container_id: str) -> None:
        """
        Remove a container.

        Args:
            container_id: ID of the container to remove.

        Raises:
            RuntimeError: If container removal fails.
        """
        # Get container name before removal (for event handler)
        with self.lock:
            container_name = self.containers.get(container_id, "unknown")

        try:
            # Remove from backend (outside lock - slow operation)
            self.backend.remove_workload(container_id)

            # Remove from tracking (minimize lock time)
            self._untrack_container(container_id)

            # Notify event handler of successful removal
            if self.event_handler:
                self.event_handler.on_container_removed(container_id, container_name)

        except Exception as e:
            # Notify event handler of failure
            if self.event_handler:
                self.event_handler.on_container_removal_failed(container_id, e)
            raise

    def execute_command(
        self,
        container_id: str,
        command: str | list[str],
        working_dir: Path | None = None,
        environment: dict[str, str] | None = None,
        timeout: int | None = None,
    ) -> ProcessResult:
        """
        Execute command in container.

        Args:
            container_id: ID of the container.
            command: Command to execute.
            working_dir: Working directory for command execution.
            environment: Environment variables.
            timeout: Timeout in seconds.

        Returns:
            ProcessResult with exit code and output.

        Raises:
            RuntimeError: If command execution fails.
        """
        return self.backend.execute_command(
            workload_id=container_id,
            command=command,
            working_dir=working_dir,
            environment=environment,
            timeout=timeout,
        )

    @abstractmethod
    def write_file(
        self,
        container_id: str,
        container_path: Path | str,
        content: str,
    ) -> Path:
        """
        Write a file for a container.

        Implementation depends on mount strategy:
        - With mounts: Write to host filesystem (persists), looks up user_id/session_id from container labels
        - Without mounts: Write inside container via command (ephemeral)

        Args:
            container_id: ID of the container.
            container_path: Path inside the container where file should appear. Can be:
                           - Relative path (e.g., "file.txt") - auto-prepended with /workspace/
                           - Absolute path (e.g., "/workspace/file.txt") - used as-is
            content: Content to write.

        Returns:
            The normalized container path where the file was written.

        Raises:
            RuntimeError: If file write fails or container labels are missing.
        """
        ...

    def get_container_status(self, container_id: str, refresh: bool = True) -> ContainerStatus:
        """
        Get container status.

        Args:
            container_id: ID of the container.
            refresh: If True, refresh container state before checking status (default: True).
                    If False, use cached state (faster but may be stale).

        Returns:
            Current container status.
        """
        if refresh:
            self.backend.reload_workload(container_id)
        return self.backend.get_workload_status(container_id)

    def discover_existing_containers(self) -> list[dict[str, str]]:
        """Discover existing containers managed by this manager.

        Discovered containers are automatically added to internal tracking.

        Returns:
            List of dicts with keys: container_id, container_name, user_id, session_id, image
        """
        try:
            containers = self.backend.list_workloads(filters={"name": f"{self.container_prefix}-"})

            discovered = []
            for container_info in containers:
                container_id = container_info["id"]
                container_name = container_info["name"]

                labels = self.backend.get_workload_labels(container_id)

                user_id = labels.get("podkit.user_id")
                session_id = labels.get("podkit.session_id")
                image = labels.get("podkit.image")

                if user_id and session_id:
                    # Add to tracking dict so cleanup_all() can find it
                    self._track_container(container_id, container_name)

                    discovered.append(
                        {
                            "container_id": container_id,
                            "container_name": container_name,
                            "user_id": user_id,
                            "session_id": session_id,
                            "image": image,
                        }
                    )

            return discovered
        except Exception:  # pylint: disable=broad-except
            return []

    def cleanup_all(self) -> None:
        """Clean up all tracked containers."""
        # Get snapshot (minimize lock time)
        container_ids = self.get_tracked_containers()

        for container_id in container_ids:
            try:
                self.remove_container(container_id)
            except Exception:  # pylint: disable=broad-except
                # Continue even if one fails
                pass


class SimpleContainerManager(BaseContainerManager):
    """
    Simple implementation of container manager.

    Uses config.volumes for mounts and writes files directly to host
    when the target path is inside a bind mount.
    """

    def get_mounts(
        self,
        user_id: str,
        session_id: str,
        config: ContainerConfig,
    ) -> list[dict[str, Any]]:
        """
        Get volume mounts from container config.

        Args:
            user_id: User identifier (unused, kept for interface compatibility).
            session_id: Session identifier (unused, kept for interface compatibility).
            config: Container configuration with volumes.

        Returns:
            List of mount specifications in Docker format.
        """
        return config_volumes_to_mounts(config.volumes)

    def write_file(
        self,
        container_id: str,
        container_path: Path | str,
        content: str,
    ) -> Path:
        """
        Write a file to a container.

        If the target path is inside a bind mount, writes directly to host filesystem.
        Otherwise, falls back to writing via docker exec.

        Args:
            container_id: ID of the container.
            container_path: Path inside the container. Can be relative or absolute.
            content: Content to write.

        Returns:
            The normalized container path where the file was written.

        Raises:
            RuntimeError: If file write fails.
        """
        path = normalize_container_path(container_path)
        mounts = self.backend.get_workload_mounts(container_id)

        for mount in mounts:
            if mount.get("Type") != "bind":
                continue

            destination = Path(mount.get("Destination", ""))
            try:
                relative = path.relative_to(destination)
                host_path = Path(mount["Source"]) / relative

                # Check if host path is accessible (handles remote Docker)
                if not Path(mount["Source"]).exists():
                    break

                self.logger.info(f"write file {path} directly as directory is mounted")
                host_path.parent.mkdir(parents=True, exist_ok=True)
                host_path.write_text(content, encoding="utf-8")
                return path
            except ValueError:
                # Path is not relative to this mount, try next
                continue

        self.logger.warning(f"fallback to docker exec to write file {path}")
        return self._write_file_via_exec(container_id, path, content)

    def _write_file_via_exec(
        self,
        container_id: str,
        container_path: Path,
        content: str,
    ) -> Path:
        """
        Write file inside container using docker exec with base64 encoding.

        Args:
            container_id: ID of the container.
            container_path: Absolute path inside the container.
            content: Content to write.

        Returns:
            The container path where the file was written.

        Raises:
            RuntimeError: If file write fails.
        """
        self.logger.info(f"write file {container_path} with docker exec")
        encoded = base64.b64encode(content.encode("utf-8")).decode("ascii")
        command = f"mkdir -p $(dirname {container_path}) && echo {encoded} | base64 -d > {container_path}"

        result = self.execute_command(container_id, ["sh", "-c", command])
        if result.exit_code != 0:
            raise RuntimeError(f"Failed to write file {container_path}: {result.stderr}")

        return container_path
