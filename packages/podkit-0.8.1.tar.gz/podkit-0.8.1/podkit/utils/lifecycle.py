"""Optional lifecycle management utilities for convenient session management.

This module provides convenience functions for common use cases. You can still use
the core SessionManager API directly for more control.
"""

import logging
import uuid
from pathlib import Path
from threading import Lock

from podkit.backends.docker import DockerBackend
from podkit.constants import (
    DEFAULT_CONTAINER_IMAGE,
    DEFAULT_CONTAINER_LIFETIME_SECONDS,
    DEFAULT_CONTAINER_PREFIX,
    DEFAULT_CPU_LIMIT,
    DEFAULT_MEMORY_LIMIT,
)
from podkit.core.manager import SimpleContainerManager
from podkit.core.models import ContainerConfig, ProcessResult, Session
from podkit.core.session import BaseSessionManager

# Global managers cache
_managers_cache: dict[str, tuple[DockerBackend, SimpleContainerManager, BaseSessionManager]] = {}
_cache_lock = Lock()


class SessionProxy:
    """
    Convenience wrapper for session operations.

    Remembers user_id and session_id so you don't have to pass them repeatedly.

    Example:
        session = get_docker_session(user_id="bob", session_id="123")
        result = session.execute_command("ls -lah")
        session.write_file(Path("/workspace/test.txt"), "Hello")
        session.close()
    """

    def __init__(self, session_manager: BaseSessionManager, user_id: str, session_id: str):
        """
        Initialize session proxy.

        Args:
            session_manager: The underlying session manager.
            user_id: User identifier.
            session_id: Session identifier.
        """
        self._manager = session_manager
        self._user_id = user_id
        self._session_id = session_id

    @property
    def user_id(self) -> str:
        """Get user ID."""
        return self._user_id

    @property
    def session_id(self) -> str:
        """Get session ID."""
        return self._session_id

    def execute_command(
        self,
        command: str | list[str],
        working_dir: Path | None = None,
        environment: dict[str, str] | None = None,
        timeout: int | None = None,
    ) -> ProcessResult:
        """
        Execute command in this session's container.

        Args:
            command: Command to execute.
            working_dir: Optional working directory.
            environment: Optional environment variables.
            timeout: Optional timeout in seconds.

        Returns:
            ProcessResult with exit code and output.

        Raises:
            RuntimeError: If the session is not found or command execution fails.
        """
        return self._manager.execute_command(
            self._user_id,
            self._session_id,
            command,
            working_dir,
            environment,
            timeout,
        )

    def write_file(self, container_path: Path | str, content: str) -> Path:
        """
        Write a file to this session's container.

        If the target path is inside a bind mount (from config.volumes),
        the file is written directly to the host filesystem and persists.
        Otherwise, the file is written inside the container via exec (ephemeral).

        Args:
            container_path: Path inside the container. Can be:
                - Relative path (e.g., "file.txt") - auto-prepended with /workspace/
                - Absolute path (e.g., "/workspace/file.txt") - used as-is
            content: Content to write.

        Returns:
            The normalized container path where the file was written.

        Raises:
            RuntimeError: If the session is not found or file write fails.
        """
        return self._manager.write_file(
            self._user_id,
            self._session_id,
            container_path,
            content,
        )

    def close(self) -> None:
        """
        Close this session and cleanup resources.

        Raises:
            RuntimeError: If the session is not found.
        """
        self._manager.close_session(self._user_id, self._session_id)

    def get_info(self) -> Session | None:
        """
        Get information about this session.

        Returns:
            Session object or None if not found.
        """
        return self._manager.get_session(self._user_id, self._session_id)

    def __enter__(self):
        """Support context manager protocol."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Auto-close on context manager exit."""
        try:
            self.close()
        except Exception:  # pylint: disable=broad-except
            pass  # Best-effort cleanup


def get_docker_session(
    *,
    user_id: str,
    session_id: str,
    config: ContainerConfig | None = None,
    container_prefix: str = DEFAULT_CONTAINER_PREFIX,
    image_name: str = DEFAULT_CONTAINER_IMAGE,
    logger: logging.Logger | None = None,
) -> SessionProxy:
    """
    Get or create a Docker session with automatic manager setup.

    This is a convenience function that handles manager lifecycle internally.
    If you need more control, use BaseSessionManager directly.

    To mount volumes, use config.volumes:

        from podkit.core.models import ContainerConfig, Mount

        session = get_docker_session(
            user_id="bob",
            session_id="123",
            config=ContainerConfig(
                image="python:3.11-alpine",
                volumes=[
                    Mount(source=Path("/host/data"), target=Path("/data"), read_only=True),
                    Mount(source=Path("/host/output"), target=Path("/output")),
                ],
            ),
        )

    Usage Pattern 1 - With volumes (files persist on host):
        session = get_docker_session(
            user_id="bob",
            session_id="123",
            config=ContainerConfig(
                volumes=[Mount(source=Path("/host/workspace"), target=Path("/workspace"))],
            ),
        )
        session.write_file("/workspace/test.txt", "content")  # Persists on host
        session.close()

    Usage Pattern 2 - No volumes (ephemeral execution):
        session = get_docker_session(user_id="bob", session_id="123")
        session.write_file("/tmp/script.py", "print('Hello')")  # Ephemeral
        result = session.execute_command("python /tmp/script.py")
        session.close()

    Usage Pattern 3 - Context manager (auto-cleanup):
        with get_docker_session(user_id="bob", session_id="123") as session:
            result = session.execute_command("ls -lah")

    Args:
        user_id: User identifier.
        session_id: Session identifier.
        config: Container configuration. Use config.volumes for mounts.
            If None, creates defaults with auto-shutdown after 60 seconds.
        container_prefix: Container name prefix (default: "podkit").
        image_name: Default image if config not provided (default: "python:3.11-alpine").
        logger: Optional logger instance.

    Returns:
        SessionProxy for convenient operations.

    Raises:
        RuntimeError: If Docker is not available or session creation fails.
    """
    cache_key = container_prefix

    with _cache_lock:
        if cache_key not in _managers_cache:
            backend = DockerBackend(logger=logger)
            backend.connect()

            container_manager = SimpleContainerManager(
                backend=backend,
                container_prefix=container_prefix,
                logger=logger,
            )

            session_manager = BaseSessionManager(
                container_manager=container_manager,
                default_image=image_name,
                logger=logger,
            )

            _managers_cache[cache_key] = (backend, container_manager, session_manager)

        _, _, session_manager = _managers_cache[cache_key]

    existing_session = session_manager.get_session(user_id, session_id)

    if existing_session is None:
        if config is None:
            config = ContainerConfig(
                image=image_name,
                # entrypoint=None means use container_lifetime_seconds for auto-shutdown
                container_lifetime_seconds=DEFAULT_CONTAINER_LIFETIME_SECONDS,
            )

        session_manager.create_session(
            user_id=user_id,
            session_id=session_id,
            config=config,
        )

    return SessionProxy(session_manager, user_id, session_id)


def reset_lifecycle_cache() -> None:
    """
    Reset the internal manager cache.

    Useful for testing or when you need to recreate managers.
    Cleanup all sessions before calling this.
    """
    with _cache_lock:
        for _, _, session_manager in _managers_cache.values():
            try:
                session_manager.cleanup_all()
            except Exception:  # pylint: disable=broad-except
                pass

        _managers_cache.clear()


def run_in_docker(
    command: str | list[str],
    *,
    image: str = DEFAULT_CONTAINER_IMAGE,
    command_timeout: int | None = None,
    memory_limit: str = DEFAULT_MEMORY_LIMIT,
    cpu_limit: float = DEFAULT_CPU_LIMIT,
    files: dict[str, str] | None = None,
    environment: dict[str, str] | None = None,
    working_dir: Path | None = None,
) -> ProcessResult:
    """Run a command in a temporary Docker container.

    This is a convenience function for one-off command executions.
    The container is automatically created and cleaned up.

    For persistent sessions or more control, use get_docker_session() instead.

    Args:
        command: Command to execute (string or list of strings).
        image: Docker image to use (default: python:3.11-alpine).
        command_timeout: Maximum seconds to wait for command completion.
            If None (default), waits indefinitely until command finishes.
            Returns exit code 124 if timeout is reached.
        memory_limit: Container memory limit (default: 512m).
        cpu_limit: Container CPU limit in cores (default: 1.0).
        files: Dict of {container_path: content} to write before execution.
        environment: Environment variables for the command.
        working_dir: Working directory for command execution.

    Returns:
        ProcessResult with exit_code, stdout, and stderr.

    Example:
        >>> result = run_in_docker("echo hello")
        >>> print(result.stdout)
        hello

        >>> result = run_in_docker(
        ...     "python /workspace/script.py",
        ...     files={"/workspace/script.py": "print('hello')"},
        ... )

        >>> result = run_in_docker(
        ...     "python long_job.py",
        ...     command_timeout=30,  # Kill if not done in 30s
        ... )
        >>> if result.exit_code == 124:
        ...     print("Command timed out")
    """
    config = ContainerConfig(
        image=image,
        memory_limit=memory_limit,
        cpu_limit=cpu_limit,
        entrypoint=[],  # Use sleep infinity - container runs until we're done
    )

    with get_docker_session(
        user_id="_run_in_docker",
        session_id=uuid.uuid4().hex,
        config=config,
    ) as session:
        if files:
            for path, content in files.items():
                session.write_file(path, content)

        return session.execute_command(
            command,
            timeout=command_timeout,
            environment=environment,
            working_dir=working_dir,
        )
