"""Mount configuration utilities for container managers."""

from typing import Any

from podkit.core.models import Mount


def config_volumes_to_mounts(volumes: list[Mount] | None) -> list[dict[str, Any]]:
    """Convert config.volumes to Docker mount format.

    Args:
        volumes: List of Mount objects from ContainerConfig.volumes.

    Returns:
        List of mount specifications in Docker format.
    """
    mounts = []
    for volume in volumes or []:
        mount_dict = {
            "Type": volume.type,
            "Source": str(volume.source),
            "Target": str(volume.target),
        }
        if volume.read_only:
            mount_dict["ReadOnly"] = True
        mounts.append(mount_dict)
    return mounts
