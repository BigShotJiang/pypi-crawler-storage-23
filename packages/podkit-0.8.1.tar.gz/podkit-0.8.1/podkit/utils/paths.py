"""Path utilities for container management."""

from pathlib import Path

from podkit.constants import CONTAINER_WORKSPACE_PATH


def normalize_container_path(container_path: Path | str) -> Path:
    """
    Normalize a container path by auto-prepending /workspace/ for relative paths.

    Args:
        container_path: Path inside the container. Can be relative or absolute.

    Returns:
        Absolute container path with /workspace/ prepended for relative paths.

    Example:
        >>> normalize_container_path("file.txt")
        Path("/workspace/file.txt")
        >>> normalize_container_path("/workspace/file.txt")
        Path("/workspace/file.txt")
        >>> normalize_container_path("/tmp/file.txt")
        Path("/tmp/file.txt")
    """
    path = Path(container_path)
    if not path.is_absolute():
        path = Path(CONTAINER_WORKSPACE_PATH) / path
    return path
