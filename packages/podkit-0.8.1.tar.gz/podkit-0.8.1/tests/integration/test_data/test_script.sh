#!/bin/sh
echo "Test script executed successfully"
echo "Arguments: $@"
exit 0