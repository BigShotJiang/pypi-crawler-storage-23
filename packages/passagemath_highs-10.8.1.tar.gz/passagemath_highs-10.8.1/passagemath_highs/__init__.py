# sage_setup: distribution = sagemath-highs

from sage.all__sagemath_highs import *
