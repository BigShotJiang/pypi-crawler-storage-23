# sage_setup: distribution = sagemath-highs
"""Cython declarations for the HiGHS optimization solver."""
