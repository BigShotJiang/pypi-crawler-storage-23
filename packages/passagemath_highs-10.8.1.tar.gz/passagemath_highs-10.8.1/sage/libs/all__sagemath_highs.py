# sage_setup: distribution = sagemath-highs
