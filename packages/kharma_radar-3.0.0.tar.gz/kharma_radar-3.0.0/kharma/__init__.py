"""
Kharma - The Over-Watch Network Monitor
"""
__version__ = "3.0.0"
