"""Allow running as `python -m wevitos_mcp`."""

from wevitos_mcp.server import main

main()
