"""Wevitos MCP Server — error tracking tools for AI coding assistants."""

__version__ = "0.1.0"
