# wevitos-mcp

MCP server for [Wevitos](https://wevitos.com) error tracking. Lets AI coding assistants (Claude Code, Cursor, etc.) list, inspect, resolve, and comment on errors directly from your editor.

## Installation

```bash
pip install wevitos-mcp
```

Or with [uvx](https://docs.astral.sh/uv/):

```bash
uvx wevitos-mcp
```

## Configuration

### Claude Code

Add to your `.mcp.json`:

```json
{
  "mcpServers": {
    "wevitos": {
      "command": "wevitos-mcp",
      "env": {
        "WEVITOS_BASE_URL": "https://app.wevitos.com"
      }
    }
  }
}
```

### Cursor

Add to your MCP settings:

```json
{
  "mcpServers": {
    "wevitos": {
      "command": "uvx",
      "args": ["wevitos-mcp"],
      "env": {
        "WEVITOS_BASE_URL": "https://app.wevitos.com"
      }
    }
  }
}
```

## Environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| `WEVITOS_BASE_URL` | `http://localhost:8000` | URL of your Wevitos instance |

## Tools

All tools require an `api_key` parameter — your Wevitos project API key.

| Tool | Description |
|------|-------------|
| `list_errors` | List error groups (filter by `status`: open, resolved, ignored) |
| `get_error` | Get error detail with stacktrace |
| `resolve_error` | Resolve an error, optionally with a comment |
| `ignore_error` | Ignore an error, optionally with a comment |
| `reopen_error` | Reopen a resolved/ignored error |

## Example usage

Once configured, ask your AI assistant:

- "List open errors in my project" (provide your API key)
- "Show me the stacktrace for error `<uuid>`"
- "Resolve error `<uuid>` with comment 'Fixed null check in auth middleware'"

## License

MIT
