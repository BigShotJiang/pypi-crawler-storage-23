from setuptools import setup

setup(
    name="kissat-sovereign",
    version="2.1.0",
    author="Americo Simoes",
    py_modules=["kissat_apex"],
    data_files=[('lib', ['libkissat.so'])],
    include_package_data=True,
    entry_points={
        'console_scripts': [
            'kissat-sovereign=kissat_apex:solve_sovereign_cli',
            'kissat-benchmark=kissat_apex:run_benchmark',
        ],
    },
)
