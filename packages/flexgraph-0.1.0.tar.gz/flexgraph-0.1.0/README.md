# FlexGraph

Knowledge operating system.

Coming soon at [flexgraph.dev](https://flexgraph.dev)
