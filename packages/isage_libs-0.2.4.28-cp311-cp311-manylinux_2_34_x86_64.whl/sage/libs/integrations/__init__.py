"""Third-party integration interfaces and registries for SAGE."""

from sage.libs.integrations.huggingface import (
    HuggingFaceClientProtocol,
    create_huggingface_client,
    register_huggingface_client_factory,
)

__all__ = [
    "HuggingFaceClientProtocol",
    "register_huggingface_client_factory",
    "create_huggingface_client",
]
