"""Vector Database backend interface for SAGE.

This module defines the abstract ``VDBBackend`` protocol so that L4 consumers
(e.g. ``isage-neuromem``) can depend on this L3 interface rather than coupling
directly to a concrete L4 package (``isage-vdb`` / sagedb).

Concrete implementations live in ``isage-vdb`` (L4) and register themselves
via the factory helper ``register_backend``.

Usage::

    from sage.libs.vdb import VDBBackend, create_backend, register_backend

    # --- registration side (in isage-vdb) ---
    @register_backend("sagedb")
    class SageDBBackend(VDBBackend):
        ...

    # --- consumer side (in isage-neuromem) ---
    backend: VDBBackend = create_backend("sagedb", config)
    backend.add(ids=["k1"], vectors=[[0.1, 0.2]], metadata=[{"text": "hello"}])
"""

from __future__ import annotations

from sage.libs.vdb.interface import VDBBackend
from sage.libs.vdb.registry import (
    VDBRegistryError,
    create_backend,
    list_backends,
    register_backend,
)

__all__ = [
    "VDBBackend",
    "VDBRegistryError",
    "create_backend",
    "list_backends",
    "register_backend",
]
