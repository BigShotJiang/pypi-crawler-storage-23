"""Abstract protocol defining the SAGE↔LLM service contract.

Any LLM backend (SageLLM, vLLM, Ollama, mock) that wishes to be used
by SAGE operators must implement :class:`LLMServiceProtocol`.

Usage example (concrete implementation side):

    from sage.libs.llm.protocol import LLMServiceProtocol
    from sage.libs.llm.types import LLMRequest, LLMResponse

    class MySageLLMBackend(LLMServiceProtocol):
        def generate(self, request: LLMRequest) -> LLMResponse: ...
        def is_available(self) -> bool: ...

Usage example (SAGE operator side):

    from sage.libs.llm.protocol import LLMServiceProtocol
    from sage.libs.llm.registry import LLMBackendRegistry

    class MyOperator:
        def __init__(self, backend: LLMServiceProtocol | None = None):
            self._backend = backend or LLMBackendRegistry.default()

        def process(self, prompt: str) -> str:
            req = LLMRequest(prompt=prompt, max_tokens=256)
            return self._backend.generate(req).text
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import AsyncGenerator, Generator
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sage.libs.llm.types import LLMRequest, LLMResponse, LLMStreamChunk


class LLMServiceProtocol(ABC):
    """Abstract interface for LLM inference backends.

    SAGE operators depend on this interface; concrete backends (SageLLM,
    vLLM, Ollama, …) implement it and register via :class:`LLMBackendRegistry`.

    Thread-safety: implementations must be safe for concurrent ``generate``
    calls (e.g. using a thread-safe HTTP client).
    """

    # ------------------------------------------------------------------ #
    # Required: sync generate
    # ------------------------------------------------------------------ #

    @abstractmethod
    def generate(self, request: LLMRequest) -> LLMResponse:
        """Run a single blocking inference request.

        Args:
            request: The :class:`~sage.libs.llm.types.LLMRequest` to execute.

        Returns:
            A :class:`~sage.libs.llm.types.LLMResponse`.

        Raises:
            LLMServiceError: If the backend is unreachable or returns an error.
        """

    # ------------------------------------------------------------------ #
    # Optional: streaming variants (default: raise NotImplementedError)
    # ------------------------------------------------------------------ #

    def stream(self, request: LLMRequest) -> Generator[LLMStreamChunk, None, None]:
        """Yield chunks for a streaming inference request.

        The default implementation falls back to a single ``generate`` call
        wrapped in a one-element generator so backends that do not support
        streaming can still satisfy callers that request it.
        """
        response = self.generate(request)
        from sage.libs.llm.types import LLMStreamChunk  # local to avoid cycle

        yield LLMStreamChunk(delta=response.text, finish_reason=response.finish_reason)

    async def agenerate(self, request: LLMRequest) -> LLMResponse:
        """Async variant of :meth:`generate`.

        The default implementation runs :meth:`generate` in the calling thread.
        Override for non-blocking I/O.
        """
        return self.generate(request)

    async def astream(self, request: LLMRequest) -> AsyncGenerator[LLMStreamChunk, None]:
        """Async streaming variant.

        Default: yields the full response as a single chunk.
        """
        response = await self.agenerate(request)
        from sage.libs.llm.types import LLMStreamChunk

        yield LLMStreamChunk(delta=response.text, finish_reason=response.finish_reason)  # type: ignore[misc]

    # ------------------------------------------------------------------ #
    # Health / lifecycle
    # ------------------------------------------------------------------ #

    @abstractmethod
    def is_available(self) -> bool:
        """Return ``True`` if the backend can accept requests right now.

        Implementations should be cheap (e.g. check a cached flag or do a
        lightweight HTTP health probe).
        """

    def backend_name(self) -> str:
        """Human-readable backend identifier (used in logs and metrics)."""
        return type(self).__name__
