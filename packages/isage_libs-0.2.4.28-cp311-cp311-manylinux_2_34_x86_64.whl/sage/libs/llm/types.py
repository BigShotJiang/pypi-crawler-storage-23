"""SAGE-side canonical types for LLM service interaction.

These types define the SAGE↔LLM contract and are intentionally
independent of any specific LLM backend (sagellm, vllm, ollama, etc.).
They mirror the shape of sagellm-protocol but live in the SAGE namespace
so upstream SAGE packages need not depend on sagellm directly.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class LLMRole(str, Enum):  # noqa: UP042
    """Chat message role."""

    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"


@dataclass
class LLMMessage:
    """A single chat message."""

    role: LLMRole
    content: str


@dataclass
class LLMRequest:
    """Unified LLM service request.

    Supports two input modes:
    - *prompt*: a pre-formatted string.
    - *messages*: a list of :class:`LLMMessage` for chat-template rendering.

    The backend must accept at least one of ``prompt`` or ``messages``.
    When both are provided ``prompt`` takes precedence.
    """

    # At least one of prompt / messages must be set.
    prompt: str = ""
    messages: list[LLMMessage] = field(default_factory=list)

    model: str = ""
    max_tokens: int = 512
    temperature: float | None = None
    top_p: float | None = None
    stream: bool = False

    # Opaque extra options forwarded verbatim to the backend.
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMResponse:
    """Unified LLM service response."""

    text: str
    model: str = ""
    finish_reason: str = "stop"
    prompt_tokens: int = 0
    completion_tokens: int = 0

    # Opaque raw response kept for introspection/debugging.
    raw: Any = field(default=None, repr=False)


@dataclass
class LLMStreamChunk:
    """A single chunk in a streaming LLM response."""

    delta: str
    finish_reason: str | None = None
    raw: Any = field(default=None, repr=False)
