"""sage.libs.llm — SAGE/SageLLM integration protocol layer.

This sub-package defines the contract between the SAGE ecosystem and any
LLM inference backend (SageLLM, vLLM, Ollama, …).  SAGE operators depend
only on the interfaces defined here; concrete backends register themselves
at package import time via their own ``_register.py`` modules.

Layer position
--------------
``sage.libs.llm`` lives at **L3** (interface/algorithm layer) inside
``isage-libs``.  It must not import from ``sage.middleware``, ``sage.kernel``,
``sage.cli``, or any L4+ package.  Concrete backend packages (e.g. a future
``isagellm-sage-bridge``) live outside this package and depend on it.

Quick start
-----------
Generate text using whichever backend is installed::

    from sage.libs.llm import LLMRequest, default_backend

    backend = default_backend()
    response = backend.generate(LLMRequest(prompt="Hello!", max_tokens=64))
    print(response.text)

Use a specific backend::

    from sage.libs.llm import LLMRequest, get_backend

    backend = get_backend("sagellm")
    response = backend.generate(LLMRequest(prompt="Hello!", max_tokens=64))

Register a custom backend::

    from sage.libs.llm import register_backend
    from my_pkg import MyBackend

    register_backend("my_backend", MyBackend)

Discover the LLM gateway URL (for HTTP clients)::

    from sage.libs.llm.gateway import get_gateway_url

    upstream = get_gateway_url()   # e.g. "http://localhost:8889"
"""

from __future__ import annotations

from sage.libs.llm.adapters.openai_compat import OpenAICompatibleBackend
from sage.libs.llm.exceptions import (
    LLMBackendNotAvailableError,
    LLMBackendNotRegisteredError,
    LLMServiceError,
)
from sage.libs.llm.protocol import LLMServiceProtocol
from sage.libs.llm.registry import (
    default_backend,
    get_backend,
    list_backends,
    register_backend,
)
from sage.libs.llm.types import (
    LLMMessage,
    LLMRequest,
    LLMResponse,
    LLMRole,
    LLMStreamChunk,
)

__all__ = [
    # Types
    "LLMMessage",
    "LLMRequest",
    "LLMResponse",
    "LLMRole",
    "LLMStreamChunk",
    # Protocol
    "LLMServiceProtocol",
    # Registry
    "register_backend",
    "get_backend",
    "default_backend",
    "list_backends",
    # Exceptions
    "LLMServiceError",
    "LLMBackendNotAvailableError",
    "LLMBackendNotRegisteredError",
    # Built-in adapter
    "OpenAICompatibleBackend",
]
