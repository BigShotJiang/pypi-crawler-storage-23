"""OpenAI-compatible HTTP adapter — default built-in LLM backend.

Works with any OpenAI API-compatible server (SageLLM, vLLM, Ollama, etc.).
This adapter is automatically registered as "openai_compat" and used as
the default when no other backend has been explicitly registered.

SageLLM integration:
    SageLLM exposes an OpenAI-compatible REST API at
    ``http://host:{SagePorts.SAGELLM_SERVE_PORT}/v1``, so pointing this
    adapter at that URL is sufficient for the most common deployment scenario.
    The sagellm bridge package may additionally register a richer backend
    (e.g. using sagellm_core directly); this adapter remains the fallback.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from sage.common.config.ports import SagePorts
from sage.libs.llm.protocol import LLMServiceProtocol
from sage.libs.llm.types import LLMRequest, LLMResponse, LLMRole, LLMStreamChunk

logger = logging.getLogger(__name__)

_OPENAI_IMPORT_ERROR = (
    "The 'openai' package is required for OpenAICompatibleBackend. "
    "Install it with: pip install openai"
)


def _default_base_url() -> str:
    """Resolve default inference base URL from env or SagePorts."""
    env = os.getenv("SAGE_LLM_BASE_URL", "").strip()
    if env:
        return env.rstrip("/")
    return f"http://127.0.0.1:{SagePorts.SAGELLM_SERVE_PORT}/v1"


def _build_messages(request: LLMRequest) -> list[dict[str, str]] | None:
    """Convert LLMRequest messages to OpenAI API format, or None for prompt mode."""
    if request.messages:
        return [{"role": msg.role.value, "content": msg.content} for msg in request.messages]
    return None


class OpenAICompatibleBackend(LLMServiceProtocol):
    """LLM backend that calls any OpenAI-compatible REST endpoint.

    Args:
        base_url: Base URL of the inference server. Defaults to the SageLLM
            serve port or ``SAGE_LLM_BASE_URL`` env variable.
        api_key: API key sent in the ``Authorization`` header.
            Defaults to the ``SAGE_LLM_API_KEY`` env var, falling back to
            ``"EMPTY"`` (accepted by SageLLM and vLLM with no auth).
        model: Default model name. Can be overridden per request.
        timeout: HTTP request timeout in seconds.
    """

    def __init__(
        self,
        base_url: str = "",
        api_key: str = "",
        model: str = "",
        timeout: float = 120.0,
    ) -> None:
        self._base_url = base_url.rstrip("/") if base_url else _default_base_url()
        self._api_key = api_key or os.getenv("SAGE_LLM_API_KEY", "EMPTY")
        self._model = model
        self._timeout = timeout
        self._client: Any = None  # lazy-initialised

    # ---------------------------------------------------------------------- #
    # Internal helpers
    # ---------------------------------------------------------------------- #

    def _ensure_client(self) -> Any:
        if self._client is not None:
            return self._client
        try:
            from openai import OpenAI  # type: ignore[import-untyped]
        except ImportError as exc:
            raise ImportError(_OPENAI_IMPORT_ERROR) from exc
        self._client = OpenAI(base_url=self._base_url, api_key=self._api_key)
        logger.info("OpenAICompatibleBackend: client → %s", self._base_url)
        return self._client

    def _pick_model(self, request: LLMRequest) -> str:
        return request.model or self._model or "default"

    def _extra_params(self, request: LLMRequest) -> dict[str, Any]:
        params: dict[str, Any] = {}
        if request.temperature is not None:
            params["temperature"] = request.temperature
        if request.top_p is not None:
            params["top_p"] = request.top_p
        params.update(request.extra)
        return params

    def _chat_completion(self, client: Any, request: LLMRequest) -> LLMResponse:
        messages = _build_messages(request)
        if messages is None:
            # Wrap bare prompt as a user message
            messages = [{"role": LLMRole.USER.value, "content": request.prompt}]

        raw = client.chat.completions.create(
            model=self._pick_model(request),
            messages=messages,
            max_tokens=request.max_tokens,
            **self._extra_params(request),
        )
        choice = raw.choices[0]
        return LLMResponse(
            text=choice.message.content or "",
            model=raw.model,
            finish_reason=choice.finish_reason or "stop",
            prompt_tokens=getattr(raw.usage, "prompt_tokens", 0),
            completion_tokens=getattr(raw.usage, "completion_tokens", 0),
            raw=raw,
        )

    # ---------------------------------------------------------------------- #
    # LLMServiceProtocol
    # ---------------------------------------------------------------------- #

    def generate(self, request: LLMRequest) -> LLMResponse:  # noqa: D102
        client = self._ensure_client()
        return self._chat_completion(client, request)

    def stream(  # type: ignore[override]  # noqa: D102
        self, request: LLMRequest
    ):
        client = self._ensure_client()
        messages = _build_messages(request)
        if messages is None:
            messages = [{"role": LLMRole.USER.value, "content": request.prompt}]

        raw_stream = client.chat.completions.create(
            model=self._pick_model(request),
            messages=messages,
            max_tokens=request.max_tokens,
            stream=True,
            **self._extra_params(request),
        )
        for chunk in raw_stream:
            choice = chunk.choices[0] if chunk.choices else None
            delta = (choice.delta.content or "") if choice else ""
            finish = choice.finish_reason if choice else None
            yield LLMStreamChunk(delta=delta, finish_reason=finish, raw=chunk)

    def is_available(self) -> bool:  # noqa: D102
        try:
            client = self._ensure_client()
            client.models.list()
            return True
        except Exception:
            return False

    def backend_name(self) -> str:  # noqa: D102
        return f"openai_compat({self._base_url})"
