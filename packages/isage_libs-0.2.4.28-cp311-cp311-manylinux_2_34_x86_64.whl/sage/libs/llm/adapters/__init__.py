"""LLM adapter implementations for the SAGE LLM protocol.

Adapters translate between :class:`~sage.libs.llm.protocol.LLMServiceProtocol`
and specific backend APIs.  The :mod:`openai_compat` adapter ships with
``sage-libs`` because it only depends on the ``openai`` package which is
already a common dependency in SAGE environments.
"""

from __future__ import annotations

from sage.libs.llm.adapters.openai_compat import OpenAICompatibleBackend

__all__ = ["OpenAICompatibleBackend"]
