"""Exceptions raised by the SAGE LLM service layer."""

from __future__ import annotations


class LLMServiceError(RuntimeError):
    """Raised when an LLM backend fails to fulfil a request.

    Attributes:
        backend_name: Identifier of the backend that raised the error.
        cause: Optional underlying exception.
    """

    def __init__(
        self,
        message: str,
        backend_name: str = "",
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.backend_name = backend_name
        self.cause = cause

    def __str__(self) -> str:
        base = super().__str__()
        if self.backend_name:
            base = f"[{self.backend_name}] {base}"
        return base


class LLMBackendNotAvailableError(LLMServiceError):
    """Raised when a backend reports it is not available (e.g. service down)."""


class LLMBackendNotRegisteredError(KeyError):
    """Raised when a requested backend name has not been registered."""
