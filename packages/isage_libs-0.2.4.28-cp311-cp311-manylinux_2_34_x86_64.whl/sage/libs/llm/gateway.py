"""SAGE-side LLM gateway URL locator.

This module answers one question: **where is the LLM gateway running?**
It returns a *URL string*, never a Python object from another ecosystem.

Two ecosystems (SAGE and SageLLM) interact exclusively over HTTP.  SAGE components
that need to reach the LLM gateway use :func:`get_gateway_url` to discover the
configured upstream address and then communicate via the OpenAI-compatible HTTP
API.  There is no in-process ASGI mounting; sagellm-gateway always runs as its
own process.

URL resolution order for :func:`get_gateway_url`:

1. Explicitly registered URL via :func:`register_gateway_url`.
2. ``SAGE_LLM_GATEWAY_URL`` environment variable.
3. Default: ``http://localhost:{SagePorts.SAGELLM_GATEWAY}`` (port 8889).

Example — sage-edge resolving the upstream::

    from sage.libs.llm.gateway import get_gateway_url

    upstream = get_gateway_url()          # e.g. "http://localhost:8889"
    # forward HTTP requests to `upstream` via httpx

Example — an operator or test overriding the URL::

    from sage.libs.llm.gateway import register_gateway_url

    register_gateway_url("sagellm", "http://sagellm-svc:8889")
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)

# Registry: name → URL string
_gateway_url_registry: dict[str, str] = {}
_default_gateway_name: str | None = None


def register_gateway_url(name: str, url: str, *, set_as_default: bool = True) -> None:
    """Register the URL at which a named LLM gateway is reachable.

    Args:
        name: Unique gateway identifier (e.g. ``"sagellm"``).
        url: Base URL of the running gateway (e.g. ``"http://localhost:8889"``).
            Trailing slashes are stripped.
        set_as_default: If ``True`` (default), this URL becomes the one returned
            by :func:`get_gateway_url` when called without a *name*.
    """
    global _default_gateway_name
    _gateway_url_registry[name] = url.rstrip("/")
    if set_as_default or _default_gateway_name is None:
        _default_gateway_name = name
    logger.debug("LLMGateway: registered URL for %r → %s", name, url)


def get_gateway_url(name: str | None = None) -> str:
    """Return the base URL for the named (or default) LLM gateway.

    Resolution order:

    1. Explicitly registered URL for *name* (or the current default).
    2. ``SAGE_LLM_GATEWAY_URL`` environment variable.
    3. ``http://localhost:{SagePorts.SAGELLM_GATEWAY}`` (port 8889).

    Args:
        name: Specific gateway name.  Pass ``None`` to use the default.

    Returns:
        Base URL string without a trailing slash.

    Raises:
        KeyError: If an explicit *name* is given but no URL is registered for it.
    """
    target = name or _default_gateway_name
    if target is not None:
        if target in _gateway_url_registry:
            return _gateway_url_registry[target]
        if name is not None:
            raise KeyError(
                f"LLM gateway URL for {name!r} not registered. "
                f"Available: {list(_gateway_url_registry)}"
            )
        # target was the default name but not actually registered — fall through

    # Environment variable override
    env_url = os.getenv("SAGE_LLM_GATEWAY_URL")
    if env_url:
        return env_url.rstrip("/")

    # Hard default from SagePorts
    from sage.common.config.ports import SagePorts  # lazy to avoid circular

    return f"http://localhost:{SagePorts.SAGELLM_GATEWAY}"


__all__ = [
    "register_gateway_url",
    "get_gateway_url",
]
