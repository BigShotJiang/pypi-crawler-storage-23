"""LLM backend registry — factory/registry pattern for LLM service implementations.

Concrete backends (SageLLM, vLLM, Ollama, mock) register themselves here
via :func:`register_backend`. SAGE operators call :func:`get_backend` or
:func:`default_backend` without importing backend-specific code.

Registration is intentionally explicit: backends self-register in their
``_register.py`` module which is loaded when the package is installed.

Example (backend registration in sagellm bridge package):

    from sage.libs.llm.registry import register_backend
    from my_sagellm_adapter import SageLLMBackend

    register_backend("sagellm", SageLLMBackend)

Example (SAGE operator usage):

    from sage.libs.llm.registry import get_backend, default_backend

    backend = get_backend("sagellm")
    # or rely on whichever backend was registered first:
    backend = default_backend()
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from sage.libs.llm.protocol import LLMServiceProtocol

logger = logging.getLogger(__name__)

_registry: dict[str, type[LLMServiceProtocol]] = {}
_default_key: str | None = None


def register_backend(
    name: str,
    backend_cls: type[LLMServiceProtocol],
    *,
    set_as_default: bool = False,
) -> None:
    """Register an LLM backend implementation.

    Args:
        name: Unique backend identifier (e.g. ``"sagellm"``, ``"ollama"``).
        backend_cls: Class implementing :class:`~sage.libs.llm.protocol.LLMServiceProtocol`.
        set_as_default: If ``True``, this backend becomes the default returned
            by :func:`default_backend`.
    """
    global _default_key
    if name in _registry:
        logger.warning("LLMBackendRegistry: overwriting already-registered backend %r", name)
    _registry[name] = backend_cls
    if set_as_default or _default_key is None:
        _default_key = name
    logger.debug("LLMBackendRegistry: registered backend %r → %s", name, backend_cls.__name__)


def get_backend(name: str, **kwargs: Any) -> LLMServiceProtocol:
    """Instantiate and return a registered backend by name.

    Args:
        name: Backend identifier previously supplied to :func:`register_backend`.
        **kwargs: Forwarded verbatim to the backend constructor.

    Returns:
        An instance of the requested backend.

    Raises:
        KeyError: If *name* is not registered.
    """
    if name not in _registry:
        available = list(_registry)
        raise KeyError(
            f"LLM backend {name!r} is not registered. "
            f"Available: {available}. "
            "Ensure the backend package is installed and its _register.py was imported."
        )
    return _registry[name](**kwargs)


def default_backend(**kwargs: Any) -> LLMServiceProtocol:
    """Return an instance of the currently registered default backend.

    Falls back to :class:`~sage.libs.llm.adapters.openai_compat.OpenAICompatibleBackend`
    (pointing at the SageLLM serve port) when no backend has been registered.

    Raises:
        RuntimeError: If no backend is registered and the fallback cannot be
            constructed.
    """
    global _default_key
    if _default_key is None:
        # Auto-fall-back: register the built-in OpenAI-compatible adapter
        # pointing at the SageLLM serve port so SAGE works out-of-the-box
        # without explicit sagellm bridge registration.
        _register_openai_compat_fallback()

    if _default_key is None:
        raise RuntimeError(
            "No LLM backend has been registered. "
            "Install an LLM backend package (e.g. isagellm) and import it "
            "before requesting a default backend."
        )
    return get_backend(_default_key, **kwargs)


def list_backends() -> list[str]:
    """Return names of all registered backends."""
    return list(_registry)


def _register_openai_compat_fallback() -> None:
    """Auto-register the built-in OpenAI-compatible adapter as a fallback."""
    global _default_key
    try:
        from sage.libs.llm.adapters.openai_compat import OpenAICompatibleBackend

        register_backend("openai_compat", OpenAICompatibleBackend, set_as_default=True)
        logger.info(
            "LLMBackendRegistry: no backend registered; defaulting to "
            "OpenAICompatibleBackend (openai_compat)."
        )
    except ImportError:
        logger.warning(
            "LLMBackendRegistry: cannot import built-in OpenAI-compat adapter; "
            "install 'openai' to enable the default backend."
        )
        _default_key = None
