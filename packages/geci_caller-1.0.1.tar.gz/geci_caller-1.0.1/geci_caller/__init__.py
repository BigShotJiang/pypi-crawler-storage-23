"""A template Python module"""

__version__ = "1.0.1"
from .cli import *  # noqa
