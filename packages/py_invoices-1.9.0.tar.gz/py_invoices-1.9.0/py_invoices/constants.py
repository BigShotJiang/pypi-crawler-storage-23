from typing import Final

# Application Meta
APP_NAME: Final = "py-invoices"
APP_DISPLAY_NAME: Final = "Invoices Engine"
CLI_NAME: Final = "py-invoices"
CLI_ALIAS: Final = "inv"
