"""CLI wrapper for pyspark-mcp-server.

This module provides a smart CLI that handles both Spark and MCP arguments,
automatically locating the mcp_server.py script and invoking spark-submit.
"""

from __future__ import annotations

import os
import socket
import subprocess
import sys
from pathlib import Path

import click

# Common spark-submit options that take a value
SPARK_OPTIONS_WITH_VALUE = {
    "--master",
    "--deploy-mode",
    "--class",
    "--name",
    "--jars",
    "--packages",
    "--exclude-packages",
    "--repositories",
    "--py-files",
    "--files",
    "--conf",
    "--properties-file",
    "--driver-memory",
    "--driver-java-options",
    "--driver-library-path",
    "--driver-class-path",
    "--executor-memory",
    "--proxy-user",
    "--driver-cores",
    "--total-executor-cores",
    "--executor-cores",
    "--num-executors",
    "--principal",
    "--keytab",
    "--queue",
    "--archives",
}

# Spark-submit options that accept comma-separated values and should be merged
# when specified multiple times (spark-submit only uses the last occurrence)
SPARK_MERGEABLE_OPTIONS = {
    "--packages",
    "--jars",
    "--py-files",
    "--files",
    "--archives",
    "--exclude-packages",
    "--repositories",
}

# Spark-submit boolean flags (no value)
SPARK_FLAGS = {
    "--verbose",
    "--supervise",
    "--help",
    "--version",
}


def get_mcp_server_path() -> Path:
    """Get the path to mcp_server.py in the installed package."""
    return Path(__file__).parent / "mcp_server.py"


def parse_spark_and_mcp_args(args: tuple[str, ...]) -> tuple[list[str], list[str]]:
    """Separate spark-submit arguments from MCP server arguments.

    Args:
        args: All command line arguments

    Returns:
        Tuple of (spark_args, mcp_args)
    """
    spark_args: list[str] = []
    mcp_args: list[str] = []
    args_list = list(args)
    i = 0

    while i < len(args_list):
        arg = args_list[i]

        # Check if it's a spark option with value
        if arg in SPARK_OPTIONS_WITH_VALUE:
            spark_args.append(arg)
            if i + 1 < len(args_list):
                i += 1
                spark_args.append(args_list[i])
            else:
                # Missing required value for spark option
                raise click.UsageError(f"Option {arg} requires a value")
        # Check for --conf style with = (e.g., --conf spark.executor.memory=4g)
        elif arg.startswith("--conf="):
            spark_args.append(arg)
        # Check for other spark options with = (e.g., --master=local[*], --jars=foo.jar)
        elif any(arg.startswith(f"{opt}=") for opt in SPARK_OPTIONS_WITH_VALUE):
            spark_args.append(arg)
        # Check if it's a spark flag
        elif arg in SPARK_FLAGS:
            spark_args.append(arg)
        # Everything else goes to MCP
        else:
            mcp_args.append(arg)

        i += 1

    return spark_args, mcp_args


def merge_spark_args(spark_args: list[str]) -> list[str]:
    """Merge multiple occurrences of comma-separated spark-submit options.

    Options like --packages, --jars, etc. accept comma-separated values.
    When specified multiple times, spark-submit only uses the last one.
    This function merges all values into a single comma-separated string.

    Args:
        spark_args: List of spark-submit arguments (flag-value pairs)

    Returns:
        New list with mergeable options consolidated
    """
    collected: dict[str, list[str]] = {}
    other_args: list[str] = []
    merge_order: list[str] = []

    i = 0
    while i < len(spark_args):
        arg = spark_args[i]

        # Check for --option=value form
        matched_equals = False
        for opt in SPARK_MERGEABLE_OPTIONS:
            if arg.startswith(f"{opt}="):
                value = arg[len(opt) + 1 :]
                if opt not in collected:
                    merge_order.append(opt)
                    collected[opt] = []
                collected[opt].append(value)
                matched_equals = True
                break

        if matched_equals:
            i += 1
            continue

        # Check for --option value form (separated)
        if arg in SPARK_MERGEABLE_OPTIONS:
            if i + 1 < len(spark_args):
                value = spark_args[i + 1]
                if arg not in collected:
                    merge_order.append(arg)
                    collected[arg] = []
                collected[arg].append(value)
                i += 2
                continue
            else:
                other_args.append(arg)
                i += 1
                continue

        other_args.append(arg)
        i += 1

    # Reconstruct: merged options first (in order of first occurrence), then others
    result: list[str] = []
    for opt in merge_order:
        merged_value = ",".join(collected[opt])
        result.extend([opt, merged_value])
    result.extend(other_args)

    return result


@click.command(context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.option(
    "--master",
    default="local[*]",
    help="Spark master URL (default: local[*])",
)
@click.option(
    "--host",
    default="127.0.0.1",
    help="MCP server host address (default: 127.0.0.1)",
)
@click.option(
    "--port",
    default=8090,
    type=click.IntRange(1, 65535),
    help="MCP server port number (default: 8090)",
)
@click.option(
    "--spark-submit",
    "spark_submit_path",
    default="spark-submit",
    help="Path to spark-submit executable (default: spark-submit)",
)
@click.option(
    "--aws-profile",
    default=None,
    help="AWS profile name from ~/.aws/config to use for S3 access. "
    "Use 'default' for the default profile.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Print the spark-submit command without executing it",
)
@click.pass_context
def main(  # noqa: C901
    ctx: click.Context,
    master: str,
    host: str,
    port: int,
    spark_submit_path: str,
    aws_profile: str | None,
    dry_run: bool,
) -> None:
    """Start the PySpark MCP server via spark-submit.

    This command wraps spark-submit to launch the MCP server with proper
    Spark configuration. All standard spark-submit options are supported.

    Examples:

        # Basic local mode
        pyspark-mcp --master "local[4]" --host 0.0.0.0 --port 8090

        # With additional Spark configuration
        pyspark-mcp --master "local[*]" --conf spark.driver.memory=4g

        # YARN cluster mode
        pyspark-mcp --master yarn --deploy-mode client --num-executors 4

        # With additional JARs
        pyspark-mcp --master "local[*]" --jars /path/to/connector.jar

        # With S3 access using AWS profile from ~/.aws/config
        pyspark-mcp --master "local[*]" \\
            --packages org.apache.hadoop:hadoop-aws:3.3.4 \\
            --aws-profile default

        # With S3 access using a named AWS profile
        pyspark-mcp --master "local[*]" \\
            --packages org.apache.hadoop:hadoop-aws:3.3.4 \\
            --aws-profile my-profile
    """
    # Get path to mcp_server.py
    mcp_server_path = get_mcp_server_path()

    if not mcp_server_path.exists():
        click.echo(f"Error: Could not find mcp_server.py at {mcp_server_path}", err=True)
        sys.exit(1)

    # Parse extra args to separate Spark args from any additional MCP args
    spark_args, extra_mcp_args = parse_spark_and_mcp_args(tuple(ctx.args))
    spark_args = merge_spark_args(spark_args)

    # Build the spark-submit command
    cmd = [
        spark_submit_path,
        "--master",
        master,
    ]

    # Add AWS profile configuration if specified
    # Uses DefaultAWSCredentialsProviderChain which reads from:
    # 1. Environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
    # 2. Java system properties
    # 3. Web Identity Token credentials
    # 4. Profile credentials (~/.aws/credentials and ~/.aws/config via AWS_PROFILE env var)
    # 5. EC2 instance credentials
    if aws_profile is not None:
        cmd.extend(
            [
                "--conf",
                "spark.hadoop.fs.s3a.aws.credentials.provider="
                "com.amazonaws.auth.DefaultAWSCredentialsProviderChain",
            ]
        )

    # Default configs for long-running server stability (user's --conf can override)
    cmd.extend(
        [
            "--conf",
            "spark.network.timeout=604800s",
            "--conf",
            "spark.executor.heartbeatInterval=300s",
            "--conf",
            "spark.ui.enabled=false",
        ]
    )

    # Add any additional spark args
    # Remove --master and its value from spark_args if --master was provided via Click option
    filtered_spark_args = []
    skip_next = False
    for i, arg in enumerate(spark_args):
        if skip_next:
            skip_next = False
            continue
        if arg == "--master":
            # Skip this and the next value
            skip_next = True
            continue
        filtered_spark_args.append(arg)
    cmd.extend(filtered_spark_args)

    # Add the script path
    cmd.append(str(mcp_server_path))

    # Add MCP server arguments
    cmd.extend(["--host", host, "--port", str(port)])

    # Add any extra MCP args, filtering out --host and --port (and their values)
    def filter_host_port(args: list[str]) -> list[str]:
        filtered = []
        skip_next = False
        for i, arg in enumerate(args):
            if skip_next:
                skip_next = False
                continue
            if arg in ("--host", "--port"):
                skip_next = True
                continue
            if arg.startswith("--host=") or arg.startswith("--port="):
                continue
            filtered.append(arg)
        return filtered

    cmd.extend(filter_host_port(extra_mcp_args))

    if dry_run:
        click.echo(" ".join(cmd))
        return

    # Check port availability before starting spark-submit (which starts the JVM)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((host, port))
    except OSError:
        click.echo(
            f"Error: Port {port} is already in use on {host}. "
            f"Use --port to specify a different port, or stop the process using port {port}.",
            err=True,
        )
        sys.exit(1)

    # Set up environment - ensure PYTHONPATH includes the package
    env = os.environ.copy()
    package_dir = str(Path(mcp_server_path).parent)
    env["PYTHONPATH"] = package_dir + os.pathsep + env.get("PYTHONPATH", "")

    # Set AWS_PROFILE environment variable if specified
    if aws_profile is not None:
        env["AWS_PROFILE"] = aws_profile

    # Execute spark-submit
    try:
        result = subprocess.run(cmd, env=env)
        sys.exit(result.returncode)
    except FileNotFoundError:
        click.echo(
            f"Error: Could not find '{spark_submit_path}'. "
            "Make sure Spark is installed and spark-submit is in your PATH, "
            "or use --spark-submit to specify the path.",
            err=True,
        )
        sys.exit(1)
    except KeyboardInterrupt:
        click.echo(
            "\n"
            "    *    .  *       .             *\n"
            "         *       *        .   *     .  *\n"
            "   .  *     Spark stopped.     .\n"
            "        .   Session ended cleanly.  *\n"
            "     *        Goodbye!       .     *\n"
            "  .      *        .    *   .         .\n"
        )
        sys.exit(0)


if __name__ == "__main__":
    main()
