"""Compliance assessment and reporting for AvaKill policies."""
