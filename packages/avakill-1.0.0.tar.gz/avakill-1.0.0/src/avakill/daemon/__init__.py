"""AvaKill daemon — persistent policy evaluation over Unix domain socket."""
