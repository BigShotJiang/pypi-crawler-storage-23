"""CLI commands for AvaKill."""
