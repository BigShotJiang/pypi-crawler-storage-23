"""Allow running ``python -m avakill``."""

from avakill.cli.main import cli

cli()
