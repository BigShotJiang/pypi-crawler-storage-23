"""A mixin for remote engines."""


class RemoteMixin:
    """Mixin for remote engine abstractions."""
