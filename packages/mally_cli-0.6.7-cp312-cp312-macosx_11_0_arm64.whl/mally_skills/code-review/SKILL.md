---
name: code-review
description: Systematic code review with security, performance, and style checks
---

# Code Review

Review the code changes systematically using this checklist.

## 1. Correctness
- Does the code do what it claims to do?
- Are edge cases handled (empty input, nulls, boundary values)?
- Are error paths handled gracefully?

## 2. Security
- No hardcoded secrets, API keys, or credentials
- User input is validated and sanitized
- No SQL injection, XSS, or command injection vectors
- File paths are validated (no path traversal)
- Permissions and auth checks are in place

## 3. Performance
- No unnecessary loops or redundant computation
- Database queries are efficient (no N+1 queries)
- Large data sets are paginated or streamed
- No blocking calls in async code paths

## 4. Readability
- Clear naming (variables, functions, classes)
- Functions are focused (single responsibility)
- Complex logic has comments explaining *why*
- No dead code or commented-out blocks

## 5. Testing
- Are new code paths covered by tests?
- Are edge cases tested?
- Do tests assert behavior, not implementation?

## Output Format

For each issue found, report:
- **File**: `path/to/file.py:line`
- **Severity**: critical / warning / nit
- **Issue**: What's wrong
- **Fix**: Suggested change
