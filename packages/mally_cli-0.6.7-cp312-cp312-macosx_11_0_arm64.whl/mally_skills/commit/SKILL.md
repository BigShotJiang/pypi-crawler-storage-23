---
name: commit
description: Create well-structured git commits with conventional commit messages
---

# Git Commit

Create a well-structured git commit by following these steps.

## Steps

1. **Check status**: Run `git status` and `git diff --staged` to see what's being committed.
2. **Review changes**: Read the changed files to understand the full scope.
3. **Stage files**: Stage relevant files individually (`git add <file>`). Don't use `git add .` blindly.
4. **Write message**: Use the conventional commit format below.
5. **Commit**: Run `git commit` with the message.

## Conventional Commit Format

```
<type>(<scope>): <subject>

<body>
```

### Types
- **feat**: New feature
- **fix**: Bug fix
- **refactor**: Code change that neither fixes a bug nor adds a feature
- **docs**: Documentation only
- **test**: Adding or updating tests
- **chore**: Build process, dependencies, CI changes
- **perf**: Performance improvement
- **style**: Formatting, whitespace (no code change)

### Rules
- Subject line: imperative mood, lowercase, no period, max 72 chars
- Body: explain *what* and *why*, not *how*
- One logical change per commit — split unrelated changes

### Examples

```
feat(auth): add OAuth2 login flow

Adds Google and GitHub OAuth2 providers with PKCE.
Tokens are stored in the system keychain.
```

```
fix(api): handle empty response from payment gateway

The gateway returns 200 with empty body on timeout.
Previously this raised an unhandled JSONDecodeError.
```
