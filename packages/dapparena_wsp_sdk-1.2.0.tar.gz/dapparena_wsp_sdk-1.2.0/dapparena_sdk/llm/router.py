"""하이브리드 LLM 라우터 (S2-07)

PII 감지, 작업 복잡도, 사용 가능한 모델에 따라
로컬(Ollama) 또는 외부(OpenAI/Claude) LLM을 자동 선택합니다.
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from typing import Any

from .connector import LLMConnector, OllamaConnector

logger = logging.getLogger("dapparena_sdk.llm.router")


@dataclass
class RoutingDecision:
    """라우팅 결정 결과."""
    provider: str  # "ollama", "openai", "claude"
    model: str
    reason: str
    is_local: bool


# PII 패턴
PII_PATTERNS = [
    (re.compile(r"(?<!\d)01[016789][-\s.]?\d{3,4}[-\s.]?\d{4}(?!\d)"), "전화번호"),
    (re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"), "이메일"),
    (re.compile(r"(?<!\d)\d{6}[-\s]?\d{7}(?!\d)"), "주민번호"),
    (re.compile(r"(?<!\d)20\d{2}[-\s]?\d{5,6}(?!\d)"), "학번"),
    (re.compile(r"(?<!\d)\d{3}[-\s]?\d{2}[-\s]?\d{5}(?!\d)"), "사업자번호"),
]


class LLMRouter:
    """하이브리드 LLM 라우터.

    Example:
        router = LLMRouter()
        response = await router.generate("블록체인 설명해줘")
        response = await router.generate("학생 010-1234-5678의 과제 평가")
        # → PII 포함 → 로컬 LLM 사용
    """

    def __init__(
        self,
        ollama_model: str = "llama3",
        ollama_host: str = "http://localhost:11434",
        openai_api_key: str = "",
        openai_model: str = "gpt-4o-mini",
        prefer_local: bool = True,
    ):
        self.ollama_model = ollama_model
        self.ollama_host = ollama_host
        self.openai_api_key = openai_api_key or os.getenv("OPENAI_API_KEY", "")
        self.openai_model = openai_model
        self.prefer_local = prefer_local
        self._connector = OllamaConnector(model=ollama_model, host=ollama_host)

    def route(self, prompt: str) -> RoutingDecision:
        """프롬프트를 분석하여 최적의 LLM을 선택합니다.

        Rules:
            1. PII 포함 → 반드시 로컬 (Ollama)
            2. prefer_local=True → Ollama 우선
            3. Ollama 사용 불가 + OpenAI 키 있음 → OpenAI
            4. 기본: Ollama
        """
        # 1. PII 감지 → 로컬 강제
        pii_types = self._detect_pii(prompt)
        if pii_types:
            logger.info(f"🛡️ PII 감지 ({', '.join(pii_types)}) → 로컬 LLM 강제")
            return RoutingDecision(
                provider="ollama",
                model=self.ollama_model,
                reason=f"PII 감지: {', '.join(pii_types)}",
                is_local=True,
            )

        # 2. 기본: 로컬 우선
        if self.prefer_local:
            return RoutingDecision(
                provider="ollama",
                model=self.ollama_model,
                reason="로컬 우선 정책",
                is_local=True,
            )

        # 3. 외부 API 사용 가능 시
        if self.openai_api_key:
            return RoutingDecision(
                provider="openai",
                model=self.openai_model,
                reason="외부 API 사용 가능",
                is_local=False,
            )

        # 4. 폴백: 로컬
        return RoutingDecision(
            provider="ollama",
            model=self.ollama_model,
            reason="폴백 — 외부 API 키 없음",
            is_local=True,
        )

    async def generate(
        self,
        prompt: str,
        system_prompt: str = "",
        temperature: float = 0.4,
        max_tokens: int = 2048,
    ) -> str:
        """프롬프트를 LLM에 전달하고 응답을 반환합니다.

        자동으로 라우팅 결정을 수행한 후 적절한 LLM을 호출합니다.
        """
        decision = self.route(prompt)
        logger.info(f"🤖 LLM 라우팅: {decision.provider}/{decision.model} ({decision.reason})")

        if decision.provider == "ollama":
            return await self._connector.generate(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=temperature,
            )

        if decision.provider == "openai" and self.openai_api_key:
            return await self._generate_openai(
                prompt=prompt,
                system_prompt=system_prompt,
                model=decision.model,
                temperature=temperature,
                max_tokens=max_tokens,
            )

        # 최종 폴백
        return await self._connector.generate(
            prompt=prompt,
            system_prompt=system_prompt,
            temperature=temperature,
        )

    async def _generate_openai(
        self,
        prompt: str,
        system_prompt: str,
        model: str,
        temperature: float,
        max_tokens: int,
    ) -> str:
        """OpenAI API 호출."""
        import httpx

        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                resp = await client.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers={
                        "Authorization": f"Bearer {self.openai_api_key}",
                        "Content-Type": "application/json",
                    },
                    json={
                        "model": model,
                        "messages": messages,
                        "temperature": temperature,
                        "max_tokens": max_tokens,
                    },
                )
                resp.raise_for_status()
                data = resp.json()
                return data["choices"][0]["message"]["content"]
        except Exception as e:
            logger.warning(f"OpenAI 호출 실패, Ollama 폴백: {e}")
            return await self._connector.generate(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=temperature,
            )

    @staticmethod
    def _detect_pii(text: str) -> list[str]:
        """텍스트에서 PII를 감지합니다."""
        found = []
        for pattern, pii_type in PII_PATTERNS:
            if pattern.search(text):
                found.append(pii_type)
        return found
