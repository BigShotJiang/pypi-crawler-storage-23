"""A2A v2 Client — 다른 에이전트에 Task를 전송하고 결과를 수신 (S1-02)"""

from __future__ import annotations

import httpx

from .models import Task


class A2AClientV2:
    """A2A v2 클라이언트 — Task 기반 에이전트 간 통신.

    Example:
        client = A2AClientV2()
        task = Task(message="논문 검색해줘")
        result = await client.send_task("http://localhost:8101", task)
        print(result.state, result.artifacts)
    """

    def __init__(self, timeout: float = 120.0, api_key: str = ""):
        self._timeout = timeout
        self._api_key = api_key

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self._api_key:
            headers["X-API-Key"] = self._api_key
        return headers

    async def send_task(self, agent_url: str, task: Task) -> Task:
        """에이전트에 Task를 전송하고 완료된 Task를 수신합니다.

        Args:
            agent_url: 대상 에이전트 base URL (예: "http://localhost:8101")
            task: 전송할 Task 객체

        Returns:
            처리 완료된 Task (state, artifacts 포함)
        """
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{agent_url}/a2a/tasks/send",
                json=task.to_dict(),
                headers=self._headers(),
            )
            resp.raise_for_status()
            return Task.from_dict(resp.json())

    async def get_task(self, agent_url: str, task_id: str) -> Task:
        """Task ID로 상태를 조회합니다.

        Args:
            agent_url: 대상 에이전트 base URL
            task_id: 조회할 Task ID

        Returns:
            현재 상태의 Task 객체
        """
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(
                f"{agent_url}/a2a/tasks/{task_id}",
                headers=self._headers(),
            )
            resp.raise_for_status()
            return Task.from_dict(resp.json())

    async def cancel_task(self, agent_url: str, task_id: str) -> Task:
        """실행 중인 Task를 취소합니다.

        Args:
            agent_url: 대상 에이전트 base URL
            task_id: 취소할 Task ID

        Returns:
            취소 처리된 Task 객체
        """
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                f"{agent_url}/a2a/tasks/{task_id}/cancel",
                headers=self._headers(),
            )
            resp.raise_for_status()
            return Task.from_dict(resp.json())

    async def health(self, agent_url: str) -> dict:
        """에이전트 헬스체크.

        Args:
            agent_url: 대상 에이전트 base URL

        Returns:
            헬스 상태 딕셔너리
        """
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                f"{agent_url}/health",
                headers=self._headers(),
            )
            resp.raise_for_status()
            return resp.json()
