"""BaseAgentV2 — WSP 에이전트 추상 기본 클래스 (S1-05, S3-13 업데이트)

Task 기반 handle_task() 인터페이스를 정의합니다.
Slice 3: blockchain_config로 DID/지갑/x402 연동 지원.
"""

from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod
from typing import Any

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .a2a.agent_card import agent_card_router, register_agent_card
from .a2a.models import AgentCard, Artifact, Task, TaskState
from .a2a.server import register_agent, router as a2a_router

logger = logging.getLogger("dapparena_sdk.base_agent")


class BaseAgentV2(ABC):
    """WSP 에이전트 기본 클래스.

    개발자는 이 클래스를 상속하고 handle_task()를 구현합니다.

    Example:
        class CheolsuAgent(BaseAgentV2):
            async def handle_task(self, task: Task) -> Task:
                # LLM으로 연구 수행
                result = await self.llm_call(task.message)
                task.artifacts.append(Artifact(
                    name="research_summary",
                    mime_type="application/json",
                    data=result,
                ))
                return task
    """

    def __init__(
        self,
        name: str,
        description: str = "",
        port: int = 8080,
        skills: list[str] | None = None,
        host: str = "0.0.0.0",
        blockchain_config: dict[str, Any] | None = None,
    ):
        self.name = name
        self.description = description
        self.port = port
        self.skills = skills or []
        self.host = host
        self._start_time = time.time()

        # Slice 3: 블록체인 설정
        self.blockchain_config = blockchain_config or {}
        self.did_manager = None
        self.tba_manager = None
        self.x402_handler = None

        if self.blockchain_config:
            self._init_blockchain()

    def _init_blockchain(self) -> None:
        """블록체인 모듈을 초기화합니다 (DID, TBA, x402)."""
        cfg = self.blockchain_config
        agent_id = cfg.get("agent_id", 0)

        try:
            from .identity import DIDManager
            self.did_manager = DIDManager(
                agent_name=self.name,
                agent_id=agent_id,
            )
            logger.info(f"🆔 DID: {self.did_manager.did_string}")
        except Exception as e:
            logger.warning(f"DID 초기화 실패: {e}")

        try:
            from .wallet import TBAManager
            self.tba_manager = TBAManager(
                rpc_url=cfg.get("rpc_url", "https://rpc.worldland.foundation"),
                registry_address=cfg.get("erc6551_registry", ""),
                implementation_address=cfg.get("tba_implementation", ""),
                nft_contract=cfg.get("nft_contract", ""),
                chain_id=cfg.get("chain_id", 103),
            )
        except Exception as e:
            logger.warning(f"TBA 초기화 실패: {e}")

        try:
            from .x402 import X402PaymentHandler
            tba_addr = ""
            if self.tba_manager and agent_id:
                tba_addr = self.tba_manager.compute_tba_address(agent_id)
            self.x402_handler = X402PaymentHandler(
                payer_tba=tba_addr,
                agent_id=agent_id,
                x402_contract=cfg.get("x402_contract", ""),
                rpc_url=cfg.get("rpc_url", "https://rpc.worldland.foundation"),
            )
        except Exception as e:
            logger.warning(f"x402 초기화 실패: {e}")

    @abstractmethod
    async def handle_task(self, task: Task) -> Task:
        """Task를 처리하고 결과 Task를 반환합니다.

        Args:
            task: 입력 Task (message + 이전 단계 artifacts)

        Returns:
            처리 완료된 Task (artifacts 추가됨)
        """
        ...

    def get_agent_card(self) -> AgentCard:
        """에이전트 능력 명세를 반환합니다."""
        return AgentCard(
            name=self.name,
            description=self.description,
            url=f"http://{self.host}:{self.port}",
            skills=self.skills,
        )

    def _create_app(self) -> FastAPI:
        """FastAPI 앱을 구성합니다."""
        app = FastAPI(title=f"WSP Agent: {self.name}", version="1.2.0")

        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )

        # 에이전트 등록
        register_agent(self)
        register_agent_card(self)

        # 라우터 포함
        app.include_router(a2a_router)
        app.include_router(agent_card_router)

        # 헬스체크
        @app.get("/health")
        async def health():
            result = {
                "status": "online",
                "agent_name": self.name,
                "uptime_seconds": round(time.time() - self._start_time, 1),
            }
            if self.did_manager:
                result["did"] = self.did_manager.did_string
            return JSONResponse(content=result)

        # DID 엔드포인트 (Slice 3)
        if self.did_manager:
            @app.get("/did")
            async def did_document():
                doc = self.did_manager.create_did_document(
                    endpoint=f"http://{self.host}:{self.port}"
                )
                return JSONResponse(content=doc.to_dict())

        return app

    def run(self, host: str | None = None, port: int | None = None) -> None:
        """에이전트 서버를 시작합니다.

        Args:
            host: 바인딩 호스트 (기본: self.host)
            port: 바인딩 포트 (기본: self.port)
        """
        _host = host or self.host
        _port = port or self.port
        app = self._create_app()
        logger.info(f"🚀 {self.name} 에이전트 시작: http://{_host}:{_port}")
        uvicorn.run(app, host=_host, port=_port, log_level="info")

