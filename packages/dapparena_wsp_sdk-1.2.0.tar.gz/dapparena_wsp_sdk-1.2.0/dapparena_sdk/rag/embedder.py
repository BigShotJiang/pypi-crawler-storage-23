"""텍스트 임베딩 생성기 (S2-06)

Ollama의 임베딩 모델을 사용하여 텍스트를 벡터로 변환합니다.
Ollama가 없으면 간단한 해시 기반 폴백을 사용합니다.
"""

from __future__ import annotations

import hashlib
import logging
import os
from typing import Any

logger = logging.getLogger("dapparena_sdk.rag.embedder")

OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://localhost:11434")
EMBED_MODEL = os.getenv("OLLAMA_EMBED_MODEL", "nomic-embed-text")


class Embedder:
    """텍스트 임베딩 생성기.

    Example:
        embedder = Embedder()
        vector = await embedder.embed("블록체인 기초")
        vectors = await embedder.embed_batch(["문장1", "문장2"])
    """

    def __init__(self, model: str = EMBED_MODEL, host: str = OLLAMA_HOST):
        self.model = model
        self.host = host
        self._use_ollama = True

    async def embed(self, text: str) -> list[float]:
        """단일 텍스트를 임베딩 벡터로 변환합니다.

        Args:
            text: 입력 텍스트

        Returns:
            임베딩 벡터 (float 리스트)
        """
        if self._use_ollama:
            try:
                import ollama
                response = ollama.embed(model=self.model, input=text)
                embeddings = response.get("embeddings", [])
                if embeddings:
                    return embeddings[0]
            except Exception as e:
                logger.warning(f"Ollama 임베딩 실패, 해시 폴백 사용: {e}")
                self._use_ollama = False

        # 해시 기반 폴백 (768차원)
        return self._hash_embed(text)

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """여러 텍스트를 일괄 임베딩합니다."""
        results = []
        for text in texts:
            vec = await self.embed(text)
            results.append(vec)
        return results

    @staticmethod
    def _hash_embed(text: str, dim: int = 768) -> list[float]:
        """해시 기반 간이 임베딩 (폴백용).

        의미적 유사도는 제공하지 않지만 인터페이스 호환성을 유지합니다.
        """
        h = hashlib.sha256(text.encode()).digest()
        # 해시를 반복 확장하여 dim 차원 벡터 생성
        extended = h * ((dim * 4 // len(h)) + 1)
        vector = []
        for i in range(dim):
            byte_val = extended[i * 4] ^ extended[i * 4 + 1]
            vector.append((byte_val / 255.0) * 2 - 1)  # [-1, 1] 범위 정규화
        return vector

    @property
    def dimension(self) -> int:
        """임베딩 차원 수."""
        return 768
