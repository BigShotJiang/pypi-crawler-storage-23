"""ChromaDB 벡터 저장소 래퍼 (S2-06)

문서를 벡터 DB에 색인하고 유사도 검색을 수행합니다.
ChromaDB가 없으면 인메모리 폴백을 사용합니다.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("dapparena_sdk.rag.vectorstore")


@dataclass
class SearchResult:
    """벡터 검색 결과."""
    id: str
    text: str
    metadata: dict[str, Any]
    score: float  # 0~1 유사도 점수


class VectorStore:
    """ChromaDB 기반 벡터 저장소.

    Example:
        store = VectorStore(collection_name="papers")
        store.index([
            {"text": "블록체인 기초...", "metadata": {"source": "paper1"}},
        ])
        results = store.search("합의 알고리즘", top_k=3)
    """

    def __init__(
        self,
        collection_name: str = "default",
        persist_directory: str | None = None,
    ):
        self.collection_name = collection_name
        self._collection = None
        self._client = None
        self._fallback_docs: list[dict[str, Any]] = []  # ChromaDB 없을 때 사용

        try:
            import chromadb

            if persist_directory:
                self._client = chromadb.PersistentClient(path=persist_directory)
            else:
                self._client = chromadb.Client()

            self._collection = self._client.get_or_create_collection(
                name=collection_name,
                metadata={"hnsw:space": "cosine"},
            )
            logger.info(f"📦 ChromaDB 컬렉션 생성: {collection_name}")

        except ImportError:
            logger.warning("ChromaDB 미설치 — 인메모리 폴백 사용 (pip install chromadb)")

    def index(self, documents: list[dict[str, Any]]) -> int:
        """문서를 벡터 DB에 색인합니다.

        Args:
            documents: [{"text": "...", "metadata": {...}}, ...]

        Returns:
            색인된 문서 수
        """
        if not documents:
            return 0

        ids = [str(uuid.uuid4()) for _ in documents]
        texts = [d["text"] for d in documents]
        metadatas = [d.get("metadata", {}) for d in documents]

        if self._collection is not None:
            self._collection.add(
                ids=ids,
                documents=texts,
                metadatas=metadatas,
            )
            logger.info(f"📦 {len(documents)}개 문서 색인 완료 ({self.collection_name})")
        else:
            # 인메모리 폴백
            for doc_id, text, meta in zip(ids, texts, metadatas):
                self._fallback_docs.append({
                    "id": doc_id,
                    "text": text,
                    "metadata": meta,
                })
            logger.info(f"📦 {len(documents)}개 문서 인메모리 색인 ({self.collection_name})")

        return len(documents)

    def search(self, query: str, top_k: int = 3) -> list[SearchResult]:
        """유사도 검색을 수행합니다.

        Args:
            query: 검색 쿼리
            top_k: 반환할 최대 결과 수

        Returns:
            SearchResult 리스트 (유사도 순)
        """
        if self._collection is not None:
            results = self._collection.query(
                query_texts=[query],
                n_results=min(top_k, self._collection.count() or 1),
            )

            search_results = []
            if results["documents"] and results["documents"][0]:
                for i, doc in enumerate(results["documents"][0]):
                    distance = results["distances"][0][i] if results.get("distances") else 0.0
                    score = max(0.0, 1.0 - distance)  # cosine distance → similarity
                    search_results.append(SearchResult(
                        id=results["ids"][0][i],
                        text=doc,
                        metadata=results["metadatas"][0][i] if results.get("metadatas") else {},
                        score=round(score, 4),
                    ))
            return search_results

        # 인메모리 폴백: 단순 키워드 매칭
        query_words = set(query.lower().split())
        scored = []
        for doc in self._fallback_docs:
            doc_words = set(doc["text"].lower().split())
            overlap = len(query_words & doc_words)
            if overlap > 0:
                score = min(1.0, overlap / max(len(query_words), 1) * 0.8)
                scored.append((score, doc))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [
            SearchResult(
                id=doc["id"],
                text=doc["text"],
                metadata=doc["metadata"],
                score=round(score, 4),
            )
            for score, doc in scored[:top_k]
        ]

    def delete(self, ids: list[str]) -> int:
        """문서를 삭제합니다."""
        if self._collection is not None:
            self._collection.delete(ids=ids)
            return len(ids)

        before = len(self._fallback_docs)
        self._fallback_docs = [d for d in self._fallback_docs if d["id"] not in set(ids)]
        return before - len(self._fallback_docs)

    def count(self) -> int:
        """색인된 문서 수를 반환합니다."""
        if self._collection is not None:
            return self._collection.count()
        return len(self._fallback_docs)

    def clear(self) -> None:
        """컬렉션의 모든 문서를 삭제합니다."""
        if self._client is not None:
            self._client.delete_collection(self.collection_name)
            self._collection = self._client.get_or_create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": "cosine"},
            )
        self._fallback_docs.clear()
