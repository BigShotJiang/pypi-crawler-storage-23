"""MCP Server — FastAPI 기반 MCP 서버 프레임워크 (S2-01)

Tool과 Resource를 등록하여 에이전트에게 외부 데이터 접근을 제공합니다.
데코레이터(@mcp_tool, @mcp_resource)로 간단히 Tool/Resource를 등록할 수 있습니다.
"""

from __future__ import annotations

import inspect
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable

from fastapi import APIRouter, FastAPI
from fastapi.responses import JSONResponse

logger = logging.getLogger("dapparena_sdk.mcp.server")


# ── 데이터 모델 ──

@dataclass
class ToolDefinition:
    """MCP Tool 정의."""
    name: str
    description: str
    parameters: dict[str, Any] = field(default_factory=dict)
    handler: Callable[..., Awaitable[Any]] | None = None


@dataclass
class ResourceDefinition:
    """MCP Resource 정의."""
    uri: str
    name: str
    description: str
    mime_type: str = "application/json"
    handler: Callable[..., Awaitable[Any]] | None = None


# ── 전역 레지스트리 ──

_tool_registry: dict[str, ToolDefinition] = {}
_resource_registry: dict[str, ResourceDefinition] = {}


def mcp_tool(
    name: str | None = None,
    description: str = "",
    parameters: dict[str, Any] | None = None,
):
    """MCP Tool 등록 데코레이터.

    Example:
        @mcp_tool(name="search_papers", description="논문 검색")
        async def search_papers(query: str, max_results: int = 5):
            ...
    """
    def decorator(func: Callable) -> Callable:
        tool_name = name or func.__name__
        tool_desc = description or (func.__doc__ or "").strip().split("\n")[0]

        # 파라미터 자동 추출
        sig = inspect.signature(func)
        auto_params = {}
        for param_name, param in sig.parameters.items():
            param_type = "string"
            if param.annotation is int:
                param_type = "integer"
            elif param.annotation is float:
                param_type = "number"
            elif param.annotation is bool:
                param_type = "boolean"
            auto_params[param_name] = {
                "type": param_type,
                "required": param.default is inspect.Parameter.empty,
            }

        _tool_registry[tool_name] = ToolDefinition(
            name=tool_name,
            description=tool_desc,
            parameters=parameters or auto_params,
            handler=func,
        )
        logger.debug(f"MCP Tool 등록: {tool_name}")
        return func

    return decorator


def mcp_resource(
    uri: str,
    name: str | None = None,
    description: str = "",
    mime_type: str = "application/json",
):
    """MCP Resource 등록 데코레이터.

    Example:
        @mcp_resource(uri="schedule://2024", name="강의 스케줄")
        async def get_schedule(year: int = 2024):
            ...
    """
    def decorator(func: Callable) -> Callable:
        res_name = name or func.__name__
        res_desc = description or (func.__doc__ or "").strip().split("\n")[0]
        _resource_registry[uri] = ResourceDefinition(
            uri=uri,
            name=res_name,
            description=res_desc,
            mime_type=mime_type,
            handler=func,
        )
        logger.debug(f"MCP Resource 등록: {uri}")
        return func

    return decorator


# ── FastAPI 라우터 ──

def create_mcp_router() -> APIRouter:
    """MCP 엔드포인트를 제공하는 FastAPI 라우터를 생성합니다."""
    router = APIRouter(prefix="/mcp", tags=["MCP"])

    @router.get("/health")
    async def mcp_health():
        return {
            "status": "online",
            "tools_count": len(_tool_registry),
            "resources_count": len(_resource_registry),
        }

    @router.get("/tools")
    async def list_tools():
        tools = [
            {
                "name": t.name,
                "description": t.description,
                "parameters": t.parameters,
            }
            for t in _tool_registry.values()
        ]
        return {"tools": tools}

    @router.post("/tools/call")
    async def call_tool(request: dict):
        tool_name = request.get("tool", "")
        arguments = request.get("arguments", {})

        if tool_name not in _tool_registry:
            return JSONResponse(
                status_code=404,
                content={"error": f"Tool '{tool_name}' not found"},
            )

        tool = _tool_registry[tool_name]
        if tool.handler is None:
            return JSONResponse(
                status_code=500,
                content={"error": f"Tool '{tool_name}' has no handler"},
            )

        try:
            result = await tool.handler(**arguments)
            return {"tool": tool_name, "result": result}
        except Exception as e:
            logger.error(f"MCP Tool 오류: {tool_name} — {e}")
            return JSONResponse(
                status_code=500,
                content={"error": str(e)},
            )

    @router.get("/resources")
    async def list_resources():
        resources = [
            {
                "uri": r.uri,
                "name": r.name,
                "description": r.description,
                "mime_type": r.mime_type,
            }
            for r in _resource_registry.values()
        ]
        return {"resources": resources}

    @router.get("/resources/read")
    async def read_resource(uri: str):
        if uri not in _resource_registry:
            return JSONResponse(
                status_code=404,
                content={"error": f"Resource '{uri}' not found"},
            )

        resource = _resource_registry[uri]
        if resource.handler is None:
            return JSONResponse(
                status_code=500,
                content={"error": f"Resource '{uri}' has no handler"},
            )

        try:
            result = await resource.handler()
            return {
                "uri": uri,
                "name": resource.name,
                "mime_type": resource.mime_type,
                "data": result,
            }
        except Exception as e:
            logger.error(f"MCP Resource 오류: {uri} — {e}")
            return JSONResponse(
                status_code=500,
                content={"error": str(e)},
            )

    return router


# ── MCPServer 클래스 ──

class MCPServer:
    """MCP Server — 독립 실행 가능한 MCP 서버.

    Example:
        server = MCPServer("ieee-mcp", port=9001)

        @server.tool("search_papers", "논문 검색")
        async def search(query: str):
            return [...]

        server.run()
    """

    def __init__(self, name: str, port: int = 9000):
        self.name = name
        self.port = port
        self._tools: dict[str, ToolDefinition] = {}
        self._resources: dict[str, ResourceDefinition] = {}

    def tool(
        self,
        name: str | None = None,
        description: str = "",
        parameters: dict[str, Any] | None = None,
    ):
        """Tool 등록 데코레이터 (인스턴스 레벨)."""
        def decorator(func: Callable) -> Callable:
            tool_name = name or func.__name__
            self._tools[tool_name] = ToolDefinition(
                name=tool_name,
                description=description or func.__doc__ or "",
                parameters=parameters or {},
                handler=func,
            )
            # 전역 레지스트리에도 등록
            _tool_registry[tool_name] = self._tools[tool_name]
            return func
        return decorator

    def resource(
        self,
        uri: str,
        name: str | None = None,
        description: str = "",
        mime_type: str = "application/json",
    ):
        """Resource 등록 데코레이터 (인스턴스 레벨)."""
        def decorator(func: Callable) -> Callable:
            res_name = name or func.__name__
            self._resources[uri] = ResourceDefinition(
                uri=uri,
                name=res_name,
                description=description or func.__doc__ or "",
                mime_type=mime_type,
                handler=func,
            )
            # 전역 레지스트리에도 등록
            _resource_registry[uri] = self._resources[uri]
            return func
        return decorator

    def create_app(self) -> FastAPI:
        """FastAPI 앱을 생성합니다."""
        app = FastAPI(title=f"MCP Server: {self.name}")
        app.include_router(create_mcp_router())
        return app

    def run(self, host: str = "0.0.0.0", port: int | None = None):
        """MCP 서버를 실행합니다."""
        import uvicorn
        _port = port or self.port
        logger.info(f"🔌 MCP Server '{self.name}' 시작: http://{host}:{_port}")
        uvicorn.run(self.create_app(), host=host, port=_port, log_level="info")
