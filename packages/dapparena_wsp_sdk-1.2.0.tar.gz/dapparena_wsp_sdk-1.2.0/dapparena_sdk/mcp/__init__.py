"""MCP (Model Context Protocol) — 에이전트 외부 데이터 접근 프레임워크 (S2-01)

에이전트가 외부 데이터 소스(IEEE, Google Drive, heungno.net 등)에
Tool/Resource 기반으로 접근할 수 있는 프로토콜을 제공합니다.
"""

from .client import MCPClient
from .server import MCPServer, mcp_tool, mcp_resource

__all__ = ["MCPClient", "MCPServer", "mcp_tool", "mcp_resource"]
