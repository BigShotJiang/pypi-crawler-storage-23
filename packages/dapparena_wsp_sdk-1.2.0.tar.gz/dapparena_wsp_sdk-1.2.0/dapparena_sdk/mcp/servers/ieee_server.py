"""IEEE Xplore MCP Server — 논문 검색 API 연동 (S2-02)

IEEE Xplore API를 통해 실제 논문을 검색합니다.
API 키가 없으면 Mock 모드로 시뮬레이션 데이터를 반환합니다.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

import httpx

from ..server import MCPServer, mcp_tool

logger = logging.getLogger("dapparena_sdk.mcp.ieee")

# IEEE Xplore API 설정
IEEE_API_KEY = os.getenv("IEEE_API_KEY", "")
IEEE_BASE_URL = "https://ieeexploreapi.ieee.org/api/v1/search/articles"

# MCP Server 인스턴스
ieee_server = MCPServer("ieee-xplore", port=9001)


# ── Mock 데이터 ──

MOCK_PAPERS = {
    "blockchain": [
        {
            "title": "A Survey on Blockchain Technology: Architecture, Consensus, and Future Trends",
            "authors": "Z. Zheng, S. Xie, H. Dai",
            "year": 2024,
            "doi": "10.1109/ACCESS.2024.1234567",
            "abstract": "This paper provides a comprehensive survey of blockchain technology, covering its architecture, consensus mechanisms (PoW, PoS, PBFT), and smart contracts. We analyze recent developments in scalability solutions including sharding, layer-2 protocols, and cross-chain interoperability.",
            "keywords": ["blockchain", "consensus", "smart contracts", "scalability"],
            "publication": "IEEE Access",
            "citations": 342,
        },
        {
            "title": "Smart Contracts: A Survey of Security Vulnerabilities and Best Practices",
            "authors": "L. Luu, D. Chu, H. Olickel",
            "year": 2024,
            "doi": "10.1109/TSE.2024.2345678",
            "abstract": "We systematically study security vulnerabilities in Ethereum smart contracts including reentrancy, integer overflow, and access control issues. We propose a comprehensive taxonomy and present automated analysis tools for vulnerability detection.",
            "keywords": ["smart contracts", "security", "vulnerability", "Ethereum"],
            "publication": "IEEE Transactions on Software Engineering",
            "citations": 186,
        },
        {
            "title": "Decentralized Finance (DeFi): A Comprehensive Analysis of Protocols and Risks",
            "authors": "W. Chen, S. Werner, K. Qin",
            "year": 2025,
            "doi": "10.1109/TIFS.2025.3456789",
            "abstract": "This paper analyzes the rapidly evolving DeFi ecosystem, examining key protocols (AMMs, lending platforms, yield farming), their economic models, and associated risks including impermanent loss, flash loan attacks, and oracle manipulation.",
            "keywords": ["DeFi", "decentralized finance", "AMM", "lending"],
            "publication": "IEEE Transactions on Information Forensics and Security",
            "citations": 95,
        },
    ],
    "zkp": [
        {
            "title": "Zero-Knowledge Proofs: Theory, Applications, and Recent Advances",
            "authors": "E. Ben-Sasson, I. Bentov, A. Chiesa",
            "year": 2024,
            "doi": "10.1109/SP.2024.4567890",
            "abstract": "We present a comprehensive overview of zero-knowledge proof systems, from theoretical foundations (zk-SNARKs, zk-STARKs, Bulletproofs) to practical applications in privacy-preserving computation and blockchain scaling solutions.",
            "keywords": ["zero-knowledge proofs", "zk-SNARKs", "zk-STARKs", "privacy"],
            "publication": "IEEE Symposium on Security and Privacy",
            "citations": 275,
        },
        {
            "title": "Scalable Zero-Knowledge Proofs for Blockchain Transaction Privacy",
            "authors": "J. Groth, M. Kohlweiss",
            "year": 2024,
            "doi": "10.1109/TC.2024.5678901",
            "abstract": "This work introduces novel zk-SNARK constructions optimized for blockchain environments, achieving significant improvements in proof generation time and verification costs while maintaining the same security guarantees.",
            "keywords": ["zk-SNARK", "blockchain", "privacy", "scalability"],
            "publication": "IEEE Transactions on Computers",
            "citations": 128,
        },
        {
            "title": "Privacy-Preserving Machine Learning with Zero-Knowledge Proofs",
            "authors": "P. Mohassel, Y. Zhang",
            "year": 2025,
            "doi": "10.1109/TDSC.2025.6789012",
            "abstract": "We propose a framework combining ZKP with federated learning to enable verifiable computation on private datasets. Our approach allows model training verification without revealing the underlying data.",
            "keywords": ["ZKP", "machine learning", "privacy", "federated learning"],
            "publication": "IEEE Transactions on Dependable and Secure Computing",
            "citations": 62,
        },
    ],
}


def _get_mock_papers(query: str, max_results: int = 3) -> list[dict[str, Any]]:
    """Mock 논문 데이터 반환."""
    query_lower = query.lower()
    for key, papers in MOCK_PAPERS.items():
        if key in query_lower:
            return papers[:max_results]

    # 기본 Mock 데이터
    return [
        {
            "title": f"A Survey on {query}: Recent Advances and Future Directions",
            "authors": "Research Team A",
            "year": 2024,
            "doi": f"10.1109/MOCK.2024.{hash(query) % 10000:04d}",
            "abstract": f"This paper surveys recent advances in {query}, providing a comprehensive overview of key techniques, applications, and open challenges.",
            "keywords": [query.lower(), "survey", "recent advances"],
            "publication": "IEEE Access",
            "citations": 150,
        },
        {
            "title": f"Deep Learning Approaches for {query}: A Comparative Study",
            "authors": "Research Team B",
            "year": 2025,
            "doi": f"10.1109/MOCK.2025.{(hash(query) + 1) % 10000:04d}",
            "abstract": f"We compare state-of-the-art deep learning methods applied to {query}, evaluating their performance on standard benchmarks and real-world datasets.",
            "keywords": [query.lower(), "deep learning", "comparative study"],
            "publication": "IEEE Transactions on Neural Networks",
            "citations": 85,
        },
        {
            "title": f"Practical Implementation of {query} in Industrial Systems",
            "authors": "Research Team C",
            "year": 2025,
            "doi": f"10.1109/MOCK.2025.{(hash(query) + 2) % 10000:04d}",
            "abstract": f"This work presents practical deployment considerations for {query} in industrial environments, including scalability, reliability, and cost analysis.",
            "keywords": [query.lower(), "implementation", "industrial"],
            "publication": "IEEE Internet of Things Journal",
            "citations": 42,
        },
    ][:max_results]


# ── MCP Tools ──

@ieee_server.tool("search_papers", "IEEE Xplore에서 논문 검색")
async def search_papers(query: str, max_results: int = 3) -> list[dict[str, Any]]:
    """IEEE Xplore에서 논문을 검색합니다.

    Args:
        query: 검색 키워드
        max_results: 최대 결과 수 (기본 3)

    Returns:
        논문 목록 (title, authors, year, doi, abstract, keywords)
    """
    if not IEEE_API_KEY:
        logger.info(f"📚 IEEE Mock 모드: '{query}' (max={max_results})")
        return _get_mock_papers(query, max_results)

    # 실제 IEEE Xplore API 호출
    logger.info(f"📚 IEEE API 호출: '{query}' (max={max_results})")
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                IEEE_BASE_URL,
                params={
                    "apikey": IEEE_API_KEY,
                    "querytext": query,
                    "max_records": max_results,
                    "sort_field": "relevance",
                },
            )
            resp.raise_for_status()
            data = resp.json()

        papers = []
        for article in data.get("articles", []):
            papers.append({
                "title": article.get("title", ""),
                "authors": ", ".join(
                    a.get("full_name", "")
                    for a in article.get("authors", {}).get("authors", [])
                ),
                "year": article.get("publication_year", 0),
                "doi": article.get("doi", ""),
                "abstract": article.get("abstract", ""),
                "keywords": [
                    t.get("kwd", "")
                    for t in article.get("index_terms", {}).get("ieee_terms", {}).get("terms", [])
                ],
                "publication": article.get("publication_title", ""),
                "citations": article.get("citing_paper_count", 0),
            })
        return papers

    except Exception as e:
        logger.warning(f"IEEE API 실패, Mock 데이터 사용: {e}")
        return _get_mock_papers(query, max_results)


@ieee_server.tool("get_paper_details", "논문 상세 정보 조회")
async def get_paper_details(doi: str) -> dict[str, Any]:
    """DOI로 논문 상세 정보를 조회합니다."""
    if not IEEE_API_KEY:
        return {
            "doi": doi,
            "title": f"Paper with DOI {doi}",
            "abstract": "Mock paper details",
            "full_text_available": False,
            "mode": "mock",
        }

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(
                IEEE_BASE_URL,
                params={
                    "apikey": IEEE_API_KEY,
                    "doi": doi,
                },
            )
            resp.raise_for_status()
            data = resp.json()
            articles = data.get("articles", [])
            return articles[0] if articles else {"error": "Not found"}
    except Exception as e:
        return {"doi": doi, "error": str(e), "mode": "fallback"}


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    ieee_server.run()
