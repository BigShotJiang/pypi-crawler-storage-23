"""Google Drive MCP Server — 문서 읽기/쓰기 연동 (S2-03)

Google Drive API를 통해 교재를 저장하고 기존 문서를 참조합니다.
OAuth 설정이 없으면 Mock 모드로 동작합니다.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from ..server import MCPServer

logger = logging.getLogger("dapparena_sdk.mcp.gdrive")

GDRIVE_CREDENTIALS = os.getenv("GDRIVE_CREDENTIALS_PATH", "")

gdrive_server = MCPServer("gdrive", port=9002)

# Mock 저장소
_mock_files: dict[str, dict[str, Any]] = {
    "mock-file-001": {
        "id": "mock-file-001",
        "name": "블록체인 기초 강의자료.pdf",
        "mime_type": "application/pdf",
        "size": 2048000,
        "content": "블록체인 기초 강의자료 — 합의 알고리즘, 스마트 계약 개요...",
    },
    "mock-file-002": {
        "id": "mock-file-002",
        "name": "ZKP 세미나 자료.docx",
        "mime_type": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "size": 512000,
        "content": "영지식 증명(ZKP) 세미나 — zk-SNARKs, zk-STARKs 비교 분석...",
    },
}


@gdrive_server.tool("list_files", "Google Drive 파일 목록 조회")
async def list_files(
    folder_id: str = "root", max_results: int = 10
) -> list[dict[str, Any]]:
    """Google Drive에서 파일 목록을 조회합니다."""
    if not GDRIVE_CREDENTIALS:
        logger.info("📁 Google Drive Mock 모드: list_files")
        return [
            {"id": f["id"], "name": f["name"], "mime_type": f["mime_type"], "size": f["size"]}
            for f in _mock_files.values()
        ][:max_results]

    # 실제 Google Drive API (생략 — 향후 구현)
    logger.info(f"📁 Google Drive API: list_files (folder={folder_id})")
    return []


@gdrive_server.tool("read_file", "Google Drive 파일 읽기")
async def read_file(file_id: str) -> dict[str, Any]:
    """Google Drive에서 파일 내용을 읽습니다."""
    if not GDRIVE_CREDENTIALS:
        logger.info(f"📁 Google Drive Mock 모드: read_file ({file_id})")
        file_data = _mock_files.get(file_id)
        if file_data:
            return {"id": file_id, "content": file_data["content"], "name": file_data["name"]}
        return {"error": f"File '{file_id}' not found (mock)"}

    logger.info(f"📁 Google Drive API: read_file ({file_id})")
    return {"error": "Not implemented — OAuth required"}


@gdrive_server.tool("upload_file", "Google Drive 파일 업로드")
async def upload_file(
    name: str, content: str, folder_id: str = "root", mime_type: str = "application/pdf"
) -> dict[str, Any]:
    """Google Drive에 파일을 업로드합니다."""
    if not GDRIVE_CREDENTIALS:
        file_id = f"mock-upload-{len(_mock_files) + 1:03d}"
        _mock_files[file_id] = {
            "id": file_id,
            "name": name,
            "mime_type": mime_type,
            "size": len(content.encode()),
            "content": content[:500],
        }
        logger.info(f"📁 Google Drive Mock 업로드: {name} → {file_id}")
        return {"id": file_id, "name": name, "uploaded": True, "mode": "mock"}

    logger.info(f"📁 Google Drive API: upload ({name})")
    return {"error": "Not implemented — OAuth required"}


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    gdrive_server.run()
