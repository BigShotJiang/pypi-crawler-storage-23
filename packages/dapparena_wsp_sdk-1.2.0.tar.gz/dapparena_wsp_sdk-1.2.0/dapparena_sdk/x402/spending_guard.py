"""SpendingGuardClient — 일일 지출 한도 관리 (S3-07)

SpendingGuard 스마트 컨트랙트와 상호작용하여
에이전트의 일일 지출 한도를 조회·설정·확인합니다.
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger("dapparena_sdk.x402.spending_guard")


@dataclass
class SpendingStatus:
    """일일 지출 현황."""

    agent_id: int
    daily_limit_wei: int
    spent_today_wei: int
    remaining_wei: int
    active: bool

    @property
    def daily_limit_wlc(self) -> float:
        return self.daily_limit_wei / 1e18

    @property
    def spent_today_wlc(self) -> float:
        return self.spent_today_wei / 1e18

    @property
    def remaining_wlc(self) -> float:
        return self.remaining_wei / 1e18


class SpendingGuardClient:
    """SpendingGuard 스마트 컨트랙트 클라이언트.

    Usage::

        guard = SpendingGuardClient(
            rpc_url="https://rpc.worldland.foundation",
            contract_address="0x...",
        )
        status = await guard.get_status(agent_id=1)
        can_pay = await guard.check_allowance(agent_id=1, amount_wei=1e18)
    """

    def __init__(
        self,
        rpc_url: str = "https://rpc.worldland.foundation",
        contract_address: str = "",
    ):
        self.rpc_url = rpc_url
        self.contract_address = contract_address
        self._client = httpx.AsyncClient(timeout=30.0)

    # ----------------------------------------------------------
    # 조회
    # ----------------------------------------------------------

    async def get_status(self, agent_id: int) -> SpendingStatus:
        """에이전트의 일일 지출 현황을 조회합니다.

        Args:
            agent_id: AgentNFT 토큰 ID

        Returns:
            SpendingStatus
        """
        daily_limit = await self._call_uint256(
            "getDailyLimit(uint256)", agent_id
        )
        spent_today = await self._call_uint256(
            "getSpentToday(uint256)", agent_id
        )
        remaining = await self._call_uint256(
            "getRemainingLimit(uint256)", agent_id
        )

        return SpendingStatus(
            agent_id=agent_id,
            daily_limit_wei=daily_limit,
            spent_today_wei=spent_today,
            remaining_wei=remaining,
            active=daily_limit > 0,
        )

    async def check_allowance(
        self, agent_id: int, amount_wei: int
    ) -> bool:
        """지출 가능 여부를 확인합니다.

        Args:
            agent_id: AgentNFT 토큰 ID
            amount_wei: 지출 금액 (wei)

        Returns:
            지출 가능 여부
        """
        if not self.contract_address:
            # 컨트랙트 미설정 → 무제한 허용
            return True

        try:
            status = await self.get_status(agent_id)
            if not status.active:
                # 한도 미설정 → 무제한
                return True
            return status.remaining_wei >= amount_wei
        except Exception as e:
            logger.warning(f"한도 확인 실패 (허용으로 폴백): {e}")
            return True

    # ----------------------------------------------------------
    # 한도 설정 TX 빌드
    # ----------------------------------------------------------

    def build_set_limit_tx(
        self, agent_id: int, limit_wei: int
    ) -> dict[str, Any]:
        """일일 한도 설정 트랜잭션을 빌드합니다.

        setDailyLimit(uint256 agentId, uint256 limitAmount)

        Args:
            agent_id: AgentNFT 토큰 ID
            limit_wei: 일일 한도 (wei)

        Returns:
            트랜잭션 딕셔너리
        """
        selector = _function_selector("setDailyLimit(uint256,uint256)")
        agent_hex = hex(agent_id)[2:].zfill(64)
        limit_hex = hex(limit_wei)[2:].zfill(64)

        return {
            "to": self.contract_address,
            "data": "0x" + selector + agent_hex + limit_hex,
            "value": "0x0",
        }

    def build_remove_limit_tx(self, agent_id: int) -> dict[str, Any]:
        """일일 한도 제거 트랜잭션을 빌드합니다.

        removeDailyLimit(uint256 agentId)
        """
        selector = _function_selector("removeDailyLimit(uint256)")
        agent_hex = hex(agent_id)[2:].zfill(64)

        return {
            "to": self.contract_address,
            "data": "0x" + selector + agent_hex,
            "value": "0x0",
        }

    # ----------------------------------------------------------
    # 내부
    # ----------------------------------------------------------

    async def _call_uint256(
        self, func_sig: str, agent_id: int
    ) -> int:
        """단일 uint256 반환 함수 호출."""
        if not self.contract_address:
            return 0

        try:
            selector = _function_selector(func_sig)
            agent_hex = hex(agent_id)[2:].zfill(64)
            data = "0x" + selector + agent_hex

            payload = {
                "jsonrpc": "2.0",
                "method": "eth_call",
                "params": [
                    {"to": self.contract_address, "data": data},
                    "latest",
                ],
                "id": 1,
            }
            resp = await self._client.post(self.rpc_url, json=payload)
            resp.raise_for_status()
            result = resp.json()

            if "error" in result:
                return 0
            raw = result.get("result", "0x0")
            return int(raw, 16) if raw != "0x" else 0
        except Exception as e:
            logger.warning(f"RPC 호출 실패 ({func_sig}): {e}")
            return 0

    async def close(self) -> None:
        """HTTP 클라이언트를 닫습니다."""
        await self._client.aclose()


def _function_selector(signature: str) -> str:
    """Solidity 함수 시그니처의 4바이트 셀렉터."""
    return hashlib.sha3_256(signature.encode()).hexdigest()[:8]
