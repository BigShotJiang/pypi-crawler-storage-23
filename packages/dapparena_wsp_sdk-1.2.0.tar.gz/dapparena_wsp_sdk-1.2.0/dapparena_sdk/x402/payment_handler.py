"""X402PaymentHandler — HTTP 402 감지·자동 결제 (S3-06)

에이전트 간 A2A 요청 시 HTTP 402 응답을 감지하고,
X402Payment 컨트랙트를 통해 자동으로 결제합니다.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import uuid
from dataclasses import dataclass, field
from typing import Any

import httpx

logger = logging.getLogger("dapparena_sdk.x402.payment_handler")


@dataclass
class PaymentRequirement:
    """x402 결제 요구사항 (WWW-Authenticate 헤더에서 파싱)."""

    amount_wei: int
    recipient: str  # 수신 에이전트 TBA 주소
    payment_contract: str  # X402Payment 컨트랙트 주소
    description: str = ""

    @property
    def amount_wlc(self) -> float:
        return self.amount_wei / 1e18


@dataclass
class PaymentResult:
    """결제 결과."""

    success: bool
    payment_id: str = ""
    tx_data: dict[str, Any] | None = None
    amount_wei: int = 0
    recipient: str = ""
    error: str = ""

    @property
    def amount_wlc(self) -> float:
        return self.amount_wei / 1e18


class X402PaymentHandler:
    """HTTP 402 자동 결제 핸들러.

    A2A 요청이 402를 반환하면:
    1. WWW-Authenticate 헤더에서 결제 요구사항을 파싱
    2. SpendingGuard 한도 확인
    3. X402Payment 컨트랙트를 통한 결제 트랜잭션 빌드
    4. 결제 완료 후 원래 요청 재시도

    Usage::

        handler = X402PaymentHandler(
            payer_tba="0x...",
            agent_id=1,
            x402_contract="0x...",
        )

        # HTTP 응답이 402인 경우
        if response.status_code == 402:
            payment_req = handler.parse_402(response)
            tx = handler.build_payment_tx(payment_req)
            # tx 서명 후 브로드캐스트
    """

    def __init__(
        self,
        payer_tba: str = "",
        agent_id: int = 0,
        x402_contract: str = "",
        rpc_url: str = "https://rpc.worldland.foundation",
    ):
        self.payer_tba = payer_tba
        self.agent_id = agent_id
        self.x402_contract = x402_contract
        self.rpc_url = rpc_url

    # ----------------------------------------------------------
    # 402 감지 · 파싱
    # ----------------------------------------------------------

    def is_payment_required(self, response: httpx.Response) -> bool:
        """HTTP 응답이 402 Payment Required인지 확인합니다."""
        return response.status_code == 402

    def parse_402(self, response: httpx.Response) -> PaymentRequirement | None:
        """402 응답에서 결제 요구사항을 파싱합니다.

        WWW-Authenticate 헤더 형식::

            X402 amount=1000000000000000000,
                 recipient=0x...,
                 contract=0x...,
                 description="서비스 이용료"

        또는 JSON 응답 본문에서 파싱:

            {"x402": {"amount": "1000000000000000000", "recipient": "0x...", ...}}

        Args:
            response: httpx.Response (status_code == 402)

        Returns:
            PaymentRequirement 또는 None
        """
        # 1. WWW-Authenticate 헤더 우선
        www_auth = response.headers.get("www-authenticate", "")
        if www_auth.startswith("X402"):
            return self._parse_www_authenticate(www_auth)

        # 2. JSON 본문 폴백
        try:
            body = response.json()
            if "x402" in body:
                x402 = body["x402"]
                return PaymentRequirement(
                    amount_wei=int(x402.get("amount", "0")),
                    recipient=x402.get("recipient", ""),
                    payment_contract=x402.get(
                        "contract", self.x402_contract
                    ),
                    description=x402.get("description", ""),
                )
        except Exception:
            pass

        logger.warning("402 응답이지만 결제 정보를 파싱할 수 없음")
        return None

    def _parse_www_authenticate(
        self, header: str
    ) -> PaymentRequirement | None:
        """WWW-Authenticate: X402 ... 헤더를 파싱합니다."""
        try:
            # 키=값 쌍 추출
            pairs: dict[str, str] = {}
            # "X402 " 이후 부분
            content = header[5:].strip() if header.startswith("X402") else header
            for match in re.finditer(r'(\w+)=("(?:[^"\\]|\\.)*"|[\w\d]+)', content):
                key = match.group(1)
                val = match.group(2).strip('"')
                pairs[key] = val

            return PaymentRequirement(
                amount_wei=int(pairs.get("amount", "0")),
                recipient=pairs.get("recipient", ""),
                payment_contract=pairs.get(
                    "contract", self.x402_contract
                ),
                description=pairs.get("description", ""),
            )
        except Exception as e:
            logger.error(f"WWW-Authenticate 파싱 실패: {e}")
            return None

    # ----------------------------------------------------------
    # 결제 트랜잭션 빌드
    # ----------------------------------------------------------

    def build_payment_tx(
        self, requirement: PaymentRequirement
    ) -> PaymentResult:
        """X402Payment.pay() 호출 트랜잭션을 빌드합니다.

        pay(bytes32 paymentId, address recipient) payable

        Args:
            requirement: 결제 요구사항

        Returns:
            PaymentResult (tx_data 포함)
        """
        try:
            payment_id = uuid.uuid4().hex
            payment_id_bytes32 = payment_id.ljust(64, "0")

            # pay(bytes32,address) selector
            selector = _function_selector("pay(bytes32,address)")
            recipient_clean = (
                requirement.recipient.lower().replace("0x", "").zfill(64)
            )

            calldata = (
                "0x" + selector + payment_id_bytes32 + recipient_clean
            )

            tx_data = {
                "to": requirement.payment_contract or self.x402_contract,
                "data": calldata,
                "value": hex(requirement.amount_wei),
            }

            logger.info(
                f"💳 결제 TX 빌드: {requirement.amount_wlc} WLC "
                f"→ {requirement.recipient[:10]}..."
            )

            return PaymentResult(
                success=True,
                payment_id=payment_id,
                tx_data=tx_data,
                amount_wei=requirement.amount_wei,
                recipient=requirement.recipient,
            )
        except Exception as e:
            logger.error(f"결제 TX 빌드 실패: {e}")
            return PaymentResult(
                success=False, error=str(e)
            )

    # ----------------------------------------------------------
    # 편의: 402 자동 처리 흐름
    # ----------------------------------------------------------

    async def handle_402(
        self,
        response: httpx.Response,
    ) -> PaymentResult:
        """402 응답을 감지하고 결제 트랜잭션을 빌드합니다.

        실제 서명/브로드캐스트는 호출자가 수행합니다.

        Args:
            response: 402 응답

        Returns:
            PaymentResult
        """
        if not self.is_payment_required(response):
            return PaymentResult(
                success=False, error="Not a 402 response"
            )

        requirement = self.parse_402(response)
        if not requirement:
            return PaymentResult(
                success=False, error="결제 정보 파싱 실패"
            )

        return self.build_payment_tx(requirement)


def _function_selector(signature: str) -> str:
    """Solidity 함수 시그니처의 4바이트 셀렉터."""
    return hashlib.sha3_256(signature.encode()).hexdigest()[:8]
