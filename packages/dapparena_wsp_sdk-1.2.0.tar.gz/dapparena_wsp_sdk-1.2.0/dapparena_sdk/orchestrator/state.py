"""워크플로 실행 상태 관리 (S1-07 보조)"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class WorkflowStatus(str, Enum):
    """워크플로 실행 상태."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class StepResult:
    """개별 단계의 실행 결과."""
    agent: str
    status: str  # "completed", "failed", "skipped"
    duration_seconds: float = 0.0
    task_id: str = ""
    error: str = ""


@dataclass
class WorkflowState:
    """워크플로 전체 실행 상태.

    Attributes:
        workflow_id: 워크플로 실행 고유 ID
        workflow_name: 워크플로 이름
        status: 실행 상태
        current_step: 현재 실행 중인 단계 인덱스
        total_steps: 전체 단계 수
        step_results: 각 단계별 실행 결과
        started_at: 시작 시간 (epoch)
        completed_at: 완료 시간 (epoch)
        metadata: 추가 정보
    """
    workflow_id: str
    workflow_name: str = ""
    status: WorkflowStatus = WorkflowStatus.PENDING
    current_step: int = 0
    total_steps: int = 0
    step_results: list[StepResult] = field(default_factory=list)
    started_at: float = 0.0
    completed_at: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def elapsed_seconds(self) -> float:
        end = self.completed_at or time.time()
        return round(end - self.started_at, 2) if self.started_at else 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "workflow_id": self.workflow_id,
            "workflow_name": self.workflow_name,
            "status": self.status.value,
            "current_step": self.current_step,
            "total_steps": self.total_steps,
            "elapsed_seconds": self.elapsed_seconds,
            "step_results": [
                {
                    "agent": sr.agent,
                    "status": sr.status,
                    "duration_seconds": sr.duration_seconds,
                    "task_id": sr.task_id,
                    "error": sr.error,
                }
                for sr in self.step_results
            ],
        }


# 글로벌 상태 저장소 (in-memory)
_workflow_states: dict[str, WorkflowState] = {}


def save_state(state: WorkflowState) -> None:
    _workflow_states[state.workflow_id] = state


def get_state(workflow_id: str) -> WorkflowState | None:
    return _workflow_states.get(workflow_id)


def list_states() -> list[WorkflowState]:
    return list(_workflow_states.values())
