"""Workflow YAML 파서 — 워크플로 정의를 로드하고 파싱 (S1-06)

워크플로 YAML 파일을 읽어 WorkflowStep 객체 리스트로 변환합니다.

YAML 형식 예시:
    name: textbook_pipeline
    description: "WSP 교재 편찬 파이프라인"
    steps:
      - agent: cheolsu
        url: http://localhost:8101
        role: researcher
        timeout: 120
        on_failure: retry
        max_retries: 2
      - agent: younghee
        url: http://localhost:8102
        role: editor
        timeout: 180
        on_failure: retry
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class WorkflowStep:
    """워크플로의 개별 단계.

    Attributes:
        agent: 에이전트 이름 (예: "cheolsu")
        url: 에이전트 서버 URL (예: "http://localhost:8101")
        role: 역할 설명 (예: "researcher")
        timeout: 요청 타임아웃 (초)
        on_failure: 실패 시 동작 ("retry", "skip", "abort")
        max_retries: 재시도 횟수
    """
    agent: str
    url: str
    role: str = ""
    timeout: int = 120
    on_failure: str = "abort"
    max_retries: int = 1

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> WorkflowStep:
        return cls(
            agent=d["agent"],
            url=d["url"],
            role=d.get("role", ""),
            timeout=d.get("timeout", 120),
            on_failure=d.get("on_failure", "abort"),
            max_retries=d.get("max_retries", 1),
        )


@dataclass
class Workflow:
    """워크플로 전체 정의.

    Attributes:
        name: 워크플로 이름
        description: 워크플로 설명
        steps: 순차 실행할 단계 목록
        metadata: 추가 설정
    """
    name: str
    description: str = ""
    steps: list[WorkflowStep] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


def load_workflow(path: str | Path) -> Workflow:
    """YAML 파일에서 Workflow를 로드합니다.

    Args:
        path: YAML 파일 경로

    Returns:
        파싱된 Workflow 객체

    Raises:
        FileNotFoundError: 파일이 존재하지 않을 때
        ValueError: YAML 파싱 실패 시
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"워크플로 파일을 찾을 수 없습니다: {path}")

    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if not isinstance(data, dict):
        raise ValueError(f"유효하지 않은 워크플로 형식: {path}")

    steps = [WorkflowStep.from_dict(s) for s in data.get("steps", [])]

    return Workflow(
        name=data.get("name", path.stem),
        description=data.get("description", ""),
        steps=steps,
        metadata=data.get("metadata", {}),
    )
