"""Orchestrator 엔진 — 워크플로를 순차 실행 (S1-07)

A2A Client를 사용하여 워크플로의 각 단계를 순서대로 실행하고,
이전 단계의 output Artifact를 다음 단계의 input으로 전달합니다.
"""

from __future__ import annotations

import logging
import time
import uuid
from pathlib import Path

from ..a2a.client import A2AClientV2
from ..a2a.models import Artifact, Task, TaskState
from .state import StepResult, WorkflowState, WorkflowStatus, save_state
from .workflow import Workflow, WorkflowStep, load_workflow

logger = logging.getLogger("dapparena_sdk.orchestrator")


class OrchestratorEngine:
    """WSP 워크플로 실행 엔진.

    워크플로 YAML을 로드하고, 각 에이전트를 순차적으로 호출합니다.
    이전 단계의 출력이 다음 단계의 입력으로 자동 전달됩니다.

    Example:
        engine = OrchestratorEngine()
        result = await engine.run_workflow(
            "workflows/textbook_pipeline.yaml",
            "Blockchain 기초 교재 만들어"
        )
        print(result.state, result.artifacts)
    """

    def __init__(self, client: A2AClientV2 | None = None):
        self._client = client or A2AClientV2()

    async def run_workflow(
        self,
        workflow_path: str | Path,
        initial_input: str,
    ) -> Task:
        """워크플로를 로드하고 순차 실행합니다.

        Args:
            workflow_path: 워크플로 YAML 파일 경로
            initial_input: 최초 입력 메시지 (예: "교재 만들어")

        Returns:
            최종 단계의 결과 Task
        """
        workflow = load_workflow(workflow_path)
        return await self.execute_workflow(workflow, initial_input)

    async def execute_workflow(
        self,
        workflow: Workflow,
        initial_input: str,
    ) -> Task:
        """Workflow 객체를 직접 실행합니다.

        Args:
            workflow: 로드된 Workflow 객체
            initial_input: 최초 입력 메시지

        Returns:
            최종 단계의 결과 Task
        """
        workflow_id = str(uuid.uuid4())
        state = WorkflowState(
            workflow_id=workflow_id,
            workflow_name=workflow.name,
            status=WorkflowStatus.RUNNING,
            total_steps=len(workflow.steps),
            started_at=time.time(),
        )
        save_state(state)

        logger.info(
            f"🎼 워크플로 시작: {workflow.name} "
            f"(id={workflow_id}, steps={len(workflow.steps)})"
        )

        # 첫 번째 Task 생성
        current_task = Task(message=initial_input)

        for i, step in enumerate(workflow.steps):
            state.current_step = i + 1
            save_state(state)

            logger.info(
                f"  [{i+1}/{len(workflow.steps)}] "
                f"{step.agent} ({step.role}) 호출 중..."
            )

            step_start = time.time()
            try:
                result_task = await self._execute_step_with_retry(step, current_task)
                duration = round(time.time() - step_start, 2)

                state.step_results.append(StepResult(
                    agent=step.agent,
                    status="completed",
                    duration_seconds=duration,
                    task_id=result_task.id,
                ))
                save_state(state)

                logger.info(
                    f"  ✅ {step.agent} 완료 "
                    f"(artifacts={len(result_task.artifacts)}, {duration}s)"
                )

                # 다음 단계를 위한 Task 준비
                # 이전 단계의 artifacts를 포함하여 새 Task 생성
                current_task = Task(
                    message=current_task.message,
                    artifacts=result_task.artifacts,
                    metadata={
                        **current_task.metadata,
                        f"step_{i+1}_agent": step.agent,
                        f"step_{i+1}_task_id": result_task.id,
                    },
                )

            except Exception as e:
                duration = round(time.time() - step_start, 2)
                state.step_results.append(StepResult(
                    agent=step.agent,
                    status="failed",
                    duration_seconds=duration,
                    error=str(e),
                ))
                state.status = WorkflowStatus.FAILED
                state.completed_at = time.time()
                save_state(state)

                logger.error(f"  ❌ {step.agent} 실패: {e}")

                if step.on_failure == "abort":
                    current_task.state = TaskState.FAILED
                    current_task.metadata["error"] = str(e)
                    current_task.metadata["failed_step"] = step.agent
                    return current_task
                elif step.on_failure == "skip":
                    logger.warning(f"  ⏭️ {step.agent} 스킵됨")
                    continue
                else:
                    # retry가 이미 실패한 경우에도 abort
                    current_task.state = TaskState.FAILED
                    current_task.metadata["error"] = str(e)
                    return current_task

        # 모든 단계 완료
        state.status = WorkflowStatus.COMPLETED
        state.completed_at = time.time()
        save_state(state)

        logger.info(
            f"🎉 워크플로 완료: {workflow.name} "
            f"(총 {state.elapsed_seconds}s)"
        )

        current_task.state = TaskState.COMPLETED
        current_task.metadata["workflow_id"] = workflow_id
        return current_task

    async def _execute_step_with_retry(
        self,
        step: WorkflowStep,
        input_task: Task,
    ) -> Task:
        """개별 단계를 retry 포함하여 실행합니다."""
        last_error: Exception | None = None
        max_attempts = step.max_retries + 1

        for attempt in range(1, max_attempts + 1):
            try:
                # A2A Client를 통해 에이전트에 Task 전송
                client = A2AClientV2(timeout=step.timeout)
                result = await client.send_task(step.url, input_task)

                if result.state == TaskState.FAILED:
                    raise RuntimeError(
                        f"에이전트 {step.agent} 처리 실패: "
                        f"{result.metadata.get('error', 'unknown')}"
                    )

                return result

            except Exception as e:
                last_error = e
                if attempt < max_attempts:
                    logger.warning(
                        f"  🔄 {step.agent} 재시도 "
                        f"({attempt}/{max_attempts}): {e}"
                    )

        raise last_error  # type: ignore[misc]

    def get_status(self, workflow_id: str) -> dict | None:
        """워크플로 진행 상황을 조회합니다.

        Args:
            workflow_id: 워크플로 실행 ID

        Returns:
            상태 딕셔너리 또는 None
        """
        from .state import get_state
        state = get_state(workflow_id)
        return state.to_dict() if state else None
