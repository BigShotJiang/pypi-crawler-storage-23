"""DIDManager — DID 생성 · DID Document 관리 (S3-01)

에이전트에게 탈중앙화 신원(DID)을 부여합니다.
did:worldland:agent:{name} 형식의 DID 문자열과 JSON-LD DID Document를 생성합니다.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("dapparena_sdk.identity.did_manager")

# Ed25519는 선택적 의존성 — 없으면 SHA-256 서명 시뮬레이션으로 폴백
try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
        Ed25519PublicKey,
    )
    from cryptography.hazmat.primitives.serialization import (
        Encoding,
        NoEncryption,
        PrivateFormat,
        PublicFormat,
    )

    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False
    logger.warning("cryptography 미설치 — Ed25519 서명 시뮬레이션 모드")


@dataclass
class DIDDocument:
    """W3C DID Document (JSON-LD 호환)"""

    id: str  # did:worldland:agent:{name}
    agent_id: int = 0
    controller: str = ""
    verification_method: list[dict[str, Any]] = field(default_factory=list)
    authentication: list[str] = field(default_factory=list)
    service: list[dict[str, Any]] = field(default_factory=list)
    created: str = ""
    updated: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "@context": [
                "https://www.w3.org/ns/did/v1",
                "https://w3id.org/security/suites/ed25519-2020/v1",
            ],
            "id": self.id,
            "controller": self.controller or self.id,
            "verificationMethod": self.verification_method,
            "authentication": self.authentication,
            "service": self.service,
            "created": self.created,
            "updated": self.updated,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=False)


class DIDManager:
    """에이전트 DID 생성 및 문서 관리.

    Usage::

        mgr = DIDManager("cheolsu", agent_id=1)
        doc = mgr.create_did_document(endpoint="http://localhost:8101")
        sig = mgr.sign(b"hello")
        assert mgr.verify(b"hello", sig)
    """

    def __init__(
        self,
        agent_name: str,
        agent_id: int = 0,
        *,
        key_dir: str | None = None,
    ):
        self.agent_name = agent_name
        self.agent_id = agent_id
        self.did_string = f"did:worldland:agent:{agent_name}"
        self._key_dir = key_dir or os.path.join(os.getcwd(), ".keys")

        # 키 쌍 생성
        self._private_key: Any = None
        self._public_key: Any = None
        self._public_key_bytes: bytes = b""
        self._generate_keys()

        logger.info(f"🆔 DID 생성: {self.did_string}")

    # ----------------------------------------------------------
    # 키 관리
    # ----------------------------------------------------------

    def _generate_keys(self) -> None:
        """Ed25519 키 쌍을 생성합니다."""
        if HAS_CRYPTO:
            self._private_key = Ed25519PrivateKey.generate()
            self._public_key = self._private_key.public_key()
            self._public_key_bytes = self._public_key.public_bytes(
                Encoding.Raw, PublicFormat.Raw
            )
        else:
            # 시뮬레이션: 랜덤 32바이트를 "키"로 사용
            self._private_key = os.urandom(32)
            self._public_key_bytes = hashlib.sha256(self._private_key).digest()

    @property
    def public_key_hex(self) -> str:
        """공개키 16진수 문자열."""
        return self._public_key_bytes.hex()

    @property
    def public_key_multibase(self) -> str:
        """공개키 Multibase(z-base58btc placeholder) 문자열."""
        return f"z{self._public_key_bytes.hex()}"

    # ----------------------------------------------------------
    # DID Document 생성
    # ----------------------------------------------------------

    def create_did_document(
        self,
        endpoint: str = "",
        controller: str = "",
    ) -> DIDDocument:
        """W3C DID Document를 생성합니다.

        Args:
            endpoint: 에이전트 A2A 엔드포인트 URL
            controller: DID 제어자 (기본: 자기 자신)

        Returns:
            DIDDocument 인스턴스
        """
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        vm_id = f"{self.did_string}#key-1"

        verification_method = [
            {
                "id": vm_id,
                "type": "Ed25519VerificationKey2020",
                "controller": controller or self.did_string,
                "publicKeyMultibase": self.public_key_multibase,
            }
        ]

        service = []
        if endpoint:
            service.append(
                {
                    "id": f"{self.did_string}#a2a",
                    "type": "A2AEndpoint",
                    "serviceEndpoint": endpoint,
                }
            )

        doc = DIDDocument(
            id=self.did_string,
            agent_id=self.agent_id,
            controller=controller or self.did_string,
            verification_method=verification_method,
            authentication=[vm_id],
            service=service,
            created=now,
            updated=now,
        )

        logger.info(f"🆔 DID Document 생성 완료: {self.did_string}")
        return doc

    # ----------------------------------------------------------
    # 서명 · 검증
    # ----------------------------------------------------------

    def sign(self, message: bytes) -> bytes:
        """메시지에 Ed25519 서명합니다.

        Args:
            message: 서명할 바이트 메시지

        Returns:
            서명 바이트
        """
        if HAS_CRYPTO:
            return self._private_key.sign(message)
        else:
            # SHA-256 HMAC 시뮬레이션
            import hmac

            return hmac.new(self._private_key, message, hashlib.sha256).digest()

    def verify(self, message: bytes, signature: bytes) -> bool:
        """서명을 검증합니다.

        Args:
            message: 원본 메시지
            signature: 검증할 서명

        Returns:
            검증 성공 여부
        """
        if HAS_CRYPTO:
            try:
                self._public_key.verify(signature, message)
                return True
            except Exception:
                return False
        else:
            import hmac

            expected = hmac.new(
                self._private_key, message, hashlib.sha256
            ).digest()
            return hmac.compare_digest(signature, expected)
