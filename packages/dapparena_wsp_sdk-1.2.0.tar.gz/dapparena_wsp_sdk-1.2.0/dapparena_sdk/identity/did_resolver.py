"""DIDResolver — DID 온체인 조회·검증 (S3-02)

DIDRegistry 스마트 컨트랙트에 등록된 DID를 RPC를 통해 조회합니다.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger("dapparena_sdk.identity.did_resolver")

# DIDRegistry ABI (조회 함수들만)
DID_REGISTRY_ABI = {
    "resolveDID": "resolveDID(string)",
    "getDIDByAgentId": "getDIDByAgentId(uint256)",
    "isDIDActive": "isDIDActive(string)",
    "verifyDID": "verifyDID(string,address)",
}


@dataclass
class OnChainDIDDocument:
    """온체인 DID Document 데이터."""

    agent_id: int
    did_string: str
    owner: str
    tba_address: str
    active: bool
    created_at: int
    updated_at: int


class DIDResolver:
    """DIDRegistry 온체인 조회 클라이언트.

    Usage::

        resolver = DIDResolver(
            rpc_url="https://rpc.worldland.foundation",
            registry_address="0x...",
        )
        doc = await resolver.resolve("did:worldland:agent:cheolsu")
        is_valid = await resolver.verify_did("did:worldland:agent:cheolsu", "0x...")
    """

    def __init__(
        self,
        rpc_url: str = "https://rpc.worldland.foundation",
        registry_address: str = "",
    ):
        self.rpc_url = rpc_url
        self.registry_address = registry_address
        self._client = httpx.AsyncClient(timeout=30.0)

    async def _eth_call(self, data: str) -> str:
        """eth_call RPC 호출."""
        payload = {
            "jsonrpc": "2.0",
            "method": "eth_call",
            "params": [
                {"to": self.registry_address, "data": data},
                "latest",
            ],
            "id": 1,
        }
        resp = await self._client.post(self.rpc_url, json=payload)
        resp.raise_for_status()
        result = resp.json()
        if "error" in result:
            raise RuntimeError(f"RPC error: {result['error']}")
        return result.get("result", "0x")

    async def resolve(self, did_string: str) -> OnChainDIDDocument | None:
        """DID 문자열로 온체인 DID Document를 조회합니다.

        Args:
            did_string: DID 문자열 (예: "did:worldland:agent:cheolsu")

        Returns:
            OnChainDIDDocument 또는 None (미등록/폐기됨)
        """
        if not self.registry_address:
            logger.warning("DIDRegistry 주소 미설정 — 조회 불가")
            return None

        try:
            # resolveDID(string) 호출 데이터 인코딩
            # keccak256("resolveDID(string)")[:4] = selector
            selector = "0x" + _function_selector("resolveDID(string)")
            encoded_did = _encode_string(did_string)
            data = selector + encoded_did

            result = await self._eth_call(data)

            if result == "0x" or len(result) < 66:
                return None

            return _decode_did_document(result, did_string)
        except Exception as e:
            logger.error(f"DID resolve 실패: {e}")
            return None

    async def is_active(self, did_string: str) -> bool:
        """DID 활성 상태를 확인합니다."""
        if not self.registry_address:
            return False

        try:
            selector = "0x" + _function_selector("isDIDActive(string)")
            encoded_did = _encode_string(did_string)
            data = selector + encoded_did

            result = await self._eth_call(data)
            # bool은 마지막 바이트가 0 또는 1
            return result != "0x" and int(result, 16) != 0
        except Exception as e:
            logger.error(f"DID 활성 확인 실패: {e}")
            return False

    async def verify_did(self, did_string: str, address: str) -> bool:
        """DID가 특정 주소에 대해 유효한지 검증합니다.

        Args:
            did_string: DID 문자열
            address: 검증할 주소 (TBA 또는 소유자)

        Returns:
            검증 성공 여부
        """
        if not self.registry_address:
            return False

        try:
            selector = "0x" + _function_selector("verifyDID(string,address)")
            encoded_did = _encode_string(did_string)
            # address를 32바이트로 패딩
            addr_clean = address.lower().replace("0x", "")
            encoded_addr = addr_clean.zfill(64)
            data = selector + encoded_did + encoded_addr

            result = await self._eth_call(data)
            return result != "0x" and int(result, 16) != 0
        except Exception as e:
            logger.error(f"DID 검증 실패: {e}")
            return False

    async def close(self) -> None:
        """HTTP 클라이언트를 닫습니다."""
        await self._client.aclose()


# ─────────────────────────────────────────────
# ABI 인코딩 유틸리티
# ─────────────────────────────────────────────


def _function_selector(signature: str) -> str:
    """Solidity 함수 시그니처의 4바이트 셀렉터를 반환합니다."""
    import hashlib

    return hashlib.sha3_256(signature.encode()).hexdigest()[:8]


def _encode_string(s: str) -> str:
    """ABI 동적 string 인코딩.

    offset(32) + length(32) + data(padded to 32)
    """
    s_bytes = s.encode("utf-8")
    length = len(s_bytes)

    # offset: 동적 데이터 시작 위치 (0x20 = 32)
    offset = "0000000000000000000000000000000000000000000000000000000000000020"
    # length
    length_hex = hex(length)[2:].zfill(64)
    # data: 32바이트 단위로 패딩
    padded_len = ((length + 31) // 32) * 32
    data_hex = s_bytes.hex().ljust(padded_len * 2, "0")

    return offset + length_hex + data_hex


def _decode_did_document(
    raw: str, did_string: str
) -> OnChainDIDDocument | None:
    """ABI 인코딩된 DIDDocument 튜플을 디코딩합니다.

    Solidity struct: (uint256 agentId, address owner, address tbaAddress,
                      bool active, uint256 createdAt, uint256 updatedAt)
    """
    try:
        # 0x 제거
        data = raw[2:] if raw.startswith("0x") else raw

        # 최소 6 * 64 = 384 hex chars 필요 (offset 이후)
        if len(data) < 384:
            return None

        # 동적 반환은 offset부터 시작 — 간단히 순차 파싱
        # agentId (uint256)
        agent_id = int(data[0:64], 16)
        # owner (address, 20바이트 우측정렬)
        owner = "0x" + data[64 + 24 : 128]
        # tbaAddress
        tba_address = "0x" + data[128 + 24 : 192]
        # active (bool)
        active = int(data[192:256], 16) != 0
        # createdAt
        created_at = int(data[256:320], 16)
        # updatedAt
        updated_at = int(data[320:384], 16)

        return OnChainDIDDocument(
            agent_id=agent_id,
            did_string=did_string,
            owner=owner,
            tba_address=tba_address,
            active=active,
            created_at=created_at,
            updated_at=updated_at,
        )
    except Exception as e:
        logger.error(f"DID Document 디코딩 실패: {e}")
        return None
