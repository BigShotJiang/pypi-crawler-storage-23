"""TBAManager — ERC-6551 Token Bound Account 관리 (S3-03)

AgentNFT에 종속된 TBA 지갑의 주소 계산, 잔액 조회, 트랜잭션 실행을 담당합니다.
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger("dapparena_sdk.wallet.tba_manager")


@dataclass
class TBAInfo:
    """TBA 계정 정보."""

    address: str
    agent_id: int
    nft_contract: str
    chain_id: int
    balance_wei: int = 0

    @property
    def balance_wlc(self) -> float:
        """WLC 잔액 (18 decimals)."""
        return self.balance_wei / 1e18


class TBAManager:
    """ERC-6551 TBA 지갑 관리 클라이언트.

    Usage::

        mgr = TBAManager(
            rpc_url="https://rpc.worldland.foundation",
            registry_address="0x...",
            implementation_address="0x...",
            nft_contract="0x...",
        )
        tba = await mgr.get_tba_info(agent_id=1)
        print(f"TBA: {tba.address}, Balance: {tba.balance_wlc} WLC")
    """

    def __init__(
        self,
        rpc_url: str = "https://rpc.worldland.foundation",
        registry_address: str = "",
        implementation_address: str = "",
        nft_contract: str = "",
        chain_id: int = 103,  # WorldLand
    ):
        self.rpc_url = rpc_url
        self.registry_address = registry_address
        self.implementation_address = implementation_address
        self.nft_contract = nft_contract
        self.chain_id = chain_id
        self._client = httpx.AsyncClient(timeout=30.0)

    # ----------------------------------------------------------
    # TBA 주소 계산 (오프체인 CREATE2)
    # ----------------------------------------------------------

    def compute_tba_address(
        self,
        agent_id: int,
        salt: int = 0,
    ) -> str:
        """CREATE2 결정적 TBA 주소를 오프체인에서 계산합니다.

        ERC-1167 minimal proxy + context data (salt, chainId, tokenContract, tokenId).

        Args:
            agent_id: AgentNFT 토큰 ID
            salt: 고유 salt (기본 0)

        Returns:
            TBA 주소 (0x 접두사 포함)
        """
        # 바이트코드 구성: proxy header + implementation + proxy footer + context
        impl_clean = self.implementation_address.lower().replace("0x", "")
        nft_clean = self.nft_contract.lower().replace("0x", "")

        proxy_header = "3d60ad80600a3d3981f3363d3d373d3d3d363d73"
        proxy_footer = "5af43d82803e903d91602b57fd5bf3"

        # Context: abi.encode(salt, chainId, tokenContract, tokenId)
        context = (
            hex(salt)[2:].zfill(64)
            + hex(self.chain_id)[2:].zfill(64)
            + nft_clean.zfill(64)
            + hex(agent_id)[2:].zfill(64)
        )

        creation_code = proxy_header + impl_clean + proxy_footer + context
        creation_code_bytes = bytes.fromhex(creation_code)

        # keccak256 대신 sha3_256 사용 (순수 Python)
        bytecode_hash = hashlib.sha3_256(creation_code_bytes).digest()

        # CREATE2: keccak256(0xff ++ registry ++ salt ++ keccak256(code))
        registry_clean = self.registry_address.lower().replace("0x", "")
        salt_bytes = salt.to_bytes(32, "big")

        pre_image = (
            b"\xff"
            + bytes.fromhex(registry_clean)
            + salt_bytes
            + bytecode_hash
        )
        address_hash = hashlib.sha3_256(pre_image).digest()
        address = "0x" + address_hash[-20:].hex()

        return address

    # ----------------------------------------------------------
    # 온체인 조회
    # ----------------------------------------------------------

    async def get_tba_info(self, agent_id: int, salt: int = 0) -> TBAInfo:
        """TBA 정보를 조회합니다 (주소 계산 + 잔액 조회).

        Args:
            agent_id: AgentNFT 토큰 ID
            salt: TBA salt

        Returns:
            TBAInfo 인스턴스
        """
        address = self.compute_tba_address(agent_id, salt)
        balance = await self._get_balance(address)

        return TBAInfo(
            address=address,
            agent_id=agent_id,
            nft_contract=self.nft_contract,
            chain_id=self.chain_id,
            balance_wei=balance,
        )

    async def _get_balance(self, address: str) -> int:
        """eth_getBalance RPC 호출."""
        try:
            payload = {
                "jsonrpc": "2.0",
                "method": "eth_getBalance",
                "params": [address, "latest"],
                "id": 1,
            }
            resp = await self._client.post(self.rpc_url, json=payload)
            resp.raise_for_status()
            result = resp.json()
            if "error" in result:
                logger.warning(f"잔액 조회 RPC 에러: {result['error']}")
                return 0
            return int(result.get("result", "0x0"), 16)
        except Exception as e:
            logger.warning(f"잔액 조회 실패: {e}")
            return 0

    # ----------------------------------------------------------
    # 트랜잭션 빌드
    # ----------------------------------------------------------

    def build_execute_tx(
        self,
        tba_address: str,
        to: str,
        value: int = 0,
        data: str = "0x",
    ) -> dict[str, Any]:
        """TBA의 execute() 호출 트랜잭션을 빌드합니다.

        AgentTBA.execute(address to, uint256 value, bytes data, uint8 operation)

        Args:
            tba_address: TBA 주소
            to: 대상 주소
            value: 전송할 WLC (wei)
            data: 호출 데이터

        Returns:
            트랜잭션 딕셔너리
        """
        # execute(address,uint256,bytes,uint8) selector
        selector = _function_selector("execute(address,uint256,bytes,uint8)")

        to_clean = to.lower().replace("0x", "").zfill(64)
        value_hex = hex(value)[2:].zfill(64)
        # operation = 0 (CALL)
        operation = "00".zfill(64)

        # bytes는 동적 타입 → offset
        # 4개 파라미터: addr(32) + value(32) + bytes_offset(32) + operation(32) = 128
        bytes_offset = "0000000000000000000000000000000000000000000000000000000000000080"

        # bytes data 인코딩
        data_bytes = bytes.fromhex(data.replace("0x", "")) if data != "0x" else b""
        data_len = hex(len(data_bytes))[2:].zfill(64)
        padded_len = ((len(data_bytes) + 31) // 32) * 32
        data_hex = data_bytes.hex().ljust(padded_len * 2, "0") if data_bytes else ""

        calldata = (
            "0x"
            + selector
            + to_clean
            + value_hex
            + bytes_offset
            + operation
            + data_len
            + data_hex
        )

        return {
            "to": tba_address,
            "data": calldata,
            "value": hex(0),  # TBA가 value를 전달
        }

    async def close(self) -> None:
        """HTTP 클라이언트를 닫습니다."""
        await self._client.aclose()


def _function_selector(signature: str) -> str:
    """Solidity 함수 시그니처의 4바이트 셀렉터."""
    return hashlib.sha3_256(signature.encode()).hexdigest()[:8]
