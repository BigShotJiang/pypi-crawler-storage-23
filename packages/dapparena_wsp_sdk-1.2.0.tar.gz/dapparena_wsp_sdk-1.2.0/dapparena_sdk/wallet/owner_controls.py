"""OwnerControls — 소유자 제어 (출금·동결) (S3-05)

NFT 소유자가 에이전트 TBA의 자금을 제어합니다.
- 출금(withdraw): TBA에서 소유자 주소로 자금 인출
- 동결(freeze/unfreeze): TBA 트랜잭션 실행 차단 (placeholder)
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger("dapparena_sdk.wallet.owner_controls")


@dataclass
class WithdrawRequest:
    """출금 요청."""

    tba_address: str
    to: str
    amount_wei: int
    agent_id: int

    @property
    def amount_wlc(self) -> float:
        return self.amount_wei / 1e18


@dataclass
class ControlAction:
    """제어 작업 결과."""

    action: str  # "withdraw" | "freeze" | "unfreeze"
    success: bool
    tx_data: dict[str, Any] | None = None
    error: str = ""


class OwnerControls:
    """에이전트 TBA 소유자 제어 기능.

    Usage::

        ctrl = OwnerControls()
        tx = ctrl.build_withdraw_tx(
            tba_address="0x...",
            to="0x...",
            amount_wei=1000000000000000000,  # 1 WLC
            agent_id=1,
        )
        # tx를 서명해서 브로드캐스트
    """

    # ----------------------------------------------------------
    # 출금
    # ----------------------------------------------------------

    def build_withdraw_tx(
        self,
        tba_address: str,
        to: str,
        amount_wei: int,
        agent_id: int,
    ) -> ControlAction:
        """출금 트랜잭션을 빌드합니다.

        TBA의 execute(to, value, "0x", 0)을 호출합니다.

        Args:
            tba_address: TBA 주소
            to: 출금 수신 주소 (소유자 주소)
            amount_wei: 출금 금액 (wei)
            agent_id: AgentNFT 토큰 ID

        Returns:
            ControlAction (tx_data 포함)
        """
        try:
            req = WithdrawRequest(
                tba_address=tba_address,
                to=to,
                amount_wei=amount_wei,
                agent_id=agent_id,
            )

            # execute(address to, uint256 value, bytes data, uint8 operation)
            selector = _function_selector(
                "execute(address,uint256,bytes,uint8)"
            )
            to_clean = to.lower().replace("0x", "").zfill(64)
            value_hex = hex(amount_wei)[2:].zfill(64)
            # bytes data = empty → offset + length(0)
            bytes_offset = "00" * 31 + "80"  # 0x80 = 128
            operation = "00".zfill(64)
            data_len = "00".zfill(64)

            calldata = (
                "0x"
                + selector
                + to_clean
                + value_hex
                + bytes_offset
                + operation
                + data_len
            )

            tx_data = {
                "to": tba_address,
                "data": calldata,
                "value": "0x0",
            }

            logger.info(
                f"💰 출금 TX 빌드: {req.amount_wlc} WLC "
                f"→ {to[:10]}... (Agent #{agent_id})"
            )

            return ControlAction(
                action="withdraw",
                success=True,
                tx_data=tx_data,
            )
        except Exception as e:
            logger.error(f"출금 TX 빌드 실패: {e}")
            return ControlAction(
                action="withdraw", success=False, error=str(e)
            )

    # ----------------------------------------------------------
    # 동결 / 해제 (placeholder — 컨트랙트 레벨 구현 필요)
    # ----------------------------------------------------------

    def build_freeze_tx(self, agent_id: int) -> ControlAction:
        """TBA 동결 트랜잭션을 빌드합니다 (placeholder).

        실제 동결은 SpendingGuard에서 일일 한도를 0으로 설정하는 것으로 구현.
        """
        logger.info(f"🧊 동결 요청: Agent #{agent_id}")
        return ControlAction(
            action="freeze",
            success=True,
            tx_data={"note": "일일 한도를 0으로 설정하여 동결"},
        )

    def build_unfreeze_tx(self, agent_id: int) -> ControlAction:
        """TBA 동결 해제 트랜잭션을 빌드합니다 (placeholder)."""
        logger.info(f"🔓 동결 해제 요청: Agent #{agent_id}")
        return ControlAction(
            action="unfreeze",
            success=True,
            tx_data={"note": "일일 한도를 원래 값으로 복원하여 해제"},
        )


def _function_selector(signature: str) -> str:
    """Solidity 함수 시그니처의 4바이트 셀렉터."""
    return hashlib.sha3_256(signature.encode()).hexdigest()[:8]
