"""DappArena WSP SDK v1.2.0 — WorldLand Scholar Protocol

Slice 1: A2A v2, Orchestrator, BaseAgent
Slice 2: MCP, RAG, LLM Router, Security
Slice 3: Identity (DID), Wallet (ERC-6551), x402 Payment, Trust Registry
"""

__version__ = "1.2.0"
