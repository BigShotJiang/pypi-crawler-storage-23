"""Trust Registry 모듈 단위 테스트 — TrustRegistry (S3-08)"""

import pytest

from dapparena_sdk.trust_registry.registry import TrustRegistry, TrustedAgent


class TestTrustRegistry:
    """TrustRegistry 단위 테스트."""

    def test_build_register_tx(self):
        """등록 트랜잭션 빌드."""
        reg = TrustRegistry(contract_address="0xTrustReg")
        tx = reg.build_register_tx(
            agent_id=1,
            did_string="did:worldland:agent:cheolsu",
        )
        assert tx["to"] == "0xTrustReg"
        assert tx["data"].startswith("0x")
        assert tx["value"] == "0x0"

    def test_build_revoke_tx(self):
        """해제 트랜잭션 빌드."""
        reg = TrustRegistry(contract_address="0xTrustReg")
        tx = reg.build_revoke_tx(agent_id=1)
        assert tx["to"] == "0xTrustReg"
        assert tx["data"].startswith("0x")

    @pytest.mark.asyncio
    async def test_is_trusted_no_contract(self):
        """컨트랙트 미설정 시 False 반환."""
        reg = TrustRegistry(contract_address="")
        result = await reg.is_trusted(agent_id=1)
        assert result is False

    def test_register_tx_contains_did(self):
        """등록 TX에 DID 문자열이 인코딩되어 있는지 확인."""
        reg = TrustRegistry(contract_address="0xReg")
        tx = reg.build_register_tx(
            agent_id=1,
            did_string="did:worldland:agent:test",
        )
        # DID 문자열의 hex 인코딩이 calldata에 포함되어야 함
        did_hex = "did:worldland:agent:test".encode().hex()
        assert did_hex in tx["data"]


class TestTrustedAgent:
    """TrustedAgent 데이터 테스트."""

    def test_creation(self):
        agent = TrustedAgent(
            agent_id=1,
            did_string="did:worldland:agent:cheolsu",
            trusted=True,
            registered_at=1709475600,
        )
        assert agent.agent_id == 1
        assert agent.did_string == "did:worldland:agent:cheolsu"
        assert agent.trusted is True
