"""단위 테스트 — Orchestrator (UT-S1-05, UT-S1-06, IT-S1-02, IT-S1-03)"""

import json
import os
import tempfile

import pytest

from dapparena_sdk.a2a.models import Artifact, Task, TaskState
from dapparena_sdk.orchestrator.workflow import Workflow, WorkflowStep, load_workflow
from dapparena_sdk.orchestrator.state import WorkflowState, WorkflowStatus


class TestWorkflowParser:
    """UT-S1-05: YAML 워크플로 파싱"""

    def test_load_workflow_from_yaml(self, tmp_path):
        yaml_content = """
name: test_pipeline
description: "테스트 파이프라인"
steps:
  - agent: agent_a
    url: http://localhost:8001
    role: researcher
    timeout: 60
    on_failure: retry
    max_retries: 2
  - agent: agent_b
    url: http://localhost:8002
    role: editor
    timeout: 90
  - agent: agent_c
    url: http://localhost:8003
    role: evaluator
"""
        yaml_file = tmp_path / "test_workflow.yaml"
        yaml_file.write_text(yaml_content, encoding="utf-8")

        workflow = load_workflow(yaml_file)

        assert workflow.name == "test_pipeline"
        assert workflow.description == "테스트 파이프라인"
        assert len(workflow.steps) == 3

    def test_workflow_step_fields(self, tmp_path):
        yaml_content = """
name: field_test
steps:
  - agent: cheolsu
    url: http://localhost:8101
    role: researcher
    timeout: 120
    on_failure: retry
    max_retries: 3
"""
        yaml_file = tmp_path / "field_test.yaml"
        yaml_file.write_text(yaml_content, encoding="utf-8")

        workflow = load_workflow(yaml_file)
        step = workflow.steps[0]

        assert step.agent == "cheolsu"
        assert step.url == "http://localhost:8101"
        assert step.role == "researcher"
        assert step.timeout == 120
        assert step.on_failure == "retry"
        assert step.max_retries == 3

    def test_workflow_step_defaults(self, tmp_path):
        yaml_content = """
name: defaults_test
steps:
  - agent: simple
    url: http://localhost:9000
"""
        yaml_file = tmp_path / "defaults.yaml"
        yaml_file.write_text(yaml_content, encoding="utf-8")

        workflow = load_workflow(yaml_file)
        step = workflow.steps[0]

        assert step.timeout == 120
        assert step.on_failure == "abort"
        assert step.max_retries == 1

    def test_load_workflow_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            load_workflow("/nonexistent/path.yaml")

    def test_textbook_pipeline_yaml(self):
        """실제 textbook_pipeline.yaml 파싱 테스트"""
        yaml_path = os.path.join(
            os.path.dirname(__file__),
            "..", "..", "..", "agents", "wsp", "workflows", "textbook_pipeline.yaml",
        )
        if not os.path.exists(yaml_path):
            pytest.skip("textbook_pipeline.yaml not found")

        workflow = load_workflow(yaml_path)
        assert workflow.name == "textbook_pipeline"
        assert len(workflow.steps) == 3
        assert workflow.steps[0].agent == "cheolsu"
        assert workflow.steps[1].agent == "younghee"
        assert workflow.steps[2].agent == "mansu"


class TestWorkflowState:
    """워크플로 상태 관리 테스트"""

    def test_state_serialization(self):
        state = WorkflowState(
            workflow_id="test-123",
            workflow_name="test",
            status=WorkflowStatus.RUNNING,
            current_step=2,
            total_steps=3,
        )
        d = state.to_dict()
        assert d["workflow_id"] == "test-123"
        assert d["status"] == "running"
        assert d["current_step"] == 2

    def test_elapsed_seconds(self):
        import time
        state = WorkflowState(
            workflow_id="timer-test",
            started_at=time.time() - 5.0,
        )
        assert state.elapsed_seconds >= 4.9


class TestOrchestratorEngine:
    """UT-S1-06: 순차 실행 시 이전 단계 output이 다음 단계 input으로 전달"""

    def test_step_output_becomes_next_input(self):
        """검증: 이전 단계의 Artifact가 다음 단계로 전달됨"""
        # 이 테스트는 엔진 로직을 직접 검증
        artifact1 = Artifact(name="step1_output", data="data from step 1")
        task = Task(message="test", artifacts=[artifact1])

        # 다음 단계 Task 생성 시 artifacts 포함 확인
        next_task = Task(
            message=task.message,
            artifacts=task.artifacts,
        )
        assert len(next_task.artifacts) == 1
        assert next_task.artifacts[0].name == artifact1.name
        assert next_task.artifacts[0].data == artifact1.data
