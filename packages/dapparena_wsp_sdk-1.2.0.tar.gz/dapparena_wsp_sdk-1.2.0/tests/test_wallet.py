"""Wallet 모듈 단위 테스트 — TBAManager, Keystore, OwnerControls (S3-03~05)"""

import os
import tempfile
from pathlib import Path

import pytest

from dapparena_sdk.wallet.tba_manager import TBAManager, TBAInfo
from dapparena_sdk.wallet.keystore import Keystore
from dapparena_sdk.wallet.owner_controls import OwnerControls, ControlAction


class TestTBAManager:
    """TBAManager 단위 테스트."""

    def test_compute_tba_address(self):
        """TBA 주소 계산이 결정적인지 확인."""
        mgr = TBAManager(
            registry_address="0x1234567890abcdef1234567890abcdef12345678",
            implementation_address="0xabcdefabcdefabcdefabcdefabcdefabcdefabcd",
            nft_contract="0x9876543210fedcba9876543210fedcba98765432",
            chain_id=103,
        )
        addr1 = mgr.compute_tba_address(agent_id=1, salt=0)
        addr2 = mgr.compute_tba_address(agent_id=1, salt=0)
        assert addr1 == addr2, "같은 입력에 대해 같은 주소가 나와야 함"

    def test_different_agents_different_addresses(self):
        """다른 에이전트 ID는 다른 TBA 주소를 생성."""
        mgr = TBAManager(
            registry_address="0x1234567890abcdef1234567890abcdef12345678",
            implementation_address="0xabcdefabcdefabcdefabcdefabcdefabcdefabcd",
            nft_contract="0x9876543210fedcba9876543210fedcba98765432",
            chain_id=103,
        )
        addr1 = mgr.compute_tba_address(agent_id=1)
        addr2 = mgr.compute_tba_address(agent_id=2)
        assert addr1 != addr2

    def test_address_format(self):
        """TBA 주소가 올바른 Ethereum 주소 형식인지 확인."""
        mgr = TBAManager(
            registry_address="0x1234567890abcdef1234567890abcdef12345678",
            implementation_address="0xabcdefabcdefabcdefabcdefabcdefabcdefabcd",
            nft_contract="0x9876543210fedcba9876543210fedcba98765432",
        )
        addr = mgr.compute_tba_address(agent_id=1)
        assert addr.startswith("0x")
        assert len(addr) == 42  # 0x + 40 hex chars

    def test_build_execute_tx(self):
        """execute() 트랜잭션 빌드 검증."""
        mgr = TBAManager()
        tx = mgr.build_execute_tx(
            tba_address="0xTBA",
            to="0xRecipient",
            value=1000000000000000000,  # 1 WLC
        )
        assert tx["to"] == "0xTBA"
        assert tx["data"].startswith("0x")
        assert len(tx["data"]) > 10


class TestTBAInfo:
    """TBAInfo 데이터 클래스 테스트."""

    def test_balance_wlc_conversion(self):
        """wei → WLC 변환 확인."""
        info = TBAInfo(
            address="0x123",
            agent_id=1,
            nft_contract="0x456",
            chain_id=103,
            balance_wei=1000000000000000000,
        )
        assert info.balance_wlc == 1.0

    def test_zero_balance(self):
        info = TBAInfo(
            address="0x123", agent_id=1,
            nft_contract="0x456", chain_id=103,
        )
        assert info.balance_wlc == 0.0


class TestKeystore:
    """Keystore 단위 테스트."""

    def test_save_and_load(self):
        """암호화 저장 → 복호화 로드 라운드트립."""
        with tempfile.TemporaryDirectory() as tmpdir:
            ks = Keystore(key_dir=tmpdir)
            original_key = "a" * 64  # 32-byte hex key

            ks.save("test_agent", original_key, password="test-password")
            recovered = ks.load("test_agent", password="test-password")

            assert recovered == original_key

    def test_wrong_password(self):
        """잘못된 패스워드로 로드 시 ValueError."""
        with tempfile.TemporaryDirectory() as tmpdir:
            ks = Keystore(key_dir=tmpdir)
            ks.save("test", "b" * 64, password="correct")

            with pytest.raises(ValueError):
                ks.load("test", password="wrong")

    def test_file_not_found(self):
        """존재하지 않는 키 로드 시 FileNotFoundError."""
        with tempfile.TemporaryDirectory() as tmpdir:
            ks = Keystore(key_dir=tmpdir)
            with pytest.raises(FileNotFoundError):
                ks.load("nonexistent", password="any")

    def test_exists(self):
        """키스토어 존재 여부 확인."""
        with tempfile.TemporaryDirectory() as tmpdir:
            ks = Keystore(key_dir=tmpdir)
            assert not ks.exists("test")
            ks.save("test", "c" * 64, password="pw")
            assert ks.exists("test")

    def test_delete(self):
        """키스토어 삭제."""
        with tempfile.TemporaryDirectory() as tmpdir:
            ks = Keystore(key_dir=tmpdir)
            ks.save("test", "d" * 64, password="pw")
            assert ks.exists("test")
            assert ks.delete("test")
            assert not ks.exists("test")

    def test_file_permissions(self):
        """키스토어 파일 생성 확인."""
        with tempfile.TemporaryDirectory() as tmpdir:
            ks = Keystore(key_dir=tmpdir)
            path = ks.save("test", "e" * 64, password="pw")
            assert path.exists()

    def test_0x_prefix_handling(self):
        """0x 접두사가 있는 키도 정상 처리."""
        with tempfile.TemporaryDirectory() as tmpdir:
            ks = Keystore(key_dir=tmpdir)
            ks.save("test", "0x" + "f" * 64, password="pw")
            recovered = ks.load("test", password="pw")
            assert recovered == "f" * 64


class TestOwnerControls:
    """OwnerControls 단위 테스트."""

    def test_build_withdraw_tx(self):
        """출금 트랜잭션 빌드."""
        ctrl = OwnerControls()
        result = ctrl.build_withdraw_tx(
            tba_address="0xTBA",
            to="0xOwner",
            amount_wei=2000000000000000000,
            agent_id=1,
        )
        assert result.action == "withdraw"
        assert result.success
        assert result.tx_data is not None
        assert result.tx_data["to"] == "0xTBA"

    def test_build_freeze_tx(self):
        """동결 트랜잭션 빌드."""
        ctrl = OwnerControls()
        result = ctrl.build_freeze_tx(agent_id=1)
        assert result.action == "freeze"
        assert result.success

    def test_build_unfreeze_tx(self):
        """해제 트랜잭션 빌드."""
        ctrl = OwnerControls()
        result = ctrl.build_unfreeze_tx(agent_id=1)
        assert result.action == "unfreeze"
        assert result.success
