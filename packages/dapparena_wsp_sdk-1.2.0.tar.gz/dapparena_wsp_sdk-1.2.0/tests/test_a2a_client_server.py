"""통합 테스트 — A2A Client ↔ Server 통신 (UT-S1-03, UT-S1-04, IT-S1-01)"""

import pytest
from fastapi.testclient import TestClient

from dapparena_sdk.a2a.models import Artifact, Task, TaskState
from dapparena_sdk.a2a.server import register_agent, router, _task_store
from dapparena_sdk.base_agent import BaseAgentV2


# ── Mock 에이전트 ──

class MockAgent(BaseAgentV2):
    """테스트용 mock 에이전트."""

    def __init__(self):
        super().__init__(
            name="mock_agent",
            description="테스트용 에이전트",
            port=9999,
        )

    async def handle_task(self, task: Task) -> Task:
        task.artifacts.append(Artifact(
            name="mock_output",
            mime_type="text/plain",
            data=f"Processed: {task.message}",
        ))
        return task


class FailingAgent(BaseAgentV2):
    """테스트용 실패 에이전트."""

    def __init__(self):
        super().__init__(name="failing_agent", port=9998)

    async def handle_task(self, task: Task) -> Task:
        raise RuntimeError("Intentional test failure")


# ── FastAPI 앱 생성 ──

def _create_test_app(agent: BaseAgentV2):
    from fastapi import FastAPI
    app = FastAPI()
    register_agent(agent)
    app.include_router(router)
    _task_store.clear()
    return app


# ── Tests ──

class TestA2AServer:
    """UT-S1-04: tasks/send 엔드포인트 테스트"""

    def test_send_task_success(self):
        app = _create_test_app(MockAgent())
        client = TestClient(app)

        task_data = Task(message="테스트 메시지").to_dict()
        resp = client.post("/a2a/tasks/send", json=task_data)

        assert resp.status_code == 200
        result = resp.json()
        assert result["state"] == "completed"
        assert len(result["artifacts"]) == 1
        assert result["artifacts"][0]["name"] == "mock_output"

    def test_send_task_preserves_id(self):
        app = _create_test_app(MockAgent())
        client = TestClient(app)

        task = Task(message="ID 보존 테스트")
        original_id = task.id
        resp = client.post("/a2a/tasks/send", json=task.to_dict())

        assert resp.status_code == 200
        assert resp.json()["id"] == original_id

    def test_send_task_failure(self):
        app = _create_test_app(FailingAgent())
        client = TestClient(app)

        task_data = Task(message="실패 테스트").to_dict()
        resp = client.post("/a2a/tasks/send", json=task_data)

        assert resp.status_code == 500
        result = resp.json()
        assert result["state"] == "failed"
        assert "error" in result["metadata"]

    def test_get_task(self):
        app = _create_test_app(MockAgent())
        client = TestClient(app)

        task = Task(message="조회 테스트")
        client.post("/a2a/tasks/send", json=task.to_dict())

        resp = client.get(f"/a2a/tasks/{task.id}")
        assert resp.status_code == 200
        assert resp.json()["id"] == task.id

    def test_get_task_not_found(self):
        app = _create_test_app(MockAgent())
        client = TestClient(app)

        resp = client.get("/a2a/tasks/nonexistent-id")
        assert resp.status_code == 404

    def test_cancel_task(self):
        app = _create_test_app(MockAgent())
        client = TestClient(app)

        task = Task(message="취소 테스트")
        client.post("/a2a/tasks/send", json=task.to_dict())

        resp = client.post(f"/a2a/tasks/{task.id}/cancel")
        assert resp.status_code == 200
        assert resp.json()["state"] == "failed"
        assert resp.json()["metadata"]["cancelled"] is True


class TestA2AIntegration:
    """IT-S1-01: Client → Server 직접 통신"""

    def test_full_roundtrip(self):
        """Client가 Task 전송 → Server가 수신 → Agent 처리 → 결과 반환"""
        app = _create_test_app(MockAgent())
        client = TestClient(app)

        task = Task(
            message="Blockchain 교재 내용 분석",
            metadata={"source": "test"},
        )
        resp = client.post("/a2a/tasks/send", json=task.to_dict())

        assert resp.status_code == 200
        result = Task.from_dict(resp.json())
        assert result.state == TaskState.COMPLETED
        assert result.id == task.id
        assert any(a.name == "mock_output" for a in result.artifacts)
        assert "Processed:" in result.artifacts[0].data
