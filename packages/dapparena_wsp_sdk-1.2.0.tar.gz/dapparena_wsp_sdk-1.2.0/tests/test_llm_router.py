"""LLM Router 테스트 — S2-07"""

import pytest

from dapparena_sdk.llm.router import LLMRouter, RoutingDecision


class TestLLMRouter:
    """LLM Router 테스트."""

    def test_route_default_local(self):
        router = LLMRouter(prefer_local=True)
        decision = router.route("블록체인 설명해줘")
        assert decision.is_local is True
        assert decision.provider == "ollama"

    def test_route_pii_forces_local(self):
        """PII 포함 시 반드시 로컬 LLM 사용."""
        router = LLMRouter(prefer_local=False, openai_api_key="test-key")
        decision = router.route("학생 010-1234-5678의 과제를 평가해주세요")
        assert decision.is_local is True
        assert "전화번호" in decision.reason

    def test_route_email_pii(self):
        router = LLMRouter(prefer_local=False, openai_api_key="test-key")
        decision = router.route("student@example.com 에게 결과를 보내주세요")
        assert decision.is_local is True
        assert "이메일" in decision.reason

    def test_route_student_id_pii(self):
        router = LLMRouter(prefer_local=False, openai_api_key="test-key")
        decision = router.route("학번 2024-123456 학생의 성적입니다")
        assert decision.is_local is True
        assert "학번" in decision.reason

    def test_route_no_pii_allows_external(self):
        router = LLMRouter(prefer_local=False, openai_api_key="test-key")
        decision = router.route("블록체인의 합의 알고리즘에 대해 설명해주세요")
        assert decision.is_local is False
        assert decision.provider == "openai"

    def test_route_fallback_when_no_api_key(self):
        router = LLMRouter(prefer_local=False, openai_api_key="")
        decision = router.route("블록체인 설명")
        assert decision.is_local is True
        assert "폴백" in decision.reason

    def test_detect_pii_multiple(self):
        pii_types = LLMRouter._detect_pii("학생 010-1234-5678, 이메일 test@abc.com")
        assert "전화번호" in pii_types
        assert "이메일" in pii_types

    def test_detect_pii_clean(self):
        pii_types = LLMRouter._detect_pii("블록체인 기초 교재를 만들어주세요")
        assert len(pii_types) == 0
