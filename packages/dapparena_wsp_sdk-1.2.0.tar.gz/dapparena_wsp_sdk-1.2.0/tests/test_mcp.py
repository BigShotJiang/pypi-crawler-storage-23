"""MCP Client/Server 프레임워크 테스트 — S2-01

MCP Server에 Tool/Resource 등록, MCP Client로 호출하는 전체 흐름을 테스트합니다.
"""

import pytest
from fastapi.testclient import TestClient

from dapparena_sdk.mcp.server import (
    MCPServer,
    _tool_registry,
    _resource_registry,
    create_mcp_router,
)


@pytest.fixture(autouse=True)
def _clear_registries():
    """각 테스트 전후로 전역 레지스트리를 초기화합니다."""
    _tool_registry.clear()
    _resource_registry.clear()
    yield
    _tool_registry.clear()
    _resource_registry.clear()


@pytest.fixture
def ieee_app():
    """IEEE MCP Server 앱을 생성합니다 (전역 레지스트리 초기화 후 재등록)."""
    _tool_registry.clear()
    _resource_registry.clear()
    # Re-import to re-register tools
    import importlib
    import dapparena_sdk.mcp.servers.ieee_server as ieee_mod
    importlib.reload(ieee_mod)
    return ieee_mod.ieee_server.create_app()


class TestMCPServer:
    """MCP Server 테스트."""

    def test_create_server(self):
        server = MCPServer("test-server", port=9999)
        assert server.name == "test-server"
        assert server.port == 9999

    def test_register_tool(self):
        server = MCPServer("test")

        @server.tool("add", "두 수를 더합니다")
        async def add(a: int, b: int):
            return a + b

        assert "add" in server._tools
        assert server._tools["add"].description == "두 수를 더합니다"

    def test_register_resource(self):
        server = MCPServer("test")

        @server.resource("data://test", name="테스트 데이터")
        async def get_test_data():
            return {"hello": "world"}

        assert "data://test" in server._resources

    def test_health_endpoint(self):
        server = MCPServer("test")

        @server.tool("dummy", "더미")
        async def dummy():
            return "ok"

        app = server.create_app()
        client = TestClient(app)

        resp = client.get("/mcp/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "online"
        assert data["tools_count"] == 1

    def test_list_tools(self):
        server = MCPServer("test")

        @server.tool("tool_a", "Tool A 설명")
        async def tool_a():
            return "a"

        @server.tool("tool_b", "Tool B 설명")
        async def tool_b():
            return "b"

        app = server.create_app()
        client = TestClient(app)

        resp = client.get("/mcp/tools")
        assert resp.status_code == 200
        tools = resp.json()["tools"]
        assert len(tools) == 2
        names = {t["name"] for t in tools}
        assert "tool_a" in names
        assert "tool_b" in names

    def test_call_tool(self):
        server = MCPServer("test")

        @server.tool("greet", "인사")
        async def greet(name: str):
            return f"안녕하세요, {name}님!"

        app = server.create_app()
        client = TestClient(app)

        resp = client.post("/mcp/tools/call", json={
            "tool": "greet",
            "arguments": {"name": "철수"},
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["tool"] == "greet"
        assert "철수" in data["result"]

    def test_call_unknown_tool(self):
        server = MCPServer("test")
        app = server.create_app()
        client = TestClient(app)

        resp = client.post("/mcp/tools/call", json={
            "tool": "nonexistent",
            "arguments": {},
        })
        assert resp.status_code == 404

    def test_list_and_read_resources(self):
        server = MCPServer("test")

        @server.resource("test://data", name="테스트")
        async def get_data():
            return {"value": 42}

        app = server.create_app()
        client = TestClient(app)

        # List
        resp = client.get("/mcp/resources")
        assert resp.status_code == 200
        resources = resp.json()["resources"]
        assert len(resources) == 1
        assert resources[0]["uri"] == "test://data"

        # Read
        resp = client.get("/mcp/resources/read", params={"uri": "test://data"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["data"]["value"] == 42


class TestMCPIEEE:
    """IEEE MCP Server Mock 테스트."""

    def test_search_papers_mock(self, ieee_app):
        client = TestClient(ieee_app)
        resp = client.post("/mcp/tools/call", json={
            "tool": "search_papers",
            "arguments": {"query": "blockchain", "max_results": 3},
        })
        assert resp.status_code == 200
        papers = resp.json()["result"]
        assert len(papers) == 3
        assert all("title" in p for p in papers)

    def test_search_papers_zkp(self, ieee_app):
        client = TestClient(ieee_app)
        resp = client.post("/mcp/tools/call", json={
            "tool": "search_papers",
            "arguments": {"query": "ZKP", "max_results": 2},
        })
        assert resp.status_code == 200
        papers = resp.json()["result"]
        assert len(papers) == 2

    def test_get_paper_details_mock(self, ieee_app):
        client = TestClient(ieee_app)
        resp = client.post("/mcp/tools/call", json={
            "tool": "get_paper_details",
            "arguments": {"doi": "10.1109/TEST.2024.001"},
        })
        assert resp.status_code == 200
        assert resp.json()["result"]["mode"] == "mock"
