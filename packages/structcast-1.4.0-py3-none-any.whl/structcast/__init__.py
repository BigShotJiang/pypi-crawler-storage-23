"""StructCast: Elegantly orchestrating structured data via a flexible and serializable workflow."""

__version__ = "1.4.0"
