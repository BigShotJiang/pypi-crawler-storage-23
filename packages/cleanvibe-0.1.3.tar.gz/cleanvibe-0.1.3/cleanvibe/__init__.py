"""cleanvibe - scaffold AI-assisted coding projects and launch Claude Code."""

__version__ = "0.1.3"
