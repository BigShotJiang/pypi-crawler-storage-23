"""
Entry point for python -m agent_dump
"""

import sys

from agent_dump.cli import main

if __name__ == "__main__":
    sys.exit(main())
