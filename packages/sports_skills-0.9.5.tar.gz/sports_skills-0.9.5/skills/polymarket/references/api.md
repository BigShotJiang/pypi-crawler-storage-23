# Polymarket APIs

- **Gamma API** (gamma-api.polymarket.com): Market metadata, events, series. Public, no auth.
- **CLOB API** (clob.polymarket.com): Prices, order books, trades. Public reads, no auth.
