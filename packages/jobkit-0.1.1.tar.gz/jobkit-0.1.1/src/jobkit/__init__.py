"""
JobKit - Open Source AI-Powered Job Application Toolkit

Automate your job search with AI-tailored resumes and cover letters.
"""

__version__ = "0.1.0"
__author__ = "JobKit Contributors"
