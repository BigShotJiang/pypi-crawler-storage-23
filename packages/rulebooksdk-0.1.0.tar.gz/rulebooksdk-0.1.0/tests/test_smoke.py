"""Smoke tests — verify the SDK imports and instantiates correctly."""

from __future__ import annotations


def test_import_client():
    """Import the client class from the package entry point."""
    from rulebook import Rulebook, AsyncRulebook

    assert Rulebook is not None
    assert AsyncRulebook is not None


def test_instantiate_sync_client():
    """Instantiate a sync client with an explicit API key."""
    from rulebook import Rulebook

    client = Rulebook(api_key="test-key")
    assert client.api_key == "test-key"
    assert hasattr(client, "exchanges")
    assert hasattr(client, "with_raw_response")
    client.close()


def test_instantiate_async_client():
    """Instantiate an async client with an explicit API key."""
    from rulebook import AsyncRulebook

    client = AsyncRulebook(api_key="test-key")
    assert client.api_key == "test-key"
    assert hasattr(client, "exchanges")
    assert hasattr(client, "with_raw_response")


def test_missing_api_key(monkeypatch):
    """Client raises RulebookError when no API key is provided."""
    from rulebook import Rulebook, RulebookError

    monkeypatch.delenv("RULEBOOK_API_KEY", raising=False)

    with __import__("pytest").raises(RulebookError, match="api_key"):
        Rulebook()


def test_api_key_from_env(monkeypatch):
    """Client reads the API key from RULEBOOK_API_KEY env var."""
    from rulebook import Rulebook

    monkeypatch.setenv("RULEBOOK_API_KEY", "env-key")
    client = Rulebook()
    assert client.api_key == "env-key"
    client.close()


def test_context_manager():
    """Sync client works as a context manager."""
    from rulebook import Rulebook

    with Rulebook(api_key="test-key") as client:
        assert client.api_key == "test-key"


def test_with_options():
    """with_options returns a new client with overridden settings."""
    from rulebook import Rulebook

    client = Rulebook(api_key="test-key")
    client2 = client.with_options(timeout=99.0)
    assert client2 is not client
    assert client2.timeout.read == 99.0
    client.close()
    client2.close()


def test_exception_hierarchy():
    """All exception types import from the top-level package."""
    from rulebook import (
        RulebookError,
        APIError,
        APIConnectionError,
        APITimeoutError,
        APIStatusError,
        BadRequestError,
        AuthenticationError,
        PermissionDeniedError,
        NotFoundError,
        UnprocessableEntityError,
        RateLimitError,
        InternalServerError,
    )

    assert issubclass(APIError, RulebookError)
    assert issubclass(APIConnectionError, APIError)
    assert issubclass(APITimeoutError, APIConnectionError)
    assert issubclass(APIStatusError, APIError)
    assert issubclass(BadRequestError, APIStatusError)
    assert issubclass(AuthenticationError, APIStatusError)
    assert issubclass(PermissionDeniedError, APIStatusError)
    assert issubclass(NotFoundError, APIStatusError)
    assert issubclass(UnprocessableEntityError, APIStatusError)
    assert issubclass(RateLimitError, APIStatusError)
    assert issubclass(InternalServerError, APIStatusError)


def test_types_importable():
    """All response models import from the top-level types namespace."""
    from rulebook.types import Exchange, ExchangeDetail, DateRange

    assert Exchange is not None
    assert ExchangeDetail is not None
    assert DateRange is not None
