"""Integration tests against a running local API server.

Run with:
    pytest tests/test_integration.py -v

Requires the platform-api running on localhost:8000.
"""

from __future__ import annotations

import pytest
import pytest_asyncio

from rulebook import (
    AsyncRulebook,
    Rulebook,
    AuthenticationError,
    NotFoundError,
    PermissionDeniedError,
    UnprocessableEntityError,
)
from rulebook._response import APIResponse
from rulebook.types import Exchange, ExchangeDetail, DateRange

BASE_URL = "http://localhost:8000/api/v1"
API_KEY = "1ea877ead3584934b00ea7205cc785d7"

# Known data for Waleed's account (access to "Fee - CBOE US Options" only)
EXCHANGE_NAME = "fee_cboe_us_options"
VALID_RESULT_ID = "6eca1ca4-1ece-4dc3-bc2c-34d7c9df4b40"
VALID_VERSION_ID = "c9ffbb45-cfe9-4b16-b4cd-3587e4c29d3c"
FORBIDDEN_RESULT_ID = "41d9eed9-56cf-447a-975e-d4f1cda010a3"
FORBIDDEN_VERSION_ID = "75d72b98-e065-4ce1-93b0-3f161c9d9bae"
NONEXISTENT_UUID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee"


@pytest.fixture
def client() -> Rulebook:
    c = Rulebook(api_key=API_KEY, base_url=BASE_URL, max_retries=0, timeout=60.0)
    yield c
    c.close()


@pytest.fixture
def bad_client() -> Rulebook:
    c = Rulebook(api_key="bad-key", base_url=BASE_URL, max_retries=0, timeout=60.0)
    yield c
    c.close()


@pytest_asyncio.fixture
async def async_client() -> AsyncRulebook:
    c = AsyncRulebook(api_key=API_KEY, base_url=BASE_URL, max_retries=0, timeout=60.0)
    yield c
    await c.close()


# ===================================================================
# Exchanges — list
# ===================================================================


class TestExchangesListIntegration:

    def test_list_returns_exchanges(self, client):
        result = client.exchanges.list()

        assert isinstance(result, list)
        assert len(result) >= 1

        ex = result[0]
        assert isinstance(ex, Exchange)
        assert ex.name == EXCHANGE_NAME
        assert ex.display_name == "Fee - CBOE US Options"
        assert "OPTION" in ex.fee_types
        assert ex.record_count > 0

    def test_list_unauthenticated(self, bad_client):
        with pytest.raises(AuthenticationError) as exc_info:
            bad_client.exchanges.list()

        assert exc_info.value.status_code == 401


# ===================================================================
# Exchanges — retrieve
# ===================================================================


class TestExchangesRetrieveIntegration:

    def test_retrieve_success(self, client):
        detail = client.exchanges.retrieve(EXCHANGE_NAME)

        assert isinstance(detail, ExchangeDetail)
        assert detail.name == EXCHANGE_NAME
        assert detail.display_name == "Fee - CBOE US Options"
        assert isinstance(detail.date_range, DateRange)
        assert detail.date_range.earliest  # non-empty string
        assert detail.date_range.latest
        assert "OPTION" in detail.fee_types
        assert len(detail.fee_categories) > 0
        assert len(detail.actions) > 0
        assert len(detail.participants) > 0
        assert len(detail.symbol_classifications) > 0
        assert len(detail.symbol_types) > 0
        assert len(detail.trade_types) > 0
        assert detail.record_count > 0

    def test_retrieve_not_found(self, client):
        with pytest.raises(NotFoundError) as exc_info:
            client.exchanges.retrieve("nonexistent_exchange")

        assert exc_info.value.status_code == 404

    def test_retrieve_unauthenticated(self, bad_client):
        with pytest.raises(AuthenticationError):
            bad_client.exchanges.retrieve(EXCHANGE_NAME)

    def test_retrieve_empty_name_raises_locally(self, client):
        with pytest.raises(ValueError, match="non-empty"):
            client.exchanges.retrieve("")


# ===================================================================
# Exchanges — with_raw_response
# ===================================================================


class TestExchangesRawResponseIntegration:

    def test_raw_response_list(self, client):
        raw = client.exchanges.with_raw_response.list()

        assert isinstance(raw, APIResponse)
        assert raw.status_code == 200
        assert "application/json" in raw.headers["content-type"]

        parsed = raw.parse()
        assert isinstance(parsed, list)
        assert len(parsed) >= 1
        assert isinstance(parsed[0], Exchange)

    def test_raw_response_retrieve(self, client):
        raw = client.exchanges.with_raw_response.retrieve(EXCHANGE_NAME)

        assert isinstance(raw, APIResponse)
        assert raw.status_code == 200

        detail = raw.parse()
        assert isinstance(detail, ExchangeDetail)
        assert detail.name == EXCHANGE_NAME


# ===================================================================
# Exchanges — async
# ===================================================================


class TestAsyncExchangesIntegration:

    @pytest.mark.asyncio
    async def test_async_list(self, async_client):
        result = await async_client.exchanges.list()

        assert isinstance(result, list)
        assert len(result) >= 1
        assert isinstance(result[0], Exchange)

    @pytest.mark.asyncio
    async def test_async_retrieve(self, async_client):
        detail = await async_client.exchanges.retrieve(EXCHANGE_NAME)

        assert isinstance(detail, ExchangeDetail)
        assert detail.name == EXCHANGE_NAME

    @pytest.mark.asyncio
    async def test_async_retrieve_not_found(self, async_client):
        with pytest.raises(NotFoundError):
            await async_client.exchanges.retrieve("nonexistent_exchange")


# ===================================================================
# Client — per-request overrides
# ===================================================================


class TestPerRequestOverridesIntegration:

    def test_extra_headers(self, client):
        # Extra headers should not break the request
        result = client.exchanges.list(extra_headers={"X-Custom-Test": "integration"})
        assert isinstance(result, list)

    def test_timeout_override(self, client):
        result = client.exchanges.list(timeout=120.0)
        assert isinstance(result, list)

    def test_with_options(self, client):
        client2 = client.with_options(timeout=120.0)
        result = client2.exchanges.list()
        assert isinstance(result, list)
        client2.close()

    def test_context_manager(self):
        with Rulebook(api_key=API_KEY, base_url=BASE_URL, timeout=60.0) as c:
            result = c.exchanges.list()
            assert isinstance(result, list)
