"""Rulebook Company SDK — Python client for the Rulebook API."""

from __future__ import annotations

from rulebook import types
from rulebook._client import AsyncRulebook, Rulebook
from rulebook._constants import DEFAULT_MAX_RETRIES, DEFAULT_TIMEOUT
from rulebook._exceptions import (
    APIConnectionError,
    APIError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    InternalServerError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    RulebookError,
    UnprocessableEntityError,
)
from rulebook._models import BaseModel
from rulebook._response import APIResponse
from rulebook._types import NOT_GIVEN, NotGiven

__all__ = [
    # Client classes
    "Rulebook",
    "AsyncRulebook",
    # Types namespace
    "types",
    # Base model
    "BaseModel",
    # Response wrapper
    "APIResponse",
    # Sentinel
    "NOT_GIVEN",
    "NotGiven",
    # Constants
    "DEFAULT_TIMEOUT",
    "DEFAULT_MAX_RETRIES",
    # Exceptions
    "RulebookError",
    "APIError",
    "APIConnectionError",
    "APITimeoutError",
    "APIStatusError",
    "BadRequestError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "UnprocessableEntityError",
    "RateLimitError",
    "InternalServerError",
]

# Fix __module__ for cleaner error messages:
#   rulebook._exceptions.NotFoundError → rulebook.NotFoundError
_locals = locals()
for _name in __all__:
    if not _name.startswith("__"):
        try:
            _locals[_name].__module__ = "rulebook"
        except (TypeError, AttributeError):
            pass
