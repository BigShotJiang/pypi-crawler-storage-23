"""Base resource classes that all API resources inherit from."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

import anyio

if TYPE_CHECKING:
    from rulebook._client import AsyncRulebook, Rulebook


class SyncAPIResource:
    """Base class for synchronous API resources.

    Resources bind HTTP methods from the client so they can
    call ``self._get(path, cast_to=Model, options=...)`` directly.
    """

    _client: Rulebook

    def __init__(self, client: Rulebook) -> None:
        self._client = client
        self._get = client.get

    def _sleep(self, seconds: float) -> None:
        time.sleep(seconds)


class AsyncAPIResource:
    """Base class for asynchronous API resources."""

    _client: AsyncRulebook

    def __init__(self, client: AsyncRulebook) -> None:
        self._client = client
        self._get = client.get

    async def _sleep(self, seconds: float) -> None:
        await anyio.sleep(seconds)
