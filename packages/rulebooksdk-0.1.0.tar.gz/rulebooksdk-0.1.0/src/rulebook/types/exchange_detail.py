"""Exchange detail model with full metadata and filter values."""

from __future__ import annotations

from typing import List

from rulebook._models import BaseModel
from rulebook.types.date_range import DateRange

__all__ = ["ExchangeDetail"]


class ExchangeDetail(BaseModel):
    name: str
    """Exchange identifier."""

    display_name: str
    """Human-readable exchange name."""

    date_range: DateRange
    """Earliest and latest dates with available data."""

    fee_types: List[str]
    """Available fee types (e.g., ``"Equity"``, ``"Option"``)."""

    fee_categories: List[str]
    """Available fee categories (e.g., ``"Fee And Rebates"``, ``"Legal Regulatory Fees"``)."""

    actions: List[str]
    """Available trading action types (e.g., ``"Make"``, ``"Take"``, ``"Open"``)."""

    participants: List[str]
    """Available participant types (e.g., ``"Market Maker"``, ``"Customer"``)."""

    symbol_classifications: List[str]
    """Available symbol classifications (e.g., ``"ETF"``, ``"Equity"``, ``"Index"``)."""

    symbol_types: List[str]
    """Available symbol types (e.g., ``"Penny"``, ``"Non Penny"``)."""

    trade_types: List[str]
    """Available trade types (e.g., ``"Simple Order"``, ``"Complex Order"``)."""

    record_count: int
    """Total fee schedule records for this exchange."""
