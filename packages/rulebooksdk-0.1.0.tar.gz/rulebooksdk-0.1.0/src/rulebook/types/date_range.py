"""Date range model for exchange data availability."""

from __future__ import annotations

from rulebook._models import BaseModel

__all__ = ["DateRange"]


class DateRange(BaseModel):
    earliest: str
    """Earliest scraped date (YYYY-MM-DD format)."""

    latest: str
    """Latest scraped date (YYYY-MM-DD format)."""
