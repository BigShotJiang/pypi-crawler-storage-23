"""SDK-wide constants."""

from __future__ import annotations

import httpx

DEFAULT_TIMEOUT = httpx.Timeout(timeout=30.0, connect=5.0)
DEFAULT_MAX_RETRIES = 2
DEFAULT_CONNECTION_LIMITS = httpx.Limits(max_connections=100, max_keepalive_connections=20)

INITIAL_RETRY_DELAY = 0.5
MAX_RETRY_DELAY = 8.0

BASE_URL = "https://api.rulebook.company/api/v1"
API_KEY_HEADER = "x-rulebook-api-access-key"
API_KEY_ENV_VAR = "RULEBOOK_API_KEY"
