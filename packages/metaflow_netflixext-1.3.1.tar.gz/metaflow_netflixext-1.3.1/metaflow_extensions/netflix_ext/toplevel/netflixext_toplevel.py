from .netflixext_version import netflixext_version

__mf_extensions__ = "netflix-ext"
__version__ = netflixext_version
