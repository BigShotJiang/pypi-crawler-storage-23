CMDS_DESC = [
    ("debug", ".debug.debug_cmd.cli"),
    ("environment", ".environment.environment_cmd.cli"),
]
