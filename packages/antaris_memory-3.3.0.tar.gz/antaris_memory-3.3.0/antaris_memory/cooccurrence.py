"""
Local co-occurrence collection for antaris-memory v3.2 — Tier 1 Semantic.

Builds a per-user word-pair frequency index from stored memories.
No data upload, zero API calls, zero dependencies.

Every time a memory is stored, word pairs within a 5-word window are
recorded. Over time this builds a personalized semantic clustering index:
  - User talks about "liver function" → index clusters "hepatic", "ALT", "enzymes"
  - Search for "liver" → results containing "hepatic" get a boost

The index is stored as a simple JSON file alongside memories.
Completely independent of BM25 — it's an additive re-ranking layer.

Usage:
    from antaris_memory.cooccurrence import CooccurrenceIndex

    idx = CooccurrenceIndex("./workspace")
    idx.load()
    idx.update_from_memory("Patient shows elevated ALT and hepatic inflammation.")
    similar = idx.similar_words("liver", top_k=10)
    # → ["hepatic", "ALT", "inflammation", "patient", ...]
    idx.save()
"""

import json
import math
import os
import re
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# Stopwords to exclude from co-occurrence pairs
_STOPWORDS = frozenset({
    'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
    'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
    'should', 'may', 'might', 'shall', 'can', 'to', 'of', 'in', 'for',
    'on', 'with', 'at', 'by', 'from', 'as', 'into', 'through', 'and',
    'or', 'but', 'if', 'that', 'this', 'it', 'its', 'he', 'she', 'they',
    'we', 'you', 'i', 'me', 'my', 'our', 'their', 'what', 'which', 'who',
    'not', 'no', 'so', 'then', 'just', 'now', 'up', 'out', 'very',
    'about', 'after', 'before', 'between', 'over', 'under', 'more',
})

# Window size for co-occurrence (words within N positions are considered co-occurring)
DEFAULT_WINDOW = 5
DEFAULT_TOP_K = 20


class CooccurrenceIndex:
    """Per-user word-pair frequency index for personalized semantic search.

    Tracks which words appear near each other across all stored memories.
    Used to boost search results that contain words semantically related
    to the query terms — even when there's no exact keyword match.

    Args:
        workspace: Path to the memory workspace directory.
        window: Co-occurrence window size in words (default 5).
        filename: Index filename within workspace (default .cooccurrence.json).
    """

    def __init__(
        self,
        workspace: str,
        window: int = DEFAULT_WINDOW,
        filename: str = ".cooccurrence.json",
    ):
        self.workspace = Path(workspace)
        self.window = window
        self._path = self.workspace / filename
        # word → {co_word: count}
        self._counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        # word → total occurrences (for PPMI normalization)
        self._word_counts: Dict[str, int] = defaultdict(int)
        self._total_pairs: int = 0
        self._dirty: bool = False
        # Cache for pair-marginals used in PPMI scoring (invalidated on updates)
        self._pair_marginals: Dict[str, int] = {}
        self._pair_marginals_valid: bool = False

    # ── Load / Save ───────────────────────────────────────────────────────────

    def load(self) -> None:
        """Load index from disk. No-op if index doesn't exist yet."""
        if not self._path.exists():
            return
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                data = json.load(f)
            raw_counts = data.get("counts", {})
            self._counts = defaultdict(lambda: defaultdict(int))
            for word, co_dict in raw_counts.items():
                self._counts[word] = defaultdict(int, co_dict)
            self._word_counts = defaultdict(int, data.get("word_counts", {}))
            self._total_pairs = data.get("total_pairs", 0)
        except (json.JSONDecodeError, KeyError):
            # Corrupted index — start fresh
            self._counts = defaultdict(lambda: defaultdict(int))
            self._word_counts = defaultdict(int)
            self._total_pairs = 0
        self._dirty = False

    def save(self) -> None:
        """Save index to disk. No-op if nothing changed."""
        if not self._dirty:
            return
        self.workspace.mkdir(parents=True, exist_ok=True)
        data = {
            "counts": {w: dict(co) for w, co in self._counts.items()},
            "word_counts": dict(self._word_counts),
            "total_pairs": self._total_pairs,
            "version": "3.2",
        }
        # Atomic write with fsync for durability
        tmp = self._path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, separators=(",", ":"))
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        tmp.replace(self._path)
        self._dirty = False

    # ── Indexing ──────────────────────────────────────────────────────────────

    def update_from_memory(self, content: str) -> int:
        """Extract word pairs from memory content and update the index.

        Processes a 5-word sliding window across the content, recording
        all non-stopword word pairs. Call this whenever a memory is stored.

        Args:
            content: Memory content string to index.

        Returns:
            Number of word pairs added.
        """
        tokens = self._tokenize(content)
        pairs_added = 0

        for i, word in enumerate(tokens):
            self._word_counts[word] += 1
            # Look ahead within window
            window_end = min(i + self.window + 1, len(tokens))
            for j in range(i + 1, window_end):
                co_word = tokens[j]
                if co_word != word:
                    self._counts[word][co_word] += 1
                    self._counts[co_word][word] += 1
                    self._total_pairs += 2
                    pairs_added += 2

        if pairs_added:
            self._dirty = True
            self._pair_marginals_valid = False
        return pairs_added

    def update_from_entries(self, entries: list) -> int:
        """Rebuild index from a list of MemoryEntry objects.

        Args:
            entries: List of MemoryEntry objects.

        Returns:
            Total word pairs indexed.
        """
        total = 0
        for entry in entries:
            content = getattr(entry, "content", "")
            if content:
                total += self.update_from_memory(content)
        return total

    def _get_pair_marginal(self, word: str) -> int:
        """Return the marginal (row sum) for a word in co-occurrence-pair space."""
        if not self._pair_marginals_valid:
            self._pair_marginals = {w: sum(co.values()) for w, co in self._counts.items()}
            self._pair_marginals_valid = True
        return self._pair_marginals.get(word, 0)

    # ── Query ─────────────────────────────────────────────────────────────────

    def similar_words(self, word: str, top_k: int = DEFAULT_TOP_K) -> List[Tuple[str, float]]:
        """Find words most similar to the given word by co-occurrence.

        Uses Positive PMI (PPMI) scoring: penalizes common word pairs,
        rewards rare but meaningful co-occurrences.

        Args:
            word: Query word to find similar words for.
            top_k: Maximum number of results to return.

        Returns:
            List of (word, ppmi_score) tuples, sorted by score descending.
        """
        word = word.lower()
        if word not in self._counts or self._total_pairs == 0:
            return []

        co_counts = self._counts[word]
        # Compute marginals in pair space (consistent denominator for PPMI)
        row_total = self._get_pair_marginal(word)
        if row_total <= 0:
            return []
        p_word = row_total / self._total_pairs

        scored = []
        for co_word, co_count in co_counts.items():
            col_total = self._get_pair_marginal(co_word)
            if col_total <= 0 or co_count <= 0:
                continue
            p_co = col_total / self._total_pairs
            p_joint = co_count / self._total_pairs

            if p_joint <= 0 or p_word <= 0 or p_co <= 0:
                continue

            # PMI = log(P(x,y) / (P(x) * P(y)))
            pmi = math.log2(p_joint / (p_word * p_co))
            # PPMI: clip negative values (reduces noise from rare pairs)
            ppmi = max(0.0, pmi)

            if ppmi > 0:
                scored.append((co_word, ppmi))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_k]

    def boost_score(
        self,
        query: str,
        entry_content: str,
        boost_factor: float = 0.3,
    ) -> float:
        """Compute a semantic boost score for an entry given a query.

        Checks whether any query terms co-occur strongly with terms in the
        entry content. Returns an additive boost (0.0 to boost_factor).

        Args:
            query: The search query string.
            entry_content: The memory entry content to check.
            boost_factor: Maximum boost to apply (default 0.3 = 30% extra).

        Returns:
            Float boost value in [0.0, boost_factor].
        """
        query_tokens = self._tokenize(query)
        entry_tokens = set(self._tokenize(entry_content))

        if not query_tokens or not entry_tokens:
            return 0.0

        total_boost = 0.0
        hits = 0
        cache = {}

        for q_token in query_tokens:
            if q_token not in cache:
                cache[q_token] = dict(self.similar_words(q_token, top_k=20))
            similar = cache[q_token]
            for e_token in entry_tokens:
                if e_token in similar:
                    # Scale similarity score to [0, 1] range (PPMI can be large)
                    raw_score = similar[e_token]
                    scaled = min(raw_score / 5.0, 1.0)  # Cap at PPMI=5
                    total_boost += scaled
                    hits += 1

        if hits == 0:
            return 0.0

        # Average boost, scaled to boost_factor
        avg = total_boost / hits
        return min(avg * boost_factor, boost_factor)

    # ── Stats ─────────────────────────────────────────────────────────────────

    @property
    def vocab_size(self) -> int:
        """Number of unique words in the index."""
        return len(self._counts)

    @property
    def total_pairs(self) -> int:
        """Total co-occurrence pairs recorded."""
        return self._total_pairs

    def stats(self) -> Dict:
        """Return index statistics."""
        return {
            "vocab_size": self.vocab_size,
            "total_pairs": self._total_pairs,
            "top_words": sorted(
                self._word_counts.items(), key=lambda x: x[1], reverse=True
            )[:10],
        }

    # ── Internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        """Extract meaningful tokens from text, excluding stopwords.

        Captures alphanumeric tokens (≥2 chars) so that domain-specific
        codes like "404", "gpt4", "100mg", and version strings are indexed.
        """
        tokens = re.findall(r'\b[a-zA-Z0-9]{2,}\b', text.lower())
        return [t for t in tokens if t not in _STOPWORDS]
