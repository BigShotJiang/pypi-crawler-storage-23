#!/usr/bin/python3
# -*- coding: utf-8 -*-
import os
import sys

def version():
  from importlib.metadata import version as get_version
  print(f"AnyAccess {get_version('anyaccess')}")
  print(f"Flask {get_version('flask')}")
  print(f"Waitress {get_version('waitress')}")
  print(f"Python: {sys.version.split()[0]}")

def prod():
  from waitress.runner import run
  anyaccess_app = os.environ.get('ANYACCESS_APP', 'main:serve_app')
  sys.argv.append("--call")
  sys.argv.append(anyaccess_app)
  sys.exit(run())
      
def dev():
  from flask.cli import main
  os.environ['FLASK_RUN_HOST'] = '0.0.0.0'
  anyaccess_app = os.environ.get('ANYACCESS_APP', 'main:serve_app')
  os.environ['FLASK_APP'] = anyaccess_app
  sys.exit(main())

def help():
  print(f"dev\t\trun as dev\n\t\texample: axs dev")
  print(f"prod\t\trun as prod\n\t\texample: axs prod")
  print(f"port\t\tChanges port.\n\t\tDefaults to port 80\n\t\texample: axs prod --port=8000")
  print(f"ANYACCESS_APP\tenvironment variable which changes which function to execute.\n\t\tDefaults to main:serve_app\n\t\texample: ANYACCESS_APP=main:serve_app axs prod")
  
def striparg():
  i = 0
  while i < len(sys.argv):
    arg = sys.argv[i]
    if arg == "--port":
      sys.argv.pop(i)
      if i < len(sys.argv):
        sys.argv.pop(i) 
      continue 
    elif arg.startswith("--port="):
      sys.argv.pop(i)
      continue  
    elif arg == "--call":
      sys.argv.pop(i)
      if i < len(sys.argv):
        sys.argv.pop(i) 
      continue 
    i += 1    

def axs():
  striparg()
  if "version" in sys.argv:
    version()
  if len(sys.argv) < 2 or "help" in sys.argv or "--help" in sys.argv:
    help()
    return True
  if sys.argv[1] == "dev":
    sys.argv[1] = "run"
    dev()
  if sys.argv[1] == "prod":
    sys.argv.pop(1)
    prod()
