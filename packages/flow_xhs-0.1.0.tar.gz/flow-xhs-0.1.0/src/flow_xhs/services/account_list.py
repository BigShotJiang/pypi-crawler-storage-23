from __future__ import annotations

from flow_xhs.platform import REDNOTE_PLATFORM
from flow_xhs.runtime.accounts.repository import FileAccountRepository


def execute_account_list(only_active: bool = True) -> list[dict]:
    repo = FileAccountRepository()
    return repo.list_accounts(platform=REDNOTE_PLATFORM, only_active=only_active)
