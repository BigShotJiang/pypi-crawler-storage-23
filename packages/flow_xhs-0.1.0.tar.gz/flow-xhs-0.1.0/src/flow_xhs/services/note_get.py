from __future__ import annotations

from flow_xhs.runtime import scraper_service


async def execute_note_get(
    note_id: str,
    xsec_token: str | None = None,
    xsec_source: str | None = "pc_feed",
    comment_size: int = 10,
    sub_comment_size: int = 5,
    account_uid: str | None = None,
) -> dict:
    return await scraper_service.get_note_info(
        note_id=note_id,
        xsec_token=xsec_token,
        xsec_source=xsec_source,
        comment_size=comment_size,
        sub_comment_size=sub_comment_size,
        account_uid=account_uid,
    )
