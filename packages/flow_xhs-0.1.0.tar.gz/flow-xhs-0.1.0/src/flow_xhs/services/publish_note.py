from __future__ import annotations

from flow_xhs.runtime import scraper_service


async def execute_publish_note(
    *,
    target: str,
    image_list: list[str],
    title: str = "",
    content: str = "",
    tags: list[str] | None = None,
    schedule_at: str | None = None,
    account_uid: str | None = None,
) -> dict:
    return await scraper_service.publish_note(
        target=target,
        image_list=image_list,
        title=title,
        content=content,
        tags=tags,
        schedule_at=schedule_at,
        account_uid=account_uid,
    )
