from __future__ import annotations

from flow_xhs.runtime import scraper_service


async def execute_note_search(
    keyword: str,
    size: int = 20,
    sort_by: str | None = None,
    note_type: str | None = None,
    publish_time: str | None = None,
    search_scope: str | None = None,
    location: str | None = None,
    account_uid: str | None = None,
) -> list[dict]:
    return await scraper_service.search_notes(
        keyword=keyword,
        size=size,
        sort_by=sort_by,
        note_type=note_type,
        publish_time=publish_time,
        search_scope=search_scope,
        location=location,
        account_uid=account_uid,
    )
