from __future__ import annotations

from flow_xhs.platform import REDNOTE_PLATFORM
from flow_xhs.runtime.accounts.repository import FileAccountRepository


def execute_account_activate(account_uid: str) -> dict:
    repo = FileAccountRepository()
    changed = repo.activate(platform=REDNOTE_PLATFORM, account_uid=account_uid)
    return {"changed": changed, "platform": REDNOTE_PLATFORM, "account_uid": account_uid, "active": True}


def execute_account_deactivate(account_uid: str) -> dict:
    repo = FileAccountRepository()
    changed = repo.deactivate(platform=REDNOTE_PLATFORM, account_uid=account_uid)
    return {"changed": changed, "platform": REDNOTE_PLATFORM, "account_uid": account_uid, "active": False}


def execute_account_delete(account_uid: str) -> dict:
    repo = FileAccountRepository()
    deleted = repo.delete(platform=REDNOTE_PLATFORM, account_uid=account_uid)
    return {"deleted": deleted, "platform": REDNOTE_PLATFORM, "account_uid": account_uid}
