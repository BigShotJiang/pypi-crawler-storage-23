from __future__ import annotations

from flow_xhs.runtime import scraper_service


async def execute_user_search(keyword: str, size: int = 20, account_uid: str | None = None) -> list[dict]:
    return await scraper_service.search_users(keyword=keyword, size=size, account_uid=account_uid)
