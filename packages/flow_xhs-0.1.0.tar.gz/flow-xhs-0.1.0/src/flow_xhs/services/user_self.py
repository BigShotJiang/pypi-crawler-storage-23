from __future__ import annotations

from flow_xhs.runtime import scraper_service


async def execute_user_self(account_uid: str | None = None) -> dict:
    return await scraper_service.get_self_info(account_uid=account_uid)
