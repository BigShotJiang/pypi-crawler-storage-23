from __future__ import annotations

from flow_xhs.runtime import scraper_service


async def execute_user_get(
    user_id: str,
    xsec_token: str | None = None,
    xsec_source: str | None = "pc_feed",
    account_uid: str | None = None,
) -> dict:
    return await scraper_service.get_user_info(
        user_id=user_id,
        xsec_token=xsec_token,
        xsec_source=xsec_source,
        account_uid=account_uid,
    )
