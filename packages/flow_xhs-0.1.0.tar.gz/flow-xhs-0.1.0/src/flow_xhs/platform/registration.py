from __future__ import annotations

from flow_xhs.runtime.enums import Platform
from flow_xhs.platform.auth_profile import REDNOTE_LOGIN_PROFILE
from flow_xhs.platform.factory import PlatformFactory
from flow_xhs.platform.extractor import RednoteExtractor


def register_flow_xhs_runtime() -> None:
    PlatformFactory.register_platform(
        Platform.REDNOTE,
        extractor_cls=RednoteExtractor,
        login_profile=REDNOTE_LOGIN_PROFILE,
    )
