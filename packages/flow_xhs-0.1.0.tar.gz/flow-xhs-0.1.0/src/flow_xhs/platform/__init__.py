"""Rednote platform internals."""

REDNOTE_PLATFORM = "Rednote"

__all__ = ["REDNOTE_PLATFORM"]
