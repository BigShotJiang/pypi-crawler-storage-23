from __future__ import annotations

from flow_xhs.platform.factory import PlatformLoginProfile


REDNOTE_LOGIN_PROFILE = PlatformLoginProfile(
    login_url="https://www.xiaohongshu.com/explore",
    login_selector=".main-container .user .link-wrapper .channel",
    qr_selector=".login-container .qrcode-img",
    account_id_field="red_id",
    nickname_field="nickname",
    guest_field="guest",
)
