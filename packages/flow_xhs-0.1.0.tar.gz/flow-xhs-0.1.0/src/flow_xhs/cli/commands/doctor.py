from __future__ import annotations

import typer

from flow_xhs.services.doctor import execute_doctor
from flow_xhs.cli.context import CliContext
from flow_xhs.cli.runtime import run_sync_command

app = typer.Typer(help="环境诊断与依赖自检", no_args_is_help=True)


@app.command("run")
def doctor_run(ctx: typer.Context):
    """
    执行自检并输出可机读诊断结果。

    推荐：`flow-xhs doctor run --format json`。
    """
    cli_ctx: CliContext = ctx.obj
    run_sync_command(ctx=cli_ctx, command="doctor.run", func=execute_doctor)
