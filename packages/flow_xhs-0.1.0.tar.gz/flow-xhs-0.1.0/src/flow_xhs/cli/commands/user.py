from __future__ import annotations

import typer

from flow_xhs.contracts.command_inputs import UserGetInput
from flow_xhs.services.user_get import execute_user_get
from flow_xhs.services.user_self import execute_user_self
from flow_xhs.cli.context import CliContext
from flow_xhs.cli.runtime import run_async_command
from flow_xhs.cli.utils import all_option_params_are_default, load_json_input, pick_cli_or_input
from flow_xhs.cli.xsec_help import USER_COMMAND_DOC, USER_INPUT_HELP, USER_XSEC_SOURCE_HELP
from flow_xhs.errors import InvalidArgsError

app = typer.Typer(help="用户主页详情查询", no_args_is_help=False)


@app.callback(invoke_without_command=True)
def user_get(
    ctx: typer.Context,
    user_id: str | None = typer.Option(None, "--user-id", help="用户 ID；可由 --input 提供"),
    xsec_token: str | None = typer.Option(None, "--xsec-token", help="xsec_token；默认优先携带，已拿到时不要省略"),
    xsec_source: str = typer.Option(
        "pc_feed",
        "--xsec-source",
        help=USER_XSEC_SOURCE_HELP,
    ),
    account: str | None = typer.Option(None, "--account", help="账号唯一标识（user_no）"),
    input_file: str | None = typer.Option(
        None,
        "--input",
        help=USER_INPUT_HELP,
    ),
):
    if ctx.invoked_subcommand:
        return
    if all_option_params_are_default(ctx=ctx):
        typer.echo(ctx.get_help())
        raise typer.Exit(code=0)

    cli_ctx: CliContext = ctx.obj
    payload = load_json_input(input_file)
    account_uid = pick_cli_or_input(
        ctx=ctx,
        param_name="account",
        cli_value=account,
        payload=payload,
        payload_key="account_uid",
    )

    async def _run():
        validated = UserGetInput(
            user_id=pick_cli_or_input(
                ctx=ctx,
                param_name="user_id",
                cli_value=user_id,
                payload=payload,
                payload_key="user_id",
            ),
            xsec_token=pick_cli_or_input(
                ctx=ctx,
                param_name="xsec_token",
                cli_value=xsec_token,
                payload=payload,
                payload_key="xsec_token",
            ),
            xsec_source=pick_cli_or_input(
                ctx=ctx,
                param_name="xsec_source",
                cli_value=xsec_source,
                payload=payload,
                payload_key="xsec_source",
            ),
            account_uid=account_uid,
        )
        return await execute_user_get(
            user_id=validated.user_id,
            xsec_token=validated.xsec_token,
            xsec_source=validated.xsec_source,
            account_uid=validated.account_uid,
        )

    run_async_command(
        ctx=cli_ctx,
        command="user.get",
        func=_run,
        account_uid=account_uid,
    )


user_get.__doc__ = USER_COMMAND_DOC


@app.command("self")
def user_self(
    ctx: typer.Context,
    account: str | None = typer.Option(None, "--account", help="账号唯一标识（user_no）"),
):
    """查询当前登录账号自己的用户信息。"""
    if all_option_params_are_default(ctx=ctx):
        typer.echo(ctx.get_help())
        raise typer.Exit(code=0)

    cli_ctx: CliContext = ctx.obj
    account_uid = (account or "").strip()

    async def _run():
        if not account_uid:
            raise InvalidArgsError("`--account` 为必填参数")
        return await execute_user_self(account_uid=account_uid)

    run_async_command(
        ctx=cli_ctx,
        command="user.self",
        func=_run,
        account_uid=account_uid,
    )
