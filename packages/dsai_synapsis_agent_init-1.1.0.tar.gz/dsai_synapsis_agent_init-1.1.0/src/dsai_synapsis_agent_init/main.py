"""
Main initialization module for Synapsis DSAI Agent Rules.

This module provides the core functionality for initializing agent rules by
copying template directories (.agent, .agents, .claude, .cursor, .github) from the package
into the user's current working directory.

Functions:
    run(): Main entry point for the initialization CLI tool.
"""

import shutil
import sys
import argparse
import re
from pathlib import Path
from importlib.resources import files

# Marker to identify files managed by this tool at the user side
MANAGED_MARKER = "<!-- synapsis-dsai-managed -->"

# Full mapping of tools to their respective folders and files
TOOL_MAPPING = {
    "1": {"name": "Gemini CLI", "folders": [".agent"], "files": ["GEMINI.md"]},
    "2": {"name": "Claude Code", "folders": [".claude"], "files": ["CLAUDE.md"]},
    "3": {"name": "Cursor AI", "folders": [".cursor"], "files": [".cursorrules"]},
    "4": {"name": "GitHub Copilot", "folders": [".github"], "files": ["AGENTS.md"]},
    "5": {"name": "Google Antigravity", "folders": [".agents"], "files": []}
}

START_MARKER = "<!-- synapsis-dsai-core-start -->"
END_MARKER = "<!-- synapsis-dsai-core-end -->"

# Extensions that should be treated as text and receive markers
TEXT_EXTENSIONS = {'.md', '.mdc', '.txt', '.json', '.yaml', '.yml', '.py', '.sh', '.ps1'}


def _get_template_path() -> Path:
    """
    Retrieve the path to the package's templates directory.
    """
    return files("dsai_synapsis_agent_init") / "templates"


def _update_standalone_file(target_path: Path, template_block: str) -> None:
    """
    Safely injects or updates the Synapsis Core Block in a standalone file.
    """
    file_name = target_path.name
    
    if not target_path.exists():
        try:
            target_path.write_text(template_block, encoding="utf-8")
            print(f"✅ Berhasil membuat {file_name}")
            return
        except Exception as e:
            print(f"❌ Gagal membuat {file_name}: {e}")
            return

    content = target_path.read_text(encoding="utf-8")
    
    start_idx = content.find(START_MARKER)
    end_idx = content.find(END_MARKER)

    if start_idx != -1 and end_idx != -1:
        if start_idx > end_idx:
            print(f"⚠️  Marker di {file_name} rusak (Start setelah End). Melewati auto-update.")
            return
            
        new_content = content[:start_idx] + template_block.strip() + content[end_idx + len(END_MARKER):]
        if content != new_content:
            target_path.write_text(new_content, encoding="utf-8")
            print(f"🔄 Berhasil memperbarui blok standar di {file_name}")
        else:
            print(f"✨ Blok standar di {file_name} sudah versi terbaru.")
    elif start_idx == -1 and end_idx == -1:
        new_content = content.rstrip() + "\n\n" + template_block.strip() + "\n"
        target_path.write_text(new_content, encoding="utf-8")
        print(f"➕ Berhasil menambahkan blok standar ke {file_name}")
    else:
        print(f"⚠️  Tag pembatas di {file_name} tidak lengkap. Melewati auto-update untuk keamanan.")


def _inject_managed_marker(content: str, file_name: str) -> str:
    """
    Injects the managed marker into the content based on file type.
    """
    if MANAGED_MARKER in content:
        return content

    # For SKILL.md with frontmatter, insert after the second ---
    if file_name == "SKILL.md" and content.strip().startswith("---"):
        match = re.search(r'^(---\s*.*?\s*---[\s\r\n]*)', content, re.DOTALL)
        if match:
            sep_end = match.end()
            return content[:sep_end] + MANAGED_MARKER + "\n" + content[sep_end:].lstrip()
    
    # Default for rules/workflows/others: Append to BOTTOM
    return f"{content.rstrip()}\n\n{MANAGED_MARKER}\n"


def _sync_file(source: Path, destination: Path, verbose: bool = False) -> None:
    """
    Syncs a single file from source to destination using dynamic ownership rules.
    """
    rel_path = destination.name
    try:
        source_raw_content = source.read_text(encoding="utf-8")
    except Exception:
        try:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(source), str(destination))
            if verbose: print(f"✨ Synced asset: {rel_path}")
            return
        except Exception as e:
            print(f"❌ Gagal menyalin asset {rel_path}: {e}")
            return
    
    target_content = _inject_managed_marker(source_raw_content, rel_path)

    if not destination.exists():
        try:
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(target_content, encoding="utf-8")
            if verbose: print(f"🆕 Created: {rel_path}")
            return
        except Exception as e:
            print(f"❌ Gagal membuat {rel_path}: {e}")
            return

    try:
        dest_current_content = destination.read_text(encoding="utf-8")
        if MANAGED_MARKER in dest_current_content:
            if dest_current_content.strip() != target_content.strip():
                destination.write_text(target_content, encoding="utf-8")
                if verbose: print(f"🔄 Updating managed file: {rel_path}")
            elif verbose:
                print(f"✨ Already up-to-date: {rel_path}")
        else:
            if verbose: print(f"⏭️  Skipping customized file: {rel_path}")
    except Exception as e:
        print(f"❌ Error syncing {rel_path}: {e}")


def _sync_template_folder(source: Path, destination: Path, folder_name: str, verbose: bool = False) -> None:
    """
    Recursively syncs a template folder using the ownership marker system.
    """
    source_path = Path(str(source))
    if not source_path.exists():
        print(f"⚠️  Template {folder_name} tidak ditemukan di dalam package.")
        return

    destination.mkdir(parents=True, exist_ok=True)
    for src_file in source_path.rglob('*'):
        if src_file.is_file():
            rel_path = src_file.relative_to(source_path)
            dest_file = destination / rel_path
            _sync_file(src_file, dest_file, verbose)

    print(f"✅ Berhasil memproses {folder_name}")


def run() -> None:
    """
    Initialize Synapsis DSAI Agent Rules in the current working directory.
    """
    parser = argparse.ArgumentParser(description="Initialize Synapsis DSAI Agent Rules.")
    parser.add_argument("--verbose", action="store_true", help="Show detailed sync information.")
    parser.add_argument("--all", action="store_true", help="Initialize all AI agent tools without asking.")
    parser.add_argument("-y", "--yes", action="store_true", help="Skip confirmation.")
    args = parser.parse_args()

    print("🚀 [Synapsis DSAI] Initializing agent rules...")

    # Step 1: Selection logic
    selected_folders = set()
    selected_files = set()

    if args.all or args.yes:
        for tool in TOOL_MAPPING.values():
            selected_folders.update(tool["folders"])
            selected_files.update(tool["files"])
    else:
        print("\nAI agent apa saja yang Anda gunakan? (Pisahkan dengan koma, misal: 1,3)")
        for key, tool in TOOL_MAPPING.items():
            print(f" {key}. {tool['name']}")
        
        try:
            choice = input("\nPilihan Anda (kosongkan untuk semua): ").strip()
            if not choice:
                for tool in TOOL_MAPPING.values():
                    selected_folders.update(tool["folders"])
                    selected_files.update(tool["files"])
            else:
                choices = [c.strip() for c in choice.split(",")]
                for c in choices:
                    if c in TOOL_MAPPING:
                        selected_folders.update(TOOL_MAPPING[c]["folders"])
                        selected_files.update(TOOL_MAPPING[c]["files"])
                    else:
                        print(f"⚠️  Pilihan '{c}' tidak valid, dilewati.")
        except EOFError:
            for tool in TOOL_MAPPING.values():
                selected_folders.update(tool["folders"])
                selected_files.update(tool["files"])

    if not selected_folders and not selected_files:
        print("❌ Tidak ada tool yang dipilih. Membatalkan.")
        return

    # Step 2: Get template path
    try:
        template_base = _get_template_path()
    except Exception as e:
        print(f"❌ Error internal: {e}")
        sys.exit(1)
        return
        
    current_work_dir = Path.cwd()

    if not (current_work_dir / ".git").exists():
        print("⚠️  Direktori .git tidak ditemukan. Pastikan Anda menjalankan ini di root repository.")

    # Step 3: Sync selected folders
    for folder_name in selected_folders:
        source = template_base / folder_name
        destination = current_work_dir / folder_name
        _sync_template_folder(source, destination, folder_name, args.verbose)

    # Step 4: Handle Selected Standalone Files
    try:
        core_block_path = template_base / "standalone" / "core-rules-block.md"
        if core_block_path.exists():
            template_block = core_block_path.read_text(encoding="utf-8")
            for file_name in selected_files:
                target_path = current_work_dir / file_name
                _update_standalone_file(target_path, template_block)
        else:
            print("⚠️  Template standalone tidak ditemukan. Melewati pembaruan file tunggal.")
    except Exception as e:
        print(f"❌ Gagal memproses file standalone: {e}")

    print("\n✨ Berhasil! Konfigurasi untuk tool terpilih telah disiapkan.")


if __name__ == "__main__":
    run()
