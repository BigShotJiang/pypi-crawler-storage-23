"""Schema validators for proof payloads."""

import logging
from typing import Any

logger = logging.getLogger(__name__)


def validate_client_proof_schema(proof_obj: dict[str, Any]) -> bool:
    required_fields: dict[str, Any] = {
        "type": str,
        "version": int,
        "updated_hash": str,
        "delta_hash": str,
        "delta_norm_l2": (float, int),
        "rigor_level": str,
        "pysnark": dict,
    }

    for field, expected_type in required_fields.items():
        if field not in proof_obj:
            logger.warning("Client proof missing required field: %s", field)
            return False
        if not isinstance(proof_obj[field], expected_type):
            logger.warning(
                "Client proof field '%s' has invalid type: got=%s expected=%s",
                field,
                type(proof_obj[field]).__name__,
                expected_type,
            )
            return False

    if proof_obj.get("type") != "client_training_proof":
        logger.warning("Client proof has invalid type: %s", proof_obj.get("type"))
        return False

    if int(proof_obj.get("version", 0)) != 1:
        logger.warning("Unsupported client proof version: %s", proof_obj.get("version"))
        return False

    return True


def validate_server_proof_schema(
    proof_data: dict[str, Any], expected_type: str, expected_version: int
) -> bool:
    if not isinstance(proof_data, dict):
        logger.warning("Invalid server proof payload type")
        return False

    has_type = "type" in proof_data and "version" in proof_data
    if has_type:
        if proof_data.get("type") != expected_type:
            logger.warning("Unexpected server proof type: %s", proof_data.get("type"))
            return False
        if int(proof_data.get("version", 0)) != expected_version:
            logger.warning(
                "Unsupported server proof version: %s", proof_data.get("version")
            )
            return False

    if "proof" not in proof_data or not isinstance(proof_data["proof"], dict):
        logger.warning("Server proof missing 'proof' object")
        return False
    if "public" not in proof_data or not isinstance(proof_data["public"], list):
        logger.warning("Server proof missing 'public' list")
        return False

    return True
