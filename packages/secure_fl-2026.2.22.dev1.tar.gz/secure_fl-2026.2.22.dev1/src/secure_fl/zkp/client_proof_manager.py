"""Client-side proof manager implementation."""

import json
import logging
from pathlib import Path
from typing import Any

import numpy as np
from flwr.common import NDArrays

from secure_fl.utils.helpers import compute_hash
from secure_fl.utils.helpers import compute_parameter_norm

from .base import ProofManagerBase

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ClientProofManager(ProofManagerBase):
    def __init__(
        self,
        max_update_norm: float | None = None,
        use_pysnark: bool = True,
        fixed_point_scale: int = 1000000,
    ):
        super().__init__()
        self.max_update_norm = max_update_norm
        self.use_pysnark = use_pysnark
        self.fixed_point_scale = fixed_point_scale

        logger.info(
            "ClientProofManager initialized (max_update_norm=%s, use_pysnark=%s, "
            "scale=%s)",
            self.max_update_norm,
            self.use_pysnark,
            self.fixed_point_scale,
        )

    def _flatten_params(self, params: NDArrays) -> list[float]:
        """Flatten list of parameter arrays into a single list of floats."""
        flat: list[float] = []
        for arr in params:
            flat.extend(arr.astype(float).ravel().tolist())
        return flat

    def _to_fixed_point_list(self, values: list[float]) -> list[int]:
        """Convert float list to fixed-point integers using configured scale."""
        s = self.fixed_point_scale
        return [int(round(v * s)) for v in values]

    def _get_effective_bound(self, delta_norm_l2: float) -> float:
        if self.max_update_norm is not None:
            return float(self.max_update_norm)
        return min(1000.0, max(1e-6, 2.0 * float(delta_norm_l2)))

    def _generate_pysnark_delta_bound_proof(
        self,
        initial_params: NDArrays,
        updated_params: NDArrays,
        delta_norm_l2: float,
        rigor_level: str = "medium",
    ) -> dict[str, Any] | None:
        if not self.use_pysnark:
            return None
        try:
            from pysnark.runtime import PrivVal
            from pysnark.runtime import PubVal
        except ImportError as e:
            logger.warning(f"PySNARK runtime not available: {e}")
            return None
        try:
            import pysnark.runtime

            from secure_fl.proofs.client_circuits.delta_bound import delta_bound_proof

            pysnark.runtime.bitlength = 128
        except Exception as e_first:
            try:
                import sys

                package_root = Path(__file__).resolve().parents[2]
                if str(package_root) not in sys.path:
                    sys.path.insert(0, str(package_root))

                import pysnark.runtime

                from secure_fl.proofs.client_circuits.delta_bound import (
                    delta_bound_proof,
                )

                pysnark.runtime.bitlength = 128
            except Exception as e_second:
                logger.warning(
                    "PySNARK / delta_bound_proof NOT available, skipping zk proof\n"
                    f"First import error:  {e_first}\n"
                    f"Second import error: {e_second}"
                )
                return None

        try:
            flat_init = self._flatten_params(initial_params)
            flat_upd = self._flatten_params(updated_params)

            if len(flat_init) != len(flat_upd):
                logger.warning(
                    "PySNARK: length mismatch initial (%s) vs updated (%s)",
                    len(flat_init),
                    len(flat_upd),
                )
                return None

            init_fp_orig = self._to_fixed_point_list(flat_init)
            upd_fp_orig = self._to_fixed_point_list(flat_upd)

            if rigor_level == "low":
                sample_size = min(200, len(init_fp_orig))
            elif rigor_level == "medium":
                sample_size = min(2000, len(init_fp_orig))
            else:
                sample_size = len(init_fp_orig)

            if sample_size < len(init_fp_orig):
                indices = np.linspace(
                    0, len(init_fp_orig) - 1, sample_size, dtype=int
                ).tolist()
                init_fp = [init_fp_orig[i] for i in indices]
                upd_fp = [upd_fp_orig[i] for i in indices]
                logger.info(
                    "PySNARK: sampled %s/%s parameters for %s rigor",
                    sample_size,
                    len(init_fp_orig),
                    rigor_level,
                )
            else:
                init_fp = init_fp_orig
                upd_fp = upd_fp_orig

            deltas_fp = [u - i for i, u in zip(init_fp, upd_fp, strict=False)]
            l2_sq_fp = sum(d * d for d in deltas_fp)
            sampled_l2_fp = int(np.sqrt(float(l2_sq_fp))) if l2_sq_fp > 0 else 0
            bound_int = max(1, int(sampled_l2_fp * 1.1) + 1)
            bound_float = bound_int / float(self.fixed_point_scale)

            initial_circuit = [PrivVal(x) for x in init_fp]
            updated_circuit = [PrivVal(x) for x in upd_fp]
            bound_circuit = PubVal(bound_int)

            logger.info(
                "Running PySNARK circuit: vector_len=%s, bound_int=%s, bound_float=%s",
                len(init_fp),
                bound_int,
                bound_float,
            )

            l2_sq_result = delta_bound_proof(
                initial_circuit, updated_circuit, bound_circuit
            )

            logger.info("PySNARK circuit executed successfully")

            return {
                "enabled": True,
                "vector_len": len(init_fp),
                "scale": self.fixed_point_scale,
                "bound_float": bound_float,
                "bound_int": bound_int,
                "l2_sq_result": str(int(l2_sq_result)),
            }
        except AssertionError as e:
            logger.error(f"PySNARK constraint failed (bound violation): {e}")
            return {
                "enabled": True,
                "error": "bound_violation",
                "message": str(e),
            }
        except Exception as e:
            logger.error(f"PySNARK delta-bound proof generation failed: {e}")
            import traceback

            logger.error(traceback.format_exc())
            return None

    def setup(self) -> bool:
        self.setup_complete = True
        return True

    def generate_training_proof(self, proof_inputs: dict[str, Any]) -> str | None:
        return self.generate_proof(proof_inputs)

    def generate_proof(self, inputs: dict[str, Any]) -> str | None:
        try:
            initial_params = inputs["initial_params"]
            updated_params = inputs["updated_params"]
            param_delta = inputs["param_delta"]

            initial_hash = compute_hash(initial_params)
            updated_hash = compute_hash(updated_params)
            delta_hash = compute_hash(param_delta)

            delta_norm_l2 = compute_parameter_norm(param_delta, norm_type="l2")
            max_norm = self.max_update_norm

            pysnark_info = self._generate_pysnark_delta_bound_proof(
                initial_params=initial_params,
                updated_params=updated_params,
                delta_norm_l2=delta_norm_l2,
                rigor_level=inputs.get("rigor_level", "medium"),
            )

            proof_obj = {
                "type": "client_training_proof",
                "version": 1,
                "client_id": inputs.get("client_id"),
                "round": int(inputs.get("round", 0)),
                "data_commitment": inputs.get("data_commitment"),
                "initial_hash": initial_hash,
                "updated_hash": updated_hash,
                "delta_hash": delta_hash,
                "delta_norm_l2": delta_norm_l2,
                "max_delta_norm_l2": max_norm,
                "learning_rate": float(inputs.get("learning_rate", 0.0)),
                "local_epochs": int(inputs.get("local_epochs", 0)),
                "rigor_level": inputs.get("rigor_level", "medium"),
                "total_samples": int(inputs.get("total_samples", 0)),
                "batch_losses": inputs.get("batch_losses", []),
                "gradient_norms": inputs.get("gradient_norms", []),
                "pysnark": pysnark_info or {"enabled": False},
            }

            proof_key = self._hash_inputs(proof_obj)
            self.proof_cache[proof_key] = proof_obj

            return json.dumps(proof_obj)

        except Exception as e:
            logger.error(f"Client proof generation failed: {e}")
            return None

    def verify_proof(self, proof: str, public_inputs: dict[str, Any]) -> bool:
        logger.warning("ClientProofManager.verify_proof called unexpectedly")
        return False
