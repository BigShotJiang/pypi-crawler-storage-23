"""
Zero-Knowledge Proof module for Secure FL.

This module contains the ZKP components including proof managers for both
client-side zk-STARKs and server-side zk-SNARKs, as well as parameter
quantization for ZKP circuit compatibility.
"""

from .client_proof_manager import ClientProofManager
from .quantization import FixedPointQuantizer
from .quantization import GradientAwareQuantizer
from .quantization import QuantizationConfig
from .quantization import QuantizationScheme
from .quantization import ScaleMethod
from .quantization import compute_quantization_error
from .quantization import dequantize_parameters
from .quantization import get_circuit_friendly_config
from .quantization import get_high_precision_config
from .quantization import get_int8_config
from .quantization import quantize_parameters
from .server_proof_manager import ServerProofManager

__all__ = [
    # Proof managers
    "ClientProofManager",
    "ServerProofManager",
    # Quantization
    "FixedPointQuantizer",
    "GradientAwareQuantizer",
    "QuantizationConfig",
    "ScaleMethod",
    "QuantizationScheme",
    "quantize_parameters",
    "dequantize_parameters",
    "compute_quantization_error",
    "get_int8_config",
    "get_circuit_friendly_config",
    "get_high_precision_config",
]
