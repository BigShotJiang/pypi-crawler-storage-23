"""Shared abstractions for proof managers."""

import hashlib
import json
from abc import ABC
from abc import abstractmethod
from typing import Any


class ProofManagerBase(ABC):
    """Base class for proof managers."""

    def __init__(self) -> None:
        self.circuit_cache: dict[str, Any] = {}
        self.proof_cache: dict[str, Any] = {}
        self.setup_complete = False

    @abstractmethod
    def setup(self) -> bool:
        """Setup circuits and proving keys."""

    @abstractmethod
    def generate_proof(self, inputs: dict[str, Any]) -> str | None:
        """Generate a proof for given inputs."""

    @abstractmethod
    def verify_proof(self, proof: str, public_inputs: dict[str, Any]) -> bool:
        """Verify a proof."""

    def _hash_inputs(self, inputs: dict[str, Any]) -> str:
        """Create hash of inputs for caching."""
        input_str = json.dumps(inputs, sort_keys=True, default=str)
        return hashlib.sha256(input_str.encode()).hexdigest()
