"""Server-side proof manager implementation."""

import json
import logging
import os
import subprocess
from pathlib import Path
from typing import Any

import numpy as np
from flwr.common import NDArrays
from flwr.common import Parameters

from secure_fl.utils.helpers import compute_hash
from secure_fl.utils.helpers import compute_parameter_norm
from secure_fl.utils.helpers import parameters_to_ndarrays

from .base import ProofManagerBase
from .proof_schema import validate_client_proof_schema
from .proof_schema import validate_server_proof_schema
from .server_setup import build_setup_manifest
from .server_setup import clean_build_artifacts
from .server_setup import has_required_setup_artifacts
from .server_setup import manifest_matches_runtime
from .server_setup import read_circuit_dimensions
from .server_setup import write_setup_manifest
from .server_snark_io import generate_snark_proof
from .server_snark_io import verify_snark_proof

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ServerProofManager(ProofManagerBase):
    """Server-side proof manager using zk-SNARKs (Groth16)."""

    FIXED_POINT_SCALE = 10**6
    SERVER_PROOF_TYPE = "server_aggregation_proof"
    SERVER_PROOF_VERSION = 1

    def __init__(
        self,
        circom_path: str = "circom",
        snarkjs_path: str = "snarkjs",
        max_clients: int = 8,
        param_size: int = 50,
    ):
        super().__init__()
        if max_clients <= 0:
            raise ValueError("max_clients must be positive")
        if param_size <= 0:
            raise ValueError("param_size must be positive")

        self.circom_path = circom_path
        self.snarkjs_path = snarkjs_path
        self.max_clients = max_clients
        self.param_size = param_size
        self.circuit_dir = os.path.join(
            os.path.dirname(__file__), "..", "proofs", "server"
        )
        self.proving_key: str | None = None
        self.verification_key: str | None = None

        logger.info("ServerProofManager initialized")

    def setup(self) -> bool:
        """Load compatible setup artifacts or build them if missing."""
        try:
            result = subprocess.run(
                [self.circom_path, "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                logger.error("Circom not found. Please install Circom.")
                return False

            if self.load_setup():
                self.setup_complete = True
                logger.info("Server proof setup loaded from existing artifacts")
                return True

            success = self._setup_snark_circuit()
            if success:
                self.setup_complete = True
                logger.info("Server proof setup completed")
            else:
                logger.error("Failed to setup server circuits")

            return success

        except Exception as e:
            logger.error(f"Server proof setup failed: {e}")
            return False

    def load_setup(self) -> bool:
        """Load an existing compatible setup from manifest and artifacts."""
        try:
            circuit_dir = Path(self.circuit_dir)
            build_dir = circuit_dir / "build"
            manifest_path = build_dir / "setup_manifest.json"

            if not manifest_path.exists():
                return False
            if not has_required_setup_artifacts(build_dir):
                return False

            with open(manifest_path, encoding="utf-8") as f:
                manifest = json.load(f)

            if not manifest_matches_runtime(
                manifest=manifest,
                circuit_dir=circuit_dir,
                proof_type=self.SERVER_PROOF_TYPE,
                proof_version=self.SERVER_PROOF_VERSION,
                max_clients=self.max_clients,
                param_size=self.param_size,
                circom_path=self.circom_path,
                snarkjs_path=self.snarkjs_path,
            ):
                return False

            self.proving_key = str(build_dir / "aggregation.zkey")
            self.verification_key = str(build_dir / "verification_key.json")
            return True

        except Exception as e:
            logger.warning(f"Failed to load proof setup from manifest: {e}")
            return False

    def generate_server_proof(
        self,
        client_updates: list[NDArrays],
        client_weights: list[float],
        aggregated_params: NDArrays,
        old_params: NDArrays,
        momentum: NDArrays,
        momentum_coeff: float,
    ) -> str | None:
        return self.generate_proof(
            {
                "client_updates": client_updates,
                "client_weights": client_weights,
                "aggregated_params": aggregated_params,
                "old_params": old_params,
                "momentum": momentum,
                "momentum_coeff": momentum_coeff,
            }
        )

    def generate_proof(self, inputs: dict[str, Any]) -> str | None:
        if not self.setup_complete and not self.setup():
            return None

        try:
            circuit_inputs = self._prepare_snark_inputs(inputs)
            if not self.proving_key:
                logger.error("Missing proving key for SNARK proof generation")
                return None
            return generate_snark_proof(
                circuit_dir=Path(self.circuit_dir),
                snarkjs_path=self.snarkjs_path,
                proving_key=self.proving_key,
                inputs=circuit_inputs,
                proof_type=self.SERVER_PROOF_TYPE,
                proof_version=self.SERVER_PROOF_VERSION,
            )
        except Exception as e:
            logger.error(f"Server proof generation failed: {e}")
            return None

    def verify_proof(self, proof: str, public_inputs: dict[str, Any]) -> bool:
        if not self.setup_complete:
            return False

        try:
            proof_data = json.loads(proof)
            formatted_inputs = self._format_public_inputs(public_inputs)
            return self._verify_snark_proof(proof_data, formatted_inputs)
        except Exception as e:
            logger.error(f"Server proof verification failed: {e}")
            return False

    def _setup_snark_circuit(self) -> bool:
        try:
            circuit_dir = Path(self.circuit_dir)
            build_dir = circuit_dir / "build"
            build_dir.mkdir(parents=True, exist_ok=True)

            circom_file = circuit_dir / "aggregation.circom"
            if not circom_file.exists():
                logger.error(f"Circuit file not found: {circom_file}")
                return False

            circuit_clients, circuit_param_size = read_circuit_dimensions(circom_file)
            if (
                circuit_clients != self.max_clients
                or circuit_param_size != self.param_size
            ):
                raise ValueError(
                    "Circuit configuration mismatch: "
                    f"expected ({self.max_clients}, {self.param_size}), "
                    f"got ({circuit_clients}, {circuit_param_size})"
                )

            r1cs = build_dir / "aggregation.r1cs"
            zkey = build_dir / "aggregation.zkey"
            vkey = build_dir / "verification_key.json"

            if self.load_setup():
                self.proving_key = str(zkey)
                self.verification_key = str(vkey)
                logger.info("Reusing existing SNARK setup artifacts")
                return True

            clean_build_artifacts(circuit_dir, build_dir)

            subprocess.check_call(
                [
                    self.circom_path,
                    str(circom_file),
                    "--r1cs",
                    "--wasm",
                    "--sym",
                    "-o",
                    str(build_dir),
                ]
            )

            ptau = circuit_dir / "pot12_final.ptau"
            if not ptau.exists():
                logger.error(
                    "Missing ptau file. Run: snarkjs powersoftau new & contribute"
                )
                return False

            subprocess.check_call(
                [
                    self.snarkjs_path,
                    "groth16",
                    "setup",
                    str(r1cs),
                    str(ptau),
                    str(zkey),
                ]
            )
            subprocess.check_call(
                [
                    self.snarkjs_path,
                    "zkey",
                    "export",
                    "verificationkey",
                    str(zkey),
                    str(vkey),
                ]
            )

            self.proving_key = str(zkey)
            self.verification_key = str(vkey)

            write_setup_manifest(
                build_dir,
                build_setup_manifest(
                    circuit_dir=circuit_dir,
                    proof_type=self.SERVER_PROOF_TYPE,
                    proof_version=self.SERVER_PROOF_VERSION,
                    max_clients=self.max_clients,
                    param_size=self.param_size,
                    circom_path=self.circom_path,
                    snarkjs_path=self.snarkjs_path,
                ),
            )

            logger.info("✓ SNARK circuit compiled and setup complete")
            return True
        except Exception as e:
            logger.error(f"Failed SNARK setup: {e}")
            return False

    def verify_client_proof(
        self,
        proof: str,
        updated_parameters: Parameters | NDArrays,
        old_global_params: NDArrays,
    ) -> bool:
        try:
            proof_obj = json.loads(proof) if isinstance(proof, str) else proof
            if not validate_client_proof_schema(proof_obj):
                return False

            new_params = (
                updated_parameters
                if isinstance(updated_parameters, list)
                else parameters_to_ndarrays(updated_parameters)
            )

            if compute_hash(new_params) != proof_obj.get("updated_hash"):
                logger.warning("Updated hash mismatch in client proof")
                return False

            if len(old_global_params) != len(new_params):
                logger.warning("Parameter length mismatch for client proof")
                return False

            delta = []
            for old_layer, new_layer in zip(
                old_global_params, new_params, strict=False
            ):
                if old_layer.shape != new_layer.shape:
                    logger.warning("Parameter shape mismatch for client proof")
                    return False
                delta.append(new_layer - old_layer)

            if compute_hash(delta) != proof_obj.get("delta_hash"):
                logger.warning("Delta hash mismatch in client proof")
                return False

            recomputed_delta_norm = compute_parameter_norm(delta, norm_type="l2")
            claimed_delta_norm = float(proof_obj.get("delta_norm_l2", -1.0))
            if claimed_delta_norm < 0:
                logger.warning("Client proof missing delta_norm_l2")
                return False
            if abs(claimed_delta_norm - recomputed_delta_norm) > 1e-4:
                logger.warning(
                    "Delta norm mismatch: claimed=%s, recomputed=%s",
                    claimed_delta_norm,
                    recomputed_delta_norm,
                )
                return False

            max_norm = proof_obj.get("max_delta_norm_l2", None)
            if max_norm is not None and recomputed_delta_norm > float(max_norm):
                logger.warning(
                    "Client delta norm %.6f exceeds bound %.6f",
                    recomputed_delta_norm,
                    float(max_norm),
                )
                return False

            pysnark_info = proof_obj.get("pysnark", {})
            if pysnark_info.get("enabled") and "error" in pysnark_info:
                logger.warning(
                    "Rejecting client proof due to ZKP error: %s",
                    pysnark_info["error"],
                )
                return False

            return True
        except Exception as e:
            logger.error(f"Client proof verification failed: {e}")
            return False

    def _prepare_snark_inputs(self, inputs: dict[str, Any]) -> dict[str, Any]:
        client_updates = inputs["client_updates"]
        client_weights = inputs["client_weights"]
        old_params = inputs["old_params"]
        old_momentum = inputs["momentum"]
        momentum_coeff = inputs["momentum_coeff"]

        self._validate_server_proof_inputs(client_updates, client_weights)

        client_deltas = [
            self._flatten_params_for_circuit(update) for update in client_updates
        ]
        fixed_weights = [self._to_fixed_point(weight) for weight in client_weights]
        padded_deltas, padded_weights, active_clients = self._pad_client_slots(
            client_deltas, fixed_weights
        )

        return {
            "client_deltas": padded_deltas,
            "client_weights": padded_weights,
            "active_clients": active_clients,
            "old_params": self._flatten_params_for_circuit(old_params),
            "old_momentum": self._flatten_params_for_circuit(old_momentum),
            "momentum_coeff": self._to_fixed_point(momentum_coeff),
        }

    def _validate_server_proof_inputs(
        self, client_updates: list[NDArrays], client_weights: list[float]
    ) -> None:
        if len(client_updates) != len(client_weights):
            raise ValueError(
                "Client updates/weights length mismatch: "
                f"updates={len(client_updates)}, weights={len(client_weights)}"
            )
        if not client_updates:
            raise ValueError("At least one client update is required for server proof")
        if len(client_updates) > self.max_clients:
            raise ValueError(
                "Server SNARK circuit supports at most "
                f"{self.max_clients} clients per round, got {len(client_updates)}"
            )

    def _to_fixed_point(self, value: Any) -> int:
        return int(round(float(value) * self.FIXED_POINT_SCALE))

    def _flatten_params_for_circuit(self, params: NDArrays) -> list[int]:
        flat = np.concatenate([arr.ravel() for arr in params])
        if len(flat) > self.param_size:
            indices = np.linspace(0, len(flat) - 1, num=self.param_size, dtype=int)
            projected = flat[indices]
            logger.warning(
                "Projecting model vector from %s to %s elements for SNARK circuit",
                len(flat),
                self.param_size,
            )
        elif len(flat) < self.param_size:
            projected = np.pad(flat, (0, self.param_size - len(flat)))
        else:
            projected = flat

        return (
            np.round(projected.astype(float) * self.FIXED_POINT_SCALE)
            .astype(np.int64)
            .tolist()
        )

    def _pad_client_slots(
        self, client_deltas: list[list[int]], client_weights: list[int]
    ) -> tuple[list[list[int]], list[int], list[int]]:
        padded_deltas = list(client_deltas)
        padded_weights = list(client_weights)
        active_clients = [1] * len(client_deltas)

        while len(padded_deltas) < self.max_clients:
            padded_deltas.append([0] * self.param_size)
            padded_weights.append(0)
            active_clients.append(0)
        return padded_deltas, padded_weights, active_clients

    def _format_public_inputs(self, public_inputs: dict[str, Any]) -> list[str]:
        formatted = []
        if "client_weights" in public_inputs:
            formatted.extend([str(w) for w in public_inputs["client_weights"]])
        if "momentum_coeff" in public_inputs:
            formatted.append(str(public_inputs["momentum_coeff"]))
        return formatted

    def _verify_snark_proof(
        self, proof_data: dict[str, Any], public_inputs: list[str]
    ) -> bool:
        if not validate_server_proof_schema(
            proof_data=proof_data,
            expected_type=self.SERVER_PROOF_TYPE,
            expected_version=self.SERVER_PROOF_VERSION,
        ):
            return False
        if not self.verification_key:
            logger.error("Missing verification key for SNARK verification")
            return False
        return verify_snark_proof(
            circuit_dir=Path(self.circuit_dir),
            snarkjs_path=self.snarkjs_path,
            verification_key=self.verification_key,
            proof_data=proof_data,
            public_inputs=public_inputs,
        )
