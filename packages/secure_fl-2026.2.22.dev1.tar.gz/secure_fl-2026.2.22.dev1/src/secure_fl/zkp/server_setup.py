"""Setup and manifest helpers for server SNARK proofs."""

import hashlib
import json
import logging
import re
import shutil
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def read_circuit_dimensions(circom_file: Path) -> tuple[int, int]:
    with open(circom_file, encoding="utf-8") as f:
        content = f.read()

    match = re.search(
        r"component\s+main\s*=\s*FedJSCMAggregation\((\d+)\s*,\s*(\d+)\s*\)",
        content,
    )
    if not match:
        raise ValueError(
            f"Unable to parse FedJSCMAggregation dimensions from {circom_file}"
        )

    return int(match.group(1)), int(match.group(2))


def clean_build_artifacts(circuit_dir: Path, build_dir: Path) -> None:
    logger.info("Cleaning stale build artifacts before setup...")
    artifacts_to_clean = [
        circuit_dir / "aggregation.sym",
        build_dir / "aggregation.r1cs",
        build_dir / "aggregation.wasm",
        build_dir / "aggregation_js",
        build_dir / "aggregation.sym",
        build_dir / "aggregation.zkey",
        build_dir / "verification_key.json",
        build_dir / "setup_manifest.json",
    ]

    for artifact in artifacts_to_clean:
        if artifact.exists():
            if artifact.is_dir():
                shutil.rmtree(artifact)
            else:
                artifact.unlink()


def has_required_setup_artifacts(build_dir: Path) -> bool:
    required = [
        build_dir / "aggregation.r1cs",
        build_dir / "aggregation_js" / "aggregation.wasm",
        build_dir / "aggregation.zkey",
        build_dir / "verification_key.json",
    ]
    return all(path.exists() for path in required)


def build_setup_manifest(
    circuit_dir: Path,
    proof_type: str,
    proof_version: int,
    max_clients: int,
    param_size: int,
    circom_path: str,
    snarkjs_path: str,
) -> dict[str, Any]:
    circom_file = circuit_dir / "aggregation.circom"
    with open(circom_file, encoding="utf-8") as f:
        circuit_content = f.read()

    return {
        "schema_version": 1,
        "proof_type": proof_type,
        "proof_version": proof_version,
        "max_clients": max_clients,
        "param_size": param_size,
        "circuit_sha256": hashlib.sha256(circuit_content.encode("utf-8")).hexdigest(),
        "circom_path": circom_path,
        "snarkjs_path": snarkjs_path,
    }


def manifest_matches_runtime(
    manifest: dict[str, Any],
    circuit_dir: Path,
    proof_type: str,
    proof_version: int,
    max_clients: int,
    param_size: int,
    circom_path: str,
    snarkjs_path: str,
) -> bool:
    expected = build_setup_manifest(
        circuit_dir=circuit_dir,
        proof_type=proof_type,
        proof_version=proof_version,
        max_clients=max_clients,
        param_size=param_size,
        circom_path=circom_path,
        snarkjs_path=snarkjs_path,
    )
    keys = [
        "schema_version",
        "proof_type",
        "proof_version",
        "max_clients",
        "param_size",
        "circuit_sha256",
    ]
    for key in keys:
        if manifest.get(key) != expected.get(key):
            logger.warning(
                "Proof setup manifest mismatch for %s: expected=%s actual=%s",
                key,
                expected.get(key),
                manifest.get(key),
            )
            return False
    return True


def write_setup_manifest(build_dir: Path, manifest: dict[str, Any]) -> None:
    with open(build_dir / "setup_manifest.json", "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
