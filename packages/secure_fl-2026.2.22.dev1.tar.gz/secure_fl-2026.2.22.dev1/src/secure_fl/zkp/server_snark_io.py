"""snarkjs proof generation and verification IO helpers."""

import json
import logging
import subprocess
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def generate_snark_proof(
    *,
    circuit_dir: Path,
    snarkjs_path: str,
    proving_key: str,
    inputs: dict[str, Any],
    proof_type: str,
    proof_version: int,
) -> str | None:
    try:
        build = circuit_dir / "build"

        input_json = build / "input.json"
        witness_wtns = build / "witness.wtns"
        proof_json = build / "proof.json"
        public_json = build / "public.json"

        with open(input_json, "w") as f:
            json.dump(inputs, f)

        wasm_file = build / "aggregation_js" / "aggregation.wasm"
        subprocess.check_call(
            [
                snarkjs_path,
                "wtns",
                "calculate",
                str(wasm_file),
                str(input_json),
                str(witness_wtns),
            ]
        )

        subprocess.check_call(
            [
                snarkjs_path,
                "groth16",
                "prove",
                proving_key,
                str(witness_wtns),
                str(proof_json),
                str(public_json),
            ]
        )

        with open(proof_json) as f:
            proof = json.load(f)
        with open(public_json) as f:
            public = json.load(f)

        return json.dumps(
            {
                "type": proof_type,
                "version": proof_version,
                "proof": proof,
                "public": public,
            }
        )

    except Exception as e:
        logger.error(f"SNARK proof generation failed: {e}")
        return None


def verify_snark_proof(
    *,
    circuit_dir: Path,
    snarkjs_path: str,
    verification_key: str,
    proof_data: dict[str, Any],
    public_inputs: list[str],
) -> bool:
    try:
        build = circuit_dir / "build"
        proof_json = build / "verify_proof.json"
        public_json = build / "verify_public.json"

        with open(proof_json, "w") as f:
            json.dump(proof_data["proof"], f)

        verify_public_inputs = public_inputs
        if not verify_public_inputs:
            verify_public_inputs = [str(v) for v in proof_data.get("public", [])]

        with open(public_json, "w") as f:
            json.dump(verify_public_inputs, f)

        result = subprocess.run(
            [
                snarkjs_path,
                "groth16",
                "verify",
                verification_key,
                str(public_json),
                str(proof_json),
            ],
            capture_output=True,
            text=True,
        )

        return "OK" in result.stdout

    except Exception as e:
        logger.error(f"SNARK verification failed: {e}")
        return False
