"""
Command Line Interface for Secure FL

This module provides command-line interfaces for running the Secure FL framework,
including server, client, experiment, and setup commands.
"""

import logging
import sys

import click
from rich import print as rprint
from rich.console import Console
from rich.logging import RichHandler

from secure_fl.cli.handlers import run_client
from secure_fl.cli.handlers import run_server
from secure_fl.cli.handlers import run_setup
from secure_fl.cli.zkp_check import check_zkp
from secure_fl.core.config import create_example_config

# Setup rich console and logging
console = Console()
logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    datefmt="[%X]",
    handlers=[RichHandler(console=console, rich_tracebacks=True)],
)
logger = logging.getLogger(__name__)


@click.group()
@click.version_option(version="0.1.0")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose logging")
@click.option("--quiet", "-q", is_flag=True, help="Suppress output")
def main(verbose: bool, quiet: bool) -> None:
    """
    🔐 Secure FL: Dual-Verifiable Federated Learning with Zero-Knowledge Proofs

    A complete framework for federated learning with ZKP verification using
    client-side zk-STARKs and server-side zk-SNARKs.
    """
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    elif quiet:
        logging.getLogger().setLevel(logging.ERROR)

    # Display banner
    if not quiet:
        rprint(
            """
[bold blue]🔐 Secure FL Framework[/bold blue]
[dim]Dual-Verifiable Federated Learning with Zero-Knowledge Proofs[/dim]
        """
        )


@main.command()
@click.option(
    "--config", "-c", type=click.Path(exists=True), help="Configuration file path"
)
@click.option("--host", default="localhost", help="Server host address")
@click.option("--port", default=8080, type=int, help="Server port")
@click.option("--rounds", "-r", default=10, type=int, help="Number of training rounds")
@click.option(
    "--min-clients", default=2, type=int, help="Minimum number of clients required"
)
@click.option(
    "--enable-zkp/--disable-zkp",
    default=True,
    help="Enable/disable zero-knowledge proofs",
)
@click.option(
    "--proof-rigor",
    type=click.Choice(["low", "medium", "high"]),
    default="high",
    help="ZKP rigor level",
)
@click.option(
    "--momentum", default=0.9, type=float, help="FedJSCM momentum coefficient"
)
@click.option(
    "--blockchain/--no-blockchain", default=False, help="Enable blockchain verification"
)
@click.option(
    "--model",
    type=click.Choice(["mnist", "cifar10", "simple", "custom"]),
    default="mnist",
    help="Model type to use",
)
def server(
    config: str | None,
    host: str,
    port: int,
    rounds: int,
    min_clients: int,
    enable_zkp: bool,
    proof_rigor: str,
    momentum: float,
    blockchain: bool,
    model: str,
) -> None:
    """Start the Secure FL server"""
    try:
        run_server(
            config=config,
            host=host,
            port=port,
            rounds=rounds,
            min_clients=min_clients,
            enable_zkp=enable_zkp,
            proof_rigor=proof_rigor,
            momentum=momentum,
            blockchain=blockchain,
            model=model,
            console=console,
        )

    except ImportError as e:
        raise click.ClickException(f"Missing dependencies: {e}") from e
    except Exception as e:
        logger.error(f"Server failed to start: {e}")
        raise click.ClickException(f"Server error: {e}") from e


@main.command()
@click.option(
    "--server-address",
    "-s",
    default="localhost:8080",
    help="Server address (host:port)",
)
@click.option("--client-id", "-i", required=True, help="Unique client identifier")
@click.option(
    "--dataset",
    type=click.Choice(["mnist", "cifar10", "synthetic"]),
    default="mnist",
    help="Dataset to use for training",
)
@click.option("--data-path", type=click.Path(), help="Path to custom dataset")
@click.option("--partition", type=int, help="Data partition index")
@click.option(
    "--enable-zkp/--disable-zkp",
    default=True,
    help="Enable/disable zero-knowledge proof generation",
)
@click.option(
    "--epochs", "-e", default=5, type=int, help="Local training epochs per round"
)
@click.option("--batch-size", "-b", default=32, type=int, help="Training batch size")
@click.option(
    "--learning-rate", "-lr", default=0.01, type=float, help="Local learning rate"
)
@click.option(
    "--proof-rigor",
    type=click.Choice(["high", "medium", "low"]),
    default="high",
    help="ZKP proof rigor level",
)
def client(
    server_address: str,
    client_id: str,
    dataset: str,
    data_path: str | None,
    partition: int | None,
    enable_zkp: bool,
    epochs: int,
    batch_size: int,
    learning_rate: float,
    proof_rigor: str,
) -> None:
    """Start a Secure FL client"""
    try:
        run_client(
            server_address=server_address,
            client_id=client_id,
            dataset=dataset,
            data_path=data_path,
            partition=partition,
            enable_zkp=enable_zkp,
            epochs=epochs,
            batch_size=batch_size,
            learning_rate=learning_rate,
            proof_rigor=proof_rigor,
            console=console,
        )

    except ImportError as e:
        raise click.ClickException(f"Missing dependencies: {e}") from e
    except Exception as e:
        logger.error(f"Client failed to start: {e}")
        raise click.ClickException(f"Client error: {e}") from e


@main.command()
@click.option(
    "--action",
    type=click.Choice(["install", "zkp", "check", "clean", "full"]),
    default="check",
    help="Setup action to perform",
)
@click.option("--force", is_flag=True, help="Force reinstallation")
@click.option("--skip-zkp", is_flag=True, help="Skip ZKP tools installation")
def setup(action: str, force: bool, skip_zkp: bool) -> None:
    """Setup and configure Secure FL environment"""
    try:
        _ = force
        run_setup(action=action, skip_zkp=skip_zkp)

    except Exception as e:
        logger.error(f"Setup failed: {e}")
        raise click.ClickException(f"Setup error: {e}") from e


@main.command()
def info() -> None:
    """Display system information and component status"""

    from . import print_system_info

    print_system_info()


def server_command() -> None:
    """Entry point for secure-fl-server command"""
    server.main(args=sys.argv[1:], prog_name="secure-fl-server")


def client_command() -> None:
    """Entry point for secure-fl-client command"""
    client.main(args=sys.argv[1:], prog_name="secure-fl-client")


def setup_command() -> None:
    """Entry point for secure-fl-setup command"""
    setup.main(args=sys.argv[1:], prog_name="secure-fl-setup")


@main.command()
@click.option("--output", "-o", default="config.yaml", help="Output file path")
def create_config(output: str) -> None:
    """Create an example configuration file."""
    try:
        create_example_config(output)
        console.print(f"✅ Example configuration created at [bold]{output}[/bold]")
        console.print("Edit the file to customize your settings.")
    except Exception as e:
        console.print(f"❌ Error creating configuration: {e}", style="red")
        raise click.Abort() from e


# Add check-zkp command to main CLI
main.add_command(check_zkp, name="check-zkp")


if __name__ == "__main__":
    main()
