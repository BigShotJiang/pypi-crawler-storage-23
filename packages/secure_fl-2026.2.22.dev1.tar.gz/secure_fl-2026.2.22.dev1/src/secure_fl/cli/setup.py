"""
Setup utilities for Secure FL CLI.

This module provides setup and installation utilities for the Secure FL framework,
including dependency checking, system configuration, and tool installation.
"""

import importlib.util
import subprocess
import sys

from rich.console import Console
from rich.table import Table


def check_dependencies() -> dict[str, bool]:
    """
    Check if required dependencies are installed.

    Returns:
        Dictionary mapping dependency names to availability status
    """
    dependencies = {
        "torch": False,
        "flwr": False,
        "numpy": False,
        "pysnark": False,
    }

    for dep in dependencies:
        try:
            __import__(dep)
            dependencies[dep] = True
        except ImportError:
            dependencies[dep] = False

    return dependencies


def check_system_requirements() -> dict[str, bool]:
    """
    Check system requirements for Secure FL.

    Returns:
        Dictionary of requirement checks
    """
    return {
        "python_version": sys.version_info >= (3, 12),
        "64_bit": sys.maxsize > 2**32,
    }


def install_zkp_tools() -> bool:
    """
    Install ZKP tools if needed.

    Returns:
        True if installation successful, False otherwise
    """
    console = Console()

    # Check if pysnark is available using importlib
    if importlib.util.find_spec("pysnark") is not None:
        console.print("✅ ZKP tools already installed")
        return True
    console.print("📦 Installing ZKP tools...")
    try:
        subprocess.check_call(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "git+https://github.com/meilof/pysnark",
            ]
        )
        console.print("✅ ZKP tools installed successfully")
        return True
    except subprocess.CalledProcessError:
        console.print("❌ Failed to install ZKP tools")
        return False


def setup_environment() -> bool:
    """
    Set up the Secure FL environment.

    Returns:
        True if setup successful, False otherwise
    """
    console = Console()

    console.print("🔧 Setting up Secure FL environment...")

    # Check system requirements
    sys_reqs = check_system_requirements()
    if not all(sys_reqs.values()):
        console.print("❌ System requirements not met")
        return False

    # Check dependencies
    deps = check_dependencies()
    missing = [dep for dep, available in deps.items() if not available]

    if missing:
        console.print(f"❌ Missing dependencies: {', '.join(missing)}")
        return False

    console.print("✅ Environment setup complete")
    return True


def print_setup_status() -> None:
    """Print current setup status."""
    console = Console()

    # System requirements table
    sys_table = Table(
        title="System Requirements", show_header=True, header_style="bold magenta"
    )
    sys_table.add_column("Requirement", style="cyan")
    sys_table.add_column("Status", style="green")

    sys_reqs = check_system_requirements()
    for req, status in sys_reqs.items():
        status_str = "✅ Met" if status else "❌ Not Met"
        sys_table.add_row(req.replace("_", " ").title(), status_str)

    console.print(sys_table)

    # Dependencies table
    deps_table = Table(
        title="Dependencies", show_header=True, header_style="bold magenta"
    )
    deps_table.add_column("Dependency", style="cyan")
    deps_table.add_column("Status", style="green")

    deps = check_dependencies()
    for dep, available in deps.items():
        status_str = "✅ Available" if available else "❌ Missing"
        deps_table.add_row(dep, status_str)

    console.print(deps_table)
