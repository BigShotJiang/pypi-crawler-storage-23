"""
CLI module for Secure FL.

This module contains command-line interface components for interacting
with the Secure FL framework, including commands for running servers,
clients, configuration management, and system validation.
"""

from .main import client
from .main import create_config
from .main import main
from .main import server
from .zkp_check import check_zkp
from .zkp_check import check_zkp_tools


def print_system_info() -> None:
    """Print system information and component status."""
    import platform
    import sys

    import torch
    from rich.console import Console
    from rich.table import Table

    console = Console()

    # System info table
    table = Table(
        title="System Information", show_header=True, header_style="bold magenta"
    )
    table.add_column("Component", style="cyan", no_wrap=True)
    table.add_column("Version/Status", style="green")

    table.add_row("Python", sys.version.split()[0])
    table.add_row("Platform", platform.platform())
    table.add_row("PyTorch", torch.__version__)
    table.add_row("CUDA Available", str(torch.cuda.is_available()))

    if torch.cuda.is_available():
        table.add_row("CUDA Devices", str(torch.cuda.device_count()))
        table.add_row("Current CUDA Device", torch.cuda.get_device_name())

    console.print(table)
    console.print("\n[bold green]✅ System check completed[/bold green]")


__all__ = [
    "main",
    "server",
    "client",
    "check_zkp",
    "create_config",
    "check_zkp_tools",
    "print_system_info",
]
