"""ZKP tool availability checks and CLI command."""

import subprocess
import sys

import click
from rich.console import Console
from rich.table import Table


def check_zkp_tools() -> dict[str, tuple[bool, str]]:
    """Check availability and version information of required ZKP tools."""
    tools: dict[str, tuple[bool, str]] = {}

    tool_checks = {
        "rust": ["rustc", "--version"],
        "circom": ["circom", "--version"],
        "snarkjs": ["snarkjs", "--version"],
        "nodejs": ["node", "--version"],
    }

    for tool_name, cmd in tool_checks.items():
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                tools[tool_name] = (True, result.stdout.strip())
            else:
                tools[tool_name] = (False, "Installation failed")
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
            tools[tool_name] = (False, "Not found")

    return tools


@click.command()
def check_zkp() -> None:
    """Check ZKP tools installation and versions."""
    console = Console()

    with console.status("Checking ZKP tools..."):
        tools = check_zkp_tools()

    table = Table(title="ZKP Tools Status", show_header=True)
    table.add_column("Tool", style="bold")
    table.add_column("Status", justify="center")
    table.add_column("Version/Info", style="dim")

    for tool_name, (available, version_info) in tools.items():
        if available:
            status = "[green]✓ Available[/green]"
            table.add_row(tool_name.title(), status, version_info)
        else:
            status = "[red]✗ Missing[/red]"
            table.add_row(tool_name.title(), status, version_info)

    console.print(table)

    required_tools = ["rust", "circom", "snarkjs", "nodejs"]
    missing_tools = [
        tool for tool in required_tools if not tools.get(tool, (False, ""))[0]
    ]

    if missing_tools:
        console.print("\n[yellow]⚠️ Missing required ZKP tools:[/yellow]")
        for tool in missing_tools:
            console.print(f"  • {tool.title()}")

        console.print("\n[blue]Installation instructions:[/blue]")
        console.print(
            "1. Install Rust: curl --proto '=https' --tlsv1.2 https://sh.rustup.rs -sSf | sh"
        )
        console.print("2. Install Node.js: https://nodejs.org/")
        console.print("3. Install Circom: cargo install circom")
        console.print("4. Install SnarkJS: npm install -g snarkjs")

        sys.exit(1)

    console.print("\n[green]✅ All ZKP tools are properly installed![/green]")
