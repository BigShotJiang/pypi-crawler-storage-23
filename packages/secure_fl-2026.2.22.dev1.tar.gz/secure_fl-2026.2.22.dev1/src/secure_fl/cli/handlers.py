"""Command handlers for the Secure FL CLI."""

import logging
import os
import shutil
import subprocess
from typing import TYPE_CHECKING
from typing import Union

import click
from rich import print as rprint
from rich.console import Console
from rich.progress import Progress
from rich.progress import SpinnerColumn
from rich.progress import TextColumn
from rich.table import Table

from secure_fl.core.config import create_example_config
from secure_fl.models import CIFAR10Model
from secure_fl.models import MNISTModel
from secure_fl.models import SimpleModel

if TYPE_CHECKING:
    from collections.abc import Callable

logger = logging.getLogger(__name__)


def run_server(
    *,
    config: str | None,
    host: str,
    port: int,
    rounds: int,
    min_clients: int,
    enable_zkp: bool,
    proof_rigor: str,
    momentum: float,
    blockchain: bool,
    model: str,
    console: Console,
) -> None:
    from secure_fl.core import get_default_config
    from secure_fl.federation.server import SecureFlowerServer
    from secure_fl.federation.server import create_server_strategy

    if config:
        import yaml

        with open(config) as f:
            cfg = yaml.safe_load(f)
    else:
        cfg = get_default_config()

    cfg["server"].update({"host": host, "port": port, "num_rounds": rounds})

    strategy_config = {**cfg["strategy"], **cfg["aggregation"], **cfg["zkp"]}
    strategy_config.update(
        {
            "min_available_clients": min_clients,
            "min_fit_clients": min_clients,
            "min_evaluate_clients": min_clients,
            "momentum": momentum,
            "enable_zkp": enable_zkp,
            "proof_rigor": proof_rigor,
            "blockchain_verification": blockchain,
        }
    )

    model_fn: Callable[[], Union[MNISTModel, CIFAR10Model, SimpleModel]]
    if model == "mnist":

        def model_fn() -> MNISTModel:
            return MNISTModel()
    elif model == "cifar10":

        def model_fn() -> CIFAR10Model:
            return CIFAR10Model()
    elif model == "simple":

        def model_fn() -> SimpleModel:
            return SimpleModel(input_dim=784, output_dim=10)
    else:
        raise click.ClickException(
            f"Unknown model '{model}'. Available: mnist, cifar10, simple"
        )

    strategy = create_server_strategy(model_fn=model_fn, **strategy_config)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        task = progress.add_task("Starting Secure FL Server...", total=None)
        server = SecureFlowerServer(strategy=strategy, **cfg["server"])
        progress.update(task, description="Server ready! Waiting for clients...")

        table = Table(title="Server Configuration")
        table.add_column("Parameter", style="cyan")
        table.add_column("Value", style="green")
        table.add_row("Host", f"{host}:{port}")
        table.add_row("Rounds", str(rounds))
        table.add_row("Min Clients", str(min_clients))
        table.add_row("ZKP Enabled", "✓" if enable_zkp else "✗")
        table.add_row("Proof Rigor", proof_rigor)
        table.add_row("Momentum", str(momentum))
        table.add_row("Blockchain", "✓" if blockchain else "✗")
        console.print(table)
        server.start()


def run_client(
    *,
    server_address: str,
    client_id: str,
    dataset: str,
    data_path: str | None,
    partition: int | None,
    enable_zkp: bool,
    epochs: int,
    batch_size: int,
    learning_rate: float,
    proof_rigor: str,
    console: Console,
) -> None:
    from secure_fl.data import FederatedDataLoader
    from secure_fl.federation.client import create_client
    from secure_fl.federation.client import start_client

    if data_path:
        data_loader = FederatedDataLoader(
            dataset_name="synthetic",
            num_clients=1,
            batch_size=batch_size,
        )
        loaders = data_loader.create_client_dataloaders(client_id=0)
        train_loader, val_loader = (
            loaders if not isinstance(loaders, list) else loaders[0]
        )
        train_data = train_loader.dataset
        val_data = val_loader.dataset if val_loader else None
    else:
        data_loader = FederatedDataLoader(
            dataset_name=dataset,
            num_clients=max(1, partition + 1) if partition is not None else 5,
            batch_size=batch_size,
        )
        client_partition = partition or 0
        loaders = data_loader.create_client_dataloaders(client_id=client_partition)
        train_loader, val_loader = (
            loaders if not isinstance(loaders, list) else loaders[0]
        )
        train_data = train_loader.dataset
        val_data = val_loader.dataset if val_loader else None

    if dataset in ["mnist", "synthetic"] and dataset != "custom":
        model_fn: Callable[[], Union[MNISTModel, CIFAR10Model, SimpleModel]]
        if dataset == "mnist":

            def model_fn() -> MNISTModel:
                return MNISTModel()
        elif dataset == "cifar10":

            def model_fn() -> CIFAR10Model:
                return CIFAR10Model()
        else:

            def model_fn() -> SimpleModel:
                return SimpleModel()
    else:

        def model_fn() -> SimpleModel:
            return SimpleModel()

    client = create_client(
        client_id=client_id,
        model_fn=model_fn,
        train_data=train_data,
        val_data=val_data,
        enable_zkp=enable_zkp,
        local_epochs=epochs,
        batch_size=batch_size,
        learning_rate=learning_rate,
        proof_rigor=proof_rigor,
    )

    table = Table(title=f"Client {client_id} Configuration")
    table.add_column("Parameter", style="cyan")
    table.add_column("Value", style="green")
    table.add_row("Server", server_address)
    table.add_row("Dataset", dataset)
    table.add_row("ZKP Enabled", "✓" if enable_zkp else "✗")
    table.add_row("Epochs", str(epochs))
    table.add_row("Batch Size", str(batch_size))
    table.add_row("Learning Rate", str(learning_rate))
    console.print(table)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        progress.add_task("Connecting to server...", total=None)
        start_client(client, server_address)


def run_setup(*, action: str, skip_zkp: bool) -> None:
    from secure_fl.cli.setup import print_setup_status
    from secure_fl.cli.setup import setup_environment

    if action == "check":
        rprint("[bold]🔍 Checking System Requirements[/bold]")
        print_setup_status()
    elif action == "install":
        rprint("[bold]📦 Installing Python Dependencies[/bold]")
        success = setup_environment()
        if success:
            rprint("[green]✓ Python dependencies installed successfully[/green]")
        else:
            rprint("[red]✗ Failed to install some dependencies[/red]")
    elif action == "zkp":
        if skip_zkp:
            rprint("[yellow]⚠ Skipping ZKP tools installation[/yellow]")
            return
        rprint("[bold]🔐 Setting up ZKP Tools[/bold]")
        from secure_fl.cli.setup import install_zkp_tools

        success = install_zkp_tools()
        if success:
            rprint("[green]✓ ZKP tools setup completed[/green]")
        else:
            rprint("[yellow]⚠ ZKP tools setup completed with warnings[/yellow]")
    elif action == "clean":
        rprint("[bold]🧹 Cleaning temporary files[/bold]")
        for cache_dir in [".ruff_cache", ".mypy_cache", "__pycache__"]:
            if os.path.exists(cache_dir):
                shutil.rmtree(cache_dir)
        rprint("[green]✓ Cleanup completed[/green]")
    elif action == "full":
        rprint("[bold]🚀 Full Setup[/bold]")
        rprint("1. Installing Python dependencies...")
        success = setup_environment()
        if not skip_zkp:
            rprint("2. Setting up ZKP tools...")
            from secure_fl.cli.setup import install_zkp_tools

            install_zkp_tools()
        else:
            rprint("2. Skipping ZKP tools...")

        rprint("3. Creating configuration...")
        create_example_config("config.yaml")
        rprint("4. Running tests...")
        try:
            subprocess.run(["uv", "run", "pytest", "--tb=short"], check=True)
            test_success = True
        except subprocess.CalledProcessError:
            test_success = False

        if success and test_success:
            rprint("[green]✓ Full setup completed successfully![/green]")
            rprint("\n[bold]Next steps:[/bold]")
            rprint(
                "1. Run a demo: [cyan]secure-fl experiment --dataset synthetic --rounds 3[/cyan]"
            )
            rprint("2. Start a server: [cyan]secure-fl server --rounds 5[/cyan]")
            rprint("3. Connect clients: [cyan]secure-fl client -i client_1[/cyan]")
        else:
            rprint("[yellow]⚠ Setup completed with test failures[/yellow]")
