"""
Utilities module for Secure FL.

This module contains utility functions and helper classes for logging,
parameter handling, data conversion, and other common operations used
throughout the Secure FL framework.
"""

from .helpers import aggregate_weighted_average
from .helpers import compute_hash
from .helpers import compute_parameter_diff
from .helpers import compute_parameter_norm
from .helpers import deserialize_parameters
from .helpers import get_parameter_stats
from .helpers import ndarrays_to_parameters
from .helpers import ndarrays_to_torch
from .helpers import parameters_to_ndarrays  # Parameter utilities
from .helpers import serialize_parameters
from .helpers import torch_to_ndarrays
from .helpers import validate_parameters
from .logging_config import AuditLogger
from .logging_config import PerformanceLogger
from .logging_config import SecureFlLogger
from .logging_config import get_client_logger
from .logging_config import get_logger
from .logging_config import get_proof_logger
from .logging_config import get_server_logger
from .logging_config import setup_development_logging
from .logging_config import setup_logging
from .logging_config import setup_production_logging
from .logging_config import setup_testing_logging

__all__ = [
    # Parameter utilities
    "parameters_to_ndarrays",
    "ndarrays_to_parameters",
    "torch_to_ndarrays",
    "ndarrays_to_torch",
    "compute_parameter_norm",
    "compute_parameter_diff",
    "compute_hash",
    "serialize_parameters",
    "deserialize_parameters",
    "aggregate_weighted_average",
    "validate_parameters",
    "get_parameter_stats",
    # Logging utilities
    "setup_logging",
    "setup_development_logging",
    "setup_production_logging",
    "setup_testing_logging",
    "get_logger",
    "SecureFlLogger",
    "PerformanceLogger",
    "AuditLogger",
    "get_client_logger",
    "get_server_logger",
    "get_proof_logger",
]
