"""
Logging configuration for Secure FL.

This module provides structured logging setup for better maintainability,
debugging, and monitoring across the Secure FL framework.
"""

from __future__ import annotations

import logging
import logging.config
from pathlib import Path
from typing import Any

import rich.logging
from rich.console import Console


class SecureFlFormatter(logging.Formatter):
    """Custom formatter for Secure FL logs with context support."""

    def format(self, record: logging.LogRecord) -> str:
        """Format log record with additional context."""
        # Add module context
        if hasattr(record, "context"):
            context = record.context
            if isinstance(context, dict):
                context_str = " | ".join(f"{k}={v}" for k, v in context.items())
                record.msg = f"{record.msg} | {context_str}"

        # Add client/server context if available
        if hasattr(record, "client_id"):
            record.msg = f"[Client {record.client_id}] {record.msg}"
        elif hasattr(record, "server_id"):
            record.msg = f"[Server {record.server_id}] {record.msg}"

        return super().format(record)


def setup_logging(
    level: str = "INFO",
    log_file: str | None = None,
    console_output: bool = True,
    rich_console: bool = True,
    log_dir: str | None = None,
) -> None:
    """
    Setup logging configuration for Secure FL.

    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Log file name (optional)
        console_output: Enable console output
        rich_console: Use rich console for better formatting
        log_dir: Directory for log files
    """
    # Convert string level to logging constant
    numeric_level = getattr(logging, level.upper(), logging.INFO)

    # Create log directory if needed
    if log_dir:
        Path(log_dir).mkdir(parents=True, exist_ok=True)

    # Base logging configuration
    config: dict[str, Any] = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "standard": {
                "()": SecureFlFormatter,
                "format": "%(asctime)s | %(name)s | %(levelname)s | %(message)s",
                "datefmt": "%Y-%m-%d %H:%M:%S",
            },
            "detailed": {
                "()": SecureFlFormatter,
                "format": "%(asctime)s | %(name)s | %(levelname)s | %(filename)s:%(lineno)d | %(funcName)s | %(message)s",
                "datefmt": "%Y-%m-%d %H:%M:%S",
            },
            "json": {
                "()": "pythonjsonlogger.jsonlogger.JsonFormatter",
                "format": "%(asctime)s %(name)s %(levelname)s %(filename)s %(lineno)d %(funcName)s %(message)s",
            },
        },
        "handlers": {},
        "loggers": {
            "secure_fl": {
                "level": level.upper(),
                "handlers": [],
                "propagate": False,
            },
            "flwr": {
                "level": "WARNING",  # Reduce Flower verbosity
                "handlers": [],
                "propagate": True,
            },
            "torch": {
                "level": "WARNING",  # Reduce PyTorch verbosity
                "handlers": [],
                "propagate": True,
            },
        },
        "root": {
            "level": "WARNING",
            "handlers": [],
        },
    }

    handlers = []

    # Console handler
    if console_output:
        if rich_console:
            # Use rich handler for better console output
            console = Console(stderr=True)
            rich_handler = rich.logging.RichHandler(
                console=console,
                show_time=True,
                show_path=True,
                markup=True,
                rich_tracebacks=True,
                tracebacks_show_locals=True,
            )
            rich_handler.setLevel(numeric_level)
            logging.getLogger().addHandler(rich_handler)
            handlers.append("rich")
        else:
            config["handlers"]["console"] = {
                "class": "logging.StreamHandler",
                "level": level.upper(),
                "formatter": "standard",
                "stream": "ext://sys.stdout",
            }
            handlers.append("console")

    # File handler
    if log_file:
        log_path = log_file
        if log_dir:
            log_path = str(Path(log_dir) / log_file)

        config["handlers"]["file"] = {
            "class": "logging.handlers.RotatingFileHandler",
            "level": level.upper(),
            "formatter": "detailed",
            "filename": log_path,
            "maxBytes": 10 * 1024 * 1024,  # 10MB
            "backupCount": 5,
            "encoding": "utf8",
        }
        handlers.append("file")

    # Error file handler (always logs errors to separate file if file logging is enabled)
    if log_file:
        error_log_path = (
            log_file.replace(".log", "_errors.log")
            if log_file.endswith(".log")
            else f"{log_file}_errors.log"
        )
        if log_dir:
            error_log_path = str(Path(log_dir) / error_log_path)

        config["handlers"]["error_file"] = {
            "class": "logging.handlers.RotatingFileHandler",
            "level": "ERROR",
            "formatter": "detailed",
            "filename": error_log_path,
            "maxBytes": 10 * 1024 * 1024,  # 10MB
            "backupCount": 3,
            "encoding": "utf8",
        }
        handlers.append("error_file")

    # Update handler lists
    config["loggers"]["secure_fl"]["handlers"] = handlers
    config["root"]["handlers"] = handlers

    # Apply configuration
    if not rich_console:
        logging.config.dictConfig(config)

    # Set up structured logging for key modules
    _setup_module_loggers()


def _setup_module_loggers() -> None:
    """Setup loggers for specific modules with appropriate levels."""
    module_configs = {
        "secure_fl.client": logging.INFO,
        "secure_fl.server": logging.INFO,
        "secure_fl.proof_manager": logging.INFO,
        "secure_fl.aggregation": logging.INFO,
        "secure_fl.quantization": logging.INFO,
        "secure_fl.stability_monitor": logging.INFO,
        "secure_fl.config": logging.INFO,
        "secure_fl.cli": logging.INFO,
    }

    for module_name, level in module_configs.items():
        logger = logging.getLogger(module_name)
        logger.setLevel(level)


def get_logger(name: str, **context: Any) -> SecureFlLogger:
    """
    Get a logger with optional context.

    Args:
        name: Logger name
        **context: Additional context to include in logs

    Returns:
        Configured logger with context support
    """
    base_logger = logging.getLogger(f"secure_fl.{name}")
    return SecureFlLogger(base_logger, context)


class SecureFlLogger:
    """Wrapper logger with context support for Secure FL."""

    def __init__(self, logger: logging.Logger, context: dict[str, Any]) -> None:
        """Initialize logger wrapper with context."""
        self._logger = logger
        self._context = context

    def _log(self, level: int, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log message with context."""
        # Merge context with any additional context in kwargs
        extra = kwargs.get("extra", {})
        if self._context:
            extra["context"] = {**self._context, **extra.get("context", {})}
            kwargs["extra"] = extra

        self._logger.log(level, msg, *args, **kwargs)

    def debug(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log debug message."""
        self._log(logging.DEBUG, msg, *args, **kwargs)

    def info(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log info message."""
        self._log(logging.INFO, msg, *args, **kwargs)

    def warning(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log warning message."""
        self._log(logging.WARNING, msg, *args, **kwargs)

    def error(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log error message."""
        self._log(logging.ERROR, msg, *args, **kwargs)

    def critical(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log critical message."""
        self._log(logging.CRITICAL, msg, *args, **kwargs)

    def exception(self, msg: str, *args: Any, **kwargs: Any) -> None:
        """Log exception with traceback."""
        kwargs["exc_info"] = True
        self.error(msg, *args, **kwargs)

    def with_context(self, **context: Any) -> SecureFlLogger:
        """Create a new logger with additional context."""
        new_context = {**self._context, **context}
        return SecureFlLogger(self._logger, new_context)


def setup_development_logging() -> None:
    """Setup logging for development environment."""
    setup_logging(
        level="DEBUG",
        console_output=True,
        rich_console=True,
        log_file="secure_fl_dev.log",
    )


def setup_production_logging(log_dir: str = "/var/log/secure-fl") -> None:
    """Setup logging for production environment."""
    setup_logging(
        level="INFO",
        console_output=True,
        rich_console=False,
        log_file="secure_fl.log",
        log_dir=log_dir,
    )


def setup_testing_logging() -> None:
    """Setup minimal logging for testing."""
    setup_logging(
        level="WARNING",
        console_output=False,
        rich_console=False,
    )


# Performance logging utilities


class PerformanceLogger:
    """Logger for performance metrics and timing."""

    def __init__(self, name: str) -> None:
        """Initialize performance logger."""
        self.logger = get_logger(f"performance.{name}")

    def log_timing(
        self,
        operation: str,
        duration: float,
        **context: Any,
    ) -> None:
        """Log operation timing."""
        self.logger.info(
            f"Operation '{operation}' completed in {duration:.4f}s",
            extra={
                "context": {"operation": operation, "duration": duration, **context}
            },
        )

    def log_metrics(
        self,
        metrics: dict[str, Any],
        operation: str = "metrics",
        **context: Any,
    ) -> None:
        """Log performance metrics."""
        self.logger.info(
            f"Metrics for '{operation}': {metrics}",
            extra={"context": {"operation": operation, "metrics": metrics, **context}},
        )


# Audit logging utilities


class AuditLogger:
    """Logger for security and audit events."""

    def __init__(self) -> None:
        """Initialize audit logger."""
        self.logger = get_logger("audit")

    def log_client_action(
        self,
        client_id: str,
        action: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Log client action for auditing."""
        context = {"client_id": client_id, "action": action}
        if details:
            context.update(details)

        self.logger.info(
            f"Client action: {client_id} performed {action}",
            extra={"context": context},
        )

    def log_server_action(
        self,
        action: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Log server action for auditing."""
        context = {"action": action}
        if details:
            context.update(details)

        self.logger.info(
            f"Server action: {action}",
            extra={"context": context},
        )

    def log_proof_event(
        self,
        event: str,
        proof_id: str,
        client_id: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """Log proof-related event for auditing."""
        context = {"event": event, "proof_id": proof_id}
        if client_id:
            context["client_id"] = client_id
        if details:
            context.update(details)

        self.logger.info(
            f"Proof event: {event} for proof {proof_id}",
            extra={"context": context},
        )


# Default loggers for common use cases
def get_client_logger(client_id: str) -> SecureFlLogger:
    """Get logger for client operations."""
    return get_logger("client", client_id=client_id)


def get_server_logger() -> SecureFlLogger:
    """Get logger for server operations."""
    return get_logger("server")


def get_proof_logger(proof_type: str = "unknown") -> SecureFlLogger:
    """Get logger for proof operations."""
    return get_logger("proof", proof_type=proof_type)


# Export all public classes and functions
__all__ = [
    "setup_logging",
    "setup_development_logging",
    "setup_production_logging",
    "setup_testing_logging",
    "get_logger",
    "SecureFlLogger",
    "PerformanceLogger",
    "AuditLogger",
    "get_client_logger",
    "get_server_logger",
    "get_proof_logger",
]
