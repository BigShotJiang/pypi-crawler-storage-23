"""
Federated Learning Client with zk-STARK Proof Generation

This module implements FL clients that:
1. Perform local training using PyTorch
2. Generate zk-STARK proofs for training verification
3. Communicate with the FL server using Flower framework
4. Support dynamic proof rigor adjustment
"""

import logging
import time
from collections.abc import Callable
from collections.abc import Sized
from typing import Any
from typing import cast

import torch
import torch.nn as nn
import torch.optim as optim
from flwr.client import NumPyClient
from flwr.common import NDArrays
from flwr.common import Scalar
from torch.utils.data import DataLoader

from secure_fl.zkp.proof_manager import ClientProofManager
from secure_fl.zkp.quantization import quantize_parameters

from .client_utils import compute_data_commitment
from .client_utils import compute_gradient_norm
from .client_utils import compute_parameter_delta
from .client_utils import compute_training_accuracy
from .client_utils import evaluate_model
from .client_utils import prepare_training_traces

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SecureFlowerClient(NumPyClient):
    """
    Secure FL client with zk-STARK proof generation
    """

    def __init__(
        self,
        client_id: str,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: DataLoader | None = None,
        device: str = "cpu",
        enable_zkp: bool = True,
        proof_rigor: str = "high",
        quantize_weights: bool = True,
        local_epochs: int = 1,
        learning_rate: float = 0.01,
    ):
        """
        Initialize secure FL client

        Args:
            client_id: Unique client identifier
            model: PyTorch model for training
            train_loader: Training data loader
            val_loader: Validation data loader (optional)
            device: Device for computation ('cpu' or 'cuda')
            enable_zkp: Whether to generate zk-STARK proofs
            proof_rigor: Proof rigor level ('high', 'medium', 'low')
            quantize_weights: Whether to quantize weights for circuits
            local_epochs: Number of local training epochs
            learning_rate: Local learning rate
        """
        self.client_id = client_id
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        self.enable_zkp = enable_zkp
        self.proof_rigor = proof_rigor
        self.quantize_weights = quantize_weights
        self.local_epochs = local_epochs
        self.learning_rate = learning_rate
        self.batch_size = (
            train_loader.batch_size if hasattr(train_loader, "batch_size") else 32
        )

        # ZKP components
        self.proof_manager = ClientProofManager() if enable_zkp else None

        # Training state
        self.training_history: list[dict[str, Any]] = []
        self.round_count = 0

        # Data commitment for ZKP
        self.data_commitment = compute_data_commitment(self.train_loader)

        logger.info(f"Client {client_id} initialized with ZKP={enable_zkp}")

    def get_parameters(self, config: dict[str, Any]) -> NDArrays:
        """Get model parameters (only learnable parameters)"""
        return [param.detach().cpu().numpy() for param in self.model.parameters()]

    def set_parameters(self, parameters: NDArrays) -> None:
        """Set model parameters (only learnable parameters)"""
        model_params = list(self.model.parameters())

        if len(model_params) != len(parameters):
            raise ValueError(
                f"Number of model parameters ({len(model_params)}) does not match "
                f"number of provided parameters ({len(parameters)})"
            )

        with torch.no_grad():
            for param, array in zip(model_params, parameters, strict=False):
                tensor = torch.from_numpy(array).to(param.device, dtype=param.dtype)
                param.copy_(tensor)

    def fit(
        self, parameters: NDArrays, config: dict[str, Any]
    ) -> tuple[NDArrays, int, dict[str, Any]]:
        """
        Train model locally and generate ZKP proof
        """
        try:
            start_time = time.time()
            self.round_count = config.get("server_round", 0)

            logger.info(
                f"Client {self.client_id} starting fit for round {self.round_count}"
            )

            # Update configuration from server
            self.local_epochs = config.get("local_epochs", self.local_epochs)
            self.learning_rate = config.get("learning_rate", self.learning_rate)
            self.proof_rigor = config.get("proof_rigor", self.proof_rigor)

            # Set received parameters
            logger.debug(f"Client {self.client_id} setting parameters...")
            self.set_parameters(parameters)
            initial_params = self.get_parameters({})

            # Perform local training
            logger.info(f"Client {self.client_id} starting local training...")
            training_metrics = self._train_local_model()

            # Get updated parameters
            logger.debug(f"Client {self.client_id} getting updated parameters...")
            updated_params = self.get_parameters({})
        except Exception as e:
            logger.error(
                f"Client {self.client_id} fit failed during initial setup: {type(e).__name__}: {e}"
            )
            raise

        try:
            # Compute parameter update (delta)
            logger.debug(f"Client {self.client_id} computing parameter delta...")
            param_delta = compute_parameter_delta(initial_params, updated_params)

            # Quantize parameters if enabled
            if self.quantize_weights:
                logger.debug(f"Client {self.client_id} quantizing parameters...")
                try:
                    from secure_fl.zkp.quantization import QuantizationConfig

                    quant_config = QuantizationConfig(bits=8)
                    param_delta, _ = quantize_parameters(param_delta, quant_config)
                    updated_params, _ = quantize_parameters(
                        updated_params, quant_config
                    )
                except Exception as e:
                    logger.warning(
                        f"Client {self.client_id} quantization failed, skipping: {e}"
                    )

            # Generate ZKP proof
            proof_time = 0.0
            proof_data = None
            if self.enable_zkp:
                try:
                    logger.debug(f"Client {self.client_id} generating ZKP proof...")
                    proof_start = time.time()
                    proof_data = self._generate_training_proof(
                        initial_params=initial_params,
                        updated_params=updated_params,
                        param_delta=param_delta,
                        training_metrics=training_metrics,
                    )
                    proof_time = time.time() - proof_start
                except Exception as e:
                    logger.warning(
                        f"Client {self.client_id} ZKP proof generation failed, skipping: {e}"
                    )

            # Prepare metrics
            dataset = self.train_loader.dataset
            num_examples = (
                len(cast("Sized", dataset)) if isinstance(dataset, Sized) else 0
            )
            total_time = time.time() - start_time

            metrics: dict[str, Scalar] = {
                "client_id": self.client_id,
                "training_time": total_time - proof_time,
                "proof_time": proof_time,
                "local_epochs": self.local_epochs,
                "proof_rigor": self.proof_rigor,
            }
            # Add numeric training metrics
            for k, v in training_metrics.items():
                if isinstance(v, (bool, bytes, float, int, str)):
                    metrics[k] = v

            if proof_data:
                metrics["zkp_proof"] = proof_data

            self.training_history.append(metrics)

            logger.info(
                f"Client {self.client_id} Round {self.round_count}: "
                f"train_time={total_time - proof_time:.2f}s, proof_time={proof_time:.2f}s, "
                f"loss={training_metrics.get('train_loss', 0):.4f}"
            )

            return updated_params, num_examples, metrics

        except Exception as e:
            logger.error(
                f"Client {self.client_id} fit failed during processing: {type(e).__name__}: {e}"
            )
            # Return basic results to avoid complete failure
            fallback_dataset: Any = (
                self.train_loader.dataset if hasattr(self, "train_loader") else None
            )
            num_examples = (
                len(fallback_dataset) if isinstance(fallback_dataset, Sized) else 0
            )
            basic_metrics: dict[str, Scalar] = {
                "client_id": self.client_id,
                "error": str(e),
                "training_time": 0.0,
                "local_epochs": self.local_epochs,
            }
            return (
                initial_params if "initial_params" in locals() else parameters,
                num_examples,
                basic_metrics,
            )

    def evaluate(
        self, parameters: NDArrays, config: dict[str, Any]
    ) -> tuple[float, int, dict[str, Any]]:
        """Evaluate model on validation data"""
        if self.val_loader is None:
            return 0.0, 0, {}

        self.set_parameters(parameters)

        loss, accuracy = self._evaluate_model(self.val_loader)
        dataset = self.val_loader.dataset if self.val_loader else None
        num_examples = len(cast("Sized", dataset)) if isinstance(dataset, Sized) else 0

        metrics = {
            "client_id": self.client_id,
            "val_accuracy": accuracy,
        }

        return float(loss), num_examples, metrics

    def _train_local_model(self) -> dict[str, Any]:
        """Perform local SGD training"""
        try:
            self.model.train()
            optimizer = optim.SGD(
                self.model.parameters(), lr=self.learning_rate, weight_decay=1e-4
            )
            criterion = nn.CrossEntropyLoss()

            total_loss = 0.0
            total_samples = 0
            batch_losses = []
            gradients_history = []

            logger.debug(
                f"Client {self.client_id} starting training for {self.local_epochs} epochs"
            )

            for epoch in range(self.local_epochs):
                epoch_loss = 0.0
                epoch_samples = 0

                try:
                    for batch_idx, (data, target) in enumerate(self.train_loader):
                        try:
                            data, target = data.to(self.device), target.to(self.device)

                            optimizer.zero_grad()
                            output = self.model(data)
                            loss = criterion(output, target)

                            loss.backward()

                            # Store gradient information for ZKP
                            if self.enable_zkp and self.proof_rigor == "high":
                                try:
                                    grad_norm = compute_gradient_norm(self.model)
                                    gradients_history.append(grad_norm)
                                except Exception as e:
                                    logger.warning(
                                        "Client %s gradient norm computation failed: %s",
                                        self.client_id,
                                        e,
                                    )

                            optimizer.step()

                            batch_loss = loss.item()
                            batch_size = data.size(0)

                            epoch_loss += batch_loss * batch_size
                            epoch_samples += batch_size
                            batch_losses.append(batch_loss)

                            # Log batch progress for high rigor proofs
                            if self.proof_rigor == "high" and batch_idx % 10 == 0:
                                logger.debug(
                                    f"Client {self.client_id} Epoch {epoch + 1}/{self.local_epochs}, "
                                    f"Batch {batch_idx}, Loss: {batch_loss:.4f}"
                                )
                        except Exception as e:
                            logger.error(
                                f"Client {self.client_id} batch {batch_idx} failed: {e}"
                            )
                            continue

                except Exception as e:
                    logger.error(f"Client {self.client_id} epoch {epoch} failed: {e}")
                    continue

                total_loss += epoch_loss
                total_samples += epoch_samples

                logger.debug(
                    f"Client {self.client_id} completed epoch {epoch + 1}, loss: {epoch_loss / max(epoch_samples, 1):.4f}"
                )

            avg_loss = total_loss / total_samples if total_samples > 0 else 0.0
        except Exception as e:
            logger.error(
                f"Client {self.client_id} training failed: {type(e).__name__}: {e}"
            )
            return {"train_loss": 0.0, "num_examples": 0}

        # Compute training accuracy on a subset for efficiency
        train_accuracy = compute_training_accuracy(
            self.model, self.train_loader, self.device
        )
        batch_trace, gradient_trace = prepare_training_traces(
            self.proof_rigor, batch_losses, gradients_history
        )

        return {
            "train_loss": avg_loss,
            "train_accuracy": train_accuracy,
            "total_samples": total_samples,
            "batch_losses": batch_trace,
            "gradient_norms": gradient_trace,
        }

    def _evaluate_model(self, data_loader: DataLoader) -> tuple[float, float]:
        """Evaluate model on given data loader"""
        return evaluate_model(self.model, data_loader, self.device)

    def _compute_training_accuracy(self) -> float:
        """Compute accuracy on training data (subset for efficiency)"""
        return compute_training_accuracy(self.model, self.train_loader, self.device)

    def _compute_parameter_delta(
        self, initial_params: NDArrays, updated_params: NDArrays
    ) -> NDArrays:
        """Compute parameter update delta = updated - initial"""
        return compute_parameter_delta(initial_params, updated_params)

    def _compute_gradient_norm(self) -> float:
        """Compute L2 norm of current gradients"""
        return compute_gradient_norm(self.model)

    def _compute_data_commitment(self) -> str:
        """Compute cryptographic commitment to training data"""
        return compute_data_commitment(self.train_loader)

    def _generate_training_proof(
        self,
        initial_params: NDArrays,
        updated_params: NDArrays,
        param_delta: NDArrays,
        training_metrics: dict[str, Any],
    ) -> str | None:
        """Generate proof of correct training"""
        if not self.proof_manager:
            return None

        try:
            proof_inputs = {
                "client_id": self.client_id,
                "round": self.round_count,
                "data_commitment": self.data_commitment,
                "initial_params": initial_params,
                "updated_params": updated_params,
                "param_delta": param_delta,
                "learning_rate": self.learning_rate,
                "local_epochs": self.local_epochs,
                "rigor_level": self.proof_rigor,
                "batch_losses": training_metrics.get("batch_losses", []),
                "gradient_norms": training_metrics.get("gradient_norms", []),
                "total_samples": training_metrics.get("total_samples", 0),
            }

            # Generate JSON proof object
            # --------------------------
            return self.proof_manager.generate_training_proof(proof_inputs)

        except Exception as e:
            logger.error(f"Client {self.client_id} proof generation failed: {e}")
            return None

    def get_client_info(self) -> dict[str, Any]:
        """Get client information and statistics"""
        return {
            "client_id": self.client_id,
            "device": self.device,
            "enable_zkp": self.enable_zkp,
            "proof_rigor": self.proof_rigor,
            "quantize_weights": self.quantize_weights,
            "dataset_size": len(cast("Sized", self.train_loader.dataset))
            if isinstance(self.train_loader.dataset, Sized)
            else 0,
            "data_commitment": self.data_commitment,
            "training_history": self.training_history[-5:],  # Recent history
            "round_count": self.round_count,
        }


def create_client(
    client_id: str,
    model_fn: Callable[..., Any],
    train_data: Any,
    val_data: Any = None,
    batch_size: int = 32,
    **kwargs: Any,
) -> SecureFlowerClient:
    """
    Factory function to create a secure FL client

    Args:
        client_id: Unique client identifier
        model_fn: Function that returns a PyTorch model
        train_data: Training dataset
        val_data: Validation dataset (optional)
        batch_size: Batch size for data loaders
        **kwargs: Additional arguments for SecureFlowerClient
    """
    from .client_runtime import create_client as _create_client

    return _create_client(
        client_id=client_id,
        model_fn=model_fn,
        train_data=train_data,
        val_data=val_data,
        batch_size=batch_size,
        **kwargs,
    )


def start_client(
    client: SecureFlowerClient, server_address: str = "localhost:8080"
) -> None:
    from .client_runtime import start_client as _start_client

    _start_client(client, server_address)


# Example usage and testing
if __name__ == "__main__":
    print("Use 'python -m secure_fl.cli client' to start a client")
