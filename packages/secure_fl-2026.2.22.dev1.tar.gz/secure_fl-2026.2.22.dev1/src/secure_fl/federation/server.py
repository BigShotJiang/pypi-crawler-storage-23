"""
Federated Learning Server with FedJSCM Aggregation and ZKP Integration

This module implements the main FL server that:
1. Manages client connections using Flower framework
2. Implements FedJSCM (Federated Joint Server-Client Momentum) aggregation
3. Integrates zk-SNARK proof generation for server-side verification
4. Manages dynamic proof rigor adjustment based on training stability
"""

import logging
import time
from collections.abc import Callable
from typing import Any
from typing import override

import numpy as np
from flwr.common import EvaluateIns
from flwr.common import EvaluateRes
from flwr.common import FitIns
from flwr.common import FitRes
from flwr.common import NDArrays
from flwr.common import Parameters
from flwr.common import Scalar
from flwr.server.client_proxy import ClientProxy
from flwr.server.strategy import Strategy

from secure_fl.utils.helpers import ndarrays_to_parameters
from secure_fl.utils.helpers import parameters_to_ndarrays
from secure_fl.zkp.proof_manager import ServerProofManager

from .aggregation import FedJSCMAggregator
from .stability_monitor import StabilityMonitor

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SecureFlowerStrategy(Strategy):
    """
    Custom Flower strategy implementing dual ZKP verification for federated learning
    """

    def __init__(
        self,
        initial_parameters: Parameters | None = None,
        momentum: float = 0.9,
        learning_rate: float = 0.01,
        min_available_clients: int = 2,
        min_fit_clients: int = 2,
        min_evaluate_clients: int = 2,
        fraction_fit: float = 1.0,
        fraction_evaluate: float = 1.0,
        enable_zkp: bool = True,
        proof_rigor: str = "high",  # "high", "medium", "low"
        blockchain_verification: bool = False,
    ):
        super().__init__()

        self.initial_parameters = initial_parameters
        self.min_available_clients = min_available_clients
        self.min_fit_clients = min_fit_clients
        self.min_evaluate_clients = min_evaluate_clients
        self.fraction_fit = fraction_fit
        self.fraction_evaluate = fraction_evaluate

        # FedJSCM components
        self.aggregator = FedJSCMAggregator(
            momentum=momentum, learning_rate=learning_rate
        )

        # ZKP components
        self.enable_zkp = enable_zkp
        self.proof_manager = ServerProofManager() if enable_zkp else None
        self.blockchain_verification = blockchain_verification

        # Dynamic proof adjustment
        self.stability_monitor = StabilityMonitor()
        self.proof_rigor = proof_rigor

        # Training state
        self.current_round = 0
        self.current_global_params: NDArrays | None = None
        self.training_metrics: list[dict[str, Scalar]] = []

        logger.info(f"Initialized SecureFlowerStrategy with ZKP={enable_zkp}")

    def initialize_parameters(self, client_manager: Any) -> Parameters | None:
        """Initialize global model parameters"""
        if self.initial_parameters:
            self.current_global_params = parameters_to_ndarrays(self.initial_parameters)
        return self.initial_parameters

    def configure_fit(
        self, server_round: int, parameters: Parameters, client_manager: Any
    ) -> list[tuple[ClientProxy, FitIns]]:
        """Configure clients for training round"""
        self.current_round = server_round

        # Sample clients
        sample_size = max(
            self.min_fit_clients, int(len(client_manager.all()) * self.fraction_fit)
        )
        clients = client_manager.sample(
            num_clients=sample_size, min_num_clients=self.min_available_clients
        )

        # Configure client instructions
        config: dict[str, Scalar] = {
            "server_round": server_round,
            "local_epochs": self._get_local_epochs(),
            "learning_rate": self.aggregator.learning_rate,
            "proof_rigor": self.proof_rigor,
            "enable_zkp": self.enable_zkp,
        }

        return [(client, FitIns(parameters, config)) for client in clients]

    def aggregate_fit(
        self,
        server_round: int,
        results: list[tuple[ClientProxy, FitRes]],
        failures: list[tuple[ClientProxy, FitRes] | BaseException],
    ) -> tuple[Parameters | None, dict[str, Scalar]]:
        """Aggregate client updates with ZKP verification"""

        if not results:
            logger.warning(f"No client results received in round {server_round}")
            if failures:
                logger.warning(f"Failures in round {server_round}: {failures}")
            return None, {}

        start_time = time.time()

        # Step 1: Verify client ZKPs if enabled
        verified_results = []
        if self.enable_zkp:
            for client, fit_res in results:
                if self._verify_client_proof(client, fit_res):
                    verified_results.append((client, fit_res))
                else:
                    cid = getattr(client, "cid", None) or getattr(
                        client, "client_id", "unknown"
                    )
                    logger.warning(f"Client {cid} failed ZKP verification")

            logger.info(
                f"Verified {len(verified_results)}/{len(results)} client proofs"
            )
        else:
            verified_results = results

        if not verified_results:
            logger.error("No verified client updates available")
            return None, {}

        # Step 2: Extract parameters and weights
        client_updates = []
        client_weights = []

        for _client, fit_res in verified_results:
            # Convert parameters to numpy arrays
            client_params = parameters_to_ndarrays(fit_res.parameters)
            client_updates.append(client_params)

            # Use number of examples as weight (can be modified)
            num_examples = fit_res.num_examples
            client_weights.append(num_examples)

        # Normalize weights
        total_examples = float(sum(client_weights))
        client_weights_float = [float(w) / total_examples for w in client_weights]

        # Step 3: FedJSCM Aggregation
        aggregated_params = self.aggregator.aggregate(
            client_updates=client_updates,
            client_weights=client_weights_float,
            server_round=server_round,
            global_params=self.current_global_params,
        )

        # Step 4: Generate server ZKP if enabled
        server_proof_time = 0.0
        if self.enable_zkp and self._should_generate_server_proof():
            proof_start = time.time()
            server_proof = self._generate_server_proof(
                client_updates=client_updates,
                client_weights=client_weights_float,
                aggregated_params=aggregated_params,
            )
            server_proof_time = time.time() - proof_start

            if self.blockchain_verification and server_proof:
                self._submit_to_blockchain(server_proof)

        # Update current global parameters only after proof generation,
        # so proof generation sees the true previous global state.
        self.current_global_params = list(aggregated_params)

        # Step 5: Update stability monitoring and proof rigor
        self._update_stability_metrics(aggregated_params)
        self._adjust_proof_rigor()

        # Prepare metrics
        aggregation_time = time.time() - start_time
        metrics: dict[str, Scalar] = {
            "aggregation_time": aggregation_time,
            "server_proof_time": server_proof_time,
            "verified_clients": len(verified_results),
            "total_clients": len(results),
            "momentum_norm": float(
                np.sqrt(
                    sum(np.sum(p**2) for p in self.aggregator.server_momentum)
                    if self.aggregator.server_momentum is not None
                    else 0.0
                )
            ),
            "proof_rigor": self.proof_rigor,
        }

        self.training_metrics.append(metrics)

        logger.info(
            f"Round {server_round}: Aggregated {len(verified_results)} clients, "
            f"time={aggregation_time:.2f}s, proof_time={server_proof_time:.2f}s"
        )

        return ndarrays_to_parameters(aggregated_params), metrics

    def configure_evaluate(
        self, server_round: int, parameters: Parameters, client_manager: Any
    ) -> list[tuple[ClientProxy, EvaluateIns]]:
        """Configure clients for evaluation"""
        if not self.fraction_evaluate:
            return []

        # Sample clients for evaluation
        sample_size = max(
            self.min_evaluate_clients,
            int(len(client_manager.all()) * self.fraction_evaluate),
        )
        clients = client_manager.sample(
            num_clients=sample_size, min_num_clients=self.min_available_clients
        )

        return [
            (client, EvaluateIns(parameters, {"server_round": str(server_round)}))
            for client in clients
        ]

    def aggregate_evaluate(
        self,
        server_round: int,
        results: list[tuple[ClientProxy, EvaluateRes]],
        failures: list[tuple[ClientProxy, EvaluateRes] | BaseException],
    ) -> tuple[float | None, dict[str, Scalar]]:
        """Aggregate evaluation results"""

        if not results:
            return None, {}

        # Aggregate metrics
        total_examples = sum([res.num_examples for _, res in results])

        # Weighted average of losses
        weighted_loss = (
            sum([res.loss * res.num_examples for _, res in results]) / total_examples
        )

        # Aggregate other metrics
        metrics: dict[str, Scalar] = {}
        metric_keys: set[str] = set()
        for _, res in results:
            if res.metrics:
                metric_keys.update(res.metrics.keys())

        for key in metric_keys:
            values = []
            for _, res in results:
                if res.metrics and key in res.metrics:
                    val = res.metrics[key]
                    if isinstance(val, (int, float, np.number)) and not isinstance(
                        val, bool
                    ):
                        values.append((val * res.num_examples, res.num_examples))

            if values:
                weighted_value = sum([v for v, w in values]) / sum(
                    [w for _, w in values]
                )
                metrics[f"avg_{key}"] = weighted_value

        metrics["total_examples"] = total_examples

        return float(weighted_loss), metrics

    @override
    def evaluate(
        self, server_round: int, parameters: Parameters
    ) -> tuple[float, dict[str, Scalar]] | None:
        """Evaluate the model on the server side."""
        # Return None to indicate no server-side evaluation is performed
        return None

    def _verify_client_proof(self, client: ClientProxy, fit_res: FitRes) -> bool:
        """Verify client's proof against the current global parameters."""
        client_id = getattr(client, "cid", None) or getattr(
            client, "client_id", "unknown"
        )
        if not self.proof_manager:
            return True

        # Extract proof from fit_res metrics
        client_proof = fit_res.metrics.get("zkp_proof")
        if not client_proof:
            logger.warning(f"No ZKP proof from client {client_id}")
            # If ZKP is enabled, treat missing proof as failure
            return not self.enable_zkp  # Allow if ZKP disabled

        if self.current_global_params is None:
            logger.error("No current_global_params available for proof verification")
            return not self.enable_zkp

        try:
            if not isinstance(client_proof, str):
                logger.warning(
                    f"Client {client_id} proof is not a string: {type(client_proof)}"
                )
                return not self.enable_zkp

            updated_params = parameters_to_ndarrays(fit_res.parameters)
            old_global_params = self.current_global_params
            ok = self.proof_manager.verify_client_proof(
                client_proof,
                updated_parameters=updated_params,
                old_global_params=old_global_params,
            )

            if not ok:
                logger.warning(f"Client {client_id} failed proof verification")
            return ok

        except Exception as e:
            logger.error(f"Error verifying proof for client {client_id}: {e}")
            return not self.enable_zkp

    def _generate_server_proof(
        self,
        client_updates: list[NDArrays],
        client_weights: list[float],
        aggregated_params: NDArrays,
    ) -> str | None:
        """Generate zk-SNARK proof for server aggregation"""
        if not self.proof_manager:
            return None

        try:
            return self.proof_manager.generate_server_proof(
                client_updates=client_updates,
                client_weights=client_weights,
                aggregated_params=aggregated_params,
                old_params=self.current_global_params
                if self.current_global_params is not None
                else [np.zeros_like(p) for p in aggregated_params],
                momentum=self.aggregator.server_momentum
                if self.aggregator.server_momentum is not None
                else [np.zeros_like(p) for p in aggregated_params],
                momentum_coeff=self.aggregator.momentum,
            )
        except Exception as e:
            logger.error(f"Failed to generate server proof: {e}")
            return None

    def _should_generate_server_proof(self) -> bool:
        """Determine if server proof should be generated based on rigor level"""
        if self.proof_rigor == "high":
            return True
        if self.proof_rigor == "medium":
            return self.current_round % 2 == 0
        if self.proof_rigor == "low":
            return self.current_round % 5 == 0
        return False

    def _submit_to_blockchain(self, proof: str) -> bool:
        """Submit proof to blockchain for verification"""
        # TODO: Implement blockchain submission
        logger.info("Submitting proof to blockchain (not implemented)")
        return True

    def _update_stability_metrics(self, params: NDArrays) -> None:
        """Update training stability metrics"""
        self.stability_monitor.update(params, self.current_round)

    def _adjust_proof_rigor(self) -> None:
        """Dynamically adjust proof rigor based on stability"""
        stability_score = self.stability_monitor.get_stability_score()

        if stability_score > 0.9:  # Very stable
            self.proof_rigor = "low"
        elif stability_score > 0.7:  # Moderately stable
            self.proof_rigor = "medium"
        else:  # Unstable
            self.proof_rigor = "high"

    def _get_local_epochs(self) -> int:
        """Get number of local epochs based on current rigor"""
        if self.proof_rigor == "high":
            return 1  # More frequent updates
        if self.proof_rigor == "medium":
            return 2
        return 3  # Fewer updates when stable


def create_server_strategy(
    model_fn: Callable[..., Any],
    momentum: float = 0.9,
    learning_rate: float = 0.01,
    enable_zkp: bool = True,
    proof_rigor: str = "high",
    **kwargs: Any,
) -> "SecureFlowerStrategy":
    from .server_runtime import create_server_strategy as _create_server_strategy

    return _create_server_strategy(
        model_fn=model_fn,
        momentum=momentum,
        learning_rate=learning_rate,
        enable_zkp=enable_zkp,
        proof_rigor=proof_rigor,
        **kwargs,
    )


class SecureFlowerServer:  # pragma: no cover - compatibility wrapper
    def __new__(cls, *args: Any, **kwargs: Any) -> Any:
        from .server_runtime import SecureFlowerServer as RuntimeServer

        return RuntimeServer(*args, **kwargs)
