"""Client factory and runtime helpers."""

import logging
import socket
from collections.abc import Callable
from typing import Any

import flwr as fl
from torch.utils.data import DataLoader

from .client import SecureFlowerClient

logger = logging.getLogger(__name__)


def create_client(
    client_id: str,
    model_fn: Callable[..., Any],
    train_data: Any,
    val_data: Any = None,
    batch_size: int = 32,
    **kwargs: Any,
) -> SecureFlowerClient:
    train_loader = DataLoader(
        train_data, batch_size=batch_size, shuffle=True, drop_last=True
    )

    val_loader = None
    if val_data is not None:
        val_loader = DataLoader(val_data, batch_size=batch_size, shuffle=False)

    model = model_fn()

    supported_params = {
        "device",
        "enable_zkp",
        "proof_rigor",
        "quantize_weights",
        "local_epochs",
        "learning_rate",
    }
    filtered_kwargs = {k: v for k, v in kwargs.items() if k in supported_params}

    return SecureFlowerClient(
        client_id=client_id,
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        **filtered_kwargs,
    )


def start_client(
    client: SecureFlowerClient, server_address: str = "localhost:8080"
) -> None:
    logger.info("🚀 Starting client %s", client.client_id)
    logger.info("Target server: %s", server_address)

    if ":" not in server_address:
        raise ValueError(
            f"Invalid server address format: {server_address}. Expected 'host:port'"
        )

    try:
        host, port_str = server_address.split(":", 1)
        port = int(port_str)
        if not (1 <= port <= 65535):
            raise ValueError(f"Invalid port: {port}")

        logger.info("Testing connection to %s:%s...", host, port)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(10)
            result = sock.connect_ex((host, port))

        if result != 0:
            logger.error("❌ Cannot reach server at %s", server_address)
            raise ConnectionError(f"Server at {server_address} is not reachable")

        logger.info("✓ Connection test successful")
        fl.client.start_numpy_client(
            server_address=server_address,
            client=client,
            grpc_max_message_length=1024 * 1024 * 1024,
        )
        logger.info("✓ Client %s finished successfully", client.client_id)

    except Exception as e:
        logger.error(
            "❌ Client %s failed: %s: %s", client.client_id, type(e).__name__, e
        )
        raise
