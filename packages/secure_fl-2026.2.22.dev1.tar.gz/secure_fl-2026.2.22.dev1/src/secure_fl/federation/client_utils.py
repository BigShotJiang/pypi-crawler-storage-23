"""Utility helpers for SecureFlowerClient training and metrics."""

from collections.abc import Sized
from typing import cast

import numpy as np
import torch
import torch.nn as nn
from flwr.common import NDArrays
from torch.utils.data import DataLoader


def prepare_training_traces(
    proof_rigor: str, batch_losses: list[float], gradient_norms: list[float]
) -> tuple[list[float], list[float]]:
    max_points = max_trace_points_for_rigor(proof_rigor)
    return (
        downsample_trace(batch_losses, max_points),
        downsample_trace(gradient_norms, max_points),
    )


def max_trace_points_for_rigor(proof_rigor: str) -> int:
    if proof_rigor == "high":
        return 2000
    if proof_rigor == "medium":
        return 500
    return 100


def downsample_trace(values: list[float], max_points: int) -> list[float]:
    if len(values) <= max_points:
        return values
    indices = np.linspace(0, len(values) - 1, num=max_points, dtype=int)
    return [values[i] for i in indices]


def evaluate_model(
    model: nn.Module, data_loader: DataLoader, device: str
) -> tuple[float, float]:
    model.eval()
    criterion = nn.CrossEntropyLoss()

    total_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        for data, target in data_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)

            loss = criterion(output, target)
            total_loss += loss.item() * data.size(0)

            pred = output.argmax(dim=1)
            correct += pred.eq(target).sum().item()
            total += data.size(0)

    avg_loss = total_loss / total if total > 0 else 0.0
    accuracy = correct / total if total > 0 else 0.0

    return avg_loss, accuracy


def compute_training_accuracy(
    model: nn.Module, train_loader: DataLoader, device: str
) -> float:
    dataset = train_loader.dataset
    dataset_size = len(cast("Sized", dataset)) if isinstance(dataset, Sized) else 0
    if dataset_size > 1000:
        subset_size = min(500, dataset_size // 4)
        indices = torch.randperm(dataset_size)[:subset_size]
        subset = torch.utils.data.Subset(dataset, indices.tolist())
        subset_loader = DataLoader(subset, batch_size=64)
        _, accuracy = evaluate_model(model, subset_loader, device)
        return accuracy
    _, accuracy = evaluate_model(model, train_loader, device)
    return accuracy


def compute_parameter_delta(
    initial_params: NDArrays, updated_params: NDArrays
) -> NDArrays:
    delta = []
    for init_p, updated_p in zip(initial_params, updated_params, strict=False):
        delta.append(updated_p - init_p)
    return delta


def compute_gradient_norm(model: nn.Module) -> float:
    total_norm = 0.0
    for param in model.parameters():
        if param.grad is not None:
            param_norm = param.grad.data.norm(2)
            total_norm += param_norm.item() ** 2
    return total_norm**0.5  # type: ignore[no-any-return]


def compute_data_commitment(train_loader: DataLoader) -> str:
    if not hasattr(train_loader.dataset, "__len__"):
        return "unknown_dataset"

    dataset_size = len(train_loader.dataset)
    sample_data: list[float] = []
    sample_count = min(10, dataset_size)

    for i, (data, _target) in enumerate(train_loader):
        if i >= sample_count:
            break
        sample_data.extend(data.flatten().numpy()[:100])

    if sample_data:
        data_mean = np.mean(sample_data)
        data_std = np.std(sample_data)
        return f"size_{dataset_size}_mean_{data_mean:.4f}_std_{data_std:.4f}"
    return f"size_{dataset_size}_empty"
