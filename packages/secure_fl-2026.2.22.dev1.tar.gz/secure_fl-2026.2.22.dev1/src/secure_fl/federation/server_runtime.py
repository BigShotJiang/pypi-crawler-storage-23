"""Server runtime and factory helpers."""

import logging
from collections.abc import Callable
from typing import Any

import flwr as fl

from secure_fl.utils.helpers import ndarrays_to_parameters

from .server import SecureFlowerStrategy

logger = logging.getLogger(__name__)


class SecureFlowerServer:
    """Main server class that orchestrates the entire FL process."""

    def __init__(
        self,
        strategy: SecureFlowerStrategy,
        host: str = "localhost",
        port: int = 8080,
        num_rounds: int = 10,
        config: dict | None = None,
    ):
        self.strategy = strategy
        self.host = host
        self.port = port
        self.num_rounds = num_rounds
        self.config = config or {}

        logger.info("SecureFlowerServer initialized on %s:%s", host, port)

    def start(self) -> Any:
        logger.info(
            "Starting secure FL server on %s:%s for %s rounds",
            self.host,
            self.port,
            self.num_rounds,
        )

        if not (1 <= self.port <= 65535):
            raise ValueError(f"Invalid port number: {self.port}")

        config = fl.server.ServerConfig(num_rounds=self.num_rounds, round_timeout=300.0)
        server_address = f"{self.host}:{self.port}"
        logger.info("Listening on: %s", server_address)

        try:
            history = fl.server.start_server(
                server_address=server_address,
                config=config,
                strategy=self.strategy,
                grpc_max_message_length=1024 * 1024 * 1024,
            )

            logger.info("✓ FL training completed successfully")
            return history

        except Exception as e:
            logger.error("❌ Server failed: %s: %s", type(e).__name__, e)
            if "Address already in use" in str(e):
                logger.error("Port %s is busy. Try another one.", self.port)
            raise

    def get_training_history(self) -> list[dict]:
        return self.strategy.training_metrics


def create_server_strategy(
    model_fn: Callable[..., Any],
    momentum: float = 0.9,
    learning_rate: float = 0.01,
    enable_zkp: bool = True,
    proof_rigor: str = "high",
    **kwargs: Any,
) -> SecureFlowerStrategy:
    model = model_fn()
    initial_params = [param.detach().cpu().numpy() for param in model.parameters()]
    initial_parameters = ndarrays_to_parameters(initial_params)

    valid_kwargs = {
        k: v
        for k, v in kwargs.items()
        if k
        in {
            "min_available_clients",
            "min_fit_clients",
            "min_evaluate_clients",
            "fraction_fit",
            "fraction_evaluate",
            "blockchain_verification",
        }
    }

    return SecureFlowerStrategy(
        initial_parameters=initial_parameters,
        momentum=momentum,
        learning_rate=learning_rate,
        enable_zkp=enable_zkp,
        proof_rigor=proof_rigor,
        **valid_kwargs,
    )
