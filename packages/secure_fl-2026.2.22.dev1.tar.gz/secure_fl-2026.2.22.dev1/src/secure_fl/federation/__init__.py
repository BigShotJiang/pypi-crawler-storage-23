"""
Federation module for Secure FL.

This module contains the core federated learning components including
clients, servers, aggregation algorithms, and stability monitoring.
The federation module implements the FedJSCM (Federated Joint Server-Client Momentum)
algorithm with zero-knowledge proof integration.
"""

from .aggregation import FedJSCMAggregator
from .client import SecureFlowerClient
from .client_runtime import create_client
from .client_runtime import start_client
from .server import SecureFlowerServer
from .server import SecureFlowerStrategy
from .server import create_server_strategy
from .stability_monitor import StabilityMetrics
from .stability_monitor import StabilityMonitor

__all__ = [
    # Core FL components
    "SecureFlowerServer",
    "SecureFlowerStrategy",
    "SecureFlowerClient",
    "create_server_strategy",
    "create_client",
    "start_client",
    # Aggregation
    "FedJSCMAggregator",
    # Stability monitoring
    "StabilityMonitor",
    "StabilityMetrics",
]
