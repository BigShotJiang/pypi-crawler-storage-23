"""
Core module for Secure FL.

This module contains the fundamental components and utilities that form
the foundation of the Secure FL framework, including types, exceptions,
configuration, and version information.
"""

from ._version import __version__
from ._version import get_build_info
from ._version import print_version_info
from .config import ConfigManager
from .config import SecureFlConfig
from .config import create_example_config
from .config import get_client_config
from .config import get_default_config
from .config import get_server_config
from .config import get_zkp_config
from .config import load_config
from .config import save_config
from .exceptions import AggregationError
from .exceptions import CircuitCompilationError
from .exceptions import ClientError
from .exceptions import ConfigurationError  # Specific exceptions
from .exceptions import DataError
from .exceptions import ModelError
from .exceptions import NetworkError
from .exceptions import ProofError
from .exceptions import ProofGenerationError
from .exceptions import ProofVerificationError
from .exceptions import QuantizationError
from .exceptions import SecureFlError  # Base exceptions
from .exceptions import ServerError
from .exceptions import ValidationError
from .exceptions import handle_error  # Error handling utilities
from .exceptions import safe_execute
from .exceptions import validate_client_id
from .exceptions import validate_positive_int  # Validation utilities
from .exceptions import validate_proof_rigor
from .exceptions import validate_range
from .exceptions import wrap_error
from .types import DEFAULT_CLIENT_CONFIG  # Default configurations
from .types import DEFAULT_SERVER_CONFIG
from .types import DEFAULT_ZKP_CONFIG
from .types import AggregationResult
from .types import BaseAggregator
from .types import BaseProofManager  # Base classes
from .types import ClientConfig  # Configuration classes
from .types import ClientID  # Core types
from .types import ComponentStatus
from .types import Metrics
from .types import ModelFunction
from .types import ModelParameters
from .types import ProofData
from .types import ProofID
from .types import ProofMetrics
from .types import ProofResult
from .types import ProofRigor  # Enums
from .types import QuantizationBits
from .types import RoundID
from .types import ServerConfig
from .types import SystemMetrics
from .types import TrainingMetrics  # Metrics classes
from .types import TrainingPhase
from .types import TrainingResult  # Result classes
from .types import ValidationResult
from .types import ZKPConfig
from .types import ensure_model_parameters
from .types import is_valid_client_id  # Utilities
from .types import is_valid_proof_rigor
from .types import is_valid_round_id

__all__ = [
    # Version information
    "__version__",
    "get_build_info",
    "print_version_info",
    # Configuration
    "SecureFlConfig",
    "ConfigManager",
    "get_default_config",
    "load_config",
    "save_config",
    "get_server_config",
    "get_client_config",
    "get_zkp_config",
    "create_example_config",
    # Exceptions
    "SecureFlError",
    "ConfigurationError",
    "ClientError",
    "ServerError",
    "ProofError",
    "CircuitCompilationError",
    "ProofGenerationError",
    "ProofVerificationError",
    "AggregationError",
    "QuantizationError",
    "DataError",
    "NetworkError",
    "ValidationError",
    "ModelError",
    "handle_error",
    "wrap_error",
    "safe_execute",
    "validate_positive_int",
    "validate_range",
    "validate_client_id",
    "validate_proof_rigor",
    # Types
    "ClientID",
    "RoundID",
    "ProofID",
    "ModelFunction",
    "ModelParameters",
    "ProofData",
    "Metrics",
    "ProofRigor",
    "QuantizationBits",
    "TrainingPhase",
    "ComponentStatus",
    "ClientConfig",
    "ServerConfig",
    "ZKPConfig",
    "TrainingMetrics",
    "ProofMetrics",
    "SystemMetrics",
    "TrainingResult",
    "ProofResult",
    "AggregationResult",
    "ValidationResult",
    "BaseProofManager",
    "BaseAggregator",
    "DEFAULT_CLIENT_CONFIG",
    "DEFAULT_SERVER_CONFIG",
    "DEFAULT_ZKP_CONFIG",
    "is_valid_client_id",
    "is_valid_round_id",
    "is_valid_proof_rigor",
    "ensure_model_parameters",
]
