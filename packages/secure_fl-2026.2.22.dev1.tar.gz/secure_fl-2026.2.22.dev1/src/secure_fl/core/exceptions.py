"""
Exception handling and custom errors for Secure FL.

This module provides custom exception classes and error handling utilities
to improve maintainability and debugging across the Secure FL framework.
"""

from __future__ import annotations

import logging
import traceback
from typing import TYPE_CHECKING
from typing import Any

if TYPE_CHECKING:
    from collections.abc import Callable


class SecureFlError(Exception):
    """Base exception class for all Secure FL errors."""

    def __init__(
        self,
        message: str,
        error_code: str | None = None,
        details: dict[str, Any] | None = None,
        cause: Exception | None = None,
    ) -> None:
        """
        Initialize SecureFL error.

        Args:
            message: Human-readable error message
            error_code: Machine-readable error code
            details: Additional error details
            cause: Original exception that caused this error
        """
        super().__init__(message)
        self.message = message
        self.error_code = error_code or self.__class__.__name__
        self.details = details or {}
        self.cause = cause

    def to_dict(self) -> dict[str, Any]:
        """Convert error to dictionary for serialization."""
        return {
            "error_type": self.__class__.__name__,
            "error_code": self.error_code,
            "message": self.message,
            "details": self.details,
            "traceback": traceback.format_exc() if self.cause else None,
        }

    def __str__(self) -> str:
        """String representation of error."""
        result = f"{self.error_code}: {self.message}"
        if self.details:
            details_str = ", ".join(f"{k}={v}" for k, v in self.details.items())
            result += f" ({details_str})"
        return result


class ConfigurationError(SecureFlError):
    """Raised when there's an error in configuration."""

    def __init__(
        self,
        message: str,
        config_key: str | None = None,
        config_value: Any | None = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.get("details", {})
        if config_key:
            details["config_key"] = config_key
        if config_value is not None:
            details["config_value"] = str(config_value)
        kwargs["details"] = details
        super().__init__(message, **kwargs)


class ClientError(SecureFlError):
    """Raised when there's an error in client operations."""

    def __init__(
        self,
        message: str,
        client_id: str | None = None,
        round_id: int | None = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.get("details", {})
        if client_id:
            details["client_id"] = client_id
        if round_id is not None:
            details["round_id"] = round_id
        kwargs["details"] = details
        super().__init__(message, **kwargs)


class ServerError(SecureFlError):
    """Raised when there's an error in server operations."""

    def __init__(
        self,
        message: str,
        round_id: int | None = None,
        num_clients: int | None = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.get("details", {})
        if round_id is not None:
            details["round_id"] = round_id
        if num_clients is not None:
            details["num_clients"] = num_clients
        kwargs["details"] = details
        super().__init__(message, **kwargs)


class ProofError(SecureFlError):
    """Raised when there's an error in ZKP operations."""

    def __init__(
        self,
        message: str,
        proof_type: str | None = None,
        proof_id: str | None = None,
        circuit_name: str | None = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.get("details", {})
        if proof_type:
            details["proof_type"] = proof_type
        if proof_id:
            details["proof_id"] = proof_id
        if circuit_name:
            details["circuit_name"] = circuit_name
        kwargs["details"] = details
        super().__init__(message, **kwargs)


class CircuitCompilationError(ProofError):
    """Raised when ZKP circuit compilation fails."""

    def __init__(
        self,
        message: str,
        circuit_file: str | None = None,
        compiler_output: str | None = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.get("details", {})
        if circuit_file:
            details["circuit_file"] = circuit_file
        if compiler_output:
            details["compiler_output"] = compiler_output[:1000]  # Truncate long output
        kwargs["details"] = details
        super().__init__(message, **kwargs)


class ProofGenerationError(ProofError):
    """Raised when proof generation fails."""

    def __init__(
        self,
        message: str,
        inputs_size: int | None = None,
        generation_time: float | None = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.get("details", {})
        if inputs_size is not None:
            details["inputs_size"] = inputs_size
        if generation_time is not None:
            details["generation_time"] = generation_time
        kwargs["details"] = details
        super().__init__(message, **kwargs)


class ProofVerificationError(ProofError):
    """Raised when proof verification fails."""

    def __init__(
        self,
        message: str,
        proof_size: int | None = None,
        verification_time: float | None = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.get("details", {})
        if proof_size is not None:
            details["proof_size"] = proof_size
        if verification_time is not None:
            details["verification_time"] = verification_time
        kwargs["details"] = details
        super().__init__(message, **kwargs)


class AggregationError(SecureFlError):
    """Raised when parameter aggregation fails."""

    def __init__(
        self,
        message: str,
        num_clients: int | None = None,
        parameter_shapes: list | None = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.get("details", {})
        if num_clients is not None:
            details["num_clients"] = num_clients
        if parameter_shapes:
            details["parameter_shapes"] = str(parameter_shapes)
        kwargs["details"] = details
        super().__init__(message, **kwargs)


class QuantizationError(SecureFlError):
    """Raised when parameter quantization fails."""

    def __init__(
        self,
        message: str,
        quantization_bits: int | None = None,
        parameter_range: tuple | None = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.get("details", {})
        if quantization_bits is not None:
            details["quantization_bits"] = quantization_bits
        if parameter_range:
            details["parameter_range"] = str(parameter_range)
        kwargs["details"] = details
        super().__init__(message, **kwargs)


class DataError(SecureFlError):
    """Raised when there's an error with data handling."""

    def __init__(
        self,
        message: str,
        dataset_name: str | None = None,
        data_size: int | None = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.get("details", {})
        if dataset_name:
            details["dataset_name"] = dataset_name
        if data_size is not None:
            details["data_size"] = data_size
        kwargs["details"] = details
        super().__init__(message, **kwargs)


class NetworkError(SecureFlError):
    """Raised when there's a network communication error."""

    def __init__(
        self,
        message: str,
        server_address: str | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.get("details", {})
        if server_address:
            details["server_address"] = server_address
        if timeout is not None:
            details["timeout"] = timeout
        kwargs["details"] = details
        super().__init__(message, **kwargs)


class ValidationError(SecureFlError):
    """Raised when validation fails."""

    def __init__(
        self,
        message: str,
        field_name: str | None = None,
        field_value: Any | None = None,
        expected_type: str | None = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.get("details", {})
        if field_name:
            details["field_name"] = field_name
        if field_value is not None:
            details["field_value"] = str(field_value)
        if expected_type:
            details["expected_type"] = expected_type
        kwargs["details"] = details
        super().__init__(message, **kwargs)


class ModelError(SecureFlError):
    """Raised when there's an error with model operations."""

    def __init__(
        self,
        message: str,
        model_type: str | None = None,
        parameter_count: int | None = None,
        **kwargs: Any,
    ) -> None:
        details = kwargs.get("details", {})
        if model_type:
            details["model_type"] = model_type
        if parameter_count is not None:
            details["parameter_count"] = parameter_count
        kwargs["details"] = details
        super().__init__(message, **kwargs)


# Error handling utilities


def handle_error(
    error: Exception,
    logger: logging.Logger | None = None,
    reraise: bool = True,
    extra_context: dict[str, Any] | None = None,
) -> None:
    """
    Handle and log errors with context.

    Args:
        error: Exception to handle
        logger: Logger to use (creates default if None)
        reraise: Whether to reraise the exception
        extra_context: Additional context to log
    """
    if logger is None:
        logger = logging.getLogger(__name__)

    # Create context for logging
    context = {
        "error_type": type(error).__name__,
        "error_message": str(error),
    }

    if isinstance(error, SecureFlError):
        context.update(error.details)

    if extra_context:
        context.update(extra_context)

    # Log the error with context
    logger.error(
        f"Error occurred: {type(error).__name__}: {str(error)}",
        extra={"context": context},
        exc_info=True,
    )

    if reraise:
        raise


def wrap_error(
    error: Exception,
    error_class: type[SecureFlError] = SecureFlError,
    message: str | None = None,
    **kwargs: Any,
) -> SecureFlError:
    """
    Wrap an exception in a SecureFL error.

    Args:
        error: Original exception
        error_class: SecureFL error class to use
        message: Custom message (uses original if None)
        **kwargs: Additional arguments for error class

    Returns:
        Wrapped SecureFL error
    """
    if isinstance(error, SecureFlError):
        return error

    error_message = message or str(error)
    return error_class(
        error_message,
        cause=error,
        **kwargs,
    )


def safe_execute(
    func: Callable[..., Any],
    *args: Any,
    error_class: type[SecureFlError] = SecureFlError,
    logger: logging.Logger | None = None,
    **kwargs: Any,
) -> Any:
    """
    Safely execute a function with error handling.

    Args:
        func: Function to execute
        *args: Arguments for the function
        error_class: Error class to wrap exceptions in
        logger: Logger for error reporting
        **kwargs: Keyword arguments for the function

    Returns:
        Function result

    Raises:
        SecureFlError: Wrapped version of any exception that occurs
    """
    try:
        return func(*args, **kwargs)
    except Exception as e:
        wrapped_error = wrap_error(e, error_class)
        handle_error(wrapped_error, logger, reraise=True)


# Validation utilities


def validate_positive_int(value: Any, name: str) -> int:
    """Validate that a value is a positive integer."""
    if not isinstance(value, int) or value <= 0:
        raise ValidationError(
            f"{name} must be a positive integer",
            field_name=name,
            field_value=value,
            expected_type="positive int",
        )
    return value


def validate_range(value: Any, name: str, min_val: float, max_val: float) -> float:
    """Validate that a value is within a specified range."""
    if not isinstance(value, (int, float)):
        raise ValidationError(
            f"{name} must be a number",
            field_name=name,
            field_value=value,
            expected_type="number",
        )

    if not (min_val <= value <= max_val):
        raise ValidationError(
            f"{name} must be between {min_val} and {max_val}",
            field_name=name,
            field_value=value,
            details={"min_value": min_val, "max_value": max_val},
        )

    return float(value)


def validate_client_id(client_id: Any) -> str:
    """Validate client ID format."""
    if not isinstance(client_id, str) or not client_id.strip():
        raise ValidationError(
            "Client ID must be a non-empty string",
            field_name="client_id",
            field_value=client_id,
            expected_type="non-empty string",
        )
    return client_id.strip()


def validate_proof_rigor(proof_rigor: Any) -> str:
    """Validate proof rigor value."""
    valid_values = {"low", "medium", "high", "adaptive"}

    if not isinstance(proof_rigor, str) or proof_rigor not in valid_values:
        raise ValidationError(
            f"Proof rigor must be one of {valid_values}",
            field_name="proof_rigor",
            field_value=proof_rigor,
            details={"valid_values": list(valid_values)},
        )

    return proof_rigor


# Export all public classes and functions
__all__ = [
    # Base exceptions
    "SecureFlError",
    # Specific exceptions
    "ConfigurationError",
    "ClientError",
    "ServerError",
    "ProofError",
    "CircuitCompilationError",
    "ProofGenerationError",
    "ProofVerificationError",
    "AggregationError",
    "QuantizationError",
    "DataError",
    "NetworkError",
    "ValidationError",
    "ModelError",
    # Error handling utilities
    "handle_error",
    "wrap_error",
    "safe_execute",
    # Validation utilities
    "validate_positive_int",
    "validate_range",
    "validate_client_id",
    "validate_proof_rigor",
]
