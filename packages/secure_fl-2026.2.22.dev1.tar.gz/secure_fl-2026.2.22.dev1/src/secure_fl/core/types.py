"""
Type definitions and interfaces for Secure FL.

This module provides type definitions, protocols, and interfaces to improve
code maintainability and type safety across the Secure FL framework.
"""

from __future__ import annotations

import logging
from abc import ABC
from abc import abstractmethod
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from enum import StrEnum
from enum import auto
from typing import Any
from typing import Protocol
from typing import TypeVar

import numpy as np
import torch
from flwr.common import NDArrays
from flwr.common import Parameters
from flwr.common import Scalar

__all__ = [
    # Core types
    "ModelFunction",
    "DataLoader",
    "ClientID",
    "RoundID",
    "ProofID",
    "ModelParameters",
    "ProofData",
    "Metrics",
    # Enums
    "ProofRigor",
    "QuantizationBits",
    "TrainingPhase",
    "ComponentStatus",
    # Data classes
    "ClientConfig",
    "ServerConfig",
    "ZKPConfig",
    "TrainingMetrics",
    "ProofMetrics",
    "SystemMetrics",
    # Protocols
    "ProofManager",
    "Aggregator",
    "Quantizer",
    "StabilityMonitor",
    "DataProvider",
    # Result types
    "TrainingResult",
    "ProofResult",
    "AggregationResult",
    "ValidationResult",
]

# ============================================================================
# Core Type Aliases
# ============================================================================

ModelFunction = Callable[[], torch.nn.Module]
DataLoader = torch.utils.data.DataLoader
ClientID = str
RoundID = int
ProofID = str
ModelParameters = NDArrays
ProofData = bytes
Metrics = dict[str, Scalar]

# Type variables for generic protocols
T = TypeVar("T")
P = TypeVar("P", bound="Parameters")
M = TypeVar("M", bound=torch.nn.Module)

# ============================================================================
# Enums
# ============================================================================


class ProofRigor(StrEnum):
    """Proof complexity levels for ZKP generation."""

    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    ADAPTIVE = "adaptive"


class QuantizationBits(int, Enum):
    """Standard quantization bit widths for ZKP compatibility."""

    INT4 = 4
    INT8 = 8
    INT16 = 16
    INT32 = 32


class TrainingPhase(Enum):
    """Training phases in federated learning."""

    INITIALIZATION = auto()
    TRAINING = auto()
    EVALUATION = auto()
    AGGREGATION = auto()
    VALIDATION = auto()
    COMPLETED = auto()


class ComponentStatus(Enum):
    """Status of system components."""

    OFFLINE = auto()
    INITIALIZING = auto()
    READY = auto()
    ACTIVE = auto()
    ERROR = auto()
    MAINTENANCE = auto()


# ============================================================================
# Configuration Data Classes
# ============================================================================


@dataclass(frozen=True)
class ClientConfig:
    """Configuration for FL clients."""

    client_id: ClientID
    local_epochs: int = 1
    learning_rate: float = 0.01
    batch_size: int = 32
    enable_zkp: bool = True
    proof_rigor: ProofRigor = ProofRigor.HIGH
    quantize_weights: bool = True
    quantization_bits: QuantizationBits = QuantizationBits.INT8
    device: str = "cpu"
    max_retries: int = 3
    timeout: int = 300

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "client_id": self.client_id,
            "local_epochs": self.local_epochs,
            "learning_rate": self.learning_rate,
            "batch_size": self.batch_size,
            "enable_zkp": self.enable_zkp,
            "proof_rigor": self.proof_rigor.value,
            "quantize_weights": self.quantize_weights,
            "quantization_bits": self.quantization_bits.value,
            "device": self.device,
            "max_retries": self.max_retries,
            "timeout": self.timeout,
        }


@dataclass(frozen=True)
class ServerConfig:
    """Configuration for FL server."""

    host: str = "localhost"
    port: int = 8080
    num_rounds: int = 10
    min_fit_clients: int = 2
    min_evaluate_clients: int = 2
    fraction_fit: float = 1.0
    fraction_evaluate: float = 1.0
    momentum: float = 0.9
    learning_rate: float = 0.01
    enable_zkp: bool = True
    proof_rigor: ProofRigor = ProofRigor.HIGH

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "host": self.host,
            "port": self.port,
            "num_rounds": self.num_rounds,
            "min_fit_clients": self.min_fit_clients,
            "min_evaluate_clients": self.min_evaluate_clients,
            "fraction_fit": self.fraction_fit,
            "fraction_evaluate": self.fraction_evaluate,
            "momentum": self.momentum,
            "learning_rate": self.learning_rate,
            "enable_zkp": self.enable_zkp,
            "proof_rigor": self.proof_rigor.value,
        }


@dataclass(frozen=True)
class ZKPConfig:
    """Configuration for zero-knowledge proofs."""

    enable_client_proofs: bool = True
    enable_server_proofs: bool = True
    proof_rigor: ProofRigor = ProofRigor.HIGH
    quantization_bits: QuantizationBits = QuantizationBits.INT8
    max_trace_length: int = 1024
    circuit_size: int = 1000
    proof_timeout: int = 120
    verification_timeout: int = 30
    circuit_cache_size: int = 100
    proof_cache_size: int = 1000

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "enable_client_proofs": self.enable_client_proofs,
            "enable_server_proofs": self.enable_server_proofs,
            "proof_rigor": self.proof_rigor.value,
            "quantization_bits": self.quantization_bits.value,
            "max_trace_length": self.max_trace_length,
            "circuit_size": self.circuit_size,
            "proof_timeout": self.proof_timeout,
            "verification_timeout": self.verification_timeout,
            "circuit_cache_size": self.circuit_cache_size,
            "proof_cache_size": self.proof_cache_size,
        }


# ============================================================================
# Metrics Data Classes
# ============================================================================


@dataclass
class TrainingMetrics:
    """Metrics collected during training."""

    round_id: RoundID
    client_id: ClientID | None = None
    loss: float = 0.0
    accuracy: float = 0.0
    num_samples: int = 0
    training_time: float = 0.0
    convergence_rate: float = 0.0
    gradient_norm: float = 0.0
    parameter_norm: float = 0.0
    custom_metrics: dict[str, float] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        result: dict[str, Any] = {
            "round_id": self.round_id,
            "loss": self.loss,
            "accuracy": self.accuracy,
            "num_samples": self.num_samples,
            "training_time": self.training_time,
            "convergence_rate": self.convergence_rate,
            "gradient_norm": self.gradient_norm,
            "parameter_norm": self.parameter_norm,
        }

        if self.client_id is not None:
            result["client_id"] = self.client_id

        if self.custom_metrics:
            result.update(self.custom_metrics)

        return result


@dataclass
class ProofMetrics:
    """Metrics for ZKP generation and verification."""

    proof_id: ProofID
    client_id: ClientID | None = None
    proof_type: str = "unknown"
    generation_time: float = 0.0
    verification_time: float = 0.0
    proof_size: int = 0
    circuit_constraints: int = 0
    memory_usage: float = 0.0
    success: bool = False
    error_message: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        result = {
            "proof_id": self.proof_id,
            "proof_type": self.proof_type,
            "generation_time": self.generation_time,
            "verification_time": self.verification_time,
            "proof_size": self.proof_size,
            "circuit_constraints": self.circuit_constraints,
            "memory_usage": self.memory_usage,
            "success": self.success,
        }

        if self.client_id is not None:
            result["client_id"] = self.client_id

        if self.error_message is not None:
            result["error_message"] = self.error_message

        return result


@dataclass
class SystemMetrics:
    """System resource metrics."""

    timestamp: float
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    disk_usage: float = 0.0
    network_io: tuple[float, float] = (0.0, 0.0)
    gpu_usage: float | None = None
    gpu_memory: float | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        result = {
            "timestamp": self.timestamp,
            "cpu_usage": self.cpu_usage,
            "memory_usage": self.memory_usage,
            "disk_usage": self.disk_usage,
            "network_io_bytes_sent": self.network_io[0],
            "network_io_bytes_recv": self.network_io[1],
        }

        if self.gpu_usage is not None:
            result["gpu_usage"] = self.gpu_usage

        if self.gpu_memory is not None:
            result["gpu_memory"] = self.gpu_memory

        return result


# ============================================================================
# Result Data Classes
# ============================================================================


@dataclass
class TrainingResult:
    """Result of training operation."""

    parameters: ModelParameters
    metrics: TrainingMetrics
    num_examples: int
    success: bool = True
    error_message: str | None = None

    def is_valid(self) -> bool:
        """Check if result is valid."""
        return self.success and len(self.parameters) > 0 and self.num_examples > 0


@dataclass
class ProofResult:
    """Result of proof generation or verification."""

    proof_id: ProofID
    proof_data: ProofData | None = None
    verification_key: bytes | None = None
    metrics: ProofMetrics | None = None
    success: bool = False
    error_message: str | None = None

    def is_valid(self) -> bool:
        """Check if proof result is valid."""
        return self.success and self.proof_data is not None


@dataclass
class AggregationResult:
    """Result of parameter aggregation."""

    aggregated_parameters: ModelParameters
    weights: list[float]
    metrics: dict[str, float]
    proof_result: ProofResult | None = None
    success: bool = True
    error_message: str | None = None

    def is_valid(self) -> bool:
        """Check if aggregation result is valid."""
        return (
            self.success
            and len(self.aggregated_parameters) > 0
            and len(self.weights) > 0
        )


@dataclass
class ValidationResult:
    """Result of model validation."""

    loss: float
    accuracy: float
    metrics: dict[str, float]
    num_examples: int
    success: bool = True
    error_message: str | None = None

    def is_valid(self) -> bool:
        """Check if validation result is valid."""
        return self.success and self.num_examples > 0


# ============================================================================
# Protocol Definitions (Interfaces)
# ============================================================================


class ProofManager(Protocol):
    """Interface for proof managers."""

    def setup(self) -> bool:
        """Setup circuits and proving keys."""
        ...

    def generate_proof(self, inputs: dict[str, Any]) -> ProofResult | None:
        """Generate a proof for given inputs."""
        ...

    def verify_proof(
        self, proof_data: ProofData, public_inputs: dict[str, Any]
    ) -> bool:
        """Verify a proof."""
        ...

    def get_metrics(self) -> dict[str, float]:
        """Get proof manager metrics."""
        ...


class Aggregator(Protocol):
    """Interface for parameter aggregators."""

    def aggregate(
        self, results: list[tuple[ModelParameters, int]]
    ) -> AggregationResult:
        """Aggregate parameters from multiple clients."""
        ...

    def get_weights(self, num_examples: list[int]) -> list[float]:
        """Calculate aggregation weights."""
        ...


class Quantizer(Protocol):
    """Interface for parameter quantizers."""

    def quantize(self, parameters: ModelParameters) -> ModelParameters:
        """Quantize parameters."""
        ...

    def dequantize(self, parameters: ModelParameters) -> ModelParameters:
        """Dequantize parameters."""
        ...

    def get_quantization_error(
        self, original: ModelParameters, quantized: ModelParameters
    ) -> float:
        """Calculate quantization error."""
        ...


class StabilityMonitor(Protocol):
    """Interface for training stability monitoring."""

    def update(
        self,
        parameters: ModelParameters,
        round_id: RoundID,
        metrics: dict[str, float] | None = None,
    ) -> None:
        """Update stability metrics."""
        ...

    def get_stability_score(self) -> float:
        """Get current stability score."""
        ...

    def recommend_proof_rigor(self) -> ProofRigor:
        """Recommend proof rigor based on stability."""
        ...


class DataProvider(Protocol):
    """Interface for data providers."""

    def get_train_loader(self, client_id: ClientID) -> DataLoader:
        """Get training data loader for client."""
        ...

    def get_val_loader(self, client_id: ClientID | None = None) -> DataLoader:
        """Get validation data loader."""
        ...

    def get_test_loader(self) -> DataLoader:
        """Get test data loader."""
        ...


# ============================================================================
# Abstract Base Classes
# ============================================================================


class BaseProofManager(ABC):
    """Abstract base class for proof managers."""

    def __init__(self, config: ZKPConfig) -> None:
        self.config = config
        self.logger = logging.getLogger(self.__class__.__name__)
        self.setup_complete = False
        self._circuit_cache: dict[str, Any] = {}
        self._proof_cache: dict[str, ProofResult] = {}

    @abstractmethod
    def setup(self) -> bool:
        """Setup circuits and proving keys."""
        pass

    @abstractmethod
    def generate_proof(self, inputs: dict[str, Any]) -> ProofResult | None:
        """Generate a proof for given inputs."""
        pass

    @abstractmethod
    def verify_proof(
        self, proof_data: ProofData, public_inputs: dict[str, Any]
    ) -> bool:
        """Verify a proof."""
        pass

    def get_metrics(self) -> dict[str, float]:
        """Get proof manager metrics."""
        return {
            "circuit_cache_size": len(self._circuit_cache),
            "proof_cache_size": len(self._proof_cache),
            "setup_complete": float(self.setup_complete),
        }


class BaseAggregator(ABC):
    """Abstract base class for aggregators."""

    def __init__(self, momentum: float = 0.9, learning_rate: float = 0.01) -> None:
        self.momentum = momentum
        self.learning_rate = learning_rate
        self.logger = logging.getLogger(self.__class__.__name__)
        self._momentum_buffer: ModelParameters | None = None

    @abstractmethod
    def aggregate(
        self, results: list[tuple[ModelParameters, int]]
    ) -> AggregationResult:
        """Aggregate parameters from multiple clients."""
        pass

    def get_weights(self, num_examples: list[int]) -> list[float]:
        """Calculate aggregation weights based on number of examples."""
        total = sum(num_examples)
        return [n / total for n in num_examples] if total > 0 else []


# ============================================================================
# Type Guards and Utilities
# ============================================================================


def is_valid_client_id(client_id: Any) -> bool:
    """Check if client_id is valid."""
    return isinstance(client_id, str) and len(client_id) > 0


def is_valid_round_id(round_id: Any) -> bool:
    """Check if round_id is valid."""
    return isinstance(round_id, int) and round_id >= 0


def is_valid_proof_rigor(proof_rigor: Any) -> bool:
    """Check if proof_rigor is valid."""
    if isinstance(proof_rigor, ProofRigor):
        return True
    if isinstance(proof_rigor, str):
        return proof_rigor in [r.value for r in ProofRigor]
    return False


def ensure_model_parameters(parameters: Any) -> ModelParameters:
    """Ensure parameters are in correct format."""
    if isinstance(parameters, list) and all(
        isinstance(p, np.ndarray) for p in parameters
    ):
        return parameters
    if isinstance(parameters, Parameters):
        from secure_fl.utils.helpers import parameters_to_ndarrays

        return parameters_to_ndarrays(parameters)
    raise TypeError(f"Invalid parameter type: {type(parameters)}")


# ============================================================================
# Constants
# ============================================================================

# Default configurations
DEFAULT_CLIENT_CONFIG = ClientConfig(client_id="default")
DEFAULT_SERVER_CONFIG = ServerConfig()
DEFAULT_ZKP_CONFIG = ZKPConfig()

# Supported model architectures
SUPPORTED_MODEL_TYPES = {
    "linear": torch.nn.Linear,
    "conv2d": torch.nn.Conv2d,
    "sequential": torch.nn.Sequential,
    "module": torch.nn.Module,
}

# ZKP circuit constraints
MAX_CIRCUIT_SIZE = 10000
MAX_TRACE_LENGTH = 2048
MAX_PROOF_SIZE_BYTES = 1024 * 1024  # 1MB

# Timeout constants (seconds)
DEFAULT_PROOF_TIMEOUT = 120
DEFAULT_VERIFICATION_TIMEOUT = 30
DEFAULT_CLIENT_TIMEOUT = 300
DEFAULT_SERVER_TIMEOUT = 600
