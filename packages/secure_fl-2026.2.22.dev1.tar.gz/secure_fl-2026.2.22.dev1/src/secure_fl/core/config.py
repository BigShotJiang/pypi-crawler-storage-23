"""
Configuration Management for Secure FL

This module provides simplified configuration management using dataclasses
and the new type system for better maintainability and type safety.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

import yaml

from .types import ClientConfig
from .types import ProofRigor
from .types import QuantizationBits
from .types import ServerConfig
from .types import ZKPConfig

__all__ = [
    "SecureFlConfig",
    "ConfigManager",
    "load_config",
    "save_config",
    "get_default_config",
]

logger = logging.getLogger(__name__)


class SecureFlConfig:
    """Main configuration class for Secure FL."""

    def __init__(
        self,
        server: ServerConfig | None = None,
        client: ClientConfig | None = None,
        zkp: ZKPConfig | None = None,
    ) -> None:
        """Initialize configuration with optional overrides."""
        self.server = server or ServerConfig()
        self.client = client or ClientConfig(client_id="default")
        self.zkp = zkp or ZKPConfig()

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SecureFlConfig:
        """Create configuration from dictionary."""
        server_data = data.get("server", {})
        client_data = data.get("client", {})
        zkp_data = data.get("zkp", {})

        # Handle enum conversions
        if "proof_rigor" in server_data and isinstance(server_data["proof_rigor"], str):
            server_data["proof_rigor"] = ProofRigor(server_data["proof_rigor"])

        if "proof_rigor" in client_data and isinstance(client_data["proof_rigor"], str):
            client_data["proof_rigor"] = ProofRigor(client_data["proof_rigor"])

        if "proof_rigor" in zkp_data and isinstance(zkp_data["proof_rigor"], str):
            zkp_data["proof_rigor"] = ProofRigor(zkp_data["proof_rigor"])

        if "quantization_bits" in client_data and isinstance(
            client_data["quantization_bits"], int
        ):
            client_data["quantization_bits"] = QuantizationBits(
                client_data["quantization_bits"]
            )

        if "quantization_bits" in zkp_data and isinstance(
            zkp_data["quantization_bits"], int
        ):
            zkp_data["quantization_bits"] = QuantizationBits(
                zkp_data["quantization_bits"]
            )

        return cls(
            server=ServerConfig(**server_data) if server_data else None,
            client=ClientConfig(**client_data) if client_data else None,
            zkp=ZKPConfig(**zkp_data) if zkp_data else None,
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert configuration to dictionary."""
        return {
            "server": self.server.to_dict(),
            "client": self.client.to_dict(),
            "zkp": self.zkp.to_dict(),
        }

    def update(self, **kwargs: Any) -> None:
        """Update configuration with new values."""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
            else:
                logger.warning(f"Unknown configuration key: {key}")


class ConfigManager:
    """Manages configuration loading, saving, and validation."""

    def __init__(self, config_dir: Path | None = None) -> None:
        """Initialize configuration manager."""
        self.config_dir = config_dir or self._get_default_config_dir()
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self._config_cache: SecureFlConfig | None = None

    def _get_default_config_dir(self) -> Path:
        """Get default configuration directory."""
        # Try XDG config directory first
        xdg_config = os.environ.get("XDG_CONFIG_HOME")
        if xdg_config:
            return Path(xdg_config) / "secure-fl"

        # Fall back to user home directory
        home = Path.home()
        return home / ".config" / "secure-fl"

    def load_config(
        self,
        config_file: str | None = None,
        env_prefix: str = "SECURE_FL",
    ) -> SecureFlConfig:
        """Load configuration from file and environment variables."""
        # Start with default configuration
        config_data: dict[str, Any] = {}

        # Load from file if specified
        if config_file:
            config_path = Path(config_file)
            if config_path.exists():
                config_data = self._load_from_file(config_path)
            else:
                logger.warning(f"Configuration file not found: {config_file}")

        # Apply environment variable overrides
        env_overrides = self._load_from_env(env_prefix)
        config_data = self._deep_merge(config_data, env_overrides)

        # Create configuration object
        config = SecureFlConfig.from_dict(config_data)
        self._config_cache = config

        logger.info("Configuration loaded successfully")
        return config

    def _load_from_file(self, config_path: Path) -> dict[str, Any]:
        """Load configuration from YAML file."""
        try:
            with open(config_path) as f:
                if config_path.suffix.lower() in {".yaml", ".yml"}:
                    return yaml.safe_load(f) or {}
                logger.warning(f"Unsupported config file format: {config_path.suffix}")
                return {}
        except Exception as e:
            logger.error(f"Error loading config file {config_path}: {e}")
            return {}

    def _load_from_env(self, prefix: str) -> dict[str, Any]:
        """Load configuration from environment variables."""
        config: dict[str, Any] = {}

        for key, value in os.environ.items():
            if key.startswith(f"{prefix}_"):
                # Remove prefix and convert to lowercase
                config_key = key[len(prefix) + 1 :].lower()

                # Parse nested keys (e.g., SECURE_FL_SERVER_PORT -> server.port)
                parts = config_key.split("_")
                current = config

                for part in parts[:-1]:
                    if part not in current:
                        current[part] = {}
                    current = current[part]

                # Convert value to appropriate type
                current[parts[-1]] = self._parse_env_value(value)

        return config

    def _parse_env_value(self, value: str) -> Any:
        """Parse environment variable value to appropriate type."""
        # Boolean values
        if value.lower() in {"true", "false"}:
            return value.lower() == "true"

        # Integer values
        try:
            return int(value)
        except ValueError:
            pass

        # Float values
        try:
            return float(value)
        except ValueError:
            pass

        # String values
        return value

    def _deep_merge(
        self, base: dict[str, Any], override: dict[str, Any]
    ) -> dict[str, Any]:
        """Deep merge two dictionaries."""
        result = base.copy()

        for key, value in override.items():
            if (
                key in result
                and isinstance(result[key], dict)
                and isinstance(value, dict)
            ):
                result[key] = self._deep_merge(result[key], value)
            else:
                result[key] = value

        return result

    def save_config(
        self, config: SecureFlConfig, filename: str = "config.yaml"
    ) -> None:
        """Save configuration to file."""
        config_path = self.config_dir / filename

        try:
            config_data = config.to_dict()
            with open(config_path, "w") as f:
                yaml.dump(config_data, f, default_flow_style=False, indent=2)

            logger.info(f"Configuration saved to {config_path}")
        except Exception as e:
            logger.error(f"Error saving configuration: {e}")
            raise

    def get_config(self) -> SecureFlConfig | None:
        """Get cached configuration."""
        return self._config_cache


# Global configuration manager instance
_config_manager: ConfigManager | None = None
_config: SecureFlConfig | None = None


def get_config_manager() -> ConfigManager:
    """Get global configuration manager instance."""
    global _config_manager
    if _config_manager is None:
        _config_manager = ConfigManager()
    return _config_manager


def load_config(
    config_file: str | None = None,
    env_prefix: str = "SECURE_FL",
    force_reload: bool = False,
) -> SecureFlConfig:
    """Load configuration using global manager."""
    global _config

    if _config is None or force_reload:
        manager = get_config_manager()
        _config = manager.load_config(config_file=config_file, env_prefix=env_prefix)

    return _config


def save_config(config: SecureFlConfig, filename: str = "config.yaml") -> None:
    """Save configuration using global manager."""
    manager = get_config_manager()
    manager.save_config(config, filename)


def get_default_config() -> SecureFlConfig:
    """Get default configuration."""
    return SecureFlConfig()


def create_example_config(output_path: str = "config.yaml") -> None:
    """Create an example configuration file."""
    get_default_config()

    # Create example with comments
    config_dict = {
        "# Secure FL Configuration Example": None,
        "server": {
            "host": "localhost",
            "port": 8080,
            "num_rounds": 10,
            "min_fit_clients": 2,
            "fraction_fit": 1.0,
            "momentum": 0.9,
            "enable_zkp": True,
            "proof_rigor": "high",  # Options: low, medium, high, adaptive
        },
        "client": {
            "client_id": "client_1",
            "local_epochs": 1,
            "learning_rate": 0.01,
            "batch_size": 32,
            "enable_zkp": True,
            "proof_rigor": "high",
            "quantize_weights": True,
            "quantization_bits": 8,  # Options: 4, 8, 16, 32
            "device": "cpu",  # Options: cpu, cuda
        },
        "zkp": {
            "enable_client_proofs": True,
            "enable_server_proofs": True,
            "proof_rigor": "high",
            "quantization_bits": 8,
            "max_trace_length": 1024,
            "circuit_size": 1000,
            "proof_timeout": 120,
            "verification_timeout": 30,
        },
    }

    # Remove comment key and save
    del config_dict["# Secure FL Configuration Example"]

    try:
        with open(output_path, "w") as f:
            f.write("# Secure FL Configuration Example\n")
            f.write("# Generated automatically - modify as needed\n\n")
            yaml.dump(config_dict, f, default_flow_style=False, indent=2)

        logger.info(f"Example configuration created at {output_path}")
    except Exception as e:
        logger.error(f"Error creating example configuration: {e}")
        raise


# Convenience functions for specific configurations
def get_server_config() -> ServerConfig:
    """Get server configuration."""
    config = load_config()
    return config.server


def get_client_config(client_id: str | None = None) -> ClientConfig:
    """Get client configuration."""
    config = load_config()
    if client_id and client_id != config.client.client_id:
        # Create new client config with specified ID
        client_dict = config.client.to_dict()
        client_dict["client_id"] = client_id
        return ClientConfig(**client_dict)
    return config.client


def get_zkp_config() -> ZKPConfig:
    """Get ZKP configuration."""
    config = load_config()
    return config.zkp
