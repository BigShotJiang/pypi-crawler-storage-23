from capslockstep.cli import main

main()
