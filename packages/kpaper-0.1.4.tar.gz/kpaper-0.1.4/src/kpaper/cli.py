from os.path import abspath
def kpaper(*args, **kwargs):
    match args, kwargs:
        case (x,), {}: print(x)
        case (), {}: 
            return None