"""
Tests for gitpush
"""
