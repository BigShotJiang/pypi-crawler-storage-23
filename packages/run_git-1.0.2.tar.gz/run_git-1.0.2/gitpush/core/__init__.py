"""
Core modules for gitpush
"""
