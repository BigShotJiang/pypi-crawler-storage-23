"""
Configuration modules for gitpush
"""
