"""Constants"""

REPOSITORIES_KEY = "repositories"
