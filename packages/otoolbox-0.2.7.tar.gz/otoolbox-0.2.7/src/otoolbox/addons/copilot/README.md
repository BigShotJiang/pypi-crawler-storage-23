# Otoolbox Addon: Copilot

This module is designe to support copilot instuction and configurations.
