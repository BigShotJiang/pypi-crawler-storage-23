# Odoonix Toolbox

This is a maintainer tool from odoonix


## Supporterd Organization

### Odoo

### OCA

### MoonSun

### Odoonix


### Tools

Run the command to see list of commands:

    ls .venv/bin/bulk-*

NOTE: the VENV must be active to use tools.

    . 