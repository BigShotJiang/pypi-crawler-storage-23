# Contributing to dynojson

Thank you for your interest in contributing! Here's how to get started.

## Development setup

1. **Clone the repo**

   ```sh
   git clone https://github.com/cykruss/dynojson.git
   cd dynojson
   ```

2. **Install Rust** via [rustup](https://rustup.rs/)

3. **Create a Python virtual environment**

   ```sh
   uv venv
   source .venv/bin/activate
   uv pip install maturin pytest
   ```

4. **Build the extension in dev mode**

   ```sh
   maturin develop
   ```

## Running tests

```sh
# Rust unit tests
cargo test --lib

# Python tests
pytest tests/ -v
```

## Code quality

```sh
# Rust formatting
cargo fmt --check

# Rust linting
cargo clippy --lib -- -D warnings

# Python linting (if ruff is installed)
ruff check python/ tests/
```

## Pull requests

1. Fork the repository and create a branch from `main`.
2. Add tests for any new functionality.
3. Ensure all tests pass (`cargo test --lib` and `pytest tests/ -v`).
4. Run `cargo fmt` and `cargo clippy`.
5. Open a pull request with a clear description of the change.

## Releasing

Releases are triggered by pushing a version tag:

```sh
git tag v0.2.0
git push origin v0.2.0
```

The CI workflow will build wheels for all platforms and publish to PyPI.
