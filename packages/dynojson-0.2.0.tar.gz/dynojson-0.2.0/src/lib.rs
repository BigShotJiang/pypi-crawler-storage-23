//! # dynojson
//!
//! **Marshall / unmarshall JSON to and from DynamoDB JSON format.**
//!
//! This crate provides a fast, pure-Rust implementation of the DynamoDB JSON
//! conversion routines (equivalent to the AWS SDK `@aws-sdk/util-dynamodb`
//! `marshall` / `unmarshall` helpers) plus a JSON property-path extractor
//! with dot-notation and wildcard support.
//!
//! It can be used as a **Rust library** (`cargo add dynojson`) or as a
//! **Python package** (`pip install dynojson`) — the Python extension is
//! compiled via [PyO3](https://pyo3.rs) when the `python` feature is enabled.
//!
//! ## Rust usage
//!
//! ```rust
//! use dynojson::marshall::marshall_top_level;
//! use dynojson::unmarshall::unmarshall_top_level;
//!
//! let regular = serde_json::json!({"name": "Alice", "age": 30});
//! let ddb = marshall_top_level(&regular);
//! let back = unmarshall_top_level(&ddb).unwrap();
//! assert_eq!(regular, back);
//! ```
//!
//! ## Modules
//!
//! - [`marshall`] — regular JSON → DynamoDB JSON
//! - [`unmarshall`] — DynamoDB JSON → regular JSON
//! - [`property`] — dot-path property extraction with `*` wildcard
//! - [`error`] — error types

pub mod error;
pub mod marshall;
pub mod property;
pub mod unmarshall;

// ── Python bindings (only compiled with the "python" feature) ──────────────

#[cfg(feature = "python")]
mod python {
    use pyo3::exceptions::PyValueError;
    use pyo3::prelude::*;
    use pyo3::types::PyString;

    use crate::error::DynoError;
    use crate::{marshall, property, unmarshall};

    /// Package version, injected at compile time from Cargo.toml.
    const VERSION: &str = env!("CARGO_PKG_VERSION");

    /// Convert a [`DynoError`] into a Python `ValueError`.
    fn dyno_err(err: DynoError) -> PyErr {
        PyValueError::new_err(err.to_string())
    }

    /// Convert a [`serde_json::Error`] into a Python `ValueError`.
    fn json_err(err: serde_json::Error) -> PyErr {
        PyValueError::new_err(err.to_string())
    }

    /// Parse a `PyAny` input into a `serde_json::Value`.
    ///
    /// Returns `(value, was_str)` — the boolean tracks whether the input was a
    /// string so we can return the same type.
    fn parse_input(input: &Bound<'_, PyAny>) -> PyResult<(serde_json::Value, bool)> {
        if let Ok(s) = input.downcast::<PyString>() {
            let json_str = s.to_str()?;
            let value = serde_json::from_str(json_str).map_err(json_err)?;
            Ok((value, true))
        } else {
            let value: serde_json::Value =
                pythonize::depythonize(input).map_err(|e| PyValueError::new_err(e.to_string()))?;
            Ok((value, false))
        }
    }

    /// Convert a `serde_json::Value` back to Python, matching the input type.
    ///
    /// If the caller passed a string, return a JSON string. If they passed a
    /// dict/list, return a native Python object.
    fn to_output(py: Python<'_>, value: &serde_json::Value, as_str: bool) -> PyResult<PyObject> {
        if as_str {
            let s = serde_json::to_string(value).map_err(json_err)?;
            Ok(s.into_pyobject(py)?.into_any().unbind())
        } else {
            pythonize::pythonize(py, value)
                .map(|bound| bound.unbind())
                .map_err(|e| PyValueError::new_err(e.to_string()))
        }
    }

    /// Convert regular JSON to DynamoDB JSON format.
    ///
    /// Accepts a JSON string, dict, or list. Returns the same type as the input.
    #[pyfunction]
    #[pyo3(name = "marshall")]
    fn py_marshall(input: &Bound<'_, PyAny>) -> PyResult<PyObject> {
        let (value, as_str) = parse_input(input)?;
        let converted = marshall::marshall_top_level(&value);
        Python::with_gil(|py| to_output(py, &converted, as_str))
    }

    /// Convert DynamoDB JSON to regular JSON format.
    ///
    /// Accepts a JSON string, dict, or list. Returns the same type as the input.
    #[pyfunction]
    #[pyo3(name = "unmarshall")]
    fn py_unmarshall(input: &Bound<'_, PyAny>) -> PyResult<PyObject> {
        let (value, as_str) = parse_input(input)?;
        let converted = unmarshall::unmarshall_top_level(&value).map_err(dyno_err)?;
        Python::with_gil(|py| to_output(py, &converted, as_str))
    }

    /// Extract a nested property from JSON by dot-separated path.
    ///
    /// Accepts a JSON string, dict, or list. Returns the same type as the input.
    #[pyfunction]
    #[pyo3(name = "get_property")]
    fn py_get_property(input: &Bound<'_, PyAny>, path: &str) -> PyResult<PyObject> {
        let (value, as_str) = parse_input(input)?;
        let result = property::get_property(&value, path).map_err(dyno_err)?;

        match result {
            Some(v) => Python::with_gil(|py| to_output(py, &v, as_str)),
            None => Err(dyno_err(DynoError::PropertyNotFound {
                path: path.to_owned(),
            })),
        }
    }

    /// Read a file, parse JSON, process it, and either write to an output file
    /// or return a Python dict/list.
    ///
    /// Returns `None` when `output_path` is provided (result written to file),
    /// or a Python dict/list when no output path is given.
    #[pyfunction]
    #[pyo3(name = "marshall_file", signature = (input_path, output_path=None, *, get=None))]
    fn py_marshall_file(
        input_path: &str,
        output_path: Option<&str>,
        get: Option<&str>,
    ) -> PyResult<PyObject> {
        let contents = std::fs::read_to_string(input_path)
            .map_err(|e| PyValueError::new_err(format!("{input_path}: {e}")))?;
        let mut value: serde_json::Value = serde_json::from_str(&contents).map_err(json_err)?;

        if let Some(path) = get {
            value = property::get_property(&value, path)
                .map_err(dyno_err)?
                .ok_or_else(|| {
                    dyno_err(DynoError::PropertyNotFound {
                        path: path.to_owned(),
                    })
                })?;
        }

        let result = marshall::marshall_top_level(&value);

        match output_path {
            Some(out) => {
                let json = serde_json::to_string(&result).map_err(json_err)?;
                std::fs::write(out, json)
                    .map_err(|e| PyValueError::new_err(format!("{out}: {e}")))?;
                Python::with_gil(|py| Ok(py.None().into()))
            }
            None => Python::with_gil(|py| {
                pythonize::pythonize(py, &result)
                    .map(|bound| bound.unbind())
                    .map_err(|e| PyValueError::new_err(e.to_string()))
            }),
        }
    }

    /// Read a DynamoDB JSON file, unmarshall it, and either write to an output
    /// file or return a Python dict/list.
    ///
    /// Returns `None` when `output_path` is provided (result written to file),
    /// or a Python dict/list when no output path is given.
    #[pyfunction]
    #[pyo3(name = "unmarshall_file", signature = (input_path, output_path=None, *, get=None))]
    fn py_unmarshall_file(
        input_path: &str,
        output_path: Option<&str>,
        get: Option<&str>,
    ) -> PyResult<PyObject> {
        let contents = std::fs::read_to_string(input_path)
            .map_err(|e| PyValueError::new_err(format!("{input_path}: {e}")))?;
        let mut value: serde_json::Value = serde_json::from_str(&contents).map_err(json_err)?;

        if let Some(path) = get {
            value = property::get_property(&value, path)
                .map_err(dyno_err)?
                .ok_or_else(|| {
                    dyno_err(DynoError::PropertyNotFound {
                        path: path.to_owned(),
                    })
                })?;
        }

        let result = unmarshall::unmarshall_top_level(&value).map_err(dyno_err)?;

        match output_path {
            Some(out) => {
                let json = serde_json::to_string(&result).map_err(json_err)?;
                std::fs::write(out, json)
                    .map_err(|e| PyValueError::new_err(format!("{out}: {e}")))?;
                Python::with_gil(|py| Ok(py.None().into()))
            }
            None => Python::with_gil(|py| {
                pythonize::pythonize(py, &result)
                    .map(|bound| bound.unbind())
                    .map_err(|e| PyValueError::new_err(e.to_string()))
            }),
        }
    }

    /// Collect sorted `.json` file paths from a directory.
    fn collect_json_files(dir: &str) -> PyResult<Vec<std::path::PathBuf>> {
        let entries =
            std::fs::read_dir(dir).map_err(|e| PyValueError::new_err(format!("{dir}: {e}")))?;
        let mut files: Vec<std::path::PathBuf> = entries
            .filter_map(|entry| {
                let entry = entry.ok()?;
                let path = entry.path();
                if path.extension().and_then(|e| e.to_str()) == Some("json") && path.is_file() {
                    Some(path)
                } else {
                    None
                }
            })
            .collect();
        files.sort();
        Ok(files)
    }

    /// Read, parse, optionally extract a property, and apply a transform to a
    /// single file. Returns `(filename, serialized_json)`.
    fn process_file(
        path: &std::path::Path,
        get: Option<&str>,
        transform: &(dyn Fn(&serde_json::Value) -> Result<serde_json::Value, PyErr> + Sync),
    ) -> Result<(String, String), PyErr> {
        let filename = path
            .file_name()
            .and_then(|n| n.to_str())
            .unwrap_or("unknown.json")
            .to_owned();

        let contents = std::fs::read_to_string(path)
            .map_err(|e| PyValueError::new_err(format!("{}: {e}", path.display())))?;
        let mut value: serde_json::Value = serde_json::from_str(&contents).map_err(json_err)?;

        if let Some(prop) = get {
            value = property::get_property(&value, prop)
                .map_err(dyno_err)?
                .ok_or_else(|| {
                    dyno_err(DynoError::PropertyNotFound {
                        path: prop.to_owned(),
                    })
                })?;
        }

        let result = transform(&value)?;
        let json = serde_json::to_string(&result).map_err(json_err)?;
        Ok((filename, json))
    }

    /// Process all `.json` files in a directory, writing results to an output
    /// directory (mirror mode) or a single merged JSON array file (merge mode).
    /// Returns the number of files processed.
    fn process_dir(
        input_dir: &str,
        output_path: &str,
        get: Option<&str>,
        merge: bool,
        transform: &(dyn Fn(&serde_json::Value) -> Result<serde_json::Value, PyErr> + Sync),
    ) -> PyResult<usize> {
        use rayon::prelude::*;

        let files = collect_json_files(input_dir)?;
        let count = files.len();

        if count == 0 {
            if merge {
                std::fs::write(output_path, "[]")
                    .map_err(|e| PyValueError::new_err(format!("{output_path}: {e}")))?;
            }
            return Ok(0);
        }

        let results: Result<Vec<(String, String)>, PyErr> = files
            .par_iter()
            .map(|path| process_file(path, get, transform))
            .collect();
        let results = results?;

        if merge {
            // Write all results as a JSON array to a single file
            let merged = format!(
                "[{}]",
                results
                    .iter()
                    .map(|(_, json)| json.as_str())
                    .collect::<Vec<_>>()
                    .join(",")
            );
            std::fs::write(output_path, merged)
                .map_err(|e| PyValueError::new_err(format!("{output_path}: {e}")))?;
        } else {
            // Mirror mode: write each result to output_path/<filename>
            let out_dir = std::path::Path::new(output_path);
            std::fs::create_dir_all(out_dir)
                .map_err(|e| PyValueError::new_err(format!("{output_path}: {e}")))?;
            for (filename, json) in &results {
                let out_file = out_dir.join(filename);
                std::fs::write(&out_file, json)
                    .map_err(|e| PyValueError::new_err(format!("{}: {e}", out_file.display())))?;
            }
        }

        Ok(count)
    }

    /// Process all `.json` files in a directory, marshalling each to DynamoDB
    /// JSON format.
    ///
    /// In mirror mode (default), writes each result to `output_path/<filename>`.
    /// In merge mode (`merge=True`), writes all results as a JSON array to
    /// `output_path`. Returns the number of files processed.
    #[pyfunction]
    #[pyo3(name = "marshall_dir", signature = (input_dir, output_path, *, get=None, merge=false))]
    fn py_marshall_dir(
        input_dir: &str,
        output_path: &str,
        get: Option<&str>,
        merge: bool,
    ) -> PyResult<usize> {
        process_dir(input_dir, output_path, get, merge, &|value| {
            Ok(marshall::marshall_top_level(value))
        })
    }

    /// Process all `.json` files in a directory, unmarshalling each from
    /// DynamoDB JSON to regular JSON.
    ///
    /// In mirror mode (default), writes each result to `output_path/<filename>`.
    /// In merge mode (`merge=True`), writes all results as a JSON array to
    /// `output_path`. Returns the number of files processed.
    #[pyfunction]
    #[pyo3(name = "unmarshall_dir", signature = (input_dir, output_path, *, get=None, merge=false))]
    fn py_unmarshall_dir(
        input_dir: &str,
        output_path: &str,
        get: Option<&str>,
        merge: bool,
    ) -> PyResult<usize> {
        process_dir(input_dir, output_path, get, merge, &|value| {
            unmarshall::unmarshall_top_level(value).map_err(dyno_err)
        })
    }

    /// The native extension module exposed to Python as `dynojson._dynojson`.
    #[pymodule]
    #[pyo3(name = "_dynojson")]
    pub fn init(m: &Bound<'_, PyModule>) -> PyResult<()> {
        m.add("__version__", VERSION)?;
        m.add_function(wrap_pyfunction!(py_marshall, m)?)?;
        m.add_function(wrap_pyfunction!(py_unmarshall, m)?)?;
        m.add_function(wrap_pyfunction!(py_get_property, m)?)?;
        m.add_function(wrap_pyfunction!(py_marshall_file, m)?)?;
        m.add_function(wrap_pyfunction!(py_unmarshall_file, m)?)?;
        m.add_function(wrap_pyfunction!(py_marshall_dir, m)?)?;
        m.add_function(wrap_pyfunction!(py_unmarshall_dir, m)?)?;
        Ok(())
    }
}
