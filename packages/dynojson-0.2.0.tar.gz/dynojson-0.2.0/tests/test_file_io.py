"""Tests for file-based marshall/unmarshall API."""

import json
import os

import pytest

from dynojson import marshall_dir, marshall_file, unmarshall_dir, unmarshall_file


# ── Helpers ──────────────────────────────────────────────────────────────────

SAMPLE_DATA = {
    "name": "Alice",
    "age": 30,
    "active": True,
    "tags": ["admin", "dev"],
    "profile": {"bio": "Engineer", "level": 5},
}

SAMPLE_MARSHALLED = {
    "name": {"S": "Alice"},
    "age": {"N": "30"},
    "active": {"BOOL": True},
    "tags": {"L": [{"S": "admin"}, {"S": "dev"}]},
    "profile": {"M": {"bio": {"S": "Engineer"}, "level": {"N": "5"}}},
}


def write_json(tmp_path, filename, data):
    path = tmp_path / filename
    path.write_text(json.dumps(data))
    return str(path)


# ── marshall_file tests ─────────────────────────────────────────────────────


class TestMarshallFile:
    def test_returns_dict_when_no_output_path(self, tmp_path):
        infile = write_json(tmp_path, "input.json", SAMPLE_DATA)
        result = marshall_file(infile)
        assert isinstance(result, dict)
        assert result == SAMPLE_MARSHALLED

    def test_writes_to_output_file(self, tmp_path):
        infile = write_json(tmp_path, "input.json", SAMPLE_DATA)
        outfile = str(tmp_path / "output.json")
        result = marshall_file(infile, outfile)
        assert result is None
        written = json.loads(open(outfile).read())
        assert written == SAMPLE_MARSHALLED

    def test_with_list_input(self, tmp_path):
        data = [{"name": "Alice"}, {"name": "Bob"}]
        infile = write_json(tmp_path, "input.json", data)
        result = marshall_file(infile)
        assert isinstance(result, list)
        assert result == [
            {"name": {"S": "Alice"}},
            {"name": {"S": "Bob"}},
        ]

    def test_with_get_parameter(self, tmp_path):
        data = {"Items": [{"name": "Alice", "age": 30}]}
        infile = write_json(tmp_path, "input.json", data)
        result = marshall_file(infile, get="Items")
        assert isinstance(result, list)
        assert result == [{"name": {"S": "Alice"}, "age": {"N": "30"}}]

    def test_with_get_and_output_file(self, tmp_path):
        data = {"Items": [{"name": "Alice"}]}
        infile = write_json(tmp_path, "input.json", data)
        outfile = str(tmp_path / "output.json")
        result = marshall_file(infile, outfile, get="Items")
        assert result is None
        written = json.loads(open(outfile).read())
        assert written == [{"name": {"S": "Alice"}}]

    def test_missing_file_raises(self):
        with pytest.raises(ValueError, match=r"nonexistent"):
            marshall_file("/nonexistent/file.json")

    def test_invalid_json_raises(self, tmp_path):
        path = tmp_path / "bad.json"
        path.write_text("not valid json {{{")
        with pytest.raises(ValueError):
            marshall_file(str(path))


# ── unmarshall_file tests ───────────────────────────────────────────────────


class TestUnmarshallFile:
    def test_returns_dict_when_no_output_path(self, tmp_path):
        infile = write_json(tmp_path, "input.json", SAMPLE_MARSHALLED)
        result = unmarshall_file(infile)
        assert isinstance(result, dict)
        assert result == SAMPLE_DATA

    def test_writes_to_output_file(self, tmp_path):
        infile = write_json(tmp_path, "input.json", SAMPLE_MARSHALLED)
        outfile = str(tmp_path / "output.json")
        result = unmarshall_file(infile, outfile)
        assert result is None
        written = json.loads(open(outfile).read())
        assert written == SAMPLE_DATA

    def test_with_list_input(self, tmp_path):
        data = [
            {"name": {"S": "Alice"}},
            {"name": {"S": "Bob"}},
        ]
        infile = write_json(tmp_path, "input.json", data)
        result = unmarshall_file(infile)
        assert isinstance(result, list)
        assert result == [{"name": "Alice"}, {"name": "Bob"}]

    def test_with_get_parameter(self, tmp_path):
        data = {"Item": {"name": {"S": "Alice"}, "age": {"N": "30"}}}
        infile = write_json(tmp_path, "input.json", data)
        result = unmarshall_file(infile, get="Item")
        assert isinstance(result, dict)
        assert result == {"name": "Alice", "age": 30}

    def test_missing_file_raises(self):
        with pytest.raises(ValueError, match=r"nonexistent"):
            unmarshall_file("/nonexistent/file.json")


# ── Roundtrip tests ─────────────────────────────────────────────────────────


class TestFileRoundtrip:
    def test_marshall_then_unmarshall(self, tmp_path):
        infile = write_json(tmp_path, "input.json", SAMPLE_DATA)
        midfile = str(tmp_path / "marshalled.json")
        outfile = str(tmp_path / "output.json")

        marshall_file(infile, midfile)
        unmarshall_file(midfile, outfile)

        result = json.loads(open(outfile).read())
        assert result == SAMPLE_DATA

    def test_roundtrip_dict_return(self, tmp_path):
        infile = write_json(tmp_path, "input.json", SAMPLE_DATA)
        marshalled = marshall_file(infile)
        # Write marshalled dict to a file for unmarshalling
        midfile = write_json(tmp_path, "marshalled.json", marshalled)
        result = unmarshall_file(midfile)
        assert result == SAMPLE_DATA


# ── Directory helpers ────────────────────────────────────────────────────────

ITEMS = [
    {"name": "Alice", "age": 30},
    {"name": "Bob", "age": 25},
    {"name": "Charlie", "age": 35},
]

ITEMS_MARSHALLED = [
    {"name": {"S": "Alice"}, "age": {"N": "30"}},
    {"name": {"S": "Bob"}, "age": {"N": "25"}},
    {"name": {"S": "Charlie"}, "age": {"N": "35"}},
]


def make_input_dir(tmp_path, items, dirname="input"):
    """Create a directory with one .json file per item."""
    indir = tmp_path / dirname
    indir.mkdir()
    for i, item in enumerate(items):
        (indir / f"item_{i:03d}.json").write_text(json.dumps(item))
    return str(indir)


# ── marshall_dir tests ───────────────────────────────────────────────────────


class TestMarshallDir:
    def test_mirror_mode(self, tmp_path):
        indir = make_input_dir(tmp_path, ITEMS)
        outdir = str(tmp_path / "output")
        count = marshall_dir(indir, outdir)
        assert count == 3
        for i, expected in enumerate(ITEMS_MARSHALLED):
            outfile = os.path.join(outdir, f"item_{i:03d}.json")
            assert os.path.exists(outfile)
            assert json.loads(open(outfile).read()) == expected

    def test_merge_mode(self, tmp_path):
        indir = make_input_dir(tmp_path, ITEMS)
        outfile = str(tmp_path / "merged.json")
        count = marshall_dir(indir, outfile, merge=True)
        assert count == 3
        result = json.loads(open(outfile).read())
        assert isinstance(result, list)
        assert len(result) == 3
        # Files are sorted, so order is deterministic
        assert result == ITEMS_MARSHALLED

    def test_with_get_parameter(self, tmp_path):
        wrapped = [{"Items": item} for item in ITEMS]
        indir = make_input_dir(tmp_path, wrapped)
        outdir = str(tmp_path / "output")
        count = marshall_dir(indir, outdir, get="Items")
        assert count == 3

    def test_only_json_files_processed(self, tmp_path):
        indir = make_input_dir(tmp_path, ITEMS[:2])
        # Add a non-json file
        (tmp_path / "input" / "readme.txt").write_text("not json")
        outdir = str(tmp_path / "output")
        count = marshall_dir(str(tmp_path / "input"), outdir)
        assert count == 2
        assert not os.path.exists(os.path.join(outdir, "readme.txt"))

    def test_empty_directory(self, tmp_path):
        indir = tmp_path / "empty"
        indir.mkdir()
        outdir = str(tmp_path / "output")
        count = marshall_dir(str(indir), outdir)
        assert count == 0

    def test_empty_directory_merge(self, tmp_path):
        indir = tmp_path / "empty"
        indir.mkdir()
        outfile = str(tmp_path / "merged.json")
        count = marshall_dir(str(indir), outfile, merge=True)
        assert count == 0
        assert json.loads(open(outfile).read()) == []

    def test_nonexistent_directory_raises(self):
        with pytest.raises(ValueError):
            marshall_dir("/nonexistent/dir", "/tmp/out")


# ── unmarshall_dir tests ─────────────────────────────────────────────────────


class TestUnmarshallDir:
    def test_mirror_mode(self, tmp_path):
        indir = make_input_dir(tmp_path, ITEMS_MARSHALLED)
        outdir = str(tmp_path / "output")
        count = unmarshall_dir(indir, outdir)
        assert count == 3
        for i, expected in enumerate(ITEMS):
            outfile = os.path.join(outdir, f"item_{i:03d}.json")
            assert json.loads(open(outfile).read()) == expected

    def test_merge_mode(self, tmp_path):
        indir = make_input_dir(tmp_path, ITEMS_MARSHALLED)
        outfile = str(tmp_path / "merged.json")
        count = unmarshall_dir(indir, outfile, merge=True)
        assert count == 3
        result = json.loads(open(outfile).read())
        assert result == ITEMS

    def test_with_get_parameter(self, tmp_path):
        wrapped = [{"Item": item} for item in ITEMS_MARSHALLED]
        indir = make_input_dir(tmp_path, wrapped)
        outdir = str(tmp_path / "output")
        count = unmarshall_dir(indir, outdir, get="Item")
        assert count == 3
        result = json.loads(open(os.path.join(outdir, "item_000.json")).read())
        assert result == ITEMS[0]


# ── Directory roundtrip tests ────────────────────────────────────────────────


class TestDirRoundtrip:
    def test_marshall_dir_then_unmarshall_dir(self, tmp_path):
        indir = make_input_dir(tmp_path, ITEMS)
        middir = str(tmp_path / "marshalled")
        outdir = str(tmp_path / "output")

        marshall_dir(indir, middir)
        unmarshall_dir(middir, outdir)

        for i, expected in enumerate(ITEMS):
            outfile = os.path.join(outdir, f"item_{i:03d}.json")
            assert json.loads(open(outfile).read()) == expected
