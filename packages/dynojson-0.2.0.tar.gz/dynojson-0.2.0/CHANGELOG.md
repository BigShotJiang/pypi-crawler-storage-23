# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] - 2026-02-28

### Added

- **File-based processing**: `marshall_file()` and `unmarshall_file()` read JSON files directly in Rust, bypassing Python-Rust FFI overhead. Optional `output_path` writes results to a file; optional `get` extracts a property before processing.
- **Directory batch processing**: `marshall_dir()` and `unmarshall_dir()` process all `.json` files in a directory with Rayon parallelism. Supports mirror mode (1:1 output files) and merge mode (single JSON array output).
- Pure Python baseline and file-based paths in benchmark script for honest performance comparison.

### Changed

- CI: Added Rust build caching (`Swatinem/rust-cache@v2`), reduced Python matrix on push-to-main, debug builds for test runs.
- Expanded benchmark script with 5 comparison paths (pure Python, string, dict, file→dict, file→file).

## [0.1.2] - 2026-02-28

### Added

- **Dict/list input support**: `marshall()`, `unmarshall()`, and `get_property()` now accept Python dicts and lists directly, in addition to JSON strings. Return type matches the input type (str in → str out, dict in → dict out).
- **Benchmark script** (`benchmarks/bench_marshall.py`): Compares string vs dict path performance across small, medium, and large payloads.
- **Python 3.14 support**: Added to CI matrix and pyproject classifiers.

### Changed

- Updated README with dict API examples and benchmark results.

## [0.1.1] - 2026-02-20

### Fixed

- Fixed CI wheel build failure on x86_64 targets.
- Fixed `maturin develop` in CI requiring a virtual environment.
- Fixed `cargo fmt` formatting issues.
- Fixed Python 3.9 compatibility (`str | None` syntax) — dropped 3.9, minimum is now Python 3.10.

## [0.1.0] - 2026-02-20

### Added

- **Marshall**: Convert regular JSON to DynamoDB JSON format (`S`, `N`, `BOOL`, `NULL`, `L`, `M`).
- **Unmarshall**: Convert DynamoDB JSON back to regular JSON. Supports all 10 DynamoDB type descriptors: `S`, `N`, `B`, `BOOL`, `NULL`, `L`, `M`, `SS`, `NS`, `BS`.
- **Property extraction**: Dot-path property access with wildcard (`*`) support for arrays.
- **Python bindings** via PyO3 — `marshall()`, `unmarshall()`, `get_property()`.
- **CLI** (`dynojson`) with `marshall`/`m` and `unmarshall`/`u` commands, `-g` property path option, stdin/file/string input.
- **Parallel processing** with Rayon for top-level arrays and objects.
- Multi-platform wheels: Linux (x86_64, aarch64), macOS (Apple Silicon), Windows (x86_64).
- Published to both [PyPI](https://pypi.org/project/dynojson/) and [crates.io](https://crates.io/crates/dynojson).

[Unreleased]: https://github.com/cykruss/dynojson/compare/v0.2.0...HEAD
[0.2.0]: https://github.com/cykruss/dynojson/compare/v0.1.2...v0.2.0
[0.1.2]: https://github.com/cykruss/dynojson/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/cykruss/dynojson/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/cykruss/dynojson/releases/tag/v0.1.0
