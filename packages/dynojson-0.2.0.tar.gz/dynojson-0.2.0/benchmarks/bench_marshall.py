"""Benchmark: pure Python vs dynojson (string / dict / file paths).

Compares four approaches for marshall/unmarshall:

  Pure Python:      Hand-written Python marshall/unmarshall functions
  String path:      json.dumps(data) → dynojson.marshall(str) → json.loads(result)
  Dict path:        dynojson.marshall(dict) → result is already a dict
  File (dict out):  dynojson.marshall_file(path) → returns dict (reads file in Rust)
  File (file out):  dynojson.marshall_file(path, out) → writes file (fully in Rust)

Usage:
    python benchmarks/bench_marshall.py
"""

import json
import os
import tempfile
import timeit

from dynojson import marshall, marshall_file, unmarshall, unmarshall_file


# ---------------------------------------------------------------------------
# Pure-Python marshall / unmarshall (baseline)
# ---------------------------------------------------------------------------

def py_marshall_value(value):
    """Marshall a single value to DynamoDB JSON format (pure Python)."""
    if isinstance(value, str):
        return {"S": value}
    if isinstance(value, bool):  # must check before int — bool is subclass of int
        return {"BOOL": value}
    if isinstance(value, (int, float)):
        return {"N": str(value)}
    if value is None:
        return {"NULL": True}
    if isinstance(value, list):
        return {"L": [py_marshall_value(v) for v in value]}
    if isinstance(value, dict):
        return {"M": {k: py_marshall_value(v) for k, v in value.items()}}
    raise TypeError(f"Unsupported type: {type(value)}")


def py_marshall_top_level(data):
    """Marshall top-level JSON to DynamoDB JSON (pure Python)."""
    if isinstance(data, dict):
        return {k: py_marshall_value(v) for k, v in data.items()}
    if isinstance(data, list):
        return [py_marshall_top_level(item) for item in data]
    return py_marshall_value(data)


def py_unmarshall_value(value):
    """Unmarshall a single DynamoDB-typed value (pure Python)."""
    if not isinstance(value, dict) or len(value) != 1:
        return value
    key, inner = next(iter(value.items()))
    if key == "S":
        return inner
    if key == "N":
        try:
            return int(inner)
        except (ValueError, TypeError):
            return float(inner)
    if key == "BOOL":
        return inner
    if key == "NULL":
        return None
    if key == "L":
        return [py_unmarshall_value(v) for v in inner]
    if key == "M":
        return {k: py_unmarshall_value(v) for k, v in inner.items()}
    if key in ("SS", "BS", "B"):
        return inner
    if key == "NS":
        result = []
        for v in inner:
            try:
                result.append(int(v))
            except (ValueError, TypeError):
                result.append(float(v))
        return result
    return value


def py_unmarshall_top_level(data):
    """Unmarshall top-level DynamoDB JSON (pure Python)."""
    if isinstance(data, dict):
        return {k: py_unmarshall_value(v) for k, v in data.items()}
    if isinstance(data, list):
        return [py_unmarshall_top_level(item) for item in data]
    return py_unmarshall_value(data)


# ---------------------------------------------------------------------------
# Test data
# ---------------------------------------------------------------------------

def make_item(i: int) -> dict:
    """Generate a realistic DynamoDB-style item."""
    return {
        "id": f"user-{i}",
        "name": f"User {i}",
        "age": 20 + (i % 50),
        "active": i % 2 == 0,
        "tags": ["admin", "dev"] if i % 3 == 0 else ["viewer"],
        "scores": [i * 10, i * 20, i * 30],
        "profile": {
            "bio": f"Bio for user {i}",
            "level": i % 10,
        },
    }


PAYLOADS = {
    "small (1 item)": make_item(0),
    "medium (100 items)": [make_item(i) for i in range(100)],
    "large (10,000 items)": [make_item(i) for i in range(10_000)],
}

ITERATIONS = {
    "small (1 item)": 10_000,
    "medium (100 items)": 1_000,
    "large (10,000 items)": 50,
}


# ---------------------------------------------------------------------------
# Benchmark functions
# ---------------------------------------------------------------------------

# Marshall
def bench_marshall_pure_python(data):
    py_marshall_top_level(data)

def bench_marshall_string(data):
    s = json.dumps(data)
    result = marshall(s)
    json.loads(result)

def bench_marshall_dict(data):
    marshall(data)

def bench_marshall_file_dict(path):
    marshall_file(path)

def bench_marshall_file_file(path, out_path):
    marshall_file(path, out_path)


# Unmarshall
def bench_unmarshall_pure_python(data):
    py_unmarshall_top_level(data)

def bench_unmarshall_string(data):
    s = json.dumps(data)
    result = unmarshall(s)
    json.loads(result)

def bench_unmarshall_dict(data):
    unmarshall(data)

def bench_unmarshall_file_dict(path):
    unmarshall_file(path)

def bench_unmarshall_file_file(path, out_path):
    unmarshall_file(path, out_path)


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def fmt_time(seconds, n):
    """Format total time and per-iteration time."""
    per_iter = seconds / n
    if per_iter < 1e-3:
        return f"{seconds:.4f}s  ({per_iter * 1e6:.1f} µs/iter)"
    return f"{seconds:.4f}s  ({per_iter * 1e3:.2f} ms/iter)"


def fmt_compare(baseline, candidate, baseline_label, candidate_label):
    """Format a comparison between two timings."""
    ratio = baseline / candidate if candidate > 0 else float("inf")
    if ratio >= 1:
        return f"{candidate_label} vs {baseline_label}: {ratio:.2f}x faster"
    return f"{candidate_label} vs {baseline_label}: {1 / ratio:.2f}x slower"


def print_results(label, timings):
    """Print timing results and comparisons."""
    t_py, t_str, t_dict, t_file_dict, t_file_file = timings
    n = ITERATIONS[label]

    print(f"    pure python:          {fmt_time(t_py, n)}")
    print(f"    dynojson (str):       {fmt_time(t_str, n)}")
    print(f"    dynojson (dict):      {fmt_time(t_dict, n)}")
    print(f"    dynojson (file→dict): {fmt_time(t_file_dict, n)}")
    print(f"    dynojson (file→file): {fmt_time(t_file_file, n)}")
    print()
    print(f"    {fmt_compare(t_py, t_str, 'python', 'str')}")
    print(f"    {fmt_compare(t_py, t_dict, 'python', 'dict')}")
    print(f"    {fmt_compare(t_py, t_file_dict, 'python', 'file→dict')}")
    print(f"    {fmt_compare(t_py, t_file_file, 'python', 'file→file')}")
    print(f"    {fmt_compare(t_str, t_dict, 'str', 'dict')}")
    print(f"    {fmt_compare(t_str, t_file_file, 'str', 'file→file')}")


def run():
    print("=" * 78)
    print("dynojson benchmark: pure Python vs str vs dict vs file paths")
    print("=" * 78)

    with tempfile.TemporaryDirectory() as tmpdir:
        for label, data in PAYLOADS.items():
            n = ITERATIONS[label]

            # Write input files for file-based benchmarks
            input_file = os.path.join(tmpdir, f"input_{label}.json")
            output_file = os.path.join(tmpdir, f"output_{label}.json")
            with open(input_file, "w") as f:
                json.dump(data, f)

            # Pre-marshall for unmarshall benchmarks
            marshalled_dict = marshall(data)
            marshalled_file = os.path.join(tmpdir, f"marshalled_{label}.json")
            marshalled_out = os.path.join(tmpdir, f"unmarshalled_{label}.json")
            with open(marshalled_file, "w") as f:
                json.dump(marshalled_dict, f)

            print(f"\n{'─' * 78}")
            print(f"  {label} ({n} iterations)")
            print(f"{'─' * 78}")

            # ── Marshall ──────────────────────────────────────────────
            print("\n  Marshall:")

            t_py = timeit.timeit(lambda: bench_marshall_pure_python(data), number=n)
            t_str = timeit.timeit(lambda: bench_marshall_string(data), number=n)
            t_dict = timeit.timeit(lambda: bench_marshall_dict(data), number=n)
            t_file_dict = timeit.timeit(
                lambda: bench_marshall_file_dict(input_file), number=n
            )
            t_file_file = timeit.timeit(
                lambda: bench_marshall_file_file(input_file, output_file), number=n
            )

            print_results(label, (t_py, t_str, t_dict, t_file_dict, t_file_file))

            # ── Unmarshall ────────────────────────────────────────────
            print("\n  Unmarshall:")

            t_py = timeit.timeit(
                lambda: bench_unmarshall_pure_python(marshalled_dict), number=n
            )
            t_str = timeit.timeit(
                lambda: bench_unmarshall_string(marshalled_dict), number=n
            )
            t_dict = timeit.timeit(
                lambda: bench_unmarshall_dict(marshalled_dict), number=n
            )
            t_file_dict = timeit.timeit(
                lambda: bench_unmarshall_file_dict(marshalled_file), number=n
            )
            t_file_file = timeit.timeit(
                lambda: bench_unmarshall_file_file(marshalled_file, marshalled_out),
                number=n,
            )

            print_results(label, (t_py, t_str, t_dict, t_file_dict, t_file_file))

    print()


if __name__ == "__main__":
    run()
