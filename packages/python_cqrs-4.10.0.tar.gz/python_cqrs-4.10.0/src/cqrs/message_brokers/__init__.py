from cqrs.message_brokers.protocol import Message, MessageBroker

__all__ = (
    "Message",
    "MessageBroker",
)
