# Production-Like Overlay

**Purpose:** Reference implementation showing production-like configuration.

**⚠️ WARNING: This is NOT production-ready. It's a reference example for SDK developers.**

## What This Is

A reference configuration demonstrating:
- GCP exporters (Cloud Trace, Cloud Logging, Prometheus)
- Langfuse integration for LLM observability
- Production-like resource limits
- Retry logic and persistent queues
- Info-level logging

## What's Missing for Production

This overlay does NOT include:
- Organization-specific security policies
- Production secret management (External Secrets, Vault)
- Production monitoring/alerting integration
- Disaster recovery configuration
- Compliance controls (audit logging, encryption at rest)
- NetworkPolicies specific to your environment
- SLOs and runbooks
- Backup procedures
- Incident response integration
- Cost optimization (right-sized resources)
- Multi-region deployment
- Production-grade mTLS (see Story 6-4)

## Configuration Details

- **Replicas:** 3
- **Exporters:** Prometheus, Cloud Logging, Cloud Trace, Langfuse
- **Log Level:** Info
- **Environment:** production
- **GCP Project:** bhsf-model-monitoring-prod
- **Region:** us-central1

## Testing This Overlay (Development Only)

This overlay can be used in development clusters to test the full telemetry pipeline:

```bash
# 1. Create secrets (use secret.yaml.example as template)
cp mca-prototype/k8s/base/secret.yaml.example secret.yaml
# Edit secret.yaml with actual credentials
kubectl apply -f secret.yaml -n monitoring

# 2. Deploy overlay
kubectl apply -k mca-prototype/k8s/overlays/prod

# 3. Verify deployment
kubectl get pods -n monitoring -l app=otel-collector
kubectl logs -n monitoring otel-collector-0 --tail=50
```

## For Production Deployment

Contact your infrastructure team. They should provide:

### Required Production Elements

1. **Infrastructure as Code**
   - Terraform or Helm configurations
   - Organization security policies
   - Multi-region deployment
   - Disaster recovery setup

2. **Secret Management**
   - External Secrets Operator integration
   - Vault integration
   - GCP Workload Identity
   - Automatic secret rotation

3. **Monitoring and Alerting**
   - Prometheus scraping configuration
   - Grafana dashboards
   - Alertmanager rules
   - PagerDuty/Opsgenie integration
   - SLOs and error budgets

4. **Security**
   - mTLS between SDK and collector
   - Pod Security Standards enforcement
   - NetworkPolicies for your environment
   - Audit logging integration
   - SIEM integration
   - Compliance controls (HIPAA, SOC2)

5. **Operational Readiness**
   - Runbooks for common issues
   - Incident response procedures
   - Capacity planning
   - Backup and restore procedures
   - Rollback procedures
   - Change management process

## Why This Is Not Production-Ready

This overlay is a **learning resource** and **development testing tool**. It shows what a production configuration might look like, but lacks the organizational context needed for actual production use:

- **Security:** Missing organization-specific policies and threat modeling
- **Compliance:** No HIPAA audit trails or compliance validation
- **Operations:** No integration with your monitoring/alerting/on-call systems
- **Cost:** Resource limits not optimized for your workload patterns
- **Reliability:** No multi-region deployment or tested disaster recovery
- **Secrets:** Uses kubectl-created secrets instead of proper secret management

## References

- [MCA SDK Production Deployment Guide](../../../docs/production-deployment.md)
- [Story 6-4: mTLS Implementation](../../../_bmad-output/implementation-artifacts/6-4-implement-mtls-for-sdk-to-collector-communication.md)
- [GCP Cloud Trace Exporter](https://github.com/open-telemetry/opentelemetry-collector-contrib/tree/main/exporter/googlecloudexporter)
- [Langfuse Integration](https://langfuse.com/docs/integrations/opentelemetry)
