# Dead Letter Queue (DLQ) Infrastructure

This directory contains scripts and configuration for the OTel Collector Dead Letter Queue (DLQ) using GCP Pub/Sub.

## Overview

The DLQ captures telemetry that fails to export after maximum retry attempts, preventing silent data loss. Failed messages can be investigated and replayed after issues are resolved.

## Files

- `create-dlq-topic.sh` - Creates GCP Pub/Sub topic and subscription for DLQ
- `dlq-replay-processor.py` - Python script to replay DLQ messages to Collector
- `README.md` - This file

## Setup

### 1. Create DLQ Topic and Subscription

```bash
cd mca-prototype/k8s/pubsub
chmod +x create-dlq-topic.sh
./create-dlq-topic.sh
```

This creates:
- Topic: `otel-collector-dlq`
- Subscription: `otel-collector-dlq-sub`
- IAM permissions for Collector service account

### 2. Configure Collector Exporters

The Collector configuration must be updated to use the DLQ for failed exports. This is done in the overlay configmap patches.

**Note:** DLQ support in OpenTelemetry Collector exporters varies by version. As of v0.146.1, DLQ is not yet natively supported by GCP exporters. The current implementation uses persistent queue (`storage: file_storage`) to prevent data loss.

**Future Enhancement:** When OTel Collector adds native DLQ support, update exporters with:

```yaml
exporters:
  googlecloud/logs:
    project: bhsf-model-monitoring-prod
    retry_on_failure:
      enabled: true
      initial_interval: 1s
      max_interval: 30s
      max_elapsed_time: 300s  # 5 minutes max retry
    sending_queue:
      enabled: true
      storage: file_storage
    # DLQ configuration (future enhancement)
    dead_letter_queue:
      topic: projects/bhsf-model-monitoring-prod/topics/otel-collector-dlq
      enabled: true
```

### 3. Monitor DLQ Messages

Check for messages in the DLQ:

```bash
gcloud pubsub subscriptions pull otel-collector-dlq-sub \
  --project=bhsf-model-monitoring-prod \
  --limit=10
```

### 4. Replay DLQ Messages

After resolving export issues, replay failed messages:

```bash
# Install dependencies
pip install google-cloud-pubsub requests

# Run replay processor
python dlq-replay-processor.py \
  --project bhsf-model-monitoring-prod \
  --subscription otel-collector-dlq-sub \
  --collector-url http://otel-collector:4318
```

## DLQ Message Format

Messages in the DLQ contain:

```json
{
  "telemetry": { ... },           // Original telemetry data
  "signal_type": "metrics",       // metrics, logs, or traces
  "error_reason": "...",          // Why export failed
  "failed_at": "2026-02-26T...",  // Timestamp of failure
  "original_endpoint": "..."      // Original export destination
}
```

## Alerting

Set up alerts for DLQ messages:

```bash
# Cloud Monitoring alert on message count
gcloud alpha monitoring policies create \
  --notification-channels=CHANNEL_ID \
  --display-name="OTel DLQ Messages" \
  --condition-display-name="DLQ has messages" \
  --condition-threshold-value=1 \
  --condition-threshold-duration=300s \
  --condition-metric-type="pubsub.googleapis.com/subscription/num_undelivered_messages" \
  --condition-filter='resource.type="pubsub_subscription" AND resource.label.subscription_id="otel-collector-dlq-sub"'
```

## Current Implementation Status

✅ **Implemented:**
- Pub/Sub topic and subscription creation script
- DLQ replay processor with error handling and statistics
- IAM permissions for Collector service account
- Message format specification
- Documentation and setup instructions

⏳ **Pending (Future Enhancement):**
- Native DLQ support in OTel Collector exporters
- Automatic DLQ publishing on export failure
- Cloud Monitoring alerts integration

📝 **Current Workaround:**
- Persistent queue with file storage prevents data loss
- Failed exports are retried with exponential backoff
- Queue persists across pod restarts via PersistentVolumes

## Testing

See `mca-prototype/tests/integration/test_dlq.py` for integration tests that verify:
1. DLQ topic and subscription exist
2. Replay processor can parse and replay messages
3. Failed exports are queued correctly
4. Statistics are tracked accurately

## References

- [GCP Pub/Sub Dead Letter Topics](https://cloud.google.com/pubsub/docs/dead-letter-topics)
- [OpenTelemetry Collector Configuration](https://opentelemetry.io/docs/collector/configuration/)
- [OTel Collector Persistent Queue](https://github.com/open-telemetry/opentelemetry-collector/tree/main/exporter/exporterhelper#persistent-queue)
