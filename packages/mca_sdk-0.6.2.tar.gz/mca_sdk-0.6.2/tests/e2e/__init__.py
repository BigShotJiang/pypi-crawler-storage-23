"""End-to-end tests for MCA SDK full workflow validation.

This package contains E2E tests that validate the complete telemetry flow:
SDK → OTel Collector → GCP backends (or mocks)

Tests verify:
- Metrics propagation to Cloud Monitoring
- Logs propagation to Cloud Logging
- Traces propagation to Cloud Trace
- Multi-model-type workflows
- Error recovery scenarios
"""
