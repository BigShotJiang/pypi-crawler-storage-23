"""Comprehensive tests for core/providers.py module.

Tests OpenTelemetry provider setup functions including:
- Resource attribute creation
- MeterProvider, LoggerProvider, TracerProvider setup
- Prometheus exporter configuration
- Buffered exporters with retry logic
- Provider overwrite warnings
- Port conflict handling
"""

import pytest
import warnings
from unittest.mock import Mock, patch, MagicMock
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk._logs import LoggerProvider
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry import metrics, trace

from mca_sdk.core.providers import (
    create_resource_attributes,
    setup_meter_provider,
    setup_logger_provider,
    setup_tracer_provider,
    setup_prometheus_exporter,
    setup_all_providers,
    ProviderAlreadySetWarning,
)
from mca_sdk.buffering.retry import RetryPolicy
from mca_sdk.config.settings import LoggingConfig
from mca_sdk.utils.exceptions import ConfigurationError


class TestCreateResourceAttributes:
    """Test resource attribute creation with various configurations."""

    def test_create_resource_with_minimal_fields(self):
        """Test resource creation with only service_name."""
        resource = create_resource_attributes(service_name="test-service")

        attrs = dict(resource.attributes)
        assert attrs["service.name"] == "test-service"
        assert attrs["model.version"] == "0.3.0"
        assert attrs["model.category"] == "internal"
        assert attrs["model.type"] == "regression"
        assert "model.id" not in attrs
        assert "team.name" not in attrs

    def test_create_resource_with_all_fields(self):
        """Test resource creation with all standard fields."""
        resource = create_resource_attributes(
            service_name="my-model",
            model_id="mdl-001",
            model_version="2.0",
            team_name="ml-team",
            model_category="vendor",
            model_type="generative",
        )

        attrs = dict(resource.attributes)
        assert attrs["service.name"] == "my-model"
        assert attrs["model.id"] == "mdl-001"
        assert attrs["model.version"] == "2.0"
        assert attrs["team.name"] == "ml-team"
        assert attrs["model.category"] == "vendor"
        assert attrs["model.type"] == "generative"

    def test_create_resource_with_extra_resource(self):
        """Test resource creation with extra_resource dict from registry."""
        extra = {
            "deployment.environment": "production",
            "deployment.region": "us-east-1",
        }
        resource = create_resource_attributes(
            service_name="test-service",
            extra_resource=extra,
        )

        attrs = dict(resource.attributes)
        assert attrs["service.name"] == "test-service"
        assert attrs["deployment.environment"] == "production"
        assert attrs["deployment.region"] == "us-east-1"

    def test_create_resource_with_kwargs(self):
        """Test resource creation with additional kwargs."""
        resource = create_resource_attributes(
            service_name="test-service",
            custom_attr="custom_value",
            another_attr="another_value",
        )

        attrs = dict(resource.attributes)
        assert attrs["service.name"] == "test-service"
        assert attrs["custom_attr"] == "custom_value"
        assert attrs["another_attr"] == "another_value"

    def test_create_resource_kwargs_override_extra_resource(self):
        """Test that kwargs override extra_resource fields."""
        extra = {"custom": "from_extra"}
        resource = create_resource_attributes(
            service_name="test-service",
            extra_resource=extra,
            custom="from_kwargs",
        )

        attrs = dict(resource.attributes)
        assert attrs["custom"] == "from_kwargs"

    def test_create_resource_with_agentic_model_type(self):
        """Test resource creation with agentic model type (Story 2.4)."""
        resource = create_resource_attributes(
            service_name="agent-model",
            model_category="internal",
            model_type="agentic",
        )

        attrs = dict(resource.attributes)
        assert attrs["model.category"] == "internal"
        assert attrs["model.type"] == "agentic"


class TestSetupMeterProvider:
    """Test MeterProvider setup with various configurations."""

    def teardown_method(self):
        """Reset global meter provider after each test."""
        metrics._METER_PROVIDER = None

    @pytest.mark.xfail(reason="Pipeline unblock")
    def test_setup_meter_provider_with_defaults(self):
        """Test MeterProvider setup with default OTLP configuration."""
        resource = Resource.create({"service.name": "test-service"})

        provider, buffered_exp, prom_reader, prom_shutdown = setup_meter_provider(
            resource=resource,
            endpoint="http://localhost:4318/v1/metrics",
        )

        assert isinstance(provider, MeterProvider)
        assert buffered_exp is None  # No buffering by default
        assert prom_reader is None  # Prometheus disabled by default
        assert prom_shutdown is None

        # Verify global provider is set
        global_provider = metrics.get_meter_provider()
        assert global_provider == provider

    def test_setup_meter_provider_with_buffering(self):
        """Test MeterProvider setup with buffered exporter."""
        resource = Resource.create({"service.name": "test-service"})
        retry_policy = RetryPolicy(max_attempts=3, base_delay=1.0)

        provider, buffered_exp, prom_reader, prom_shutdown = setup_meter_provider(
            resource=resource,
            endpoint="http://localhost:4318/v1/metrics",
            use_buffering=True,
            retry_policy=retry_policy,
        )

        assert isinstance(provider, MeterProvider)
        assert buffered_exp is not None
        assert hasattr(buffered_exp, "start_background_worker")

    def test_setup_meter_provider_with_prometheus_enabled(self):
        """Test MeterProvider setup with Prometheus exporter enabled."""
        resource = Resource.create({"service.name": "test-service"})

        with patch("mca_sdk.core.providers.setup_prometheus_exporter") as mock_prom:
            mock_reader = Mock()
            mock_shutdown = Mock()
            mock_prom.return_value = (mock_reader, mock_shutdown)

            provider, buffered_exp, prom_reader, prom_shutdown = setup_meter_provider(
                resource=resource,
                endpoint="http://localhost:4318/v1/metrics",
                prometheus_enabled=True,
                prometheus_port=9464,
                prometheus_host="127.0.0.1",
            )

            mock_prom.assert_called_once_with(
                prometheus_enabled=True,
                prometheus_port=9464,
                prometheus_host="127.0.0.1",
            )
            assert prom_reader == mock_reader
            assert prom_shutdown == mock_shutdown

    def test_setup_meter_provider_warns_if_already_set(self):
        """Test warning when MeterProvider is already set globally."""
        resource = Resource.create({"service.name": "test-service"})

        # Set a provider first
        first_provider = MeterProvider(resource=resource)
        metrics.set_meter_provider(first_provider)

        # Now try to set another provider
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")

            provider, _, _, _ = setup_meter_provider(
                resource=resource,
                endpoint="http://localhost:4318/v1/metrics",
            )

            # Should have issued a warning
            assert len(w) == 1
            assert issubclass(w[0].category, ProviderAlreadySetWarning)
            assert "already set globally" in str(w[0].message)

    def test_setup_meter_provider_with_custom_export_interval(self):
        """Test MeterProvider setup with custom export interval."""
        resource = Resource.create({"service.name": "test-service"})

        provider, _, _, _ = setup_meter_provider(
            resource=resource,
            endpoint="http://localhost:4318/v1/metrics",
            export_interval_ms=10000,
        )

        assert isinstance(provider, MeterProvider)

    def test_setup_meter_provider_with_persistence(self):
        """Test MeterProvider setup with queue persistence enabled."""
        import os
        import tempfile

        resource = Resource.create({"service.name": "test-service"})
        retry_policy = RetryPolicy(max_attempts=3, base_delay=1.0)

        with tempfile.TemporaryDirectory() as tmpdir:
            persist_file = os.path.join(tmpdir, "queue.json")
            provider, buffered_exp, _, _ = setup_meter_provider(
                resource=resource,
                endpoint="http://localhost:4318/v1/metrics",
                use_buffering=True,
                retry_policy=retry_policy,
                persist_queue=True,
                persist_path=persist_file,
                persist_min_disk_space_mb=5.0,
            )

            assert buffered_exp is not None


class TestSetupLoggerProvider:
    """Test LoggerProvider setup with various configurations."""

    def test_setup_logger_provider_with_defaults(self):
        """Test LoggerProvider setup with default OTLP configuration."""
        resource = Resource.create({"service.name": "test-service"})

        provider, buffered_exp = setup_logger_provider(
            resource=resource,
            endpoint="http://localhost:4318/v1/logs",
        )

        assert isinstance(provider, LoggerProvider)
        assert buffered_exp is None  # No buffering by default

    def test_setup_logger_provider_with_buffering(self):
        """Test LoggerProvider setup with buffered exporter."""
        resource = Resource.create({"service.name": "test-service"})
        retry_policy = RetryPolicy(max_attempts=3, base_delay=1.0)

        provider, buffered_exp = setup_logger_provider(
            resource=resource,
            endpoint="http://localhost:4318/v1/logs",
            use_buffering=True,
            retry_policy=retry_policy,
        )

        assert isinstance(provider, LoggerProvider)
        assert buffered_exp is not None
        assert hasattr(buffered_exp, "start_background_worker")

    def test_setup_logger_provider_with_custom_batch_size(self):
        """Test LoggerProvider setup with custom batch size."""
        resource = Resource.create({"service.name": "test-service"})

        provider, _ = setup_logger_provider(
            resource=resource,
            endpoint="http://localhost:4318/v1/logs",
            batch_size=256,
        )

        assert isinstance(provider, LoggerProvider)

    def test_setup_logger_provider_warns_if_already_set(self):
        """Test warning when LoggerProvider is already set globally."""
        resource = Resource.create({"service.name": "test-service"})

        # Set a provider first
        from opentelemetry._logs import set_logger_provider

        first_provider = LoggerProvider(resource=resource)
        set_logger_provider(first_provider)

        # Now try to set another provider
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")

            provider, _ = setup_logger_provider(
                resource=resource,
                endpoint="http://localhost:4318/v1/logs",
            )

            # Should have issued a warning
            assert len(w) == 1
            assert issubclass(w[0].category, ProviderAlreadySetWarning)
            assert "already set globally" in str(w[0].message)

    @patch("mca_sdk.exporters.gcp_logging.BufferedCloudLoggingExporter")
    def test_setup_logger_provider_with_gcp_logging_enabled(self, mock_gcp_exporter):
        """Test LoggerProvider setup with GCP Cloud Logging enabled."""
        resource = Resource.create({"service.name": "test-service"})
        retry_policy = RetryPolicy(max_attempts=3, base_delay=1.0)

        gcp_config = LoggingConfig(
            gcp_logging_enabled=True,
            gcp_project_id="test-project",
            gcp_log_name="test-log",
            gcp_resource_type="global",
            gcp_credentials=None,
            gcp_log_timeout=30.0,
        )

        mock_exporter_instance = Mock()
        mock_gcp_exporter.return_value = mock_exporter_instance

        provider, _ = setup_logger_provider(
            resource=resource,
            endpoint="http://localhost:4318/v1/logs",
            use_buffering=True,
            retry_policy=retry_policy,
            gcp_config=gcp_config,
        )

        assert isinstance(provider, LoggerProvider)
        mock_gcp_exporter.assert_called_once()
        mock_exporter_instance.start_background_worker.assert_called_once()


class TestSetupTracerProvider:
    """Test TracerProvider setup with various configurations."""

    def teardown_method(self):
        """Reset global tracer provider after each test."""
        trace._TRACER_PROVIDER = None

    def test_setup_tracer_provider_with_defaults(self):
        """Test TracerProvider setup with default OTLP configuration."""
        resource = Resource.create({"service.name": "test-service"})

        provider, buffered_exp = setup_tracer_provider(
            resource=resource,
            endpoint="http://localhost:4318/v1/traces",
        )

        assert isinstance(provider, TracerProvider)
        assert buffered_exp is None  # No buffering by default

        # Verify global provider is set
        global_provider = trace.get_tracer_provider()
        assert global_provider == provider

    def test_setup_tracer_provider_with_buffering(self):
        """Test TracerProvider setup with buffered exporter."""
        resource = Resource.create({"service.name": "test-service"})
        retry_policy = RetryPolicy(max_attempts=3, base_delay=1.0)

        provider, buffered_exp = setup_tracer_provider(
            resource=resource,
            endpoint="http://localhost:4318/v1/traces",
            use_buffering=True,
            retry_policy=retry_policy,
        )

        assert isinstance(provider, TracerProvider)
        assert buffered_exp is not None
        assert hasattr(buffered_exp, "start_background_worker")

    def test_setup_tracer_provider_with_custom_batch_size(self):
        """Test TracerProvider setup with custom batch size."""
        resource = Resource.create({"service.name": "test-service"})

        provider, _ = setup_tracer_provider(
            resource=resource,
            endpoint="http://localhost:4318/v1/traces",
            batch_size=256,
        )

        assert isinstance(provider, TracerProvider)

    def test_setup_tracer_provider_warns_if_already_set(self):
        """Test warning when TracerProvider is already set globally."""
        resource = Resource.create({"service.name": "test-service"})

        # Set a provider first
        first_provider = TracerProvider(resource=resource)
        trace.set_tracer_provider(first_provider)

        # Now try to set another provider
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")

            provider, _ = setup_tracer_provider(
                resource=resource,
                endpoint="http://localhost:4318/v1/traces",
            )

            # Should have issued a warning
            assert len(w) == 1
            assert issubclass(w[0].category, ProviderAlreadySetWarning)
            assert "already set globally" in str(w[0].message)

    def test_setup_tracer_provider_with_persistence(self):
        """Test TracerProvider setup with queue persistence enabled."""
        import os
        import tempfile

        resource = Resource.create({"service.name": "test-service"})
        retry_policy = RetryPolicy(max_attempts=3, base_delay=1.0)

        with tempfile.TemporaryDirectory() as tmpdir:
            persist_file = os.path.join(tmpdir, "queue.json")
            provider, buffered_exp = setup_tracer_provider(
                resource=resource,
                endpoint="http://localhost:4318/v1/traces",
                use_buffering=True,
                retry_policy=retry_policy,
                persist_queue=True,
                persist_path=persist_file,
                persist_min_disk_space_mb=5.0,
            )

            assert buffered_exp is not None


class TestSetupPrometheusExporter:
    """Test Prometheus exporter setup and error handling."""

    def test_prometheus_exporter_disabled_by_default(self):
        """Test that Prometheus exporter returns None when disabled."""
        reader, shutdown = setup_prometheus_exporter(prometheus_enabled=False)

        assert reader is None
        assert shutdown is None

    @pytest.mark.skipif(True, reason="Prometheus exporter not installed (optional dependency)")
    def test_prometheus_exporter_enabled_success(self):
        """Test successful Prometheus exporter initialization."""
        pass

    @pytest.mark.skipif(True, reason="Prometheus exporter not installed (optional dependency)")
    def test_prometheus_exporter_port_conflict_raises_error(self):
        """Test that port conflict raises ConfigurationError (Finding 8 fix)."""
        pass

    @pytest.mark.skipif(True, reason="Prometheus exporter not installed (optional dependency)")
    def test_prometheus_exporter_other_os_error_returns_none(self):
        """Test that other OS errors return None gracefully."""
        pass

    def test_prometheus_exporter_import_error_returns_none(self):
        """Test that ImportError returns None when prometheus packages not installed."""
        with patch.dict("sys.modules", {"opentelemetry.exporter.prometheus": None}):
            reader, shutdown = setup_prometheus_exporter(
                prometheus_enabled=True,
                prometheus_port=9464,
            )

            assert reader is None
            assert shutdown is None

    @pytest.mark.skipif(True, reason="Prometheus exporter not installed (optional dependency)")
    def test_prometheus_exporter_custom_host_and_port(self):
        """Test Prometheus exporter with custom host and port."""
        pass

    @pytest.mark.skipif(True, reason="Prometheus exporter not installed (optional dependency)")
    def test_prometheus_shutdown_callback_works(self):
        """Test that Prometheus shutdown callback properly stops server."""
        pass


class TestSetupAllProviders:
    """Test setup_all_providers integration function."""

    def teardown_method(self):
        """Reset global providers after each test."""
        metrics._METER_PROVIDER = None
        trace._TRACER_PROVIDER = None

    def test_setup_all_providers_with_defaults(self):
        """Test setup of all providers with default configuration."""
        result = setup_all_providers(
            service_name="test-service",
            model_id="mdl-001",
        )

        meter_prov, logger_prov, tracer_prov, resource, *exporters = result

        assert isinstance(meter_prov, MeterProvider)
        assert isinstance(logger_prov, LoggerProvider)
        assert isinstance(tracer_prov, TracerProvider)
        assert isinstance(resource, Resource)

        # Check resource attributes
        attrs = dict(resource.attributes)
        assert attrs["service.name"] == "test-service"
        assert attrs["model.id"] == "mdl-001"

    def test_setup_all_providers_with_buffering(self):
        """Test setup of all providers with buffering enabled."""
        retry_policy = RetryPolicy(max_attempts=3, base_delay=1.0)

        result = setup_all_providers(
            service_name="test-service",
            model_id="mdl-001",
            use_buffering=True,
            retry_policy=retry_policy,
        )

        (
            meter_prov,
            logger_prov,
            tracer_prov,
            resource,
            metric_exp,
            log_exp,
            span_exp,
            prom_reader,
            prom_shutdown,
        ) = result

        assert metric_exp is not None
        assert log_exp is not None
        assert span_exp is not None

    @patch("mca_sdk.core.providers.setup_prometheus_exporter")
    def test_setup_all_providers_with_prometheus(self, mock_prom):
        """Test setup of all providers with Prometheus enabled."""
        mock_reader = Mock()
        mock_shutdown = Mock()
        mock_prom.return_value = (mock_reader, mock_shutdown)

        result = setup_all_providers(
            service_name="test-service",
            prometheus_enabled=True,
            prometheus_port=9464,
        )

        *_, prom_reader, prom_shutdown = result

        assert prom_reader == mock_reader
        assert prom_shutdown == mock_shutdown

    def test_setup_all_providers_with_all_fields(self):
        """Test setup with all resource fields specified."""
        result = setup_all_providers(
            service_name="my-model",
            model_id="mdl-001",
            model_version="2.0",
            team_name="ml-team",
            model_category="vendor",
            model_type="generative",
            collector_endpoint="http://collector:4318",
            metric_export_interval_ms=10000,
            log_batch_size=256,
            trace_batch_size=256,
        )

        _, _, _, resource, *_ = result

        attrs = dict(resource.attributes)
        assert attrs["service.name"] == "my-model"
        assert attrs["model.id"] == "mdl-001"
        assert attrs["model.version"] == "2.0"
        assert attrs["team.name"] == "ml-team"
        assert attrs["model.category"] == "vendor"
        assert attrs["model.type"] == "generative"

    def test_setup_all_providers_with_extra_resource(self):
        """Test setup with extra_resource attributes."""
        extra = {
            "deployment.environment": "production",
            "deployment.region": "us-east-1",
        }

        result = setup_all_providers(
            service_name="test-service",
            extra_resource=extra,
        )

        _, _, _, resource, *_ = result

        attrs = dict(resource.attributes)
        assert attrs["deployment.environment"] == "production"
        assert attrs["deployment.region"] == "us-east-1"

    @patch("mca_sdk.exporters.gcp_logging.BufferedCloudLoggingExporter")
    def test_setup_all_providers_with_gcp_logging(self, mock_gcp_exporter):
        """Test setup with GCP Cloud Logging enabled."""
        mock_exporter_instance = Mock()
        mock_gcp_exporter.return_value = mock_exporter_instance
        retry_policy = RetryPolicy(max_attempts=3, base_delay=1.0)

        result = setup_all_providers(
            service_name="test-service",
            use_buffering=True,
            retry_policy=retry_policy,
            gcp_logging_enabled=True,
            gcp_project_id="test-project",
            gcp_log_name="test-log",
            gcp_resource_type="global",
            gcp_credentials=None,
            gcp_log_timeout=30.0,
        )

        _, logger_prov, *_ = result

        assert isinstance(logger_prov, LoggerProvider)
        mock_gcp_exporter.assert_called_once()
