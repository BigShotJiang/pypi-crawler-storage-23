"""Unit tests for mca_sdk.utils.serialization module."""

import json
import logging
import pytest
from dataclasses import dataclass
from unittest.mock import MagicMock, patch

from mca_sdk.utils.serialization import serialize_for_telemetry, _json_default


class TestSerializeForTelemetry:
    """Test suite for serialize_for_telemetry function."""

    def test_serialize_simple_dict(self):
        """Test that simple dicts are returned unchanged (OTel-compatible type)."""
        data = {"key": "value", "number": 42}
        result = serialize_for_telemetry(data)
        assert result == data

    def test_serialize_simple_list(self):
        """Test that simple lists are returned unchanged (OTel-compatible type)."""
        data = [1, 2, 3, 4, 5]
        result = serialize_for_telemetry(data)
        assert result == data

    def test_serialize_string(self):
        """Test that strings are returned unchanged (OTel-compatible type)."""
        data = "hello world"
        result = serialize_for_telemetry(data)
        assert result == "hello world"

    def test_serialize_number(self):
        """Test that numbers are returned unchanged (OTel-compatible type)."""
        assert serialize_for_telemetry(42) == 42
        assert serialize_for_telemetry(3.14) == 3.14

    def test_serialize_boolean(self):
        """Test that booleans are returned unchanged (OTel-compatible type)."""
        assert serialize_for_telemetry(True) is True
        assert serialize_for_telemetry(False) is False

    def test_serialize_none(self):
        """Test that None is returned unchanged (OTel-compatible type)."""
        assert serialize_for_telemetry(None) is None

    def test_serialize_nested_structure(self):
        """Test that nested dicts are returned unchanged (OTel-compatible type)."""
        data = {
            "users": [{"name": "Alice", "age": 30}, {"name": "Bob", "age": 25}],
            "metadata": {"count": 2, "active": True},
        }
        result = serialize_for_telemetry(data)
        assert result == data

    def test_truncate_large_payload(self):
        """Test truncation of payload exceeding max_length."""
        data = "a" * 1000
        result = serialize_for_telemetry(data, max_length=100)
        assert len(result) == 100
        assert result.endswith("...[truncated]")

    def test_truncate_with_custom_marker(self):
        """Test truncation with custom truncation marker."""
        data = "x" * 500
        result = serialize_for_telemetry(data, max_length=50, truncate_marker="...")
        assert len(result) == 50
        assert result.endswith("...")

    def test_truncate_marker_longer_than_max_length(self):
        """Test edge case where truncation marker is longer than max_length."""
        data = "x" * 20  # Long enough to exceed max_length=5 and trigger truncation
        result = serialize_for_telemetry(data, max_length=5, truncate_marker="...[truncated]")
        assert result == "...[truncated]"

    def test_no_truncation_under_limit(self):
        """Test that data under max_length is not truncated (custom objects)."""

        class SmallObj:
            def __init__(self):
                self.key = "value"

        obj = SmallObj()
        result = serialize_for_telemetry(obj, max_length=1000)
        assert isinstance(result, str)
        assert "truncated" not in result

    def test_fallback_to_str_on_serialization_error(self):
        """Test fallback to str() when JSON serialization fails."""

        class NonSerializable:
            def __str__(self):
                return "NonSerializable instance"

            def __repr__(self):
                return "NonSerializable instance"

        obj = NonSerializable()
        result = serialize_for_telemetry(obj)
        # Should serialize using __dict__ which contains the __str__ method
        assert isinstance(result, str)

    def test_unicode_characters_preserved(self):
        """Test that Unicode characters are preserved in dicts returned unchanged."""
        data = {"message": "Hello 世界 🌍"}
        result = serialize_for_telemetry(data)
        assert result["message"] == "Hello 世界 🌍"

    def test_empty_dict(self):
        """Test that empty dict is returned unchanged."""
        assert serialize_for_telemetry({}) == {}

    def test_empty_list(self):
        """Test that empty list is returned unchanged."""
        assert serialize_for_telemetry([]) == []


class TestJsonDefault:
    """Test suite for _json_default custom JSON encoder."""

    def test_numpy_array_with_tolist(self):
        """Test serialization of object with tolist() method (NumPy-like)."""

        class NumpyLike:
            def tolist(self):
                return [1, 2, 3, 4, 5]

        obj = NumpyLike()
        result = _json_default(obj)
        assert result == [1, 2, 3, 4, 5]

    def test_pandas_dataframe_with_to_dict(self):
        """Test serialization of object with to_dict() method (Pandas-like)."""

        class PandasLike:
            def to_dict(self):
                return {"col1": [1, 2, 3], "col2": [4, 5, 6]}

        obj = PandasLike()
        result = _json_default(obj)
        assert result == {"col1": [1, 2, 3], "col2": [4, 5, 6]}

    def test_dataclass_serialization(self):
        """Test serialization of dataclass objects."""

        @dataclass
        class Person:
            name: str
            age: int

        person = Person(name="Alice", age=30)
        result = _json_default(person)
        assert result == {"name": "Alice", "age": 30}

    def test_custom_class_with_dict(self):
        """Test serialization of custom class using __dict__."""

        class CustomClass:
            def __init__(self):
                self.attr1 = "value1"
                self.attr2 = 42

        obj = CustomClass()
        result = _json_default(obj)
        assert result == {"attr1": "value1", "attr2": 42}

    def test_fallback_to_str(self):
        """Test final fallback to str() when no serialization method works."""

        # Use a builtin type that doesn't have serialization methods
        class MinimalClass:
            pass

        obj = MinimalClass()
        result = _json_default(obj)
        # Should return the __dict__ or str representation
        assert isinstance(result, (dict, str))

    def test_tolist_failure_fallback(self, caplog):
        """Test fallback when tolist() raises exception."""

        class BrokenToList:
            def tolist(self):
                raise ValueError("tolist failed")

            def to_dict(self):
                return {"fallback": "to_dict"}

        obj = BrokenToList()
        with caplog.at_level(logging.WARNING):
            result = _json_default(obj)

        assert result == {"fallback": "to_dict"}
        assert "Failed to serialize" in caplog.text
        assert "tolist()" in caplog.text

    def test_to_dict_failure_fallback(self, caplog):
        """Test fallback when to_dict() raises exception."""

        class BrokenToDict:
            def to_dict(self):
                raise TypeError("to_dict failed")

        obj = BrokenToDict()
        with caplog.at_level(logging.WARNING):
            result = _json_default(obj)

        # Should fall back to __dict__
        assert isinstance(result, dict)
        assert "Failed to serialize" in caplog.text

    def test_dataclass_failure_fallback(self, caplog):
        """Test fallback when dataclass serialization fails."""

        class BrokenDataclass:
            __dataclass_fields__ = {"field": "metadata"}

            def __getattribute__(self, name):
                if name == "field":
                    raise AttributeError("field access failed")
                return super().__getattribute__(name)

            __dict__ = {"fallback": "dict"}

        obj = BrokenDataclass()
        with caplog.at_level(logging.WARNING):
            result = _json_default(obj)

        # Should fall back to __dict__
        assert isinstance(result, dict)

    def test_dict_failure_final_fallback(self, caplog):
        """Test str() fallback when no other method works."""

        # Create an object without common serialization methods
        obj = object()  # Builtin object type

        with caplog.at_level(logging.DEBUG):
            result = _json_default(obj)

        # Should use str() fallback for object()
        assert isinstance(result, str)
        assert "object" in result

    def test_logging_debug_messages(self, caplog):
        """Test that debug logging works for successful serializations."""

        class SimpleClass:
            def tolist(self):
                return [1, 2, 3]

        obj = SimpleClass()
        with caplog.at_level(logging.DEBUG):
            _json_default(obj)

        assert "Serialized" in caplog.text
        assert "tolist()" in caplog.text

    def test_mixed_serialization_methods(self):
        """Test object with multiple serialization methods uses first available."""

        class MultiMethod:
            def tolist(self):
                return [1, 2, 3]

            def to_dict(self):
                return {"should": "not reach this"}

        obj = MultiMethod()
        result = _json_default(obj)
        # Should use tolist() since it's checked first
        assert result == [1, 2, 3]


class TestIntegrationScenarios:
    """Integration tests for real-world serialization scenarios."""

    def test_complex_nested_with_custom_objects(self):
        """Test serialization of custom objects (non-dict) with nested attrs."""

        class Model:
            def __init__(self, name, version):
                self.name = name
                self.version = version

        # Pass the custom object directly (not wrapped in a dict) to trigger _json_default
        obj = Model("classifier", "1.0")
        result = serialize_for_telemetry(obj)

        parsed = json.loads(result)
        assert parsed["name"] == "classifier"
        assert parsed["version"] == "1.0"

    def test_large_dataset_truncation_preserves_structure(self):
        """Test that truncation happens at correct position for custom objects."""

        class LargeObj:
            def __init__(self):
                self.data = "x" * 10000

        obj = LargeObj()
        result = serialize_for_telemetry(obj, max_length=100)

        assert len(result) == 100
        assert result.startswith('{"data"')
        assert result.endswith("...[truncated]")

    def test_serialization_exception_types(self):
        """Test handling of different JSON serialization exception types."""

        # Object that has __dict__ will be serialized successfully
        class RegularObj:
            def __init__(self):
                self.value = "handled"

        obj = RegularObj()
        result = serialize_for_telemetry(obj)

        # Should serialize successfully using __dict__
        assert "value" in result
        assert "handled" in result
