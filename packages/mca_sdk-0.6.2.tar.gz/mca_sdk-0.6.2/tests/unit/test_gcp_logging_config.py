"""Unit tests for GCP Cloud Logging configuration.

Story 6.2: Implement GCP Cloud Logging Exporter
Tests configuration parameters for Cloud Logging integration.
"""

import pytest
from mca_sdk.config import MCAConfig
from mca_sdk.utils.exceptions import ConfigurationError


class TestGCPLoggingConfiguration:
    """Test GCP Cloud Logging configuration parameters."""

    def test_gcp_logging_disabled_by_default(self):
        """Test that GCP logging is disabled by default."""
        config = MCAConfig(service_name="test-service")
        assert config.gcp_logging_enabled is False

    def test_gcp_logging_can_be_enabled(self):
        """Test that GCP logging can be enabled via config."""
        config = MCAConfig(
            service_name="test-service", gcp_logging_enabled=True, gcp_project_id="test-project-123"
        )
        assert config.gcp_logging_enabled is True
        assert config.gcp_project_id == "test-project-123"

    def test_gcp_logging_requires_project_id_when_enabled(self):
        """Test that enabling GCP logging without project_id raises error."""
        with pytest.raises(ConfigurationError, match="gcp_project_id is required"):
            MCAConfig(service_name="test-service", gcp_logging_enabled=True)

    def test_gcp_logging_project_id_validation(self):
        """Test that invalid project IDs are rejected."""
        # Valid project ID
        config = MCAConfig(
            service_name="test-service", gcp_logging_enabled=True, gcp_project_id="my-project-123"
        )
        assert config.gcp_project_id == "my-project-123"

        # Invalid: too short
        with pytest.raises(ConfigurationError, match="Invalid GCP project_id"):
            MCAConfig(service_name="test-service", gcp_logging_enabled=True, gcp_project_id="abc")

        # Invalid: uppercase
        with pytest.raises(ConfigurationError, match="Invalid GCP project_id"):
            MCAConfig(
                service_name="test-service", gcp_logging_enabled=True, gcp_project_id="MyProject"
            )

    def test_gcp_logging_log_name_configuration(self):
        """Test configuration of custom log name."""
        config = MCAConfig(
            service_name="test-service",
            gcp_logging_enabled=True,
            gcp_project_id="test-project",
            gcp_log_name="my-custom-log",
        )
        assert config.gcp_log_name == "my-custom-log"

    def test_gcp_logging_default_log_name(self):
        """Test that default log name is service_name."""
        config = MCAConfig(
            service_name="test-service", gcp_logging_enabled=True, gcp_project_id="test-project"
        )
        assert config.gcp_log_name == "test-service"

    def test_gcp_logging_severity_filter(self):
        """Test configuration of minimum log severity."""
        config = MCAConfig(
            service_name="test-service",
            gcp_logging_enabled=True,
            gcp_project_id="test-project",
            gcp_log_min_severity="WARNING",
        )
        assert config.gcp_log_min_severity == "WARNING"

    def test_gcp_logging_invalid_severity(self):
        """Test that invalid severity levels are rejected."""
        with pytest.raises(ConfigurationError, match="Invalid log severity"):
            MCAConfig(
                service_name="test-service",
                gcp_logging_enabled=True,
                gcp_project_id="test-project",
                gcp_log_min_severity="INVALID",
            )

    def test_gcp_logging_with_credentials_path(self):
        """Test GCP logging with service account credentials."""
        config = MCAConfig(
            service_name="test-service",
            gcp_logging_enabled=True,
            gcp_project_id="test-project",
            gcp_credentials_path="/path/to/service-account.json",
        )
        assert config.gcp_logging_enabled is True
        assert config.gcp_credentials_path == "/path/to/service-account.json"

    def test_gcp_logging_environment_variables(self, monkeypatch):
        """Test GCP logging configuration from environment variables."""
        monkeypatch.setenv("MCA_SERVICE_NAME", "test-service")
        monkeypatch.setenv("MCA_GCP_LOGGING_ENABLED", "true")
        monkeypatch.setenv("MCA_GCP_PROJECT_ID", "env-project")
        monkeypatch.setenv("MCA_GCP_LOG_NAME", "env-log")

        config = MCAConfig.from_env()

        assert config.gcp_logging_enabled is True
        assert config.gcp_project_id == "env-project"
        assert config.gcp_log_name == "env-log"

    def test_gcp_logging_resource_type_configuration(self):
        """Test configuration of GCP resource type."""
        config = MCAConfig(
            service_name="test-service",
            gcp_logging_enabled=True,
            gcp_project_id="test-project",
            gcp_resource_type="k8s_container",
        )
        assert config.gcp_resource_type == "k8s_container"

    def test_gcp_logging_default_resource_type(self):
        """Test that default resource type is 'global'."""
        config = MCAConfig(
            service_name="test-service", gcp_logging_enabled=True, gcp_project_id="test-project"
        )
        assert config.gcp_resource_type == "global"
