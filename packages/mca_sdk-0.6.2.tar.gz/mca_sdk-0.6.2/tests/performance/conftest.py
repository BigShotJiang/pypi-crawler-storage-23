"""Pytest configuration for performance tests.

Provides fixtures and configuration for performance, load, and stress testing.
"""

import os
import pytest
import warnings


def get_collector_endpoint() -> str:
    """Get collector endpoint from environment or default to localhost.

    Returns:
        Collector endpoint URL (defaults to http://localhost:4318)

    Environment Variables:
        MCA_TEST_COLLECTOR_ENDPOINT: Override default collector endpoint for CI/CD
    """
    return os.environ.get("MCA_TEST_COLLECTOR_ENDPOINT", "http://localhost:4318")


@pytest.fixture
def mca_client_config():
    """Standard MCAClient configuration for performance tests.

    Uses new two-field taxonomy to avoid deprecation warnings.
    Collector endpoint can be overridden via MCA_TEST_COLLECTOR_ENDPOINT env var.

    Returns:
        Dict with common client configuration
    """
    return {
        "model_category": "internal",
        "model_type": "regression",
        "collector_endpoint": get_collector_endpoint(),
        "buffering_enabled": True,
    }


@pytest.fixture(autouse=True)
def filter_expected_warnings():
    """Filter expected warnings that are normal in test scenarios.

    Multiple MCAClient instances in tests will naturally overwrite global
    providers - this is expected test behavior and not a production issue.
    """
    # Filter ProviderAlreadySetWarning - expected when creating multiple clients in tests
    warnings.filterwarnings(
        "ignore",
        message="Overriding of current .* is not allowed",
        category=Warning,
    )

    warnings.filterwarnings(
        "ignore",
        message=".*Provider is already set globally.*",
        category=Warning,
    )

    # Filter MeterProvider shutdown warnings - expected in tests
    warnings.filterwarnings(
        "ignore",
        message="A shutdown.*can not provide.*",
        category=Warning,
    )


def pytest_configure(config):
    """Register custom markers for performance tests."""
    config.addinivalue_line("markers", "benchmark: Benchmark test for performance measurement")
