"""Shared utilities for performance testing.

FIX #7: Eliminates code duplication across test_performance.py,
profile_overhead.py, and generate_overhead_report.py.

This module provides a factory function that can be imported by both
pytest tests AND standalone scripts.
"""

from mca_sdk import MCAClient


def create_benchmark_client():
    """Create MCAClient with standard benchmark configuration.

    FIX #7: Single source of truth for benchmark client configuration.
    Used by:
    - test_performance.py (pytest tests)
    - profile_overhead.py (standalone script)
    - generate_overhead_report.py (standalone script)

    Returns:
        MCAClient: Configured client for benchmarking with:
            - service_name: "benchmark"
            - model_id: "benchmark-model-001"
            - team_name: "performance-team"
            - model_category: "internal"
            - model_type: "classification"
            - strict_validation: True (production default)

    Usage:
        from tests.performance.utils import create_benchmark_client

        client = create_benchmark_client()
        # ... test/benchmark code ...
        client.shutdown()
    """
    return MCAClient(
        service_name="benchmark",
        model_id="benchmark-model-001",
        team_name="performance-team",
        model_category="internal",
        model_type="classification",
        strict_validation=True,
    )
