#!/bin/bash
# Run Story 6-8 load tests with comprehensive reporting
#
# Usage:
#   ./run_load_tests.sh [scenario]
#
# Scenarios:
#   all      - Run all 4 scenarios (default)
#   constant - Run constant load (60s at 1000 RPS)
#   ramp     - Run ramp-up scenario
#   burst    - Run burst load scenario
#   spike    - Run spike recovery scenario
#   quick    - Run quick validation (single scenario, 10s)

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

SCENARIO="${1:-all}"

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}MCA SDK Load Testing - Story 6-8${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# Check if collector is running
echo "Checking OTel Collector..."
if docker ps | grep -q mca-otel-collector; then
    echo -e "${GREEN}✓ OTel Collector is running${NC}"
else
    echo -e "${YELLOW}⚠ OTel Collector not detected${NC}"
    echo "Starting collector..."
    cd ../..
    docker compose up -d otel-collector
    sleep 10
    cd tests/performance
    echo -e "${GREEN}✓ Collector started${NC}"
fi

# Wait for collector health check
echo "Waiting for collector health check..."
max_retries=30
retry_count=0
while [ $retry_count -lt $max_retries ]; do
    if curl -s http://localhost:13133/health/status | grep -q "Server available"; then
        echo -e "${GREEN}✓ Collector is healthy${NC}"
        break
    fi
    retry_count=$((retry_count + 1))
    sleep 1
done

if [ $retry_count -eq $max_retries ]; then
    echo -e "${RED}✗ Collector health check failed${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}Running load tests: ${SCENARIO}${NC}"
echo ""

case "$SCENARIO" in
    all)
        echo "Running comprehensive load test suite..."
        pytest test_load_testing.py::test_load_scenarios_1000_rps -v -s --log-cli-level=INFO
        ;;
    constant)
        echo "Running constant load scenario..."
        pytest test_load_testing.py::test_constant_load_60s_1000rps -v -s --log-cli-level=INFO
        ;;
    ramp)
        echo "Running ramp-up scenario..."
        pytest test_load_testing.py::test_ramp_up_scenario -v -s --log-cli-level=INFO
        ;;
    burst)
        echo "Running burst load scenario..."
        pytest test_load_testing.py::test_burst_load_scenario -v -s --log-cli-level=INFO
        ;;
    spike)
        echo "Running spike recovery scenario..."
        python3 load_test_scenarios.py --scenario spike
        ;;
    quick)
        echo "Running quick validation (10s)..."
        python3 load_test_scenarios.py --scenario constant --duration 10
        ;;
    completeness)
        echo "Running telemetry completeness test..."
        pytest test_load_testing.py::test_telemetry_completeness_under_load -v -s --log-cli-level=INFO
        ;;
    *)
        echo -e "${RED}Unknown scenario: $SCENARIO${NC}"
        echo "Valid scenarios: all, constant, ramp, burst, spike, quick, completeness"
        exit 1
        ;;
esac

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Load Tests Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# Show results
if [ -d "results" ]; then
    echo "Generated reports:"
    ls -lh results/ | grep "$(date +%Y%m%d)" || echo "No reports from today"
    echo ""
    echo "View latest report:"
    latest_report=$(ls -t results/load_test_report_*.md 2>/dev/null | head -1)
    if [ -n "$latest_report" ]; then
        echo "  cat $latest_report"
    fi
fi
