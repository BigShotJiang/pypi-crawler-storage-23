# Internal Model Example

This example demonstrates how to instrument an internal ML model using the MCA SDK.

## Overview

The example uses scikit-learn to train a simple Iris classification model and instruments it with MCA SDK for OpenTelemetry monitoring.

## Features Demonstrated

- Model training instrumentation
- Prediction recording with metrics
- Resource attributes configuration
- Integration with OpenTelemetry Collector

## Prerequisites

- Python 3.10+
- OpenTelemetry Collector running on `http://localhost:4318`
- Docker Compose (optional, for running collector)

## Installation

```bash
pip install -r requirements.txt
```

## Usage

### Start the Collector (Optional)

If you don't have a collector running:

```bash
docker-compose up -d otel-collector
```

### Run the Example

```bash
python instrumented_model.py
```

## Using GCP Development Infrastructure

To test against the real GCP dev environment instead of a local collector:

```bash
# Use Docker Compose override
docker-compose -f ../../docker-compose.yml -f ../../docker-compose.gcp-dev.yml up internal-model

# Or set environment variables for local testing
export MCA_COLLECTOR_ENDPOINT=http://10.164.76.8:4318
export MCA_ALLOW_INSECURE_COLLECTOR=true
python instrumented_model.py
```

See [GCP Dev Environment Guide](../../../docs/gcp-dev-environment.md) for complete setup instructions and troubleshooting.

### Verification

After running against GCP dev, verify telemetry in GCP Console:

```bash
# View logs
gcloud logging read "logName=projects/bhsf-ai-team-projects/logs/emms-model-telemetry" --limit=10

# View traces
gcloud trace list --project=bhsf-ai-team-projects --limit=10
```

Or use the GCP Console:
- **Logs**: [https://console.cloud.google.com/logs/query?project=bhsf-ai-team-projects](https://console.cloud.google.com/logs/query?project=bhsf-ai-team-projects)
- **Traces**: [https://console.cloud.google.com/traces/list?project=bhsf-ai-team-projects](https://console.cloud.google.com/traces/list?project=bhsf-ai-team-projects)

### Troubleshooting GCP Connectivity

**Cannot connect to 10.164.76.8:**
- Verify VPC connectivity or VPN access
- Test with: `curl http://10.164.76.8:4318/`

**Telemetry not appearing in GCP Console:**
- Verify collector endpoint is set correctly
- Check collector health: `curl http://10.164.76.8:13133/health/status`
- Wait 15 seconds for batch processing

## Expected Output

The script will:
1. Train an Iris classification model
2. Make predictions on test data
3. Send metrics and traces to the OpenTelemetry Collector
4. Print prediction results

## Monitoring

View metrics and traces in your configured backend:
- Prometheus (metrics)
- Cloud Logging (logs)
- Cloud Trace (traces)
- Grafana for dashboards

## Files

- `instrumented_model.py` - Main example script
- `requirements.txt` - Python dependencies
- `Dockerfile` - Containerized version

## Troubleshooting

### Connection Refused Error

If you see "Connection refused" errors:
- Ensure OpenTelemetry Collector is running
- Check collector endpoint: `http://localhost:4318`
- Verify Docker Compose services are up

### Import Errors

Ensure all dependencies are installed:
```bash
pip install -r requirements.txt
```
