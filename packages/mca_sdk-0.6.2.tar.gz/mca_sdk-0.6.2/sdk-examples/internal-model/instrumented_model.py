import os
import sys
import time
import random

# Import MCA SDK (install via: pip install mca-sdk)
from mca_sdk import MCAClient
from opentelemetry.trace import Status, StatusCode

OTEL_ENDPOINT = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4318")


def predict(client, input_data):
    """Mock prediction function that generates metrics, logs, and traces."""
    # Generate prediction ID
    prediction_id = f"pred-{random.randint(1000, 9999)}"

    # Custom metrics (optional - SDK provides convenience methods too)
    predictions_counter = client.meter.create_counter(
        "emms_model_predictions_total",
        description="Total number of model predictions"
    )

    latency_histogram = client.meter.create_histogram(
        "emms_model_prediction_duration_seconds",
        description="Model prediction latency",
        unit="s"
    )

    # Create parent span for entire prediction (SDK provides context manager)
    with client.trace("model.predict") as span:
        # Add span attributes
        span.set_attribute("model.id", "mdl-001")
        span.set_attribute("prediction_id", prediction_id)

        # Feature extraction (child span)
        with client.tracer.start_as_current_span("feature_extraction") as feature_span:
            time.sleep(0.05)  # Mock 50ms processing
            feature_span.set_attribute("features_count", 42)

        # Inference (child span)
        with client.tracer.start_as_current_span("inference") as inference_span:
            try:
                time.sleep(0.1)  # Mock 100ms processing
                inference_span.set_attribute("model_type", "logistic_regression")
                inference_span.set_status(Status(StatusCode.OK))
            except Exception as e:
                inference_span.set_status(Status(StatusCode.ERROR, str(e)))
                inference_span.record_exception(e)
                raise

        # Metrics (using custom counters)
        predictions_counter.add(1)
        latency = random.uniform(0.01, 0.5)
        latency_histogram.record(latency)

        # Logs
        client.logger.info(
            "Prediction completed",
            extra={
                "prediction_id": prediction_id,
                "input_data": str(input_data)
            }
        )

        # Warning log for high latency
        if latency > 0.3:
            client.logger.warning(
                f"High latency detected: {latency:.3f}s",
                extra={
                    "prediction_id": prediction_id,
                    "latency": latency
                }
            )

        return {
            "prediction": "low_risk",
            "confidence": 0.87,
            "latency": latency,
            "prediction_id": prediction_id
        }


def predict_with_decorator(client, input_data):
    """Mock prediction using manual instrumentation with decorator pattern.

    This function demonstrates a simpler instrumentation approach that
    manually:
    - Measures latency
    - Generates prediction_id
    - Creates trace spans
    - Records metrics
    """
    # Use decorator for automatic span creation
    @client.predict(capture_input=True, capture_output=True)
    def _inner_predict(data):
        time.sleep(0.1)  # Mock processing
        risk_score = random.uniform(0.1, 0.9)

        return {
            "prediction": "low_risk" if risk_score < 0.5 else "high_risk",
            "confidence": risk_score,
            "risk_score": risk_score
        }

    return _inner_predict(input_data)


if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    logger = logging.getLogger(__name__)

    # Parse command-line arguments
    num_predictions = 10  # default
    if len(sys.argv) > 1:
        try:
            num_predictions = int(sys.argv[1])
        except ValueError:
            logger.error("Usage: python instrumented_model.py [num_predictions]")
            sys.exit(1)

    logger.info("NOTE: This example uses MOCK data only.")
    logger.info("No real patient data (PHI) is used in this demonstration.")
    logger.info(f"Sending telemetry to: {OTEL_ENDPOINT}")
    logger.info(f"Running {num_predictions} predictions...")

    # Use context manager for automatic resource cleanup
    with MCAClient(
        service_name="demo-readmission-model",
        model_id="mdl-001",
        model_version="0.4.0",
        team_name="clinical-ai",
        collector_endpoint=OTEL_ENDPOINT,
        metric_export_interval_ms=5000
    ) as client:
        # Run half with manual instrumentation, half with decorator
        half = num_predictions // 2

        logger.info("--- Manual instrumentation ---")
        for i in range(1, half + 1):
            result = predict(client, {"record_id": f"rec-{i:03d}"})  # Mock data - not real PHI
            logger.info(f"Prediction #{i}: latency={result['latency']:.3f}s")
            time.sleep(0.5)

        logger.info("--- Auto-instrumentation (decorator) ---")
        for i in range(half + 1, num_predictions + 1):
            result = predict_with_decorator(client, {"record_id": f"rec-{i:03d}"})  # Mock data - not real PHI
            logger.info(f"Prediction #{i}: {result['prediction']} (confidence={result['confidence']:.2f})")
            time.sleep(0.5)

    logger.info("Demo complete. Check collector logs for metrics, logs, and traces output.")
