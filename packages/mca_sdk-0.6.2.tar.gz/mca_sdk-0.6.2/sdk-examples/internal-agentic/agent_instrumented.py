"""
Medical Research Assistant Agent - Agentic AI Example

Demonstrates agentic AI monitoring with MCA SDK using the new agentic tracking API:
- record_goal_started() / record_goal_completed() for goal tracking
- track_tool() context manager for tool execution telemetry
- record_human_intervention() for human-in-the-loop tracking
- Nested spans for multi-step reasoning

DESIGN NOTES:
- Uses print() for demo clarity (data scientists can see execution flow)
- Production code should use self.client.logger for OTel log integration
- Token tracking (input_tokens/output_tokens) requires LLM integration
- Reasoning step tokens_used should be added when using LLM for reasoning
"""

import os
import time
from typing import List, Dict, Any

from mca_sdk import MCAClient
from mca_sdk.core.client import _sanitize_error_message
from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

from tools import MockPubMedSearch, MockDrugDatabase, MockCalculator


class MedicalResearchAgent:
    """
    Agentic AI that researches clinical questions using multiple tools.
    Uses MCA SDK's built-in agentic tracking methods for observability.
    """

    def __init__(self, mca_client: MCAClient, simulation_delay: float = None):
        self.client = mca_client
        self.tracer = trace.get_tracer(__name__)

        # Configurable simulation delay (can be set to 0 for testing)
        # Falls back to environment variable or default
        if simulation_delay is not None:
            self.simulation_delay = simulation_delay
        else:
            self.simulation_delay = float(os.environ.get("AGENT_SIMULATION_DELAY", "0.5"))

        # Initialize tools
        self.pubmed = MockPubMedSearch()
        self.drug_db = MockDrugDatabase()
        self.calculator = MockCalculator()

        # Note: No need to create metrics manually - SDK handles all agentic metrics
        # via record_goal_started(), record_goal_completed(), track_tool(), etc.

    def cleanup(self):
        """Clean up tool resources before shutdown."""
        if hasattr(self.pubmed, 'close'):
            self.pubmed.close()
        if hasattr(self.drug_db, 'close'):
            self.drug_db.close()
        if hasattr(self.calculator, 'close'):
            self.calculator.close()
        self.client.shutdown()

    def research_question(self, question: str) -> Dict[str, Any]:
        """
        Main entry point: Research a clinical question.
        Uses SDK's goal tracking for complete observability.

        IMPORTANT: Ensure 'question' contains NO PHI before calling this method.
        In production, sanitize user input to remove patient identifiers before
        passing to telemetry systems.
        """
        # WARNING: goal_description is recorded in telemetry/traces
        # Ensure no PHI (patient names, MRNs, dates of birth, etc.) in goal_description
        # Truncate to limit potential exposure and demonstrate sanitization best practice
        sanitized_question = question[:100]  # Limit to first 100 chars

        # Start goal tracking using SDK method - returns unique goal_id
        goal_id = self.client.record_goal_started(
            goal_description=sanitized_question,  # Use sanitized version
            goal_type="research_question"
        )

        # Demonstrate OTel log integration alongside print statements
        # Note: Both are shown for educational purposes. Production code should
        # prefer self.client.logger for integration with OpenTelemetry logs.
        print(f"\n[GOAL STARTED]: {goal_id}")
        print(f"   Question: {question}\n")
        self.client.logger.info(
            f"Agent goal started: {goal_id}",
            extra={
                "goal_id": goal_id,
                "goal_type": "research_question",
                "question_length": len(question)
            }
        )

        try:
            # Step 1: Planning
            search_terms = self._plan_search_strategy(question)

            # Step 2: Research (with goal_id for correlation)
            papers = self._execute_literature_search(search_terms, goal_id)

            # Step 3: Analysis
            analysis = self._analyze_findings(papers, question)

            # Step 4: Query drug database for details (with goal_id for correlation)
            drug_info = self._query_drug_database(analysis.get("recommended_drugs", []), goal_id)

            # Step 4.5: Calculate dosage ratios (demonstrates calculator tool usage)
            dosage_calculations = self._calculate_dosage_ratios(drug_info, goal_id)

            # Step 5: Synthesize answer
            answer = self._synthesize_answer(question, papers, analysis, drug_info, dosage_calculations)

            # Step 6: Request human review
            self._request_human_review(answer)

            # Mark goal as successful using SDK method
            self.client.record_goal_completed(goal_id, status="success")

            print(f"\n[GOAL COMPLETED]: {goal_id}\n")
            self.client.logger.info(
                f"Agent goal completed successfully: {goal_id}",
                extra={
                    "goal_id": goal_id,
                    "status": "success",
                    "answer_length": len(answer)
                }
            )

            return {
                "goal_id": goal_id,
                "question": question,
                "answer": answer,
                "status": "success"
            }

        except Exception as e:
            # Mark goal as failed using SDK method
            self.client.record_goal_completed(goal_id, status="failure")

            # Sanitize error message to prevent PHI leakage
            sanitized_error = _sanitize_error_message(str(e))
            print(f"\n[GOAL FAILED]: {goal_id} - {sanitized_error}\n")

            return {
                "goal_id": goal_id,
                "question": question,
                "error": sanitized_error,
                "status": "failure"
            }

    def _plan_search_strategy(self, question: str) -> List[str]:
        """Step 1: Plan search strategy"""
        # Use SDK's reasoning_step() context manager
        with self.client.reasoning_step(
            step_type="planning",
            step_description="Analyzing question and determining search strategy"
        ) as span:
            span.set_attribute("step", "search_strategy")
            # Mock token usage for LLM-based reasoning (AC 5 requirement)
            span.set_attribute("tokens_used", 150)  # Mock: planning typically uses ~150 tokens

            print("[PLANNING]: Analyzing question and determining search strategy...")

            time.sleep(self.simulation_delay)

            # Use substring matching instead of word matching to handle punctuation
            question_lower = question.lower()
            search_terms = []

            if "diabetes" in question_lower or "diabetic" in question_lower:
                search_terms.append("diabetes type 2 cardiovascular")
            if "treatment" in question_lower or "therapy" in question_lower:
                search_terms.append("treatment guidelines")

            if not search_terms:
                search_terms = [question]

            print(f"   > Search terms: {search_terms}\n")
            return search_terms

    def _execute_literature_search(self, search_terms: List[str], goal_id: str) -> List[Dict]:
        """Step 2: Execute PubMed search using SDK's track_tool()

        Demonstrates error handling and resilience: If one search term fails,
        the agent continues with remaining terms (fallback behavior).
        """
        all_papers = []

        for term in search_terms:
            # Use SDK's track_tool() with goal_id for correlation
            with self.client.track_tool("pubmed_search", goal_id=goal_id, search_term=term) as span:
                print(f"[TOOL]: PubMed search for '{term}'...")

                try:
                    # Mock token tracking (AC 3 requirement)
                    # In real LLM-based tools, these would be actual token counts from the API
                    mock_input_tokens = len(str(term)) // 4  # Rough estimate: 4 chars per token
                    span.set_attribute("tool.input_tokens", mock_input_tokens)

                    papers = self.pubmed.search(term)

                    # Mock output tokens based on result size
                    mock_output_tokens = len(papers) * 50  # Estimate: 50 tokens per paper summary
                    span.set_attribute("tool.output_tokens", mock_output_tokens)
                    span.set_attribute("papers_found", len(papers))

                    print(f"   [OK] Found {len(papers)} papers\n")
                    all_papers.extend(papers)

                except Exception as e:
                    # Fallback behavior: Log error but continue with other search terms
                    # CRITICAL: Must manually set span status to ERROR since we're not re-raising
                    span.record_exception(e)
                    span.set_status(Status(StatusCode.ERROR))

                    sanitized_error = _sanitize_error_message(str(e))
                    print(f"   [WARNING] Search failed for term '{term}': {sanitized_error}")
                    print(f"   [FALLBACK] Continuing with remaining search terms...\n")
                    self.client.logger.warning(
                        f"PubMed search failed for term, continuing with fallback",
                        extra={
                            "goal_id": goal_id,
                            "search_term": term,
                            "error": sanitized_error
                        }
                    )
                    # Note: track_tool() won't see the exception because we caught it
                    # That's why we manually record_exception() and set_status() above

        return all_papers

    def _analyze_findings(self, papers: List[Dict], question: str) -> Dict:
        """Step 3: Analyze research findings"""
        # Use SDK's reasoning_step() context manager
        with self.client.reasoning_step(
            step_type="evaluation",
            step_description=f"Analyzing {len(papers)} research papers to identify drug classes"
        ) as span:
            span.set_attribute("step", "analyze_findings")
            span.set_attribute("paper_count", len(papers))
            # Mock token usage for LLM-based analysis (AC 5 requirement)
            span.set_attribute("tokens_used", 300)  # Mock: analysis uses more tokens

            print("[REASONING]: Analyzing research papers...")

            time.sleep(self.simulation_delay * 2)  # Analysis takes longer

            recommended_drugs = []
            for paper in papers:
                if "SGLT2" in paper.get("title", ""):
                    recommended_drugs.append("sglt2_inhibitors")
                if "GLP-1" in paper.get("title", ""):
                    recommended_drugs.append("glp1_agonists")

            recommended_drugs = list(set(recommended_drugs))

            analysis = {
                "papers_analyzed": len(papers),
                "recommended_drugs": recommended_drugs,
                "key_finding": "Multiple drug classes show cardiovascular benefits"
            }

            print(f"   > Analyzed {len(papers)} papers")
            print(f"   > Identified drug classes: {recommended_drugs}\n")

            return analysis

    def _query_drug_database(self, drug_classes: List[str], goal_id: str) -> Dict:
        """Step 4: Query drug interaction database using SDK's track_tool()"""
        drug_info = {}

        for drug_class in drug_classes:
            # Use SDK's track_tool() with goal_id for correlation
            with self.client.track_tool("drug_database", goal_id=goal_id, drug_class=drug_class) as span:
                print(f"[TOOL]: Querying drug database for '{drug_class}'...")

                try:
                    # Mock token tracking (AC 3 requirement)
                    mock_input_tokens = len(drug_class) // 4
                    span.set_attribute("tool.input_tokens", mock_input_tokens)

                    info = self.drug_db.query(drug_class)

                    # Mock output tokens for database response
                    mock_output_tokens = 200  # Fixed estimate for structured drug data
                    span.set_attribute("tool.output_tokens", mock_output_tokens)

                    drug_info[drug_class] = info
                    print(f"   [OK] Retrieved drug info\n")

                except Exception as e:
                    print(f"   [ERROR] Query failed: {str(e)}\n")
                    raise

        return drug_info

    def _calculate_dosage_ratios(self, drug_info: Dict, goal_id: str) -> Dict:
        """Step 4.5: Calculate dosage ratios using calculator tool"""
        calculations = {}

        # Example: Calculate dosage adjustment ratio (simplified for demo)
        # In a real agent, this might calculate actual dosing based on patient factors
        with self.client.track_tool("calculator", goal_id=goal_id, operation="dosage_ratio") as span:
            print("[TOOL]: Calculating dosage adjustment ratios...")

            try:
                # Mock calculation: 10mg base dose * 1.5 adjustment factor
                ratio = self.calculator.calculate("10 * 1.5")
                calculations["adjusted_dose_mg"] = ratio
                span.set_attribute("calculation_result", ratio)
                print(f"   [OK] Dosage ratio calculated: {ratio}mg\n")

            except Exception as e:
                # CRITICAL: Must manually set span status to ERROR since we're not re-raising
                span.record_exception(e)
                span.set_status(Status(StatusCode.ERROR))

                print(f"   [ERROR] Calculation failed: {str(e)}\n")
                # Don't raise - calculation failure shouldn't stop the agent
                calculations["adjusted_dose_mg"] = "N/A"

        return calculations

    def _synthesize_answer(self, question: str, papers: List[Dict],
                           analysis: Dict, drug_info: Dict, dosage_calculations: Dict) -> str:
        """Step 5: Synthesize final answer"""
        # Use SDK's reasoning_step() context manager
        with self.client.reasoning_step(
            step_type="synthesis",
            step_description="Creating comprehensive answer from research findings"
        ) as span:
            span.set_attribute("step", "synthesize_answer")
            # Mock token usage for LLM-based synthesis (AC 5 requirement)
            span.set_attribute("tokens_used", 250)  # Mock: synthesis generates ~250 tokens

            print("[SYNTHESIS]: Creating comprehensive answer...")

            time.sleep(self.simulation_delay)

            answer_parts = [
                f"Question: {question}\n",
                f"\nBased on analysis of {analysis['papers_analyzed']} recent research papers:\n"
            ]

            for drug_class, info in drug_info.items():
                answer_parts.append(f"\n- {info.get('class', drug_class)}:")
                answer_parts.append(f"  - Examples: {', '.join(info.get('examples', []))}")
                if info.get('cardiovascular_benefits'):
                    answer_parts.append("  - Shows cardiovascular benefits")
                answer_parts.append(f"  - Key contraindications: {', '.join(info.get('contraindications', []))}")

            # Add dosage information if calculated
            if dosage_calculations.get("adjusted_dose_mg") != "N/A":
                answer_parts.append(f"\n\nDosage Calculation Example:")
                answer_parts.append(f"- Adjusted dose: {dosage_calculations['adjusted_dose_mg']}mg")

            answer_parts.append("\n\nRecommendation: Consult with healthcare provider for personalized treatment plan.")

            answer = "\n".join(answer_parts)
            print(f"   > Answer synthesized ({len(answer)} characters)\n")

            return answer

    def _request_human_review(self, answer: str):
        """Step 6: Request human review using SDK's record_human_intervention()"""
        # Use SDK's record_human_intervention() method
        self.client.record_human_intervention(
            reason="clinical_decision_support",
            intervention_type="review_request"
        )
        print("[HUMAN INTERVENTION]: Requesting clinical review...")
        print("   > Answer ready for healthcare professional review")
        print("   > Awaiting approval before patient communication\n")


def main():
    """Main demo function"""
    print("=" * 80)
    print("MEDICAL RESEARCH ASSISTANT AGENT - Agentic AI Demo")
    print("=" * 80)
    print("=" * 70)
    print("NOTE: This example uses MOCK clinical data only.")
    print("No real patient data (PHI) is used in this demonstration.")
    print("=" * 70)
    print("\nInitializing MCA SDK and agent...\n")

    OTEL_ENDPOINT = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4318")

    # Initialize MCA client with agentic model type
    client = MCAClient(
        service_name="medical-research-agent",
        model_id="agent-001",
        model_version="0.4.0",
        model_category="internal",
        model_type="agentic",  # Use agentic model type
        team_name="ai-research-team",
        collector_endpoint=OTEL_ENDPOINT
    )

    agent = MedicalResearchAgent(client)

    question = "What are the latest treatments for Type 2 Diabetes with cardiovascular complications?"

    try:
        result = agent.research_question(question)

        print("\n" + "=" * 80)
        print("FINAL RESULT")
        print("=" * 80)
        if result["status"] == "success":
            print("\n" + result["answer"])
        else:
            print(f"\nError: {result.get('error', 'Unknown error')}")

        print("\n" + "=" * 80)
        print("TELEMETRY SUMMARY (using MCA SDK agentic tracking)")
        print("=" * 80)
        print("\nMetrics exported via SDK methods:")
        print("  - agent.goals_started_total: 1 (via record_goal_started())")
        print("  - agent.goals_completed_total: 1 (via record_goal_completed())")
        print("  - agent.goal_duration_seconds: histogram")
        print("  - agent.tool_calls_total: ~3-4 (via track_tool())")
        print("  - agent.tool_latency_seconds: histogram (auto-captured)")
        print("  - agent.human_interventions_total: 1 (via record_human_intervention())")
        print("\nTraces created:")
        print("  - agent.goal (parent span from record_goal_started())")
        print("    |-- agent.planning")
        print("    |-- agent.tool.pubmed_search x2 (from track_tool())")
        print("    |-- agent.reasoning")
        print("    |-- agent.tool.drug_database x2 (from track_tool())")
        print("    |-- agent.synthesis")
        print("    |-- agent.human_intervention (from record_human_intervention())")

    finally:
        print("\nCleaning up resources...")
        agent.cleanup()
        print("[OK] Shutdown complete\n")


if __name__ == "__main__":
    main()
