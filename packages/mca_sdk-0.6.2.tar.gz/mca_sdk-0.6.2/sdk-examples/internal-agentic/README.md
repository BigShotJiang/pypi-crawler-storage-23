# Internal Agentic AI Example - Medical Research Assistant

A demonstration of agentic AI monitoring with the MCA SDK. This example shows a medical research assistant agent that uses multiple tools to answer clinical questions.

## What is Agentic AI?

Agentic AI systems are autonomous agents that:
- Define and pursue goals
- Use multiple tools to gather information
- Perform multi-step reasoning
- Make decisions with optional human oversight

## Features Demonstrated

This example showcases comprehensive agentic AI instrumentation:

### 1. Goal Tracking
- **Goal Start/Complete**: Metrics track when goals begin and end
- **Goal Success/Failure**: Status tracking for each goal execution
- **Goal Duration**: Measure time from start to completion

### 2. Tool Execution Telemetry
- **Tool Call Counts**: Track how often each tool is used
- **Tool Latency**: Measure execution time per tool
- **Tool Success/Failure**: Monitor tool reliability

### 3. Multi-Step Reasoning
- **Nested Spans**: Each reasoning step creates a span
- **Step Types**: Planning, research, analysis, synthesis
- **Reasoning Step Counter**: Track complexity of agent's thought process

### 4. Human Intervention
- **Intervention Points**: Track when human review is requested
- **Intervention Reasons**: Categorize why intervention was needed

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│          Medical Research Assistant Agent               │
│                                                          │
│  Goal: "What are latest T2D treatments with CVD?"       │
│                                                          │
│  ┌────────────┐   ┌────────────┐   ┌────────────┐      │
│  │  Planning  │ → │  Research  │ → │  Analysis  │      │
│  └────────────┘   └────────────┘   └────────────┘      │
│                                                          │
│  ┌────────────┐   ┌────────────┐   ┌────────────┐      │
│  │    Query   │ → │ Synthesize │ → │   Human    │      │
│  │  Drug DB   │   │   Answer   │   │  Intervention│    │
│  └────────────┘   └────────────┘   └────────────┘      │
└─────────────────────────────────────────────────────────┘
           │                    │                  │
           ▼                    ▼                  ▼
     PubMed Search        Drug Database       Calculator
     (Mock Tool)          (Mock Tool)         (Mock Tool)
```

## Quick Start

### 1. Install Dependencies
```bash
cd mca-prototype/sdk-examples/internal-agentic
pip install -r requirements.txt
```

### 2. Start the OpenTelemetry Collector
```bash
# From mca-prototype directory
docker-compose up -d otel-collector
```

### 3. Run the Agent
```bash
python agent_instrumented.py
```

## Using GCP Development Infrastructure

To test against the real GCP dev environment instead of a local collector:

```bash
# Use Docker Compose override
docker-compose -f ../../docker-compose.yml -f ../../docker-compose.gcp-dev.yml up internal-agentic

# Or set environment variables for local testing
export MCA_COLLECTOR_ENDPOINT=http://10.164.76.8:4318
export MCA_ALLOW_INSECURE_COLLECTOR=true
python agent_instrumented.py
```

See [GCP Dev Environment Guide](../../../docs/gcp-dev-environment.md) for complete setup instructions and troubleshooting.

### Verification

After running against GCP dev, verify telemetry in GCP Console:

```bash
# View logs
gcloud logging read "logName=projects/bhsf-ai-team-projects/logs/emms-model-telemetry" --limit=10

# View traces
gcloud trace list --project=bhsf-ai-team-projects --limit=10
```

Or use the GCP Console:
- **Logs**: [https://console.cloud.google.com/logs/query?project=bhsf-ai-team-projects](https://console.cloud.google.com/logs/query?project=bhsf-ai-team-projects)
- **Traces**: [https://console.cloud.google.com/traces/list?project=bhsf-ai-team-projects](https://console.cloud.google.com/traces/list?project=bhsf-ai-team-projects)

### Troubleshooting GCP Connectivity

**Cannot connect to 10.164.76.8:**
- Verify VPC connectivity or VPN access
- Test with: `curl http://10.164.76.8:4318/`

**Telemetry not appearing in GCP Console:**
- Verify collector endpoint is set correctly
- Check collector health: `curl http://10.164.76.8:13133/health/status`
- Wait 15 seconds for batch processing

## Expected Output

The agent will:
1. **Plan** the search strategy
2. **Execute** PubMed searches (mock)
3. **Analyze** research findings
4. **Query** the drug database
5. **Synthesize** a comprehensive answer
6. **Request** human review

### Console Output Example
```
================================================================================
MEDICAL RESEARCH ASSISTANT AGENT - Agentic AI Demo
================================================================================

Initializing MCA SDK and agent...

🎯 GOAL STARTED: goal-1234567890
   Question: What are the latest treatments for Type 2 Diabetes with cardiovascular complications?

📋 PLANNING: Analyzing question and determining search strategy...
   → Search terms: ['diabetes type 2 cardiovascular']

🔍 TOOL EXECUTION: PubMed search for 'diabetes type 2 cardiovascular'...
   ✓ Found 2 papers (1.23s)

🧠 REASONING: Analyzing research papers...
   → Analyzed 2 papers
   → Identified drug classes: ['sglt2_inhibitors', 'glp1_agonists']

💊 TOOL EXECUTION: Querying drug database for 'sglt2_inhibitors'...
   ✓ Retrieved drug info (0.65s)

💊 TOOL EXECUTION: Querying drug database for 'glp1_agonists'...
   ✓ Retrieved drug info (0.72s)

📝 SYNTHESIS: Creating comprehensive answer...
   → Answer synthesized (412 characters)

👤 HUMAN INTERVENTION: Requesting clinical review...
   → Answer ready for healthcare professional review
   → Awaiting approval before patient communication

✅ GOAL COMPLETED: goal-1234567890
```

## Telemetry Exported

### Metrics
- `agent.goals_started_total` (counter)
- `agent.goals_completed_total` (counter with status label)
- `agent.tool_calls_total` (counter with tool_name label)
- `agent.tool_latency_seconds` (histogram with tool_name label)
- `agent.human_interventions_total` (counter with reason label)
- `agent.reasoning_steps_total` (counter with step_type label)

### Traces
- `agent.goal` - Top-level span for entire goal
  - `agent.planning` - Search strategy planning
  - `agent.tool_execution` - Each tool invocation (with tool_name attribute)
  - `agent.reasoning` - Analysis and decision-making
  - `agent.synthesis` - Final answer creation
  - `agent.human_intervention` - Human review request

### Resource Attributes
- `service.name`: medical-research-agent
- `model.id`: agent-001
- `model.version`: 0.3.0
- `model.type`: internal
- `team.name`: ai-research-team

## Verify in Collector Logs

```bash
docker logs mca-otel-collector | grep -A 5 "agent.goals_started_total"
docker logs mca-otel-collector | grep "agent.tool_execution"
```

## Mock Mode

All tools are mocked with predefined responses:
- **PubMed Search**: Returns hardcoded research paper summaries
- **Drug Database**: Returns predefined drug information
- **Calculator**: Performs safe arithmetic (not used in main demo)

**No external API calls are made**, making this suitable for demo purposes.

## Customization

### Add New Tools
Edit `tools.py` to add more mock tools:
```python
class MockNewTool:
    def execute(self, params):
        # Your implementation
        pass
```

### Modify Research Question
Edit the `question` variable in `agent_instrumented.py`:
```python
question = "Your custom clinical research question"
```

### Adjust Instrumentation
The agent uses standard OpenTelemetry APIs:
- `tracer.start_as_current_span()` for traces
- `counter.add()` for metrics
- `histogram.record()` for latency

## HIPAA Compliance & PHI Protection

**CRITICAL:** This example demonstrates telemetry in a healthcare context.

### PHI Handling Requirements

1. **Never include PHI in telemetry data**
   - Patient names, MRNs, dates of birth, SSNs
   - Specific addresses, phone numbers, email addresses
   - Protected health information per HIPAA

2. **Sanitize inputs before instrumentation**
   ```python
   # BAD - May expose PHI
   goal_id = client.record_goal_started(
       goal_description=user_question  # Might contain PHI!
   )

   # GOOD - Sanitized
   sanitized_question = remove_phi(user_question[:100])
   goal_id = client.record_goal_started(
       goal_description=sanitized_question
   )
   ```

3. **Review all span attributes**
   - `goal_description` - Truncate and sanitize
   - `tool.input_tokens` - Safe (numeric)
   - `tool.output_tokens` - Safe (numeric)
   - Custom attributes - Review for PHI

4. **Error messages**
   - SDK automatically sanitizes error messages
   - But review custom error handling code

### This Example's PHI Protection

- Questions are truncated to 100 characters maximum
- Mock data contains no real PHI
- Error messages sanitized via `_sanitize_error_message()`
- OTel logs use structured logging (no free-form text)

**For production:** Implement organization-specific PHI detection and removal before any telemetry recording.

## Production Considerations

For production deployment:
1. **Implement PHI sanitization** - Use NER models or regex patterns to detect/remove PHI
2. Replace mock tools with real API clients (PubMed API, drug databases)
3. Add authentication and rate limiting for external APIs
4. Implement caching to reduce API calls
5. Add retry logic with exponential backoff
6. Use LangChain's agent framework for more sophisticated reasoning
7. Implement proper error handling and fallback strategies
8. Add data validation for tool inputs/outputs
9. Consider using LangSmith or similar for agent debugging

## Integration with LangChain

While this example uses simple Python classes, production agentic systems often use frameworks like LangChain:

```python
from langchain.agents import AgentExecutor, create_react_agent
from langchain.tools import Tool

# Define tools as LangChain Tools
tools = [
    Tool(
        name="PubMed Search",
        func=pubmed.search,
        description="Search PubMed for medical research papers"
    )
]

# Create agent (with MCA SDK instrumentation)
agent = create_react_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools, verbose=True)
```

Add MCA SDK instrumentation at key points in the LangChain callbacks.

## License

See main project LICENSE.
