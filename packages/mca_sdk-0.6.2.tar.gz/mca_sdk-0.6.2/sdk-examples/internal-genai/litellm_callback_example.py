"""LiteLLM Callback Integration Example

Demonstrates automatic GenAI telemetry capture using MCALiteLLMCallback.
This approach requires ZERO manual instrumentation - just register the callback
and all litellm.completion() calls are automatically instrumented.

Key Features:
- Automatic token tracking (prompt, completion, total)
- Automatic cost calculation (using litellm.completion_cost)
- Automatic trace span creation with attributes
- Automatic error handling and logging
- Supports HIPAA compliance (no PHI logged by default)

Installation:
    pip install mca-sdk[genai]  # Includes litellm dependency

Usage:
    python litellm_callback_example.py

Note: This example uses mock mode to avoid actual API calls.
For production, set your API keys and remove mock configuration.
"""

import os
import sys
import time
import random
from typing import Optional

# Import MCA SDK
from mca_sdk.integrations import create_genai_client, MCALiteLLMCallback

# LiteLLM imports
import litellm

# Mock clinical data (no real PHI)
MOCK_PROMPTS = [
    "Summarize: Patient presents with fever and cough for 3 days.",
    "Summarize: 72yo male with hypertension, BP 142/88, on lisinopril.",
    "Summarize: 45yo female, Type 2 DM, HbA1c 8.2%, on metformin.",
    "Summarize: 28yo pregnant female, 8 weeks gestation, first prenatal visit.",
]


def call_llm_with_automatic_instrumentation(prompt: str) -> str:
    """
    Call LiteLLM - telemetry is automatically captured!

    No manual instrumentation needed. The callback handles:
    - Token counting
    - Cost calculation
    - Trace span creation
    - Metric recording
    - Error handling
    """
    try:
        # This is all you need! The callback handles everything else.
        response = litellm.completion(
            model="gpt-4",  # In mock mode, this returns test data
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=150,
        )

        return response.choices[0].message.content

    except Exception as e:
        print(f"Error during LLM call: {e}")
        # Error is automatically logged and recorded by callback
        raise


def main() -> None:
    """Main function - all execution logic contained here to prevent module-level side effects."""
    print("Initializing GenAI Clinical Assistant with MCALiteLLMCallback...")

    # Mock mode configuration (set MOCK_LLM=true to run without API keys)
    MOCK_LLM = os.environ.get("MOCK_LLM", "false").lower() == "true"

    if MOCK_LLM:
        print("🔵 Running in MOCK mode (no real API calls)")
        # LITELLM_MODE=COMPLETION is the official LiteLLM approach for mock mode
        # This enables testing without API keys by returning simulated responses
        os.environ["LITELLM_MODE"] = "COMPLETION"
        litellm.verbose = True
    else:
        print("🟢 Running in PRODUCTION mode (real API calls)")
        # Optional: Enable verbose logging for debugging
        if os.environ.get("DEBUG", "false").lower() == "true":
            litellm.verbose = True

    # OTLP endpoint configuration
    # Note: Manual parsing required because MCA SDK does not auto-read OTEL_EXPORTER_OTLP_ENDPOINT
    # The SDK's setup_meter_provider() requires an explicit endpoint parameter
    OTEL_ENDPOINT = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4318")

    print(f"OTLP Endpoint: {OTEL_ENDPOINT}")

    # Initialize MCA SDK client for GenAI
    client = create_genai_client(
        service_name="genai-clinical-assistant-callback",
        llm_provider="openai",
        llm_model="gpt-4",
        team_name="clinical-ai",
        collector_endpoint=OTEL_ENDPOINT,
        metric_export_interval_ms=5000,
    )

    # Create and register the LiteLLM callback
    # This is the ONLY instrumentation needed!
    callback = MCALiteLLMCallback(
        client=client,
        record_prompts=False,  # HIPAA: Don't log prompts (may contain PHI)
        record_completions=False,  # HIPAA: Don't log completions (may contain PHI)
        record_error_messages=False,  # SECURITY: Don't log error messages (may contain PHI)
    )

    # Register callback with LiteLLM
    # Use append() instead of assignment to respect existing callbacks
    # Check if we already have an MCALiteLLMCallback to avoid duplicates
    if not any(isinstance(cb, MCALiteLLMCallback) for cb in litellm.callbacks):
        litellm.callbacks.append(callback)
    else:
        print("⚠️  MCALiteLLMCallback already registered, skipping duplicate registration")

    print("✓ MCALiteLLMCallback registered with LiteLLM")
    print("✓ All LLM calls will be automatically instrumented\n")

    # Main loop execution
    run_demo_loop(client)

def run_demo_loop(client) -> None:
    """Execute the demo loop with success and failure scenarios."""
    print("\nStarting automated GenAI telemetry demo...")
    print("All telemetry is captured automatically by MCALiteLLMCallback")
    print("This demo runs 5 iterations (3 success + 2 failure scenarios)")
    print("Press Ctrl+C to stop\n")

    MAX_ITERATIONS = 5
    iteration = 0
    success_count = 0
    failure_count = 0

    try:
        while iteration < MAX_ITERATIONS:
            iteration += 1

            print(f"\n{'=' * 70}")
            print(f"Iteration #{iteration}/{MAX_ITERATIONS} - {time.strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"{'=' * 70}")

            # Demonstrate failure scenarios on iterations 3 and 5
            if iteration == 3:
                print("🔴 Demonstrating FAILURE scenario: Invalid model")
                print("This tests error handling and failure metric tracking")
                try:
                    response = litellm.completion(
                        model="invalid-model-that-does-not-exist",
                        messages=[{"role": "user", "content": "This should fail"}],
                    )
                    print(f"Response: {response.choices[0].message.content[:100]}...")
                    success_count += 1
                except Exception as e:
                    print(f"✓ Error caught: {type(e).__name__}: {str(e)[:80]}...")
                    print(f"✓ Failure automatically tracked by callback")
                    failure_count += 1

            elif iteration == 5:
                print("🔴 Demonstrating FAILURE scenario: Simulated API error")
                print("This tests resilience and error telemetry")
                try:
                    # In production, this could be a rate limit, timeout, etc.
                    response = litellm.completion(
                        model="gpt-4-this-will-fail-in-real-mode",
                        messages=[{"role": "user", "content": "Test"}],
                    )
                    print(f"Response: {response.choices[0].message.content[:100]}...")
                    success_count += 1
                except Exception as e:
                    print(f"✓ Error caught: {type(e).__name__}: {str(e)[:80]}...")
                    print(f"✓ Failure automatically tracked by callback")
                    failure_count += 1

            else:
                # Success scenario
                prompt = random.choice(MOCK_PROMPTS)
                print(f"🟢 Demonstrating SUCCESS scenario")
                print(f"Prompt: {prompt}")

                try:
                    response = call_llm_with_automatic_instrumentation(prompt)
                    print(f"Response: {response[:100]}...")
                    success_count += 1
                except Exception as e:
                    print(f"Call failed (error automatically logged): {e}")
                    failure_count += 1

            print(f"\n✓ Telemetry recorded (queued for export to collector):")
            print("  - genai.token_count (counter)")
            print("  - genai.cost_dollars (histogram)")
            print("  - genai.requests_total (counter)")
            if failure_count > 0:
                print("  - genai.requests_total{status='error'} (counter)")
            print("  - genai.latency_seconds (histogram)")
            print("  - Trace span with LLM attributes")
            print("  Note: Export is asynchronous; data sent in background")

            # Short wait between iterations (not needed for last iteration)
            if iteration < MAX_ITERATIONS:
                print(f"\nWaiting 3 seconds before next iteration...")
                time.sleep(3)

    except KeyboardInterrupt:
        print("\n\n⚠️  Interrupted by user (Ctrl+C)")
        print(f"Summary: {success_count} successful, {failure_count} failed out of {iteration} total calls")
        print("\nShutting down gracefully...")
        print("Flushing telemetry via MCA SDK...")
        client.shutdown()
        print("✓ Shutdown complete.")

    except Exception as e:
        print(f"\n❌ Error in main loop: {e}")
        client.shutdown()
        raise

    # Normal completion
    print(f"\n{'=' * 70}")
    print("DEMO COMPLETE")
    print(f"{'=' * 70}")
    print(f"\n📊 Summary:")
    print(f"  Total iterations: {iteration}")
    print(f"  ✓ Successful calls: {success_count}")
    print(f"  ✗ Failed calls: {failure_count}")
    print(f"\n✓ Telemetry export complete")
    print(f"✓ Metrics and traces queued for collector")
    print(f"\nTo verify telemetry:")
    print(f"  - Check collector logs: docker-compose logs otel-collector")
    print(f"  - View traces in Cloud Trace (if configured)")
    print(f"  - Query metrics in Prometheus (if configured)")
    print("\nShutting down MCA SDK...")
    client.shutdown()
    print("✓ Shutdown complete.")


if __name__ == "__main__":
    main()
