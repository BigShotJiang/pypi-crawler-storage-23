# GenAI/LLM Example with LiteLLM Integration

This example demonstrates **automatic GenAI telemetry capture** using the MCA SDK's `MCALiteLLMCallback` integration with LiteLLM. The callback automatically instruments all LLM API calls with zero manual effort.

## Overview

The `MCALiteLLMCallback` provides automatic instrumentation for LiteLLM-based applications, capturing comprehensive telemetry without requiring manual span creation or metric recording. Simply register the callback once, and all subsequent `litellm.completion()` calls are automatically tracked.

### What Gets Tracked

The callback automatically captures the following telemetry for every LLM call:

#### Metrics
| Metric | Type | Description |
|--------|------|-------------|
| `genai.tokens.prompt` | Counter | Total prompt tokens consumed |
| `genai.tokens.completion` | Counter | Total completion tokens generated |
| `genai.tokens.total` | Counter | Total tokens used (prompt + completion) |
| `genai.request.cost_usd` | Histogram | Request cost in USD (when available) |
| `genai.requests_total` | Counter | Total number of requests (tagged with status) |
| `genai.requests_failed_total` | Counter | Total number of failed requests |
| `genai.request_latency_seconds` | Histogram | Request latency in seconds |

#### Distributed Traces
Each LLM call creates a trace span with attributes:
- `llm.model` - Model identifier (e.g., "gpt-4", "claude-3")
- `llm.provider` - Provider name (e.g., "openai", "anthropic")
- `llm.temperature` - Temperature parameter
- `llm.max_tokens` - Maximum tokens parameter
- `genai.tokens.prompt` - Prompt token count
- `genai.tokens.completion` - Completion token count
- `genai.tokens.total` - Total token count
- `genai.latency_seconds` - Request latency
- `genai.cost_usd` - Request cost (when available)

#### Structured Logs
Logs are emitted for successful and failed requests with structured fields for querying and alerting.

## Files in This Example

- **`litellm_callback_example.py`** - Demonstrates `MCALiteLLMCallback` (automatic instrumentation, recommended)
- **`litellm_instrumented.py`** - Demonstrates manual instrumentation helpers (lower-level approach)
- **`requirements.txt`** - Python dependencies
- **`Dockerfile`** - Container image for running the example
- **`README.md`** - This file

## Prerequisites

- **Python 3.10+**
- **pip** (Python package manager)
- **Docker** (optional, for OpenTelemetry Collector)
- **Internet connection** (for production mode with real API calls)

## Installation

### Option 1: Install Local Development Version (Recommended for Development)

If you're developing the SDK itself or working from this repository:

```bash
cd mca-prototype
pip install -e .[genai]
cd sdk-examples/internal-genai
pip install tiktoken
```

### Option 2: Install from PyPI (When Published)

Once the MCA SDK is published to PyPI:

```bash
cd mca-prototype/sdk-examples/internal-genai
pip install -r requirements.txt
```

**Note:** This requires `mca-sdk[genai]>=0.3.0` to be available on PyPI. If you see installation errors, use Option 1 instead.

This installs:
- `mca-sdk[genai]>=0.3.0` - MCA SDK with LiteLLM support
- `tiktoken>=0.5.2` - Token counting library
- `opentelemetry-semantic-conventions` - OTel conventions (optional)

## Quick Start (Mock Mode)

Run the example in **mock mode** to test without making real API calls:

```bash
cd mca-prototype/sdk-examples/internal-genai
export MOCK_LLM=true
python3 litellm_callback_example.py
```

**What happens in mock mode:**
- No API keys required
- LiteLLM returns simulated responses
- Token counts are simulated
- Cost may show as $0.00 (expected)
- All telemetry is still captured and exported

**Expected Output:**
```
Initializing GenAI Clinical Assistant with MCALiteLLMCallback...
🔵 Running in MOCK mode (no real API calls)
OTLP Endpoint: http://localhost:4318
✓ MCALiteLLMCallback registered with LiteLLM
✓ All LLM calls will be automatically instrumented

Starting automated GenAI telemetry demo...
All telemetry is captured automatically by MCALiteLLMCallback
Press Ctrl+C to stop

======================================================================
Iteration #1/5 - 2026-02-12 10:15:30
======================================================================
🟢 Demonstrating SUCCESS scenario
Prompt: Summarize: Patient presents with fever and cough for 3 days.
Response: Mock response from LiteLLM...

✓ Telemetry recorded (queued for export to collector):
  - genai.tokens.prompt (counter)
  - genai.tokens.completion (counter)
  - genai.tokens.total (counter)
  - genai.request.cost_usd (histogram)
  - genai.requests_total (counter)
  - genai.request_latency_seconds (histogram)
  - Trace span with LLM attributes
  Note: Export is asynchronous; data sent in background
```

The example runs 5 iterations by default, then exits. Press `Ctrl+C` to stop early.

## Production Mode (Real API Calls)

To use with real LLM providers:

### Step 1: Set API Keys

```bash
# For OpenAI
export OPENAI_API_KEY="sk-..."

# For Anthropic (Claude)
export ANTHROPIC_API_KEY="sk-ant-..."

# For Google (Gemini)
export GOOGLE_API_KEY="AIza..."
```

### Step 2: Run with Real API (No Code Edits Needed!)

```bash
# Do NOT set MOCK_LLM (or set it to false)
cd mca-prototype/sdk-examples/internal-genai
python3 litellm_callback_example.py
```

**Expected Output:**
```
Initializing GenAI Clinical Assistant with MCALiteLLMCallback...
🟢 Running in PRODUCTION mode (real API calls)
OTLP Endpoint: http://localhost:4318
...
```

The callback will now track real API calls with accurate token counts and costs.

### Optional: Enable Debug Logging

For verbose LiteLLM logging in production mode:

```bash
export DEBUG=true
python3 litellm_callback_example.py
```

## Configuration

### OpenTelemetry Collector Endpoint

By default, telemetry is sent to `http://localhost:4318` (OTLP/HTTP). To change this:

```bash
export OTEL_EXPORTER_OTLP_ENDPOINT="http://your-collector:4318"
python litellm_callback_example.py
```

Or modify in code:

```python
OTEL_ENDPOINT = "http://your-collector:4318"
client = create_genai_client(
    service_name="my-service",
    llm_provider="openai",
    llm_model="gpt-4",
    team_name="my-team",
    collector_endpoint=OTEL_ENDPOINT,
)
```

### Iteration Count

By default, the example runs 5 iterations. To change this, edit `litellm_callback_example.py`:

```python
MAX_ITERATIONS = 10  # Add this constant

while iteration < MAX_ITERATIONS:
    iteration += 1
    # ... rest of loop
```

### HIPAA Compliance - PHI Logging

By default, the callback does **NOT** log prompts, completions, or error messages (which may contain PHI):

```python
callback = MCALiteLLMCallback(
    client=client,
    record_prompts=False,        # Don't log prompts
    record_completions=False,    # Don't log completions
    record_error_messages=False, # Don't log error messages
)
```

**NEVER set these to `True` in production HIPAA environments** unless you have explicit approval and proper PHI safeguards in place.

## Running with OpenTelemetry Collector

To see telemetry exported to a real collector:

### Step 1: Start the Collector

```bash
cd mca-prototype
docker-compose up -d otel-collector
```

This starts the OpenTelemetry Collector on:
- OTLP/HTTP: `http://localhost:4318`
- OTLP/gRPC: `http://localhost:4317`

### Step 2: Run the Example

```bash
cd sdk-examples/internal-genai
python litellm_callback_example.py
```

## Using GCP Development Infrastructure

To test against the real GCP dev environment instead of a local collector:

```bash
# Use Docker Compose override
docker-compose -f ../../docker-compose.yml -f ../../docker-compose.gcp-dev.yml up genai-assistant

# Or set environment variables for local testing
export MCA_COLLECTOR_ENDPOINT=http://10.164.76.8:4318
export MCA_ALLOW_INSECURE_COLLECTOR=true
python litellm_callback_example.py
```

See [GCP Dev Environment Guide](../../../docs/gcp-dev-environment.md) for complete setup instructions and troubleshooting.

### Verification

After running against GCP dev, verify telemetry in GCP Console:

```bash
# View logs
gcloud logging read "logName=projects/bhsf-ai-team-projects/logs/emms-model-telemetry" --limit=10

# View traces
gcloud trace list --project=bhsf-ai-team-projects --limit=10
```

Or use the GCP Console:
- **Logs**: [https://console.cloud.google.com/logs/query?project=bhsf-ai-team-projects](https://console.cloud.google.com/logs/query?project=bhsf-ai-team-projects)
- **Traces**: [https://console.cloud.google.com/traces/list?project=bhsf-ai-team-projects](https://console.cloud.google.com/traces/list?project=bhsf-ai-team-projects)

### Troubleshooting GCP Connectivity

**Cannot connect to 10.164.76.8:**
- Verify VPC connectivity or VPN access
- Test with: `curl http://10.164.76.8:4318/`

**Telemetry not appearing in GCP Console:**
- Verify collector endpoint is set correctly
- Check collector health: `curl http://10.164.76.8:13133/health/status`
- Wait 15 seconds for batch processing

### Step 3: Verify Telemetry

Check the collector logs:

```bash
docker-compose logs -f otel-collector
```

You should see OTLP exports with GenAI metrics and traces.

## Verification

### Verify Metrics Are Emitted

When running the example, you should see:

1. **Console Output:** Each iteration logs the prompt and response
2. **Structured Logs:** MCA SDK logs LLM requests with token/cost/latency data
3. **Collector Logs:** OTLP exports visible in `docker-compose logs otel-collector`

### Verify Traces Are Created

Traces are exported to the OpenTelemetry Collector and can be viewed in:
- **Cloud Trace** (Google Cloud)
- **Jaeger** (open-source tracing UI)
- **Zipkin** (open-source tracing UI)

Each trace span will have:
- Span name: `llm.{model}` (e.g., `llm.gpt-4`)
- Attributes: Model, provider, tokens, cost, latency
- Status: OK or ERROR

### Verify Cost Calculation

**Mock mode limitation:** Cost calculation is unavailable because LiteLLM's mock responses lack the required pricing metadata fields. This is a fundamental limitation of mock mode and cannot be fully addressed without real API responses.

**For production:** Real API calls provide accurate cost calculation using LiteLLM's pricing data and actual usage information from the provider.

## Mock Mode vs Production Mode

| Feature | Mock Mode | Production Mode |
|---------|-----------|-----------------|
| API Calls | No (simulated) | Yes (real API) |
| Token Counts | Simulated | Real from API |
| Cost Calculation | $0.00 or None | Accurate USD cost |
| Latency | Simulated | Real API latency |
| API Keys Required | No | Yes |
| Use Case | Testing, demos | Production apps |

## Troubleshooting

### Issue: "MCALiteLLMCallback requires the 'litellm' package"

**Solution:** Install the GenAI extra:

```bash
pip install mca-sdk[genai]
```

Or install LiteLLM directly:

```bash
pip install litellm>=1.61.15
```

### Issue: "Connection refused" to OpenTelemetry Collector

**Symptoms:**
```
Failed to export telemetry: Connection refused (localhost:4318)
```

**Solutions:**
1. **Start the collector:**
   ```bash
   cd mca-prototype
   docker-compose up -d otel-collector
   ```

2. **Verify collector is running:**
   ```bash
   docker-compose ps
   curl http://localhost:4318/v1/traces
   ```

3. **SDK continues running:** The SDK uses graceful degradation - if the collector is unavailable, the example continues without crashing.

### Issue: Cost is $0.00 in mock mode

**Explanation:** Mock mode limitation - LiteLLM's simulated responses lack the pricing metadata required for cost calculation. This is expected behavior and not a bug.

**Verification:** Run with a real API key to see accurate costs:
```bash
export OPENAI_API_KEY="sk-..."
# Do NOT set MOCK_LLM (production mode)
python3 litellm_callback_example.py
```

### Issue: How to switch between mock and production mode?

**Mock Mode** (no API keys needed):
```bash
export MOCK_LLM=true
python3 litellm_callback_example.py
# Console shows: 🔵 Running in MOCK mode (no real API calls)
```

**Production Mode** (requires API keys):
```bash
export OPENAI_API_KEY="sk-..."
# Do NOT set MOCK_LLM, or set it to false
python3 litellm_callback_example.py
# Console shows: 🟢 Running in PRODUCTION mode (real API calls)
```

**How it works internally:**
- When `MOCK_LLM=true`, the script sets `LITELLM_MODE=COMPLETION` internally
- This is the official LiteLLM approach for mock/test mode
- LiteLLM returns simulated responses without making API calls
- All telemetry is still captured normally (tokens, latency, traces)
- No code edits required to switch modes!

### Issue: "Multiple MCALiteLLMCallback instances detected"

**Symptoms:**
```
WARNING: Multiple MCALiteLLMCallback instances detected in litellm.callbacks
```

**Explanation:** LiteLLM uses a global callback registry. If you create multiple callback instances, they will all fire for every request, causing duplicate metrics.

**Solution:** Only create ONE callback instance per application process:

```python
# GOOD (one callback, using append)
callback = MCALiteLLMCallback(client)
litellm.callbacks.append(callback)

# ALSO GOOD (check for duplicates first)
if not any(isinstance(cb, MCALiteLLMCallback) for cb in litellm.callbacks):
    litellm.callbacks.append(callback)

# BAD (overwrites existing callbacks)
litellm.callbacks = [callback]  # Destroys any pre-existing callbacks

# BAD (multiple callbacks)
callback1 = MCALiteLLMCallback(client1)
callback2 = MCALiteLLMCallback(client2)  # Will cause duplicates!
litellm.callbacks.extend([callback1, callback2])
```

### Issue: Traces not appearing in Cloud Trace

**Checklist:**
1. Verify collector is exporting to Google Cloud:
   ```bash
   # Check collector config
   cat config/otel-collector-config.yaml
   ```

2. Verify GCP credentials are set:
   ```bash
   echo $GOOGLE_APPLICATION_CREDENTIALS
   ```

3. Check collector logs for export errors:
   ```bash
   docker-compose logs otel-collector | grep -i error
   ```

### Issue: Import error "cannot import name 'MCALiteLLMCallback'"

**Solution:** Ensure you're using MCA SDK 0.3.0 or later:

```bash
pip install --upgrade mca-sdk[genai]
```

Verify version:

```bash
python -c "import mca_sdk; print(mca_sdk.__version__)"
```

## Architecture

### How MCALiteLLMCallback Works

```
┌─────────────────────────────────────────────────────────────────┐
│ YOUR APPLICATION                                                │
│   import litellm                                                │
│   from mca_sdk.integrations import MCALiteLLMCallback          │
│                                                                  │
│   callback = MCALiteLLMCallback(client)                        │
│   litellm.callbacks = [callback]  ← Register once              │
│                                                                  │
│   response = litellm.completion(...)  ← Automatically tracked! │
└─────────────────┬───────────────────────────────────────────────┘
                  │
                  │ (1) log_pre_api_call → Start trace span
                  │ (2) LLM API call (OpenAI, Claude, etc.)
                  │ (3) log_success_event → Record metrics, end span
                  │
                  ▼
┌─────────────────────────────────────────────────────────────────┐
│ MCA SDK (OpenTelemetry)                                         │
│   - Record token counters                                       │
│   - Record cost histogram                                       │
│   - Record latency histogram                                    │
│   - Create trace span with attributes                           │
│   - Emit structured logs                                        │
└─────────────────┬───────────────────────────────────────────────┘
                  │
                  │ OTLP/HTTP or OTLP/gRPC
                  ▼
┌─────────────────────────────────────────────────────────────────┐
│ OPENTELEMETRY COLLECTOR                                         │
│   - Batch processor                                             │
│   - Attributes processor (add gcp.region, environment, etc.)    │
│   - Exporters (Prometheus, Cloud Trace, Cloud Logging, Langfuse)│
└─────────────────────────────────────────────────────────────────┘
```

### Callback Lifecycle

1. **Registration:**
   ```python
   callback = MCALiteLLMCallback(client)
   litellm.callbacks.append(callback)  # Use append to respect existing callbacks
   ```

2. **Pre-API Call (`log_pre_api_call`):**
   - Extract model, temperature, max_tokens
   - Start trace span with attributes
   - Store span in active spans dict

3. **API Call:**
   - LiteLLM calls the provider (OpenAI, Anthropic, etc.)
   - Response includes token usage

4. **Post-API Call (`log_success_event` or `log_failure_event`):**
   - Extract token usage from response
   - Calculate cost using `litellm.completion_cost()`
   - Calculate latency
   - Record metrics (tokens, cost, latency)
   - End trace span with attributes
   - Emit structured log

5. **Export (Asynchronous):**
   - MCA SDK queues telemetry data for export
   - OTel exporters send data to collector in background
   - Collector forwards to backends (Prometheus for metrics, Cloud Logging for logs, Cloud Trace for traces, Langfuse for LLM observability)

## Known Limitations

### 1. Time To First Token (TTFT) Not Supported

TTFT tracking requires streaming mode and the `log_stream_event` hook, which is not currently implemented in `MCALiteLLMCallback`. This callback only supports non-streaming (batch) completion calls.

**Workaround:** For streaming use cases, use the manual instrumentation approach shown in `litellm_instrumented.py`.

### 2. Cost Calculation May Fail for Custom Models

The `litellm.completion_cost()` function relies on LiteLLM's internal pricing tables. If you're using:
- Custom fine-tuned models
- Local models (Ollama, LMStudio)
- New models not yet in LiteLLM's pricing data

Cost calculation may return `None` or `$0.00`. This is expected and the callback will gracefully skip the cost metric.

**Workaround:** Implement custom cost calculation logic outside the callback if needed.

### 3. Global Callback Registry

LiteLLM uses a global callback registry (`litellm.callbacks`), which means:
- Only ONE `MCALiteLLMCallback` instance should be registered per process
- Multiple instances cause duplicate metrics
- Cannot have different configurations for different LLM calls in the same process

This is a fundamental LiteLLM design constraint that cannot be fully mitigated without changes to LiteLLM itself.

## Security Considerations

### PHI Protection

The callback is **configured for data privacy by default to support HIPAA compliance requirements**:
- Prompts are NOT logged (may contain patient data)
- Completions are NOT logged (may contain PHI)
- Error messages are NOT logged (may contain user input)
- Only metadata is captured (model, tokens, cost, latency)

**Note:** HIPAA compliance depends on organizational usage and implementation. Software configuration alone cannot guarantee compliance.

**NEVER enable `record_prompts`, `record_completions`, or `record_error_messages` in production HIPAA environments** unless you have:
- Explicit approval from compliance team
- Proper PHI de-identification in place
- Secure log storage with access controls

### Credential Management

API keys should be set via environment variables, never hardcoded:

```python
# GOOD
export OPENAI_API_KEY="sk-..."
response = litellm.completion(model="gpt-4", ...)

# BAD (never hardcode)
response = litellm.completion(
    model="gpt-4",
    api_key="sk-hardcoded-key",  # NEVER DO THIS
    ...
)
```

## Additional Examples

### Example: Error Handling

The callback automatically tracks failures:

```python
try:
    response = litellm.completion(
        model="invalid-model",  # Will fail
        messages=[{"role": "user", "content": "Hello"}]
    )
except Exception as e:
    print(f"Error: {e}")
    # Error is automatically tracked by callback:
    # - genai.requests_total (status=error)
    # - genai.requests_failed_total
    # - Trace span with error status
```

### Example: Custom Attributes

Add custom attributes to the MCA client (not directly to the callback):

```python
client = create_genai_client(
    service_name="clinical-summarizer",
    llm_provider="openai",
    llm_model="gpt-4",
    team_name="clinical-ai",
    collector_endpoint="http://localhost:4318",
)

# Custom attributes on the client propagate to all metrics
client.meter.create_counter("custom.metric").add(1, attributes={
    "use_case": "patient_summarization",
    "department": "cardiology"
})
```

### Example: Multiple Models

The callback tracks all models used:

```python
# Register callback once (use append to respect existing callbacks)
callback = MCALiteLLMCallback(client)
litellm.callbacks.append(callback)

# All models are automatically tracked
response1 = litellm.completion(model="gpt-4", messages=[...])
response2 = litellm.completion(model="claude-3", messages=[...])
response3 = litellm.completion(model="gemini-pro", messages=[...])

# Metrics are tagged with model name for filtering
```

## Next Steps

1. **Run the example in mock mode** to verify setup
2. **Start OpenTelemetry Collector** to see telemetry exports
3. **Configure for production** with real API keys
4. **Integrate into your application** by copying the callback setup
5. **Monitor in production** using Prometheus dashboards for metrics

## References

- **MCA SDK Documentation:** `mca-prototype/README.md`
- **LiteLLM Documentation:** https://docs.litellm.ai/
- **OpenTelemetry Python:** https://opentelemetry.io/docs/languages/python/
- **MCA SDK Integrations:** `mca_sdk/integrations/`

## Support

For issues or questions:
- Review `mca-prototype/README.md`
- Check `tests/test_litellm_callback.py` for usage examples
- See `docs/api-contracts.md` for API specifications
