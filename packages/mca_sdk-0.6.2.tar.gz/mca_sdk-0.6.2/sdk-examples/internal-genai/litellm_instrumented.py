import os
import sys
import time
import random

# Import MCA SDK (install via: pip install mca-sdk[genai])
from mca_sdk.integrations import create_genai_client, estimate_openai_cost, track_llm_completion

# LiteLLM imports
import litellm


print("Initializing GenAI Clinical Documentation Assistant with MCA SDK...")

# Mock mode configuration (no API calls)
os.environ["LITELLM_MODE"] = "COMPLETION"
litellm.set_verbose = True

# OTLP endpoint configuration
OTEL_ENDPOINT = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4318")

print(f"OTLP Endpoint: {OTEL_ENDPOINT}")

print("=" * 70)
print("NOTE: This example uses MOCK clinical data only.")
print("No real patient data (PHI) is logged or transmitted.")
print("=" * 70)

# Initialize MCA SDK client for GenAI (single function call)
client = create_genai_client(
    service_name="genai-clinical-assistant",
    llm_provider="openai-mock",
    llm_model="gpt-3.5-turbo",
    team_name="clinical-ai",
    collector_endpoint=OTEL_ENDPOINT,
    metric_export_interval_ms=5000
)


# ==========================================
# Mock Clinical Data
# ==========================================
# Mock patient encounter notes for clinical documentation assistant demo
# No real patient data - for demonstration purposes only

MOCK_ENCOUNTERS = [
    """Patient presents with fever (101.5°F), productive cough with yellow sputum, and body aches for 3 days.
    No recent travel history. Previously vaccinated for influenza this season.
    Lungs clear to auscultation bilaterally. No wheezing or rales noted.""",

    """72-year-old male with history of hypertension presents for routine follow-up.
    Blood pressure 142/88 mmHg. Currently on lisinopril 10mg daily.
    Reports good medication compliance. No chest pain, shortness of breath, or edema.
    No new symptoms since last visit.""",

    """45-year-old female with Type 2 Diabetes Mellitus, HbA1c 8.2% (last check 3 months ago).
    Reports difficulty with dietary adherence due to work schedule.
    No hypoglycemic episodes. Currently on metformin 1000mg twice daily.
    Denies polyuria, polydipsia, or unexplained weight loss.""",

    """28-year-old female, 8 weeks pregnant, presents for initial prenatal visit.
    Last menstrual period 8 weeks ago. Positive home pregnancy test.
    Mild nausea in mornings, no vomiting. Taking prenatal vitamins.
    No vaginal bleeding or cramping. No significant medical history."""
]

# Mock LLM summaries (what the model would generate)
MOCK_SUMMARIES = [
    "Clinical Summary: Patient with acute upper respiratory infection, likely viral etiology given symptom duration and clear lung exam. Recommend symptomatic treatment, hydration, rest. Consider rapid flu test if symptoms worsen. Return if fever persists >5 days or develops dyspnea.",

    "Clinical Summary: Hypertension management visit. Blood pressure slightly elevated at 142/88 despite current medication. Consider increasing lisinopril to 20mg daily or adding second agent. Patient compliant with medications. Schedule follow-up in 4 weeks to reassess BP control.",

    "Clinical Summary: Type 2 Diabetes with suboptimal glycemic control (HbA1c 8.2%). Dietary non-compliance identified as primary factor. Recommend nutrition counseling and diabetes education. Consider medication adjustment if HbA1c remains elevated at 3-month follow-up. Monitor for diabetic complications.",

    "Clinical Summary: Initial prenatal visit at 8 weeks gestation. Patient experiencing normal early pregnancy symptoms. Recommend continue prenatal vitamins with folic acid. Schedule comprehensive prenatal panel: CBC, blood type, antibody screen, rubella, HIV, hepatitis B, urinalysis. Next visit at 12 weeks for first trimester ultrasound."
]


# ==========================================
# Clinical Summarization Function
# ==========================================

def summarize_clinical_note(encounter_note: str) -> dict:
    """
    Generate clinical summary using LiteLLM with mock mode.

    This function demonstrates:
    1. LiteLLM's automatic OpenTelemetry span creation
    2. Custom metric recording for tokens, cost, and latency
    3. Mock mode demo without API calls

    Args:
        encounter_note: Raw clinical encounter text

    Returns:
        dict with summary, token counts, cost, and latency
    """
    start_time = time.time()

    # Prepare messages in OpenAI format
    messages = [
        {
            "role": "system",
            "content": "You are a clinical documentation assistant. Summarize patient encounters into concise clinical summaries for the medical record."
        },
        {
            "role": "user",
            "content": f"Summarize the following patient encounter:\n\n{encounter_note}"
        }
    ]

    try:
        # LiteLLM completion call
        # IMPORTANT: LiteLLM automatically creates an OpenTelemetry span here!
        # The span includes attributes: model, prompt_tokens, completion_tokens, response_time
        #
        # In mock mode, this returns a test response without hitting any API
        # We simulate the response by using our pre-defined mock summaries

        # For mock mode, we'll use a custom implementation since litellm mock may vary
        # In production, you would just use: response = litellm.completion(model="gpt-3.5-turbo", messages=messages)

        # Mock response structure matching OpenAI format
        mock_prompt_tokens = len(encounter_note.split()) * 1.3  # Rough estimate
        mock_completion_tokens = random.randint(60, 120)  # Typical summary length

        # Pick a random mock summary that corresponds to this encounter
        encounter_index = MOCK_ENCOUNTERS.index(encounter_note) if encounter_note in MOCK_ENCOUNTERS else 0
        mock_content = MOCK_SUMMARIES[encounter_index]

        response = {
            "choices": [{
                "message": {
                    "role": "assistant",
                    "content": mock_content
                }
            }],
            "usage": {
                "prompt_tokens": int(mock_prompt_tokens),
                "completion_tokens": mock_completion_tokens,
                "total_tokens": int(mock_prompt_tokens) + mock_completion_tokens
            },
            "model": "gpt-3.5-turbo-mock"
        }

        # Calculate latency
        latency = time.time() - start_time

        # Extract token counts
        prompt_tokens = response["usage"]["prompt_tokens"]
        completion_tokens = response["usage"]["completion_tokens"]
        total_tokens = response["usage"]["total_tokens"]
        model_name = response["model"]

        # Calculate cost using SDK helper
        total_cost = estimate_openai_cost(model_name, prompt_tokens, completion_tokens)

        # Record all metrics using SDK helper (single function call)
        track_llm_completion(
            client=client,
            model=model_name,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            latency=latency,
            status="success"
        )

        return {
            "summary": response["choices"][0]["message"]["content"],
            "model": model_name,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": total_tokens,
            "cost_usd": total_cost,
            "latency_seconds": latency
        }

    except Exception as e:
        print(f"Error during completion: {e}")
        # Record error using SDK helper
        latency = time.time() - start_time
        track_llm_completion(
            client=client,
            model="gpt-3.5-turbo",
            prompt_tokens=0,
            completion_tokens=0,
            latency=latency,
            status="error",
            error=str(e)
        )
        raise


# ==========================================
# Main Loop
# ==========================================

if __name__ == "__main__":
    print("\nStarting GenAI Clinical Documentation Assistant...")
    print(f"Mock mode: {os.environ.get('LITELLM_MODE', 'disabled')}")
    print(f"Sending telemetry to: {OTEL_ENDPOINT}")
    print("\nGenerating clinical summaries every 30 seconds...")
    print("Press Ctrl+C to stop\n")

    iteration = 0

    try:
        while True:
            iteration += 1

            # Pick a random encounter note
            encounter_note = random.choice(MOCK_ENCOUNTERS)
            encounter_preview = encounter_note[:80] + "..." if len(encounter_note) > 80 else encounter_note

            print(f"\n{'='*70}")
            print(f"Iteration #{iteration} - {time.strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"{'='*70}")
            print(f"Input: {encounter_preview}")

            # Generate summary (with automatic OTel instrumentation)
            result = summarize_clinical_note(encounter_note)

            # Display results
            print(f"\nSummary: {result['summary'][:100]}...")
            print(f"\nTelemetry:")
            print(f"  Model: {result['model']}")
            print(f"  Prompt Tokens: {result['prompt_tokens']}")
            print(f"  Completion Tokens: {result['completion_tokens']}")
            print(f"  Total Tokens: {result['total_tokens']}")
            print(f"  Estimated Cost: ${result['cost_usd']:.6f}")
            print(f"  Latency: {result['latency_seconds']:.3f}s")
            print(f"\n✓ Metrics and traces sent to collector")

            # Wait 30 seconds before next iteration
            print(f"\nWaiting 30 seconds before next summary...")
            time.sleep(30)

    except KeyboardInterrupt:
        print("\n\nShutting down gracefully...")
        print("Flushing telemetry via MCA SDK...")
        client.shutdown()
        print("Shutdown complete.")

    except Exception as e:
        print(f"\nError in main loop: {e}")
        client.shutdown()
        raise
