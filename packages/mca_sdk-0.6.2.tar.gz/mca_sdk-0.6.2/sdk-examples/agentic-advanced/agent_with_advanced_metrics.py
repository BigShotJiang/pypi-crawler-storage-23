#!/usr/bin/env python3
"""Advanced agentic metrics demonstration (Story 1.19).

Demonstrates all 13 data points from the advanced agentic metrics spec:
- Goal-level tracking with decorators
- Step-level tracking
- Tool recovery tracking (retry detection)
- Human-in-the-loop events
- Policy violation events

Usage:
    python agent_with_advanced_metrics.py
"""

import time
from mca_sdk import MCAClient
from mca_sdk.integrations.decorators import trace_agent_goal, trace_agent_step


def simulate_research_agent():
    """Simulate a research agent with comprehensive telemetry."""

    # Initialize MCA SDK for agentic AI
    client = MCAClient(
        service_name="research-agent-advanced",
        model_type="agentic",
        model_id="agent-v2",
        team_name="ai-research",
        collector_endpoint="http://localhost:4318",
        debug_mode=True,
        strict_validation=False,  # Disable for demo purposes
    )

    print("=" * 70)
    print("ADVANCED AGENTIC METRICS DEMO - Story 1.19")
    print("=" * 70)
    print()

    try:
        # Use @trace_agent_goal decorator for automatic goal tracking
        @trace_agent_goal(
            client,
            description="Find latest treatment options for Type 2 diabetes",
            goal_type="medical_research"
        )
        def execute_research_goal():
            """Main research goal with automatic telemetry."""
            # FIX Issue #2: Retrieve goal_id from context (non-destructive)
            goal_id = client.get_current_goal_id()
            print(f"🎯 Goal started: {goal_id}")
            print()

            # Step 1: Database search with retry/recovery
            @trace_agent_step(client, step_id="pubmed-search")
            def search_pubmed_step():
                """Search PubMed database (with simulated failure + recovery)."""
                print("📚 Step 1: Searching PubMed database...")

                # First attempt: Simulated API timeout
                try:
                    with client.track_tool("pubmed_api", goal_id=goal_id, query="diabetes treatment") as span:
                        print("   ⏱️  Tool call #1: pubmed_api")
                        time.sleep(0.1)
                        # Simulate API failure
                        raise ConnectionError("PubMed API timeout (simulated)")
                except ConnectionError as e:
                    print(f"   ❌ Tool failed: {e}")
                    print()

                    # Human intervention: API timeout requires manual review
                    print("🙋 Human intervention required (API timeout)")
                    client.record_human_intervention(
                        reason="api_timeout_needs_troubleshooting",
                        timestamp=time.time()
                    )
                    print("   ✓ HITL event recorded")
                    print()
                    time.sleep(0.2)  # Simulate human review time

                # Retry after intervention (recovery tracking automatic)
                print("   🔄 Retrying after intervention...")
                with client.track_tool("pubmed_api", goal_id=goal_id, query="diabetes treatment") as span:
                    print("   ⏱️  Tool call #2: pubmed_api (retry)")
                    time.sleep(0.15)
                    span.set_attribute("results_count", 42)
                    span.set_attribute("search_terms", "type 2 diabetes treatment")
                    print("   ✅ Tool succeeded on retry (recovery_attempted=True, recovery_success=True)")
                    print()

                return {"papers_found": 42}

            search_results = search_pubmed_step()
            print(f"   📊 Search complete: {search_results['papers_found']} papers found")
            print()

            # Step 2: Data analysis with security check
            @trace_agent_step(client, step_id="analyze-papers")
            def analyze_papers_step():
                """Analyze retrieved papers with security policy enforcement."""
                print("🔬 Step 2: Analyzing papers...")

                # Security check: Ensure no unauthorized PHI access
                accessing_phi = False  # In real scenario, check permissions

                if accessing_phi:
                    # Record policy violation
                    print("   🚨 Policy violation detected: Unauthorized PHI access")
                    client.record_policy_violation(policy_type="phi_access_violation")
                    raise PermissionError("Unauthorized PHI access blocked")
                else:
                    print("   🔒 Security check passed (no policy violations)")

                # Perform analysis
                with client.track_tool("ml_analyzer", goal_id=goal_id) as span:
                    print("   ⏱️  Tool call: ml_analyzer")
                    time.sleep(0.2)
                    span.set_attribute("analysis_type", "meta_analysis")
                    span.set_attribute("confidence_score", 0.89)
                    print("   ✅ Analysis complete")
                    print()

                return {"analysis": "Latest treatments show 23% efficacy improvement"}

            analysis_results = analyze_papers_step()
            print(f"   📈 Analysis result: {analysis_results['analysis']}")
            print()

            # Step 3: Report generation
            @trace_agent_step(client, step_id="generate-report")
            def generate_report_step():
                """Generate final research report."""
                print("📝 Step 3: Generating report...")

                with client.track_tool("report_generator", goal_id=goal_id) as span:
                    print("   ⏱️  Tool call: report_generator")
                    time.sleep(0.15)
                    span.set_attribute("report_format", "markdown")
                    span.set_attribute("pages_generated", 8)
                    print("   ✅ Report generated")
                    print()

                return {"report_path": "/reports/diabetes_treatment_2026.md"}

            report = generate_report_step()
            print(f"   📄 Report saved: {report['report_path']}")
            print()

            return {
                "search": search_results,
                "analysis": analysis_results,
                "report": report
            }

        # Execute the research goal
        print("▶️  Starting research agent execution...")
        print()
        results = execute_research_goal()

        print("=" * 70)
        print("✅ GOAL COMPLETED SUCCESSFULLY")
        print("=" * 70)
        print()
        print("📊 TELEMETRY SUMMARY:")
        print("   • Goal-level metrics: agent_start_time, agent_end_time, goal_completion_time")
        print("   • Step-level metrics: 3 steps tracked (step_id, timestamps)")
        print("   • Tool executions: 4 tools (1 failed + retry)")
        print("   • Recovery tracking: recovery_attempted=True, recovery_success=True")
        print("   • HITL events: 1 human intervention (api_timeout)")
        print("   • Policy checks: 0 violations")
        print("   • Span hierarchy: goal → steps → tools")
        print()
        print("🔍 All 13 data points captured per Story 1.19 spec:")
        print("   1. goal_description      7. step_start_time          13. policy_violated_type")
        print("   2. goal_type             8. step_end_time")
        print("   3. agent_start_time      9. tool_latency")
        print("   4. agent_end_time       10. tool_success")
        print("   5. goal_completion_time 11. recovery_attempted")
        print("   6. step_id              12. recovery_success")
        print()
        print("Plus HITL events: human_intervention_required, Human_intervention_reason,")
        print("                  human_intervention_timestamp")
        print()
        print("Plus Policy events: unauthorized_action_attempted, policy_violated_type")
        print()

    finally:
        # Graceful shutdown
        print("🔄 Flushing telemetry...")
        client.shutdown()
        print("✅ SDK shutdown complete")
        print()


if __name__ == "__main__":
    simulate_research_agent()
