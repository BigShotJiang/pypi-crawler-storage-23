# Advanced Agentic Metrics Example (Story 1.19)

Comprehensive demonstration of advanced agentic AI telemetry features including step-level tracking, tool recovery, human-in-the-loop events, and policy violation monitoring.

## Features Demonstrated

### 1. Goal-Level Tracking
- `@trace_agent_goal` decorator for automatic lifecycle tracking
- Captures: `agent_start_time`, `agent_end_time`, `goal_completion_time`
- Attributes: `goal_description`, `goal_type`

### 2. Step-Level Tracking
- `@trace_agent_step` decorator for reasoning step instrumentation
- Captures: `step_start_time`, `step_end_time`
- Attributes: `step_id` (UUID or custom)

### 3. Tool Recovery Tracking
- Automatic retry detection via state tracking
- Attributes: `tool_success`, `recovery_attempted`, `recovery_success`
- Measures: `tool_latency` (span duration)

### 4. Human-in-the-Loop (HITL) Events
- `record_human_intervention(reason, timestamp)` for HITL events
- Span event: `genai.agent.human_intervention`
- Attributes: `intervention.required`, `intervention.reason`
- Timestamp: Native OTel event timestamp

### 5. Policy Violation Events
- `record_policy_violation(policy_type)` for security events
- Span event: `genai.agent.policy_violation`
- Attributes: `violation.unauthorized_attempt`, `violation.policy_type`

## Data Dictionary Compliance

All 13 data points from Story 1.19 specification:

| # | Field Name | Source | Type |
|---|------------|--------|------|
| 1 | goal_description | span attribute | string |
| 2 | goal_type | span attribute | string |
| 3 | agent_start_time | span start timestamp | timestamp |
| 4 | agent_end_time | span end timestamp | timestamp |
| 5 | goal_completion_time | span duration | float |
| 6 | step_id | span attribute | UUID |
| 7 | step_start_time | span start timestamp | timestamp |
| 8 | step_end_time | span end timestamp | timestamp |
| 9 | tool_latency | span duration | float |
| 10 | tool_success | span attribute | boolean |
| 11 | recovery_attempted | span attribute | boolean |
| 12 | recovery_success | span attribute | boolean |
| 13 | (events) | span events | - |

Plus HITL event fields:
- `human_intervention_required` (event attribute)
- `Human_intervention_reason` (event attribute)
- `human_intervention_timestamp` (event timestamp)

Plus policy event fields:
- `unauthorized_action_attempted` (event attribute)
- `policy_violated_type` (event attribute)

## Usage

### Prerequisites

```bash
# Start OTel Collector
docker-compose up -d otel-collector

# Install SDK
pip install -e ../../
```

### Run Example

```bash
python agent_with_advanced_metrics.py
```

### Expected Output

```
======================================================================
ADVANCED AGENTIC METRICS DEMO - Story 1.19
======================================================================

🎯 Goal started: <goal-id>

📚 Step 1: Searching PubMed database...
   ⏱️  Tool call #1: pubmed_api
   ❌ Tool failed: PubMed API timeout (simulated)

🙋 Human intervention required (API timeout)
   ✓ HITL event recorded

   🔄 Retrying after intervention...
   ⏱️  Tool call #2: pubmed_api (retry)
   ✅ Tool succeeded on retry (recovery_attempted=True, recovery_success=True)

   📊 Search complete: 42 papers found

🔬 Step 2: Analyzing papers...
   🔒 Security check passed (no policy violations)
   ⏱️  Tool call: ml_analyzer
   ✅ Analysis complete

   📈 Analysis result: Latest treatments show 23% efficacy improvement

📝 Step 3: Generating report...
   ⏱️  Tool call: report_generator
   ✅ Report generated

   📄 Report saved: /reports/diabetes_treatment_2026.md

======================================================================
✅ GOAL COMPLETED SUCCESSFULLY
======================================================================

📊 TELEMETRY SUMMARY:
   • Goal-level metrics: agent_start_time, agent_end_time, goal_completion_time
   • Step-level metrics: 3 steps tracked (step_id, timestamps)
   • Tool executions: 4 tools (1 failed + retry)
   • Recovery tracking: recovery_attempted=True, recovery_success=True
   • HITL events: 1 human intervention (api_timeout)
   • Policy checks: 0 violations
   • Span hierarchy: goal → steps → tools
```

## Observability

### Span Hierarchy

```
agent.goal (research-agent-advanced)
├── agent.step (pubmed-search)
│   ├── agent.tool.pubmed_api [FAILED]
│   └── agent.tool.pubmed_api [SUCCESS, recovery_attempted=True]
├── agent.step (analyze-papers)
│   └── agent.tool.ml_analyzer
└── agent.step (generate-report)
    └── agent.tool.report_generator
```

### Metrics Generated

- `agentic.goals_started_total{goal_type="medical_research"}`
- `agentic.goals_completed_total{status="success"}`
- `agentic.goal_duration_seconds{status="success"}`
- `agentic.tool_calls_total{tool_name="pubmed_api", status="error"}`
- `agentic.tool_calls_total{tool_name="pubmed_api", status="success"}`
- `agentic.tool_errors_total{tool_name="pubmed_api"}`
- `agentic.human_interventions_total{reason="api_timeout_needs_troubleshooting"}`

### Span Events

1. **genai.agent.human_intervention**
   - `intervention.required: true`
   - `intervention.reason: "api_timeout_needs_troubleshooting"`
   - timestamp: precise event time

2. **genai.agent.policy_violation** (if triggered)
   - `violation.unauthorized_attempt: true`
   - `violation.policy_type: "phi_access_violation"`

## Architecture Notes

### Attribute Naming Convention

All agent-specific attributes use the `genai.agent.*` prefix:
- `genai.agent.goal.description`
- `genai.agent.goal.type`
- `genai.agent.step.id`
- `genai.agent.tool.success`
- `genai.agent.recovery.attempted`
- `genai.agent.recovery.success`

### Recovery Tracking Mechanism

The SDK maintains a thread-safe state dictionary mapping `(goal_id, tool_name)` tuples to execution state:

```python
{
  ("goal-123", "pubmed_api"): {
    "attempts": 2,
    "first_failed": True
  }
}
```

When a tool is called:
1. If state exists with `first_failed=True`, mark span with `recovery_attempted=True`
2. On success, mark span with `recovery_success=True` and clear state
3. On failure again, mark span with `recovery_success=False`

### HIPAA Compliance

**CRITICAL:** This example uses generic descriptions. In production:
- NEVER include PHI in `goal_description`
- NEVER include PHI in `Human_intervention_reason`
- NEVER include PHI in `policy_violated_type`
- Use generic categories only (e.g., "patient_data_analysis" not "John Doe diabetes analysis")

## Testing

Run integration tests to verify all data points:

```bash
pytest tests/integration/test_agentic_advanced_integration.py -v
```

Expected: 12/12 tests passing

## References

- Story 1.19: Implement Advanced Agentic Metrics Instrumentation
- Story 1.11: Basic Agentic AI Goal and Tool Tracking (foundation)
- OpenTelemetry Semantic Conventions for AI/ML
- User's architectural plan (2026-03-02)
