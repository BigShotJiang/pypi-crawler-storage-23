# Registry-integrated GenAI example for MCA SDK.
# Demonstrates how a data scientist uses the Model Registry to dynamically
# configure a GenAI clinical referral triage assistant with runtime thresholds.
#
# Key features demonstrated:
#   - Registry-first configuration (thresholds, team_name, extra_resource)
#   - Threshold-driven runtime behavior (latency/cost warnings)
#   - Background refresh (thresholds update without restart)
#   - Graceful fallback when registry is unavailable

import os
import sys
import time
import random
import logging

from mca_sdk.integrations import create_genai_client, estimate_openai_cost, track_llm_completion

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s"
)

# ==========================================
# Configuration from environment
# ==========================================
OTEL_ENDPOINT = os.environ.get("MCA_COLLECTOR_ENDPOINT", "http://10.164.76.8:4318")
REGISTRY_URL = os.environ.get("MCA_REGISTRY_URL", "https://emms-registration-api-dev-rlaptra7zq-ue.a.run.app")
USE_GCP_AUTH = os.environ.get("MCA_USE_GCP_AUTH", "true").lower() == "true"
ALLOW_INSECURE_COLLECTOR = os.environ.get("MCA_ALLOW_INSECURE_COLLECTOR", "true").lower() == "true"

# Use one of the existing model configs from the Registration API
# Options: 2272bb1d-b2ec-4f4e-bcc5-18f7215f5908 (regression)
#          256c8edd-1abe-4ec3-9cc6-18a760be5718 (generative)
#          7a6fd3b1-3d8c-4768-9100-a8628d1f6237 (classification)
MODEL_ID = os.environ.get("MCA_MODEL_ID", "256c8edd-1abe-4ec3-9cc6-18a760be5718")  # GenAI model
MODEL_VERSION = "1.0.0"

print("=" * 70)
print("Registry-Integrated GenAI Referral Triage Assistant")
print("=" * 70)
print(f"Registry URL: {REGISTRY_URL}")
print(f"OTLP Endpoint: {OTEL_ENDPOINT}")
print(f"Model: {MODEL_ID} v{MODEL_VERSION}")
print()

# ==========================================
# Initialize MCA SDK client WITH registry
# ==========================================
# create_genai_client passes **kwargs through to MCAClient, which
# triggers _hydrate_from_registry() when registry_url is set.
# This fetches ModelConfig including thresholds and extra_resource.
# If registry is unavailable, falls back to local config gracefully.

print("Initializing MCA SDK client with registry integration...")
client = create_genai_client(
    service_name="clinical-notes-summarizer-v2",  # From registry config
    llm_provider="openai",
    llm_model="gpt-4",
    team_name="ai-innovation-team",  # From registry config
    model_id=MODEL_ID,
    model_version=MODEL_VERSION,
    collector_endpoint=OTEL_ENDPOINT,
    allow_insecure_collector=ALLOW_INSECURE_COLLECTOR,
    metric_export_interval_ms=5000,
    registry_url=REGISTRY_URL,
    use_gcp_auth=USE_GCP_AUTH,
    refresh_interval_secs=60,
)
print("Client initialized successfully!")

print("=" * 70)
print("NOTE: This example uses MOCK clinical data only.")
print("No real patient data (PHI) is used in this demonstration.")
print("=" * 70)

# ==========================================
# Display registry-derived configuration
# ==========================================
print("\n--- Registry Configuration ---")
thresholds = client.thresholds
if thresholds:
    print("  Thresholds loaded from registry:")
    for key, value in thresholds.items():
        print(f"    {key}: {value}")
else:
    print("  No thresholds (registry unavailable or not configured)")
    print("  Operating in fallback mode with local-only config")

# ==========================================
# Mock Clinical Referral Data
# No real patient data - for demonstration purposes only
# ==========================================
MOCK_REFERRALS = [
    {
        "specialty": "cardiology",
        "urgency": "routine",
        "summary": "54yo male, mild chest discomfort on exertion, normal EKG, elevated lipids",
        "mock_latency_range": (0.1, 0.4),
    },
    {
        "specialty": "endocrinology",
        "urgency": "urgent",
        "summary": "62yo female, new-onset diabetes with HbA1c 11.2%, weight loss, polyuria",
        "mock_latency_range": (0.3, 0.8),
    },
    {
        "specialty": "neurology",
        "urgency": "stat",
        "summary": "45yo male, sudden onset severe headache, neck stiffness, photophobia",
        "mock_latency_range": (0.5, 2.5),
    },
    {
        "specialty": "orthopedics",
        "urgency": "routine",
        "summary": "38yo female, chronic knee pain, failed physical therapy, MRI showing meniscal tear",
        "mock_latency_range": (0.1, 0.3),
    },
]

MOCK_TRIAGE_RESPONSES = [
    "Triage: ROUTINE - Schedule within 2-4 weeks. Risk: low. Recommend lipid panel follow-up.",
    "Triage: URGENT - Schedule within 48-72 hours. Risk: moderate-high. Immediate insulin initiation.",
    "Triage: STAT - Immediate referral. Risk: critical. Rule out subarachnoid hemorrhage.",
    "Triage: ROUTINE - Schedule within 2-4 weeks. Risk: low. Pre-op evaluation if surgical candidate.",
]


def triage_referral(referral: dict) -> dict:
    """Simulate GenAI-powered referral triage with registry threshold checks."""
    start_time = time.time()

    # Simulate LLM call with variable latency
    min_lat, max_lat = referral["mock_latency_range"]
    simulated_latency = random.uniform(min_lat, max_lat)
    time.sleep(simulated_latency * 0.1)  # Scale down for demo speed

    latency = time.time() - start_time
    latency_ms = latency * 1000

    # Mock token counts
    prompt_tokens = random.randint(80, 150)
    completion_tokens = random.randint(40, 100)
    model_name = "gpt-4-mock"
    total_cost = estimate_openai_cost("gpt-4", prompt_tokens, completion_tokens)

    # Record telemetry via SDK
    track_llm_completion(
        client=client,
        model=model_name,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        latency=latency,
        status="success"
    )

    # ==========================================
    # THRESHOLD-DRIVEN BEHAVIOR (registry feature)
    # client.thresholds is always fresh (updated by background refresh thread)
    # ==========================================
    current_thresholds = client.thresholds
    warnings_emitted = []

    if current_thresholds:
        # Check latency thresholds
        latency_warn = current_thresholds.get("latency_warn_ms", float("inf"))
        latency_critical = current_thresholds.get("latency_critical_ms", float("inf"))

        if latency_ms > latency_critical:
            client.logger.warning(
                "CRITICAL: Latency exceeds critical threshold",
                extra={
                    "latency_ms": round(latency_ms, 1),
                    "threshold_ms": latency_critical,
                    "specialty": referral["specialty"],
                    "urgency": referral["urgency"],
                }
            )
            warnings_emitted.append(
                f"CRITICAL LATENCY: {latency_ms:.0f}ms > {latency_critical}ms"
            )
        elif latency_ms > latency_warn:
            client.logger.warning(
                "WARNING: Latency exceeds warning threshold",
                extra={
                    "latency_ms": round(latency_ms, 1),
                    "threshold_ms": latency_warn,
                    "specialty": referral["specialty"],
                }
            )
            warnings_emitted.append(
                f"HIGH LATENCY: {latency_ms:.0f}ms > {latency_warn}ms"
            )

        # Check cost thresholds
        cost_warn = current_thresholds.get("cost_warn_usd", float("inf"))
        if total_cost > cost_warn:
            client.logger.warning(
                "WARNING: Cost exceeds warning threshold",
                extra={"cost_usd": round(total_cost, 6), "threshold_usd": cost_warn}
            )
            warnings_emitted.append(f"HIGH COST: ${total_cost:.4f} > ${cost_warn}")

    # Select mock response
    idx = MOCK_REFERRALS.index(referral)
    response_text = MOCK_TRIAGE_RESPONSES[idx]

    return {
        "response": response_text,
        "latency_ms": latency_ms,
        "cost_usd": total_cost,
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "warnings": warnings_emitted,
        "thresholds_active": bool(current_thresholds),
    }


# ==========================================
# Main Loop
# ==========================================
if __name__ == "__main__":
    print(f"\nStarting referral triage loop...")
    print(f"Thresholds active: {bool(client.thresholds)}")
    print("Press Ctrl+C to stop\n")
    print("TIP: This demo uses GCP Registration API for configuration.")
    print(f"  Model ID: {MODEL_ID}")
    print(f"  Registry: {REGISTRY_URL}")
    print(f"  Authentication: GCP ADC (use_gcp_auth={USE_GCP_AUTH})")
    print(f"  Collector: {OTEL_ENDPOINT}")
    print("  Background refresh: Thresholds update every 60 seconds from registry")
    print()

    iteration = 0

    try:
        while True:
            iteration += 1
            referral = MOCK_REFERRALS[iteration % len(MOCK_REFERRALS)]

            print(f"\n{'='*70}")
            print(f"Iteration #{iteration} - {time.strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"{'='*70}")
            print(f"Specialty: {referral['specialty']} | Urgency: {referral['urgency']}")
            print(f"Summary: {referral['summary'][:60]}...")

            result = triage_referral(referral)

            print(f"\nResult: {result['response'][:80]}...")
            print(f"\nTelemetry:")
            print(f"  Latency: {result['latency_ms']:.1f}ms")
            print(f"  Cost: ${result['cost_usd']:.6f}")
            print(f"  Tokens: {result['prompt_tokens']}p + {result['completion_tokens']}c")
            print(f"  Thresholds active: {result['thresholds_active']}")

            if result["warnings"]:
                print(f"\n  Threshold Alerts:")
                for w in result["warnings"]:
                    print(f"    - {w}")

            print(f"\nWaiting 20 seconds...")
            time.sleep(20)

    except KeyboardInterrupt:
        print("\n\nShutting down gracefully...")
        print("Flushing telemetry via MCA SDK...")
        client.shutdown()
        print("Shutdown complete.")

    except Exception as e:
        print(f"\nError in main loop: {e}")
        client.shutdown()
        raise
