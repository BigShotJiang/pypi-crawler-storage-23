# Mock Model Registry server for demonstrating registry-integrated GenAI monitoring.
# Serves model configuration, thresholds, and resource attributes via REST API.
# Follows the same pattern as vendor-model/mock_vendor_api.py.

from fastapi import FastAPI, Query, HTTPException
from pydantic import BaseModel
from datetime import datetime, timezone
from typing import Dict, Optional
import logging
import copy

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Mock Model Registry")

# In-memory model configuration store
# Uses the two-field taxonomy: model_category + model_type
MODEL_CONFIGS = {
    "genai-referral-triage": {
        "1.0.0": {
            "service_name": "genai-referral-triage",
            "model_id": "genai-referral-triage",
            "model_version": "1.0.0",
            "team_name": "clinical-ai",
            "model_category": "internal",
            "model_type": "generative",
            "thresholds": {
                "latency_warn_ms": 500,
                "latency_critical_ms": 2000,
                "cost_warn_usd": 0.10,
                "cost_critical_usd": 0.50,
                "error_rate_warn": 0.05
            },
            "extra_resource": {
                "deployment.env": "staging",
                "deployment.region": "us-east-1",
                "compliance.hipaa": "true"
            }
        },
        "2.0.0": {
            "service_name": "genai-referral-triage",
            "model_id": "genai-referral-triage",
            "model_version": "2.0.0",
            "team_name": "clinical-ai",
            "model_category": "internal",
            "model_type": "generative",
            "thresholds": {
                "latency_warn_ms": 300,
                "latency_critical_ms": 1000,
                "cost_warn_usd": 0.05,
                "cost_critical_usd": 0.25,
                "error_rate_warn": 0.02
            },
            "extra_resource": {
                "deployment.env": "staging",
                "deployment.region": "us-east-1",
                "compliance.hipaa": "true"
            }
        }
    }
}


class ThresholdUpdate(BaseModel):
    """Request body for threshold updates."""
    thresholds: Dict[str, float]


@app.get("/health")
def health_check():
    """Health check endpoint for Docker healthcheck."""
    return {"status": "healthy", "timestamp": datetime.now(timezone.utc).isoformat()}


@app.get("/models/{model_id}")
def get_model_config(model_id: str, version: Optional[str] = Query(None)):
    """Fetch model configuration by ID and optional version.

    This matches the registry API contract:
        GET /models/{model_id}?version=X
        Response: ModelConfig JSON
    """
    if model_id not in MODEL_CONFIGS:
        raise HTTPException(status_code=404, detail=f"Model not found: {model_id}")

    versions = MODEL_CONFIGS[model_id]

    if version:
        if version not in versions:
            raise HTTPException(
                status_code=404,
                detail=f"Version {version} not found for model {model_id}"
            )
        logger.info(f"Serving config for {model_id} v{version}")
        return copy.deepcopy(versions[version])

    # Return latest version if no version specified
    latest = sorted(versions.keys())[-1]
    logger.info(f"Serving latest config for {model_id} v{latest}")
    return copy.deepcopy(versions[latest])


@app.put("/models/{model_id}/thresholds")
def update_thresholds(
    model_id: str,
    body: ThresholdUpdate,
    version: Optional[str] = Query(None),
):
    """Update thresholds at runtime to demonstrate background refresh.

    Usage:
        curl -X PUT "http://localhost:8090/models/genai-referral-triage/thresholds?version=1.0.0" \
            -H "Content-Type: application/json" \
            -d '{"thresholds": {"latency_warn_ms": 200}}'
    """
    if model_id not in MODEL_CONFIGS:
        raise HTTPException(status_code=404, detail=f"Model not found: {model_id}")

    versions = MODEL_CONFIGS[model_id]
    target_version = version or sorted(versions.keys())[-1]

    if target_version not in versions:
        raise HTTPException(status_code=404, detail=f"Version {target_version} not found")

    # Merge new thresholds into existing
    old_thresholds = versions[target_version]["thresholds"].copy()
    versions[target_version]["thresholds"].update(body.thresholds)

    logger.info(
        f"Updated thresholds for {model_id} v{target_version}: "
        f"{old_thresholds} -> {versions[target_version]['thresholds']}"
    )
    return {
        "status": "updated",
        "model_id": model_id,
        "version": target_version,
        "thresholds": versions[target_version]["thresholds"],
    }


if __name__ == "__main__":
    import uvicorn

    print("Starting Mock Model Registry on port 8090...")
    print("Endpoints:")
    print("  GET  /health")
    print("  GET  /models/{model_id}?version=X")
    print("  PUT  /models/{model_id}/thresholds?version=X")
    print()
    uvicorn.run(app, host="0.0.0.0", port=8090)
