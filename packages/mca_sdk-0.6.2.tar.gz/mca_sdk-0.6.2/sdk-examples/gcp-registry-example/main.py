"""Example: Using MCA SDK with GCP Registry API.

This example demonstrates:
1. Connecting to GCP Cloud Run Registry API with automatic ID token authentication
2. Fetching model configuration using the /api/v1/configs endpoint
3. Listing and filtering model configurations
4. Response schema handling (config field mapping)

Prerequisites:
- Install: pip install mca-sdk[gcp-auth]
- Set up Application Default Credentials: gcloud auth application-default login
- Ensure you have access to the GCP project where the API is deployed
"""

import logging

from mca_sdk.registry.client import RegistryClient
from mca_sdk.utils.exceptions import RegistryError, RegistryConnectionError, RegistryAuthError

logger = logging.getLogger(__name__)

# GCP Cloud Run Registry API endpoint
REGISTRY_URL = "https://emms-registration-api-dev-rlaptra7zq-ue.a.run.app"


def main():
    """Demonstrate GCP Registry API integration."""
    logging.basicConfig(level=logging.INFO)

    logger.info("=== MCA SDK GCP Registry API Integration Example ===")

    # Create registry client.
    # For GCP Cloud Run endpoints (*.run.app), the SDK will automatically:
    # 1. Detect it's a GCP endpoint
    # 2. Fetch a Google ID token using Application Default Credentials
    # 3. Use the ID token for authentication (auto-refreshed every 55 minutes)
    logger.info("Connecting to: %s", REGISTRY_URL)
    logger.info("Authentication: Google ID token (via ADC)")

    try:
        client = RegistryClient(
            url=REGISTRY_URL,
            timeout=10.0
        )
        logger.info("Registry client created successfully")

        # Example 1: List all configurations
        logger.info("Example 1: List all configurations")
        try:
            result = client.list_configs(limit=5)
            logger.info("Total configs: %d", result["total"])
            logger.info("Showing first %d items:", len(result["items"]))

            for item in result["items"]:
                logger.info(
                    "  service_name=%s  model_id=%s  team=%s  category=%s  type=%s",
                    item.service_name,
                    item.model_id,
                    item.team_name,
                    item.model_category,
                    item.model_type,
                )

            if result["parse_failures"] > 0:
                logger.warning("%d item(s) could not be parsed", result["parse_failures"])
        except (RegistryConnectionError, RegistryAuthError, RegistryError) as e:
            logger.warning("Error listing configs: %s", e)

        # Example 2: Filter by team
        logger.info("Example 2: Filter by team name")
        try:
            result = client.list_configs(team_name="data-science")
            logger.info("Found %d configs for team 'data-science'", result["total"])
        except (RegistryConnectionError, RegistryAuthError, RegistryError) as e:
            logger.warning("Error filtering configs: %s", e)

        # Example 3: Filter by model type and category
        logger.info("Example 3: Filter by model type and category")
        try:
            result = client.list_configs(
                model_category="internal",
                model_type="classification"
            )
            logger.info("Found %d internal classification models", result["total"])
        except (RegistryConnectionError, RegistryAuthError, RegistryError) as e:
            logger.warning("Error filtering configs: %s", e)

        # Example 4: Fetch specific model configuration
        # Note: Replace with an actual model_id from your registry
        logger.info("Example 4: Fetch specific model configuration")
        logger.info("(Requires a valid model_id from your registry)")
        # Uncomment and provide a valid model_id to test:
        # try:
        #     config = client.fetch_model_config("550e8400-e29b-41d4-a716-446655440000")
        #     logger.info("Fetched config for: %s", config.service_name)
        #     logger.info("  Model Version: %s", config.model_version)
        #     logger.info("  Team: %s", config.team_name)
        #     logger.info("  Category: %s", config.model_category)
        #     logger.info("  Type: %s", config.model_type)
        #     logger.info("  Thresholds: %s", config.thresholds)
        #     logger.info("  Extra Resource: %s", config.extra_resource)
        # except RegistryConfigNotFoundError:
        #     logger.warning("Model not found")
        # except (RegistryConnectionError, RegistryAuthError, RegistryError) as e:
        #     logger.warning("Error fetching config: %s", e)

        logger.info("All examples completed successfully")

    except RegistryError as e:
        logger.error("Registry client initialization failed: %s", e)
        logger.error(
            "Troubleshooting: "
            "(1) gcloud auth application-default login  "
            "(2) Verify GCP project access  "
            "(3) pip install mca-sdk[gcp-auth]"
        )
        return 1
    finally:
        if "client" in locals():
            client.close()

    return 0


if __name__ == "__main__":
    exit(main())
