# GCP Registry Example

Demonstrates how to use the MCA SDK to fetch model configurations from a
GCP Cloud Run-hosted Registry API using automatic Google ID token authentication.

## Features Demonstrated

- Automatic GCP endpoint detection (*.run.app hostnames)
- Google ID token authentication via Application Default Credentials (ADC)
- Listing and filtering model configurations
- Fetching a specific model configuration by ID

## Prerequisites

- Python 3.10+
- `gcloud` CLI installed and authenticated

## Installation

```bash
pip install -r requirements.txt
```

## Setup

Authenticate with GCP Application Default Credentials:

```bash
gcloud auth application-default login
```

Ensure you have `roles/run.invoker` on the target Cloud Run service.

## Usage

```bash
python main.py
```

## Using GCP Development Infrastructure

To test against the real GCP dev environment collector instead of a local collector:

```bash
# Use Docker Compose override (if using registry-genai service)
docker-compose -f ../../docker-compose.yml -f ../../docker-compose.gcp-dev.yml up registry-genai

# Or set environment variables for local testing
export MCA_COLLECTOR_ENDPOINT=http://10.164.76.8:4318
export MCA_ALLOW_INSECURE_COLLECTOR=true
python main.py
```

See [GCP Dev Environment Guide](../../../docs/gcp-dev-environment.md) for complete setup instructions and troubleshooting.

### Verification

After running against GCP dev, verify telemetry in GCP Console:

```bash
# View logs
gcloud logging read "logName=projects/bhsf-ai-team-projects/logs/emms-model-telemetry" --limit=10

# View traces
gcloud trace list --project=bhsf-ai-team-projects --limit=10
```

Or use the GCP Console:
- **Logs**: [https://console.cloud.google.com/logs/query?project=bhsf-ai-team-projects](https://console.cloud.google.com/logs/query?project=bhsf-ai-team-projects)
- **Traces**: [https://console.cloud.google.com/traces/list?project=bhsf-ai-team-projects](https://console.cloud.google.com/traces/list?project=bhsf-ai-team-projects)

### Troubleshooting GCP Connectivity

**Cannot connect to 10.164.76.8:**
- Verify VPC connectivity or VPN access
- Test with: `curl http://10.164.76.8:4318/`

**Telemetry not appearing in GCP Console:**
- Verify collector endpoint is set correctly
- Check collector health: `curl http://10.164.76.8:13133/health/status`
- Wait 15 seconds for batch processing

## Files

- `main.py` - Main example script
- `requirements.txt` - Python dependencies (`mca-sdk[gcp-auth]`)
- `Dockerfile` - Containerized version

## Troubleshooting

### Authentication Error

If you see "Failed to configure Google ID token authentication":

1. Run `gcloud auth application-default login`
2. Verify you have access to the GCP project
3. Confirm `mca-sdk[gcp-auth]` is installed: `pip install mca-sdk[gcp-auth]`

### Connection Error

If you see "Failed to connect to registry":

1. Verify the `REGISTRY_URL` in `main.py` matches your deployed Cloud Run service
2. Confirm the service is running: `gcloud run services describe <service-name>`
