# Health Check Test Examples

This directory contains test scripts and examples for the OpenTelemetry Collector health check endpoint.

## Files

### test-health-check.py

Python script for testing the health check endpoint functionality.

**Features:**
- Tests endpoint accessibility
- Validates response structure
- Measures response time
- Checks for required fields (status, uptime)
- Provides detailed output

**Usage:**

```bash
# Test default endpoint (localhost:13133)
python test-health-check.py

# Test custom endpoint
python test-health-check.py --endpoint http://collector:13133/

# Verbose output with full response body
python test-health-check.py -v

# JSON output for automation
python test-health-check.py --json
```

**Example Output:**

```
============================================================
OpenTelemetry Collector Health Check Test Results
============================================================
✓ Health check PASSED
  Status Code: 200
  Response Time: 15.23ms
✓ Response structure is valid

Status: Server available
Uptime: 120s (2m 0s)
============================================================
```

**Requirements:**
- Python 3.7+
- No external dependencies (uses standard library)
- OTel Collector running with health check extension

## Testing Workflow

### 1. Start the Collector

```bash
cd ../../
docker-compose up -d otel-collector
```

### 2. Wait for Startup

```bash
# Wait 5 seconds for collector to initialize
sleep 5
```

### 3. Run Health Check Test

```bash
python test-health-check.py
```

### 4. Verify Results

Expected results:
- ✓ Health check PASSED
- Status Code: 200
- Response Time: <50ms
- Status: "Server available"

## Integration with CI/CD

### GitHub Actions Example

```yaml
- name: Test Health Check
  run: |
    cd mca-prototype/config/examples
    python test-health-check.py --json > health-check-results.json
    
- name: Verify Health Check
  run: |
    if [ $(jq -r '.success' health-check-results.json) != "true" ]; then
      echo "Health check failed"
      exit 1
    fi
```

### Docker Compose Test

```bash
# Start collector
docker-compose up -d otel-collector

# Wait for startup
sleep 5

# Test health check
docker-compose exec otel-collector curl -f http://localhost:13133/

# Check exit code
if [ $? -eq 0 ]; then
  echo "Health check passed"
else
  echo "Health check failed"
  exit 1
fi
```

## Troubleshooting

### Connection Refused

**Error:**
```
Connection Error: [Errno 61] Connection refused
```

**Solution:**
1. Verify collector is running: `docker ps | grep otel-collector`
2. Check collector logs: `docker logs mca-otel-collector`
3. Verify port is exposed: `docker port mca-otel-collector 13133`

### Slow Response Time

**Warning:**
```
⚠ WARNING: Response time exceeds 50ms threshold
```

**Solution:**
1. Check collector resource usage: `docker stats mca-otel-collector`
2. Reduce check frequency in config
3. Increase collector resources

### Invalid JSON Response

**Error:**
```
Invalid JSON response: Expecting value: line 1 column 1 (char 0)
```

**Solution:**
1. Verify health check extension is configured
2. Check collector version supports health_check extension
3. Review collector logs for errors

## Related Documentation

- [Health Check Documentation](../../../docs/health-check.md)
- [OTel Collector Configuration](../otel-collector-config.yaml)
- [Docker Compose Configuration](../../docker-compose.yml)
- [Integration Tests](../../../tests/integration/test_health_check.py)
