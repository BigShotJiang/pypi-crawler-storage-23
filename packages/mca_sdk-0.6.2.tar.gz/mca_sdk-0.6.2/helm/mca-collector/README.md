# MCA Collector Helm Chart

Helm chart for deploying the OpenTelemetry Collector for MCA SDK model monitoring.

## Overview

This Helm chart deploys a production-ready OpenTelemetry Collector configured for healthcare ML model monitoring at Baptist Health South Florida (BHSF). The collector receives telemetry data (metrics, logs, traces) from ML models instrumented with the MCA SDK and forwards it to various backends (Prometheus, Cloud Logging, Cloud Trace, Langfuse).

## Features

- **High Availability**: StatefulSet with 3 replicas, pod anti-affinity, topology spread constraints
- **Auto-scaling**: HorizontalPodAutoscaler (HPA) for dynamic scaling (3-10 replicas)
- **Resilience**: PodDisruptionBudget (PDB) ensures minimum availability during disruptions
- **Security**: Non-root containers, read-only filesystem, dropped capabilities, network policies
- **Persistent Queue**: SSD-backed storage for buffering telemetry during backend outages
- **Multi-Environment**: Separate values files for dev, staging, and production
- **Parameterized Config**: Eliminates configuration duplication via Helm templating

## Prerequisites

- Kubernetes 1.24+
- Helm 3.8+
- PersistentVolume provisioner support (for queue storage)
- (Optional) GKE with Workload Identity for GCP exporter authentication

## Installation

### Quick Start (Development)

```bash
# Install with development defaults (1 replica, NodePort, debug exporter)
helm install mca-collector ./mca-prototype/helm/mca-collector \
  --namespace monitoring \
  --create-namespace
```

### Environment-Specific Deployments

#### Development

```bash
helm install mca-collector ./mca-prototype/helm/mca-collector \
  --values ./mca-prototype/helm/mca-collector/values-dev.yaml \
  --namespace monitoring \
  --create-namespace
```

#### Staging

```bash
helm install mca-collector ./mca-prototype/helm/mca-collector \
  --values ./mca-prototype/helm/mca-collector/values-staging.yaml \
  --namespace monitoring \
  --create-namespace
```

#### Production

```bash
helm install mca-collector ./mca-prototype/helm/mca-collector \
  --values ./mca-prototype/helm/mca-collector/values-prod.yaml \
  --namespace monitoring \
  --create-namespace
```

### Custom Configuration

```bash
# Override specific values
helm install mca-collector ./mca-prototype/helm/mca-collector \
  --namespace monitoring \
  --create-namespace \
  --set replicaCount=5 \
  --set resources.limits.memory=2Gi \
  --set externalService.type=LoadBalancer
```

## Configuration

### Key Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `namespace` | Namespace for collector deployment | `monitoring` |
| `replicaCount` | Number of collector replicas | `1` (dev), `3` (prod) |
| `image.repository` | Collector image repository | `otel/opentelemetry-collector-contrib` |
| `image.tag` | Collector image tag | `0.146.1` |
| `service.type` | Internal service type | `ClusterIP` |
| `externalService.enabled` | Enable external service | `false` (default), `true` (dev/prod) |
| `externalService.type` | External service type | `LoadBalancer` |
| `resources.requests.memory` | Memory request | `256Mi` (dev), `512Mi` (prod) |
| `resources.limits.memory` | Memory limit | `512Mi` (dev), `1Gi` (prod) |
| `hpa.enabled` | Enable HorizontalPodAutoscaler | `false` (dev), `true` (prod) |
| `pdb.enabled` | Enable PodDisruptionBudget | `false` (dev), `true` (prod) |
| `persistence.size` | PVC storage size | `5Gi` (dev), `10Gi` (prod) |
| `storageClass.enabled` | Create SSD StorageClass | `false` (dev), `true` (prod) |
| `networkPolicy.enabled` | Enable NetworkPolicy | `true` |
| `networkPolicy.ingress.otlpAllowedNamespaces` | Restrict OTLP to namespaces | `[]` (all namespaces) |
| `networkPolicy.egress.httpsDestinations` | Restrict HTTPS to IP ranges | `[]` (all destinations) |
| `gcp.workloadIdentity.enabled` | Enable GCP Workload Identity | `false` (dev), `true` (prod) |
| `terminationGracePeriodSeconds` | Pod termination grace period | `60` (dev), `90` (prod) |
| `debug.enabled` | Enable debug exporter | `false` |

### Full Parameter Reference

See [values.yaml](values.yaml) for complete list of configurable parameters with inline documentation.

## Collector Configuration

The OpenTelemetry Collector configuration is fully templated via the `config` section in values files. This eliminates the configuration duplication present in the Kustomize approach.

### Key Configuration Sections

#### Receivers

```yaml
config:
  receivers:
    otlp:
      protocols:
        http:
          endpoint: 0.0.0.0:4318
        grpc:
          endpoint: 0.0.0.0:4317
```

#### Processors

```yaml
config:
  processors:
    memory_limiter:
      limit_mib: 384
      spike_limit_mib: 128
    attributes:
      actions:
        - key: environment
          value: production  # Per-environment
          action: insert
    batch:
      timeout: 5s
      send_batch_size: 512
```

#### Exporters

**Development** (debug exporter):
```yaml
config:
  exporters:
    debug:
      verbosity: detailed
```

**Production** (GCP exporters):
```yaml
config:
  exporters:
    prometheus:
      endpoint: "0.0.0.0:8889"
      namespace: mca
    googlecloud/logs:
      project: bhsf-model-monitoring-prod
    googlecloud/trace:
      project: bhsf-model-monitoring-prod
```

### Environment-Specific Differences

| Configuration | Development | Staging | Production |
|--------------|-------------|---------|------------|
| Replicas | 1 | 2 | 3 |
| Service Type | NodePort | LoadBalancer | LoadBalancer |
| HPA | Disabled | Disabled | Enabled (3-10) |
| PDB | Disabled | Enabled (min 1) | Enabled (min 2) |
| Storage | 5Gi default | 10Gi SSD | 10Gi SSD |
| Exporters | `debug` | Prometheus, GCP | Prometheus, GCP |
| Log Level | `debug` | `info` | `info` |
| GCP Project | - | `bhsf-model-monitoring-staging` | `bhsf-model-monitoring-prod` |

## Usage

### Configuring MCA SDK

After installing the chart, configure your MCA SDK to send telemetry to the collector:

```python
from mca_sdk import MCAClient

# Get the collector endpoint (see NOTES.txt after installation)
client = MCAClient(
    service_name="readmission-model",
    model_id="mdl-001",
    team_name="clinical-ai",
    otel_endpoint="http://<COLLECTOR_IP>:4318",  # OTLP HTTP
    otel_protocol="http"
)

# Or use gRPC
client = MCAClient(
    service_name="readmission-model",
    model_id="mdl-001",
    team_name="clinical-ai",
    otel_endpoint="<COLLECTOR_IP>:4317",  # OTLP gRPC
    otel_protocol="grpc"
)
```

### Getting Collector Endpoints

```bash
# For NodePort (dev)
export NODE_PORT=$(kubectl get service mca-collector-external -n monitoring -o jsonpath='{.spec.ports[?(@.name=="otlp-http")].nodePort}')
export NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="ExternalIP")].address}')
echo "OTLP HTTP: http://$NODE_IP:$NODE_PORT"

# For LoadBalancer (staging/prod)
export LB_IP=$(kubectl get service mca-collector-external -n monitoring -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
echo "OTLP HTTP: http://$LB_IP:4318"
echo "OTLP gRPC: $LB_IP:4317"
```

### Verifying Deployment

```bash
# Check pod status
kubectl get pods -n monitoring -l app.kubernetes.io/name=mca-collector

# Check logs
kubectl logs -n monitoring -l app.kubernetes.io/name=mca-collector --tail=100

# Check health endpoint
kubectl port-forward -n monitoring svc/mca-collector 13133:13133
curl http://localhost:13133/

# Check metrics endpoint
kubectl port-forward -n monitoring svc/mca-collector 8888:8888
curl http://localhost:8888/metrics
```

## Upgrading

### Upgrade Chart

```bash
# Upgrade with new values
helm upgrade mca-collector ./mca-prototype/helm/mca-collector \
  --namespace monitoring \
  --values ./mca-prototype/helm/mca-collector/values-prod.yaml
```

### Rollback

```bash
# View revision history
helm history mca-collector -n monitoring

# Rollback to previous revision
helm rollback mca-collector -n monitoring
```

## Uninstallation

```bash
helm uninstall mca-collector -n monitoring
```

**Note:** This will also delete PersistentVolumeClaims if `persistence.enabled=true` and `storageClass.reclaimPolicy=Delete`.

## PVC Cleanup

StatefulSet PersistentVolumeClaims (PVCs) are not automatically deleted when:
1. The Helm chart is uninstalled
2. The StatefulSet is scaled down

### Manual PVC Cleanup

```bash
# List PVCs created by the collector
kubectl get pvc -n monitoring -l app.kubernetes.io/name=mca-collector

# Delete specific PVC (replace with actual name)
kubectl delete pvc queue-storage-mca-collector-0 -n monitoring

# Delete all collector PVCs
kubectl delete pvc -n monitoring -l app.kubernetes.io/name=mca-collector
```

### Automated Cleanup Script

```bash
#!/bin/bash
# cleanup-pvcs.sh - Remove orphaned collector PVCs

NAMESPACE="monitoring"
RELEASE_NAME="mca-collector"

# Get current replica count
CURRENT_REPLICAS=$(kubectl get statefulset ${RELEASE_NAME} -n ${NAMESPACE} -o jsonpath='{.spec.replicas}')

# Delete PVCs for replicas beyond current count
for i in $(seq ${CURRENT_REPLICAS} 10); do
  PVC_NAME="queue-storage-${RELEASE_NAME}-${i}"
  kubectl delete pvc ${PVC_NAME} -n ${NAMESPACE} --ignore-not-found=true
done
```

### Cost Management

Monitor PVC costs regularly:
```bash
# Check PVC usage and cost
kubectl get pvc -n monitoring --show-labels
kubectl top pvc -n monitoring
```

**Recommendation:** Set up alerts for orphaned PVCs in your cloud provider's billing console.

## Security

### Pod Security

- Runs as non-root user (UID 10001)
- Read-only root filesystem
- All capabilities dropped
- Privilege escalation disabled
- Seccomp profile: RuntimeDefault

### Network Security

By default, the NetworkPolicy allows OTLP ingress from all namespaces. For production, restrict to specific namespaces:

```yaml
networkPolicy:
  ingress:
    otlpAllowedNamespaces:
      - ml-models
      - data-science
```

#### NetworkPolicy Rules

- **OTLP ingress**: Configurable namespace restriction (default: all namespaces)
- **Health checks**: Allow from kube-system only
- **Metrics**: Allow from monitoring namespace only
- **Egress**: DNS (kube-system), HTTPS (configurable IP ranges), Prometheus

#### Network Policy - Egress Restrictions

By default, HTTPS egress is allowed to all destinations. For production, restrict to known IP ranges:

```yaml
networkPolicy:
  egress:
    httpsDestinations:
      - "35.199.192.0/19"  # GCP us-central1
      - "34.64.0.0/10"     # GCP services
      - "10.0.0.0/8"       # Internal corporate network
```

**Finding GCP API IP ranges:**
```bash
# Query GCP IP ranges
curl -s https://www.gstatic.com/ipranges/cloud.json | jq '.prefixes[] | select(.scope == "us-central1")'
```

**Note:** Restricting to specific IPs may require maintenance as cloud provider IPs change.

#### External Access

By default, the collector is only accessible within the cluster via ClusterIP service. For external access (from outside the cluster), enable the external service:

```yaml
externalService:
  enabled: true
  type: LoadBalancer  # or NodePort for development
```

**Security Warning:** NodePort exposes the collector on all cluster nodes. Use LoadBalancer with internal annotation for production.

### HIPAA Compliance

- **PHI Masking**: SDK applications MUST sanitize PHI before sending telemetry
- **Header Filtering**: Collector automatically deletes sensitive headers (Authorization, Cookie, X-Patient-ID, etc.)
- **Encryption**: Use HTTPS/TLS for external service endpoints in production
- **Access Control**: RBAC, NetworkPolicy, and ServiceAccount configured
- **Audit Logging**: All telemetry forwarded to Cloud Logging for audit trails

### GCP Authentication (Production)

For GCP exporters (Cloud Logging, Cloud Trace), configure Workload Identity:

1. Create GCP service account:
```bash
gcloud iam service-accounts create otel-collector-sa --project=bhsf-model-monitoring-prod
```

2. Grant permissions:
```bash
gcloud projects add-iam-policy-binding bhsf-model-monitoring-prod \
  --member="serviceAccount:otel-collector-sa@bhsf-model-monitoring-prod.iam.gserviceaccount.com" \
  --role="roles/logging.logWriter"

gcloud projects add-iam-policy-binding bhsf-model-monitoring-prod \
  --member="serviceAccount:otel-collector-sa@bhsf-model-monitoring-prod.iam.gserviceaccount.com" \
  --role="roles/cloudtrace.agent"
```

3. Bind K8s SA to GCP SA:
```bash
gcloud iam service-accounts add-iam-policy-binding \
  otel-collector-sa@bhsf-model-monitoring-prod.iam.gserviceaccount.com \
  --role roles/iam.workloadIdentityUser \
  --member "serviceAccount:bhsf-model-monitoring-prod.svc.id.goog[monitoring/otel-collector]"
```

4. Install with Workload Identity enabled:
```yaml
gcp:
  workloadIdentity:
    enabled: true
    serviceAccount: "otel-collector-sa@bhsf-model-monitoring-prod.iam.gserviceaccount.com"
```

## High Availability

### StatefulSet

- 3 replicas in production (1 in dev)
- OrderedReady pod management for graceful rollouts
- RollingUpdate strategy

### Pod Anti-Affinity

- Prefers scheduling replicas on different nodes
- Prevents single-node failure from taking down all collectors

### Topology Spread Constraints

- Ensures even distribution across availability zones
- `maxSkew: 1` for balanced placement

### PodDisruptionBudget

- Production: `minAvailable: 2` (requires 3 replicas)
- Prevents voluntary disruptions from reducing availability below 2 replicas
- Protects against node drains, evictions during cluster upgrades

### HorizontalPodAutoscaler

- Production: 3-10 replicas based on CPU (70%) and memory (80%)
- Fast scale-up: 50%/2 pods per minute
- Slow scale-down: 10%/1 pod per 3 minutes (prevents thrashing)

### HPA with StatefulSet - Known Limitations

The HorizontalPodAutoscaler targets the StatefulSet, which has specific considerations:

**Limitations:**
1. **gRPC Connection Rebalancing**: Existing gRPC streams to scaled-down pods may not automatically rebalance to remaining pods
2. **Ordered Scaling**: StatefulSet scales pods in order (0, 1, 2...), which may cause temporary imbalance
3. **PVC Retention**: Scaled-down pods leave behind PVCs (see PVC Cleanup section)

**Mitigation:**
- Use `terminationGracePeriodSeconds: 90` to allow graceful connection draining
- Configure SDK clients with connection retry and load balancing
- Monitor connection distribution across pods during scaling events

**SDK Client Configuration:**
```python
# Use round-robin load balancing for gRPC
from mca_sdk import MCAClient

client = MCAClient(
    otel_endpoint="http://otel-collector-headless.monitoring.svc.cluster.local:4318",  # Use headless service
    otel_protocol="http"  # HTTP protocol handles load balancing better than gRPC
)
```

**Alternative:** Use Deployment instead of StatefulSet if persistent storage is not required.

## Persistent Queue

- SSD-backed PersistentVolumeClaim (10Gi in prod)
- Buffers telemetry during backend outages
- Prevents data loss during network failures
- File storage extension: `/var/otel/queue`

### Termination Grace Period

The termination grace period must allow the collector to flush its internal buffers before shutdown. Calculate as:

```
terminationGracePeriodSeconds = (queue_size * avg_item_size * safety_factor) / throughput
```

Example for production (2000-item queue, 5s batch timeout, 2x safety):
```
90s = (2000 items * 5s batch timeout * 2x safety) / 100 items/sec throughput
```

Default: 60s (dev), 90s (prod)

### StorageClass Handling

The chart creates a StorageClass if `storageClass.enabled=true`. Since StorageClass is cluster-scoped, the chart uses a lookup to check if it already exists and skips creation if found. This allows multiple chart installations in different namespaces to share the same StorageClass.

**Alternative:** Disable StorageClass creation and create it manually cluster-wide:
```yaml
storageClass:
  enabled: false
persistence:
  storageClassName: "existing-ssd-storage"  # Reference existing StorageClass
```

## Monitoring

### Prometheus Metrics

The collector exposes internal metrics on port 8888:

```bash
kubectl port-forward -n monitoring svc/mca-collector 8888:8888
curl http://localhost:8888/metrics
```

Key metrics:
- `otelcol_receiver_accepted_spans` - Spans received
- `otelcol_receiver_refused_spans` - Spans rejected
- `otelcol_exporter_sent_spans` - Spans exported
- `otelcol_exporter_send_failed_spans` - Export failures
- `otelcol_processor_batch_batch_send_size` - Batch sizes
- `otelcol_process_runtime_heap_alloc_bytes` - Memory usage

### Health Checks

Liveness, readiness, and startup probes configured on port 13133:

```bash
curl http://<collector-pod>:13133/
```

### Logs

```bash
# View collector logs
kubectl logs -n monitoring -l app.kubernetes.io/name=mca-collector --tail=100 -f
```

### Enabling Debug Mode

To enable debug logging without modifying ConfigMap:

```bash
# Enable debug via upgrade
helm upgrade mca-collector ./mca-prototype/helm/mca-collector \
  --set debug.enabled=true \
  --set env[0].name=OTEL_LOG_LEVEL \
  --set env[0].value=debug \
  --reuse-values
```

Or create a debug values file:
```yaml
# values-debug.yaml
debug:
  enabled: true

env:
  - name: OTEL_LOG_LEVEL
    value: "debug"

config:
  service:
    telemetry:
      logs:
        level: debug
  exporters:
    debug:
      verbosity: detailed
  pipelines:
    metrics:
      exporters: [debug, prometheus]  # Add debug alongside production
```

## Troubleshooting

### Pods Not Starting

```bash
# Check pod events
kubectl describe pod -n monitoring -l app.kubernetes.io/name=mca-collector

# Check PVC status
kubectl get pvc -n monitoring

# Check StorageClass
kubectl get storageclass
```

### Connection Refused from SDK

```bash
# Verify service endpoints
kubectl get svc -n monitoring

# Test connectivity from inside cluster
kubectl run -it --rm debug --image=curlimages/curl --restart=Never -- \
  curl -v http://mca-collector.monitoring.svc.cluster.local:4318

# Check NetworkPolicy
kubectl get networkpolicy -n monitoring
kubectl describe networkpolicy mca-collector -n monitoring
```

### High Memory Usage

```bash
# Check memory_limiter processor configuration
kubectl get configmap mca-collector-config -n monitoring -o yaml

# Increase memory limits
helm upgrade mca-collector ./mca-prototype/helm/mca-collector \
  --set resources.limits.memory=2Gi \
  --set config.processors.memory_limiter.limit_mib=768
```

### Exporter Failures

```bash
# Check collector logs for exporter errors
kubectl logs -n monitoring -l app.kubernetes.io/name=mca-collector | grep -i error

# For GCP exporters, verify Workload Identity binding
kubectl describe serviceaccount mca-collector -n monitoring

# Test GCP API connectivity
kubectl exec -it -n monitoring <pod-name> -- curl -v https://logging.googleapis.com
```

### Queue Storage Full

```bash
# Check PVC usage
kubectl exec -it -n monitoring <pod-name> -- df -h /var/otel/queue

# Increase PVC size (if StorageClass allows expansion)
kubectl patch pvc queue-storage-mca-collector-0 -n monitoring \
  -p '{"spec":{"resources":{"requests":{"storage":"20Gi"}}}}'
```

## Migration from Kustomize

If you're migrating from the existing Kustomize deployment:

1. **Backup existing configuration:**
   ```bash
   kubectl get configmap otel-collector-config -n monitoring -o yaml > backup-configmap.yaml
   ```

2. **Uninstall Kustomize deployment:**
   ```bash
   kubectl delete -k mca-prototype/k8s/overlays/prod/
   ```

3. **Install Helm chart:**
   ```bash
   helm install mca-collector ./mca-prototype/helm/mca-collector \
     --values ./mca-prototype/helm/mca-collector/values-prod.yaml \
     --namespace monitoring
   ```

4. **Verify migration:**
   ```bash
   kubectl get all -n monitoring
   helm status mca-collector -n monitoring
   ```

## Development

### Linting

```bash
helm lint ./mca-prototype/helm/mca-collector/
```

### Template Rendering

```bash
# Render dev templates
helm template test-release ./mca-prototype/helm/mca-collector/ \
  --values ./mca-prototype/helm/mca-collector/values-dev.yaml \
  --namespace monitoring \
  --debug

# Render prod templates
helm template test-release ./mca-prototype/helm/mca-collector/ \
  --values ./mca-prototype/helm/mca-collector/values-prod.yaml \
  --namespace monitoring \
  --debug
```

### Dry Run

```bash
helm install mca-collector ./mca-prototype/helm/mca-collector \
  --values ./mca-prototype/helm/mca-collector/values-prod.yaml \
  --namespace monitoring \
  --dry-run --debug
```

### Packaging

```bash
# Package chart
helm package ./mca-prototype/helm/mca-collector/

# Create chart repository index
helm repo index .
```

## Contributing

See the main [MCA SDK repository](https://github.com/bhsf/mca-sdk) for contribution guidelines.

## License

Copyright 2026 Baptist Health South Florida. Internal use only.

## Support

For issues or questions:
- File an issue: https://github.com/bhsf/mca-sdk/issues
- Contact: mca-sdk@bhsf.org
