"""Noto Sans subset font data."""
