"""GHEA Grapalat subset font data."""
