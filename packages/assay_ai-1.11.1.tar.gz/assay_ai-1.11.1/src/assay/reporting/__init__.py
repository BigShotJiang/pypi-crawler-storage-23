"""Assay reporting: generate shareable artifacts from scan results."""

from assay.reporting import score_report  # noqa: F401
