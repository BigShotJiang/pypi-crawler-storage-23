# TAY Community Bot

A powerful Free Fire automation bot for Python.

## Installation

```bash
pip install taycommunity