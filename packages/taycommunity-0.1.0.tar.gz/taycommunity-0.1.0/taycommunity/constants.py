"""
Constants for TAYBot
"""

from taycommunity.utils import Uaa

# Headers for HTTP requests
Hr = {
    'User-Agent': Uaa(),
    'Connection': "Keep-Alive",
    'Accept-Encoding': "gzip",
    'Content-Type': "application/x-www-form-urlencoded",
    'Expect': "100-continue",
    'X-Unity-Version': "2018.4.11f1",
    'X-GA': "v1 1",
}

# Default values
DEFAULT_TIMEOUT = 30
MAX_RETRIES = 3
RECONNECT_DELAY = 0.5