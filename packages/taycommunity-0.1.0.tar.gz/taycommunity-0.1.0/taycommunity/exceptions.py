"""
Exceptions for TAYBot
"""

class TAYBotError(Exception):
    """Base exception for TAYBot"""
    pass

class LoginError(TAYBotError):
    """Raised when login fails"""
    pass

class ConnectionError(TAYBotError):
    """Raised when connection fails"""
    pass

class AuthenticationError(TAYBotError):
    """Raised when authentication fails"""
    pass

class PacketError(TAYBotError):
    """Raised when packet creation/decoding fails"""
    pass