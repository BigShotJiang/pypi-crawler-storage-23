"""
Core functions and packet generators for TAYBot
Original by RedZed PARAHEX
"""

import requests
import json
import binascii
import time
import urllib3
import base64
import datetime
import re
import socket
import threading
import random
import os
import asyncio
from typing import Optional, Any, Dict, List, Tuple
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from datetime import datetime
from google.protobuf.timestamp_pb2 import Timestamp
from protobuf_decoder.protobuf_decoder import Parser

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Global keys
Key = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
Iv = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

# ==================== ENCRYPTION FUNCTIONS ====================

async def encrypted_proto(encoded_hex: bytes) -> bytes:
    """Encrypt protobuf data with AES"""
    key = b'Yg&tc%DEuh6%Zc^8'
    iv = b'6oyZDr22E3ychjM%'
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded_message = pad(encoded_hex, AES.block_size)
    encrypted_payload = cipher.encrypt(padded_message)
    return encrypted_payload

async def EnC_AEs(HeX: str) -> str:
    """Encrypt with AES using global keys"""
    cipher = AES.new(Key, AES.MODE_CBC, Iv)
    return cipher.encrypt(pad(bytes.fromhex(HeX), AES.block_size)).hex()

async def DEc_AEs(HeX: str) -> str:
    """Decrypt with AES using global keys"""
    cipher = AES.new(Key, AES.MODE_CBC, Iv)
    return unpad(cipher.decrypt(bytes.fromhex(HeX)), AES.block_size).hex()

async def EnC_PacKeT(HeX: str, K: bytes, V: bytes) -> str:
    """Encrypt packet with provided keys"""
    return AES.new(K, AES.MODE_CBC, V).encrypt(pad(bytes.fromhex(HeX), 16)).hex()

async def DEc_PacKeT(HeX: str, K: bytes, V: bytes) -> str:
    """Decrypt packet with provided keys"""
    return unpad(AES.new(K, AES.MODE_CBC, V).decrypt(bytes.fromhex(HeX)), 16).hex()

# ==================== UID ENCODING/DECODING ====================

async def EnC_Uid(H: str, Tp: str) -> str:
    """Encode UID to hex format"""
    e = []
    H = int(H)
    while H:
        e.append((H & 0x7F) | (0x80 if H > 0x7F else 0))
        H >>= 7
    return bytes(e).hex() if Tp == 'Uid' else None

async def EnC_Vr(N: int) -> bytes:
    """Encode varint"""
    if N < 0:
        return b''
    H = []
    while True:
        RedZed = N & 0x7F
        N >>= 7
        if N:
            RedZed |= 0x80
        H.append(RedZed)
        if not N:
            break
    return bytes(H)

def DEc_Uid(H: str) -> int:
    """Decode UID from hex"""
    n = 0
    s = 0
    for b in bytes.fromhex(H):
        n |= (b & 0x7F) << s
        if not b & 0x80:
            break
        s += 7
    return n

# ==================== PROTOBUF CREATION ====================

async def CrEaTe_VarianT(field_number: int, value: int) -> bytes:
    """Create variant field for protobuf"""
    field_header = (field_number << 3) | 0
    return await EnC_Vr(field_header) + await EnC_Vr(value)

async def CrEaTe_LenGTh(field_number: int, value: Any) -> bytes:
    """Create length-delimited field for protobuf"""
    field_header = (field_number << 3) | 2
    encoded_value = value.encode() if isinstance(value, str) else value
    return await EnC_Vr(field_header) + await EnC_Vr(len(encoded_value)) + encoded_value

async def CrEaTe_ProTo(fields: dict) -> bytearray:
    """Create protobuf packet from fields dictionary"""
    packet = bytearray()
    for field, value in fields.items():
        if isinstance(value, dict):
            nested_packet = await CrEaTe_ProTo(value)
            packet.extend(await CrEaTe_LenGTh(field, nested_packet))
        elif isinstance(value, int):
            packet.extend(await CrEaTe_VarianT(field, value))
        elif isinstance(value, (str, bytes)):
            packet.extend(await CrEaTe_LenGTh(field, value))
    return packet

async def DecodE_HeX(H: int) -> str:
    """Decode integer to hex string"""
    R = hex(H)
    F = str(R)[2:]
    if len(F) == 1:
        F = "0" + F
        return F
    else:
        return F

async def Fix_PackEt(parsed_results) -> dict:
    """Fix parsed packet results"""
    result_dict = {}
    for result in parsed_results:
        field_data = {}
        field_data['wire_type'] = result.wire_type
        if result.wire_type == "varint":
            field_data['data'] = result.data
        if result.wire_type == "string":
            field_data['data'] = result.data
        if result.wire_type == "bytes":
            field_data['data'] = result.data
        elif result.wire_type == 'length_delimited':
            field_data["data"] = await Fix_PackEt(result.data.results)
        result_dict[result.field] = field_data
    return result_dict

# ==================== PACKET DECODING ====================

async def DeCode_PackEt(input_text: str) -> Any:
    """Decode packet from hex string"""
    try:
        parsed_results = Parser().parse(input_text)
        parsed_results_objects = parsed_results
        parsed_results_dict = await Fix_PackEt(parsed_results_objects)
        json_data = json.dumps(parsed_results_dict)
        return json_data
    except Exception as e:
        print(f"error {e}")
        return None

async def DecodeWhisperMessage(hex_packet: str) -> Any:
    """Decode whisper message from hex"""
    from taycommunity.protos import DEcwHisPErMsG_pb2
    packet = bytes.fromhex(hex_packet)
    proto = DEcwHisPErMsG_pb2.DecodeWhisper()
    proto.ParseFromString(packet)
    return proto

async def EnC_UiDInFo(uid: int) -> str:
    """Encode UID for info packet"""
    fields = {1: int(uid)}
    uid_bytes = await CrEaTe_ProTo(fields)
    uid_hex = uid_bytes.hex()
    uid_hex = str(uid_hex)[2:]
    return uid_hex

# ==================== PACKET GENERATION ====================

async def GeneRaTePk(Pk: str, N: str, K: bytes, V: bytes) -> bytes:
    """Generate final packet with header"""
    PkEnc = await EnC_PacKeT(Pk, K, V)
    _ = await DecodE_HeX(int(len(PkEnc) // 2))
    if len(_) == 2:
        HeadEr = N + "000000"
    elif len(_) == 3:
        HeadEr = N + "00000"
    elif len(_) == 4:
        HeadEr = N + "0000"
    elif len(_) == 5:
        HeadEr = N + "000"
    else:
        HeadEr = N + "00000"
    return bytes.fromhex(HeadEr + _ + PkEnc)

async def xAuThSTarTuP(TarGeT: int, token: str, timestamp: int, key: bytes, iv: bytes) -> str:
    """Create authentication start packet"""
    uid_hex = hex(TarGeT)[2:]
    uid_length = len(uid_hex)
    
    headers_map = {
        7: '000000000',
        8: '00000000',
        9: '0000000',
        10: '000000'
    }
    headers = headers_map.get(uid_length, '0000000')
    
    encrypted_timestamp = str(timestamp)
    encrypted_account_token = token.encode().hex()
    
    return f"0115{headers}{uid_hex}{encrypted_timestamp}00000"

async def SendInFoPaCKeT(uid: str, key: bytes, iv: bytes) -> bytes:
    """Send info packet for UID"""
    uid_encoded = await EnC_UiDInFo(int(uid))
    hex_packet = f"080112090A05{uid_encoded}1005"
    return await GeneRaTePk(hex_packet, '0F15', key, iv)

async def GeT_Status(PLayer_Uid: int, K: bytes, V: bytes) -> bytes:
    """Get status packet"""
    PLayer_Uid_encoded = await EnC_Uid(str(PLayer_Uid), Tp='Uid')
    if len(PLayer_Uid_encoded) == 8:
        Pk = f'080112080a04{PLayer_Uid_encoded}1005'
    elif len(PLayer_Uid_encoded) == 10:
        Pk = f"080112090a05{PLayer_Uid_encoded}1005"
    else:
        Pk = f"080112090a05{PLayer_Uid_encoded}1005"
    return await GeneRaTePk(Pk, '0f15', K, V)

async def PlayerStatus(uid: int, key: bytes, iv: bytes) -> bytes:
    """Player status packet"""
    fields = {1: 1, 2: {1: int(uid), 5: 1}}
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0F15', key, iv)

async def SendRoomInfo(uid: int, key: bytes, iv: bytes) -> bytes:
    """Send room info request packet"""
    fields = {
        1: 1,
        2: {
            1: uid,
            3: {},
            4: 1,
            6: "en"
        }
    }
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0E15', key, iv)

async def xSEndMsg(Msg: str, Tp: int, Tp2: int, id: int, K: bytes, V: bytes) -> bytes:
    """Send message packet"""
    from taycommunity.utils import xBunnEr, xPiN
    fields = {
        1: id,
        2: Tp2,
        3: Tp,
        4: Msg,
        5: 1735129800,
        7: 2,
        9: {
            1: "TAYCommunity",
            2: int(await xBunnEr()),
            3: 901048018,
            4: 330,
            5: int(await xPiN()),
            8: "TAYCommunity",
            10: 1,
            11: 1,
            13: {1: 2},
            14: {1: 12484827014, 2: 8, 3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"},
            12: 0
        },
        10: "en",
        13: {3: 1}
    }
    Pk = (await CrEaTe_ProTo(fields)).hex()
    Pk = "080112" + await EnC_Uid(str(len(Pk) // 2), Tp='Uid') + Pk
    return await GeneRaTePk(Pk, '1215', K, V)

async def xSEndMsgsQ(Msg: str, id: int, K: bytes, V: bytes) -> bytes:
    """Send squad message packet"""
    from taycommunity.utils import xBunnEr
    fields = {
        1: id,
        2: id,
        4: Msg,
        5: 1756580149,
        7: 2,
        8: 904990072,
        9: {
            1: "TAYCommunity",
            2: await xBunnEr(),
            4: 330,
            5: 827001005,
            8: "TAYCommunity",
            10: 1,
            11: 1,
            13: {1: 2},
            14: {1: 1158053040, 2: 8, 3: "\u0010\u0015\b\n\u000b\u0015\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"}
        },
        10: "en",
        13: {2: 2, 3: 1}
    }
    Pk = (await CrEaTe_ProTo(fields)).hex()
    Pk = "080112" + await EnC_Uid(str(len(Pk) // 2), Tp='Uid') + Pk
    return await GeneRaTePk(Pk, '1215', K, V)

async def AuthClan(CLan_Uid: int, AuTh: str, K: bytes, V: bytes) -> bytes:
    """Authenticate clan packet"""
    fields = {1: 3, 2: {1: int(CLan_Uid), 2: 1, 4: str(AuTh)}}
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '1215', K, V)

async def RedZedLeaveRoom(uid: int, key: bytes, iv: bytes) -> bytes:
    """Leave room packet"""
    fields = {1: 6, 2: {1: uid}}
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0E15', key, iv)

async def RedZedJoinRomm(uid: int, password: str, key: bytes, iv: bytes) -> bytes:
    """Join room packet"""
    fields = {
        1: 3,
        2: {
            1: int(uid),
            2: str(password),
            8: {1: "IDC3", 2: 149, 3: "VN"},
            9: "\u0001\u0003\u0004\u0007\t\n\u000b\u0012\u000e\u0016\u0019 \u001d",
            10: 1,
            12: {},
            13: 1,
            14: 1,
            16: "en",
            22: {1: 21}
        }
    }
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0E15', key, iv)

async def RedZedRefuse(owner: int, uid: int, K: bytes, V: bytes) -> bytes:
    """Refuse invite packet"""
    fields = {
        1: 5,
        2: {
            1: int(owner),
            2: 1,
            3: int(uid),
            4: "[FF0000][B][C] HI , CẢM ƠN VÌ ĐÃ MUA BOT CỦA CHÚNG TÔI[FFFFFF]!\n Đang Nhận Tin Nhắn Đội[00FF00]Hãy Nhắn Để Sử Dụng Hành Động TAY BOT ! \n[FFFF00]CHÚC SỬ DỤNG BOT VUI VẺ !\n[FF0000]TELEGRAM : @TAYCommunity[000000]\n"
        }
    }
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', K, V)

async def RedZed_SendInv(uid: str, K: bytes, V: bytes) -> bytes:
    """Send invite packet"""
    from taycommunity.utils import xBunnEr
    fields = {
        1: 33,
        2: {
            1: int(uid),
            2: "VN",
            3: 1,
            4: 1,
            6: "TAYCommunity!!",
            7: 330,
            8: 1000,
            9: 100,
            10: "DZ",
            12: 1,
            13: int(uid),
            16: 1,
            17: {2: 159, 4: "y[WW", 6: 11, 8: "1.118.1", 9: 3, 10: 1},
            18: 306,
            19: 18,
            24: await xBunnEr(),
            26: {},
            27: {1: 11, 2: 12999994075, 3: 999},
            28: {},
            31: {1: 1, 2: 32768},
            32: 32768,
            34: {1: 12947882969, 2: 8, 3: "\u0010\u0015\b\n\u000b\u0013\f\u000f\u0011\u0004\u0007\u0002\u0003\r\u000e\u0012\u0001\u0005\u0006"}
        }
    }
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', K, V)

async def RedZedAccepted(uid: int, code: str, K: bytes, V: bytes) -> bytes:
    """Accept invite packet"""
    fields = {
        1: 4,
        2: {
            1: uid,
            3: uid,
            8: 1,
            9: {2: 161, 4: "y[WW", 6: 11, 8: "1.114.18", 9: 3, 10: 1},
            10: str(code),
        }
    }
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', K, V)

async def Emote_k(TarGeT: int, idT: int, K: bytes, V: bytes) -> bytes:
    """Send emote packet"""
    fields = {
        1: 21,
        2: {
            1: 804266360,
            2: 909000001,
            5: {1: TarGeT, 3: idT,}
        }
    }
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', K, V)

async def ExiT(idT: Any, K: bytes, V: bytes) -> bytes:
    """Exit squad packet"""
    fields = {1: 7, 2: {1: idT}}
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', K, V)

async def OpEnSq(K: bytes, V: bytes) -> bytes:
    """Open squad packet"""
    fields = {1: 1, 2: {2: "\u0001", 3: 1, 4: 1, 5: "en", 9: 1, 11: 1, 13: 1, 14: {2: 5756, 6: 11, 8: "1.111.5", 9: 2, 10: 4}}}
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', K, V)

async def cHSq(Nu: int, Uid: int, K: bytes, V: bytes) -> bytes:
    """Change squad packet"""
    fields = {1: 17, 2: {1: int(Uid), 2: 1, 3: int(Nu - 1), 4: 62, 5: "\u001a", 8: 5, 13: 329}}
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', K, V)

async def SEnd_InV(Nu: int, Uid: int, K: bytes, V: bytes) -> bytes:
    """Send invite packet"""
    fields = {1: 2, 2: {1: int(Uid), 2: "VN", 4: int(Nu)}}
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', K, V)

async def GenJoinSquadsPacket(code: str, K: bytes, V: bytes) -> bytes:
    """Generate join squad packet"""
    fields = {}
    fields[1] = 4
    fields[2] = {}
    fields[2][4] = bytes.fromhex("01090a0b121920")
    fields[2][5] = str(code)
    fields[2][6] = 6
    fields[2][8] = 1
    fields[2][9] = {}
    fields[2][9][2] = 800
    fields[2][9][6] = 11
    fields[2][9][8] = "1.111.1"
    fields[2][9][9] = 5
    fields[2][9][10] = 1
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', K, V)

async def SPam_Room(player_uid: str, room_id: str, K: bytes, V: bytes) -> bytes:
    """Spam room packet"""
    from taycommunity.utils import xBunnEr
    fields = {
        1: 78,
        2: {
            1: room_id,
            2: "[FF0000]TAY COMMUNITY",
            4: 330,
            5: 6000,
            6: 201,
            10: await xBunnEr(),
            11: player_uid,
            12: 1,
            13: {1: 11, 2: 13502539260, 3: 9999},
            15: {1: 1, 2: 32768},
            16: 32768,
            18: {1: 13502539260, 2: 8, 3: b"\x10\x15\x08\x0a\x0b\x13\x0c\x0f\x11\x04\x07\x02\x03\x0d\x0e\x12\x01\x05\x06"},
        }
    }
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0e15', K, V)

async def SwitchLoneWolf(key: bytes, iv: bytes) -> bytes:
    """Switch to lone wolf packet"""
    fields = {
        1: 1,
        2: {
            2: "\u000b",
            3: 43,
            4: 1,
            5: "en",
            9: 1,
            10: "\u0001\t\n\u000b\u0012\u0019\u001a ",
            11: 1,
            13: 1,
            14: {2: 86, 6: 11, 8: "1.118.10", 9: 3, 10: 1}
        }
    }
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', key, iv)

async def SwitchLoneWolfDule(BotUid: int, key: bytes, iv: bytes) -> bytes:
    """Switch to lone wolf duel packet"""
    fields = {1: 17, 2: {1: BotUid, 2: 1, 3: 1, 4: 43, 5: "\u000b", 8: 1, 19: 1}}
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', key, iv)

async def InvitePlayer(uid: int, key: bytes, iv: bytes) -> bytes:
    """Invite player packet"""
    fields = {1: 2, 2: {1: int(uid), 2: "VN", 4: 1}}
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', key, iv)

async def StartGame(BotUid: Any, key: bytes, iv: bytes) -> bytes:
    """Start game packet"""
    fields = {1: 9, 2: {1: BotUid}}
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', key, iv)

async def LeaveTeam(BotUid: Any, key: bytes, iv: bytes) -> bytes:
    """Leave team packet"""
    fields = {1: 7, 2: {1: BotUid}}
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', key, iv)

async def FS(K: bytes, V: bytes) -> bytes:
    """FS packet"""
    fields = {1: 9, 2: {1: 13250133060}}
    return await GeneRaTePk((await CrEaTe_ProTo(fields)).hex(), '0515', K, V)

async def Emote_auto(target_uid: int, key: bytes, iv: bytes) -> bytes:
    """Auto emote packet"""
    return await Emote_k(target_uid, 909000001, key, iv)

# ==================== PARSING FUNCTIONS ====================

def get_room_info(packet: str) -> str:
    """Parse room info from packet"""
    try:
        parsed_data = json.loads(packet)
        room_data = parsed_data['5']['data']['1']['data']
        room_id = int(room_data['1']['data'])
        owner_uid = int(room_data['37']['data']['1']['data'])
        room_name = room_data['2']['data']
        mode = room_data['4']['data']
        max_members = room_data['7']['data']
        specs_number = room_data['9']['data']
        
        try:
            members = room_data['6']['data']
        except:
            members = 0
            
        mode_names = {
            1: "BERMUDA",
            201: "BATTLE CAGE",
            15: "CLASH SQUAD",
            43: "LONE WOLF",
            3: "RUSH HOUR",
            27: "BOMB SQUAD 5v5",
            24: "DEATH MATCH"
        }
        mode = mode_names.get(mode, "UNKNOWN")
        
        return f"[B][00FF00]- PLAYER IS IN ROOM !\n\n[00FF00]- Room Name : [FFFFFF]{room_name}\n[00FF00]- Room ID : [FFFFFF]{room_id}\n[FFFF00]- Owner : [FFFFFF]{owner_uid}\n[FF0000]- Players : [FFFFFF]{members}/{max_members}\n[FF00FF]- Spectators : [FFFFFF]{specs_number}\n[FFA500]- Mode : [FFFFFF]{mode}"
    except:
        return "Failed to parse room info"

def get_player_status(packet: str) -> Any:
    """Parse player status from packet"""
    try:
        parsed_data = json.loads(packet)
        if "5" not in parsed_data or "data" not in parsed_data["5"]:
            return "OFFLINE"
        
        data = parsed_data["5"]["data"]["1"]["data"]
        status = data.get("3", {}).get("data", 0)
        
        if status == 4:  # In room
            room_uid = data.get("15", {}).get("data")
            return {"IN_ROOM": True, "room_uid": room_uid}
        elif status == 2:  # In squad
            return "IN SQUAD"
        elif status in [3, 5]:  # In game
            return "IN GAME"
        elif status == 1:  # Online
            return "ONLINE"
        else:
            return "UNKNOWN"
    except:
        return "OFFLINE"