"""
TAY Community - Free Fire Automation Bot
A powerful bot for Free Fire game automation
"""

__version__ = "1.0.0"
__author__ = "TAY Community"
__email__ = "taycommunity@example.com"

from taycommunity.client import TAYBot
from taycommunity.auth import guest
from taycommunity.core import *
from taycommunity.headers import *
from taycommunity.utils import get_random_color, xMsGFixinG

__all__ = [
    'TAYBot',
    'guest',
    'get_random_color',
    'xMsGFixinG'
]