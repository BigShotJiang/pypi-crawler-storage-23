"""
Message and event handlers for TAYBot
"""

from typing import Callable, Dict, Any

class MessageHandler:
    """Handles message routing and command processing"""
    
    def __init__(self):
        self._handlers: Dict[str, Callable] = {}
    
    def register(self, command: str, handler: Callable):
        """Register a command handler"""
        self._handlers[command.lower()] = handler
    
    async def handle(self, message: Any) -> bool:
        """Handle a message"""
        if not hasattr(message, 'text'):
            return False
            
        text = message.text.lower()
        
        if text.startswith('/'):
            command = text[1:].split()[0] if ' ' in text else text[1:]
            if command in self._handlers:
                await self._handlers[command](message)
                return True
        
        return False

class EventHandler:
    """Handles bot events"""
    
    def __init__(self):
        self._handlers: Dict[str, Callable] = {}
    
    def on(self, event: str):
        """Decorator for event handlers"""
        def decorator(func):
            self._handlers[event] = func
            return func
        return decorator
    
    async def emit(self, event: str, *args, **kwargs):
        """Emit an event"""
        if event in self._handlers:
            await self._handlers[event](*args, **kwargs)