"""
Headers and update functions for TAYBot
"""

import requests
import os
import psutil
import sys
import jwt
import pickle
import json
import binascii
import time
import urllib3
import base64
import datetime
import re
import socket
import threading
import random
from typing import Tuple, Optional
from threading import Thread
from google_play_scraper import app

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Token management
def ToK() -> None:
    """Background thread to fetch tokens periodically"""
    while True:
        try:
            r = requests.get('https://tokens-asfufvfshnfkhvbb.francecentral-01.azurewebsites.net/ReQuesT?&type=ToKens')
            t = r.text
            i = t.find("ToKens : [")
            if i != -1:
                j = t.find("]", i)
                L = [x.strip(" '\"") for x in t[i+11:j].split(',') if x.strip()]
                if L:
                    with open("token.txt", "w") as f:
                        f.write(random.choice(L))
        except:
            pass
        time.sleep(5 * 60 * 60)

# Start token fetcher thread
Thread(target=ToK, daemon=True).start()

def GeTToK() -> str:
    """Get token from file"""
    try:
        with open("token.txt") as f:
            return f.read().strip()
    except:
        return ""

def GeT_OB() -> Optional[str]:
    """Get OB version from server"""
    try:
        url = "https://version.freefire.info/mscrtfree/live/ver.php?version=2.114.18&lang=en&device=android&channel=android_max&appstore=googleplay_max&region=DEFAULT&whitelist_version=1.3.0&whitelist_sp_version=1.0.0&device_name=samsung%20SM-A165F&device_CPU=ARM64%20FP%20ASIMD%20AES&device_GPU=Mali-G57%20MC2&device_mem=3621"
        response = requests.get(url)
        ob = response.json()["latest_release_version"]
        return ob
    except:
        return None

def obv() -> Optional[str]:
    """Get OB version with retry"""
    ob = GeT_OB()
    if ob is None:
        print('Error Fetching OB Version!')
        return "OB51"
    else:
        print(f"OB VERSION = > {ob}")
        return ob

def lag(JWT: str) -> None:
    """Lag function"""
    url = "https://clientbp.ggblueshark.com/RequestJoinClan"
    headers = {
        "Accept-Encoding": "gzip",
        "Authorization": f"Bearer {JWT}",
        "Connection": "Keep-Alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "Host": "clientbp.ggblueshark.com",
        "ReleaseVersion": "OB51",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)",
        "X-GA": "v1 1",
        "X-Unity-Version": "2018.4.11f1"
    }
    data = bytes.fromhex("BA1F7AE7D09DAC6DA350417294B6E504")
    response = requests.post(url, headers=headers, data=data)
    print("Status:", response.status_code)

def AuToUpDaTE() -> Tuple[str, str, str]:
    """Auto update function to get latest version info"""
    try:
        result = app('com.dts.freefireth', lang="en", country='us')
        version = result['version']
        
        r = requests.get(f'https://bdversion.ggbluefox.com/live/ver.php?version={version}&lang=en&device=android&channel=android&appstore=googleplay&region=ME&whitelist_version=1.3.0&whitelist_sp_version=1.0.0&device_name=google%20G011A&device_CPU=ARMv7%20VFPv3%20NEON%20VMH&device_GPU=Adreno%20(TM)%20640&device_mem=1993').json()
        
        url = r['server_url']
        ob = r['latest_release_version']
        return url, ob, version
    except:
        return "https://login.freefire.com/", "OB51", "2.114.1"

def equipe_emote(JWT: str) -> None:
    """Equip emote"""
    url = "https://clientbp.ggblueshark.com/ChooseEmote"
    headers = {
        "Accept-Encoding": "gzip",
        "Authorization": f"Bearer {JWT}",
        "Connection": "Keep-Alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "Expect": "100-continue",
        "Host": "clientbp.ggblueshark.com",
        "ReleaseVersion": "OB51",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)",
        "X-GA": "v1 1",
        "X-Unity-Version": "2018.4.11f1",
    }
    data = bytes.fromhex("CAF683222A25C7BEFEB51F59544DB313")
    requests.post(url, headers=headers, data=data)

# Export all functions
__all__ = [
    'ToK', 'GeTToK', 'GeT_OB', 'obv', 'lag',
    'AuToUpDaTE', 'equipe_emote'
]