"""
Main client module for TAYBot
"""

import asyncio
import aiohttp
import ssl
import json
import random
from datetime import datetime
from typing import Optional, Callable, Any, Dict, List
from dataclasses import dataclass
import urllib3

from taycommunity.auth import AuthManager
from taycommunity.core import (
    xAuThSTarTuP, DeCode_PackEt, xSEndMsg, xSEndMsgsQ,
    SendRoomInfo, RedZedRefuse, RedZed_SendInv,
    RedZedAccepted, Emote_k, ExiT, get_player_status,
    get_room_info, AuthClan, SPam_Room, SendInFoPaCKeT,
    GenJoinSquadsPacket, SwitchLoneWolf, SwitchLoneWolfDule,
    InvitePlayer, StartGame, LeaveTeam, FS, OpEnSq,
    cHSq, SEnd_InV, Emote_auto, DecodeWhisperMessage,
    GeT_Status, PlayerStatus
)
from taycommunity.headers import AuToUpDaTE, equipe_emote
from taycommunity.utils import get_random_color, xMsGFixinG
from taycommunity.constants import Hr
from taycommunity.exceptions import LoginError, ConnectionError
from taycommunity.protos import PorTs_pb2

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

@dataclass
class Message:
    """Represents a chat message"""
    user_id: int
    chat_id: int
    chat_type: int
    text: str
    nickname: str
    raw_data: dict

class TAYBot:
    """Main bot class for Free Fire automation"""
    
    def __init__(self):
        self.uid: Optional[int] = None
        self.nickname: Optional[str] = None
        self.region: Optional[str] = None
        self._token: Optional[str] = None
        self._jwt: Optional[str] = None
        self._key: Optional[bytes] = None
        self._iv: Optional[bytes] = None
        self._online_ip: Optional[str] = None
        self._online_port: Optional[int] = None
        self._chat_ip: Optional[str] = None
        self._chat_port: Optional[int] = None
        self._login_data: Optional[Any] = None
        self._login_url: Optional[str] = None
        self._ob: Optional[str] = None
        self._version: Optional[str] = None
        
        self._online_writer = None
        self._chat_writer = None
        self._chat_reader = None
        self._online_reader = None
        
        self._message_handlers: Dict[str, Callable] = {}
        self._event_handlers: Dict[str, Callable] = {}
        self._is_connected = False
        self._last_status = {}
        self._last_room_info = {}
        
        self._auth_manager = AuthManager()
        
        # Auto update
        self._login_url, self._ob, self._version = AuToUpDaTE()
        
    @property
    def is_connected(self) -> bool:
        """Check if bot is connected to servers"""
        return self._is_connected
    
    @property
    def account_uid(self) -> Optional[int]:
        """Get bot account UID"""
        return self.uid
    
    @property
    def token(self) -> Optional[str]:
        """Get bot authentication token"""
        return self._jwt
    
    @classmethod
    async def login(cls, uid: str, password: str) -> Optional['TAYBot']:
        """
        Login to Free Fire using guest account
        
        Args:
            uid: Account UID
            password: Account password
            
        Returns:
            TAYBot instance if login successful, None otherwise
        """
        bot = cls()
        print(f"🔐 Logging in with UID: {uid}")
        
        # Get access token
        open_id, access_token = await bot._auth_manager.get_access_token(uid, password)
        if not open_id or not access_token:
            raise LoginError("Invalid account credentials")
        
        print("✅ Got access token from Garena")
        
        # Major login
        login_data = await bot._auth_manager.major_login(open_id, access_token)
        if not login_data:
            raise LoginError("Account is banned or not registered")
        
        print("✅ Major login successful")
        
        # Parse login response
        bot._jwt = login_data['token']
        bot.uid = login_data['account_uid']
        bot._key = login_data['key']
        bot._iv = login_data['iv']
        bot._token = await xAuThSTarTuP(
            int(bot.uid), 
            login_data['token'], 
            int(login_data['timestamp']), 
            bot._key, 
            bot._iv
        )
        
        # Get login data
        get_login_data = await bot._auth_manager.get_login_data(
            login_data['url'], 
            login_data['payload'], 
            login_data['token']
        )
        if not get_login_data:
            raise LoginError("Failed to get login data")
        
        bot._login_data = get_login_data
        bot.region = get_login_data.Region
        bot.nickname = get_login_data.AccountName
        
        # Parse connection info
        online_ip_port = get_login_data.Online_IP_Port.split(":")
        bot._online_ip, bot._online_port = online_ip_port[0], int(online_ip_port[1])
        
        chat_ip_port = get_login_data.AccountIP_Port.split(":")
        bot._chat_ip, bot._chat_port = chat_ip_port[0], int(chat_ip_port[1])
        
        print(f"✅ Logged in as: {bot.nickname} (UID: {bot.uid})")
        print(f"🌍 Region: {bot.region}")
        
        return bot
    
    def message_handler(self, command: str = None):
        """
        Decorator for handling chat messages
        
        Args:
            command: Command to handle (without prefix)
        """
        def decorator(func):
            cmd = command or func.__name__
            self._message_handlers[cmd.lower()] = func
            return func
        return decorator
    
    def online(self):
        """Decorator for online ready event"""
        def decorator(func):
            self._event_handlers['online_ready'] = func
            return func
        return decorator
    
    async def send_dm(self, message: str, user_id: int, chat_type: int = 2) -> bool:
        """
        Send a direct message to a user
        
        Args:
            message: Message text
            user_id: Target user ID
            chat_type: Chat type (0=squad, 1=clan, 2=private)
            
        Returns:
            True if sent successfully
        """
        if not self._chat_writer:
            raise ConnectionError("Chat connection not established")
        
        packet = await xSEndMsg(message, chat_type, user_id, user_id, self._key, self._iv)
        self._chat_writer.write(packet)
        await self._chat_writer.drain()
        return True
    
    async def send_squad(self, message: str, squad_id: int) -> bool:
        """Send message to squad chat"""
        return await self.send_dm(message, squad_id, 0)
    
    async def send_clan(self, message: str, clan_id: int) -> bool:
        """Send message to clan chat"""
        return await self.send_dm(message, clan_id, 1)
    
    async def send_colored_message(self, message: str, user_id: int, color: str = None) -> bool:
        """
        Send colored message to user
        
        Args:
            message: Message text
            user_id: Target user ID
            color: Color code (e.g., "FF0000" for red)
        """
        if not color:
            color = await get_random_color()
        colored_msg = f"[B][C][{color}]{message}"
        return await self.send_dm(colored_msg, user_id)
    
    async def add_friend(self, target_uid: int) -> str:
        """
        Send friend request
        
        Args:
            target_uid: Target user ID
            
        Returns:
            Status message
        """
        # Implementation for adding friend
        return "Friend request sent"
    
    async def invite_to_squad(self, target_uid: int, count: int = 1) -> bool:
        """
        Invite user to squad multiple times
        
        Args:
            target_uid: Target user ID
            count: Number of invites to send
            
        Returns:
            True if successful
        """
        if not self._online_writer:
            raise ConnectionError("Online connection not established")
        
        for i in range(count):
            packet = await RedZed_SendInv(str(target_uid), self._key, self._iv)
            self._online_writer.write(packet)
            await self._online_writer.drain()
            await asyncio.sleep(0.01)
        
        return True
    
    async def join_squad(self, squad_code: str) -> bool:
        """
        Join a squad by code
        
        Args:
            squad_code: Squad code
            
        Returns:
            True if successful
        """
        if not self._online_writer:
            raise ConnectionError("Online connection not established")
        
        packet = await GenJoinSquadsPacket(squad_code, self._key, self._iv)
        self._online_writer.write(packet)
        await self._online_writer.drain()
        return True
    
    async def leave_squad(self) -> bool:
        """Leave current squad"""
        if not self._online_writer:
            raise ConnectionError("Online connection not established")
        
        packet = await ExiT(None, self._key, self._iv)
        self._online_writer.write(packet)
        await self._online_writer.drain()
        return True
    
    async def send_emote(self, target_uid: int, emote_id: int) -> bool:
        """
        Send emote to target
        
        Args:
            target_uid: Target user ID
            emote_id: Emote ID
            
        Returns:
            True if successful
        """
        if not self._online_writer:
            raise ConnectionError("Online connection not established")
        
        packet = await Emote_k(target_uid, emote_id, self._key, self._iv)
        self._online_writer.write(packet)
        await self._online_writer.drain()
        return True
    
    async def get_user_status(self, target_uid: int) -> dict:
        """
        Get user status
        
        Args:
            target_uid: Target user ID
            
        Returns:
            User status dictionary
        """
        if not self._online_writer:
            raise ConnectionError("Online connection not established")
        
        packet = await GeT_Status(target_uid, self._key, self._iv)
        self._online_writer.write(packet)
        await self._online_writer.drain()
        
        # Wait for response
        await asyncio.sleep(2)
        
        return self._last_status
    
    async def _handle_chat_message(self, data: bytes):
        """Handle incoming chat messages"""
        try:
            if data.hex().startswith("120000"):
                msg_data = await DeCode_PackEt(data.hex()[10:])
                chat_data = await DecodeWhisperMessage(data.hex()[10:])
                
                # Parse message
                user_id = chat_data.Data.uid
                chat_id = chat_data.Data.Chat_ID
                chat_type = chat_data.Data.chat_type
                text = chat_data.Data.msg.lower()
                
                # Get nickname
                try:
                    raw_data = json.loads(msg_data)
                    nickname = (
                        raw_data.get('5', {})
                        .get('data', {})
                        .get('9', {})
                        .get('data', {})
                        .get('1', {})
                        .get('data', 'Unknown')
                    )
                except:
                    nickname = "Unknown"
                
                msg = Message(
                    user_id=user_id,
                    chat_id=chat_id,
                    chat_type=chat_type,
                    text=text,
                    nickname=nickname,
                    raw_data=raw_data if 'raw_data' in locals() else {}
                )
                
                # Check for command handlers
                if text.startswith('/'):
                    command = text[1:].split()[0] if ' ' in text else text[1:]
                    if command in self._message_handlers:
                        await self._message_handlers[command](msg)
                        
        except Exception as e:
            print(f"Error handling message: {e}")
    
    async def _chat_loop(self):
        """Main chat connection loop"""
        while True:
            try:
                reader, writer = await asyncio.open_connection(
                    self._chat_ip, self._chat_port
                )
                self._chat_writer = writer
                self._chat_reader = reader
                
                # Send auth token
                writer.write(bytes.fromhex(self._token))
                await writer.drain()
                
                # Join clan if applicable
                if self._login_data and hasattr(self._login_data, 'Clan_ID'):
                    if self._login_data.Clan_ID:
                        clan_packet = await AuthClan(
                            self._login_data.Clan_ID,
                            self._login_data.Clan_Compiled_Data,
                            self._key,
                            self._iv
                        )
                        writer.write(clan_packet)
                        await writer.drain()
                
                while True:
                    data = await reader.read(9999)
                    if not data:
                        break
                    
                    await self._handle_chat_message(data)
                    
            except Exception as e:
                print(f"Chat connection error: {e}")
                await asyncio.sleep(5)
            finally:
                if self._chat_writer:
                    self._chat_writer.close()
                    await self._chat_writer.wait_closed()
                    self._chat_writer = None
    
    async def _online_loop(self):
        """Main online connection loop"""
        while True:
            try:
                reader, writer = await asyncio.open_connection(
                    self._online_ip, self._online_port
                )
                self._online_writer = writer
                self._online_reader = reader
                
                # Send auth token
                writer.write(bytes.fromhex(self._token))
                await writer.drain()
                
                self._is_connected = True
                
                # Trigger online ready event
                if 'online_ready' in self._event_handlers:
                    await self._event_handlers['online_ready'](self)
                
                while True:
                    data = await reader.read(9999)
                    if not data:
                        break
                    
                    hex_data = data.hex()
                    
                    # Handle status packets
                    if hex_data.startswith("0f00"):
                        info = await DeCode_PackEt(hex_data[10:])
                        self._last_status = get_player_status(info)
                        
                    # Handle room info packets
                    elif hex_data.startswith("0e00"):
                        info = await DeCode_PackEt(hex_data[10:])
                        self._last_room_info = get_room_info(info)
                        
            except Exception as e:
                print(f"Online connection error: {e}")
                self._is_connected = False
                await asyncio.sleep(5)
            finally:
                if self._online_writer:
                    self._online_writer.close()
                    await self._online_writer.wait_closed()
                    self._online_writer = None
    
    async def online_loop(self):
        """Start both connection loops"""
        print("🚀 Starting bot connections...")
        await asyncio.gather(
            self._chat_loop(),
            self._online_loop()
        )