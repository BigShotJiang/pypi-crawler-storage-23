"""
Utility functions for TAYBot
"""

import random
import json
from typing import Any

async def get_random_color() -> str:
    """Get random color code for messages"""
    colors = [
        "FF0000", "00FF00", "0000FF", "FFFF00", "FF00FF", "00FFFF",
        "FFFFFF", "FFA500", "A52A2A", "800080", "000000", "808080",
        "C0C0C0", "FFC0CB", "FFD700", "ADD8E6", "90EE90", "D2691E",
        "DC143C", "00CED1", "9400D3", "F08080", "20B2AA", "FF1493",
        "7CFC00", "B22222", "FF4500", "DAA520", "00BFFF", "00FF7F",
        "4682B4", "6495ED", "5F9EA0", "DDA0DD", "E6E6FA", "B0C4DE"
    ]
    return random.choice(colors)

def xMsGFixinG(n: Any) -> str:
    """Fix message with emoji separators"""
    return '🗿'.join(str(n)[i:i + 3] for i in range(0, len(str(n)), 3))

async def ArA_CoLor() -> str:
    """Get random color"""
    colors = ["32CD32", "00BFFF", "00FA9A", "90EE90", "FF4500", "FF6347", 
              "FF69B4", "FF8C00", "FFD700", "FFDAB9", "F0F0F0", "F0E68C",
              "D3D3D3", "A9A9A9", "D2691E", "CD853F", "BC8F8F", "6A5ACD",
              "483D8B", "4682B4", "9370DB", "C71585", "FF8C00", "FFA07A"]
    return random.choice(colors)

async def xBunnEr() -> int:
    """Get random banner ID"""
    banners = [902000306, 902000305, 902000003, 902000016, 902000017, 
               902000019, 902031010, 902043025, 902043024, 902000020,
               902000021, 902000023, 902000070, 902000087, 902000108,
               902000011, 902049020, 902049018, 902049017, 902049016,
               902049015, 902049003, 902033016, 902033017, 902033018,
               902048018, 902000306, 902000305, 902000079]
    return random.choice(banners)

async def xPiN() -> str:
    """Get random PIN"""
    pins = ['827001005', '827001004', '827001003', '827001006']
    return random.choice(pins)

def get_random_title() -> int:
    """Get random title ID"""
    titles = list(set([
        904090023, 904090026, 904090027, 904290048, 904590058,
        904590059, 904790062, 904890068, 904990069, 904990070,
        904990071, 904990072, 905090075, 905190079
    ]))
    return random.choice(titles)

async def Ua() -> str:
    """Generate random user agent"""
    versions = [
        '4.0.18P6', '4.0.19P7', '4.0.20P1', '4.1.0P3', '4.1.5P2', '4.2.1P8',
        '4.2.3P1', '5.0.1B2', '5.0.2P4', '5.1.0P1', '5.2.0B1', '5.2.5P3',
        '5.3.0B1', '5.3.2P2', '5.4.0P1', '5.4.3B2', '5.5.0P1', '5.5.2P3'
    ]
    models = [
        'SM-A125F', 'SM-A225F', 'SM-A325M', 'SM-A515F', 'SM-A725F', 
        'SM-M215F', 'SM-M325FV', 'Redmi 9A', 'Redmi 9C', 'POCO M3',
        'POCO M4 Pro', 'RMX2185', 'RMX3085', 'moto g(9) play', 'CPH2239',
        'V2027', 'OnePlus Nord', 'ASUS_Z01QD',
    ]
    android_versions = ['9', '10', '11', '12', '13', '14']
    languages = ['en-US', 'es-MX', 'pt-BR', 'id-ID', 'ru-RU', 'hi-IN']
    countries = ['USA', 'MEX', 'BRA', 'IDN', 'RUS', 'IND']
    
    version = random.choice(versions)
    model = random.choice(models)
    android = random.choice(android_versions)
    lang = random.choice(languages)
    country = random.choice(countries)
    
    return f"GarenaMSDK/{version}({model};Android {android};{lang};{country};)"

def Uaa():
    """Generate random user agent (sync version)"""
    versions = [
        '4.0.18P6', '4.0.19P7', '4.0.20P1', '4.1.0P3', '4.1.5P2', '4.2.1P8',
        '4.2.3P1', '5.0.1B2', '5.0.2P4', '5.1.0P1', '5.2.0B1', '5.2.5P3',
        '5.3.0B1', '5.3.2P2', '5.4.0P1', '5.4.3B2', '5.5.0P1', '5.5.2P3'
    ]
    models = [
        'SM-A125F', 'SM-A225F', 'SM-A325M', 'SM-A515F', 'SM-A725F', 
        'SM-M215F', 'SM-M325FV', 'Redmi 9A', 'Redmi 9C', 'POCO M3',
        'POCO M4 Pro', 'RMX2185', 'RMX3085', 'moto g(9) play', 'CPH2239',
        'V2027', 'OnePlus Nord', 'ASUS_Z01QD',
    ]
    android_versions = ['9', '10', '11', '12', '13', '14']
    languages = ['en-US', 'es-MX', 'pt-BR', 'id-ID', 'ru-RU', 'hi-IN']
    countries = ['USA', 'MEX', 'BRA', 'IDN', 'RUS', 'IND']
    
    version = random.choice(versions)
    model = random.choice(models)
    android = random.choice(android_versions)
    lang = random.choice(languages)
    country = random.choice(countries)
    
    return f"GarenaMSDK/{version}({model};Android {android};{lang};{country};)"