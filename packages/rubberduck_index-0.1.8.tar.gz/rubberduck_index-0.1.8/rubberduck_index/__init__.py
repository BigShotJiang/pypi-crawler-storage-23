"""RubberDuck Index — local project indexer for RubberDuck Semantic Intelligence.

Scans a local Python project, computes SHA-256 hashes, and syncs changed files
to the RubberDuck MCP server (EC2) via HTTP. The server builds CPG graphs
automatically so the LLM can query them instantly.

Usage:
    rubberduck-index init --server http://host:8182 --project my-app
    rubberduck-index sync
    rubberduck-index watch
    rubberduck-index status
    rubberduck-index list
"""

__version__ = "0.1.8"
