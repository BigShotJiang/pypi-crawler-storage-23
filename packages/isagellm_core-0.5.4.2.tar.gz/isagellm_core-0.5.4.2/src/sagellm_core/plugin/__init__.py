"""sageLLM Core Plugin System.

Implements the Adapter/Provider Pattern for pluggable Backend, Engine,
Scheduler, and Accelerator components. Plugins are discovered via
setuptools entry_points, enabling zero-code registration from
external packages.

Entry-point Groups:
    sagellm.backends    - BackendPlugin implementations
    sagellm.engines     - EnginePlugin (BaseEngine subclasses)
    sagellm.schedulers  - SchedulerPlugin implementations
    sagellm.accelerators - AcceleratorPlugin implementations

Quick Start:
    # In your package's pyproject.toml:
    [project.entry-points."sagellm.backends"]
    my_backend = "my_pkg.backend:MyBackendPlugin"

    # Then auto-discover at runtime:
    from sagellm_core.plugin import PluginRegistry
    registry = PluginRegistry.discover()
    backend = registry.create_backend("my_backend")

Plugin Chain (end-to-end):
    from sagellm_core.plugin import PluginChain
    chain = PluginChain.build(backend_kind="cpu", scheduler_kind="fcfs")
    engine = chain.engine
"""

from __future__ import annotations

from sagellm_core.plugin.accelerator_plugin import AcceleratorPlugin, AcceleratorPluginMeta
from sagellm_core.plugin.backend_plugin import BackendPlugin, BackendPluginMeta
from sagellm_core.plugin.chain import PluginChain, PluginChainConfig
from sagellm_core.plugin.engine_plugin import EnginePlugin, EnginePluginMeta
from sagellm_core.plugin.registry import PluginRegistry, PluginRegistrySnapshot
from sagellm_core.plugin.scheduler_plugin import SchedulerPlugin, SchedulerPluginMeta

__all__ = [
    # Per-type plugin ABCs
    "BackendPlugin",
    "BackendPluginMeta",
    "EnginePlugin",
    "EnginePluginMeta",
    "SchedulerPlugin",
    "SchedulerPluginMeta",
    "AcceleratorPlugin",
    "AcceleratorPluginMeta",
    # Registry
    "PluginRegistry",
    "PluginRegistrySnapshot",
    # Chain
    "PluginChain",
    "PluginChainConfig",
]
