class Xursparks:
    def __init__(self) -> None:
        pass