from .main import GenericXursparksException, ApiServiceException


def test():
    return GenericXursparksException('test')