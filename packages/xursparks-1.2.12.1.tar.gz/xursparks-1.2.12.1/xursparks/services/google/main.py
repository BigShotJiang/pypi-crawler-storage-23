import sys
from google.oauth2 import service_account
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
import pandas as pd
import base64
import pickle
from typing import Optional, Dict, Any, Union
import json
import os
import io

class XGoogleDriveReader:
    """Class to handle Google Drive operations and read Google Sheets"""
    
    SCOPES = ['https://www.googleapis.com/auth/drive',
              'https://www.googleapis.com/auth/spreadsheets']
    
    def __init__(self, auth_file_path: str = 'auth/service-account-gdrive.json',
                 scopes: list = SCOPES):
        """
        Initialize GoogleDriveReader with service account credentials
        
        Args:
            auth_file_path: Path to service account JSON file (relative or absolute)
        """
        try:
            # Get absolute path if relative path provided
            if not os.path.isabs(auth_file_path):
                current_dir = os.path.dirname(os.path.abspath(__file__))
                auth_file_path = os.path.join(current_dir, auth_file_path)
            
            # Load credentials from JSON file
            with open(auth_file_path, 'r') as f:
                self.credentials = json.load(f)
                
            self.creds = None
            self.service = None
            self.sheets_service = None
            self.scopes = scopes
            
        except Exception as e:
            raise ValueError(f"Failed to load authentication file: {str(e)}")

    def authenticate(self) -> bool:
        """Authenticate with Google Drive API using service account"""
        try:

            self.creds = service_account.Credentials.from_service_account_info(
                self.credentials,
                scopes=self.scopes
            )
            
            self.service = build('drive', 'v3', credentials=self.creds)
            self.sheets_service = build('sheets', 'v4', credentials=self.creds)
            print("Successfully authenticated with service account")
            return True
            
        except Exception as e:
            print(f"Authentication failed: {str(e)}")
            return False
    
    def get_file_id(self, file_path: str, mime_type: str = None) -> Optional[str]:
        """
        Get Google Drive file ID by path
        
        Args:
            file_path: Full path to the file in Google Drive (e.g. 'folder1/folder2/filename')
            mime_type: Optional MIME type filter
            
        Returns:
            str: File ID if found, None otherwise
        """
        try:
            path_parts = file_path.strip('/').split('/')
            file_name = path_parts[-1]
            parent_path = '/'.join(path_parts[:-1])
            
            # Build query
            query = f"name='{file_name}'"
            if mime_type:
                query += f" and mimeType='{mime_type}'"
            
            # Add parent folder constraints if path provided
            if parent_path:
                parent_id = self._get_folder_id(parent_path)
                if parent_id:
                    query += f" and '{parent_id}' in parents"
                    
            results = self.service.files().list(
                q=query,
                fields="files(id, name)").execute()
            items = results.get('files', [])
            
            if not items:
                print(f"File '{file_path}' not found")
                return None
                
            return items[0]['id']
            
        except Exception as e:
            print(f"Error getting file ID: {str(e)}")
            return None

    def _get_folder_id(self, folder_path: str) -> Optional[str]:
        """
        Get folder ID from path
        
        Args:
            folder_path: Path to folder (e.g. 'folder1/folder2')
            
        Returns:
            str: Folder ID if found, None otherwise
        """
        try:
            current_parent = 'root'
            
            for folder in folder_path.split('/'):
                query = f"name='{folder}' and mimeType='application/vnd.google-apps.folder'"
                if current_parent != 'root':
                    query += f" and '{current_parent}' in parents"
                    
                results = self.service.files().list(
                    q=query,
                    fields="files(id)").execute()
                items = results.get('files', [])
                
                if not items:
                    print(f"Folder '{folder}' not found in path '{folder_path}'")
                    return None
                    
                current_parent = items[0]['id']
                
            return current_parent
            
        except Exception as e:
            print(f"Error getting folder ID: {str(e)}")
            return None

    def _col_str_to_index(self, col_str: str) -> int:
        """Convert column letter to 0-based index"""
        num = 0
        for c in col_str:
            if 'A' <= c.upper() <= 'Z':
                num = num * 26 + (ord(c.upper()) - ord('A') + 1)
        return num - 1

    def _parse_range_string(self, range_str: str) -> tuple:
        """Parse range string to (start_row, start_col)"""
        try:
            if '!' in range_str:
                range_str = range_str.split('!')[-1]
            
            start_cell = range_str.split(':')[0]
            
            col_str = ""
            row_str = ""
            for char in start_cell:
                if char.isalpha():
                    col_str += char
                elif char.isdigit():
                    row_str += char
            
            start_col = self._col_str_to_index(col_str)
            start_row = int(row_str) - 1 if row_str else 0
            
            return start_row, start_col
        except:
            return 0, 0

    def read_sheet(self, 
                   file_path: str, 
                   sheet_name: Optional[str] = None,
                   range_name: Optional[str] = None,
                   header_row: int = 0,
                   fill_empty_cells: bool = True) -> Optional[pd.DataFrame]:
        """
        Read Google Sheet into pandas DataFrame with improved merged cell handling
        
        Args:
            file_path: Full path to the file in Google Drive (e.g. 'folder1/folder2/filename')
            sheet_name: Optional sheet name (default: first sheet)
            range_name: Optional range to read (default: all)
            header_row: Row index to use as header (default: 0, first row)
            fill_empty_cells: Whether to fill empty cells with forward fill method (default: True)
            
        Returns:
            pd.DataFrame: DataFrame containing sheet data
        """
        try:
            # Get file ID
            file_id = self.get_file_id(file_path)
            if not file_id:
                return None
            
            # Get sheet properties
            sheet_metadata = self.sheets_service.spreadsheets().get(
                spreadsheetId=file_id).execute()
            
            target_sheet = None
            if not sheet_name:
                target_sheet = sheet_metadata['sheets'][0]
                sheet_name = target_sheet['properties']['title']
            else:
                for s in sheet_metadata['sheets']:
                    if s['properties']['title'] == sheet_name:
                        target_sheet = s
                        break
            
            # Construct range
            range_str = f"'{sheet_name}'"
            if range_name:
                range_str += f"!{range_name}"
            
            # Read data
            result = self.sheets_service.spreadsheets().values().get(
                spreadsheetId=file_id,
                range=range_str).execute()
            
            values = result.get('values', [])
            if not values:
                print("No data found in sheet")
                return None
            else:
                print(f"Data retrieved: {len(values)} rows")
                print(f"First 5 rows: {values[:5]}")
            
            # If range_name is specified and doesn't start at row 1, read headers separately
            header_values = None
            if range_name and not range_name.lower().startswith('a1'):
                try:
                    # Parse the range to check starting row
                    start_row, start_col = self._parse_range_string(range_name)
                    if start_row > 0:  # If not starting from row 1, fetch headers
                        # Build header range (from row 1 to the start of data range, same columns)
                        col_end = range_name.split(':')[-1] if ':' in range_name else range_name
                        # Extract end column from range
                        col_letters = ''.join(c for c in col_end if c.isalpha())
                        header_range_str = f"'{sheet_name}'!A1:{col_letters}{start_row}"
                        
                        header_result = self.sheets_service.spreadsheets().values().get(
                            spreadsheetId=file_id,
                            range=header_range_str).execute()
                        header_values = header_result.get('values', [])
                        print(f"Header rows retrieved: {len(header_values) if header_values else 0} rows")
                except:
                    pass
            
            # Skip completely empty rows at the start
            first_non_empty_idx = 0
            for idx, row in enumerate(values):
                if any(str(cell).strip() for cell in row):
                    first_non_empty_idx = idx
                    break
            
            values = values[first_non_empty_idx:]
            if not values:
                print("No data found in sheet")
                return None
            
            # First, normalize all rows to same length
            max_cols = max(len(row) for row in values) if values else 0
            if max_cols == 0:
                print("No data found in sheet")
                return None
            
            # Include header rows if they were read separately
            if header_values:
                # Normalize header rows
                for row in header_values:
                    while len(row) < max_cols:
                        row.append('')
                values = header_values + values
                print(f"Total rows after adding headers: {len(values)}")
                
            normalized_values = []
            for row in values:
                normalized_row = list(row) if row else []
                # Pad with empty strings to reach max_cols
                while len(normalized_row) < max_cols:
                    normalized_row.append('')
                normalized_values.append(normalized_row)
            
            # Handle Merged Cells - fill merged cell ranges with the first cell value
            if target_sheet:
                merges = target_sheet.get('merges', [])
                if merges:
                    # Parse range offset
                    actual_range = result.get('range', '')
                    start_row_offset, start_col_offset = self._parse_range_string(actual_range)
                    
                    # Adjust offset by removed empty rows
                    start_row_offset = max(0, start_row_offset - first_non_empty_idx)
                    
                    for merge in merges:
                        start_row = merge.get('startRowIndex', 0)
                        end_row = merge.get('endRowIndex', start_row + 1)
                        start_col = merge.get('startColumnIndex', 0)
                        end_col = merge.get('endColumnIndex', start_col + 1)
                        
                        # Adjust to relative coordinates
                        rel_start_row = start_row - start_row_offset - first_non_empty_idx
                        rel_end_row = end_row - start_row_offset - first_non_empty_idx
                        rel_start_col = start_col - start_col_offset
                        rel_end_col = end_col - start_col_offset
                        
                        # Check bounds and fill
                        if (0 <= rel_start_row < len(normalized_values) and 
                            0 <= rel_start_col < max_cols):
                            fill_value = normalized_values[rel_start_row][rel_start_col]
                            
                            r_start = max(0, rel_start_row)
                            r_end = min(len(normalized_values), rel_end_row)
                            c_start = max(0, rel_start_col)
                            c_end = min(max_cols, rel_end_col)
                            
                            for r in range(r_start, r_end):
                                for c in range(c_start, c_end):
                                    if not normalized_values[r][c]:
                                        normalized_values[r][c] = fill_value
            
            # Auto-detect header row if all values in first row are empty
            detected_header_row = header_row
            if detected_header_row == 0 and not any(str(cell).strip() for cell in normalized_values[0]):
                # First row is empty, try to find next non-empty row as header
                for idx in range(1, min(5, len(normalized_values))):
                    if any(str(cell).strip() for cell in normalized_values[idx]):
                        detected_header_row = idx
                        break
            
            # If headers were read separately, use the last header row
            if header_values:
                detected_header_row = len(header_values) - 1
            
            if detected_header_row >= len(normalized_values):
                detected_header_row = 0
            
            header = normalized_values[detected_header_row]
            data = normalized_values[detected_header_row + 1:]
            
            # Generate column names, preserving existing header values
            column_names = []
            unnamed_idx = 0
            for i, col in enumerate(header):
                col_str = str(col).strip() if col else ''
                if col_str:
                    # Lowercase and replace spaces with underscores for consistency
                    column_names.append(col_str.lower().replace(' ', '_'))
                else:
                    column_names.append(f"col_{i}")
                    unnamed_idx += 1
            
            # Ensure all column names are unique
            seen_names = {}
            for i, name in enumerate(column_names):
                if name in seen_names:
                    seen_names[name] += 1
                    column_names[i] = f"{name}_{seen_names[name]}"
                else:
                    seen_names[name] = 0
            
            # Filter out completely empty rows from data
            filtered_data = []
            for row in data:
                if any(str(cell).strip() for cell in row):
                    filtered_data.append(row)
            
            if not filtered_data:
                print("No data rows found in sheet")
                return None
            
            # Create DataFrame with normalized data
            df = pd.DataFrame(filtered_data, columns=column_names)
            
            # Fill empty strings with NaN for better data handling
            df = df.replace('', pd.NA)
            
            # Apply forward fill on empty cells if requested
            if fill_empty_cells:
                df = df.ffill(axis=0)
            
            print(f"Successfully read {len(df)} rows with {len(df.columns)} columns")
            return df
            
        except Exception as e:
            print(f"Error reading sheet: {str(e)}")
            return None

    def download_file(self, 
                     file_path: str, 
                     local_path: str,
                     mime_type: str = None) -> bool:
        """
        Download file from Google Drive
        
        Args:
            file_path: Full path to file in Google Drive (e.g. 'folder1/folder2/filename')
            local_path: Local path where to save the file
            mime_type: Optional MIME type for export (for Google Docs, Sheets etc.)
            
        Returns:
            bool: True if download successful, False otherwise
        """
        try:
            # Get file ID using the new method
            file_id = self.get_file_id(file_path)
            if not file_id:
                print(f"File not found: {file_path}")
                return False

            # Create local directory if it doesn't exist
            os.makedirs(os.path.dirname(local_path), exist_ok=True)

            # Download the file
            if mime_type:
                # Export Google Workspace files
                request = self.service.files().export_media(
                    fileId=file_id,
                    mimeType=mime_type
                )
            else:
                # Download regular files
                request = self.service.files().get_media(
                    fileId=file_id
                )

            # Stream the file content
            fh = io.BytesIO()
            downloader = MediaIoBaseDownload(fh, request)
            done = False

            while not done:
                status, done = downloader.next_chunk()
                if status:
                    print(f"Download progress: {int(status.progress() * 100)}%")

            # Save the file
            fh.seek(0)
            with open(local_path, 'wb') as f:
                f.write(fh.read())
                f.flush()

            print(f"File downloaded successfully to: {local_path}")
            return True

        except Exception as e:
            print(f"Error downloading file: {str(e)}")
            return False

    def list_files(self, folder_path: str = '') -> Optional[list]:
        """
        List all files and subfolders in the specified Google Drive folder
        
        Args:
            folder_path: Path to folder in Google Drive (e.g. 'folder1/folder2')
                        Empty string '' means root folder
            
        Returns:
            list: List of dictionaries containing file/folder information with structure:
                  [{'name': str, 'id': str, 'type': str, 'path': str}, ...]
            None: If error occurs
        """
        try:
            # Get folder ID for the path
            folder_id = 'root' if not folder_path else self._get_folder_id(folder_path)
            if folder_path and not folder_id:
                return None

            # Build query to list all files/folders in the directory
            query = f"'{folder_id}' in parents and trashed=false"
            
            # Get list of all files/folders
            results = []
            page_token = None
            
            while True:
                response = self.service.files().list(
                    q=query,
                    spaces='drive',
                    fields='nextPageToken, files(id, name, mimeType)',
                    pageToken=page_token
                ).execute()
                
                for file in response.get('files', []):
                    file_type = 'folder' if file['mimeType'] == 'application/vnd.google-apps.folder' else 'file'
                    file_path = os.path.join(folder_path, file['name']) if folder_path else file['name']
                    
                    results.append({
                        'name': file['name'],
                        'id': file['id'],
                        'type': file_type,
                        'path': file_path
                    })
                    
                    # Recursively list files in subfolders
                    if file_type == 'folder':
                        sub_files = self.list_files(file_path)
                        if sub_files:
                            results.extend(sub_files)
                
                page_token = response.get('nextPageToken')
                if not page_token:
                    break
            
            return results
            
        except Exception as e:
            print(f"Error listing files: {str(e)}")
            return None

    def rename_file(self, file_path: str, new_name: str) -> bool:
        """
        Rename a file in Google Drive
    
        Args:
            file_path: Full path to file in Google Drive (e.g. 'folder1/folder2/filename')
            new_name: New name for the file (without path)
        
        Returns:
            bool: True if rename successful, False otherwise
        """
        try:
            # Get file ID
            file_id = self.get_file_id(file_path)
            if not file_id:
                print(f"File not found: {file_path}")
                return False

            # Create file metadata with new name
            file_metadata = {'name': new_name}

            # Update file metadata
            file = self.service.files().update(
                fileId=file_id,
                body=file_metadata,
                fields='id, name'
            ).execute()

            print(f"File renamed successfully to: {file.get('name')}")
            return True

        except Exception as e:
            print(f"Error renaming file: {str(e)}")
            return False

    def export_sheet_to_excel(self, 
                          file_path: str, 
                          local_path: str,
                          sheet_name: Optional[str] = None,
                          range_name: Optional[str] = None,
                          mime_type: str = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') -> bool:
        """
        Export Google Sheet to Excel file and download to local path
    
        Args:
            file_path: Full path to the Google Sheet in Google Drive (e.g. 'folder1/folder2/filename')
            local_path: Local path where to save the Excel file (e.g. './output/myfile.xlsx')
            sheet_name: Optional sheet name to export (if not specified, exports all sheets)
        
        Returns:
            bool: True if export and download successful, False otherwise
        """
        try:
            # Create local directory if it doesn't exist
            local_dir = os.path.dirname(local_path)
            if local_dir and not os.path.exists(local_dir):
                os.makedirs(local_dir, exist_ok=True)

            if sheet_name:
                df = self.read_sheet(file_path, sheet_name=sheet_name, range_name=range_name)
                if df is not None:
                    df.to_excel(local_path, index=False)
                    print(f"Successfully exported sheet '{sheet_name}' to: {local_path}")
                    return True
                return False

            # Get the file ID from the path
            file_id = self.get_file_id(file_path)
        
            if not file_id:
                print(f"File not found: {file_path}")
                return False
        
            # Export Google Sheet as Excel file
            request = self.service.files().export(
                fileId=file_id,
                mimeType=mime_type
            )
        
            # Download the file
            with open(local_path, 'wb') as fh:
                downloader = MediaIoBaseDownload(fh, request)
                done = False
                while done is False:
                    status, done = downloader.next_chunk()
                    if status:
                        print(f"Download progress: {int(status.progress() * 100)}%")
        
            print(f"Successfully exported and downloaded to: {local_path}")
            return True
        
        except Exception as e:
            print(f"Export failed: {str(e)}")
            return False

# Example usage
def read_sheet_from_gdrive():
    # Initialize reader with default auth file path
    reader = XGoogleDriveReader("./auth/hpmeis-7784af30c873.json")
    
    # Authenticate
    if reader.authenticate():
        df = reader.read_sheet(
            file_path="HPMEIS/sb/Monitored SWDAs by fo 7",
            sheet_name="FO Inventory",
            range_name="A2:AF76"
        )
        
        if df is not None:
            print(df.head())

def download_file_from_gdrive():
    reader = XGoogleDriveReader("./auth/hpmeis-7784af30c873.json")
    
    if reader.authenticate():
        # Download Google Sheet as Excel
        success = reader.download_file(
            file_path="HPMEIS/dswd_academy/sdca/1LGU TA PLAN Monitoring Sheet - Central Office",
            local_path="./my_sheet.xlsx"
        )
    print(f"Download success: {success}")

def list_files_from_gdrive():
    """Example usage of list_files function"""
    reader = XGoogleDriveReader("/home/hadoop/tests/hpmeis-7784af30c873.json")
    # reader = XGoogleDriveReader("./auth/hpmeis-7784af30c873.json")

    if reader.authenticate():
        # List all files in a specific folder
        files = reader.list_files("HPMEIS/sb")
        
        if files:
            print("\nFiles found:")
            for file in files:
                prefix = "📁" if file['type'] == 'folder' else "📄"
                print(f"{prefix} {file['path']}")
                
def rename_file_in_gdrive():
    """Example usage of rename_file function"""
    reader = XGoogleDriveReader("./auth/service-account-gdrive.json")
    
    if reader.authenticate():
        # Rename a Google Sheet
        success = reader.rename_file(
            file_path="DSWD-Sheets/AICS 1.xlsx",
            # file_path="DSWD-Sheets/Chill",
            # new_name="BHill"
            new_name="BICS 1.xlsx"
        )
        
        # Or rename any other file
        # success = reader.rename_file(
        #     file_path="Documents/old_doc.pdf",
        #     new_name="new_doc.pdf"
        # )
        
    print(f"Rename success: {success}")

def export_sheet_example():
    reader = XGoogleDriveReader("/home/hadoop/tests/hpmeis-7784af30c873.json")
    
    if reader.authenticate():
        # Export Google Sheet to Excel
        success = reader.export_sheet_to_excel(
            file_path="HPMEIS/sb/Monitored SWDAs by fo 7",
            local_path="/home/hadoop/poc/Monitored SWDAs by fo 7.xlsx",
            sheet_name='FO Inventory'
        )
        
        print(f"Export success: {success}")

if __name__ == "__main__":
    if sys.argv[1] == 'read':
        read_sheet_from_gdrive()
    elif sys.argv[1] == 'download':
        download_file_from_gdrive()
    elif sys.argv[1] == 'list':
        list_files_from_gdrive()
    elif sys.argv[1] == 'rename':
        rename_file_in_gdrive()
    elif sys.argv[1] == 'export':
        export_sheet_example()