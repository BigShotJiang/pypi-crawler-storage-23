from xursparks.xkynet.nlp.nlp import NLPAgent
from xursparks.xkynet.nlp.finance import FinanceAgent
from xursparks.xkynet.nlp.hr import HRAgent