"""HeyLead LinkedIn integration — via Unipile API or Backend proxy."""

from __future__ import annotations

from .unipile import (
    UnipileAuthError,
    UnipileClient,
    UnipileError,
    get_account_id,
    get_unipile_client,
)

__all__ = [
    "UnipileClient",
    "UnipileError",
    "UnipileAuthError",
    "get_unipile_client",
    "get_account_id",
    "get_linkedin_client",
]


def get_linkedin_client() -> UnipileClient:
    """Factory: return BackendClient if backend config exists, else UnipileClient.

    Both implement the same interface so all tools work without changes.
    """
    from .. import config

    if config.is_backend_mode():
        from .backend_client import BackendClient
        backend_url, jwt_token = config.get_backend_config()
        return BackendClient(backend_url, jwt_token)  # type: ignore[return-value]

    return get_unipile_client()
