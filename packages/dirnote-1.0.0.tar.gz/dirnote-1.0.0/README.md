# 📌 dirnote

**Your directories have something to say.**

Directory-specific notes that automatically appear when you `cd` into them.

## Quick Demo

```bash
$ dirnote add "TODO: Refactor auth module"
Note added to ./.dirnote

$ dirnote show
--- Notes for /home/user/project ---
1: [2024-01-15 09:30] TODO: Refactor auth module
----------------------------------------

$ cd my-project  # Notes appear automatically!
--- Notes for /home/user/my-project ---
1: [2024-01-15 10:00] Remember to update API keys
----------------------------------------
```

## Install

```bash
pip install dirnote
python -m dirnote init
# Restart your terminal
```

## Usage

```bash
dirnote add "TODO: Refactor auth"   # Add note
dirnote show                         # View notes
dirnote rm 1                         # Remove note #1
dirnote clear                        # Remove all
```

**Notes appear automatically:**

```bash
$ cd my-project
--- Notes for /home/user/my-project ---
1: [2024-01-15 09:30] TODO: Refactor auth
----------------------------------------
```

## Features

- ✅ Zero dependencies
- ✅ Cross-platform (Windows, macOS, Linux)
- ✅ Works with bash, zsh, fish, PowerShell
- ✅ Auto-display on cd

## Why?

Because everyone forgets what they were working on.

## License

MIT
