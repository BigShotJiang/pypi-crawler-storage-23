#!/usr/bin/env python3
"""dirnote - Directory notes that appear when you cd. Zero deps."""

import os
import sys
from datetime import datetime
from pathlib import Path

NOTE_FILE = os.environ.get("DIRNOTE_FILE", ".dirnote")

SHELL_HOOKS = {
    "bash": """# DIRNOTE_INIT
cd() { builtin cd "$@" && [ -f "${DIRNOTE_FILE:-.dirnote}" ] && cat "${DIRNOTE_FILE:-.dirnote}" 2>/dev/null; }
""",
    "zsh": """# DIRNOTE_INIT  
cd() { builtin cd "$@" && [ -f "${DIRNOTE_FILE:-.dirnote}" ] && cat "${DIRNOTE_FILE:-.dirnote}" 2>/dev/null; }
""",
    "powershell": """# DIRNOTE_INIT
function Set-LocationWithNotes { param([string]$Path); if ($Path) { Set-Location $Path }; $f=$env:DIRNOTE_FILE; if (!$f) { $f=".dirnote" }; if (Test-Path $f) { Get-Content $f } }
Set-Alias -Name cd -Value Set-LocationWithNotes -Option AllScope -Force
""",
}


def detect_shell():
    shell = os.environ.get("SHELL", "").lower()
    if "zsh" in shell:
        return "zsh"
    if "bash" in shell:
        return "bash"
    if os.environ.get("PSModulePath"):
        return "powershell"
    return "bash"


def get_config(shell):
    home = Path.home()
    if shell == "powershell":
        # Support both Windows PowerShell and PowerShell Core
        # Use $PROFILE variable if available, otherwise fallback
        profile_path = os.environ.get("PROFILE")
        if profile_path:
            return Path(profile_path)
        # Fallback: try Windows PowerShell (more common)
        return (
            home
            / "Documents"
            / "WindowsPowerShell"
            / "Microsoft.PowerShell_profile.ps1"
        )
    paths = {"bash": home / ".bashrc", "zsh": home / ".zshrc"}
    return paths.get(shell)


def cmd_add(msg):
    if not msg:
        print("Error: dirnote add <message>", file=sys.stderr)
        sys.exit(1)
    with open(NOTE_FILE, "a") as f:
        f.write(f"[{datetime.now():%Y-%m-%d %H:%M}] {msg}\n")
    print(f"Note added to ./{NOTE_FILE}")


def cmd_show():
    p = Path(NOTE_FILE)
    if p.exists():
        print(f"--- Notes for {Path.cwd()} ---")
        with open(p) as f:
            lines = f.readlines()
        for i, line in enumerate(lines, 1):
            print(f"{i}: {line}", end="")
        print("\n" + "-" * 40)
    else:
        print(f"No notes in {Path.cwd()}")


def cmd_rm(idx):
    p = Path(NOTE_FILE)
    if not p.exists():
        print("No notes")
        return
    try:
        i = int(idx) - 1
        with open(p) as f:
            lines = f.readlines()
        if 0 <= i < len(lines):
            removed = lines.pop(i)
            with open(p, "w") as f:
                f.writelines(lines)
            print(f"Removed: {removed.strip()}")
        else:
            print(f"Note #{idx} doesn't exist")
    except:
        print(f"Invalid number: {idx}")


def cmd_clear():
    p = Path(NOTE_FILE)
    if p.exists():
        p.unlink()
        print("Notes cleared")
    else:
        print("No notes")


def cmd_init():
    shell = detect_shell()
    cfg = get_config(shell)
    if not cfg:
        print("Unknown shell")
        return
    cfg.parent.mkdir(parents=True, exist_ok=True)
    if cfg.exists() and "DIRNOTE_INIT" in cfg.read_text():
        print("Already initialized")
        return
    with open(cfg, "a") as f:
        f.write(SHELL_HOOKS[shell])
    print(
        f"Initialized! Restart terminal or: {'. $PROFILE' if shell == 'powershell' else 'source ' + str(cfg)}"
    )


def cmd_help():
    print("""dirnote - Your directories have something to say

USAGE:
    dirnote add <msg>   Add note
    dirnote show        Show notes (default)
    dirnote rm <num>    Remove note #
    dirnote clear       Remove all
    dirnote init        Setup cd hook
    dirnote help        This help

INSTALL:
    pip install dirnote
    python -m dirnote init
    # Restart terminal
""")


def main():
    if len(sys.argv) < 2:
        cmd_show()
        return
    cmd, args = sys.argv[1].lower(), sys.argv[2:]
    cmds = {
        "add": lambda: cmd_add(" ".join(args)),
        "show": cmd_show,
        "rm": lambda: (
            cmd_rm(args[0])
            if args
            else print("Usage: dirnote rm <num>", file=sys.stderr) or sys.exit(1)
        ),
        "clear": cmd_clear,
        "init": cmd_init,
        "help": cmd_help,
        "--help": cmd_help,
        "-h": cmd_help,
    }
    if cmd in cmds:
        cmds[cmd]()
    else:
        print(f"Unknown: {cmd}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
