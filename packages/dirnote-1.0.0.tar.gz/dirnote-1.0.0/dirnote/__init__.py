"""dirnote - Directory notes that appear when you cd into them."""

__version__ = "1.0.0"
