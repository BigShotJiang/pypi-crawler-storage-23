#!/usr/bin/env python3
"""Run: python -m dirnote"""

from dirnote.cli import main

main()
