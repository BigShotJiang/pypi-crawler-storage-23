from fastapi import FastAPI
import uvicorn

class RokaApp:
    def __init__(self):
        self.app = FastAPI()

    def route(self, path: str, methods=["GET"]):
        def wrapper(func):
            self.app.add_api_route(path, func, methods=methods)
            return func
        return wrapper

    def run(self, port=8000):
        print(f"ROKA launching on port {port}...")
        uvicorn.run(self.app, host="0.0.0.0", port=port)

# Usage: app = RokaApp() -> @app.route("/") -> app.run()