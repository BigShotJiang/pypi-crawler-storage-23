import httpx
from parsel import Selector

def quick_fetch(url, selector="body", attr=None):
    """Fetch data from any URL with one line."""
    resp = httpx.get(url, follow_redirects=True)
    sel = Selector(text=resp.text)
    
    if attr:
        return sel.css(selector).attrib.get(attr)
    return sel.css(selector).getall()