from .web import RokaApp
from .scrape import quick_fetch
from .synapse import QuickNet, auto_ml

__version__ = "0.1.0"