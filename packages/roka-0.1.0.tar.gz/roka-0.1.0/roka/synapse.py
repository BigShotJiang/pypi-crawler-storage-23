import torch
import torch.nn as nn
from sklearn.ensemble import RandomForestClassifier

# Device-agnostic setup for hackathon speed
device = "cuda" if torch.cuda.is_available() else "mps" if torch.backends.mps.is_available() else "cpu"

class QuickNet(nn.Module):
    def __init__(self, in_features, out_features, hidden=[64, 32]):
        super().__init__()
        layers = []
        last_dim = in_features
        for h in hidden:
            layers.append(nn.Linear(last_dim, h))
            layers.append(nn.ReLU())
            last_dim = h
        layers.append(nn.Linear(last_dim, out_features))
        self.model = nn.Sequential(*layers).to(device)

    def forward(self, x):
        return self.model(x)

def auto_ml(X, y):
    """Instantly fit a Random Forest and return the model."""
    clf = RandomForestClassifier(n_estimators=100)
    clf.fit(X, y)
    return clf