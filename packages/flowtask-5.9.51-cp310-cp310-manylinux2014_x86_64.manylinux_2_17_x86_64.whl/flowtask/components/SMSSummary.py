from typing import List
from collections.abc import Callable
import asyncio
import json
from pydantic import BaseModel, Field
from .CallSummary import CallSummary, SentimentItem, EmotionCount


class SMSAnalysisSummary(BaseModel):
    sentiment_distribution: List[SentimentItem] = Field(
        description="Percentage distribution of sentiments"
    )
    most_frequent_sentiment: str = Field(
        description="The most common sentiment across all SMS conversations"
    )
    top_emotions: List[EmotionCount] = Field(
        description="Top emotions with occurrence counts"
    )
    common_key_topics: list[str] = Field(
        description="Recurring topics across SMS conversations"
    )
    brief_notes_summary: str = Field(
        description="Synthesized summary of all brief notes"
    )
    consolidated_recommendations: list[str] = Field(
        description="4-6 prioritized actionable recommendations"
    )
    engagement_summary: str = Field(
        description="Summary of engagement levels across conversations"
    )
    intent_distribution: str = Field(
        description="Distribution of conversation intents"
    )
    outcome_distribution: str = Field(
        description="Distribution of conversation outcomes"
    )
    avg_response_time_minutes: float = Field(
        description="Average response time in minutes across conversations"
    )
    response_time_interpretation: str = Field(
        description="Explanation of what the response time metric indicates"
    )
    follow_up_rate: float = Field(
        description="Percentage of conversations that recommend follow-up (0.0 to 1.0)"
    )


class SMSSummary(CallSummary):
    """
    SMSSummary.

    Overview

        The SMSSummary class is a component for interacting with an IA Agent
        for making SMS Conversation Summarization per agent per day.
        It extends the CallSummary class and adapts it for SMS analysis data.

    .. code-block:: yaml

        SMSSummary:
          eval_column: extracted_analysis
          date_column: summary_date
          output_column: sms_summary
          summary_column: sms_summarization
          llm:
            llm: google
            model: gemini-2.5-pro
            temperature: 0.1
            max_tokens: 8192

    |---|---|---|
    | version | No | version of component |
    """
    _version = "1.0.0"

    def __init__(
        self,
        loop: asyncio.AbstractEventLoop = None,
        job: Callable = None,
        stat: Callable = None,
        **kwargs,
    ):
        super().__init__(
            loop=loop, job=job, stat=stat, **kwargs
        )
        self._goal: str = 'Your task is to provide a concise and insightful analysis of SMS Conversations'
        self.system_prompt_file: str = 'sms_summary.txt'
        prompt_path = self._taskstore.path.joinpath(self._program, 'prompts')
        self._prompt_file = prompt_path.joinpath(self.system_prompt_file)

    def format_question(self, extension, owner_name, summary_day, analysis):
        question = f"""
        Agent Extension: {extension}
        Agent Name: {owner_name}
        Date: {summary_day}

        SMS Conversation Analysis:
        """
        for a in analysis:
            rv = json.dumps(a, indent=2)
            question += f"* {rv}\n"
        return question

    async def bot_evaluation(self):
        """
        bot_evaluation

        Overview

            Iterates each row (agent+date), makes two LLM calls per row:
            1. Generate markdown report -> output_column
            2. Generate structured JSON via Pydantic -> summary_column

        Return

            A Pandas Dataframe with the IA-based statistics.
        """
        self.data[self.output_column] = None
        self.data[self.summary_column] = None
        for idx, row in self.data.iterrows():
            owner_name = row['owner_name']
            extension = row['extension']
            summary_day = row[self.date_column]
            analysis = row[self._eval_column]
            formatted_question = self.format_question(
                extension, owner_name, summary_day, analysis
            )
            # First summary: text/markdown summary
            try:
                result = await self._bot.invoke(
                    question=formatted_question,
                    use_conversation_history=False,
                )
                self.data.at[idx, self.output_column] = result.output
            except Exception as e:
                self.logger.error(f"Error during first summary generation: {e}")
                self.data.at[idx, self.output_column] = None
                continue
            # Second summary: structured summary via Pydantic
            try:
                result = await self._bot.invoke(
                    question=formatted_question,
                    response_model=SMSAnalysisSummary,
                    use_conversation_history=False,
                )
                output = result.output
                if isinstance(output, str):
                    try:
                        output = json.loads(output.replace('\n', ''))
                    except json.JSONDecodeError:
                        pass
                if isinstance(output, SMSAnalysisSummary):
                    output = output.model_dump(
                        by_alias=False,
                        exclude_none=True,
                    )
                self.data.at[idx, self.summary_column] = output
            except Exception as e:
                self.logger.error(f"Error during second summary generation: {e}")
                self.data.at[idx, self.summary_column] = None
                continue
        return self.data
