from .TableOutput import TableOutput

__all__ = ("TableOutput",)
