"""
CreateReport.

Component for creating Rich Reports and send via Notify.
"""

from .CreateReport import CreateReport

__all__ = ["CreateReport"]
