"""
Zoom Phone Component for FlowTask.

Concrete implementation of ZoomInterface using the standard HTTP layer
provided by the interface.  Supports two operation types:

- ``call_logs`` – fetch call logs with optional recording / transcript
  downloads.
- ``sms`` – fetch SMS sessions and messages for given phone numbers or
  extensions.

Usage in a FlowTask YAML::

    ZoomUs:
      type: call_logs
      from_date: "2025-01-01"
      to_date: "2025-01-31"
      download: true
      download_transcripts: true

    ZoomUs:
      type: sms
      from_date: "2025-01-01"
      to_date: "2025-01-31"
      phone_numbers: "18001234567,18007654321"
"""
import asyncio
import time
from collections.abc import Callable
from datetime import datetime, timedelta
from io import BytesIO
from pathlib import Path
from typing import Optional, Dict, Any, List

import pandas as pd
from tqdm import tqdm

from ..interfaces.zoom import ZoomInterface
from ..interfaces.cache import CacheSupport
from ..interfaces.Boto3Client import Boto3Client
from ..interfaces.qs import QSSupport
from .flow import FlowComponent
from ..exceptions import ComponentError, ConfigError
from ..conf import (
    ZOOM_ACCOUNT_ID,
    ZOOM_CLIENT_ID,
    ZOOM_CLIENT_SECRET,
)


class ZoomUs(ZoomInterface, CacheSupport, Boto3Client, QSSupport, FlowComponent):
    """Zoom Phone Component for FlowTask (interface-based).

    1:1 replacement for the master ``Zoom`` component.  All Zoom API
    interactions go through ``ZoomInterface``; business logic (S3,
    database auto-skip, ``as_bytes`` mode, tqdm) lives here.

    Args:
        type: ``call_logs`` (default) or ``sms``.
        from_date: Start date ``YYYY-MM-DD``.
        to_date: End date ``YYYY-MM-DD``.
        download: Download recordings (default ``True``).
        download_transcripts: Download transcripts (default ``True``).
        as_bytes: Keep files in memory as ``BytesIO`` (default ``False``).
        auto_skip_processed: Query DB to skip existing recordings.
        recordings_table: DB table with existing recordings.
        call_id_column: Column name for call ID in DB.
        s3_filename_column: Column with S3 key in DB.
        s3_config: Named S3 credential set.
        bucket: S3 bucket name.
        directory: S3 prefix / directory.
    """

    _version = "1.0.0"
    BASE_URL = "https://api.zoom.us/v2"
    CACHE_KEY = "_zoom_authentication"

    def __init__(
        self,
        loop: asyncio.AbstractEventLoop = None,
        job: Callable = None,
        stat: Callable = None,
        **kwargs,
    ):
        # ── Type dispatch ──
        self._fn = kwargs.pop("type", "call_logs").lower().strip()
        if self._fn not in ("call_logs", "sms"):
            raise ConfigError(
                f"Invalid type '{self._fn}'. Supported: 'call_logs', 'sms'"
            )

        # ── Credentials ──
        self.client_id = kwargs.pop("client_id", ZOOM_CLIENT_ID)
        self.client_secret = kwargs.pop("client_secret", ZOOM_CLIENT_SECRET)
        self.account_id = kwargs.pop("account_id", ZOOM_ACCOUNT_ID)
        self.access_token: Optional[str] = kwargs.pop("access_token", None)
        self.timeout = kwargs.get("timeout", 30)
        self.session = None

        # ── Date range ──
        self.from_date: str = kwargs.get("from_date")
        self.to_date: str = kwargs.get("to_date")

        # ── Phone numbers / Extensions (SMS) ──
        pn = kwargs.get("phone_numbers")
        self.phone_numbers: List[str] = (
            [str(p).strip() for p in pn if str(p).strip()]
            if isinstance(pn, list)
            else [p.strip() for p in (pn or "").split(",") if p.strip()]
        )
        ext = kwargs.get("extensions")
        self.extensions: List[str] = (
            [str(e).strip() for e in ext if str(e).strip()]
            if isinstance(ext, list)
            else [e.strip() for e in (ext or "").split(",") if e.strip()]
        )

        # ── Paths ──
        base_path = Path(kwargs.get("base_path", "/tmp/zoom"))
        self.save_path = Path(kwargs.get("save_path", base_path / "recordings"))
        self.transcripts_path = Path(
            kwargs.get("transcripts_path", base_path / "transcripts")
        )
        self.download_recordings: bool = bool(kwargs.get("download", True))
        self.download_transcripts: bool = bool(kwargs.get("download_transcripts", True))
        self.max_pages: Optional[int] = kwargs.get("max_pages")

        # ── Extension column filtering ──
        self.extension_column: Optional[str] = kwargs.get("extension_column")
        self._extensions_filter: List[str] = []

        # ── as_bytes mode ──
        self.as_bytes: bool = kwargs.get("as_bytes", False)
        self.content_type: str = kwargs.get("content_type", "audio/mpeg")

        # ── Auto-skip / DB ──
        self.auto_skip_processed: bool = kwargs.get("auto_skip_processed", False)
        self.datasource: str = kwargs.get("datasource", "db")
        self.recordings_table: str = kwargs.get("recordings_table", "recordings")
        self.call_id_column: str = kwargs.get("call_id_column", "call_id")
        self.s3_filename_column: str = kwargs.get(
            "s3_filename_column", "recording_mp3_s3_key"
        )
        self.s3_directory: str = kwargs.get("directory", "zoom/recordings/")
        self._driver: str = kwargs.get("driver", "pg")

        # ── S3 ──
        self._s3_config: str = kwargs.get("s3_config", "default")
        if self.auto_skip_processed:
            kwargs["config"] = self._s3_config

        # ── State ──
        self._existing_recordings: Dict[str, str] = {}
        self._s3_client = None
        self._phone_to_extension_map: Dict[str, str] = {}
        self._extension_phone_map: Dict[str, str] = {}

        # ── Ensure folders ──
        if not self.as_bytes:
            self.save_path.mkdir(parents=True, exist_ok=True)
            self.transcripts_path.mkdir(parents=True, exist_ok=True)

        super().__init__(loop=loop, job=job, stat=stat, **kwargs)

    # =================================================================
    # Lifecycle
    # =================================================================

    async def start(self, **kwargs):
        """Authenticate and prepare for execution."""
        # Process masks on dates
        if hasattr(self, "masks"):
            for mask, replace in self._mask.items():
                if self.from_date:
                    self.from_date = self.from_date.replace(mask, str(replace))
                if self.to_date:
                    self.to_date = self.to_date.replace(mask, str(replace))

        self._logger.info("🔐 Starting Zoom authentication...")
        # Use the interface's token method
        token = await self._get_access_token()
        self._logger.info("✅ Successfully authenticated with Zoom API")

        # Process input DataFrame if provided
        if self.previous and hasattr(self, "input") and self.input is not None:
            if hasattr(self.input, "empty") and not self.input.empty:
                self._logger.info(
                    f"📊 Received input DataFrame with {len(self.input)} rows"
                )
                self._process_input_dataframe()

        return True

    # =================================================================
    # Input processing helpers
    # =================================================================

    def _process_input_dataframe(self):
        """Extract extensions for call-log filtering from input DataFrame."""
        if not self.extension_column:
            return

        if self.extension_column not in self.input.columns:
            self._logger.warning(
                f"Extension column '{self.extension_column}' not found. "
                f"Available: {list(self.input.columns)}"
            )
            return

        extensions = (
            self.input[self.extension_column].dropna().astype(str).unique().tolist()
        )
        self._extensions_filter = [ext.strip() for ext in extensions if ext.strip()]
        if self._extensions_filter:
            self._logger.info(
                f"🔍 Extracted {len(self._extensions_filter)} extensions "
                f"from column '{self.extension_column}'"
            )

    def _process_input_dataframe_for_sms(self):
        """Extract phone numbers and extensions from input DataFrame for SMS."""
        extension_column = None
        phone_column = None

        for col_name in ("extension", "extensions", "extension_number"):
            if col_name in self.input.columns:
                extension_column = col_name
                break

        for col_name in ("phone_number", "phone_numbers"):
            if col_name in self.input.columns:
                phone_column = col_name
                break

        # Hybrid: build bidirectional mapping if both columns exist
        if extension_column and phone_column:
            self._logger.info(
                "📋 Found both extension and phone_number columns – "
                "creating local mapping"
            )
            for _, row in self.input.iterrows():
                ext = str(row[extension_column]).strip()
                phone = str(row[phone_column]).strip()
                if ext and phone and phone.lower() not in ("nan", "none", ""):
                    normalized = self.normalize_phone_number(phone)
                    self._extension_phone_map[ext] = normalized
                    self._phone_to_extension_map[normalized] = ext
            self._logger.info(
                f"✅ Created mapping for {len(self._extension_phone_map)} extension(s)"
            )

        # Extract phone numbers
        if phone_column:
            phone_numbers = (
                self.input[phone_column].dropna().astype(str).unique().tolist()
            )
            for num in phone_numbers:
                num = num.strip()
                if num and num.lower() not in ("nan", "none", ""):
                    normalized = self.normalize_phone_number(num)
                    if normalized not in self.phone_numbers:
                        self.phone_numbers.append(normalized)

        # Extract extensions
        if extension_column:
            exts = (
                self.input[extension_column].dropna().astype(str).unique().tolist()
            )
            for ext in exts:
                ext = ext.strip()
                if ext and ext not in self.extensions:
                    self.extensions.append(ext)

    # =================================================================
    # Main entry point
    # =================================================================

    async def run(self):
        """Dispatch to the appropriate method based on ``type``."""
        t0 = time.time()
        self._logger.info(f"🚀 Starting ZoomUs {self._fn.upper()} processing...")

        fn = getattr(self, self._fn, None)
        if fn is None or not callable(fn):
            raise ComponentError(
                f"Unknown operation type: '{self._fn}'. "
                f"Supported: 'call_logs', 'sms'"
            )

        self._result = await fn()
        self.add_metric("DURATION_SEC", round(time.time() - t0, 3))
        return self._result

    # =================================================================
    # call_logs flow
    # =================================================================

    async def call_logs(self) -> pd.DataFrame:
        """Fetch call logs and optionally download recordings/transcripts.

        Full 1:1 replacement for ``Zoom.py``'s ``call_logs`` method including:
        auto-skip (DB), S3 download with Zoom API fallback, ``as_bytes``
        mode, deduplication, tqdm progress, and detailed metrics.
        """
        t0 = time.time()

        if not self.from_date or not self.to_date:
            raise ComponentError("from_date and to_date are required for call_logs")

        self._logger.info(f"📅 Date range: {self.from_date} → {self.to_date}")
        self._logger.info(f"⬇️ Download recordings: {self.download_recordings}")
        self._logger.info(f"📝 Download transcripts: {self.download_transcripts}")
        self._logger.info(f"💾 as_bytes mode: {self.as_bytes}")
        self._logger.info(f"🔄 auto_skip_processed: {self.auto_skip_processed}")

        # Process input DataFrame for extension filtering
        if self.previous and hasattr(self, "input") and self.input is not None:
            if hasattr(self.input, "empty") and not self.input.empty:
                self._process_input_dataframe()

        # Ensure paths (only when saving to disk)
        if not self.as_bytes:
            self.save_path.mkdir(parents=True, exist_ok=True)
            self.transcripts_path.mkdir(parents=True, exist_ok=True)

        # ── Fetch call logs with pagination ──
        self._logger.info("📞 Fetching call logs...")
        all_logs: List[Dict[str, Any]] = []
        next_page = None
        page = 0

        while True:
            data = await self.get_call_logs(
                from_date=self.from_date,
                to_date=self.to_date,
                next_page_token=next_page,
            )
            items = data.get("call_logs", [])
            all_logs.extend(items)
            self._logger.info(f"📊 Page {page + 1}: {len(items)} logs")

            next_page = data.get("next_page_token")
            page += 1
            if self.max_pages and page >= self.max_pages:
                self._logger.warning(f"Reached max_pages={self.max_pages}")
                break
            if not next_page:
                break

        self._logger.info(f"✅ Total call logs: {len(all_logs)}")

        df = pd.json_normalize(all_logs) if all_logs else pd.DataFrame()
        # Clean column names (dots → underscores)
        if not df.empty:
            col_map = {c: c.replace(".", "_") for c in df.columns if "." in c}
            if col_map:
                df = df.rename(columns=col_map)

        # Filter by extensions if specified
        if self._extensions_filter and not df.empty:
            field = "owner_extension_number"
            if field in df.columns:

                def _norm_ext(val):
                    if pd.isna(val):
                        return None
                    try:
                        return str(int(float(val)))
                    except (ValueError, TypeError):
                        return str(val).strip()

                df["_ext_norm"] = df[field].apply(_norm_ext)
                before = len(df)
                df = df[df["_ext_norm"].isin(self._extensions_filter)]
                df = df.drop(columns=["_ext_norm"])
                self._logger.info(
                    f"✅ Filtered by extension: {before} → {len(df)} calls"
                )

        if df.empty:
            self._logger.warning("⚠️ No call logs found")
            self._add_empty_metrics()
            self._result = df
            return df

        # ── Output columns ──
        if self.as_bytes:
            for col in ("file_data", "content_type", "downloaded_filename",
                         "transcript_data", "transcript_filename"):
                if col not in df.columns:
                    df[col] = None
        else:
            for col in ("local_path", "recording_filename",
                         "transcript_paths", "transcript_filename"):
                if col not in df.columns:
                    df[col] = None

        # ── Identify recorded calls ──
        self._logger.info("🔍 Filtering recorded calls...")

        has_rec = pd.Series(False, index=df.index)
        if "has_recording" in df.columns:
            has_rec = df["has_recording"].astype(str).str.lower().isin(
                ["true", "1", "yes"]
            )
        by_rec_id = (
            df["recording_id"].notna() if "recording_id" in df.columns else False
        )
        by_rec_type = (
            df["recording_type"].notna() if "recording_type" in df.columns else False
        )

        count_has_rec = int(has_rec.sum())
        count_rec_id = int(by_rec_id.sum()) if not isinstance(by_rec_id, bool) else 0
        count_rec_type = int(by_rec_type.sum()) if not isinstance(by_rec_type, bool) else 0

        self._logger.info(f"📹 Found {count_has_rec} calls with has_recording=True")
        self._logger.info(f"🆔 Found {count_rec_id} calls with recording_id")
        self._logger.info(f"📋 Found {count_rec_type} calls with recording_type")

        recorded_df = df[has_rec | by_rec_id | by_rec_type]
        recorded_count = len(recorded_df)
        self._logger.info(f"🎯 Processing {recorded_count} recorded calls...")

        if recorded_count == 0 or not (
            self.download_recordings or self.download_transcripts
        ):
            self._add_final_metrics(df, recorded_count, 0, 0, 0, t0)
            self._result = df
            return df

        # ── Auto-skip: separate into new-downloads vs S3-downloads ──
        new_call_ids: List[str] = []
        s3_call_ids: Dict[str, str] = {}  # call_id → s3_filename

        if self.auto_skip_processed:
            all_call_ids = []
            for _, row in recorded_df.iterrows():
                cid = str(row.get("call_id", "") or "").strip()
                if cid:
                    all_call_ids.append(cid)
            if all_call_ids:
                self._existing_recordings = await self._fetch_existing_recordings(
                    all_call_ids
                )
                for cid in all_call_ids:
                    if cid in self._existing_recordings:
                        s3_call_ids[cid] = self._existing_recordings[cid]
                    else:
                        new_call_ids.append(cid)
                self._logger.info(
                    f"📊 Auto-skip status: {len(s3_call_ids)}/{recorded_count} "
                    f"recordings already exist in database"
                )
        else:
            for _, row in recorded_df.iterrows():
                cid = str(row.get("call_id", "") or "").strip()
                if cid:
                    new_call_ids.append(cid)

        # ── Summary before download ──
        total_to_process = len(new_call_ids) + len(s3_call_ids)
        self._logger.info(f"🎥 Total recordings to process: {total_to_process}")
        self._logger.info(f"   📥 New recordings from Zoom API: {len(new_call_ids)}")
        self._logger.info(f"   ♻️ Existing recordings from S3: {len(s3_call_ids)}")

        # ── Download from Zoom API (new recordings) ──
        downloaded = 0
        transcripts_downloaded = 0
        skipped_s3 = 0
        seen_recording_keys: set = set()
        seen_transcript_keys: set = set()

        rows_to_process = recorded_df[
            recorded_df.apply(
                lambda r: str(r.get("call_id", "") or "").strip() in new_call_ids,
                axis=1,
            )
        ] if new_call_ids else pd.DataFrame()

        if not rows_to_process.empty:
            self._logger.info(
                f"🎥 Starting download of {len(rows_to_process)} NEW "
                f"recording files from Zoom API..."
            )
            for _, row in tqdm(
                rows_to_process.iterrows(),
                total=len(rows_to_process),
                desc="Recordings",
                disable=not self._logger.isEnabledFor(20),  # INFO level
            ):
                call_ref = str(row.get("call_id", "") or "").strip()
                call_uuid = str(row.get("id", "") or "").strip()
                call_ref = call_ref or call_uuid
                if not call_ref:
                    continue

                try:
                    meta = await self.get_recording_metadata(call_ref)

                    # ── Recordings ──
                    if self.download_recordings:
                        rec_entries = self._extract_rec_entries(meta)
                        for url, rec_id in rec_entries:
                            dedup_key = f"{call_ref}_{rec_id}"
                            if dedup_key in seen_recording_keys:
                                continue
                            seen_recording_keys.add(dedup_key)

                            result = await self._download_and_store(
                                url, call_ref, rec_id, is_transcript=False
                            )
                            if result is not None:
                                downloaded += 1
                                self._update_df_recording(
                                    df, call_ref, result
                                )

                    # ── Transcripts ──
                    if self.download_transcripts:
                        t_ids = self._extract_transcript_ids(meta)
                        for rid in t_ids:
                            dedup_key = f"{call_ref}_{rid}"
                            if dedup_key in seen_transcript_keys:
                                continue
                            seen_transcript_keys.add(dedup_key)
                            try:
                                content = await self.download_transcript_by_recording_id(rid)
                                if content:
                                    transcripts_downloaded += 1
                                    self._store_transcript(
                                        df, call_ref, rid, content
                                    )
                            except Exception as te:
                                self._logger.warning(
                                    f"  Transcript error {call_ref}/{rid}: {te}"
                                )

                except Exception as e:
                    self._logger.warning(f"Failed metadata for {call_ref}: {e}")

        # ── Download from S3 (existing recordings) ──
        if s3_call_ids and self.download_recordings:
            self._logger.info(
                f"☁️ Downloading {len(s3_call_ids)} recording(s) from S3..."
            )
            for call_id, s3_filename in tqdm(
                s3_call_ids.items(),
                desc="S3 Downloads",
                disable=not self._logger.isEnabledFor(20),
            ):
                result = await self._download_recording_from_s3(
                    s3_filename, call_id
                )
                if result is not None:
                    skipped_s3 += 1
                    self._update_df_recording(df, call_id, result)
                else:
                    # Fallback to Zoom API if S3 fails
                    self._logger.warning(
                        f"  S3 failed for {call_id}, falling back to API"
                    )
                    try:
                        meta = await self.get_recording_metadata(call_id)
                        rec_entries = self._extract_rec_entries(meta)
                        for url, rec_id in rec_entries:
                            result = await self._download_and_store(
                                url, call_id, rec_id, is_transcript=False
                            )
                            if result is not None:
                                downloaded += 1
                                self._update_df_recording(df, call_id, result)
                                break
                    except Exception as e:
                        self._logger.error(
                            f"  API fallback also failed for {call_id}: {e}"
                        )

        # ── Metrics ──
        self._add_final_metrics(
            df, recorded_count, downloaded, transcripts_downloaded, skipped_s3, t0
        )
        self._logger.info(
            f"🎉 Done: {len(df)} logs, {downloaded} new downloads, "
            f"{skipped_s3} from S3, {transcripts_downloaded} transcripts"
        )
        self._result = df
        return self._result

    # =================================================================
    # sms flow
    # =================================================================

    async def sms(self) -> pd.DataFrame:
        """Fetch SMS sessions and messages for specified phone numbers."""
        # Process input DataFrame
        if self.previous and hasattr(self, "input") and self.input is not None:
            if hasattr(self.input, "empty") and not self.input.empty:
                self._logger.info(
                    f"📊 Input DataFrame: {len(self.input)} rows"
                )
                self._process_input_dataframe_for_sms()

        # Extension → phone lookup
        if self.extensions:
            self._logger.info(
                f"🔍 Looking up {len(self.extensions)} extension(s)..."
            )
            for ext in self.extensions:
                # Use local mapping first, then API
                if ext in self._extension_phone_map:
                    normalized = self._extension_phone_map[ext]
                    if normalized not in self.phone_numbers:
                        self.phone_numbers.append(normalized)
                    self._logger.info(f"  ✅ Ext {ext} → {normalized} (local)")
                else:
                    numbers = await self.get_phone_numbers_by_extension(ext)
                    for num in numbers:
                        normalized = self.normalize_phone_number(num)
                        if normalized not in self.phone_numbers:
                            self.phone_numbers.append(normalized)
                        self._phone_to_extension_map[normalized] = ext
                    if numbers:
                        self._logger.info(
                            f"  ✅ Ext {ext} → {len(numbers)} number(s) (API)"
                        )
                    else:
                        self._logger.warning(f"  ⚠️ Ext {ext}: not found")

        if not self.phone_numbers:
            raise ConfigError(
                "No phone numbers found. Provide 'phone_numbers', 'extensions', "
                "or an input DataFrame with appropriate columns."
            )

        self._logger.info(f"📱 Phone numbers: {', '.join(self.phone_numbers)}")

        # ── Step 1: Fetch sessions ──
        all_sessions: List[Dict[str, Any]] = []
        for phone_number in self.phone_numbers:
            self._logger.info(f"  Querying sessions for {phone_number}...")
            next_page = None
            page = 0

            # Calculate to_date if not provided (SMS API requires both)
            effective_to = self.to_date
            if self.from_date and not effective_to:
                from_dt = datetime.strptime(self.from_date, "%Y-%m-%d")
                max_to = from_dt + timedelta(days=31)
                effective_to = min(max_to, datetime.now()).strftime("%Y-%m-%d")

            while True:
                try:
                    data = await self.list_sms_sessions(
                        phone_number=phone_number,
                        from_date=self.from_date,
                        to_date=effective_to,
                        next_page_token=next_page,
                    )
                    sessions = data.get("sms_sessions", [])
                    for s in sessions:
                        s["queried_phone_number"] = phone_number
                        s["fetched_at"] = datetime.utcnow().isoformat() + "Z"
                    all_sessions.extend(sessions)
                    self._logger.info(
                        f"    Page {page + 1}: {len(sessions)} session(s)"
                    )

                    next_page = data.get("next_page_token")
                    page += 1
                    if self.max_pages and page >= self.max_pages:
                        break
                    if not next_page:
                        break
                except Exception as e:
                    self._logger.error(
                        f"    Error fetching sessions for {phone_number}: {e}"
                    )
                    break

        self._logger.info(f"✅ Total sessions: {len(all_sessions)}")
        self.add_metric("SMS_SESSIONS_COUNT", len(all_sessions))

        if not all_sessions:
            self._logger.warning("⚠️ No SMS sessions found")
            self.add_metric("NUMROWS", 0)
            self.add_metric("SMS_MESSAGES_COUNT", 0)
            return pd.DataFrame()

        # ── Step 2: Fetch messages per session ──
        session_records = []
        total_messages = 0

        for idx, session in enumerate(all_sessions, 1):
            session_id = session.get("session_id") or session.get("id")
            if not session_id:
                continue

            session_messages = session.get("sms_histories") or session.get(
                "messages", []
            )

            if not session_messages:
                try:
                    next_page = None
                    while True:
                        details = await self.get_sms_session_details(
                            session_id, next_page_token=next_page
                        )
                        msgs = details.get("sms_histories", [])
                        session_messages.extend(msgs)

                        next_page = details.get("next_page_token")
                        if not next_page:
                            break
                except Exception as e:
                    self._logger.error(
                        f"  Session {idx}: Error fetching messages – {e}"
                    )
                    continue

            # Build session record
            queried_phone = session.get("queried_phone_number", "")
            bound = self.determine_bound(session)
            extension = self._phone_to_extension_map.get(
                self.normalize_phone_number(queried_phone), ""
            )

            # Participant details
            participants = session.get("participants", [])
            owner_number = owner_name = other_number = None
            for p in participants:
                if p.get("is_session_owner", False):
                    owner_number = p.get("phone_number", "")
                    owner_name = p.get("display_name", "")
                else:
                    other_number = p.get("phone_number", "")

            # Last message time
            last_message_time = session.get("last_message_time")
            if not last_message_time and session_messages:
                times = [m.get("date_time") for m in session_messages if m.get("date_time")]
                if times:
                    last_message_time = max(times)

            session_records.append(
                {
                    "session_id": session_id,
                    "extension": extension,
                    "phone_number": queried_phone,
                    "bound": bound,
                    "owner_number": owner_number,
                    "owner_name": owner_name,
                    "other_number": other_number,
                    "session_type": session.get("session_type"),
                    "last_message_time": last_message_time,
                    "last_access_time": session.get("last_access_time"),
                    "message_count": len(session_messages),
                    "messages": session_messages,
                    "participants": participants,
                    "fetched_at": session.get("fetched_at"),
                }
            )
            total_messages += len(session_messages)

        self._logger.info(
            f"✅ Processed {len(session_records)} session(s) "
            f"with {total_messages} message(s)"
        )

        if not session_records:
            self.add_metric("NUMROWS", 0)
            self.add_metric("SMS_MESSAGES_COUNT", 0)
            return pd.DataFrame()

        df = pd.DataFrame(session_records)
        self.add_metric("NUMROWS", len(df))
        self.add_metric("NUMCOLS", len(df.columns))
        self.add_metric("SMS_SESSIONS_COUNT", len(session_records))
        self.add_metric("SMS_MESSAGES_COUNT", total_messages)

        return df

    # =================================================================
    # S3 / Database helpers
    # =================================================================

    async def _get_s3_client(self):
        """Get or initialize S3 client (lazy, avoids QSSupport conflicts)."""
        if self._s3_client is None:
            import boto3
            from ..conf import AWS_CREDENTIALS

            s3_credentials = AWS_CREDENTIALS.get(self._s3_config)
            if s3_credentials:
                cred = {
                    "aws_access_key_id": s3_credentials.get("aws_key"),
                    "aws_secret_access_key": s3_credentials.get("aws_secret"),
                    "region_name": s3_credentials.get("region_name", "us-east-1"),
                }
                self._s3_client = boto3.client("s3", **cred)
                if not getattr(self, "bucket", None) and "bucket" in s3_credentials:
                    self.bucket = s3_credentials["bucket"]
            else:
                self._s3_client = boto3.client("s3", region_name="us-east-1")
        return self._s3_client

    async def _fetch_existing_recordings(
        self, call_ids: List[str]
    ) -> Dict[str, str]:
        """Query DB for existing recordings.

        Returns:
            Dict mapping ``call_id`` → ``s3_filename``.
        """
        if not call_ids:
            return {}
        try:
            connection = await self.create_connection()
            placeholders = ",".join(f"${i+1}" for i in range(len(call_ids)))
            query = (
                f"SELECT {self.call_id_column}, {self.s3_filename_column} "
                f"FROM {self.recordings_table} "
                f"WHERE {self.call_id_column} IN ({placeholders}) "
                f"AND {self.s3_filename_column} IS NOT NULL"
            )
            self._logger.info(f"🔍 Querying DB for {len(call_ids)} call_ids...")
            async with await connection.connection() as conn:
                res, error = await conn.query(query, *call_ids)
                if error:
                    self._logger.error(f"DB query error: {error}")
                    return {}
                result = {}
                for row in res:
                    cid = row[self.call_id_column]
                    s3fn = row[self.s3_filename_column]
                    if s3fn:
                        result[cid] = s3fn
                self._logger.info(f"✅ Found {len(result)} existing recordings")
                return result
        except Exception as e:
            self._logger.error(f"Error querying existing recordings: {e}")
            return {}

    async def _download_recording_from_s3(
        self, s3_filename: str, call_id: str
    ):
        """Download recording from S3.

        Returns:
            ``(BytesIO, content_type, filename)`` if ``as_bytes``,
            ``Path`` if disk mode, or ``None`` on error.
        """
        bucket = getattr(self, "bucket", None)
        if not bucket:
            self._logger.error("S3 bucket not set, cannot download")
            return None
        try:
            s3_key = (
                self.s3_directory + s3_filename
                if self.s3_directory
                else s3_filename
            )
            s3_client = await self._get_s3_client()
            response = s3_client.get_object(Bucket=bucket, Key=s3_key)
            content = response["Body"].read()
            ct = response.get("ContentType", self.content_type)

            if self.as_bytes:
                fd = BytesIO(content)
                fd.seek(0)
                return (fd, ct, s3_filename)

            final_path = self.save_path / s3_filename
            final_path.parent.mkdir(parents=True, exist_ok=True)
            with open(final_path, "wb") as f:
                f.write(content)
            return final_path
        except Exception as e:
            self._logger.error(f"S3 download error for {s3_filename}: {e}")
            return None

    # =================================================================
    # Download helpers
    # =================================================================

    async def _download_and_store(
        self,
        url: str,
        call_ref: str,
        rec_id: str,
        is_transcript: bool = False,
    ):
        """Download binary from Zoom API via interface and store.

        Returns:
            ``(BytesIO, content_type, filename)`` in as_bytes mode,
            ``Path`` in disk mode, or ``None`` on failure.
        """
        try:
            content_bytes, ct, filename = await self.download_binary(url)
            if not content_bytes:
                self._logger.warning(f"  ⚠️ Empty content for {call_ref}")
                return None

            # Fallback filename
            if not filename or filename == "download":
                ext = ".txt" if is_transcript else ".mp4"
                filename = f"{call_ref}_{rec_id}{ext}"

            if self.as_bytes:
                fd = BytesIO(content_bytes)
                fd.seek(0)
                return (fd, ct, filename)

            dest = (
                self.transcripts_path if is_transcript else self.save_path
            )
            final_path = dest / filename
            final_path.parent.mkdir(parents=True, exist_ok=True)
            with open(final_path, "wb") as f:
                f.write(content_bytes)

            self._logger.info(
                f"  ✅ Saved: {final_path.name} "
                f"({len(content_bytes) / 1024:.1f} KB)"
            )
            return final_path

        except asyncio.TimeoutError:
            self._logger.error(f"  ❌ Timeout downloading {call_ref}_{rec_id}")
        except Exception as e:
            self._logger.error(f"  ❌ Download failed for {call_ref}: {e}")
        return None

    @staticmethod
    def _extract_rec_entries(meta: Dict) -> List[tuple]:
        """Extract ``(download_url, recording_id)`` pairs from metadata."""
        entries = []
        recs = meta.get("recordings")
        if isinstance(recs, list) and recs:
            for rec in recs:
                url = rec.get("download_url") or rec.get("file_url")
                if not url:
                    continue
                rid = str(
                    rec.get("id") or rec.get("recording_id") or ""
                ).strip()
                entries.append((url, rid or "rec"))
        else:
            url = meta.get("download_url") or meta.get("file_url")
            if url:
                rid = str(
                    meta.get("id") or meta.get("recording_id") or ""
                ).strip()
                entries.append((url, rid or "rec"))
        return entries

    @staticmethod
    def _extract_transcript_ids(meta: Dict) -> List[str]:
        """Extract recording IDs that may have transcripts."""
        ids = []
        recs = meta.get("recordings")
        if isinstance(recs, list) and recs:
            for rec in recs:
                rid = str(
                    rec.get("id") or rec.get("recording_id") or ""
                ).strip()
                if rid:
                    ids.append(rid)
        else:
            rid = str(
                meta.get("id") or meta.get("recording_id") or ""
            ).strip()
            if rid:
                ids.append(rid)
        return ids

    def _update_df_recording(self, df: pd.DataFrame, call_ref: str, result):
        """Update the DataFrame row with the download result."""
        mask = df["call_id"].astype(str).str.strip().eq(call_ref)
        if not mask.any() and "id" in df.columns:
            mask = mask | df["id"].astype(str).str.strip().eq(call_ref)

        if not mask.any():
            return

        if self.as_bytes and isinstance(result, tuple):
            fd, ct, fname = result
            for idx in df.index[mask]:
                df.at[idx, "file_data"] = fd
                df.at[idx, "content_type"] = ct
                df.at[idx, "downloaded_filename"] = fname
        elif isinstance(result, Path):
            df.loc[mask, "local_path"] = str(result)
            df.loc[mask, "recording_filename"] = result.name

    def _store_transcript(
        self, df: pd.DataFrame, call_ref: str, rid: str, content: bytes
    ):
        """Store a transcript (BytesIO or disk) and update the DataFrame."""
        mask = df["call_id"].astype(str).str.strip().eq(call_ref)
        if not mask.any() and "id" in df.columns:
            mask = mask | df["id"].astype(str).str.strip().eq(call_ref)

        fname = f"{call_ref}_{rid}.txt"
        if self.as_bytes:
            fd = BytesIO(content)
            fd.seek(0)
            for idx in df.index[mask]:
                df.at[idx, "transcript_data"] = fd
                df.at[idx, "transcript_filename"] = fname
        else:
            path = self.transcripts_path / fname
            path.write_bytes(content)
            self._logger.debug(f"  📝 Transcript saved: {path.name}")
            if mask.any():
                df.loc[mask, "transcript_paths"] = str(path)
                df.loc[mask, "transcript_filename"] = fname

    # =================================================================
    # Metrics helpers
    # =================================================================

    def _add_empty_metrics(self):
        """Add zero metrics when no data is found."""
        for key in (
            "NUMROWS", "NUMCOLS", "RECORDED_COUNT",
            "DOWNLOADED_COUNT", "TRANSCRIPTS_DOWNLOADED",
        ):
            self.add_metric(key, 0)

    def _add_final_metrics(
        self, df, recorded, downloaded, transcripts, s3_count, t0
    ):
        """Add summary metrics at the end of call_logs."""
        self.add_metric("NUMROWS", len(df))
        self.add_metric("NUMCOLS", len(df.columns))
        self.add_metric("RECORDED_COUNT", recorded)
        self.add_metric("DOWNLOADED_COUNT", downloaded)
        self.add_metric("S3_DOWNLOADED_COUNT", s3_count)
        self.add_metric("TRANSCRIPTS_DOWNLOADED", transcripts)
        self.add_metric("SAVE_PATH", str(self.save_path))
        self.add_metric("TRANSCRIPTS_PATH", str(self.transcripts_path))
        self.add_metric("DURATION_SEC", round(time.time() - t0, 3))

    # =================================================================
    # Lifecycle
    # =================================================================

    async def close(self):
        """Cleanup session and S3 client."""
        if self.session and not self.session.closed:
            await self.session.close()
        # S3 client doesn't need explicit close
        return True

