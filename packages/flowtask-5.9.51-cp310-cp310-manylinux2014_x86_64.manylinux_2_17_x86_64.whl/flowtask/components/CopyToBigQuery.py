import asyncio
from collections.abc import Callable
import math
import time
import pandas as pd
from asyncdb import AsyncDB
from asyncdb.exceptions import (
    StatementError,
    DataError
)
from pathlib import Path
from .CopyTo import CopyTo
from ..interfaces.dataframes import PandasDataframe
from ..exceptions import (
    ComponentError,
    DataNotFound
)
from querysource.conf import (
    BIGQUERY_CREDENTIALS,
    BIGQUERY_PROJECT_ID
)


class CopyToBigQuery(CopyTo, PandasDataframe):
    """
    CopyToBigQuery.

    Overview

        This component allows copying data into a BigQuery table,
        using write functionality from AsyncDB BigQuery driver.

        :widths: auto

        | tablename    |   Yes    | Name of the table in                                   |
        |              |          | BigQuery                                               |
        | schema       |   Yes    | Name of the dataset                                    |
        |              |          | where the table is located                             |
        | truncate     |   Yes    | This option indicates if the component should empty    |
        |              |          | before copying the new data to the table. If set to    |
        |              |          | true, the table will be truncated before saving data.  |
        | use_buffer   |   No     | When activated, this option allows optimizing the      |
        |              |          | performance of the task when dealing with large        |
        |              |          | volumes of data.                                       |
        | credentials  |   No     | Path to BigQuery credentials JSON file                 |
        |              |          |                                                        |
        | project_id   |   No     | Google Cloud Project ID                                |
        |              |          |                                                        |


        Example:

    |---|---|---|
    | version | No | version of component |


        Example:

        | Name | Required | Summary |
    |---|---|---|
    | version | No | version of component |


        Example:

        ```yaml
          CopyToBigQuery:
          schema: hisense
          tablename: product_availability_all
        ```
    """  # noqa: E501
    _version = "1.0.0"

    def __init__(
        self,
        loop: asyncio.AbstractEventLoop = None,
        job: Callable = None,
        stat: Callable = None,
        **kwargs,
    ):
        self.pk = []
        self.truncate: bool = False
        self.delete_before_insert: bool = False  # NEW: Delete matching PK rows before insert
        self.data = None
        self._engine = None
        self.tablename: str = ""
        self.schema: str = ""  # dataset in BigQuery terminology
        self.use_chunks = False
        self._chunksize: int = kwargs.pop('chunksize', 10000)
        self._connection: Callable = None
        self._project_id: str = kwargs.pop('project_id', BIGQUERY_PROJECT_ID)
        self._credentials: str = kwargs.pop('credentials', BIGQUERY_CREDENTIALS)
        self._record_columns: dict = kwargs.pop('record_columns', {})
        try:
            self.multi = bool(kwargs["multi"])
            del kwargs["multi"]
        except KeyError:
            self.multi = False
        super().__init__(
            loop=loop,
            job=job,
            stat=stat,
            **kwargs
        )
        self._driver: str = 'bigquery'

    def default_connection(self):
        """default_connection.

        Default Connection to BigQuery.
        """
        try:
            credentials = self._credentials
            if isinstance(credentials, Path):
                credentials = str(credentials)
            params: dict = {
                "credentials": credentials,
                "project_id": self._project_id
            }
            self._connection = AsyncDB(
                'bigquery',
                params=params,
                loop=self._loop
            )
            return self._connection
        except Exception as err:
            raise ComponentError(
                f"Error configuring BigQuery Connection: {err!s}"
            ) from err

    def _build_record_schema(self) -> list:
        """Build schema including RECORD type columns."""
        type_mapping = {
            'object': 'STRING',
            'string': 'STRING',
            'int64': 'INTEGER',
            'float64': 'FLOAT',
            'Float64': 'FLOAT',
            'bool': 'BOOLEAN',
            'datetime64[ns]': 'TIMESTAMP',
            'datetime64[ns, UTC]': 'TIMESTAMP',
            'datetime64[us, UTC]': 'TIMESTAMP',
            'date': 'DATE'
        }

        bq_schema = []
        for column, dtype in self.data.dtypes.items():
            # Check if this column has a custom RECORD schema
            if column in self._record_columns:
                bq_schema.append({
                    "name": column,
                    "type": "RECORD",
                    "mode": "REPEATED",
                    "fields": self._record_columns[column]
                })
            else:
                bq_type = type_mapping.get(str(dtype), 'STRING')
                bq_schema.append({
                    "name": column,
                    "type": bq_type,
                    "mode": "NULLABLE"
                })

        return bq_schema

    # Function to clean invalid float values
    def clean_floats(self, data):
        def sanitize_value(value):
            if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
                return None
            return value

        if isinstance(data, dict):
            return {k: sanitize_value(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [self.clean_floats(item) for item in data]
        return data

    async def _create_table(self):
        """Create a Table in BigQuery if it doesn't exist."""
        from google.cloud import bigquery
        from google.cloud.exceptions import Conflict, NotFound

        try:
            async with await self._connection.connection() as conn:
                client = conn._connection
                table_ref = client.dataset(self.schema).table(self.tablename)

                # Check if we need to drop the table first
                if hasattr(self, 'create_table') and isinstance(self.create_table, dict):
                    if self.create_table.get('drop', False) is True:
                        print(f"CopyTo: Dropping table {self.schema}.{self.tablename} (create_table['drop']=True)")
                        client.delete_table(table_ref, not_found_ok=True)

                
                # Check if table already exists
                try:
                    client.get_table(table_ref)
                    print(f"CopyTo: Table {self.schema}.{self.tablename} already exists")
                    return
                except NotFound:
                    pass  # Table does not exist, proceed with creation

                # First ensure dataset exists
                await conn.create_dataset(self.schema)

                # Infer schema from DataFrame
                bq_schema = []
                type_mapping = {
                    'object': 'STRING',
                    'string': 'STRING',
                    'int64': 'INTEGER',
                    'Int64': 'INTEGER',
                    'int32': 'INTEGER',
                    'Int32': 'INTEGER',
                    'float64': 'FLOAT',
                    'Float64': 'FLOAT',
                    'bool': 'BOOLEAN',
                    'datetime64[ns]': 'TIMESTAMP',
                    'datetime64[ns, UTC]': 'TIMESTAMP',
                    'datetime64[us, UTC]': 'TIMESTAMP',
                    'date': 'DATE'
                }

                # Build DDL for debugging
                ddl_columns = []

                for column, dtype in self.data.dtypes.items():
                    bq_type = type_mapping.get(str(dtype), 'STRING')
                    # Create SchemaField object directly
                    field = bigquery.SchemaField(column, bq_type, mode="NULLABLE")
                    bq_schema.append(field)
                    ddl_columns.append(f"{column} {bq_type}")

                # Construct and print CREATE TABLE sentence
                ddl = f"CREATE TABLE `{self.schema}.{self.tablename}` (\n"
                ddl += ",\n".join([f"  {col}" for col in ddl_columns])
                ddl += "\n)"
                print(f"CopyTo: Table Sentence: \n{ddl}")

                # If create_table has clustering fields, get them
                clustering_fields = None
                if hasattr(self, 'create_table'):
                    if isinstance(self.create_table, dict) and 'pk' in self.create_table:
                        clustering_fields = self.create_table['pk']


                # Create table using underlying client to support clustering
                client = conn._connection
                table_ref = client.dataset(self.schema).table(self.tablename)
                table = bigquery.Table(table_ref, schema=bq_schema)
                
                if clustering_fields:
                    table.clustering_fields = clustering_fields

                try:
                    table = client.create_table(table)
                    print(f"CopyTo: Created table {table.project}.{table.dataset_id}.{table.table_id}")
                except Conflict:
                    print(f"CopyTo: Table {self.schema}.{self.tablename} already exists")

        except Exception as err:
            raise ComponentError(
                f"Error creating BigQuery table: {err}"
            ) from err

    async def _truncate_table(self):
        """Truncate the BigQuery table using the driver's built-in method."""
        async with await self._connection.connection() as conn:
            await self._connection.truncate_table(
                table_id=self.tablename,
                dataset_id=self.schema
            )

    def _prepare_record_data(self, records: list) -> list:
        """Prepare records for BigQuery, converting datetimes in nested structures."""
        import datetime as dt

        def convert_value(value):
            if isinstance(value, dt.datetime):
                return value.isoformat()
            elif isinstance(value, dict):
                return {k: convert_value(v) for k, v in value.items()}
            elif isinstance(value, list):
                return [convert_value(item) for item in value]
            return value

        return [convert_value(record) for record in records]

    async def _copy_with_records(self):
        """Copy DataFrame to BigQuery with RECORD column support using JSON loading."""
        from google.cloud import bigquery
        # Convert DataFrame to list of dicts
        records = self.data.to_dict(orient='records')

        # Convert datetime objects in nested structures
        records = self._prepare_record_data(records)

        async with await self._connection.connection() as conn:
            client = conn._connection

            table_ref = f"{self._project_id}.{self.schema}.{self.tablename}"

            job_config = bigquery.LoadJobConfig(
                source_format=bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
                write_disposition=bigquery.WriteDisposition.WRITE_APPEND,
            )

            load_job = client.load_table_from_json(
                records,
                table_ref,
                job_config=job_config
            )
            result = load_job.result()  # Wait for completion
            print(f'CopyTo: Loaded {len(records)} rows into {table_ref}')

    async def _copy_with_json_loader(self, json_columns, column_types):
        """Copy DataFrame to BigQuery using NDJSON loader (for JSON column support)."""
        import datetime as dt

        # Convert DataFrame to list of dicts
        records = self.data.to_dict(orient='records')

        def normalize_value(value, column=None):
            col_type = column_types.get(column) if column_types else None
            if value is None:
                return None
            # Check for NaN (skip for lists/arrays to avoid ambiguity error)
            try:
                if pd.isna(value):
                    return None
            except (ValueError, TypeError):
                # value is array/list/dict, not NaN
                pass

            # JSON columns: pass dict/list directly (no serialization needed)
            if column in json_columns and isinstance(value, (dict, list)):
                return value

            # Handle temporal types
            if col_type in ("DATETIME", "TIMESTAMP"):
                if isinstance(value, (int, float)):
                    # Unix timestamp
                    ts = value / 1000 if value > 1_000_000_000_000 else value
                    dt_value = dt.datetime.fromtimestamp(ts, tz=dt.timezone.utc)
                    if col_type == "DATETIME":
                        return dt_value.strftime("%Y-%m-%d %H:%M:%S")
                    return dt_value.isoformat()
                elif isinstance(value, (pd.Timestamp, dt.datetime)):
                    if col_type == "DATETIME":
                        return value.strftime("%Y-%m-%d %H:%M:%S")
                    return value.isoformat()
                elif isinstance(value, dt.date):
                    return dt.datetime.combine(value, dt.time.min).strftime("%Y-%m-%d %H:%M:%S")

            elif col_type == "DATE":
                if isinstance(value, (int, float)):
                    # Unix timestamp to date
                    ts = value / 1000 if value > 1_000_000_000_000 else value
                    dt_value = dt.datetime.fromtimestamp(ts, tz=dt.timezone.utc).date()
                    return dt_value.isoformat()
                elif isinstance(value, (pd.Timestamp, dt.datetime)):
                    return value.date().isoformat()
                elif isinstance(value, dt.date):
                    return value.isoformat()
                elif isinstance(value, str) and "T" in value:
                    # String with time component - extract date part
                    return value.split("T", 1)[0]

            # Recursive for nested structures
            if isinstance(value, dict):
                return {k: normalize_value(v) for k, v in value.items()}
            if isinstance(value, list):
                return [normalize_value(v) for v in value]

            return value

        # Normalize all records
        normalized_records = []
        for record in records:
            normalized = {k: normalize_value(v, column=k) for k, v in record.items()}
            normalized_records.append(normalized)

        print(f'CopyTo: Normalized {len(normalized_records)} records for NDJSON loader')

        # Use NDJSON loader
        async with await self._connection.connection() as conn:
            result = await conn.write(
                data=normalized_records,
                table_id=self.tablename,
                dataset_id=self.schema,
                use_pandas=False,  # Use NDJSON, not parquet
                if_exists="append"
            )
            print(f'CopyTo: NDJSON loader result: {result}')

            # Verify insertion
            count_q = f"SELECT COUNT(*) as count FROM `{self.schema}.{self.tablename}`"
            count_result, count_error = await conn.query(count_q)
            if count_result:
                # Convert RowIterator to list
                rows = list(count_result) if hasattr(count_result, '__iter__') else count_result
                if rows and len(rows) > 0:
                    print(f'CopyTo: Rows in table after INSERT: {rows[0].get("count", "unknown")}')
            elif count_error:
                print(f'CopyTo: Error verifying row count: {count_error}')

    async def _delete_existing_rows(self, column_types=None):
        """
        Delete rows that match PK values in the incoming data before inserting.
        This is more cost-efficient than MERGE for small batch updates.
        """
        if not self.pk or not isinstance(self.data, pd.DataFrame):
            print("CopyTo: Cannot delete - pk not defined or data is not DataFrame")
            return

        # Extract unique PK values from the incoming data
        pk_values = self.data[self.pk].drop_duplicates()

        if pk_values.empty:
            print("CopyTo: No rows to delete (empty PK values)")
            return

        # Convert PK columns to match BigQuery schema types
        if column_types:
            print("=== Converting PK values for DELETE ===")
            for col in self.pk:
                df_type = str(pk_values[col].dtype)
                bq_type = column_types.get(col, "UNKNOWN")
                print(f"  PK {col}: DataFrame={df_type} → BigQuery={bq_type}")

            pk_values = self._convert_dataframe_to_bigquery_types(pk_values, column_types)

            print("=== PK values after conversion (first 3) ===")
            for idx, row in pk_values.head(3).iterrows():
                pk_str = ", ".join([f"{col}={row[col]}" for col in self.pk])
                print(f"  Row {idx}: {pk_str}")

        async with await self._connection.connection() as conn:
            try:
                if len(self.pk) == 1:
                    # Single PK column - use direct IN clause
                    pk_col = self.pk[0]
                    values_list = pk_values[pk_col].tolist()

                    # Convert to SQL-safe format
                    if pd.api.types.is_string_dtype(pk_values[pk_col]):
                        # String values - escape and quote
                        values_str = ", ".join([f"'{str(v).replace(chr(39), chr(39)+chr(39))}'" for v in values_list])
                    elif pd.api.types.is_numeric_dtype(pk_values[pk_col]):
                        # Numeric values
                        values_str = ", ".join([str(v) for v in values_list])
                    else:
                        # Other types - convert to string
                        values_str = ", ".join([f"'{str(v)}'" for v in values_list])

                    delete_q = f"""
                        DELETE FROM `{self.schema}.{self.tablename}`
                        WHERE {pk_col} IN ({values_str})
                    """

                    print(f"=== DELETE Query (single PK) ===\n{delete_q[:500]}...")  # Show first 500 chars
                    result, error = await conn.query(delete_q)
                    if error:
                        raise ComponentError(f"Error deleting existing rows: {error}")

                    print(f'CopyTo: Deleted rows matching {len(values_list)} PK values')

                else:
                    # Multiple PK columns - use temp table approach
                    temp_table = f"{self.tablename}_delete_temp_{int(time.time())}"

                    try:
                        # Load PK values to temp table
                        load_job = await conn.write(
                            data=pk_values,
                            table_id=temp_table,
                            dataset_id=self.schema,
                            use_pandas=True,
                            if_exists="replace"
                        )

                        # Wait for load to complete
                        while not load_job.done():
                            await asyncio.sleep(1)

                        if load_job.errors:
                            raise ComponentError(f"Error loading temp table: {load_job.errors}")

                        # Build DELETE with EXISTS subquery (BigQuery doesn't support multi-column IN)
                        # Add CAST for proper type matching
                        pk_conditions = []
                        for k in self.pk:
                            if column_types and k in column_types:
                                bq_type = column_types[k]
                                # Cast temp table column to match main table type
                                pk_conditions.append(f"T.{k} = CAST(S.{k} AS {bq_type})")
                            else:
                                pk_conditions.append(f"T.{k} = S.{k}")

                        pk_conditions_str = " AND ".join(pk_conditions)
                        delete_q = f"""
                            DELETE FROM `{self.schema}.{self.tablename}` T
                            WHERE EXISTS (
                                SELECT 1 FROM `{self.schema}.{temp_table}` S
                                WHERE {pk_conditions_str}
                            )
                        """

                        print(f"=== DELETE Query ===\n{delete_q}")
                        result, error = await conn.query(delete_q)
                        if error:
                            raise ComponentError(f"Error deleting existing rows: {error}")

                        # Verify deletion
                        count_q = f"SELECT COUNT(*) as count FROM `{self.schema}.{self.tablename}`"
                        count_result, _ = await conn.query(count_q)
                        if count_result:
                            # Convert RowIterator to list
                            rows = list(count_result) if hasattr(count_result, '__iter__') else count_result
                            if rows and len(rows) > 0:
                                print(f'CopyTo: Rows in table after DELETE: {rows[0].get("count", "unknown")}')

                        print(f'CopyTo: Deleted rows matching {len(pk_values)} PK combinations')

                    finally:
                        # Cleanup temp table
                        await conn.query(f"DROP TABLE IF EXISTS `{self.schema}.{temp_table}`")

            except Exception as err:
                raise ComponentError(f"Error in _delete_existing_rows: {err}") from err

    async def _get_table_schema(self):
        """Get BigQuery table schema to properly convert DataFrame columns."""
        column_types = {}
        try:
            async with await self._connection.connection() as conn:
                schema_q = f"""
                    SELECT column_name, data_type
                    FROM {self.schema}.INFORMATION_SCHEMA.COLUMNS
                    WHERE table_name = '{self.tablename}'
                """
                schema_res, error = await conn.query(schema_q)
                if not error and schema_res:
                    column_types = {
                        row["column_name"]: row["data_type"] for row in schema_res
                    }
                    print(f'CopyTo: Retrieved schema for {self.schema}.{self.tablename}')
        except Exception as err:
            print(f'CopyTo: Could not retrieve table schema: {err}')
        return column_types

    def _convert_dataframe_to_bigquery_types(self, df, column_types):
        """Convert DataFrame columns to match BigQuery schema types."""
        converted_df = df.copy()

        for col in converted_df.columns:
            if col not in column_types:
                continue

            bq_type = column_types[col]

            # Handle DATE type
            if bq_type == "DATE":
                if pd.api.types.is_datetime64_any_dtype(converted_df[col]):
                    converted_df[col] = pd.to_datetime(converted_df[col]).dt.date
                    print(f'CopyTo: Converted {col} to DATE (BigQuery schema type)')
                elif pd.api.types.is_integer_dtype(converted_df[col]):
                    # Unix timestamp to date
                    converted_df[col] = pd.to_datetime(converted_df[col], unit='s').dt.date

            # Handle DATETIME type
            elif bq_type == "DATETIME":
                if pd.api.types.is_datetime64_any_dtype(converted_df[col]):
                    converted_df[col] = converted_df[col].dt.tz_localize(None)

            # Handle TIMESTAMP type
            elif bq_type == "TIMESTAMP":
                if pd.api.types.is_datetime64_any_dtype(converted_df[col]):
                    converted_df[col] = converted_df[col].dt.tz_localize(None)

            # Handle STRING type
            elif bq_type == "STRING":
                if pd.api.types.is_datetime64_any_dtype(converted_df[col]):
                    converted_df[col] = converted_df[col].astype(str).replace('NaT', None)
                    print(f'CopyTo: Converted {col} to STRING (from datetime for BigQuery schema)')

        return converted_df

    async def _copy_dataframe(self):
        """Copy a pandas DataFrame to BigQuery."""
        try:
            # Get BigQuery table schema for proper type conversion
            column_types = await self._get_table_schema()

            # Handle truncate flag (delete all rows from table)
            if self.truncate:
                print(f'CopyTo: Truncating table {self.schema}.{self.tablename}')
                await self._truncate_table()

            # Handle delete_before_insert flag (delete only matching PK rows)
            if self.delete_before_insert and self.pk:
                print(f'CopyTo: Deleting existing rows matching PK values')
                await self._delete_existing_rows(column_types)

            # Clean NA/NaT values from string fields
            str_cols = self.data.select_dtypes(include=["string"])
            if not str_cols.empty:
                self.data[str_cols.columns] = str_cols.astype(object).where(
                    pd.notnull(str_cols), None
                )

            # Convert DataFrame columns to match BigQuery schema
            if column_types:
                # Debug: show DataFrame types vs BigQuery types
                print("=== DataFrame to BigQuery Type Conversion ===")
                for col in self.data.columns:
                    df_type = str(self.data[col].dtype)
                    bq_type = column_types.get(col, "NOT IN SCHEMA")
                    if bq_type != "NOT IN SCHEMA" and col in self.pk:
                        print(f"  PK {col}: DataFrame={df_type} → BigQuery={bq_type}")
                    elif bq_type != "NOT IN SCHEMA":
                        print(f"     {col}: DataFrame={df_type} → BigQuery={bq_type}")

                self.data = self._convert_dataframe_to_bigquery_types(self.data, column_types)

                # Debug: show types after conversion
                print("=== After Conversion ===")
                for col in self.pk:
                    if col in self.data.columns:
                        print(f"  PK {col}: {str(self.data[col].dtype)} - Sample: {self.data[col].iloc[0]}")

            # Clean datetime fields (fallback if no schema info)
            # Note: Only using "datetime64" as pandas doesn't accept specific frequencies like [s] or [ns]
            try:
                datetime_cols = self.data.select_dtypes(include=["datetime64"])
                if not datetime_cols.empty:
                    for col in datetime_cols.columns:
                        if col not in column_types:  # Only if we don't have schema info
                            self.data[col] = self.data[col].dt.tz_localize(None)
            except Exception as e:
                print(f"CopyTo: Warning - could not clean datetime fields: {e}")

            # Route to JSON loader if we have RECORD columns OR JSON columns
            json_columns = set()
            if column_types:
                json_columns = {col for col, dtype in column_types.items() if dtype == "JSON"}

            if self._record_columns or json_columns:
                if json_columns:
                    print(f'CopyTo: Detected {len(json_columns)} JSON columns, using NDJSON loader')
                await self._copy_with_json_loader(json_columns, column_types)
                return

            async with await self._connection.connection() as conn:
                result = await conn.write(
                    data=self.data,
                    table_id=self.tablename,
                    dataset_id=self.schema,
                    use_pandas=True,
                    if_exists="append"
                )
                print('CopyTo: ', result)

                # Verify insertion
                count_q = f"SELECT COUNT(*) as count FROM `{self.schema}.{self.tablename}`"
                count_result, count_error = await conn.query(count_q)
                if count_result:
                    # Convert RowIterator to list
                    rows = list(count_result) if hasattr(count_result, '__iter__') else count_result
                    if rows and len(rows) > 0:
                        print(f'CopyTo: Rows in table after INSERT: {rows[0].get("count", "unknown")}')
                elif count_error:
                    print(f'CopyTo: Error verifying row count: {count_error}')
        except StatementError as err:
            raise ComponentError(f"Statement error: {err}") from err
        except DataError as err:
            raise ComponentError(f"Data error: {err}") from err
        except Exception as err:
            raise ComponentError(f"{self.StepName} Error: {err!s}") from err

    async def _copy_iterable(self):
        """Copy an iterable to BigQuery."""
        try:
            async with await self._connection.connection() as conn:
                await conn.write(
                    data=self.data,
                    table_id=self.tablename,
                    dataset_id=self.schema,
                    use_pandas=False,
                    if_exists="append",
                    batch_size=self._chunksize
                )
        except Exception as err:
            raise ComponentError(
                f"Error copying iterable to BigQuery: {err}"
            ) from err
