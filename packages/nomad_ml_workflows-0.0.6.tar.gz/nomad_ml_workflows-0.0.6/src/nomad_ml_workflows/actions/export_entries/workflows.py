from datetime import timedelta

from temporalio import workflow
from temporalio.common import RetryPolicy
from temporalio.exceptions import ApplicationError

with workflow.unsafe.imports_passed_through():
    from nomad.config import config as nomad_config

    from nomad_ml_workflows.actions.export_entries.activities import (
        cleanup_artifacts,
        create_artifact_subdirectory,
        export_dataset_to_upload,
        merge_output_files,
        search,
    )
    from nomad_ml_workflows.actions.export_entries.models import (
        CleanupArtifactsInput,
        CreateArtifactSubdirectoryInput,
        ExportDatasetInput,
        ExportDatasetMetadata,
        ExportEntriesUserInput,
        MergeOutputFilesInput,
        SearchInput,
    )


@workflow.defn
class ExportEntriesWorkflow:
    @workflow.run
    async def run(self, data: ExportEntriesUserInput) -> str:
        """
        Workflow to search entries and export them into a datafile in the specified
        upload.

        Args:
            data (ExportEntriesUserInput): Input data for the export entries workflow.
        Returns:
            str: Path to the saved dataset in the upload's `raw` folder.
        """
        retry_policy = RetryPolicy(
            maximum_attempts=1,
            initial_interval=timedelta(seconds=10),
            maximum_interval=timedelta(minutes=1),
            backoff_coefficient=2.0,
        )
        artifact_subdirectory = await workflow.execute_activity(
            create_artifact_subdirectory,
            CreateArtifactSubdirectoryInput(subdir_name=workflow.info().workflow_id),
            start_to_close_timeout=timedelta(minutes=10),
            retry_policy=retry_policy,
        )
        export_dataset_input = ExportDatasetInput(
            user_id=data.user_id,
            upload_id=data.upload_id,
            artifact_subdirectory=artifact_subdirectory,
            exportable_dir_name='export_entries_error',  # name used in case of error
            zip_output=data.output_settings.zip_output,
            source_paths=[],
            metadata=ExportDatasetMetadata(user_input=data),
        )

        try:
            config = nomad_config.get_plugin_entry_point(
                'nomad_ml_workflows.actions:export_entries'
            )

            search_counter = 0
            num_entries_available = 0
            generated_file_paths = []
            search_start_times = []
            search_end_times = []
            total_num_entries_exported = 0
            reached_max_entries_limit = False
            search_input = SearchInput.from_user_input(
                data,
                output_file_path='',  # Placeholder, will be set in loop
                max_entries_export_limit=config.max_entries_export_limit,
            )
            while True:
                search_counter += 1
                search_input.output_file_path = (
                    f'{artifact_subdirectory}/{search_counter}.'
                    f'{search_input.batch_file_type}'
                )
                search_output = await workflow.execute_activity(
                    search,
                    search_input,
                    activity_id=f'search-activity-{search_counter}',
                    start_to_close_timeout=timedelta(
                        seconds=config.search_batch_timeout
                    ),
                    retry_policy=retry_policy,
                )
                if search_counter == 1:
                    # capture the total available entries from the first search output
                    num_entries_available = search_output.num_entries_available
                if search_output.num_entries_exported > 0:
                    # only save paths if the writing files was not skipped
                    generated_file_paths.append(search_input.output_file_path)
                search_start_times.append(search_output.search_start_time)
                search_end_times.append(search_output.search_end_time)
                total_num_entries_exported += search_output.num_entries_exported
                # Update pagination for next iteration
                search_input.pagination.page_after_value = (
                    search_output.pagination_next_page_after_value
                )
                search_input.max_entries_export_limit -= (
                    search_output.num_entries_exported
                )

                if search_output.pagination_next_page_after_value is None:
                    # break if there are no more pages to fetch
                    break
                if search_input.max_entries_export_limit <= 0:
                    # break early if the max entries limit has been reached
                    reached_max_entries_limit = True
                    break

            merged_file_path = await workflow.execute_activity(
                merge_output_files,
                MergeOutputFilesInput(
                    artifact_subdirectory=artifact_subdirectory,
                    output_file_type=data.output_settings.output_file_type,
                    generated_file_paths=generated_file_paths,
                ),
                start_to_close_timeout=timedelta(hours=2),
                retry_policy=retry_policy,
            )

            # Prepare export dataset input and metadata
            export_dataset_input.exportable_dir_name = (
                'export_entries_' + search_start_times[0].replace(':', '-')
            )
            export_dataset_input.source_paths = [merged_file_path]
            export_dataset_input.metadata = ExportDatasetMetadata(
                num_entries_exported=total_num_entries_exported,
                num_entries_available=num_entries_available,
                reached_max_entries_limit=reached_max_entries_limit,
                search_start_time=search_start_times[0],
                search_end_time=search_end_times[-1],
                user_input=data,
            )

        except Exception as e:
            # Capture error info to include in metadata
            import traceback

            export_dataset_input.metadata.error_info = traceback.format_exc()
            raise ApplicationError(
                'Encountered an error during export entries workflow.',
            ) from e

        finally:
            saved_dataset_path = await workflow.execute_activity(
                export_dataset_to_upload,
                export_dataset_input,
                start_to_close_timeout=timedelta(hours=2),
                retry_policy=retry_policy,
            )

            await workflow.execute_activity(
                cleanup_artifacts,
                CleanupArtifactsInput(subdir_path=artifact_subdirectory),
                start_to_close_timeout=timedelta(hours=2),
                retry_policy=retry_policy,
            )

        return saved_dataset_path
