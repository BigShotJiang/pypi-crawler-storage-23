import json
from typing import Literal

from nomad.app.v1.models.models import MetadataPagination, MetadataRequired, Query
from pydantic import BaseModel, Field

OwnerLiteral = Literal['public', 'visible', 'shared', 'user', 'staging']
BatchFileTypeLiteral = Literal['parquet', 'json']
OutputFileTypeLiteral = Literal['parquet', 'csv', 'json']
IndexLiteral = Literal['entries', 'datasets', 'models', 'spaces']


class SearchSettings(BaseModel):
    owner: OwnerLiteral = Field(
        'visible', description='Owner of the entries to be searched.'
    )
    query: str = Field(
        ...,
        description="""Query for extracting entries. Should be a valid dictionary
        string. For example:
        {
            'entry_type': 'ELNSample'
        }""",
        # TODO: add `ui:widget` though `json_schema_extra` after NOMAD UI supports it
    )
    required_include: list[str] = Field(
        None,
        description='List of fields to include in the search results. For example: '
        'results*, data.results*',
    )
    required_exclude: list[str] = Field(
        None,
        description='List of fields to exclude from the search results. For example: '
        'results.method.method_name',
    )


class OutputSettings(BaseModel):
    output_file_type: OutputFileTypeLiteral = Field(
        'parquet',
        description='Type of the output file.',
    )
    batch_size: int = Field(
        1000,
        gt=0,
        description='Number of entries to be fetched and written per search batch. '
        'Use smaller batch sizes when exporting large entries to reduce memory usage.',
    )
    zip_output: bool = Field(
        True,
        description='Whether to create a zip file for the output file(s). Set it '
        'to true if you want download the dataset for external use. If you want to '
        'work with the exported data in NOMAD, set it to false. This will export the '
        'dataset as a directory in the specified project.',
    )


class ExportEntriesUserInput(BaseModel):
    upload_id: str = Field(
        ...,
        description='Unique identifier for the upload associated with the workflow.',
    )
    user_id: str = Field(
        ..., description='Unique identifier for the user who initiated the workflow.'
    )
    search_settings: SearchSettings
    output_settings: OutputSettings


class CreateArtifactSubdirectoryInput(BaseModel):
    subdir_name: str = Field(..., description='Name of the subdirectory to be created.')


class SearchInput(BaseModel):
    user_id: str = Field(..., description='User ID performing the search.')
    owner: OwnerLiteral = Field(..., description='Owner of the entries to be searched.')
    query: Query = Field(..., description='Search query parameters.')
    required: MetadataRequired = Field(
        ..., description='Required fields for filtering the search results.'
    )
    pagination: MetadataPagination = Field(
        ..., description='Pagination settings for the search results.'
    )
    batch_file_type: BatchFileTypeLiteral = Field(
        ..., description='Type of the output file.'
    )
    output_file_path: str = Field(..., description='Path to the generated output file.')
    max_entries_export_limit: int = Field(
        ..., description='Maximum number of entries to be exported.'
    )

    @classmethod
    def from_user_input(
        cls,
        user_input: ExportEntriesUserInput,
        /,
        output_file_path: str,
        max_entries_export_limit: int,
    ) -> 'SearchInput':
        """Convert from ExportEntriesUserInput to SearchInput"""

        def _clean_field(field: str) -> str:
            """
            Removes trailing whitespaces and inverted commas
            """
            return field.strip().strip("'").strip('"')

        query = json.loads(
            _clean_field(user_input.search_settings.query).replace("'", '"')
        )

        required = MetadataRequired()
        if user_input.search_settings.required_include is not None:
            include = [
                _clean_field(field)
                for field in user_input.search_settings.required_include
            ]
            required.include = include if include else None
        if user_input.search_settings.required_exclude:
            exclude = [
                _clean_field(field)
                for field in user_input.search_settings.required_exclude
            ]
            required.exclude = exclude if exclude else None

        pagination = MetadataPagination(page_size=user_input.output_settings.batch_size)

        batch_file_type = user_input.output_settings.output_file_type
        if batch_file_type == 'csv':
            batch_file_type = 'parquet'  # use parquet batches for csv

        return cls(
            user_id=user_input.user_id,
            owner=user_input.search_settings.owner,
            query=query,
            required=required,
            pagination=pagination,
            batch_file_type=batch_file_type,
            output_file_path=output_file_path,
            max_entries_export_limit=max_entries_export_limit,
        )


class SearchOutput(BaseModel):
    num_entries_exported: int = Field(
        ..., description='Number of entries exported to the output file.'
    )
    num_entries_available: int = Field(
        ...,
        description='Total number of entries available for the given search query.',
    )
    search_start_time: str = Field(
        ..., description='Timestamp when the search started.'
    )
    search_end_time: str = Field(
        ..., description='Timestamp when the search completed.'
    )
    pagination_next_page_after_value: str | None = Field(
        None,
        description='The next_page_after_value from pagination, if more results are '
        'available.',
    )


class MergeOutputFilesInput(BaseModel):
    artifact_subdirectory: str = Field(
        ...,
        description='Subdirectory where the merged output file will be stored.',
    )
    output_file_type: OutputFileTypeLiteral = Field(
        ...,
        description='Type of the output file.',
    )
    generated_file_paths: list[str] = Field(
        ...,
        description='List of the generated file paths to be merged into a single file.',
    )


class ExportDatasetMetadata(BaseModel):
    num_entries_exported: int = Field(
        0,
        description='Total number of entries exported in all the exported dataset '
        'batches.',
    )
    num_entries_available: int = Field(
        0,
        description='Total number of entries available for the given search query.',
    )
    reached_max_entries_limit: bool = Field(
        False,
        description='Indicates whether the export reached the maximum number of '
        'entries allowed. If true, the exported dataset contains the first N entries '
        'up to the maximum limit.',
    )
    search_start_time: str = Field(
        '',
        description='Timestamp when the first search batch started.',
    )
    search_end_time: str = Field(
        '',
        description='Timestamp when the last search batch completed.',
    )
    user_input: ExportEntriesUserInput | None = Field(
        None, description='Original user input for the export entries workflow.'
    )
    error_info: str | None = Field(
        None,
        description='Error information if any error occurred during the search and '
        'merging process.',
    )


class ExportDatasetInput(BaseModel):
    user_id: str = Field(
        ..., description='User ID performing the export dataset operation.'
    )
    upload_id: str = Field(
        ..., description='Upload ID associated with the export dataset operation.'
    )
    artifact_subdirectory: str = Field(
        ...,
        description='Subdirectory where the exported dataset zip file will be stored.',
    )
    zip_output: bool = Field(
        ...,
        description='Whether to create a zip file for the exported dataset.',
    )
    exportable_dir_name: str = Field(
        ...,
        description='Name of the directory containing the dataset that will be '
        'exported.',
    )
    source_paths: list[str] = Field(
        ..., description='List of paths to the source files of the dataset.'
    )
    metadata: ExportDatasetMetadata = Field(
        ..., description='Metadata associated with the exported dataset.'
    )


class CleanupArtifactsInput(BaseModel):
    subdir_path: str = Field(
        ..., description='Path to the subdirectory to be cleaned up.'
    )
