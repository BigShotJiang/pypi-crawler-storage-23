"""Streaming interfaces and tick normalization utilities."""
