"""Zerodha adapter package."""
