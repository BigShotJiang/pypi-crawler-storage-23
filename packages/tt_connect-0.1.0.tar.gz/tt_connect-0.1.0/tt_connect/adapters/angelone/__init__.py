"""AngelOne adapter package."""
