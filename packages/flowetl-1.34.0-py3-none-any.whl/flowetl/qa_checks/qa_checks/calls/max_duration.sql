SELECT
    max(duration)
FROM
    {{ final_table }}
