# Copyright (c) 2025 格律至微
# SPDX-License-Identifier: AGPL-3.0-only

from .agent_config import Config

__all__ = [
    "Config",
]
