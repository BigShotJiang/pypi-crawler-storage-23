from .core import (
    get_all_desktops as get_all_desktops,
    get_current_desktop as get_current_desktop,
    is_window_on_current_desktop as is_window_on_current_desktop,
)
