"""Action system for TAPDB."""

from daylily_tapdb.actions.dispatcher import ActionDispatcher

__all__ = ["ActionDispatcher"]
