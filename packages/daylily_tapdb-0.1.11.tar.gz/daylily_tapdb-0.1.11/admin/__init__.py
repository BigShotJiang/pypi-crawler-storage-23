"""
TAPDB Admin Application.

FastAPI-based admin interface for managing TAPDB objects.
"""
__version__ = "0.1.0"

