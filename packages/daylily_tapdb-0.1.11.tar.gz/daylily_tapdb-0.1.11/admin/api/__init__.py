"""TAPDB Admin API endpoints."""

