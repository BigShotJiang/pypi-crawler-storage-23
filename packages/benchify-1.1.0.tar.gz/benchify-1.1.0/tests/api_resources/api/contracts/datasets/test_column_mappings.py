# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from formalize import Formalize, AsyncFormalize
from tests.utils import assert_matches_type

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestColumnMappings:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_retrieve_column_mappings(self, client: Formalize) -> None:
        column_mapping = client.api.contracts.datasets.column_mappings.retrieve_column_mappings(
            dataset_id="dataset_id",
            contract_id="contract_id",
        )
        assert_matches_type(object, column_mapping, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_retrieve_column_mappings(self, client: Formalize) -> None:
        response = client.api.contracts.datasets.column_mappings.with_raw_response.retrieve_column_mappings(
            dataset_id="dataset_id",
            contract_id="contract_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        column_mapping = response.parse()
        assert_matches_type(object, column_mapping, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_retrieve_column_mappings(self, client: Formalize) -> None:
        with client.api.contracts.datasets.column_mappings.with_streaming_response.retrieve_column_mappings(
            dataset_id="dataset_id",
            contract_id="contract_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            column_mapping = response.parse()
            assert_matches_type(object, column_mapping, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_retrieve_column_mappings(self, client: Formalize) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `contract_id` but received ''"):
            client.api.contracts.datasets.column_mappings.with_raw_response.retrieve_column_mappings(
                dataset_id="dataset_id",
                contract_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `dataset_id` but received ''"):
            client.api.contracts.datasets.column_mappings.with_raw_response.retrieve_column_mappings(
                dataset_id="",
                contract_id="contract_id",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_column_mappings(self, client: Formalize) -> None:
        column_mapping = client.api.contracts.datasets.column_mappings.update_column_mappings(
            dataset_id="dataset_id",
            contract_id="contract_id",
            mappings={"foo": "string"},
        )
        assert_matches_type(object, column_mapping, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update_column_mappings(self, client: Formalize) -> None:
        response = client.api.contracts.datasets.column_mappings.with_raw_response.update_column_mappings(
            dataset_id="dataset_id",
            contract_id="contract_id",
            mappings={"foo": "string"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        column_mapping = response.parse()
        assert_matches_type(object, column_mapping, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update_column_mappings(self, client: Formalize) -> None:
        with client.api.contracts.datasets.column_mappings.with_streaming_response.update_column_mappings(
            dataset_id="dataset_id",
            contract_id="contract_id",
            mappings={"foo": "string"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            column_mapping = response.parse()
            assert_matches_type(object, column_mapping, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_path_params_update_column_mappings(self, client: Formalize) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `contract_id` but received ''"):
            client.api.contracts.datasets.column_mappings.with_raw_response.update_column_mappings(
                dataset_id="dataset_id",
                contract_id="",
                mappings={"foo": "string"},
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `dataset_id` but received ''"):
            client.api.contracts.datasets.column_mappings.with_raw_response.update_column_mappings(
                dataset_id="",
                contract_id="contract_id",
                mappings={"foo": "string"},
            )


class TestAsyncColumnMappings:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_retrieve_column_mappings(self, async_client: AsyncFormalize) -> None:
        column_mapping = await async_client.api.contracts.datasets.column_mappings.retrieve_column_mappings(
            dataset_id="dataset_id",
            contract_id="contract_id",
        )
        assert_matches_type(object, column_mapping, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_retrieve_column_mappings(self, async_client: AsyncFormalize) -> None:
        response = await async_client.api.contracts.datasets.column_mappings.with_raw_response.retrieve_column_mappings(
            dataset_id="dataset_id",
            contract_id="contract_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        column_mapping = await response.parse()
        assert_matches_type(object, column_mapping, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve_column_mappings(self, async_client: AsyncFormalize) -> None:
        async with async_client.api.contracts.datasets.column_mappings.with_streaming_response.retrieve_column_mappings(
            dataset_id="dataset_id",
            contract_id="contract_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            column_mapping = await response.parse()
            assert_matches_type(object, column_mapping, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_retrieve_column_mappings(self, async_client: AsyncFormalize) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `contract_id` but received ''"):
            await async_client.api.contracts.datasets.column_mappings.with_raw_response.retrieve_column_mappings(
                dataset_id="dataset_id",
                contract_id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `dataset_id` but received ''"):
            await async_client.api.contracts.datasets.column_mappings.with_raw_response.retrieve_column_mappings(
                dataset_id="",
                contract_id="contract_id",
            )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_column_mappings(self, async_client: AsyncFormalize) -> None:
        column_mapping = await async_client.api.contracts.datasets.column_mappings.update_column_mappings(
            dataset_id="dataset_id",
            contract_id="contract_id",
            mappings={"foo": "string"},
        )
        assert_matches_type(object, column_mapping, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update_column_mappings(self, async_client: AsyncFormalize) -> None:
        response = await async_client.api.contracts.datasets.column_mappings.with_raw_response.update_column_mappings(
            dataset_id="dataset_id",
            contract_id="contract_id",
            mappings={"foo": "string"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        column_mapping = await response.parse()
        assert_matches_type(object, column_mapping, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update_column_mappings(self, async_client: AsyncFormalize) -> None:
        async with async_client.api.contracts.datasets.column_mappings.with_streaming_response.update_column_mappings(
            dataset_id="dataset_id",
            contract_id="contract_id",
            mappings={"foo": "string"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            column_mapping = await response.parse()
            assert_matches_type(object, column_mapping, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_path_params_update_column_mappings(self, async_client: AsyncFormalize) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `contract_id` but received ''"):
            await async_client.api.contracts.datasets.column_mappings.with_raw_response.update_column_mappings(
                dataset_id="dataset_id",
                contract_id="",
                mappings={"foo": "string"},
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `dataset_id` but received ''"):
            await async_client.api.contracts.datasets.column_mappings.with_raw_response.update_column_mappings(
                dataset_id="",
                contract_id="contract_id",
                mappings={"foo": "string"},
            )
