"""
WEAC - Weak Layer Anticrack Nucleation Model
"""

__version__ = "3.1.4"
