"""Sandboxed code execution for programmatic attack enhancement.

Runs Python code in an isolated subprocess with:
- Module whitelist (only safe string/encoding modules)
- Static analysis blocking dangerous patterns
- Hard timeout enforcement
- Output size capping

Also supports interactive mode where sandbox code can send messages
to the target via a controlled IPC protocol (stdin/stdout JSON).
"""

import ast
import asyncio
import json
import sys
import time
from typing import Any, Callable, ClassVar, List, Optional, Tuple

from pydantic import BaseModel

from .logging import get_logger

logger = get_logger(__name__)


class InteractionEntry(BaseModel):
    """Single send/receive exchange in an interactive sandbox run."""

    message_sent: str
    response_received: str
    round_index: int


class SandboxResult(BaseModel):
    """Result of sandboxed code execution."""

    success: bool
    output: str
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    truncated: bool = False
    interaction_log: List[InteractionEntry] = []


class CodeSandbox:
    """Execute Python code in an isolated subprocess with strict restrictions."""

    ALLOWED_MODULES: ClassVar[set] = {
        "base64",
        "codecs",
        "hashlib",
        "string",
        "random",
        "re",
        "json",
        "math",
        "urllib.parse",
        "html",
        "unicodedata",
        "itertools",
        "collections",
        "textwrap",
        "binascii",
    }

    BLOCKED_PATTERNS: ClassVar[list] = [
        "__import__",
        "globals(",
        "locals(",
        "getattr(",
        "setattr(",
        "delattr(",
        "compile(",
        "breakpoint(",
        "__builtins__",
        "__subclasses__",
    ]

    def __init__(
        self,
        timeout_seconds: int = 10,
        max_output_bytes: int = 50_000,
    ):
        self.timeout_seconds = timeout_seconds
        self.max_output_bytes = max_output_bytes

    def validate_code(self, code: str) -> Tuple[bool, Optional[str]]:
        """Static analysis: AST-walk to check imports and blocked calls.

        Returns:
            (is_valid, error_message) tuple.
        """
        for pattern in self.BLOCKED_PATTERNS:
            if pattern in code:
                return False, f"Blocked pattern found: {pattern}"

        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return False, f"Syntax error: {e}"

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    full_name = alias.name
                    root_module = full_name.split(".")[0]
                    if (
                        full_name not in self.ALLOWED_MODULES
                        and root_module not in self.ALLOWED_MODULES
                    ):
                        return False, f"Import not allowed: {full_name}"

            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    full_name = node.module
                    root_module = full_name.split(".")[0]
                    if (
                        full_name not in self.ALLOWED_MODULES
                        and root_module not in self.ALLOWED_MODULES
                    ):
                        return False, f"Import not allowed: {full_name}"

            elif isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name) and func.id in (
                    "open",
                    "exec",
                    "eval",
                    "input",
                    "exit",
                    "quit",
                ):
                    return False, f"Blocked builtin call: {func.id}()"

        return True, None

    async def execute(self, code: str) -> SandboxResult:
        """Run code in a subprocess with timeout and output capture.

        The code's stdout is captured as the result. The subprocess
        inherits a minimal environment stripped of credentials.
        """
        is_valid, error = self.validate_code(code)
        if not is_valid:
            return SandboxResult(success=False, output="", error=error)

        # Wrap user code so stdout is captured and errors are reported
        wrapper = (
            "import sys\n" "sys.path = [p for p in sys.path if 'site-packages' not in p]\n" "try:\n"
        )
        for line in code.splitlines():
            wrapper += f"    {line}\n"
        wrapper += "except Exception as _e:\n" "    sys.stderr.write(str(_e))\n" "    sys.exit(1)\n"

        start = time.monotonic()

        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable,
                "-c",
                wrapper,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env={},  # stripped environment — no credentials
            )

            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(),
                    timeout=self.timeout_seconds,
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                elapsed = (time.monotonic() - start) * 1000
                return SandboxResult(
                    success=False,
                    output="",
                    error=f"Execution timed out after {self.timeout_seconds}s",
                    execution_time_ms=elapsed,
                )

            elapsed = (time.monotonic() - start) * 1000
            stdout = stdout_bytes.decode("utf-8", errors="replace")
            stderr = stderr_bytes.decode("utf-8", errors="replace")

            truncated = False
            if len(stdout) > self.max_output_bytes:
                stdout = stdout[: self.max_output_bytes]
                truncated = True

            if proc.returncode != 0:
                return SandboxResult(
                    success=False,
                    output=stdout,
                    error=stderr or f"Process exited with code {proc.returncode}",
                    execution_time_ms=elapsed,
                    truncated=truncated,
                )

            return SandboxResult(
                success=True,
                output=stdout.strip(),
                error=None,
                execution_time_ms=elapsed,
                truncated=truncated,
            )

        except Exception as e:
            elapsed = (time.monotonic() - start) * 1000
            return SandboxResult(
                success=False,
                output="",
                error=f"Sandbox error: {e}",
                execution_time_ms=elapsed,
            )

    # ------------------------------------------------------------------
    # Interactive execution (bidirectional IPC)
    # ------------------------------------------------------------------

    _SEND_HARNESS = (
        "import sys as _sys, json as _json\n"
        "def send(message):\n"
        '    _sys.stdout.write(_json.dumps({"action":"send","message":str(message)}) + "\\n")\n'
        "    _sys.stdout.flush()\n"
        "    _line = _sys.stdin.readline()\n"
        "    if not _line:\n"
        '        raise RuntimeError("Parent closed stdin")\n'
        '    return _json.loads(_line)["response"]\n'
    )

    async def execute_interactive(
        self,
        code: str,
        send_handler: Callable[[str], Any],
        max_messages: int = 10,
    ) -> SandboxResult:
        """Run code with bidirectional IPC for target interaction.

        The subprocess gets an injected ``send(message)`` function that
        routes messages through *send_handler* (typically the target
        connector's ``send_message``).  Communication uses a JSON
        protocol over stdin/stdout; the subprocess never touches the
        network directly.

        Args:
            code: User (LLM-generated) code to execute.
            send_handler: Async callable that accepts a message string
                and returns the target's response string.
            max_messages: Hard cap on ``send()`` calls per run.

        Returns:
            SandboxResult with interaction_log populated.
        """
        is_valid, error = self.validate_code(code)
        if not is_valid:
            return SandboxResult(success=False, output="", error=error)

        wrapper = self._build_interactive_wrapper(code)
        start = time.monotonic()
        interaction_log: List[InteractionEntry] = []

        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable,
                "-c",
                wrapper,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env={},
            )

            collected_output: list[str] = []
            messages_sent = 0

            try:
                while True:
                    remaining = self.timeout_seconds - (time.monotonic() - start)
                    if remaining <= 0:
                        raise asyncio.TimeoutError()

                    line_bytes = await asyncio.wait_for(
                        proc.stdout.readline(),
                        timeout=min(remaining, 30),
                    )

                    if not line_bytes:
                        break

                    line = line_bytes.decode("utf-8", errors="replace").strip()
                    if not line:
                        continue

                    try:
                        cmd = json.loads(line)
                    except (json.JSONDecodeError, ValueError):
                        collected_output.append(line)
                        continue

                    if not isinstance(cmd, dict):
                        collected_output.append(line)
                        continue

                    action = cmd.get("action")

                    if action == "send":
                        if messages_sent >= max_messages:
                            reply = json.dumps(
                                {"response": f"[SANDBOX] Message limit ({max_messages}) reached"}
                            )
                            proc.stdin.write(reply.encode() + b"\n")
                            await proc.stdin.drain()
                            continue

                        msg = str(cmd.get("message", ""))
                        try:
                            resp = await send_handler(msg)
                            resp_str = resp if isinstance(resp, str) else str(resp)
                        except Exception as exc:
                            resp_str = f"[ERROR] {exc}"

                        interaction_log.append(
                            InteractionEntry(
                                message_sent=msg,
                                response_received=resp_str,
                                round_index=messages_sent,
                            )
                        )
                        messages_sent += 1

                        reply = json.dumps({"response": resp_str})
                        proc.stdin.write(reply.encode() + b"\n")
                        await proc.stdin.drain()

                    elif action == "done":
                        result_text = cmd.get("result", "")
                        if result_text:
                            collected_output.append(result_text)
                        break

                    elif action == "finding":
                        collected_output.append(f"FINDING: {json.dumps(cmd.get('data', {}))}")

                    else:
                        collected_output.append(line)

            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                elapsed = (time.monotonic() - start) * 1000
                return SandboxResult(
                    success=False,
                    output="\n".join(collected_output),
                    error=f"Interactive execution timed out after {self.timeout_seconds}s",
                    execution_time_ms=elapsed,
                    interaction_log=interaction_log,
                )

            if proc.stdin and not proc.stdin.is_closing():
                proc.stdin.close()

            stderr_bytes = await proc.stderr.read()
            await proc.wait()

            elapsed = (time.monotonic() - start) * 1000
            stderr = stderr_bytes.decode("utf-8", errors="replace")
            output = "\n".join(collected_output)

            if len(output) > self.max_output_bytes:
                output = output[: self.max_output_bytes]

            if proc.returncode != 0 and not interaction_log:
                return SandboxResult(
                    success=False,
                    output=output,
                    error=stderr or f"Process exited with code {proc.returncode}",
                    execution_time_ms=elapsed,
                    interaction_log=interaction_log,
                )

            return SandboxResult(
                success=True,
                output=output.strip(),
                error=None,
                execution_time_ms=elapsed,
                interaction_log=interaction_log,
            )

        except Exception as e:
            elapsed = (time.monotonic() - start) * 1000
            return SandboxResult(
                success=False,
                output="",
                error=f"Interactive sandbox error: {e}",
                execution_time_ms=elapsed,
                interaction_log=interaction_log,
            )

    def _build_interactive_wrapper(self, code: str) -> str:
        """Build the subprocess script with the send() harness injected."""
        wrapper = "import sys\n" "sys.path = [p for p in sys.path if 'site-packages' not in p]\n"
        wrapper += self._SEND_HARNESS
        wrapper += "try:\n"
        for line in code.splitlines():
            wrapper += f"    {line}\n"
        wrapper += "except Exception as _e:\n" "    sys.stderr.write(str(_e))\n" "    sys.exit(1)\n"
        return wrapper
