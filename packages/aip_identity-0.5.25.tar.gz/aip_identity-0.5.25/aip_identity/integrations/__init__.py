"""AIP integrations with popular agent frameworks (LangChain, CrewAI, etc.)."""
