# Makes cpgrpc a Python package for setuptools discovery.
