class InteractiveModel:
    def __init__(self):
        self.image = None
        self.masks = None
        self.params = {}
