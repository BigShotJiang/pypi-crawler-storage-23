# This file has been moved to guv_app/plugins/basic_stats.py
# Please update your imports.