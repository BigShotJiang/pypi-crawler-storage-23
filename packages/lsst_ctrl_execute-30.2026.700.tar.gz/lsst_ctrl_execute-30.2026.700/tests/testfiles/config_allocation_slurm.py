# flake8: noqa
config.platform.queue = "normal"
config.platform.scratchDirectory = "/tmp/$USER_NAME/test_scratch"
config.platform.loginHostName = "bighost.lsstcorp.org"
config.platform.utilityPath = "/bin"
