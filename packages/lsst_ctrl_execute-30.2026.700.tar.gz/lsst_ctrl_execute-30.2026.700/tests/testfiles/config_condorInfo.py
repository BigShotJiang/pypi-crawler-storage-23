# flake8: noqa
config.platform["test1"].user.name = "test1"
config.platform["test1"].user.home = "/home/test1"
config.platform["test2"].user.name = "test2"
config.platform["test2"].user.home = "/home/test2"
