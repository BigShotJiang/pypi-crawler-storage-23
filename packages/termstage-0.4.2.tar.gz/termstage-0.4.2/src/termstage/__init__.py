"""termstage — Generate polished terminal demo SVGs from YAML."""

__version__ = "0.4.2"
