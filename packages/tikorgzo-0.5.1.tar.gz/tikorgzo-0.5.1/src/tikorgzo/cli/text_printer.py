from rich.console import Console

console = Console(highlight=False)
