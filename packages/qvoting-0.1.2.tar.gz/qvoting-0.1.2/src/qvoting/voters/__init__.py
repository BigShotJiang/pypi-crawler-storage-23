# qvoting/voters
from qvoting.voters.majority import majority_voter

__all__ = ["majority_voter"]
