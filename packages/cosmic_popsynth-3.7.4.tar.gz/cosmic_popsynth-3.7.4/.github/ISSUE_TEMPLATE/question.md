---
name: Question
about: I want to ask a question about COSMIC
title: ''
labels: question
assignees: ''

---

Use this issue to ask any questions about how functions work, how best to use the package for your project or anything else you need help with! Wherever possible please include code examples to make it easier to help you!
