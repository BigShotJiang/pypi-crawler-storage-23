---
name: New physics prescription
about: I want to request/suggest a new physics prescription
title: ''
labels: new-prescription
assignees: ''

---

**Describe the new physics prescription you want to add**
TODO

**Link to the publication this is based on**
TODO

**Is this a new option for an existing flag? Or would require a new setting?**
TODO