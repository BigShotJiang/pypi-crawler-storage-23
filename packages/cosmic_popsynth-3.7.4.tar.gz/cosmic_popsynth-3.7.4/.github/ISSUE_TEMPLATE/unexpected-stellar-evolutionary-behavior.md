---
name: Unexpected Stellar Evolutionary Behavior
about: I want to report some weird evolutionary behavior and things tried to resolve that behavior for better history tracking.
title: ""
labels: Unexpected Evolutionary Behavior
assignees: ''

---

# Checklist
- [ ] Attached CSV file with initial conditions and BSE flags for reproducing this behavior
- [ ] Included code that produces the BPP/BCM arrays
- [ ] Written description of weird behavior
- [ ] Explained expected outcome
- [ ] Listed flags you have tried to turn on and off that you think relate to the evolutionary behavior
- [ ] Attached a plot if applicable

# CSV file 

Attach file with initC file here. You can save this like
```python
# create CSV file
initC.to_csv('weird_behavior.csv', index=False)

# now attach it to this issue!
```

# Code that produces the BPP and BCM arrays

```python
# your code here
```

# Description

Add a description of the weird behavior you've seen

# Expect outcome

How do you think this system _should_ evolve?

# Flags

Which flag have you tried to turn on and off that you think relate to the evolutionary behavior?

# Plot (if applicable)

Plot goes here