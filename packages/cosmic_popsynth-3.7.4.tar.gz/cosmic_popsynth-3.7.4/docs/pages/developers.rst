**************
For Developers
**************

This page is intended for developers who wish to contribute to the COSMIC codebase. If you are a user looking to install COSMIC, please refer to the `installation guide <install.html>`_.

.. toctree::
    :maxdepth: 1
    
    develop/how-it-works
    develop/new-settings
    develop/adding-options
    develop/debugging-vscode
    develop/settings-json-file