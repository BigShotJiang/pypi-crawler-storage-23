Impact of settings on evolution
===============================

This gallery shows examples of how different settings affect the evolution of binaries.

.. admonition:: Under construction
    :class: warning

    This page is still being developed, but will eventually contain examples of how all settings affect the evolution of binaries. For now it's just a few.