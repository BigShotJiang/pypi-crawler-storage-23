        include "int64.h"
        COMMON/Taus113Consts/ c, cseed
        integer(kind=int64) c(4), cseed
        SAVE /Taus113Consts/
