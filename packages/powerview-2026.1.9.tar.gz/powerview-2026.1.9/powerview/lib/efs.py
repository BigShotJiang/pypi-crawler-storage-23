#!/usr/bin/env python3
from impacket.uuid import uuidtup_to_bin

EFS_UUID = uuidtup_to_bin(('df1941c5-fe89-4e79-bf10-463657acf44d', '1.0'))
