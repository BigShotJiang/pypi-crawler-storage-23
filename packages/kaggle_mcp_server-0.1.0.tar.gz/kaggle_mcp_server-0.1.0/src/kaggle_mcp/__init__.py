"""Kaggle MCP Server - A full-featured MCP server wrapping the Kaggle API."""

__all__ = ["server"]
