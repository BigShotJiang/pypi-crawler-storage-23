#!/bin/sh

sudo systemctl enable ssh
sudo systemctl start ssh
