#!/bin/sh

echo "==> Installing uv (fast Python package manager)..."

curl -LsSf https://astral.sh/uv/install.sh | sh

echo "==> Done! uv installed."
