#!/bin/sh

./xschem.sh
./xschem130.sh
./ngspice.sh
./netgen.sh
