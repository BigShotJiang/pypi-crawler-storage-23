#!/bin/sh

cp klayoutrc  ~/.klayout/
