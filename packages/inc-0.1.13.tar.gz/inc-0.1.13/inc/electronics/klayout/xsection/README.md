# Xsection script

Based on CMOS

Installation:

- copy macros to ~/.klayout

References:

- [link to xsection](https://sourceforge.net/p/xsectionklayout/wiki/MainPage/)
