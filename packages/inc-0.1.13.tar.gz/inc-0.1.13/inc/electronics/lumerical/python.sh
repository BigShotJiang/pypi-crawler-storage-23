
pip install numpy scipy matplotlib
python -m ipykernel install --user --name myenv --display-name "py36"
