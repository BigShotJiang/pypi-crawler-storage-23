"""inc - install new computer"""

__version__ = "0.1.13"

from .app import app

__all__ = ["app"]
