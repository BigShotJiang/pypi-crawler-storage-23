#!/bin/bash

cp -r $HOME/.local/share/jupyter/kernels kernels_linux
