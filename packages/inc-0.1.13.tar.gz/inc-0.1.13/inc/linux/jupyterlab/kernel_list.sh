#!/bin/bash

less ~/.local/share/jupyter/kernels
jupyter kernelspec list
