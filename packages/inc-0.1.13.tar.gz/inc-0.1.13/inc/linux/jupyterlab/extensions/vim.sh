#!/bin/sh
# https://github.com/jwkvam/jupyterlab-vim

# jupyter labextension install jupyterlab_vim
jupyter labextension install @axlair/jupyterlab_vim
