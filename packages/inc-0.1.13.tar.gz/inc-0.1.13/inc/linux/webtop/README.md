

- https://github.com/techno-tim/techno-tim.github.io/blob/master/reference_files/webtop-container/docker-compose.yml
- video https://www.youtube.com/watch?v=Gd9bvdkIXOQ
- https://www.linuxserver.io/
