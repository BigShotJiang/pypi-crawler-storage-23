#!/bin/sh
# starship is a cross-shell

cargo install starship
