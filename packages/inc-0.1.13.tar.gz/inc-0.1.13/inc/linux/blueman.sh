# https://github.com/blueman-project/blueman

git clone https://github.com/blueman-project/blueman.git
cd blueman
./configure && make && make install
