#!/bin/sh

sudo cp arch/dwm.desktop /user/share/xsessions/
bash install arch.mk
