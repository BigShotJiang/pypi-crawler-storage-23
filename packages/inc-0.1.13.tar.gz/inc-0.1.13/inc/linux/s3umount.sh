#!/bin/bash

sudo umount ~/s3
