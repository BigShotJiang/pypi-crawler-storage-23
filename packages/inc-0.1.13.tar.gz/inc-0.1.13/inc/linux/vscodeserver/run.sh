
code-server --link
