#!/bin/bash
# requires python3 64 bits, make sure you install miniconda 3 and check add path during installation

conda install -y jupyterlab
