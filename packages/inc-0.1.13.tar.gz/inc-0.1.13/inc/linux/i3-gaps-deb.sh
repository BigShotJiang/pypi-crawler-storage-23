#!/bin/sh

git clone https://github.com/maestrogerardo/i3-gaps-deb.git
cd i3-gaps-deb
dpkg -i i3-gaps-deb
