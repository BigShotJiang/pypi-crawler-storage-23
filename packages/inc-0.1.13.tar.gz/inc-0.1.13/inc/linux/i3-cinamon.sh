#!/bin/sh

git clone https://github.com/jbbr/i3-cinnamon.git
cd i3-cinnamon
make install
