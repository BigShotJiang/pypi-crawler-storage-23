# Running apps inside Docker

- http://wiki.ros.org/docker/Tutorials/GUI
- https://medium.com/@SaravSun/running-gui-applications-inside-docker-containers-83d65c0db110
