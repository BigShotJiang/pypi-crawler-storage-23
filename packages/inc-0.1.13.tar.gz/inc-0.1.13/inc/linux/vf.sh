#!/bin/sh
# https://virtualfish.readthedocs.io/en/latest/install.html

pipx install virtualfish
vf install
vf addplugins global_requirements
