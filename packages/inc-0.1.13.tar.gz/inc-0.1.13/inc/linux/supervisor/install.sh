#!/bin/bash

sudo apt install supervisor
