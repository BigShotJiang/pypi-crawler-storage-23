#!/bin/sh
# ST is a lightweight terminal

git clone https://github.com/LukeSmithxyz/st st2
cd st2
sudo make install
