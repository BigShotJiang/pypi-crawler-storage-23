#!/bin/sh

sudo yum install -y git make
bash install centos.mk
