#!/bin/sh
# LukeSmith's arch setup script

curl -LO larbs.xyz/larbs.sh
sudo bash larbs.sh

bash install arch.mk
