#!/bin/sh
# https://docs.pi-hole.net/main/basic-install/

curl -sSL https://install.pi-hole.net | bash
