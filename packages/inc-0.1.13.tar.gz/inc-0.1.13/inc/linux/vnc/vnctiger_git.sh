#!/bin/bash
# Desc: Install TigerVNC from git

git clone https://github.com/TigerVNC/tigervnc.git
cd tigervnc
make install
