# Install

- `deploy` configures nginx and supervisorctl ensures devpi-server is always running

# Requirements

- needs nginx installed

References:

- https://github.com/jhermann/devpi-enterprisey/tree/master/debianized-devpi
- https://devpi.net/docs/devpi/devpi/stable/+doc/quickstart-server.html#quickstart-server
- http://supervisord.org/running.html
- supervisorctl config based on `echo_supervisord_conf >> supervisord.conf`
