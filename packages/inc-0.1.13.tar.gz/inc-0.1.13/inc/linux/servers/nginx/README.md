
nginx is a port forwarding

# References
- https://docs.nginx.com/nginx/admin-guide/web-server/serving-static-content/
- https://www.digitalocean.com/community/tutorials/how-to-serve-flask-applications-with-uwsgi-and-nginx-on-ubuntu-16-04
