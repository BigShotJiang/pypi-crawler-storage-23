

References:

- https://github.com/discourse/discourse/blob/master/docs/INSTALL-cloud.md#edit-discourse-configuration
- https://github.com/discourse/discourse/blob/master/docs/INSTALL-email.md
- https://meta.discourse.org/t/beginners-guide-to-install-discourse-on-ubuntu-for-development/14727
