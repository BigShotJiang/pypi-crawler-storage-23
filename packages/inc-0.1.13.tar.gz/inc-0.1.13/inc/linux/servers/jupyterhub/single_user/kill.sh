#!/bin/bash

sudo pkill jupyterhub
sudo pkill node
