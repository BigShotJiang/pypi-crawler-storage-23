#!/bin/bash

conda install notebook ipykernel
python2 -m pip install ipykernel --user
