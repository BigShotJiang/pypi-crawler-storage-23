#!/bin/bash

sh stop.sh
sh run.sh
