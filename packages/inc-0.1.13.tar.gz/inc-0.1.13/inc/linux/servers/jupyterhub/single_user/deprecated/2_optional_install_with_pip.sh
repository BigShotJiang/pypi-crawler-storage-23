#!/bin/bash

pip install jupyterhub
