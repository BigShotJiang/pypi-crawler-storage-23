#!/bin/bash
#  If containers already exist, don't recreate them.

docker-compose up -d --no-recreate
