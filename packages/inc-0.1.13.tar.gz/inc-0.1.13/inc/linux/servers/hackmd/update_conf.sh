#!/bin/bash

cp docker-compose.yml ~/docker-hackmd/
cd ~/hackmd-docker
docker-compose up -d
