

```
eksctl create cluster --name=eks --nodes=3 --alb-ingress-access --region=us-west-2
```


- https://docs.fluxcd.io/en/stable/
- https://eksworkshop.com/prerequisites/k8stools/
