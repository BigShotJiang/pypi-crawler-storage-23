flatpak install flathub im.riot.Riot
