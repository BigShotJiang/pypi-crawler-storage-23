#!/bin/sh
# https://github.com/samhal/cmus-sync.git

git clone https://github.com/samhal/cmus-sync.git
cp cmus-sync/cmus-sync ~/.local/bin/
