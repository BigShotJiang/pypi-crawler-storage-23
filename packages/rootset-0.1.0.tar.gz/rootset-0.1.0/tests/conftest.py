"""Shared test fixtures."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest
import pytest_asyncio

from rootset.storage.sqlite import SQLiteBackend


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture
async def tmp_db(tmp_path):
    db_path = tmp_path / "test.db"
    backend = SQLiteBackend(db_path)
    await backend.initialize(embedding_dimensions=4)
    yield backend
    await backend.close()


@pytest.fixture
def sample_python_file(tmp_path) -> Path:
    code = '''\
def hello(name: str) -> str:
    """Greet someone."""
    return f"Hello, {name}!"


def add(a: int, b: int) -> int:
    result = a + b
    return result


class Calculator:
    def multiply(self, x: int, y: int) -> int:
        return x * y

    def divide(self, x: float, y: float) -> float:
        return x / y
'''
    p = tmp_path / "sample.py"
    p.write_text(code)
    return p
