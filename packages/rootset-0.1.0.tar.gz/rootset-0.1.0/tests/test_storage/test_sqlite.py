"""Tests for SQLiteBackend."""

from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_upsert_and_get_file(tmp_db):
    file = await tmp_db.upsert_file("src/foo.py", "python", "abc123")
    assert file.id is not None
    assert file.path == "src/foo.py"
    assert file.language == "python"

    fetched = await tmp_db.get_file_by_path("src/foo.py")
    assert fetched is not None
    assert fetched.id == file.id
    assert fetched.content_hash == "abc123"


@pytest.mark.asyncio
async def test_upsert_file_updates_on_conflict(tmp_db):
    await tmp_db.upsert_file("src/foo.py", "python", "hash1")
    updated = await tmp_db.upsert_file("src/foo.py", "python", "hash2")
    assert updated.content_hash == "hash2"


@pytest.mark.asyncio
async def test_insert_and_get_symbols(tmp_db):
    file = await tmp_db.upsert_file("src/foo.py", "python", "abc")
    ids = await tmp_db.insert_symbols([
        {
            "file_id": file.id,
            "name": "hello",
            "qualified_name": "foo.hello",
            "kind": "function",
            "line_start": 1,
            "line_end": 3,
            "signature": "def hello(name: str) -> str:",
            "docstring": "Greet someone.",
            "content": "def hello(name: str) -> str:\n    return name",
        }
    ])
    assert len(ids) == 1

    syms = await tmp_db.get_symbols_by_file(file.id)
    assert len(syms) == 1
    assert syms[0].name == "hello"
    assert syms[0].qualified_name == "foo.hello"


@pytest.mark.asyncio
async def test_get_symbol_by_qname(tmp_db):
    file = await tmp_db.upsert_file("src/bar.py", "python", "def")
    await tmp_db.insert_symbols([
        {
            "file_id": file.id,
            "name": "bar",
            "qualified_name": "bar.bar",
            "kind": "function",
            "line_start": 1,
            "line_end": 2,
            "signature": "def bar():",
            "docstring": None,
            "content": "def bar(): pass",
        }
    ])
    sym = await tmp_db.get_symbol_by_qname("bar.bar")
    assert sym is not None
    assert sym.name == "bar"


@pytest.mark.asyncio
async def test_fts_search(tmp_db):
    file = await tmp_db.upsert_file("src/search_test.py", "python", "xyz")
    await tmp_db.insert_symbols([
        {
            "file_id": file.id,
            "name": "compute_graph",
            "qualified_name": "search_test.compute_graph",
            "kind": "function",
            "line_start": 1,
            "line_end": 5,
            "signature": "def compute_graph(nodes):",
            "docstring": "Build call graph from nodes.",
            "content": "def compute_graph(nodes): pass",
        },
        {
            "file_id": file.id,
            "name": "parse_tokens",
            "qualified_name": "search_test.parse_tokens",
            "kind": "function",
            "line_start": 7,
            "line_end": 10,
            "signature": "def parse_tokens(text):",
            "docstring": "Parse input tokens.",
            "content": "def parse_tokens(text): pass",
        },
    ])
    hits = await tmp_db.fts_search("graph", 10)
    assert len(hits) >= 1
    ids = [h[0] for h in hits]
    syms = await tmp_db.get_symbols_by_ids(ids)
    names = [s.name for s in syms]
    assert "compute_graph" in names


@pytest.mark.asyncio
async def test_get_counts(tmp_db):
    counts = await tmp_db.get_counts()
    assert "files" in counts
    assert "symbols" in counts


@pytest.mark.asyncio
async def test_insert_call_edges(tmp_db):
    file = await tmp_db.upsert_file("src/edges.py", "python", "e1")
    ids = await tmp_db.insert_symbols([
        {
            "file_id": file.id,
            "name": "caller",
            "qualified_name": "edges.caller",
            "kind": "function",
            "line_start": 1,
            "line_end": 3,
            "signature": "def caller():",
            "docstring": None,
            "content": "def caller(): callee()",
        },
    ])
    caller_id = ids[0]
    await tmp_db.insert_call_edges([
        {
            "caller_id": caller_id,
            "callee_name": "callee",
            "callee_id": None,
            "call_site_line": 2,
        }
    ])
    edges = await tmp_db.get_call_edges_for_symbol(caller_id)
    assert len(edges) == 1
    assert edges[0].callee_name == "callee"
