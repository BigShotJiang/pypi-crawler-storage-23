"""Tests for TextSearcher (FTS5)."""

from __future__ import annotations

import pytest

from rootset.search.text import TextSearcher


@pytest.mark.asyncio
async def test_text_search_returns_results(tmp_db):
    file = await tmp_db.upsert_file("src/text_test.py", "python", "t1")
    await tmp_db.insert_symbols([
        {
            "file_id": file.id,
            "name": "build_call_graph",
            "qualified_name": "text_test.build_call_graph",
            "kind": "function",
            "line_start": 1,
            "line_end": 5,
            "signature": "def build_call_graph(symbols):",
            "docstring": "Build a call graph from symbol list.",
            "content": "def build_call_graph(symbols): pass",
        },
    ])
    searcher = TextSearcher(tmp_db)
    results = await searcher.search("call graph", top_k=5)
    assert len(results) >= 1
    assert results[0].search_type == "text"
    assert results[0].symbol.name == "build_call_graph"


@pytest.mark.asyncio
async def test_text_search_no_match(tmp_db):
    searcher = TextSearcher(tmp_db)
    results = await searcher.search("xyznonexistentterm", top_k=5)
    assert results == []
