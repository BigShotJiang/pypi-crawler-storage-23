"""Tests for HybridSearcher RRF fusion."""

from __future__ import annotations

import pytest

from rootset.search.hybrid import HybridSearcher
from rootset.search.text import TextSearcher


@pytest.mark.asyncio
async def test_hybrid_fuses_single_searcher(tmp_db):
    file = await tmp_db.upsert_file("src/hybrid_test.py", "python", "h1")
    await tmp_db.insert_symbols([
        {
            "file_id": file.id,
            "name": "index_repository",
            "qualified_name": "hybrid_test.index_repository",
            "kind": "function",
            "line_start": 1,
            "line_end": 10,
            "signature": "def index_repository(path):",
            "docstring": "Index all files in a repository.",
            "content": "def index_repository(path): pass",
        },
    ])
    hybrid = HybridSearcher([TextSearcher(tmp_db)])
    results = await hybrid.search("index repository", top_k=5)
    assert len(results) >= 1
    assert results[0].search_type == "hybrid"


@pytest.mark.asyncio
async def test_hybrid_search_type_is_hybrid(tmp_db):
    file = await tmp_db.upsert_file("src/hybrid2.py", "python", "h2")
    await tmp_db.insert_symbols([
        {
            "file_id": file.id,
            "name": "rrf_fusion",
            "qualified_name": "hybrid2.rrf_fusion",
            "kind": "function",
            "line_start": 1,
            "line_end": 5,
            "signature": "def rrf_fusion(results):",
            "docstring": "Reciprocal rank fusion.",
            "content": "def rrf_fusion(results): pass",
        },
    ])
    hybrid = HybridSearcher([TextSearcher(tmp_db)])
    results = await hybrid.search("rrf fusion", top_k=5)
    for r in results:
        assert r.search_type == "hybrid"
