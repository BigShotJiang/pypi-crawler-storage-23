"""Tests for TreeSitterIndexer."""

from __future__ import annotations

import pytest

from rootset.indexing.treesitter import TreeSitterIndexer
from rootset.models import SymbolKind


@pytest.mark.asyncio
async def test_index_python_file(tmp_db, sample_python_file, tmp_path):
    file_record = await tmp_db.upsert_file(
        str(sample_python_file), "python", "hash1"
    )
    indexer = TreeSitterIndexer(tmp_db)
    await indexer.index_file(sample_python_file, file_record.id, "python")
    await indexer.close()

    symbols = await tmp_db.get_symbols_by_file(file_record.id)
    names = {s.name for s in symbols}
    assert "hello" in names
    assert "add" in names
    assert "Calculator" in names


@pytest.mark.asyncio
async def test_index_python_extracts_function_kind(tmp_db, sample_python_file):
    file_record = await tmp_db.upsert_file(
        str(sample_python_file), "python", "hash2"
    )
    indexer = TreeSitterIndexer(tmp_db)
    await indexer.index_file(sample_python_file, file_record.id, "python")
    await indexer.close()

    symbols = await tmp_db.get_symbols_by_file(file_record.id)
    by_name = {s.name: s for s in symbols}
    assert by_name["hello"].kind == SymbolKind.FUNCTION
    assert by_name["Calculator"].kind == SymbolKind.CLASS


@pytest.mark.asyncio
async def test_index_python_docstring(tmp_db, sample_python_file):
    file_record = await tmp_db.upsert_file(
        str(sample_python_file), "python", "hash3"
    )
    indexer = TreeSitterIndexer(tmp_db)
    await indexer.index_file(sample_python_file, file_record.id, "python")
    await indexer.close()

    symbols = await tmp_db.get_symbols_by_file(file_record.id)
    by_name = {s.name: s for s in symbols}
    assert by_name["hello"].docstring is not None
    assert "Greet" in by_name["hello"].docstring


@pytest.mark.asyncio
async def test_index_unsupported_language_raises(tmp_db, tmp_path):
    from rootset.exceptions import LanguageNotSupportedError
    p = tmp_path / "file.lua"
    p.write_text("-- lua code")
    file_record = await tmp_db.upsert_file(str(p), "lua", "h1")
    indexer = TreeSitterIndexer(tmp_db)
    with pytest.raises(LanguageNotSupportedError):
        await indexer.index_file(p, file_record.id, "lua")
    await indexer.close()
