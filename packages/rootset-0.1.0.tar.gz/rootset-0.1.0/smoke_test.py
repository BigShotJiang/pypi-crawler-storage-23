"""Integration smoke test: index rootset itself, run all search modes."""

import asyncio
from pathlib import Path

from rootset import Repository, SearchMode
from rootset.config import Settings


async def smoke():
    db = Path("/tmp/rootset_smoke.db")
    db.unlink(missing_ok=True)

    s = Settings(db_path=db)
    repo = Repository(s)

    async with repo:
        print("=== Indexing ===")
        stats = await repo.index(
            Path(__file__).parent / "src", incremental=False
        )
        print(stats)

        print("\n=== TEXT search: 'function that builds call graph' ===")
        results = await repo.search(
            "function that builds call graph", top_k=5, mode=SearchMode.TEXT
        )
        for r in results:
            print(f"  [{r.score:.3f}] {r.symbol.qualified_name}")

        print("\n=== HYBRID search: 'find function that builds call graph' ===")
        results = await repo.search(
            "find function that builds call graph", top_k=5, mode=SearchMode.HYBRID
        )
        for r in results:
            print(f"  [{r.score:.4f}] {r.symbol.qualified_name}")

        print("\n=== get_context('GraphIndexer.build') ===")
        try:
            ctx = await repo.get_context("GraphIndexer.build")
            print(f"  symbol:   {ctx.symbol.qualified_name}")
            print(f"  callers:  {[s.qualified_name for s in ctx.callers]}")
            print(f"  callees:  {[s.qualified_name for s in ctx.callees]}")
            print(f"  related:  {[s.name for s in ctx.related_symbols[:5]]}")
        except Exception:
            print("  (not found via exact qname — trying FTS fallback)")
            results = await repo.search("build call graph GraphIndexer", top_k=3, mode=SearchMode.TEXT)
            for r in results:
                print(f"  [{r.score:.3f}] {r.symbol.qualified_name}")

        print("\n=== find_callers('GraphIndexer.build') ===")
        try:
            callers = await repo.find_callers("GraphIndexer.build", depth=2)
            print(f"  {[s.qualified_name for s in callers]}")
        except Exception as e:
            print(f"  {e}")

        print("\n=== All indexed symbols (sample) ===")
        hits = await repo._storage.fts_search("index", 10)
        syms = await repo._storage.get_symbols_by_ids([h[0] for h in hits])
        for s in syms[:5]:
            print(f"  {s.qualified_name} ({s.kind.value})")

        print("\n=== DEBUG: call edges for GraphIndexer.build ===")
        build_sym = await repo._storage.get_symbol_by_qname("rootset.indexing.graph.GraphIndexer.build")
        if build_sym:
            print(f"  symbol id: {build_sym.id}")
            edges = await repo._storage.get_call_edges_for_symbol(build_sym.id)
            print(f"  outgoing edges ({len(edges)}):")
            for e in edges:
                print(f"    callee_name={e.callee_name!r} callee_id={e.callee_id}")

        print("\n=== DEBUG: who calls 'build' (resolved edges pointing at build_sym.id) ===")
        if build_sym:
            async with repo._storage._conn().execute(
                "SELECT ce.caller_id, ce.callee_name, s.qualified_name "
                "FROM call_edges ce JOIN symbols s ON s.id = ce.caller_id "
                "WHERE ce.callee_id = ?",
                (build_sym.id,),
            ) as cur:
                rows = await cur.fetchall()
            for r in rows:
                print(f"  caller: {r['qualified_name']} via {r['callee_name']!r}")
            if not rows:
                print("  (none)")

        print("\n=== DEBUG: resolved call edges count ===")
        resolved = await repo._storage.get_all_resolved_call_edges()
        print(f"  total resolved: {len(resolved)}")
        async with repo._storage._conn().execute(
            "SELECT COUNT(*) as n FROM call_edges WHERE callee_id IS NULL"
        ) as cur:
            row = await cur.fetchone()
        print(f"  unresolved: {row['n']}")


if __name__ == "__main__":
    asyncio.run(smoke())
