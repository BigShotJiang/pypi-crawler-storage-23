"""Custom exception hierarchy for rootset."""


class RootsetError(Exception):
    """Base exception for all rootset errors."""


class IndexingError(RootsetError):
    """Raised when indexing fails."""


class StorageError(RootsetError):
    """Raised when storage operations fail."""


class SearchError(RootsetError):
    """Raised when search operations fail."""


class SymbolNotFoundError(RootsetError):
    """Raised when a requested symbol cannot be found."""

    def __init__(self, symbol_name: str) -> None:
        super().__init__(f"Symbol not found: {symbol_name!r}")
        self.symbol_name = symbol_name


class LanguageNotSupportedError(RootsetError):
    """Raised when a language has no indexer support."""

    def __init__(self, language: str) -> None:
        super().__init__(f"Language not supported: {language!r}")
        self.language = language


class EmbeddingError(RootsetError):
    """Raised when embedding generation fails."""


class LSPError(RootsetError):
    """Raised when LSP communication fails."""


class GraphError(RootsetError):
    """Raised when graph operations fail."""
