"""rustworkx DiGraph builder and serializer."""

from __future__ import annotations

import rustworkx as rx

from rootset.storage.base import StorageBackend


class GraphIndexer:
    """Builds and persists the call/import graph using rustworkx."""

    def __init__(self, storage: StorageBackend) -> None:
        self._storage = storage
        self._graph: rx.PyDiGraph | None = None
        # symbol_id → graph node index
        self._node_map: dict[int, int] = {}

    async def build(self) -> None:
        """Reconstruct graph from all call and import edges in storage."""
        edges = await self._storage.get_all_graph_edges()
        graph = rx.PyDiGraph()
        node_map: dict[int, int] = {}

        def _get_or_add(symbol_id: int) -> int:
            if symbol_id not in node_map:
                idx = graph.add_node(symbol_id)
                node_map[symbol_id] = idx
            return node_map[symbol_id]

        for source_id, target_id, edge_type in edges:
            src = _get_or_add(source_id)
            tgt = _get_or_add(target_id)
            graph.add_edge(src, tgt, edge_type)

        self._graph = graph
        self._node_map = node_map

    async def persist(self) -> None:
        """Serialize current call_edges + import_edges from storage into graph_edges."""
        await self._storage.get_counts()
        # Rebuild from call_edges view
        edges: list[tuple[int, int, str]] = []

        # Fetch all symbols to iterate call edges
        # We use a raw approach: read back from storage via counts
        # Since we don't have a get_all_call_edges in the abstract interface,
        # we'll build from what's already in graph if available.
        if self._graph is not None:
            for src_idx, tgt_idx, data in self._graph.edge_index_map().values():
                src_sym = self._graph[src_idx]
                tgt_sym = self._graph[tgt_idx]
                edges.append((src_sym, tgt_sym, data))

        await self._storage.insert_graph_edges(edges)

    async def build_from_edges(
        self,
        call_edges: list[tuple[int, int]],
        import_edges: list[tuple[int, int]],
    ) -> None:
        """Build graph directly from provided edge lists."""
        graph = rx.PyDiGraph()
        node_map: dict[int, int] = {}

        def _get_or_add(symbol_id: int) -> int:
            if symbol_id not in node_map:
                idx = graph.add_node(symbol_id)
                node_map[symbol_id] = idx
            return node_map[symbol_id]

        all_edges: list[tuple[int, int, str]] = []
        for caller_id, callee_id in call_edges:
            src = _get_or_add(caller_id)
            tgt = _get_or_add(callee_id)
            graph.add_edge(src, tgt, "call")
            all_edges.append((caller_id, callee_id, "call"))

        for file_id, dep_id in import_edges:
            src = _get_or_add(file_id)
            tgt = _get_or_add(dep_id)
            graph.add_edge(src, tgt, "import")
            all_edges.append((file_id, dep_id, "import"))

        self._graph = graph
        self._node_map = node_map

        await self._storage.insert_graph_edges(all_edges)

    def find_callers(self, symbol_id: int, depth: int = 1) -> list[int]:
        """Return symbol_ids of nodes that call symbol_id (inbound BFS)."""
        return self._bfs_inbound(symbol_id, depth)

    def find_callees(self, symbol_id: int, depth: int = 1) -> list[int]:
        """Return symbol_ids of nodes called by symbol_id (outbound BFS)."""
        return self._bfs_outbound(symbol_id, depth)

    def find_shortest_path(self, from_id: int, to_id: int) -> list[int] | None:
        if self._graph is None:
            return None
        src = self._node_map.get(from_id)
        tgt = self._node_map.get(to_id)
        if src is None or tgt is None:
            return None
        try:
            paths = rx.dijkstra_shortest_paths(self._graph, src, target=tgt)
            if tgt not in paths:
                return None
            return [self._graph[n] for n in paths[tgt]]
        except Exception:
            return None

    def _bfs_inbound(self, symbol_id: int, depth: int) -> list[int]:
        if self._graph is None:
            return []
        start = self._node_map.get(symbol_id)
        if start is None:
            return []
        visited: set[int] = set()
        queue = [(start, 0)]
        result: list[int] = []
        while queue:
            node, d = queue.pop(0)
            if node in visited:
                continue
            visited.add(node)
            if node != start:
                result.append(self._graph[node])
            if d < depth:
                for pred in self._graph.predecessor_indices(node):
                    queue.append((pred, d + 1))
        return result

    def _bfs_outbound(self, symbol_id: int, depth: int) -> list[int]:
        if self._graph is None:
            return []
        start = self._node_map.get(symbol_id)
        if start is None:
            return []
        visited: set[int] = set()
        queue = [(start, 0)]
        result: list[int] = []
        while queue:
            node, d = queue.pop(0)
            if node in visited:
                continue
            visited.add(node)
            if node != start:
                result.append(self._graph[node])
            if d < depth:
                for succ in self._graph.successor_indices(node):
                    queue.append((succ, d + 1))
        return result

    @property
    def graph(self) -> rx.PyDiGraph | None:
        return self._graph
