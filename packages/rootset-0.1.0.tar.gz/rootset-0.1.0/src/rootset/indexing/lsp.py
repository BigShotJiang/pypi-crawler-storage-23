"""LSP-based symbol resolution.

Python: uses jedi directly (no subprocess).
Other languages: minimal async JSON-RPC client over a single persistent subprocess
per language, started once and kept alive for the whole index run.
"""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import Any, cast

from rootset.indexing.base import BaseIndexer
from rootset.models import Symbol
from rootset.storage.base import StorageBackend

# CLI commands to launch language servers (must be on PATH)
_SERVER_CMD: dict[str, list[str]] = {
    "typescript": ["typescript-language-server", "--stdio"],
    "tsx": ["typescript-language-server", "--stdio"],
    "javascript": ["typescript-language-server", "--stdio"],
    "rust": ["rust-analyzer"],
    "go": ["gopls", "-mode=stdio"],
}


class _AsyncLSPClient:
    """Minimal async JSON-RPC 2.0 client over a subprocess's stdio."""

    def __init__(self, cmd: list[str], root: Path) -> None:
        self._cmd = cmd
        self._root = root
        self._proc: asyncio.subprocess.Process | None = None
        self._next_id = 1
        self._initialized = False

    async def start(self) -> bool:
        try:
            self._proc = await asyncio.create_subprocess_exec(
                *self._cmd,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
        except (FileNotFoundError, OSError):
            return False

        await self._send(
            "initialize",
            {
                "processId": os.getpid(),
                "rootUri": self._root.as_uri(),
                "capabilities": {},
            },
        )
        # Read initialize response (ignore content, just drain it)
        await self._read_response()
        await self._notify("initialized", {})
        self._initialized = True
        return True

    async def goto_definition(
        self, file_path: Path, line: int, character: int
    ) -> list[dict[str, Any]]:
        if not self._initialized or self._proc is None:
            return []
        try:
            await self._send(
                "textDocument/definition",
                {
                    "textDocument": {"uri": file_path.as_uri()},
                    "position": {"line": line, "character": character},
                },
            )
            response = await asyncio.wait_for(self._read_response(), timeout=2.0)
            result = response.get("result") or []
            if isinstance(result, dict):
                result = [result]
            return result
        except Exception:
            return []

    async def close(self) -> None:
        if self._proc and self._proc.returncode is None:
            try:
                await self._send("shutdown", {})
                await self._notify("exit", {})
                await asyncio.wait_for(self._proc.wait(), timeout=2.0)
            except Exception:
                self._proc.kill()

    async def _send(self, method: str, params: dict[str, Any]) -> int:
        msg_id = self._next_id
        self._next_id += 1
        payload = json.dumps(
            {"jsonrpc": "2.0", "id": msg_id, "method": method, "params": params}
        )
        header = f"Content-Length: {len(payload)}\r\n\r\n"
        assert self._proc and self._proc.stdin
        self._proc.stdin.write((header + payload).encode())
        await self._proc.stdin.drain()
        return msg_id

    async def _notify(self, method: str, params: dict[str, Any]) -> None:
        payload = json.dumps({"jsonrpc": "2.0", "method": method, "params": params})
        header = f"Content-Length: {len(payload)}\r\n\r\n"
        assert self._proc and self._proc.stdin
        self._proc.stdin.write((header + payload).encode())
        await self._proc.stdin.drain()

    async def _read_response(self) -> dict[str, Any]:
        assert self._proc and self._proc.stdout
        # Read headers
        content_length = 0
        while True:
            raw = await self._proc.stdout.readline()
            line = raw.decode().strip()
            if not line:
                break
            if line.lower().startswith("content-length:"):
                content_length = int(line.split(":", 1)[1].strip())
        body = await self._proc.stdout.readexactly(content_length)
        return cast(dict[str, Any], json.loads(body))


class LSPIndexer(BaseIndexer):
    """Resolves call edges using jedi (Python) or persistent LSP subprocesses."""

    def __init__(self, storage: StorageBackend, repo_root: Path) -> None:
        super().__init__(storage)
        self._repo_root = repo_root
        self._lsp_clients: dict[str, _AsyncLSPClient] = {}
        self._jedi_project: object | None = None

    def _get_jedi_project(self) -> object:
        if self._jedi_project is None:
            import jedi  # type: ignore[import-untyped]
            self._jedi_project = jedi.Project(path=str(self._repo_root))
        return self._jedi_project

    async def _get_lsp_client(self, language: str) -> _AsyncLSPClient | None:
        if language not in _SERVER_CMD:
            return None
        if language in self._lsp_clients:
            return self._lsp_clients[language]
        client = _AsyncLSPClient(_SERVER_CMD[language], self._repo_root)
        started = await client.start()
        if not started:
            return None
        self._lsp_clients[language] = client
        return client

    async def index_file(self, path: Path, file_id: int, language: str) -> None:
        symbols = await self._storage.get_symbols_by_file(file_id)
        if not symbols:
            return

        if language == "python":
            await self._resolve_python(path, file_id, symbols)
        else:
            client = await self._get_lsp_client(language)
            if client:
                await self._resolve_via_lsp(client, path, file_id, symbols)

    async def _resolve_python(self, path: Path, file_id: int, symbols: list[Symbol]) -> None:
        try:
            import jedi
            project = self._get_jedi_project()
            source = path.read_text(errors="replace")
            lines = source.splitlines()
            script = jedi.Script(source, path=str(path), project=project)
        except Exception:
            return

        for symbol in symbols:
            edges = await self._storage.get_call_edges_for_symbol(symbol.id)
            for edge in edges:
                if edge.callee_id is not None:
                    continue
                try:
                    # Find the column of the callee name on the call site line
                    line_idx = edge.call_site_line - 1
                    if line_idx >= len(lines):
                        continue
                    line_text = lines[line_idx]
                    col = line_text.find(edge.callee_name)
                    if col < 0:
                        continue
                    # jedi uses 1-indexed line, 0-indexed column
                    defs = script.goto(edge.call_site_line, col + len(edge.callee_name))
                    for defn in defs:
                        if not defn.module_path or not defn.name:
                            continue
                        # Build qualified name and look it up
                        module = defn.full_name or ""
                        resolved = await self._storage.get_symbol_by_qname(module)
                        if resolved is None:
                            # Try just module + name
                            qname = f"{defn.module_name}.{defn.name}" if defn.module_name else defn.name
                            resolved = await self._storage.get_symbol_by_qname(qname)
                        if resolved:
                            await self._storage.update_call_edge_callee(
                                edge.caller_id,
                                edge.call_site_line,
                                resolved.id,
                                callee_name=edge.callee_name,
                            )
                            break
                except Exception:
                    continue

    async def _resolve_via_lsp(
        self,
        client: _AsyncLSPClient,
        path: Path,
        file_id: int,
        symbols: list[Symbol],
    ) -> None:
        for symbol in symbols:
            edges = await self._storage.get_call_edges_for_symbol(symbol.id)
            for edge in edges:
                if edge.callee_id is not None:
                    continue
                try:
                    locs = await client.goto_definition(path, edge.call_site_line - 1, 0)
                    for loc in locs:
                        uri = loc.get("uri", "")
                        target_path = Path(uri.removeprefix("file://"))
                        target_line = loc.get("range", {}).get("start", {}).get("line", 0) + 1
                        # Find symbol at that location
                        target_file = await self._storage.get_file_by_path(
                            str(target_path.relative_to(self._repo_root))
                        )
                        if not target_file:
                            continue
                        target_syms = await self._storage.get_symbols_by_file(target_file.id)
                        for sym in target_syms:
                            if sym.line_start <= target_line <= sym.line_end:
                                await self._storage.update_call_edge_callee(
                                    edge.caller_id, edge.call_site_line, sym.id
                                )
                                break
                except Exception:
                    continue

    async def close(self) -> None:
        for client in self._lsp_clients.values():
            await client.close()
        self._lsp_clients.clear()
        self._jedi_project = None
