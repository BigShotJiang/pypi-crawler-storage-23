"""Tree-sitter structural indexer for Python, TypeScript, JavaScript, Rust, Go."""

from __future__ import annotations

from pathlib import Path
from typing import Any, cast

from tree_sitter import Language, Node, Parser, Query, QueryCursor
from tree_sitter_language_pack import get_language, get_parser

from rootset.exceptions import LanguageNotSupportedError
from rootset.indexing.base import BaseIndexer
from rootset.models import SymbolKind
from rootset.storage.base import StorageBackend

# ---------------------------------------------------------------------------
# S-expression queries per language
# ---------------------------------------------------------------------------

_PYTHON_SYMBOLS = """
(function_definition
  name: (identifier) @name
  parameters: (parameters) @params) @fn

(class_definition
  name: (identifier) @name) @cls
"""

_PYTHON_CALLS = """
(call
  function: [
    (identifier) @callee
    (attribute attribute: (identifier) @callee)
  ])
"""

_PYTHON_IMPORTS = """
(import_statement
  name: (dotted_name) @module)

(import_from_statement
  module_name: (dotted_name) @module
  name: (dotted_name) @symbol)

(import_from_statement
  module_name: (dotted_name) @module
  name: (aliased_import
    name: (dotted_name) @symbol
    alias: (identifier) @alias))
"""

_TS_SYMBOLS = """
(function_declaration
  name: (identifier) @name
  parameters: (formal_parameters) @params) @fn

(method_definition
  name: (property_identifier) @name
  parameters: (formal_parameters) @params) @fn

(class_declaration
  name: (type_identifier) @name) @cls

(arrow_function
  parameters: _ @params) @fn
"""

_TS_CALLS = """
(call_expression
  function: [
    (identifier) @callee
    (member_expression property: (property_identifier) @callee)
  ])
"""

_TS_IMPORTS = """
(import_statement
  source: (string) @module)
"""

_RUST_SYMBOLS = """
(function_item
  name: (identifier) @name
  parameters: (parameters) @params) @fn

(impl_item
  type: (type_identifier) @impl_type) @impl

(struct_item
  name: (type_identifier) @name) @cls

(trait_item
  name: (type_identifier) @name) @cls
"""

_RUST_CALLS = """
(call_expression
  function: [
    (identifier) @callee
    (field_expression field: (field_identifier) @callee)
    (scoped_identifier name: (identifier) @callee)
  ])
"""

_RUST_IMPORTS = """
(use_declaration
  argument: (scoped_identifier path: (identifier) @module name: (identifier) @symbol))

(use_declaration
  argument: (identifier) @module)
"""

_GO_SYMBOLS = """
(function_declaration
  name: (identifier) @name
  parameters: (parameter_list) @params) @fn

(method_declaration
  name: (field_identifier) @name
  parameters: (parameter_list) @params) @fn

(type_declaration
  (type_spec name: (type_identifier) @name)) @cls
"""

_GO_CALLS = """
(call_expression
  function: [
    (identifier) @callee
    (selector_expression field: (field_identifier) @callee)
  ])
"""

_GO_IMPORTS = """
(import_spec path: (interpreted_string_literal) @module)
"""

LANGUAGE_QUERIES: dict[str, dict[str, str]] = {
    "python": {
        "symbols": _PYTHON_SYMBOLS,
        "calls": _PYTHON_CALLS,
        "imports": _PYTHON_IMPORTS,
    },
    "typescript": {
        "symbols": _TS_SYMBOLS,
        "calls": _TS_CALLS,
        "imports": _TS_IMPORTS,
    },
    "tsx": {
        "symbols": _TS_SYMBOLS,
        "calls": _TS_CALLS,
        "imports": _TS_IMPORTS,
    },
    "javascript": {
        "symbols": _TS_SYMBOLS,
        "calls": _TS_CALLS,
        "imports": _TS_IMPORTS,
    },
    "rust": {
        "symbols": _RUST_SYMBOLS,
        "calls": _RUST_CALLS,
        "imports": _RUST_IMPORTS,
    },
    "go": {
        "symbols": _GO_SYMBOLS,
        "calls": _GO_CALLS,
        "imports": _GO_IMPORTS,
    },
}


class TreeSitterIndexer(BaseIndexer):
    def __init__(self, storage: StorageBackend) -> None:
        super().__init__(storage)
        self._parsers: dict[str, Parser] = {}
        self._languages: dict[str, Language] = {}

    def _get_parser(self, language: str) -> Parser:
        if language not in self._parsers:
            if language not in LANGUAGE_QUERIES:
                raise LanguageNotSupportedError(language)
            self._parsers[language] = get_parser(cast(Any, language))
            self._languages[language] = get_language(cast(Any, language))
        return self._parsers[language]

    async def index_file(self, path: Path, file_id: int, language: str) -> None:
        parser = self._get_parser(language)
        source = path.read_bytes()
        source.decode("utf-8", errors="replace")
        tree = parser.parse(source)
        root = tree.root_node

        lang_obj = self._languages[language]
        queries = LANGUAGE_QUERIES[language]

        # Extract module name from path for qualified names
        module_name = _path_to_module(path)

        # --- Symbols ---
        sym_q = Query(lang_obj, queries["symbols"])
        sym_captures = QueryCursor(sym_q).captures(root)

        symbols = _extract_symbols(
            sym_captures, source, file_id, module_name, language
        )
        if not symbols:
            return

        inserted_ids = await self._storage.insert_symbols(symbols)
        id_map = {
            sym["qualified_name"]: sid
            for sym, sid in zip(symbols, inserted_ids)
        }

        # --- Calls (per-function) ---
        call_q = Query(lang_obj, queries["calls"])
        call_cursor = QueryCursor(call_q)
        call_edges = _extract_calls(
            sym_captures, call_cursor, root, source, id_map
        )
        if call_edges:
            await self._storage.insert_call_edges(call_edges)

        # --- Imports ---
        import_q = Query(lang_obj, queries["imports"])
        import_captures = QueryCursor(import_q).captures(root)
        import_edges = _extract_imports(import_captures, file_id, source)
        if import_edges:
            await self._storage.insert_import_edges(import_edges)

    async def close(self) -> None:
        pass


# ---------------------------------------------------------------------------
# Extraction helpers
# ---------------------------------------------------------------------------


def _path_to_module(path: Path) -> str:
    parts = path.with_suffix("").parts
    # Strip leading path components to get a reasonable module name
    try:
        src_idx = parts.index("src")
        return ".".join(parts[src_idx + 1 :])
    except ValueError:
        return ".".join(parts[-3:]) if len(parts) >= 3 else path.stem


def _node_text(node: Node, source: bytes) -> str:
    return source[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def _extract_docstring(body_node: Node | None, source: bytes) -> str | None:
    if body_node is None:
        return None
    for child in body_node.children:
        # Direct string node (Python tree-sitter 0.25+)
        if child.type == "string":
            content_node = next(
                (c for c in child.children if c.type == "string_content"), None
            )
            if content_node:
                return _node_text(content_node, source).strip() or None
            text = _node_text(child, source).strip("'\" \t\n")
            return text or None
        # Wrapped in expression_statement (older grammars)
        if child.type == "expression_statement":
            for sub in child.children:
                if sub.type in ("string", "string_literal"):
                    content_node = next(
                        (c for c in sub.children if c.type == "string_content"), None
                    )
                    if content_node:
                        return _node_text(content_node, source).strip() or None
                    text = _node_text(sub, source).strip("'\" \t\n")
                    return text or None
    return None


def _extract_symbols(
    captures: dict[str, list[Node]],
    source: bytes,
    file_id: int,
    module_name: str,
    language: str,
) -> list[dict[str, Any]]:
    symbols: list[dict[str, Any]] = []
    seen_qnames: set[str] = set()

    cls_nodes = captures.get("cls", [])
    fn_nodes = captures.get("fn", []) + cls_nodes

    for node in fn_nodes:
        name_node = None
        for child in node.children:
            if child.type in ("identifier", "type_identifier", "property_identifier", "field_identifier"):
                name_node = child
                break
        if name_node is None:
            continue

        name = _node_text(name_node, source)
        kind = _node_kind(node.type, language)

        # Check if this node is nested inside a class — if so, qualify with class name
        enclosing_class = _find_enclosing_class(node, cls_nodes, source)
        if enclosing_class and kind != SymbolKind.CLASS:
            qname = f"{module_name}.{enclosing_class}.{name}"
        else:
            qname = f"{module_name}.{name}"

        if qname in seen_qnames:
            qname = f"{qname}_{node.start_point[0]}"
        seen_qnames.add(qname)

        first_line = source[node.start_byte:].split(b"\n")[0][:200].decode("utf-8", errors="replace")
        docstring = _extract_docstring(_get_body(node), source)
        content = source[node.start_byte:node.end_byte].decode("utf-8", errors="replace")

        symbols.append({
            "file_id": file_id,
            "name": name,
            "qualified_name": qname,
            "kind": kind.value,
            "line_start": node.start_point[0] + 1,
            "line_end": node.end_point[0] + 1,
            "signature": first_line,
            "docstring": docstring,
            "content": content,
        })

    return symbols


def _get_body(node: Node) -> Node | None:
    for child in node.children:
        if child.type in ("block", "body"):
            return child
    return None


def _find_enclosing_class(
    node: Node, cls_nodes: list[Node], source: bytes
) -> str | None:
    """Return the name of the tightest enclosing class node, if any."""
    best: Node | None = None
    for cls_node in cls_nodes:
        if cls_node is node:
            continue
        if cls_node.start_byte <= node.start_byte and cls_node.end_byte >= node.end_byte:
            if best is None or (cls_node.end_byte - cls_node.start_byte) < (best.end_byte - best.start_byte):
                best = cls_node
    if best is None:
        return None
    for child in best.children:
        if child.type in ("identifier", "type_identifier"):
            return _node_text(child, source)
    return None


def _node_kind(node_type: str, language: str) -> SymbolKind:
    if node_type in ("class_definition", "class_declaration", "struct_item", "trait_item", "type_declaration", "impl_item"):
        return SymbolKind.CLASS
    if node_type in ("method_definition", "method_declaration"):
        return SymbolKind.METHOD
    return SymbolKind.FUNCTION


def _extract_calls(
    sym_captures: dict[str, list[Node]],
    call_cursor: QueryCursor,
    root: Node,
    source: bytes,
    id_map: dict[str, int],
) -> list[dict[str, Any]]:
    edges: list[dict[str, Any]] = []

    # Build a mapping: line range → symbol id for each function
    fn_ranges: list[tuple[int, int, int]] = []  # (start_line, end_line, symbol_id)
    fn_nodes = sym_captures.get("fn", []) + sym_captures.get("cls", [])

    for node in fn_nodes:
        name_node = None
        for child in node.children:
            if child.type in ("identifier", "type_identifier", "property_identifier"):
                name_node = child
                break
        if name_node is None:
            continue
        name = _node_text(name_node, source)
        for qname, sid in id_map.items():
            if qname.endswith(f".{name}") or qname == name:
                fn_ranges.append((node.start_point[0], node.end_point[0], sid))
                break

    call_captures = call_cursor.captures(root)
    callee_nodes = call_captures.get("callee", [])

    for node in callee_nodes:
        call_line = node.start_point[0]
        callee_name = _node_text(node, source)
        caller_id = _find_enclosing(fn_ranges, call_line)
        if caller_id is None:
            continue
        edges.append({
            "caller_id": caller_id,
            "callee_name": callee_name,
            "callee_id": None,
            "call_site_line": call_line + 1,
        })

    return edges



def _find_enclosing(
    fn_ranges: list[tuple[int, int, int]], line: int
) -> int | None:
    best: tuple[int, int, int] | None = None
    for start, end, sid in fn_ranges:
        if start <= line <= end:
            if best is None or (end - start) < (best[1] - best[0]):
                best = (start, end, sid)
    return best[2] if best else None


def _extract_imports(
    captures: dict[str, list[Node]],
    file_id: int,
    source: bytes,
) -> list[dict[str, Any]]:
    edges: list[dict[str, Any]] = []
    modules = [_node_text(n, source).strip('"\'') for n in captures.get("module", [])]
    symbols = [_node_text(n, source) for n in captures.get("symbol", [])]
    aliases = [_node_text(n, source) for n in captures.get("alias", [])]

    for i, mod in enumerate(modules):
        edges.append({
            "file_id": file_id,
            "imported_module": mod,
            "symbol_name": symbols[i] if i < len(symbols) else None,
            "alias": aliases[i] if i < len(aliases) else None,
        })
    return edges
