"""Pluggable embedding providers."""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, cast, runtime_checkable

from rootset.config import EmbeddingProviderName, Settings
from rootset.exceptions import EmbeddingError

if TYPE_CHECKING:
    from sentence_transformers import SentenceTransformer as _SentenceTransformer


@runtime_checkable
class EmbeddingProvider(Protocol):
    async def embed(self, texts: list[str]) -> list[list[float]]: ...

    @property
    def dimensions(self) -> int: ...


class LocalEmbeddingProvider:
    """nomic-ai/nomic-embed-code via sentence-transformers."""

    def __init__(self, model_name: str) -> None:
        self._model_name = model_name
        self._model: _SentenceTransformer | None = None
        self._dim: int | None = None

    def _load(self) -> None:
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(self._model_name, trust_remote_code=True)
            self._dim = self._model.get_sentence_embedding_dimension()

    async def embed(self, texts: list[str]) -> list[list[float]]:
        import asyncio
        self._load()
        assert self._model is not None
        model = self._model
        loop = asyncio.get_event_loop()
        embeddings = await loop.run_in_executor(
            None, lambda: model.encode(texts, show_progress_bar=False)
        )
        return [e.tolist() for e in embeddings]

    @property
    def dimensions(self) -> int:
        self._load()
        return self._dim or 768


class VoyageEmbeddingProvider:
    """voyage-code-3 via voyageai SDK."""

    def __init__(self, api_key: str) -> None:
        import voyageai
        self._client = voyageai.AsyncClient(api_key=api_key)  # type: ignore[attr-defined]
        self._dim = 1024

    async def embed(self, texts: list[str]) -> list[list[float]]:
        result = await self._client.embed(texts, model="voyage-code-3")
        return cast(list[list[float]], result.embeddings)

    @property
    def dimensions(self) -> int:
        return self._dim


class OpenAIEmbeddingProvider:
    """OpenAI text-embedding-* via openai SDK."""

    def __init__(self, api_key: str, model: str, base_url: str) -> None:
        from openai import AsyncOpenAI
        self._client = AsyncOpenAI(api_key=api_key, base_url=base_url)
        self._model = model
        self._dim = 1536

    async def embed(self, texts: list[str]) -> list[list[float]]:
        response = await self._client.embeddings.create(
            input=texts, model=self._model
        )
        return [d.embedding for d in response.data]

    @property
    def dimensions(self) -> int:
        return self._dim


def build_provider(settings: Settings) -> EmbeddingProvider:
    match settings.embedding_provider:
        case EmbeddingProviderName.LOCAL:
            return LocalEmbeddingProvider(settings.embedding_model_local)
        case EmbeddingProviderName.VOYAGE:
            if not settings.voyage_api_key:
                raise EmbeddingError("ROOTSET_VOYAGE_API_KEY not set")
            return VoyageEmbeddingProvider(settings.voyage_api_key)
        case EmbeddingProviderName.OPENAI:
            if not settings.openai_api_key:
                raise EmbeddingError("ROOTSET_OPENAI_API_KEY not set")
            return OpenAIEmbeddingProvider(
                settings.openai_api_key,
                settings.openai_embedding_model,
                settings.openai_base_url,
            )
