"""Abstract base class for indexers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from rootset.storage.base import StorageBackend


class BaseIndexer(ABC):
    def __init__(self, storage: StorageBackend) -> None:
        self._storage = storage

    @abstractmethod
    async def index_file(self, path: Path, file_id: int, language: str) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...
