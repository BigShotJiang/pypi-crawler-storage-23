"""Configuration for rootset.

Explicit construction (``Settings(db_path=...)``) uses only the provided
values and hard-coded defaults — env vars are never consulted.

``get_settings()`` is the single place that reads from ``ROOTSET_*`` env vars
and an optional ``.env`` file.  It caches the result so the env is read at
most once per process.
"""

from __future__ import annotations

from enum import Enum
from pathlib import Path

from pydantic import BaseModel, ConfigDict, model_validator


class EmbeddingProviderName(str, Enum):
    LOCAL = "local"
    VOYAGE = "voyage"
    OPENAI = "openai"


class Settings(BaseModel):
    """Pure configuration model — no env reading on construction."""

    model_config = ConfigDict(extra="ignore")

    # Storage
    db_path: Path = Path("rootset.db")

    # Embedding provider
    embedding_provider: EmbeddingProviderName = EmbeddingProviderName.LOCAL
    embedding_model_local: str = "nomic-ai/nomic-embed-code"
    embedding_dimensions: int = 768

    # API keys (optional — presence activates provider)
    voyage_api_key: str | None = None
    openai_api_key: str | None = None
    openai_base_url: str = "https://api.openai.com/v1"
    openai_embedding_model: str = "text-embedding-3-small"

    # Reasoning retrieval
    reasoning_model: str = "cyankiwi/Qwen3-Coder-Next-AWQ-4bit"
    reasoning_api_key: str | None = "EMPTY"
    reasoning_base_url: str = "http://10.6.12.18:9000/v1"

    # Search defaults
    default_top_k: int = 10
    rrf_k: int = 60

    # Indexing
    incremental: bool = True
    reindex_debounce_seconds: float = 1.5

    @model_validator(mode="after")
    def auto_select_provider(self) -> "Settings":
        if self.embedding_provider == EmbeddingProviderName.LOCAL:
            if self.voyage_api_key:
                self.embedding_provider = EmbeddingProviderName.VOYAGE
            elif self.openai_api_key:
                self.embedding_provider = EmbeddingProviderName.OPENAI
        return self


_settings: Settings | None = None


def get_settings() -> Settings:
    """Return a cached Settings instance loaded from ROOTSET_* env vars / .env."""
    global _settings
    if _settings is None:
        from pydantic_settings import BaseSettings, SettingsConfigDict

        class _EnvSettings(Settings, BaseSettings):
            model_config = SettingsConfigDict(
                env_prefix="ROOTSET_", env_file=".env", extra="ignore"
            )

        _settings = _EnvSettings()
    return _settings
