"""Repository: main entry point for rootset."""

from __future__ import annotations

import asyncio
from datetime import timezone
from pathlib import Path

from rootset.config import Settings, get_settings
from rootset.exceptions import SymbolNotFoundError
from rootset.indexing.embeddings import EmbeddingProvider, build_provider
from rootset.indexing.graph import GraphIndexer
from rootset.indexing.lsp import LSPIndexer
from rootset.indexing.treesitter import TreeSitterIndexer
from rootset.models import (
    CodeContext,
    IndexStats,
    SearchMode,
    SearchResult,
    Symbol,
)
from rootset.search.base import BaseSearcher
from rootset.search.graph import GraphSearcher
from rootset.search.hybrid import HybridSearcher
from rootset.search.reasoning import ReasoningSearcher
from rootset.search.semantic import SemanticSearcher
from rootset.search.structural import StructuralSearcher
from rootset.search.text import TextSearcher
from rootset.storage.sqlite import SQLiteBackend
from rootset.utils.hashing import hash_file
from rootset.utils.language import detect_language, is_supported


class Repository:
    """In-process code intelligence database."""

    def __init__(self, settings: Settings | None = None) -> None:
        self._settings = settings or get_settings()
        self._storage = SQLiteBackend(self._settings.db_path)
        self._provider: EmbeddingProvider | None = None
        self._graph_indexer = GraphIndexer(self._storage)
        self._initialized = False
        self._repo_root: Path | None = None
        self._pending_reindex: dict[str, asyncio.Task[None]] = {}

    async def _ensure_init(self) -> None:
        if self._initialized:
            return
        self._provider = build_provider(self._settings)
        await self._storage.initialize(self._provider.dimensions)
        await self._graph_indexer.build()
        self._initialized = True

    async def close(self) -> None:
        for task in self._pending_reindex.values():
            task.cancel()
        self._pending_reindex.clear()
        await self._storage.close()
        self._initialized = False

    # --- Context manager support ---

    async def __aenter__(self) -> "Repository":
        await self._ensure_init()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.close()

    # --- Indexing ---

    async def index(
        self, path: str | Path, *, incremental: bool = True
    ) -> IndexStats:
        await self._ensure_init()
        repo_path = Path(path).resolve()
        self._repo_root = repo_path

        ts_indexer = TreeSitterIndexer(self._storage)
        lsp_indexer = LSPIndexer(self._storage, repo_path)

        files_skipped = 0

        # Collect all supported files
        all_files = [f for f in repo_path.rglob("*") if f.is_file() and is_supported(f)]

        symbol_ids_to_embed: list[int] = []
        # Track successfully indexed files for post-loop resolution passes
        indexed_files: list[tuple[Path, int, str]] = []  # (path, file_id, language)

        # Pass 1: tree-sitter extraction (symbols + raw call edges, no resolution yet)
        for file_path in all_files:
            language = detect_language(file_path)
            if language is None:
                continue

            file_hash = hash_file(file_path)
            rel_path = str(file_path.relative_to(repo_path))

            # Incremental: skip if unchanged
            if incremental:
                existing = await self._storage.get_file_by_path(rel_path)
                if existing and existing.content_hash == file_hash:
                    files_skipped += 1
                    continue

            # Register file
            file_record = await self._storage.upsert_file(rel_path, language, file_hash)

            # Clear old symbols for re-index
            await self._storage.delete_file_symbols(file_record.id)

            try:
                await ts_indexer.index_file(file_path, file_record.id, language)
            except Exception:
                files_skipped += 1
                continue

            indexed_files.append((file_path, file_record.id, language))

        await ts_indexer.close()

        # Pass 2: SQL resolution — all symbols now exist, so cross-file edges resolve
        for _, file_id, _ in indexed_files:
            await self._storage.resolve_call_edges(file_id)

        # Pass 3: LSP resolution (best-effort) for remaining unresolved edges
        for file_path, file_id, language in indexed_files:
            try:
                await lsp_indexer.index_file(file_path, file_id, language)
            except Exception:
                pass

        await lsp_indexer.close()

        # Collect symbol ids for embedding
        for _, file_id, _ in indexed_files:
            syms = await self._storage.get_symbols_by_file(file_id)
            symbol_ids_to_embed.extend(s.id for s in syms)

        files_indexed = len(indexed_files)

        # Generate embeddings in batches
        if symbol_ids_to_embed and self._provider:
            await self._embed_symbols(symbol_ids_to_embed)

        # Rebuild graph from all edges
        await self._rebuild_graph()

        counts = await self._storage.get_counts()
        return IndexStats(
            files_indexed=files_indexed,
            symbols_indexed=counts.get("symbols", 0),
            call_edges_indexed=counts.get("call_edges", 0),
            import_edges_indexed=counts.get("import_edges", 0),
            files_skipped=files_skipped,
        )

    async def _embed_symbols(self, symbol_ids: list[int]) -> None:
        assert self._provider is not None
        batch_size = 64
        for i in range(0, len(symbol_ids), batch_size):
            batch_ids = symbol_ids[i : i + batch_size]
            symbols = await self._storage.get_symbols_by_ids(batch_ids)
            if not symbols:
                continue
            texts = [f"{s.signature}\n{s.docstring or ''}\n{s.content[:512]}" for s in symbols]
            try:
                embeddings = await self._provider.embed(texts)
                ids = [s.id for s in symbols]
                await self._storage.insert_embeddings(ids, embeddings)
            except Exception:
                pass

    async def _rebuild_graph(self) -> None:
        call_edges = await self._storage.get_all_resolved_call_edges()
        await self._graph_indexer.build_from_edges(call_edges, [])

    # --- Search ---

    async def search(
        self,
        query: str,
        *,
        top_k: int | None = None,
        mode: SearchMode = SearchMode.HYBRID,
    ) -> list[SearchResult]:
        await self._ensure_init()
        k = top_k or self._settings.default_top_k

        if mode == SearchMode.TEXT:
            return await TextSearcher(self._storage).search(query, k)

        if mode == SearchMode.SEMANTIC:
            assert self._provider is not None
            return await SemanticSearcher(self._storage, self._provider).search(query, k)

        if mode == SearchMode.STRUCTURAL:
            searcher = StructuralSearcher(self._storage, self._settings.db_path.parent)
            return await searcher.search(query, k)

        if mode == SearchMode.GRAPH:
            graph_searcher = GraphSearcher(self._storage, self._graph_indexer)
            return await graph_searcher.search(query, k)

        # HYBRID
        searchers: list[BaseSearcher] = [TextSearcher(self._storage)]
        if self._provider:
            searchers.append(SemanticSearcher(self._storage, self._provider))
        hybrid = HybridSearcher(searchers, k=self._settings.rrf_k)

        if mode == SearchMode.REASONING:
            return await ReasoningSearcher(
                self._storage,
                hybrid,
                self._settings.reasoning_model,
                self._settings.reasoning_api_key,
                self._settings.reasoning_base_url,
            ).search(query, k)

        return await hybrid.search(query, k)

    async def reasoning_search(
        self, query: str, *, top_k: int | None = None
    ) -> list[SearchResult]:
        return await self.search(query, top_k=top_k, mode=SearchMode.REASONING)

    # --- Symbol lookup ---

    async def get_symbol(self, qualified_name: str) -> Symbol | None:
        await self._ensure_init()
        return await self._storage.get_symbol_by_qname(qualified_name)

    # --- Graph traversal ---

    async def find_callers(self, symbol_name: str, depth: int = 1) -> list[Symbol]:
        await self._ensure_init()
        sym = await self._resolve_symbol(symbol_name)
        graph_searcher = GraphSearcher(self._storage, self._graph_indexer)
        return await graph_searcher.find_callers(sym.id, depth)

    async def find_callees(self, symbol_name: str, depth: int = 1) -> list[Symbol]:
        await self._ensure_init()
        sym = await self._resolve_symbol(symbol_name)
        graph_searcher = GraphSearcher(self._storage, self._graph_indexer)
        return await graph_searcher.find_callees(sym.id, depth)

    # --- Context ---

    async def get_context(self, symbol_name: str) -> CodeContext:
        await self._ensure_init()
        sym = await self._resolve_symbol(symbol_name)

        file_record = None
        if sym.file_id:
            # Get file by id via symbols_by_file lookup
            await self._storage.get_symbols_by_file(sym.file_id)
            # Get file from storage — need the file record
            from rootset.models import File
            await self._storage.get_counts()
            # Use a direct db query via sqlite backend
            if hasattr(self._storage, "_conn"):
                async with self._storage._conn().execute(
                    "SELECT * FROM files WHERE id = ?", (sym.file_id,)
                ) as cur:
                    row = await cur.fetchone()
                if row:
                    from datetime import datetime
                    file_record = File(
                        id=row["id"],
                        path=row["path"],
                        language=row["language"],
                        content_hash=row["content_hash"],
                        last_indexed=datetime.fromisoformat(str(row["last_indexed"])),
                    )

        callers = await self.find_callers(symbol_name, depth=1)
        callees = await self.find_callees(symbol_name, depth=1)

        # Related: same file, same kind
        file_symbols = await self._storage.get_symbols_by_file(sym.file_id)
        related = [s for s in file_symbols if s.id != sym.id and s.kind == sym.kind][:10]

        # Import chain
        imports = await self._storage.get_import_edges_for_file(sym.file_id)
        import_chain = [f"{e.imported_module}" + (f".{e.symbol_name}" if e.symbol_name else "") for e in imports]

        from rootset.models import File as FileModel
        if file_record is None:
            file_record = FileModel(
                id=sym.file_id,
                path="unknown",
                language="unknown",
                content_hash="",
                last_indexed=datetime.now(timezone.utc),
            )

        return CodeContext(
            symbol=sym,
            definition_file=file_record,
            callers=callers,
            callees=callees,
            related_symbols=related,
            import_chain=import_chain,
        )

    async def structural_query(self, pattern: str, language: str) -> list[Symbol]:
        await self._ensure_init()
        searcher = StructuralSearcher(self._storage, self._settings.db_path.parent)
        results = await searcher.query(pattern, language)
        return [r.symbol for r in results]

    # --- Debounced auto-reindex ---

    def notify_file_changed(self, path: str | Path) -> None:
        """Schedule a debounced re-index of a single file. Safe to call repeatedly."""
        if self._repo_root is None:
            return
        abs_path = Path(path).resolve()
        key = str(abs_path)
        existing = self._pending_reindex.get(key)
        if existing and not existing.done():
            existing.cancel()
        try:
            loop = asyncio.get_running_loop()
            task = loop.create_task(self._debounced_reindex(abs_path, key))
            self._pending_reindex[key] = task
        except RuntimeError:
            pass  # no running event loop

    async def _debounced_reindex(self, path: Path, key: str) -> None:
        try:
            await asyncio.sleep(self._settings.reindex_debounce_seconds)
            await self._reindex_file(path)
        except asyncio.CancelledError:
            pass
        finally:
            self._pending_reindex.pop(key, None)

    async def _reindex_file(self, path: Path) -> None:
        repo_root = self._repo_root
        if repo_root is None:
            return
        language = detect_language(path)
        if language is None or not is_supported(path):
            return
        file_hash = hash_file(path)
        rel_path = str(path.relative_to(repo_root))

        existing = await self._storage.get_file_by_path(rel_path)
        if existing and existing.content_hash == file_hash:
            return  # file unchanged on disk — skip

        file_record = await self._storage.upsert_file(rel_path, language, file_hash)
        await self._storage.delete_file_symbols(file_record.id)

        ts_indexer = TreeSitterIndexer(self._storage)
        lsp_indexer = LSPIndexer(self._storage, repo_root)
        try:
            await ts_indexer.index_file(path, file_record.id, language)
            await self._storage.resolve_call_edges(file_record.id)
            await lsp_indexer.index_file(path, file_record.id, language)
        except Exception:
            return
        finally:
            await ts_indexer.close()
            await lsp_indexer.close()

        syms = await self._storage.get_symbols_by_file(file_record.id)
        if syms and self._provider:
            await self._embed_symbols([s.id for s in syms])
        await self._rebuild_graph()

    async def _resolve_symbol(self, symbol_name: str) -> Symbol:
        sym = await self._storage.get_symbol_by_qname(symbol_name)
        if sym is None:
            # Try deterministic suffix match: qname ends with .{symbol_name}
            candidates = await self._storage.find_symbols_by_qname_suffix(symbol_name)
            if len(candidates) == 1:
                sym = candidates[0]
            elif len(candidates) > 1:
                # Multiple matches — fall back to FTS to pick most relevant
                hits = await self._storage.fts_search(symbol_name, 1)
                if hits:
                    syms = await self._storage.get_symbols_by_ids([hits[0][0]])
                    if syms:
                        sym = syms[0]
                if sym is None:
                    sym = candidates[0]
        if sym is None:
            raise SymbolNotFoundError(symbol_name)
        return sym
