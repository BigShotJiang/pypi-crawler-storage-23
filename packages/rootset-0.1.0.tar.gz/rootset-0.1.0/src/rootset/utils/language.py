"""Language detection and tree-sitter language mapping."""

from __future__ import annotations

from pathlib import Path

EXTENSION_MAP: dict[str, str] = {
    ".py": "python",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".js": "javascript",
    ".jsx": "javascript",
    ".rs": "rust",
    ".go": "go",
}

SUPPORTED_LANGUAGES: frozenset[str] = frozenset(EXTENSION_MAP.values())


def detect_language(path: Path | str) -> str | None:
    suffix = Path(path).suffix.lower()
    return EXTENSION_MAP.get(suffix)


def is_supported(path: Path | str) -> bool:
    return detect_language(path) is not None
