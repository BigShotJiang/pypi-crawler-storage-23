"""Reciprocal Rank Fusion hybrid searcher."""

from __future__ import annotations

import asyncio
from collections import defaultdict

from rootset.models import SearchResult
from rootset.search.base import BaseSearcher


class HybridSearcher:
    """Fuses results from multiple searchers using RRF."""

    def __init__(self, searchers: list[BaseSearcher], k: int = 60) -> None:
        self._searchers = searchers
        self._k = k

    async def search(self, query: str, top_k: int) -> list[SearchResult]:
        tasks = [s.search(query, top_k * 2) for s in self._searchers]
        all_results = await asyncio.gather(*tasks, return_exceptions=True)

        rrf_scores: dict[int, float] = defaultdict(float)
        best_result: dict[int, SearchResult] = {}

        for results in all_results:
            if isinstance(results, BaseException):
                continue
            sorted_results = sorted(results, key=lambda r: r.score, reverse=True)
            for rank, result in enumerate(sorted_results, start=1):
                sid = result.symbol.id
                rrf_scores[sid] += 1.0 / (self._k + rank)
                if sid not in best_result or result.score > best_result[sid].score:
                    best_result[sid] = result

        ranked = sorted(rrf_scores.items(), key=lambda x: x[1], reverse=True)[:top_k]
        return [
            SearchResult(
                symbol=best_result[sid].symbol,
                score=score,
                search_type="hybrid",
            )
            for sid, score in ranked
            if sid in best_result
        ]
