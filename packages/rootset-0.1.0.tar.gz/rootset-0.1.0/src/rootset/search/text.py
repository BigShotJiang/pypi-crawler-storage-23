"""FTS5 BM25 full-text searcher."""

from __future__ import annotations

from rootset.models import SearchResult
from rootset.search.base import BaseSearcher


class TextSearcher(BaseSearcher):
    async def search(self, query: str, top_k: int) -> list[SearchResult]:
        hits = await self._storage.fts_search(query, top_k)
        if not hits:
            return []
        ids = [h[0] for h in hits]
        score_map = {h[0]: h[1] for h in hits}
        symbols = await self._storage.get_symbols_by_ids(ids)
        return [
            SearchResult(symbol=sym, score=score_map[sym.id], search_type="text")
            for sym in symbols
        ]
