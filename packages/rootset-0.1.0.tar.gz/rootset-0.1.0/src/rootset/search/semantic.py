"""sqlite-vec ANN semantic searcher."""

from __future__ import annotations

from rootset.indexing.embeddings import EmbeddingProvider
from rootset.models import SearchResult
from rootset.search.base import BaseSearcher
from rootset.storage.base import StorageBackend


class SemanticSearcher(BaseSearcher):
    def __init__(self, storage: StorageBackend, provider: EmbeddingProvider) -> None:
        super().__init__(storage)
        self._provider = provider

    async def search(self, query: str, top_k: int) -> list[SearchResult]:
        embeddings = await self._provider.embed([query])
        query_vec = embeddings[0]
        hits = await self._storage.vec_search(query_vec, top_k)
        if not hits:
            return []
        ids = [h[0] for h in hits]
        score_map = {h[0]: 1.0 / (1.0 + h[1]) for h in hits}  # invert distance
        symbols = await self._storage.get_symbols_by_ids(ids)
        return [
            SearchResult(symbol=sym, score=score_map[sym.id], search_type="semantic")
            for sym in symbols
        ]
