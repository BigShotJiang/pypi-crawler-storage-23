"""Abstract base for searchers."""

from __future__ import annotations

from abc import ABC, abstractmethod

from rootset.models import SearchResult
from rootset.storage.base import StorageBackend


class BaseSearcher(ABC):
    def __init__(self, storage: StorageBackend) -> None:
        self._storage = storage

    @abstractmethod
    async def search(self, query: str, top_k: int) -> list[SearchResult]: ...
