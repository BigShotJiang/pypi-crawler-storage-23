"""Tree-sitter S-expression pattern searcher."""

from __future__ import annotations

from pathlib import Path
from typing import Any, cast

from tree_sitter import Query, QueryCursor
from tree_sitter_language_pack import get_language, get_parser

from rootset.exceptions import LanguageNotSupportedError
from rootset.models import SearchResult
from rootset.search.base import BaseSearcher
from rootset.storage.base import StorageBackend


class StructuralSearcher(BaseSearcher):
    """Runs S-expression queries against indexed files and returns matching symbols."""

    def __init__(self, storage: StorageBackend, repo_root: Path) -> None:
        super().__init__(storage)
        self._repo_root = repo_root

    async def search(self, query: str, top_k: int) -> list[SearchResult]:
        # query format: "language:pattern" e.g. "python:(function_definition name: (identifier) @name)"
        if ":" not in query:
            return []
        language, pattern = query.split(":", 1)
        language = language.strip()
        pattern = pattern.strip()
        return await self.query(pattern, language, top_k)

    async def query(self, pattern: str, language: str, top_k: int = 10) -> list[SearchResult]:
        try:
            lang_obj = get_language(cast(Any, language))
            parser = get_parser(cast(Any, language))
            q = Query(lang_obj, pattern)
        except Exception as e:
            raise LanguageNotSupportedError(language) from e

        results: list[SearchResult] = []
        for path in self._repo_root.rglob("*"):
            if not path.is_file():
                continue
            from rootset.utils.language import detect_language
            if detect_language(path) != language:
                continue
            try:
                source = path.read_bytes()
                tree = parser.parse(source)
                captures = QueryCursor(q).captures(tree.root_node)
                all_nodes = [n for nodes in captures.values() for n in nodes]
                if not all_nodes:
                    continue
                file = await self._storage.get_file_by_path(str(path))
                if file is None:
                    continue
                for node in all_nodes[:top_k]:
                    line = node.start_point[0] + 1
                    syms = await self._storage.get_symbols_by_file(file.id)
                    for sym in syms:
                        if sym.line_start <= line <= sym.line_end:
                            results.append(
                                SearchResult(symbol=sym, score=1.0, search_type="structural")
                            )
                            break
            except Exception:
                continue

        return results[:top_k]
