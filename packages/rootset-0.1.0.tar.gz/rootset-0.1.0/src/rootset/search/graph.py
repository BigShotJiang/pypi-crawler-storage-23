"""Call graph traversal searcher using rustworkx."""

from __future__ import annotations

from rootset.indexing.graph import GraphIndexer
from rootset.models import SearchResult, Symbol
from rootset.search.base import BaseSearcher
from rootset.storage.base import StorageBackend


class GraphSearcher(BaseSearcher):
    def __init__(self, storage: StorageBackend, graph_indexer: GraphIndexer) -> None:
        super().__init__(storage)
        self._graph = graph_indexer

    async def search(self, query: str, top_k: int) -> list[SearchResult]:
        """Find symbols related to query via graph traversal from exact name match."""
        # Try to find a symbol matching the query by name
        sym = await self._storage.get_symbol_by_qname(query)
        if sym is None:
            # Try FTS fallback to find the symbol
            hits = await self._storage.fts_search(query, 1)
            if not hits:
                return []
            syms = await self._storage.get_symbols_by_ids([hits[0][0]])
            if not syms:
                return []
            sym = syms[0]

        callers = self._graph.find_callers(sym.id, depth=2)
        callees = self._graph.find_callees(sym.id, depth=2)
        all_ids = list(set(callers + callees))[:top_k]

        if not all_ids:
            return []

        symbols = await self._storage.get_symbols_by_ids(all_ids)
        results = []
        for s in symbols:
            score = 1.0 if s.id in callers else 0.8
            results.append(
                SearchResult(symbol=s, score=score, search_type="graph")
            )
        return sorted(results, key=lambda r: r.score, reverse=True)[:top_k]

    async def find_callers(self, symbol_id: int, depth: int = 1) -> list[Symbol]:
        ids = self._graph.find_callers(symbol_id, depth)
        return await self._storage.get_symbols_by_ids(ids)

    async def find_callees(self, symbol_id: int, depth: int = 1) -> list[Symbol]:
        ids = self._graph.find_callees(symbol_id, depth)
        return await self._storage.get_symbols_by_ids(ids)
