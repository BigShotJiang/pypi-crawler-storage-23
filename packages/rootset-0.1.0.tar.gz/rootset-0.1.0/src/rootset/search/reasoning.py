"""LLM reranking and graph-expansion reasoning retrieval."""

from __future__ import annotations

import json
from typing import Any

from rootset.models import SearchResult
from rootset.search.hybrid import HybridSearcher
from rootset.storage.base import StorageBackend


_RERANK_PROMPT = """\
You are a code search assistant. Given the user query and a list of candidate symbols,
rank the symbols by relevance and explain why each is relevant.

Query: {query}

Candidates:
{candidates}

Respond with a JSON array of objects in this exact format:
[
  {{"rank": 1, "qualified_name": "...", "explanation": "..."}},
  ...
]
Only include symbols you believe are relevant. Keep explanations under 30 words.
"""


class ReasoningSearcher:
    """LLM reranking over hybrid search results."""

    def __init__(
        self,
        storage: StorageBackend,
        hybrid: HybridSearcher,
        model: str,
        api_key: str | None,
        base_url: str,
    ) -> None:
        self._storage = storage
        self._hybrid = hybrid
        self._model = model
        self._api_key = api_key
        self._base_url = base_url

    async def search(self, query: str, top_k: int) -> list[SearchResult]:
        # Get hybrid candidates
        candidates = await self._hybrid.search(query, top_k * 2)
        if not candidates:
            return []

        # Build candidate text for LLM
        candidate_lines = []
        for i, r in enumerate(candidates, 1):
            sym = r.symbol
            doc = f" — {sym.docstring[:80]}" if sym.docstring else ""
            candidate_lines.append(
                f"{i}. {sym.qualified_name} ({sym.kind.value}): {sym.signature[:100]}{doc}"
            )

        prompt = _RERANK_PROMPT.format(
            query=query,
            candidates="\n".join(candidate_lines),
        )

        try:
            ranked = await self._call_llm(prompt)
        except Exception:
            # Fall back to hybrid results unchanged
            return [
                SearchResult(
                    symbol=r.symbol,
                    score=r.score,
                    search_type="reasoning",
                    explanation=None,
                )
                for r in candidates[:top_k]
            ]

        # Map back by qualified_name
        qname_map = {r.symbol.qualified_name: r for r in candidates}
        results: list[SearchResult] = []
        for item in ranked[:top_k]:
            qname = item.get("qualified_name", "")
            original = qname_map.get(qname)
            if original is None:
                continue
            results.append(
                SearchResult(
                    symbol=original.symbol,
                    score=1.0 / item.get("rank", len(results) + 1),
                    search_type="reasoning",
                    explanation=item.get("explanation"),
                )
            )
        return results

    async def _call_llm(self, prompt: str) -> list[dict[str, Any]]:
        from openai import AsyncOpenAI

        client = AsyncOpenAI(
            api_key=self._api_key or "none",
            base_url=self._base_url,
        )
        response = await client.chat.completions.create(
            model=self._model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            response_format={"type": "json_object"},
        )
        text = response.choices[0].message.content or "[]"
        parsed = json.loads(text)
        if isinstance(parsed, list):
            return parsed
        # Some models return {"results": [...]}
        for v in parsed.values():
            if isinstance(v, list):
                return v
        return []
