"""rootset — in-process code intelligence database."""

from rootset.config import Settings, get_settings
from rootset.exceptions import (
    EmbeddingError,
    GraphError,
    IndexingError,
    LanguageNotSupportedError,
    LSPError,
    RootsetError,
    SearchError,
    StorageError,
    SymbolNotFoundError,
)
from rootset.models import (
    CallEdge,
    CodeContext,
    File,
    ImportEdge,
    IndexStats,
    SearchMode,
    SearchResult,
    Symbol,
    SymbolKind,
)
from rootset.repository import Repository

__all__ = [
    "Repository",
    "Settings",
    "get_settings",
    # Models
    "File",
    "Symbol",
    "SymbolKind",
    "CallEdge",
    "ImportEdge",
    "SearchResult",
    "CodeContext",
    "IndexStats",
    "SearchMode",
    # Exceptions
    "RootsetError",
    "IndexingError",
    "StorageError",
    "SearchError",
    "SymbolNotFoundError",
    "LanguageNotSupportedError",
    "EmbeddingError",
    "LSPError",
    "GraphError",
]
