"""Pydantic data models for rootset."""

from __future__ import annotations

from datetime import datetime
from enum import Enum

from pydantic import BaseModel


class SymbolKind(str, Enum):
    FUNCTION = "function"
    METHOD = "method"
    CLASS = "class"
    VARIABLE = "variable"
    MODULE = "module"


class SearchMode(str, Enum):
    TEXT = "text"
    SEMANTIC = "semantic"
    STRUCTURAL = "structural"
    GRAPH = "graph"
    HYBRID = "hybrid"
    REASONING = "reasoning"


class File(BaseModel):
    id: int
    path: str
    language: str
    content_hash: str
    last_indexed: datetime


class Symbol(BaseModel):
    id: int
    file_id: int
    name: str
    qualified_name: str
    kind: SymbolKind
    line_start: int
    line_end: int
    signature: str
    docstring: str | None
    content: str


class CallEdge(BaseModel):
    caller_id: int
    callee_name: str
    callee_id: int | None
    call_site_line: int


class ImportEdge(BaseModel):
    file_id: int
    imported_module: str
    symbol_name: str | None
    alias: str | None


class SearchResult(BaseModel):
    symbol: Symbol
    score: float
    search_type: str
    explanation: str | None = None


class CodeContext(BaseModel):
    symbol: Symbol
    definition_file: File
    callers: list[Symbol]
    callees: list[Symbol]
    related_symbols: list[Symbol]
    import_chain: list[str]


class IndexStats(BaseModel):
    files_indexed: int
    symbols_indexed: int
    call_edges_indexed: int
    import_edges_indexed: int
    files_skipped: int
