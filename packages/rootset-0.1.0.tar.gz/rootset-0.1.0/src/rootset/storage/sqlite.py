"""aiosqlite storage backend."""

from __future__ import annotations

import sqlite3
import struct
from datetime import datetime, timezone
from pathlib import Path

import aiosqlite
import sqlite_vec  # type: ignore[import-untyped]

from rootset.exceptions import StorageError
from rootset.models import CallEdge, File, ImportEdge, Symbol, SymbolKind
from typing import Any
from rootset.storage.base import StorageBackend
from rootset.storage.schema import FTS_DDL, SCHEMA_DDL, vec_ddl


class SQLiteBackend(StorageBackend):
    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path
        self._db: aiosqlite.Connection | None = None

    async def initialize(self, embedding_dimensions: int) -> None:
        sqlite3.register_adapter(datetime, lambda dt: dt.isoformat())
        sqlite3.register_converter("TIMESTAMP", lambda b: datetime.fromisoformat(b.decode()))
        self._db = await aiosqlite.connect(self._db_path, detect_types=sqlite3.PARSE_DECLTYPES)
        self._db.row_factory = aiosqlite.Row
        await self._db.execute("PRAGMA journal_mode=WAL")
        await self._db.execute("PRAGMA foreign_keys=ON")

        # Load sqlite-vec extension
        await self._db.enable_load_extension(True)
        await self._db.load_extension(sqlite_vec.loadable_path())
        await self._db.enable_load_extension(False)

        # Apply schema (simple statements, safe to split on ;)
        for stmt in SCHEMA_DDL.strip().split(";"):
            stmt = stmt.strip()
            if stmt:
                await self._db.execute(stmt)

        # FTS virtual table + triggers — use executescript to handle ; inside trigger bodies
        try:
            await self._db.executescript(FTS_DDL)
        except Exception:
            pass  # tables/triggers may already exist

        # Vector table
        await self._db.execute(vec_ddl(embedding_dimensions))
        await self._db.commit()

    async def close(self) -> None:
        if self._db:
            await self._db.close()
            self._db = None

    def _conn(self) -> aiosqlite.Connection:
        if self._db is None:
            raise StorageError("Database not initialized — call initialize() first")
        return self._db

    # --- Files ---

    async def upsert_file(self, path: str, language: str, content_hash: str) -> File:
        db = self._conn()
        now = datetime.now(timezone.utc)
        await db.execute(
            """
            INSERT INTO files (path, language, content_hash, last_indexed)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(path) DO UPDATE SET
                language=excluded.language,
                content_hash=excluded.content_hash,
                last_indexed=excluded.last_indexed
            """,
            (path, language, content_hash, now),
        )
        await db.commit()
        async with db.execute("SELECT * FROM files WHERE path = ?", (path,)) as cur:
            row = await cur.fetchone()
        assert row is not None
        return _file_from_row(row)

    async def get_file_by_path(self, path: str) -> File | None:
        async with self._conn().execute(
            "SELECT * FROM files WHERE path = ?", (path,)
        ) as cur:
            row = await cur.fetchone()
        return _file_from_row(row) if row else None

    async def delete_file_symbols(self, file_id: int) -> None:
        db = self._conn()
        await db.execute("DELETE FROM symbols WHERE file_id = ?", (file_id,))
        await db.execute("DELETE FROM import_edges WHERE file_id = ?", (file_id,))
        await db.commit()

    # --- Symbols ---

    async def insert_symbols(self, symbols: list[dict[str, Any]]) -> list[int]:
        db = self._conn()
        ids: list[int] = []
        for sym in symbols:
            async with db.execute(
                """
                INSERT INTO symbols
                    (file_id, name, qualified_name, kind, line_start, line_end,
                     signature, docstring, content)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    sym["file_id"],
                    sym["name"],
                    sym["qualified_name"],
                    sym["kind"],
                    sym["line_start"],
                    sym["line_end"],
                    sym["signature"],
                    sym.get("docstring"),
                    sym["content"],
                ),
            ) as cur:
                ids.append(cur.lastrowid)  # type: ignore[arg-type]
        await db.commit()
        return ids

    async def get_symbol_by_qname(self, qualified_name: str) -> Symbol | None:
        async with self._conn().execute(
            "SELECT * FROM symbols WHERE qualified_name = ?", (qualified_name,)
        ) as cur:
            row = await cur.fetchone()
        return _symbol_from_row(row) if row else None

    async def find_symbols_by_qname_suffix(self, suffix: str) -> list[Symbol]:
        """Return symbols whose qualified_name ends with '.{suffix}' or equals suffix."""
        async with self._conn().execute(
            "SELECT * FROM symbols WHERE qualified_name = ? OR qualified_name LIKE ?",
            (suffix, f"%.{suffix}"),
        ) as cur:
            rows = await cur.fetchall()
        return [_symbol_from_row(r) for r in rows]

    async def get_symbols_by_file(self, file_id: int) -> list[Symbol]:
        async with self._conn().execute(
            "SELECT * FROM symbols WHERE file_id = ?", (file_id,)
        ) as cur:
            rows = await cur.fetchall()
        return [_symbol_from_row(r) for r in rows]

    async def get_symbols_by_ids(self, ids: list[int]) -> list[Symbol]:
        if not ids:
            return []
        placeholders = ",".join("?" * len(ids))
        async with self._conn().execute(
            f"SELECT * FROM symbols WHERE id IN ({placeholders})", ids
        ) as cur:
            rows = await cur.fetchall()
        return [_symbol_from_row(r) for r in rows]

    # --- Edges ---

    async def insert_call_edges(self, edges: list[dict[str, Any]]) -> None:
        db = self._conn()
        await db.executemany(
            """
            INSERT INTO call_edges (caller_id, callee_name, callee_id, call_site_line)
            VALUES (:caller_id, :callee_name, :callee_id, :call_site_line)
            """,
            edges,
        )
        await db.commit()

    async def insert_import_edges(self, edges: list[dict[str, Any]]) -> None:
        db = self._conn()
        await db.executemany(
            """
            INSERT INTO import_edges (file_id, imported_module, symbol_name, alias)
            VALUES (:file_id, :imported_module, :symbol_name, :alias)
            """,
            edges,
        )
        await db.commit()

    async def resolve_call_edges(self, file_id: int) -> None:
        """Resolve callee_id for unresolved call edges in a file's symbols.

        Only resolves unambiguous matches: qualified_name ends exactly with
        '.<callee_name>' AND there is exactly one such symbol. Skips dunder
        names like __init__ which are too ambiguous to resolve by name alone.
        """
        db = self._conn()
        await db.execute(
            """
            UPDATE call_edges SET callee_id = (
                SELECT id FROM symbols
                WHERE qualified_name LIKE '%.' || call_edges.callee_name
                  AND call_edges.callee_name NOT GLOB '__*'
                LIMIT 1
            )
            WHERE callee_id IS NULL
              AND caller_id IN (SELECT id FROM symbols WHERE file_id = ?)
              AND call_edges.callee_name NOT GLOB '__*'
              AND (
                SELECT COUNT(*) FROM symbols
                WHERE qualified_name LIKE '%.' || call_edges.callee_name
              ) = 1
            """,
            (file_id,),
        )
        await db.commit()

    async def get_call_edges_for_symbol(self, symbol_id: int) -> list[CallEdge]:
        async with self._conn().execute(
            "SELECT * FROM call_edges WHERE caller_id = ?", (symbol_id,)
        ) as cur:
            rows = await cur.fetchall()
        return [
            CallEdge(
                caller_id=r["caller_id"],
                callee_name=r["callee_name"],
                callee_id=r["callee_id"],
                call_site_line=r["call_site_line"],
            )
            for r in rows
        ]

    async def get_import_edges_for_file(self, file_id: int) -> list[ImportEdge]:
        async with self._conn().execute(
            "SELECT * FROM import_edges WHERE file_id = ?", (file_id,)
        ) as cur:
            rows = await cur.fetchall()
        return [
            ImportEdge(
                file_id=r["file_id"],
                imported_module=r["imported_module"],
                symbol_name=r["symbol_name"],
                alias=r["alias"],
            )
            for r in rows
        ]

    async def update_call_edge_callee(
        self,
        caller_id: int,
        call_site_line: int,
        callee_id: int,
        *,
        callee_name: str | None = None,
    ) -> None:
        db = self._conn()
        if callee_name is not None:
            await db.execute(
                "UPDATE call_edges SET callee_id = ? "
                "WHERE caller_id = ? AND call_site_line = ? AND callee_name = ? AND callee_id IS NULL",
                (callee_id, caller_id, call_site_line, callee_name),
            )
        else:
            await db.execute(
                "UPDATE call_edges SET callee_id = ? "
                "WHERE caller_id = ? AND call_site_line = ? AND callee_id IS NULL",
                (callee_id, caller_id, call_site_line),
            )
        await db.commit()

    async def get_all_resolved_call_edges(self) -> list[tuple[int, int]]:
        async with self._conn().execute(
            "SELECT caller_id, callee_id FROM call_edges WHERE callee_id IS NOT NULL"
        ) as cur:
            rows = await cur.fetchall()
        return [(r["caller_id"], r["callee_id"]) for r in rows]

    # --- Graph ---

    async def insert_graph_edges(self, edges: list[tuple[int, int, str]]) -> None:
        db = self._conn()
        await db.execute("DELETE FROM graph_edges")
        await db.executemany(
            "INSERT INTO graph_edges (source_id, target_id, edge_type) VALUES (?, ?, ?)",
            edges,
        )
        await db.commit()

    async def get_all_graph_edges(self) -> list[tuple[int, int, str]]:
        async with self._conn().execute(
            "SELECT source_id, target_id, edge_type FROM graph_edges"
        ) as cur:
            rows = await cur.fetchall()
        return [(r["source_id"], r["target_id"], r["edge_type"]) for r in rows]

    # --- Embeddings ---

    async def insert_embeddings(
        self, symbol_ids: list[int], embeddings: list[list[float]]
    ) -> None:
        db = self._conn()
        for sid, emb in zip(symbol_ids, embeddings):
            blob = _serialize_float_list(emb)
            await db.execute(
                "INSERT OR REPLACE INTO symbol_embeddings(symbol_id, embedding) VALUES (?, ?)",
                (sid, blob),
            )
        await db.commit()

    # --- Search ---

    async def fts_search(self, query: str, top_k: int) -> list[tuple[int, float]]:
        fts_query = _build_fts_query(query)
        try:
            async with self._conn().execute(
                """
                SELECT rowid, bm25(symbols_fts) AS score
                FROM symbols_fts
                WHERE symbols_fts MATCH ?
                ORDER BY score
                LIMIT ?
                """,
                (fts_query, top_k),
            ) as cur:
                rows = await cur.fetchall()
        except Exception:
            return []
        # bm25 returns negative values; negate for ascending relevance
        return [(r["rowid"], -r["score"]) for r in rows]

    async def vec_search(
        self, embedding: list[float], top_k: int
    ) -> list[tuple[int, float]]:
        blob = _serialize_float_list(embedding)
        async with self._conn().execute(
            """
            SELECT symbol_id, distance
            FROM symbol_embeddings
            WHERE embedding MATCH ?
              AND k = ?
            ORDER BY distance
            """,
            (blob, top_k),
        ) as cur:
            rows = await cur.fetchall()
        return [(r["symbol_id"], r["distance"]) for r in rows]

    # --- Stats ---

    async def get_counts(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for table in ("files", "symbols", "call_edges", "import_edges"):
            async with self._conn().execute(f"SELECT COUNT(*) FROM {table}") as cur:
                row = await cur.fetchone()
            counts[table] = row[0] if row else 0
        return counts


# --- Helpers ---

_FTS_SPECIAL = set('"\'()[]{}:*^~-+')


def _build_fts_query(query: str) -> str:
    """Convert a natural-language query to an FTS5 OR query of quoted tokens."""
    # Strip FTS special chars, split into tokens, join with OR
    tokens = []
    for token in query.split():
        clean = "".join(c for c in token if c not in _FTS_SPECIAL)
        if clean:
            tokens.append(f'"{clean}"')
    if not tokens:
        return '""'
    return " OR ".join(tokens)


def _file_from_row(row: aiosqlite.Row) -> File:
    return File(
        id=row["id"],
        path=row["path"],
        language=row["language"],
        content_hash=row["content_hash"],
        last_indexed=row["last_indexed"] if isinstance(row["last_indexed"], datetime) else datetime.fromisoformat(str(row["last_indexed"])),
    )


def _symbol_from_row(row: aiosqlite.Row) -> Symbol:
    return Symbol(
        id=row["id"],
        file_id=row["file_id"],
        name=row["name"],
        qualified_name=row["qualified_name"],
        kind=SymbolKind(row["kind"]),
        line_start=row["line_start"],
        line_end=row["line_end"],
        signature=row["signature"],
        docstring=row["docstring"],
        content=row["content"],
    )


def _serialize_float_list(values: list[float]) -> bytes:
    return struct.pack(f"{len(values)}f", *values)
