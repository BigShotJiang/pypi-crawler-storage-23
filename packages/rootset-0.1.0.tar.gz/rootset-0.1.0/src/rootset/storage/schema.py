"""DDL for all SQLite tables including FTS5 and sqlite-vec virtual tables."""

from __future__ import annotations

SCHEMA_DDL = """\
CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY,
    path TEXT UNIQUE NOT NULL,
    language TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    last_indexed TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS symbols (
    id INTEGER PRIMARY KEY,
    file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    qualified_name TEXT NOT NULL,
    kind TEXT NOT NULL,
    line_start INTEGER NOT NULL,
    line_end INTEGER NOT NULL,
    signature TEXT NOT NULL,
    docstring TEXT,
    content TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS call_edges (
    id INTEGER PRIMARY KEY,
    caller_id INTEGER NOT NULL REFERENCES symbols(id) ON DELETE CASCADE,
    callee_name TEXT NOT NULL,
    callee_id INTEGER REFERENCES symbols(id) ON DELETE SET NULL,
    call_site_line INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS import_edges (
    id INTEGER PRIMARY KEY,
    file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    imported_module TEXT NOT NULL,
    symbol_name TEXT,
    alias TEXT
);

CREATE TABLE IF NOT EXISTS graph_edges (
    id INTEGER PRIMARY KEY,
    source_id INTEGER NOT NULL,
    target_id INTEGER NOT NULL,
    edge_type TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_symbols_file ON symbols(file_id);
CREATE INDEX IF NOT EXISTS idx_symbols_qname ON symbols(qualified_name);
CREATE INDEX IF NOT EXISTS idx_call_caller ON call_edges(caller_id);
CREATE INDEX IF NOT EXISTS idx_call_callee ON call_edges(callee_id);
CREATE INDEX IF NOT EXISTS idx_graph_source ON graph_edges(source_id);
CREATE INDEX IF NOT EXISTS idx_graph_target ON graph_edges(target_id);
"""

FTS_DDL = """\
CREATE VIRTUAL TABLE IF NOT EXISTS symbols_fts USING fts5(
    name,
    qualified_name,
    signature,
    docstring,
    content,
    tokenize='porter unicode61',
    content=symbols,
    content_rowid=id
);

CREATE TRIGGER IF NOT EXISTS symbols_ai AFTER INSERT ON symbols BEGIN
    INSERT INTO symbols_fts(rowid, name, qualified_name, signature, docstring, content)
    VALUES (new.id, new.name, new.qualified_name, new.signature, new.docstring, new.content);
END;

CREATE TRIGGER IF NOT EXISTS symbols_ad AFTER DELETE ON symbols BEGIN
    INSERT INTO symbols_fts(symbols_fts, rowid, name, qualified_name, signature, docstring, content)
    VALUES ('delete', old.id, old.name, old.qualified_name, old.signature, old.docstring, old.content);
END;

CREATE TRIGGER IF NOT EXISTS symbols_au AFTER UPDATE ON symbols BEGIN
    INSERT INTO symbols_fts(symbols_fts, rowid, name, qualified_name, signature, docstring, content)
    VALUES ('delete', old.id, old.name, old.qualified_name, old.signature, old.docstring, old.content);
    INSERT INTO symbols_fts(rowid, name, qualified_name, signature, docstring, content)
    VALUES (new.id, new.name, new.qualified_name, new.signature, new.docstring, new.content);
END;
"""


def vec_ddl(dimensions: int) -> str:
    return f"""\
CREATE VIRTUAL TABLE IF NOT EXISTS symbol_embeddings USING vec0(
    symbol_id INTEGER PRIMARY KEY,
    embedding FLOAT[{dimensions}]
);
"""
