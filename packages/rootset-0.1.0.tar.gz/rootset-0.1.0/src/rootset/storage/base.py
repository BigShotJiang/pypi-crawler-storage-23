"""Abstract base for storage backends."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from rootset.models import CallEdge, File, ImportEdge, Symbol


class StorageBackend(ABC):
    @abstractmethod
    async def initialize(self, embedding_dimensions: int) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...

    # Files
    @abstractmethod
    async def upsert_file(
        self, path: str, language: str, content_hash: str
    ) -> File: ...

    @abstractmethod
    async def get_file_by_path(self, path: str) -> File | None: ...

    @abstractmethod
    async def delete_file_symbols(self, file_id: int) -> None: ...

    # Symbols
    @abstractmethod
    async def insert_symbols(self, symbols: list[dict[str, Any]]) -> list[int]: ...

    @abstractmethod
    async def get_symbol_by_qname(self, qualified_name: str) -> Symbol | None: ...

    @abstractmethod
    async def find_symbols_by_qname_suffix(self, suffix: str) -> list[Symbol]: ...

    @abstractmethod
    async def get_symbols_by_file(self, file_id: int) -> list[Symbol]: ...

    @abstractmethod
    async def get_symbols_by_ids(self, ids: list[int]) -> list[Symbol]: ...

    # Edges
    @abstractmethod
    async def insert_call_edges(self, edges: list[dict[str, Any]]) -> None: ...

    @abstractmethod
    async def insert_import_edges(self, edges: list[dict[str, Any]]) -> None: ...

    @abstractmethod
    async def resolve_call_edges(self, file_id: int) -> None: ...

    @abstractmethod
    async def get_call_edges_for_symbol(self, symbol_id: int) -> list[CallEdge]: ...

    @abstractmethod
    async def get_import_edges_for_file(self, file_id: int) -> list[ImportEdge]: ...

    @abstractmethod
    async def get_all_resolved_call_edges(self) -> list[tuple[int, int]]: ...

    @abstractmethod
    async def update_call_edge_callee(
        self,
        caller_id: int,
        call_site_line: int,
        callee_id: int,
        *,
        callee_name: str | None = None,
    ) -> None: ...

    # Graph persistence
    @abstractmethod
    async def insert_graph_edges(self, edges: list[tuple[int, int, str]]) -> None: ...

    @abstractmethod
    async def get_all_graph_edges(self) -> list[tuple[int, int, str]]: ...

    # Embeddings
    @abstractmethod
    async def insert_embeddings(
        self, symbol_ids: list[int], embeddings: list[list[float]]
    ) -> None: ...

    # Search
    @abstractmethod
    async def fts_search(self, query: str, top_k: int) -> list[tuple[int, float]]: ...

    @abstractmethod
    async def vec_search(
        self, embedding: list[float], top_k: int
    ) -> list[tuple[int, float]]: ...

    # Stats
    @abstractmethod
    async def get_counts(self) -> dict[str, int]: ...
