import asyncio
from pathlib import Path
from rootset import Repository, SearchMode, get_settings


async def main():
    settings = get_settings()  # reads ROOTSET_* from .env
    repo = Repository(settings)

    async with repo:
        stats = await repo.index(Path(__file__).parent / "src", incremental=False)
        print(stats)

        results = await repo.search("function that builds call graph", mode=SearchMode.HYBRID)
        for r in results:
            print(f"  [{r.score:.4f}] {r.symbol.qualified_name}")

        ctx = await repo.get_context("Repository.index")
        print(f"\ncallers: {[s.qualified_name for s in ctx.callers]}")
        print(f"callees: {[s.qualified_name for s in ctx.callees]}")


asyncio.run(main())
