from .values import BASE_RESOLUTION, BASE_HEIGHT, BASE_WIDTH, DEFAULT_FPS

__all__ = [
    "BASE_RESOLUTION", 
    "BASE_HEIGHT",
    "BASE_WIDTH",
    "DEFAULT_FPS"
]