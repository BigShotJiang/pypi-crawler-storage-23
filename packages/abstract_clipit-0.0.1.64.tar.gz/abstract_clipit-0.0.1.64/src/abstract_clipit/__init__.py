from .main import clipitTab
from abstract_gui.QT6.utils.console_utils import startConsole,ConsoleBase

def startClipitConsole():
    startConsole(clipitTab)
