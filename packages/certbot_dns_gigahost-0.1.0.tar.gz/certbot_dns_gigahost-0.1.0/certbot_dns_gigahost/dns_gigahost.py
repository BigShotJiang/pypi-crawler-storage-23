"""Gigahost DNS Authenticator plugin for Certbot.

This plugin automates the process of completing a ``dns-01`` challenge by
creating, and subsequently removing, TXT records using the Gigahost API.

.. seealso::
   https://gigahost.no/api-dokumentasjon

"""
import logging
from typing import Any, Optional

import requests
from certbot import errors
from certbot.plugins import dns_common

logger = logging.getLogger(__name__)

API_BASE_URL = "https://api.gigahost.no/api/v0"


class Authenticator(dns_common.DNSAuthenticator):
    """Gigahost DNS Authenticator.

    This plugin automates the process of completing a ``dns-01`` challenge by
    creating, and subsequently removing, TXT records using the Gigahost API.
    """

    description = "Obtain certificates using a DNS TXT record (if you are using Gigahost for DNS)."

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.credentials: Optional[dns_common.CredentialsConfiguration] = None

    @classmethod
    def add_parser_arguments(cls, add: Any) -> None:
        super().add_parser_arguments(add, default_propagation_seconds=120)
        add("credentials", help="Gigahost credentials INI file.")

    def more_info(self) -> str:
        return (
            "This plugin configures a DNS TXT record to respond to a dns-01 challenge "
            "using the Gigahost API."
        )

    def _setup_credentials(self) -> None:
        self.credentials = self._configure_credentials(
            "credentials",
            "Gigahost credentials INI file",
            {
                "username": "Username (email) for Gigahost API",
                "password": "Password for Gigahost API",
            },
        )

    def _perform(self, domain: str, validation_name: str, validation: str) -> None:
        self._get_client().add_txt_record(domain, validation_name, validation)

    def _cleanup(self, domain: str, validation_name: str, validation: str) -> None:
        self._get_client().del_txt_record(domain, validation_name, validation)

    def _get_client(self) -> "_GigahostClient":
        if self.credentials is None:
            raise errors.PluginError("Plugin has not been prepared.")
        return _GigahostClient(
            self.credentials.conf("username"),
            self.credentials.conf("password"),
        )


class _GigahostClient:
    """Wrapper around the Gigahost API.

    Uses HTTP Basic Auth for all requests.
    """

    def __init__(self, username: str, password: str) -> None:
        self.session = requests.Session()
        self.session.auth = (username, password)
        self.session.headers.update({"Content-Type": "application/json"})

    def _api_request(self, method: str, endpoint: str, **kwargs: Any) -> Any:
        url = f"{API_BASE_URL}{endpoint}"
        logger.debug("Gigahost API request: %s %s", method, url)
        resp = self.session.request(method, url, **kwargs)
        logger.debug("Gigahost API response: %s %s", resp.status_code, resp.text[:500])

        if resp.status_code not in (200, 201):
            raise errors.PluginError(
                f"Gigahost API error ({resp.status_code}): {resp.text}"
            )
        return resp.json()

    def _find_zone_id(self, domain: str) -> tuple[str, str]:
        """Find the zone_id for a given FQDN.

        Walks up the domain hierarchy to find the matching zone.
        Returns (zone_id, zone_name).
        """
        data = self._api_request("GET", "/dns/zones")
        zones = data.get("data", [])

        # Build a dict of zone_name -> zone_id for quick lookup
        zone_map = {}
        for zone in zones:
            zone_map[zone["zone_name"]] = zone["zone_id"]

        # Walk up the domain hierarchy to find the zone
        domain_parts = domain.rstrip(".").split(".")
        for i in range(len(domain_parts)):
            candidate = ".".join(domain_parts[i:])
            if candidate in zone_map:
                return zone_map[candidate], candidate

        raise errors.PluginError(
            f"Could not find a Gigahost DNS zone for domain: {domain}"
        )

    def add_txt_record(self, domain: str, record_name: str, record_content: str) -> None:
        """Add a TXT record for the ACME challenge.

        :param domain: The base domain being validated.
        :param record_name: The full FQDN for the TXT record (e.g. _acme-challenge.example.com).
        :param record_content: The validation string to set as the TXT record value.
        """
        zone_id, zone_name = self._find_zone_id(record_name)

        # Compute the record name relative to the zone
        relative_name = self._relative_name(record_name, zone_name)

        logger.debug(
            "Adding TXT record: zone_id=%s, name=%s, value=%s",
            zone_id, relative_name, record_content,
        )

        self._api_request(
            "POST",
            f"/dns/zones/{zone_id}/records",
            json={
                "record_name": relative_name,
                "record_type": "TXT",
                "record_value": record_content,
                "record_ttl": 60,
            },
        )

    def del_txt_record(self, domain: str, record_name: str, record_content: str) -> None:
        """Delete the TXT record used for the ACME challenge.

        :param domain: The base domain being validated.
        :param record_name: The full FQDN for the TXT record.
        :param record_content: The validation string that was set.
        """
        zone_id, zone_name = self._find_zone_id(record_name)
        relative_name = self._relative_name(record_name, zone_name)

        # Find the matching record
        data = self._api_request("GET", f"/dns/zones/{zone_id}/records")
        records = data.get("data", [])

        for record in records:
            if (
                record.get("record_type") == "TXT"
                and record.get("record_name") == relative_name
                and record.get("record_value", "").strip('"') == record_content
            ):
                record_id = record["record_id"]
                logger.debug(
                    "Deleting TXT record: zone_id=%s, record_id=%s, name=%s",
                    zone_id, record_id, relative_name,
                )
                self._api_request(
                    "DELETE",
                    f"/dns/zones/{zone_id}/records/{record_id}",
                    params={"name": relative_name, "type": "TXT"},
                )
                return

        logger.warning(
            "Could not find TXT record to delete: name=%s, value=%s",
            relative_name, record_content,
        )

    @staticmethod
    def _relative_name(fqdn: str, zone_name: str) -> str:
        """Compute the record name relative to the zone.

        e.g. _acme-challenge.example.com relative to example.com -> _acme-challenge
             _acme-challenge.sub.example.com relative to example.com -> _acme-challenge.sub
        """
        fqdn = fqdn.rstrip(".")
        zone_name = zone_name.rstrip(".")

        if fqdn == zone_name:
            return "@"

        if fqdn.endswith("." + zone_name):
            return fqdn[: -(len(zone_name) + 1)]

        return fqdn
