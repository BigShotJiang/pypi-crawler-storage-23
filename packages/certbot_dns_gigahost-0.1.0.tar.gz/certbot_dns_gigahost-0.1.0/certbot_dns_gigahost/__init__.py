"""Gigahost DNS Authenticator plugin for Certbot."""
