# certbot-dns-gigahost

[Gigahost](https://gigahost.no) DNS Authenticator plugin for [Certbot](https://certbot.eff.org/).

This plugin automates the process of completing a `dns-01` challenge by creating, and subsequently removing, TXT records using the [Gigahost API](https://gigahost.no/api-dokumentasjon).

## Named Arguments

| Argument | Description |
|---|---|
| `--dns-gigahost-credentials` | Gigahost credentials INI file. **(required)** |
| `--dns-gigahost-propagation-seconds` | The number of seconds to wait for DNS to propagate before asking the ACME server to verify the DNS record. (Default: 120) |

## Installation

```bash
pip install certbot-dns-gigahost
```

## Credentials

Use of this plugin requires a configuration file containing your Gigahost account credentials.

See the [Gigahost API documentation](https://gigahost.no/api-dokumentasjon) for more information.

An example `credentials.ini` file:

```ini
dns_gigahost_username=user@example.com
dns_gigahost_password=yourpassword
```

The path to this file can be provided interactively or using the `--dns-gigahost-credentials` command-line argument. Certbot records the path to this file for use during renewal, but does not store the file's contents.

> **CAUTION:** You should protect these credentials as you would the password to your Gigahost account. Users who can read this file can use these credentials to issue arbitrary API calls on your behalf. Users who can cause Certbot to run using these credentials can complete a `dns-01` challenge to acquire new certificates or revoke existing certificates for associated domains, even if those domains aren't being managed by this server.

Certbot will emit a warning if it detects that the credentials file can be accessed by other users on your system. The warning reads "Unsafe permissions on credentials configuration file", followed by the path to the credentials file. This warning will be emitted each time Certbot uses the credentials file, including for renewal, and cannot be silenced except by addressing the issue (e.g., by using a command like `chmod 600` to restrict access to the file).

## Examples

### Acquire a certificate

To acquire a single certificate for both `example.com` and `www.example.com`, waiting 120 seconds (the default) for DNS propagation:

```bash
certbot certonly \
  --authenticator dns-gigahost \
  --dns-gigahost-credentials ~/.secrets/certbot/gigahost.ini \
  --dns-gigahost-propagation-seconds 120 \
  -d example.com \
  -d www.example.com
```

### Wildcard certificate

```bash
certbot certonly \
  --authenticator dns-gigahost \
  --dns-gigahost-credentials ~/.secrets/certbot/gigahost.ini \
  -d example.com \
  -d "*.example.com"
```

### Secure your credentials file

```bash
mkdir -p ~/.secrets/certbot
chmod 700 ~/.secrets/certbot

cat > ~/.secrets/certbot/gigahost.ini << EOF
dns_gigahost_username=user@example.com
dns_gigahost_password=yourpassword
EOF

chmod 600 ~/.secrets/certbot/gigahost.ini
```

## Docker

A Docker image can be built from the included Dockerfile:

```bash
docker build -t certbot-dns-gigahost .
```

Example usage:

```bash
docker run --rm \
  -v /etc/letsencrypt:/etc/letsencrypt \
  -v /var/lib/letsencrypt:/var/lib/letsencrypt \
  certbot-dns-gigahost \
  certonly \
  --authenticator dns-gigahost \
  --dns-gigahost-credentials /etc/letsencrypt/gigahost.ini \
  --agree-tos \
  --email "email@example.com" \
  -d example.com
```

## Automatic renewal

Certbot will automatically use the plugin and credentials file during renewal. No additional configuration is needed after the initial certificate issuance. You can test renewal with:

```bash
certbot renew --dry-run
```

## How it works

1. When Certbot needs to validate domain ownership, the plugin authenticates with the Gigahost API using HTTP Basic Auth.
2. It looks up the DNS zone for the domain being validated.
3. It creates a `_acme-challenge` TXT record with the validation token.
4. After Certbot verifies the challenge, the plugin removes the TXT record.

## Development

```bash
# Clone the repository
git clone https://github.com/gigahost/certbot-dns-gigahost.git
cd certbot-dns-gigahost

# Install in development mode
pip install -e .

# Verify the plugin is recognized by certbot
certbot plugins
```

## License

Apache License 2.0. See [LICENSE](LICENSE) for details.
