<<<<<<< HEAD
# metu-class-auto
Python CLI tool to manage ODTUClass resources
=======
# odtuclass

CLI tool to sync [ODTUClass](https://odtuclass.metu.edu.tr) course files to your local machine.

Downloads PDFs, slides, homeworks, and any other files from your enrolled courses. Tracks changes so subsequent syncs only download new or updated files.

## Install

```bash
pip install odtuclass
```

Requires Python 3.11+.

## Quick start

```bash
# Log in with your METU credentials
odtuclass login

# See your courses
odtuclass courses

# Download everything
odtuclass sync
```

Files are saved to `~/odtuclass/` by default, organized by course and section:

```
~/odtuclass/
  CENG 334 Section 1/
    Week 01 - Introduction/
      slides.pdf
    Week 02 - Processes/
      slides.pdf
      notes.pdf
  CENG 596 Section 1/
    General/
      syllabus.pdf
    ...
```

## Commands

### `odtuclass login`

Authenticate with your METU username and password. Stores a session token locally — you only need to do this once (or again if your password changes).

```bash
odtuclass login
```

### `odtuclass courses`

List all your enrolled courses.

```bash
odtuclass courses
```

### `odtuclass ls <course>`

Show files available in a course. You can use the course shortname or ID.

```bash
odtuclass ls "CENG 334 Section 1"
odtuclass ls 3100
```

### `odtuclass sync [course]`

Download new and updated files. Omit the course to sync all courses.

```bash
# Sync a specific course
odtuclass sync "CENG 334 Section 1"

# Sync all courses
odtuclass sync

# Preview what would be downloaded
odtuclass sync --dry-run

# Overwrite locally modified files
odtuclass sync --force

# Download to a specific directory
odtuclass sync --sync-dir ~/Documents/courses
```

### `odtuclass config [key] [value]`

View or change configuration.

```bash
# Show all config
odtuclass config

# Set sync directory
odtuclass config sync.directory ~/Documents/courses
```

## Configuration

Config is stored at `~/.config/odtuclass/config.toml`.

### Sync directory

Where files are downloaded to (default: `~/odtuclass`). Set it with any of these (highest priority first):

1. `--sync-dir` flag
2. `ODTUCLASS_SYNC_DIR` environment variable
3. `odtuclass config sync.directory <path>`

### Environment variables

You can set these in a `.env` file (in your working directory or `~/.config/odtuclass/.env`):

```bash
ODTUCLASS_USERNAME=e123456
ODTUCLASS_PASSWORD=your_password
ODTUCLASS_SYNC_DIR=~/odtuclass
```

When `ODTUCLASS_USERNAME` and `ODTUCLASS_PASSWORD` are set, `odtuclass login` won't prompt for input — useful for automation.

## How sync works

1. Fetches the file list from ODTUClass for each course
2. Compares against a local manifest (SQLite database) to find new/updated files
3. Downloads changes concurrently, writing to temp files and renaming on success
4. Files with local modifications are skipped as conflicts (use `--force` to overwrite)

Running `odtuclass sync` a second time is a no-op if nothing changed on ODTUClass.

## License

MIT
>>>>>>> d8f4fd6 (Initial release)
