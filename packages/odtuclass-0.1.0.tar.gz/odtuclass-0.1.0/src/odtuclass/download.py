"""Async file downloads with SHA-256 hashing and .part temp files."""

from __future__ import annotations

import hashlib
from pathlib import Path

import httpx


async def download_file(
    client: httpx.AsyncClient,
    url: str,
    dest: Path,
) -> str:
    """Download a file to dest, returning its SHA-256 hash.

    Writes to a .part file first, then renames on success.
    """
    dest.parent.mkdir(parents=True, exist_ok=True)
    part_path = dest.with_suffix(dest.suffix + ".part")

    sha = hashlib.sha256()
    try:
        async with client.stream("GET", url, follow_redirects=True) as resp:
            resp.raise_for_status()
            with open(part_path, "wb") as f:
                async for chunk in resp.aiter_bytes(chunk_size=65536):
                    f.write(chunk)
                    sha.update(chunk)
    except BaseException:
        part_path.unlink(missing_ok=True)
        raise

    part_path.rename(dest)
    return sha.hexdigest()
