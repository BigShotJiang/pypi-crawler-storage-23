"""Login flow: get token from Moodle, store in config."""

from __future__ import annotations

import getpass
import json
import os
import sys
import urllib.parse
import urllib.request

from odtuclass.config import (
    API_ENDPOINT,
    SERVICE_NAME,
    TOKEN_ENDPOINT,
    load_config,
    save_config,
)


def cmd_login() -> None:
    username = os.environ.get("ODTUCLASS_USERNAME") or input("Username: ").strip()
    password = os.environ.get("ODTUCLASS_PASSWORD") or getpass.getpass("Password: ")

    if not username or not password:
        sys.stderr.write("Username and password are required.\n")
        sys.exit(1)

    # get token
    sys.stderr.write("Authenticating... ")
    params = urllib.parse.urlencode({
        "username": username,
        "password": password,
        "service": SERVICE_NAME,
    })
    url = f"{TOKEN_ENDPOINT}?{params}"
    try:
        resp = urllib.request.urlopen(urllib.request.Request(url))
        result = json.loads(resp.read())
    except Exception as e:
        sys.stderr.write(f"\nRequest failed: {e}\n")
        sys.exit(1)

    if "token" not in result:
        msg = result.get("error", "unknown error")
        sys.stderr.write(f"\nLogin failed: {msg}\n")
        sys.exit(1)

    token = result["token"]
    sys.stderr.write("ok\n")

    # get userid from site info
    sys.stderr.write("Fetching user info... ")
    info_params = urllib.parse.urlencode({
        "wstoken": token,
        "wsfunction": "core_webservice_get_site_info",
        "moodlewsrestformat": "json",
    })
    info_url = f"{API_ENDPOINT}?{info_params}"
    try:
        info_resp = urllib.request.urlopen(urllib.request.Request(info_url))
        info = json.loads(info_resp.read())
    except Exception as e:
        sys.stderr.write(f"\nFailed to get user info: {e}\n")
        sys.exit(1)

    userid = info.get("userid")
    fullname = info.get("fullname", "?")
    if userid is None:
        sys.stderr.write("\nCould not determine userid.\n")
        sys.exit(1)

    sys.stderr.write("ok\n")

    # save to config
    cfg = load_config()
    cfg["auth"] = {
        "token": token,
        "userid": userid,
        "username": username,
    }
    save_config(cfg)

    sys.stderr.write(f"Logged in as {fullname} (userid={userid})\n")
    sys.stderr.write("Token stored in config.\n")
