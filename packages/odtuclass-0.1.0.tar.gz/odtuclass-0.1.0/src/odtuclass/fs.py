"""Filesystem utilities: path sanitization, local path building."""

from __future__ import annotations

import re
from pathlib import Path


# Characters illegal in filenames across platforms
_ILLEGAL_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_TRAILING_DOTS_SPACES = re.compile(r'[\s.]+$')


def sanitize_name(name: str) -> str:
    """Sanitize a string for use as a filename/directory component."""
    name = name.strip()
    name = _ILLEGAL_CHARS.sub("_", name)
    name = _TRAILING_DOTS_SPACES.sub("", name)
    if not name:
        name = "_unnamed"
    return name


def build_local_path(
    course_shortname: str,
    section_name: str,
    filename: str,
) -> str:
    """Build a relative path: COURSE/SECTION/filename."""
    parts = [
        sanitize_name(course_shortname),
        sanitize_name(section_name) if section_name else "_general",
        sanitize_name(filename),
    ]
    return str(Path(*parts))


def resolve_local_path(sync_dir: Path, relative: str) -> Path:
    return sync_dir / relative
