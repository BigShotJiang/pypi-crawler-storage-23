"""3-phase sync: discover remote -> diff against manifest -> download."""

from __future__ import annotations

import asyncio
import hashlib
import sys
from pathlib import Path

from odtuclass.api import MoodleAPI
from odtuclass.config import get_sync_dir
from odtuclass.db import ManifestDB
from odtuclass.download import download_file
from odtuclass.fs import build_local_path, resolve_local_path
from odtuclass.models import Course, Section, SyncAction
from odtuclass.output import print_progress, print_sync_actions


async def cmd_sync(
    course_query: str | None,
    dry_run: bool,
    force: bool,
    sync_dir_override: str | None,
) -> None:
    sync_dir = Path(sync_dir_override).expanduser().resolve() if sync_dir_override else get_sync_dir()

    async with MoodleAPI.from_config() as api:
        # resolve which courses to sync
        if course_query:
            courses = [await api.resolve_course(course_query)]
        else:
            courses = await api.get_courses()
            if len(courses) > 1:
                sys.stderr.write(f"Syncing {len(courses)} courses to {sync_dir}\n")

        with ManifestDB() as db:
            all_actions: list[SyncAction] = []

            for course in courses:
                db.upsert_course(course.id, course.shortname, course.fullname)
                sections = await api.get_course_contents(course.id)
                actions = _diff_course(course, sections, sync_dir, db)
                all_actions.extend(actions)

            # report
            print_sync_actions(all_actions)

            actionable = [a for a in all_actions if a.kind in ("download", "update")]
            conflicts = [a for a in all_actions if a.kind == "conflict"]

            if force:
                actionable.extend(conflicts)

            if not actionable:
                return

            if dry_run:
                sys.stderr.write(f"\nDry run: {len(actionable)} file(s) would be downloaded.\n")
                return

            # execute downloads
            sys.stderr.write(f"\nDownloading {len(actionable)} file(s) to {sync_dir}\n")
            sem = asyncio.Semaphore(5)
            completed = 0
            failed: list[tuple[SyncAction, str]] = []

            async def _download_one(action: SyncAction) -> None:
                nonlocal completed
                async with sem:
                    dest = resolve_local_path(sync_dir, action.local_path)
                    url = api.file_download_url(action.file.fileurl)
                    try:
                        content_hash = await download_file(api.client, url, dest)
                    except Exception as e:
                        failed.append((action, str(e)))
                        completed += 1
                        print_progress(completed, len(actionable), action.file.filename)
                        return
                    db.upsert_file(
                        course_id=action.course.id,
                        section_name=action.section_name,
                        module_name=action.module_name,
                        filename=action.file.filename,
                        fileurl=action.file.fileurl,
                        filesize=action.file.filesize,
                        timemodified=action.file.timemodified,
                        content_hash=content_hash,
                        local_path=action.local_path,
                    )
                    completed += 1
                    print_progress(completed, len(actionable), action.file.filename)

            async with asyncio.TaskGroup() as tg:
                for action in actionable:
                    tg.create_task(_download_one(action))

            # update course sync timestamps
            synced_course_ids = {a.course.id for a in actionable}
            for cid in synced_course_ids:
                db.update_course_synced(cid)

            if failed:
                sys.stderr.write(f"\n{len(failed)} file(s) failed:\n")
                for action, err in failed:
                    sys.stderr.write(f"  {action.local_path}: {err}\n")
                sys.stderr.write(f"\n{len(actionable) - len(failed)} file(s) downloaded.\n")
            else:
                sys.stderr.write("Done.\n")


def _diff_course(
    course: Course,
    sections: list[Section],
    sync_dir: Path,
    db: ManifestDB,
) -> list[SyncAction]:
    """Compare remote course contents against local manifest, return sync actions."""
    actions: list[SyncAction] = []

    for section in sections:
        for module in section.modules:
            for fc in module.files:
                local_path = build_local_path(course.shortname, section.name, fc.filename)
                record = db.get_file_record(course.id, section.name, module.name, fc.filename)

                if record is None:
                    # new file
                    actions.append(SyncAction(
                        kind="download",
                        course=course,
                        section_name=section.name,
                        module_name=module.name,
                        file=fc,
                        local_path=local_path,
                    ))
                elif fc.timemodified > (record["timemodified"] or 0):
                    # remote is newer
                    full_path = resolve_local_path(sync_dir, local_path)
                    if _local_modified(full_path, record["content_hash"]):
                        actions.append(SyncAction(
                            kind="conflict",
                            course=course,
                            section_name=section.name,
                            module_name=module.name,
                            file=fc,
                            local_path=local_path,
                            reason="local file modified since last sync",
                        ))
                    else:
                        actions.append(SyncAction(
                            kind="update",
                            course=course,
                            section_name=section.name,
                            module_name=module.name,
                            file=fc,
                            local_path=local_path,
                        ))
                # else: same timemodified -> skip

    return actions


def _local_modified(path: Path, expected_hash: str | None) -> bool:
    """Check if a local file has been modified since last sync."""
    if not path.exists():
        return False
    if expected_hash is None:
        return False
    sha = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            sha.update(chunk)
    return sha.hexdigest() != expected_hash
