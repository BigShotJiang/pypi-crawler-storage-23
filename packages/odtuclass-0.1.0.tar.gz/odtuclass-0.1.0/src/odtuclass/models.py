"""Frozen dataclasses for Moodle API responses."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Course:
    id: int
    shortname: str
    fullname: str


@dataclass(frozen=True)
class FileContent:
    filename: str
    fileurl: str
    filesize: int
    timemodified: int


@dataclass(frozen=True)
class Module:
    id: int
    name: str
    files: list[FileContent]


@dataclass(frozen=True)
class Section:
    id: int
    name: str
    modules: list[Module]


@dataclass(frozen=True)
class SyncAction:
    kind: str  # "download", "update", "conflict", "skip"
    course: Course
    section_name: str
    module_name: str
    file: FileContent
    local_path: str  # relative to sync_dir
    reason: str = ""
