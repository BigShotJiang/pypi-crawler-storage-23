"""MoodleAPI: async HTTP client wrapping all Moodle web service calls."""

from __future__ import annotations

import sys
from types import TracebackType
from typing import Any, Self

import httpx

from odtuclass.config import API_ENDPOINT, get_token, get_userid
from odtuclass.models import Course, FileContent, Module, Section


class MoodleAPIError(Exception):
    pass


class MoodleAPI:
    def __init__(self, token: str, userid: int) -> None:
        self._token = token
        self._userid = userid
        self._client = httpx.AsyncClient(timeout=30.0, follow_redirects=True)

    @property
    def client(self) -> httpx.AsyncClient:
        return self._client

    @classmethod
    def from_config(cls) -> Self:
        token = get_token()
        userid = get_userid()
        if not token or userid is None:
            sys.stderr.write("Not logged in. Run 'odtuclass login' first.\n")
            sys.exit(1)
        return cls(token, userid)

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self._client.aclose()

    async def _call(self, function: str, **params: Any) -> Any:
        params["wstoken"] = self._token
        params["wsfunction"] = function
        params["moodlewsrestformat"] = "json"
        resp = await self._client.get(API_ENDPOINT, params=params)
        resp.raise_for_status()
        data = resp.json()
        if isinstance(data, dict) and "exception" in data:
            code = data.get("errorcode", "")
            msg = data.get("message", "unknown error")
            if code == "invalidtoken":
                raise MoodleAPIError(
                    "Token expired or invalid. Run 'odtuclass login' to re-authenticate."
                )
            raise MoodleAPIError(f"{code}: {msg}")
        return data

    async def get_courses(self) -> list[Course]:
        data = await self._call("core_enrol_get_users_courses", userid=self._userid)
        courses: list[Course] = []
        for c in data:
            courses.append(Course(
                id=c["id"],
                shortname=c["shortname"],
                fullname=c["fullname"],
            ))
        courses.sort(key=lambda c: c.shortname)
        return courses

    async def resolve_course(self, query: str | None) -> Course:
        """Resolve a course by shortname or ID. If query is None, error."""
        if query is None:
            sys.stderr.write("Please specify a course (shortname or ID).\n")
            sys.stderr.write("Run 'odtuclass courses' to see available courses.\n")
            sys.exit(1)

        courses = await self.get_courses()

        # try exact shortname match (case-insensitive)
        for c in courses:
            if c.shortname.lower() == query.lower():
                return c

        # try ID match
        try:
            qid = int(query)
            for c in courses:
                if c.id == qid:
                    return c
        except ValueError:
            pass

        # try substring match
        matches = [c for c in courses if query.lower() in c.shortname.lower()]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            sys.stderr.write(f"Ambiguous course '{query}'. Matches:\n")
            for c in matches:
                sys.stderr.write(f"  {c.shortname} — {c.fullname}\n")
            sys.exit(1)

        sys.stderr.write(f"Course '{query}' not found.\n")
        sys.stderr.write("Run 'odtuclass courses' to see available courses.\n")
        sys.exit(1)

    async def get_course_contents(self, course_id: int) -> list[Section]:
        data = await self._call("core_course_get_contents", courseid=course_id)
        sections: list[Section] = []
        for s in data:
            modules: list[Module] = []
            for m in s.get("modules", []):
                files: list[FileContent] = []
                for content in m.get("contents", []):
                    if content.get("type") != "file":
                        continue
                    files.append(FileContent(
                        filename=content["filename"],
                        fileurl=content["fileurl"],
                        filesize=content.get("filesize", 0),
                        timemodified=content.get("timemodified", 0),
                    ))
                if files:
                    modules.append(Module(id=m["id"], name=m["name"], files=files))
            sections.append(Section(id=s["id"], name=s.get("name", ""), modules=modules))
        return sections

    def file_download_url(self, fileurl: str) -> str:
        """Convert a pluginfile URL to use token-based auth for download."""
        sep = "&" if "?" in fileurl else "?"
        return f"{fileurl}{sep}token={self._token}"
