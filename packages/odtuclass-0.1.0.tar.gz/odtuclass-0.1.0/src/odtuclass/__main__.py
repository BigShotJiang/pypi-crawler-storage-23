from odtuclass.cli import main

main()
