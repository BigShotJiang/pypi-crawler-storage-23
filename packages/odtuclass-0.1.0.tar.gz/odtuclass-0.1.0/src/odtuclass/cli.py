"""CLI entry point: argparse, subcommand dispatch, top-level error handling."""

from __future__ import annotations

import argparse
import asyncio
import sys

import httpx

from odtuclass import __version__
from odtuclass.api import MoodleAPIError


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="odtuclass",
        description="Sync ODTUClass (METU Moodle) course files to local disk.",
        epilog="Run 'odtuclass <command> --help' for more info on a command.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    sub = parser.add_subparsers(dest="command")

    # login
    sub.add_parser("login", help="Authenticate and store token")

    # courses
    sub.add_parser("courses", help="List enrolled courses")

    # ls
    ls_parser = sub.add_parser("ls", help="List files in a course")
    ls_parser.add_argument("course", help="Course shortname or ID")

    # sync
    sync_parser = sub.add_parser("sync", help="Download new/updated files")
    sync_parser.add_argument("course", nargs="?", help="Course shortname or ID (omit for all)")
    sync_parser.add_argument("--dry-run", action="store_true", help="Preview without downloading")
    sync_parser.add_argument("--force", action="store_true", help="Overwrite conflicting files")
    sync_parser.add_argument("--sync-dir", type=str, help="Override sync directory")

    # config
    cfg_parser = sub.add_parser("config", help="Show or set config values")
    cfg_parser.add_argument("key", nargs="?", help="Config key (e.g. sync.directory)")
    cfg_parser.add_argument("value", nargs="?", help="Value to set")

    return parser


def main() -> None:
    from odtuclass.config import load_dotenv
    load_dotenv()

    parser = build_parser()
    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    try:
        _dispatch(args)
    except KeyboardInterrupt:
        sys.stderr.write("\nInterrupted.\n")
        sys.exit(130)
    except MoodleAPIError as e:
        sys.stderr.write(f"error: {e}\n")
        sys.exit(1)
    except httpx.ConnectError:
        sys.stderr.write("error: Could not connect to odtuclass.metu.edu.tr\n")
        sys.stderr.write("Check your internet connection or try again later.\n")
        sys.exit(1)
    except httpx.HTTPStatusError as e:
        sys.stderr.write(f"error: HTTP {e.response.status_code} from server\n")
        sys.exit(1)
    except Exception as e:
        sys.stderr.write(f"error: {e}\n")
        sys.exit(1)


def _dispatch(args: argparse.Namespace) -> None:
    if args.command == "login":
        from odtuclass.auth import cmd_login
        cmd_login()

    elif args.command == "courses":
        from odtuclass.api import MoodleAPI
        from odtuclass.output import print_courses

        async def _run() -> None:
            async with MoodleAPI.from_config() as api:
                courses = await api.get_courses()
                print_courses(courses)

        asyncio.run(_run())

    elif args.command == "ls":
        from odtuclass.api import MoodleAPI
        from odtuclass.output import print_course_files

        async def _run() -> None:
            async with MoodleAPI.from_config() as api:
                course = await api.resolve_course(args.course)
                sections = await api.get_course_contents(course.id)
                print_course_files(course, sections)

        asyncio.run(_run())

    elif args.command == "sync":
        from odtuclass.sync import cmd_sync

        asyncio.run(cmd_sync(
            course_query=args.course,
            dry_run=args.dry_run,
            force=args.force,
            sync_dir_override=args.sync_dir,
        ))

    elif args.command == "config":
        _cmd_config(args)


def _cmd_config(args: argparse.Namespace) -> None:
    from odtuclass.config import load_config, save_config

    cfg = load_config()

    if args.key is None:
        # show all
        if not cfg:
            print("No configuration set. Run 'odtuclass login' to get started.")
            return
        for section, values in cfg.items():
            if isinstance(values, dict):
                for k, v in values.items():
                    print(f"{section}.{k} = {v}")
            else:
                print(f"{section} = {values}")
        return

    if args.value is None:
        # get
        parts = args.key.split(".", 1)
        if len(parts) == 2:
            val = cfg.get(parts[0], {}).get(parts[1])
        else:
            val = cfg.get(parts[0])
        if val is None:
            sys.stderr.write(f"Key '{args.key}' not set.\n")
            sys.exit(1)
        print(val)
        return

    # set
    parts = args.key.split(".", 1)
    if len(parts) == 2:
        section, key = parts
        if section not in cfg:
            cfg[section] = {}
        cfg[section][key] = args.value
    else:
        cfg[parts[0]] = args.value
    save_config(cfg)
    print(f"{args.key} = {args.value}")
