"""SQLite manifest database for tracking synced files."""

from __future__ import annotations

import sqlite3
import time
from pathlib import Path

from odtuclass.config import DB_FILE


_SCHEMA = """
CREATE TABLE IF NOT EXISTS courses (
    id INTEGER PRIMARY KEY,
    shortname TEXT NOT NULL,
    fullname TEXT NOT NULL,
    last_synced INTEGER
);

CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    course_id INTEGER NOT NULL REFERENCES courses(id),
    section_name TEXT NOT NULL,
    module_name TEXT NOT NULL,
    filename TEXT NOT NULL,
    fileurl TEXT NOT NULL,
    filesize INTEGER NOT NULL DEFAULT 0,
    timemodified INTEGER,
    content_hash TEXT,
    local_path TEXT NOT NULL,
    last_downloaded INTEGER,
    UNIQUE(course_id, section_name, module_name, filename)
);
"""


class ManifestDB:
    def __init__(self, db_path: Path | None = None) -> None:
        self._path = db_path or DB_FILE
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._path))
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(_SCHEMA)

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> ManifestDB:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def upsert_course(self, course_id: int, shortname: str, fullname: str) -> None:
        self._conn.execute(
            "INSERT INTO courses (id, shortname, fullname) VALUES (?, ?, ?) "
            "ON CONFLICT(id) DO UPDATE SET shortname=excluded.shortname, fullname=excluded.fullname",
            (course_id, shortname, fullname),
        )
        self._conn.commit()

    def update_course_synced(self, course_id: int) -> None:
        self._conn.execute(
            "UPDATE courses SET last_synced = ? WHERE id = ?",
            (int(time.time()), course_id),
        )
        self._conn.commit()

    def get_file_record(
        self, course_id: int, section_name: str, module_name: str, filename: str
    ) -> sqlite3.Row | None:
        cur = self._conn.execute(
            "SELECT * FROM files WHERE course_id=? AND section_name=? AND module_name=? AND filename=?",
            (course_id, section_name, module_name, filename),
        )
        return cur.fetchone()

    def upsert_file(
        self,
        course_id: int,
        section_name: str,
        module_name: str,
        filename: str,
        fileurl: str,
        filesize: int,
        timemodified: int,
        content_hash: str,
        local_path: str,
    ) -> None:
        self._conn.execute(
            """INSERT INTO files
               (course_id, section_name, module_name, filename, fileurl, filesize,
                timemodified, content_hash, local_path, last_downloaded)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(course_id, section_name, module_name, filename)
               DO UPDATE SET
                 fileurl=excluded.fileurl,
                 filesize=excluded.filesize,
                 timemodified=excluded.timemodified,
                 content_hash=excluded.content_hash,
                 local_path=excluded.local_path,
                 last_downloaded=excluded.last_downloaded
            """,
            (course_id, section_name, module_name, filename, fileurl, filesize,
             timemodified, content_hash, local_path, int(time.time())),
        )
        self._conn.commit()
