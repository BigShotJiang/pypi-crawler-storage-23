"""Output formatting: tables and progress to stderr. No external deps."""

from __future__ import annotations

import sys
from typing import TextIO

from odtuclass.models import Course, Section, SyncAction


def print_courses(courses: list[Course], file: TextIO = sys.stdout) -> None:
    if not courses:
        file.write("No courses found.\n")
        return

    # find column widths
    sn_width = max(len(c.shortname) for c in courses)
    sn_width = max(sn_width, 9)  # "SHORTNAME"

    file.write(f"{'SHORTNAME':<{sn_width}}  {'ID':>6}  FULLNAME\n")
    file.write(f"{'-' * sn_width}  {'-' * 6}  {'-' * 40}\n")
    for c in courses:
        file.write(f"{c.shortname:<{sn_width}}  {c.id:>6}  {c.fullname}\n")


def print_course_files(course: Course, sections: list[Section], file: TextIO = sys.stdout) -> None:
    file.write(f"{course.shortname} — {course.fullname}\n\n")
    total_files = 0
    for section in sections:
        if not section.modules:
            continue
        file.write(f"  {section.name or '(unnamed section)'}\n")
        for module in section.modules:
            for f_content in module.files:
                size = _format_size(f_content.filesize)
                file.write(f"    {f_content.filename}  ({size})\n")
                total_files += 1
    if total_files == 0:
        file.write("  (no files)\n")
    else:
        file.write(f"\n{total_files} file(s)\n")


def print_sync_actions(actions: list[SyncAction], file: TextIO = sys.stderr) -> None:
    if not actions:
        file.write("Everything up to date.\n")
        return

    downloads = [a for a in actions if a.kind == "download"]
    updates = [a for a in actions if a.kind == "update"]
    conflicts = [a for a in actions if a.kind == "conflict"]

    if downloads:
        file.write(f"\nNew files ({len(downloads)}):\n")
        for a in downloads:
            file.write(f"  + {a.local_path}\n")

    if updates:
        file.write(f"\nUpdated files ({len(updates)}):\n")
        for a in updates:
            file.write(f"  ~ {a.local_path}\n")

    if conflicts:
        file.write(f"\nConflicts ({len(conflicts)}):\n")
        for a in conflicts:
            file.write(f"  ! {a.local_path}  ({a.reason})\n")


def print_progress(current: int, total: int, filename: str, file: TextIO = sys.stderr) -> None:
    file.write(f"\r[{current}/{total}] {filename[:60]:<60}")
    file.flush()
    if current == total:
        file.write("\n")


def _format_size(size: int) -> str:
    if size <= 0:
        return "?"
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024:
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"
