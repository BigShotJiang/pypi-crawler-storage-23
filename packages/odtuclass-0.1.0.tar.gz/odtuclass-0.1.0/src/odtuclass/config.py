"""Configuration management: ~/.config/odtuclass/config.toml + .env loading."""

from __future__ import annotations

import os
import sys
import tomllib
from pathlib import Path
from typing import Any

CONFIG_DIR = Path(os.environ.get("ODTUCLASS_CONFIG_DIR", "~/.config/odtuclass")).expanduser()
CONFIG_FILE = CONFIG_DIR / "config.toml"
DB_FILE = CONFIG_DIR / "manifest.db"

BASE_URL = "https://odtuclass.metu.edu.tr"
TOKEN_ENDPOINT = f"{BASE_URL}/login/token.php"
API_ENDPOINT = f"{BASE_URL}/webservice/rest/server.php"
SERVICE_NAME = "moodle_mobile_app"


def load_dotenv() -> None:
    """Load .env file into os.environ. Does not override existing vars.

    Search order: CWD, then ~/.config/odtuclass/.env
    """
    for candidate in (Path(".env"), CONFIG_DIR / ".env"):
        if candidate.exists():
            _parse_env_file(candidate)
            return


def _parse_env_file(path: Path) -> None:
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip("'\"")
            if key and key not in os.environ:
                os.environ[key] = value


def ensure_config_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict[str, Any]:
    if not CONFIG_FILE.exists():
        return {}
    with open(CONFIG_FILE, "rb") as f:
        return tomllib.load(f)


def save_config(cfg: dict[str, Any]) -> None:
    ensure_config_dir()
    lines: list[str] = []
    for section, values in cfg.items():
        if isinstance(values, dict):
            lines.append(f"[{section}]")
            for k, v in values.items():
                lines.append(f"{k} = {_toml_value(v)}")
            lines.append("")
        else:
            lines.append(f"{section} = {_toml_value(values)}")
    with open(CONFIG_FILE, "w") as f:
        f.write("\n".join(lines) + "\n")
    # restrict permissions on unix — token is stored here
    if sys.platform != "win32":
        import stat
        CONFIG_FILE.chmod(stat.S_IRUSR | stat.S_IWUSR)


def _toml_value(v: Any) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, str):
        escaped = v.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    raise TypeError(f"unsupported config value type: {type(v)}")


def get_token() -> str | None:
    cfg = load_config()
    return cfg.get("auth", {}).get("token")


def get_userid() -> int | None:
    cfg = load_config()
    val = cfg.get("auth", {}).get("userid")
    return int(val) if val is not None else None


def get_sync_dir() -> Path:
    """Resolve sync directory with priority: CLI flag handled by caller, then env, then config, then default."""
    env = os.environ.get("ODTUCLASS_SYNC_DIR")
    if env:
        return Path(env).expanduser().resolve()
    cfg = load_config()
    configured = cfg.get("sync", {}).get("directory")
    if configured:
        return Path(configured).expanduser().resolve()
    return Path("~/odtuclass").expanduser().resolve()
