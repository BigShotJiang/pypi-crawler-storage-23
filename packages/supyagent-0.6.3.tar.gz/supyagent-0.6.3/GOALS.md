# Goals

## User Goals
<!-- Define what you want to achieve. The agent reads this on every conversation. -->

- I'm the CTO of ergodic.ai, and I'm trying to expand my business. We want to sell more to supply chain and I want to figure out how

## Subgoals
<!-- Managed by the agent. Uses checkbox syntax: [ ] pending, [x] done, [~] skipped -->
