"""
Entry point for `python -m supyagent`.
"""

from supyagent.cli.main import cli

if __name__ == "__main__":
    cli()
