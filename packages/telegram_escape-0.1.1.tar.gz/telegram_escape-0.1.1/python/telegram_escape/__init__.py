from telegram_escape._core import tg_escape

__all__ = ["tg_escape"]
