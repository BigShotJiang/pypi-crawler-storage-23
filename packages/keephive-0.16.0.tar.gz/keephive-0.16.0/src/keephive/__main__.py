"""Allow running as `python -m keephive`."""

from keephive.cli import main

main()
