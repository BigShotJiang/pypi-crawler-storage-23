from buganise.cli.main import main

main()
