"""
config.py — All constants and zero logic.
Every path, every provider, every model lives here.
Nothing else in the package defines paths or provider info.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Base directories (OS-aware, XDG-compliant on Linux)
# ---------------------------------------------------------------------------

if sys.platform == "win32":
    _BASE = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
elif sys.platform == "darwin":
    _BASE = Path.home() / "Library" / "Application Support"
else:
    _BASE = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))

BASE_DIR: Path = _BASE / "bysalim"
DATA_DIR: Path = BASE_DIR / "data"
LOG_DIR: Path = BASE_DIR / "logs"

CONFIG_FILE: Path = DATA_DIR / "config.json"
LOCK_FILE: Path = DATA_DIR / "agent.pid"
TASK_LOG: Path = LOG_DIR / "tasks.jsonl"
ENCRYPTION_KEY_FILE: Path = DATA_DIR / ".enc_key"

# ---------------------------------------------------------------------------
# AI provider registry
# ---------------------------------------------------------------------------

AI_PROVIDERS: dict[str, dict] = {
    "openai": {
        "display_name": "OpenAI",
        "base_url": "https://api.openai.com/v1",
        "key_url": "https://platform.openai.com/api-keys",
        "models": [
            {"id": "gpt-4o-mini",       "label": "GPT-4o Mini (fast, cheap)",      "free": False},
            {"id": "gpt-4o",            "label": "GPT-4o (powerful)",               "free": False},
            {"id": "gpt-3.5-turbo",     "label": "GPT-3.5 Turbo (legacy, cheap)",  "free": False},
        ],
    },
    "anthropic": {
        "display_name": "Anthropic (Claude)",
        "base_url": "https://api.anthropic.com/v1",
        "key_url": "https://console.anthropic.com/settings/keys",
        "models": [
            {"id": "claude-3-haiku-20240307",   "label": "Claude 3 Haiku (fast)",      "free": False},
            {"id": "claude-3-5-sonnet-20241022", "label": "Claude 3.5 Sonnet (smart)",  "free": False},
            {"id": "claude-3-opus-20240229",     "label": "Claude 3 Opus (powerful)",   "free": False},
        ],
    },
    "groq": {
        "display_name": "Groq (ultra-fast inference)",
        "base_url": "https://api.groq.com/openai/v1",
        "key_url": "https://console.groq.com/keys",
        "models": [
            {"id": "llama3-8b-8192",     "label": "Llama 3 8B (free tier)",   "free": True},
            {"id": "llama3-70b-8192",    "label": "Llama 3 70B (free tier)",  "free": True},
            {"id": "mixtral-8x7b-32768", "label": "Mixtral 8x7B (free tier)", "free": True},
            {"id": "gemma2-9b-it",       "label": "Gemma 2 9B (free tier)",   "free": True},
        ],
    },
    "together": {
        "display_name": "Together AI",
        "base_url": "https://api.together.xyz/v1",
        "key_url": "https://api.together.xyz/settings/api-keys",
        "models": [
            {"id": "meta-llama/Llama-3-8b-chat-hf",           "label": "Llama 3 8B (free tier)", "free": True},
            {"id": "meta-llama/Llama-3-70b-chat-hf",          "label": "Llama 3 70B",             "free": False},
            {"id": "mistralai/Mixtral-8x7B-Instruct-v0.1",    "label": "Mixtral 8x7B",            "free": False},
        ],
    },
    "nvidia": {
        "display_name": "NVIDIA NIM (free tier available)",
        "base_url": "https://integrate.api.nvidia.com/v1",
        "key_url": "https://build.nvidia.com/explore/discover",
        "models": [
            {"id": "meta/llama3-8b-instruct",             "label": "Llama 3 8B (free tier)",    "free": True},
            {"id": "meta/llama3-70b-instruct",            "label": "Llama 3 70B (free tier)",   "free": True},
            {"id": "mistralai/mistral-7b-instruct-v0.3",  "label": "Mistral 7B (free tier)",    "free": True},
        ],
    },
    "mistral": {
        "display_name": "Mistral AI",
        "base_url": "https://api.mistral.ai/v1",
        "key_url": "https://console.mistral.ai/api-keys",
        "models": [
            {"id": "mistral-small-latest",  "label": "Mistral Small",  "free": False},
            {"id": "mistral-medium-latest", "label": "Mistral Medium", "free": False},
            {"id": "mistral-large-latest",  "label": "Mistral Large",  "free": False},
        ],
    },
    "cohere": {
        "display_name": "Cohere",
        "base_url": "https://api.cohere.ai/v1",
        "key_url": "https://dashboard.cohere.com/api-keys",
        "models": [
            {"id": "command-r",      "label": "Command R",   "free": False},
            {"id": "command-r-plus", "label": "Command R+",  "free": False},
        ],
    },
    "zhipu": {
        "display_name": "Zhipu AI (GLM)",
        "base_url": "https://open.bigmodel.cn/api/paas/v4",
        "key_url": "https://open.bigmodel.cn/usercenter/apikeys",
        "models": [
            {"id": "glm-4",       "label": "GLM-4",                    "free": False},
            {"id": "glm-4-flash", "label": "GLM-4 Flash (free tier)",  "free": True},
            {"id": "glm-3-turbo", "label": "GLM-3 Turbo",              "free": False},
        ],
    },
    "openrouter": {
        "display_name": "OpenRouter (100+ models, free tiers)",
        "base_url": "https://openrouter.ai/api/v1",
        "key_url": "https://openrouter.ai/keys",
        "models": [
            {"id": "mistralai/mistral-7b-instruct:free",  "label": "Mistral 7B (FREE)",   "free": True},
            {"id": "meta-llama/llama-3-8b-instruct:free", "label": "Llama 3 8B (FREE)",   "free": True},
            {"id": "google/gemma-2-9b-it:free",           "label": "Gemma 2 9B (FREE)",   "free": True},
            {"id": "openchat/openchat-7b:free",           "label": "OpenChat 7B (FREE)",  "free": True},
            {"id": "anthropic/claude-3.5-sonnet",         "label": "Claude 3.5 Sonnet",   "free": False},
            {"id": "openai/gpt-4o",                       "label": "GPT-4o",              "free": False},
        ],
    },
}

# ---------------------------------------------------------------------------
# Misc constants
# ---------------------------------------------------------------------------

CONVERSATION_MEMORY_SIZE: int = 20      # max turns kept in memory
POLLING_TIMEOUT: int = 30               # Telegram long-poll seconds
STARTUP_DELAY: float = 2.0             # seconds before startup message
LOG_MAX_BYTES: int = 5 * 1024 * 1024   # 5 MB log rotation
LOG_BACKUP_COUNT: int = 3
TOOL_TIMEOUT: float = 30.0             # seconds before a tool is timed out

# Retry configuration for network calls
MAX_RETRIES: int = 3
RETRY_BASE_DELAY: float = 1.0          # exponential backoff base (seconds)
RETRY_MAX_DELAY: float = 30.0

# Telegram limits
TELEGRAM_MAX_MESSAGE_LENGTH: int = 4096
TELEGRAM_CAPTION_MAX_LENGTH: int = 1024
