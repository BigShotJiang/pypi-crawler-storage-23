"""
tools.py — BySalim v2 — Bulletproof. Every tool guaranteed to never crash.

Philosophy:
  • Every function is wrapped in a top-level try/except that catches BaseException.
  • Every argument is validated AND coerced — wrong types (str instead of int, etc.) are
    silently fixed rather than raising TypeError.
  • Every platform-specific path has at least 3 fallbacks.
  • Every external tool call is guarded: check shutil.which() before calling.
  • Every file operation checks existence, type, permissions, size before acting.
  • Empty/None inputs → clear user-friendly error, never AttributeError.
  • Auto-install: pip-installable libs install themselves on first use.
  • _safe_str / _safe_int / _safe_float coerce all incoming AI-generated args.
"""
from __future__ import annotations

import asyncio
import datetime
import json
import os
import platform
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
import wave
import webbrowser
from pathlib import Path
from typing import Any, Callable, Coroutine

import psutil

from .config import TOOL_TIMEOUT
from .logger import get_logger, log_task

log = get_logger("tools")
SYS = platform.system()   # "Darwin" | "Linux" | "Windows"
HOME = Path.home()


# ─────────────────────────────────────────────────────────────────────────────
# Arg coercion — never let wrong types from the AI cause AttributeError/TypeError
# ─────────────────────────────────────────────────────────────────────────────

def _safe_str(v: Any, default: str = "") -> str:
    if v is None: return default
    try: return str(v).strip()
    except Exception: return default

def _safe_int(v: Any, default: int = 0, lo: int | None = None, hi: int | None = None) -> int:
    try:
        n = int(float(str(v)))
        if lo is not None: n = max(lo, n)
        if hi is not None: n = min(hi, n)
        return n
    except Exception: return default

def _safe_float(v: Any, default: float = 0.0, lo: float | None = None, hi: float | None = None) -> float:
    try:
        f = float(str(v))
        if lo is not None: f = max(lo, f)
        if hi is not None: f = min(hi, f)
        return f
    except Exception: return default

def _safe_bool(v: Any, default: bool = False) -> bool:
    if isinstance(v, bool): return v
    if isinstance(v, int): return bool(v)
    if isinstance(v, str): return v.lower() in ("true","yes","1","on")
    return default


# ─────────────────────────────────────────────────────────────────────────────
# Telegram push callbacks
# ─────────────────────────────────────────────────────────────────────────────

_send_cbs: list[Callable[[str], Coroutine]] = []
_send_file_cbs: list[Callable[[str, str, str], Coroutine]] = []

def register_send_callback(fn): _send_cbs.append(fn)
def register_send_file_callback(fn): _send_file_cbs.append(fn)

async def _push(msg: str) -> None:
    for cb in _send_cbs:
        try: await cb(msg)
        except Exception as e: log.warning("push cb: %s", e)

async def _push_file(path: str, caption: str = "", ftype: str = "document") -> None:
    for cb in _send_file_cbs:
        try: await cb(path, caption, ftype)
        except Exception as e: log.warning("push_file cb: %s", e)


# ─────────────────────────────────────────────────────────────────────────────
# Auto-pip-install
# ─────────────────────────────────────────────────────────────────────────────

_pip_tried: set[str] = set()

def _pip(pkg: str, import_as: str | None = None) -> Any:
    """Import pkg, auto-pip-install if missing. Returns module or None — never raises."""
    mod_name = import_as or pkg.split("[")[0].split(">=")[0].split("==")[0].strip()
    try:
        import importlib
        return importlib.import_module(mod_name)
    except ImportError:
        pass
    if pkg in _pip_tried:
        return None
    _pip_tried.add(pkg)
    log.info("Auto-installing %s …", pkg)
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet",
             "--break-system-packages", pkg],
            check=True, capture_output=True, timeout=120,
        )
        import importlib
        return importlib.import_module(mod_name)
    except Exception as e:
        log.warning("pip install %s failed: %s", pkg, e)
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Subprocess wrapper — never raises, always returns dict
# ─────────────────────────────────────────────────────────────────────────────

def _run(cmd: list | str, timeout: float = TOOL_TIMEOUT,
         shell: bool = False, cwd: str | None = None,
         stdin_data: bytes | None = None) -> dict:
    try:
        r = subprocess.run(
            cmd, capture_output=True, timeout=timeout,
            shell=shell, cwd=cwd,
            input=stdin_data if stdin_data else None,
        )
        return {
            "exit_code": r.returncode,
            "stdout": (r.stdout or b"").decode("utf-8", errors="replace").strip(),
            "stderr": (r.stderr or b"").decode("utf-8", errors="replace").strip(),
        }
    except subprocess.TimeoutExpired:
        return {"error": f"Command timed out after {timeout:.0f}s", "exit_code": -1}
    except FileNotFoundError:
        name = cmd[0] if isinstance(cmd, list) else cmd.split()[0]
        return {"error": f"'{name}' not found on PATH", "exit_code": -1}
    except PermissionError as e:
        return {"error": f"Permission denied: {e}", "exit_code": -1}
    except Exception as e:
        return {"error": f"subprocess error: {e}", "exit_code": -1}


async def _arun(fn, *a, **kw):
    """Run sync fn in thread executor — always returns its result."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, lambda: fn(*a, **kw))


# ─────────────────────────────────────────────────────────────────────────────
# Path helpers
# ─────────────────────────────────────────────────────────────────────────────

def _resolve(path: str) -> Path:
    """Expand ~ and resolve to absolute path. Never raises."""
    try:
        return Path(_safe_str(path, "~")).expanduser().resolve()
    except Exception:
        return HOME

def _sz(b: int | float) -> str:
    b = max(0, int(b))
    for u in ("B", "KB", "MB", "GB", "TB"):
        if b < 1024:
            return f"{b:.1f} {u}"
        b /= 1024
    return f"{b:.1f} PB"

def _media_type(path: str) -> str:
    ext = Path(path).suffix.lower()
    if ext in {".jpg",".jpeg",".png",".gif",".bmp",".webp",".tiff",".tif",
               ".heic",".heif",".ico",".avif",".psd",".svg"}: return "image"
    if ext in {".mp4",".mkv",".avi",".mov",".wmv",".flv",".webm",".m4v",
               ".3gp",".ts",".ogv",".f4v",".rm"}:              return "video"
    if ext in {".mp3",".flac",".wav",".aac",".ogg",".m4a",".wma",
               ".opus",".aiff",".alac",".mid",".midi"}:         return "audio"
    try:
        with open(path, "rb") as f: h = f.read(16)
        if h[:2]==b"\xff\xd8":    return "image"
        if h[:4]==b"\x89PNG":     return "image"
        if h[:3]==b"GIF":         return "image"
        if h[:3]==b"ID3":         return "audio"
        if h[:4]==b"fLaC":        return "audio"
        if h[:4]==b"OggS":        return "audio"
        if h[:4]==b"RIFF":
            return "audio" if h[8:12]==b"WAVE" else "video"
        if h[4:8]==b"ftyp":       return "video"
        if h[:4]==b"\x1a\x45\xdf\xa3": return "video"
    except Exception: pass
    return "document"

def _check_path(path: str, must_exist: bool = True, must_be_file: bool = False,
                must_be_dir: bool = False) -> tuple[Path | None, str | None]:
    """Returns (Path, None) on success or (None, error_string) on failure."""
    if not path:
        return None, "No path provided"
    try:
        p = _resolve(path)
        if must_exist and not p.exists():
            return None, f"Not found: {p}"
        if must_be_file and not p.is_file():
            return None, f"Not a file: {p}"
        if must_be_dir and not p.is_dir():
            return None, f"Not a directory: {p}"
        return p, None
    except Exception as e:
        return None, f"Path error: {e}"


# ─────────────────────────────────────────────────────────────────────────────
# Top-level crash shield decorator
# ─────────────────────────────────────────────────────────────────────────────

def _shield(fn):
    """Wrap any async tool function so it NEVER propagates an exception."""
    import functools
    @functools.wraps(fn)
    async def wrapper(**kwargs):
        try:
            return await fn(**kwargs)
        except BaseException as e:
            log.error("Tool %s crashed: %s\n%s", fn.__name__, e, traceback.format_exc())
            return {"error": f"{fn.__name__} crashed: {type(e).__name__}: {e}"}
    return wrapper


# ═════════════════════════════════════════════════════════════════════════════
# SYSTEM TOOLS
# ═════════════════════════════════════════════════════════════════════════════

@_shield
async def tool_system_health(**_) -> dict:
    loop = asyncio.get_event_loop()
    cpu = await loop.run_in_executor(None, lambda: psutil.cpu_percent(interval=0.5))
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage("/")
    swap = psutil.swap_memory()
    # Per-CPU
    try:
        per_cpu = psutil.cpu_percent(percpu=True)
    except Exception:
        per_cpu = []
    # Top procs
    procs = []
    for p in psutil.process_iter(["pid","name","cpu_percent","memory_percent","status"]):
        try:
            i = p.info
            if i.get("status") in ("zombie","dead"): continue
            procs.append({"pid": i["pid"],
                          "name": (i.get("name") or "?")[:40],
                          "cpu_pct": round(float(i.get("cpu_percent") or 0), 1),
                          "mem_pct": round(float(i.get("memory_percent") or 0), 1)})
        except Exception: pass
    # Temp sensors
    temps = {}
    try:
        raw = psutil.sensors_temperatures() or {}
        for k, v in raw.items():
            if v: temps[k] = round(v[0].current, 1)
    except Exception: pass
    return {
        "cpu_percent": round(cpu, 1),
        "cpu_count_logical": psutil.cpu_count(logical=True),
        "cpu_count_physical": psutil.cpu_count(logical=False),
        "cpu_per_core": per_cpu,
        "ram_total_gb":  round(mem.total / 1e9, 2),
        "ram_used_gb":   round(mem.used  / 1e9, 2),
        "ram_free_gb":   round(mem.available / 1e9, 2),
        "ram_percent":   round(mem.percent, 1),
        "swap_total_gb": round(swap.total / 1e9, 2),
        "swap_used_gb":  round(swap.used  / 1e9, 2),
        "disk_total_gb": round(disk.total / 1e9, 2),
        "disk_used_gb":  round(disk.used  / 1e9, 2),
        "disk_free_gb":  round(disk.free  / 1e9, 2),
        "disk_percent":  round(disk.percent, 1),
        "temperatures":  temps,
        "top_processes": sorted(procs, key=lambda x: x["cpu_pct"], reverse=True)[:10],
    }


@_shield
async def tool_uptime(**_) -> dict:
    boot_ts = psutil.boot_time()
    delta = time.time() - boot_ts
    d = int(delta // 86400)
    h = int((delta % 86400) // 3600)
    m = int((delta % 3600) // 60)
    s = int(delta % 60)
    return {
        "uptime": f"{d}d {h}h {m}m {s}s",
        "uptime_seconds": int(delta),
        "boot_time": datetime.datetime.fromtimestamp(boot_ts).strftime("%Y-%m-%d %H:%M:%S"),
        "boot_timestamp": int(boot_ts),
    }


@_shield
async def tool_battery(**_) -> dict:
    bat = psutil.sensors_battery()
    if bat is None:
        return {"plugged_in": True, "note": "No battery detected (desktop or sensor unavailable)"}
    secs = bat.secsleft
    if secs == psutil.POWER_TIME_UNLIMITED or (bat.power_plugged and secs <= 0):
        tl = "Charging / AC power"
    elif secs == psutil.POWER_TIME_UNKNOWN or secs < 0:
        tl = "Unknown"
    else:
        h, mn = divmod(secs // 60, 60)
        tl = f"{h}h {mn}m remaining"
    return {
        "percent": round(bat.percent, 1),
        "plugged_in": bool(bat.power_plugged),
        "time_left": tl,
        "secsleft": int(secs) if secs > 0 else -1,
    }


@_shield
async def tool_network_stats(**_) -> dict:
    c = psutil.net_io_counters()
    ifaces: dict = {}
    for name, addrs in psutil.net_if_addrs().items():
        for a in addrs:
            fname = getattr(a.family, "name", str(a.family))
            if fname in ("AF_INET","AF_INET6") and not a.address.startswith(("127.","::1")):
                ifaces[name] = a.address
                break
    try: conns = len(psutil.net_connections())
    except Exception: conns = -1
    # Per-interface counters
    per_iface: dict = {}
    try:
        for iname, ic in (psutil.net_io_counters(pernic=True) or {}).items():
            per_iface[iname] = {
                "sent_mb": round(ic.bytes_sent / 1e6, 2),
                "recv_mb": round(ic.bytes_recv / 1e6, 2),
            }
    except Exception: pass
    return {
        "bytes_sent_mb": round(c.bytes_sent / 1e6, 3),
        "bytes_recv_mb": round(c.bytes_recv / 1e6, 3),
        "packets_sent":  c.packets_sent,
        "packets_recv":  c.packets_recv,
        "errors_in":     c.errin,
        "errors_out":    c.errout,
        "active_connections": conns,
        "interfaces": ifaces,
        "per_interface": per_iface,
    }


@_shield
async def tool_run_shell(command: str = "", timeout: float = 30.0, **_) -> dict:
    command = _safe_str(command)
    if not command:
        return {"error": "No command provided"}
    timeout = _safe_float(timeout, 30.0, 1.0, 120.0)
    r = await _arun(_run, command, timeout, True)
    # Always return something useful
    return {
        "exit_code": r.get("exit_code", -1),
        "stdout":    r.get("stdout", ""),
        "stderr":    r.get("stderr", ""),
        "error":     r.get("error"),
    } if "error" in r else {
        "exit_code": r["exit_code"],
        "stdout":    r["stdout"],
        "stderr":    r["stderr"],
        "success":   r["exit_code"] == 0,
    }


@_shield
async def tool_kill_process(pid: int = 0, name: str = "", signal_num: int = 15, **_) -> dict:
    pid = _safe_int(pid, 0)
    name = _safe_str(name)
    signal_num = _safe_int(signal_num, 15, 1, 31)
    killed = []
    errors = []
    if pid > 0:
        try:
            proc = psutil.Process(pid)
            pname = proc.name()
            proc.send_signal(signal_num)
            killed.append(f"PID {pid} ({pname})")
        except psutil.NoSuchProcess:
            return {"error": f"No process with PID {pid}"}
        except psutil.AccessDenied:
            return {"error": f"Permission denied to kill PID {pid}. Try running as root."}
        except Exception as e:
            return {"error": f"kill PID {pid}: {e}"}
    elif name:
        for p in psutil.process_iter(["pid","name"]):
            try:
                pname = p.info.get("name") or ""
                if name.lower() in pname.lower():
                    try:
                        p.send_signal(signal_num)
                        killed.append(f"PID {p.info['pid']} ({pname})")
                    except psutil.AccessDenied:
                        errors.append(f"PID {p.info['pid']}: permission denied")
                    except Exception as e:
                        errors.append(f"PID {p.info['pid']}: {e}")
            except Exception: pass
        if not killed and not errors:
            return {"error": f"No process matched name='{name}'"}
    else:
        return {"error": "Provide pid (int) or name (str)"}
    result: dict = {"killed": killed}
    if errors: result["errors"] = errors
    return result


@_shield
async def tool_list_processes(sort_by: str = "cpu", limit: int = 50, **_) -> dict:
    sort_by = _safe_str(sort_by, "cpu")
    limit = _safe_int(limit, 50, 1, 500)
    procs = []
    for p in psutil.process_iter(["pid","name","status","cpu_percent","memory_percent","username","create_time"]):
        try:
            i = p.info
            if not i.get("pid"): continue
            procs.append({
                "pid":    i["pid"],
                "name":   (i.get("name") or "?")[:40],
                "status": i.get("status","?"),
                "cpu_pct": round(float(i.get("cpu_percent") or 0), 1),
                "mem_pct": round(float(i.get("memory_percent") or 0), 2),
                "user":   (i.get("username") or "?")[:20],
            })
        except Exception: pass
    key = "mem_pct" if "mem" in sort_by.lower() else "cpu_pct"
    procs.sort(key=lambda x: x[key], reverse=True)
    return {"processes": procs[:limit], "total": len(procs)}


# ═════════════════════════════════════════════════════════════════════════════
# FILE SYSTEM
# ═════════════════════════════════════════════════════════════════════════════

@_shield
async def tool_list_directory(path: str = "~", show_hidden: bool = False, **_) -> dict:
    path = _safe_str(path, "~")
    show_hidden = _safe_bool(show_hidden, False)
    p, err = _check_path(path, must_exist=True, must_be_dir=True)
    if err: return {"error": err}
    items = []
    try:
        entries = sorted(p.iterdir(), key=lambda e: (e.is_file(), e.name.lower()))
    except PermissionError:
        return {"error": f"Permission denied: {p}"}
    for e in entries:
        if not show_hidden and e.name.startswith("."): continue
        try:
            st = e.stat()
            is_file = e.is_file()
            items.append({
                "name":       e.name,
                "type":       "file" if is_file else "dir",
                "media_type": _media_type(str(e)) if is_file else None,
                "size_bytes": st.st_size if is_file else None,
                "size_human": _sz(st.st_size) if is_file else None,
                "modified":   datetime.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M"),
                "readable":   os.access(str(e), os.R_OK),
                "writable":   os.access(str(e), os.W_OK),
            })
        except Exception:
            items.append({"name": e.name, "type": "unknown"})
    return {"path": str(p), "items": items, "count": len(items)}


@_shield
async def tool_read_file(path: str = "", max_lines: int = 150, encoding: str = "utf-8", **_) -> dict:
    path = _safe_str(path)
    max_lines = _safe_int(max_lines, 150, 1, 2000)
    encoding = _safe_str(encoding, "utf-8")
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}
    size = p.stat().st_size
    if size > 5_000_000:
        return {"error": f"File too large ({_sz(size)}). Max 5 MB for text reading."}
    # Try requested encoding, fallback to latin-1 (never fails)
    for enc in [encoding, "utf-8", "latin-1"]:
        try:
            text = p.read_text(encoding=enc, errors="replace")
            break
        except Exception: continue
    else:
        return {"error": f"Could not decode {p}"}
    lines = text.splitlines()
    return {
        "path": str(p),
        "lines_total": len(lines),
        "content": "\n".join(lines[:max_lines]),
        "truncated": len(lines) > max_lines,
        "encoding_used": enc,
        "size_human": _sz(size),
    }


@_shield
async def tool_write_file(path: str = "", content: str = "", append: bool = False,
                           encoding: str = "utf-8", **_) -> dict:
    path = _safe_str(path)
    content = _safe_str(content)
    append = _safe_bool(append)
    encoding = _safe_str(encoding, "utf-8")
    if not path: return {"error": "No path provided"}
    p = _resolve(path)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
    except PermissionError as e:
        return {"error": f"Cannot create directory: {e}"}
    mode = "a" if append else "w"
    try:
        with open(p, mode, encoding=encoding, errors="replace") as f:
            f.write(content)
        return {
            "path": str(p),
            "bytes_written": len(content.encode(encoding, errors="replace")),
            "mode": "append" if append else "overwrite",
            "size_human": _sz(p.stat().st_size),
        }
    except PermissionError:
        return {"error": f"Permission denied writing to {p}"}
    except Exception as e:
        return {"error": f"write_file: {e}"}


@_shield
async def tool_delete_file(path: str = "", force: bool = False, trash: bool = True, **_) -> dict:
    path = _safe_str(path)
    force = _safe_bool(force)
    trash = _safe_bool(trash, True)
    p, err = _check_path(path, must_exist=True)
    if err: return {"error": err}
    ftype = "file" if p.is_file() else "directory"
    # Try trash first (recoverable)
    if trash and not force:
        s2t = _pip("send2trash")
        if s2t:
            try:
                s2t.send2trash(str(p))
                return {"deleted": str(p), "type": ftype, "method": "moved_to_trash"}
            except Exception as e:
                log.warning("send2trash: %s — falling back to permanent", e)
    # Permanent delete
    try:
        if p.is_symlink() or p.is_file():
            p.unlink(missing_ok=True)
        elif p.is_dir():
            shutil.rmtree(str(p), ignore_errors=False)
        return {"deleted": str(p), "type": ftype, "method": "permanent"}
    except PermissionError:
        return {"error": f"Permission denied deleting {p}. Try running as root."}
    except Exception as e:
        return {"error": f"delete_file: {e}"}


@_shield
async def tool_copy_file(src: str = "", dst: str = "", **_) -> dict:
    src, dst = _safe_str(src), _safe_str(dst)
    if not src: return {"error": "No src path"}
    if not dst: return {"error": "No dst path"}
    s, err = _check_path(src, must_exist=True)
    if err: return {"error": err}
    d = _resolve(dst)
    try:
        d.parent.mkdir(parents=True, exist_ok=True)
        if s.is_file():
            shutil.copy2(str(s), str(d))
        elif s.is_dir():
            if d.exists(): shutil.rmtree(str(d))
            shutil.copytree(str(s), str(d))
        return {"copied": str(s), "to": str(d),
                "size_human": _sz(d.stat().st_size) if d.is_file() else None}
    except PermissionError:
        return {"error": f"Permission denied copying {s} → {d}"}
    except Exception as e:
        return {"error": f"copy_file: {e}"}


@_shield
async def tool_move_file(src: str = "", dst: str = "", **_) -> dict:
    src, dst = _safe_str(src), _safe_str(dst)
    if not src: return {"error": "No src"}
    if not dst: return {"error": "No dst"}
    s, err = _check_path(src, must_exist=True)
    if err: return {"error": err}
    d = _resolve(dst)
    try:
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(s), str(d))
        return {"moved": str(s), "to": str(d)}
    except PermissionError:
        return {"error": f"Permission denied moving {s}"}
    except Exception as e:
        return {"error": f"move_file: {e}"}


@_shield
async def tool_rename_file(path: str = "", new_name: str = "", **_) -> dict:
    path = _safe_str(path)
    new_name = _safe_str(new_name)
    if not new_name: return {"error": "No new_name provided"}
    # Strip path separators from new_name for safety
    new_name = re.sub(r"[/\\]", "_", new_name)
    p, err = _check_path(path, must_exist=True)
    if err: return {"error": err}
    dest = p.parent / new_name
    if dest.exists(): return {"error": f"'{dest.name}' already exists in {p.parent}"}
    try:
        p.rename(dest)
        return {"renamed": str(p), "to": str(dest), "new_name": new_name}
    except PermissionError:
        return {"error": f"Permission denied renaming {p}"}
    except Exception as e:
        return {"error": f"rename_file: {e}"}


@_shield
async def tool_search_files(query: str = "", path: str = "~", extension: str = "",
                              max_results: int = 50, **_) -> dict:
    query = _safe_str(query)
    path = _safe_str(path, "~")
    extension = _safe_str(extension)
    max_results = _safe_int(max_results, 50, 1, 500)
    if not query and not extension:
        return {"error": "Provide query (filename pattern) or extension (e.g. '.py')"}
    root, err = _check_path(path, must_exist=True, must_be_dir=True)
    if err: return {"error": err}
    if extension and not extension.startswith("."): extension = f".{extension}"
    pattern = f"*{query}*" if query else "*"
    matches = []
    try:
        for f in root.rglob(pattern):
            if extension and f.suffix.lower() != extension.lower(): continue
            try:
                st = f.stat()
                matches.append({
                    "path": str(f),
                    "name": f.name,
                    "type": "file" if f.is_file() else "dir",
                    "media_type": _media_type(str(f)) if f.is_file() else None,
                    "size_human": _sz(st.st_size) if f.is_file() else None,
                    "modified": datetime.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M"),
                })
            except Exception: pass
            if len(matches) >= max_results: break
    except PermissionError: pass
    return {"matches": matches, "count": len(matches), "root": str(root), "pattern": pattern}


@_shield
async def tool_create_directory(path: str = "", **_) -> dict:
    path = _safe_str(path)
    if not path: return {"error": "No path provided"}
    p = _resolve(path)
    try:
        p.mkdir(parents=True, exist_ok=True)
        return {"created": str(p), "exists": p.exists()}
    except PermissionError:
        return {"error": f"Permission denied creating {p}"}
    except Exception as e:
        return {"error": f"create_directory: {e}"}


@_shield
async def tool_disk_usage(path: str = "/", **_) -> dict:
    path = _safe_str(path, "/")
    p, err = _check_path(path, must_exist=True)
    if err: return {"error": err}
    try:
        u = shutil.disk_usage(str(p))
        pct = round(u.used / u.total * 100, 1) if u.total else 0
        # Also try to get all mounted partitions
        partitions = []
        try:
            for part in psutil.disk_partitions():
                try:
                    pu = psutil.disk_usage(part.mountpoint)
                    partitions.append({
                        "device": part.device,
                        "mountpoint": part.mountpoint,
                        "fstype": part.fstype,
                        "total_gb": round(pu.total / 1e9, 2),
                        "used_gb": round(pu.used / 1e9, 2),
                        "free_gb": round(pu.free / 1e9, 2),
                        "percent": round(pu.percent, 1),
                    })
                except Exception: pass
        except Exception: pass
        return {
            "path": str(p),
            "total_gb": round(u.total / 1e9, 3),
            "used_gb":  round(u.used  / 1e9, 3),
            "free_gb":  round(u.free  / 1e9, 3),
            "used_percent": pct,
            "all_partitions": partitions,
        }
    except Exception as e:
        return {"error": f"disk_usage: {e}"}


# ═════════════════════════════════════════════════════════════════════════════
# SCREENSHOT
# ═════════════════════════════════════════════════════════════════════════════

@_shield
async def tool_screenshot(**_) -> dict:
    out = Path(tempfile.mktemp(suffix=".png", prefix="bysalim_shot_"))
    took = False

    if SYS == "Darwin":
        r = _run(["screencapture", "-x", "-t", "png", str(out)], timeout=20)
        took = out.exists() and out.stat().st_size > 100

    elif SYS == "Windows":
        # PowerShell System.Drawing
        ps = (
            "Add-Type -AssemblyName System.Windows.Forms,System.Drawing;"
            "$s=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds;"
            "$b=New-Object System.Drawing.Bitmap($s.Width,$s.Height);"
            "$g=[System.Drawing.Graphics]::FromImage($b);"
            "$g.CopyFromScreen($s.Location,[System.Drawing.Point]::Empty,$s.Size);"
            f"$b.Save('{out}',[System.Drawing.Imaging.ImageFormat]::Png);"
            "$g.Dispose();$b.Dispose()"
        )
        _run(["powershell","-NonInteractive","-Command",ps], timeout=30)
        took = out.exists() and out.stat().st_size > 100

        if not took:
            pss = _pip("pyscreenshot")
            if pss:
                try:
                    loop = asyncio.get_event_loop()
                    img = await loop.run_in_executor(None, pss.grab)
                    img.save(str(out))
                    took = out.exists() and out.stat().st_size > 100
                except Exception: pass

        if not took:
            pil = _pip("Pillow", "PIL")
            if pil:
                try:
                    from PIL import ImageGrab
                    loop = asyncio.get_event_loop()
                    img = await loop.run_in_executor(None, ImageGrab.grab)
                    img.save(str(out))
                    took = out.exists() and out.stat().st_size > 100
                except Exception: pass

    else:  # Linux
        # Try CLI tools in priority order
        for cmd in [
            ["scrot", "-z", str(out)],
            ["maim", str(out)],
            ["gnome-screenshot", "-f", str(out)],
            ["import", "-window", "root", str(out)],
            ["grim", str(out)],
            ["spectacle", "-b", "-n", "-o", str(out)],
            ["flameshot", "full", "-p", str(out.parent), "--filename", out.name],
        ]:
            if not shutil.which(cmd[0]): continue
            _run(cmd, timeout=20)
            if out.exists() and out.stat().st_size > 100:
                took = True; break

        # xwd + convert fallback
        if not took and shutil.which("xwd") and shutil.which("convert"):
            xwd = out.with_suffix(".xwd")
            _run(["xwd", "-root", "-silent", "-out", str(xwd)], timeout=15)
            if xwd.exists():
                _run(["convert", str(xwd), str(out)], timeout=15)
                xwd.unlink(missing_ok=True)
                took = out.exists() and out.stat().st_size > 100

        # pyscreenshot (Python, wraps multiple backends)
        if not took:
            pss = _pip("pyscreenshot")
            if pss:
                try:
                    loop = asyncio.get_event_loop()
                    img = await loop.run_in_executor(None, pss.grab)
                    img.save(str(out))
                    took = out.exists() and out.stat().st_size > 100
                except Exception: pass

        # Pillow ImageGrab (X11)
        if not took:
            pil = _pip("Pillow", "PIL")
            if pil:
                try:
                    from PIL import ImageGrab
                    loop = asyncio.get_event_loop()
                    img = await loop.run_in_executor(None, ImageGrab.grab)
                    img.save(str(out))
                    took = out.exists() and out.stat().st_size > 100
                except Exception: pass

        # GNOME D-Bus portal (Wayland without grim)
        if not took and shutil.which("gdbus"):
            try:
                r = _run(["gdbus","call","--session",
                           "--dest","org.gnome.Shell.Screenshot",
                           "--object-path","/org/gnome/Shell/Screenshot",
                           "--method","org.gnome.Shell.Screenshot.Screenshot",
                           "true","true",str(out)], timeout=20)
                took = out.exists() and out.stat().st_size > 100
            except Exception: pass

        if not took:
            return {"error":
                "No screenshot tool found. Install one:\n"
                "  X11:     sudo apt install scrot\n"
                "  Wayland: sudo apt install grim\n"
                "  Any:     pip install pyscreenshot"}

    if not (out.exists() and out.stat().st_size > 0):
        return {"error": "Screenshot file empty or missing after capture"}
    size = out.stat().st_size
    return {"path": str(out), "size_bytes": size, "size_kb": round(size / 1024, 1)}


# ═════════════════════════════════════════════════════════════════════════════
# VOLUME
# ═════════════════════════════════════════════════════════════════════════════

@_shield
async def tool_get_volume(**_) -> dict:
    if SYS == "Darwin":
        r = _run(["osascript","-e","output volume of (get volume settings)"])
        if r.get("exit_code") == 0 and r.get("stdout","").strip():
            try: return {"volume": int(r["stdout"].strip().splitlines()[0])}
            except ValueError: pass
        return {"error": "osascript volume query failed", "hint": "Check System Preferences > Sound"}

    elif SYS == "Windows":
        # pycaw — COM API, most reliable
        pycaw = _pip("pycaw")
        if pycaw:
            try:
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                import comtypes
                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(IAudioEndpointVolume._iid_, comtypes.CLSCTX_ALL, None)
                vol_ctl = interface.QueryInterface(IAudioEndpointVolume)
                scalar = vol_ctl.GetMasterVolumeLevelScalar()
                muted = bool(vol_ctl.GetMute())
                return {"volume": round(scalar * 100), "muted": muted}
            except Exception as e:
                log.debug("pycaw get_volume: %s", e)
        # PowerShell WMPlayer (fallback)
        r = _run(["powershell","-NonInteractive","-Command",
                  "(New-Object -ComObject WMPlayer.OCX.7).settings.volume"], timeout=10)
        if r.get("exit_code") == 0 and r.get("stdout","").strip().isdigit():
            return {"volume": int(r["stdout"].strip())}
        # nircmd registry read
        if shutil.which("nircmd"):
            r2 = _run(["powershell","-NonInteractive","-Command",
                       "Get-ItemPropertyValue 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion"
                       "\\Applets\\Volume' -Name Volume 2>$null"], timeout=10)
            if r2.get("stdout","").strip().isdigit():
                return {"volume": round(int(r2["stdout"].strip()) / 655.35)}
        return {"error": "Could not read volume.\nInstall pycaw: pip install pycaw comtypes"}

    else:  # Linux
        for cmd, parse in [
            (["pactl","get-sink-volume","@DEFAULT_SINK@"],
             lambda o: int(re.search(r"(\d+)%",o).group(1)) if re.search(r"(\d+)%",o) else None),
            (["pactl","get-sink-volume","@DEFAULT_AUDIO_OUTPUT@"],
             lambda o: int(re.search(r"(\d+)%",o).group(1)) if re.search(r"(\d+)%",o) else None),
            (["amixer","-D","pulse","get","Master"],
             lambda o: int(re.search(r"\[(\d+)%\]",o).group(1)) if re.search(r"\[(\d+)%\]",o) else None),
            (["wpctl","get-volume","@DEFAULT_AUDIO_SINK@"],
             lambda o: int(float(re.search(r"[\d.]+",o).group(0))*100) if re.search(r"[\d.]+",o) else None),
            (["amixer","get","Master"],
             lambda o: int(re.search(r"\[(\d+)%\]",o).group(1)) if re.search(r"\[(\d+)%\]",o) else None),
        ]:
            if not shutil.which(cmd[0]): continue
            r = _run(cmd, timeout=8)
            if r.get("exit_code") == 0:
                try:
                    vol = parse(r.get("stdout",""))
                    if vol is not None: return {"volume": max(0, min(100, vol))}
                except Exception: pass
        # pulsectl Python binding
        pulsectl = _pip("pulsectl")
        if pulsectl:
            try:
                import pulsectl
                with pulsectl.Pulse("bysalim-vol") as pulse:
                    sinks = pulse.sink_list()
                    if sinks:
                        vol = round(sinks[0].volume.value_flat * 100)
                        muted = bool(sinks[0].mute)
                        return {"volume": max(0, min(100, vol)), "muted": muted}
            except Exception: pass
        return {"error":
            "No volume control available.\n"
            "Install: sudo apt install pulseaudio-utils\n"
            "Or:      sudo apt install wireplumber"}


@_shield
async def tool_set_volume(level: int = 50, **_) -> dict:
    level = _safe_int(level, 50, 0, 100)

    if SYS == "Darwin":
        r = _run(["osascript","-e",f"set volume output volume {level}"])
        return {"volume_set": level} if r.get("exit_code") == 0 else {"error": r.get("stderr","osascript failed")}

    elif SYS == "Windows":
        pycaw = _pip("pycaw")
        if pycaw:
            try:
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                import comtypes
                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(IAudioEndpointVolume._iid_, comtypes.CLSCTX_ALL, None)
                vol_ctl = interface.QueryInterface(IAudioEndpointVolume)
                vol_ctl.SetMasterVolumeLevelScalar(level / 100.0, None)
                return {"volume_set": level}
            except Exception as e:
                log.debug("pycaw set_volume: %s", e)
        if shutil.which("nircmd"):
            _run(["nircmd","setsysvolume",str(int(level * 655.35))])
            return {"volume_set": level}
        # PowerShell WScript
        r = _run(["powershell","-NonInteractive","-Command",
                  f"(New-Object -ComObject WMPlayer.OCX.7).settings.volume = {level}"], timeout=10)
        if r.get("exit_code") == 0: return {"volume_set": level}
        return {"error": "Cannot set volume.\nInstall: pip install pycaw comtypes\nOr download nircmd from nirsoft.net"}

    else:  # Linux
        for cmd in [
            ["pactl","set-sink-volume","@DEFAULT_AUDIO_SINK@",f"{level}%"],
            ["pactl","set-sink-volume","@DEFAULT_SINK@",f"{level}%"],
            ["amixer","-D","pulse","sset","Master",f"{level}%"],
            ["wpctl","set-volume","@DEFAULT_AUDIO_SINK@",f"{level/100:.2f}"],
            ["amixer","sset","Master",f"{level}%"],
        ]:
            if not shutil.which(cmd[0]): continue
            r = _run(cmd, timeout=8)
            if r.get("exit_code") == 0:
                return {"volume_set": level}
        pulsectl = _pip("pulsectl")
        if pulsectl:
            try:
                import pulsectl
                with pulsectl.Pulse("bysalim-setvol") as pulse:
                    for sink in pulse.sink_list():
                        pulse.volume_set_all_chans(sink, level / 100.0)
                return {"volume_set": level}
            except Exception: pass
        return {"error": "No volume control found.\nInstall: sudo apt install pulseaudio-utils"}


@_shield
async def tool_mute_volume(**_) -> dict:
    if SYS == "Darwin":
        _run(["osascript","-e","set volume with output muted"])
        return {"muted": True}

    elif SYS == "Windows":
        pycaw = _pip("pycaw")
        if pycaw:
            try:
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                import comtypes
                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(IAudioEndpointVolume._iid_, comtypes.CLSCTX_ALL, None)
                vol_ctl = interface.QueryInterface(IAudioEndpointVolume)
                vol_ctl.SetMute(1, None)
                return {"muted": True}
            except Exception: pass
        if shutil.which("nircmd"):
            _run(["nircmd","mutesysvolume","1"])
            return {"muted": True}
        # Media key VK_VOLUME_MUTE via PowerShell
        _run(["powershell","-NonInteractive","-Command",
              "(New-Object -ComObject WScript.Shell).SendKeys([char]173)"])
        return {"muted": True}

    else:  # Linux
        for cmd in [
            ["pactl","set-sink-mute","@DEFAULT_AUDIO_SINK@","1"],
            ["pactl","set-sink-mute","@DEFAULT_SINK@","1"],
            ["amixer","-D","pulse","sset","Master","mute"],
            ["wpctl","set-mute","@DEFAULT_AUDIO_SINK@","1"],
            ["amixer","sset","Master","mute"],
        ]:
            if not shutil.which(cmd[0]): continue
            r = _run(cmd, timeout=8)
            if r.get("exit_code") == 0: return {"muted": True}
        pulsectl = _pip("pulsectl")
        if pulsectl:
            try:
                import pulsectl
                with pulsectl.Pulse("bysalim-mute") as pulse:
                    for sink in pulse.sink_list():
                        pulse.mute(sink, True)
                return {"muted": True}
            except Exception: pass
        return {"error": "No mute control found.\nInstall: sudo apt install pulseaudio-utils"}


# ═════════════════════════════════════════════════════════════════════════════
# CLIPBOARD
# ═════════════════════════════════════════════════════════════════════════════

@_shield
async def tool_get_clipboard(**_) -> dict:
    # pyperclip first (cross-platform, works everywhere pip runs)
    pyperclip = _pip("pyperclip")
    if pyperclip:
        try:
            content = pyperclip.paste()
            if content is not None:
                return {"clipboard": content, "length": len(content)}
        except Exception: pass

    if SYS == "Darwin":
        r = _run(["pbpaste"])
        if r.get("exit_code") == 0:
            return {"clipboard": r.get("stdout",""), "length": len(r.get("stdout",""))}
    elif SYS == "Windows":
        r = _run(["powershell","-NonInteractive","-Command","Get-Clipboard"])
        if r.get("exit_code") == 0:
            c = r.get("stdout","")
            return {"clipboard": c, "length": len(c)}
    else:
        for tool, args in [
            ("xclip",   ["xclip","-selection","clipboard","-o"]),
            ("xsel",    ["xsel","--clipboard","--output"]),
            ("wl-paste",["wl-paste"]),
        ]:
            if not shutil.which(tool): continue
            r = _run(args, timeout=8)
            if r.get("exit_code") == 0:
                c = r.get("stdout","")
                return {"clipboard": c, "length": len(c)}

    return {"error":
        "No clipboard tool available.\n"
        "Install: pip install pyperclip\n"
        "Or (Linux): sudo apt install xclip"}


@_shield
async def tool_set_clipboard(text: str = "", **_) -> dict:
    text = _safe_str(text)
    enc = text.encode("utf-8")

    pyperclip = _pip("pyperclip")
    if pyperclip:
        try:
            pyperclip.copy(text)
            return {"clipboard_set": True, "length": len(text), "preview": text[:80]}
        except Exception: pass

    if SYS == "Darwin":
        r = subprocess.run(["pbcopy"], input=enc, timeout=10, capture_output=True)
        if r.returncode == 0: return {"clipboard_set": True, "length": len(text)}
    elif SYS == "Windows":
        r = _run(["powershell","-NonInteractive","-Command",
                  f"Set-Clipboard '{text.replace(chr(39), chr(39)*2)}'"], timeout=10)
        if r.get("exit_code") == 0: return {"clipboard_set": True, "length": len(text)}
    else:
        for tool, args in [
            ("xclip",  ["xclip","-selection","clipboard"]),
            ("xsel",   ["xsel","--clipboard","--input"]),
            ("wl-copy",["wl-copy"]),
        ]:
            if not shutil.which(tool): continue
            r = subprocess.run(args, input=enc, timeout=8, capture_output=True)
            if r.returncode == 0: return {"clipboard_set": True, "length": len(text)}

    return {"error":
        "No clipboard tool found.\n"
        "Install: pip install pyperclip\n"
        "Or (Linux): sudo apt install xclip"}


# ═════════════════════════════════════════════════════════════════════════════
# IMAGE — Pillow (auto-installed)
# ═════════════════════════════════════════════════════════════════════════════

def _get_pil():
    """Return PIL.Image or raise ImportError with install hint."""
    pil = _pip("Pillow", "PIL")
    if pil is None:
        raise ImportError("Pillow not available. Will auto-install on next call, or: pip install Pillow")
    from PIL import Image
    return Image


@_shield
async def tool_image_info(path: str = "", **_) -> dict:
    path = _safe_str(path)
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}
    try:
        Image = _get_pil()
        from PIL import ExifTags
    except ImportError as e:
        return {"error": str(e)}

    def _do():
        with Image.open(str(p)) as img:
            img.load()
            info: dict = {
                "path":        str(p),
                "format":      img.format or p.suffix.lstrip(".").upper(),
                "mode":        img.mode,
                "width":       img.width,
                "height":      img.height,
                "megapixels":  round(img.width * img.height / 1e6, 2),
                "size_bytes":  p.stat().st_size,
                "size_human":  _sz(p.stat().st_size),
                "aspect_ratio": f"{img.width}:{img.height}",
            }
            # Animated?
            try:
                if hasattr(img, "n_frames"): info["frames"] = img.n_frames
            except Exception: pass
            # EXIF via Pillow
            exif: dict = {}
            try:
                raw = img._getexif()
                if raw:
                    for tid, val in raw.items():
                        tag = ExifTags.TAGS.get(tid, str(tid))
                        if isinstance(val, (str, int, float)):
                            exif[tag] = str(val)[:100]
            except Exception: pass
            # EXIF via piexif (deeper GPS/maker notes)
            if not exif:
                piexif = _pip("piexif")
                if piexif:
                    try:
                        ed = piexif.load(str(p))
                        for ifd_name, ifd in ed.items():
                            if not isinstance(ifd, dict): continue
                            for k, v in ifd.items():
                                tag = piexif.TAGS.get(ifd_name, {}).get(k, {}).get("name", str(k))
                                if isinstance(v, (int, float)):
                                    exif[f"{ifd_name}.{tag}"] = v
                                elif isinstance(v, bytes) and len(v) < 100:
                                    try: exif[f"{ifd_name}.{tag}"] = v.decode("utf-8", errors="replace")
                                    except Exception: pass
                    except Exception: pass
            if exif: info["exif"] = exif
            # Color stats (mean brightness per channel)
            try:
                from PIL import ImageStat
                s = ImageStat.Stat(img)
                info["mean_brightness"] = round(sum(s.mean) / max(len(s.mean), 1), 1)
                if len(s.mean) >= 3:
                    info["mean_rgb"] = [round(v, 1) for v in s.mean[:3]]
            except Exception: pass
            return info
    return await _arun(_do)


@_shield
async def tool_image_resize(path: str = "", width: int = 0, height: int = 0,
                             output: str = "", keep_aspect: bool = True, **_) -> dict:
    path = _safe_str(path)
    width = _safe_int(width, 0, 0)
    height = _safe_int(height, 0, 0)
    keep_aspect = _safe_bool(keep_aspect, True)
    if not width and not height: return {"error": "Provide width and/or height in pixels"}
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}
    try: Image = _get_pil()
    except ImportError as e: return {"error": str(e)}
    out = _resolve(_safe_str(output)) if output else p

    def _do():
        with Image.open(str(p)) as img:
            ow, oh = img.size
            exif_data = img.info.get("exif", b"")
            if keep_aspect:
                if width and height:
                    img = img.copy(); img.thumbnail((width, height), Image.LANCZOS)
                elif width:
                    nh = max(1, int(oh * width / ow))
                    img = img.resize((width, nh), Image.LANCZOS)
                else:
                    nw = max(1, int(ow * height / oh))
                    img = img.resize((nw, height), Image.LANCZOS)
            else:
                img = img.resize((width or ow, height or oh), Image.LANCZOS)
            out.parent.mkdir(parents=True, exist_ok=True)
            fmt = (img.format or p.suffix.lstrip(".").upper() or "PNG").replace("JPG","JPEG")
            kw: dict = {"format": fmt}
            if exif_data and fmt in ("JPEG","WEBP"): kw["exif"] = exif_data
            if fmt == "JPEG" and img.mode in ("RGBA","P","LA"):
                bg = Image.new("RGB", img.size, (255,255,255))
                bg.paste(img, mask=img.split()[-1] if img.mode in ("RGBA","LA") else None)
                img = bg
            img.save(str(out), **kw)
            return {"resized": str(out), "orig_width": ow, "orig_height": oh,
                    "new_width": img.width, "new_height": img.height,
                    "size_human": _sz(out.stat().st_size)}
    return await _arun(_do)


@_shield
async def tool_image_rotate(path: str = "", angle: float = 90, output: str = "",
                              expand: bool = True, **_) -> dict:
    path = _safe_str(path)
    angle = _safe_float(angle, 90.0)
    expand = _safe_bool(expand, True)
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}
    try: Image = _get_pil()
    except ImportError as e: return {"error": str(e)}
    out = _resolve(_safe_str(output)) if output else p

    def _do():
        with Image.open(str(p)) as img:
            rotated = img.rotate(angle, expand=expand, resample=Image.BICUBIC)
            out.parent.mkdir(parents=True, exist_ok=True)
            fmt = (img.format or p.suffix.lstrip(".").upper() or "PNG").replace("JPG","JPEG")
            kw: dict = {"format": fmt}
            if fmt == "JPEG" and rotated.mode in ("RGBA","P","LA"):
                bg = Image.new("RGB", rotated.size, (255,255,255))
                bg.paste(rotated, mask=rotated.split()[-1] if "A" in rotated.mode else None)
                rotated = bg
            rotated.save(str(out), **kw)
            return {"rotated": str(out), "angle": angle,
                    "width": rotated.width, "height": rotated.height,
                    "size_human": _sz(out.stat().st_size)}
    return await _arun(_do)


@_shield
async def tool_image_crop(path: str = "", left: int = 0, top: int = 0,
                           right: int = 0, bottom: int = 0, output: str = "", **_) -> dict:
    path = _safe_str(path)
    left = _safe_int(left, 0, 0)
    top  = _safe_int(top,  0, 0)
    right  = _safe_int(right,  0, 0)
    bottom = _safe_int(bottom, 0, 0)
    if not any([left, top, right, bottom]):
        return {"error": "Provide crop box: left, top, right, bottom (pixels)"}
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}
    try: Image = _get_pil()
    except ImportError as e: return {"error": str(e)}
    out = _resolve(_safe_str(output)) if output else p

    def _do():
        with Image.open(str(p)) as img:
            w, h = img.size
            r = right  or w
            b = bottom or h
            # Clamp to image bounds
            r = min(r, w); b = min(b, h)
            l = max(0, left); t = max(0, top)
            if l >= r or t >= b:
                return {"error": f"Invalid crop box {l},{t},{r},{b} for image {w}x{h}"}
            cropped = img.crop((l, t, r, b))
            out.parent.mkdir(parents=True, exist_ok=True)
            fmt = (img.format or p.suffix.lstrip(".").upper() or "PNG").replace("JPG","JPEG")
            cropped.save(str(out), format=fmt)
            return {"cropped": str(out), "box": [l,t,r,b],
                    "width": cropped.width, "height": cropped.height,
                    "size_human": _sz(out.stat().st_size)}
    return await _arun(_do)


@_shield
async def tool_image_convert(path: str = "", format: str = "", output: str = "",
                              quality: int = 90, **_) -> dict:
    path = _safe_str(path)
    format = _safe_str(format)
    quality = _safe_int(quality, 90, 1, 100)
    if not format and not output:
        return {"error": "Provide format (e.g. 'jpg') or output path"}
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}
    try: Image = _get_pil()
    except ImportError as e: return {"error": str(e)}
    if output:
        out = _resolve(output)
        fmt = (out.suffix.lstrip(".").upper() or format.upper()).replace("JPG","JPEG")
    else:
        fmt = format.upper().replace("JPG","JPEG")
        ext = fmt.lower().replace("jpeg","jpg")
        out = p.with_suffix(f".{ext}")
    if fmt not in ("JPEG","PNG","WEBP","BMP","GIF","TIFF","ICO","PPM","RGBA"):
        return {"error": f"Unsupported format '{fmt}'. Use: jpg, png, webp, bmp, gif, tiff"}

    def _do():
        with Image.open(str(p)) as img:
            # Handle transparency for JPEG
            if fmt == "JPEG":
                if img.mode in ("RGBA","P","LA"):
                    bg = Image.new("RGB", img.size, (255,255,255))
                    if img.mode == "P": img = img.convert("RGBA")
                    mask = img.split()[-1] if img.mode in ("RGBA","LA") else None
                    bg.paste(img, mask=mask)
                    img = bg
                elif img.mode != "RGB":
                    img = img.convert("RGB")
            elif fmt == "PNG" and img.mode not in ("RGB","RGBA","L","LA","P"):
                img = img.convert("RGBA")
            elif fmt == "BMP" and img.mode not in ("RGB","RGBA","L"):
                img = img.convert("RGB")
            out.parent.mkdir(parents=True, exist_ok=True)
            kw: dict = {"format": fmt}
            if fmt in ("JPEG","WEBP"): kw["quality"] = quality
            if fmt == "PNG": kw["optimize"] = True
            img.save(str(out), **kw)
            return {"converted": str(out), "format": fmt,
                    "width": img.width, "height": img.height,
                    "size_human": _sz(out.stat().st_size)}
    return await _arun(_do)


# ═════════════════════════════════════════════════════════════════════════════
# AUDIO
# ═════════════════════════════════════════════════════════════════════════════

@_shield
async def tool_audio_info(path: str = "", **_) -> dict:
    path = _safe_str(path)
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}

    def _do() -> dict:
        info: dict = {
            "path": str(p),
            "filename": p.name,
            "format": p.suffix.upper().lstrip("."),
            "size_bytes": p.stat().st_size,
            "size_human": _sz(p.stat().st_size),
        }

        # Strategy 1: ffprobe — handles every format, reads all tags
        if shutil.which("ffprobe"):
            r = _run(["ffprobe","-v","quiet","-print_format","json",
                      "-show_streams","-show_format", str(p)], timeout=15)
            if r.get("exit_code") == 0 and r.get("stdout"):
                try:
                    d = json.loads(r["stdout"])
                    fmt = d.get("format", {})
                    dur = float(fmt.get("duration", 0) or 0)
                    if dur > 0:
                        info["duration_seconds"] = round(dur, 2)
                        m, s = divmod(int(dur), 60)
                        h, m = divmod(m, 60)
                        info["duration"] = f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"
                    br = int(fmt.get("bit_rate", 0) or 0)
                    if br: info["bitrate_kbps"] = round(br / 1000, 1)
                    for stream in d.get("streams", []):
                        if stream.get("codec_type") == "audio":
                            info["codec"]          = stream.get("codec_name","")
                            info["codec_long"]     = stream.get("codec_long_name","")
                            if stream.get("sample_rate"):
                                info["sample_rate_hz"] = int(stream["sample_rate"])
                            if stream.get("channels"):
                                info["channels"] = int(stream["channels"])
                            info["channel_layout"] = stream.get("channel_layout","")
                            if stream.get("bit_rate"):
                                info["stream_bitrate_kbps"] = round(int(stream["bit_rate"]) / 1000, 1)
                            break
                    for k, v in fmt.get("tags", {}).items():
                        kl = k.lower()
                        if kl in ("title","artist","album","date","genre","track","comment","album_artist"):
                            info[kl] = str(v)
                    return info
                except Exception: pass

        # Strategy 2: mutagen — pure Python, reads tags for MP3/FLAC/OGG/M4A/AIFF etc.
        mutagen = _pip("mutagen")
        if mutagen:
            try:
                from mutagen import File as MFile
                mf = MFile(str(p), easy=True)
                if mf is not None:
                    fi = mf.info
                    dur = getattr(fi, "length", None)
                    if dur:
                        info["duration_seconds"] = round(float(dur), 2)
                        m, s = divmod(int(dur), 60)
                        info["duration"] = f"{m}:{s:02d}"
                    br = getattr(fi, "bitrate", None)
                    if br: info["bitrate_kbps"] = round(br / 1000, 1)
                    sr = getattr(fi, "sample_rate", None)
                    if sr: info["sample_rate_hz"] = int(sr)
                    ch = getattr(fi, "channels", None)
                    if ch: info["channels"] = int(ch)
                    for tag in ("title","artist","album","date","genre","tracknumber","comment"):
                        v = mf.get(tag)
                        if v: info[tag] = str(v[0]) if isinstance(v, list) else str(v)
                    return info
            except Exception: pass

        # Strategy 3: stdlib wave for WAV
        if p.suffix.lower() == ".wav":
            try:
                with wave.open(str(p), "r") as wf:
                    frames   = wf.getnframes()
                    rate     = wf.getframerate()
                    channels = wf.getnchannels()
                    width    = wf.getsampwidth()
                    dur      = frames / rate if rate else 0
                info["duration_seconds"] = round(dur, 2)
                m, s = divmod(int(dur), 60)
                info["duration"] = f"{m}:{s:02d}"
                info["sample_rate_hz"] = rate
                info["channels"]       = channels
                info["bit_depth"]      = width * 8
                info["bitrate_kbps"]   = round(rate * channels * width * 8 / 1000, 1)
                return info
            except Exception: pass

        # Strategy 4: Raw ID3v2 + MP3 frame scan
        if p.suffix.lower() == ".mp3":
            try:
                fsize = p.stat().st_size
                with open(str(p), "rb") as f:
                    raw = f.read(min(fsize, 8 * 1024 * 1024))
                # ID3v2 tags
                if raw[:3] == b"ID3":
                    sz_b = raw[6:10]
                    tag_sz = ((sz_b[0] & 0x7F)<<21)|((sz_b[1] & 0x7F)<<14)|((sz_b[2] & 0x7F)<<7)|(sz_b[3] & 0x7F)
                    body = raw[10:10 + tag_sz]
                    pos = 0
                    name_map = {"TIT2":"title","TPE1":"artist","TALB":"album","TDRC":"date",
                                "TCON":"genre","TRCK":"track","TPOS":"disc"}
                    while pos < len(body) - 10:
                        fid = body[pos:pos+4]
                        if not fid or fid[0:1] == b"\x00": break
                        try:
                            fid_str = fid.decode("latin-1")
                            fsize_t = struct.unpack(">I", body[pos+4:pos+8])[0]
                            if fid_str in name_map and fsize_t > 0:
                                fdata = body[pos+10:pos+10+fsize_t]
                                enc = fdata[0] if fdata else 0
                                text_val = fdata[1:].decode(
                                    "utf-16" if enc in (1,2) else "utf-8", errors="replace"
                                ).strip("\x00").strip()
                                if text_val: info[name_map[fid_str]] = text_val
                            pos += 10 + fsize_t
                        except Exception: break
                # Frame scan for bitrate/duration
                br_table = [0,32,40,48,56,64,80,96,112,128,160,192,224,256,320,0]
                sr_table = {0:[44100,48000,32000,0], 3:[44100,48000,32000,0]}
                file_size = p.stat().st_size
                for i in range(min(len(raw)-4, 200000)):
                    if raw[i] == 0xFF and (raw[i+1] & 0xE0) == 0xE0:
                        b2 = raw[i+2]
                        bi = (b2 >> 4) & 0xF
                        si = (b2 >> 2) & 0x3
                        if 0 < bi < 15 and si < 3:
                            br = br_table[bi] * 1000
                            sr = [44100, 48000, 32000][si]
                            if br > 0 and sr > 0:
                                dur = (file_size * 8) / br
                                info["duration_seconds"] = round(dur, 2)
                                m, s = divmod(int(dur), 60)
                                info["duration"] = f"{m}:{s:02d}"
                                info["bitrate_kbps"] = br // 1000
                                info["sample_rate_hz"] = sr
                                break
            except Exception: pass
            return info

        info["note"] = (
            "Limited info available. Install ffmpeg for full metadata:\n"
            "  sudo apt install ffmpeg  (Linux)\n"
            "  brew install ffmpeg      (Mac)\n"
            "  winget install ffmpeg    (Windows)"
        )
        return info

    return await _arun(_do)


@_shield
async def tool_audio_convert(path: str = "", format: str = "mp3", output: str = "",
                              bitrate: str = "", **_) -> dict:
    path = _safe_str(path)
    format = _safe_str(format, "mp3").lower().lstrip(".")
    bitrate = _safe_str(bitrate)
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}
    out = _resolve(_safe_str(output)) if output else p.with_suffix(f".{format}")
    out.parent.mkdir(parents=True, exist_ok=True)

    # Method 1: ffmpeg — best
    if shutil.which("ffmpeg"):
        cmd = ["ffmpeg","-y","-i",str(p)]
        if bitrate: cmd += ["-b:a", bitrate]
        # Format-specific quality settings
        if format == "mp3" and not bitrate: cmd += ["-q:a","2"]
        elif format == "ogg" and not bitrate: cmd += ["-q:a","4"]
        elif format == "flac": cmd += ["-compression_level","5"]
        cmd.append(str(out))
        r = await _arun(_run, cmd, 300)
        if out.exists() and out.stat().st_size > 0:
            return {"converted": str(out), "format": format, "size_human": _sz(out.stat().st_size)}
        return {"error": f"ffmpeg failed: {r.get('stderr','')[:500]}"}

    # Method 2: pydub
    pydub = _pip("pydub")
    if pydub:
        try:
            from pydub import AudioSegment
            audio = AudioSegment.from_file(str(p))
            kw: dict = {}
            if bitrate: kw["bitrate"] = bitrate
            audio.export(str(out), format=format, **kw)
            if out.exists() and out.stat().st_size > 0:
                return {"converted": str(out), "format": format, "size_human": _sz(out.stat().st_size)}
        except Exception as e:
            return {"error": f"pydub failed: {e}"}

    return {"error":
        "ffmpeg not found. Install it:\n"
        "  Linux:   sudo apt install ffmpeg\n"
        "  Mac:     brew install ffmpeg\n"
        "  Windows: winget install ffmpeg"}


@_shield
async def tool_audio_trim(path: str = "", start: float = 0, duration: float = 0,
                           output: str = "", **_) -> dict:
    path = _safe_str(path)
    start = _safe_float(start, 0.0, 0.0)
    duration = _safe_float(duration, 0.0, 0.0)
    if duration <= 0: return {"error": "Provide duration > 0 (seconds to keep)"}
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}
    out_path = _safe_str(output)
    out = _resolve(out_path) if out_path else p.with_stem(p.stem + "_trimmed")
    out.parent.mkdir(parents=True, exist_ok=True)

    if shutil.which("ffmpeg"):
        cmd = ["ffmpeg","-y","-i",str(p),"-ss",str(start),"-t",str(duration),
               "-c","copy", str(out)]
        r = await _arun(_run, cmd, 300)
        if out.exists() and out.stat().st_size > 0:
            return {"trimmed": str(out), "start_sec": start, "duration_sec": duration,
                    "size_human": _sz(out.stat().st_size)}
        # Retry with re-encode (some formats don't support stream copy)
        cmd2 = ["ffmpeg","-y","-i",str(p),"-ss",str(start),"-t",str(duration), str(out)]
        r2 = await _arun(_run, cmd2, 300)
        if out.exists() and out.stat().st_size > 0:
            return {"trimmed": str(out), "start_sec": start, "duration_sec": duration,
                    "size_human": _sz(out.stat().st_size)}
        return {"error": f"ffmpeg trim failed: {r2.get('stderr','')[:400]}"}

    pydub = _pip("pydub")
    if pydub:
        try:
            from pydub import AudioSegment
            audio = AudioSegment.from_file(str(p))
            trimmed = audio[int(start * 1000) : int((start + duration) * 1000)]
            fmt = out.suffix.lstrip(".")
            trimmed.export(str(out), format=fmt)
            if out.exists(): return {"trimmed": str(out), "start_sec": start, "duration_sec": duration}
        except Exception as e:
            return {"error": f"pydub trim: {e}"}

    return {"error": "ffmpeg not found. Install: sudo apt install ffmpeg"}


# ═════════════════════════════════════════════════════════════════════════════
# VIDEO
# ═════════════════════════════════════════════════════════════════════════════

@_shield
async def tool_video_info(path: str = "", **_) -> dict:
    path = _safe_str(path)
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}

    def _do() -> dict:
        info: dict = {
            "path": str(p),
            "filename": p.name,
            "size_bytes": p.stat().st_size,
            "size_human": _sz(p.stat().st_size),
        }

        # Strategy 1: ffprobe
        if shutil.which("ffprobe"):
            r = _run(["ffprobe","-v","quiet","-print_format","json",
                      "-show_streams","-show_format", str(p)], timeout=20)
            if r.get("exit_code") == 0 and r.get("stdout"):
                try:
                    d = json.loads(r["stdout"])
                    fmt = d.get("format", {})
                    dur = float(fmt.get("duration", 0) or 0)
                    info["duration_seconds"] = round(dur, 2)
                    h_, rem = divmod(int(dur), 3600)
                    m_, s_  = divmod(rem, 60)
                    info["duration"] = f"{h_}:{m_:02d}:{s_:02d}" if h_ else f"{m_}:{s_:02d}"
                    br = int(fmt.get("bit_rate", 0) or 0)
                    info["bit_rate_kbps"]  = round(br / 1000, 1)
                    info["format_name"]    = fmt.get("format_long_name", fmt.get("format_name",""))
                    info["nb_streams"]     = fmt.get("nb_streams", 0)
                    for stream in d.get("streams", []):
                        ct = stream.get("codec_type")
                        if ct == "video" and "video_codec" not in info:
                            info["video_codec"]  = stream.get("codec_name","")
                            info["video_profile"]= stream.get("profile","")
                            info["width"]        = stream.get("width")
                            info["height"]       = stream.get("height")
                            if info["width"] and info["height"]:
                                info["resolution"] = f"{info['width']}x{info['height']}"
                            rfr = stream.get("r_frame_rate","0/1")
                            try:
                                n, dd = rfr.split("/")
                                info["fps"] = round(int(n)/int(dd), 3) if int(dd) else 0
                            except Exception:
                                info["fps"] = rfr
                            info["pix_fmt"] = stream.get("pix_fmt","")
                        elif ct == "audio" and "audio_codec" not in info:
                            info["audio_codec"]       = stream.get("codec_name","")
                            info["audio_channels"]    = stream.get("channels")
                            info["audio_sample_rate"] = stream.get("sample_rate")
                            info["audio_layout"]      = stream.get("channel_layout","")
                    return info
                except Exception: pass

        # Strategy 2: hachoir (pure Python)
        hachoir = _pip("hachoir")
        if hachoir:
            try:
                from hachoir.parser import createParser
                from hachoir.metadata import extractMetadata
                parser = createParser(str(p))
                if parser:
                    meta = extractMetadata(parser)
                    if meta:
                        for line in meta.exportPlaintext():
                            if "Duration" in line:
                                info["duration"] = line.split(":",1)[-1].strip()
                            elif "Image width" in line:
                                try: info["width"] = int(line.split(":",1)[-1].strip().split()[0])
                                except Exception: pass
                            elif "Image height" in line:
                                try: info["height"] = int(line.split(":",1)[-1].strip().split()[0])
                                except Exception: pass
                            elif "Frame rate" in line:
                                try: info["fps"] = float(line.split(":",1)[-1].strip().split()[0])
                                except Exception: pass
                            elif "Bit rate" in line:
                                try: info["bit_rate_kbps"] = float(line.split(":",1)[-1].strip().split()[0])
                                except Exception: pass
                        if "width" in info and "height" in info:
                            info["resolution"] = f"{info['width']}x{info['height']}"
                        return info
            except Exception as e:
                log.debug("hachoir: %s", e)

        # Strategy 3: mediainfo CLI
        if shutil.which("mediainfo"):
            r = _run(["mediainfo","--Output=JSON", str(p)], timeout=15)
            if r.get("exit_code") == 0 and r.get("stdout"):
                try:
                    d = json.loads(r["stdout"])
                    for track in d.get("media",{}).get("track",[]):
                        tt = track.get("@type")
                        if tt == "General":
                            dur = float(track.get("Duration", 0) or 0)
                            if dur:
                                info["duration_seconds"] = round(dur, 2)
                                m_, s_ = divmod(int(dur), 60)
                                info["duration"] = f"{m_}:{s_:02d}"
                        elif tt == "Video":
                            info["video_codec"] = track.get("Format","")
                            w = track.get("Width")
                            h = track.get("Height")
                            if w and h:
                                info["width"] = int(w); info["height"] = int(h)
                                info["resolution"] = f"{info['width']}x{info['height']}"
                            fr = track.get("FrameRate")
                            if fr: info["fps"] = float(fr)
                        elif tt == "Audio":
                            info["audio_codec"] = track.get("Format","")
                    return info
                except Exception: pass

        info["note"] = (
            "Install ffmpeg for full video metadata:\n"
            "  Linux:   sudo apt install ffmpeg\n"
            "  Mac:     brew install ffmpeg\n"
            "  Windows: winget install ffmpeg"
        )
        return info

    return await _arun(_do)


@_shield
async def tool_video_thumbnail(path: str = "", time_sec: float = 1.0, output: str = "", **_) -> dict:
    path = _safe_str(path)
    time_sec = _safe_float(time_sec, 1.0, 0.0)
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}
    out_s = _safe_str(output)
    out = _resolve(out_s) if out_s else p.with_suffix(".thumb.jpg")
    out.parent.mkdir(parents=True, exist_ok=True)

    if shutil.which("ffmpeg"):
        cmd = ["ffmpeg","-y","-ss",str(time_sec),"-i",str(p),
               "-vframes","1","-q:v","2","-vf","scale=iw:ih",str(out)]
        r = await _arun(_run, cmd, 60)
        if out.exists() and out.stat().st_size > 0:
            return {"thumbnail": str(out), "at_sec": time_sec, "size_human": _sz(out.stat().st_size)}
        # Fallback: try without -ss before input (seek after may work for some containers)
        cmd2 = ["ffmpeg","-y","-i",str(p),"-ss",str(time_sec),
                "-vframes","1","-q:v","2", str(out)]
        await _arun(_run, cmd2, 60)
        if out.exists() and out.stat().st_size > 0:
            return {"thumbnail": str(out), "at_sec": time_sec, "size_human": _sz(out.stat().st_size)}
        return {"error": f"ffmpeg thumbnail failed: {r.get('stderr','')[:300]}"}

    # OpenCV fallback
    cv2_mod = _pip("opencv-python", "cv2")
    if cv2_mod:
        try:
            import cv2
            def _grab():
                cap = cv2.VideoCapture(str(p))
                cap.set(cv2.CAP_PROP_POS_MSEC, time_sec * 1000)
                ok, frame = cap.read()
                cap.release()
                if ok:
                    cv2.imwrite(str(out), frame)
                    return True
                return False
            ok = await _arun(_grab)
            if ok and out.exists():
                return {"thumbnail": str(out), "at_sec": time_sec, "size_human": _sz(out.stat().st_size)}
        except Exception as e:
            return {"error": f"OpenCV thumbnail: {e}"}

    return {"error": "ffmpeg required for video thumbnails. Install: sudo apt install ffmpeg"}


@_shield
async def tool_video_convert(path: str = "", format: str = "mp4", output: str = "", **_) -> dict:
    path = _safe_str(path)
    format = _safe_str(format, "mp4").lower().lstrip(".")
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}
    out_s = _safe_str(output)
    out = _resolve(out_s) if out_s else p.with_suffix(f".{format}")
    if out == p:
        out = p.with_stem(p.stem + f"_converted").with_suffix(f".{format}")
    out.parent.mkdir(parents=True, exist_ok=True)

    if not shutil.which("ffmpeg"):
        return {"error":
            "ffmpeg required for video conversion.\n"
            "  Linux:   sudo apt install ffmpeg\n"
            "  Mac:     brew install ffmpeg\n"
            "  Windows: winget install ffmpeg"}

    # Format-specific codec hints
    codec_hints: dict = {
        "mp4":  ["-c:v","libx264","-c:a","aac","-movflags","+faststart"],
        "webm": ["-c:v","libvpx-vp9","-c:a","libopus"],
        "mkv":  [],
        "avi":  ["-c:v","libxvid","-c:a","mp3"],
        "gif":  ["-vf","fps=10,scale=480:-1:flags=lanczos","-loop","0"],
        "mov":  ["-c:v","libx264","-c:a","aac"],
    }
    extra = codec_hints.get(format, [])
    cmd = ["ffmpeg","-y","-i",str(p)] + extra + [str(out)]
    r = await _arun(_run, cmd, 600)
    if out.exists() and out.stat().st_size > 0:
        return {"converted": str(out), "format": format, "size_human": _sz(out.stat().st_size)}
    # Retry with no codec hints (let ffmpeg choose)
    if extra:
        cmd2 = ["ffmpeg","-y","-i",str(p), str(out)]
        r2 = await _arun(_run, cmd2, 600)
        if out.exists() and out.stat().st_size > 0:
            return {"converted": str(out), "format": format, "size_human": _sz(out.stat().st_size)}
        return {"error": f"ffmpeg failed: {r2.get('stderr','')[:500]}"}
    return {"error": f"ffmpeg failed: {r.get('stderr','')[:500]}"}


@_shield
async def tool_video_trim(path: str = "", start: float = 0, duration: float = 0,
                           output: str = "", **_) -> dict:
    path = _safe_str(path)
    start = _safe_float(start, 0.0, 0.0)
    duration = _safe_float(duration, 0.0, 0.0)
    if duration <= 0: return {"error": "Provide duration > 0 (seconds to keep)"}
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}
    out_s = _safe_str(output)
    out = _resolve(out_s) if out_s else p.with_stem(p.stem + "_trimmed")
    out.parent.mkdir(parents=True, exist_ok=True)

    if not shutil.which("ffmpeg"):
        return {"error": "ffmpeg required. Install: sudo apt install ffmpeg"}

    # Fast copy (no re-encode)
    cmd = ["ffmpeg","-y","-i",str(p),"-ss",str(start),"-t",str(duration),"-c","copy", str(out)]
    r = await _arun(_run, cmd, 600)
    if out.exists() and out.stat().st_size > 0:
        return {"trimmed": str(out), "start_sec": start, "duration_sec": duration,
                "size_human": _sz(out.stat().st_size), "method": "stream_copy"}
    # Re-encode fallback
    if out.exists(): out.unlink()
    cmd2 = ["ffmpeg","-y","-i",str(p),"-ss",str(start),"-t",str(duration), str(out)]
    r2 = await _arun(_run, cmd2, 600)
    if out.exists() and out.stat().st_size > 0:
        return {"trimmed": str(out), "start_sec": start, "duration_sec": duration,
                "size_human": _sz(out.stat().st_size), "method": "re-encode"}
    return {"error": f"ffmpeg trim failed: {r2.get('stderr','')[:500]}"}


# ═════════════════════════════════════════════════════════════════════════════
# SEND FILE
# ═════════════════════════════════════════════════════════════════════════════

@_shield
async def tool_send_file(path: str = "", caption: str = "", **_) -> dict:
    path = _safe_str(path)
    caption = _safe_str(caption)
    p, err = _check_path(path, must_exist=True, must_be_file=True)
    if err: return {"error": err}
    mt = _media_type(str(p))
    size = p.stat().st_size
    if size > 50 * 1024 * 1024:
        return {"error": f"File too large ({_sz(size)}). Telegram limit is 50 MB."}
    if size == 0:
        return {"error": "File is empty — nothing to send"}
    cap = caption or f"📎 {p.name} ({_sz(size)})"
    await _push_file(str(p), cap, mt)
    return {"sent": str(p), "media_type": mt, "size_human": _sz(size), "caption": cap}


# ═════════════════════════════════════════════════════════════════════════════
# APP LAUNCHER
# ═════════════════════════════════════════════════════════════════════════════

_ALIASES: dict[str, dict[str, str | list]] = {
    "chrome":       {"Linux":["google-chrome","google-chrome-stable","chromium-browser","chromium"],
                     "Darwin":"Google Chrome","Windows":"chrome"},
    "chromium":     {"Linux":["chromium","chromium-browser"],"Darwin":"Chromium","Windows":"chromium"},
    "firefox":      {"Linux":"firefox","Darwin":"Firefox","Windows":"firefox"},
    "safari":       {"Linux":"","Darwin":"Safari","Windows":""},
    "edge":         {"Linux":["microsoft-edge","microsoft-edge-stable"],
                     "Darwin":"Microsoft Edge","Windows":"msedge"},
    "vscode":       {"Linux":"code","Darwin":"Visual Studio Code","Windows":"code"},
    "vs code":      {"Linux":"code","Darwin":"Visual Studio Code","Windows":"code"},
    "code":         {"Linux":"code","Darwin":"Visual Studio Code","Windows":"code"},
    "terminal":     {"Linux":["x-terminal-emulator","gnome-terminal","konsole","xfce4-terminal",
                               "xterm","alacritty","kitty","tilix"],
                     "Darwin":"Terminal","Windows":"cmd"},
    "calculator":   {"Linux":["gnome-calculator","kcalc","galculator","qalculate-gtk"],
                     "Darwin":"Calculator","Windows":"calc"},
    "vlc":          {"Linux":"vlc","Darwin":"VLC","Windows":"vlc"},
    "spotify":      {"Linux":"spotify","Darwin":"Spotify","Windows":"spotify"},
    "slack":        {"Linux":"slack","Darwin":"Slack","Windows":"slack"},
    "zoom":         {"Linux":["zoom","ZoomLauncher"],"Darwin":"zoom.us","Windows":"zoom"},
    "discord":      {"Linux":["discord","Discord"],"Darwin":"Discord","Windows":"discord"},
    "telegram":     {"Linux":["telegram-desktop","Telegram"],"Darwin":"Telegram","Windows":"telegram"},
    "files":        {"Linux":["nautilus","dolphin","thunar","nemo","pcmanfm"],
                     "Darwin":"Finder","Windows":"explorer"},
    "finder":       {"Linux":"nautilus","Darwin":"Finder","Windows":"explorer"},
    "file manager": {"Linux":["nautilus","dolphin","thunar","nemo","pcmanfm"],
                     "Darwin":"Finder","Windows":"explorer"},
    "gimp":         {"Linux":"gimp","Darwin":"GIMP","Windows":"gimp"},
    "inkscape":     {"Linux":"inkscape","Darwin":"Inkscape","Windows":"inkscape"},
    "notepad":      {"Linux":["gedit","mousepad","kate","xed","pluma","geany"],
                     "Darwin":"TextEdit","Windows":"notepad"},
    "textedit":     {"Linux":"gedit","Darwin":"TextEdit","Windows":"notepad"},
    "gedit":        {"Linux":"gedit","Darwin":"TextEdit","Windows":"notepad"},
    "obs":          {"Linux":"obs","Darwin":"OBS","Windows":"obs64"},
    "audacity":     {"Linux":"audacity","Darwin":"Audacity","Windows":"audacity"},
    "libreoffice":  {"Linux":["libreoffice","soffice"],"Darwin":"LibreOffice","Windows":"soffice"},
    "thunderbird":  {"Linux":"thunderbird","Darwin":"Thunderbird","Windows":"thunderbird"},
    "nautilus":     {"Linux":"nautilus","Darwin":"Finder","Windows":"explorer"},
    "dolphin":      {"Linux":"dolphin","Darwin":"Finder","Windows":"explorer"},
    "steam":        {"Linux":"steam","Darwin":"Steam","Windows":"steam"},
    "pycharm":      {"Linux":["pycharm","pycharm.sh"],"Darwin":"PyCharm","Windows":"pycharm"},
    "intellij":     {"Linux":["idea","idea.sh"],"Darwin":"IntelliJ IDEA","Windows":"idea"},
    "postman":      {"Linux":"postman","Darwin":"Postman","Windows":"postman"},
    "dbeaver":      {"Linux":"dbeaver","Darwin":"DBeaver","Windows":"dbeaver"},
}


@_shield
async def tool_open_application(name: str = "", file_path: str = "", **_) -> dict:
    name = _safe_str(name)
    file_path = _safe_str(file_path)
    if not name and not file_path:
        return {"error": "Provide app name or file_path"}

    if file_path and not name:
        p, err = _check_path(file_path, must_exist=True)
        if err: return {"error": err}
        return await _open_with_default(str(p))

    key = name.strip().lower()
    aliases = _ALIASES.get(key, {})
    raw = aliases.get(SYS, name.strip())
    candidates: list[str] = raw if isinstance(raw, list) else ([raw] if raw else [])
    if name.strip() not in candidates: candidates.append(name.strip())
    extra = [str(_resolve(file_path))] if file_path else []

    if SYS == "Darwin":   return await _launch_mac(candidates, extra)
    elif SYS == "Windows": return await _launch_win(candidates, extra)
    else:                  return await _launch_linux(candidates, name.strip(), extra)


async def _open_with_default(path: str) -> dict:
    if SYS == "Darwin":
        subprocess.Popen(["open", path], start_new_session=True)
        return {"opened_file": path, "method": "open"}
    elif SYS == "Windows":
        try:
            os.startfile(path)  # type: ignore
            return {"opened_file": path, "method": "os.startfile"}
        except Exception:
            subprocess.Popen(["explorer", path], start_new_session=True)
            return {"opened_file": path, "method": "explorer"}
    else:
        for opener in ["xdg-open","gio","mimeopen","exo-open"]:
            if shutil.which(opener):
                subprocess.Popen([opener, path], start_new_session=True)
                return {"opened_file": path, "method": opener}
        return {"error": "No file opener found. Install: sudo apt install xdg-utils"}


async def _launch_mac(candidates: list, extra: list) -> dict:
    for c in candidates:
        if not c: continue
        r = _run(["open","-a",c] + (["--args"] + extra if extra else []), timeout=12)
        if r.get("exit_code") == 0:
            return {"launched": c, "method": "open -a"}
        if shutil.which(c.lower()):
            subprocess.Popen([c.lower()] + extra, start_new_session=True)
            return {"launched": c, "method": "binary"}
    return {"error": f"Could not launch '{candidates[0]}' on macOS"}


async def _launch_win(candidates: list, extra: list) -> dict:
    for c in candidates:
        if not c: continue
        if shutil.which(c):
            subprocess.Popen([c] + extra, start_new_session=True)
            return {"launched": c, "method": "which"}
    app = candidates[0]
    subprocess.Popen(f'start "" "{app}"', shell=True, start_new_session=True)
    return {"launched": app, "method": "start"}


async def _launch_linux(candidates: list, original: str, extra: list) -> dict:
    # 1. Direct binary
    for c in candidates:
        if c and shutil.which(c):
            subprocess.Popen([c] + extra, start_new_session=True)
            return {"launched": c, "method": "binary"}

    # 2. .desktop file scan
    desktop_dirs = [
        Path("/usr/share/applications"), Path("/usr/local/share/applications"),
        HOME / ".local/share/applications",
        Path("/var/lib/flatpak/exports/share/applications"),
        HOME / ".local/share/flatpak/exports/share/applications",
    ]
    search = original.lower().replace(" ","")
    for ddir in desktop_dirs:
        if not ddir.exists(): continue
        for df in ddir.glob("*.desktop"):
            if search not in df.stem.lower() and search not in df.name.lower(): continue
            try:
                text = df.read_text(errors="replace")
                for line in text.splitlines():
                    if line.startswith("Exec="):
                        exec_str = re.sub(r"%[A-Za-z]","",line[5:]).strip()
                        parts = exec_str.split()
                        if parts and shutil.which(parts[0]):
                            subprocess.Popen(parts + extra, start_new_session=True)
                            return {"launched": original, "method": ".desktop", "binary": parts[0]}
            except Exception: pass

    # 3. snap
    if shutil.which("snap"):
        r = _run(["snap","run", original.lower()] + extra, timeout=10)
        if r.get("exit_code") == 0:
            return {"launched": original, "method": "snap"}

    # 4. flatpak
    if shutil.which("flatpak"):
        r = _run(["flatpak","run", original] + extra, timeout=10)
        if r.get("exit_code") == 0:
            return {"launched": original, "method": "flatpak"}

    # 5. xdg-open (for file opening)
    if shutil.which("xdg-open") and extra:
        subprocess.Popen(["xdg-open"] + extra, start_new_session=True)
        return {"launched": original, "method": "xdg-open"}

    return {"error":
        f"'{original}' not found on this system.\n"
        f"Check spelling or install it first."}


@_shield
async def tool_open_url(url: str = "", **_) -> dict:
    url = _safe_str(url)
    if not url: return {"error": "No URL provided"}
    if not re.match(r"^https?://", url, re.I): url = f"https://{url}"
    loop = asyncio.get_event_loop()
    # Try OS-specific first, then Python webbrowser
    if SYS == "Darwin":
        r = await _arun(_run, ["open", url], 10)
        if r.get("exit_code") == 0: return {"opened": url, "method": "open"}
    elif SYS == "Windows":
        r = await _arun(_run, ["start", "", url], 10, True)
        if r.get("exit_code") == 0: return {"opened": url, "method": "start"}
    else:
        for opener in ["xdg-open","gio","x-www-browser","sensible-browser"]:
            if shutil.which(opener):
                subprocess.Popen([opener, url], start_new_session=True)
                return {"opened": url, "method": opener}
    # Python webbrowser fallback
    ok = await loop.run_in_executor(None, webbrowser.open, url)
    return {"opened": url, "method": "webbrowser"} if ok else {"error": f"Could not open {url}"}


# ═════════════════════════════════════════════════════════════════════════════
# INTERNET / WEATHER / PING
# ═════════════════════════════════════════════════════════════════════════════

@_shield
async def tool_weather(city: str = "", lat: float = 0.0, lon: float = 0.0, **_) -> dict:
    city = _safe_str(city)
    lat  = _safe_float(lat, 0.0)
    lon  = _safe_float(lon, 0.0)
    loop = asyncio.get_event_loop()

    def _fetch(url: str) -> dict:
        req = urllib.request.Request(url, headers={"User-Agent": "BySalim/2.0"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.loads(r.read())

    if city and not (lat and lon):
        geo_url = ("https://geocoding-api.open-meteo.com/v1/search?" +
                   urllib.parse.urlencode({"name": city, "count": 1, "language": "en", "format": "json"}))
        try:
            geo = await loop.run_in_executor(None, _fetch, geo_url)
        except Exception as e:
            return {"error": f"Geocoding failed: {e}"}
        results = geo.get("results")
        if not results:
            return {"error": f"City not found: '{city}'. Try a different spelling."}
        lat  = float(results[0]["latitude"])
        lon  = float(results[0]["longitude"])
        city = f"{results[0].get('name', city)}, {results[0].get('country_code','')}"

    if not (lat or lon):
        return {"error": "Provide city name or lat/lon coordinates"}

    wx_url = ("https://api.open-meteo.com/v1/forecast?" +
              urllib.parse.urlencode({
                  "latitude": round(lat, 4), "longitude": round(lon, 4),
                  "current": "temperature_2m,relative_humidity_2m,apparent_temperature,"
                             "precipitation,weather_code,wind_speed_10m,wind_direction_10m,"
                             "cloud_cover,uv_index,is_day",
                  "timezone": "auto", "forecast_days": 1,
              }))
    try:
        wx = await loop.run_in_executor(None, _fetch, wx_url)
    except Exception as e:
        return {"error": f"Weather API failed: {e}"}

    curr = wx.get("current", {})
    wmo = {
        0:"Clear sky ☀️", 1:"Mainly clear 🌤️", 2:"Partly cloudy ⛅", 3:"Overcast ☁️",
        45:"Foggy 🌫️", 48:"Rime fog 🌫️", 51:"Light drizzle 🌦️", 53:"Moderate drizzle 🌦️",
        55:"Dense drizzle 🌧️", 61:"Slight rain 🌧️", 63:"Moderate rain 🌧️", 65:"Heavy rain 🌧️",
        71:"Slight snow ❄️", 73:"Moderate snow ❄️", 75:"Heavy snow ❄️", 77:"Snow grains ❄️",
        80:"Slight showers 🌦️", 81:"Moderate showers 🌦️", 82:"Violent showers ⛈️",
        85:"Slight snow showers ❄️", 86:"Heavy snow showers ❄️",
        95:"Thunderstorm ⛈️", 96:"Thunderstorm+hail ⛈️", 99:"Thunderstorm+heavy hail ⛈️",
    }
    code = curr.get("weather_code", -1)
    return {
        "city":             city or f"{lat},{lon}",
        "temperature_c":    curr.get("temperature_2m"),
        "feels_like_c":     curr.get("apparent_temperature"),
        "humidity_percent": curr.get("relative_humidity_2m"),
        "conditions":       wmo.get(code, f"Code {code}"),
        "wind_speed_kmh":   curr.get("wind_speed_10m"),
        "wind_direction":   curr.get("wind_direction_10m"),
        "cloud_cover_pct":  curr.get("cloud_cover"),
        "precipitation_mm": curr.get("precipitation"),
        "uv_index":         curr.get("uv_index"),
        "is_day":           bool(curr.get("is_day", 1)),
        "timezone":         wx.get("timezone",""),
    }


@_shield
async def tool_ping(host: str = "8.8.8.8", count: int = 4, **_) -> dict:
    host = _safe_str(host, "8.8.8.8").strip()
    count = _safe_int(count, 4, 1, 20)
    if not host: return {"error": "No host provided"}
    flag = "-n" if SYS == "Windows" else "-c"
    cmd = ["ping", flag, str(count), host]
    r = await _arun(_run, cmd, count * 6 + 15)
    if "not found" in r.get("error",""):
        return {"error": "ping command not found on system"}
    out = r.get("stdout","") + r.get("stderr","")
    # Parse avg latency
    avg = None
    for pat in [
        r"rtt\s+\S+\s*=\s*[\d.]+/([\d.]+)",      # Linux
        r"round-trip\s+\S+\s*=\s*[\d.]+/([\d.]+)",# macOS
        r"Average\s*=\s*([\d.]+)\s*ms",            # Windows
        r"avg\s*=\s*[\d.]+/([\d.]+)",
    ]:
        m = re.search(pat, out, re.I)
        if m: avg = round(float(m.group(1)), 2); break
    # Parse packet loss
    loss_pct = None
    m2 = re.search(r"(\d+(?:\.\d+)?)\s*%\s*(?:packet\s+)?loss", out, re.I)
    if m2: loss_pct = float(m2.group(1))
    reachable = r.get("exit_code", 1) == 0
    return {
        "host":         host,
        "packets_sent": count,
        "reachable":    reachable,
        "avg_ms":       avg,
        "packet_loss_pct": loss_pct,
        "raw_output":   out[:500],
    }


@_shield
async def tool_internet_speed(**_) -> dict:
    loop = asyncio.get_event_loop()
    endpoints = [
        ("Cloudflare DNS", "https://1.1.1.1"),
        ("Google",         "https://www.google.com"),
        ("GitHub",         "https://github.com"),
        ("Cloudflare",     "https://cloudflare.com"),
    ]
    results: dict = {}
    async def _chk(name: str, url: str):
        t0 = time.monotonic()
        try:
            def _req():
                req = urllib.request.Request(url, method="HEAD",
                                             headers={"User-Agent":"BySalim/2.0"})
                with urllib.request.urlopen(req, timeout=8): pass
            await loop.run_in_executor(None, _req)
            results[name] = {"reachable": True, "latency_ms": round((time.monotonic()-t0)*1000, 1)}
        except Exception as e:
            results[name] = {"reachable": False, "error": str(e)[:80]}
    await asyncio.gather(*[_chk(n,u) for n,u in endpoints])
    reachable_count = sum(1 for v in results.values() if v.get("reachable"))
    return {
        "connected": reachable_count > 0,
        "reachable_count": reachable_count,
        "total_checked": len(endpoints),
        "endpoints": results,
    }


@_shield
async def tool_reminder(message: str = "", delay_seconds: int = 0,
                          delay_minutes: int = 0, delay_hours: int = 0, **_) -> dict:
    message = _safe_str(message)
    if not message: return {"error": "No message provided"}
    ds = _safe_int(delay_seconds, 0, 0)
    dm = _safe_int(delay_minutes, 0, 0)
    dh = _safe_int(delay_hours,   0, 0)
    total = ds + dm * 60 + dh * 3600
    if total <= 0: return {"error": "Provide a positive delay (seconds/minutes/hours)"}
    if total > 86400 * 7: return {"error": "Max delay is 7 days"}
    async def _fire():
        await asyncio.sleep(total)
        await _push(f"⏰ *Reminder:* {message}")
    asyncio.ensure_future(_fire())
    eta = datetime.datetime.now() + datetime.timedelta(seconds=total)
    h, r = divmod(total, 3600); m, s = divmod(r, 60)
    human = f"{h}h {m}m {s}s" if h else (f"{m}m {s}s" if m else f"{s}s")
    return {
        "reminder_set": message,
        "fires_at": eta.strftime("%H:%M:%S"),
        "fires_at_full": eta.strftime("%Y-%m-%d %H:%M:%S"),
        "delay": human,
        "total_seconds": total,
    }


@_shield
async def tool_datetime(**_) -> dict:
    now = datetime.datetime.now()
    utc = datetime.datetime.utcnow()
    return {
        "local":             now.isoformat(timespec="seconds"),
        "utc":               utc.isoformat(timespec="seconds") + "Z",
        "date":              now.strftime("%A, %B %d %Y"),
        "time":              now.strftime("%H:%M:%S"),
        "timestamp_unix":    int(time.time()),
        "timezone":          time.tzname[0],
        "utc_offset_hours":  round(-time.timezone / 3600, 1),
        "week_number":       now.isocalendar()[1],
        "day_of_week":       now.strftime("%A"),
        "day_of_year":       now.timetuple().tm_yday,
        "quarter":           (now.month - 1) // 3 + 1,
    }


# ═════════════════════════════════════════════════════════════════════════════
# DEV TOOLS
# ═════════════════════════════════════════════════════════════════════════════

@_shield
async def tool_python_info(**_) -> dict:
    r = await _arun(_run, [sys.executable,"-m","pip","list","--format=json"], 30)
    pkgs: list = []
    if r.get("exit_code") == 0 and r.get("stdout"):
        try: pkgs = json.loads(r["stdout"])
        except Exception: pass
    return {
        "python_version":    sys.version,
        "python_version_tuple": list(sys.version_info[:3]),
        "executable":        sys.executable,
        "platform":          sys.platform,
        "implementation":    platform.python_implementation(),
        "packages_installed": len(pkgs),
        "packages_sample":   [p["name"] for p in pkgs[:15]],
    }


@_shield
async def tool_env_vars(filter_key: str = "", **_) -> dict:
    filter_key = _safe_str(filter_key)
    SENS = {"key","secret","token","password","passwd","pwd","api","auth","cred","private"}
    safe: dict = {}
    for k, v in os.environ.items():
        if any(s in k.lower() for s in SENS):
            safe[k] = "***REDACTED***"
        else:
            safe[k] = v[:500]  # cap length
    if filter_key:
        safe = {k: v for k, v in safe.items() if filter_key.lower() in k.lower()}
    return {"env": safe, "count": len(safe)}


@_shield
async def tool_git_status(path: str = ".", **_) -> dict:
    path = _safe_str(path, ".")
    p, err = _check_path(path, must_exist=True)
    if err: return {"error": err}
    if not shutil.which("git"): return {"error": "git not installed"}
    r = await _arun(_run, ["git","status","--short","--branch"], 15, False, str(p))
    if r.get("exit_code") == 0:
        return {"path": str(p), "status": r.get("stdout","") or "(clean)"}
    stderr = r.get("stderr","")
    if "not a git repo" in stderr.lower() or "fatal" in stderr.lower():
        return {"error": f"Not a git repository: {p}"}
    return {"error": stderr or "git status failed"}


@_shield
async def tool_git_log(path: str = ".", count: int = 10, **_) -> dict:
    path = _safe_str(path, ".")
    count = _safe_int(count, 10, 1, 100)
    p, err = _check_path(path, must_exist=True)
    if err: return {"error": err}
    if not shutil.which("git"): return {"error": "git not installed"}
    r = await _arun(_run,
        ["git","log",f"--max-count={count}","--no-color","--pretty=format:%h\t%s\t%cr\t%an"],
        20, False, str(p))
    if r.get("exit_code") != 0:
        return {"error": r.get("stderr","git log failed")}
    commits = []
    for line in r.get("stdout","").splitlines():
        parts = line.split("\t", 3)
        if len(parts) >= 2:
            commits.append({
                "hash":    parts[0],
                "message": parts[1],
                "when":    parts[2] if len(parts) > 2 else "",
                "author":  parts[3] if len(parts) > 3 else "",
            })
    return {"commits": commits, "count": len(commits), "path": str(p)}


@_shield
async def tool_pip_install(package: str = "", **_) -> dict:
    package = _safe_str(package)
    if not package: return {"error": "No package name provided"}
    # Safety: only allow simple package names
    if not re.match(r"^[a-zA-Z0-9_\-\.\[\]>=<!=~]+$", package):
        return {"error": f"Invalid package name: '{package}'"}
    r = await _arun(_run,
        [sys.executable,"-m","pip","install","--break-system-packages", package], 180)
    if r.get("exit_code") == 0:
        return {"installed": package, "stdout": r.get("stdout","")[:500]}
    return {"error": f"pip install {package} failed", "stderr": r.get("stderr","")[:500]}


@_shield
async def tool_pip_list(**_) -> dict:
    r = await _arun(_run, [sys.executable,"-m","pip","list","--format=json"], 30)
    if r.get("exit_code") != 0:
        return {"error": "pip list failed", "stderr": r.get("stderr","")}
    try:
        pkgs = json.loads(r["stdout"])
        return {"packages": pkgs, "count": len(pkgs)}
    except Exception:
        # Fallback: return raw
        return {"packages_raw": r.get("stdout",""), "count": -1}


@_shield
async def tool_calculate(expression: str = "", **_) -> dict:
    expression = _safe_str(expression)
    if not expression: return {"error": "No expression provided"}
    clean = expression.strip().replace("^","**")
    # Whitelist: only safe characters and function names
    allowed = re.sub(
        r"[\d\s\+\-\*\/\(\)\.\%_]"
        r"|sqrt|floor|ceil|log10|log2|log|sin|cos|tan|asin|acos|atan|atan2"
        r"|pi|abs|round|min|max|pow|sum|inf|e\b|tau|hypot|degrees|radians|factorial",
        "", clean)
    if allowed.strip():
        return {"error": f"Expression contains unsafe content: '{allowed.strip()[:20]}'"}
    import math as _m
    ns: dict = {
        "__builtins__": {},
        "abs":abs,"round":round,"min":min,"max":max,"pow":pow,"sum":sum,"len":len,
        "sqrt":_m.sqrt,"floor":_m.floor,"ceil":_m.ceil,
        "log":_m.log,"log10":_m.log10,"log2":_m.log2,
        "sin":_m.sin,"cos":_m.cos,"tan":_m.tan,
        "asin":_m.asin,"acos":_m.acos,"atan":_m.atan,"atan2":_m.atan2,
        "hypot":_m.hypot,"degrees":_m.degrees,"radians":_m.radians,
        "factorial":_m.factorial,
        "pi":_m.pi,"e":_m.e,"tau":_m.tau,"inf":_m.inf,
    }
    try:
        result = eval(compile(clean, "<expr>", "eval"), ns)
        if isinstance(result, float):
            if result != result: return {"error": "Result is NaN"}
            if result == float("inf"): return {"error": "Result is infinity"}
            if abs(result) > 1e15 or result == int(result):
                pass
            else:
                result = round(result, 10)
        if isinstance(result, float) and result == int(result) and abs(result) < 1e15:
            result = int(result)
        return {"expression": expression, "result": result}
    except ZeroDivisionError:
        return {"error": "Division by zero"}
    except OverflowError:
        return {"error": "Result too large to compute"}
    except Exception as e:
        return {"error": f"Cannot evaluate: {e}"}


@_shield
async def tool_word_count(text: str = "", path: str = "", **_) -> dict:
    text = _safe_str(text)
    path_s = _safe_str(path)
    if path_s:
        p, err = _check_path(path_s, must_exist=True, must_be_file=True)
        if err: return {"error": err}
        try: text = p.read_text(encoding="utf-8", errors="replace")
        except Exception as e: return {"error": f"read failed: {e}"}
    if not text: return {"error": "Provide text or path"}
    words = text.split()
    lines = text.splitlines()
    sentences = len([s for s in re.split(r"[.!?]+", text) if s.strip()])
    paragraphs = len([pp for pp in re.split(r"\n\s*\n", text) if pp.strip()])
    unique_words = len(set(w.lower().strip(".,!?;:\"'") for w in words))
    return {
        "characters":              len(text),
        "characters_no_spaces":    len(re.sub(r"\s","",text)),
        "words":                   len(words),
        "unique_words":            unique_words,
        "lines":                   len(lines),
        "non_empty_lines":         len([l for l in lines if l.strip()]),
        "sentences":               sentences,
        "paragraphs":              paragraphs,
        "avg_words_per_sentence":  round(len(words) / max(sentences, 1), 1),
    }


@_shield
async def tool_clarify(message: str = "", **_) -> dict:
    message = _safe_str(message)
    return {"clarify": message or "Could you be more specific? I'm not sure what you want."}


# ═════════════════════════════════════════════════════════════════════════════
# TOOL REGISTRY & DISPATCHER
# ═════════════════════════════════════════════════════════════════════════════

TOOLS: dict[str, dict] = {
    # System
    "system_health":    {"fn": tool_system_health,    "description": "CPU, RAM, disk, swap, temps, top processes",             "danger": False},
    "uptime":           {"fn": tool_uptime,            "description": "System uptime and boot time",                            "danger": False},
    "battery":          {"fn": tool_battery,           "description": "Battery percent, charging status, time remaining",       "danger": False},
    "network_stats":    {"fn": tool_network_stats,     "description": "Network I/O, per-interface stats, active connections",   "danger": False},
    "list_processes":   {"fn": tool_list_processes,    "description": "Running processes sorted by CPU or memory",             "danger": False},
    "kill_process":     {"fn": tool_kill_process,      "description": "Kill process by PID or name",                           "danger": True},
    "run_shell":        {"fn": tool_run_shell,         "description": "Execute shell/terminal command",                         "danger": True},
    # Files
    "list_directory":   {"fn": tool_list_directory,    "description": "List directory contents with types and sizes",          "danger": False},
    "read_file":        {"fn": tool_read_file,         "description": "Read text file (up to 5 MB)",                           "danger": False},
    "write_file":       {"fn": tool_write_file,        "description": "Write or append to a file",                             "danger": True},
    "delete_file":      {"fn": tool_delete_file,       "description": "Delete file or directory (trash by default)",            "danger": True},
    "copy_file":        {"fn": tool_copy_file,         "description": "Copy file or directory",                                "danger": False},
    "move_file":        {"fn": tool_move_file,         "description": "Move file or directory",                                "danger": True},
    "rename_file":      {"fn": tool_rename_file,       "description": "Rename file or folder in-place",                        "danger": False},
    "search_files":     {"fn": tool_search_files,      "description": "Search files by name or extension",                     "danger": False},
    "create_directory": {"fn": tool_create_directory,  "description": "Create directory (with parents)",                       "danger": False},
    "disk_usage":       {"fn": tool_disk_usage,        "description": "Disk space for path and all mounted partitions",        "danger": False},
    "send_file":        {"fn": tool_send_file,         "description": "Send any file to Telegram",                             "danger": False},
    # Screen/Input
    "screenshot":       {"fn": tool_screenshot,        "description": "Take a screenshot",                                     "danger": False},
    "get_volume":       {"fn": tool_get_volume,        "description": "Get system audio volume (0–100)",                       "danger": False},
    "set_volume":       {"fn": tool_set_volume,        "description": "Set system audio volume (0–100)",                       "danger": False},
    "mute_volume":      {"fn": tool_mute_volume,       "description": "Mute system audio",                                     "danger": False},
    "get_clipboard":    {"fn": tool_get_clipboard,     "description": "Read clipboard text",                                   "danger": False},
    "set_clipboard":    {"fn": tool_set_clipboard,     "description": "Copy text to clipboard",                                "danger": False},
    # Images
    "image_info":       {"fn": tool_image_info,        "description": "Image metadata: size, format, EXIF, color stats",       "danger": False},
    "image_resize":     {"fn": tool_image_resize,      "description": "Resize image (width, height, aspect ratio)",            "danger": False},
    "image_rotate":     {"fn": tool_image_rotate,      "description": "Rotate image by angle degrees",                         "danger": False},
    "image_crop":       {"fn": tool_image_crop,        "description": "Crop image to pixel box (left, top, right, bottom)",    "danger": False},
    "image_convert":    {"fn": tool_image_convert,     "description": "Convert image format: jpg/png/webp/bmp/gif/tiff",       "danger": False},
    # Audio
    "audio_info":       {"fn": tool_audio_info,        "description": "Audio metadata: duration, bitrate, tags (title/artist/album)", "danger": False},
    "audio_convert":    {"fn": tool_audio_convert,     "description": "Convert audio: mp3/flac/wav/ogg/m4a via ffmpeg",        "danger": False},
    "audio_trim":       {"fn": tool_audio_trim,        "description": "Trim audio clip: start_sec + duration_sec",             "danger": False},
    # Video
    "video_info":       {"fn": tool_video_info,        "description": "Video metadata: duration, resolution, codec, fps",      "danger": False},
    "video_thumbnail":  {"fn": tool_video_thumbnail,   "description": "Extract video frame as image at timestamp",             "danger": False},
    "video_convert":    {"fn": tool_video_convert,     "description": "Convert video format: mp4/mkv/webm/avi/gif via ffmpeg", "danger": False},
    "video_trim":       {"fn": tool_video_trim,        "description": "Trim video clip: start_sec + duration_sec",             "danger": False},
    # Apps/Web
    "open_url":         {"fn": tool_open_url,          "description": "Open URL in default browser",                           "danger": False},
    "open_application": {"fn": tool_open_application,  "description": "Launch app by name or open file with default app",      "danger": False},
    # Network
    "weather":          {"fn": tool_weather,           "description": "Current weather for city or coordinates",               "danger": False},
    "ping":             {"fn": tool_ping,              "description": "Ping host, measure latency and packet loss",             "danger": False},
    "internet_speed":   {"fn": tool_internet_speed,    "description": "Check internet connectivity to multiple endpoints",     "danger": False},
    # Time/Reminders
    "datetime":         {"fn": tool_datetime,          "description": "Current date, time, timezone, week number",             "danger": False},
    "reminder":         {"fn": tool_reminder,          "description": "Set timed reminder (fires via Telegram)",               "danger": False},
    # Dev
    "python_info":      {"fn": tool_python_info,       "description": "Python version, packages list",                         "danger": False},
    "env_vars":         {"fn": tool_env_vars,          "description": "Environment variables (sensitive values redacted)",      "danger": False},
    "git_status":       {"fn": tool_git_status,        "description": "Git status for a repository path",                      "danger": False},
    "git_log":          {"fn": tool_git_log,           "description": "Recent git commits (hash, message, author, when)",      "danger": False},
    "pip_install":      {"fn": tool_pip_install,       "description": "Install Python package via pip",                        "danger": True},
    "pip_list":         {"fn": tool_pip_list,          "description": "List all installed Python packages",                    "danger": False},
    # Utility
    "calculate":        {"fn": tool_calculate,         "description": "Evaluate math expression (safe sandbox)",               "danger": False},
    "word_count":       {"fn": tool_word_count,        "description": "Count words, lines, sentences in text or file",         "danger": False},
    "clarify":          {"fn": tool_clarify,           "description": "Ask the user for clarification",                        "danger": False},
}


async def run_tool(name: str, args: Any) -> dict:
    """Dispatch to a tool. Never raises. Guarantees a dict with 'error' or useful data."""
    if not isinstance(args, dict):
        args = {}
    # Coerce all arg values through safe_ helpers where possible
    entry = TOOLS.get(_safe_str(name))
    if entry is None:
        close = [t for t in TOOLS if _safe_str(name).lower() in t]
        hint = f" Did you mean: {', '.join(close[:3])}?" if close else ""
        return {"error": f"Unknown tool '{name}'.{hint} Available: {', '.join(sorted(TOOLS))}"}
    t0 = time.monotonic()
    try:
        result = await asyncio.wait_for(entry["fn"](**args), timeout=TOOL_TIMEOUT + 30)
    except asyncio.TimeoutError:
        result = {"error": f"Tool '{name}' timed out after {TOOL_TIMEOUT + 30}s"}
    except BaseException as e:
        log.exception("run_tool '%s' crashed", name)
        result = {"error": f"Tool '{name}' crashed: {type(e).__name__}: {e}"}
    ms = (time.monotonic() - t0) * 1000
    log_task(name, args if isinstance(args, dict) else {}, result, ms)
    return result


def tool_list_for_prompt() -> str:
    return "\n".join(
        f"  {name}: {e['description']}" + (" ⚠️ DANGEROUS — requires confirm=true" if e["danger"] else "")
        for name, e in TOOLS.items()
    )
