"""
BySalim — AI agent that controls your computer via Telegram.

Quick start:
    bysalim init    # one-time setup wizard
    bysalim run     # start the agent
    bysalim stop    # stop it
    bysalim status  # check status
    bysalim doctor  # diagnose issues
"""
__version__ = "2.0.2"
__all__ = ["__version__"]
