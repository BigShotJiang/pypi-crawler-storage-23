from dagster._cli import main

main()
