set -e

if [ -z "$__DEVBOX_SKIP_INIT_HOOK_5d8c75d77b939a68451aa29ba1bc78c88ff4b38868ca7d11a7641bfbd5a0a183" ]; then
    . "/home/runner/work/yaml-to-markdown/yaml-to-markdown/.devbox/gen/scripts/.hooks.sh"
fi

scripts/install.sh
