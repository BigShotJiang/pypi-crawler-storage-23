{
   description = "A devbox shell";

   inputs = {
     nixpkgs.url = "github:NixOS/nixpkgs/d7f52a7a640bc54c7bb414cca603835bf8dd4b10?narHash=sha256-krgZxGAIIIKFJS%2BUB0l8do3sYUDWJc75M72tepmVMzE%3D";
     glibc-patch.url = "path:glibc-patch";
   };

   outputs = {
     self,
     nixpkgs,
     glibc-patch,
   }:
      let
        pkgs = nixpkgs.legacyPackages.x86_64-linux;
      in
      {
        devShells.x86_64-linux.default = pkgs.mkShell {
          buildInputs = [
            
            (builtins.trace "downloading uv@latest" (builtins.fetchClosure {
              
              fromStore = "https://cache.nixos.org";
              fromPath = "/nix/store/ksi4jmfapiqnk1lclzlf2hrdj6s1rzjs-uv-0.10.2";
              inputAddressed = true;
            }))
            (builtins.trace "evaluating glibc-patch.packages.x86_64-linux.python314" glibc-patch.packages.x86_64-linux.python314)
          ];
        };
      };
 }
