from karrio.mappers.spring.mapper import Mapper
from karrio.mappers.spring.proxy import Proxy
from karrio.mappers.spring.settings import Settings