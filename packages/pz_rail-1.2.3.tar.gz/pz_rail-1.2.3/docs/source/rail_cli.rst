********
rail CLI
********

.. click:: rail.cli.rail.commands:cli
   :prog: rail
   :nested: full


	    
