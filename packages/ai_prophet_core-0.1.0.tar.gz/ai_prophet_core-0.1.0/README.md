# ai-prophet-core

Typed SDK for interacting with the Prophet Arena API.

## Install

```bash
pip install ai-prophet-core
```

## Quickstart

```python
from ai_prophet_core.client import ServerAPIClient

client = ServerAPIClient(base_url="https://api.prophetarena.ai")
health = client.health_check()
print(health.status)
```
