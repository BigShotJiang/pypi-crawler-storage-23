"""
SalimBot — Main bot class that assembles all handler modules.
Now includes AI natural language handler via NVIDIA NIM.
"""

from __future__ import annotations

import asyncio
import logging
import platform
from datetime import datetime
from pathlib import Path

from telegram import (
    BotCommand, InlineKeyboardButton, InlineKeyboardMarkup, Update
)
from telegram.ext import (
    Application, ApplicationBuilder, CallbackQueryHandler,
    CommandHandler, ContextTypes, MessageHandler, filters
)

from salim.auth import AuthMiddleware, require_auth
from salim.config import Config
from salim.handlers.system import SystemHandlers
from salim.handlers.shell  import ShellHandlers
from salim.handlers.files  import FileHandlers
from salim.handlers.screen import ScreenHandlers
from salim.handlers.power  import PowerHandlers
from salim.handlers.ai_handler import AIHandler          # ← NEW
from salim.handlers.document_writer import DocumentHandlers
from salim.handlers.voice       import VoiceHandlers
from salim.handlers.camera      import CameraHandlers
from salim.handlers.alerts      import AlertHandlers, start_monitor
from salim.handlers.history     import ConversationHistoryHandlers
from salim.handlers.code_runner import CodeRunnerHandlers
from salim.handlers.guard       import IntrusionHandlers
from salim.handlers.smart_upload import SmartUploadHandlers
from salim.handlers.clipboard_image import ClipboardImageHandlers   # Feature 2: clipboard images
from salim.handlers.stream import ScreenStreamHandlers               # Feature 3: live stream
from salim.handlers.browser import BrowserHandlers                   # Feature 5: browser automation
from salim.handlers.tts import TTSHandlers                           # Feature 8: text-to-speech
from salim.handlers.ssh_handler import SSHHandlers                   # Feature 9: SSH remote control
from salim.handlers.vision import VisionHandlers                     # Feature 11: vision AI
# ── v10: New features ────────────────────────────────────────────────────────
from salim.handlers.speedtest_handler import SpeedTestHandlers       # v10: /speedtest
from salim.handlers.qr_handler        import QRHandlers              # v10: /qr /qrread
from salim.handlers.watcher_handler   import WatcherHandlers         # v10: /watch /watchlist /watchstop
from salim.handlers.notes_handler     import NotesHandlers           # v10: /note /notes /notedel
from salim.handlers.scheduler_handler import SchedulerHandlers       # v10: /at /every /jobs /jobcancel
# ── v11: OpenClaw-style features ─────────────────────────────────────────────
from salim.handlers.memory     import MemoryHandlers, update_last_seen, build_memory_context, learn_from_text  # v11: persistent memory
from salim.handlers.heartbeat  import HeartbeatHandlers, get_heartbeat                                          # v11: proactive agent
from salim.handlers.agent      import AgentHandlers                                                              # v11: autonomous multi-step agent
from salim.handlers.skills     import SkillsHandlers, get_skill_loader                                          # v11: plugin/skills system
# ── v12: New capability modules ───────────────────────────────────────────────
from salim.handlers.weather        import WeatherHandlers                                # v12: real-time weather
from salim.handlers.calendar_handler import CalendarHandlers                             # v12: Google Calendar
from salim.handlers.web_handler    import WebHandlers                                    # v12: web fetch/search/YT
from salim.handlers.git_handler    import GitHandlers                                    # v12: git/GitHub control
from salim.handlers.digest_handler import DigestHandlers                                 # v12: morning briefing
from salim.handlers.translate_handler import TranslateHandlers                           # v12: translation
from salim.handlers.sysmon_handler import SysMonHandlers                                 # v12: network/port scanner
from salim.handlers.reminder_handler import ReminderHandlers                             # v12: natural language reminders
from salim.handlers.crypto_finance import FinanceHandlers                                # v12: stocks/crypto/forex
from salim.handlers.backup_handler import BackupHandlers                                 # v12: encrypted backups
from salim.handlers.transcript_handler import TranscriptHandlers                         # v12: JSONL session transcripts
from salim.handlers.agent_advanced  import AdvancedAgentHandlers, update_rapport_after_message, build_personality_context
from salim.handlers.onboarding     import OnboardingHandlers, is_onboarded, load_prefs  # v13: first-run setup                             # v12: autonomous problem-solving + EQ
import html
from salim.utils import short_time

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

logger = logging.getLogger("salim.bot")


class SalimBot(
    SystemHandlers, ShellHandlers, FileHandlers,
    ScreenHandlers, PowerHandlers,
    AIHandler,
    DocumentHandlers,
    VoiceHandlers,
    CameraHandlers,
    AlertHandlers,
    ConversationHistoryHandlers,
    CodeRunnerHandlers,
    IntrusionHandlers,
    SmartUploadHandlers,
    ClipboardImageHandlers,    # v9: clipboard image support
    ScreenStreamHandlers,      # v9: live screen stream
    BrowserHandlers,           # v9: browser automation
    TTSHandlers,               # v9: text-to-speech
    SSHHandlers,               # v9: SSH remote control
    VisionHandlers,            # v9: vision AI
    SpeedTestHandlers,         # v10: internet speed test
    QRHandlers,                # v10: QR code generate + read
    WatcherHandlers,           # v10: file system watcher
    NotesHandlers,             # v10: quick notes scratchpad
    SchedulerHandlers,         # v10: task scheduler
    MemoryHandlers,            # v11: persistent user memory
    HeartbeatHandlers,         # v11: proactive autonomous agent
    AgentHandlers,             # v11: multi-step autonomous task execution
    SkillsHandlers,            # v11: dynamic plugin/skills system
    WeatherHandlers,           # v12: real-time weather (Open-Meteo, free)
    CalendarHandlers,          # v12: Google Calendar + local calendar
    WebHandlers,               # v12: web fetch / DuckDuckGo search / YouTube
    GitHandlers,               # v12: git & GitHub control
    DigestHandlers,            # v12: daily morning briefing
    TranslateHandlers,         # v12: LibreTranslate + AI fallback
    SysMonHandlers,            # v12: network scanner, ports, ping, DNS
    ReminderHandlers,          # v12: natural-language reminders
    FinanceHandlers,           # v12: stocks, crypto, forex (free APIs)
    BackupHandlers,            # v12: rsync/tar backups
    TranscriptHandlers,        # v12: JSONL session audit log
    AdvancedAgentHandlers,     # v12: autonomous reasoning + EQ + goals + hypotheses
    OnboardingHandlers,         # v13: first-run setup wizard + image save dir
):
    """
    Main Salim bot — composes all handler mixins into one class.
    AIHandler adds natural language understanding via NVIDIA NIM.
    """

    def __init__(self, config: Config):
        self.config = config
        self.auth   = AuthMiddleware(config)
        self._cwd   = str(Path.home())
        # v9: override /paste with smart version (handles images + text)
        self.cmd_paste = self.cmd_paste_smart

    # ── Build telegram Application ───────────────────────────────────────────
    def build(self) -> Application:
        app = (
            ApplicationBuilder()
            .token(self.config.bot_token)
            .build()
        )
        self._register_handlers(app)
        return app

    def _register_handlers(self, app: Application):
        # ── Start / Help ──────────────────────────────────────────────────────
        app.add_handler(CommandHandler("start",      self.cmd_start))
        app.add_handler(CommandHandler("help",       self.cmd_help))
        app.add_handler(CommandHandler("status",     self.cmd_status))
        app.add_handler(CommandHandler("config",     self.cmd_config))
        app.add_handler(CommandHandler("logs",       self.cmd_logs))

        # ── System ───────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("info",       self.cmd_info))
        app.add_handler(CommandHandler("cpu",        self.cmd_cpu))
        app.add_handler(CommandHandler("mem",        self.cmd_mem))
        app.add_handler(CommandHandler("disk",       self.cmd_disk))
        app.add_handler(CommandHandler("battery",    self.cmd_battery))
        app.add_handler(CommandHandler("network",    self.cmd_network))
        app.add_handler(CommandHandler("uptime",     self.cmd_uptime))
        app.add_handler(CommandHandler("ps",         self.cmd_ps))
        app.add_handler(CommandHandler("top",        self.cmd_top))
        app.add_handler(CommandHandler("kill",       self.cmd_kill))

        # ── Shell ─────────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("run",        self.cmd_run))
        app.add_handler(CommandHandler("sh",         self.cmd_run))
        app.add_handler(CommandHandler("exec",       self.cmd_run))
        app.add_handler(CommandHandler("runbg",      self.cmd_runbg))
        app.add_handler(CommandHandler("pipe",       self.cmd_pipe))
        app.add_handler(CommandHandler("env",        self.cmd_env))
        app.add_handler(CommandHandler("which",      self.cmd_which))
        app.add_handler(CommandHandler("cron",       self.cmd_cron))
        app.add_handler(CommandHandler("cronstop",   self.cmd_cronstop))
        app.add_handler(CommandHandler("cronjobs",   self.cmd_cronjobs))

        # ── Files ─────────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("ls",         self.cmd_ls))
        app.add_handler(CommandHandler("cd",         self.cmd_cd))
        app.add_handler(CommandHandler("pwd",        self.cmd_pwd))
        app.add_handler(CommandHandler("cat",        self.cmd_cat))
        app.add_handler(CommandHandler("stat",       self.cmd_stat))
        app.add_handler(CommandHandler("find",       self.cmd_find))
        app.add_handler(CommandHandler("grep",       self.cmd_grep))
        app.add_handler(CommandHandler("mkdir",      self.cmd_mkdir))
        app.add_handler(CommandHandler("rm",         self.cmd_rm))
        app.add_handler(CommandHandler("mv",         self.cmd_mv))
        app.add_handler(CommandHandler("cp",         self.cmd_cp))
        app.add_handler(CommandHandler("download",   self.cmd_download))
        app.add_handler(CommandHandler("upload",     self.cmd_upload_prompt))
        app.add_handler(CommandHandler("zip",        self.cmd_zip))
        app.add_handler(CommandHandler("unzip",      self.cmd_unzip))
        app.add_handler(CommandHandler("write",      self.cmd_write))

        # ── Screen ────────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("screenshot", self.cmd_screenshot))
        app.add_handler(CommandHandler("ss",         self.cmd_screenshot))
        app.add_handler(CommandHandler("type",       self.cmd_type))
        app.add_handler(CommandHandler("key",        self.cmd_key))
        app.add_handler(CommandHandler("click",      self.cmd_click))
        app.add_handler(CommandHandler("scroll",     self.cmd_scroll))
        app.add_handler(CommandHandler("move",       self.cmd_move))
        app.add_handler(CommandHandler("mousepos",   self.cmd_mousepos))
        app.add_handler(CommandHandler("notify",     self.cmd_notify))
        app.add_handler(CommandHandler("volume",     self.cmd_volume))
        app.add_handler(CommandHandler("brightness", self.cmd_brightness))
        app.add_handler(CommandHandler("copy",       self.cmd_copy))
        app.add_handler(CommandHandler("paste",      self.cmd_paste))
        app.add_handler(CommandHandler("open",       self.cmd_open))

        # ── Document Writer ───────────────────────────────────────────────────────
        app.add_handler(CommandHandler("doc",        self.cmd_doc))

        # ── Camera & Recording ───────────────────────────────────────────────────
        app.add_handler(CommandHandler("cam",        self.cmd_cam))
        app.add_handler(CommandHandler("record",     self.cmd_record))

        # ── Alerts ───────────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("alert",      self.cmd_alert))

        # ── Conversation History ──────────────────────────────────────────────────
        app.add_handler(CommandHandler("history",    self.cmd_history))

        # ── AI Code Runner ────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("code",       self.cmd_code))

        # ── Intrusion Guard ───────────────────────────────────────────────────────
        app.add_handler(CommandHandler("guard",      self.cmd_guard))

        # ── Smart Upload ──────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("uploads",    self.cmd_uploads_history))

        # ── Voice status ──────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("voicestatus", self.cmd_voice_status))

        # ── v9: Clipboard Image ────────────────────────────────────────────────────
        app.add_handler(CommandHandler("copyphoto",  self.cmd_copyphoto))

        # ── v9: Live Screen Stream ─────────────────────────────────────────────────
        app.add_handler(CommandHandler("stream",      self.cmd_stream))
        app.add_handler(CommandHandler("streamstop",  self.cmd_streamstop))

        # ── v9: Browser Automation ─────────────────────────────────────────────────
        app.add_handler(CommandHandler("browse",          self.cmd_browse))
        app.add_handler(CommandHandler("browse_click",    self.cmd_browse_click))
        app.add_handler(CommandHandler("browse_type",     self.cmd_browse_type))
        app.add_handler(CommandHandler("browse_scroll",   self.cmd_browse_scroll))
        app.add_handler(CommandHandler("browse_js",       self.cmd_browse_js))
        app.add_handler(CommandHandler("browse_back",     self.cmd_browse_back))
        app.add_handler(CommandHandler("browse_get",      self.cmd_browse_get))
        app.add_handler(CommandHandler("browse_close",    self.cmd_browse_close))

        # ── v9: Text-to-Speech ─────────────────────────────────────────────────────
        app.add_handler(CommandHandler("tts",         self.cmd_tts))
        app.add_handler(CommandHandler("say",         self.cmd_say))
        app.add_handler(CommandHandler("tts_lang",    self.cmd_tts_lang))
        app.add_handler(CommandHandler("tts_speed",   self.cmd_tts_speed))
        app.add_handler(CommandHandler("tts_engine",  self.cmd_tts_engine))
        app.add_handler(CommandHandler("tts_voice",   self.cmd_tts_voice))

        # ── v9: SSH Remote Control ─────────────────────────────────────────────────
        app.add_handler(CommandHandler("ssh_add",      self.cmd_ssh_add))
        app.add_handler(CommandHandler("ssh_list",     self.cmd_ssh_list))
        app.add_handler(CommandHandler("ssh",          self.cmd_ssh))
        app.add_handler(CommandHandler("ssh_remove",   self.cmd_ssh_remove))
        app.add_handler(CommandHandler("ssh_password", self.cmd_ssh_password))
        app.add_handler(CommandHandler("ssh_upload",   self.cmd_ssh_upload))
        app.add_handler(CommandHandler("ssh_download", self.cmd_ssh_download))
        app.add_handler(CommandHandler("ssh_connect",  self.cmd_ssh_connect))
        app.add_handler(CommandHandler("ssh_disconnect", self.cmd_ssh_disconnect))

        # ── v9: Vision AI ──────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("vision",       self.cmd_vision))
        app.add_handler(CommandHandler("askvision",    self.cmd_askvision))

        # ── v10: Speed Test ────────────────────────────────────────────────────
        app.add_handler(CommandHandler("speedtest",    self.cmd_speedtest))

        # ── v10: QR Code ───────────────────────────────────────────────────────
        app.add_handler(CommandHandler("qr",           self.cmd_qr))
        app.add_handler(CommandHandler("qrread",       self.cmd_qrread))

        # ── v10: File Watcher ──────────────────────────────────────────────────
        app.add_handler(CommandHandler("watch",        self.cmd_watch))
        app.add_handler(CommandHandler("watchlist",    self.cmd_watchlist))
        app.add_handler(CommandHandler("watchstop",    self.cmd_watchstop))

        # ── v10: Notes Scratchpad ─────────────────────────────────────────────
        app.add_handler(CommandHandler("note",         self.cmd_note))
        app.add_handler(CommandHandler("notes",        self.cmd_notes))
        app.add_handler(CommandHandler("notedel",      self.cmd_notedel))
        app.add_handler(CommandHandler("noteclear",    self.cmd_noteclear))

        # ── v10: Task Scheduler ───────────────────────────────────────────────
        app.add_handler(CommandHandler("at",           self.cmd_at))
        app.add_handler(CommandHandler("every",        self.cmd_every))
        app.add_handler(CommandHandler("jobs",         self.cmd_jobs))
        app.add_handler(CommandHandler("jobcancel",    self.cmd_jobcancel))

        # ── v11: Persistent Memory ────────────────────────────────────────────
        app.add_handler(CommandHandler("memory",       self.cmd_memory))

        # ── v11: Heartbeat / Proactive Agent ─────────────────────────────────
        app.add_handler(CommandHandler("heartbeat",    self.cmd_heartbeat))

        # ── v11: Autonomous Multi-Step Agent ─────────────────────────────────
        app.add_handler(CommandHandler("agent",        self.cmd_agent))
        app.add_handler(CommandHandler("agenthelp",    self.cmd_agenthelp))
        app.add_handler(CommandHandler("agentstop",    self.cmd_agentstop))
        app.add_handler(CommandHandler("agentstatus",  self.cmd_agentstatus))
        app.add_handler(CommandHandler("agentlog",     self.cmd_agentlog))

        # ── v11: Skills / Plugin System ───────────────────────────────────────
        app.add_handler(CommandHandler("skills",       self.cmd_skills))
        app.add_handler(CommandHandler("skilladd",     self.cmd_skilladd))

        # ── v12: Weather ──────────────────────────────────────────────────────
        app.add_handler(CommandHandler("weather",      self.cmd_weather))

        # ── v12: Calendar ─────────────────────────────────────────────────────
        app.add_handler(CommandHandler("cal",          self.cmd_cal))

        # ── v12: Web / Search / YouTube ───────────────────────────────────────
        app.add_handler(CommandHandler("web",          self.cmd_web))
        app.add_handler(CommandHandler("webread",      self.cmd_webread))
        app.add_handler(CommandHandler("websearch",    self.cmd_websearch))
        app.add_handler(CommandHandler("webnews",      self.cmd_webnews))
        app.add_handler(CommandHandler("yt",           self.cmd_yt))

        # ── v12: Git ──────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("git",          self.cmd_git))

        # ── v12: Daily Digest ─────────────────────────────────────────────────
        app.add_handler(CommandHandler("digest",       self.cmd_digest))

        # ── v12: Translation ──────────────────────────────────────────────────
        app.add_handler(CommandHandler("translate",    self.cmd_translate))
        app.add_handler(CommandHandler("tl",           self.cmd_tl))

        # ── v12: Network / SysMon ─────────────────────────────────────────────
        app.add_handler(CommandHandler("ports",        self.cmd_ports))
        app.add_handler(CommandHandler("portscan",     self.cmd_portscan))
        app.add_handler(CommandHandler("netdevices",   self.cmd_netdevices))
        app.add_handler(CommandHandler("myip",         self.cmd_myip))
        app.add_handler(CommandHandler("ping",         self.cmd_ping))
        app.add_handler(CommandHandler("dns",          self.cmd_dns))
        app.add_handler(CommandHandler("traceroute",   self.cmd_traceroute))
        app.add_handler(CommandHandler("whois",        self.cmd_whois))

        # ── v12: Reminders ────────────────────────────────────────────────────
        app.add_handler(CommandHandler("remind",       self.cmd_remind))
        app.add_handler(CommandHandler("reminders",    self.cmd_reminders))
        app.add_handler(CommandHandler("remdel",       self.cmd_remdel))
        app.add_handler(CommandHandler("remclear",     self.cmd_remclear))

        # ── v12: Finance / Crypto / Forex ─────────────────────────────────────
        app.add_handler(CommandHandler("price",        self.cmd_price))
        app.add_handler(CommandHandler("crypto",       self.cmd_crypto))
        app.add_handler(CommandHandler("stocks",       self.cmd_stocks))
        app.add_handler(CommandHandler("market",       self.cmd_market))
        app.add_handler(CommandHandler("fx",           self.cmd_fx))

        # ── v12: Backup ───────────────────────────────────────────────────────
        app.add_handler(CommandHandler("backup",       self.cmd_backup))

        # ── v12: Transcript / Session Log ─────────────────────────────────────
        app.add_handler(CommandHandler("transcript",   self.cmd_transcript))

        # ── v12: Advanced Autonomous Agent ───────────────────────────────────
        app.add_handler(CommandHandler("think",        self.cmd_think))
        app.add_handler(CommandHandler("goal",         self.cmd_goal))
        app.add_handler(CommandHandler("hypo",         self.cmd_hypo))
        app.add_handler(CommandHandler("beliefs",      self.cmd_beliefs))
        app.add_handler(CommandHandler("rapport",      self.cmd_rapport))
        app.add_handler(CommandHandler("selfcheck",    self.cmd_selfcheck))
        app.add_handler(CommandHandler("agentmode",    self.cmd_agentmode))
        app.add_handler(CommandHandler("probe",        self.cmd_probe))
        # v13: New commands
        app.add_handler(CommandHandler("setup",        self.cmd_setup))
        app.add_handler(CommandHandler("skilldocs",    self.cmd_skilldocs))

        # ── Power ─────────────────────────────────────────────────────────────
        app.add_handler(CommandHandler("shutdown",   self.cmd_shutdown))
        app.add_handler(CommandHandler("restart",    self.cmd_restart))
        app.add_handler(CommandHandler("sleep",      self.cmd_sleep))
        app.add_handler(CommandHandler("lock",       self.cmd_lock))
        app.add_handler(CommandHandler("logout",     self.cmd_logout))
        app.add_handler(CommandHandler("hibernate",  self.cmd_hibernate))
        app.add_handler(CommandHandler("screensaver",self.cmd_screensaver))
        app.add_handler(CommandHandler("displays",   self.cmd_displays))

        # ── Callback queries ──────────────────────────────────────────────────
        # Order matters: ai_handler callbacks checked first, then existing ones
        app.add_handler(CallbackQueryHandler(self._dispatch_callback))

        # ── Documents (file uploads) — smart upload with folder picker ─────────
        app.add_handler(MessageHandler(
            filters.Document.ALL,
            self.handle_document_smart
        ))

        # ── Photos — vision AI handler ─────────────────────────────────────────
        app.add_handler(MessageHandler(
            filters.PHOTO,
            self.handle_photo_message
        ))

        # ── Text replies to photos — vision AI ────────────────────────────────
        app.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND & filters.REPLY,
            self._handle_text_or_photo_reply
        ))

        # ── Voice / Audio messages → transcribe & execute ─────────────────────
        app.add_handler(MessageHandler(
            filters.VOICE | filters.AUDIO,
            self.handle_voice_message
        ))

        # ── Unknown /commands ─────────────────────────────────────────────────
        app.add_handler(MessageHandler(
            filters.COMMAND,
            self.cmd_unknown
        ))

        # ── AI: plain text messages (non-reply, MUST be last) ─────────────────
        app.add_handler(MessageHandler(
            filters.TEXT & ~filters.COMMAND & ~filters.REPLY,
            self.handle_ai_message
        ))

        # ── Post-init: set bot command menu + start background services ─────
        async def post_init(app2: Application):
            await app2.bot.set_my_commands(self._bot_commands())
            self._start_alert_monitor(app2)
            self._app = app2
            # Start heartbeat service
            hb = get_heartbeat()
            hb.set_app(app2)
            hb.start()
            logger.info("Heartbeat service started")
            # Restore pending reminders
            try:
                await self.restore_reminders(app2.bot)
                logger.info("Reminders restored")
            except Exception as e:
                logger.warning(f"Reminders restore error: {e}")
            # Load dynamic skill plugins
            try:
                loader = get_skill_loader()
                loaded = loader.load_all(self)
                if loaded:
                    loader.register_with_bot(self)
                    for skill_name, info in loader.get_loaded().items():
                        for cmd in info["commands"]:
                            method = getattr(self, f"cmd_{cmd}", None)
                            if method:
                                app2.add_handler(CommandHandler(cmd, method))
                    logger.info(f"Loaded {len(loaded)} skills: {', '.join(loaded)}")
            except Exception as e:
                logger.warning(f"Skills load error: {e}")
            # v13: Bootstrap skill .md files from built-in paths
            try:
                from salim.handlers.skill_engine import bootstrap_skills
                bootstrapped = bootstrap_skills()
                if bootstrapped:
                    logger.info(f"Bootstrapped skill docs: {', '.join(bootstrapped)}")
            except Exception as e:
                logger.warning(f"Skill engine bootstrap error: {e}")
        app.post_init = post_init

    # ── /start ───────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_start(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        from salim.ai import SalimAI
        ai = SalimAI(self.config)
        ai_status = ai.status_line()

        keyboard = [
            [
                InlineKeyboardButton("💻 System",     callback_data="dash:info"),
                InlineKeyboardButton("📸 Screenshot", callback_data="dash:screenshot"),
                InlineKeyboardButton("📊 Top",        callback_data="dash:top"),
            ],
            [
                InlineKeyboardButton("📂 Files",      callback_data="dash:ls"),
                InlineKeyboardButton("⚙️ Processes",  callback_data="dash:ps"),
                InlineKeyboardButton("🌐 Network",    callback_data="dash:network"),
            ],
            [
                InlineKeyboardButton("🔋 Battery",    callback_data="dash:battery"),
                InlineKeyboardButton("📋 Clipboard",  callback_data="dash:paste"),
                InlineKeyboardButton("💿 Disk",       callback_data="dash:disk"),
            ],
            [
                InlineKeyboardButton("📋 All Commands", callback_data="dash:help"),
                InlineKeyboardButton("⚙️ Config",       callback_data="dash:config"),
            ],
        ]
        markup = InlineKeyboardMarkup(keyboard)
        user   = update.effective_user
        os_name = platform.system()
        await update.effective_message.reply_text(
            f"🖥️ <b>Salim</b> — {esc(os_name)} Control\n\n"
            f"Hello, {esc(user.first_name)}! Your laptop is ready.\n"
            f"📂 CWD: <code>{esc(self._cwd)}</code>\n"
            f"🕐 {short_time()}\n"
            f"{esc(ai_status)}\n\n"
            "💬 <b>Just type anything in plain English — AI will understand!</b>\n"
            "Or choose an action below:",
            parse_mode=H,
            reply_markup=markup
        )

    # ── /help ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_help(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        text = (
            "📋 <b>Salim v13 — All Commands</b>\n"
            "💬 <b>Just type anything in plain English — no / needed!</b>\n\n"

            "🤖 <b>AI &amp; Agent</b>\n"
            "<code>/agent &lt;goal&gt;</code> — autonomous multi-step task\n"
            "<code>/think &lt;problem&gt;</code> — deep reasoning\n"
            "<code>/goal &lt;set|list|done&gt;</code> — persistent goals\n"
            "<code>/hypo &lt;hypothesis&gt;</code> — hypothesis testing\n"
            "<code>/beliefs</code> — agent knowledge base\n"
            "<code>/rapport</code> — communication style\n"
            "<code>/selfcheck</code> — self-assessment\n"
            "<code>/agentmode &lt;mode&gt;</code> — brief/detailed/empathy\n"
            "<code>/probe &lt;topic&gt;</code> — investigate + hypothesize\n\n"

            "📄 <b>Documents (Skills-powered)</b>\n"
            "<code>/agent create word invoice for ABC</code>\n"
            "<code>/agent create excel salary sheet</code>\n"
            "<code>/agent create pptx sales pitch 6 slides</code>\n"
            "<code>/agent create pdf company profile</code>\n"
            "<code>/agent write resignation letter for Ahmed</code>\n"
            "<i>Also just type: 'create an invoice' — Salim understands!</i>\n\n"

            "📧 <b>Email (HTML Beautiful)</b>\n"
            "<code>/agent email send to boss@co.com subject Update body Done</code>\n"
            "<code>/agent email read</code> — read inbox\n"
            "<code>/agent email search invoice</code> — search emails\n"
            "<code>/agent email setup</code> — configure SMTP/IMAP\n\n"

            "🖥️ <b>System</b>\n"
            "<code>/info /cpu /mem /disk /battery /network /uptime /top</code>\n\n"

            "⚙️ <b>Processes</b>\n"
            "<code>/ps [name]  /kill &lt;pid&gt;  /top</code>\n\n"

            "💻 <b>Shell</b>\n"
            "<code>/run /runbg /pipe /env /which /cron /cronjobs /cronstop</code>\n\n"

            "📂 <b>Files</b>\n"
            "<code>/ls /cd /pwd /cat /stat /find /grep /mkdir /rm /mv /cp</code>\n"
            "<code>/write /download /upload /zip /unzip</code>\n\n"

            "📸 <b>Screen &amp; Photos</b>\n"
            "<code>/screenshot  /stream [interval]  /streamstop</code>\n"
            "<code>/type /key /click /scroll /move /open</code>\n"
            "Send photo with caption <i>'save this'</i> — auto-saves to your folder\n"
            "Send photo with <i>'email to x@y.com'</i> — sends as attachment\n\n"

            "🌍 <b>Web &amp; Info</b>\n"
            "<code>/web &lt;url&gt; /websearch &lt;query&gt; /webnews &lt;topic&gt; /yt &lt;url&gt;</code>\n"
            "<code>/weather [city]  /translate &lt;text&gt;  /tl &lt;text&gt;</code>\n\n"

            "💰 <b>Finance</b>\n"
            "<code>/price &lt;BTC|AAPL&gt;  /market  /fx &lt;USD EUR 100&gt;</code>\n\n"

            "📅 <b>Calendar &amp; Reminders</b>\n"
            "<code>/cal [add|list|search]  /remind &lt;natural language&gt;</code>\n"
            "<code>/reminders  /at &lt;time&gt; &lt;cmd&gt;  /every &lt;interval&gt;</code>\n\n"

            "🔌 <b>Network</b>\n"
            "<code>/ports /netdevices /myip /ping /dns /whois</code>\n\n"

            "🔀 <b>Git</b>\n"
            "<code>/git status|commit|push|pull|clone|branch</code>\n\n"

            "📋 <b>Notes &amp; Memory</b>\n"
            "<code>/note /notes /notedel /memory /history</code>\n\n"

            "🔌 <b>Skills (SKILL.md)</b>\n"
            "<code>/skills — list installed skill docs\n"
            "/skilladd &lt;url&gt; — install skill from URL\n"
            "/skills reload — hot-reload</code>\n\n"

            "🎙️ <b>Voice &amp; Vision</b>\n"
            "<code>/vision on|off  /askvision &lt;q&gt;  /tts &lt;text&gt;  /say &lt;text&gt;</code>\n"
            "Send any voice note → transcribed + executed\n\n"

            "🔐 <b>SSH</b>\n"
            "<code>/ssh_add /ssh_list /ssh &lt;alias&gt; &lt;cmd&gt;</code>\n\n"

            "📷 <b>Camera</b>\n"
            "<code>/cam  /cam list  /record &lt;seconds&gt;</code>\n\n"

            "💾 <b>Backup &amp; Transcript</b>\n"
            "<code>/backup  /transcript</code>\n\n"

            "⚙️ <b>Setup</b>\n"
            "<code>/setup — re-run onboarding wizard\n"
            "/config /logs /status /digest</code>\n\n"

            "🌅 <b>Morning Briefing</b>\n"
            "<code>/digest — weather + calendar + email + news</code>"
        )
        await update.effective_message.reply_text(text, parse_mode=H)

    # ── /status ──────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_status(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        import psutil
        from salim.utils import bytes_to_human
        from salim.ai import SalimAI
        cpu = psutil.cpu_percent(interval=0.5)
        mem = psutil.virtual_memory()
        ai  = SalimAI(self.config)
        text = (
            f"✅ <b>Salim Online</b>\n"
            f"🕐 {short_time()} · {esc(platform.node())}\n"
            f"📂 <code>{esc(self._cwd)}</code>\n"
            f"⚙️ CPU {cpu}% · RAM {mem.percent}%\n"
            f"{esc(ai.status_line())}"
        )
        await update.effective_message.reply_text(text, parse_mode=H)

    # ── /config ──────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_config(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if ctx.args and ctx.args[0] == "set" and len(ctx.args) >= 3:
            key_map = {
                "max_file_mb":        "SALIM_MAX_FILE_MB",
                "screenshot_quality": "SALIM_SCREENSHOT_QUALITY",
                "log_commands":       "SALIM_LOG_COMMANDS",
                "download_dir":       "SALIM_DOWNLOAD_DIR",
                "upload_dir":         "SALIM_UPLOAD_DIR",
                "nvidia_model":       "SALIM_NVIDIA_MODEL",
                "groq_model":         "SALIM_GROQ_MODEL",
                "zai_model":          "SALIM_ZAI_MODEL",
            }
            k = ctx.args[1].lower()
            v = " ".join(ctx.args[2:])
            env_key = key_map.get(k)
            if env_key:
                self.config.set(env_key, v)
                await update.effective_message.reply_text(
                    f"✅ Set <code>{esc(k)}</code> = <code>{esc(v)}</code>", parse_mode=H
                )
            else:
                valid = ", ".join(key_map.keys())
                await update.effective_message.reply_text(
                    f"❌ Unknown key <code>{esc(k)}</code>\nValid: {esc(valid)}", parse_mode=H
                )
            return

        summary = self.config.summary()
        # Add all 3 AI providers to summary
        for _k, _env, _model_env in [
            ("nvidia", "SALIM_NVIDIA_API_KEY", "SALIM_NVIDIA_MODEL"),
            ("groq",   "SALIM_GROQ_API_KEY",   "SALIM_GROQ_MODEL"),
            ("zai",    "SALIM_ZAI_API_KEY",     "SALIM_ZAI_MODEL"),
        ]:
            _key = self.config.get(_env, "")
            _model = self.config.get(_model_env, "(not set)").split("/")[-1]
            summary[f"{_k}_model"]   = _model
            summary[f"{_k}_api_key"] = (_key[:8] + "...") if _key else "(not set)"

        lines = [f"• <code>{esc(k)}</code>: <code>{esc(v)}</code>" for k, v in summary.items()]
        text = "⚙️ <b>Salim Config</b>\n\n" + "\n".join(lines) + \
               "\n\n<i>Change with: <code>/config set &lt;key&gt; &lt;value&gt;</code></i>"
        await update.effective_message.reply_text(text, parse_mode=H)

    # ── /logs ────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_logs(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        n = int(ctx.args[0]) if ctx.args else 20
        entries = self.auth.get_audit_log(n)
        if not entries:
            await update.effective_message.reply_text("📋 No log entries yet.")
            return
        lines = [
            f"<code>{esc(e['ts'][11:19])}</code> {esc(e.get('user','?'))} → <code>{esc(e['cmd'])}</code> {esc(e.get('args','')[:40])}"
            for e in entries
        ]
        await update.effective_message.reply_text(
            f"📋 <b>Last {len(lines)} Commands</b>\n\n" + "\n".join(lines),
            parse_mode=H
        )

    # ── Callback dispatcher ───────────────────────────────────────────────────
    async def _dispatch_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data  = query.data or ""

        # ── Onboarding callbacks ──────────────────────────────────────────────
        if data.startswith("ob_"):
            await self._handle_onboarding_callback(query, data)
            return

        # ── NLP auto-confirm callback ─────────────────────────────────────────
        if data.startswith("nlp_confirm:"):
            handler_name = data.split(":", 1)[1]
            if hasattr(self, handler_name):
                await query.edit_message_text(
                    f"✅ <b>Confirmed</b> — running <code>{esc(handler_name.replace('cmd_', ''))}</code>",
                    parse_mode="HTML"
                )
                ctx.args = []
                await getattr(self, handler_name)(update, ctx)
            return

        # ── AI callbacks ──────────────────────────────────────────────────────
        if (data.startswith("ai_") or data.startswith("sr_") or data.startswith("fa_")):
            await self.handle_ai_callback(update, ctx)
            return

        # ── Stream callbacks ──────────────────────────────────────────────────
        if data.startswith("stream_"):
            await self.handle_stream_callback(update, ctx)
            return

        # ── Browser callbacks ─────────────────────────────────────────────────
        if data.startswith("browse_"):
            await self.handle_browse_callback(update, ctx)
            return

        # ── Vision callbacks ──────────────────────────────────────────────────
        if data.startswith("vision_"):
            await self.handle_vision_callback(update, ctx)
            return

        # ── Existing dashboard callbacks ──────────────────────────────────────
        dispatch_map = {
            "dash:info":       self.cmd_info,
            "dash:screenshot": self.cmd_screenshot,
            "dash:top":        self.cmd_top,
            "dash:ls":         self.cmd_ls,
            "dash:ps":         self.cmd_ps,
            "dash:network":    self.cmd_network,
            "dash:battery":    self.cmd_battery,
            "dash:paste":      self.cmd_paste_smart,  # use new smart paste
            "dash:disk":       self.cmd_disk,
            "dash:help":       self.cmd_help,
            "dash:config":     self.cmd_config,
        }

        if data in dispatch_map:
            ctx.args = []
            await dispatch_map[data](update, ctx)
        elif data.startswith("rm_confirm:"):
            await self.cb_rm_confirm(update, ctx)
        elif data == "rm_cancel":
            await query.edit_message_text("❌ Deletion cancelled.")
        elif data.startswith("power:"):
            await self.cb_power(update, ctx)
        elif data.startswith("upload_dest:") or data.startswith("upload_cancel:") or data.startswith("upload_custom:"):
            await self.handle_upload_callback(update, ctx)
        elif data.startswith("code_rerun:") or data.startswith("code_save:"):
            await self.handle_code_callback(update, ctx)
        elif data.startswith("alert_ack:"):
            aid = data.split(":", 1)[1]
            await query.edit_message_text(
                f"✅ <b>Alert acknowledged</b>\n\n"
                f"<code>{aid}</code> noted at {datetime.now().strftime('%H:%M:%S')}.\n"
                f"Alert will re-arm once the condition clears.",
                parse_mode="HTML"
            )
        else:
            logger.warning(f"Unknown callback: {data!r}")

    async def _handle_text_or_photo_reply(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Routes reply messages:
        - If replying to a photo → vision AI
        - Otherwise → AI handler
        """
        msg = update.effective_message
        if msg and msg.reply_to_message and msg.reply_to_message.photo:
            await self.handle_photo_reply(update, ctx)
        else:
            await self.handle_ai_message(update, ctx)

    # ── Unknown command ───────────────────────────────────────────────────────
    async def cmd_unknown(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not self.auth.is_allowed(update.effective_user.id):
            return
        cmd = update.effective_message.text.split()[0]
        await update.effective_message.reply_text(
            f"❓ Unknown command: <code>{esc(cmd)}</code>\n"
            f"Send /help for all commands, or just <b>type in plain English</b> — AI will understand!",
            parse_mode=H
        )

    # ── Bot command menu list ─────────────────────────────────────────────────
    def _bot_commands(self) -> list[BotCommand]:
        """
        Telegram allows max 100 commands in the bot menu.
        We show the most useful ones here. All commands still work via text.
        """
        return [
            # ── Core ─────────────────────────────────────────────────────────
            BotCommand("start",       "Dashboard"),
            BotCommand("help",        "All commands"),
            BotCommand("config",      "Bot settings"),
            BotCommand("setup",       "Onboarding wizard (save folders)"),
            BotCommand("status",      "Bot health check"),
            # ── Agent & AI ───────────────────────────────────────────────────
            BotCommand("agent",       "Autonomous multi-step task"),
            BotCommand("think",       "Deep reasoning"),
            BotCommand("goal",        "Manage goals"),
            BotCommand("probe",       "Investigate a topic"),
            BotCommand("beliefs",     "Agent knowledge base"),
            BotCommand("rapport",     "Communication style"),
            # ── Documents (skill-powered) ─────────────────────────────────
            BotCommand("doc",         "Create Word/Excel/PDF/PPTX"),
            BotCommand("skilldocs",   "List SKILL.md files"),
            BotCommand("skills",      "List skill plugins"),
            # ── System ───────────────────────────────────────────────────────
            BotCommand("info",        "System overview"),
            BotCommand("screenshot",  "Take screenshot"),
            BotCommand("cpu",         "CPU usage"),
            BotCommand("mem",         "Memory usage"),
            BotCommand("disk",        "Disk usage"),
            BotCommand("battery",     "Battery status"),
            BotCommand("network",     "Network info"),
            BotCommand("top",         "Live resource monitor"),
            BotCommand("ps",          "Running processes"),
            BotCommand("kill",        "Kill process"),
            BotCommand("uptime",      "System uptime"),
            # ── Screen & Input ───────────────────────────────────────────────
            BotCommand("stream",      "Live screen stream"),
            BotCommand("type",        "Type text on screen"),
            BotCommand("key",         "Press keyboard shortcut"),
            BotCommand("click",       "Mouse click"),
            BotCommand("volume",      "Get/set volume"),
            BotCommand("notify",      "Desktop notification"),
            BotCommand("lock",        "Lock screen"),
            BotCommand("sleep",       "Sleep / suspend"),
            # ── Shell & Files ────────────────────────────────────────────────
            BotCommand("run",         "Run shell command"),
            BotCommand("ls",          "List files"),
            BotCommand("cat",         "Read file"),
            BotCommand("find",        "Find files"),
            BotCommand("grep",        "Search in files"),
            BotCommand("download",    "Download file"),
            BotCommand("upload",      "Upload file to laptop"),
            BotCommand("write",       "Create/overwrite file"),
            BotCommand("mkdir",       "Create directory"),
            BotCommand("rm",          "Delete file"),
            BotCommand("mv",          "Move/rename file"),
            BotCommand("cp",          "Copy file"),
            BotCommand("zip",         "Create zip archive"),
            BotCommand("unzip",       "Extract zip archive"),
            # ── Clipboard ───────────────────────────────────────────────────
            BotCommand("paste",       "Read clipboard"),
            BotCommand("copy",        "Copy to clipboard"),
            # ── Power ────────────────────────────────────────────────────────
            BotCommand("shutdown",    "Shutdown laptop"),
            BotCommand("restart",     "Restart laptop"),
            # ── Web & Info ───────────────────────────────────────────────────
            BotCommand("web",         "Fetch a URL"),
            BotCommand("websearch",   "DuckDuckGo search"),
            BotCommand("weather",     "Weather forecast"),
            BotCommand("translate",   "Translate text"),
            BotCommand("webnews",     "Latest news"),
            BotCommand("yt",          "Summarize YouTube video"),
            # ── Finance ──────────────────────────────────────────────────────
            BotCommand("price",       "Stock or crypto price"),
            BotCommand("market",      "Market indices"),
            BotCommand("fx",          "Currency exchange"),
            # ── Calendar & Reminders ─────────────────────────────────────────
            BotCommand("cal",         "Calendar management"),
            BotCommand("remind",      "Set a reminder"),
            BotCommand("reminders",   "List reminders"),
            # ── Network ──────────────────────────────────────────────────────
            BotCommand("myip",        "Local and public IP"),
            BotCommand("ping",        "Ping a host"),
            BotCommand("ports",       "Open ports"),
            BotCommand("netdevices",  "Scan local network"),
            BotCommand("dns",         "DNS lookup"),
            # ── Vision & Voice ───────────────────────────────────────────────
            BotCommand("vision",      "Vision AI for images"),
            BotCommand("askvision",   "Ask about last photo"),
            BotCommand("tts",         "Text-to-speech"),
            BotCommand("say",         "Speak text aloud"),
            # ── Git ──────────────────────────────────────────────────────────
            BotCommand("git",         "Git control"),
            # ── SSH ──────────────────────────────────────────────────────────
            BotCommand("ssh",         "Run command on remote machine"),
            BotCommand("ssh_add",     "Register SSH host"),
            BotCommand("ssh_list",    "List SSH hosts"),
            # ── Notes & Memory ───────────────────────────────────────────────
            BotCommand("note",        "Quick note"),
            BotCommand("notes",       "List notes"),
            BotCommand("memory",      "Conversation memory"),
            BotCommand("history",     "Chat history"),
            # ── Misc ─────────────────────────────────────────────────────────
            BotCommand("cam",         "Webcam snapshot"),
            BotCommand("qr",          "Generate QR code"),
            BotCommand("alert",       "System alerts"),
            BotCommand("digest",      "Morning briefing"),
            BotCommand("backup",      "Backup files"),
            BotCommand("logs",        "Audit log"),
            BotCommand("code",        "AI writes & runs code"),
        ]
