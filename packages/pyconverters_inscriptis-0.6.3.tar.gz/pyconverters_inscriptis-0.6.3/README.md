## Requirements

- Python 3.12+
- uv as the package manager
- Pydantic v2 for the data parts.

## Installation
```
pip install pyconverters-inscriptis
```

## Publish the Python Package to PyPI
- Increment the version of your package in the `src/pyconverters_inscriptis/__init__.py` file:
```python
"""Sherpa HTML inscriptis converter"""

__version__ = 'x.y.z'
```
- Build and publish
```
uv build
uv publish
```
