from rest_framework.response import Response
from rest_framework import viewsets
from ..models import BattleReport
from .serializers import  BattleReportSerializer
from ..services import BattleReportsService
from ..permissions import HasCompensationsPluginAccess

class BattleReportViewSet(viewsets.ModelViewSet):
    '''
        API для работы с ссылками на баттл репорты и киллмэйлы
    '''
    queryset = BattleReport.objects.all().order_by('added_at')
    serializer_class = BattleReportSerializer
    permission_classes = [HasCompensationsPluginAccess]
     
    def get_queryset(self):
        """Оптимизация запросов"""
        return super().get_queryset()
    
    def create(self, validated_data):
        serializer = BattleReportSerializer(data=validated_data.data)
        if serializer.is_valid():            
            
            if 'br.evetools.org' in validated_data.data['link']:
                validated_data.data['report_type'] = BattleReport.BATTLEREPORT
            elif 'zkillboard' in validated_data.data['link']: 
                validated_data.data['report_type'] = BattleReport.KILLMAIL

            instance = BattleReport.objects.create(
                link = validated_data.data['link'],
                comment = validated_data.data['comment'] , 
                report_type = validated_data.data['report_type']
            )
            response_data = BattleReportSerializer(instance)            
            return Response(data=response_data.data, status=201)
        return Response(serializer.errors, status=400)
    
    def partial_update(self, request, pk=None, *args, **kwargs):
        if pk:
            report = BattleReport.objects.get(report_id = pk)
            data = request.data
            if data['status'] == 'N':
                report.status = BattleReport.PROCESS_NEW
            elif data['status'] == 'R':
                report.status = BattleReport.PROCESS_REINITIALIZE
            report.save()
            BattleReportsService.process(report)
            
            return Response(status=200,data=pk)
        return Response(status=404)
    def delete(self, request, pk=None, *args,**kwargs):
        if pk:
            report = BattleReport.objects.get(report_id=id)
            if report:
                report.delete()
                return Response(status=200, data=pk)
        return Response(status=404,data=pk)