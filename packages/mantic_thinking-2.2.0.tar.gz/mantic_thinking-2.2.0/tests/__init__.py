# Mantic Early Warning System - Tests
