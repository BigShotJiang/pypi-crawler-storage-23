"""Bundled JSON schemas (OpenAPI, Kimi tool definitions, etc.)."""
