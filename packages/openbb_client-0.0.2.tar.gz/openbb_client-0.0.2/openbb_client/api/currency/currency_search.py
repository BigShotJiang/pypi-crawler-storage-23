from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.currency_search_provider import CurrencySearchProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_currency_pairs import OBBjectCurrencyPairs
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: CurrencySearchProvider,
    query: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    json_query: None | str | Unset
    if isinstance(query, Unset):
        json_query = UNSET
    else:
        json_query = query
    params["query"] = json_query

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/currency/search",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectCurrencyPairs | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectCurrencyPairs.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectCurrencyPairs | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: CurrencySearchProvider,
    query: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectCurrencyPairs | OpenBBErrorResponse]:
    """Search

     Currency Search.

    Search available currency pairs.
    Currency pairs are the national currencies from two countries coupled for trading on
    the foreign exchange (FX) marketplace.
    Both currencies will have exchange rates on which the trade will have its position basis.
    All trading within the forex market, whether selling, buying, or trading, will take place through
    currency pairs.
    (ref: Investopedia)
    Major currency pairs include pairs such as EUR/USD, USD/JPY, GBP/USD, etc.

    Args:
        provider (CurrencySearchProvider):
        query (None | str | Unset): Query to search for currency pairs.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCurrencyPairs | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        query=query,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: CurrencySearchProvider,
    query: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectCurrencyPairs | OpenBBErrorResponse | None:
    """Search

     Currency Search.

    Search available currency pairs.
    Currency pairs are the national currencies from two countries coupled for trading on
    the foreign exchange (FX) marketplace.
    Both currencies will have exchange rates on which the trade will have its position basis.
    All trading within the forex market, whether selling, buying, or trading, will take place through
    currency pairs.
    (ref: Investopedia)
    Major currency pairs include pairs such as EUR/USD, USD/JPY, GBP/USD, etc.

    Args:
        provider (CurrencySearchProvider):
        query (None | str | Unset): Query to search for currency pairs.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCurrencyPairs | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        query=query,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: CurrencySearchProvider,
    query: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectCurrencyPairs | OpenBBErrorResponse]:
    """Search

     Currency Search.

    Search available currency pairs.
    Currency pairs are the national currencies from two countries coupled for trading on
    the foreign exchange (FX) marketplace.
    Both currencies will have exchange rates on which the trade will have its position basis.
    All trading within the forex market, whether selling, buying, or trading, will take place through
    currency pairs.
    (ref: Investopedia)
    Major currency pairs include pairs such as EUR/USD, USD/JPY, GBP/USD, etc.

    Args:
        provider (CurrencySearchProvider):
        query (None | str | Unset): Query to search for currency pairs.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCurrencyPairs | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        query=query,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: CurrencySearchProvider,
    query: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectCurrencyPairs | OpenBBErrorResponse | None:
    """Search

     Currency Search.

    Search available currency pairs.
    Currency pairs are the national currencies from two countries coupled for trading on
    the foreign exchange (FX) marketplace.
    Both currencies will have exchange rates on which the trade will have its position basis.
    All trading within the forex market, whether selling, buying, or trading, will take place through
    currency pairs.
    (ref: Investopedia)
    Major currency pairs include pairs such as EUR/USD, USD/JPY, GBP/USD, etc.

    Args:
        provider (CurrencySearchProvider):
        query (None | str | Unset): Query to search for currency pairs.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCurrencyPairs | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            query=query,
        )
    ).parsed
