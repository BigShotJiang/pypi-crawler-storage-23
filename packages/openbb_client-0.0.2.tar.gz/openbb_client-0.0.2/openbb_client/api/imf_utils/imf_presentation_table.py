from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    dataflow_group: None | str | Unset = UNSET,
    table: None | str | Unset = UNSET,
    country: None | str | Unset = UNSET,
    frequency: None | str | Unset = UNSET,
    dimension_values: list[str] | None | str | Unset = UNSET,
    limit: int | Unset = 1,
    raw: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_dataflow_group: None | str | Unset
    if isinstance(dataflow_group, Unset):
        json_dataflow_group = UNSET
    else:
        json_dataflow_group = dataflow_group
    params["dataflow_group"] = json_dataflow_group

    json_table: None | str | Unset
    if isinstance(table, Unset):
        json_table = UNSET
    else:
        json_table = table
    params["table"] = json_table

    json_country: None | str | Unset
    if isinstance(country, Unset):
        json_country = UNSET
    else:
        json_country = country
    params["country"] = json_country

    json_frequency: None | str | Unset
    if isinstance(frequency, Unset):
        json_frequency = UNSET
    else:
        json_frequency = frequency
    params["frequency"] = json_frequency

    json_dimension_values: list[str] | None | str | Unset
    if isinstance(dimension_values, Unset):
        json_dimension_values = UNSET
    elif isinstance(dimension_values, list):
        json_dimension_values = dimension_values

    else:
        json_dimension_values = dimension_values
    params["dimension_values"] = json_dimension_values

    params["limit"] = limit

    params["raw"] = raw

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/imf_utils/presentation_table",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    dataflow_group: None | str | Unset = UNSET,
    table: None | str | Unset = UNSET,
    country: None | str | Unset = UNSET,
    frequency: None | str | Unset = UNSET,
    dimension_values: list[str] | None | str | Unset = UNSET,
    limit: int | Unset = 1,
    raw: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OpenBBErrorResponse]:
    """Presentation Table

     Get a formatted presentation table from the IMF database. Returns as HTML or JSON list.

    Args:
        dataflow_group (None | str | Unset): The IMF dataflow group. See
            presentation_table_choices() for options.
        table (None | str | Unset): The IMF presentation table ID. See
            presentation_table_choices() for options.
        country (None | str | Unset): Country code to filter the data. Enter multiple codes by
            joining on '+'. See presentation_table_choices() for options. Typical values are ISO3
            country codes.
        frequency (None | str | Unset): The data frequency. See presentation_table_choices() for
            options. Typical values are 'A' (annual), 'Q' (quarter), 'M' (month), or 'D' (day).
        dimension_values (list[str] | None | str | Unset): Dimension selection for filtering.
            Format: 'DIM_ID1:VAL1+VAL2.' See presentation_table_choices() and list_dataflow_choices()
            for available dimensions and values.
        limit (int | Unset): Maximum number of records to retrieve per series. Default: 1.
        raw (bool | Unset): Return presentation table as raw JSON data if True. Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        dataflow_group=dataflow_group,
        table=table,
        country=country,
        frequency=frequency,
        dimension_values=dimension_values,
        limit=limit,
        raw=raw,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    dataflow_group: None | str | Unset = UNSET,
    table: None | str | Unset = UNSET,
    country: None | str | Unset = UNSET,
    frequency: None | str | Unset = UNSET,
    dimension_values: list[str] | None | str | Unset = UNSET,
    limit: int | Unset = 1,
    raw: bool | Unset = False,
) -> Any | HTTPValidationError | OpenBBErrorResponse | None:
    """Presentation Table

     Get a formatted presentation table from the IMF database. Returns as HTML or JSON list.

    Args:
        dataflow_group (None | str | Unset): The IMF dataflow group. See
            presentation_table_choices() for options.
        table (None | str | Unset): The IMF presentation table ID. See
            presentation_table_choices() for options.
        country (None | str | Unset): Country code to filter the data. Enter multiple codes by
            joining on '+'. See presentation_table_choices() for options. Typical values are ISO3
            country codes.
        frequency (None | str | Unset): The data frequency. See presentation_table_choices() for
            options. Typical values are 'A' (annual), 'Q' (quarter), 'M' (month), or 'D' (day).
        dimension_values (list[str] | None | str | Unset): Dimension selection for filtering.
            Format: 'DIM_ID1:VAL1+VAL2.' See presentation_table_choices() and list_dataflow_choices()
            for available dimensions and values.
        limit (int | Unset): Maximum number of records to retrieve per series. Default: 1.
        raw (bool | Unset): Return presentation table as raw JSON data if True. Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        dataflow_group=dataflow_group,
        table=table,
        country=country,
        frequency=frequency,
        dimension_values=dimension_values,
        limit=limit,
        raw=raw,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    dataflow_group: None | str | Unset = UNSET,
    table: None | str | Unset = UNSET,
    country: None | str | Unset = UNSET,
    frequency: None | str | Unset = UNSET,
    dimension_values: list[str] | None | str | Unset = UNSET,
    limit: int | Unset = 1,
    raw: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OpenBBErrorResponse]:
    """Presentation Table

     Get a formatted presentation table from the IMF database. Returns as HTML or JSON list.

    Args:
        dataflow_group (None | str | Unset): The IMF dataflow group. See
            presentation_table_choices() for options.
        table (None | str | Unset): The IMF presentation table ID. See
            presentation_table_choices() for options.
        country (None | str | Unset): Country code to filter the data. Enter multiple codes by
            joining on '+'. See presentation_table_choices() for options. Typical values are ISO3
            country codes.
        frequency (None | str | Unset): The data frequency. See presentation_table_choices() for
            options. Typical values are 'A' (annual), 'Q' (quarter), 'M' (month), or 'D' (day).
        dimension_values (list[str] | None | str | Unset): Dimension selection for filtering.
            Format: 'DIM_ID1:VAL1+VAL2.' See presentation_table_choices() and list_dataflow_choices()
            for available dimensions and values.
        limit (int | Unset): Maximum number of records to retrieve per series. Default: 1.
        raw (bool | Unset): Return presentation table as raw JSON data if True. Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        dataflow_group=dataflow_group,
        table=table,
        country=country,
        frequency=frequency,
        dimension_values=dimension_values,
        limit=limit,
        raw=raw,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    dataflow_group: None | str | Unset = UNSET,
    table: None | str | Unset = UNSET,
    country: None | str | Unset = UNSET,
    frequency: None | str | Unset = UNSET,
    dimension_values: list[str] | None | str | Unset = UNSET,
    limit: int | Unset = 1,
    raw: bool | Unset = False,
) -> Any | HTTPValidationError | OpenBBErrorResponse | None:
    """Presentation Table

     Get a formatted presentation table from the IMF database. Returns as HTML or JSON list.

    Args:
        dataflow_group (None | str | Unset): The IMF dataflow group. See
            presentation_table_choices() for options.
        table (None | str | Unset): The IMF presentation table ID. See
            presentation_table_choices() for options.
        country (None | str | Unset): Country code to filter the data. Enter multiple codes by
            joining on '+'. See presentation_table_choices() for options. Typical values are ISO3
            country codes.
        frequency (None | str | Unset): The data frequency. See presentation_table_choices() for
            options. Typical values are 'A' (annual), 'Q' (quarter), 'M' (month), or 'D' (day).
        dimension_values (list[str] | None | str | Unset): Dimension selection for filtering.
            Format: 'DIM_ID1:VAL1+VAL2.' See presentation_table_choices() and list_dataflow_choices()
            for available dimensions and values.
        limit (int | Unset): Maximum number of records to retrieve per series. Default: 1.
        raw (bool | Unset): Return presentation table as raw JSON data if True. Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            dataflow_group=dataflow_group,
            table=table,
            country=country,
            frequency=frequency,
            dimension_values=dimension_values,
            limit=limit,
            raw=raw,
        )
    ).parsed
