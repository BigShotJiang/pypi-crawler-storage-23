from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_estimates_forward_eps_calendar_period_type_0 import EquityEstimatesForwardEpsCalendarPeriodType0
from ...models.equity_estimates_forward_eps_fiscal_period_type_0 import EquityEstimatesForwardEpsFiscalPeriodType0
from ...models.equity_estimates_forward_eps_fiscal_period_type_1 import EquityEstimatesForwardEpsFiscalPeriodType1
from ...models.equity_estimates_forward_eps_provider import EquityEstimatesForwardEpsProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_forward_eps_estimates import OBBjectForwardEpsEstimates
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EquityEstimatesForwardEpsProvider,
    symbol: None | str | Unset = UNSET,
    fiscal_period: EquityEstimatesForwardEpsFiscalPeriodType0
    | EquityEstimatesForwardEpsFiscalPeriodType1
    | None
    | Unset = EquityEstimatesForwardEpsFiscalPeriodType0.ANNUAL,
    limit: int | None | Unset = UNSET,
    include_historical: bool | Unset = False,
    fiscal_year: int | None | Unset = UNSET,
    calendar_year: int | None | Unset = UNSET,
    calendar_period: EquityEstimatesForwardEpsCalendarPeriodType0 | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    json_symbol: None | str | Unset
    if isinstance(symbol, Unset):
        json_symbol = UNSET
    else:
        json_symbol = symbol
    params["symbol"] = json_symbol

    json_fiscal_period: None | str | Unset
    if isinstance(fiscal_period, Unset):
        json_fiscal_period = UNSET
    elif isinstance(fiscal_period, EquityEstimatesForwardEpsFiscalPeriodType0):
        json_fiscal_period = fiscal_period.value
    elif isinstance(fiscal_period, EquityEstimatesForwardEpsFiscalPeriodType1):
        json_fiscal_period = fiscal_period.value
    else:
        json_fiscal_period = fiscal_period
    params["fiscal_period"] = json_fiscal_period

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params["include_historical"] = include_historical

    json_fiscal_year: int | None | Unset
    if isinstance(fiscal_year, Unset):
        json_fiscal_year = UNSET
    else:
        json_fiscal_year = fiscal_year
    params["fiscal_year"] = json_fiscal_year

    json_calendar_year: int | None | Unset
    if isinstance(calendar_year, Unset):
        json_calendar_year = UNSET
    else:
        json_calendar_year = calendar_year
    params["calendar_year"] = json_calendar_year

    json_calendar_period: None | str | Unset
    if isinstance(calendar_period, Unset):
        json_calendar_period = UNSET
    elif isinstance(calendar_period, EquityEstimatesForwardEpsCalendarPeriodType0):
        json_calendar_period = calendar_period.value
    else:
        json_calendar_period = calendar_period
    params["calendar_period"] = json_calendar_period

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/estimates/forward_eps",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectForwardEpsEstimates | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectForwardEpsEstimates.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectForwardEpsEstimates | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityEstimatesForwardEpsProvider,
    symbol: None | str | Unset = UNSET,
    fiscal_period: EquityEstimatesForwardEpsFiscalPeriodType0
    | EquityEstimatesForwardEpsFiscalPeriodType1
    | None
    | Unset = EquityEstimatesForwardEpsFiscalPeriodType0.ANNUAL,
    limit: int | None | Unset = UNSET,
    include_historical: bool | Unset = False,
    fiscal_year: int | None | Unset = UNSET,
    calendar_year: int | None | Unset = UNSET,
    calendar_period: EquityEstimatesForwardEpsCalendarPeriodType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectForwardEpsEstimates | OpenBBErrorResponse]:
    """Forward Eps

     Get forward EPS estimates.

    Args:
        provider (EquityEstimatesForwardEpsProvider):
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): fmp, intrinio.
        fiscal_period (EquityEstimatesForwardEpsFiscalPeriodType0 |
            EquityEstimatesForwardEpsFiscalPeriodType1 | None | Unset): The future fiscal period to
            retrieve estimates for. (provider: fmp, intrinio) Default:
            EquityEstimatesForwardEpsFiscalPeriodType0.ANNUAL.
        limit (int | None | Unset): The number of data entries to return. Number of historical
            periods. (provider: fmp)
        include_historical (bool | Unset): If True, the data will include all past data and the
            limit will be ignored. (provider: fmp) Default: False.
        fiscal_year (int | None | Unset): The future fiscal year to retrieve estimates for. When
            no symbol and year is supplied the current calendar year is used. (provider: intrinio)
        calendar_year (int | None | Unset): The future calendar year to retrieve estimates for.
            When no symbol and year is supplied the current calendar year is used. (provider:
            intrinio)
        calendar_period (EquityEstimatesForwardEpsCalendarPeriodType0 | None | Unset): The future
            calendar period to retrieve estimates for. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectForwardEpsEstimates | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        fiscal_period=fiscal_period,
        limit=limit,
        include_historical=include_historical,
        fiscal_year=fiscal_year,
        calendar_year=calendar_year,
        calendar_period=calendar_period,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityEstimatesForwardEpsProvider,
    symbol: None | str | Unset = UNSET,
    fiscal_period: EquityEstimatesForwardEpsFiscalPeriodType0
    | EquityEstimatesForwardEpsFiscalPeriodType1
    | None
    | Unset = EquityEstimatesForwardEpsFiscalPeriodType0.ANNUAL,
    limit: int | None | Unset = UNSET,
    include_historical: bool | Unset = False,
    fiscal_year: int | None | Unset = UNSET,
    calendar_year: int | None | Unset = UNSET,
    calendar_period: EquityEstimatesForwardEpsCalendarPeriodType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectForwardEpsEstimates | OpenBBErrorResponse | None:
    """Forward Eps

     Get forward EPS estimates.

    Args:
        provider (EquityEstimatesForwardEpsProvider):
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): fmp, intrinio.
        fiscal_period (EquityEstimatesForwardEpsFiscalPeriodType0 |
            EquityEstimatesForwardEpsFiscalPeriodType1 | None | Unset): The future fiscal period to
            retrieve estimates for. (provider: fmp, intrinio) Default:
            EquityEstimatesForwardEpsFiscalPeriodType0.ANNUAL.
        limit (int | None | Unset): The number of data entries to return. Number of historical
            periods. (provider: fmp)
        include_historical (bool | Unset): If True, the data will include all past data and the
            limit will be ignored. (provider: fmp) Default: False.
        fiscal_year (int | None | Unset): The future fiscal year to retrieve estimates for. When
            no symbol and year is supplied the current calendar year is used. (provider: intrinio)
        calendar_year (int | None | Unset): The future calendar year to retrieve estimates for.
            When no symbol and year is supplied the current calendar year is used. (provider:
            intrinio)
        calendar_period (EquityEstimatesForwardEpsCalendarPeriodType0 | None | Unset): The future
            calendar period to retrieve estimates for. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectForwardEpsEstimates | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        fiscal_period=fiscal_period,
        limit=limit,
        include_historical=include_historical,
        fiscal_year=fiscal_year,
        calendar_year=calendar_year,
        calendar_period=calendar_period,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityEstimatesForwardEpsProvider,
    symbol: None | str | Unset = UNSET,
    fiscal_period: EquityEstimatesForwardEpsFiscalPeriodType0
    | EquityEstimatesForwardEpsFiscalPeriodType1
    | None
    | Unset = EquityEstimatesForwardEpsFiscalPeriodType0.ANNUAL,
    limit: int | None | Unset = UNSET,
    include_historical: bool | Unset = False,
    fiscal_year: int | None | Unset = UNSET,
    calendar_year: int | None | Unset = UNSET,
    calendar_period: EquityEstimatesForwardEpsCalendarPeriodType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectForwardEpsEstimates | OpenBBErrorResponse]:
    """Forward Eps

     Get forward EPS estimates.

    Args:
        provider (EquityEstimatesForwardEpsProvider):
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): fmp, intrinio.
        fiscal_period (EquityEstimatesForwardEpsFiscalPeriodType0 |
            EquityEstimatesForwardEpsFiscalPeriodType1 | None | Unset): The future fiscal period to
            retrieve estimates for. (provider: fmp, intrinio) Default:
            EquityEstimatesForwardEpsFiscalPeriodType0.ANNUAL.
        limit (int | None | Unset): The number of data entries to return. Number of historical
            periods. (provider: fmp)
        include_historical (bool | Unset): If True, the data will include all past data and the
            limit will be ignored. (provider: fmp) Default: False.
        fiscal_year (int | None | Unset): The future fiscal year to retrieve estimates for. When
            no symbol and year is supplied the current calendar year is used. (provider: intrinio)
        calendar_year (int | None | Unset): The future calendar year to retrieve estimates for.
            When no symbol and year is supplied the current calendar year is used. (provider:
            intrinio)
        calendar_period (EquityEstimatesForwardEpsCalendarPeriodType0 | None | Unset): The future
            calendar period to retrieve estimates for. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectForwardEpsEstimates | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        fiscal_period=fiscal_period,
        limit=limit,
        include_historical=include_historical,
        fiscal_year=fiscal_year,
        calendar_year=calendar_year,
        calendar_period=calendar_period,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityEstimatesForwardEpsProvider,
    symbol: None | str | Unset = UNSET,
    fiscal_period: EquityEstimatesForwardEpsFiscalPeriodType0
    | EquityEstimatesForwardEpsFiscalPeriodType1
    | None
    | Unset = EquityEstimatesForwardEpsFiscalPeriodType0.ANNUAL,
    limit: int | None | Unset = UNSET,
    include_historical: bool | Unset = False,
    fiscal_year: int | None | Unset = UNSET,
    calendar_year: int | None | Unset = UNSET,
    calendar_period: EquityEstimatesForwardEpsCalendarPeriodType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectForwardEpsEstimates | OpenBBErrorResponse | None:
    """Forward Eps

     Get forward EPS estimates.

    Args:
        provider (EquityEstimatesForwardEpsProvider):
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): fmp, intrinio.
        fiscal_period (EquityEstimatesForwardEpsFiscalPeriodType0 |
            EquityEstimatesForwardEpsFiscalPeriodType1 | None | Unset): The future fiscal period to
            retrieve estimates for. (provider: fmp, intrinio) Default:
            EquityEstimatesForwardEpsFiscalPeriodType0.ANNUAL.
        limit (int | None | Unset): The number of data entries to return. Number of historical
            periods. (provider: fmp)
        include_historical (bool | Unset): If True, the data will include all past data and the
            limit will be ignored. (provider: fmp) Default: False.
        fiscal_year (int | None | Unset): The future fiscal year to retrieve estimates for. When
            no symbol and year is supplied the current calendar year is used. (provider: intrinio)
        calendar_year (int | None | Unset): The future calendar year to retrieve estimates for.
            When no symbol and year is supplied the current calendar year is used. (provider:
            intrinio)
        calendar_period (EquityEstimatesForwardEpsCalendarPeriodType0 | None | Unset): The future
            calendar period to retrieve estimates for. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectForwardEpsEstimates | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            fiscal_period=fiscal_period,
            limit=limit,
            include_historical=include_historical,
            fiscal_year=fiscal_year,
            calendar_year=calendar_year,
            calendar_period=calendar_period,
        )
    ).parsed
