from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_estimates_forward_ebitda_estimate_type_type_0 import EquityEstimatesForwardEbitdaEstimateTypeType0
from ...models.equity_estimates_forward_ebitda_fiscal_period_type_0 import EquityEstimatesForwardEbitdaFiscalPeriodType0
from ...models.equity_estimates_forward_ebitda_provider import EquityEstimatesForwardEbitdaProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_forward_ebitda_estimates import OBBjectForwardEbitdaEstimates
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EquityEstimatesForwardEbitdaProvider,
    symbol: None | str | Unset = UNSET,
    fiscal_period: EquityEstimatesForwardEbitdaFiscalPeriodType0
    | None
    | Unset = EquityEstimatesForwardEbitdaFiscalPeriodType0.ANNUAL,
    limit: int | None | Unset = UNSET,
    include_historical: bool | Unset = False,
    estimate_type: EquityEstimatesForwardEbitdaEstimateTypeType0 | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    json_symbol: None | str | Unset
    if isinstance(symbol, Unset):
        json_symbol = UNSET
    else:
        json_symbol = symbol
    params["symbol"] = json_symbol

    json_fiscal_period: None | str | Unset
    if isinstance(fiscal_period, Unset):
        json_fiscal_period = UNSET
    elif isinstance(fiscal_period, EquityEstimatesForwardEbitdaFiscalPeriodType0):
        json_fiscal_period = fiscal_period.value
    else:
        json_fiscal_period = fiscal_period
    params["fiscal_period"] = json_fiscal_period

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params["include_historical"] = include_historical

    json_estimate_type: None | str | Unset
    if isinstance(estimate_type, Unset):
        json_estimate_type = UNSET
    elif isinstance(estimate_type, EquityEstimatesForwardEbitdaEstimateTypeType0):
        json_estimate_type = estimate_type.value
    else:
        json_estimate_type = estimate_type
    params["estimate_type"] = json_estimate_type

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/estimates/forward_ebitda",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectForwardEbitdaEstimates | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectForwardEbitdaEstimates.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectForwardEbitdaEstimates | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityEstimatesForwardEbitdaProvider,
    symbol: None | str | Unset = UNSET,
    fiscal_period: EquityEstimatesForwardEbitdaFiscalPeriodType0
    | None
    | Unset = EquityEstimatesForwardEbitdaFiscalPeriodType0.ANNUAL,
    limit: int | None | Unset = UNSET,
    include_historical: bool | Unset = False,
    estimate_type: EquityEstimatesForwardEbitdaEstimateTypeType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectForwardEbitdaEstimates | OpenBBErrorResponse]:
    """Forward Ebitda

     Get forward EBITDA estimates.

    Args:
        provider (EquityEstimatesForwardEbitdaProvider):
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): fmp, intrinio.
        fiscal_period (EquityEstimatesForwardEbitdaFiscalPeriodType0 | None | Unset): The future
            fiscal period to retrieve estimates for. (provider: fmp);
                Filter for only full-year or quarterly estimates. (provider: intrinio) Default:
            EquityEstimatesForwardEbitdaFiscalPeriodType0.ANNUAL.
        limit (int | None | Unset): The number of data entries to return. Number of historical
            periods. (provider: fmp)
        include_historical (bool | Unset): If True, the data will include all past data and the
            limit will be ignored. (provider: fmp) Default: False.
        estimate_type (EquityEstimatesForwardEbitdaEstimateTypeType0 | None | Unset): Limit the
            EBITDA estimates to this type. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectForwardEbitdaEstimates | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        fiscal_period=fiscal_period,
        limit=limit,
        include_historical=include_historical,
        estimate_type=estimate_type,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityEstimatesForwardEbitdaProvider,
    symbol: None | str | Unset = UNSET,
    fiscal_period: EquityEstimatesForwardEbitdaFiscalPeriodType0
    | None
    | Unset = EquityEstimatesForwardEbitdaFiscalPeriodType0.ANNUAL,
    limit: int | None | Unset = UNSET,
    include_historical: bool | Unset = False,
    estimate_type: EquityEstimatesForwardEbitdaEstimateTypeType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectForwardEbitdaEstimates | OpenBBErrorResponse | None:
    """Forward Ebitda

     Get forward EBITDA estimates.

    Args:
        provider (EquityEstimatesForwardEbitdaProvider):
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): fmp, intrinio.
        fiscal_period (EquityEstimatesForwardEbitdaFiscalPeriodType0 | None | Unset): The future
            fiscal period to retrieve estimates for. (provider: fmp);
                Filter for only full-year or quarterly estimates. (provider: intrinio) Default:
            EquityEstimatesForwardEbitdaFiscalPeriodType0.ANNUAL.
        limit (int | None | Unset): The number of data entries to return. Number of historical
            periods. (provider: fmp)
        include_historical (bool | Unset): If True, the data will include all past data and the
            limit will be ignored. (provider: fmp) Default: False.
        estimate_type (EquityEstimatesForwardEbitdaEstimateTypeType0 | None | Unset): Limit the
            EBITDA estimates to this type. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectForwardEbitdaEstimates | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        fiscal_period=fiscal_period,
        limit=limit,
        include_historical=include_historical,
        estimate_type=estimate_type,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityEstimatesForwardEbitdaProvider,
    symbol: None | str | Unset = UNSET,
    fiscal_period: EquityEstimatesForwardEbitdaFiscalPeriodType0
    | None
    | Unset = EquityEstimatesForwardEbitdaFiscalPeriodType0.ANNUAL,
    limit: int | None | Unset = UNSET,
    include_historical: bool | Unset = False,
    estimate_type: EquityEstimatesForwardEbitdaEstimateTypeType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectForwardEbitdaEstimates | OpenBBErrorResponse]:
    """Forward Ebitda

     Get forward EBITDA estimates.

    Args:
        provider (EquityEstimatesForwardEbitdaProvider):
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): fmp, intrinio.
        fiscal_period (EquityEstimatesForwardEbitdaFiscalPeriodType0 | None | Unset): The future
            fiscal period to retrieve estimates for. (provider: fmp);
                Filter for only full-year or quarterly estimates. (provider: intrinio) Default:
            EquityEstimatesForwardEbitdaFiscalPeriodType0.ANNUAL.
        limit (int | None | Unset): The number of data entries to return. Number of historical
            periods. (provider: fmp)
        include_historical (bool | Unset): If True, the data will include all past data and the
            limit will be ignored. (provider: fmp) Default: False.
        estimate_type (EquityEstimatesForwardEbitdaEstimateTypeType0 | None | Unset): Limit the
            EBITDA estimates to this type. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectForwardEbitdaEstimates | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        fiscal_period=fiscal_period,
        limit=limit,
        include_historical=include_historical,
        estimate_type=estimate_type,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityEstimatesForwardEbitdaProvider,
    symbol: None | str | Unset = UNSET,
    fiscal_period: EquityEstimatesForwardEbitdaFiscalPeriodType0
    | None
    | Unset = EquityEstimatesForwardEbitdaFiscalPeriodType0.ANNUAL,
    limit: int | None | Unset = UNSET,
    include_historical: bool | Unset = False,
    estimate_type: EquityEstimatesForwardEbitdaEstimateTypeType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectForwardEbitdaEstimates | OpenBBErrorResponse | None:
    """Forward Ebitda

     Get forward EBITDA estimates.

    Args:
        provider (EquityEstimatesForwardEbitdaProvider):
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): fmp, intrinio.
        fiscal_period (EquityEstimatesForwardEbitdaFiscalPeriodType0 | None | Unset): The future
            fiscal period to retrieve estimates for. (provider: fmp);
                Filter for only full-year or quarterly estimates. (provider: intrinio) Default:
            EquityEstimatesForwardEbitdaFiscalPeriodType0.ANNUAL.
        limit (int | None | Unset): The number of data entries to return. Number of historical
            periods. (provider: fmp)
        include_historical (bool | Unset): If True, the data will include all past data and the
            limit will be ignored. (provider: fmp) Default: False.
        estimate_type (EquityEstimatesForwardEbitdaEstimateTypeType0 | None | Unset): Limit the
            EBITDA estimates to this type. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectForwardEbitdaEstimates | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            fiscal_period=fiscal_period,
            limit=limit,
            include_historical=include_historical,
            estimate_type=estimate_type,
        )
    ).parsed
