import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_ownership_insider_trading_ownership_type_type_0 import (
    EquityOwnershipInsiderTradingOwnershipTypeType0,
)
from ...models.equity_ownership_insider_trading_provider import EquityOwnershipInsiderTradingProvider
from ...models.equity_ownership_insider_trading_sort_by_type_0 import EquityOwnershipInsiderTradingSortByType0
from ...models.equity_ownership_insider_trading_transaction_type_type_0 import (
    EquityOwnershipInsiderTradingTransactionTypeType0,
)
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_insider_trading import OBBjectInsiderTrading
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EquityOwnershipInsiderTradingProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    transaction_type: EquityOwnershipInsiderTradingTransactionTypeType0 | None | Unset = UNSET,
    statistics: bool | Unset = False,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    ownership_type: EquityOwnershipInsiderTradingOwnershipTypeType0 | None | Unset = UNSET,
    sort_by: EquityOwnershipInsiderTradingSortByType0
    | None
    | Unset = EquityOwnershipInsiderTradingSortByType0.UPDATED_ON,
    use_cache: bool | Unset = True,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    params["symbol"] = symbol

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_transaction_type: None | str | Unset
    if isinstance(transaction_type, Unset):
        json_transaction_type = UNSET
    elif isinstance(transaction_type, EquityOwnershipInsiderTradingTransactionTypeType0):
        json_transaction_type = transaction_type.value
    else:
        json_transaction_type = transaction_type
    params["transaction_type"] = json_transaction_type

    params["statistics"] = statistics

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_ownership_type: None | str | Unset
    if isinstance(ownership_type, Unset):
        json_ownership_type = UNSET
    elif isinstance(ownership_type, EquityOwnershipInsiderTradingOwnershipTypeType0):
        json_ownership_type = ownership_type.value
    else:
        json_ownership_type = ownership_type
    params["ownership_type"] = json_ownership_type

    json_sort_by: None | str | Unset
    if isinstance(sort_by, Unset):
        json_sort_by = UNSET
    elif isinstance(sort_by, EquityOwnershipInsiderTradingSortByType0):
        json_sort_by = sort_by.value
    else:
        json_sort_by = sort_by
    params["sort_by"] = json_sort_by

    params["use_cache"] = use_cache

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/ownership/insider_trading",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectInsiderTrading | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectInsiderTrading.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectInsiderTrading | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityOwnershipInsiderTradingProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    transaction_type: EquityOwnershipInsiderTradingTransactionTypeType0 | None | Unset = UNSET,
    statistics: bool | Unset = False,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    ownership_type: EquityOwnershipInsiderTradingOwnershipTypeType0 | None | Unset = UNSET,
    sort_by: EquityOwnershipInsiderTradingSortByType0
    | None
    | Unset = EquityOwnershipInsiderTradingSortByType0.UPDATED_ON,
    use_cache: bool | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectInsiderTrading | OpenBBErrorResponse]:
    """Insider Trading

     Get data about trading by a company's management team and board of directors.

    Args:
        provider (EquityOwnershipInsiderTradingProvider):
        symbol (str): Symbol to get data for.
        limit (int | None | Unset): The number of data entries to return.
        transaction_type (EquityOwnershipInsiderTradingTransactionTypeType0 | None | Unset): Type
            of the transaction. (provider: fmp)
        statistics (bool | Unset): Flag to return summary statistics for the given symbol. Setting
            as True will ignore other parameters except symbol. (provider: fmp) Default: False.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            (provider: intrinio);
                Start date of the data, in YYYY-MM-DD format. Wide date ranges can result in long
            download times. Recommended to use a smaller date range, default is 120 days ago.
            (provider: sec)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
            (provider: intrinio, sec)
        ownership_type (EquityOwnershipInsiderTradingOwnershipTypeType0 | None | Unset): Type of
            ownership. (provider: intrinio)
        sort_by (EquityOwnershipInsiderTradingSortByType0 | None | Unset): Field to sort by.
            (provider: intrinio) Default: EquityOwnershipInsiderTradingSortByType0.UPDATED_ON.
        use_cache (bool | Unset): Persist the data locally for future use. Default is True. Each
            form submission is an individual download and the SEC limits the number of concurrent
            downloads. This prevents the same file from being downloaded multiple times. (provider:
            sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectInsiderTrading | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        limit=limit,
        transaction_type=transaction_type,
        statistics=statistics,
        start_date=start_date,
        end_date=end_date,
        ownership_type=ownership_type,
        sort_by=sort_by,
        use_cache=use_cache,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityOwnershipInsiderTradingProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    transaction_type: EquityOwnershipInsiderTradingTransactionTypeType0 | None | Unset = UNSET,
    statistics: bool | Unset = False,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    ownership_type: EquityOwnershipInsiderTradingOwnershipTypeType0 | None | Unset = UNSET,
    sort_by: EquityOwnershipInsiderTradingSortByType0
    | None
    | Unset = EquityOwnershipInsiderTradingSortByType0.UPDATED_ON,
    use_cache: bool | Unset = True,
) -> Any | HTTPValidationError | OBBjectInsiderTrading | OpenBBErrorResponse | None:
    """Insider Trading

     Get data about trading by a company's management team and board of directors.

    Args:
        provider (EquityOwnershipInsiderTradingProvider):
        symbol (str): Symbol to get data for.
        limit (int | None | Unset): The number of data entries to return.
        transaction_type (EquityOwnershipInsiderTradingTransactionTypeType0 | None | Unset): Type
            of the transaction. (provider: fmp)
        statistics (bool | Unset): Flag to return summary statistics for the given symbol. Setting
            as True will ignore other parameters except symbol. (provider: fmp) Default: False.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            (provider: intrinio);
                Start date of the data, in YYYY-MM-DD format. Wide date ranges can result in long
            download times. Recommended to use a smaller date range, default is 120 days ago.
            (provider: sec)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
            (provider: intrinio, sec)
        ownership_type (EquityOwnershipInsiderTradingOwnershipTypeType0 | None | Unset): Type of
            ownership. (provider: intrinio)
        sort_by (EquityOwnershipInsiderTradingSortByType0 | None | Unset): Field to sort by.
            (provider: intrinio) Default: EquityOwnershipInsiderTradingSortByType0.UPDATED_ON.
        use_cache (bool | Unset): Persist the data locally for future use. Default is True. Each
            form submission is an individual download and the SEC limits the number of concurrent
            downloads. This prevents the same file from being downloaded multiple times. (provider:
            sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectInsiderTrading | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        limit=limit,
        transaction_type=transaction_type,
        statistics=statistics,
        start_date=start_date,
        end_date=end_date,
        ownership_type=ownership_type,
        sort_by=sort_by,
        use_cache=use_cache,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityOwnershipInsiderTradingProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    transaction_type: EquityOwnershipInsiderTradingTransactionTypeType0 | None | Unset = UNSET,
    statistics: bool | Unset = False,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    ownership_type: EquityOwnershipInsiderTradingOwnershipTypeType0 | None | Unset = UNSET,
    sort_by: EquityOwnershipInsiderTradingSortByType0
    | None
    | Unset = EquityOwnershipInsiderTradingSortByType0.UPDATED_ON,
    use_cache: bool | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectInsiderTrading | OpenBBErrorResponse]:
    """Insider Trading

     Get data about trading by a company's management team and board of directors.

    Args:
        provider (EquityOwnershipInsiderTradingProvider):
        symbol (str): Symbol to get data for.
        limit (int | None | Unset): The number of data entries to return.
        transaction_type (EquityOwnershipInsiderTradingTransactionTypeType0 | None | Unset): Type
            of the transaction. (provider: fmp)
        statistics (bool | Unset): Flag to return summary statistics for the given symbol. Setting
            as True will ignore other parameters except symbol. (provider: fmp) Default: False.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            (provider: intrinio);
                Start date of the data, in YYYY-MM-DD format. Wide date ranges can result in long
            download times. Recommended to use a smaller date range, default is 120 days ago.
            (provider: sec)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
            (provider: intrinio, sec)
        ownership_type (EquityOwnershipInsiderTradingOwnershipTypeType0 | None | Unset): Type of
            ownership. (provider: intrinio)
        sort_by (EquityOwnershipInsiderTradingSortByType0 | None | Unset): Field to sort by.
            (provider: intrinio) Default: EquityOwnershipInsiderTradingSortByType0.UPDATED_ON.
        use_cache (bool | Unset): Persist the data locally for future use. Default is True. Each
            form submission is an individual download and the SEC limits the number of concurrent
            downloads. This prevents the same file from being downloaded multiple times. (provider:
            sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectInsiderTrading | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        limit=limit,
        transaction_type=transaction_type,
        statistics=statistics,
        start_date=start_date,
        end_date=end_date,
        ownership_type=ownership_type,
        sort_by=sort_by,
        use_cache=use_cache,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityOwnershipInsiderTradingProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    transaction_type: EquityOwnershipInsiderTradingTransactionTypeType0 | None | Unset = UNSET,
    statistics: bool | Unset = False,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    ownership_type: EquityOwnershipInsiderTradingOwnershipTypeType0 | None | Unset = UNSET,
    sort_by: EquityOwnershipInsiderTradingSortByType0
    | None
    | Unset = EquityOwnershipInsiderTradingSortByType0.UPDATED_ON,
    use_cache: bool | Unset = True,
) -> Any | HTTPValidationError | OBBjectInsiderTrading | OpenBBErrorResponse | None:
    """Insider Trading

     Get data about trading by a company's management team and board of directors.

    Args:
        provider (EquityOwnershipInsiderTradingProvider):
        symbol (str): Symbol to get data for.
        limit (int | None | Unset): The number of data entries to return.
        transaction_type (EquityOwnershipInsiderTradingTransactionTypeType0 | None | Unset): Type
            of the transaction. (provider: fmp)
        statistics (bool | Unset): Flag to return summary statistics for the given symbol. Setting
            as True will ignore other parameters except symbol. (provider: fmp) Default: False.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            (provider: intrinio);
                Start date of the data, in YYYY-MM-DD format. Wide date ranges can result in long
            download times. Recommended to use a smaller date range, default is 120 days ago.
            (provider: sec)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
            (provider: intrinio, sec)
        ownership_type (EquityOwnershipInsiderTradingOwnershipTypeType0 | None | Unset): Type of
            ownership. (provider: intrinio)
        sort_by (EquityOwnershipInsiderTradingSortByType0 | None | Unset): Field to sort by.
            (provider: intrinio) Default: EquityOwnershipInsiderTradingSortByType0.UPDATED_ON.
        use_cache (bool | Unset): Persist the data locally for future use. Default is True. Each
            form submission is an individual download and the SEC limits the number of concurrent
            downloads. This prevents the same file from being downloaded multiple times. (provider:
            sec) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectInsiderTrading | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            limit=limit,
            transaction_type=transaction_type,
            statistics=statistics,
            start_date=start_date,
            end_date=end_date,
            ownership_type=ownership_type,
            sort_by=sort_by,
            use_cache=use_cache,
        )
    ).parsed
