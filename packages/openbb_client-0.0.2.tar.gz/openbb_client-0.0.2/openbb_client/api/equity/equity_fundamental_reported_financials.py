from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_fundamental_reported_financials_statement_type_type_1 import (
    EquityFundamentalReportedFinancialsStatementTypeType1,
)
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_reported_financials import OBBjectReportedFinancials
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: str,
    period: str | Unset = "annual",
    statement_type: EquityFundamentalReportedFinancialsStatementTypeType1 | str | Unset = "balance",
    limit: int | None | Unset = 100,
    fiscal_year: int | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["symbol"] = symbol

    params["period"] = period

    json_statement_type: str | Unset
    if isinstance(statement_type, Unset):
        json_statement_type = UNSET
    elif isinstance(statement_type, EquityFundamentalReportedFinancialsStatementTypeType1):
        json_statement_type = statement_type.value
    else:
        json_statement_type = statement_type
    params["statement_type"] = json_statement_type

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_fiscal_year: int | None | Unset
    if isinstance(fiscal_year, Unset):
        json_fiscal_year = UNSET
    else:
        json_fiscal_year = fiscal_year
    params["fiscal_year"] = json_fiscal_year

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/fundamental/reported_financials",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectReportedFinancials | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectReportedFinancials.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectReportedFinancials | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: str,
    period: str | Unset = "annual",
    statement_type: EquityFundamentalReportedFinancialsStatementTypeType1 | str | Unset = "balance",
    limit: int | None | Unset = 100,
    fiscal_year: int | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectReportedFinancials | OpenBBErrorResponse]:
    """Reported Financials

     Get financial statements as reported by the company.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (str): Symbol to get data for.
        period (str | Unset): Time period of the data to return. Default: 'annual'.
        statement_type (EquityFundamentalReportedFinancialsStatementTypeType1 | str | Unset): The
            type of financial statement - i.e, balance, income, cash.;
                Cash flow statements are reported as YTD, Q4 is the same as FY. (provider: intrinio)
            Default: 'balance'.
        limit (int | None | Unset): The number of data entries to return. Although the response
            object contains multiple results, because of the variance in the fields, year-to-year and
            quarter-to-quarter, it is recommended to view results in small chunks. Default: 100.
        fiscal_year (int | None | Unset): The specific fiscal year.  Reports do not go beyond
            2008. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectReportedFinancials | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        period=period,
        statement_type=statement_type,
        limit=limit,
        fiscal_year=fiscal_year,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: str,
    period: str | Unset = "annual",
    statement_type: EquityFundamentalReportedFinancialsStatementTypeType1 | str | Unset = "balance",
    limit: int | None | Unset = 100,
    fiscal_year: int | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectReportedFinancials | OpenBBErrorResponse | None:
    """Reported Financials

     Get financial statements as reported by the company.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (str): Symbol to get data for.
        period (str | Unset): Time period of the data to return. Default: 'annual'.
        statement_type (EquityFundamentalReportedFinancialsStatementTypeType1 | str | Unset): The
            type of financial statement - i.e, balance, income, cash.;
                Cash flow statements are reported as YTD, Q4 is the same as FY. (provider: intrinio)
            Default: 'balance'.
        limit (int | None | Unset): The number of data entries to return. Although the response
            object contains multiple results, because of the variance in the fields, year-to-year and
            quarter-to-quarter, it is recommended to view results in small chunks. Default: 100.
        fiscal_year (int | None | Unset): The specific fiscal year.  Reports do not go beyond
            2008. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectReportedFinancials | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        period=period,
        statement_type=statement_type,
        limit=limit,
        fiscal_year=fiscal_year,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: str,
    period: str | Unset = "annual",
    statement_type: EquityFundamentalReportedFinancialsStatementTypeType1 | str | Unset = "balance",
    limit: int | None | Unset = 100,
    fiscal_year: int | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectReportedFinancials | OpenBBErrorResponse]:
    """Reported Financials

     Get financial statements as reported by the company.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (str): Symbol to get data for.
        period (str | Unset): Time period of the data to return. Default: 'annual'.
        statement_type (EquityFundamentalReportedFinancialsStatementTypeType1 | str | Unset): The
            type of financial statement - i.e, balance, income, cash.;
                Cash flow statements are reported as YTD, Q4 is the same as FY. (provider: intrinio)
            Default: 'balance'.
        limit (int | None | Unset): The number of data entries to return. Although the response
            object contains multiple results, because of the variance in the fields, year-to-year and
            quarter-to-quarter, it is recommended to view results in small chunks. Default: 100.
        fiscal_year (int | None | Unset): The specific fiscal year.  Reports do not go beyond
            2008. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectReportedFinancials | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        period=period,
        statement_type=statement_type,
        limit=limit,
        fiscal_year=fiscal_year,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: str,
    period: str | Unset = "annual",
    statement_type: EquityFundamentalReportedFinancialsStatementTypeType1 | str | Unset = "balance",
    limit: int | None | Unset = 100,
    fiscal_year: int | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectReportedFinancials | OpenBBErrorResponse | None:
    """Reported Financials

     Get financial statements as reported by the company.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (str): Symbol to get data for.
        period (str | Unset): Time period of the data to return. Default: 'annual'.
        statement_type (EquityFundamentalReportedFinancialsStatementTypeType1 | str | Unset): The
            type of financial statement - i.e, balance, income, cash.;
                Cash flow statements are reported as YTD, Q4 is the same as FY. (provider: intrinio)
            Default: 'balance'.
        limit (int | None | Unset): The number of data entries to return. Although the response
            object contains multiple results, because of the variance in the fields, year-to-year and
            quarter-to-quarter, it is recommended to view results in small chunks. Default: 100.
        fiscal_year (int | None | Unset): The specific fiscal year.  Reports do not go beyond
            2008. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectReportedFinancials | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            period=period,
            statement_type=statement_type,
            limit=limit,
            fiscal_year=fiscal_year,
        )
    ).parsed
