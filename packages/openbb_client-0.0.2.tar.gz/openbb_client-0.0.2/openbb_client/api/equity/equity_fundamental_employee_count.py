import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_historical_employees import OBBjectHistoricalEmployees
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["symbol"] = symbol

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/fundamental/employee_count",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectHistoricalEmployees | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectHistoricalEmployees.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectHistoricalEmployees | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectHistoricalEmployees | OpenBBErrorResponse]:
    """Employee Count

     Get historical employee count data for a given company.

    Args:
        provider (Literal['fmp'] | Unset):  Default: 'fmp'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): fmp.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        limit (int | None | Unset): Number of records to return. Default is all. (provider: fmp)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectHistoricalEmployees | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectHistoricalEmployees | OpenBBErrorResponse | None:
    """Employee Count

     Get historical employee count data for a given company.

    Args:
        provider (Literal['fmp'] | Unset):  Default: 'fmp'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): fmp.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        limit (int | None | Unset): Number of records to return. Default is all. (provider: fmp)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectHistoricalEmployees | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectHistoricalEmployees | OpenBBErrorResponse]:
    """Employee Count

     Get historical employee count data for a given company.

    Args:
        provider (Literal['fmp'] | Unset):  Default: 'fmp'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): fmp.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        limit (int | None | Unset): Number of records to return. Default is all. (provider: fmp)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectHistoricalEmployees | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectHistoricalEmployees | OpenBBErrorResponse | None:
    """Employee Count

     Get historical employee count data for a given company.

    Args:
        provider (Literal['fmp'] | Unset):  Default: 'fmp'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): fmp.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        limit (int | None | Unset): Number of records to return. Default is all. (provider: fmp)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectHistoricalEmployees | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            start_date=start_date,
            end_date=end_date,
            limit=limit,
        )
    ).parsed
