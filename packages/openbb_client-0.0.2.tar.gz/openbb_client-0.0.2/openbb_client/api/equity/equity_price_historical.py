import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_price_historical_adjustment_type_0 import EquityPriceHistoricalAdjustmentType0
from ...models.equity_price_historical_adjustment_type_1 import EquityPriceHistoricalAdjustmentType1
from ...models.equity_price_historical_adjustment_type_2 import EquityPriceHistoricalAdjustmentType2
from ...models.equity_price_historical_akshare import EquityPriceHistoricalAkshare
from ...models.equity_price_historical_interval_type_0 import EquityPriceHistoricalIntervalType0
from ...models.equity_price_historical_interval_type_1 import EquityPriceHistoricalIntervalType1
from ...models.equity_price_historical_interval_type_3 import EquityPriceHistoricalIntervalType3
from ...models.equity_price_historical_interval_type_4 import EquityPriceHistoricalIntervalType4
from ...models.equity_price_historical_intrinio import EquityPriceHistoricalIntrinio
from ...models.equity_price_historical_polygon import EquityPriceHistoricalPolygon
from ...models.equity_price_historical_provider import EquityPriceHistoricalProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_equity_historical import OBBjectEquityHistorical
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EquityPriceHistoricalProvider,
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    period: EquityPriceHistoricalAkshare | Unset = EquityPriceHistoricalAkshare.DAILY,
    use_cache: bool | Unset = True,
    interval: EquityPriceHistoricalIntervalType0
    | EquityPriceHistoricalIntervalType1
    | EquityPriceHistoricalIntervalType3
    | EquityPriceHistoricalIntervalType4
    | str
    | Unset = EquityPriceHistoricalIntervalType0.VALUE_6,
    adjustment: EquityPriceHistoricalAdjustmentType0
    | EquityPriceHistoricalAdjustmentType1
    | EquityPriceHistoricalAdjustmentType2
    | Unset = EquityPriceHistoricalAdjustmentType0.SPLITS_ONLY,
    start_time: None | str | Unset = UNSET,
    end_time: None | str | Unset = UNSET,
    timezone: None | str | Unset = "America/New_York",
    source: EquityPriceHistoricalIntrinio | Unset = EquityPriceHistoricalIntrinio.REALTIME,
    extended_hours: bool | Unset = False,
    sort: EquityPriceHistoricalPolygon | Unset = EquityPriceHistoricalPolygon.ASC,
    limit: int | Unset = 49999,
    include_actions: bool | Unset = True,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    params["symbol"] = symbol

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_period: str | Unset = UNSET
    if not isinstance(period, Unset):
        json_period = period.value

    params["period"] = json_period

    params["use_cache"] = use_cache

    json_interval: str | Unset
    if isinstance(interval, Unset):
        json_interval = UNSET
    elif isinstance(interval, EquityPriceHistoricalIntervalType0):
        json_interval = interval.value
    elif isinstance(interval, EquityPriceHistoricalIntervalType1):
        json_interval = interval.value
    elif isinstance(interval, EquityPriceHistoricalIntervalType3):
        json_interval = interval.value
    elif isinstance(interval, EquityPriceHistoricalIntervalType4):
        json_interval = interval.value
    else:
        json_interval = interval
    params["interval"] = json_interval

    json_adjustment: str | Unset
    if isinstance(adjustment, Unset):
        json_adjustment = UNSET
    elif isinstance(adjustment, EquityPriceHistoricalAdjustmentType0):
        json_adjustment = adjustment.value
    elif isinstance(adjustment, EquityPriceHistoricalAdjustmentType1):
        json_adjustment = adjustment.value
    else:
        json_adjustment = adjustment.value

    params["adjustment"] = json_adjustment

    json_start_time: None | str | Unset
    if isinstance(start_time, Unset):
        json_start_time = UNSET
    else:
        json_start_time = start_time
    params["start_time"] = json_start_time

    json_end_time: None | str | Unset
    if isinstance(end_time, Unset):
        json_end_time = UNSET
    else:
        json_end_time = end_time
    params["end_time"] = json_end_time

    json_timezone: None | str | Unset
    if isinstance(timezone, Unset):
        json_timezone = UNSET
    else:
        json_timezone = timezone
    params["timezone"] = json_timezone

    json_source: str | Unset = UNSET
    if not isinstance(source, Unset):
        json_source = source.value

    params["source"] = json_source

    params["extended_hours"] = extended_hours

    json_sort: str | Unset = UNSET
    if not isinstance(sort, Unset):
        json_sort = sort.value

    params["sort"] = json_sort

    params["limit"] = limit

    params["include_actions"] = include_actions

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/price/historical",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectEquityHistorical | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectEquityHistorical.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectEquityHistorical | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityPriceHistoricalProvider,
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    period: EquityPriceHistoricalAkshare | Unset = EquityPriceHistoricalAkshare.DAILY,
    use_cache: bool | Unset = True,
    interval: EquityPriceHistoricalIntervalType0
    | EquityPriceHistoricalIntervalType1
    | EquityPriceHistoricalIntervalType3
    | EquityPriceHistoricalIntervalType4
    | str
    | Unset = EquityPriceHistoricalIntervalType0.VALUE_6,
    adjustment: EquityPriceHistoricalAdjustmentType0
    | EquityPriceHistoricalAdjustmentType1
    | EquityPriceHistoricalAdjustmentType2
    | Unset = EquityPriceHistoricalAdjustmentType0.SPLITS_ONLY,
    start_time: None | str | Unset = UNSET,
    end_time: None | str | Unset = UNSET,
    timezone: None | str | Unset = "America/New_York",
    source: EquityPriceHistoricalIntrinio | Unset = EquityPriceHistoricalIntrinio.REALTIME,
    extended_hours: bool | Unset = False,
    sort: EquityPriceHistoricalPolygon | Unset = EquityPriceHistoricalPolygon.ASC,
    limit: int | Unset = 49999,
    include_actions: bool | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectEquityHistorical | OpenBBErrorResponse]:
    """Historical

     Get historical price data for a given stock. This includes open, high, low, close, and volume.

    Args:
        provider (EquityPriceHistoricalProvider):
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): akshare, fmp, polygon, tiingo, yfinance.;
                A Security identifier (Ticker, FIGI, ISIN, CUSIP, Intrinio ID). (provider: intrinio)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        period (EquityPriceHistoricalAkshare | Unset): Time period of the data to return.
            (provider: akshare) Default: EquityPriceHistoricalAkshare.DAILY.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        interval (EquityPriceHistoricalIntervalType0 | EquityPriceHistoricalIntervalType1 |
            EquityPriceHistoricalIntervalType3 | EquityPriceHistoricalIntervalType4 | str | Unset):
            Time interval of the data to return. (provider: fmp,intrinio,polygon,tiingo, yfinance)
            Default: EquityPriceHistoricalIntervalType0.VALUE_6.
        adjustment (EquityPriceHistoricalAdjustmentType0 | EquityPriceHistoricalAdjustmentType1 |
            EquityPriceHistoricalAdjustmentType2 | Unset): Type of adjustment for historical prices.
            Only applies to daily data. (provider: fmp);
                The adjustment factor to apply. Default is splits only. (provider: polygon);
                The adjustment factor to apply. Default is splits only. (provider: yfinance) Default:
            EquityPriceHistoricalAdjustmentType0.SPLITS_ONLY.
        start_time (None | str | Unset): Return intervals starting at the specified time on the
            `start_date` formatted as 'HH:MM:SS'. (provider: intrinio)
        end_time (None | str | Unset): Return intervals stopping at the specified time on the
            `end_date` formatted as 'HH:MM:SS'. (provider: intrinio)
        timezone (None | str | Unset): Timezone of the data, in the IANA format (Continent/City).
            (provider: intrinio) Default: 'America/New_York'.
        source (EquityPriceHistoricalIntrinio | Unset): The source of the data. (provider:
            intrinio) Default: EquityPriceHistoricalIntrinio.REALTIME.
        extended_hours (bool | Unset): Include Pre and Post market data. (provider: polygon,
            yfinance) Default: False.
        sort (EquityPriceHistoricalPolygon | Unset): Sort order of the data. This impacts the
            results in combination with the 'limit' parameter. The results are always returned in
            ascending order by date. (provider: polygon) Default: EquityPriceHistoricalPolygon.ASC.
        limit (int | Unset): The number of data entries to return. (provider: polygon) Default:
            49999.
        include_actions (bool | Unset): Include dividends and stock splits in results. (provider:
            yfinance) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEquityHistorical | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        period=period,
        use_cache=use_cache,
        interval=interval,
        adjustment=adjustment,
        start_time=start_time,
        end_time=end_time,
        timezone=timezone,
        source=source,
        extended_hours=extended_hours,
        sort=sort,
        limit=limit,
        include_actions=include_actions,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityPriceHistoricalProvider,
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    period: EquityPriceHistoricalAkshare | Unset = EquityPriceHistoricalAkshare.DAILY,
    use_cache: bool | Unset = True,
    interval: EquityPriceHistoricalIntervalType0
    | EquityPriceHistoricalIntervalType1
    | EquityPriceHistoricalIntervalType3
    | EquityPriceHistoricalIntervalType4
    | str
    | Unset = EquityPriceHistoricalIntervalType0.VALUE_6,
    adjustment: EquityPriceHistoricalAdjustmentType0
    | EquityPriceHistoricalAdjustmentType1
    | EquityPriceHistoricalAdjustmentType2
    | Unset = EquityPriceHistoricalAdjustmentType0.SPLITS_ONLY,
    start_time: None | str | Unset = UNSET,
    end_time: None | str | Unset = UNSET,
    timezone: None | str | Unset = "America/New_York",
    source: EquityPriceHistoricalIntrinio | Unset = EquityPriceHistoricalIntrinio.REALTIME,
    extended_hours: bool | Unset = False,
    sort: EquityPriceHistoricalPolygon | Unset = EquityPriceHistoricalPolygon.ASC,
    limit: int | Unset = 49999,
    include_actions: bool | Unset = True,
) -> Any | HTTPValidationError | OBBjectEquityHistorical | OpenBBErrorResponse | None:
    """Historical

     Get historical price data for a given stock. This includes open, high, low, close, and volume.

    Args:
        provider (EquityPriceHistoricalProvider):
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): akshare, fmp, polygon, tiingo, yfinance.;
                A Security identifier (Ticker, FIGI, ISIN, CUSIP, Intrinio ID). (provider: intrinio)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        period (EquityPriceHistoricalAkshare | Unset): Time period of the data to return.
            (provider: akshare) Default: EquityPriceHistoricalAkshare.DAILY.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        interval (EquityPriceHistoricalIntervalType0 | EquityPriceHistoricalIntervalType1 |
            EquityPriceHistoricalIntervalType3 | EquityPriceHistoricalIntervalType4 | str | Unset):
            Time interval of the data to return. (provider: fmp,intrinio,polygon,tiingo, yfinance)
            Default: EquityPriceHistoricalIntervalType0.VALUE_6.
        adjustment (EquityPriceHistoricalAdjustmentType0 | EquityPriceHistoricalAdjustmentType1 |
            EquityPriceHistoricalAdjustmentType2 | Unset): Type of adjustment for historical prices.
            Only applies to daily data. (provider: fmp);
                The adjustment factor to apply. Default is splits only. (provider: polygon);
                The adjustment factor to apply. Default is splits only. (provider: yfinance) Default:
            EquityPriceHistoricalAdjustmentType0.SPLITS_ONLY.
        start_time (None | str | Unset): Return intervals starting at the specified time on the
            `start_date` formatted as 'HH:MM:SS'. (provider: intrinio)
        end_time (None | str | Unset): Return intervals stopping at the specified time on the
            `end_date` formatted as 'HH:MM:SS'. (provider: intrinio)
        timezone (None | str | Unset): Timezone of the data, in the IANA format (Continent/City).
            (provider: intrinio) Default: 'America/New_York'.
        source (EquityPriceHistoricalIntrinio | Unset): The source of the data. (provider:
            intrinio) Default: EquityPriceHistoricalIntrinio.REALTIME.
        extended_hours (bool | Unset): Include Pre and Post market data. (provider: polygon,
            yfinance) Default: False.
        sort (EquityPriceHistoricalPolygon | Unset): Sort order of the data. This impacts the
            results in combination with the 'limit' parameter. The results are always returned in
            ascending order by date. (provider: polygon) Default: EquityPriceHistoricalPolygon.ASC.
        limit (int | Unset): The number of data entries to return. (provider: polygon) Default:
            49999.
        include_actions (bool | Unset): Include dividends and stock splits in results. (provider:
            yfinance) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEquityHistorical | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        period=period,
        use_cache=use_cache,
        interval=interval,
        adjustment=adjustment,
        start_time=start_time,
        end_time=end_time,
        timezone=timezone,
        source=source,
        extended_hours=extended_hours,
        sort=sort,
        limit=limit,
        include_actions=include_actions,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityPriceHistoricalProvider,
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    period: EquityPriceHistoricalAkshare | Unset = EquityPriceHistoricalAkshare.DAILY,
    use_cache: bool | Unset = True,
    interval: EquityPriceHistoricalIntervalType0
    | EquityPriceHistoricalIntervalType1
    | EquityPriceHistoricalIntervalType3
    | EquityPriceHistoricalIntervalType4
    | str
    | Unset = EquityPriceHistoricalIntervalType0.VALUE_6,
    adjustment: EquityPriceHistoricalAdjustmentType0
    | EquityPriceHistoricalAdjustmentType1
    | EquityPriceHistoricalAdjustmentType2
    | Unset = EquityPriceHistoricalAdjustmentType0.SPLITS_ONLY,
    start_time: None | str | Unset = UNSET,
    end_time: None | str | Unset = UNSET,
    timezone: None | str | Unset = "America/New_York",
    source: EquityPriceHistoricalIntrinio | Unset = EquityPriceHistoricalIntrinio.REALTIME,
    extended_hours: bool | Unset = False,
    sort: EquityPriceHistoricalPolygon | Unset = EquityPriceHistoricalPolygon.ASC,
    limit: int | Unset = 49999,
    include_actions: bool | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectEquityHistorical | OpenBBErrorResponse]:
    """Historical

     Get historical price data for a given stock. This includes open, high, low, close, and volume.

    Args:
        provider (EquityPriceHistoricalProvider):
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): akshare, fmp, polygon, tiingo, yfinance.;
                A Security identifier (Ticker, FIGI, ISIN, CUSIP, Intrinio ID). (provider: intrinio)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        period (EquityPriceHistoricalAkshare | Unset): Time period of the data to return.
            (provider: akshare) Default: EquityPriceHistoricalAkshare.DAILY.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        interval (EquityPriceHistoricalIntervalType0 | EquityPriceHistoricalIntervalType1 |
            EquityPriceHistoricalIntervalType3 | EquityPriceHistoricalIntervalType4 | str | Unset):
            Time interval of the data to return. (provider: fmp,intrinio,polygon,tiingo, yfinance)
            Default: EquityPriceHistoricalIntervalType0.VALUE_6.
        adjustment (EquityPriceHistoricalAdjustmentType0 | EquityPriceHistoricalAdjustmentType1 |
            EquityPriceHistoricalAdjustmentType2 | Unset): Type of adjustment for historical prices.
            Only applies to daily data. (provider: fmp);
                The adjustment factor to apply. Default is splits only. (provider: polygon);
                The adjustment factor to apply. Default is splits only. (provider: yfinance) Default:
            EquityPriceHistoricalAdjustmentType0.SPLITS_ONLY.
        start_time (None | str | Unset): Return intervals starting at the specified time on the
            `start_date` formatted as 'HH:MM:SS'. (provider: intrinio)
        end_time (None | str | Unset): Return intervals stopping at the specified time on the
            `end_date` formatted as 'HH:MM:SS'. (provider: intrinio)
        timezone (None | str | Unset): Timezone of the data, in the IANA format (Continent/City).
            (provider: intrinio) Default: 'America/New_York'.
        source (EquityPriceHistoricalIntrinio | Unset): The source of the data. (provider:
            intrinio) Default: EquityPriceHistoricalIntrinio.REALTIME.
        extended_hours (bool | Unset): Include Pre and Post market data. (provider: polygon,
            yfinance) Default: False.
        sort (EquityPriceHistoricalPolygon | Unset): Sort order of the data. This impacts the
            results in combination with the 'limit' parameter. The results are always returned in
            ascending order by date. (provider: polygon) Default: EquityPriceHistoricalPolygon.ASC.
        limit (int | Unset): The number of data entries to return. (provider: polygon) Default:
            49999.
        include_actions (bool | Unset): Include dividends and stock splits in results. (provider:
            yfinance) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEquityHistorical | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        period=period,
        use_cache=use_cache,
        interval=interval,
        adjustment=adjustment,
        start_time=start_time,
        end_time=end_time,
        timezone=timezone,
        source=source,
        extended_hours=extended_hours,
        sort=sort,
        limit=limit,
        include_actions=include_actions,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityPriceHistoricalProvider,
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    period: EquityPriceHistoricalAkshare | Unset = EquityPriceHistoricalAkshare.DAILY,
    use_cache: bool | Unset = True,
    interval: EquityPriceHistoricalIntervalType0
    | EquityPriceHistoricalIntervalType1
    | EquityPriceHistoricalIntervalType3
    | EquityPriceHistoricalIntervalType4
    | str
    | Unset = EquityPriceHistoricalIntervalType0.VALUE_6,
    adjustment: EquityPriceHistoricalAdjustmentType0
    | EquityPriceHistoricalAdjustmentType1
    | EquityPriceHistoricalAdjustmentType2
    | Unset = EquityPriceHistoricalAdjustmentType0.SPLITS_ONLY,
    start_time: None | str | Unset = UNSET,
    end_time: None | str | Unset = UNSET,
    timezone: None | str | Unset = "America/New_York",
    source: EquityPriceHistoricalIntrinio | Unset = EquityPriceHistoricalIntrinio.REALTIME,
    extended_hours: bool | Unset = False,
    sort: EquityPriceHistoricalPolygon | Unset = EquityPriceHistoricalPolygon.ASC,
    limit: int | Unset = 49999,
    include_actions: bool | Unset = True,
) -> Any | HTTPValidationError | OBBjectEquityHistorical | OpenBBErrorResponse | None:
    """Historical

     Get historical price data for a given stock. This includes open, high, low, close, and volume.

    Args:
        provider (EquityPriceHistoricalProvider):
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): akshare, fmp, polygon, tiingo, yfinance.;
                A Security identifier (Ticker, FIGI, ISIN, CUSIP, Intrinio ID). (provider: intrinio)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        period (EquityPriceHistoricalAkshare | Unset): Time period of the data to return.
            (provider: akshare) Default: EquityPriceHistoricalAkshare.DAILY.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        interval (EquityPriceHistoricalIntervalType0 | EquityPriceHistoricalIntervalType1 |
            EquityPriceHistoricalIntervalType3 | EquityPriceHistoricalIntervalType4 | str | Unset):
            Time interval of the data to return. (provider: fmp,intrinio,polygon,tiingo, yfinance)
            Default: EquityPriceHistoricalIntervalType0.VALUE_6.
        adjustment (EquityPriceHistoricalAdjustmentType0 | EquityPriceHistoricalAdjustmentType1 |
            EquityPriceHistoricalAdjustmentType2 | Unset): Type of adjustment for historical prices.
            Only applies to daily data. (provider: fmp);
                The adjustment factor to apply. Default is splits only. (provider: polygon);
                The adjustment factor to apply. Default is splits only. (provider: yfinance) Default:
            EquityPriceHistoricalAdjustmentType0.SPLITS_ONLY.
        start_time (None | str | Unset): Return intervals starting at the specified time on the
            `start_date` formatted as 'HH:MM:SS'. (provider: intrinio)
        end_time (None | str | Unset): Return intervals stopping at the specified time on the
            `end_date` formatted as 'HH:MM:SS'. (provider: intrinio)
        timezone (None | str | Unset): Timezone of the data, in the IANA format (Continent/City).
            (provider: intrinio) Default: 'America/New_York'.
        source (EquityPriceHistoricalIntrinio | Unset): The source of the data. (provider:
            intrinio) Default: EquityPriceHistoricalIntrinio.REALTIME.
        extended_hours (bool | Unset): Include Pre and Post market data. (provider: polygon,
            yfinance) Default: False.
        sort (EquityPriceHistoricalPolygon | Unset): Sort order of the data. This impacts the
            results in combination with the 'limit' parameter. The results are always returned in
            ascending order by date. (provider: polygon) Default: EquityPriceHistoricalPolygon.ASC.
        limit (int | Unset): The number of data entries to return. (provider: polygon) Default:
            49999.
        include_actions (bool | Unset): Include dividends and stock splits in results. (provider:
            yfinance) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEquityHistorical | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            start_date=start_date,
            end_date=end_date,
            period=period,
            use_cache=use_cache,
            interval=interval,
            adjustment=adjustment,
            start_time=start_time,
            end_time=end_time,
            timezone=timezone,
            source=source,
            extended_hours=extended_hours,
            sort=sort,
            limit=limit,
            include_actions=include_actions,
        )
    ).parsed
