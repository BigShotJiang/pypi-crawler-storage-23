import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_fundamental_historical_attributes_frequency_type_0 import (
    EquityFundamentalHistoricalAttributesFrequencyType0,
)
from ...models.equity_fundamental_historical_attributes_sort_type_0 import (
    EquityFundamentalHistoricalAttributesSortType0,
)
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_historical_attributes import OBBjectHistoricalAttributes
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: str,
    tag: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: EquityFundamentalHistoricalAttributesFrequencyType0
    | None
    | Unset = EquityFundamentalHistoricalAttributesFrequencyType0.YEARLY,
    limit: int | None | Unset = 1000,
    tag_type: None | str | Unset = UNSET,
    sort: EquityFundamentalHistoricalAttributesSortType0
    | None
    | Unset = EquityFundamentalHistoricalAttributesSortType0.DESC,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["symbol"] = symbol

    params["tag"] = tag

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_frequency: None | str | Unset
    if isinstance(frequency, Unset):
        json_frequency = UNSET
    elif isinstance(frequency, EquityFundamentalHistoricalAttributesFrequencyType0):
        json_frequency = frequency.value
    else:
        json_frequency = frequency
    params["frequency"] = json_frequency

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_tag_type: None | str | Unset
    if isinstance(tag_type, Unset):
        json_tag_type = UNSET
    else:
        json_tag_type = tag_type
    params["tag_type"] = json_tag_type

    json_sort: None | str | Unset
    if isinstance(sort, Unset):
        json_sort = UNSET
    elif isinstance(sort, EquityFundamentalHistoricalAttributesSortType0):
        json_sort = sort.value
    else:
        json_sort = sort
    params["sort"] = json_sort

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/fundamental/historical_attributes",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectHistoricalAttributes | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectHistoricalAttributes.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectHistoricalAttributes | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: str,
    tag: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: EquityFundamentalHistoricalAttributesFrequencyType0
    | None
    | Unset = EquityFundamentalHistoricalAttributesFrequencyType0.YEARLY,
    limit: int | None | Unset = 1000,
    tag_type: None | str | Unset = UNSET,
    sort: EquityFundamentalHistoricalAttributesSortType0
    | None
    | Unset = EquityFundamentalHistoricalAttributesSortType0.DESC,
) -> Response[Any | HTTPValidationError | OBBjectHistoricalAttributes | OpenBBErrorResponse]:
    """Historical Attributes

     Get the historical values of a data tag from Intrinio.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): intrinio.
        tag (str): Intrinio data tag ID or code. Multiple comma separated items allowed for
            provider(s): intrinio.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        frequency (EquityFundamentalHistoricalAttributesFrequencyType0 | None | Unset): The
            frequency of the data. Default:
            EquityFundamentalHistoricalAttributesFrequencyType0.YEARLY.
        limit (int | None | Unset): The number of data entries to return. Default: 1000.
        tag_type (None | str | Unset): Filter by type, when applicable.
        sort (EquityFundamentalHistoricalAttributesSortType0 | None | Unset): Sort order. Default:
            EquityFundamentalHistoricalAttributesSortType0.DESC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectHistoricalAttributes | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        tag=tag,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        limit=limit,
        tag_type=tag_type,
        sort=sort,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: str,
    tag: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: EquityFundamentalHistoricalAttributesFrequencyType0
    | None
    | Unset = EquityFundamentalHistoricalAttributesFrequencyType0.YEARLY,
    limit: int | None | Unset = 1000,
    tag_type: None | str | Unset = UNSET,
    sort: EquityFundamentalHistoricalAttributesSortType0
    | None
    | Unset = EquityFundamentalHistoricalAttributesSortType0.DESC,
) -> Any | HTTPValidationError | OBBjectHistoricalAttributes | OpenBBErrorResponse | None:
    """Historical Attributes

     Get the historical values of a data tag from Intrinio.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): intrinio.
        tag (str): Intrinio data tag ID or code. Multiple comma separated items allowed for
            provider(s): intrinio.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        frequency (EquityFundamentalHistoricalAttributesFrequencyType0 | None | Unset): The
            frequency of the data. Default:
            EquityFundamentalHistoricalAttributesFrequencyType0.YEARLY.
        limit (int | None | Unset): The number of data entries to return. Default: 1000.
        tag_type (None | str | Unset): Filter by type, when applicable.
        sort (EquityFundamentalHistoricalAttributesSortType0 | None | Unset): Sort order. Default:
            EquityFundamentalHistoricalAttributesSortType0.DESC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectHistoricalAttributes | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        tag=tag,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        limit=limit,
        tag_type=tag_type,
        sort=sort,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: str,
    tag: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: EquityFundamentalHistoricalAttributesFrequencyType0
    | None
    | Unset = EquityFundamentalHistoricalAttributesFrequencyType0.YEARLY,
    limit: int | None | Unset = 1000,
    tag_type: None | str | Unset = UNSET,
    sort: EquityFundamentalHistoricalAttributesSortType0
    | None
    | Unset = EquityFundamentalHistoricalAttributesSortType0.DESC,
) -> Response[Any | HTTPValidationError | OBBjectHistoricalAttributes | OpenBBErrorResponse]:
    """Historical Attributes

     Get the historical values of a data tag from Intrinio.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): intrinio.
        tag (str): Intrinio data tag ID or code. Multiple comma separated items allowed for
            provider(s): intrinio.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        frequency (EquityFundamentalHistoricalAttributesFrequencyType0 | None | Unset): The
            frequency of the data. Default:
            EquityFundamentalHistoricalAttributesFrequencyType0.YEARLY.
        limit (int | None | Unset): The number of data entries to return. Default: 1000.
        tag_type (None | str | Unset): Filter by type, when applicable.
        sort (EquityFundamentalHistoricalAttributesSortType0 | None | Unset): Sort order. Default:
            EquityFundamentalHistoricalAttributesSortType0.DESC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectHistoricalAttributes | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        tag=tag,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        limit=limit,
        tag_type=tag_type,
        sort=sort,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: str,
    tag: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: EquityFundamentalHistoricalAttributesFrequencyType0
    | None
    | Unset = EquityFundamentalHistoricalAttributesFrequencyType0.YEARLY,
    limit: int | None | Unset = 1000,
    tag_type: None | str | Unset = UNSET,
    sort: EquityFundamentalHistoricalAttributesSortType0
    | None
    | Unset = EquityFundamentalHistoricalAttributesSortType0.DESC,
) -> Any | HTTPValidationError | OBBjectHistoricalAttributes | OpenBBErrorResponse | None:
    """Historical Attributes

     Get the historical values of a data tag from Intrinio.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): intrinio.
        tag (str): Intrinio data tag ID or code. Multiple comma separated items allowed for
            provider(s): intrinio.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        frequency (EquityFundamentalHistoricalAttributesFrequencyType0 | None | Unset): The
            frequency of the data. Default:
            EquityFundamentalHistoricalAttributesFrequencyType0.YEARLY.
        limit (int | None | Unset): The number of data entries to return. Default: 1000.
        tag_type (None | str | Unset): Filter by type, when applicable.
        sort (EquityFundamentalHistoricalAttributesSortType0 | None | Unset): Sort order. Default:
            EquityFundamentalHistoricalAttributesSortType0.DESC.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectHistoricalAttributes | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            tag=tag,
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            limit=limit,
            tag_type=tag_type,
            sort=sort,
        )
    ).parsed
