import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_latest_financial_reports import OBBjectLatestFinancialReports
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["sec"] | Unset = "sec",
    date: datetime.date | None | Unset = UNSET,
    report_type: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_date: None | str | Unset
    if isinstance(date, Unset):
        json_date = UNSET
    elif isinstance(date, datetime.date):
        json_date = date.isoformat()
    else:
        json_date = date
    params["date"] = json_date

    json_report_type: None | str | Unset
    if isinstance(report_type, Unset):
        json_report_type = UNSET
    else:
        json_report_type = report_type
    params["report_type"] = json_report_type

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/discovery/latest_financial_reports",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectLatestFinancialReports | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectLatestFinancialReports.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectLatestFinancialReports | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    date: datetime.date | None | Unset = UNSET,
    report_type: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectLatestFinancialReports | OpenBBErrorResponse]:
    """Latest Financial Reports

     Get the newest quarterly, annual, and current reports for all companies.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        date (datetime.date | None | Unset): A specific date to get data for. Defaults to today.
            (provider: sec)
        report_type (None | str | Unset): Return only a specific form type. Default is all
            quarterly, annual, and current reports. Choices: 1-K, 1-SA, 1-U, 10-D, 10-K, 10-KT, 10-Q,
            10-QT, 20-F, 40-F, 6-K, 8-K. Multiple comma separated items allowed. (provider: sec)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectLatestFinancialReports | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        date=date,
        report_type=report_type,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    date: datetime.date | None | Unset = UNSET,
    report_type: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectLatestFinancialReports | OpenBBErrorResponse | None:
    """Latest Financial Reports

     Get the newest quarterly, annual, and current reports for all companies.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        date (datetime.date | None | Unset): A specific date to get data for. Defaults to today.
            (provider: sec)
        report_type (None | str | Unset): Return only a specific form type. Default is all
            quarterly, annual, and current reports. Choices: 1-K, 1-SA, 1-U, 10-D, 10-K, 10-KT, 10-Q,
            10-QT, 20-F, 40-F, 6-K, 8-K. Multiple comma separated items allowed. (provider: sec)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectLatestFinancialReports | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        date=date,
        report_type=report_type,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    date: datetime.date | None | Unset = UNSET,
    report_type: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectLatestFinancialReports | OpenBBErrorResponse]:
    """Latest Financial Reports

     Get the newest quarterly, annual, and current reports for all companies.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        date (datetime.date | None | Unset): A specific date to get data for. Defaults to today.
            (provider: sec)
        report_type (None | str | Unset): Return only a specific form type. Default is all
            quarterly, annual, and current reports. Choices: 1-K, 1-SA, 1-U, 10-D, 10-K, 10-KT, 10-Q,
            10-QT, 20-F, 40-F, 6-K, 8-K. Multiple comma separated items allowed. (provider: sec)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectLatestFinancialReports | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        date=date,
        report_type=report_type,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    date: datetime.date | None | Unset = UNSET,
    report_type: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectLatestFinancialReports | OpenBBErrorResponse | None:
    """Latest Financial Reports

     Get the newest quarterly, annual, and current reports for all companies.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        date (datetime.date | None | Unset): A specific date to get data for. Defaults to today.
            (provider: sec)
        report_type (None | str | Unset): Return only a specific form type. Default is all
            quarterly, annual, and current reports. Choices: 1-K, 1-SA, 1-U, 10-D, 10-K, 10-KT, 10-Q,
            10-QT, 20-F, 40-F, 6-K, 8-K. Multiple comma separated items allowed. (provider: sec)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectLatestFinancialReports | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            date=date,
            report_type=report_type,
        )
    ).parsed
