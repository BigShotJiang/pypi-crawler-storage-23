from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_revenue_business_line import OBBjectRevenueBusinessLine
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    period: str | Unset = "annual",
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["symbol"] = symbol

    params["period"] = period

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/fundamental/revenue_per_segment",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectRevenueBusinessLine | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectRevenueBusinessLine.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectRevenueBusinessLine | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    period: str | Unset = "annual",
) -> Response[Any | HTTPValidationError | OBBjectRevenueBusinessLine | OpenBBErrorResponse]:
    """Revenue Per Segment

     Get the revenue breakdown by business segment for a given company over time.

    Args:
        provider (Literal['fmp'] | Unset):  Default: 'fmp'.
        symbol (str): Symbol to get data for.
        period (str | Unset): Time period of the data to return. (provider: fmp) Default:
            'annual'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectRevenueBusinessLine | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        period=period,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    period: str | Unset = "annual",
) -> Any | HTTPValidationError | OBBjectRevenueBusinessLine | OpenBBErrorResponse | None:
    """Revenue Per Segment

     Get the revenue breakdown by business segment for a given company over time.

    Args:
        provider (Literal['fmp'] | Unset):  Default: 'fmp'.
        symbol (str): Symbol to get data for.
        period (str | Unset): Time period of the data to return. (provider: fmp) Default:
            'annual'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectRevenueBusinessLine | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        period=period,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    period: str | Unset = "annual",
) -> Response[Any | HTTPValidationError | OBBjectRevenueBusinessLine | OpenBBErrorResponse]:
    """Revenue Per Segment

     Get the revenue breakdown by business segment for a given company over time.

    Args:
        provider (Literal['fmp'] | Unset):  Default: 'fmp'.
        symbol (str): Symbol to get data for.
        period (str | Unset): Time period of the data to return. (provider: fmp) Default:
            'annual'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectRevenueBusinessLine | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        period=period,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fmp"] | Unset = "fmp",
    symbol: str,
    period: str | Unset = "annual",
) -> Any | HTTPValidationError | OBBjectRevenueBusinessLine | OpenBBErrorResponse | None:
    """Revenue Per Segment

     Get the revenue breakdown by business segment for a given company over time.

    Args:
        provider (Literal['fmp'] | Unset):  Default: 'fmp'.
        symbol (str): Symbol to get data for.
        period (str | Unset): Time period of the data to return. (provider: fmp) Default:
            'annual'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectRevenueBusinessLine | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            period=period,
        )
    ).parsed
