from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.body_derivatives_options_surface import BodyDerivativesOptionsSurface
from ...models.derivatives_options_surface_option_type_type_0 import DerivativesOptionsSurfaceOptionTypeType0
from ...models.derivatives_options_surface_theme import DerivativesOptionsSurfaceTheme
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_t import OBBjectT
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: BodyDerivativesOptionsSurface,
    target: str | Unset = "implied_volatility",
    underlying_price: float | None | Unset = UNSET,
    option_type: DerivativesOptionsSurfaceOptionTypeType0 | None | Unset = DerivativesOptionsSurfaceOptionTypeType0.OTM,
    dte_min: int | None | Unset = UNSET,
    dte_max: int | None | Unset = UNSET,
    moneyness: float | None | Unset = UNSET,
    strike_min: float | None | Unset = UNSET,
    strike_max: float | None | Unset = UNSET,
    oi: bool | Unset = False,
    volume: bool | Unset = False,
    theme: DerivativesOptionsSurfaceTheme | Unset = DerivativesOptionsSurfaceTheme.DARK,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["target"] = target

    json_underlying_price: float | None | Unset
    if isinstance(underlying_price, Unset):
        json_underlying_price = UNSET
    else:
        json_underlying_price = underlying_price
    params["underlying_price"] = json_underlying_price

    json_option_type: None | str | Unset
    if isinstance(option_type, Unset):
        json_option_type = UNSET
    elif isinstance(option_type, DerivativesOptionsSurfaceOptionTypeType0):
        json_option_type = option_type.value
    else:
        json_option_type = option_type
    params["option_type"] = json_option_type

    json_dte_min: int | None | Unset
    if isinstance(dte_min, Unset):
        json_dte_min = UNSET
    else:
        json_dte_min = dte_min
    params["dte_min"] = json_dte_min

    json_dte_max: int | None | Unset
    if isinstance(dte_max, Unset):
        json_dte_max = UNSET
    else:
        json_dte_max = dte_max
    params["dte_max"] = json_dte_max

    json_moneyness: float | None | Unset
    if isinstance(moneyness, Unset):
        json_moneyness = UNSET
    else:
        json_moneyness = moneyness
    params["moneyness"] = json_moneyness

    json_strike_min: float | None | Unset
    if isinstance(strike_min, Unset):
        json_strike_min = UNSET
    else:
        json_strike_min = strike_min
    params["strike_min"] = json_strike_min

    json_strike_max: float | None | Unset
    if isinstance(strike_max, Unset):
        json_strike_max = UNSET
    else:
        json_strike_max = strike_max
    params["strike_max"] = json_strike_max

    params["oi"] = oi

    params["volume"] = volume

    json_theme: str | Unset = UNSET
    if not isinstance(theme, Unset):
        json_theme = theme.value

    params["theme"] = json_theme

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/derivatives/options/surface",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectT | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectT.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectT | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: BodyDerivativesOptionsSurface,
    target: str | Unset = "implied_volatility",
    underlying_price: float | None | Unset = UNSET,
    option_type: DerivativesOptionsSurfaceOptionTypeType0 | None | Unset = DerivativesOptionsSurfaceOptionTypeType0.OTM,
    dte_min: int | None | Unset = UNSET,
    dte_max: int | None | Unset = UNSET,
    moneyness: float | None | Unset = UNSET,
    strike_min: float | None | Unset = UNSET,
    strike_max: float | None | Unset = UNSET,
    oi: bool | Unset = False,
    volume: bool | Unset = False,
    theme: DerivativesOptionsSurfaceTheme | Unset = DerivativesOptionsSurfaceTheme.DARK,
) -> Response[Any | HTTPValidationError | OBBjectT | OpenBBErrorResponse]:
    """Surface

     Filter and process the options chains data for volatility.

    Data posted can be an instance of OptionsChainsData,
    a pandas DataFrame, or a list of dictionaries.
    Data should contain the fields:

    - `expiration`: The expiration date of the option.
    - `strike`: The strike price of the option.
    - `option_type`: The type of the option (call or put).
    - `implied_volatility`: The implied volatility of the option. Or 'target' field.
    - `open_interest`: The open interest of the option.
    - `volume`: The trading volume of the option.
    - `dte` : Optional, days to expiration (DTE) of the option.
    - `underlying_price`: Optional, the price of the underlying asset.

    Results from the `/derivatives/options/chains` endpoint are the preferred input.

    If `underlying_price` is not supplied in the data as a field, it must be provided as a parameter.

    Args:
        target (str | Unset):  Default: 'implied_volatility'.
        underlying_price (float | None | Unset):
        option_type (DerivativesOptionsSurfaceOptionTypeType0 | None | Unset):  Default:
            DerivativesOptionsSurfaceOptionTypeType0.OTM.
        dte_min (int | None | Unset):
        dte_max (int | None | Unset):
        moneyness (float | None | Unset):
        strike_min (float | None | Unset):
        strike_max (float | None | Unset):
        oi (bool | Unset):  Default: False.
        volume (bool | Unset):  Default: False.
        theme (DerivativesOptionsSurfaceTheme | Unset):  Default:
            DerivativesOptionsSurfaceTheme.DARK.
        body (BodyDerivativesOptionsSurface):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectT | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        target=target,
        underlying_price=underlying_price,
        option_type=option_type,
        dte_min=dte_min,
        dte_max=dte_max,
        moneyness=moneyness,
        strike_min=strike_min,
        strike_max=strike_max,
        oi=oi,
        volume=volume,
        theme=theme,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: BodyDerivativesOptionsSurface,
    target: str | Unset = "implied_volatility",
    underlying_price: float | None | Unset = UNSET,
    option_type: DerivativesOptionsSurfaceOptionTypeType0 | None | Unset = DerivativesOptionsSurfaceOptionTypeType0.OTM,
    dte_min: int | None | Unset = UNSET,
    dte_max: int | None | Unset = UNSET,
    moneyness: float | None | Unset = UNSET,
    strike_min: float | None | Unset = UNSET,
    strike_max: float | None | Unset = UNSET,
    oi: bool | Unset = False,
    volume: bool | Unset = False,
    theme: DerivativesOptionsSurfaceTheme | Unset = DerivativesOptionsSurfaceTheme.DARK,
) -> Any | HTTPValidationError | OBBjectT | OpenBBErrorResponse | None:
    """Surface

     Filter and process the options chains data for volatility.

    Data posted can be an instance of OptionsChainsData,
    a pandas DataFrame, or a list of dictionaries.
    Data should contain the fields:

    - `expiration`: The expiration date of the option.
    - `strike`: The strike price of the option.
    - `option_type`: The type of the option (call or put).
    - `implied_volatility`: The implied volatility of the option. Or 'target' field.
    - `open_interest`: The open interest of the option.
    - `volume`: The trading volume of the option.
    - `dte` : Optional, days to expiration (DTE) of the option.
    - `underlying_price`: Optional, the price of the underlying asset.

    Results from the `/derivatives/options/chains` endpoint are the preferred input.

    If `underlying_price` is not supplied in the data as a field, it must be provided as a parameter.

    Args:
        target (str | Unset):  Default: 'implied_volatility'.
        underlying_price (float | None | Unset):
        option_type (DerivativesOptionsSurfaceOptionTypeType0 | None | Unset):  Default:
            DerivativesOptionsSurfaceOptionTypeType0.OTM.
        dte_min (int | None | Unset):
        dte_max (int | None | Unset):
        moneyness (float | None | Unset):
        strike_min (float | None | Unset):
        strike_max (float | None | Unset):
        oi (bool | Unset):  Default: False.
        volume (bool | Unset):  Default: False.
        theme (DerivativesOptionsSurfaceTheme | Unset):  Default:
            DerivativesOptionsSurfaceTheme.DARK.
        body (BodyDerivativesOptionsSurface):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectT | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        target=target,
        underlying_price=underlying_price,
        option_type=option_type,
        dte_min=dte_min,
        dte_max=dte_max,
        moneyness=moneyness,
        strike_min=strike_min,
        strike_max=strike_max,
        oi=oi,
        volume=volume,
        theme=theme,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: BodyDerivativesOptionsSurface,
    target: str | Unset = "implied_volatility",
    underlying_price: float | None | Unset = UNSET,
    option_type: DerivativesOptionsSurfaceOptionTypeType0 | None | Unset = DerivativesOptionsSurfaceOptionTypeType0.OTM,
    dte_min: int | None | Unset = UNSET,
    dte_max: int | None | Unset = UNSET,
    moneyness: float | None | Unset = UNSET,
    strike_min: float | None | Unset = UNSET,
    strike_max: float | None | Unset = UNSET,
    oi: bool | Unset = False,
    volume: bool | Unset = False,
    theme: DerivativesOptionsSurfaceTheme | Unset = DerivativesOptionsSurfaceTheme.DARK,
) -> Response[Any | HTTPValidationError | OBBjectT | OpenBBErrorResponse]:
    """Surface

     Filter and process the options chains data for volatility.

    Data posted can be an instance of OptionsChainsData,
    a pandas DataFrame, or a list of dictionaries.
    Data should contain the fields:

    - `expiration`: The expiration date of the option.
    - `strike`: The strike price of the option.
    - `option_type`: The type of the option (call or put).
    - `implied_volatility`: The implied volatility of the option. Or 'target' field.
    - `open_interest`: The open interest of the option.
    - `volume`: The trading volume of the option.
    - `dte` : Optional, days to expiration (DTE) of the option.
    - `underlying_price`: Optional, the price of the underlying asset.

    Results from the `/derivatives/options/chains` endpoint are the preferred input.

    If `underlying_price` is not supplied in the data as a field, it must be provided as a parameter.

    Args:
        target (str | Unset):  Default: 'implied_volatility'.
        underlying_price (float | None | Unset):
        option_type (DerivativesOptionsSurfaceOptionTypeType0 | None | Unset):  Default:
            DerivativesOptionsSurfaceOptionTypeType0.OTM.
        dte_min (int | None | Unset):
        dte_max (int | None | Unset):
        moneyness (float | None | Unset):
        strike_min (float | None | Unset):
        strike_max (float | None | Unset):
        oi (bool | Unset):  Default: False.
        volume (bool | Unset):  Default: False.
        theme (DerivativesOptionsSurfaceTheme | Unset):  Default:
            DerivativesOptionsSurfaceTheme.DARK.
        body (BodyDerivativesOptionsSurface):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectT | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        target=target,
        underlying_price=underlying_price,
        option_type=option_type,
        dte_min=dte_min,
        dte_max=dte_max,
        moneyness=moneyness,
        strike_min=strike_min,
        strike_max=strike_max,
        oi=oi,
        volume=volume,
        theme=theme,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: BodyDerivativesOptionsSurface,
    target: str | Unset = "implied_volatility",
    underlying_price: float | None | Unset = UNSET,
    option_type: DerivativesOptionsSurfaceOptionTypeType0 | None | Unset = DerivativesOptionsSurfaceOptionTypeType0.OTM,
    dte_min: int | None | Unset = UNSET,
    dte_max: int | None | Unset = UNSET,
    moneyness: float | None | Unset = UNSET,
    strike_min: float | None | Unset = UNSET,
    strike_max: float | None | Unset = UNSET,
    oi: bool | Unset = False,
    volume: bool | Unset = False,
    theme: DerivativesOptionsSurfaceTheme | Unset = DerivativesOptionsSurfaceTheme.DARK,
) -> Any | HTTPValidationError | OBBjectT | OpenBBErrorResponse | None:
    """Surface

     Filter and process the options chains data for volatility.

    Data posted can be an instance of OptionsChainsData,
    a pandas DataFrame, or a list of dictionaries.
    Data should contain the fields:

    - `expiration`: The expiration date of the option.
    - `strike`: The strike price of the option.
    - `option_type`: The type of the option (call or put).
    - `implied_volatility`: The implied volatility of the option. Or 'target' field.
    - `open_interest`: The open interest of the option.
    - `volume`: The trading volume of the option.
    - `dte` : Optional, days to expiration (DTE) of the option.
    - `underlying_price`: Optional, the price of the underlying asset.

    Results from the `/derivatives/options/chains` endpoint are the preferred input.

    If `underlying_price` is not supplied in the data as a field, it must be provided as a parameter.

    Args:
        target (str | Unset):  Default: 'implied_volatility'.
        underlying_price (float | None | Unset):
        option_type (DerivativesOptionsSurfaceOptionTypeType0 | None | Unset):  Default:
            DerivativesOptionsSurfaceOptionTypeType0.OTM.
        dte_min (int | None | Unset):
        dte_max (int | None | Unset):
        moneyness (float | None | Unset):
        strike_min (float | None | Unset):
        strike_max (float | None | Unset):
        oi (bool | Unset):  Default: False.
        volume (bool | Unset):  Default: False.
        theme (DerivativesOptionsSurfaceTheme | Unset):  Default:
            DerivativesOptionsSurfaceTheme.DARK.
        body (BodyDerivativesOptionsSurface):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectT | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            target=target,
            underlying_price=underlying_price,
            option_type=option_type,
            dte_min=dte_min,
            dte_max=dte_max,
            moneyness=moneyness,
            strike_min=strike_min,
            strike_max=strike_max,
            oi=oi,
            volume=volume,
            theme=theme,
        )
    ).parsed
