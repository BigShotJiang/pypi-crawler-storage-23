import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.derivatives_options_unusual_sentiment_type_0 import DerivativesOptionsUnusualSentimentType0
from ...models.derivatives_options_unusual_trade_type_type_0 import DerivativesOptionsUnusualTradeTypeType0
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_options_unusual import OBBjectOptionsUnusual
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    trade_type: DerivativesOptionsUnusualTradeTypeType0 | None | Unset = UNSET,
    sentiment: DerivativesOptionsUnusualSentimentType0 | None | Unset = UNSET,
    min_value: float | int | None | Unset = UNSET,
    max_value: float | int | None | Unset = UNSET,
    limit: int | Unset = 100000,
    source: str | Unset = "delayed",
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_symbol: None | str | Unset
    if isinstance(symbol, Unset):
        json_symbol = UNSET
    else:
        json_symbol = symbol
    params["symbol"] = json_symbol

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_trade_type: None | str | Unset
    if isinstance(trade_type, Unset):
        json_trade_type = UNSET
    elif isinstance(trade_type, DerivativesOptionsUnusualTradeTypeType0):
        json_trade_type = trade_type.value
    else:
        json_trade_type = trade_type
    params["trade_type"] = json_trade_type

    json_sentiment: None | str | Unset
    if isinstance(sentiment, Unset):
        json_sentiment = UNSET
    elif isinstance(sentiment, DerivativesOptionsUnusualSentimentType0):
        json_sentiment = sentiment.value
    else:
        json_sentiment = sentiment
    params["sentiment"] = json_sentiment

    json_min_value: float | int | None | Unset
    if isinstance(min_value, Unset):
        json_min_value = UNSET
    else:
        json_min_value = min_value
    params["min_value"] = json_min_value

    json_max_value: float | int | None | Unset
    if isinstance(max_value, Unset):
        json_max_value = UNSET
    else:
        json_max_value = max_value
    params["max_value"] = json_max_value

    params["limit"] = limit

    params["source"] = source

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/derivatives/options/unusual",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectOptionsUnusual | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectOptionsUnusual.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectOptionsUnusual | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    trade_type: DerivativesOptionsUnusualTradeTypeType0 | None | Unset = UNSET,
    sentiment: DerivativesOptionsUnusualSentimentType0 | None | Unset = UNSET,
    min_value: float | int | None | Unset = UNSET,
    max_value: float | int | None | Unset = UNSET,
    limit: int | Unset = 100000,
    source: str | Unset = "delayed",
) -> Response[Any | HTTPValidationError | OBBjectOptionsUnusual | OpenBBErrorResponse]:
    """Unusual

     Get the complete options chain for a ticker.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (None | str | Unset): Symbol to get data for. (the underlying symbol)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            If no symbol is supplied, requests are only allowed for a single date. Use the start_date
            for the target date. Intrinio appears to have data beginning Feb/2022, but is unclear when
            it actually began. (provider: intrinio)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format. If a
            symbol is not supplied, do not include an end date. (provider: intrinio)
        trade_type (DerivativesOptionsUnusualTradeTypeType0 | None | Unset): The type of unusual
            activity to query for. (provider: intrinio)
        sentiment (DerivativesOptionsUnusualSentimentType0 | None | Unset): The sentiment type to
            query for. (provider: intrinio)
        min_value (float | int | None | Unset): The inclusive minimum total value for the unusual
            activity. (provider: intrinio)
        max_value (float | int | None | Unset): The inclusive maximum total value for the unusual
            activity. (provider: intrinio)
        limit (int | Unset): The number of data entries to return. A typical day for all symbols
            will yield 50-80K records. The API will paginate at 1000 records. The high default limit
            (100K) is to be able to reliably capture the most days. The high absolute limit (1.25M) is
            to allow for outlier days. Queries at the absolute limit will take a long time, and might
            be unreliable. Apply filters to improve performance. (provider: intrinio) Default: 100000.
        source (str | Unset): The source of the data. Either realtime or delayed. (provider:
            intrinio) Default: 'delayed'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectOptionsUnusual | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        trade_type=trade_type,
        sentiment=sentiment,
        min_value=min_value,
        max_value=max_value,
        limit=limit,
        source=source,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    trade_type: DerivativesOptionsUnusualTradeTypeType0 | None | Unset = UNSET,
    sentiment: DerivativesOptionsUnusualSentimentType0 | None | Unset = UNSET,
    min_value: float | int | None | Unset = UNSET,
    max_value: float | int | None | Unset = UNSET,
    limit: int | Unset = 100000,
    source: str | Unset = "delayed",
) -> Any | HTTPValidationError | OBBjectOptionsUnusual | OpenBBErrorResponse | None:
    """Unusual

     Get the complete options chain for a ticker.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (None | str | Unset): Symbol to get data for. (the underlying symbol)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            If no symbol is supplied, requests are only allowed for a single date. Use the start_date
            for the target date. Intrinio appears to have data beginning Feb/2022, but is unclear when
            it actually began. (provider: intrinio)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format. If a
            symbol is not supplied, do not include an end date. (provider: intrinio)
        trade_type (DerivativesOptionsUnusualTradeTypeType0 | None | Unset): The type of unusual
            activity to query for. (provider: intrinio)
        sentiment (DerivativesOptionsUnusualSentimentType0 | None | Unset): The sentiment type to
            query for. (provider: intrinio)
        min_value (float | int | None | Unset): The inclusive minimum total value for the unusual
            activity. (provider: intrinio)
        max_value (float | int | None | Unset): The inclusive maximum total value for the unusual
            activity. (provider: intrinio)
        limit (int | Unset): The number of data entries to return. A typical day for all symbols
            will yield 50-80K records. The API will paginate at 1000 records. The high default limit
            (100K) is to be able to reliably capture the most days. The high absolute limit (1.25M) is
            to allow for outlier days. Queries at the absolute limit will take a long time, and might
            be unreliable. Apply filters to improve performance. (provider: intrinio) Default: 100000.
        source (str | Unset): The source of the data. Either realtime or delayed. (provider:
            intrinio) Default: 'delayed'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectOptionsUnusual | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        trade_type=trade_type,
        sentiment=sentiment,
        min_value=min_value,
        max_value=max_value,
        limit=limit,
        source=source,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    trade_type: DerivativesOptionsUnusualTradeTypeType0 | None | Unset = UNSET,
    sentiment: DerivativesOptionsUnusualSentimentType0 | None | Unset = UNSET,
    min_value: float | int | None | Unset = UNSET,
    max_value: float | int | None | Unset = UNSET,
    limit: int | Unset = 100000,
    source: str | Unset = "delayed",
) -> Response[Any | HTTPValidationError | OBBjectOptionsUnusual | OpenBBErrorResponse]:
    """Unusual

     Get the complete options chain for a ticker.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (None | str | Unset): Symbol to get data for. (the underlying symbol)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            If no symbol is supplied, requests are only allowed for a single date. Use the start_date
            for the target date. Intrinio appears to have data beginning Feb/2022, but is unclear when
            it actually began. (provider: intrinio)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format. If a
            symbol is not supplied, do not include an end date. (provider: intrinio)
        trade_type (DerivativesOptionsUnusualTradeTypeType0 | None | Unset): The type of unusual
            activity to query for. (provider: intrinio)
        sentiment (DerivativesOptionsUnusualSentimentType0 | None | Unset): The sentiment type to
            query for. (provider: intrinio)
        min_value (float | int | None | Unset): The inclusive minimum total value for the unusual
            activity. (provider: intrinio)
        max_value (float | int | None | Unset): The inclusive maximum total value for the unusual
            activity. (provider: intrinio)
        limit (int | Unset): The number of data entries to return. A typical day for all symbols
            will yield 50-80K records. The API will paginate at 1000 records. The high default limit
            (100K) is to be able to reliably capture the most days. The high absolute limit (1.25M) is
            to allow for outlier days. Queries at the absolute limit will take a long time, and might
            be unreliable. Apply filters to improve performance. (provider: intrinio) Default: 100000.
        source (str | Unset): The source of the data. Either realtime or delayed. (provider:
            intrinio) Default: 'delayed'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectOptionsUnusual | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        trade_type=trade_type,
        sentiment=sentiment,
        min_value=min_value,
        max_value=max_value,
        limit=limit,
        source=source,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    trade_type: DerivativesOptionsUnusualTradeTypeType0 | None | Unset = UNSET,
    sentiment: DerivativesOptionsUnusualSentimentType0 | None | Unset = UNSET,
    min_value: float | int | None | Unset = UNSET,
    max_value: float | int | None | Unset = UNSET,
    limit: int | Unset = 100000,
    source: str | Unset = "delayed",
) -> Any | HTTPValidationError | OBBjectOptionsUnusual | OpenBBErrorResponse | None:
    """Unusual

     Get the complete options chain for a ticker.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (None | str | Unset): Symbol to get data for. (the underlying symbol)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            If no symbol is supplied, requests are only allowed for a single date. Use the start_date
            for the target date. Intrinio appears to have data beginning Feb/2022, but is unclear when
            it actually began. (provider: intrinio)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format. If a
            symbol is not supplied, do not include an end date. (provider: intrinio)
        trade_type (DerivativesOptionsUnusualTradeTypeType0 | None | Unset): The type of unusual
            activity to query for. (provider: intrinio)
        sentiment (DerivativesOptionsUnusualSentimentType0 | None | Unset): The sentiment type to
            query for. (provider: intrinio)
        min_value (float | int | None | Unset): The inclusive minimum total value for the unusual
            activity. (provider: intrinio)
        max_value (float | int | None | Unset): The inclusive maximum total value for the unusual
            activity. (provider: intrinio)
        limit (int | Unset): The number of data entries to return. A typical day for all symbols
            will yield 50-80K records. The API will paginate at 1000 records. The high default limit
            (100K) is to be able to reliably capture the most days. The high absolute limit (1.25M) is
            to allow for outlier days. Queries at the absolute limit will take a long time, and might
            be unreliable. Apply filters to improve performance. (provider: intrinio) Default: 100000.
        source (str | Unset): The source of the data. Either realtime or delayed. (provider:
            intrinio) Default: 'delayed'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectOptionsUnusual | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            start_date=start_date,
            end_date=end_date,
            trade_type=trade_type,
            sentiment=sentiment,
            min_value=min_value,
            max_value=max_value,
            limit=limit,
            source=source,
        )
    ).parsed
