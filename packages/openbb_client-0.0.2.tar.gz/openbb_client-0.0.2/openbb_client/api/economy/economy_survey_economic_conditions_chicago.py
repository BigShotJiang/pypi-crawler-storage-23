import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.economy_survey_economic_conditions_chicago_aggregation_method_type_0 import (
    EconomySurveyEconomicConditionsChicagoAggregationMethodType0,
)
from ...models.economy_survey_economic_conditions_chicago_frequency_type_0 import (
    EconomySurveyEconomicConditionsChicagoFrequencyType0,
)
from ...models.economy_survey_economic_conditions_chicago_transform_type_0 import (
    EconomySurveyEconomicConditionsChicagoTransformType0,
)
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_survey_of_economic_conditions_chicago import OBBjectSurveyOfEconomicConditionsChicago
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["fred"] | Unset = "fred",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: EconomySurveyEconomicConditionsChicagoFrequencyType0 | None | Unset = UNSET,
    aggregation_method: EconomySurveyEconomicConditionsChicagoAggregationMethodType0 | None | Unset = UNSET,
    transform: EconomySurveyEconomicConditionsChicagoTransformType0 | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_frequency: None | str | Unset
    if isinstance(frequency, Unset):
        json_frequency = UNSET
    elif isinstance(frequency, EconomySurveyEconomicConditionsChicagoFrequencyType0):
        json_frequency = frequency.value
    else:
        json_frequency = frequency
    params["frequency"] = json_frequency

    json_aggregation_method: None | str | Unset
    if isinstance(aggregation_method, Unset):
        json_aggregation_method = UNSET
    elif isinstance(aggregation_method, EconomySurveyEconomicConditionsChicagoAggregationMethodType0):
        json_aggregation_method = aggregation_method.value
    else:
        json_aggregation_method = aggregation_method
    params["aggregation_method"] = json_aggregation_method

    json_transform: None | str | Unset
    if isinstance(transform, Unset):
        json_transform = UNSET
    elif isinstance(transform, EconomySurveyEconomicConditionsChicagoTransformType0):
        json_transform = transform.value
    else:
        json_transform = transform
    params["transform"] = json_transform

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/economy/survey/economic_conditions_chicago",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectSurveyOfEconomicConditionsChicago | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectSurveyOfEconomicConditionsChicago.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectSurveyOfEconomicConditionsChicago | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: EconomySurveyEconomicConditionsChicagoFrequencyType0 | None | Unset = UNSET,
    aggregation_method: EconomySurveyEconomicConditionsChicagoAggregationMethodType0 | None | Unset = UNSET,
    transform: EconomySurveyEconomicConditionsChicagoTransformType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectSurveyOfEconomicConditionsChicago | OpenBBErrorResponse]:
    """Economic Conditions Chicago

     Get The Survey Of Economic Conditions For The Chicago Region.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        frequency (EconomySurveyEconomicConditionsChicagoFrequencyType0 | None | Unset): Frequency
            aggregation to convert monthly data to lower frequency. None is monthly. (provider: fred)
        aggregation_method (EconomySurveyEconomicConditionsChicagoAggregationMethodType0 | None |
            Unset): A key that indicates the aggregation method used for frequency aggregation.

                avg = Average

                sum = Sum

                eop = End of Period
                     (provider: fred)
        transform (EconomySurveyEconomicConditionsChicagoTransformType0 | None | Unset):
            Transformation type

                None = No transformation

                chg = Change

                ch1 = Change from Year Ago

                pch = Percent Change

                pc1 = Percent Change from Year Ago

                pca = Compounded Annual Rate of Change

                cch = Continuously Compounded Rate of Change

                cca = Continuously Compounded Annual Rate of Change

                log = Natural Log
                     (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectSurveyOfEconomicConditionsChicago | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        aggregation_method=aggregation_method,
        transform=transform,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: EconomySurveyEconomicConditionsChicagoFrequencyType0 | None | Unset = UNSET,
    aggregation_method: EconomySurveyEconomicConditionsChicagoAggregationMethodType0 | None | Unset = UNSET,
    transform: EconomySurveyEconomicConditionsChicagoTransformType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectSurveyOfEconomicConditionsChicago | OpenBBErrorResponse | None:
    """Economic Conditions Chicago

     Get The Survey Of Economic Conditions For The Chicago Region.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        frequency (EconomySurveyEconomicConditionsChicagoFrequencyType0 | None | Unset): Frequency
            aggregation to convert monthly data to lower frequency. None is monthly. (provider: fred)
        aggregation_method (EconomySurveyEconomicConditionsChicagoAggregationMethodType0 | None |
            Unset): A key that indicates the aggregation method used for frequency aggregation.

                avg = Average

                sum = Sum

                eop = End of Period
                     (provider: fred)
        transform (EconomySurveyEconomicConditionsChicagoTransformType0 | None | Unset):
            Transformation type

                None = No transformation

                chg = Change

                ch1 = Change from Year Ago

                pch = Percent Change

                pc1 = Percent Change from Year Ago

                pca = Compounded Annual Rate of Change

                cch = Continuously Compounded Rate of Change

                cca = Continuously Compounded Annual Rate of Change

                log = Natural Log
                     (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectSurveyOfEconomicConditionsChicago | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        aggregation_method=aggregation_method,
        transform=transform,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: EconomySurveyEconomicConditionsChicagoFrequencyType0 | None | Unset = UNSET,
    aggregation_method: EconomySurveyEconomicConditionsChicagoAggregationMethodType0 | None | Unset = UNSET,
    transform: EconomySurveyEconomicConditionsChicagoTransformType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectSurveyOfEconomicConditionsChicago | OpenBBErrorResponse]:
    """Economic Conditions Chicago

     Get The Survey Of Economic Conditions For The Chicago Region.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        frequency (EconomySurveyEconomicConditionsChicagoFrequencyType0 | None | Unset): Frequency
            aggregation to convert monthly data to lower frequency. None is monthly. (provider: fred)
        aggregation_method (EconomySurveyEconomicConditionsChicagoAggregationMethodType0 | None |
            Unset): A key that indicates the aggregation method used for frequency aggregation.

                avg = Average

                sum = Sum

                eop = End of Period
                     (provider: fred)
        transform (EconomySurveyEconomicConditionsChicagoTransformType0 | None | Unset):
            Transformation type

                None = No transformation

                chg = Change

                ch1 = Change from Year Ago

                pch = Percent Change

                pc1 = Percent Change from Year Ago

                pca = Compounded Annual Rate of Change

                cch = Continuously Compounded Rate of Change

                cca = Continuously Compounded Annual Rate of Change

                log = Natural Log
                     (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectSurveyOfEconomicConditionsChicago | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        frequency=frequency,
        aggregation_method=aggregation_method,
        transform=transform,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    frequency: EconomySurveyEconomicConditionsChicagoFrequencyType0 | None | Unset = UNSET,
    aggregation_method: EconomySurveyEconomicConditionsChicagoAggregationMethodType0 | None | Unset = UNSET,
    transform: EconomySurveyEconomicConditionsChicagoTransformType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectSurveyOfEconomicConditionsChicago | OpenBBErrorResponse | None:
    """Economic Conditions Chicago

     Get The Survey Of Economic Conditions For The Chicago Region.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        frequency (EconomySurveyEconomicConditionsChicagoFrequencyType0 | None | Unset): Frequency
            aggregation to convert monthly data to lower frequency. None is monthly. (provider: fred)
        aggregation_method (EconomySurveyEconomicConditionsChicagoAggregationMethodType0 | None |
            Unset): A key that indicates the aggregation method used for frequency aggregation.

                avg = Average

                sum = Sum

                eop = End of Period
                     (provider: fred)
        transform (EconomySurveyEconomicConditionsChicagoTransformType0 | None | Unset):
            Transformation type

                None = No transformation

                chg = Change

                ch1 = Change from Year Ago

                pch = Percent Change

                pc1 = Percent Change from Year Ago

                pca = Compounded Annual Rate of Change

                cch = Continuously Compounded Rate of Change

                cca = Continuously Compounded Annual Rate of Change

                log = Natural Log
                     (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectSurveyOfEconomicConditionsChicago | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            start_date=start_date,
            end_date=end_date,
            frequency=frequency,
            aggregation_method=aggregation_method,
            transform=transform,
        )
    ).parsed
