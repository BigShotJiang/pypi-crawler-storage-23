import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.economy_shipping_port_volume_country_type_0 import EconomyShippingPortVolumeCountryType0
from ...models.economy_shipping_port_volume_provider import EconomyShippingPortVolumeProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_port_volume import OBBjectPortVolume
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EconomyShippingPortVolumeProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    port_code: None | str | Unset = UNSET,
    country: EconomyShippingPortVolumeCountryType0 | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_port_code: None | str | Unset
    if isinstance(port_code, Unset):
        json_port_code = UNSET
    else:
        json_port_code = port_code
    params["port_code"] = json_port_code

    json_country: None | str | Unset
    if isinstance(country, Unset):
        json_country = UNSET
    elif isinstance(country, EconomyShippingPortVolumeCountryType0):
        json_country = country.value
    else:
        json_country = country
    params["country"] = json_country

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/economy/shipping/port_volume",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectPortVolume | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectPortVolume.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectPortVolume | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyShippingPortVolumeProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    port_code: None | str | Unset = UNSET,
    country: EconomyShippingPortVolumeCountryType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectPortVolume | OpenBBErrorResponse]:
    """Port Volume

     Daily port calls and estimates of trading volumes for ports around the world.

    Args:
        provider (EconomyShippingPortVolumeProvider):
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        port_code (None | str | Unset): Port code to filter results by a specific port. This
            parameter is ignored if `country` parameter is provided. To get a list of available ports,
            use `obb.economy.shipping.port_info()`. Multiple comma separated items allowed. (provider:
            imf)
        country (EconomyShippingPortVolumeCountryType0 | None | Unset): Country to focus on. Enter
            as a 3-letter ISO country code. This parameter is overridden by `port_code` if both are
            provided. (provider: imf)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectPortVolume | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        port_code=port_code,
        country=country,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyShippingPortVolumeProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    port_code: None | str | Unset = UNSET,
    country: EconomyShippingPortVolumeCountryType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectPortVolume | OpenBBErrorResponse | None:
    """Port Volume

     Daily port calls and estimates of trading volumes for ports around the world.

    Args:
        provider (EconomyShippingPortVolumeProvider):
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        port_code (None | str | Unset): Port code to filter results by a specific port. This
            parameter is ignored if `country` parameter is provided. To get a list of available ports,
            use `obb.economy.shipping.port_info()`. Multiple comma separated items allowed. (provider:
            imf)
        country (EconomyShippingPortVolumeCountryType0 | None | Unset): Country to focus on. Enter
            as a 3-letter ISO country code. This parameter is overridden by `port_code` if both are
            provided. (provider: imf)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectPortVolume | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        port_code=port_code,
        country=country,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyShippingPortVolumeProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    port_code: None | str | Unset = UNSET,
    country: EconomyShippingPortVolumeCountryType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectPortVolume | OpenBBErrorResponse]:
    """Port Volume

     Daily port calls and estimates of trading volumes for ports around the world.

    Args:
        provider (EconomyShippingPortVolumeProvider):
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        port_code (None | str | Unset): Port code to filter results by a specific port. This
            parameter is ignored if `country` parameter is provided. To get a list of available ports,
            use `obb.economy.shipping.port_info()`. Multiple comma separated items allowed. (provider:
            imf)
        country (EconomyShippingPortVolumeCountryType0 | None | Unset): Country to focus on. Enter
            as a 3-letter ISO country code. This parameter is overridden by `port_code` if both are
            provided. (provider: imf)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectPortVolume | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        port_code=port_code,
        country=country,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyShippingPortVolumeProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    port_code: None | str | Unset = UNSET,
    country: EconomyShippingPortVolumeCountryType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectPortVolume | OpenBBErrorResponse | None:
    """Port Volume

     Daily port calls and estimates of trading volumes for ports around the world.

    Args:
        provider (EconomyShippingPortVolumeProvider):
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        port_code (None | str | Unset): Port code to filter results by a specific port. This
            parameter is ignored if `country` parameter is provided. To get a list of available ports,
            use `obb.economy.shipping.port_info()`. Multiple comma separated items allowed. (provider:
            imf)
        country (EconomyShippingPortVolumeCountryType0 | None | Unset): Country to focus on. Enter
            as a 3-letter ISO country code. This parameter is overridden by `port_code` if both are
            provided. (provider: imf)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectPortVolume | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            start_date=start_date,
            end_date=end_date,
            port_code=port_code,
            country=country,
        )
    ).parsed
