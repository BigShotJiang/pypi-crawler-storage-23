import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.economy_gdp_real_oecd import EconomyGdpRealOecd
from ...models.economy_gdp_real_provider import EconomyGdpRealProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_gdp_real import OBBjectGdpReal
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EconomyGdpRealProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    country: str | Unset = "united_states",
    use_cache: bool | Unset = True,
    frequency: EconomyGdpRealOecd | Unset = EconomyGdpRealOecd.QUARTER,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    params["country"] = country

    params["use_cache"] = use_cache

    json_frequency: str | Unset = UNSET
    if not isinstance(frequency, Unset):
        json_frequency = frequency.value

    params["frequency"] = json_frequency

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/economy/gdp/real",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectGdpReal | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectGdpReal.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectGdpReal | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyGdpRealProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    country: str | Unset = "united_states",
    use_cache: bool | Unset = True,
    frequency: EconomyGdpRealOecd | Unset = EconomyGdpRealOecd.QUARTER,
) -> Response[Any | HTTPValidationError | OBBjectGdpReal | OpenBBErrorResponse]:
    """Real

     Get Real GDP Data.

    Args:
        provider (EconomyGdpRealProvider):
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        country (str | Unset): The country to get data.Use 'all' to get data for all available
            countries. (provider: econdb, oecd) Default: 'united_states'.
        use_cache (bool | Unset): If True, the request will be cached for one day. Using cache is
            recommended to avoid needlessly requesting the same data. (provider: econdb) Default:
            True.
        frequency (EconomyGdpRealOecd | Unset): Frequency of the data. (provider: oecd) Default:
            EconomyGdpRealOecd.QUARTER.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectGdpReal | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        country=country,
        use_cache=use_cache,
        frequency=frequency,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyGdpRealProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    country: str | Unset = "united_states",
    use_cache: bool | Unset = True,
    frequency: EconomyGdpRealOecd | Unset = EconomyGdpRealOecd.QUARTER,
) -> Any | HTTPValidationError | OBBjectGdpReal | OpenBBErrorResponse | None:
    """Real

     Get Real GDP Data.

    Args:
        provider (EconomyGdpRealProvider):
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        country (str | Unset): The country to get data.Use 'all' to get data for all available
            countries. (provider: econdb, oecd) Default: 'united_states'.
        use_cache (bool | Unset): If True, the request will be cached for one day. Using cache is
            recommended to avoid needlessly requesting the same data. (provider: econdb) Default:
            True.
        frequency (EconomyGdpRealOecd | Unset): Frequency of the data. (provider: oecd) Default:
            EconomyGdpRealOecd.QUARTER.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectGdpReal | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        country=country,
        use_cache=use_cache,
        frequency=frequency,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyGdpRealProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    country: str | Unset = "united_states",
    use_cache: bool | Unset = True,
    frequency: EconomyGdpRealOecd | Unset = EconomyGdpRealOecd.QUARTER,
) -> Response[Any | HTTPValidationError | OBBjectGdpReal | OpenBBErrorResponse]:
    """Real

     Get Real GDP Data.

    Args:
        provider (EconomyGdpRealProvider):
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        country (str | Unset): The country to get data.Use 'all' to get data for all available
            countries. (provider: econdb, oecd) Default: 'united_states'.
        use_cache (bool | Unset): If True, the request will be cached for one day. Using cache is
            recommended to avoid needlessly requesting the same data. (provider: econdb) Default:
            True.
        frequency (EconomyGdpRealOecd | Unset): Frequency of the data. (provider: oecd) Default:
            EconomyGdpRealOecd.QUARTER.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectGdpReal | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        country=country,
        use_cache=use_cache,
        frequency=frequency,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyGdpRealProvider,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    country: str | Unset = "united_states",
    use_cache: bool | Unset = True,
    frequency: EconomyGdpRealOecd | Unset = EconomyGdpRealOecd.QUARTER,
) -> Any | HTTPValidationError | OBBjectGdpReal | OpenBBErrorResponse | None:
    """Real

     Get Real GDP Data.

    Args:
        provider (EconomyGdpRealProvider):
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        country (str | Unset): The country to get data.Use 'all' to get data for all available
            countries. (provider: econdb, oecd) Default: 'united_states'.
        use_cache (bool | Unset): If True, the request will be cached for one day. Using cache is
            recommended to avoid needlessly requesting the same data. (provider: econdb) Default:
            True.
        frequency (EconomyGdpRealOecd | Unset): Frequency of the data. (provider: oecd) Default:
            EconomyGdpRealOecd.QUARTER.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectGdpReal | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            start_date=start_date,
            end_date=end_date,
            country=country,
            use_cache=use_cache,
            frequency=frequency,
        )
    ).parsed
