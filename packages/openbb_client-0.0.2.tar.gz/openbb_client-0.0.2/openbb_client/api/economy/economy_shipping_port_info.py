from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.economy_shipping_port_info_continent_type_0 import EconomyShippingPortInfoContinentType0
from ...models.economy_shipping_port_info_country_type_0 import EconomyShippingPortInfoCountryType0
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_port_info import OBBjectPortInfo
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["imf"] | Unset = "imf",
    continent: EconomyShippingPortInfoContinentType0 | None | Unset = UNSET,
    country: EconomyShippingPortInfoCountryType0 | None | Unset = UNSET,
    port_code: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_continent: None | str | Unset
    if isinstance(continent, Unset):
        json_continent = UNSET
    elif isinstance(continent, EconomyShippingPortInfoContinentType0):
        json_continent = continent.value
    else:
        json_continent = continent
    params["continent"] = json_continent

    json_country: None | str | Unset
    if isinstance(country, Unset):
        json_country = UNSET
    elif isinstance(country, EconomyShippingPortInfoCountryType0):
        json_country = country.value
    else:
        json_country = country
    params["country"] = json_country

    json_port_code: None | str | Unset
    if isinstance(port_code, Unset):
        json_port_code = UNSET
    else:
        json_port_code = port_code
    params["port_code"] = json_port_code

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/economy/shipping/port_info",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectPortInfo | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectPortInfo.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectPortInfo | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["imf"] | Unset = "imf",
    continent: EconomyShippingPortInfoContinentType0 | None | Unset = UNSET,
    country: EconomyShippingPortInfoCountryType0 | None | Unset = UNSET,
    port_code: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectPortInfo | OpenBBErrorResponse]:
    """Port Info

     Get general metadata and statistics for all ports from a given provider.

    Args:
        provider (Literal['imf'] | Unset):  Default: 'imf'.
        continent (EconomyShippingPortInfoContinentType0 | None | Unset): Filter by continent.
            This parameter is ignored when a `country` is provided. (provider: imf)
        country (EconomyShippingPortInfoCountryType0 | None | Unset): Country to focus on. Enter
            as a 3-letter ISO country code. This parameter supersedes `continent` if both are
            provided. (provider: imf)
        port_code (None | str | Unset): This is a dummy parameter to allow grouping in OpenBB
            Workspace widgets. (provider: imf)
        limit (int | None | Unset): Limit the number of results returned. Limit is determined by
            the annual average number of vessels transiting through the port. If not provided, all
            ports are returned. (provider: imf)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectPortInfo | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        continent=continent,
        country=country,
        port_code=port_code,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["imf"] | Unset = "imf",
    continent: EconomyShippingPortInfoContinentType0 | None | Unset = UNSET,
    country: EconomyShippingPortInfoCountryType0 | None | Unset = UNSET,
    port_code: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectPortInfo | OpenBBErrorResponse | None:
    """Port Info

     Get general metadata and statistics for all ports from a given provider.

    Args:
        provider (Literal['imf'] | Unset):  Default: 'imf'.
        continent (EconomyShippingPortInfoContinentType0 | None | Unset): Filter by continent.
            This parameter is ignored when a `country` is provided. (provider: imf)
        country (EconomyShippingPortInfoCountryType0 | None | Unset): Country to focus on. Enter
            as a 3-letter ISO country code. This parameter supersedes `continent` if both are
            provided. (provider: imf)
        port_code (None | str | Unset): This is a dummy parameter to allow grouping in OpenBB
            Workspace widgets. (provider: imf)
        limit (int | None | Unset): Limit the number of results returned. Limit is determined by
            the annual average number of vessels transiting through the port. If not provided, all
            ports are returned. (provider: imf)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectPortInfo | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        continent=continent,
        country=country,
        port_code=port_code,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["imf"] | Unset = "imf",
    continent: EconomyShippingPortInfoContinentType0 | None | Unset = UNSET,
    country: EconomyShippingPortInfoCountryType0 | None | Unset = UNSET,
    port_code: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectPortInfo | OpenBBErrorResponse]:
    """Port Info

     Get general metadata and statistics for all ports from a given provider.

    Args:
        provider (Literal['imf'] | Unset):  Default: 'imf'.
        continent (EconomyShippingPortInfoContinentType0 | None | Unset): Filter by continent.
            This parameter is ignored when a `country` is provided. (provider: imf)
        country (EconomyShippingPortInfoCountryType0 | None | Unset): Country to focus on. Enter
            as a 3-letter ISO country code. This parameter supersedes `continent` if both are
            provided. (provider: imf)
        port_code (None | str | Unset): This is a dummy parameter to allow grouping in OpenBB
            Workspace widgets. (provider: imf)
        limit (int | None | Unset): Limit the number of results returned. Limit is determined by
            the annual average number of vessels transiting through the port. If not provided, all
            ports are returned. (provider: imf)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectPortInfo | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        continent=continent,
        country=country,
        port_code=port_code,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["imf"] | Unset = "imf",
    continent: EconomyShippingPortInfoContinentType0 | None | Unset = UNSET,
    country: EconomyShippingPortInfoCountryType0 | None | Unset = UNSET,
    port_code: None | str | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectPortInfo | OpenBBErrorResponse | None:
    """Port Info

     Get general metadata and statistics for all ports from a given provider.

    Args:
        provider (Literal['imf'] | Unset):  Default: 'imf'.
        continent (EconomyShippingPortInfoContinentType0 | None | Unset): Filter by continent.
            This parameter is ignored when a `country` is provided. (provider: imf)
        country (EconomyShippingPortInfoCountryType0 | None | Unset): Country to focus on. Enter
            as a 3-letter ISO country code. This parameter supersedes `continent` if both are
            provided. (provider: imf)
        port_code (None | str | Unset): This is a dummy parameter to allow grouping in OpenBB
            Workspace widgets. (provider: imf)
        limit (int | None | Unset): Limit the number of results returned. Limit is determined by
            the annual average number of vessels transiting through the port. If not provided, all
            ports are returned. (provider: imf)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectPortInfo | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            continent=continent,
            country=country,
            port_code=port_code,
            limit=limit,
        )
    ).parsed
