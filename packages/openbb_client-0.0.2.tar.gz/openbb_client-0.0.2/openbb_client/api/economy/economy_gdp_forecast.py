import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_gdp_forecast import OBBjectGdpForecast
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["oecd"] | Unset = "oecd",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    country: str | Unset = "all",
    frequency: str | Unset = "annual",
    units: str | Unset = "volume",
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    params["country"] = country

    params["frequency"] = frequency

    params["units"] = units

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/economy/gdp/forecast",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectGdpForecast | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectGdpForecast.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectGdpForecast | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["oecd"] | Unset = "oecd",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    country: str | Unset = "all",
    frequency: str | Unset = "annual",
    units: str | Unset = "volume",
) -> Response[Any | HTTPValidationError | OBBjectGdpForecast | OpenBBErrorResponse]:
    """Forecast

     Get Forecasted GDP Data.

    Args:
        provider (Literal['oecd'] | Unset):  Default: 'oecd'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        country (str | Unset): Country, or countries, to get forward GDP projections for. Default
            is all. Multiple comma separated items allowed. (provider: oecd) Default: 'all'.
        frequency (str | Unset): Frequency of the data, default is annual. (provider: oecd)
            Default: 'annual'.
        units (str | Unset): Units of the data, default is volume (chain linked volume, 2015).
            'current_prices', 'volume', and 'capita' are expressed in USD; 'growth' as a percent;
            'deflator' as an index. (provider: oecd) Default: 'volume'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectGdpForecast | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        country=country,
        frequency=frequency,
        units=units,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["oecd"] | Unset = "oecd",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    country: str | Unset = "all",
    frequency: str | Unset = "annual",
    units: str | Unset = "volume",
) -> Any | HTTPValidationError | OBBjectGdpForecast | OpenBBErrorResponse | None:
    """Forecast

     Get Forecasted GDP Data.

    Args:
        provider (Literal['oecd'] | Unset):  Default: 'oecd'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        country (str | Unset): Country, or countries, to get forward GDP projections for. Default
            is all. Multiple comma separated items allowed. (provider: oecd) Default: 'all'.
        frequency (str | Unset): Frequency of the data, default is annual. (provider: oecd)
            Default: 'annual'.
        units (str | Unset): Units of the data, default is volume (chain linked volume, 2015).
            'current_prices', 'volume', and 'capita' are expressed in USD; 'growth' as a percent;
            'deflator' as an index. (provider: oecd) Default: 'volume'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectGdpForecast | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        country=country,
        frequency=frequency,
        units=units,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["oecd"] | Unset = "oecd",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    country: str | Unset = "all",
    frequency: str | Unset = "annual",
    units: str | Unset = "volume",
) -> Response[Any | HTTPValidationError | OBBjectGdpForecast | OpenBBErrorResponse]:
    """Forecast

     Get Forecasted GDP Data.

    Args:
        provider (Literal['oecd'] | Unset):  Default: 'oecd'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        country (str | Unset): Country, or countries, to get forward GDP projections for. Default
            is all. Multiple comma separated items allowed. (provider: oecd) Default: 'all'.
        frequency (str | Unset): Frequency of the data, default is annual. (provider: oecd)
            Default: 'annual'.
        units (str | Unset): Units of the data, default is volume (chain linked volume, 2015).
            'current_prices', 'volume', and 'capita' are expressed in USD; 'growth' as a percent;
            'deflator' as an index. (provider: oecd) Default: 'volume'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectGdpForecast | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        country=country,
        frequency=frequency,
        units=units,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["oecd"] | Unset = "oecd",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    country: str | Unset = "all",
    frequency: str | Unset = "annual",
    units: str | Unset = "volume",
) -> Any | HTTPValidationError | OBBjectGdpForecast | OpenBBErrorResponse | None:
    """Forecast

     Get Forecasted GDP Data.

    Args:
        provider (Literal['oecd'] | Unset):  Default: 'oecd'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        country (str | Unset): Country, or countries, to get forward GDP projections for. Default
            is all. Multiple comma separated items allowed. (provider: oecd) Default: 'all'.
        frequency (str | Unset): Frequency of the data, default is annual. (provider: oecd)
            Default: 'annual'.
        units (str | Unset): Units of the data, default is volume (chain linked volume, 2015).
            'current_prices', 'volume', and 'capita' are expressed in USD; 'growth' as a percent;
            'deflator' as an index. (provider: oecd) Default: 'volume'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectGdpForecast | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            start_date=start_date,
            end_date=end_date,
            country=country,
            frequency=frequency,
            units=units,
        )
    ).parsed
