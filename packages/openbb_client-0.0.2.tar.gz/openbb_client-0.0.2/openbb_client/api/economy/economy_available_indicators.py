from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.economy_available_indicators_provider import EconomyAvailableIndicatorsProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_available_indicators import OBBjectAvailableIndicators
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EconomyAvailableIndicatorsProvider,
    use_cache: bool | Unset = True,
    query: None | str | Unset = UNSET,
    dataflows: list[str] | None | str | Unset = UNSET,
    keywords: list[str] | None | str | Unset = UNSET,
    symbol: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    params["use_cache"] = use_cache

    json_query: None | str | Unset
    if isinstance(query, Unset):
        json_query = UNSET
    else:
        json_query = query
    params["query"] = json_query

    json_dataflows: list[str] | None | str | Unset
    if isinstance(dataflows, Unset):
        json_dataflows = UNSET
    elif isinstance(dataflows, list):
        json_dataflows = dataflows

    else:
        json_dataflows = dataflows
    params["dataflows"] = json_dataflows

    json_keywords: list[str] | None | str | Unset
    if isinstance(keywords, Unset):
        json_keywords = UNSET
    elif isinstance(keywords, list):
        json_keywords = keywords

    else:
        json_keywords = keywords
    params["keywords"] = json_keywords

    json_symbol: None | str | Unset
    if isinstance(symbol, Unset):
        json_symbol = UNSET
    else:
        json_symbol = symbol
    params["symbol"] = json_symbol

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/economy/available_indicators",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectAvailableIndicators | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectAvailableIndicators.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectAvailableIndicators | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyAvailableIndicatorsProvider,
    use_cache: bool | Unset = True,
    query: None | str | Unset = UNSET,
    dataflows: list[str] | None | str | Unset = UNSET,
    keywords: list[str] | None | str | Unset = UNSET,
    symbol: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectAvailableIndicators | OpenBBErrorResponse]:
    """Available Indicators

     Get the available economic indicators for a provider.

    Args:
        provider (EconomyAvailableIndicatorsProvider):
        use_cache (bool | Unset): Whether to use cache or not, by default is True The cache of
            indicator symbols will persist for one week. (provider: econdb) Default: True.
        query (None | str | Unset): The search query string. Multiple search phrases can be
            separated by semicolons. Each phrase can use AND (+) and OR (|) operators, as well as
            quoted phrases. Semicolon separation allows commas to be used within search phrases.
            Multiple comma separated items allowed. (provider: imf)
        dataflows (list[str] | None | str | Unset): List of IMF dataflow IDs to filter the
            indicators. Use semicolons to separate multiple dataflow IDs. Multiple comma separated
            items allowed. (provider: imf)
        keywords (list[str] | None | str | Unset): List of keywords to filter results. Each
            keyword is a single word that must appear in the indicator's label or description.
            Keywords prefixed with 'not' will exclude indicators containing that word (e.g., 'not USD'
            excludes indicators with 'USD' in them). Multiple comma separated items allowed.
            (provider: imf)
        symbol (None | str | Unset): Dummy field to allow grouping by symbol. Multiple comma
            separated items allowed. (provider: imf)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectAvailableIndicators | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        use_cache=use_cache,
        query=query,
        dataflows=dataflows,
        keywords=keywords,
        symbol=symbol,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyAvailableIndicatorsProvider,
    use_cache: bool | Unset = True,
    query: None | str | Unset = UNSET,
    dataflows: list[str] | None | str | Unset = UNSET,
    keywords: list[str] | None | str | Unset = UNSET,
    symbol: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectAvailableIndicators | OpenBBErrorResponse | None:
    """Available Indicators

     Get the available economic indicators for a provider.

    Args:
        provider (EconomyAvailableIndicatorsProvider):
        use_cache (bool | Unset): Whether to use cache or not, by default is True The cache of
            indicator symbols will persist for one week. (provider: econdb) Default: True.
        query (None | str | Unset): The search query string. Multiple search phrases can be
            separated by semicolons. Each phrase can use AND (+) and OR (|) operators, as well as
            quoted phrases. Semicolon separation allows commas to be used within search phrases.
            Multiple comma separated items allowed. (provider: imf)
        dataflows (list[str] | None | str | Unset): List of IMF dataflow IDs to filter the
            indicators. Use semicolons to separate multiple dataflow IDs. Multiple comma separated
            items allowed. (provider: imf)
        keywords (list[str] | None | str | Unset): List of keywords to filter results. Each
            keyword is a single word that must appear in the indicator's label or description.
            Keywords prefixed with 'not' will exclude indicators containing that word (e.g., 'not USD'
            excludes indicators with 'USD' in them). Multiple comma separated items allowed.
            (provider: imf)
        symbol (None | str | Unset): Dummy field to allow grouping by symbol. Multiple comma
            separated items allowed. (provider: imf)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectAvailableIndicators | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        use_cache=use_cache,
        query=query,
        dataflows=dataflows,
        keywords=keywords,
        symbol=symbol,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyAvailableIndicatorsProvider,
    use_cache: bool | Unset = True,
    query: None | str | Unset = UNSET,
    dataflows: list[str] | None | str | Unset = UNSET,
    keywords: list[str] | None | str | Unset = UNSET,
    symbol: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectAvailableIndicators | OpenBBErrorResponse]:
    """Available Indicators

     Get the available economic indicators for a provider.

    Args:
        provider (EconomyAvailableIndicatorsProvider):
        use_cache (bool | Unset): Whether to use cache or not, by default is True The cache of
            indicator symbols will persist for one week. (provider: econdb) Default: True.
        query (None | str | Unset): The search query string. Multiple search phrases can be
            separated by semicolons. Each phrase can use AND (+) and OR (|) operators, as well as
            quoted phrases. Semicolon separation allows commas to be used within search phrases.
            Multiple comma separated items allowed. (provider: imf)
        dataflows (list[str] | None | str | Unset): List of IMF dataflow IDs to filter the
            indicators. Use semicolons to separate multiple dataflow IDs. Multiple comma separated
            items allowed. (provider: imf)
        keywords (list[str] | None | str | Unset): List of keywords to filter results. Each
            keyword is a single word that must appear in the indicator's label or description.
            Keywords prefixed with 'not' will exclude indicators containing that word (e.g., 'not USD'
            excludes indicators with 'USD' in them). Multiple comma separated items allowed.
            (provider: imf)
        symbol (None | str | Unset): Dummy field to allow grouping by symbol. Multiple comma
            separated items allowed. (provider: imf)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectAvailableIndicators | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        use_cache=use_cache,
        query=query,
        dataflows=dataflows,
        keywords=keywords,
        symbol=symbol,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyAvailableIndicatorsProvider,
    use_cache: bool | Unset = True,
    query: None | str | Unset = UNSET,
    dataflows: list[str] | None | str | Unset = UNSET,
    keywords: list[str] | None | str | Unset = UNSET,
    symbol: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectAvailableIndicators | OpenBBErrorResponse | None:
    """Available Indicators

     Get the available economic indicators for a provider.

    Args:
        provider (EconomyAvailableIndicatorsProvider):
        use_cache (bool | Unset): Whether to use cache or not, by default is True The cache of
            indicator symbols will persist for one week. (provider: econdb) Default: True.
        query (None | str | Unset): The search query string. Multiple search phrases can be
            separated by semicolons. Each phrase can use AND (+) and OR (|) operators, as well as
            quoted phrases. Semicolon separation allows commas to be used within search phrases.
            Multiple comma separated items allowed. (provider: imf)
        dataflows (list[str] | None | str | Unset): List of IMF dataflow IDs to filter the
            indicators. Use semicolons to separate multiple dataflow IDs. Multiple comma separated
            items allowed. (provider: imf)
        keywords (list[str] | None | str | Unset): List of keywords to filter results. Each
            keyword is a single word that must appear in the indicator's label or description.
            Keywords prefixed with 'not' will exclude indicators containing that word (e.g., 'not USD'
            excludes indicators with 'USD' in them). Multiple comma separated items allowed.
            (provider: imf)
        symbol (None | str | Unset): Dummy field to allow grouping by symbol. Multiple comma
            separated items allowed. (provider: imf)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectAvailableIndicators | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            use_cache=use_cache,
            query=query,
            dataflows=dataflows,
            keywords=keywords,
            symbol=symbol,
        )
    ).parsed
