import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.economy_retail_prices_transform_type_0 import EconomyRetailPricesTransformType0
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_retail_prices import OBBjectRetailPrices
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["fred"] | Unset = "fred",
    item: None | str | Unset = UNSET,
    country: str | Unset = "united_states",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    region: str | Unset = "all_city",
    frequency: str | Unset = "monthly",
    transform: EconomyRetailPricesTransformType0 | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_item: None | str | Unset
    if isinstance(item, Unset):
        json_item = UNSET
    else:
        json_item = item
    params["item"] = json_item

    params["country"] = country

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    params["region"] = region

    params["frequency"] = frequency

    json_transform: None | str | Unset
    if isinstance(transform, Unset):
        json_transform = UNSET
    elif isinstance(transform, EconomyRetailPricesTransformType0):
        json_transform = transform.value
    else:
        json_transform = transform
    params["transform"] = json_transform

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/economy/retail_prices",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectRetailPrices | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectRetailPrices.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectRetailPrices | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    item: None | str | Unset = UNSET,
    country: str | Unset = "united_states",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    region: str | Unset = "all_city",
    frequency: str | Unset = "monthly",
    transform: EconomyRetailPricesTransformType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectRetailPrices | OpenBBErrorResponse]:
    """Retail Prices

     Get retail prices for common items.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        item (None | str | Unset): The item or basket of items to query.
        country (str | Unset): The country to get data. Default: 'united_states'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        region (str | Unset): The region to get average price levels for. (provider: fred)
            Default: 'all_city'.
        frequency (str | Unset): The frequency of the data. (provider: fred) Default: 'monthly'.
        transform (EconomyRetailPricesTransformType0 | None | Unset): Transformation type
                None = No transformation
                chg = Change
                ch1 = Change from Year Ago
                pch = Percent Change
                pc1 = Percent Change from Year Ago
                pca = Compounded Annual Rate of Change
                cch = Continuously Compounded Rate of Change
                cca = Continuously Compounded Annual Rate of Change
                log = Natural Log
             (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectRetailPrices | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        item=item,
        country=country,
        start_date=start_date,
        end_date=end_date,
        region=region,
        frequency=frequency,
        transform=transform,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    item: None | str | Unset = UNSET,
    country: str | Unset = "united_states",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    region: str | Unset = "all_city",
    frequency: str | Unset = "monthly",
    transform: EconomyRetailPricesTransformType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectRetailPrices | OpenBBErrorResponse | None:
    """Retail Prices

     Get retail prices for common items.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        item (None | str | Unset): The item or basket of items to query.
        country (str | Unset): The country to get data. Default: 'united_states'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        region (str | Unset): The region to get average price levels for. (provider: fred)
            Default: 'all_city'.
        frequency (str | Unset): The frequency of the data. (provider: fred) Default: 'monthly'.
        transform (EconomyRetailPricesTransformType0 | None | Unset): Transformation type
                None = No transformation
                chg = Change
                ch1 = Change from Year Ago
                pch = Percent Change
                pc1 = Percent Change from Year Ago
                pca = Compounded Annual Rate of Change
                cch = Continuously Compounded Rate of Change
                cca = Continuously Compounded Annual Rate of Change
                log = Natural Log
             (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectRetailPrices | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        item=item,
        country=country,
        start_date=start_date,
        end_date=end_date,
        region=region,
        frequency=frequency,
        transform=transform,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    item: None | str | Unset = UNSET,
    country: str | Unset = "united_states",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    region: str | Unset = "all_city",
    frequency: str | Unset = "monthly",
    transform: EconomyRetailPricesTransformType0 | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectRetailPrices | OpenBBErrorResponse]:
    """Retail Prices

     Get retail prices for common items.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        item (None | str | Unset): The item or basket of items to query.
        country (str | Unset): The country to get data. Default: 'united_states'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        region (str | Unset): The region to get average price levels for. (provider: fred)
            Default: 'all_city'.
        frequency (str | Unset): The frequency of the data. (provider: fred) Default: 'monthly'.
        transform (EconomyRetailPricesTransformType0 | None | Unset): Transformation type
                None = No transformation
                chg = Change
                ch1 = Change from Year Ago
                pch = Percent Change
                pc1 = Percent Change from Year Ago
                pca = Compounded Annual Rate of Change
                cch = Continuously Compounded Rate of Change
                cca = Continuously Compounded Annual Rate of Change
                log = Natural Log
             (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectRetailPrices | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        item=item,
        country=country,
        start_date=start_date,
        end_date=end_date,
        region=region,
        frequency=frequency,
        transform=transform,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["fred"] | Unset = "fred",
    item: None | str | Unset = UNSET,
    country: str | Unset = "united_states",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    region: str | Unset = "all_city",
    frequency: str | Unset = "monthly",
    transform: EconomyRetailPricesTransformType0 | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectRetailPrices | OpenBBErrorResponse | None:
    """Retail Prices

     Get retail prices for common items.

    Args:
        provider (Literal['fred'] | Unset):  Default: 'fred'.
        item (None | str | Unset): The item or basket of items to query.
        country (str | Unset): The country to get data. Default: 'united_states'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        region (str | Unset): The region to get average price levels for. (provider: fred)
            Default: 'all_city'.
        frequency (str | Unset): The frequency of the data. (provider: fred) Default: 'monthly'.
        transform (EconomyRetailPricesTransformType0 | None | Unset): Transformation type
                None = No transformation
                chg = Change
                ch1 = Change from Year Ago
                pch = Percent Change
                pc1 = Percent Change from Year Ago
                pca = Compounded Annual Rate of Change
                cch = Continuously Compounded Rate of Change
                cca = Continuously Compounded Annual Rate of Change
                log = Natural Log
             (provider: fred)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectRetailPrices | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            item=item,
            country=country,
            start_date=start_date,
            end_date=end_date,
            region=region,
            frequency=frequency,
            transform=transform,
        )
    ).parsed
