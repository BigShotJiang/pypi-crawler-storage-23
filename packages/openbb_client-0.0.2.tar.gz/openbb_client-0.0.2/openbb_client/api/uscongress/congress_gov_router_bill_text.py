from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.congress_gov_router_bill_text_body_type_2 import CongressGovRouterBillTextBodyType2
from ...models.http_validation_error import HTTPValidationError
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: CongressGovRouterBillTextBodyType2 | list[str] | None | str | Unset = UNSET,
    provider: Literal["congress_gov"] | Unset = "congress_gov",
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["provider"] = provider

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/uscongress/bill_text",
        "params": params,
    }

    if isinstance(body, list):
        _kwargs["json"] = body

    elif isinstance(body, CongressGovRouterBillTextBodyType2):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OpenBBErrorResponse | list[Any] | None:
    if response.status_code == 200:
        response_200 = cast(list[Any], response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OpenBBErrorResponse | list[Any]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CongressGovRouterBillTextBodyType2 | list[str] | None | str | Unset = UNSET,
    provider: Literal["congress_gov"] | Unset = "congress_gov",
) -> Response[Any | HTTPValidationError | OpenBBErrorResponse | list[Any]]:
    r"""Bill Text

     Download the content of bill(s) from a Congress.gov file.

    Note: This endpoint returns only the results array of the OBBject.

    Enter a list of URLs to download the bill text.

    For the API, the body of the request will look like this:

    ```json
    {
    \"urls\": [
    \"https://www.congress.gov/119/bills/hr1/BILLS-119hr1eh.pdf\"
    ]
    }
    ```

    In OpenBB Workspace, this command returns as a multi-file viewer widget.

    Args:
        provider (Literal['congress_gov'] | Unset):  Default: 'congress_gov'.
        body (CongressGovRouterBillTextBodyType2 | list[str] | None | str | Unset): List of direct
            bill URLs to download. Multiple comma separated items allowed. (provider: congress_gov)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OpenBBErrorResponse | list[Any]]
    """

    kwargs = _get_kwargs(
        body=body,
        provider=provider,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: CongressGovRouterBillTextBodyType2 | list[str] | None | str | Unset = UNSET,
    provider: Literal["congress_gov"] | Unset = "congress_gov",
) -> Any | HTTPValidationError | OpenBBErrorResponse | list[Any] | None:
    r"""Bill Text

     Download the content of bill(s) from a Congress.gov file.

    Note: This endpoint returns only the results array of the OBBject.

    Enter a list of URLs to download the bill text.

    For the API, the body of the request will look like this:

    ```json
    {
    \"urls\": [
    \"https://www.congress.gov/119/bills/hr1/BILLS-119hr1eh.pdf\"
    ]
    }
    ```

    In OpenBB Workspace, this command returns as a multi-file viewer widget.

    Args:
        provider (Literal['congress_gov'] | Unset):  Default: 'congress_gov'.
        body (CongressGovRouterBillTextBodyType2 | list[str] | None | str | Unset): List of direct
            bill URLs to download. Multiple comma separated items allowed. (provider: congress_gov)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OpenBBErrorResponse | list[Any]
    """

    return sync_detailed(
        client=client,
        body=body,
        provider=provider,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: CongressGovRouterBillTextBodyType2 | list[str] | None | str | Unset = UNSET,
    provider: Literal["congress_gov"] | Unset = "congress_gov",
) -> Response[Any | HTTPValidationError | OpenBBErrorResponse | list[Any]]:
    r"""Bill Text

     Download the content of bill(s) from a Congress.gov file.

    Note: This endpoint returns only the results array of the OBBject.

    Enter a list of URLs to download the bill text.

    For the API, the body of the request will look like this:

    ```json
    {
    \"urls\": [
    \"https://www.congress.gov/119/bills/hr1/BILLS-119hr1eh.pdf\"
    ]
    }
    ```

    In OpenBB Workspace, this command returns as a multi-file viewer widget.

    Args:
        provider (Literal['congress_gov'] | Unset):  Default: 'congress_gov'.
        body (CongressGovRouterBillTextBodyType2 | list[str] | None | str | Unset): List of direct
            bill URLs to download. Multiple comma separated items allowed. (provider: congress_gov)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OpenBBErrorResponse | list[Any]]
    """

    kwargs = _get_kwargs(
        body=body,
        provider=provider,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: CongressGovRouterBillTextBodyType2 | list[str] | None | str | Unset = UNSET,
    provider: Literal["congress_gov"] | Unset = "congress_gov",
) -> Any | HTTPValidationError | OpenBBErrorResponse | list[Any] | None:
    r"""Bill Text

     Download the content of bill(s) from a Congress.gov file.

    Note: This endpoint returns only the results array of the OBBject.

    Enter a list of URLs to download the bill text.

    For the API, the body of the request will look like this:

    ```json
    {
    \"urls\": [
    \"https://www.congress.gov/119/bills/hr1/BILLS-119hr1eh.pdf\"
    ]
    }
    ```

    In OpenBB Workspace, this command returns as a multi-file viewer widget.

    Args:
        provider (Literal['congress_gov'] | Unset):  Default: 'congress_gov'.
        body (CongressGovRouterBillTextBodyType2 | list[str] | None | str | Unset): List of direct
            bill URLs to download. Multiple comma separated items allowed. (provider: congress_gov)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OpenBBErrorResponse | list[Any]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            provider=provider,
        )
    ).parsed
