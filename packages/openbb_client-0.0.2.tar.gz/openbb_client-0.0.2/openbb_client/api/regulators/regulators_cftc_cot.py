import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_cot import OBBjectCOT
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...models.regulators_cftc_cot_cftc import RegulatorsCftcCotCftc
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["cftc"] | Unset = "cftc",
    id: str | Unset = "045601",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    report_type: RegulatorsCftcCotCftc | Unset = RegulatorsCftcCotCftc.LEGACY,
    futures_only: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["id"] = id

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_report_type: str | Unset = UNSET
    if not isinstance(report_type, Unset):
        json_report_type = report_type.value

    params["report_type"] = json_report_type

    params["futures_only"] = futures_only

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/regulators/cftc/cot",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectCOT | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectCOT.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectCOT | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["cftc"] | Unset = "cftc",
    id: str | Unset = "045601",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    report_type: RegulatorsCftcCotCftc | Unset = RegulatorsCftcCotCftc.LEGACY,
    futures_only: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OBBjectCOT | OpenBBErrorResponse]:
    """Cot

     Get Commitment of Traders Reports.

    Args:
        provider (Literal['cftc'] | Unset):  Default: 'cftc'.
        id (str | Unset): A string with the CFTC market code or other identifying string, such as
            the contract market name, commodity name, or commodity group - i.e, 'gold' or 'japanese
            yen'.Default report is Fed Funds Futures. Use the 'cftc_market_code' for an exact match.
            Default: '045601'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            Default is the most recent report.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        report_type (RegulatorsCftcCotCftc | Unset): The type of report to retrieve. Set `id` as
            'all' to return all items in the report
                        type (default date range returns the latest report). The Legacy report is
            broken down by exchange
                        with reported open interest further broken down into three trader
            classifications: commercial,
                        non-commercial and non-reportable. The Disaggregated reports are broken down
            by Agriculture and
                        Natural Resource contracts. The Disaggregated reports break down reportable
            open interest positions
                        into four classifications: Producer/Merchant, Swap Dealers, Managed Money and
            Other Reportables.
                        The Traders in Financial Futures (TFF) report includes financial contracts.
            The TFF report breaks
                        down the reported open interest into five classifications: Dealer, Asset
            Manager, Leveraged Money,
                        Other Reportables and Non-Reportables. (provider: cftc) Default:
            RegulatorsCftcCotCftc.LEGACY.
        futures_only (bool | Unset): Returns the futures-only report. Default is False, for the
            combined report. (provider: cftc) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCOT | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        id=id,
        start_date=start_date,
        end_date=end_date,
        report_type=report_type,
        futures_only=futures_only,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["cftc"] | Unset = "cftc",
    id: str | Unset = "045601",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    report_type: RegulatorsCftcCotCftc | Unset = RegulatorsCftcCotCftc.LEGACY,
    futures_only: bool | Unset = False,
) -> Any | HTTPValidationError | OBBjectCOT | OpenBBErrorResponse | None:
    """Cot

     Get Commitment of Traders Reports.

    Args:
        provider (Literal['cftc'] | Unset):  Default: 'cftc'.
        id (str | Unset): A string with the CFTC market code or other identifying string, such as
            the contract market name, commodity name, or commodity group - i.e, 'gold' or 'japanese
            yen'.Default report is Fed Funds Futures. Use the 'cftc_market_code' for an exact match.
            Default: '045601'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            Default is the most recent report.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        report_type (RegulatorsCftcCotCftc | Unset): The type of report to retrieve. Set `id` as
            'all' to return all items in the report
                        type (default date range returns the latest report). The Legacy report is
            broken down by exchange
                        with reported open interest further broken down into three trader
            classifications: commercial,
                        non-commercial and non-reportable. The Disaggregated reports are broken down
            by Agriculture and
                        Natural Resource contracts. The Disaggregated reports break down reportable
            open interest positions
                        into four classifications: Producer/Merchant, Swap Dealers, Managed Money and
            Other Reportables.
                        The Traders in Financial Futures (TFF) report includes financial contracts.
            The TFF report breaks
                        down the reported open interest into five classifications: Dealer, Asset
            Manager, Leveraged Money,
                        Other Reportables and Non-Reportables. (provider: cftc) Default:
            RegulatorsCftcCotCftc.LEGACY.
        futures_only (bool | Unset): Returns the futures-only report. Default is False, for the
            combined report. (provider: cftc) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCOT | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        id=id,
        start_date=start_date,
        end_date=end_date,
        report_type=report_type,
        futures_only=futures_only,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["cftc"] | Unset = "cftc",
    id: str | Unset = "045601",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    report_type: RegulatorsCftcCotCftc | Unset = RegulatorsCftcCotCftc.LEGACY,
    futures_only: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OBBjectCOT | OpenBBErrorResponse]:
    """Cot

     Get Commitment of Traders Reports.

    Args:
        provider (Literal['cftc'] | Unset):  Default: 'cftc'.
        id (str | Unset): A string with the CFTC market code or other identifying string, such as
            the contract market name, commodity name, or commodity group - i.e, 'gold' or 'japanese
            yen'.Default report is Fed Funds Futures. Use the 'cftc_market_code' for an exact match.
            Default: '045601'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            Default is the most recent report.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        report_type (RegulatorsCftcCotCftc | Unset): The type of report to retrieve. Set `id` as
            'all' to return all items in the report
                        type (default date range returns the latest report). The Legacy report is
            broken down by exchange
                        with reported open interest further broken down into three trader
            classifications: commercial,
                        non-commercial and non-reportable. The Disaggregated reports are broken down
            by Agriculture and
                        Natural Resource contracts. The Disaggregated reports break down reportable
            open interest positions
                        into four classifications: Producer/Merchant, Swap Dealers, Managed Money and
            Other Reportables.
                        The Traders in Financial Futures (TFF) report includes financial contracts.
            The TFF report breaks
                        down the reported open interest into five classifications: Dealer, Asset
            Manager, Leveraged Money,
                        Other Reportables and Non-Reportables. (provider: cftc) Default:
            RegulatorsCftcCotCftc.LEGACY.
        futures_only (bool | Unset): Returns the futures-only report. Default is False, for the
            combined report. (provider: cftc) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCOT | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        id=id,
        start_date=start_date,
        end_date=end_date,
        report_type=report_type,
        futures_only=futures_only,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["cftc"] | Unset = "cftc",
    id: str | Unset = "045601",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    report_type: RegulatorsCftcCotCftc | Unset = RegulatorsCftcCotCftc.LEGACY,
    futures_only: bool | Unset = False,
) -> Any | HTTPValidationError | OBBjectCOT | OpenBBErrorResponse | None:
    """Cot

     Get Commitment of Traders Reports.

    Args:
        provider (Literal['cftc'] | Unset):  Default: 'cftc'.
        id (str | Unset): A string with the CFTC market code or other identifying string, such as
            the contract market name, commodity name, or commodity group - i.e, 'gold' or 'japanese
            yen'.Default report is Fed Funds Futures. Use the 'cftc_market_code' for an exact match.
            Default: '045601'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            Default is the most recent report.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        report_type (RegulatorsCftcCotCftc | Unset): The type of report to retrieve. Set `id` as
            'all' to return all items in the report
                        type (default date range returns the latest report). The Legacy report is
            broken down by exchange
                        with reported open interest further broken down into three trader
            classifications: commercial,
                        non-commercial and non-reportable. The Disaggregated reports are broken down
            by Agriculture and
                        Natural Resource contracts. The Disaggregated reports break down reportable
            open interest positions
                        into four classifications: Producer/Merchant, Swap Dealers, Managed Money and
            Other Reportables.
                        The Traders in Financial Futures (TFF) report includes financial contracts.
            The TFF report breaks
                        down the reported open interest into five classifications: Dealer, Asset
            Manager, Leveraged Money,
                        Other Reportables and Non-Reportables. (provider: cftc) Default:
            RegulatorsCftcCotCftc.LEGACY.
        futures_only (bool | Unset): Returns the futures-only report. Default is False, for the
            combined report. (provider: cftc) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCOT | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            id=id,
            start_date=start_date,
            end_date=end_date,
            report_type=report_type,
            futures_only=futures_only,
        )
    ).parsed
