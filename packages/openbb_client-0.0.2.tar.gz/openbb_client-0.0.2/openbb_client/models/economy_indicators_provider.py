from enum import Enum


class EconomyIndicatorsProvider(str, Enum):
    ECONDB = "econdb"
    IMF = "imf"

    def __str__(self) -> str:
        return str(self.value)
