from enum import Enum


class EtfHoldingsProvider(str, Enum):
    AKSHARE = "akshare"
    FMP = "fmp"
    INTRINIO = "intrinio"

    def __str__(self) -> str:
        return str(self.value)
