from enum import Enum


class CommodityPetroleumStatusReportEia(str, Enum):
    BALANCE_SHEET = "balance_sheet"
    CRUDE_PETROLEUM_STOCKS = "crude_petroleum_stocks"
    DISTILLATE_FUEL_OIL_STOCKS = "distillate_fuel_oil_stocks"
    GASOLINE_FUEL_STOCKS = "gasoline_fuel_stocks"
    IMPORTS = "imports"
    IMPORTS_BY_COUNTRY = "imports_by_country"
    INPUTS_AND_PRODUCTION = "inputs_and_production"
    REFINER_BLENDER_NET_PRODUCTION = "refiner_blender_net_production"
    RETAIL_PRICES = "retail_prices"
    SPOT_PRICES_CRUDE_GAS_HEATING = "spot_prices_crude_gas_heating"
    SPOT_PRICES_DIESEL_JET_FUEL_PROPANE = "spot_prices_diesel_jet_fuel_propane"
    TOTAL_GASOLINE_BY_SUB_PADD = "total_gasoline_by_sub_padd"
    WEEKLY_ESTIMATES = "weekly_estimates"

    def __str__(self) -> str:
        return str(self.value)
