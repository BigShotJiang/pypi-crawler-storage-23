from enum import Enum


class EconomyFredRegionalRegionTypeType0(str, Enum):
    BEA = "bea"
    CENSUSREGION = "censusregion"
    COUNTRY = "country"
    COUNTY = "county"
    FRB = "frb"
    MSA = "msa"
    NECTA = "necta"
    STATE = "state"

    def __str__(self) -> str:
        return str(self.value)
