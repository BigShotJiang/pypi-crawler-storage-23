from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="CongressBillsData")


@_attrs_define
class CongressBillsData:
    """Congress Bills Data.

    Attributes:
        update_date (datetime.date): The date the bill was last updated.
        bill_url (str): Base URL to the bill for the congress.gov API.
        congress (int): The congress session number.
        bill_number (int): The bill number.
        origin_chamber (str): The chamber where the bill originated.
        origin_chamber_code (str): The chamber code where the bill originated.
        bill_type (str): The type of bill (e.g., HR, S).
        title (str): The title of the bill.
        latest_action_date (datetime.date | None | Unset): The date of the latest action on the bill.
        latest_action (None | str | Unset): Latest action information for the bill.
        update_date_including_text (datetime.datetime | None | Unset): The date and time the bill text was last updated.
    """

    update_date: datetime.date
    bill_url: str
    congress: int
    bill_number: int
    origin_chamber: str
    origin_chamber_code: str
    bill_type: str
    title: str
    latest_action_date: datetime.date | None | Unset = UNSET
    latest_action: None | str | Unset = UNSET
    update_date_including_text: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        update_date = self.update_date.isoformat()

        bill_url = self.bill_url

        congress = self.congress

        bill_number = self.bill_number

        origin_chamber = self.origin_chamber

        origin_chamber_code = self.origin_chamber_code

        bill_type = self.bill_type

        title = self.title

        latest_action_date: None | str | Unset
        if isinstance(self.latest_action_date, Unset):
            latest_action_date = UNSET
        elif isinstance(self.latest_action_date, datetime.date):
            latest_action_date = self.latest_action_date.isoformat()
        else:
            latest_action_date = self.latest_action_date

        latest_action: None | str | Unset
        if isinstance(self.latest_action, Unset):
            latest_action = UNSET
        else:
            latest_action = self.latest_action

        update_date_including_text: None | str | Unset
        if isinstance(self.update_date_including_text, Unset):
            update_date_including_text = UNSET
        elif isinstance(self.update_date_including_text, datetime.datetime):
            update_date_including_text = self.update_date_including_text.isoformat()
        else:
            update_date_including_text = self.update_date_including_text

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "update_date": update_date,
                "bill_url": bill_url,
                "congress": congress,
                "bill_number": bill_number,
                "origin_chamber": origin_chamber,
                "origin_chamber_code": origin_chamber_code,
                "bill_type": bill_type,
                "title": title,
            }
        )
        if latest_action_date is not UNSET:
            field_dict["latest_action_date"] = latest_action_date
        if latest_action is not UNSET:
            field_dict["latest_action"] = latest_action
        if update_date_including_text is not UNSET:
            field_dict["update_date_including_text"] = update_date_including_text

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        update_date = isoparse(d.pop("update_date")).date()

        bill_url = d.pop("bill_url")

        congress = d.pop("congress")

        bill_number = d.pop("bill_number")

        origin_chamber = d.pop("origin_chamber")

        origin_chamber_code = d.pop("origin_chamber_code")

        bill_type = d.pop("bill_type")

        title = d.pop("title")

        def _parse_latest_action_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                latest_action_date_type_0 = isoparse(data).date()

                return latest_action_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        latest_action_date = _parse_latest_action_date(d.pop("latest_action_date", UNSET))

        def _parse_latest_action(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        latest_action = _parse_latest_action(d.pop("latest_action", UNSET))

        def _parse_update_date_including_text(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                update_date_including_text_type_0 = isoparse(data)

                return update_date_including_text_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        update_date_including_text = _parse_update_date_including_text(d.pop("update_date_including_text", UNSET))

        congress_bills_data = cls(
            update_date=update_date,
            bill_url=bill_url,
            congress=congress,
            bill_number=bill_number,
            origin_chamber=origin_chamber,
            origin_chamber_code=origin_chamber_code,
            bill_type=bill_type,
            title=title,
            latest_action_date=latest_action_date,
            latest_action=latest_action,
            update_date_including_text=update_date_including_text,
        )

        congress_bills_data.additional_properties = d
        return congress_bills_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
