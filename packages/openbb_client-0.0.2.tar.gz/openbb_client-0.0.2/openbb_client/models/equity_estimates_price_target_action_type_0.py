from enum import Enum


class EquityEstimatesPriceTargetActionType0(str, Enum):
    ASSUMES = "assumes"
    DOWNGRADES = "downgrades"
    FIRM_DISSOLVED = "firm_dissolved"
    INITIATES = "initiates"
    MAINTAINS = "maintains"
    REINSTATES = "reinstates"
    REITERATES = "reiterates"
    REMOVES = "removes"
    SUSPENDS = "suspends"
    TERMINATES = "terminates"
    UPGRADES = "upgrades"

    def __str__(self) -> str:
        return str(self.value)
