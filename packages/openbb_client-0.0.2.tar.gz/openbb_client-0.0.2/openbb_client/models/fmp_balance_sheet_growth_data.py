from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FMPBalanceSheetGrowthData")


@_attrs_define
class FMPBalanceSheetGrowthData:
    """FMP Balance Sheet Growth Data.

    Attributes:
        period_ending (datetime.date): The end date of the reporting period.
        symbol (str): Symbol representing the entity requested in the data.
        growth_property_plant_equipment_net (float | None): Growth rate of net property, plant, and equipment.
        growth_goodwill (float | None): Growth rate of goodwill.
        growth_intangible_assets (float | None): Growth rate of intangible assets.
        growth_goodwill_and_intangible_assets (float | None): Growth rate of goodwill and intangible assets.
        growth_other_liabilities (float | None): Growth rate of other liabilities.
        growth_total_liabilities (float | None): Growth rate of total liabilities.
        growth_retained_earnings (float | None): Growth rate of retained earnings.
        growth_accumulated_other_comprehensive_income (float | None): Growth rate of accumulated other comprehensive
            income/loss.
        growth_common_stock (float | None): Growth rate of common stock.
        growth_preferred_stock (float | None): Growth rate of preferred stock.
        fiscal_period (None | str | Unset): The fiscal period of the report.
        fiscal_year (int | None | Unset): The fiscal year of the fiscal period.
        reported_currency (None | str | Unset): The currency in which the financial data is reported.
        growth_cash_and_cash_equivalents (float | None | Unset): Growth rate of cash and cash equivalents.
        growth_short_term_investments (float | None | Unset): Growth rate of short-term investments.
        growth_cash_and_short_term_investments (float | None | Unset): Growth rate of cash and short-term investments.
        growth_accounts_receivables (float | None | Unset): Growth rate of accounts receivable.
        growth_other_receivables (float | None | Unset): Growth rate of other receivables.
        growth_net_receivables (float | None | Unset): Growth rate of net receivables.
        growth_inventory (float | None | Unset): Growth rate of inventory.
        growth_other_current_assets (float | None | Unset): Growth rate of other current assets.
        growth_total_current_assets (float | None | Unset): Growth rate of total current assets.
        growth_long_term_investments (float | None | Unset): Growth rate of long-term investments.
        growth_tax_assets (float | None | Unset): Growth rate of tax assets.
        growth_other_non_current_assets (float | None | Unset): Growth rate of other non-current assets.
        growth_total_non_current_assets (float | None | Unset): Growth rate of total non-current assets.
        growth_other_assets (float | None | Unset): Growth rate of other assets.
        growth_total_assets (float | None | Unset): Growth rate of total assets.
        growth_account_payables (float | None | Unset): Growth rate of accounts payable.
        growth_other_payables (float | None | Unset): Growth rate of other payables.
        growth_total_payables (float | None | Unset): Growth rate of total payables.
        growth_accrued_expenses (float | None | Unset): Growth rate of accrued expenses.
        growth_prepaid_expenses (float | None | Unset): Growth rate of prepaid expenses.
        growth_capital_lease_obligations_current (float | None | Unset): Growth rate of current capital lease
            obligations.
        growth_short_term_debt (float | None | Unset): Growth rate of short-term debt.
        growth_tax_payables (float | None | Unset): Growth rate of tax payables.
        growth_deferred_tax_liabilities_non_current (float | None | Unset): Growth rate of non-current deferred tax
            liabilities.
        growth_deferred_revenue (float | None | Unset): Growth rate of deferred revenue.
        growth_other_current_liabilities (float | None | Unset): Growth rate of other current liabilities.
        growth_total_current_liabilities (float | None | Unset): Growth rate of total current liabilities.
        growth_deferred_revenue_non_current (float | None | Unset): Growth rate of non-current deferred revenue.
        growth_long_term_debt (float | None | Unset): Growth rate of long-term debt.
        growth_deferrred_tax_liabilities_non_current (float | None | Unset): Growth rate of non-current deferred tax
            liabilities.
        growth_other_non_current_liabilities (float | None | Unset): Growth rate of other non-current liabilities.
        growth_total_non_current_liabilities (float | None | Unset): Growth rate of total non-current liabilities.
        growth_minority_interest (float | None | Unset): Growth rate of minority interest.
        growth_additional_paid_in_capital (float | None | Unset): Growth rate of additional paid-in capital.
        growth_other_total_shareholders_equity (float | None | Unset): Growth rate of other total stockholders' equity.
        growth_total_shareholders_equity (float | None | Unset): Growth rate of total stockholders' equity.
        growth_treasury_stock (float | None | Unset): Growth rate of treasury stock.
        growth_total_equity (float | None | Unset): Growth rate of total equity.
        growth_total_liabilities_and_shareholders_equity (float | None | Unset): Growth rate of total liabilities and
            stockholders' equity.
        growth_total_investments (float | None | Unset): Growth rate of total investments.
        growth_total_debt (float | None | Unset): Growth rate of total debt.
        growth_net_debt (float | None | Unset): Growth rate of net debt.
    """

    period_ending: datetime.date
    symbol: str
    growth_property_plant_equipment_net: float | None
    growth_goodwill: float | None
    growth_intangible_assets: float | None
    growth_goodwill_and_intangible_assets: float | None
    growth_other_liabilities: float | None
    growth_total_liabilities: float | None
    growth_retained_earnings: float | None
    growth_accumulated_other_comprehensive_income: float | None
    growth_common_stock: float | None
    growth_preferred_stock: float | None
    fiscal_period: None | str | Unset = UNSET
    fiscal_year: int | None | Unset = UNSET
    reported_currency: None | str | Unset = UNSET
    growth_cash_and_cash_equivalents: float | None | Unset = UNSET
    growth_short_term_investments: float | None | Unset = UNSET
    growth_cash_and_short_term_investments: float | None | Unset = UNSET
    growth_accounts_receivables: float | None | Unset = UNSET
    growth_other_receivables: float | None | Unset = UNSET
    growth_net_receivables: float | None | Unset = UNSET
    growth_inventory: float | None | Unset = UNSET
    growth_other_current_assets: float | None | Unset = UNSET
    growth_total_current_assets: float | None | Unset = UNSET
    growth_long_term_investments: float | None | Unset = UNSET
    growth_tax_assets: float | None | Unset = UNSET
    growth_other_non_current_assets: float | None | Unset = UNSET
    growth_total_non_current_assets: float | None | Unset = UNSET
    growth_other_assets: float | None | Unset = UNSET
    growth_total_assets: float | None | Unset = UNSET
    growth_account_payables: float | None | Unset = UNSET
    growth_other_payables: float | None | Unset = UNSET
    growth_total_payables: float | None | Unset = UNSET
    growth_accrued_expenses: float | None | Unset = UNSET
    growth_prepaid_expenses: float | None | Unset = UNSET
    growth_capital_lease_obligations_current: float | None | Unset = UNSET
    growth_short_term_debt: float | None | Unset = UNSET
    growth_tax_payables: float | None | Unset = UNSET
    growth_deferred_tax_liabilities_non_current: float | None | Unset = UNSET
    growth_deferred_revenue: float | None | Unset = UNSET
    growth_other_current_liabilities: float | None | Unset = UNSET
    growth_total_current_liabilities: float | None | Unset = UNSET
    growth_deferred_revenue_non_current: float | None | Unset = UNSET
    growth_long_term_debt: float | None | Unset = UNSET
    growth_deferrred_tax_liabilities_non_current: float | None | Unset = UNSET
    growth_other_non_current_liabilities: float | None | Unset = UNSET
    growth_total_non_current_liabilities: float | None | Unset = UNSET
    growth_minority_interest: float | None | Unset = UNSET
    growth_additional_paid_in_capital: float | None | Unset = UNSET
    growth_other_total_shareholders_equity: float | None | Unset = UNSET
    growth_total_shareholders_equity: float | None | Unset = UNSET
    growth_treasury_stock: float | None | Unset = UNSET
    growth_total_equity: float | None | Unset = UNSET
    growth_total_liabilities_and_shareholders_equity: float | None | Unset = UNSET
    growth_total_investments: float | None | Unset = UNSET
    growth_total_debt: float | None | Unset = UNSET
    growth_net_debt: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        period_ending = self.period_ending.isoformat()

        symbol = self.symbol

        growth_property_plant_equipment_net: float | None
        growth_property_plant_equipment_net = self.growth_property_plant_equipment_net

        growth_goodwill: float | None
        growth_goodwill = self.growth_goodwill

        growth_intangible_assets: float | None
        growth_intangible_assets = self.growth_intangible_assets

        growth_goodwill_and_intangible_assets: float | None
        growth_goodwill_and_intangible_assets = self.growth_goodwill_and_intangible_assets

        growth_other_liabilities: float | None
        growth_other_liabilities = self.growth_other_liabilities

        growth_total_liabilities: float | None
        growth_total_liabilities = self.growth_total_liabilities

        growth_retained_earnings: float | None
        growth_retained_earnings = self.growth_retained_earnings

        growth_accumulated_other_comprehensive_income: float | None
        growth_accumulated_other_comprehensive_income = self.growth_accumulated_other_comprehensive_income

        growth_common_stock: float | None
        growth_common_stock = self.growth_common_stock

        growth_preferred_stock: float | None
        growth_preferred_stock = self.growth_preferred_stock

        fiscal_period: None | str | Unset
        if isinstance(self.fiscal_period, Unset):
            fiscal_period = UNSET
        else:
            fiscal_period = self.fiscal_period

        fiscal_year: int | None | Unset
        if isinstance(self.fiscal_year, Unset):
            fiscal_year = UNSET
        else:
            fiscal_year = self.fiscal_year

        reported_currency: None | str | Unset
        if isinstance(self.reported_currency, Unset):
            reported_currency = UNSET
        else:
            reported_currency = self.reported_currency

        growth_cash_and_cash_equivalents: float | None | Unset
        if isinstance(self.growth_cash_and_cash_equivalents, Unset):
            growth_cash_and_cash_equivalents = UNSET
        else:
            growth_cash_and_cash_equivalents = self.growth_cash_and_cash_equivalents

        growth_short_term_investments: float | None | Unset
        if isinstance(self.growth_short_term_investments, Unset):
            growth_short_term_investments = UNSET
        else:
            growth_short_term_investments = self.growth_short_term_investments

        growth_cash_and_short_term_investments: float | None | Unset
        if isinstance(self.growth_cash_and_short_term_investments, Unset):
            growth_cash_and_short_term_investments = UNSET
        else:
            growth_cash_and_short_term_investments = self.growth_cash_and_short_term_investments

        growth_accounts_receivables: float | None | Unset
        if isinstance(self.growth_accounts_receivables, Unset):
            growth_accounts_receivables = UNSET
        else:
            growth_accounts_receivables = self.growth_accounts_receivables

        growth_other_receivables: float | None | Unset
        if isinstance(self.growth_other_receivables, Unset):
            growth_other_receivables = UNSET
        else:
            growth_other_receivables = self.growth_other_receivables

        growth_net_receivables: float | None | Unset
        if isinstance(self.growth_net_receivables, Unset):
            growth_net_receivables = UNSET
        else:
            growth_net_receivables = self.growth_net_receivables

        growth_inventory: float | None | Unset
        if isinstance(self.growth_inventory, Unset):
            growth_inventory = UNSET
        else:
            growth_inventory = self.growth_inventory

        growth_other_current_assets: float | None | Unset
        if isinstance(self.growth_other_current_assets, Unset):
            growth_other_current_assets = UNSET
        else:
            growth_other_current_assets = self.growth_other_current_assets

        growth_total_current_assets: float | None | Unset
        if isinstance(self.growth_total_current_assets, Unset):
            growth_total_current_assets = UNSET
        else:
            growth_total_current_assets = self.growth_total_current_assets

        growth_long_term_investments: float | None | Unset
        if isinstance(self.growth_long_term_investments, Unset):
            growth_long_term_investments = UNSET
        else:
            growth_long_term_investments = self.growth_long_term_investments

        growth_tax_assets: float | None | Unset
        if isinstance(self.growth_tax_assets, Unset):
            growth_tax_assets = UNSET
        else:
            growth_tax_assets = self.growth_tax_assets

        growth_other_non_current_assets: float | None | Unset
        if isinstance(self.growth_other_non_current_assets, Unset):
            growth_other_non_current_assets = UNSET
        else:
            growth_other_non_current_assets = self.growth_other_non_current_assets

        growth_total_non_current_assets: float | None | Unset
        if isinstance(self.growth_total_non_current_assets, Unset):
            growth_total_non_current_assets = UNSET
        else:
            growth_total_non_current_assets = self.growth_total_non_current_assets

        growth_other_assets: float | None | Unset
        if isinstance(self.growth_other_assets, Unset):
            growth_other_assets = UNSET
        else:
            growth_other_assets = self.growth_other_assets

        growth_total_assets: float | None | Unset
        if isinstance(self.growth_total_assets, Unset):
            growth_total_assets = UNSET
        else:
            growth_total_assets = self.growth_total_assets

        growth_account_payables: float | None | Unset
        if isinstance(self.growth_account_payables, Unset):
            growth_account_payables = UNSET
        else:
            growth_account_payables = self.growth_account_payables

        growth_other_payables: float | None | Unset
        if isinstance(self.growth_other_payables, Unset):
            growth_other_payables = UNSET
        else:
            growth_other_payables = self.growth_other_payables

        growth_total_payables: float | None | Unset
        if isinstance(self.growth_total_payables, Unset):
            growth_total_payables = UNSET
        else:
            growth_total_payables = self.growth_total_payables

        growth_accrued_expenses: float | None | Unset
        if isinstance(self.growth_accrued_expenses, Unset):
            growth_accrued_expenses = UNSET
        else:
            growth_accrued_expenses = self.growth_accrued_expenses

        growth_prepaid_expenses: float | None | Unset
        if isinstance(self.growth_prepaid_expenses, Unset):
            growth_prepaid_expenses = UNSET
        else:
            growth_prepaid_expenses = self.growth_prepaid_expenses

        growth_capital_lease_obligations_current: float | None | Unset
        if isinstance(self.growth_capital_lease_obligations_current, Unset):
            growth_capital_lease_obligations_current = UNSET
        else:
            growth_capital_lease_obligations_current = self.growth_capital_lease_obligations_current

        growth_short_term_debt: float | None | Unset
        if isinstance(self.growth_short_term_debt, Unset):
            growth_short_term_debt = UNSET
        else:
            growth_short_term_debt = self.growth_short_term_debt

        growth_tax_payables: float | None | Unset
        if isinstance(self.growth_tax_payables, Unset):
            growth_tax_payables = UNSET
        else:
            growth_tax_payables = self.growth_tax_payables

        growth_deferred_tax_liabilities_non_current: float | None | Unset
        if isinstance(self.growth_deferred_tax_liabilities_non_current, Unset):
            growth_deferred_tax_liabilities_non_current = UNSET
        else:
            growth_deferred_tax_liabilities_non_current = self.growth_deferred_tax_liabilities_non_current

        growth_deferred_revenue: float | None | Unset
        if isinstance(self.growth_deferred_revenue, Unset):
            growth_deferred_revenue = UNSET
        else:
            growth_deferred_revenue = self.growth_deferred_revenue

        growth_other_current_liabilities: float | None | Unset
        if isinstance(self.growth_other_current_liabilities, Unset):
            growth_other_current_liabilities = UNSET
        else:
            growth_other_current_liabilities = self.growth_other_current_liabilities

        growth_total_current_liabilities: float | None | Unset
        if isinstance(self.growth_total_current_liabilities, Unset):
            growth_total_current_liabilities = UNSET
        else:
            growth_total_current_liabilities = self.growth_total_current_liabilities

        growth_deferred_revenue_non_current: float | None | Unset
        if isinstance(self.growth_deferred_revenue_non_current, Unset):
            growth_deferred_revenue_non_current = UNSET
        else:
            growth_deferred_revenue_non_current = self.growth_deferred_revenue_non_current

        growth_long_term_debt: float | None | Unset
        if isinstance(self.growth_long_term_debt, Unset):
            growth_long_term_debt = UNSET
        else:
            growth_long_term_debt = self.growth_long_term_debt

        growth_deferrred_tax_liabilities_non_current: float | None | Unset
        if isinstance(self.growth_deferrred_tax_liabilities_non_current, Unset):
            growth_deferrred_tax_liabilities_non_current = UNSET
        else:
            growth_deferrred_tax_liabilities_non_current = self.growth_deferrred_tax_liabilities_non_current

        growth_other_non_current_liabilities: float | None | Unset
        if isinstance(self.growth_other_non_current_liabilities, Unset):
            growth_other_non_current_liabilities = UNSET
        else:
            growth_other_non_current_liabilities = self.growth_other_non_current_liabilities

        growth_total_non_current_liabilities: float | None | Unset
        if isinstance(self.growth_total_non_current_liabilities, Unset):
            growth_total_non_current_liabilities = UNSET
        else:
            growth_total_non_current_liabilities = self.growth_total_non_current_liabilities

        growth_minority_interest: float | None | Unset
        if isinstance(self.growth_minority_interest, Unset):
            growth_minority_interest = UNSET
        else:
            growth_minority_interest = self.growth_minority_interest

        growth_additional_paid_in_capital: float | None | Unset
        if isinstance(self.growth_additional_paid_in_capital, Unset):
            growth_additional_paid_in_capital = UNSET
        else:
            growth_additional_paid_in_capital = self.growth_additional_paid_in_capital

        growth_other_total_shareholders_equity: float | None | Unset
        if isinstance(self.growth_other_total_shareholders_equity, Unset):
            growth_other_total_shareholders_equity = UNSET
        else:
            growth_other_total_shareholders_equity = self.growth_other_total_shareholders_equity

        growth_total_shareholders_equity: float | None | Unset
        if isinstance(self.growth_total_shareholders_equity, Unset):
            growth_total_shareholders_equity = UNSET
        else:
            growth_total_shareholders_equity = self.growth_total_shareholders_equity

        growth_treasury_stock: float | None | Unset
        if isinstance(self.growth_treasury_stock, Unset):
            growth_treasury_stock = UNSET
        else:
            growth_treasury_stock = self.growth_treasury_stock

        growth_total_equity: float | None | Unset
        if isinstance(self.growth_total_equity, Unset):
            growth_total_equity = UNSET
        else:
            growth_total_equity = self.growth_total_equity

        growth_total_liabilities_and_shareholders_equity: float | None | Unset
        if isinstance(self.growth_total_liabilities_and_shareholders_equity, Unset):
            growth_total_liabilities_and_shareholders_equity = UNSET
        else:
            growth_total_liabilities_and_shareholders_equity = self.growth_total_liabilities_and_shareholders_equity

        growth_total_investments: float | None | Unset
        if isinstance(self.growth_total_investments, Unset):
            growth_total_investments = UNSET
        else:
            growth_total_investments = self.growth_total_investments

        growth_total_debt: float | None | Unset
        if isinstance(self.growth_total_debt, Unset):
            growth_total_debt = UNSET
        else:
            growth_total_debt = self.growth_total_debt

        growth_net_debt: float | None | Unset
        if isinstance(self.growth_net_debt, Unset):
            growth_net_debt = UNSET
        else:
            growth_net_debt = self.growth_net_debt

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "period_ending": period_ending,
                "symbol": symbol,
                "growth_property_plant_equipment_net": growth_property_plant_equipment_net,
                "growth_goodwill": growth_goodwill,
                "growth_intangible_assets": growth_intangible_assets,
                "growth_goodwill_and_intangible_assets": growth_goodwill_and_intangible_assets,
                "growth_other_liabilities": growth_other_liabilities,
                "growth_total_liabilities": growth_total_liabilities,
                "growth_retained_earnings": growth_retained_earnings,
                "growth_accumulated_other_comprehensive_income": growth_accumulated_other_comprehensive_income,
                "growth_common_stock": growth_common_stock,
                "growth_preferred_stock": growth_preferred_stock,
            }
        )
        if fiscal_period is not UNSET:
            field_dict["fiscal_period"] = fiscal_period
        if fiscal_year is not UNSET:
            field_dict["fiscal_year"] = fiscal_year
        if reported_currency is not UNSET:
            field_dict["reported_currency"] = reported_currency
        if growth_cash_and_cash_equivalents is not UNSET:
            field_dict["growth_cash_and_cash_equivalents"] = growth_cash_and_cash_equivalents
        if growth_short_term_investments is not UNSET:
            field_dict["growth_short_term_investments"] = growth_short_term_investments
        if growth_cash_and_short_term_investments is not UNSET:
            field_dict["growth_cash_and_short_term_investments"] = growth_cash_and_short_term_investments
        if growth_accounts_receivables is not UNSET:
            field_dict["growth_accounts_receivables"] = growth_accounts_receivables
        if growth_other_receivables is not UNSET:
            field_dict["growth_other_receivables"] = growth_other_receivables
        if growth_net_receivables is not UNSET:
            field_dict["growth_net_receivables"] = growth_net_receivables
        if growth_inventory is not UNSET:
            field_dict["growth_inventory"] = growth_inventory
        if growth_other_current_assets is not UNSET:
            field_dict["growth_other_current_assets"] = growth_other_current_assets
        if growth_total_current_assets is not UNSET:
            field_dict["growth_total_current_assets"] = growth_total_current_assets
        if growth_long_term_investments is not UNSET:
            field_dict["growth_long_term_investments"] = growth_long_term_investments
        if growth_tax_assets is not UNSET:
            field_dict["growth_tax_assets"] = growth_tax_assets
        if growth_other_non_current_assets is not UNSET:
            field_dict["growth_other_non_current_assets"] = growth_other_non_current_assets
        if growth_total_non_current_assets is not UNSET:
            field_dict["growth_total_non_current_assets"] = growth_total_non_current_assets
        if growth_other_assets is not UNSET:
            field_dict["growth_other_assets"] = growth_other_assets
        if growth_total_assets is not UNSET:
            field_dict["growth_total_assets"] = growth_total_assets
        if growth_account_payables is not UNSET:
            field_dict["growth_account_payables"] = growth_account_payables
        if growth_other_payables is not UNSET:
            field_dict["growth_other_payables"] = growth_other_payables
        if growth_total_payables is not UNSET:
            field_dict["growth_total_payables"] = growth_total_payables
        if growth_accrued_expenses is not UNSET:
            field_dict["growth_accrued_expenses"] = growth_accrued_expenses
        if growth_prepaid_expenses is not UNSET:
            field_dict["growth_prepaid_expenses"] = growth_prepaid_expenses
        if growth_capital_lease_obligations_current is not UNSET:
            field_dict["growth_capital_lease_obligations_current"] = growth_capital_lease_obligations_current
        if growth_short_term_debt is not UNSET:
            field_dict["growth_short_term_debt"] = growth_short_term_debt
        if growth_tax_payables is not UNSET:
            field_dict["growth_tax_payables"] = growth_tax_payables
        if growth_deferred_tax_liabilities_non_current is not UNSET:
            field_dict["growth_deferred_tax_liabilities_non_current"] = growth_deferred_tax_liabilities_non_current
        if growth_deferred_revenue is not UNSET:
            field_dict["growth_deferred_revenue"] = growth_deferred_revenue
        if growth_other_current_liabilities is not UNSET:
            field_dict["growth_other_current_liabilities"] = growth_other_current_liabilities
        if growth_total_current_liabilities is not UNSET:
            field_dict["growth_total_current_liabilities"] = growth_total_current_liabilities
        if growth_deferred_revenue_non_current is not UNSET:
            field_dict["growth_deferred_revenue_non_current"] = growth_deferred_revenue_non_current
        if growth_long_term_debt is not UNSET:
            field_dict["growth_long_term_debt"] = growth_long_term_debt
        if growth_deferrred_tax_liabilities_non_current is not UNSET:
            field_dict["growth_deferrred_tax_liabilities_non_current"] = growth_deferrred_tax_liabilities_non_current
        if growth_other_non_current_liabilities is not UNSET:
            field_dict["growth_other_non_current_liabilities"] = growth_other_non_current_liabilities
        if growth_total_non_current_liabilities is not UNSET:
            field_dict["growth_total_non_current_liabilities"] = growth_total_non_current_liabilities
        if growth_minority_interest is not UNSET:
            field_dict["growth_minority_interest"] = growth_minority_interest
        if growth_additional_paid_in_capital is not UNSET:
            field_dict["growth_additional_paid_in_capital"] = growth_additional_paid_in_capital
        if growth_other_total_shareholders_equity is not UNSET:
            field_dict["growth_other_total_shareholders_equity"] = growth_other_total_shareholders_equity
        if growth_total_shareholders_equity is not UNSET:
            field_dict["growth_total_shareholders_equity"] = growth_total_shareholders_equity
        if growth_treasury_stock is not UNSET:
            field_dict["growth_treasury_stock"] = growth_treasury_stock
        if growth_total_equity is not UNSET:
            field_dict["growth_total_equity"] = growth_total_equity
        if growth_total_liabilities_and_shareholders_equity is not UNSET:
            field_dict["growth_total_liabilities_and_shareholders_equity"] = (
                growth_total_liabilities_and_shareholders_equity
            )
        if growth_total_investments is not UNSET:
            field_dict["growth_total_investments"] = growth_total_investments
        if growth_total_debt is not UNSET:
            field_dict["growth_total_debt"] = growth_total_debt
        if growth_net_debt is not UNSET:
            field_dict["growth_net_debt"] = growth_net_debt

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        period_ending = isoparse(d.pop("period_ending")).date()

        symbol = d.pop("symbol")

        def _parse_growth_property_plant_equipment_net(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        growth_property_plant_equipment_net = _parse_growth_property_plant_equipment_net(
            d.pop("growth_property_plant_equipment_net")
        )

        def _parse_growth_goodwill(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        growth_goodwill = _parse_growth_goodwill(d.pop("growth_goodwill"))

        def _parse_growth_intangible_assets(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        growth_intangible_assets = _parse_growth_intangible_assets(d.pop("growth_intangible_assets"))

        def _parse_growth_goodwill_and_intangible_assets(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        growth_goodwill_and_intangible_assets = _parse_growth_goodwill_and_intangible_assets(
            d.pop("growth_goodwill_and_intangible_assets")
        )

        def _parse_growth_other_liabilities(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        growth_other_liabilities = _parse_growth_other_liabilities(d.pop("growth_other_liabilities"))

        def _parse_growth_total_liabilities(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        growth_total_liabilities = _parse_growth_total_liabilities(d.pop("growth_total_liabilities"))

        def _parse_growth_retained_earnings(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        growth_retained_earnings = _parse_growth_retained_earnings(d.pop("growth_retained_earnings"))

        def _parse_growth_accumulated_other_comprehensive_income(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        growth_accumulated_other_comprehensive_income = _parse_growth_accumulated_other_comprehensive_income(
            d.pop("growth_accumulated_other_comprehensive_income")
        )

        def _parse_growth_common_stock(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        growth_common_stock = _parse_growth_common_stock(d.pop("growth_common_stock"))

        def _parse_growth_preferred_stock(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        growth_preferred_stock = _parse_growth_preferred_stock(d.pop("growth_preferred_stock"))

        def _parse_fiscal_period(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        fiscal_period = _parse_fiscal_period(d.pop("fiscal_period", UNSET))

        def _parse_fiscal_year(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        fiscal_year = _parse_fiscal_year(d.pop("fiscal_year", UNSET))

        def _parse_reported_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reported_currency = _parse_reported_currency(d.pop("reported_currency", UNSET))

        def _parse_growth_cash_and_cash_equivalents(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_cash_and_cash_equivalents = _parse_growth_cash_and_cash_equivalents(
            d.pop("growth_cash_and_cash_equivalents", UNSET)
        )

        def _parse_growth_short_term_investments(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_short_term_investments = _parse_growth_short_term_investments(
            d.pop("growth_short_term_investments", UNSET)
        )

        def _parse_growth_cash_and_short_term_investments(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_cash_and_short_term_investments = _parse_growth_cash_and_short_term_investments(
            d.pop("growth_cash_and_short_term_investments", UNSET)
        )

        def _parse_growth_accounts_receivables(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_accounts_receivables = _parse_growth_accounts_receivables(d.pop("growth_accounts_receivables", UNSET))

        def _parse_growth_other_receivables(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_other_receivables = _parse_growth_other_receivables(d.pop("growth_other_receivables", UNSET))

        def _parse_growth_net_receivables(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_net_receivables = _parse_growth_net_receivables(d.pop("growth_net_receivables", UNSET))

        def _parse_growth_inventory(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_inventory = _parse_growth_inventory(d.pop("growth_inventory", UNSET))

        def _parse_growth_other_current_assets(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_other_current_assets = _parse_growth_other_current_assets(d.pop("growth_other_current_assets", UNSET))

        def _parse_growth_total_current_assets(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_total_current_assets = _parse_growth_total_current_assets(d.pop("growth_total_current_assets", UNSET))

        def _parse_growth_long_term_investments(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_long_term_investments = _parse_growth_long_term_investments(d.pop("growth_long_term_investments", UNSET))

        def _parse_growth_tax_assets(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_tax_assets = _parse_growth_tax_assets(d.pop("growth_tax_assets", UNSET))

        def _parse_growth_other_non_current_assets(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_other_non_current_assets = _parse_growth_other_non_current_assets(
            d.pop("growth_other_non_current_assets", UNSET)
        )

        def _parse_growth_total_non_current_assets(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_total_non_current_assets = _parse_growth_total_non_current_assets(
            d.pop("growth_total_non_current_assets", UNSET)
        )

        def _parse_growth_other_assets(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_other_assets = _parse_growth_other_assets(d.pop("growth_other_assets", UNSET))

        def _parse_growth_total_assets(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_total_assets = _parse_growth_total_assets(d.pop("growth_total_assets", UNSET))

        def _parse_growth_account_payables(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_account_payables = _parse_growth_account_payables(d.pop("growth_account_payables", UNSET))

        def _parse_growth_other_payables(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_other_payables = _parse_growth_other_payables(d.pop("growth_other_payables", UNSET))

        def _parse_growth_total_payables(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_total_payables = _parse_growth_total_payables(d.pop("growth_total_payables", UNSET))

        def _parse_growth_accrued_expenses(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_accrued_expenses = _parse_growth_accrued_expenses(d.pop("growth_accrued_expenses", UNSET))

        def _parse_growth_prepaid_expenses(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_prepaid_expenses = _parse_growth_prepaid_expenses(d.pop("growth_prepaid_expenses", UNSET))

        def _parse_growth_capital_lease_obligations_current(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_capital_lease_obligations_current = _parse_growth_capital_lease_obligations_current(
            d.pop("growth_capital_lease_obligations_current", UNSET)
        )

        def _parse_growth_short_term_debt(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_short_term_debt = _parse_growth_short_term_debt(d.pop("growth_short_term_debt", UNSET))

        def _parse_growth_tax_payables(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_tax_payables = _parse_growth_tax_payables(d.pop("growth_tax_payables", UNSET))

        def _parse_growth_deferred_tax_liabilities_non_current(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_deferred_tax_liabilities_non_current = _parse_growth_deferred_tax_liabilities_non_current(
            d.pop("growth_deferred_tax_liabilities_non_current", UNSET)
        )

        def _parse_growth_deferred_revenue(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_deferred_revenue = _parse_growth_deferred_revenue(d.pop("growth_deferred_revenue", UNSET))

        def _parse_growth_other_current_liabilities(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_other_current_liabilities = _parse_growth_other_current_liabilities(
            d.pop("growth_other_current_liabilities", UNSET)
        )

        def _parse_growth_total_current_liabilities(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_total_current_liabilities = _parse_growth_total_current_liabilities(
            d.pop("growth_total_current_liabilities", UNSET)
        )

        def _parse_growth_deferred_revenue_non_current(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_deferred_revenue_non_current = _parse_growth_deferred_revenue_non_current(
            d.pop("growth_deferred_revenue_non_current", UNSET)
        )

        def _parse_growth_long_term_debt(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_long_term_debt = _parse_growth_long_term_debt(d.pop("growth_long_term_debt", UNSET))

        def _parse_growth_deferrred_tax_liabilities_non_current(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_deferrred_tax_liabilities_non_current = _parse_growth_deferrred_tax_liabilities_non_current(
            d.pop("growth_deferrred_tax_liabilities_non_current", UNSET)
        )

        def _parse_growth_other_non_current_liabilities(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_other_non_current_liabilities = _parse_growth_other_non_current_liabilities(
            d.pop("growth_other_non_current_liabilities", UNSET)
        )

        def _parse_growth_total_non_current_liabilities(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_total_non_current_liabilities = _parse_growth_total_non_current_liabilities(
            d.pop("growth_total_non_current_liabilities", UNSET)
        )

        def _parse_growth_minority_interest(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_minority_interest = _parse_growth_minority_interest(d.pop("growth_minority_interest", UNSET))

        def _parse_growth_additional_paid_in_capital(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_additional_paid_in_capital = _parse_growth_additional_paid_in_capital(
            d.pop("growth_additional_paid_in_capital", UNSET)
        )

        def _parse_growth_other_total_shareholders_equity(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_other_total_shareholders_equity = _parse_growth_other_total_shareholders_equity(
            d.pop("growth_other_total_shareholders_equity", UNSET)
        )

        def _parse_growth_total_shareholders_equity(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_total_shareholders_equity = _parse_growth_total_shareholders_equity(
            d.pop("growth_total_shareholders_equity", UNSET)
        )

        def _parse_growth_treasury_stock(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_treasury_stock = _parse_growth_treasury_stock(d.pop("growth_treasury_stock", UNSET))

        def _parse_growth_total_equity(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_total_equity = _parse_growth_total_equity(d.pop("growth_total_equity", UNSET))

        def _parse_growth_total_liabilities_and_shareholders_equity(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_total_liabilities_and_shareholders_equity = _parse_growth_total_liabilities_and_shareholders_equity(
            d.pop("growth_total_liabilities_and_shareholders_equity", UNSET)
        )

        def _parse_growth_total_investments(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_total_investments = _parse_growth_total_investments(d.pop("growth_total_investments", UNSET))

        def _parse_growth_total_debt(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_total_debt = _parse_growth_total_debt(d.pop("growth_total_debt", UNSET))

        def _parse_growth_net_debt(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        growth_net_debt = _parse_growth_net_debt(d.pop("growth_net_debt", UNSET))

        fmp_balance_sheet_growth_data = cls(
            period_ending=period_ending,
            symbol=symbol,
            growth_property_plant_equipment_net=growth_property_plant_equipment_net,
            growth_goodwill=growth_goodwill,
            growth_intangible_assets=growth_intangible_assets,
            growth_goodwill_and_intangible_assets=growth_goodwill_and_intangible_assets,
            growth_other_liabilities=growth_other_liabilities,
            growth_total_liabilities=growth_total_liabilities,
            growth_retained_earnings=growth_retained_earnings,
            growth_accumulated_other_comprehensive_income=growth_accumulated_other_comprehensive_income,
            growth_common_stock=growth_common_stock,
            growth_preferred_stock=growth_preferred_stock,
            fiscal_period=fiscal_period,
            fiscal_year=fiscal_year,
            reported_currency=reported_currency,
            growth_cash_and_cash_equivalents=growth_cash_and_cash_equivalents,
            growth_short_term_investments=growth_short_term_investments,
            growth_cash_and_short_term_investments=growth_cash_and_short_term_investments,
            growth_accounts_receivables=growth_accounts_receivables,
            growth_other_receivables=growth_other_receivables,
            growth_net_receivables=growth_net_receivables,
            growth_inventory=growth_inventory,
            growth_other_current_assets=growth_other_current_assets,
            growth_total_current_assets=growth_total_current_assets,
            growth_long_term_investments=growth_long_term_investments,
            growth_tax_assets=growth_tax_assets,
            growth_other_non_current_assets=growth_other_non_current_assets,
            growth_total_non_current_assets=growth_total_non_current_assets,
            growth_other_assets=growth_other_assets,
            growth_total_assets=growth_total_assets,
            growth_account_payables=growth_account_payables,
            growth_other_payables=growth_other_payables,
            growth_total_payables=growth_total_payables,
            growth_accrued_expenses=growth_accrued_expenses,
            growth_prepaid_expenses=growth_prepaid_expenses,
            growth_capital_lease_obligations_current=growth_capital_lease_obligations_current,
            growth_short_term_debt=growth_short_term_debt,
            growth_tax_payables=growth_tax_payables,
            growth_deferred_tax_liabilities_non_current=growth_deferred_tax_liabilities_non_current,
            growth_deferred_revenue=growth_deferred_revenue,
            growth_other_current_liabilities=growth_other_current_liabilities,
            growth_total_current_liabilities=growth_total_current_liabilities,
            growth_deferred_revenue_non_current=growth_deferred_revenue_non_current,
            growth_long_term_debt=growth_long_term_debt,
            growth_deferrred_tax_liabilities_non_current=growth_deferrred_tax_liabilities_non_current,
            growth_other_non_current_liabilities=growth_other_non_current_liabilities,
            growth_total_non_current_liabilities=growth_total_non_current_liabilities,
            growth_minority_interest=growth_minority_interest,
            growth_additional_paid_in_capital=growth_additional_paid_in_capital,
            growth_other_total_shareholders_equity=growth_other_total_shareholders_equity,
            growth_total_shareholders_equity=growth_total_shareholders_equity,
            growth_treasury_stock=growth_treasury_stock,
            growth_total_equity=growth_total_equity,
            growth_total_liabilities_and_shareholders_equity=growth_total_liabilities_and_shareholders_equity,
            growth_total_investments=growth_total_investments,
            growth_total_debt=growth_total_debt,
            growth_net_debt=growth_net_debt,
        )

        fmp_balance_sheet_growth_data.additional_properties = d
        return fmp_balance_sheet_growth_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
