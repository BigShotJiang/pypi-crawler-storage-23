from enum import Enum


class EquityFundamentalManagementDiscussionAnalysisCalendarPeriodType0(str, Enum):
    Q1 = "Q1"
    Q2 = "Q2"
    Q3 = "Q3"
    Q4 = "Q4"

    def __str__(self) -> str:
        return str(self.value)
