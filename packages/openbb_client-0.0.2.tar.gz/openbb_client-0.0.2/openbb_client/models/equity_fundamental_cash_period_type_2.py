from enum import Enum


class EquityFundamentalCashPeriodType2(str, Enum):
    ANNUAL = "annual"
    QUARTER = "quarter"
    TTM = "ttm"
    YTD = "ytd"

    def __str__(self) -> str:
        return str(self.value)
