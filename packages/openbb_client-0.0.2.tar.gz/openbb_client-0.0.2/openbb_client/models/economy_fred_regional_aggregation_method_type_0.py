from enum import Enum


class EconomyFredRegionalAggregationMethodType0(str, Enum):
    AVG = "avg"
    EOP = "eop"
    SUM = "sum"

    def __str__(self) -> str:
        return str(self.value)
