from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FMPCompanyFilingsData")


@_attrs_define
class FMPCompanyFilingsData:
    """FMP Company Filings Data.

    Attributes:
        filing_date (datetime.date): The date of the filing.
        report_url (str): URL to the actual report.
        report_type (None | str | Unset): Type of filing.
        filing_url (None | str | Unset): URL to the filing page.
        symbol (None | str | Unset): Symbol representing the entity requested in the data.
        cik (None | str | Unset): Central Index Key (CIK) for the requested entity.
        accepted_date (datetime.date | None | Unset): Accepted date of the filing.
    """

    filing_date: datetime.date
    report_url: str
    report_type: None | str | Unset = UNSET
    filing_url: None | str | Unset = UNSET
    symbol: None | str | Unset = UNSET
    cik: None | str | Unset = UNSET
    accepted_date: datetime.date | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        filing_date = self.filing_date.isoformat()

        report_url = self.report_url

        report_type: None | str | Unset
        if isinstance(self.report_type, Unset):
            report_type = UNSET
        else:
            report_type = self.report_type

        filing_url: None | str | Unset
        if isinstance(self.filing_url, Unset):
            filing_url = UNSET
        else:
            filing_url = self.filing_url

        symbol: None | str | Unset
        if isinstance(self.symbol, Unset):
            symbol = UNSET
        else:
            symbol = self.symbol

        cik: None | str | Unset
        if isinstance(self.cik, Unset):
            cik = UNSET
        else:
            cik = self.cik

        accepted_date: None | str | Unset
        if isinstance(self.accepted_date, Unset):
            accepted_date = UNSET
        elif isinstance(self.accepted_date, datetime.date):
            accepted_date = self.accepted_date.isoformat()
        else:
            accepted_date = self.accepted_date

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "filing_date": filing_date,
                "report_url": report_url,
            }
        )
        if report_type is not UNSET:
            field_dict["report_type"] = report_type
        if filing_url is not UNSET:
            field_dict["filing_url"] = filing_url
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if cik is not UNSET:
            field_dict["cik"] = cik
        if accepted_date is not UNSET:
            field_dict["accepted_date"] = accepted_date

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        filing_date = isoparse(d.pop("filing_date")).date()

        report_url = d.pop("report_url")

        def _parse_report_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        report_type = _parse_report_type(d.pop("report_type", UNSET))

        def _parse_filing_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        filing_url = _parse_filing_url(d.pop("filing_url", UNSET))

        def _parse_symbol(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbol = _parse_symbol(d.pop("symbol", UNSET))

        def _parse_cik(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cik = _parse_cik(d.pop("cik", UNSET))

        def _parse_accepted_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                accepted_date_type_0 = isoparse(data).date()

                return accepted_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        accepted_date = _parse_accepted_date(d.pop("accepted_date", UNSET))

        fmp_company_filings_data = cls(
            filing_date=filing_date,
            report_url=report_url,
            report_type=report_type,
            filing_url=filing_url,
            symbol=symbol,
            cik=cik,
            accepted_date=accepted_date,
        )

        fmp_company_filings_data.additional_properties = d
        return fmp_company_filings_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
