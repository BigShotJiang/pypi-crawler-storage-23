from enum import Enum


class EquityDiscoveryLosersProvider(str, Enum):
    FMP = "fmp"
    YFINANCE = "yfinance"

    def __str__(self) -> str:
        return str(self.value)
