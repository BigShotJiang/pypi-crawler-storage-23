from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FMPCryptoSearchData")


@_attrs_define
class FMPCryptoSearchData:
    """FMP Crypto Search Data.

    Attributes:
        symbol (str): Symbol representing the entity requested in the data. (Crypto)
        name (None | str | Unset): Name of the crypto.
        exchange (None | str | Unset): The exchange code the crypto trades on.
        ico_date (datetime.date | None | Unset): The ICO date of the token.
        circulating_supply (float | None | Unset): The circulating supply of the token.
        total_supply (float | None | Unset): The total supply of the token.
    """

    symbol: str
    name: None | str | Unset = UNSET
    exchange: None | str | Unset = UNSET
    ico_date: datetime.date | None | Unset = UNSET
    circulating_supply: float | None | Unset = UNSET
    total_supply: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        symbol = self.symbol

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        exchange: None | str | Unset
        if isinstance(self.exchange, Unset):
            exchange = UNSET
        else:
            exchange = self.exchange

        ico_date: None | str | Unset
        if isinstance(self.ico_date, Unset):
            ico_date = UNSET
        elif isinstance(self.ico_date, datetime.date):
            ico_date = self.ico_date.isoformat()
        else:
            ico_date = self.ico_date

        circulating_supply: float | None | Unset
        if isinstance(self.circulating_supply, Unset):
            circulating_supply = UNSET
        else:
            circulating_supply = self.circulating_supply

        total_supply: float | None | Unset
        if isinstance(self.total_supply, Unset):
            total_supply = UNSET
        else:
            total_supply = self.total_supply

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "symbol": symbol,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name
        if exchange is not UNSET:
            field_dict["exchange"] = exchange
        if ico_date is not UNSET:
            field_dict["ico_date"] = ico_date
        if circulating_supply is not UNSET:
            field_dict["circulating_supply"] = circulating_supply
        if total_supply is not UNSET:
            field_dict["total_supply"] = total_supply

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        symbol = d.pop("symbol")

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_exchange(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        exchange = _parse_exchange(d.pop("exchange", UNSET))

        def _parse_ico_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                ico_date_type_0 = isoparse(data).date()

                return ico_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        ico_date = _parse_ico_date(d.pop("ico_date", UNSET))

        def _parse_circulating_supply(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        circulating_supply = _parse_circulating_supply(d.pop("circulating_supply", UNSET))

        def _parse_total_supply(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        total_supply = _parse_total_supply(d.pop("total_supply", UNSET))

        fmp_crypto_search_data = cls(
            symbol=symbol,
            name=name,
            exchange=exchange,
            ico_date=ico_date,
            circulating_supply=circulating_supply,
            total_supply=total_supply,
        )

        fmp_crypto_search_data.additional_properties = d
        return fmp_crypto_search_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
