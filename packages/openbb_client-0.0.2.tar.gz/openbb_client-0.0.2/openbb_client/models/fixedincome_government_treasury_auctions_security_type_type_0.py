from enum import Enum


class FixedincomeGovernmentTreasuryAuctionsSecurityTypeType0(str, Enum):
    BILL = "bill"
    BOND = "bond"
    CMB = "cmb"
    FRN = "frn"
    NOTE = "note"
    TIPS = "tips"

    def __str__(self) -> str:
        return str(self.value)
