from enum import Enum


class EconomyCpiFrequency(str, Enum):
    ANNUAL = "annual"
    MONTHLY = "monthly"
    QUARTER = "quarter"

    def __str__(self) -> str:
        return str(self.value)
