from enum import Enum


class DerivativesOptionsChainsIntrinio(str, Enum):
    DELAYED = "delayed"
    EOD = "eod"
    REALTIME = "realtime"

    def __str__(self) -> str:
        return str(self.value)
