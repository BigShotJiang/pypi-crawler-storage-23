from enum import Enum


class EquityOwnershipInsiderTradingSortByType0(str, Enum):
    FILING_DATE = "filing_date"
    UPDATED_ON = "updated_on"

    def __str__(self) -> str:
        return str(self.value)
