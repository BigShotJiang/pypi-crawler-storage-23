from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AKShareKeyMetricsData")


@_attrs_define
class AKShareKeyMetricsData:
    """AKShare Key Metrics Data.

    Attributes:
        symbol (str): Symbol representing the entity requested in the data.
        period_ending (datetime.date | None | Unset): End date of the reporting period.
        fiscal_year (int | None | Unset): Fiscal year for the fiscal period, if available.
        fiscal_period (None | str | Unset): Fiscal period for the data, if available.
        currency (None | str | Unset): Currency in which the data is reported.
        market_cap (float | int | None | Unset):
    """

    symbol: str
    period_ending: datetime.date | None | Unset = UNSET
    fiscal_year: int | None | Unset = UNSET
    fiscal_period: None | str | Unset = UNSET
    currency: None | str | Unset = UNSET
    market_cap: float | int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        symbol = self.symbol

        period_ending: None | str | Unset
        if isinstance(self.period_ending, Unset):
            period_ending = UNSET
        elif isinstance(self.period_ending, datetime.date):
            period_ending = self.period_ending.isoformat()
        else:
            period_ending = self.period_ending

        fiscal_year: int | None | Unset
        if isinstance(self.fiscal_year, Unset):
            fiscal_year = UNSET
        else:
            fiscal_year = self.fiscal_year

        fiscal_period: None | str | Unset
        if isinstance(self.fiscal_period, Unset):
            fiscal_period = UNSET
        else:
            fiscal_period = self.fiscal_period

        currency: None | str | Unset
        if isinstance(self.currency, Unset):
            currency = UNSET
        else:
            currency = self.currency

        market_cap: float | int | None | Unset
        if isinstance(self.market_cap, Unset):
            market_cap = UNSET
        else:
            market_cap = self.market_cap

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "symbol": symbol,
            }
        )
        if period_ending is not UNSET:
            field_dict["period_ending"] = period_ending
        if fiscal_year is not UNSET:
            field_dict["fiscal_year"] = fiscal_year
        if fiscal_period is not UNSET:
            field_dict["fiscal_period"] = fiscal_period
        if currency is not UNSET:
            field_dict["currency"] = currency
        if market_cap is not UNSET:
            field_dict["market_cap"] = market_cap

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        symbol = d.pop("symbol")

        def _parse_period_ending(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                period_ending_type_0 = isoparse(data).date()

                return period_ending_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        period_ending = _parse_period_ending(d.pop("period_ending", UNSET))

        def _parse_fiscal_year(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        fiscal_year = _parse_fiscal_year(d.pop("fiscal_year", UNSET))

        def _parse_fiscal_period(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        fiscal_period = _parse_fiscal_period(d.pop("fiscal_period", UNSET))

        def _parse_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        currency = _parse_currency(d.pop("currency", UNSET))

        def _parse_market_cap(data: object) -> float | int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | int | None | Unset, data)

        market_cap = _parse_market_cap(d.pop("market_cap", UNSET))

        ak_share_key_metrics_data = cls(
            symbol=symbol,
            period_ending=period_ending,
            fiscal_year=fiscal_year,
            fiscal_period=fiscal_period,
            currency=currency,
            market_cap=market_cap,
        )

        ak_share_key_metrics_data.additional_properties = d
        return ak_share_key_metrics_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
