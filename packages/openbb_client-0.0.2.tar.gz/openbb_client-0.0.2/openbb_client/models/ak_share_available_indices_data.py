from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AKShareAvailableIndicesData")


@_attrs_define
class AKShareAvailableIndicesData:
    """AKShare Available Indices Data.

    Attributes:
        symbol (str): Symbol for the index.
        name (None | str | Unset):
        exchange (None | str | Unset): Stock exchange where the index is listed.
        currency (None | str | Unset): Currency the index is traded in.
        publish_date (datetime.date | None | Unset): The date of the index published.
    """

    symbol: str
    name: None | str | Unset = UNSET
    exchange: None | str | Unset = UNSET
    currency: None | str | Unset = UNSET
    publish_date: datetime.date | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        symbol = self.symbol

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        exchange: None | str | Unset
        if isinstance(self.exchange, Unset):
            exchange = UNSET
        else:
            exchange = self.exchange

        currency: None | str | Unset
        if isinstance(self.currency, Unset):
            currency = UNSET
        else:
            currency = self.currency

        publish_date: None | str | Unset
        if isinstance(self.publish_date, Unset):
            publish_date = UNSET
        elif isinstance(self.publish_date, datetime.date):
            publish_date = self.publish_date.isoformat()
        else:
            publish_date = self.publish_date

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "symbol": symbol,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name
        if exchange is not UNSET:
            field_dict["exchange"] = exchange
        if currency is not UNSET:
            field_dict["currency"] = currency
        if publish_date is not UNSET:
            field_dict["publish_date"] = publish_date

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        symbol = d.pop("symbol")

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_exchange(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        exchange = _parse_exchange(d.pop("exchange", UNSET))

        def _parse_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        currency = _parse_currency(d.pop("currency", UNSET))

        def _parse_publish_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                publish_date_type_0 = isoparse(data).date()

                return publish_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        publish_date = _parse_publish_date(d.pop("publish_date", UNSET))

        ak_share_available_indices_data = cls(
            symbol=symbol,
            name=name,
            exchange=exchange,
            currency=currency,
            publish_date=publish_date,
        )

        ak_share_available_indices_data.additional_properties = d
        return ak_share_available_indices_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
