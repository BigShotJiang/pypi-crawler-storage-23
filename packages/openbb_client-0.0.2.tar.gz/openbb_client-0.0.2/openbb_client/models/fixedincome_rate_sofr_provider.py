from enum import Enum


class FixedincomeRateSofrProvider(str, Enum):
    FEDERAL_RESERVE = "federal_reserve"
    FRED = "fred"

    def __str__(self) -> str:
        return str(self.value)
