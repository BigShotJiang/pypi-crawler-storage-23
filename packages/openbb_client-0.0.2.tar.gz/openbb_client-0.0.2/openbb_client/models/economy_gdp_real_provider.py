from enum import Enum


class EconomyGdpRealProvider(str, Enum):
    ECONDB = "econdb"
    OECD = "oecd"

    def __str__(self) -> str:
        return str(self.value)
