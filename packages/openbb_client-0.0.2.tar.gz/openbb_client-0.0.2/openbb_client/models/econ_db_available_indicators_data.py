from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="EconDbAvailableIndicatorsData")


@_attrs_define
class EconDbAvailableIndicatorsData:
    """EconDB Available Indicators Data.

    Attributes:
        multiplier (int | None): The multiplier of the data to arrive at whole units.
        transformation (str): Transformation type.
        symbol_root (None | str | Unset): The root symbol representing the indicator.
        symbol (None | str | Unset): Symbol representing the entity requested in the data. The root symbol with
            additional codes.
        country (None | str | Unset): The name of the country, region, or entity represented by the symbol.
        iso (None | str | Unset): The ISO code of the country, region, or entity represented by the symbol.
        description (None | str | Unset): The description of the indicator.
        frequency (None | str | Unset): The frequency of the indicator data.
        currency (None | str | Unset): The currency, or unit, the data is based in.
        scale (None | str | Unset): The scale of the data.
        source (None | str | Unset): The original source of the data.
        first_date (datetime.date | None | Unset): The first date of the data.
        last_date (datetime.date | None | Unset): The last date of the data.
        last_insert_timestamp (datetime.datetime | None | Unset): The time of the last update. Data is typically
            reported with a lag.
    """

    multiplier: int | None
    transformation: str
    symbol_root: None | str | Unset = UNSET
    symbol: None | str | Unset = UNSET
    country: None | str | Unset = UNSET
    iso: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    frequency: None | str | Unset = UNSET
    currency: None | str | Unset = UNSET
    scale: None | str | Unset = UNSET
    source: None | str | Unset = UNSET
    first_date: datetime.date | None | Unset = UNSET
    last_date: datetime.date | None | Unset = UNSET
    last_insert_timestamp: datetime.datetime | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        multiplier: int | None
        multiplier = self.multiplier

        transformation = self.transformation

        symbol_root: None | str | Unset
        if isinstance(self.symbol_root, Unset):
            symbol_root = UNSET
        else:
            symbol_root = self.symbol_root

        symbol: None | str | Unset
        if isinstance(self.symbol, Unset):
            symbol = UNSET
        else:
            symbol = self.symbol

        country: None | str | Unset
        if isinstance(self.country, Unset):
            country = UNSET
        else:
            country = self.country

        iso: None | str | Unset
        if isinstance(self.iso, Unset):
            iso = UNSET
        else:
            iso = self.iso

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        frequency: None | str | Unset
        if isinstance(self.frequency, Unset):
            frequency = UNSET
        else:
            frequency = self.frequency

        currency: None | str | Unset
        if isinstance(self.currency, Unset):
            currency = UNSET
        else:
            currency = self.currency

        scale: None | str | Unset
        if isinstance(self.scale, Unset):
            scale = UNSET
        else:
            scale = self.scale

        source: None | str | Unset
        if isinstance(self.source, Unset):
            source = UNSET
        else:
            source = self.source

        first_date: None | str | Unset
        if isinstance(self.first_date, Unset):
            first_date = UNSET
        elif isinstance(self.first_date, datetime.date):
            first_date = self.first_date.isoformat()
        else:
            first_date = self.first_date

        last_date: None | str | Unset
        if isinstance(self.last_date, Unset):
            last_date = UNSET
        elif isinstance(self.last_date, datetime.date):
            last_date = self.last_date.isoformat()
        else:
            last_date = self.last_date

        last_insert_timestamp: None | str | Unset
        if isinstance(self.last_insert_timestamp, Unset):
            last_insert_timestamp = UNSET
        elif isinstance(self.last_insert_timestamp, datetime.datetime):
            last_insert_timestamp = self.last_insert_timestamp.isoformat()
        else:
            last_insert_timestamp = self.last_insert_timestamp

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "multiplier": multiplier,
                "transformation": transformation,
            }
        )
        if symbol_root is not UNSET:
            field_dict["symbol_root"] = symbol_root
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if country is not UNSET:
            field_dict["country"] = country
        if iso is not UNSET:
            field_dict["iso"] = iso
        if description is not UNSET:
            field_dict["description"] = description
        if frequency is not UNSET:
            field_dict["frequency"] = frequency
        if currency is not UNSET:
            field_dict["currency"] = currency
        if scale is not UNSET:
            field_dict["scale"] = scale
        if source is not UNSET:
            field_dict["source"] = source
        if first_date is not UNSET:
            field_dict["first_date"] = first_date
        if last_date is not UNSET:
            field_dict["last_date"] = last_date
        if last_insert_timestamp is not UNSET:
            field_dict["last_insert_timestamp"] = last_insert_timestamp

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_multiplier(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        multiplier = _parse_multiplier(d.pop("multiplier"))

        transformation = d.pop("transformation")

        def _parse_symbol_root(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbol_root = _parse_symbol_root(d.pop("symbol_root", UNSET))

        def _parse_symbol(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbol = _parse_symbol(d.pop("symbol", UNSET))

        def _parse_country(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        country = _parse_country(d.pop("country", UNSET))

        def _parse_iso(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        iso = _parse_iso(d.pop("iso", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_frequency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        frequency = _parse_frequency(d.pop("frequency", UNSET))

        def _parse_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        currency = _parse_currency(d.pop("currency", UNSET))

        def _parse_scale(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        scale = _parse_scale(d.pop("scale", UNSET))

        def _parse_source(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        source = _parse_source(d.pop("source", UNSET))

        def _parse_first_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                first_date_type_0 = isoparse(data).date()

                return first_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        first_date = _parse_first_date(d.pop("first_date", UNSET))

        def _parse_last_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_date_type_0 = isoparse(data).date()

                return last_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        last_date = _parse_last_date(d.pop("last_date", UNSET))

        def _parse_last_insert_timestamp(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_insert_timestamp_type_0 = isoparse(data)

                return last_insert_timestamp_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_insert_timestamp = _parse_last_insert_timestamp(d.pop("last_insert_timestamp", UNSET))

        econ_db_available_indicators_data = cls(
            multiplier=multiplier,
            transformation=transformation,
            symbol_root=symbol_root,
            symbol=symbol,
            country=country,
            iso=iso,
            description=description,
            frequency=frequency,
            currency=currency,
            scale=scale,
            source=source,
            first_date=first_date,
            last_date=last_date,
            last_insert_timestamp=last_insert_timestamp,
        )

        econ_db_available_indicators_data.additional_properties = d
        return econ_db_available_indicators_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
