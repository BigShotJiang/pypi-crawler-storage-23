from enum import Enum


class EquityFundamentalMetricsFmp(str, Enum):
    EXCLUDE = "exclude"
    INCLUDE = "include"
    ONLY = "only"

    def __str__(self) -> str:
        return str(self.value)
