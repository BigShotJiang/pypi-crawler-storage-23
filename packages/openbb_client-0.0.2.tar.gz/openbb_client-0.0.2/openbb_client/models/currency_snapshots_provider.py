from enum import Enum


class CurrencySnapshotsProvider(str, Enum):
    AKSHARE = "akshare"
    FMP = "fmp"
    POLYGON = "polygon"

    def __str__(self) -> str:
        return str(self.value)
