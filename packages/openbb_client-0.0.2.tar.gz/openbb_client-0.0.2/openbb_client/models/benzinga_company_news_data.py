from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="BenzingaCompanyNewsData")


@_attrs_define
class BenzingaCompanyNewsData:
    """Benzinga Company News Data.

    Attributes:
        date (datetime.datetime): The date of the data. The date of publication.
        title (str): Title of the article.
        url (str): URL to the article.
        id (str): Article ID.
        author (None | str | Unset): Author of the article.
        excerpt (None | str | Unset): Excerpt of the article text.
        body (None | str | Unset): Body of the article text.
        images (Any | None | Unset): Images associated with the article.
        symbols (None | str | Unset): Symbols associated with the article.
        channels (None | str | Unset): Channels associated with the news.
        tags (None | str | Unset): Tags associated with the news.
        updated (datetime.datetime | None | Unset): Updated date of the news.
        original_id (None | str | Unset): Original ID of the news article.
    """

    date: datetime.datetime
    title: str
    url: str
    id: str
    author: None | str | Unset = UNSET
    excerpt: None | str | Unset = UNSET
    body: None | str | Unset = UNSET
    images: Any | None | Unset = UNSET
    symbols: None | str | Unset = UNSET
    channels: None | str | Unset = UNSET
    tags: None | str | Unset = UNSET
    updated: datetime.datetime | None | Unset = UNSET
    original_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date = self.date.isoformat()

        title = self.title

        url = self.url

        id = self.id

        author: None | str | Unset
        if isinstance(self.author, Unset):
            author = UNSET
        else:
            author = self.author

        excerpt: None | str | Unset
        if isinstance(self.excerpt, Unset):
            excerpt = UNSET
        else:
            excerpt = self.excerpt

        body: None | str | Unset
        if isinstance(self.body, Unset):
            body = UNSET
        else:
            body = self.body

        images: Any | None | Unset
        if isinstance(self.images, Unset):
            images = UNSET
        else:
            images = self.images

        symbols: None | str | Unset
        if isinstance(self.symbols, Unset):
            symbols = UNSET
        else:
            symbols = self.symbols

        channels: None | str | Unset
        if isinstance(self.channels, Unset):
            channels = UNSET
        else:
            channels = self.channels

        tags: None | str | Unset
        if isinstance(self.tags, Unset):
            tags = UNSET
        else:
            tags = self.tags

        updated: None | str | Unset
        if isinstance(self.updated, Unset):
            updated = UNSET
        elif isinstance(self.updated, datetime.datetime):
            updated = self.updated.isoformat()
        else:
            updated = self.updated

        original_id: None | str | Unset
        if isinstance(self.original_id, Unset):
            original_id = UNSET
        else:
            original_id = self.original_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
                "title": title,
                "url": url,
                "id": id,
            }
        )
        if author is not UNSET:
            field_dict["author"] = author
        if excerpt is not UNSET:
            field_dict["excerpt"] = excerpt
        if body is not UNSET:
            field_dict["body"] = body
        if images is not UNSET:
            field_dict["images"] = images
        if symbols is not UNSET:
            field_dict["symbols"] = symbols
        if channels is not UNSET:
            field_dict["channels"] = channels
        if tags is not UNSET:
            field_dict["tags"] = tags
        if updated is not UNSET:
            field_dict["updated"] = updated
        if original_id is not UNSET:
            field_dict["original_id"] = original_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = isoparse(d.pop("date"))

        title = d.pop("title")

        url = d.pop("url")

        id = d.pop("id")

        def _parse_author(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        author = _parse_author(d.pop("author", UNSET))

        def _parse_excerpt(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        excerpt = _parse_excerpt(d.pop("excerpt", UNSET))

        def _parse_body(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        body = _parse_body(d.pop("body", UNSET))

        def _parse_images(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        images = _parse_images(d.pop("images", UNSET))

        def _parse_symbols(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbols = _parse_symbols(d.pop("symbols", UNSET))

        def _parse_channels(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        channels = _parse_channels(d.pop("channels", UNSET))

        def _parse_tags(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tags = _parse_tags(d.pop("tags", UNSET))

        def _parse_updated(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_type_0 = isoparse(data)

                return updated_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        updated = _parse_updated(d.pop("updated", UNSET))

        def _parse_original_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        original_id = _parse_original_id(d.pop("original_id", UNSET))

        benzinga_company_news_data = cls(
            date=date,
            title=title,
            url=url,
            id=id,
            author=author,
            excerpt=excerpt,
            body=body,
            images=images,
            symbols=symbols,
            channels=channels,
            tags=tags,
            updated=updated,
            original_id=original_id,
        )

        benzinga_company_news_data.additional_properties = d
        return benzinga_company_news_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
