from enum import Enum


class EtfSearchExchangeType1(str, Enum):
    ARCX = "arcx"
    BATS = "bats"
    BVMF = "bvmf"
    ROCO = "roco"
    TASE = "tase"
    XBKK = "xbkk"
    XBOM = "xbom"
    XHKG = "xhkg"
    XIDX = "xidx"
    XIST = "xist"
    XKLS = "xkls"
    XKRX = "xkrx"
    XMEX = "xmex"
    XNAS = "xnas"
    XNSE = "xnse"
    XNYS = "xnys"
    XSES = "xses"
    XSHE = "xshe"
    XSHG = "xshg"
    XTAI = "xtai"

    def __str__(self) -> str:
        return str(self.value)
