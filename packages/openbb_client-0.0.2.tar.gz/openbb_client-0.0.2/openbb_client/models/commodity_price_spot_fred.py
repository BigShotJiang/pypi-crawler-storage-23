from enum import Enum


class CommodityPriceSpotFred(str, Enum):
    ALL = "all"
    BRENT = "brent"
    DIESEL_GULF_COAST = "diesel_gulf_coast"
    DIESEL_LA = "diesel_la"
    DIESEL_NY_HARBOR = "diesel_ny_harbor"
    GASOLINE_GULF_COAST = "gasoline_gulf_coast"
    GASOLINE_NY_HARBOR = "gasoline_ny_harbor"
    HEATING_OIL = "heating_oil"
    JET_FUEL = "jet_fuel"
    NATURAL_GAS = "natural_gas"
    PROPANE = "propane"
    RBOB = "rbob"
    WTI = "wti"

    def __str__(self) -> str:
        return str(self.value)
