from enum import Enum


class FixedincomeGovernmentTreasuryPricesSecurityTypeType0(str, Enum):
    BILL = "bill"
    BOND = "bond"
    FRN = "frn"
    NOTE = "note"
    TIPS = "tips"

    def __str__(self) -> str:
        return str(self.value)
