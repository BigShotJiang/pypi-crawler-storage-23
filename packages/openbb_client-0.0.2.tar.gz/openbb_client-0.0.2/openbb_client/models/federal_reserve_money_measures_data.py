from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FederalReserveMoneyMeasuresData")


@_attrs_define
class FederalReserveMoneyMeasuresData:
    """FederalReserve Money Measures Data.

    Attributes:
        month (datetime.date): The date of the data.
        m1 (float): Value of the M1 money supply in billions.
        m2 (float): Value of the M2 money supply in billions.
        currency (float | None | Unset): Value of currency in circulation in billions.
        demand_deposits (float | None | Unset): Value of demand deposits in billions.
        retail_money_market_funds (float | None | Unset): Value of retail money market funds in billions.
        other_liquid_deposits (float | None | Unset): Value of other liquid deposits in billions.
        small_denomination_time_deposits (float | None | Unset): Value of small denomination time deposits in billions.
    """

    month: datetime.date
    m1: float
    m2: float
    currency: float | None | Unset = UNSET
    demand_deposits: float | None | Unset = UNSET
    retail_money_market_funds: float | None | Unset = UNSET
    other_liquid_deposits: float | None | Unset = UNSET
    small_denomination_time_deposits: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        month = self.month.isoformat()

        m1 = self.m1

        m2 = self.m2

        currency: float | None | Unset
        if isinstance(self.currency, Unset):
            currency = UNSET
        else:
            currency = self.currency

        demand_deposits: float | None | Unset
        if isinstance(self.demand_deposits, Unset):
            demand_deposits = UNSET
        else:
            demand_deposits = self.demand_deposits

        retail_money_market_funds: float | None | Unset
        if isinstance(self.retail_money_market_funds, Unset):
            retail_money_market_funds = UNSET
        else:
            retail_money_market_funds = self.retail_money_market_funds

        other_liquid_deposits: float | None | Unset
        if isinstance(self.other_liquid_deposits, Unset):
            other_liquid_deposits = UNSET
        else:
            other_liquid_deposits = self.other_liquid_deposits

        small_denomination_time_deposits: float | None | Unset
        if isinstance(self.small_denomination_time_deposits, Unset):
            small_denomination_time_deposits = UNSET
        else:
            small_denomination_time_deposits = self.small_denomination_time_deposits

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "month": month,
                "m1": m1,
                "m2": m2,
            }
        )
        if currency is not UNSET:
            field_dict["currency"] = currency
        if demand_deposits is not UNSET:
            field_dict["demand_deposits"] = demand_deposits
        if retail_money_market_funds is not UNSET:
            field_dict["retail_money_market_funds"] = retail_money_market_funds
        if other_liquid_deposits is not UNSET:
            field_dict["other_liquid_deposits"] = other_liquid_deposits
        if small_denomination_time_deposits is not UNSET:
            field_dict["small_denomination_time_deposits"] = small_denomination_time_deposits

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        month = isoparse(d.pop("month")).date()

        m1 = d.pop("m1")

        m2 = d.pop("m2")

        def _parse_currency(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        currency = _parse_currency(d.pop("currency", UNSET))

        def _parse_demand_deposits(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        demand_deposits = _parse_demand_deposits(d.pop("demand_deposits", UNSET))

        def _parse_retail_money_market_funds(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        retail_money_market_funds = _parse_retail_money_market_funds(d.pop("retail_money_market_funds", UNSET))

        def _parse_other_liquid_deposits(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        other_liquid_deposits = _parse_other_liquid_deposits(d.pop("other_liquid_deposits", UNSET))

        def _parse_small_denomination_time_deposits(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        small_denomination_time_deposits = _parse_small_denomination_time_deposits(
            d.pop("small_denomination_time_deposits", UNSET)
        )

        federal_reserve_money_measures_data = cls(
            month=month,
            m1=m1,
            m2=m2,
            currency=currency,
            demand_deposits=demand_deposits,
            retail_money_market_funds=retail_money_market_funds,
            other_liquid_deposits=other_liquid_deposits,
            small_denomination_time_deposits=small_denomination_time_deposits,
        )

        federal_reserve_money_measures_data.additional_properties = d
        return federal_reserve_money_measures_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
