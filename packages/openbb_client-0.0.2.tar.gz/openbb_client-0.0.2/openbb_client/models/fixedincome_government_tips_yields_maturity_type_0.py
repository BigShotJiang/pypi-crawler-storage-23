from enum import Enum


class FixedincomeGovernmentTipsYieldsMaturityType0(str, Enum):
    VALUE_0 = "5"
    VALUE_1 = "10"
    VALUE_2 = "20"
    VALUE_3 = "30"

    def __str__(self) -> str:
        return str(self.value)
