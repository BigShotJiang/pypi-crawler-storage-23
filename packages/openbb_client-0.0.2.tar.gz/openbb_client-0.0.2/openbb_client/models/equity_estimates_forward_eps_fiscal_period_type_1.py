from enum import Enum


class EquityEstimatesForwardEpsFiscalPeriodType1(str, Enum):
    FY = "fy"
    Q1 = "q1"
    Q2 = "q2"
    Q3 = "q3"
    Q4 = "q4"

    def __str__(self) -> str:
        return str(self.value)
