from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FMPCompanyNewsData")


@_attrs_define
class FMPCompanyNewsData:
    """FMP Company News Data.

    Attributes:
        date (datetime.datetime): The date of the data. The date of publication.
        title (str): Title of the article.
        url (str): URL to the article.
        source (str): Name of the news site.
        author (None | str | Unset): Author of the article.
        excerpt (None | str | Unset): Excerpt of the article text.
        body (None | str | Unset): Body of the article text.
        images (Any | None | Unset): Images associated with the article.
        symbols (None | str | Unset): Symbols associated with the article.
    """

    date: datetime.datetime
    title: str
    url: str
    source: str
    author: None | str | Unset = UNSET
    excerpt: None | str | Unset = UNSET
    body: None | str | Unset = UNSET
    images: Any | None | Unset = UNSET
    symbols: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date = self.date.isoformat()

        title = self.title

        url = self.url

        source = self.source

        author: None | str | Unset
        if isinstance(self.author, Unset):
            author = UNSET
        else:
            author = self.author

        excerpt: None | str | Unset
        if isinstance(self.excerpt, Unset):
            excerpt = UNSET
        else:
            excerpt = self.excerpt

        body: None | str | Unset
        if isinstance(self.body, Unset):
            body = UNSET
        else:
            body = self.body

        images: Any | None | Unset
        if isinstance(self.images, Unset):
            images = UNSET
        else:
            images = self.images

        symbols: None | str | Unset
        if isinstance(self.symbols, Unset):
            symbols = UNSET
        else:
            symbols = self.symbols

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
                "title": title,
                "url": url,
                "source": source,
            }
        )
        if author is not UNSET:
            field_dict["author"] = author
        if excerpt is not UNSET:
            field_dict["excerpt"] = excerpt
        if body is not UNSET:
            field_dict["body"] = body
        if images is not UNSET:
            field_dict["images"] = images
        if symbols is not UNSET:
            field_dict["symbols"] = symbols

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = isoparse(d.pop("date"))

        title = d.pop("title")

        url = d.pop("url")

        source = d.pop("source")

        def _parse_author(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        author = _parse_author(d.pop("author", UNSET))

        def _parse_excerpt(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        excerpt = _parse_excerpt(d.pop("excerpt", UNSET))

        def _parse_body(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        body = _parse_body(d.pop("body", UNSET))

        def _parse_images(data: object) -> Any | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Any | None | Unset, data)

        images = _parse_images(d.pop("images", UNSET))

        def _parse_symbols(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbols = _parse_symbols(d.pop("symbols", UNSET))

        fmp_company_news_data = cls(
            date=date,
            title=title,
            url=url,
            source=source,
            author=author,
            excerpt=excerpt,
            body=body,
            images=images,
            symbols=symbols,
        )

        fmp_company_news_data.additional_properties = d
        return fmp_company_news_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
