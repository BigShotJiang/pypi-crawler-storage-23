from enum import Enum


class FixedincomeMortgageIndicesIndexType0(str, Enum):
    CONFORMING_15Y = "conforming_15y"
    CONFORMING_30Y = "conforming_30y"
    CONFORMING_30Y_NA = "conforming_30y_na"
    FHA_30Y = "fha_30y"
    JUMBO_30Y = "jumbo_30y"
    LTV_GT80_FICO_A680B699 = "ltv_gt80_fico_a680b699"
    LTV_GT80_FICO_A700B719 = "ltv_gt80_fico_a700b719"
    LTV_GT80_FICO_A720B739 = "ltv_gt80_fico_a720b739"
    LTV_GT80_FICO_GE740 = "ltv_gt80_fico_ge740"
    LTV_GT80_FICO_LT680 = "ltv_gt80_fico_lt680"
    LTV_GT_80 = "ltv_gt_80"
    LTV_LTE80_FICO_A680B699 = "ltv_lte80_fico_a680b699"
    LTV_LTE80_FICO_A700B719 = "ltv_lte80_fico_a700b719"
    LTV_LTE80_FICO_A720B739 = "ltv_lte80_fico_a720b739"
    LTV_LTE80_FICO_GE740 = "ltv_lte80_fico_ge740"
    LTV_LTE80_FICO_LT680 = "ltv_lte80_fico_lt680"
    LTV_LTE_80 = "ltv_lte_80"
    PRIMARY = "primary"
    USDA_30Y = "usda_30y"
    VA_30Y = "va_30y"

    def __str__(self) -> str:
        return str(self.value)
