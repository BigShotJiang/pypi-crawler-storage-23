from enum import Enum


class EquityPriceHistoricalIntervalType4(str, Enum):
    VALUE_0 = "1m"
    VALUE_1 = "2m"
    VALUE_10 = "1W"
    VALUE_11 = "1M"
    VALUE_12 = "1Q"
    VALUE_2 = "5m"
    VALUE_3 = "15m"
    VALUE_4 = "30m"
    VALUE_5 = "60m"
    VALUE_6 = "90m"
    VALUE_7 = "1h"
    VALUE_8 = "1d"
    VALUE_9 = "5d"

    def __str__(self) -> str:
        return str(self.value)
